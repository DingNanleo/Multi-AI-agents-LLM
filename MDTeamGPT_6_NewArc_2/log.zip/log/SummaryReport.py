import re
from ast import literal_eval
from collections import defaultdict

def analyze_markdown_log(file_path):
    # Initialize data structures (保持原样)
    case_ids = []
    case_results = {}
    error_cases = {}
    
    # 只修改正则表达式部分
    case_start_pattern = re.compile(r'Processing case \d+/\d+ \(ID: (\d+)\)')
    error_pattern = re.compile(r'Error processing case (\d+): (.+)')
    # 修改后的case_result正则表达式，确保匹配完整结果
    case_result_pattern = re.compile(r'Case result: (\{(?:[^{}]|(?:\{[^{}]*\}))*\})', re.DOTALL)

    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
        
        # Find all case IDs (保持原样)
        case_ids = case_start_pattern.findall(content)
        
        # Find all errors (保持原样)
        for case_id, error_msg in error_pattern.findall(content):
            error_cases[case_id] = error_msg.strip('` |')  # 只增加去除特殊字符
        
        # Find all case results (核心修改部分)
        case_result_matches = case_result_pattern.finditer(content)
        
        for result in case_result_matches:
            result_str = result.group(1)
            try:
                # 使用更安全的literal_eval替代eval
                # 先替换单引号为双引号以便json解析
                result_str_fixed = result_str.replace("'", '"')
                result_dict = literal_eval(result_str_fixed)
                
                case_id = str(result_dict.get('Question_ID', ''))
                if case_id:
                    case_results[case_id] = {
                        'official_answer': result_dict.get('Official_Answer', ''),
                        'consensus_answer': result_dict.get('Consensused_Answer', {}),
                        'is_correct': result_dict.get('Is_Correct', None),
                        'correct_key': result_dict.get('Correct_Answer_Key', ''),
                        'expert_key': result_dict.get('Expert_Answer_Key', '')
                    }
            except:
                continue
    
    # 以下保持完全不变
    total_cases = len(case_ids)
    correct = sum(1 for res in case_results.values() if res.get('is_correct') is True)
    incorrect = sum(1 for res in case_results.values() if res.get('is_correct') is False)
    errors = len(error_cases)
    unknown = total_cases - (correct + incorrect + errors)
    
    report = "Medical Consultation Log Analysis Report\n"
    report += "=======================================\n"
    report += f"1) Total cases processed: {total_cases}\n\n"
    report += f"2) Case IDs processed:\n"
    report += f"   {', '.join(case_ids)}\n\n"
    
    report += "3) Detailed Case Statuses:\n"
    for case_id in case_ids:
        if case_id in error_cases:
            report += f"   - Case {case_id}: ERROR - {error_cases[case_id]}\n"
        elif case_id in case_results:
            res = case_results[case_id]
            if res['is_correct'] is True:
                report += f"   - Case {case_id}: CORRECT\n"
            elif res['is_correct'] is False:
                report += f"   - Case {case_id}: INCORRECT\n"
            else:
                report += f"   - Case {case_id}: PROCESSED BUT UNKNOWN RESULT\n"
            
            report += f"     Official Answer: {res['official_answer']}\n"
            report += f"     Consensus Answer: {res['consensus_answer']}\n"
            report += f"     Correct Key: {res['correct_key']} vs Expert Key: {res['expert_key']}\n"
        else:
            report += f"   - Case {case_id}: Status unknown (no result found)\n"
    
    report += "\n4) Summary Statistics:\n"
    report += f"   - Correct answers: {correct} ({correct/total_cases*100:.1f}%)\n"
    report += f"   - Incorrect answers: {incorrect} ({incorrect/total_cases*100:.1f}%)\n"
    report += f"   - Errors: {errors} ({errors/total_cases*100:.1f}%)\n"
    report += f"   - Unknown status: {unknown} ({unknown/total_cases*100:.1f}%)\n"
    
    return report

if __name__ == "__main__":
    file_path = 'log/medqa_main_20250807_231613.md'
    
    try:
        report = analyze_markdown_log(file_path)
        print(report)
        
        with open('log/consultation_report_20250807_231613.txt', 'w', encoding='utf-8') as f:
            f.write(report)
        print("\nReport saved.")
    except Exception as e:
        print(f"Error: {str(e)}")