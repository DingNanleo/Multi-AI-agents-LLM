## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 185: Alcohols
Jennifer P. Cohen; Dan Quan
INTRODUCTION
All alcohols cause clinical inebriation, with the strength of the inebriating effects directly proportional to the alcohol’s molecular weight; hence, at the same concentration, isopropanol is more intoxicating than ethanol (Figure 185­1).
FIGURE 185­1. Chemical structures of the common alcohols.
Primary toxicity can be due to the parent compound (ethanol and isopropanol) or to toxic metabolites (ethylene glycol and methanol). Ethanol and isopropanol are the most common alcohols ingested; their principal effects are GI irritation and intoxication, and they do not in themselves produce a clinically relevant metabolic acidosis. Methanol and ethylene glycol are toxic alcohols because they cause serious multisystem damage and metabolic acidosis.
ETHANOL
INTRODUCTION
Ethanol (CH CH OH, molecular weight .07) is a colorless, volatile liquid that is the most frequently used and abused drug in the world. Morbidity
  from acute ethanol intoxication is usually related to secondary injuries rather than direct toxic effects. Intoxication most commonly occurs from ingestion, but ethanol may also be absorbed via inhalation or percutaneous exposure.
Ethanol is usually consumed as an alcoholic beverage, such as  oz (355 mL) of beer (2% to 6% ethanol by volume),  oz (148 mL) of wine (10% to 20% ethanol by volume), or .5 oz (44 mL) of 80­proof spirits (40% ethanol by volume), each serving containing about  grams of ethanol. Ethanol may be found in high concentrations in many other common household products such as mouthwash (may contain up to 75% ethanol by volume) and colognes and perfumes (up to 40% to 60%), and as a diluent or solvent for medications (concentration varies widely between .4% and 65%). Such products are often flavored or brightly colored and may be attractive to children.
PATHOPHYSIOLOGY
Ethanol is rapidly absorbed after oral administration, and blood levels peak about  to  minutes after ingestion. The presence of food in the stomach prolongs absorption and delays the peak blood level. High concentrations of ethanol in the stomach may cause pylorospasm, delaying gastric emptying. Some ethanol is broken down in the stomach by gastric alcohol dehydrogenase, which lowers the amount available for absorption. This enzyme is present at higher levels in men than in women, which may account for the fact that women usually develop a higher blood ethanol level than men after consuming the same dose per kilogram of body weight.

Ethanol is a CNS depressant that enhances the inhibitory neurotransmitter γ­aminobutyric acid receptors and blockade of excitatory N­methyl­D­
Chapter 185: Alcohols, Jennifer P. Cohen; Dan Quan a©s2p0a2rt5i cM accGidr arewc eHpitllo. rAsl.l MRoigdhutlsa tRioens eorfv tehde.s e Tsyesrtmesm osf l eUasdes * t oP trihvea cdye vPeololipcym * e nNto otifc teo l * e Aracnccees, sdiebpilietyndence, and a withdrawal syndrome when ethanol intake ceases in dependent individuals.
Because of the phenomenon of tolerance, blood ethanol levels correlate poorly with degree of intoxication. Although death from respiratory depression may occur in nonhabituated individuals at concentrations of 400 to 500 milligrams/dL (87 to 109 mmol/L), some alcoholic individuals can
 appear minimally intoxicated at blood concentrations as high as 400 milligrams/dL (87 mmol/L). Although Canada, Mexico, and the United States have adopted  milligrams/dL (17 mmol/L) as the legal definition of intoxication for the purposes of driving a motor vehicle, impairment may occur with
 levels as low as  milligrams/dL (11 mmol/L), especially in nonhabituated individuals.
Ethanol is predominantly eliminated by hepatic metabolism, with about 10% excreted in the urine, exhaled breath, and sweat. Alcohol dehydrogenase (Figure 185­2) is the major enzyme involved in the metabolism of ethanol, producing acetaldehyde. At low ethanol concentrations,
 this process follows first­order kinetics, but as concentrations rise, alcohol dehydrogenase becomes saturated and metabolism switches to zeroorder kinetics—a fixed amount is metabolized per unit of time. Also, as ethanol concentrations rise, the hepatic microsomal oxidizing system
(specifically, cytochrome P450 2E1 [CYP2E1]) plays a more important role in metabolism.
FIGURE 185­2. Metabolism of ethanol. CoA = coenzyme A.
Both alcohol dehydrogenase and CYP2E1 are inducible and thus are more active in chronic ethanol users. Therefore, rates of ethanol elimination from the blood vary from about  milligrams/dL per hour (4 mmol/L per hour) in nonhabituated individuals to up to  milligrams/dL per hour (6 mmol/L per hour) in individuals with chronic alcoholism.
CLINICAL FEATURES

The hallmark of ethanol toxicity is clinical inebriation. Behavioral disinhibition may initially appear as euphoria or agitation and combativeness. As intoxication becomes more severe, slurred speech, nystagmus, ataxia, and decreased motor coordination develop. Severe intoxication may cause respiratory depression and coma. Nausea and vomiting often occur in conjunction with neurologic depression.
Ethanol causes peripheral vasodilation and flushed, warm skin, enabling loss to the environment and promoting hypothermia. Vasodilation may also lead to orthostatic hypotension and reflex tachycardia. Ethanol­induced hypotension is usually mild and transient, so significant or persistent hypotension warrants investigation for alternative causes.
Ethanol ingestion may cause hypoglycemia, usually in children and malnourished individuals due to low glycogen stores and reduced gluconeogenesis. The metabolism of ethanol by alcohol dehydrogenase requires the presence of the oxidized form of nicotinamide adenine
+ dinucleotide (NAD ), which is then converted into its reduced form (NADH). The metabolism of a significant amount of ethanol increases the
+
NADH/NAD ratio, which then promotes the conversion of pyruvate to lactate, diverting pyruvate away from the gluconeogenesis pathway (Figure
185­3).
FIGURE 185­3. +
Conversion of pyruvate to lactate. LDH = lactate dehydrogenase; NAD = oxidized form of nicotinamide adenine dinucleotide; NADH = reduced form of nicotinamide adenine dinucleotide.
When a chronic alcoholic suddenly stops consuming calories in the form of either ethanol or food, the body uses alternative fuel sources and begins to break down adipose tissue. This metabolism of fatty acids results in ketoacidosis (see Chapter 226, “Ketoacidotic Syndromes”).
DIAGNOSIS
Ethanol­intoxicated patients often have other disease processes, such as infections and traumatic injuries, so perform a detailed physical examination, looking especially for evidence of trauma, and obtain as much history as possible. Uncomplicated ethanol intoxication improves over a few hours. If depressed mental status fails to improve or deteriorates, consider other causes of altered mental status and evaluate appropriately.
The clinical assessment guides the selection of laboratory tests. For altered levels of consciousness, obtain a point­of­care glucose level. Ethanol levels are not necessarily required in cases of mild or moderate intoxication when no other abnormality is suspected, but measure serum alcohol levels in patients with altered mental status of unclear cause. Estimation of ethanol level is unreliable, particularly around levels of 100 milligrams/dL (22
,7  mmol/L) or in alcohol­tolerant patients. In isolated ethanol intoxication, the presence of horizontal gaze nystagmus has a sensitivity of 70% to 80%
9­11 for a blood ethanol level of  milligrams/dL (17 mmol/L) and a sensitivity of 80% to 90% for blood ethanol levels >100 milligrams/dL (22 mmol/L).
Ask about concomitant drug use, especially cocaine. The attraction of abusing these drugs together may relate to the formation of the active cocaine
 metabolite cocaethylene, which, although less potent than the parent compound, has a half­life that is three to five times longer. The risk of sudden death among users of both drugs simultaneously is higher than that among cocaine users alone.
Ethanol ingestion is the most common cause of an osmolar gap on serum electrolyte analysis (see Chapter , “Fluids and Electrolytes”) and may be
 associated with a mild metabolic acidosis, but a significant anion gap metabolic acidosis suggests the presence of lactic acidosis, ketoacidosis, or methanol or ethylene glycol toxicity.
TREATMENT

Management is observation until sobriety. Activated charcoal is not useful since ethanol is rapidly absorbed; consider activated charcoal only if toxic adsorbable substances have been co­ingested within the past hour.
Treat hypoglycemia with IV dextrose .5 to  gram/kg. Although acute Wernicke’s encephalopathy can be precipitated by prolonged sustained
,15 administration of IV carbohydrate, there is no evidence that a single dose of IV glucose can cause this syndrome. The prevalence of vitamin
 deficiencies in acutely intoxicated ED patients is low and does not justify the routine use of IV vitamin­containing fluids. Long­term drinkers may be vitamin deficient and are sometimes treated with IV fluids containing magnesium, folate, thiamine, and multivitamins, termed a banana bag because of the yellow color imparted by the multivitamin mixture.
Wernicke’s encephalopathy is characterized by abnormal mental status, ataxia, and nystagmus, and requires daily treatment with thiamine, 100 milligrams, until normal diet is resumed. Fluid administration does not hasten alcohol elimination, so establishment of IV access for fluid
 administration alone is unnecessary in uncomplicated mild to moderate intoxication.
Metadoxine, which is not currently available in the United States but is available in Latin America, Mexico, Asia, Africa, and Eastern Europe, enhances
,19 the metabolism of ethanol and accelerates recovery. Metadoxine 900 milligrams IV is reported to double the rate at which ethanol blood levels
,20 decrease with time compared with the patient’s own metabolism.
DISPOSITION AND FOLLOW­UP
Patients with acute ethanol intoxication as the only clinical problem require ED observation until sober. Prior to discharge, reassess for an underlying mental health disorder, such as suicidal or homicidal ideation, that requires further care or hospital admission. Screening for alcohol use disorder
 prior to discharge with brief intervention and referral to appropriate outpatient services is recommended to reduce future harm. Clinical judgment, rather than a serum ethanol level, determines the appropriateness of discharge. Discharge the patient in the care of a responsible companion. Patients treated for alcohol intoxication should not be responsible for their own transportation home.
ALCOHOL WITHDRAWAL SYNDROMES
INTRODUCTION
Alcohol withdrawal symptoms develop in individuals with a history of heavy and prolonged consumption of alcohol who abruptly stop or reduce their drinking. The spectrum of alcohol withdrawal symptoms includes hand tremors, headache, loss of appetite, nausea and vomiting, diaphoresis, insomnia, tachycardia, hypertension, fever, psychomotor agitation, hyperarousal, craving, and anxiety, as well as the more serious manifestations of
 seizures, hallucinations, and delirium. The abrupt withdrawal of alcohol from the brain of chronic heavy drinkers is thought to reduce inhibitory neurotransmission through γ­aminobutyric acid and enhance excitatory neurotransmission through glutamate, but not all heavy drinkers experience withdrawal when stopping or cutting back their consumption.
Alcohol withdrawal symptoms exist on a continuum from uncomplicated to moderate and severe, may begin as early as  to  hours after reduction in alcohol consumption, and can persist for up to  weeks (Table 185­1). Convulsions occur in 5% to 15%, and delirium tremens occurs in <5% of patient undergoing alcohol withdrawal; those with a prior history are at greater risk. Deaths from delirium tremens among patients receiving early and
22­24 aggressive treatment have declined from 35% in the early 20th century to <5% in the current period.
TABLE 185­1
Alcohol Withdrawal Continuum
Time Manifestations Comments
6–24 h Minor Symptoms Can be mild and patients may not require medical care
Anxiety
Insomnia
Anorexia, nausea and vomiting
Headache
Palpitations
Tremor
24–48 h Alcohol Withdrawal Hallucinations Occur in 7%–8%
Tactile most common Usually resolve in  h
Occasionally auditory or visual
36–60 h Withdrawal Seizures Occur in 5%–10%
Generalized tonic­clonic May occur as early as  h after alcohol cessation
Can be single or multiple
Status epilepticus uncommon
60+ h Delirium Tremens Peaks at  d and may last up to  d
Agitation
Disorientation
Hallucinations
Fever
Diaphoresis
Hypertension
Tachycardia
The first step in successful treatment is to identify alcohol withdrawal early and distinguish withdrawal from mimics. The most common mimics include toxic­metabolic abnormalities (hyponatremia, hypoglycemia, hypomagnesemia, diabetic ketoacidosis, Wernicke’s encephalopathy), toxic alcohol ingestions (ethylene glycol, methanol), opioid or sedative withdrawal, prescription or illicit drug ingestions (anticholinergic drugs, stimulants), neurologic abnormalities (primary generalized seizures, withdrawal seizures), and sepsis.
Gastritis, peptic ulcer disease, and pancreatitis are comorbidities with symptoms that often require abrupt cessation of alcohol consumption, leading to withdrawal. The gathering of collateral history, thorough serial examinations of the undressed patient, repeated monitoring of vital signs, measurement of oxygen saturation and point­of­care testing for blood glucose, laboratory assessment of metabolic conditions, and imaging as clinically indicated can detect most comorbidities.
WITHDRAWAL HALLUCINOSIS
About a quarter of patients in alcohol withdrawal experience transient alterations in perception or illusions, such as tactile (paresthesias), visual
(zooscopies or hallucinations of animals), or auditory (voices) illusions. Persistence of these symptoms, usually tactile or visual, is termed alcohol withdrawal hallucinations. Patients generally recognize these hallucinations as not real and maintain a clear sensorium. Tremors and other signs of alcohol withdrawal may not be present.
ALCOHOL WITHDRAWAL SEIZURES
Alcohol withdrawal seizures are diffuse tonic­clonic seizures that can occur as early as  hours after the decrease or cessation of alcohol ingestion, and

90% occur within  hours. Alcohol withdrawal seizures can be single or multiple, and a few percent of patients can progress to status epilepticus.

More than half of withdrawal seizures are associated with underlying epilepsy, brain lesions, or substance use. Focal seizures suggest a focal cerebral lesion. About one third of patients with alcohol withdrawal seizures develop delirium tremens, with the seizures terminating before the
 development of delirium. An alcohol withdrawal seizure may be brief, with a short or no postictal period. The diagnosis of alcohol withdrawal seizures requires the exclusion of traumatic brain injury, hypoxia, hypoglycemia, structural lesions, infections, use of illicit drugs, idiopathic epilepsy,
 withdrawal from other recreational drugs, withdrawal from prescription sedatives, and noncompliance with antiseizure medications.
DELIRIUM TREMENS
Alcohol withdrawal delirium tremens is characterized by acute and fluctuating disturbances in consciousness, confusion, psychomotor agitation,
 inattention, and impairment in cognitive and perceptual function (hallucinations) unrelated to preexisting or established dementia. Patients often develop life­threatening fluid, metabolic, and electrolyte imbalances. Autonomic instability is generally present. Among the risk factors associated with delirium tremens are past withdrawal seizure and delirium tremens, severe dependence and prior detoxification history, high and long duration of
 alcohol intake, older age, use of other drugs, genetic polymorphism, and comorbidities.
ALCOHOL­INDUCED PSYCHOTIC DISORDER
Alcohol­induced psychotic disorder is a separate entity from the more common withdrawal hallucinations seen as part of an acute alcohol withdrawal syndrome. In contrast to alcohol withdrawal hallucinations, auditory hallucinations predominate over visual and tactile hallucinations. They are often
 of a persecutory nature. Psychosis, paranoia, and agitation may last from days to weeks. Diagnostic criteria require that symptoms start within 
 weeks of alcohol consumption and persist for  hours or greater beyond the withdrawal state. Clouding of sensorium should be minimal.

Treatment may require short­ or long­term use of antipsychotics. Alcohol­induced psychotic disorder has a high risk for suicide and co­occurs with other psychiatric diagnoses. Patients with hallucinations lasting for >6 months have the worst prognosis; however, the prognosis is more favorable if
 abstinence can be maintained.
TREATMENT
The goals of therapy for alcohol withdrawal are to alleviate autonomic hyperactivity and agitation, halt progression to delirium tremens, and if
22­24,28 possible, provide motivation for and access to detoxification to promote long­term abstinence. Initial therapy is usually with benzodiazepines;
,24,28 no specific agent is superior to the others (Table 185­2). IV administration works the fastest, with an onset of action of  to  minutes for
 diazepam,  to  minutes for midazolam, and  to  minutes for lorazepam in alcohol withdrawal. Intramuscular absorption of lorazepam and midazolam is adequate, but absorption of IM diazepam is erratic, and therefore, IM diazepam is not recommended. Both diazepam and chlordiazepoxide are metabolized by the liver, producing long­acting active metabolites with a 20­ to 30­hour duration of action.
TABLE 185­2
Treatment of Alcohol Withdrawal Syndromes
Condition Treatment (see text)
Uncomplicated alcohol withdrawal Lorazepam  milligrams PO
(no seizures, no delirium) or
Diazepam 10–20 milligrams PO or
Oxazepam 15–30 milligrams PO or
Chlordiazepoxide 50–100 milligrams PO
If vomiting:
Diazepam 10–20 milligrams IV or
Lorazepam 2–4 milligrams IV and
Ondansetron  milligrams IV
Alcohol withdrawal seizures Lorazepam  milligrams IV
Alcohol withdrawal delirium tremens Lorazepam 2–4 milligrams IV; double the dose and repeat every 15–20 min until light somnolence or
Diazepam 10–20 milligrams IV over  min; double the dose and repeat every 5–10 min until light somnolence
If refractory to benzodiazepines:
Phenobarbital  milligrams IV every 15–30 min to maximum of 260 milligrams7 (respiratory depression more common than with benzodiazepines; typically requires intubation) or
Propofol  micrograms/kg per minute (or .3 milligram/kg per hour) titrated to effect; typically requires intubation (unlabeled use, primarily case reports of effectiveness)
Alcohol­induced psychotic disorder Abstinence from alcohol
Antipsychotics until symptoms remit
Individualized symptom­triggered therapy is recommended; such an approach results in less drug administration and shorter duration of treatment
 than fixed­drug dosing. The Clinical Institute Withdrawal Assessment for Alcohol–Revised is the most commonly used instrument for guiding
 continuing treatment once a diagnosis of alcohol withdrawal is established (Table 185­3). Symptom­triggered therapy uses hourly assessments of the Clinical Institute Withdrawal Assessment for Alcohol–Revised score to time repeat benzodiazepine doses. If the score is >15, successive doses are given every hour until the score is <15, and if the score is  to , successive doses are given every  hours until the score is <8. The Clinical Institute
Withdrawal Assessment for Alcohol–Revised has been critiqued because  of the  components require accurate communication with the patient, so
 language barriers, comorbid conditions, and medications may make it difficult to score. Alternatives to the Clinical Institute Withdrawal Assessment
 for Alcohol–Revised have been developed, but most have not been validated.
TABLE 185­3
Clinical Institute Withdrawal Assessment for Alcohol–Revised Scale* Nausea and Vomiting Tactile Disturbances
Ask “Do you feel sick to your stomach? Have you Ask “Do you have any itching, pins and needles sensations, any burning, or any numbness, or do you vomited?” feel bugs crawling on or under your skin?”
Observation: Observation:
 no nausea and no vomiting  none
 mild nausea with no vomiting  very mild itching, pins and needles, burning or numbness
  mild itching, pins and needles, burning or numbness
  moderate itching, pins and needles, burning or numbness
 intermittent nausea with dry heaves  moderately severe hallucinations
  severe hallucinations
  extremely severe hallucinations
 constant nausea, frequent dry heaves and  continuous hallucinations vomiting
Tremor Auditory Disturbances
Arms extended and fingers spread apart. Ask “Are you more aware of sounds around you? Are they harsh? Do they frighten you? Are you
Observation: hearing anything that is disturbing to you? Are you hearing things you know are not there?”
 no tremor Observation:
 not visible, but can be felt fingertip to fingertip  not present
  very mild harshness or ability to frighten
  mild harshness or ability to frighten
 moderate, with patient’s arms extended  moderate harshness or ability to frighten
  moderately severe hallucinations
  severe hallucinations
 severe, even with arms not extended  extremely severe hallucinations
 continuous hallucinations
Paroxysmal Sweats Visual Disturbances
Observation: Ask “Does the light appear to be too bright? Is its color different? Does it hurt your eyes? Are you
 no sweat visible seeing anything that is disturbing to you? Are you seeing things you know are not there?”
 barely perceptible sweating, palms moist Observation:
  not present
  very mild sensitivity
 beads of sweat obvious on forehead  mild sensitivity
  moderate sensitivity
  moderately severe hallucinations
 drenching sweats  severe hallucinations
 extremely severe hallucinations
 continuous hallucinations
Anxiety Headache, Fullness in Head
Ask “Do you feel nervous?” Ask “Does your head feel different? Does it feel like there is a band around your head?”
Observation: Observation:
 no anxiety, at ease  not present
 mild anxious  very mild
  mild
  moderate
 moderately anxious, or guarded, so anxiety is  moderately severe inferred  severe
  very severe
  extremely severe
 equivalent to acute panic states as seen in severe delirium or acute schizophrenic reactions
Agitation Orientation and Clouding of Sensorium
Observation: Ask “What day is this? Where are you? Who am I?”
 normal activity Observation:
 somewhat more than normal activity  oriented and can do serial additions
  cannot do serial additions or is uncertain about date
  disoriented for date by no more than  calendar days
 moderately fidgety and restless  disoriented for date by more than  calendar days
  disoriented for place or person

 paces back and forth during most of the interview, or constantly thrashes about
*Total score ranges from  to . A score <8 represents mild withdrawal, no medication necessary; a score of  to  indicates moderate withdrawal, dose medication every  h; and a score >15 indicates severe withdrawal, dose medication every hour.
Drug Therapy for Uncomplicated Alcohol Withdrawal
For patients meeting criteria for uncomplicated alcohol withdrawal without seizures, or delirium, the recommended first­line treatment is a
22­24,28 benzodiazepine (Table 185­2). Because no specific benzodiazepine is more effective than the others, physician choice, institutional availability, cost, and patient factors are taken into consideration.
Drug Therapy for Alcohol Withdrawal Seizures
,34
Benzodiazepines are effective in protecting against seizures and reducing recurrent seizures in alcohol withdrawal. The recommended dose is
 lorazepam  milligrams IV. Phenytoin is not recommended for prevention of further alcohol­related seizures, and loading of phenytoin may, in fact,
 lower the seizure threshold.
Drug Therapy for Alcohol Withdrawal Delirium
Alcohol withdrawal delirium is treated with sedative­hypnotics in high enough doses to quickly control agitation, minimize adverse events, and achieve
,28 light somnolence with arousal when stimulated. A benzodiazepine is the initial treatment of choice (Table 185­2). An approach using escalating
 doses, doubled each time until light somnolence, is recommended. After that, patients can be placed on maintenance therapy with periodic boluses or continuous infusions.
Some patients may have continued symptoms unresponsive to adequate doses of benzodiazepines. The amount of benzodiazepine administered after which the patient is considered refractory is not well defined; failure to achieve an adequate response with  to 100 milligrams of diazepam or  to  milligrams of lorazepam administered in the first hour suggests that additional agents, such as phenobarbital, propofol, or dexmedetomidine,
37­42 will be required. The use of phenobarbital or propofol typically requires intubation. Adverse effects of propofol include hypotension, and prolonged use >48 hours at a dose of >5 milligrams/kg per hour can cause propofol infusion syndrome, with dysrhythmias, heart failure,
,40 hyperkalemia, lipemia, metabolic acidosis, and rhabdomyolysis.
Patients with delirium require thorough diagnostic assessment, aggressive treatment of co­occurring illnesses, supportive care, prevention of aspiration, and treatment of hyperthermia, dehydration, hypoglycemia, and electrolyte imbalance. Thiamine 100 milligrams daily and folate  milligram daily should be considered. Use magnesium sulfate only if hypomagnesemia is present; benefit from magnesium therapy in the absence of
 hypomagnesemia is not established. Physical restraints may be temporarily needed until chemical restraint is achieved; a quiet, calm, supportive
22­24 environment with low stimuli contributes to successful management.
Drug Therapy for Alcohol­Induced Psychotic Disorder
Antipsychotic therapy with alcohol abstinence is the recommended treatment. Because patients with active alcohol­induced psychotic disorder are at
 risk for suicide, mental health assessment is recommended.
DISPOSITION
Patients with mild or moderate uncomplicated alcohol withdrawal that responds well to initial ED treatment, without trauma or major medical comorbidities, with no suicidal or homicidal ideation, and without a seizure disorder can be managed successfully in a detoxification unit or discharged to a supportive family with referral to an outpatient program. Indications for admission include advanced age, mild or moderate withdrawal that does not respond well to ED treatment, the presence of active medical comorbidities, a prior history of delirium tremens, and alcohol withdrawal seizures. Consider intensive care unit admission for moderate withdrawal with comorbid conditions or severe withdrawal in which sedative requirements necessitate close monitoring to monitor respiratory status.
ISOPROPANOL
INTRODUCTION
Isopropanol (CH CHOCH , molecular weight .10), also known as isopropyl alcohol and 2­propanol, is a colorless, volatile liquid with a bitter,
  burning taste and an aromatic odor. It is found in many common, inexpensive household products, such as rubbing alcohol (usually 70% isopropanol). Isopropanol is widely used in industry as a solvent and disinfectant and is a component of a variety of skin and hair products, jewelry cleaners, detergents, paint thinners, and deicers.
,45
Poisoning usually results from ingestion, but may also occur after inhalation or dermal exposure in poorly ventilated areas or during alcohol sponge bathing. Isopropanol is approximately twice as potent as ethanol in causing CNS depression, and its duration of action is two to four times that of ethanol. As a result, it is often used as a substitute intoxicant by alcoholics as well as in suicide attempts.
PATHOPHYSIOLOGY
Isopropanol is rapidly absorbed from the GI tract. Its peak blood levels occur  to 120 minutes after ingestion, and its volume of distribution is similar to that of ethanol. The major pathway for the metabolism of isopropanol is in the liver by alcohol dehydrogenase (50% to 80%), with the remainder excreted unchanged in the urine. Isopropanol is metabolized to a ketone, not an acid (Figure 185­4).
FIGURE 185­4. +
Metabolism of isopropanol. NAD = oxidized form of nicotinamide adenine dinucleotide; NADH = reduced form of nicotinamide adenine dinucleotide.
,44
Ketosis and an osmolar gap without acidosis are the hallmarks of isopropanol toxicity. The principal metabolite, acetone, does not cause eye, kidney, cardiac, or metabolic toxicity, although high levels of acetone may contribute to CNS depression. Acetone is excreted primarily by the kidneys, with some excretion through the lungs. It takes about  to  minutes after isopropanol ingestion for acetone to appear in the serum and
 about  hours for it to be detectable in the urine.
Isopropanol metabolism most closely follows concentration­dependent (first­order) kinetics. The elimination half­life of isopropanol in the absence of
 ethanol is  to  hours, whereas the elimination half­life of acetone is  to  hours. The long half­life of acetone may contribute to the prolonged mental status depression often associated with isopropanol poisoning. The toxic dose of 70% isopropanol is approximately  mL/kg, although as little as .5 mL/kg may cause symptoms. The minimum lethal dose for an adult has been reported as approximately  to  mL/kg, but survival has been reported following ingestions of up to  L. Children are especially susceptible to toxic effects and may develop symptoms after as little as
 three swallows of 70% isopropanol.
CLINICAL FEATURES
The primary clinical toxicities of isopropanol are CNS depression caused by both the parent compound and acetone, and gastric
,44 irritation from isopropanol itself. Onset of symptoms occurs within  to  minutes after ingestion, with peak effects in a few hours and duration of symptoms for many hours longer, possibly due to the contribution of acetone. As with the metabolism of any alcohol by alcohol
+ dehydrogenase, the increased NADH/NAD ratio may produce hypoglycemia.
Gastric irritation appears early and is a striking feature of isopropanol ingestions. GI symptoms range from nausea, vomiting, abdominal pain, and acute pancreatitis to hemorrhagic gastritis and upper GI bleeding. Severe poisoning is marked by early onset of coma, respiratory depression, and hypotension; rhabdomyolysis and renal failure have also been reported.
Massive ingestion may cause hypotension secondary to peripheral vasodilation. In infants and small children, if isopropanol is used to clean the skin, chemical burns can result and systemic symptoms can occur from dermal absorption.
DIAGNOSIS
Obtain point­of­care glucose testing and other testing as directed by the history and physical examination. Assess for upper and lower GI bleeding.
Suspect isopropanol poisoning if the fruity odor of acetone or the smell of rubbing alcohol is present on the breath. Other signs are elevated osmolar gap, ketonuria, and ketonemia without acidosis. An increased anion gap or metabolic acidosis is not due to isopropanol intoxication, so if either is present, investigate for another cause. A spurious increase in serum creatinine level as a result of acetone’s interference with the colorimetric
 creatinine assay is sometimes seen.
Serum isopropanol and acetone levels may be assessed, although isopropanol levels may not be readily available from hospital laboratories.
Isopropanol levels of  milligrams/dL (8 mmol/L) are often associated with intoxication in individuals who are not habituated to ethanol, but alcoholic patients may be considerably more resistant to the CNS effects of isopropanol.
TREATMENT
Treatment is supportive. Do not administer activated charcoal or perform gastric lavage unless indicated by recent co­ingestion of an additional toxic substance. Do not administer fomepizole or ethanol, because the metabolite (acetone) is no more toxic than isopropanol itself, and preventing isopropanol metabolism may prolong CNS toxicity.
Monitor for respiratory depression, and intubate and ventilate as needed. Hypotension usually responds to IV fluids. Obtain blood for type and crossmatch if needed to treat GI bleeding. Hemodialysis eliminates both isopropanol and acetone. Consider hemodialysis if hypotension is refractory to
,44 conventional therapy or when the isopropanol level is >400 milligrams/dL (>66 mmol/L).
DISPOSITION AND FOLLOW­UP
Patients with lethargy or prolonged CNS depression should be admitted to the hospital. Those who remain asymptomatic for  to  hours after ingestion may be discharged with referral for substance abuse counseling or mental health evaluation as indicated.
METHANOL AND ETHYLENE GLYCOL
INTRODUCTION
Methanol and ethylene glycol are similar in that the parent compounds possess minor toxicity (both causing inebriation and some direct gastric irritation), but the major toxicity occurs when the liver metabolizes these compounds to substances that cause metabolic acidosis and end­organ
,50­52 damage (Table 185­4). Treatment is primarily directed toward halting the formation of these toxic metabolites.
TABLE 185­4
Features of Methanol and Ethylene Glycol Toxicity and Treatment
Methanol Ethylene Glycol
Sources Windshield cleaners, gas line antifreeze, solvents, solid fuel Glycerin substitute, hydraulic fluid, antifreeze, adulterated alcoholic for stoves, adulterated alcoholic beverages, moonshine beverages, adulterated toothpaste (diethylene glycol)
Absorption 30–60 min 1–4 h
Metabolism Decreases .5 milligrams/dL per hour (2.7 mmol/L per hour) Elimination half­life ≈ 3–8 h
(untreated)
Minimum lethal  gram/kg or about 100 mL in an adult .1–1.7 grams/kg or about 100 mL in an adult dose without treatment
Metabolism Methanol → formaldehyde → formic acid Ethylene glycol → glycoaldehyde → glycolic acid → glyoxylic acid → oxalic acid
Toxic effects Formic acid blocks oxidative phosphorylation; metabolic Metabolic acidosis and tissue toxicity from glycolic acid and calcium acidosis from formic and lactic acids oxalate crystals
Clinical features Inebriation from parent compound, then 12–14 h later: Inebriation from parent compound, then 4–12 h later: CNS effects, metabolic acidosis; blurred or snow field vision; nausea, hypocalcemia, metabolic acidosis; 12–24 h: multisystem organ failure; vomiting, abdominal pain 24–72 h: renal failure
Diagnosis Methanol level >20 milligrams/dL (>6 mmol/L) Ethylene glycol level >20 milligrams/dL (>3.2 mmol/L)
Early: unexplained osmolal gap >10 mOsm/kg H O Early: unexplained osmolal gap >10 mOsm/kg H O

Later: elevated anion gap metabolic acidosis Later: elevated anion gap metabolic acidosis and calcium oxalate crystals in urine
Treatment Fomepizole  milligrams/kg IV over  min and then  Fomepizole  milligrams/kg IV over  min and then  milligrams/kg milligrams/kg IV over  min every  h IV over  min every  h or or
Ethanol  mL/kg of 10% IV ethanol at 100 milligrams/kg per Ethanol  mL/kg of 10% IV ethanol at 100 milligrams/kg per hour to hour to keep ethanol level 100–150 milligrams/dL (22–33 keep ethanol level 100–150 milligrams/dL (22–33 mmol/L) mmol/L)
Folinic or folic acid  milligram/kg IV every 4–6 h (up to  Pyridoxine 50–100 milligrams IV every  h for 24–48 h milligrams per dose), continue until toxicity resolved Thiamine 100 milligrams IV every  h for 24–48 h
Magnesium sulfate  grams IV (once)
IV sodium bicarbonate to maintain serum pH >7.30 IV sodium bicarbonate to maintain serum pH >7.20
See text for indications for hemodialysis See text for indications for hemodialysis
Methanol, the simplest alcohol (CH OH, molecular weight .05), is a colorless, volatile liquid with a distinctive “alcohol” odor. Methanol is used in the
 synthesis of other chemicals and may be found in automotive windshield cleaning solution, solid fuel for stoves and chafing dishes, model airplane fuel, carburetor cleaner, gas line antifreeze, photocopying fluid, and solvents.
Most cases of methanol poisoning occur by ingestion, and most contemporary exposures in the United States occur from unintentional ingestion of
 windshield washer fluid and other automotive cleaning products. Worldwide, there are outbreaks of poisoning from contaminated alcoholic
,55 beverages. Persons who wish to consume ethanol but have no access to it for financial or other reasons may consume methanol as an alternative, either intentionally or unintentionally (due to improper or confusing labeling containing the word alcohol). Methanol may be systemically absorbed after inhalation or dermal exposure, but this rarely causes significant clinical toxicity. Hence, extensive evaluation or observation is not required after minor skin or inhalational exposures.
Ethylene glycol [CH CH (OH) , molecular weight .07] is a colorless, odorless, sweet­tasting liquid. Ethylene glycol has many contemporary uses as a
   glycerin substitute, preservative, component of hydraulic brake fluid, foam stabilizer, component for chemical synthesis, and most commonly an automotive coolant (antifreeze).

Virtually all ethylene glycol toxicity results from ingestion, because the chemical has a low vapor pressure and does not penetrate skin well. Its sweet taste renders ethylene glycol an attractive ingestant for children and pets. Other common exposure scenarios include ingestion as an ethanol
 substitute when ethanol is unavailable and intentional suicidal ingestions.
PATHOPHYSIOLOGY
METHANOL
Methanol is rapidly absorbed and metabolized in the liver by alcohol dehydrogenase to formaldehyde, and then by aldehyde dehydrogenase to formic
 acid (Figure 185­5). First­order kinetics is present at very low methanol concentrations, with an elimination half­life of .8 to .0 hours. At higher methanol concentrations, metabolism switches to zero­order kinetics, and blood methanol level decreases at a fixed rate, roughly .5 milligrams/dL
 per hour (2.7 mmol/L per hour).
FIGURE 185­5. +
Metabolism of methanol. NAD = oxidized form of nicotinamide adenine dinucleotide; NADH = reduced form of nicotinamide adenine dinucleotide.
Formic acid is the metabolite responsible for the toxicity and metabolic acidosis that occur with methanol poisoning. Acidosis correlates well with formic acid levels both in its magnitude and in the timing of its development. Formic acid’s main mechanism of toxicity is its binding to cytochrome oxidase and blockade of oxidative phosphorylation. This leads to anaerobic metabolism and development of lactic acidosis. In
+ addition, metabolism of methanol increases the NADH/NAD ratio, which favors the conversion of pyruvate to lactate and thereby worsens lactic acidosis. Early in the course of methanol poisoning, more of the acidosis is due to formic acid itself, whereas later on, as cellular aerobic respiration is
 blocked and more lactate builds up, the contribution of lactate becomes more significant.
Formic acid’s inhibition of cytochrome oxidase increases with decreasing pH, so acidemia worsens the blockade of aerobic metabolism. Falling pH also favors the undissociated form of formic acid (as opposed to formate ion), which moves more readily across tissue barriers. Therefore, at lower pH, more formic acid can enter the brain and ocular tissues, worsening CNS depression as well as causing retinal and optic nerve injury. Lower pH may also
 prolong formic acid elimination by increasing tubular reabsorption.
ETHYLENE GLYCOL
Like methanol, ethylene glycol itself has minor toxicity (it is a stronger inebriant than both methanol and ethanol and causes gastric irritation), but it is the hepatic oxidation of ethylene glycol that creates the toxic metabolites responsible for metabolic acidosis and end­organ damage. The liver metabolizes about 80% of an ingested dose, whereas the other 20% is excreted unchanged in the urine. When metabolism is unblocked, ethylene glycol has first­order metabolic kinetics with an elimination half­life of roughly  to  hours.
Like the other alcohols, ethylene glycol is metabolized sequentially by alcohol dehydrogenase to glycoaldehyde, followed by metabolism with aldehyde dehydrogenase to glycolic acid (Figure 185­6). The subsequent conversion of glycolic acid to glyoxylic acid is the rate­limiting step for the elimination of ethylene glycol. Glycolic acid is the toxic metabolite, and its buildup is responsible for most of the metabolic acidosis. Once glycolic acid is converted to glyoxylic acid, it can be metabolized by one of several pathways. The major pathway is the conversion of glyoxylic acid to oxalic acid. Oxalic acid can
 complex with calcium, which leads to hypocalcemia and precipitation of calcium oxalate crystals in tissues and urine. End­organ damage from ethylene glycol poisoning is thought to be due to direct cytotoxicity of glycolic acid (although the exact mechanism of this is
,62 unclear) and tissue damage from precipitation of calcium oxalate crystals.
FIGURE 185­6. +
Metabolism of ethylene glycol. NAD = oxidized form of nicotinamide adenine dinucleotide; NADH = reduced form of nicotinamide adenine dinucleotide.
CLINICAL FEATURES
METHANOL
,52
Methanol poisoning is characterized by CNS depression, metabolic acidosis, and visual changes. However, multiple other organ
,64 systems are also affected. Coma, seizure, and severe metabolic acidosis on presentation predict a poor outcome in methanol poisoning. Severity of poisoning correlates more with the level of acidosis than with the methanol level.
Clinical signs and symptoms may be significantly delayed after exposure, often by  to  hours, because metabolism to formic acid is required for tissue damage. Because ethanol competes for alcohol dehydrogenase, formation of the toxic metabolites from methanol will be delayed if ethanol has also been ingested.
Methanol is only a mild inebriant, and patients with tolerance to ethanol also demonstrate tolerance to methanol’s intoxicating effects. Neurologic symptoms seen with methanol toxicity include headache, vertigo, dizziness, and seizures. Retinal and optic nerve tissue seems to be especially sensitive to the toxic effects of formic acid. Ocular toxicity may present as photophobia or blurred or “snow field” vision, with clinical
 findings including papilledema, nystagmus (rare), and nonreactive mydriasis once permanent damage has occurred.
Head CT may demonstrate bilateral putamen necrosis, subcortical white matter damage, intracranial hemorrhage, and other patterns of brain injury
66­68 from methanol poisoning. Obtain a noncontrast head CT before administering anticoagulants. Delayed parkinsonism and polyneuropathies
 can occur.
Cardiovascular toxicity includes tachycardia and hypotension, which may progress to shock. Initially, patients often demonstrate tachypnea and shortness of breath while attempting to compensate for the metabolic acidosis, but over time, this may progress to respiratory failure.
Methanol is irritating to the GI tract and may cause abdominal pain, anorexia, nausea, vomiting, pancreatitis, or gastritis. Transaminitis is usually mild
 and transient. Rhabdomyolysis, renal failure, coma, and shock can occur in severe cases.
ETHYLENE GLYCOL
,52
Ethylene glycol poisoning is characterized by CNS depression, metabolic acidosis, and renal failure. However, multiple other organ systems may be affected. Clinical poisoning has historically been divided into three stages, although timing may vary and stages may overlap.
The first or “neurologic” stage typically begins  minutes to  hours after ingestion due to the intoxicating effects of the ethylene glycol parent compound and may range from mild depression to seizure and coma. Patients with tolerance to the depressant effects of ethanol may also exhibit relative tolerance to the inebriating effects of ethylene glycol. Patients are often described as appearing intoxicated (with ataxia, confusion, and slurred speech) but without an ethanol odor on the breath. Ethylene glycol is directly irritating to the GI tract, so abdominal pain, nausea, and vomiting may be present.
The generation of toxic metabolites generally takes  to  hours, or more if ethanol was co­ingested. CNS tissue effects of glycolic acid and calcium
 oxalate crystals include cerebral edema, basal ganglia hemorrhagic infarction, and meningoencephalitis. Hypocalcemia, which occurs when calcium combines with oxalate, may contribute to seizures. Metabolic acidosis appears as toxic metabolites are generated.
The second or “cardiopulmonary” stage begins  to  hours after ingestion and is characterized by tachycardia and possibly hypertension. Tachypnea compensates for metabolic acidosis. Glycolate and oxalate crystal deposition in tissues leads to multiorgan system failure, including heart failure, acute lung injury, and myositis. Hypocalcemia, if present during any stage, may cause prolongation of the QT interval, myocardial depression, and dysrhythmias. Most deaths occur during this stage.
The third or “renal” stage is often delayed  to  hours after ingestion and is characterized by renal failure due to calcium oxalate crystal deposition in the proximal tubules, the most common major complication of serious ethylene glycol poisoning. Short­term hemodialysis is often required, and it may take weeks to months for the kidneys to recover. Delayed neuropathies may occur  to  days after ethylene glycol
,71,72 poisoning.
DIAGNOSIS OF METHANOL OR ETHYLENE GLYCOL POISONING
Laboratory tests for a patient with suspected methanol or ethylene glycol poisoning should include blood ethanol levels, arterial blood gas analysis, chemistry panel, calculation of anion and osmolar gaps, serum osmolarity, and creatine kinase level. Serum ketone, β­hydroxybutyrate (if available), and lactate levels are helpful if a metabolic acidosis or an osmolar gap is present. Falsely elevated lactate results have been seen with some point­of­
 care analyzers in patients with severe ethylene glycol poisoning. Check point­of­care glucose level. Measure serum acetaminophen and salicylate levels in patients with an intentional overdose. Consider methanol or ethylene glycol poisoning in a patient with an unexplained acidosis
(see Chapter , “Acid­Base Disorders”).
Acidosis will not be present immediately after exposure. The parent compounds must be converted to toxic metabolites before the acidosis develops; this may be delayed by hours to over a day, especially if ethanol is co­ingested.
METHANOL AND ETHYLENE GLYCOL LEVELS
The best laboratory test for diagnosing methanol or ethylene glycol poisoning is measurement of the specific serum level of the
 alcohol.
Asymptomatic individuals following methanol ingestion usually have levels of <20 milligrams/dL (<6 mmol/L), and CNS symptoms may appear as levels rise above that. Ocular problems are associated with methanol levels of >50 milligrams/dL (>16 mmol/L), and the risk of fatality rises with levels >150 to
200 milligrams/dL (>47 to  mmol/L). However, toxicity associated with a given level depends greatly on how long after ingestion the level was measured. A level of  milligrams/dL (16 mmol/L) obtained  hours after ingestion implies a much smaller ingestion and less toxicity than if the same
 value was obtained  hours after ingestion.
Asymptomatic individuals following ethylene glycol ingestion usually have peak levels <20 milligrams/dL (<3.2 mmol/L). As with methanol, toxicity associated with a given level depends greatly on how long after ingestion the level was measured. More useful are factors indicating metabolic dysfunction such as acidosis.
OSMOLAR GAP
In many hospital and clinical laboratories, methanol and ethylene glycol levels are not available in a timely manner to assist with initial medical
 decision making. In such circumstances, the osmolar gap may be used as a surrogate marker for toxic alcohol levels (Table 185­5). This calculation determines the difference between the measured serum osmoles and the calculated osmoles. Methanol and ethylene glycol, but not their metabolites, are osmotically active and will contribute to the measured serum osmolarity.
TABLE 185­5
Substances That Contribute to the Osmolar Gap
Substance Molecular Weight mOsm/kg H  O With a Serum Concentration of 100 milligrams/dL Conversion Factor
Ethanol   .6
Isopropanol   .0
Methanol   .2
Ethylene glycol   .2
Notes: Calculated serum osmolarity =  × sodium + (BUN/2.8) + (glucose/18) + (ethanol/4.6) + (isopropanol/6.0) + (methanol/3.2) + (ethylene glycol/6.2)
Osmolar gap = measured serum osmolarity – calculated serum osmolarity
For accurate calculation of the osmolar gap, obtain simultaneous blood samples for a basic serum chemistry panel (including BUN, glucose, and sodium levels), measurement of ethanol level, and measurement of serum osmolarity. Using a previously obtained specimen to measure serum osmolarity (“add­on” tests) is not acceptable, because any toxic alcohols present may have volatilized since the sample was obtained. In addition, the freezing point depression method must be used to measure serum osmolarity, rather than the vapor pressure method, which can miss volatile substances such as toxic alcohols. There is considerable variation in baseline osmolar gap in healthy subjects depending on the
 formula used for calculation, so the reference range may differ among clinical laboratories. In general, an osmolar gap of more than  to  mOsm/kg H O raises concern and >50 mOsm/kg H O is highly suggestive of either methanol or ethylene glycol poisoning and is associated with

 increased mortality.
The osmolar gap is highest when the parent toxic alcohol level is at its peak (roughly  to  minutes after ingestion), before significant metabolism has occurred (Figure 185­7). As the time since ingestion increases and the parent compound is metabolized, the osmolar gap will decrease. Hence, later­presenting patients may not have significant osmolar gaps. As metabolism occurs, acid metabolites build up and an anion gap metabolic acidosis
 develops as the osmolar gap narrows. There may be a time period in the middle range when the patient has both an osmolar gap and an anion gap.
FIGURE 185­7. Relative changes in anion and osmolar gaps over time from ingestion of a toxic alcohol.
Although the osmolar gap may be helpful in conjunction with the rest of the clinical picture, it has many shortcomings and cannot be relied on to
,79,80 definitively diagnose or exclude a toxic alcohol poisoning. Other conditions such as ketoacidosis, shock, and sepsis may cause an elevated
 osmolar gap. Also, forgetting to account for ethanol is a common error when calculating the osmolar gap.
As noted, the range of normal variation in osmolar gap is wide and dependent on the formula used for calculation, so a toxic concentration of
79­81 methanol or ethylene glycol may be present with an osmolar gap in the normal range. For example,  milligram/dL (0.3 mmol/L) of methanol will
 raise serum osmolarity by .34 mOsm/kg H O. Therefore, a methanol concentration of  milligrams/dL (15 mmol/L)—generally accepted to be toxic

—will raise serum osmolarity  mOsm/kg H O. If a given patient’s baseline was low to begin with, this methanol concentration would not create an
 abnormal osmolar gap.
ANION GAP
The positively charged cations in the serum are electrically balanced by the negatively charged anions. In the clinical laboratory, not all cations and anions are routinely measured, and the level of measured cations is usually greater than that of measured anions; the difference is termed unmeasured anions. The predominant serum cation measured is sodium, which is almost completely balanced by the measured charged chloride and bicarbonate anions; the difference is termed the anion gap, consisting mostly of serum proteins, phosphate, sulfate, organic acids, and conjugate bases of ketoacids (see Chapter , “Acid­Base Disorders”).
+ – –
Anion gap = Na – (Cl + HCO )

The normal anion gap varies according to the methodology used, and the physician should use the values established by the clinical laboratory. In most clinical settings, an anion gap >15 mEq/L should be considered abnormal. As noted, it takes time for the acidotic metabolites to become present, as much as  to  hours following methanol ingestion, so a normal anion gap does not exclude the diagnosis.
URINARY FLUORESCENCE
Urinary fluorescence under an ultraviolet or Wood’s lamp has been anecdotally taught to be a helpful sign of ethylene glycol poisoning because most antifreeze products contain sodium fluorescein as an additive to aid in the detection of radiator leaks. Not all ethylene glycol products contain fluorescein; the fluorescence may be short­lived (lasting about  hours after ingestion); and the ability of the physician to detect fluorescence is
 affected by many technical factors. Thus, the absence of urinary fluorescence cannot exclude an ethylene glycol ingestion. In addition, false­positive results occur, because many types of glass or plastic containers fluoresce on their own, and numerous foods, medications, toxins, and endogenous
,84 substances may cause urinary fluorescence.
CALCIUM OXALATE CRYSTALS FOR ETHYLENE GLYCOL

Approximately half of patients poisoned with ethylene glycol demonstrate either monohydrate or dihydrate calcium oxalate crystals on urinalysis.
These are often misread as hippurate crystals. If present, they start to appear  to  hours after ingestion and may persist for days, especially in patients with renal failure. The monohydrate form is more common, and the dihydrate form is more specific for ethylene glycol poisoning.
TREATMENT
The basic principles of treatment for both methanol and ethylene glycol poisoning are performing initial resuscitation, providing cardiopulmonary
 support, correcting acidosis, preventing formation of toxic metabolites, and enhancing the clearance of the parent compound and toxic metabolites.
Because toxic alcohols are absorbed so rapidly, gastric decontamination is unlikely to be of benefit, and there is no evidence to support its routine
,86,87 use. Activated charcoal may be used if there is a recent co­ingestant known to adsorb to charcoal.
CORRECT ACIDOSIS
Correcting acidosis may improve the outcome in patients poisoned with methanol because acidosis worsens the toxicity of formate; rapid improvement in visual and other systemic symptoms has been reported with correction of acidosis. In addition, alkalinization may help increase formic
 acid clearance by decreasing reabsorption in the proximal renal tubules. However, the benefits of alkalinization may be equivocal if the patient is treated with metabolic blockade and hemodialysis. When used in methanol poisoning, give IV sodium bicarbonate infusions to maintain a serum pH of

>7.30. There is no evidence that alkalinization is specifically beneficial in ethylene glycol poisoning, but it seems reasonable to use sodium bicarbonate IV if there is a severe metabolic acidosis with pH <7.20. METABOLIC BLOCKADE
Because laboratory confirmation may take time and because prompt treatment is important to prevent the formation of toxic metabolites, the decision
 to block metabolism often must be made before the diagnosis is secure (Table 185­6). Start treatment while sorting out the clinical picture to protect the patient from serious toxicity, such as blindness or renal failure. Treatment with either ethanol or fomepizole greatly slows the elimination of methanol and ethylene glycol. Because hepatic oxidation is inhibited, elimination is determined by first­order renal excretion, and the elimination half­life averages  hours (range,  to  hours) for methanol (compared to an elimination half­life without metabolic blockade of .8 to  hours) and
,87,89,90
 to  hours for ethylene glycol (compared to an elimination half­life without metabolic blockade of  to  hours).
TABLE 185­6
Indications for Metabolic Blockade With Fomepizole or Ethanol
Elevated plasma levels: methanol >20 milligrams/dL (>6 mmol/L) or ethylene glycol >20 milligrams/dL (>3 mmol/L)
If methanol or ethylene glycol level not available:
Documented or suspected significant methanol or ethylene glycol ingestion with ethanol level lower than approximately 100 milligrams/dL (22 mmol/L)* Coma or altered mental status in patient with unclear history and:
Unexplained serum osmolar gap of >10 mOsm/L or
Unexplained metabolic acidosis and ethanol level of <100 milligrams/dL (<22 mmol/L)* *If serum ethanol level is >100 milligrams/dL (>22 mmol/L), the patient will be protected from the formation of toxic metabolites by co­ingestion of ethanol, and specific metabolic blockade treatment can be delayed until toxic alcohol level is available. If the ethanol level is likely to fall to <100 milligrams/dL before the toxic alcohol results are back, then initiate metabolic blockade.
The initial step in the metabolism of methanol (Figure 185­5) or ethylene glycol (Figure 185­6) is performed by alcohol dehydrogenase. This enzyme is
 competitively inhibited by either ethanol or fomepizole (4­methyl­1H­pyrazole). Both ethanol and fomepizole have a much higher affinity for alcohol dehydrogenase than does methanol or ethylene glycol. Although ethanol was traditionally administered for metabolic blockade in methanol and ethylene glycol poisonings, fomepizole has supplanted ethanol for this purpose in many institutions.
Metabolic Blockade With Fomepizole
91­93
The primary advantage of fomepizole is the lack of side effects such as CNS depression, GI irritation, and hypoglycemia caused by ethanol therapy.

Fomepizole is less susceptible to dosing errors than ethanol. The primary limiting factor to fomepizole use is the increased cost of the drug relative to ethanol, which may reduce availability in resource­poor locations.
Fomepizole is continued until the toxic alcohol level is <20 milligrams/dL (methanol <6 mmol/L or ethylene glycol <3 mmol/L) and the metabolic acidosis has resolved. Fomepizole is believed to induce its own metabolism, so it is recommended that the dose be increased to  milligrams/kg every
,95
 hours if treatment lasts >48 hours. More frequent dosing (every  hours) is required during hemodialysis because fomepizole is removed during this procedure. Fomepizole does not require frequent monitoring of serum levels or dosage adjustments necessary with ethanol treatment.

Adverse effects from fomepizole are rare; mild and transient nausea, headache, dizziness, and injection site irritation are most commonly reported.
The safety of fomepizole in pregnancy is unknown, so the risks and benefits to fetus and mother of fomepizole therapy should be weighed against
 those of the alternative treatments. Reports show good efficacy of fomepizole therapy in children.
Metabolic Blockade With Ethanol
If fomepizole is not available or its use is contraindicated (e.g., the patient has a known allergy), ethanol may be used to inhibit toxic alcohol
 metabolism, administered PO or IV. Although ethanol may prevent toxic alcohol metabolism at blood levels as low as  milligrams/dL (7 mmol/L),
 the general recommendation is to maintain a target ethanol level of 100 to 150 milligrams/dL (22 to  mmol/L). Extremely elevated toxic alcohol levels may reduce the effectiveness of alcohol dehydrogenase inhibition by ethanol, and ethanol levels of >150 milligrams/dL (>33 mmol/L) may be required to effectively block production of the toxic metabolites. Achieving the desired ethanol level may be difficult because individual response to ethanol administration varies considerably depending on baseline ethanol consumption.
While the loading dose of ethanol produces reasonably predictable blood levels, maintenance dosing varies depending on the patient’s baseline ethanol use. If IV ethanol is not available, an oral ethanol protocol can be used with a loading dose (PO or via nasogastric tube) using 80­proof liquor of
### .5 to  mL/kg followed by maintenance dosing of .2 to .5 mL/kg per hour. Do not use oral ethanol preparations via the IV route. For both the
IV and PO routes, serum ethanol concentrations should be monitored every  to  hours. All maintenance doses need to be doubled for patients undergoing hemodialysis.
With severe adult poisoning and when fomepizole therapy may be delayed or transport time to the hospital may be long, administration of three or
 four 1­oz (30­mL) “shots” of 80­proof liquor should raise blood ethanol concentrations sufficiently to block toxic alcohol metabolism in a 70­kg adult.
Maintenance dosages are approximately one to two shots per hour.
Ethanol treatment is continued until the toxic alcohol level is <20 milligrams/dL (methanol <6 mmol/L or ethylene glycol <3 mmol/L) and the metabolic acidosis has resolved. The disadvantage of using ethanol is the induction of a state of inebriation, so patients require close monitoring for neurologic and respiratory depression. Individual metabolic variations make dosing complicated, and frequent serum level monitoring and dosage adjustments are required. Children and malnourished individuals are particularly at risk for the development of hypoglycemia, although with careful monitoring,
 this complication is rare. Administration of the 10% ethanol solution IV requires central venous access because it is hyperosmolar and irritating to peripheral veins. Use of less concentrated solutions, such as 5% IV ethanol solutions, may require administration of large fluid volumes.
Hemodialysis
Hemodialysis can rapidly clear the toxic alcohols and metabolites, as well as correct acid­base disorders, thereby shortening the duration of metabolic
,87,98­100 blockade treatment. Conversely, with fomepizole, patients can receive prolonged treatment with few side effects and without the need for
101 hemodialysis and attendant risks.
Hemodialysis may be required emergently for patients with severe acidosis, visual changes, hemodynamic instability, or renal failure (Table 185­
7). ,87,102,103 A serum level of ≥50 milligrams/dL (methanol ≥15 mmol/L or ethylene glycol ≥7.5 mmol/L) is considered an indication for hemodialysis, but this criterion has been questioned because many patients with high methanol or ethylene glycol levels have been effectively treated without
101,104­106 hemodialysis. Consider the entire clinical picture, rather than making a decision based only on a serum level. Some rebound in toxic alcohol levels may occur after hemodialysis is stopped, so metabolic blockade therapy should be continued for several hours after cessation of dialysis, with
,87 blood level rechecked to ensure that the toxic alcohol level remains low.
TABLE 185­7
Indications for Hemodialysis After Methanol or Ethylene Glycol Ingestion
Refractory metabolic acidosis: pH <7.25 with anion gap >30 mEq/L and/or base deficit <–15
Visual abnormalities* Renal insufficiency
Deteriorating vital signs despite aggressive supportive care
Electrolyte abnormalities refractory to conventional therapy
Serum methanol or ethylene glycol level of >50 milligrams/dL†
*Applies only to methanol; visual abnormalities may not resolve immediately, so their persistence in the absence of other indications once hemodialysis is started is not an indication for continued hemodialysis.
†Although previously considered an indication for hemodialysis, there are reports of patients with levels of ≥50 milligrams/dL (methanol ≥15 mmol/L or ethylene glycol ≥7.5 mmol/L) being successfully treated with fomepizole with or without bicarbonate and no hemodialysis.
Vitamin Therapy
Adjunctive treatment with B vitamins (including folate) is recommended to help clear the toxic metabolites of methanol and ethylene glycol more
107 quickly, although no solid evidence exists to indicate that this treatment is necessary or even helpful.
In methanol poisoning, high doses of folate or folinic acid may facilitate breakdown of formic acid into carbon dioxide and water (Figure 185­5).
Experimental animals with very large folate stores do not develop acidosis and toxicity from methanol poisoning unless they are artificially depleted of folate. Theoretically, increasing folate stores should hasten the detoxification of formate and prevent it from accumulating and causing end­organ damage. Folinic acid, the activated form of folic acid, is preferred, but folic acid may be used if the former is not available. Recommended dosing is 
 milligram/kg (up to  milligrams) IV every  to  hours.
In ethylene glycol poisoning, adjunctive therapy with pyridoxine, thiamine, and magnesium may be used to facilitate metabolism of glyoxylate to nontoxic glycine and α­hydroxy­β­ketoadipoic acid (Figure 185­6). Magnesium can be given as a one­time dose of magnesium sulfate  grams IV. The
108 two B vitamins are given in large doses: thiamine 100 milligrams IV and pyridoxine  to 100 milligrams IV, both every  hours for  days.
109,110
Visual impairment can be a permanent complication of methanol poisoning. Although treatment with fomepizole or ethanol and bicarbonate can
109 prevent ocular toxicity, there is no other proven therapy to restore established visual damage.
DISPOSITION AND FOLLOW­UP
Because of the complex management decisions required with methanol or ethylene glycol poisoning, consultation with a medical toxicologist or a regional poison control center is strongly recommended. Symptoms of methanol or ethylene glycol intoxication may be delayed, particularly if ethanol has been co­ingested. A patient with suspected ethylene glycol ingestion should be observed and monitored for  hours. If no ethanol is present, the patient remains completely asymptomatic, there is no osmolar gap, and no metabolic acidosis develops, the patient can be discharged. Methanol toxicity may be delayed longer, so a patient with suspected methanol ingestion should be observed for  hours using the same criteria.
Patients with significant signs and symptoms should be admitted to an intensive care setting. Patients seen at facilities unable to provide hemodialysis or intensive care should be transferred as soon as possible, if in sufficiently stable condition, to institutions capable of providing such care. Suicidal patients should receive a psychiatric evaluation when their condition improves and prior to discharge.


