## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 190: Acetaminophen
Rachel S. Wightman; Lewis S. Nelson
INTRODUCTION
Acetaminophen (N­acetyl­p­aminophenol or paracetamol) is the most popular over­the­counter analgesic and is one of the most common toxic exposures reported to poison centers. Acetaminophen (sometimes abbreviated APAP) is available as a sole agent or combined with a variety of other medications prepared in different forms, such as tablets, ​capsules, gels, and liquids. Although most serious poisonings involve intentional self­harm, poisonings often occur because of the erroneous belief that this medication is benign or because the victim was unaware that acetaminophen was an
,2 ingredient in the ingested preparation. In the United States, acetaminophen is the most common cause of drug­induced liver failure and accounts
,4 for almost half of all cases of acute liver failure. Acetaminophen–opioid combination products have been implicated in chronic overuse, likely due to
 an increasing opioid requirement leading to concomitantly increasing acetaminophen exposure. In response to these safety concerns, in 2011, the
U.S. Food and Drug Administration limited the prescription acetaminophen–opioid combination preparation strength to 325 milligrams per dosage
 unit and now requires a boxed warning to notify consumers of the potential risk for serious liver toxicity.
PHARMACOLOGY
ORAL ACETAMINOPHEN
The recommended maximum total daily dose is 3900 milligrams in adults using 325­milligram acetaminophen (regular strength) and 3000 milligrams when using the 500­milligram acetaminophen (extra strength) preparation. Adults should not use acetaminophen for more than  consecutive days unless directed by their physician. For children, the recommended acetaminophen dose is  to  milligrams/kg every  to  hours as needed, with a maximum daily dose of  milligrams/kg or five doses in a 24­hour period.
Patients with insufficient glutathione stores (e.g., alcoholics and acquired immunodeficiency syndrome patients) and patients with induced cytochrome P450 (CYP450) enzymatic activity (e.g., alcoholics and those taking concurrent anticonvulsant or antituberculous medications) may be at greater risk for developing acetaminophen­induced hepatotoxicity following overdose (as opposed to therapeutic dosing described earlier). Despite the limited evidence, it may be prudent to reduce acetaminophen dosage and duration of therapy for this population. In contrast, children, because of their greater ability to metabolize acetaminophen through hepatic sulfation, may be at decreased risk for developing hepatotoxicity following a
7­9 moderate overdose.
After ingestion of therapeutic doses, acetaminophen is rapidly absorbed from the GI tract, and peak serum concentrations are usually achieved within
 minutes to  hours. Following an overdose, peak serum concentrations are usually achieved within  hours. Delayed absorption can occur especially after overdose of acetaminophen preparations combined with opioid or antimuscarinic medications, as well as those with altered­release
10­12 kinetics such as extended­release preparations. In therapeutic amounts, acetaminophen has nearly 100% b​ ioavailability, is approximately 20% bound to serum proteins, has a volume of distribution around .85 L/kg, and has an elimination half­life of approximately .5 hours. The therapeutic concentration for the ​antipyretic effect of acetaminophen is between  and  micrograms/mL (66 to 132 micromole/L), but therapeutic concentrations for ​analgesia are not established. Oral acetaminophen appears to be nontoxic when administered following therapeutic dosing guidelines.
IV ACETAMINOPHEN
The recommended dosing of IV acetaminophen for adults or ​children weighing more than  kg is 650 milligrams every  hours or
1000 ​milligrams every  hours, with a maximum total daily dose of  grams. For adults or children weighing less than  kg, the ​­ rDeocwomnlmoaednedde d2 0d2o5si­n7g­1 is  1:22.85 Pm iYlliogurar mIPs /isk g1 e3v6e.1ry4  .h1o5u9r.s1 o2r7  milligrams/kg every  hours (maximum individual dose of 750 milligrams), with a
Chapter 190: Acetaminophen, Rachel S. Wightman; Lewis S. Nelson maximum total daily dose of  milligrams/kg or 3750 milligrams, whichever is less. Peak concentrations following IV administration occur at the end of
. Terms of Use * Privacy Policy * Notice * Accessibility
 the 15­minute infusion period. Compared to a similar dose of oral acetaminophen, IV acetaminophen achieves a 70% greater maximum
 concentration but provides a similar total drug exposure.
ACETAMINOPHEN METABOLISM
Acetaminophen metabolism after therapeutic ingestion is primarily by glucuronidation and sulfation (Figure 190­1).
FIGURE 190­1. Acetaminophen metabolism. A. After ingestion of therapeutic amounts, predominant metabolism is via glucuronidation and sulfation. The small amount of N­acetyl­p­benzoquinoneimine (NAPQI) generated is conjugated with glutathione to a nontoxic compound. B. After ingestion of large amounts, glucuronidation and sulfation are saturated, and an increased amount of NAPQI is generated. Detoxification of NAPQI to a nontoxic compound soon depletes glutathione stores, leaving excess NAPQI to bind to intracellular proteins, causing cell death. APAP = N­acetyl­p­aminophenol
(acetaminophen).
In overdose, normal pathways for acetaminophen metabolism are saturated and a larger proportion is oxidized by the CYP450 system to a reactive metabolite, N­acetyl­p­benzoquioneimine (NAPQI). NAPQI is detoxified by hepatic glutathione to a nontoxic compound that can be renally eliminated.
However, when hepatic stores of glutathione decrease to <30% of normal in the setting of overdose, NAPQI binds to hepatic macromolecules, resulting in a centrilobular hepatic necrosis. Observed hepatocyte damage typically progresses with cell lysis on the second day after an acute toxic exposure, releasing hepatic enzymes (such as transaminases) and NAPQI­hepatic protein adducts into the circulation where they are detectable in the serum.
This corresponds generally to the development of overt clinical toxicity.
CLINICAL FEATURES
FOUR STAGES OF ACETAMINOPHEN TOXICITY
The clinical presentation of human acetaminophen poisoning can be roughly divided into four stages (Table 190­1). During the first  hours after exposure (stage 1), patients may be asymptomatic or have minimal and nonspecific clinical effects of toxicity, such as anorexia, nausea, vomiting, and malaise. By days  to  (stage 2), findings seen in stage  often improve, but clinical signs of hepatotoxicity (including right upper quadrant pain and tenderness) may occur and serum transaminases may be elevated. Even without treatment, most patients with mild to moderate hepatotoxicity recover
,15 without sequelae. However, by days  to  (stage 3), some patients will progress to fulminant hepatic failure. Characteristic stage  findings include metabolic acidosis, coagulopathy, renal failure, encephalopathy, and recurrent GI symptoms. Patients who survive the complications of fulminant hepatic failure begin to recover over the next  weeks (stage 4), with complete resolution of hepatic ​dysfunction in survivors after  to  months.
TABLE 190­1
Clinical Stages of Acute Acetaminophen Toxicity
Stage  Stage  Stage  Stage 
Approximate First  Days 2–3 Days 3–4 After day  timing h
Clinical Anorexia Improvement in anorexia, nausea, and Recurrence of anorexia, nausea, Clinical improvement and manifestations Nausea vomiting and vomiting recovery (7–8 d)
Vomiting Abdominal pain Encephalopathy or
Malaise Hepatic tenderness Anuria Deterioration to multiorgan
Jaundice failure and death
Laboratory Elevated serum transaminases Hepatic failure Improvement and resolution abnormalities Elevated bilirubin and prolonged ​­ Metabolic acidosis or prothrombin time if severe Coagulopathy Continued deterioration
Renal failure
Pancreatitis
Acetaminophen may also cause acute, extrahepatic toxic effects, presumably because of the presence of CYP450 or similar enzymes (e.g.,
,17 prostaglandin H synthase) in other organs. In rare cases, isolated renal injury, cardiac toxicity, and pancreatitis may occur.
Ingestion of massive doses of acetaminophen (e.g., >500 milligrams/kg or peak plasma acetaminophen concentration >750 micrograms/mL or >5000 micromole/L) can cause early­onset metabolic acidosis with an elevated lactate and altered sensorium even in the absence of either liver failure or hypotension. Likely mechanisms for this finding include depletion of liver glutathione stores resulting in generation of 5­​oxoproline and metabolite­
,19 induced inhibition of mitochondrial respiration.
DIAGNOSIS
A toxic exposure to acetaminophen is suggested when a patient ≥6 years old ingests (1) >10 grams or 200 milligrams/kg as a single ingestion, (2) >10 grams or 200 milligrams/kg over a 24­hour period, or (3) >6 grams or 150 milligrams/kg per 24­hour period for at least  consecutive days. For children <6 years old, ingestion of 200 milligrams/kg or more of acetaminophen as a single ingestion or over an 8­hour period, or of 150 milligrams/kg per 24­hour period for the preceding  hours is considered a toxic exposure.
These values are empiric and not validated in human trials, but they are widely used as recommendations for emergency evaluation.
Due to the widespread availability of acetaminophen­containing products, limited accuracy of the medical history, the delayed nature of clinical manifestations after overdose, and the serious complications of acute toxicity without antidotal therapy, measurement of a serum ​­
,21 acetaminophen concentration is recommended for all patients ​presenting to the ED with an intentional overdose. Potentially toxic
,23 acetaminophen concentrations are occasionally identified in patients who overdose but deny ingesting acetaminophen. Therefore, empirical testing of all patients with presumed intentional or chronic acetaminophen overdose may be cost­effective, as the estimated cost of treating a single patient for complications of acetaminophen­induced hepatotoxicity is judged to outweigh the cost of routine laboratory ​testing all intentional overdose patients.
THE RUMACK­MATTHEW NOMOGRAM
The implication of a measured acetaminophen concentration is ​determined by plotting the value on the Rumack­Matthew nomogram (Figure 190­

2). This nomogram was derived from a retrospective analysis of oral acetaminophen overdose patients and their clinical ​outcomes. The original nomogram line separating possible toxicity from unlikely toxicity was based on a 4­hour acetaminophen concentration of 200 micrograms/mL (1300 micromole/L), but was subsequently modified by moving the line to a 4­hour acetaminophen concentration of 150 micrograms/mL (1000 micromole/L) to increase the safety margin for treatment decisions. The nomogram only directly applies to an acetaminophen concentration obtained after a single oral exposure and during the window between  hours and  hours after ingestion. Outcome prediction using this nomogram cannot be applied to acetaminophen concentrations obtained outside this window or following chronic or recurrent exposures. Obtaining
,26 multiple acetaminophen concentrations following acute overdose is rarely indicated in the absence of hepatotoxicity. An initial concentration below the nomogram line may rarely “cross the line” in patients who ingest acetaminophen preparations known to have prolonged absorption
 kinetics. However, the clinical significance of “crossing the line” in this fashion is unknown. Similarly, because the nomogram was constructed and verified by using only a single serum concentration, the clinical implications of a concentration above the line that falls below it on repeat analysis are unknown.
FIGURE 190­2. Rumack­Matthew nomogram.
Based on data obtained before the widespread use of antidotal therapy, patients with serum acetaminophen concentrations above the original line (4­ hour postingestion concentration >200 micrograms/mL or >1300 micromole/L) were observed to have a 60% risk of ​developing hepatotoxicity (defined
 as alanine aminotransferase >1000 IU/mL), a 1% risk of renal failure, and a 5% risk of mortality. In addition, patients with extremely high serum acetaminophen concentrations (above a parallel line coinciding with a 4­hour postingestion concentration of 300 micrograms/mL or 2000 micromole/L) were observed to have a 90% risk of developing hepatotoxicity. The prediction of a safe outcome below the nomogram line corresponding to a 4­hour postingestion concentration of 150 micrograms/mL (1000 micromole/L) was confirmed in patients who did not receive antidotal therapy; the incidence of hepatotoxicity in patients with acetaminophen concentrations below this nomogram line was 1%, and all patients
 recovered without complications.
A validated method to determine potential toxicity from IV acetaminophen overdose has not been established. Fortunately, the
European experience with IV acetaminophen suggests that these overdoses appear to be rare in­hospital occurrences that are likely to occur following
28­30 an error in calculating the acetaminophen dose in pediatric patients. The available clinical data for evaluating IV acetaminophen overdose remain
,30,31 limited to several published case reports. Based on these data, the United Kingdom published revised precautionary guidelines recommending empiric acetylcysteine for any single IV acetaminophen dose above  milligrams/kg or acetaminophen concentrations above  micrograms/mL on the nomogram at  hours. The Rumack­Matthew nomogram was, however, derived solely from oral acetaminophen overdose patients, and the effectiveness of application to determine toxicity following IV acetaminophen overdose is unknown.
TREATMENT
GI DECONTAMINATION
For most cases of acetaminophen poisoning, adequate GI decontamination consists of the early administration of activated charcoal orally or through
,33 a nasogastric tube. More aggressive forms of decontamination, such as gastric lavage or whole­bowel irrigation, are unnecessary because of the rapid GI absorption of acetaminophen and the reliable success of treating acetaminophen poisoning with acetylcysteine.
ACETYLCYSTEINE
34­36
The mainstay for the prevention or treatment of acetaminophen ​toxicity is the administration of acetylcysteine. The current “​­ standard” acetylcysteine protocols were developed primarily from observational trials, and it is not clear if they represent the most ​effective
 regimens.
,37
Although its mechanisms of action are not fully understood, ​acetylcysteine is thought to have two important beneficial effects. In early acetaminophen poisoning (<8 hours after ingestion), acetylcysteine averts toxicity by preventing the binding of NAPQI to hepatic macromolecules.
Acetylcysteine may do this by acting as a glutathione precursor or substitute, or a sulfate precursor, or it may directly reduce NAPQI back to acetaminophen. In established acetaminophen toxicity or >24 hours after acetaminophen ingestion, acetylcysteine diminishes hepatic necrosis by acting as an antioxidant, decreasing neutrophil infiltration, improving microcirculatory blood flow, or increasing tissue oxygen delivery and extraction.
If acetylcysteine is given within  hours of an acute acetaminophen ingestion, it is nearly 100% effective in preventing the development of
 hepatotoxicity. The longer the initiation of acetylcysteine therapy is delayed beyond  hours after ingestion, the greater is the risk of developing
  hepatotoxicity. Even if administration is delayed up to  hours, acetylcysteine reduces risk of hepatotoxicity compared to historical controls.
Clinical experience suggests that patients with poor glutathione reserves, such as alcoholics and the chronically ill, have similar excellent clinical outcomes when the standard treatment guidelines are applied to their care. As such, there is no need to alter the use of the acetaminophen treatment nomogram or modify the dosing of acetylcysteine for these patients.
The weight of evidence suggests that acetylcysteine therapy is both safe and efficacious during pregnancy and that the approach to treating a pregnant patient following an acetaminophen overdose should remain the same. Acetylcysteine treatment has never been associated with fetal malformations in humans, but fetal demise and malformations have been described following a delay in acetylcysteine treatment after acetaminophen
 overdose in first­trimester pregnant women.
IV Acetylcysteine
IV acetylcysteine has supplanted oral administration due to its greater ease of administration, greater patient acceptance, equivalent efficacy, and
40­43 shorter duration of treatment for many cases of acetaminophen poisoning. The major limitation of IV acetylcysteine is the occurrence of drug­
,45 related anaphylactoid reactions, which occur in 4% to 17% of patients (most during the first  hours of ​administration). Mild cases are treated with diphenhydramine, and severe cases are treated by temporarily slowing or stopping the acetylcysteine infusion. Unfortunately, fulminant liver failure
,46 requiring transplant has occurred after discontinuation of N­acetylcysteine due to anaphylactoid reaction. IV N­acetylcysteine infusion can be
 reinitiated at a slower rate after administration of diphenhydramine in asymptomatic patients. Asthmatics appear to have a greater risk of anaphylactoid reactions during IV acetylcysteine therapy, whereas high acetaminophen concentrations are protective from developing anaphylactoid
,46,48­50 reactions.
The standard regimen for IV acetylcysteine uses a 21­hour protocol including a loading dose of 150 milligrams/kg over  hour, followed by a first maintenance dose of  milligrams/kg infused over  hours, and then followed by a second maintenance dose of 100 milligrams/kg infused over  hours (Table 190­2). Because the three­phase dosing regimen for IV acetylcysteine may result in dosing errors and produce side effects due to the
51­55 initial high infusion rate, alternative dosing regimens are being explored.
TABLE 190­2
Acetylcysteine Dosing Regimens
PO IV Adult IV Pediatric (21–40 kg) IV Pediatric (5–20 kg)
Preparation Available as 10% Available as 20% solution. Available as 20% solution. Available as 20% solution.
and 20% Dilution required. Dilution required. Dilution required.
solutions.
Dilute to 5% solution for PO administration.
Loading 140 milligrams/kg 150 milligrams/kg in 200 mL 5% ​­ 150 milligrams/kg in 100 mL 5% ​­ 150 milligrams/kg in  mL/kg 5% ​­ dose dextrose in water infused over  dextrose in water infused over  dextrose in water infused over  min min min
Maintenance  milligrams/kg  milligrams/kg in 500 mL 5%  milligrams/kg in 250 mL 5%  milligrams/kg in  mL/kg 5% ​­ dose every  h for  dextrose in water infused over  h dextrose in water infused over  h dextrose in water infused over  h doses (12.5 milligrams/kg per hour) (12.5 milligrams/kg per hour) (12.5 milligrams/kg per hour) followed by followed by followed by
100 milligrams/kg in 1000 mL 5% ​­ 100 milligrams/kg in 500 mL 5% ​­ 100 milligrams/kg in  mL/kg 5% ​­ dextrose in water infused over  h dextrose in water infused over  h dextrose in water infused over  h
(6.25 milligrams/kg per hour) (6.25 milligrams/kg per hour) (6.25 milligrams/kg per hour)
Duration of  h*  h*  h  h therapy
Comments Dilute with Monitor for drug­related adverse Monitor for drug­related adverse Monitor for drug­related adverse powdered drink effects and anaphylactoid reactions. effects and anaphylactoid reactions. effects and anaphylactoid reactions.
mix, juice, or soda.
Serve chilled.
Drink through a straw to reduce disagreeable smell.
*Check with your institution or poison control center for alternative dosing protocols and for management of adverse effects.
IV acetylcysteine is commercially available as a 20% solution and requires dilution to a 2% solution for infusion into a peripheral vein. Both 5% dextrose
 in water and half­normal saline can be used as ​diluents. Given the volume and hypotonicity of fluid required, ​specific acetylcysteine weight­based fluid volume guidelines should be followed for children and small adults (<40 kg), and these patients should be carefully monitored to avoid fluid overload and ​hyponatremia during treatment. A dose calculator and detailed pediatric dilution
 directions for IV acetylcysteine are available at Acetadote.com.
Despite the lack of randomized direct comparisons, IV acetylcysteine is as effective and safe as oral therapy for patients with early acetaminophen
,57­60 poisoning, as compared with retrospective cohorts and historical controls. IV acetylcysteine is the route of choice for patients with
 acetaminophen­induced fulminant hepatic failure because oral acetylcysteine has not been adequately studied in this setting.
Oral Acetylcysteine
The standard 72­hour oral acetylcysteine ​regimen used in the United States consists of a loading dose of 140 milligrams/kg followed by maintenance doses of  milligrams/kg every  hours for  additional doses (Table 190­2). It may still be appropriate in certain patients, such as those at high risk for anaphylactoid responses to the IV formulation and asthmatics. The taste is disagreeable, and some patients with persistent nausea and vomiting may require concomitant antiemetics such as ondansetron.
EXTRACORPOREAL ELIMINATION
Recent guidelines recommend extracorporeal treatment (extracorporeal membrane oxygenation) in addition to acetylcysteine only in the setting of altered mental status, metabolic acidosis, an elevated lactate, and an acetaminophen level of >900 milligrams/L. In all other instances, extracorporeal
 treatment would only be recommended in the rare clinical scenario where acetylcysteine was unavailable or could not be administered.
Acetylcysteine is dialyzable, and a dose increase to account for acetylcysteine removal during hemodialysis (50%) or continuous renal replacement
,64 therapy (25%) is recommended.
TREATMENT GUIDELINES BASED ON TIME TO ED PRESENTATION
Treatment guidelines for oral acetaminophen poisoning are based on the time to presentation to the ED after ingestion: <4 hours,
 between  hours and  hours, and unknown time or >24 hours before presentation (Figure 190­3). The risk of hepatotoxicity
 increases with the lag time between ingestion and initiation of acetylcysteine therapy. The optimal outcome with acetylcysteine therapy is achieved when it is administered within  hours after ingestion, so the optimal “decision­time window” for treatment is between the 4­hour acetaminophen
 concentration measurement and 8­hour goal to initiate acetylcysteine. No further acetaminophen serum measurements are necessary once the need for acetylcysteine therapy has been determined until the completion of the course of therapy.
FIGURE 190­3. Treatment guidelines for acetaminophen (APAP) ingestion. All times noted are after ingestion. AC = acetylcysteine; ALT = alanine aminotransferase;
AMS = altered mental status; AST = aspartate aminotransferase; Cr = creatinine; LFTs = liver function tests; PT = prothrombin time; Rx = treatment.
Presentation Within  Hours of Ingestion
For patients who present to the ED within  hours and are likely to have a significant acetaminophen overdose, treatment begins with GI decontamination (usually activated charcoal) while awaiting the 4­hour postingestion acetaminophen concentration. If the clinical laboratory can report the acetaminophen concentration within the 8­hour postingestion window, wait for the serum acetaminophen concentration and plot the result on the nomogram to determine whether acetylcysteine therapy is necessary. If the acetaminophen concentration will not be available by  hours after ingestion, empirically initiate acetylcysteine therapy, by either route, without waiting for the result. Subsequently, when the acetaminophen concentration is determined, the need for acetylcysteine therapy can be determined with the use of the nomogram.
Presentation >4 and <24 Hours After Ingestion
For patients who present >4 hours but <24 hours following acetaminophen ingestion, determine the serum acetaminophen concentration as soon as possible. GI decontamination may be performed, particularly for suspected ​co­ingestants, but it may have limited effectiveness because of the delay in presentation. If the laboratory can determine the acetaminophen concentration within  hours after ingestion, await the acetaminophen concentration and plot the result on the nomogram to determine if acetylcysteine therapy is necessary. Otherwise, empirically administer acetylcysteine.
Presentation >24 Hours After Ingestion or Time of Ingestion Unknown
For patients in whom the time of acetaminophen ingestion remains unknown or is >24 hours or for those with suggestive clinical findings of acetaminophen poisoning, a serum acetaminophen concentration and serum transaminase, bilirubin, and prothrombin time tests should be determined. Initiate acetylcysteine therapy as soon as possible while awaiting laboratory results. In this scenario, a detectable acetaminophen concentration (>10 micrograms/mL or >66 micromole/L) suggests that the patient may be at risk for developing hepatotoxicity. Similarly, elevated serum transaminases suggest the possibility of ongoing hepatic toxicity. Therefore, continued acetylcysteine therapy is indicated if the acetaminophen concentration is measurable or if the serum transaminases are elevated. If serum acetaminophen concentration is <10 micrograms/mL (<66 micromole/L) and the serum transaminases are not elevated, the acetylcysteine can be discontinued.
DISPOSITION AND FOLLOW­UP
Recheck serum acetaminophen and transaminase levels at the completion of acetylcysteine therapy with continuation of a​ cetylcysteine infusion at the rate of .25 milligrams/kg per hour. If serum acetaminophen concentration is not detectable or is <10 micrograms/mL (66 micromole/L)
,43 and transaminase concentrations are normal, the acetylcysteine therapy can be discontinued. If either the serum acetaminophen concentration or liver function tests are elevated, the acetylcysteine should be continued until the serum acetaminophen concentration is undetectable and the patient has demonstrated clearly downtrending transaminases (at least two values) and there are no signs of synthetic liver dysfunction.
All patients requiring acetylcysteine therapy should be admitted to the hospital until the completion of the therapy. In general, admission to a hospital floor bed is adequate unless the co­ingestant is of concern, hepatotoxicity is severe, or the patient is suicidal and 24­hour direct observation cannot be arranged. Patients who are not at risk for developing acetaminophen­induced hepatotoxicity (e.g., acetaminophen concentration below the nomogram or unmeasurable acetaminophen concentration with normal hepatic transaminase concentrations) should be observed in the ED for  to  hours to exclude potentially toxic ​co­ingestants before disposition. Psychiatric evaluation should be considered for patients with intentional acetaminophen overdoses. Cases of acetaminophen ingestion or toxicity should be reported to the regional poison control center for both data collection purposes and assistance with management.
SPECIAL CONSIDERATIONS
FULMINANT HEPATIC FAILURE
Unfortunately, a small percentage of patients who overdose with acetaminophen will develop fulminant hepatic failure. The mortality rate for patients with acetaminophen­induced fulminant hepatic failure without acetylcysteine therapy is significant. Most fatalities occur on days  to  after overdose and are attributed to hepatic complications such as cerebral edema, hemorrhage, shock, acute lung injury, sepsis, and multiorgan failure. Patients who survive fulminant hepatic failure generally begin to show evidence of recovery by days  to . Survivors will eventually develop complete hepatic regeneration without any ​persistence of hepatic impairment.
Acetylcysteine treatment decreases the incidence of cerebral edema, reduces vasopressor requirements, and improves survival in acetaminophen­
,65 induced fulminant hepatic failure. Acetylcysteine also appears to be beneficial in the treatment of other forms of hepatic failure, including viral
66­68 hepatitis and alcoholic cirrhosis.
Prognostic indicators (aka King’s College Criteria) associated with the highest risk of mortality from acetaminophen­induced fulminant hepatic failure include metabolic acidosis (arterial pH <7.30) despite fluid and hemodynamic resuscitation, or a combination of coagulopathy (prothrombin time >100
 seconds), renal insufficiency (serum creatinine >3.3 milligrams/dL or >292 micromole/L), and grade III or IV hepatic encephalopathy. Other predictors of a poor prognosis individually include an Acute Physiology and Chronic Health Evaluation II score >15, elevated serum lactate (>26 milligrams/dL or
>3.0 mmol/L) after fluid resuscitation, hypoglycemia, and elevated serum phosphate (>3.71 milligrams/dL or >1.2 mmol/L) on the second day after
70­73 ingestion.
Treatment for acetaminophen­induced fulminant hepatic failure includes acetylcysteine therapy; correction of coagulopathy and ​acidosis; monitoring for and aggressive treatment of cerebral edema, hypoglycemia, and electrolyte abnormalities; and early patient referral to a liver specialty or transplant center. Unlike the treatment of early acetaminophen toxicity, IV acetylcysteine therapy should be continued past the 21­hour standard regimen and until the patient recovers, receives a liver transplant, or dies.
MULTIPLE­DOSE AND EXTENDED­RELEASE ACETAMINOPHEN INGESTIONS
Patients with staggered acetaminophen ingestions and liver injury often have delayed presentation to the hospital and a higher rate of adverse
 outcomes. Multiple closely spaced acetaminophen ingestions and extended­release acetaminophen ingestions represent two unique aspects of acetaminophen poisoning for which the Rumack­Matthew nomogram cannot be applied because a single time of ingestion does not exist. A conservative approach is to assume that a single ingestion occurred at the earliest possible time stated by the patient, with the acetaminophen concentration plotted on the Rumack­Matthew nomogram based on this artificial time and treatment decisions made accordingly. For example, if the patient ingests five doses of  milligrams/kg of acetaminophen over a 4­hour period beginning  hours ago, a single acetaminophen ingestion is assumed to have occurred  hours ago, and the serum concentration is accordingly plotted on the nomogram.
Extended­release acetaminophen formulations consist of a bilayered tablet containing a 325­milligram immediate­release outer layer and a 325­ milligram slow, continuous­release, highly compressed inner layer. Because there are few clinical data concerning overdose with these preparations, treatment guidelines remain conservative, and the manufacturer recommends obtaining a second acetaminophen concentration  to  hours after the first concentration in those situations in which the first measured concentration (4 to  hours after ingestion) is elevated, but below the nomogram
,75,76 line. A full course of acetylcysteine therapy should be instituted (or continued if already started) if the second acetaminophen concentration is above the nomogram line. If the initial concentration is above the nomogram line, standard therapy should be administered, and there is no need to obtain a second concentration.
MASSIVE ACETAMINOPHEN OVERDOSE
Patients presenting after massive (>40 grams or 500 milligrams/kg) acetaminophen overdose are at high risk of hepatotoxicity, even with early
,77­79 acetylcysteine administration. The standard 21­hour protocol relies on empiric dosing, and this model may prove inadequate for patients with massive acetaminophen overdose. At this time, no data demonstrate superiority of an alternative regimen, but in patients with massive acetaminophen overdose, enhanced therapeutic measures should be considered. Options include the addition of oral acetylcysteine to the standard
IV protocol, increasing the third infusion dose to 200 milligrams/kg over  hours as opposed to the dose of 100 milligrams/kg over  hours used in the standard IV acetylcysteine protocol, or reloading the standard acetylcysteine regimen at completion of the 21­hour protocol if serum
,81 acetaminophen concentration remains significantly elevated.
IV ACETAMINOPHEN OVERDOSE
Accepted guidelines for treatment of IV acetaminophen overdose do not currently exist in the United States. The United Kingdom has published revised precautionary guidelines recommending empiric acetylcysteine for any single IV acetaminophen dose >60 milligrams/kg or acetaminophen concentrations >50 micrograms/mL on the nomogram at  hours. The local poison center should be contacted for guidance following any suspected IV acetaminophen overdose.


