## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 39: Wound Evaluation
Adam J. Singer; Judd E. Hollander
PRINCIPLES OF INITIAL EVALUATION
1­3
Evaluation of the patient with a traumatic wound begins with overall patient assessment. Less obvious but more serious life­threatening injuries
,2 need care before directing attention to wound management. Determine the patient’s past medical history and circumstances surrounding the injury.
Remove rings or other circumferential jewelry as soon as possible so they do not act as constricting bands when swelling progresses. Remove clothing over the injured area to reduce the potential for contamination.
External bleeding can usually be controlled by focal direct pressure over the bleeding site. When possible, replace skin flaps to their original position before applying pressure in order to avoid exacerbating vascular compromise. Tourniquet application may be necessary to stop life­threatening
,5 exsanguination or when needed for a short period to create a “bloodless” field for wound inspection. Amputated fingers or extremities should be wrapped with a moist, sterile, protective dressing, placed in a waterproof bag, and then placed in a container of ice water for preservation and
 consideration for future reattachment. Before wound exploration, cleansing, and repair, most patients will need some form of anesthesia. Systemic analgesia or procedural sedation may be required (see Chapter , “Acute Pain Management,” and Chapter , “Procedural Sedation and Analgesia in
Adults”).
RISK ASSESSMENT
,2
Proper wound management begins with a pertinent patient history (Table 39­1). A variety of patient factors have adverse effects on wound healing and increase the rate of wound infection—extremes of age, diabetes mellitus, chronic renal failure, obesity, malnutrition, the use of
 immunosuppressive medications, the presence of connective tissue disorders, and protein and vitamin C deficiencies. Predictive factors for infection
7­9 are the wound characteristics of mechanism of injury, location, depth, length, configuration, and contamination.
TABLE 39­1
Pertinent Medical History
Symptoms
Pain, swelling, paresthesias, muscle weakness
Type of force causing injury
Crush (blunt) or shear (sharp)
Bite or puncture
Elements of contamination
Time elapsed from injury until initial cleansing
Time elapsed from injury until presentation
Wound care performed prior to ED arrival
Object that caused injury (glass, wood, etc.)
Cleanliness of body and environment at time of injury and afterward
Factors resulting in injury
Intentional or unintentional
Occupation or nonoccupation related
Assault or self­inflicted

Foreign body potential
Chapter 39: Wound Evaluation, Adam J. Singer; Judd E. Hollander 
©2025 McGrawD Hidil tl.h Ae lol bRjeigcth btsre Rake osre srhvaetdte. r ? Terms of Use * Privacy Policy * Notice * Accessibility
Foreign body sensation
Removal of portion of object
Function
Occupation and handedness
Allergies
Anesthetics, analgesics, antibiotics, and latex
Medications
Chronic medical conditions that increase risk of infection
Chronic medical conditions that increase likelihood of poor wound healing
Previous scar formation (hypertrophic scars or keloids)
Ascertain the tendency of patients to form hypertrophic scars or keloids by both history and examination, as past experience may predict poor scar formation. Black and Asian patients are more prone to keloid formation than whites. Hypertrophic scars are due to tissue tension during wound healing, and these scars stay within the original wound boundaries and tend to undergo partial spontaneous regression within  to  years. Keloids are genetically linked variations in wound healing, resulting in the production of excess collagen beyond the original wound boundaries (Figure 39­1).
Once formed, keloids rarely decrease in size.
FIGURE 39­1. A large keloid extending beyond the original wound margins. [Reproduced with permission from Park CW, Juliano ML, Woodhall D: Wounds and soft tissue injuries, in Knoop KJ, Stack LB, Storrow AB, Thurman RJ (eds): Atlas of Emergency Medicine, 4th ed. Figure 18­41. Copyright © 2016, by McGraw­
Hill Education. All rights reserved.]

Obtain a detailed history of allergies or prior adverse reactions to anesthetic agents or antibiotics. Review any prior allergies to latex.
Determine the status of prior tetanus immunization and the need for further tetanus vaccination (see Chapter 157, “Tetanus”).
Review the mechanism of injury to determine the risk for potential wound contaminants and foreign bodies. Bite wounds have higher risk for infection and are generally managed differently than other lacerations (see Chapter , “Puncture Wounds and Bites”). Foreign bodies are more common in
,12 puncture wounds, wounds associated with broken glass, and motor vehicle collisions. Ask about the presence of a foreign body sensation. In
 adults, those reporting a foreign body sensation are more likely to have a retained foreign body than those who do not. This question has little utility
 in children.
,8
Both foreign body retention and visible contamination increase the risk of infection. Organic and inorganic components of soil can cause infection even from very small doses of bacterial inoculum. Clay is the major inorganic soil component responsible for promoting infection. Conversely, sand grains and black dirt from roadways are relatively inert.
,8
The likelihood of wound infection varies according to the forces applied at the time of injury. The most common mechanism for traumatic wounds is blunt force. The skin is crushed against underlying bone and tears or splits from the subsequent tension. Conversely, sharp objects produce shear forces that cut skin cleanly. Severely crushed injuries producing extensive tissue devitalization are more susceptible to infection than wounds from shear forces. However, these distinctions may not be clinically relevant when appropriate principles of wound care are used, as was observed in a
 multicenter observational study that did not find higher rates of infection in blunt versus sharp injuries.
Low­energy impact injuries may not result in lacerations, but instead may disrupt vessels, leading to ecchymosis or hematoma formation. Some hematomas spontaneously resorb. Those that become encapsulated may eventually require aspiration or incision and drainage.
Determine the time that the injury occurred. Although the growth of the bacterial inoculum is directly related to the time interval from injury to
,15­17 laceration repair, there is no clearly defined relationship of time to closure to clinical infection (Table 39­2). Therefore, time from injury until presentation is only one element to be considered, in addition to the injury mechanism, location, degree of contamination, host risk factors, and the importance of cosmetic appearance, before determining whether or not to perform
 primary wound closure. The aforementioned multicenter observational study confirmed that a history of diabetes, visible contamination, length greater than  cm, and non–head­and­neck location are associated with higher rates of infection. However, there was no association between time
 from injury to wound closure and the development of infection. Wounds that are not closed primarily because of a high risk of infection should be considered for delayed primary closure after  days. The consensus of wound­care experts is that after  days of open wound management, the risk of
 infection after closure substantially decreases, although this approach has not been subjected to randomized controlled trials.
TABLE 39­2
Risk of Wound Infection as Function of Time From Injury to Closure
Distinction Between Percent
Infection Rate/Inadequate Infection Rate/Inadequate
Reference Comments Early and Late Closure Difference
Healing With Early Closure Healing With Late Closure
(h) (95% CI)
Berk et al, All locations  8/97 (8.2%) 25/107 (23.4%) .1% (5.4% to
198816 .8%)
Head  2/44 (5%) 1/36 (3%) −1.8% (−9.9% to .4%)
Trunk and  6/53 (11.3%) 24/71 (33.8%) .5% (8.6% to extremities .4%)
Baker and Children, 59%  32/2665 (1.2%) 2/147 (1.3%) .16% (−1.76%
Lanuti, head and neck to .08%)
199016 location
Van den Adults, all  30/363 (9.1%) 3/45 (6.7%) −1.6 (−6.2 to
Baar et al, locations, sutured .4)

Quinn et al, All locations,  5/135 (3.7%) 43/1443 (3.0%) .7% (−1.6% to
20149 sutured wounds .5%)
Determine whether the wound was the result of an intentional, unintentional, or workplace event. Most states have regulations that require the reporting of intentional injuries, and patients with self­inflicted injuries may need psychiatric evaluation. Occupational injuries may require alternative follow­up arrangements.
7­9,19
The anatomic location of the injury helps predict the clinical outcome, both in terms of infection risk and cosmetic result (Table 39­3). The risk of infection is determined largely by the interplay between baseline bacterial colonization and vascular blood supply. With respect to bacterial colonization, the density of the bacterial population is low on the upper arms, legs, and torso. Conversely, moist areas of the body, such as the axilla,
 perineum, toe webs, and intertriginous areas, harbor millions of bacteria per square centimeter, including anaerobes. Obviously, any wounds with human or animal fecal contaminants run a high risk of infection, even with therapeutic intervention.
TABLE 39­3
Approximate Risk of Wound Infection After ED Closure
Location Risk of Infection (%)
Head and neck 1–2
Upper extremity 
Lower extremity 
7­9
Wounds located on highly vascular areas, such as the face or scalp, are less likely to be infected than wounds located in less vascular areas. The increased vascularity of the area more than offsets the high bacterial inoculum found in the scalp, and lacerations of the scalp and face have a very low
,21 infection rate regardless of the intensity of cleansing. Although prophylactic oral antibiotics have traditionally been considered as warranted for
  intraoral lacerations, there is inconclusive evidence to support their use, and practice varies considerably.
WOUND EXAMINATION
Thorough wound examination should be conducted when the patient is calm and cooperative and positioned appropriately, with optimal lighting conditions, and with little or no residual bleeding. The use of magnifying lenses, such as surgical loupes (×2.5) or reading glasses, may improve
 visualization and reduce the likelihood of missing foreign bodies.
Cursory examination under poor lighting or when the depths of the wound are obscured by blood will occasionally result in poor detection of foreign bodies and tendon, nerve, and vascular injuries. If bleeding is a problem, epinephrine­containing anesthetic solutions may be helpful, when not contraindicated. Tourniquets may be used to obtain a bloodless field, but they should not be used for more than  minutes.
Lacerations over joints may have penetrated the joint capsule, and sometimes it is necessary to inject the joint with normal saline to ensure that there
 is no communication between the joint space and the laceration. Evaluate the wound in neutral position, throughout the full range of motion, and particularly in the position present during injury. Chain­saw knee wounds, for example, are often sustained with the knee in flexed position.
Repositioning the joint or extremity in the position assumed during injury can better reconstruct the mechanism of injury and identify injured structures. Lacerations over the metacarpophalangeal joints are suspicious for having occurred during a fight (clenched fist injury) and should be treated as though they are human bites.
IMAGING
Although most lacerations will not require any diagnostic testing, on occasion, wound imaging for detection of foreign bodies may be necessary (see
Chapter , “Soft Tissue Foreign Bodies”). Most foreign bodies commonly found in wounds are much denser than the surrounding tissue and are
 readily apparent on plain radiographs. Metal, bone, teeth, pencil graphite, certain plastics, glass, gravel, sand, some fish bones, some painted wood, and most aluminum are visible on plain radiographs.
,28
CT and MRI are useful for identifying and locating objects that have densities similar to soft tissue. US may also be useful, particularly for wooden
 foreign bodies, although the sensitivity of US is inadequate to reliably exclude small (<2.5 mm) wood fragments. Cone beam CT may be even more
 sensitive than the other modalities.
PATIENT EDUCATION
Patients should be carefully educated regarding the expected cosmetic outcome. They should be informed that all lacerations result in some scarring
 and, if predisposed, possible keloid formation. Some indication of the maximal width of the scar can be predicted based on wound location, whether the laceration is aligned parallel or perpendicular with lines of minimal tension, and how gaping the wound is while at rest (static tension) or when put
,23 through a range of motion (dynamic tension). Lacerations over joints (which have more dynamic tension) will have wider scars than similar lacerations subject to less tension. Wounds that deviate from the lines of skin tension will also be prone to greater scar formation after suturing than
 wounds that are more closely aligned with skin tension. The most important determinant of cosmetic outcome under control of the treating physician is meticulous wound repair with approximation of viable wound edges under little tension.


