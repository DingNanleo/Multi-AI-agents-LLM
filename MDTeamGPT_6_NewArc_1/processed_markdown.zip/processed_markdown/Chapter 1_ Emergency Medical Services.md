
University of Pittsburgh
Access Provided by:

Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 1: Emergency Medical Services
C. Crawford Mechem

INTRODUCTION
EMS is the extension of emergency medical care into the prehospital setting. Today’s EMS systems have their roots in legislative and clinical developments of the 1960s and 1970s. The 1966 report “Accidental Death and Disability—The Neglected Disease of Modern Society” highlighted the deficiencies of prehospital care of trauma victims, attributable to inadequate equipment and training. Until that time, more than half of ambulance services were run by funeral homes because hearses were among the few vehicles able to transport a stretcher. The National Highway Safety Act of 1966 established the Department of Transportation and made it the lead agency responsible for upgrading EMS systems nationwide.

In 1967, J. F. Pantridge began using a physician­staffed mobile coronary care unit in Belfast, Northern Ireland, to provide prehospital cardiac care.
Physician staffing of ambulances never gained popularity in the United States. However, in the late 1960s and 1970s, nonphysician personnel began
3 learning advanced skills, including IV administration of medications, cardiac rhythm interpretation, and defibrillation.

The U.S. EMS Systems Act of 1973 made available federal grants to develop regional EMS systems. Approximately 300 EMS regions were established. To receive funding, the Act required that EMS systems address 15 key elements (Table 1­1). These elements form the foundation of many EMS systems today.

TABLE 1­1
Fifteen Key Elements of EMS Systems Defined by U.S. EMS Systems Act of 1973
Manpower
Training
Communications
Transportation
Facilities
Critical care units
Public safety agencies
Consumer participation
Access to care
Patient transfer
Coordinated patient record keeping
Public information and education
Review and evaluation
Disaster plan
Mutual aid

The 1970s became a Golden Age for EMS. The U.S. Department of Transportation developed curricula for emergency medical technicians, paramedics, and first responders. EMS communications systems were formalized. In 1972, the Federal Communications Commission recommended 9­1­1 be adopted as the emergency telephone number nationwide. In addition, the concept of designated trauma centers was introduced, with the idea being that EMS personnel would transport injured patients preferentially to these facilities.

The Omnibus Budget Reconciliation Act of 1981 eliminated direct federal funding for EMS. Instead, federal funds were distributed as block grants. The result was a decrease in both EMS funding and coordination. EMS systems took on a decidedly local flavor, with great variation between systems. This trend has had long­term consequences for the field.

In 2011, the American Board of Emergency Medicine recognized EMS as its seventh subspecialty. The certification examination is based on the Core Content of EMS Medicine with four major content areas: Clinical Aspects of EMS Medicine, Medical Oversight of EMS, Quality Management and Research, and Special Operations.

EMS SYSTEM OVERVIEW
A review of the 15 elements of EMS systems identified by the EMS Systems Act of 1973 (Table 1­1) provides insight into the structure of EMS systems and the challenges they face.

MANPOWER
In most urban areas, paid public safety and ambulance personnel provide prehospital care. In contrast, suburban, rural, or wilderness EMS systems commonly use volunteers. Personnel fall into one of four licensure levels in accordance with the National EMS Scope of Practice Model, set forth by the
National Highway Traffic Safety Administration. These are emergency medical responder, emergency medical technician, advanced emergency medical technician, and paramedic. Each type of provider must master a minimum set of skills. Emergency medical responders are often first on the scene of an emergency. They are trained to perform CPR, spine immobilization, and hemorrhage control and to use auto­injectors, automated external defibrillators, and other basic interventions while awaiting an ambulance. Emergency medical technicians function as part of an ambulance crew. Their training includes oxygen administration, CPR, hemorrhage control, and patient extrication, immobilization, and transportation. They assist patients in using some of their own medications and can administer certain over­the­counter medications. Advanced emergency medical technician training includes additional assessment skills plus placement of IVs and supraglottic airway devices and administration of some medications. Paramedics have
6 the highest skill level. Because of their advanced level of training, paramedics function under a designated physician’s supervision.

TRAINING
Training includes initial provider training and continuing education. As EMS call volume increases, providers often care for a disproportionate number of patients with minor medical issues. Maintaining proficiency in skills to manage critically ill patients may be difficult. Innovative training methods to ensure skills retention must be sought. Use of computerized human patient simulators is one option, both for reviewing skills and learning new ones.

COMMUNICATIONS
The adoption of 9­1­1 as a nationwide emergency number has greatly facilitated public access to emergency care. In many systems, the local public safety answering point has software that provides the number and location of a caller (enhanced 9­1­1). Widespread use of cellular telephones has prompted the development of technology to identify and locate these callers as well, in accordance with Federal Communications Commission regulations. Emergency call takers are trained to collect necessary information, dispatch appropriate resources, and offer first aid or prearrival instructions while the ambulance is en route. Ambulance personnel should also be able to communicate with the destination hospital. Most EMS personnel operate under standing orders and protocols. However, there are times when providers may require online medical control, talking directly with a physician for direction. Historically, communications represent the weakest link in disasters. It is important that EMS communication systems have built­in redundancy to ensure uninterrupted service.

TRANSPORTATION
Ambulance design must enable EMS personnel to provide care such as airway and ventilatory support while transporting the patient safely. Basic life support ambulances carry equipment appropriate for personnel trained at the emergency medical technician level, such as automated external defibrillators, oxygen, bag­mask ventilation devices, immobilization and splinting devices, and wound dressings. They carry few medications and cannot transport patients requiring IVs or cardiac monitoring. Advanced life support ambulances are equipped for advanced emergency medical technicians or paramedics, including IV fluids and medications, intubation equipment, cardiac monitors, and pulse oximeters. Ground transportation is appropriate for the majority of patients, especially in urban and suburban areas. However, air transport, generally by helicopter, should be considered for critically ill patients when ground transport time would be long or if the terrain is difficult to navigate.

FACILITIES AND CRITICAL CARE UNITS
Patients are often transported to the closest appropriate hospital. In recent years, the number of specialty hospitals has increased, including pediatric hospitals, trauma centers, burn centers, stroke centers, and centers with advanced cardiac or resuscitation capabilities. Tertiary care centers provide many of these services and may also have a large number of critical care unit beds. The decision to bypass hospitals to go directly to a specialty center, often at a greater distance, is not a simple one. Although specialty hospitals often have more resources, transporting an unstable patient past an ED to
1 get to the specialty hospital is not without risks. Furthermore, bypassing hospitals may have negative financial consequences for bypassed facilities. It is wise to solicit input from the local medical community before developing destination policies involving specialty centers.

Due to ED overcrowding, even the largest hospitals may not always have adequate resources to care for EMS patients. This may result in prolonged offload times of ambulance patients, long wait times for patients to be seen, and ED boarding of admitted patients. Furthermore, some EDs may request EMS divert elsewhere. Because of these issues, regional EMS systems should develop methods to monitor available resources of their receiving hospitals. A secure, Internet­based website of hospital resources, including ED and inpatient bed availability, is one option.

PUBLIC SAFETY AGENCIES
EMS systems should have strong ties with police and fire departments. Many large EMS systems are run by fire departments. In addition to providing scene security, public safety agencies can provide first responder services because they are often first on the scene. Fire and police automated external defibrillator programs are common. Police administration of naloxone to opioid overdose victims is also a growing trend. Such practices have been shown to improve patient outcomes. Finally, EMS personnel often provide medical support to police and fire departments in hazardous circumstances.

CONSUMER PARTICIPATION
Public support, both political and financial, is necessary for a good EMS system. It is important that laypersons contribute to policymaking. One way to accomplish this is to encourage representation of the public on regional EMS councils. The public can also participate by volunteering for local EMS agencies.

ACCESS TO CARE
Successful EMS systems ensure all individuals have access to care regardless of ability to pay. The EMS system is often a patient’s primary entry point into the healthcare system. There should be no barriers preventing access. A more difficult problem exists when terrain or low population densities result in longer response times for some citizens, as in rural or wilderness areas. EMS telemedicine programs may be one way to bring high­level medical expertise to patients in remote areas.

PATIENT TRANSFER
Patients are often transferred from one medical facility to another for a higher level of care. Safe and seamless transfer is an important concept and may be facilitated if transferring and receiving facilities develop transfer agreements in advance. The Emergency Medical Treatment and Active Labor
Act of 1986 sets forth rules hospitals participating in the Medicare program must follow. Under the Emergency Medical Treatment and Active Labor Act, all patients must receive a medical screening exam and be stabilized before transfer. There must also be explicit acceptance of the transfer by the receiving hospital.

COORDINATED PATIENT RECORD KEEPING
Maintaining good medical records is important to any patient encounter. Prehospital medical records must be legible and readily accessible to hospital providers. Standardization of EMS records among different agencies within a region helps streamline transfer of information between prehospital and hospital providers. The adoption of electronic charting and cloud­based electronic medical record keeping by EMS systems is a step toward this goal. Electronic charts can be printed out in the receiving ED or downloaded from a secure Internet website. Regardless of the system used, EMS agencies
15 must comply with the Health Insurance Portability and Accountability Act of 1996, designed to protect the privacy of patient health information.

PUBLIC INFORMATION AND EDUCATION
EMS systems have a responsibility to train the public on how to access EMS and use it appropriately. As EMS call volumes rise and available resources decline, educating the public to use 9­1­1 for true emergencies is an appropriate goal. However, given the obstacles that many patients encounter in accessing office­ or hospital­based care, conveying this message is not simple. The public needs to know that EMS will always be there when needed.

Another important message EMS can convey to the public is the importance of learning CPR, first aid, and basic disaster preparedness. Recent disasters have illustrated that, at times, the emergency response infrastructure may be so seriously disrupted that it may take hours or longer for help to arrive. A public that is adequately prepared and trained will be in a better position to safely await help.

REVIEW AND EVALUATION
To ensure proper functioning of an EMS system and high­quality care, there must be a process for ongoing review and evaluation. This requires input from EMS providers and active involvement of a physician medical director. A continuous quality improvement program should be established to assess system performance and formulate improvements. Routine audits of communications, response and scene times, and patient care records should be performed. Focused audits of conditions such as cardiac arrest and trauma are valuable. However, obtaining patient outcomes may be problematic. An unforeseen consequence of the Health Insurance Portability and Accountability Act is that hospitals are often hesitant to release patient information, even to EMS services, for fear of liability.

EMS research is invaluable in advancing prehospital care. It should not be assumed that what works in the hospital will work in the prehospital setting. Issues such as limited funding, barriers to getting patient outcomes, and obtaining informed consent from critically ill patients, or waivers of consent, can make prehospital research daunting. However, these barriers must be overcome if patients are to receive quality care.

DISASTER PLAN
The EMS system is an integral part of disaster preparedness and should be involved in planning with other agencies and the medical community. The Omnibus Budget Reconciliation Act legislation of 1981 ended direct federal block grants to EMS. Because EMS is often not considered to be a public safety entity, emergency preparedness funding for EMS has fallen behind that of police and fire services. Despite this, EMS agencies must maintain a high level of disaster preparedness. This involves written policies and procedures, stockpiling supplies that may be depleted in multicasualty situations, and participating in regional disaster drills with other emergency response agencies and hospitals.

MUTUAL AID

EMS services should develop mutual aid agreements with neighboring jurisdictions so care is available when local agencies are unable to respond.Depending on the size and resources of the system, mutual aid may be required frequently or only under extreme circumstances. Addressing in advance details such as reimbursement, credentialing, liability, and chain of command at incident scenes will streamline the process.

CHALLENGES AND FUTURE TRENDS

The 2006 Institute of Medicine publication Emergency Medical Services at the Crossroads detailed many of the challenges facing EMS. These include fragmentation and lack of interoperability between EMS systems, between EMS and other public safety agencies, and between EMS and the rest of the healthcare infrastructure. These limit the efficiency of EMS systems and may have serious consequences in disaster response. In addition, the fallout from the Omnibus Budget Reconciliation Act legislation of 1981 is still being felt. Funding for EMS continues to fall behind other public safety agencies.
Restructuring of Medicare payment for advanced life support and basic life support services has impacted reimbursement. The effect of the Affordable
Care Act on EMS is unclear. It has resulted in an increased number of individuals covered by Medicaid and a proliferation of high­deductible insurance plans, factors that may affect EMS revenues. In the face of these uncertainties, many EMS agencies may have to find other funding sources or cut services. This is occurring at a time when call volumes are rising in many areas, in part due to the aging of the population and limited access to health care.

While demand for EMS steadily grows, in many parts of the country, EMS staffing is not keeping pace. Many EMS systems are currently experiencing paramedic shortages. Low pay, high stress, increased length of training, and limited advancement opportunities may make alternative careers in health care more appealing.

As a consequence of funding and staffing constraints, many EMS systems routinely operate at full capacity. As a result, their surge capacity, or ability to accommodate a sudden, large increase in demand for services, is limited. To enhance surge capacity, EMS systems need additional funding for personnel, vehicles, and supplies. They must also participate in mutual aid programs and frequent training based on threats they are most likely to encounter.

Despite the many challenges EMS faces, the quality of care continues to improve, driven in part by EMS research. Some of the advances involve regionalization of care, resuscitation of cardiac arrest victims, and management of ST­segment elevation myocardial infarction (STEMI) patients. The quality of cardiac arrest studies has been enhanced by adoption of the Utstein template for data reporting. The Utstein style presents a systematic and standardized format for reporting cardiac arrest data, facilitating comparison of results of studies from different EMS systems. The importance of basic life support skills in cardiac arrest and other emergencies is being rediscovered. Basic interventions in some cases can have a greater impact on outcome than advanced life support skills. More widespread use of automated external defibrillators by first responders and the public has the potential to increase cardiac arrest resuscitation rates. The emphasis on high­quality, uninterrupted CPR, as set forth by the 2015 Guidelines for CPR and Emergency Cardiovascular Care, is widely reflected in EMS protocols. Devices that provide instant feedback on the quality of CPR are in use by many EMS services. Prehospital use of 12­lead electrocardiograms on patients with chest pain is now common. Some systems transmit electrocardiograms to receiving EDs. Others activate cardiac catheterization labs directly when a patient with STEMI is identified on electrocardiogram.

EMS is maturing as an important subspecialty of emergency medicine. Growing populations and increased urbanization are driving the development of EMS systems worldwide. The aftermath of the 2004 Asian tsunami emphasized the need for organized and effective prehospital care in developing countries, as well as for international cooperation among EMS agencies. Although EMS systems in some countries are similar to those in the United States, in other countries, differences in geography, healthcare system design, funding, and political structure present unique challenges and the potential for novel solutions. These developing systems have the advantage of not being encumbered by decades of tradition and thus can take advantage of lessons learned elsewhere. They also present the opportunity for collaboration on international research initiatives that can lead to improved patient outcomes.
