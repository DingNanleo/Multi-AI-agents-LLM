## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 96: Abnormal Uterine Bleeding
Bophal Sarha Hang
INTRODUCTION
Abnormal uterine bleeding is an overarching term that is defined as bleeding from the uterine corpus that is irregular in volume, frequency, or
,2 duration in absence of pregnancy (Table 96­1). Vaginal bleeding is a common complaint in the ED, and differential diagnoses include pregnancy, structural abnormalities (e.g., polyps, fibroids), endometritis, coagulopathies, trauma, and various other causes. This chapter will focus on the ED evaluation and management of abnormal uterine bleeding.
TABLE 96­1
FIGO Terminology for Bleeding2* Type Definition
Abnormal uterine bleeding Bleeding that is abnormal in regularity, volume, frequency, or duration. Bleeding may be acute or chronic and is present for at least  months.
Heavy menstrual bleeding (heavy Excessive menstrual bleeding that interferes with a woman’s physical, emotional, social, and quality of life. Note uterine bleeding [HUB] replaces that the definition is menstrual bleeding deemed excessive by the patient regardless of duration, frequency, or menorrhagia) timing.
Amenorrhea Bleeding that is absent for >6 months.
Prolonged menstrual bleeding Menstrual periods that exceed  days’ duration on a regular basis.
Intermenstrual bleeding (replaces Bleeding episodes between normally timed menstrual periods.
metrorrhagia)
Irregular menstrual bleeding Unpredictable onset of menses, with cycle variations >20 days over a period of  year.
Postmenopausal bleeding Any bleeding that occurs >12 months after cessation of menstruation.
Abbreviation: FIGO = International Federation of Gynecology and Obstetrics.
Source:https://www.figo.org/news/ground­breaking­figo­classification­published­ijgo­0014139. *Discarded terms include dysfunctional uterine bleeding, menorrhagia, functional uterine bleeding, hypermenorrhea, hypomenorrhea, menometrorrhagia, metrorrhagia, oligomenorrhea, polymenorrhea, and uterine hemorrhage.2
MENSTRUAL CYCLE
A normal menstrual cycle has an average duration of .5 to  days and an interval of  to  days between the onset of menses. The average blood loss is ≤30 mL, and menstrual blood loss >80 mL is considered abnormal. Menstrual cycle variation during early menarche and the perimenopausal period
 iCs hdaupet etor 9h6ig:h A pbrneovramleanlc Ue toefr ianneo Bvulelaetdioinng. ,F Bigouprhea l9 S6a­r1h dae Hpiacntsg hormonal and endometrial changes associated with a normal menstrual cyclPea.ge  / 
. Terms of Use * Privacy Policy * Notice * Accessibility
FIGURE 96­1. The hormonal, ovarian, endometrial, and basal body temperature changes and relationships throughout the normal menstrual cycle. E =
 prostaglandin E ; FSH = follicle­stimulating hormone; LH = luteinizing hormone; P = progesterone. [Reproduced with permission from Patel DR,

Greydanus DE, Baker RJ: Pediatric Practice Sports Medicine. © 2009, McGraw­Hill, Inc., New York, NY.]
In response to the rising estrogen levels, the pituitary gland secretes follicle­stimulating hormone and luteinizing hormone, stimulating the release of a mature oocyte. The residual follicular capsule forms the corpus luteum. During the luteal phase, the corpus luteum secretes estrogen and progesterone, which maintains the integrity of the endometrium for implantation. In the absence of human chorionic gonadotropin released by a pregnancy, the corpus luteum involutes, and estrogen and progesterone levels fall. Hormonal withdrawal causes vasoconstriction in the spiral arterioles of the endometrium, resulting in endometrial sloughing and leading to menses.
CLINICAL FEATURES
HISTORY
Obtaining a focused medical history should include bleeding pattern, associated symptoms, and past medical, reproductive, and sexual history (Table
96­2). The average tampon or pad absorbs  to  mL of vaginal effluent. However, judging the amount of blood loss by usage may be unreliable because personal habits vary greatly among women. In women with heavy bleeding, there may be insufficient time for fibrinolysis, so blood clots form.
TABLE 96­2
Important Historical Elements in Uterine Bleeding
Category Details
Reproductive history Age of menarche
Menstrual history
Date of the last menstrual period
Pattern of normal and abnormal bleeding or discharge
Presence of dysmenorrhea
Sexual history Current sexual activity
Contraception
Use of barrier protection
Pregnant—yes/no?
Gravida and para
Previous abortion or recent termination
History of ectopic pregnancy
History of pelvic inflammatory disease, sexually transmitted diseases, human immunodeficiency virus, and hepatitis status
History of trauma Postcoital bleeding
Possibility of retained foreign body —
Medications, including alternative and Anticoagulants complementary medicine
NSAIDs
Ginseng
Past medical history Signs and symptoms of coagulopathy, including nosebleeds, petechiae, and ecchymoses
Endocrine disorders, including diabetes, pituitary tumors, polycystic ovary disease, hyperthyroidism, and hypothyroidism
Liver disease
Associated symptoms Urinary, GI, musculoskeletal symptoms; fever or syncope
Determine whether bleeding is acute or chronic. It is also important to elicit whether there is a family history of bleeding disorders or chronic illnesses.
Up to 20% of women with heavy bleeding have an underlying coagulation disorder, with von Willebrand’s disease being the most common. Screening criteria include heavy menstrual bleeding since menarche, postpartum hemorrhage, bleeding related to surgery or dental procedure, and two or more of the following: bruising one to two times a month, epistaxis one to two times a month, frequent gum bleeding, or family history. Medications, such as hormonal contraceptives, anticoagulants, selective serotonin reuptake inhibitors, tamoxifen, and herbal supplements

(e.g., ginseng), are also important causes of bleeding.
PHYSICAL EXAMINATION
Evaluate for hemodynamic stability on initial assessment. Significant signs of volume depletion may not be present until bleeding is profuse. A focused physical examination including pelvic is required to exclude life­threatening blood loss and need for emergent surgical intervention. Hirsutism, obesity, and galactorrhea may point toward endocrinologic causes. Petechiae, purpura, and mucosal bleeding require further hematologic investigation.
For pelvic examinations in the ED, both male and female physicians are equally advised to have a chaperone present. Inspect the perineum, vulva, urethra, and perianal region before speculum exam. Evaluate the vaginal canal and cervix for potential causes of bleeding. Bimanual exam of the uterus and adnexal structures should be performed to assess for size, masses, or tenderness.
In elderly patients, immobility and degenerative joint disease may make it difficult to place the patient in the dorsal lithotomy position. Patients may be positioned supine, with the head supported with a pillow and with knees flexed and hips externally rotated (frog­leg position). Consider using a smaller speculum with generous lubrication if there is vaginal atrophy. Abnormalities such as irregular nodules, masses, or thickened rectovaginal septum may suggest malignancy.
CAUSES OF VAGINAL BLEEDING
The causes of abnormal uterine bleeding are classified into structural and nonstructural causes, using the acronym PALM­COEIN: Polyp, Adenomyosis,

Leiomyoma, Malignancy and hyperplasia, Coagulopathy, Ovulatory dysfunction, Endometrial, Iatrogenic, and Not otherwise classified. Causes of bleeding based on age are shown in Table 96­3. The term abnormal uterine bleeding encompasses all causes of abnormal bleeding in nonpregnant women, and the most likely causes are largely determined by patient age. Because the first clinical signs of heavy menstrual bleeding (heavy uterine bleeding) are noted after the onset of menses during early adolescence, structural causes are uncommon. Anovulatory and bleeding disorders are most common during this time period (ages  to 19). Pregnancy­related complications become the most common cause of abnormal vaginal bleeding during the reproductive years. Issues regarding pregnancy are covered in Chapters , “Ectopic Pregnancy and Emergencies in the First  Weeks of Pregnancy,” and 100, “Maternal Emergencies After  Weeks of Pregnancy and in the Peripartum Period.”
TABLE 96­3
Causes of Bleeding by Age Group* Adolescent Reproductive Perimenopausal Postmenopausal
Anovulation (hypothalamic­pituitary­ovarian Pregnancy Anovulation Atrophic vaginitis (30%) immaturity)
Pregnancy Anovulation (PCOS) Uterine leiomyomas Exogenous hormone use (30%)
Exogenous hormones or OCP Exogenous hormone use or Cervical and endometrial Endometrial lesions, including cancer
OCP polyps (30%)
Coagulopathy Uterine leiomyomas Thyroid dysfunction Other tumor—vulvar, vaginal, cervical
(10%)
Pelvic infections Cervical and endometrial polyps
Thyroid dysfunction
Abbreviations: OCP = oral contraceptive pill; PCOS = polycystic ovary syndrome.
*Prepubertal bleeding is discussed in Chapter 136, “Pediatric Urologic and Gynecologic Disorders.”
Abnormal uterine bleeding as a result of local structural pathology such as polyps and fibroids is not typically seen until women reach their mid­30s.
Perimenopausal anovulatory bleeding is typically seen in the mid to late 40s. Postmenopausal bleeding is often related to atrophic vaginitis, exogenous hormones, and malignancy.
STRUCTURAL CAUSES OF VAGINAL BLEEDING
POLYPS
Endometrial and endocervical polyps are epithelial proliferations that most often are benign. Although most polyps are asymptomatic, polyps can be a cause of abnormal uterine bleeding in women older than  years. A common symptom is intermenstrual bleeding, and diagnosis is made on US or hysteroscopy.
ADENOMYOSIS
Adenomyosis is the presence of endometrial glands and stroma within the myometrium. The histopathology is often diffuse within the uterus, but localized areas of growth are called adenomyomas. Symptoms include painful, heavy periods most commonly seen in the fourth and fifth decade of life. MRI is the imaging modality of choice, but US is a good alternative. Patients with severe bleeding unresponsive to medical management often require surgical management.
LEIOMYOMAS
Uterine fibroids (also called leiomyoma or myoma) are the most common benign tumors of the pelvis in women; an estimated 25% of white women and 50% of black women have fibroids in their reproductive years. The cause is unclear, but fibroids increase with reproductive age and decrease in size during menopause. Thus, growth is thought to be dependent on genetic and hormonal factors. In some cases, fibroids may enlarge early in pregnancy and with oral contraceptive pill use. Most fibroids are asymptomatic, but up to 30% of patients with leiomyomas experience pelvic pain and abnormal bleeding. Acute pain is rare, but severe pain may be experienced with torsion or degeneration. Degeneration results from rapid growth and loss of blood supply, often seen during early pregnancy. A rare case of spontaneous fibroid rupture causing massive intra­abdominal hemorrhage has
 been reported in the literature.
Signs and symptoms of fibroids vary depending on size and location. Large fibroids may be palpated on abdominal or rectal exam. Symptoms of acute degeneration include tenderness, rebound guarding, fever, and elevated WBC count. Rapid growth at any age or growth after menopause is highly suspicious for malignant transformation. The best diagnostic test is ultrasonography, which is as sensitive as MRI.
In the ED, management is focused on treating complications associated with fibroids. Iron deficiency anemia is often long­standing and may require a blood transfusion. Other complications are rarer, but constipation, urinary retention, vaginal or intraperitoneal hemorrhage, deep vein thrombosis,
 and mesenteric thrombosis have been reported. NSAIDs are the mainstays for analgesia in the ED. Medical management with hormonal agents may be
 initiated in the ED with gynecologic consultation. Tranexamic acid can reduce menstrual blood loss from uterine fibroids. See discussion below on tranexamic acid. Surgical removal of fibroids is associated with a 25% to 30% rate of recurrence and significant bleeding complications. Uterine artery
 embolization is an effective treatment for symptomatic fibroids, resulting in decreased fibroid volume and alleviation of symptoms.
MALIGNANCY
Any malignancy of the genital tract, in particular endometrial or cervical cancer, may produce bleeding. Consider endometrial hyperplasia or
 cancer in women >45 years old or in younger women with other risk factors. The amount of bleeding does not correlate with the severity of disease. All patients with postmenopausal bleeding warrant prompt outpatient referral for US and endometrial biopsy. Elderly patients may not be able to accurately describe the location of pain or bleeding in the proximity of the bladder, uterus, or rectum. Therefore, make sure to adequately visualize the urethra, vagina, and cervix on pelvic examination.
Vaginal bleeding, especially when seen in conjunction with atrophic vaginitis, may be associated with the use of pessaries and douche solutions, which can irritate the mucosa. Cervical polyps can also cause vaginal bleeding. However, an endometrial biopsy is ultimately required to rule out other serious causes of bleeding.
NONSTRUCTURAL CAUSES OF VAGINAL BLEEDING
COAGULOPATHIES

Primary coagulation disorders account for up to 20% of acute uterine bleeding in adolescents. von Willebrand’s disease is the most common cause, but myeloproliferative disorders and immune thrombocytopenia also may be diagnosed. In adults, bleeding may result from anticoagulation agents or acquired bleeding disorders. Cirrhosis may lead to bleeding secondary to reduced capacity of the liver to metabolize estrogens.
OVULATORY DYSFUNCTION
Acute uterine bleeding secondary to anovulation is seen in 10% to 15% of gynecologic patients. Signs include irregular and/or heavy menstruation.
Ovulatory dysfunction is common in perimenarchal and perimenopausal women, as well as in patients with endocrine disorders, polycystic ovary syndrome, exogenous hormone use, and liver or renal disease.
Anovulatory uterine bleeding in adolescence is due to the immature hypothalamic­pituitary­ovarian axis. In this situation, the amount of bleeding is usually minimal and painless. Severe anemia from heavy menstrual bleeding in early adolescence should prompt evaluation for bleeding disorders (e.g., von Willebrand’s disease, factor VIII deficiency). Table 96­4 outlines the medical management of acute uterine bleeding from ovulatory dysfunction in the ED.
TABLE 96­4
Treatment of Massive or Heavy Vaginal Bleeding
Massive or Life­Threatening Bleeding
General management Fluid and Identify and treat Exclude pregnancy, blood coagulopathies foreign body, laceration resuscitation
Initial Dose Dose Schedule Comments Contraindications
Conjugated equine estrogen  Every 4–6 hours until Emergency GYN If VTE, thrombophilia, vascular disease, or
(Premarin) milligrams IV bleeding diminishes/stops consultation; provide malignancy, do not give estrogens and antiemetics get emergency GYN consultation
Tranexamic acid (FDA .0–1.3 Can continue PO  times a Emergency GYN If VTE, thrombophilia, vascular disease, or approved for menorrhagia) grams IV day; effective in about  h consultation malignancy, do not give tranexamic acid and get emergency GYN consultation
Hemodynamically Stable or Ovulatory Dysfunction
Dose Dose Schedule Comments Contraindications
Combined OCP (i.e., Sprintec®): Monophasic Three times a day for  days Provide antiemetics; Smokers >35 years, hypertension,
### .25 milligram norgestimate combined Or bleeding pregnancy, VTE, cerebrovascular and .035 milligram ethinyl OCP that Twice daily for  days, then diminishes/stops in ~3 accident, breast cancer, liver disease, estradiol; Yaz®, Alesse®, contains ≤35 once daily until pack is days thromboembolic disorders, diabetes with
Seasonale®, other options micrograms finished vascular disease, heart disease, major with a bit less estrogen) of ethinyl surgery with immobilization estradiol
Medroxyprogesterone acetate   times a day for  days Bleeding Liver disease; breast, uterine, or ovarian milligrams Or diminishes/stops in ~3 cancer; inconsistent reports of deep
PO Once daily for  days days; for patients with venous thrombosis risk contraindications to estrogen; primarily for older or perimenopausal patients
NSAIDs Naproxen or Naproxen 500 milligrams Consider for younger Use NSAIDS with caution in patients with ibuprofen PO twice a day; ibuprofen 400 patients with relatively history of GI bleed, bleeding disorders, or or milligrams every  hours; stable bleeding and renal disease mefenamic mefenamic acid, 500 those who cannot acid milligrams  times daily for 4– receive hormonal
 days or until bleeding stops therapy
Abbreviations: FDA = U.S. Food and Drug Administration; GYN = gynecology; OCP = oral contraceptive pill; VTE = venous thromboembolism.
Anovulatory bleeding in the reproductive­age female may be regular in timing, but more often is irregular because of fluctuating estrogen levels. Characteristically, anovulatory cycles present as prolonged amenorrhea with periodic heavy menstrual bleeding. This pattern of bleeding increases the risk of endometrial hyperplasia and adenocarcinoma.
Hypothyroidism may be associated with heavy uterine bleeding or intermenstrual bleeding from ovulatory dysfunction, with an estimated incidence
 of .3% to .5%. Eating disorders, excessive weight loss, stress, and exercise can also cause abnormal uterine bleeding. Consider obtaining thyroidstimulating hormone levels in women with uterine bleeding of undetermined origin or in those with thyroid nodule or goiter.
ENDOMETRIAL CAUSES
Abnormal uterine bleeding that occurs in the context of normal ovulation and with a structurally normal endometrial cavity is attributed to endometrial causes. Normal ovulation is based on a history of regular menstrual periods. Bleeding may be preceded by breast tenderness, abdominal bloating, and pelvic pain. The diagnosis is made when patients have heavy menstrual bleeding with no other identifiable abnormalities.
Ovulatory dysfunction bleeding is generally treated with oral contraceptives, NSAIDs, or progestins (Table 96­4). NSAIDs reduce prostaglandin levels and can reduce menstrual bleeding. Endometrial ablation may be useful for those who do not respond to medical therapy; hysterectomy is reserved for those who fail medical management and have excessive blood loss.
IATROGENIC CAUSES
Oral contraceptive pill use remains the most common cause of intermenstrual bleeding. Additionally, medications (e.g., antiseizure medications) that increase the P450 system of the liver may increase the metabolism of endogenous hormonal glucocorticoids and may cause withdrawal bleeding.
Hormone replacement therapy, which can relieve symptoms associated with menopause, may also be associated with vaginal bleeding. Hormone replacement therapy for symptom control has been called into question, as there is no clear benefit for primary and secondary prevention of
,13 cardiovascular disease, and excessive risk of endometrial, breast, and colorectal cancer and thromboembolism has been noted.
Forty percent of women receiving continuous oral contraceptive pill therapy will experience abnormal bleeding in the initial  to  months. Bleeding after  months of continuous combined hormone replacement therapy, unexpected bleeding with cyclic hormone replacement therapy, or bleeding that recurs after amenorrhea is established should prompt referral for evaluation. There are no acceptable criteria for “abnormal bleeding” on these therapies. The most common etiologies for bleeding while on hormone replacement therapy are poor compliance, poor GI absorption, drug interactions, failure to synchronize therapy with endogenous ovarian activity, and coagulation disorders.
OTHER CAUSES OF VAGINAL BLEEDING
Pelvic inflammatory disease or infections that cause endometritis can result in abnormal vaginal bleeding. Cervical erosions, polyps, and cervicitis may cause bleeding from the cervix. Vaginal infections, trauma, and foreign bodies may also present with abnormal bleeding. Emergency therapy should be directed at investigating and treating obvious causes of bleeding. For further details, see Chapters 103, “Pelvic Inflammatory Disease,” and 102,
“Vulvovaginitis.”
LABORATORY EVALUATION AND IMAGING
Obtain a pregnancy test in women of childbearing age (except those with hysterectomy) to rule out pregnancy as a cause of bleeding. A CBC identifies anemia. Consider thyroid studies if they have not been recently obtained. Obtain coagulation studies only when indicated by history or physical examination. In individuals with suspected endocrine disorders, determination of prolactin levels may be helpful, but the levels may not be available for ED evaluation.
Ultrasonography is the first­line imaging modality for gynecologic conditions such as vaginal bleeding, adnexal or uterine masses, or pelvic pain. US can determine uterine size and endometrial characteristics and can identify the presence of leiomyoma, ovarian cysts, hydrosalpinx, pelvic adhesions, tubo­ovarian abscesses, endometriosis, and tumors. Transvaginal ultrasonography further delineates ovarian cysts and fluid in the cul­de­sac.
Depending on the degree of pain and findings on physical examination, US can be done on an emergency basis or deferred for outpatient evaluation.
CT is used primarily in the ED for the evaluation of acute abdominal or pelvic pain (see Chapter , “Abdominal and Pelvic Pain in the Nonpregnant
Female”). MRI is used primarily for cancer staging and is rarely indicated during ED evaluation.
TREATMENT
MASSIVE UTERINE BLEEDING
Women who are hemodynamically unstable need immediate resuscitation and emergent gynecologic consultation (Table 96­4). Do not attempt vaginal packing, because it increases the risk of infection and may hide ongoing blood loss. In addition to fluid resuscitation, blood transfusion, and identification and correction of underlying coagulopathies, assess for other potential causes of bleeding including trauma, bleeding dyscrasia, infection, and retained foreign bodies. The options for management of acute hemorrhage include hormonal, surgical, and hemostatic interventions.

Hormonal agents are first­line medical management for massive uterine bleeding in patients without an underlying bleeding disorder. Short­term hormonal treatment allows the endometrium to stabilize and slows acute bleeding. For severe hemorrhage, give conjugated estrogen (Premarin®) at a dose of  milligrams IV every  to  hours until bleeding stops, with further treatment and disposition determined by the gynecologist. In women with a history of blood clot or cardiovascular disease, high­dose estrogen therapy is contraindicated, so obtain emergency gynecologic consultation for other treatment options. Obtain transvaginal US to identify anatomic causes of bleeding.
Tranexamic acid, a lysine derivative that prevents fibrin degradation, has been primarily used for intraoperative gynecologic and obstetric
,16 hemorrhage. Obtain gynecologic consultation if IV administration is considered, especially to discuss the risks and benefits. Clinical studies on the effectiveness of tranexamic acid have excluded patients with the potential for thrombosis. However, the U.S. Food and Drug Administration has approved PO tranexamic acid for treatment of ovulatory abnormal uterine bleeding. A recent review showed no thromboembolic events with the use
 of PO regimens. The most commonly recommended and studied treatment regimen is PO tranexamic acid  to .3 grams every  to  hours for  days.
HEAVY OR ANOVULATORY MENSTRUAL BLEEDING
The most common medication treatment options for heavy menstrual bleeding (Table 96­4) include hormonal (i.e., combined contraceptives, progestin­only) and nonhormonal therapies (i.e., NSAIDs). Common side effects include nausea and vomiting. Simplified ED regimens for combined oral contraceptive pills and progestin­only pills are outlined in Table 96­4. The median time to stop bleeding for either regimen (combined oral contraceptive pill or progestin­only regimen) is  days. However, multiple different hormonal doses and schedules are also effective. In general, for young healthy women in whom bleeding is often related to anovulation and there is no concern for endometrial pathology, oral contraceptive pills are favored. For older patients or obese/perimenopausal patients in whom there could be concern for endometrial pathology, progestin­only therapy is preferred.
Oral contraceptive pills have long been an excellent choice for adolescents and women requiring contraception. Heavy menstrual bleeding is decreased by 50%, with a similar reduction in the degree of pain associated with bleeding. Alternative therapy at gynecologic follow­up can consist of a levonorgestrel intrauterine device (71% to 95% reduction), which may be superior to combined oral contraceptive pills (35% to 69% reduction) and

NSAIDs (10% to 52% reduction).

NSAIDs are effective in reducing pain and blood loss in 20% to 50% of women with abnormal uterine bleeding secondary to ovulatory dysfunction.
NSAIDs should be started on the first day of the period and continued until bleeding stops and pain resolves.
All NSAIDs inhibit cyclooxygenase in the arachidonic acid cascade. Prostaglandin inhibitors alter the ratio of prostaglandin F α, which causes
 vasoconstriction, to prostaglandin E , which causes vasodilation. NSAIDs also increase levels of thromboxane A , which causes vasoconstriction and
  increases platelet aggregation. NSAIDs have a mild side effect profile and are inexpensive. Treatment choices include mefenamic acid, 500 milligrams three times a day PO, naproxen, 500 milligrams twice per day PO, and ibuprofen, 400 milligrams every  hours. Any of these may be administered to
 reduce bleeding and pain associated with use of an intrauterine device. NSAIDs are less useful in patients with uterine leiomyomas.
For women with contraindications to estrogen, progestin­only therapy is an alternative therapy. Progestin works by decreasing the number of available estrogen receptors and stabilizing the endometrium. Progestin is used when there is concern for underlying endometrial pathology or hyperplasia. The American College of Obstetricians and Gynecologists recommends medroxyprogesterone acetate,  milligrams three times per day for  days. Another common regimen is medroxyprogesterone acetate,  milligrams daily PO for  days.
Gonadotropin­releasing hormone agonists may be used to induce amenorrhea, but women on this therapy become menopausal. Other drawbacks include medication expense and bone loss when used for >6 months. Oral tranexamic acid, a fibrinolytic, reduces vaginal bleeding with minimal side
 effects. An improved quality of life in patients using tranexamic acid when compared with hormone therapy and NSAIDs has been reported.
Nonmedical invasive management strategies may be required if medical treatment fails. These include hysteroscopy, endometrial ablation, or myomectomy. Hysteroscopy can be used to sample the endometrium and resect polyps and myoma. Endometrial ablation may be performed in
 patients who do not desire fertility, have no pathologic diagnosis, and for whom medical therapy has failed. Myomectomy may be useful in patients with symptomatic fibroids. Hysterectomy is reserved for selected patient populations. Uterine artery embolization is an effective nonsurgical option for
 the management of bleeding caused by fibroids.
DISPOSITION AND FOLLOW­UP
Stable patients can be discharged home with arrangements for prompt follow­up.
The need for surgical management is based on clinical stability. If medical management fails or if there is a contraindication (e.g., thromboembolic disease), then surgical management is the next step. Surgical options are directed by suspected etiology and include dilatation and curettage, hysteroscopy, endometrial balloon tamponade, and uterine artery embolization. Hysterectomy is used as a last resort in patients with acute lifethreatening bleeding unresponsive to other treatment measures.
Provide referral for endometrial biopsy for patients at risk for endometrial cancer and all women >45 years old. Perimenopausal bleeding is associated with malignancy in 10% of women. Risk factors include obesity, nulliparity, history of anovulation, tamoxifen use, infertility, and a family history of endometrial or colon cancer. Other diagnostic procedures performed at follow­up may include sonohysterography, hysterosalpingography, and
 hysteroscopy with directed biopsy and dilatation and curettage.
SPECIAL CONSIDERATIONS
ANTICOAGULANTS
Anticoagulation for deep vein thrombosis, pulmonary embolism, artificial heart valves, atrial fibrillation, and other conditions may be a cause of
 abnormal uterine bleeding. More than 70% of these women report changes in their periods, with more than half reporting heavy menstrual bleeding.
The management of women with active or prior thrombotic disease is challenging because first­line treatments such as combined contraceptives and tranexamic acid are contraindicated in this population. Progestin­only may be used with caution and gynecologic consultation due to potential increased risk of thrombosis. Risks and benefits must be evaluated for reversal of anticoagulation.
INHERITED BLEEDING DISORDERS
Abnormal uterine bleeding is the most common symptom of inherited bleeding disorders in women. Of historical interest, the first described case of
 von Willebrand’s disease was in a 13­year­old who died as a result of uncontrollable uterine bleeding. Abnormal uterine bleeding is present in the majority of women with von Willebrand’s disease or factor XI deficiency and in carriers of hemophilia.
A multidisciplinary approach is recommended. Initial treatment options are similar to those without bleeding disorder, except the use of NSAIDs is contraindicated. Hormonal agents raise factor VIII and von Willebrand factor levels and are an effective and popular form of therapy. If standard treatment fails, consider desmopressin acetate to stimulate endogenous release of factor VIII and von Willebrand factor. Patients must be typed and screened for antibodies before administering desmopressin acetate because it may induce thrombocytopenia in certain subgroups. Antifibrinolytics,
,27 such as tranexamic acid and recombinant von Willebrand factor, are other treatment options that have shown reduction in bleeding.
POLYCYSTIC OVARY SYNDROME
Polycystic ovary syndrome, one of the most common endocrine disorders, is the association of hyperandrogenism and anovulation without underlying
 disease of the adrenal or pituitary glands. A triad of obesity, hirsutism, and oligomenorrhea is classically described, although obesity is not universally seen. When menses occurs, it is heavy and prolonged. The syndrome is further characterized by acne, androgen­dependent alopecia, elevated serum concentrations of androgens, hyperinsulinemia, and hypersecretion of luteinizing hormone with a normal or low follicle­stimulating hormone level. Typical ovarian morphology, which may be seen by US, is not necessary for the diagnosis and may, in fact, represent a response of the ovary to chronic anovulation. The differential diagnosis includes hyperprolactinemia, acromegaly, congenital adrenal hyperplasia, and androgensecreting tumors of the ovary or adrenal gland. Management of menorrhagia in women who do not desire fertility includes low­dose oral contraceptives or cyclic progestin administration.
STRESS, ILLNESS, AND RAPID WEIGHT CHANGE
Periods of physical or psychological stress, illness, malnutrition, rapid weight gain or loss, and intense physical regimens affect the hypothalamus and disrupt the normal pattern of gonadotropin release. This usually causes amenorrhea but may result in irregular, heavy bleeding. In obese women, menorrhagia may be a result of increased circulating levels of estrogen from peripheral conversion of androstenedione to estrone in fatty tissue.
Patients with liver and renal disease may also develop irregular bleeding.


