## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 36: Local and Regional Anesthesia
Michael A. Gibbs; Teresa Wu
INTRODUCTION
Local anesthetics (Tables 36­1 and 36­2) are used to reduce pain from acute injury or procedures performed in the ED.1 The most common routes of administration include topical, subdermal, and infiltrative around peripheral nerves (regional anesthesia).2,3
TABLE 36­1
Topical Anesthetic Agents
Active Time to
Agent Application
Ingredients Effectiveness
Intact Dermis
Eutectic mixture of local anesthetic agents Lidocaine .5% Apply thick layer, 5–10 grams (maximum  grams), to area to be anesthetized; cover with semiocclusive  min
(EMLA®) Prilocaine .5% dressing.
Tetracaine (amethocaine) gel (Ametop®) Tetracaine 4% Apply  gram (1 tube) to area to be anesthetized; cover with occlusive dressing.  min
Liposome­encapsulated tetracaine Tetracaine 5% Apply .5 gram to area to be anesthetized.  min
Liposome­encapsulated lidocaine (LMX4® Lidocaine 4% or Apply .5 grams to area to be anesthetized. 30–60 min and LMX5®) 5%
Open Dermis
Lidocaine, epinephrine, tetracaine (LET) Lidocaine 4% Apply 3–5 mL to gauze pad placed into wound; cover with semiocclusive dressing. 20–30 min
Epinephrine
.1%
Tetracaine .5%
Mucosa
Topical anesthetic gel (ZAP®) Benzocaine 18% Apply .2 mL (1 dispenser application) with cotton swab to area to be anesthetized.  min
Tetracaine 2%
Benzocaine spray (Hurricaine®) Benzocaine 20% Apply  spray to area to be anesthetized; volume delivered is highly dependent on canister orientation 15–30 s and residual volume.
Viscous lidocaine Lidocaine 2% Apply  mL to area (e.g., topical anesthesia before upper airway procedures). 2–5 min
TABLE 36­2
Local Anesthetic Agents
Lipid Protein Duration† without Onset‡ Maximum Dose milligrams/kg without Concentration Concentration (regional
Agent
Solubility* Binding epinephrine (min) (min) epinephrine (with epinephrine) (subdermal use) anesthesia use)
Amides
Bupivacaine High High 120–240 2–10  (5) .50%–0.75% .25%–0.50%
Lidocaine Medium Medium 30–120 <1  (7) .5%–1.0% 1%–2%
Levobupivacaine High High >1000 10–20  .25% .50%

Mepivacaine Low Medium 30–120 3–20  .5%–1.0% 1%–2%
Chapter 36: Local and Regional Anesthesia, Michael A. Gibbs; Teresa Wu 
. Terms of Use * Privacy Policy * Notice * Accessibility
Prilocaine Medium Medium 30–120 5–6  4% NA
Ropivacaine Medium High 120–350 10–45  .5% .5%
Esters
Procaine Low Low 15–90   .25%–0.5% .5%–2.0%
Chloroprocaine Low Low 30–60 5–6  1%–2% 1%–2%
Tetracaine High High 120–240  .5 NA .2%–0.3%
(amethocaine)
Alternatives for patients with reactions to amides and esters
Diphenhydramine§  1% NA
Benzyl alcohol with 15–25 .9% NA epinephrine¶
Abbreviation: NA = not applicable.
*Lipid solubility determines the potency of the anesthetic, with the more lipophilic anesthetics having enhanced potency compared with less lipophilic agents.
†The more an anesthetic is bound to proteins, generally, the longer the duration of action.
‡The onset of action of an anesthetic is determined by the total dose of anesthetic given and the pH at which 50% of the drug is ionized and 50% of the drug is nonionized.
§Diphenhydramine 1% or  milligrams/mL (created by mixing  parts normal saline and  part 5% diphenhydramine).
¶Benzyl alcohol .9% solution (created by mixing .2 mL of epinephrine 1:1000 with a 20­mL vial of normal saline containing benzyl alcohol .9%).
LOCAL ANESTHESIA
PHARMACOLOGY
Local anesthetics are divided into two classes—esters and amides—that work by reversibly blocking sodium channels and inhibiting the propagation of nerve impulses.4,5 Sodium channel blockade first affects the smaller nerve fibers, causing a reduction in pain and temperature sensation, followed by loss of touch, deep pressure sensation, and, finally, motor function. Esters are hydrolyzed by cholinesterase enzymes in plasma, whereas amides are metabolized by hepatic microsomal enzymes. Onset of action, duration of anesthesia, and potential for systemic toxicity are the three primary factors in selecting a local anesthetic.
The onset of action of a local anesthetic is dependent on the pK (the pH at which 50% of the drug is ionized and 50% of the drug is nonionized). If the ambient pH is higher than the pK of the a a agent, a greater percentage of the drug will be in the nonionized form, which diffuses more rapidly across lipid membranes with a more rapid onset of action. Thus, drugs with a lower pK, a such as mepivacaine, lidocaine, and prilocaine, have a more rapid onset of action. The pH of available local anesthetic solutions is acidic, varying from .3 to .8, depending on the agent, additives, and buffers, accounting for some of the initial pain upon local injection. The duration of action of the local anesthetics is a function of receptor affinity. Agents with a higher receptor affinity as measured by protein binging (e.g., bupivacaine or tetracaine) have a longer duration of action than those with lower receptor affinity (e.g., lidocaine, prilocaine).6 Selecting agents with a longer duration of action provides superior results for long procedures or for those in which postprocedure analgesia is desired. Longer­acting agents also offer continued analgesia when providers are pulled away from the procedure. The downside of long­acting agents is the greater risk of systemic toxicity.7 Levobupivacaine8 and ropivacaine9 appear to have a lower risk of systemic toxicity than bupivacaine.
LOCAL ANESTHETIC SYSTEMIC TOXICITY
Local anesthetic systemic toxicity occurs from dose­related clinical progression of sodium channel blockade in nontarget tissues, primarily the brain and heart.10,11 Toxicity can range from subtle neurologic symptoms to refractory seizures and, ultimately, cardiovascular collapse (Figure 36­1).12­14 The risk of systemic toxicity can be reduced by adherence to dose limitation and techniques to minimize systemic absorption.15­18 Seizures due to neurologic toxicity should be treated with benzodiazepines.19,20 Patients with cardiac depression or arrest should be treated with intravenous 20% lipid emulsion, especially if systemic toxicity is due to bupivacaine with its high lipid solubility.19­28 Guidelines recommend an initial dose of 20% lipid emulsion .5 mL/kg infused over  minute followed by an infusion at .25 mL/kg based on lean body mass continued for  minutes after hemodynamic stability occurs. If hemodynamic instability persists, repeat boluses can be administered with the recommended maximum dose of approximately  mL/kg over the initial  minutes.19,20 Cardiac arrest is treated with standard resuscitative measures with the exception that small doses of epinephrine,  to 100 micrograms, are preferred instead of the standard adult dose of  milligram, and vasopressin (for use as a vasopressor) and lidocaine (for use as an antiarrhythmic) should be avoided.20
FIGURE 36­1. Adverse effects of local anesthetics. Plasma concentration of local anesthetics versus toxic effects.
Prilocaine and benzocaine can cause the oxidation of the ferrous iron in normal hemoglobin to the ferric form creating methemoglobin, which results in cyanosis when methemoglobin concentrations exceed .5 grams/dL (see Chapter 207, “Dyshemoglobinemias”).
GENERAL PRINCIPLES
When using any local anesthetic, calculate the volume and concentration of drug used, especially when treating smaller patients or tending to large wounds (Table 36­2). Aspiration before injection helps to avoid inadvertent deposit of local anesthetic in a vein or artery. When the use of a large quantity of local anesthetic seems unavoidable, procedural sedation or alternative regional blocking techniques and supplementation with systemic analgesics or anxiolytics should be considered (see Chapter , “Procedural Sedation and Analgesia in Adults”).
The addition of epinephrine to the injected local anesthetic solution increases the duration of anesthesia, helps to control wound bleeding, and slows the systemic absorption.29 The use of local anesthetic with epinephrine is safe in end­arterial fields (e.g., fingers, toes) in healthy patients,30­35 but probably should be avoided in suspected digital vascular injury; in patients with vascular disease, such as Raynaud’s or Berger’s disease; or in other conditions in which end­arterial vascular supply is problematic. An alternative to epinephrine is clonidine (U.S. Food and
Drug Administration unlabeled use), an α­adrenergic agonist that can also be used in combination with a local anesthetic to prolong the duration of anesthesia.36­38 A dose of .5 microgram/kg of clonidine (maximal dose, 150 micrograms) can be mixed with the anesthetic to prolong the duration of anesthesia by >50%. Do not exceed a maximum dose of 150 micrograms because sedation, hypotension, and bradycardia can result.37,38
The addition of sodium bicarbonate to local anesthetics reduces the pain of injection and slightly shortens the onset of action by raising tissue pH.1,39­41Lidocaine can be buffered by adding  mL of sodium bicarbonate .4% (1 mEq/mL) to  mL of 1% lidocaine. Bupivacaine can be buffered by adding  mL of sodium bicarbonate .4% (1 mEq/mL) to  mL of bupivacaine
.25%. The addition of bicarbonate can cause precipitation of the anesthetic agent (most prominently bupivacaine) and accelerate degradation of epinephrine, but the clinical effectiveness of buffered anesthetic solutions is maintained for at least  week after preparation.
Adverse reactions to local anesthetics are most often local reactions to preservatives or to the epinephrine in the solution, and true allergic reactions are extremely rare.42,43 In patients with true allergies to local anesthetics, two nontraditional agents can be used for wound repair via local injection—diphenhydramine and benzyl alcohol (Table 36­2).44­46
Local anesthetics can be administered topically, intradermally, subdermally, or infiltrated near peripheral nerves. Considerations in wound management include patient factors (age, anticipated pain tolerance, comorbidities), wound factors (location, depth, presence or absence of contamination, and/or neurovascular injury), and technical factors (time required, clinician experience).
TOPICAL ANESTHESIA
Topical anesthetics are used in three major situations: on intact skin before dermal instrumentation, applied to intact mucosa, and placed on open skin for pain control or before wound repair.47­49 Topical anesthetics are probably as effective as local anesthetic infiltration for suturing of many dermal lacerations, although the comparison studies are of modest quality.50
An alkaline (pH approximately 9) cream mixture of lidocaine .5% and prilocaine .5% (eutectic mixture of local anesthetics [EMLA®]) was the first topical anesthetic formulated to penetrate intact skin. When applied for at least  minutes under a semiocclusive dressing before dermal instrumentation, this lidocaine/prilocaine mixture is as efficacious as the infiltration of local anesthetic and is ideal for venous catheter insertion and lumbar puncture. EMLA® is approved for application to intact normal skin and genital mucous membranes. Liposome­encapsulated tetracaine, liposome­encapsulated lidocaine, and tetracaine gel have all been compared to the lidocaine/prilocaine mixture and found to be equally efficacious (Table 36­1).51­55
A mixture of lidocaine, epinephrine, and tetracaine acts as a topical anesthetic when used on open dermis.56 This mixture is used in a variety of liquid and gel formulations that are usually compounded by the hospital pharmacy in accordance with the concentration preferences of local clinicians; a common version is 4% lidocaine, .1% epinephrine, and .5% tetracaine prepared for use in 3­ to 5­mL aliquots.
INTRADERMAL AND SUBDERMAL ANESTHESIA
Intradermal injection produces a visible wheal, whereas subdermal injection does not. Intradermal injection produces more immediate pain upon injection due to stretching of the compact dermal structure, but can enhance the anesthetic effect by applying pressure to and numbing the cutaneous pain sensors. Intradermal injection raises the skin surface and is useful when shaving off a cutaneous lesion. Subdermal injections have a slower onset of action, are less painful, and are the most commonly used method of achieving local anesthesia in the ED and for office­based surgery.1,57 Local anesthetics may be delivered directly into the subdermal space in most clean lacerations or as a field block for contaminated wounds.
In addition to modifying the injected solution, a variety of techniques are used to reduce the pain of needle puncture and local anesthetic injection39­41,58: application of a topical anesthetic prior to injection,59,60 warming the local anesthetic agent,61­63 stretching the skin at the puncture site, vibrating the skin adjacent to the area,64,65 talking during the process to distract the patient, use of a small­bore needle (27 to  gauge),39,66 small pulse or slow injection,39,67 inserting the needle through enlarged pores or hair follicles, inserting the needle perpendicular to skin surface,68 inserting the needle with bevel­up position,69 or numbing the skin with an aerosol refrigerant.70­74
REGIONAL ANESTHESIA
Regional anesthesia is a technique that infiltrates local anesthetic agents adjacent to peripheral nerves (“nerve blocks”) and is typically used for complicated lacerations, abscesses, fractures, debridement, and dislocations.75­77 Providing adequate anesthesia quells patient anxiety, provides greater patient satisfaction, and increases the likelihood of an optimal result when treating complex injuries. With careful technique, serious complications from peripheral nerve blocks are uncommon.78­80 Assess and document distal neurovascular status before application of a regional nerve block to prevent masking a primary traumatic neurovascular injury. Distal vascular function is assessed by noting skin color and temperature, measuring capillary refill time, and palpating pulses. Distal neurologic function is assessed by noting cutaneous sensation (pain, touch) and motor function (active movement, strength). For digital injuries, assess digital nerves by determining two­point discrimination on the volar pad before anesthetic injection. Normal two­point discrimination is <6 mm at the fingertips and is often <2 mm.
Compare the injured digit with the contralateral normal digit.
Regional anesthesia for laceration repair eliminates wound distortion caused by large­volume subdermal injection. Regional anesthesia on the extremities provides superior pain control when compared with subdermal infiltration of anesthetic.75 Topical anesthetic before peripheral nerve blocks can minimize the pain associated with the block.51­55,59,60
When selecting a local anesthetic for regional anesthesia, consider the onset of clinical effects, duration of analgesia, and risk of toxicity.75 Although lidocaine continues to be the most popular agent, bupivacaine, levobupivacaine, and ropivacaine offer a longer duration of action, with levobupivacaine and ropivacaine being significantly less cardiotoxic.6,8,9 Peripheral nerve blocks require time to achieve optimal analgesia, approximately  to  minutes for lidocaine and  to  minutes for bupivacaine. Pain and temperature sensation are affected first, followed by loss of touch, deep pressure, and then motor function. Intraneural injection of anesthetic causes significant pain.81 Thus, if excessive pain upon injection is noted, withdraw the needle a few millimeters, and after pain abates, resume the injection.
The regional nerve blocks commonly performed by emergency physicians often use the “landmark” technique to identify the site of local anesthetic injection.75 The major disadvantage of the landmark approach is anatomic variation. Large volumes of anesthetic are typically administered in case the needle tip is not close enough to the desired nerve. There are currently two devices that are commonly used to help localize and direct the needle and to maximize the rate of successful anesthesia: a peripheral nerve stimulator using electrically insulated needles and
US guidance to localize the nerve.82­87 US guidance shortens the block performance time, reduces the number of needle passes, minimizes risk for vascular injury, and enables blocks to be performed using lower anesthetic doses.88­91
During a US­guided nerve block, the goal is to visualize the needle tip as it is being directed toward the target nerve.87 Using a high­frequency linear array transducer, the nerve will appear as a white honeycomb structure in the short axis and a hyperechoic, white linear array of fibers in the long axis (Figure 36­2A). The needle can be visualized as a hyperechoic, bright white structure in either the short­axis or long­axis approach (Figure 36­2B). It is often helpful to inject anesthetic through the needle as it is slowly being advanced toward the target nerve. This hydrodissection of the adjacent tissues and infiltration of fluid allow better visualization of the needle tip and improved pain control. Once the needle is in close proximity to the nerve, US can be used guide injection of anesthetic around the nerve.
FIGURE 36­2. A. White, hyperechoic, honeycomb appearance of a nerve in cross­section on US (arrow). [Image used with permission of Teresa Wu, MD.] B. US visualization of the bright white, hyperechoic needle approaching the target nerve via long­axis approach. [Image used with permission of Teresa Wu, MD.]
DIGITAL BLOCKS
DIGITAL NERVE BLOCK
Purpose
A digital nerve block provides anesthesia to the entire digit and is an excellent block when tending to lacerations of the fingers or toes, drainage of paronychia, finger or toenail removal or repair, and reduction of fractured or dislocated fingers or toes.92 Use of topical anesthesia before instrumentation can quell anxiety about the procedure and minimize pain. Assess distal capillary refill and two­point discrimination (normal <6 mm) on the volar pad of a finger before the block. There is less pain with injection using lidocaine 1% with epinephrine compared to bupivacaine .5% for digital blocks, but the duration of anesthesia is only about half as long.93 (See Video: Digital Nerve Block.)
Video 36­1: Digital Nerve Block
Used with permission from Aaron Hexdall; Jorma Mueller and Moira Davenport, Bellevue Hospital Center, New York.
Play Video
Patient Positioning and Anatomy
The hand and wrist are placed in a prone (palm down) position. The common digital nerves are derived from the median and ulnar nerves. In the distal palm, the common digital nerve divides into paired palmar branches that travel on both sides of the flexor tendon sheath and innervate the lateral and palmar aspect of each digit. The dorsal digital nerves are smaller, derived from the radial and ulnar nerves, and travel on the dorsal lateral aspect of each finger to provide sensation to the back of the finger.
Technique
Insert the needle on the dorsal surface of the proximal phalanx, advance toward the volar surface staying tangential to the phalanx, aspirate to ensure no inadvertent vascular puncture has occurred, deposit  mL of anesthetic solution, and inject an additional  mL while withdrawing the needle back to the skin surface (Figure 36­3). Reinsert the needle in the same location, but direct it across the dorsum of the digit to the other side, and inject a 1­mL band of anesthetic solution into the subcutaneous space across the dorsum of the digit. Repeat the initial injection process on the other side of the digit.
FIGURE 36­3. Digital nerve block. Anesthetic placed as shown blocks both the dorsal (a) and palmar (b) digital nerves, ensuring circumferential anesthesia of the finger. By using the sequence shown, the prior injection provides relief from the injection to follow. [Illustration used with permission of Timothy Sweeney, MD.]
The digital nerves can also be blocked at their bifurcation adjacent to the metacarpal heads. This approach (metacarpal block) is particularly useful for long and ring finger anesthesia.
TRANSTHECAL OR FLEXOR TENDON SHEATH DIGITAL NERVE BLOCK
Purpose
A transthecal or flexor tendon sheath digital nerve block provides anesthesia to the entire digit by using the flexor tendon sheath to guide anesthetic to the underlying digital nerves.94,95 This procedure can be performed in addition or as an alternative to a digital nerve block. However, a flexor tendon sheath block may not fully anesthetize the distal fingertip.
Patient Positioning and Anatomy
The hand and wrist are placed in a supine (palm up) position. The flexor tendon sheath surrounds the flexor tendon on the palmar side of the digit.
Technique
Identify the distal palmar crease on the palmar aspect of the hand. Have the patient flex the finger against resistance to improve visualization of the flexor tendon. Insert the needle at the distal palmar crease directed distally at a 45­degree angle to the palmar plane with the tip pointed distally (Figure 36­4).
FIGURE 36­4. Transthecal (flexor tendon sheath) digital nerve block. The point of injection is in the middle of the flexor tendon sheath at the level of the distal palmar crease. A 25­gauge needle is advanced at  degrees, with tip directed distally until it enters the flexor tendon sheath (shown in blue) or until bone is encountered. When the needle is properly placed within the flexor tendon sheath, the anesthetic solution is injected. Diffusion out of the tendon sheath blocks adjacent palmar digital nerves. [Illustration used with permission of Timothy Sweeney, MD.]
Advance the needle until a “pop” is felt, indicating penetration of the flexor tendon sheath. Inject  to  mL of anesthetic solution. If bone is struck before the “pop” is felt, withdraw the needle
 to  mm and inject the solution.
A modification of the transthecal approach is to inject into the flexor tendon sheath at the base of the digit in the metacarpal crease96­98 or into the midportion of the proximal phalanx.99
HAND AND WRIST BLOCKS
The median, radial, and ulnar nerves supply the sensory innervation to the hand and can be used in part or in combination to provide anesthesia for wound repair or fracture/dislocation reductions (Figures 36­5 and 36­6). (See Video: Forearm Nerve Blocks.)
FIGURE 36­5. Hand innervation, dorsal view. Dorsal hand distribution of ulnar nerve (yellow), radial nerve (red), and median nerve (blue).
FIGURE 36­6. Hand innervation, palmar view. Palmar hand distribution of ulnar nerve (yellow), radial nerve (red), and median nerve (blue).
Video 36­2: Forearm Nerve Blocks
Used with permission from Sandra L. Werner and Jessica Resnick, Department of Emergency Medicine, MetroHealth Medical Center, Case Western Reserve University School of Medicine, Ohio.
Play Video
MEDIAN NERVE BLOCK
Purpose
A median nerve block provides anesthesia to the thumb, index, long, and half of the ring finger distal to the proximal interphalangeal joint, but not the dorsum of the thumb (Figures 36­5 and
36­6).
Patient Positioning and Anatomy
The hand and wrist are placed in a supine (palm up) position. The median nerve traverses between the flexor carpi radialis and the palmaris longus tendon at the proximal wrist crease. With the hand and wrist in a supine position, the flexor carpi radialis is lateral (radial direction) and the palmaris longus is medial (ulnar direction) to the nerve. When the patient makes a fist and flexes the wrist, the palmaris longus tendon is usually the more prominent of the two tendons (Figure 36­7, top left).
FIGURE 36­7. Median and radial nerve block. Top left: Technique for identification of the palmaris longus tendon (p.l.) through wrist flexion using finger and thumb opposition. Right: The median nerve
(m.) is blocked by inserting the needle between the palmaris longus and flexor carpi radialis (f.c.r.) tendons. The radial nerve (r.) block begins with an injection over the lateral aspect of the radial styloid. Lower left: The radial nerve block continues dorsally as a subcutaneous field block extending to the dorsal midwrist. [Illustration used with permission of Timothy Sweeney,
MD.]
Technique
Raise a wheal of anesthetic in the subcutaneous space between the palmaris longus and flexor carpi radialis at the level of the proximal palmar crease (Figure 36­7, right). Insert the needle until the “pop” of the deep fascia can be felt, and inject  to  mL of anesthetic.
If bone is contacted before the “pop” is felt, withdraw the needle  to  mm and inject the solution. To increase the probability of a successful block, withdraw the needle back to the skin and reinsert, directing the needle  degrees both medially and laterally, and inject an additional  to  mL of anesthetic solution. The palmar branch of the medial nerve is superficial and can be blocked by withdrawing the needle to the subcutaneous space and injecting  to  mL of anesthetic solution.
RADIAL NERVE BLOCK
Purpose
A radial nerve block provides anesthesia to the dorsal lateral half of the hand and dorsal aspect of the thumb.
Patient Positioning and Anatomy
The hand and wrist are placed in a supine (palm up) position. The superficial branch of the radial nerve traverses above the styloid process of the radius and provides sensation to the dorsum of the thumb, index finger, and lateral half of the middle finger (Figures 36­5 and 36­6). Other branches of the radial nerve traverse over the anatomic snuff box. The sides of the anatomic snuff box are formed by the tendons of the extensor pollicis brevis and longus and the base by the radial styloid.
Technique
Raise a wheal of anesthetic in the subcutaneous space just proximal to the anatomic snuffbox. Inject  mL of anesthetic solution into the subcutaneous tissue overlying the radial styloid
(Figure 36­7, right). (See Video: Regional Anesthesia: The Hand – Radial Nerve.)
Video 36­3: Regional Anesthesia: The Hand ­ Radial Nerve
Douglas Dillon, Intermountain Medical Center Emergency Department, Utah.
Play Video
Then, reinsert the needle and direct it through the subcutaneous space in a lateral (ulnar) direction, injecting a band of an additional  mL of anesthetic solution overlying the dorsum of the wrist to ensure blockage of the smaller branches of the radial nerve (Figure 36­7, lower left). The distribution of the radial nerve is less predictable; therefore, a generous amount of anesthetic solution should be injected.
ULNAR NERVE BLOCK
Purpose
An ulnar nerve block provides anesthesia to the entire fifth digit, half of the fourth digit, and the medial aspect of the hand and wrist.
Patient Positioning and Anatomy
The hand and wrist are placed in a supine (palm up) position. The ulnar nerve travels with the corresponding vein and nerve and can be located underneath (deep to) the flexor carpi ulnaris.
To identify the flexor carpi ulnaris, have the patient make a fist and tense the wrist. The flexor carpi ulnaris is the most prominent tendon on the ulnar side at the wrist (Figure 36­8A).
FIGURE 36­8. Ulnar nerve block. A. Technique for identifying the flexor carpi ulnaris tendon (fcu) by making a fist and tensing the wrist. B. The subcutaneous field block of the dorsal ulnar nerve branches, extending from the site of insertion of the ulnar block to the midline dorsal wrist. C. The needle is oriented horizontally beneath the flexor carpi ulnaris tendon and inserted to a depth of  to
 mm past the tendon edge where the anesthetic solution is injected after a negative aspiration. [Illustration used with permission of Timothy Sweeney, MD.]
Technique
Raise a wheal of anesthetic in the subcutaneous space just proximal (1 to  cm) to the most distal wrist crease. Insert the needle under the flexor carpi ulnaris tendon to an additional  to  mm past the edge of the tendon (Figure 36­8C). (See Video: Regional Anesthesia: The Hand – Ulnar Nerve.)
Video 36­4: Regional Anesthesia: The Hand ­ Ulnar Nerve
Douglas Dillon, Intermountain Medical Center Emergency Department, Utah.
Play Video
Aspirate before injection to ensure that inadvertent arterial/venous puncture has not occurred, and inject  to  mL of anesthetic solution. To block the dorsal branches of the ulnar nerve, inject  to  mL band of anesthetic solution in the subcutaneous space just above the tendon of the extensor carpi ulnaris (Figure 36­8B). US guidance can be useful when anatomic landmarks are not easy to discern.100,101
FOOT AND ANKLE BLOCKS
The five nerves that provide sensation to the foot are four branches of the sciatic nerve (deep and superficial peroneal, tibial, and sural nerves) and one cutaneous branch of the femoral nerve (saphenous nerve; Figures 36­9, 36­10, 36­11, 36­12). These are excellent blocks to use alone or in combination for lacerations, fracture reductions, and exploring wounds. The deep peroneal nerve and the posterior tibial nerves are deep nerves and can be consistently found by anatomic landmarks. The superficial peroneal, sural, and saphenous nerves are superficial and located in the subcutaneous tissue encircling the ankle. Due to the anatomic variability of these three nerves, no single injection point can reliably provide adequate anesthesia, so these nerves are blocked by depositing the local anesthetic agent as a field block in the subcutaneous space in the area through which the nerve travels. The pertinent landmarks for performing all of the ankle blocks are the extensor hallucis longus, tibialis anterior tendon, Achilles tendon, and the medial and lateral malleolus (Figure 36­13).
FIGURE 36­9. Foot innervation plantar view. Plantar foot distribution of deep peroneal nerve (green), posterior tibial nerve (red), and sural nerve (blue).
FIGURE 36­10. Foot innervation dorsal view. Dorsal foot distribution of deep peroneal nerve (green), superficial peroneal nerve (yellow), saphenous nerve (brown), and sural nerve (blue).
FIGURE 36­11. Foot innervation medial view. Medial foot distribution of superficial peroneal nerve (yellow), saphenous nerve (brown), and posterior tibial nerve (red).
FIGURE 36­12. Foot innervation lateral view. Lateral foot distribution of deep peroneal nerve (green), superficial peroneal nerve (yellow), posterior tibial nerve (red), and sural nerve (blue).
FIGURE 36­13. Ankle nerve blocks. A. The subcutaneous field block of the sural nerve (sur.) extends from the Achilles tendon to the lateral malleolus. The posterior tibial nerve (p.t.) is blocked just behind the posterior tibial artery. B. The deep peroneal nerve is blocked at the level of the medial malleolus between the anterior tibial tendon (t.a.) and extensor hallucis longus tendon (e.h.l.). The subcutaneous field block of the superficial peroneal nerve (s.per.) extends from the lateral malleolus to the anterior tibial tendon. C. The posterior tibial nerve is blocked posteriorly to the posterior tibial artery. The subcutaneous field block of the saphenous nerve (saph.) extends from the medial malleolus to the anterior tibial tendon. [Illustration used with permission of
Timothy Sweeney, MD.]
When all five blocks are used for complete foot anesthesia, the deep nerves (deep peroneal and posterior tibial) should be anesthetized before the surface anatomy is distorted by the superficial field blocks of the other three. An additional tip is to prepare and clean the entire foot before starting so that the physician can change his or her body position and reposition the patient’s foot as needed to avoid awkward reaches when accessing all five sites.
DEEP PERONEAL NERVE BLOCK
Purpose
A deep peroneal nerve block provides anesthesia to the web space between the first and second toe and a small area just proximal to the first and second toe on the plantar aspect of the foot.
Patient Positioning and Anatomy
The foot is placed in a neutral position. At the level of the medial malleolus, the deep peroneal nerve can be found between the extensor hallucis longus and the tibialis anterior tendon.
Extension of the big toe against resistance will help to identify the extensor hallucis longus. Dorsiflexion and inversion of the ankle will help to identify the tibialis anterior tendon.
Technique
Raise a wheal of anesthesia in the subcutaneous space between the extensor hallucis longus and the tibialis anterior tendon at the level of the medial malleolus (Figure 36­13B). With the syringe perpendicular to the skin, insert the needle until the extensor retinaculum is penetrated or bone is struck. If bone is struck, withdraw the needle  mm. After aspirating to verify that no vascular structure has been entered, inject approximately  to  mL of anesthetic solution. To increase the chance of a successful block, withdraw the needle back to the skin and reinsert, direct the needle  degrees medially and laterally, and deposit an additional  mL of anesthetic solution on each side.
POSTERIOR TIBIAL NERVE BLOCK
Purpose
A posterior tibial nerve block provides anesthesia to the plantar aspect of the foot. This is an excellent block when repairing a laceration on the bottom of the foot.
Patient Positioning and Anatomy
The patient can be either supine with the foot rotated outward or prone with the foot rotated inward. The posterior tibial nerve, artery, and vein can be found just posterior to the medial malleolus. The nerve is deep to the fascia and superficial/posterior to the artery.
Technique
Raise a wheal of anesthesia posterior to the medial malleolus. Palpate the posterior tibial artery and insert the needle just posterior to the artery until it is deep to the fascia or bone is struck
(Figure 36­13A and C). (See Video: Regional Anesthesia: The Foot – Posterior Tibial Nerve.)
Video 36­5: Regional Anesthesia: The Foot ­ Posterior Tibial Nerve
Douglas Dillon, Intermountain Medical Center Emergency Department, Utah.
Play Video
If bone is struck, withdraw the needle  mm. Inject  to  mL of local anesthetic solution after aspirating to ensure that inadvertent arterial/venous puncture has not occurred. To increase the chance of a successful block, withdraw the needle back to the skin and reinsert, directing the needle  degrees medially and laterally, and deposit an additional  mL of anesthetic solution on each side. US guidance can be used to guide the needle and increase the completeness of a posterior tibial nerve block.102
SUPERFICIAL PERONEAL NERVE BLOCK
Purpose
A superficial peroneal nerve block provides anesthesia to the dorsal lateral aspect of the foot.
Patient Positioning and Anatomy
The patient is supine, and the foot is rotated inward. The superficial peroneal nerve traverses the lateral portion of the ankle in the subcutaneous space between the lateral malleolus and the tibialis anterior tendon.
Technique
Prepare a sterile site between the superior border of the lateral malleolus and the tibialis anterior tendon. Dorsiflexion and inversion of the ankle will help to identify the tibialis anterior tendon. In the subcutaneous space, inject  mL of anesthetic, tracking from the tibialis anterior tendon to the superior portion of the lateral malleolus (Figure 36­13B). Creation of a subcutaneous wheal indicates proper anesthetic placement.
SURAL NERVE BLOCK
Purpose
A sural nerve block provides anesthesia to the lateral aspect of the ankle with some extension of anesthesia to the plantar aspect of the foot.
Patient Positioning and Anatomy
The patient can be either supine with the foot rotated inward or prone with the foot rotated outward. The sural nerve traverses the posterior lateral portion of the ankle in the subcutaneous space between the Achilles tendon and the lateral malleolus.
Technique
Identify the space between the Achilles tendon and the superior border of the lateral malleolus. In the subcutaneous space, inject  to  mL of anesthetic solution in a band running from the superior portion of the lateral malleolus to the Achilles tendon (Figure 36­13A). (See Video: Regional Anesthesia: The Foot – Sural Nerve.)
Video 36­6: Regional Anesthesia: The Foot ­ Sural Nerve
Douglas Dillon, Intermountain Medical Center Emergency Department, Utah.
Play Video
Creation of a subcutaneous wheal indicates proper anesthetic placement. Using US guidance to inject local anesthetic around the lesser saphenous vein may facilitate a more complete block of longer duration.103
SAPHENOUS NERVE BLOCK
Purpose
A saphenous nerve block provides anesthesia to the medial aspect of the ankle.
Patient Positioning and Anatomy
The foot is in a neutral position. The saphenous nerve traverses the anterior medial portion of the ankle in the subcutaneous space between the tibialis anterior tendon and the medial malleolus.
Technique
Identify the space between the tibialis anterior tendon and the superior border of the medial malleolus. In the subcutaneous space, inject  to  mL of anesthetic solution in a band from the tibialis anterior tendon to the superior portion of the medial malleolus (Figure 36­13C). (See Video: Regional Anesthesia: The Foot – Saphenous Nerve.)
Video 36­7: Regional Anesthesia: The Foot ­ Saphenous Nerve
Douglas Dillon, Intermountain Medical Center Emergency Department, Utah.
Play Video
Creation of a subcutaneous wheal indicates proper anesthetic placement.
FACIAL NERVE BLOCKS
Facial nerve blocks provide excellent analgesia and little to no distortion of the forehead, cheek, and chin (Figure 36­14).75,104Topical anesthetic applied to the mucosa should be used before the intraoral approach for infraorbital and mental nerve blocks. It is important to assess neurovascular status before application of the block to prevent masking a primary traumatic neurovascular injury.
FIGURE 36­14. Face innervation frontal view. Nerve distribution to the face with supraorbital nerve (red), supratrochlear nerve (brown), infraorbital nerve (yellow), and mental nerve (blue).
SUPRAORBITAL AND SUPRATROCHLEAR NERVE BLOCKS
Purpose
Supraorbital and supratrochlear nerve blocks provide anesthesia to the entire forehead up to the vertex of the scalp and down the bridge of the nose.
Patient Positioning and Anatomy
The patient is either lying supine or sitting upright in a position of comfort. The supraorbital nerve exits the supraorbital foramen, which is in line with the pupil and above the superior orbital rim. The supratrochlear nerve exits from under the superior orbital rim  to  mm medial to the supraorbital foramen. The supraorbital nerve supplies most of the forehead, whereas the supratrochlear nerve supplies the area along the bridge of the nose (Figure 36­14).
Technique
Raise a wheal of anesthesia in the subcutaneous space just superior to the eyebrow and in line with the pupil. Deposit  to  mL of anesthetic solution in the subcutaneous space, and then direct the needle medially to raise a horizontal wheal reaching to the medial border of the eyebrow using an additional  mL of anesthetic solution (Figure 36­15).
FIGURE 36­15. Supraorbital and infraorbital nerve blocks. Palpation of the subtle supraorbital foramen may be difficult, although identification is achieved when forehead paresthesias are elicited. A subcutaneous field block extending horizontally above the eyebrow is a useful addition. Palpation of the infraorbital foramen, especially via the intraoral approach, is typically easier.
[Illustration used with permission of Timothy Sweeney, MD.]
INFRAORBITAL NERVE BLOCK
Purpose
An infraorbital nerve block provides anesthesia to the lower lid, medial cheek, ipsilateral side of the nose, and ipsilateral upper lip (Figure 36­14).
Patient Positioning and Anatomy
The patient is either lying supine or sitting upright in a position of comfort. The infraorbital nerve exits the infraorbital foramen  to  mm inferior to the midportion of the orbital rim and just cranial (superior) to the maxillary canine teeth (tooth #6 on the patient’s right and #11 on the patient’s left).
Technique
After adequately providing topical anesthetic to the mucosa superior to the maxillary canine, dry the mucosa and retract the upper lip. The recommended technique involves placing the index finger and middle finger of the noninjecting hand on the inferior optic rim and everting the upper lip with the thumb. Insert the needle at the gingival reflection above the maxillary canine, direct the needle superiorly, advance approximately half the distance from the entry site to the orbital rim, and inject  to  mL of anesthetic solution (Figure 36­15). Depending on the patient’s anatomy, it may be possible for the physician’s index or middle finger to palpate the infraorbital foramen through the skin and direct the needle to this site.
MENTAL NERVE BLOCK
Purpose
A mental nerve block provides anesthesia to the labial mucosa, gingiva, and lower lip adjacent to the incisors and canines.
Patient Positioning and Anatomy
The patient can be either lying supine or sitting upright in a position of comfort. The inferior alveolar nerve gives rise to the mental nerve, which exits the mental foramen, located inferior to the mandibular canines and first premolars (teeth #21 and #22 on the patient’s left, and #27 and #28 on the patient’s right).
Technique
After adequately providing topical anesthetic to the mucosa inferior to the canine and first premolars, dry the mucosa and evert the lower lip. Insert the needle at the gingival reflection at this site, direct the needle inferiorly, advance approximately  cm, and inject  to  mL of anesthetic solution (Figure 36­16). (See Video: Mental Nerve Block.)
FIGURE 36­16. Mental nerve block. Infiltration of anesthetic around the mental foramen from an intraoral (right needle) or transcutaneous (left needle) approach. [Illustration used with permission of
Timothy Sweeney, MD.]
Video 36­8: Mental Nerve Block
Used with permission from Saundra A. Jackson and Shawn C. Patterson, Dept of Emergency Medicine, University of North Carolina.
Play Video
Depending on the patient’s anatomy, it may be possible for the physician’s finger to palpate the mental foramen through the skin and direct the needle to this site.
AURICULAR BLOCK
Purpose
An auricular block provides anesthesia to the external ear by blocking the auriculotemporal (anterior and superior portion), lessor occipital (posterior), and great auricular (inferior portion) nerves.105
Patient Positioning and Anatomy
Patient can either be lying supine or sitting upright in a position of comfort. The sensation to the ear is provided anteriorly by the auriculotemporal nerve and posteriorly by the greater auricular nerve and the mastoid branch of the lesser occipital nerve.
Technique
Raise a wheal in the subcutaneous space inferior to the auricle. From this site, direct the needle in the subcutaneous space anterior and superior, and inject  to  mL of anesthetic while withdrawing the needle (Figure 36­17). From the original injection point, redirect the needle posteriorly and superiorly and deposit  to  mL in the subcutaneous space while withdrawing the needle. Repeat this process from the superior aspect of the ear, injecting  to  mL of local anesthetic in the subcutaneous space both anterior and posterior to the ear to complete the field block around the ear.
FIGURE 36­17. Auricular field block. The auricular block is a simple field block around the base of the external ear. [Illustration used with permission of Timothy Sweeney, MD.]
INTERCOSTAL NERVE BLOCK
Purpose
An intercostal nerve block provides analgesia to the intercostal nerve above and below the affected rib in a band­like fashion around the chest wall. These blocks provide an alternative to parenteral analgesia for controlling pain from rib fractures,106,107 tube thoracostomy,108 and thoracic herpes zoster.109 Although controlled trials comparing parenteral analgesia with intercostal nerve blocks are lacking, clinical observations suggest better pain control and increased lung function associated with intercostal blocks.110 A good intercostal block will provide anesthesia duration between  and  hours when a long­acting local anesthetic is used.
Patient Positioning and Anatomy
Patient is sitting upright, with the ipsilateral arm raised at the shoulder and the wrist rested on top of the head. Within the subcostal groove of the rib, the intercostal nerve originates from the thoracic nerve and runs inferior to the artery and vein (“vein, artery, nerve”). Ribs  through  are difficult to block due to the position of the scapula and rhomboid muscles. With both anterior and posterior rib fractures, the optimal block site is at the “rib angle,” approximately  cm lateral to the midline, or just lateral to the paraspinous muscles. Blocking posterior to the midaxillary line ensures analgesia to the lateral cutaneous and anterior branch of the intercostal nerve (Figure 36­18, right).
FIGURE 36­18. Intercostal block. Top: Cross­section of the chest shows the relevant branching of a typical intercostal nerve. Intercostal nerve blocks are commonly performed at the midaxillary line (a) or the posterior axillary “rib angle” line (b). Bottom: Retraction of the skin cephalad from the lower edge of the rib exposes the site of entry. The needle is inserted at a 10­degree angle off perpendicular, tip cephalad until contact is made with the lower rib edge. When the skin is released, the needle is allowed to slide caudad to the lowermost rib border. There, the needle is advanced  mm, aspiration is attempted, and the anesthetic solution is injected. [Illustration used with permission of Timothy Sweeney, MD.]
Technique
Palpate the inferior border of the rib to be blocked with the noninjecting hand, and retract the skin cephalad at a location about  cm from the midline. Raise a wheal in the subcutaneous space, and insert the needle bevel up with the syringe lower than the entry site. The optimal angle is approximately  to  degrees off the perpendicular with the needle tip angled cephalad
(Figure 36­18, top). Continue inserting the needle until it contacts bone. The needle should be resting at the inferior border of the rib to be blocked. Release the skin being retracted with the noninjecting hand, walk the needle caudally until it drops off the inferior edge of the rib, and advance the needle approximately  mm. This is the subcostal groove. Aspirate before injection, and deposit  to  mL of anesthetic.
The patient should be monitored for  minutes after the procedure to watch for clinical signs of pneumothorax. A postprocedure chest radiograph is not routinely indicated unless clinical signs of pneumothorax, including coughing, shortness of breath, or hypoxia, occur. A bedside pulmonary US can be performed following the procedure to assess for pneumothorax.
Pneumothorax occurs in 8% to 9% of patients, or at a rate of about .4% for each individual intercostal block.111
EXTREMITY BLOCKS
FEMORAL NERVE BLOCK
Purpose
Regional anesthesia in the femoral region can result in an isolated femoral nerve block or a larger block involving the femoral, obturator, and lateral femoral cutaneous nerves. These blocks provide good to excellent pain control for patients with proximal femur and hip fractures and are especially useful in the elderly.112­117 The “three­in­one” block uses the same injection location as a femoral nerve block but applies distal pressure to promote cephalad distribution of the anesthetic agent to block the obturator and lateral femoral cutaneous nerves.118 It is important to assess distal neurovascular status before application of the block to prevent masking a primary traumatic neurovascular injury.
Patient Positioning and Anatomy
The patient is lying in a supine position. In obese patients, placement of a pillow underneath the hip and retraction of the lower abdominal pannus superiorly and laterally will help expose the area. At the inguinal ligament and the inguinal (femoral) crease, the femoral nerve is positioned lateral to and slightly deeper than the femoral artery (Figure 36­19). The femoral nerve block will provide anesthesia to the anterior thigh and medial leg. The “three­in­one” block anesthetizes regions innervated by the obturator and the lateral femoral cutaneous nerves in addition to the anterior thigh and medial leg. (See Video: Femoral Nerve Block.)
FIGURE 36­19. Femoral nerve block. The area  cm lateral to the femoral artery and at the level of the inguinal crease provides the point of insertion. The needle enters directly slightly cephalad and advances until paresthesia is felt. [Illustration used with permission of Timothy Sweeney, MD.]
Video 36­9: Femoral Nerve Block
Used with permission from Sandra L. Werner, MD, RDMS.
Play Video
Technique
A peripheral nerve stimulator or US guidance is recommended.82­86,88­90,119,120 Ropivacaine is an excellent long­acting anesthetic for femoral nerve blocks.6,8,9
Locate the femoral artery on the affected side at the level of the inguinal crease. Palpate the femoral artery with the noninjecting hand, and raise a wheal of anesthetic in the subcutaneous space at the level of the inguinal crease and  cm lateral to the femoral artery. Insert the needle at this site and directed slightly cephalad (Figure 36­19). The femoral nerve is typically  to  cm below the skin.
If a peripheral nerve stimulator is being used, needle position is confirmed by contraction of the quadriceps muscle and subsequent patellar movement. If the sartorius muscle contracts, the needle should be repositioned slightly lateral and deeper. The sartorius muscle may mimic the quadriceps contractions, but the patella will only move with quadriceps contractions. US can also be used to accurately guide needle advancement and distribution of the anesthetic agent for a femoral nerve block.120
If a peripheral nerve stimulator is not being used, correct positioning of the needle is confirmed by the patient reporting paresthesia over the anterior thigh as the needle impacts the femoral nerve. Back the needle off slightly and inject approximately  mL of the anesthetic solution into the perineural space. If paresthesia over the anterior thigh cannot be elicited, the needle should be withdrawn to the skin, redirected  to  degrees laterally, and advanced as before. More lateral skin insertions may be required to locate the femoral nerve. Alternatively, a “blind” attempt can be made by injecting a larger quantity (30 to  mL) of anesthetic solution in and around the original site in an effort to spread the anesthetic through the region and reach the femoral nerve. Aspirate before each injection to avoid inadvertent arterial puncture, and do not inject if resistance is felt, as this indicates the possibility for intraneural injection.
To perform a “three­in­one” block, needle position should be confirmed by paresthesia or preferably by US.119 Firm pressure distal to the injection site is then applied and held for  minutes as  to  mL of anesthetic solution is delivered. This distal pressure promotes cephalad distribution of the anesthetic solution.
An alternative to the femoral nerve block for pain control in patients with hip and femoral neck fractures is the fascia iliaca compartment block.121­123 During the fascia iliaca compartment block (also known as the fascia iliaca block),  to  mL of anesthetic is injected deep to the fascia iliaca and allowed to spread medially and laterally to reach the femoral nerve and lateral femoral cutaneous nerve. The procedure can be performed under US guidance where the needle can be easily visualized as it approaches and passes through the fascia lata and fascia iliaca.
If the procedure is being performed via the landmark approach alone, two “pops” will be felt as the needle is advanced through the fascia lata and the underlying fascia iliaca. Following the second “pop,” aspirate to ensure that the needle tip is not within a vessel, and then inject the full amount of anesthetic to complete the fascia iliaca compartment block.
HEMATOMA BLOCK
Purpose
Hematoma blocks are commonly performed for fracture reduction, using the hematoma formation around the fracture to deliver anesthetic to the fracture site, most commonly for Colles’ fractures.124­126 This block has waned in use due to the rising popularity of procedural sedation and the misconception that hematoma blocks dramatically increase the risk of infection. The hematoma block remains a staple in the armamentarium of fracture analgesia because it is simple, fast, and requires no special tools or personnel.127,128
Patient Positioning
The patient is usually lying supine with the limb placed in a position of comfort to allow access to the fracture hematoma.
Technique
Prepare a sterile block site over the bony fracture site and insert the needle directly into the hematoma (Figure 36­20). Positioning the needle in the hematoma can be difficult at times.
Bedside US can be used to localize the dark, anechoic hematoma. Aspiration of blood aids in confirmation of needle position. Inject  to  mL of local anesthetic solution into the fracture site. The typical dose for distal radius fractures is  mL of 1% lidocaine or  mL of 2% lidocaine.129When performing this block, ensure that the maximum dose of local anesthetic is not exceeded. This procedure should not be performed through a contaminated wound or an open fracture.
FIGURE 36­20. Hematoma block. After careful palpation for the fracture edge, the needle is inserted directly into the hematoma, with care taken to avoid regional vessels. [Illustration used with permission of Timothy Sweeney, MD.]
INTRAVENOUS REGIONAL ANESTHESIA (BIER BLOCK)
PURPOSE
The Bier block provides dense anesthesia in a limb for up to  minutes without the risks of general anesthesia. It is an excellent block for large complex lacerations, fracture reductions, and surgical procedures lasting <1 hour in duration on the extremities130,131 and does not require fasting for safe performance.132Although this block is relatively easy to perform, it does require a specialized pneumatic tourniquet and provides no postprocedure pain control. Because the local anesthetic solution is directly infused into the venous system, careful attention to technique is important to prevent systemic toxicity.133 It is important to assess neurovascular status in the involved limb before application of the block to prevent masking a primary traumatic neurovascular injury.

## Page 26

TECHNIQUE
Place two IV catheters: one small­gauge catheter distally in the affected extremity and the other in the unaffected extremity for fluid administration and sedation, if needed. Apply the specialized double­cuff pneumatic tourniquet to the affected upper arm or thigh. The standard blood pressure cuff is not an acceptable alternative. The pneumatic tourniquet should be placed proximal to the site of injury. Provide adequate padding beneath the cuff, as this is often the site of maximal discomfort during the procedure.
Exsanguinate the affected extremity by either elevating it for  to  minutes or wrapping the extremity with a compression bandage from distal to proximal. The cuffs are then inflated in the following sequence: Inflate the distal cuff first, followed by inflating the proximal cuff and, finally, deflating the distal cuff. In the upper extremity, inflate the pneumatic tourniquet to 250 to
300 mm Hg (30 to  kPa) or 100 mm Hg (15 kPa) above the patient’s systolic blood pressure. In the leg, cuff inflation pressures are 350 to 400 mm Hg (45 to  kPa). The compression bandage should be removed if used. The limb should be pale, and pulses should not be palpable.
Infuse the anesthetic via the small catheter of the affected limb. Most authors recommend diluting standard 1% lidocaine with equal parts normal saline to create a .5% (5 milligrams/mL) solution. The amount infused varies according to physician preference in the range of .5 to .0 milligrams/kg (3 to  mL of the .5% lidocaine solution for every  kg of body weight).130
Onset of anesthesia is usually within  minutes. If inadequate anesthesia occurs when using a minidose (1.5 milligrams/kg), infuse additional lidocaine up to  milligrams/kg. If adequate anesthesia is not obtained with the maximum dose of lidocaine, infuse additional normal saline to help circulate the anesthetic.
The patient may report a sensation of warmth or cold, and the skin will become mottled. The smaller nerve fibers are affected first, causing a reduction in pain and temperature sensation followed by loss of touch, deep pressure, and, finally, motor function. An ideal Bier block will provide complete anesthesia and muscle relaxation, but some patients may retain varying degrees of intact touch, deep pressure sensation, and motor function. Remove the IV in the affected extremity once adequate analgesia is obtained. Many patients will describe pain or
University of Pittsburgh pressure at the tourniquet site, usually within  minutes or so. This is handled by reinflating the previously deflated distal cuff. After ensuring that the distal cuff is inflated to the proper level and will hold pressure, the proximal cuff is slowly deflated. Adjuncts, such as ketorolac  milligrams, dexamethasone  milligrams, midazolam  micrograms/kgA,c kceestas mPrionveid 0e.d5 bmy:illigram/kg, or dexmedetomidine  microgram/kg, mixed with the local anesthetic can also be used to control the pain of tourniquet inflation and provide postprocedure analgesia.134­136
The cuff should not be released until a minimum of  minutes after the initial lidocaine infusion. Premature release of the cuff increases the chance of systemic toxicity from the anesthetic.
Upon completion of the procedure, the pneumatic tourniquet should be cycled by lowering the cuff pressure for  to  seconds and then reinflating it for  to  minutes. This cycle should be repeated three to five times to prevent any possible bolus of anesthetic into the central circulation. Additional analgesia is usually required after completion of the procedure because anesthesia rapidly dissipates after release of the tourniquet. The patient should be monitored for approximately  minutes to ensure that no adverse reaction to the anesthetic has occurred.130
Acknowledgment
We acknowledge the contributions of Douglas C. Sillon to this chapter in the previous edition.


