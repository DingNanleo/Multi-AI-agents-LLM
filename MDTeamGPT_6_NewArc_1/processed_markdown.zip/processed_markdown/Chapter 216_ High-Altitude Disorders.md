## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 216: High­Altitude Disorders
Chris Davis; Kurt Power Eifling
INTRODUCTION
Millions of people annually visit mountainous areas of the western United States at altitudes of >2440 m (>8000 ft). In addition, tens of thousands travel to high­altitude regions in other parts of the world. Physicians working or traveling in or near these locations are likely to encounter high­altitude illness or preexisting conditions that are exacerbated by altitude. Although the focus of this chapter is hypoxia­related problems, patients in the mountain environment may require care for associated illnesses such as hypothermia (see Chapter 209, “Hypothermia”), frostbite (see Chapter 208,
“Cold Injuries”), dehydration, and lightning injury (see Chapter 219, “Electrical and Lightning Injuries”).
High altitude (>2440 m [>8000 ft]) is a hypoxic environment. Because the concentration of oxygen in the troposphere remains constant at 21%, the partial pressure of oxygen (P ) decreases as a function of the barometric pressure. Two locations in the U.S. western state of Colorado are illustrative.
O2
In Denver, at 1610 m (5280 ft), air pressure is 17% less than at sea level; Aspen, at 2440 m (8000 ft), has 26% less oxygen than sea level. At 5490 m (18,000 ft), there is half the oxygen available at sea level, whereas on top of Mount Everest (8848 m or ,029 ft), there is only one third. Oxygen supplementation prevents symptoms of altitude illness during hypobaric exposure. Symptoms of acute mountain sickness (AMS) are due primarily to hypoxia, not hypobaria.
Altitude may be divided into stages according to physiologic effects. Intermediate altitude, 1520 to 2440 m (5000 to 8000 ft), produces decreased exercise performance and increased alveolar ventilation without major impairment in arterial oxygen transport. AMS occurs at and above 2130 to 2440 m (7000 to 8000 ft) and sometimes at lower altitudes in particularly susceptible individuals. Patients who have limitations in ventilatory response (e.g., patients with some neuromuscular diseases or those with preexisting hypoxemia) may become more symptomatic in this range of altitude. High altitude, 2440 to 4270 m (8000 to ,000 ft), is associated with decreased arterial oxygen saturation (Sa ); marked hypoxemia may occur during
O2 exercise and sleep. Most cases of altitude­related medical problems occur in this elevation range, because of the availability of overnight tourist facilities located at these heights.
Very high altitude, 4270 to 5490 m (14000 to ,000 ft), is uncommon in the United States, but is encountered by visitors to the mountainous regions of
South America and the Himalayas. Abrupt ascent can be dangerous, and a period of acclimatization is required to prevent illness. Extreme altitude,
>5490 m (>18,000 ft), experienced only by mountain climbers, is accompanied by severe hypoxemia and hypocapnia. At this height, progressive physiologic deterioration eventually outstrips acclimatization, and sustained human habitation is impossible. Because hypoxemia is maximal during sleep, sleeping altitude is the critical driver of altitude illness.
PHYSIOLOGY AND PATHOPHYSIOLOGY OF ALTITUDE ACCLIMATIZATION
Acutely hypoxic individuals become dizzy, faint, and rapidly unconscious if hypoxic stress is sufficient (Sa <65%). However, if given days to weeks to
O2 acclimatize, individuals can tolerate surprising degrees of hypoxemia. Although the fundamental process of acclimatization takes place in cellular and mitochondrial metabolism, acute “stress” responses enable temporizing homeostasis while allowing cells time to truly acclimatize.
VENTILATION
The primary initial adaptation to hypoxemia is defense of alveolar P through increased ventilation. The hypoxic ventilatory response is modulated by
O2 the carotid body, which senses a decrease in arterial oxygenation and signals the central respiratory center in the medulla to increase ventilation.
Individuals with a more vigorous inborn response show more successful acclimatization and improved exercise performance. Respiratory stimulants increase the ventilation response; respiratory depressants and chronic hypoxia weaken it. A low hypoxic respiratory drive may allow significant hDyopwonxleomadiae tdo  d0e2v5e­lo7p­1 d 6u:r3in5g P s l eYeopu.r IP is 136.142.159.127
Chapter 216: High­Altitude Disorders, Chris Davis; Kurt Power Eifling 
W©2it0h2 a5s cMecnGt, rianwiti aHl ihll.y Apell rRveignhtitlsa tRioens eisr vaettde.n u Taetermd sq uoifc Uklsye b * y P rerisvpaicrayt Poroyli acylk a * lNosoitsic, we h * iAchc caectsss aibsi lait ybrake on the respiratory center. As renal excretion of bicarbonate increases to compensate for the respiratory alkalosis, pH returns toward normal and ventilation continues to increase. The process of maximizing ventilation, termed ventilatory acclimatization, culminates after  to  days at a given altitude. With continuing rise to higher altitudes, the central chemoreceptors reset to progressively lower values of partial pressure of CO , and the completeness of acclimatization can be gauged by the
 partial pressure of arterial CO . Acetazolamide, which induces bicarbonate diuresis, greatly facilitates this process through its inhibition of carbonic

 anhydrase (thus counteracting ascent­related respiratory alkalosis). An appreciation of the normal values for blood gases and acid­base status with acclimatization at various altitudes is necessary to distinguish abnormalities (Table 216­1).
TABLE 216­1
Normal Blood Gas Concentrations at Various Altitudes
Altitude Pa O2 (mm Hg) Sa O2 (%) Pa CO2 (mm Hg)
Sea level 90–95  
5000 ft (1520 m) 75–81  .6
7500 ft (2290 m) 69–74 92–93 31–33
,000 ft (4570 m) 48–53  
,000 ft (7000 m) 37–45  
,000 ft (7620 m) 32–39  
,000 ft (8840 m) 26–33  .5–13.8
Abbreviations: Pa = partial pressure of arterial carbon dioxide; Pa = partial pressure of arterial oxygen; Sa = arterial oxygen saturation.
CO2 O2 O2
BLOOD
Within hours of ascent to altitude, serum erythropoietin level increases, resulting in increased red cell mass over days to weeks. This adaptation has no importance during initial acclimatization when acute altitude illness develops. However, excessive red cell mass may develop over a period of weeks to months, leading to chronic mountain polycythemia. Shifts in the oxyhemoglobin dissociation curve are thought to be minimal at altitude because of balancing physiologic effects. Hypoxia causes an increase in the level of ,3­diphosphoglyceric acid and shifts the curve to the right, which has the effect of facilitating unloading of oxygen to the tissues. Respiratory alkalosis shifts the curve to the left, which has the opposite effect (i.e., facilitating oxygen loading in the lungs).
FLUID BALANCE
Peripheral venous constriction on ascent to altitude causes an increase in central blood volume that triggers baroreceptors to suppress secretion of antidiuretic hormone and aldosterone; diuresis results. Combined with the bicarbonate diuresis from the respiratory alkalosis, the result is decreased plasma volume and a hyperosmolality that results from a reset of the osmolar center of the brain. Hemoconcentration increases oxygen­carrying capacity of the blood. Clinically, diuresis and hemoconcentration are considered healthy responses, whereas antidiuresis is associated with AMS and may contribute to peripheral edema.
CARDIOVASCULAR SYSTEM
Stroke volume decreases initially, and increased heart rate is required to maintain cardiac output. Maximum exercising heart rate at altitude declines in proportion to the decrease in maximum oxygen consumption (VO max). Cardiac muscle in healthy persons can withstand extreme levels of hypoxemia

(partial pressure of arterial oxygen [Pa ] of <30 mm Hg) without evidence of ST­segment changes or ischemic events. Blood pressure typically
O2 increases mildly on ascent, secondary to increased sympathetic tone, but labile blood pressures are also possible.
The pulmonary circulation constricts with exposure to hypoxia. Pulmonary vasoconstriction is advantageous during some conditions of regional alveolar hypoxia (e.g., pneumonia). However, it poses a disadvantage during the global hypoxia of altitude exposure by increasing overall pulmonary vascular resistance and pulmonary artery pressure. A hyperreactive response increases susceptibility to high­altitude pulmonary edema (HAPE). This is
 the underpinning of sildenafil therapy for HAPE.
Cerebral blood flow transiently increases on ascent to altitude (despite the respiratory alkalosis), increasing oxygen delivery to the brain. This response is limited by the increase in cerebral blood volume, which may increase intracranial pressure and aggravate symptoms of altitude illness.
EXERCISE CAPACITY
Exercise capacity, as measured by VO max, drops dramatically on ascent to altitude, by approximately 10% for each 1000­m (3280­ft) altitude gain
 above 1500 m (4920 ft). During acclimatization, submaximal endurance increases appreciably after  days, but VO max does not. The mechanism of
 this decrement might be lack of adequate oxygen supply to the muscle cells due to the low driving pressure for transcapillary oxygen diffusion. Another theory suggests that the CNS limits muscle activity to preserve its own oxygenation.
LIMITATIONS TO ACCLIMATIZATION
There are limits to acclimatization. Even those who are by nature good acclimatizers cannot tolerate the hypoxia of extreme altitude for long. Miners in
South America report that they cannot live at altitudes >5800 m (>19,000 ft) because of weight loss, lethargy, poor­quality sleep, weakness, and headache. High­altitude mountaineers cannot survive for more than a few days at >8000 m (>26,200 ft) without supplemental oxygen because of rapid deterioration of physiologic functioning. Considerable weight loss due to loss of fat and lean body mass is unavoidable.
SLEEP AT HIGH ALTITUDE
Frequent nighttime awakenings are a common nuisance at high altitude but are innocuous and improve with acclimatization. These awakenings are typically seen above 2700 m (8860 ft) and are driven by periodic breathing (Cheyne­Stokes respiration). Awakenings consist of 6­ to 12­second apneic pauses interspersed with cycles of vigorous ventilation. Intervals of apnea of >20 seconds can be observed at extreme altitudes. Both sleep quality and arterial oxygenation during sleep improve with acclimatization and with acetazolamide.
HIGH­ALTITUDE SYNDROMES
High­altitude syndromes are those attributed directly to hypoxia: acute hypoxia, AMS, HAPE, high­altitude cerebral edema (HACE), retinopathy, peripheral edema, sleeping problems, and a group of neurologic syndromes. Each of these clinical syndromes has a distinctive pattern and phenotype, but all share the fundamental etiology of hypoxia, all are seen in the same setting of rapid ascent in unacclimatized persons, and all respond to the same essential therapies: descent and oxygen. Other syndromes occurring at high altitude, which are not necessarily related to hypoxia, include thromboembolic events, high­altitude pharyngitis, and bronchitis.
ACUTE HYPOXIA
The syndrome of acute hypoxia occurs in the setting of sudden and severe hypoxic insult, such as occurs with accidental decompression of a pressurized aircraft cabin or failure of the oxygen system used by a pilot or high­altitude mountaineer. Relatively acute hypoxia can also occur due to abrupt overexertion (precipitating arterial desaturation), acute onset of pulmonary edema, carbon monoxide poisoning, or sleep apnea.
Unacclimatized persons become unconscious at an Sa of 50% to 60%, a Pa of less than approximately  mm Hg, or a jugular venous P of <15
O2 O2 O2 mm Hg. Acute hypoxia reverses with immediate administration of oxygen, rapid descent, and correction of the underlying cause. The sensitivity of the
CNS to acute hypoxia is reflected in the entity’s symptom progression: dizziness, lightheadedness, and dimmed vision leading to loss of consciousness.
ACUTE MOUNTAIN SICKNESS
AMS is a syndrome characterized by headache along with some combination of nausea or vomiting, dizziness, fatigue, or sleep disturbance (Table 216­2). AMS occurs in the setting of more gradual and less severe hypoxic insult than acute hypoxia syndrome. Its incidence varies by location, ease of access to the high­altitude environment, rate of ascent, and sleeping altitude. One study found a 25% incidence of AMS in physicians attending a continuing education meeting held at 2100 m (6900 ft) in Colorado. Other studies at resorts between 2220 and 2700 m (7280 and
8860 ft) in elevation claim an incidence between 17% and 40%; a sleeping altitude of 2740 m (9000 ft) seems to be a threshold for a marked increase in

AMS incidence. Approximately 40% of trekkers in Nepal on the path to Mount Everest experience AMS, and climbers on Mount Rainier have a very high incidence of 70% (probably due to rapidity of ascent).
TABLE 216­2
Lake Louise Acute Mountain Sickness (AMS) Self­Questionnaire* Headache Score
No headache—0
Mild headache—1
Moderate headache—2
Severe headache, incapacitating—3
GI symptoms Score
No symptoms—0
Poor appetite or nausea—1
Moderate nausea or vomiting—2
Severe nausea and vomiting, incapacitating—3
Fatigue/weakness Score
Not tired or weak at all—0
Mild fatigue or weakness—1
Moderate fatigue or weakness—2
Severe fatigue or weakness, incapacitating—3
Dizzy/lightheadedness Score
No dizziness/lightheadedness—0
Mild dizziness/lightheadedness—1
Moderate dizziness/lightheadedness—2
Severely light­headed, fainting/passing out—3
Difficulty sleeping Score
Slept well—0
Did not sleep as well as usual—1
Woke many times, poor night’s sleep—2
Could not sleep at all—3
Total symptom score
*Diagnosis of AMS requires headache plus  or more of the above symptoms.
Mild AMS: score of 2–4
Moderate AMS: score of 5–9
Severe AMS: score of 10–15
Source: Reproduced with permission from Roach RC, Bartsch P, Hackett PH, Oelz O; the Lake Louise AMS Scoring Consensus Committee: The Lake Louise Acute
Mountain Sickness Scoring System, in Sutton J, Houston C, Coates G (eds): Hypoxia and Mountain Medicine: Proceedings of the 8th International Hypoxia
Symposium. Burlington, VT: Pergamon Press; 1992, p. 272. In addition to sleeping altitude and rate of ascent, genetic predisposition determines individual susceptibility to AMS largely through a phenotype of blunted ventilatory response to hypoxia. Cardiovascular training status and sex have little influence on attack rates. Age has little influence on incidence, with children being as susceptible as adults, although those >50 years of age tend to have less AMS. Obesity appears to increase the risk of

AMS, possibly due to greater nocturnal oxygen desaturation. Susceptibility to AMS generally is reproducible in an individual on repeated exposures.
Persons living at intermediate altitudes of 1000 to 2000 m (3300 to 6600 ft) already are partially acclimatized and do much better than lowlanders on ascent to higher altitudes.
PATHOPHYSIOLOGY
AMS is due to hypobaric hypoxia, but the exact sequence of events leading to illness remains unclear. Cerebral vasodilation appears to be the initiating event. Vasodilation occurs in the brain in all persons ascending to high altitude, thus increasing cerebral blood flow and blood volume. Whether this is solely sufficient to cause the symptoms of mild AMS is unclear. However, in persons who progress to HACE, vasogenic edema is evident as increased T2
 signal on MRI. The leaky blood–brain barrier in HACE is due either to loss of autoregulation leading to overperfusion or to increased permeability caused by inflammatory mediators. A robust anti­inflammatory response leading to less disruption of the blood–brain barrier may be a key factor in
 those individual’s resistance to AMS. A combination of these two processes is also possible. The fact that dexamethasone so effectively treats AMS supports the hypothesis that vasogenic edema is critical to its development.
CLINICAL FEATURES
The diagnosis of AMS is based on characteristic symptoms within the context of a recent ascent to an altitude above 2000 m (6560 ft). On arrival, the person typically feels lightheaded and slightly breathless, especially with exercise. Characteristic symptoms develop between  and  hours later, but sometimes are delayed for  or  days, and may be worst upon awakening. Symptoms of mild AMS are similar to those of an ethanol hangover.
Headaches are usually bifrontal and worsen with exertion, bending over, or performing a Valsalva maneuver. GI symptoms include anorexia, nausea, and sometimes vomiting (especially in children). The chief constitutional symptoms are lassitude and weakness. The person with AMS can be irritable and often wants to be left alone. Sleepiness and a deep inner chill also are common. The Lake Louise AMS self­report questionnaire can be helpful in following the severity of the illness (Table 216­2).
Physical findings in mild AMS are nonspecific. Heart rate and blood pressure are variable and usually in the normal range, although postural hypotension may be present. Sa can be normal or slightly low for a given altitude. The percent Sa correlates poorly with the
O2 O2 diagnosis of AMS. Localized rales are detectable in up to 20% of persons with AMS. Fundoscopy reveals venous tortuosity and dilatation, and retinal hemorrhages are common at altitudes >5000 m (>16,400 ft) and in those with pulmonary and cerebral edema. Facial and peripheral edema sometimes
 accompanies AMS. With ascent, optic nerve sheath diameter increases due to edema but does not correlate with AMS development.
As the illness progresses, headache becomes more severe while vomiting and oliguria develop. Lassitude may progress so that the victim requires assistance in eating and dressing. The onset of ataxia or altered level of consciousness heralds progression to HACE. Coma may ensue within  hours if treatment is delayed. The diagnosis of AMS can be difficult in preverbal children; in these cases, AMS should be a diagnosis of
 exclusion.
The differential diagnosis in this setting includes carbon monoxide poisoning, dehydration, migraine, hypothermia, viral illness, and exhaustion.
Carbon monoxide poisoning may have a presentation very similar to that of AMS and is not uncommon in mountain towns in the winter. Reduced oxyhemoglobin levels complicate hypoxia from high altitude, and the effects are additive. Hypoxia may trigger a migraine headache in patients with a
,10 personal or family history of migraine. Unlike headaches from non­AMS causes (e.g., migraine), cephalalgia from AMS often dissipates within  to
 minutes of supplemental oxygen administration.
The average duration of AMS at a Colorado resort (3000 m or 9840 ft) was  hours, with a range of up to  hours. Half of those affected with AMS
 chose to self­medicate. At higher sleeping altitudes, the illness may last much longer (up to weeks if untreated) and is more likely to progress to
 pulmonary or cerebral edema. Eight percent of those with AMS at 4270 m (14,000 ft) in Nepal developed HAPE, HACE, or both.
TREATMENT
The goals of treatment (Table 216­3) are to prevent progression, treat symptoms, and hasten acclimatization. Early diagnosis is essential. Initial clinical presentation does not predict eventual severity, and all persons with AMS must be observed carefully for progression of illness. The three principles of treatment are (1) do not proceed to a higher sleeping altitude in the presence of symptoms, (2) descend if symptoms do not abate or become worse despite treatment, and (3) descend and treat immediately in the presence of symptoms of HACE or
HAPE. Descent is the definitive treatment for all forms of altitude illness. However, descent is not always an option, nor is it always necessary.
TABLE 216­3
Suggested Treatment Options for High­Altitude Illness
Mild AMS No further ascent
Descent to lower altitude or acclimatization at same altitude
Acetazolamide, 125–250 milligrams PO twice a day, to speed acclimatization
Symptomatic treatment as necessary with analgesics and antiemetics
Moderate/severe AMS Immediate descent for worsening symptoms
Low­flow oxygen if available
Acetazolamide, 250 milligrams PO twice a day, and/or dexamethasone,  milligrams PO every  h
Hyperbaric therapy
High­altitude cerebral edema Immediate descent or evacuation
Oxygen 2–4 L/min or titrated to Sa >90%
O2
Dexamethasone,  milligrams PO, IM, or IV, then  milligrams every  h
Hyperbaric therapy if patient cannot descend
High­altitude pulmonary Immediate descent or evacuation edema
Oxygen  L/min or titrated to Sa >90%
O2
Nifedipine,  milligrams PO extended­release every  h, or tadalafil,  milligrams PO every  h if no oxygen or descent* Hyperbaric therapy if patient cannot descend
Measures to minimize patient exertion and keep patient warm
Dexamethasone if cerebral signs present,  milligrams PO every  h
Periodic breathing/insomnia Acetazolamide, .5–125.0 milligrams PO at bedtime as needed
Abbreviations: AMS = acute mountain sickness; Sa = arterial oxygen saturation.
O2
*Drug therapy is unnecessary if oxygen is available.
Descent and Oxygen
Mild AMS is self­limited and generally improves with an extra  to  hours of acclimatization if ascent is halted. Remarkably, a drop in altitude of only
300 to 1000 m (980 to 3280 ft) is usually effective in ameliorating symptoms. Evacuation to a hospital or to sea level is unnecessary except in the most severe cases. To simulate descent, portable hyperbaric bags can be used to treat high­altitude illness (Gamow® bags). The patient is inserted into the
  fabric chamber, and a pressure of .9 kg/2.5 cm (2 lb/in ) is achieved by means of a manual or automated pump, equivalent to a drop in altitude of
1500 m (4920 ft). A valve system creates sufficient ventilation to avoid CO accumulation or oxygen depletion.

Oxygen effectively relieves symptoms, but to conserve supplies in the field, it is generally unavailable or reserved for those with moderate to severe
AMS. Oxygen supplementation quickly relieves headache and dizziness. Nocturnal administration of low­flow oxygen (0.5 to  L/min) is particularly helpful. The combination of oxygen and descent provides optimal therapy, especially in more severe illness.
Medical Therapy
Pharmacologic treatment offers an alternative to descent or oxygen in patients with mild to moderate AMS. Acetazolamide acts by inhibiting the enzyme carbonic anhydrase. Acetazolamide reduces renal reabsorption of bicarbonate, causing a bicarbonate diuresis and metabolic acidosis that stimulates ventilation. As a result, Pa rises and the deleterious effects of hypobaric hypoxia are reduced. The drug also maintains cerebral blood flow
O2 despite greater hypocapnia.
The treatment regimen for AMS varies: a dose of 125 milligrams PO twice daily is effective for most individuals, whereas others may require 250 milligrams PO twice daily. Side effects occur more commonly with higher doses, including peripheral paresthesias and sometimes nausea or drowsiness. Although acetazolamide contains a sulfhydryl moiety, cross­reactivity in those with sulfa
 antibiotic allergy is uncommon. Nevertheless, individuals with a history of anaphylaxis to sulfa antibiotics should avoid acetazolamide. Treatment should be continued until symptoms of AMS resolve. It can always be restarted if symptoms return. Because the drug inhibits carbonic anhydrase on the tongue, carbonated beverages such as soda or beer may have an altered or “flat” taste.
Although acetazolamide remains the standard of care for the treatment of AMS, a targeted approach focused on symptomatic treatment is a reasonable alternative, especially in those with intolerance or allergy to acetazolamide. Acetaminophen (650 to 1000 milligrams), ibuprofen (600 to 800 milligrams), and aspirin (650 milligrams) are all effective for altitude­related headache. Ondansetron,  to  milligrams as orally disintegrating tablets every  to  hours, effectively treats nausea and vomiting associated with AMS and should be the first­line antiemetic in this setting.
Dexamethasone,  milligrams PO, IM, or IV every  hours, is quite effective for mountain sickness, but is best reserved for cases of moderate to severe
AMS because of potential side effects. Given that dexamethasone does not aid acclimatization, some rebound symptoms may follow discontinuation. A short taper period may prevent rebound. It is often clinically useful to provide simultaneous therapy with acetazolamide (to speed acclimatization) and a brief course of dexamethasone (to treat symptoms). Another useful treatment regimen, but one that is not yet validated, is a one­time dose of
 dexamethasone followed by a course of acetazolamide. Dexamethasone is not useful for prophylaxis, however.
Frequent nighttime awakening is a common nuisance at high altitude. Before bedtime, acetazolamide, .5 to 125 milligrams, improves sleep oxygenation and reduces apneic periods, thereby improving sleep quality. Other safe sleep aids that do not cause respiratory depression include zolpidem, eszopiclone, and diphenhydramine (Table 216­4).
TABLE 216­4
Medications for High­Altitude Illnesses
Agent Indication Dosage Adverse Effects Comments
Acetazolamide Prevention 125–250 milligrams PO twice a day Common: paresthesias, Can be taken episodically for symptoms (speeds of AMS beginning  h before ascent and polyuria, altered taste of acclimatization); no rebound effect; pregnancy continuing during ascent and for at carbonated beverages category C, avoid in breastfeeding least  h after arrival at highest Less common: drowsiness, altitude nausea
Treatment 250 milligrams PO every 8–12 h of AMS
Pediatric  milligrams/kg/d PO in divided
AMS doses every 8–12 h
Periodic 125 milligrams PO  h before breathing bedtime
Dexamethasone Treatment  milligrams every  h PO, IM, or IV Mood changes, Rapidly improves AMS symptoms; can be of AMS hyperglycemia, dyspepsia lifesaving in HACE, may improve HACE enough to facilitate descent; no value in HAPE; pregnancy
HACE  milligrams initially, then  category C but preferably avoided in pregnancy or milligrams every  h PO, IM, or IV breastfeeding
Pediatric .15 milligram/kg every  h PO, IM,
HACE or IV, not to exceed  milligrams/d
Tadalafil Prevention  milligrams PO twice a day Headache, hypotension More effectively blunts hypoxic pulmonary of HAPE starting  d prior to ascent and (less than with nifedipine), vasoconstriction than sildenafil; better tolerated continuing for 2–4 d at maximum priapism (rare), than nifedipine; pregnancy category B sleeping altitude visual/hearing change or loss (extremely rare)
Nifedipine Prevention 20–30 milligrams extended­release Reflex tachycardia, of HAPE PO every  h hypotension (uncommon)
Treatment  milligrams extended­release PO No value in AMS or HACE; not necessary if of HAPE every  h supplemental oxygen available; pregnancy category C
Abbreviations: AMS = acute mountain sickness; HACE = high­altitude cerebral edema; HAPE = high­altitude pulmonary edema.
PREVENTION
Graded ascent with adequate time for acclimatization is the best prevention. A recommendation for those visiting moderate­altitude resorts in the western United States is to spend a night at an intermediate altitude of 1500 to 2000 m (4920 to 6560 ft) (Denver or Salt Lake City) before sleeping at altitudes >2500 m (>8200 ft). Mountaineers and trekkers should avoid abrupt ascent to sleeping altitudes over 3000 m (9840 ft) and allow two nights for each 1000­m (3230­ft) gain in camp altitude starting at 3000 m (9840 ft). Other preventive measures include avoiding overexertion, alcohol, and respiratory depressants.
Graded ascent is not always possible or practical. In such cases, a pharmacologic approach aimed at prevention of AMS may be warranted. The ideal prophylactic drug for AMS would be safe, cheap, and available over the counter given the millions of individuals at risk for AMS. Unfortunately, such a drug does not exist, and each approach has trade­offs.
Prophylactic acetazolamide benefits those with a history of AMS and those with forced rapid ascent to sleeping altitude above 2500 m. It remains the standard of care for prevention. Because acetazolamide prevents AMS by enhancing ventilatory acclimatization, fear of masking serious illness is unwarranted. For prophylactic use, acetazolamide should be started  hours before the ascent and should be continued for the first  days at altitude. It can be restarted if illness develops. Acetazolamide reduces the symptoms of AMS by approximately 75% in persons ascending rapidly to sleeping altitudes of >2500 m (>8200 ft). The downsides of acetazolamide include the commonly experienced paresthesias and, in rare cases,
 development of Stevens­Johnson syndrome. An alternative for those with anaphylaxis to sulfa is dexamethasone,  milligrams PO every  hours, starting the day of ascent and continuing for the first  days at altitude.
Several promising recent studies suggest that over­the­counter analgesics such as ibuprofen and acetaminophen are effective for AMS prevention. In
 one study of  individuals ascending above 3800 m (>12,000 ft), ibuprofen was shown to reduce the incidence of AMS from 69% to 43%. One theoretical drawback to ibuprofen is that it may exacerbate high­altitude gastropathy found in some patients at high altitude, theoretically leading to GI
,17  bleeding. When acetaminophen was compared to ibuprofen, both medicines performed similarly in reducing incidence of AMS. Conflicting evidence exists on the use of Ginkgo biloba for AMS prevention. A few studies indicate that a regimen of 100 milligrams twice a day started  to  days
,20 before ascent is effective in preventing AMS, but other studies have shown no benefit. Lack of standardization of gingko preparations may explain these conflicting results; the active ingredient is still unknown. Despite the variable results, ginkgo is a safe option for those who desire a natural
21­23 alternative. Neither iron nor budesonide is currently recommended for the prevention of AMS.
Preacclimatization
Although graded ascent is the most effective means of preventing altitude illness, this strategy is not always feasible. Numerous preacclimatization strategies have been proposed by commercial guiding services with the goal of reducing the incidence of altitude illness and to improve exercise performance while climbing. These preacclimatization protocols use intermittent exposure either to hypobaric hypoxia by use of hypobaric chambers or normobaric hypoxia through commercially available low­oxygen tents or breathing masks. These strategies vary considerably in their use of hypoxic
“dose” (simulated altitude), duration of exposure, and overall number of exposures over a period of days. Although many of these strategies induce
,25 physiologic responses suggestive of acclimatization, only a few are able to demonstrate a significant decrease in AMS incidence. An efficient and effective preacclimatization strategy has yet to be determined.
HIGH­ALTITUDE CEREBRAL EDEMA
HACE is defined by progressive neurologic deterioration or ataxia in an individual who has recently ascended to high altitude. Headache, nausea, and vomiting are common antecedents to HACE but are not always present. HAPE is concomitantly found in roughly half of cases of HACE. The diagnosis should be made clinically and is characterized by altered mental status, ataxia, stupor, and progression to coma if untreated. Raised intracranial pressure can lead to focal neurologic signs such as third or sixth cranial nerve palsies. HACE at intermediate altitudes is exceedingly rare, with reported cases precipitated by severe hypoxia associated with HAPE and/or a preexisting space­occupying cerebral lesion.
Treatment of HACE is oxygen supplementation, descent, and steroid therapy (Tables 216­3 and 216­4). Descent is the highest priority. In acutely ill patients who cannot descend, a combination of steroids, supplemental oxygen, and a hyperbaric bag constitutes optimal therapy, but it is rare that all of these are available. Persons remaining ataxic or confused after descent should be admitted to hospital. The possibility of encephalitis or meningitis, stroke, or subarachnoid hemorrhage should be considered in patients whose condition does not improve with treatment. Typically, the partial pressure of arterial CO is already low and the pH high; thus, further hyperventilation could exacerbate cerebral
 ischemia. Acetazolamide may be used as an adjunct for acute management in the field. Evidence is lacking for the use of hypertonic saline, loop diuretics, or mannitol in HACE. Coma may persist for days, even for weeks, after evacuation to lower altitude, yet the patient may still recover.
Persistent coma is sufficiently unusual that its presence mandates exclusion of other causes of neurologic deterioration. MRI findings of HACE include
 reversible white matter edema evidenced by increased T2 signal, especially in the splenium of the corpus callosum (Figure 216­1). Hemosiderin
 depositions in the corpus callosum may be detected by MRI for years after a case of HACE; this may be useful in the setting of diagnostic uncertainty.
FIGURE 216­1. MRI of a 34­year­old male high­altitude mountaineer with high­altitude cerebral edema. The arrows indicate the markedly increased T2 signaling in the splenium of the corpus callosum indicating edema.
HIGH­ALTITUDE PULMONARY EDEMA
HAPE accounts for more altitude­related mortality than HACE, since it occurs more frequently. While treatable with the right resources, death occurs due to a failure of early recognition, misdiagnosis, or inability to descend to a lower altitude. The condition is easily reversible with descent and oxygen administration.
The incidence of HAPE varies from <1 in ,000 skiers in Colorado to 2% to 3% of climbers on Mount Denali. Women appear less susceptible than men.
Risk factors include heavy exertion, rapid ascent, cold, excessive salt ingestion, use of a respiratory depressant, a previous history indicating inherent individual susceptibility, and pulmonary hypertension. Genetic factors include diminished lung epithelial sodium channel activity, excessive hypoxic
,28 pulmonary hypertension, and immunogenetic factors. Pulmonary hypertension from any cause greatly predisposes to HAPE. As a result, HAPE has been reported in patients with intracardiac shunts (atrial septal defect, patent ductus arteriosus, patent foramen ovale), congenital absent pulmonary
,30 artery, drug­induced pulmonary hypertension (phentermine), and chronic venous thrombotic disease. Preexisting respiratory infection may
 predispose children to HAPE.
PATHOPHYSIOLOGY
HAPE is a noncardiogenic, hydrostatic edema; left ventricular function is normal. Left ventricular end­diastolic pressure, pulmonary artery wedge pressures, and left atrial pressures are low to normal, cardiac output is low, and pulmonary vascular resistance and pulmonary artery pressure are markedly elevated. The culprit in HAPE is high microvascular pressure. Pulmonary hypertension is an essential component, but not all persons with pulmonary hypertension develop HAPE. Predisposed individuals have a low hypoxic ventilatory response paired with exaggerated vasoconstriction within the microcirculation of the lung. These individuals tend to experience recurring HAPE on repeated exposures to high altitude. Inflammation is not present early in the course of HAPE, as measured by the chemical composition of bronchoalveolar lavage fluid, but appears as secondary finding as

HAPE progresses.
CLINICAL FEATURES
The differential diagnosis of shortness of breath at altitude is broad and includes pneumonia, pulmonary embolism, myocardial infarction, congestive heart failure, mucous plugging, hypoxia with mild exercise intolerance, and bronchitis. Early in the course of HAPE, the individual develops a dry cough, decreased exercise performance, dyspnea on exertion, and increased recovery time from exercise. Localized rales, usually in the right mid­lung field, are common. Resting percent Sa is often  to  points lower than normal for a given altitude and will drop further with exertion. Comparing oxygen
O2 saturation of a symptomatic individual to others without dyspneic symptoms can be a useful test in the field and requires only a portable pulse
 oximeter. Late in the course of the illness, tachycardia, tachypnea, dyspnea at rest, marked weakness, productive cough, cyanosis, and more generalized rales develop. As hypoxemia worsens, altered mental status progresses to coma.
Because early diagnosis is critical, decreased exercise performance or dry cough should raise the suspicion of early HAPE.
Progression of dyspnea with exertion to dyspnea at rest is a hallmark of HAPE. The typical victim is strong and fit (which are factors that facilitate quick ascent) and may or may not have symptoms of AMS before the onset of HAPE. The condition typically worsens at night and is most commonly noticed on or after the second night at a new altitude. Rales are not audible in 15% of persons with HAPE at rest, but can be elicited immediately after a short bout of exercise. Low­grade fever is common, and tachycardia and tachypnea generally correlate with the severity of illness.
On cardiac auscultation, a prominent P and right ventricular heave may be appreciated. ECG may reveal right­axis deviation and a right ventricular
 strain pattern consistent with acute pulmonary hypertension. Chest radiographic findings progress from interstitial to localized alveolar to generalized alveolar infiltrates as the illness progresses from mild to severe (Figure 216­2). The absence of infiltrates should alert the clinician to the possibility of
 an alternative diagnosis. US is accurate to diagnose HAPE.
FIGURE 216­2. Chest radiograph of an 11­year­old girl with reentry high­altitude pulmonary edema at 2670 m (8750 ft).
TREATMENT
The key to successful treatment of HAPE (Tables 216­3 and 216­4) is early recognition; the condition in its early stage is easily reversible. The optimal therapy depends on the environmental setting, evacuation options, availability of oxygen or hyperbaric units, and ease of descent. Immediate descent is the treatment of choice, but this is not always possible. During descent, exertion by the patient must be minimized. Reports of patients dying during descent probably are related to overexertion that offsets the benefit of lower altitude. Oxygen supplementation produces excellent results and can completely resolve the pulmonary edema without descent to a lower altitude, but it may require  to  hours to do so. In settings such as Colorado ski resorts, for example, keeping the patient at altitude but on oxygen may be a practical option. However, the required quantities of oxygen are rarely available to trekking, mountaineering, and back­country skiing groups. Oxygen immediately lowers pulmonary artery pressure and improves arterial oxygenation. Its use is lifesaving when descent is not an option; in such cases, rescue groups should prioritize delivery of oxygen to the victim. As in the treatment of AMS and HACE, the portable hyperbaric bag is a useful adjunct to therapy when immediate descent is not possible.
Bed rest may be adequate for very mild cases, and bed rest with supplemental oxygen may suffice for moderate illness, as long as the safety of the patient can be ensured by the presence of a medical facility, adequate oxygen, or immediate descent capability should the patient’s condition
 deteriorate. Because cold stress elevates pulmonary artery pressure, the patient should be kept warm.
Because oxygen supplementation and descent are so effective, experience with drugs has been limited. Nifedipine, either as a 10­milligram capsule or

30­milligram extended­release formulation, can reduce pulmonary artery pressure by 30% to 50% but increases Sa only slightly. Nifedipine, 
O2
 milligrams (slow­release preparation) every  hours while ascending, provides effective prophylaxis in those who have previously experienced HAPE.

The phosphodiesterase­5 inhibitors sildenafil and tadalafil blunt hypoxic pulmonary vasoconstriction through generation of nitric oxide. Tadalafil,

 milligrams PO twice a day  hours prior to ascent, effectively prevents HAPE in susceptible individuals. These agents may also prove to be useful for treatment of HAPE when oxygen is unavailable. It should be noted that when oxygen is available, additional treatment with drugs such as nifedipine
 may be unnecessary.

Inhaled salmeterol twice a day reduces the incidence of HAPE by 50% in persons with previous repeat episodes of HAPE. The mechanism is presumed to be upregulation of the epithelial sodium channel and increased clearance of alveolar fluid. Although β­agonists have not yet been studied for the treatment of HAPE, their likely benefit and appealing safety profile make their use for treatment of HAPE reasonable. However, none of these agents is as effective as oxygen administration or descent, which still remain the treatments of choice.
Hospitalization is warranted for severe illness that does not respond immediately to descent, especially if cerebral edema is present. Intubation, oxygen supplementation with a high fraction of inspired oxygen (FIO ), and positive end­expiratory pressure ventilation are rarely required. Antibiotics
 are indicated for coexisting infection when present. Measurement of brain natriuretic peptide level or echocardiography may be needed to exclude a cardiac component of edema in persons with potential heart failure. Patients with HAPE who do not make the usual rapid improvement or who develop the condition at <2500 m (<8200 ft) should be evaluated for pulmonary emboli or other anatomic abnormalities, such as congenital absence of a pulmonary artery or intracardiac shunt. Echocardiography with bubble contrast material can assess for the presence or absence of shunting from a patent foramen ovale or other cardiac abnormality.
Adequate discharge criteria are progressive clinical and radiographic improvement plus Pa of  mm Hg or Sa of >90%. Residual effects such as
O2 O2 fibrosis or abnormal pulmonary function tests have not been reported. An episode of HAPE is not a contraindication to subsequent ascent. However, patients should be counseled regarding the importance of staged ascent and of recognizing early signs and symptoms; prophylaxis with acetazolamide along with tadalafil, sildenafil, or nifedipine may also be wise.
OTHER ALTITUDE SYNDROMES
PERIPHERAL EDEMA
Swelling of the face and distal extremities is common at high altitude. Peripheral edema was reported in 18% of trekkers at 4200 m (13,800 ft) in Nepal
 and was twice as common in women. It often was associated with AMS but not in all cases. The presence of peripheral edema should raise suspicion of altitude illness and prompt a thorough examination for pulmonary and cerebral edema. The problem can be treated with diuretics but will resolve spontaneously with descent.
HIGH­ALTITUDE RETINOPATHY
Retinal abnormalities described at high altitude include retinal edema, tortuosity and dilatation of retinal veins, disc hyperemia, retinal hemorrhage, and, rarely, cotton­wool exudates. Retinal hemorrhages are asymptomatic, except for rarely occurring macular hemorrhages, and are not considered an indication for descent unless vision changes are present. They resolve spontaneously in  to  days. Hemorrhages are common at sleeping altitudes of >5000 m (>16,400 ft) and occur at lower altitudes in persons with altitude illness.
HIGH­ALTITUDE BRONCHITIS
Many unacclimatized persons exercising at altitudes of >2500 m (>8200 ft) develop a dry, hacking cough. Breathing high volumes of dry, cold air may induce respiratory heat loss, secretions, and bronchospasm. As in cough­variant asthma, fast­acting β­agonists (e.g., albuterol) delivered by metereddose inhaler may provide relief from these coughing spasms. Prophylactic use of long­acting β­agonists and inhaled steroids may be useful for prevention of debilitating cough. Humidification units may help indoors, while wearing a balaclava or a similar thin fabric layer over the mouth and nose may help keep the airway moist and reduce coughing fits.
CHRONIC MOUNTAIN POLYCYTHEMIA/CHRONIC MOUNTAIN SICKNESS
Monge’s disease, also called chronic mountain sickness, has been recognized in all high­altitude locations of the world. Both long­term high­altitude residents and lowlanders who relocate to high altitude may develop this condition after variable lengths of residence. Males have a much higher incidence, and incidence also increases with age. The disease is characterized by excessive polycythemia for a given altitude, which causes symptoms such as headache, muddled thinking, difficulty sleeping, impaired peripheral circulation, drowsiness, and chest congestion. The diagnosis is based on presence of the characteristic symptoms and a hemoglobin value greater than expected for the altitude, generally >20 to  grams/dL.
Therapy includes phlebotomy, relocation to a lower altitude, or home oxygen use. Respiratory stimulants such as acetazolamide (250 milligrams PO twice a day) and medroxyprogesterone acetate (20 to  milligrams PO twice per day) also have been used successfully. The response to respiratory stimulants supports the role of hypoventilation in this disorder.
SPECIAL POPULATIONS
INDIVIDUALS WITH ILLNESSES AGGRAVATED BY HIGH ALTITUDE
Chronic Lung Disease
Patients with chronic obstructive pulmonary disease ascending to altitude often report increased dyspnea and reduced exercise performance. Patients with hypoxemia, pulmonary hypertension, disordered control of ventilation, and sleep­disordered breathing at sea level may require supplemental oxygen at altitude because of greater alveolar hypoxia. Patients who are oxygen dependent at sea level will need to increase their FIO . The required

FIO can be calculated by multiplying low­altitude FIO by the ratio of low­altitude barometric pressure to high­altitude barometric pressure. This will
  ensure the delivery of the same P as at low altitude.
O2
Cardiovascular Disease
A healthy heart and cardiovascular system can tolerate even extreme hypoxia remarkably well. Examinations of numerous ECGs, echocardiograms, heart catheterization findings, and exercise test results demonstrate no cardiac ischemia or cardiac dysfunction in healthy persons at high altitude, even when Pa is <30 mm Hg. Those with atherosclerotic disease may not have the same adaptive capabilities and intuitively seem more likely to
O2
 experience acute cardiac events. Epidemiologic data, however, do not support this supposition. Long­term residence at high altitude reduces
,44 morbidity and mortality from atherosclerotic heart disease, and visitors apparently do not have increased risk of acute myocardial infarction.
Ischemia may be provoked with less exercise during the first few days at 2500 m (8200 ft) among persons with coronary artery disease; however, after 
 days of acclimatization, patients perform at their sea­level exercise capacity without increased or early­onset angina.
Congestive heart failure may worsen in tourists arriving at the moderate altitude of ski resorts; this is related to fluid retention rather than depressed ventricular function from hypoxia. Therefore, patients with congestive heart failure should maintain or increase their diuretic dosage during travel to high altitude, and clinicians may consider administering low­flow oxygen during sleep to patients with congestive heart failure, at least for the first few nights after arrival at altitude.
Ascent to altitude produces a mild but variable increase in blood pressure in normotensive and hypertensive persons, secondary to increased sympathetic tone. Patients should continue hypertensive medications at altitude, monitor blood pressures, and, in some cases, temporarily adjust medication doses. No data suggest that hypertensive patients have a higher risk for any of the altitude illnesses. Hypertension is not a contraindication to altitude exposure.
Neurologic Syndromes of High Altitude
Until recently, most neurologic events at high altitude were attributed to HACE or AMS. Clearly, this is oversimplification. Other syndromes now recognized as related to high altitude include altitude syncope, cerebrovascular spasm (migraine equivalent), cerebral arterial or venous thrombosis
(infarct), transient ischemic attack, and cerebral hemorrhage. These syndromes are characterized by more focal neurologic findings than in cerebral edema, although differentiation in the field may be difficult. Previously asymptomatic conditions may be unmasked by exposure to altitude: Spaceoccupying lesions may be revealed as the brain volume increases; hyperventilation can reveal seizure disorders, and arteriovenous malformations may hemorrhage due to changes in cerebral blood flow. Focal neurologic signs should be thoroughly evaluated and not attributed to altitude illness.
Other symptoms may be due to exacerbation or unmasking of underlying disease, such as previously asymptomatic brain tumors and epilepsy.
Presumably, space­occupying lesions become symptomatic because of increased brain volume at altitude. Hyperventilation (hypocapnic alkalosis), which is commonly used to induce seizure activity on electroencephalography, may explain unmasking of seizure disorder at altitude. Changes in cerebral blood flow may exacerbate preexisting vascular lesions such as aneurysm or arteriovenous malformation, leading to spontaneous intracerebral hemorrhage.
In the field, it is reasonable to treat neurologic events as if cerebral edema were present, with rapid descent to lower altitude, oxygen supplementation, administration of steroids, and evacuation to hospital if symptoms persist. It is prudent to avoid use of agents that may contribute to hypotension and decrease cerebral perfusion.
Sickle Cell Disease
Even the modest cabin altitude of pressurized aircraft (1500 to 2000 m [5000 to 6600 ft]) may cause persons with hemoglobin SC and sickle cell– thalassemia disease to experience vaso­occlusive crisis. Exposure to high altitude thus requires oxygen supplementation for such individuals. At high altitudes, left upper quadrant pain should alert the physician to consider splenic infarction syndrome. Sickle cell trait is not considered a risk factor for most high­altitude conditions, although splenic infarction has been reported.
Pregnancy
Pregnant women who live at high altitude have an increased prevalence of hypertension, delivery of low­birth­weight infants, and neonatal hyperbilirubinemia in their offspring. However, although data are limited, an increased incidence of pregnancy complications in lowlanders who visit
 high altitude has not been reported. The normal Pa of the fetus is  to  mm Hg, and the mild maternal hypoxia induced by traveling to resort­
O2 type altitudes does not generate significantly more hypoxic stress. Few data exist regarding exercise in pregnancy at altitudes of >2500 m (>8200 ft), so a conservative approach should be used. Pregnant women should avoid altitudes—generally speaking, a sleeping altitude of 3000 m (10,000 ft)—at
 which Sa falls to <85%. Perhaps of more concern than mild hypoxia is the fact that high­altitude locations are often remote from medical (and
O2 obstetric) facilities. Patients need to be aware that without access to sophisticated medical care, complications may be associated with more serious consequences. Patients with high­risk pregnancies should stay at low altitude.


