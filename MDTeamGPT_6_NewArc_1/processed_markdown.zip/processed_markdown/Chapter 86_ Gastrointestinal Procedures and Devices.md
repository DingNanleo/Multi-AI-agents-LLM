## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 86: Gastrointestinal Procedures and Devices
Michael D. Witting
INTRODUCTION
Gastric Tamponade for Variceal Bleeding September 2020
Details of Sengstaken­Blakemore and Minnesota Tube placement, for control of massive life­threatening bleeding from esophageal varices, are provided in the section on Balloon Tamponade.
NASOGASTRIC ASPIRATION
Nasogastric (NG) aspiration is used to remove liquid contents from the stomach and decompress the stomach and small bowel. The need for NG aspiration often varies with the clinical presentation (Table 86­1). Gastric decompression is useful in small bowel obstruction, although some studies
,2 have shown that medical therapy with octreotide or somatostatin has allowed safe treatment of bowel obstruction associated with malignancy. NG
,4 aspiration and decompression are no longer considered routine for the treatment of adynamic ileus. Removal of liquid contents is useful in cases of GI bleeding, but most patients with GI bleeding can be managed without NG aspiration.
TABLE 86­1
Selection of Patients for Nasogastric Aspiration
Clinical Situation Best Uses Consider Withholding
GI bleeding with Rapid bleeding (large hematemesis, refractory Slow or mild bleeding (coffee grounds, blood­streaked emesis) hematemesis hemodynamic instability)
GI bleeding without Massive rectal bleeding with hemodynamic Clinical picture suggests lower GI source (bright red blood per rectum, age >50 hematemesis instability y, blood urea nitrogen/creatinine <30)5
Small bowel dilation Small bowel obstruction Ileus

In GI bleeding, a common and controversial situation for NG aspiration, aspiration of stomach contents can localize the source of bleeding, indicate the rate of bleeding, and clear the stomach for endoscopy. Patients with hematemesis virtually always have an upper GI source, and NG aspiration is helpful to assess the rate of hemorrhage rather than identify the source. In significant upper GI bleeding, such as suggested by refractory hemodynamic instability or large quantities of bright red bloody emesis, the rate of bleeding can determine the success of medical interventions and the need for emergent endoscopy. When the clinical picture suggests a slower rate of bleeding, such as with coffee­ground emesis or blood­streaked emesis, the need for NG aspiration is less clear because less sensitive methods of assessing the rate of hemorrhage, such as observation of spontaneous bleeding, hemodynamic assessment, and serial hematocrit measurement, are often adequate.
,8
In patients without hematemesis, NG aspiration lacks sensitivity to detect an upper GI source. Although it has been reported that 10% of patients
 with hematochezia have an upper GI source, many of these are from a duodenal source and are beyond the reach of the NG tube. Most patients with mDoewlennlao ahdaeved a2n0 2u5p­p7e­r1 G 5I :s5o5u Prc e Y aonudr rIePq iusi r1e3 u6p.1p4e2r .e1n5d9o.1s2co7py regardless of the results of NG aspiration. In severe, ongoing rectal bleeding with
Chapter 86: Gastrointestinal Procedures and Devices, Michael D. Witting hemodynamic instability, NG aspiration is relatively useful because severe upper GI bleeding is generally easier to stop than severe lower GI bleeding.
. Terms of Use * Privacy Policy * Notice * Accessibility
The literature is riddled with case reports of bizarre mishaps resulting from the use of NG tubes, some of which are listed in Table 86­2. However, the rate of adverse effects has not been systematically addressed. The main morbidity from the procedure is probably related to pain, followed by epistaxis, both of which can be minimized by good technique.
TABLE 86­2
Complications of Placement of Nasogastric and Nasoenteric Tubes
Epistaxis
Intracranial placement
Bronchial placement
Pharyngeal placement
Esophageal obstruction or rupture
Bronchial or alveolar perforation
Pneumothorax
Charcoal instillation into the lungs and pleural cavity
Gastric or duodenal rupture
Vocal cord paralysis
Pneumomediastinum
Laryngeal injuries
Knotting (preventing removal)
The equipment required for NG tube insertion is listed in Table 86­3. The optimal positioning is with the patient seated upright with the neck slightly flexed. Topical application of anesthetic can reduce the pain of the procedure, and a vasoconstrictor can shrink the turbinates, creating a larger nasal opening, but use a vasoconstrictor with caution in hypertensive patients. One option is to mix 4% lidocaine with oxymetazoline and instill this solution
  using a nasal atomizer. Nebulized lidocaine also provides effective analgesia. Although it is tempting to use viscous lidocaine on the tip of the tube instead of premedication, this maneuver does not allow time for the lidocaine to be effective. A right­handed operator may choose the right side or the
12–14 side of patient preference. Premedication with IV metoclopramide, in adults, or lingual 24% to 25% sucrose, in infants, may also decrease pain.

Also, in adults, premedication with a small dose of midazolam (2 milligrams) improves pain relief compared with topical anesthesia alone.
TABLE 86­3
Equipment for Nasogastric Tube Insertion
Absorbent pad (blue Chux®)
Kidney basin
Materials for anesthesia and vasoconstriction
Nebulizer or nasal atomizer
Local anesthetic (4% lidocaine)
Vasoconstrictor (oxymetazoline, phenylephrine)
Water­soluble lubricant
Cup of water with straw
Nasogastric Salem sump tube—16F
Catheter­tip syringe
Tubing connected to suction device, such as wall suction
Describing the procedure to the patient in advance and talking to the patient during the procedure will minimize anxiety. Insert the lubricated tube into the selected nostril. Direct the tube posteriorly, not superiorly, and it should naturally bend inferiorly toward the glottis. Resistance is expected at the level of the glottis. At this point, have the patient take a drink of water, and advance the tube at the time of swallowing. This step minimizes the potential for false passage at the level of the glottis. Warming the distal tip of the tube will make it more pliable and may further decrease the pain of the procedure. Once the tube is past the glottis, quickly advance the tube and aspirate stomach contents. If the patient coughs during the procedure, stop and make sure that the patient can speak clearly. Failure to aspirate stomach contents should prompt visualization of the pharynx to ensure the tube is not coiled in the posterior pharynx. If the appearance of the gastric aspirate is inconclusive, its pH can be tested, or air can be insufflated during auscultation over the stomach (Table 86­4). A chest radiograph can also be obtained to confirm tube placement. If the NG tube is to remain in place, it can be taped to the patient’s nose and connected to low­intermittent suction.
TABLE 86­4
Techniques for Identifying Nasogastric and Nasointestinal Feeding Tube Placement
Indicates gastric placement
Epigastric auscultation of air insufflated through the tube
Aspiration of visually recognizable GI secretions pH testing of aspirates (pH <6 indicates gastric placement)
Indicates tracheobronchial placement
Coughing or choking
Inability to speak
Air bubbles when proximal end of tube is placed in water
Some situations make NG tube insertion more difficult, such as obstructed nares, lack of patient cooperation, or endotracheal intubation. In patients with obstructed nares, the orogastric route may be used, although this is often less comfortable than the NG route. In obtunded patients with a poor gag reflex, endotracheal intubation may prevent aspiration. In patients with endotracheal intubation, flexing the neck or cooling the tube in ice water to stiffen it may facilitate passage.
ANOSCOPY
Anoscopy can identify an anorectal cause of bleeding in patients with hematochezia. Although an uncomfortable test, it is safe if performed properly.
Contraindications include suspected rectal perforation. For detailed description of technique, see Chapter  “Anorectal Disorders.”
OROGASTRIC LAVAGE
Orogastric lavage is used to remove pills and fragments from the stomach. It is only appropriate for patients presenting well within  hour after a
 potentially lethal ingestion. Because an NG tube is too small to retrieve pill fragments, gastric lavage for solids is done orally with a large­bore tube.
Gagging and vomiting during the procedure are common, and aspiration is a significant risk, particularly when airway protection is in doubt. Many other complications are possible, including tube misplacement into the bronchi, pharyngeal injury, and viscus perforation. Endotracheal intubation before this procedure can minimize these risks when a patient is, or may become, obtunded.
Equipment for the procedure includes a large­bore tube, such as the Ewald tube ® or the Tum­E­Vac ® (Ethox Corp, Buffalo, NY); lubricant; suction; emesis basin; blue absorbent pad; a catheter­tip syringe; irrigation fluid; and a bite block or oral airway to prevent patients from biting down on the tube. Patient positioning, tube advancement, and confirmation of placement are similar to NG tube insertion, but be especially sure to aim the proximal end away from others. After inserting a bite block in uncooperative patients, insert the gastric tube to the level of the glottis, and encourage the patient to swallow. Then pass the tube quickly into the stomach. Coughing or airflow from the tube raises concern for tracheal malpositioning.
Have the patient vocalize to exclude tracheal placement. After suction and irrigation of gastric contents, charcoal and sorbitol can be instilled before withdrawal of the tube.
SENGSTAKEN­BLAKEMORE AND MINNESOTA BALLOON TAMPONADE
The Sengstaken­Blakemore and the Minnesota tubes provide direct balloon tamponade for uncontrolled, life­threatening bleeding from esophageal varices, as a temporizing measure until definitive treatment (Figure 86­1). With the increasing availability of endoscopy and success of medical therapy with octreotide, somatostatin, and vasopressin, their use has declined. Nevertheless, balloon tamponade still has a role in cases in which endoscopy is unavailable or hemorrhage is refractory to endoscopic techniques. In one series, most survivors received a transjugular intrahepatic
 portosystemic shunt procedure after balloon tamponade.
Figure 86­1
A. Sengstaken­Blakemore tube. B. Insertion of Sengstaken­Blakemore tube.
The Sengstaken­Blakemore (S­B) Tube is a  lumen tube which allows aspiration of gastric contents. A nasogastric tube is usually inserted alongside the SB tube, to the level 3­4 cm proximal to the esophageal balloon, to aspirate esophageal contents. The Minnesota Tube has  lumens and can aspirate esophageal and gastric contents. The procedure for both tubes is complex and it is best to have algorithms available so the insertion steps can be followed accurately and complications are minimized. Due to the high risk of aspiration, intubate the patient before insertion.
Check the esophageal and gastric balloons for leaks. Then deflate the balloons. When placing the S­B tube, tie the nasogastric tube to the S­B tube with its tip 3­4 cm proximal to the esophageal balloon. This step is not needed with the Minnesota tube. Note the  cm depth marker on the S­B or o
Minnesota tubes, as you will insert the tube to the 50­cm mark. Place the patient supine elevated to  . Insert the tube orally to  cm, inflate the gastric port with  cc air and confirm tube placement with chest xray or US to make sure the tube is in the stomach. After confirming tube placement, inflate the gastric tube in  cc increments up to 250 cc for the S­B tube, or 450 cc for the Minnesota tube. Do not inflate the esophageal tube. Apply gentle traction to the tube. A 1­L bag of NS suspended over an IV pole will produce about  kg of traction. Mark the end of the tube to make sure it does not migrate cephalad into the esophagus during traction. Because varices are often at the gastroesophageal junction, this usually stops the bleeding. If not, expand the esophageal balloon to  mm Hg, using a manometer to guide the pressure. To maintain traction, tape the proximal end of the tube to the face guard of a baseball catcher’s mask or lacrosse helmet that has been already placed onto the patient.
Once the tube is in place, maintain traction to the minimum amount necessary to stop the bleeding to minimize the risk of tissue ischemia. Maintain balloon tamponade for up to  hours until more definitive measures can be taken.
ABDOMINAL PARACENTESIS
In paracentesis, ascitic fluid is removed for diagnostic or therapeutic purposes. Patients with ascites and abdominal pain or other GI symptoms may have peritonitis, requiring diagnostic paracentesis. This may be true even if the abdominal pain is mild and unaccompanied by signs of systemic
 infection. Patients with respiratory compromise or severe pain due to tense ascites require therapeutic paracentesis, in which a large quantity of fluid, often greater than  L, is removed. Large­volume paracentesis, in which greater than  L is removed, is time­consuming and associated with complications such as hyponatremia, renal impairment, and encephalopathy. Many of these patients require other treatment, including albumin
,20 infusion. Therefore, it is generally best reserved for the admitting team or ED observation unit, except in rare cases in which pain or respiratory compromise cannot be controlled in the ED with medications or supplemental oxygen. Other risks of paracentesis in general, whether diagnostic or therapeutic, include bowel perforation, ascitic fluid leak, hemorrhage, and introduction of infection.
Equipment for diagnostic paracentesis (See Video: Abdominal Paracentesis) includes sterile drapes (both fenestrated and nonfenestrated), sterilizing solution (povidone­iodine or chlorhexidine), gauze, assorted syringes (3, , or  mL), a small­bore (27­gauge or smaller) needle, three medium­bore (21­gauge) needles, local anesthetic (lidocaine), and containers for cell count and culture for the laboratory. If paracentesis is also to be therapeutic, a three­way stopcock, sterile tubing, and a source of suction—either vacuum bottles or a setup for wall suction—are necessary, and a large­bore needle or plastic catheter (18­ or 16­gauge) will speed the procedure. Ultrasonography can confirm ascites and identify a target fluid collection to minimize the potential for bowel perforation (Figure 86­2). US guidance can also assist the operator in avoiding subcutaneous vessels
 dilated by portal hypertension, and it decreases the risk of bleeding.
Video 86­1: Abdominal Paracentesis
Used with permission from Ian B.K. Martin and Benjamin Leacock, Department of Emergency Medicine, University of North Carolina.
Play Video
FIGURE 86­2
US view of a desirable puncture site for paracentesis (arrow).
,23
If the patient has severe coagulopathy (INR >2.5) or thrombocytopenia (platelets <50,000/μL), consider correcting deficiencies before paracentesis.
Place the patient in a comfortable supine position, and cleanse and sterilely prepare the site of expected needle insertion. The left lower quadrant is generally a good area because this minimizes the potential for liver injury, but the right lower quadrant may also be used if the left lower quadrant has distorted anatomy, such as with prior scarring or ostomy surgery (Figure 86­3). Anesthetize the skin over the target area by raising a wheal, and then switch to a larger­bore needle to infiltrate to the level of the peritoneum. A Z­track technique, in which traction on the skin is used to create a displaced
 track to the peritoneum, can minimize the potential for infection and persistent leakage. At a depth expected to be near the peritoneum, apply suction to the syringe and infiltrate lidocaine while advancing until peritoneal fluid is aspirated. Once the fluid is aspirated, change the syringe with the needle still in place, and then aspirate at least  mL of fluid into the fresh syringe for laboratory analysis. In therapeutic paracentesis, attach tubing to the needle, catheter, or stopcock, and connect to suction. Even if the goal is diagnosis, removal of  to  L is unlikely to cause complications and may provide significant symptomatic relief. Then withdraw the needle or catheter and cover the insertion site with a dressing. A purse­string suture can be placed to minimize leakage. Recheck the patient in  minutes to identify persistent leakage or an increase in symptoms to suggest a complication.
Patients with large­volume paracentesis should be monitored for hypotension for several hours after the procedure. Cover the puncture site with a dry dressing for  hours.
FIGURE 86­3
Sites for needle introduction in the left or right lower quadrant (x) for abdominal paracentesis.
TRANSABDOMINAL FEEDING TUBES
Although the techniques for the initial placement of transabdominal feeding tubes (gastrostomy [G­tube], jejunostomy [J­tube], and gastrojejunostomy) are beyond the scope of emergency physicians, complications related to these tubes need to be recognized (Table 86­5). These tubes can be placed by a surgeon using open technique, by a gastroenterologist using endoscopic technique (percutaneous endoscopic gastrostomy), or by a radiologist with percutaneous techniques. The radiographic technique has been associated with fewer complications than has open or
 endoscopically assisted placement.
TABLE 86­5
Complications Seen With Transabdominal Feeding Tubes
Complication Initial Considerations
Leakage from stoma Check outer bolster position, consider tube malposition.
Tube occlusion Attempt irrigation; most often, just replace.
Dislodged tubes Gently replace; confirm placement with x­rays.
Pneumothorax High index of suspicion; consider needle aspiration.
Bacteremia Consider as potential source in septic patient.
Bleeding from tract If recently inserted, consider local injection, consult.
Bleeding from granuloma buildup Local therapy with silver nitrate.
Infection of surrounding skin Consultation, pull tube, IV antibiotics.
Necrotizing fasciitis Consider MRI to help confirm; surgical debridement.
Peritonitis Determine if fistula exists; consultation, IV antibiotics.
Pulmonary aspiration of feedings Reduce flow rate, half­strength feeds, consider J­tube.
Vomiting or diarrhea Reduce flow rate, half­strength feeds, stop feeds.
Gastroesophageal reflux Reduce flow rate, half­strength feeds, consider J­tube.
Intestinal obstruction Step feedings, NPO, admit, and observe.
Gastric outlet obstruction Reposition tube.
Gastric volvulus Surgical consult.
Gastric perforation Surgical consult.
Esophageal perforation Surgical consult.
Colonic perforation Surgical consult.
Colocutaneous fistula Surgical consult.
Electrolyte abnormalities Change feedings or increase free water.
GI bleeding Endoscopy and therapy directed at cause.
Bolster buried in abdominal wall Surgical consult.
Abbreviations: J­tube = jejunostomy tube; NPO = nothing by mouth.
Frequent minor complications are associated with the use of these tubes, including purulent drainage and leakage around the stomal site, clogging, dislodgement, diarrhea, and vomiting.
Drainage from the stomal site is a common finding and represents a foreign­body reaction due to the catheter. As long as there is no evidence of cellulitis or necrotizing fasciitis, local skin care will usually clear up the problem. Local bleeding from granuloma formation may be treated with silver nitrate.
Leakage of gastric contents is a common problem. Gastric contents may leak due to excessive pressure between bolsters, which can limit blood flow

(Figure 86­4). Leak can also result from excessive tube mobility, either in­and­out (from excessive distance between bolsters) or side­to­side. Tube malposition can also cause leakage. Management strategies include gently withdrawing the tube and adjusting the outer bolster, tube replacement, or
 removing the tube for  to  hours to allow healing (if tract is mature). CT or plain radiographs, after injection of gastrograffin through the tube, can be used to assess placement of the original or replaced tube. Consider surgical consultation for assistance with bolster adjustment or tube replacement (if tract maturity is uncertain).
FIGURE 86­4
Percutaneous endoscopic gastrostomy tube (G­tube) with a mushroom bolster in place.
Prevention is the best treatment for clogging of gastrostomy and jejunostomy tubes. Frequent flushing with water and careful crushing of pills usually can prevent this problem. Vomiting and diarrhea can be relieved by decreasing the amount of the feedings and/or diluting the feedings. To unclog the
 tube, instill warm water or carbonated beverage (cola is most often used) and let it remain for  minutes. Then attempt flushing. Alkalinized
 pancreatic enzymes (12,000 lipase units dissolved in 650 mL bicarbonate) have also proven effective in about 50% of cases.
TUBE REPLACEMENT
If the tube cannot be unclogged or if it has fallen out, replacement will be necessary. If the tube was placed by a surgeon or gastroenterologist and has not been replaced, it probably will have a bolster (also called a mushroom or bumper) holding the tube in place (Figure 86­4). This will prevent the tube
 from being removed. The bolster must be removed endoscopically, or the tube may be cut off and the bolster allowed to pass through the GI tract.

The latter technique is generally safe in adults, but passage in children has complications, and tube removal should be done by the endoscopist or surgeon. Endoscopic removal in adults is advisable when there is suspected or potential obstructive disease of the GI tract, such as pyloric stenosis, intestinal pseudo­obstruction, and intestinal stricture (e.g., due to radiation, ischemia, or inflammatory bowel disease). If the tube is cut, an abdominal radiograph should be obtained  week later to confirm passage of the internal component. Most reported complications from a retained internal
 bolster have occurred when the bolster did not pass within  to  weeks. If the bolster or bumper becomes buried in the abdominal wall, consult with the endoscopist or surgeon who placed the device. Do not attempt removal by traction. Some specially designed tubes have internal bumpers that can be removed by external traction, but consultation with the endoscopist or surgeon who placed the device is necessary before any traction is applied to
 verify the type of tube and the appropriate method of removal (Figure 86­4).
If the tube has become dislodged or has fallen out, replace it as quickly as possible (within a few hours) to prevent closure of the tract.

Most tracts mature after  to  weeks. Do not attempt to replace a tube with an immature tract. First determine, if possible, which type of tube is being used. If the tube is available, replacement with the same size is usually possible. If the tube is not available, it can be difficult to determine whether the tract is for a jejunostomy or gastrostomy tube. Location site on the abdominal wall is not helpful to differentiate the two. A tract for a gastrostomy tube is usually larger. Old records may be useful and should be obtained, if possible. After determining the type of tract and size of tube used previously, insert the tube using a water­soluble lubricant. If the size of the tube being replaced is not known, it is reasonable to start with a
16­ or 18­F replacement gastrostomy tube or Foley catheter. The lubricated tube should pass easily into the stoma without additional equipment. If resistance is met, abandon the attempt. A smaller tube can be tried to keep the tract open. After replacing the tube, instill a 20­ to 30­mL bolus of a water­soluble contrast material (e.g., diatrizoate meglumine and diatrizoate sodium solution [Gastrografin]) through the tube, and obtain a supine abdominal radiograph within  to  minutes. The radiograph should demonstrate rugae of the stomach for a gastrostomy tube and flow into the small bowel for a jejunostomy tube. US can also be used to verify gastric placement. The tip of the tube can be visualized within the stomach, and confirmation of placement can be done by injecting  mL of normal saline into the tube and observing the fluid entering the stomach, using real­time
US. Another way of determining placement is to withdraw gastric fluid and check pH to make sure it is acidic. If there is any question of improper placement, obtain immediate consultation.
A special caution regarding jejunostomy tubes should be noted. Jejunostomy tracts are smaller, and smaller tubes are used (8­ to 14­F). These tubes usually are not sutured in place and frequently become dislodged. They can be replaced with catheters made specifically for jejunostomies or with
Foley catheters. If a Foley catheter is used to replace a lost jejunostomy catheter, the balloon should never be inflated because it can cause a bowel obstruction or damage the jejunum. The tube is lubricated, inserted into the stoma, and advanced  cm. These tubes are easily replaced if the tract is mature; however, if resistance is met, referral to a radiologist for fluoroscopic placement using guidewires is recommended.
OSTOMY COMPLICATIONS
Emergency physicians frequently encounter patients with ostomies and their complications. Common ostomies include colostomies, ileostomies, catheterizable ileal pouches, and ileal conduits. As expected, ostomy surgery can result in the following surgical complications: wound infection, dehiscence, parasomal herniation, bowel obstruction, including from volvulus, and bleeding. These complications generally require surgical
 consultation. Dermatitis is commonly caused by exposure to urine or feces, abrasion, or allergy to adhesive or ostomy material. Remedies include resizing ostomy contact and changing ostomy material, perhaps guided by referral for patch testing. Ostomy powder is available to help dry skin, and ostomy paste can be used to prevent leakage from poor ostomy contact.
The ileum is commonly used for two types of urinary diversion—ileal conduit and catheterizable ileal pouch. In either case, a part of the ileum is detached from the alimentary canal and reformed into a reservoir; the remaining ileum is reconnected end­to­end. The ileal conduit, which is more
 common, does not require catheterization, has a small reservoir, and has a relatively continuous ostomy output. In the catherizable ileal pouch, the patient catheterizes a larger reservoir and can maintain continence. Both reservoirs are prone to urinary infection and colonization, and patients with
 a catheterizable pouch must irrigate periodically to minimize the risk of urinary infection.


