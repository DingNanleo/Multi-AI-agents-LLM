## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 53: Acute Heart Failure
Alan B. Storrow; Brian D. Bales; Zachary L. Cox; Lynea I. Bull; Sean P. Collins
Content Update: Acute Heart Failure June 2025
Current updates on the management of acute heart failure are presented in the chapter.
INTRODUCTION AND EPIDEMIOLOGY
Acute heart failure is a gradual or rapid onset of symptoms and/or signs of heart failure, severe enough for the patient or caregiver to seek urgent or emergent care. Acute heart failure covers a wide spectrum of illness severity, ranging from a gradual increase in leg swelling, shortness of breath, decreased exercise tolerance, or fatigue to the abrupt onset of pulmonary edema. It is common, associated with unplanned emergency department visits, unplanned hospitalizations, frequent readmissions, and death. However, most patients are admitted for symptomatic evaluation and treatment of congestion with intravenous diuretics and to lesser degree (∼10%) for respiratory failure, cardiogenic shock, malignant dysrhythmia, or the need for
 urgent procedures. Despite this relative clinically stability, the complication rate after an acute heart failure hospitalization is high.

While the alternative terms decompensated heart failure, acute heart failure syndrome, or hospitalized with heart failure are used in an overlapping manner, we refer to patients with either an acute exacerbation of chronic heart failure or new­onset heart failure as having acute heart failure. The outdated term congestive heart failure describes patients with signs and symptoms of fluid accumulation.
,4
Most ED visits for acute heart failure result in hospital admission. ED physicians drive most disposition decisions in this setting. With the aging population, increased survival from acute myocardial infarction, and improving outpatient treatment options, the worldwide prevalence of heart
5­7 failure is expected to increase. Although long­term heart failure management has improved with therapies such as angiotensin receptor/neprilysin inhibitors, angiotensin­converting enzyme inhibitors, angiotensin receptor blockers, β­blockers, mineralocorticoid receptor antagonists, sodium­
8­10 glucose cotransporter  inhibitors, and cardiac resynchronization therapy, acute heart failure therapy in the ED remains largely unchanged. This includes diuretics, supplemental oxygen, nitrates when appropriate, and occasionally, positive pressure ventilation or intubation, vasopressors, and inotropes.

Heart failure has a poor prognosis, with approximately 50% of patients dying within  years of diagnosis. Hospitalization is an inflection point; those
 hospitalized have a higher mortality than a matched nonhospitalized cohort.
PATHOPHYSIOLOGY
Heart failure is a complex clinical syndrome manifested by cardinal symptoms (shortness of breath, edema, and fatigue) occurring from functional or structural cardiac damage, impairing the ability of the heart to act as an efficient pump. Symptoms may limit exercise tolerance and lead to fluid
 retention, driving pulmonary and/or splanchnic congestion and/or peripheral edema. Responsive adaptations in the kidney, peripheral circulation, skeletal muscle, and other organs maintain short­term circulatory function. Eventually, these may contribute to long­term disease progression and to acute exacerbations.
As cardiac output drops from myocardial injury or stress, a neurohormonal­mediated cascade including activation of the renin­angiotensinaldosterone and sympathetic nervous systems occurs. Responses include release of norepinephrine, vasopressin, endothelin (a potent vasoconstrictor), and tumor necrosis factor­α. Although not measured in routine care, elevated levels of these hormones correlate with higher
 mortality.
Chapter 53: Acute Heart Failure, Alan B. Storrow; Brian D. Bales; Zachary L. Cox; Lynea I. Bull; Sean P. Collins 
. Terms of Use * Privacy Policy * Notice * Accessibility
The clinical effects of neurohormonal activation are sodium and water retention coupled with increased systemic vascular resistance. These maintain blood pressure and perfusion but at the cost of increasing myocardial workload, wall tension, and myocardial oxygen demand. Although some patients are initially asymptomatic cardiac remodeling (a secondary pathologic process), begins to occur, eventually triggering more cardiac dysfunction.
Natriuretic peptides are the endogenous counterregulatory response to neurohormonal activation in heart failure. Three types exist: atrial natriuretic peptide, primarily secreted from the atria; B­type natriuretic peptide (BNP), secreted mainly from the cardiac ventricle; and C­type natriuretic peptide, localized in the endothelium. Natriuretic peptides produce vasodilation, natriuresis, decreased levels of endothelin, and inhibit the renin­angiotensin­aldosterone system as well as the sympathetic nervous systems. BNP is synthesized as N­terminal pre–pro­BNP, which is cleaved into two substances, inactive N­terminal pro­BNP, with a half­life of approximately  hours, and physiologically active BNP, with a half­life of about  minutes. Assays for both BNP and N­terminal pro­BNP are available.
Heart failure may also result from pump dysfunction from acute myocardial infarction. Mechanistically, loss of a critical mass of myocardium results in immediate symptoms. If there is symptomatic hypotension with inadequate perfusion, cardiogenic shock is present (see Chapter , “Cardiogenic
Shock”). Acute pulmonary edema may be precipitous and is the clinical manifestation of a downward spiral of rapidly decreasing cardiac output and rising systemic vascular resistance on top of underlying cardiac dysfunction. Even small elevations of blood pressure can decrease cardiac output, which triggers increasing systemic vascular resistance and eventually further decreases cardiac output. Acute pulmonary edema can be abrupt, severely symptomatic, and rapidly fatal if it goes untreated.
SYSTOLIC AND DIASTOLIC HEART FAILURE
Heart failure classifications also identify systolic or diastolic dysfunction based on left ventricular ejection fraction (LVEF). Systolic dysfunction, or heart failure with reduced ejection fraction, is identified in patients with a LVEF <50%. Mechanistically, the ventricle has difficulty ejecting blood, leading to increased intracardiac volume and afterload sensitivity. With circulatory stress (e.g., walking), failure to improve contractility despite increasing venous return results in increased cardiac pressures, pulmonary congestion, and edema.
Diastolic dysfunction, or heart failure with preserved ejection fraction, has impaired ventricular relaxation, causing an abnormal relation between diastolic pressure and volume. The left ventricle has difficulty filling with blood due to this impaired relaxation. Decreased left ventricular compliance necessitates higher atrial pressures to ensure adequate left ventricular diastolic filling, creating a preload sensitivity. The frequency of diastolic dysfunction increases with age and is more common in chronic hypertension, which leads to left ventricular hypertrophy. Coronary artery disease also contributes, as diastolic dysfunction is an early event in the ischemic cascade.
DIAGNOSIS
,4
Most hospitalized patients with acute heart failure receive initial care in the ED. Commonly, patients present with dyspnea, which has a large differential diagnosis including acute heart failure, chronic obstructive pulmonary disease, asthma, pulmonary embolus, pneumonia, and acute coronary syndrome. Misdiagnosis increases mortality, prolongs hospital stay, and increases treatment costs. The approach to those with dyspnea is covered in Chapter , “Respiratory Distress.” There is no single diagnostic testfor acute heart failure; it is a diagnosis based on all clinical data, especially the history and physical examination.
HISTORY AND PHYSICAL EXAMINATION
There is no singular historical or physicalexamination finding with excellent sensitivity and specificity for the diagnosis of acute heart failure. The initial global clinical judgment has a sensitivity of 61% and specificity of 86%. A history of heart failure is the most useful historical parameter but has a sensitivity of only 56% and specificity of 80% (positive likelihood ratio = .7; negative likelihood ratio = .58). Risk factors for acute heart failure may be helpful, including hypertension, diabetes, valvular heart disease, old age, male sex, and obesity. The symptom with the highest sensitivity for diagnosis
 is dyspnea on exertion (84%). The most specific symptoms are paroxysmal nocturnal dyspnea, orthopnea, and edema (76% to 84%). Evaluation for precipitating factors (Table 53­1) may aid diagnosis.
TABLE 53­1
Common Precipitants of AHF
Nonadherence
Excess salt or fluid intake
Medication nonadherence
Renal failure (especially missed dialysis)
Substance abuse—cocaine, methamphetamines, ethanol
Poorly controlled hypertension
Iatrogenic
Recent addition of negative inotropic drugs (e.g., calcium channel blocker, β­blocker)
Initiation of salt­retaining drugs (e.g., NSAID, steroids, thiazolidinediones)
Inappropriate therapy reduction
New dysrhythmic agents
Acute coronary syndrome
Atrial fibrillation and other dysrhythmias
Additional cardiac disease (e.g., endocarditis)
Acute infections (e.g., pneumonia, urinary tract)
Anemia
Hyper­ or hypothyroidism
Abbreviations: AHF = acute heart failure; NSAID = nonsteroidal anti­inflammatory drug.
,14
On exam, an S has the highest positive likelihood ratio for acute heart failure (4.0), but its absence is not useful (negative likelihood ratio = .91).

Further, the interrater reliability of an S3 is not good, and the ambient noise in a busy ED may interfere with detection.
12­15
When clinicians are 80% confident of the diagnosis of acute heart failure, the “clinical gestalt” outperforms ED diagnostic tests.
Decision support tools may show promise for improving diagnostic accuracy. CoDE­HF was developed and validated through systematic review, meta­
 analysis, and modelling. In a large retrospective cohort they suggested improved diagnostic characteristics with the use of the tool, including in subgroups accounting for age, obesity, renal impairment, or previous heart failure. The model includes demographics, clinical evaluation, and laboratory tests.
CHEST RADIOGRAPHY
Although chest radiographs showing pulmonary venous congestion, cardiomegaly, and interstitial edema are most specific for a final diagnosis of
 acute heart failure, the absence of these does not exclude the diagnosis. Up to 20% of patients in whom acute heart failure is subsequently
 diagnosed have chest radiographs without signs of congestion at ED evaluation. In late stage heart failure, patients may have few radiographic signs, despite symptoms and elevated pulmonary capillary wedge pressure.
ECG AND BIOMARKERS
The ECG is best used to find an underlying cause or precipitant. ECG signs of ischemia, acute myocardial infarction, or dysrhythmias (commonly atrial fibrillation) may point to the trigger.
BNP and N­terminal pro­BNP may add value in the setting of undifferentiated dyspnea in the ED, improving diagnostic discrimination in a variety of settings25,27 and correlating with cardiac filling pressures and ventricular stretch.28 As a result, BNP or pro­BNP testing is recommended when the cause of dyspnea is unclear after standard evaluation; when the other bedside data make acute heart failure likely, these assays add little ED actionable information. (Table 53­2).
TABLE 53­2
Natriuretic Peptide Cut Points for Clinical Decision Making
Low Cut Point (rule out HF) High Cut Point (HF likely)
BNP 100 pg/mL (sensitivity 90%, specificity 73%) 500 pg/mL (sensitivity 75%, specificity 90%)
N­terminal pro­BNP30 300 pg/mL (sensitivity 93%, specificity 71%) If <  years old: 450 pg/mL (sensitivity 86% Specificity 94%)
If 50–75 years old: 900 pg/mL (sensitivity 79%, specificity 84%)
If older than  years: 1800 pg/mL (sensitivity 76%, specificity 75%)
Abbreviations: BNP = B­type natriuretic peptide; HF = heart failure.
Despite the established value of natriuretic peptide testing, there are situations where interpretation of results is unclear. Levels can be affected by
 age, sex, body mass, sacubitril/valsartan therapy; levels may elevate later in patients with flash pulmonary edema. Dyspnea and modest BNP elevation are evident in conditions such as pulmonary hypertension, pulmonary embolism, pneumonia, sepsis, and renal failure. As many as 25% of patients will fall into the diagnostic “gray zone” (100­500 pg/mL for BNP), complicating test interpretation. Heart failure can largely be excluded in patients presenting with acute dyspnea and pro­BNP <300 pg/mL or BNP <100 pg/mL. In addition, pro­BNP has age­specific cutoffs to further increase
 accuracy, with cutoff levels of 450, 900, and 1800 pg/mL in patients <50, 50­75, and >75 years old, respectively (Table 53­2). BNP/pro­BNP testing is best used when diagnostic uncertainty exists and as an addition to the physician assessment, rather than in isolation. Similarly, although marked natriuretic peptide elevations are associated with worse short­term outcomes, even low elevations have increased mortality risk, limiting usefulness in bedside ED prognostication, although results may be useful for comparison with inpatient testing in a serial fashion.
Urine sodium measurement shortly after the start of diuretic therapy may be useful to gauge diuretic responsiveness and help determine subsequent dosing in the ED or inpatient setting. The ESC HF consensus statement suggests a urine sodium <50­75 mEq/L at  hours after diuretic
 administration is correlated with a poor diuretic response and should result in a doubling of the diuretic dose. Urine sodium guided treatment is
 correlated with greater natriuresis without a mortality or HF rehospitalization difference.
POCUS
Point­of­care cardiopulmonary US can help to determine emergent causes of dyspnea, including cardiac tamponade or pulmonary embolism (e.g.,
,32 evidence of acute right heart strain), and can determine left ventricular function and volume status. Bedside cardiopulmonary US can also be used to address three questions in regard to acute heart failure (Figure 53­1): (1) Are there signs of pulmonary congestion? (2) Are there signs of systemic volume overload? (3) What is the LVEF?
FIGURE 53­1. Bedside US can be performed to identify acute heart failure (AHF) in dyspneic ED patients using a curvilinear transducer or phased array probe to a depth of  cm. BNP = B­type natriuretic peptide; HFpEF = heart failure with preserved ejection fraction; HFrEF = heart failure with reduced ejection fraction; IVC = inferior vena cava; LVEF = left ventricular ejection fraction; RV = right ventricle. [Data adapted from Anderson KL, Jenq KY, Fields MF et al:
Diagnosing heart failure among acutely dyspneic patients with cardiac, inferior vena cava, and lung ultrasonography. Am J Emerg Med 31: 1208–1214,
2013.]
Pulmonary US is used first to determine if pulmonary congestion is present by looking for B­lines. Sonographic B­lines (Figure 53­2) are ring­down artifacts that arise from the interface of the visceral and parietal pleura when there is swelling of the lung's interlobular septa due to lymphatic
 congestion, as is seen in pulmonary edema. They are the sonographic equivalent of Kerley B­lines seen on chest radiography. Involvement of two or more of the eight thoracic regions bilaterally is suggestive of a disease process. The presence of three or more simultaneous B­lines in any one intercostal window is pathologic and highly specific for alveolar and interstitial edema.
FIGURE 53­2. Multiple B­Lines seen in a single lung field/intercostal window, originating from the pleural line. B­lines represent thickened interalveolar/interlobular septa. (Reproduced with permission from Kohler MJ. Musculoskeletal Ultrasound in Rheumatology. In: Stone JH, ed. Current Diagnosis & Treatment
Rheumatology, 4e. McGraw Hill; 2021.)
Because bilateral B­lines can be present in other conditions not caused by pulmonary edema (e.g., pulmonary fibrosis, pulmonary contusion, bilateral
 pneumonia), rapid assessment for elevated central venous pressure (CVP) follows. An inferior vena cava (IVC) size >2 cm or collapsibility index of

<50% is indicative of elevated CVP (Figure 53­3). In the absence of significant pulmonary disease, these measurements are highly correlated with pulmonary capillary wedge pressure and are specific for acute heart failure. Emergency physicians should use US to look for other clinical conditions causing an elevation in right heart pressure, including pulmonary embolism or tricuspid regurgitation, both could cause IVC changes consistent with those seen in heart failure.
FIGURE 53­3. Longitudinal view of the IVC. Measurement should be performed approximately  cm distal to the HV insertion site. In this image, the IVC diameter is measured to be .5 cm, indicative of elevated central venous pressure. IVC = inferior vena cava; RA = right atrium; HV = hepatic vein. (Used with permission from Jonathan Bruhn and Lynea Bull.)
Determining the crude LVEF is the final piece of evaluation. With focused training, emergency physicians have reasonable agreement with expert
 cardiology interpretations by classifying a visual US estimation of LVEF into broad categories of normal, moderately reduced, and severely reduced.
Moderate to severe reduction in LVEF should raise concerns for acute heart failure. In patients with previously documented systolic dysfunction, it can be helpful to compare POCUS estimated LVEF to the patient's most recently performed echocardiography. E­point septal separation (EPSS, Figure 53­
4) can also be obtained for more quantitative assessment rather than solely relying on visual estimation of LVEF, however this and other LVEF
 measurements such as fractional shortening may be more time consuming in the ED setting.
FIGURE 53­4. M­mode ultrasound image of the EPSS measurement. E= E­point, the maximum opening of the anterior leaflet of the mitral valve; A= A­point, the maximum mitral valve anterior motion during the late diastolic atrial contraction; {= The measurement area that correlates with the EPSS, the distance between the E­point and the intraventricular septum. A healthy heart will have a short distance between the septum and the E­point. An EPSS >7mm is highly sensitive for severe systolic dysfunction (LVEF <30%). (Used with permission from Lynea Bull.)
In summary, presence of diffuse B­lines, a dilated IVC and reduced IVC Collapsibility Index (IVC­CI), and reduced LVEF are highly sensitive and specific for acute heart failure. The basic cardiac POCUS views necessary to assess the heart for various pathology are generally easy to obtain rapidly and make assessment of systolic dysfunction an accessible first choice. Tachycardia or cardiac dysrhythmias such as atrial fibrillation may make LVEF assessment challenging and may require repeat evaluations or management of underlying condition for accurate measurement. It is also important to
 note an estimated 50% of acute heart failure exacerbations are due to diastolic dysfunction ; and while studies have demonstrated emergency
 physicians can diagnose diastolic heart failure with good sensitivity, adding more advanced POCUS measurements (such as E/A ratio or E/E' ratio) can prolong the time needed to evaluate each patient. Additionally, ultrasound is useful as a dynamic diagnostic tool and performing serial
 cardiopulmonary US exams after interventions can be helpful in evaluating patient response to treatment.
TREATMENT
The initial approach is driven by presentation acuity and a clinical assessment of the hemodynamic profile for severity of congestion and adequacy of
 perfusion (Table 53­3). In critically ill patients, airway management is the priority to ensure adequate oxygenation and ventilation. Diagnosis of cardiogenic shock (evidence of tissue hypoperfusion) without another cause may be due to an ischemic or structural heart trigger. These patients warrant consideration of recommendations in Chapter , Cardiogenic Shock. Such patients often benefit from inotropic agents and invasive hemodynamic monitoring to guide other therapies. Initial evaluation also includes recognition of patients with ACS, in whom urgent revascularization may be indicated (see Chapter , Acute Coronary Syndromes). In the absence of ischemic disease, recent onset with accelerating hemodynamic
 decompensation may represent inflammatory heart disease, and can be accompanied with conduction block or ventricular arrhythmias. Those with acute heart failure and hypertension often have a precipitous presentation and may have pulmonary edema and hypoxemia. Symptoms may be due to
,31 fluid redistribution more than fluid overload, and treatment initially focuses on antihypertensive therapy. Patients with pulmonary edema may
,33 also benefit from noninvasive ventilation to decrease the work of breathing and avoid intubation.
TABLE 53­3
Synopsis of Initial Assessment and Therapy of ED Patients With Acute Heart Failure8
Assessment 1) Address adequacy of perfusion
2) Assess severity of congestion
3) Assess common precipitating factors (Table 53­1)
Initial 1) For those with evidence of significant fluid overload, treat promptly with intravenous loop diuretics
Therapy 2) When diuresis is inadequate to relieve symptoms and signs of congestion and patient remains in the ED, it is reasonable to intensify the diuretic regimen using higher doses of intravenous loop diuretics34
In those who are less acutely ill, a focused evaluation ensues next, followed by treatment. Patients with acute decompensation of chronic heart failure tend to have gradual symptoms (shortness of breath, peripheral edema, or weakness common) and weight gain over days to weeks. Thus, most ED patients with acute heart failure are not truly “acute” but have a gradual increase of cardiac filling pressures on preexisting structural heart disease;
 precipitating factors can often be identified. Those with isolated right heart failure have lower extremity edema and jugular venous distention but little or no pulmonary congestion; the cause is usually from pulmonary disease, valvular disease such as tricuspid regurgitation, or obstructive sleep apnea. Treatment approaches center on identifying and treating the underlying cause, often without volume removal because low­output states and volume dependence may coexist.
Use pulse oximetry and supplemental oxygen to keep oxygen saturation at or above 92%. Because hypoxemia is a greater risk than hypercarbia, do not withhold oxygen if saturations are depressed or unknown, even when there is concern about carbon dioxide retention. Capnometry and blood gas measurements can later help titrate therapy in the critically ill. In those with extreme findings, positive pressure ventilation or endotracheal intubation may be indicated.
,35
Noninvasive positive pressure ventilation often improves the symptoms in patients with acute heart failure or pulmonary edema. Successful noninvasive ventilation requires close monitoring, hemodynamic stability, facial anatomy allowing an adequate facemask seal, and patient cooperation (see Chapter , “Noninvasive Airway Management and Supraglottic Airways”). Noninvasive ventilation plus standard medical therapy reduces the need for intubation and improves respiratory distress and metabolic disturbance versus standard therapy alone. The effect on hospital mortality remains unclear.
Alternatively, high velocity nasal insufflation of oxygen via nasal cannula (flow rates between  L/min and  L/min) may be superior to standard oxygen delivered by nasal cannula and noninferior to noninvasive positive pressure ventilation in treatment of undifferentiated respiratory failure in
 adult ED patients, although trial results have been mixed. High velocity nasal insufflation provides high concentrations of oxygen and a mild distending pressure, and it may improve ventilatory efficiency by way of dead space washout. High velocity nasal insufflation is easier to use and better
 tolerated by many patients compared with noninvasive positive pressure ventilation.
Other standard initial care measures include cardiac monitoring, IV access, and frequent vital sign assessments. A urinary Foley catheter may aid in monitoring fluid status in the severely ill or incontinent, but this is best reserved for those with extreme illness, inability to void or those who are unsteady and unable to use a bedside commode (to avoid catheter­related complications).
MANAGEMENT OF AHF WITH REDUCED EJECTION FRACTION PRECIPITATED BY
HYPERTENSION
The failing heart with reduced ejection fraction is sensitive to increases in afterload, with pulmonary edema developing in some patients with a systolic
 blood pressure as low as 150 mm Hg. Prompt recognition and afterload reduction with vasodilators can avoid the need for intubation.
Nitroglycerin
A short­acting, rapid­onset, systemic venous and arterial dilator, nitroglycerin decreases cardiac filling pressures by reducing preload and at high doses also reduces afterload. Nitroglycerin may have coronary vasodilatory effects, decreasing myocardial ischemia and improving cardiac function.
The choice of IV, sublingual, or transdermal routes should be based on symptom severity. Sublingual nitroglycerin spray is easily administered, rapidly bioavailable, and titratable to reach a desired clinical endpoint provided there is adequate blood pressure. An initial approach is sublingual administration of nitroglycerin, .4 milligrams (400 micrograms), 1­2 sprays or tablets within 1­5 minutes until relief or replacement with IV nitroglycerin. A starting dose of .5 to .7 micrograms/kg/min IV is common and titrated every few minutes up to 200 micrograms/min based on the blood pressure tolerance and symptoms (Tables 53­4 and 53­6). High doses may be used in the acute setting and adverse events
 are reportedly uncommon. Apply transdermal nitroglycerin (0.5–2 inches to the chest wall based on blood pressure) only after initial therapy has improved conditions or if the symptoms are minor, because transdermal medication has a slow onset of action.
TABLE 53­4
Management of Acute Heart Failure with reduced ejection fraction precipitated by hypertension (SBP > approximately 150 mm Hg)
Stepwise Approach Comments
Administer oxygen as needed for saturation ≥90%; give sublingual nitroglycerin. Sublingual nitroglycerin may be repeated 1­2 sprays or tablets every  minutes.
If severe dyspnea, consider NIV, HFNC, or intubation.
If BP >150/100 mm Hg, add IV nitroglycerin; if BP falls below 100 mm Hg, stop nitrates, and monitor for persistent hypotension See Chapter , or symptoms (see Chapter , “Cardiogenic Shock”). If BP <150/100 mm Hg after sublingual administration and if improved, “Pulmonary consider transdermal nitroglycerin. See discussion of nitroprusside below as a seldom used ED alternative to nitroglycerin. Hypertension”; for further discussion.
Start IV loop diuretic (furosemide or bumetanide) in the setting of volume overload. Nitrates are typically started before diuretics but can be given simultaneously
Assess for severity of illness/high risk: altered mental status persistent, hypoxia despite NIV, hypotension, troponin elevation, See Chapter , “Acute ischemic ECG changes, tachycardia, tachypnea, or inadequate urine output. Coronary Syndromes,” for ECG criteria.
Admit to intensive care unit if high severity of illness or risk of decompensation.
Choose discharge or ED observation unit admission if good response to therapy, no high­risk features, and good social Scoring systems may not support. Admit the rest. Admit to intensive care unit if any ongoing cardiorespiratory compromise or acute ischemia. reliably identify all patients at risk.
Abbreviations: BP = blood pressure; HFNC = high­flow nasal cannula; NIV = noninvasive ventilation; SBP = systolic blood pressure.
TABLE 53­5
Causes of Hypotension After Vasodilator Use
Excessive vasodilation
Hypertrophic obstructive cardiomyopathy
Intravascular volume depletion
Right ventricular infarction
Cardiogenic shock/myocardial infarction
Aortic stenosis
Anaphylaxis
Unsuspected sepsis
Concomitant use with a phosphodiesterase type  inhibitor (PDE5I)
TABLE 53­6
Medications for Acute Heart Failure
Vasodilators for Acute Heart Failure
Vasodilator Dose Titration End Complications
Point
Sublingual .4 milligram within 1–5 min Blood pressure Hypotension
NTG
IV NTG .5–0.7 micrograms/kg/min (starting dose if blood Symptoms Headache, hypotension pressure okay)
Nitroprusside .3 micrograms/kg/min (starting dose),  Blood pressure Hypotension, cyanide/thiocyanate toxicity, renal micrograms/kg/min (maximum) Symptoms impairment, coronary steal. A PA catheter should be required for MAP monitoring and titration.
Diuretics for Heart Failure
Diuretic Dose (IV) Effect Complications
Furosemide No prior use: 20–40 milligrams IVP Diuresis starts within ↓ K+, ↓ Mg2+, hyperuricemia, hypovolemia, ototoxicity,
If prior use: total daily IV dose 1–2.5 times the 15–20 min Duration prerenal azotemia patient's previous total daily oral dose, divided in of action is 4–6 h half and given IV bolus every  h
If no effect by 20–30 min, increase subsequent dose
Bumetanide No prior use:  milligrams IVP (1 milligram IV Diuresis starts within Same as above bumetanide =  milligram IV furosemide) 15­20 min Duration of
Titration and monitoring are identical to IV action is 4–6 h furosemide
Torsemide 10–20 milligrams PO (20 milligram PO torsemide = Diuresis starts within Same as above
 milligram IV furosemide)  min Peak action in
1–2 h
Abbreviations: IVP = IV push; NTG = nitroglycerin; PA = pulmonary artery; MAP = mean arterial pressure ↓ = decreased.
The most important nitroglycerin complication is hypotension, often lasting only transiently and, at times, even seen with overall clinical improvement.
Hypotension usually resolves after cessation of nitroglycerin (Table 53­5). If persistent, think of concomitant volume depletion or right ventricular infarct, and deliver a normal saline fluid bolus (250 to 1000 mL). Headache is frequent, but acetaminophen usually provides adequate relief.
Methemoglobinemia is a theoretic possibility, but not a concern unless high doses are used for extended intervals. Despite broad uptake into regular clinical practice, nitroglycerin use has little supporting prospective data on improving clinical outcomes such as number of days alive and out of
  hospital at  days or all­cause mortality and 180­day rehospitalization.
Nitroprusside
If requiring further afterload reduction (i.e., continued high systemic vascular resistance usually manifested by persistent elevated blood pressure and continued symptoms despite nitroglycerin doses >200 micrograms/min), use of IV nitroprusside may be considered. This is a potent arterial and venous vasodilator; its hemodynamic effects include decreased blood pressure, left ventricular filling pressure reduction, and increased cardiac output. The initial dose of nitroprusside is .3 micrograms/kg/min, titrated upward every  to  minutes based on blood pressure and clinical response (maximum  micrograms/kg/min). The major complication is hypotension. It is also associated with thiocyanate toxicity, especially with high doses, prolonged (>3 days) use, and hepatic or renal impairment.
The critical endpoint is rapidly lowering filling pressure to prevent the need for endotracheal intubation. Give or titrate up IV vasodilators as soon as possible when the blood pressure remains elevated.
Loop Diuretics
After vasodilator therapy (or with near normal blood pressure and symptoms; see next section), patients may require diuresis (see Table 53­6 and next section) based on continued symptoms after blood pressure is controlled. Loop diuretics (furosemide is the most commonly used) administered alone
 without vasodilators for hypertensive heart failure may increase mortality and worsen renal dysfunction. Ultimately, successful management of blood pressure and cardiac filling pressure usually creates marked improvement in respiratory status long before any diuresis.
Contraindications and Alternatives to Vasodilation in Select Settings
Because all vasodilators exert hypotensive effects, do not use if there are signs of hypoperfusion or existing hypotension. Flow limiting, preloaddependent states such as right ventricular infarction, aortic stenosis, hypertrophic obstructive cardiomyopathy, or volume depletion increase the risk of vasodilator associated hypotension (Table 53­5). Combined with acute pulmonary edema, the latter preloaddependent states are very difficult to manage. In hypertrophic obstructive cardiomyopathy, goals of therapy include decreasing the outflow gradient by slowing heart rate and cardiac contractility. Although this can be accomplished with IV β­blockers, it is best done with invasive hemodynamic guidance. If there is coexistent shock in the setting of hypertrophic obstructive cardiomyopathy, phenylephrine (40 to 100 micrograms/min IV) is a good choice because it creates peripheral vasoconstriction without increasing cardiac contractility. It is usually given with the assistance of a pulmonary artery catheter.
NORMOTENSIVE HEART FAILURE
Shortness of breath, orthopnea, jugular venous distention, rales, and an S may exist in the presence of normal vital signs, oxygenation, and
 ventilation. In this situation, diuresis should occur first, with further treatment based on response to therapy (Table 53­6).
Loop diuretics provide rapid symptomatic relief of congestive symptoms and improve the effects of angiotensin­converting enzyme inhibitors by decreasing intravascular volume. Most ED patients with anything but modest symptoms should receive IV dosing because bowel wall edema may prevent proper GI absorption. Choose the dose based on symptoms and prior usage (Table 53­6). In general, dose loop diuretics at the lowest possible dose that relieves congestion. After initial relief, a fixed maintenance dose helps prevent recurrence.
Loop diuretics promote water and sodium excretion; they are effective except in severe renal dysfunction or diuretic resistance (failure to achieve the therapeutically desired reduction in congestion despite a full dose of diuretic). Furosemide and bumetanide are inexpensive and effective. Torsemide is available orally and can be converted to IV furosemide (20 milligrams equivalent to  milligrams of IV furosemide). Loop diuretics usually trigger rapid diuresis after an IV dose, often within  to  minutes.
The DOSE trial suggests a reasonable starting point for IV diuretic dosing is  to .5 times the patient's previous total daily oral dose, divided in half and
 administered by IV bolus every  hours. For example, if the patient is taking furosemide  milligrams PO twice a day, then an initial ED dose is  to
200 milligrams IV bolus. Higher doses create more rapid symptom improvement but also a slight decrease in renal function. For patients who are loop diuretic naive, a reasonable starting dose is furosemide  milligrams IV bolus. Ethacrynic acid (0.5 to  milligram/kg; maximum 100 milligrams) is an alternative loop diuretic in the setting of a sulfa allergy, however hypersensitivity cross reactivity with sulfa antibiotics is generally not a concern with nonantibiotic drugs that contain a sulfa moiety such as loop diuretics.
Diuretics may worsen renal function and create hypokalemia. If a prolonging QT interval exists, look for hypocalcemia, hypokalemia, or hypomagnesemia. Ototoxicity is rare but may occur if using diuretics with aminoglycoside antibiotics. Potassium­sparing diuretics, such as spironolactone (25 to  milligrams PO), are common in care of those with heart failure; these are used more for their mortality benefit than diuretic effect.
Urinary diuretic response requires monitoring. With greater symptoms or less response to initial IV diuretics (urine output < 100 mL/hr or urine Na <50­

 mEq/L at  hours post administration), double the dose and repeat in  to  minutes or as needed based on urine output.
If response remains inadequate to high doses of IV loop diuretics and there is a prolonged ED stay, concomitant use of other diuretics acting at different sites, namely thiazides (i.e., metolazone) or acetazolamide, may be considered. However, these options require careful monitoring of serum
,20,42,43 electrolytes and renal function and are best reserved for inpatient use.
Several studies have evaluated the relationship of timing of diuretic therapy in relationship to patient outcomes in the setting of acute heart failure.

One trial noted a hospital mortality benefit (2.3% vs. 6%) for patients receiving diuretics within  minutes of ED arrival. Conversely, another trial found no significant difference in in­hospital mortality or mortality  month after hospital discharge between those who received IV diuretics early
 compared to those who received them later. Such confounding results may be related to the heterogeneity of presentation of acute heart failure leading to variations in the timing of diagnosis (and thus associated therapy). However, guidelines suggest reasonable evidence to support prompt ED administration.
Morphine is not a good choice for acute heart failure due to the potential for adverse events, including nausea, hypotension, bradycardia, respiratory
 depression, possible need for mechanical ventilation, prolonged hospitalization, intensive care unit admission, and mortality. If desired for its venodilation properties, pain control, anxiety, or palliation, use morphine in small, titrated doses (2 to  milligrams IV) and with monitoring.
Oral angiotensin­converting enzyme inhibitors and angiotensin receptor blockers are given for hypertension and chronic heart failure, but
 there are no solid data to recommend ED use for acute heart failure. Oral angiotensin­converting enzyme inhibitors decrease mortality and
 hospitalizations in patients with reduced ejection fraction. Consider these (continuing home medications or new initiation) during or after observation care if no contraindications exist and with follow­up physician coordination. Oral angiotensin receptor blockers are alternatives in select heart failure patients with reduced ejection fraction intolerant to angiotensin­converting enzyme inhibitors due to cough or angioedema. IV enalaprilat appears safe and perhaps efficacious in patients with acute hypertensive heart failure, but further data are required to define an ED role.
β­Blockers are not usually initiated in the ED setting except to control rate­related heart failure, but only in those patients with preserved ejection fraction. Initiation or up­titration of β­blockers in patients with decompensated HFrEF can precipitate cardiogenic shock by reducing compensatory sinus tachycardia and reducing inotropy and should be avoided. Norepinephrine levels are elevated in heart failure, contribute to myocardial hypertrophy, increase afterload and coronary vasoconstriction, and are associated with mortality. β­Blockers reduce sympathetic nervous system activity and are used chronically for mortality reduction and symptom relief.
Oral calcium channel blockers (i.e., diltiazem or verapamil) have myocardial depressant activity and are not routine treatment for acute heart failure; trials demonstrate either no benefit or worse outcomes.
Avoid selective or nonselective NSAIDs in patients with acute heart failure. They can cause sodium and water retention and blunt the effects of diuretics. They may lead to adverse gastrointestinal effects and increase morbidity and mortality.
DISPOSITION DECISIONS
Emergency physicians serve as major decision makers for approximately one­half of all inpatient admissions for acute heart failure. Lack of firm national guideline disposition recommendations, lack of early ED­based therapy, high rates of relapse and mortality, and perhaps a perspective of
,47 hospitalization protecting patients from adverse events, help drive inpatient admission for >80% of patients. While other ED­based cardiovascular processes have moved from high rates of admission to safe and timely discharge for many, decision­making in acute heart failure has evolved slower.
Thus, disposition decisions are often based on physician judgment, a physiologic risk evaluation, and an assessment of barriers to successful
 outpatient care such as caregiver support, medication access, and timely follow­up (Figure 53­5). The importance of timely follow­up was emphasized in a trial evaluating patients with acute heart failure who were seeking emergency care. The use of a risk stratification tool (EHMERG, see below) and timely follow­up with an internist or cardiologist for low­risk patients discharged early (median  days, IQR 3­12), compared to usual care

(median  days, IQR 5­29), led to a lower risk of 30­day all­cause death or cardiovascular rehospitalization.
FIGURE 53­5. Factors impacting disposition decisions in ED patients with acute heart failure (AHF). [Reproduced with permission from Collins SP, Storrow AB:
Moving toward comprehensive acute heart failure risk assessment in the emergency department: the importance of self­care and shared decision making, JACC Heart Fail. 2013 Aug;1(4):273­280.]
However, there have been many promising investigations of ED risk stratification decision making tools with good to excellent discriminatory
,49 ,51 52­54 ,56 ,58 statistics. Examples in common use are EHMERG, MESSI, STRATIFY, and OTTAWA HF Risk Scale (Table 53­7). There are some limitations with retrospective cohort methodology, lack of external validation, inclusion of high­risk variables most ED physicians would consider reasons for admission alone, and rule complexity. These limitations notwithstanding, renal dysfunction, low blood pressure, low serum sodium, and elevated cardiac biomarkers (troponin or natriuretic peptides) are consistently associated with an increased risk of morbidity and mortality.
TABLE 53­7
Selected ED­based Risk Stratification Studies
Study Size Country Variables Risk Stratification Goal
Stiell et al, 2017 1100 Canada History of stroke or TIA 30­day serious adverse
Ottawa Heart Failure History of intubation for respiratory distress events
Risk Scale Heart rate on ED arrival ≥110
Room air Sao <90% on EMS or ED arrival

ECG has acute ischemic changes
Urea ≥12
Serum CO ≥35

Troponin I or T elevated to MI level
NT­pro­BNP ≥5000 pg/mL
During walk test, Sao <90% on room air or usual O , or HR ≥100 during 3­
  min walk test, or too ill to walk
Miro et al, 2018 4711 Spain Barthel index at admission 30­day mortality
MEESSI Systolic blood pressure
Age
NT­pro­BNP
Potassium
Troponin
NYHA at admission
Respiratory rate
Low­output symptoms?
Oxygen saturation
Episode associated with ACS?
Hypertrophy on ECG?
Creatinine
Lee et al, 2018 1983 Canada Age 7­ and 30­day mortality
EHMRG Arrival by ambulance
Systolic blood pressure (triage)
Heart rate (triage)
Oxygen saturation (triage)
Potassium
Creatinine
Troponin
Active cancer
Metolazone use before ED arrival
ST depression on 12­lead (30­day model)
Collins et al, 2015 1033 USA Age 5­ and 30­day hierarchical
STRATIFY BMI adverse events
BNP
Diastolic blood pressure
BUN
Sodium
Respiratory rate
Oxygen saturation
Troponin
Dialysis
On supplemental oxygen
On outpatient ACEI
QRS duration
ACEI = angiotensin­converting enzyme inhibitor; ACS = acute coronary syndrome; BMI = body mass index; BNP = B­type natriuretic peptide; BUN = blood urea nitrogen; CXR = chest x­ray; ED = emergency department; EHMRG = Emergency Heart Failure Mortality Risk Grade; EMS = emergency medical services; h/o = history of;
HR = heart rate; MEESSI = Multiple Estimation of risk based on the Emergency department Spanish Score in patients with AHF; MI = myocardial infarction; NT­pro­BNP
= N­terminal pro­B­type natriuretic peptide; NYHA = New York Heart Association; OHFRS = Ottawa Heart Failure Risk Scale; PTCA = percutaneous transluminal coronary angioplasty; STRATIFY = Improving Heart Failure Risk Stratification in the ED; TIA = transient ischemic attack; and WBC = white blood cell.

Admit patients with high­risk features to the hospital (Table 53­8). Those who require invasive monitoring or procedures require intensive care unit admission. Others may be appropriate for non–intensive care unit level care. Observation unit management is an option in those who lack higher risk features. Some patients do not have high risk features at initial evaluation and experience improvement in dyspnea during their ED stay after treatment
 with standard therapy. Many have complete symptom resolution within  to  hours of initial therapy, a typical time period of observation. The monitoring of blood pressure, heart rate, urine output, and body weight is easily accomplished in the observation unit, and additional diagnostic testing (labs, echocardiography) needed can occur. Finally, an extended observation interval allows patients to receive heart failure education, confirm outpatient medications, assess self­care barriers, and arrange follow­up prior to discharge. If discharged directly or after an observation stay,
,60 outpatient follow­up within  days can decrease readmissions.
TABLE 53­8
Heart Failure Observation Unit/Short Stay Exclusion Criteria
Recommended Exclusions
Positive troponin
BUN >40 milligrams/dL
Creatinine >3.0 milligrams/dL
Sodium <135 mEq/L
New ischemic changes on ECG
∗
New onset of acute heart failure
IV vasoactive infusions being actively titrated
Significant comorbidities requiring acute interventions
Respiratory rate ≥32 breaths/min and/or requiring noninvasive ventilation at the time of OU consideration
Signs of poor perfusion at the time of OU consideration
Suggested Exclusions
Poor social support
Poor follow­up
∗
Although part of the published guidelines, many institutions admit patients to OUs with new­onset heart failure.
Abbreviation: OU = observation unit.

Prior observation studies suggest most patients will respond to therapy, will have no identifiable high risk features, and can be discharged home.
Their rates of readmission are similar to or better than those who are managed in an inpatient setting. Other benefits are reduced ED visits and
 hospital readmissions. Patients with an inadequate response to initial therapy or with high­risk features identified during observation should be admitted to the hospital for further management. An observation unit strategy can help reduce costs while delivering quality care for select lower­risk
ED patients with acute heart failure.


