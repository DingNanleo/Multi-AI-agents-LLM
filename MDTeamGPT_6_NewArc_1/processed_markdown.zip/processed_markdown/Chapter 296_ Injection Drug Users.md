## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 296: Injection Drug Users
Suzanne M. Shepherd
INTRODUCTION AND EPIDEMIOLOGY
In 2015, multiple groups estimated that a quarter of a million people, approximately 5% of the adult population, used illicit drugs of any variety at least
 once; the expected use likely causes between  million and  million years of “healthy life” lost due to premature disability and death. In 2015, the
United States had approximately one quarter of reported drug­related deaths worldwide, with more than double the death rate seen in 1999. Globally, drug­related deaths produced more mortality than road traffic accidents or violence. Opioids remain the most harmful type of drug of abuse, with a higher risk of fatal and nonfatal overdose and risk of acquiring infection. Of people who inject illicit drugs worldwide, about .6 million are infected with human immunodeficiency virus (HIV) and .1 million are infected with hepatitis C.
RISK BEHAVIORS OF INJECTION DRUG USERS
The practice of injection and the lifestyle and culture of injection drug users place such individuals at risk for a wide variety of infectious and noninfectious medical complications. In addition to carrying an increased risk of infection with HIV, hepatitis B and C, Kaposi’s sarcoma­associated herpes virus, tetanus, tuberculosis, and sexually transmitted diseases, the injection drug user also has an increased risk of trauma and intimate
,3 partner violence. It is important to vaccinate injection drug users against hepatitis B virus, human papillomavirus, and, when it becomes available,

HIV. The Centers for Disease Control and Prevention recommends routine HIV screening in EDs and that consent for testing should be “opt­out.”
An association between childhood emotional, physical, and sexual abuse or trauma and IV drug abuse also highlights the importance of traumainformed interventions for injection drug users and the importance of early screening and treatment for drug abuse in those who have undergone
 childhood trauma. The high incidence of migration, incarceration, homelessness, nutritional deficiencies, coincident smoking and alcohol use, and mental illness further compromises the health of this group.
PATHOPHYSIOLOGY
Injection drug use increases the risk for immunomodulating infections, such as HIV infection and hepatitis, and may induce immune dysregulation.
Exaggerated and atypical lymphocytosis, diminished lymphocyte responsiveness to mitogenic stimulation and depressed chemotaxis, hypergammaglobulinemia, increased opsonin production, decreased T­cell and natural killer cell activity, high levels of circulating immune complexes, and reticuloendothelial abnormalities can be evident with ongoing drug injection. False­positive results on nontreponemal syphilis serologic tests, positive results on Coombs tests, low measured antibody response to vaccination, and thrombotic thrombocytopenic purpura are possible in this
 population. The immunomodulatory effects of injection drug use may also contribute to the progression of HIV infection, as HIV­infected patients who
 inject drugs are found to be less likely to suppress HIV­1 RNA than those who do not. Given their immune dysfunction, suspect infection in all febrile patients with ongoing drug injection even if the temperature elevation is modest or WBC counts and erythrocyte sedimentation rates are normal or near normal.
CLINICAL FEATURES
Be aware of the drugs used in local ED catchment areas, the constantly evolving street names (e.g., “H,” “skag,” “tar,” “bud light”), and adulterants used to cut the drugs. Ask about drug type(s) and amount, preparation of materials for injection (e.g., crushing capsules in the mouth, licking needles, blowing on injection sites or blowing out clots in needles, or using saliva, lemon juice, or tap or toilet water for drug reconstitution), reuse of needles, needle sharing and HIV/hepatitis status of drug­sharing partner(s), use of antibiotics, antiretroviral and hepatitis C therapy, and coincident medical and mental illness.

Chapter 296: Injection Drug Users, Suzanne M. Shepherd 
Complications of injection drug use may be obvious, such as a painful, erythematous, fluctuant abscess. However, more subtle and vague symptoms
. Terms of Use * Privacy Policy * Notice * Accessibility such as weakness, anorexia, myalgias, weight loss, night sweats, and fever are common and may be the only signs of serious underlying disease (Table
296­1). In addition, approximately  in  female injection drug users seeking care has alloantibody in pregnancy, possibly due to needle sharing, that
 can accompany early pregnancy loss and poor obstetric care.
TABLE 296­1
Evaluation of Injection Drug Users in the ED
Potential Possible
Presenting Symptom Ancillary Tests
Findings Diagnoses
Fever alone Shortness of Pneumonia Chest radiography; blood cultures; ESR CRP; echocardiography breath, cough
Heart murmur Endocarditis CXR; blood cultures; ESR; CRP; TTE or TEE
Needle and Occult bacteremia Blood cultures; CXR; possible Doppler US to evaluate abscess, septic track marks thrombophlebitis
Hypoxemia CXR; possible ECHO
Dysuria UA
Fever with nausea and vomiting, Diaphoresis Drug withdrawal Complete blood cell count; blood cultures; hepatitis serologic testing; rigors, abdominal pain liver panel; UA
Recent injection “Cotton fever”
Jaundice or Hepatitis CBC; LFTS; INR; consider hepatitis serology icterus
Fever with dyspnea and cough Rales and Bacterial pneumonia Chest radiography; blood cultures; chest CT rhonchi
Purulent Atypical pneumonia sputum
Hypoxemia Tuberculosis Also sputum cx & gram stain and AFB stain
Pneumonia due to opportunistic organisms
Septic pulmonary emboli
Fever with weakness, weight loss, Cachexia HIV infection; HIV serologic testing; blood cultures; chest radiography; sputum anorexia, night sweats, diarrhea tuberculosis staining for acid­fast bacillus; sputum culture; hepatitis serologic testing
Oral thrush HIV infection
Hepatitis B and C
Fever with back pain Heart murmur Osteomyelitis Blood cultures; ESR; CRP; bone radiography; CT or MRI; urinalysis
Focal Epidural abscess neurologic signs
Flank Endocarditis tenderness
Renal abscess
Dyspnea and cough Expiratory Hypersensitivity Chest radiography; spirometry; echocardiography; blood cultures wheezes reaction
Rales and Noncardiogenic CXR; ECHO rhonchi pulmonary edema
Fever Pneumonia
Pleuritic chest Septic pulmonary Blood cultures, ECHO pain emboli
Talc reaction
Painful limb Localized Cellulitis Wound specimen cultures; soft tissue radiography; CT; blood cultures erythema
Tenderness Abscess
Localized bruit Pseudoaneurysm Doppler ultrasound
Muscle pain and Myositis ESR, CK, aldolase swelling
Fever Fasciitis
Retained foreign X­ray or CT body
Altered mental status Obtundation Drug overdose or CT; drug screen; lumbar puncture; blood cultures intoxication
Focal Drug withdrawal neurologic signs
Meningismus Central nervous system lesion
Seizure Meningitis
Tetanus
Eye pain and vision loss Periorbital Herpes zoster Viral and fungal cultures; serology for HSV/syphilis; slit lamp exam; vesicles funduscopy; ophthalmology consult
Subconjunctival Kaposi sarcoma lesions
Keratitis Keratoconjunctivitis sicca
Iridocyclitis Herpes simplex
Retinitis Cytomegalovirus infection
Poorly reactive Varicella zoster pupil
Vitreous Toxoplasmosis exudates
Syphilis
Fungal infection
Abbreviations: CRP = C­reactive protein; ESR = erythrocyte sedimentation rate; HIV = human immunodeficiency virus.
FEVER
Fever is associated with infection in most patients. Noninfectious causes of fever include acute toxic reactions to substances of abuse, reactions to injected adulterants, and withdrawal syndromes. Cocaine and amphetamines can cause acute fever. Patients with “cotton fever” develop a flulike syndrome within hours after injection with drug suspensions filtered through cotton balls. Findings may include tachypnea, tachycardia, abdominal pain, and inflammatory retinal nodules. Chest radiographs typically are normal but may demonstrate inflammatory pulmonary granulomata.

Symptoms spontaneously resolve within  hours. Patients withdrawing from barbiturates or heroin also may appear acutely ill, presenting with chest and abdominal pain, diaphoresis, tachycardia, and fever.
Because no reliable markers are available to exclude serious illness in the febrile injection drug user, common practice samples blood for culture to detect bacteremia or endocarditis when no clear other source exists (e.g., pneumonia, urine infection, cellulitis, or abscess) while admitting such patients for observation pending results. In clinically well patients for whom follow­up can be ensured, outpatient management is reasonable after appropriate culture specimens are obtained.
Explore socioeconomic issues such as the injection drug user’s ability to purchase medications and access to outpatient follow­up; the latter may impact disposition plans.
Deliver nonjudgmental instruction on measures to reduce the risk of recurrent harm and offer drug rehabilitation (even as an outpatient referral) in all cases. If available, counsel about local needle exchange centers or supervised drug injection centers, which can save lives, prevent disease transmission, and improve health in this population.
DYSPNEA
A wide range of infectious and noninfectious entities may produce dyspnea and cough in patients with ongoing drug injection. Pneumonia in injection drug users is typically community acquired (see Chapter 155, “Human Immunodeficiency Virus Infections”). However, dyspnea may arise from aspiration during intoxication, tuberculosis, opportunistic infections, presence of foreign body, and septic pulmonary emboli complicating right­sided endocarditis. Place all febrile injection drug users who present with dyspnea, cough, or abnormal findings on chest radiograph in respiratory isolation until tuberculosis is excluded or an alternative diagnosis is found.
Noninfectious causes of dyspnea include noncardiogenic pulmonary edema, pneumo­ or hemothorax, toxic reaction to injected substances, hypersensitivity reaction, foreign body granulomatosis, and exacerbation of reactive airway disease. Pneumothorax and hemothorax are seen most commonly in association with the practice of “pocket shooting,” in which drug users inject into the supraclavicular fossa to access the subclavian, jugular, or brachiocephalic vein. “Talc lung” is a syndrome of progressive respiratory distress and diffuse interstitial infiltrates caused by the injection of the talc adulterant. Hypersensitivity reactions, associated with both heroin and cocaine injection, present with cough and wheezing and typically respond to inhaled β­agonist therapy. Noncardiogenic pulmonary edema is associated with both heroin and cocaine use, and patients display dyspnea, exhibit a low pulse oximetry reading, or have a radiograph revealing diffuse alveolar infiltrates. Treatment is supportive. Finally, septic, air, or needle fragment emboli to the lungs can produce dyspnea.
ALTERED MENTAL STATUS AND NEUROLOGIC ABNORMALITIES
Drug intoxication or withdrawal, stroke syndromes, hypoxia, delayed leukoencephalopathy, infectious diseases, mycotic aneurysms, and secondary trauma from either loss of consciousness and fall or drug­related violence may all produce altered mental status or other neurologic impairment in injection drug users. CNS infections may result from contiguous spread of overlying soft tissue infection, embolic complications of distant infections
(e.g., endocarditis), or extension of local infections (e.g., vertebral osteomyelitis). Nervous system infections that commonly occur in this population include epidural abscess, bacterial and fungal meningitis, and brain abscess. Meningococcus, pneumococcus, and Staphylococcus aureus bacteremia from endocarditis are common causes of bacterial meningitis. Both tetanus and botulism exist more often in patients who inject drugs and may present with cranial nerve involvement, altered mental status, and progressive symmetric paralysis. Infections caused by opportunistic organisms,
 such as Toxoplasma, are common in patients with coincident HIV infection who have low CD4 counts (especially <100/mm ). Stroke syndromes may occur secondary to low­flow states during heroin intoxication; hypertensive hemorrhage from amphetamines, phencyclidine, or cocaine; and embolized vegetations associated with infectious endocarditis. Delayed leukoencephalopathies, both hypoxic and nonhypoxic, have been reported in injection drug users but are rare.
BACK PAIN
Back pain may result from an epidural abscess, vertebral osteomyelitis, spondylodiscitis, or trauma; often the WBC count, sedimentation rate, or C­ reactive protein are elevated in these conditions but not universally. Mycobacterial infections usually involve the ribs and vertebral column (Pott’s disease). These infections may be indolent and present only with pain or may demonstrate night sweats, fevers, and weight loss. In patients with coincident HIV infection, opportunistic infections may present with a more indolent course, and the only symptom may be local pain. Nontraumatic focal back pain in febrile or nonfebrile injection drug users requires imaging studies, usually MRI, to evaluate for possible infection. In patients with chronic back pain, failure to inquire about a history of IV drug use or ignoring features that suggest infection (e.g., pain that does not resolve when the patient lies down, severe nighttime pain, or failure of pain to improve with conservative therapy) can lead to missed diagnosis of a cord­compromising
 infections.
SPECIFIC INFECTIONS IN INJECTION DRUG USERS
HUMAN IMMUNODEFICIENCY VIRUS INFECTION
HIV infection and management are discussed in Chapter 155. All­cause mortality is three times higher among HIV­positive injection drug users than
,13 those who do not inject, with the largest portion attributable to acquired immunodeficiency syndrome–related deaths. Evidence supports the
 effectiveness of HIV prevention programs including needle exchange, education on condom usage, and agonist maintenance treatment, and more
 recently the use of preexposure prophylaxis.
INFECTIVE ENDOCARDITIS

The incidence of endocarditis in injection drug users is estimated to be  times that in the general population. For injection drug users presenting with fever, the risk of endocarditis increases to one in eight, and for injection drug users from an inner­city population who are later found to be
 bacteremic, the risk increases to 40%. Endocarditis in injection drug users is typically right sided (57% to 86% of cases); 55% to 94% of cases involve
,18 the tricuspid valve, 20% to 40% involve the mitral and aortic valves, and 5% to 14% involve both sides of the heart (see Chapter 156,
 ,20
“Endocarditis”). Hospitalizations for endocarditis are increasing in the setting of the current opioid epidemic. Chapter 156 covers endocarditis management in detail.
Presenting signs and symptoms in injection drug users with endocarditis include fever, murmur (up to 65%), cough, pleuritic chest pain, and
 hemoptysis. Right­sided heart murmurs that vary with respiration are typically pathologic and more specific for the diagnosis. Multiple opacities on
 chest radiograph, consistent with septic pulmonary emboli, are common in patients with right­sided endocarditis (Figures 296­1 and 296­2). Other findings include pyuria (22%) and hematuria (35%) due to glomerulonephritis from immune complex deposition, embolic renal infarction, and
,21 perinephric abscess. Systemic embolization is found in approximately 22% to 50% of cases, and embolic infections may precede the finding of
,22,23 endocarditis in 25% to 60% of cases.
FIGURE 296­1. Chest radiograph showing septic emboli. Multiple opacities are seen in this chest radiograph of an injection drug–using female patient who was found to have bacterial endocarditis.
FIGURE 296­2. CT image showing multiple peripheral cavitary lesions consistent with septic pulmonary emboli.
Diagnosis of infective endocarditis generally requires isolation of microbes in a blood culture and/or demonstration of typical lesions on echocardiography. The classic findings of embolic phenomena, including Janeway lesions and Roth spots, are usually not observed unless the
 infection is advanced and occur in less than 15% of cases. Osler’s nodules are usually not seen with right­sided endocarditis. Obtain at least three sets of blood cultures from separate sites, with at least an hour’s wait between collection of the first and last set, before the initiation of antibiotic therapy.
Determine empiric antibiotic therapy based on the stability of the patient and the ability to wait for initial blood culture results. Direct initial treatment against S. aureus (methicillin­specific or methicillin­resistant S. aureus) and Streptococcus and Enterococcus species, with consideration of local sensitivities and pathogens. If the injection drug user engages in needle licking or uses saliva to reconstitute the drug, antibiotic selection must cover oral (streptococcal and anaerobic) and skin flora.
PULMONARY INFECTIONS
Community­acquired pneumonia caused by Streptococcus pneumoniae and Haemophilus influenzae remains the most common pulmonary infection in injection drug users. Patients are also at high risk for infection due to S. aureus, including methicillin­resistant S. aureus; Klebsiella pneumoniae infection; aspiration pneumonia; tuberculosis; and, in HIV­positive patients, opportunistic infections caused by Pneumocystis jiroveci, cytomegalovirus, and atypical mycobacteria. Suspect aspiration pneumonia in those with a history of depressed level of consciousness and/or radiographic infiltrate in the posterior or basal lung segments.
The risk of tuberculosis, including drug­resistant tuberculosis and extrapulmonary tuberculosis (see earlier discussion of Pott’s disease), is higher in injection drug users, accompanied by delays in diagnosis and poor adherence to treatment regimens. The tuberculin skin test may be negative.

Coincident HIV infection is one of the major risks for the high incidence of tuberculosis. Tuberculosis management is discussed in detail in Chapter ,
“Tuberculosis.”

Patients are usually admitted to the hospital with respiratory isolation until tuberculosis is excluded. In patients without risk for Pseudomonas infection, an IV quinolone and IV ceftriaxone or cefotaxime are reasonable empiric coverage until culture results return. In those at risk for
Pseudomonas infection (structural lung disease, malnutrition, current or recent corticosteroid use or antibiotic use), consider an IV antipseudomonal
β­lactamase agent (cefepime, imipenem, meropenem, or piperacillin/tazobactam) and an IV antipseudomonal fluoroquinolone or, alternatively, an
 antipseudomonal β­lactamase agent, IV aminoglycoside, and fluoroquinolone. Injection drug users are also at increased risk for influenza due to
 injection practices and living conditions, so encourage yearly influenza vaccination.
SKIN AND SOFT TISSUE INFECTIONS
EPIDEMIOLOGY AND PATHOPHYSIOLOGY
Skin and soft tissue infections are common among injection drug users and include cellulitis, skin ulcers, subcutaneous abscesses, septic phlebitis, necrotizing fasciitis, Fournier’s gangrene, gas gangrene, and pyomyositis. Most are caused by the user’s own flora, with S. aureus and streptococcal species common pathogens. Because these infections are often self­treated and reporting is not required, the prevalence is difficult to determine.
Injection techniques and eventual loss of easily accessible veins predispose injection drug users to soft tissue trauma and ischemia. The drugs themselves and the adulterants irritate, sclerose, and necrose the skin. Desomorphine (street name Krokodil) typically contains large amounts of toxic components such as iodine and phosphorus and can cause serious damage to skin, blood vessels, bone, and muscles. Limb amputation may be
 necessary, which has given this drug the nickname “the flesh­eating drug.”
CLINICAL FEATURES AND DIAGNOSIS
Cutaneous infection presents with fever, pain, localized erythema, and edema. Inspect painful areas for fluctuance, crepitus, and lymphangitis suggestive of deeper infection or abscess. Cellulitis and abscesses are typically caused by S. aureus, Streptococcus, or community­acquired
 methicillin­resistant S. aureus. Abscess cultures may also demonstrate polymicrobial growth, with aerobic gram­negative rods, anaerobic cocci, and bacilli. Increased rates of Clostridium botulinum infection exist in injection drug users who engage in skin popping, particularly those using Mexican black tar heroin.

Tetanus is another potential complication of injection drug use, and mortality from tetanus is high in older, unvaccinated patients. Other skin concerns include retained portions of broken needles, which act as a nidus for infection or migrate into adjacent vessels and, in addition, pose an increased risk to the examining healthcare provider. These may be identified by radiograph prior to exploration.
Infections overlying venipuncture sites may produce septic thrombophlebitis and infected pseudoaneurysms. Femoral vein injection (“groin hit”) may start development of local gangrene as well as rapidly progressive and fatal Fournier’s gangrene. Injection into the jugular vein (“pocket shot”) may lead to cutaneous abscess formation involving the carotid triangle and produce airway obstruction, vocal cord paralysis, and laryngeal edema.
Imaging
For nonpulsatile areas of induration, bedside US can define an underlying abscess. Image any pulsatile masses with Doppler US prior to incision and drainage. Angiography may identify vasospasm, thrombosis, emboli, or mycotic aneurysms. Plain radiographs are not routinely needed, unless suspecting air in the soft tissues or radiopaque foreign bodies. CT or MRI can delineate the involvement of other structures and the extent of deep abscesses, especially in complex areas such as the neck or groin.
TREATMENT AND DISPOSITION
Incise and drain all uncomplicated small abscesses, large furuncles, and carbuncles. Treat injection drug users with superficial cellulitis without evidence of systemic involvement with oral antibiotics to cover streptococci and methicillin­resistant S. aureus (see Chapter 152, “Soft Tissue

Infections,” Table 152­2).
Febrile or toxic­appearing patients or those not responding to outpatient treatment require hospital admission. If hand, deep tissue, or muscle involvement is detected or suspected clinically, consult for possible exploration or debridement.
For admitted febrile or toxic­appearing patients, obtain blood and wound specimens for culture and start broad­spectrum IV antibiotic therapy. Base antibiotic coverage on community microbial prevalence and host factors. Appropriate choices include a penicillinase­resistant synthetic penicillin or vancomycin plus an antipseudomonal aminoglycoside, antipseudomonal penicillin, or cephalosporin (see Chapter 152, “Soft Tissue Infections”).

Update tetanus immunization.
VASCULAR INFECTIONS
Vascular infections associated with injection drug use include inadvertent arterial injection with resultant vasospasm or thrombosis, septic thrombophlebitis, venous and arterial pseudoaneurysms, and infected hematomas. Arterial injection causes pain, edema, and patchy mottling of the
 affected limb due to ischemia. Tissue necrosis and gangrene are the consequence of persistent focal ischemia. When suspecting limb ischemia, promptly consult a vascular surgeon to determine whether anticoagulation, surgical intervention, or intra­arterial thrombolysis is best. Limb edema
 and ischemia can progress to compartment syndrome or may be complicated by rhabdomyolysis.

Intra­arterial drug injection can result in an infected arterial pseudoaneurysm (Figure 296­3). Venous pseudoaneurysms are relatively rare and are usually secondary to septic phlebitis. Signs and symptoms are fever and a painful mass. Complications include life­threatening hemorrhage, sepsis,
,31 chronic claudication, chronic skin and soft tissue infections, posttraumatic ulcers, and limb loss. A pseudoaneurysm is similar in gross appearance to an abscess; the presence of pulsations and a bruit suggest this diagnosis. Because of the disastrous hemorrhagic consequences of attempted incision and drainage, all painful masses, particularly in the groin, should be first imaged with duplex US or contrast CT.
FIGURE 296­3. Volume­rendering CT of the wrist showing a radial artery pseudoaneurysm in the inferior portion of the image. The pseudoaneurysm has displaced the radial artery away from the bony radius.
Treatment is antibiotic therapy guided by recommendations for endocarditis (see Chapter 156, “Endocarditis”). Surgical options include ligation and resection of the infected pseudoaneurysm with or without selective revascularization.
BONE AND JOINT INFECTIONS
Bone and joint infections occur either through contiguous spread from an overlying skin or soft tissue infection or through hematogenous spread from a distant site. Infecting microorganisms in injection drug users include S. aureus and other streptococci, or they may be unusual, such as Candida and gram­negative organisms.
OSTEOMYELITIS
In injection drug users, osteomyelitis is more frequent in the axial skeleton than in the extremities. Injection drug use–related osteomyelitis involves the vertebral column in approximately 50% of cases, particularly the lumbar segments, followed by the sternoclavicular joint in approximately 18% of cases, the sacroiliac joints, and the extremities, especially the hip and knee joints, in 17% of cases. Vertebral osteomyelitis usually presents with localized pain and tenderness to palpation over the involved bone, and a soft tissue mass may be palpable. Osteomyelitis coexists with spinal epidural
 abscess in approximately 80% of cases. Symptoms may be present for days in the case of bacterial infections or weeks in the case of fungal or mycobacterial infections. The presence of fever, leukocytosis, and an elevated erythrocyte sedimentation rate and C­reactive protein level is helpful, but their absence does not exclude these infections.
Culture any drainage from a contiguous abscess. Biopsy or needle aspiration of joint spaces and bony infections may be necessary, especially in the case of infection with unusual or fastidious organisms, such as Mycobacterium, Candida, or Eikenella. Eikenella corrodens osteomyelitis may occur in injection drug users who lick their needles prior to injection.
Fungal infections are rare but increasing in spinal infections related to immunosuppression and IV drug use. Candida species infection occurs in as many as 20% of patients with injection drug use–related osteomyelitis. Candidal infections are probably hematogenous in origin and have been reported from the use of contaminated reconstituted lemon juice to mix drugs before injection. An initial flulike syndrome lasting  to  days is followed by the appearance of metastatic lesions involving the skin, eye (chorioretinitis and endophthalmitis), and then bones and joints several days to weeks later. Rarely, Aspergillus species may cause osteomyelitis of the sternum in injection drug users.
MRI is currently the imaging modality of choice at many facilities because it delineates both the longitudinal and paraspinous extension of an abscess and can determine the exact site of infection. CT may reveal disk space narrowing and bony lysis suggesting osteomyelitis, but it is neither as sensitive
 nor as specific as MRI. Patients with osteomyelitis warrant admission, and unless the patient appears septic, the patient has focal neurologic complaints, or coincident endocarditis is a concern, antibiotic therapy should be withheld until culture results are obtained.
Early consultation with the orthopedist or neurosurgeon guides the timing of antimicrobial coverage, because blood culture results may be
 insufficient, and a CT­guided needle biopsy for epidural abscess or a bone sample culture for osteomyelitis is often required. Base antimicrobial choice on culture results. Therapy is typically required for  to  weeks. Unstable injection drug users who are suspected of having osteomyelitis should receive vancomycin to cover S. aureus and ceftazidime to cover Pseudomonas (see Chapter 281, “Hip and Knee Pain,” Table 281­4).
SEPTIC ARTHRITIS
Septic arthritis in injection drug users usually involves the knee or hip (see Chapter 284, “Joints and Bursae”). Sternoclavicular septic arthritis strongly
 suggests injection drug use. Patients often report recent trauma to the area, but causality is unclear. Consider gonococcal arthritis and tenosynovitis as causes of joint or ligamentous pain.
The initial symptoms are pain, localized tenderness, and swelling at the sites. The erythrocyte sedimentation rate is usually elevated, and fever and leukocytosis may be present. Most plain radiographs are normal; however, joint space widening, articular surface erosion, and surrounding soft tissue infection may be noted. CT or MRI may detect early infection. See Table 284­3 for discussion of findings of synovial fluid analysis. Treatment includes immobilization; empiric antibiotic therapy providing wide­spectrum coverage, including coverage for methicillin­resistant S. aureus; physical therapy; therapeutic arthrocentesis/washout; and occasional open drainage.
HEPATIC DISEASE
Injection drug users can develop liver disease from both parenterally and sexually transmitted hepatitis A, B, C, D, E, and non–A through G. In injection drug users, hepatitis B virus seroprevalence ranges from 25% to 55%. Worldwide hepatitis C virus infection is hyperendemic and rising, with a steady
 infection and death frequency over the past decade. In 2007, injection drug use was cited as a risk factor for 15% of new cases of hepatitis B virus and
 nearly half (48%) of new hepatitis C virus cases in the United States. Currently, the United States is experiencing an increase in HCV incidence attributed to injection drug use, and hepatitis C is associated with more deaths in the United States than combined deaths from  other infectious
 diseases.
For evaluation of a clinical syndrome suggestive of acute hepatitis (e.g., weakness, nausea, fever, abdominal pain, or jaundice), obtain laboratory tests that include serum transaminase levels, bilirubin level, alkaline phosphatase level, prothrombin time, and serologic testing. Many patients can receive an outpatient care plan. Admission criteria include inability to tolerate oral intake, toxicity, and significantly prolonged prothrombin time. Counsel patients about sexual transmission and needle exposure, and encourage informing all sexual and needle­sharing partners and household contacts of their exposure. Long­term sequelae of infection include chronic active hepatitis, decompensated cirrhosis, and primary liver cancer.
Unfortunately, drug treatment programs often lack adequate funding to offer optimal hepatitis B and C prevention, diagnosis, and care. Current hepatitis B virus vaccination rates among injection drug users remain low at 30%. The short­ and long­term benefit and cost of antiviral treatment for hepatitis C for both the individual patient who continues to intravenously inject drugs (increasing reexposure or reinfection) and any partners are
  unclear. Both partners are key in appropriately framed therapeutic discussions.
OPHTHALMOLOGIC INFECTIONS
Ophthalmologic infections in injection drug users are usually the result of hematogenous seeding from a primary source of infection or from opportunistic infections associated with HIV disease. Bacterial endophthalmitis often presents acutely, with pain, redness, lid swelling, and decrease in visual acuity. Inflammation is usually present in both the anterior and posterior chambers. White­centered, flame­shaped embolic hemorrhages (Roth spots), cotton­wool exudates, and macular holes may be present. S. aureus is the most commonly isolated organism, followed by Streptococcus
 species. Treatment involves subconjunctival, intravitreal, and systemic antibiotic therapy. Surgical intervention, such as vitrectomy, may be needed.
Fungal organisms, often Candida or Aspergillosis, but sometimes rarer organisms such as Torulopsis, Helminthosporium, and Penicillium species, are causes of endophthalmitis among injection drug users, notably from Mexican black tar heroin injection. In injection drug users coinfected with HIV, cytomegalovirus infection, toxoplasmosis retinitis, and choroidal Cryptococcus and Mycobacterium avium­intracellulare complex infections must also be considered. Symptoms include blurred vision, pain, poorly reactive pupil, and decreased visual acuity and can progress over days to weeks. White cotton­like lesions are seen on the choroid retina, with vitreous haziness. Uveitis, papillitis, and vitreitis also have been reported. Microbiologic diagnosis is made from the results of blood and vitreous culture. Treatment includes amphotericin B, amphotericin lipid complex, and fluconazole,
,40 with or without intravitreous antifungal therapy and early vitrectomy.


