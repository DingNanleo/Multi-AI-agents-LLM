## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 155: Human Immunodeficiency Virus Infection
Catherine A. Marco; Kamna S. Balhara; Richard E. Rothman
EPIDEMIOLOGY
The human immunodeficiency virus (HIV) is the leading cause of infectious disease deaths worldwide. As of 2016, an estimated .7 million people
 worldwide and .2 million people in the United States have HIV infection or acquired immunodeficiency syndrome (AIDS). Although HIV exists everywhere across the globe, the vast majority of new infections (95%) occur in those living in low­ and middle­income countries. In sub­Saharan

Africa, the world’s most affected region, nearly  in every  adults is living with HIV.

Despite the global burden, the number of new HIV infections and deaths is falling each year. Since the peak of the epidemic in 1996, new HIV infections
 dropped by nearly 50%; similar worldwide rates of AIDS­related deaths declined by more than 50% since the peak in 2004. Risks associated with acquiring HIV infection include homosexuality or bisexuality, injection drug use, heterosexual exposure, receipt of a blood transfusion prior to 1985, and maternal HIV infection (risk for vertical and horizontal maternal–neonatal transmission). Currently, the majority of HIV cases in the United States (67%) have occurred through men who have sex with men. Heterosexual contact accounts for approximately 24% of transmissions (with recent declines in that group), followed by about 6% associated with injection drug use and 3% with male­to­male sexual contact
 and IV drug use. New HIV infection rates continue to rise among young disadvantaged minority populations (many of whom use the ED for both primary and emergency care).
African Americans represent 12% of the total U.S. population but almost half (43%) of those with new HIV infections, the highest of any group by race and sex, notably in men having sex with men. Hispanics also have a higher proportion of new infections (26%) than accounted for by their relative size
 in the population (18%). ED visits by HIV­infected individuals occur at rates higher than the general population due to the characteristics of the
 populations who use the ED, which are the same groups disproportionately affected by HIV/AIDS.
PATHOPHYSIOLOGY
HIV is a cytopathic retrovirus that kills infected cells. The virus is labile and neutralized easily by heat and common disinfecting agents such as 50% ethanol, 35% isopropyl alcohol, .3% hydrogen peroxide, or a 1:10 solution of household bleach. There are two major subtypes of HIV; HIV­1 is the predominant subtype worldwide and is the cause of AIDS. HIV­2 causes a similar immune syndrome, but exists primarily in western Africa and is infrequent in the United States, but its incidence is growing.
The HIV virion is a central RNA molecule and a reverse transcriptase protein surrounded by a core protein encased by a lipid bilayer envelope. After infection, HIV selectively attacks host cells involved in immune function, primarily CD4+ T cells. Within the host cell, HIV­encoded RNA uses reverse transcription to enter into DNA, aided by the enzyme reverse transcriptase. The viral genome integrates into the host genome, where it may lie dormant or be transcribed and translated to produce virally encoded proteins and new HIV virions. As a result of infection, immunologic abnormalities eventually occur, including lymphopenia, qualitative CD4+ T­cell function defects, and autoimmune phenomena. Defects in cellular immunity ultimately result in a variety of opportunistic infections and neoplasms.
HIV exists in saliva, urine, cerebrospinal fluid (CSF), pus, brain, tears, alveolar fluid, synovial fluid, and amniotic fluid. Transmission of HIV occurs through semen, vaginal secretions, blood or blood products, and breast milk, and in utero by transplacental transmission. Transmission of HIV infection does not occur with casual contact. There is only one documented confirmed case of transmission from healthcare worker to patient in the
United States, which involved an infected dentist in Florida who transmitted the virus to six patients; as of 2018, there were  cases of confirmed patient–to–healthcare worker transmissions, with the vast majority occurring before 1991 (see later discussion regarding occupational exposure).

NATURAL HISTORY AND CLINICAL STAGES OF HIV INFECTION
Chapter 155: Human Immunodeficiency Virus Infection, Catherine A. Marco; Kamna S. Balhara; Richard E. Rothman 
. Terms of Use * Privacy Policy * Notice * Accessibility
Stage  or acute HIV infection occurs  to  weeks after infection with HIV. Also called acute retroviral syndrome, this is the initial response to infection, causing symptoms in the majority of those infected. The clinical presentation is nonspecific, resembling a flulike or mononucleosis­like syndrome; the diagnosis is missed in about 75% of cases. Symptoms of acute HIV infection typically occur within  month of becoming infected, may last for  to  weeks, and include fever (>90%), fatigue (70% to 90%), pharyngitis (>70%), rash (40% to 80%), headache (30% to 70%), and lymphadenopathy (40% to

70%); other reported symptoms are weight loss, headache, and diarrhea. Seroconversion and detectable antibody response to HIV usually occur  to  weeks after infection, although delays can be up to  months.
Stage  of HIV infection is the period of clinical latency or HIV inactivity during which time patients generally have no complaints or findings on physical examination except for possible persistent generalized lymphadenopathy (enlarged lymph nodes in at least two noncontiguous sites other than inguinal nodes). For patients not taking any medication, the median incubation time from exposure to the development of AIDS is estimated at  years for adults; shorter incubation periods occur in untreated infants and older adults. Virologic studies of patients during this period suggest that a steady state of HIV replication and CD4+ T­cell death and replacement exists until increased levels of HIV replication occur. Variables most predictive of disease stage are viral load and CD4+ T­cell counts, with a steeper decline in CD4+ T­cell count and a higher viral burden associated with more rapid progression and more adverse outcomes. Other non–HIV­related factors, such as age and malignancy, also impact disease progression. Toward the end of the clinical latency period, as the CD4 count begins to drop and viral load starts to rise, patients begin to develop symptomatic infection characterized by conditions that are more common and more severe in the presence of HIV infection, but are not AIDS­indicator conditions. These include thrush, persistent vulvovaginal candidiasis, peripheral neuropathy, cervical dysplasia, recurrent herpes zoster, and idiopathic thrombocytopenic purpura.

Stage  of HIV infection has either laboratory markers of severe immunosuppression (CD cell counts <200 cells/mm ) or occurrence of one of any opportunistic infections or AIDS­defining illnesses (Table 155­1).
TABLE 155­1
Stage  AIDS­Defining Opportunistic Illnesses in HIV Infection
Bacterial infections, multiple or recurrent* Candidiasis of bronchi, trachea, or lungs
Candidiasis of esophagus
Cervical cancer, invasive†
Coccidioidomycosis, disseminated or extrapulmonary
Cryptococcosis, extrapulmonary
Cryptosporidiosis, chronic intestinal (>1 month in duration)
Cytomegalovirus disease (other than liver, spleen, or nodes), onset at age >1 month
Cytomegalovirus retinitis (with loss of vision)
Encephalopathy attributed to HIV
Herpes simplex: chronic ulcers (>1 month in duration) or bronchitis, pneumonitis, or esophagitis (onset at age >1 month)
Histoplasmosis, disseminated or extrapulmonary
Isosporiasis, chronic intestinal (>1 month in duration)
Kaposi’s sarcoma
Lymphoma, Burkitt’s (or equivalent term)
Lymphoma, immunoblastic (or equivalent term)
Lymphoma, primary, of brain
Lymphoid interstitial pneumonia or pulmonary lymphoid hyperplasia complex* Mycobacterium avium complex or Mycobacterium kansasii, disseminated or extrapulmonary
Mycobacterium tuberculosis of any site, pulmonary,† disseminated, or extrapulmonary
Mycobacterium, other species or unidentified species, disseminated or extrapulmonary
Pneumocystis jirovecii (previously known as Pneumocystis carinii) pneumonia
Pneumonia, recurrent†
Progressive multifocal leukoencephalopathy
Salmonella septicemia, recurrent
Toxoplasmosis of brain, onset at age >1 month
Wasting syndrome attributed to HIV
Abbreviations: AIDS = acquired immunodeficiency syndrome; HIV = human immunodeficiency syndrome.
*Only among children aged <13 years. (Centers for Disease Control and Prevention: 1994 Revised classification system for human immunodeficiency virus infection in children less than  years of age. Morbid Mortal Wkly Rep 1994;43[No. RR­12].)
†Only among adults and adolescents aged >13 years. (Centers for Disease Control and Prevention: 1993 Revised classification system for HIV infection and expanded surveillance case definition for AIDS among adolescents and adults. Morbid Mortal Wkly Rep 1992;41[No. RR­17].)
DIAGNOSIS
Early diagnosis of acute HIV infection allows the benefit of limiting risk of unrecognized HIV and also initiation of antiretroviral therapy (ART), which reduces symptoms and slows disease progression.
Acute HIV is the time from HIV transmission to seroconversion. Diagnosis of acute HIV infection can now be made with newer fourth­generation HIV tests (see later discussion). Other methods for earlier detection of HIV­1 include techniques to detect DNA, RNA, or HIV antigens, although these tests are not always available in the ED. Mean times from transmission to detection are shortest for viral load (17 days), followed by p24 antigen (22 days),
 enzyme­linked immunosorbent assay positivity (25 days), and Western blot positivity (31 days).
For patients with suspected acute HIV that has not been confirmed (i.e., those with a high­risk profile presenting with fever of unknown origin and/or a syndrome suspicious for acute seroconversion), counseling and urgent referral to outpatient follow­up are best.
HIV TESTING METHODS
HIV infection diagnosis uses identification of HIV nucleic acid, detection of viral­specific antigen, detection of antibodies to HIV, and isolation of the virus by culture (now rarely used in practice). The most commonly used testing method for HIV is detection of antibodies to the virus. These newer testing methods revolutionized the ability of ED providers to diagnose patients with HIV. Previously, HIV testing involved sequential use of an enzymelinked immunosorbent assay, followed by a Western blot assay. Enzyme­linked immunosorbent assay is approximately 99% specific and .5% sensitive; Western blot testing is nearly 100% sensitive and specific if performed under ideal laboratory conditions. Enzyme­linked immunosorbent assay detects specific serum antibodies to HIV antigens. Western blot assay detects HIV antibodies to viral antigens. Reasons for indeterminate test results include early seroconversion, cross­reacting antibodies, pregnancy, presence of an autoimmune disease, or technical errors.
RAPID HIV TESTS
There are numerous rapid HIV tests approved for use by the U.S. Food and Drug Administration, usable as single­use disposable tests of blood, serum,
 plasma, or oral fluid. Sensitivity and specificity are comparable with those of standard serologic testing, and minimal training is required for administration. Relay any point­of­care results to the patient as preliminary positive if reactive, and confirm the results with Western blot testing.
Negative test results may miss patients in the window period before seroconversion; this requires a repeat test at  months.
THE HIV TESTING ALGORITHM

The Centers for Disease Control and Prevention recommends laboratory testing approaches for HIV. The algorithm calls for automated testing for antibody to HIV­1 and HIV­2 simultaneously with detection of HIV­1 p24 antigen, permitting detection of acute infections. In instances where this set of tests is negative, no further testing occurs, and the patient is counseled that he or she tested negative. For those with positive results, follow­up testing differentiates HIV­1 and HIV­2. In cases where the differentiation test is negative, a nucleic acid amplification test confirms acute seroconversion.
Turnaround time for the combined assay and HIV­1/2 differentiation assay is about  minutes. Turnaround time for confirmatory testing with nucleic acid amplification can take up to a few days. This new algorithm allows better early detection; ED­based studies show this is feasible and will detect
11­13 new, acutely infected patients.
CD4+ T­CELL COUNTS

CD4+ T­cell counts of <200 cells/mm and a viral load of >50,000 copies/mm are associated with increased risk of AIDS­defining illnesses. When this information is unavailable or the stage of disease is unknown, use the total lymphocyte count to approximate the CD4+ T­cell count. In a recent ED
   study, a total lymphocyte count <1700 cells/mm had a sensitivity of 95% for a CD4 count of <200 cells/mm .
HIV TESTING PRACTICES IN THE ED
Historically, HIV testing challenges in the ED were time limitations, difficulty with follow­up, ity requirements, costs, and questions regarding reimbursement. Advances in testing technologies coupled with new policy guidelines address these barriers. In 2006, the Centers for Disease
Control and Prevention recommended testing guidelines that included an opt­out approach to consent, meaning that HIV testing can be performed
 after notifying the patient that testing will be done (without separate written consent) unless they explicitly decline. Further, the U.S. Preventive
Services Task Force gave a “Grade A” recommendation for routine HIV screening for all people age  to  years, as well as younger adolescents and older adults who are at an increased risk for HIV infection and all pregnant women, including those in labor whose HIV status is unknown. The Patient
Protection and Affordable Care Act requires new insurance policies to pay for preventive services with “Grade A” recommendation. The American
College of Emergency Physicians supports ED HIV testing based on clinical need and supports screening with caveats. While overall rates of HIV testing in EDs in the United States in the early part of the century were low (approximately .2% of all ED visits), programs are increasing, particularly in urban
 and/or academic centers; in some areas, increases in testing paralleled declines in undiagnosed HIV and control of the epidemic. Ongoing research targets best ED testing approaches (e.g., nontargeted universal vs. targeted), with local prevalence playing a key role in the screening plan chosen.
CLINICAL FEATURES AND TREATMENT
INITIAL CARE: GENERAL CONSIDERATIONS
The spectrum of disease caused by HIV infection varies, from those coming to the ED with asymptomatic infection for symptoms unrelated to HIV disease, to symptomatic patients seeking care from involvement of virtually any organ system and with multiple coexisting symptoms.
Maintain ity regarding HIV­related diagnoses in the ED. Begin care without discrimination and without assuming any illness trajectory unless advance directives, including cardiopulmonary resuscitation, are already in place. If friends or family accompany the patient to the ED, first ask the patient about privacy issues before beginning any conversations.
Always use blood and body fluid precautions during care (in some hospitals, this is termed universal or standard precautions). Healthcare workers can be exposed to the blood and body fluids of HIV­infected patients or patients at high risk of harboring the HIV virus. ED­based studies show that many patients have unsuspected HIV infection and that seropositivity cannot be predicted accurately, even after assessment of risk factors. See Chapter 163,
“Occupational Exposures, Infection Control, and Standard Precautions.”
A basic history and physical examination help to identify the clinical stage of disease and to direct attention to the most likely complications. Obtain a thorough report detailing past and current medications including ART, previous infections, and the patient’s ability to perform activities of daily living.
The exam seeks findings of organ involvement related to the chief complaint and features that might assist with staging such as oral candidiasis, skin lesions, temporal wasting, and dementia.
Diagnosis and initial care seek to recognize infection (when not previously diagnosed), assess the severity of disease, identify specific organ(s) involved, and institute therapy. Consultation with an infectious disease specialist and others with expertise in HIV infection is often necessary to provide proper therapy and disposition. Disposition decisions are based on the need for inpatient evaluation or management and the patient’s ability to function as an outpatient, the latter often being driven by oral intake and ambulation ability and the availability of appropriate medical follow­up.
Healthcare, family resources, and case management can aid decision making about appropriate site for care.
Systemic symptoms such as fever, weight loss, and malaise are common in HIV­infected patients and account for the majority of HIV­related ED presentations. In the ED, look for systemic infection, malignancy, drug toxicity, or metabolic abnormalities. Often, this includes assessing serum electrolytes with renal function, CBC, liver function studies, blood cultures, urinalysis and urine culture, hepatic function tests, and chest radiograph; use serologic testing for syphilis, cryptococcosis, toxoplasmosis, cytomegalovirus infection, and coccidioidomycosis more selectively. Lumbar puncture occurs after neuroimaging if headache, altered sensorium, visual change, or other focal neurologic symptoms or signs are present.
When treating the febrile ill­appearing HIV patient, provide fluid resuscitation and prompt empiric antibiotics, and admit for further evaluation and management. Outpatient evaluation and treatment are indicated only when all of the following conditions are met: the source of the fever does not dictate admission, the patient is able to function adequately at home (e.g., can maintain sufficient oral intake), and timely medical follow­up can be arranged.
HIV STAGE AND CAUSES OF FEVER
Infections are the most common cause of hospitalization among HIV­infected persons. In HIV­infected persons without obvious localizing signs or
 symptoms, sources of fever vary by stage of disease. Patients with CD4+ T­cell counts of >500 cells/mm generally have causes of fever similar to
 those in nonimmunocompromised patients, whereas those with CD4+ T­cell counts between 200 and 500 cells/mm are more likely to have infections that are associated with early immune compromise, including bacterial pneumonia, herpes zoster, and tuberculosis. For patients with CD4+

T­cell counts of <200 cells/mm , the most common causes of fever without obvious localizing findings are early Pneumocystis jirovecii pneumonia
(formerly known as Pneumocystis carinii); central line infection; infection with Mycobacterium avium complex, Mycobacterium tuberculosis, or cytomegalovirus; drug fever; and sinusitis. Other causes of fever include endocarditis, lymphoma, and infection with Histoplasma capsulatum or
Cryptococcus neoformans.
Disseminated M. avium Complex Infection
Disseminated M. avium complex infection occurs predominantly in patients with CD4+ T­cell counts of ≤100 cells/mm  who are not on ART or azithromycin prophylaxis. Persistent fever and night sweats are typical symptoms. Associated symptoms include weight loss, diarrhea, malaise, and anorexia. Dissemination to the bone marrow, liver, and spleen results in anemia and elevated alkaline phosphatase levels. Diagnose this with acid­fast stain of stool or other body fluids or by blood culture. Cultures using the lysis­centrifugation method are more sensitive for M. avium complex (and histoplasmosis) and aid diagnosis in patients with late­stage disease and fever of unknown origin. Treatment for M. avium complex reduces bacteremia and improves symptoms but does not eradicate disease; therapy starts with clarithromycin combined with ethambutol and rifabutin.
Azithromycin is an alternative therapy.
Immune Reconstitution Inflammatory Syndrome
Immune reconstitution inflammatory syndrome mimics an autoimmune event, with lymphadenitis, fever, and other symptoms starting weeks to months after beginning ART, often during tuberculosis therapy. There is no definitive diagnostic test for this condition. Treatment guidelines advise continuing ART; use nonsteroidal anti­inflammatory agents for mild to moderate cases; in severe cases, use corticosteroids (prednisone  to  milligrams/kg or equivalent for  to  weeks). Add the appropriate antimicrobials if there is a known or suspected infection.
Cytomegalovirus
Cytomegalovirus is a common cause of serious opportunistic viral disease in HIV­infected patients. Disseminated disease involves the GI, pulmonary, and central nervous systems. The most important manifestation is retinitis (see later section, “Cytomegalovirus Retinitis”). Treatment is with foscarnet or ganciclovir. Oral ganciclovir is a prophylaxis agent (Table 155­2).
TABLE 155­2
Treatment Recommendations for Common Human Immunodeficiency Virus–Related Infections
Organ System Infection Therapy
Systemic Mycobacterium avium­ Clarithromycin, 500 milligrams PO twice a day intracellulare and
Ethambutol,  milligrams/kg PO once a day and
Rifabutin, 300 milligrams/kg PO once a day (addition may improve survival and decrease risk of macrolide resistance)
CMV infection (GI) Ganciclovir,  milligrams/kg IV twice a day for 3–4 wk or
Foscarnet,  milligrams/kg every  h for 3–4 wk
Pulmonary Pneumocystis jirovecii Trimethoprim­sulfamethoxazole (TMP­SMZ),  milligrams/kg (of TMP component) every  h for  d
(Pneumocystis carinii) or pneumonia Clindamycin 600 milligrams every  h plus primaquine 15–30 milligrams once daily for  d
Note: Other second­line options are available for those who are allergic.
If partial pressure of arterial oxygen is <70 mm Hg or alveolar­arterial gradient is >35 mm Hg, then add:
Prednisone,  milligrams twice a day for  d, then  milligrams once a day for  d, then  milligrams once a day for  d
Mycobacterium Isoniazid,  milligrams/kg PO once a day tuberculosis infection* and
Rifampin,  milligrams/kg (600 milligrams max) PO once a day orrifabutin  milligrams/kg PO once a day
(for person on PIsw, NNRTIs, integrase inhibitors, or methadone) and
Pyrazinamide, 15–30 milligrams/kg (2 grams max) PO once a day and
Ethambutol, 15–20 milligrams/kg (1.6 grams max) PO once a day and
Pyridoxine (vitamin B )  milligrams PO once daily

Note: Treatment duration determined by site of disease and response to therapy.
CNS Toxoplasmosis† Pyrimethamine, 200­milligram loading dose PO followed by 50–75 milligrams PO once a day for 6–8 wk and
Sulfadiazine, 1–1.5 grams PO every  h for 6–8 wk and
Leucovorin, 10–25 milligrams once a day
Cryptococcosis‡ Amphotericin B, .7 milligram/kg IV once a day for  wk and
Flucytosine,  milligrams/kg IV four times a day for  wk then
Fluconazole, 400 milligrams/d PO for 8–10 wk
Ophthalmologic
CMV infection (retinitis)§ Valganciclovir, 900 milligrams PO twice a day for 14–20 d of induction therapy, then 900 milligrams PO daily for maintenance therapy
IV ganciclovir and foscarnet are now rarely used because of need for permanent indwelling catheter and availability of safer options (valganciclovir)
GI Candidiasis (thrush— Clotrimazole, 10­milligram troches  times a day for 7–14 d limited to mouth) or
Nystatin, 500,000 units  times a day, gargle for 7–14 d
Esophagitis (primarily Fluconazole, 200–400 milligrams/d PO
Candida)
Salmonellosis† Ciprofloxacin, 500 milligrams PO twice a day for 2–4 wk
Note: Modify according to susceptibilities when available.
Cryptosporidiosis No known effective cure; best results with highly active antiretroviral therapy and symptomatic treatment
Cutaneous Herpes simplex Acyclovir, 400 milligrams PO  times a day for 7–10 d or
Famciclovir, 500 milligrams  times a day for 7–10 d or
Valacyclovir,  gram PO twice a day for  d or for severe disease
Acyclovir, 5–10 milligrams/kg IV every  h for  d
Herpes zoster Acyclovir, 800 milligrams PO  times a day for 7–10 d or
Famciclovir, 500 milligrams PO  times a day for 7–10 d or
Valacyclovir,  gram PO  times a day for 7–10 d or for ocular or disseminated disease
Acyclovir, 5–10 milligrams/kg PO every  h for 5–7 d
Candida or Trichophyton Topical clotrimazole  or  times a day for  wk infection or
Nystatin, 500,000 units  times a day, gargle for 7–14 d or
Fluconazole 100–200 milligrams PO every day for 7–14 d
Note: Medication dose and duration may need to be adjusted based on drug–drug interactions, renal and/or liver functions based on individual patient, and concomitant medications. Please check with your local pharmacist prior to using these doses.
Abbreviations:CMV = cytomegalovirus; NNRTIs = nonnucleoside reverse transcriptase inhibitors.
*Specific drug regimen must be adjusted if patient is receiving highly active antiretroviral therapy.
†Maintenance therapy required.
‡ Maintenance therapy required; may be discontinued if CD4+ T­cell count is >150 cells/mm3 for >16 wk.
§Maintenance therapy required until CD4+ T­cell count is >150 cells/mm3. Endocarditis
Fever in injection drug users should trigger suspicion for infective endocarditis, which often has a nonspecific presentation in the ED (see Chapter 156,
“Endocarditis”). Most ED physicians admit febrile injection drug users while awaiting the results of blood cultures and echocardiography given the high morbidity and mortality coupled with the difficulties encountered with outpatient follow­up in the drug user population.
Neoplasm and Drug Fever
Noninfectious causes of fever in HIV patients include neoplasm and drug fever. Non­Hodgkin’s lymphoma is the most frequently occurring neoplasm, characterized by high­grade, rapidly growing mass lesions. New CNS symptoms, particularly a change in mental status in the presence of fever, require neuroimaging. Definitive diagnosis of non­Hodgkin’s lymphoma requires biopsy. Radiotherapy and chemotherapy are effective treatment regimens.
Drug fever may be secondary to injection drug abuse or adverse drug reactions (see later discussion).
NEUROLOGIC COMPLICATIONS
Neurologic disease in HIV patients may be related to opportunistic infections, neoplasms, impact of HIV infection on CNS, or HIV treatment itself.
Presenting symptoms may include seizures, altered mental status, headache, meningismus, and focal neurologic deficits.
Patients with HIV presenting to the ED with headache, seizure, altered mental status, or focal neurologic deficits with or without fever should have
 neuroimaging, especially in patients with CD4 count <200 cells/mm . Although noncontrast CT is typically the first imaging modality used in the ED, contrast­enhanced CT and MRI may be needed if CT findings are equivocal or negative. If no mass lesion exists, lumbar puncture follows to assess or obtain the following: CSF pressures, WBC count and differential, protein and glucose concentrations, Gram staining, India ink staining, bacterial culture, mycobacterial culture, fungal culture, toxoplasmosis and cryptococcosis antigen assays, coccidioidomycosis titer, and polymerase chain reaction assays for JC virus, Epstein­Barr virus, cytomegalovirus, Toxoplasma gondii, herpes simplex virus types  and , and varicella­zoster virus.
Save additional CSF in case further testing needs arise later. Consider toxoplasmosis serology and QuantiFERON tuberculosis testing too. Even if the
ED evaluation is unrevealing, admit all patients with new or changed neurologic signs or symptoms.
HIV­ASSOCIATED NEUROCOGNITIVE DISORDER
HIV­associated neurocognitive disorder (also referred to as HIV encephalopathy, HIV­associated dementia, or AIDS dementia complex) is a progressive, subacute disorder heralded by subtle impairment of recent memory, cognitive deficits, and behavioral disturbances. Up to 50% of patients on ART
 have some form of HIV­associated neurocognitive disorder. Many patients may exhibit only mild deficits. However, inadequately treated patients may progress to the most advanced form of HIV­associated neurocognitive disorder, HIV­associated dementia, and demonstrate moderate to severe
 cognitive impairment with behavioral changes. HIV­associated dementia is a diagnosis of exclusion, once MRI and lumbar puncture have ruled out other pathologies. New signs or symptoms in a patient with known HIV­associated dementia should prompt workup for other CNS processes. ART is the most effective treatment for HIV­associated dementia.
TOXOPLASMIC ENCEPHALITIS

Since the introduction of ART, toxoplasmosis encephalitis remains the most commonly reported neurologic opportunistic infection. It occurs most
 commonly in patients with CD4+ cell counts <100 cells/mm as latent bradyzoites acquired early in life reactivate. Symptoms may include headache, fever, focal neurologic deficits, altered mental status, seizures, and behavioral changes. On unenhanced CT scan, toxoplasmosis typically appears as multiple subcortical lesions with a predilection for the basal ganglia and corticomedullary junction. Contrast­enhanced CT scan typically shows multiple ring­enhancing lesions with surrounding areas of edema. MRI is more sensitive than contrast­enhanced CT scan in detecting toxoplasmosis.
Consider primary CNS lymphoma as another potential cause or mimic. CSF may not be available since many patients are at risk for herniation; polymerase chain reaction, although highly specific (100%), is not sufficiently sensitive (50% to 80%) to detect T. gondii in CSF. Patients with positive serology (immunoglobulin G) in combination with symptoms and imaging suggestive of T. gondii should be treated.
Admit patients with suspected toxoplasmosis and treat with a combination of IV pyrimethamine plus sulfadiazine plus leucovorin (folinic acid).

Clindamycin is a substitute for sulfadiazine. Some trials show trimethoprim­sulfamethoxazole may have equal efficacy (Table 155­2). Corticosteroids can aid in treating any mass effect, but discontinue these as soon as possible. For patients responsive to toxoplasmosis therapy, use chronic suppressive therapy with oral sulfamethoxazole­trimethoprim; this can also be prophylaxis in patients with positive toxoplasmosis serologic test
 results and CD4+ T­cell counts of <100 cells/mm .
CRYPTOCOCCAL MENINGITIS

Cryptococcal infection occurs most commonly in patients with CD4+ counts of <50 cells/mm . The most common presenting signs are fever and headache, followed by nausea, altered mentation, and focal neurologic deficits. Presentation may be subacute, and meningismus is uncommon.
Although communicating hydrocephalus with high intracranial pressure may develop, CT imaging may be normal or nonspecific.
Diagnosis of CNS cryptococcal infection in HIV patients relies on CSF cryptococcal antigen testing (92% sensitive and 83% specific), fungal culture (95% to 100% sensitive), or staining with India ink (60% to 80% sensitive). Serum cryptococcal antigen testing helps but has lower sensitivity than CSF testing
(approximately 95%). The expected CSF WBC count elevation is often absent in patients with AIDS, although increased opening pressure is common and drainage aiming to reduce pressure by 50% or to less than  cm H O is best.

Patients with CNS cryptococcosis require hospital admission and IV amphotericin B and oral flucytosine for  days, followed by fluconazole for  weeks to clear the CSF (Table 155­2). Long­term maintenance therapy follows initial treatment.
OTHER NEUROLOGIC DISORDERS
Cytomegalovirus may cause encephalitis, radiculomyelitis, or mononeuritis multiplex, with nonspecific periventricular enhancement on neuroimaging and highly sensitive and specific CSF polymerase chain reaction. Evaluate patients with cytomegalovirus encephalitis for concurrent retinitis.
Ganciclovir is a mainstay of treatment. Reactivation of the JC virus may lead to progressive multifocal leukoencephalopathy, with focal neurologic deficits developing over weeks, although acute cases may mimic stroke, and initiation of ART is key to management. Multifocal demyelinating lesions exist on imaging; sensitivity of CSF polymerase chain reaction for JC virus is variable.
The incidence of primary CNS lymphoma has declined since the introduction of ART; once diagnosed, prognosis is poor, with a median survival of  months. CNS lymphoma may present with nonspecific symptoms or focal deficits, without fever. Postcontrast imaging may demonstrate a ringenhancing lesion, and presence of Epstein­Barr virus in CSF is highly sensitive. Other considerations in the presence of neurologic symptoms include bacterial meningitis, herpes simplex virus infection, neurosyphilis, tuberculosis (tuberculoma or meningitis, treated as systemic tuberculosis), cerebrovascular accidents, and metabolic encephalopathies. Neuropsychiatric disturbances may occur from HIV therapies including ART, such as efavirenz, or drugs to treat opportunistic infections, such as ganciclovir.
Peripheral neuropathies are common in HIV patients, either because of chronic HIV infection, known as HIV­associated distal sensory polyneuropathy, or treatment­related toxicity related to ART; change in treatment regimen may address the latter. Reserve opioids for short durations and severe pain;
 topical capsaicin or lamotrigine aid often. Autonomic neuropathies and inflammatory demyelinating polyneuropathies may also occur.
PSYCHIATRIC DISORDERS
HIV infection may cause CNS and metabolic disturbances that can produce psychiatric symptoms. HIV infection is also a psychosocial stressor and may contribute to social isolation, poverty, and hopelessness. In the ED, search for underlying organic causes, such as delirium, dementia, neurologic infection or mass, electrolyte abnormality, medication adverse effect, trauma, or other organic etiology of depression. Patients with AIDS psychosis typically develop hallucinations, delusions, or other behavioral changes.
21­23
Depression is common during all phases of HIV infection. Antidepressant therapy is often started if symptoms of depression continue for >2 weeks and with close monitoring for side effects. Patients with suicidal ideation or profound dysfunction may require inpatient psychiatric management.
An increased incidence of mania occurs in both the early and late stages of HIV infection. Late­stage mania is closely associated with dementia and carries a poor prognosis. If danger exists, use physical restraints or acute pharmacologic intervention. Other psychiatric manifestations may occur with increased incidence in the HIV­infected population, including schizophrenia, bipolar disorder, posttraumatic stress disorder, and personality disturbance.

Nearly 50% of those with HIV infection also have a history of substance abuse. Depression and psychotic symptoms are more prevalent among patients with substance abuse. ED management includes identification and outpatient referral to integrated substance abuse and psychiatric resources. Some antiretroviral agents have interactions with buprenorphine and methadone requiring dosage modifications of the latter two agents.
OPHTHALMIC COMPLICATIONS
Cytomegalovirus retinitis and herpes zoster ophthalmicus must be recognized by the emergency physician and have specialty consultation sought.
Other manifestations include HIV retinopathy, characterized by non–vision­threatening retinal cotton­wool spots (seen in >50% of patients with advanced HIV), retinal hemorrhages, and microaneurysms. Syphilis may lead to ocular complications, and Toxoplasma retinochoroiditis (whitish retinal lesions without hemorrhage), Cryptococcus chorioretinitis (multiple discrete yellowish spots on choroid and retina), and pneumocystis choroiditis (multiple pale yellow­white choroidal spots) may also occur. Treatment for these entities is the same as for systemic infection.
CYTOMEGALOVIRUS RETINITIS
Cytomegalovirus retinitis (Figure 155­1) is the most serious ocular opportunistic infection and is the leading cause of blindness in AIDS patients.

Since the advent of newer ART, the incidence of cytomegalovirus infection has decreased. Retinitis may be asymptomatic early but may present with changes in visual acuity, visual field cuts, photophobia, flashes, floaters, eye redness, or eye pain. Findings on indirect ophthalmoscopy are fluffy white perivascular lesions with areas of hemorrhage, which may be confused with benign cotton­wool spots. Request emergent ophthalmologic consultation early in suspected cytomegalovirus retinitis. Systemic treatment, often with oral valganciclovir, is a first­line treatment; those with sightthreatening lesions near the optic nerve or macula also need intravitreal ganciclovir.
FIGURE 155­1. Cytomegalovirus retinitis. “Pizza pie” or “cheese and ketchup” appearance is demonstrated by hemorrhages and the dirty white granular­appearing retinal necrosis adjacent to major vessels. [Photograph contributed by Richard E. Wyszynski, MD. Reproduced with permission from Knoop KJ, Stack
LB, Storrow AB, Thurman RJ: The Atlas of Emergency Medicine, 3rd ed, © 2009 by McGraw­Hill, Inc., New York.]
HERPES ZOSTER OPHTHALMICUS
Herpes zoster ophthalmicus (see Chapter 241, “Eye Emergencies”) usually presents with paresthesia and discomfort in the distribution of cranial nerve
V (ophthalmic branch), followed by the appearance of the typical zoster skin rash. Ocular complications include conjunctivitis, episcleritis, iritis,
 keratitis, secondary glaucoma, and, rarely, retinal necrosis. Early recognition and treatment can prevent ocular damage.
PULMONARY COMPLICATIONS
Pulmonary abnormalities in HIV­infected patients include a wide variety of conditions including community­acquired bacterial pneumonia, P. jirovecii pneumonia (PCP), tuberculosis, cytomegalovirus infection, cryptococcosis, histoplasmosis, chronic obstructive pulmonary disease, lymphoid interstitial pneumonia, and neoplasms. The most common cause of pneumonia in HIV­infected patients in the United States and Western Europe is

Streptococcus pneumoniae, followed by PCP and tuberculosis. Pulmonary radiographic findings are helpful in determining likely causes (Table
155­3). Admit patients with new­onset or profound pulmonary symptoms, especially in the presence of hypoxemia or altered mental status. In patients with known existing pulmonary involvement, disposition and care decisions are based on change from baseline, the effectiveness of ongoing or previous treatment, ability to adhere to therapy, and the ability to obtain outpatient follow­up.
TABLE 155­3
Chest Radiographic Abnormalities: Differential Diagnosis in the Patient With Acquired Immunodeficiency Syndrome
Finding Causes
Diffuse interstitial infiltration Pneumocystis jirovecii infection
Cytomegalovirus infection
Mycobacterium tuberculosis infection
Mycobacterium avium­intracellulare complex infection
Histoplasmosis
Coccidioidomycosis
Lymphoid interstitial pneumonitis
Focal consolidation Bacterial pneumonia
Mycoplasma pneumoniae infection
P. jirovecii infection
M. tuberculosis infection
M. avium­intracellulare complex infection
Malignancy
Nodular lesions Lymphocytic interstitial pneumonitis
Kaposi’s sarcoma
M. tuberculosis infection
M. avium­intracellulare complex infection
Fungal infection
Toxoplasmosis
Cavitary lesions P. jirovecii infection
M. tuberculosis infection
Bacterial infection
Fungal infection
Adenopathy Kaposi’s sarcoma
Lymphoma
M. tuberculosis infection
Cryptococcosis
Normal radiograph Upper respiratory infection
Bronchiolitis
P. jirovecii infection
PNEUMOCYSTIS PNEUMONIA

PCP is the most common opportunistic infection among AIDS patients. The causal agent is known as P. jirovecii (previously known as P. carinii), previously classified as a protozoan but now reclassified as a fungus. Approximately 70% of HIV­infected patients acquire PCP at some time during their illness, and PCP is often the initial opportunistic infection that establishes the diagnosis of AIDS. This infection is the most frequent serious complication of HIV infection in the United States and the most common identifiable cause of death in patients with AIDS. The incidence of PCP has
 decreased among patients on ART but remains a high trigger for morbidity and mortality. PCP pneumonia typically occurs in patients with a low CD4
 count of <200 cells/mm . The classic presenting symptoms of PCP are fever, cough (typically nonproductive), and shortness of breath (progressing from being present only with exertion to being present at rest).
Symptoms are often insidious and accompanied by fatigue. Chest radiographs most often show diffuse interstitial infiltrates (Table 155­3), but
 negative radiographic findings exist in 15% to 25% of patients with PCP. The lactate dehydrogenase level may be elevated in patients with PCP, but this test has low sensitivity and specificity, impairing utility. Arterial blood gas analysis usually demonstrates hypoxemia and an increase in the alveolar­arterial gradient. Suspect early PCP if a patient demonstrates a decrease in pulse oximetric values with exercise; even an ED “walk” can detect this exercise desaturation. Presumptive diagnosis of PCP is possible in the ED if there is hypoxemia without any other explanation. Inpatient diagnostics include bronchoscopy with specimen analyses.
30­32
The preferred therapy is trimethoprim­sulfamethoxazole (Table 155­2). Use body mass–based dosing,  to  milligrams/kg/d PO or IV; a typical
PO dose is two double­strength tablets three times daily for  days. For moderate to severe disease, use IV trimethoprim­sulfamethoxazole (15 to  milligrams/kg of trimethoprim and  to 100 milligrams/kg of sulfamethoxazole per day). Adverse reactions, including rash, fever, and neutropenia, occur in up to 65% of AIDS patients. Alternative regimens include trimethoprim­dapsone, clindamycin­primaquine, or atovaquone. Pentamidine is an alternative IV agent (Table 155­2). Add systemic steroids in patients with a partial pressure of arterial oxygen of <70 mm Hg or an alveolar­arterial
 gradient of >35 mm Hg. Oral prednisone, starting at  milligrams twice daily and tapering over  days (Table 155­2), is a common approach. Start
ART or continue any existing regimen.
Seventy percent of patients have reinfection within  months, which is why prophylactic therapy is key. Oral trimethoprim­sulfamethoxazole, one
 double­strength tablet daily, is preferred. Prophylaxis for all patients with CD4+ T­cell counts of <200 cells/mm is another common approach to mitigate PCP. Repeat PCP infections are often less responsive to therapy.
TUBERCULOSIS
Clinical manifestations of tuberculosis in HIV­infected patients vary according to the severity of immunosuppression. Typical presentations of
 tuberculosis occur in patients with CD4+ T­cell counts of >200 to 500 cells/mm . Those with tuberculosis and advanced HIV infection, with CD4 cell
 ,35 counts <100 cells/mm , often have extrapulmonary or disseminated disease. Classic manifestations include cough with hemoptysis, night sweats, prolonged fevers, weight loss, and anorexia. With worsening immunosuppression, patient presentation becomes less classic; in addition, upper lobe
 involvement and cavitary lesions are less common as patients become more immunosuppressed, particularly among patients with late­stage AIDS.
Negative purified protein derivative skin tuberculosis test results are frequent among AIDS patients due to immunosuppression. Definitive diagnosis of tuberculosis usually occurs with stain and culture of expectorated sputum, although some cases require bronchoscopy. Later stage HIV is also associated with increased frequency of extrapulmonary tuberculosis with clinical manifestation associated with the involved sites of infection.
Frequent sites of dissemination are peripheral lymph nodes, bone marrow, CNS, GI system, and urogenital system.
In the ED, think of tuberculosis in any HIV­infected patients with pulmonary symptoms, and begin precautions to avoid transmission. Place the patient in an isolation room and with an appropriate mask immediately and until the diagnosis is excluded. Current treatment guidelines recommend a fourdrug initial empirical therapy to include a combination of isoniazid, rifampin, ethambutol, and pyrazinamide (Table 155­2; see Chapter ,
37­39
“Tuberculosis”). Multidrug­resistant tuberculosis remains a concern, increasing the need for suspicion and early isolation. All HIV­infected patients with positive purified protein derivative skin tests should receive isoniazid plus pyridoxine for  to  months; alternatives include rifampin or rifabutin for  months. In addition, give empiric treatment to HIV­infected persons in close contact with another patient with active tuberculosis. Start

ART or continue a regimen, regardless of CD4 count.
OTHER PNEUMONIAS
Bacterial pneumonia is the most common pulmonary infection in HIV­infected patients. Morbidity and mortality are high, with an inpatient mortality
 rate of 10%. Common pathogens are S. pneumoniae, Haemophilus influenzae, and Staphylococcus aureus. Productive cough, leukocytosis, and the presence of a focal infiltrate suggest bacterial pneumonia. Risk factors and prognosis for bacterial pneumonia among HIV­infected persons on newer

ART are similar to those of the general population.
Patients with severe immunosuppression are predisposed to disseminated fungal infections such as those caused by C. neoformans, H. capsulatum,
 and Aspergillus fumigatus. Cytomegalovirus or M. avium complex infections can occur in patients with extremely low CD4 cell counts (<50 cells/mm ).
NONINFECTIOUS PULMONARY DISORDERS
Lymphocytic interstitial pneumonia may present with dyspnea and hypoxia. Typical radiographic findings include ground­glass opacities and/or nodules. Treat lymphocytic interstitial pneumonia with a systemic antiretroviral regimen. Chronic obstructive pulmonary disease and asthma are seen
 with increasing frequency and are managed with traditional therapies. HIV­infected persons are at increased risk for lung cancer, which may include
,45
Kaposi’s sarcoma and lymphoma. Increased incidence of pulmonary hypertension may be related to HIV infection, injecting drug use, and/or

ART. Pulmonary hypertension may present with dyspnea, cough, or chest pain and should be treated with ART.
CARDIOVASCULAR COMPLICATIONS
 48­51
Cardiovascular disease is one of the most common causes of death. HIV­infected individuals are at increased risk of cardiovascular disease.
Cardiovascular complications may be related to opportunistic infections, structural defects, or drug toxicity. HIV­associated cardiovascular conditions include ischemic heart disease, cardiomyopathy, infective endocarditis, pericardial effusion, congestive heart failure, or dysrhythmias. Cardiotoxicity may result from illicit substances, such as cocaine and methamphetamine, or therapeutic agents, such as pentamidine and zidovudine.
RENAL COMPLICATIONS
Monitor renal function during care for those with HIV infection, because renal insufficiency secondary to HIV­associated nephropathy, HIV immune
,53 complex disease, prerenal azotemia, drug nephrotoxicity, and arterionephrosclerosis are possible. Risk factors for HIV­associated nephropathy
 include African descent, low CD4 count, and high viral load. Nephrotoxicity may rise from ART, including agents such as atazanavir, tenofovir, acyclovir, foscarnet, indinavir (associated with nephrolithiasis), trimethoprim, and other agents. In the ED, check serum creatinine, estimated
 glomerular filtration rate, and urinary sediment. Many medications, including antiretroviral agents, have renal metabolism and require dosage adjustment for patients with renal insufficiency.
GI COMPLICATIONS
GI disorders compose some of the most common complaints in patients with HIV. Frequent presenting symptoms include odynophagia, abdominal pain, and diarrhea. ED evaluation seeks to identify the severity of symptoms and perform appropriate initial diagnostic studies. Therapy starts with volume and electrolyte repletion, with antimicrobial therapy when appropriate. Disposition is based on degree of immunosuppression, the duration of symptoms, the clinical appearance of the patient, and the response to ED therapy.
ORAL AND ESOPHAGEAL COMPLICATIONS
Oral Candidiasis/Thrush
Oral lesions are common in HIV­infected patients, frequently contributing to malnutrition. The appearance of oral lesions in HIV patients serves as a
 potential clinical marker for degree of immunodeficiency, with increased rates of thrush occurring with CD4 counts of <500 cells/mm . Oral candidiasis
(“thrush”; Figure 155­2) affects >80% of AIDS patients. The tongue and buccal mucosa are commonly involved, and the plaques are easily scraped from the erythematous base. Differentiation from hairy leukoplakia (adherent, white, thickened lesion[s] on the lateral tongue border) is challenging, but microscopic examination of a potassium hydroxide smear can confirm the diagnosis. Oral fluconazole, 100 mg once daily for  to  days, is firstline treatment; clotrimazole and nystatin are second­line treatments.
FIGURE 155­2. Oral candidiasis (thrush). Extensive thrush is seen on the hard and soft palate of this immunocompromised patient. [Photograph contributed by
Lawrence B. Stack. Reproduced with permission from Knoop KJ, Stack LB, Storrow AB, Thurman RJ: The Atlas of Emergency Medicine, 3rd ed, © 2009,
McGraw­Hill, Inc., New York.]
Other Oral Lesions
Other causes of painful oral and perioral lesions include hairy leukoplakia, which is associated with the Epstein­Barr virus, leads to epithelial thickening on the lateral borders of the tongue, and is adherent. Herpes simplex virus infection usually has painful oral and perioral vesicular lesions, with diagnosis confirmed by identification of multinucleated giant cells in scrapings or by culture. Both herpes simplex virus infection and hairy leukoplakia are responsive to oral acyclovir. Oral Kaposi’s sarcoma appears as a nontender, well­circumscribed, slightly raised violaceous lesion.
Diagnosis requires biopsy, with topical treatments being palliative and started outside the ED.
Esophageal involvement may occur with Candida, herpes simplex virus, and cytomegalovirus infection. Complaints of odynophagia, dysphagia, or
 chest pain may be indicative of esophagitis and be debilitating. In those with CD4+ T­cell counts of <200 cells/mm , Candida is responsible for the majority of bouts. Treatment for esophagitis is presumptive in the ED with oral fluconazole (Table 155­2). IV amphotericin B is a second­line therapy and used when oral treatment fails. Endoscopy, histologic staining and culture of lesions, and biopsy should be done for patients who fail to respond to therapy or have atypical presentations. Cytomegalovirus and herpes simplex virus infections discovered by endoscopy are treated with ganciclovir and acyclovir, respectively.
DIARRHEA
Diarrhea is the most frequent GI complaint of patients with HIV. Infectious causes include bacteria (Shigella, Salmonella, enteroadherent Escherichia coli, Entamoeba histolytica, Campylobacter, M. avium­intracellulare complex, Clostridium difficile, and others), parasites (Giardia lamblia,
Cryptosporidium, Cystoisospora belli [previously Isospora belli], and others), viruses (cytomegalovirus, herpes simplex virus, HIV, and others), and
 fungi (H. capsulatum, C. neoformans, and others). In those with CD4 <200 cells/mm , consider Cryptosporidium and microsporidia; if CD4 is <50
 cells/mm , patients are at risk for cytomegalovirus and MAC. Sexual transmission of shigellosis and lymphogranuloma venereum is increasing and may contribute to etiology of diarrhea in men who have sex with men. In many cases, a pathogen is never identified.
In the ED, exclude dietary causes and medication effects first; then, obtain stool culture for enteric bacteria, a specimen for C. difficile toxin (in the setting of antibiotic use), and multiple stool specimens for ova and parasite examination (including acid­fast bacilli and trichrome stain). Bacterial infections generally follow a more acute and fulminant course, whereas parasitic infections are frequently indolent. If suspecting bacterial infection in
 a patient with CD4 count <200 cells/mm and clinically severe diarrhea (six or more episodes or bloody stools and/or fevers/chills), start empiric treatment with ciprofloxacin by mouth.
Cryptosporidium and Cystoisospora infections are common parasitic causes associated with profuse watery diarrhea; both are detected by modified acid­fast staining of a stool specimen. Cystoisospora infection is usually responsive to trimethoprim­sulfamethoxazole, but relapse is common.
Cryptosporidiosis is difficult to treat; ART is the mainstay of treatment, coupled with supportive care, including rehydration and electrolyte repletion.
The efficacy of paromomycin and nitazoxanide and other agents is unclear.

In patients with CD4 <50 cells/mm , the most common diarrheal pathogens are cytomegalovirus and M. avium­intracellulare complex, each requiring biopsy for diagnosis. Use prolonged antimicrobial therapy; relapse is frequent for both infections.
About 15% of patients with late­stage AIDS experience severe, high­volume watery diarrhea absent a clear pathogen, with the presumed diagnosis of
AIDS­related enteropathy. Octreotide may aid some of these patients. Crofelemer may reduce symptoms of noninfectious diarrhea in patients with

HIV. Diarrhea can also be a side effect of protease inhibitors; non­Hodgkin’s lymphoma and Kaposi’s sarcoma can also present with diarrhea if GI tract involvement is present. Pancreatic insufficiency may represent a treatable cause of chronic diarrhea.
ED management consists of repletion of fluid and electrolytes and treatment of targeted pathogens, as noted earlier; admit those with suspected bacteremia, AIDS, significant dehydration, malnutrition, or electrolyte imbalance. Patients who appear nontoxic and can tolerate liquids are eligible for outpatient care and follow­up to obtain test results. In the absence of bloody diarrhea or systemic complaints, treat patients symptomatically with antimotility agents (e.g., loperamide, diphenoxylate).
OTHER GI COMPLICATIONS
Coinfection with hepatitis B virus and hepatitis C virus is common, especially among injection drug users. Opportunistic infection with cytomegalovirus, Cryptosporidium, M. avium­intracellulare complex, and M. tuberculosis also may cause hepatitis. Cryptosporidium may also cause cholangiopathy. Drug­related hepatitis and hypersensitivity are other possibilities.
Anorectal disease is common in AIDS patients. Proctitis presents with painful defecation, rectal discharge, or tenesmus. Common causative organisms include Neisseria gonorrhoeae, Chlamydia trachomatis, Treponema pallidum, lymphogranuloma venereum, and herpes simplex virus. Proctocolitis includes the same symptoms plus diarrhea, and multiple bacterial organisms may be responsible (most commonly Shigella, Campylobacter, and E.
histolytica). Evaluation includes anoscopy with microscopic examination, Gram staining, and culture of pus and/or stool.
CUTANEOUS COMPLICATIONS

Noninfectious cutaneous disorders are common in HIV and can include xerosis, eczema, seborrheic dermatitis, psoriasis, and drug reactions.
Pruritus is common, and ED evaluation includes history, physical examination, removal of offending agents, and treatment of the underlying condition.

Symptomatic treatment with emollients and antipruritic agents can be effective.
CUTANEOUS INFECTIONS
Skin and soft tissue infections occur in the HIV­infected population, and often are signs of disseminated disease or bacteremia. Methicillin­resistant S.
aureus colonization and infection are prevalent and are associated with low CD4+ cell counts, men who have sex with men, anal intercourse, previous
,60 methicillin­resistant S. aureus infections, and illicit drug use. Human papillomavirus infections manifesting as condyloma acuminata or warts are common; treatment is cosmetic or symptomatic and includes cryotherapy, topical therapy, or laser therapy. Intertriginous infections with Candida or
Trichophyton are frequent in HIV­positive patients. Treatment is with topical clotrimazole, miconazole, or ketoconazole. Molluscum contagiosum
 presents as CD4 counts decrease to <100 cells/mm with pearly flesh­colored papules with central umbilication; the goal of localized treatment is primarily cosmetic. Scabies occurs in about 20% of HIV­infected patients, with scaly, persistent pruritic eruptions. Treat with permethrin 5% cream or oral ivermectin. Atypical presentations, such as papular or crusted scabies, may also occur. Cutaneous cytomegalovirus, tuberculosis, syphilis, coccidioidomycosis, histoplasmosis, and cryptococcosis are other considerations and may mandate systemic treatment.
HERPES SIMPLEX VIRUS
Herpes simplex virus infections are common and either localized or systemic. In patients with immunosuppression, infection may become progressive and chronic (see Chapter 153, “Sexually Transmitted Infections”). IV acyclovir is the therapy for extensive disease (Table 155­2).
VARICELLA­ZOSTER VIRUS INFECTION
Reactivation of varicella­zoster virus is more common in patients with HIV infection and AIDS than in the general population. The clinical course is prolonged, and complications are more frequent. In HIV­positive patients, oral acyclovir, famciclovir, and valacyclovir are options for treatment for those with limited involvement in absence of significant immunosuppression (Table 155­2). Patients with disseminated disease or ophthalmic involvement should receive IV acyclovir.
KAPOSI’S SARCOMA
Kaposi’s sarcoma appears more often in men who have sex with men than in other risk groups. Clinically, it consists of firm, painless, raised, brownblack or purple patches, plaques, or nodules (see Figure 251­30).
Common sites are the face, chest, genitals, and oral cavity, but widespread dissemination involving internal organs may occur. Biopsy confirms the
 diagnosis. Radiotherapy treats localized disease; widespread disease may be responsive to chemotherapy in combination with ART.
BACILLARY ANGIOMATOSIS

In patients with CD4 count <100 cells/mm , Bartonella may cause vascular proliferations of the skin, although any organ may be involved. Firm, red or violaceous nodules are painful and may resemble pyogenic granulomas or Kaposi’s sarcoma. Treatment typically consists of doxycycline or erythromycin, and patients should be referred for biopsy.
SEXUALLY TRANSMITTED INFECTIONS
62­64
Sexually transmitted infections, HIV, and viral hepatitis share common routes of transmission and may coexist. Genital ulcers caused by diseases such as herpes, chancroid, and syphilis are portals of entry for HIV. There is more frequent HIV seropositivity in patients with genital ulcers, gonorrhea,
 and chlamydial infections. The prevalence of sexually transmitted infections, including syphilis, is increasing and warrants enhanced surveillance.
See Chapter 153 for details.
IMMUNIZATION OF HIV­INFECTED PATIENTS

HIV­infected persons should not receive live­virus or live­bacteria vaccines. The exception to this rule is the measles­mumps­rubella vaccine.

Killed or inactivated vaccines pose no danger to immunosuppressed patients. Because symptomatic HIV­infected persons have a suboptimal response to vaccines, all single­dose vaccines are best given early in the course of HIV infection. Table 155­4 summarizes recommendations for common immunizations.
TABLE 155­4
Immunization Recommendations for Adult Human Immunodeficiency Virus–Infected Patients
Recommended Vaccines Recommendation
Tetanus, diphtheria, and pertussis (Tdap) One booster in adulthood
Tetanus­diphtheria toxoid (Td) Every  y
Pneumococcal One dose
Influenza (inactivated) One dose annually
Hepatitis B Three doses over a 2­y period
Withhold in Severe Immunodeficiency
Measles­mumps­rubella Avoid in patients with CD4+ T­cell count <200 cells/mm3
Varicella Avoid in patients with CD4+ T­cell count <200 cells/mm3
Contraindicated Vaccines
Oral polio vaccine
Smallpox vaccine
Live attenuated influenza vaccine
ANTIRETROVIRAL THERAPY
After the introduction of ART, sharp declines in AIDS incidence and mortality occurred, transforming HIV therapeutics into long­term management of a chronic infection. General therapeutic goals include: (1) prolonging and improving the quality of life; (2) reducing viral load as much as possible to halt disease progression and prevent or reduce the development of resistant variants; (3) promoting immune reconstitution, both quantitative (CD4+ T­cell count) and qualitative (pathogen­specific immune response); and (4) reducing side effects and maintaining therapeutic options. A complete drug list and up­to­date guide for the general classes of antiretroviral drugs, principles for initiating therapy, and common adverse reactions are on the Centers for Disease Control and Prevention website (https://www.cdc.gov/hiv/guidelines/index.html).
The five main classes of antiretroviral drugs are (1) nucleoside reverse transcriptase inhibitors, which interfere with the action of reverse transcriptase
(e.g., zidovudine); (2) nonnucleoside reverse transcriptase inhibitors, which bind to reverse transcriptase and block RNA­ and DNA­dependent DNA polymerase activity (e.g., efavirenz); (3) protease inhibitors, which block HIV protease, a key enzyme in establishing HIV infectivity (e.g., indinavir); (4) entry inhibitors, which prevent HIV entry into cells by targeting specific viral surface proteins or their corresponding receptors (e.g., enfuvirtide); and
(5) integrase inhibitors, which work by blocking integrase, a protein that HIV needs to insert its viral genetic material into the genetic material of an infected cell (e.g., raltegravir).
Preferred initial treatment regimens include at least three drugs—two nucleoside reverse transcriptase inhibitors plus one of the following classes: nonnucleoside reverse transcriptase inhibitor, protease inhibitor (boosted with ritonavir), or integrase strand transfer inhibitor. The newest guidelines recommend that all HIV­infected patients, regardless of CD4+ cell count, start ART in order to reduce morbidity and mortality associated
 with HIV infection and to prevent HIV transmission. Education and counseling are considered an integral part of ART initiation regarding risk and
 benefits as well as developing strategies to optimize adherence. For these reasons, decisions regarding initiation of and changes in ART should be made in consultation with the primary care physician and an infectious disease consultant.
DRUG INTERACTIONS AND ADVERSE EFFECTS IN HIV­INFECTED PATIENTS
Current ART programs include a standard three­drug regimen that may cause a range of changes in metabolic or physiologic functions and be toxic.
Table 155­5 shows the currently available antiretroviral medications, their major adverse effects, and their interacting drug effects. Concomitant antibiotic prophylaxis can compound adverse effects from antiretrovirals.
TABLE 155­5
Antiretroviral Medications, Major Adverse Effects, and Interacting Drug Effects70
Antiretroviral Interacting
Adverse Effects Effects of Interaction
Medications* Drugs
Nucleoside reverse transcriptase inhibitors
Abacavir Stevens­Johnson syndrome, hypersensitivity reaction
Didanosine Peripheral neuropathy, lactic acidosis, pancreatitis, retinal changes, insulin resistance/diabetes mellitus
Emtricitabine Skin hyperpigmentation/discoloration, acute exacerbation of hepatitis may occur in HBV/HCV patients who discontinue drug
Lamivudine Acute exacerbation of hepatitis may occur in HBV/HCV patients who discontinue drug
Stavudine Pancreatitis, lactic acidosis/hepatic steatosis (rare), peripheral neuropathy, ascending muscle weakness (rare), dyslipidemia, lipoatrophy
Tenofovir Pancreatitis, headache, renal insufficiency, diarrhea, nausea, vomiting, osteomalacia, acute exacerbation of hepatitis may occur in HBV/HCV patients who discontinue drug
Zidovudine Bone marrow suppression, nausea, vomiting, headache, lactic acidosis/hepatic steatosis (rare), hyperlipidemia, insulin resistance/diabetes mellitus, lipoatrophy, myopathy
Nonnucleoside Anticonvulsants, Anticonvulsants: decreased concentration of antiretrovirals (some reverse rifampin contraindicated), rifampin: decreased NNRTI (contraindicated with some transcriptase NNRTIs) inhibitors
(NNRTIs)
Delavirdine Transaminitis, rash, headache
Efavirenz Depression, psychosis, suicidal Midazolam Increased concentration of midazolam (oral administration ideation, rash, serum contraindicated) transaminase elevation, hyperlipidemia, QT prolongation
Etravirine Rash (including Stevens­Johnson syndrome, hypersensitivity reaction), nausea
Nevirapine Rash (including Stevens­Johnson syndrome), hepatic failure
Rilpivirine Rash, depression, insomnia, Proton pump Decreased concentration of antiretroviral (contraindicated) headache, hepatoxicity, QT inhibitors prolongation
Protease Hyperlipidemia, hyperglycemia, Antiarrhythmics, Antiarrhythmics: increased levels of both drugs (some contraindicated); inhibitors fat maldistribution anticonvulsants, anticonvulsants: decreased concentration of antiretroviral and varying anticoagulants concentration of the interacting drug (some contraindicated); and antiplatelet anticoagulants: varying impact on anticoagulant concentration agents, (monitoring needed with warfarin, coadministration not recommended midazolam, with others); midazolam: increased midazolam (do not administer orally); rifampin, HMG­ rifampin: decreased concentration of antiretroviral (contraindicated);
CoA reductase HMG­CoA reductase inhibitors: increased risk of rhabdomyolysis inhibitors
Amprenavir Toxicity from propylene glycol diluent
Atazanavir Indirect hyperbilirubinemia, Antacids, H ­ Decreased absorption of atazanavir; space use of antacids/H ­receptor
  prolonged PR interval, receptor antagonists; proton pump inhibitors contraindicated in some situations cholelithiasis, nephrolithiasis, antagonists, renal insufficiency, serum proton pump transaminase elevations, rash inhibitors
Diltiazem Increased concentration of diltiazem (decrease diltiazem dose by half)
Darunavir Headache, nausea, diarrhea, rash
(including Stevens­Johnson syndrome, toxic epidermal necrolysis, etc.), hepatotoxicity, serum transaminase elevation, increase in serum creatinine
Fosamprenavir Rash, diarrhea, nausea, vomiting, headache, serum transaminase elevation, possible increased bleeding episodes in patients with hemophilia, nephrolithiasis
Indinavir Nephrolithiasis, nausea, hepatitis, nephrotoxicity, indirect hyperbilirubinemia, headache, blurred vision, dizziness, rash, metallic taste, thrombocytopenia, alopecia, hemolytic anemia, possible increased bleeding episodes in patients with hemophilia
Nelfinavir Secretory diarrhea, possible increased bleeding episodes in patients with hemophilia, serum transaminase elevation
Ritonavir Nausea, vomiting, diarrhea, paresthesia (circumoral and extremities), hepatitis, taste perversion, possible increased bleeding episodes in patients with hemophilia
Ritonavir/lopinavir Nausea, vomiting, pancreatitis, Digoxin Increased digoxin concentration (monitor levels) serum transaminase elevation, insulin resistance/diabetes mellitus, possible increased bleeding episodes in patients with hemophilia, PR interval prolongation
Saquinavir Nausea, diarrhea, headache, serum transaminase elevation, possible increased bleeding episodes in patients with hemophilia, PR interval prolongation, QT interval prolongation, torsades de pointes
Tipranavir Intracerebral hemorrhage, Proton pump Decreased absorption of proton pump inhibitors; coadministration not hepatotoxicity, rash, possible inhibitors recommended increased bleeding episodes in patients with hemophilia
Entry and fusion inhibitors
Enfuvirtide Bacterial pneumonia, injection site reaction, hypersensitivity reaction
CCR­5 antagonist
Maraviroc Abdominal pain, postural hypotension, cough, dizziness, pyrexia, rash, upper respiratory tract infection, hepatotoxicity
Integrase Anticonvulsants Decreased antiretroviral concentrations (some contraindicated) inhibitors
Dolutegravir Hypersensitivity reaction, insomnia, headache, depression and suicidal ideation (rare)
Raltegravir Increased creatine phosphokinase, rhabdomyolysis, muscle weakness, nausea, diarrhea, headache, rash
(including Stevens­Johnson syndrome, hypersensitivity reaction, and toxic epidermal necrolysis), pyrexia, insomnia, depression, and suicidal ideation
(rare)
Abbreviations: HBV = hepatitis B virus; HCV = hepatitis C virus; HMG­CoA = 3­hydroxy­3­methylglutaryl­coenzyme A.
*Some antiretroviral agents have interactions with buprenorphine and methadone, requiring modifications of the latter two agents.
Source:http://www.aidsinfo.nih.gov/ContentFiles/AdultandAdolescentGL.pdf. (Panel on Antiretroviral Guidelines for Adults and Adolescents: Guidelines for the use of antiretroviral agents in adults and adolescents living with HIV. Department of Health and Human Services.) Accessed October , 2018. Drug interactions are pharmacokinetic (changes in the level of one or more drugs) or pharmacodynamic (changes in effect, therapeutic response, or
,72 side effect of one or more drugs). Consultation with a hospital pharmacologist and an infectious disease specialist helps manage those with a suspected drug reaction.


