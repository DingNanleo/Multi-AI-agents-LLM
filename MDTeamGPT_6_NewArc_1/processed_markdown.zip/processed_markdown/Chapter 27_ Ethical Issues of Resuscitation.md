University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 27: Ethical Issues of Resuscitation
Catherine A. Marco
GENERAL PRINCIPLES OF MEDICAL ETHICS

The study of ethics is an effort to understand and examine the moral life. The Hippocratic Oath is revered as one of the oldest codes of medical ethics.

More recently, the American Medical Association Code of Ethics (earliest version in 1847) and the American College of Emergency Physicians Code of
,4
Ethics (2016 and 2017) have provided guidance to emergency physicians in the application of ethical principles to clinical practice. Principles of bioethics include beneficence (doing good); nonmaleficence (primum non nocere, or “do no harm”); respect for patient autonomy, ity, and honesty; distributive justice; and respect for the law. Ethical dilemmas arise when there is a potential conflict between two principles, values, or individuals. Physicians resolve these dilemmas by gathering additional information; assessing patient capacity; conducting meetings with other healthcare professionals, patients, and families; and applying an informed judgment in individual situations. In some circumstances, physicians may seek the involvement of the institutional ethics committee or the judicial system.
CARDIAC RESUSCITATION AND OUTCOMES

There are approximately 300,000 sudden deaths in the United States annually. The outcome of resuscitative efforts for victims of cardiac arrest is uniformly poor but varies depending on a variety of factors, including time elapsed since arrest (down time), presenting rhythm, bystander CPR, and response to prehospital advanced cardiac life support protocols. Reported estimates of survival of out­of­hospital arrest vary significantly. Recent data suggest improved survival after cardiac arrest. Overall survival after out­of­hospital cardiac arrest was .6% in 2005 to 2006 and improved to .3% in

2012. Several variables are associated with improved outcome after out­of­hospital cardiac arrest, including witnessed arrest, shockable rhythm, lower age,
7­19 lack of significant comorbidities, bystander CPR, early advanced cardiac life support early defibrillation, and targeted temperature management.
FUTILITY AND NONBENEFICIAL INTERVENTIONS
An advance directive is any proactive document stating the patient’s wishes in various situations should the patient be unable to do so, yet most
20­25
Americans do not have an advance directive, complicating the application of resuscitative interventions. See Chapter 301, “Death Notification and
Advance Directives,” for further information; see also Chapter 303, “Legal Issues in Emergency Medicine.”
The term futility is subject to interpretation. Healthcare professionals may determine futile interventions to be those that carry an absolute impossibility of successful outcome, a low likelihood of return to spontaneous circulation, a low likelihood of survival to discharge from the hospital, or a low likelihood of restoration of meaningful quality of life. Futility can be defined as “any effort to achieve a result that is possible, but that
 reasoning, or experience suggests is highly improbable and that cannot be systematically produced.” There is no consensus among physicians about the meaning of the term. It is probably more accurate to use terminology such as nonbeneficial, ineffectual, or low likelihood of success when discussing resuscitation with patients or families.
The American Medical Association Council on Ethical and Judicial Affairs stated that CPR may be withheld, even if requested by the patient, “when
 efforts to resuscitate a patient are judged by the treating physician to be futile.” Dilemmas regarding nonbeneficial interventions often arise due to inadequate or ineffective communication between the physician, patient, and family. This is of concern in emergency medicine, in which previous relationships with patients and family rarely exist and time is often inadequate to establish effective relationships. Thus, initial efforts should be directed to improve communication, education, and joint decision making.
EDmowerngleonacdye pdh 2y0s2ic5ia­7n­s1’ j4u:d3g7m Pe n Ytso ushr oIPu ldis b1e3 u6n.1b4ia2s.1e5d9, b.1a2s7ed on available scientific evidence, mindful of societal and professional standards, and
Chapter 27: Ethical Issues of Resuscitation, Catherine A. Marco sensitive to differences of opinion regarding the value of medical intervention in various situations.
. Terms of Use * Privacy Policy * Notice * Accessibility
Ultimately, the decision regarding CPR and its likelihood of benefit to the patient and decisions to provide, limit, or withhold resuscitative efforts are to be made by the emergency physician in the context of well­accepted research results, patient and family wishes, and professional judgment. Individual bias regarding quality of life or other related issues should be avoided. There are many situations in which dying can be accepted as a natural process, even in an emergency setting.
TERMINATION OF RESUSCITATIVE EFFORTS
Several organizations have proposed criteria for withholding resuscitative efforts for patients with a very low likelihood of successful resuscitation.
28­32
Several validated decision rules incorporate related factors predictive of dismal outcome. Prehospital resuscitative efforts may be terminated
 under circumstances delineated by the Basic Life Support Termination of Resuscitation Rule. This rule is recognized by the American Heart

Association ; the National Association of EMS Physicians has adopted these criteria, which are listed in Table 27­1. TABLE 27­1
National Association of EMS Physicians Standards for Termination of Resuscitation in Nontraumatic Cardiopulmonary Arrest
Termination of resuscitation may be considered when, at the time of decision of termination, all of the following conditions have been met:
The arrest was not witnessed by an EMS provider.
There is no shockable rhythm identified by an automated external defibrillator (AED) or other electronic monitor.
There is no return of spontaneous circulation prior to EMS transport.
In accordance, American College of Emergency Physicians policy states, “Resuscitative efforts may be appropriately withheld, withdrawn, or limited in circumstances such as the lack of immediately available resuscitation resources, or when there is no realistic likelihood of benefit to the patient based
 on existing scientific evidence and reasonable medical judgment.”
FAMILY PRESENCE DURING RESUSCITATION
Family presence during resuscitation may improve understanding and relieve family member guilt or disappointment and may be a helpful part of the
37­44 grieving process. Physicians should be sensitive to the possibility that this option may be difficult for certain family members or staff. If family members are invited to be present, provide a liaison to assist with communication and education about procedures and other medical issues.
SPECIAL SITUATIONS
RESUSCITATION AFTER SUICIDE ATTEMPTS
Following a suicide attempt, assessment of mental capacity is difficult or impossible. Because resuscitative efforts may be lifesaving, efforts should be undertaken in this setting. Potential issues regarding capacity, patient autonomy, and shared decision making can be addressed following successful
 resuscitative efforts.
PROCEDURES ON RECENTLY DECEASED PATIENTS
The practices of teaching and performing procedures on recently deceased patients are controversial. The most important benefit of these practices is
 the opportunity for hands­on practice for students, house staff, and even experienced physicians. However, some consider performing procedures
 without informed consent to be disrespectful, deceptive, or unethical. Obtaining consent from families or surrogates is recommended before such
,49 practice.
RESUSCITATION RESEARCH
Research on resuscitation techniques and pharmaceuticals has been problematic due to the frequent inability to obtain informed consent and the constraints of the decision­making process. Ordinarily, the informed consent procedure for human subject research is designed to ensure protection and autonomy of the subject. However, this process is time­consuming and requires decisional capacity in the subject. Because of these difficulties, the
U.S. Food and Drug Administration issued guidelines under which resuscitation research may be performed, with a waiver of informed consent under
 certain conditions. When designing such research protocols, relevant factors include the patient’s wishes (if known), expected safety of the study protocol, expected benefit of the therapeutic intervention, overall predicted benefit to society by improved knowledge regarding resuscitation, related animal data, feasibility of surrogate consent, local institutional review board opinion, and local general public opinion, if available. Waiver of consent is available through application with the Food and Drug Administration with local institutional review board approval.
COMMUNICATION AND COUNSELING FOR SURVIVORS
Counseling should be available for families and friends of those patients who have died in the ED. See Chapter 301, “Death Notification and Advance
Directives,” for detailed discussion on communication strategies. Table 27­2 summarizes the American College of Emergency Physicians Policy on

Ethical Issues at the End of Life. Table 27­3 provides a summary of practical advice for resuscitation scenarios. See also Chapter 300, “Palliative
Care,” for guidance in situations where de­escalation of care is appropriate.
TABLE 27­2
Ethical Issues at the End of Life: The American College of Emergency Physicians Policy
The American College of Emergency Physicians believes that:
Emergency physicians play an important role in providing care at the end of life (EOL).
Helping patients and their families achieve greater control over the dying process will improve EOL care.
Advance care planning can help patients formulate and express individual wishes for EOL care and communicate those wishes to their healthcare providers by means of advance directives (including state­approved advance directives, Do Not Attempt Resuscitation orders, living wills, and durable powers of attorney for health care).
To enhance EOL care in the emergency department, the American College of Emergency Physicians believes that emergency physicians should:
Respect the dying patient’s needs for care, comfort, and compassion.
Communicate promptly and appropriately with patients and their families about EOL care choices, avoiding medical jargon.
Elicit the patient’s goals for care before initiating treatment, recognizing that EOL care includes a broad range of therapeutic and palliative options.
Respect the wishes of dying patients including those expressed in advance directives. Assist surrogates to make EOL care choices for patients who lack decision­making capacity, based on the patient’s own preferences, values, and goals.
Encourage the presence of family and friends at the patient’s bedside near the end of life, if desired by the patient.
Protect the privacy of patients and families near the end of life.
Promote liaisons with individuals and organizations to help patients and families honor EOL cultural and religious traditions.
Develop skill at communicating sensitive information, including poor prognoses and the death of a loved one.
Comply with institutional policies regarding recovery of organs for transplantation.
Obtain informed consent from surrogates for postmortem procedures.
TABLE 27­3
Practical Advice for Resuscitation Scenarios
Identify patient wishes (advance directive, prior communications).
Communicate with family and loved ones during and following resuscitative efforts.
Allow family to be present during resuscitative efforts, if appropriate.
Assess prognosis, based on scientific evidence.
Enroll patient in research trials, with surrogate consent, or using U.S. Food and Drug Administration waiver of consent rule, as appropriate.
Provide spiritual, psychosocial, and educational support to family and loved ones throughout and after termination of resuscitative efforts.


