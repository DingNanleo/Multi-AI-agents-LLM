## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 130: Syncope, Dysrhythmias, and ECG Interpretation in Children
Andrew Dixon
SYNCOPE
INTRODUCTION
Syncope, or fainting, is the abrupt loss of consciousness and postural tone resulting from transient global cerebral hypoperfusion, followed by
 complete spontaneous recovery. In children, this process is usually benign, but it can be a symptom of serious cardiac, neurologic, or metabolic pathology. Assessing syncope in children is complicated by the variability of symptoms and lack of a gold standard for diagnosis. The primary goal of the emergency physician is to differentiate children with benign syncope from those with serious disease. Noncardiovascular causes of syncope are listed in Table 130­1. Although pacemaker use is not common in childhood, any child with a pacemaker who develops syncope or presyncope should be presumed to have a pacemaker malfunction.
TABLE 130­1
Events Easily Mistaken for Cardiovascular Syncope
Condition Distinguishing Characteristics
Basilar migraine Headache, rarely loss of consciousness, other neurologic symptoms
Seizure Loss of consciousness simultaneous with motor event, prolonged postictal phase
Vertigo Rotation or spinning sensation, no loss of consciousness
Hyperventilation Inciting event, paresthesias or carpopedal spasm, tachypnea
Hysteria No loss of consciousness, indifference to event
Hypoglycemia Confusion progressing to loss of consciousness, requires glucose administration to terminate
EPIDEMIOLOGY
,3 
Syncope is a presenting symptom in 1% to 3% of pediatric emergency visits, with 2% of patients admitted to hospital, and is more common in
 adolescents than in younger children. Between 15% and 25% of adolescents experience at least one episode of syncope. Only 10% to 15% of patients
 evaluated in the pediatric ED for syncope are ultimately diagnosed with a serious illness. Approximately 80% of pediatric fainting is neurocardiogenic
(also known as vasovagal) syncope. Neurologic disorders, mostly seizures, account for about 10% of episodes, and 2% to 3% are due to cardiac
,7 pathology.
PATHOPHYSIOLOGY
Neurocardiogenic syncope, otherwise known as neurally mediated or vasovagal syncope, is a mix of vasodepressor syncope due to vasodilation and cardioinhibitory syncope due to vagal stimulation. Neurocardiogenic syncope can be triggered by a variety of conditions in which a reduction in
 venous return enhances vagal tone causing hypotension, bradycardia, and reduced cerebral perfusion. Recovery of consciousness occurs over  to 
Chapter 130: Syncope, Dysrhythmias, and ECG Interpretation in Children, Andrew Dixon minutes, but symptoms of nausea and fatigue can last for several hours.
. Terms of Use * Privacy Policy * Notice * Accessibility
Cardiac syncope occurs when there is an interruption of cardiac output due to an intrinsic cardiac abnormality. These causes are divided into tachydysrhythmia, bradydysrhythmia, outflow obstruction, and myocardial dysfunction.
Any event that causes sufficient cerebral hypoperfusion can lead to sudden death. The most common causes are seizures, cardiac diseases, and metabolic diseases. Little is known about the most common dysrhythmias that cause sudden death in children, because such cardiopulmonary arrests are unwitnessed. In children, bradycardic or asystolic arrests are thought to be most common, especially in infants <1 year old, but ventricular
 fibrillation is also seen in older children, although at much lower rates than in adults.
CLINICAL FEATURES
Syncope is characterized by the sudden onset of falling with a brief episode of loss of consciousness. Other associated symptoms or signs are usually
 related to the cause for the syncopal event. Two thirds of children experience a prodrome of lightheadedness or dizziness before the event, and vertigo is uncommon. Involuntary motor movements related to cerebral hypoxia occur with all types of syncopal events, but are more common with seizures. A careful history can usually differentiate tonic­clonic movements associated with seizures from the myoclonus of cerebral hypoxia, due to their onset after loss of consciousness, less rhythmic nature, and shorter duration.
RISK FACTORS FOR A SERIOUS CAUSE OF SYNCOPE
Risk factors for syncope are outlined in Table 130­2. Events that may mimic syncope in children are listed in Table 130­1. TABLE 130­2
Risk Factors for a Serious Cause of Syncope* Mid­exertional event
Absence of premonitory symptoms or physical precipitating factors
Syncope triggered by loud noise or when swimming (may be due to long QT)
Age <6 y
History of cardiac disease
Family history of sudden death under age  y, long QT syndrome, or sensorineural hearing loss
Recurrent episodes
Recumbent episode (consider seizure)
Prolonged loss of consciousness (if >5 min, consider seizure or somatization)
Associated chest pain or palpitations
Use of medications that can alter cardiac conduction including QT prolongation
*Bolded risk factors represent those factors at highest risk for a cardiac cause.
A syncopal event during physical exertion increases the suspicion of structural heart disease, specifically cardiac outflow obstruction. Conditions such as aortic stenosis, hypertrophic obstructive cardiomyopathy, and other vascular or valvular anomalies may cause cardiac outflow obstruction.
Prior to age  years, syncope is much more likely to be associated with seizures, breath­holding spells, and cardiac arrhythmia. Preexisting cardiac disease heightens suspicion of ventricular dysrhythmias as a cause of syncope. Bradyarrhythmias secondary to ischemia, overmedication, or pacemaker malfunction also cause syncope. A history of heart murmur, or discovery of one on exam, may indicate undiagnosed congenital heart disease.
Several familial inherited syndromes are associated with syncope and sudden death. Romano­Ward syndrome is an autosomal dominant syndrome associated with prolonged QT interval and ventricular dysrhythmias; Jervell and Lange­Nielsen syndrome is an autosomal recessive syndrome associated with prolonged QT interval, deafness, and ventricular dysrhythmias. The presence of a family history of dysrhythmias should prompt a more thorough investigation.
When more than one episode of syncope has occurred, consider the presence of ongoing cardiac disease producing a low­flow state, although neurocardiogenic syncope is also often recurrent. Consider illnesses associated with valvular insufficiency, congestive heart failure and diastolic dysfunction, or recurrent supraventricular tachycardia or atrial fibrillation causing rate­dependent hypoperfusion, even in children. Recurrence also raises the probability of a neurologic cause (i.e., seizures).
Episodes that occur when the patient is supine can suggest ventricular dysrhythmias or seizures, which are unrelated to activity.
An extended period of loss of consciousness is worrisome and can be a sign of hypotension resulting from cardiac disease that causes prolonged cerebral hypoperfusion. Alternatively, prolonged loss of consciousness, lasting up to hours, is often seen with pseudosyncope or pseudoseizures in
 adolescent females. Syncope in association with chest pain may result from acute myocardial infarction or aortic dissection, whereas preceding
 palpitations may raise suspicion for possible dysrhythmia, although in adults, palpitations are a common symptom in vasovagal syncope.
Antidysrhythmic medications, blood pressure agents, tricyclic antidepressants, amphetamines, and cocaine are all agents that can precipitate electrical conduction disturbances. Many common medications can prolong QT interval and predispose to syncope (see Table 130­5 in “Long QT
Syndrome” section).

No clinical or historical features can reliably exclude all serious causes of syncope. Certain elements in the history increase the likelihood of a potentially serious cause (Table 130­2), and a careful history and physical examination are necessary. Many of the diseases that cause syncope also cause sudden death in children. A syncopal event can be the presenting symptom of these more serious illnesses. Up to 25% of children who die
 suddenly have a history of at least one prior syncopal event. Syncope is a very common event, however, and a syncopal event by itself is not
 associated with an increased risk of sudden death unless certain features are present (Table 130­2).
HISTORY
Obtain a history focused on hydration status, last meal, environmental conditions, activity preceding the syncopal event, and the use of drugs and medications. Note the position the child was in when syncope occurred, because recumbent positioning is less consistent with neurocardiogenic syncope. Syncope associated with change of position, warm environment, or prolonged standing is very likely to be neurocardiogenic. Be sure to include interviews with any family members, friends, or witnesses who were with the child just before the event. A history of syncope during exertion or exercise increases the likelihood of a serious cause. A prodrome of warmth, nausea, lightheadedness, and a visual gray­out or tunneling of vision is indicative of benign neurocardiogenic syncope. The sequence and timing of motor movements and postural positioning help to differentiate primary seizures from syncope. Loss of consciousness occurs with the onset of movements in seizures, but loss of consciousness precedes movements in most cases of true syncope. Inquire about past history such as previous syncopal events, cardiac disease, diabetes, seizures, medication or drug use, and psychiatric or psychological problems. Ask about a family history of structural cardiac disease, dysrhythmias, sudden death, migraines, or seizures. Take statements by the witnesses that the patient appeared dead and required CPR seriously and characterize the duration of pulselessness and the degree of intervention required. Whenever CPR has been performed, even if by an inexperienced layperson, consider the event resuscitation from sudden death and evaluate comprehensively, although the ultimate diagnosis may be benign.
PHYSICAL EXAMINATION
Complete cardiovascular, neurologic, and pulmonary examinations are crucial, but the findings are normal in the vast majority of children with syncope, regardless of the seriousness of the cause. Perform a neurologic examination including deep tendon reflex, gait, and coordination testing.
Examine the cardiovascular system including blood pressure, resting heart rate, oxygen saturation, and respiratory rate. Assess pulse quality in all extremities. Measure blood pressure and heart rate with positional changes (orthostatic vital signs), especially if syncope occurred during positional change. This may indicate an element of dehydration, although there is some evidence that a significant percentage of normal adolescents have
 abnormal postural vital signs. Auscultate the heart to identify any murmurs, abnormalities in rhythm, and variations or abnormalities in heart sounds. Any abnormal findings in the cardiovascular assessment require an in­depth cardiac evaluation.
LABORATORY EVALUATION

Obtain an ECG in all children with syncope. However, abnormalities on the ECG may not correlate with the syncopal event, and some patients
 with a dysrhythmic cause of syncope have normal ECGs. The overall yield of ECG is <1%, and ECG overreading often leads to further unnecessary
 investigations. Therefore, abnormal ECG results should be interpreted with caution and most often with the assistance of a pediatric cardiologist.
See the section “ECG Interpretation in Infants and Children” at the end of the chapter for detailed discussion.

A detailed history, physical exam, and ECG have a 96% sensitivity for detecting cardiac syncope. Selection of other laboratory tests should be guided by clinical suspicion (e.g., a hemoglobin measurement for a patient with possible anemia or a glucose measurement for a patient with diabetes).
Routine laboratory studies are not needed in a child with a clear episode of vasovagal syncope. For patients with an atypical presentation or worrisome associated symptoms, a serum chemistry panel, hematocrit, thyroid function tests, and chest radiograph may be performed in the ED if indicated by history. For example, hyperthyroidism predisposes children to supraventricular tachycardia, so thyroid function tests are appropriate when supraventricular tachycardia is considered. In adolescents, consider serum alcohol level and a urine drug screen to rule out illicit drug use (most commonly cocaine and amphetamines).
Obtain an echocardiogram for those with known cardiac disease, abnormal heart sounds, abnormal cardiac murmurs, evidence of cardiac chamber enlargement, or repolarization abnormalities on ECG, or other features that suggest myocardial dysfunction. If an echocardiogram cannot be obtained in the ED, then consider admission for inpatient evaluation. Echocardiography has very limited utility in patients without known heart disease and no high­risk historical factors.

Electroencephalogram has very low diagnostic yield in syncope and is not needed routinely. The clinical utility of other tests, such as stress tests, tilttable tests, electrophysiologic studies, and cardiac catheterization, usually is determined by the pediatric cardiologist and is beyond the scope of this chapter.
Children resuscitated from sudden death must undergo a complete evaluation unless a clear cause for the arrest is apparent. The diagnostic possibilities are extensive, so laboratory and radiographic studies should be directed by clinical and historical information. For all such patients, obtain a serum chemistry panel, cardiac enzymes, a CBC, serum alcohol level, urine drug screen, thyroid function tests, chest radiograph, and ECG.
Look for complications resulting from the arrest, such as hypothermia, acidosis, rhabdomyolysis, and cerebral edema or hypoxia. Inpatient evaluation can include an echocardiogram, cardiac catheterization, stress test, and electrophysiologic testing as directed by the pediatric cardiologist.
TREATMENT
,6
Most children experiencing syncope have recovered fully by the time they arrive at the ED. Continued altered level of consciousness should prompt an evaluation for continued neurologic, cardiovascular, or psychological derangements. Treatment should be tailored to current symptoms. Correct compromised oxygenation, ventilation, or circulation. Apply a cardiac monitor to document any transient dysrhythmias while gathering the history and physical findings. Manage ongoing cardiac dysrhythmias or seizures as appropriate (see Chapter 109, “Resuscitation of Children,” and Chapter 138,
“Seizures in Infants and Children”). Most patients, however, have no treatable dysrhythmias in the ED.
Treatment is targeted to specific identified causes of the syncopal event; 80% of the time, this will be neurocardiogenic syncope, and treatment for these patients includes reassurance, increasing water (1.5 to .5 L/d or until urine consistently clear) and salt intake (2 to  g/d), and isometric counterpressure maneuvers. There is little evidence to support the use of compression devices.
If diet and lifestyle modifications are not sufficient, a trial of midodrine is reasonable in patients with persistent and bothersome vasovagal
,17 syncope.
DISPOSITION AND FOLLOW­UP
A child who had a syncopal event can present a challenging disposition decision, although in the majority of patients, the condition is benign.
Admit any child with a dysrhythmia documented by prehospital providers or on the ECG in the ED. Ensure that children who have any of the risk factors listed in Table 130­2 are seen by a pediatric cardiologist, either in the ED or in follow­up. Patients with a normal ECG but a history suspicious for dysrhythmia are candidates for outpatient ambulatory cardiac monitoring. Identified causes of syncope should be treated as appropriate in the ED, and admission to the hospital is directed by the need for further evaluation or therapy. Place all children admitted for an evaluation of syncope on a cardiorespiratory monitor.
If, after appropriately thorough history taking, physical examination, and ECG, no concerning features are elicited, the child may be discharged to home with follow­up by the child’s primary physician. Because neurally mediated syncope accounts for up to 80% of the cases of syncope in children,
 most children without cardiac risk factors or exercise­induced symptoms do not require any further cardiac investigations.
SPECIFIC CONDITIONS
SUDDEN DEATH
Sudden unexpected death can be due to many causes, such as a seizure, asthma, or toxic ingestion, whereas sudden cardiac death includes just those events that directly relate to cardiovascular dysfunction. Sudden unexpected death in children occurs in .5 cases per 100,000 children overall, with a
 ,21 much higher rate of  per 100,000 in children <1 year old. Sudden cardiac death rates range from .7 to .4 per 100,000, and sudden cardiac
 death accounts for about 2000 deaths per year in those younger than age . These numbers are approximate because there is no centralized registry of these cases. Excluding trauma, sudden cardiac death is the most common cause of sports­related death in young athletes, accounting for
 about 100 deaths per year in the United States. The greatest risk for sudden cardiac death is in patients with congenital or acquired structural cardiac disease, including those with congenital heart disease who have undergone corrective surgery. The most frequent causes of sudden cardiac death in
 children are listed in Table 130­3. Hypertrophic cardiomyopathy and congenital artery anomalies are the most common causes of sudden cardiac
 death in adolescents without known cardiac disease.
TABLE 130­3
Predisposing Factors for Sudden Cardiac Death in Children
Structural/functional cardiac disease Hypertrophic cardiomyopathy
Coronary artery anomalies
Dilated or restrictive cardiomyopathy
Acute myocarditis
Congenital heart disease
Arrhythmogenic ventricular cardiomyopathy
Rhythm disturbances Long QT syndrome
Wolff­Parkinson­White syndrome (WPW)
Brugada syndrome
Complete heart block
Systemic disease Marfan’s syndrome (aortic rupture)
Sudden cardiac death is usually an unexpected, unwitnessed, terminal event.
,26
Survival from an out­of­hospital cardiac arrest is very unlikely, with reported rates from .5% to 5%. Any surviving patients must undergo rapid stabilization, and any identified conditions must be quickly treated. In general, the principles of pediatric advanced life support are followed (see
Chapter 109). Wide QRS complex tachydysrhythmias should not be treated with class Ia agents such as procainamide and quinidine or class III agents such as sotalol or amiodarone if long QT syndrome is suspected, as these medications act by prolonging the QT interval. Class Ib drugs, such as phenytoin, should be used instead; torsades de pointes should be treated with magnesium,  to  milligrams/kg (maximum dose,  grams; see
Chapter 109).
After stabilization, children who have experienced a sudden cardiac arrest should be transferred to a pediatric intensive care unit that is capable of managing cardiac disorders. A crew capable of treating cardiac arrest from any dysrhythmia must perform any transfers. In general, this should be done by a dedicated pediatric critical care transport team and in consultation with the receiving pediatric intensivist.
NEUROCARDIOGENIC SYNCOPE
The majority of neurally mediated syncope is a mixed pattern of vasodepressor syncope (due to vasodilation) and cardioinhibitory syncope (due to
 vagal stimulation). Neurocardiogenic syncope is the most common type of syncope in children and usually is preceded by a sensation
 of warmth, nausea, lightheadedness, and a visual gray­out or tunneling of vision. This type of syncope frequently lasts <1 minute.
Common precipitating factors include prolonged recumbence just before standing or prolonged standing, sight of blood or disfiguring injury (e.g., fractures or soft tissue injuries), emotional upset, mild physical trauma or pain, physical exertion, and hot or crowded conditions. Other contributing factors that are less common include hypovolemia, anemia, dehydration, and pregnancy. Breath­holding spells are a variant of this form of syncope. Medications that alter vascular tone or heart rate may contribute to the development of syncope, including β­blockers, calcium channel blockers, and diuretics. Hypovolemia can result from diuretic use in young athletes, such as wrestlers, who must comply with weight restrictions.
Diagnosing neurocardiogenic syncope in the ED can be challenging, because there is no specific diagnostic test. A history of position change, prodromal symptoms, an absence of previously noted red flags, a normal physical exam, and normal ECG fairly reliably confirm that the syncopal event is benign in nature.
BREATH­HOLDING SPELLS
Breath­holding spells are a form of neurally mediated syncope. Typical occurrence is in a 6­ to 18­month­old child, and an intense emotional trigger
 that causes crying precipitates the spell and then breath­holding during expiration. The child may become cyanotic or pale and lose consciousness from progressive cerebral hypoperfusion. Myoclonic activity or seizure activity may occur. The episode is usually short, requires no specific intervention, and rapidly resolves with gasping respirations and progressive loss of cyanosis or pallor. Up to 20% of children who have breath­holding
 spells develop neurocardiogenic syncope in later life.
ORTHOSTATIC SYNCOPE AND POSTURAL ORTHOSTATIC TACHYCARDIA SYNDROME
Factors that predispose children to orthostatic syncope include anemia, dehydration, and use of certain medications, especially calcium channel
 blockers and angiotensin­converting enzyme inhibitors. A drop of >20 mm Hg in blood pressure with an increase in heart rate of >20 beats/min when the child changes from a supine position to a standing position is often considered diagnostic of orthostatic hypotension. Postural orthostatic tachycardia syndrome is a form of chronic orthostatic intolerance, defined by elevation in heart rate of >35 to  beats/min, with stable or increased
 blood pressure on tilt­table testing combined with symptoms of orthostatic intolerance and sympathetic overactivation.
SITUATIONAL SYNCOPE
Urination, defecation, coughing, and swallowing have been described as causing syncope. The pathophysiology is thought to be related to an exaggerated Valsalva response causing cardioinhibitory syncope. Stretching, neck extension, external neck pressure, and hair grooming also have been described as causing syncope, presumably due to carotid sinus hypersensitivity or abnormal Valsalva responses.
PEDIATRIC AUTONOMIC DISORDERS
Abnormalities in heart rate and blood pressure control can be inherited as a primary disorder. These disorders are associated with general autonomic dysfunction and present with many more symptoms than syncope. The most common is familial dysautonomia (Riley­Day syndrome). This disorder results from abnormal development of the sensory and autonomic ganglia, due to a genetic defect that inhibits neurotransmitter production.
Manifestations include failure to thrive, developmental delay, temperature instability, abnormal sweating, absent lacrimation, breath­holding spells, and seizures.
HYPERTROPHIC CARDIOMYOPATHY
Hypertrophic cardiomyopathy, also known as idiopathic hypertrophic subaortic stenosis, results in a dynamic and a fixed subvalvular obstruction (see
Chapter 129, “Congenital and Acquired Pediatric Heart Disease”). Exertional syncope is a common presentation, but infants may present with congestive heart failure and cyanosis. This diagnosis must be considered in any child with exertion­related syncope. A typical loud crescendodecrescendo murmur may be heard at the left sternal border, which is accentuated by standing or Valsalva (decreased left ventricular preload). The

ECG is abnormal in >75% of patients, usually with findings of left ventricular hypertrophy. Onset of symptoms in early childhood is associated with a
 greater risk of mortality—the 10­year mortality rate is 50% for children diagnosed before  years of age. Syncopal events appear to be related to myocardial ischemia and/or ventricular tachycardia, secondary to the long QT syndrome. Echocardiography is necessary to exclude or confirm this diagnosis and should be performed in the ED or on the inpatient ward. Patients with hypertrophic cardiomyopathy should be advised against playing competitive sports to reduce risk of sudden death. β­Blockers and septal reduction surgery are the mainstays of treatment. The benefit of implanted
 cardiac defibrillators is controversial in pediatric hypertrophic cardiomyopathy. All patients with this condition should be managed in consultation with a pediatric cardiologist.
DILATED CARDIOMYOPATHY
Dilated cardiomyopathy is unusual in children but can occur by three general mechanisms: idiopathic, with congenital heart disease, or after myocarditis (see Chapter 129). Syncope and death are thought to be caused by ventricular dysrhythmias or severe myocardial dysfunction.
ARRHYTHMOGENIC VENTRICULAR CARDIOMYOPATHY (FORMERLY ARRHYTHMOGENIC RIGHT VENTRICULAR DYSPLASIA)
Arrhythmogenic ventricular cardiomyopathy has a general prevalence of  in 2000 population; however, it is a common cause of adolescent death in
 certain countries such as Italy and parts of Greece. The disorder is more common in older adolescents and adults. Once thought to affect only the right ventricle, this has been shown to be a biventricular disease with a right­sided predominance. Patients usually present with congestive heart failure, cardiomegaly, and syncope or sudden death from a dysrhythmia. ECG abnormalities include left bundle branch block and T­wave inversion, but some patients may have normal ECG findings. Even the echocardiogram, cardiac catheterization, and myocardial biopsy results can be nondiagnostic, which makes exclusion of this disorder by the ED physician problematic.
CONGENITAL CYANOTIC AND NONCYANOTIC HEART DISEASE
Hypercyanotic spells may progress to syncope in tetralogy of Fallot, tricuspid atresia, transposition of the great arteries, and Eisenmenger’s syndrome.
Children with structural heart disease are also prone to ventricular dysrhythmias and atrioventricular block (see Chapter 129).
VALVULAR DISEASES
Several valvular lesions are associated with syncope and sudden death. In general, the degree of valve dysfunction correlates with the risk of sudden death. Aortic stenosis is usually due to a congenital defect and is often associated with a bicuspid valve. Other associated cardiac anomalies, in particular coarctation of the aorta, also may present as syncope. Most patients with valvular disease are identified by the presence of a murmur.
Exertional syncope, from valvular disease, is caused by reduced cerebral blood flow and is associated with chest pain, dyspnea on exertion, and poor exercise tolerance. Mitral valve prolapse itself is not associated with an increased risk of sudden death, but children with the disorder do appear to
 have a higher frequency of syncope and dyshythmias. A child with mitral valve prolapse and syncope requires a more intensive diagnostic workup.
Ebstein’s malformation of the tricuspid valve is an uncommon disorder (see Chapter 129). Sudden death in patients with this anomaly is thought to be due to the development of supraventricular or ventricular dysrhythmias.
PULMONARY HYPERTENSION
Primary pulmonary hypertension (without structural heart disease) is uncommon but can present in adolescence. It is often associated with dyspnea on exertion, shortness of breath, exercise intolerance, and syncope. Eisenmenger’s syndrome is acquired pulmonary hypertension due to a cardiac shunt. High blood flow to the pulmonary circulation from a left­to­right shunt leads to a reactive increase in pulmonary resistance. After months to years, the development of pulmonary hypertension causes the shunt to reverse to a right­to­left shunt, and cyanosis becomes apparent. One half of patients with pulmonary hypertension develop syncope. Physical findings include an increased ventricular impulse, a loud second heart sound, and cyanosis, which is particularly prominent in patients with Eisenmenger’s syndrome. Syncope and sudden death usually are related to a dysrhythmia.
CORONARY ARTERY ABNORMALITIES
Coronary artery abnormalities can cause sudden death during exercise or exercise­induced syncope. Abnormalities of coronary artery origin include the origination of the left main artery from the right sinus of Valsalva and, less frequently, the origination of the right artery from the left sinus. In both cases, the aberrant artery often passes between the aorta and the pulmonary artery, which thus places it at risk for extrinsic compression, especially during physical exertion. The ECG in abnormal left coronary arteries shows evidence of anterolateral myocardial infarction and abnormal R­wave progression. Other coronary abnormalities include myocardial overbridging, coronary artery fistulas, coronary artery spasm, coronary ostial stenosis, coronary artery aneurysms, and stenosis from Kawasaki’s disease.
DYSRHYTHMIAS IN CHILDREN
,13
Outpatient continuous portable ECG monitoring identifies the cause of syncope in <1% of cases. Case series indicate value in implantable loop recorders in cases of recurrent syncope with a history concerning for cardiac dysrhythmia. A cardiac dysrhythmia should be suspected if syncope is associated with an intense sympathetic stimulus, such as fright, anger, surprise, or physical exertion. The event usually starts and ends abruptly and may be associated with palpitations, irregularities of heartbeat, or chest pain.
A number of variations in rhythm can occur in normal children that are not considered pathologic. Significant P­P interval variation is common in children and represents an exaggerated respiratory reflex (slowing during expiration) leading to this benign sinus dysrhythmia. Infants in particular may demonstrate sudden prolongation of the P­P interval (up to .9 seconds), which is normal. Other common and benign variations include isolated ventricular premature beats (up to 40% of adolescents), which are typically of uniform morphology. Isolated supraventricular premature beats are also common in children of all ages. First­degree atrioventricular block, Mobitz type  second­degree atrioventricular block, and junctional rhythms can
 also be seen in normal children.
Dysrhythmias occur as a result of altered cardiac impulse formation, conduction, or both, and may be related to congenital structural disease (e.g.,
Ebstein’s anomaly, mitral valve prolapse, mitral stenosis), operative repair of congenital heart defect (e.g., corrected transposition of the great arteries, tetralogy of Fallot, atrial septal defect, or Fontan procedure), systemic disease (e.g., electrolyte abnormalities, neuromuscular disorders, metabolic or
,35 endocrine disease), acquired heart disease (e.g., myocarditis, endocarditis, Kawasaki’s disease), or isolated electrical abnormalities.
In general, children are able to tolerate higher rates without the ischemic phenomenon often present in adults. Dysrhythmias can occur in the absence of underlying structural heart disease or metabolic condition. Many conditions that occur in the adult population—such as hypoxia, electrolyte imbalance, collagen vascular diseases, and overzealous use of sympathomimetic agents—rarely occur in children. Because much of the prognosis with regard to the recurrence of a dysrhythmia depends on the nature of underlying structural cardiac defects, cardiologic evaluation is needed for all firsttime occurrences of dysrhythmias.
The symptoms of true dysrhythmias can be subtle and nonspecific, particularly in neonates and infants, in whom poor feeding and irritability may be the only signs of early tachyarrhythmia. Sustained tachyarrhythmia may progress to signs of poor cardiac output and the development of congestive heart failure, edema, and poor capillary refill. Older children, on the other hand, may verbalize more classic adult symptoms of palpitations or tachycardia. Symptoms related to decreased cerebral blood flow that may suggest dysrhythmia include syncope or dizziness, whereas those related to decreased coronary blood flow include chest pain. Some dysrhythmias with features or treatments unique to children are discussed below.
ATRIOVENTRICULAR BLOCK
Atrioventricular block is most common in children with congenital heart disease after heart surgery but also occurs as a rare congenital disorder.

Congenital atrioventricular block is associated with death in infancy, but children may be asymptomatic into adolescence. Congenital atrioventricular block is more prevalent with connective tissue disease in the mother. Atrioventricular block also occurs with acquired heart diseases, such as
 hypertrophic cardiomyopathy, myocarditis, and muscular dystrophy, and in 87% of children with carditis associated with Lyme disease. Syncope from a high­degree atrioventricular block warrants urgent referral to cardiology.
The treatment of sinus bradycardia in symptomatic patients begins with epinephrine (0.01 milligram/kg every  to  minutes; maximum dose,  milligram). If the bradycardia is due to atrioventricular block or increased vagal tone, then atropine (0.02 milligram/kg IV) as a temporizing measure is the best first­line treatment. The minimum dose is .1 milligram, with maximum single doses of .5 milligram for children and .0 milligram for adolescents. The maximum total dose (which is fully vagolytic) is .0 milligram for children and .0 milligrams for adolescents. Isoproterenol infusion
(0.1 to  micrograms/kg/min) or epinephrine infusion (0.1 to  micrograms/kg/min of 1:10,000 dilution) can also be used, although definitive treatment usually requires pacing. Transthoracic pacing in children is discussed in Chapter 109, “Resuscitation of Children.”
Prophylactic pacemaker insertion is routinely performed in children with acquired or congenital atrioventricular block.
SUPRAVENTRICULAR TACHYCARDIA
Supraventricular tachycardia can lead to syncope while the patient is recumbent if the heart rate is high enough to inhibit cardiac filling or if coincident
 vasomotor abnormalities occur. Wolff­Parkinson­White syndrome (see next section) and atrial fibrillation are the most common causes, but primary supraventricular tachycardia can also occur. Episodes of supraventricular tachycardia are associated with congenital heart disease, including Ebstein’s anomaly and corrected transposition of the great arteries.
The differentiation of sinus tachycardia from supraventricular tachycardia can be difficult in young children. A rate of >220 beats/min in an infant or >180 beats/min in a child, with a rate out of proportion to clinical status, is likely supraventricular tachycardia. Causes of sustained high­rate sinus tachycardia important to exclude are severe dehydration, fever, pain, hemorrhage, hyperthyroidism, sepsis, and drug toxicity from ingestion or iatrogenic medication administration. If vagal maneuvers can slow the heart rate and P waves become visible, the diagnosis is sinus tachycardia. Treatment of supraventricular tachycardia is described in Chapter 109. WOLFF­PARKINSON­WHITE SYNDROME
Accessory pathways are common in infants and children with supraventricular tachydysrhythmias. They consist of thin strands of subendocardial tissue with conductive properties that create a “bypass” tract around the atrioventricular node, allowing direct conduction of atrial impulses to the ventricular myocardium. Accessory pathways often carry impulses faster than the normal atrioventricular conduction system and are not subject to the normal conduction delay of the atrioventricular node. Some accessory pathways carry impulses bidirectionally, whereas others may conduct in only one direction. Those that conduct in a retrograde­only direction are known as “concealed” because they are not visible on ECG during sinus rhythm but can lead to atrial preexcitation and fibrillation. Those that conduct in an antegrade­only fashion can cause atrioventricular reentrant tachycardia that is conducted in the retrograde direction through the atrioventricular node, resulting in wide complex tachycardia.
Wolff­Parkinson­White syndrome is the most common form of ventricular preexcitation in children and was first described in 1930. It has a prevalence of .1 to .1 per 1000 and is more common in boys than girls. Although most cases of Wolff­Parkinson­White syndrome are sporadic, familial autosomal dominant inheritance has been described. Approximately  in  patients with Wolff­Parkinson­White syndrome have associated cardiac anomalies including Ebstein’s anomaly, hypertrophic obstructive cardiomyopathy, atrial septal defect, ventricular septal defect, transposition of the great arteries, and coarctation. Wolff­Parkinson­White syndrome is characterized by an accessory pathway that may be asymptomatic or can lead to
 recurrent episodes of tachydysrhythmia through ventricular preexcitation.
The diagnosis of Wolff­Parkinson­White syndrome is typically made electrocardiographically through signs of preexcitation: a short PR interval (<0.12 seconds), a prolonged QRS complex (>0.12 seconds), and the delta wave, which represents a slurred upstroke of the QRS complex (Figure 130­1).
These findings may be subtle during normal sinus rhythm or absent during paroxysmal supraventricular tachycardia, but may be enhanced with vagal maneuvers or immediately after conversion of a tachydysrhythmia. Therefore, it is important to run a rhythm strip during the conversion of all patients with supraventricular tachycardia so any abnormal ECG findings in the immediate postconversion rhythm are observed.
FIGURE 130­1. Wolff­Parkinson­White syndrome. Note the short PR interval and widened QRS with delta waves.
The clinical presentation of Wolff­Parkinson­White syndrome ranges from asymptomatic discovery on ECG to symptoms of dysrhythmia including palpitations, dizziness, shortness of breath, chest pain, or syncope. Dysrhythmias occur in approximately 50% of patients with Wolff­Parkinson­White syndrome and are usually characterized by narrow complex tachycardia through atrioventricular reentrance (antegrade conduction through the atrioventricular node with retrograde conduction through the accessory pathway—”orthodromic”); atrial fibrillation is common in patients with orthodromic accessory pathways with Wolff­Parkinson­White syndrome. Occasionally, antidromic tachycardia (antegrade conduction through the accessory pathway with retrograde conduction through the atrioventricular node) can lead to ventricular fibrillation and death.
The acute management of supraventricular tachycardia in patients with Wolff­Parkinson­White syndrome is similar to that of supraventricular tachycardia from other causes: in stable patients, vagal maneuvers or adenosine may be useful; unstable patients are treated with immediate synchronized cardioversion. Two important caveats, however, should be noted in the pharmacologic management of supraventricular tachycardia with accessory pathways: verapamil and digoxin should not be used in this setting because they may precipitate lethal dysrhythmias; similarly, flecainide should be avoided in patients with Wolff­Parkinson­White syndrome. Because of the risk of recurrence of dysrhythmias in Wolff­Parkinson­White syndrome, definitive treatment usually consists of radiofrequency catheter ablation. Pharmacologic options for the treatment of atrial fibrillation associated with Wolff­Parkinson­White syndrome and the prevention of recurrent dysrhythmias are listed in
Table 130­4. TABLE 130­4
Management of Patients With Accessory Pathways (Wolff­Parkinson­White Syndrome)
Clinical
Treatment Comments
Situation
Supraventricular Pharmacologic: Treat as per Chapter 109 Adenosine may induce atrial fibrillation/flutter with rapid ventricular tachycardia Definitive treatment: radiofrequency catheter ablation response; avoid digoxin and flecainide, which can lead to lethal dysrhythmias.
Atrial fibrillation
Stable Amiodarone  milligrams/kg (300 milligrams max) over Avoid nodal blocking agents such as verapamil, diltiazem, adenosine, β­
Unstable 20–60 min blockers, and digoxin because these may precipitate ventricular
Synchronized cardioversion .5–2 J/kg fibrillation.
Prevention of Pharmacologic: propranolol  milligram/kg/dose 2–3 recurrence times a day or sotalol .5–2 milligrams/kg/dose  times a day
Definitive treatment: radiofrequency catheter ablation
LONG QT SYNDROME
Long QT syndrome is an inherited or acquired channelopathy and is characterized by a prolonged QT interval on the ECG. Inherited long QT syndrome is relatively rare, occurring at a rate of  in 2000 to 5000 births. It is associated with an increased risk of polymorphic ventricular tachyarrhythmias and
 sudden cardiac death in young individuals with normal cardiac morphology. Classically, a patient with long QT syndrome should have a corrected QT interval that is >0.44 seconds on the ECG; however, registry evidence indicates that the risk of cardiac events increases only with corrected QT of >0.50
 seconds in children and >0.53 seconds in adolescents. Therefore, patients with corrected QT <0.5 seconds and no history of syncope are considered at low risk of cardiac events. Other abnormalities on the ECG associated with long QT syndrome include torsade de pointes, T­wave alternans, notched
T waves in three leads, and prominent U waves. Children with long QT syndrome may have a normal ECG in the ED. The disorder may then be diagnosed by discovery of a history of long QT syndrome in a family member (familial), stress testing (exertional), or Holter monitoring (intermittent).
On history, review any recent use of medications that can prolong the QT interval. (Table 130–5 indicates some common medications, but there are many other medications that can cause QT prolongation.) Appropriate treatment can reduce the risk of aborted cardiac arrest and sudden cardiac death by approximately 50%. β­Blockers are the mainstay of treatment, but they are ineffective for some long QT variants. Therapy should be started in consultation with a cardiologist. Genetic studies to date have identified  genetic loci associated with long QT syndrome, all of which encode proteins
 involved in sodium, calcium, and potassium transport.
TABLE 130­5
Some Common Medications That Prolong QTc
Drug Class Examples
Antiarrhythmics Class Ia and Ic (quinidine, flecainide; procainamide)
Class III (sotalol > amiodarone)
Antihistamines Diphenhydramine, hydroxyzine, terfenadine, astemizole
Antimicrobials Macrolides (azithromycin, erythromycin, clarithromycin)
Fluoroquinolones (ciprofloxacin, levofloxacin, ofloxacin, moxifloxacin)
Antifungals (cotrimoxazole, fluconazole, ketoconazole, voriconazole)
Other (antimalarials, trimethoprim sulfa, pentamidine)
Psychiatric drugs Tricyclics
Phenothiazines
Others (citalopram, clozapine, fluoxetine, haloperidol, lithium, methadone, risperidone, quetiapine, sertraline, trazodone, venlafaxine, ziprasidone)
GI agents Cisapride, ondansetron
Anticonvulsants Fosphenytoin, felbamate
Immunosuppressives Tacrolimus
Migraine medications Sumatriptan, zolmitriptan
Stimulants Albuterol, epinephrine, dopamine, dobutamine, isoproterenol, methylphenidate, phenylephrine, terbutaline
Other Chloral hydrate, octreotide, vasopressin
Over­the­counter/illicit Phenylephrine, pseudoephedrine, cocaine, amphetamine drugs
SICK SINUS SYNDROME
Sick sinus syndrome is also known as tachycardia­bradycardia syndrome. Isolated sinus node dysfunction rarely causes syncope, and syncope associated with sick sinus syndrome is more likely to be due to a reentrant atrial tachycardia. Most commonly, these dysrhythmias are associated with prior heart surgery, especially the Mustard or Senning operation for transposition of the great vessels and the Fontan procedure. Syncope and sudden death can occur after pacemaker placement, because the pacemaker prevents bradycardia but not tachycardia.
ECG INTERPRETATION IN INFANTS AND CHILDREN
The pediatric ECG is characterized by age­related variations and, as a result, can be very difficult to interpret. The age­related variations reflect the maturation of the pediatric myocardium and vascular system from the neonate to adult. Developmental changes in the pediatric ECG from birth to adolescence include a gradual shift from right to left ventricular dominance, decrease in the resting heart rate, a lengthening of the PR and QRS
,42,43 intervals, and a change from inverted to upright T waves in the precordial leads. Use a systematic approach to ECG interpretation, checking rate, rhythm, axis, hypertrophy of the atria and ventricles, and repolarization changes. Reference tables with age­specific values are necessary to deal with the progressive changes in heart rate, axis, interval duration, and morphology. The most important changes are described below.
NORMAL ECG INTERVALS
HEART RATE
The normal heart rate is age dependent (Table 130­6). The neonatal and infant heart has a limited capacity to increase stroke volume, and therefore, cardiac output is largely dependent on rate, which is relatively high in the young infant to meet increased metabolic demands. Significant statedependent and beat­to­beat variability in resting heart rate is characteristic of the normal neonatal and infant heart. Sinus tachycardia in the neonate can often reach 200 to 220 beats/min and is common in the setting of fever or pain. In general, bradycardia with normal perfusion and without evidence of heart block (discussed below) rarely requires treatment or investigation.
TABLE 130­6
Normal Pediatric Heart Rates44
Age Heart Rate (beats/min)
Birth–4 wk 130–190
1–3 mo 125–185
3–6 mo 110–165
6–12 mo 105–195
1–3 y 100–155
3–5 y 70–120
5–8 y 60–110
8–12 y 55–100
12–16 y 50–100
P AND QRS AXES
Because blood is shunted away from fetal lungs and the right ventricle provides the majority of systemic blood flow in utero, the right ventricle predominates in the neonate. In the first few months of life, this is characterized by right ventricular dominance and right axis deviation. P waves should be upright in leads I and aVF with the P axis between  and +90 degrees. The precordial leads have increased R­wave amplitude in V and V and
  decreased amplitude in V and V . With a subsequent increase in left ventricular size during infancy and early childhood, the QRS axis shifts leftward, so
  that R­wave amplitude decreases in V and V and increases in V and V (Table 130­7).

TABLE 130­7
Age­Specific QRS Axis44
Age Mean Axis in Degrees Range in Degrees
Birth–4 wk 105 60–160
1–3 mo  40–140
3–6 mo  0–110
6–12 mo  0–120
1–3 y  0–120
3–5 y  0–115
5–8 y  –10 to 120
8–12 y  –20 to 120
12–16 y  –10 to 110
PR, QRS, AND QT INTERVALS

The PR interval varies with age, gradually lengthening from .08 to .12 seconds in neonates to .11 to .18 seconds in adolescents. The QRS interval
 also lengthens over time from .05 to .09 seconds in the neonate to .07 to .11 seconds in the adolescent. The QT interval (measured from the onset of the QRS complex to the end of the T wave) is subject to variations in heart rate, and a correction for heart rate is calculated using Bazett’s formula: QTc = QT/the square root of the RR interval. The QTc should be <0.49 seconds in the first  months of life and <0.44 seconds thereafter,
 although different definitions for prolonged QTc have been suggested. Age­specific normal intervals are listed in Table 130­8. TABLE 130­8
Age­Specific ECG Intervals44
Age PR (seconds) QRS (seconds) QTc (seconds)
Birth–4 wk .08–0.12 .05–0.09 .38–0.46
1–3 mo .08–0.13 .05–0.08 .38–0.46
3–6 mo .08–0.14 .05–0.09 .39–0.45
6–12 mo .08–0.14 .05–0.09 .38–0.45
1–3 y .08–0.15 .05–0.09 .38–0.45
3–5 y .1–0.15 .06–0.09 .38–0.45
5–8 y .09–0.16 .06–0.1 .37–0.45
8–12 y .1–0.17 .07–0.1 .37–0.45
12–16 y .1–0.18 .7–0.11 .36–0.46
T WAVES
Pediatric T­wave changes are typically nonspecific. Flat or inverted T waves are usually normal in the newborn. T­wave inversion in the right precordial
 leads is common in the first years of life and may persist into adolescence or revert in early childhood to the typical upright pattern seen in adults. T­ wave changes are common in infants and children and rarely reflect ischemia.
CHAMBER SIZE
Evaluating the ECG for signs of chamber size is important when considering congenital or acquired heart disease in the pediatric patient. P­wave amplitude is relatively age independent and best measured in lead II. P waves >0.25 mV should be considered abnormal and may indicate right atrial
 enlargement. Left atrial enlargement is suggested by prolonged P­wave duration, which should not be >0.08 seconds in infants or >0.12 seconds in
 ,45 adolescents. Voltage criteria for left ventricular hypertrophy and right ventricular hypertrophy depend on age and are listed in Table 130­9. Left ventricular hypertrophy is also suggested by a q­wave amplitude >4 mm in V or V or inverted T wave in V , whereas right ventricular hypertrophy is

,42,43 suggested by an RSR′ pattern in V with an R′ >15 mm in infants or >10 mm in children after the first year of life, or with a q wave in lead V .

TABLE 130­9
Voltage Criteria for Left Ventricular Hypertrophy (LVH) and Right Ventricular Hypertrophy (RVH) by Age42,45
Age
0–7 d  d–1 y 1–3 y 3–5 y >5 y
LVH
RV >12 mm >23 mm >21–23 mm >24–25 mm >25–27 mm

SV >23 mm >15–18 mm >21 mm >22 mm >26 mm

SV + RV >28 mm >35 mm >38 mm >42 mm >47 mm

RVH
RV >26 mm >20–22 mm >18 mm >14–18 mm >13 mm

SV >10 mm >7–10 mm >7 mm >6 mm >4 mm

RV + SV >37 mm >43 mm >30 mm >24 mm >17 mm



