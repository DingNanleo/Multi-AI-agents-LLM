## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 95: Complications of Urologic Procedures and Devices
Elaine B. Josephson; Benjamin Azan
COMPLICATIONS OF URINARY CATHETERS
Urinary catheters should be used sparingly. Indwelling urethral catheters are the most common; suprapubic catheters require a surgical procedure but
,2 have fewer long­term infectious complications than indwelling urethral catheters after  days of use (see Chapter , “Acute Urinary Retention”).
Table 95­1 lists the complications of urinary catheters.
TABLE 95­1
Complications of Urinary Catheters
Indwelling Urethral Catheters Suprapubic Catheter
Prostatitis Hematoma formation
Epididymitis Persistent leakage
Scrotal abscess Insertion failure/catheter misplacement
Creation of false urethral lumen Abdominal wall cellulitis/abscess
Urethral disruption Injury to abdominal organs
Urethral stricture
Complications Common to Both Indwelling Urethral and Suprapubic Catheters
Asymptomatic bacteriuria
Urinary tract infection
Pyelonephritis
Intraluminal encrustation
Mechanical obstruction
Gross and microscopic hematuria
Bladder perforation
Nondeflating catheter balloon
Allergy to catheter material
INFECTION

Catheter­associated urinary tract infection (UTI) is one of the most common causes of nosocomial infections. The risk of bacteriuria is approximately

3% to 8% per day, with the prevalence reaching almost 100% for long­term catheterization (by  days). However, bacteriuria does not equate to
 clinical infection. Infection rates range from .5 to .8 per 1000 catheter days. Comorbidities that increase the risk of infection include female sex,
 prostatic hypertrophy, elevated creatinine at time of insertion, diabetes, advanced age, catheter care violations, and debilitation. Associated microbial factors include the source of the organisms, the specific bacteria, the route of invasion, and the duration of catheterization.
Pathophysiology

Chapter 95: Complications of Urologic Procedures and Devices, Elaine B. Josephson; Benjamin Azan 
In the noncatheterized urinary tract, bacteria are efficiently eliminated. Most bacterial strains that are introduced into the catheterized urinary tract, in
. Terms of Use * Privacy Policy * Notice * Accessibility contrast, are able to multiply to high concentrations in  hours. Bacteria may be able to gain access to the urinary tract through the catheter lumen
(intraluminal) or along the catheter surface (extraluminal). If the drainage tube lumen is colonized, bacteria may ascend the collection bag and catheter and may cause an infection. An infection from the catheter lumen route begins with the formation of a biofilm on the catheter’s inner surface. This biofilm extends from the uroepithelium through catheters to the drainage bag and allows adherence of bacteria to a catheter or mucosal surface.

Organisms become embedded within the biofilm and gain protection from the mechanical flow of urine, host defenses, and antibiotics. The microbiology varies according to the duration of catheter placement. During short­term catheterization, infections are usually due to single organisms, most commonly Escherichia coli, followed by Klebsiella, Pseudomonas, Enterobacter, and gram­positive cocci such as staphylococci. With long­term catheterization (≤30 days), catheter­associated UTIs are usually polymicrobial from E. coli, Proteus mirabilis, Pseudomonas, Morganella morganii, and
Candida species.
Clinical Features
Signs and symptoms include fever, rigors, altered mental status, malaise, or lethargy with no other identified cause; flank pain; costovertebral angle tenderness; acute hematuria; pelvic discomfort; and in those patients whose catheters have been removed, dysuria, urgent or frequent urination, or suprapubic pain or tenderness. In patients with spinal cord injury, increased spasticity, autonomic dysreflexia, and sense of unease are also
 compatible with infection.
Diagnosis
,6
Specific symptoms of symptomatic infection are listed in Table 95­2. Pyuria is universal for patients with long­term (>1 month) indwelling
3­5 catheters; in the absence of clinical symptoms, pyuria should not be used in the diagnosis of symptomatic infection.
TABLE 95­2
Catheter­Associated Urinary Tract Infection (CAUTI) Symptoms in Different Patient Populations
Symptomatic CAUTI
Diagnosis Requires Symptoms or Signs
Infection Type/Group
Cystitis New onset or worsening of fever, rigors, suprapubic pain or tenderness, altered mental status, malaise, acute hematuria (compare to prior assessment); pelvic discomfort or lethargy with no other identified cause.
Pyelonephritis Syndrome, including fever, rigors, flank pain, or costovertebral angle tenderness.
Critically ill patient with Fever, rigors, change in normal appearance, change in normal mental status, subtle signs of either cystitis or compromised ability to give a pyelonephritis listed above.
history
Spinal cord injury patient Fever, rigors, increased spasticity, autonomic dysreflexia, or sense of unease.
Bacteremia Diagnosis supported by correlation between blood and urine cultures.
Sepsis syndrome See Chapter 151, “Sepsis.”
Suppurative Complications
Epididymitis See Chapter , “Male Genital Problems.”
Prostatitis See Chapter . Abscess, scrotal, prostate See Chapter . Pyelonephritis (complicated UTI; see Chapter , “Urinary Tract Infections and Hematuria”) is the most common complication of febrile catheterassociated infections. Other related infections include prostatitis, epididymitis, and scrotal or prostate abscess. Obtain urine cultures prior to empiric
 antibiotic therapy and obtain blood cultures if the patient is septic or immunocompromised.
Treatment
,5 
Remove the catheter if clinically feasible, or replace the catheter if it has been in place for more than  days. Antibiotic treatment of asymptomatic bacteriuria in a patient with a short­term indwelling urinary catheter is not recommended, unless the
,5,7 patient is pregnant or a urologic procedure is immediately pending. Guidelines and reviews recommend antibiotics for symptomatic
,5 catheter­associated infections only. Promptly give empiric antibiotics. Assess local resistance patterns before instituting therapy, and tailor therapy once culture results are available. Inpatient treatment for complicated UTI is reviewed in Table 91­6, and outpatient treatment for patients without clinical toxicity is presented in Table 91­5; see Chapter , “Urinary Tract Infections and Hematuria.” A total of  days is the recommended duration of antimicrobial treatment for patients with prompt resolution of symptoms, and a total of  to  days of treatment is recommended for those with a
 delayed response. Asymptomatic candiduria does not require treatment, except in high­risk populations, such as immunocompromised or
 neutropenic patients. If a Candida UTI is present, remove or replace the catheter, and treat with antifungal agents for  days.
CATHETER OBSTRUCTION AND LEAKAGE
Urethral catheters can become obstructed for many reasons. The most common in the patient without hematuria is the formation of intraluminal encrustations during long­term placement. Concretions are composed of compounds such as ammonium magnesium sulfate (struvite) and calcium phosphate (apatite), often originating from urease­splitting organisms, such as Protease and Morganella. Such encrustations can increase the risk of
 formation of infectious bladder stones with continued bladder infection and bladder trauma. A catheter obstruction may lead to urinary leakage around the catheter and acute urinary retention. Replacement of the catheter is the most common management used in the ED. See also Chapter ,
“Acute Urinary Retention.” Options to prevent re­obstruction include oral methenamine, catheter management by urology, or management by primary care at follow­up.
NONDEFLATION OF FOLEY RETENTION BALLOON
Nondeflation of the retention balloon on the catheter can be caused by a faulty valve mechanism or crystallization of balloon fluid, yielding entrapment
 of the Foley catheter. One noninvasive method is introduction of a flexible guidewire into the balloon inflation channel after cutting off the plastic cylindrical valve from the catheter just below its head. The guidewire dilates the channel and may allow the balloon to deflate. If unsuccessful, try step
; a 22­gauge central venous catheter can be passed over the guidewire. When the catheter tip is in the balloon, the wire can be removed, and the
  balloon may drain. If step  is unsuccessful, instill  mL of mineral oil and leave for  minutes in an attempt to chemically dissolve the balloon. If
 simple methods do not work, urologic consultation for intervention and potential cystoscopy or other complex management is recommended.
Another alternative is US­guided percutaneous rupture of the balloon using a needle, typically done by interventional radiology with input from urology.
TRAUMATIC COMPLICATIONS
Trauma is another common and sometimes dangerous complication of a urinary catheter. A catheter can cause false passages in the urethra during
 insertion, hematuria from direct urethral or bladder irritation, pain or erosion at the urethral meatus, and, rarely, bladder perforation. Ureteral
 intubation has been reported. Bowel perforation has been reported in the context of bladder perforation, usually from a chronic indwelling
 catheter. Nontotal deflation of the balloon and ridging (the formation of ridges on the deflated balloon) can cause urethral trauma during catheter
 removal. Consult urology if injury to the bladder or urethra is suspected.
COMPLICATIONS OF PERCUTANEOUS NEPHROSTOMY AND NEPHROLITHOTOMY
Percutaneous nephrostomy is a urinary drainage procedure used for supravesical or ureteral obstruction secondary to malignancy, pyonephrosis, GU stones, and ureteral strictures. The percutaneous procedure to remove renal calculi is known as percutaneous nephrolithotomy. Nephrostomy tubes or stents are commonly left in place during this procedure. In general, the risk of complications is low and includes bleeding, infection, mechanical
14­16 complications related to the catheter (dislodgement or obstruction), and accidental punctures of adjacent organs.
During insertion, injury can occur to the renal collecting system (subintimal dissection), lungs (pneumothorax), liver, spleen, and bowel
,17
(perforation). Complications usually are clinically apparent during or immediately after the procedure, but recognition may be delayed a few days.
Bleeding Complications
Bleeding and hemorrhage can occur, especially if the patient has a coagulopathy. Check hemoglobin, hematocrit, and renal function. Obtain coagulation studies (prothrombin time, PTT, and platelet count) and type and cross­match if bleeding is excessive, if coagulopathy is suspected, or if the patient is unstable. Most bleeding episodes are mild and can be managed with irrigation to clear nephrostomy tube blood clots. Transient
  hematuria is common and usually resolves spontaneously in  to  days. More severe bleeding, reported in .6% to .4% of patients, can be handled by catheter tamponade, a procedure undertaken by the urologist and radiologist. Severe hemorrhage occurs from vascular injury, such as laceration of an artery, formation of an arteriovenous fistula, or bleeding from a pseudoaneurysm, and may occur in the retroperitoneal space or perirenal areas. In such cases, fluid resuscitation and blood transfusion, in addition to more definitive interventions, are required. Angiographic
,17 studies with possible embolization may be needed to ascertain the site of bleeding.
Infectious Complications
Infections from nephrostomy tubes include simple bacteriuria, pyelonephritis, renal abscess, bacteremia, and urosepsis. Septicemia has been
 reported in .8% to .7% of cases. Signs and symptoms are fever, chills, rigors, pain, and purulent drainage at the site or from the tube. Obtain urine and wound cultures and give antibiotics.
Mechanical Complications
Catheter dislodgement, tube blockage, and residual stone fragments can occur. CT scan may be helpful for specific diagnosis. The risk of catheter
 dislodgement increases with increasing duration of the nephrostomy and obesity. Dislodgement occurring in the early postoperative period usually requires creation of a new tract at a different site. Dislodgement occurring after some period may be treated by recannulation under fluoroscopic guidance. Tube blockage can occur secondary to encrustations and kinking, which often require urologic intervention.
URINARY DIVERSION AND ORTHOTOPIC BLADDER SUBSTITUTION
The most common method of urinary diversion in the United States is the ileal conduit. With this procedure, a section of small bowel is isolated, and the free ends of the remaining small bowel are reunited, allowing for normal bowel function. The ureters are reimplanted to the isolated section of small bowel, most commonly at the base of the conduit. A stoma is created, typically on the anterior abdominal wall, where a collecting bag is attached.
Postoperative complications include bowel obstruction, pyelonephritis, skin breakdown surrounding the stoma, stenosis of the stoma, and inflammatory changes of the upper tract due to reflux of urine back into the ureters. Long­term complications include bowel obstruction or dysfunction (20.3%); deterioration in kidney function (20.2%); symptomatic UTI/pyelonephritis (16.5%); stomal hernia or stenosis (15.4%); urolithiasis
,20
(15.3%); metabolic derangements, most often metabolic acidosis (12.8%); and structural conduit dysfunction (11.5%).
There are multiple newer methods of creating a neobladder for orthotopic bladder substitution. These methods all have a goal of creating a continent reservoir for urine without reflux of the urine into the reimplanted ureters, which predisposes the patient to pyelonephritis. Options include other means of isolating portions of the small bowel (Kock pouch, T pouch, W­shaped neobladder) or large bowel (ileocecal segment). Evidenced­based
21­23 evaluations of multiple methods have failed to identify a superior procedure. Bacteriuria is very common after the procedure (up to 80%) and mostly involves skin flora, but may occasionally include uropathogenic strains (gram­negative Enterobacteriaceae species such as E. coli, Proteus,
,25
Pseudomonas, and Enterococcus faecalis). Clean intermittent catheterization, frequently required after the procedure, is associated with increased bacteriuria and pyuria. Diagnosis of infection should be made on evidence of symptomatic infection based on fever, flank
,25 pain, a change in chronic symptoms, or culture of pathologic organisms. Consult with urology for optimal management.
LITHOTRIPSY
Extracorporeal shock wave lithotripsy is the application of high­intensity sound waves to fragment GU calculi so they can pass down the ureter.
Common complications include colicky pain (15% to 40%), gross hematuria (32%), skin bruising (up to 26%), and steinstrasse (“street of stone,” or
,27 aggregate of stone fragments lining and/or impacting the ureter; up to 24%). In one report of 235 patients, 6% visited the ED after the procedure
 and .4% were admitted. Uncommon complications include spleen rupture, kidney rupture, abdominal or intrahepatic hematoma, pyelonephritis/sepsis, bowel injury, ureteric perforations, psoas abscess, vascular injury, and pancreatitis (a small increase in lipase is
,27,29­31 common). Postlithotripsy patients may develop abdominal and flank pain, nausea, vomiting (especially  hours after procedure), skin ecchymosis, gross hematuria, fever, or sepsis. Hematuria is generally self­limited (<24 hours); however, UTI may coexist. Diagnosis of minor complications usually requires CBC, basic chemistries, urinalysis, and renal US if obstruction is suspected. CT scan or MRI (only if stable) is indicated if serious complications are suspected (consider with flank hematoma, decrease in hematocrit, hypotension, syncope, or significant pain). Acute management may include IV fluid hydration, antiemetics, analgesics, monitoring, fluid resuscitation, blood transfusions, and antibiotics. Consider
 urology consultation early on, because specific treatments, such as embolization, may be required.
COMPLICATIONS OF URETERAL STENTS
Ureteral stents are used primarily in patients to relieve ureteral obstruction and maintain ureteral lumen patency or as an adjunct to lithotripsy.
Obstruction to the ureter may result from causes such as stones, strictures, trauma, malignancies, or retroperitoneal fibrosis. Stents can be placed during ureteroscopy, by the percutaneous nephrostomy route, or during surgery involving the GU tract. Table 95­3 lists the complications of ureteral stents.
TABLE 95­3
Complications of Ureteral Stents
Complication Management
Fever with pyelonephritis or sepsis Resuscitate, admit, IV antibiotics, consult urology
Simple urinary tract infection (UTI) Oral antibiotics
Microscopic hematuria/gross hematuria Microscopic hematuria is expected; consult urology for gross hematuria
Pyuria Consider treatment if coexistent bacteriuria
Irritative bladder symptoms: Analgesics, anticholinergics, rule out UTI
Dysuria/urgency/frequency
Flank pain/abdominal pain
Pain with voiding
Incontinence (urinary)
Mechanical/anatomic issues: Consult urology; resuscitate when needed
Obstruction (encrustation, clots, compression)
Stent migration/stent fragmentation
Erosion of the urinary tract
Vascular­ureter fistula
Malposition
Stent malfunction
Many factors contribute to stent­related UTIs. Stents induce a foreign body reaction, which increases the risk of infection. Stent encrustation also promotes infection. Pyelonephritis and sepsis can occur but are less common.
Most minor infections can be managed with outpatient antibiotics (see Tables 91­5 and 91­6 in Chapter , “Urinary Tract Infections and Hematuria”) and do not require stent removal. If pyelonephritis or a systemic infection is suspected, IV antibiotics, radiologic studies to determine the position of the stent, and urologic consultation are required. Stents usually can be visualized by plain abdominal radiographs due to the presence of radiodense marking embedded within the catheters. US imaging can detect hydronephrosis, along with confirmatory CT studies if obstruction or pyelonephritis is
 present.
Symptoms and signs suggestive of an irritative bladder, such as dysuria, urgency, frequency, incontinence, and pain during voiding, occur commonly in patients with ureteral stents. Treatment options for these symptoms can include antimuscarinics such as tolterodine,  milligrams twice daily, or α­
 blockers such as tamsulosin, .4 milligrams daily; common analgesics have poor efficacy. Obtain urinalysis and culture to exclude UTI. Severe flank pain requires evaluation for stent migration, infection, or obstruction. Asymptomatic microscopic hematuria is usually of no clinical significance, but
 gross hematuria may indicate stent migration or ureteral erosion. Obtain imaging to identify stent position.
Serious problems, such as stent migration and stent fragmentation—or even rarer, ureteral­arterial fistulization due to stent erosion into a nearby vessel—are usually late complications seen with long­term stent placements. Stent migration can occur upward above the ureteropelvic junction or downward below this junction. See Figure 95­1 for a radiographic demonstration of ureteral stent migration. Migration can lead to obstruction and
 infections. Stent migration results in symptoms of new­onset abdominal pain, fever, and irritative bladder symptoms and hematuria. For new anemia
 without hematuria, obtain a CT without contrast to rule out a stent­caused retroperitoneal hematoma. In the presence of severe gross hematuria and
,36 syncope or hypotension, assume that a vascular fistulization from an eroding stent exists until proven otherwise. Resuscitate and obtain emergency urologic and surgical consultation.
FIGURE 95­1. Ureteral stent migration. This abdominal plain film demonstrates stent migration with the distal portion of the stent coiled within the bladder.
[Reproduced with permission from Cline D, Stead L: Abdominal Emergencies. © 2008, McGraw­Hill, Inc., New York.]
PROSTATE SURGICAL PROCEDURES
Prostate surgery is performed for symptomatic benign prostatic hyperplasia or prostate cancer. Surgical prostate techniques include needle biopsy, transurethral resection of the prostate (TURP), transurethral electrovaporization, transurethral microwave thermotherapy, transurethral needle
,38 ablation, and visually assisted laser prostatectomy. For TURP, reported complications include urinary retention (3% to 9%), urethral strictures
,39
(2.2% to .8% as late complication), clot retention (2% to 13%), UTI (1.7%), and bleeding requiring transfusion (0.4% to 2%). Less common
 complications include urosepsis, myocardial infraction, pulmonary embolism, and cardiac arrhythmia. Bladder rupture following TURP has been
 reported. Patients may also experience obstructive or irritative voiding symptoms, including incontinence, dysuria, hesitancy, dribbling, urgency, and frequency.
Depending on severity of illness, appropriate laboratory studies may include urinalysis, CBC, blood type and screen, blood chemistries, and renal function. Assess for hemodynamic instability and treat with IV fluids or blood for life­threatening bleeding. Patients with outflow obstruction should be treated with a three­way Foley catheter. Start with manual irrigation to remove clots, and then initiate continuous irrigation with normal saline until
 clear or slight pink return. If bleeding does not clear, consult urology. Prolonged irrigation requires monitoring of serum electrolytes to
 assess for hyponatremia. If infection is suspected, obtain urine cultures, administer antibiotics, and consult urology.
COMPLICATIONS OF ARTIFICIAL URINARY SPHINCTERS
The artificial urinary sphincter is used for urinary incontinence secondary to sphincter disturbance, postsurgical incontinence, neurogenic bladder with incontinence, trauma to the urethra, and congenital conditions associated with bladder dysfunction, such as exstrophy and epispadias.
Sphincters are used predominantly in men, but are also placed in women. Placement of the artificial sphincter increases the resistance around the
 urethra and provides urinary continence. Mechanical parts of the artificial sphincter include an implanted pump, an inflatable cuff that encircles the urethra, and a pressure­regulating reservoir balloon (Figure 95­2). These are connected by a set of two tubes. Continence occurs when fluid is moved from the balloon to the cuff. To allow urination, the cuff is emptied, and fluid moves to the reservoir.
FIGURE 95­2. Diagram of artificial urinary sphincter. [Adapted with permission from James MH, McCammon KA: Artificial urinary sphincter for post­prostatectomy incontinence: a review. Int J Urol 21: 536, 2014. Copyright John Wiley & Sons.]

The most common complication after primary implantation is urinary retention, occurring in 31% of patients. Never introduce a urethral urinary
 drainage catheter through an artificial urinary sphincter. Periprosthetic infection can present early or late after surgical implantation (2%).
Infections occurring early after implantation are usually due to skin flora. Later infections are usually due to gram­negative organisms of the urinary tract. Symptoms and signs of infection can range from pain, swelling, and induration of the site to localized erythema of the pump or cuff site. More serious infections can present with fever, cellulitis, local abscess formation, drainage from incision sites, and erosion of the pump or the cuff.

Infections can cause the cuff to erode to the skin or the urethra. Treat periprosthetic infection with antibiotics and sphincter removal.
Retained air bubbles, tube kinking, fluid leaks, and perforation of the cuff are some of the mechanical complications that can occur leading to dysfunction of the artificial sphincter. A careful history may provide clues to malfunction. A pump that is difficult to squeeze implies blockage due to any cause, whereas a pump that remains compressed after squeezing signifies pressure loss or fluid leakage. Urinary catheterization and damage to
 the device components during other nonurologic surgeries may account for iatrogenic malfunction of the artificial sphincter. Plain radiographs of the pelvis and other imaging studies are used to assess continuity of the mechanical components.
Urethral erosion secondary to infection or excessive cuff pressure around the urethra is another serious complication. Signs and symptoms include
41­44 pain, swelling along the urethra and in the perineum, difficulty voiding, bloody urethral discharge, and infection.
Acute urinary retention in a patient with an artificial sphincter implant may occur as a result of bladder neck contractures, urethral strictures, or cuff erosion. Evaluation usually requires cystourethrography or cystourethral endoscopy.
Diagnosis and Treatment
Evaluation in the ED of complications related to the artificial sphincter requires a thorough history noting the model type and make; symptom assessment; a detailed physical examination; urinalysis; appropriate labs, cultures, and imaging studies; and consideration for IV antibiotics as indicated. Consult urology emergently. Do not introduce a urethral urinary drainage catheter through an artificial urinary sphincter.
COMPLICATIONS OF TREATMENTS FOR ERECTILE DYSFUNCTION
The most common causes of erectile dysfunction are diabetes, priapism, vascular disease, Peyronie’s disease (deformity especially seen on erection due to nodules/fibrous plaques in penile tissue), pelvic trauma or surgery, spinal cord injury, and psychogenic reasons. Oral phosphodiesterase­5 inhibitors (e.g., sildenafil, tadalafil, vardenafil) are often prescribed for erectile dysfunction. Nitrates can cause life­threatening hypotension when taken with phosphodiesterase­5 inhibitors. Sudden hearing loss has also been reported as an adverse effect. Some patients with erectile dysfunction fail oral pharmacologic therapy and are treated with penile injectable medications or nonpharmacologic interventions such as vacuum
45­47 therapy, external splint devices, and surgically implantable prostheses.
Drugs used for intracavernosal injections include papaverine, phentolamine, and alprostadil, a prostaglandin E analogue. Side effects include
 penile pain, prolonged erections (4 to  hours), priapism, and localized hematoma. Of these, priapism is the most serious complication (see Chapter
, “Male Genital Problems”).
Intraurethral injection of alprostadil or urethral insertion of a medicated pellet has a similar effect as intracavernosal injections. Intraurethral administration is usually free of any major systemic side effects, but hypotension and syncope secondary to a vasovagal reaction due to the anxiety of
,49 the injection and the vasodilatory effects of the drug can occur.
Vacuum devices work by use of negative pressure and the use of a constriction ring to cause venous and arterial congestion, thus causing penile engorgement. Serious complications from the use of a vacuum device include penile skin necrosis, urethral bleeding, ischemia, and subcutaneous
,51 hemorrhage with ecchymosis. Peyronie’s disease and Fournier’s gangrene have also been reported.
A penile prosthesis is reserved for men who fail pharmacologic treatment. Postoperative urinary retention, penoscrotal hematoma formation, and
,46 superficial wound infections have been reported. Infection usually occurs soon after the primary surgery for implantation. Late infections can occur years after the procedure secondary to bacteremia. Organisms causing penile prosthesis infection are typically Staphylococcus epidermidis,
Staphylococcus aureus,E. coli, and Candida. Infections present as pain along the device (e.g., in the scrotum or along the penis), erosion, and purulent
,46,52 urethral discharge. Treatment requires antibiotics and possible removal of the entire device by the urologist.

Erosion of the prosthesis can occur into penile tissue and often is accompanied by an infection in the same area. Migration of the device may occur
,46 proximally or distally, presenting as extrusion through the urethral meatus. Consult urology for erosion problems and device migration. Penile ischemia and necrosis are rare but serious complications. Mechanical failures may occur, such as pump autoinflation or fluid leakage from tubing, cylinder, or reservoir. Urologic consultation is necessary to evaluate mechanical problems.
VASECTOMY

With few exceptions, vasectomies are completed in the urologist’s office and are a safe procedure, with a complication rate of 1% to 2%.
Complications include bleeding and scrotal hematoma (most common), local wound infections (cellulitis, abscess, necrotizing infection), epididymitis, and painful sperm granulomas. Patients may develop persistent testicular pain or congestive epididymitis (pain and testicular tenderness on the
 affected side) months to years later.
Evaluate for infection, especially if the patient is immunosuppressed, and treat accordingly; consider scrotal US and consult urology for deep abscess
(see Chapter 93). When there is no evidence of bleeding or wound infection, treat postvasectomy epididymitis with ice packs, scrotal support, and analgesia with NSAIDs or opiates.
ADULT CIRCUMCISION

Circumcision, or foreskin resection, is usually performed on infant males. However, the procedure is also performed in adolescents and adults.
Complications after circumcision include bleeding (most common), infection, pain, edema, and wound dehiscence due to premature erection before
,56 completion of healing. Treat minor bleeding with direct pressure or a topical thrombostatic agent as needed. Administer oral antibiotics
(trimethoprim­sulfamethoxazole or ciprofloxacin) with local wound care for minor infections. Give analgesia as indicated. Consult urology for significant bleeding or infection. Plastic devices used for circumcision may become displaced prior to planned removal date; consult urology for
 management.


