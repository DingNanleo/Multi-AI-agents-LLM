## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 276: Ankle Injuries
Talib Omer; Margarita Santiago­Martinez
INTRODUCTION AND EPIDEMIOLOGY

Given the mobility of the ankle joint and our bipedal existence, ankle injuries are a common complaint. They represent about 4% of all visits to the ED.
,3
Previous ankle sprain and participation in contact sports are risk factors for ankle injuries.
ANATOMY
The proximal part of the ankle mortise is composed of the distal fibula and tibia that fits on top of the talus. These bones are wider anteriorly than posteriorly. Joint stability is provided by medial and lateral malleoli extending on either side of the talus. The medial deltoid ligament, lateral
 ligament complex, and syndesmosis are the three distinct groups of ligaments that stabilize the ankle (Figure 276­1). The deltoid ligament is the strongest of these ligaments and is a thick, triangular band of tissue originating from the medial malleolus. The lateral ligament complex consists of the lateral malleolus that attaches to the anterior and posterior aspects of the talus and calcaneus by the anterior talofibular, posterior talofibular, and calcaneofibular ligaments, respectively. This ligament complex, weaker than the deltoid and prone to inversion injuries, is commonly injured and
 represents 85% of all ankle sprains. The syndesmosis, which holds the tibia and fibula together, yet allows the fibula to rotate, is a group of four distinct ligaments attaching the distal tibia to the fibula just above the talus (Figure 276­1). While the fibula has no direct contact to the weight­bearing
 portion of the talus, the syndesmosis transmits about 16% of the axial load to the fibula.
FIGURE 276­1. Ligaments of the ankle joint. A. The three lateral ligaments: the anterior and posterior talofibular ligaments and the calcaneofibular ligament. B. The four bands of the deltoid ligament: the anterior and posterior tibiotalar, the tibiocalcaneal, and the tibionavicular. C. Anterior and posterior view of the ankle syndesmosis. The ligaments of the syndesmosis are the anterior inferior tibiofibular ligament, the posterior inferior tibiofibular ligament, the transverse ligament, and the interosseous ligament, which connects the entire length of the tibia and fibula.

Chapter 276: Ankle Injuries, Talib Omer; Margarita Santiago­Martinez 
. Terms of Use * Privacy Policy * Notice * Accessibility

The ankle is considered a hinged joint, but ligamentous attachments allow for some rotation and translation within the mortise of the talar dome.
Branches of the sciatic nerve, the superficial peroneal, deep peroneal, peroneal, and tibial, innervate the four muscle groups of the ankle joint with branches of the popliteal artery serving as the blood supply (Figure 276­2). The tibialis anterior, extensor digitorum longus, and extensor hallucis longus muscles run over the anterior aspect of the joint and are responsible for dorsiflexion. Inversion is accomplished by the tibialis posterior, flexor digitorum longus, and flexor hallucis longus. The peroneus longus and brevis muscles, sharing a common synovial sheath held in place by a groove on the posterior aspect of the lateral malleolus and superior retinaculum, run laterally to evert and plantarflex the joint. Plantarflexion is primarily accomplished by the gastrocnemius and soleus muscles.
FIGURE 276­2. Neurovascular anatomy of ankle.
CLINICAL FEATURES
HISTORY
Understanding the mechanism and timing of the injury is important. Document these details along with any previous bony or soft tissue injuries.
Patients with signs of neurovascular compromise, including coldness and numbness of the foot, a rapid onset of swelling, extreme pain, and
 complicating conditions such as diabetes, require urgent evaluation. A normal­appearing ankle does not preclude the need for further inquiry. Due to the significant swelling that typically presents after acute injuries, examining the ankle is challenging but can be helped by elevation of the injured
 extremity and ice applied at triage. Peroneal spasms may mask any instability in the joint.
PHYSICAL EXAMINATION
Place the patient on a stretcher to perform a thorough evaluation. A systematic approach to the examination decreases the chance of missed injuries.
Starting with the skin and soft tissues, note any ecchymosis, abrasions, or swelling. Note the position, swelling, and skin integrity of the joint as well as any areas of tenderness or crepitus. Joints above and below the ankle need to be examined for any concomitant injuries. Suspect a Maisonneuve fracture (or fibulotibialis ligament tear) if there is tenderness of the fibular head or proximal fibular shaft. Palpate the area of obvious injury last. Test the functionality of the joint with both active and passive plantarflexion, dorsiflexion, and full range­of­motion exercises. Peroneal tendon injuries
 can occur from forced dorsiflexion, which presents as weakness on eversion (Figure 276­3). Check stability in external rotation, varus, and valgus.
Palpate the posterior aspects of the lateral and medial malleoli, starting proximally to the joint and working distally. If there is a concern for isolated
 fibular fractures, check for evidence of injury to the syndesmosis or deltoid ligament.
FIGURE 276­3. Peroneal tendon of the foot, lateral view.
Functional testing of the joint can reveal significant injuries. A positive anterior drawer test (Figure 276­4) is indicative of a torn anterior talofibular ligament. To perform the test, have the patient sit with the ankle in  to  degrees of plantar flexion, cup the heel in one hand, and provide countertraction to the tibia with the other hand while attempting to draw the heel forward. Increased subluxation of  mm or more compared to the
 uninjured side or visible dimpling of the anterior skin of the affected ankle indicates a significant anterior talofibular ligament injury. A positive anterior drawer test, swelling, and a hematoma are signs of a grade III sprain. Syndesmosis injuries can be deceiving because the patient describes ankle pain, but there is typically little ankle edema or ecchymosis. The crossed­leg test (compressing the fibula toward the tibia just above the
 midpoint of the calf ) can detect a syndesmosis injury and is indicated if pressure to the medial aspect of the knee elicits pain in the syndesmosis
(Figure 276­5). The squeeze test is performed by squeezing the calf just above the ankle joint. Pain indicates syndesmosis injury. Calcaneofibular
 ligament instability can be detected with the inversion stress test or talar tilt. If the examination is uncomfortable for the patient, consider a hematoma block, sedation, or both to perform a more thorough examination.
FIGURE 276­4. Technique for performing the anterior drawer stress test of the ankle. [Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ:
Emergency Orthopedics, The Extremities, 5th ed. © 2007, McGraw­Hill Inc., New York.]
FIGURE 276­5. The crossed­leg test. The affected leg is crossed over the opposite leg as demonstrated. If pain results at the arrow sites when pressure is applied to the medial side of the affected knee, the test is positive and indicates syndesmosis injury. [Copyright © 2010 by the American Orthopaedic Foot and
Ankle Society, Inc., originally published in Foot & Ankle International in Kiter E, Bozkurt M: The crossed­leg test for examination of ankle syndemosis injuries. Foot Ankle Int 2: 187, 2005, and reproduced here with permission.]
Examine areas in close proximity to the ankle as well. What may be described as an ankle injury may end up being an injury to the Achilles tendon or foot and cannot be excluded by ankle radiographic imaging. Assess the integrity of the Achilles tendon. Fluoroquinolones and corticosteroids
 increase the risk of such an Achilles tendon injury. Palpate the hindfoot and midfoot over the calcaneus, tarsals, and base of the fifth metatarsal to check for areas of tenderness that may require further investigation.
Perform a neurovascular examination. Check dorsalis pedis and posterior tibial pulses and document digital capillary refill. Inability to dorsiflex the toes suggests a tibial nerve injury. Inability to plantarflex the great toe is suspicious for peroneal nerve injury.
If there are any significantly displaced fractures or dislocations, immobilize the joint in a neutral position with a well­padded splint to reduce further soft tissue injury. Follow this with elevation and application of ice to reduce edema. Emergently reduce any displaced fractures or dislocations with neurovascular compromise (see later treatment section under “Dislocations”).
DIAGNOSIS
IMAGING
9–13 
The Ottawa Ankle Rules for Ankle and Midfoot Injuries are easily applied by physicians and other healthcare providers and can rule out ankle
 fractures without the need for radiography with high accuracy. The rules are summarized in Figure 276­6.(See Video: Ottawa Ankle Rules).
FIGURE 276­6. Ottawa Ankle Rules for Ankle and Midfoot Injuries. Ankle radiographs are required only if there is any pain in the malleolar zone or midfoot zone along with bony tenderness in any of these four locations or the inability to bear weight both immediately and in the ED.
They were originally developed for patients older than age  years who were able to cooperate, were not intoxicated, and had no distracting injuries
,17 or decreased sensation. See Chapter 141, “Pediatric Orthopedic Emergencies” for detailed discussion of the rules in children. Assuming the patient does not have any bony tenderness, assess the ability to bear weight by having the patient take four steps, resulting in two transfers to and
 from the injured ankle. The initial studies demonstrated an approximately 30% reduction for the need of ankle radiographs.
The standard ankle trauma series consists of three views: anteroposterior, 15­degree internal oblique, and lateral views. See Figure 276­7 for normal
 anatomy. About 95% of all ankle fractures can be detected with any two of these views.
FIGURE 276­7. Normal ankle radiograph. A. Anteroposterior view. B. Lateral view. C. Oblique view. [Image used with permission of Robert DeMayo, MD.]
When there is an abnormal motion of the talus within the mortis, there is stress on the malleoli and ligaments, which causes the injury. Fractures above the talus and those that cause disruption of both sides of the joint have the potential to create an unstable injury. Instability of the joint is usually diagnosed based on plain radiographs because pain and swelling make it difficult to determine true stability of an acutely injured ankle. If radiographs are normal but there is concern about stability, weight­bearing ankle films can be helpful. Point­of­care ultrasound can detect Achilles tendon
  injuries and ankle fractures.
CT and MRI may play a role in better delineating pathology. Ideal imaging for a CT includes both axial and direct coronal images with sagittal reformations. To obtain these images, keep the ankle between neutral and  degrees of plantarflexion when possible, similar to that for plain radiographs. CT can be used for operative planning by orthopedic surgeons and to evaluate comminuted fractures and complex bony injuries like pilon fractures and malunions. MRI can help define soft tissue, muscle, ligamentous, and tendon injuries and is used more in the outpatient setting for
 subacute and chronic pain presentations.
TENDON INJURIES
CLINICAL FEATURES
A peroneal tendon subluxation and dislocation occurs when there is a sudden hyperdorsiflexion of the foot in a position of eversion, as in skiing.
The superior retinaculum, which holds the peroneal tendons in place, is torn from the posterolateral malleolus. This leads to a small avulsion fracture in more severe injuries with a dislocation or anterior subluxation of the peroneal tendon over the tip of the fibula. Consider this injury when there is ecchymosis or tenderness over the posterior edge of the lateral malleolus and no tenderness over the talofibular ligament.
Achilles tendon ruptures occur with sudden plantarflexion of the foot. A complete tendon rupture will become apparent with palpation of a defect over the Achilles tendon and is identified by the Thompson test (Figure 276­8). Perform the Thompson test if there is tenderness or a defect. Place the patient prone on the stretcher and squeeze the calf on the affected side. Loss of plantarflexion indicates a complete Achilles tendon rupture.
Ultrasound can also identify Achilles tendon ruptures (Figure 276­9).
FIGURE 276­8. Thompson test. There is no plantarflexion with squeezing the calf of the affected leg, or less plantarflexion compared with the normal leg. [Adapted with permission from Stone CK, Humphries RL. Current Diagnosis and Treatment Emergency Medicine, 7th ed. Copyright @ The McGraw Hill
Companies, 2011. Figure 28­20.]
FIGURE 276­9. Point­of­care ultrasound of Achilles tendon. A. Unaffected side. B. Ruptured Achilles tendon. [Used with permission of Talib Omer, MD, and Division of
Emergency Ultrasound at LAC+USC Medical Center.]
TREATMENT
The treatment for both types of tendon rupture is often operative repair, especially for those who wish to return to full activity.
LIGAMENT INJURIES
CLINICAL FEATURES
The most common type of ankle sprain is one to the lateral ankle. Typically, these are minor and are due to an inversion injury when the ankle is plantarflexed. Sprains are categorized into three grades. Grade I involves no tearing of the ligaments with minimal functional loss, pain, swelling, and ecchymosis. Weight bearing is tolerable. Grade II sprains occur with a partial tear and result in some loss of functional ability. These tend to be more painful, with swelling, ecchymosis, and difficulty bearing weight. Grade III sprains result from a complete tear, with significant functional loss, pain,
 swelling, bruising, and almost a universal inability to bear weight. However, joint stability is the primary determinant of a treatment plan for a sprain.
An isolated sprain of the medial deltoid ligament is rare. Medial deltoid ligament tears are usually associated with a fibular fracture or tear of the tibial­fibular syndesmosis from an eversion injury. If there is significant medial malleolus tenderness and swelling, suspect a Maisonneuve fracture of the proximal fibula and fibular shaft. Negative radiographs should suggest syndesmosis tears.
Injuries to the tibiofibular syndesmotic complex are associated with hyperdorsiflexion injuries when the talus moves superiorly and separates the tibia and fibula. This leads to a partial or complete tear of the syndesmosis with complaints of pain just above the talus.
If there is concern for an unstable ligamentous injury, weight­bearing views of the ankle can help diagnosis—an unstable ligamentous injury may demonstrate talar shift.
TREATMENT
The immediate goals are to decrease pain and swelling and protect ligaments from further injury. The PRICE protocol (protection, rest, ice, compression, elevation) involves elevating the ankle and protecting it with a compressive device along with applying ice and resting up to  hours to
 allow the ligaments to heal. There is controversy as to whether or not early immobilization versus functional treatment results in the best outcomes.

There is a trend toward favoring early functional treatment over immobilization. Patients returned to mobility anywhere between .6 and .1 days
 sooner with functional treatment when compared with immobilization. Functional treatment usually consists of three phases: (1) PRICE protocol within the first  hours of injury; (2) motion and strength exercises to begin within  to  hours; and (3) endurance training, focused toward specific
 sports when applicable, and training to improve balance after the second phase begins.
In patients with a lateral ligament sprain, a stable joint, and the ability to bear weight, treatment consists of analgesics, an elastic bandage or ankle brace, and no sports engagement, with follow­up in a week if no improvement. There is consensus among reviews that
 bracing is effective at preventing a recurrence of an ankle sprain. For patients who are unable to bear weight but have a stable joint, provide an ankle brace and crutches and have them follow up with either their primary care provider or orthopedic surgeon within  week for repeat evaluation. Given the trend for early immobilization, functional braces, such as semirigid (e.g., Aircast®) and soft, lace­up braces, are commonly used. There is no
  consensus as to which leads to a more favorable outcome, although early rehabilitation of low­grade ankle sprains results in a good outcome.
Another option is an inflatable cast boot (also called a walking fracture boot or Aircast boot) that molds to the foot with inflatable air bladders. This device can also be used for stable ankle fractures.
Treat medial ligament sprains with PRICE and early referral to an orthopedic surgeon given the risk for undetected underlying fractures. Consider early orthopedic referral for syndesmotic complex sprains given the expected prolonged recovery time.
Refer patients with an unstable joint to an orthopedic surgeon after placement of a posterior splint for stabilization. Establish contact with the orthopedic surgeon early because the timing of treatment and follow­up is ultimately at his or her discretion.
There is no consensus as to whether surgery versus conservative treatment results in more favorable outcomes. Cryotherapy with ice will help decrease pain and limit swelling and should be applied directly to the ankle or splint but not left on for >20 minutes at a time. Therapeutic
 ultrasonography is not helpful.
DISLOCATIONS
CLINICAL FEATURES
Most ankle dislocations are associated with a fracture and can occur in one of four planes. Posterior dislocations are the most common and occur with a backward force on the plantarflexed foot, usually resulting in rupture of the tibiofibular ligaments or a lateral malleolus fracture. The less common anterior dislocation results from a force on the dorsiflexed foot with an associated anterior tibial fracture. A lateral dislocation results in ligamentous disruption and fracture of one or both malleoli (Figure 276­10). An axial compression force can drive the talus upward with an associated fracture of the talar dome and disruption of the syndesmosis.
FIGURE 276­10. Open fracture with dislocation. A. Anteroposterior view. B. Lateral view. [Image used with permission of Robert DeMayo, MD.]
TREATMENT
There is a significant concern for neurovascular compromise. Check carefully for an open fracture in these instances. If the patient has intact pulses, dislocations associated with fractures should be reduced by an orthopedic surgeon. If vascular compromise is present, as evidenced by a dusky foot or absent pulses, or there is tenting of the skin, an immediate reduction by the emergency physician is warranted without any prereduction radiographs.
First provide appropriate sedation and analgesia before attempts at reduction. Grasp the heel and foot with both hands, and gently apply traction and rotation opposite to the direction of the mechanism of injury. Confirm pulses and distal perfusion, and then apply a splint and elevate the foot while waiting for orthopedic evaluation. Confirm and document distal perfusion again after splint application. Any dislocations that cannot be reduced using closed techniques will require open reduction.
MUSCULAR INJURIES
CLINICAL FEATURES
Strains are injuries to muscle or tendons not usually associated with a specific injury but due to repetitive stress and overuse. Common muscles and tendons involved include the extensor digitorum longus, extensor hallucis longus, peroneus brevis and longus, and anterior tibial tendon (Figure
276­11). Strains can be due to athletics or poorly fitting footwear. Contusions are usually caused by direct trauma from a projectile like a baseball or hockey puck. Fractures associated with contusions are rare and usually involve only the bony cortex.
FIGURE 276­11. Muscles of the ankle.
TREATMENT
For overuse injuries, analgesics, especially NSAIDs, will help, along with rest and cessation of the activities that are causing the strain. Targeted exercises may help in the recovery as well. Contusions are treated symptomatically with analgesia and ice.
FRACTURES
CLINICAL FEATURES
Radiographically, ankle fractures are described as unimalleolar, bimalleolar (Figure 276­12), and trimalleolar (Figure 276­13). A bimalleolar fracture is fracture of the lateral and medial malleoli; trimalleolar fracture additionally involves the posterior malleolus.
FIGURE 276­12. Bimalleolar fracture. A. Anteroposterior view. B. Lateral view. [Image used with permission of Robert DeMayo, MD.]
FIGURE 276­13. Trimalleolar fracture. A. Anteroposterior view. B. Lateral view. [Image used with permission of Robert DeMayo, MD.]
The ankle consists of a ring of bone and ligaments around the talus. The ring is composed of the tibia, tibiofibular ligament, fibula, lateral and medial
 ankle ligaments, and calcaneus. A single ring disruption is typically a stable injury. Injuries involving two or more components of the ring are unstable injuries and usually need surgical fixation.
The Danis­Weber and Lauge­Hansen schemes are used by orthopedic surgeons to classify ankle fractures and help determine surgical repair. The

Danis­Weber system classifies fracture patterns based on the level of the fracture of the fibula. The Lauge­Hansen system classifies fractures based on
 the position of the foot at the time of injury.
Critical aspects of the examination for ankle fractures are summarized in Table 276­1. TABLE 276­1
Associated and Occult Injuries of the Ankle
Injury Clinical Suspicion Confirmatory Test
Maisonneuve fracture Examine proximal fibula and shaft, tenderness to palpation; proximal fracture and Fibula radiograph syndesmosis tear indicate unstable fracture9
Peroneal tendon dislocation Palpable anterior tendon dislocation or subluxation Clinical examination
Usually identified in follow­up of ankle sprains
Osteochondral injuries Diffuse ankle swelling, passive plantarflexion Ankle mortise view/CT
Syndesmosis tear Significant ankle pain, positive squeeze test Widened mortise with weight bearing
Anterior calcaneal process Tenderness more inferoanterior than a typical ankle sprain Lateral ankle fracture radiograph/CT
Lateral talar process fracture Tenderness just distal to the tip of fibula Ankle mortise view/CT
Os trigonum Tenderness anterior to Achilles tendon Lateral ankle radiograph
TREATMENT
The goal is to restore the anatomic relationship of the ankle, maintain reduction during the healing, and mobilize the ankle early. Treat small fibular avulsion fractures as stable ankle sprains (see earlier section, “Ligament Injuries”) if they are minimally displaced (<3 mm in diameter) and there is no sign of medial ligament injury.
,30
Most other ankle fractures require immobilization by either cast alone or surgical repair and casting. Severe comminuted fractures are at risk for compartment syndrome, fat emboli, and poor healing. Urgent orthopedic consultation in the ED is necessary. Until definitive fracture treatment can be provided, apply a posterior splint and stirrup and keep the patient non–weight bearing (see Chapter 267, “Initial Evaluation and Management of
Orthopedic Injuries”). Provide analgesics, and remind the patient to elevate the leg and apply ice. Table 276­2 provides guidelines for orthopedic consultation and follow­up.
TABLE 276­2
Timing of Consultation
Immediate Consultation in ED Deferred Consultation* Within  Week
All open fractures Stable unimalleolar fractures Potentially unstable sprains
All fracture dislocations Unstable ligamentous injuries
All dislocations Acute peroneal dislocations
All trimalleolar fractures†
All bimalleolar fractures†
Unstable unimalleolar fractures†
Maisonneuve fractures†
*Implies that communication is established at time of diagnosis and specific time of consultation has been set.
†Consultation can be delayed in the ED in fractures without neurovascular compromise and appropriate splinting.
OPEN FRACTURES
The most important prognostic factor in open ankle fractures is the amount of energy involved in the injury and amount of soft tissue damage involved. Open fractures require rapid surgical management that involves aggressive debridement of nonviable tissue and either internal or external
  fixation. Administer empiric antibiotics, which decrease infection by 59%. The most commonly used antibiotic is IV cefazolin, but consider adding an aminoglycoside for contaminated wounds. Use clindamycin in patients with a penicillin allergy. Update the tetanus status of the patient as needed.
While waiting for the orthopedic surgeon, irrigate the wound with several liters of normal saline, then apply sterile gauze soaked in saline over the open wound, and secure it in place with a gauze roll. Do not use iodine solutions, as they are caustic to tissues. Splint the injury to stabilize it while obtaining radiographs and coordinating orthopedic care.
DISPOSITION AND FOLLOW­UP
To date, there is no established standard of care regarding the time of orthopedic consultation and follow­up. Whether an orthopedic surgeon sees the patient in the ED depends on the specialist resources available. Table 276­2 can serve as a general guideline for local practice standards and resources. Most severe fractures require orthopedic consultation in the ED.


