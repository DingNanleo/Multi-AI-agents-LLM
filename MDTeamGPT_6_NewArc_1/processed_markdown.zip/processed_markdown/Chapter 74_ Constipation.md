## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 74: Constipation
Shawn R. Wassmuth; Elizabeth C. Oehler
INTRODUCTION AND EPIDEMIOLOGY
1­4
Constipation is an extraordinarily common cause of patient morbidity. The incidence of constipation increases with age, with overall prevalence
 rates in North America from 12% to 19%. Constipation affects as many as 80% of critically ill patients and is directly associated with patient mortality in
 this population.
Physicians and patients define constipation differently. Physicians have traditionally defined constipation as fewer than three bowel movements per week. Patients commonly define constipation in terms of symptoms such as abdominal discomfort, bloating, straining during bowel movements, or the sensation of incomplete evacuation. Constipation should not be defined simply by stool frequency alone, because doing so can lead to
 underdiagnosis for a significant number of patients who suffer from the condition. The Rome criteria for the definition of constipation consist of two or more of the following signs or symptoms: (1) straining at defecation at least 25% of the time, (2) hard stools at least 25% of the time, (3) incomplete evacuation at least 25% of the time, (4) fewer than three bowel movements per week, and (5) rarely having loose stools without the use of laxatives and
 having symptoms for at least  months in the preceding  months for chronic constipation.
PATHOPHYSIOLOGY
Constipation is a complicated condition with multiple, often overlapping causes (Table 74­1). Gut motility is affected by diet, activity level, anatomic lesions, neurologic conditions, medications, toxins, hormone levels, rheumatologic conditions, microorganisms, and psychiatric conditions.
Constipation is best thought of as either acute or chronic, as doing so helps formulate a differential diagnosis (Table 74­1). Acute constipation should primarily prompt evaluation for intestinal obstruction, and history and physical examination can identify other causes. Chronic constipation can be caused by many of the same conditions that cause acute constipation (Table 74­1).
TABLE 74­1
Differential Diagnosis of Constipation
Acute causes
GI: bowel obstruction, quickly growing tumors, strictures, hernias, adhesions, inflammatory conditions, and volvulus
Medicinal: narcotic analgesic, antipsychotic, anticholinergic, antacid, antihistamine
Exercise and nutrition: decrease in level of exercise, fiber intake, fluid intake
Painful anal pathology: anal fissure, hemorrhoids, anorectal abscesses, proctitis
Chronic causes
Gastrointestinal: slowly growing tumor, colonic dysmotility, chronic anal pathology
Medicinal: chronic laxative abuse, narcotic analgesic, antipsychotic, anticholinergic, antacid, antihistamine
Neurologic: neuropathies, Parkinson’s disease, cerebral palsy, paraplegia
Endocrine: hypothyroidism, hyperparathyroidism, diabetes
Electrolyte abnormalities: hypomagnesemia, hypercalcemia, hypokalemia
Rheumatologic: amyloidosis, scleroderma
Toxicologic: lead, iron, chronic opioid use

Chapter 74: Constipation, Shawn R. Wassmuth; Elizabeth C. Oehler 
. Terms of Use * Privacy Policy * Notice * Accessibility
CLINICAL FEATURES
HISTORY
The differential diagnosis of constipation is broad, so obtain a thorough history. Determine when the symptoms started and if there are any temporally related clues that can help narrow the differential diagnosis. Was a new medication or dietary supplement added at that time? Was there a decrease in fiber or fluid intake? Was there a change in activity level? Past medical and family history can help shed light on the cause of the constipation. Is there a history of hypothyroidism or diabetes? Identify past abdominal surgical procedures. Does the patient have frequent kidney stones, which might point to hyperparathyroidism? Although most patients who present with constipation do not have emergent conditions and may be treated symptomatically as outpatients, there are several historical elements that hint to a more ominous cause of symptoms, such as intestinal obstruction. Worrisome findings, in addition to constipation, include rapid onset, nausea or vomiting, inability to pass flatus, severe abdominal pain and distention,
 unexplained weight loss, rectal bleeding, unexplained iron deficiency anemia, or a family history of colon cancer. Consider ovarian carcinoma in women with new concerning symptoms of obstruction or bloating. Any of these findings should prompt a more rigorous evaluation. Diarrhea does not rule out constipation/obstruction, as liquid stool can move past an obstructive source.
PHYSICAL EXAMINATION
Focused abdominal, pelvic, and rectal examinations are essential. Examine the patient for the presence of hernias and abdominal or pelvic masses.
Bowel sounds will be decreased in cases of slow gut transit and increased in cases of obstruction. Ascites in the presence of constipation can be a sign of ovarian or uterine neoplasm in women. External rectal examination may demonstrate anal fissures, hemorrhoids, abscesses, or protruding masses.
Digital rectal examination may demonstrate fecal impaction or an obstructing rectal mass. Watery stool making its way around a fecal impaction is common in elderly patients. Normal rectal tone is useful in ruling out neurologic causes of obstruction. Stool retrieved from the rectal vault should be visually inspected and tested for occult blood. The finding of grossly bloody or guaiac­positive stool in the setting of constipation raises concern for cancer, bowel ischemia, stercoral ulcer, or inflammatory bowel disease.
LABORATORY EVALUATION AND IMAGING
The evaluation of a constipated patient depends on the level of concern for organic causes. If the patient is chronically constipated, little is usually gained from any testing if the history and physical examination do not point toward a new organic cause. If the patient has a history concerning for intestinal obstruction (e.g., acute onset of symptoms, vomiting, significant abdominal distention or pain), abdominal flat and erect films (or left lateral decubitus films if the patient cannot stand) are useful. In cases of complete or partial intestinal obstruction, these films may demonstrate air­fluid levels or dilated bowel. If there continues to be high clinical suspicion for intestinal obstruction despite a normal chest and abdominal series of radiographs, then abdominal CT with PO and IV contrast may be necessary to make the diagnosis. In cases of suspected fecal impaction, an abdominal film should be obtained (Figure 74­1). In a constipated patient, such a film will demonstrate colonic or rectal dilation with or without air­fluid levels.

Normal maximum diameter of the colon is  cm, whereas normal maximum diameter of the rectum is  cm. In all patients in whom an organic cause of constipation is suspected, laboratory evaluation should include a CBC to screen for anemia, and electrolytes to evaluate for hypomagnesemia, hypercalcemia, and hypokalemia. Obtain thyroid function tests for suspected hypothyroidism. Obtain serum lead and iron levels for suspected heavy metal toxicity.
FIGURE 74­1. Large bowel obstruction due to fecal impaction (F). [Reused with permission from Schwartz DT (ed): Emergency Radiology: Case Studies. © McGraw­
Hill, Inc., 2008. Chapter II­2, Fig. .]
SPECIAL CONSIDERATIONS
FUNCTIONAL CONSTIPATION
The treatment of chronic (functional) constipation is best managed using a multidisciplinary approach. Unfortunately, there is no simple medication fix for this common problem. Emergency medicine providers are encouraged to stress lifestyle and diet modification. A strict dietary and exercise
 regimen is important, because without adequate fluid (1.5 L per day), fiber (10 grams per day), and exercise, medicinal treatments usually fail. The bulking agent psyllium can improve bowel movement frequency in adults with chronic constipation. Osmotic laxatives such as polyethylene glycol and
 lactulose have been shown in randomized controlled trials to be effective at improving stool frequency in patients. Newer prescription drugs that stimulate GO motility via the serotonin  receptor (prokinetics), as well as agents that directly stimulate intestinal secretion to increase stool water
 content (colonic secretagogues), are being marketed.
Medications often employed in the treatment of constipation are listed in Table 74­2. Although some evidence supports polyethylene glycol as a first­
 line agent in children, the literature does not clearly demonstrate the superiority of any one laxative for use in pediatric patients. Also, there is no gold standard management of constipation in palliative care and no evidence to support the use of one laxative, or combinations of laxatives, over
 another. There has been some promise recently with the use of subcutaneous methylnaltrexone and oral naloxegol in multiple studies of patients
13­18 with opioid­induced constipation. The effectiveness of rectal irrigation for functional bowel disorders has not been clearly demonstrated in
 prospective trials. Nevertheless, the procedure is felt to be safe and will benefit some patients. In its extreme form, functional constipation can result
,20 in a variety of potentially life­threatening complications, especially fecal impaction and intestinal pseudo­obstruction (Ogilvie’s syndrome ).
TABLE 74­2
Medical Adjuncts for the Treatment of Constipation
Trade
Type Generic Name PRN Doses Side Effects Mechanism
Name
Fiber Psyllium Metamucil®  teaspoon three times a Bloating, flatulence Increases stool bulk or day transit time
Emollient Docusate Colace® 100 milligrams Cramping Facilitates mixture of stool sodium daily/twice a day fat and water
Stimulants Bisacodyl Dulcolax®  milligrams PR three Incontinence, rectal burning Stimulates the myenteric
Anthraquinones Peri­ times a day Melanosis coli, degeneration of plexus, thereby increasing
Senna Colace® One to two tablets PO myenteric plexus intestinal motility
Senokot®, daily/twice a day Laxative abuse, nausea,
Ex­lax® Two tablets PO melanosis coli, cramping daily/twice a day or 15–
 mL daily/twice a day
Saline laxative Magnesium Milk of 15–30 mL daily/twice a Magnesium toxicity, especially May decrease colonic transit magnesia day in renal insufficiency time; osmotic laxative
Magnesium 100–240 mL daily/twice a Cramping, flatulence, citrate day hypermagnesemia
Suppository Glycerin NA  PR daily Rectal irritation Local rectal stimulation suppository
Hyperosmolar agents Lactulose NA 15–30 mL daily/twice a Cramps, flatulence, belching, Osmotically active
Sorbitol NA day nausea nonabsorbable sugars pull
Polyethylene GoLYTELY® 15–30 mL daily/twice a Cramps, flatulence fluid into the gut glycol MiraLAX® day Nausea, cramping, anal
 gallon/4 h irritation
 grams daily, onset of effect 1–3 days
Enemas Mineral oil NA 100–250 mL PR Local trauma Colonic distention
Tap water NA 500 mL PR Local trauma encourages evacuation
Soap suds NA 1500 mL PR Local trauma
Monophosphate Fleets®  unit PR Local trauma, hyperphosphatemia
(especially in patients with renal failure)
Serotonergic agents Prucalopride Resolor®  mg daily Nausea, diarrhea Stimulates GI motility
Prosecretory agents Lubiprostone Amitiza®  micrograms twice a Nausea, diarrhea Stimulates the movement of day ions and water into the lumen
Peripherally acting mu­ Naloxegol Movantik®  milligrams daily Abdominal pain Mu­opioid receptor opioid receptor antagonist antagonists
Abbreviations: NA = not applicable; PRN = as needed.
OPIOID­INDUCED BOWEL DYSFUNCTION
,17
Opioid­induced bowel dysfunction is a common complication of long­term opioid therapy, which affects 40% to 80% of patients. Novel treatments for opioid­induced constipation, such as purely peripherally acting mu­opioid receptor antagonists, work to decrease the constipating effects of
,21,22 opioids without reversing their central analgesic effects. These medications can be useful when conventional laxative treatments are ineffective.
FECAL IMPACTION
Physician resistance to manual disimpaction does the patient a disservice, as enemas provide little or no relief. Diarrhea does not rule out fecal impaction, especially in the elderly or debilitated patient. Failure to perform a rectal examination will result in misdiagnosis. Manual disimpaction is a painful procedure that often requires sedation. A novel instrument invented by an emergency physician termed The DisImpactor® is a U.S. Food and
Drug Administration–registered disposable medical device that is being retailed that claims that with its use, uncomfortable digital disimpaction can be avoided. After disimpaction, prescribe a regimen of medications and medical adjuncts to properly reestablish fecal flow.
INTESTINAL PSEUDO­OBSTRUCTION (OGILVIE’S SYNDROME)
Ogilvie’s syndrome, or acute colonic pseudo­obstruction, is a clinical disorder with the signs, symptoms, and radiographic appearance of an acute large bowel obstruction with no evidence of distal colonic obstruction. The colon may become massively dilated (>10 cm). If the bowel is not
,20 decompressed the patient risks perforation, peritonitis, and death. The exact mechanism is not known, but is thought to be secondary to a dysregulation of colonic motor activity by the autonomic nervous system. Predisposing factors include recent surgery, underlying neurologic
 disorders, and critical illness. Treatment is varied and determined with surgical consultation. The symptoms may resolve with conservative management but may require operative or colonoscopic decompression of the dilated intestine.
ORGANIC CONSTIPATION
Symptoms suggestive of organic constipation are acute onset, weight loss, rectal bleeding/melena, nausea/vomiting, fever, rectal pain, and change in
 stool caliber. Intestinal obstruction or carcinoma is the primary consideration. If fecal impaction is the cause, manual disimpaction is the treatment.
DISPOSITION AND FOLLOW­UP

Many constipated patients can be safely discharged from the ED with the caveat that certain key aspects have been adequately addressed (Table 74­
3). Fecal impaction requires disimpaction before discharge. Patients with organic constipation of a nonobstructive cause also can be managed safely as outpatients. The primary care provider should be contacted to ensure follow­up and to communicate concern for an organic process.
TABLE 74­3
Key Aspects to Address Before Discharging a Constipated Patient
Possible obstructing lesion
Systemic illness
Medication interaction/effect
Electrolyte imbalance
Potential for intestinal perforation with self­administered enemas
Referral to a gastroenterologist is warranted for patients with nonorganic constipation of recent onset; chronic constipation associated with weight
,26 loss, anemia, or change in stool caliber; refractory constipation; and constipation requiring chronic laxative use. Patients with organic constipation of obstructive origin require hospitalization, gastric decompression, and surgical consultation.
Acknowledgments
The authors thank Vito Rocco and Arash Armin, who were coauthors of the chapter in the previous edition.


