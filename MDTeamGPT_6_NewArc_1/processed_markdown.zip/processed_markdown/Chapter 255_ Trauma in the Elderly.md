## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 255: Trauma in the Elderly
Ross J. Fleischman; O. John Ma
INTRODUCTION AND EPIDEMIOLOGY
The elderly have worse outcomes following trauma because of physiologic changes that occur with aging. They are more susceptible to serious injury from low­energy mechanisms, less able to compensate from the stress of injury, and more likely to suffer complications during treatment and recovery. Emergency physicians should have a higher suspicion for injury and lower threshold for diagnostic testing and admission than in younger patients.

While studies most commonly define geriatric trauma by an age of  or older, some have shown mortality to increase by as young as  years of age.
The U.S. Census Bureau projects that those ≥65 years old will increase from 15% of the population in 2014 to 21% by 2030.  These older patients
 consume trauma resources at a greater rate than younger patients.
PATHOPHYSIOLOGY
The difficulty in describing the elderly population derives from the discrepancy between chronologic and physiologic age. Chronologic age is the actual number of years the individual has lived, whereas physiologic age describes the functional capacity of the patient’s organ systems. Studies have shown a clear association between age and mortality. Comorbid diseases have been shown to be associated with increased mortality after minor and
 moderate injuries in all age groups.
The physiologic changes of aging complicate recovery from injury and make assessment of injury more difficult. With age, myocytes
 are lost and replaced by collagen. Contractility and compliance decrease for any given preload. An 80­year­old person will have approximately 50% of the cardiac output of a 20­year­old, even without significant coronary artery disease. Maximal heart rate and cardiac output decrease with age. Aging myocardium has a decreased chronotropic response to catecholamines and is dependent on preload (intravascular volume). Hypovolemia can easily result in shock. Deterioration of the cardiac conduction system leads to atrial fibrillation and bundle branch blocks. Medications, especially digoxin, β­ blockers, and calcium channel blockers, impair the tachycardic response to catecholamines, both impairing the body’s inability to compensate for hemorrhage and making heart rate an unreliable predictor of hypovolemia.
Chest wall compliance, respiratory muscle strength, and the capacity for oxygen exchange all decrease with age. The response to hypoxia may decline
 by 50% and that to hypercarbia by 40%, such that the patient may not appear to be in respiratory distress despite impending respiratory failure.
Because of weakened respiratory muscles and degenerative changes in the chest wall, maximum inspiratory and expiratory force may be decreased by up to 50% compared with younger patients. Age­related reductions in vital capacity, functional residual capacity, and forced expiratory volume can limit older patients’ ability to compensate for chest injuries.
Renal function declines with age and predisposes patients to dehydration, requiring medication dose adjustments and making them susceptible to acute kidney injury.
This state of decreased physiologic reserve and resistance to stressors, now formally referred to as “frailty,” is being increasingly recognized.
Instruments for assessing frailty go beyond counting medical comorbidities and may include assessments of mobility, activity level, cognition, and independence with activities of daily living. In one study, a validated frailty scoring system outperformed age, vital signs, and injury severity score in
 predicting adverse outcomes.
COMMON MECHANISMS OF INJURY

Falls
Chapter 255: Trauma in the Elderly, Ross J. Fleischman; O. John Ma 
. Terms of Use * Privacy Policy * Notice * Accessibility
Falls are the most common cause of fatal and nonfatal injury in people ≥65 years of age. ,9 One third of older adults fall annually, with the rate increasing with age. Hip fractures are the most common fracture in elders hospitalized for injury, but the overall incidence of nonhip, nonspine
,11 fractures in women >55 years old is five times greater than hip fractures. There are age­related changes in postural stability, balance, motor strength, coordination, and reaction time that make the elderly more prone to falling. Other causes of falls in the elderly are listed in Table 255­1. Bathroom falls are concerning because hard surfaces can result in head and spinal injuries, and slippery surfaces can cause falls. Falls on stairs involve higher energy and potential for injury than those on flat ground. Falls in which an individual is unable to get help for a prolonged period should prompt investigation for rhabdomyolysis and dehydration with a check of the creatinine kinase and electrolytes.
TABLE 255­1
Common Causes of Falls in the Elderly
Associated with syncope/loss of consciousness
Dysrhythmias
Seizures
Acute coronary syndrome
Hypoglycemia
Pulmonary embolism
Associated with near­syncope, positional change, vasodilation (e.g., hot water)
Antihypertensive medications (especially β­blockers, calcium channel blockers)
Dehydration, diuretic medications
Hemorrhage (GI bleed, abdominal aortic aneurysm)
Hot bath or shower
Sepsis
Anemia
Nonsyncopal, “mechanical” causes
Deconditioning
Decreased visual acuity
Unsafe home conditions (e.g., poor lighting, loose rugs)
Alcohol
Sedating medications (narcotics, benzodiazepines, antihistamines, sleep aids)
Neurologic disease (cerebrovascular attack, Parkinson’s disease)
Motor Vehicle Crashes
Motor vehicle crashes are the second most common cause of injury in the elderly and are the leading cause of death, with a case fatality rate twice that
  of those under  years. The elderly make up 17% of U.S. traffic fatalities.
Pedestrian–Motor Vehicle Collisions
The elderly are second only to children as victims of pedestrian–motor vehicle collisions. Those ≥65 years old account for 19% of pedestrian– automobile fatalities in the United States. Pedestrian–motor vehicle collisions are one of the most lethal mechanisms of injury in this age group, with a
53% case fatality rate.
Burns

Burns are the second leading cause of traumatic death in the home in older adults. There is a direct relationship between age and burn mortality, as
 evidenced by the traditionally taught mortality­predicting Baux score.
Elder Abuse
Maintain a high suspicion for intentional injuries and injuries caused by neglect. Warning signs include poor hygiene, untreated decubitus ulcers, injuries not explained by the reported mechanism, and subacute injuries in various stages of healing.
CLINICAL FEATURES
HISTORY
Treat injured elders as both trauma and medical patients. Ask the patient, family, and prehospital care providers about the exact events leading up to the injury. Avoid skipping the review of systems, past medical history, and medications list. Investigating the cause of a fall may uncover serious underlying medical causes or prevent future trauma.
PRIMARY SURVEY
Avoid feeling reassured by “normal” vital signs. A tachycardic response to pain, hypovolemia, or anxiety may be absent in the elderly trauma patient. Medications such as β­blockers may mask tachycardia and hinder evaluation. One study demonstrated that eight of  geriatric blunt trauma patients initially considered to be hemodynamically “stable” had cardiac outputs <3.5 L/min, and none had an adequate response to volume loading.

Of seven patients with normal cardiac outputs, five had inadequate oxygen delivery. Another study reported that 39% of patients with a systolic blood
 pressure >90 mm Hg and heart rate <120 beats/min had occult hypoperfusion, defined by lactate >2.2 or base deficit less than –2. The elderly also have blunted responses to hypoxia, hypercarbia, and acidosis, which can mask the signs of respiratory failure.
Blood pressures are also misleading in the elderly patient. Because the incidence of underlying hypertension approaches 90%, use a higher cutoff for hypotension than in younger patients. In blunt trauma patients ≥65 years old, there is an association between hypotension and mortality starting with systolic blood pressures <110 mm Hg and heart rates >90 beats/min. Therefore, it is reasonable to use these more
 conservative cutoffs as markers of abnormal vital signs. A decrease in blood pressure of  mm Hg below a known baseline or a falling trend is also a marker of instability.
Be highly concerned about the elderly patient with abnormal vital signs. One study found that patients with a respiratory rate <10 breaths/min had

100% mortality. Likewise, a systolic blood pressure <90 mm Hg in the blunt trauma patient has been associated with a mortality between 82% and

100%.
Anatomic variations may complicate airway management. These include the presence of dentures (which may occlude the airway and make laryngoscopy more difficult), cervical arthritis (which adds danger to extending the neck), or temporomandibular joint arthritis (which may limit mouth opening).
SECONDARY SURVEY
A thorough secondary survey is essential to uncover less serious injuries. Patients with no apparent life­threatening injuries can have potentially fatal injuries if there is some degree of limited physiologic reserve. Seemingly stable geriatric trauma patients can deteriorate rapidly and without warning. Undertake a medication review early in the patient’s evaluation, paying particular attention to medications that affect heart rate, blood pressure, and coagulation.
DIAGNOSIS
HEAD INJURY

Head injuries in the elderly cause almost 142,000 U.S. ED visits resulting in discharge, ,000 survivable hospitalizations, and ,000 deaths annually.
Age is an independent predictor for morbidity and mortality in patients with moderate or severe head trauma. When evaluating the patient’s mental status, it would be a grave error to assume that alterations in mental status are due solely to dementia.
Elders are less prone to develop epidural hematomas than the general population because of the denser fibrous bond between the dura mater and the inner table of the skull. There is, however, a higher incidence of subdural and intraparenchymal hematomas in the elderly than in younger patients. As the brain mass decreases with age, there is greater stretching and tension of the bridging veins that pass from the brain to the dural sinuses. Bridging veins are more susceptible to traumatic tears. Diagnosis of intracranial bleeding may be delayed because brain atrophy increases intracranial free space, allowing blood to accumulate without initial signs or symptoms.
One study of blunt head trauma patients taking warfarin who were experiencing no or minimal symptoms found a rate of injury on head CT that
 changed disposition in 7%. Therefore, immediate noncontrast head CT is recommended for patients who take warfarin or clopidogrel
 and have a minor head injury mechanism, even if asymptomatic. Check the INR, because the degree of anticoagulation correlates with the
 risk of adverse outcomes. The limited data on dabigatran suggest a risk similar to warfarin, so have a similarly low threshold for CT scan of patients
,25 ,27 on direct­acting oral anticoagulants. There is insufficient evidence to delineate the risk conferred by aspirin or low­molecular­weight heparins.
CERVICAL SPINAL INJURIES
The incidence of cervical spine injury is about twice as great in elders as in a younger cohort of blunt trauma patients. Odontoid fractures are
 particularly common in geriatric patients, accounting for 20% of geriatric cervical spine fractures, as compared with 5% of nongeriatric fractures.
Preexisting cervical spine pathology, such as osteoarthritis, bulging discs, and osteoporosis, may predispose elderly patients to spinal cord injuries.
With hyperextension injuries, elderly patients may develop a central cord syndrome, which causes motor deficits in the upper extremities more often than the lower extremities, variable sensory loss, and bladder dysfunction. The Canadian Cervical Spine Rule, but not the National
Emergency X­Radiography Utilization Study criteria, excludes patients age ≥65 years from being considered low risk for cervical spine injury. ,30
Thus, liberal imaging of the cervical spine in geriatric trauma patients is warranted. CT scan is the preferred initial modality for assessing the geriatric cervical spine because of the higher pretest probability of injury and the difficulties in interpreting plain radiographs in a patient with age­related degeneration. Many fractures in one section of the spine are accompanied by fractures in another section, so
 identification of one fracture should prompt imaging of the entire spinal column.
THORACOLUMBAR SPINAL INJURIES

Thoracic and lumbar spine fractures account for almost half of all osteoporotic fractures. They are most common at the thoracolumbar junction

(T12­L1) and midthoracic areas (T7­T8). Anterior wedge compression fractures are the most common. Because of the low sensitivity of plain films for
 identifying thoracolumbar fractures in trauma patients, CT scan is the first­line imaging modality for adult patients. This is even more significant in elders, in whom osteoporosis and degenerative changes make plain radiographs more difficult to interpret. See Chapter 258, “Spine Trauma,” for more information on specific fracture types and management.
CHEST TRAUMA
The elderly are more susceptible to chest injuries from blunt trauma and have a decreased ability to compensate for these injuries. Rib fractures in the elderly often lead to morbidity, pneumonia, and death. The adjusted odds of death in the elderly with rib fractures are about five times that of a younger cohort.  Rates of pneumonia and mortality in patients ≥65 years old are twice that of younger patients, with most studies showing a
,37 correlation between the number of rib fractures and the risk of death. Because of the complications associated with rib fractures in elders, a CT may be necessary to assess the extent of injuries that might not be seen on plain radiographs.
ABDOMINAL TRAUMA
The abdominal examination in elderly patients is unreliable. The FAST examination is an ideal imaging study to detect large volumes of free intraperitoneal fluid. Even with an initially benign physical examination, maintain a high suspicion for intra­abdominal injuries in patients with associated pelvic and lower rib cage fractures. As in younger patients, many solid organ injuries can be managed nonoperatively. Rates of successful
 nonoperative management of splenic injuries in elderly patients range from 62% to 85%. Therefore, CT with contrast is a crucial diagnostic test for evaluating the extent of injury and ongoing hemorrhage. The risk of acute kidney injury following injury increases with age, hypovolemia, diuretic and nephrotoxic medications, diabetes, and preexisting renal disease; however, recent studies have questioned the strength of the association between
 low and iso­osmolar contrast given at the doses used for CT and acute kidney injury (contrast­induced nephropathy). The risk can be reduced by volume expansion with isotonic crystalloids. Oral N­acetylcysteine does not appear to prevent contrast­induced nephropathy in patients
 undergoing coronary angiography. Other strategies, including sodium bicarbonate, ascorbic acid, and low versus iso­osmolar contrast, have had
41­45 mixed results in studies.
ORTHOPEDIC INJURIES
Pelvic Fractures
While pelvic fractures in the young are generally caused by high­energy mechanisms, the elderly, especially women, frequently suffer pelvic fractures from low­energy falls to the ground from a standing or seated position. Pubic ramus fractures are the most common injuries, and lateral compression
 is the most common mechanism.
,48
CT of the pelvis should be ordered in stable patients with pelvic tenderness after an injury if plain radiographs are negative.
Plain radiography is especially insensitive for posterior fractures involving the sacrum and iliac wings, so tenderness of the posterior pelvis especially
  suggests the need for cross­sectional imaging. Plain radiography may be omitted in stable patients who will be going promptly to CT. Even CT may be only 77% sensitive for pelvic fractures in the elderly, particularly with nondisplaced posterior fractures in osteoporotic bone. Therefore, consider

MRI for patients with pelvic pain or pain on weight bearing with negative CT imaging.

Studies have been contradictory on whether age is an important predictor of the need for angiographic assessment for bleeding in pelvic fractures.
One study found that 94% of patients  years of age and older taken to angiography required embolization, which is significantly higher than the rate
 of 52% in younger patients. Therefore, these authors advocate liberal use of angiography in elderly patients with significant pelvic fractures, even in the absence of hemodynamic instability or need for transfusion. Other studies did not demonstrate an association between age and the need for
,55 angioembolization.
Hip Fractures
Hip fracture is the single most common injury diagnosis that leads to hospitalization in the elderly. Hip fractures are a significant cause of mortality,
 with about 25% of elderly patients dying within a year of injury. The vast majority of hip fractures are caused by falls to the ground. The age­adjusted incidence of hip fractures in women is approximately twice that of men. Hip fractures in men occur at older ages than in women. Femoral neck

(intracapsular) and intertrochanteric fractures are about equally common, with subtrochanteric fractures comprising the remaining 5% to 10%.
Bleeding from closed pelvic and long­bone fractures can cause hypovolemia in elderly patients.
Obtain anteroposterior radiographs of the pelvis, as well as dedicated anteroposterior and lateral radiographs of the affected hip. Because plain radiographs are only 90% sensitive for hip fractures and delay in operative repair is associated with an increase in morbidity and mortality, normal
 plain radiographs should be followed by more definitive imaging in patients in whom suspicion of hip fracture persists. MRI has higher sensitivity than CT for detecting hip fractures, with one study finding that 17% of hip fractures that were occult on plain radiographs were seen
 by MRI but not CT. The sensitivity of CT is lower in patients with risk factors for osteoporosis (older age, female sex, chronic steroid use, alcoholism, inactivity, poor calcium intake, endocrine disorders) and a lower­energy mechanism of injury (ground­level falls), in which fractures are less likely to be
 displaced. If MRI is difficult to obtain, CT may yield a diagnosis, but should be followed by MRI if nondiagnostic. Consider admitting patients with hip fractures to a multidisciplinary team of geriatricians, orthopedists, and rehabilitation specialists.
Upper Extremity Injuries
,61
Distal radius fractures (Colles’ fractures) are the most common fractures in women up to age , with a lifetime risk of about 15%. Such fractures are often caused by a fall onto an outstretched hand and are associated with low bone mineral density or osteoporosis. Assess median nerve function before and after reduction, as a deficit will require immediate orthopedic consultation for possible nerve decompression. Unstable or displaced fractures require closed reduction with a hematoma block for anesthesia. A systematic review of unstable distal radius fractures in the elderly reported that functional outcomes were similar with nonoperative and operative management, even though nonoperative management was associated with a
 less satisfactory radiographic appearance. So while elderly patients with active lifestyles and good functional statuses may benefit from surgical treatment, many others will do as well with conservative treatment.
Fractures of the proximal humerus and humeral shaft are also common after falls from standing. Carefully assess for axillary nerve injury by checking sensation at the area of deltoid muscle insertion and deltoid muscle engagement with shoulder abduction. Note that the initial  degrees of shoulder abduction are generated by the supraspinatus muscle, so movement in this range may still be possible with an axillary nerve injury.
LABORATORY TESTING
Elderly trauma patients should receive more intensive laboratory evaluation than younger patients. This may be helpful to identify comorbid diseases
(e.g., creatinine for renal dysfunction) or acute causes of syncope (e.g., troponin for myocardial infarction) or to uncover occult physiologic insults
(e.g., lactate, INR, and base deficit). As discussed earlier, vital signs are an unreliable marker of shock in the elderly. Base deficit and lactate levels are useful initial indicators of shock, and serial measurements can guide resuscitation progress. Elevated lactate levels correlate with
,64 systemic hypoperfusion, intensive care unit and hospital length of stay, and mortality. A “normal” or mild base deficit of –3 to –5 correlates with
24% mortality, a moderate base deficit of –6 to –9 correlates with 60% mortality, and a severe base deficit of ≤–10 correlates with 80% mortality. 
Check creatine kinase levels to assess for rhabdomyolysis in patients who have fallen and been unable to receive assistance for a prolonged period.
TREATMENT
OUT­OF­HOSPITAL CONSIDERATIONS
EMS providers should recognize that seemingly minor trauma mechanisms, such as ground­level falls and low­speed motor vehicle crashes, may result in significant injury. For these reasons, the threshold for scene triage or transfer to a trauma center should be lower for elderly patients than for
 younger patients.
,68
Rates of prehospital undertriage are higher in older than in younger patients, with significant associated mortality. For the reasons discussed earlier, traditional triage criteria of physiology (e.g., heart rate and blood pressure), anatomic injury, and mechanism are unreliable in elderly patients.
Therefore, the 2011 U.S. Centers for Disease Control and Prevention National Expert Panel on Field Triage recommended a lower threshold for triage of injured elderly patients, giving three key recommendations: “Risk of injury/death increases after age  years. Systolic blood pressure <
110 mm Hg might represent shock after age  years. Low impact mechanisms (e.g. ground level falls) might result in severe
 injury.” While the guidelines emphasize that anticoagulated patients are at “high risk for rapid deterioration,” they stop short of making anticoagulation a criterion for triage to a trauma center. Although the Advanced Trauma Life Support guidelines also stop short of making age ≥55 years a mandatory criterion, they recommend transporting patients to a trauma center or hospital capable of evaluation of injuries and considering
 consulting medical control.
The elderly can rapidly develop tissue damage leading to decubitus ulcers. Consider padded backboards or vacuum splints for prolonged transports.
Patients with cervical kyphosis may need firm padding placed behind the head when in spinal immobilization in order to prevent forcing the spine into an abnormal position.
BLEEDING AND HEAD INJURY

The volume of intracranial blood and hematoma expansion are the most important determinants of morbidity and mortality in head injury. Rapidly reverse anticoagulation in patients taking warfarin or dabigatran with intracranial bleeding on CT scan. Despite a lack of definitive evidence, it is recommended to reverse other direct thrombin inhibitors and heparin. While studies on the effectiveness of platelet transfusion and desmopressin in patients with intracranial hemorrhage taking aspirin or clopidogrel have been mixed, one guideline recommends desmopressin, but would reserve
 platelet transfusion only for patients undergoing a neurosurgical procedure.
Admit patients with bleeding on head CT to an intensive care unit. The disposition of patients taking warfarin but with a normal initial CT scan is
,74 challenging because such patients have a reported rate of delayed intracranial hemorrhage between 1% and 8%. Admission for a repeat head CT at
 hours will catch most, but not all, delayed hemorrhages. Discharge after an initial negative head CT is also reasonable in patients with lower INRs and caregivers to watch them closely at home.
RIB FRACTURES AND RESPIRATORY FAILURE
Maintain a low threshold for admitting elderly patients with rib fractures for a period of observation until good pain control and pulmonary toilet are ensured. More severe thoracic injuries, such as hemopneumothorax, pulmonary contusion, flail chest, and cardiac contusion, can quickly lead to decompensation in the elderly, especially those with baseline respiratory insufficiency. Pain control after chest wall trauma is vital to encourage ventilation in order to reduce atelectasis and the risk of infection. Pain control is challenging because the elderly may have decreased tolerance for opioid analgesics, which can have profound respiratory (hypoventilation), hemodynamic (hypotension), and CNS effects
(imbalance and delirium).
Continuous pulse oximetry and capnometry are helpful to assess oxygenation and ventilation. Serial arterial blood gas analysis may provide early insight into respiratory function and reserve. Consider prompt tracheal intubation and use of mechanical ventilation in patients with more severe injuries, respiratory rates >40 breaths/min, or when the partial pressure of arterial oxygen is <60 mm Hg or the pressure of arterial carbon dioxide is
>50 mm Hg.
SHOCK
,17
Multiple studies have shown that occult hypoperfusion is frequently present even with normal vital signs. The optimal approach to optimizing hemodynamics is unknown. A general strategy is to perform the initial imaging necessary to identify life­threatening injuries (e.g., chest radiograph, CT of the head, spine, chest, abdomen, and pelvis) and then transport to the intensive care unit, after which nonessential imaging and interventions (e.g., extremity radiographs and suturing) can be performed.
Resuscitate the elderly trauma patient with small volumes of isotonic crystalloid (normal saline or lactated Ringer’s), watching for a response, to avoid underresuscitation or volume overload. Strong consideration should be made for early red blood cell transfusion, which may enhance oxygen delivery and minimize tissue ischemia. Depending on the type of injury and severity of blood loss, consider switching to blood transfusion after  to  L of
 crystalloid resuscitation. Routine use of pulmonary artery catheters is no longer recommended.
ENVIRONMENTAL AND IATROGENIC INJURY
The decreased lean muscle mass and impaired peripheral circulation associated with aging make the elderly patient more susceptible to pressure sores and hypothermia. Patients with prolonged extrications or transport in cool climates may be hypothermic. Expose the patient as needed for a thorough examination, but keep the patient covered as much as possible to maintain body heat. Hypothermia not explained by environmental factors may be a sign of sepsis or endocrine abnormalities. Logroll patients onto a padded surface as soon as possible.
DISPOSITION AND FOLLOW­UP
Have a low threshold for admitting geriatric trauma patients. Admit elderly patients with polytrauma, significant chest wall injuries, abnormal vital signs, or evidence of overt or occult hypoperfusion to the intensive care unit.
Even in patients without the need for inpatient treatment or observation, consider whether the patient is immediately ready to return home with a trial of ambulation and discussion of their home situation. In patients whose preinjury mobility was already tenuous, pain, decreased mobility, and medications may make a return to home dangerous. While opioid analgesics may be necessary, they may also cause delirium, decrease balance, and impair ambulation. Observation for establishment of a safe and effective pain regimen, consultation with physical therapy, and assurance of a safe home environment may be advisable to prevent a secondary injury.
OUTCOME
The ultimate goal is to return the elderly trauma patient to the preinjury state of function. Immediately after discharge, about half of survivors return
 home, and half go to skilled nursing or rehabilitation facilities. The general consensus is that elderly trauma patients benefit from preferential triage to trauma centers and from aggressive and thoughtful resuscitation. In light of investigations showing that elderly patients often return to preexisting health status after trauma, aggressive resuscitation efforts for geriatric trauma patients are warranted in keeping with their preexpressed end­of­life care preferences.


