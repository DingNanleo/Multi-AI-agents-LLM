## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 194: Beta­Blockers
Matthew K. Riddle; Christian Tomaszewski
INTRODUCTION
β­Adrenergic receptor antagonists (β­blockers) are medications used in the treatment of various cardiovascular, neurologic, endocrine, ophthalmologic, and psychiatric disorders. Among all drug­related fatalities reported to poison control centers nationwide in 2016, β­blockers were
 involved in 8% of all cases and were responsible for 2% of single­agent fatal exposures.
PHARMACOLOGY
The β­adrenergic receptors are membrane glycoproteins present as three subtypes in various tissues (Table 194­1). These receptors play a critical role in cardiovascular physiology by modulating cardiac activity and vascular tone.
TABLE 194­1
Location and Activity of β­Adrenergic Receptors
β­Receptor Type Location Agonism Antagonism
β Myocardium Increases inotropy Decreases inotropy

Increases chronotropy Decreases chronotropy
Kidney Stimulates renin release Inhibits renin release
Eye Stimulates aqueous humor production Inhibits aqueous humor production
β Bronchial smooth muscle Causes bronchodilation Causes bronchospasm

Visceral smooth muscle Relaxes uterus —
Causes ileus
Skeletal muscle Increases force of contraction —
Stimulates glycogenolysis
Liver Stimulates glycogenolysis and gluconeogenesis Inhibits glycogenolysis and gluconeogenesis
Vascular Vasodilation Minimal vasoconstriction
β Adipose tissue Stimulates lipolysis Inhibits lipolysis

Skeletal muscle Stimulates thermogenesis Inhibits thermogenesis

DCuhrainpgte tri m19e4s :o Bf esttare­sBsl o(ic.ek.e, rcsa, tMecahtothlaemw iKne. Rreidledalsee; )C, βh­raisdtriaenn eTrogmic aresczeepwtsokr istimulation increases myocardial and vascular smooth muscle ce P ll a a g c e t i  vi t / y 
. Terms of Use * Privacy Policy * Notice * Accessibility
,3 through a sequence of intracellular events (Figure 194­1).
FIGURE 194­1. 2+
Cardiac myocyte β ­receptor and calcium signaling. Following myocyte depolarization, extracellular calcium (Ca ) enters the cell via the L­type or

2+ voltage­gated calcium channel (L­VDCC) and binds to the ryanodine receptor (RyR) in the sarcoplasmic reticulum, causing an efflux of sequestered Ca
2+ out of the sarcoplasmic reticulum into the cytosol. Free Ca binds to troponin that allows the myosin and actin interaction, resulting in contraction of the cardiac myocyte. Binding of a β­agonist to the β ­adrenergic receptor (B1) on the cell surface activates the Gs protein. The Gs protein then activates
 adenylate cyclase (AC), which converts adenosine triphosphate (ATP) to cyclic adenosine monophosphate (cAMP). The increased cAMP activates protein kinase A (PKA). Activated PKA serves as further stimulus for the L­VDCC opening. Glucagon independently activates adenylate cyclase. cAMP is metabolized by phosphodiesterase (PDE) into inactive adenosine 5’­monophosphate (5’AMP).
The β­receptor is coupled to a stimulatory G protein. This G protein stimulates adenylate cyclase, which in turn catalyzes the formation of cyclic s s adenosine monophosphate (cAMP), the so­called intracellular second messenger. Increased cAMP ultimately phosphorylates the L­type calcium channel, which leads to channel opening and calcium entry into the cell. This increase in cytosolic calcium acts at the ryanodine receptor, a calcium channel on the sarcoplasmic reticulum, causing it to release its stored calcium into the cytosol. This process is termed calcium­induced calcium release. Stored calcium becomes available to participate in mechanical contraction via the actin and myosin complex. Like the cardiac myocyte, the vascular smooth muscle uses L­type calcium channels to regulate intracellular calcium and subsequently coordinate vascular tone. Phosphodiesterase breaks down cAMP to adenosine 5’­monophosphate, which removes the stimulus for calcium channel opening, and the contractile process ceases.
,3
The β­blockers modulate the activity of cardiac myocytes and vascular smooth muscle contraction by decreasing calcium entry into the cell.
Therapeutically, β­blockade lessens the work performed by diseased or injured myocardium and lowers elevated blood pressure. In toxicity, excessive

β­blockade may lead to bradycardia, decreased contractility, hypotension, and ultimately cardiogenic shock.
,5
The pharmacologic properties of various β­blockers influence their spectrum of action, adverse drug reactions, and toxicity (Table 194­2). These properties include receptor selectivity, sodium channel blockade (also known as membrane­stabilizing activity), lipid solubility, protein binding, and partial agonist activity (also known as intrinsic sympathomimetic activity). For example, highly lipid­soluble agents (such as propranolol) readily cross
,3 the blood–brain barrier and achieve high concentrations in brain tissue. This may contribute to the more severe CNS manifestations of mental status
,3 depression, seizures, and coma seen after an overdose of such agents. In addition to β­antagonism, several β­blockers also inhibit myocardial
 sodium channels (similar to quinidine and cyclic antidepressants), rendering these drugs potentially more cardiodepressant following overdose.

However, in massive overdoses, all β­blockers can be severely cardiodepressive.
TABLE 194­2
β­Blocker Pharmacologic Profiles
Sodium Half­
β  Partial Protein Maximum Recommended Adult
Agent Lipophilicity Channel Life
Selectivity Agonism Binding (%) Daily Dose (milligrams)
Blockade (h)
Acebutolol + Moderate +  + 3–4 1200 (800 in elderly)
Atenolol + Weak  6–16  6–9 100 (HTN) 200 (angina)
Betaxolol + High   ± 14–22 
Bisoprolol ++ Moderate  30–40  9–12  (HTN)
 (HFrEF)
Carvedilol  Moderate  >95 ± 7–10  (IR)
 (ER)
Esmolol + Weak   ±  min NA
Labetalol + Weak   ± 3–4 2400
Metoprolol ++ Moderate   ± 3–4 450 (HTN)
400 (angina)
Nadolol  Weak    12–24 320 (HTN)
240 (angina)
Nebivolol +++ Moderate    8–27 
Oxprenolol  Moderate ++  + 1–2
Pindolol  High ++ 40–60 ± 3–4  (HTN)
 (angina)
Penbutolol  High + 80–98  5–20 
Propranolol  High  >90 ++ 3–4 640 (HTN)
320 (angina)
Sotalol  Weak  Minimal   640
Timolol  High ± 10–60  4–5 
Abbreviations: + = some activity; ++ = strong activity; ± = possible activity;  = no activity; ER = extended­release form; HTN = hypertension; HFrEF = heart failure with reduced ejection fraction; IR = immediate­release form; NA = not applicable.
Although β cardioselective medications have less risk of unwanted β effects, such as bronchospasm, selectivity is often lost following large

 overdoses. Several β­blockers, such as pindolol, have partial agonist activity, causing weak stimulation of the β­receptor, with a lesser tendency for
 bradycardia during therapeutic use. Some β­blockers, such as labetalol and carvedilol, are also antagonists at α ­adrenergic receptors, which can
 result in exaggerated hypotension during therapeutic use. Sotalol is unique among β­blockers in its action as a Vaughan­Williams class III agent,
2–4 causing blockade of inward rectifier potassium channels involved in cardiac repolarization.
In addition to cardiopulmonary effects, β­blockers alter metabolism in the liver, skeletal muscle, and adipose tissue. Under normal conditions, the heart uses free fatty acids as its primary energy source, but during times of stress, it switches to carbohydrate metabolism. The inhibition of glycogenolysis and gluconeogenesis in β­blocker overdose reduces the availability of carbohydrates for use by metabolically active cells. Although
 hypoglycemia can occur as a consequence of β­blocker toxicity, it is actually uncommon. In the presence of adequate glucose stores, euglycemia and even hyperglycemia are more common than hypoglycemia.
Clinically relevant pharmacokinetic characteristics include drug formulation (regular or extended release), rate of drug absorption, protein binding, lipid solubility, elimination (mostly by hepatic metabolism), and volume of distribution. These properties determine onset of symptoms, duration of symptoms, target organ toxicity, and potential treatment modalities.
CLINICAL FEATURES
,3,7
Toxicity due to β­blockers can produce a spectrum of clinical symptoms (Table 194­3). The timing of symptom appearance depends upon the formulation. Absorption of regular­release β­blockers occurs rapidly, often with peak effects within  to  hours. However, delays of up to  hours
 following acute ingestion have occurred. Experience is limited regarding onset of symptoms with poisoning following an ingestion of sustainedrelease β­blocker formulations, but based on other sustained­release cardiac drugs, it is assumed that symptoms may be delayed for >6 hours after
,3 ingestion. Co­ingestants that alter gut function, such as opioids and antimuscarinic drugs, may affect absorption of β­blockers and subsequent
 onset of symptoms.
TABLE 194­3
Common Findings With β­Blocker Toxicity
Cardiovascular Hypotension
Bradycardia
Conduction delays and blocks (first­degree atrioventricular block)
Ventricular dysrhythmias (sotalol)
Asystole
Decreased contractility
CNS Depressed mental status
Coma
Psychosis
Seizures
Respiratory arrest
Pulmonary Bronchospasm
Electrolytes Hypoglycemia (uncommon)
Hyperkalemia
,3,7,9
The primary target of β­blocker toxicity is the cardiovascular system, and the hallmark of severe toxicity is bradycardia with shock. Bradycardia due to sinus node suppression or conduction abnormalities occurs in virtually all significant β­blocker intoxications, although ingestion of β­blockers
 with partial agonist activity may initially present with hypertension and tachycardia. The β­blockers with sodium channel antagonism can cause conduction abnormalities, leading to a wide­complex bradycardia that can worsen hypotension and shock (especially when the QRS interval is >100
 milliseconds).

The cardiotoxic profile of sotalol is different from that of other β­blockers due to its blockade of potassium channels, causing QT prolongation. Thus, sotalol is more often associated with ventricular dysrhythmias, including premature ventricular contractions, bigeminy, ventricular tachycardia,
 ventricular fibrillation, and torsades de pointes.

β­Blockers also affect the CNS and pulmonary system. Neurologic manifestations include depressed mental status, coma, and seizures. These
 symptoms most likely occur due to a combination of hypoxia secondary to poor perfusion, sodium channel antagonism, and direct neuronal toxicity.

More lipophilic β­blockers, such as propranolol, cause greater neurologic toxicity than the less lipophilic agents. Seizures are generally brief, and
 status epilepticus is rare. Antagonism of the β ­receptor in bronchial smooth muscle can cause bronchospasm, both in the setting of nonselective β­
 blockers and in large ingestions of cardioselective β­blockers, where β selectivity may be lost.

DIAGNOSIS
The diagnosis of β­blocker toxicity is primarily made on clinical grounds, including patient history, physical examination findings, and results of basic diagnostic testing. Patients commonly present with a history of intentional overdose or therapeutic misadventure. The diagnosis may be more challenging in cases of polypharmacy, multidrug overdose, or chronic drug toxicity. In addition to β­blockers, multiple other drugs and toxins can present with bradycardia and hypotension; however, there are several features that can help to differentiate these exposures (Table 194­4).
TABLE 194­4
Toxicologic Causes of Bradycardia and Hypotension
Cause Differentiating Features
Calcium channel blockers Elevated lactate level and possible hyperglycemia
Naturally occurring cardioactive steroids (oleander, foxglove, lily of the valley, rhododendron, Ventricular ectopy and Bufo toads) May cross­react with digoxin immunoassay
Class IC antiarrhythmic drugs (propafenone) Wide­complex bradycardia
Clonidine Opioid­like manifestations: coma, miosis, decreased respirations
Cyanide Profound metabolic acidosis and elevated lactate level
Digoxin (acute) Hyperkalemia
Elevated level on digoxin immunoassay
Organophosphates Cholinergic toxidrome
Laboratory testing is recommended to assess renal function, glucose level, oxygenation, and acid­base status. Although specific β­blocker drug levels might be of value for later confirmation of an ingestion, these levels are not helpful initially because they do not correlate with the degree of toxicity
,3,7 and are generally not available in a timely fashion to affect acute management. False­positive amphetamine results can be seen on urine drug
 screens from labetalol, because one of its metabolites is structurally similar to amphetamine. Cardiac function may be evaluated with a 12­lead ECG,
 rhythm monitor, and bedside cardiac US. A drug­induced Brugada pattern has been reported in propranolol overdose, a β­blocker that also blocks
 cardiac sodium channels.
TREATMENT
GENERAL MANAGEMENT
Patients with suspected β­blocker overdose should be evaluated in a critical care area of the ED with appropriate monitoring because they may experience abrupt cardiovascular collapse or neurologic depression. If orotracheal intubation is performed, the drugs used for sedation and paralysis
,3,7 may worsen hypotension in the setting of an already depressed myocardium (see Chapter 29A, “Tracheal Intubation”).
No one particular treatment is consistently effective in the management of β­blocker toxicity, and multiple simultaneous treatment measures may be required to resuscitate the critically ill patient. Therapy should be tailored to each individual case based on exposure history, ECG, bedside cardiac US, and/or central hemodynamic monitoring. The goal of resuscitation is to improve hemodynamics and organ perfusion. Specific end points of therapy may include a cardiac ejection fraction of 50% or greater, a reduction of the QRS interval to <120 milliseconds, a heart rate of >50 to  beats/min, a systolic blood pressure of >90 to 100 mm Hg (12.0 to .3 kPa) in an adult, urine output of  to  mL/kg per hour, and improved mentation.
GI DECONTAMINATION
Although there is little evidence to support routine GI decontamination following overdose of most substances, ingestion of a significant quantity of β­
 blockers with the risk of severe toxicity is a circumstance in which early decontamination should be considered. Activated charcoal may be of benefit
,15 if it can be given within  hour after ingestion in a patient without airway compromise. There may be an additional window of opportunity for
 activated charcoal therapy following ingestion of extended­release β­blockers. Ipecac syrup and cathartic agents are not recommended. Gastric
 lavage is not recommended. Whole­bowel irrigation may be beneficial and should be considered after a large ingestion of an extended­release
 product.
PHARMACOLOGIC TREATMENT
Specific pharmacologic therapies are directed at restoring perfusion to critical organ systems by improving myocardial contractility, increasing heart
,3,7 rate, or both. This is done through fluid resuscitation and administration of glucagon, adrenergic agonists, high­dose insulin, calcium, and
 phosphodiesterase inhibitors (Figure 194­2). Individual pharmacologic therapies have variable effectiveness and are often used simultaneously.
Aggressive measures such as hemodialysis, hemoperfusion, cardiac pacing, placement of intra­aortic balloon pumps, and extracorporeal circulatory
 support have also been used when patients are refractory to pharmacologic therapy.
FIGURE 194­2. Management strategies in β­blocker toxicity. Cardiac function is evaluated using ECG, cardiac US, and/or central hemodynamic monitoring. For wide
QRS interval, consider sodium bicarbonate therapy. For impaired myocardial contractility, consider glucagon, high­dose insulin, adrenergic agents, and calcium therapy. For decreased systemic vascular resistance, consider vasopressors, such as norepinephrine, epinephrine, dopamine, and phenylephrine. For bradycardia, consider glucagon, adrenergic agents, and cardiac pacing. (See text for details.) SVR = systemic vascular resistance.
Treatment of sotalol toxicity may require the use of additional pharmacologic measures due to its potassium channel effects. In addition to the therapies discussed earlier, magnesium supplementation, lidocaine, and cardiac overdrive pacing may be of specific benefit if there is QT prolongation or torsades de pointes.
GLUCAGON
,19
Glucagon is a first­line agent in the treatment of acute β­blocker–induced bradycardia and hypotension. Glucagon, produced in the pancreatic α­cells from proglucagon, independently activates myocardial adenylate cyclase, bypassing the impaired β­receptor and increasing
 intracellular cAMP (Figure 194­1). Glucagon has demonstrated positive inotropic and chronotropic effects in both animal models and human studies.
,3
Effects from an IV bolus of glucagon are seen within  to  minutes, reach a peak in  to  minutes, and have a duration of action of  to  minutes.
Due to the short duration of effect, a continuous infusion is often necessary after bolus administration. The initial bolus dose of glucagon is  to  milligrams (30 to 150 micrograms/kg in children), and if no response is seen within  minutes, a repeat bolus can be given. If a beneficial effect is seen from the glucagon bolus, a continuous infusion of  to  milligrams/h (20 to  micrograms/kg per hour in children) can be used to maintain this effect.
Titrate the glucagon infusion to achieve adequate hemodynamic response. There is no identified maximum therapeutic dose or duration of
 treatment.

The amount of glucagon required to treat a significant β­blocker overdose may exceed the total amount available at any given hospital. The positive inotropic and chronotropic effects of glucagon may not be maintained for a prolonged period due to tachyphylaxis. Nausea and vomiting are commonly reported side effects of high­dose glucagon therapy and may be related to esophageal sphincter relaxation. Antiemetics can be given prior to glucagon administration. Check QTc interval before giving ondansetron. Intubation prior to glucagon administration may be warranted in any
,3,7 patient with altered mental status in order to limit the risk of aspiration.
Prior to 1998, glucagon was derived from porcine and bovine pancreas and contained other pancreatic compounds such as insulin and phenol as a
 preservative. The contribution of this insulin content to the original glucagon’s overall efficacy is unclear (see discussion later in “High­Dose Insulin
Therapy”). Since 1998, glucagon has been produced via recombinant technology and is devoid of insulin or phenol.
ADRENERGIC RECEPTOR AGONISTS
The β­adrenergic receptor agonists—such as norepinephrine, dopamine, epinephrine, and isoproterenol—are routinely used to treat β­blocker
,19  toxicity. However, results have been variable even when dosages far exceed those recommended in standard guidelines for cardiac resuscitation.
The most effective adrenergic receptor agonists may be norepinephrine and epinephrine due to their chronotropic and vasopressor effects.
Phenylephrine may also be beneficial as a vasopressor. Although isoproterenol may increase heart rate, it does so at the expense of vasodilation.
Dobutamine has a similar downside: potential improvement in inotropy but worsening of hypotension due to vasodilation.
HIGH­DOSE INSULIN THERAPY
21­
High­dose insulin (HDI) therapy, also referred to as hyperinsulinemia­euglycemia therapy, is an important treatment modality for β­blocker toxicity.
,17
Insulin acts as an inotrope by facilitating myocardial utilization of glucose (the energy substrate employed during stress), in contrast to glucagon,
21–24 epinephrine, and calcium, which promote free fatty acid utilization. In animal models, HDI improved survival in severe β­blocker overdose
,26 compared with glucagon, epinephrine, or vasopressin administration. The most consistent cardiodynamic effect in these models was an increase in contractility.
HDI dosing used for treatment of β­blocker toxicity is much higher than that used for traditional glucose control in diabetes (Table 194­5). The initial dose is regular insulin  unit/kg IV bolus and is followed by a continuous infusion of  unit/kg per hour that is titrated to the desired hemodynamic
21–23 response of a heart rate at least  beats/min and systolic blood pressure of at least 100 mm Hg (13.3 kPa). The maximum dose has not yet been established, although an animal model of propranolol overdose found that cardiac output increased in a dose­response manner when the insulin
 ,28 dose was raised from  to  units/kg per hour, and human case reports and case series have reported doses this high.
TABLE 194­5
Protocol for High­Dose Insulin Therapy in Severe β­Blocker Overdose
Check serum glucose, and if <200 milligrams/dL (<11 mmol/L), administer  mL of 50% dextrose (0.5 gram/mL) in water IV (children  mL/kg of 25% dextrose).
Administer regular insulin  unit/kg IV bolus.
Begin regular insulin infusion at .0 unit/kg per hour along with dextrose 10% (0.1 gram/mL) in water at 200 mL/h (adult) or  mL/kg per hour
(pediatric).
Titrate infusion rate up to  units/kg per hour according to the hemodynamic goal of HR >50 beats/min and SBP >100 mm Hg (>13.3 kPa).
Monitor serum glucose every 15–20 min.
Titrate dextrose infusion rate to maintain serum glucose level between 100 and 200 milligrams/dL (5.3 and .7 mmol/L).
Once dextrose infusion rates have been stable for  min, glucose monitoring may be decreased to hourly.
Monitor serum potassium level and start IV potassium infusion if serum potassium level is <2.8 mEq/L (<2.8 mmol/L).
Maintain serum potassium between .8 and .2 mEq/L (2.8 and .2 mmol/L).
Abbreviations: HR = heart rate; SBP = systolic blood pressure.

The onset of action with HDI is reported to be  to  minutes, but a delayed response of several hours has been noted. HDI is continued until there
 is resolution of toxicity; the duration of HDI infusion described in case reports ranges from  to  hours. The insulin infusion can be gradually weaned or abruptly halted, and should be reinstituted if heart rate or blood pressure falls after cessation of HDI. Supplemental dextrose is needed for several hours after insulin infusion is stopped.
Potential adverse effects from HDI are hypoglycemia and lowered serum potassium. Dextrose infusion is used to prevent hypoglycemia and often
 required during the duration of therapy. Hypoglycemia tends to occur more often in the treatment of β­blocker toxicity when compared to the treatment of calcium channel–blocker overdose. In a large case series, 41% of patients with single­agent β­blocker overdose treated with HDI
 ,23 developed hypoglycemia. Serum potassium is monitored, and supplemental replacement is given if the level is below .8 mEq/L (2.8 mmol/L). An increase in the dextrose infusion rate required to maintain serum glucose between 100 and 200 milligrams/dL (5.3 and .7 mmol/L), along with signs of clinical improvement, may be an indication that metabolic status is normalizing; that is, that the stress response is diminishing, the heart is reverting back to basal energy substrates, and extra insulin is no longer needed.
IV LIPID EMULSION THERAPY
IV lipid emulsion (ILE) therapy, also known as fat emulsion therapy or lipid rescue, is extremely effective in treating toxicity from local anesthetics and has also been used with mixed results in the treatment of toxicity from calcium channel blockers, typical and atypical antipsychotics, cyclic and other
29–32 antidepressants, and some β­blockers. The exact mechanism is not fully understood, but the likely explanation is that lipid emulsion acts as a pharmacologic sink, sequestering lipophilic drugs into a separate lipid compartment, and the amount of free drug available to target tissues is reduced

(“lipid sink” model). Other potential mechanisms may include supplying the myocardium with free fatty acids and phospholipids, increasing myocardial contractility by increasing myocyte calcium concentration, and elevating blood pressure by central sympathetic activation.
Animal models suggest that ILE, if effective, may be most beneficial in the treatment of toxicity from lipophilic β­blockers (Table 194­2), such as
 propranolol and carvedilol, rather than the more hydrophilic agents, such as metoprolol and atenolol.
The dosing regimen for ILE is based on treatment of local anesthetic systemic toxicity. The standard 20% lipid emulsion is given as a .5 mL/kg bolus
 over  minute, followed by an infusion at .25 mL/kg per minute. If the blood pressure remains low, an additional .5 mL/kg bolus may be repeated followed by an increase in the infusion rate to .5 mL/kg per minute. The recommended upper limit is  mL/kg over the initial  minutes. If the patient’s hemodynamic stability is dependent on continued lipid infusion, the treatment may be continued beyond this level. Duration of therapy has not been fully established. If cardiac arrest occurs, a bolus dose can be given during the resuscitation.
Adverse effects reported with the use of ILE for the treatment of overdose and toxicity include lipemia causing interference with laboratory analysis, hypertriglyceridemia, pancreatitis, hypersensitivity, allergic reaction, acute lung injury, acute renal failure, venous thromboembolism, fat embolism,
35–38 increased susceptibility to infection, and cardiac arrest. Lipid emulsion may clog the hemofiltration filter, precluding renal replacement therapy
 and other methods of extracorporeal support during the infusion and until the lipid has been cleared from the blood. Overall, the effect of ILE in
 various non–local anesthetic poisonings is heterogenous, and the quality of evidence remains low to very low. Given the potential for adverse effects and the lack of strong supporting evidence for use of ILE in the treatment of β­blocker toxicity, ILE should be reserved for refractory shock after other treatment modalities have failed.
ATROPINE
Atropine, a muscarinic blocker, is unlikely to be effective in the management of β­blocker–induced bradycardia and hypotension, although its use is
,4,7 unlikely to cause harm. It may be beneficial for the treatment of other co­ingestants.
CALCIUM
Canine studies and limited case reports suggest that calcium therapy may reverse depression of the myocardium via positive inotropic action, although
,3 with few chronotropic effects. Calcium administration is not routinely recommended in β­blocker overdose, but may be considered in patients with refractory shock unresponsive to other therapies. Calcium for IV administration is available in two forms, gluconate and chloride, both in a 10% solution. A 10­mL dose of 10% calcium chloride solution contains three times more elemental calcium, .6 mEq (6.8 mmol), than  mL of 10% calcium gluconate solution, .5 mEq (2.23 mmol). Thus, one 10­mL ampule of 10% calcium chloride equals three 10­mL ampules of 10% calcium gluconate.
Potential adverse effects of calcium therapy include hypercalcemia, conduction blocks, worsening bradycardia, and inefficient cardiac energetics during shock (see earlier “High­Dose Insulin Therapy” section). Most patients tolerate transient increases in total calcium level without difficulty, and conduction blocks are rare. Severe soft tissue injury associated with inadvertent IV infiltration of the chloride formulation is the most concerning adverse event. Thus, calcium chloride is ideally given via central access. Calcium gluconate is only rarely associated with tissue injury and is the preferred form for peripheral administration.
The optimum dose of calcium in β­blocker toxicity is unknown. Animal studies and limited human studies suggest that large amounts of calcium are
,3 needed to treat drug­induced cardiac toxicity, but these data come from experience derived from treating calcium channel–blocker toxicity. The recommended dose of 10% calcium gluconate is .6 mL/kg given over  to  minutes, followed by a continuous infusion of .6 to .5 mL/kg per
,3 hour. The equivalent dosage of 10% calcium chloride is .2 mL/kg given via central line over  to  minutes, followed by a continuous infusion of .2 to .5 mL/kg per hour. Ionized calcium levels should be checked every  minutes initially and then every  hours to achieve an ionized calcium level of
 twice the normal value.
PHOSPHODIESTERASE INHIBITORS
Phosphodiesterase inhibitors such as milrinone have been used to treat β­blocker toxicity. These agents inhibit the breakdown of cAMP, thereby
,3 sustaining intracellular calcium levels (Figure 194­1). In animal models, phosphodiesterase inhibitors produce positive inotropic effects without increasing myocardial oxygen demand but have no appreciable effect on heart rate. Compared with glucagon, phosphodiesterase inhibitors do not provide any additional benefit and therefore have no advantage over glucagon. However, if glucagon is not available or pharmacy stores have been exhausted, a phosphodiesterase inhibitor is a reasonable alternative. In the setting of a β­blocker overdose, milrinone is administered as a continuous

IV infusion, starting with a  micrograms/kg IV bolus, followed by an IV infusion of .375 to .75 microgram/kg per minute for milrinone.
SODIUM BICARBONATE
Sodium bicarbonate is used to treat severe acidosis and wide QRS interval dysrhythmias secondary to sodium channel blockade. β­Blockers with sodium channel antagonism (e.g., propranolol; Table 194­2) can interfere with ventricular depolarization, predisposing to cardiac dysrhythmias. When
 the QRS interval is longer than 120 milliseconds, it is reasonable to administer sodium bicarbonate. The suggested dose is a rapid bolus of  to 
,3,6 mEq/kg over  to  min. Thus, a 70­kg adult receives a bolus of 140 to 210 mEq of sodium bicarbonate, or three to four ampules (50 mL each) of
.4% sodium bicarbonate. Repeat boluses or an infusion may be required to maintain the QRS interval at <120 milliseconds.
CARDIAC PACING
,3
Internal or external pacing may be considered to treat bradycardia in the setting of β­blocker toxicity. Electrical capture and restoration of blood
,3 pressure are not always successful, potentially due to the lack of intracellular calcium needed for contraction. Cardiac pacing may be most beneficial in treating torsades de pointes associated with sotalol toxicity.
EXTRACORPOREAL ELIMINATION (HEMODIALYSIS)
The high degree of protein binding and lipid solubility of β­blockers, as well as their large volume of distribution, renders extracorporeal drug removal useless for most drugs in this class. Acebutolol, atenolol, nadolol, and sotalol may be amenable to removal through hemodialysis owing to their lower
 protein binding, water solubility, and lower volume of distribution.
EXTRACORPOREAL CIRCULATION
Occasionally, extreme means of resuscitation, including extracorporeal circulation (extracorporeal membrane oxygenation) and intra­aortic balloon
,43 pumps, have been successful when pharmacologic measures have failed to reverse cardiogenic shock.
DISPOSITION AND FOLLOW­UP
Patients who develop altered mental status, bradycardia, conduction delays, or hypotension should be managed in an intensive care unit. A patient
,3,9 who ingests a sustained­released β­blocker product warrants admission and monitoring for the development of delayed toxicity. Patients ingesting an overdose of immediate­release β­blocker tablets who remain asymptomatic and have normal vital signs at  hours after time of ingestion can be
 deemed medically safe for discharge or admission to a psychiatric facility.


