## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 241: Eye Emergencies
Richard A. Walker; Srikar Adhikari
INTRODUCTION AND EPIDEMIOLOGY
The breadth of ocular emergencies seen in the ED requires solid examination skills and an understanding of basic differential diagnosis. An analysis of 1412 ED ocular emergencies presenting to a single center identified the four most common condition categories: ocular trauma in 27% (73% of trauma group had corneal abrasions), conjunctivitis in 15%, retinal problems in .6%, and glaucoma in 2%.1
This chapter reviews eye anatomy, the essential skills needed for the ED eye examination, and common ophthalmic medications. Common causes of the red eye, ocular infections and inflammation, trauma to the eye, acute visual reduction or loss, and acute cranial nerve palsies are discussed. The principles and advantages of ocular US are summarized.
EYE ANATOMY
The orbit is a pyramid of bony walls that converge to an apex posteriorly. The orbit is bordered superiorly by the frontal sinus, medially by the ethmoid sinus, inferiorly by the maxillary sinus, and laterally by the zygomatic bone. The ethmoid bone (lamina papyracea) is paper thin and is the most likely sinus wall to break in blunt eye trauma or to be perforated due to sinusitis with subsequent spread of infection to the orbit. The orbital contents include the ocular muscles, retroseptal fat, and the optic nerve, whereas the globe is considered a separate entity.
The anterior limit of the orbital cavity is the orbital septum (Figure 241­1), which is a layer of fascia extending from the periosteum along the orbital rim to the levator aponeurosis of the upper eyelid and to the edge of the tarsal plate of the lower eyelid. Abnormalities, such as the accumulation of blood or infection, are referred to as “preseptal” or “postseptal.” Postseptal conditions are extremely serious. The septum is generally impervious to bacteria, which serves to limit spread of infection from the facial skin into the orbit. All nerves and vessels of the eye enter through the apex of the orbit (posterior limit), which is also the site of origin for the extraocular muscles. The optic nerve is subject to compression from mass effect due to tumors, abscesses, or hematomas.
FIGURE 241­1. Cross­section of the anterior orbit. [Reproduced with permission from Riordan­Eva P, Whitcher J: Vaughn & Asbury’s General Ophthalmology, 17th ed. New York: Lange Medical
Books/McGraw­Hill; 2008.]
The arterial blood supply of the eye and orbit is the ophthalmic artery, the first major branch of the intracranial portion of the internal carotid artery, which enters the orbit beneath the optic nerve. The central retinal artery is the first intraorbital branch of the ophthalmic artery and courses through the optic nerve. The venous drainage of the eye and orbit is through the ophthalmic veins, which drain into the central retinal vein. The ophthalmic veins communicate directly to the cavernous sinus. This venous system has no valves, and this fact is the basis for the spread of facial and periorbital infections to the cavernous sinus.
The eye itself is composed of several different layers (Figure 241­2). The outermost layer is a thin, transparent mucous membrane (the bulbar conjunctiva) that continues onto the posterior surface of the eyelids (the palpebral conjunctiva). Deep to the conjunctiva is the episclera, a layer of thin, elastic tissue containing blood vessels that nourish the next deepest layer, the sclera. The sclera is the collagenous protective coating of the eye, which is the thinnest (and prone to rupture) at the insertion of the rectus muscles.
FIGURE 241­2. Internal structures of the human eye. [Reproduced with permission from Riordan­Eva P, Whitcher J: Vaughn & Asbury’s General Ophthalmology, 17th ed. New York: Lange Medical

Books/McGraw­Hill; 2008.]
Chapter 241: Eye Emergencies, Richard A. Walker; Srikar Adhikari 
. Terms of Use * Privacy Policy * Notice * Accessibility
The cornea forms the anterior surface of the eyeball and is attached to the sclera at the limbus. From anterior to posterior, the cornea has five separate layers: epithelium, Bowman layer, stroma, Descemet membrane, and endothelium. The epithelium is five or six cell layers thick and is subject to damage from minor mechanical forces, resulting in corneal abrasion (Figure
241­3).
FIGURE 241­3. Transverse section of cornea. [Reproduced with permission from Riordan­Eva P, Whitcher J: Vaughn & Asbury’s General Ophthalmology, 17th ed. New York: Lange Medical Books/McGraw­
Hill; 2008.]
The iris, ciliary body, and choroid (the vascular pigmented layer of the eye between the sclera and retina) make up the uveal tract. The uveal tract supplies nutrition to the eye and assists in accommodation and pupillary constriction. The lens separates the aqueous humor in the anterior chamber from the vitreous humor in the remainder of the globe. (See the section titled
“Acute Angle­Closure Glaucoma,” under the section “Acute and Painful Vision Reduction or Loss,” in this chapter for discussion of the production and flow of aqueous humor.) The retina is the sheet of neural tissue containing the rods and cones that lines the posterior two thirds of the inner surface of the globe, extending anteriorly as far as the ciliary body.
EYE EXAMINATION
HISTORY
A detailed history is as important in the patient with an eye complaint as it is for a complaint related to any other organ system. History should first categorize the symptom as vision loss, change in appearance of the eye, eye pain/discomfort, or trauma. The onset (gradual or sudden) of symptoms, duration of the symptoms, and circumstances surrounding the onset are important. Eye discomfort should be characterized as pain (aching, burning, throbbing, etc.), pruritus (associated with allergy), or a foreign body sensation as seen with corneal foreign bodies, abrasions, or ulcers. “Flashing lights” and a “curtain or veil” obstructing a portion of the visual field suggest a retinal detachment. In the case of trauma, ask about onset (traumatic iritis occurs  to several days after blunt trauma to the eye) and mechanism (globe penetration may occur in association with hammering, grinding, or use of other high­speed machinery).
Document tetanus status and give tetanus toxoid as appropriate.
Past medical history can narrow the differential diagnosis. Previous surgery may be the cause of an irregular pupil. Absence of corrective lenses may account for decreased visual acuity and will require modification of the method for testing visual acuity. Use of contact lenses, especially the extended wear type, may be associated with bacterial corneal ulcers. Chronic use of certain ophthalmic medications may cause chemical conjunctivitis and inflammatory changes of the cornea. A history of diabetes or chronic hypertension and acute isolated sixth­nerve palsy suggests an ischemic cranial neuropathy. Monocular diplopia following trauma in a patient with an intraocular lens implant suggests dislocation of the intraocular lens. Ask about previous instances of similar symptoms and the associated diagnosis.
EXAMINATION
The eye examination typically proceeds in a sequential fashion unless the circumstances require otherwise (e.g., chemical ocular injuries require irrigation before assessment of visual acuity). The glossary of terms and abbreviations in Table 241­1 is helpful when communicating with the ophthalmologist.
TABLE 241­1
Glossary of Terms, Abbreviations, and Notations
Table 241­1. Glossary of Terms, Abbreviations, and Notations
AC Anterior chamber, the first portion of the anterior segment.
Anisocoria Unequal pupil size under equal lighting conditions.
Anterior segment Consists of the anterior chamber and posterior chamber. Aqueous humor is produced in the posterior chamber of the anterior segment and circulates through the pupil into the anterior chamber of the anterior segment.
APD Afferent pupillary defect (see Figure 241­8).
CF Counting fingers (visual acuity assessment).
CVF Confrontation visual fields.
EOM Extraocular muscle. Extraocular movements.
HM Hand motion (visual acuity assessment).
Hyphema Red blood cells in the anterior chamber.
Hypopyon WBCs in the anterior chamber.
INO Internuclear ophthalmoplegia.
IOFB Intraocular foreign body.
IOP Intraocular pressure (mm Hg).
Limbus Circumferential border where clear cornea ends and white sclera begins.
NLP No light perception (blind).
OD Oculus dexter (right eye).
OS Oculus sinister (left eye).
OU Oculus uterque (each eye).
PH Pinhole visual acuity.
RD Retinal detachment.
Tono­Pen® (Reichert, Inc., A hand­held, pen­shaped device for measuring IOP.
Depew, NY)
Ttono Tension (IOP) with subscript representing method used: (tono = Tono­Pen®; S = Schiötz; A = applanation).* VAC Visual acuity with correction (glasses or contact lenses).* VAS Visual acuity without correction.* *By convention, in documenting the visual acuity (VA) or IOP, the right eye is listed above the left, as follows:
This represents an IOP of  mm Hg in the right eye and  mm Hg in the left eye measured by Tono­Pen®.
This represents a visual acuity with glasses/contacts of 20/20 right eye and 20/30 left eye.
This represents a visual acuity without glasses/contacts of 20/400 in the right eye, improving to 20/30 with pinhole testing; counting fingers at  ft (2.4 m) in the left eye, improving to
20/40 with pinhole testing.
Full examination should include the following, generally in the order listed: visual acuity, confrontational visual fields, extraocular movements, pupillary reactions, lids and adnexa, conjunctiva and sclerae, cornea, anterior chamber, iris, lenses, vitreous, intraocular pressure, and funduscopic examination. Measurement of intraocular pressure is done toward the end of the examination because physical touching of the cornea is more irritating and invasive than the rest of the examination. Performance of a thorough funduscopic examination requires dilatation of the pupil, so this part of the examination is performed last. Not all parts of the examination need to be done on every patient. For example, testing visual fields adds little to the evaluation of a corneal foreign body but is essential to the evaluation of acute vision loss.
Visual Acuity
Most vision­threatening disorders present with decreased visual acuity. Visual acuity testing is the vital sign of the eye and is the first step in any eye examination, even before shining a light in the eye; bright light can temporarily decrease visual acuity. The only exception to this rule is for chemical burns to the eye, where irrigation takes precedence above all else. Test visual acuity with contact lenses or glasses in place if possible. If the patient’s glasses or contacts are unavailable, use pinhole testing of visual acuity. A commercial pinhole occluder may be used, or a note card perforated with an 18­gauge needle is an acceptable substitute. The pinhole allows only parallel light rays to fall on the macula, thereby reducing the refractive error and allowing an estimate of the person’s corrected visual acuity. Visual acuity testing is ideally done with a standard wall­mounted visual acuity chart (Snellen chart) with the patient standing  ft (6 m) from the chart. Record the visual acuity as 20/x, where the numerator is the distance from which the patient can read the line (always 20) and the denominator is the distance from which a person with normal vision can read the same line. The visual acuity is determined by the smallest line a patient can read with one half of the letters correct. The number of incorrect letters is listed after the visual acuity as follows: 20/x­y (e.g., 20/40­2). Document best acuity in each eye and whether prosthetic devices were used in testing (glasses, pinhole).
Visual acuity can also be tested with a near card (Rosenbaum chart) held  in. (36 cm) from the patient. Patients in their mid­40s or older may require reading glasses or bifocals to read a near card because of presbyopia. If the bifocals are not available, use a pinhole occluder.
For patients with visual acuity <20/200, finger counting at a distance (e.g., finger counting at  ft or  m), perception of hand motion at  to  ft (0.3 to .6 m), and ultimately light perception can be used to document visual acuity. If the patient is unable to detect hand motion, turn off all the lights in the room, fully occlude the contralateral eye, and test for light perception. Illiterate patients can be tested using the direction of the letter E on the chart, and a verbal child may be tested with an Allen chart (pictures). Corneal abrasions or foreign bodies can cause severe photophobia, pain, and tearing, so a topical anesthetic can reduce discomfort sufficiently to allow a more accurate assessment of visual acuity. In recording the results of visual acuity testing, refer to Table 241­1. When alternating black­and­white lines are passed from one side to another in front of a patient’s eyes, involuntary horizontal nystagmus (optokinetic nystagmus) will occur. The presence of optokinetic nystagmus excludes blindness in a patient with an otherwise normal examination who claims he or she cannot see (hysterical blindness). The test can be performed by placing thick black lines approximately  in. apart on a 2­ft strip of cardiac monitor paper, which is passed back and forth at eye level a distance of  ft from the patient.
Confrontation Visual Fields
Test all four quadrants of the visual fields by having the patient cover one eye and look at the physician’s nose. The examiner closes the opposite eye and holds a finger halfway between the patient and himself or herself. The finger is wiggled as it is moved medially toward the patient. The normal patient should see movement at approximately the same time as the physician does. A visual field defect may represent pathology anywhere from the occipital cortex to the optic nerve (Figure 241­4). Bitemporal hemianopia can occur in pituitary adenoma; homonymous hemianopia is associated with some cerebrovascular accidents; and monocular field cuts are sometimes seen with large retinal detachments.
FIGURE 241­4. Visual field defects produced by lesions at various points along the optic pathways: (1) field defect caused by retinal lesion, (2) total blindness right eye, (3) bitemporal hemianopia, (4) right incongruous hemianopia, (5) left homonymous superior quadrantanopia, (6) right homonymous inferior quadrantanopia, (7) right congruous incomplete homonymous hemianopia, and (8) right homonymous hemianopia with macular sparing. [Reproduced with permission from Riordan­Eva P, Whitcher J: Vaughn & Asbury’s General Ophthalmology, 17th ed. New York: Lange
Medical Books/McGraw­Hill; 2008.]
Ocular Motility
The normal patient can move the eye through the six cardinal positions of gaze, and the eye movements are controlled by the six extraocular muscles attached to each eye (Figures 241­5 and 241­6). Extraocular muscles are innervated by cranial nerves III, IV, and VI. Cranial nerve IV controls the superior oblique muscle, cranial nerve VI controls the lateral rectus muscle, and all other extraocular muscles are controlled by cranial nerve III. Extraocular movement can be impaired by restriction, interrupted or decreased innervation, or trauma. Examples of restriction include thyroid orbitopathy, myositis, and mechanical entrapment of a muscle secondary to an orbital blow­out fracture. Cranial nerve palsies or paresis may be caused by stroke, myasthenia gravis, diabetes, hypertension, tumors, aneurysms, infections, and trauma. Penetrating or blunt traumatic injury to an extraocular muscle also can result in motility disturbance.
FIGURE 241­5. Extraocular muscles of the eye.
FIGURE 241­6. Arrows indicate direction of ocular movement by each muscle. Cranial nerve IV, superior oblique muscle; cranial nerve VI, lateral rectus muscle; cranial nerve III, superior rectus, inferior rectus, inferior oblique, and medial rectus muscles. L = left; R = right.
Evaluate ocular alignment initially in primary gaze (looking straight ahead), and then test eye movements in all fields of gaze. Always ask the patient about diplopia, which may be a subtle sign of problems with extraocular muscles. Diplopia is usually worse when the patient is attempting to look in the direction of the malfunctioning muscle. Ask patients if diplopia persists when one eye is covered (monocular diplopia). Monocular diplopia can be caused by corneal irregularity, lens problems, or intraocular lens dislocation, or it can be a sign of malingering. Resolution of diplopia when one eye is covered represents pathology of an extraocular muscle or its innervation. Patients with lesions of the superior oblique muscle or the fourth cranial nerve may tilt their head to compensate for the diplopia.
Pupils
Note the pupil size in millimeters and test shape and reaction to light. An irregular pupil may occur from prior surgery or remote trauma. The patient will usually be able to relate a previous history of irregular pupil. The classic irregular teardrop­shaped pupil may also be seen in acute blunt or penetrating trauma with rupture of the iris (Figure 241­7).
FIGURE 241­7. Prolapse of the iris with the classic teardrop­shaped pupil after penetrating trauma. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
Assess pupils under slightly dim light to test for an afferent pupillary defect (Figure 241­8). A positive afferent pupillary defect indicates an optic nerve disorder. Any pathology that prevents light from getting to the CNS, such as opacification of the vitreous with blood, retinal pathology, or optic nerve pathology, will cause an afferent pupillary defect, also known as a
Marcus­Gunn pupil. The pupils will be equal in size before testing because of the consensual light response. Therefore, an afferent pupillary defect does not cause a baseline anisocoria and will be discovered only if specifically tested for. Perform the “swinging flashlight test” to detect an afferent pupillary defect. Shine a light in the pupil. The light causes constriction of the ipsilateral pupil and consensual constriction of the opposite pupil. The light is then shined/swung to the opposite pupil. The opposite pupil will dilate if an afferent pupillary defect is present, because the effect of light is not getting through to the CNS.
FIGURE 241­8. A and B. “Swinging flashlight test” revealing an afferent pupillary defect (Marcus­Gunn pupil) of the left eye. A. Pupils are normal and equal before light testing. B. Both pupils constrict when light is shined into the normal (right) eye. C and D. The test is positive when the affected pupil (left pupil) dilates in response to light. Conditions with an afferent pupillary defect include optic neuritis and central retinal artery occlusion.
Causes of unequal pupils (anisocoria) can range from an acute emergency (posterior communicating artery aneurysm) to chronic baseline conditions such as previous intraocular trauma or surgery, or they can be idiopathic. Physiologic anisocoria (benign chronic difference in pupil size) is the most common cause of asymmetric pupils. The difference in size is usually <1 mm, and both pupils react normally by constricting to light and dilating in darkness. A single dilated pupil may represent impending uncal herniation (from pressure on the third nerve), but uncal herniation is accompanied by an altered level of consciousness and other focal neurologic signs. A single nonreactive dilated pupil may result from a topical cycloplegic agent (scopolamine, cyclopentolate, or atropine) or if an anticholinergic medication (such as ipratropium from a nebulization treatment for bronchospasm) is splashed into the eye. A careful history is important to determine whether anisocoria is preexisting. It is not worthwhile to attempt to “reverse” a suspected chemically altered pupil in the ED as a diagnostic test because the results are not reliable.
External Eye: Periorbital Skin, Lids, and Adnexa
First, carefully examine the eyebrows, eyelids, lashes, palpebral and bulbar conjunctivae, lacrimal apparatus, cornea, and sclera. Look for follicles (seen with allergic and viral conjunctivitis), chemosis (subconjunctival edema fluid), injection/inflammation, discharge, trauma, hypopyon, hyphema, and foreign bodies. Apply drops of a fresh unused bottle of anesthetic if the eye is painful, and apply fluorescein to look for abrasions and lacerations.
Examine the periorbital skin and lids for trauma, infection, dysfunction, deformity, crepitus, or proptosis. Subcutaneous emphysema can be found with blow­out fractures of the medial orbital wall (ethmoid). Palpate the orbital rims for step­off deformities in trauma. Evert the upper eyelid to check for foreign bodies. Use of a cotton applicator is often recommended; however, this technique will only visualize the lower half of the inner upper eyelid (Figure 241­9). The edge of an eyelid retractor may be used to tent the upper lid while a second examiner looks under the lid from a caudal direction, so­called double eversion of the eyelid. This will allow visualization of the upper half of the inner eyelid. A large paper clip may be bent into the shape of an eyelid retractor for this purpose (Figure 241­10 and see Figure 241­11).
FIGURE 241­9. Single eversion of eyelid when a cotton applicator is used. [Reproduced with permission from Riordan­Eva P, Whitcher J: Vaughn & Asbury’s General Ophthalmology, 17th ed. New York: Lange
Medical Books/McGraw­Hill; 2008.]
FIGURE 241­10. An alternative to an eyelid retractor. A. Unfold a paper clip and bend it into shape with a hemostat. B. Paper clips used to retract the eyelids. [Reproduced with permission from Reichman EF,
Simon RR: Emergency Medicine Procedures. © 2004, Eric F. Reichman, PhD, MD, and Robert R. Simon, MD. McGraw­Hill Professional, Inc.]
FIGURE 241­11. Eyelid retractors fashioned from paper clips. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. ©2002 McGraw Hill, New York.]
Examine the Iris for Pupil Irregularity and Pupillary Dysfunction
Irregularity of the pupil will occur whenever one portion of the iris is tethered into place and may occur from posterior synechiae, where the iris is adhesed to the anterior lens capsule as seen in uveitis, or when any portion of the iris plugs a corneoscleral laceration causing a peaked pupil. Trauma may also cause the iris to tear at the root, termed iridodialysis. Assess the lens for opacities, lacerations, and subluxation.
Fluorescein Examination
Fluorescein binds to damaged corneal epithelium and fluoresces green under a Wood’s lamp or light through a cobalt blue filter. Using the slit lamp, always remove contact lenses, as fluorescein will cause permanent staining of the lenses. Touching the fluorescein strip directly to the cornea will cause staining mimicking a linear abrasion. The best way to apply fluorescein dye is to apply several drops of eye­irrigating solution or saline onto a paper fluorescein strip, and then lightly apply the moistened end of the fluorescein strip into the inferior conjunctival fornix. Ask the patient to blink several times to distribute the fluorescein. Then examine the cornea for streaming of fluorescein­tinged aqueous humor (positive Seidel test) seen in full­thickness laceration of the cornea (Figure 241­12). The Seidel test can be negative (no streaming) with a small or spontaneously sealing corneal laceration. Ask the patient to blink to wash out the fluorescein, and then examine the cornea with the cobalt blue filter on the slit lamp. A corneal abrasion will fluoresce bright green. A Wood’s lamp (ultraviolet light) may also be used to look grossly (without the slit lamp) for corneal abrasions, but microscopic/punctate abrasions will be missed without use of a slit lamp.
FIGURE 241­12. Positive Seidel test showing aqueous humor leaking through a full­thickness corneal wound. Aqueous humor will turn fluorescein lime green under a cobalt blue light as it oozes through the wound while being observed through the slit lamp.
Funduscopic Examination
Note the size, shape, and sharpness of the borders of the optic disk, the cup­to­disk ratio, the size ratio of the arteries to veins (normal 2:3), any nicking where the arteries and veins cross, the texture and color of the retina as well as the presence of lesions (e.g., hemorrhages or exudates) of the retina or vessels (e.g., aneurysms), and the color and size of the macula. To locate lesions of the retina, note the direction (e.g., superonasal) and distance from the disk in terms of disk diameters. Opacities of the lens may obscure the view of the retina, and lens opacities appear as black spots of various shapes. Lesions in the vitreous, such as vitreous hemorrhage, will also obscure the view. Vitreous hemorrhage will have an irregular shape and may have a reddish hue.
The direct hand­held ophthalmoscope is used to examine the fundus. Pharmacologic dilatation will greatly enhance the view of the disk, macula, and proximal retinal vessels. Dilation is achieved by using one drop of 1% tropicamide in Caucasian patients and one drop each of 1% tropicamide and .5% phenylephrine in all others. An indirect ophthalmoscope provides an excellent three­dimensional view of the optic nerve and retina, but requires extensive practice to use and generally is not a tool for the nonophthalmologist.
The Welch Allyn Panoptic® direct ophthalmoscope allows a five times larger view of the fundus than the standard direct ophthalmoscope and provides a better view of the fundus with an undilated pupil (Figure 241­13). It also allows for more distance between the patient and examiner, for the comfort of both. The Panoptic® device attaches to a standard Welch Allyn handle. (See Video: Panoptic ophthalmoscope.)
FIGURE 241­13. Welch Allyn Panoptic.]
Video 241­1: Panoptic ophthalmoscope
Used with permission from Dr. Stephen Gamboa, University of North Carolina, Department of Emergency Medicine, Chapel Hill, NC; Matthew Wetschler, Dr. Stephen Gamboa, TarpanGroup, LLC, B.K. Fox.
Play Video
Use the Panoptic® as follows:
. Remove your glasses and the patient’s glasses; seat the patient upright or with the patient’s stretcher set as upright as possible. Position yourself in a direct line of vision to the patient’s eyes.
. With the scope turned off, focus on an object at least  ft away.
. Set the aperture dial to small (“home” position—green line).
. Turn on the scope and adjust to maximum brightness.
. Ask the patient to be still and look straight ahead and tell him or her that the eyecup will touch the brow.
. Place your hand on the patient’s forehead and position the scope  in. away at a 15­ to 20­degree angle to the temporal side.
. Locate the red reflex and move the scope toward the patient keeping the red reflex in view.
. Maximum view should be obtained when the eyecup is compressed by half.
. If you have a dominant eye and prefer to use that for the examination, you may examine the opposite eye without switching your eye on the scope.
. Make sure you wipe off the eyepiece with antiseptic/antibacterial solution after use or change eyepieces between patients.
Papilledema
Papilledema is bilateral edema of the head of the optic nerve due to increased intracranial pressure. Any disease process that increases the intracranial pressure and inhibits vascular or axoplasmic flow in the optic nerve causes congestion and edema of the nerve head. Bilateral papilledema is a common finding in malignant hypertension, pseudotumor cerebri, intracranial tumors, and hydrocephalus. The disk margins are blurred, the cup is diminished or absent, and the nerve head is elevated with vascular congestion (Figure 241­14). Frequently, flameshaped hemorrhages are seen on or adjacent to the nerve head. A distinguishing feature of papilledema is prolonged preservation of visual acuity (frequently patients are visually asymptomatic).
FIGURE 241­14. Optic nerve head edema. Vascular congestion, elevation of the nerve head, and blurred disk margins are characteristically seen in papilledema, papillitis, and compressive lesions of the optic nerve. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New York.]
Intraocular Pressure
The eye remains consistently “inflated” because of a delicate balance between intraocular aqueous fluid production and outflow. Intraocular pressure can decrease due to reduced ciliary body production (some cases of iritis and uveitis) or loss of globe integrity (perforating injury). Intraocular pressure increases when intraocular fluid production exceeds outflow (glaucoma, hyphema). Measure intraocular pressure in all cases of vision loss, eye pain (suspected glaucoma), and acute or remote trauma. Do not attempt to measure intraocular pressure if globe rupture from blunt or penetrating trauma is suspected, as the pressure placed on the globe during pressure measurement may cause extrusion of intraocular contents. The normal intraocular pressure is  to  mm Hg. Digital palpation of the globe may give a rough estimation, using the examiner’s eye or tip of the nose as control. Provide topical eye anesthetic when devices are used to measure pressure. To measure pressure, the lid must be open, and the patient must look straight ahead. Hold the lids open, with your fingers compressing the patient’s lids against the bony rims of the orbit. Avoid placing any pressure on the globe with your fingers when holding the lids open, because this will cause a falsely high reading. Document the method used for determining intraocular pressure. In recording the pressure, refer to Table 241­1. Schiötz Tonometer
The Schiötz tonometer is a device using a plunger to indent the cornea. The direct Schiötz scale reading is not the intraocular pressure. Schiötz tonometry is inaccurate and not well tolerated by patients, and the instrument is difficult to sterilize, leading to potential spread of infection. The Tono­Pen® XL (Reichert, Inc., Depew, NY), Goldman® applanation tonometer, and pneumatonometer have supplanted the use of the Schiötz tonometer.
Tono­Pen®
The Tono­Pen® XL and similar electronic devices have disposable latex covers and measure pressure by indentation of the cornea. The Tono­Pen® XL is touched to the cornea  to  times and will read out an average pressure reading (Figure 241­15). (See Video: Intraocular Pressure Measurement With Pen Tonometer.)
FIGURE 241­15. Tono­Pen® XL (Reichert, Inc., Depew, NY). [Reproduced with permission from Rhee J: Glaucoma: Color Atlas and Synopsis of Clinical Ophthalmology. New York: McGraw­Hill; 2003.]
Video 241­2: Pen Tonometer
Used with permission from Judith E. Tintinalli; George Escaravage and Amy M. Fowler, Department of Ophthalmology, University of North Carolina.
Play Video
Applanation Tonometer
Use of the Goldman® applanation tonometer requires training and practice and is a method used by optometrists and ophthalmologists. The cone must be sterilized between patients. The cone of the tonometer is touched to the cornea after topical anesthesia, and fluorescein is instilled into the eye (without irrigation). When looking through the slit lamp, two half circles are seen and properly aligned by adjusting the dial on the tonometer, from which the pressure is read (Figures 241­16 and 241­17).
FIGURE 241­16. Goldman® applanation tonometry. [Reproduced with permission from Riordan­Eva P, Whitcher J: Vaughn & Asbury’s General Ophthalmology, 17th ed. New York: Lange Medical
Books/McGraw­Hill; 2008.]
FIGURE 241­17. Appearance of fluorescein semicircles using applanation tonometry under the slit lamp. [Reproduced with permission from Riordan­Eva P, Whitcher J: Vaughn & Asbury’s General
Ophthalmology, 17th ed. New York: Lange Medical Books/McGraw­Hill; 2008.]
SLIT LAMP EXAMINATION
The palpebral and bulbar conjunctiva, sclerae, cornea, anterior chamber, and iris and ciliary body make up the anterior chamber, and all except the ciliary body may be examined with the slit lamp (Figure 241­18A and B). (See Video: Slit Lamp Exam.)
FIGURE 241­18. A. The slit lamp provides a magnified view of the eye. B. A thin slit can demonstrate the cornea (C), iris (I), and lens (L, seen directly through the pupil).
Video 241­3: Slit Lamp Exam
Used with permission from Amy Fowler and Tim Platts­Mills, Department of Ophthalmology, Department of Emergency Medicine, University of North Carolina.
Play Video
The slit lamp is a binocular microscope that provides a highly magnified three­dimensional view of ocular structures. Although there are different slit lamp manufacturers, all slit lamps have the same type of knobs and adjustments. The patient and examiner should both be seated on adjustable stools so that the examiner’s and patient’s eyes are at the same level. Cover the chin rest with tissue paper or a washcloth. Adjust the slit lamp height so the patient can lean forward and comfortably place the forehead against the upper plastic bar and the chin on the chin rest.
Adjust the height of the chin rest so the patient’s lateral canthus is even with the black line on the vertical bar. The oculars and light source are generally straight ahead for the general eye evaluation. Focus is adjusted by the anterior­posterior movement of the eyepiece and light source in relation to the patient. The joystick controls focus by moving the slit lamp closer to or farther away from the patient’s eyes. Joystick rotation controls vertical movement of the light source and eyepieces. When one looks through the eyepieces, the focus should be close to correct if a narrow slit of light falls on the structures to be examined. Fine adjustments in focus are then made with the joystick. Adjust the vertical light beam to the full height of the cornea with a width of approximately  mm (Figure 241­18B).
To examine the cornea, first make the light beam as thin and bright as possible (Figure 241­19A). Next, move the light source to a 45­degree angle relative to the body of the slit lamp (Figure
241­19B). By generating a thin intense light beam directed at an angle, you can view an optical cross­section of the clear structures of the eye (Figure 241­19C to E). Small movements of the joystick can improve visualization and also go more posteriorly into the eye. Increase magnification to 16× to visualize subtle findings.
FIGURE 241­19. A. To examine the cornea, adjust the light beam to be thin and bright. B. Move the light source to a 45­degree angle. C. The first structure is the cornea. The first curve of the cornea is the tear film and corneal epithelium. D. Corneal stroma. E. Corneal endothelium. F. Anterior chamber. The anterior chamber is usually clear. If filled with material, it represents cells or proteinaceous material. G. The lens of the eye is seen posterior to the anterior chamber. As you focus on the lens of the eye, the cornea will be out of focus.
The first structure the light beam passes through is the cornea. Inspect the corneal epithelium for abrasions, ulcers, edema, and foreign bodies (Figure 241­19C). Examine the corneal stroma
(Figure 241­19D) for edema, scars, and lacerations, and examine the endothelium (Figure 241­19E) for precipitates (WBCs on the endothelium characteristic of iritis) and lacerations.
Next is the anterior chamber, which is normally empty (Figure 241­19F), but WBC and proteinaceous material can be evident in iritis.
Assess the depth of the anterior chamber by adjusting the angle of the light source on the slit lamp or by shining a penlight onto the iris from a lateral direction. If the iris is bowed forward, as with a shallow anterior chamber, a shadow will be cast on the medial (nasal) iris (Figure 241­20).
FIGURE 241­20. Estimation of depth of the anterior chamber by oblique illumination. Note the shadow cast in the shallow chamber. [Reproduced with permission from Riordan­Eva P, Whitcher J: Vaughn &
Asbury’s General Ophthalmology, 17th ed. New York: Lange Medical Books/McGraw­Hill; 2008.]
To better view the anterior chamber, move the focus inward halfway between the iris and cornea, with the pupillary aperture as a dark backdrop. This will place your focus in the center of the aqueous humor, and the light beam will illuminate WBCs and red blood cells (if present) slowly drifting up and down in the aqueous convection currents, sometimes likened to snowflakes floating through the beam from a car’s headlight at night. Iritis may result in WBC layers in the anterior chamber (hypopyon) (Figure 241­21). Trauma to the eye may cause red blood cells in the anterior chamber (hyphema or microhyphema). Hyphema is layering of the red cells in the anterior chamber visible to the naked eye (Figure 241­22). A hyphema may occasionally be clotted (Figure 241­23). Flare is described as the appearance of “headlights in a fog” and represents the ability to see the course of the normally transparent light beam through the aqueous humor. Flare is caused by increased aqueous protein in the anterior chamber, which is common with inflammatory conditions such as iritis.
FIGURE 241­21. Hypopyon: a layering of WBCs in the inferior portion of the anterior chamber. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
FIGURE 241­22. Hyphema secondary to blunt trauma. Note the blood filling the lower half of the anterior chamber and hazy appearance of cornea suggesting increased intraocular pressure. [Courtesy of
Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
FIGURE 241­23. Hyphema appearing as a clot rather than layering out. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
Finally, aiming posteriorly, the light beam passes to the lens (Figure 241­19G).
COMMON OPHTHALMIC MEDICATIONS USED IN THE ED
Topical anesthetics are needed for eye examination, intraocular pressure measurement, and corneal foreign body removal. Mydriatics and cycloplegics are needed for a more thorough eye examination. Ophthalmic antibiotics are prescribed for conjunctivitis and corneal abrasions. Antiviral medications are used for herpes simplex. Glaucoma may be treated with various combinations of topical nonselective and β ­blockers, selective α ­agonists, carbonic anhydrase inhibitors, cholinergic agents, and prostaglandin analogs. Allergic conjunctivitis is treated
  with topical nonsteroidal anti­inflammatory drugs, mast cell stabilizers, selective H antagonists, or corticosteroids.

Table 241­2 lists common agents used in the ED and those that the consulting ophthalmologists may ask the emergency medicine physician to prescribe.
TABLE 241­2
Ophthalmic Medications Used in the ED
Type Generic Name Trade Name Indication Cautions Usual Dose
Mydriatic Sympathomimetic .5% Mydfrin® Pupil dilation, no Hypertension, One drop, onset 20–30 min, duration several hours phenylephrine AK Dilate® cycloplegia, glaucoma; do not usually adjunctive use after chemical to an injury to the eye anticholinergic
Mydriatic­cycloplegic Cyclopentolate Cyclogyl® Short­term Glaucoma; higher .5% in children, one drop; 1% in adults, one drop; onset  min, duration
Anticholinergic mydriasis and concentrations in ≤24 h cycloplegia for children can cause examination agitation
Tropicamide Mydriacyl® Short­term Glaucoma One to two drops of .5% or 1% solution, onset  min, duration of action 
Tropicamide mydriasis and h
Ophthalmic cycloplegia for
Solution examination
Homatropine Isopto Intermediate­term Glaucoma, avoid in One to two drops of 2% solution; onset  min; duration of action 2–4 d; for
Homatropine® pupil dilation, children iritis one to two drops twice a day cycloplegia, treatment of iritis
Antihistamine/decongestant Naphazoline and Naphcon­A® Conjunctival Do not use >72 h; One drop three to four times a day pheniramine Visine A® congestion/itching avoid in narrow angle glaucoma; hypertension; do not use with contact lenses in place
Antihistamine Olopatadine Patanol® Allergic Do not administer .1% solution, one drop twice daily, onset of action 30–60 min, duration  h conjunctivitis while contact lenses are present
Topical anesthetics Tetracaine Pontocaine® Anesthetic for eye Sensitivity to ester­ .5% solution, one to two drops; onset of action  min, duration  min ophthalmic Tetravisc® examination, type anesthetics; no solution foreign body prolonged use; removal delays healing at toxic doses
Proparacaine Alcaine® Anesthetic for eye .5% solution, one to two drops; onset of action  s, duration  min ophthalmic Ophthetic® examination, solution foreign body removal
Antibiotics Erythromycin Ilotycin® Conjunctivitis Not agent of choice 1/ in. applied to lower eyelid two to four times a day
 ophthalmic AK­Mycin® Do not use for for contact lens ointment corneal abrasion if wearers a contact lens wearer
Ciprofloxacin Ciloxan® Conjunctivitis, — Solution: one to two drops when awake every  h for  d; ointment, 1/ in.

Ophthalmic corneal abrasion if applied to lower eyelid three times a day for  d
Solution and a contact lens
Ointment wearer
Tobramycin Tobrex® Conjunctivitis, One drop per time .3% solution, one to two drops every  h; .3% ointment, 1/ in. applied to

Ophthalmic corneal abrasions period is sufficient in lower lid two to three times/d
Solution and if a contact lens most cases
Ointment wearer
Gentamicin Garamycin® Conjunctivitis, One drop per time .3% solution, instill one to two drops every  h; .3% ointment, 1/ in.

Genoptic® corneal abrasion if period is sufficient in applied to lower lid two to three times/d a contact lens most cases wearer
Sulfacetamide Bleph­10 Conjunctivitis Do not use for One to two drops four times a day sodium Ophthalmic corneal abrasion if a
Solution 10%® contact lens wearer or if allergic to sulfa
Besifloxacin Besivance Conjunctivitis, — One drop three times a day for  d
Ophthalmic corneal abrasion if
Suspension® a contact lens wearer
Levofloxacin Iquix Conjunctivitis, Corneal ulcer One to two drops every  min to  h while awake and every 4–6 h at night
Ophthalmic corneal abrasion if
Solution® a contact lens
Quixin wearer
Ophthalmic
Solution®
Moxifloxacin Moxeza Conjunctivitis, One drop twice a day for  d hydrochloride Ophthalmic corneal abrasion if
Solution® a contact lens
Vigamox wearer
Ophthalmic
Solution®
Ofloxacin Ocuflox Conjunctivitis, Conjunctivitis: one to two drops every 2–4 h for  d, then one to two drops
Ophthalmic corneal abrasion if four times a day for  d. Corneal ulcer: one to two drops every  min while
Solution® a contact lens awake and one to two drops every 4–6 hours after retiring for  d, then one wearer to two drops every hour while awake for 5–7 days, then one to two drops four times a day for  d or until treatment completion
Polymyxin b Polytrim Conjunctivitis Do not use for One drop every  h sulfate, Ophthalmic corneal abrasion if a trimethoprim Solution® contact lens wearer sulfate
Gatifloxacin Zymaxid Conjunctivitis, One drop every  hrs while awake, up to  times/day for  days, then one
Ophthalmic corneal abrasion if drop  times per day for  days
Solution® a contact lens wearer
Antivirals Idoxuridine Dendrid Herpes simplex One drop every hour
Sterile keratitis
Ophthalmic
Solution®
Trifluridine Viroptic Herpes simplex One drop every  h
Ophthalmic keratitis
Solution®
Ganciclovir Zirgan Herpes simplex One drop five times per day
Ophthalmic keratitis
Gel®
Antibiotic–steroid Prednisolone Blephamide Conjunctivitis Do not use for Suspension: instill two drops into conjunctival sac every  h during the day combination acetate, Ophthalmic corneal abrasion if a and at bedtime sulfacetamide Suspension® contact lens wearer Ointment: apply ­in. ribbon into conjunctival sac three to four times a day sodium Brimonidine or if sulfa allergy and two to four times a night
Tartrate
Ophthalmic
Solution®
Dexamethasone, Maxitrol Conjunctivitis Do not use for Ointment:  inch in conjunctival sac(s) up to three to four times a day neomycin sulfate, Ophthalmic corneal abrasion if a Suspension: instill one to two drops four to six times a day up to every hour polymyxin b Ointment® contact lens wearer sulfate Maxitrol
Ophthalmic
Suspension®
Neomycin sulfate, Poly­Pred Conjunctivitis Do not use for One to two drops every 3–4 h polymyxin b Ophthalmic corneal abrasion if a sulfate, Suspension® contact lens wearer prednisolone acetate
Dexamethasone, TobraDex Conjunctivitis Do not use for Suspension: one to two drops every 4–6 h tobramycin Ophthalmic corneal abrasion if a ST: one drop every 4–6 h
Ointment® contact lens wearer Ointment: ­in. ribbon three to four times a day
TobraDex
Ophthalmic
Suspension®
TobraDex ST
Ophthalmic
Suspension®
Loteprednol Zylet Conjunctivitis Do not use for One to two drops every 4–6 h etabonate, Ophthalmic corneal abrasion if a tobramycin Suspension® contact lens wearer
NSAIDs Ketorolac Acular Allergic One drop four times a day for 3–4 d
Ophthalmic conjunctivitis,
Solution® corneal abrasions,
Acular LS UV keratitis
Ophthalmic
Solution®
Acular PF
Ophthalmic
Solution®
Acuvail
Ophthalmic
Solution®
Bromfenac Bromday Allergic One drop every day
Ophthalmic conjunctivitis,
Solution® corneal abrasions,
UV keratitis
Nepafenac Nevanac Allergic One drop three times a day
Ophthalmic conjunctivitis,
Suspension® corneal abrasions,
UV keratitis
Diclofenac Voltaren Allergic One drop four times a day sodium Ophthalmic conjunctivitis,
Solution® corneal abrasions,
UV keratitis
Mast cell stabilizers Nedocromil Alocril Allergic One to two drops twice a day sodium Ophthalmic conjunctivitis
Solution®
Pemirolast Alamast Allergic One to two drops four times a day potassium Ophthalmic conjunctivitis
Solution®
Lodoxamide Alomide Allergic One to two drops four times a day tromethamine Ophthalmic conjunctivitis
Solution®
Cromolyn Cromolyn Allergic One to two drops four to six times a day sodium Sodium conjunctivitis
Ophthalmic
Solution®
Selective H1 antagonists Bepotastine Bepreve Allergic One drop two times a day besilate Ophthalmic conjunctivitis
Solution®
Epinastine Elestat Allergic One drop two times a day hydrochloride Ophthalmic conjunctivitis
Solution®
Emedastine Emadine Allergic One drop up to four times a day difumarate Ophthalmic conjunctivitis
Solution®
Alcaftadine Lastacaft Allergic One drop every day
Ophthalmic conjunctivitis
Solution®
Azelastine Optivar Allergic One drop two times a day hydrochloride Ophthalmic conjunctivitis
Solution®
Combination mast cell Olopatadine Pataday Allergic One drop two times a day stabilizers–H1 antagonists hydrochloride Ophthalmic conjunctivitis
Solution®
Patanol
Ophthalmic
Solution®
Nonselective β­blocker Levobunolol Betagan Glaucoma .5%: one to two drops once a day; twice a day for more severe or
(may cause asthma) hydrochloride Ophthalmic uncontrolled glaucoma .25%: one to two drops twice a day
Solution®
Timolol Betimol Glaucoma One drop .25% twice a day; may increase to maximum of one drop .5% hemihydrate Ophthalmic twice a day
Solution®
Timolol maleate Istalol Glaucoma One drop once a day
Ophthalmic
Solution®
Timoptic
Sterile
Ophthalmic
Solution®
Timoptic­XE
Sterile
Ophthalmic
Gel Forming
Solution®
Carteolol Carteolol Glaucoma One drop twice a day hydrochloride Hydrochloride
Ophthalmic
Solution®
Ocupress
Ophthalmic
Solution®
Metipranolol OptiPranolol Glaucoma One drop two times a day
Ophthalmic
Solution®
Selective β1­blocker (safe Betaxolol Betaxolol Glaucoma One to two drops twice a day for COPD or asthma) hydrochloride Hydrochloride
Ophthalmic
Solution®
Betoptic S
Ophthalmic
Suspension®
Selective α2­agonists Brimonidine Alphagan P Glaucoma One drop every  h tartrate Ophthalmic
Solution®
Brimonidine
Tartrate
Ophthalmic
Solution®
Apraclonidine Iopidine .5% Glaucoma One to two drops three times a day hydrochloride Ophthalmic
Solution®
Iopidine
Ophthalmic
Solution®
Combination α2­ agonist– Brimonidine Combigan Glaucoma One drop every  h nonselective β­blocker tartrate, timolol Ophthalmic maleate Solution®
Carbonic anhydrase Brinzolamide Azopt Glaucoma One drop three times a day inhibitors Ophthalmic
Suspension®
Dorzolamide Trusopt Glaucoma One drop three times a day hydrochloride Sterile
Ophthalmic
Solution®
Combination carbonic Dorzolamide Cosopt Sterile Glaucoma One drop every  h anhydrase inhibitor– hydrochloride, Ophthalmic selective β­blocker timolol maleate Solution®
Cholinergic agents Pilocarpine Isopto Glaucoma; Two drops three to four times a day hydrochloride Carpine contraindicated in
Ophthalmic pupillary block
Solution® glaucoma
Prostaglandin analog Bimatoprost Lumigan Glaucoma One drop once a day
Ophthalmic
Solution®
Travoprost Travatan Z Glaucoma One drop once a day
Ophthalmic
Solution®
Latanoprost Xalatan Glaucoma One drop once a day
Ophthalmic
Solution®

## Page 26

Loteprednol Alrex Allergic One drop four times a day etabonate Ophthalmic conjunctivitis,
Suspension® uveitis
Difluprednate Durezol Allergic One drop four times a day
Ophthalmic conjunctivitis,
Emulsion® uveitis
Fluorometholone Flarex Allergic One to two drops four times a day acetate Ophthalmic conjunctivitis,
Suspension® uveitis
FML Forte
Ophthalmic
Suspension®
FML
Ophthalmic
Ointment®
FML
Ophthalmic
Suspension®
Loteprednol Lotemax Allergic Ointment:  in. four times a day etabonate Ophthalmic conjunctivitis, Suspension: one to two drops four times a day
Ointment® uveitis
Lotemax
Ophthalmic
Suspension®
University of Pittsburgh
Prednisolone Omnipred Allergic Two drops four times a day acetate Ophthalmic conjunctivitis, Access Provided by:
Suspension® uveitis
Pred Forte
Ophthalmic
Suspension®
Pred Mild
Ophthalmic
Suspension®
Rimexolone Vexol 1% Allergic One to two drops every hour while awake
Ophthalmic conjunctivitis,
Suspension® uveitis
Note: Blue­eyed individuals are sensitive to mydriatics and cycloplegics and tend to have a longer duration of action, whereas brown­eyed individuals may require a double dose for adequate mydriasis.
Abbreviations: COPD = chronic obstructive pulmonary disease; UV = ultraviolet.
THE RED EYE
The differential diagnosis of the red eye is extensive. Key differentiating factors are the presence or absence of pain, itching, photophobia, systemic symptoms, discharge and injections, visual loss, and changes in the cornea, pupils, and intraocular pressure. Table 241­3 lists various causes of the red eye with key differentiating features. Many of these conditions are discussed more extensively in the text.
TABLE 241­3
Differential Diagnosis of the Red Eye
Diagnosis Pain Itching Photophobia Systemic Symptoms Visual Acuity Discharge Injection Cornea Pupils IOP
Chalazion Mild­ No No No Normal No Minimal Normal Normal Normal moderate localized lid
Hordeolum Mild­ No No No Normal No Minimal Normal Normal Normal moderate localized lid
Blepharitis Mild, Yes Yes No Normal Morning Diffuse Normal Normal Normal foreign crusting, body tearing sensation
Dacryocystitis Mild­ No No Fever if severe Normal No Localized Normal Normal Normal moderate medial canthus
Ectropion Irritation No No No Normal Watery Lid margin Normal Normal Normal and diffuse
Corneal Yes No No unless No Normal unless Watery Diffuse Visible abrasion Normal or Normal abrasion associated iritis central or with constricted
(after several associated with hours) iritis associated iritis
Ultraviolet Severe No No unless No Decreased Watery Diffuse Punctate lesions Normal or Normal keratitis associated iritis constricted
(after several with hours) associated iritis
Superficial Mild No No No Normal Watery Diffuse Punctate lesions Normal Normal keratitis
Corneal ulcer Moderate No No No No unless Watery Diffuse Visible ulcer Normal Normal central or with associated
 iritis
Chapter 241: Eye Emergencies, Richard A. Walker; Srikar Adhikari 
. Terms of Use * Privacy Policy * Notice * Accessibility
Corneal foreign Moderate No No No Normal unless Watery Diffuse Visible foreign body Normal Normal body central
Chemical burn Moderate­ No No No Normal unless Watery Diffuse— Cloudy if severe Normal Normal severe central none with severe alkaline burn
Bacterial None or No No No Normal Purulent Diffuse Normal, punctate Normal Normal conjunctivitis irritation bulbar and lesions if associated palpebral keratitis
Viral None or No No Occasional URI Normal Watery Diffuse Normal, punctate Normal Normal conjunctivitis irritation, symptoms, fever with bulbar and lesions if associated severe with EKC palpebral keratitis
EKC
Allergic None Yes No Sneezing, rhinorrhea Normal Watery Diffuse Normal Normal Normal conjunctivitis bulbar and palpebral
Stevens­ Foreign Yes Yes Fever, tachycardia, Decreased Watery Diffuse Punctate lesions, — —
Johnson body hypotension, skin and corneal ulcer, syndrome sensation, mucous membranes neovascularization, burning involved hazy, perforation
Orbital cellulitis Pain with No No Fever Normal, No Yes Normal Normal Occasionally eye decreased late increased movement
Preseptal Mild—no No No Fever Normal No Yes Normal Normal Normal cellulitis pain with eye movement
Episcleritis Mild No No Usually none; Normal Watery Focal Normal Normal Normal occasional rheumatologic symptoms
Scleritis Severe, No No Usually none; Decreased Watery Diffuse, Normal Normal Normal, tender to occasional with advanced occasionally may be palpation rheumatologic disease violaceous increased symptoms color
Subconjunctival None No No No Normal No No Normal Normal Normal hemorrhage
Iritis/uveitis Yes No Yes Occasional Decreased Watery Perilimbal Normal, flare and cells Constricted, Usually rheumatologic or GI (ciliary) in anterior chamber poorly normal, symptoms flush reactive may be low
Acute angle­ Severe No No Headache, nausea, Decreased Watery Diffuse Cloudy or hazy Midpoint, Increased closure vomiting poorly glaucoma reactive
Endophthalmitis Mild­ No Yes Fever Decreased Purulent if Diffuse Hazy, flare and cells — — moderate present anterior chamber,
“ache” hypopyon
Abbreviations: EKC = epidemic keratoconjunctivitis; IOP = intraocular pressure; URI = upper respiratory infection.
OCULAR INFECTIONS AND INFLAMMATION
PRESEPTAL (PERIORBITAL) AND POSTSEPTAL (ORBITAL) CELLULITIS
COMMON PRESENTATION
Orbital and periorbital infections exist in a spectrum of increasing severity: preseptal (periorbital) cellulitis, postseptal (orbital) cellulitis, subperiosteal abscess, orbital abscess, and cavernous sinus thrombosis, from least to most severe. Preseptal cellulitis and postseptal cellulitis, although both of an infectious etiology and involving periocular tissues, are very different entities with different morbidities. Preseptal cellulitis (periorbital cellulitis) is an infection of the eyelids and periocular tissues that is anterior to the orbital septum. It is generally benign and may be treated in the outpatient setting. Postseptal cellulitis (orbital cellulitis) is an infection of the orbital soft tissues posterior to the orbital septum. It may be life and vision threatening and must be treated as an inpatient with IV antibiotics and occasionally surgical drainage. Endophthalmitis is an infection of the globe and is a completely separate entity.
The outward appearance of the patient with postseptal cellulitis may be very similar to that of the patient with preseptal cellulitis. Preseptal and postseptal cellulitis may both display excessive tearing, fever, erythema, edema, warmth, and tenderness to palpation of the lids and periorbital soft tissues.2 Laboratory studies do not discriminate between the two conditions, and blood cultures are not helpful. Contrast­enhanced CT scan of the orbits and sinuses differentiates the two conditions and identifies complications.3 A misdiagnosis can result in significant neurologic disability and death. The differential diagnosis for preseptal and postseptal cellulitis is listed in Table 241­4. TABLE 241­4
Differential Diagnosis of Preseptal and Postseptal Cellulitis
Preseptal cellulitis
Postseptal cellulitis
Subperiosteal abscess
Orbital abscess
Cavernous sinus thrombosis
Dacryoadenitis
Dacryocystitis
Hordeolum
Bacterial and viral conjunctivitis
Contact dermatitis
Herpes zoster
Herpes simplex
PRESEPTAL CELLULITIS
Preseptal cellulitis is usually associated with upper respiratory tract infections, especially paranasal sinusitis, and may result from eyelid problems such as hordeolum, chalazion, insect bites, and trauma. Preseptal cellulitis is primarily a disease of childhood, with most patients <10 years of age. The most common organisms are Staphylococcus aureus and Staphylococcus epidermidis, Streptococcus species, and anaerobes. Since the introduction of the Haemophilus influenzae type B vaccine, H. influenzae has become a rare cause of preseptal cellulitis in children.
Upper respiratory symptoms, low­grade fever, redness and swelling of the eyelid, and excessive tearing (epiphora) are signs and symptoms of preseptal cellulitis. The eye itself is not involved, and visual acuity and pupillary reaction are maintained, and full painless ocular motility is preserved. Exam may require lid retractors to uncover a normal globe.
CT scan of the orbit is not necessary for uncomplicated cases of preseptal cellulitis; however, when there is decreased ocular motility or other signs of orbital involvement, or when examination is unreliable, obtain a CT scan of the orbits with contrast. MRI is also an option.
The nontoxic adult patient and older child with mild preseptal cellulitis may be managed as outpatients with oral antibiotics (amoxicillin/clavulanic acid or a first­generation cephalosporin), hot packs, and close follow­up in  to  hours. Obtain ophthalmology consultation and consider admission with severe preseptal cellulitis or when orbital cellulitis cannot be ruled out (see
Chapter 122, “Eye Emergencies in Infants and Children”).
POSTSEPTAL OR ORBITAL CELLULITIS
Postseptal cellulitis occurs most frequently from the spread of paranasal sinusitis. The ethmoid sinus is most frequently implicated, probably due to perforation of the thin lamina papyracea. Trauma, intraorbital foreign body, spread of periorbital skin infection, seeding from bacteremia, and ocular surgery are also predisposing factors. The infection is often polymicrobial, with S. aureus, Streptococcus pneumoniae, and anaerobes being most common; however, H. influenzae should be considered in unimmunized young children and mucormycosis in diabetics and immunocompromised patients.3
Orbital cellulitis presents with gradual onset of upper respiratory symptoms, including rhinitis, facial pressure, and fever. Physical exam may demonstrate pain with eye movement, limitation of extraocular muscle movement, chemosis, proptosis, abnormal pupillary response, and decreased visual acuity. Headache and fever in association with deficits of cranial nerves III, IV, or VI suggest cavernous sinus thrombosis.4
Consult ophthalmology immediately for patients with clear clinical or CT evidence of postseptal cellulitis. Postseptal cellulitis may lead to vision loss and requires an aggressive approach with hospitalization and institution of IV antibiotics (see Chapter 122, “Eye Emergencies in Infants and Children”). Antibiotics should be broad spectrum with both aerobic (including coverage for methicillin­resistant S. aureus) and anaerobic coverage. Choices include vancomycin plus a third­generation cephalosporin, piperacillin­tazobactam, ticarcillin­clavulanate, imipenem, or meropenem.5Metronidazole or clindamycin is added for anaerobic coverage.5 Adjuvant therapy includes a topical nasal decongestant such as oxymetazoline. Consider emergent lateral canthotomy if the intraocular pressure is elevated or an optic neuropathy is present.5 Patients with orbital abscess require operative drainage and debridement in addition to antibiotics.
Complications include cavernous sinus thrombosis, frontal bone osteomyelitis, meningitis, subdural empyema, epidural abscess, and brain abscess that should be evident on CT or MRI scan.
LIDS
STYE (EXTERNAL HORDEOLUM)
A stye is an acute bacterial infection (usually Staphylococcus) of the follicle of an eyelash and adjacent sebaceous glands (Zeis) or sweat glands (Moll). It is located at the lash line and has the appearance of a small pustule at the margin of the eyelid (Figure 241­24). An internal hordeolum is an acute bacterial infection of the meibomian glands associated with the eyelashes.
Signs and symptoms are similar to a stye except that the pustule occurs on the inner surface of the tarsal plate. Signs and symptoms include pain, edema, and erythema of the eyelid. Warm compresses and erythromycin ophthalmic ointment twice daily for  to  days are usually sufficient treatment. Removal of the offending eyelash could be considered. Systemic antibiotics may be necessary if there is significant surrounding cellulitis. Should incision and drainage be considered, refer to an ophthalmologist.6
FIGURE 241­24. External hordeolum. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
CHALAZION
A chalazion is an acute or chronic inflammation of the eyelid secondary to blockage of one of the meibomian or Zeis oil glands in the tarsal plate (Figure 241­25). The condition tends to be subacute to chronic and is associated with a (usually) painless lump that develops in the lid or at the lid margin, occasionally with mild erythema. Clinical differentiation of an acute chalazion from an internal hordeolum may be impossible, but treatment is the same. Treatment of chronic or recurrent chalazia may require injection of corticosteroids into the lesion or incision and curettage/drainage depending on the size.6 Refer to an ophthalmologist in  to  weeks.
FIGURE 241­25. Chalazion. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
BLEPHARITIS
Blepharitis is a common cause of prolonged red eye due to inflammation of the eyelash follicles along the edge of the eyelid. The most common cause is overgrowth of S. epidermidis, and the inflammation is largely a reaction to the deltalike toxin produced by the bacteria. The disorder is associated with seborrheic dermatitis, atopic dermatitis, and occasionally eyelash infestation with lice or infection with S. aureus. Typical symptoms include conjunctival injection; crusting, swollen, pruritic eyelids; and occasional complaint of eye pain. It is most commonly treated with careful daily cleansing of the edges of the eyelids and eyelashes. In severe cases, antibiotic drops or ointment at night may be required.6
CONJUNCTIVITIS
Conjunctivitis is an inflammatory condition of the conjunctiva and is a common cause of the red eye. It is usually viral in etiology and is a benign self­limited condition. The task is to sort out the occasional case of serious bacterial infection or corneal herpetic involvement that may result in vision loss without aggressive treatment. Causes of conjunctivitis are viral, bacterial (including gonococcal and chlamydial), parasitic, or fungal infections and allergic, toxic, or chemical irritation. Keratoconjunctivitis is the term used to indicate corneal involvement, usually in the form of punctate ulcerations.
Bacterial Conjunctivitis
Symptoms of bacterial conjunctivitis are painless, unilateral, or bilateral mucopurulent discharge (Figure 241­26), frequently causing adherence of the eyelids on awakening. The conjunctiva is injected, and the cornea is clear without fluorescein staining. Chemosis (edema of the conjunctiva) is common, and preauricular lymphadenopathy is usually absent, except in gonococcal infections. Typical pathogens are Staphylococcus and Streptococcus species. Perform fluorescein stain of the cornea (especially in infants) to avoid missing a corneal abrasion, ulcer, or herpetic dendrite. Consider culture and sensitivity of the discharge in severe cases. Cases are frequently self­limited, but antibiotic treatment shortens course of symptoms.7
Trimethoprim–polymyxin B is very effective and avoids potential allergies to sulfa and neomycin preparations. Wearers of soft contact lenses should be treated with a fluoroquinolone
(besifloxacin, gatifloxacin, levofloxacin, moxifloxacin, or ofloxacin) or aminoglycoside (tobramycin) to treat Pseudomonas.8Gentamicin is seldom used because of the high incidence of ocular irritation.
FIGURE 241­26. Bacterial conjunctivitis. Note the mucopurulent discharge, conjunctival injection, and lid edema in a pediatric patient with Haemophilus influenzae conjunctivitis. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New York.]
Gonococcal conjunctivitis is a cause of ophthalmia neonatorum, and chlamydial conjunctivitis is also a disease of the newborn (see Chapter 122, “Eye Emergencies in Infants and
Children,” for discussion of ophthalmia neonatorum and chlamydial conjunctivitis).
Viral Conjunctivitis
The most common cause of viral conjunctivitis is adenovirus. Epidemic keratoconjunctivitis (Figure 241­27) is a more severe type of adenovirus infection that is highly contagious and tends to occur in epidemics. Cough, high fever, malaise, and myalgias may precede epidemic keratoconjunctivitis. Symptoms are marked eye redness, photophobia, foreign body sensation, and tearing. Physical examination findings are similar to viral conjunctivitis, except they are more severe. Several systemic viral diseases, such as measles, influenza, and mumps, may also cause conjunctival injection. Viral keratoconjunctivitis may be caused by herpes simplex and herpes zoster (see “Cornea” section later in this chapter).
FIGURE 241­27. Epidemic keratoconjunctivitis (EKC). Diffuse bulbar conjunctival injection and inferior palpebral papillae as seen in EKC. The erythema is usually much more intense than in this photo.
[Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New York.]
An upper respiratory infection may precede viral conjunctivitis. Symptoms include a complaint of “red eye” and mild to moderate watery discharge. There is no eye pain unless there is some degree of keratitis. Generally, one eye will be involved initially, with the other eye becoming involved within days. Physical examination reveals unilateral or bilateral conjunctival injection, occasional chemosis and small subconjunctival hemorrhages, and preauricular lymphadenopathy. Slit lamp examination demonstrates follicles (small, regular, translucent bumps) on the inferior palpebral conjunctiva (Figure 241­27). Punctate fluorescein staining represents keratitis (Figure 241­28). Make sure to examine the cornea with fluorescein to avoid missing a herpetic dendrite.
FIGURE 241­28. Fluorescein stain demonstrating punctate staining as seen with epithelial keratitis in epidemic keratoconjunctivitis. The keratitis is usually much more widespread than demonstrated here.
[Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New York.]
Treatment of viral conjunctivitis consists of cool compresses; ocular decongestants such as Naphcon­A®, one drop three times daily as needed for redness and conjunctival congestion; and artificial tears five or six times a day. Viral conjunctivitis can take  to  weeks to run its course and is very contagious. Instruct the patient to wash hands frequently and use separate towels.
The examiner should wear gloves to avoid self­contamination, and the slit lamp, exam table, and exam chair should be disinfected after patient contact. If, after a history and physical examination, it is still uncertain if the conjunctivitis is viral or bacterial, prescribe ocular antibiotics until the patient is reexamined by an ophthalmologist.
Allergic Conjunctivitis
Allergens can cause watery discharge, redness, and itching. Physical findings may include erythematous swollen eyelids and injected and edematous conjunctiva with papillae (irregular mounds of tissue with a central vascular tuft) on the inferior conjunctival fornix (Figure 241­29). Try to identify and eliminate the offending allergen. Treatment is cool compresses four times daily and topical drops, depending on the severity of symptoms. Mild symptoms may be treated with artificial tears alone. Moderate symptoms may require a topical antihistamine/decongestant, mast cell stabilizers, or NSAIDs. Severe symptoms may justify the use of topical steroids. However, we generally recommend against the use of ocular steroids by nonophthalmologists because occult herpetic infection is always a possibility (see following section on herpes simplex virus infection of the cornea). Should ocular steroids be chosen as a treatment option, consult an ophthalmologist first.
FIGURE 241­29. Prominent chemosis may be seen in allergic conjunctivitis. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New
York.]
SUBCONJUNCTIVAL HEMORRHAGE
The fragile conjunctival vessels can rupture from trauma, sudden increased venous pressure related to Valsalva maneuvers (sneezing, coughing, vomiting, straining), hypertension, or spontaneously (Figure 241­30). The eye examination is normal other than the presence of the subconjunctival hemorrhage. Reassurance is the only treatment necessary, and the hemorrhage usually resolves within  weeks. For multiple recurrent episodes, coagulation studies and further investigation are warranted.
FIGURE 241­30. Spontaneous subconjunctival hemorrhage. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
CORNEA
HERPES SIMPLEX KERATOCONJUNCTIVITIS
Herpes simplex virus can affect the eyelids, conjunctiva, and cornea. The patient may give a history of oral or genital herpes infection and complain of photophobia, pain (which may be mild), eye redness, and decreased vision. The eyelid may have the typical herpetic vesicular eruptions. The infection tends to be unilateral with a palpable preauricular node. The conjunctiva can be injected, but ocular herpes simplex frequently presents with only corneal findings on physical examination. The dendrite of herpes keratitis is an epithelial defect that can be seen with fluorescein staining and classically has a linear branching pattern with terminal bulbs (Figure 241­31), or may be a “geographic ulcer,” which is an amoeba­shaped ulceration with dendrites at the edge. Herpetic infection may be very difficult to diagnose, as infection may present as involvement of the cornea with a neurotrophic ulceration, which is a smooth­edged ulcer over an area of underlying stromal disease; as stromal edema and/or white infiltrates with intact epithelium and an associated mild iritis with keratitic precipitates; or as an isolated uveitis, without epithelial or stromal involvement and with an elevated intraocular pressure. Corneal sensation may be decreased and should be checked before instillation of anesthetic drops.
FIGURE 241­31. Herpes simplex corneal dendrite in an infant seen with fluorescein staining. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
Herpes simplex keratitis can progress to corneal scarring and requires prompt treatment with topical antiviral agents. An initial outbreak of herpes simplex virus involving the lids is treated with an oral acyclovir derivative such as acyclovir (Zovirax®), 500 milligrams five times daily, or famciclovir (Famvir®), 500 milligrams three times daily.9 For conjunctival involvement, prescribe topical trifluridine (Viroptic®),9 one drop nine times a day. Idoxuridine (Dendrid®), one drop every  hour during the day and every  hours at night, can be substituted for those who are allergic to trifluridine. Erythromycin ophthalmic ointment can be added to prevent secondary infection. Do not prescribe topical steroids, and refer patients to an ophthalmologist in  to  hours.
HERPES ZOSTER OPHTHALMICUS
Herpes zoster ophthalmicus is shingles involving the first division (V1) of the trigeminal nerve distribution with ocular involvement. The rash usually does not cross the midline and involves only the upper eyelid, although rarely, the cheek (V2) and mandible (V3) may be affected. Involvement of the nasociliary nerve is associated with cutaneous lesions on the tip of the nose (Hutchinson sign) and predicts a high likelihood of ocular involvement. Symptoms that may precede the rash are pain and paresthesias in a dermatomal distribution; fever, headache, and malaise; and red eye, blurred vision, and eye pain/photophobia. Eye involvement may take the form of epithelial keratitis, stromal keratitis, uveitis, retinitis, and choroiditis. Optic neuritis and other cranial nerve palsies may occur, as well as elevated intraocular pressure. The cornea can have a pseudodendrite, which is a poorly staining mucous plaque with no epithelial erosion (unlike herpes simplex virus, which has a true dendrite with epithelial erosion and staining). The anterior chamber on slit lamp examination can show the cells and flare of iritis. Consider the possibility of associated immunocompromise in patients <40 years old.
Skin involvement is treated with cool compresses, and patients presenting with a rash for <1 week should be treated with oral antiviral medications for  to  days. Choices include acyclovir,
800 milligrams five times a day; famciclovir, 500 milligrams three times a day; or valacyclovir, 1000 milligrams three times a day.10 Treat cutaneous lesions with bacitracin or erythromycin ointment to prevent secondary bacterial infection. Treat conjunctivitis with erythromycin ophthalmic ointment twice a day. Treat iritis with topical steroids such as prednisolone acetate 1%, one drop four to five times a day, but consultation with an ophthalmologist is recommended first. Consider topical cycloplegic agents (cyclopentolate 1%, one drop three times daily) for patients with significant pain. Consider admission and IV acyclovir when the orbit, optic nerve, or cranial nerves are involved, or if the patient is immunocompromised. See Chapter 250, “Skin
Disorders: Face and Scalp,” for additional discussion.
CORNEAL ULCER
A corneal ulcer is a serious infection involving multiple layers of the cornea and develops secondary to breaks in the epithelial barrier, so that infectious agents invade the underlying corneal stroma. The initial disruption of the epithelial layer can be due to desquamation, trauma, or direct microbial invasion. Exposure keratitis from incomplete lid closure secondary to
Bell’s palsy can cause corneal desiccation and sloughing of the epithelium, allowing bacteria to gain access to the underlying stroma and create an ulcer. Trauma can also breach the epithelium and inoculate the cornea. S. pneumoniae and S. aureus are common causes of corneal ulceration. Contact lens users can develop Pseudomonas infection (Table 241­5). Wearing of soft contact lenses is a very common cause of corneal ulcers, and the incidence increases dramatically in those who use extended­wear lenses and wearers who sleep with them in place.
Fungi and viruses have also become a more common cause of corneal ulcer due to the widespread use of both topical and systemic immunosuppressant medications.
TABLE 241­5
Causative Organisms in Corneal Ulcer
Bacteria
Pseudomonas aeruginosa
Streptococcus pneumoniae
Staphylococcus species
Moraxella species
Viruses
Herpes simplex
Varicella zoster
Fungi
Candida
Aspergillus
Penicillium
Cephalosporium (Acremonium)
Collect a history of predisposing factors including the use of contact lenses, previous ocular surgery or injury, recent trauma, and presence or history of genital herpes, topical or systemic steroids, or other immunosuppressants. Redness and swelling of lids and conjunctivae, discharge from the eye, ocular pain or foreign body sensation, photophobia, and blurred vision are common complaints. Visual acuity is decreased if the ulcer is located in the central visual axis or if uveal tract inflammation is present. The eyelids and conjunctiva may be erythematous with a mucopurulent discharge. Associated iritis may cause a miotic pupil and consensual photophobia due to ciliary spasm. Examination of the cornea reveals a round or irregular ulcer with a white, hazy base extending into the underlying stroma due to WBC infiltration, or with heaped­up edges (Figure 241­32). Slit lamp examination reveals flare and cells from iritis and occasionally a hypopyon.
FIGURE 241­32. Corneal ulcer is seen at  o’clock. (Photo contributor: Kevin J. Knoop, MD, MS.)
The diagnosis is clinical. The ophthalmologist typically scrapes the center of the ulcer to culture the offending organism. Table 241­5 lists the differential diagnosis of causative organisms.
Treat corneal ulcers aggressively with topical antibiotics. Emergent ophthalmologic consultation for culture of the ulcer and institution of appropriate antibiotics should be considered. Once cultures are obtained, topical antibiotics are started. A fluoroquinolone such as ciprofloxacin (Ciloxan®) or ofloxacin (Ocuflox®), one drop every hour in the affected eye, is the current recommended treatment. If the suspicion is high for a fungal infection, a topical antifungal medication (e.g., natamycin, amphotericin B, or fluconazole)11 should be given at the direction of an ophthalmologist who may consider intrastromal injections of antifungal medication.12
Cycloplegic drops such as cyclopentolate 1% are often used due to pain from accompanying iritis. Topical steroids are relatively contraindicated in viral infections but may decrease the incidence of scarring and perforation. Steroid eye drops should not be initiated by the emergency physician unless advised to do so by the ophthalmologist. Do not patch the eye because of the risk of Pseudomonas infection, which can cause rapid, aggressive ulceration with corneal melting and perforation. Refer patients with corneal ulcers to an ophthalmologist to be seen within  to  hours. Complications of corneal ulcers include corneal scarring, corneal perforation, development of anterior and posterior synechiae, glaucoma, and cataracts.
ULTRAVIOLET KERATITIS (PHOTOKERATITIS)
Intense light in the ultraviolet range from any source can cause death of corneal epithelial cells. Classically described as “snow blindness,” when due to reflected ultraviolet light from the sun, ultraviolet keratitis is also caused by unprotected exposure to arc welders (“welder’s flash”), tanning beds, or industrial ultraviolet lighting. Ultraviolet keratitis may occur if protective glasses are not applied tightly to the face, allowing light to hit the cornea obliquely. Effects are cumulative, so multiple short exposures are the same as one long exposure. Corneal cells do not die immediately, so symptoms develop after a delay of up to  to  hours with slow onset of foreign body sensation and mild photophobia, progressing to severe pain and photophobia.
Patients sometimes are awakened from sleep after midnight by pain. Physical examination may reveal blepharospasm, conjunctival injection, and prominent tearing. Topical anesthetic drops are often required to complete the eye examination. Slit lamp examination reveals diffuse punctate corneal edema, and instillation of fluorescein reveals diffuse punctate corneal abrasionlike lesions. Treatment includes oral analgesics and topical antibiotics (erythromycin) to provide lubrication.13 If photophobia is prominent, cycloplegics such as cyclopentolate can be used
(see Table 241­2). Patching the eye does not speed healing.14 Healing occurs in  to  hours. Follow­up with ophthalmology is recommended for moderate to severe cases.
UVEAL TRACT
UVEITIS/IRITIS
Iritis is inflammation of the anterior segment of the uveal tract (anterior uveitis). Systemic inflammatory diseases are the most common causes in the United States15; infections, such as tuberculosis, are most common in Asia (Table 241­6).16 Iritis is not a true ocular emergency but does require prompt follow­up by an ophthalmologist. Irritation of the ciliary nerves and ciliary muscle spasm cause the pain of iritis. Photophobia is often marked. Keratitic precipitates are deposits of inflammatory cells on the corneal endothelium. A proteinaceous transudate from uveal vessels occurs in the anterior chamber and causes flare seen with the slit lamp. WBCs released from the uveal vessels may be seen in the anterior chamber with the slit lamp and are termed cells (as in “flare and cells”). Cells appear as snowflakes in a headlight beam at night.
Clinical Features and Diagnosis
The patient will complain of unilateral pain, although the pain may be bilateral with systemic disease. There may be complaints of conjunctival injection, photophobia, and decreased vision.
There is usually no discharge. Complaints of systemic symptoms, including arthritis, urethritis, and recurrent GI symptoms, are common when the cause is systemic inflammatory disease.
Collect past medical history to include exposure to tuberculosis, history of genital herpes, or history of previous similar symptoms, and the associated diagnosis. Ask about recent trauma or exposure to welding without protective goggles.
Inspection of the eye may reveal a perilimbal flush (injection is greatest around the limbus) or diffuse conjunctival injection without mucopurulent discharge. Photophobia is usually present.
Consensual photophobia (shining light on the unaffected eye causes pain in the affected eye) is highly suggestive of iritis. The pupil is usually miotic and poorly reactive.
Visual acuity may be decreased with severe inflammation and clouding of the aqueous humor. Slit lamp examination will reveal flare and cells in the anterior chamber, culminating in a hypopyon with severe disease. Intraocular pressure may be decreased if the ciliary body is involved secondary to decreased production of aqueous humor. Fluorescein staining of the cornea may show abrasions, ulcerations, or dendritic lesions.
The diagnosis of iritis is based on the typical history and the finding of flare and cells in the anterior chamber on slit lamp examination.
TABLE 241­6
Differential Diagnosis of Iritis (Anterior Uveitis)
Systemic diseases
Juvenile rheumatoid arthritis
Ankylosing spondylitis
Ulcerative colitis
Reiter syndrome
Behçet’s syndrome
Sarcoidosis
Infectious
Tuberculosis
Lyme disease
Herpes simplex
Toxoplasmosis
Varicella zoster
Syphilis
Adenovirus
Malignancies
Leukemia
Lymphoma
Malignant melanoma
Trauma/environmental
Corneal foreign body
Posttraumatic (blunt trauma)
Ultraviolet keratitis
Treatment
The treatment of iritis depends on the underlying cause. If infection is suspected based on systemic symptoms, testing should be directed at identifying the infection, and ophthalmology should be consulted for management.17 If an acute or chronic inflammatory condition is suspected, treatment can be directed to the eye with referral to ophthalmology. Blocking the pupillary sphincter and ciliary body with a long­acting cycloplegic agent, such as homatropine (duration  to  days) or tropicamide (duration  hours), will decrease pain.17 Refer the patient to an ophthalmologist in  to  hours for topical corticosteroids and further management.18
VITREOUS HUMOR
ENDOPHTHALMITIS
Endophthalmitis is inflammation (usually infectious) of the aqueous or vitreous humor that frequently leads to loss of vision. The most frequent cause is postsurgical, followed by penetrating ocular injuries and, rarely, hematogenous spread. History may include ocular surgery, hammering with steel, working with high­speed machinery such as grinders or weed whackers, or ocular trauma. Symptoms may include headache, eye pain, photophobia, vision loss, and ocular discharge. Physical examination may reveal erythema and swelling of the lids, conjunctival and scleral injection, chemosis, hypopyon, and evidence of uveitis. If suspected, immediate ophthalmologic consultation is required.8 Treatment may include aspiration of the vitreous or pars plana vitrectomy and administration of intravitreal antibiotics and steroids, in addition to systemic antibiotics. Admission is required except for postoperative cases.
VITREOUS DETACHMENT AND HEMORRHAGE
The vitreous is avascular and attached firmly to the anterior eye at the ora serrata, posteriorly at the optic nerve head, and along the major retinal vessels. Liquefaction of the vitreous can cause detachment from the retina, with or without accompanying hemorrhage. Symptoms are sudden onset of floaters, especially with eye movement. Traction at vascular areas due to trauma or pathologic neovascularization can cause vitreous hemorrhage. The most common causes of vitreous hemorrhage are proliferative diabetic retinopathy, posterior vitreous detachment in the elderly, and ocular trauma such as shaken baby syndrome in infants. An unusual cause is subhyaloid hemorrhage associated with subarachnoid hemorrhage. History includes sudden painless vision loss and sudden appearance of black spots, cobwebs, or generalized unilateral hazy vision. Past medical history may include diabetes or sickle cell disease. Examination of the retina of the affected eye may be impossible due to the hemorrhage. Examination of the contralateral retina may give clues to the diagnosis. Important differential diagnoses include sickle cell disease, diabetic retinopathy, retinal detachment, central retinal vein occlusion, subarachnoid hemorrhage, and lupus erythematosus. Consult ophthalmology if the diagnosis is suspected.19 Check the INR of patients receiving warfarin (Coumadin®) and withhold antiplatelet therapy. Ocular US can rule out retinal detachment (see later section on US).
TRAUMA TO THE EYE
CONJUNCTIVAL ABRASION, LACERATION, AND FOREIGN BODY
The conjunctiva has less innervation than the cornea, so conjunctival abrasions are far less symptomatic than corneal abrasions. The patient may complain of a scratchy foreign body sensation, mild pain, tearing, and, rarely, photophobia. Vision should not be affected unless there is a full­thickness conjunctival laceration with globe penetration. Physical examination may reveal mild conjunctival injection or subconjunctival hemorrhage. A conjunctival abrasion is seen with fluorescein staining.
Conjunctival lacerations may bleed, the edges of the bulbar conjunctiva may retract with underlying sclera visible to the naked eye, and fluorescein stain may pool in the defect. Perform the Seidel test to exclude globe perforation. The Seidel test can be negative if a full­thickness laceration is small or has spontaneously closed. Inspect the conjunctiva for a foreign body. Conjunctival foreign bodies usually can be removed with a moistened, cotton­tipped applicator after anesthetizing the eye with a topical anesthetic. Evert the upper eyelid and inspect under the highest magnification available to avoid missing any additional foreign bodies. Frequently, small wooden particles such as sawdust will blend into the conjunctiva when moistened by the tears and be difficult to find without slit lamp magnification.
Superficial conjunctival abrasions and lacerations without any other associated ocular injury only require erythromycin ophthalmic ointment .5% four times a day for  to  days or no treatment if very small. Suturing of lacerations is almost never required. Any suspicion of globe laceration requires immediate ophthalmologic referral.
CORNEAL ABRASION, LACERATION, AND FOREIGN BODY
The corneal epithelium is fragile and easily damaged. It is richly innervated and therefore very painful when injury occurs. Corneal epithelium regenerates quickly, so healing time for abrasions is short, usually within  to  hours. Intact corneal epithelium is resistant to infection, but damaged epithelium is a portal of entry for bacteria, viruses, and fungi. Most abrasions not treated immediately will develop an associated inflammatory iritis.
CORNEAL ABRASION
Abrasions may be caused by contact lens wear, fingernails, makeup brushes, and foreign objects blown into eyes while driving or on windy days or that drop into the eye while working overhead (construction) or under a car (mechanics). Injury to the cornea causes intense pain that may be delayed several hours after the inciting event. Initial symptoms are a foreign body sensation, photophobia, and tearing. Ask about the work environment and the mechanism of injury if known, because corneal abrasions sustained using high­speed machinery, such as grinders, lawn mowers, or weed whackers, and hammering metal against metal are associated with corneal laceration and perforation of the globe.
Clinical Features
Inspection of the eye may reveal conjunctival injection, tearing, and lid swelling. Blepharospasm may occur with severe pain, requiring a topical anesthetic to accomplish the examination and obtain the visual acuity. Relief of pain with topical anesthesia is virtually diagnostic of corneal abrasion. Photophobia may be evident when shining a light into the affected or the opposite eye.
Decreased visual acuity may occur if the abrasion is in the central visual axis or if there is an associated iritis, but otherwise, vision should be normal. The corneal abrasion is often visible to the naked eye as an irregular area of light reflection off the cornea.
Diagnosis
Slit lamp examination may show flare and cells from iritis if the abrasion is large and >24 hours old, but there is no corneal infiltrate. Examine the entire thickness of the cornea for fullthickness laceration. The Seidel test should be negative. The abrasion usually appears as a superficial, irregular corneal defect appearing bright green under the cobalt blue light after instillation of fluorescein (Figure 241­33). A series of small, fine­lined vertical corneal abrasions seen with fluorescein staining suggests the presence of a foreign body embedded in the tarsal conjunctiva of the upper lid. Multiple linear corneal abrasions or punctate keratitis also suggests a retained foreign body under the upper lid.
FIGURE 241­33. Corneal abrasion. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New York.]
Some slit lamps (Haag­Streit) have a measuring dial attached to the mechanism that varies the length of the slit beam. If your slit lamp is equipped with this feature, you can vary the length of the slit beam on the cornea until it corresponds to the length or width of the abrasion. The reading on the wheel equals the length of the slit beam in millimeters. This additional feature allows you to document the dimensions of the abrasion precisely, thereby enabling subsequent examiners to evaluate the wound’s healing response objectively.
Treatment
Because the majority of corneal abrasions heal spontaneously, treatment is aimed at relieving pain and preventing infection. Topical NSAIDs such as ketorolac and diclofenac help to relieve pain, but cost more and offer little advantage over oral NSAIDs.20,21 Topical tetracaine  drop hourly while awake, limited to  hours, has been advocated,22 with no complications found at  hours in one randomized controlled trial.23 However, pain scores were not improved compared to placebo,23 and significant safety issues have been raised by ophthalmologists regarding misdiagnosis of more serious conditions and delayed follow­up.24­26 The protective blink reflex is obliterated by topical tetracaine. Therefore, we cannot recommend topical tetracaine for use at home without further study. Patching the eye does not promote healing,14 but some patients feel better with the eye patched. Loss of depth perception results from patching one eye, so patients should not drive a car. Abrasions from fingernails, vegetable matter, or a contact lens should not be patched, as they are at higher risk of infection.
Cycloplegics relax the ciliary body and relieve pain from spasm as well as decrease secondary iritis. However, two randomized controlled trials including 440 patients did not find improvement in pain scores with cycloplegics compared to placebo.27,28 If an abrasion is large and spasm is marked, consider cyclopentolate 1%, one drop three times daily. Topical antibiotics are typically prescribed (Table 241­7).
TABLE 241­7
Suggested Ophthalmic Antibiotics for Corneal Abrasions
Situation Antibiotic
Not related to contact lens wear Erythromycin ophthalmic ointment three to four times a day
Related to contact lens wear Ciprofloxacin, ofloxacin, or tobramycin ointment three to four times a day
Organic source Erythromycin ointment three to four times a day
Large abrasions or abrasions in the central visual axis should be checked by an ophthalmologist in  hours; small abrasions should be checked in  to  hours.
Eye Patch
An eye patch may be recommended by ophthalmology or may be needed to prevent keratitis in a patient with Bell’s palsy. Assemble supplies—two cotton oval eye pads and multiple pieces of tape pretorn to approximately  in. (13 cm). To properly apply an eye patch, have the patient sit with both eyes closed. Have the patient keep both eyes closed until the patch is applied and secure. Take one cotton oval eye pad, fold it in half, and hold the eye pad gently but firmly over the closed lid of the eye to be patched. Then take another eye patch, do not fold it in half, and place it over the first patch. Very deep­set eyes may require a third patch. Keep holding firmly but gently. Then tape the patch in place, applying the tape in an X fashion over the eye pad. Now have the patient open his or her eyes. If the patch is properly placed and taped, the lid under the patch will remain closed. (See Video: Eye Patch.)
Video 241­4: Eye Patch
Used with permission from Dr. Stephen Gamboa, University of North Carolina.
Play Video
CORNEAL LACERATION
Full­thickness corneal lacerations can be identified by a misshapen iris, macro­ or microhyphema, decrease in visual acuity, and shallow anterior chamber. The Seidel test (Figure 241­12) should be positive. However, small corneal lacerations can close spontaneously, the Seidel test will be negative, and there may be no gross distortion of globe anatomy
(see Figure 241­47). Corneal lacerations occur in young children from a wide variety of objects—sharp sticks, fingernails, thorns, broken glass, or sharp toys.29 Objects as diverse as bungee cords and eyelash curlers30,31 can cause globe perforation. A history of eye irritation while working with metal fragments or high­speed machinery suggests the possibility of a corneal laceration. Pain out of proportion to physical findings, decrease in visual acuity, or other unexplained ocular symptoms may be the only symptoms or signs of a small full­thickness corneal laceration. Evaluate the entire thickness of the cornea during slit lamp examination to identify a corneal laceration.
If there is any suspicion of penetrating injury or severe blunt injury, obtain a CT of the orbit to identify changes in globe anatomy or contour or a foreign body within the globe, and consult ophthalmology. The sensitivity of CT for the detection of occult globe perforation is reported as 51% to 77%,32 further emphasizing the need for consultation.
Unrecognized corneal lacerations can quickly result in endophthalmitis or traumatic cataract. Once endophthalmitis develops, vision is at great risk.
CORNEAL FOREIGN BODIES
Corneal foreign bodies are usually superficial and benign, but penetration of a foreign body into the globe can cause loss of vision. Foreign bodies are generally small pieces of metal, wood, or plastic that become embedded in the cornea. The presence of a corneal foreign body causes an inflammatory reaction, dilating blood vessels of the conjunctiva and causing edema of the lids, conjunctiva, and cornea. When the foreign body is present for >24 hours, WBCs may migrate into the cornea and anterior chamber as a sign of iritis.
The patient will usually complain of a “foreign body” sensation during blinking. Tearing, blurred vision, and photophobia are common. Ask about details surrounding the onset of symptoms, including patient activity. If a cause is not obvious, ask about all activities in the previous  hours, especially activities that cause high­velocity projectiles. High­velocity globe penetration injuries include grinding, hammering metal on metal, or operation of other high­speed machinery. Visual acuity should be normal. Inspection of the eye may reveal edema of the eyelid and diffuse or focal/perilimbal conjunctival injection.
Occasionally, the foreign body may be visible with the naked eye. Evert the lid to identify and remove other foreign bodies that may be present. When a metallic foreign body is present for more than a few hours, a rust ring (Figure 241­34) develops around the metal. Foreign bodies present for >24 hours may be surrounded by a white ring representing a WBC infiltrate.
Anterior chamber flare and cells and a corneal foreign body are identifiable on slit lamp examination (Figure 241­35). The presence of a gross hyphema or a microhyphema evident in the anterior chamber on slit lamp examination suggests globe perforation. If the foreign body has penetrated the cornea, the tract of the projectile may be seen. The Seidel test may be positive with penetration of the globe.
FIGURE 241­34. Rust ring (arrow). [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New York.]
FIGURE 241­35. Corneal foreign body. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
Corneal Foreign Body Removal
Corneal foreign bodies should be removed carefully, with the patient and physician seated at each other’s eye level, and under the best magnification available. Anesthetize the cornea with a local anesthetic such as .5% proparacaine. Sometimes, anesthetizing both eyes is helpful, because that can eliminate reflex blinking during attempts at foreign body removal. Irrigate with normal saline first, as a very superficial foreign body may be irrigated off the cornea. Next, try to dislodge the foreign body with a moistened cotton applicator. Efforts at removal may themselves cause corneal abrasion.
If the foreign body is tightly adherent to or embedded in the cornea, inspect the cornea using the slit lamp to assess the depth of penetration (Figure 241­19C to E). Full­thickness corneal foreign bodies should be removed by an ophthalmologist.
For superficial foreign bodies, a 25­gauge needle (using needle bevel up)33 or a sterile foreign body spud (1 mm diameter) on an Alger brush (a low­speed, low­torque, battery­operated hand­held drill) can be used to remove the foreign body. Use slit lamp magnification to ensure safe foreign body removal. Before the removal, prepare a moistened cotton applicator and set it aside on the slit lamp table. The upper lid can be held open by an assistant or by the clinician’s nondominant hand. Many slit lamps have an attached “fixation light” that can be moved in front of the unaffected eye to give the patient a steady target to concentrate on. Using either the 25­gauge needle or the Alger brush, place the tip into the slit lamp beam using the naked eye. With the tip close to the cornea, look through the slit lamp and move the tip tangentially into contact with the cornea. Using the bevel­up edge of the tip of the 25­gauge needle, hook the edge of the foreign body and dislodge it.33 You may then lift it off the cornea using the previously moistened cotton applicator. Alternatively, using the spinning tip of the Alger brush, the foreign body may be dislodged and removed with the cotton applicator as above.
After successful foreign body removal, discharge the patient with a prescription for topical antibiotics, cycloplegics, and oral analgesics. Administer tetanus toxoid as appropriate. Provide ophthalmology follow­up the next day if the foreign body is in the central visual axis or if there is a residual rust ring. Otherwise, after complete removal of the foreign body, advise follow­up if symptoms persist at  hours.
Rust Ring Removal
Metallic foreign bodies can create rust rings that are toxic to the corneal tissue (Figure 241­34). If a rust ring is present, the spud or an ophthalmic burr can remove superficial rust, but rust often reaccumulates by the next day, requiring additional burring. It is therefore not necessary to remove a rust ring in the ED if the patient can be seen by an ophthalmologist the next day. Once the metallic foreign body is removed, the rust ring area softens overnight and can be more easily removed in the office the next day. The deeper the stromal involvement, the higher is the risk of corneal scarring, so if rust ring removal is done in the ED, perform only superficial burring. No ED drill burring should take place if the rust ring is located in the visual axis (pupil) owing to the risk of causing visually significant scarring. Such conditions require that an ophthalmologist remove the stromal rust in the office within  hours.
LID LACERATIONS
Eyelid lacerations that involve the lid margin, those within  to  mm of the medial canthus or involving the lacrimal duct or sac, those involving the inner surface of the lid, wounds associated with ptosis, and those involving the tarsal plate or levator palpebrae muscle need repair by an oculoplastic specialist. Lacerations medial to the lacrimal puncta are at high risk of canalicular involvement. Suspect involvement of the levator palpebral muscle in the presence of a horizontal laceration with ptosis or when orbital fat is seen protruding through the laceration, indicating a breach of the orbital septum.
FULL­THICKNESS LID LACERATIONS
Consider the possibility of corneal laceration and globe rupture in all full­thickness lid lacerations. Ocular injuries such as corneal abrasion, traumatic hyphema, and globe rupture are seen with lid lacerations in up to two thirds of cases. Lid lacerations require a thorough examination using a slit lamp to exclude other associated ocular injuries.
Deep lacerations to the medial one third of an eyelid potentially transect the canalicular system. Failure to repair a canalicular laceration results in chronic tearing. Instillation of fluorescein dye in the eye with subsequent appearance in the wound indicates loss of canalicular integrity. If a canalicular laceration is discovered, the patient will need to go to the operating room within
 to  hours for repair and Silastic® tube stenting. Because a meticulous repair by an experienced eye surgery team is preferable, it is not unreasonable for the ophthalmologist to discharge a patient seen late in the evening or on the weekend with arrangements for surgical repair to take place within the next  hours. Patients discharged pending repair should be placed on oral and topical antibiotics and told to use cold compresses. Oral cephalexin, 500 milligrams two to four times daily, and topical erythromycin ophthalmic ointment four times daily are reasonable choices.
PARTIAL­THICKNESS LID LACERATIONS
Partial­thickness lid lacerations not meeting the preceding criteria can usually be repaired in the ED, with referral for ophthalmologic evaluation in  to  days. Use a soft, absorbable or nonabsorbable 6­0 or 7­0 suture. Have the suture ends closest to the cornea tucked under more distant sutures to avoid corneal irritation (Figure 241­36). Cut the ends of each suture  cm long. When the second suture is tied, take the long ends of the first suture into the loop of the knot of the second suture. This keeps the ends of the first suture secure. Do this for every successive suture. Do not incorporate the ends of the suture into the wound itself, but make sure the suture ends are kept to the side of the wound margin. Sutures are removed from the bottom.
FIGURE 241­36. A through D. Each suture holds down the ends of the adjacent suture to prevent corneal irritation or abrasion. Note that this illustration shows a laceration at the lid margin. Lid margin lacerations >1 mm need repair by an oculoplastic specialist.
LACERATIONS AT THE LID MARGIN
Very small lacerations (<1 mm) at the lid edge only do not need suturing and can heal spontaneously. Any laceration >1 mm at the lid edge needs repair by a specialist. Proper alignment of the lid margin during repair under magnification (loupe or microscope) is essential to preserve proper lid function and even corneal wetting with each blink. Notching of the lid can result in improper lid closure.
If there is no opportunity for the patient to see an ophthalmologist, repair should be performed as in Figure 241­37. Soft (gut or chromic) sutures 6­0 or smaller should be used for all repairs. One vertical mattress suture, using the meibomian gland orifices as a landmark, or two 6­0 soft sutures (one approximating the anterior and the other the posterior lamella) are used to repair the lid margin. The initial suture can be used for traction to extend the lid and facilitate the repair. The tarsus should be repaired with 6­0 absorbable suture (polyglactin) from the external side so as to approximate the wound without the need for sutures on the conjunctival side of the lid (which would abrade the cornea with each blink). Skin closure can be performed with 6­0 or smaller soft nonabsorbable suture.
FIGURE 241­37. A through D. Full­thickness lid repair. 6­0 silk is used for lid margin. 5­0 Vicryl® is used to approximate the tarsal plate. The Vicryl® sutures should not pass through the conjunctiva on the inside of the eyelid to avoid mechanical abrasion of the cornea during blinking. 7­0 nylon is used for skin closure, and the lid margin silk suture tail can be incorporated into these sutures to avoid corneal irritation.
BLUNT EYE TRAUMA
CLINICAL FINDINGS AND DIAGNOSIS
The first steps are assessment of the visual acuity, anterior chamber, and integrity of the globe. The eyelids frequently swell shut, making visualization of the globe difficult. Prying the eyelids open with the fingers is difficult, usually yields an unsatisfactory view of the globe, and can raise intraocular pressure. Insertion of a paper clip bent in an appropriate shape (Figure 241­11) or an eyelid speculum (Figure 241­38) provides a significantly improved view of the cornea and anterior chamber. Use of an eyelid retractor allows your hands to remain free for examination of the globe using the slit lamp.
FIGURE 241­38. Commercial eyelid retractors. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New York.]
If the anterior chamber is flat, a ruptured globe is certain, so stop the examination, place a metal shield over the injured eye, and consult ophthalmology. If the globe appears intact and vision is preserved, check ocular motility. Restricted upgaze or lateral gaze suggests a blow­out fracture with entrapment (see later section, “Orbital Blow­Out Fractures”), and a CT scan of facial bones should be obtained. A head CT scan may be indicated to assess for associated intracranial injury. Feel the orbital rim above and below for step­off deformities. Test for cutaneous sensation along the distribution of the inferior orbital nerve (below the eye and ipsilateral side of the nose). Perform a slit lamp examination with fluorescein staining to check for abrasions, lacerations, foreign bodies, hyphema, iritis, and lens dislocation. Measure intraocular pressure if there are no signs of a ruptured globe. Traumatic iritis is common, causing cells and flare to be seen on slit lamp examination. The pupil can be constricted or dilated after sustaining trauma. It is important to look for pupillary irregularity because the pupil often will peak toward the site of a penetration or rupture. If the anterior chamber is of normal depth and not shallow, apply a mydriatic. Nonwhite, brown­eyed individuals frequently will require an additional drop of a mydriatic to achieve adequate dilation. If vision and ocular anatomy and function are preserved, outpatient follow­up by an ophthalmologist in the next  hours should be planned. If a ruptured globe is suspected due to loss of visual acuity, flat anterior chamber, obvious full­thickness laceration, or intraocular foreign body, do not manipulate the eye or measure intraocular pressure. Consult ophthalmology immediately.
HYPHEMA
A hyphema is blood or blood clots in the anterior chamber (Figures 241­22 and 241­23). Hyphemas are traumatic or spontaneous. A traumatic hyphema usually results from bleeding from a ruptured iris root vessel. Spontaneous hyphemas frequently are associated with sickle cell disease. In addition to standard ophthalmologic history, query anticoagulant or antiplatelet medication use or history of a bleeding diathesis. A hyphema may layer out posteriorly when the patient is lying flat and may only become grossly evident when the patient is sitting upright. The complications of hyphema include increased intraocular pressure, rebleeding, peripheral anterior synechiae, corneal staining, optic atrophy, and accommodative impairment. Patients with large hyphemas, sickle cell disease, and bleeding tendency are more likely to develop vision loss. A microhyphema is suspension of red blood cells in the anterior chamber without the formation of a layered blood clot. It is generally seen with a slit lamp and can progress into a hyphema. The most significant complications of microhyphema include rebleeding and intraocular pressure elevation. Patients with sickle cell disease are more likely to develop these complications. The treatment of microhyphema is somewhat controversial, but the principles of management are the same as those for the hyphema. Patients at high risk for complications include those with suspected ruptured globe, those with sickle cell disease, those taking anticoagulants, and those with a bleeding diathesis.
Hyphema Treatment
Treatment consists of the prevention of rebleeding and intraocular hypertension. Elevate the patient’s head to  degrees to promote settling of suspended red blood cells inferiorly to prevent occlusion of the trabecular meshwork. Interventions should be directed by an ophthalmologist. Treatment modalities include antifibrinolytic agents (oral and systemic aminocaproic acid, tranexamic acid, and aminomethylbenzoic acid), corticosteroids (systemic and topical), cycloplegics, miotics, and aspirin.34 Both tranexamic acid and aminocaproic acid have been shown to decrease the rebleeding rate.34
Rebleeding can occur  to  days later in up to 30% of cases, sometimes causing severe elevation of intraocular pressure and necessitating surgical anterior chamber “washouts.” Because of this risk, some ophthalmologists believe in admitting all patients with significant hyphemas. Generally, patients with hyphemas occupying one third or less of the anterior chamber can be followed closely as outpatients. The disposition decision should be made by the ophthalmologist after examining the patient. Topical steroids may prevent posterior synechiae and treat iridocyclitis. Close follow­up and serial examinations by an ophthalmologist are recommended in patients receiving topical ocular steroids to ensure no infection or corneal perforation occurs.
ORBITAL BLOW­OUT FRACTURES
The most frequent sites of orbital blow­out fractures are the inferior wall (maxillary sinus) and medial wall (ethmoid sinus through the lamina papyracea). Fractures of the medial wall can be associated with subcutaneous emphysema, sometimes exacerbated by sneezing or blowing the nose. Fractures of the inferior wall with entrapment of the inferior rectus muscle can cause restriction of upgaze and diplopia (Figure 241­39). Especially in children, tight entrapment of an ocular muscle or swelling putting pressure on the globe may stimulate the oculovagal reflex (oculocardiac reflex), yielding nausea, vomiting, bradycardia, and hypotension of varying degrees.35 Orbital wall fractures are suspected on clinical examination and confirmed by
CT scanning. About one third of blow­out fractures are associated with ocular trauma (abrasion, traumatic iritis, hyphema, lens dislocation/subluxation, retinal tear, or detachment); therefore, a careful eye examination in the ED is necessary. All blow­out fractures with normal initial eye examination in the ED should be referred to an ophthalmologist for dilated examination to rule out any unidentified retinal tears or detachments. The complete eye exam can be done as an outpatient in  to  hours if there is no need for admission or immediate surgery. The need for admission and timing of surgical repair are controversial.35­37
FIGURE 241­39. Inferior wall blow­out fracture of the left eye with entrapment of the inferior rectus muscle. The patient’s left eye is unable to look upward, causing diplopia on upward gaze. [Courtesy of Allen
R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
Patients demonstrating signs of oculovagal reflex and patients with CT findings demonstrating a large tissue herniation through a narrow bone fragment separation have signs of tight entrapment and should be referred immediately to ophthalmology for management.35 All patients with entrapment as indicated by diplopia, limitation of ocular motility, CT findings, or proptosis should be discussed with ophthalmology for management.35,36 Isolated blow­out fractures without entrapment and without eye injury do not require immediate surgery and can be referred to ophthalmology, plastic surgery, oral maxillofacial surgery, or otolaryngology (depending on the local referral patterns) for repair within the next  to  days.37 Oral antibiotics
(cephalexin, 250 to 500 milligrams PO four times daily for  days) are often recommended because of the presence of sinus wall fractures. Patients who develop new symptoms, such as diplopia, or who have persistent nausea and vomiting should be instructed to return to the ED for reevaluation.
RUPTURED GLOBE
Rupture of the globe is a vision­threatening emergency that may be easily missed. The patient will usually complain of eye pain but may not have a decrease in visual acuity. Rupture of the globe presenting with a large subconjunctival hemorrhage is easily recognized, but a penetrating wound of the cornea caused by a tiny piece of metal launched from a grinder may be easily overlooked and requires careful exam or imaging to detect. Periorbital ecchymosis and maxillofacial fractures, including blow­out fracture with limitation of extraocular muscle movement, should raise one’s suspicion for globe rupture.
Scleral rupture may occur from blunt or penetrating trauma. Blunt trauma directly to the eyeball (for example, a blow by a fist) will cause a sudden elevation of intraocular pressure, with the globe tending to rupture at the thinnest points of the sclera, the limbus, and the insertion of the extraocular muscles. Any object that impacts the orbital rim at a high velocity and causes a seal around the orbit (tennis balls, racquetballs, etc.) will also cause a sudden peak in intraocular pressure and may result in rupture. A history of ocular surgery or previous ocular injury may predispose to globe rupture. Penetrating trauma may occur from bullets, BB pellets, knives, sticks, darts, needles, hammering, and lawn mower projectiles. Any projectile injury has the potential for penetrating the eye. The bony canal protects the globe from posterior and oblique injuries, but the eyelids afford little protection anteriorly. Suspect globe penetration with any puncture or laceration of the eyelid or periorbital area, and make sure to conduct a thorough slit lamp examination. The smaller the diameter of the offending object, the higher is the likelihood of occult injury. Corneal abrasions occurring when hammering metal on metal; associated with the use of high­speed machinery such as lawn mowers, line trimmers (weed whackers), grinders, or drills; and sustained during explosions should always be investigated for occult globe penetration.
Whenever globe rupture is obvious or strongly suspected, cover the eye with a metal eye shield or make a shield from a paper cup (Figures 241­40 and 241­41), and consult ophthalmology immediately without further manipulation. Elevate the head of the bed to  degrees. Administer broad­spectrum IV antibiotics (vancomycin plus ceftazidime, or similar coverage), and give tetanus toxoid as appropriate. Provide sedation and analgesia. Administer antiemetics to prevent increased intraocular pressure and extrusion of intraocular contents from vomiting. Avoid any topical eye solutions. Give the patient nothing by mouth, anticipating surgery.
FIGURE 241­40. Metal eye shield placed in suspected globe rupture to prevent inadvertent pressure on the eye. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine,
2nd ed. © 2002, McGraw­Hill, New York.]
FIGURE 241­41. Protective eye shield fashioned from a paper cup. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New York.]
Most cases, however, will require an initial eye examination to determine the type and extent of injury before consulting ophthalmology. If at any step of the examination globe rupture is suspected, stop the examination, place a protective shield over the eye, and consult ophthalmology. Do not measure intraocular pressure as this may result in extrusion of globe contents.
Eye examination must be careful and gentle. If using US to evaluate for trauma, do not apply significant pressure on the globe (see later section on ocular US, including Figure 241­60).
Manufactured or homemade eyelid retractors should be used to gently retract the lids to examine the eye and to avoid increasing intraocular pressure during examination.
Examination of the eye may reveal decreased visual acuity, an irregular or teardrop­shaped pupil, an afferent pupillary defect, shallow anterior chamber, hyphema, positive Seidel test, and lens dislocation (Figure 241­42). Presence of a large subconjunctival hemorrhage involving the entire sclera or hemorrhagic chemosis (bullous, raised subconjunctival hemorrhage) is very suspicious for rupture of the globe (Figures 241­43 and 241­44). Uveal prolapse through a scleral wound may appear as a brownish­black discoloration against the white sclera (Figure
241­45). One may occasionally visualize a corneal laceration (Figure 241­46) or an intraocular foreign body on slit lamp examination (Figure 241­47). The Seidel test may or may not be positive with a small corneal laceration. Funduscopic examination may reveal a poor view of the optic nerve and posterior pole due to vitreous hemorrhage.
FIGURE 241­42. Lens dislocation. [Reproduced with permission from Knoop K, Stack L, Storrow A, et al: Atlas of Emergency Medicine, 3rd ed. © 2010 McGraw­Hill Inc.; Photo contributed by Department of
Ophthalmology, Naval Medical Center, Portsmouth, VA.]
FIGURE 241­43. Large subconjunctival hemorrhage. Note that it is flat, not raised. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill,
New York.]
FIGURE 241­44. Bloody chemosis. Note the raised or bullous appearance. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New
York.]
FIGURE 241­45. Uveal prolapse with globe rupture and teardrop pupil. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New York.]
FIGURE 241­46. Corneal laceration due to hammering concrete. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
FIGURE 241­47. Intraocular foreign body associated with laceration in Figure 241­46 as seen on slit lamp examination. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska
Medical Center.]
The diagnosis is made based on a combination of history, physical examination, and selected radiologic studies. CT scan of the eye is the preferred imaging modality to detect occult open globe rupture and associated optic nerve injury. CT scan of the orbit using 2­ to 3­mm cuts in both the axial and coronal planes will also localize small intraocular foreign bodies. US and both direct and indirect ophthalmoscopy after pupillary dilatation may assist in the diagnosis and can be helpful in locating and confirming the presence of orbital and intraocular foreign bodies.
See Figure 241­60 in the later ocular US section. MRI is contraindicated if a metallic foreign body is possible.
For patients in the ED with multiple trauma and a possible ruptured globe who require rapid­sequence intubation, there is no clear consensus on the best agent to use because quick airway stabilization takes priority. Although a depolarizing agent like succinylcholine is associated with an increase in intraocular pressure, the underlying mechanism is not clear. Pretreatment with a nondepolarizing muscle relaxant or a pretreatment dose of succinylcholine does not necessarily attenuate the increase in intracranial pressure. Use of a nondepolarizing agent like rocuronium can mitigate increases in intraocular pressure, but disadvantages are a longer onset and longer duration of action38 (see Chapter 29A, “Tracheal Intubation” and Chapter
29B, “Mechanical Ventilation”).
ORBITAL HEMORRHAGE: PRESEPTAL AND POSTSEPTAL
Severe blunt trauma to the orbit can occasionally cause an orbital hemorrhage. Preseptal hemorrhage is dramatic in appearance, but not as vision threatening as a postseptal hemorrhage (often called retrobulbar hematoma), which can cause an orbital compartment syndrome. A postseptal hematoma can cause an abrupt increase in intraocular pressure, resulting in decreased blood flow to the optic nerve and its blood supply and loss of vision.
Traumatic periorbital hematomas (black eyes) are common, but the extension of bleeding into the postseptal compartment is a true emergency. Differentiation of preseptal versus postseptal hematoma depends on the examination and noncontrast orbital CT findings. Clinical findings of postseptal hemorrhage are eye pain, proptosis, impaired extraocular movements, decreased vision, possibly an afferent pupillary defect, and elevated intraocular pressure. An intraocular pressure >40 mm Hg is a consideration for emergency lateral canthotomy. No matter what the intraocular pressure, if postseptal hematoma is suspected or confirmed, request emergency ophthalmology consultation. Preseptal hematomas can be observed to make sure that the hematoma is not expanding.
Lateral Canthotomy
The goals of lateral canthotomy are to release pressure on the globe and to reduce intraocular pressure to reestablish retinal artery blood flow. To perform the procedure, place the patient in the supine position and anesthetize the lateral canthus area with 1% to 2% lidocaine with epinephrine.39 Place a straight Kelly clamp horizontally across the lateral canthus to the lateral orbital rim for about  to  minutes to crush the tissues and minimize bleeding.39 Remove the clamp, and with sterile scissors, make a 1­ to 2­cm lateral incision in the compressed tissue at the clamp site. Then retract the lower lid to expose the lateral canthus tendon. With the scissors directed inferoposteriorly toward the lateral orbital rim, cut the inferior crus of the lateral canthus tendon. This critical incision is generally  to  cm in depth and length. If the procedure is successful, the intraocular pressure should be less than  mm Hg and the visual acuity should improve. If the intraocular pressure continues to remain elevated, the superior crus of the lateral canthus tendon can be cut in a similar fashion. The complications of lateral canthotomy include hemorrhage, infection, and mechanical injury. These complications generally respond to treatment better than does retinal injury from prolonged ischemia. Lateral canthotomy incisions usually heal well; repair is performed by ophthalmology.40 (See Video: Lateral Canthotomy.)
Video 241­5: Lateral Canthotomy
Used with permission from Sandra L. Werner, MD, RDMS, Case Western Reserve University. Cleveland, OH.

## Page 50

Play Video
Ocular Hemorrhage and Antithrombotic Therapy
The use of anticoagulant and antiplatelet agents is very common in current clinical practice and can complicate the management of ocular hemorrhage from trauma. Spontaneous ocular hemorrhage has also been reported in patients taking these agents. Ocular complications in patients on oral anticoagulant therapy include subconjunctival hemorrhage, hyphema, vitreous hemorrhage, subretinal hemorrhage, and choroidal hemorrhage. A higher incidence of hemorrhagic complications has been reported in patients with macular degeneration using anticoagulants or other antithrombotic drugs. Ocular hemorrhages in patients taking warfarin can potentially be vision­threatening events, but frequently they are benign and resolve without any sequelae. See the ocular US section later in this chapter, including Figure 241­62, for US diagnosis of vitreous hemorrhage.
There are no clear guidelines to guide treatment of ocular hemorrhage in patients taking anticoagulant and antiplatelet therapy. The severity of bleeding, INR levels, and benefits of using these agents should be taken into consideration when managing these patients. Stop the anticoagulant or antiplatelet drug in patients with active bleeding. Prothrombin complex concentrate, fresh frozen plasma, and vitamin K should be considered in patients taking warfarin (see Chapter 239, “Thrombotics and Antithrombotics,” for detailed discussion). Platelet transfusions might be beneficial to stop active bleeding in patients with thrombocytopenia or taking antiplatelet drugs, but efficacy differs depending on the antiplatelet agent. For example, platelet transfusions do not reverse the effects of clopidogrel.41 Consult ophthalmology, the care provider who prescribed the anticoagulant or antiplatelet drug, and hematology for recommendations.
CHEMICAL OCULAR INJURY
Chemical burns to the eye are a true ocular emergency. Complications of chemical burns to the eye include scarring of the cornea with permanent loss of vision and loss of the eye due to corneal perforation. Irrigation of the eyes with  to  L of normal saline must be done immediately and before any examination, including testing of vision.
ALKALI AND ACID INJURIES
Alkali injuries occur more frequently than acid injuries, due to the presence of alkaline substances in household cleaning agents and in building materials. The most serious alkali injuries are associated with ammonia, found in many household cleaners, and lye, a common ingredient in drain cleaners. Lye is also a component of concrete. Alkali injuries tend to be much more serious than acid injuries because they cause a liquefaction necrosis, characterized by denaturing of proteins and saponification of fats, allowing deep penetration into tissue. Acid, on the other hand, causes coagulation necrosis, with denaturing of protein forming a coagulum that acts as a barrier to further tissue penetration.
University of Pittsburgh
Treatment
Access Provided by:
Irrigation should begin at the scene and continue in the ED. Instill a topical anesthetic and continue irrigation for at least  minutes. Then check pH by touching a strip of litmus paper to the inferior conjunctival fornix. If the pH is >7.4, continue irrigation until the pH remains neutral  minutes after the last irrigation. Irrigation should be with sterile normal saline or other isotonic solution and may be instilled into the eye by hand, using bottles of eye­irrigating solution, or by a Morgan Lens® (MorTan Inc., Missoula, MT) (Figure 241­48) attached to a bag of an isotonic IV solution.
FIGURE 241­48. Eye irrigation with a Morgan Lens® (MorTan Inc., Missoula, MT). [Reproduced with permission from Reichman EF, Simon RR: Emergency Medicine Procedures. © 2004, Eric F. Reichman, PhD,
MD, and Robert R. Simon, MD. McGraw­Hill, Inc.]
After irrigation and maintenance of ocular pH >7.4, perform the eye examination. Inspect the facial skin and eyelids for burns. Evert the eyelids and remove any particulate matter with a cotton applicator.
Exposure to chemical agents can cause conjunctival injection and chemosis, but severe chemical burns can cause scleral whitening, secondary to ischemia and blood vessel injury. Document visual acuity and measure intraocular pressure. Intraocular pressure may be increased if the trabecular meshwork has been damaged. Use the slit lamp to evaluate corneal injury and to detect for cells and flare in the anterior chamber. Injury to the cornea may range from punctate defects to complete loss of epithelium. The cornea may become cloudy with severe burns
(Figure 241­49).
FIGURE 241­49. Severe lye burn with corneal opacification. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New York.]
After irrigation, and once time permits, identify the substance. The pH is usually listed on bottles of household cleaners. The U.S. Occupational Health and Safety Administration requires the patient’s workplace to maintain Material Data Safety Sheets, a list of all the physical properties, including pH, of chemicals used at the site. Data on the pH of known chemicals can also be obtained from a poison control center or from Poisindex®. Alkaline substances with pH <12 or acidic substances with pH >2 are thought not to cause serious injury, but duration of exposure can increase severity of injury. Circumstances surrounding the injury (e.g., battery explosion) should be determined to identify any other associated ocular or facial injuries.
Obtain ophthalmology consultation for all but minor burns: Any patient with corneal clouding or an epithelial defect after irrigation should receive prompt ophthalmology referral.42
Patients with chemosis (edema of the bulbar conjunctiva overlying the white sclera) and no corneal or anterior chamber findings should be treated after irrigation with erythromycin ointment four times daily and referred for an ophthalmologic examination in  to  hours. These patients are considered to have “chemical conjunctivitis.”

AC thopaipcatle cry c2lo4p1le: gEicy aeg eEntm (ceycrlgoepennctioelast,e R1%ic, honaer ddr oAp.) Wshoaulklde bre; uSsreidk tahrr eAe dtihmieksa draiily for pain reduction if an epithelial defect is present.43 Apply erythromycin ophthalmPica oginet m5e0n /t f7o2ur t
© im
 e
 s
 da
 i ly
M to c G aff r e a c w te d
H e i y l e l.
s .
A
D l o l x
R yc ig yc h li t n s e
R
 e
 s m e i r ll v ig e ra d m
.
s t
T w e ic r e m a s d a o y f m
U a s y e b e
 * r
P ec r o iv m a m c e y n d
P e o d l t i o c y re d
 * u
N ce o r t i i s c k e o f
 * c o
A r c ne c a e l s m s e i l b tin il g it
.
y43
Administer tetanus toxoid as appropriate. Consider prescribing topical corticosteroids after consultation with an ophthalmologist if recommended to control inflammation.
CYANOACRYLATE (SUPER GLUE/CRAZY GLUE)
Accidental instillation of cyanoacrylate adhesives into the eye and adnexa can cause adherence of the lids and clumps of adhesive to form on the cornea. Medicinal grade cyanoacrylates are occasionally used to seal corneal perforations and are not toxic to the cornea, so there is rarely permanent damage to the eye. The mechanical abrasive effect of hard, irregular glue aggregates rubbing against the cornea with eye movement and blinking may cause corneal abrasions. To remove crazy glue, instill generous amounts of erythromycin ointment onto the eye and on the surface of the eyelids to moisten, lubricate, and provide antibiotic coverage. Clumps of glue on the surface should begin to loosen. Remove only those pieces that are easily removable. Gentle traction may separate the lids. The glue will loosen and become easier to remove in a few days.
Refer to an ophthalmologist within  hours for complete removal.
ACUTE VISUAL REDUCTION OR LOSS
Acute visual loss is usually divided into painful and painless visual loss for diagnostic categorization. Other differentiating features include presence or absence of a relative afferent pupillary defect, the rapidity of onset, funduscopic exam, and various physical exam and historical features. The differential diagnosis of visual loss is listed in Table 241­8. Many of the diagnoses are discussed in further detail in the text.
TABLE 241­8
Differential Diagnosis of Visual Loss
Relative Afferent
Diagnosis Eye Pain Onset Fundoscopic Exam Other Findings
Pupillary Defect
Central retinal No Yes Sudden Pale retina, cherry red spot artery occlusion
Central retinal vein No +/– Sudden “Blood and thunder”/”ketchup” fundus occlusion
Acute ischemic optic No Yes Gradual Swollen pale disk Signs of temporal arteritis neuropathy
Acute angle­closure Yes +/– Sudden Difficult to visualize the fundus due to Painful red eye, hazy cornea, midpoint pupil, narrow glaucoma corneal edema anterior chamber, firm globe
Optic neuritis Yes Yes Gradual Papilledema Painful EOM, young female patient
Giant cell arteritis Possible retro­orbital Yes Gradual Normal Headache, myalgias headache/pain
Cataract No +/– Gradual Often unable to visualize fundus Opacity in the lens
Uveitis Yes No Gradual Normal Flare and cells in anterior chamber, ciliary flush, consensual photophobia
Vitreous No +/– Sudden Opacity in the vitreous Floaters, cobwebs hemorrhage
Amaurosis fugax No No Sudden Normal Transient monocular vision loss
Transient ischemic No No Sudden Normal Transient binocular vision loss attack
Cortical blindness No +/– Sudden or Possible papilledema Complete visual loss or homonymous hemianopsia, gradual headache
Migraine headache Possible retro­orbital No Sudden Normal Visual scotomata, nausea, vomiting headache/pain
Retinal detachment No +/– Sudden Retina may be difficult to visualize (portion Possible localized visual field defect, “cloudy veil,” of retina out of focus) “window shade”; suspect by history
Diabetic retinopathy No +/– Gradual Neovascularization, retinal hemorrhages History of diabetes mellitus
Macular No +/– Gradual Drusen, macular pigment clumps Spots in visual field degeneration
Cytomegalovirus No +/– Sudden or “Tomato and cheese” pizza (retinal History of human immunodeficiency virus or other retinitis gradual necrosis), retinal hemorrhages immunosuppression
Methanol No No Gradual Normal Headache, nausea, vomiting, history of ingestion
Functional visual No No Sudden or Normal Optokinetic nystagmus loss gradual
Abbreviation: EOM = extraocular muscle movement.
ACUTE AND PAINFUL VISION REDUCTION OR LOSS
ACUTE ANGLE­CLOSURE GLAUCOMA (ACUTE ANGLE­CLOSURE CRISIS)
Pathophysiology
Glaucoma is a group of ocular disorders characterized by increased intraocular pressure causing optic neuropathy and vision loss if left untreated. Obstruction to aqueous humor outflow is the basic underlying problem in glaucoma. In primary acute angle­closure glaucoma or crisis, the lens or the peripheral iris blocks the trabecular meshwork, obstructing the outflow of aqueous humor.44 Angle closure occurs more easily in persons whose eyes have shallow anterior chambers where the angle between the cornea and iris is reduced. A shallow anterior chamber results in a greater area of contact between the lens and iris, impeding flow of aqueous humor from the posterior to anterior chamber. This results in a pressure differential between the posterior and anterior chamber (referred to as pupillary block) and causes forward bowing of the iris, further narrowing the angle (Figure 241­50).
FIGURE 241­50. A. Normal flow of aqueous from ciliary body, through the pupil, and out through the trabecular meshwork and Schlemm canal located in the anterior chamber angle. B. Angle­closure glaucoma with pupillary block. Iris leaflet bows forward, blocking the chamber angle and prohibiting aqueous outflow. Meanwhile, aqueous production continues, and intraocular pressure rises.
An acute attack is usually precipitated by pupillary dilation. Dilation increases contact between the iris and lens as the iris becomes thicker. When the pupil is mid­dilated, relative pupillary block and peripheral laxity of the iris are maximal. This increases the degree of pupillary block, increasing pressure in the posterior chamber and causing the iris to bulge forward (iris bombe). The angle between the peripheral iris, trabecular meshwork, and cornea becomes acutely closed, resulting in a precipitous increase in intraocular pressure. Intraocular pressure eventually exceeds the capacity of the corneal pump mechanism, causing the cornea to become edematous and less transparent, thus explaining the foggy vision or halos patients complain of and the hazy appearance of the cornea on physical examination.
As people age, the lens becomes less elastic and thicker, or cataracts may develop. These events can push the iris forward into greater contact with the lens, increasing the degree of pupillary block. Hypermetropic (farsighted) eyes have a shorter anterior to posterior length, a flatter cornea, and a narrower angle, increasing the risk of acute angle­closure glaucoma.
Anything causing pupillary dilatation can trigger an acute attack. The use of topical or systemic parasympatholytic agents (mydriatics, antihistamines) or sympathomimetics (epinephrine, pseudoephedrine), dim illumination, and emotionally upsetting events have all been implicated. Precipitation of acute angle­closure glaucoma has been reported with therapeutic use, and abuse of, intranasal cocaine. Critically ill patients being treated for respiratory failure with nebulized β­sympathomimetic and anticholinergic medications (e.g., albuterol and ipratropium) may develop acute angle­closure glaucoma.45
Clinical Features
Acute angle­closure glaucoma is abrupt in onset, painful, and may result in severe visual impairment if not treated quickly. Patients complain of sudden onset of severe eye pain or frontal or supraorbital headache. Associated symptoms include blurred vision, nausea, and vomiting. Rarely, acute angle­closure glaucoma may result in painless monocular vision loss. Acute angleclosure glaucoma may be misdiagnosed as migraine, temporal arteritis, subarachnoid hemorrhage, or intra­abdominal emergency.
Examination reveals a fixed, midposition pupil and a hazy (cloudy/steamy) cornea with conjunctival injection (Figure 241­51), most prominent at the limbus. The affected eye is rock hard.
Measure the intraocular pressure to confirm the diagnosis (see earlier section, “Intraocular Pressure”), although the presence of the characteristic symptom complex—a cloudy cornea, fixed midposition pupil, and rock­hard globe—is diagnostic. Normal intraocular pressure is  to  mm Hg; ocular pressure may exceed  to  mm Hg in an acute attack.
FIGURE 241­51. Acute angle­closure glaucoma. The cornea is cloudy, and there is marked conjunctival injection. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine,
2nd ed. © 2002, McGraw­Hill, New York.]
Treatment
There have been no controlled studies regarding medical treatment for acute angle­closure glaucoma. Medical treatment lowers the intraocular pressure by blocking production of aqueous humor and reducing the volume of vitreous humor (Table 241­9).44,46 The initial treatment combines the effects of a carbonic anhydrase inhibitor (IV, PO, or topical), a topical β­blocker, and a topical α­agonist. If the intraocular pressure does not drop significantly with resolution of associated symptoms in the first hour (usually below  mm Hg), IV mannitol should be given if there are no contraindications. Pilocarpine is no longer recommended in the acute setting as cholinergic agents can paradoxically result in shallowing of the anterior chamber and further closure of the chamber’s angle.44,46 Begin treatment immediately, simultaneously with consulting ophthalmology. Ophthalmology, with access to a four­mirror slit lamp, may perform corneal indentation using dynamic gonioscopy to release angle closure. Pain and vomiting should be treated. Vomiting increases ocular pressure; fentanyl lowers intraocular pressure, whereas ondansetron has no effect on ocular pressure.47,48 Definitive treatment is peripheral laser iridotomy (iridectomy). While many patients with acute angle­closure crisis are admitted to the hospital, patients who experience a stable drop in intraocular pressure with relief of associated symptoms may be discharged to definitive outpatient care at the direction of the ophthalmologist.
TABLE 241­9
Treatment of Acute Angle­Closure Glaucoma (Crisis)
Initial Treatment to Reduce Intraocular Pressure and Block Production of Aqueous Humor
Agent Class Agent, Dose, and Frequency* Alternative Agent, Dose, and Frequency†
Carbonic anhydrase Acetazolamide, 500 milligrams IV or PO, then 250 milligrams IV or PO  hours later, max 1000 Brinzolamide .5%, one drop, affected eye, three times inhibitor milligrams/d daily
Or
Dorzolamide 2%, one drop, affected eye, three times daily
Topical β­blocker Timolol .5%, one drop, affected eye, two times daily Betaxolol .5%, one drop affected eye, three times daily
Topical α2­agonist Apraclonidine 1%, one drop, affected eye, three times daily Brimonidine .2%, one drop, affected eye, three times daily
Recheck IOP Hourly, Assess Need for Additional Agents
Hyperosmotic agent Mannitol, 15% or 20% solution, .5–2 grams/kg IV over  minutes Glycerine, 1–2 grams/kg/dose orally, repeat every  hours
Abbreviation: IOP = intraocular pressure.
*Agents most commonly used, historically.
†Agents recommended by the American Academy of Ophthalmology.
ACUTE VISUAL LOSS WITH OR WITHOUT PAIN
OPTIC NEURITIS
Acute optic neuritis may present without the complaint of pain, but patients frequently have mild to moderate pain with eye movement (19% to 92%).49,50
Visual acuity can range from mildly reduced to profound loss with no light perception. Reduction of vision occurs most commonly over days, but occasionally over hours. Visual loss is usually unilateral but can be bilateral. Color vision is affected more commonly than visual acuity, and there may be visual field deficits.
The red desaturation test is helpful in identifying optic neuropathies. This test is performed by having the patient look with one eye at a dark red object and then testing the other eye to see if the object looks the same color. The affected eye often will see the red object as pink or lighter red. An afferent pupillary defect (Figure 241­8) is commonly present. Funduscopic examination will reveal a swollen and edematous optic disk (papillitis) in approximately 30% of patients. If the head of the optic nerve is normal in appearance, the patient is said to have retrobulbar neuritis.
Optic neuritis can be idiopathic or an initial presentation of multiple sclerosis. Other causes of optic neuritis include post childhood vaccination; viral infections such as measles, mumps, chickenpox, encephalitis, herpes zoster, and mononucleosis; inflammation of structures contiguous with the optic nerve such as the meninges, orbit, and sinuses; and other infections, including syphilis, tuberculosis, Cryptococcus, and sarcoidosis. The differential diagnosis includes ischemic optic neuropathy (sudden onset and painless), papilledema (bilateral, painless with preserved visual acuity), hypertensive retinopathy, orbital tumor compressing the optic nerve (proptosis frequent), intracranial tumor compressing the visual pathway (seen on CT), and toxic or metabolic optic neuropathy from alcohol or various toxins such as the heavy metals or chloroquine.
Neurology and ophthalmology consultation are needed to establish a diagnosis. MRI results are important prognosticators for optic neuritis.50
ACUTE VISUAL LOSS WITHOUT PAIN
CENTRAL RETINAL ARTERY OCCLUSION
Central retinal artery occlusion is rare, thought to account for  in ,000 ophthalmic visits.51 The first branch off the internal carotid artery is the ophthalmic artery, which supplies the central retinal artery, which, in turn, provides the blood supply to the inner retina. If the central retinal artery becomes occluded, the inner retina will infarct and become pale, less transparent, and edematous. The macula is the thinnest portion of the retina, and the intact underlying choroidal circulation remains visible through this section of retina, creating the illusion of a “cherry red spot.” The macular area maintains its normal color, and the surrounding ischemic retina turns pale, thus causing this classic finding on fundoscopy (Figure 241­52). Causes include carotid or cardiac embolus, retinal artery thrombosis, giant cell arteritis, vasculitis (lupus, polyarteritis nodosa), sickle cell disease, trauma, vasospasm (migraine), elevated intraocular pressure (glaucoma), hypercoagulable states, and low retinal blood flow (carotid stenosis or hypotension).
FIGURE 241­52. Central retinal artery occlusion. Note macular “cherry red spot” and retinal pallor as well as the plaques visible in the retinal vessels. [Courtesy of Allen R. Katz, Department of Ophthalmology,
University of Nebraska Medical Center.]
Sudden (occurring over seconds), profound, painless, monocular loss of vision is characteristic of a central retinal artery occlusion. The event is often preceded by episodes of amaurosis fugax. Physical examination will often reveal an afferent pupillary defect in addition to the pale retina and cherry red macula. There is no evidence supporting or refuting the success of maneuvers such as digital massage or intraocular pressure–lowering drugs or breathing into a paper bag to increase partial pressure of arterial carbon dioxide.52 Local intra­arterial tissue plasminogen activator does not appear to be effective.53 More recent studies support IV tissue plasminogen activator within .5 hours of symptom onset54­56; however, ophthalmologists have not yet reached consensus on optimal management.57Consult an ophthalmologist and neurologist immediately when suspecting acute central retinal artery occlusion, and follow institutional protocols for treatment. Irreversible loss of visual function usually occurs after  hours of ischemia.
CENTRAL RETINAL VEIN OCCLUSION
Thrombosis of the central retinal vein causes retinal venous stasis, edema, and hemorrhage. Risk factors include diabetes, hypertension, cerebrovascular disease, cardiovascular disease, dyslipidemia, hypercoagulable states, vasculitis, glaucoma, and compression of the vein in thyroid disease and orbital tumors. Loss of vision is variable, ranging from vague blurring to rapid, painless, and monocular loss of vision. Funduscopic examination typically reveals optic disk edema and diffuse retinal hemorrhages in all quadrants (“blood­and­thunder fundus”) (Figure
241­53). The contralateral optic nerve and fundus generally are normal, which helps distinguish central retinal vein occlusion from papilledema, and the diffuse retinal hemorrhages help distinguish it from optic neuritis (the peripheral retina is normal in optic neuritis). While no universally beneficial treatment exists,58 anti–vascular endothelial growth factor and laser­induced chorioretinal anastomosis show promise.59 Consult neurology and ophthalmology.
FIGURE 241­53. Central retinal vein occlusion. The disk margin is blurred, the veins are dilated and tortuous, and there is a large amount of hemorrhage typical of the “blood­and­thunder fundus.” [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
RETINAL DETACHMENT/FLASHING LIGHTS AND FLOATERS
Complaints about new­onset flashing lights and/or floaters commonly cause patients to seek urgent medical attention. The first distinction to make is if the symptoms are monocular or binocular. Binocular complaints are almost always intracranial (i.e., ophthalmic migraines), whereas monocular complaints are almost always related to the symptomatic eye.
The posterior segment of the eye is a large cavity filled with vitreous gel. As a person ages, this gel eventually contracts centrally and separates from the posterior wall of the eye. The vitreous is very sticky and tugs on the retina before separation, stimulating the retina, which the brain perceives as light. The average age of onset is  years old, but it can occur as early as the 20s in severely nearsighted people. If the vitreous gel separates successfully, then floaters occur, which may persist for years until the gel liquefies enough for the floaters to sink below the visual axis. If the gel creates enough traction on the retina before separation that it tears a hole in the retina, then fluid can go through the retinal hole and start to peel the retina off like wallpaper.
Symptoms may include flashes of light, floaters, a dark veil or curtain in the field of vision, and decreased peripheral and/or central visual acuity. This is an emergent condition requiring a retina specialist to evaluate and treat the patient. Diagnosing a retinal detachment or tear or vitreous detachment requires a dilated indirect ophthalmoscopic evaluation by an ophthalmologist within  hours. Most tears occur in the peripheral retina, which is not visualized on the direct funduscopic examination. A large retinal detachment will appear as a pale billowing parachute on dilated funduscopic examination. See Figure 241­61 in the ocular US section later in this chapter for US diagnosis of retinal detachment. The US impression should be confirmed by the ophthalmologist who will manage the patient.
TEMPORAL ARTERITIS/GIANT CELL ARTERITIS
Temporal arteritis, or giant cell arteritis, is a systemic vasculitis involving medium­sized and large arteries. The temporal artery is the most common vessel involved. The disease causes optic neuropathy with profound visual loss and contralateral ocular involvement in days to weeks if not diagnosed and treated promptly. Patients are generally >50 years of age and frequently have a history of polymyalgia rheumatica. Symptoms may include headache, jaw claudication, myalgias, fatigue, fever, anorexia, and temporal artery tenderness. Many patients may have associated symptoms of transient ischemic attacks or stroke. The physical examination frequently will reveal an afferent pupillary defect if the optic nerve circulation is involved. An elevated sedimentation rate is usually present, with the majority of biopsy­proven cases in the range of  to 110 mm/h. The added presence of an elevated C­reactive protein also suggests the diagnosis. CT angiography is 71% sensitive and .7% specific for giant cell arteritis.60 MRI is 94% sensitive but only 78% specific.61 Ophthalmology should be consulted for management recommendations. Treatment consists of high­dose corticosteroids; however, the need for admission and IV steroids is controversial.62 If the patient has no visual symptoms, typically the patient would be started on prednisone  milligrams once daily until follow­up with ophthalmology within  week. Some ophthalmologists admit all patients with any visual loss for highdose IV methylprednisolone, 500 to 1000 milligrams per day for  days.62 Steroids should not be delayed while waiting for a temporal artery biopsy to be performed; however, biopsies should be performed within  week of starting steroid therapy. Tocilizumab is recommended for those resistant to or unable to take corticosteroids.61
CRANIAL NERVE PALSIES
Bell’s palsy is discussed in Chapter 172, “Acute Peripheral Neurologic Disorders.”
DIABETIC/HYPERTENSIVE CRANIAL NERVE PALSIES
Chronic diabetes and hypertension eventually can create vascular compromise to the vasa nervorum of any cranial nerve. The pupil is spared in acute diabetic cranial nerve III palsy due to vascular compromise of the central nerve fibers primarily (the efferent pupillomotor fibers run in the periphery of the nerve and are spared) (Figure 241­54). Extraocular muscle testing will reveal an inhibition of ipsilateral medial gaze, upward gaze, and downward gaze as well as ptosis in an acute cranial nerve III palsy. Lateral gaze (abduction) will be preserved, and diplopia will be worse when the patient attempts to look toward the contralateral side due to the inability to adduct the eye (medial rectus dysfunction). In an acute cranial nerve VI palsy, lateral gaze will be diminished (abduction) on the ipsilateral side, and diplopia will be worse when the patient is trying to look to the affected side (lateral rectus dysfunction). Neuroimaging is needed in the ED to rule out an intracranial lesion.
FIGURE 241­54. Posterior communicating artery aneurysm compresses the peripherally located pupillomotor fibers of cranial nerve (CN) III, causing a nerve palsy and pupillary dilatation. Diabetes and hypertension can cause microvascular compromise of the central nerve fibers, causing a nerve palsy with pupil sparing.
If no other associated neurologic symptoms or findings are present, the blood sugar and blood pressure are under control, and neuroimaging does not suggest an alternative diagnosis, the patient can be discharged with ophthalmology and/or neurology follow­up. Most cases show spontaneous improvement over time.
POSTERIOR COMMUNICATING ARTERY ANEURYSM
Acute cranial nerve III palsy with ipsilateral pupillary dilatation is a posterior communicating artery aneurysm until proven otherwise. Concomitant headache is a frequent but not absolute finding. Expansion of an aneurysm of the posterior communicating artery frequently causes compression of the outer fibers of cranial nerve III. The pupillomotor fibers are located in the outer portion of cranial nerve III; therefore, the pupil becomes dilated on the affected side (Figure 241­54). Treatment is emergent blood pressure reduction if hypertensive, neuroimaging, and neurosurgical consultation.
HORNER’S SYNDROME
The physical findings of ipsilateral ptosis and miosis and anhidrosis are characteristic of Horner’s syndrome (Figure 241­55). Interruption of the sympathetic nerve impulses controlling the superior tarsal muscle in the upper eyelid and the iris dilators causes these classic findings. Interruption can occur anywhere along the pathway from the brainstem to the sympathetic plexus surrounding the carotid artery (Figure 241­56). ED evaluation includes a chest radiograph, CT scan of the brain and cervical region, and CT angiogram or magnetic resonance angiography of the head and neck vessels for carotid dissection. Institutional protocols determine if CT angiogram or magnetic resonance angiography is preferred.
FIGURE 241­55. Horner’s syndrome. Note the ptosis and miosis of the right eye. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill,
New York.]
FIGURE 241­56. Sympathetic nerve pathway of the eye. An interruption anywhere along this pathway can cause Horner’s syndrome.
In adults, causes of Horner’s syndrome include cerebrovascular accidents, tumors, internal carotid artery dissection, herpes zoster, and trauma. In children, the causes include neuroblastoma, lymphoma, and metastasis. Neck pain and acute Horner’s syndrome suggest carotid dissection and can occur spontaneously (usually >30 years old) or as a result of blunt or penetrating neck injury. Patients presenting with Horner’s syndrome will most likely need CTA or MRI imaging of the head and neck.
PSEUDOTUMOR CEREBRI (IDIOPATHIC INTRACRANIAL HYPERTENSION)
Increased intracranial pressure, papilledema, normal cerebrospinal fluid, and normal CT/MRI characterize pseudotumor cerebri. Incidence is increasing.63 Patients complain of nausea, vomiting, headaches, and blurring of vision. Patients can develop cranial nerve VI paresis, causing horizontal diplopia (double vision on lateral gaze). A key component of examination is the identification of visual field defects. If CT/MRI is normal, perform lumbar puncture and record opening pressure; send cerebrospinal fluid for routine diagnostics.
Consult ophthalmology as well as neurosurgery or neurology for the treatment plan. Initial treatment is acetazolamide, 500 milligrams PO twice daily, and outpatient visual field monitoring.
OCULAR ULTRASONOGRAPHY
Direct visualization of intraocular structures can be limited by periorbital edema, corneal abrasions, hyphema, and cataracts. The superficial location of the eye and its cystic composition make US ideal in the assessment of a variety of ocular disorders. Ocular ultrasonography can expedite the diagnosis and management of several ocular emergencies, including retinal detachment, retrobulbar hematoma, globe perforation, lens dislocation, vitreous hemorrhage, and intraocular foreign body.64­66 The indications for ocular ultrasonography include loss of vision/decreased vision, eye pain, eye trauma, suspected intraocular foreign body, and head injury. The ability of emergency physicians to accurately diagnose ocular pathology using bedside ocular ultrasonography has been well documented in emergency medicine literature.64,65
SCANNING TECHNIQUE AND NORMAL ANATOMY
Use a .5­to 10­mHz linear array transducer and set the unit to “Ocular” for lower energy. Place the patient in a supine or partially upright position and have the patient keep the eyes closed (Figure 241­57). Apply a large amount of standard water­soluble US gel to the patient’s closed eyelid so that the transducer does not touch the eyelid. US gel is not detrimental to the eye. Without applying any pressure and asking the patient to look straight ahead with the eyes closed, scan the globe in sagittal and transverse planes. Stabilize the scanning hand over the bridge of the nose or on the forehead. Scan both eyes through closed eyelids for comparison. Examine the eyes in the neutral position and during gentle eye movements from side to side and up and down to thoroughly evaluate the orbit. Dynamic examination is crucial to identify adhesions, detachments, and membranes. The probe can also be moved side to side in both scanning planes to demonstrate the full extent of the structures in the eye. Adjust the depth so that the image fills the screen. The gain also needs to be adjusted multiple times during the examination to identify subtle abnormalities and avoid artifacts. Because the eye is a fluid­filled organ, it provides a perfect acoustic window for scanning and obtaining excellent images.67,68 (See Video:
Ocular Ultrasound.)
FIGURE 241­57. A high­resolution linear array US transducer is being applied to the closed eyelid. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
Video 241­6: Ocular Ultrasound
Used with permission from Fernando Lopez, MD.
Play Video
The normal eye appears as a circular hypoechoic organ. The cornea is seen as a thin hyperechoic layer parallel to the eyelid attached to the sclera at the periphery. The iris is identified as a linear echogenic line extending from the periphery toward the lens on both sides. The anterior chamber contains anechoic fluid and is bordered by the cornea, iris, and anterior reflection of the lens. The normal lens has anterior and posterior boundary echoes with an anechoic center and is biconvex in shape. The normal vitreous chamber is filled with anechoic fluid. Vitreous is relatively echo free in a young, healthy eye. Sonographically, the normal retina cannot be differentiated from the other posterior layers such as choroid and sclera (Figure 241­58). The evaluation of the retrobulbar space includes optic nerve, extraocular muscles, and bony orbit. The retro­orbital fat appears very echogenic. The optic nerve is visible as a hypoechoic linear region extending away from the globe posteriorly. Minor manipulations in the angulation of the probe are necessary to visualize the optic nerve. The central retinal artery and central retinal vein can be identified using Doppler.67,68
FIGURE 241­58. Normal eye in transverse view showing the anterior chamber, lens, vitreous, and optic nerve. [Courtesy of Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
OCULAR TRAUMA ULTRASONOGRAPHY
Assessment of patients with ocular trauma by US is of particular value when pain, soft tissue edema, and abnormalities like corneal edema, hyphema, or cataract make direct visualization of the posterior segment of the eye difficult. US can detect a wide variety of ocular pathologies from trauma including dislocated lens, globe disruption, vitreous hemorrhage, hyphema, retinal detachment, orbital emphysema, and retrobulbar hemorrhage. Suspected ruptured globe is a relative contraindication to US examination, due to the risk of extruding globe contents associated with direct pressure on and around the eye.65
US findings of globe rupture include distortion of the normal shape of the globe, decrease in the size of the globe, anterior chamber collapse, and vitreous hemorrhage.64 Ocular trauma can lead to buckling of the sclera and scleral folds, which appear sonographically as irregularities in globe contour, highly reflective at their top and shadowing the orbital tissues (Figure 241­
59). Sonographically, lens dislocation is seen as a highly reflective oval mass moving independently of the surrounding structures with eye movements. The dislocation is more readily visualized if it is complete or a cataract has formed. Hyphema can be identified on US as an echoic structure of variable echogenicity depending on the age of the bleed. Fresh hyphema will have low echogenicity and becomes more echogenic as it becomes organized. A retrobulbar (pre­ or postseptal) hematoma is visualized as an echoluceny posterior to the globe.69
FIGURE 241­59. Extensive globe rupture from trauma. US shows abnormal, irregular shape of the eye with ocular contents displaced posteriorly (arrows). [Courtesy of M. Blaivas and Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
INTRAOCULAR FOREIGN BODY ULTRASONOGRAPHY
The presence of an intraocular foreign body may not always be apparent on clinical examination. US is a useful adjunct for detecting and localizing intraocular foreign bodies, but visualization of intraocular foreign bodies depends on their intrinsic echogenicity. Metallic objects are especially visible because of their bright echogenic acoustic profile and associated shadowing or reverberation artifacts in the echolucent vitreous, whereas materials such as wood are more difficult to detect (Figure 241­60). Sonographic patterns of shadowing and comet tail artifacts may help distinguish different foreign body materials. The dynamic nature of the US examination is also helpful in anatomic localization, determination of the size, and analysis of the composition of the foreign body.70­72 With penetrating ocular injuries, a track of hemorrhage may be seen outlining the route of passage of a foreign body.
FIGURE 241­60. A hyperechoic foreign body (arrow) in the eye. Note the bright echogenic reverberation artifact (arrowheads). [Courtesy of M. Blaivas and Allen R. Katz, Department of Ophthalmology,
University of Nebraska Medical Center.]
RETINAL DETACHMENT ULTRASONOGRAPHY
Retinal detachment can be difficult to detect on physical examination, especially when the detachment is small. Bedside US reliably detects retinal detachment and is particularly useful when the examiner’s view to the retina is obscured by periorbital edema, blood, or other opacities. For the detection of retinal detachment, ultrasonography performed by an emergency physician has a sensitivity of 97% to 100% and a specificity of 83% to 92%.73,74
A retinal detachment is seen as an echogenic undulating membrane in the posterior to lateral globe, protruding into vitreous (Figure 241­61). Even in complete retinal detachments, the typically folded surface remains bound to the ora serrata anteriorly and the optic nerve head posteriorly. Unlike choroidal detachment that does not change with ocular movements, retinal detachment moves with eye movements.75 A shallow cuff of subretinal fluid may also be seen along with the detachment. On occasion, retinal detachments are also accompanied by vitreous hemorrhages.
FIGURE 241­61. Retinal detachment is seen as a hyperechoic membrane in the posterior aspect of the globe (arrow). [Courtesy of D. Chandwani and Allen R. Katz, Department of Ophthalmology, University of
Nebraska Medical Center.]
VITREOUS HEMORRHAGE ULTRASONOGRAPHY
Vitreous hemorrhage can be spontaneous or associated with trauma. Vitreous hemorrhage can interfere with vision and, if it is large, can potentially cause blindness. It appears as echogenic material in the posterior chamber. The sonographic appearance of vitreous hemorrhage depends on its age and the severity of the bleed. Increasing gain is helpful for detecting acute hemorrhages because they are often minimally echogenic. Early mild hemorrhages are seen as small dots or scattered low­amplitude reflective mobile opacities in the vitreous. As the hemorrhage matures and organizes, thick mobile membranes are formed in the vitreous. Sonographically, this is seen as vitreous filled with multiple large echoes (Figure 241­62). Due to gravitational forces, these opacities may also layer inferiorly. Echogenic stranding and scarring of the vitreous occur as time progresses.75­77 As vitreous hemorrhage becomes more echogenic, it can mimic the appearance of a retinal detachment. The main characteristics that can help in differentiating vitreous hemorrhage from retinal detachment are as follows: (1)
Retinal detachment moves with eye movements unlike vitreous hemorrhage, which will remain horizontal; and (2) vitreous hemorrhages are frequently seen in the middle portion of the posterior chamber, and retinal detachments almost always occur at the posterior­most portion of the eye, adjacent to the optic disk and macula.73
FIGURE 241­62. Bright echoes (enclosed in oval) in the posterior chamber demonstrating vitreous hemorrhage. [Courtesy of D. Chandwani and Allen R. Katz, Department of Ophthalmology, University of
Nebraska Medical Center.]
OPTIC NERVE SHEATH ULTRASONOGRAPHY TO DETECT ELEVATED INTRACRANIAL PRESSURE
Optic Nerve Sheath Measurement
Another novel use of bedside ocular US is the evaluation of the optic nerve sheath diameter to assess possible elevated intracranial pressure. Multiple studies have shown good correlation between intracranial pressure and sonographic optic nerve sheath diameter.78­85 On US, a normal optic nerve sheath measures up to .0 mm in diameter in adults, .5 mm in children, and .0 mm in infants.86 The linear probe is used in this assessment with the patient supine or with a 20­ to 30­degree head up tilt. The measurement is obtained  mm posterior to the globe for both eyes. A position of  mm behind the globe is selected because the US contrast is greatest at this point, and the measurements are more reproducible (Figure 241­63). Typically, three measurements are averaged. Current literature suggests that the cutoff value that provides the best accuracy for the prediction of intracranial pressure >20 mm Hg is .7 to .0 mm. Increased intracranial pressure should be suspected with values above this threshold. The sensitivity and specificity in detecting increased intracranial pressure using a cutoff value of .7 to .0 mm are in the range of 87% to 95% and 79% to 100%, respectively.87 In addition to elevated intercranial pressure, the differential for increased optic nerve sheath diameter includes an anterior orbital mass, optic neuritis, trauma, and cavernous sinus mass.88
FIGURE 241­63. An optic nerve sheath measuring .3 mm in a patient with head injury is shown. One set of calipers measures  mm behind the globe, and the second measures the optic nerve sheath diameter (arrow). [Courtesy of M. Blaivas and Allen R. Katz, Department of Ophthalmology, University of Nebraska Medical Center.]
CAUTIONS WITH OCULAR ULTRASONOGRAPHY
If globe rupture is suspected, avoid any manipulation or pressure upon the globe or eyelid.
Limit the duration of ocular US examination, especially when using spectral and color Doppler, and set the US unit for ocular imaging. The recommended exposure limits are half those of fetal imaging.
Various artifacts may interfere with ocular US examination. Orbital emphysema can make it difficult to visualize contents of the orbit.
Air bubbles within the vitreous, which may appear in the setting of trauma to the globe, may resemble an intraocular foreign body.


