## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 151: Sepsis
Michael A. Puskarich; Alan E. Jones
INTRODUCTION AND EPIDEMIOLOGY
Sepsis is a heterogeneous syndrome characterized by widespread inflammation and organ distress initiated by any type of microorganism. Invasion of the blood is not necessary to develop or identify sepsis, which is determined by the host response. As sepsis severity increases, a multifactorial series of events leads to impairments in perfusion, oxygen delivery, and direct cellular damage secondary to inflammation. Eventually, multisystem organ failure occurs, and mortality is high.
The varying clinical presentation leads to a wide range of estimates of the annual incidence of severe sepsis, ranging from 300 to 1000 cases per

100,000 persons per year, and most patients have initial hospital care in the ED. The sepsis incidence is increasing for multiple reasons, including an
 aging patient population.

Most patients with sepsis spend several hours in the ED, and once admitted, more than half will require care in an intermediate or intensive care unit.

Sepsis is the leading cause of hospital death, with mortality rates improved from a decade ago but still high, approximately 15% to 20% in optimal
,5  clinical trial scenarios. This hospital mortality rate approaches 50% in the sicker subset of those with septic shock. Sepsis hospital mortality exceeds
7­9 that of many other high­visibility acute care conditions. Morbidity is common, even after surviving a year, with a long­term deficit in cognition and
  functioning prevalent. Estimates from  years ago suggest annual national costs reaching $16.7 billion, which has certainly increased in the past decade. Sepsis is the single most expensive inpatient condition.

Gram­positive bacteria are the predominant pathogens of sepsis. Methicillin­resistant Staphylococcus aureus, vancomycin­resistant Enterococcus,
 and other multidrug­resistant organisms are common organisms. Fungal sources are more common now, particularly in immunosuppressed patients. The most likely causative microorganism varies based on the likelihood of exposure to drug­resistant microorganisms (due to recent healthcare exposures) and the anatomic site of infection.
DEFINITIONS
Sepsis syndromes exist on a continuum and are defined based on the presence of a systemic, dysfunctional host response that leads to organ
,14 failure. Historic and more recent definitions are often not sensitive or specific. Previously, sepsis was a suspected or confirmed infection with evidence of systemic inflammation (demonstrated either through evidence of the systemic immune response syndrome or laboratory abnormalities).
Severe sepsis was sepsis plus evidence of new organ dysfunction thought to be secondary to tissue hypoperfusion. Septic shock exists when cardiovascular failure occurs and carries the worst prognosis.
In 2016, the Third International Consensus Definitions for Sepsis and Septic Shock removed severe sepsis as a term and narrowed
 the definition of septic shock (Table 151­1). In Third International Consensus Definitions for Sepsis and Septic Shock, patients with suspected or proven infection, signs of systemic inflammation (without strict definitions), and organ failure (defined as a Sequential Organ Failure Assessment score of at least 2) have sepsis. Septic shock is defined as those with sepsis requiring vasopressors after adequate resuscitation and with an elevated lactate. These new definitions are simpler and better identify the highest­risk group. However, the new definitions diminish the sensitivity of detecting those in the middle ground (previously called severe sepsis), in whom death and morbidity rates are elevated compared to those simply infected, and
 for whom simple detection and care can alter illness trajectories and outcomes.
TABLE 151­1
The Third International Consensus Definitions for Sepsis and Septic Shock

Chapter 151: Sepsis, Michael A. Puskarich; Alan E. Jones 
. Terms of Use * Privacy Policy * Notice * Accessibility
Condition Definition Criteria
Sepsis Life­threatening organ dysfunction caused by a dysregulated host response to Suspected or proven infection and infection Increase in Sequential Organ Failure Assessment
(SOFA) score of  or more from baseline* Septic A subset of sepsis in which underlying circulatory and cellular metabolism Sepsis and shock abnormalities are profound enough to substantially increase mortality Vasopressor therapy required to maintain a mean arterial pressure ≥65 mm Hg and
Lactate >2 mmol/L despite adequate fluid therapy
*Can be assumed to be  in patients without known prior organ dysfunction.

An overlapping and potentially confusing recent mandate is the Centers for Medicare and Medicaid Services quality measure called SEP­1. Enacted prior to the Third International Conference definitions, it mandates specific actions to meet Centers for Medicare and Medicaid Services requirements, but it used the older definitions of severe sepsis and septic shock. Patients with severe sepsis and septic shock require the following clinical actions between initial recognition and  hours:
. Lactate measurement
. Blood and other cultures prior to antibiotic administration
. Antibiotic therapy directed at specific source or broadly
. Initial fluid therapy with  mL/kg of crystalloid
. If the initial lactate is elevated (>2 mmol/L), repeat lactate required prior to  hours
Patients with septic shock require the following additional actions:
. A repeat  mL/kg fluid bolus for persistent hypotension
. Initiation of vasopressor for persistent hypotension
. Reassessment and documentation using clinical or hemodynamic/oxygenation measurements to judge adequacy of volume status and tissue perfusion interventions
Recently, the Surviving Sepsis Campaign changed its recommendations to include measuring a lactate, obtaining blood cultures, starting antibiotics, beginning  mL/kg crystalloid for hypotension or a lactate >4 mmol/L, and initiating vasopressors during or after fluid resuscitation to maintain a
 mean arterial pressure >65 mm Hg, all within  hour of ED triage. However, there is no clear evidence yet to support this narrower time window for metric completion, and that aggressive measure is not yet widely adopted.
QUICK SEQUENTIAL ORGAN FAILURE ASSESSMENT (qSOFA)
The Quick Sequential Organ Failure Assessment (qSOFA) tool is a simple screening tool derived to identify patients at higher risk of death. Criteria include altered mental status, respiratory rate ≥22 breaths/min, and systolic blood pressure ≤100 mm Hg, with a score ≥2 indicating a high risk for poor outcome. This tool also aids in the rapid identification of high­risk patients immediately upon presentation whose care might benefit from being expedited.
Like the new definitions, the Quick Sequential Organ Failure Assessment enhances specificity for short­term mortality assessment at the expense of lower sensitivity; it may not identify those at risk for later disease progression. Many sepsis patients who might benefit from early aggressive treatment are negative according to the Quick Sequential Organ Failure Assessment, so it is currently recommended that a full Sequential Organ Failure
Assessment score be calculated on patients with infection requiring hospital admission. Unfortunately, this approach is hampered by the need for fairly complex calculations and laboratory testing that may delay identification; therefore, neither the Quick Sequential Organ Failure Assessment nor
,19,20 the full Sequential Organ Failure Assessment should completely replace clinical judgment about presence of sepsis or its perceived severity.
SYSTEMIC INFLAMMATORY RESPONSE SYNDROME (SIRS) PROGNOSIS
Having systemic inflammatory response syndrome criteria does not confirm the presence of infection or sepsis because these features are shared by many other noninfectious conditions such as trauma, pancreatitis, and burns (Figure 151­1). The systemic inflammatory response syndrome response is not a diagnosis or a good indicator of outcome; it is a crude means of stratification of patients with systemic inflammation.
FIGURE 151­1. Interrelationship between systemic inflammatory response syndrome (SIRS), sepsis, and infection.
Complementary risk stratification and adjustment can be pursued using various tools, including the Acute Physiology and Chronic Health Evaluation
  acuity system, the Sequential Organ Failure Assessment score, and the Mortality in Emergency Department Score. With the exception of the
Sequential Organ Failure Assessment score, now part of the definition of sepsis, these scoring systems are typically limited to research and are yet to be established as beneficial in the guidance or provision of clinical care.

Serum lactate across a wide spectrum provides prognostic data in those with sepsis, but it is not a singular test to diagnose or exclude sepsis.
Lactate arises from anaerobic metabolism, heightened with tissue hypoperfusion; it also accumulates from changes in aerobic metabolism that occur
 in response to widespread inflammation. As lactate increases, the risk of mortality rises, with the degree of lactate elevation and hypotension being
,26 independent predictors of mortality. Specifically, 28­day mortality rate associated with modest elevation of serum lactate to  to  mmol/L
 approaches 15% even in those patients without hypotension, and the rate continues to rise with increasing lactate levels. In general, venous or
 arterial lactate levels on either point­of­care bedside devices or measured in a central laboratory are useful ; even better are serial levels using the
 same method of sampling (arterial or venous) to identify improvement that mirrors clinical responses. This is called lactate clearance, defined as a drop over time; lactate clearance provides an independent prognostic value in addition to vital signs and other measurements. Patients with sepsis
,30 who do not clear lactate have a higher mortality rate than patients who do. The major limitation is that lactate is nonspecific and can be elevated in a number of conditions, and it must be used together with clinical judgment.
PATHOPHYSIOLOGY
,32
In sepsis, the host immune response fails to control or overreacts to invasive pathogens, leading to two critical events. First, the host first develops a hyperinflammatory response in the early stages of sepsis that evolves into a blunted response. This blunted response leads to an increased risk of secondary hospital­acquired infections and results in programmed death of key immune, epithelial, and endothelial cells, leading to tissue injury and multiorgan dysfunction.
The second event is an imbalance in procoagulant and anticoagulant functioning; in the most extreme of situations, this results in the clinical syndrome of disseminated intravascular coagulation. Disseminated intravascular coagulation causes micro­ and macrovascular clot formation and impaired microvascular tissue perfusion. Subclinical disseminated intravascular coagulation can lurk despite relatively normal basic laboratory
 findings and is associated with a worse prognosis. Microvascular ischemia adds to organ failure and the release of proinflammatory intracellular
 contents, which further stimulates the innate immune response and perpetuates the underlying pathology. As these events progress, the inflammatory response intensifies and a destructive cycle ensues (Figure 151­2). There are no current specific therapies to remedy microvascular dysfunction.
FIGURE 151­2. Pathogenic sequence of events in septic shock.
CLINICAL FEATURES
While some presentations are immediately clinically apparent, sepsis can present in a subtle or occult manner, particularly early in the course. Vital sign abnormalities—notably fever, hypotension, and/or tachycardia—are a hint to sepsis, recognizing that many patients with these findings may have
 another cause. In ED patients with undifferentiated hypotension, 40% will ultimately have an infectious cause of symptoms.
Although traditionally categorized as an example of distributive shock (peripheral vasodilation evidenced by warm extremities with a compensatory increased cardiac output), this presentation does not describe all patients with sepsis. ED patients with sepsis are often volume depleted from decreased intake and increased fluid losses (from emesis, diarrhea, or insensible losses). Intravascular volume depletion affects preload, cardiac output, and ultimately, peripheral perfusion. Further complicating matters is septic cardiomyopathy, a reversible process with impaired systolic
 function and diastolic relaxation. The combination of intravascular volume depletion and septic cardiomyopathy may manifest as “cold shock,” impaired peripheral perfusion and cool extremities.
PULMONARY INJURY
Widespread inflammation secondary to sepsis can affect pulmonary function even in the absence of pneumonia. Acute lung injury is common and may result in the acute respiratory distress syndrome, characterized by new lung edema from increased alveolar and capillary permeability. Acute
 respiratory distress syndrome classification uses the degree of hypoxemia and radiographic findings. The three mutually exclusive categories are mild (partial pressure of arterial oxygen [PaO ] divided by fraction of inspired oxygen [FIO ] of 200 to 300), moderate (PaO /FIO of 100 to 200), and
    severe (PaO /FIO <100), coupled with new bilateral pulmonary infiltrates on chest radiographs not explained by effusions, lung collapse, or nodules
  and not fully explained by heart failure or volume overload. Clinically, severe refractory hypoxemia, noncompliant lungs noted on mechanical ventilation, and a chest radiograph showing bilateral pulmonary alveolar infiltrates suggest the diagnosis. Mortality increases from 27% to 45% with increasing severity of acute respiratory distress syndrome.
RENAL INJURY
Acute kidney injury can present with azotemia, oliguria, or anuria. Factors increasing acute kidney injury risk include preexisting kidney dysfunction, depth and duration of hypotension, dehydration, and use of nephrotoxic substances (e.g., aminoglycoside antibiotics, nonionic IV contrast). Renal ischemic injury from hypoperfusion is a major factor in the pathogenesis of acute kidney injury in sepsis, although toxic products resulting from neutrophil–endothelial interactions, endothelial damage by various mediators, reperfusion injury, and microvascular thrombosis also contribute.
HEPATIC INJURY
Increased concentrations of transaminase, alkaline phosphatase (one to three times the normal level), and bilirubin (usually not >10 milligrams/dL) are evidence of this injury. Marked elevations of transaminases or bilirubin are less common unless shock is present; if seen, consider a biliary source of infection. Lessor elevations in liver function tests can result from intermittent or prolonged macro­ or microvascular hypoperfusion and ischemia or be secondary to direct endotoxin, cytokines, or immune complex damage. Red blood cell hemolysis from microvascular coagulation can cause jaundice.
GI CHANGES
The most common GI manifestation of sepsis is ileus, which may persist for days after shock resolves. Major blood loss secondary to upper GI bleeding is rare in septic patients. Minor GI blood loss within  hours of developing severe sepsis can result from painless erosions in the mucosal layer of the stomach or duodenum.
HEMATOLOGIC CHANGES
Multiple abnormalities are possible in the hematologic system in the setting of sepsis, including neutropenia or neutrophilia, thrombocytopenia, or disseminated intravascular coagulation. Neutrophilic leukocytosis with a left shift results from demargination and release of newer granulocytes from the marrow storage pools. However, the presence of excessive bands (the immature neutrophil) is neither sensitive nor specific. Neutropenia occurs rarely and is associated with increased mortality. Functional neutropenia creates a relative immunosuppression, particularly later in patients’ course.
Both red cell production and survival decrease, but anemia is usually preexisting or occurs if the patient has bleeding or experiences a prolonged course.
Thrombocytopenia may arise from disseminated intravascular coagulation but is present in >30% of cases of sepsis even in the absence of
,39 disseminated intravascular coagulation. Lower platelet levels are associated with worse outcomes. Mechanisms of thrombocytopenia include inhibition of thrombopoiesis, increased platelet turnover (due to a consumptive coagulopathy), increased endothelial adherence, and increased destruction secondary to immunologic mechanisms.
Finally, fulminant disseminated intravascular coagulation, where clinical clotting and bleeding coexist, is rare but associated with a very poor
 prognosis. Occult disseminated intravascular coagulation has microvascular flow abnormalities, subclinical increased activation of the coagulation system, and evidence of increased fibrinogen split products in the absence of overt bleeding and clotting, and is much more common than overt forms.
The activation of the hemostatic (clotting) system is due primarily to the activation of the extrinsic pathway of clotting. The fibrinolytic system is also activated and plays an important role in limiting fibrin deposition in the microcirculation. The release of tissue plasminogen activator activates the fibrinolytic system, at least initially. As sepsis progresses, there is an increased release of plasminogen activator inhibitor , which blocks plasmin generation and thus contributes to fibrin deposition in the microcirculation. Laboratory studies suggesting the presence of disseminated intravascular coagulation include thrombocytopenia, prolonged prothrombin and activated partial thromboplastin values, decreased fibrinogen and antithrombin
III levels, and increased fibrin monomer, fibrin split products, and d­dimer levels.
METABOLIC CHANGES
Sepsis induces multiple metabolic changes. Abnormalities in lactate metabolism come from tissue hypoperfusion with resultant anaerobic metabolism as well as increased aerobic production of lactate. Hyperglycemia is found in many, including patients without a history of diabetes; in this
 latter group, it is associated with a worse prognosis, in contrast to less impact of glucose elevations in those with known diabetes. Hypoglycemia, with glucose levels as low as  to  milligrams/dL, occurs but is uncommon, and it may result due to depletion of hepatic glycogen and inhibition of
 gluconeogenesis and/or adrenal insufficiency. Adrenal insufficiency exists in many patients and is caused by hypoperfusion of the adrenal glands, adrenal or pituitary hemorrhage, cytokine dysfunction of the adrenals, drug­induced hypermetabolism, inhibition of steroidogenesis by chemotherapeutics (e.g., ketoconazole), and desensitization of glucocorticoid responsiveness at the cellular level.
SKIN
Cutaneous manifestations of sepsis can include direct bacterial involvement of the skin and underlying soft tissues (cellulitis, erysipelas, and fasciitis); lesions from hematogenous seeding of the skin or the underlying tissue (petechiae, pustules, cellulitis, ecthyma gangrenosum); lesions from hypotension and/or disseminated intravascular coagulation (acrocyanosis and necrosis of peripheral tissues); lesions from intravascular infections
(microemboli and/or immune complex vasculitis); and lesions caused by toxins (toxic shock syndrome). Look for any necrotizing or surgical source of sepsis, and recall that the toxic shock syndromes present in an overlapping fashion.
DIAGNOSIS
In the ED, sepsis is a clinical diagnosis predicated on suspicion or confirmation of infection, systemic inflammation, and evidence of new organ
 dysfunction and/or tissue hypoperfusion. Septic shock now is a term used for those with sepsis receiving vasopressors after adequate resuscitation and with an elevated lactate.
The differential diagnosis of sepsis and septic shock includes other causes of shock. This includes cardiogenic, hypovolemic, anaphylactic, neurogenic, or obstructive shock (pulmonary embolism, cardiac tamponade) or endocrine disorders (adrenal insufficiency, thyroid storm) that mimic sepsis. Given the high frequency of sepsis in ED patients with undifferentiated shock (40%), think of this cause when uncertain.
Children may not have hypotension until very late during the disease process due to an ability to upregulate their heart rate as a compensatory response to tissue hypoperfusion. This means considering compensated shock and occult sepsis in infected children who do not appear well but with normal blood pressure.
Once sepsis is diagnosed, seek the source, but do not withhold interventions such as resuscitative measures and antimicrobials. Often the source is clear, with signs and symptoms attributable to a pulmonary, genitourinary, skin and soft tissue, or intra­abdominal source. However, a source of infection is often not readily apparent.
The most common sepsis trigger is acute bacterial pneumonia, although viral and bacterial etiologies are difficult to initially differentiate. The most frequent causative organisms are Streptococcus pneumoniae, S. aureus, gram­negative bacilli, and Legionella pneumophila. A chest radiograph may identify air space changes and pneumonia, although radiograph findings can lag behind the clinical presentation (see also Chapter , “Community­
Acquired Pneumonia, Aspiration Pneumonia, and Noninfectious Pulmonary Infiltrates”).
Acute pyelonephritis, typically due to gram­negative enteric bacteria or enterococci, is another frequent cause of severe sepsis. Other abdominal triggers include cholecystitis and cholangitis, each rare but devastating sources of septic shock, and both require immediate surgical assessment. If there is abdominal tenderness or peritonitis, the possibilities include perforated viscous, appendicitis, diffuse colitis, or intra­abdominal abscesses.

Acute pancreatitis can result in a presentation identical to that of septic shock due to widespread inflammation. If peritonitis or organ ischemia/necrosis exists, early surgical consultation is needed. In women of childbearing age, septic abortion and postpartum endometritis or myometritis are unusual etiologies of septic shock.
The most common skin and soft tissue infection triggering a sepsis syndrome is cellulitis due to S. aureus or Streptococcus pyogenes. Soft tissue infections caused by gram­negative organisms are indistinguishable from those caused by staphylococci or streptococci.
Necrotizing soft tissue infections often happen in immunocompromised patients, diabetic patients, or patients with a history of poor vascular circulation (see Chapter 152, “Soft Tissue Infections”). Pay close attention to skin and soft tissue infections, particularly in elderly or obtunded patients. Include an assessment for decubitus ulcers and a genitourinary assessment to look for a necrotizing infection such as Fournier’s gangrene. In female patients, particularly those with a rash, a pelvic exam including an assessment for a retained foreign body or tampon responsible for toxic shock syndrome is important.
Those without an obvious source of septic shock may have primary bacteremia or endocarditis. The most prevalent causes of primary bacteremia in outpatients are S. aureus, S. pneumoniae, and Neisseria meningitidis. Pseudomonas aeruginosa and other gram­negative bacteria are occasional causes of bacteremia and endocarditis in injection drug users. Secondary bacteremia from indwelling medical devices, including intraperitoneal or intravascular dialysis catheters, chemotherapy ports, peripherally inserted central catheters, ventriculoperitoneal shunts, and pacemaker/defibrillators, is possible. Although bacteremia can be suspected, it takes time for a blood culture to be fully assessed, making ED diagnosis difficult.
Acute bacterial meningitis is a devastating but rare cause of septic shock. Community­acquired meningitis with shock is usually caused by S.
pneumoniae or N. meningitidis (see Chapter 174, “Central Nervous System and Spinal Infections”). Brain and spinal abscesses, subdural or epidural empyemas, and viral CNS infections are seldom associated with shock on the initial presentation. Shock is also unusual in neurosurgical patients with
S. aureus or enteric gram­negative meningitis secondary to neurosurgical procedure or skull fracture.
LABORATORY TESTING AND IMAGING
Tests are useful to assess the general hematologic and metabolic state of the patient and aid in detecting occult bacterial infection, uncovering a specific microbial cause of infection, and identifying occult severe sepsis. Common tests include a CBC with platelet count; serum electrolytes
(including calcium and glucose); renal function panel (BUN and creatinine levels); lactic acid level; liver function panel (bilirubin, alkaline phosphate, and aspartate and alanine aminotransferase levels); and urinalysis. An arterial blood gas aids the metabolic, ventilatory, and oxygenation assessment in select patients. In the setting of active bleeding or suspected disseminated intravascular coagulation, obtain prothrombin time, activated PTT, fibrinogen, and D­dimer.
Given the frequency of pneumonia or concomitant acute respiratory distress syndrome, obtain a chest radiograph. Obtain abdominal plain radiographs or CT scan in patients if perforation or diffuse inflammation suspicions exist, and US can identify a biliary source. Soft tissue CT scans to assess for the presence of free air in the tissue or deep space abscesses may assist in making the diagnosis of necrotizing skin and soft tissue infections. Perform head CT and lumbar puncture in any patient with potential meningitis, but do not delay antibiotics pending these tests. Order MRI if possible spinal epidural abscess is present.
In adults with sepsis, obtain at least two separate sets of blood cultures from different venipuncture sites when possible. Order
Gram staining and culture of secretions from any potential site of infection when possible.
Other tests of interest in the assessment of sepsis include C­reactive protein and procalcitonin, both of which reflect systemic inflammation; neither of
,44 these tests excludes sepsis, and they are not routinely needed in the ED. Both of these tests may be better suited to guide the necessity of initiating
 or continuing antimicrobial therapy outside of sepsis or after a treatment course.
TREATMENT
The cornerstones of the initial treatment and stabilization of severe sepsis are early recognition, early reversal (or prevention) of
 hemodynamic compromise, and early infection control. Base the resuscitation on administering fluids, frequently assessing response, and adding adjunct therapies including vasopressors based on the conditions. The specific method of titrating resuscitation is less important than treating early and aggressively.
The goals of resuscitation are to improve preload, tissue perfusion, and oxygen delivery. There is no set amount of fluid, although most patients will require a total (bolus plus infusion) of  to  L of crystalloid in the first  hours to achieve optimal outcomes. Similarly, do not delay vasopressors when blood pressure does not respond to volume or if volume overload seems likely. Administer appropriate antibiotics and remove any nidus of infection. Each of these interventions will be discussed in detail below. Once the patient is stabilized, other interventions such as appropriate management of oxygenation and ventilation, fever control to reduce metabolic demand, and control of hyperglycemia may be needed to improve patient outcomes.
The following is a sepsis checklist:
In those with signs or symptoms of infection, look for occult shock: check vital signs and consider lactate early and repeat if in doubt.
Give appropriate antimicrobials to patients with suspected sepsis as soon as possible.
Look hard for the infection source, including getting blood cultures and seeking a surgical, gynecologic, or indwelling medical device infection.
Give at least  to  L bolus of IV crystalloid (lactated Ringer’s) to hypotensive patients or patients with elevated lactate and monitor the response.
Recheck resuscitation responses using more than one measure—better vital signs/shock index, improved clinical appearance, improved mentation and urine output, decreasing lactate, and/or improved central venous pressure or oxygen saturation.
A central venous catheter is not mandatory to resuscitate most patients, and central venous pressure trends are more important than absolute values.
Give more fluids if not clinically better and there is no evidence of volume overload. Often,  to  L are needed in the first  hours. Use balanced fluids after  to  L when possible.
Administer norepinephrine as the first­line vasopressor to patients with refractory hypotension despite adequate fluid resuscitation.
Although not mandatory for all, consider central venous pressure and central venous oxygen monitoring to titrate dobutamine and packed red blood cells, and consider corticosteroids in those with refractory shock.
EARLY QUANTITATIVE RESUSCITATION
The primary deficit leading to poor outcomes in shock states (typically studied in hemorrhagic shock) is a mismatch between oxygen supply and
  demand, and after a certain time point, processes initiated by this mismatch are irreversible. In 2001, Rivers et al described the use of an early, structured hemodynamic resuscitation protocol driven by a central venous catheter with continuous oximetric capability to titrate fluids to central venous pressure, vasopressors to mean arterial pressure, and transfusion of blood or inotropes to central venous oxygen saturation (S ). This
CVO2 protocol, termed early goal­directed therapy, decreased mortality when compared with standard care, although all patients had central venous catheters placed early. Follow­up uncontrolled observational studies confirmed that even partial use of this approach lowered mortality in settings
48­52 compared with previous time periods prior to education and interventions to increase aggressive early sepsis detection or care.
In a second large trial, Jones et al  randomized patients to this protocol or a protocol that measured lactate clearance of ≥10% rather than S . The
CVO2 lactate clearance protocol was noninferior to continuous S monitoring in the setting of ED­based resuscitation of septic shock. Lactate clearance–
CVO2 guided therapy (titrating fluids and vasopressors) became an alternative to invasive S monitoring and early goal­directed therapy. Although the
CVO2
,30 ideal lactate clearance target remains unclear, a minimum of 10% relative lactate clearance and normalization of lactate to <2 mmol/L emerged as
,53   goals. Still, about one third of patients with severe sepsis have a normal lactate, and up to one half or more have a normal S , limiting either
CVO2 tool in guiding therapy.

Most recently, the ProCESS, ARISE, and ProMISE trials compared structured, quantitative resuscitation (the Rivers early goal­directed therapy protocol) to usual care chosen by the bedside clinician in ED treatment groups after early identification and antibiotics. These resuscitative approaches all delivered different care, but all groups received aggressive fluids and vasopressors in addition to early recognition and antibiotic use; however, no one approach was superior in terms of morbidity or mortality. Furthermore, pooled subgroup analyses failed to demonstrate benefit in any
 subgroup of patients. These trials emphasize that the early recognition of sepsis, administration of antimicrobials, adequate volume resuscitation, and assessment of the adequacy of circulation are the important elements that improve outcomes, not any specific path of resuscitation. These observations allow providers or sites the flexibility of crafting the best approach to care but show that mandatory central venous catheterization and monitoring of central venous pressure or S are not necessary for all patients with sepsis.
CVO2
VOLUME RESUSCITATION
When resuscitating an ED patient with sepsis, first assess and replenish circulating volume, typically with an initial  to  mL/kg crystalloid bolus, preferably through large­bore IVs. This amounts to an approximate 1­ to 2­L bolus of lactated Ringer’s or normal saline solution in a 70­kg adult, although some patients require more or less. Saline can produce a hyperchloremic metabolic acidosis if used in large­volume resuscitation. A large cluster randomized trial that studied the effect of saline versus balanced fluids across an entire hospital (including both EDs and intensive care units) demonstrated that the use of balanced fluids (such as lactated Ringer’s) induced less acute kidney injury in sepsis with a modest effect on
,60 mortality. These effects appear most notable in more critically ill patients receiving large volume. Balanced fluids appear to be preferable, particularly among more critically ill patients or those receiving large volumes of fluids. Colloids are not needed in early sepsis care, and hydroxyethyl starch can worsen acute kidney injury.
The most important variable process in volume replacement is determining whether a patient is volume responsive. There are several more sophisticated measurements that can be used to make this determination such as cardiac output and stroke volume variation. The latter entails lifting the legs of a supine patient for  seconds; improved blood pressure or less variation in the peak blood pressure wave (if an arterial line is present) identifies a volume­responsive patient who will likely benefit from more fluid. If these tools are unavailable, assess the need for further volume expansion with empiric crystalloid boluses until the patient fails to demonstrate a physiologic or hemodynamic response.
VASOPRESSORS
Once the patient fails to respond to further IV volume expansion, aid perfusion with vasoactive agents. In general, target a mean arterial pressure goal
 of  mm Hg; routine targeting of a higher mean arterial pressure does not aid outcomes. A mean arterial pressure is preferable to a specific systolic blood pressure goal; however, systolic pressure is commonly used in practice, seeking a goal of  mm Hg or higher.
Peripheral vasopressor use to start care is safe; high­dose and prolonged infusions are better deployed using a central venous line to limit extravasation and resultant tissue necrosis. When using peripheral catheters, make sure they are large, secured, and not distal.
In septic shock, norepinephrine, .5 to  micrograms/min, is the best first choice since the dual α­ and β­adrenergic effects result in peripheral vasoconstriction and cardiac inotropy. Dopamine has a higher rate of complications, most notably dysrhythmias and failure, compared with
 norepinephrine and is no longer routinely recommended. Vasopressin is a second­line agent and may allow for the downtitration of the
 norepinephrine dose. Give vasopressin as a constant infusion at a rate of .03 or .04 U/min. Do not titrate the dose, because higher rates are associated with vasospasm and high morbidity. Epinephrine at a dose of  to  micrograms/min is an option instead of norepinephrine when dosed
 appropriately, although the risk of medication dosing errors related to epinephrine concentration may make norepinephrine a superior choice. If tachydysrhythmias are a problem, phenylephrine is an option as a pure α­adrenergic agonist.
CENTRAL VENOUS OXYGENATION
After volume repletion and perfusion pressure optimization, if tissue perfusion is compromised (cool extremities, poor pulses, worsening organ function), assess oxygen balance. Although not needed routinely, measuring continuous S with a catheter can aid additional therapy as outlined in
CVO2
 the early goal­directed therapy approach. An S <70% implies a relative oxygen supply and demand mismatch.
CVO2
LACTATE CLEARANCE
A decrease in lactate over time suggests a restoration of adequate tissue perfusion. Measure lactate using the same method  to  hours apart;
 improvement of 10% or more is associated with improved clinical outcomes. Larger reductions in lactate are associated with even better outcomes, although whether targeting higher amounts of lactate clearance leads to improved outcomes remains unclear and is not recommended.
TREAT INFECTION

Give broad­spectrum antibiotics as early as possible for severe sepsis. Combination antibiotic therapy as opposed to monotherapy leads
 to improved outcomes, potentially due to higher rates of bactericidal activity. Recommendations for antibiotic regimens are provided in Table 151­
. Therapy can later be tailored based on clinical response and microbiologic data. Given the high rates of community­acquired methicillin­resistant S.
 aureus, ensure this is covered along with gram­negative pathogens and anaerobic organisms. Vancomycin is often underdosed in clinical practice,
 and guidelines suggest an initial dose of  to  milligrams/kg in critically ill patients. In immunosuppressed patients, consider antifungal or antiviral agents.
TABLE 151­2
Empiric Antibiotic Selection in Severe Sepsis and Septic Shock
Host Likely Pathogens Initial Antibiotic Selection
Adults (nonneutropenic) without an obvious source of infection Staphylococcus aureus, streptococci, Imipenem, 500 milligrams every  gram­negative bacilli, others h to  gram IV every  h or
Meropenem,  gram IV every  h or
Doripenem, 500 milligrams IV every  h or
Ertapenem*,  gram IV every  h plus
Vancomycin†,  milligrams/kg loading dose
Adults (nonneutropenic), suspected biliary source Aerobic gram­negative bacilli, enterococci Ampicillin/sulbactam,  grams IV every  h or
Piperacillin/tazobactam, .5 grams IV every  h or
Ticarcillin/clavulanate, .1 grams
IV every  h plus
Metronidazole,  milligrams/kg
IV load then .5 milligrams/kg every  h
Adults (nonneutropenic), suspected pneumonia Streptococcus pneumoniae, methicillin­ Ceftriaxone, 1–2 grams IV every  resistant S. aureus, gram­negative bacilli, h
Legionella plus
Azithromycin, 500 milligrams IV, then 250 milligrams IV every  h plus
Levofloxacin, 750 milligrams IV every  h ormoxifloxacin, 400 milligrams IV every  h plus
Vancomycin†,  milligrams/kg loading dose
Adults (nonneutropenic), suspected illicit use of IV drugs S. aureus Vancomycin†,  milligrams/kg loading dose
Adults with petechial rash Neisseria meningitidis, RMSF Ceftriaxone,  grams IV every  h or
Cefotaxime,  grams IV every 4–6 h
Consider
Addition of doxycycline 100 milligrams IV every  h for possible RMSF
Adults (nonneutropenic), suspected intra­abdominal source Mixture of aerobic and anaerobic gram­ Imipenem, 500 milligrams IV every negative bacilli  h to  gram IV every  h or
Meropenem,  gram IV every  h or
Doripenem, 500 milligrams IV every  h or
Ertapenem,  gram IV every  h or
Ampicillin/sulbactam,  grams IV every  h or
Piperacillin/tazobactam, .5 grams IV every  h plus
Metronidazole,  milligrams/kg
IV load then .5 milligrams/kg every  h#
Adults (nonneutropenic), suspected urinary source (hospitalized with Aerobic gram­negative bacilli, enterococci Levofloxacin, 750 milligrams IV pyelonephritis) every  h or
Moxifloxacin, 400 milligrams IV every  h or
Piperacillin/tazobactam, .5 grams IV every  h or
Ceftriaxone, 1–2 grams IV every
12–24 h or
Ampicillin, 1–2 grams IV every 4–6 h plus
Gentamicin, .0–1.5 milligrams/kg
‡ every  h
Adults (nonneutropenic), suspected urinary source (complicated Enterobacteriaceae, Pseudomonas Piperacillin/tazobactam, .5 urinary tract infection/urinary catheter) aeruginosa, enterococci, rarely S. aureus grams IV every  h or
Imipenem, 500 milligrams every  h to  gram IV every  h or
Meropenem,  gram IV every  h or
Doripenem, 500 milligrams IV every  h or
Ampicillin, 1–2 grams IV every 4–6 h plus
Gentamicin, .0–1.5 milligrams/kg
‡ every  h
Neutropenic adults Aerobic gram­negative bacilli, especially P. Ceftazidime,  grams IV every  h aeruginosa, S. aureus or
Cefepime,  grams IV every  h or
Imipenem, 500 milligrams IV every
 h to  gram IV every  h or
Meropenem,  gram IV every  h or
Piperacillin/tazobactam, .5 grams IV every  h plus
Levofloxacin, 750 milligrams IV every  h ormoxifloxacin, 400 milligrams IV every  h plus
Vancomycin†,  milligrams/kg loading dose and consider
Fluconazole, 400 milligrams IV every  h or micafungin, 100 milligrams every  h
Patients with suspected anaerobic source: intra­abdominal, biliary, Anaerobic bacteria plus gram­negative Metronidazole,  milligrams/kg female genital tract infection; necrotizing cellulitis; odontogenic bacilli (also see suspected biliary or intra­ IV load, then .5 milligrams/kg infection; or anaerobic soft tissue infection abdominal source, above) every  h# or
Clindamycin, 600–900 milligrams
IV every  h
Patients with indwelling vascular devices Coagulase­negative Staphylococcus, Vancomycin†,  milligrams/kg methicillin­resistant S. aureus loading dose
Patients with potential for Legionella species infection Azithromycin, 500 milligrams IV, then 250 milligrams IV every  h or
Erythromycin, 800 milligrams IV every  h should be added to the regimen
Asplenic patients S. pneumoniae, N. meningitidis, Ceftriaxone,  gram IV every  h
Haemophilus influenzae, Capnocytophaga up to  grams IV every  h if meningitis
Abbreviation: RMSF = Rocky Mountain spotted fever.
*Ertapenem has no antipseudomonal coverage and is not recommended in many intensive care units due to concerns of potentiating pseudomonal antimicrobial resistance.
†Methicillin­resistant S. aureus colonization is extremely high, and consideration should be given to including vancomycin in addition to the antibiotic recommendations. Vancomycin dosage is typically suggested at  milligrams/kg but can delay effective antimicrobial activity; initial dosages of  to  milligrams/kg have been recommended by some authorities. If the patient has an allergy to vancomycin, linezolid 600 milligrams IV can be substituted.
‡
Multiple daily dosing:  milligrams/kg load then .7 milligrams/kg every  h.
#Metronidazole is often prepackaged as 500­milligram bags. Dosing at 500 milligrams IV every  or  h to approximate the milligram per kilogram dosing may speed time to antibiotic administration.
The Surviving Sepsis Campaign recommends giving antibiotics as soon as feasible, ideally within  hour of the recognition of severe sepsis and/or within  hours of triage. However, a meta­analysis failed to demonstrate that patients receiving antibiotics before versus after  hours from triage had improved outcomes. Ultimately, these suggestions are not commonly used or adopted by other organizations for many reasons, including ability to
 achieve an overall effect.
Whether antimicrobials are best given initially or after hemodynamic stabilization of the patient remains unclear. A randomized controlled trial of prehospital ceftriaxone demonstrated a reduction in time to antibiotics but no effect on mortality, giving further support to the notion of
 administration as soon as feasible but without an absolute time target. Given the poor prognosis associated with delays in either resuscitation or infection therapies, we recommend delivering both together. Ideally, sample any organ infectious source and obtain blood cultures prior to the
 initiation of antibiotics, but do not delay the initiation of antibiotics to obtain cultures.
Infection control is not confined to antimicrobial administration; it also includes addressing potential surgical sources of infection. Drain any source and remove indwelling vascular lines and other medical devices suspected as infected once the patient is stabilized.
OTHER THERAPIES: VENTILATION, GLYCEMIC CONTROL, ACTIVATED PROTEIN C, STEROIDS, AND OTHER
ADJUNCTIVE TREATMENTS
Sepsis is the leading cause of acute respiratory distress syndrome; mechanical ventilation is discussed in Chapter . In those with acute respiratory
 distress syndrome findings, low tidal volume ventilation (6 mL/kg ideal body weight) limits barotrauma and improves outcomes. It is unclear whether a fixed tidal volume of  mL/kg is best for all; some titration is permissible. Positive end­expiratory pressure adequate to prevent alveolar collapse is recommended. Patients may be allowed some hypercapnia if the accompanying acidosis does not threaten hemodynamic deterioration.
Hyperglycemia is associated with worsened outcomes in the setting of sepsis. Due to the high rate of hypoglycemia, tight (<110 milligrams/dL) glucose
 control is no longer recommended; modest goals of <180 milligrams/dL allow for similar outcomes. Glucose control is most important after initial care and is best if protocolized, especially for patients receiving extended sepsis care in the ED.
Therapies to manipulate the coagulation cascade are unproven; the most promising candidate to date, activated protein C, failed to improve outcomes
 72­74 and is not used. Systemic corticosteroids are the only anti­inflammatory agent in use in clinical practice but remain controversial.
Hydrocortisone shortens the time to shock reversal in refractory hemodynamic shock (i.e., requiring more than one vasopressor after adequate volume restoration) as well as those receiving mechanical ventilation, although trials have not demonstrated a consistent mortality benefit. Patients
 with refractory septic shock for at least  hours may have a mortality benefit from the combination of hydrocortisone and fludrocortisone.
Stimulation testing using adrenocorticotropic hormone is not clinically helpful. Although even a single dose of etomidate may alter adrenal activity as
 measured by laboratory tests, there is no clear evidence that the use of etomidate to facilitate endotracheal intubation alters any clinically important outcome. A single­center before­and­after study of a cocktail of corticosteroids combined with vitamin C and thiamine demonstrated a dramatic
 mortality benefit and received significant media attention, although it was limited by the study design and methodology, and it remains unproven at this time. Given that these trials predominantly demonstrate benefit in refractory septic shock that may not be established until intensive care unit admission, deferral to the intensive care unit regarding these therapies is a reasonable approach, although they could be considered in appropriately selected ED patients with a prolonged time to admission.
SPECIAL POPULATIONS
ASYMPTOMATIC PATIENTS WITH POSITIVE BLOOD CULTURES
There is no consensus for interpretation or management of positive ED blood cultures in asymptomatic patients. Corynebacterium species, Bacillus species, and Propionibacterium acnes rarely represent true bacteremia or require action. Other organisms such as viridans group streptococci, enterococci, and coagulase­negative Staphylococcus (the most common organism reported on blood culture notifications) may represent a pathogen or require new care in a given patient. In both ambulatory and ED patients, blood cultures are positive in <10% of cases, with only one third to two
 thirds of those cultures representing true bacteremia.
An important predictor of true­positive first blood culture is persistence of the organism on subsequent culture if the latter was done separately (time and location). In a discharged patient, this requires reevaluation, either in the ED or by another provider. Decisions regarding antibiotics or admission are guided by the pathogen and clinical grounds: All highly lethal pathogens should receive therapy and admission, whereas some pathogens in blood culture may clear with or without therapy.
POSTSPLENECTOMY PATIENTS
Patients without a spleen are at increased risk for infection with encapsulated species such as Salmonella or Haemophilus influenzae. Table 151­2 details treatment recommendations of these patients. Given the frequent rapid and dramatic progression of their disease process, manage asplenic patients quickly. Although not relevant at the time of initial sepsis care, these patients should have appropriate bacterial immunization following a splenectomy.
NEUTROPENIC FEVER
Due to an impaired immune system, neutropenic patients are at increased risk for developing sepsis and worse outcomes. Any fever in a neutropenic patient is suspicious for infection, and all patients should have source organ and blood cultures drawn followed by empiric antibiotics. After conferring with an oncologist, some patients may be treated at home with oral broad­spectrum agents (often including a quinolone) if they look well and are closely followed; the rest are admitted.


