## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 180: Antipsychotics
Michael Levine; Frank LoVecchio
ANTIPSYCHOTICS
INTRODUCTION
The first­generation (typical) antipsychotics, introduced in the 1950s, were effective against the positive features of psychosis (e.g., delusions, hallucinations, disorganized thought) but provided no treatment for the negative features (e.g., avolition, alogia, social withdrawal). In addition, numerous adverse side effects associated with these agents led to poor patient compliance. The second­generation (atypical) antipsychotics were introduced in the 1990s, and the third generation followed in the 2000s. These second­ and third­generation drugs work on both the positive and negative symptoms and, when taken at therapeutic doses, are associated with fewer extrapyramidal effects than the first­generation antipsychotics
(Table 180­1).
TABLE 180­1
Common Antipsychotics
Brand Name in the Typical Adult Maintenance Maximum Adult Daily Dose for Elimination Half­Life
Generic Name
United States Dose (milligrams) Psychosis (milligrams) (oral dosing)
First­generation or typical antipsychotics
Chlorpromazine Thorazine®* 50–100 orally  or  times day 1000 23–37 h (parent drug)
10–40 h (active metabolite)
Fluphenazine Prolixin®* 1–2.5 orally  or  times a day   h
Haloperidol Haldol®* .5–2 orally  to  times a day 100 21–24 h
Loxapine Loxitane® 15–25 orally  to  times a day 250 3–4 h
Perphenazine Trilafon®* 8–16 orally  to  times a day  9–12 h
Pimozide Orap® 2–10 orally once or twice a day   h
Prochlorperazine# Compazine®* 5–10 orally  or  times a day 150 3–5 h
Promethazine# Phenergan® .25–25 orally  to  times a day 100 7–14 h
Thioridazine Mellaril®* 50–100 orally  to  times a day 800  h
Thiothixene Navane®* 2–5 orally  to  times a day   h
Trifluoperazine Stelazine®* 2–5 orally twice a day   h

Chapter 180: Antipsychotics, Michael Levine; Frank LoVecchio 
Second­generation or atypical antipsychotics
. Terms of Use * Privacy Policy * Notice * Accessibility
Amisulpride† Solian® 200 orally twice a day 1200  h
Asenapine Saphris® 5–10 SL twice a day   h
Brexpiprazole Rexulti® 2–4 orally once a day   h
Cariprazine Vraylar® .5–6 orally once a day  2–4 d (parent drug)
1–3 wk (active metabolite)
Clozapine Clozaril® 150–300 orally twice a day 900  h (single dose)
 h (steady state)
Iloperidone Fanapt® 6–12 orally twice a day   h (extensive metabolizers)
 h (poor metabolizers)
Lurasidone Latuda® 4–160 orally once a day 160  h
Olanzapine Zyprexa®  orally once a day  21–54 h
Paliperidone Invega®  orally once a day in the   h morning
Pimavanserin Nuplazid®  orally once a day   h (parent drug)
200 h (active metabolite)
Quetiapine Seroquel® 50–100 orally  or  times a day 800 6–7 h
Risperidone Resperidal® 1–2 orally once or twice a day   h
Sulpiride† Dogmatil® 200–400 orally twice a day 1200  h
Ziprasidone Geodone®  orally twice a day 160  h
Third­generation antipsychotics
Aripiprazole Abilify® 10–15 orally once a day   h (extensive metabolizers)
146 h (slow metabolizers)
Brexpiprazole Rexulti® 2–4 orally once a day   h
Cariprazine Vraylar® .5–6 orally once a day  2–4 d (parent drug)
1–3 wk (active metabolite)
Note: Several of these drugs are used for other conditions, such as nausea/vomiting, allergic disorders, and hiccups.
Abbreviation: SL = sublingual.
*Brand name formulation has been discontinued in the United States.
†Not available in the United States.
#Promethazine and prochlorperazine have low antipsychotic potency.
Antipsychotics were historically referred to as major tranquilizers or neuroleptics. With the advent of the atypical antipsychotics, it became clear that antipsychotic properties do not necessarily parallel neuroleptic properties. For this reason, the preferred term is antipsychotics. These drugs are sometimes administered to treat other conditions, such as agitation, nausea and vomiting, and headache conditions; to suppress hiccups; and to control involuntary motor disorders, such as Tourette’s syndrome, Huntington’s chorea, and basal ganglia disorders.
PATHOPHYSIOLOGY
More than  different antipsychotics are available worldwide. Their pharmacologic effect is mediated by binding to CNS dopaminergic, α­adrenergic,
 muscarinic, histaminergic, and serotoninergic receptors. In overdose, the clinical toxicity is primarily an exaggerated effect of the pharmacologic activity.

Virtually all antipsychotics bind to (and inhibit) presynaptic and postsynaptic dopamine­2 (D ) receptors in the CNS. Blockade of dopamine receptors
 in different regions of the brain produces varying effects. Blockade of D receptors in the mesocortical and mesolimbic system is associated with
 antipsychotic efficacy, whereas D receptor blockade in the area postrema (chemotactic trigger zone) is responsible for antiemetic activity.

The third­generation agents, such as aripiprazole, are also partial D ­agonists, with effects dependent on the concentration of dopamine. At low levels
 of dopamine, they will stimulate the D receptors, and at high levels of dopamine, they will inhibit the D receptors.

Blockade of the D receptors in other regions of the brain produces many of the adverse effects associated with antipsychotics. Antagonism of the D
  receptors in the tuberoinfundibular region is associated with hyperprolactinemia, which can cause galactorrhea, gynecomastia, and sexual dysfunction. Blockade of the D receptors in the nigrostriatal region is associated with the development of extrapyramidal symptoms. Agents with
 greater D receptor affinity (e.g., haloperidol or fluphenazine) have higher likelihood of inducing extrapyramidal symptoms, whereas agents with less
 receptor affinity (e.g., clozapine) are less likely to cause extrapyramidal symptoms. Blockade of the D receptors in the anterior hypothalamus (preoptic
 area) can produce alterations in body temperature.
In addition to blocking dopamine receptors, many antipsychotics have activities at the α­adrenergic, muscarinic, histaminergic, and serotoninergic receptors. Antagonism of the α ­adrenergic receptors leads to orthostatic hypotension and reflex tachycardia. Antagonism of the muscarinic receptors
 can produce hyperthermia, tachycardia, mydriasis, dry mucosal membranes, and urinary retention. Blockade of the histaminergic receptors primarily results in sedation. A consistent feature of the second­ and third­generation antipsychotics is their potent blockade of serotonin subtype 2A, which is greater than D receptor inhibition. This intense antagonism of serotonin subtype 2A actually increases dopaminergic transmission in the nigrostriatal

,4 pathway, reducing the risk of extrapyramidal symptoms, and enhances the ability to treat negative features of psychosis.
PHARMACOKINETICS
Most antipsychotics have similar pharmacokinetic profiles. After oral administration, absorption occurs rapidly, the drugs undergo significant firstpass metabolism, and peak plasma concentrations typically occur within  to  hours. Following intramuscular injection, peak plasma concentrations typically occur within  minutes for immediate­release products but can be delayed up to  day with depot preparations. Nearly all antipsychotics have high protein binding and a large volume of distribution. Metabolism is primarily through the cytochrome P450 enzyme system. Because of the near­complete hepatic metabolism of these drugs, renal impairment rarely requires dosage adjustments.
CLINICAL FEATURES
5­7
Isolated overdose of antipsychotics is rarely fatal, and most patients develop only mild to moderate symptoms. Toxicity is largely a function of the dose ingested, habituation, comorbid conditions, and age. Following overdose, CNS depression is frequent but is less severe in patients receiving long­term therapy, because tolerance to the sedative effects develops after days to weeks of regular use. CNS effects range from lethargy, ataxia,
,7 dysarthria, and confusion to coma with respiratory depression in cases of severe overdose. The ingestion of a single pill of some antipsychotics can cause significant CNS and respiratory depression in young children. Respiratory depression in adults is more common in multidrug overdoses.
Paradoxical agitation and delirium may occur in mixed overdoses, especially those involving agents with antimuscarinic properties. Seizures occur in approximately 1% of individuals after overdose, with the incidence higher for loxapine and clozapine. Gastric pharmacobezoars have been
 reported with quetiapine extended­release overdose.
Many of the antipsychotics have antimuscarinic properties, especially clozapine, olanzapine, quetiapine, and thioridazine. Thus, patients can manifest signs or symptoms that are consistent with antimuscarinic toxicity, including tachycardia, dry mucous membranes, dry skin, decreased bowel sounds, urinary retention, agitation, delirium, and hyperthermia. However, due to the concurrent α­adrenergic antagonism of many of these agents, miosis, rather than mydriasis, is frequently observed.
The most common cardiovascular manifestations of antipsychotic overdose are sinus tachycardia and orthostatic hypotension. ECG changes also include QT prolongation (highest rate with amisulpride and thioridazine), QRS widening (usually with large ingestions), and nonspecific T­wave
,10   abnormalities. Ventricular dysrhythmias are rare, with the exception of amisulpride overdoses.
DIAGNOSIS
Routine laboratory analysis should include basic chemistry tests and a pregnancy test for women of childbearing age. Test for co­ingestants, including acetaminophen and salicylate levels, in all intentional overdoses. Perform an ECG to assess the conduction intervals. Obtain complete blood counts for patients who develop a fever while taking clozapine or chlorpromazine.
TREATMENT
5­7
Treatment for patients with antipsychotic poisoning is largely supportive. For patients who are known to have ingested or are suspected of having ingested a significant amount, establish IV access and monitor cardiac rhythm. Ventilatory support should be provided to patients with respiratory depression. Patients with depressed consciousness should receive oxygen supplementation, continuous pulse oximetry, assessment of blood glucose, and consideration for administration of naloxone and thiamine. Seizures should be treated with a benzodiazepine such as lorazepam.
Treat hypotension with IV fluid resuscitation; adults without previously known or suspected cardiac disease should receive at least  to  L of crystalloid and children should receive  to  mL/kg. If hypotension persists, direct­acting α­adrenergic agonists, such as phenylephrine or norepinephrine, are the preferred vasopressors for treatment. Dopamine, an indirect­acting vasopressor, is not recommended as a first­line agent for treatment of hypotension following an antipsychotic overdose.
,14
Patients with a QT interval of >500 milliseconds are at increased risk for torsades de pointes. Assuming there are no contraindications to c magnesium supplementation and regardless of the serum magnesium level, adults with a QT interval of >500 milliseconds should receive c
 magnesium sulfate,  grams IV over  minutes. Patients with torsades de pointes should receive  grams of magnesium sulfate as a bolus, followed by an infusion of  to  milligrams/min, regardless of the magnesium concentration. Overdrive pacing can also be useful, especially in cases that prove
 refractory to magnesium.
Patients with an intraventricular conduction delay (e.g., prolonged QRS complex) and ventricular dysrhythmias should be treated with sodium bicarbonate,  to  mEq/kg IV bolus, followed by intermittent boluses or a continuous infusion. Lidocaine is an acceptable alternative or second­line agent for ventricular dysrhythmias. Avoid using class Ia (e.g., quinidine, procainamide), Ic (e.g., propafenone), III (e.g., amiodarone), and IV antiarrhythmics in patients with cardiac conduction disturbances or ventricular dysrhythmias who are concurrently taking an antipsychotic because these antiarrhythmics may potentiate such cardiotoxicity.
DISPOSITION AND FOLLOW­UP
Following ingestion, observe the patient for at least  hours. Obtain orthostatic pulse and blood pressures and observe successful ambulation prior to discharge. The patient can be judged to be free of toxicity if there are no mental status changes, pulse and blood pressure abnormalities, orthostatic
,17 hypotension, and QT interval prolongation after  hours of observation from the time of ingestion. Patients with evidence of toxicity (e.g., sinus c tachycardia or QT interval prolongation) should be admitted to a monitored bed for observation. Patients who develop severe symptoms (e.g., seizure, respiratory depression, hypotension, acidosis) during the observation period in the ED should be admitted to an intensive care unit.
ADVERSE EFFECTS OF THERAPEUTIC DOSING
CARDIOVASCULAR
Antipsychotics can affect myocardial conduction and repolarization. At therapeutic dosages, this is usually evidenced by prolongation of the QT
,18 interval. Of the typical agents, thioridazine, pimozide, and IV haloperidol cause the greatest degree of QT prolongation. Among the atypical
,18 antipsychotics, ziprasidone, sertindole, and amisulpride are associated with the greatest degree of QT prolongation in therapeutic dosing.
EXTRAPYRAMIDAL SYMPTOMS
Although high­potency typical agents cause the highest rate of extrapyramidal symptoms, all antipsychotic agents are capable of producing these
 symptoms. The four extrapyramidal syndromes include acute dystonia, akathisia, drug­induced parkinsonism, and tardive dyskinesia.
Acute dystonias manifest as hyperkinetic movements characterized by intermittent, uncoordinated, involuntary contractions of the muscles of the face, tongue, neck, trunk, or extremities. Although distressing to patients, these effects are not life threatening. Akathisias are a subjective sensation of motor restlessness. Occasionally, akathisia can be misinterpreted as increasing agitation related to an underlying psychiatric condition and can thereby prompt additional medication administration.
Acute dystonic reactions and akathisia are typically encountered early after starting therapy (or increasing the dose of a drug) and can be reversed with diphenhydramine (25 to  milligrams IV) or benztropine (1 to  milligrams IV). Diphenhydramine,  to  milligrams PO three or four times a day, or benztropine,  to  milligrams PO twice a day, should be continued for  to  days after parenteral treatment because of the prolonged effects of the dystonia­inducing agent.
Tardive dyskinesia and drug­induced parkinsonism typically develop after prolonged therapeutic use and are unlikely to be reversible.
OTHER ADVERSE EFFECTS
,19­21
Therapeutic use of atypical antipsychotics is linked with the development of type  diabetes mellitus and diabetic ketoacidosis. There is some
 suggestion that the risk is greatest with olanzapine. Phenothiazines are associated with leukopenia in up to .8% and agranulocytosis in .05% of
 patients. Several atypical antipsychotics have also been associated with agranulocytosis, with the highest incidence in patients taking clozapine, in whom leukopenia occurs in 3% and agranulocytosis in .8%. Due to these adverse effects, clozapine can only be prescribed within a strictly monitored
24­26 program. Seizures have been associated with several antipsychotics, primarily chlorpromazine, loxapine, and clozapine. The risk of seizure appears to be dose dependent. If they occur, seizures, should be treated with benzodiazepines (e.g., lorazepam,  to  milligrams IV bolus).
NEUROLEPTIC MALIGNANT SYNDROME
Neuroleptic malignant syndrome is a rare but potentially fatal idiosyncratic complication of antipsychotic drug therapy and not the result of an
27­29 overdose. Neuroleptic malignant syndrome most often occurs shortly after the start of therapy or after a dosage adjustment, and the antipsychotic serum concentration is usually within the therapeutic range. Neuroleptic malignant syndrome is associated with all the typical antipsychotics and most
,31 of the commonly available atypical antipsychotics, including aripiprazole, clozapine, olanzapine, risperidone, and ziprasidone. Neuroleptic
 malignant syndrome patients are more commonly adult males, with peak incidence in the 20­ to 25­year age range. The incidence is about  to 
 cases per ,000 patients treated.
CLINICAL FEATURES
Neuroleptic malignant syndrome typically develops over a period of  to  days and is characterized by the tetrad of altered mental status, muscular rigidity, fever, and sympathetic nervous system lability. The rigidity is typically described as lead pipe and cogwheel rigidity, similar to that observed with parkinsonism. The majority of patients present first with altered mental status, followed by rigidity, then fever, and lastly sympathetic nervous system lability. Fever can be delayed for more than  hours after the first symptom.
In addition to the tetrad, two other features embody important concepts about this syndrome: recent dopamine antagonist exposure or dopamine
,34 agonist withdrawal and negative evaluation for other causes (Table 180­2). Common laboratory abnormalities include elevated creatine kinase level, leukocytosis, elevated levels of hepatic transaminases, hypernatremia or hyponatremia, metabolic acidosis, myoglobinuria, elevated BUN and
 creatinine levels, and decreased serum iron level.
TABLE 180­2
Diagnostic Criteria for Neuroleptic Malignant Syndrome
Major features Fever >38°C (100.4°F), measured orally on at least two occasions
Lead­pipe muscle rigidity
Psychomotor slowing and altered mental status
Sympathetic nervous system lability (2 or more features)
Elevated blood pressure
Blood pressure fluctuation
Diaphoresis
Urinary incontinence
Recent dopamine antagonist exposure or dopamine agonist withdrawal
Minor features Increased creatine kinase level (>  × upper limit) or myoglobinuria
Tachycardia
Tachypnea
Hypersalivation (more prominent with clozapine or amisulpride)
Tremor
Muscle cramps
Exclusionary criteria No other infectious, toxic, metabolic, or neurologic cause identified
All antipsychotics have been associated with neuroleptic malignant syndrome, but the clinical features of reported cases associated with second­ and third­generation agents differ somewhat from the classic presentation induced by the first­generation drugs. Fever and sympathetic liability are less
 common in neuroleptic malignant syndrome induced by second­ and third­generation antipsychotics.
The differential diagnosis of neuroleptic malignant syndrome includes infectious, endocrine, toxicologic, and metabolic disorders. The most common disorder creating diagnostic confusion is serotonin syndrome (see Chapter 178, “Atypical and Serotonergic Antidepressants”). Clinical features more indicative of serotonin syndrome include a more rapid onset (2 to  hours), shivering, hyperreflexia, myoclonus, nausea, vomiting, diarrhea, and less intense muscle rigidity and fever.
TREATMENT
,28,37,38
Treatment is primarily supportive (Table 180­3). Withdraw any antipsychotics and potentiating drugs. Consider and evaluate for other medical conditions that can present in a similar manner, including CNS infection, other drug­induced hyperthermic syndromes, serotonin syndrome,
,38 anticholinergic poisoning, and sympathomimetic toxicity. Reduce the patient’s temperature with external cooling measures; pharmacologic antipyretics such as acetaminophen are not beneficial in lowering the temperature associated with this syndrome. Sedation is very important to
,37,38 decrease agitation and sympathetic activity; a benzodiazepine, such as lorazepam, is recommended.
TABLE 180­3
Treatment of Neuroleptic Malignant Syndrome
Withdraw any antipsychotics and potentiating drugs, such as anticholinergics, antihistamines, or lithium
IV hydration to restore circulating volume and maintain urine output
Reduce the patient’s temperature with external cooling measures
Sedation with a benzodiazepine, such as lorazepam, 1–2 milligrams IV every 2–4 h as needed
Airway protection: consider early intubation, especially if hypersalivation is present
Nondepolarizing neuromuscular blocking agents
Consider agents to reduce severe muscle rigidity
Dantrolene, .0–2.5 milligrams/kg IV load, followed by  milligram/kg IV every  h or
Bromocriptine, starting with .5 milligrams PO  to  times a day or
Amantadine, 100 milligrams PO  times a day
Airway and breathing difficulties should be anticipated, and patients with excessive secretions, dysphagia, decreased airway reflexes, acidosis, or hypoxia should be intubated. In addition, strongly consider intubating patients with fever and rigidity, because neuromuscular paralysis reduces the muscle contraction and thereby reduces the fever. When patients with neuroleptic malignant syndrome are intubated, nondepolarizing agents (e.g., rocuronium) are preferred over depolarizing agents (e.g., succinylcholine).
Complications from profound muscle rigidity are responsible for most deaths in neuroleptic malignant syndrome. Prompt reduction in muscle rigidity can be expected to minimize the occurrence of complications such as rhabdomyolysis, renal failure, respiratory failure, disseminated intravascular coagulation, and cardiovascular collapse. The role of specific pharmacotherapy is unclear; no treatment has been shown to be superior to
,37,38 supportive care alone.

Pharmacologic therapies described in case reports and series include dantrolene, bromocriptine, benzodiazepines, and amantadine. Dantrolene is a direct­acting skeletal muscle relaxant that is primarily used for more severe cases of neuroleptic malignant syndrome in which the rigidity is
 pronounced. Dantrolene should not be used concurrently with calcium, because this increases the risk of cardiovascular collapse. Bromocriptine is
 a centrally acting dopamine agonist that can reduce fever and muscle rigidity in neuroleptic malignant syndrome and possibly shorten the duration.
This drug is only available in an oral preparation and may require administration by a nasogastric tube. Adverse side effects of hypotension, vomiting,
 and worsening of psychosis are limiting factors to the routine use of bromocriptine. Amantadine is similar to bromocriptine in activity and only available in enteral form but is less likely to cause hypotension.
Patients with neuroleptic malignant syndrome should be admitted to the intensive care unit for monitoring and treatment. Most patients recover in  to  days.


