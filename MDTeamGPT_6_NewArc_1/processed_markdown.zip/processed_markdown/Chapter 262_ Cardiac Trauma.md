## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 262: Cardiac Trauma
Brit Long; Alex Koyfman
BLUNT AND PENETRATING CARDIAC TRAUMA AND GREAT VESSEL INJURY
INTRODUCTION
Detection of cardiac injuries is critical for patient survival in trauma. Penetrating cardiothoracic injury causes one quarter to one third of deaths immediately following trauma, and the majority of these fatalities involve either cardiac or great vessel injury.1,2 Penetrating cardiac injury results when a foreign object enters the body, piercing the pericardium or heart, and cardiac injury may account for close to 10% of deaths from gunshot wounds.2,3 Invasive cardiac procedures or therapies may cause iatrogenic trauma to the pericardium and myocardium.
Even noncardiac procedures like central lines placed into the internal jugular vein can lead to penetration of the pericardium, heart, and great vessels.4 The incidence of blunt cardiac injury has been reported to range anywhere from 8% to 71%.5,6 Blunt cardiac injury results from physical forces acting externally on the body, and up to 20% of all motor vehicle collision deaths are due to blunt cardiac injury.2,3
Suspect the diagnosis of cardiac or great vessel injury in a patient with chest, lower neck, epigastric, or precordial injury. Closely observe for evidence of hemodynamic instability, loss of circulating blood volume, electrocardiographic changes, cardiac tamponade, and hemothorax.2,6
EPIDEMIOLOGY
Most penetrating injuries occur from guns and knives, with a shift toward gunshot wounds becoming more common than knife wounds.2,7­9 The injury usually involves only the free cardiac wall, but other structures can be injured, such as cardiac valves, chordae tendineae, papillary muscles, atrial or ventricular septum, coronary arteries, and conduction system (Table 262­
1).2,10 Rates of involvement of cardiac structures due to penetrating injuries to the right ventricle, left ventricle, right atrium, and left atrium are approximately 40%, 35%, 20%, and 5%, respectively.11,12 Mortality approximates 40% for penetrating cardiac injury.7
TABLE 262­1
Injuries From Penetrating Wounds of the Heart
Pericardial damage
Laceration or perforation
Hemopericardium with or without cardiac tamponade
Serofibrinous or suppurative pericarditis
Pneumopericardium
Constrictive pericarditis
Myocardial damage
Laceration
Penetration or perforation
Retained foreign body
Structural defects
Aneurysm formation
Septal defects
Aorticocardiac fistula
Valvular injury
Leaflet or cusp injury
Papillary muscle or chordae tendineae laceration
Coronary artery injury
Laceration or thrombosis with or without myocardial infarction
Arteriovenous fistula
Aneurysm
Embolism
Foreign body
Thrombus (septic or sterile)
Infective endocarditis
Rhythm or conduction disturbance

Chapter 262: Cardiac Trauma, Brit Long; Alex Koyfman 
T
© yp
 e
 s
 o
 f b
M lun c t
G ca ra rd w ia c
H in il j l u
.
r
A y c ll a
R n b ig e h su ts st a
R in e e s d e fr r o v m ed a
.
n y o
T f e th rm e m s e o ch f a
U n s is e m s
 * l
P ist r e iv d a in c
T y a
P bl o e l i
 c
 y

 * 
­2
N .13o
R t a ic p e id
 * d e
A c c el c e e ra s ti s o i n b i i s l i t t h y e most common mechanism responsible for most blunt cardiac injury followed by a direct blow to the precordium. Blunt cardiac injury results in a range of conditions from clinically silent transient dysrhythmias to cardiac wall rupture.6
TABLE 262­2
Mechanisms for Blunt Cardiac Injury
Direct precordial impact
Crush injury from compression between the sternum and spine
Abrupt pressure fluctuations in the chest and abdomen
Shearing from rapid deceleration or torsion causing a tear in the heart at a point of fixation (right atrium and vena cava)
Injury from rib fracture fragments
Hydraulic effect resulting in cardiac rupture
Blast injury
The most common reported blunt injury is “myocardial or cardiac contusion.” These terms describing blunt cardiac injury are nonspecific and have been used to report a wide range of injuries. Further, there is not a clear definition or a gold standard for testing, which makes the diagnosis and treatment difficult. The term blunt cardiac injury has replaced the terms cardiac contusion and myocardial contusion. Blunt cardiac injury can encompass cardiac dysfunction (diminished contractility in the absence of dysrhythmia or hemorrhage), dysrhythmias, specific injuries (septal rupture, valvular injuries, myocardial infarction), and cardiac rupture, the most devastating blunt cardiac injury.5,6,14,15
Most patients who present with thoracic great vessel injury have sustained penetrating trauma and have a dire prognosis; most die before they reach medical care.16­18 Aortic injuries from blunt trauma are usually due to motor vehicle crashes. Over 90% of patients who sustain this injury die at the scene; of the remaining 10% who survive, 50% die within  hours and 90% die within  months.17 The mortality for untreated patients is 1% per hour for the initial  hours.18
ANATOMY AND PATHOPHYSIOLOGY
Cardiac and great vessel anatomy relates to the specific injury patterns found in penetrating and blunt injury. The anatomic “cardiac box” (Figure 262­1) is the area of the chest bound by the sternal notch superiorly, the xiphoid process inferiorly, and the nipples laterally. A high likelihood for cardiac injury is present for injuries in the corresponding lateral and posterior areas of the thorax. This results in a three­dimensional cardiac box that should be considered in penetrating injury.2,19 Most stab wounds injuring the heart enter through this area. Gunshot wounds, however, may enter at regions well outside this area, so any penetrating injuries involving the thoracoabdominal region, back region, or any potential of transmediastinal trajectory place the heart at risk for injury. Pericardial injury can result in acute tamponade. The right ventricle is at greatest risk due to its large anterior exposure on the chest wall. The right and left atria are less frequently involved due to their smaller surface area. Blunt cardiac injury most often involves the right heart due to the anterior location of the right atrium and ventricle within the mediastinum. Injury often involves more than one chamber in over half of the reported cases.2,20
FIGURE 262­1. The cardiac box: chest area with potential for cardiac injury.
The thoracic great vessels consist of the aorta and its brachiocephalic trunk and its branches; the left subclavian, left common carotid, and pulmonary arteries and veins; the superior and intrathoracic venae cavae; and the innominate and azygos veins. Injuries to these vessels occur in both penetrating and blunt trauma. The large blood volume flowing through these vessels leads to exsanguinating hemorrhage as the primary acute manifestation of trauma. Even if not immediately ruptured, injury to these vessels can produce aneurysm and pseudoaneurysm through fistula formation, which in turn can lead to massive hemorrhage.2,21
PATHOPHYSIOLOGY
The pathophysiology is determined by the type and location of injury. With regard to penetrating trauma, knives tend to involve a single cardiac chamber, producing a single slit­like defect that is often more amenable to medical and surgical therapy than gunshot wounds, with survival for right ventricle injuries at nearly 60%.22 Gunshot wounds, however, can cause a spectrum of injury from multiple­chamber perforation to gaping defects depending on the caliber and velocity of the missile. Patients with stab wounds to the heart are  times more likely to survive than those with gunshot wounds.23 Atrial injuries are less common and generally less severe, whereas multichamber injuries are associated with higher mortality.7,23­25
The pathologic changes seen in blunt cardiac injury typically include subendocardial hemorrhage and a much larger area of focal myocardial edema, interstitial hemorrhage, and myocytolysis with infiltrates of polymorphonuclear leukocytes. Additional myocardial injury may occur if there are concomitant intimal tears or compression from adjacent hemorrhage or edema. Myocardial injury may also be due to redistribution of coronary blood flow. Minor myocardial marker elevation or ECG abnormalities and dyskinesia or dysrhythmias typically resolve over time, usually within the first  hours.6,13 Blunt cardiac injury can lead to death from complex dysrhythmias, acute heart failure, cardiac­free wall rupture, or laceration of a coronary artery that causes extracardiac hemorrhage. Most of these lethal mechanisms result in death at the scene of the injury.26­28 Less severe injuries to the ventricular wall may lead to delayed necrosis and clinically manifest as delayed rupture days after admission. If a low­pressure chamber or coronary vein is injured, patients may survive until presentation to the hospital.2,29
Blunt cardiac injury can also result in rupture of an atrial or ventricular septum, resulting in shunting of blood and presentation similar to heart failure.30 Similarly, blunt cardiac injury can result in regurgitation of blood from a high­pressure chamber or artery into a lower­pressure chamber, such as with an acute valve dysfunction or papillary muscle injury.30,31 Valvular injury tends to worsen over time. The degeneration of the valve’s function appears to depend on its location. High­pressure valves like the aorta and mitral valves tend to manifest symptoms immediately or within the first few weeks, whereas injury to lower­pressure valves like the pulmonic and tricuspid can be asymptomatic for years.6,13 Coronary arteries can have occlusion, dissection, or spasm that can manifest as immediate or delayed injury patterns. Coronary artery injury presents most often in a myocardial infarction pattern.33
CLINICAL APPROACH
Nonspecific signs and concomitant injuries will affect clinical presentation. Such other clinical findings in the trauma patient may make it difficult to determine whether symptoms stem from cardiac or other injuries. Specific signs of cardiac injury (e.g., distended neck veins or specific murmurs) may not be present if the patient is hypotensive from other injuries. Symptoms of cardiac injury may occur in a delayed fashion coincident with fluid resuscitation.2,6
HISTORY
For penetrating injury, mechanism, initial hospital signs, injuries, and treatments are valuable if obtainable from prehospital providers. In unstable patients with penetrating trauma, history may not be obtainable from the patient. The most common symptom of blunt cardiac trauma is chest pain. All different qualities of chest pain occur, ranging from pleuritic to pressure­like.
Even the classic crushing retrosternal pain of myocardial ischemia can occur if coronary arteries are involved. Patients with injuries on the chest wall such as rib fractures, sternal fractures, or clavicular fractures may have underlying cardiac injury. Be cautious about attributing symptoms only to those of the superficial chest wall, because pericardial and myocardial structures may be damaged as well. Patients may have shortness of breath due to overlying chest and pulmonary injury or due to myocardial dysfunction from cardiac tamponade or heart failure. Other nonspecific symptoms such as lightheadedness and palpitations are also common.13,15 Clinical findings vary widely depending on the structures injured, the extent of the injuries, concomitant injuries, and the patient’s body habitus and mental status.
PHYSICAL EXAMINATION
Close observation of heart rate and blood pressure and their associated trends is important. In patients with chest trauma, initial vital signs are not reliable, as patients can decompensate quickly. Often, the presence of unexplained tachycardia may be the only finding of cardiac injury. Listening to breath sounds and heart sounds may assist in diagnosing cardiac injury.
Identification of all injuries and retained foreign bodies is imperative, with complete visualization of the torso, including back and axilla. Clear lungs with muffled heart sounds may be indicative of cardiac tamponade, but this finding is quite rare and difficult to detect in a noisy ED. Coarse crackles in the lungs, extra heart sounds, and elevated jugular venous pressure may be present if myocardial dysfunction leads to heart failure. Physical examination may also reveal a “seat belt sign,” chest wall deformity, or subcutaneous emphysema, although the absence of these findings does not exclude injury.2,6,34 Repeat examination and vigilance are needed, as these patients may rapidly decompensate.
PENETRATING CARDIAC TRAUMA
PENETRATING CARDIAC TRAUMA
The two conditions that can occur after penetrating cardiac injury are exsanguinating hemorrhage and cardiac tamponade. Pericardial defects that are large or remain open may present with hemothorax and clinical signs of blood loss that may progress to rapid exsanguination and death. If the pericardial wound seals itself, which is common with the linear defect in a stab wound, the result is intrapericardial hemorrhage that may progress to cardiac tamponade.2 The location of the wound will also determine the rate of accumulation. Right ventricular wounds tend to seal themselves more readily than right atrial wounds due to the thicker, more muscular walls of the ventricle. Atrial injuries may have subtle or no clinical findings initially; however, rapid clinical deterioration can occur. Injury to the coronary arteries is manifested by tamponade or myocardial ischemia.2,6
CARDIAC TAMPONADE
Cardiac tamponade, characterized by the accumulation of pericardial fluid under pressure, can be found in up to 2% of penetrating trauma to the thoracoabdominal region and very rarely in blunt trauma. Up to 80% of myocardial stab wounds may develop cardiac tamponade. Gunshot wounds leave defects in the pericardium that are larger and more irregular than stab wounds.
Gunshot wounds are therefore less likely to develop tamponade because it is more difficult for the pericardium to seal the defect.35,36
Blood in the pericardial cavity may be defibrinated by the lytic activity normally present in the pericardium, resulting in a hematoma that may inhibit normal myocardial function.
Intrapericardial blood accumulation eventually causes elevated intrapericardial pressure, which leads to decreasing right and left ventricular filling. Catecholamines are released in this state as a compensatory mechanism that results in tachycardia and further elevated right­sided filling pressures. Once the distensibility limits from intrapericardial fluid are reached by the pericardium, the myocardial septum shifts toward the left side, which further reduces left ventricular filling and subsequent cardiac output. This downward spiral eventually produces irreversible shock and death. Even small amounts of blood (65 to 100 mL) can lead to an acute rise in intrapericardial pressure. Hypovolemic shock from other injuries may partially or completely compensate for the elevated right­sided pressures, resulting in normal or even low central venous pressures.2,6
Cardiac tamponade is identified by the FAST exam. Without point­of­care US, cardiac tamponade can be deceptively difficult to diagnose as the body compensates for the hemodynamic effects by various mechanisms. The reduced cardiac output is offset by the increase in heart rate and increase in systemic vascular resistance. Often, the only clinical finding of pericardial tamponade is sinus tachycardia. Hypotension may be a sign of ominous decompensation and emergent need for surgical intervention if due to pericardial tamponade or systemic hypovolemia from other injuries. The classic finding of Beck’s triad of muffled heart sounds, hypotension, and distended neck veins is present in less than 10% of cases.2,3,6 Pulsus paradoxus, a substantial fall in systolic blood pressure during inspiration, and Kussmaul’s sign, an increase in jugular venous distention on inspiration, are not reliable signs and may only be found with moderate to severe tamponade.36 A more reproducible sign of cardiac tamponade is a narrowing of the pulse pressure, which along with elevation of the central venous pressure, is cardiac tamponade until proven otherwise. The narrowed pulse pressure is not sensitive, and its absence should never be used to exclude tamponade. Usually the jugular venous pressure is elevated and may be associated with venous distention of the neck veins, forehead, and even scalp. (See Video: FAST.)
Video 262­2: FAST
Used with permission from Sandra Werner, MetroHealth Medical Center, Department of Emergency Medicine, Cleveland, OH.
Play Video
INTRACARDIAC MISSILES
The heart may have a retained missile from a direct injury or as a result of venous migration from another injury. These missiles, or the thrombus that may form as a result, may embolize into systemic or pulmonary arteries.1 Many patients with a retained cardiac missile are hemodynamically stable. The patients may do well with prolonged observation and no operative intervention.37 The treatment for missiles is highly variable, depending on missile size, shape, and location. Missiles that cause any hemodynamic instability or symptoms should be removed.
A left ventricular missile that is free or partially exposed should be removed to prevent systemic embolization.37 Right­sided missiles may be removed or left alone because embolization to the pulmonary vascular bed usually has minimal consequences.38 Most intramyocardial and intrapericardial bullets and pellets are generally well tolerated and left in place. Embolized missiles need immediate removal because of the downstream ischemic effects of arterial occlusion. If a missile is embedded or adjacent to a coronary artery, it should be removed because of the potential for erosion and bleeding, which may lead to myocardial infarction and pericardial tamponade. Long­term effects of a retained missile may include bacterial endocarditis, thrombosis, embolization, and cardiac neurosis (many patients feel that they need any missile removed at all cost).37
IATROGENIC CARDIAC INJURY
Diagnostic and therapeutic percutaneous procedures may lead to many cardiovascular complications. Vascular (including extra­ and intracardiac), valvular, and myocardial injuries are wellrecognized complications of procedures such as central line placement, thoracentesis, chest tube placement, pericardiocentesis, percutaneous coronary catheterization, valvuloplasty, and electrophysiologic lab procedures.39
TREATMENT OF PENETRATING CARDIAC TRAUMA
The utility of pericardiocentesis for cardiac tamponade identified on FAST exam in cardiac trauma is controversial, though it may act as a temporizing measure. Perform ED thoracotomy in unstable patients with cardiac tamponade who may not survive transfer to an operating room.
PERICARDIOCENTESIS
Pericardiocentesis is a prelude to formal thoracotomy if there are inevitable delays to definitive surgery (i.e., transport to trauma center). Use of US guidance of the needle increases accuracy and is a class I American College of Cardiology/American Heart Association recommendation for critically injured patients. Detailed discussion is provided in Chapter , “Pericardiocentesis.”
(See Video: Pericardiocentesis.)
Video 262­1: Pericardiocentesis
Used with permission from Henderson McGinnis, Wake Forest University Baptist Hospital
Play Video
ED RESUSCITATIVE THORACOTOMY
Patients in extremis but with electrical cardiac activity should be rapidly transported to the ED. Resuscitative ED thoracotomy can be lifesaving in carefully selected patients. The decision to perform an ED thoracotomy or alternately determine that resuscitation is futile must be made in short order under highly stressful circumstances.
Candidates for ED thoracotomy include penetrating chest trauma patients who are hemodynamically unstable and those who demonstrated signs of life (palpable pulse, a blood pressure, pupil reactivity, any purposeful movement, organized cardiac rhythm, or any respiratory effort) either in the field or ED but subsequently lost these signs of life. Resuscitative ED thoracotomy is likely to be futile in patients under the following clinical scenarios: (1) no pulse or blood pressure in the field; (2) asystole is the presenting rhythm and there is no pericardial tamponade; (3) prolonged pulselessness (>15 minutes) at any time; (4) other massive, nonsurvivable injuries; or (5) blunt traumatic cardiac arrest.40,41
Exposure to the heart is accomplished by a left anterolateral thoracotomy. No matter where the penetrating injury occurs, use the left­sided approach initially. This approach allows for quick access to the pericardium and heart and exposure for aortic cross­clamping if necessary. Identify the left fourth or fifth intercostal space, which corresponds to an intercostal space below the male nipple or at the inframammary fold in a woman. Make the incision in a single stroke through all layers down through the intercostal musculature from sternum to posterior axillary line.
Use Mayo scissors to cut the remaining intercostal muscles. Insert a Finochietto retractor with the crank positioned near the bed. Open the retractor to allow exposure of the left thorax.
Remove blood and inspect for brisk bleeding. Control intrathoracic hemorrhage with direct pressure, the application of appropriate pulmonary or vascular clamps, and direct suture ligation.
Gently push the lung out of the field to expose the pericardium. To minimize the left lung obscuring the field, a right mainstem bronchus intubation may be performed.
A distended, discolored, and often tense pericardial sac confirms cardiac injury. Perform a pericardiotomy by making a long incision from the apex of the heart to the root of the aorta just anterior to the phrenic nerve. Remove any blood and clot from the pericardial sac. Patients who do not have blood in the pericardium and do not exhibit cardiac activity may be declared dead at this point. If there is evidence of blood in the pericardium or cardiac activity, then expose the heart for inspection. After extruding the heart through the incision in the pericardium, identify the cardiac wound. One of several techniques may be used to control hemorrhage (Figure 262­2). Simple digital occlusion on top of the wound is the first maneuver to attempt initial hemostasis. Never insert a finger into the wound because this may extend the defect. The defect can then be stapled with regular skin staplers, which is a quick and easy method of temporary cardiac repair. Suturing of wounds is often technically difficult due to the dynamic nature of the myocardium, the slippery edges, the ease with which the sutures pull through the myocardium, inadequate lighting, and bloody field. Putting a Foley catheter into the defect and blowing up the balloon can fill a large circular defect. Gentle traction on the catheter will allow the balloon to seal the defect. A purse string suture can then be placed around the Foley catheter so that when the catheter is removed, tightening of the suture will seal the defect. Myocardial defects can be sutured with horizontal mattress sutures, but use pledgets to reinforce the repair and prevent cutting through the heart tissue.
FIGURE 262­2. Temporary techniques to control bleeding of myocardial laceration. Emergency center management of injury to the epicardium. A. Stab wound to the left ventricle. B. Initially managed with either a continuous 4­0 polypropylene suture or interrupted sutures tied beneath the surgeon’s finger. C. Injuries that are more complex and cannot be managed in the ED can be temporized using a Foley catheter for ventricular injuries and either a Foley catheter and/or partial occluding clamp for atrial injuries. D. Because of concerns about surgeon needle stick during cardiorrhaphy on the beating heart, hemostasis can initially be achieved with the skin stapler. Care must be observed in avoiding ligation of coronary arteries.
Cross­clamp the aorta and then perform internal cardiac massage in the absence of coordinated cardiac function. Whatever type of repair is attempted, be careful and do not ligate major coronary vessels. If there is no evidence of injury to the left side or there is a high index of suspicion of right­sided injury, the ED thoracotomy incision can be extended to the right side. This is done by extending the incision across the sternum (“clam shelling”) in the same manner as the primary left­sided incision to gain access to the right side of the chest and allow for better exposure of the right ventricle and atrium. Patients with suspected intra­abdominal hemorrhage should have the descending aorta cross­clamped.
After resuscitative ED thoracotomy, if vital signs are regained, transfer the patient to the operating room for definitive repair. The survival rate for patients who make it to the operating room is 70% to 80% for stab wounds and 30% to 40% for gunshot wounds.40,41
A second approach for ED thoracotomy, which is perhaps faster with greater exposure, is to perform bilateral finger thoracostomies and then connect these incisions anteriorly, completing a clamshell.42­44
ADJUNCTIVE MEASURES: TRANEXAMIC ACID
Antibrinolytic agents have demonstrated utility in preventing death due to hemorrhage in severe trauma. The Clinical Randomization of an Antifibrinolytic in Significant Hemorrhage­2 and
Military Application of Tranexamic Acid (TXA) in Trauma Emergency Resuscitation trials are landmark studies demonstrating improved outcomes with TXA when given within  hours of traumatic injury.45­47 Administer TXA  gram IV to patients with penetrating cardiac or great vessel injury if within  hours of injury. There is no study directly evaluating TXA in cardiac trauma or great vessel injury patients; however, a 2012 meta­analysis of patients undergoing surgery, the majority cardiac, found reduced death and need for transfusion in patients receiving TXA.47
TXA can provide a potential benefit in these severely injured patients with little risk for adverse event from the medication.
BLUNT CARDIAC TRAUMA
COMMOTIO CORDIS
Commotio cordis, meaning “disturbance of the heart” in Latin, is sudden death as a result of blunt trauma to the chest wall. It often results from an innocent­appearing chest wall blow. It is the second most common cause of death in youth athletics following hypertrophic obstructive cardiomyopathy. Usually victims are young athletes who are struck in the chest by hard projectiles that are used in the particular sport. Sports using small dense projectiles like baseball, hockey, and lacrosse have the highest incidence of commotio cordis. The hardness of the impact object, location of impact, and velocity of the object affect the risk of development of ventricular fibrillation. Commotio cordis blows are generally low impact, most of which are insufficient to cause any significant structural damage to the ribs, sternum, or heart. Commotio cordis is a primary electrical event resulting in the induction of ventricular fibrillation; it is a result of a blow that occurs  to  milliseconds before the peak of the T wave, a time of vulnerability to ventricular fibrillation.6,48 Autopsy findings typically show normal cardiac anatomy with no evidence of injury. The overall survival rate is less than 15%, but due to increasing prevalence of automated external defibrillators being placed in sporting venues, survival rates may improve.48
CARDIAC DYSFUNCTION
The exact incidence of cardiac dysfunction (decreased contractility) in blunt cardiac injury is unknown. Further, the cause of dysfunction may be difficult to determine in the hypotensive, multiply injured trauma patient. Patients almost universally present with chest pain. The pain usually results from associated thoracic trauma (Table 262­3). Associated blunt injury to the lung can lead to a rise in pulmonary vascular resistance, which can result in a reduction in preload of the left ventricle. This, coupled with the reduced cardiac output of the involved right ventricle, can lead to hypotension.15,49 The damaged myocardial tissue may be a focus for both atrial and ventricular dysrhythmias, which may further produce decreased contractility and hemodynamic deterioration.
TABLE 262­3
Associated Injuries With Blunt Cardiac Trauma3
Associated Injuries Incidence of Finding in Patients With Blunt Cardiac Injury
Thoracic injury
Chest pain 18%–92%
Rib fracture 18%–69%
Aortic or great vessel injury 20%–40%
Hemothorax 7%–64%
Pulmonary contusion 6%–58%
Pneumothorax 7%–40%
Flail chest 4%–38%
Sternal fracture 0%–60%
Head injury 20%–73%
Extremity injury 20%–66%
Abdominal solid organ injury 5%–43%
Spinal injury 10%–20%
Source: With permission from Schultz JM, Trunkey DD. Blunt cardiac injury. Crit Care Clin. 2004;20(1):57­70. Copyright Elsevier.
Monitor for dysrhythmias. Persistent tachycardia, new bundle branch block, supraventricular tachycardia, atrial and ventricular fibrillation, and minor dysrhythmias (occasional premature ventricular contraction) can occur after blunt injury.
INJURY TO THE PERICARDIUM
Direct impact or increased intra­abdominal pressure can cause pericardial tears. The tears usually occur on the left side of the pericardium parallel to the phrenic nerve. Herniation can occur through the defect leading to cardiac dysfunction and dysrhythmias. Tears in the pericardium often are missed and may have little clinical impact. Physical examination (pericardial rub), point­of­care US, or CT findings (pneumopericardium, displacement of the heart, abnormal bowel gas in chest or around heart, or evidence of intra­abdominal contents inside pericardium) may lead to the diagnosis. Pericardial laceration may cause herniation and strangulation of the myocardium if not diagnosed and corrected surgically.2,49 Patients with detectable pericardial rents are usually taken to the operating room for repair unless the tear is too large so that closure would lead to tension on the pericardium and potentially produce myocardial dysfunction.2
INJURY TO CARDIAC VALVES, PAPILLARY MUSCLES, CHORDAE TENDINEAE, AND SEPTUM
Injury to cardiac valves occurs in approximately 10% of blunt cardiac injury.6 Isolated valvular injuries appear to be rare. The aortic valve is most often involved, followed by the mitral and tricuspid valves. Injury to the aortic valve can cause severe regurgitation with development of pulmonary edema. Presentation may vary from new murmur to acute valvular insufficiency with right­ or left­sided cardiac failure. A widened pulse pressure can be seen with acute aortic valvular injuries. Septal injuries are also rare with variable presentations, ranging from insignificant tears to frank rupture. They may occur in isolation or with valvular injury. The muscular portion of the septum can rupture several days after blunt trauma. Suspect patients with new­onset murmurs of having valvular, septal, or papillary muscle pathology. Any patients with clinical or echocardiographic evidence of injury require emergent surgical consultation. Treatment for septal and valvular injury is generally surgical, and timing depends on the presenting signs and acuity. Acute heart failure resulting from elevated pulmonary pressure due to structural injury warrants rapid surgical intervention, whereas small septal injuries with minimal clinical effects can be treated conservatively because many eventually close spontaneously.2,6,15,50
INJURY TO CORONARY VESSELS/MYOCARDIAL INFARCTION
Although blunt cardiac injury rarely leads to injury of the coronary vessels, arteriovenous fistula, coronary artery dissection, and coronary thromboses have been reported.51,52 The most common artery involved is the left anterior descending artery. Coronary artery injury presents in the same fashion as atherosclerotic heart disease, has similar treatment by percutaneous coronary intervention with stenting, and has a more favorable prognosis. Because of the possibility of other injuries, extreme caution must be taken in using anticoagulation therapy due to bleeding complications.51,52 Fibrinolytic therapy is contraindicated.
CARDIAC RUPTURE
The most severe form of blunt cardiac injury is cardiac rupture. Most patients with cardiac rupture die at the scene of the trauma. The right­sided portion of the heart is much more prone to rupture due to its more anterior location, as are the thin­walled atria compared with the thicker­walled, stronger ventricles. In patients who survive to ED arrival, the physical examination may reveal a “splashing mill wheel” sounding murmur (“bruit de Moulin”), but this finding is rare. ECG may show conduction defects or, if herniation has occurred, axis deviation. A skilled sonographer can rapidly reveal the diagnosis, and immediate thoracotomy is required for survival.2,6,28
PERICARDIAL INFLAMMATION SYNDROME
The cause of pericardial inflammation may be a delayed hypersensitivity reaction to the presence of damaged myocardium in the pericardial cavity. Consider this syndrome in individuals who develop chest pain, fever, and pleural or pericardial effusions  to  weeks after cardiac trauma (or surgery). Patients may also have friction rubs, arthralgia, and pulmonary infiltrates. The
ECG will often show ST­T wave changes consistent with pericarditis. Treatment is primarily symptomatic. NSAIDs and rest can often reduce symptoms dramatically within  to  hours, and glucocorticoids are occasionally required. Rarely, drainage of pleural or pericardial fluid may be required to relieve symptoms or to exclude other problems.
TREATMENT OF BLUNT CARDIAC INJURY
Treat hypotension with boluses of crystalloid or blood products to optimize intravascular blood volume, which will also optimize preload. Trauma patients often have multiple injuries, especially in blunt injury, so the most common reason for hypotension is due to hypovolemia requiring blood products, not myocardial dysfunction.
The management of blunt cardiac injury (myocardial or cardiac contusion) is otherwise not standardized. Surgical intervention is rarely required, although pericardial fluid discovered on
FAST may require operative intervention for subxiphoid pericardial window.2 The only universally accepted practice pattern is to observe patients with hemodynamic and continuous cardiac monitoring.15 It is generally agreed that low­risk patients (minor injuries, no dysrhythmias, and normal ECG) usually will not develop complications so that further workup is not warranted. A patient with normal troponin and ECG is at low risk for blunt cardiac injury. Evaluate moderate­ to high­risk patients (evidence of associated injuries, dysrhythmias, elevated cardiac biomarkers, abnormal ECG) with echocardiogram. Admit patients for cardiac monitoring with minor ECG abnormalities (premature ventricular or atrial contractions), no significant concomitant injuries, and normal hemodynamics.53,54 Telemetry monitoring criteria do not exist, but monitoring for  hours is reasonable for minor abnormalities.2,6,13,14
Subsequent management depends on complications. After ruling out hypovolemia as the source of hypotension, vasopressor and inotropic support may be required to maintain cardiac output and blood pressure. Dysrhythmias that result in hemodynamic instability or are ventricular in origin are treated according to advanced cardiac life support algorithms. Dysrhythmias and myocardial dysfunction from blunt injury typically resolve in  hours.49 Patients in cardiogenic shock require evaluation for structural injury. Patients with cardiac rupture, valvular injury, papillary muscle or chordae tendineae rupture, or coronary thromboses or dissection require emergent surgery or percutaneous coronary intervention depending on specific injury.
Stabilizing therapies can be performed based on the specific injury.2 Mitral valve injuries with regurgitation may need afterload reduction, as well as inotropic therapy. Aortic valvular injuries typically require emergent surgery.2
GREAT VESSEL INJURY
BLUNT INJURY
Blunt trauma injury to the great vessels involves high­speed deceleration. Usually the chest strikes the steering wheel, which subsequently transmits the force across the mediastinum. There may also be vascular compression of the vessels between the sternum and vertebral bodies and subsequent marked increases in intraluminal pressure.18 Consider blunt aortic injury when the mechanism involves sudden deceleration such as a fall over  ft (3 m) or a motor vehicle crash at speeds greater than  mph (50 km/h).2,6
The proximal descending aorta is most commonly injured in blunt trauma because of the fixation of the vessels between the left subclavian artery and the ligamentum arteriosum.2,6 The aorta is mobile and continues to move forward as the tethered portions decelerate with the remainder of the chest, leading to shearing forces that produce aortic injury. The diagnosis of ascending aortic injury is rarely made since very few patients survive long enough to diagnosis and repair. Ascending aortic injuries are frequently associated with cardiac rupture or severe myocardial contusion, and the aortic tears are often multiple. Usually large amounts of energy are required to injure the ascending aorta. The distal descending aorta is also a less frequently injured structure. Patients may present with paraplegia, mesenteric ischemia, anuria, or lower extremity ischemia. The more distal the injury, the better is the anticipated outcome, provided the patient does not exsanguinate prior to repair.
Although the subclavian artery is occasionally avulsed at its origin because of sudden deceleration, direct trauma to the distal artery with intimal damage and occlusion associated with fractures of the first rib or clavicle is more likely. Shoulder restraints that are loose may be a major factor in causing this injury. Injuries to the innominate artery are second in frequency only to rupture of the aorta at the isthmus. This injury is difficult to diagnose because less than half of patients have any physical findings at all and those who do have some diminution of the right radial or brachial pulse, a systolic murmur, or distal ischemia (rarely).
The pulmonic veins and the venae cavae attach to the atria and can serve as a nidus for injury with shearing forces. Venous thoracic great vessel injury is extremely rare, and most are fatal.
Suspicion of inferior vena caval injury should occur with major hepatic injury, and both the superior and inferior venae cavae should be considered a source if there is cardiac tamponade or arterial bleeding that cannot be identified.
The aorta is primarily involved in about 85% of cases, but branch vessels are involved in 15% of documented vascular injuries.21 The branch injuries are potentially fatal so their identification is of the utmost importance as well. Concurrent vascular injuries should be identified because the definitive surgical approach may change depending on where the injuries occur.55
PENETRATING INJURY
The pathophysiology of penetrating trauma to the great vessels is straightforward: either there is direct vessel injury or the kinetic energy damages the vessels by propagation through the tissues. Patients with penetrating injuries rarely survive to reach the hospital. Iatrogenic injuries from central line placement and other invasive thoracic procedures can lead to great vessel injury.
Bullets entering large systemic veins or the right heart can embolize to the lungs, whereas bullets entering the pulmonary veins or left heart can embolize to major systemic arteries. Some of these embolized foreign bodies do not cause symptoms or signs and can be located only after taking multiple radiographs. Suspect embolization if the missile appears distant from the anticipated trajectory. The other explanation for missiles off trajectory is gravity: low­velocity bullets that violate the pleural space but are not trapped in lung parenchyma often fall to the lowest place in the hemithorax, namely the posterior costophrenic recess.
CLINICAL FEATURES
Blunt trauma involving motor vehicle crashes can injure the aorta with side­impact collisions just as often as head­on collisions. Any blunt trauma from significant force (falls from a significant height, blast injuries, high­speed motor vehicle crash, crush injuries, pedestrian versus automobile injuries) can lead to blunt aortic injury.
Half the patients with blunt thoracic vascular injury present without external physical signs of injury. Although the physical examination findings of great vessel injury can be minimal to nonexistent, several important clues should be investigated. Hypotension, hypertension in the upper extremity and hypotension in the lower extremity, unequal blood pressures in the extremities, external evidence of major chest trauma (seatbelt or steering wheel contusion on the chest), thoracic outlet expanding hematoma, interscapular murmurs or bruits, palpable fractures of the sternum and ribs, or flail chest should increase suspicion of great vessel injury.2,6
Proximity of a missile trajectory to the brachiocephalic vessels, even without any physical findings of vascular injury, is an indication for pursuing a diagnosis of vascular injury. Close inspection of a penetrating wound should look for evidence, by inspection only, of retained implement or foreign body. Under no circumstances should the wound be deeply probed to determine depth or trajectory. Perform a complete neurologic examination due to involvement of the spinal arteries from the initial trauma.
DIAGNOSIS
ELECTROCARDIOGRAM
Patients with penetrating and blunt chest trauma require monitoring and immediate IV access. For blunt chest trauma, place the patient on a cardiac monitor, and obtain an ECG. The negative predictive value for cardiac injury in a patient with a normal ECG approaches 90%, but using the ECG alone does not exclude cardiac injury.15,56­58 A clinically significant cardiac event can occur over the first  hours following injury.34 The ECG is more sensitive for left ventricular injury and is poorly sensitive for the more common right­sided injuries. The most common dysrhythmia includes sinus tachycardia, followed by atrial fibrillation.6 Nondiagnostic findings on ECG, such as sinus tachycardia and nonspecific ST­T wave changes, do not help diagnose blunt cardiac injury. A small subset of blunt cardiac injury patients may have symptoms and ECG findings consistent with myocardial infarction. In such patients, consider coronary artery disease or acute coronary artery dissection, which may manifest with thrombosis of a cardiac artery and typically develops  to  days after injury (Table 262­4).17,59
TABLE 262­4
Electrocardiographic Findings in Cardiac Injury36
Nonspecific abnormalities
Pericarditis­like ST­segment elevation
Prolonged QT syndrome
Myocardial injury
New Q wave
ST­T segment elevation or depression
Conduction disorders
Right bundle branch block
Fascicular block
Atrioventricular nodal conduction disorders (first­, second­, and third­degree atrioventricular block)
Dysrhythmias
Sinus tachycardia (most common)
Atrial and ventricular extrasystoles
Atrial fibrillation
Ventricular tachycardia
Ventricular fibrillation
Sinus bradycardia
Atrial tachycardia
Source: Reproduced with permission from Sybrandy KC, Cramer MJ, Burgersdijk C. Diagnosing cardiac contusion: old wisdom and new insights. Heart. 2003;89(5):485­489. In patients in whom concern for blunt cardiac injury exists but in whom the ECG is normal, monitor for  to  hours with repeat examinations, ECGs, and cardiac monitoring. ECG can be utilized in combination with troponin to evaluate for blunt cardiac injury. If there are no new signs or symptoms and no abnormalities occur during this time period, patients can be safely discharged in absence of any other injuries.6,13 If the ECG is abnormal but there is no hemodynamic instability, admit the patient to a monitored setting, with serial ECGs to monitor for disease progression.6,13,15
CARDIAC BIOMARKERS
Although cardiac markers can be used to assist in the diagnosis of myocardial trauma, the utility of cardiac biomarkers in the setting of blunt cardiac injury remains unclear.6,60 The Eastern
Association for the Surgery of Trauma guideline provides a Level  recommendation stating troponin I should be utilized for patients with blunt cardiac injury. The guideline provides a Level  recommendation that normal troponin and ECG rule out blunt cardiac injury.69 Creatine kinase has limited reliability in the trauma patient because it is elevated in cases of severe skeletal muscle, liver, diaphragm, or intestinal injury; the creatine kinase­MB fraction will therefore be elevated as well. Creatine kinase­MB fraction elevation has been shown to occur in this situation in the absence of clinical evidence of cardiac injury. The isolated elevation of creatine kinase­MB, with no other associated injury, is not predictive of complications and mortality.2,6,61 Thus, obtaining creatine kinase­MB is of no value.
Cardiac troponins, specifically troponin I and troponin T, are very specific to myocardial injury and can detect very small amounts of myocardial necrosis. Neither cardiac troponin I nor cardiac troponin T is released with skeletal muscle injury. Elevation of troponins occurs in all myocardial trauma, including both blunt and penetrating trauma, surgery, ablation, pacing, defibrillator shocks, cardioversion, and interventional cardiac procedures. The sensitivity and specificity of troponins for blunt cardiac injury vary from 12% to 23% and 97% to 100%, respectively.58,62 Also, injuries remote from the chest from multisystem trauma and the presence of preexisting disease may result in dysrhythmia and elevated biomarkers, making their presence even less specific.63
Troponins in conjunction with a presenting ECG may increase the effectiveness of risk stratification.6 Patients with a normal ECG and normal serial measurements of serial cardiac troponin I had no significant blunt cardiac injury–related complications in one study.64 The sensitivity of an abnormal ECG and elevated cardiac troponin I for clinically significant blunt cardiac injury
(cardiogenic shock, dysrhythmias requiring intervention, or structural cardiac abnormalities related to trauma) was 100%, with a positive predictive value of 62%.62 Troponin T may also be used with similar sensitivity and specificity.57,65 Clinically significant blunt cardiac injury can occur without elevation of troponins, but there is usually an abnormality of the ECG. Monitor any serum troponin elevation and follow serially. Increased troponin levels at admission or within  hours of arrival have correlated with increasing risk of dysrhythmia and decreased ejection fraction.66 Troponin elevations have been associated with ventricular dysrhythmias and left ventricular dysfunction.67
Ultimately, the use of cardiac biomarkers may not affect the management of blunt trauma patients with hemodynamic instability, signs of severe injury, or an abnormal ECG. Such patients generally undergo echocardiography and are admitted regardless of biomarker elevation.
In rare blunt trauma patients with ECG findings of myocardial infarction, obtain cardiac biomarkers and immediately consult cardiology and cardiac surgery.5,6
ECHOCARDIOGRAPHY
The FAST examination includes a cardiac window using either the subxiphoid (Figure 262­3) or parasternal long­axis approach and is useful in penetrating and blunt trauma. This allows detection of free pericardial fluid and can give an estimation of general cardiac function. Point­of­care US has been shown to have a sensitivity of 100% and a specificity of 99% for detecting pericardial effusion.68
FIGURE 262­3. A. Traumatic pericardial effusion. Large pericardial effusion (arrow) after stab wound to chest visualized by subxiphoid approach of a FAST scan. The effusion can be seen outside the right ventricular (RV) and left ventricular (LV) walls. B. Large effusion (apical view). [Image contributed by James Mateer, MD.]
Point­of­care US is an invaluable tool for blunt trauma patients with unexplained, persistent shock out of proportion to apparent injuries and in any patients with signs consistent with blunt cardiac injury. Echocardiography provides information about global cardiac function, individual chamber function and wall motion, valvular function, and ejection fraction. It can also assist in alternative diagnoses for conditions such as aortic disruption/dissection, pericardial effusion, pleural effusion, and intracardiac thrombus.68,69 Transesophageal echocardiography has been shown to be up to three times more sensitive in diagnosing blunt cardiac injury than transthoracic echocardiography.70 Transthoracic echocardiography and transesophageal echocardiography, however, are not helpful in identifying patients at risk for developing blunt cardiac injury–related complications.13 Obtain comprehensive echocardiography for patients demonstrating elevated cardiac markers, dysrhythmias, or myocardial dysfunction.71
CHEST RADIOGRAPH
Many findings on the initial chest radiograph may be indicative of cardiac and great vessel injury (Tables 262­5 and 262­6), but many of these findings are insensitive and nonspecific.
TABLE 262­5
Radiographic Findings Suggestive of a Great Vessel Injury
Fractures
Sternum
Scapula
Multiple ribs
Clavicle in multisystem­injured patients
First rib
Mediastinal Clues
Obliteration of the aortic knob contour
Widening of the mediastinum
Depression of the left mainstem bronchus >140 degrees from trachea
Loss of paravertebral pleural stripe
Calcium layering at aortic knob
Abnormal general appearance of mediastinum
Deviation of nasogastric tube to the right at T4
Lateral displacement of the trachea
Lateral Chest Radiograph
Anterior displacement of the trachea
Loss of the aortic/pulmonary window
Other Findings
Apical pleural hematoma (cap)
Massive left hemothorax
Obvious diaphragmatic injury
Source: Reproduced with permission from Mattox KL, Moore EE, Feliciano DV: Trauma, 7th ed. New York, NY: McGraw­Hill; 2013. Table 26­5. TABLE 262­6
Reliability of Selected Clinical and Radiographic Criteria in the Detection of Traumatic Rupture of the Aorta*†
Chest Radiograph Finding Correlation With TAI (P value) Sensitivity Specificity Accuracy
Widened mediastinum (<65 years old) .001 .95 .82 .84
Widened mediastinum (all ages) .001 .80 .82 .82
Murmur .002 .32 .93 .84
Pneumothorax/pulmonary contusion .07 .22 .67 .51
Hemothorax .21 .25 .88 .81
First/second rib fracture .39 .36 .73 .68
Abbreviations: FN = false negative; FP = false positive; TAI = traumatic aortic injury; TN = true negative; TP = true positive.
*All other clinical and radiographic criteria were less useful in detecting TAI.
†Sensitivity = TP/(TP + FN); specificity = TN/(TN + FP); accuracy = (TP + TN)/All tests.
Source:Table 259­6 from Tintinalli, et al: Emergency Medicine: A Comprehensive Study Guide, 6th ed. © 2002, McGraw­Hill, New York.
Widening of the mediastinum on chest radiograph (Figure 262­4) has classically been considered as being a very sensitive finding for detection of major vascular injury. Definitions of a widened mediastinum have included a measured width greater than  cm or a clinician gestalt of mediastinal widening and mediastinum to chest width ratio of >0.38. Trauma patients have
<20% probability of major thoracic vascular injury with the absence of this finding on chest radiograph.72 However, a normal mediastinum on chest radiograph does not rule out aortic injury.
Therefore, the investigation of great vessel injury should occur if mechanism of injury, physician gestalt, physical examination findings, or radiographic indicators are consistent with injury.
One sensitive radiographic sign for traumatic aortic injury is deviation of the esophagus more than  cm to the right of the spinous process at T4.73
FIGURE 262­4. Portable chest radiograph of a patient with blunt thoracic trauma: chest radiograph shows widened mediastinum, obliteration of the aortic knob contour, and loss of visualization of the left hemidiaphragm, which are consistent with aortic injury.
CT ANGIOGRAPHY
CT angiography is the diagnostic modality of choice for both penetrating and blunt trauma of the thorax. Because CT is widely used in the evaluation of multisystem trauma, incorporating CT imaging for vascular injury can be easily done. Newer­generation multidetector scanners are very sensitive and specific for injury to the great vessels.2 Three­dimensional reconstructions of high­resolution data sets produce extremely accurate representations of the vascular anatomy and may be the only diagnostic imaging studies required by vascular surgeons. Multidetector
CT scanners can detect pericardial rupture and effusion, and ECG­gated CT scan can identify structural cardiac injuries.74,75 Although CT does require the patient to leave an intensive monitoring area, the information it provides can lead to treatment avenues vital for patient survival. Full­body scans are relatively rapid, with image acquisition occurring in less than  minutes. In comparison to classical angiography, CT angiography is faster and less expensive and eliminates complications related to vessel catheterization. Most institutions use multidetector CT scanners with CT angiography as the screening study of choice for aortic injury. Thin­slice multidetector CT with rapid scanning and contrast­bolus timing has shown great promise in detecting and localizing a variety of nonaortic vascular injuries, including active bleeding that can lead to early surgical or angiographic intervention to control blood loss.55 Major
CT angiography findings for blunt trauma can be seen in Table 262­7. TABLE 262­7
CT Signs of Traumatic Aortic Injury65
Common Signs
Aortic pseudoaneurysm
Periaortic hemorrhage
Displacement of the trachea and esophagus to the right by hematoma, an irregular shape to the aortic lumen
Intimal flaps projecting into the lumen
Uncommon Signs
Luminal clot at sites of intimal disruption
Sudden change in caliber of the aorta without intervening branch vessels (coarctation)
A small aortic caliber in the lower chest and abdomen
Peridiaphragmatic hemorrhage (from proximal intraluminal thrombus)
Rare Signs
Transection of the aorta
Active bleeding from the aorta into the mediastinum
Source: Reproduced with permission from Mirvis SE. Thoracic vascular injury. Radiol Clin North Am. 2006;44(2):181­197. Copyright Elsevier.
The major role of CT in penetrating trauma is determination of the presence or absence of mediastinal involvement along or near the course of the penetrating object (Figure 262­5). This can lead to direct finding of injury to major mediastinal structures. Aortic or major arterial injuries can be detected and appear as irregular vascular contours, luminal narrowing or irregularity, pseudoaneurysms, dissections, and acute bleeding. CT angiography is also helpful in penetrating injury to the thoracic great vessels.55 In some cases, the vessel lumen may appear completely normal on CT due to the external forces to the vessel. Damage surrounding the vessel, usually in the form of perivascular hemorrhage, is present. Following the tract of the missile on CT should also help in determining the likelihood of direct vascular involvement.2,55
FIGURE 262­5. CT scan of traumatic aortic injury. A. Axial CT scan showing mediastinal hematoma (open arrow) and irregularity and thrombus in the aorta (closed arrow). B. Sagittal CT scan of same patient with pseudoaneurysm (arrow) from tear in aorta distal to left subclavian artery.
OTHER IMAGING MODALITIES
MRI and magnetic resonance angiography provide similar detailed information. However, MRI and magnetic resonance angiography require lengthy study times, have limited emergent availability at most institutions, and require the transport of a potentially unstable patient away from a monitored environment. These limitations make MRI and magnetic resonance angiography impractical for most trauma patients presenting to the ED.2
Transesophageal echocardiography remains a very attractive diagnostic option because of its advantages of speed, portability, immediate availability of results, and low cost. With recent advances in echocardiographic instrumentation and technology, it has evolved as a promising imaging technique that can provide comprehensive information on the location and extent of aortic injury. Transesophageal echocardiography allows diagnosis of limited intimal lesions frequently missed by other conventional methods and permits rapid diagnosis of complete rupture at the bedside of hemodynamically unstable patients. One study demonstrated that despite significant blurring of the aortic outline in 20% of cases and intraluminal artifacts being observed in 36% of cases, the accurate diagnosis of traumatic aortic injury was made.32 Transesophageal echocardiography is contraindicated in patients with potential airway problems or suspected cervical spinal injuries.
Aortography remains a viable imaging option for determining the location of aortic injury, which is paramount in operative management (Figure 262­6). Angiography is more time consuming to perform, invasive, and not as readily available as CT on an acute basis. It is more expensive than CT as a screening study. Angiography is useful when CT results are indeterminate and may be required by surgeons for planning and guiding operative repair. Angiography may be used to pursue injury in the aorta or branch vessels in penetrating injuries that have only proximity to these vessels. Caution should be exercised with “negative” results because a clot or an intimal flap may close the luminal defect. The overall complication rate of angiography has remained at about 25%, but rates for serious complications, such as amputation and death, remain low at .1% and .3%, respectively.76
FIGURE 262­6. Angiogram of the same patient in Figure 262­5 showing pseudoaneurysm (open arrow) and irregular lumen (closed arrow) of injured aorta.
TREATMENT OF GREAT VESSEL INJURY
Consult a trauma or vascular surgeon at the time of initial suspicion of great vessel injury or immediately upon diagnosis. Transport patients with great vessel injury who exhibit hemodynamic instability, profound hemorrhage from chest tubes, and radiographic evidence of a rapidly expanding mediastinal hematoma immediately to the operating room.
Immediate surgical repair may not be possible in all patients. Patients with instability from other injuries, such as from intra­abdominal injuries or severe closed head injuries, may require a delayed repair due to the severity of these other life­threatening issues. Some elderly patients may have comorbidities that require medical management prior to surgery. Pharmacologic control of blood pressure and heart rate is extremely important when delayed or nonoperative management is contemplated.2,77 Avoid large swings in blood pressure that may increase vessel­shearing forces in patients who are hemodynamically stable. Administer β­adrenergic blocking agents, sedatives, analgesics, and vasodilators as needed to keep the patient’s heart rate and systolic blood pressure at appropriate levels. Use autotransfusion devices in cases of large bleeding vessels if available.
Traumatic aortic injuries can be partial thickness (as in the classic intimal flap of aortic dissection) or full thickness with containment by surrounding structures. These histopathologic entities mandate a similar therapeutic approach as aortic dissection. Decreasing the slope of the dP/dT (change in pressure over the change in time) will decrease wall tension and shearing forces.
This may lead to permissive hypotension and bradycardia as a treatment and temporizing measure in aortic disruption. Maintain systolic blood pressure in the 100 to 120 mm Hg range with a heart rate around  beats/min. This will decrease the shearing forces on the internal lumen. Patients should not perform any maneuver, like a Valsalva, that will increase intrathoracic pressure. Titrating a short­acting β­blocker, such as esmolol, can decrease the heart rate. Once the heart rate is controlled, an arterial vasodilator, such as a calcium channel blocker or sodium nitroprusside, can be added to help control the blood pressure. A vasodilating calcium channel blocker such as nicardipine or clevidipine is recommended over sodium nitroprusside. Do not use sodium nitroprusside alone due to the reactive tachycardia associated with its administration.2,6
Acknowledgments
The authors thank Christopher Ross and Theresa Schwab for their contributions to this chapter in the prior edition.


