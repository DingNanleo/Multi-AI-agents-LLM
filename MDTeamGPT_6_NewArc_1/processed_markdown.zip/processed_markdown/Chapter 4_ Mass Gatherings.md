University of Pittsburgh
Access Provided by:

Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 4: Mass Gatherings
Asa M. Margolis; Michael G. Millin
INTRODUCTION
Mass gathering medical care refers to the provision of medical services to organized events or venues with relatively large numbers of people in a defined geographic area. Typically, mass gatherings are considered to be events that have at least 1000 people; however, this does not have to be the
1,2 case. In fact, large organizations including the World Health Organization and the U.S. Federal Emergency Management Administration do not focus on the number of attendees when defining mass gatherings; rather, they recognize the impact on the surrounding resources.
There are several variables in event and crowd characteristics that may affect patient presentation rates, thus resulting in demands on the event medical staff and larger surrounding system that bear little direct relationship to the number in attendance. Some of these variables include weather conditions, presence of alcohol and/or illicit substances, type of event, violent spectator behavior, and presence of potable water. Further, events that are considered “bounded/focused” (stadium sporting events) are associated with higher patient presentation rates than those considered

“unbounded/extended” (parades), likely due to the leakage of patients in the unbounded events into the surrounding healthcare system. Event medical directors should also consider the transport to hospital rate from the same or similar previous events when planning their event. In
4 conjunction with the patient presentation rate, the transport to hospital rate can assist in estimating resources needed.
Table 4­1 lists some of the major factors affecting planning for a mass gathering event. Physical barriers may inhibit easy entry and exit from the site.
These barriers can make it difficult to get medical resources into, and to get patients out of, the event location. Reliable communication between medical personnel, event organizers, and outside medical resources is key to a successful medical response. Finally, event planners should consider possible public health threats of widespread communicable disease and the potential for a terrorist attack with explosive or other devices.
TABLE 4­1
Factors Affecting Planning for a Mass Gathering Event
Venue entry and exit
Communication
Environment
Potential public health threats
EPIDEMIOLOGY AND TYPES OF MASS GATHERINGS
The need for mass gathering medical care was first described after two spectators collapsed and died during a University of Nebraska football game in

1965. The event organizers were not prepared to manage medical emergencies in the midst of the event, and consequently, when these two patients needed medical care, the organizers were not able to meet the need. Medical directors have become experienced in mass gathering medicine, and case
2 reports are described for sporting events, concerts, expositions, and other large congregations of people.
One of the largest global gatherings, the Islamic Hajj pilgrimage to Mecca, Saudi Arabia, has required officials to manage threats to public safety from outbreaks of infectious disease to major traumatic injuries from stampedes. Other notable global mass gatherings include the 2010 World Expo in

SDhoawnnglhoaaid, eCdh i2n0a,2 w5­h7ic­1h 4at:5tr aPc t Yedo uarp IpPro isx im13a6t.e1ly4 27.01 m59il.l1io2n7 visitors, and the Olympic and Paralympic Games in Rio de Janeiro, Brazil, in 2016. More
Chapter 4: Mass Gatherings, Asa M. Margolis; Michael G. Millin recently, music festivals, including electronic dance events, are increasingly common. These events have predictable risks and patient presentations.
. Terms of Use * Privacy Policy * Notice * Accessibility
Studies suggest that appropriate on­site healthcare resources may reduce significantly the impact on the prehospital and emergency health resources
7 in the surrounding community. As mass gathering events become more common, there is a need to develop the science of mass gathering medicine.
The growing field of mass gathering medicine continues to be instrumental in exploring the health risks of mass gatherings and providing strategies that contribute positively to delivering care during these events.
Interestingly, despite the fact that mass gatherings are generally attended by individuals in good health, these events tend to have a higher incidence of
8 illness and injury than that which would be found in the general population. The incidence of usage of medical care at mass gatherings has been
2 reported to range from 4 to 440 patients per 10,000. The wide variance in medical usage rate is a function of the variables previously discussed.
COMPONENTS OF A MEDICAL ACTION PLAN

In preparing for a mass gathering event, medical directors should develop an organized approach through the development of a medical action plan.
PHYSICIAN MEDICAL OVERSIGHT
All mass gathering events should have an identified physician medical director who is responsible for developing the medical action plan. The objective of this plan, which should be a component of the overall incident action plan, is to describe the details about the organization and delivery of medical care. The medical director is also responsible for providing medical oversight before and during the event. This person should be board certified in emergency medicine and have a current medical license from the state(s) where the event will be located. The medical director should also have experience in the medical direction of EMS and the provision of medical care at mass gathering events. It is becoming more common for the event medical director to be board certified in EMS. Experience and training in EMS provide an event medical director with skills in field medicine, including creative thinking, the ability to make diagnostic and treatment decisions purely on clinical grounds, and an awareness of operational environments that are very different from a typical ED.
The medical director is responsible for developing plans for indirect medical oversight and ensuring a coordinated system of direct medical oversight.
Indirect oversight describes a system of written protocols that provide the medical personnel with a standardized set of directions for the care of a variety of traumatic and medical conditions that may be encountered during the event. These protocols should always be at least commensurate with local EMS protocols unless the medical director has prior approval from the local jurisdictional EMS medical director to deviate from them. Direct medical oversight describes a method of direct communication with medical providers during the event to answer questions and provide medical direction in real time during the event. Although direct oversight can be delegated to a team of physicians for an event of long duration, ideally, the medical director should plan to be on site during the event as much as possible.
COMMAND AND CONTROL
In addition to an event medical director, mass gathering plans should have an organized system of command and control. Although many systems exist for the command and control of resources at emergency incidents or mass gatherings, one of the most well­tested and efficient methods is the
Incident Command System. The system can be used for any type or size of emergency, disaster, or mass gathering, with the purpose of allowing either
10 a single agency or multiple agencies to communicate using common terminology and operating procedures.
The purpose of establishing a command and control system like the Incident Command System is to define clear lines of reporting and communication among all major functioning components that may coexist during an incident. The organizational structure develops in a modular fashion from the top down. While the Command function is always established, the other divisions, which include Operations, Logistics, Planning, and Finance, form as
11 needed (Figure 4­1). As will be discussed later, the physician’s role within the Incident Command System structure should be focused on direct oversight of patient care and not involve the global issues that are the concern of the incident commander.
FIGURE 4­1. 11
Incident Command System organizational chart.
Within a typical Incident Command System, the provision of medical care to the public occurs within the Operations Section. Often referred to as the
“doers,” it is the function of the Operations Section to complete the primary tasks of the mission. Members of the medical branch in Operations include, but are not limited to, emergency medical technicians, paramedics, nurses, physician assistants, and physicians. It is not required that the physician take the lead role of each medical team. In fact, it may be more beneficial to have the individual with EMS or fire service experience in the role of team lead, which ideally may be an EMS physician. An agency’s medical director should be available for direct medical oversight as needed and should ideally be on site as much as possible. The medical director(s) should function as a commander within the Operations Section and report back to the section head of Operations who ultimately reports to the incident commander. Key to the success of the Incident Command System is that every individual abides by the established hierarchical ranks of command.
FORCE PROTECTION MEDICAL SUPPORT
It is well known that if a medical provider becomes sick or injured, the provider will use resources intended for the public and distract other providers from the ability to perform their duties. As such, a sick or injured medical provider has the potential to dramatically disrupt the overall medical mission for the event. While medical personnel are always responsible for assessing and ensuring their own safety and those with whom they work, it is imperative to have a well­designed plan for the overall medical care and protection of the medical providers at the event. The provision of dedicated force protection medical support can be a critical factor toward enhancing individual law enforcement and EMS/fire personnel health sufficient to
12 maintaining effectiveness for the duration of the event.
One of the duties of the event medical director is to be prepared to provide care to the other medical and law enforcement providers should the need arise. In addition, communication with law enforcement personnel will help to ensure the overall protection of the medical providers. Their support should be readily available and have the means to immediately respond to any location should the situation become unsafe. Depending on the type of event, threats could range from those that are readily seen (e.g., crowds at a concert) to those that are hidden (e.g., explosives and other weapons carried by an individual with the goal of using mass gathering events to kill and injure).
EVENT RECONNAISSANCE
In the beginning stages of preparation, the medical director and assistants need to assess the site to identify potential risks for morbidity during the event. This should ideally be done with the dates and duration of the event in mind and should also account for the geographic variants that will affect their ability to provide medical care to the public. Adequacy of exits should be addressed, routes of ingress and egress should be reviewed, and the geographic area the medical care sector is responsible for should be identified. Backup plans should also be developed. Planners should determine ideal locations for setting up a base of operations, fixed medical care sites, and staging areas for mobile units. Decisions should take into account the effects of predicted traffic flow, predicted sites of high­volume medical need, natural geographic barriers, and location of receiving medical facilities.
Ideally, the event medical director should meet with the jurisdictional 9­1­1 EMS medical director(s) to discuss planning and response should a mass casualty response be required.
EVENT NEGOTIATIONS
The process of developing a medical plan for a mass gathering event requires a cohesive teamwork approach with multiple interest groups. First and foremost, the medical planners should develop a plan that meets the needs of the public and the event planners. This first step may require some negotiations with event planners in determining locations for fixed and mobile medical units, level of care to be provided, and resources provided to the medical units. Negotiations will determine if the medical units will be paid under contractual terms by the event planners or if they will volunteer their services to the event. This negotiation stage should also resolve who will finance the purchase of needed supplies and pay for other needed resources, such as costs of transportation and liability coverage.
Regardless of who pays for supplies, it is important that the medical teams coordinate to ensure that equipment and supplies are readily available when needed. Similarly, regardless of who is responsible for acquiring supplies, there is value to the event medical director having ultimate control over the acquisition and maintenance of critical medical supplies, as this will ensure that the medical needs of the public are met.
Medical planners should also establish communication and agreements with other outside agencies that have a potential need to interact with the medical response team for the event. Medical teams that are formed outside the local jurisdictional EMS system should have an agreement with local
EMS that addresses transportation of patients out of the event to local resource hospitals. Transfer and acceptance agreements should be developed with the hospitals. Local law enforcement should be contacted for assistance with traffic flow and security. Events that have the potential to be affected by security issues on a national scale may also require agreements with the U.S. Department of Homeland Security for disaster and security response.
HUMAN RESOURCES, LEVEL OF CARE, AND TRAINING
The event medical director should determine the desired level of care for the event based on the predicted medical need and available resources.
While there is no universally acceptable formula that can accurately predict staffing requirement, the number of medical providers should be a balance between the number determined to be optimal based on reconnaissance, statistical estimates, and review of previous similar events. Emergency medical technician should be the minimum acceptable level of care. However, depending on the event type and size and the number of medical providers available to staff the event, there may also be a role for the emergency medical responder to provide operational medical support. Once the desired level of care and the predicted patient volume are determined, the medical director will be able to develop a plan for human resource needs.
These resources may be acquired through the local EMS system, area hospitals, medical training programs, or other sources such as ski patrols and medical reserve corps.
Medical personnel should be licensed to practice at their level of training in the local jurisdiction. Although the medical personnel should be trained for their established level of care, the medical director may want to have additional training sessions to address specific injuries and medical conditions that are predicted to be encountered by the medical personnel during the event. Using new or modified protocols should be preceded by pre­event education of all relevant personnel and close medical oversight. Regardless, it is important that the providers work within a defined scope of practice as determined by level of training and any operational­specific protocols that may be authorized by local authorities for mass gathering events.
EQUIPMENT
When considering equipment for a mass gathering event, planners and medical directors should take into account the type of event, the weather, and the skill level of the medical staff. Units with physicians may elect to have on hand supplies to do simple suturing and advanced resuscitation. However, thought should be given to the available time needed to suture a wound in balance to the patient volume and the availability of the fixed standing acute care centers. If available, it may be more advantageous to refer patients needing procedures to acute care hospitals. The appropriate way to manage the need for procedures is dependent on the available resources and the overall mission of the medical care at the event.
Often, a large proportion of time spent planning out supplies is focused on generating a broad list and subsequently obtaining supplies that would be necessary to provide medical care for a critical patient. As discussed earlier, it is important to consider that rapid transport of this patient away from the incident to the controlled environment of an acute care hospital may be more beneficial for the patient and free up the provider to care for other patients who would likely not receive evaluation given the time­consuming nature of the critical patient. In addition, proportionally fewer critical patients are seen at a given event compared with the vast majority who seek aid for minor complaints such as scrapes, blisters, headaches, and sprains. Therefore, more effort should be placed on obtaining supplies in highest demand. As suggested by the number and type of complaints seen, those supplies in highest demand typically include bandages, foam padding for blisters, ice for sprains, fluids for oral rehydration, acetaminophen, and ibuprofen.

Data have demonstrated the incidence of cardiopulmonary arrest and the need for major resuscitation at mass gathering events is low. However, medical units should, at the very least, have access to an automated external defibrillator.
Event­specific protocols should address the use of advanced airway equipment, including the possible use of medications for rapid­sequence intubation. Plans for other resuscitation needs should also be addressed prior to the event so that all providers manage these small numbers of cases in a standard format (e.g., fluids for sepsis, postresuscitation care, management of cardiac arrhythmia, status asthmaticus). Although it is rare that there is a need for major resuscitation, there may be value to having supraglottic airways and intraosseous needles.
In addition to the level of training of the medical staff, equipment needs will be determined by the mobility of the unit. Some events may need mobile medical units that are able to reach patients in difficult locations or easily move through large crowds. Units on foot and other nonmotorized means of travel will be able to carry fewer supplies than those using motorized vehicles such as golf carts. For events using nonmotorized mobile units, it will be important to design a means to bring heavier supplies to a patient should the need arise. Units in fixed locations will be able to stock a greater quantity of materials, possibly including cots, shelter, and additional medical supplies.
Although the equipment needs are unique for each event, there are some things that are universal. Tables 4­2 and 4­3 show suggested items for both mobile and fixed units as well as suggested equipment based on the skill level of medical personnel.
TABLE 4­2
Equipment List for Mobile Units
Item
Basic (BLS­level EMS provider and above) Automatic external defibrillator
(May alternatively place in a strategic location in the site venue)
Cervical collar
(May strategically place in the site venue a method for transport of a patient requiring in­line spinal immobilization)
Airway adjuncts
Oxygen delivery devices (nasal cannula, nonrebreather mask, bag­valve mask)
Oxygen and suction
(May be strategically placed in site venue)
Bandages (4×4, roller gauze)
Triangular cravats
Adhesive bandages
Nonlatex gloves
Splints
Stethoscope
Sphygmomanometer
Tape
Shears
Flashlight
Documentation forms
Hazardous waste bags
Compact foil space blankets
Petroleum jelly (used to prevent chaffing by marathon runners)
Oral fluids for hydration (water, sports drinks)
Advanced (ALS­level EMS provider and Advanced airway equipment including laryngoscope with assorted blades, endotracheal tubes, and above) cricothyrotomy kit
(May alternatively use a supraglottic airway device)
IV access devices and tubing
(May choose to carry an adult intraosseous set)
Normal saline in 1­L bags
Glucometer
Dextrose for IV administration
Advanced cardiovascular life support medications: epinephrine, atropine, amiodarone, adenosine
Aspirin
Nitroglycerin
IV diphenhydramine
Parenteral benzodiazepine
Multidose inhaler albuterol
Epinephrine in 1:1000 concentration
Morphine
Airway medications: induction agent, paralytic
Abbreviations: ALS = advanced life support; BLS = basic life support.
TABLE 4­3
Equipment List for Fixed Units
Item
Physician­level care (some of these skills and/or medications may be available for use by EMS providers with Suture kits with absorbable and authorized operational­specific scope of practice for mass gathering events) nonabsorbable sutures
Needles and syringes
Forceps
Scalpel
Normal saline for irrigation
Local anesthetics
Otoscope
Analgesics: acetaminophen, ibuprofen, morphine
Antacids
Antiemetics
Prednisone
Antibiotics: ointment, oral
Activated charcoal
Airway management: induction agent, paralytic
Nonmedical equipment Cots
Shelter
Blankets
Chairs
Hazardous waste receptacle
Sharps box
TREATMENT FACILITIES
Medical directors will need to determine if the scope of the event will require fixed treatment facilities or if mobile units will be sufficient. Factors that contribute to this decision include, but are not limited to, the predicted number of patients expected to seek medical care, length of the event, distance to off­site medical care, and environmental factors. Fixed treatment facilities can be set up in mobile tents or within a permanent structure. Regardless, fixed treatment facilities should be set up in such a way as to be able to withstand the predictable weather conditions that may be encountered during the duration of the event. The location of the facility should also be easily accessible and have a secure path for ingress and egress. From a patient care perspective, it is important to have a facility that has environmental control to manage heat­related illness in warm weather and cold­related illness in cold/wet weather. Off­site treatment facilities should be arranged with local hospitals.
Staffing of both fixed treatment facilities and mobile units contributes to the success of the overall event’s medical response plan. Appropriately placed physicians can expand on­site definitive treatment, including the use of chemical sedation, advanced wound care, and disposition of high­risk cases who wish to sign out against medical advice. Further, physicians on site have been able to affect ambulance transport rates, thereby helping to
14 preserve EMS and resources for the surrounding community.
TRANSPORTATION
Nonmedical and medical transportation is necessary, taking into account the number, capacity, and staging location for transport units. Nonmedical transportation units move personnel and resources throughout the site. Medical transportation moves patients within the event location and out to area hospitals. Ambulances are the mainstay of ground transport from the venue to outlying medical facilities. They should be dedicated to the event and prepositioned in an easily accessible and known location. If the supply of event­dedicated ambulances becomes depleted, there should be a plan in place to support emergency medical transportation.
Planners may also need to address nontraditional modes of transportation, such as golf carts, all­terrain vehicles, boats, bicycles, horses,
15 snowmobiles, and toboggans. Operators must have experience in their handling, and these resources should be dedicated for use throughout the duration of the event. Protocols should also be developed that address the appropriate use of air medical transportation, including location and setup of a safe landing zone.
PUBLIC HEALTH
Public health concerns during a mass gathering event may be addressed by the event managers or delegated to the local public health authority or the medical director and EMS system. Even if these concerns are not delegated to the medical response team, public health concerns can affect patient care, and therefore, the medical director should be aware of these issues. Table 4­4 lists some potential public health concerns.
TABLE 4­4
Public Health Concerns to Be Considered for a Mass Gathering Event
Access to potable water
Proper waste management for human waste
Waste management for nonhuman waste
Proper management of food service to prevent spread of foodborne illness
Proper road/traffic management to prevent traffic­related injuries
Other considerations for injury prevention
Large­scale natural or man­made disaster
ACCESS TO CARE
The event managers and medical director should develop plans to ensure that the public will be able to access emergency care, if needed. These plans should ensure that the locations of fixed treatment facilities are well marked with signs and other visual aids and that there are limited barriers to access these facilities. Fixed treatment facilities should be accessible to all members of the public, regardless of their ability to actively seek care, and comply with guidelines that are in accordance with the Americans with Disabilities Act. Mobile medical personnel should also wear vests or other highvisibility clothing easily identified by the public. Pamphlets or signage can alert the public about methods for accessing emergency care.
COMMUNICATIONS
Successful management of any mass gathering event is contingent upon an effective communication system. To maintain coordination and control, the system must be tailored to the unique needs of the scenario. The design is dictated by a variety of factors, including geography and size of venue, number of participants, budget, and the systems of those with whom providers will be interfacing. Consideration should also be given to environmental factors including temperature extremes, water, and noise. Venues at music concerts and motor sports may require special communication devices to allow for providers to communicate with each other while in the presence of loud background noise.
Modalities can range from simple flag signals to sophisticated radio networks and may include consumer Family Radio Service devices (walkie­talkies), cellular systems, and landline phones. Each has their strengths and weaknesses. Walkie­talkies have a multitude of channel options but are typically limited to a 1­ to 2­mile range. Cellular and other phone systems may provide an inexpensive option but are easily overwhelmed by large numbers of users during a crisis. Two­way radios with more power and range than Family Radio Service systems may be analog or digital, using very high frequency, ultra­high frequency, or 800­MHz frequencies. Systems using a repeater antenna allow for communication over greater distances and across rugged terrain. Large­scale, trunked radio systems provide central control of end­user access to selected channels, allowing a greater number of people to function within a limited spectrum. These systems also allow for discrete groups of responders to communicate among themselves without disturbing other groups.
The communication center should be located in an area that affords the greatest coverage for the event and is fully accessible to the medical director. If situationally appropriate, it may be advantageous to have it co­located in the event command center. This communications network should be separate from the surrounding EMS jurisdiction and should be solely dedicated to the event. Ideally, the communications center should be linked by cell phone, landline, or radio to surrounding jurisdictional services, which include, but are not limited to, public safety answering point (PSAP), local emergency management, EDs, and public health departments.
If the communications network is not linked to surrounding resources, a protocol must be in place for making contact and for relaying information as needed. In an urban environment, this may be in the form of an on­site representative from the local EMS system or an identified phone number or frequency designated for the activation of additional resources. In a remote area, one or more people may be tasked with relaying messages via radio or traveling to the nearest telephone or area of cellular service to contact local authorities, or a specific “communications tent” may be organized.
DOCUMENTATION
The medical director should develop a system for documentation of patient encounters during the event. This system need not be as extensive as that which would be found in the typical ED setting and, instead, should be focused on the event to address specific components of the patient encounter as outlined in Table 4­5. Medical documentation should be easy to complete and not exhaustive, such that it can be quickly completed if large numbers of patients seek medical care at the same time. Medical directors may want to consider a method of electronic documentation. Paper documentation should ideally be on a single sheet that can be used by all providers involved in the patient’s care (Figure 4­2).
TABLE 4­5
Documentation
Purposes of medical documentation for a mass gathering event
Assist in transfer of care from the event site to off­site medical facilities
Record medical interactions for the purposes of liability control
Establish a means of data capture for continuous quality oversight and research
Essential components of medical documentation for a mass gathering event
Patient’s name, contact information, sex, and age
Vital signs
Chief complaint
Focused physical examination
Suspected diagnosis
Medical care rendered
Disposition
FIGURE 4­2. Patient encounter form. (Used with permission from the Mass Gathering Medicine On­Line Registry, accessed at http://ubcmgm.ca/registry/.)
LIABILITY
All members of the medical response team for a mass gathering event should have medical liability coverage. Depending on the restrictions of the carrier, liability coverage may be provided by the policy of one’s primary employment or may need to be purchased as additional coverage. The medical director may want to arrange coverage for all members of the medical response team as a group. This should be factored into the cost of providing medical care for the event and should be discussed with planners during the negotiation stage before the event. It is important to note that, if the medical personnel will be reimbursed for services in the form of legal tender or payment in kind (even in the form of a free meal at the event), they may not be protected from liability through Good Samaritan laws, depending on the state. In addition, if the medical providers are advertising their medical services to the public at an event even by setting up an established medical tent, the providers have established a duty to act and are liable to the public to provide care at an established standard. To mitigate untoward risk, the medical director should review the laws that pertain to the local area before the event.
CONTINUOUS QUALITY IMPROVEMENT
Unless an event is anticipated to be a one­time occurrence of a short duration, the medical director should establish a method of continuous quality improvement. The continuous quality improvement program should begin with a review of the documentation for patient encounters to identify elements of the system that are performing well and elements that need improvement. The results of continuous quality improvement review should then be used to improve upon the system of delivery of care. The medical director may also consider having regular case reviews with the medical personnel at the event to improve the care being delivered. In addition, an after­action report, which includes all aspects of the event from planning through execution, can identify areas of improvement for future events.
SPECIAL SITUATIONS
CARDIAC ARREST
In general, the incidence of cardiopulmonary arrest and the need for major resuscitation at mass gathering events is low. However, cardiac arrest has
16 been shown to be particularly susceptible to successful intervention in this type of setting. The foundational components of successful resuscitation,

CPR and early defibrillation, should be delivered to a patient within 3 minutes of notification of collapse. Thus, staging of medical personnel within an appropriate response radius and equipping medical units with an automated external defibrillator should be a priority. Planners should also consider the placement of ambulances within a location at the event for easy egress and the provision of advance life support care.
MASS CASUALTY INCIDENT
In preparing for a mass gathering event, the event medical director should contribute to and have full working knowledge of the action plan in response to a mass casualty incident. Plans should include methods of triage, coordination of the mass casualty with local EMS, and distribution of large numbers of patients as needed to area acute care facilities. There should be predesignated communication channels so incoming responders can communicate with the scene of the incident. The medical teams should function seamlessly in the Incident Command System structure. Success is partly predicated on predetermined roles of the personnel at the event, which allows for immediate implementation of the Incident Command System.
History has demonstrated that mass gathering events can be targets for intentional acts of harm. Given this possibility, the medical director should be involved, along with the director of event security, in formulating an action plan should such an event occur. This plan should include a contingent causality collection area able to manage an influx of patients.


