## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 58: Pulmonary Hypertension
John C. Greenwood; Michael Winters
INTRODUCTION AND EPIDEMIOLOGY
The pulmonary vascular system is normally a high­flow, low­resistance circuit, with a mean pulmonary arterial pressure that constitutes approximately

15% to 20% of the systemic circulation. Normal pulmonary arterial systolic pressures range from  to  mm Hg, and diastolic pulmonary arterial
 pressures range from  to  mm Hg. Pulmonary hypertension exists when a mean pulmonary arterial pressure is >25 mm Hg at rest or >30 mm Hg
,2 during exertion.
Pulmonary hypertension classification uses measurements of pulmonary arterial pressure, pulmonary vascular resistance, and pulmonary capillary
,3 wedge pressure (Table 58­1). Although echocardiography estimates pulmonary arterial pressure in a patient with suspected pulmonary hypertension, definitive diagnosis requires right heart catheterization.
TABLE 58­1
World Health Organization Classification of Pulmonary Hypertension
Group 1: Pulmonary Arterial Hypertension
Idiopathic
Genetic/heritable abnormalities
Drug or toxin induced
Associated with known risk factors for pulmonary arterial hypertension (human immunodeficiency virus, portal hypertension, pulmonary venoocclusive disease, collagen vascular disorders)
Group 2: Pulmonary Venous Hypertension (left heart disease)
Left ventricular systolic or diastolic dysfunction
Mitral or aortic valve disease
Group 3: Chronic Hypoxemic Lung Disease
Obstructive lung disorders (chronic obstructive pulmonary disease)
Interstitial lung disease
Idiopathic pulmonary fibrosis
Collagen vascular disorders
Sleep­disordered breathing (obstructive sleep apnea)
Chronic exposure to high altitude
Group 4: Chronic Thromboembolic Pulmonary Hypertension
Group 5: Miscellaneous
Lymphatic obstruction
Hematologic disorders: myeloproliferative disorders
Systemic disorders: sarcoidosis, neurofibromatosis
Metabolic disorders: glycogen storage disease, thyroid disorders
PDaotwiennltosa wdeitdh g2r0o2u5p­ 71­ 1p u4l:m59o nPa r yY aorutre rIPia li sh y1p3e6r.t1e4n2s.i1o5n9 h.a1v2e7 a mean pulmonary arterial pressure >25 mm Hg, a pulmonary vascular resistance >240
Chapter 58: Pulmonary Hypertension, John C. Greenwood; Michael Winters 
  dynes/s/cm , and a pulmonary capillary wedge pressure <15 mm Hg. Group  disease is caused by left heart disease and is the most common
. Terms of Use * Privacy Policy * Notice * Accessibility
 etiology. Group  occurs with chronic hypoxemic lung disease. Chronic thromboembolic pulmonary hypertension, group , develops in up to 4% of
4­6 ,7 patients with thromboembolic disease. Regardless of the cause, pulmonary hypertension is associated with high rates of morbidity and mortality,
 with a 5­year death rate for patients with idiopathic pulmonary arterial hypertension exceeding 30%.
PATHOPHYSIOLOGY
Pulmonary arterial hypertension consists of vascular remodeling in all layers of small and mid­sized pulmonary arterioles, plus inflammation and in
 situ thrombosis formation. Additional pathology includes alterations in microvascular permeability, hypoxic vasoconstriction, and plexiform lesion formation in arteriolar walls. The cumulative effect of these changes is sustained elevations of pulmonary vascular resistance and impaired pulmonary blood flow.
With persistent elevations in pulmonary vascular resistance, the right ventricle (RV) dilates. RV dilation leads to increased ventricular wall tension during systole, increased oxygen consumption, and eventually decreased contractility. With progressive RV dilation, the intraventricular septum displaces toward the left ventricle, which inhibits left ventricular filling and ultimately impairs cardiac output and systemic perfusion.
Perfusion of the right coronary artery depends on the coronary perfusion pressure (systemic diastolic pressure – right atrial pressure), which normally occurs during both systole and diastole. In patients with advanced pulmonary hypertension, right coronary artery perfusion occurs almost exclusively
,11 during diastole. Decreased perfusion results in RV ischemia and further impairment of cardiac output. Eventually, this cycle results in RV failure and cardiovascular collapse.
CLINICAL FEATURES
,12
The most common symptom of pulmonary hypertension is dyspnea, either at rest or with exertion, and is present in over 50% of patients. Other
,12,13 symptoms include fatigue, chest pain, syncope, and exertional lightheadedness. Delays in diagnosis are common, with a mean interval between
 symptom onset and diagnosis of  years. As pulmonary artery pressure increases, patients can develop symptoms of advanced heart failure such as early satiety, anorexia, orthopnea, paroxysmal nocturnal dyspnea, and peripheral edema.

The physical examination is often normal in the early stages. As the disorder worsens, findings of RV failure emerge (e.g., a holosystolic tricuspid regurgitation murmur, jugular venous distention, hepatomegaly, ascites, increased intensity of the pulmonary component of the second heart sound
,4
[P ], and lower extremity edema).

DIAGNOSTIC TESTING
ECG

The most common ECG abnormality is right axis deviation. Additional findings include signs of RV hypertrophy or RV failure, such as an R/S ratio >1 in lead V , an R/S ratio <1 in leads V and V , a qR complex in lead V , an S Q T , right atrial enlargement in the inferior leads, and an incomplete or

 complete right bundle branch block (Figure 58­1). These findings are neither sensitive nor specific for pulmonary hypertension.
FIGURE 58­1. ECG with atrial fibrillation and findings predictive of pulmonary hypertension: R/S ratio in V >1, right axis deviation, and ST depressions in V to V
   indicating possible right ventricular strain.
The ECG may show signs of RV ischemia or dysrhythmia. The most common dysrhythmias in patients with pulmonary hypertension are atrial
,17 fibrillation, atrial flutter, and atrioventricular nodal reentrant tachycardia.
LABORATORY TESTING
Routine laboratory testing (e.g., CBC, comprehensive metabolic panel) is nonspecific. Elevations in troponin from myocardial ischemia or a strain­
18­21 induced leak of B­type natriuretic peptide are associated with more serious disease. Elevated liver function tests, lactate, and coagulation panel
 can reflect liver congestion and are a poor prognostic finding.
IMAGING
Common chest radiographic abnormalities associated with pulmonary hypertension include enlargement of the right atrium, RV, and hilar pulmonary
,23 arteries. Depending on the cause, additional radiographic findings might include pulmonary edema, hyperinflation, or interstitial lung disease. In most patients presenting with dyspnea, a chest radiograph may identify other causes of dyspnea, such as pneumonia or pneumothorax.
Transthoracic echocardiography (TTE) is the best initial diagnostic test to assess pulmonary hypertension in the ED. Signs of disease severity include
,4
RV hypertrophy, decreased RV function, and tricuspid regurgitation. Echocardiography detects precipitating factors for RV failure, including
 ventricular regional wall motion abnormalities and acute valvular abnormalities. Additional findings in patients with severe disease include leftward
,25 deviation of the intraventricular septum and an RV­to­left ventricle end­diastolic diameter >1 in the four­chamber view. Figures 58­2, 58­3, and
58­4 demonstrate typical echocardiographic findings in patients with pulmonary hypertension.
FIGURE 58­2. US of elevated right atrial pressures. Inferior vena cava (IVC) and hepatic vein dilation.
FIGURE 58­3. Cardiac US, parasternal short­axis view (PSS), of right ventricle (RV) and left ventricle (LV). Notice the flattening of the interventricular septum occurring in systole, suggesting elevated right ventricular systolic pressures. This is also known as a D­shaped septum. Illustration of normal PSS view in top left corner.
FIGURE 58­4. Apical four­chamber (A4C) view of right ventricle (RV) and left ventricle (LV). The right atrium (RA) and RV are dilated, with RV is dilated with hypertrophy of the RV trabeculae, indicating chronic RV overload. The interventricular septum is shifted toward the LV in systole, suggesting RV pressure overload.
Illustration of normal A4C view in top left corner.
CT pulmonary angiography is the imaging method of choice to evaluate for acute pulmonary embolism (PE). TTE should not be used to exclude acute
 venous thromboembolism (VTE). Given the high risk for VTE in this patient population, obtain a CT angiogram early if an acute PE is suspected, which
,28 also allows RV assessment.
TREATMENT
The mainstays of ED therapy are supplemental oxygen, optimizing intravascular volume, augmenting RV function, maintaining coronary artery
 perfusion, and decreasing RV afterload (Table 58­2).
TABLE 58­2
Pharmacotherapy for Acute Pulmonary Hypertension
Condition Drug Comments
RV failure Dobutamine 2–10 micrograms/kg/min or Avoid >10 micrograms/kg/min
Milrinone .125–0.375 microgram/kg/min Higher doses can cause hypotension
RCA perfusion Norepinephrine .05–0.75 microgram/kg/min Avoid high doses of norepinephrine; avoid dopamine and phenylephrine
RV afterload Inhaled epoprostenol:  nanograms/kg/min Inhaled therapy limits vasodilatory effect to pulmonary circulation.
Inhaled nitric oxide: 20–80 ppm Rarely initiated in ED; obtain consultation
IV prostanoids
Abbreviations: RCA = right coronary artery; RV = right ventricle.
OXYGEN AND MECHANICAL VENTILATION

Consensus opinion is to titrate supplemental oxygen to maintain a level >90% (rather than routinely targeting higher saturations). Although intubation and mechanical ventilation are common ED therapies for the patient with acute respiratory failure, RV failure is often exacerbated by positive­pressure ventilation, with rapid cardiovascular collapse due to increased intrathoracic pressure and reduced coronary perfusion.
If ventilation is needed, set the ventilator to maintain low airway pressure, using lung­protective settings (i.e., a tidal volume of  to  mL/kg of ideal
 body weight and the lowest positive end­expiratory pressure to maintain the oxygen saturation >90%), and target a plateau pressure of <30 cm H O.

Adjust the respiratory rate to avoid hypercapnia, which can increase pulmonary vascular resistance, pulmonary artery pressure, and RV strain.
INTRAVASCULAR VOLUME

Volume overload can cause RV dilation, impaired left ventricular output, and ultimately compromise tissue perfusion. For patients who are
 hypovolemic, fluid challenges with 100­ to 250­mL of isotonic crystalloid is a good first step. Dynamic measures of volume responsiveness may be
 unreliable due to baseline elevations in right­sided pressures. Eventually, diuresis may be accomplished to remove any excess fluid.
RV FUNCTION
For RV failure without hypotension, inotropic therapy to augment contractility and RV afterload can improve cardiac output. Dobutamine (a β

,32,33 agonist) is preferred, starting at  micrograms/kg/min and titrated to  micrograms/kg/min. Higher doses of dobutamine can cause
,35  tachydysrhythmias and hypotension. For patients unable to tolerate dobutamine, milrinone, a phosphodiesterase­3 inhibitor, is an option.
Initiate milrinone at .125 microgram/kg/min and titrate to a maximum of .75 microgram/kg/min. Higher doses of milrinone can cause hypotension and require cardiac output monitoring for titration.
RIGHT CORONARY ARTERY PERFUSION
Adequate perfusion of the right coronary artery is necessary to maintain RV function. To maintain right coronary artery blood flow, arterial pressure at the aortic root must be higher than the pulmonary artery pressure. For the hypotensive pulmonary hypertension patient, initiate vasopressor therapy.

Although there are limited data regarding a singular superior agent, most experts recommend norepinephrine, aiming to improve cardiac output, initiated at a dose of .05 microgram/kg/min. Avoid high doses of norepinephrine, which may increase pulmonary vascular resistance and impair RV output. Avoid dopamine, which can cause tachydysrhythmias, and avoid phenylephrine, which may provide less benefit compared to
 norephinephrine.
RV AFTERLOAD
Patients with chronic pulmonary hypertension may be prescribed pulmonary vasodilators as outpatients. Such agents are rarely initiated in the ED.
The most commonly prescribed outpatient pulmonary vasodilators are prostanoids, endothelin receptor antagonists, and phosphodiesterase­5 inhibitors (Table 58­3).
TABLE 58­3
Commonly Prescribed Outpatient Pulmonary Vasodilators
Prostanoids Potent vasodilators, antiplatelet and antiproliferative properties
Epoprostenol 2­ to 5­min half­life; is provided by continuous IV infusion29,37,38
Can be administered in aerosolized form for acute pulmonary hypertension with RV failure
Treprostinil IV and SC administration; 4­ to 5­h half­life; not for acute RV failure
Iloprost Aerosol; use if unable to tolerate parenteral prostanoid as outpatient therapy29
Not for acute RV failure
Endothelin receptor antagonists1,39­43 Elevated transaminase levels and decrease in hemoglobin1
Bosentan Oral agents; not for acute RV failure29
Ambrisentan
Phosphodiesterase­5 inhibitors1,44­49 Headache, flushing, dyspepsia, hypotension when used with nitrates1
Sildenafil Oral agents; not for acute RV failure
Tadalafil
Abbreviation: RV = right ventricle.
For the acutely ill patient receiving outpatient IV prostanoid therapy, restart the home infusion quickly. The first step is to confirm patency of the home
IV catheter and check for proper infusion pump function. If occlusion or malfunction is detected, immediately restart the homeadministered prostanoid through a peripheral IV.
If initiating pulmonary vasodilator therapy for acute exacerbations of pulmonary hypertension with RV failure, inhaled therapy with epoprostenol or nitric oxide therapy can be administered by facemask, high­flow nasal cannula, or endotracheal tube to reduce RV afterload and improve patient
 hemodynamics. Initiation of IV pulmonary vasodilators is not recommended in the acutely ill patient.
DISPOSITION AND FOLLOW­UP
When patients with pulmonary hypertension present to an ED, they are often critically ill and with evidence of acute right heart failure. Nearly all require admission, often to an intensive care or coronary care unit with expertise in pulmonary hypertension. On rare occasions, a mildly symptomatic patient may be discharged home after consultation, care plan development, and close follow­up with the primary provider.


