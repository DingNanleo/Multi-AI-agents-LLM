## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 237: Acquired Hemolytic Anemia
Laurie Ann Dixon; Robin R. Hemphill
INTRODUCTION
Acquired hemolytic anemias are disorders characterized by hemolysis of red blood cells (RBCs) not due to congenital or inherited disorders of hemoglobin synthesis or of the RBC membrane. Hemolysis of RBCs can take place within the intravascular space or in the extravascular spaces of the spleen and liver and can produce a spectrum of disease from mild, asymptomatic illness to severe hemodynamic compromise leading to critical ED encounters.
Clinical features of hemolytic anemia include those common to anemia in general: weakness, dizziness, shortness of breath, tachycardia, palpitations, chest pain, new or accentuated cardiac murmur, and pallor. RBC destruction generates free hemoglobin that is then broken down into bilirubin.
Jaundice and darkened urine may develop when bilirubin production exceeds the liver’s ability to conjugate it for biliary and fecal excretion. Splenic enlargement may promote the storage and extravascular breakdown of RBCs.
Characteristic laboratory findings of acquired hemolytic anemia demonstrate hemolysis of RBCs, hemoglobin breakdown, and compensatory RBC production (Table 237­1).
TABLE 237­1
Basic Tests and Findings in the Evaluation of Hemolytic Anemia
Purpose Test Finding
Confirm anemia/blood loss Hemoglobin Decreased
Hematocrit Decreased
Confirm compensatory RBC Reticulocyte count Increased production
Confirm hemolysis Peripheral smear Spherocytes—extravascular hemolysis, RBC phagocytosis by macrophages
Schistocytes—intravascular hemolysis, RBCs fragmented by shear mechanism
Confirm hemolysis Lactate dehydrogenase Increased, released by RBCs
Confirm hemolysis Haptoglobin Decreased, indicative of intravascular hemolysis
Free hemoglobin Increased, indicative of intravascular hemolysis
Hemoglobinuria Present
Confirm hemoglobin breakdown Total bilirubin Increased
Indirect (unconjugated) Increased (hepatic conjugation of bilirubin overwhelmed)
 bilirubin
Chapter 237: Acquired Hemolytic Anemia, Laurie Ann Dixon; Robin R. Hemphill 
. Terms of Use * Privacy Policy * Notice * Accessibility
Urinary urobilinogen Increased
Abbreviation: RBC = red blood cell.
IMMUNE­MEDIATED ACQUIRED HEMOLYTIC ANEMIA
Immune­mediated acquired hemolytic anemia encompasses three main categories: autoimmune, alloimmune, and drug induced.
AUTOIMMUNE HEMOLYTIC ANEMIA
,2
Individuals with autoimmune hemolytic anemia make antibodies against their own RBCs. Diagnosis requires evidence of an antibody on the patient’s
RBCs, usually accompanied by an autoantibody in the plasma. The direct antigen test, also known as the direct Coombs test, is performed by combining the patient’s anticoagulated, washed RBCs with anti–immunoglobulin G and anti­C3d (complement) antibodies to detect the presence of immunoglobulin G and/or complement on the RBC surface. A positive direct antigen test consists of the detection of either immunoglobulin G or complement on the RBC surface; it does not require the detection of both. A positive direct antigen test is not specific for a diagnosis of autoimmune hemolytic anemia (Table 237­2), nor does the presence of immunoglobulin G and/or complement on a patient’s RBCs indicate the severity of disease; the direct antigen test is, however, a critical confirmatory screen. The indirect Coombs test looks for the presence of autoantibodies in the patient’s serum, testing against a panel of RBCs bearing specific surface antigens.
TABLE 237­2
Differential Diagnosis of Positive Direct Antigen (Direct Coombs) Test
Autoimmune hemolytic anemia
Hemolytic transfusion reaction, acute or delayed
Hemolytic disease of newborn
Transplantation
Drug­related hemolytic anemia
IV immunoglobulin therapy
Rh(D) immunoglobulin therapy
Antilymphocyte globulin therapy
Antithymocyte globulin therapy
Sickle cell disease
β­Thalassemia
Renal disease
Multiple myeloma
Hodgkin’s disease
Systemic lupus erythematosus
Human immunodeficiency virus/acquired immunodeficiency syndrome

Autoimmune hemolytic anemia can be categorized into primary and secondary disease. Primary, or idiopathic, disease occurs without a known underlying etiology, whereas secondary disease is associated with an underlying disorder. Many cases initially designated as primary are later found to be associated with lymphoproliferative, autoimmune, or infectious diseases. Autoimmune hemolytic anemia is further divided into autoantibody type:
 warm type, cold type, and mixed type (Table 237­3).
TABLE 237­3
Categories of Autoimmune Hemolytic Anemia (AIHA)
Warm antibody AIHA: Autoantibodies adhere most strongly to RBCs at 37°C 65%–70% of AIHA cases
(98.6°F). 2:1 female predominance
50% primary (idiopathic) disease
50% secondary disease: lymphoproliferative, autoimmune disease, postinfection (transient)
Usually immunoglobulin G (IgG) autoantibody against Rh(D) antigen
Hemolysis usually extravascular
Steroid responsive: 70%–80%
Cold antibody AIHA: Autoantibodies adhere most strongly to RBCs at 0–4°C 20%–25% of AIHA cases
(32–39.2°F). Cold agglutinin disease: IgM autoantibody against I antigen
Primary disease: older females
Secondary disease: lymphoproliferative disorders, postinfection
(transient)
Raynaud’s phenomenon, livedo reticularis, vascular occlusion
Attacks precipitated by cold exposure
Rarely intravascular hemolysis
Not steroid responsive
Paroxysmal cold hemoglobinuria: IgG autoantibody against P antigen
Primary disease: rare, in adults
Secondary disease: usually in children after upper respiratory infection
Intravascular hemolysis during cold weather
Usually not steroid responsive
Mixed­type antibody AIHA: Autoantibodies have variable temperature­ 5%–10% of AIHA cases dependent RBC adherence. Primary disease: more common in older females
Secondary disease: lymphoproliferative and autoimmune disorders
Usually chronic course with severe exacerbations
Usually steroid responsive
Abbreviation: RBC = red blood cell.
Warm Antibody Autoimmune Hemolytic Anemia
Warm autoantibody–mediated hemolysis is predominantly extravascular, with antibody­coated RBCs consumed mostly by splenic macrophages and,
,4 to a lesser degree, by hepatic macrophages known as Kupffer cells. Partial phagocytosis of the original RBC membrane structure leads to the formation of the more rigid, fragmentation­prone spherocyte. Increased spherocytosis found on peripheral blood smear correlates positively with severity of extravascular hemolysis.
Warm antibody autoimmune hemolytic anemia is initially treated with high­dose corticosteroids, typically oral prednisone,  to .5 milligrams/kg per day for  to  weeks, followed by lower doses for  to  months. Improvement is expected in 80% to 85% of patients, but complete remission occurs in
 only approximately 30% of patients.
Monoclonal antibodies (e.g., rituximab) or immunosuppressive agents (e.g., azathioprine, mycophenolate mofetil, cyclosporine, cyclophosphamide)
,3 are used to decrease autoantibody production. Splenectomy removes both the main site of extravascular hemolysis in IgG­mediated disease and a major site of general autoantibody production, with clinical benefit in up to 60% of patients and potential for long­term remission or a complete cure.
,6
A serious complication of splenectomy is overwhelmingpostsplenectomy infection due to encapsulated bacteria. Prevention strategies include pneumococcal and meningococcal vaccinations and daily penicillin prophylaxis for the first few years after splenectomy. Overwhelming
 postsplenectomy infection should be treated early, often when symptoms and findings are mild, with both vancomycin and ceftriaxone IV.
Severe hemolysis in cases of warm antibody autoimmune hemolytic anemia may be treated with plasma exchange as a transient stabilizing measure while waiting for steroids or immunosuppressive agents to take effect.
For a patient with life­threatening anemia, the goal is to transfuse allogeneic RBCs without producing potentially harmful transfusion reactions. To find compatible RBCs for transfusion, laboratory personnel must determine whether the patient’s blood contains both alloantibodies (directed to antigens
,9 not present on the patient’s RBCs) and autoantibodies (targeted to commonly occurring antigens present on the patient’s RBCs). The testing process can be both labor and time intensive, sometimes requiring  hours or longer. Once completed, antigen­free, compatible RBC units are the best approach for safe and effective transfusion. If emergently needed, transfusion of the least incompatible units may be administered slowly and in the
 smallest amounts necessary with close monitoring.
Cold Antibody Autoimmune Hemolytic Anemia
,2
Cold autoantibodies lead to clumping or agglutination of RBCs on peripheral smear at cooler temperatures. Cold antibody autoimmune hemolytic anemia is associated with complement fixation on the RBC surface and triggering of the complement cascade. Hemolysis occurs in both the extravascular and intravascular spaces. Instead of splenic macrophages, the hepatic macrophages known as Kupffer cells are responsible for most of the extravascular RBC destruction. The two major cold antibody disorders are cold agglutinin disease and paroxysmal cold hemoglobinuria.
Fifty percent of secondary cold antibody cases are associated with lymphoproliferative disorders, with underlying infection as the next leading cause.

Cold agglutinin disease is exacerbated by the cold, so more episodes of acute hemolysis are seen during winter. Because the peripheral circulation is typically cooler than the central circulation, secondary Raynaud’s phenomenon and vascular occlusion can complicate cold agglutinin
 disease, leading to acrocyanosis and tissue necrosis/gangrene. Painful discoloration and mottling of the skin (termed livedo reticularis) may be
 seen. Primary cold agglutinin disease causes chronic, recurrent hemolysis in older adults, particularly females, with a peak incidence at age  years.
As with all of the idiopathic autoimmune hemolytic anemias, an associated underlying disease process may be discovered well after initial presentation of cold agglutinin disease; in particular, an occult lymphoproliferative disorder may be the source of the aberrant cold autoantibodies.
Secondary cold agglutinin disease may present after infection with Mycoplasma pneumoniae, Epstein­Barr virus, infectious mononucleosis, adenovirus, cytomegalovirus, influenza, varicella­zoster virus, human immunodeficiency virus, Escherichia coli, Listeria monocytogenes, or
Treponema pallidum. Hemolysis typically begins  to  weeks after the onset of illness, corresponding with peak antibody development against the infectious agent, and resolves about  to  weeks after resolution of the infectious illness. Many patients with Mycoplasma pneumonia and infectious mononucleosis will have measurable cold agglutinin titers, but far fewer will develop symptomatic hemolytic anemia. Conversely, cold agglutinin disease associated with lymphoproliferative diseases such as chronic lymphocytic leukemia and lymphoma produces high autoantibody levels with potential for significant hemolysis.
An important principle in treating cold agglutinin disease is keeping the extremities and appendages, particularly the nose and ears, warm in cold weather. Patients should take a daily folate supplement for healthy RBC production. Cold agglutinin disease is less likely to respond to steroids, with
 response rates as low as 35%. Splenectomy is less effective in treating cold agglutinin disease because splenic macrophages play a lesser role in IgM­ mediated cold antibody disease. Severe hemolysis has been treated successfully with immunosuppressive agents such as chlorambucil,
,14 cyclophosphamide, interferon­α, fludarabine, or rituximab. Because immunoglobulin M autoantibodies have an intravascular distribution, plasmapheresis may assist by removing autoantibodies from the circulation when combined with immunosuppressive agents. Infection­related cold antibody disease does not require therapy because the hemolytic anemia is usually self­limited.
If RBC transfusion is necessary, transfused blood should be infused at 37°C (98.6°F) using a blood warmer. Transfusions should be limited as they may worsen ongoing hemolysis because most cold antibodies act against the I/i group antigens found on most donor RBCs. Donor complement in the transfused product also may exacerbate ongoing hemolysis.
Paroxysmal cold hemoglobinuria is caused by a biphasic hemolysin immunoglobulin G autoantibody called the Donath­Landsteiner (D­L)
 antibody that is directed against the P antigen system found on most RBCs. This potent autoantibody binds to RBCs and fixes early complement cascade proteins at low temperatures, whereas terminal complement components adhere and produce intravascular lysis of RBCs at warmer, physiologic temperatures.
Bursts of cold weather–induced intravascular hemolysis lead to bouts of dark urine or hemoglobinuria for which the disease is named. Other presenting symptoms include attacks of high fever, chills, headache, abdominal cramps, nausea and vomiting, diarrhea, and leg and back pain, all exacerbated by cold weather. Cold urticaria may develop, as well as extremity paresthesias and Raynaud’s phenomenon.
Primary paroxysmal cold hemoglobinuria is a rare, idiopathic, chronic condition occurring in adults, characterized by cold­induced episodes of massive hemolysis. Secondary disease occurs predominantly in children, usually seen after a preceding infection with adenovirus, influenza A, measles, mumps, Epstein­Barr virus, cytomegalovirus, varicella, M. pneumoniae, Haemophilus influenzae, or E. coli. Most pediatric cases are selflimited and nonrecurring, but severe cases may take weeks to resolve. With severe hemolysis, hemoglobinuria is common, and methemoglobinemia may be seen. Acute renal failure may develop as a complication. Adult patients with chronic, relapsing disease should be tested for syphilis, because cold­provoked hemolysis has been associated with tertiary or late syphilis as well as with congenital syphilis.
Patients with paroxysmal cold hemoglobinuria should be kept warm. Steroids can be considered in children with severe hemolytic anemia, but because infection­related disease tends to be self­limited, benefit is uncertain. Disease secondary to syphilis responds to effective antibiotic treatment.
Splenectomy is not helpful, and plasmapheresis should be used only as a temporizing measure in life­threatening cases. RBC transfusion using a blood warmer should be limited to cases of severe anemia because most donor units are P antigen positive and may stimulate further production of antibodies.
Mixed Antibody Autoimmune Hemolytic Anemia
Mixed­type autoimmune hemolytic anemia, with both warm and cold autoantibodies to RBCs, presents as either primary or secondary disease, with the
,2 latter most commonly associated with lymphoproliferative and autoimmune diseases, particularly systemic lupus. The course of illness is usually chronic with severe exacerbations. Like the warm antibody disorder, the mixed type is usually steroid responsive, can be treated with splenectomy, and responds to immunosuppressive therapy.
ALLOIMMUNE HEMOLYTIC ANEMIA
Alloimmune hemolytic anemia requires exposure to allogeneic RBCs with subsequent alloantibody formation. In the laboratory, alloantibodies react specifically with the allogeneic RBCs that triggered their production and not against a patient’s own RBCs. A well­known example of this is when the Rh(D)­negative maternal immune system develops immunoglobulin G alloantibodies upon exposure to Rh(D)­positive fetal RBCs. The maternal
 alloantibodies can then cross the placenta, leading to fetal RBC destruction in a condition known as hemolytic disease of the newborn. Anemia can range from mild to potentially fatal, producing intrauterine fetal death. The term hydrops fetalis has been used to describe the anasarca seen in severe cases. Transplacental or fetomaternal hemorrhage, the inciting stimulus for maternal alloantibody formation, may occur during amniocentesis, chorionic villus sampling, delivery, or abortion (threatened or otherwise). Administration of anti­D immunoglobulin G following a fetomaternal hemorrhage event and soon after delivery will suppress maternal alloantibody formation and prevent subsequent hemolytic disease of the newborn. Treatment of established hemolytic disease of the newborn employs intrauterine and intravascular fetal transfusion and may include plasma exchange and/or IV immunoglobulin therapy.
Most adults who develop alloimmune hemolytic anemia have a history of RBC transfusion, which sensitizes patients to allogeneic RBC antigens. A subsequent transfusion can result in immediate alloantibody production, resulting in the fever, chest and flank pain, tachypnea, tachycardia, hypotension, hemoglobinuria, and oliguria seen in the hemolytic transfusion reaction (see Chapter 238, “Transfusion Therapy”). In patients with high alloantibody titers, the hemolytic reaction can be immediate. Delayed alloantibody­mediated hemolysis is also possible, with hemolytic transfusion reaction symptoms presenting  to  days after transfusion.
DRUG­INDUCED HEMOLYTIC ANEMIA
Drug­induced hemolytic anemia is rare, estimated at  in ,000,000 patients, where drug exposure induces antibody formation, leading to the
  destruction of RBCs. More than 100 drugs are reported to induce autoantibody production against RBC antigens (Table 237­4). Drug­induced hemolytic anemia can result in either a positive or negative direct antigen test and can be difficult to distinguish from autoimmune hemolytic anemia, so a careful review of current medications is important in patients with a new hemolytic anemia.
TABLE 237­4
Drugs Most Often Cited as Inducing Hemolytic Anemia
Cephalosporins Cefotetan
Ceftriaxone
Cephalothin
Chemotherapeutic agents Fludarabine
Interferon
Oxaliplatin
NSAIDs Diclofenac
Mefenamic acid
Phenacetin
Tolmetin
Penicillins Penicillin G
Piperacillin
Miscellaneous Catechin (antidiarrheal)
Levodopa (antiparkinsonian)
Methyldopa (antihypertensive)
Nomifensine (antidepressant)
Quinidine (antidysrhythmic)
Rifampin (antibiotic)
Stop the potentially offending agent when a drug­induced hemolytic anemia is suspected. Treatment is symptomatic, with carefully screened RBCs transfused as needed. Steroids can be used in cases of drug­related severe hemolysis.
MICROANGIOPATHIC SYNDROMES
The two classic syndromes associated with microangiopathic hemolytic anemia are thrombotic thrombocytopenic purpura (TTP) and hemolytic­
,20 uremic syndrome (HUS). Both syndromes involve platelet aggregation in the microvascular circulation via mediation of von Willebrand factor.
Microangiopathic hemolytic anemia or schistocyte­forming hemolysis occurs from fragmentation of RBCs during travel through these partially occluded arterioles and capillaries. Although TTP and HUS are clinical syndromes with characteristic features, overlap does occur, sometimes making differentiation difficult. TTP is more common in adults and induces more prominent neurologic effects, whereas HUS is more common in children with greater impairment on the renal system.
THROMBOTIC THROMBOCYTOPENIC PURPURA
The classic pentad for TTP includes CNS abnormalities, renal pathology, fever, microangiopathic hemolytic anemia, and thrombocytopenia. Untreated TTP carries a high mortality rate, but plasma exchange therapy can achieve remission of disease in >80% of
20­22 patients.
Pathophysiology
The pathophysiology of TTP is connected to a specific metalloprotease ADAMTS­13 (adisintegrin and metalloproteinase with a thrombospondin type  motif, member , also known as von Willebrand factor–cleaving protease). ADAMTS­13 is made by hepatic stellate cells, glomerular podocytes, and vascular endothelial cells. Its function is to cleave von Willebrand factor that has been unfolded by shear stress within the microvasculature of arterioles and capillaries. Without this cleavage function, unfolded von Willebrand factor monomers can form large multimers that lead to formation
 of intravascular microthrombi. TTP has been associated with ADAMTS­13 activity at levels <10% of normal. However, severely deficient ADAMTS­13 activity alone does not reliably trigger TTP; often other precipitating or contributing factors are important, including pregnancy, infection, inflammation, and medication use.

ADAMTS­13 activity levels typically decrease by up to 30% during pregnancy, although not usually to the severely low levels associated with TTP. It is hypothesized that the hypercoagulable state of pregnancy combined with the decreased ADAMTS­13 activity level may set the stage for TTP in pregnancy. TTP shares many clinical and laboratory features with preeclampsia–eclampsia, HELLP syndrome (hemolysis, elevated liver enzymes, low platelet count), and acute fatty liver of pregnancy (see Chapter 100, “Material Emergencies After  Weeks of Pregnancy and in the Peripartum Period”),
,24 but symptoms of severe preeclampsia or HELLP syndrome before  weeks of gestation should raise suspicion for TTP.
Human immunodeficiency virus infection, particularly with progression to acquired immunodeficiency syndrome, is associated with microangiopathic
 anemia and thrombocytopenia. Influenza vaccination has been implicated as a TTP trigger, leading to production of autoantibody against ADAMTS­

. Acute pancreatitis, capable of inducing a systemic inflammatory response, has also been associated with TTP, although moderately rather than
,28 severely low ADAMTS­13 activity levels lead to uncertainty about a TTP diagnosis versus some other thrombotic microangiopathic process.
Drugs associated with TTP include ciprofloxacin, ofloxacin, levofloxacin, quinine, sirolimus (when used with calcineurin inhibitors such as
 cyclosporine), risperidone, clopidogrel, lansoprazole, valacyclovir, mitomycin, infliximab, and ticlopidine. Ticlopidine in particular is thought to induce autoantibody formation against ADAMTS­13 as well as microvascular endothelial cell injury in genetically susceptible individuals within  to  weeks of starting the medication. Ticlopidine has been associated with more severe thrombocytopenia and microangiopathic hemolysis than
 clopidogrel, whereas clopidogrel has produced more significant renal insufficiency not readily responsive to plasma exchange therapy. Days to weeks may be required to achieve remission in ticlopidine­ or clopidogrel­associated TTP cases.
Clinical Features
Shearing of RBCs across these microthrombi produces the microangiopathic hemolytic anemia. Platelet aggregation in TTP leads to systemic platelet depletion or thrombocytopenia. When these microthrombi are concentrated in the CNS and renal arterioles and capillaries (though notably not found in venules), they promote tissue ischemia and necrosis, with resultant end­organ damage such as seizure, stroke, other focal neurologic deficits, coma, and acute renal injury.

Along with findings of severe anemia and thrombocytopenia of <20,000/mm (<20 ×  /L), serum and urine tests may corroborate ongoing intravascular hemolysis (Table 237­1) with renal injury or failure. Because TTP thrombi do not incorporate fibrin, TTP can be distinguished from
 disseminated intravascular coagulation by normal coagulation studies.
Treatment
,21
Plasma exchange therapy is very effective in TTP with the goal to achieve a normal platelet count. Daily plasmapheresis (plasma exchange) of  mL/kg or up to .0 to .5 times a patient’s plasma volume is performed and then either weaned in frequency or stopped once normal platelet counts are reached for  to  consecutive days. Infusion of donor plasma replaces defective or insufficient ADAMTS­13, and removal of the patient’s plasma rids the body of defect ADAMTS­13, autoantibodies, and large von Willebrand factor multimers.

If plasmapheresis cannot be performed immediately, fresh frozen plasma infusion can be initiated, with pheresis occurring later. Infusion with factor
VIII concentrate containing ADAMTS­13 activity can be considered for patients with plasma allergy after specialist consultation and review.
Severe TTP may require additional interventions such as RBC transfusion, anticonvulsants, antihypertensives, and hemodialysis. Avoid platelet transfusions, except in life­threatening bleeding or intracranial hemorrhage, because acutely worsened thrombosis can lead to renal failure and, potentially, death. Aspirin can exacerbate hemorrhagic complications in the setting of severe thrombocytopenia, but can still be used for cerebrovascular and cardiovascular indications in patients with adequate platelet counts. Heparin is not beneficial in TTP. Corticosteroids, rituximab,
,21 and cyclosporine may be used in the treatment of autoimmune TTP. Discontinue the inciting drug in all cases of drug­associated TTP.
Outcome
TTP relapse, defined as a new case onset >30 days after completion of remission­achieving plasma exchange therapy, is seen in 20% to 50% of cases,
 most often within  years after the initial episode. Patients with ADAMTS­13 activity levels <10% are at increased risk for relapse. Triggers for relapse may be the same as those inciting original cases. Relapses may present with milder symptoms and less severe hematologic findings. Patients with multiple relapses may experience them farther and farther apart, and total volume and duration requirements for plasma exchange therapy are
 lessened in subsequent cases.
The maternal mortality rate from TTP has been reduced significantly with the use of plasma exchange therapy, but fetal mortality has remained high secondary to placental microvascular occlusion, ischemia, and infarction. TTP may relapse with subsequent pregnancy, so affected women should be
 counseled accordingly.
HEMOLYTIC­UREMIC SYNDROME
HUS, a common cause of acute renal failure in childhood, consists of microangiopathic hemolytic anemia, acute nephropathy or renal
,20,32  failure, and thrombocytopenia. HUS can be classified as typical or atypical, with prognosis favoring typical cases.
Typical HUS (>90% of cases) occurs in children, usually between age  and  years, presenting about  week into a case of infectious diarrhea that is often bloody and without associated fever. The causative agent of typical HUS is Shiga toxin (alternatively verocytotoxin)–producing E. coli, with
,33 serotype O157:H7 predominating in North America. Other less common causes of diarrhea­associated HUS include Shigella, Yersinia,
Campylobacter, and Salmonella. A variety of both fresh and processed foods have been implicated in E. coli O157:H7 infection outbreaks, with HUS
 occurring as a complication in each of the outbreaks.
Atypical HUS (5% to 10% of cases) occurs in older children and adults and may be difficult to distinguish from TTP because of extrarenal involvement.
Atypical HUS is associated with other infectious organisms, such as Streptococcus pneumoniae and Epstein­Barr virus, or it may have a noninfectious
 cause, such as bone marrow transplantation or the administration of immunosuppressant or chemotherapeutic agents.
Pathophysiology
Shiga toxin–producing E. coli O157:H7 possesses potent virulence factors that allow invasion of intestinal epithelial cells and subsequent transmural
 intestinal migration. The ensuing colonic inflammation produces the characteristic hemorrhagic colitis associated with E. coli O157:H7 and other
Shiga toxin–producing bacteria. Shiga toxin, once absorbed into the systemic circulation, binds with greatest affinity to receptors found on the surfaces of glomerular and renal tubular epithelial and endothelial cells and, to a lesser extent, to receptors lining cerebral and colonic epithelial and endothelial cells and pancreas. Molecular mimicry may exist between human CD36, an antigen found on endothelial cells and platelets, and Shiga
 toxin, so that antibody formed against the toxin may bind to CD36 and incite the pathologic processes leading to HUS.
Toxin­mediated microvascular injury promotes platelet aggregation (and therefore, systemic depletion, leading to thrombocytopenia), thrombus formation at the injury site, and shearing of RBCs, contributing to tissue ischemia and necrosis. Microthrombi within the pancreas have been postulated to cause pancreatic β­cell death and subsequent deficits in insulin secretion. Thus, patients with HUS may present with hyperglycemia consistent with new­onset diabetes mellitus. Some may even go on to have chronic insulin requirements with increased morbidity and mortality
 rates.
Clinical Features
HUS typically presents  to  days after diarrhea develops, so patients may present during the diarrheal illness phase, with abdominal cramps, with or without bloody diarrhea, and often without fever. For the patient with nonbloody diarrhea, testing stool for fecal leukocytes can reveal occult
 inflammatory colitis, thereby prompting stool culture, specifically for E. coli O157:H7. For the patient with bloody diarrhea, the results of stool testing for Shiga toxin–producing bacteria, including E. coli O157:H7, can guide medical treatment, alert providers that the complication of HUS should be anticipated, and aid in the cause of public health disease monitoring and outbreak prevention. In addition to the studies required for diagnosing hemolytic anemia, electrolyte and renal function panels should be obtained to detect nephropathy and associated electrolyte disturbances, whereas
 urinalysis should be examined for RBCs, RBC casts, protein, and other evidence of acute nephropathy.
Treatment
,37
Typical HUS is treated with supportive care, with focus on hydration and RBC transfusion for significant anemia. Hemodialysis may be required should acute renal failure develop. Infection with E. coli O157:H7 should not be treated with antimotility drugs because these agents appear to increase
 the risk of developing HUS. Use of antibiotics for the treatment of E. coli O157:H7 diarrhea is controversial because in vitro studies have found that antibiotics may increase Shiga toxin expression from the bacteria, and case­control human studies have found that antibiotic treatment of the
,38  diarrheal illness may increase the risk of developing HUS. Atypical HUS is treated with eculizumab.
Outcome

Acute renal failure occurs in 55% to 70% of patients with typical HUS, but most patients, up to 85%, recover kidney function. The mortality rate in typical HUS is about 5% to 15%. Historically, patients with atypical HUS had a poor outcome, with permanent renal failure or neurologic damage occurring in about half of patients and a morality rate approaching 25%. Aggressive treatment, including eculizumab, appears to significantly reduce
 the incidence of permanent renal failure and lower the death rate in atypical HUS.
MACROVASCULAR HEMOLYSIS
A prosthetic heart valve may create turbulent blood flow with high shear stress across the valve. Older­generation mechanical heart valves were subject to deterioration that produced subsequent hemolysis, but hemolysis associated with current prosthetic heart valve models is most often attributed to paravalvular leak. Such leaks may occur at the time of valve placement or develop later in the life of the prosthetic valve if infection or
 calcification promotes dehiscence. Particularly after mitral valve replacement, hemolysis may occur at both clinically insignificant and significant levels.
Macrovascular hemolysis can also occur after intracardiac patch repair or aortofemoral bypass; in patients with coarctation of the aorta, severe aortic valve disease, or ventricular assist devices; and in patients requiring the use of extracorporeal circulation such as during
,42 cardiopulmonary bypass, plasma exchange, or hemodialysis. Mechanical sheer stress, chemical contaminant, and exposure to dialysis membranes
 are all factors contributing to hemolysis risk during hemodialysis, although technologic advances have made these events rare.
Patients with ongoing mild macrovascular hemolysis should receive supplemental iron and folate to promote healthy reticulocytosis. By reducing the heart rate, β­blocker therapy may decrease RBC shear stress in the presence of a prosthetic valve and thereby mitigate hemolysis. Pentoxifylline, a xanthine derivative that reduces blood viscosity and improves RBC flexibility and deformability, can reduce hemolysis associated with prosthetic heart
 valves. Hemolysis associated with extracorporeal circulation typically begins during the procedure, but such patients may or may not exhibit symptoms until hours afterward.
ADDITIONAL CAUSES OF HEMOLYSIS
Infection, envenomation, chemical exposure, and trauma can also result in hemolysis (Table 237­5).
TABLE 237­5
Additional Causes of Hemolysis
Cause Disorder Comments
Infection
Malaria Protozoan infects and damages RBCs, producing “blackwater fever” or hemoglobinuria
Babesiosis Protozoan infects and damages the RBC
Clostridium perfringens Toxin lyses RBCs
Leptospirosis Weil’s syndrome; toxin lyses RBCs
Envenomation
Hymenoptera stings Requires massive venom injection
Brown recluse spider Part of systemic loxoscelism
Pit viper; Crotalinae; Elapidae; Intravascular RBC destruction
Viperinae
Chemical exposure
Arsine Hemolysis can present  h after exposure43,44
Naphthalene Mothballs; well water contaminated by toxic dumps; can affect fetus in utero and neonates; patients with
G6PD deficiency at higher risk
Direct impact trauma
March hemoglobinuria Runners, soldiers, karate, conga drummers45; hemoglobinuria but usually not anemia45­47
Abbreviations: G6PD = glucose­6­phosphate dehydrogenase; RBC = red blood cell.


