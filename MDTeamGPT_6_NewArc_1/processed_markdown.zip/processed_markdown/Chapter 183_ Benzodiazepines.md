## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 183: Benzodiazepines
Dan Quan
INTRODUCTION
Benzodiazepines, to varying degrees, have in common six major pharmacologic effects: sedative, hypnotic, anxiolytic, amnestic, anticonvulsant, and
 muscle relaxant. Benzodiazepines are commonly used for the short­term treatment of anxiety, insomnia, seizures, and withdrawal from alcohol or
2­5 ,7 sedative­hypnotic agents. The long­term benefits of benzodiazepines for psychiatric disorders are controversial. Midazolam, a benzodiazepine with a short duration of action, is also used for procedural sedation and general anesthesia (Table 183­1).
TABLE 183­1
Benzodiazepines
Elimination
Time to Peak Duration of Active Metabolite Oral Dose Equivalents in Milligrams
Generic Name Half­Life
Effect (hours)† Action (hours) Half­Life (hours) to Diazepam  Milligrams
‡
(hours)
Short Acting
Alprazolam* 1–2 6–12 4­7 No .5
Midazolam* IV 1–2 min 3–6 IV  Yes 
IM 10–15 min IM 4–6
PO .5–1 PO 4–6
Oxazepam* .3–0.5 5–10 3–6 No 
Tetrazepam 1–3  6–8 No 50–100
Triazolam* .25–0.5 2–5 6–7 No .25–0.50
Intermediate Acting
Bromazepam 1–3 10–20 <12 Yes 5–6
Cinolazepam .5–2   No 
Estazolam*  10–24 <12 No 1–2
Flunitrazepam .25–0.3 18–24 4–6 Yes (36–200) 
Loprazolam .5–4 6–12 <12 No 1–2
Lorazepam* IV 5–20 min 9–16 6–8 No 
IM 20–30 min

PO .5–1
Chapter 183: Benzodiazepines, Dan Quan 
. Terms of Use * Privacy Policy * Notice * Accessibility
Lormetazepam .5–2 10–12 <12 No 1–2
Nimetazepam .25–0.5 14–30 <12 No 
Nitrazepam .5–5 16–48 <12 No 
Premazepam  10–13 <12 No .75
Temazepam* .5 9–12 5–20 No 
Long Acting
Chlordiazepoxide*  5–30 5–30 Yes (36–200) 
Clonazepam* .3–0.5 20–80 <12 No .5
Clorazepate* 1–2  8–24 Yes (36–200) 
Cloxazolam 2–5  18–50 No 1–2
Diazepam* IV 1–5 min 20–50 IV .25–1 Yes (36–200) 
PO 15–45 min PO 12–24
PR 5–45 min
Flurazepam* .5–1   Yes (50–100) 15–30
Flutoprazepam .5–2 60–90  Yes 2–3
Halazepam 1–3 — 12–24 Yes (30–100) 20–40
Ketazolam .5–3 30–100 12–24 Yes (36–200) 15–30
Medazepam — 36–150 10–12 Yes (36–200) 
Nordazepam  40–50 12–14 Yes (50–120) 
Phenazepam .5–4   Yes 
Pinazepam 1–2 20–25 12–24 Yes (40–100) 
Prazepam 2–6 40–80 12–24 Yes (36–200) 10–20
Quazepam* .5–2 27–41 12–24 Yes (28–80) 
*Available in the United States.
†After oral ingestion, unless otherwise specified.
‡
Parent compound.

Isolated benzodiazepine overdose has low mortality, and death is rare. However, increased rates of morbidity do result from mixed overdose, especially in combination with opioids. Isolated overdose with high­potency short­acting agents, such as alprazolam, temazepam, and triazolam, is associated with higher incidences of intensive care unit admissions, coma, and mechanical ventilation with toxicity
 compared to other benzodiazepines, such as diazepam. A review of suicide by self­poisoning found that temazepam was  times more toxic

(fatal toxicity index) and  times more lethal (case fatality index) than diazepam. In the ED, parenteral administration of benzodiazepines may result in significant complications, particularly respiratory depression and hypotension, especially when combined with opioids or other sedatives.
PHARMACOLOGY
Benzodiazepines stimulate the α subunit of the postsynaptic γ­aminobutyric acid (GABA ) receptor in the CNS. Stimulation of this receptor affects the
A ligand­gated chloride channel on the cell membrane, altering the transmembrane resting potential to below stimulation threshold and rendering the postsynaptic neuron less excitable. Stimulation of this GABA receptor leads to inhibitory effects throughout the neuraxis, producing the typical
A clinical effects of sedation, anxiolysis, anticonvulsant activity, and striated muscle relaxation.
In general, benzodiazepines are well absorbed from the GI tract. The onset of action after oral ingestion is limited more by the rate of absorption from the GI tract than by the relatively rapid passage from the bloodstream into the brain. With the exception of lorazepam and midazolam, IM injection of benzodiazepines results in unpredictable absorption. IV administration of midazolam and lorazepam has an onset of action in  to  minutes.
Diazepam may be administered rectally, and midazolam may be administered intranasally or intrabuccally, with variable rates of absorption by those routes.
Benzodiazepines are relatively lipid soluble, with some variation among the agents. Increased lipid solubility is associated with more rapid diffusion across the blood–brain barrier. After single doses, the more highly lipophilic benzodiazepines have a shorter onset of action but also a shorter duration of activity. This short duration of activity occurs because of rapid egress of the drug from the brain and bloodstream into inactive tissue storage sites. For this reason, the serum half­life is not a good indicator of the duration of action in an acute ingestion.
Benzodiazepine derivatives undergo hepatic metabolism through different pathways depending on the agent. Hepatic biotransformation occurs through either oxidation or conjugation; both pathways may be used by some derivatives. Oxidation often produces active metabolites that prolong the pharmacologic effects of the parent compounds. Oxidation is more susceptible to impairment by such factors as disease states (chronic liver disease), demographic characteristics (advanced age), and concurrent treatment with drugs that affect metabolism (estrogen, isoniazid, ethanol, ketoconazole, cimetidine, and phenytoin). Conjugation is a rapid process that generally produces inactive metabolites. Examples of agents that undergo conjugation primarily include lorazepam, oxazepam, and temazepam. These agents may be safer in susceptible groups such as patients with hepatic dysfunction.
11­13
There is conflicting evidence on how benzodiazepines affect fetal development. In general, cohort studies have not found an increase in congenital malformations, whereas case­control studies show a small increase (especially for cleft lip and palate). This difference is ascribed to the higher sensitivity of case­control studies in identifying an association with specific conditions. The effect on fetal outcome of large doses of benzodiazepines taken for suicide attempts by pregnant women is not clear. Retrospective reviews of overdose with four different benzodiazepines,
14­18 albeit with relatively small numbers, did not find an increased incidence of congenital abnormalities in the offspring. Nearly all benzodiazepines
,12 enter breast milk, and therefore, caution should be exercised in patients taking benzodiazepines.
Administration of benzodiazepines in the elderly or in patients with comorbid conditions (such as hepatic dysfunction) may be associated with more complications. Those with hepatic dysfunction can have impaired metabolism, causing increased clinical effects. Elderly patients taking
,19 benzodiazepines are at increased risk for falls, cognitive impairment, delirium, fractures, and motor vehicle accidents.
Drug–drug interactions with benzodiazepines occur mainly with drugs that affect the cytochrome P450 pathway, specifically CYP3A4 and CYP2C19. For example, drugs such as ketoconazole or cimetidine are CYP3A4 inhibitors and may increase benzodiazepine blood levels, increasing their duration of action and/or clinical effect. Benzodiazepines themselves have not been implicated in affecting cytochrome P450 enzymes and, therefore, are unlikely to interfere with metabolism of other agents.
CLINICAL FEATURES
The clinical presentation of benzodiazepine intoxication is nonspecific and may be highly variable because of the frequent co­ingestion of other agents. Except for additive effects, drug interactions of benzodiazepines with other sedative­hypnotics are unusual.
The predominant manifestations of benzodiazepines are neurologic and are characterized by somnolence, dizziness, slurred speech, confusion, ataxia, incoordination, and general impairment of intellectual function. Prolonged coma is atypical and should prompt suspicion of intoxication with other agents or a nontoxicologic explanation. Neurologic effects of benzodiazepines may be prolonged or enhanced in the elderly, the young, and in those with protein deficiency or hepatic disease.
Paradoxical reactions, including excitement, anxiety, aggression, hostile behavior, rage, and delirium, have been reported but are quite uncommon.
Paradoxical reactions may occur more with hyperactive children and in psychiatric patients. Benzodiazepines may have a disinhibiting effect, which, in the presence of various extrinsic factors, can lead to such actions as aggressive or hostile behavior. Other effects that have been reported and that have unclear etiologies include headache, nausea, vomiting, chest pain, joint pain, diarrhea, and incontinence.

Benzodiazepines may cause short­term anterograde amnesia; this effect may be desired, especially in procedural sedation. Agents most often associated with anterograde amnesia are lorazepam, midazolam, and triazolam, although this may occur with the other benzodiazepines.
Uncommonly, respiratory depression and hypotension may occur, generally with either parenteral administration or in the presence of co­ingestants.
IV administration is more likely to cause serious cardiorespiratory effects with rapid administration. In addition, the elderly and those with underlying cardiorespiratory disease are more susceptible to adverse effects of IV administration.
Propylene glycol as a diluent in parenteral preparations of diazepam and lorazepam may cause severe metabolic acidosis (lactic acidosis),
,21 nephrotoxicity, and hyperosmolar states when infused at doses >1 milligram/kg per day for an extended period of time. During such treatment, an
 osmolar gap >10 is predictive of elevated propylene glycol concentrations. Treatment of propylene toxicity is generally supportive but may require
 hemodialysis.
Extrapyramidal reactions have been associated with the use of midazolam. Various allergic, hepatotoxic, and hematologic reactions also have been reported, but they are infrequent. In general, benzodiazepines have no long­term organ system toxicity other than that which can be ascribed to indirect effects from neurologic or cardiorespiratory depression.
DIAGNOSIS
Toxicologic testing in benzodiazepine ingestion is of limited value. Serum benzodiazepine levels do not correlate well with the clinical state, so serum level measurement is not routinely indicated. Qualitative testing with urine drug screens is typically designed to identify major metabolites of most
 benzodiazepines, such as oxazepam, temazepam, or nordiazepam, and not the parent compound. Depending on the antibody specificity used in the immunoassay, a false­negative test can occur and is commonly seen with midazolam and flunitrazepam. A urine benzodiazepine screen can usually detect a short­acting agent (e.g., lorazepam) up to  days and a long­acting agent (e.g., diazepam) up to  days after ingestion. Thus, detection of a benzodiazepine agent taken in the recent past may not correctly identify the toxicologic cause of the patient’s current condition. False­positive benzodiazepine urine drug screens have been reported with oxaprozin and sertraline, although improved immunoassay techniques have reduced this
,25 potential interference.
TREATMENT
GENERAL MEASURES
Benzodiazepines often are ingested with other agents, and the history is frequently inaccurate. Therefore, in patients with depressed or altered mental status, other metabolic and toxicologic possibilities should be considered (see Chapter 176, “General Management of Poisoned Patients”). Do not induce emesis in benzodiazepine overdose because mental status depression may develop and increase the risk for pulmonary aspiration. Activated charcoal binds benzodiazepines effectively and may be considered. Aspiration risk should be weighed against the benefits of treatment for an ingestion that rarely causes major morbidity in isolated overdose.
The combination of rapid absorption and high level of protein binding render gastric lavage, elimination enhancement by forced diuresis, hemodialysis, and hemoperfusion ineffective. Monitor neurologic and respiratory status and provide mechanical ventilation if necessary. Aspiration pneumonitis may be caused by severe respiratory and neurologic depression.
BENZODIAZEPINE ANTAGONIST
Flumazenil is a unique selective antagonist of the central effects of benzodiazepines, although there have been inconclusive claims that it may be
 effective in reversing the neurologic toxicity from other drugs. Potential clinical applications include the reversal of coma in benzodiazepine
,27 overdose and reversal of iatrogenic benzodiazepine­induced sedation during procedural sedation. Its use in benzodiazepine toxicity may obviate
,29 the need for tracheal intubation and respiratory support.
However, some toxicologists advocate that flumazenil has limited utility in the ED, noting it is useful mainly in reversing the effects of short­acting
 benzodiazepines administered for diagnostic and therapeutic procedures. Even in such cases, management is usually accomplished safely and easily
 by allowing the effects of the benzodiazepine to subside without antidotal administration. Although the plasma elimination half­life of flumazenil is approximately  hour, its duration of action is variable and depends on the dose of flumazenil and the benzodiazepine administered. Recurrent
 benzodiazepine toxicity may result once the effects of flumazenil have worn off. This is less likely for a benzodiazepine with a short duration of action, such as midazolam. The dose of flumazenil is .2 milligram IV, which can be repeated every minute, titrated according to response or to a total dose of  milligrams.
Several considerations should limit the empiric administration of flumazenil to a poisoned patient (Table 183­2). There is a higher incidence of side effects, albeit generally minor (agitation, nausea, vomiting, abdominal pain), when flumazenil is administered to an unconscious patient presenting to
,31 the ED. Of greater importance, generalized seizures have occurred in patients given flumazenil after co­ingestions of benzodiazepines and seizure­
,32 inducing agents, particularly cyclic antidepressants. Seizure activity after flumazenil administration also has occurred in patients physically dependent on benzodiazepines and in patients receiving benzodiazepines for control of a seizure disorder. The putative explanation for this convulsive activity is either the reversal of the cerebroprotective and anticonvulsive effects of benzodiazepines or the precipitation of a benzodiazepine withdrawal syndrome.
TABLE 183­2
Contraindications to Flumazenil
Overdose of unknown agents
Suspected or known physical dependence on benzodiazepines
Suspected cyclic antidepressant overdose
Co­ingestion of seizure­inducing agents
Known seizure disorder
Suspected increased intracranial pressure
Flumazenil­precipitated seizures in patients who are chronically taking benzodiazepines should be treated aggressively with another GABA receptor
A agonist because the benzodiazepine site on the receptor is antagonized. Anticonvulsants such as phenobarbital or propofol are recommended for flumazenil­induced seizures. Careful monitoring of the patient’s respiratory and mental status is necessary during treatment and may require securing the airway.
Another reason to avoid empiric administration of flumazenil in overdose patients is that the history is often unreliable or unavailable. The apparent overdose may be caused instead by an intracranial mass lesion. Flumazenil is contraindicated in patients with a suspected elevation of intracranial pressure, such as in severe head injury, due to its adverse effect on cerebral hemodynamics.
DISPOSITION AND FOLLOW­UP
Indications for observation or hospital admission include significant alterations in mental status, respiratory depression, and hypotension. If mental status depression persists or is profound, other agents or conditions must be considered. Although many clinicians use the 6­hour principle for observation of stable patients after ingestion, there is insufficient evidence to recommend a specific duration for an appropriate ED observation period.
BENZODIAZEPINE WITHDRAWAL
Benzodiazepine dependence can develop after long­term use—usually  to  months—and typically develops without tolerance (e.g., the absence of
 needing to increase dose to obtain the same effect). Such patients are at risk for withdrawal upon sudden cessation. Withdrawal symptoms usually start within  to  days for short­acting benzodiazepines and  to  days for longer­acting ones. Benzodiazepine withdrawal is characterized by nervous system hyperactivity (Table 183­3). Seizures are common in benzodiazepine withdrawal upon sudden discontinuation.
Withdrawal symptoms tend to be more severe with short­acting agents. Alprazolam withdrawal has some unique features compared with other
 benzodiazepine withdrawal syndromes. Delirium and psychosis are more common, and hyperadrenergic states characterized by intermittent episodes of hypertension with sinus tachycardia have been reported.
TABLE 183­3
Clinical Features of Benzodiazepine Withdrawal
Psychiatric Anxiety and nervousness* Restlessness and irritability* Insomnia and nightmares* Paranoia
Hallucinations
Delirium
Neurologic Muscle twitching and tremors* Cognition and memory impairment* Perceptual distortions
Hyperacusis and photophobia* Seizures* Autonomic Tachycardia* Hypertension
Diaphoresis
Nausea and vomiting
Headache
*Common features.
To prevent withdrawal, benzodiazepine dosing should be slowly reduced over  to  weeks, or even longer when a patient is tolerant to a long­acting
 agent such as diazepam. Dose reduction is guided by the patient’s ability to tolerate symptoms.
Treatment of benzodiazepine withdrawal can obviously be done by reinstituting the drug and then embarking on a slow taper. Most benzodiazepines can be substituted by others for treatment of withdrawal symptoms with the apparent exception of alprazolam withdrawal, in which cases clonazepam
 is recommended since lorazepam, diazepam, and chlordiazepoxide are ineffective. Alternative nonbenzodiazepine treatment includes antidepressants (e.g., trazodone), mood stabilizers (e.g., carbamazepine), anxiolytic agents (e.g., pregabalin or gabapentin), and β­blockers (e.g.,
,36  propranolol). Antihistaminic agents may be useful, and diphenhydramine, hydroxyzine, or promethazine have been effective.
Patients with severe benzodiazepine withdrawal (i.e., experiencing seizures, delirium, and psychosis) should be admitted for stabilization on
,38 appropriate medications. For patients with less severe withdrawal, reinstituting the benzodiazepine is recommended, with a suggestion to switch
 to a long­acting agent at an equivalent dose. Outpatient follow­up with taper can then be done.


