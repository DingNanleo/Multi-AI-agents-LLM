## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 82: Diverticulitis
Autumn Graham
INTRODUCTION AND EPIDEMIOLOGY
Diverticular disease is increasingly common in industrialized nations, and the prevalence of diverticulosis increases with age: 5% in patients age <40
 years, 30% by age , and >70% by age . Based on National Emergency Department Sample records from 2006 to 2013, evolving diverticulitis prevalence and management have resulted in a 27% increase in diverticulitis­related ED visits and a 105% increase in aggregated national cost,
 whereas ED admissions for diverticulitis decreased from 58% to 47% and surgical management decreased by 33%.
The natural history of the disease appears to be more benign than previously believed. Only 15% of patients with diverticulitis develop complicated
 ,4 disease. Recurrence occurs in 20% to 30% of patients with diverticulitis treated conservatively. Although surgery played a prominent role in diverticulitis management in the past, most cases of diverticulitis can be managed medically, even with recurrent episodes. In one study following 2366
Kaiser Permanente patients hospitalized with acute diverticulitis and treated nonoperatively, 86% required no further inpatient care for diverticulitis
 during a 9­year follow­up period. Only 4% had a second recurrence. No patient with a second recurrence required an operation.
PATHOPHYSIOLOGY
Diverticula are small herniations at sites where the vasculature, called vasa recta, penetrates the circular muscle layer of the colon. Although true diverticula involve all layers of the colon wall, most acquired diverticula are considered false diverticula, involving only the mucosal and submucosal layers. Diverticula usually range from  to  mm, but can extend up to  mm in length. Diverticulitis occurs when inflammation develops and, in
 complicated diverticulitis, leads to translocation of bacteria, microperforation, and abscess or phlegmon formation.
There are similar chemical and histologic changes seen in inflammatory bowel disease and irritable bowel syndrome, but no unifying mechanism has
,7 been demonstrated. Common bacterial pathogens are anaerobes, including Bacteroides, Clostridium, and Peptostreptococcus, as well as aerobic bacteria such as Escherichia coli, Enterococcus, Pseudomonas aeruginosa, and Klebsiella. While most GI infections are both anaerobic and aerobic,

Bacteroides fragilis and E. coli are the dominant bacteria isolated.
Altered bowel motility leads to high intraluminal colonic pressures and diverticula formation. The role of diet remains unclear. Smoking and obesity
 increase risk for diverticulitis, and an active lifestyle is said to decrease the risk. NSAIDs, opioids, and steroids increase the risk of perforation.
In the United States, diverticular disease is almost exclusively a left­sided colon disease, specifically the descending and sigmoid colon. Right­sided
 disease accounts for only 2% to 5% of cases and is found predominantly in Asian populations.
CLINICAL FEATURES
Classically, diverticulitis presents with left lower quadrant abdominal pain, fever, and leukocytosis. Patients with a redundant sigmoid colon, of Asian descent, or with right­sided disease may complain of right lower quadrant or suprapubic pain. The pain may be intermittent or constant and is often associated with a change of bowel habits, either diarrhea or constipation. Other associated symptoms include nausea/vomiting, anorexia, and urinary symptoms. On physical examination, patients may exhibit findings ranging from mild abdominal tenderness to moderate tenderness with a tender palpable mass, to distended abdomen, to peritonitis with rebound and guarding. Urinalysis may demonstrate sterile pyuria due to inflammation of the bladder.
DIAGNOSIS

Chapter 82: Diverticulitis, Autumn Graham 
In stable patients with a history of confirmed diverticulitis and a similar acute presentation, no further diagnostic evaluation is necessary unless the
. Terms of Use * Privacy Policy * Notice * Accessibility patient fails to improve with conservative medical treatment. If a prior diagnosis has not been confirmed or the current episode differs from the past episode, diagnostic imaging is required to exclude other intra­abdominal pathology and to evaluate for complications. The differential diagnosis of diverticulitis is extensive, including gynecologic emergencies, cancer, and inflammatory or infectious colitis (Table 82­1). Laboratory data are rarely diagnostic for diverticulitis, but liver function panels, CBC, renal panel, lipase, C­reactive protein, and urinalysis may aid in the exclusion of other disorders and prediction of diverticulitis severity.
TABLE 82­1
Differential Diagnosis of Diverticulitis
Acute appendicitis
Colitis—ischemic or infectious
Inflammatory bowel disease (Crohn’s disease, ulcerative colitis)
Colon cancer
Irritable bowel syndrome
Pseudomembranous colitis
Epiploic appendagitis
Gallbladder disease
Incarcerated hernia
Mesenteric infarction
Complicated ulcer disease
Peritonitis
Obstruction
Ovarian torsion
Ectopic pregnancy
Ovarian cyst or mass
Pelvic inflammatory disease
Cystitis
Kidney stone
Renal pathology
Pancreatic disease
IMAGING
CT is the preferred imaging modality because of its ability to evaluate the severity of disease and the presence of complications. The American College of Radiology Appropriateness Criteria recommends CT of abdomen and pelvis with IV contrast and states that “oral and/or colonic contrast may be
 helpful for bowel luminal visualization” due to its documented sensitivities of 97% and specificities approaching 100%. Multiple retrospective and small prospective studies have shown that variable contrast strategies including no IV or PO contrast and low­dose radiation CTs have been sensitive
11­13  and specific for diverticulitis. For most patients, CT of abdomen and pelvis with IV contrast only for patients with a body mass index >20 kg/m and
 addition of PO contrast for patients with a body mass index <20 kg/m is appropriate. CT findings include increased soft tissue density within the pericolic fat, indicating inflammation; presence of diverticula; bowel wall thickening >4 mm; soft tissue masses representing phlegmon; or pericolic
 fluid collections representing abscesses.
Compression US is operator dependent and limited based on the patient’s body habitus. Sensitivity and specificity of US for diverticulitis vary but are

>80% in experienced hands. CT is preferred to detect complications.
TREATMENT
Treatment varies with disease severity. Uncomplicated diverticulitis is isolated to inflammation of the diverticula with or without phlegmon or small abscess confined to the bowel wall. Complicated diverticulitis includes diverticular inflammation associated with abscess, stricture, obstruction, fistula, or perforation.
Current treatment and disposition recommendations are provided in Tables 82­2 and 82­3. TABLE 82­2
Antibiotics for Diverticulitis
Outpatient First line Metronidazole 500 milligrams PO QID
4–7 days PLUS
Ciprofloxacin 750 milligrams PO BID
OR
Levofloxacin 750 milligrams PO daily
OR
Trimethoprim­sulfamethoxazole (160 milligrams/800 milligrams)  double­strength tablet PO BID
OR
Cefuroxime 500 milligrams PO BID
Alternate Amoxicillin­clavulanate 875 milligrams  tablet PO BID
OR
Moxifloxacin 400 milligrams PO daily
Inpatient
Moderate disease First line Metronidazole 500 milligrams IV q6h or metronidazole  gram IV q12h
PLUS
Ciprofloxacin 400 milligrams IV q12h
OR
Levofloxacin 750 milligrams IV q24h
OR
Aztreonam  grams IV TID
OR
Ceftriaxone 1–2 grams IV q24h
OR
Cefuroxime .5 grams IV q8h
Alternative Ertapenem  gram IV q24h
Piperacillin­tazobactam .375 grams IV q6h or .5 grams IV q8h
Ticarcillin­clavulanate .1 grams IV q 6h
Severe, life­threatening First line Imipenem/cilastatin 500 milligrams IV q6h
OR
Meropenem  gram IV q8h
OR
Piperacillin­tazobactam .5 milligrams IV q8h
OR
Ticarcillin­clavulanate .1 grams IV q4h
Alternative Ampicillin  grams IV q6h
PLUS
Metronidazole 500 milligrams IV q6h
PLUS
Ciprofloxacin 400 milligrams IV q12h
OR
Amikacin  milligrams/kg/day IV divided q12h
Penicillin allergy Aztreonam  grams IV q6h
PLUS
Metronidazole 500 milligrams IV q6h
Note. Adult dosing only. Dose adjustments may be required for renal and/or liver impairment. Antibiotic choice should be guided by local antibiograms and local antibiotic resistance patterns.
TABLE 82­3
Disposition Options for Diverticulitis
Disposition
Appropriate for Outpatient Management +/­ antibiotics
Uncomplicated diverticulitis
Normal vital signs
Mild to moderate symptoms with mild tenderness on physical exam
No associated abdominal distention
No vomiting, able to tolerate fluids and take medications
Able to control pain with oral medications
Able to follow up with physician in 2–3 days
Able to care for self at home
Inpatient Management
Complicated diverticulitis (phlegmon, abscess, perforation, fistula, stricture, obstruction)
High­risk patients
High Risk of Complications and Treatment Failure
Clinical Risk Factors Diagnostic Risk Factors CT Imaging Risk Factors for Progression to
Complicated Diverticulitis
Age >70 years Generalized abdominal pain/tenderness versus Fluid collections (frequently anterior to rectum)
Fever localized to left lower quadrant Greater length of inflamed colon (85 mm vs. 
Vomiting/Inability to tolerate Leukocytosis – WBC  × 109/L (sensitivity 82%, mm)
PO Inflamed diverticulum greater than  cm specificity 45%)
Poor follow­up or inability to
CRP >90 mg/L (sensitivity 88%, specificity 75%) care for self at home
Signs of sepsis
Multiple comorbid conditions
Immunocompromised
Corticosteroid use
Malnutrition
Active malignancy
Chronic opiate use
. Bolkenstein HE, Van de Wall BJ, Consten E, Broeders A, Draaisma W. Risk factors for complicated diverticulitis: systemic review and meta­analysis. Int J Colorectal
Dis 2017; 32: 1375­1383. . Lorimer JW, Doumit G. Comorbidity is a major determinant of severity in acute diverticulitis. Am J Surg 193: 681, 2007. [PMID: 17512276]
. Van Diijk S, Daniels L, Nio C, Somers I, Van Geloven A, Boermeester M. Predictive factors on CT imaging for progression of uncomplicated into complicated acute diverticulitis. Int J Colorectal Dis 2017; 32: 1693­1698. Source: Reproduced with permission from Graham AC, Carlberg DJ: Gastrointestinal Emergencies: Evidence­Based Answers to Key Clinical Questions. Switzerland:
Springer Nature; 2019. Uncomplicated diverticulitis treatment is rapidly evolving. The cornerstone of treatment has been antibiotics (Table 82­2). With increased understanding of the inflammatory rather than infectious etiology of uncomplicated diverticulitis, recent studies have reported no benefit to routine antibiotic use. The 2015 American Gastroenterology Association recommends “that antibiotics should be used selectively, rather than routinely, in
   patients with acute uncomplicated diverticulitis” confirmed by CT. These recommendations are similar to those adopted in Denmark, Italy,

Germany, and the Netherlands.
In the United States, this guideline recommendation was based in large part on the multicenter, randomized AVOD trial (20) in Sweden and Iceland. Of the 623 admitted patients with CT­verified, acute, left­sided diverticulitis, 309 patients were randomized to IV fluids with no antibiotics and 314 patients to IV antibiotics. Six patients (2%) who did not receive antibiotics and three patients (1%) who received antibiotics developed complications (e.g., abscess or perforation). There were no differences between the antibiotic and no antibiotic groups in symptoms at 30­day follow­up, need for
 emergency surgery, or median hospital stay.
,22 
Other retrospective and prospective studies have reported similar findings. Daniels and colleagues published a multicenter, open­label, pragmatic, randomized controlled trial of 528 patients with acute, CT­confirmed diverticulitis enrolled in one of the following strategies: (1) admission with  hours of IV antibiotics with conversion to oral antibiotics for the remainder of a 10­day antibiotic treatment course, or (2) an outpatient observation arm for those who met criteria for outpatient treatment. No significant differences were reported between the observational versus antibiotic group in recovery time (14 vs.  days), complications (3.8% vs. .6%), recurrent disease (3.4% vs. .0%), surgery (3.8% vs. .3%), readmission

(18% vs. 12%), or mortality (1.1% vs. .4%).
These studies and expert opinion suggest that observational treatment without antibiotics may be appropriate for CT­confirmed, uncomplicated, acute diverticulitis in immunocompetent patients with mild symptoms and without systemic infectious signs or symptoms or red flags for progression to complicated diverticulitis. Procalcitonin has been suggested as a tool to guide the use of antibiotics in diverticulitis, similar to its role in upper
 respiratory infection management, but more research is needed before clinical application.

Dietary restriction or modification is commonly recommended, but efficacy is not clear. It is not necessary to limit the patient to a clear diet, but patients can be advised to eat foods as tolerated. During the acute episode, our personal recommendations also include no dairy foods, because ability to process lactate can change, and no red meat, because it is difficult to digest.
If antibiotics are warranted, a shorter duration of antibiotics (4 to  days) compared to the standard antibiotic course (7 to  days) may be appropriate. The Infectious Diseases Society of America recommends “antimicrobial therapy for established infections should be continued until
 resolution of clinical signs of infection occurs, including normalization of temperature and WBC count and return of gastrointestinal function.” The natural history of diverticulitis suggests symptom improvement in  to  days. A study of admitted patients receiving IV ertapenem found that a 4­day
  course of antibiotics was as effective as a 7­day course. There is no proven advantage of IV antibiotics over PO antibiotics for diverticulitis. Thus, for stable, immunocompetent patients with established follow­up in  to  days, a short course of antibiotics (4 to  days) may be appropriate.
Complicated diverticulitis generally requires admission. In addition to bowel rest and IV antibiotics, treatments directed at specific complications
 are needed. Complicated diverticulitis is classified by the Hinchey classification scheme : Stage  is small, confined pericolic or mesenteric abscesses; stage  is larger abscesses, extending to the pelvis; stage  is perforated diverticulitis and purulent peritonitis; and stage  refers to free perforation with fecal contamination of the peritoneal cavity.
Abscesses and phlegmon are among the most common complications. Phlegmon is inflammation and infection of tissue without abscess. Patients with abscesses that measure <3 cm and phlegmon (Hinchey stage 1) are admitted for IV antibiotics and monitoring for progression. Percutaneous drainage of abscesses >3 cm have allowed many patients to forgo invasive surgical management. Initial nonoperative treatment fails in up to 20% of
 patients. Perforation has a high mortality rate, and patients need volume resuscitation, IV antibiotics, and emergent exploratory surgery. For Hinchey
,28 stage , the mortality rate approaches 13% and increases to 43% for Hinchey stage . DISPOSITION AND FOLLOW­UP
Table 82­3 provides detailed disposition options. ED discharge is appropriate for uncomplicated diverticulitis with instructions to follow up in  to  days with a primary care provider or to return to the ED for recurring pain, fever, nausea and vomiting, or abdominal tenderness.

Patients with intractable nausea or vomiting, significant comorbid diseases, poor support at home, high leukocytosis, or high fevers, as well as the elderly, the immunocompromised, and those with persistent pain should be admitted. The immunocompromised and those taking chronic steroids often present atypically and are at risk for complications. Admit patients with complicated diverticulitis or failed outpatient management.
Acknowledgments
Special thanks to Elaine Bromberek, Brandon Ruderman, Sreeja Natesan, Traci Thoureen, and Sara Scott for their assistance with this chapter.


