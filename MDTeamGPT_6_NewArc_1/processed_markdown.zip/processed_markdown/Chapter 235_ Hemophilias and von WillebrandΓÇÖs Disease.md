## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 235: Hemophilias and von Willebrand’s Disease
Jonathan A. Drew Clare; Robin R. Hemphill
INTRODUCTION
1­3
Hemophilias are bleeding disorders due to deficiency in clotting cascade factors (see Chapter 232, “Hemostasis”). The most common factor abnormalities are of factor VIII (hemophilia A) or factor IX (hemophilia B). von Willebrand’s disease is a related defect of the von Willebrand
 factor.
These hereditary bleeding disorders typically appear early in life, and adult patients will usually be able to relate a history of a bleeding problem.
However, patients with mild forms of inherited disease may be unaware of a bleeding disorder until stressed by significant trauma or development of another hemostatic problem such as addition of antihemostatic medications.
Systemic bleeding disorders should be suspected in patients with severe bleeding related to trivial trauma or minor surgery, or spontaneous bleeding, particularly when the bleeding occurs in joints or muscle. Unusual bleeding or bruising at multiple areas should also raise concern about a coagulopathy. Medications can be responsible for unmasking a mild bleeding diathesis.
The pattern of bleeding can suggest a likely etiology. Patients with easy bruising, gingival bleeding, epistaxis, hematuria, GI bleeding, or heavy menses are more likely to have a deficiency or dysfunction of the platelets. Conversely, patients with spontaneous deep bruises, hemarthrosis, retroperitoneal bleeding, or intracranial bleeding are more likely to have a coagulation factor deficiency. In factor­deficient patients, bleeding associated with trauma may be delayed, due to defective fibrin clot formation that inadequately stabilizes the initial platelet thrombus. Patients with von Willebrand’s disease may present with features of both platelet and clotting factor problems.
HEMOPHILIA
EPIDEMIOLOGY
The genes that encode factors VIII and IX are located on the long arm of the X chromosome. A genetic mutation in the factor VIII gene produces hemophilia A, occurring in about  in 5000 male births in the United States. A mutation in the factor IX gene causes hemophilia B, affecting approximately  in ,000 male births in the United States. Together, these two forms of hemophilia make up about 99% of patients with inherited coagulation factor deficiencies. Hemophilia A and B are clinically indistinguishable from each other, and specific factor testing is required to identify the type.
Because hemophilia A and B are X­linked disorders, hemophilia is overwhelmingly a disease of men, with women typically being asymptomatic carriers,
 except in rare cases. Although these disorders are genetic and usually inherited, approximately one third of new cases of hemophilia arise from a spontaneous gene mutation, and a family history may be absent.
PATHOPHYSIOLOGY
Bleeding manifestations in patients with all forms of hemophilia are directly attributable to the decreased plasma activity levels of either factor VIII or IX
(Table 235­1). Those with factor activity levels of .3 to .4 IU/mL (30% to 40% of normal) may never be aware that they have hemophilia, or they might manifest unusual bleeding only after major surgery or severe trauma. Unless there is another underlying disease, patients with hemophilia do not have problems with minor cuts and abrasions, as hemostasis from these injuries is achieved by platelet activation and the formation of the primary hemostatic plug (see Chapter 232).
TABLE 235­1

Hemophilia Severity
Chapter 235: Hemophilias and von Willebrand’s Disease, Jonathan A. Drew Clare; Robin R. Hemphill 
. Terms of Use * Privacy Policy * Notice * Accessibility
Disease Severity Factor VIII or IX Activity (% of normal) Clinical Features
Severe <0.01 IU/mL Severe spontaneous bleeding, difficult to control if traumatic
(<1%)
Moderate .01–0.05 IU/mL Usually bleeding from trauma; may bleed spontaneously
(1%–5%)
Mild .05–0.40 IU/mL Bleeding after trauma
(5%–40%)
Bleeding is the major complication of hemophilia, but as a result of frequent exposure to blood products, many hemophiliacs in the past were infected with viral hepatitis or human immunodeficiency virus. Fortunately, currently available factor replacement products have essentially eliminated the risk of seroconversion.
CLINICAL FEATURES
Depending on the severity of the disease, both hemophilia A and B are characterized by easy bruising and spontaneous recurrent bleeding primarily
1­3 into the joints and muscles and less commonly into other areas (Table 235­2). Trauma or a surgical procedure can result in prolonged and difficultto­control bleeding.
TABLE 235­2
Hemophilia Bleeding Manifestations
Site Comments
Hemarthroses Most common site, more frequent in hinged joints (elbows, knees, ankles) than in multiaxial joints.
Soft tissue Bleeding into soft tissues or muscle; bleeding can dissect along fascial planes; most dangerous in the neck (airway compromise), limbs
(compartment syndromes), eye (retro­orbital hematoma), spine (epidural hematoma), and retroperitoneum (circulatory shock).
Mucocutaneous Delayed bleeding after dental extractions; spontaneous bleeding from the nose, pharynx, GI tract, or lungs is uncommon.
bleeding
CNS Intracranial bleeding is the most common cause of hemorrhagic death in hemophiliacs of all age groups; subdural hematomas occur spontaneously or with minimal trauma.
Hematuria Common, usually not serious, and a specific bleeding site is rarely found.
Hemophilic Unresolved or undertreated hematomas erode into adjacent bones resembling bone cysts or malignancy; may compress adjacent pseudotumor nerves and vessels.
DIAGNOSIS
For patients with established hemophilia, hemostatic testing (e.g., prothrombin time, activated partial thromboplastin time) is unlikely to yield new information and is not routinely indicated. In patients with a suspected bleeding disorder, hemophilia is suspected when the prothrombin time, which measures the extrinsic coagulation cascade, is normal, but the activated partial thromboplastin time, which measures the intrinsic coagulation cascade, is prolonged. However, patients with factor levels above .3 to .4 IU/mL (30% to 40% of normal) may have an activated partial thromboplastin time within the test reference range. Bleeding time in both forms of hemophilia will be normal and therefore not helpful. The diagnosis is confirmed by quantitative measurement of factor VIII or IX levels below .50 IU/mL (<50% normal). If mild hemophilia A is suspected, a variant of von Willebrand’s disease characterized by abnormal binding of factor VIII and von Willebrand factor should be excluded by special binding tests or genetic analysis.
TREATMENT
GENERAL PRINCIPLES
,7
Initiate indicated resuscitation and hemorrhage control (Table 235­3). Assess the patient’s history. Many patients and their families administer factor concentrate therapy at home, and patients are taught to self­treat at the first symptom before little outward evidence develops. Patients may have an established management plan for acute bleeding episodes, and regional hemophilia foundations, associations, and centers often maintain a database that can be contacted for patient­specific information, especially if there is an uncertainty about the need for factor replacement.
TABLE 235­3
Approach to the Bleeding Hemophiliac Patient6,7
Initial resuscitation and hemorrhage control
Assess patient’s history, home factor replacement therapy, and presence of inhibitors
Discuss with hematologist or contact hemophilia center
Initiate replacement therapy as indicated
Prior to invasive procedures, central lines and further workup or intervention
Imaging as indicated (e.g., head CT for head injury or neurologic findings, plain films for effusions, CT of abdomen/pelvis for retroperitoneal bleeding)
Treat pain as indicated, primarily with acetaminophen or opioids
Avoid use of aspirin or NSAIDs; no IM injections
Consultations as indicated (e.g., orthopedics for hemarthrosis)
Admission or transfer for CNS, neck, pharyngeal, retropharyngeal, or retroperitoneal bleeding or possible compartment syndrome
Adequate factor replacement therapy should be initiated prior to transfer
Treatment of bleeding in patients with hemophilia primarily relies on either the early replacement of missing factors or, for those who have mild factor
VIII deficiency, stimulating the body to secrete clotting factor from intracellular stores. Begin replacement before or at the same time as other resuscitative and diagnostic maneuvers for intracranial, intrathoracic, intra­abdominal, retroperitoneal, ocular, or airway bleeding
(Table 235­2). Bleeding into the neck, tongue, or retropharynx can compromise the airway. Patients with suspected intracranial hemorrhage, either spontaneous with an acute severe headache or after blunt head injury, should receive immediate factor replacement therapy prior to head CT.
Complaints of back, thigh, groin, or abdominal pain may be symptoms of retroperitoneal bleeding. An iliopsoas muscle hemorrhage is a common form of retroperitoneal bleeding seen in hemophiliacs, and patients may describe hip pain and have difficulty straightening their leg, preferring to keep it in a flexed, externally rotated position. An iliopsoas muscle hemorrhage can compress and damage the femoral nerve, cause anemia of blood loss, or produce circulatory shock.
The initial manifestations of bleeding can be subtle. Simple injuries, such as ankle and wrist sprains, may at first appear benign, and several hours may pass before hemarthrosis is apparent. So, while there may not be physical signs of bleeding into a joint, patients will reliably report when bleeding is occurring. Prompt treatment of hemarthroses with factor replacement and rest of the joint for  to  days can prevent or reduce the long­term sequelae of hemophilic arthropathy. If a large hemarthrosis is already present, consultation with an orthopedist for appropriate
 splinting, possible arthrocentesis, and rehabilitation may improve the outcome once the bleeding has been controlled. Compartment syndromes can result from bleeds within the fascial compartments of the extremities. Compartment pressures can be safely measured after the patient has received factor replacement.
When treating patients with hemophilia for other reasons, some general principles apply. Do not place central venous access or arterial lines without factor replacement. Similar rules apply to arterial blood gases, lumbar puncture, and other invasive procedures. Do not give IM injections unless factor replacement is given and maintained for several days. If a patient with hemophilia requires interhospital transfer, initiate factor replacement before transfer, and do not delay factor replacement with attempts to obtain imaging.
FACTOR REPLACEMENT THERAPY
The two sources of factor replacement therapy for hemophilic patients are purification from human plasma and recombinant technology from
9­11 ,13 hamster or human embryonic kidney cell lines (Table 235­4). Opinions vary as to the preferred product, and World Federation of Hemophilia
,9 guidelines do not express a preference. In the United States, the National Hemophilia Foundation position is that recombinant factor concentrates
  are the preferred treatment for hemophilia. Where possible, use the product that the patient uses at home.
TABLE 235­4
Hemophilia Replacement Factor Products
Hemophilia Type Available Products* (Manufacturer/Distributor)
Hemophilia A Recombinant Factor VIII Concentrates
Advate® (Baxter)
Adynovate® (Shire)
Afstyla® (CSL Behring)
Eloctate® (Bioverativ)
Helixate FS® (Bayer/CSL Behring)
Kogenate FS® (Bayer)
Kovaltry® (Bayer HealthCare)
Novoeight® (Novo Nordisk A/S)
Nuwig® (Octapharma USA)
Recombinate® (Baxter)
Xyntha® (Pfizer)
Human Plasma–Derived Factor VIII Concentrates
Corifact® (CSL Behring)
Hemofil M® (Baxter)
Koate­DVI® (Grifols Therapeutics)
Monarc­M® (Baxter HealthCare)
Monoclate­P® (CSL Behring)
Human Plasma–Derived Factor VIII Concentrates That Contain von Willebrand Factor
Alphanate® (Grifols Therapeutics)
Humate­P® (CSL Behring GmbH)
Wilate® (Octapharma USA)
Hemophilia B Recombinant Factor IX Concentrates
Alprolix® (Bioveratic)
BeneFIX® (Pfizer)
Idelvion® (CSL Behring)
Ixinity® (Emergent BioSolutions)
Rebinyn® (Novo Nordisk A/S)
Rixubis® (Shire)
Human Plasma–Derived Factor IX Concentrates
Bebulin® (Shire)
Mononine® (CSL Behring)
*Commercial trade names provided for ease of specific identification.
The dosing regimen used in the hemophilic patient is based on the clotting factor volume of distribution, the half­life of the factor, and the hemostatic
 level of factor required to control the bleeding (Table 235­5). Clotting factor is dosed in units of activity;  IU of factor represents the amount present in  mL of normal plasma. In hemophilia A,  IU of factor VIII per kilogram of body weight raises the plasma level by approximately .02 IU/mL
(2%). The half­life of factor VIII is approximately  to  hours. For hemophilia B,  IU of factor IX per kilogram of body weight will raise the plasma level by approximately .01 IU/mL (1%). The half­life of factor IX is approximately  to  hours.
TABLE 235­5
Initial Factor Replacement Guidelines in Moderate and Severe Hemophilia
Desired Factor
Hemophilia Hemophilia
Level to
Severity and Site A Initial B Initial Comments
Control
Dose (IU/kg) Dose (IU/kg)
Bleeding
Minor: skin (deep laceration) — — — Skin abrasions and lacerations usually do not require factor replacement. Treat with pressure and topical thrombin.
Minor: early hemarthrosis, mild .2–0.4 IU/mL 10–20 20–30 Repeat dose every 12–24 h for 1–3 d until bleeding episode muscle bleeding, mild oral (20%–40%) is resolved. Typical duration of replacement is 1–3 d.
bleeding
Moderate: definite hemarthrosis, .3–0.6 IU/mL 15–30 25–50 Repeat dose every 8–24 h until resolution of bleeding moderate muscle bleeding, (30%–60%) episode. Orthopedic consult for hemarthrosis. Typical moderate oral bleeding duration of replacement is 3–5 d.
Major: retropharyngeal, GI, intra­ .6–1.0 IU/mL 30–50 30–50 Repeat dose every 8–24 h until resolution of bleeding abdominal, intrathoracic, (60%–100%) episode. May require replacement for up to  d.
retroperitoneal
CNS .0 IU/mL  50–100 Treat before CT. Early neurosurgical consultation.
(100%)
Factor concentrates are supplied as lyophilized powder in single­use glass vials containing a range of amounts, from 250 to 4000 IU per vial. Calculation of the factor dose is done using the patient’s weight and, to avoid wasting factor, rounding up doses to the next vial. For major bleeding, high levels of factor replacement are required and continued until bleeding stops (Table 235­5). Repeat doses are usually given as repeat bolus therapy every  to  hours, or  to  hours in patients under  years of age.
For less severe bleeding in soft tissue, muscle, or joints, a lesser amount of factor replacement is necessary; usually three doses over  to  days are
 sufficient to control bleeding. In addition to factor replacement, extremity and joint bleeding may benefit from splinting followed by physical therapy.

Cryotherapy has no proven benefit in hemarthroses.
SPECIAL CONSIDERATIONS
ORAL AND MUCOSAL BLEEDING
Oral bleeding from hemophilia is more common in children than in adults. For an oral bleed, the area should be identified and cleaned of inadequate clot and solution of topical bovine thrombin sprayed on to the site or applied in conjunction with a saturated absorbable gelatin sponge. Repeat doses should be limited because repetitive application of topical bovine thrombin can induce antibodies to factor V, resulting in a syndrome of severe bleeding and thrombosis, which can rarely be fatal. Factor replacement may be required, dosed according to the severity of bleeding. Antifibrinolytic
 agents, such as aminocaproic acid and tranexamic acid, are useful adjunctive therapies with a low rate of adverse effects. For very superficial mucosal injuries, it may be possible to manage the bleeding with antifibrinolytic therapy alone. The adult dose of aminocaproic acid is  grams every  hours given PO or IV. The adult dose of tranexamic acid is  milligrams/kg IV three times per day for  to  days.
MILD HEMOPHILIA A
,2,16
Patients with mild hemophilia A (factor levels of 5% of normal or greater) who have mild bleeding may not always require factor replacement.
Rather, they may be treated with desmopressin, which stimulates the release of von Willebrand factor from endothelial storage sites, promoting an
16­18 increase of factor VIII in the plasma (Table 235­6). A concentrated intranasal preparation is available and can be used at home. IV or intranasal desmopressin will increase the factor VIII level by two to four times. Desmopressin treatment can be repeated in  hours, but with repetitive use, the patient’s stores of factor VIII will become depleted, and subsequently, the effect will be less. Desmopressin is an antidiuretic agent, so fluid restriction may be needed during use.
TABLE 235­6
Desmopressin Treatment of Mild Hemophilia A and von Willebrand Disease
Patient IV Preparation Nasal Preparation
<2 y Not recommended Not recommended
<50 kg .3 microgram/kg IV over  min Single spray of 150 micrograms in one nostril weight
>50 kg .3 microgram/kg IV over  min; maximum dose,  One spray of 150 micrograms in each nostril (total dose, 300 weight micrograms micrograms)
HEMATURIA

Hematuria is common in hemophilia but is typically not severe. Rest and hydration are important to ameliorate bleeding and factor replacement is indicated for gross hematuria. Hemophiliacs are at increased risk for nephrolithiasis, suggesting that renal imaging is indicated for patients with
 symptoms of renal colic or new­onset hematuria.
FACTOR INHIBITORS

Factor inhibitors, antibodies against replacement factors, tend to occur most commonly in severe hemophiliacs. The incidence of inhibitor
 development is 30% in severe hemophilia A and 5% in severe hemophilia B. Inhibitors not only interfere with the effectiveness of factor replacement therapy, but also can cause anaphylaxis during factor administration in patients with hemophilia B. The use of factor replacement in hemophilic patients with inhibitors is guided by the concentration of inhibitor and the type of response the patient has to factor concentrates. ED physicians should query hemophiliacs about whether they have known inhibitors.
The overriding principle in treating patients with inhibitors is close consultation with a hematologist. In patients with low levels of inhibitor antibodies (<5 Bethesda inhibitor assay units) who are not vigorous antibody responders, some hematologists may recommend giving an increased dose of factor in an attempt to overwhelm the existing antibody. Alternative therapies include anti­inhibitor coagulant complex (FEIBA®) and
21­23 coagulation factor VIIa (recombinant) (Table 235­7). Anti­inhibitor coagulant complex, derived from human plasma, contains factors II, IX, and X, mostly nonactivated, and factor VII, primarily in the activated form. Activated factor VII, either from human plasma or recombinant, when complexed with tissue factor, activates factor X. Factor Xa, in concert with factor Va, calcium, and phospholipid, promotes the conversion of prothrombin to thrombin, which ultimately leads to the formation of a hemostatic plug composed of cross­linked fibrin.
TABLE 235­7
Replacement Therapy for Hemophilia A and B in Patients With Inhibitors
Dosing
Product* Initial Dose Comments
Interval
Anti­inhibitor coagulant 50–100 6–12 h Repeat until hemostasis is achieved. Total daily doses should not normally complex units/kg exceed 200 units/kg
FEIBA® (Shire)
Coagulation factor VIIa   h Repeat until hemostasis is achieved or therapy is judged ineffective
(recombinant) micrograms/kg
NovoSeven RT® (Novo Nordisk
A/S)
*Commercial trade names provided for ease of specific identification.
ACQUIRED HEMOPHILIA
Acquired hemophilia occurs when autoantibodies are created against factor VIII, resulting in inactivation of this factor and a hemorrhagic tendency
,25
(see Chapter 233, “Acquired Bleeding Disorders”). The bleeding pattern in acquired hemophilia is usually widespread cutaneous purpura and internal bleeding, with hemarthroses being less common, a difference from congenital hemophilia. Treatment of acute bleeding uses factor products that bypass the inhibitor antibodies, such as anti­inhibitor coagulant complex or coagulation factor VIIa (recombinant).
POSTPARTUM ACQUIRED HEMOPHILIA
,27
Postpartum acquired hemophilia is a rare condition with severe hemorrhagic potential. The risk is highest with the first pregnancy, and presentation is typically  months after delivery, with persistent vaginal bleeding being the most common presenting symptom. Treatment for hemorrhage is with anti­inhibitor coagulant complex or coagulation factor VIIa (recombinant) (Table 235­7). Production of the autoantibodies will spontaneously cease over many months, achieving complete remission. Recurrence with subsequent pregnancies is uncommon.
DISPOSITION AND FOLLOW­UP
,2,6,7
Many hemophilic patients are able to judge the severity of bleeding, self­administer replacement therapy, and monitor the response at home.
Such patients may likely be discharged after initial treatment in the ED for typical joint, soft tissue, or nasal hemorrhage. Relative indications for hospital admission include treatment requiring multiple factor replacement doses or necessity for parenteral pain management. Patients with bleeding in the CNS, neck, pharynx, retropharynx, or retroperitoneum or those with a potential compartment syndrome should be admitted. Given the complexity of treatment for this subset of patients, consultation or transfer to a hemophilia treatment center is recommended.
VON WILLEBRAND’S DISEASE
EPIDEMIOLOGY
 von Willebrand’s disease is the most common inherited bleeding disorder, present in 1% of the population. Most patients have a mild defect, and clinically significant bleeding is rare. Congenital von Willebrand’s disease is heterogeneously inherited and variably expressed, and although there are multiple variants, it can be classified into three major groups (Table 235­8). An acquired form of von Willebrand’s disease occurs when autoantibodies develop against von Willebrand factor, resulting in rapid clearance of the antibody–von Willebrand factor complex from the circulation.
TABLE 235­8 von Willebrand’s Disease Classification and Treatment
Type Frequency Defect Treatment
 70%–80% Normal vWF is present but in decreased quantity Desmopressin and, if no response, consider the measures below of cases (approximately 20%–50% normal levels)
 10%–15% The vWF is abnormal and dysfunctional Recombinant vWF, vWF­containing concentrate or cryoprecipitate (if of cases vWF­containing product is not available)
 <10% of Almost no vWF is present Recombinant vWF, vWF­containing concentrate or cryoprecipitate (if cases vWF­containing product is not available)
Abbreviation: vWF = von Willebrand factor.
PATHOPHYSIOLOGY von Willebrand factor is a glycoprotein that, unlike most other coagulation factors, is synthesized, stored, and then secreted by the vascular endothelial cells. von Willebrand factor serves two key roles in normal hemostasis: as a cofactor for platelet adhesion and as the carrier protein for
 factor VIII. Circulating von Willebrand factor does not bind directly to platelets, but, when exposed to the subendothelial matrix, von Willebrand factor undergoes a structural change, allowing it to bind to platelet glycoprotein Ib. This interaction between von Willebrand factor and platelet glycoprotein Ib leads to platelet activation and adhesion to other platelets, as well as to the damaged endothelium. As a carrier protein, von Willebrand factor protects factor VIII from proteolytic degradation within the plasma. A defect in von Willebrand factor that diminishes factor VIII binding produces a clinical presentation similar to mild hemophilia A.
CLINICAL FEATURES
Skin and mucosal bleeding is common in people with von Willebrand’s disease, particularly in children and adolescents. Examples of bleeding include recurrent epistaxis, gingival bleeding, unusual bruising, GI bleeding, and menorrhagia in young women. Hemarthrosis is not typical unless severe disease is present. In mild cases of von Willebrand’s disease, the patient may be unaware of the disease until after a surgical procedure or injury when unexpected bleeding occurs.
DIAGNOSIS
The common abnormalities seen in von Willebrand’s disease include prolonged bleeding time, low or normal von Willebrand factor antigen, and low
 von Willebrand factor activity. The prothrombin time should be normal, and about half of patients have a mildly prolonged activated partial thromboplastin time. Diagnostic testing can be complicated, and misdiagnosis can occur from errors in specimen handling, storage, processing, and laboratory testing proficiency. In addition, variability in von Willebrand factor levels can sometimes make von Willebrand’s disease difficult to differentiate from mild hemophilia A.
TREATMENT
NONTRANSFUSIONAL THERAPY
,30
Desmopressin is the primary therapy for many patients with type  von Willebrand’s disease. For other types of von Willebrand’s disease, desmopressin may still work in conjunction with products that contain von Willebrand factor, but hematologists tend to recommend either one or the other. Desmopressin induces the release of von Willebrand factor from storage sites within the endothelium. In responsive individuals, it causes a transient two­ to fourfold increase in von Willebrand factor. Desmopressin also has an effect on the endothelium that promotes hemostasis. IV and concentrated nasal spray preparations of desmopressin are available (Table 235­5). Desmopressin may be repeated in  hours, but the response to subsequent doses diminishes as vWF stores become depleted. Desmopressin also has antidiuretic properties, so fluid restriction for  hours after
 administration is important to prevent hyponatremia.
TRANSFUSIONAL THERAPY
,31
Transfusional therapy is used for type  patients who do not (or no longer) respond to desmopressin or have type  or  von Willebrand’s disease.
A von Willebrand Factor (recombinant) (Vonvendi®, Baxalta US, Inc.) product became available in 2015. The initial dose is  to  IU/kg IV for minor bleeding and  to  IU/kg for major bleeding, with subsequent doses every  to  hours as needed. Plasma derivatives that contain von Willebrand factor can also be used with an initial dose of  to  IU/kg (Table 235­4). Cryoprecipitate also contains von Willebrand factor, but because it does not
 undergo viral inactivation, cryoprecipitate should only be used in life­threatening emergencies when other products are not available. Platelet
 transfusions may benefit patients with certain types of von Willebrand’s disease (type 3) who do not respond to von Willebrand factor products.
ADDITIONAL THERAPY
Avoid medications with known antiplatelet effects, including aspirin, NSAIDs, antiplatelet agents, heparin, and some antibiotics. Patients with von
Willebrand’s disease with significant epistaxis should be treated with desmopressin or transfusion therapy as needed to control bleeding. If unsuccessful, intranasal topical therapy or cauterization may be necessary (see Chapter 244, “Nose and Sinuses”). Menorrhagia is a common complaint in young women with von Willebrand’s disease. Oral contraceptives can help raise von Willebrand factor levels and limit the degree of menstrual bleeding. For dental injury or planned procedures in the oral cavity, an antifibrinolytic agent can be used. Aminocaproic acid can be taken orally, and tranexamic acid can be made into a mouthwash, to be used for  to  days after the injury or surgical procedure.
DISPOSITION AND FOLLOW­UP
In most patients with von Willebrand’s disease, the acute bleeding episodes can be controlled with local measures and desmopressin; such patients can usually be discharged. The unusual von Willebrand’s disease patient with almost no von Willebrand factor activity is typically handled like a patient with hemophilia. Relative indications for hospital admission include treatment requiring multiple factor replacement doses or necessity for parenteral pain management. Patients with bleeding in the CNS, neck, pharynx, retropharynx, or retroperitoneum or those with a potential compartment syndrome should be admitted, with consideration of transfer to a hemophilia center.


