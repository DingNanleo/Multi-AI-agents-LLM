## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 245: Oral and Dental Emergencies
Ronald W. Beaudreau
INTRODUCTION
Oral emergencies generally can be divided into two broad categories: (1) nontraumatic orofacial pain and (2) orofacial trauma, specifically dentoalveolar trauma. Dental pain is a common ED chief complaint, so emergency providers should be familiar with normal oral and dental anatomy to appropriately differentiate and manage dental and nondental causes of dental pain.
ORAL AND DENTAL ANATOMY
The normal adult dentition consists of  permanent teeth. The adult dentition has four types of teeth:  incisors,  canines,  premolars, and  molars. The primary or deciduous dentition consists of  teeth of three types:  incisors,  canines, and  molars. Figure 245­1 shows the eruptive pattern of both the primary and permanent dentition. Figure 245­2 illustrates the most commonly used tooth numbering system; however, description of the tooth type and location is also appropriate.
FIGURE 245­1. Normal eruptive patterns of the primary and permanent dentition. mo. = month; yr. = years.

FIGURE 245­2. Chapter 245: Oral and Dental Emergencies, Ronald W. Beaudreau 
. Terms of Use * Privacy Policy * Notice * Accessibility
Tooth numbering system.
ANATOMY OF THE TEETH
A tooth consists largely of dentin, which surrounds the pulp, the tooth’s neurovascular supply (Figure 245­3). Dentin is a homogeneous material produced by pulpal odontoblasts throughout life. Dentin is deposited as a system of microtubules filled with odontoblastic processes and extracellular fluid. The crown, or the visible portion of tooth, consists of a thick enamel layer overlying the dentin. Enamel, the hardest substance in the human body, consists largely of hydroxyapatite and is produced by ameloblasts before eruption of the tooth into the mouth. The root portion of the tooth extends into the alveolar bone and is covered with a thin layer of cementum.
FIGURE 245­3. The dental anatomic unit and attachment apparatus.
THE NORMAL PERIODONTIUM
The periodontium, or attachment apparatus, is essential for maintaining the integrity of the dentoalveolar unit. The attachment apparatus consists of a gingival component and a periodontal component. The gingival component includes the junctional epithelium, gingival tissue, and gingival fibers and primarily functions to maintain the integrity of the periodontal component. The periodontal component includes the periodontal ligament, alveolar bone, and cementum of the root of the tooth and forms most of the attachment apparatus. Disease states such as gingivitis and periodontal
 disease weaken and destroy the attachment apparatus, resulting in tooth mobility and tooth loss.
Gingival tissue is keratinized stratified squamous epithelium. It can be divided into the free gingival margin and the attached gingiva. The free gingiva is the portion that forms the 2­ to 3­mm­deep gingival sulcus in the disease­free state. The attached gingiva adheres firmly to the underlying alveolar bone. The nonkeratinized alveolar mucosa extends from the attached gingiva to the vestibule and floor of the mouth. The mucosal tissue of the cheeks, lips, and floor of the mouth is also composed of nonkeratinized squamous epithelium.
OROFACIAL PAIN
Table 245­1 lists common causes of orofacial pain. Pain of dental origin may be diffuse in nature, presenting as a headache, sinus pain, eye pain, or jaw or neck pain, or may be localized to a single tooth. Remember to consider myocardial infarction as a cause of jaw pain.
TABLE 245­1
Differential Diagnosis of Orofacial Pain
Nontraumatic Causes of Potential Dental Pain
Odontogenic origin
Tooth eruption Cracked tooth syndrome
Pericoronitis Periradicular periodontitis
Dental caries Periapical abscess/facial space infection
Dentinal sensitivity/cervical erosion Postextraction discomfort
Reversible pulpitis Postextraction alveolar osteitis
Irreversible pulpitis Postrestorative pain
Periodontal pathology
Gingivitis Periodontal abscess
Periodontal disease Acute necrotizing gingivostomatitis
Gingival abscess Peri­implantitis
Neurogenic/neurophysiologic syndromes
Trigeminal neuralgia Bell’s palsy
Other cranial neuralgias Temporomandibular disorder
Nondental infections
Oral candidiasis Hand­foot­and­mouth disease
Herpes simplex types  and  Sexually transmitted infections
Varicella­zoster Herpangina
Mumps Sinusitis
Sialadenitis Parotitis
Malignancies
Squamous cell carcinoma Leukemia
Kaposi’s sarcoma Melanoma
Lymphoma
Other etiologies
Aphthous ulcers Pyogenic granuloma
Traumatic ulcers Lichen planus
Stomatitis and mucositis Cicatricial pemphigoid
Uremia Pemphigus vulgaris
Vitamin deficiency Erythema multiforme
Radiation/chemotherapy related Crohn’s disease
Benign migratory glossitis Behçet’s syndrome
Orofacial Trauma
Dental fractures Alveolar ridge fractures
Subtle enamel cracks/infractions Facial bone fractures
Dental crown and/or root fractures Oral soft tissue lacerations
Dental luxations and avulsions
Use a systematic approach for examination of the oral cavity. If not contraindicated, examine the patient in the sitting position with the head supported. First, evaluate the general condition of the patient, including speech, ability to swallow oral secretions, and any obvious swelling or asymmetry of the head and neck. Next, examine the oral soft tissue using a tongue depressor to expand your view, looking specifically at the inner lips, the buccal and labial mucosa, the hard and soft palate, and the tongue and floor of the mouth. Ask the patient to extend the tongue, and gently grasp it with a piece of dry gauze, further extending it to the right and to the left, to expose each base. The floor of the mouth should be palpated with a finger in the mouth and one externally under the chin to check for a mass or lesion. Examine the teeth visually, and then gently percuss the suspected teeth with a firm clean object to determine if a specific tooth is the source of pain. If the patient has experienced trauma, test each tooth for mobility and tenderness with gentle pressure and percussion. Check that all the teeth occlude as normal for the patient. Assess the degree of opening of the mouth.
Palpate for potential fractures of the mandible of maxilla. Finally, evaluate the temporomandibular joint by placing your index fingers in the ears and feeling for crepitance or popping while the mandible is fully opened and closed.
PAIN OF ODONTOGENIC ORIGIN
TOOTH ERUPTION AND PERICORONITIS
Discomfort is commonly associated with the eruption of primary or deciduous teeth in infants. Gingival irritation (86.18%), irritability (68.19%), and drooling (55.72%) are commonly associated findings. Teething infants may have a mildly elevated temperature, but it is rarely high enough to be
 characterized as fever. Eruption of permanent teeth, especially third molars, or wisdom teeth, may cause pain. Gingival irritation and inflammation associated with tooth eruption are common and must be distinguished from pericoronitis. Pericoronitis is inflammation of the operculum: the gingival tissue overlying the occlusal surface of an erupting tooth. Impaction of food and debris beneath the operculum results in a severe inflammatory response. Without intervention, this progressive inflammatory process will result in localized infection. Because of the close proximity of the masticator space (composed of the masseteric space, pterygomandibular space, and the superficial and deep temporalis space) to third molars, this infection can cause trismus. If the infection spreads into the connecting parapharyngeal spaces, it can be life threatening. Treatment of mild to moderate pericoronitis without associated systemic symptoms consists of appropriate oral antibiotic therapy; local irrigation of food and debris from underneath the operculum; saline mouth rinses; and analgesia with NSAIDs and opiates as appropriate. See Table 245­2 for appropriate antibiotics for outpatient treatment of dental and oral infections. More severe cases may require IV antibiotics and admission; see masticator space infections in
Chapter 243, “Face and Jaw Emergencies,” for more information. For outpatient management, referral to a general dentist or an oral and maxillofacial
,4 surgeon within  to  hours is appropriate.
TABLE 245­2
Appropriate Oral Antibiotics for Management of Dental and Oral Infections
Antibiotic Adults Dosage Pediatric Dosage
Amoxicillin 500 milligrams  times daily for  d .5 milligrams/kg
 times daily
Augmentin 875 milligrams  times daily for  d .5 milligrams/kg
 times daily
Clindamycin 300 milligrams  times daily for  d 7–10 milligrams/kg
 times daily
Metronidazole 500 milligrams  times daily for  d 5–10 milligrams/kg
 times daily
Doxycycline 100 milligrams  times daily for  d  milligrams/kg  times daily (not recommended <8 y old)
DENTAL CARIES AND PULPITIS
Dental caries is the loss of integrity of the tooth enamel from hydroxyapatite dissolution by prolonged exposure to the acidic metabolic by­products of plaque bacteria. Caries most commonly occur in areas where plaque accumulates such as pits and fissures of the occlusal surface, interproximally, and along the gingival margins. When a sufficient breach of enamel integrity occurs, and the dentin is involved, caries spread along dentinal microtubules.
Direct communication between the oral environment and the vital dental pulp is established, and sensitivity to cold or sweet stimulus may result.
The pulpal inflammatory process is initially reversible, but with continued stimuli, the pulp’s ability to respond and repair is compromised. Irreversible pulpitis can be distinguished from reversible pulpitis by the duration of symptoms. In reversible pulpitis, the duration of pain is short, lasting seconds, as compared with irreversible pulpitis, in which the pain may last for minutes to hours. The most common stimulus is heat or cold, although sweet or sour stimuli also can elicit pain. Irreversible pulpits may also present as spontaneous tooth pain; however, this is more commonly associated with
 pulpal necrosis. Authors of a systematic review published in 2016 concluded that there is insufficient evidence to determine if antibiotics reduce pain
 when used to treat irreversible pulpitis, in the absence of obvious infection. A local anesthetic block, as discussed in this chapter’s section on dental local anesthesia, greatly reduces pain and should be considered for short­term pain management. NSAIDs with or without acetaminophen as an adjunct are recommended by the American Dental Association over narcotics for managing dental pain because NSAIDs offer the most favorable
 balance between pain reduction and potential harms. The definitive treatment for irreversible pulpitis and pulpal necrosis is root canal therapy or dental extraction.
CRACKED TOOTH SYNDROME
Cracked tooth syndrome is an incomplete fracture of a tooth that may extend into the vital pulp. Molars are most commonly affected. The patient experiences sharp pain on chewing that resolves when chewing ceases. Cold and sweet stimuli may also evoke pain. NSAIDs are frequently effective at
,4 temporarily controlling pain. The patient should avoid chewing on the affected side and see a dentist for definitive treatment.
PERIRADICULAR PERIODONTITIS
Acute periradicular periodontitis is the extension of pulp disease, inflammation, or necrosis into the tissues surrounding the root and apex of the tooth (deepest portion of the tooth socket). Occasionally it can be due to occlusal trauma. Periradicular lesions appear as a slight widening of the periodontal ligament space, a thinning of the lamina dura, or a radiolucent area associated with the root apex on a periapical dental radiograph. A
 panorex is not typically useful for periradicular periodontitis but can be important in identifying other painful osseous pathology (Figure 245­4).
FIGURE 245­4. The radiographic appearance of a healthy tooth with a normal periodontal ligament space and distinct lamina dura (A) compared with the radiographic appearance of periapical radiolucency (arrows) consistent with periradicular periodontitis, a periapical abscess, or periradicular cyst (B).
[Image used with permission of Gary M. Beaudreau.]
Pain on percussion of the suspected tooth with a light metal instrument, such as a handle of a dental mirror, helps to identify the offending tooth.
Radiographically and clinically indistinguishable from periradicular periodontitis, a periapical abscess by definition contains a collection of pus. A small swelling of the gingiva with a draining fistula adjacent to the affected tooth is known as a parulis and can help identify the involved tooth (Figure
245­5). If a dental abscess erodes through the cortical bone but does not drain spontaneously, then subperiosteal extension results in intraoral or
,7 facial swelling and fluctuance that should be incised and drained. Treat dental abscesses or other periapical lesions with appropriate antibiotics

(Table 245­2). NSAIDs with or without supplemental acetaminophen are preferred over opiates by the American Dental Association for pain relief.
Refer to a dentist for definitive treatment.
FIGURE 245­5. A parulis (arrow) superior to the maxillary molar. [Image used with permission of David E. Beaudreau.]
FACIAL SPACE INFECTIONS
Spread of odontogenic infections into the various facial spaces is relatively common. Buccal extension of a periapical infection of the mandibular teeth will involve the buccinator space. Maxillary labial extension of infection primarily will involve the infraorbital space. Perforation through the lingual cortical bone of mandibular molars, particularly the second and third molars, usually occurs below the mylohyoid ridge and involves the submandibular space. Lingual spread of periapical infections associated with mandibular anterior teeth will affect the lingual space. The submandibular space and lingual space communicate with each other at the posterior border of the mylohyoid muscle. Cellulitis of bilateral submandibular spaces and the lingual space is called Ludwig’s angina and is potentially life threatening. As these spaces and the masticator space communicate directly with the parapharyngeal space, airway compromise is the immediate concern. For detailed discussion, see Chapter 243, “Face and Jaw Emergencies,” and Chapter 246, “Neck and Upper Airway.”
Infection of the infraorbital space may have a potentially devastating outcome if retrograde spread through the ophthalmic veins occurs and the cavernous sinus becomes involved.
POSTEXTRACTION PAIN
Immediate postoperative pain is most commonly related to the trauma of surgery. Postoperative edema, such as with extraction of third molars, peaks within the first  to  hours and is best managed with ice packs and elevation of the head of the bed to  degrees. NSAIDs are preferred over oral
 narcotics for pain. Trismus, common immediately after extraction, is usually the result of postoperative inflammation. It can also be caused by direct trauma to the temporomandibular joint or the muscles of mastication during the surgical procedure or during administration of the inferior alveolar injection. Trismus peaks in the first  hours and usually decreases thereafter unless infection develops. Progressively worsening trismus is concerning for a postoperative infection.
POSTEXTRACTION ALVEOLAR OSTEITIS (DRY SOCKET)
Postextraction alveolar osteitis, or dry socket, usually occurs on the second or third postoperative day and is associated with exquisite oral pain.
Total or partial displacement of the clot from the socket or fibrinolytic dissolution of the clot results in exposure of the alveolar bone and initiates a localized osteomyelitis of the exposed bone. Risk factors for developing postextraction alveolar osteitis include smoking, preexisting pericoronitis or
8­10 periodontal disease, a traumatic extraction, a prior history of alveolar osteitis, and hormone replacement therapy. The incidence of postextraction
 alveolar osteitis is 1% to 5% of all extractions but is considerably higher (up to 30%) among impacted third molar extractions.
It is generally agreed that the goal of treatment of alveolar osteitis is pain management until healing occurs. Gentle irrigation of the socket with warmed saline or chlorhexidine .12% oral rinse to remove debris is recommended. Intrasocket placement of various available medicaments is controversial,
,9 and two systematic reviews concurred that there is insufficient evidence to support one method of treatment over another. Antibiotics may be
 8­10 indicated if there are systemic signs of infection (Table 245­2). Refer for dental follow­up.
POSTEXTRACTION BLEEDING
Postextraction bleeding is not uncommon. Displacement of the clot may result in recurrent or continued bleeding. Generally, firm pressure applied to the extraction site is adequate to control bleeding. This is best accomplished by folding a  × 2–inch gauze pad and placing it over the extraction site and applying firm pressure by clenching with the opposing teeth. Pressure must be held firmly, not a chewing action, for  minutes or until hemostasis is complete. If direct pressure is not successful, then apply an absorbable gelatin sponge (Gelfoam®, Pfizer Inc., New York, NY), microfibrillar collagen (Avitene®, Davol, Inc., Warwick, RI), or regenerated cellulose (Surgicel®, Ethicon, Inc., Somerville, NJ) into the socket to provide a matrix for clot formation. Pressure can also be applied with a gauze pad soaked with tranexamic acid. When using any of these agents, continue to maintain pressure for  to  minutes. Sutures can be used for holding such agents in place or to loosely close the gingiva over the socket. Do not suture the gingiva tightly because this may cause necrosis of the gingival flap. If the above techniques are not successful, careful injection of the soft tissue surrounding the extraction with lidocaine with epinephrine may control the bleeding. Careful cautery with silver nitrate can also be useful. If bleeding continues, then oral and maxillofacial surgical consultation is necessary.
POSTRESTORATIVE PAIN
Postrestorative pain can result from normal trauma from mechanical instrumentation of the tooth or direct exposure of the pulpal tissue during instrumentation. Pain associated primarily with mastication may be the result of improper occlusion of the new dental restoration or filling. After endodontic therapy, buildup of pressure in the pulpal chamber can cause severe pain. Provide NSAIDs or narcotic analgesia and refer to the patient’s dentist. Temporary prolonged pain relief can also be obtained using .5% bupivacaine with epinephrine and the appropriate dental anesthetic block as discussed in the dental local anesthesia technique section of this chapter. Follow up with the dentist the next day.
ORTHODONTIC APPLIANCES
The most common emergency is a broken or bent wire that is irritating or lacerating the cheek or lip. This wire needs to be bent back away from soft tissue. This can easily be accomplished with dental instruments, or something soft such as a pencil eraser can be used to gently bend the wire. Cutting the wire is generally not indicated because it makes the end sharper. The broken portion of the wire can be removed in its entirety by removing the rubber ligatures from each orthodontic bracket, but this generally is not necessary. The patient should follow up as soon as possible with the orthodontist.
PERIODONTAL PATHOLOGY
Periodontal disease is a continuum of disease that begins with gingival inflammation and bleeding, or gingivitis, and can progress to destruction of the periodontal attachment apparatus, deepening of the normal gingival sulcus, periodontal pocket formation, bone loss, tooth mobility, and ultimately
 loss of teeth. Besides oral hygiene, many factors including hormonal variations, medications, and systemic disease can also influence periodontal health.
Periodontal disease usually progresses painlessly but may present as swollen gingival tissue or gingival bleeding. Treatment is directed at slowing or
 arresting the progression of disease primarily by the removal of plaque and its by­products. Antibiotics may play a role in treatment. Referral to a dentist for definitive treatment is indicated because the treatment involves extensive dental cleaning, instruction and improvement in oral hygiene, and in some cases, periodontal surgery.
GINGIVAL AND PERIODONTAL ABSCESS
A gingival abscess is an acutely painful swelling confined to the margin of the gingiva or interdental papilla. It usually rapidly enlarges over  to  hours, and purulent exudate can frequently be expressed from the orifice. The most common etiology is the entrapment of foreign matter such as a popcorn kernel, piece of meat, toothbrush bristle, or piece of food in the gingiva. Treatment includes identifying and removing the embedded foreign
,3 body and irrigating with normal saline. Continued home irrigation is beneficial, and symptoms resolve quickly.
When plaque and debris are entrapped in the periodontal pocket, a periodontal abscess may form, resulting in severe pain. Small periodontal abscesses respond to local therapy with warm saline rinses and systemic antibiotics (Table 245­2). Larger periodontal abscesses require incision and
,3,4 drainage. Chlorhexidine .12% mouth rinses twice daily are useful in the short term. Provide analgesia with NSAIDs, which are preferred over
 narcotics.
ACUTE NECROTIZING ULCERATIVE GINGIVITIS
Acute necrotizing ulcerative gingivitis is an aggressively destructive process (Figure 245­6). Also known as Vincent’s disease or trench mouth, it is part of a spectrum of disease ranging from localized ulceration of the gingiva to fatal noma (cancrum oris), in which localized ulceration and necrosis
,3,4,11,12 spread to the adjacent tissues of the cheeks, lips, and underlying facial bones. The diagnostic triad includes pain, ulcerated or “punched out” interdental papillae, and gingival bleeding. Secondary signs include fetid breath, pseudomembrane formation, foul metallic taste, tooth mobility,
,3,11,12 lymphadenopathy, fever, and malaise.
FIGURE 245­6. Acute necrotizing ulcerative gingivitis. [Image used with permission of Philip J. Hanes.]
The differential diagnosis for acute necrotizing ulcerative gingivitis is quite extensive, but herpes gingivostomatitis is the most difficult to differentiate.
Herpes gingivostomatitis usually has smaller vesicular eruptions, less bleeding, more systemic signs, and lack of interdental papilla
,3,11,12 involvement.
The cause is still poorly understood. Acute necrotizing ulcerative gingivitis appears to be an opportunistic infection in a host with lowered resistance.
Anaerobic bacteria such as Treponema, Selenomonas, Fusobacterium, and Prevotella invade otherwise healthy tissue, resulting in an aggressively
,3,11,12 destructive disease process. The most important predisposing factors are human immunodeficiency virus infection and a previous episode of necrotizing gingivitis. Other contributing factors include poor oral hygiene, unusual emotional stress, poor diet and malnutrition, inadequate sleep,
,3,11,12
Caucasian descent, young age (early 20s), poor socioeconomic status, recent illness, alcohol use, and tobacco use.
Treatment consists primarily of bacterial control. Chlorhexidine .12% oral rinses twice a day and professional debridement and scaling are the mainstay of treatment. Adjunctive antibiotic therapy with metronidazole (Table 245­2) is reserved for the immunocompromised or those with signs of systemic infection. Reduction in pain can be expected within  hours of institution of this regimen. Identification and resolution of the predisposing factors and supportive therapy with a soft diet rich in protein, vitamins, and fluids are important in establishing and maintaining a disease­free
,3,11,12, state.
PERI­IMPLANTITIS
Osseointegrated dental implants have become common over the past  years, allowing for a dental implant to replace a tooth. Pathologic changes around an implant are all given the general term of peri­implant disease. Patients who present with peri­implantitis, a general term describing postprocedure pathologic changes, manifest similar symptoms to a periodontal abscess and require similar treatment. Gentle removal of the plaque and debris from around the implant and irrigation with normal saline or .12% chlorhexidine solution should be done. Give analgesia as needed and
,4,13 refer to a dentist for definitive care.
SPECIAL CONSIDERATIONS: NEUROGENIC AND NEUROPHYSIOLOGIC SYNDROMES
See Chapter 172, “Acute Peripheral Neurologic Disorders,” for management of Bell’s palsy.
CRANIOFACIAL NEURALGIAS
Trigeminal neuralgia is the most common of the craniofacial neuralgias. Other significantly less common neuralgias of the craniofacial region include glossopharyngeal neuralgia, vagal neuralgia, and superior laryngeal neuralgia involving the respective nerve distributions. Post–herpes zoster–related neuralgia is also a cause of acute facial pain and may become chronic in nature. See Chapter 165, “Headache,” for further discussion.
TEMPOROMANDIBULAR DISORDER
Temporomandibular disorder is a common cause of facial pain and headache representing a group of signs and symptoms that involve the muscles of mastication or the temporomandibular joint. See Chapter 243, “Face and Jaw Emergencies,” for management.
CAVERNOUS SINUS THROMBOSIS
Cavernous sinus thrombosis may present in association with an odontogenic infection with the additional symptoms of headache with or without vomiting, or the patient may rapidly deteriorate with meningeal signs, sepsis, and coma. Contrasted CT imaging may facilitate early recognition. See
Chapter 174, “Central Nervous System and Spinal Infections,” for management.
SOFT TISSUE LESIONS OF THE ORAL CAVITY
RECURRENT APHTHOUS STOMATITIS
Recurrent aphthous stomatitis, or ulceration, is one of the most common oral lesions (Figure 245­7). Recurrent aphthous stomatitis by definition is idiopathic; therefore, other underlying causes such as trauma, vesiculobullous disease, medications, nutritional deficiencies, hematologic disorders, and fever syndromes must be considered. The etiology is multifactorial, involving physiologic interactions between the immune system and genetic and environmental factors. Aphthous ulceration involves the nonkeratinized epithelium, especially the labial and buccal mucosa, and begins as an erythematous macule that ulcerates and forms a central fibropurulent eschar. Aphthous stomatitis occurs in three forms. Minor aphthae usually measure <10 mm in diameter, are painful, and frequently are multiple. They usually resolve spontaneously in  to  days. Major aphthae have larger
(>10 mm), deeper ulcers that take significantly longer to heal. The third form, called herpetiform aphthae, has up to 100 ulcers, each  to  mm in diameter. They tend to coalesce, creating much larger ulcers that require  to  days to heal. Treatment is primarily symptomatic. Several medications are effective in decreasing pain and increasing the rate of healing. Topical agents such as chlorhexidine .2% mouth rinse, anesthetic agents, and steroids applied topically or as a mouth rinse should be the first­line therapy. Commercially available bioadhesive pastes such as Orobase®
(Colgate Oral Pharmaceuticals, Canton, MA), which contains both corticosteroids and anesthetic agents, are effective. In more resistant cases, systemic
 steroids are indicated.
FIGURE 245­7. Aphthous stomatitis. [Image used with permission of Baldev Singh.]
HERPES ZOSTER AND OTHER INFECTIONS
Herpes zoster frequently occurs along the distribution of the trigeminal nerve (see Chapter 154, “Serious Viral Infections,” for management). Isolated intraoral lesions can occur but are not common. Involvement of the ophthalmic branch of the trigeminal nerve requires urgent ophthalmologic
,15 consultation (see Chapter 241, “Eye Emergencies”).
Other common infections such herpes simplex types  and , herpangina, hand­foot­and­mouth disease, and varicella­zoster virus cause painful ulcerative lesions of the oral cavity and perioral region. These conditions are adequately discussed in Chapter 124, “Mouth and Throat Disorders in
Infants and Children.” Many sexually transmitted infections can affect the oral cavity. In general, the appearance of oral lesions is similar in appearance
,15 to that of their genital counterpart. Treatment of sexually transmitted diseases of the oral cavity is the same as for genital involvement. See Chapter
153, “Sexually Transmitted Infections,” for detailed discussion.
TRAUMATIC ULCERS
Traumatic ulcers are a result of direct trauma to epithelial tissue. Common sources of trauma include rough or jagged edges on teeth or restorations, ill­fitting dentures, oral hygiene mishaps, and burns to the hard or soft palate secondary to hot foods. Removal of persistent sources of trauma is essential; otherwise, treatment is palliative.
MEDICATION­RELATED SOFT TISSUE ABNORMALITIES
Gingival hyperplasia is associated with many commonly used medications (Figure 245­8). Three classes of drugs have been identified as causal: anticonvulsants, calcium channel blockers, and immunosuppressants. Phenytoin, nifedipine, and cyclosporine exhibit the strongest association.
Concomitant use of two such medications results in accelerated gingival proliferation. Enlargement begins in the interdental papillae. Regardless of medication, the clinical and histologic characteristics of gingival hyperplasia appear to be identical. The clinical appearance of the gingival tissue depends on oral hygiene and secondary inflammation. In the absence of inflammation, gingival proliferation results in dense tissue, normal in coloration, with a smooth, stippled, or granular texture. Inflammation causes edematous changes and an erythematous coloration. Inflamed tissue bleeds readily. Histologically, an increase in collagen fibers, fibroblasts, and glycosaminoglycans is seen. Epithelial acanthosis also occurs. Although the cause of drug­related gingival hyperplasia is unclear, poor oral hygiene clearly increases its likelihood and severity. Treatment includes fastidious
 oral hygiene to slow the hyperplasia and gingivectomy in advanced cases.
FIGURE 245­8. Gingival hyperplasia (overgrowth) secondary to phenytoin (Dilantin®). [Used with permission of Philip J. Hanes.]
Many other medications and diseases are known to cause abnormalities of the oral mucosa or dental structures. Allergic mucositis, erythema multiforme, and fixed drug­type reactions are examples. Xerostomia and associated mucosal alterations are a side effect of many medications such as
,16 anticholinergics, antidepressants, and antihistamines. Stomatitis and mucosal ulcerations from chemotherapeutic agents are also common.
LESIONS OF THE TONGUE
Many systemic conditions and local stimuli affect the appearance of the tongue. Various vitamin deficiencies and iron deficiency anemia cause atrophy of the filiform papillae, resulting in a smooth erythematous appearance. Occurrence of ectopic thyroid tissue on the midline posterior portion of the tongue is called a lingual thyroid and is a common finding. Some common conditions affecting the tongue are discussed in the following sections.
BENIGN MIGRATORY GLOSSITIS
Geographic tongue, or benign migratory glossitis, is a common benign finding on oral examination, occurring in 1% to 3% of the population. Typically, multiple areas of erythema on the tongue, caused by atrophy of the filiform papillae, are surrounded by well­demarcated zones of hyperkeratotic plaques. The lesions concentrate on the tip and dorsolateral aspect of the tongue and heal in several days, only to quickly reappear in other areas.
These lesions usually are asymptomatic; however, a burning sensation or sensitivity to hot or spicy foods has been described. The cause is unknown, but an association with psoriasis, allergies, stress, diabetes, and anemia is reported. Generally, treatment is not indicated because this entity is benign.
Reassurance of patients is usually sufficient. In patients in whom discomfort is a major factor, oral topical steroids such as fluocinonide gel applied
 several times daily may provide relief.
STRAWBERRY TONGUE
Strawberry tongue is associated with erythrogenic, toxin­producing Streptococcus pyogenes. Clinically, the tongue has prominent red spots on a white­coated background. Microscopically, the fungiform papillae are hyperemic with a smooth, glossy surface. Treatment is with antibiotics directed at group A streptococci.
LEUKOPLAKIA AND ERYTHROPLAKIA
Leukoplakia is a white patch or plaque that cannot be scraped off and cannot be classified as any other disease. Leukoplakia is the most common oral precancer. Up to 7% of lesions exhibit dysplastic changes, with an overall risk of malignant transformation of 2% to 3% per year. The cause is unknown, but tobacco, alcohol, ultraviolet radiation, candidiasis, human papillomavirus, tertiary syphilis, and trauma have all been implicated. Lesions can occur on any intraoral mucosal site but commonly affect the buccal mucosa, tongue, and floor of the mouth. Biopsy is mandatory for all persistent leukoplakic lesions. Leukoplakic lesions of the floor of the mouth, tongue, and vermilion border are most likely associated with malignancy. Lesions
,17 demonstrating dysplastic changes warrant removal at follow­up by an oral surgeon or otolarygologist.
Erythroplakia is defined as a red patch that similarly cannot be clinically or pathologically characterized as any other disease. Although erythroplakia is far less common than leukoplakia, it has a greater potential for dysplastic changes; refer for removal as with leukoplakia.
ORAL CANCER
Oral cancer accounts for 2% to 4% of the cancers in the United States. More than 90% of all oral malignancies are squamous cell carcinoma (Figure
245­9). Lymphomas, Kaposi’s sarcoma, and melanoma compose most of the remainder. Extrinsic risk factors include tobacco use, especially chewing tobacco or snuff; excessive alcohol consumption; and sunlight exposure. Intrinsic factors include immunosuppression, lichen planus, chronic oral candidiasis, human papilloma virus infection, human immunodeficiency virus infection, chronic inflammation, and nutritional deficiencies and
,17 general malnutrition.
FIGURE 245­9. Oral squamous cell carcinoma of the hard palate. [Image used with permission of H. Anthony Neal.]
Oral squamous cell carcinoma has four common morphologic presentations. Lesions can be exophytic, with an irregular surface; ulcerative, with irregular depressions and rolled borders; malignant leukoplakic; or erythroplakic. The most common site involved in oral cancer is the tongue,
,17 particularly the posterolateral and ventral surface, accounting for 50% of the oral cancers in the United States. Cancer of the floor of the mouth accounts for nearly 35%. Cancer of the lips is common and usually secondary to sunlight exposure. Oral cancer is generally painless, and patients are often unaware of the presence of a mass until it is advanced. Oral cancer lesions are usually firm, may bleed from ulceration, and have a history of poor healing. There may be associated firm lymphadenopathy. Early diagnosis is the key to successful treatment of oral squamous cell carcinoma. All ulcers, erythroplakic lesions, and leukoplakic lesions of the oral cavity that do not respond to palliative treatment in  to  days warrant biopsy by
 otolaryngology. Treatment depends on site of involvement and stage of disease.
DENTOALVEOLAR TRAUMA
Management of dentoalveolar trauma depends on the extent of tooth and alveolar involvement, the degree of development of the apex of the tooth, and the age of the patient. In injuries in younger patients, especially those who are <12 years of age, the pulp of anterior teeth is quite large, and dental fractures involving the pulp are common. Fortunately, in this age group, the apex of the root also is usually incompletely formed, allowing for a greater pulpal regenerative capability. As one ages, more dentin is formed. Thus, in older patients, the pulp chamber may be very small and pulpal exposure highly unlikely. Involvement of the root of the tooth compromises the attachment apparatus and makes it difficult to restore the tooth to function.
DENTAL FRACTURES
The International Association of Dental Traumatology system divides dental trauma into eight categories: enamel infraction, enamel fracture, enameldentin fracture, enamel­dentin­pulp fracture, crown­root fracture without pulp exposure, crown­root fracture with pulp exposure, root fracture, and alveolar bone fracture (Figure 245­10). The International Association of Dental Traumatology has developed guidelines to aid dentists and other
,19 healthcare professionals in the management of each these categories.
FIGURE 245­10. The International Association of Dental Traumatology classification of dental fractures.
The goal of the emergency treatment of a fractured tooth is maintaining pulpal vitality and completion of the formation of the root and apex of the tooth. The proximity of the fracture to the pulp and the length of time before treatment, as well as other associated injuries, are most important in determining outcome. Treatment is aimed at sealing the dentinal tubules and creating a barrier between the dental pulp and the oral environment.
,19
Because pulpal necrosis is a process, it can occur at any time after trauma, and serial follow­up with a dentist is recommended.
A fracture of the crown of the tooth can involve any part of the enamel, dentin, and pulp of the tooth. Infraction is the least serious type of dental injury and essentially is a crack in the enamel of the tooth without loss of structure. This can be obvious or quite subtle. No emergency treatment is needed.
ENAMEL FRACTURES
Enamel fractures (Ellis class I fractures) do not extend into the dentin of the tooth (Figure 245­11). Generally, no emergency treatment is indicated, except to smooth sharp corners that may irritate the tongue or mucosa. If the enamel fragment is recovered and kept moist, the patient’s dentist can bond it back in place. If the fragment was not recovered, soft tissue radiographs of any oral lacerations are necessary to rule out foreign bodies.
,19
Referral to a general dentist for aesthetic repair depends on the degree of cosmetic concern of the patient.
FIGURE 245­11. International Association of Dental Traumatology classification for fractures of teeth (clinical). A. Enamel fracture (Ellis class I). B. Enamel­dentin fracture (Ellis class II) of the central incisor on the left in the photograph (notice the pink blush of the pulp through the thin layer of dentin), and an enamel­dentin­pulp fracture of the central incisor on the right in the photograph. [Image used with permission of Felicity K. Hardwick.]
ENAMEL­DENTIN FRACTURES
Enamel­dentin fractures (Ellis class II fractures) involve the dentin of the tooth and require intervention (Figure 245­11). Generally, patients experience sensitivity to hot or cold stimuli as well as air passing over the exposed surface during breathing. The enamel­dentin fracture can be identified both by the patient’s symptoms and visualization of exposed dentin, which is a creamy yellow color compared with the whiter enamel. Because dentin is microtubular in structure, communication with the oral environment or desiccation from mouth breathing initiates an inflammatory response in the dental pulp. The thickness of remaining dentin determines the rate of pulpal contamination. Greater than  mm of remaining dentin is felt to offer some protection to the pulpal tissue. A delay in treatment of >24 to  hours increases the likelihood of pulpal necrosis. The ED goal is the identification of a fracture. If definitive treatment cannot be ensured in  to  days, then cover the exposed dentin to decrease likelihood of pulpal injury. This is best achieved using glass ionomer dental cement that is easily mixed according to the manufacturer’s instructions and carefully applied to the dried exposed dentin (DenTemp®, Majestic Drug Co., South Fallsburg, NY; and others). If the dentin layer is <0.5 mm and the pulp can be seen as a pink area without bleeding, then first place a thin layer of calcium hydroxide base (Dycal®, Dentsply International, York, PA) followed by glass
,19 ionomer, as described earlier, to further protect the dental pulp. Referral to a dentist for definitive treatment is important.
ENAMEL­DENTIN­PULP FRACTURES
In enamel­dentin­pulp fractures (Ellis class III fractures), exposure of the pulp has occurred (Figure 245­10). On wiping the fractured surface dry with sterile gauze, blood originating from the pulp of the tooth is easily identified. After carefully controlling pulpal bleeding with sterile gauze or a cotton pellet, cover the exposed pulp with a calcium hydroxide base (Dycal®, Dentsply International, York, PA), and then cover this and the remaining exposed dentin with glass ionomer cement as in enamel­dentin fractures until urgent dental evaluation can occur. If the pulpal exposure is extremely small, placing a calcium hydroxide base and glass ionomer is adequate until dental evaluation. For all but the smallest pulpal exposures, definitive treatment
,19 is some kind of endodontic or root canal therapy. Oral analgesics should be prescribed and topical analgesics avoided.
Crown­root fractures and root fractures are an uncommon consequence of dental trauma. The coronal segment of the tooth may be displaced or simply mobile. Tenderness to percussion is usual. With any dental trauma, careful attention must be paid to identifying fractures of the root, as they can be clinically obscure, and dental radiographs from several angles may be necessary to identify these fractures. This, however, is beyond the scope of most EDs. Crown­root fractures may or may not involve the pulp. Emergency treatment consists of stabilizing the coronal segment until definitive treatment can be arranged. In isolated root fractures, the pulp is always involved. Healing of stabilized root fractures has been reported; thus, current recommendations are to reposition the coronal segment to its original position, confirm that position by radiograph, if available, and then stabilize with a flexible splint as described below for luxation injuries. Dental follow­up within  to  hours is important, because splinting for a minimum of  weeks is required. In the ED, where oral surgical or dental consultation may not be readily available, extraction of an extremely mobile coronal segment
18­20 of the tooth may be required to prevent possible aspiration.
LUXATION INJURIES
The same forces that cause dental fractures may result in loosening of a tooth from the attachment apparatus. Careful evaluation of the teeth for tenderness, malpositioning, or mobility must be performed. There are six types of luxations: concussion, subluxation, extrusive luxation, lateral
,19 luxation, intrusive luxation, and avulsion.
Concussion is injury to the supporting structures of a tooth with clinical tenderness to percussion but no mobility. Subluxation is injury resulting in mobility without clinical or radiographic evidence of dislodgement of the tooth. Extrusive luxation is partial or total disruption of the periodontal ligament resulting in a partial dislodgement of a tooth from the alveolar bone. Lateral luxation is displacement of a tooth labially (toward the lip) or lingually (toward the tongue) with concomitant fracture of the alveolar bone. Intrusive luxation is displacement of a tooth into its socket with associated periodontal ligament damage and alveolar bone contusion and fracture. Treatment of luxations depends on the tooth involved, the severity
,19 of injury, and the presence of associated root fracture and/or significant associated alveolar fracture.
CONCUSSIONS
A concussive injury to a tooth is minor. The degree of tenderness to percussion determines the treatment. Stabilizing the tooth by splinting it to adjacent teeth is not indicated. Management of pain with NSAIDs, soft diet, and referral to a dentist to confirm the diagnosis and exclude more severe
,19 injury constitute the most appropriate course of action for the emergency physician.
LUXATIONS
Subluxation represents a more significant injury than concussion and is associated with a higher incidence of subsequent pulpal necrosis. Clinically,
,19 tooth mobility and some bleeding along the gingiva may be noted. A subluxed tooth generally does not require splinting.
An extrusive luxation requires repositioning the tooth to its original position and splinting to stabilize the tooth during healing. Ideally, dental radiographs should be obtained prior to repositioning the tooth to ensure that there is not a fracture of the root of the tooth, but in most EDs, this may not be possible, and repositioning and stabilizing should be attempted regardless. Repositioning the tooth may require local anesthesia. Firm, gentle pressure usually will reposition the tooth. If a clot has formed apical to the tooth, then more aggressive manipulation may be required. Splints made
,19,21 with flexible wire, nylon line, or bondable fiber mesh ribbon provide ideal stabilization. If unavailable in the ED, a temporary splint with a
™ noneugenol zinc oxide periodontal dressing (Coe­Pak , GC America Inc., Alsip, IL; or ZONE Periopak®, DUX Dental, Oxnard, CA) (Figure 245­12) is acceptable. Avoid excess material placement, especially on the occlusal surface, because interference in occlusion will place stress on the tooth during mastication. The patient should see a dentist or oral and maxillofacial surgeon within  hours.
FIGURE 245­12. Temporary stabilization of a replanted or repositioned tooth. A. Tooth is repositioned back into its original position in the socket. B. Splint material is mixed thoroughly. C. Splint material is shaped and made ready for application. D. Packing is molded over repositioned tooth and two adjacent teeth to each side.
A lateral luxation represents a more extensive injury and is associated with fracture of the surrounding alveolar bone. Repositioning of the tooth is generally more difficult. It usually can be accomplished by manipulating the displaced tooth with the thumb and forefinger. Once the apex has been dislodged from its locked­in position labially, apically directed axial pressure will reposition the tooth. Intra­arch stabilization is necessary for a minimum of  weeks. Temporary splinting with a periodontal dressing is acceptable if a minimal associated alveolar fracture occurred. Otherwise,
,19,21 splinting by an oral and maxillofacial surgeon or general dentist in the ED is mandatory.
Intrusive luxations are the most serious because significant damage to the alveolar socket and periodontal ligament occurs. Root resorption is common as a result of damage to the periodontal ligament. Recommended treatment is allowing the tooth to erupt on its own or to orthodontically
,19,21 extrude the tooth if no eruption is noted by  weeks.
All patients who sustain luxation injuries should be instructed to maintain a soft diet for at least  weeks. Meticulous oral hygiene is essential. Twicedaily rinsing with chlorhexidine .12% mouth rinse is helpful. Referral to a dentist for close follow­up is indicated.
AVULSIONS
Tooth Replantation and Care at the Scene
,23
Total displacement of a tooth from its socket, or avulsion, is a true dental emergency. Replantation at the scene is the treatment of choice because the long­term prognosis for the replanted tooth is highly time dependent. Ideally, the patient or a healthcare provider at the scene should perform this procedure. Handling only the crown portion of the tooth, gently rinse the tooth for a maximum of  seconds with sterile normal saline or tap water to remove debris. Then replace it immediately into the socket. Anterior teeth are most commonly affected. Figure 245­13 illustrates the morphology of the maxillary central incisor to assist replantation in the proper orientation. Early improper replantation holds a higher
,23 success rate for tooth salvage than delayed replantation resulting from waiting for arrival at the ED or for an oral and maxillofacial surgeon.
FIGURE 245­13. Illustration of a maxillary left central incisor in two views. Note that the part of the tooth facing medially comes to more of a right angle at the incisal edge (biting edge) than occurs distally. The facial portion of the tooth is more convex.
If immediate replantation is not possible, then transport the tooth with the patient to the ED. Acceptable transport media include isotonic solutions such as Hank’s balanced salt solution, organ transport media, sterile saline, milk, and saliva. Commercial preparations of Hank’s balanced salt solution
™ such as Save­A­Tooth® (Phoenix­Lazerus, Inc., Pottstown, PA) and EMT Tooth Saver (Smart Practice, Phoenix, AZ) are available and come with a useful
 transport container as part of the system.
Survival of the periodontal ligament fibers that remain attached to the root of an avulsed tooth is key to successful replantation. Milk is an acceptable storage medium because of its osmolarity and essential concentration of calcium and magnesium ions, and compares favorably with Hank’s balanced
 salt solution, which maintains periodontal ligament cell viability for up to  to  hours.
Tooth Replantation in the ED
In the ED, before replantation, rinse the tooth root clean of dirt and debris with sterile saline or, preferably, Hank’s balanced salt solution. Do not scrub the root of the tooth, and do not disrupt existing periodontal fibers. Handle only the crown of the tooth. If an avulsed tooth with an open apex has been dry for <20 minutes, then the prognosis for reestablishing a vital pulp is good. If the tooth has been dry from  to  minutes regardless of apices, soak the tooth in a physiologic solution while preparing to replant the tooth. Physiologic solution decreases the chance of ankylosis (fixation of the tooth to the underlying bone). For an avulsed tooth that has been dry for >60 minutes, the periodontal cells are dead, and the goal is to maintain alveolar bone contour and aesthetics; however, ankylosis, root resorption, and eventual tooth loss are the expected outcome. Table 245­3 provides
.23,25 specific recommendations. Dentists manage avulsed immature permanent teeth (patients age  to  years) differently than avulsed mature permanent teeth, but care of avulsed teeth in the ED prioritizes rapid replacement to preserve function. If the avulsed tooth was not recovered, obtain
22­24 radiographs to ensure that the tooth was not aspirated.
TABLE 245­3
Specific Recommendations for Replantation of Avulsed Teeth
Clinical Scenario Treatment
Moist tooth stored in acceptable media, and/or <60 min extra . Gently irrigate the tooth root clean with sterile saline.
oral dry time . Administer local anesthesia.
. Remove coagulum from the socket with a stream of saline.
. Examine the socket. If there is a fracture of the socket wall, reposition it with an appropriate instrument.
. Firmly replant tooth and verify the tooth position clinically and radiographically, if possible.
. Flexible splint for up to  weeks.
Extra oral dry time >60 min or other reason suggesting . Remove from tooth attached necrotic soft tissue carefully with gauze.
nonviable cells . Administer local anesthesia.
. Remove coagulum from the socket with a stream of saline.
. Examine the socket. If there is a fracture of the socket wall, reposition it with an appropriate instrument.
. Firmly replant tooth and verify the tooth’s position clinically and radiographically, if possible.
. Flexible splint for up to  weeks.
Prepare the socket by carefully removing the clot and gently irrigating with sterile normal saline. Avoid socket manipulation if possible. However, any fracture of the socket wall should be carefully repositioned with an appropriate instrument. Local anesthesia is usually required. Replantation is accomplished with firm pressure. Having the patient bite on gauze until more permanent stabilization can be arranged is acceptable. Stabilization of the tooth in the ED with a flexible splint or temporary splinting such as a periodontal dressing (Figure 245­12) is necessary until follow­up with an oral
21­23 and maxillofacial surgeon.
Treatment with systemic antibiotics is controversial but still recommended because experimental studies show benefit. Doxycycline is the preferred antibiotic choice. For children <12 years old, amoxicillin is acceptable (Table 245­2). Tetanus prophylaxis is necessary if the tooth has been contaminated by soil and the tetanus status is uncertain. Posttreatment instructions for most dental trauma are essentially the same. Patient should be instructed to maintain a soft diet for  weeks, brush carefully with a soft toothbrush after each meal, and use chlorhexidine .12% mouth rinse twice a
,23,25 day. Follow­up should be facilitated with a dentist in  week.
SPECIAL CONSIDERATIONS WITH LUXATION INJURIES
SEQUELAE OF LUXATION INJURIES
Posttraumatic sequelae are variable. Pulp canal obliteration, pulpal necrosis, internal and external resorption of the root, and ankylosis may occur.
The severity of luxation or avulsion is the most important determining factor in sequela occurrence. Transient apical breakdown occurs with all types of luxations, but is especially common with extrusive and lateral luxations and avulsions. Extrusive luxated teeth commonly undergo pulpal necrosis within .5 years of the traumatic event. Close dental follow­up is essential for early identification of these sequelae.
ALVEOLAR RIDGE FRACTURES
Significant force must occur to dislodge or fracture teeth; consequently, associated alveolar ridge fracture is common. Care to ensure the integrity of the maxilla and mandible is also important. Stabilization of repositioned alveolar segments and associated teeth is essential for optimal results. This is best accomplished with flexible fixation placed by a general dentist or oral surgeon. Stabilization is maintained for up to  weeks depending on the severity of the involvement of alveolar bone. With significant alveolar ridge fracture, segments may require intermaxillary stabilization for up to 
,23 weeks in order to ensure adequate healing.
LUXATION INJURIES OF PRIMARY TEETH
Avulsion or luxation injuries of primary teeth are treated differently from those of permanent teeth. In patients age  to  years old, dentition is mixed, so it is very important to distinguish primary from permanent teeth. Avulsed primary teeth are never replanted. Most luxation injuries in children require no treatment and heal spontaneously. However, severe luxations of primary teeth generally require extraction of the tooth. Repositioning or replanting primary teeth risks injuring the underlying permanent teeth and thus is avoided. Intruded primary teeth are generally left alone to reerupt into normal position. Because of the risk of damage to the permanent dentition, unless there is occlusal interference or the risk of aspiration, a dentist should manage most complicated luxation injuries of primary teeth. Referral to a dentist for follow­up is essential to ensure optimal long­term
### .27 outcome.
SOFT TISSUE TRAUMA
ORAL CAVITY MUCOSAL LACERATIONS
Traumatic injuries to the soft tissue of the oral cavity are common and can involve any of the soft tissues of the mouth. Appropriate treatment remains an area of controversy. Generally, because of the vascularity of the oral tissue, lacerations of the mouth heal quickly. See the “Intraoral Mucosal
Lacerations” section of Chapter , “Face and Scalp Lacerations,” for management recommendations. Lacerations involving the cheek or buccal mucosa must be examined carefully for involvement of Stensen’s duct, which drains the parotid salivary gland (the duct opens into the mouth opposite the upper second molar). If Stensen’s duct is compromised, repair by an oral and maxillofacial surgeon or otolaryngologist is indicated. Likewise, lacerations to the floor of the mouth require careful evaluation for involvement of Wharton’s duct of the submandibular salivary glands.
LIP LACERATIONS
Lip lacerations are a potential cosmetic problem, so careful closure is essential (see Chapter , “Face and Scalp Lacerations,” for management
 recommendations).
FRENULUM LACERATIONS
Laceration of the maxillary labial frenulum, unless unusually large, does not require repair. Because such lacerations can be very painful, scheduled

NSAIDs are recommended. Because of the vascularity of adjacent tissue, lacerations to the lingual frenulum of the tongue may need repair. An absorbable suture such as 4­0 chromic gut or Vicryl® is appropriate.
TONGUE LACERATIONS
Lacerations of the tongue require special consideration because bleeding and delayed swelling can compromise the airway. Simple linear lacerations <1 cm involving the central portion of dorsal surface of the tongue and that do not gape open heal well without repair.
Except for the most extensive tongue lacerations, suturing does not necessarily improve outcome or reduce morbidity. All lacerations that bisect the
 tongue require repair. Partial amputations can be successfully replanted with the appropriate microsurgical techniques.
Local anesthesia can be obtained by local infiltration or topically by placing 4% lidocaine­soaked gauze for  minutes on the laceration. Bilateral lingual nerve blocks can be used for lacerations of the anterior two thirds of the tongue that cross the midline. Repair of the tongue, especially in children, presents a special challenge, and many adjuncts such as a dental bite block or a Molt mouth prop can be helpful in keeping the mouth open. A piece of

 ×  gauze can be used to grasp the tongue.
When laceration repair is warranted, absorbable sutures such as 4­0 chromic gut or Vicryl should be used. Sutures should be placed so as to include the muscular layer and the superficial mucosal layers of the tongue. Wound edges should be approximated and closed very loosely to allow for swelling of the tongue, which can be significant. Placing a closed hemostat between the suture and the tongue while tying can help prevent overtightening of the suture. The constant motion of the tongue quickly unties sutures in the mouth, so sutures should be tied with at least four square knots. If feasible, the sutures can also be placed so that the knots are buried into the wound. All patients should be instructed to rinse several times
 daily with a saline or chlorhexidine .12% mouth rinse.
DENTAL LOCAL ANESTHESIA TECHNIQUES
Competence in dental local anesthesia is a useful skill for the emergency provider. The maxillary teeth can be anesthetized using local infiltrative or supraperiosteal techniques, which are simple to do. (See Video: Periapical Dental Block).
Video 245­1: Periapical Dental Block
Used with permission from Stacey Clark, Covenant HealthCare, Covenant Emergency Care Center, Saginaw, Michigan; Kathleen Cowling.
Play Video
ANATOMY
The trigeminal nerve is the largest cranial nerve, and although it has important motor functions, it is primarily a sensory nerve (Figure 245­14). It divides into three main branches: the ophthalmic nerve, maxillary nerve, and mandibular nerve. The maxillary nerve provides sensory innervation to the maxilla and associated structures including the maxillary teeth and gingiva and oral mucous membranes. The third division, or mandibular nerve, is the largest of the three branches. The mandibular nerve has three main divisions. The first is the long buccal nerve that provides sensory innervation to the mucosa of cheek and buccal gingiva of the mandibular molars. The second is the lingual nerve that runs superficial to the internal pterygoid muscle and innervates the anterior two thirds of the tongue, lingual gingiva, and floor of the mouth. Finally, the largest branch is the inferior alveolar nerve, which accompanies the inferior alveolar vein and artery in a neurovascular bundle passing between the ramus of the mandible and the sphenomandibular ligament to enter the mandibular canal. It divides at the region of the premolars, with the mental nerve exiting the mental foramen to innervate the soft tissue of the lip and chin and the incisal nerve continuing within the mandibular canal to innervate the teeth and gingiva.
FIGURE 245­14. The trigeminal nerve and its three main divisions.
EQUIPMENT
Specialized equipment is useful when giving dental injections, especially the inferior alveolar nerve block. Equipment includes:
A monojet aspirating dental syringe
Dental cartridges of anesthetic solution
Disposable 27­gauge, 32­mm needle
Topical anesthetic, if possible
If an aspirating dental syringe is not available, any 3­mm aspirating syringe can be used. With larger syringes, the inferior alveolar nerve block is difficult because the syringe barrel interferes with the proper positioning of the needle.
Position the patient in a dental chair or stretcher in a semi­reclined position with the head firmly against the headrest. Anticipate sudden movement of the patient. An overhead light is essential because dental injections require good visibility and control at all times to ensure safety of both the patient and the physician. If available, topical anesthetic can be applied to mucosa prior to injection to lessen the discomfort. First, dry the mucosal surface with gauze; then apply the topical gel for at least  minute prior to proceeding.
MAXILLARY INJECTIONS
Supraperiosteal Infiltration
Maxillary cortical bone is thin and porous enough to allow the diffusion of anesthetic solution to reach the apex of the root and effectively anesthetize the tooth. Figure 245­15 illustrates the supraperiosteal infiltration technique. The upper lip or cheek, depending on which tooth you are anesthetizing, is pulled up and taut. With the bevel facing toward the bone, the needle is inserted at the height of the buccal fold adjacent to the tooth.
The needle should be directed along the long axis of the tooth and inserted to the height of or slightly above the apex of the tooth. In most cases, the needle only needs to be inserted a few millimeters. Aspirate, and if negative, then slowly inject .5 to  mL of anesthetic solution. It is important to remember that the root of the canine is significantly longer than that of other teeth and that, in general, the roots of teeth are inclined in a distal
29­31 direction. The goal is to deposit the anesthesia at or above the apex of the desired tooth.
FIGURE 245­15. The supraperiosteal infiltration. A. The maxillary nerve and innervation of the maxillary teeth by the posterior superior alveolar nerve, the middle superior alveolar nerve, and the anterior superior alveolar nerve. B. With the lip or cheek pulled taut, the needle is inserted at the height of the buccal fold. Note: The two to three concentric circles of dotted lines around the needle tip indicate the area where the anesthesia is deposited. C. The needle is directed along the long axis of the tooth, and anesthesia is deposited just superior to the area of the root apex. D. Clinical photograph depicting a supraperiosteal infiltration of the maxillary lateral incisor.
Palatal Injection
Supraperiosteal infiltration of the maxillary teeth provides adequate anesthesia for pain control for a toothache, but not for procedures such as management of a dry socket or avulsed tooth. This may also require anesthesia of the palatal tissue, which can simply be accomplished by local infiltrative anesthesia. With a fine­gauge needle, puncture the palatal mucosa about halfway up the palate adjacent to the target tooth (Figure 245­
16). Inject .1 mL of anesthetic solution. Blanching of the surrounding tissue is common, and this injection is usually quite uncomfortable. If a larger area of anesthesia is required, anesthesia of the anterior portion of the palate can be obtained by injecting anesthesia over the incisive foramen. The landmark is the incisive papilla. Anesthesia to the unilateral posterior portion of the palate can be obtained by injecting a small amount of anesthesia
29­31 over the greater palatine foramen.
FIGURE 245­16. Palatal infiltration. A. The innervation to the soft tissue of the hard palate. The posterior portion of the palate is innervated by bilateral greater palatine nerves after they each exit their respective greater palatine foramens (see blue shaded area). The anterior portion of the hard palate is innervated by the nasopalatine nerve after exiting the incisive foramen. Injection over the incisive foramen (shown) will result in anesthesia to the purple shaded area. A similar injection over the area of the greater palatine foramen or the incisive foramen will provide anesthesia to its respective zone. B. A finegauge needle is inserted into the palatal tissue about  cm below the gingival margin, and a small amount of anesthesia is injected. Blanching of the palatal tissue surrounding the injection site is noted. This will provide anesthesia to the tissue adjacent to area injected as shown. C. Clinical photograph depicting a palatal infiltration.
MANDIBULAR INJECTIONS
In contrast to the maxilla where the cortex of overlying bone is relatively thin and infiltrative anesthesia is usually effective, the mandibular boney cortex is relatively thick and the inferior alveolar nerve block is usually required to gain adequate anesthesia of the mandibular molars and premolars.
A mental nerve block, as described in Chapter , “Local and Regional Anesthesia,” can provide anesthesia for the premolars, canines, and incisors, as well as soft tissue of the lip and chin, when properly administered. The bone adjacent to the canines and incisors is thinner and more amenable to infiltrative anesthesia. Also, soft tissue anesthesia of the tongue can be obtained using the basics of the inferior alveolar nerve block. Injection of the long buccal nerve may be necessary for incision and drainage of dental abscesses in the mandibular molar region, and this technique will be described. (See Video: Mental Nerve Block.)
Video 245­2: Mental Nerve Block
Used with permission from Saundra A. Jackson and Shawn C. Patterson, Dept of Emergency Medicine, University of North Carolina.
Play Video
Inferior Alveolar Nerve Block (Direct Technique)
The patient should be instructed to open the mouth widely to ensure good visualization of anatomic landmarks (Figure 245­17). First, the physician needs to palpate the greatest depth of the anterior border of the ramus or coronoid notch with the index finger or thumb. Then with that finger or thumb, the tissue is retracted toward the cheek, revealing the pterygotemporal depression that is between the raised ridge of mucosa
(pterygomandibular raphe) medially and coronoid notch laterally. With the syringe directed from the opposite premolar area, the needle is inserted into the pterygomandibular depression at a point  to .5 cm above the occlusal plane. This is approximately at the level of index finger or thumb. The needle is then slowly advanced until bone is contacted (about  to  mm). Once bone has been contacted, the needle should be withdrawn about  to
 mm and then aspirated. If no blood is aspirated, then about .5 mL of anesthetic solution should be slowly injected. The needle then should be
29­31 withdrawn about half of the distance, and the remainder of the dental carpule injected. This will ensure the anesthesia of the lingual nerve. With experienced operators, the direct technique has about a 20% to 25% failure rate. Most commonly, failure is due to using too low of a point of injection.
This places the anesthesia below the sphenomandibular ligament, which impedes its flow toward the inferior alveolar nerve. Repositioning the syringe higher above the occlusal plane will usually result in a successful injection. (See Video: Inferior Alveolar Nerve Block.)
FIGURE 245­17. Inferior alveolar nerve block (direct technique). A. Shows the anatomy of the inferior alveolar nerve as it enters the mandibular foramen in the pterygomandibular space. The lingual nerve lies superficial and medial to the inferior alveolar nerve. The coronoid notch is noted. B. The area of anesthesia obtained with a successful inferior alveolar nerve block. Usually the lingual nerve is also blocked, which provides anesthesia to the floor of the mouth, lingual gingiva, and the anterior two thirds of the tongue. C. The syringe should be directed from the contralateral premolar area about  to
### .5 cm above the mandibular plane. It is inserted about  to  mm until bone is touched in an area above the lingula. The needle should then be withdrawn  to  mm and aspirated for blood before injecting anesthesia. The sphenomandibular ligament attaches to the lingula and prevents the anesthesia from reaching the inferior alveolar nerve if the injection is too low. D. Clinical photograph of the direct technique. Note the point of injection in the pterygomandibular depression just lateral to the pterygomandibular raphe. E. A diagram of a transverse section of the pterygomandibular fossa at the level of an inferior alveolar nerve injection. Note that the needle passes through the buccinator muscle to an area just superior to the lingula.
Video 245­3: Inferior Alveolar Nerve Block
Used with permission from Saundra A. Jackson and Shawn C. Patterson, Dept of Emergency Medicine, University of North Carolina.
Play Video
Lingual Nerve Block
If only lingual nerve anesthesia is desired, then the above technique can be followed, except the needle need only be initially inserted about  mm, aspirated, and then the anesthetic agent instilled. This will provide anesthesia to the ipsilateral half of the anterior two thirds of the tongue (Figure
29­31
245­18).
FIGURE 245­18. The lingual nerve block and the long buccal nerve block. A. The shaded areas represent the area in which anesthesia should be deposited for their respective blocks. The lingual nerve runs superficial and medial to the inferior alveolar nerve and can be easily anesthetized as part of the inferior alveolar nerve block. The lingual nerve block can be performed by depositing anesthesia about half the depth of the inferior alveolar nerve block. B. A diagrammatic representation of the long buccal nerve block. The long buccal nerve requires a separate injection of a small quantity of anesthetic just lateral to the molars in the buccal mucosa. C. Clinical photograph of the long buccal nerve block.

## Page 30

University of Pittsburgh
Access Provided by:
Long Buccal Injection
If buccal soft tissue anesthesia is required, then this injection should be used. The needle is inserted into the mucosa in the buccal vestibule adjacent
29­31 to the second or third mandibular molars (Figure 245­18).
INJECTION COMPLICATIONS
The normal vasovagal symptoms, such as syncope, that can occur with any injection may occur during or after a dental injection. Flushing and elevation of the heart rate can also occur. Mild to severe allergic reactions are possible. Due to the close proximity of the inferior alveolar artery and vein and the pterygoid plexus, a potential complication of inferior alveolar nerve block is traumatic hematoma formation. These are usually selflimiting and treated with ice to the face, but can be quite uncomfortable and an aesthetic issue for more than a week. Due to the superficial nature of the lingual nerve relative to the inferior alveolar nerve, inadvertent injury to the lingual nerve with subsequent temporary or permanent paresthesia can occur. This not only can affect sensation to the anterior two thirds of the affected side but also may affect taste because taste fibers run with the lingual nerve. Postinjection trismus, due to local trauma to the muscles of mastication, can occasionally occur. Needle breakage, although uncommon, has been reported, especially with improper technique such as bending the needle prior to use or redirecting the needle while injecting. Finally,
 unintentional injection too posteriorly may result in injection into the parotid region and can cause temporary facial nerve palsy.


