## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 277: Foot Injuries
Talib Omer; Margarita Santiago­Martinez
INTRODUCTION
Foot injuries are a common presentation in the ED and are frequently missed.1–3 These injuries typically occur in work, athletic, and traffic environments.4,5 Foot injuries can be associated with substantial medical and economic costs.6,7 Sport­related foot and ankle injuries require care so the athlete can return to the demands of the sport as quickly as possible.3 Motor vehicle crash patients with a foot or ankle injury typically have a higher injury severity score than those without such injuries.8 The majority of foot injuries involve fractures of the metatarsals.9
ANATOMY
The foot is divided into three sections: the hindfoot, the midfoot, and the forefoot. The Chopart joint separates the hindfoot from the midfoot. The Lisfranc joint divides the midfoot and the forefoot. The hindfoot is composed of the talus and the calcaneus. The midfoot encompasses the medial, middle, and lateral cuneiforms; the navicular; and the cuboid. The tarsus refers to the bones of the hind and midfoot. The forefoot includes the metatarsals and the proximal, middle, and distal phalanges (Figure 277­1). Ligaments and muscles enable foot movements of eversion, inversion, adduction, and abduction.
FIGURE 277­1. A. Diagram of normal bony anatomy of the foot. B. Radiograph of normal bony alignment of the foot. [Panel B image used with permission of Robert DeMayo, MD.]

Chapter 277: Foot Injuries, Talib Omer; Margarita Santiago­Martinez 
. Terms of Use * Privacy Policy * Notice * Accessibility
Vascular supply of the foot originates from branches of the popliteal artery: the anterior tibial artery, with its branch the dorsalis pedis supplying the dorsal aspect of the foot; and the posterior tibial and peroneal arteries supplying the sole (Figure 277­2).
FIGURE 277­2. A. Arteries of the dorsum of the foot. B. Vessels, muscles, and nerves of the sole of the foot and nerves of the sole of the foot. a. = artery; aa. = arteries; n., nn. = nerves; m. = muscles.
The sural, saphenous, peroneal, and lateral plantar nerves innervate the foot for both motor and sensory function and originate in branches from the sciatic and femoral nerves.
CLINICAL FEATURES
HISTORY
Ask about the mechanism of injury and direction of force. Obtain key information, including ability to bear weight after the injury, prior injury or surgery to the area, and any other potential injuries. Because it requires great force to fracture the foot, other injuries can coexist, and foot pain can distract from other serious injuries, or conversely, other injuries can distract from foot pain, leading to a high miss rate of foot fractures in polytrauma patients.5
PHYSICAL EXAMINATION
The foot examination does not necessarily begin with the foot, but with the entire lower extremity on the affected side. Examine the hip, knee, and ankle. Evaluate neurovascular integrity.
Vascular compromise of the foot is identified with diminished pulses, a cool extremity, and mottled skin. Once the general examination is completed and the focused foot examination begins, start with the general appearance of the foot and compare it with the uninjured side. Look for obvious closed or open deformities. Ask the patient to identify painful areas, although pain is often poorly localized. Palpate the foot for abnormal findings or tenderness. Pay particular attention to the base of the fifth metatarsal and the dorsal aspect of the base of the second metatarsal. Range the joint both passively and actively through all typical motions of the foot. Evaluate gait when possible.
HINDFOOT INJURIES
CALCANEUS INJURIES
CLINICAL FEATURES
The calcaneus is the most commonly fractured tarsal bone.10 Fractures in the hindfoot typically require a large force, like an axial load to the heel, to occur. Because of this force, associated injuries are common.
Calcaneal fractures are subdivided into intra­articular and extra­articular fractures, with intra­articular fractures being the more common of the two. A displaced intra­articular fracture is common and poses its own challenges for long­term care. Some surgeons advocate for open reduction and internal fixation; others prefer nonoperative closed reduction; and still others prefer primary arthrodesis, with all management strategies having mixed results.11,12
DIAGNOSIS
Plain radiographs, specifically the lateral view, are needed for fracture diagnosis. The Boehler angle is measured using the lateral view and represents the intersection of two lines: (1) the line drawn from the highest part of the anterior process of the calcaneus and the highest point of the posterior articular surface of this bone, and (2) the line between the highest point of the posterior articular surface of the calcaneus and the most superior part of the calcaneal tuberosity. The normal angle measures between  and  degrees. When the angle is <25 degrees, suspect a fracture (Figure 277­3). Because this angle varies widely between individuals, a comparison view is helpful if the diagnosis is in question. Although plain radiographs are helpful when the fracture is visible, a CT can provide detail and help clarify the management plan.
FIGURE 277­3. A. Calcaneal fracture with abnormal Boehler angle. B. Normal radiograph with normal Boehler angle. [Image used with permission of Robert DeMayo, MD.]
TREATMENT AND FOLLOW­UP
For intra­articular fractures, obtain orthopedic consultation to determine the management plan. For nondisplaced fractures, treat an intra­articular fracture with immobilization, a wellpadded posterior splint, strict elevation, non–weight­bearing status, and appropriate analgesia. Elevate the leg above the heart to minimize edema and the risk of compartment syndrome
(see the Chapter 278, “Compartment Syndromes”). Displaced fractures may require surgical repair. Care for an extra­articular fracture is elevation, immobilization, analgesia, and orthopedic follow­up. Some of these will require outpatient surgical intervention, with less invasive, percutaneous approaches being adopted in more recent years.13
TALUS INJURIES
CLINICAL FEATURES
Fractures of the talus usually require a significant mechanism such as extreme dorsiflexion or a fall from a great height. “Major” talus fractures are those involving the head, neck, or body of the talus (Figure 277­4) and can result in avascular necrosis. “Minor” talus fractures are those that do not cross the central part of the talus (Figure 277­5). A lateral process talar fracture is sometimes called “snowboarder’s ankle” and is commonly mistaken for a lateral ankle sprain.
FIGURE 277­4. Major talus fractures. [Reproduced with permission from Simon RR, Sherman SC (eds): Emergency Orthopedics, 6th ed. New York: McGraw­Hill; 2011; Fig. 23­13, p. 525.]
FIGURE 277­5. Minor talus fractures. [Reproduced with permission from Simon RR, Sherman SC (eds): Emergency Orthopedics, 6th ed. New York: McGraw­Hill; 2011; Fig. 23­14, p. 527.]
DIAGNOSIS, TREATMENT, AND FOLLOW­UP
Diagnosis begins with plain radiography, but CT provides better visualization of the talus. Minor talus fractures can be treated on an outpatient basis with a posterior splint, non–weightbearing status, analgesia, and orthopedic referral. Major talar fractures ideally require orthopedic consultation in the ED.
Dislocations of the talus, when the tibiotalar joint remains intact, are subtalar dislocations, also known as peritalar dislocations.14 The talocalcaneal and talonavicular joints are disrupted by a rotational­inversion force. Dislocations are rare but are orthopedic emergencies. Immediate orthopedic consultation and reduction are necessary to prevent neurovascular compromise to the foot.
MIDFOOT INJURIES
LISFRANC INJURIES
CLINICAL FEATURES
The midfoot is divided into two columns; the medial column contains the navicular, cuneiforms, and first three tarsometatarsal joints, and the lateral column contains the cuboid and fourth and fifth tarsometatarsal joints (Figure 277­1). The midfoot is a vital bridge between the hindfoot and the forefoot. Injuries to the midfoot have the potential to dramatically affect an individual’s daily function, including the ability to stand and walk. Untreated midfoot injuries in diabetics can lead to the development of Charcot’s foot (collapse of the midfoot arch) and lifelong complications with ambulating.15
The cornerstone of mechanism, diagnosis, and treatment of Lisfranc injuries lies in the anatomy of the second metatarsal and the Lisfranc ligament, which runs between the lateral base of the medial cuneiform and the medial base of the second metatarsal. Lisfranc injuries range from sprains to fracture­dislocations, with concurrent fractures of the hindfoot and forefoot being relatively common, especially fractures of the second metatarsal. The usual mechanism of injury for sprains is a low­velocity indirect force, whereas plantarflexion with an axial load (e.g., strenuous jumping over an obstacle) is seen in more significant injuries. Sports injuries (specifically football) and motor vehicle crashes are common causes of these injuries.10,16–18
DIAGNOSIS
The Ottawa Ankle Rules (see Figure 276­6) can safely be applied to help exclude midfoot injuries with high accuracy, both in the adult and pediatric populations.19,20 If no bony tenderness is present at the base of the fifth metatarsal or at the navicular, and the patient is able to bear weight immediately after injury, and while in the ED, no radiograph is required. However, significant pain elicited by torsion of the midfoot or pain on passive dorsiflexion or plantarflexion of the foot may specifically raise suspicion for a Lisfranc injury. When indicated, radiographic studies should include at minimum bilateral weight­bearing anteroposterior (when tolerable), lateral, and 30­degree oblique views of the foot. Bony displacement of  mm or greater between the bases of the first and second metatarsals is considered unstable. CT imaging is recommended when radiographic imaging is equivocal because it provides better delineation of bony structures and diagnoses occult fractures or subluxations that can be missed on plain radiographs (Figure 277­6).21
FIGURE 277­6. A. Radiograph of Lisfranc injury. B. CT of Lisfranc injury. Note the metatarsal bones are fractured (arrow) and displaced from the tarsus. [Image used with permission of Robert DeMayo, MD.]
Lisfranc injuries have multiple classification systems. The Nunley classification groups low­energy ligamentous injuries by diastasis and preservation or loss of arch height: type I are nondisplaced, type II involve diastasis between the first and second metatarsal heads, and type III involve diastasis with loss of arch height.16 (See Video: Ottawa Ankle Rules)
Video 277­1: Ottawa Knee Rule
Used with permission from Sarah Nelson, Department of Emergency Medicine, University of North Carolina; Judith E. Tintinalli, David Cline, O. John Ma, Medical Editor.
Play Video
TREATMENT AND FOLLOW­UP
Treatment of a nondisplaced injury (<1 mm between the bases of the first and second metatarsals) is with a non–weight­bearing splint, rest, ice, and elevation. Orthopedic reevaluation is usually scheduled within  weeks when repeat imaging will likely be obtained, and a cast will likely remain on for an additional  weeks. At  weeks, gradual progressive weight bearing can be attempted.
Fracture displacement, associated dislocation, or evidence of compartment syndrome requires emergent intervention and orthopedic consultation.10 Whether the reduction is open or closed depends on the degree of the injury and is determined by the orthopedic consultant. Surgical options are variable and range from open reduction and internal fixation to primary arthrodesis.22
NAVICULAR INJURIES
Navicular fractures are typically caused by a direct blow or axial loading. Avulsion injuries can also occur with a pulling or rotational force. On physical examination, tenderness and ecchymosis are found about the navicular. Imaging includes bilateral weight­bearing anteroposterior, lateral, and oblique radiographs. CT is best for evaluating the talonavicular joint surfaces. The goals of treatment are maintenance of anatomy and restoration of articular congruity. Nondisplaced fractures should be treated in a non–weight­bearing short leg cast for  to  weeks, with orthopedic reevaluation in approximately  weeks. Orthopedic consultation in the ED is usually required for displaced and, therefore, unstable fractures to determine the management plan. Given that the central part of the navicular bone is avascular, complications include avascular necrosis, nonunion, and instability, all of which can lead to a flatfoot deformity.23,24
CUBOID INJURIES
The cuboid articulates with the calcaneus and the fourth and fifth metatarsals. Plantarflexion and abduction is the most common mechanism of injury. Imaging includes bilateral weightbearing anteroposterior, lateral, and oblique radiographs. CT may be helpful. Nondisplaced fractures are treated with a short leg cast and initial non–weight­bearing status. Comminuted injuries are treated with surgery. Complications include foot instability and joint arthrosis.
CUNEIFORM INJURIES
The cuneiforms all articulate with the navicular. Isolated cuneiform injuries are very rare, but especially with a high­energy mechanism of injury, cuneiform fractures can coexist with other fractures of the foot. Imaging studies are the same as for the other bones of the midfoot. Treatment depends on which bone is injured: medial cuneiform injuries are typically treated with surgery, whereas closed reduction usually suffices for the middle and lateral cuneiform bones.
FOREFOOT INJURIES
Forefoot injuries cover a broad range, from those requiring minimal intervention to those requiring operative repair. Fractures range from the minimally displaced to open, comminuted fractures.
FIFTH METATARSAL INJURIES
CLINICAL FEATURES
Fractures of the proximal fifth metatarsal occur in three forms and can be identified using the joint between the proximal fourth and fifth metatarsal as a guide: (1) tuberosity or styloid fractures, which are proximal to the joint; (2) Jones fractures, which are also known as metaphyseal­diaphyseal junction fractures; and (3) diaphyseal stress fractures.
DIAGNOSIS
Plain radiographs are usually adequate. CT scans should be considered for more detailed imaging in the high­performance athlete25 (Figure 277­7).
FIGURE 277­7. A. Anteroposterior radiograph of Jones fracture (arrow). B. Lateral radiographs of Jones fracture (arrow). [Image used with permission of Robert DeMayo, MD.]
TREATMENT AND FOLLOW­UP
Patients with nondisplaced Jones fractures should be non–weight bearing in a cast for  to  weeks. Complications of a Jones fracture treated nonoperatively include bony nonunion, which may later require intramedullary screw fixation. Some orthopedic surgeons are advocating for early surgical correction, especially in athletes, so posterior splinting and outpatient referral to an orthopedic surgeon are appropriate initial treatment.26,27 Nondisplaced avulsion fractures of the tuberosity, also known as a pseudo­Jones fracture, can be treated with a walking cast and pain control with weight bearing as tolerated.
METATARSAL INJURIES
Proximal fractures of the first through fourth metatarsals are typically caused by a crush injury or direct blow. Take care to exclude an associated Lisfranc injury. An isolated proximal metatarsal fracture can be treated with a posterior splint and non–weight­bearing status. Orthopedic follow­up within  to  days is needed for the likely placement of a more definitive cast.
Nondisplaced isolated fractures of the shaft of a metatarsal, usually caused by an acute direct blow or twisting force, can typically be seen on oblique or lateral foot films. These can typically be treated with a posterior splint or orthopedic shoe or walking boot (see Chapter 267, “Initial Evaluation and Management of Orthopedic Injuries”). Repeat imaging can be performed  week after injury and then again at  weeks. Fractures with displacement of  to  mm or angulation >10 degrees usually require surgical reduction28 (Figure 277­8).
FIGURE 277­8. A. Anteroposterior radiograph of multiple metatarsal shaft fractures. B. Lateral radiograph of multiple metatarsal shaft fractures. [Image used with permission of Robert DeMayo, MD.]
STRESS INJURIES
Chronic direct forces cause stress fractures. Stress fractures typically occur in the setting of increasing activity or chronic overuse and are sometimes called “march fractures.” Stress fractures are rarely visible on plain radiographs; MRI can be used when pain is persistent. A clinical diagnosis typically suffices. Cessation of the causative activity usually results in good outcomes for recovery.26
METATARSOPHALANGEAL INJURIES
Metatarsophalangeal joint injuries are caused by multiple mechanisms and occur in various forms, including sprains, subluxations, and dislocations. Turf toe is a form of a sprain that results when there is acute or chronic hyperdorsiflexion of the first metatarsophalangeal joint while the foot remains in plantarflexion. History usually yields the diagnosis. When radiographs are obtained, a capsular avulsion, the hallmark of this injury, is seen. On physical examination, passive ranging results in a pathologically increased range of motion. Treatment is rest, ice, and elevation. Upon returning to sports, a reinforced shoe can be helpful and protective from further injury.29
Dislocations of the metatarsophalangeal joint, usually dorsal, can also occur. A high­energy mechanism is the usual cause, and this injury often accompanies other foot injuries. Treatment ranges from closed reduction to operative repair, depending on the severity of injury.
PHALANGE INJURIES
Fractures of the phalanges are the most common fractures of the forefoot, with a stubbing mechanism of the hallucal proximal phalanx being the most common injury.29 Radiographs are obtained if there is extensive injury or suspicion of foreign body or open fracture or if the great toe is injured. Radiographs are not necessarily obtained for the distal phalanges of the other toes if the only injury is a closed isolated injury of the distal phalanx. Crush mechanisms can lead to distal phalanx fractures. Treatment is with buddy taping to the adjacent toe or application of tape about the forefoot for greater stability (taking care to avoid undue pressure from the tape) and a hard­soled shoe.
For general guidance regarding the care of patients with acute bony foot injuries, see Table 277­1. TABLE 277­1
Summary of Emergent Care of Bony Foot Injuries
Orthopedic Referral Advice on Long­Term
Fracture or ED Home Care/Weight­
ED Imaging (immediate: within  h; early: Care and Special Considerations
Injury Type Care* Bearing Status within  wk) Management
Calcaneal, intra­ Plain films, Boehler Posterior Intra­articular: immediate; extra­ NWBS; RICE Possible surgery and extra­ angle; CT for subtle splint articular: early articular findings
Talus fracture CT Posterior Major: immediate; minor: early NWBS; RICE Possible surgery Risk of avascular necrosis splint
Lisfranc CT Splint Displaced: orthopedic consult in ED; NWBS; RICE Possible surgery Risk of compartment syndrome; nondisplaced: early arthritis. Plain radiographs have low sensitivity
Navicular Plain films or CT Splint Nondisplaced: early; displaced: NWBS; RICE Possible surgery Risk of avascular necrosis; nonunion fracture immediate
Cuboid fracture Plain films or CT Splint Early NWBS; RICE Comminuted: possible surgery
Cuneiform Plain films or CT Splint Early NWBS; RICE Medial: possible surgery fracture
Jones Plain films; CT for Splint Early NWBS; RICE Athletes: possible athletes surgery
Metatarsal Plain films Posterior Within a week for a cast NWBS; RICE Surgery not likely fracture splint
Stress fracture Clinical Cessation of causative Plain radiographs usually negative activity initially
Phalange Plain films Buddy Hard­soled shoe and fracture taping weight bearing as tolerated
Open fractures of Consider antibiotics, Td Pain Orthopedic consult in ED any kind control
*All patients with fractures should receive adequate analgesia, and splints should be well padded.
Abbreviations: NWBS = non–weight­bearing status; ortho = orthopedist; RICE = rest, ice, compression, elevation; Td = tetanus booster.
TENDON INJURIES
Lacerations to the foot may result in injury to the extensor hallucis longus tendon, with inability to dorsiflex the great toe, or tibialis anterior tendon, with loss of dorsiflexion of the foot. Consult with the orthopedist. Treatment is primary repair if the tendon edges are opposable; otherwise, tendon reconstruction is necessary.30
Lacerations of the flexor hallucis longus are typically repaired. Lacerations to the flexor tendons of the other toes are generally left unrepaired, as there is little if any functional impact.
Dislocation of the posterior tibial tendon is uncommon and is often misdiagnosed as ankle sprain. Mechanism of injury is forced dorsiflexion of the foot and ankle eversion when the posterior tibial tendon is contracted, as may occur in snowboarding or ice skating.31 Treatment is surgical repair.
Achilles tendon injuries are discussed in Chapter 275, “Leg Injuries,” Chapter 276, “Ankle Injuries,” and Chapter 285, “Soft Tissue Problems of the Foot.” Repair of lacerations of the foot is discussed in Chapter , “Thigh, Leg, and Foot Lacerations.”
Acknowledgments
The authors would like to thank Drs. Esther Choo and Robert DeMayo for many of the radiographic images.


