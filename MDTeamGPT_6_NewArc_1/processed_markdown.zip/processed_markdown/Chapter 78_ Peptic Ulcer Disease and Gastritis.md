## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 78: Peptic Ulcer Disease and Gastritis
Angela M. Bogle; Matthew C. Gratton
INTRODUCTION AND EPIDEMIOLOGY
Peptic ulcer disease is a chronic illness manifested by recurrent ulcerations in the stomach and proximal duodenum. Acid and pepsin are thought to
,2 be crucial to ulcer development, but the great majority of peptic ulcers are directly related to infection with Helicobacter pylori or NSAID use.
Gastritis is acute or chronic inflammation of the gastric mucosa and has various etiologies. Dyspepsia is continuous or recurrent upper abdominal
 pain or discomfort and may be caused by a number of diseases or may be functional. Uncomplicated peptic ulcer disease has an estimated incidence
 of .1% to .3% per year, and about 5% to 10% of people living in the Western world will experience a peptic ulcer at some point during their lives. H.
pylori infection, one of the main risk factors for peptic ulcer disease, is one of the most prevalent human infections in the world, affecting at least 50%
 of the world’s population. The age­adjusted prevalence of H. pylori infection is decreasing in industrialized countries, likely due to an improved
,3 standard of living and to the increased use of proton pump inhibitors and antimicrobial therapy. This may explain the decreasing incidence of peptic
 ulcer disease in the United States, but this may be partially offset by the widespread use of low­dose aspirin and NSAIDs. Currently, at least a fifth of
 peptic ulcer disease cases have been found to be H. pylori–negative, NSAID­negative, and aspirin­negative. Certain medical conditions such as
Helicobacter heilmannii, cytomegalovirus infections, Behçet’s disease, Zollinger­Ellison syndrome, Crohn’s disease, and cirrhosis with portal
 hypertension may contribute to the development of peptic ulcers. Other risk factors include antiplatelet agents, psychological stress, older age, and
,5
African­American ethnicity.
PATHOPHYSIOLOGY
Hydrochloric acid and pepsin destroy gastric and duodenal mucosa. Mucus and bicarbonate ion secretions protect mucosa. Prostaglandins protect mucosa by enhancing mucus and bicarbonate production and by enhancing mucosal blood flow, thereby supporting metabolism. The balance between these protective and destructive forces determines whether peptic ulcer disease occurs. H. pylori bacteria or NSAIDs are thought to be the
,2 causal agents of peptic ulcer disease in most cases. Although traditional treatment of peptic ulcers by various modalities heals most ulcers, eradication of H. pylori has been shown to accelerate healing and decrease both relapse and rebleeding of ulcers that are not associated with the use
,6 of NSAIDs.
H. pylori is a spiral, gram­negative, urease­producing, flagellated bacterium that is found living between the mucous gel and the mucosa. The bacterium’s production of urease, cytotoxins, proteases, and other compounds is thought to disturb the mucous gel and cause tissue injury. In addition, increased gastrin levels and decreased mucus and bicarbonate production are associated with H. pylori infection. Chronic active (usually
 asymptomatic) gastritis is an almost universal finding with H. pylori infection, but only some infected people develop peptic ulcer disease. It is unclear why most infected persons do not develop symptomatic peptic ulcer disease, but it most likely reflects an interaction of factors, including characteristics of host and pathogen (different virulence of strains of bacteria). In 2005, Marshal and Warren were awarded the Nobel Prize in
Physiology or Medicine for their discovery of H. pylori and its role in gastritis and peptic ulcer disease.
H. pylori is a causative agent of mucosa­associated lymphoid tissue lymphoma, and eradication of infection causes a remission in a sizable percentage
 of patients with low­grade tumors. In addition, H. pylori infection is a risk factor for adenocarcinoma of the stomach. However, because the prevalence of gastric cancer in the United States is very low and the H. pylori infection rate is high, other factors undoubtedly are involved. There is
,7,8 some evidence that eradication of the infection reduces the risk of gastric cancer. H. pylori infection has been associated with the development of iron deficiency anemia, with possible mechanisms including decreased iron absorption and/or occult blood loss from chronic gastritis. Eradication
 therapy plus iron improves hemoglobin levels more than iron alone. Improvement in the platelet count in some patients with idiopathic

 thrombocytopenic purpura has been demonstrated with H. pylori eradication, but more work remains to be done in this regard.
Chapter 78: Peptic Ulcer Disease and Gastritis, Angela M. Bogle; Matthew C. Gratton 
. Terms of Use * Privacy Policy * Notice * Accessibility
NSAIDs inhibit prostaglandin synthesis, thereby decreasing mucus and bicarbonate production and mucosal blood flow, which allows ulcer formation.
Gastrin­secreting tumors produce ulceration due to high levels of acid and pepsin production, but acid alone rarely causes ulceration. However, inhibition of acid secretion may allow ulcers to heal and is the basis for traditional ulcer treatments.
Acute gastritis may be related to ischemia from severe illness (e.g., shock, trauma, severe burns, organ failure) or to the direct toxic effects of agents
(e.g., NSAIDs, steroids, bile acids). H. pylori infection causes acute and chronic gastritis (both usually asymptomatic). Chronic gastritis may also be caused by autoimmune factors that destroy gastric parietal cells; this results in the loss of acid production and the loss of intrinsic factor production, which in turn cause malabsorption of vitamin B and, hence, pernicious anemia.

Dyspepsia has multiple causes. Endoscopy of patients with dyspepsia demonstrates that less than 10% have peptic ulcer disease and less than 1% have
 gastroesophageal cancer. More than 70% have no definite findings on endoscopy and are said to have “functional” dyspepsia. Patients with functional dyspepsia may have evidence of abnormal gastric emptying, abnormal sensitivity to distention, abnormal ability of the stomach to distend with a meal, abnormalities in acid clearance, and abnormal duodenal sensitivity to acid. In addition, there appears to be an as yet poorly characterized
 interaction between the stomach and intestine and the CNS, which may contribute to symptoms.
CLINICAL FEATURES
Symptoms are nonspecific; however, burning epigastric pain is the most classic symptom of peptic ulcer disease. The pain also may be described as sharp, dull, an ache, or an “empty” or “hungry” feeling. Pain may be relieved by ingestion of milk, food, or antacids, presumably due to buffering and/or dilution of acid. Pain recurs as the gastric contents empty, and the recurrent pain may classically awaken the patient at night.
Pain tends to occur daily for weeks, resolve, and then recur in weeks to months. Postprandial pain and nausea may be associated with gastric ulcers;
 however, food intolerance, retrosternal pain, and belching are not related to peptic ulcer disease. Older patients (>65 years old) frequently will have no symptoms or only mild symptoms or may have more atypical symptoms such as nausea, vomiting, anorexia, weight loss, and bleeding.
A change in the character of typical pain may herald a complication. Abrupt onset of severe or generalized pain may indicate perforation with peritoneal spillage of gastric or duodenal contents. Rapid onset of mid­back pain may be due to posterior penetration into the pancreas, resulting in pancreatitis. Nausea and vomiting may indicate gastric outlet obstruction from scarring or edema. Vomiting of bright red blood or coffee­ground emesis or passage of tarry or melanotic stool or hematochezia may indicate ulcer bleeding.
On physical examination, the only positive finding in patients with uncomplicated peptic ulcer disease may be epigastric tenderness. This finding is neither sensitive nor specific for the diagnosis. Other physical findings may be indicative of complications: a rigid abdomen consistent with peritonitis in perforation; abdominal distention or a succussion splash due to obstruction; or occult or gross rectal blood or blood in the nasogastric aspirate signaling ulcer bleeding.
Epigastric pain, nausea, and vomiting may be present with acute gastritis, but the most common presentation of gastritis is GI bleeding, ranging from occult blood loss in the stool to massive upper GI hemorrhage. Physical findings may be normal, may reflect only the GI bleeding, or may reflect a severe underlying associated illness (as listed earlier).
DIAGNOSIS
A definitive diagnosis of peptic ulcer disease cannot be made on clinical grounds alone. Uncomplicated peptic ulcer disease can be strongly suspected in the presence of a “classic” history, including epigastric burning pain; relief of pain with ingestion of milk, food, or antacids; and night pain accompanied by “benign” physical examination findings, including normal vital signs with or without mild epigastric tenderness. The differential diagnosis of epigastric pain is extensive and, in addition to peptic ulcer disease, includes gastritis, gastroesophageal reflux disease, cholelithiasis, pancreatitis, hepatitis, abdominal aortic aneurysm, gastroparesis, and functional dyspepsia. Careful history taking may elicit features that point away from peptic ulcer disease: burning pain radiating into the chest, water brash, and belching may suggest gastroesophageal reflux disease; more severe pain radiating to the right upper quadrant and around the right or left side suggests cholelithiasis; radiation through to the back indicates pancreatitis or abdominal aortic aneurysm; chronic pain, anorexia, or weight loss may indicate gastric cancer. Myocardial ischemic pain may also present as epigastric pain and should be strongly considered in the appropriate clinical setting.
Physical examination findings may suggest other diagnoses: right upper quadrant tenderness points to cholelithiasis or hepatitis, an epigastric mass to pancreatitis (pseudocyst) or pancreatic or gastric neoplasm, a pulsatile mass to abdominal aortic aneurysm, jaundice to hepatitis, and peritoneal findings to an acute abdomen.
ANCILLARY TESTING
Ancillary tests may help exclude peptic ulcer disease complications and narrow the differential diagnosis. Normal results for CBC rule out anemia from chronic GI bleeding due to peptic ulcer disease, gastritis, or cancer (but do not rule out acute blood loss). Elevated liver function test results may indicate hepatitis, and an elevated lipase level may indicate pancreatitis. An acute abdominal series may show free air associated with perforation. A limited ED US examination may show gallstones or an abdominal aortic aneurysm. An ECG and cardiac enzyme determination are indicated if there is a suspicion of myocardial ischemic pain.

The gold standard for diagnosis of peptic ulcer disease is visualization of an ulcer by upper GI endoscopy. Although not all patients with
,9 undiagnosed dyspepsia require endoscopy, those with “alarm features” do (Table 78­1). Alarm features raise the index of suspicion for gastric or esophageal cancer, as well as other potentially serious conditions, but the features are not specific.
TABLE 78­1
“Alarm Features” for Endoscopy
Age >50 y, with new­onset symptoms
Unexplained weight loss
Persistent vomiting
Dysphagia or odynophagia
Iron deficiency anemia or GI bleeding
Abdominal mass or lymphadenopathy
Family history of upper GI malignancy
H. pylori Tests
Because many peptic ulcers are caused by H. pylori infection and eradication of H. pylori dramatically decreases the ulcer recurrence rate, it is important to know how to diagnose infection. H. pylori infection can be diagnosed by endoscopic tests, including the rapid urease test, histologic
 study, and culture, all of which rely on a biopsy of the gastric mucosa. Noninvasive tests include serologic tests, urea breath tests, and stool antigen
,11 tests.
The rapid urease test detects the presence of urease in a biopsy specimen (presumptive evidence of H. pylori infection) with >85% to 95% sensitivity
 and >95% specificity. Histologic studies allow direct assessment of H. pylori infection and culture of the organism, but these tests require highly trained technicians in appropriate facilities and are not widely available. The major disadvantage of all the aforementioned tests is the cost in time, dollars, and potential complications of endoscopy.

Serologic studies detect immunoglobulin G antibodies to H. pylori and are readily available, but the sensitivity and specificity are not very good.
Serologic studies are not useful as a test of cure, because antibodies remain for several months to years after eradication of infection.
The urea breath test relies on the presence of urease produced by H. pylori. Urea labeled with carbon­13 or carbon­14 instead of carbon­12 is ingested and, in the presence of bacterial urease, is broken down into labeled carbon dioxide and ammonia. The labeled carbon dioxide is detected in
,12 the breath later. Sensitivity and specificity are >90%. The urea breath test can be used to determine the presence of infection after eradication therapy.  H. pylori antigens can be detected in the stool with about 95% sensitivity and specificity.  Testing performed ≥4 weeks after completion of

H. pylori eradication therapy is useful as a test of cure. The sensitivity of all tests that rely on active infection with H. pylori is decreased significantly by recent treatment with proton pump inhibitors, histamine­2 (H ) antagonists, antibiotics, and bismuth compounds, and most recommend stopping

 these agents for  to  weeks before testing.
TREATMENT
Traditional ulcer therapy (proton pump inhibitors, H receptor antagonists, sucralfate, and antacids) heals the ulcer, relieves pain, and prevents
 complications but does not prevent recurrence. Treatment of H. pylori infection dramatically decreases the recurrence rate and accelerates ulcer
,6 healing. If NSAID­associated ulcers are present, the offending agent should be stopped whenever possible.
Traditional ED treatment would entail initiating a trial of a proton pump inhibitor or an H receptor antagonist, with antacids for breakthrough pain
 and referral to a primary care provider to direct evaluation and subsequent treatment. Current literature supports using proton pump inhibitors as
 first­line noneradication therapy for peptic ulcers. This usually remains the best option. Practice guidelines and reviews support treatment of known
H. pylori–positive dyspeptic patients with antimicrobial and antisecretory therapy followed by endoscopic study only in those with persistent
 symptoms. It might be reasonable for the ED physician to order a test for H. pylori, begin symptomatic therapy after the H. pylori test is obtained, and refer the patient for early follow­up with a primary care provider for initiation of antibacterial therapy if the test results are positive. This specific strategy has not been tested. However, there is some evidence that a “test­and­treat” strategy in the ED using the urea breath test to identify patients
 positive for H. pylori may be both beneficial and feasible in an area with a known high prevalence. Immediate referral for definitive diagnosis is mandated if alarm features are present (Table 78­1).
PROTON PUMP INHIBITORS
+ +
Proton pump inhibitors (e.g., esomeprazole, lansoprazole, omeprazole, pantoprazole) decrease acid production by irreversibly binding with an H K

ATPase molecule (proton pump) located on the gastric parietal cell, thus blocking hydrogen ion secretion. Proton pump inhibitors are most effective if taken  to  minutes prior to a meal. Proton pump inhibitors generally heal ulcers faster than H receptor antagonists and also have

 some in vitro inhibitory effect against H. pylori. Proton pump inhibitors are metabolized in the liver by the cytochrome P450 system and therefore may decrease the metabolism of many other drugs. In addition, proton pump inhibitors may inhibit the absorption of drugs that rely on
 gastric acidity. Proton pump inhibitors are well tolerated by most patients; however, headache and GI upset can occur. Long­term use of proton pump inhibitors may be associated with Clostridium difficile–associated diarrhea, fracture and pneumonia risk, chronic kidney disease, and
  hypomagnesemia. Discontinuing a proton pump inhibitor may result in rebound acid hypersecretion and dyspeptic symptoms. Symptoms can be minimized by gradually discontinuing the proton pump inhibitor over a few weeks, and replacing it with an H receptor antagonist or antacids. All
 proton pump inhibitors, even those available over the counter, appear to have similar efficacy in treating peptic ulcer disease and are the treatment of
,13 choice in a patient who develops an ulcer while taking NSAIDs and must continue NSAID therapy.
H RECEPTOR ANTAGONISTS

H receptor antagonists competitively inhibit the actions of histamine on the H receptors of the gastric parietal cells. All four H receptor antagonists

(cimetidine, famotidine, nizatidine, and ranitidine) heal ulcers approximately equally and are available in over­the­counter preparations. Because of renal excretion, make dosage adjustments in patients with renal failure. Long­term use of H receptor antagonists can lead to tolerance,

 and discontinuation can lead to rebound hypersecretion of acid. Side effects are uncommon but can include headache, confusion, lethargy,
 depression, and hallucinations. Cimetidine has more significant drug interactions than do the other H receptor antagonists due to inhibition of

 cytochrome P450 activity.
OTHER AGENTS
Sucralfate, an aluminum hydroxide complex of sucrose, appears to protect the ulcer from acid exposure by forming a sticky gel that adheres to the
 ulcer crater and allows healing to occur but does not relieve pain as well as proton pump inhibitors and H receptor antagonists. Sucralfate has few

 side effects but can cause constipation and aluminum toxicity, as well as inhibit absorption of a number of medications. Antacids heal ulcers by buffering gastric acid. Magnesium­ and aluminum­containing antacids can inhibit absorption of drugs and should be avoided in patients with renal insufficiency or renal failure. In renal failure, aluminum can accumulate and cause osteoporosis and encephalopathy, and hypermagnesemia can also result. Due to the simplicity of proton pump inhibitor and H receptor antagonists dosing requirements, antacids currently are used mainly on an as­
 needed basis for ulcer pain until healing occurs.
Although NSAIDs should be stopped in patients with peptic ulcer disease whenever possible, misoprostol may prevent ulcer formation in those
 concurrently receiving NSAID therapy but has not been proven to heal ulcers. Misoprostol is a prostaglandin analogue that may act by increasing mucus and bicarbonate production and by increasing mucosal blood flow. Because it is an abortifacient, do not use misoprostol in women who could
 become pregnant.
H. PYLORI ERADICATION
If H. pylori infection is diagnosed in the presence of peptic ulcer disease, eradication is clearly indicated but has become more challenging due to
,6,8 increasing antibiotic resistance. Multiple regimens have been proposed and studied, and most commonly, “triple therapy” with a proton pump
,6,8,11 inhibitor, clarithromycin, and either amoxicillin or metronidazole has been prescribed. Authorities in the United States recommend 10­ to 14­day
,6,8,11,14 regimens for the best cure rates, and tailoring decisions regarding first­line therapy on local antibiotic resistance. In areas where
 clarithromycin resistance is high, quadruple therapy or sequential therapy may be preferred. If H. pylori is not eradicated after treatment with two
 different regimens, resistance testing should be considered.
Patients generally do not present to the ED with a definitive diagnosis of H. pylori–positive peptic ulcer disease but rather with a symptom, such as epigastric pain. If appropriate history, physical examination, and laboratory evaluation result in a physician’s impression of “possible peptic ulcer disease” or “dyspepsia,” the physician is left with three main options: empiric treatment with conventional antiulcer medication, immediate referral for definite diagnosis (endoscopic study), or noninvasive testing for H. pylori followed by antibiotic therapy for patients with positive test results.
COMPLICATIONS
HEMORRHAGE
Upper GI bleeding is the most common cause of GI­related hospital admissions, and of those, peptic ulcer disease is the most common underlying
,15,16 etiology. Due to advances in endoscopic and medical management of peptic ulcer disease, the overall incidence of upper GI bleeding is
,15 decreasing; however, the mortality rate has remained the same at 10% to 14%. Bleeding from peptic ulcers is most commonly seen in the elderly.
ED treatment for ulcer bleeding focuses on restoring hemodynamic stability by IV administration of isotonic saline solution and packed red blood cells
(see Chapter , “Upper Gastrointestinal Bleeding” for details of treatment). Transfusion of red cells is recommended for hemoglobin levels less than 
 grams/dL or in patients who are hypotensive with severe GI bleeding before the hemoglobin level is known or if it falls below that threshold. Early
,15 upper endoscopy is recommended in most patients to confirm the diagnosis and target endoscopic treatment. Before endoscopy, a bolus dose of a proton pump inhibitor followed by a continuous infusion can be considered, as can use of a prokinetic agent, such as erythromycin, given IV. Neither has been consistently shown to improve clinical outcomes; however, erythromycin administered  minutes prior to endoscopy may improve
  visualization of the gastric mucosa. There is no clinical benefit to either a nasogastric or orogastric tube.
,15,16
Most patients should undergo upper GI endoscopy within  hours for diagnostic, prognostic, and treatment purposes. Lesions can be described
 using the Forrest classification to predict risk of rebleeding. Ranging from highest to lowest risk, the classification is as follows: active spurting of
 blood (Ia); active oozing (Ib); nonbleeding visible vessel (IIa); adherent clot (IIb); flat pigmented spot (IIc); and an ulcer with a clean base (III).
Endoscopic management is indicated for those ulcers at high risk for rebleeding. Treatment through endoscopy includes injection therapy
(epinephrine, sclerosing agents), thermal therapy (electrocoagulation, heater probe, argon plasma coagulation), and mechanical clipping and
,15,16 banding. All of these treatments stop bleeding, prevent recurrences, and decrease transfusion rates and length of hospital stay. The technique chosen depends on the equipment available and the experience of the endoscopist. Recently, topical therapy using a hemostatic spray and endoscopic

US­guided angiotherapy has shown promising results, but additional studies are needed to confirm their utility, efficacy, and safety.
Hospitalization in an intensive care setting is indicated for patients with significant upper GI bleeding due to peptic ulcers. If clinical and endoscopic features suggest a low risk of rebleeding, a ward bed may be acceptable.
PERFORATION

Perforation occurs in 2% to 14% of ulcers. Its presentation is heralded by the abrupt onset of severe epigastric pain as gastric or duodenal contents spill into the peritoneal cavity, followed by the development of chemical and then bacterial peritonitis. Mortality can be as high as 10% to 40%,
,17 depending on age, comorbidities, and timeliness of diagnosis and management. Patients may not have a history of peptic ulcer disease and may in fact have no history of ulcer­like symptoms; thus, a high index of suspicion based on history of present illness and physical exam is necessary. Elderly patients may not have dramatic pain or impressive peritoneal findings.
When the diagnosis is suspected, obtain appropriate laboratory tests, including a CBC, type and cross­match, and a lipase level; place two large­bore IV lines; provide oxygen for hypoxemia, and place a cardiac monitor; insert a nasogastric tube with suction; and obtain an acute abdominal series. Free air seen on radiographs in the setting of peritonitis on exam and appropriate history are enough to justify broad­spectrum antibiotics and prompt
 ,19 surgical consultation. About 60% to 75% of patients with perforated peptic ulcer have free air on an upright chest radiograph. If the plain films are ordered and do not demonstrate free air, then an abdominal CT should be ordered because the sensitivity is reported to be 98% and it can also
17­19 demonstrate other potential pathology. In some cases, nonsurgical therapy may be recommended, but operative intervention is the standard in the United States.
OBSTRUCTION
Obstruction occurs because of scarring of the gastric outlet due to chronic peptic ulcer disease, edema due to an active ulcer, or some combination of both. Resulting symptoms include abdominal fullness, nausea, and vomiting, and signs may include abdominal distention and a succussion splash.
Dehydration and electrolyte imbalances may occur. Treatment includes rehydration with IV fluids, correction of electrolyte abnormalities, and relief of distention with nasogastric suction. Hospitalization is almost always indicated. The outlet may open as edema subsides, but surgical correction is often necessary.
DISPOSITION AND FOLLOW­UP
Patients with complications always require consultation, and most require admission to an appropriate inpatient unit based on the diagnosis and hemodynamic stability. Most patients with epigastric pain or dyspepsia do not leave the ED with a definitive diagnosis, but, if critical diagnoses (e.g., abdominal aortic aneurysm or myocardial ischemia) are still in the differential, obtain consultation for admission, and further evaluation is indicated.
When uncomplicated peptic ulcer disease, gastritis, or dyspepsia is strongly suspected, the great majority of patients can be discharged with acidsuppressive therapy with a proton pump inhibitor or an H receptor antagonist and instructions to follow up with their primary care providers. If alarm
 features (indicating possible cancer or bleeding) are present, obtain consultation for early endoscopy.
Discharge instructions should include an explanation of the diagnosis and home treatment, specific follow­up instructions, and warning symptoms that should prompt immediate reevaluation. The explanation of the diagnosis should specify that peptic ulcer disease is a presumptive diagnosis and that more definitive diagnostic testing may be necessary. Instructions for home treatment should include a reminder to take medications as directed; a warning against use of alcohol, tobacco products, and aspirin or other NSAIDs; and a recommendation to avoid foods that appear to upset the individual’s “stomach.” Specific follow­up instructions should include the name and phone number of the appropriate provider whenever possible and a time frame for reevaluation, generally  to  hours if not improving or  to  weeks if improving. Warning symptoms that merit immediate reevaluation include those that may be attributed to ulcer complications or confounding illness: worsening pain, increased vomiting, hematemesis or melena, weakness or syncope, fever, chest pain, radiation of pain to the neck or back, and shortness of breath.


