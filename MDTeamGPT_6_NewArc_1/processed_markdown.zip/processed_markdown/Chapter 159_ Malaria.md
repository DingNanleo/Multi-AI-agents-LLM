## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 159: Malaria
Malcolm E. Molyneux
INTRODUCTION
Malaria, a protozoan disease transmitted by the bite of the Anopheles mosquito, is one of mankind’s most feared and serious afflictions. It is a leading cause of morbidity and mortality in many tropical areas of the world, especially in Africa. Approximately 55% of the world’s population is exposed to the infection, which exerts its toll mainly on the young and the pregnant. Malaria is endemic or sporadic throughout most of the tropics and subtropics below an altitude of 1500 m, excluding the Mediterranean littoral, the United States, and Australia. Malaria is perhaps the most significant disease acquired through international travel to the tropics.
Five species of the genus Plasmodium infect humans: Plasmodium vivax, Plasmodium ovale, Plasmodium malariae, Plasmodium falciparum, and
Plasmodium knowlesi. In 2016, there were an estimated 216 million cases of symptomatic malaria worldwide (88% of which occurred in Africa), with
 about 445,000 deaths, 90% of which occurred in Africa, with nearly 77% of those occurring in young children. The great majority of malaria deaths are due to P. falciparum infections, although both P. vivax and P. knowlesi can also cause fatal disease. P. knowlesi is a zoonosis. Macaques (old world monkeys) are the natural host, and the transmitting mosquito’s habitat is limited to the forest fringe—a fact that may limit the spread of this species of
 parasite.
The global incidence of malaria (both cases and deaths) has decreased dramatically in recent years. In many countries, however, transmission has
 remained unchanged or even increased. Obstacles to successful reduction of malaria worldwide include human factors (poverty, war, inadequate international cooperation), capacities of the mosquito vector (changing temperatures, insecticide resistance), and parasite characteristics
(antimalarial drug resistance).
EPIDEMIOLOGY
Malaria transmission occurs in large areas of Central and South America, the Caribbean, sub­Saharan Africa, the Indian subcontinent, Southeast Asia,
 the Middle East, and Oceania. Certain species may predominate in a given geographic area. For example, P. vivax is more common in the Indian subcontinent, whereas P. falciparum is the most prevalent form in Africa, Haiti, and New Guinea. P. knowlesi has been found in several countries in
 southeast Asia, including Malaysia, Myanmar (Burma), Thailand, the Philippines, and Singapore.
The risk of contracting malaria varies considerably between regions. In 2014, the Centers for Disease Control and Prevention reported 1724 cases of
 malaria among persons in the United States. Of 1605 imported cases where the region of acquisition was known, 1383 (82%) were acquired in Africa
(70% of these in West Africa), 160 (9.5%) in Asia (62% of these in India), and  (3.4%) in Central and South America and the Caribbean. P. falciparum accounted for 66% and P. vivax for 13% of all cases (although in many cases, the parasite species was not identified). Thus >60% of all cases of malaria identified in the United States in 2014, including the majority of cases due to P. falciparum, were acquired from travels in West Africa, despite the fact that for every traveler to sub­Saharan Africa, at least  travelers visit potential malarious areas of Asia and South America each year.

Resistance of P. falciparum to chloroquine has been widespread for many years. Strains of P. falciparum have since become resistant to other chemotherapeutic agents, including pyrimethamine­sulfadoxine (no longer recommended as first­line treatment; can be used in pregnancy), quinine,
 mefloquine, and doxycycline. Widespread mefloquine­resistant strains of P. falciparum have been seen in parts of Thailand, Myanmar (Burma),
Cambodia, and China. Of greatest current concern is the observation in Cambodia and other parts of southeast Asia that parasites have become slower
 to respond to artemisinin therapy and that some artemisinin combination therapies have begun to fail. Worldwide vigilance is required to track the
 continuing efficacy of this important class of drugs. Resistance of P. vivax to chloroquine has also been identified in Southeast Asia.

PATHOPHYSIOLOGY
Chapter 159: Malaria, Malcolm E. Molyneux 
. Terms of Use * Privacy Policy * Notice * Accessibility
The organism is transmitted primarily by the bite of an infected female Anopheles mosquito, which requires a blood meal every  to  days to nourish its eggs. This vector is most frequently found in tropical and subtropical regions below 1500 m (5000 ft) above sea level. Plasmodial sporozoites are injected into the host’s bloodstream during the mosquito’s blood meal and are carried through the bloodstream to the liver. Within hours, the hepatic parenchymal cells are invaded, and asexual reproduction of the parasite begins (pre­erythrocytic schizogony or exoerythrocytic stage). After thousands of daughter merozoites have been formed within a hepatocyte (amplification cycle), the cell ruptures, releasing daughter merozoites into the circulation, where they rapidly invade erythrocytes to begin the erythrocytic stage of the asexual cycle. In P. vivax and P. ovale infection, a portion of the intrahepatic forms are not released, but remain dormant as hypnozoites, which can reactivate after months or years to cause clinical relapses.
A merozoite matures within the erythrocyte, feeding on hemoglobin and enlarging until it divides into about a score of daughter­merozoites to form a schizont. Eventually, the infected erythrocyte lyses, merozoites are released, and these invade uninfected red blood cells, continuing and amplifying the infection. Once merozoites enter the erythrocytic stage, they do not reinvade the liver.
A portion of the merozoites develop into sexual forms (gametocytes). Upon ingestion by another feeding Anopheles mosquito, male and female gametocytes undergo sexual reproduction within the vector’s gut and migrate as infective sporozoites to her salivary glands. To maximize her blood meal, the mosquito injects her next victim with saliva containing an anticoagulant, which introduces the malarial infection. The rate at which parasites replicate and migrate in the mosquito is temperature dependent; at average environmental temperatures below about 15°C (59°F), the cycle does not complete before the death of the mosquito, and malaria transmission cannot occur.
The clinical signs of malaria first appear during the erythrocytic stage. The rupture of schizont­containing erythrocytes triggers an array of host cytokine responses, giving rise to fever and other features of the malarial illness. Because fever slows the rate of schizont formation, early­stage parasites tend to catch up with more mature stages, and therefore over time, schizont rupture may become synchronous, giving rise to the periodic fever characteristic of untreated malaria. Such periodicity rarely has time to develop when malaria is treated promptly with efficacious drugs.
Each species of Plasmodium has specific characteristics, including typical morphologic forms and selective red blood cell tropism (Table 159­1). Many of these characteristics are responsible for important pathophysiologic consequences.
TABLE 159­1
Characteristics of Malaria­Causing Plasmodium Species
P.
P. falciparum P. vivax P. ovale P. knowlesi malariae
Clinical Characteristics
Incubation period 8–25 d 8–27 d 9–17 d 15–30 d Uncertain
Chloroquine Yes Rare No No No resistance
Fatal attack Yes No No No No
Relapse No Yes Yes No No
Histologic Characteristics
Asexual erythrocytic  h  h  h  h Uncertain cycle
RBC preference Reticulocytes (but can infect RBCs of all ages) Reticulocytes Reticulocytes Older cells All RBCs
Degree of High (multiple rings per RBC) Low Low Low Can be high parasitemia
Ring forms and early Ring forms predominate; threadlike cytoplasm Amoeboid Compact cytoplasm Compact Ring forms trophozoites with double­chromatic dots cytoplasm cytoplasm sometimes seen
Mature trophozoites Rarely seen Observed Observed Observed Observed
Schizonts Rarely seen Observed Observed Observed Observed
Gametocytes Banana shaped Round Round Round Round
Circumference of Normal Enlarged Oval, with ragged Normal Normal infected red cell (fimbriated) ends
Appearance of red Normal Stippled (fine Larger Schuffner’s Normal Normal cell cytoplasm Schuffner’s dots) dots
Abbreviation: RBC = red blood cell.
Anemia can develop rapidly with P. falciparum infection because the percentage of erythrocytes parasitized can be overwhelming (erythrocytes of all ages are susceptible to invasion) and because the life span of uninfected erythrocytes is also reduced, while bone marrow erythropoiesis is slowed or halted. P. falciparum asexual parasites transport to the red cell surface proteins that can adhere to host endothelial receptors, resulting in the sequestration of mature parasites in the microvasculature of many tissues and organs. Sequestration may be enhanced by the impaired deformability of infected erythrocytes and consequent slowing of blood flow through microvessels. Sequestration benefits parasites by keeping them away from the spleen, but additional consequences for the host include metabolic deprivation and/or impaired perfusion of tissues, processes that are believed to contribute to many of the syndromes characteristic of severe falciparum malaria. Acidosis, for example, results from tissue hypoxia, to which sequestration, hypotension, and severe anemia may all contribute. Hypoglycemia is largely due to impaired hepatic gluconeogenesis, possibly enhanced by the consumption of glucose by actively metabolizing parasites and the diversion of glucose for the host’s anaerobic glycolysis.
Sequestration accounts for the paucity of observed mature parasites in the peripheral smear of patients infected with P. falciparum.
Although nearly all malaria transmission is mediated by mosquito vectors, plasmodia of any species may also be transmitted by transfusion of infected blood, by needlestick accident, or across the placenta from mother to fetus. In these cases, an exoerythrocytic phase is absent, and hypnozoites of P.
vivax or P. ovale cannot develop.
Untreated, inadequately treated, or frequent malaria may lead to sequelae mediated by immunologic mechanisms, including massive splenomegaly with consequent hypersplenism, and glomerulonephritis leading to a nephrotic syndrome (attributed, without strong evidence, mainly to P. malariae infection). Thrombocytopenia (rarely sufficient to cause bleeding) is invariable in acute symptomatic malaria.
INCUBATION PERIOD
The incubation period between inoculation and symptoms varies with the species of parasite (Table 159­1). In the nonimmune, symptoms begin after an incubation period ranging from  days to several weeks or more. Incomplete suppression of disease by partially active chemoprophylaxis and partial immunity can prolong the incubation period to months or even years. For U.S. residents who developed malaria associated with travels abroad during 2014, 95% of those with P. falciparum infections reported symptom onset before or within  days of arrival in the United States. By contrast, in
41% of patients with P. vivax and in 66% of patients with P. ovale infections, symptoms began ≥30 days after arrival in the United States. Ninety­nine
 percent of infections with any species presented within  year of arrival in the United States.
CLINICAL FEATURES
In an area of intense transmission, most malaria infections occur in children, who gradually acquire a considerable degree of immunity. In such areas, a high percentage of children may have asymptomatic parasitemia (malaria infection), and illness due to malaria (malaria disease) is commonly mild and only occasionally severe or life threatening. Nevertheless, the absolute burden of mortality is large because nearly all children are infected.
Adults in such areas rarely develop severe or fatal disease.
By contrast, malaria due to P. falciparum is a medical emergency in a nonimmune host of any age, because the infection, if untreated, is likely to progress and to become life threatening. Once a P. falciparum infection has reached the stage of severe disease, there is a 5% to 30% risk of a fatal outcome, even if optimal treatment is then begun. The early clinical features of malaria are nonspecific, and malaria can mimic many other infections.
A diagnosis of malaria must be considered in any person returning from the tropics with an unexplained febrile illness and must be considered in any resident in the tropics who develops a fever.
UNCOMPLICATED MALARIA

The clinical hallmark of malaria is fever, with a prodrome of malaise, myalgia, headache, and chills. In some patients, chest pain, cough, abdominal pain, or arthralgias may be prominent. Early symptoms are nonspecific and can easily be confused with a viral syndrome such as influenza or hepatitis or with bacterial sepsis. In a nonimmune individual, the illness usually progresses to include chills, followed by high­grade fever accompanied by nausea, orthostatic dizziness, and extreme weakness. After several hours, the fever abates and the patient develops diaphoresis and becomes exhausted. If the infection is untreated, the paroxysms of malaria—chills and fever followed by diaphoresis—may over time begin to occur at nearly regular intervals that correspond to the length of the asexual erythrocytic cycles (Table 159­1). The classic paroxysms of malaria are often lacking in malaria due to P. falciparum or in persons who received some form of chemoprophylaxis. The findings upon physical examination are also not specific for malaria. Most patients appear acutely ill with high fever, tachycardia, and tachypnea. Splenomegaly and abdominal tenderness are common. The liver may or may not be enlarged. Clinical signs that point to a diagnosis other than (or in addition to) malaria include lymphadenopathy and a maculopapular or petechial rash.
In children growing up in a malarious area, attributing an illness to malaria is particularly difficult because many children carry parasites without being
 unwell and because symptoms and signs of both mild and severe malaria are nonspecific. In these circumstances, the higher the parasite density in the peripheral blood, the greater is the likelihood that malaria is the cause of the illness.
SEVERE (COMPLICATED) MALARIA
Malaria is described as severe or complicated when it includes one or more of the following syndromes in the context of a plasmodial infection, usually due to P. falciparum: coma with or without seizures (“cerebral malaria”), prostration, severe anemia, acidosis, hypoglycemia, acute renal failure, acute respiratory distress syndrome, pulmonary edema, jaundice, intravascular hemolysis, shock, and disseminated intravascular coagulation. Of 1724
 malaria cases reported in the United States in 2014, 293 (17%) became severe, and five patients died (1.7% of the 293 severe cases).
Complications of malaria can develop rapidly in untreated P. falciparum infection or may supervene early in the course of treatment. Occasionally, one or more complications may constitute the presenting illness, when correct diagnosis may be both difficult and critically important. A patient with severe malaria is at risk of dying even with optimal case management. Case fatality rates range between 5% and 30% in patients receiving treatment for severe malaria according to the complications present and their intensity.
When cerebral malaria is suspected, meningitis or encephalitis must be either excluded or treated, and the clinician must decide whether a lumbar puncture is safe. At lumbar puncture, the opening pressure is usually raised in children and normal in adults. The fluid is normal in appearance and on routine tests. In children in P. falciparum–endemic areas, asymptomatic parasitemia is common, so it is difficult to be sure that an illness is due to malaria. In a child with coma and parasitemia, the presence of a recently identified retinopathy (Figure 159­1) greatly strengthens confidence that
 malaria is the cause of the syndrome. Among those who recover from cerebral malaria, up to  in  children and up to  in  adults may be left with, or may later develop, neurologic sequelae.
FIGURE 159­1. Retinal examination in a child with cerebral malaria. Note the patches of whitening around the fovea (dark area .5 disc diameters from the disc, right of field). Note also scattered white­centered hemorrhages. [Photo contributed by Ian McCormick, MD.]
Infections caused by any species of Plasmodium can result in hemolysis, some degree of anemia, splenic enlargement, and, occasionally, traumatic rupture of the enlarged spleen.

The very young, the elderly, and pregnant women are at greatest risk of developing complications when infected with P. falciparum. Additional risk factors for severe malaria include an immunocompromised state, asplenia, failure to take appropriate chemoprophylaxis, refusal of or delay in
 seeking medical care, and late or erroneous diagnosis.
DIAGNOSIS
The diagnosis of malaria rests on a history of potential exposure in a malarious area, clinical symptoms, signs, and competent microscopic examination of well­prepared thick and thin blood films (Figure 159­2). Diagnosis based on clinical features alone has very low specificity and results
 in overtreatment.
FIGURE 159­2. A. Thick and B. thin blood microscopy films from different children with malaria. The thick film shows numerous parasite nuclei, each with a faint blush of cytoplasm, seen either as a ring or as a smudge beside the nucleus. The thin film shows a single early ring stage of Plasmodium falciparum
(center of field). The absence of dots in the erythrocyte cytoplasm and the normal size and shape of the erythrocyte distinguish this from Plasmodium vivax and Plasmodium ovale.
The three major questions to be answered by the blood smear are as follows: (1) Is there evidence of malaria? (2) If so, what is the density of parasitemia (correlates with prognosis)? (3) What species of malaria is responsible for the infection, and in particular, is P. falciparum present? Clues to the diagnosis of P. falciparum infection include the presence of small ring forms with double­chromatin dots within the erythrocyte, multiple infected rings in individual red blood cells, a paucity (usually absence) of mature trophozoites and schizonts on smear, and infected erythrocytes that are not enlarged and that have cytoplasm without basophilic stippling. In some (but not all) cases, gametocytes may be seen; in P. falciparum infection, these have a diagnostic crescent shape (banana shape). Parasite densities above 4% of erythrocytes are rare in malaria due to non­falciparum species.
Obtain smears daily to assess the efficacy of drug treatment.
P. knowlesi is usually misdiagnosed as the less aggressive P. malariae, because the two are identical under light microscopy and require polymerase chain reaction for differentiation. Any patient coming from Asia with a high parasite burden resembling P. malariae should be assumed to be
 harboring P. knowlesi.
THICK BLOOD FILM
Place a small drop of blood (5 μL) on a microscope slide, spread it evenly to a diameter of approximately  cm, allow it to dry, and then stain, without initial fixation, with Field’s or Giemsa stain. Record the result as the number of parasites seen per oil­immersion field (for an approximate indication of density) or per 200 white cell nuclei counted (a more accurate density of parasites can then be calculated once the WBC count is known). A thick blood film contains several layers of red cells (which are lysed by the staining procedure), allowing parasitemias down to approximately 40/µL to be detected by an expert microscopist.
THIN BLOOD FILM
A standard hematologic blood smear (fixed with methanol and stained with Giemsa) allows a single sheet of intact red cells to be scrutinized for the percentage of red cells parasitized, from which the number of parasites per microliter can be calculated when the red cell count is known. Because the red cells are not destroyed, a thin film allows both parasite and red cell morphology to be examined, enabling more confident identification of the species of plasmodium. A thin film may fail to detect a parasitemia with a density below approximately 1000/µL, but it is more useful than a thick film for counting very heavy infections.
A long and careful search for parasites is necessary before a film is declared “negative.” In early infection, especially infection due to P. falciparum, in which mature­stage parasitized erythrocytes are sequestered from the bloodstream, parasitemia may be undetectable even in a competently read thick blood film. In highly suspicious cases, failure to detect parasitemia is not an indication to withhold therapy. If parasites are not seen in the stained thin smear, a thick smear must be done. If parasites are not seen on the first thick film, obtain repeat thick smears at least twice
 daily for as long as malaria remains a suspected diagnosis or until the patient is better. The first smear is positive in >90% of cases.
ADDITIONAL DIAGNOSTIC TECHNIQUES
Rapid diagnostic tests now make an important contribution to immediate diagnosis where facilities are limited. Rapid diagnostic tests detect parasite
 antigens (BinaxNOW®, ParaSight­F®) or the parasite enzyme lactate dehydrogenase (OptiMal®). The sensitivity of rapid tests is close to that of thick blood films, especially for P. falciparum malaria. Antigen­detecting rapid tests remain positive for up to a month after a malarial infection, even if the infection has been successfully treated.
Polymerase chain reaction–based techniques to detect parasite DNA are more sensitive than microscopy and are valuable for research studies, but are rarely available for routine clinical purposes.
ADDITIONAL LABORATORY STUDIES
Nonspecific laboratory features of malaria include normochromic normocytic anemia with findings suggestive of hemolysis, a normal or mildly depressed total leukocyte count, thrombocytopenia, an elevated erythrocyte sedimentation rate, and mild abnormalities in liver and renal functions. In severe P. falciparum malaria, there may be hypoglycemia, severe anemia, hyperlactatemia, electrolyte disturbances, or evidence of acute renal failure or disseminated intravascular coagulation.
TREATMENT
Treatment decisions are based on the severity of the illness and the species of the infecting parasite determined by microscopic examination of thick
 and thin blood films. Treatment guidelines in this section are based on the most current information available as of this writing. The World Health
 ,17
Organization and the Centers for Disease Control and Prevention update and publish practice guidelines at intervals for the diagnosis and treatment of malaria.
UNCOMPLICATED (NONSEVERE) MALARIA DUE TO P. FALCIPARUM
Admit the patient to the hospital because severe disease can develop rapidly, even after the start of specific therapy. Give analgesia if required (e.g., acetaminophen, 500 milligrams every  hours PO) and oral fluids. If the patient can take and retain drugs by mouth, begin a full course of oral antimalarial drugs without delay (Table 159­2). Artemisinin­containing combination therapies are considered the drugs of choice by the World Health
,15
Organization. If a dose is vomited, the dose may be repeated; if it is vomited again, switch to parenteral therapy as for severe disease (see Table
159­3) until able to resume treatment by mouth. Maintain regular checks for the development of any complications (listed earlier under “Clinical
Features”). Check blood daily for parasite density and for hemoglobin concentration. When stable, the patient may be discharged to complete the course of oral drugs at home; stress the importance of completing the course and of reporting back with any recurrence of symptoms.
TABLE 159­2
Drug Options for Therapy of Uncomplicated Plasmodium falciparum Malaria
Treatment of Choice Is an Artemisinin­Containing Combination Therapy (ACT)
Drug Adult Dose Pediatric Dose
Artemether­lumefantrine (Coartem®; each tablet contains  tablets twice daily for  d (the first  doses should be 5–15 kg:  tab initially,  artemether  milligrams and lumefantrine 120 milligrams) about  h apart) tablet in  h, then  tablet every  h ×  d
15–25 kg:  tablets initially,  tablets in  h, then  tablets every  h
×  d
25–35 kg:  tablets initially,  tablets in  h, then  tablets every  h
×  d
>35 kg: follow adult dosing
Artesunate­amodiaquine (where available; not available in the  tablets once daily for  d  to <9 kg:  tablet/d of
United States; each adult tablet contains artesunate 100 artesunate (AS)  milligrams and amodiaquine hydrochloride salt 270 milligrams) milligrams/amodiaquine
(AQ) .5 milligrams
 to <18 kg:  tablet/d of
AS  milligrams/AQ 135 milligrams
 to <36 kg:  tablet/d of
AS 100 milligrams/AQ 270 milligrams
≥36 kg:  tablets/d of AS
100 milligrams/AQ 270 milligrams (adult dose)
Alternatives to ACT
Drug Adult Dose Pediatric Dose
Atovaquone­proguanil (Malarone®; each adult tablet contains  tablets once daily for  d. Do not use for treatment if 5–8 kg:  pediatric tablets atovaquone 250 milligrams and proguanil 100 milligrams; each atovaquone­proguanil has been taken as ×  d pediatric tablet contains atovaquone .5 milligrams and chemoprophylaxis and the patient’s current illness is a 9–10 kg:  pediatric proguanil  milligrams) suspected treatment failure. tablets ×  d
11–20 kg:  adult tablet ×
 d
21–30 kg:  adult tablets ×
 d
31–40 kg:  adult tablets ×
 d
>41 kg: adult dose
Quinine sulfate (plus doxycycline or clindamycin) 650 milligrams PO every  h for 3–7 d  milligrams sulfate salt/kg, up to adult dose
PO every  h for 3–7 d
Plus
Doxycycline 100 milligrams PO every  h for  d .2 milligrams/kg (up to adult dose of 100 milligrams) PO every  h for  d.
Or in children under age  y
Clindamycin  milligrams/kg PO every
 h for  d
TABLE 159­3
Antimalarial Drug Options for Severe (Complicated) Malaria
Drug Adult Dose Pediatric Dose
Artesunate* (available from .4 milligrams/kg IV at , , and  h, then daily. .4 milligrams/kg IV at , , and  h, then daily.
the CDC if quinidine fails to Artesunate can be given IM if necessary. Artesunate can be given IM if necessary.
provide improvement; call 770­
488­7788)
Quinidine gluconate (plus .25 milligrams base (=  milligrams salt)/kg IV load over .25 milligrams base (=  milligrams salt)/kg IV load over doxycycline or clindamycin)†  h (maximum, 600 milligrams), follow with .0125  h (maximum, 600 milligrams), follow with .0125 milligram base (= .02 milligram salt)/kg/min continuous milligram base (= .02 milligram salt)/kg/min continuous infusion. infusion.
Plus
Doxycycline .2 milligrams/kg IV (up to adult dose of 100 milligrams) .2 milligrams/kg IV (up to adult dose of 100 milligrams) every  h for  d. every  h for  d.
Or in children under age  y
Clindamycin  milligrams base/kg loading dose IV followed by  milligrams base/kg IV every  h for  d.
Abbreviation: CDC = Centers for Disease Control and Prevention.
*Artesunate is considered the drug of choice by World Health Organization guidelines.
†Quinine dihydrochloride is an alternative to quinidine gluconate (20 milligrams [salt]/kg infused IV over 2–4 hours, then  milligrams/kg every  hours, can be given IM if necessary, as  milligrams/mL solution).
The World Health Organization does not recommend chloroquine for the treatment of P. falciparum malaria, owing to changing resistance patterns
,15 and the superiority of artemisinin­containing combination therapies. As of July 2017, the Centers for Disease Control and Prevention recommends chloroquine for P. falciparum malaria imported from areas of low chloroquine resistance including Central America west of the Panama Canal, Haiti,
,17 the Dominican Republic, and parts of the Middle East. Dose options are listed at the Centers for Disease Control and Prevention malaria website
(http://www.cdc.gov/malaria/).
UNCOMPLICATED MALARIA DUE TO P. VIVAX, P. MALARIAE, P. OVALE, OR P. KNOWLESI
Admission to the hospital should not be necessary in most cases; however, if P. knowlesi is suspected, hospital admission is recommended. Dual infection with P. falciparum and any of the other species is possible. Make sure that the initial and subsequent slides are carefully scrutinized for evidence of P. falciparum, because severe disease may then develop even while on treatment. Give simple analgesia and fluids as required. Treat nonfalciparum malaria with chloroquine (each tablet contains 250 milligrams of salt = 150 milligrams of base); the adult dose is four tablets initially, then two tablets after  hours, then two tablets daily for  days. The pediatric dose is .7 milligrams (salt)/kg PO immediately, followed by .3 milligrams (salt)/kg PO at , , and  hours. A preferable alternative is an artemisinin combination therapy (Table 159­3 for dosage). P. vivax malaria
 acquired from an area with chloroquine resistance should be treated with artemisinin­containing combination therapy.
Patients with P. vivax or P. ovale malaria require additional treatment to eradicate hypnozoites from the liver. This treatment can be given after full recovery from the initial illness; the most common agent used is primaquine phosphate. The adult dose is  milligrams of base per day for  days.
First check the patient for glucose­6­phosphate dehydrogenase deficiency (glucose­6­phosphate dehydrogenase–deficient persons are at risk of hemolysis when treated with primaquine; an alternative management of relapsing malarias is chloroquine base 300 milligrams weekly for  months).
Treatment with primaquine is not needed in patients with P. falciparum or P. malariae malaria because there are no dormant asexual forms in the liver.
P. vivax or P. ovale infections that have been acquired by needlestick accident, blood transfusion, or transplacental infection do not need treatment with primaquine for the same reason. However, primaquine is recommended after completion of treatment for P. falciparum in areas where onward
 transmission of the parasite must be prevented (e.g., in countries approaching elimination).
SEVERE (COMPLICATED) MALARIA
Severe malaria is usually due to P. falciparum, but occasionally, it is due to P. vivax or P. knowlesi. The patients should be admitted to an appropriate level of intensive care. Both supportive and specific antimalarial therapies are urgent and critical to the patient’s survival. Monitor the patient frequently; new complications may develop after the start of treatment.
Supportive Management
Initial resuscitation may require oxygen for hypoxia, fluid replacement, IV glucose for hypoglycemia, blood or platelet transfusion for severe anemia or for disseminated intravascular coagulation, and occasionally intubation for severe respiratory distress or suspected raised intracranial pressure with altered mental status. Additional treatments for septic shock may be necessary (see Chapter 151, “Sepsis”). Monitor to identify and treat seizures, hyperpyrexia, acute respiratory distress syndrome, or acute renal failure. Culture blood samples for bacterial infections, and give immediate parenteral antibiotics, because a bacterial coinfection cannot be ruled out by clinical assessment initially.
Specific Antimalarial Chemotherapy
Initiate parenteral therapy with an efficacious antimalarial drug without delay. Options are listed in Table 159­3. With any of the regimens in Table 159­3, continue the treatment by a parenteral route for at least  hours; thereafter, as soon as the patient is well enough to take drugs by mouth, switch to a complete course of the best available oral therapy (Table 159­2). If the patient remains unable to take oral therapy, the chosen parenteral therapy should be continued for a maximum of  days.
Do not delay treatment while awaiting laboratory confirmation, because the initial smear for P. falciparum may be negative, even on microscopy of a thick blood film, in a nonimmune individual. An unstable patient (abnormal vital signs or any systemic complication) with a clinical or travel history suggesting malaria should be started on artesunate (if available) or quinidine gluconate (Table 159­3) until a diagnosis of malaria can be ruled out.
In the United States, parenteral quinine should be reserved for individuals who develop, or who are considered to be at high risk of developing, cardiotoxicity while receiving IV quinidine.
To initiate a patient with severe malaria in the Centers for Disease Control and Prevention treatment protocol (United States only) using artesunate, contact the Centers for Disease Control and Prevention Malaria Hotline: 770­488­7788 (Monday–Friday,  a.m.–5 p.m., Eastern time), or after hours, call 770­488­7100 and request to speak with a Centers for Disease Control and Prevention

Malaria Branch clinician.
IV artesunate is the drug of choice for severe malaria, according to the World Health Organization. Artesunate is rapidly effective and extremely potent
 against all erythrocyte stages. It does not cause cardiac toxicity or hypoglycemia. It is effective and is superior to IV quinine or quinidine in both adults
 and children. Prompt treatment for severe malaria is critical, and artesunate’s major limitation at present in the United States is its lack of timely availability.
RATES OF PARASITE CLEARANCE
With correct treatment, the parasite load in the peripheral blood should decrease rapidly during the first few days. This decrease is significantly faster with artemisinin drugs than with all other therapies, because artemisinin drugs kill early­stage as well as late­stage parasites. With artemisinin treatment, the parasite count usually decreases significantly within the first  hours, whereas with other drugs, this decrease may take  to  hours.
In a patient treated with quinidine or quinine, the density of asexual parasites may be unchanged or even increased after  hours of therapy, but this is rarely the case in a person treated with an artemisinin therapy. Asexual forms of the parasite should not be detectable within  days of the start of any effective treatment course. Gametocytes, the sexual forms, which do not cause disease in the human host, may persist for several weeks after treatment and do not indicate treatment failure.
COMPLICATIONS OF TREATMENT
Complications of treatment are listed in Table 159­4. TABLE 159­4
Adverse Effects, Precautions, and Contraindications of Antimalarial Drugs
Drug Minor Toxicity Major Toxicity Precautions/Contraindications
Chloroquine Nausea/vomiting, diarrhea, Rare; hypotension and shock after parenteral therapy Avoid in patients with severe pruritus, postural Retinopathy after prolonged use psoriasis and some types of hypotension, rash, fever, porphyria. Caution with decreased headache, dizziness liver function.
Quinine or Cinchonism (nausea and Hypotension, cardiac dysrhythmias, hypoglycemia, Coombs­ Contraindicated in cardiac disease.
quinidine vomiting, headache, tinnitus, positive hemolysis, abortions, neuromuscular paralysis Caution in pregnancy, myasthenia dizziness, visual disturbance) (myasthenia) gravis.
Mefloquine Nausea/vomiting, cramps, Rare unless underlying heart disease with bradycardia or the Precaution during pregnancy and in diarrhea, anorexia, dizziness, patient is on selected cardiotoxic medications (dysrhythmias, children weighing <10 kg.
headaches, nightmares, and arrest); acute toxic confusional states may occur, as can Avoid if the patient is receiving bradycardia seizures quinidine.
Avoid if the patient has heart conduction disturbance or if underlying seizure or major neuropsychiatric disorders.
Doxycycline GI disturbances, phototoxicity, Rare; esophageal ulcerations if not taken with fluids Avoid during pregnancy and in vaginal candidiasis children <8 y of age unless alternatives not available.
May depress prothrombin time in patients receiving anticoagulants.
Artemether­ Headache, dizziness, anorexia, Rare; severe skin rash, QT prolongation Avoid use with other drugs that may lumefantrine and asthenia prolong QT interval.
(Coartem®) Drug interactions with cytochrome
P450 3A4 and cytochrome P450 2D6. Atovaquone­ Nausea, vomiting, cramps, oral Rare serious allergic reactions and alopecia reported Contraindicated in pregnancy and in proguanil ulcers, headaches, dizziness children <5 kg (no safety data) and in
(Malarone®) patients with creatinine clearance
<30. Primaquine* Nausea, vomiting, diarrhea, Massive hemolysis in patients with G6PD deficiency Contraindicated in G6PD deficiency, cramps, methemoglobinemia Exacerbation of systemic lupus erythematosus or rheumatoid pregnancy.
arthritis
Abbreviation: G6PD = glucose­6­phosphate dehydrogenase.
*Terminal treatment for Plasmodium vivax and Plasmodium ovale infections only.
Glucocorticoids are of no proven benefit for cerebral malaria and should not be used. Other unproven or harmful adjunctive therapies include heparin, iron chelators, pentoxifylline, and dichloroacetate.
Quinine and quinidine are potent inducers of insulin release and may cause severe hypoglycemia, especially during pregnancy. Sudden changes in orientation, sweating, tremor, tachycardia, or anxiety should prompt bedside glucose measurement and treatment accordingly. Cinchona alkaloids are myocardial depressants, so cardiac monitoring is needed during administration of quinidine or quinine. At least partial resistance to quinine has been reported in Southeast Asia, but it has not yet been identified in Africa.
DISPOSITION AND FOLLOW­UP
Many patients feel better after the first day or two of treatment for uncomplicated malaria. Emphasize the importance of completing the treatment, because partial therapy may fail to eliminate parasites and may be followed by recrudescence of infection. Advise the patient to report any recurrence of symptoms, because even completed treatment may fail or an unrecognized additional infection may emerge. An episode of malaria is an opportunity to advise an individual about how to prevent further infections. After severe malaria, review the patient at intervals for any sequelae.
Survivors of acute kidney injury, acute respiratory distress syndrome, or severe anemia usually recover fully, but cerebral malaria may be followed by
 neurologic sequelae in a proportion of cases, especially in children.
SPECIAL CONSIDERATIONS
PREGNANCY
Among nonimmune adults, those who are pregnant are at greater risk of developing severe disease than others. Pregnant women are at particular risk of anemia, hypoglycemia, and, especially in the third stage of labor, fluid overload. Artemisinin drugs are probably safe in pregnancy but are still subject to restriction in the first trimester. Quinidine and quinine can be used in pregnancy but carry a greater risk of causing hypoglycemia through stimulation of insulin secretion from hypertrophied pancreatic β­cells.
PREVENTION
Both the Centers for Disease Control and Prevention and World Health Organization publish information regarding prevention of malaria for residents of endemic areas and for travelers who are considering visiting those countries. These recommendations are updated at regular intervals.


