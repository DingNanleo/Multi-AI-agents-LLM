## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 284: Joints and Bursae
John H. Burton; Timothy J. Fortuna
INTRODUCTION
Many mechanisms provoke acute joint symptoms: degradation and degeneration of articular cartilage (osteoarthritis), deposition of immune complexes or immune system–related phenomena (rheumatoid arthritis, rheumatic fever, and possibly, a component of gonococcal arthritis), crystal­induced inflammation (gout and pseudogout), seronegative spondyloarthropathies (ankylosing spondylitis [see Chapter 282, “Systemic Rheumatic Diseases”] and reactive arthritis [postinfectious with HLA­B27 susceptibility]), and bacterial or viral invasion (gonococcal and nongonococcal septic arthritis, including Lyme arthritis). These processes impact joint capsules and surfaces, resulting in a cascade of reactive and inflammatory events. This chapter reviews the common causes and treatments of acute nontraumatic joint pain. Joint injuries are discussed in Section , “Orthopedics,” and disorders due to repetitive use syndromes are discussed throughout Section , “Musculoskeletal Disorders,” by anatomic site.
CLINICAL APPROACH TO ACUTE JOINT PAIN
Septic arthritis is the most important consideration in the evaluation of a swollen, warm, and painful joint. Septic arthritis is invasion of a joint by an infectious agent with organism proliferation and associated inflammation; bacterial arthritis is a subset of septic arthritis. Urgent treatment may prevent both joint destruction and mortality (6% to 11% with treatment).1­3
Septic arthritis is a clinical diagnosis supported by diagnostic tests.1,4No single diagnostic parameter is sufficiently sensitive to screen patients for septic arthritis including synovial WBC counts.5
CLINICAL FEATURES AND RISK FACTORS
Risk factors (Table 284­1),5,6 the number of joints involved (Table 284­2), and the migratory pattern, if one exists, aid in the differential diagnosis. Approximately 85% of patients with nongonococcal septic arthritis present with a single joint infected; Staphylococcus aureus and Streptococcus pneumoniae are more likely to infect two or more joints simultaneously.7­10
Septic arthritis involving more than one joint can occur in rheumatoid arthritis (50%), immunocompromise, gout, diabetes, and/or renal disease; the morality rate is significantly higher in patients with polyarticular septic arthritis (11% vs. 30%).7,9 Recent joint surgery and cellulitis overlying a prosthetic hip or knee are the only findings on history or physical examination that significantly alter (both increase) the probability of nongonococcal septic arthritis.5 Joint disorders associated with migratory pattern include gonococcal arthritis, acute rheumatic fever,
Lyme disease, and viral arthritis.
TABLE 284­1
Risk Factors for Nongonococcal and Gonococcal Septic Arthritis
Nongonococcal Gonococcal
Injection drug use* HIV infection* Diabetes mellitus* Injection drug use* Rheumatoid arthritis* Pregnancy
Prosthetic joint, knee,* or hip* Menses
Immunosuppression, HIV* Systemic lupus erythematosus
Age: >80 y old* Complement deficiency
Skin ulceration and/or infection* Hemophilia
Hypogammaglobulinemia
Malignancy
Hemodialysis
Liver disease
DownAllcooahodliesmd 2025­7­1 9:1 P Your IP is 136.142.159.127
Chapter 284: Joints and Bursae, John H. Burton; Timothy J. Fortuna 
Steroid therapy
. Terms of Use * Privacy Policy * Notice * Accessibility
Abbreviation: HIV = human immunodeficiency virus.
*Risk factors supported by epidemiologic study.
TABLE 284­2
Differential Diagnosis of Arthritis by Number of Affected Joints
Number of Joints Differential Considerations for Typical Presentations
 = Monoarthritis 85% of nongonococcal septic arthritis* Crystal­induced (gout, pseudogout)
Gonococcal septic arthritis
Trauma­induced arthritis
Osteoarthritis (acute)
Lyme disease
Avascular necrosis
Tumor
2–3 = Oligoarthritis† 15% of nongonococcal septic arthritis, more common with Staphylococcus aureus and Streptococcus pneumoniae
Lyme disease
Reactive arthritis (Reiter’s syndrome)
Gonococcal arthritis
Rheumatic fever
>3 = Polyarthritis† Rheumatoid arthritis
Systemic lupus erythematosus
Viral arthritis
Osteoarthritis (chronic)
Serum sickness
Serum sickness–like reactions
*Involvement of more than one joint does not rule out septic arthritis.
†The distinction between oligoarthritis and polyarthritis varies in the literature with a cut point of either three or four joints.
SYNOVIAL FLUID ANALYSIS
When septic arthritis is suspected, aspirate joint fluid, and obtain analysis and culture of the aspirate to direct treatment.1,4Table 284­3 provides diagnostic guidance based on synovial fluid results in the context of different patient characteristics.1,3­14
TABLE 284­3
Septic Arthritis: Joint Aspiration Results in Different Patient Groups* Joint
Key Factor Patient Status Diagnostic Considerations/Management
Aspiration
Positive Gram stain Acute joint pain and swelling Gram stain Initiate empiric IV antibiotics, admit to the hospital, monitor culture and patient course (positive Gram stain is positive for found in <50% of patients with septic arthritis).
bacteria
Classic synovial WBC Acute joint pain and swelling >50,000 Synovial fluid with >50,000 WBC/mm3 is 56% sensitive and 90% specific for septic arthritis. Initiate empiric IV count WBC/mm3 or antibiotics and hospital admission.
>90% PMNs
Increased sensitivity Acute joint pain and swelling in a >25,000 Synovial fluid with >25,000 WBC/mm3 is 73% sensitive and 77% specific for septic arthritis. Consider empiric IV of lower synovial patient with risk factors for septic WBC/mm3 or antibiotics and admission to the hospital for monitoring of patient course and cultures.
WBC counts arthritis or systemic signs of infection >90% PMNs
Acute gout with Acute joint pain and swelling; patient Crystals, Crystal­induced arthritis may coexist with septic arthritis in up to 27% of cases; cell counts are <6000 WBC/mm3 in coexisting septic with acute gout or history of gout with >2000 10% of infected joints; more than one joint is involved in 10%–45%. Look for infected tophi. Consider empiric IV arthritis systemic signs of infection WBC/mm3, or antibiotics and admission to the hospital pending cultures.
>90% PMNs
Prosthetic joint Acute pain and swelling in patient with >10,000 Consult operating orthopedic surgeon before aspiration if possible. AAOS definition for acute periprosthetic prosthetic joint WBC/mm3, infection is  of the following: (1) CRP elevated above 100 milligrams/L and ESR elevated above local norm, (2)
>90% PMNs synovial WBC >10,000/mm3, (3) synovial PMNs >90%, (4) positive culture, and (5) positive histologic analysis of periprosthetic tissue.
Immunocompromise Joint swelling in an >200 Immunocompromised patients sustain septic arthritis with diminished immune response; cell counts and percent immunocompromised patient or WBC/mm3, PMNs are frequently lower than in immunocompetent patients with similar infections. Consider empiric IV systemic signs of infection in a patient >25% PMNs antibiotics and admission to the hospital for monitoring of patient course and cultures.
with immunocompromise
Gonococcal arthritis Monoarticular or polyarticular joint ,000– Positive culture in <50% of infected joints; collect urogenital cultures plus pharynx and rectum cultures as pain in a patient with history of ,000 determined by history. Consider empiric IV antibiotics and admission to the hospital for monitoring of patient unprotected sex (primarily in young WBC/mm3 course and cultures.
patients)
Rheumatoid arthritis Joint pain and/or swelling in a patient 2000–120,000 Severe pain and limited range of motion may be absent in patients on immunosuppression. Look for infected with coexisting septic with rheumatoid arthritis WBC/mm3 rheumatoid nodules or ulcerated foot calluses; source in 76% of cases. Consider empiric IV antibiotics and arthritis admission to the hospital for monitoring of patient course and cultures.
Lyme disease Acute joint pain in a patient living in a 200–300,000 Consider empiric antibiotics and close follow­up to monitor culture and patient course; admit if clinical picture is
Lyme disease–endemic area or with a WBC/mm3 indistinguishable from septic arthritis. Arthralgia appears months after initial symptoms. Joint effusion (moderate history of rash or tick bite to large) may be out of proportion to the patient’s pain (mild to moderate). Knee is the most common affected joint.
Post trauma Joint trauma several days prior, initial 0–2000 Posttraumatic effusions may become infected in patients with skin infections or bacteremia. Aspiration of the joint swelling, now increasing pain WBC/mm3, reduces pain for approximately  week, but has no effect on long­term disability.
<25% PMNs,
0–500
RBC/mm3
Dry tap Patient with acute joint pain and No fluid Major causes of dry tap are mistaken physical diagnosis of effusion; blockage of the needle by plica, fat, or debris; suspected swelling, with or without aspirated or synovial fluid with high viscosity or true lipoma arborescens (benign replacement of subsynovial tissue by fat other symptoms or signs to suggest cells). Use US to determine true effusion and direct needle to largest collection of fluid.
septic arthritis
Normal synovial cell Patient with sufficient joint pain and <200 Normal WBC cell counts and differential percentages make the diagnosis of septic arthritis unlikely in a patient counts swelling to warrant arthrocentesis, no WBC/mm3, without comorbidities or objective signs of infection. A mechanism should be in place for timely follow­up of comorbidities, absent signs and <25% PMNs culture results if they turn positive.
symptoms of sepsis
Abbreviations: AAOS = American Academy of Orthopedic Surgeons; CRP = C­reactive protein; ESR = erythrocyte sedimentation rate; PMNs = polymorphonuclear leukocytes; RBC = red blood cell.
*All patients who received joint aspiration for suspected septic arthritis should have cultures of synovial fluid, blood, and any nonjoint source clinically suspected of infection (e.g., skin, urine).
Analyze joint fluid for Gram stain, leukocyte count with differential, and a wet preparation for crystals.6,8 Glucose, protein, and lactate dehydrogenase levels do not direct treatment decisions.6 An elevated synovial lactate level or novel biomarker presepsin suggests septic arthritis.5,15 Culture for gonococci and anaerobes, in addition to typical gram­positive and gramnegative organisms.1,4,6
SERUM LABORATORY STUDIES
Serum erythrocyte sedimentation rate and C­reactive protein levels are commonly elevated in several acute inflammatory and reactive arthritides (gonococcal and nongonococcal septic arthritis, crystal­induced, spondyloarthropathies, and rheumatoid and Lyme arthritis) but are not helpful for establishing a specific diagnosis in adults. However, erythrocyte sedimentation rate and C­reactive protein are recommended by the British Society of Rheumatology4 and the American Academy of Orthopedic Surgeons as an aid to monitor response to therapy. These guidelines include erythrocyte sedimentation rate and C­reactive protein as part of their minor criteria for the diagnosis of acute periprosthetic joint infection (Table 284­3).13 The American
Academy of Orthopedic Surgeons also recommends that an elevation of either erythrocyte sedimentation rate or C­reactive protein be used as a criterion to aspirate a painful prosthetic joint with increased warmth.13 The sensitivity of the serum WBC count in adults for the diagnosis of nongonococcal bacterial septic arthritis is approximately 60%.5 Blood cultures should be obtained before antibiotic therapy for presumptive or possible septic arthritis. However, the sensitivity for identifying the causative organism in adults and children with nongonococcal bacterial septic arthritis is 23% to 36%.5 Elevated procalcitonin levels provide 90% specificity to help rule in the diagnosis of septic arthritis but are only 67% sensitive in screening for the diagnosis.5,16
Laboratory studies can aid in the diagnosis at follow­up. Possible studies include Lyme titer, rheumatoid factor, antinuclear antibodies, antineutrophil cytoplasmic antibodies, HLA­B27 tissue typing, lupus anticoagulant, and repeat synovial fluid analysis.
IMAGING
Bedside US is a useful tool to identify joint effusion and aids successful joint aspiration.17,18 Obtain radiographs of an inflamed joint if trauma, tumor, avascular necrosis, and osteomyelitis are diagnostic considerations. MRI is not recommended for directing assessment of septic arthritis but may be helpful for difficult diagnostic cases. MRI is more sensitive to identify joint effusion than specific for the diagnosis of septic arthritis.19 Radioisotope scanning is not usually required for ED diagnosis but can be useful to detect osteomyelitis, occult fracture, avascular necrosis, or tumor.
ARTHROCENTESIS
Prepare the site to avoid bacterial contamination. The skin overlying the affected joint should be free of cellulitis or impetigo to avoid contamination of the joint space during arthrocentesis.
Orthopedics should be consulted before aspiration of a prosthetic joint for direction in diagnostic workup and interpretation of results.13 Other relative contraindications to joint aspiration are coagulopathy in high­risk patients such as suspected hemarthrosis in hemophiliac patients before factor replacement.20 Routine preprocedure laboratory screening for coagulopathy prior to arthrocentesis is not necessary. Anticoagulation should not be viewed as an absolute contraindication to arthrocentesis. Arthrocentesis is typically a safe procedure in the anticoagulated patient, including those on direct oral anticoagulants.21
Cleanse a large area overlying and adjacent to the affected joint with povidone­iodine solution. After air drying, clean the skin with an alcohol wipe to remove the povidone­iodine solution from the skin surface. Removal of the overlying povidone­iodine prevents the introduction of the povidone­iodine antiseptic into the joint, which can result in chemical irritation or sterilization of the aspiration sample. Next place sterile drapes over the site and maintain sterile technique throughout the procedure.
Anesthetize the skin and soft tissues overlying the joint with a 25­ to 30­gauge needle. Avoid intra­articular injection of anesthetic because the anesthetic can inhibit bacterial growth and may result in a spuriously negative culture in an early septic joint.
Use a large­bore needle (18 or  gauge) for aspiration of fluid from large joints. Use smaller­bore needles for small joints (no smaller than  gauge). Choose a syringe large enough to accommodate the anticipated volume of fluid within the joint space. Remove as much synovial fluid as possible to obtain a good diagnostic sample and to relieve pain from joint capsule distention. Promptly send aspirated fluid to the laboratory for culture, Gram stain, leukocyte count with differential, and crystal analysis. US should be used in the event of a dry tap to visualize the largest collection of fluid (see Table 284­3).
SHOULDER JOINT ASPIRATION
US can facilitate shoulder aspiration. The anterior or posterior approach can be used.
Anterior Approach
Have the patient sit upright, facing you, and externally rotate the humerus. Insert the needle just lateral to the coracoid process, between the coracoid process and the humeral head (Figure
284­1A). Direct the needle posteriorly. If it is difficult to locate the coracoid process, the posterior approach to the glenohumeral joint may be easier.
FIGURE 284­1. Shoulder arthrocentesis. A. Anterior approach. B. Posterior approach. The skin overlying the lateral margin of the acromion is outlined in green.
Posterior Approach
Sit the patient upright with the back facing you. Palpate the spine of the scapula to its lateral limit: the acromion. Identify the posterolateral corner of the acromion. Use a .5­inch needle. The point for needle insertion is  cm inferior and  cm medial to the posterolateral corner of the acromion (Figures 284­1B and 284­2). Direct the needle anterior and medial toward the presumed position of the coracoid process. The glenohumeral joint is located at a depth of approximately .0 to .5 inches. (See Video: Shoulder Arthrocentesis.)
Video 284­5: Shoulder Arthrocentesis
Used with permission from Lori J. Whelan and Christopher Tainter, University of Oklahoma, School of Community Medicine,Tulsa, OK.
Play Video
FIGURE 284­2. Shoulder arthrocentesis, posterior approach.
ELBOW JOINT ASPIRATION
Use a lateral or posterior approach to the elbow joint. Do not use a medial approach to avoid neurovascular structures. Place the elbow in 90­degree flexion, resting on a table, with the hand prone to widen the joint space. Locate the radial head, lateral epicondyle of the distal humerus, and the lateral aspect of the olecranon tip. These three landmarks form the anconeus triangle.
The center of this triangle is the site for needle entry into the skin. Using the tip of the gloved index finger of the nondominant hand, palpate a sulcus just proximal to the radial head. The sulcus is the needle entry point. Direct the needle medial and perpendicular to the radius toward the distal end of the antecubital fossa (Figure 284­3). (See Video: Elbow Arthrocentesis.)
Video 284­2: Elbow Arthrocentesis
Used with permission from Lori J. Whelan and Christopher Tainter, University of Oklahoma, School of Community Medicine,Tulsa, OK
Play Video
FIGURE 284­3. Arthrocentesis of the elbow.
WRIST JOINT ASPIRATION
Landmarks for wrist arthrocentesis are palpable with the wrist in a neutral position. The landmarks are the radial tubercle of the distal radius, the anatomic snuffbox, the extensor pollicis longus tendon, and the common extensor tendon of the index finger (Figure 284­4). Insert the needle perpendicular to the skin, ulnar to the radial tubercle and the anatomic snuffbox, between the extensor pollicis longus (just ulnar to the extensor pollicis longus) and the common extensor tendons. (See Video: Wrist Arthrocentesis.)
Video 284­6: Wrist Arthrocentesis
Used with permission from Sandra L. Werner, MD, RDMS, Case Western Reserve University, Cleveland, Ohio.
Play Video
FIGURE 284­4. Arthrocentesis of the wrist. [Images used with permission of Sandra Werner.]
HIP JOINT ASPIRATION
Hip arthrocentesis may be performed by an anterior or medial approach. If local practice dictates open surgical assessment and drainage, an orthopedic consultant will often perform this procedure. US­guided arthrocentesis by an emergency physician or radiologist is also acceptable if local practices and training are in place to support this approach (Figure 284­5).
Controversy exists regarding the utility of US or MRI as a screening test before open surgical evaluation.18,22 Immediate consultation with an orthopedic surgeon is therefore desirable when a diagnosis of septic hip arthritis is considered.
FIGURE 284­5. US image of a hip effusion. The hypoechoic effusion (asterisk) is located in the anterior synovial recess between the echogenic cortices of the femoral neck (arrowhead) and the femoral head
(arrow). [Reproduced with permission from Reichman EF (ed): Emergency Medicine Procedures, 3rd ed. Figure 97­18. Copyright .]
KNEE JOINT ASPIRATION
The knee joint can be entered either medial or lateral to the patella. With the patient supine, fully extend the knee and make sure the quadriceps muscle is relaxed. Identify the midpoint of the patella. The insertion point of the needle is located approximately  cm inferior to the patellar edge, either lateral (Figure 284­6) or medial (Figure 284­7) to the middle of the patella. Direct the needle posterior to the patella and horizontally toward the joint space. Compression or “milking” applied to both sides (proximal and distal) of the joint space by an assistant who is using sterile technique may facilitate aspiration of small amounts of fluid. In patients with obese or large knees, it may be necessary to use a needle longer than .5 inches to enter the joint space.
Figure 284­8 demonstrates the use of US to visualize a knee joint effusion. (See Video: Knee Arthrocentesis.)
Video 284­4: Knee Arthrocentesis
Used with permission from Lori J. Whelan and Christopher Tainter, University of Oklahoma, School of Community Medicine,Tulsa, OK.
Play Video
FIGURE 284­6. A. Landmarks for knee arthrocentesis. D = distal femur; P = patella; T = tibia. B. Arthrocentesis of the knee, lateral approach.
FIGURE 284­7. Arthrocentesis of the knee, medial approach.
FIGURE 284­8. Bedside US of the knee in long axis (A) and short axis (B) demonstrating joint effusion.
ANKLE JOINT ASPIRATION
Ankle arthrocentesis may be performed at either the tibiotalar joint (medial approach) (Figure 284­9) or the subtalar joint (lateral approach) (Figure 284­10). The medial approach is generally preferred. (See Video: Ankle Arthrocentesis.)
Video 284­1: Ankle Arthrocentesis
Used with permission from Sandra L. Werner, MD, RDMS, Case Western Reserve University, Cleveland, Ohio.
Play Video
FIGURE 284­9. Arthrocentesis of the ankle, medial approach.
FIGURE 284­10. Arthrocentesis of the ankle, lateral approach.
Medial (Tibiotalar) Approach
Have the patient supine with the foot initially perpendicular to the leg. This position facilitates the location of a sulcus lateral to the medial malleolus and medial to the tibialis anterior and extensor hallucis longus tendons (Figure 284­9 and Figure 284­11A and B). Then plantar flex the foot with the needle entering the skin overlying the sulcus. Angle the needle slightly cephalad as it passes between the medial malleolus and the tibialis anterior tendon.
FIGURE 284­11. A. US­guided approach to medial ankle arthrocentesis. Arrow points to the ankle effusion. B.Arrow points to needle in the tibiotalar joint, medial approach with transducer in the sagittal plane. [Images used with permission of Sandra Werner.]
Lateral (Subtalar) Approach
Keep the patient’s foot perpendicular to the leg. Enter the subtalar joint just below the tip of the lateral malleolus (Figure 284­10). Direct the needle medially toward the joint space.
SEPTIC ARTHRITIS
An acutely hot, swollen, and tender joint (or joints) with restriction of movement is bacterial nongonococcal septic arthritis until proven otherwise.1 Clinical features, risk factors, and treatment differ for bacterial, nongonococcal septic arthritis, and gonococcal arthritis (Tables 284­1 through 284­3). For management of septic arthritis in infants and children, see Chapter 141, “Pediatric Orthopedic Emergencies.” In young adults, sexual activity increases the prevalence of gonococcal arthritis and reactive arthritis (formerly known as
Reiter’s syndrome) associated with chlamydial urethritis.
BACTERIAL NONGONOCOCCAL SEPTIC ARTHRITIS
Clinical Features and Diagnosis
Although no clinical pattern is diagnostic of bacterial nongonococcal septic arthritis, certain general observations are helpful. Joint pain (85%), a history of joint swelling (78%), and fever
(57%) are the only findings that occur in >50% of patients with bacterial nongonococcal septic arthritis.6
The involved joint can become exquisitely painful over a few hours. The patient may splint the affected joint to relieve pain with movement. Joint effusion may be small or large. Resistance to passive and active movement and limitation of full joint movement are notable findings but are common with gout without infection and may be absent in immunosuppressed patients.
Although joint aspiration and analysis are essential to the diagnosis, the sensitivity of any one finding for the diagnosis of nongonococcal septic arthritis is only moderate. For example, the sensitivity of joint fluid WBC to make the diagnosis of nongonococcal septic arthritis using the commonly quoted cutoff of ,000 cells/mm3 is only 56%.5 The sensitivity of erythrocyte sedimentation rate for nongonococcal septic arthritis using a cutoff of  mm/h ranges between 76% and 96%,5 but this test is nonspecific.
Treatment
If a septic arthritis diagnosis cannot be reliably excluded after clinical evaluation, including arthrocentesis, admit the patient for parenteral antibiotics and pain control until synovial fluid culture results are available. Antibiotic coverage is directed at staphylococcal and streptococcal species including methicillin­resistant S. aureus. Vancomycin plus a broadspectrum cephalosporin or carbapenem is the preferred therapy (Table 284­4).1,23 Patients found to have septic arthritis caused by methicillin­resistant S. aureus are often significantly older; have more comorbidities, including end­stage renal disease; have increased erythrocyte sedimentation rates and C­reactive protein levels; and have nosocomial infections. Methicillinsensitive S. aureus septic arthritis patients are more likely to be IV drug users.24
TABLE 284­4
Commonly Encountered Organisms in Septic Arthritis in Adolescents and Adults
Patient/Condition Expected Organisms Antibiotic Considerations
Young healthy adults, or patients with Staphylococcus, Vancomycin,  milligrams/kg IV load, if Gram stain reveals gram­positive organisms in clusters. Ceftriaxone,  gram IV, or risk factors for Neisseria gonorrhoeae N. gonorrhoeae, imipenem, 500 milligrams IV, should be used/added if either gram­negative organisms are present or no organisms are present
Streptococcus, gram­ on Gram stain and N. gonorrhoeae is suspected (also culture urethra, cervix, or anal canal as indicated).
negative bacteria
Adults with comorbid disease Staphylococcus, gram­ Vancomycin,  milligrams/kg IV load, plus cefepime,  grams IV, or imipenem, 500 milligrams IV. Meropenem,  gram IV, may be
(rheumatoid arthritis, human negative bacilli used as an alternative agent.
immunodeficiency virus, cancer) or injection drug users
Sickle cell patients Salmonella Vancomycin,  milligrams/kg IV load, plus ciprofloxacin, 400 milligrams IV. Imipenem, 500 milligrams IV, may be used as an
(increasingly alternative agent.
Staphylococcus)
Consult orthopedic surgery for possible joint irrigation in the operating room and further management if the joint aspiration is positive for infection. Consultation with infectious disease may be required to determine ideal antibiotic choice in select patients.4
GONOCOCCAL SEPTIC ARTHRITIS
Clinical Features and Diagnosis
Gonococcal arthritis is the most common cause of septic arthritis in young sexually active adults.25,26 Joint infection will typically have a prodromal phase in which migratory arthritis and tenosynovitis predominate before pain and swelling settle on one or more septic joints. Vesiculopustular lesions, especially on the fingers, may be found (see Figure 153­3A in Chapter 153,
“Sexually Transmitted Infections”).
Synovial fluid cultures are often negative in gonococcal arthritis, with only 25% to 50% of cases yielding positive identification of the organism.6 Cultures of the posterior pharynx, urethra, cervix, and rectum (as directed by history of sexual contact) before antibiotic treatment increase the culture yield.25,27 Cases of gonococcal arthritis suspected clinically should be treated despite negative initial results while waiting for all culture results to return.
Treatment
Treatment for gonococcal arthritis follows the same general principles as treatment for nongonococcal septic arthritis (see Table 284­4 for details). However, gonococcal arthritis does not yield joint destruction with the frequency of nongonococcal arthritis, and therefore, surgical intervention is rarely needed.27,28 Daily joint aspiration is routinely done until there is clinical improvement.25,27,28Neisseria gonorrhoeae, in the setting of arthritis, remains sensitive to third­generation cephalosporin ceftriaxone,  gram IV every  hours,25,27,28(see Chapter 153,
“Sexually Transmitted Infections”).
CRYSTAL­INDUCED SYNOVITIS (GOUT AND PSEUDOGOUT)
Crystal­induced synovitis is primarily an illness of middle­aged and elderly adults. Uric acid (monosodium urate monohydrate crystals, gout) and calcium pyrophosphate (calcium pyrophosphate deposition, or pseudogout) are the two most common crystalline agents, with gout representing the most common form of inflammatory joint disease in men >40 years old.29,30 The classic description of gout is monoarthritis involving the great toe or knee joint in a man >40 years old.29,31 Gout is less common in women during their reproductive years, but may occur in association with periods of increased insulin resistance such as gestational diabetes.32
CLINICAL FEATURES
Joint pain develops over hours. Gout results from precipitation of uric acid crystals in the joint, and pseudogout results from calcium pyrophosphate crystals. Crystalline involvement of joints has a predilection for the foot and knee. Although the first metatarsophalangeal joint is a classic focus for acute gout, no joint is the exclusive site of involvement for either gout or pseudogout. (See Video: Joint Arthrocentesis.)
Video 284­3: MTP Joint Arthrocentesis
Used with permission from Sandra L. Werner, MD, RDMS, Case Western Reserve University, Cleveland, Ohio.
Play Video
DIAGNOSIS
The diagnosis of a crystal­induced synovitis is by joint aspiration and identification of crystals through a polarizing microscope. Uric acid crystals (gout) appear needle shaped and blue when the source of light is perpendicular to the crystal (negative birefringence). Calcium pyrophosphate (pseudogout) is yellow in this alignment (positive birefringence), with a rhomboid shape.
Crystals are located within phagocytes from aspirates of synovial fluid, or within inflamed tissues adjacent to the affected joint.
Radiography and CT are not useful in the routine diagnosis of gout but can be used to rule out other reasons for an erythematous, painful, swollen, and tender joint. Imaging can be useful to identify fractures, osteomyelitis, gaseous gangrene, or retained foreign bodies. Typical US findings in gout are the double­contour sign, tophi, and the snowstorm sign.33 US in the hands of an experienced user can be more sensitive than radiography in identifying bony erosions.34
Serum uric acid levels are not generally useful for diagnosis, as up to 30% of patients will have normal uric acid levels during an acute gout attack.29,31 There is no elevation of serum uric acid, calcium, or phosphate in pseudogout. The joint aspirate WBC count can be elevated with gout and pseudogout.29­31,35 However, the presence of crystals, the absence of bacteria on Gram stain or culture, and frequently, the dramatic response to NSAIDs clarify the diagnosis. When the diagnosis of a septic joint cannot be excluded, hospital admission until cultures and/or clinical response clarify the diagnosis is the safest course of action.1,4,31,35
TREATMENT
When the diagnosis of gout or pseudogout is established, treatment is an NSAID for  to  days. First­line treatment is indomethacin (or naproxen).29,30Do not give NSAIDs to patients with renal insufficiency. For patients with normal renal function, the initial dose of indomethacin is  milligrams up to three times a day or naproxen 250 to 500 milligram twice daily.
Therapy is continued for  to  days as needed. Substantial pain relief typically occurs within  hours of NSAID administration.29,30Colchicine is an alternative agent to treat acute gout and pseudogout in patients with normal renal and hepatic function.31,35 Oral colchicine for an acute gout attack is typically administered at a dose of .2 milligrams, followed by another dose of
### .6 milligram in  hour. After  hours, .6 milligram can be given once or twice daily until symptoms resolve.33 IV administration of colchicine can be associated with serious side effects, such as bone marrow suppression, neuropathy, myopathy, and death.29 For patients with renal insufficiency, narcotic analgesics may be needed for pain relief because NSAIDs and colchicine are generally avoided. Prednisone is a first­line treatment option but must be used with caution in patients with diabetes, congestive heart failure, or hypertension.33 The use of prednisone compared to indomethacin has similar clinical effectiveness.36 A proton pump inhibitor may be added to NSAID therapy if there is concern for gastritis.35
Discharge is typical unless pain is not controlled or if septic arthritis is a consideration. Once acute symptoms have resolved, long­term control may be achieved with reduction or elimination of gout­inducing agents (diuretics, aspirin, or cyclosporine) and treatment with urate­lowering therapy, such as allopurinol or probenecid. There is no effective prophylaxis for pseudogout.
VIRAL ARTHRITIS
The most common causes of viral arthritis in the United States are parvovirus B19, rubella, and hepatitis B. Table 284­5 lists these viruses along with incidence, clinical findings, typical duration, and other significant features.
TABLE 284­5
Common Causes of Viral Arthritis
Virus Prevalence of Arthritis Findings Duration Additional Features
Parvovirus B19 Children 10% Polyarticular 2–8 wk or chronic Causes erythema infectiosum in children, rarely causes aplastic crisis
Adults 50%–70% Symmetric
Rubella Adults 50% Polyarticular 5–7 d Relapse
Epstein­Barr virus 1%–5% Poly­ or monoarticular 1–12 wk Autoantibodies
Hepatitis B 10%–25% Migratory 1–3 wk Vasculitis
Hepatitis C 10% Polyarticular Chronic Vasculitis
HIV 10%–50% Mono­ or oligoarticular Chronic Viral load >10,000 copies of HIV RNA, CD4 count <350 cells
Alphaviruses* >50% Oligoarticular 1–4 wk More common in Asia, Africa; fever, myalgias
Abbreviation: HIV = human immunodeficiency virus.
*Alphaviruses include Sindbis virus, Mayaro virus, Ross River virus, Semliki Forest virus, O’nyong­nyong virus, chikungunya virus, and Barmah Forest virus.
LYME DISEASE
The arthritic manifestations of Lyme disease occur weeks, months, or years after primary, stage I infection. Symptoms include monoarticular or oligoarticular asymmetric joint involvement.
Large joints are most often affected, particularly the knee.37 A migratory pattern of oligoarthritis may be noted in addition to brief attacks of bursitis and tendonitis.
The diagnosis of Lyme arthritis is initially suspected in patients residing in, or with a recent visit to, an endemic area. A history of tick bite or erythema chronicum migrans rash (see Figure 251­
, erythema migrans, in Chapter 251, “Skin Disorders: Trunk”) is helpful but often absent. Arthrocentesis yields an inflammatory synovial fluid, usually with negative cultures. Given the difficulty of making a definitive diagnosis in many patients, treatment of suspected Lyme arthritis is often initiated on the grounds of high clinical suspicion. Treatment is administered for  weeks, with a number of antibiotics recognized as effective, including doxycycline, 100 milligrams PO twice daily; amoxicillin, 500 milligrams three times daily; or cefuroxime, 500 milligrams twice daily.23,37 For detailed discussion of the diagnosis and treatment of Lyme disease, including the involvement of other body sites, see Chapter 161, “Zoonotic Infections.”
HEMARTHROSIS
TRAUMATIC HEMARTHROSIS
Traumatic hemarthrosis has a high association with ligamentous injury or an intra­articular fracture. Effusions following trauma may range from small minor effusions to large painful fluid collections that impede range of motion. Aspiration of very large traumatic effusions will provide temporary pain relief and increase range of motion, but has no effect on long­term outcome.14 Treatment of traumatic hemarthrosis consists of immobilization, ice, and elevation of the affected joint. In the absence of a fracture or significantly unstable joint requiring immediate orthopedic evaluation, follow­up is needed for possible ligamentous and articular injuries.
SPONTANEOUS HEMARTHROSIS
Spontaneous hemarthrosis usually indicates underlying systemic illness and should prompt consideration for primary or secondary coagulopathies. Hemophiliacs should receive specific clotting factor replacement for hemarthrosis (see Chapter 235, “Hemophilias and von Willebrand’s Disease”). Joint aspiration for acute hemarthrosis in hemophilia is controversial but recommended by some for a large hemarthrosis that can be aspirated during the first  hours of symptoms. Joint aspiration should only be performed after factor replacement.20
Follow­up and/or consultation should be provided with hematology and orthopedics.
RHEUMATOID ARTHRITIS
Rheumatoid arthritis is typically a progressive disease, with polyarticular involvement of symmetric joints and sparing of the distal interphalangeal joints. Women are affected more commonly than men. Patients describe stiffness of the joints occurring after prolonged periods of inactivity (morning stiffness). A “boggy,” slightly edematous synovium may be palpated. Arthrocentesis of synovial fluid is typically noted for an inflammatory profile. For further discussion of systemic clinical features of rheumatoid arthritis, see Chapter 282, “Systemic Rheumatic Diseases.”
Salicylates or other NSAIDs are the cornerstone of treatment for an acute exacerbation. Corticosteroids may be used for brief periods, with long­term therapy using agents such as methotrexate, leflunomide, sulfasalazine, and other nonbiologic and biologic disease­modifying antirheumatic drugs.38 Consider septic arthritis in patients with an acute episode of arthritis who are also receiving immunosuppressive agents.
OSTEOARTHRITIS
Osteoarthritis is distinguished from rheumatoid arthritis by a lack of constitutional symptoms and/or multisystem involvement. Destruction of joints in osteoarthritis may involve the distal interphalangeal joints, with less dramatic symmetric, polyarticular exacerbations. Although osteoarthritis is a chronic, polyarticular disease, patients may present with an acute monoarthritis exacerbation, typically of the knee. Effusions are small and difficult to aspirate. If fluid is aspirated, it is noninflammatory.
Radiographs demonstrate characteristic joint space narrowing due to destruction of articular cartilage. Treatment is joint rest and NSAIDs or acetaminophen in the setting of GI complications.39 Systemic corticosteroids are not indicated. Ongoing long­term management may include intra­articular corticosteroid injections by a primary care physician or orthopedist.
REACTIVE ARTHRITIS
Reactive arthritis (formerly known as Reiter’s syndrome) is a seronegative spondyloarthropathy characterized by an acute, asymmetric oligoarthritis occurring  to  weeks after an infectious illness.40­42The classic triad of Reiter’s syndrome is arthritis, urethritis, and conjunctivitis. A history of all three components is not necessary for diagnosis.Chlamydia or
Ureaplasma are common inciting infectious agents (postvenereal reactive arthritis). Enteric infections may precipitate a reactive arthritis (postdysentery reactive arthritis). Implicated agents of postdysentery reactive arthritis are Salmonella, Shigella, Yersinia, and Campylobacter, and possible agents include Escherichia coli and Clostridium difficile.40,41 Conjunctivitis occurs in one third of postvenereal and >50% of postdysentery forms of reactive arthritis.41
Joint involvement in reactive arthritis typically involves the lower extremities, including the feet. Back and buttock pain may occur. A diffuse swelling of an entire digit (sausage digit) may be found as well but is not specific to reactive arthritis.41,42 Synovial fluid aspirates demonstrate an inflammatory profile. Treatment has traditionally been supportive, with emphasis on pain control with NSAID therapy.40,41 Antibiotics were previously thought to be of no benefit, but now long­term combination antibiotic therapy is being used for Chlamydia­induced reactive arthritis, using rifampin 300 milligrams daily combined with either doxycycline 100 milligrams twice daily or azithromycin 500 milligrams daily.40,42 Arthroscopic synovectomy may also provide benefit.43 Suspected cases should be referred to rheumatology for confirmation of diagnosis and management.
BURSITIS
NONSEPTIC BURSITIS
Bursitis is an inflammatory process involving one of the >150 bursae in the body, but most commonly the bursa overlying the elbow or the knee (see also Chapter 281, “Hip and Knee Pain”).44
Bursitis can be caused by repetitive trauma or can be associated with gout, pseudogout, or rheumatoid arthritis. Repetitive activities that can precipitate bursitis are identified by the typical names given: “carpet layer’s or housemaid’s knee” (prepatellar bursitis) or “student’s elbow” (olecranon bursitis). The affected bursa is easily palpated but is not tender and not erythematous. Bursal enlargement is usually chronic or progressive but not acute. If bursitis is acute, consider septic bursitis (see following section, “Septic Bursitis”). In nonseptic bursitis, there is no limitation of, or pain upon, joint movement. The skin over the bursa may be thickened and calloused, indicating chronic repetitive trauma or pressure. Treatment is NSAIDs and elimination of activities that produce symptoms. Aspiration and drainage of bursal fluid are controversial (if infection is not suspected), because bursal fluid often reaccumulates after aspiration.
SEPTIC BURSITIS
Unlike septic arthritis, septic bursitis is more likely secondary to bacterial spread from a skin lesion or local cellulitis to an injured or inflamed bursa. Therefore, cultures more closely reflect skin flora.44 Septic bursitis is characterized by acute pain, tenderness, erythema of the affected bursa, and overlying warmth when compared with the unaffected side.44,45 The most common sites for septic bursitis are the prepatellar bursa (50% to 53%) and the olecranon bursa (40% to 45%).45­47
Fever occurs in <50% of patients with septic bursitis.45 Pain can occasionally be mild (10%) but is usually moderate or severe.46 Associated cellulitis of the surrounding skin may be evident.
Most authors recommend the aspiration of bursal fluid if septic bursitis is considered.44,46 Bursal aspiration can be diagnostic and therapeutic. Bursal fluid demonstrates characteristic findings in infection (Table 284­6).44 Culture is the definitive test for presence or absence of infection. Diagnosis is presumed by one of the following criteria based on bursal fluid results: positive Gram stain, >3000 WBC/mm3, >50% polymorphonuclear cells, glucose <31 milligrams/dL, or bursal to serum glucose ratio of <50%.44
TABLE 284­6
Characteristics of Bursal Fluid in Patients With Septic and Nonseptic Olecranon and Prepatellar Bursitis
Septic Traumatic and Idiopathic Crystal Induced
Appearance Purulent or serosanguineous Straw colored, serosanguineous, or bloody Straw colored to bloody
Leukocytes/mm3 Range, 350–392,000; mean, ,3300 ± ,197; >3000 is considered diagnostic Range, 0–11,700; mean, 2475 ± 1988 Range, 1000–6000; mean, 2900
Differential count >50% polymorphonuclear cells is considered diagnostic Predominantly mononuclear Highly variable
Ratio of bursal fluid to serum glucose <50% in 90% of cases (diagnostic) >50%, 70%–80% in 98% of cases Unknown
Gram stain Positive in 70% (diagnostic) Negative Negative
Crystals present No* No Yes
Culture results Positive (diagnostic) Negative Negative
*The presence of crystals does not rule out infection.
S. aureus accounts for the majority of infections, but Staphylococcus epidermidis and Streptococcus species are also encountered.44­46 Septic bursitis generally responds well to oral antibiotics, with emphasis on coverage of Staphylococcus and Streptococcus species. With the increasing prevalence of methicillin­resistant S. aureus, adjust antibiotic choice according to local sensitivities. Conditions that require hospital admission for incision and debridement and IV antibiotics include sepsis, extensive purulent bursitis, extensive surrounding cellulitis, suspected joint involvement, immunocompromise, or failure to respond to a course of oral antibiotics.44 See specific treatment recommendations later in this chapter.
OLECRANON BURSITIS
The olecranon bursa overlies the olecranon process on the extensor surface of the elbow. The bursa is tense and edematous. Pain elicited with range of motion at the elbow is minor until the motion tightens and compresses the distended overlying bursa. Gouty tophi on the extensor surface of the elbow may be palpable or visible if the cause of bursitis is crystal­induced bursitis.
If bursal fluid is aspirated, uric acid crystals are evident on microscopy.
To aspirate the olecranon bursa, prepare the bursal skin and use antiseptic technique. The patient’s arm can be extended to allow for maximal bursal distention. Use a lateral approach to the affected bursa. Remove as much fluid as possible, and send the aspirate to the laboratory for analysis for WBC, Gram stain, crystals, glucose, and culture.
Treatment depends on patient condition; if sepsis is generalized, the patient should be treated with vancomycin,  milligrams/kg, plus piperacillin/tazobactam, .5 grams IV, or meropenem,
500 to 1000 milligrams IV. Most patients have localized infection only and can be treated as outpatients with a 14­day course of oral antibiotics.44­46 Common antibiotics chosen include clindamycin, 300 milligrams three times per day for  days, or dicloxacillin, 500 milligrams four times per day.46 Trimethoprim­sulfamethoxazole is an alternative.45 Steroids are not indicated in the ED because infection cannot be definitively excluded by negative culture results. Admission is indicated for clinical toxicity, extensive surrounding cellulitis, failure of outpatient treatment, or immunocompromise.46 Some patients benefit from surgical excision of the bursa sac.47,48
PREPATELLAR BURSITIS
Bursitis may affect any of the four bursae surrounding the extensor aspect of the knee (see Figure 281­8). A history of overuse or repetitive trauma to the prepatellar area is typical.44 The noninfected or aseptic bursa is enlarged and taut but nontender and not warm. There is full range of motion of the knee. If septic patellar bursitis is a consideration (Figure 284­12), aspirate the prepatellar bursa to obtain fluid for analysis. Prepare the skin overlying the bursa and use aseptic technique. Use either a lateral or medial approach. Fluid analysis and treatment are the same as for septic olecranon bursitis (see earlier section, “Olecranon Bursitis”).
FIGURE 284­12. Septic prepatellar bursitis. This patient presented with obvious purulence of his right prepatellar bursal sac. Aspiration confirmed septic bursitis. [Courtesy of Alan B. Storrow, MD.
Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, Inc., New York.]


