## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 301: Death Notification and Advance Directives
Lindsay M. Weaver; Cherri D. Hobgood
DEATH NOTIFICATION
Death notification is perhaps the most difficult, emotionally laden physician communication. In most situations, the notification of death occurs during the first meeting of the emergency physician with the deceased patient’s family. The notification often comes after extensive resuscitation efforts,
,2 creating an upheaval of emotion for the physician and ED staff and leaving the team emotionally and physically exhausted.
For survivors, death notification is a life­altering event. The language used during the communication, the venue, and the characteristics of the
 individual delivering the news create indelible memories for the family.
EFFECTS ON SURVIVORS
Because death that occurs in the ED is frequently sudden, unexpected, and often violent, survivors can develop complicated bereavement and/or
4­7 posttraumatic stress disorder. Death notifications that provide limited or incorrect information about the death or occur in chaotic settings with
 limited support may exacerbate the grief reaction. When properly performed, death notifications may mitigate substantial negative effects on
 surviving family members. A well­delivered death notification can reduce the incidence of posttraumatic stress disorder in the families of patients who
 died suddenly, particularly notifications involving the loss of a spouse or the death of a child.
WHAT REACTIONS TO EXPECT
Responses to loss vary greatly. Families often describe themselves as numb immediately after learning of the loss. They have difficulty processing
 information and making decisions. Following the initial shock, the family may experience denial, anger, and/or guilt. Denial is most typically expressed as incredulity and is thought to be a defensive mechanism. Your role is to understand this condition and allow time and, if needed, to provide additional information to confirm death. Seeing the body of the deceased may help the family to accept the truth. Anger is not unusual. Be prepared to react in a supportive manner rather than responding with anger or becoming defensive. These are typically expressions of grief and misplaced guilt.
The survivors’ culture is an important predictor of the types of emotional responses that may be exhibited. These may range from no expression of emotion to wailing and hysterical collapse. Allow these expressions and remain calm and respectful. If you want to touch the grieving individual, the shoulder is the most suitable location.
EFFECTS ON PHYSICIANS
Physicians find death notification physically and emotionally difficult, with evidence of increased heart rate, heart rate variability, and cortisol levels
11­14 immediately after the event. Common emotional reactions in emergency physicians faced with the task of death notification are sadness (60%) and
 disappointment (38%), resulting in insomnia in 37%. The cause of death, the patient’s age, the presence of family, and the similarity to self are the
,15 most common reasons cited by emergency physicians for powerful impact of a recent death notification experience. Other factors that may also increase the stress level for the physician include racial and ethnic differences between the physician and the family, lack of a clear family leader, a nontraditional family (e.g., broken or blended), and situations in which the physician is personally emotional or cannot control his or her own
 reaction.
,3
Skillful death notification is a priority in emergency medicine practice. Protocols to enhance communication skills for delivering bad news in the ED
Downloaded 2025­7­1 9:6 P You17r IP is 136.142.159.127 improve satisfaction of survivors. The use of successful methods to communicate effectively with families may also mitigate physician burnout and
Chapter 301: Death Notification and Advance Directives, Lindsay M. Weaver; Cherri D. Hobgood 
 reduce stress on ED staff. Understanding and using compassionate methods of information exchange are critical to success. Providers must learn to
. Terms of Use * Privacy Policy * Notice * Accessibility
 recognize emotions, even when they are indirectly expressed, and allow these to be aired and displayed without judgment.
©
GRIEV_ING : A METHOD FOR DELIVERY OF DEATH NOTIFICATION
©
The GRIEV_ING mnemonic is a method for delivering concise and accurate death notification. This mnemonic provides physicians with an
 organized, sequenced approach to deliver the news of death (Table 301­1). The structured organization of communication elements provides a coherent sequence of information to the family that is easy for providers to remember and ensures complete information transfer to the family. (See
Video: Grieving: Announcing a Death in the Emergency Department.)
Video 301­1: Grieving: Announcing a Death in the Emergency Department
Used with permission from Cherri Hobgood and Brendan Anzalone, Department of Emergency Medicine, University of North Carolina; Judith E. Tintinalli, Medical
Editor
Play Video
TABLE 301­1
The GRIEV_ING Mnemonic
G Gather Assemble the family in a calm, considerate place for the discussion. Gather as many family members as time allows. This mitigates the need for multiple episodes of information delivery. This step may be done by ED support staff.
R Resources Ask for any additional support available to aid the family (e.g., hospital chaplain services, family ministers, additional family and friends [especially if the survivor is alone], and, if needed, an interpreter).
I Identify Upon entering the room with the family:
Identify yourself.
Identify the deceased patient by name.
Identify the family’s state of knowledge. Are they aware of the situation, or will news of the death be unexpected?
E Educate In a concise manner, educate the family about the events that have transpired since the patient entered care. EMS should be included in this description.
Fire a “warning shot” by stating that you bring “very bad news.”
Tell them the current state of their loved one.
V Verify Confirm the news of death. State emphatically that their family member is dead. Be clear! Use the words dead or died. Express your sincere condolences.
_ Space Stop talking. Allow the news to settle and give them time to process the information.
I Inquire After a brief interval, ask if they have any questions. Then take the time to answer all of them.
N Nuts and Provide additional information on: bolts Organ donation
Funeral service that will collect the body
The deceased’s personal belongings
Be sure to offer the family the opportunity to view the body.
G Give Give the family your card and contact information.
Offer to answer any questions that they may have later. Return their call if contacted.
Express condolences.
Modified with permission from Hobgood C, Harward D, Newton K, Davis W: The educational intervention “GRIEV_ING” improves the death notification skills of residents. Acad Emerg Med 12: 296, 2005. Copyright John Wiley & Sons.
G (GATHER)
As early as possible during the resuscitation, instruct ED staff, nursing, social work, or chaplain services to “gather” the family. Place the group in a quiet, private environment with few distractions. Assist the family with outreach to other family members or friends. Gathering allows the physician to deliver the information a single time, ensuring that everyone hears the same information. This also allows the family to support each other during this most difficult time.
R (RESOURCES)
Ask if there are any needs, and work to collect any needed items. Ask about desires for a chaplain, minister, or priest who may provide support for the family. Obtain interpreter services if needed.
I (IDENTIFY)
Confirm that the deceased individual is properly identified. As the physician and staff join the family, they must clearly identify themselves and their role in the resuscitation. Clarify and confirm that the family is associated with the deceased individual by saying the patient’s full name, for example, “Are you the family of Ellen Smith?” Ask the family members to state their relation to the patient. Identify the next of kin. All discussion moving forward is between you and the next of kin. Face that person directly and ask permission to discuss the events of the day in the presence of the extended family and those gathered in the room.
Ask for a brief statement of the state of knowledge of the family regarding the patient’s status. This final step is important because it allows you to begin your story at the point their knowledge ends. Depending on the prior state of knowledge, the family will process information differently and at different rates.
If possible, before you begin your discussion, ask the family to take a seat. You and your team should sit as well. Having the family sit reduces the risk of falling and sustaining injury during the notification. Position yourself across from the next of kin, preferably at eye level, and address the majority of the dialogue to that person. This posture creates open communication and allows you to assess understanding as you deliver the information.
E (EDUCATE)
From this point forward, your role is to educate. Your description of the event should begin at the conclusion of the family’s knowledge of events. The narrative should be a focused summary of the scene, including any EMS response and the events in the ED. Communicate with nontechnical, nonmedical words; be thoughtful with your language and listen and watch for incomprehension. Throughout your summary, on multiple occasions, provide the family with “warning shots,” such as “this is difficult news” or “the information that I am relating is bad news.” These “warning shots” are a communication strategy intended to adjust the family toward the idea that they are about to learn something difficult and portend the disclosure of death. Carefully observe the family’s reactions and those of the next of kin. If it appears that they do not understand the severity of events, reemphasize the finality of the news. Once the family appears to be following your story with clarity, then you must disclose the death.
V (VERIFY)
Continuing your dialogue seamlessly, you will “verify” the death. You should unequivocally state that their family member has died. You must decisively affirm this fact clearly and say the words death, died, or dead. Provide your condolences on their loss. This may include language such as, “I am sorry for your loss” or “I can see how difficult it is for you to learn of the death of your [mother, brother, sister, friend, etc.].” Without knowing the religious convictions of the patient and everyone present, it is inappropriate to say “they are in a better place” or that the events “were God’s will.”
_(SPACE)
Now stop talking. Give the family some room to comprehend what you have just said. Even families who were anticipating the death will need a moment to register the information and compose themselves. Once you have allowed an adequate period of time to pass, you may move into the last three steps of notification.
I (INQUIRE)
The next phase, “inquire,” is a very natural progression of the dialogue. Ask the family, “Are there any questions for me?” or “How can I help you?” In most cases, if the preceding steps have gone well and there has been complete information transfer, then there will be no major questions. The family may ask if there was pain or suffering. This is a difficult question to answer. Maintaining your credibility is important, and you can never state with full certainty that the patient did not suffer. If you did everything possible to mitigate pain and suffering while the patient was in the ED, you can reassure the family with this fact.
N (NUTS AND BOLTS)
The “nuts and bolts” are the necessary practical things that require attention. The physician has several key tasks at this stage. Inform the family that they will need to complete documents before they leave the hospital. You should also ask the family’s wishes regarding autopsy. You should also offer the family the chance to view the body after it is appropriately prepped. This preparation includes removal of blood and secretions, closing the eyes, and covering the body except for the hands and face. It is fine to remove tubes and catheters as long as it is not a medical examiner’s case. If the patient is disfigured, cover the wound as best as possible with towels or bandages. You should warn the family that there is trauma or if tubes must be left in place and that these sights may result in a lasting memory of their loved one. In all situations, it is best to have the family members seated.
G (GIVE)
The concluding step in the notification process is “give.” During this period, you give the family your name and, if possible, your business card. Inform them that, if they call, you may not be immediately available but that you will contact them after you receive the message. If they reach out to you, be sure to return the call. Typically, calls are made to provide additional clarity or to express thanks. Express your condolences and then close the encounter.
SPECIAL SITUATIONS
LONG­DISTANCE NOTIFICATION
Occasionally, death notification must be made to survivors over the telephone. The GRIEV_ING protocol steps are still appropriate. Ask the survivor to
“gather” other family members to join on the phone. If the survivor is alone, ask the survivor to get “resources,” such as friends, relatives, or personal clergy, and call you back. At that time, proceed with the rest of the steps of in­person notification. After notification, the survivors may wish to come to the hospital to attend to the “nuts and bolts.” Recommend that they do not drive alone and assure them someone will be available to answer all of their questions.
AUTOPSY AND MEDICAL EXAMINER CASES
The Joint Commission requires that physicians ask families if an autopsy is desired. Autopsies are voluntary and serve to clarify premortem diagnoses or aid in the diagnosis of new diseases. Autopsies do not prevent an open­casket funeral. If there are religious concerns, a chaplain can help. Local and institutional policies regarding autopsy billing and payment vary; however, if the family will be charged for the autopsy, they should be informed.
Depending on state laws, certain deaths must be referred to the medical examiner or coroner for investigation and/or autopsy. Medical examiners may choose to investigate deaths due to trauma, homicide, suicide, or medical procedures; death from a disease that is a public threat; death of a person in custody or incarcerated; pediatric and sudden infant death syndrome deaths; and deaths that are unexpected and unexplained. An autopsy may or may not be performed in these cases, but the family is not allowed to refuse investigation or autopsy by the medical examiner if that is necessary.
Families are still permitted to view the body, but they are discouraged from removing mementos or disturbing the body until after the medical examiner investigation. Do not remove resuscitative lines and tubes in a medical examiner case. Designation of the death as a medical examiner case does not prevent organ donation, but the consent of the medical examiner is required before organ procurement.
ORGAN DONATION

Currently >110,000 patients are on the national transplant list. The Joint Commission requires physicians to contact an organ­procuring agency for all deaths in the ED. The role of the ED physician is to notify the family of the grave prognosis or death of the patient and remain supportive and available to the family.
Traditionally, the family consent process has been the largest single obstacle to obtaining organ donation. The best predictor of consent is the family’s initial reaction to the request for donation. Currently, all  U.S. states have first­person consent and registry laws associated with the Department of

Motor Vehicles. These laws increase families’ satisfaction and likelihood of consent for organ donation. Trained organ procurement specialists should manage conflicts with the family disagreeing with the deceased’s stated wishes. They are trained in this type of conflict resolution and are aware of each state’s laws. Physicians can provide information while allowing the coordinator to initiate and lead the conversation about organ donation.
WITNESSED RESUSCITATION
Emergency physicians should consider developing programs to educate staff and develop procedures to routinely invite family members to observe
24­26 resuscitation in the ED. Family­witnessed resuscitation gives family members closure and comprehension of the patient’s situation and grave
 condition. Emergency medicine providers may be concerned about the family interfering with resuscitation efforts, patient ity, increased
 litigation, distraction from resuscitation efforts, wrongly prolonging the code, and increased stress for the family and staff members. However, many of these concerns have been found to be unwarranted. In one study, family members who witnessed CPR had fewer symptoms of posttraumatic stress
 disorder and less complicated grief  year after the death. However, family members should be screened for appropriateness to attend the
 resuscitation and escorted out if safety becomes a concern. A staff member should prepare the family members for what they may see during the
 resuscitation and then remain with them to offer support, answer questions, and explain procedures.
PEDIATRIC DEATH
Recognizing that the death of a child in the ED is uniquely different from other ED deaths, the American College of Emergency Physicians and the

American Academy of Pediatrics addressed challenges by developing a set of principles. They recommend ED physicians provide “personal,
 compassionate, and individualized” support through a “family­centered and team­oriented approach.” The family­centered approach begins with allowing the family to be with the child during the resuscitation. After the child’s death, the family should be encouraged to stay with the child. The
 healthcare team should respect families’ “social, religious, and cultural diversity.” Many pediatric deaths are medical examiner cases. Therefore, tubes and lines may need to be kept in place, which may affect what the family can do. The team­oriented approach provides appropriate resources,
 including organizations and individuals that may assist families, and a coordinated response to the child’s death. In more than one third of pediatric
 deaths, an autopsy provides information of undiagnosed findings and complications. The ED physician should notify the child’s pediatrician
 concerning the circumstances of the child’s death so that the pediatrician can follow up with the child’s family and siblings.
ADVANCE HEALTHCARE DIRECTIVES, PHYSICIAN ORDERS FOR LIFE­SUSTAINING
TREATMENT, AND WITHDRAWAL OF LIFE­SUSTAINING TREATMENT
Advance healthcare directives (AHD) are legal documents that assist in communicating to healthcare providers a patient’s healthcare preferences when
 a patient is incapacitated and cannot speak for him­ or herself. There are many forms of AHDs, including, but not limited to, out­of­hospital do not resuscitate (DNR) orders, living wills, designation of a healthcare durable power of attorney or healthcare representative, and the Physician Order for
,32
Life­Sustaining Treatment (POLST) form. Unfortunately, only 29% to 33% of American adults have an AHD. The traditional DNR form facilitates the patient’s or healthcare proxy’s refusal of CPR should the patient sustain a cardiac or respiratory arrest. However, DNR forms generally do not outline
 the patient’s treatment wishes for a life­threatening condition. The inadequacy of DNR forms led to the development of POLST forms, including other states’ iterations (e.g., Medical Orders for Life­Sustaining Treatment, Physician Orders for Scope of Treatment). The POLST form is meant to translate a patient’s end­of­life wishes into actionable physician orders. Forms may include directives concerning the patient’s code status; desire for further medical interventions including hospital transport, intubation, IV fluids, and comfort measures; desire for antibiotics; and desire for artificial nutrition.
Forms are transportable (authority transferred from the patient’s living situation to the ED) and may be brought into the ED from extended­care
 facilities, from patients’ homes, and with EMS. These directives should be honored in the ED. It is important to become aware of what form of the
POLST is available in the state in which you work as well as the rules and regulations regarding who may complete the form and how it may be used.
AHDs can assist emergency medicine providers with facilitating discussion about goals of care. However, physicians may wonder when it is appropriate to begin these discussions in the acute setting of the ED. Clinical prediction tools, such as PREDICT, can assist providers in recognizing patients who
 would benefit from advance care planning and or a palliative care consult. PREDICT assesses a patient’s risk of mortality at  year with a reported

.3% specificity for a cutoff score >13 (Table 301­2). Recognizing the likelihood of someone having <1 year to live can assist providers in knowing when it may be appropriate to discuss AHDs such as the POLST form, initiate goals of care discussion, and consult palliative medicine.
TABLE 301­2
PREDICT Score
PREDICT Feature Points* Referral to palliative care team for a noncancer diagnosis 
Current residence in nursing home 
Department of intensive care unit admission with multiorgan failure 
Current diagnosis of cancer 
Two or more medical admissions in the past year 
Age at ED visit 55–65 y 
Age at ED visit 66–75 y 
Age at ED visit ≥76 y 
*Score of >13 predicts mortality at  year with 95% specificity.
WITHDRAWAL OF LIFE­SUSTAINING TREATMENT
At times, it is appropriate to move from aggressive life­sustaining treatment to comfort measures for patients who are facing imminent death in the ED.
This conversation may be initiated by the physician, the patient, the healthcare proxy when patients cannot speak for themselves, and/or by available
AHDs such as the POLST form. The patient and/or healthcare proxy should agree that continued aggressive therapies are futile and discuss possible symptoms and outcomes. The physician should explain that medicine would be given to treat symptoms and alleviate suffering. Family should be made aware that patients might display restlessness, dyspnea, or air hunger. Encourage the family to stay and care for the patient and to notify a nurse or physician for concerning symptoms.
When possible, move the patient to a room that is quiet, private, and secluded from high­traffic areas; has low lighting; and is of sufficient size to accommodate chairs for the family. Offer to call the chaplain. Turn off or silence all alarms in the room, and remove any unnecessary equipment from the patient, such as cardiac leads, blood pressure cuffs, cardiac pads, and oxygen saturation monitors. Comfort treatment is further discussed in
Chapter 300, “Palliative Care.”


