## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 203: Metals and Metalloids
Eddie Charles Michael Garcia; Lewis S. Nelson
INTRODUCTION
Acute metal and metalloid toxicity can cause significant morbidity and mortality if unrecognized and inappropriately treated. Metals are chemical elements that possess three general properties: (1) they are a good conductor of heat and electricity, (2) they are able to form cations, and (3) they can combine with nonmetals through ionic bonds. The terms heavy metal and toxic metals have a historical tradition in clinical medicine, but lack precise definition and scientific merit. In order of ascending atomic weight, the following metals are toxic to humans: beryllium, vanadium, cadmium, barium, osmium, mercury, thallium, and lead. Lead and mercury produce the most clinically significant cases of human metal poisoning.
Metalloids are chemical elements with properties intermediate to those of metals and nonmetals. Although there is no precise definition, metalloids tend to have these two general properties: (1) they are semiconductors of electricity, and (2) they form amphoteric oxides. In order of ascending atomic weight, the following metalloids are considered toxic to humans: boron, silicon, germanium, arsenic, antimony, tellurium, and polonium, with arsenic being the most clinically significant toxic metalloid.
Exposure to either metals or nonmetals can be from (1) the pure element, (2) an organic compound containing the toxic element (defined as those compounds that contain carbon), or (3) an inorganic compound containing the element (defined as those that do not contain carbon). Depending on the metal or metalloid, potential toxicity is affected by which chemical form is responsible for the exposure.
Because of their effects on numerous enzymatic systems in the body, patients with metal or metalloid poisoning often present with protean manifestations primarily affecting five systems: neurologic, cardiovascular, GI, hematologic, and renal. Effects on the endocrine and reproductive systems are less clinically apparent. It is important to recognize an initial “index case” of metal poisoning to prevent others from being exposed or poisoned (Table 203­1).
TABLE 203­1
Sources of Lead, Arsenic, and Mercury Exposure
Element Source
Lead
Elemental, Soldering; battery burning/reclamation; bronzing; brass­making; glassmaking; ingesting ceramic lead glaze; stripping old paint; lead inorganic abatement; “moonshine”; liquids in improperly glazed pottery; contaminated herbal medications and cosmetics; indoor shooting ranges; ingestion of paint chips, lead­laden floor dust, lead foreign bodies; lead bullets in abdomen or joint spaces; contaminated municipal water supplies
Workers at risk: jewelers, painters, lead smelters, stained glass designers, pipe cutters, pigment makers, printers, welders, pottery makers, radiator repair personnel, battery reclamation workers, construction workers
Organic Leaded gasoline (tetraethyl lead) [no longer legally produced]
Arsenic
Inorganic Insecticides, rodenticides, herbicides, mining, smelting/refining, Ayurvedic and homeopathic medicines, well water contaminated by
Downl(oaarsdeendit e2025­7­1 6:l3e2ac Phi n Yg omuinr eIrPa li so r1es3 a6n.1d4/o2r. i1n5d9u.s1tr2ia7l waste; wood preservatives
Chapte[trr i2va0l3en: tM] oertals and Metalloids, Eddie Charles Michael Garcia; Lewis S. Nelson 
. Terms of Use * Privacy Policy * Notice * Accessibility arsenate
[pentavalent])
Organic Seafood, parasitical medicines
Gas (arsine) Mining smelting/refining, semiconductor industry; made by mixing acids with arsenic­containing insecticides
Mercury
Elemental Battery and thermometer manufacture; sphygmomanometer repair; dentistry; jewelry and lamp manufacture; photography; mercury mining; manufacture of scientific instruments
Inorganic Cosmetic products, especially skin­lightening products; taxidermy; fur processing; tannery work; chemical laboratories; manufacture
(mercury salts) of explosives, fireworks, disinfectants, button batteries, inks, and vinyl chloride
Organic (methyl Contaminated seafood; embalming; manufacture of drugs, fungicides, bactericides; handling of insecticides; pesticides, coated seeds; mercury, ethyl use of chlor­alkali process mercury, and phenyl mercury)
LEAD
EPIDEMIOLOGY
Lead is the most common cause of chronic metal poisoning and remains a major environmental contaminant, especially in developing countries.
Exposure to lead can occur from inhalation or ingestion, and both inorganic and organic forms of lead produce clinical toxicity. Nonpaint sources include foreign medications, herbal and dietary supplements, Ayurvedic medications, traditional remedies, metallic charms, and cosmetics, especially
 products from Asia and Africa.

Chronic lead exposure and toxicity in children is considered a public health concern because of the potential impact on intellectual development.
Most industrialized countries have banned lead in household paints, gasoline, plumbing systems, food, and drink cans; created lead abatement
2­4 programs; and enforced standards for industrial use of lead. In the United States, continued lead exposure is associated with residence in urban dwellings, residence in dwellings built before 1974 (especially before 1946), poverty, non­Hispanic black race or ethnicity, and higher population
,6 density. The town of Flint, Michigan, became the focus of national attention in 2014 when a change in water supply resulted in a 5% incidence of
 elevated blood lead levels in children <6 years old from a prior baseline of .1%.
Elevated lead levels in children are common in low­income countries where substandard or marginal living conditions exist near landfills and
,5 industries such as smelters, mines, and refineries. In developing countries, informal recycling of used lead­acid batteries and processing of gold ore
,9 rich in lead have caused mass lead poisonings.
PHARMACOLOGY
Absorption of inorganic lead is usually via the respiratory and GI tracts; skin absorption is negligible. Dietary deficiencies in calcium, iron, copper, and zinc may contribute to increased GI absorption in children. Absorption of lead from bullets or shot lodged in bone or muscle is typically minimal, but increased absorption and toxicity have been reported when these are in contact with body fluids, such as synovial fluid or cerebrospinal fluid.
Absorption of organic lead, such as tetraethyl lead from “leaded gasoline,” can occur after inhalation, ingestion, and dermal exposure. After absorption, tetraethyl lead is metabolized to inorganic lead and triethyl lead; the latter is responsible for the acute neurotoxicity from leaded gasoline.
Greater than 90% of the total body lead is stored in bone, where it easily exchanges with the blood. Lead can be transferred across the placenta, a process exacerbated by increased bone turnover during pregnancy. Excretion of lead occurs slowly; the biologic half­life of lead in bone has been estimated to be  years.
PATHOPHYSIOLOGY
Lead toxicity primarily affects the nervous, cardiovascular, hematopoietic, and renal systems. Toxic effects of lead in the CNS include (1) injuries to astrocytes, with secondary damage to the microvasculature and resultant disruption of the blood–brain barrier, cerebral edema, and increased intracranial pressure; (2) decreases in cyclic adenosine monophosphate and protein phosphorylation, which contribute to memory and learning
 deficits; and (3) alteration with calcium homeostasis, which leads to spontaneous and uncontrolled neurotransmitter release. In the peripheral
 nervous system, lead causes primary segmental demyelination, followed by secondary axonal degeneration, mostly of the motor nerves.
In the cardiovascular system, increases in the prevalence of hypertension and atherosclerotic vascular disease are found in individuals with elevated
 blood lead levels. Worldwide, it is estimated that chronic lead toxicity contributes to .5% of ischemic heart disease and .1% of stroke.
In the hematopoietic system, lead interferes with porphyrin metabolism, which contributes to lead­induced anemia. Coexisting iron deficiency may act synergistically with lead toxicity to produce a more profound anemia. Hemolytic anemia also occurs as a result of inhibition of red blood cell pyrimidine 5′­nucleotidase, an enzyme responsible for clearing cellular RNA degradation products.
In the kidney, lead affects the proximal tubule, producing Fanconi’s syndrome with aminoaciduria, glycosuria, phosphaturia, and renal tubular
 acidosis. Chronic interstitial nephritis and increased uric acid levels are due to increased tubular reabsorption of urate. Chronic lead toxicity has been linked to gout and chronic renal failure.
Lead adversely affects osteoblast and osteoclast function in bone. With chronic lead exposure, increased calcium deposition at growth plates may be seen as “lead lines” on radiographs of long bones. Lead­induced adverse effects on the reproductive system include increased fetal demise, premature rupture of membranes, depressed sperm counts, abnormal or nonmotile sperm, and sterility.
CLINICAL FEATURES
Signs and symptoms of lead poisoning vary according to the type of exposure (acute vs. chronic) and, to a lesser extent, according to the age of the individual and type of lead (inorganic vs. organic) involved (Table 203­2). Young children are more susceptible than adults to the CNS effects of lead.

Delayed cognitive development can occur in infants and children whose blood lead levels are  micrograms/dL (0.24 micromol/L) or higher.
Encephalopathy due to lead poisoning typically occurs in toddlers age  to  months old with blood lead levels >100 micrograms/dL (4.8 micromol/L), but may occur with lower blood lead levels. Encephalopathy may begin dramatically with seizures or coma or may develop indolently over
 weeks to months with decreased alertness and memory progressing to delirium.
TABLE 203­2
Clinical Features of Lead Poisoning
System Clinical Manifestations
CNS Acute toxicity: encephalopathy, seizures, altered mental status, papilledema, optic neuritis, ataxia
Chronic toxicity: headache, irritability, depression, fatigue, mood and behavioral changes, memory deficit, sleep disturbance
Peripheral nervous system Paresthesias, motor weakness (classic is wrist drop), depressed or absent deep tendon reflexes, sensory function intact
GI Abdominal pain (mostly with acute poisoning), constipation, diarrhea, toxic hepatitis
Renal Acute toxicity: Fanconi’s syndrome (renal tubular acidosis with aminoaciduria, glucosuria, and phosphaturia)
Chronic toxicity: interstitial nephritis, renal insufficiency, hypertension, gout
Hematologic Hypoproliferative and/or hemolytic anemia; basophilic stippling (nonspecific)
Reproductive Decreased libido, impotence, sterility, abortions, premature births, decreased or abnormal sperm production
GI and hematologic manifestations occur more frequently with acute than with chronic poisoning, and the colicky abdominal pains may be associated with concurrent hemolysis. Patients may complain of a metallic taste and, with long­term exposure, have bluish­gray gingival lead lines. Lead poisoning also causes constitutional symptoms, including arthralgias, generalized weakness, and weight loss. Conversely, adult and pediatric patients may appear asymptomatic in the face of significantly elevated blood lead levels.
With organic lead poisoning, neurologic abnormalities predominate. Findings range from behavioral changes, with irritability, insomnia, restlessness, and nausea and vomiting, to tremor, chorea, convulsions, and mania.
DIAGNOSIS
A detailed history, including potential occupational, environmental, travel­related, or recreational exposures, is the most important part in making a diagnosis of lead toxicity. Focus on clinical findings, the age of the home as well as any remodeling, and work, school, or day care locale. Ask adults about medication, dietary supplements, cosmetics, and hobbies and evaluate children who may be secondarily exposed to lead from adult activities. Additionally, screen children for abnormal development and the presence of pica or excessive hand­to­mouth behavior. Toxicity due to retained lead bullets may manifest several decades after being shot. Hyperthyroidism, pregnancy, fever, reinjury, or immobilization of the affected extremity can promote lead release from these retained objects after years of dormancy. The combination of abdominal pain or neurologic dysfunction with anemia should raise suspicion for lead toxicity. Consider the diagnosis in all children presenting with acute encephalopathy.
The definitive diagnosis of lead poisoning rests on finding an elevated blood lead level. Fingerstick capillary blood may be used as screening, but results maybe be misleading due to the potential for environmental lead contamination. Elevated concentrations always should be confirmed using a
 venous blood sample. The reference value for an elevated blood lead level per the Centers for Disease Control and Prevention has decreased from 
,17 micrograms/dL (2.88 micromol/L) in the 1960s to its current value of  micrograms/dL (0.24 micromol/L).
Although it is important to order a blood lead level for confirmatory diagnosis and assistance in monitoring therapy, the laboratory turnaround time for results may be days. Diagnostic studies in the ED should therefore focus on evaluation for anemia and examination of radiographs for evidence of lead exposure.
The anemia from lead toxicity can be normocytic or microcytic, with or without evidence of hemolysis. Basophilic stippling in red blood cells from impaired clearing of cellular RNA degradation products is sometimes seen in lead­poisoned patients. This finding is nonspecific for lead poisoning; it is also found in arsenic toxicity, sideroblastic anemia, and the thalassemias. Anemia and basophilic stippling occur variably, and their absence does not exclude lead toxicity.
Following acute or subacute ingestion of lead, abdominal radiographs may show radiopaque material in the GI tract. In children with chronic lead poisoning, radiographs of long bones, especially of the knee, may reveal horizontal, metaphyseal “lead lines,” which represent failure of bone remodeling rather than deposition of lead.
The differential diagnosis of lead poisoning includes Wernicke’s encephalopathy; withdrawal from ethanol and other sedative­hypnotic drugs; meningitis; encephalitis; human immunodeficiency virus infection; intracerebral hemorrhage; hypoglycemia; severe fluid and electrolyte imbalances; hypoxia; arsenic, thallium, and mercury toxicity; and poisoning with cyclic antidepressants, anticholinergic drugs, ethylene glycol, or carbon monoxide.
The abdominal pains of lead poisoning can mimic sickle cell crisis, the hepatic porphyrias, or appendicitis. Chronic lead poisoning can mimic major depression, hypothyroidism, polyneuritis, gout, iron deficiency anemia, and learning disability.
TREATMENT
Patients with appropriate signs and symptoms and an elevated blood lead level are classified as lead poisoned and should be treated.
For acute encephalopathy, provide standard life support measures and treat seizures with benzodiazepines. If lead encephalopathy is suspected, initiate chelation therapy promptly (i.e., in the ED) without waiting for the results of a blood lead level (Table 203­3). If abdominal films demonstrate
GI foreign bodies consistent with lead, institute whole­bowel irrigation with a polyethylene glycol electrolyte solution. Larger lead bodies, such as fishing sinkers and jewelry, may require endoscopic or surgical removal.
TABLE 203­3
Guidelines for Chelation Therapy in Lead­Poisoned Patients* Severity and Blood Lead Level Dose
Encephalopathy Dimercaprol,  milligrams/m2 (or  milligrams/kg) IM every  h for  d and
Edetate calcium disodium, 1500 milligrams/m2 per day via continuous infusion or in 2–4 divided doses IV for
 d; max  grams/d; start  h after dimercaprol
Symptomatic Dimercaprol and/or severe poisoning and
Adults: blood lead >100 micrograms/dL (4.8 Edetate calcium disodium (as described above) micromol/L) or
Children: blood lead >70 micrograms/dL Edetate calcium disodium (alone)
(3.4 micromol/L) or
Succimer (as described below)
Asymptomatic
Succimer
, 350 milligrams/m2 (or  milligrams/kg) PO every  h for  d, then every  h for  d
Adults: blood lead 70–100 micrograms/dL
(3.4–4.8 micromol/L)
Children: blood lead 45–69 micrograms/dL
(2.2–3.3 micromol/L)
Asymptomatic Routine chelation not indicated; remove patient from source of exposure
Adults: blood lead <70 micrograms/dL (3.4 micromol/L)
Children: blood lead <45 micrograms/dL
(2.2 micromol/L)
*General guidelines. Consult with medical toxicologist or regional poison center for specifics and dosing.
Chelation therapy for lead toxicity uses dimercaprol (previously known as British anti­Lewisite or BAL), edetate calcium disodium (sometimes
,19 abbreviated CaNa­EDTA), and succimer (also known as dimercaptosuccinic acid or DMSA) (Table 203­3). Penicillamine, another chelating
 agent, is not approved by the U.S. Food and Drug Administration for treatment of lead toxicity, but penicillamine is used in Europe for lead poisoning.
The chelation dosing schedules are guided by the blood lead levels, the presence or absence of findings, and the age of the
,21 patient. Adverse side effects from chelation therapy are common, and consultation with a medical toxicologist or other lead poisoning expert is recommended to assist in management.
Dimercaprol crosses the blood–brain barrier and is indicated when neurotoxicity or high blood lead levels are present. Dimercaprol is administered IM and is typically used with edetate calcium disodium to prevent lead from being transported into the brain. The diluent for dimercaprol includes peanut oil, and therefore, anticipate an allergic reaction and provide careful monitoring for patients with peanut allergy. Side effects of dimercaprol include hypertension; fever, pain, and sterile abscess at injection site; nausea; vomiting; diarrhea; abdominal pain; headache; lacrimation; rhinorrhea; and hemolysis in glucose­6­phosphate dehydrogenase–deficient patients. Side effects with dimercaprol are dose dependent and occur in up to 65% of treated patients using recommended doses.
Edetate calcium disodium can be used as a single agent in the treatment of lead toxicity, but because this agent does not cross the blood–brain barrier, dimercaprol should be given before and during the entire course of edetate calcium disodium when there are CNS symptoms. An important precaution: do not confuse this product with edetate disodium, which is used to treat hypercalcemia. Side effects from edetate calcium disodium include renal toxicity, dermatitis, headache, fever, chills, and myalgias.
Succimer, an oral analog of dimercaprol, effectively chelates lead. Although succimer does not cross the blood–brain barrier, its use as a sole agent is
 not associated with exacerbation of lead­induced encephalopathy. Some toxicologists consider succimer the preferred chelator for lead poisoning in all but the most severe cases. Its advantages include oral administration without increasing lead absorption from the GI tract, no serious adverse effects, and minimal chelation of essential metals. Side effects from succimer include nausea, vomiting, diarrhea, abdominal pain, rash, pruritus, sore throat, rhinorrhea, drowsiness, paresthesias, transient elevations in serum transaminases and alkaline phosphatase, thrombocytosis, and eosinophilia.
Chelation was not associated with any increased risk of birth defects in the few published cases, and pregnant women with elevated blood lead levels
 should be chelated following the same guidelines (Table 203­3). Neonatal blood lead levels may be elevated despite maternal chelation, and neonates may require chelation following birth.
Abdominal colic usually subsides within days after beginning chelation therapy, and other acute manifestations clear within  to  weeks with therapy. Lead­induced nephropathy may be partly reversible with chelation therapy. Approximately 85% of patients who suffer lead encephalopathy develop permanent central neurologic damage, including seizures, mental retardation in children, and cognitive deficits in adults.
DISPOSITION AND FOLLOW­UP
Removal of the source of lead is the most important action for lead poisoning, and patients should not be returned to the home environment until lead decontamination and abatement measures have been addressed. Family members and coworkers should be evaluated for occult lead toxicity.
Hospital admission is recommended for (1) children with symptoms or with a blood lead level >70 micrograms/dL (>3.4 micromol/L), (2) adults with central neurologic symptoms, and (3) patients with suspected lead toxicity when returning to the environment is considered dangerous.
ARSENIC
EPIDEMIOLOGY

Arsenic is a nearly tasteless, odorless metalloid that causes significant acute and chronic toxicity worldwide. Arsenicals are found in a variety of compounds and industries (Table 203­1) and continue to be used as a means for homicide and suicide. Chronic arsenic toxicity from unsafe drinking
 water has the potential to threaten the health of millions of people worldwide, particularly in Bangladesh.
Arsenic exists in elemental, inorganic salts, organic salts, and gaseous forms. Elemental and organic forms have limited toxicity, whereas inorganic
3+ 5+ compounds, including arsenite (trivalent or As ) and arsenate (pentavalent or As ), are highly toxic.
PHARMACOLOGY
Arsenic is well absorbed by GI, respiratory, and parenteral routes and may be absorbed through nonintact skin. Due to its water solubility, pentavalent arsenic (arsenate) is more readily absorbed across mucous membranes, such as the GI tract, than is trivalent arsenic (arsenite), which penetrates the skin more readily due to its increased lipid solubility. Within  hours, inorganic arsenic redistribution into the liver, kidney, spleen, lung, GI tract, muscle, and nervous tissues occurs, with subsequent integration into hair, nails, and bone. Elimination from the blood is rapid, and excretion is predominantly renal. Toxicity of the various forms is partly determined by excretory rates, with the more toxic arsenite being excreted at a slower rate than arsenate or the organic arsenical compounds. Arsenic crosses the placenta and is teratogenic in animals and humans.
PATHOPHYSIOLOGY
Arsenic reversibly binds with sulfhydryl groups found in many tissues and enzyme systems. Acute exposure produces dilatation and increased permeability of small blood vessels, resulting in GI mucosal and submucosal inflammation and necrosis, cerebral edema and hemorrhage, myocardial tissue destruction, and fatty degeneration of the liver and kidneys. Subacute or chronic exposure can cause a primary peripheral axonal neuropathy with secondary demyelination. Inhaled arsine attaches to sulfhydryl groups of hemoglobin, producing an acute hemolytic anemia with resulting
 jaundice, abdominal pain, and hemoglobinuria­induced acute renal failure.
CLINICAL FEATURES
The signs and symptoms of toxicity vary with the form, amount, and concentration ingested and the rates of absorption and excretion of the various arsenical compounds (Table 203­4).
TABLE 203­4
Clinical Features of Inorganic Arsenic Toxicity
Onset of Symptoms Clinical Features
Acute toxicity (10 min to several hours) GI: nausea, vomiting, cholera­like diarrhea
Cardiovascular: hypotension; tachycardia; dysrhythmias, including torsades de pointes; secondary myocardial ischemia
Pulmonary: acute respiratory distress syndrome
Renal: acute renal failure
Central neurologic: encephalopathy
Subacute toxicity (1–3 wk after acute exposure or with Central neurologic: headache, confusion, delirium, personality changes chronic exposure) Peripheral neurologic: sensory and motor neuropathy
Cardiovascular: QT interval prolongation
Pulmonary: cough, alveolar infiltrates
Dermatologic: rash, alopecia, Mees lines
Chronic toxicity (ongoing low­level occupational or Dermatologic: hyperpigmentation, keratoses, Bowen’s disease, squamous and basal cell environmental exposure) carcinoma
Cardiovascular: hypertension, peripheral arterial disease
Endocrine: diabetes mellitus
Oncologic: lung and skin cancer
Following ingestion of inorganic arsenic, clinical effects usually develop within minutes to hours of ingestion. Severe gastroenteritis with nausea, vomiting, and cholera­like diarrhea is the hallmark of acute poisoning and may last several days to weeks, frequently necessitating hospitalization.
Patients may complain of a metallic taste. Hypotension and tachycardia secondary to volume depletion, capillary leak, and myocardial dysfunction occur in moderate to severe cases. The ECG may demonstrate nonspecific ST­segment and T­wave changes with a prolonged QT interval, although
 these findings are more common in chronic intoxication. Ventricular tachycardia with a torsades de pointes morphology may occur. Acute encephalopathy, acute respiratory distress syndrome, acute kidney injury, and rhabdomyolysis may ensue.
Survivors of acute poisonings and patients who are poisoned slowly may develop subacute toxicity, typically presenting with weakness, muscle aches, abdominal pain, memory loss, personality changes, periorbital and extremity edema, or skin rash, often with a history of gastroenteritis occurring  to

 weeks earlier. Central neurologic symptoms include headache, confusion, delirium, and personality changes, which may become chronic.
Peripheral neuropathy develops in a stocking­glove distribution and is initially sensory, with motor symptoms developing later. Rarely, an ascending paralysis mimicking Guillain­Barré syndrome may develop. Dermatologic manifestations vary and include morbilliform rash, alopecia, and desquamation. Mees lines (1­ to 2­mm–wide transverse white lines in the nails) due to disrupted keratinization of the nail matrix may be seen  to  weeks after an acute exposure.
Chronic toxicity from arsenic occurs with ongoing low­level occupational or environmental exposure and has been linked to the development of hypertension, peripheral vascular disease, diabetes mellitus, epidermoid cancer, respiratory tract cancer, hepatic angiosarcoma, and, possibly, leukemia. Dermatologic findings are prominent and include hyperpigmentation, hyperkeratosis of the palms and soles, Bowen’s disease, and squamous and basal cell carcinomas. Perforation of the nasal septum has been found in workers exposed occupationally to arsenic.
DIAGNOSIS
The diagnosis is easily missed without a history of exposure to arsenic, and physicians rarely encounter arsenic toxicity. Consideracute arsenic poisoning in a patient with hypotension that was preceded by severe gastroenteritis with no apparent explanation. Chronic arsenic toxicity should be considered in a patient with a peripheral neuropathy, typical skin manifestations, or recurrent bouts of unexplained gastroenteritis.
An abdominal radiograph may demonstrate intestinal radiopaque metallic flecks following ingestion. The ECG often reveals a prolonged QT interval, especially in subacute poisoning. The CBC may reveal a normocytic, normochromic, or megaloblastic anemia, and/or a thrombocytopenia. The WBC count may be elevated in acute toxicity and decreased in chronic toxicity. A relative eosinophilia and red cell basophilic stippling may be observed.
Elevated reticulocyte counts are found in cases with a component of hemolytic anemia.
Definitive diagnosis of acute poisoning is made by finding elevated arsenic levels in a 24­hour urine collection. All urinary measurements of metals should be collected in metal­free containers after a 5­day seafood­free diet (there is a large amount of organic arsenic in seafood). Normal urinary arsenic level is <50 micrograms/L (0.67 micromol/L), and total urinary arsenic excretion in an unexposed patient typically does not exceed 100 micrograms/d (1.3 micromol/d). If the baseline urinary level is within normal limits and arsenic intoxication is still suspected, hair and nail clippings should be harvested for laboratory analysis. Due to the rapid distribution of arsenic in tissues, blood arsenic levels are often unreliable.
Include arsenic toxicity in the differential diagnosis for shock of unknown cause, encephalopathy, peripheral neuropathy (including Guillain­Barré syndrome), Addison’s disease, hypo­ and hyperthyroidism, patients with the previously mentioned dermatologic manifestations, Korsakoff’s syndrome, persistent gastroenteritis and/or cholera­like diarrhea, porphyria, other metal toxicities such as thallium and mercury, and unexplained, prolonged malaise and weakness.
TREATMENT
Acute arsenic toxicity is a life­threatening illness requiring aggressive management. Hypotension and dysrhythmias are the most common causes of death. Hypotension, usually due to volume depletion, should be managed initially with crystalloid volume replacement, and vasopressor therapy with dopamine or norepinephrine may be required. Avoid overhydration because pulmonary and cerebral edema can occur. Ventricular tachycardia and fibrillation may be treated with lidocaine, amiodarone, and electrical defibrillation as necessary. Magnesium sulfate, isoproterenol, and overdrive pacing therapies should be considered for torsades de pointes. Monitor and correct potassium, calcium, and magnesium levels.
Institute gastric lavage with a large­bore orogastric tube for acute ingestion. Activated charcoal poorly adsorbs arsenic but may be effective for coingestants. Whole­bowel irrigation should be considered if abdominal radiographs reveal intestinal radiopaque materials consistent with arsenic.
Chelation therapy for arsenic toxicity uses dimercaprol or succimer (Table 203­5). Treat patients with acute arsenical poisoning or severe, life­
 threatening toxicity with dimercaprol until the clinical condition stabilizes and succimer, the less toxic oral chelating agent, can be substituted. Do not delay chelation in severely ill patients until laboratory confirmation because chelation is most effective when given within minutes to hours of exposure. Conversely, hold chelation therapy in clinically stable patients with suspected chronic arsenic toxicity pending diagnosis. Chelation with the oral agent succimer may lower the tissue content of arsenic and speed urinary excretion but does not appear to decrease
 morbidity or mortality in chronic arsenic poisoning. Obtain early consultation with a regional poison control center or medical toxicologist for treatment. For chronic toxicity, prevent further arsenic absorption and, if appropriate, GI decontamination. Dermatologic manifestations of chronic
 toxicity are unresponsive to chelation.
TABLE 203­5
Guidelines for Chelation Therapy in Arsenic­Poisoned Patients
Chelator Dose
Dimercaprol 3–5 milligrams/kg deep IM every  h for  d, followed by 3–5 milligrams/kg IM every 6–12 h until able to switch to succimer, up to  d total
Succimer  milligrams/kg PO every  h for  d, followed by  milligrams/kg PO every  h for  days; children <5 years old: 350 milligrams/m2 PO on adult schedule
Note: These are general guidelines. Consult with medical toxicologist or regional poison center for specifics and dosing.
DISPOSITION AND FOLLOW­UP
Hospitalization is recommended for (1) patients with acute or life­threatening known or suspected arsenic poisoning, (2) chronically poisoned patients requiring dimercaprol therapy, and (3) patients in whom suicidal or homicidal intent is suspected. In patients with acute arsenic poisoning, prognosis may be influenced favorably by the rapid institution of dimercaprol therapy. Recovery from arsenical neuropathy appears to be related more to the initial severity of symptoms than to chelation therapy, although in patients who do recover, dimercaprol appears to significantly shorten the duration of illness. Often, neurologic recovery occurs slowly over months to years.
ARSINE GAS
Arsine is a colorless, nonirritating toxic gas encountered in the semiconductor industry, ore smelting, and refining processes and is produced when arsenic­containing insecticides are mixed with acids.
Arsine gas is highly toxic and extremely flammable. It has a garlic or fishy odor, but there may be no odor detectable with toxic exposure. Exposure is by inhalation. Malaise, dizziness, nausea, and abdominal pain occur within a few hours. Intravascular hemolysis and renal failure then develop. Arsine gas does not cause acute arsenic poisoning. Treatment is supportive, with blood transfusions, exchange transfusion to remove the nondialyzable arsine,
 and hemodialysis for the acute kidney injury. Chelation therapy has no role in the management of arsine toxicity.
MERCURY
EPIDEMIOLOGY
+
Mercury occurs in elemental (quicksilver), inorganic, and organic forms. Inorganic mercury compounds are subdivided largely into mercurous (Hg )
2+
(e.g., mercurous chloride or calomel) and mercuric (Hg ) salts (e.g., cinnabar or mercuric sulfide). Organic mercurials exist as short­ and long­chained alkyl and aryl compounds. The short­chained alkyls, such as methyl mercury and ethyl mercury, are more toxic to humans, with dimethyl mercury being lethal in small amounts. All forms of mercury are toxic but differ in the means of exposure, routes of absorption, constellations of clinical
 findings, and responses to therapy (Table 203­1).
PHARMACOLOGY
Elemental mercury is absorbed primarily by vapor inhalation or transdermally. For example, attempting to clean up elemental mercury from a broken thermometer with a vacuum causes volatilization due to both the heat and the airflow through the canister. Absorption by the GI tract is usually negligible so that swallowing elemental mercury contained in a glass thermometer does not produce adverse effects unless the mucosa is damaged. IM injections of mercury can induce abscess and granuloma formation. IV injections have produced mercury pulmonary and
 systemic emboli. Elemental mercury crosses the blood–brain barrier, where it is ionized and trapped in the CNS.

Inorganic mercurysalts are absorbed primarily through the GI tract, but they may also be slowly absorbed across intact skin. Mercuric salts deposit in the ionized form primarily in the kidney, liver, and spleen. Mercury salts do not enter the CNS in consequential amounts nor do they cross the placenta.
Organic mercury compounds are also primarily absorbed by the GI tract. The highly lipid­soluble short­chained alkyls easily cross membranes, accumulating in red blood cells, the CNS, liver, kidney, and fetus. Longer chained alkyl and the aryl compounds are biotransformed into inorganic mercuric ions in the body; thus, their toxicity more closely resembles inorganic mercury toxicity.
Inorganic and the aryl organic mercurials are eliminated in the urine and feces. The short­chained alkyl compounds are excreted primarily in the bile, where they undergo significant enterohepatic circulation.
PATHOPHYSIOLOGY
Mercury binds with sulfhydryl groups, affecting a diverse number of enzyme and protein systems in the various organs in which they deposit. For
 example, mercuric salts produce proximal renal tubular necrosis.
CLINICAL FEATURES

The clinical effects of mercury poisoning depend on the form and, in some cases, the route of exposure. In general, the neurologic, GI, and renal systems are predominantly affected.
Elemental Mercury
Acute symptoms following inhalation of elemental mercury vapor include shortness of breath, fever/chills, cough, nausea, vomiting, diarrhea, metallic taste, headaches, weakness, and blurry vision. In severe cases, patients may develop acute respiratory distress syndrome. Following metabolism of absorbed elemental mercury to inorganic salts, patients may also develop signs of inorganic mercury toxicity, including tremor and renal failure.
Inorganic Mercury
Mercury salts are highly irritating, and an acute ingestion produces a severe hemorrhagic gastroenteritis with abdominal pain often associated with a characteristic graying of the oral mucosa and metallic taste. Shock and cardiovascular collapse may rapidly ensue. Acute kidney injury results from both direct toxicity of the mercury ions and from decreased renal perfusion due to shock.
GI findings of chronic inorganic mercury toxicity include metallic taste, burning sensation in the mouth, loose teeth, mucosal lesions and fissures,
 excessive salivation, and nausea. Hallmarks of chronic neurologic toxicity include tremor, neurasthenia, and erethism. Neurasthenia is characterized by fatigue, depression, headaches, and difficulty concentrating. Erethism refers to behavioral changes characterized by shyness, emotional lability, irritability, insomnia, and delirium. Chronic renal toxicity ranges from reversible proteinuria to the nephrotic syndrome. Acrodynia, also known in small children as pink disease, is an immune­mediated reaction to mercury characterized by a generalized rash; edema and erythema of the palms, soles, and face; excessive sweating; fever; irritability; splenomegaly; and generalized hypotonia with particular weakness of the pelvic and pectoral muscles.
Organic Mercury
The short­chained alkyl compounds, methyl, dimethyl, and ethyl mercury, have the most devastating effects on the CNS. After a latent period of weeks to months, orofacial paresthesias are a common initial symptom, followed by headache, tremor, and fatigue. In severe cases, patients may develop
 ataxia, muscle rigidity and spasticity, blindness, hearing deficits, and dementia. Mild GI, renal, and pulmonary abnormalities may develop with organic mercury poisoning.
DIAGNOSIS
An exposure history in either the patient or a household member, along with typical physical findings, especially tremor or those of erethism or acrodynia, suggests mercury poisoning. Ingestion of mercuric chloride can produce a rapidly fatal course and should be considered in a patient
 presenting with a corrosive gastroenteritis. Often, however, the diagnosis of mercury toxicity is subtle and only made after many other diagnoses have been investigated.
For all forms of mercury, except short­chained alkyls, a 24­hour urinary measurement of mercury should be performed after a 5­day seafood­free diet.
A seafood meal (which contains organic mercury) can temporarily elevate the mercury level to the toxic range until the mercury is eliminated. Most unexposed individuals will have 24­hour urine mercury levels <10 to  micrograms/L (<0.05 to .075 micromol/L). A level >20 micrograms/L (>0.1 micromol/L) may indicate meaningful exposure, but does not diagnose poisoning without an appropriate exposure and clinical syndrome.
Short­chained alkyl mercury compounds are excreted predominantly by the bile, rendering urinary measurements invalid to assess toxicity from these agents. Laboratory diagnosis after this exposure rests on finding elevated whole­blood mercury levels, because these compounds concentrate in erythrocytes. Whole­blood mercury levels are normally <5 micrograms/L (<0.025 micromol/L).
Although elevated blood or urine values are necessary to confirm the diagnosis, levels correlate poorly with toxicity and do not distinguish asymptomatic exposure from mercury poisoning. Furthermore, blood or urine levels do not represent total­body burden. Levels are most useful in confirming exposure and in following the effects of chelation therapy (see following section, “Treatment”).
MRI findings in methyl mercury toxicity from ingestion of contaminated seafood include marked atrophy of the visual cortex, cerebellar vermis and
 hemispheres, and postcentral cortex.
Behavioral changes or tremor similar to those caused by mercury can be seen with hypothyroidism, apathetic hyperthyroidism, metabolic encephalopathy, senile dementia, adverse effects of therapeutic drugs, Parkinson disease, delayed neuropsychiatric sequelae of carbon monoxide poisoning, lacunar infarction, cerebellar degenerative disease or tumor, and ethanol or sedative­hypnotic drug withdrawal. Corrosive gastroenteritis can be caused by iron, arsenic, phosphorus, acids, or alkali ingestion. Cerebral palsy, intrauterine hypoxia, and teratogenic effects of therapeutic and illicit drugs and environmental contaminants should be considered when evaluating an infant thought to be affected in utero by short­chained alkyl mercury compounds.
TREATMENT
General therapeutic measures include removal from exposure and supportive therapy. Hemodialysis does not enhance mercury clearance but may be indicated for treatment of acute kidney injury.
For elemental mercury, the severe respiratory failure following inhalation of volatilized elemental mercury or aspiration of elemental mercury may require endotracheal intubation and positive­pressure ventilation.
For ingestion of inorganic mercury salts, treat with aggressive IV hydration and GI decontamination, including gastric lavage if the patient has not had significant emesis, and consider activated charcoal unless contraindicated (e.g., bleeding).
For organic mercury toxicity, institute gastric decontamination in the setting of acute ingestion, and supportive care. Chelation is indicated if it can
 be given within several hours after ingestion of mercury salts. Chelation therapy for patients with chronic poisoning, especially to organic mercury, is less effective. A history of significant mercury exposure, signs and symptoms consistent with mercury poisoning, and substantially elevated blood or urine mercury levels may assist in the decision making and help determine duration of treatment for chronic mercury toxicity. Dimercaprol and succimer are Food and Drug Administration approved for mercury poisoning (Table 203­6). In Germany, the chelator dimercapto­propane sulfonate
,31,36 is widely used to treat mercury poisoning.
TABLE 203­6
Guidelines for Chelation Therapy in Mercury­Poisoned Patients
Elemental and Inorganic Mercury Organic Mercury
Severe acute Dimercaprol,  milligrams/m2 (5 milligrams/kg) IM every  h for  d, followed by .5 Succimer,  milligrams/kg PO every  h for  poisoning d, then every  h for  d; children <5 years milligrams/kg IM every  h for  d, followed by .5 milligrams/kg IM every 12–24 h until clinical improvement occurs or until able to switch to succimer therapy, for up to  d old: 350 milligrams/m2 orally on adult total schedule
Mild acute Succimer,  milligrams/kg PO every  h for  d, then every  h for  d No proven benefit for chelation therapy poisoning and chronic poisoning
Note: These are general guidelines. Consult with medical toxicologist or regional poison center for specifics and dosing.
The chelation regimen is adjusted according to clinical response and development of adverse reactions. Adverse reactions with dimercaprol increase with dose and include nausea, vomiting, headache, paresthesias, and diaphoresis. Fever is frequently seen in children during dimercaprol therapy.
The dimercaprol–mercury complex is dialyzable, and hemodialysis may be helpful in patients receiving dimercaprol who have diminished renal
 function. Plasma exchange transfusion also was beneficial in a case of mercuric chloride ingestion. Dimercaprol is contraindicated in methyl mercury poisoning due to the potential for exacerbation of central neurologic symptoms.Succimer is generally well tolerated.
Consultation with a poison control center or medical toxicologist is recommended for further assistance with chelation treatment.
DISPOSITION AND FOLLOW­UP
Hospital admission is recommended for (1) patients known or suspected to have ingested mercury salts, (2) patients known or suspected to have inhaled elemental mercury vapor with pulmonary injury, and (3) patients requiring dimercaprol therapy.
Outcome depends on the form of mercury and the severity of toxicity. Mild cases of elemental and mercury salt poisoning and very mild cases of organic mercury toxicity may have complete recovery. Death can occur in severe cases of mercuric chloride poisoning and with dimethyl mercury exposure. Most patients with symptomatic organic mercury poisoning are left with residual neurologic deficits. Environmental decontamination and removal of the patient, family members, and coworkers from a site of ongoing contamination play a critical role in preventing injury to others.
OTHER METALS AND METAL SALTS
Other metals and their salts may cause toxicity (Table 203­7). Metal salts typically cause early GI irritation (nausea, vomiting, diarrhea, cramping, and hemorrhage) with subsequent neurologic, renal, hematologic, and cutaneous abnormalities. Symptoms are often vague, and without an explicit
 history of metal salt exposure, patients are usually misdiagnosed. Metal fume fever is the clinical syndrome of fever, chills, body ache, headache, and fatigue resulting from inhalation of dust or fumes containing zinc, aluminum, or magnesium oxide.
TABLE 203­7
Source, Manifestations, and Treatments for Patients Poisoned by Less Common Metals
Acute Clinical Chronic Clinical
Metal Poisoning Source Specific Treatment
Manifestations Manifestations
Bismuth Antidiarrheals (bismuth subsalicylate), Abdominal pain, acute renal Myoclonic encephalopathy Dimercaprol (limited impregnated surgical packing paste failure evidence)
Cadmium Contaminated soil in cadmium­rich areas; Ingestion: hemorrhagic Proteinuria, osteomalacia (itai­itai Ingestion: succimer alloys used in welding, soldering, jewelry, gastroenteritis or ouch­ouch disease), lung cancer (limited evidence; not and batteries Inhalation: pneumonitis, (questionable) generally indicated) acute respiratory distress Pneumonitis: chelation syndrome not indicated
Chromium Corrosion inhibitors (e.g., heating Skin irritation and ulceration, Mucous membrane irritation, Acetylcysteine (animal systems), pigment production, leather contact dermatitis; GI perforation of nasal septum, studies suggest efficacy tanning, metal finishing, dietary irritation, renal and chronic cough, contact dermatitis, as chelator) supplements, prosthetic joints pulmonary failure skin ulcers (“chrome holes”), lung cancer
Cobalt “Hard metal dust” (tungsten–cobalt Contact dermatitis, asthma Metal lung disease (spectrum Acetylcysteine (animal mixture), flexible magnets, drying agents, ranging from alveolitis to fibrosis), studies suggest efficacy prosthetic joints cardiomyopathy, thyroid as chelator) hyperplasia
Copper Leaching from copper pipes and Ingestion: resembles iron Hepatotoxicity (childhood cirrhosis Dimercaprol for containers; fungicide (copper sulfate); poisoning; blue vomitus or idiopathic copper toxicosis) hepatic or hematologic welding (copper oxide) (copper salts), toxicity hepatotoxicity, hemolysis, Succimer in mild methemoglobinemia poisoning
Inhalation: metal fume fever
(self­limited fever, chills, cough, dyspnea)
Silver Colloidal (metallic) silver used for Mucosal irritation (silver Argyria (permanent skin Selenium (possible medicinal purposes as oral solutions, oxide and nitrate) discoloration due to silver role) aerosols, and douches; cauterizing and deposition and melanocyte antiseptic agent (silver nitrate); jewelry, stimulation) wire
Thallium Rodenticides (use prohibited in the United Early: nausea, vomiting, Sensorimotor neuropathy, Multidose activated
States); contaminated herbal products; abdominal pain, tachycardia psychosis, dermatitis, charcoal medical radioisotope (minuscule dose); Intermediate (>24 h): painful hepatotoxicity Prussian blue, 125 most poisonings related to homicide ascending neuropathy, milligrams/kg PO every cardiac dysrhythmias,  h (usually dissolved altered mental status in  mL of 15%
Delayed (2 wk): alopecia mannitol)
Zinc Smelting, electroplating, military smoke Ingestion: nausea, vomiting, Copper deficiency, sideroblastic Edetate calcium bombs, zinc lozenges, abdominal pain (resembles anemia, neutropenia disodium welding/galvanizing (zinc oxide) iron poisoning) Supportive care for
Inhalation: mucosal metal fume fever irritation, metal fume fever
(zinc oxide)
Treatment universally involves removal of the patient from the source, topical decontamination, administration of activated charcoal (if exposure involves ingestion), and supportive care, including aggressive fluid and electrolyte repletion and hemodialysis, if required. Indications for chelation
,19,36,38 and its efficacy in treating metal toxicity vary with the specific metal (Table 203­7). Consult with a medical toxicologist or a regional poison control center for specific indications and drug doses.


