## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 125: Neck Masses in Infants and Children
Charles E. A. Stringer; Vikram Sabhaney
INTRODUCTION AND EPIDEMIOLOGY
Neck masses are common in childhood, and although most are benign, malignancy must remain a primary consideration. Among patients referred to
,2 tertiary centers for surgical excision of a cervical lesion, 90% to 96% of lesions are benign and are predominantly congenital. While diagnosis is challenging, differentiating neck masses into inflammatory, congenital, or a neoplastic category is the first step toward diagnosis.
GENERAL APPROACH
CLINICAL FEATURES
A thorough history and physical examination help narrow the broad differential for cervical lymphadenopathy. Both acuity and laterality of node swelling are helpful for diagnosis. Acute bilateral lymph nodes are typically due to a viral infection, acute unilateral nodes are due to a bacterial cause, and subacute/chronic nodes (>4 to  weeks) are due to granulomatous bacteria or noninfectious causes. This framework is most effective for diagnosis when combined with the general and specific features of different etiologies (Tables 125­1 and 125­2). Carefully document the features
(size, location) of all head and neck masses for future comparison. Lymph node location and characteristics give clues based on lymphatic drainage patterns. Look for systemic disease by assessing for generalized lymphadenopathy, hepatosplenomegaly, testicular masses and/or enlargement in males, and the child’s overall condition.
TABLE 125­1
Key Features From History
Historical Feature Associated Etiology
Duration >4–6 weeks Granulomatous lymphadenitis, congenital lesions, malignancies
Rate of growth Fluctuating → inflammatory
Progressive → malignancy
Pain Infectious, or infected congenital lesion
Recent illness Viral URTI → Reactive lymphadenopathy
Pharyngitis → EBV, GAS
Neonatal period Group B Streptococcus
Pain with meals Sialoadenitis
Tuberculosis exposure (travel or sick contacts) Tuberculosis mycobacteria
Undercooked meat or unpasteurized milk exposure Toxoplasmosis
Cat exposure Cat­scratch disease or toxoplasmosis

Chapter 125: Neck Masses in Infants and Children, Charles E. A. Stringer; Vikram Sabhaney 
Animal exposure (including rabbits) Tularemia, cat­scratch disease, toxoplasmosis
. Terms of Use * Privacy Policy * Notice * Accessibility
Mass since birth Congenital
Birth trauma, forceps delivery Fibromatosis colli
Constitutional symptoms (fever, weight loss, night sweats) Tuberculosis mycobacteria, malignancy
Recent blood transfusions EBV, CMV, HIV
Recent immunizations (DPT, polio, typhoid) Reactive lymphadenopathy
Medications Phenytoin, carbamazepine, isoniazid, hydralazine, and others
Abbreviations:CMV = cytomegalovirus; DPT = diphtheria, pertussis, and tetanus; EBV = Epstein­Barr virus; GAS = group A Streptococcus; HIV = human immunodeficiency virus; URTI = upper respiratory tract infection.
TABLE 125­2
Key Features on Examination
Physical Examination Finding Associated Etiology
Laterality Bilateral → viral
Unilateral → bacterial
Size >3 cm more likely congenital or malignant; fluctuations in size more likely infectious
Location Depends on lymph drainage pattern (see Figure 125­2)
Hard, rubbery, fixed, matted nodes Possibly malignant
Signs of inflammation (tenderness, erythema, warmth) Bacterial lymphadenitis or infected congenital lesion
Fluctuance Abscess, often due to Staphylococcus aureus, or GAS
Difficulty swallowing or drooling Deep space infection—retropharyngeal abscess
Viral URTI (cough, rhinorrhea, conjunctivitis) Reactive lymphadenopathy
Pharyngitis EBV mononucleosis, GAS
Periodontal disease Anaerobic bacteria
Purulent salivary duct drainage Sialoadenitis
Crossing jaw—suggests parotid involvement Sialoadenitis, mumps, salivary gland malignancy
Violaceous skin change Granulomatous lymphadenitis (TbM, NTM, CSD, tularemia)
Cold node Granulomatous lymphadenitis or malignancy
Midline, moves with swallowing or tongue protrusion Thyroglossal duct cyst
Transillumination Lymphangioma (cystic hygroma)
Torticollis, laterally mobile, vertically immobile Fibromatosis colli
Supraclavicular mass Lymphoma, or less likely metastatic node
Midline mass Thyroid cancer, thyroglossal duct cyst, dermoid cyst
Posterior mass Rubella, toxoplasmosis, nasopharyngeal cancer
Hepatosplenomegaly Malignancy, mononucleosis, systemic disease
Wasting or cachexia Malignancy
Abbreviations: CSD = cat­scratch disease; EBV = Epstein­Barr virus; GAS = group A Streptococcus; NTM = nontuberculous mycobacteria; TbM = tuberculous mycobacteria; URTI = upper respiratory tract infection.
GENERAL MANAGEMENT
Ideally, the treatment of a childhood neck mass is directed at the specific cause; however, due to the many etiologies, this is not always possible at first presentation. The majority of presentations are benign; however, the priority of childhood neck masses is to correctly identify those that are neoplastic. Figure 125­1 provides an approach to management based on suspected etiology and should be adapted to the individual patient. Followup of patients who are treated with antibiotics is necessary at  to  hours: if improvement of symptoms is not seen, then expand antibiotic coverage to include periodontal flora or methicillin­resistant Staphylococcus aureus and consider aspiration of fluctuant nodes for culture. Most lymphadenopathy will improve after  weeks of observation or antibiotics; however, all cases require 6­week follow­up to ensure resolution.
FIGURE 125­1. Approach to the pediatric neck mass in the ED. ABC = airway, breathing, circulation.
INFLAMMATORY NECK MASSES
The most common pediatric neck mass is an enlarged lymph node caused by infection. Be careful to consider masquerading lesions such as salivary gland infections, acutely infected congenital lesions, and malignancies.
Cervical lymph nodes drain the skin of the head and neck as well as the entire nasal, oral, and pharyngeal mucosa (Figure 125­2). Enlarged
,4 submandibular and cervical nodes are most common because they drain much of the oropharynx, including the adenoids and tonsils.

Supraclavicular lymphadenopathy is suspicious for metastasis as these nodes drain the abdomen and thorax.
FIGURE 125­2. Cervical lymph node drainage.
,5,6
Palpable cervical lymph nodes are found in about 28% to 44% of healthy infants and children, with the incidence peaking in early childhood. Lymph nodes ≤1 cm in children <12 years old are considered normal. ,8 Most lymphadenopathy represents nonspecific reactive hyperplasia, often due to a
 viral upper respiratory tract infection. Lymphadenitis is lymph node inflammation (swelling, tenderness, warmth, erythema) and is most commonly due to viral or bacterial causes. Infection with a pyogenic organism may lead to liquefactive necrosis (suppuration) and abscess formation (Figure
125­3). If the immune system is unable to eradicate a particular organism, macrophages will attempt to contain it, forming a chronic granulomatous lymphadenitis.
FIGURE 125­3. Suppurative lymphadenitis. [Reproduced with permission from Shah BR, Lucchesi M, Amodio J (eds): Atlas of Pediatric Emergency Medicine, 2nd ed. ©
2013, McGraw­Hill Education, New York, NY, Figure 3­2.]
ACUTE BILATERAL LYMPHADENOPATHY
Acute bilateral lymphadenopathy is usually due to viral infection and is self­limited. Common viruses include rhinovirus, parainfluenza, influenza,
 respiratory syncytial virus, coronavirus, reovirus, and adenovirus. Treatment is symptomatic and expectant.
Alternative viral causes include infectious mononucleosis, characterized by fever, exudative pharyngitis, and significant lymphadenopathy (Figure
125­4). Heterophile antibodies or Epstein­Barr virus–specific immunoglobulin M confirms the diagnosis, and in immunocompetent patients, treatment is symptomatic. Some viral causes of lymphadenopathy are associated with classic exanthems such as measles (Koplik spots, conjunctivitis, and a descending rash) and rubella (Forchheimer spots, rash, and polyarthritis). Acute bilateral lymphadenopathy and oral lesions may also be due to herpes simplex virus (gingivostomatitis) or coxsackie virus (herpangina). Pharyngitis caused by group A Streptococcus is accompanied by cervical
 lymphadenopathy. Bilateral swelling that extends over the jaw suggests parotid gland involvement due to mumps and may be associated with orchitis and a rash.
FIGURE 125­4. Infectious mononucleosis typically presents with bilateral lymphadenopathy. A 6­year­old girl demonstrating bilateral lymphadenopathy. [Reproduced with permission from Shah BR, Lucchesi M: Atlas of Pediatric Emergency Medicine. © 2006, McGraw­Hill Education, New York, NY, Figure 11­14.]
ACUTE UNILATERAL LYMPHADENOPATHY

Acute unilateral lymphadenopathy is most often due to bacterial lymphadenitis (Figure 125­5) caused by S. aureus and group A Streptococcus.
Lymph nodes typically have signs of inflammation (erythema, warmth, tenderness), and if an abscess has developed, fluctuance may be appreciated.
Often the source of group A Streptococcus is the pharynx, whereas S. aureus originates from a break in the skin. Careful examination of the head, neck, throat, skin, and ears may identify a source that can be cultured.
FIGURE 125­5. An infant with unilateral lymphadenitis due to Staphylococcus aureus infection. [Photo contributed by Dr. J. P. Ludemann, BC Children’s Hospital,
Vancouver, British Columbia, Canada.]
Generally, lymph nodes <1 cm do not need treatment. If lymphadenitis measures between  and  cm, initiate antibiotics to treat group A

Streptococcus and Staphylococcus for up to  to  days. Nodes >3 cm raise suspicion for malignancy, but if the nodes are acute and inflammatory, a course of antibiotics and observation are reasonable.
,14,15
Due to increasing β­lactamase–resistant Staphylococcus, first­generation cephalosporins or amoxicillin­clavulanic acid are first­line choices,
 although clindamycin as a first­line agent is reasonable if local methicillin­resistant S. aureus prevalence is high. If the child is unwell or immunocompromised, use IV cefazolin, nafcillin, or clindamycin. All patients require reassessment in  hours, and if no improvement is appreciated, expand antibiotic coverage to treat methicillin­resistant S. aureus.Clindamycin and trimethoprim­sulfamethoxazole are both effective choices if local
16­18 resistance is low. Failure to improve at  hours is not an indication for surgical drainage as outcomes after switching to second­line antibiotics
 without surgery are similar.

Fluctuance of the node suggests abscess formation due to pyogenic bacteria, typically from a tonsillar source. While fluctuance is associated with a
 ,21 higher rate of surgical drainage, neck abscesses often respond to antibiotics alone. Needle aspiration may be helpful to avoid incision in
 cosmetically important areas. If a superficial abscess is pointing or not resolving within  weeks of antibiotics, then evaluation by US and incision and
 drainage may be necessary. Early US for inflammatory neck masses results in unnecessary cost and drainage, particularly in patients with less than 
 days of symptoms and who are older than  year of age. When associated with torticollis or trismus, consider a deep space infection and obtain imaging and/or surgical consultation (see Chapter 126, “Stridor and Drooling in Infants and Children”).
Infants have a higher incidence of infection with group B Streptococcus than S. aureus or group A Streptococcus. Group B streptococcal infection can
,25 be associated with bacteremia, pneumonia, and meningitis. Infections originating from the oral mucosa, seen most commonly in children age  to
 years with periodontal disease, are more likely to contain anaerobic bacteria requiring coverage with penicillin V, amoxicillin­clavulanic acid, or
 clindamycin. Sialadenitis is characterized by unilateral swelling crossing the jaw and tenderness after meals and can be associated with purulent discharge from Wharton’s and Stensen’s ducts (Figure 125­6). Sialolithiasis can cause recurrent infections due to outflow obstruction of the gland.
FIGURE 125­6. Sialadenitis. A. Unilateral swelling crossing the angle of the mandible. B and C. Purulent drainage from Stensen’s and Wharton’s salivary ducts, respectively. [Reproduced with permission from Knoop KJ, Stack LB, Storrow AB: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, Inc., New
York, Figures 5­32 and 5­33.]
SUBACUTE/CHRONIC LYMPHADENOPATHY
Chronic lymphadenopathy is defined as persistence for  weeks without resolution. Persistent lymphadenopathy, generalized lymphadenopathy, or failure to respond to  to  weeks of antibiotics requires evaluation for uncommon infectious, congenital, and neoplastic causes. Persistent infectious agents evade eradication by granuloma formation. Generally, the course of evolution is slower than with typical inflammatory lymphadenitis and may
26­28 be characterized by a violaceous color of the overlying skin. Refer to otolaryngology for definitive diagnosis and management. Refer immunocompromised patients to an infectious disease specialist. Some of the more common causes of granulomatous lymphadenitis are covered below.
MYCOBACTERIAL LYMPHADENITIS
Chronic cervical lymphadenitis may be due to tuberculous (Mycobacterium tuberculosis) or nontuberculous mycobacterial strains. Clinically, both varieties of lymphadenitis are characterized by a chronic, minimally tender, “cold abscess,” with overlying violaceous skin. Spontaneous drainage can
 transform into a chronic draining sinus. It is important to differentiate between tuberculous and nontuberculous strains because treatment is
 different. Differential Mantoux testing with a combination of antigens can identify strains in about 93% of patients. Consider M. tuberculosis
 lymphadenitis in children with tuberculosis exposure, in those exhibiting constitutional signs, and in those with an abnormal chest radiograph and
 with a strongly reactive purified protein derivative skin test, and treat for  to  months. Treatment for nontuberculous lymphadenitis is surgical
 excision.
CAT­SCRATCH DISEASE
Cat­scratch disease is caused by Bartonella henselae, with inoculation by a scratch or a bite from a kitten. The inoculation site develops into a painless, erythematous vesicle or pustule after  to  days, which may disappear before other symptoms develop. After  to  weeks, regional lymphadenopathy typically develops; suppuration is uncommon. Diagnosis involves serologic testing, but because antibody development may be delayed and the primary lesion may have resolved, rely on a strong history of cat exposure and an inoculating lesion. No treatment is needed due to
 high rates of spontaneous resolution, although azithromycin may hasten resolution. Serious complications (encephalitis) can develop in immunodeficient patients, with treatment options based primarily on case reports.
TOXOPLASMOSIS
Toxoplasma gondii is a protozoan parasite with a complex life cycle that can infect humans through ingestion of undercooked meat, exposure to oocysts in cat feces, or through maternal­fetal transmission (congenital toxoplasmosis). Infection is widespread: an estimated .5% of children in the
United States are infected by the age of  years old, and in some countries, up to 95% of the population has been infected. The lymphatic system is the most common organ system involved. Diagnosis is usually made serologically with antibody titers. Treatment is not typically needed in healthy children.
TULAREMIA
Tularemia is caused by the bacteria Francisella tularensis, which is transmitted by arthropod bites, handling infected animals (classically rabbits), and contaminated food and water. The most common forms are ulceroglandular and glandular tularemia. In the ulceroglandular form, the inoculation site develops from an erythematous tender papule into an exudative ulcer within days. Regionally draining lymphadenopathy subsequently develops that may spontaneously suppurate and drain if not treated. Tularemia is diagnosed serologically with microagglutination testing. Gentamicin is the treatment of choice.
OTHER CAUSES
Other causes of cervical lymphadenopathy include recent immunizations (diphtheria, pertussis, and tetanus; polio; typhoid), blood transfusions
(through Epstein­Barr virus, cytomegalovirus, or human immunodeficiency virus exposure), medications (including phenytoin, carbamazepine, isoniazid, and hydralazine), and systemic disease (Kawasaki’s disease; sarcoid; periodic fever, aphthous stomatitis, pharyngitis, and adenitis; and autoimmune) (Tables 125­1 and 125­2).
CONGENITAL NECK MASSES

Congenital lesions are the most common cause of noninflammatory pediatric neck masses, but may not be recognized until infection develops. The sternocleidomastoid muscle divides the neck into anterior and posterior triangles, and congenital neck masses can be organized into midline, anterior, and posterior groups (Table 125­3). The most common congenital neck masses and their characteristic features are discussed below.
TABLE 125­3
Common Congenital Neck Cysts by Location, Signs, and Typical Age of Onset
Type Location Signs Age
Thyroglossal duct Midline (infrahyoid mostly) Cyst moves with swallowing or tongue Birth–elderly protrusion.
Dermoid/epidermoid Midline (suprahyoid) Cyst may move with swallowing. Birth–adult
Branchial Anterior triangle anterior to sternocleidomastoid muscle near May be associated with draining sinus. Childhood– angle of the mandible adult
Lymphangioma (cystic Posterior triangle Soft; enlarges in first few weeks of life. Birth– hygroma) Transilluminates. infancy
THYROGLOSSAL DUCT CYSTS
Thyroglossal duct cysts (Figure 125­7) account for approximately 70% of congenital neck masses and are the second most common benign neck
 mass after lymphadenopathy. Thyroglossal duct cysts result from the persistence of any segment of the thyroglossal duct along its course from the
 foramen cecum of the tongue to the pyramidal lobe of the thyroid and are located in the midline of the neck within the anterior triangle. Most of the
,37 lesions are infrahyoid (65%), whereas suprahyoid cysts account for 20%, and another 15% of lesions are at the level of the hyoid bone. The pathognomonic feature is a painless fluctuant mass that moves with swallowing or protrusion of the tongue. Acutely infected cysts require antibiotics.

Further investigations and surgical excision are undertaken after infection subsides because they carry a very small risk of malignant transformation.
FIGURE 125­7. Large thyroglossal duct cyst.
DERMOID CYSTS
Dermoid cysts are developmental anomalies involving pluripotent embryonal stem cells and occur most often in children <3 years old. Dermoid cysts
 ,41 are usually suprahyoid and midline and are often misdiagnosed as thyroglossal duct cysts. Dermoid cysts are mobile, but they do not move with tongue protrusion. Management is surgical excision.
BRANCHIAL CLEFT CYSTS

Incomplete obliteration of the branchial apparatus, predominantly the cleft, leads to branchial cleft anomalies: cysts, sinuses, or fistulae. Up to 95%
 of branchial cleft cysts arise from remnants of the second branchial cleft, which are most often anterior to the sternocleidomastoid muscle near the angle of the mandible (Figure 125­8). The cysts are round, smooth, and mobile, but are not tender unless they become infected. There may be a history of recurrent swelling or infection in the same area. Cysts may spontaneously rupture, forming an external sinus or fistula. Oral antibiotics are indicated for infected cysts prior to definitive surgery.
FIGURE 125­8. Second arch branchial cleft cyst. [Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 4th ed. ©
2016. McGraw­Hill, Inc., New York, Figure 14­69, p. 469. (Photo contributor: Scott Manning, MD.)]
LYMPHANGIOMAS
Lymphangiomas (also known as cystic hygromas) result from sequestration of lymphatic channels that fail to communicate with the internal jugular
 vein leading to a blockage of the lymphatic system. They can occur anywhere in the body, but nearly 75% arise within the neck, most commonly along the jugular chain of lymphatics. Cervical lymphangiomas are soft, painless, and compressible, and can be very large (Figure 125­9). Morbidity is usually secondary to compression of surrounding structures, and large neck lesions may cause serious airway and feeding problems. Sixty­five
,43 percent present at birth, and 90% are clinically detected by the end of the second year. Sudden enlargement can occur from infection or hemorrhage into the lesion. Careful inspection of the oral cavity and palpation of the trachea for deviation are important in assessing the airway of
 patients with large cystic hygromas. Injection of sclerosing agents can be used in some lesions, although surgical excision is the definitive treatment.
FIGURE 125­9. Lymphangioma. [Reproduced with permission from Knoop KJ, Stack LB, Storrow AB, Thurman RJ: Atlas of Emergency Medicine, 2nd ed. © 2002,
McGraw­Hill, Inc., New York, Figure 14­35.]
NEOPLASTIC NECK MASSES
Malignancy must always be considered as a potential etiology in the evaluation of a child with a neck mass (see Chapter 145, “Oncologic Emergencies in
,44­47
Infants and Children”). Of childhood malignancies, 5% to 12% present as a head or neck mass, of which 99% are primary tumors. Diagnosing
 malignancies is made challenging by their rarity; only 1% of pediatric superficial lumps are malignant. Accordingly, a high index of suspicion and
,31,46­50 attention to worrisome features from history and physical examination are required (Table 125­4). One review demonstrated that in 80% of
 superficial masses, malignancy can be ruled out with .7% accuracy based on the absence of five clinical features (Table 125­4). The presence of any worrying features should prompt urgent referral for further diagnostic workup that may include fine­needle aspiration cytology, imaging, or excisional biopsy.
TABLE 125­4
Worrisome Features of Head and Neck Masses
Constitutional symptoms (fever, weight loss, night sweats, fatigue)
History of malignancy
Mass features (onset in the neonatal period*; size >3 cm; duration >4–6 wk; supraclavicular, posterior, or midline location; rapid and progressive enlargement*; hard or rubbery consistency; fixation to skin or deep fascia*; associated skin ulceration*)
Generalized lymphadenopathy
Inflammatory mass >3 cm persistent for >6 wk, despite treatment
Mass >3 cm with firm or hard consistency* *If these five features are absent, then there is .7% accuracy that a superficial lump is not malignant in 80% of cases.41
BENIGN NEOPLASMS

Benign noninflammatory pediatric neck masses compose 5% of presentations. An exhaustive review is not included in this chapter; instead, benign masses with specific identifying features are highlighted.
HEMANGIOMAS
Hemangiomas are congenital vascular tumors that present at  to  weeks, usually grow rapidly until  to  months of age, and typically regress
 thereafter. When palpable, they are soft, mobile, and frequently have a bluish hue. Almost 90% of hemangiomas resolve spontaneously without the need for therapy. Lesions showing unusually rapid growth, hemorrhage, recurrent infection, or compression of adjacent structures may require treatment by a specialist, including beta­blockers, steroids, and laser or surgical excision. Hemangiomas compromising the airway result in biphasic stridor not responsive to nebulized epinephrine and may be associated with cutaneous lesions in a beard distribution.
NEUROFIBROMAS AND SCHWANNOMAS
Neurofibromas and schwannomas are rare usually large tumors often involving the orbits, the skull base, or the parotid region, and are frequently
 associated with neurofibromatosis type I, which may present with café­au­lait spots and other classic features.
FIBROMATOSIS COLLI
Fibromatosis colli (also known as pseudotumor of infancy) presents in the neonatal period as a mass in the sternocleidomastoid muscle (Figure 125­
,53
10). Often due to birth trauma with forceps delivery, part of the involved muscle is replaced by dense fibrous tissue. Parents will often notice a mass or limited range of motion of the neonate’s neck in the first weeks of life. Physical examination reveals a firm, solid, immobile mass located within the sternocleidomastoid muscle that is horizontally mobile, vertically fixed, and moves with the muscle when the head is turned. It is often associated with some degree of sternocleidomastoid contracture (torticollis). The diagnosis can often be made clinically, and imaging is not necessary. Treatment
,51,53 involves stretching and physical therapy, resulting in spontaneous resolution over a period of  to  months.
FIGURE 125­10. Schematic of fibromatosis colli or pseudotumor of infancy.
MALIGNANT NEOPLASMS
Malignant head and neck masses are rare, accounting for approximately 1% of all etiologies. However, assessment for worrying features is important in the ED (Table 125­4); management of a suspected malignant lesion should include urgent referral for definitive treatment. The more common childhood malignancies presenting as a neck mass are highlighted briefly (see also Chapter 145).
LYMPHOMA
,46,51
Lymphoma is the most common childhood malignancy of the head and neck. Most lymphomas present as a large, firm mass that is often mobile,
,44,46,54,55 but can be fixed and is commonly located in the anterior triangle or the supraclavicular area. One study found that 35% of childhood head
 and neck lymphomas presented as a supraclavicular mass. Hodgkin’s lymphoma is more likely nodal, is more often found in the supraclavicular area, and is seen more often in teenagers, whereas non­Hodgkin’s lymphoma is primarily extranodal and has increasing incidence with age. Diagnosis requires excisional biopsy. Do not give steroids before biopsy because steroids interfere with staging.
RHABDOMYOSARCOMA
Rhabdomyosarcoma is a frequent malignancy of the head and neck in children. This tumor presents in the neck in 40% of cases, often as a large
,45,56 painless mass, rarely causing compression or infiltration of adjacent structures, most notably the airway. Peak incidence is at  to  years old and again at  to  years old. Neck tumors may present with brachial plexus palsy.
NEUROBLASTOMA
,57
Neuroblastoma in the neck is a malignancy of the sympathetic chain, although the adrenal glands are the most common primary site. Most present
,58 before the age of  years, and those arising in the neck (5%) have a better prognosis than tumors of adrenal origin. Neuroblastoma may present with local compressive signs such as hoarseness, dysphagia, airway obstruction, Horner’s syndrome, or cranial nerve palsies.
THYROID CANCER

Thyroid cancer accounts for 21% of pediatric head and neck cancers; however, its incidence is decreasing due to declining radiation exposure.
Childhood thyroid cancer is usually papillary, presenting at a more advanced stage, with node, muscle, and metastatic involvement in 90% of cases;
 despite its advanced presentation, the prognosis is better than adult thyroid cancer. Benign causes of diffuse thyroid enlargement include
 symptomatic thyrotoxicosis or Hashimoto’s thyroiditis, although goiter is seen in some parts of the world.
METASTATIC DISEASE
Metastatic disease may also present as cervical lymphadenopathy, accounting for 1% of childhood head and neck cancers. Tumors that metastasize to the neck include nasopharyngeal carcinoma and some thoracic/GI tumors. The location of the metastasis may give a hint to the origin of the primary tumor: posterior triangle nodes are often seen in nasopharyngeal carcinoma, whereas isolated supraclavicular nodes suggest a mediastinal or abdominal mass.


