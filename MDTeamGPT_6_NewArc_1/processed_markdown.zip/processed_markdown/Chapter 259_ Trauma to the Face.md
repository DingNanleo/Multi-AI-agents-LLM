## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 259: Trauma to the Face
Tarlan Hedayati; Dhara P. Amin
INTRODUCTION AND EPIDEMIOLOGY
Assaults, motor vehicle crashes, falls, sports, and gunshot wounds account for the majority of facial fractures (in descending order of incidence), with
 motor vehicle crashes and gunshot wounds resulting in a higher severity of injury. The lack of a seat belt or air bag increases the risk of facial fractures
 and panfacial fracture. The most common fractures are to the nasal bone, followed by orbital floor, zygomaticomaxillary, maxillary sinuses, and
 mandibular ramus. Mechanisms and injury patterns vary with geography. In the urban setting, penetrating trauma and assaults result in midface and zygomatic fractures. In the rural setting, motor vehicle crashes and recreational injuries result in fractures of the mandible and nose. Males are more frequently affected than females, but domestic violence and elder and child abuse must always be considered in any patient presenting with facial
,4 trauma. The majority of abused women and children will have injuries to the head, face, and neck.
PATHOPHYSIOLOGY
The facial skeleton is designed to create effective mastication. Vertical and horizontal buttresses are formed by bony arches joined at suture lines.
Stronger vertical buttresses are formed by the zygomaticomaxillary buttress laterally and the frontal process of the maxilla medially. Weaker horizontal buttresses are formed by the superior orbital rims, orbital floor, and hard palate. The orbit itself is comprised of seven different bones, with the inferior and medial walls being particularly fragile. Therefore, frontal, lateral, and oblique forces often result in facial fractures.

The identification of facial injury and the restoration of normal appearance, sight, mastication, smell, and sensation are all essential tasks, but the principal focus should be on protecting the patient’s airway during the primary survey and the other initial considerations described in Table 259­1. TABLE 259­1
Initial Considerations in Facial Trauma
Primary survey
Airway—endotracheal intubation for mechanical disruption or severe hemorrhage.
Circulation—early packing of nasal and oral cavity. Apply direct pressure to external wounds. Avoid blind clamping.
Evaluate and manage emergent life­threatening conditions before facial injuries.
Secondary survey
Early meticulous facial and ocular examinations.
History
Mechanism predicts severity of facial and associated brain, cervical spine, and pulmonary injury.
Screen for abuse, especially in women, children, and elders.
Up to 44% of patients with severe maxillofacial trauma require endotracheal intubation due to mechanical disruption or massive hemorrhage into the
 airway. The incidence of associated injury to the brain, orbit, cervical spine, and lungs is directly related to the mechanism of injury and severity of
6­8 facial fractures. Evaluate facial injuries as part of the secondary survey only after managing life­threatening injuries. Because up to 6% of patients with maxillofacial trauma will develop vision loss, a detailed eye examination is essential, especially in patients with high­energy mechanisms, orbital fDraocwtunrloeas,d seigdn 2if0ic2a5n­7t ­h1e a8d:4 i8n jPu r yY, oaunrd I aPb inso 1r3m6a.1l p4u2p.1il5la9r.y1 2fi7ndings. ,9
Chapter 259: Trauma to the Face, Tarlan Hedayati; Dhara P. Amin 
. Terms of Use * Privacy Policy * Notice * Accessibility
CLINICAL FEATURES
The mechanism of injury helps estimate the extent of injury. Exact details of motor vehicle crashes and assaults are often incomplete due to associated traumatic brain injury, intoxication, or other factors. Always address the possibility of abuse. When reported mechanisms do not match the injury, ask patients, especially women and the elderly, about interpersonal violence. Contact pediatricians and local child protective services when considering child abuse. It is better to report all suspected abuse than allow violence to continue and escalate. Obtain history of allergies, medications (especially cardiovascular and antithrombotic agents), comorbidities, tetanus immunization status, and time of last meal from the trauma patient or other available sources.
The secondary survey begins with three screening questions to help localize injuries while simultaneously examining the patient from the upper to the lower face. Important clinical findings in facial trauma are presented in Table 259­2. TABLE 259­2
Important Clinical Issues in Facial Trauma
History
How is your vision?
Do any parts of your face feel numb?
Does your bite feel normal?
Inspection
Lateral view for dish face with Le Fort III fractures.
Frontal view for donkey face with Le Fort II or III fractures.
Bird’s eye view for exophthalmos with retrobulbar hematoma.
Worm’s view for enophthalmos with blow­out fractures or flattening of malar prominence with zygomatic arch fractures.
Raccoon eyes (bilateral orbital ecchymosis) and Battle’s sign (mastoid ecchymosis) typically develop over several hours, suggesting basilar skull fracture.
Palpation
Palpating the entire face will detect the majority of fractures.
Intraoral palpation of the zygomatic arch, palpating lateral to posterior maxillary molars to distinguish bony from soft tissue injury.
Assess for Le Fort fractures by gently rocking the hard palate with one hand while stabilizing the forehead with the other.
Eye
Examine early before swelling of lids, or use retractors. Document visual acuity. Systematically examine the eye from front to back. Specifically, check the pupil for teardrop sign pointing to globe rupture; hyphema; and swinging flashlight test for afferent papillary defect.
Fat through wound indicates orbital septal perforation.
Check intraocular pressure for evidence of orbital compartment syndrome only in absence of globe injury.
Nose
Crepitus over any facial sinus suggests sinus fracture.
Nasal septal hematoma appears as blue, boggy swelling on nasal septum.
Cerebrospinal fluid leak.
Ears
Auricular hematoma.
Hemotympanum.
Cerebrospinal fluid leak.
Oral
Jaw deviation due to mandible dislocation or condyle fracture. Malocclusion occurs in mandible, zygomatic, and Le Fort fractures.
Missing or injured tooth.
Lacerations and mucosal ecchymosis suggest mandible fracture.
Place finger in external ear while the patient gently opens and closes jaw to detect condyle fractures.
Tongue blade test: Patient without fracture can bite down on a tongue blade enough to break blade twisted by examiner.
(1) How is your vision? Any patient with visual complaints or evidence of periorbital injury requires a thorough eye examination. (2) Is your face numb?
Ask this question while checking for anesthesia of the forehead, lower eyelid, cheek and upper lip, or chin, suggesting injury to the supraorbital, infraorbital, or mental nerves. (3) Do your teeth fit together normally? Malocclusion typically occurs in patients with mandibular or maxillary fractures.
Pain and tenderness near the ear indicate mandibular condyle injury. With zygomaticomaxillary complex fractures, patients often report pain over the cheek and trismus from masseter spasm or mechanical impingement of either the temporalis muscle or coronoid process of the mandible.
Inspect the face from the front, sides, feet, and above to detect subtle asymmetry in facial structure from zygomatic, orbital, and Le Fort injuries
(Figures 259­1, 259­2, 259­3). Palpate the entire orbital rim for tenderness and step­off deformities, which suggest fracture, and for crepitus, which suggests sinus involvement.
FIGURE 259­1. Zygomatic arch fracture. Note flattening of the right malar eminence on bird’s eye. [Reproduced with permission from Knoop K, Stack L, Storrow A,
Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, New York.]
FIGURE 259­2. Traumatic exophthalmos. Note significant right exophthalmos on bird’s eye view due to retrobulbar hematoma. [Reproduced with permission from
Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, New York.]
FIGURE 259­3. Le Fort III fracture has a classic dish face deformity on lateral view. [Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, New York.]
Examine the eyes before significant swelling occurs, or use lid retractors to better inspect the globe. Begin with corrected visual acuity using a wall, pocket, or phone app Snellen eye chart, name tag, or finger counting. In patients with loss of visual acuity, note light perception and color perception.
Loss of vision implies injury to the optic nerve or globe. Subconjunctival hemorrhage and bloody chemosis occur with orbital fractures.
Assess extraocular motion and pupils. Binocular double vision suggests entrapment of the extraocular muscles, whereas monocular double vision suggests lens dislocation. Limitation on upward gaze occurs with fractures of the inferior and medial orbital wall from entrapment or injury to the inferior rectus, inferior oblique, or oculomotor nerve (Figure 259­4). Examine the pupils for shape, position, symmetry, and reactivity.
Teardrop­shaped pupil indicates globe injury. Note the distance between the medial canthi; normal is the width of the patient’s globe. Telecanthus, widening of this distance with normal interpupillary distance, occurs with naso­orbito­ethmoid injuries. Widening of the interpupillary distance, or hypertelorism, results from a “blow­out” injury to the orbits, often resulting in blindness.
FIGURE 259­4. Orbital blow­out fracture causes limitation of upward gaze due to entrapment of inferior rectus.
Check the swinging flashlight test for evidence of an afferent papillary defect (Marcus Gunn pupil) (see Chapter 241, “Eye Emergencies”). With normal function, the swinging light results in brief dilation during movement followed by constriction when the light is directly over the eye. With injury to the optic nerve or retina, the affected pupil will not constrict until the light is again moved to the unaffected eye. The test is sensitive but not specific for optic nerve injury, because an afferent papillary defect may result from pathology anywhere along the visual pathway.
Finish the physical examination of the eye by completing funduscopic, slit­lamp, and fluorescein examinations, as well as checking intraocular pressures when indicated. Flashes of light and floaters may be reported in patients with retinal detachments and vitreous hemorrhage. Foreign­body sensation and photophobia suggest corneal abrasions. Check for hyphema after having the patient sit upright for several minutes. In patients without evidence of globe rupture, check intraocular pressure in patients with significant exophthalmos, afferent nerve defects, or other evidence of retrobulbar hematoma.
Check carefully for globe injury with any penetrating injury to the periorbital area. Consult ophthalmology for suspected hyphema or vitreous hemorrhage. Fat herniating through the wound suggests an injury through the orbital septum. Through­and­through injuries, tarsal plate injuries, and injuries to the medial quadrant involving the lacrimal duct require repair by an ophthalmologist.
Begin the examination of the nose by checking for deformity from multiple angles while asking the patient about prior nose injury. Check for tenderness, crepitus, septal hematoma, and cerebrospinal fluid rhinorrhea. A septal hematoma appears as a blue, boggy, and tender area of swelling along the nasal septum (Figure 259­5). Incision and evacuation are required to prevent destruction of cartilage resulting in a saddle nose deformity.
Ensure that simple nasal fractures are not associated with complex naso­orbito­ethmoid injuries. Perform the bimanual nasal palpation test with tenderness over the medial canthus. Begin by anesthetizing the nose. Then insert a cotton tip applicator inside the nose along the lateral nasal wall to the area behind the medial orbital wall and canthus. Palpate the area of the medial canthus externally with the opposite hand to check for movement from fracture of the medial wall of the orbit. Obtain a CT scan for suspected injury to the medial canthus or when telecanthus is present. Isolated nasal fractures and septal hematoma evacuation are reviewed in Chapter 244, “Nose and Sinuses.”
FIGURE 259­5. Septal hematoma presenting as a grapelike mass on left nasal septum. [Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ:
Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, New York.]
Classic tests for cerebrospinal fluid rhinorrhea are not accurate in distinguishing cerebrospinal fluid from serous nasal discharge in the presence of nasal bleeding. The double ring or halo sign occurs when clear cerebrospinal fluid diffuses past blood when dropped on a paper towel, but is not sensitive or specific for cerebrospinal fluid leak. Trauma­related serous nasal discharge will also diffuse past blood. The glucose test is likewise not reliable. Nasal discharge does not contain glucose, whereas cerebrospinal fluid does. Bleeding may create a false­positive glucose test. Assays of
 serum beta­2 transferrin from the drainage are highly sensitive and specific for cerebrospinal fluid leakage.
Begin the inspection of the ear by checking the mastoid process for Battle’s sign (suggesting a basilar skull fracture) and the ear for auricular hematoma. Incision and drainage are required to prevent destruction of cartilage resulting in a cauliflower deformity. Traumatic injury to the ear, including auricular hematoma evacuation, is reviewed in Chapter 242, “Ear Disorders.” Check the external auditory canal for lacerations, cerebrospinal fluid leak (temporal bone or middle cranial fossa injury), and hematotympanum (a purple and often bulging tympanic membrane). Insert a finger into the external auditory canal and ask the patient to gently open and close the mouth to check for a mandibular condyle fracture.
Inspect the jaw for deviation resulting from a fracture or dislocation. Malocclusion occurs in mandibular fractures, Le Fort fractures, and zygomatic fractures. Check the mouth carefully for missing or subluxed teeth, fractures of the alveolar ridge, sublingual hematoma, or breaks in the oral mucosa
(Figure 259­6). Be sure to inspect the tongue for lacerations that may result in significant swelling later on. The tongue blade test has been reported
11­13 to be 96% sensitive in identifying clinically significant mandibular fracture injuries in facial trauma patients. The patient without a mandible fracture bites down forcefully enough on a tongue blade to allow the physician to snap the tongue blade with a twisting motion. Patients who open the mouth and cannot break the blade require further imaging. The tongue blade test is best used in conjunction with other clinical findings because test
 sensitivity may be as low as 85%.
FIGURE 259­6. Open mandible fracture with a fracture line through gingiva into oral cavity. [Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman
RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, New York.]
DIAGNOSIS
IMAGING
Noncontrast CT is the imaging modality of choice. Plain radiographs remain helpful when CT is not available or to exclude injury in the low­risk patient.
Recommendations for imaging based on level of injury and clinical findings are summarized in Table 259­3. TABLE 259­3
Recommendations for Imaging Based on Level of Injury and Clinical Findings
Level Low Suspicion Significant Clinical Findings Additional Considerations
Frontal Head CT Head CT (skull windows) Facial CT with orbital involvement.
bone Cervical spine CT with significant clinical findings.
Midface Waters’ view Face CT with coronal and axial sections; head CT as strong Coronal face sections require cervical spine clearance force causes midface fractures for positioning.
Computer­generated, three­dimensional reconstructions with complex injuries.
Head CT can replace Waters’ view.
Mandible Panorex Mandible CT Facial CT detects mandible fractures.
(orthopantomogram)
Subtle fractures of the frontal bone require head CT with bone windows for optimal evaluation. Because fracture of the frontal bones requires a significant force, head CT is also required to evaluate for associated traumatic brain injury. With involvement of the supraorbital ridge, include a facial
CT with axial and coronal sections to better define often complex orbital fracture anatomy.
,15
The Waters’ view safely replaces the multiple views in traditional facial series for midfacial fractures. One study suggested that at least two views be
 obtained due to recalculated sensitivities as low as 87% and the lack of comparison of the Waters’ view to CT. Not included in this analysis was a study
 of 730 patients demonstrating a sensitivity of 100% for Waters’ view read by emergency physicians versus facial series read by specialists.
Head CT has been reported to be 90% sensitive in excluding injury found on facial CT. An additional Waters’ view is unnecessary with a low
 clinical suspicion for facial fracture in patients undergoing a head CT for suspected traumatic brain injury. Using this strategy avoids additional radiation from unnecessary Waters’ view or facial CT and prevents additional trips to CT after cervical spine clearance required for facial CT coronal positioning.
Facial CT with coronal and axial sections is the imaging study of choice for patients with an abnormal Waters’ view or as the initial study with significant
 clinical findings. Multiplanar computer reconstructions increase the effectiveness of visualization of fractures, especially in the case of fractures in
 the inferior orbital wall.
Head and cervical spine CT scans are recommended in addition to facial CT in patients with high­energy mechanisms or significant clinical findings.
Panorex (orthopantomogram) remains the imaging study of choice for mandible fractures. However, mandible CT is 92% to 100% sensitive for detecting injury compared with 70% to 86% for Panorex in adults and children and has become the “gold standard” for diagnosing mandible
,21  fractures. Mandible CT is easier to interpret with less interphysician variability compared with Panorex. Mandible CT scans may miss fractures of
 the dental root. Panorex is not often available in the ED, requires an upright patient, and may miss mandibular condyle fractures. Mandible CT is recommended in patients requiring head CT to evaluate for traumatic brain injury or when a Panorex is not available. The traditional mandible series
(including posterior­anterior, Towne’s view, and lateral oblique view) remains an option when Panorex and CT are not available.
TREATMENT
AIRWAY MANAGEMENT
During the primary survey of facial trauma patients, aggressively protect the airway from hemorrhage and mechanical obstruction.
Significant hemorrhage into the airway can result from mandible and midfacial fractures. Loss of mechanical support resulting in airway obstruction can occur with bilateral posterior mandible fractures. Significant edema of the soft palate may result from midfacial injuries. Furthermore, the patient is often unable to maintain the damaged airway due to concomitant traumatic brain injury, intoxication, or other life­threatening injuries.
Reposition the airway as needed with a jaw thrust or head tilt and chin lift after cervical spine clearance. Grasp an obstructing tongue with gauze, a towel clip, or suture, to pull anteriorly and out of the airway with mandible fractures. Remove avulsed teeth and foreign bodies. Use nasal trumpets very carefully to avoid worsening of the injury or intracranial placement in severe midfacial injuries. Bag­mask ventilation often requires a two­person technique because of loss of normal facial bony structures and the need to suction the airway secondary to significant hemorrhage. When the cervical spine has been clinically cleared, allow the alert patient without significant associated injury to remain in an upright position of comfort, with suction in hand, to better handle bleeding and secretions.
Each patient’s unique clinical presentation and the physician’s experience dictate the best method for establishing a definitive airway. Rapid­sequence intubation is the preferred method of airway management in trauma. The presence of mandible fractures occasionally makes intubation easier than expected. However, always plan for the difficult airway in patients with facial trauma. To prevent the “can’t intubate/can’t oxygenate” failed airway, do not administer paralytics unless a patient can be bagged effectively or alternative airway devices or plans are in place.
Awake intubation with sedation and local airway anesthesia may allow the emergency physician to quickly determine how difficult orotracheal
 intubation will be while preserving airway reflexes. Etomidate and ketamine both provide sedation with preservation of respiratory drive. When oral endotracheal intubation appears more straightforward than expected on direct laryngoscopy, the endotracheal tube may be placed or paralytics administered followed by orotracheal intubation. When endotracheal intubation appears more difficult or impossible, primary cricothyrotomy or alternative airway management techniques may be performed (see Chapter , “Basic Cardiopulmonary Resuscitation,” Chapter 108, “Resuscitation of
Neonates,” and Chapter 109, “Resuscitation of Children”).
The best approach to the difficult trauma airway involves planning ahead by having equipment ready for oral endotracheal intubation as well as the neck prepared and a cricothyrotomy kit ready. A laryngeal mask airway device may be a temporizing measure, but does not protect the airway from aspiration of stomach contents and may not be possible with injuries involving the pharynx. Fiberoptic devices are an excellent option in the rare case when time, a lack of significant hemorrhage, and an experienced operator are present. Avoid nasal intubation to prevent worsening of injury,
 hemorrhage, or intracranial placement.
HEMORRHAGE
Significant hemorrhage with severe midfacial or mandible injury can obstruct the airway and make attempts at intubation difficult. The blood supply to the face originates primarily from the sphenopalatine and greater palatine branches of the external carotid artery. Extensive anastomoses occur in the nasal cavity with the anterior and posterior ethmoidal branches of the internal carotid artery. Control posterior nasal epistaxis early with nasal tampon, dual balloon device, or traditional Foley catheter placement with anterior layered gauze packing. Be careful to avoid intracranial placement of nasal packing in severe midfacial fractures. After intubation, oral packing may be needed in a patient with significant mid­ and lower­facial bleeding.
Reduction of significantly displaced nasal fractures and Le Fort injuries may be needed (although rarely) to stop arterial bleeding. Life­threatening
 hemorrhage can occur in up to 10% of patients with midface fractures. With significant persistent bleeding, immediate operative intervention is required for ligation of injured vessels or better reduction of fractures. Arterial embolization may also be effective in controlling bleeding from
 branches of the external carotid artery, but is associated with a small risk of stroke and other complications. To date, there are no reports describing the use of tranexamic acid for control of massive bleeding from facial injury in the ED.
SPECIFIC FACIAL FRACTURES
FRONTAL BONE FRACTURES
Frontal bone fractures are uncommon injuries resulting from high­energy mechanisms such as unrestrained motor vehicle crashes or assaults with blunt objects. The significant amount of force needed to fracture the thick frontal bone likewise increases the immediate risk of traumatic brain injury, additional facial fractures, and cervical spine injury. Concomitant craniofacial injuries are present in 56% to 87% of patients with frontal sinus
 fractures. Severe frontal fractures may extend to the temporal bones and require a hearing and facial nerve function evaluation. Otorrhea in this
 setting is a cerebrospinal fluid leak until proven otherwise. Ocular injuries can occur in up to 25% of patients with frontal bone fractures. The most
 common finding is an afferent pupillary defect, occurring in about 10% of patients.
Lacerations typically overlie frontal sinus fractures. Careful exploration is needed to identify all fractures. Crepitus is frequently palpable with any sinus fracture. In cases of suspected fracture, obtain a head CT to evaluate the anterior and posterior tables as well as the underlying intracranial structures
(Figures 259­7 and 259­8).
FIGURE 259­7. Forehead laceration overlying a frontal sinus fracture. [Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of
Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, New York.]
FIGURE 259­8. Frontal sinus fracture from patient in Figure 259­7. CT demonstrating fracture of the anterior table of the frontal sinus. [Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, New York.]
Because the dura is adherent to the posterior table, operative repair of through­and­through frontal sinus fractures is necessary to prevent pneumocephalus, cerebrospinal fluid leak, and infection. Consider rhinorrhea in any patient with a frontal bone fracture to be a cerebrospinal fluid
 leak until proven otherwise. Mucopyoceles, collections of pus that develop as a result of nasal ducts blocked by fracture, and cranial empyema can result. Oral antibiotics, such as first­generation cephalosporins or amoxicillin clavulanate, are recommended with any sinus fracture. The patient with an isolated anterior table fracture may be discharged with nasal and oral decongestants and appropriate follow­up with a facial surgeon
(otolaryngologist, plastic surgeon, or ophthalmology). Admit patients with depressed fractures for IV antibiotics and operative repair.
ORBITAL FRACTURES
The orbit is traditionally thought of as a four­walled structure. It is made up of the frontal bone superiorly, the zygoma and sphenoid bones laterally, the zygoma and maxilla inferiorly, and the thin­walled lamina papyracea of the ethmoid bone medially. There are two categories of orbital fractures: pure, blow­out fractures and unpure, orbital fractures. The pure orbital blow­out fracture involves only the orbital walls and occurs when an object of small diameter strikes the globe without causing an orbital ridge or rim fracture. Force transmitted through the fluid­filled globe results in a fracture of the weaker inferior or medial orbital walls. Adipose tissue, the inferior rectus, or the inferior oblique can then herniate and become entrapped within the maxillary or ethmoid sinus (Figure 259­9). Lateral, inferior, and superior orbital ridge fractures typically occur with other facial fractures. See
Chapter 241, “Eye Emergencies,” for further discussion of orbital fractures and ocular injuries. Significant force applied to the nasal bridge can result in naso­orbito­ethmoid fractures that are often accompanied by injury to the lacrimal duct, dural tears, and traumatic brain injury.
FIGURE 259­9. Blow­out fracture findings, including fluid in the maxillary sinus, herniated fat or muscle, and delayed enophthalmos, occur with orbital floor fracture.
[Reproduced with permission from Scaletta TA, Schaider JJ: Emergency Management of Trauma, 2nd ed. © 2001, McGraw­Hill, Inc., New York.]
Several key physical examination findings suggest orbital fracture. Enophthalmos occurs with herniation of globe contents before significant edema.
Carefully palpate the entire orbital rim to detect any step­off deformity or crepitus. Infraorbital anesthesia often occurs with fracture of the orbital floor. Diplopia on upward gaze occurs with entrapment of the inferior rectus, inferior oblique, or orbital fat, or from injury of muscles or the oculomotor nerve. Naso­orbito­ethmoid fractures result in pain on eye movement, traumatic telecanthus, epiphora (tears spilling over the lower lid),
 and cerebrospinal fluid leak.
Radiographic findings consistent with orbital fracture are seen in Figure 259­10. Additional findings include air­fluid levels or opacification of the maxillary sinus. Obtain a facial or orbital CT with axial and coronal sections to plan surgical management in patients with positive findings on a Waters’ view or as the initial study in patients with significant clinical findings (Figure 259­11).
FIGURE 259­10. Blow­out fracture. Waters’ view with teardrop sign (arrow) and fluid in right maxillary sinus (arrowhead). [Reproduced with permission from Knoop K,
Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, New York.]
FIGURE 259­11. Left zygomatic maxillary complex and right blow­out fractures. Disruption of zygomatic frontal suture and maxillary sinus on left (arrowheads) with herniation of orbital contents into maxillary sinus on the right (arrow) on face CT coronal section.
The patient with an isolated orbital fracture requires treatment with oral amoxicillin­clavulanate to treat sinus pathogens, decongestants, and instructions to avoid nose blowing until the defect has been repaired. Specialty consultation before discharge is important because controversy continues regarding the best time and indications for operative repair. Repair may be delayed  to  weeks in adults, whereas children require a shorter time for follow­up and repair. Naso­orbito­ethmoid fractures require admission for specialty consultation with facial surgery and neurosurgery.
Emergent ophthalmology consultation is required for associated ocular injury. Retrobulbar hematoma or malignant orbital emphysema may create an ocular compartment syndrome, resulting in an acute ischemic optic neuropathy (Figure 259­12). Physical examination findings include exophthalmos, decreasing visual acuity, and increased intraocular pressure. Emergency lateral canthotomy reduces ocular pressure and ischemia. Orbital fissure syndrome results from a fracture of the orbit involving the superior orbital fissure with injury to the oculomotor and ophthalmic divisions of the trigeminal nerve. Physical examination findings include paralysis of extraocular motions, ptosis, and periorbital anesthesia. Orbital apex syndrome occurs when the optic nerve is also involved, resulting in the preceding physical examination findings and diminished visual acuity.
FIGURE 259­12. Retrobulbar hematoma. CT of patient in Figure 259­2 demonstrates right retrobulbar hematoma. [Reproduced with permission from Knoop K, Stack L,
Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, New York.]
ZYGOMA FRACTURES
The prominent location of the zygoma results in frequent fractures. Zygomatic arch fractures occur when an anterior and lateral force is applied typically from a fist or blunt object. The less common zygomaticomaxillary (or “tripod”) fracture results classically from a high­energy deceleration injury with disruption of the zygomaticofrontal suture, zygomaticotemporal junction, and infraorbital rim (Figures
259­13). Because the zygoma forms the inferior and lateral walls of the orbit and superior and lateral roof of the maxillary sinus, zygomaticomaxillary fractures are considered orbital and sinus fractures.
FIGURE 259­13. Tripod fracture locations. Zygomatic arch fracture (1), lateral orbital rim fracture (2), inferior orbital rim fracture (3), and lateral wall of maxillary sinus fracture (4). [Reproduced with permission from Schwartz DT: Emergency Radiology: Case Studies. © 2008, McGraw­Hill, New York.]
On physical examination, flattening of the malar eminence will be noted in the absence of often significant swelling (Figure 259­1). The eye may appear to tilt as the lateral canthus is pulled inferiorly, often with a large lateral subconjunctival hemorrhage. Trismus results from masseter spasm or mechanical impingement of either the temporalis muscle or coronoid process of the mandible. Place a finger adjacent to the maxillary molars and palpate the posterior surface of the arch for tenderness or loss of the space compared to the uninjured side. Diplopia, infraorbital anesthesia, and crepitus occur with significant orbital and sinus involvement. Facial CT is needed to define the extent of the injury.
Patients with isolated temporal arch fractures can be discharged with appropriate medications and follow­up. Patients with zygomaticomaxillary fractures with any loss of vision or significant displacement require admission for IV antibiotics and operative repair.
MIDFACIAL FRACTURES
Midfacial fractures can be caused by motor vehicle crashes, sports, assault, and falls due to seizures or intoxication or in the elderly. The incidence of
 midfacial fractures in motor vehicle crashes has declined significantly due to improvements in vehicle restraint systems. Fractures of the maxilla require a significant force such as an unrestrained motor vehicle crash patient whose face strikes the dashboard or the severely battered patient.
Le Fort injuries often present dramatically, with significant hemorrhage, early swelling, bilateral orbital ecchymosis, and cerebrospinal fluid leaks in Le
Fort II and III injuries. Each pattern results in a unique movement of the midface while gently rocking the hard palate with one hand and stabilizing the forehead with the other hand (Figure 259­14). Le Fort I is a transverse fracture separating the body of the maxilla from the pterygoid plate and nasal septum. Only the hard palate and teeth move, similar to a loose upper denture. Le Fort II is a pyramidal fracture through the central maxilla and hard palate. Movement of the hard palate and nose occurs, but not the eyes. Le Fort III is craniofacial dysjunction when the entire face is separated from the skull from fractures of the frontozygomatic suture line, across the orbit and through the base of the nose and ethmoids. The entire face shifts with the globes held in place only by the optic nerve. A Le Fort IV fracture includes characteristics of the Le Fort III and also involves the frontal bone. CT scan of the face with coronal and axial slices with three­dimensional reconstructions best defines these complex injuries.
FIGURE 259­14. Le Fort injury patterns. Illustration of the fracture lines of Le Fort I (alveolar), Le Fort II (zygomatic maxillary complex), and Le Fort III (craniofacial dysjunction) fractures. [Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010,
McGraw­Hill, New York.]
Patients with Le Fort injuries often present with significant hemorrhage, requiring airway protection and nasal packing. Oral packing is often required for control of fractures involving the hard palate. Le Fort injuries require admission for management of significant associated injuries, IV antibiotics, and surgical repair.
MANDIBLE FRACTURES
Mandible fractures are the second most common facial fracture after nasal fractures. Assaults, motor vehicle crashes, and falls are the most commonly
 reported mechanisms. One large trauma center reported 36% of fractures in the region of the angle, followed by 21% in body, and 17% in the
 parasymphyseal region. Always look for multiple mandibular fractures with one injury at the site of impact and a second subtle injury on the opposite side of the ring. In fact, a mandibular fracture should be considered bilateral until proven otherwise. Comminuted mandible fractures could result in upper airway obstruction due to the tongue being unsupported anteriorly. Presume an open fracture until a thorough intraoral examination determines otherwise. Fractures are classified as either favorable or unfavorable, depending on whether the musculature reduces or opens the fracture.
Patients with mandible fractures usually complain of malocclusion with pain worsened by attempted movement. On inspection, the mandible may appear widened or displaced to one side. Patients may present with trismus due to pain and swelling. Palpation reveals loss of the smooth counters of the mandible, tenderness, and anesthesia in the distribution of the proximal inferior alveolar or distal mental nerve. A careful intraoral examination is important to exclude small breaks in the mucosa seen with open fractures, sublingual hematoma or ecchymosis, and dental or alveolar ridge fractures and to identify missing teeth. Examine the ears for evidence of tympanic membrane perforation, hematotympanum, or evidence of condyle displacement. Place a finger into the external auditory canal and ask the patient to open and close the mouth to palpate for injury to the condyle.
Panorex remains the initial imaging study in patients with a low clinical suspicion of injury (Figure 259­15). Order mandible or face CT with coronal and axial sections in patients suspected of having condyle fractures, complex fractures, or multiple facial fractures. A chest radiograph is necessary in the unconscious patient with missing teeth to exclude aspiration of the missing teeth.
FIGURE 259­15. Mandible fracture. Panoramic view demonstrating an unfavorable mandibular fracture with obvious misalignment (arrow) due to the distracting forces of the masseter muscle. [Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010,
McGraw­Hill, New York.]
In the patient with a stable airway, placement of a Barton’s bandage, an ace wrap over the top of the head and underneath the mandible, will stabilize the fracture and help relieve pain. Administer pain control and antibiotics, such as penicillin G  to  million units IV (or clindamycin, 600 to 900 milligrams, in penicillin­allergic patients), for open fractures. Although studies question the utility of antibiotics, given the overwhelming number of
,34 potentially virulent oral anaerobes contaminating open mandible fractures, antibiotics remain a logical therapeutic agent. Patients with closed fractures may be given urgent outpatient follow­up. Open fractures require admission for operative repair.
PEDIATRIC CONSIDERATIONS
Facial fractures in the pediatric population are typically due to falls, bicycle accidents, pedestrian accidents, and transport accidents. The nasal bones
 and mandible are most commonly fractured. Several unique considerations must be made in the initial management of the pediatric patient with facial trauma. Cricothyrotomy is contraindicated in patients <8 years old because the cricothyroid membrane is not developed until age  and should be avoided in those between  and  years of age. In children with severe midfacial injury in whom oral endotracheal intubation is not possible, laryngeal mask airway placement or needle cricothyrotomy serves as a temporizing measure pending emergency tracheostomy. Facial trauma in children should always prompt the consideration of child abuse.
Skull development predisposes children to certain facial and associated injuries while making others less likely. The child’s high center of gravity, relatively poor balance, explorative nature, and prominent forehead make the child more susceptible to frontal bone impact and underlying brain injury. Cervical spine injury in children occurs at higher levels and more often without bony radiographic injury (spinal cord injury without radiologic abnormality). The maxillary sinuses do not begin developing until age  years old, which reduces the incidence of midfacial fractures compared with adults.
The pliable pediatric orbital floor is more likely to bend and crack, forming a small “trapdoor” through which muscle and fat become entrapped and
 potentially ischemic. Pediatric mandible fractures are more likely to be incomplete fractures and more irregular secondary to the underlying
 developing teeth. Rapid bone remodeling in children with callus formation begins within  week and makes delayed reduction difficult. Children with mandible fractures require prompt diagnosis and 1­ to 2­day referral to a pediatric facial surgeon to prevent long­term problems with asymmetrical
 facial growth, cosmetic deformities, and difficulty with mastication.


