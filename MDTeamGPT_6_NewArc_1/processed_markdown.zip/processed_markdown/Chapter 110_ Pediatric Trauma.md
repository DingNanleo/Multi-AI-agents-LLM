## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 110: Pediatric Trauma
Genevieve Ernst
INTRODUCTION AND EPIDEMIOLOGY
Traumatic injuries are the biggest killer of children in the developed world and can lead to significant disability and healthcare expenditure. On
 average, one child dies every hour from injuries or violence in the United States. Almost ,000 children and adolescents died in 2016 in the United

States from unintentional or violence­related injury, giving a crude death rate of almost  per 100,000; >60% of these deaths were unintentional.

Additionally, an average of ,200 children seek medical attention every day in U.S. EDs for nonfatal injuries. Although often referred to as
“accidents,” most traumatic injuries in children represent discrete, potentially preventable events.
,3
Pediatric trauma occurs in a bimodal age distribution, with peak incidences in toddlers and adolescents. Motor traffic–related injury is the number one cause of death in children >4 years old as well as adolescents. Other leading causes of unintentional injury include pedestrians and cyclists struck
  by vehicles, falls, and fires. Children are at greater risk of serious injury than adults when operating all­terrain vehicles and snowmobiles. Although blunt force trauma is far more common in children than penetrating injury, firearm­related mortality is one of the top four causes of mortality in

American youth. Infants <1 year of age are at greatest risk of death from inflicted injury. Although the rate of pediatric homicides has decreased over
 the past two decades, death by suicide is on the rise in the adolescent population.
BEHAVIORAL CONSIDERATIONS
The psychological ramifications of traumatic injuries and resuscitation in a busy trauma bay on the seriously injured child should not be underestimated. Behavioral regression is common due to pain, anxiety, and perceived threats in an unfamiliar environment. Making an effort to build a rapport and limit the number of providers in direct contact with the child is essential to gaining the child’s trust and cooperation. Understanding normal child development helps identify alterations of the sensorium, which may be the result of traumatic brain injury, hypoperfusion, or hypoxemia.
Family/caregiver presence during resuscitation is an important standard practice in pediatric care. This not only can help comfort the injured child but can also assist in assessing the child’s mental status. Studies repeatedly demonstrate that caregiver presence is beneficial for both
 the patient’s and caregiver’s psychological well­being, does not interfere with medical efforts, and does not result in increased medicolegal issues.
Consider providing a designated support person to help family/caregivers cope.
ED PREPAREDNESS
Prearrival preparedness warrants special consideration when anticipating the arrival of a critically injured child: estimate the child’s weight beforehand, precalculate common sedation and intubation medications, and have the appropriate­size equipment readily available. Make sure ED personnel maintain pediatric trauma competency. When anticipating the arrival of a critically injured child, consider drawing up sedation and intubation drugs beforehand using the “3:2:1 rule”: fentanyl  micrograms/kg IV, ketamine  milligrams/kg IV, and rocuronium  milligram/kg.
PEDIATRIC ANATOMY
Pediatric anatomy and physiology differences compared to adults are outlined in Table 110­1. The pediatric head has a larger surface area that is prone to significant bleeding either from open scalp wounds or hematomas, which can cause hypovolemic shock in infants. The cranium is thinner, transmits energy easily, and predisposes to skull fractures. Open sutures in infants can accommodate increases in intracranial pressure and may delay the recognition of serious intracranial injuries. Infants have prominent extra­axial intracranial spaces through which bridging cortical vessels traverse aDnodw anrleo apdroende  t0o2 s5h­e7e­1r a6n:5d aPc cYeoleurra ItPio nis­ d1e3c6e.l1e4ra2t.1io5n9 f.o1r2c7es such as those sustained in aggressive shaking; this accounts for classic findings such as
Chapter 110: Pediatric Trauma, Genevieve Ernst subdural hemorrhages in inflicted injury victims. Finally, the size of the head in young children is larger compared to the body, which predisposes to
. Terms of Use * Privacy Policy * Notice * Accessibility closed head injury, giving a higher incidence of concomitant traumatic brain injury in children with polytrauma. A larger head may also lead to airway occlusion when placed supine without back support.
TABLE 110­1
Pediatric Anatomy and Physiology Compared to Adults
Anatomy and
Differences Compared to Adults Considerations
Physiology
Head/brain Larger surface area Significant bleeding from lacerations or hematomas
Thinner cranium Predisposes to skull fractures
Open sutures Accommodate ICP increases; delay recognition of serious intracranial injury
Larger extra­axial intracranial space Prone to sheer and acceleration­deceleration forces
Larger head Head more likely to be injured in polytrauma
Cervical spine Facets more horizontal; ligamentous and Higher level cervical spinal injury and SCIWORA muscle laxity
Airway Laryngeal cartilages more pliable Less prone to fracture than adults
Smaller airway and neck More risk of soft tissue swelling/bleeding compromising airway
Chest Compliant chest wall Minimal wall injury but still serious pulmonary injury
Heart more anterior and mediastinum Minimal wall injury but still serious cardiac/mediastinal injury mobile
Susceptible to barotrauma Avoid excessive airway pressures during ventilation
Smaller airways Small changes in airway diameter by secretions or aspiration cause greater resistance to airflow
Abdomen Relatively larger sized abdominal organs Greater risk for blunt abdominal trauma
Thick visceral capsules May limit hemoperitoneum and US sensitivity
Less abdominal fat and elastic ligamentous More vulnerable to acceleration­deceleration injury and hollow viscus injuries attachments
Skeleton Incomplete calcification Bones more pliable; specific fractures unique to children
Body surface area Higher; thinner skin layers Greater risk for hypothermia
BP and PR Vary by age CO relies on PR rather than stroke volume; BP can remain normal despite loss of
40% of blood volume
Ventilation Tidal volume fixed; smaller FRC Minute ventilation maintained by increasing respiratory rate; rapid desaturation during apnea
Abbreviations: BP = blood pressure; CO = cardiac output; FRC = functional reserve capacity; ICP = intracranial pressure; PR = pulse rate; SCIWORA = spinal cord injury without radiographic abnormality.
The facets in the pediatric cervical spine are more horizontal than in adults, with less calcified vertebral bodies, increased laxity of spinal ligaments, and weaker supporting musculature, all of which allow translational forces to cause spine injuries without bony abnormalities. Due to the weaker neck musculature and larger cranium, the fulcrum of force is more cephalad, predisposing children to higher cervical spine injuries compared to adults (see
Chapter 112, “Cervical Spine Injury in Infants and Children”).
Significant anatomic differences between pediatric and adult airways are discussed in Chapter 113, “Intubation and Ventilation in Infants and
Children,” as they relate to advanced airway management. The pediatric laryngeal cartilages are more pliable and therefore less prone to fracture than the firm ossified adult cartilages. Although the larynx is relatively protected, children have higher risk for airway compromise due to soft tissue swelling or expanding hematoma in relation to the smaller size of the pediatric airway and neck.
The chest wall in children is more compliant, its tracheobronchial structures are more vulnerable, and the heart is more anterior with mobile mediastinal structures, all of which predispose to intrathoracic injury such as pulmonary contusions with minimal thoracic wall injury. Delicate tracheobronchial structures are susceptible to barotrauma especially in situations of excessive volume ventilations during resuscitation generating iatrogenic pneumothorax. The diameter of the respiratory structures is much smaller than in adults, and a change in the inner diameter (from aspirated fluids or secretions) has a four­fold impact on the resistance to air flow as stated by the Hagen­Poiseuille equation, predisposing to airway obstruction.
The child’s abdomen is relatively larger in size compared with the rest of the trunk, has underdeveloped musculature, and has relatively larger intraabdominal organs, which predispose to solid organ injuries in blunt abdominal trauma. Furthermore, a thick capsule limits hemoperitoneum in solid organ injury in children, decreasing the sensitivity of US to detect significant injury. The lower intra­abdominal fat content and elastic ligamentous attachments in children (i.e., perinephric fat, sigmoid and ascending colon peritoneal attachments) contribute to increased vulnerability to injury from acceleration­deceleration or abdominal compression. This can predispose children to hollow viscus injuries from seat belt or handlebar trauma. In infants and younger children, the bladder boundaries extend cephalad to just below the umbilicus, and the bladder is vulnerable to direct blows to the lower abdomen.
The skeleton is incompletely calcified, which renders bones more pliable and leads to bowing and greenstick injuries; multiple active growth centers and weaker epiphysis explain certain fracture types specific to children such as supracondylar fractures of the elbow and epiphyseal injuries such as the ones described by the Salter­Harris classification (see Chapter 141, “Pediatric Orthopedic Emergencies”).
The higher body surface area to overall body mass in children and thin epidermal and dermal layers of the skin along with a paucity of subcutaneous fat and immature thermoregulatory mechanisms lead to increased propensity for hypothermia in cold environments, which must be considered when assessing an exposed child in the trauma bay.
Given their smaller size, multisystem injuries are the rule rather than the exception for children with blunt force trauma. However, increased neuroplasticity in young children and general good health increase their likelihood of a favorable recovery.
PHYSIOLOGY
Table 110­2 shows the expected vital signs according to age. Be alert to abnormalities in heart rate, respiratory rate, and peripheral perfusion that
 can indicate acute deterioration in the setting of trauma.
TABLE 110­2
Normal Pediatric Vital Signs
Pulse (beats/min) Systolic Blood Pressure (mm Hg) Diastolic Blood Pressure (mm Hg)
Newborn 95–145 60–90 30–45
Infant 125–170 75–100 30–70
Toddler 100–160 80–110 40–90
Preschool 70–110 80–110 45–85
School age 70–110 85–120 45–88
Adolescent 55–100 95–120 60–90
Cardiac output is mediated primarily by heart rate in children as opposed to stroke volume in adults. Children with significant blood loss develop tachycardia, which can be sustained for a variable period of time before cardiac output is compromised. In addition, the vasculature is quite sensitive to endogenous catecholamines, allowing children to modify vascular tone in response to hemodynamic changes and regulate perfusion to the core organs. These two parameters, capacity to increase heart rate and modulate peripheral vascular resistance, help children maintain normal blood and perfusion pressures in the face of significant hemorrhage of up to 40% of the total blood volume (80 to 100 mL/kg depending on age), and hypotension is a very late and ominous sign of cardiovascular compromise in children.
The mean systolic blood pressure in children  to  years of age can be estimated using the following formula:  + (2 × age) mm
Hg; hypotension can be estimated as systolic blood pressure less than  + (2 × age) mm Hg.
In children, pulmonary tidal volume is relatively fixed, so minute ventilation is maintained primarily by respiratory rate (tachypnea) rather than depth
(hyperpnea). Small residual volumes contribute to atelectasis, and a smaller functional residual capacity contributes to rapid desaturation during apnea.
Finally, the metabolic demands in children are higher than in adults. Children have a higher energy expenditure and caloric requirement at baseline.
Although stress­induced hyperglycemia is common in the setting of polytrauma, hypoglycemia can occur in younger children and should be treated promptly.
THE PRIMARY SURVEY
Despite the many differences between pediatric and adult trauma management, the general approach to assessing the child with multiple trauma is the same: the traditional “(C)ABCDE” (catastrophic bleeding, airway with cervical spine motion restriction, breathing, circulation with hemorrhage control, disability, exposure) approach to the primary survey while addressing life­threatening injuries should be employed in all injured children. (See
Chapter 254, “Trauma in Adults,” for a summary of primary and secondary survey steps.)
AIRWAY
A significant proportion of traumatic deaths occur from hypoxia, and timely airway management by an experienced provider is of paramount importance. Assess the patency of the airway first; note a hoarse or muffled cry or voice, stridor or sonorous respirations, increased work of breathing, or poor chest rise with bag­valve mask ventilation. Evaluate the maintainability of a protected airway in the presence of facial or neck trauma or facial burns, or in patients with neurologic compromise that precludes them from having an organized breathing pattern. In a spontaneously breathing child with a partially obstructed airway, use a jaw­thrust maneuver with bimanual in­line spinal motion restriction to open the airway, suction secretions and debris, and apply supplemental oxygen.
A larger occiput in smaller children results in passive extension of the cervical spine and distortion of airway anatomy. The plane of the midface should remain parallel to the spinal board or bed. For infants and toddlers, placement of a 1­ to .5­in. layer of padding below the entire torso may be required to maintain neutral alignment of the spine. Care should be taken to restrict cervical spine motion in polytrauma patients, especially if obtunded or if a cervical spine injury is suspected (see Chapter 112, “Cervical Spine Injury in Infants and Children”)).
Endotracheal intubation may be challenging due to distorted anatomy or due to blood, foreign bodies, or teeth occluding the airway. Since in­line stabilization may be required for airway manipulation, airway support in trauma is considered “difficult,” with adjuncts such as laryngeal mask airways, bougie, video laryngoscopy, and surgical airways sometimes being required (see Chapter 113, “Intubation and Ventilation in Infants and
Children”). Indications for endotracheal intubation in the trauma patient include the following:
. Glasgow Coma Scale score <8 or lack of airway protective reflexes
. Respiratory failure due to inadequate oxygenation or ventilation (e.g., pulmonary contusions, large pneumohemothoraces, chest wall or diaphragm injuries)
. Impending airway comprise (e.g., facial burns, inhalation injury, expanding neck hematoma)
. Lack of neuromuscular respiratory drive (e.g., cervical spinal cord injuries)
. Significant hypovolemia with depressed sensorium
. Unstable patients in need of CT imaging, angioembolization, or operative intervention
. Transport of critically injured patients to another institution, especially over long distances
Preoxygenate children who require endotracheal intubation for airway control. Having a standardized approach to drug­assisted intubation in
,8 pediatric trauma patients can reduce medical errors and improve patient safety. The vast majority of pediatric trauma patients can be safely intubated using ketamine followed by a paralytic agent, including those with head or ocular injuries. Ketamine is the induction agent of choice in
,10 hypotensive patients and may improve cerebral blood flow in children with raised intracranial pressure. Alternatively, etomidate reduces cerebral blood flow, intracranial pressures, and cerebral oxygen consumption, while maintaining arterial blood pressure, and may be considered in children with severe traumatic brain injury. Induction agents with a propensity to cause hypotension, such as propofol, should be avoided in all hemodynamically compromised children, especially those with associated head injuries, because a single hypotensive event can worsen neurologic
 outcome. Consider premedication with atropine sulfate in infants <1 year of age because they are at risk for bradycardia in response to both laryngeal stimulation and hypoxia.
A needle cricothyroidotomy may be required if orotracheal intubation is not possible due to severe maxillofacial injuries and the patient cannot be adequately ventilated and oxygenated. Laryngeal anatomy is difficult to discern, especially in young children, making needle­jet insufflation via the cricothyroid membrane the preferred temporizing technique for oxygenation. However, lifesaving surgical cricothyrotomy has been successfully performed in older children in whom the cricothyroid membrane is easily palpable (usually by  years of age). (See Chapter 113, “Intubation and
Ventilation in Infants and Children.”)
BREATHING
Once a definitive airway has been established, assess the adequacy of breathing through careful observation of the rate, depth, pattern, and work of breathing, including tracheal position and symmetry of chest wall movements as well as air entry. Note that alterations in the mental status might signify hypoxia (agitation) or hypercarbia (somnolence) from inadequate breathing.
The physiologic consequences of blood or air accumulation in the pleural space are similar in children and adults, and significant hemopneumothoraces are treated with pleural decompression. When there is concern for tension pneumothorax, immediately perform a needle thoracostomy by placing a 16­ to 18­gauge IV catheter in the midclavicular line just above the third rib. Be mindful that longer over­the­catheter needles
 in small children pose a risk of iatrogenic lung injury given their relative size and thinner chest walls. Alternatively, in overweight children or muscular adolescents, consider placing a catheter between the fourth and fifth ribs at the anterior axillary line. Proceeding directly to a decompressive finger thoracostomy should be considered for patients in extremis or in cardiac arrest, as long as this can be performed expediently. A tube thoracostomy
(chest tube) should then be inserted to drain air and/or blood from the chest with an appropriate­size tube based on age or weight. Although the open technique with a larger­size chest tube is preferable during a resuscitation, consider inserting a pigtail­type chest tube by Seldinger method in stable
 children with isolated pneumothoraces.
Of note, infants and toddlers are predominantly diaphragmatic breathers and are highly sensitive to increased intra­abdominal pressure. Early gastric decompression with an orogastric tube can significantly improve their work of breathing.
CIRCULATION
As in adults, catastrophic bleeding should be addressed first in the primary survey. Hemorrhage control with direct pressure, tourniquets, and pelvic
 binding are essential prehospital interventions that save lives in both children and adults. Infants can lose a substantial amount of blood from their scalps. However, isolated long bone or pelvic fracture are unlikely to be the sole cause of circulatory compromise in the prepubertal child, and other sources of bleeding should be considered, especially intra­abdominal injuries.
Because hypotension is a late and ominous sign of decompensated shock, recognition of early signs of hypovolemia is of paramount importance.
Tachycardia and poor skin perfusion are often the only signs of circulatory compromise. Tachycardia may also be caused by pain or fear, which provides an additional challenge when assessing the pediatric patient. Other important signs of blood loss include weakening of peripheral pulses, mottled skin, cool extremities relative to the torso, altered sensorium including dulled response to pain, and narrowing of the pulse pressure to <20
 mm Hg.
Vascular access can be challenging in small children, especially in hypovolemic shock, with limited cannulation options. Ideally, place two proximal large­bore IV catheters, but limit attempts in the critically injured child and proceed to intraosseous access if unsuccessful after  seconds (see
Chapter 114, “Vascular Access in Infants and Children”). Venous cutdowns and central access are rarely used for initial vascular access in children because they can be procedurally difficult and time consuming. Rapid infusion devices can deliver warmed fluids rapidly through a 20­gauge or larger cannula but are not compatible with smaller­gauge catheters. In smaller children, a pressure bag or multiple handheld syringes may be used for rapid fluid resuscitation via the pull–push method. However, neither of these methods accounts for warming the fluids. Instead, consider using prewarmed
 crystalloids, placing syringes under forced air warmers, or using a Hotline® Fluid Warmer (Smiths Medical, Dublin, OH).
Fluid Management and Hemostatic Resuscitation
Ongoing controversy exists with regard to the ideal fluid resuscitation strategy for seriously injured children. Recently, there has been a move away from crystalloid resuscitation in adult hemorrhagic shock in favor of a “damage control resuscitation” approach, with includes early administration of blood products (see Chapter 254, “Trauma in Adults”), the goal of which is to minimize the dilution of clotting factors, tissue edema, and acidosis associated with excessive crystalloids, which are thought to worsen trauma­induced coagulopathy. Many pediatric trauma centers in North America have adopted a crystalloid restrictive balanced fluid resuscitation strategy, although evidence of improved outcomes with this approach is lacking in children. Although the exact threshold for adverse crystalloid effects is not known, excessive crystalloids in pediatric trauma (in excess of  mL/kg/d)
,16 are associated with increased intensive care and ventilator days.
,17
On the other hand, children may be relatively fluid tolerant as compared to adults and usually tolerate initial boluses of  to  mL/kg. For instance, the majority of children with bleeding from an isolated intra­abdominal solid organ injury will respond to a single bolus of normal saline or
 lactated Ringer’s and hence may forgo a blood transfusion.
At this time, judicious use of crystalloids is recommended for injured children with suspected bleeding. Children in compensated
,18 hemorrhagic shock should be given an initial bolus of  mL/kg (10 to  mL/kg) of warmed crystalloids. If their condition does not improve, early transition to weight­based blood product resuscitation is advised (10 to  mL/kg of packed red blood cells for children <40 kg). On the other hand, children in decompensated shock should receive blood as soon as logistically possible. Keep
 in mind that aggressive blood component replacement is not a substitute for definitive surgical control of bleeding.
Permissive hypotension, to prevent clot disruption, is not currently recommended in children given that hypotension is a late
 finding of shock and the high incidence of concomitant traumatic brain injury in polytrauma victims.
Massive transfusion protocols provide balanced ratios of red blood cells, plasma, and platelets with the goal of minimizing the coagulopathy associated with significant hemorrhage. Evidence from combat literature suggests that children requiring >40 mL/kg of blood products in the first 
 hours, or roughly half their blood volume, have an increased risk of both early and late mortality. Therefore, many centers across the United
States have incorporated a definition of >40 mL/kg of anticipated blood product requirements into their massive transfusion guidelines. Although studies have yet to demonstrate a survival benefit for blood­based massive transfusion protocols in children, they can help
 organize and expedite blood product delivery, and pediatric trauma centers should advocate for their use. Further research is needed to determine the optimal ratio of packed red blood cells to plasma to platelets in children, and evidence for improved outcomes with any given foundation ratio,
 including high plasma ratios (1:1:1) as in adults, is lacking.

Most of the evidence supporting use of tranexamic acid in children originates from combat literature, and its use in pediatric polytrauma is not yet
 standard of care. That said, hemorrhage, as in adults, remains a leading cause of preventable trauma death. Acute traumatic coagulopathy and hyperfibrinolysis exist in severely injured children and can be further exacerbated by traumatic brain injury–associated coagulopathy. Furthermore, tranexamic acid has been shown to be both safe and efficacious when used in high doses in pediatric surgery. Given the minimal risks and plausible benefit, tranexamic acidshould be strongly considered within  hours of injury in adolescents as well as children of all ages
 requiring a blood transfusion. More research is needed to determine the role of tranexamic acid in isolated solid organ injury.
DISABILITY
Assess mental status by observing the patient’s best response to a parent or caregiver. Mental status in preverbal children can be assessed using the modified pediatric Glasgow Coma Scale (GCS) (Table 110­3). The pediatric Glasgow Coma Scale for infants has a similar accuracy for predicting
 clinically important traumatic brain injury as the standard Glasgow Coma Scale for older children.
TABLE 110­3
Modified Pediatric Glasgow Coma Scale
Verbal Response Eye Opening Motor Response
Coos or babbles =  Spontaneous =  Spontaneous = 
Irritable cry =  To voice =  Withdraws to touch = 
Cries to pain =  To pain =  Withdraws to pain = 
Moans to pain =  None =  Abnormal flexion = 
No response =  Abnormal extension =2
None = 
A simpler and validated method to assess mental status in children is by using the AVPU score, which is currently recommended by the pediatric
 advanced life support guidelines (Table 110­4).
TABLE 110­4
AVPU Score
A = Awake
V = Responds to verbal stimuli
P = Responds to pain
U = Unresponsive
Check the pupillary response to light and determine whether the child is moving all four limbs. Pupillary response is predictive of both survival and
 neurologic outcome. Monitor serum glucose because hypoglycemia can lead to an altered mental status as well as worsen neurologic outcome.
Be mindful that pain is often undertreated in children and ensure that appropriate analgesics and sedatives are given. Intranasal medications or inhaled nitrous oxide can be used prior to establishing IV access, and children, as adults, can benefit from regional blocks for musculoskeletal injuries (see Chapter 115 “Pain Management and Procedural Sedation in Infants and Children”).
EXPOSURE AND ENVIRONMENTAL CONTROL
Disrobe and expose the child to identify all potential injuries and perform lifesaving procedures; however, children are particularly susceptible to hypothermia when exposed to cold environments or receiving room temperature fluids. Keeping the child warm is imperative as temperature instability can worsen coagulopathy, thereby exacerbating blood loss. To avoid iatrogenic hypothermia, maintain a warm resuscitation environment, remove wet clothing, and cover the child with warm blankets or an external warming device as soon as the assessment is complete. If the child remains hypothermic or ongoing fluid resuscitation is needed, give warmed crystalloids and blood products.
If a log roll is performed to examine the back and spine, make sure to examine the back of the scalp for ongoing bleeding. Note that a digital rectal exam should be performed only in select patients in whom there is concern about serious spinal injury. The digital rectal exam rarely provides
 additional useful information and may be particularly upsetting for the pediatric patient.
THE SECONDARY SURVEY AND SURVEY ADJUNCTS
After the primary survey is complete and life­threatening injuries have been addressed, perform a secondary survey. This includes an AMPLE history
(allergies, any relevant medications, past medical history, time of last meal, and events leading up to the trauma), a “head to toe” examination, and completion of adjunctive laboratory or imaging tests not already performed. See Chapter 254, “Trauma in Adults,” for key physical examination findings.
LABORATORY INVESTIGATION
Routine laboratory “trauma panels” are frequently obtained in the evaluation of injured children, but individual laboratory abnormalities, while common, are seldom useful to dictate therapy, and no single laboratory test has acceptable sensitivity or negative predictive value to safely and
 effectively screen patients when used alone. Even organ­specific chemistries alone predict abdominal injury poorly in children and rarely alter acute management. Although elevated liver function tests, particularly alanine aminotransferase, are suggestive of liver injury, no consensus exists as to the cutoff point for determining risk. An exception to the generally poor utility of liver function tests is in the setting of suspected inflicted injury in infants
 and young children, for whom liver function tests are recommended as a screening tool to detect occult blunt intra­abdominal injury.
Urinalysis is frequently obtained in trauma patients, but microhematuria alone is poorly predictive of either genitourinary or intra­abdominal injury across a range of cut points for number of red blood cells per high­power field; gross hematuria and mechanism of injury, rather than microhematuria,
 should guide imaging studies.
Consider obtaining a β­human chorionic gonadotropin in all girls over the age of  years. Additionally, obtain toxicology testing in preteens and adolescents, especially if their mental status is altered or if drug or alcohol use is suspected to have contributed to the injury. A visit to the ED for serious injuries may be an opportune time to identify patients who could benefit from a Screening, Brief Intervention, and Referral to Treatment
,30
(SBIRT) approach for substance use once the patient is stable.
Combining laboratory tests with clinical findings may be useful for prognostication in pediatric blunt trauma. Furthermore, early coagulopathy and acidosis may better predict mortality and ongoing blood product needs than traditional scoring tools such as the Pediatric Trauma Score or Injury

Severity Score. A promising score currently being prospectively validated in polytraumatized children is the B.I.G. Score (base deficit + [2.5 × INR] +
[15 – Glasgow Coma Scale score]). A score of <16 accurately predicts children with a high probability of survival and allows physicians to rapidly recognize the degree of physiologic derangement. This may prove useful not only in tracking patient outcomes, but also for providing a meaningful
32­34 way of communicating severity of injury to the referral hospital.
IMAGING
Plain Radiography
Not all children require a complete “trauma series” in which the cervical spine, chest, and pelvis are imaged. Predictors of intrathoracic injury after blunt trauma in pediatrics include low systolic blood pressure, blood oxygen saturation <95%, abnormal thoracic exam, femur fracture, and altered mental status. However, up to 5% of children with intrathoracic injuries may have no predictors, and therefore, a chest radiograph should be
 considered in all patients with a concerning mechanism. Complaints of pain or abnormal exam of the pelvis or hip, hematuria, femoral deformity, hemodynamic instability, and Glasgow Coma Scale score of ≤13 are independent risk factors for pelvic fractures. Children with none of these features
 have <0.5% risk of pelvic injury and may forgo plain films of the pelvis. Furthermore, if an abdominopelvic CT is planned, plain radiographs of the pelvis are not required. Although plain films of critical musculoskeletal injuries, such as long bone fracture, may be needed in the resuscitation bay, radiographs of non–limb­threatening injuries should not delay CT imaging or transfer to definitive care.
US
FAST is an appealing test due to its rapid bedside acquisition, relatively low cost, and lack of radiation, but there are a number of limitations in pediatric use. Due to anatomic and physiologic differences between children and adults, up to 30% of children with solid organ injury have no demonstrable free fluid on FAST, decreasing the sensitivity of this exam for solid organ injuries and limiting its negative predictive value, particularly in hemodynamically normal patients. FAST can miss intra­abdominal injuries requiring intervention, and CT imaging should be obtained when an injury is suspected on clinical exam regardless of findings on US. Moreover, unlike adults in whom free fluid
(hemoperitoneum) usually requires laparotomy, the vast majority of children with hemoperitoneum are successfully managed nonoperatively, so a
,38 positive FAST rarely changes management. However, in the hemodynamically compromised patient with multiple injuries, FAST may provide
,40 valuable information as to the source of bleeding and help to focus resuscitative efforts. There is an emerging role for serial FAST in combination with abdominal exam and blood work in patients with suspected blunt abdominal trauma. However, further study is needed to determine how to best
 incorporate FAST into clinical practice guidelines for children. In addition, contrast­enhanced US is a novel radiation­free imaging modality that has
,43 shown promise for the diagnosis and follow­up of blunt abdominal trauma in children.
Currently the greatest advantages of POCUS in pediatric trauma lie in the extension of the traditional FAST to include an assessment of the lungs and heart, especially in penetrating trauma. POCUS is superior to plain films for detecting occult pneumothoraces in the supine patient and is useful for identifying cardiac effusions as well as assessing global cardiac contractility. Other important applications include procedural guidance, such as
,40,44 regional nerve blocks, and airway confirmation for intubated patients.
CT
CT imaging is the gold standard for evaluation of acute intracranial bleeding, pulmonary parenchymal or great vessel injuries, solid organ injuries, and pelvic injuries. However, children are at increased risk of malignancy secondary to ionizing radiation, and judicious use of CT and application of the
ALARA (as low as reasonably achievable) principle to limit the dose of radiation received are imperative. A retrospective review of >42,000 pediatric patients with blunt trauma showed no mortality benefit to whole­body CT imaging compared to a selective CT approach. In addition, additional injuries
 identified on the “pan scan” were not life threatening and did not change management. When possible, CT imaging should be reviewed by a pediatric
 radiologist with trauma experience, and scans from referring hospitals should be reinterpreted on arrival to a pediatric trauma center. Furthermore, imaging should not delay transfer to a higher level of care.
REFERRAL TO A PEDIATRIC CENTER
Pediatric trauma center designation in the United States is conferred by governmental authority, and requirements vary from state to state. Guidelines have been created by the American College of Surgeons to delineate the capabilities of a designated pediatric trauma center. Necessary resources include 24­hour availability of a pediatric surgeon, pediatric surgical specialists, pediatric anesthesiology, pediatric intensive care, and medical
,48 pediatric specialties, and the ability to provide comprehensive care to children of all ages.
Use of trauma triage scores can help identify a child with more severe injuries in need of a higher level of care. Two of the most commonly used scores are the Pediatric Trauma Score (Table 110­5) and the Revised Trauma Score (Table 110­6), which emphasize physiologic variables rather than
 relying solely on anatomic factors or mechanism of injury. Lower scores are associated with greater need for critical interventions and mortality : a

Revised Trauma Score of <12 or a Pediatric Trauma Score of <8 should prompt transfer to a pediatric trauma center.
TABLE 110­5
Pediatric Trauma Score* –1 +1 +2
Size (kg) <10 10–20 >20
Airway Unmaintained Maintained Normal
Systolic blood pressure (mm Hg) <50 50–90 >90
Level of consciousness Comatose Altered Awake
Wounds Major open Minor open None
Skeletal trauma Open/multiple Closed None
*Total score is calculated by adding the score corresponding to the appropriate value from each column.
TABLE 110­6
Revised Trauma Score* Number Glasgow Coma Scale Score Systolic Blood Pressure (mm Hg) Respiratory Rate (breaths/min)
 13–15 >89 10–29
 9–12 76–89 >29
 6–8 50–75 6–9
 4–5 1–49 1–5

*Total score is calculated by adding the score corresponding to the appropriate value from each column.
Although mechanism is associated with specific injury patterns, the decision to transfer a patient to a pediatric trauma center should be based primarily on anatomic and physiologic factors as they better predict the need for interventions. Additional indications for transfer to a pediatric trauma
 center are listed in Table 110­7. TABLE 110­7
Indications for Transfer to a Pediatric Trauma Center
Physiologic criteria Depressed or deteriorating neurologic status
Respiratory distress or failure
Intubated children requiring ventilatory support
Shock, compensated or uncompensated
Injuries requiring blood transfusion
Children requiring pediatric intensive care monitoring
Arterial or central venous pressure monitoring
Intracranial pressure monitoring
Vasoactive medications
Anatomic injury Multiple severe trauma
Two or more major long­bone fractures (i.e., femur, humerus)
Fractures of the axial skeleton
Spinal cord or column injuries
Traumatic amputation of an extremity
Moderate to severe head injury
Cerebrospinal fluid leaks
Open or depressed skull fractures
Significant blunt injury to the torso
Major pelvic fractures
Penetrating head, chest, abdominal, or pelvic trauma
Extensive burns or burns with associated trauma
Sources:https://www.doh.wa.gov/portals/1/Documents/Pubs/530092.pdf (Washington State Department of EMS and Trauma Systems: Pediatric Consultation and
Transfer Guidelines.); http://www.dshs.state.tx.us/WorkArea/linkit.aspx?LinkIdentifier=id&ItemID=8589975024 (The Trauma Center Association of America: Pediatric
Trauma Interfacility Transfer Guidelines.); and http://pediatrictraumasociety.org/multimedia/files/Inter­Facility­Tool­Kit.pdf (Pediatric Trauma Society: Interfacility
Trauma Toolkit for Pediatric Patients.) Accessed December , 2018. ,53
Care of seriously injured children at a pediatric trauma center is associated with improved survival. If not available, transport to a designated
,55 trauma center, adult or pediatric, is still associated with improved outcomes. Interfacility transfer of critically injured children is best done by a specialized pediatric transport team or a critical care transport team with pediatric experience when available (see Chapter 107, “Neonatal and
Pediatric Transport”).
HEAD TRAUMA
Minor head injury (Glasgow Coma Scale >13) and concussion, including pathophysiology and clinical decision rules to decide which children require neuroimaging, is discussed in Chapter 111, “Minor Head Injury and Concussion in Children.” Inflicted head injuries are discussed in more detail in
Chapter 150, “Child Abuse and Neglect.” This section focuses on moderate to severe traumatic brain injury.
The first priority for children with severe head injuries is complete and rapid physiologic resuscitation. Cerebral perfusion pressure is dependent on the difference between the mean arterial pressure and intracranial pressure. Keeping this physiologic principle in mind, timely goal­directed therapy is the key to preventing secondary brain insults. Avoid hypoxia as well as hypotension and maintain normothermia, normocapnia, euvolemia, and
,57 euglycemia. When possible, avoid secondary transfers via hospitals without neurosurgical presence because expedient imaging followed by timely
 neurosurgical intervention improves survival.
There remains substantial practice variation in the management of pediatric traumatic brain injury across the United States as well as a paucity of high­
 level evidence to support specific therapies. However, adherence to clinical practice guidelines and development of multidisciplinary neurocritical
60­62 care programs for children have been shown to reduce mortality and improve neurologic outcome. Comparative effectiveness studies evaluating
 different medical therapies on children with severe traumatic brain injury are needed.
TREATMENT
63­66
A summary of management recommendations for serious traumatic brain injury is listed in Table 110­8. TABLE 110­8
Management of Serious Traumatic Brain Injury in Children
Considerations Primary Goal Comments
Cervical spine Maintain spinal motion restriction Image the cervical spine in intubated or obtunded patients
Airway Maintain airway, intubate for Glasgow Coma Scale (GCS) Intubation can raise intracranial pressure and should be score <8 or as needed for oxygenation and ventilation performed by an experienced provider
Oxygenation and Oxygen saturation >90%; Pco2 35–40 mm Hg No prophylactic hyperventilation ventilation
Blood pressure Systolic blood pressure >70 + (2 × age) No permissive hypotension
Cerebral perfusion CPP = 40–50 mm Hg (ref) Target may vary by age and size of the child pressure (CPP)
Intracranial pressure ICP ≤20 mm Hg Consultation with neurosurgeon
(ICP) monitoring
GCS GCS before paralytics if possible Serial GCS to document changes
Sedation and pain Midazolam, fentanyl, ketamine, etomidate, barbiturates, Consider paralytics once a neurologic examination is completed management thiopental (pediatric intensive care unit only)
Neuroimaging Identify intracranial injury and signs of increased intracranial Transcranial Doppler may be useful in infants with open
(noncontrast head CT) pressure or herniation fontanelles but requires an experienced pediatric radiologist
Glucose Treat hypoglycemia and avoid hyperglycemia Maintain normal blood glucose
Increased Elevate head of bed  degrees 3% normal saline  mL/kg bolus over  min followed by
ICP/impending infusion of .1 mL/kg/h to maintain serum sodium within 155– herniation 165 mEq/L or
Mannitol .5–1 gram/kg if normotensive (response is not dose dependent)
No corticosteroids
Core temperature Maintain temperature 36°C–38°C A 24­h course of moderate hypothermia is not indicated
Seizure prophylaxis Optional: consider for children with witnessed posttraumatic Phenytoin  milligrams/kg (or fosphenytoin  PE/kg) seizures and intracranial blood or
Levetiracetam  milligrams/kg (maximum, 500 milligrams/dose)67 for first week following severe traumatic brain injury
Anemia Transfuse for hemoglobin <7 grams/dL68
Neurosurgery/transfer ICP monitoring, evacuation of intracranial hematomas, or cerebrospinal fluid shunt for refractory intracranial hypertension
Abbreviation: PE = phenytoin equivalent.
NECK TRAUMA

Penetrating neck trauma is rare in children as compared to adults, comprising only .3% of cases reported in the National Trauma Data Bank.
Management of penetrating neck trauma in children is similar to adults and includes selective neck exploration based on physical examination and the
 use of CT angiography in stable patients. Blunt neck injuries are more common than penetrating injuries in children and are a result of falls into stationary objects, direct impact during sports, “clothesline injuries,” and intentional hanging injuries. Hanging can result in laryngeal fractures or
 separation injuries. Blunt cerebral vascular injury in children can be evaluated according to adult guidelines. For a complete discussion of neck injuries, see Chapter 260, “Trauma to the Neck.”
An approach to the evaluation of pediatric blunt neck trauma is shown in Figure 110­1. Assess children with neck injuries in a position of comfort to avoid airway compromise; avoid forcing a patient into recumbence when the physiology dictates tripoding and neck hyperextension in order to maintain airway patency.
FIGURE 110­1. Algorithm for the evaluation of pediatric blunt neck trauma. ATLS = advanced trauma life support; DL/bronch = direct laryngoscopy/bronchoscopy;
FFL = flexible fiberoptic laryngoscopy. [Source: Hernandez DJ, Jatana KR, Hoff SR, et al: Emergency airway management for pediatric blunt neck trauma. Clin Pediatr Emerg Med 15: 1522, 2014. .]
THORACIC TRAUMA
For a general description of thoracic trauma, see Chapter 261, “Pulmonary Trauma,” and Chapter 262, “Cardiac Trauma,” in the adult section. Thoracic injuries occur infrequently in children, accounting for 5% to 12% of pediatric trauma admissions, but are the second leading cause of death from trauma after closed head injury. More than two thirds of children with chest injuries have other organ system injuries. Isolated chest trauma in children
,34,72 carries 5% mortality rate, but when associated with closed head injuries and abdominal trauma, mortality increases up to 40%.
Blunt forces account for 90% of pediatric thoracic injuries. Motor vehicle crashes, pedestrian accidents, and inflicted injury are more common in
 younger children, whereas falls, sports­related injuries, and high­speed crashes are more common in older children and teenagers. Penetrating trauma is rare in children, but is more lethal than blunt trauma. However, firearm injuries continue to have a substantial impact on American youth,
,73,74 and young children are at the greatest risk from accidental access to firearms.
PULMONARY CONTUSIONS
Pulmonary contusions are the most common injury in blunt chest trauma in children and may present with minimal or no external signs of trauma, as forces are preferentially transmitted to internal organs. Anatomic changes in pulmonary contusion include interstitial edema and alveolar hemorrhage with subsequent consolidation. Areas of ventilation/perfusion mismatch reflect poor lung compliance and are associated with disordered ventilation and oxygenation. Pulmonary contusions evolve over the first  to  hours after injury, and even for several days, and hence may not be evident on initial chest radiograph. Respiratory deterioration on clinical exam should guide the need for repeat imaging. Of note, occult contusions seen only on
,76
CT imaging rarely impact management. Supportive care, including careful fluid management and lung­injury preventive ventilatory strategies, is
 the mainstay of management. Consider antibiotic prophylaxis for large contusions given the high rate of associated pneumonia. Interestingly, there have been case reports of refractory traumatic acute respiratory distress syndrome successfully managed with extracorporeal membrane
,79 oxygenation.
PNEUMOTHORAX
Pneumothoraces are common and present in up to a third of trauma victims; they should alert the clinician to the possibility of associated injuries.
Tension pneumothorax is of special concern in younger children due to the relatively easier compromise of cardiopulmonary physiology and detrimental effect on right side heart­filling pressures. Signs such as jugular venous distention are less prominent in children than in adults, and their absence can be falsely reassuring. If a tension pneumothorax is suspected, emergently decompress the chest and place a chest tube without waiting for confirmatory chest radiograph.
HEMOTHORAX
Hemothoraces are relatively less common in children than adults. A child’s hemithorax can contain up to 40% of the effective blood volume, and intrathoracic bleeding can lead to hemorrhagic shock. Pediatric recommendations for surgical thoracotomy include chest tube output >20 mL/kg on insertion, drainage exceeding  to  mL/kg/h, or need for ongoing blood transfusions. Hemothorax is associated with morbidity from infection, lung scarring, and chronic atelectasis.
RIB FRACTURES
Rib fractures are uncommon in children as a result of the elasticity of the rib cage. When present, however, rib fractures are often associated with severe injuries due to the high force required to cause them. In the absence of a witnessed high­energy mechanism, rib fractures, especially posterior, are highly suggestive of inflicted injury in infants. Obtain a chest radiograph to assess for acute or healing rib fractures when abuse is suspected.
Myocardial injury following blunt thoracic trauma in children is extremely rare but potentially lethal. Significant blunt cardiac injury resulting in major vessel disruption or cardiac rupture generally results in immediate death. There should be a high index of suspicion for blunt cardiac injury in children admitted to hospital with evidence of thoracic injury and a high­velocity mechanism. Although no consensus exists in children <14 years of age, most
,81 experts agree that a screening ECG and troponin level are reasonable. If there are any concerning features on cardiac FAST, ECG, thoracic CT, or elevated troponins, a transthoracic echocardiogram and urgent pediatric cardiology consultation are strongly recommended.
Commotio cordis is a rare condition reported in young athletes; a direct blow to the anterior chest at a critical time in the cardiac cycle results in cardiac
,83 dysrhythmia (usually ventricular fibrillation) and cardiac arrest.
IMAGING
Thoracic CT with angiography should be used selectively in the pediatric population given the high dose of ionizing radiation to sensitive tissues.
Although thoracic CT is more sensitive than chest radiograph for intrathoracic injuries, CT seldom results in significant changes in patient management. Thoracic CT should be reserved for patients with a high­risk mechanism of injury, such as rapid deceleration injury, and an abnormal
 chest radiograph. Note that tracheobronchial injuries may need to be further evaluated by bronchoscopy.
ABDOMINAL TRAUMA
Abdominal trauma is present in approximately 25% of major trauma patients and is the leading cause of unrecognized fatal injury in children. Ninety percent of abdominal trauma in children is blunt and may result from motor vehicle collisions, pedestrian injuries, falls, direct trauma (e.g., bicycle
 handlebar), or inflicted injury. Although penetrating trauma is less common in children, a quarter of gunshot wounds involve the abdomen, and

>10% of these injuries are fatal. Other causes of penetrating injuries in this age group include impalement, stab wounds, and animal bites.
The spleen is the most commonly injured solid organ, followed by the liver and kidney. Hollow viscus injuries involve the jejunum, duodenum, colon,
 and stomach (15%) in decreasing order of frequency. Pancreatic injuries are less commonly seen in pediatric abdominal trauma (<5%).
ABDOMINAL IMAGING AND CLINICAL DECISION RULES
Mechanism of injury is much less predictive of clinically important torso injuries than spine or musculoskeletal injuries. Furthermore, the abdominal
 exam can be misleading; 20% to 30% of children with a normal exam may have significant intra­abdominal injuries on imaging. A number of clinical decision rules have been developed to risk­stratify children with blunt abdominal trauma, and the approach to CT imaging depends on the level of clinical suspicion.
,88
Indications for CT in children at high risk of significant intra­abdominal injuries include :
Polytrauma victims with a history suggestive of severe intra­abdominal injury
Concerning physical exam findings: abdominal tenderness, peritonitis, a seatbelt sign or other bruising
Aspartate aminotransferase >200 IU/L or alanine aminotransferase >125 IU/L
Decreasing hemoglobin or hematocrit
Gross hematuria
The Pediatric Emergency Care Applied Research Network (PECARN) developed a rule to identify patients at very low risk for intra­abdominal injury requiring intervention (surgery, embolization, transfusion for abdominal bleeding, IV fluid requirement >48 hours). Children are classified as very low
,90 risk and may forgo CT imaging if they meet the following criteria :
No evidence of abdominal or thoracic wall trauma
Glasgow Coma Scale score >13
No abdominal pain or tenderness
Normal breath sounds
No vomiting after injury
Forty­two percent of the study population met these very low­risk criteria, among whom the risk of intra­abdominal injury requiring intervention was

.1%. The Pediatric Emergency Care Applied Research Network rule has a sensitivity of 97% and negative predictive value of .9%.
LIVER AND SPLEEN INJURIES
Nonoperative management is successful in >95% of children with solid organ injuries. Conservative management, with fluid resuscitation and
 monitoring with serial abdominal exams and laboratory tests (hemoglobin/hematocrit), is the mainstay of treatment. Furthermore, clinical status
,93 may better predict the need for admission or intensive care monitoring than grade of injury on CT. Blood transfusion, while uncommon, is the most frequent therapeutic intervention; angioembolization and laparotomy are reserved for patients who show evidence of active bleeding after
 resuscitation. Children who require splenectomy should receive vaccination against encapsulated bacteria (meningococcal and streptococcal pneumonia) as well as antibiotic prophylaxis. Pseudoaneurysm formation is a possible complication of liver and spleen injury, and ongoing
 monitoring may be required.
RENAL INJURY
Blunt renal injuries in children are seldom isolated, and multiorgan injuries are the rule. The risk of renal injury with blunt trauma is higher in children than adults due to their anatomy. Injury to the kidney is associated with rapid deceleration mechanisms (e.g., motor vehicle and pedestrian collisions, falls from height) or, less commonly, a direct blow to the flank (e.g., sports). Penetrating injury to the flank results in a much higher incidence of renal
 vascular injury, which is rare in blunt trauma.
Clinical findings include localized flank tenderness, ecchymosis, palpable flank mass, and penetrating wounds in proximity to the kidney.
Microscopic hematuria is common after blunt trauma and does not require further investigation as an isolated finding. Although gross hematuria indicates potential serious injury, up to 50% of patients with vascular hilar injuries have no hematuria. Furthermore, hematuria >50 red blood cells per high­powered field may also be associated with other solid organ injury, particularly splenic injuries. A four­phase CT with angiography, looking for renal extravasation, should be obtained in patients with history of significant force trauma and gross hematuria. The vast majority of renal injuries, including high­grade injuries, are treated conservatively. Minimally invasive procedures such as angioembolization, stenting,
,97 and percutaneous drainage are often used to manage complications.
PANCREATIC INJURY
The pancreas is the least commonly injured solid abdominal organ, and injury is usually due to focal upper abdomen trauma, often from bicycle handlebars. Pancreatic injuries are difficult to diagnose due to their nonspecific and indolent clinical presentation. Pancreatic enzymes are neither sensitive nor specific for pancreatic injury in pediatric blunt abdominal trauma: they can be elevated without otherwise demonstrable pancreatic injury and are normal in up to 30% of patients with complete pancreatic transection. Amylase and lipase may be more useful when measured more than 
 hours after injury or serially as pancreatic inflammation tends to increase over time. Ductal injuries can be difficult to identify on CT imaging, and patients with a suspected pancreatic duct injury may require magnetic resonance cholangiopancreatography or endoscopic retrograde
 cholangiopancreatography.
Most patients with pancreatic injury can be managed nonoperatively, with close monitoring and nutritional support. Management of major pancreatic injury with ductal transection remains controversial, although higher injury severity is associated with increased need for surgical intervention.
Patients with higher injury severity managed nonoperatively are at increased risk of pseudocyst formation, although two thirds of pseudocysts do not
,100 require surgery. The role of endoscopy and interventional radiology in these patients is currently being studied.
HOLLOW VISCUS INJURY
Intestinal trauma is less common than solid organ injury and is usually associated with motor vehicle versus pedestrian trauma, seatbelt injuries, or inflicted injury. Injury can result from a direct blow producing visceral compression or acceleration­deceleration forces at anatomic points of fixation, resulting in visceral and mesenteric tears. Visceral injuries include bowel perforation, bowel wall hematoma, and mesenteric tears. Acute symptoms are nonspecific and sometimes mild, and a high index of suspicion is required. Moreover, traditional CT imaging can miss important hollow viscus
101 injuries, and oral contrast adds little to the evaluation.
Observation and serial abdominal exams are therefore crucial, regardless of CT findings. Persistent or worsening abdominal pain, vomiting
(particularly bilious), or the development of peritonitis or fever should alert the clinician to the possibility of hollow viscus injury. Surgical exploration may be required for definitive diagnosis.
Duodenal injuries are often associated with handlebar injuries and classically present in a delayed manner  to  hours after the injury, as expansion
 of the hematoma causes partial or complete obstruction. Abdominal pain and bilious vomiting are the most common symptoms.
The seatbelt injury complex is a pattern of blunt abdominal injury seen in children who are inappropriately restrained with a lap belt positioned over the abdomen instead of the pelvic girdle. Acceleration­deceleration forces crush the bowel between the seatbelt and the spine. Classic findings include a “seatbelt sign” (abdominal wall contusion in the distribution of the lap belt), with small bowel injury and Chance fractures of the lumbar spine. Trauma from the lap belt is also associated with injury to the mesentery, renal vasculature, inferior vena cava, aorta, ureters, and solid organs. A seatbelt sign may be present in >15% of children with blunt torso trauma secondary to motor vehicle collisions and, when present, confers a greater
102 than fivefold increased relative risk of intra­abdominal injury requiring intervention. The presence of a Chance fracture is associated with a 50% incidence of associated intra­abdominal injury.
PEDIATRIC SPINE AND SPINAL CORD INJURY
PEDIATRIC CERVICAL SPINE TRAUMA
Guidelines for immobilization and imaging and information on specific injuries are provided in Chapter 112, “Cervical Spine Injury in Infants and
Children.”
PEDIATRIC THORACIC AND LUMBAR SPINE TRAUMA

Children account for only 2% to 5% of all spine injuries, and only 5% of pediatric fractures occur in the spine. Up to 60% of pediatric spine injuries
104 involve the thoracic or lumbar spine, with lumbosacral injuries accounting for two thirds of spinal injury hospitalizations. Pediatric spine injury has a bimodal age distribution, with one peak in children <5 years and another in children >10 years of age. Falls and motor traffic–related injury account for the first peak; motor vehicle collisions account for the majority of spine injuries in older children, although sports­related mechanisms are an
105 important cause of thoracolumbar spine injury in adolescents. Penetrating trauma accounts for <5% of pediatric spine injury, occurs primarily in
106 adolescents, and is associated with greater morbidity than blunt trauma.
The pediatric spine differs from that of adults in that children have greater ligamentous elasticity and flexibility, more horizontal facets, wedge­shaped vertebral bodies, and relatively weak musculature, particularly before the age of , with a transition toward adult anatomy and physiology after this age. Distraction forces can result in Salter­type fractures of the thoracolumbar spine in children, and anatomic differences make multilevel injuries
103,107 more common in children aged  to  years in the setting of compression forces.
Evaluate the pediatric spine during the secondary survey with careful palpation of the entire spine and paraspinous region for tenderness, step­offs,
103 crepitus, bruising, or open injuries. Physical examination is 87% sensitive and 75% specific for thoracolumbar injuries.
Obtain anteroposterior and lateral radiographs of the entire spine in all children with symptoms or signs of spinal injury during physical exam,
107 because up to one third of children with spine injury have two or more spinal fractures. CT scan should be limited to those with neurologic deficits, obvious bony injury on plain film, or significant concern for intra­abdominal or intrathoracic injuries requiring cross­sectional imaging for other reasons. Stable children with thoracolumbar spine injury associated with neurologic deficits should be imaged with MRI.
Thoracolumbar injuries can be classified using the Thoracolumbar Injury Classification and Severity Score System, which appears to be valid in
108 children as well as adults and can help guide the need for operative management. Generally speaking, clinically stable pediatric fractures without associated neurologic deficits can be treated nonoperatively. Moderate injuries not necessitating surgical decompression or fixation may be considered for bracing depending on age and the extent of injury (e.g., thoracolumbosacral orthosis). Scoliosis can be a sequel to spinal cord injury,
109 particularly among younger children.
Compression fractures are the most common fracture in the thoracolumbar spine and are usually stable and managed nonoperatively. Fractures of the spinous or transverse processes are often associated with blunt trauma and carry low risk for associated visceral injury; most of these fractures are managed with analgesics and rest, often without immobilization. The flexion­distraction injury known as the Chance fracture deserves special consideration, given the high rate of concomitant intra­abdominal injury.
PEDIATRIC SPINAL CORD INJURY

Pediatric spinal cord injury is uncommon, with an estimated annual incidence of  per million population under  years. Children under  years of age account for only 10% of spinal cord injuries, which are often related to motor vehicle collisions and involve the cervical spine (60% to 80%) far
 more commonly than the thoracolumbar spine.
Overall, neurologic recovery is better among children than adults with traumatic spinal cord injury, with incomplete injuries associated with better outcomes. Spinal cord injury without radiographic abnormality, a unique pediatric entity, is far more common in the thoracic spine than the
107 lumbar spine. Spinal cord injuries are frequently associated with other injuries, with rates ranging from 40% to 60%, and most commonly involve
107 the torso, extremities, and cranium.
The clinical evaluation and presentation of spinal cord injury and syndromes as well as the principles of physical examination and stabilization are similar to those of adults (see Chapter 258, “Spine Trauma”). As with adults, flaccid paralysis with hypotension and relative bradycardia suggests neurogenic shock; early administration of vasopressors is recommended, as aggressive fluid administration can worsen spinal cord edema.
Corticosteroids are not recommended to treat acute spinal cord injury in children.Steroids increase the risk of infection and do
 not result in significant neurologic improvements in children.
TRAUMATIC ARREST

Emergency thoracotomy has no role in blunt traumatic arrest in children. As in adults, the resuscitation of children with blunt traumatic arrest should focus on addressing reversible causes, with deemphasis on CPR and vasoactive agents. Key interventions include (1) obtaining a definitive airway, (2) managing major external bleeding, (3) chest decompression and assessment for cardiac tamponade, and (4) administering blood. If there is no return of circulation after these steps, the child is unlikely to survive, and a prolonged resuscitation is futile. ED thoracotomy should be considered for children with penetrating chest injuries who lose vital signs during transport or in the trauma bay, especially if there are signs of life. Keep in mind,
110,111 emergency thoracotomy poses substantial risk of injury to staff.


