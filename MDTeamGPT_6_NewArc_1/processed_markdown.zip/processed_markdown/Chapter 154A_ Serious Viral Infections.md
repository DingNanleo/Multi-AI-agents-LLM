## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 154A: Serious Viral Infections
Sukhjit S. Takhar; Gregory J. Moran
INTRODUCTION
Content Update: October 2022
Monkeypox (pathophysiology, clinical features, vaccination, treatment, and prevention) is discussed at the end of the chapter, in the section Human
Monkeypox Infections.
Content Update: February 2022. CORONAVIRUS­19 (COVID­19) is now discussed in Chapter 154­B, with most recent update for that chapter in February 2022. Coronavirus discussion is deleted from this chapter.
New information on vaccines for Dengue and Ebola are in the sections of this chapter, Dengue fever is discussed in the section Arboviral Infections, and Ebola is discussed in the section Ebola Virus Disease and Other Hemorrhagic Fevers.
Viral infections are among the most common illnesses encountered in the ED. Although many are self­limited, some are life­threatening, have specific treatments, or have public health implications. We review serious viral infections that cause disseminated illness, viruses with a predilection for the neurologic system, and new viral threats.
INFLUENZA
Human influenza infection comes from a large, single­stranded RNA virus in the orthomyxovirus family. Influenza A and influenza B cause most human infections, with influenza A typically being more serious.
EPIDEMIOLOGY
Influenza is highly infectious and transmitted via aerosolized respiratory secretions, large droplets, or fomites. Seasonal influenza has varying severity, typically peaking in the winter months of temperate climates. Seasonal disease causes 250,000 to 500,000 annual deaths worldwide and between 5000 and ,000 deaths in the United States. Outbreaks spread quickly throughout a community, largely among school­age children. Mortality occurs mostly among the elderly and young infants.
Influenza viruses undergo minor variations (antigenic drift) in their surface antigens that allow the virus to reinfect individuals and reemerge each winter. Occasionally, there are major antigenic changes that increase population susceptibility and lead to a pandemic. The 1918 influenza pandemic killed between  million and 100 million people worldwide; the potential for a recurrence with devastation from a novel influenza virus understandably drives anxiety among clinicians and public health personnel. Mortality during pandemics occurs more frequently among healthy adults compared to seasonal influenza, when the infirm and those at the extremes of age are more likely to die. In 2009, a pandemic H1N1 strain emerged in Mexico and followed this pandemic pattern. Highly pathogenic avian strains of influenza emerged from China, including the H5N1 strain in
1997 and, more recently, the H7N9 strain in 2013. PATHOPHYSIOLOGY

Chapter 154A: Serious Viral Infections, Sukhjit S. Takhar; Gregory J. Moran 
Influenza is transmitted usually by sneezing or coughing and via touching hands. The incubation period is typically  to  days. Viral replication in
. Terms of Use * Privacy Policy * Notice * Accessibility upper and lower respiratory tract epithelium leads to cell damage and respiratory symptoms. Most infections resolve within about a week, but viral pneumonia is one of the more common complications that can result in alveolar damage and hypoxemia.
CLINICAL FEATURES
Patients with influenza typically present with an abrupt onset of fever and respiratory symptoms. Most cases are self­limited; however, some patients, particularly the elderly, the very young, and those with comorbid conditions, require hospitalization or die from complications of influenza.
Additionally, influenza can lead to exacerbations of chronic medical conditions, such as congestive heart failure or chronic obstructive lung disease.
Delirium is common in the elderly.
Pneumonia complicates some influenza infections. Primary influenza pneumonia develops quickly and can progress to acute respiratory distress syndrome (ARDS), often within  hours. Bacterial superinfections also occur. Classically, secondary Staphylococcus aureus pneumonia, including community­acquired methicillin­resistant S. aureus, can follow influenza infection.
DIAGNOSIS
Most cases of influenza are diagnosed clinically when a patient presents with fever, aches, and cough with influenza virus circulating in the community. However, clinical features of influenza overlap with other respiratory infections; laboratory confirmation can occasionally be helpful with patient care and infection control, especially before influenza emergence is clear.
Rapid antigen assays identify the surface proteins in influenza A and B. These tests are simple to perform and give results within  minutes. However, they often have low sensitivity, with ranges between 10% and 80% reported in clinical use. Specificity of these tests is between 90% and 95%, so a positive test indicates high likelihood of influenza during an outbreak.
Molecular diagnostic tests, such as polymerase chain reaction for nucleic acids, are more sensitive and specific than antigen tests. These tests are best
 used in patients hospitalized with suspected influenza. Several nucleic acid–based tests can return results within the time frame of an ED visit, although they are more costly than rapid antigen tests.
TREATMENT
The majority of patients will have a self­limited, uncomplicated illness requiring only symptomatic care. Patients with more severe influenza may benefit from IV fluids, respiratory support, and occasionally vasopressors (if signs of shock exist). Treat patients with pneumonia with antibiotics, targeting methicillin­resistant S. aureus if severe pneumonia exists. Extracorporeal membrane oxygenation (ECMO) aids those with severe cardiorespiratory dysfunction, especially in pandemic settings when younger patients are afflicted.

Neuraminidase inhibitors have limited roles in otherwise healthy adults and children ; the Centers for Disease Control and Prevention recommends treating higher­risk populations. In the non–higher­risk population (i.e., relatively healthy patients outside extremes of age), a modest symptoms benefit exists if the patient starts therapy within  hours of symptom onset. Antiviral treatment may benefit patients hospitalized with influenza or bacterial complications of influenza even if started after  hours of illness. Consider empiric antiviral treatment for patients with severe or progressive illness and those with higher risk of complications (Table 154­1).
TABLE 154­1
Risk Factors for Severe Influenza4
Children younger than age  y
Adults age  y and older
Comorbid conditions
Immunosuppression
Pregnancy
Patients younger than  y receiving long­term aspirin
American Indians/Alaskan natives
Morbid obesity
Residents of nursing homes and long­term care facilities
The Centers for Disease Control and Prevention posts updates regarding influenza treatment, which can be helpful for clinicians
(http://www.cdc.gov/flu/professionals/antivirals/summary­clinicians.htm).
Oseltamivir is the most widely used neuraminidase inhibitor (75 milligrams twice daily for  days), with longer treatment for critically ill patients. For chemoprophylaxis, the dose is  mg once a day for 1­2 weeks. Peramivir is an IV neuraminidase inhibitor for those unable to tolerate oral oseltamivir.
Baloxavir is an endonuclease inhibitor approved for those  years and older. It is given as a single PO dose,  milligrams for those 40­80 kg, and 
 milligrams for those >  kg. It is not approved for chemoprophylaxis.
HERPES SIMPLEX VIRUS INFECTIONS
Herpes simplex virus type  (HSV­1) and herpes simplex virus type  (HSV­2) are related double­stranded DNA viruses that cause oral and genital infections; rarely, these result in devastating CNS disease. Herpes simplex infections are treatable with antiviral drugs, making early recognition of serious infection important.
EPIDEMIOLOGY
HSV is common throughout the world. HSV­1 is usually acquired during childhood through nonsexual contact; HSV­2 is almost always sexually transmitted (see Chapter 153, “Sexually Transmitted Diseases”). HSV­1 seroprevalence varies by socioeconomic status, age, and geographic location.

More than 50% of the U.S. population is seropositive for HSV­1, and .7% is seropositive for HSV­2. HSV­1 is one of the most common viral causes of
 encephalitis in the United States. It occurs most commonly in patients <20 and >50 years of age. The mortality rate for untreated disease is >70%.
Neonates with HSV infection have a high frequency of both visceral involvement and CNS disease. Encephalitis in neonates is acquired from the maternal genital tract at the time of delivery. The risk is highest when the mother acquires the infection in the third trimester.
PATHOPHYSIOLOGY
HSV infections are transmitted through contact with persons with ulcerative lesions or by those who are shedding the virus by the exchange of saliva, vesicle fluid, semen, and cervical fluid. The virus must come in contact with a mucosal surface or abraded skin, where it replicates and causes localized symptoms before becoming latent in the sensory ganglia. HSV­1 typically resides in the trigeminal ganglia, and HSV­2 is found in the sacral ganglia.
Reactivated virus travels to the cutaneous surface and results in localized vesicular eruptions (Figure 154­1).
FIGURE 154­1
Herpes simplex virus infection, latency, and recurrence. A. Primary infection. B. Latent phase. C. Recurrence. [Reproduced with permission from Wolff
K, Johnson RA: Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 6th ed., © 2009 by McGraw­Hill, Inc., New York.]
In herpes simplex encephalitis, experts postulate the virus gains access to the brain by the olfactory or the trigeminal nerve, with a predilection for the medial and inferior temporal lobes of the brain.
Most healthy hosts are able to control the virus and limit its replication to mucosal surfaces. Rarely during primary infection, the virus can spread beyond the local dorsal root ganglia and cause more widespread involvement. Multiorgan disease is much more common in the immunosuppressed and in neonates.
CLINICAL FEATURES
HSV infections occur year­round. Symptoms of HSV depend on multiple factors, including the anatomic site involved, the immune status of the host, virus type, and whether the infection is primary or recurrent. Most HSV infections are subclinical. Symptomatic HSV­1 infection most commonly results in recurrent orolabial lesions, whereas HSV­2 is most often implicated in genital herpes. Primary infections typically produce more extensive lesions involving mucosal and extramucosal sites, often accompanied by systemic signs and symptoms. Gingivostomatitis and pharyngitis are typical manifestations of primary HSV­1 infection (Figure 154­2), and recurrence presents as herpes labialis (Figure 154­3). Less common skin manifestations include herpetic whitlow and herpes gladiatorum (skin). For additional discussion, see Chapter 250, “Skin Disorders: Face and Scalp,” and Chapter 253, “Skin Disorders: Extremities.”
FIGURE 154­2
Primary herpetic gingivostomatitis. Typical lesions of herpes gingivostomatitis on the buccal mucosa. [Reproduced with permission from Shah BR,
Lucchesi M: Atlas of Pediatric Emergency Medicine, © 2006 by McGraw­Hill, Inc., New York.]
FIGURE 154­3
A through D. Herpes labialis. Typical vesicular lesions of the upper and lower lip. [Reproduced with permission from Wolff K, Johnson RA:
Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 6th ed., © 2009 by McGraw­Hill, Inc., New York.]
Eczema herpeticum (see Figure 251­14) can occur in patients with atopic dermatitis. Bell’s palsy may result from latent HSV­1 in the geniculate ganglia
(see Chapter 172, “Acute Peripheral Neurologic Disorders”). Herpetic keratitis presents as a painful, red eye and can be identified by characteristic dendritic lesions on fluorescein slit lamp exam. See Chapter 241, “Eye Emergencies,” for further discussion. HSV­1 and HSV­2 can cause identical
 genital lesions. Genital HSV­2 is more common and has a higher relapse rate, but the proportion of genital disease caused by HSV­1 is increasing.
Primary genital infections can present with aseptic meningitis, which is a complication more common in women.
The hallmark of HSV encephalitis is acute onset of fever and neurologic symptoms. Patients can present with hemiparesis, cranial nerve abnormalities, ataxia, focal seizures, and altered mental status or behavioral abnormalities. It can be difficult to distinguish HSV encephalitis from other types of meningoencephalitis. Meningitis occurs in up to 25% of females with primary HSV­2 infections. HSV­2 meningitis, unlike encephalitis, has a benign course, and patients recover uneventfully, although many patients have recurrent episodes.
HSV infections in immunocompromised hosts can lead to widespread dissemination with multiorgan involvement (Figure 154­4). Organ transplant patients may develop esophagitis, hepatitis, colitis, and pneumonia (see Chapter 297, “The Transplant Patient”). Severely burned patients are also prone to potentially fatal disease. HSV infections can also cause immune­mediated manifestations such as erythema multiforme, hemolytic anemia, and thrombocytopenia.
FIGURE 154­4
Disseminated herpes simplex in an immunocompromised host. The rash of disseminated herpes simplex begins as vesicular lesions on an erythematous base, which may umbilicate and may blister and crust over as seen here. [Reproduced with permission from Wolff K, Johnson RA:
Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 5th ed., © 2005 by McGraw­Hill, Inc., New York.]
DIAGNOSIS
The preferred diagnostic test for confirmation of suspected HSV infection depends on the presentation. Because mucocutaneous infection is lifelong, most recommend laboratory confirmation of the clinical diagnosis of primary HSV infection. Viral culture from the fluid of an unroofed vesicle is traditionally the reference criterion for diagnosis. However, polymerase chain reaction testing or a direct fluorescent antibody test have higher sensitivity. A Tzanck smear is not useful.
Identification of temporal lobe lesions on CT scan or MRI is strongly suggestive of HSV encephalitis (Figure 154­5). An electroencephalogram shows typical intermittent, high­amplitude slow waves localized to the temporal lobes.
FIGURE 154­5
MRI scans showing hyperintensity involving the left temporal lobe and insular cortex in herpes simplex encephalitis. A. T2­weighted coronal MRI scan in the axial plane, taken during the acute stage of the illness. There is increased signal from practically all of the inferior and deep temporal lobe and the insular cortex. B. T1­weighted image after gadolinium infusion showing enhancement of the left insular and temporal cortices and early involvement of the right temporal lobe. [Reproduced with permission from Ropper AH, Samuels MA: Adams and Victor’s Principles of Neurology, 9th ed., © 2009 by McGraw­Hill Inc., New York.]
Cerebrospinal fluid analysis typically shows a lymphocytic pleocytosis with the presence of red blood cells. However, some patients have normal cerebrospinal fluid parameters. Polymerase chain reaction testing of the cerebrospinal fluid is the testing modality of choice for HSV
 meningoencephalitis, with high sensitivity and specificity. Detectable viral DNA in the cerebrospinal fluid occurs within the first  hours, and results remain positive for a week or longer. Multiplex polymerase chain reaction panels are available to test cerebrospinal fluid for HSV and other viral, bacterial, and fungal pathogens.
TREATMENT
Treatment depends on the severity of the disease and the immune status of the patient (see Chapter 153, “Sexually Transmitted Diseases”). IV acyclovir is the drug of choice in patients with HSV encephalitis or disseminated disease and in immunocompromised patients with severe mucocutaneous disease (Table 154­2). Valacyclovir is a prodrug of acyclovir with less frequent dosing.
TABLE 154­2
Antiviral Treatment of Severe Herpes Simplex Virus (HSV) Infection
Infection Drug Dosage Duration
Mucocutaneous HSV infections in immunocompromised patients Acyclovir  milligrams/kg IV every  h 7–14 d
Valacyclovir 500 milligrams–1 gram PO twice per day
Famciclovir 500 milligrams PO twice per day
Herpes simplex encephalitis Acyclovir 10–15 milligrams/kg IV every  h 14–21 d
Neonatal herpes simplex Acyclovir 10–20 milligrams/kg IV every  h 14–21 d
Visceral herpes simplex disease Acyclovir 10–15 milligrams/kg IV every  h 14–21 d
Even with early treatment, patients with HSV encephalitis have a high mortality. Without treatment, mortality is >70%. Survivors are often left with longterm neurologic sequelae. Independent predictors of a poor outcome for patients with HSV encephalitis include a Glasgow Coma Scale score of ≤6,
 focal CNS lesions on CT scan, increased patient age, and start of antiviral therapy >4 days after onset of symptoms. Because altered mental status and focal neurologic abnormalities are key features of encephalitis and because it can be clinically difficult to distinguish meningitis from encephalitis, consider adding acyclovir to empiric antibiotic therapy in patients with these neurologic findings
 when the diagnosis of acute bacterial meningitis is also being considered.
Healthy patients with primary HSV­1 or HSV­2 infections can be treated with oral acyclovir, valacyclovir, or famciclovir for  to  days. Recurrent herpes labialis usually does not require treatment. Those with severe or frequent recurrences may benefit from daily suppressive therapy.
VARICELLA AND HERPES ZOSTER
Varicella­zoster virus is the causative organism of both varicella (chickenpox) and herpes zoster (shingles). It is extremely contagious; prior to routine vaccination, it was usually acquired in childhood.
Varicella occurs year­round, but there is a higher incidence during winter and spring months. The infection rate ranges from 60% to 100% in exposed individuals. The introduction of the varicella vaccine to routine childhood immunizations in 1995 has dramatically reduced the clinical burden of the
 virus.
Herpes zoster can occur once immune response against the virus wanes, usually with advancing age. Over 90% of adults have serologic evidence of
 varicella­zoster virus infection, and unvaccinated persons who live to  years of age have a 50% risk of herpes zoster. Iatrogenic immune suppression, certain diseases such as lymphoproliferative disorders, human immunodeficiency virus infection, and organ transplantation increase the risk of herpes zoster.
Vaccines are available to prevent both chickenpox and herpes zoster, although neither is 100% effective. Encourage parents to vaccinate their children, and remind those age  years or older about the availability of a vaccine to prevent herpes zoster. Varicella­zoster immune globulin is available, but its use is generally limited to postexposure prophylaxis for nonimmune pregnant women and the severely immunosuppressed. Healthy individuals who are not immune can be vaccinated after exposure. Watch varicella­zoster virus–exposed individuals and give antivirals to high­risk patients if they
 develop symptoms.
PATHOPHYSIOLOGY
Varicella­zoster virus spreads to the respiratory mucosa of a susceptible host via aerosolized droplets of respiratory secretions of patients with chickenpox. It can also spread from direct contact with vesicle fluid in herpes zoster but is not as highly contagious in this situation. The virus multiplies in regional lymph nodes and then disseminates to the nasopharyngeal surfaces and the skin, causing the characteristic rash. It is contagious until all the lesions have crusted over. VZV remains latent in the dorsal root ganglion and can later reactivate along dermatomes, resulting in shingles
(Figure 154­6).
FIGURE 154­6
Primary infection, latency, and reactivation of varicella­zoster virus. A. Generalized distribution of primary varicella with infection of sensory ganglia.
B. Latent phase with persistence in ganglia. C. Reactivation phase with descent to sensory nerves and skin involvement. [Reproduced with permission from Wolff K, Johnson RA: Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 6th ed., © 2009 by McGraw­Hill, Inc., New York.]
VARICELLA CLINICAL FEATURES
Varicella (chickenpox) is a febrile illness with a vesicular rash. Often it is associated with nonspecific symptoms of headache, malaise, and loss of appetite. The rash is superficial and appears in crops, so patients typically have lesions at varying stages, including papules, vesicles, and crusted lesions (Figure 154­7). Lesions are concentrated more on the torso and face and typically crust and slough off after  to  weeks. Most infections are minor and self­limited. Immunized patients can occasionally develop mild chickenpox.
FIGURE 154­7
Rash of primary varicella (chickenpox), demonstrating lesions of multiple stages, including papules, vesicles, and crusted lesions. [Reproduced with permission from Wolff K, Johnson RA: Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 6th ed., © 2009 by McGraw­Hill, Inc., New York.]
A range of complications can occur, more often in those at extremes of age or the immunocompromised. Bacterial superinfections of skin lesions, most often with group A streptococci, can cause serious illness including necrotizing fasciitis. Children with lymphoma and leukemia may develop progressive varicella in which vesicles continue to erupt into the second week of illness, sometimes with visceral involvement of the lung, liver, and brain. CNS complications such as cerebellar ataxia, meningitis, meningoencephalitis, and vasculopathy are well described. Pneumonitis can be
 severe and is more common in pregnant women.
HERPES ZOSTER CLINICAL FEATURES
Herpes zoster (shingles) often begins with a prodrome of malaise, headache, and photophobia. The patient notes pain, itching, and paresthesias in one or more dermatomes. These symptoms are followed by the development of a maculopapular rash that becomes vesicular. The eruption does not cross the midline (Figure 154­8). Most commonly, herpes zoster affects the chest or face, but it can affect any dermatomal level. Herpes zoster ophthalmicus can cause corneal damage and is the result of reactivation along the ophthalmic distribution of the trigeminal nerve (see Chapter 241,
“Eye Emergencies”). The seventh cranial nerve involvement can trigger facial nerve paralysis and lesions along the auditory canal (herpes zoster oticus). Postherpetic neuralgia, pain that persists for >30 days, is a feared complication. The incidence increases with advancing age, and pain may last months or years.
FIGURE 154­8
Dermatome distribution of the classic rash of herpes zoster (shingles).
Dissemination of varicella­zoster virus can occur in immunocompromised patients. Herpes zoster involving more than three dermatomes is often a clue to an immunodeficient condition. The presence of herpes zoster in a young, healthy person may be a sign of human immunodeficiency virus infection. In many cases of disseminated disease, the skin is the only involved structure. However, the virus may spread to the visceral organs and cause pneumonitis, hepatitis, and encephalitis.
DIAGNOSIS
Varicella­zoster virus infections have a characteristic appearance, so a clinical diagnosis is sufficient in most cases. Look for the characteristic rash of chickenpox, which involves vesicles in crops at different stages of development. Herpes zoster diagnosis is clear when clusters of vesicles and papules appear in a dermatomal pattern.
Laboratory diagnosis aids in patients with atypical illness or severe disease. This is accomplished through viral culture, antigen testing, or polymerase chain reaction testing of vesicle fluid. Although smallpox has been eradicated, it remains a potential threat as a biologic weapon, and the lesions could be confused with those of varicella. The lesions of smallpox are larger and distributed more on the extremities, and all lesions are at the same stage of development.
Obtain a chest radiograph if there are any breathing symptoms to assess for pneumonitis. An MRI of the brain, lumbar puncture, and polymerase chain reaction cerebrospinal fluid testing for varicella­zoster virus are appropriate for suspected neurologic involvement.
VARICELLA TREATMENT
Most healthy patients need only supportive care for chickenpox. Acyclovir and similar antiviral agents decrease the number of lesions and shorten the course of therapy if started within  hours of rash onset. However, the impact of treatment is modest, so it is not routinely recommended for those who are otherwise healthy. Secondary skin infections are typically caused by group A streptococci and can be treated with a first­generation cephalosporin.
Consider acyclovir for those at higher risk for complications, including adults and children >12 years of age, patients with chronic skin or pulmonary disorders, those receiving long­term salicylate therapy, and immunocompromised patients. Varicella­zoster virus is less sensitive to antiviral medications than herpesvirus and requires higher and more frequent dosing.
HERPES ZOSTER TREATMENT
Antiviral agents hasten lesion resolution, reduce new lesions, reduce viral shedding, and decrease acute pain, but do not reduce the severity of
 postherpetic neuralgia. Using antiviral therapy in immunocompromised patients may reduce the risk of severe disseminated disease. Start antiviral medication within  hours of the onset of rash, and consider treatment at >72 hours if new vesicles are still present or developing. Treat immunocompromised patients regardless of the time since rash onset. Benefits are more pronounced in patients >50 years of age. Therapy is well tolerated, and adverse events are infrequent.
Treat those with disseminated herpes zoster, those with CNS involvement, and severely immunosuppressed patients with herpes zoster with IV acyclovir. Use valacyclovir in those with herpes zoster ophthalmicus, along with ophthalmologist consultation (see Chapter 241, “Eye Emergencies”).
Herpes zoster can be extremely painful and require opioid analgesia. Corticosteroids in combination with antivirals may provide a modest decrease in
 acute pain, but do not decrease the development of postherpetic neuralgia. Adjunctive corticosteroids can be considered in older individuals with severe pain who do not have contraindications to their use.
EPSTEIN­BARR VIRUS INFECTION
Epstein­Barr virus is implicated in a variety of human illnesses. It is the causative agent of heterophile­positive infectious mononucleosis. Epstein­Barr virus infection is also associated with cancers such as B­cell lymphoma, Hodgkin’s disease, Burkitt’s lymphoma, and nasopharyngeal carcinoma.
There are two age­related peaks of infection: early childhood and young adulthood. In developing countries, Epstein­Barr virus infection is widespread in early childhood and is often asymptomatic. College students and military recruits experience the highest morbidity. Epstein­Barr virus requires close contact for transmission. The infection is usually contracted from an asymptomatic individual who sheds the virus.
PATHOPHYSIOLOGY
Epstein­Barr virus is transmitted via salivary secretions. After infecting the oropharyngeal epithelium, it disseminates through the bloodstream. The virus infects B lymphocytes and causes an increase in T lymphocytes, which results in enlargement of lymphoid tissue. In immunocompromised patients with decreased T­cell function, the B cells continue to proliferate, and proliferation may lead to neoplastic transformation.
CLINICAL FEATURES
The manifestations of Epstein­Barr virus infection depend on age and immune status. Infections in infants and young children are often asymptomatic or have mild pharyngitis. Teenagers and young adults can develop infectious mononucleosis, which presents as fever, lymphadenopathy, and pharyngitis. Tonsillar exudates are frequent and often extensive and may be necrotic appearing (Figure 154­9). Splenomegaly occurs in more than half of patients. Symptoms generally resolve over  to  weeks, and most patients recover uneventfully. Severe fatigue is a prominent feature and can persist for months. Patients treated with ampicillin or amoxicillin for suspected streptococcal pharyngitis often develop a nonallergic morbilliform rash if they have infection with Epstein­Barr virus.
FIGURE 154­9
Classic findings of tonsillopharyngitis associated with infectious mononucleosis caused by Epstein­Barr virus. [Reproduced with permission from Shah
BR, Lucchesi M: Atlas of Pediatric Emergency Medicine, © 2006 by McGraw­Hill, Inc., New York.]
Epstein­Barr virus can affect nearly all organ systems. Neurologic complications such as encephalitis, meningitis, and Guillain­Barré syndrome have been described. Hepatitis, myocarditis, and hematologic disorders are also known complications. Rarely, death results from splenic rupture, CNS complications, and airway obstruction.
DIAGNOSIS
If suspecting infectious mononucleosis based on the history and physical examination, a CBC and a monospot test aid in diagnosis. Typically, there is lymphocytosis with >50% lymphocytes, and atypical lymphocytes are found on examination of the smear. These are reactive cytotoxic T cells that can also be found in other illnesses, including cytomegalovirus infection, human immunodeficiency virus infection, and viral hepatitis. The monospot test identifies heterophile antibodies that agglutinate animal erythrocytes, and a positive result is considered diagnostic of Epstein­Barr virus infection in the right clinical setting. The monospot test result may be negative early in the course of disease (first days), requiring a second test later if unclear. The sensitivity of the test is also decreased in infants and the elderly. Testing is particularly important in pregnant patients, because some other causes of heterophile­negative mononucleosis, such as toxoplasmosis and cytomegalovirus, can be teratogenic.
TREATMENT
Rest and analgesia are the mainstays of therapy, with most cases being self­limited and not requiring specific therapy. Corticosteroid use may increase complications and is recommended only for patients with severe disease, such as upper airway obstruction, neurologic disease, or hemolytic anemia. Acyclovir is active against Epstein­Barr virus, but is thought to be effective only for oral hairy leukoplakia associated with human immunodeficiency virus infection. Advise patients to avoid all contact sports for a minimum of  weeks after illness onset to
 avoid splenic injury.
CYTOMEGALOVIRUS INFECTION
Cytomegalovirus causes a wide variety of diseases, ranging from asymptomatic infections in most to life­threatening pneumonia in transplant patients.
Like other herpesviruses, it causes a primary infection and then recedes into lifelong latency.
Cytomegalovirus is not highly contagious, and transmission requires repeated or prolonged exposure. The virus is spread by sexual contact, saliva, breastfeeding, and transplantation, as well as transplacentally and through blood transfusion. Seroprevalence rates approach 100% in Africa and in some Asian countries. In the developed world, it is not unusual for older individuals to acquire a primary infection. This is of particular concern in women of childbearing age because of teratogenic effects. The risk of fetal cytomegalovirus infection is highest in the first trimester of pregnancy in a previously seronegative mother who acquires a primary infection.
Organ transplant patients can acquire infection, most often between  and  months after transplant. The risk is highest when a seronegative patient receives a cytomegalovirus­positive organ.
PATHOPHYSIOLOGY
Cytomegalovirus is usually inoculated on the mucosal surface of the upper respiratory or genital tract, where the virus multiplies and then disseminates. Most infections are only mildly symptomatic. Primary disease in late adolescence and adulthood results in an infectious mononucleosis syndrome. The virus remains latent in most individuals unless immunity is suppressed.
CLINICAL FEATURES
Primary infection in healthy individuals is usually asymptomatic. Cytomegalovirus can cause a heterophile­negative infectious mononucleosis syndrome, characterized by prolonged fever, myalgias, and atypical lymphocytosis, but no exudative pharyngitis, and mild lymphadenopathy. Severe
 disease in the otherwise healthy host includes hepatitis, colitis, Guillain­Barré syndrome, encephalitis, and hemolytic anemia.
Congenital and neonatal infections have some of the most important complications of primary cytomegalovirus infection. Symptoms in infants can be devastating and include hepatosplenomegaly, jaundice, microcephaly, petechiae, and growth retardation. Severe infections carry a high mortality, and those who survive often have neurologic sequelae.
Infections in immunocompromised patients can be severe and involve any organ. Infection can be primary or the result of reactivation of latent virus.
Severe disease can develop in previously healthy cytomegalovirus­seropositive individuals with an abnormal T­cell response during critical illness.
Infections after solid­organ and hematopoietic stem cell transplantation are a leading cause of morbidity (see Chapter 297, “The Transplant

Patient”). In human immunodeficiency virus–infected patients with CD4 counts of <50 cells/mm , retinitis is the most common manifestation of infection, causing painless loss of vision. Other manifestations associated with human immunodeficiency virus infection include encephalopathy, colitis, and peripheral polyradiculopathy.
DIAGNOSIS
A specific diagnosis is usually not made in the ED. Body fluids such as urine, saliva, blood, tears, semen, and vaginal fluid are antigen, polymerase chain reaction, and antibody tested, and tissue is examined or cultured for diagnosis. The hallmark of cytomegalovirus infection on histologic examination is a large cell containing a large basophilic intranuclear “owl’s eye” and intracytoplasmic inclusion bodies.
TREATMENT
Several systemic antiviral agents are active against cytomegalovirus infection, including ganciclovir, valganciclovir, foscarnet, and cidofovir. These medications are not started absent consultation with an infectious disease or a transplant specialist. Illness in the otherwise healthy host is usually self­limited and does not require antiviral therapy. Cytomegalovirus­induced infectious mononucleosis is treated symptomatically.
MEASLES
Measles is used to describe rubeola (Morbillivirus) and rubella (Rubivirus), both of which are covered in the MMR (Measles, Mumps, Rubella) vaccine.
Rubella infection is typically mild, but when contracted during pregnancy is teratogenic. The current global measles epidemic is due to Rubeola.
Rubeola is the most infectious virus known to humans and is communicable before symptoms begin. Most measles deaths occur among children in developing countries, but developed countries are now seeing outbreaks related to parents choosing not to vaccinate their children, largely due to unfounded fears about vaccine safety. After an incubation period of  to  days, illness starts with fever, malaise, cough, and runny nose, often with conjunctivitis. Small, white Koplik’s spots (Figure 154­10) appear on the buccal mucosa early in the illness, followed by a red maculopapular rash that typically starts on the head and spreads throughout the body. Diagnosis is usually clinical, with pathognomonic Koplik’s spots and the characteristic rash. Measles confirmation is by detecting immunoglobulin M antibodies, which are present at rash onset. Polymerase chain reaction testing of urine and throat specimens also is a reference criterion for diagnosis, and can distinguish true measles from IgM elevation with recent vaccination. Results typically take several days. Treatment is supportive, with particular attention to ensuring adequate nutrition, especially vitamin A.
Mortality in developed countries is <1 per 1000, but can be up to 20% to 30% among infants in developing countries, often from pneumonia. Most measles suspects can be discharged home with instructions to watch for symptoms of complications such as pneumonia or encephalitis. Suspects should be reported immediately to local public health authorities prior to discharge; they can provide guidance on testing, quarantine, and postexposure management of contacts. See Chapter 142, “Rashes in Infants and Children,” for further discussion of Measles (rubeola) and rubella.
FIGURE 154­10
Oral Koplik’s spots on day  of measles. [Reproduced with permission from Nester EW, Anderson DG, Roberts CE Jr, Nester MT: Microbiology: A Human
Perspective, 6th ed. New York: McGraw­Hill, Inc., 2008.]
Because measles is so highly infectious, EDs should have protocols for identification of measles suspects at initial point of contact based on characteristic symptoms in the setting of local outbreak or recent travel to an outbreak area. Measles suspects should be immediately placed in airborne isolation. It is helpful to public health to identify family contacts of high­risk suspects in the ED and offer vaccination. It can also be helpful to save a log of potential exposures of both ED staff and other patients at the time of the visit, in case it is later confirmed as measles. See the following for current CDC information: https://www.cdc.gov/measls/hcp/index.html.
ARBOVIRAL INFECTIONS
Arboviral infections are spread by biting mosquitoes, ticks, and flies. Japanese encephalitis is one of the most common and important causes of encephalitis in the world. The emergence of West Nile virus infection renewed interest in North America about epidemic viral encephalitis. This section
,15 reviews some of the more important and severe arboviral infections, concentrating on those that occur in North America (Table 154­3). Other significant arboviral diseases are discussed in Chapter 162, “Global Travelers.”
TABLE 154­3
Arboviral Infections in North America
Virus Geographic Distribution Groups at Highest Risk
West Nile virus United States, Canada, Mexico Elderly adults
St. Louis encephalitis virus United States, Canada, Mexico Elderly adults
La Crosse virus Central, northeastern United States Children
Eastern equine encephalitis virus Eastern and Gulf Coast states, eastern Canada All ages
Western equine encephalitis virus Western and midwestern United States and western Canada Infants and elderly adults
Venezuelan equine encephalitis virus Florida, Texas, Mexico All ages
Dengue virus Mexico, Caribbean All ages
Zika virus Mexico, Caribbean Women of childbearing age
EPIDEMIOLOGY
Arboviral infections tend to be seasonal, with increased incidence in warmer months due to the breeding patterns of the arthropod vectors. The major hosts are mammals and birds. When migratory birds are involved, the virus can spread quickly over large distances. Humans are usually an incidental host and acquire the diseases when they venture into areas occupied by the reservoir host.
The age group affected often depends on local prevalence. Japanese encephalitis, which is highly endemic in certain parts of Asia, usually affects children. Most adults have been exposed and are immune. Elderly adults are at risk for St. Louis encephalitis.
Dengue, yellow fever, Rift Valley fever, and chikungunya viruses are among the viruses causing hemorrhagic fever syndromes (see Chapter 162, “Global
Travelers”). Dengue virus is a common cause of fever and rash (Figure 154­11) in tropical areas with large mosquito populations, and transmission has been found in the southern United States. Severe dengue hemorrhagic fever can develop in locals who are exposed to a second infection with a different serotype. Dengavaxia® is recommented for those at highest risk for the disease for children 9­16 years old, but only if previous infection with
15A dengue infection is demonstrated by pre­vaccine screening. Efficacy is about 80%, for  years. It is effective against all  serotypes. Chikungunya fever causes rash, myalgias, arthralgias, and fever. Although fatalities are rare, arthralgias can be debilitating and last for months. The disease is reported in Asia, Africa, and more recently in the Caribbean and southeastern United States. Yellow fever is found in the tropics of Africa and South
America. The Aedes aegypti mosquito vector for the yellow fever virus was once eradicated in the United States, but it is now starting to reappear. This mosquito can also spread dengue and chikungunya viruses.
FIGURE 154­11
Maculopapular rash of dengue hemorrhagic fever with areas of dermal hemorrhage, petechiae, and edema. [Reproduced with permission from Wolff
K, Johnson RA: Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 6th ed., © 2009 by McGraw­Hill, Inc., New York.]
Japanese encephalitis virus causes >15,000 deaths yearly, primarily in Asia, and is now spreading to Australia. West Nile virus and the viruses causing
,15
La Crosse encephalitis, St. Louis encephalitis, eastern equine encephalitis, and western equine encephalitis are found in North America.
Zika virus disease is a mosquito born illness, typically either asymptomatic or causing a few days of mild fever, rash, conjunctivitis, and myalgias. Rare sequelae include Guillain­Barre syndrome, neuropathy, or myelitis. There is no treatment. Zika virus can be transmitted to the fetus during pregnancy, resulting in serious congenital malformations (congenital Zika syndrome). See Chapter 162, "Global Travelers", for further discussion.
PATHOPHYSIOLOGY
A mosquito or other appropriate vector becomes infected after it feeds on the blood of a viremic host. Humans are infected when the arthropod takes a blood meal. The virus replicates near the site of inoculation before it enters the reticuloendothelial system and then disseminates to various target
,15 organs. There is often a low­grade viremia until the host can produce immunoglobulin M neutralizing antibodies. If the immune system is unable to clear the virus, then the more serious manifestations of disease may become evident.
CLINICAL FEATURES
Most arbovirus infections are either asymptomatic or cause a nonspecific mild illness. Only a few individuals develop hemorrhagic fever or encephalitis. Severe human arboviral diseases most commonly manifest as four syndromes: fever and myalgia, arthritis and rash, encephalitis, and hemorrhagic fever. These syndromes can overlap; viruses that cause encephalitis and hemorrhagic fever may also cause fever and myalgia. Headache is a common symptom of most arboviral infections and may be quite severe. Hemorrhagic fever presents with bleeding from the gums, petechiae, and GI tract. The classic presentation of viral encephalitis is fever, headache, and altered level of consciousness. Patients can be
14–16 lethargic and confused and occasionally present with seizures. In general, those at extremes of age are more likely to have severe manifestations with these infections. The major concern with Zika virus infection is its potential for teratogenicity.
DIAGNOSIS
Obtaining a detailed travel and exposure history and knowing local epidemiologic patterns help in diagnosing arboviral infections. Patients with encephalitis should undergo CT or MRI of the brain. MRI is more sensitive and may show foci of increased signal intensity in the parenchyma.
Cerebrospinal fluid typically shows a lymphocytic pleocytosis and a slightly elevated protein level, although these findings are nonspecific. When encephalitis is in the differential diagnosis, save an extra vial of cerebrospinal fluid for further testing, because less common infections are often diagnosed only with stepwise testing after more common causes have been ruled out.
Serologic testing is the main method for diagnosis of arboviral infections. Viral cultures are labor intensive and technically demanding. Furthermore, patients are viremic for only a few days after the onset of illness. Generally, immunoglobulin M appears within a few days. Patients who are tested very early in the course of illness may have a false­negative result. A presumptive diagnosis of the suspected arboviral infection can be made based on an elevated immunoglobulin M level, and this can be confirmed with an increase in antibody titers between acute and convalescent samples. Many arboviruses are antigenically similar and cross­react on testing. Arboviral infections are reportable to public health authorities in many areas.
TREATMENT
Symptomatic management is the mainstay of treatment after excluding other serious, treatable causes of meningitis and encephalitis. Antiviral drugs, interferon, and steroids are not useful. Empiric treatment with acyclovir and antibiotics is appropriate until excluding HSV encephalitis and bacterial meningitis. Anticonvulsant therapy may aid if seizures occur.
,15
Hemorrhagic fever is treated with supportive care, with careful fluid management to avoid overload.
COLORADO TICK FEVER, HEARTLAND VIRUS, AND OTHERS
Many rare and novel viruses are either zoonotic or vector borne. Colorado tick fever is an RNA virus transmitted by a tick bite, usually at altitude. The virus then infects erythrocyte precursor cells, and transmission by blood transfusions has been reported. Symptoms are nonspecific, such as fevers, chills, headaches, and myalgias. Rare fatalities have been reported.

In 2009 a febrile disease was described in two Missouri farmers and later identified as Heartland virus. It has been reported in the midwestern and southern United States and is thought to be spread by infected ticks, with symptoms similar to bacterial tick­borne diseases such as anaplasmosis or ehrlichiosis. These symptoms include headache, fevers, nausea, and occasionally confusion. A virus with similar geographic distribution, Bourbon virus disease, was described in 2014, when a southern farmer died of complications of a previously unknown viral infection.
There is no routine testing available for these viruses, and suspected cases are best referred to local health authorities. The treatment remains supportive, although many also treat for Rocky Mountain spotted fever or other tick­borne bacterial infections when these viruses are suspected. This is because these viral infections have symptoms similar to the tick­borne infections. When symptoms are nonspecific, it is important to obtain a history on exposures and have an understanding of geographic risks. See Chapter 161, “Zoonotic Infections,” for more discussion.
EBOLA VIRUS DISEASE AND OTHER HEMORRHAGIC FEVERS
Viral hemorrhagic fevers are caused by several groups of RNA viruses with varying geographic distributions. These rare diseases elicit fear among the public and healthcare providers because of the lethality and transmission patterns, heightened by outbreaks in Western Africa. Examples include hantavirus pulmonary syndromes, Lassa fever, and perhaps the most notorious, Ebola virus disease. Geographic exposure and contact with an infected traveler are the most important clues to suspecting viral hemorrhagic fevers in an individual patient. Clinical presentation varies between viruses, with some causing relatively minor illness and some with high mortality. Symptoms typically begin with fever, myalgia, and malaise, which then progress to GI and other system involvement. Increased vascular permeability results in hypotension, pulmonary edema, and renal failure.
Coagulation defects lead to diffuse hemorrhage, which can be worse in patients with thrombocytopenia or platelet dysfunction, sometimes with extensive bleeding, organ damage, and shock. Ebola and most other viral hemorrhagic fevers can be confirmed with acute serology to identify antibodies or, more commonly, reverse transcriptase polymerase chain reaction identification of the virus that is performed at specialized labs such as the Centers for Disease Control and Prevention.
Periodic Ebola virus outbreaks in western Africa have high mortality. The virus is spread through contact with infected body fluids such as bloody vomit
 and diarrhea, and the lack of personal protective equipment in developing countries contributes to spread within healthcare facilities. Important aspects of preparing for Ebola and other severe viral hemorrhagic fevers in EDs include screening at triage for illness in travelers returning from areas of current outbreak and rapid initiation of appropriate isolation. Ebola and many other viral hemorrhagic fevers require contact and droplet precautions including full gown, gloves, and facemask with eye protection. Train staff on proper donning and removal of protective equipment to avoid contamination with body fluids. It is important to notify the hospital laboratory to take precautions and to plan for sending specimens to specialized labs. Treatment of Ebola and most other viral hemorrhagic fevers is supportive, with fluids, renal replacement, and respiratory support. Ebola Zaire Vaccine (ERVEBO©) is a live vaccine, which only contains a gene from the Ebola virus, not the whole virus. An antibody response is noted in  days after a single dose. Duration of effectiveness is not known. Zabdeno and Mvabea are delivered in  doses.

Quantities are limited and will be reserved for outbreak responses for those at highest risk of infection.
HUMAN MONKEYPOX INFECTIONS
Human monkeypox is a zoonotic infection caused by an orthopox virus, similar to variola, the causative agent of smallpox.
Epidemiology and Pathophysiology
Monkeypox is endemic in rural areas in central and western Africa, through contact with wildlife, especially rodents. However, since May, 2022 there
 have been multiple confirmed cases of monkeypox in >  non­endemic countries and in July of 2022, the WHO declared a public health emergency
21­ outbreak of international concern. In the current outbreak, disproportionate infections occur in communities of men who have sex with men (MSM),
 but monkeypox should be considered in any individual with a concerning rash. Monkeypox is primarily transmitted by skin­to­skin contact with infected lesions, but contact with respiratory secretions or contaminated materials such as towels or bedding, is also reported. Transmission is from prolonged exposure to infected individuals.
Clinical Features
Monkeypox is associated with a variety of skin lesions ­macular, pustular, vesicular, and crusted­which somewhat resemble smallpox. Lesions are firm or rubbery and well­circumscribed. The anatomic sites are primarily the anogenital area, trunk, arms, or legs. Lesions also occur on the face, palms
 and soles. In the original case series , most individuals had  or less lesions. Besides rash, presenting signs and symptoms include proctitis, balanitis, pharyngitis, and penile edema. Encephalitis, myocarditis, pneumonia, keratitis, and epiglottitis have been reported. Monkeypox may mimic other STI’s such as HSV and syphilis, and STI co­infections are common.
Clinical onset varies. Systemic flu­like symptoms (fever, chills, lymphadenopathy, fatigue, myalgias, headache, sore throat) may appear first, followed by the rash 1­4 days later. Or, the rash may appear first, before systemic symptoms. The incubation period is 3­17 days, and the disease is not contagious during the incubation period. The duration of illness is typically 2­4 weeks. Patients remain contagious until the skin crusts over. Most have mild, self­limiting disease.
FIGURE 154­12A&B
Photo credit: NHS England High Consequence Infectious Diseases Network.
Content source: Centers for Disease Control and Prevention, National Center for Emerging and Zoonotic Infectious Diseases (NCEZID) Division of High­
Consequence Pathogens and Pathology (DHCPP) https://www.cdc.gov/poxvirus/monkeypox/resources/graphic
Diagnosis
Perform PCR testing of suspected lesions. False positives have been occasionally reported in patients with atypical lesions with no epidemiologic link
 to infection or risk factors. Consult with the health department or infectious disease specialists when faced with such cases.
Vaccination
The JYNNEOS (IMVANEX in the UK) vaccine is a live, attenuated, non­replicating virus delivered in two doses, a month apart. ACAM2000 vaccine, a live, replication competent virus, is available under an Expanded Access Investigational New Drug protocol (EA­IND). It produces a marked cutaneous reaction at the site of injection. It should not be given to immunocompromised or HIV+ patients. The vaccines appear efficacious against monkeypox.
,25
Unvaccinated high­risk individuals had  times the risk of contracting monkeypox compared to those who were unvaccinated.
Pre­exposure prophylaxis is recommended for those at risk for occupational exposure: research and clinical laboratory personnel; response team
,25 members at risk. Post­exposure prophylaxis is recommended within  days of exposure.
Treatment
Treatment is supportive. Monkeypox lesions can cause severe pain and lesions can become superinfected with bacteria. Tecovirimat (TPOXX) is an
 antiviral agent approved for the treatment of human smallpox disease. It is available for monkeypox treatment through EA­IND. Patients who are severely immunosuppressed, pregnant or breastfeeding, those with active exfoliating agents, and those with lesions in areas that can lead to problematic scarring and strictures are candidates for TPOXX. Consult with infections disease for additional treatment with antiviral agents
(brincidofovir, cidofovir) and vaccinia immune globulin.
TPOXX PO dose:
 to 120 kg: 600 mg po bid × 14d
>120 kg: 600 mg po tid × 14d
TPOXX IV dose:
35­120 kg: 200 mg IV over  h q  h ×  d
>120 kg: 300 mg IV over  h ×  d
Prevention
Transmission to healthcare personnel is so far rare. Infection control recommendations are to wear gowns, gloves, eye protection, and an N95 (or higher) respirator when caring for those suspected or known to have monkeypox. ED patients with suspected monkeypox should be isolated, masked, and have suspected lesions covered. As soon as monkeypox exposure is suspected, contact the state health department.
Patients who are not hospitalized should be isolated at home, and ensure that others have no contact with any potentially infected materials.


