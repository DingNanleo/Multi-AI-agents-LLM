## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 169: Ataxia and Gait Disturbances
J. Stephen Huff
INTRODUCTION
Ataxia and gait disturbances may be symptoms of many disease processes and generally are not in themselves diagnoses. Ataxia is uncoordinated movement. A gait disorder is an abnormal pattern or style of walking. The presenting problem may be articulated by the patient or family as weakness, dizziness, stroke, falling, or another nonspecific chief complaint. Such symptoms must always be viewed in the context of the patient’s overall clinical picture. This chapter reviews the more common causes of acute ataxia and gait disorders (Table 169­1).
TABLE 169­1
Common Etiologies of Acute Ataxia and Gait Disturbances
Systemic conditions
Intoxications with diminished alertness
Ethanol
Sedative—hypnotics
Intoxications with relatively preserved alertness (diminished alertness at higher levels)
Phenytoin
Carbamazepine
Valproic acid
Heavy metals—lead, organic mercurials
Other metabolic disorders
Hyponatremia
Inborn errors of metabolism
Wernicke’s disease
Disorders predominantly of the nervous system
Conditions affecting predominantly one region of the CNS
Cerebellum
Hemorrhage
Infarction
Degenerative changes
Abscess
Cortex
Frontal tumor, hemorrhage, or trauma
Hydrocephalus
Subcortical
Thalamic infarction or hemorrhage
Parkinson’s disease
Normal pressure hydrocephalus
Spinal cord
Cervical spondylosis and other causes of spinal cord compression
Posterior column disorders

Conditions affecting predominantly the peripheral nervous system
Chapter 169: Ataxia and Gait Disturbances, J. Stephen Huff 
Peripheral neuropathy
. Terms of Use * Privacy Policy * Notice * Accessibility
Vestibulopathy
PATHOPHYSIOLOGY
Clinicians often erroneously think that ataxia and gait disorders result primarily from cerebellar lesions. However, such ataxia and gait problems may result from systemic conditions that affect different elements of the central or peripheral nervous systems. Cerebellar lesions may indeed cause ataxia, but isolated lesions of the cerebellum are not the most common cause of these complaints. Ataxias may be classified as either motor (cerebellar) or sensory.
MOTOR ATAXIAS
Motor ataxias (also referred to as cerebellar ataxias) are usually caused by disorders of the cerebellum. The sensory receptors and afferent pathways are intact, but integration of proprioceptive information is faulty. Involvement of the lateral cerebellum (one of the cerebellar hemispheres) may lead to a motor ataxia of the ipsilateral limb. Lesions affecting primarily the midline portion of the cerebellum often cause problems with axial muscle coordination, which is reflected in difficulty maintaining a steady upright standing or sitting posture.
There are many reports of CNS lesions producing motor ataxia in what intuitively seem unlikely locations. Supratentorial infarctions, particularly small, deep infarctions, and lacunae of the posterior limb of the internal capsule have been reported to cause isolated hemiataxia. It is postulated that
 interruption of either ascending or descending cerebellar to cortical pathways are the cause of this motor­type ataxia. Small infarctions or hemorrhages in thalamic nuclei may produce a clinical picture of motor­ or cerebellar­like ataxia with hemisensory loss. These effects are seen
 contralateral to the lesion. Lesions affecting the frontal lobe, such as tumors or cystic masses, may cause a motor ataxia of the contralateral
  extremities through poorly understood mechanisms. Nontraumatic spinal cord compression may present with gait ataxia or abnormality.
SENSORY ATAXIAS
Sensory ataxias are due to failure of transmission of proprioception or position sense information to the CNS. Failure may arise from disorders affecting the peripheral nerves, spinal cord, or cerebellar input tracts. Coordinated motor performance is faulty, even though motor systems and the cerebellum are intact. Sensory ataxias may be somewhat compensated by visual sensory information. Loss of visual information leads to the observation that sensory ataxias often worsen in poor lighting conditions.
GAIT DISORDERS
No organized classification scheme exists for gait disorders, and different authors categorize abnormal gaits in descriptive terms. A cerebellar or motor ataxic gait is wide­based with unsteady and irregular steps, and compensation for environmental barriers may be lacking. The gait of sensory ataxia resulting from loss of proprioception is notable for abrupt movement of the legs and slapping impact of the feet with each step. A variety of other terms are used to describe abnormal gaits.
An apraxic gait is one in which the patient seemingly has lost the ability to initiate the process of walking, an “ignition failure.” This may occur with
 right or nondominant hemispheric lesions. Frontal lobe dysfunction may result in a similar gait and may be seen in normal pressure hydrocephalus.
The term festinating gait is used to describe narrowly based miniature shuffling steps and is common in Parkinson’s disease. An abnormal gait with outward swinging or circumabduction of the leg suggests a mild hemiparesis reflecting the asymmetric weakness of the proximal lower extremity muscles. Bilateral weakness of the trunk and pelvic girdle muscles may result in a waddling gait from failure to maintain the normal position of the pelvis relative to the lower extremities.
A functional gait disorder is one in which the patient is unable to walk normally, although all motor pathways, sensory pathways, and cerebellar functions may be demonstrated to be functioning normally. The underlying problem is often a conversion disorder. Functional gaits may be bizarre, at times resembling a person balancing on a tightrope and seemingly threatening to fall but not falling. A dramatic functional gait with flailing movements without falling actually demonstrates that strength, balance, and coordination are intact.
,7
A unifying concept defines gait disorders according to the level of processing of neurologic information (Table 169­2). The classification scheme is not ideal but does allow a thoughtful approach to patient diagnosis.
TABLE 169­2
Classification of Gait Disorders
Low­level gait disorders
Musculoskeletal problems
Arthritic gait or other joint or skeletal problems
Muscle weakness
Peripheral sensory problems
Sensory ataxic gait
Vestibular problems
Middle­level gait disorders
Hemiplegia
Paraplegia
Motor or cerebellar ataxia
Parkinson’s disease
Dystonia, chorea, other movement disorders
High­level gait disorders
Senile gait (cautious gait)
Frontal ataxic gait
Apraxic gait (gait ignition failure)
Frontal disequilibrium
Low­level gait disturbance refers to disorders of proprioception or dysfunction of the musculoskeletal system. Middle­level gait disturbance causes distortion of appropriate interaction of postural and motor processes or synergies. This might include stroke with paralysis, cerebellar dysfunction, or diseases of the basal ganglia such as Parkinson’s disease. High­level gait disturbances seemingly involve structures or processes that choose the appropriate responses for the support surface, body position in space, and intention of the patient. Cautious gait, apraxic gait, and the frontal gait disorder conceptually fall into this group with pathology that correlates with lesions in the frontal cortex or thalamus. This latter group is the least understood and often the source of clinical confusion.
CLINICAL FEATURES
HISTORY
Collect historical information about the entire symptom constellation including presence of headache, nausea, fever, weakness, or numbness. A history of fever, review of medication history, or family history of ataxia may lead to the diagnosis in individual cases. The nature of onset of symptoms and the time course of the process guide the pace of investigations. For example, abrupt onset of gait difficulty in a patient with severe headache, drowsiness, nausea, and vomiting should suggest an acute process within the CNS, possibly a hemorrhage into the cerebellum. The possible consequences of that diagnosis are severe and may require immediate attention. At the other extreme, a patient without significant medical history who is brought to the ED with a stumbling gait after an episode of binge drinking requires examination and may need nothing other than observation unless history or physical examination suggests trauma or some alternative cause for the symptoms.
PHYSICAL EXAMINATION
The following discussion of the neurologic examination assumes that the gait disorder is the dominating abnormality. Physical examination including testing of cranial nerves, mental status, sensation, and the motor system is necessary and may yield findings that lead to an unanticipated diagnosis.
An approach to the neurologic examination is presented in Chapter 164. General physical examination of a patient with ataxia or gait disturbance should include determination of orthostatic vital signs. Orthostatic hypotension may be present in hypovolemia, diabetic neuropathy, and other neurologic syndromes. Especially in the elderly, fluid replacement for simple hypovolemia may often correct symptoms of unsteadiness.
Gait testing is one of the most important parts of the directed neurologic examination. Observe the patient sitting upright in the stretcher, and then have the patient rise, stand, walk, and turn around. The patient should be asked to walk at a normal speed, then walk on the heels, and then the toes.
Tandem gait is toe­to­toe walking and tests many elements of the nervous system. Do not assume a normal examination without observing ambulation.
Cerebellar functions are tested by asking the patient to perform smooth voluntary movements and rapidly alternating movements. Dyssynergia
(breakdown of movements into parts), dysmetria (inaccurate fine movements), or dysdiadochokinesia (clumsy rapid movements) may indicate a lateral cerebellar lesion. The rapid thigh­slapping test particularly examines rapidly alternating movements. This is correctly performed by asking the patient to pat the thigh with the palm then the back of the same hand in alternating fashion, making a sound with each rapid slap. The maneuver is performed with each hand in turn. The finger­to­nose test may be helpful in distinguishing between cerebellar and posterior column (proprioceptive) lesions. Performing this test with the eyes closed tests proprioception in the upper extremities. A test for cerebellar function that emphasizes the lower extremities is the heel­to­shin test. In cerebellar disease, the heel may initially overshoot the other shin or knee, and the action is done with a series of jerky movements. In posterior column disease, there may be difficulty locating the knee with the heel, and the movement down the shin typically weaves from side to side or falls off. Another test commonly used for cerebellar function is checking for abnormal rebound; with sudden release of a flexed forearm against resistance, the individual fails to check further excessive flexion. Another example of rebound phenomena is when a tapped outstretched arm excessively oscillates back and forth for several seconds.
The Romberg test is primarily a test of sensation, and if positive, it may distinguish sensory from motor ataxia. While standing with arms outstretched and eyes open, observe the patient for signs of unsteadiness. The feet should be narrowly spaced, and the posture should be easily maintained. The inability to maintain a steady standing posture (or, in extreme cases, a seated position) confirms that an ataxia is present but does not yet give any information about the type of ataxia. Then ask the patient to close his or her eyes, which eliminates visually orienting information. If the ataxia worsens with the loss of visual input, then the Romberg sign is present or positive, suggesting sensory ataxia with a problem of proprioceptive input (posterior column, vestibular dysfunction) or a peripheral neuropathy. Further neurologic examination is indicated to confirm the suspicion of sensory ataxia. In patients who show little or no change in unsteadiness with eye closure (Romberg test–negative), a motor ataxia is suggested, with possible localization of that problem to the cerebellum. Note that many normal individuals will have some small increase in unsteadiness with eye closure.
Historically, tabes dorsalis (neurosyphilis) was a common cause of sensory ataxia. In tabes dorsalis, the posterior columns and posterior spinal roots degenerate primarily in the lumbosacral region. The loss of proprioceptive information from the lower extremities renders the patient dependent on visual cues for correct gait. The classic description depicts a patient walking slowly with wide gait while staring at the ground. In darkness or with interruption of vision, the patient is unable to walk. The gait in this condition appears peculiar, with the foot first raised and then slapped to the ground with each step. These abnormalities reflect the loss of proprioceptive information from the posterior roots and posterior columns. Consider the possibility of vitamin B deficiency in patients with evidence of posterior column disease. If the deficiency is left untreated, an initial unsteady gait
 may progress to weakness, spasticity, and ataxia. The finding of a megaloblastic anemia may be a clue, but the neuropathy may precede the anemia.
Sensory examination in a patient with unsteady gait or ataxic movements should include position or vibration testing (posterior columns), as well as testing sensation to pinprick. Testing of the deep tendon reflexes will serve largely to discover asymmetry or spasticity that might suggest an alternative
 diagnosis. Acute cerebellar injury may result in muscle hypotonia for a few days or weeks.
Nystagmus is seen in many different disorders due to lesions in a variety of different locations of the CNS, but the presence of nystagmus does suggest that a pathologic process is intracranial (CNS or vestibular) and not in the spinal cord or peripheral nervous system (see Chapter 170, “Vertigo”).
DIAGNOSIS
Assuming a primary complaint of ataxia, the first task is to determine whether the ataxia is sensory or motor, and whether the primary process is systemic or within the nervous system. If the ataxia is thought to result from problems within the nervous system, the next question is one of localization to the peripheral nervous system or the CNS and then perhaps to a more specific anatomic location. Finally, the tempo of the illness, comorbid diseases, and other clinical findings guide investigations and may allow a disease­specific diagnosis.
A patient with acute gait failure over hours to days needs thorough evaluation in the ED, often requiring neuroimaging and lumbar puncture if cerebrospinal fluid infection is suspected. Acute ataxia or gait disturbance may also be evaluated by consultation if available, and possible admission, in contrast to a patient with gradual loss of abilities over weeks or months where outpatient referral and evaluation may be more appropriate.
SPECIAL POPULATIONS
THE GERIATRIC PATIENT
The gait changes with advancing age. A typical constellation includes gait slowing, shortening of the stride, and widening of the base. This results in the appearance of a guarded gait—that is, the gait of someone about to slip and fall. Many patients are aware of the loss of speed and adaptive balance and acknowledge the need to be careful. The nature of the senile gait is not fully understood but may represent a mild degree of neuronal loss, failing proprioception, slowing of corrective responses, or weakness of the lower extremities. Senile gait disorder is thought to exist in up to one fourth of the elderly population. Some authorities divide this disorder into components of gait ataxia with mild truncal instability and widened gait, and gait slowing
 with diminished spontaneous arm swing and bradykinesia. However, elements of the senile gait are also found in neurologic diseases, so consider the
 possible presence of a disorder such as Parkinson’s disease or normal pressure hydrocephalus in elderly patients with gait impairment. Patients unable to walk or care for themselves, or with increasing falls at home, need admission for diagnosis and supportive care planning.
THE ALCOHOLIC PATIENT
A history of alcoholism or malabsorption problem in the patient with ataxia or gait disorder raises the possibility of a potentially remedial nutritional
 problem. If acute motor ataxia is present with confusion or eye movement abnormalities, consider Wernicke’s disease and administer IV thiamine.
The entity of alcoholic cerebellar degeneration (sometimes referred to as rostral vermis syndrome, because a portion of the cerebellar vermis is preferentially affected) may represent the same nutritional deficiency and not the direct toxic effects of alcohol.
CHILDREN
In evaluating children with acute ataxia or gait disorder, examination must exclude weakness and musculoskeletal disorders. The child may be awake, alert, and playful but is visibly unsteady or wobbly sitting on a stretcher. The differential diagnosis is extensive (Table 169­3). Acute or deteriorating
 presentation generally mandates an aggressive search for the underlying cause and will likely need inpatient management.
TABLE 169­3
Causes of Acute Ataxia in Children, Roughly in Order of Frequency
Cause Example
Drug intoxication Ethanol
Isopropyl alcohol
Phenytoin
Carbamazepine
Sedatives
Lead, mercury
Idiopathic Acute cerebellar ataxia of childhood
Infection and inflammation Varicella
Coxsackievirus A and B
Mycoplasma
Echovirus
Postinfectious inflammation
Postimmunization
Neoplasm Neuroblastoma
Other CNS tumors
Paraneoplastic Opsoclonus­myoclonus syndrome
Trauma Subdural or epidural posterior fossa hematoma
Congenital or hereditary Pyruvate decarboxylase deficiency
Friedreich’s ataxia
Hartnup disease
Hydrocephalus
Cerebellar abscess
Labyrinthitis/vestibular neuronitis
Transverse myelitis
Meningoencephalitis
Intoxications are a cause of ataxia in children, and ingestions may be surreptitious. History should include queries about any medications in the
 household. Acute ataxia may follow immunizations, viral illnesses, or varicella, which has been rarely reported in the preeruptive phase of varicella.
Most children are in the 2­ to 4­year­old range. Acute cerebellar ataxia of childhood is thought to be a postinfectious demyelinating disorder. The onset of gait ataxia is abrupt, and only occasionally is fever present at the time ataxia begins. The latency from the prodromal illness to the onset of ataxia is from  days to  weeks. Other neurologic findings encountered included truncal ataxia, dysmetria, and, uncommonly, cranial nerve abnormalities.
Patients with ataxia following varicella appear to have uniform excellent recovery compared with patients with acute cerebellar ataxia of other causes
 who may have some residual problems. Little workup is needed if the ataxia occurs in the convalescent phase of varicella, and antiviral medications are not indicated. Otherwise, neuroimaging, lumbar puncture, and consultation are advisable. One study showed that although roughly half of the patients had cerebrospinal fluid inflammatory changes with pleocytosis or elevated immunoglobulin G index, in only a minority of cases did MRI
 identify inflammatory changes in the cerebellum. Another small report noted MRI abnormalities not only in the cerebellum but also in other areas of
 the CNS. This “syndrome” may in fact consist of several subgroups, some of which involve transient demyelination.
Posterior fossa mass lesions and other CNS masses may present with ataxia, although usually some additional abnormalities of cranial nerves or strength will be discovered with careful examination. Attention is needed to exclude abnormalities on physical examination that might suggest problems not localized to the cerebellum. Abnormal ocular movements should increase the suspicion of a mass lesion. Acute ataxia associated with rapid chaotic eye movements (opsoclonus) and myoclonic jerks of the head and extremities is the striking syndrome of opsoclonus­myoclonus. This
 may be a postviral syndrome but is often a paraneoplastic syndrome associated with a neuroblastoma located in the abdomen or chest.
Unusual metabolic disorders such as pyruvate decarboxylase complex deficiency may present with ataxia. Family history may or may not suggest a metabolic disorder. Typically, the onset is gradual, but abrupt decompensations may occur. Other systemic or CNS abnormalities will be present.


