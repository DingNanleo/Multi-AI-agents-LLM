## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 41: Wound Closure
Adam J. Singer; Judd E. Hollander
INTRODUCTION
The major goal of wound closure is to restore the skin’s integrity in order to reduce the risk of infection, scarring, and impaired function. Closure can occur in three ways. With primary closure, the wound is immediately closed by approximating its edges, with the main advantage being a reduction in healing time in comparison with other closure methods. Primary wound closure also may reduce bleeding and discomfort often associated with open wounds. Secondary wound closure, in which the wound is left open and allowed to close on its own, is particularly well suited for highly contaminated or infected wounds as well as in patients at high risk of infection. Although this method may reduce the risk of infection, it is relatively slow and uncomfortable and leaves a larger scar than primary closure. With delayed (or tertiary) closure, also sometimes referred to as delayed primary closure, the wound is initially cleansed and then packed with moist sterile gauze covered by a sterile covering. The dressing is left undisturbed unless signs of infection—fever, purulent exudate, or spreading cellulitis—develop. After  to  days, the dressing is removed, and the wound edges can be closed if no infection has supervened. This approach may be useful for highly contaminated wounds and animal bites, and while commonly
 described and recommended, there is little evidence documenting the effectiveness for traumatic wounds seen in the ED.
OVERVIEW OF WOUND CLOSURE METHODS
Lacerations may be closed by one of five commonly available methods or devices: sutures, staples, adhesive tapes, tissue adhesives, and hair apposition. Each method has advantages and disadvantages (Table 41­1). Choice of the wound closure method and timing should take into account
 both patient and wound characteristics. Cosmetic outcome is more closely related to practitioner technique and the patient’s own healing characteristics than to any specific closure method or device. Many of the principles discussed in this chapter are based on experience and observation rather than on controlled trials.
TABLE 41­1
Advantages and Disadvantages of Wound Closure Techniques
Technique Advantages Disadvantages
Sutures Time honored Requires removal (if using nonabsorbable material)
Meticulous closure Requires anesthesia
Greatest tensile strength Risk of needle stick to physician
Lowest dehiscence rate Greatest tissue reactivity
Highest cost
Slowest application
Staples Rapid application Less meticulous closure
Low tissue reactivity May interfere with some imaging techniques (CT, MRI)
Low cost Requires removal
Low risk of needle stick
Tissue adhesives Rapid application Lower tensile strength than 5­0 or greater sutures
Patient comfort Dehiscence over high­tension areas (joints)
Resistant to bacterial growth Not useful on hands

No need for removal Cannot bathe or swim (can briefly get wet in a shower)
Chapter 41: Wound Closure, Adam J. Singer; Judd E. Hollander 
©2025 McGraw Hill. All Rights LRowes ceorsvted. Terms of Use * Privacy Policy * Notice * Accessibility
No risk of needle stick
Microbial barrier
Occlusive dressing
Adhesive tapes Least reactive Frequently fall off
Lowest infection rates Lower tensile strength than sutures or tissue adhesives
Rapid application Highest rate of dehiscence
Patient comfort Often requires use of toxic adjuncts
Low cost Cannot be used in areas with hair
No risk of needle stick Cannot get wet
Hair apposition Simple Can be used only on the scalp
Low cost Can only approximate simple nongaping lacerations
No foreign body placed in wound
No risk of needle stick
One important consideration when choosing a wound closure method is the amount of tension on the wound, both static (at rest) and dynamic (with motion). Linear lacerations subject to little tension can usually be closed by any one of the five closure methods. For low­tension lacerations, consider patient characteristics and preferences such as compliance, the availability to return for follow­up and device removal, and overall level of patient anxiety. With low­tension irregular lacerations, sutures may be the best alternative, allowing the greatest degree of precision for accurate wound edge approximation. Conversely, some small lacerations where the wound edges approximate with little tension do not require primary closure. For example, simple (<2 cm) uncomplicated hand and finger lacerations, when treated with antibiotic ointment and gauze dressing, heal as fast and with
 no notable differences in appearance or function as those closed primarily with sutures. Note that this technique is limited to small, superficial hand lacerations; it cannot be recommended for larger lacerations, and it has not been studied in other sites.
With lacerations subject to high tension (static and/or dynamic), relief of tension on the wound can reduce the risk of early dehiscence or gradual widening of the scar. Relief of tension is best achieved by careful undermining, placement of deep dermal sutures, and wound immobilization (when appropriate). After placement of deep, tension­relieving sutures, the superficial epidermal layer may be closed by any of the aforementioned closure
4­6 methods. Reinforcement with adhesive skin tape is useful when the skin is thin, as in pretibial lacerations.
With patients at risk of keloid formation, it makes logical sense to relieve tension and minimize the amount of foreign material introduced into the wound by using skin tapes or tissue adhesives, instead of sutures.
SUTURES
Sutures are the strongest of all the closure devices and allow the most accurate approximation of the wound edges, regardless of their shape or configuration. However, sutures are the most time­consuming and operator dependent of all wound closure methods and have the risk of inadvertent needle­stick injury (to the provider). Using forceps to handle the needle during suturing can reduce this risk. A needle­catcher device is reported to be
7­9 useful in reducing needle­stick injury during skin suturing.
Sutures may be classified as absorbable and nonabsorbable. Nonabsorbable sutures retain their tensile strength for at least  days. They are most often used to close the outermost layer of the skin (where they can be removed) or for repair of tendons (where prolonged strength is desired due to high tension). In general, nonabsorbable sutures are avoided in deep vascularized tissues where their presence stimulates a foreign body response with fibroblastic proliferation. Nonabsorbable sutures are differentiated by their origin and structure (Table 41­2). Due to their strength,
 handling, and relatively low tissue reactivity, synthetic monofilament material (such as nylon or polypropylene) is preferred for nonabsorbable use.
Polybutester sutures have the ability to elongate in response to external forces and possess elasticity to return to the original size once the load is removed. This property may be useful in wounds where swelling is anticipated. Less distensible sutures, such as nylon or polypropylene, cannot expand, and instead may lacerate the wound edges as the tissue swells.
TABLE 41­2
Nonabsorbable Suture Characteristics
Tensile Strength Retention Tissue Common ED
Suture Structure Raw Material
Profile Reactivity Uses
Silk Braided Organic protein fibroin Degradation of fiber results in Significant Intraoral mucosal loss of strength over many inflammatory surfaces for months reaction comfort
Nylon (Ethilon®, Braided and Polyamide polymer Hydrolysis results in 20% loss in Minimal Soft tissue and skin
Dermalon®) monofilament strength per year reapproximation
Polypropylene Monofilament Polypropylene polymer Indefinite Least Soft tissue and skin
(Prolene®, reapproximation
Surgipro®)
Polyester Braided and Polyethylene terephthalate polymer Indefinite Minimal Tendon repair
(Mersilene®, Ti– monofilament using undyed
Cron®) (white) color
Polybutester Monofilament Copolymer of butylene Indefinite Minimal Soft tissue
(Novafil®) terephthalate and approximation polytetramethylene ether glycol
Absorbable sutures lose most of their tensile strength in less than  days; they are well suited for closure of deep structures such as the dermis and fascia (Table 41­3). Poliglecaprone  has handling characteristics that are similar to nonabsorbable sutures (such as nylon) and is particularly useful for intradermal or subcuticular closure. Due to its rapid absorption, poliglecaprone  should probably be limited to relatively lowtension wounds. With high­tension wounds, a suture with more sustained tensile strength is preferred, such as polyglyconate. Absorbable sutures that
11­14 incorporate the antibacterial agent triclosan are also available and may be especially indicated in contaminated wounds. Rapidly absorbing
15­20 sutures can also be used to close skin and mucosa, especially when avoidance of suture removal is desirable.
TABLE 41­3
Absorbable Sutures
Tensile
Strength Absorption Tissue
Suture Structure Raw Material Common ED Uses
Retention Rate Reactivity
Profile
Surgical gut Monofilament Collagen derived from beef serosa or 7–10 d Absorbed by Moderate Intraoral wounds sheep submucosa proteolytic reactivity processes in
 d
Chromic gut Monofilament Collagen derived from beef serosa or 21–28 d Absorbed by Moderate Subcutaneous with chromic sheep submucosa proteolytic reactivity approximation and salt coating processes in intraoral wounds
 d
Fast­absorbing Monofilament Collagen derived from beef serosa or 5–7 d Absorbed by Moderate Facial wounds and gut heat treated sheep submucosa proteolytic reactivity skin grafts to facilitate processes in absorption 21–42 d
Polyglycolic Braided Glycolic acid polymer 65% at  d and Absorbed by Minimal Subcutaneous acid (Dexon®) 35% at  d hydrolysis, approximation and complete by ligation of vessels
60–90 d
Coated Braided Copolymer of lactide and glycolide, 75% at  d and Absorbed by Minimal Subcutaneous polyglactin 910 coated with polyglactin 370 and 40% at  d hydrolysis, approximation and
(Vicryl®) calcium stearate complete by ligation of vessels
56–70 d
Coated Braided Copolymer of lactide and glycolide, 75% at  d, 50% Absorbed by Minimal Subcutaneous polyglactin 910 coated with polyglactin 370 and at  d, and 25% hydrolysis, approximation and with triclosan calcium stearate; incorporates at  d complete by ligation of vessels,
(Vicryl PLUS®) antibacterial agent triclosan 56–70 d especially useful in contaminated wounds
Coated Braided Copolymer of glycolide and lactide, 50% by  d and Absorbed by Minimal to Skin approximation polyglactin 910 coated with polyglactin 370 and 0% at  d hydrolysis, moderate when absorbable rapid calcium stearate complete by sutures are used absorption  d
(Vicryl Rapide®)
Coated Braided Copolymer of glycolide and lactide, 80% at  d and Absorbed by Minimal Subcutaneous soft glycolide and coated with mixture of caprolactone, 30% at  d hydrolysis, tissue approximation lactide glycolide copolymer, and calcium complete by
(Polysorb®) stearoyl lactylate 56–70 d
Polydioxanone Monofilament Polyester polymer 70% at  d, 50% Absorbed by Slight Subcutaneous soft
(PDS II®) at  d, and 25% hydrolysis, tissue approximation at  d complete at where more
180–210 d prolonged strength is needed
Poliglecaprone Monofilament Copolymer of glycolide and epsilon­ 50%–70% at  d Absorbed by Minimal Subcutaneous soft
 (Monocryl®) caprolactone and 20%–40% at hydrolysis, tissue approximation
 d complete by
91–119 d
Poliglecaprone Monofilament Copolymer of glycolide and epsilon­ 50%–70% at  d Absorbed by Minimal Subcutaneous soft
 with caprolactone; incorporates and 20%–40% at hydrolysis, tissue approximation, triclosan antibacterial agent triclosan  d complete by especially in
(Monocryl 91–119 d contaminated
PLUS®) wounds
Glycomer 631 Monofilament Polyester composed of glycolide, 75% at  d and Absorbed by Slight Subcutaneous soft
(Biosyn®) dioxanone, and trimethylene 40% at  d hydrolysis, tissue approximation carbonate complete by where extended
90–110 d strength is not needed
Polyglyconate Monofilament Copolymer of glycolic acid and 80% at  d, 75% at Absorbed by Slight Subcutaneous soft
(Maxon®) trimethylene carbonate  d, 65% at  d, hydrolysis, tissue approximation
50% at  d, and complete by where more
25% at  d 180 d prolonged strength is needed
For most ED use, the choice between absorbable and nonabsorbable material for percutaneous sutures is clinically irrelevant. The cosmetic outcomes and complications of traumatic lacerations and surgical incisions closed with absorbable or nonabsorbable sutures have similar short­ (infection, dehiscence) and long­term (cosmesis) outcomes. Absorbable sutures, such as rapidly absorbing gut, are especially useful for skin
,20 closure in children who are not candidates for wound repair with skin tapes or tissue adhesives.
Suture material is categorized by the U.S. Pharmacopeia gauge size. The larger the suture size number, the thinner is the suture (and the lower the tensile strength), so that, for example, a 6­0 suture is thinner than a 5­0 suture. A general principle is that larger­diameter material produces more damage to the tissues and leaves larger holes in the skin, so generally thinner suture material is used whenever possible.
Because smaller­diameter material has less tensile strength, the trade­off is that more individual sutures closer together are sometimes needed to close a wound. Where cosmetic appearance is important, as on the face, smaller­diameter material is preferred (Table 41­4).
TABLE 41­4
Recommended Suture Size Based on Laceration Location
Location Suture Size
Scalp 3­0 or 4­0
Face 6­0
Trunk 4­0
Extremities 4­0
Digits 5­0

Improper tissue handling further traumatizes the tissues and results in an increased risk of infection and poor scarring. Gentle tissue handling using either skin hooks or the open limb of fine forceps is encouraged (Figure 41­1). Magnifying lenses such as surgical loupes can assist in accurate
 placement of sutures, as well as in the identification of retained foreign bodies. While there are many types of surgical loupes available, a version useful in the ED is a magnifying power of .5× with the Keplerian lens system, which will provide a bright, clear image out to a field of view of  cm.
Alternatively, over­the­counter reading glasses with similar magnification may be used. Hemostasis is best achieved by direct pressure. Topical vasoconstrictors (e.g., epinephrine) applied to the wound edges and bed or mixed with the local anesthetic injected into the wound may help control bleeding in traumatic lacerations treated in the ED. Careful and selective placement of a ligature tie is sometimes necessary for bleeding from vessels
>2 mm in diameter.
FIGURE 41­1. The skin hook (A) or one limb of a tissue forceps with teeth (B) is used to elevate the wound edge to facilitate placement of the percutaneous suture.
The best cosmetic outcome is achieved by carefully matching each layer of the wound with its corresponding counterpart on the opposite side, ensuring eversion of the wound edges and minimizing the amount of tension on the wound. As the wound heals and the swelling subsides, the wound will eventually flatten, becoming flush with the surrounding skin surface. Inadvertent inversion of the wound edges may result in an unsightly depressed scar. A variety of suture techniques can be used to handle wounds of nearly all shapes, irregularities, and depths (Table 41­5). Studies of abdominal surgical incision closure did not consistently find that small suture bites placed close to the wound edges and close to one another reduced
,24 surgical site infections compared with larger suture bites. Although small suture bites placed close together have not been compared to larger suture bites in the closure of traumatic wounds, there is likely no clear advantage to sutures placed close to the wound edges and each other; the number of sutures placed and bite size chosen should achieve optimal approximation of wound edges while minimizing the amount of suture material used. The operator should concentrate on suture placement; minimize nonrelevant small talk during wound closure to reduce the risk of wound
 infection.
TABLE 41­5
Suture Techniques Based on Wound Type
Suture Type Advantages Disadvantages Frequent Uses
Interrupted Excellent approximation for irregular and Time­consuming Low­tension wounds percutaneous complex lacerations May strangulate tissues May be used with deep sutures for high­tension wounds
Continuous Rapid closure Less meticulous closure than interrupted Percutaneous closure in percutaneous Accommodates edema sutures conjunction with deep sutures
Wound may dehisce if a single knot unravels and no deep sutures were placed
Deep dermal Reduces tension on wound surface May increase infection in contaminated wounds High­tension wounds
Allows early removal of percutaneous Closure of dead space sutures, avoiding hatch marking
May reduce scar width
Continuous Rapid closure Technically difficult Cosmetically visible areas to subcuticular Reduces tension on wound surface Less accurate approximation than interrupted reduce scarring
Reduces or eliminates need for sutures percutaneous sutures Wound may dehisce if a single knot unravels
May reduce scar width
Vertical mattress Excellent wound edge eversion May cause tissue strangulation Thin or lax skin with little dermal
Combines advantages of deep and or fascial tissue superficial sutures High­tension areas (e.g., extremities)
Horizontal More rapid than simple interrupted sutures Requires skill to achieve wound edge eversion Volar wounds of the hands mattress Avoids punctures close to wound edges Initial approximation of highthat may impair perfusion tension wounds
Accommodates wound swelling
Half­buried Less compromising to flap tip perfusion Technically difficult Corner stitches and flaps horizontal and stellate lacerations Stellate lacerations mattress
SIMPLE INTERRUPTED PERCUTANEOUS SUTURES
Individual simple interrupted percutaneous sutures are the most basic and most commonly used approach for laceration closure. Introduce the needle through the outer layer of the skin, and exit at the level of the dermis on one side of the wound. Then, reinsert the needle through the opposite wound edge starting at the level of the dermis and exit superficially (Figure 41­2). To ensure proper wound edge eversion, the needle should enter and exit the skin at equal distances from the wound and at an angle of  degrees. Wound edge eversion is achieved by taking a larger bite through the depth of the wound than through the more superficial layers (Figure 41­3).
FIGURE 41­2. Placement of simple interrupted percutaneous sutures. A. Insert the needle at a 90­degree angle to the skin. B. Drive the needle through the tissue until the tip exits the skin. C. Grasp the needle behind the tip and pull it through the wound. D. The suture should enter and exit the skin equidistant from the wound edges. E. Pull the suture to oppose the wound edges and cinch down the knot. F. Complete the knot to one side of the laceration. G.
Apply additional sutures equidistant from each other until the wound is closed. [Reproduced with permission from Reichman EF (ed): Reichman’s
Emergency Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F. Reichman, PhD, MD, Figure 116­6. New York, NY: McGraw­Hill, Inc.]
FIGURE 41­3. Wound edge eversion. The distance of the suture from the wound edge is greater at the depth of the wound than at the surface, promoting wound edge eversion when tightened. [Reproduced with permission from Reichman EF (ed): Reichman’s Emergency Medicine Procedures, 3rd edition.
Copyright © 2019 by Eric F. Reichman, PhD, MD, Figure 114­14. New York, NY: McGraw­Hill, Inc.]
The entrance and exit of the suture should be close enough to the wound edges that they are not puckered when the knot is tied but far enough away to allow the suture material a firm hold on the tissue. Sutures are tied using square knots, and, generally, the number of knot ties should correspond to the suture size (i.e., four ties for a 4­0 suture, five ties for a 5­0 suture, etc.). Additional ties do not increase the strength of a properly tied square knot; they only add to its bulk. The extra ties are to increase knot security and prevent unraveling. Once the knot is completed, it should be moved to one side of the wound so as to not rest directly over the edges. For simple linear lacerations, a useful approach is to place the first suture in the middle of the wound, creating two smaller segments that are sequentially bisected into smaller segments until adequate coaptation of the edges is achieved. Sutures should not be cut so short that they may be difficult to locate through a scab or scalp hair at the time of suture removal.
CONTINUOUS (RUNNING) PERCUTANEOUS SUTURES
The major advantage of this method is its rapidity, as the entire wound is closed before any of the suture material is cut. This technique is most appropriate for long linear lacerations. Because running percutaneous sutures do not enable precise wound edge apposition, it should be avoided in irregularly shaped lacerations. With this method, the first suture is placed at one end of the laceration similarly to an interrupted percutaneous suture.
After the knot is tied, the suture material is not cut, and the needle is reintroduced into the skin on the opposite side, pulling the suture across the wound at a 65­degree angle (Figure 41­4). The needle then crosses the depth of the wound in a circular motion perpendicular to the wound, exiting on the opposite side approximately  to  mm from the wound edge. This process is repeated as needed until the entire wound is approximated and a second knot is tied.
FIGURE 41­4. Continuous or running percutaneous suture. A. Place the initial stitch as a simple interrupted stitch, but do not cut the suture after the knot is securely tied. B and C. Place a second stitch  to  mm from the first stitch as if placing another simple interrupted stitch. D and E. Place a third stitch  to  mm from the second stitch and continue to place additional stitches until the end of the laceration is reached. F. Do not pull the last throw taut against the skin; the loop will act as the tail end of the suture for knot tying. G. Loop the needle end of the suture twice around the tip of the needle driver and grasp the last throw with the tips of the needle driver. H. Pull the last throw through the loops until the knot is against the skin. I. Perform three to five more instrument ties to secure the knot, and then cut off the excess suture. [Reproduced with permission from Reichman EF (ed): Reichman’s
Emergency Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F. Reichman, PhD, MD, Figure 116­9. New York, NY: McGraw­Hill, Inc.]
BURIED DERMAL SUTURES
Deep dermal sutures are used to reduce tension on the wound and to close dead spaces. Placement of buried dermal sutures requires judgment
,27 because the benefits for nongaping small wounds are unproven and their presence may increase the risk of infection in contaminated wounds. Do not suture through adipose tissue to approximate wound edges; adipose tissue will not hold tension, and sutures through adipose tissue are
 unnecessary in clean surgical cases and only promote infection in contaminated wounds.
With buried dermal sutures, the needle is first inserted at the level of the mid dermis on one side of the wound and then exits more superficially below the dermal–epidermal junction (Figure 41­5). The needle is then introduced below the dermal–epidermal junction on the opposite wound side and exits at the level of the mid dermis. Thus, the knot becomes buried in the depth of the tissue when tying of the suture is completed. The first suture is placed at the center of the laceration, followed by additional sutures that sequentially bisect the wound. The number of buried sutures should be limited to those necessary to enable skin closure with minimal tension. There is no difference in surgical site infections after interrupted intradermal
 and interrupted percutaneous suturing ; since placement of interrupted percutaneous sutures is easier and faster, this method is generally preferred in the ED.
FIGURE 41­5. Buried dermal suture. A. Insert the needle into one side of the base of the wound, and drive the needle from deep to superficial, exiting at the dermal– epidermal junction. B. Insert the needle through the dermal–epidermal junction on the opposite side of the wound and drive it through the base of the wound. The suture should exit the base of the wound across from and level with the entrance site of the first throw. C. Pull both free ends of the suture up and out through the laceration. D. Tie a knot in the suture. E. Pull both free ends of the suture to lower the knot to the base of the wound and oppose the tissue. Tie three additional knots to secure the suture. Cut off any excess suture. [Reproduced with permission from Reichman EF (ed):
Reichman’s Emergency Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F. Reichman, PhD, MD, Figure 116­19. New York, NY: McGraw­Hill,
Inc.]
CONTINUOUS SUBCUTICULAR SUTURES
The continuous subcuticular suture is one of the more complex methods of wound closure. The major advantage of this method is that it results in fairly good wound approximation, often without requiring any percutaneous sutures. For this technique, after anchoring the absorbable suture at one end of the wound, sequential, horizontally oriented “bites” are taken immediately below the dermal–epidermal junction, working toward the other end until the wound is adequately approximated (Figure 41­6). The second knot is tied with the tails cut short so as to remain buried.
FIGURE 41­6. Continuous subcuticular sutures. A, B, and C. Place the first stitch into the dermis, just inside the laceration edge, as a buried knot. D. Place the continuous suture until the opposite end of the laceration is reached. E. The final throw should be left lax with a trailing loop of suture. F. The loop should be used as the “tail end” to perform an instrument tie. Tie three or four knots in the suture. Lift the free ends of the suture and cut them just above the knot. Apply adhesive tape across the laceration to help maintain the apposition of the wound. [Reproduced with permission from Reichman
EF (ed): Reichman’s Emergency Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F. Reichman, PhD, MD, Figure 116­18. New York, NY:
McGraw­Hill, Inc.]
VERTICAL MATTRESS SUTURES
Vertical mattress sutures combine some of the advantages of deep and percutaneous sutures—closure of gaping wound edges with excellent wound edge eversion. Vertical mattress sutures are particularly useful in very thin or lax skin and in areas where the deep subcutaneous tissues are too fragile to be used for anchoring tension­reducing sutures (e.g., over the shin). After taking a large, deep bite from both sides of the wound (“far to far”), the direction of the needle is reversed, and a smaller superficial bite is taken from both sides (“near to near”) of the laceration (Figure 41­7). Vertical mattress sutures may result in excessive tension on the more superficial skin edges, which reduces blood supply to the skin and may result in necrosis of the wound margins.
FIGURE 41­7. Vertical mattress suture. A. The needle should enter and exit the skin .0 to .5 cm from the wound edge. B. The needle should traverse the base of the wound and grasp a large amount of tissue. C and D. Reverse the needle. The second throw should enter and exit the skin approximately  to  mm from the wound edge. The first and second throws must be directly over each other and parallel. E. Tie the suture to approximate the wound edges.
The first throw will close the wound base and relieve the tension at the skin surface. The second throw approximates and everts the skin edges.
[Reproduced with permission from Reichman EF (ed): Reichman’s Emergency Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F. Reichman,
PhD, MD, Figure 116­11. New York, NY: McGraw­Hill, Inc.]
A modification of the standard vertical mattress suture is the shorthand version. In this approach, the first stitch is close to the wound edges (“near to near”); the suture is then grasped and pulled away from the wound, elevating the wound edges while a second stitch is performed farther away from
 the wound (“far to far”) (Figure 41­8). This shorthand version can be performed in less time with the same outcome; however, blind placement of the larger bite may injure underlying structures.
FIGURE 41­8. The “shorthand” vertical mattress suture. A and B. Place the first throw close to the lacerated wound edge to approximate the skin edges. C. Grasp and pull the suture to elevate the wound edges. This allows the needle to more easily take a large bite of tissue on the second throw. D. Place the second throw .0 to .5 cm from the wound edge. Release the suture. E. Tie the suture to approximate the wound edges and evert the skin surface. F. The final product looks exactly the same as the traditional vertical mattress suture. [Reproduced with permission from Reichman EF (ed): Reichman’s Emergency
Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F. Reichman, PhD, MD, Figure 116­12. New York, NY: McGraw­Hill, Inc.]
HORIZONTAL MATTRESS SUTURES
The horizontal mattress is a good suture technique to close wounds with poor circulation to the wound edges because no percutaneous punctures that could further disrupt skin perfusion are placed close to the wound edges. This suture also reduces tension at the wound edges and reduces the potential for subsequent local necrosis. Horizontal mattress sutures can close a wound with fewer individual stitches because each stitch encases more tissue than other techniques (Figure 41­9). This suture is useful on the volar surfaces of the hands and fingers, because these delicate skin areas may swell but the skin edges are not easily cut due to the placement of the skin punctures far from the wound. The main disadvantage of the horizontal mattress stitch is the skill required to place the suture to achieve wound eversion.
FIGURE 41­9. Horizontal mattress suture. A. The needle should enter and exit the skin .5 to .0 cm from the wound edge. B. The needle should traverse the base of the wound. C. Reverse the needle and make a second throw .5 cm from the first. D. The needle must enter and exit the skin and the wound edges so that the first and second throws are parallel to each other. E. Pull the free ends of the suture taut to oppose and evert the wound edges. F. The final result. [Reproduced with permission from Reichman EF (ed): Reichman’s Emergency Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F.
Reichman, PhD, MD, Figure 116­14. New York, NY: McGraw­Hill, Inc.]
,32
One variation is the locking horizontal mattress suture, which applies additional force to approximate separated wound edges. This technique passes the needle through the loop formed on the second side before typing the knot. A v­shaped pattern is created as the loop is pulled
 over the wound when the knot is tied on the initial side (Figure 41­10).
FIGURE 41­10. The standard horizontal mattress suture is placed, with 1­ to 2­cm loop of suture left protruding on the second side. The suture needle is then passed through the loop before tying the knot on the initial side, thus pulling the loop across the wound creating a v­shape.

A modification of this technique incorporates the loop into the knot. After initial placement of the horizontal mattress suture, the end of the suture with needle attached is looped twice around the needle driver (Figure 41­11). The tip of the needle driver is passed through the loop to grasp the tail of suture. As the suture tail is pulled back through the loop, the suture looped around the needle driver slides off and the knot is placed over the wound, creating an x­shaped pattern (Figure 41­12).
FIGURE 41­11. The standard horizontal mattress suture is placed, with 1­ to 2­cm loop of suture left protruding on the second side. The end of the suture with needle attached is looped twice around the needle driver. The tip of the needle driver is passed through the loop to grasp the tail of suture and then pulled back out of the loop.
FIGURE 41­12. As the suture tail is pulled through the loop, the suture looped around the needle driver slides off and the knot is placed over the wound, creating an xshaped pattern.
The benefits of these modifications are increased pressure on the wound edges to enhance hemostasis, reduce dehiscence, promote extra wound edge eversion, and achieve precise epidermal edge apposition.
HORIZONTAL HALF­BURIED MATTRESS SUTURES
Horizontal half­buried mattress sutures are particularly well suited for closing the tip of skin flaps and stellate lacerations because they minimize strangulation of the blood supply to the tip. The key to this stitch is that the needle and suture pass through the dermis of the tip and not the epidermis. The needle is introduced percutaneously through one side of the wound, then horizontally through the tip at the level of the dermis.
The suture is completed by exiting the skin through the other side and tying the knot (Figure 41­13). The stitch through the tip of the flap should be at the level of the mid dermis and close to the distal end of the tip to avoid burying of the tip beneath the adjacent wound edges. The stiches through the wound edges adjacent to the tip should exit and enter the wound at the same level of the middle of the dermis to prevent a step off between the wound edges and the tip.
FIGURE 41­13. Half­buried horizontal mattress suture. A. To close a flap tip, place the first stitch percutaneously through the skin adjacent to the tip of the flap.
Advance the needle horizontally through the dermal layer of the flap, the dermal layer of the skin adjacent to the tip of the flap, and out the skin adjacent to the tip of the flap opposite to where the stitch began. The needle must traverse the dermis of the flap and adjacent tissue at the same level of the dermis to properly approximate the wound edges. Gently pull on the free ends of the suture to approximate the flap against the adjacent skin edges. Tie and secure the suture in the usual manner. B. To close a stellate laceration, insert the needle through the skin of the largest flap. Advance the needle so that its tip exits the dermis. Continue to advance the needle through the dermis of each flap. The half­buried horizontal mattress stitch should encompass the tips of all the flaps. [Reproduced with permission from Reichman EF (ed): Reichman’s Emergency Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F. Reichman, PhD, MD, Figure 116­15. New York, NY: McGraw­Hill, Inc.]
STAPLES
The major advantages of staples are their speed and relative ease of use. They are also cost­effective, especially when devices containing fewer staples are used in the ED, where most lacerations are relatively short. However, of all closure techniques, staples allow the least precision in wound approximation. As a result, their use should be limited to linear, nonfacial lacerations. Staples are particularly useful for scalp lacerations because the hair does not require clipping and staples are easier to locate than sutures for removal. However, deep sutures may be required to close lacerations of the galea aponeurotica, whereas percutaneous sutures are always desirable when hemostasis is difficult. In appropriate patients,
33­37  staples have infection rates and cosmetic outcomes similar to sutures. Staple removal is more painful than removal of sutures.
There are few practical differences between the variety of stapling devices commercially available from the standpoint of the emergency practitioner.
The key principle is to approximate the wound edges and align the centerline indicator of the stapler head so that the legs of the staple will straddle the wound an equal distance on each side (Figure 41­14). Touch the stapler lightly to the skin so that the staple comes out and pinches the wound edges together with eversion. Pressing firmly downward can cause depression of the wound edges. After the staple is set, pull the stapler slightly backward to disengage. New stapling devices that allow placement of deep staples are available, but they have not been studied in the ED.
FIGURE 41­14. Laceration repair with staple closure. A. The wound edges are opposed and everted. B. The stapler is applied over the laceration. C. The stapler is applied over the everted wound edges. D. The plunger advances the staple into the wound margins. E. The anvil bends the staple into shape. F. The final result. [Reproduced with permission from Reichman EF (ed): Reichman’s Emergency Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F.
Reichman, PhD, MD, Figure 116­26. New York, NY: McGraw­Hill, Inc.]
ADHESIVE TAPES

Adhesive tapes are the least reactive and most cost­effective of all wound closure devices. Their application is simple, painless, and rapid, and they also do not require formal removal. However, adhesive tapes tend to slough off when exposed to any tension or moisture. As a result, their use is limited to very low­tension simple wounds or for closure of fragile skin subject to low tension, such as superficial skin tears. They are also of little use in noncompliant patients because they are so easy to remove.
To increase their adhesiveness, skin tapes should be used in conjunction with a liquid adhesive adjunct, such as tincture of benzoin or Mastisol®, that is gently painted on either side of the wound edges and allowed to dry until tacky. Because these adhesive adjuncts are toxic to wounds, avoid their introduction into the wound itself.
The tapes should be placed perpendicular to the wound edges approximately  to  mm apart. With long lacerations, the first strip of tape should be placed across the center of the wound followed by additional strips on either side of the wound center (Figure 41­15). To reduce the possibility of skin blistering or premature dislodgement, additional strips should be placed over the ends of the other strips, parallel to the laceration.
FIGURE 41­15. Laceration repair with adhesive tapes. A. After the initial cleansing of the skin, clean the skin surface with acetone or alcohol to remove any surface oils. Allow the skin to dry. Apply benzoin solution to the skin on both sides of the wound with a cotton applicator. B. Cut the skin closure tapes to the proper length. C. Gently tear the end­tab off the back of the card to prevent the strips from deforming. D. Remove a strip from the card. E. Firmly secure the tape to one side of the wound. F. Use the nondominant hand to oppose the wound edges as the tape is brought over and secured to the skin on the opposite wound edge. G and H. Place additional tapes at 2­ to 3­mm intervals until the wound edges are opposed. I. Place pieces of tape across the tape edges to prevent premature removal and skin blistering from the tape ends. [Reproduced with permission from Reichman EF (ed):
Reichman’s Emergency Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F. Reichman, PhD, MD, Figure 116­23. New York, NY: McGraw­Hill,
Inc.]
Simple skin tapes may also be used to reinforce lacerations after suture or staple removal. The cosmetic results and dehiscence rates after closure of
 small (<4 cm) and superficial facial lacerations with tapes are similar to those with cyanoacrylate tissue adhesives. A version of skin tape composed of two independent parts, each with an adhesive underside and multiple interlocking filaments attached to pulling ends, is useful for simple wound
,41 closure (Steri­Strip® S Surgical Skin Closure; 3M, St. Paul, MN; Figure 41­16).
FIGURE 41­16. Application of Steri­Strip® S Surgical Skin Closure (3M, St. Paul, MN). A. The two adhesive pads are applied to the two sides of the wound approximately  to  mm from the wound edges. B. The skin edges are drawn together by pulling on the clear pulling tabs across the wound at a 45­ degree angle in opposite directions approximating and aligning the wound edges.
CYANOACRYLATE TISSUE ADHESIVES

The cyanoacrylate tissue adhesives are liquid monomers that polymerize into a stable bond when they come into contact with moisture. The adhesive is applied topically to the epidermis across the apposed wound edges, forming a strong bridge that holds the wound closed. The adhesive sloughs off in  to  days as the skin renews itself. The tissue adhesives offer many advantages over other wound closure methods. They may be applied rapidly and painlessly to any easily approximated laceration. Because they slough off spontaneously, they do not require removal. The cyanoacrylates form an occlusive dressing that serves as a barrier to microbial penetration. They have antibacterial effects in vitro and reduce infection
 rates in experimental contaminated wound models in animals.

The cyanoacrylate tissue adhesives are similar in strength to 4­0 poliglecaprone subcuticular sutures, but weaker than staples. Tissue adhesives should not be used alone for high­tension wounds nor should they be used for wounds subjected to varying dynamic tension, such as over a moving joint. However, they can be used in conjunction with deep dermal sutures and/or immobilization aimed at reducing wound tension. A variety of octyland butyl­based cyanoacrylate adhesives (alone or in combination) are now commercially available. The tensile strength and surface characteristics of
,46 octyl­ and butyl­cyanoacrylate differ (Table 41­6). Octyl­cyanoacrylate is generally stronger and more flexible than butyl­cyanoacrylate, allowing its use on irregular surfaces and long lacerations. The mechanical characteristics of the adhesive are also determined by a number of additives such as chemical initiators and plasticizers.
TABLE 41­6
Comparison of Butyl­ and Octyl­Cyanoacrylate
Octyl­Cyanoacrylate Butyl­Cyanoacrylate
Number of carbons in side chain  
Bursting strength High Moderate
Plasticizers that enhance flexibility Present Absent
Water resistance Moderate Minimal
Need for refrigeration No Yes
Clinical experience Short and long incisions and lacerations Limited to incisions and lacerations up to  cm
Viscosity High Low
Cost Moderate Slightly less than octyl­cyanoacrylate
Polymerization time 30–45 s 5–10 s
Working time once applicator opened 2–3 min Unlimited
Wound closure with the tissue adhesives is faster than with other wound closure methods, is cost­effective compared with sutures, and has
47­50 comparable rates of infection and ultimate cosmetic appearance. Patient­reported pain scores and physician­reported procedure time are lower
 with tissue adhesives. However, there is a small increase, about 4%, in wound dehiscence using tissue adhesives, emphasizing the need to limit the use of adhesives to low­tension wounds.
Few studies have directly compared the various cyanoacrylate tissue adhesives against each other. For closure of short, simple facial lacerations in
 children, comparable results are seen with either type of cyanoacrylate. For closure of pediatric operative wounds subject to more tension than facial
 lacerations, octyl­cyanoacrylate had a lower wound dehiscence rate.
To ensure optimal results, tissue adhesives should be used only when laceration edges are easily approximated with the practitioner’s hands, forceps, or tape. An assistant can maintain constant and meticulous wound edge apposition while the adhesive is applied. With octyl­cyanoacrylate, the adhesive is carefully expressed through the tip of the applicator and gently brushed over the wound surface parallel to the wound edges in a continuous, steady motion (Figure 41­17A). The adhesive should cover the entire wound and extend  to  mm on either side of the wound edges. A single layer is applied and allowed to dry for  to  seconds. With butyl­cyanoacrylate, the adhesive is applied from the tip of the applicator in discrete drops along the wound edges, similar to “spot welds” (Figure 41­17B), or as bands across the wound (Figure 41­17C).
FIGURE 41­17. Laceration repair with tissue adhesives. A. Apply octyl­cyanoacrylate in a single layer along the wound edges, extending  to  mm on either side. With butyl­cyanoacrylate, the adhesive may also be applied (B) in spots over the laceration or (C) as bands across the laceration. [Reproduced with permission from Reichman EF (ed): Reichman’s Emergency Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F. Reichman, PhD, MD, Figure
117­8. New York, NY: McGraw­Hill, Inc.]
With long or complex lacerations, adhesive tape can be used to approximate the wound edges, making closure with a tissue adhesive easier (Figure

41­18). Application of a tissue adhesive on top of adhesive tape also results in greater wound­bursting strength than either device alone. A
 combination of a mesh tape and tissue adhesive has recently become available and may be especially useful on very long lacerations. However, its cost may be prohibitive in the ED. Care in application will reduce some of the common problems associated with tissue adhesives (Table 41­7).
FIGURE 41­18. Closure of a long or complex laceration is achieved by applying adhesive tape to approximate the wound edges followed by application of the tissue adhesive over the approximated wound and tape.
TABLE 41­7
Avoiding Potential Pitfalls of Tissue Adhesives
Problem Ways to Avoid the Problem
Runoff Position patient with wound parallel to floor.
Use high­viscosity adhesive.
Apply small, controlled amount of adhesive.
Spillage into eyes Cover eyes with moist gauze barrier.
Position patient so adhesive will not run into the eye.
For eyebrow and forehead lacerations, place the patient in the Trendelenburg position.
For lacerations on the cheek and lower face, place the patient in the reverse Trendelenburg position.
Apply petrolatum­based ointment on the eyelashes before applying adhesive.
Wound dehiscence Avoid adhesive use for high­tension wounds.
Reduce exposure to friction or moisture.
Use deep sutures or immobilization for high­tension wounds.
Do not introduce adhesive into wound.
Wound infection Use adhesives only for properly selected wounds.
Use proper wound preparation, including irrigation, exploration, and, when necessary, debridement.
Use proper application technique.
Getting stuck to the wound Practice expressing small amounts of adhesive and controlling runoff.
Alternate the hand used to oppose wound edges prior to complete polymerization of the adhesive.
HAIR APPOSITION
,56
Simple scalp wounds, without contamination or active bleeding, may be closed via the hair apposition technique. This technique is an efficient
,58 alternative to more traditional methods of closure, with potentially fewer complications, less pain to the patient, and less overall cost.
Contraindications to hair apposition closure include long lacerations (e.g., >10 cm), grossly contaminated wounds, uncontrolled bleeding, wounds that gape open and cannot be closed without significant tension, and hair strands adjacent to the wound that are less than  cm in length.
After wound irrigation and control of bleeding, select and twist together three to seven strands of hair at least  cm in length that lie close to the edge on one side of the wound. Repeat this process directly opposite on the other side of the wound. Then twist these two hair bundles in a full 360­degree revolution and secure the intertwined hair bundles by applying a few drops of tissue adhesive. Repeat this process as needed to close the full length of the laceration (Figure 41­19). The patient will not need a routine return visit because the tissue adhesive will flake off and the hair will unravel in about a week.
FIGURE 41­19. The hair apposition technique to close a scalp laceration. A. Grasp hairs on each side of the laceration. Twist the hair strands on each side of the laceration to form a single “rope.” B. Cross the hair ropes to opposite sides of the laceration. C. Twist the two “ropes” of hair together to close the wound and appose the wound edges. D. Apply tissue adhesive to the twisted hair and apposed skin segment of the laceration. [Reproduced with permission from Reichman EF (ed): Reichman’s Emergency Medicine Procedures, 3rd edition. Copyright © 2019 by Eric F. Reichman, PhD, MD, Figure
116­29. New York, NY: McGraw­Hill, Inc.]


