## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 224: Type  Diabetes Mellitus
Mohammad Jalili; Mahtab Niroomand
TYPE  DIABETES MELLITUS
EPIDEMIOLOGY
Type  diabetes mellitus (T2DM) is a complex, chronic metabolic disorder. It is a major public health issue and an important contributor to morbidity
,2 and mortality all over the world. Diabetes reduces the life expectancy of its victims by approximately  years. Mortality and morbidity increase because of increased risk of cardiovascular disease, stroke, visual impairment, renal disease, and amputations.
According to the Centers for Disease Control and Prevention report on ED visits of ≥18­year­old adults in 2014, .2 million were reported with diabetes
 as any listed diagnosis. These included 245,000 visits for hypoglycemia and 207,000 for hyperglycemic crisis.
PATHOPHYSIOLOGY
T2DM is a complex heterogeneous metabolic disorder, characterized by chronic elevation of plasma glucose levels. The pathogenesis is complex and involves interaction of genetic and environmental factors. The most important pathophysiologic features of T2DM are decreased insulin sensitivity
(insulin resistance) and impaired insulin secretion
It is generally believed that, in T2DM, fasting hyperglycemia is caused by increased production of glucose by liver, which is not suppressed because of hepatic resistance to insulin action. Normally, after meals, glucose uptake in peripheral tissues increases and glucose production by gluconeogenesis and glycogenolysis decreases. Insulin acts both directly and indirectly to inhibit gluconeogenesis and glycogenolysis. In T2DM, owing to hepatic resistance to insulin, the liver is programmed to both overproduce and underuse glucose.
However, postprandial hyperglycemia results from several mechanisms: abnormal insulin secretion by pancreatic β cells in response to a meal, impaired regulation of hepatic glucose production, and reduced glucose uptake by peripheral tissues, particularly the skeletal muscle, that are insulin
 sensitive.
Insulin resistance is the diminished tissue response to insulin at one or more sites in the complex pathways of hormone action and requires higher than normal plasma insulin levels to maintain normoglycemia. The major sites of insulin resistance in T2DM are the liver, skeletal muscle, and adipose tissue.

Insulin secretion is usually impaired and generally insufficient to compensate for insulin resistance. The mechanism behind impaired insulin release in T2DM is complicated and includes glucotoxic and lipotoxic effects, as well as deposition of amyloid within islet cells. Glucotoxicity is the negative effect of prolonged and excessive glucose on β­cell function. Lipotoxicity is the exposure to increased levels of free fatty acid, which also impairs β­cell
 function.
The incretin hormonesglucagon­like peptide­1 (GLP­1) and glucose­dependent insulinotropic polypeptide, secreted by intestinal L cells following glucose intake, stimulate pancreatic β cells and are responsible for 50% to 70% of total insulin secretion. In people with T2DM, the incretin system is
,8 functionally impaired, leading to hyperglycemia.
Chronic hyperglycemia is the cornerstone of microvascular complications. Dyslipidemia and hypertension that often accompany T2DM play an
,10 important part in macrovascular complications.
The increased prevalence of infection is primarily attributed to phagocyte dysfunction, including impaired adherence, chemotaxis, phagocytosis,
Downloaded 2025­7­1 6:37 P Your IP11 is 136.142.159.127 bacterial killing, and respiratory burst. Other abnormalities include nonenzymatic glycation of immunoglobulins and reduced T­lymphocyte
Chapter 224: Type  Diabetes Mellitus, Mohammad Jalili; Mahtab Niroomand populations.
. Terms of Use * Privacy Policy * Notice * Accessibility
CLINICAL FEATURES
The classic symptoms, which are usually mild and nonspecific, include fatigue, weakness, polyuria, polydipsia, polyphagia, and blurred vision. Most patients with T2DM are overweight, beyond their 30s, and suffer from other comorbid conditions such as hypertension, cardiovascular disease, dyslipidemia, or polycystic ovary syndrome. Clues in the patient’s past medical history that are suggestive of diabetes mellitus include frequent superficial infections and slow healing of skin lesions after minor trauma.
Acute complications include diabetic ketoacidosis, hyperosmolar hypertonic nonketotic state, and hypoglycemia. Diabetic ketoacidosis and hyperosmolar hypertonic nonketotic state are covered elsewhere in this book (see Chapters 225 and 227), and hypoglycemia, which in most cases is actually a complication of the treatment of diabetes, is discussed separately at the end of this chapter in the “Hypoglycemia” section.
Chronic complications are categorized as microvascular (retinopathy, neuropathy, and nephropathy), macrovascular (coronary artery disease, cerebrovascular disease, peripheral vascular disease), and nonvascular (including infectious) complications. One of the chronic complications of diabetes may be the reason for the ED visit or may be found during review of systems and physical examination. A brief review of the manifestations of the involvement of various organ systems by diabetes is presented in Table 224­1. TABLE 224­1
Chronic Complications of Type  Diabetes Mellitus
Organ
Disorders Comments
Complications
Cardiovascular Coronary artery disease 2­ to 4­fold increase in risk and worse prognosis than in nondiabetics complications Atypical acute coronary syndrome symptoms
Heart failure 2–5 times increased risk in diabetics
Risk factor–adjusted hazard ratio of .82 in men and .73 in women
Diabetic cardiomyopathy Myocardium more susceptible to ischemia and less able to recover after an ischemic insult
Peripheral vascular disease 2–4 times increased in diabetics
Limb claudication, limb ischemia and tissue loss, and amputation
Affects tibial and peroneal arteries, as well as femoral and popliteal arteries
Renal Diabetic nephropathy Affects 5%–40% of patients with type  diabetes complications Present in approximately 7% of the cases at the time of diagnosis
Triad of hypertension, albuminuria, and progressive renal failure
Renal papillary necrosis Asymptomatic or symptoms similar to renal colic or acute pyelonephritis
Urinalysis: necrotic fragments of renal papilla, red and white blood cells, bacteria
Neurologic Stroke  times increased risk of stroke complications Increased risk of recurrent stroke and stroke­related dementia
Chronic sensorimotor distal Burning pain, electrical or stabbing sensations, paresthesia, hyperesthesia, and deep aching symmetric polyneuropathy pain
Loss of vibration, pressure, pain, and temperature sense; commonly in the legs and feet with a symmetric stocking and glove pattern
Proximal motor neuropathy Weakness of the proximal muscles of the lower limbs
Spontaneous or percussion­provoked muscle fasciculation
Onset may be gradual or abrupt
Mononeuropathies May affect a large peripheral nerve or an isolated cranial nerve
Usually sudden onset with pain
Due to entrapment or microvascular infarct
Increased incidence of carpal tunnel syndrome
Autonomic neuropathy May cause dysfunction of every part of the body
Signs include resting tachycardia, orthostatic hypotension, gastroparesis, autonomic diarrhea
(at least  weeks of increased stool frequency and/or liquidity), constipation, erectile dysfunction, neurogenic bladder
Infectious Common infections (pneumonia, Infectious agents usually similar to nondiabetics complications soft tissue infections, and urinary Some organisms more common (Staphylococcus aureus and Mycobacterium tuberculosis in tract infections) pneumonia, and Candida species in urinary tract infections)
Malignant otitis externa Frequently due to Pseudomonas aeruginosa, but staphylococci, fungi, and other gram­negative organisms also have been isolated
Unilateral otalgia, decreased hearing, purulent ear discharge, tenderness of the pinna and periauricular area, swollen external auditory canal, and sometimes fever
Tender, inflamed external auditory canal with a mass of granular­appearing tissue
Can lead to osteomyelitis, meningitis, venous sinus thrombosis, or subdural empyema
Emphysematous cholecystitis Fever and abdominal pain
Gas within the gallbladder and biliary tree on imaging
Most frequently Clostridium species in addition to streptococci, Escherichia coli, and
Pseudomonas
Emphysematous pyelonephritis Rare, life­threatening infection with gas production in renal parenchyma and around the kidney
Fever, clinical toxicity, flank pain, and sometimes a palpable mass
Rhinocerebral mucormycosis Almost exclusively occurs in diabetics
Invasive fungal infection of the nasal and paranasal sinuses, sometimes involving the palate and adjacent tissues
Sudden and rapidly progressive onset
Periorbital or perinasal pain, blood­tinged nasal discharge, unilateral headache, increased tearing, swelling of eyelids and conjunctiva, and decreased vision
Signs can include black eschar on the nasal mucosa or hard palate due to ischemia, proptosis, and, if the infection progresses, cranial nerve involvement or seizures
Ophthalmologic Retinopathy Nonproliferative stage: complications Hard exudates (accumulation of lipid in the outer plexiform layer)
Retinal hemorrhage (flame­shaped hemorrhage in the nerve fiber layer; dot­and­blot hemorrhage in deeper layers of the retina)
Soft exudates (cotton wool spots due to microinfarctions of the retina)
Venous tortuosity and beading
Proliferative stage:
Neovascularization
Vitreous hemorrhage
Rubeosis iridis and the resultant glaucoma
Traction retinal detachment
Eyelids and conjunctiva Recurrent styes, blepharoconjunctivitis, and xanthelasma; fatty deposits in the subcutaneous tissue of the lids
Cornea Bacterial corneal ulcers, neurotropic ulcers, and difficulties with contact lenses
Other Cataracts and open­ and narrow­angle glaucoma
Dermatologic Noninfectious Protracted wound healing, acanthosis nigricans, necrobiosis lipoidica, diabetic dermopathy, complications scleredema, and granuloma annulare
Infectious Cellulitis, furuncles and carbuncles, and candidiasis
Necrotizing fasciitis: typically of mixed bacterial origin, most common organisms: Streptococcus pyogenes, S. aureus, anaerobic streptococci, and Bacteroides.
Fournier's gangrene
Erythrasma: pruritic red­brown patch in the axilla or groin; Corynebacterium minutissimum
CARDIOVASCULAR COMPLICATIONS
“Silent ischemia” (the absence of chest pain despite myocardial ischemia) is common in diabetic patients. It is also common for myocardial infarction to present with atypical or less impressive symptoms such as weakness, fatigue, and confusion. Patients may suffer from pain in unusual locations or with lower than expected severity. This may explain the increased incidence of medically unrecognized acute myocardial infarction in diabetics compared with nondiabetics (40% vs 25%).
NEUROLOGIC COMPLICATIONS
Diabetic neuropathy is a diagnosis of exclusion and should be labeled as such only after other forms of neuropathy, such as chronic inflammatory demyelinating polyneuropathy, vitamin B deficiency, hypothyroidism, and uremia, have been excluded. The most significant morbidity associated
 with diabetic neuropathy is foot ulceration.
It may be difficult in the ED to differentiate the signs and symptoms of diabetic mononeuropathy from a transient ischemic attack or stroke, and imaging and other modalities are needed for diagnosis.
FOOT AND LOWER EXTREMITY COMPLICATIONS
Diabetic foot ulceration results from interaction of many factors, including peripheral neuropathy, excessive plantar pressure, repetitive trauma,
12­14 peripheral vascular disease, and wound­healing disturbances. Ulcers act as a portal of entry for bacteria, resulting in cellulitis and abscess formation. Aerobic gram­positive cocci (especially Staphylococcus aureus) are the predominant pathogens. Gram­negative rods may be encountered in patients with chronic wounds or those who have recently received antibiotic therapy. Those with foot ischemia or gangrene may be infected with
,15 obligate anaerobic microorganisms.
Foot complaints in a diabetic require a thorough foot examination. Ulcer characteristics, including dimensions, depth, appearance (erythema, swelling, and purulence), and location, should be described. Hair and nail growth, calluses, corns, foot deformities, sensation, and vascular status (palpation of pedal and popliteal pulses) should be assessed. It is sometimes difficult to distinguish between lower extremity ulcers resulting from vascular insufficiency and those due to diabetes. Venous ulcers are typically present above the malleoli with irregular borders. Arterial ulcers are often found on the toes or the shins, with pale, “punched­out” borders. These ulcers are typically painful in the absence of coexisting neuropathy. Diabetic ulcers, on the other hand, usually occur at areas of increased pressure (e.g., sole of the foot) or friction (due to footwear). Any ulceration found should be unroofed and probed using a blunt­ended rigid sterile probe to determine the depth. The ability to probe to bone through the ulcer suggests the strong possibility of osteomyelitis and deep­space soft tissue infection. Purulence or inflammation suggests infection, and both aerobic and anaerobic cultures should be taken from purulent drainage or material curetted from the base of the wound. Such specimens are preferable to wound swab specimens, which are often contaminated with colonizing bacteria and often do not identify the infected organism(s).
The diagnosis of osteomyelitis in patients with diabetic foot ulcer remains a challenge. When the wound can be probed to the underlying bone, presence of osteomyelitis is almost certain. Radiographs, although not very sensitive, should be obtained in patients with deep or long­standing ulcers to exclude osteomyelitis, subcutaneous gas, foreign bodies, and Charcot joints. MRI can identify osteomyelitis if radiographs are negative but clinical
,17 suspicion is high. Table 224­2 shows the diagnostic utility of physical examination, laboratory, and basic radiographic testing in the diagnosis of osteomyelitis in patients with diabetic foot ulcer.
TABLE 224­2
Diagnostic Accuracy of Physical Examination, Laboratory, and Imaging Investigations for Lower Extremity Osteomyelitis in Patients with
Diabetic Foot Ulcers* Finding Positive LR (95% CI) Negative LR (95% CI)
Ulcer area >2 cm2 .2 (1.1–49) .48 (0.31–0.76)
Positive “probe­to­bone” test .4 (3.6–11) .39 (0.20–0.76)
Erythrocyte sedimentation rate (with a cutoff of  mm/h)  (1.6–79) .34 (0.06–1.90)†
Plain radiograph .3 (1.6–3.3) .63 (0.51–0.78)
MRI .8 (2.5–5.8) .14 (0.08–0.26)
Abbreviations: CI = confidence interval; LR = likelihood ratio.
*Bone biopsy is considered the gold standard.
†95% CI crosses .0. OPHTHALMIC COMPLICATIONS
,19
Although there are case reports of ocular hemorrhage after thrombolysis with streptokinase, the risk of intraocular bleeding
 following thrombolytic therapy in patients with retinopathy is thought to be very low (0.05%).

In neither the American College of Cardiology/American Heart Association nor the European Society of Cardiology guidelines for the management of patients with ST­segment elevation myocardial infarction has retinopathy been mentioned as the absolute or relative contraindications to intravenous fibrinolytic therapy. Therefore, retinopathy should not be considered a contraindication. The indications and potential complications of thrombolytic therapy should be discussed with the patient before its administration.
RENAL, DERMATOLOGIC, AND INFECTIOUS COMPLICATIONS
Renal, dermatologic, and infectious complications are listed in Table 224­1. DIAGNOSIS
Look for diabetes in the presence of symptoms suggestive of hyperglycemia in the undiagnosed diabetic. It is reasonable to check the glucose level in patients with certain presentations such as unexplained cellulitis, foot ulcers, frequent candidal infections, and unexplained neuropathy.
When evaluating a patient with established diabetes mellitus in the ED, in addition to complaint­directed history and physical examination, give special attention to diabetes­related aspects. Assessment can include questions about prior diabetes care, presence or absence of diabetes complications and diabetes­related comorbidities, and assessment of the patient’s knowledge about the disease. Elements of the history and physical examination relative to T2DM are presented in Tables 224­3 and 224­4. TABLE 224­3
Elements of the Medical History in Patients with Type  Diabetes Mellitus
Key Elements of Medical History
Past Cardiovascular disease, hypertension, dyslipidemia, foot lesions, ophthalmologic diseases, nephropathy, neuropathy, cerebrovascular medical disease history
Prior Type of treatment and recent changes in the regimen; prior glycated hemoglobin A levels; blood sugar self­monitoring results; frequency,
1c diabetes severity, and cause of hyper­ or hypoglycemic episodes; diet and exercise history care
Drug Oral antidiabetic drugs, insulin, diuretics, β­adrenergic agonists, β­adrenergic blockers, aspirin, statins history
Social Smoking, substance abuse history
Review of Skin: dryness, pruritus, color changes, ulcers systems Weight loss
GI: constipation, diarrhea, nausea, gastric fullness
GU: urine, and sexual dysfunction (impotence)
Visual changes
Numbness, dizziness, and weakness
Chest pain
TABLE 224­4
Elements of the Physical Examination in Patients with Type  Diabetes Mellitus
Key Elements of Physical Examination
General Height, weight, and body mass index
Vital signs Blood pressure (including orthostatic measurement)
Head, eye, ear, nose, and Funduscopy (to look for hemorrhage or proliferative retinopathy); visual acuity; intraocular pressure; thyroid palpation throat examination
Skin Intertriginous areas (to look for acanthosis nigricans), insulin injection sites, lancet puncture sites, nonhealing wounds, cellulitis, tinea
Cardiovascular Auscultation of the carotid arteries and abdomen for bruits; assessment of peripheral pulses (especially dorsalis pedis and posterior tibial pulses)
Foot examination Signs of skin breakdown on the feet, signs of infection, determination of proprioception and vibration, monofilament sensation, presence/absence of patellar and ankle reflexes, pinprick or temperature sensation
Diagnosis of diabetes can be done in four ways: fasting plasma glucose level; random glucose level; hemoglobin A (HbA ) level; or 2­hour oral
1c 1c glucose tolerance test. An oral glucose tolerance test is reserved for patients in whom diabetes is strongly suspected despite a normal or impaired
 fasting glucose. HbA is often used to monitor the effectiveness of treatment.
1c
Current criteria for the diagnosis of diabetes are summarized in Table 224­5. Impaired fasting glucose, impaired glucose tolerance, or an HbA level
1c between .7% and .4% is usually referred to as prediabetes and denotes hyperglycemia not sufficient to meet diagnostic criteria for diabetes but significant for being a risk factor for future diabetes and for cardiovascular disease.
TABLE 224­5
Diagnostic Criteria for Diabetes
Impaired Fasting Glucose Impaired Glucose Tolerance
Test Diabetes* (milligrams/dL)
(milligrams/dL) (milligrams/dL)
Fasting plasma glucose† 100–125 (5.5–6.9 mmol/L) — ≥126 (≥6.9 mmol/L)
2­h OGTT — 140–199 (7.8–11 mmol/L) ≥200 (≥11 mmol/L)
Random‡ plasma glucose — — ≥200 (≥11 mmol/L) plus symptoms concentration of diabetes#
HgbA .7–6.4% ≥6.5%
1c
Abbreviations: HgbA = hemoglobin A ; OGTT = oral glucose tolerance test (75­gram glucose load).
1c 1c
*In the absence of unequivocal symptoms of hyperglycemia, these criteria should be confirmed on a subsequent day.
†Fasting is defined as no caloric intake for at least  hours.
‡
Random is defined as any time of the day without regard to time since last meal.
#The classic symptoms of hyperglycemia include polyuria, polydipsia, and unexplained weight loss.
TREATMENT
Treatment of T2DM can be discussed under three topics: the day­to­day prevention of hyperglycemia (long­term management of hyperglycemia); prevention and management of chronic complications; and acute therapy of severe hyperglycemia and life­threatening metabolic decompensation
(i.e., hyperosmolar hypertonic nonketotic state and diabetic ketoacidosis). Diabetic ketoacidosis and hyperosmolar hypertonic nonketotic state are discussed elsewhere in this book (see Chapters 225 and 227, respectively).
The American Diabetes Association recommends that the goal of treatment in nonpregnant adults should be an HbA value <7%. Other guidelines,
1c
 such as that of the American College of Endocrinology, have recommended lower levels. With respect to fasting, premeal, and postprandial targets,
 the American Diabetes Association suggestions are summarized in Table 224­6. TABLE 224­6
Glycemic Goals
Parameter American Diabetes Association Recommended Target
Premeal plasma glucose 80–130 milligrams/dL (4.4–7.2 mmol/L)
Postprandial plasma glucose <180 milligrams/dL (<10 mmol/L)
Hemoglobin A <7.0%
1c
NEWLY DIAGNOSED DIABETIC IN THE ED
The consensus statement on management of T2DM by the American Diabetes Association and the European Association for the Study of Diabetes recommends metformin in combination with lifestyle changes, as well as timely augmentation of therapy with additional agents (including other oral antidiabetic agents and insulin) to achieve recommended levels of glycemic control. This should be done in conjunction with the control of the symptoms of acute hyperglycemia and treatment of the underlying or exacerbating conditions. Metformin can be safely initiated at a dose of
500 milligrams per day for patients whose T2DM has been newly diagnosed in the ED, provided that the estimated glomerular filtration rate is ≥30 mL/min/1.73 m  .  The dose can be increased as needed in 500­milligram increments each week to a maximum of  grams per day. If admission is not warranted and exacerbating factors have been sought and effectively addressed, however, the initiation of pharmacotherapy can also be left to the primary care physician at 24­ to 48­hour follow­up.
ACUTE THERAPY OF SEVERE HYPERGLYCEMIA
Acute hyperglycemia is defined as a blood glucose level of >300 milligrams/dL (>16.7 mmol/L). In this situation, the patient may have excessive urine output, weight loss, fatigue, blurred vision, or prominent neuropathic symptoms. Older patients may develop volume depletion, with acute mental status changes, hypovolemic shock, and acute renal insufficiency. Common precipitants include drug interaction with glucose­altering medications
(most commonly, corticosteroids, sympathomimetics, diuretics, anticonvulsants, salicylates, and β­adrenergic receptor agonists), infections, acute illnesses such as acute coronary syndrome or CNS ischemia, or changes in or noncompliance with the prescribed drug regimen. Volume repletion, IV regular insulin, correction of electrolyte imbalance, and specific therapies directed toward any identified underlying cause of hyperglycemia are the components of treatment.
Regular human insulin is administered IV because absorption of SC insulin in a volume­depleted patient can be erratic. SC administration of insulin in non–volume­depleted patients is acceptable. Insulin lispro is an excellent alternative to regular human insulin. However, insulin lispro does not currently have U.S. Food and Drug Administration approval for IV administration, although many clinicians do use it. Typically, an initial bolus dose of
### .1 to .15 unit/kg IV or SC of regular human insulin or insulin lispro is given, which may be repeated in  to  hours if glucose levels have not fallen at least  milligrams/dL (2.8 mmol/L).
Patients should have a rapid therapeutic response to insulin, and with improved glycemic control, many patients may become more responsive to oral therapies and may be able to switch to oral agents alone after using insulin initially. When initial therapy with insulin can be discontinued because of recovery from an acute illness or marked improvement of metabolic control, a standard oral therapy approach may be instituted.
MANAGEMENT OF HYPERGLYCEMIA IN ED OBSERVATION OR ED BOARDING
With many admitted patients boarding in the ED for longer periods, EPs frequently encounter patients with random blood glucose of 140 mg/dL (7.8 mmol/L) or higher on routine lab tests. The patient may or may not be a known diabetic. Stress and decompensation of diabetes may contribute to the pathophysiology of this problem, or it may be iatrogenic, resulting from either inadvertent cessation of antihyperglycemic medications or administration of hyperglycemia­inducing drugs such as glucocorticoids or vasopressors. Whatever the mechanism, emergency physicians may be called upon to control the patient’s blood glucose. There is some evidence that in patients who are later admitted, paying careful attention to high blood glucose levels in the ED leads to better glycemic control in the hospital.
In critically ill patients, insulin infusion is usually required. The goal is to maintain blood glucose in the range of 140 to 180 mg/dL (7.8 to  mmol/L). More stringent control (with blood glucose <110 mg/dL [<6 mmol/L]) may actually increase mortality and is not recommended.
In patients who are not in a critical condition, subcutaneous insulin with a premeal glucose target of less than 140 mg/dL (7.8 mmol/L) and random blood glucose of less than 180 mg/dL (10 mmol/L) is recommended. In most patients with T2DM admitted for an acute illness, oral hypoglycemic agents should be discontinued and insulin substituted. However, writing orders for sliding scale insulin for admitted patients can lead to undesirable levels of hypoglycemia and hyperglycemia. Sliding scale insulin should not be used for more than  to  hours, and scheduled subcutaneous insulin therapy, consisting of basal (long­ or intermediate­acting) insulin, in combination with bolus/prandial (rapid­ or short­acting) insulin, should be substituted. A total dose of .2 to .5 unit/kg/day is usually required based on the age and renal function of the patient. Half of this dose is administered as basal once or twice a day, and the remaining is given as prandial doses in three equally divided doses before each meal (only if the patient is eating) or every  to  hours (in patients on enteral or parenteral nutrition). If the desired target blood glucose is not achieved, correction
26­28 insulin should also be added to the scheduled insulin regimen. In noncritical diabetic patients who are already on insulin therapy, the patient’s current regimen should be adjusted based on the patient glycemic control status; the .2 to .5 unit/kg/day dose calculation may not be sufficient in these cases.
DISPOSITION AND FOLLOW­UP
Guidelines for admission considerations are listed in Table 224­7. Diabetic patients may need admission for conditions that in nondiabetics are usually treated on an outpatient basis.
TABLE 224­7
Disposition/Guidelines for Hospital Admission
Inpatient care for type  diabetes mellitus is generally appropriate for the following clinical situations:
Life­threatening metabolic decompensation such as diabetic ketoacidosis or hyperglycemic hyperosmolar nonketotic state
Severe chronic complications of diabetes, acute comorbidities, or inadequate social situation
Hyperglycemia (>400 milligrams/dL [>22 mmol/L]) associated with severe volume depletion or refractory to appropriate interventions
Hypoglycemia with neuroglycopenia (altered level of consciousness, altered behavior, coma, seizure) that does not rapidly resolve with correction of hypoglycemia
Hypoglycemia resulting from long­acting oral hypoglycemic agents or hypoglycemia of unknown cause
Fever without an obvious source in patients with poorly controlled diabetes
Patients who present with new­onset T2DM without evidence of metabolic decompensation, acute hypoglycemia, or hyperglycemia and do not meet the aforementioned criteria for admission should see their primary care provider within the week, as a general rule, to arrange for education, dietary evaluation, and initiation or refinement of appropriate therapy for glycemic control.
ANTIDIABETIC PHARMACOTHERAPY
There are several classes of antidiabetic agents. Their classification is based on mechanism of action: agents that cause insulin sensitization primarily in the liver, agents that cause insulin sensitization primarily in peripheral tissues, agents that promote secretion of insulin, agents that block reabsorption of glucose by the kidney, and agents that slow the absorption of carbohydrates (Table 224­8). Combined formulations are available that mix drugs from different classes of antihyperglycemic agents (metformin plus a thiazolidinedione or a secretagogue).
TABLE 224­8
Some Properties of Classes of Antihyperglycemic Agents
α­ GLP1
Glitazones SGLT2 DPP4 Amylin
Parameter Biguanides Sulfonylureas Glinides Glucosidase Receptor
(TZDs) Inhibitors Inhibitors Mimetics
Inhibitors Agonists
Mechanism Suppress Potentiate Potentiate Improve Delay Potentiate Block glucose Potentiate Decrease of action liver glucose insulin insulin insulin intestinal insulin reabsorption insulin glucagon production secretion secretion sensitivity carbohydrate secretion, by the kidney secretion secretion,
(fat, liver, absorption decrease and slow gastric and muscle) glucagon decrease emptying secretion, glucagon and slow secretion gastric emptying
Examples Metformin Glyburide, Repaglinide, Pioglitazone, Acarbose, Exenatide, Canaglifiozin, Sitagliptin Pramlintide glipizide, nateglinide rosiglitazone miglitol liraglutide dapaglifiozin glimepiride
Efficacy High High Modest High Modest High Intermediate Intermediate Modest
Adverse Nausea, Hypoglycemia, Weight gain Edema, Flatulence, Nausea, Genitourinary Angioedema, Nausea, effects diarrhea, weight gain congestive diarrhea vomiting, infections, urticaria, vomiting lactic heart failure, diarrhea euglycemic pancreatitis acidosis weight gain DKA
(rare), vitamin B
 deficiency
Nonglycemic Limits None None None None Weight Weight loss, None Weight loss effects weight gain loss blood pressure reduction
Abbreviation: DKA = diabetic ketoacidosis; DPP4 = dipeptidyl peptidase ; GLP1 = glucagon­like peptide­1; SGLT2 = sodium­glucose cotransporter ; TZD = thiazolidinediones.
METFORMIN
Metformin is the only biguanide available in the United States. Metformin activates adenosine monophosphate–activated protein kinase and hence
,30 reduces hepatic insulin resistance. The resulting effect is decreased gluconeogenesis and glucose production in the liver. Some effect on improving insulin sensitivity in peripheral tissues has inconsistently been suggested. Metformin is usually started at a dose of 500 milligrams once daily
(with a meal) and can be titrated upward slowly to a maximum dose of  grams per day. Due to its short duration of action, metformin is generally taken
 at least twice daily. Metformin bears a wide safety margin ; the most common adverse effects include nausea, diarrhea, crampy abdominal pain, metallic taste, and dysgeusia. Another rare side effect of metformin is lactic acidosis, which almost exclusively occurs in patients with renal insufficiency.Metformin is eliminated by the kidney in unchanged form and so is contraindicated in patients with an estimated glomerular filtration rate of <30 mL/min. Because metformin does not increase insulin levels, it is not associated with a significant risk of hypoglycemia. Other contraindications include hepatic insufficiency, any form of acidosis, severe hypoxemia, and alcohol abuse. Take care when administering metformin simultaneously with nephrotoxic agents such as contrast dye. Withhold metformin for  hours after
IV contrast administration.
GLITAZONES
Glitazones (thiazolidinediones) work through binding and modulation of the activity of peroxisome proliferator–activated receptors. This nuclear receptor influences the differentiation of fibroblasts into adipocytes and lowers free fatty acid levels. Thus, thiazolidinediones improve insulin sensitivity and reduce free fatty acid levels. Pioglitazone and rosiglitazone have replaced the first drug of this class, troglitazone, because they are believed to be safer. Thiazolidinediones are well tolerated, and their only significant adverse effects are weight gain and fluid retention. This class of drugs is contraindicated in the presence of active hepatocellular disease. Thiazolidinediones can increase the risk of bone fractures in
,32 postmenopausal women and older males.
SULFONYLUREAS
Sulfonylureas are the oldest class of oral antidiabetic agents. They bind to the sulfonylurea receptor, a subunit of the adenosine triphosphate– sensitive potassium channel on plasma membrane of pancreatic β cells, causing a series of reactions, thereby leading to insulin secretion (exocytosis of insulin granules). Drugs in this class can be divided into first­ and second­generation agents. First­generation sulfonylureas include chlorpropamide, tolbutamide, tolazamide, and acetohexamide. The second generation of this class includes drugs with higher potency and fewer adverse effects and drug–drug interactions (namely, glipizide, glyburide, gliclazide, and glimepiride). Hypoglycemia and weight gain are the major adverse effects of sulfonylureas (highest risk of hypoglycemia seen with glyburide), and other side effects like allergic reactions, GI intolerance, hyponatremia, or alcohol flushing are very rare and drug dependent.
GLINIDES
Repaglinide is an insulin secretagogue, structurally distinct from the sulfonylureas. It binds to pancreatic β cells and stimulates insulin release.
Repaglinide is absorbed more rapidly and thus produces faster and briefer stimulus to insulin secretion. However, it has a prolonged effect on fasting glucose. The maximum dose of this drug is  milligrams taken with each meal. Repaglinide has an almost completely biliary elimination, and therefore, can be used safely in patients with renal insufficiency.
Nateglinide, a phenylalanine derivative, has an even shorter duration of action than repaglinide. It has a specific effect on postprandial glucose and almost no effect on fasting glucose. This drug is used as 120­milligram tablets taken with each meal.
ALPHA­GLUCOSIDASE INHIBITORS
Acarbose and miglitol inhibit the final step of carbohydrate digestion at the brush border of intestinal epithelium through competitive inhibition of α­ glucosidases. This action delays the absorption of carbohydrates and consequently decreases the postprandial glucose peak and insulin response to the meal. They have only a modest effect on blood glucose reduction and commonly cause flatulence and diarrhea. Their advantage is lowering postprandial glucose without increasing weight or hypoglycemic risk. They should be used cautiously in patients with chronic renal disease.
GLUCAGON­LIKE PEPTIDE  RECEPTOR AGONISTS
In humans, glucagon­like peptide  (GLP­1) mediates the process by which oral glucose has a greater stimulatory effect on endogenous insulin secretion than parenteral glucose (the so­called incretin effect). GLP­1 analogues (also referred to as incretin analogues or incretin mimetics) are available in several formulations and exert their HbA ­lowering and weight reduction effects through several mechanisms: they suppress glucagon
1c secretion, slow gastric emptying, reduce food intake, and promote β­cell proliferation and secretion. GLP­1 analogues are used in the treatment of
33­35
T2DM patients who do not achieve adequate glycemic control on metformin or the combination of metformin and another antidiabetic agent. An important feature of GLP­1 analogues is that this class of drugs increases insulin secretion only in the presence of hyperglycemia resulting from oral intake, leading to a low risk of hypoglycemia. Exenatide (Byetta®) is a synthetic peptide with 53% amino acid similarity to GLP­1. Exenatide is administered at a dose of  to  micrograms twice daily as SC injection in the abdomen, thigh, or arm. Dose adjustment is necessary in patients with end­stage renal failure (creatinine clearance of <30 mL/min). Liraglutide (Victoza®) is a GLP­1 receptor agonist that is injected at a dose of .6 to .2 milligrams once a day, so some prefer it over exenatide. This class of drug is contraindicated in the presence of medullary thyroid cancer or in those with multiple endocrine neoplasia. Pancreatitis is a reported adverse effect, but the evidence is questionable. They should be withheld if the patient develops acute pancreatitis.
DIPEPTIDYL PEPTIDASE  INHIBITORS
Dipeptidyl peptidase  inhibitors prolong the action of native GLP­1 through inhibiting its metabolism by dipeptidyl peptidase . They are administered orally. Saxagliptin, sitagliptin, linagliptin, and vildagliptin are some of available preparations. Dipeptidyl peptidase  inhibitors (except linagliptin) need dose adjustment in renal dysfunction. A safety alert was issued for saxagliptin in February 2014 due to possible association with heart failure. This class should be used cautiously in patients with history of pancreatitis.
AMYLIN ANALOGUES
Amylin is a neuroendocrine peptide that is normally cosecreted with insulin from the pancreatic β cells. It has a complementary action for insulin in regulating plasma glucose. In T2DM, secretion of amylin diminishes and is delayed in advanced stages of the disease. Pramlintide is the synthetic analogue of amylin with several metabolic effects: It (1) suppresses endogenous secretion of glucagon, especially in the postprandial state, thereby decreasing postprandial hepatic glucose production; (2) reduces the rate of gastric emptying; (3) decreases appetite and induces satiety; and (4)
36­38 reduces postprandial glucose levels. Pramlintide is used as a 120­microgram SC injection at mealtime in patients with type  diabetes as well as patients with T2DM who are treated with insulin but who are very vigilant with insulin dosage and blood glucose monitoring. It carries a U.S. Food and
Drug Administration black box warning; if given with insulin therapy, it can induce severe hypoglycemia, especially within  hours of insulin administration.
SODIUM­GLUCOSE COTRANSPORTER  INHIBITORS
This group of drugs, through a mechanism that is independent of insulin, inhibits sodium­glucose cotransporter  in the proximal nephron, thereby decreasing reabsorption of glucose and increasing glucose and sodium excretion in the urine. This leads to the reduction of HbA as well as systolic
1c and diastolic blood pressure. Due to their mechanism of action, their effectiveness decreases at the estimated glomerular filtration rate of less than 
 to  mL/min/1.73 m . Canagliflozin, dapagliflozin, and empagliflozin are the available formularies in this group. Sodium­glucose cotransporter 
 inhibitors have been reported to be associated with euglycemic DKA. Therefore, in diabetic patients taking sodium­glucose cotransporter  inhibitors, the presence of nausea, vomiting, malaise, or metabolic acidosis should prompt the clinician to look for the presence of urine and/or serum ketones.
INSULIN
Decreased secretion of insulin due to declining β­cell function eventually makes oral antidiabetic agents ineffective in achieving glycemic control and leads to the need for insulin therapy. Insulin can be used to supplement endogenous production of insulin both in the basal and postprandial state.
Traditionally, insulin has been used for the treatment of T2DM when nutritional therapy and oral agents have failed to control blood glucose levels.
There is, however, an increasing trend toward the initiation of insulin at an earlier stage of the disease. Besides when therapy with oral agents fails to achieve the glycemic target, insulin may be used in the treatment of T2DM in several other situations: during the perioperative period in a diabetic patient, for treatment of acute hyperglycemic crises, and even as the initial therapy in severe hyperglycemia (blood glucose ≥300 milligrams/dL or
HbA ≥10%). There are several formulations of insulin available, with different pharmacokinetics. See Chapter 223, “Type  Diabetes Mellitus,” for
1c detailed discussion of insulins.
PREVENTION AND MANAGEMENT OF CHRONIC COMPLICATIONS
Emergency physicians can reinforce patient education and provide access to additional resources as necessary. Interventions that may be initiated or augmented in the ED for chronic complications are presented in Table 224­9, 224­10, and 224­11 and are briefly discussed below.
TABLE 224­9
Management of Diabetes Complications
Complication Treatment
Hypertension Lifestyle modification
ACEI and ARB are the preferred agents if albuminuria is present
Thiazide­like diuretics or dihydropyridine calcium channel blockers can also be used
Dyslipidemia Lifestyle modifications
Moderate to high­intensity statin therapy
PCSK9 inhibitors in refractory cases
Fibrates for extreme hypertriglyceridemia
Acute coronary Same as in nondiabetic patients syndrome
Nephropathy ACEI or ARB (if hypertensive)
Retinopathy Optimize glucose and blood pressure control
Prompt referral of patients with any level of macular edema, severe nonproliferative diabetic retinopathy, or any proliferative diabetic retinopathy
Bleeding after thrombolytic therapy felt to be very low (0.05%); discuss risks/benefits before administration
Neuropathy Improved glycemic control
Pharmacologic treatment
Abbreviations: ACEI = angiotensin­converting enzyme inhibitor; ARB = angiotensin II receptor blocker; PCSK9 = proprotein convertase subtilisin/kexin type . TABLE 224­10
Drugs Used in the Treatment of Symptomatic Diabetic Autonomic Neuropathy
Class Examples Typical Dosages* Tricyclic drugs Amitriptyline 10–75 milligrams at bedtime
Nortriptyline 25–75 milligrams at bedtime
Imipramine 25–75 milligrams at bedtime
Anticonvulsants Gabapentin 300–1200 milligrams twice a day
Carbamazepine 200–400 milligrams twice a day
Pregabalin† 100 milligrams twice a day
5­Hydroxytryptamine and norepinephrine uptake inhibitor Duloxetine† 60–120 milligrams daily
Substance P inhibitor Capsaicin cream .025%–0.075% applied twice a day or four times a day
Opioids
Tapentadol
(extended release)† 50–250 milligrams orally twice a day
*Dose response may vary; initial doses need to be low and titrated up.
†Has U.S. Food and Drug Administration indication for treatment of painful diabetic neuropathy.
TABLE 224­11
Symptomatic Treatment of Selected Autonomic Neuropathies in Diabetic Patients
Manifestation of Autonomic Neuropathy Treatment
Gastroparesis Frequent small meals, prokinetic agents (e.g., metoclopramide), dietary modification
Diarrhea Soluble fiber, anticholinergic agents, cholestyramine
Constipation Dietary fiber supplementation, bulking agents, stool softener
Neurogenic bladder Bethanechol, intermittent catheterization
Erectile dysfunction Psychological counseling, phosphodiesterase inhibitors (e.g., sildenafil)
Postural hypotension Increasing salt intake (in the absence of hypertension), elastic stockings, midodrine, or droxidopa
Anhydrosis Scopolamine, emollients, skin lubricants
LOWER EXTREMITY AND FOOT COMPLICATIONS
From a clinical standpoint, foot ulcers can be classified as non–limb­threatening, limb­threatening, or life­threatening infections. Non–limbthreatening infection is defined as one that is small (<2 cm of surrounding cellulitis or inflammation), does not involve deep structures or bone, and is the result of recent injury to a well­perfused limb. The patient has no signs of systemic toxicity or leukocytosis. Limb­threatening infections are characterized by the presence of >2 cm of surrounding cellulitis or inflammation, with associated ascending lymphangitis, deep full­thickness ulceration or abscess, a large area of necrotic tissue, involvement of deep structures or bone, gangrene adjacent to the ulcer, or critical lower extremity ischemia (i.e., absence of palpable pulses). Life­threatening infection has clinical signs of sepsis, including fever, leukocytosis, hypotension, tachycardia, tachypnea, altered mental status, and metabolic abnormalities ranging from hypoglycemia to diabetic ketoacidosis and hyperosmolar hypertonic nonketotic state (Table 224­12).
TABLE 224­12
Clinical Practice Pathways for Diabetic Foot Ulcer and Infection
Extent of
Characteristics Diagnostic Procedures Treatment
Infection
Non–limb­ <2 cm cellulitis Cultures from base of ulcer (with tissue specimen if Outpatient management with follow­up in 24– threatening Superficial ulcer possible)  h infection Mild infection Diagnostic imaging (radiography, MRI, nuclear scans as Debridement of all necrotic tissue and callus
No systemic toxicity indicated) Wound care/dressing
No ischemic changes Serologic testing Empiric antibiotic coverage, modified by culture
No bone or joint CBC with differential findings involvement ESR Appropriate off­loading of weight bearing
Does not probe to Comprehensive metabolic panel Wound care continued with packs, dressings, bone and debridement as needed
Hospital admission if infection progresses or systemic signs or symptoms develop
Refer to podiatrist for follow­up care, special shoes, and prostheses as needed
Life­ or limb­ >2 cm cellulitis Deep culture from base of ulcer/wound with tissue Hospital admission threatening Deep ulcer specimen if possible Surgical debridement with resection of all infection Odor or purulent Diagnostic imaging (radiography, MRI, nuclear scan, necrotic bone and soft tissue drainage from wound bone scan, leukocyte scan, arteriography) Exploration and drainage of deep abscess
Fever Serologic testing Empiric antibiotic coverage, modified by culture
Ischemic changes CBC with differential findings
Lymphangitis, edema ESR Surgical resection of osteomyelitis
Sepsis or septic shock Comprehensive metabolic panel Wound care continued with packs, dressings,
Blood cultures debridement as needed
Foot­sparing reconstructive procedures
Refer to podiatrist for follow­up care, special shoes, and prostheses as needed
Abbreviation: ESR = erythrocyte sedimentation rate.
Management of foot ulcers requires a multidisciplinary approach. Principles of management include debridement of necrotic tissues, avoidance of pressure points, management of infection (Table 224­13) and/or ischemia, management of hyperglycemia and other medical comorbidities, proper wound handling, and surgery.
TABLE 224­13
Antimicrobial Therapy in Infected Diabetes­Related Lower Extremity Ulcers
Non–limb­threatening* Cephalexin, 500 milligrams PO every  h, 10­d course
Or
Clindamycin, 300–450 milligrams PO every 6–8 h, 10­d course
Or
Dicloxacillin, 500 milligrams PO every  h, 10­d course
Or
Amoxicillin­clavulanate, 875/125 milligrams PO every  h, 10­d course
Or
Clarithromycin 500 milligrams PO every  h (in severe penicillin allergy)
Limb­threatening* Oral regimen†:
(Ciprofloxacinorlevofloxacinormoxifloxacin) plusclindamycin
Or
Trimethoprim­sulfamethoxazole plus amoxicillin­clavulanate
IV regimens:
Ampicillin­sulbactam,  grams every  h
Or
Piperacillin­tazobactam .5 grams every 6–8 h
Or
Clindamycin, 900 milligrams every  h plus
(ciprofloxacin, 400 milligrams every 8–12 h
Or
Ceftriaxone,  gram every  h)
Life­threatening* IV regimens:
Imipenem­cilastatin, 500 milligrams every  h
Or
Meropenem  gram every  h
Or
Vancomycin, 15–20 milligram/kg every  h, plusmetronidazole, 500 milligrams every  h, plus (aztreonam,  grams every 6–8 h
Or
Ciprofloxacin 400 milligrams every 8–12 h)
(if MRSA coverage is warranted)
Abbreviation: MRSA = methicillin­resistant Staphylococcus aureus.
Note: Adjust all dosages for renal/hepatic function and monitor blood levels where appropriate.
*See the section “Lower Extremity and Foot Complications” for definitions.
†This approach is acceptable under special circumstances with close follow­up.
Treatment of noninfected chronic wounds mostly relies on avoidance of weight bearing and nonadherent padded dressings. Prophylactic antibiotics are not recommended. Refer to a specialist in diabetes­related foot care within a few days to consider the need for debridement, total contact casting, further evaluation of any bony deformity or neuropathy, and evaluation for peripheral vascular disease.
Non–limb­threatening infections can usually be managed in the outpatient setting with appropriate minor debridement and administration of oral antibiotic therapy (Table 224­13). Application of well­padded dressing and avoidance of pressure to the affected area are necessary for adequate wound healing.
Treatment of limb­threatening infections requires hospitalization, IV antibiotics (Table 224­13), and surgical debridement. Direct empiric antibiotics against the predominant pathogens, Staphylococcus and Streptococcus species. Include coverage for aerobic gram­negative and anaerobic bacteria for gangrenous, ischemic, or malodorous wounds. Topical antibiotics are generally not recommended. In the absence of palpable pedal pulses, vascular ultrasonography is needed. Further studies can include the ankle­brachial index, toe pressures, or measurement of transcutaneous oxygen tension. Immediate surgical consultation is indicated for incision and debridement, possible revascularization, or amputation.
HYPOGLYCEMIA
Hypoglycemia is often a complication of the treatment of diabetes mellitus. However, some cases of hypoglycemia encountered in the ED are spontaneous. Timely recognition of this diagnosis and prompt intervention, as well as initiating the workup for the etiology of the spontaneous
 hypoglycemic event, are important yet sometimes challenging tasks.
Although there is no fixed laboratory definition of hypoglycemia, in a nondiabetic patient, it is clinically defined as follows: (1) symptoms consistent with the diagnosis; (2) symptoms associated with a low glucose level; and (3) symptoms resolve with glucose administration. 41­43 The definition of hypoglycemia in diabetics is more complex. Generally speaking, a plasma glucose concentration of ≤70
 milligrams/dL (3.9 mmol/L) is often considered as a reasonable threshold to alert the patient to the possibility of developing hypoglycemia.
PATHOPHYSIOLOGY
Although the human brain depends on glucose as its primary source of energy, it is unable to synthesize or store glucose, accounting for the common manifestation of hypoglycemia as altered mental status. Physiologic response to low blood glucose includes suppression of insulin secretion and release of the counterregulatory hormones (e.g., glucagon and epinephrine). These responses are modified with increasing age. Renal clearance of insulin decreases with age, and this may enhance the risk of hypoglycemia in the elderly. On the other hand, in subjects with T2DM, counterregulatory hormones are secreted at higher blood glucose levels (compared with nondiabetics and those with type  diabetes mellitus), resulting in some protection against hypoglycemia in patients with T2DM. Improved glycemic control through insulin therapy lowers the blood glucose level threshold for the counterregulatory response and offsets this protective effect of diabetes.
Hypoglycemia occurs most frequently with insulin and sulfonylureas. Hypoglycemia is not a common side effect of treatment with glitazones, glinides, or α­glucosidase inhibitors. Among sulfonylureas, the risk of hypoglycemia depends on the pharmacokinetic properties of each agent.
Chlorpropamide, glyburide (glibenclamide), and long­acting glipizide are long­acting sulfonylureas and are associated with more episodes of hypoglycemia. Hypoglycemia is rarely, if ever, encountered in patients using only metformin. Risk factors for severe hypoglycemia in patients with
T2DM include age, past history of vascular disease, renal failure, decreased food ingestion, alcohol consumption, and drug interactions. In nondiabetics, other causes such as adverse effects of drugs (and alcohol), factitious hypoglycemia, tumors (insulinoma or non–islet cell), critical illness
(e.g., sepsis or liver failure), and hormone deficiencies (adrenal insufficiency or hypopituitarism) should be considered.
CLINICAL FEATURES
The clinical manifestations of hypoglycemia are divided into two broad categories: neuroglycopenic and autonomic. Autonomic findings consist of adrenergic symptoms (including anxiety, nervousness, irritability, nausea, vomiting, palpitations, and tremor) and cholinergic symptoms (e.g., sweating, hunger, and paresthesias). Neuroglycopenic manifestations include alterations in consciousness, lethargy, confusion, combativeness, agitation, seizures, and focal neurologic deficits. The patient is commonly found pale and diaphoretic, with some levels of altered mental status. Table 224­14 lists various medical conditions that may be mistaken for hypoglycemia.
TABLE 224­14
Differential Diagnosis of Hypoglycemia
Stroke
Transient ischemic attack
Seizure disorder
Traumatic head injury
Brain tumor
Narcolepsy
Multiple sclerosis
Psychosis
Sympathomimetic drug ingestion
Hysteria
Altered sleep patterns and nightmares
Depression
DIAGNOSIS
Always consider hypoglycemia (in both the ED and the prehospital setting) as a potential cause of altered mental status. Failure to determine the blood glucose level early in the evaluation can result in a delayed or missed diagnosis with associated morbidity because of CNS injury or unnecessary invasive procedures and therapies. Confirm hypoglycemia with bedside glucose testing. The accuracy of bedside reflectance tests is acceptable although less reliable at extremely low and high glucose levels. Glucose values of whole blood are approximately 15% less than that of serum or plasma. This discrepancy is a result of the relatively low glucose concentration in red blood cells. Whenever possible, send a serum sample to the laboratory for confirmation. In diabetic patients who develop hypoglycemia while taking the usual dose of sulfonylurea, suspect an underlying cause. Drug interactions, decreased drug metabolism, and decreased drug excretion are common precipitating causes. In nondiabetic patients, without history of inadvertent or deliberate use of blood sugar–lowering agents, obtain a serum sample before initiation of dextrose therapy.
This sample can later be sent to the laboratory for measuring serum insulin, pro­insulin, and C­peptide, at the discretion of the consultant endocrinologist. This simple measure obviates the need to perform a fasting test in order to diagnose the cause of hypoglycemia.
TREATMENT
Regardless of the cause, management of hypoglycemia in the ED includes prompt diagnosis and PO or IV administration of rapidly metabolized carbohydrates (i.e., glucose or dextrose). In patients with altered mental status, 50% dextrose in water is administered IV as a bolus dose of  mL, which provides  grams of glucose. This dose may be repeated after  minutes if hypoglycemia persists. When blood glucose reaches  milligrams/dL and the patient regains consciousness, continue carbohydrates to prevent recurrence of hypoglycemia. This can be accomplished through PO administration of long­acting carbohydrates. If blood glucose is normalized but the patient is still unconscious or receiving nothing by mouth, provide a continuous IV infusion of dextrose (5% dextrose in water at a rate to maintain the serum glucose >100 milligrams/dL [5.55 mmol/L]).
Check blood glucose every  minutes for the first  hours, looking for rebound hypoglycemia. If hyperglycemia is maintained by slow administration of dextrose, the infusion may be reduced and eventually withdrawn.
Failure to respond to parenteral glucose administration should prompt consideration of other causes of hypoglycemia, such as sepsis, toxin, insulinoma, hepatic failure, or adrenal insufficiency. Hypoglycemia resulting from sulfonylureas is much more challenging than insulin­induced hypoglycemia. Hemodialysis and charcoal hemoperfusion, although mentioned in case reports, are not routinely recommended for sulfonylurea overdose.
Since sulfonylureas cause glucose­stimulated insulin secretion, glucose administration may potentially aggravate hypoglycemia in these cases.
Octreotide is a somatostatin analog and is able to suppress insulin secretion immediately and negates the effects of the sulfonylurea. It can be used successfully for the treatment of sulfonylurea­induced hypoglycemia and is believed to be superior to glucose and diazoxide in preventing recurrent hypoglycemia. The ideal dosage and interval of octreotide are not well defined. Recommendations vary from a single 50­ to 100­microgram SC injection after a single hypoglycemic episode, to serial SC injections (50 to 100 micrograms every  to  hours) or constant IV infusion (125 micrograms/h) after a second hypoglycemic episode. Some suggest that the addition of octreotide,  micrograms SC, to standard therapy may result in a decrease in
,46 frequency of hypoglycemic episodes and an increase in mean plasma glucose. Octreotide is only recommended after initial glucose therapy has been initiated for sulfonylurea­induced hypoglycemia and can be considered when the response to dextrose is inadequate. It is primarily used to reduce the risk of recurrent hypoglycemia.
Glucagon is a U.S. Food and Drug Administration–approved alternative that may be used SC or IM in the absence of IV access. SC injection of this polypeptide hormone can cause an approximate 100 milligram/dL (5.55 mmol/L) increase in serum glucose of hypoglycemic patients. Response to glucagon therapy is generally slower when compared with IV dextrose, requiring  to  minutes for normalization of mental status. Additionally, the response to glucagon administration may be short lived. In adults, glucagon is administered at the dose of  milligram as an SC or IM
 injection. Intranasal glucagon has also been used safely in some studies for the treatment of hypoglycemia. In patients who are thought to be glycogen­depleted (such as heavy alcohol users or marathon runners after the race), glucagon therapy is not recommended. Glucagon is not recommended for sulfonylurea­induced hypoglycemia.
Diazoxide has also been used in the treatment of refractory sulfonylurea­induced hypoglycemia. It acts by directly inhibiting insulin secretion from pancreatic β cells. Diazoxide may cause hypotension and so should be administered as a slow IV infusion (300 milligrams over  minutes every  hours).
DISPOSITION AND FOLLOW­UP
Patients who experience hypoglycemia due to sulfonylureas, non–short­acting insulins, or meglitinides should be admitted for serial glucose monitoring and treatment. A patient with an isolated episode of accidental hypoglycemia not resulting from oral hypoglycemic agents of long­acting insulins, who has reliable follow­up, may be discharged from the ED upon completion of an uneventful 4­hour observation
 period.


