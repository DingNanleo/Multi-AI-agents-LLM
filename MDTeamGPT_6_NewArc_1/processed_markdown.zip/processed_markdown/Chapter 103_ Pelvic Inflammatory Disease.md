## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 103: Pelvic Inflammatory Disease
Brian Weiss; Suzanne M. Shepherd
INTRODUCTION AND EPIDEMIOLOGY
Content Update: CDC PID Treatment Guidelines October 2021
See Table 103­4 and 103­5 for the most current CDC treatment updates.
The term pelvic inflammatory disease (PID) comprises a spectrum of infections of the female upper reproductive tract. Although accurate estimates of the incidence and prevalence of PID in the United States are lacking due to lack of mandatory reporting and reliance on testing data, it is a common and serious disease initiated by ascending infection from the vagina and cervix. PID includes salpingitis, endometritis, myometritis, parametritis, oophoritis, and tubo­ovarian abscess and may extend to produce peri­appendicitis, pelvic peritonitis, and perihepatitis (Fitz­Hugh–Curtis syndrome).

PID is the most common serious infection in sexually active women age  to  years. In 2001, ambulatory data estimated that more than 750,000
 cases of PID occurred in the United States. The percentage of ED visits resulting in a diagnosis of PID decreased during 2006 to 2018 among females age  to  years (28.1% overall reduction, –4.3% annual change). Patients with less access to health care, including those without insurance or with
 public health insurance and those with lower median incomes, were the most likely to visit EDs.
Long­term sequelae, including tubal factor infertility, implantation failure after in vitro fertilization, ectopic pregnancy, and chronic pain, may
 ultimately affect 11% of reproductive­aged women. The most common cause of death is rupture of a tubo­ovarian abscess, with mortality associated with rupture remaining at 5% to 10%, even with current treatment methods.
PATHOPHYSIOLOGY
ORGANISMS ASSOCIATED WITH PID
Neisseria gonorrhoeae and Chlamydia trachomatis can be isolated in many cases of PID, and therapy is largely directed against these organisms.
Chlamydia has developed a number of mechanisms to avoid autophagy and destruction by the host immune system and is able to persist in a
5–7 nonreplicative form in host epithelial cells. Polymicrobial infection, including infection with anaerobic and aerobic vaginal flora, is evident from
 cultured material from the upper reproductive tract. Table 103­1 lists common pathogenic organisms associated with acute or subclinical PID. N.
gonorrhoeae, C. trachomatis, and bacterial vaginosis–associated organisms are usually instrumental in initial infection of the upper genital tract.

Approximately 15% of cases are due to enteric or respiratory organisms that have colonized the lower genital tract. Anaerobes, facultative anaerobes, and other bacteria are isolated increasingly as inflammation develops and abscesses form.
TABLE 103­1
Organisms Associated With Pelvic Inflammatory Disease
Sexually transmitted organisms
Chlamydia trachomatis
Neisseria gonorrhoeae
Herpes simplex virus (types  and 2)
Trichomonas vaginalis

Chapter 103: Pelvic Inflammatory Disease, Brian Weiss; Suzanne M. Shepherd 
Endogenous genital tract Mycoplasma
. Terms of Use * Privacy Policy * Notice * Accessibility
Mycoplasma genitalium, Mycoplasma hominis, Ureaplasma urealyticum
Anaerobic bacteria
Bacteroides species, Peptostreptococcus, Prevotella bivia, Leptotrichia sanguinegens/amnionii, Atopobium vaginae
Aerobic bacteria
Gardnerella vaginalis, Haemophilus influenzae, Streptococcus agalactiae, Escherichia coli, and other gram­negative rods, Actinomyces israelii,
Campylobacter fetus
Bacterial vaginosis is frequently identified in women with PID, and the type of bacterial vaginosis–associated microorganism (Gardnerella vaginalis,
Mycoplasma hominis, Ureaplasma urealyticum, pigmented or nonpigmented anaerobic gram­negative rods) may make a difference in the likelihood of
,9,10 developing PID. Sexually transmitted Mycoplasma genitalium has increasingly been implicated as contributory or causative to both cervicitis and
,11­14 ascending disease.
Infection with Trichomonas vaginalis is associated with a fourfold increase in the incidence of acute endometritis. Coinfection with herpes simplex virus type  and C. trachomatis, N. gonorrhoeae, or bacteria causing vaginosis is also associated with acute endometritis. Infection with
 herpes simplex virus type  causes fallopian tube inflammation and lower tract ulceration that may disrupt the endocervical canal mucous barrier.
Human immunodeficiency virus  (HIV­1) infection is associated with an increased incidence of C. trachomatis infection, increased incidence of
 coinfection with Candida and human papillomavirus, and increased risk of progression to PID.

Chronic PID may result from Mycobacterium tuberculosis infection in endemic areas. Schistosomes can cause genital infection, including a PID­ like tubal infection, infertility, and chronic abortion, and a recent report links schistosomiasis to HIV transmission in Africa. Actinomyces species have
 been identified almost exclusively in patients with intrauterine devices (IUDs).
ASCENDING INFECTION
Most cases of PID are presumed to originate with sexually transmitted infections of the lower genital tract, followed by ascending infection of the upper
 tract. The original sexually transmitted infection may be asymptomatic, as may the ascending infection (subclinical PID). The precise mechanisms by which upper genital tract infection and inflammation are initiated and propagated are not well understood. Although the cervical mucus serves as a functional barrier to ascending infection much of the time, its efficacy may be decreased by a number of factors, including enzymes produced by
,21 bacterial vaginosis–associated organisms that degrade cervical mucus and antimicrobial peptides, hormonal changes during menstruation and ovulation, and retrograde menstruation. Intercourse may contribute to the ascent of infection due to rhythmic mechanical uterine contractions.
Bacteria also may be carried by, or along with, sperm into the uterus and tubes. Uterine infection usually is limited to the endometrium, but can be more invasive in a gravid or postpartum uterus. Tubal infection initially affects only the mucosa, but acute, complement­mediated transmural inflammation may develop rapidly and increase in intensity with repeated infection. Inflammation may extend to uninfected parametrial structures, including the appendix and bowel. Infection may spread by direct extension of purulent material from the fallopian tubes or via lymphatic spread beyond the pelvis to involve the hepatic capsule with acute perihepatitis (Fitz­Hugh–Curtis syndrome) and produce acute peritonitis.
RISK FACTORS FOR PID
,22­29
Multiple risk factors are associated with development of PID (Table 103­2).
TABLE 103­2
Risk Factors Associated With Pelvic Inflammatory Disease23–29
Multiple sexual partners
History of sexually transmitted infection or pelvic inflammatory disease
History of sexual abuse
Frequent vaginal douching
Intrauterine device insertion within previous month
Adolescence, younger adulthood
Lower socioeconomic status
Post­abortion
IUD use has been associated with an increased risk for PID. Although the majority of risk occurs within  days of insertion, the presence of an IUD is
,25­27 associated with complicated PID irrespective of the duration of use. The risk of PID in IUD users is more related to the development of sexually
,31 transmitted infection than the IUD, and sexually transmitted infection screening and treatment at the time of insertion can significantly decrease
 the likelihood that PID will develop.
Pregnancy decreases the risk of PID because the cervical os is protected by the mucous plug. However, PID can occur during the first trimester and is associated with substantial fetal loss and preterm delivery.
COMPLICATIONS OF PID
PID is associated with a number of serious clinical sequelae. Tubo­ovarian abscess is reported in up to one third of women hospitalized for PID.
Infection and inflammation can lead to loss of ciliated epithelial cells in the fallopian tubes and to scarring and adhesions with obstruction within tubal lumens. Ectopic pregnancy is more frequent in women who have had PID than in those who have never had an ectopic pregnancy.
Tubal factor infertility is increased by 12% to 50% in women with a past diagnosis of PID, and the incidence increases with the number and severity of
 past PID episodes. Asymptomatic or silent PID also appears to be associated with tubal factor infertility. Sequelae of PID include recurrence of PID, chronic pelvic pain, menstrual disturbances, and chronic dyspareunia. Recurrence of PID may occur because of inadequately treated infection, nontreatment of partner(s), or reinfection from another sexual contact. In follow­up to the Pelvic Inflammatory Disease Evaluation and Clinical Health
 trial, those with recurrence of PID were five times more likely to experience chronic pelvic pain. PID may also be associated with an increased risk of
 borderline ovarian tumors.
CLINICAL FEATURES
The clinical presentation of PID is variable. The most common presenting complaint is lower abdominal pain, most frequently described as bilateral and dull or crampy. Pain may be exacerbated by movement or by sexual activity. Other symptoms include abnormal vaginal discharge (75% of individuals), vaginal bleeding (including increased or prolonged menstrual bleeding) and postcoital bleeding (more than one third of patients),
 irritative voiding symptoms, and much less commonly systemic signs of fever, malaise, nausea, and vomiting. Symptoms usually occur early in the menstrual cycle or at the end of the menses and are attributed to low progesterone levels and coincident thinning of the cervical mucosal barrier.
The physical examination usually is notable for lower abdominal tenderness, cervical motion tenderness, and uterine or adnexal tenderness.
Involuntary guarding and rebound tenderness may be present and may indicate associated peritonitis. The positive predictive value of these findings
 varies depending on the prevalence of PID in a given clinical population. Adnexal tenderness appears to have a sensitivity of 95%. Mucopurulent cervicitis is common, and its absence should raise consideration of another diagnosis. In women suspected of having PID and for whom there is no likely alternative diagnosis for abdominal pain, the presence of fever, adnexal tenderness, and an elevated erythrocyte sedimentation rate are significant independent predictors of endometritis and correctly classify 65% of patients with laparoscopically proven PID (95% confidence interval,
,38
61% to 99%).
Right upper quadrant tenderness, particularly with jaundice, may indicate perihepatic inflammation. Fitz­Hugh–Curtis syndrome (perihepatitis) is strongly suggested by right upper quadrant pain, and occasionally slightly elevated transaminases, in a woman with a clinical diagnosis of PID and no
 other cause for this pain. It is an uncommon complication and responds to standard antibiotic treatment for PID.
The differential diagnosis of PID is broad and includes cervicitis, ectopic pregnancy, endometriosis, ovarian cyst, ovarian torsion, spontaneous abortion, septic abortion, cholecystitis, gastroenteritis, appendicitis, diverticulitis, pyelonephritis, and renal colic. Look for signs of other sexually transmitted infections, such as herpes simplex, syphilis, and human papillomavirus infection.
DIAGNOSIS
The diagnosis is based on history and clinical findings. No single piece of historical, physical, or laboratory information is sensitive and specific for the disease. Laboratory evaluation of any woman of childbearing age in the ED always should include a pregnancy test. Consider the possibility of ectopic pregnancy or septic abortion. The most common alternative diagnosis in missed ectopic pregnancy is PID. Concurrent pregnancy also influences patient treatment and disposition.
Current Centers for Disease Control and Prevention guidelines encourage initiation of empiric treatment in women at risk for PID who exhibit lower abdominal pain, adnexal tenderness, and cervical motion tenderness. Guidelines stratify diagnostic criteria into the three groups shown in Table 103­3. TABLE 103­3
Diagnostic Criteria for Pelvic Inflammatory Disease (PID)
Group 1: Minimum criteria. Empiric treatment if no other cause to explain findings.
Uterine or adnexal tenderness
Cervical motion tenderness
Group 2: Additional criteria improving diagnostic specificity.
Oral temperature >101°F (38.3°C)
Abnormal cervical or vaginal mucopurulent secretions
Elevated erythrocyte sedimentation rate
Elevated C­reactive protein level
Laboratory evidence of cervical infection with Neisseria gonorrhoeae or Chlamydia trachomatis (i.e., culture or DNA probe techniques)
Group 3: Specific criteria for PID based on procedures that may be appropriate for some patients.
Laparoscopic confirmation
Transvaginal US (or MRI) showing thickened, fluid­filled tubes with or without free pelvic fluid or tubo­ovarian complex
Endometrial biopsy results showing endometritis
Source: Reproduced with permission from Centers for Disease Control and Prevention, Workowski KA, Berman SM: Sexually transmitted diseases treatment guidelines, 2010. MMWR Recomm Rep 59(RR­12): , 2010. LABORATORY TESTING
Obtain saline­ and potassium hydroxide–treated wet preparations of vaginal secretions to identify leukorrhea (more than one polymorphonuclear leukocyte per epithelial cell) and trichomonads and to test for bacterial vaginosis (clue cells, pH, and a whiff test). If increased white blood cells are seen with clue cells, this increases the likelihood of accompanying cervicitis or PID, as bacterial vaginosis is not inflammatory. Leukorrhea is sensitive
 but not specific for upper tract infection, and the absence of leukorrhea is a negative predictor for PID. Although endocervical swab specimens may be sent for culture and can be Gram stained for gonococci, nucleic acid amplification tests and DNA probes for N. gonorrhoeae and Chlamydia have replaced culture and Gram staining in many settings. If positive, the probability of PID increases significantly. Unfortunately, the latter results are not available to the ED at the time of initial evaluation. Several sensitive and specific diagnostic tests are currently available for Trichomonas testing, including a nucleic acid amplification test (Aptima®; GenProbe, San Diego, CA), approved in 2013, that is performed on the same clinical samples as
,42 those for Chlamydia and gonorrhea testing.

If PID is clinically suspected, an elevated WBC count, erythrocyte sedimentation rate, or C­reactive protein level supports the diagnosis. Because a patient may have multiple sexually transmitted infections, also obtain a rapid plasma reagin test for syphilis. Test for HIV, chlamydia, gonorrhea, and hepatitis. Urinalysis can exclude urinary tract infection, but a positive urinalysis does not exclude PID, because any inflammatory process in the contiguous pelvis can produce WBCs in the urine. Blood cultures do not aid in diagnosis or treatment.
IMAGING AND OTHER DIAGNOSTIC MODALITIES
Transvaginal pelvic US may demonstrate thickened (>5 mm), fluid­filled fallopian tubes or free pelvic fluid in acute severe PID. Pelvic or tubo­ovarian abscesses appear as complex adnexal masses with multiple internal echoes. Pelvic US can demonstrate as many as 70% of adnexal masses missed on physical examination. US also may be helpful in ruling in or out other causes in the differential diagnosis of pelvic pain, including ectopic pregnancy,
 ovarian torsion, hemorrhagic ovarian cyst, and possibly appendicitis or endometriosis. The addition of power Doppler can identify increased blood
 flow, which is suggestive of inflammation and infection.
Abdominopelvic CT and MRI may also be used to diagnose PID and tubo­ovarian abscess and to exclude other important causes of pelvic pain. If appendicitis or other surgical or GI diagnoses cannot be excluded, obtain an abdominopelvic CT. For further discussion, see Chapter , “Abdominal and Pelvic Pain in the Nonpregnant Female.” CT findings in PID include obscuration of the pelvic fascial planes, cervicitis, oophoritis, salpingitis, thickening of the uterosacral ligaments, and the presence of simple or complex pelvic fluid or abscess collections. Both PID and acute appendicitis may
 produce overlapping radiographic findings, but diagnosis can be improved by accounting for both appendiceal diameter and left tubal thickness.

Right tubal thickening does not distinguish the disorders, as inflammation from appendicitis can spread and cause right tubal thickening. An appendiceal diameter cutoff of ≥7 mm in the Hentour cohort was sufficiently sensitive to capture all but one case of acute appendicitis, but left tubal enlargement to ≥10 mm was more suggestive of PID even in patients with dilation of the appendix to ≥7 mm. These measurements together resulted in
 a diagnostic algorithm with 98% accuracy in distinguishing PID from acute appendicitis. MRI is especially helpful in characterizing complicated soft tissue masses, including dilated fallopian tubes and abscesses. MRI is more specific and accurate than US to assess PID, with a sensitivity of 95% and a
,46 specificity of 89%; however, it is often less available acutely in the ED.
Laparoscopy has been considered the gold standard for the diagnosis of PID. It is invasive, has a high interobserver variability, may not detect endometritis or early tubal inflammation, and often is not readily available for ED consultation. Transcervical endometrial aspiration and endometrial
,38,47 biopsy, although still invasive, may be more commonly used by consultants when the diagnosis is uncertain and the patient is ill.
TREATMENT
Treatment is aimed at relieving acute symptoms, eradicating current infection, and minimizing the risk of long­term sequelae. From a public health perspective, another objective of treatment is to reduce the risk of transmission of infection to other new partners and to identify and treat past and current sexual partners to prevent disease spread. Early diagnosis and treatment are critical because duration of symptoms is an independent risk
 factor for infertility.
Due to the difficulty of diagnosis and the potential for serious sequelae, the Centers for Disease Control and Prevention recommends a low threshold for empiric treatment, with overtreatment preferred to a missed diagnosis with resultant delayed or no treatment.
Provide adequate analgesia, control of emesis and fever, and fluid replacement in those with nausea, vomiting, and dehydration and in those who appear toxic. NSAIDs are very useful for the management of pain of pelvic origin.
ED treatment should include empiric broad­spectrum antibiotic therapy to cover the full range of likely organisms. Screen for bacterial vaginosis and treat when screening is positive. Treatment regimens should follow both national guidelines from the Centers for Disease Control and Prevention and local health department surveillance reports. The Pelvic Inflammatory Disease Evaluation and Clinical Health trial, which included 654 females age  to  years old, demonstrated no differences between oral and parenteral regimens in women with mild to moderately severe acute PID uncomplicated
,50 by pregnancy or the presence of a tubo­ovarian abscess.
Currently accepted inpatient and outpatient treatment regimens are summarized in Tables 103­4 and 103­5. Changing geographic patterns of drug resistance may alter recommendations. For example, worldwide resistance in gonorrhea has emerged over the past several decades by multiple
 molecular mechanisms to all the commonly used antibiotics. Patients with PID who require IV antibiotics initially can be switched to oral antibiotics after clinical improvement. Advise patients to abstain from intercourse until therapy is complete, symptoms have resolved, and partners have been treated.
TABLE 103­4
Parenteral Treatment Regimens for Pelvic Inflammatory Disease in Adults and Adolescents (CDC 2021 Guidelines)
IV Treatment Recommended Regimens Alternative Regimens
Ceftriaxone  gm IV q d Ampicillin/sulbactam  gm IV q  h
PLUS PLUS
Doxycycline 100 mg PO or IV& q  h Doxycycline 100 mg PO or IV q  h&
PLUS
Metronidazole 500 mg PO or IV q  h
OR OR
*Cefoxitin  gm IV q  h or *Cefotetan  gm IV q  h Clindamycin 900 mg IV q  h
PLUS PLUS
Doxycycline 100 mg po or IV q  h #Gentamicin loading dose 2mg/kg IV/IM
FOLLOWED BY
Gentamicin maintainance dose .5mg/kg q  h
*Ceftriaxone does not provide anaerobic coverage so add metronidazole; Cefoxitin and Cefotetan provide anaerobic coverage so metronidazole is not needed for the duration of IV therapy with those agents.
#Single daily dose 3­5mg/kg can be given instead.
&PO doxycycline has same bioavailability as IV form and avoids painful infusion
Source: Centers for Disease Control and Prevention, Sexually Transmitted Treatment Guidelines, 2021, July , 2021. Division of STD Prevention. National Center for
HIV/AIDS, Viral Hepatitis, STD, and TB prevention. Centers for Disease Control and Prevention.
TABLE 103­5
Oral and Outpatient Treatment Regimens for Pelvic Inflammatory Disease in Adults and Adolescents (CDC 2021 Guidelines)
Ambulatory
Recommended Regimens Alternative Regimens
Treatment
Ceftriaxone 500 mg IM single dose for <150 kg; 1000 Ceftizoxime or cefotaxime% single dose mg IM single dose for >150 kg
PLUS
PLUS
Doxycycline 100 mg po bid x 14d
Doxycycline 100 mg PO bid x  d
PLUS
PLUS
Metronidazole 500 mg PO bid x 14d
Metronidazole 500 mg PO bid x 14d
OR IF cephalosporin allergy and community prevalence and individual risk for
Gonorrhea is low, and followup is likely:
Cefoxitin  gm IM single dose Levofloxacin 500 mg PO qd or Moxifloxacin 400 mg po qd x 14d
PLUS PLUS
Probenecid  gm PO Metronidazole 500 mg PO bid x 14d
PLUS OR
Doxycycline 100 mg PO bid x 14d Azithromycin 500 mg IV qd for 1­2 doses, followed by 250 mg PO bid x  days
PLUS AND
Metronidazole 500 mg PO bid x 14d Metronidazole 500 mg PO bid x 14d
% specific dose not given in CDC guidelines
Source: Centers for Disease Control and Prevention, Sexually Transmitted Treatment Guidelines, 2021, July , 2021. Division of STD Prevention. National Center for
HIV/AIDS, Viral Hepatitis, STD, and TB prevention. Centers for Disease Control and Prevention.
SPECIAL CONSIDERATIONS
TREATMENT WITH IUD IN PLACE
In the past, an IUD was generally removed, based on the belief that because it is a foreign body removal of the IUD would allow treatment to be more effective. There is a low risk of PID from IUD insertion, especially when sexually transmitted infection testing is done concomitantly and immediate
 treatment is initiated. Current Centers for Disease Control and Prevention guidelines suggest that there is insufficient evidence to recommend IUD removal before treatment for PID, because the device is usually not the source of infection. In those with an IUD who develop PID, there are no data to support the use of one treatment regimen over another. Studies were also performed on women with nonhormonal
IUDs, with similar results. No data are available regarding treatment outcomes in those with levonorgestrel­releasing IUDs. Close clinical follow­up is prudent. If there is a concern regarding PID in a patient with an IUD newly placed in the past  weeks, it is reasonable to consult a gynecologist regarding removal.
TREATMENT IN HIV INFECTION
Microbiologically, HIV­positive women are more likely to have concomitant Candida, M. hominis, HPV, and streptococcal infection. HIV­positive women with PID may experience more severe symptoms irrespective of CD4 count and are more likely to have sonographically diagnosed tubo­ovarian
52–54 abscess. However, such patients appear to respond similarly to treatment for uncomplicated PID as do those not infected with HIV. HIV­positive
,52,55,56 status alone is not a criterion for hospitalization.
TREATMENT OF ADOLESCENTS
Early and mid­adolescents were not well represented in the Pelvic Inflammatory Disease Evaluation and Clinical Health study, and of those enrolled, adolescents had increased risk of recurrent PID and a shorter time to pregnancy after an acute episode compared with adult enrollees. However, there is no robust evidence to suggest that adolescent outcomes are improved after hospitalization for PID management. Adolescents hospitalized in pediatric centers often receive services beyond IV antibiotics, including education on risk reduction and pregnancy prevention, emotional support,
,58 social work intervention, assistance with communicating the nature of their illness with parents, and assistance to arrange close follow­up.
ALTERNATIVE ANTIBIOTICS
For those with severe cephalosporin allergy, spectinomycin is recommended in Canada and Europe but is not currently available in the United States.
For more information, see the Centers for Disease Control and Prevention Web pages on antibiotic­resistant gonorrhea at
 http://www.cdc.gov/std/Gonorrhea/arg/default.htm.
Multiple studies have demonstrated poor compliance with doxycycline therapy (25%; 50% with partial compliance), and 20% to 25% of patients never
59–61 fill their prescriptions. Doxycycline also does not cover Mycoplasma genitalium. For PID treatment, azithromycin is an alternative, with studied dosing of 500 milligrams IV daily for one to two doses, followed by 250 milligrams once daily for  to  days, or in combination with metronidazole for
 anaerobic coverage, 250 milligrams PO once a day for  days or  gram once a week for  weeks. The long half­life of azithromycin requires significantly fewer doses, which is thought to improve the likelihood of patient compliance. Azithromycin also provides intrinsic anti­inflammatory effects and may reduce local tissue damage. Weigh these potential benefits against the lack of large­scale or long­term studies comparing the
,59,62­65 effectiveness of azithromycin to doxycycline in the treatment of PID and the possibility of emerging resistance to azithromycin. A recent metaanalysis of  randomized controlled trials, including multiple international trials, found that all Centers for Disease Control and Prevention– recommended regimens studied demonstrated fairly similar treatment efficacy, but that azithromycin might be superior in those with mild to moderate PID. The authors point out the risk of bias in the trials studied and the need for high­quality randomized controlled trials to more robustly address this.
TUBO­OVARIAN ABSCESS
Tubo­ovarian abscesses are most commonly a late complication of PID, and the majority have associated peritonitis. Tubo­ovarian abscess complicates about 2% of PID cases. Due to slower resolution of PID, women coinfected with HIV demonstrate an increased incidence of tubo­ovarian abscess. Disproportionate unilateral adnexal tenderness or adnexal mass or fullness may indicate a tubo­ovarian abscess (Figure 103­1). In women with clinical toxicity and asymmetric pelvic findings, obtain a pelvic US. Most tubo­ovarian abscesses (60% to 80%) resolve with antibiotic
66–68 administration alone. In the setting of tubo­ovarian abscess, oral therapy should be continued with clindamycin (450 milligrams PO four times per day) or metronidazole with doxycycline for better anaerobe coverage for  days. Patients who do not improve after  hours of treatment should be reevaluated for possible CT­ or US­guided percutaneous drainage, laparoscopic drainage, posterior colpotomy with drainage, surgical intervention, or reconsideration of other possible diagnoses. Abscesses  cm or larger on imaging appear to have a higher likelihood of requiring surgical therapy. An enlarging pelvic mass may indicate bleeding secondary to vessel erosion or a ruptured abscess.
FIGURE 103­1
Tubo­ovarian complex. Endovaginal image of left adnexa shows a distorted ovary (OV) partially encircled by a fluid­filled hydrosalpinx (TUBE).
[Reproduced with permission from Ma OJ, Mateer JR, Reardon RF, Joing SA (eds): Ma & Mateer’s Emergency Ultrasound, 3rd ed. New York, NY:
McGraw­Hill Education, Inc.; 2014. Fig. 16­17 Part A, p. 469.]
DISPOSITION AND FOLLOW­UP
Guidelines for admission (Table 103­6) and inpatient treatment (Table 103­4) have evolved over the past decade. Among the problems encountered with outpatient care are the provision of adequate guideline­driven treatment, patient adherence to the prescribed therapeutic regimen, difficulty in arranging outpatient administration of parenteral medications, coordination of 72­hour follow­up evaluation, and partner treatment, all of which have been implicated as causes of treatment failure. Consider these and other constraints when determining the patient’s ability to follow or tolerate an outpatient regimen.
TABLE 103­6
Admission Considerations
Inability to exclude surgical emergency from the differential diagnosis
Pregnancy
Failure to respond to outpatient treatment
Inability to tolerate or comply with outpatient treatment
Severe toxicity, high fever, nausea, vomiting
Tubo­ovarian abscess
Source: Reproduced with permission from Centers for Disease Control and Prevention, Workowski KA, Berman SM: Sexually transmitted diseases treatment guidelines, 2010. MMWR Recomm Rep 59(RR­12): , 2010. Institutions should consider adoption of protocolized treatment guidelines to help to ensure fidelity to standards of care. Admission decisions in the ED are based on severity of illness, likelihood of adherence to outpatient medication regimen, likelihood of major anaerobic infection (IUD, suspected pelvic or tubo­ovarian abscess, or history of recent uterine instrumentation), certainty of diagnosis, coexisting illness and immunosuppression, pregnancy, patient age, and other major fertility issues.
If the patient is discharged, arrange reevaluation within  hours for clinical improvement and adherence to the prescribed regimen. Encourage partner evaluation and treatment. Test and treat for other sexually transmitted infections if not already done. Educate patients about the use of barrier contraceptives and other “safe sex” techniques to lessen the risk of reinfection. Counsel the patient to remain abstinent from sexual activity until  week after treatment is finished for both the patient and partner and symptoms have abated.
Partner treatment is crucial to preventing repeated episodes of PID. This can be difficult to ensure. If the current partner has accompanied the patient to the ED, and the patient is willing to tell this partner about her infection, she can be asked to suggest immediate ED evaluation to her partner. If not, the patient should be instructed to notify partners with whom she has had sexual contact in the  days preceding the onset of her symptoms to go to the local public health department or sexually transmitted infection clinic for empiric treatment of N. gonorrhoeae and C. trachomatis. A 6­minute PID
 outreach video has been developed and was found in one randomized controlled trial to improve partner treatment. Recent European guidelines
 suggest the use of doxycycline as empirical treatment of partners to reduce exposure to macrolide to avoid increasing resistance in M. genitalium.
ACKNOWLEDGMENTS
The authors gratefully acknowledge the contributions of Amy Behrman and William Shoff, coauthors of this chapter in previous editions.


