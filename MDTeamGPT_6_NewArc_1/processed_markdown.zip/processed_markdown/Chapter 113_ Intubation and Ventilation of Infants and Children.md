## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 113: Intubation and Ventilation of Infants and Children
Matthew L. Hansen; Carl Eriksson
INTRODUCTION
Endotracheal Tubes and Cuffs for Infants and Children August 2020
Endotracheal tube sizing, and endotracheal tube cuffs, have been updated in the section Endotracheal Tubes and Cuffs, under the section
ENDOTRACHEAL TUBE EQUIPMENT. For premature infants, use an uncuffed endotracheal tube. For fullterm infants and children to age , use a cuffed endotracheal tube. Tube size for children ≥  years old is estimated by the formula: (Age in years/4) + .5
Garth Meckler, MD, MPH
Children have distinct characteristics that result in differences in the approach to supporting oxygenation and ventilation compared to adults. In addition, there are significant physiologic, anatomic, and equipment differences between children and adults that must be considered when managing the pediatric airway. The presentation of a critically ill child requiring significant support of oxygenation or ventilation, potentially leading to
1–4 endotracheal intubation, is relatively uncommon compared to adults. This chapter presents some unique characteristics of pediatric respiratory physiology as well as distinct anatomic characteristics of the pediatric airway. It also discusses strategies for effective airway management, including
 strategies to select equipment and dose drugs with the goal to minimize errors.
PHYSIOLOGIC CHARACTERISTICS
Due to a higher metabolic rate, oxygen consumption is increased in children, especially in infants. As a result, children are vulnerable to rapid desaturation when oxygenation or ventilation is reduced. Children have relatively small­volume lungs with small functional residual capacities, and tachypnea is the initial response to most insults to oxygenation and ventilation. This also translates into a reduced oxygen reservoir, which decreases the length of safe apnea time after neuromuscular blockade, even when preoxygenation is optimized. Therefore, be prepared to support oxygenation with bag­mask ventilation (BMV) before an intubation attempt, while awaiting the onset of induction and paralysis, and during the apneic period after
 paralytics have been administered. Below an oxygen saturation of 90%, desaturation is particularly rapid. The vast majority of children are easily bag ventilated when the proper technique is used, even when partial obstruction is present. The key is anticipation and early use of good BMV.
Children can develop gastric distention from swallowing air during distress as well as insufflation during BMV. Gastric distention can further compromise functional residual capacity, tidal volume, and ventilation. Gastric insufflation is generally a more significant problem the younger the age of the child. Proper BMV technique can reduce the risk, and early placement of an orogastric or nasogastric tube may help. Gastric tubes are also recommended to minimize the risk of reflux from an incompetent gastroesophageal junction, but the incidence of aspiration in children appears to be quite low, even in emergent intubation.
Children have a proportionally larger extracellular fluid compartment than adults. This results in a quicker onset and shorter duration of action of drugs and may require higher doses per kilogram for many of the drugs used to facilitate rapid­sequence intubation.
ANATOMIC CHARACTERISTICS
There are a number of anatomic characteristics of children that must be appreciated to optimize the success of airway management including endotracheal intubation (Table 113­1). Most of the unique anatomic characteristics are most prominent in infancy. Over the first  years of life, there iDs oaw trnalonasidtieodn 2to0 2a5 s­m7­a1l le6r:6 b uPt sYimouilra IrPly ipsr 1o3p6o.r1ti4o2n.e1d5 9a.n1a2t7omy compared to adults. Most children do not have the many acquired anatomic challenges
Chapter 113: Intubation and Ventilation of Infants and Children, Matthew L. Hansen; Carl Eriksson present in older adults, and the differences in children are predictable. With good technique and anticipation of these differences, the majority of
. Terms of Use * Privacy Policy * Notice * Accessibility pediatric airways are successfully managed.
TABLE 113­1
Anatomic Considerations in the Pediatric Airway
Pediatric Anatomy Potential Implications Airway Maneuvers
Large head and occiput May push head forward, occluding airway Shoulder roll should be used to align airway axes* in infants
Large tongue May occlude upper airway in sedated, Jaw thrust, chin lift, oral or nasopharyngeal airway obtunded, or paralyzed patient
Floppy epiglottis May obscure laryngeal view Lifting the epiglottis directly with a straight blade, or potentially a curved blade may be necessary to visualize the glottis
Superior larynx and May make visualization of cords difficult Shoulder roll may be required to align airway axes*; video laryngoscopy anterior cords may improve glottic view
Cricoid narrowing Subglottic space is narrowest portion of the Monitor cuff insufflation pressures in small children pediatric airway
Large adenoids and May cause upper airway obstruction Oral and nasal airway adjuncts may help; jaw thrust and chin lift are also tonsils likely to help
Small cricoid cartilage Makes open cricothyrotomy technically Needle cricothyrotomy preferred in young children difficult
Low gastroesophageal Insufflation of stomach with bag­valve­mask Use proper bag­valve­mask ventilation technique; consider early sphincter tone, relatively ventilation or swallowed air can compromise placement of orogastric or nasogastric tube to deflate stomach when using small lungs respiratory status positive­pressure ventilation
*Tragus should be aligned with the clavicle. In older children, the roll may need to be placed under the occiput to achieve alignment.
Alignment of the oral, pharyngeal, and tracheal axes, to allow visualization of the glottis, is affected by several features most pronounced in the infant:
(1) a relatively large head and occiput, (2) a disproportionately large tongue and small mandible, and (3) a larynx that is more cephalad and thus appears more anterior than in adults. This acute angle can be overcome by extending the infant’s neck (unless cervical injury is suspected) and, in some cases, placing a small roll under the shoulders.
The infant glottic opening, epiglottis, and aryepiglottic folds are more prominent, soft, and mobile than in an adult or older child. This redundant tissue can obscure the view of the vocal cords. Under tension from a laryngoscope blade, the esophageal inlet can also appear similar to the vocal cords. Many skilled laryngoscopists prefer to use a straight laryngoscope in younger children as it allows the epiglottis to be directly lifted out of view by the laryngoscope.

The narrow trachea, combined with the redundant, mobile periglottic tissues, predisposes the young child to airway obstruction. The narrowest point of the child’s trachea is at the cricoid ring, which is also the site of mucosal swelling associated with croup. Airway resistance increases disproportionately with any reduction in diameter and dramatically increases when airflow becomes turbulent rather than laminar. A 25% reduction in diameter from swelling (e.g.,  mm to  mm) reduces the cross­sectional area by 50% and increases resistance by 200%. The swollen, mobile tissues
 create a dynamic obstruction, and, in the agitated, crying, young child with subsequent turbulent airflow, the work of breathing can increase 32­fold.
This can lead to complete obstruction and respiratory arrest. This principle underscores the need to keep children with partial airway obstructions as calm as possible. Because the obstruction often worsens during negative airway pressure associated with inspiration, children with airway edema usually respond well to positive­pressure ventilation including BMV, continuous positive airway pressure, or potentially high­flow nasal cannula at the higher range of flow rates.
Surgical cricothyrotomy is contraindicated in children <10 years old because the cricothyroid membrane is too small. Therefore, in children <10 years of age, needle cricothyrotomy is the subglottic, invasive airway of choice.
BAG­MASK VENTILATION
BMV is a fundamental critical skill for pediatric resuscitation and arguably one of the most important skills to master. BMV alone may be sufficient to support oxygenation in certain clinical scenarios where rapid recovery is expected, such as apnea or hypopnea associated with postictal states or deep sedation. BMV is also commonly required before endotracheal intubation, may be needed during the apneic period following neuromuscular blockade, and is the principal rescue technique in children when intubation attempts fail. Correctly sized bags and masks are essential to good ventilation, regardless of the provider’s skill. Proper mask size is illustrated in Figure 113­1. FIGURE 113­1. Proper facemask size.
Common errors in pediatric BMV include excessive ventilatory rate, inspiratory pressure, and volume. Many self­inflating “pediatric”­sized bags have a volume of approximately 500 mL. However, a 20­kg child should receive only about 160 mL of air with each breath (8 mL/kg). Thus, providers should generally squeeze the bag only enough to allow for chest rise in order to prevent gastric insufflation and barotrauma. On occasion, the rate or volume will need to be adjusted for the disease state. For example, longer expiratory times are often needed in asthma. Table 113­2 includes normal initial ventilation parameters.
TABLE 113­2
Initial Ventilation Parameters in Children
Patient weight (kg) 3–9 10–18 19–36
Patient length (cm) 46–75 76–109 110–146
Tidal volume (mL/kg) 6–8 6–8 6–8
Rate (breaths/min) 20–25 15–25 12–20
In infants and younger children, a supine position usually causes flexion of the neck due to the large occiput, and elevation of the shoulders or thorax is helpful to align the airway.
There are two common hand positions to achieve a mask seal. The “E­C” clamp technique is perhaps the most common, with the thumb and index finger positioned on the mask and the remaining fingers pulling the mandible up into the mask, while maintaining extension at the atlanto­occipital
,9 junction (Figure 113­2). The E­C clamp technique can be used with one or two hands, although the two­handed technique provides a better seal.
Another technique known as the “V­E” technique, or thenar eminence technique, requires two hands but may allow for a better seal (Figure 113­
,10
3). With either technique, it is critical that the majority of force be dedicated to pulling the airway up into the mask, rather than pushing the mask down into the face. It is also important to apply pressure to the bony mandible rather than the soft submandibular space, since pressure on the submandibular space can cause the tongue to obstruct the airway. Oral and nasopharyngeal airways can be helpful adjuncts to BMV in children by helping displace the highly mobile tissues of the pediatric airway.
FIGURE 113­2. Double “E­C” clamp bag­valve­mask technique. Using two hands results in a better mask seal compared to single­hand technique.
FIGURE 113­3. “V­E” bag­valve­mask technique. This technique requires two hands but results in a good seal and potentially less hand fatigue than other methods.
Manometers are available for many BVM systems that allow the user to monitor ventilatory pressures. Keeping inspiratory pressure as low as possible will decrease the likelihood of inflating the stomach. In addition, positive end­expiratory pressure valves can be added to many models that can assist in oxygenating patients with hypoxemia. There are some data to suggest the cricoid pressure may reduce gastric insufflation during bag­valve­mask
,12 ventilation, although at higher pressures, especially in smaller children, it can also cause obstruction of the airway.
Consider placing appropriately sized oral airways (measured from the mandibular angle to the lip; see Table 113­4) in unconscious children to assist with displacement of the relatively large pediatric tongue.
Finally, most pediatric bags incorporate a pop­off, or pressure­relief, valve (Figure 113­4). Designed to avoid barotrauma, the valve will open at a preset peak pressure (usually  to  cm H O of pressure). However, in some diseases associated with high airway pressures, such as asthma or
 airway obstruction, higher peak pressures may be needed to achieve adequate ventilation. In these circumstances, disable or occlude the pop­off valve manually.
FIGURE 113­4. The pop­off valve on a pediatric bag­valve mask, designed to prevent barotrauma, may need to be occluded when higher pressures are required, such as in patients with asthma.
NONINVASIVE VENTILATION
Noninvasive ventilation has been most rigorously studied in adults, and studies in children have focused mostly on respiratory support in bronchiolitis. Nasal continuous positive airway pressure and high­flow (i.e.,  L/min) nasal cannula, where humidified oxygen is delivered via
13–17 nasal cannula, have been evaluated in the literature as means to support respiratory effort in infants and children with bronchiolitis. Use of this technique has been shown to improve ventilation and, in some children, obviate the need for subsequent intubation and should be considered as an adjunct in cases of moderate to severe bronchiolitis. In addition, several retrospective studies have suggested that bilevel positive­pressure ventilation
,19 is safe and may be effective for children with status asthmaticus. In addition to supporting patients with acute respiratory disorders, noninvasive ventilation may also be useful for chronic conditions; bilevel positive airway pressure may provide ventilatory assistance in neuromuscular disorders, whereas continuous positive airway pressure can improve aeration for patients with syndromes associated with anatomic upper airway obstruction
(e.g., craniofacial syndromes, Down syndrome with macroglossia). Noninvasive positive­pressure ventilation is most effective when instituted early on in the disease process and is also more effective for ventilatory failure compared to acute hypoxemic respiratory failure. Table 113­3 provides an overview of the indications, equipment, settings, advantages, and disadvantages of nasal cannula and noninvasive ventilation strategies in infants and children.
TABLE 113­3
Overview of Pediatric Nasal Cannula and Noninvasive Ventilation Strategies
Common
Method Equipment Indications Comments
Settings
Standard Standard cannula Hypoxemia .5–4 L/min Use higher rates for apneic oxygenation (5
NC Apneic oxygenation L/min for infants, 10–15 L/min for older children)
High­ High­flow cannula with heater, Bronchiolitis 1–2 L/kg/min May also be used with FiO2 regulator to flow NC humidifier, and flow regulator Status asthmaticus apply high flow without high FiO2
Mildly to moderately
Higher flow rates can create positive increased work of breathing airway pressure
CPAP Commercial device (often a ventilator) CPAP CPAP Keep FiO2 as low as possible to avoid or with circuit and mask or nasal prongs Upper airway 5–8 cm H O
 masking hypoventilation
BiPAP obstruction
BiPAP Less helpful in acute hypoxemic
Status asthmaticus
Inspiratory respiratory failure
Moderately to severely
PAP 8–15 cm Use caution in patients at high risk for increased work of
H O aspiration
 breathing
Expiratory
PAP 4–8 cm
BiPAP
H O
Neuromuscular disease 
Respiratory distress not improved with CPAP
Abbreviations: BiPAP = bilevel positive airway pressure; CPAP = continuous positive airway pressure; FiO2 ,= fraction of inspired oxygen; NC = nasal cannula; PAP = positive airway pressure.
ENDOTRACHEAL INTUBATION EQUIPMENT
The principal challenge with children is selecting the appropriate­size equipment. There are several formulas that can assist in the estimation of equipment sizing. It is ideal for emergency physicians to have basic knowledge of equipment size for endotracheal intubation such as tube sizing, depth of insertion, and blade selection. In addition, all EDs should have an established system to identify the appropriate­size equipment needed for each child. There are many available systems, and each hospital should evaluate the merits of each system and select one that meets their needs.
Effective systems can range from relatively high­cost commercial systems to low­cost, internally developed, length­based tables for drug doses and
® equipment sizes that rely on simple tape measures to determine the length. The Broselow tape represents a common system that uses length­based
 estimates of equipment and medications, organized by color. Some EDs organize their airway equipment to align with their chosen system in order to minimize confusion and delay.
ENDOTRACHEAL TUBES AND CUFFS
CUFFED endotracheal tubes are preferred for term newborns, infants, and older children. For premature infants, use an UNCUFFED endotracheal tube.
For full­term newborn infants and children to age , use a CUFFED endotracheal tube ,21 . Tube size can be estimated for children ≥  years old by the formula: (Age in years/4) + .5
Tables 113­4 and 113­5 display some common equipment sizes by age and length.
TABLE 113­4
Age­Based Airway Equipment Size* Age Internal Diameter (mm) Blade Size
Premature .0 Uncuffed  Straight
0–6 mo .0­3.5 Cuffed  Straight
6–12 mo .0­3.5 Cuffed 1–1.5 Straight
1–2 y .5­4.0 Cuffed .5 Straight
3–4 y .0­4.5 Cuffed .5–2 Straight or curved
5–6 y .5­5.0 Cuffed .0 Curved
7–8 y .0­5.5 Cuffed .0 Curved
9–10 y .5­6.0 Cuffed .0 Curved
≥11 y .5­8.0 Cuffed .0 Curved
*Estimated equipment size varies between age and length­based methods, but either method can be used as a start. Have additional tubes bedside,  size small and larger than estimated.
TABLE 113­5
Length­Based Equipment Chart (length in cm)
85–95
Item 54–70 cm 70–85 cm 95–107 cm 107–124 cm 124–138 cm 138–155 cm cm
Cuffed Endotracheal tube .5 .0 .5 .0 .5 .0 .5 size (mm)
Lip–tip length (mm) .5 .0 .5 .0 .5 .0 .5
Laryngoscope  Straight 1–1.5 .5–2  Straight or  Straight or 2–3 Straight or  Straight or
Straight Straight curved curved curved curved
Suction catheter 8F 8F–10F 10F 10F 10F 10F 12F
Stylet 6F 6F 6F 6F 14F 14F 14F
Oral airway Infant/small Small child Child Child Child/small Child/adult Medium adult child adult
Bag­valve mask Infant Child Child Child Child Child/adult Adult
Oxygen mask Newborn Pediatric Pediatric Pediatric Pediatric Adult Adult
Vascular access (gauge)
Catheter 22–24 20–22 18–22 18–22 18–20 18–20 16–20
Butterfly 23–25 23–25 21–23 21–23 21–23 21–22 18–21
Nasogastric tube 5F–8F 8F–10F 10F 10F–12F 12F–14F 14F–18F 18F
Urinary catheter 5F–8F 8F–10F 10F 10F–12F 10F–12F 12F 12F
Chest tube 10F–12F 16F–20F 20F–24F 20F–24F 24F–32F 28F–32F 32F–40F
Blood pressure cuff Newborn/infant Infant/child Child Child Child Child/adult Adult
Over­inflation of the endotracheal tube cuff can cause ischemic damage to the trachea. Inflate the cuff carefully. Because the cuff volume varies according to size and manufacturer, one strategy is to initially inflate the cuff with a small amount of air while someone auscultates over the anterior neck as breaths are provided; stop inflating when air is no longer heard to be leaking around the cuff.
LARYNGOSCOPE BLADES
Straight laryngoscope blades (Miller) are preferred to curved blades in young children because the large epiglottis can be lifted directly, and the large
 tongue is more easily displaced to provide direct visualization. A blade that is too small or short is potentially more difficult to use than one that is too large, because a short blade may not reach the supraglottic area. To determine proper blade length, place the blade handle joint at the child’s upper incisors and the tip at the angle of the mandible. The length of the blade from its tip to the handle joint should be within  cm proximal or distal of the
,23 angle of the mandible. The #0 straight (Miller) blade or #1 curved (MacIntosh) blades are used only for the small or premature newborn (Figure
113­5).
FIGURE 113­5. Measurement of proper laryngoscope length for curved and straight blades. [Instruments on left: Reproduced with permission from Mellick LB,
Edholm T, Corbett SW: Pediatric laryngoscope blade size selection using facial landmarks. Pediatr Emerg Care Apr;22(4):226­229, 2006. Copyright
Wolters Kluwer Health.]
VIDEO LARYNGOSCOPY
Video laryngoscopy has become quite common in adult airway management in the ED. Video laryngoscopy has also recently become more common in
,25 pediatric patients in the ED and the pediatric intensive care unit. In general, it appears that for most patients, first­pass success rates are similar in
 children with direct and video laryngoscopy. However, in children with difficult airways, video laryngoscopy may provide better first­pass
,28 success. It is reasonable to use video laryngoscopy as first­line technique in children, especially if video laryngoscopy is primarily what a given provider or hospital uses for adults. Standardizing equipment across age groups as much as possible may reduce the likelihood of errors and may reduce stress during uncommonly performed procedures.
AIRWAY ADJUNCTS
The selection of alternative airway techniques or rescue devices for children is limited. However, most children can be bag­mask ventilated should laryngoscopy fail. The typical 15F intubating stylet, or bougie, commonly used for adults will typically only accommodate a .5 or larger endotracheal tube. Intubating stylets are available in pediatric sizes small enough to accept a .0­mm internal diameter endotracheal tube.
As noted in the earlier section “Anatomic Characteristics,” emergency subglottic surgical airways in children <10 years of age are restricted to needle cricothyrotomy. The indications for these alternative airway options are discussed in more detail later in this chapter.
APPROACH TO AIRWAY MANAGEMENT IN NEONATES, INFANTS, AND CHILDREN
PREPARATION FOR INTUBATION
Begin preparation for endotracheal intubation as soon as you anticipate the potential need for invasive airway management. Initiate preoxygenation early, even if oxygen saturation is 100%. Maximize preoxygenation through elevation of the head of the bed when possible. The actual fraction of inspired oxygen of commonly used equipment for pediatric preoxygenation in the ED environment is not well described. However non­rebreather
 masks at standard flow rates have been shown to achieve a fraction of inspired oxygen that is much lower than the desired 100%. Adult data recommend using either a well­sealed BVM with  L/min of oxygen or a non­rebreather mask with oxygen flows at flush rate, which provides better
 preoxygenation. For children, the addition of a nasal cannula to other preoxygenation techniques may also be beneficial, although the flow needs to
,32 be relatively high at  to  L/min for larger children and  L/min for children under  year of age. This is also a reasonable approach for most children. Applying a nasal cannula during preoxygenation also facilitates apneic oxygenation, which likely reduces the rate of hypoxia during
33–35 intubation in children. Prepare appropriately sized equipment before initiating intubation. Prepare different­sized blades and at least one size smaller endotracheal tube. Make sure that oral and endotracheal suction catheters are functioning and of proper size. Assess airway difficulty (see later section, “The Difficult Pediatric Airway”) and have rescue devices at hand. In some situations, such as partial airway obstruction, the best strategy may include anesthesia or otolaryngology consultation and consideration of intubation in the operating room. Even if the plan is to defer final management to another setting or a consultant, have equipment at the bedside in case of clinical deterioration requiring immediate action. Specialty equipment, such as a pediatric Magill forceps for foreign body obstruction, should also be at the bedside. Using an airway checklist throughout airway
 management is likely to improve preparation and reduce complication rates.
Ensure reliable IV or IO access. Finally, a fluid bolus (20 mL/kg normal saline) is often beneficial before initiation of rapid­sequence intubation. Many children require intubation for respiratory failure, which is often associated with dehydration from reduced oral intake and increased insensible losses. Many medications used during intubation can decrease venous return or ventricular performance. In addition, positive intrathoracic pressure resulting from ventilation after intubation may further decrease preload, making preintubation fluid resuscitation important. Push­dose vasopressors are appropriate for children in selected circumstances, such as children who are significantly hypotensive prior to intubation and children with poor cardiac function (likely a result of congenital heart disease) who require intubation. Push­dose vasopressors should be prepared and available when intubating the critically ill hypotensive pediatric patient. Epinephrine is used most commonly in children and is prepared by drawing  mL of 1:10,000 epinephrine and adding  mL of normal saline to produce a 1:100,000 solution (10 micrograms/mL); administer .1 mL/kg (1 microgram/kg) bolus doses as needed to maintain systolic blood pressure of  plus twice the age in years from ages  to  years. Beyond age , maintain systolic blood pressure  mm Hg. [see footnote, Table 106.2].
Finally, similar to adults, a subset of pediatric patients may not be suitable for rapid­sequence intubation. Other approaches such as delayed­sequence intubation or techniques that maintain spontaneous breathing may be more appropriate in certain pediatric patients. Specific examples include those with preexisting difficult airways or those unlikely to tolerate apnea due to impaired oxygenation.
LARYNGOSCOPY AND TRACHEAL INTUBATION
The technique for laryngoscopy is similar between children and adults and is described in detail in Chapter 29A, “Tracheal Intubation.” Proper positioning is critical, and optimal alignment of the airway axes for laryngoscopy may be different than proper positioning for BMV (Figure 113­6).
Extension of the neck can help align airway axes to improve glottic view. In infants, elevation of the torso may be necessary to align airway axes and improve laryngeal view. If using a straight blade, the large epiglottis overlies the vocal cords. Pick up the epiglottis with the straight blade to see the cords below. In younger children, there is a tendency to place the blade too deeply, into the esophagus. If identification of structures is impossible, the tip of the blade is usually in the upper esophagus or retroglottic space. Slowly withdraw the blade, and the cords or the epiglottis should come into view.
FIGURE 113­6. A. Proper positioning of an infant for intubation. Elevation of the shoulders is often needed to accommodate the prominent occiput and prevent flexion of the neck. B. In an older child, elevation of the head with neck extension often results in the best alignment for intubation.
EXTERNAL LARYNGEAL MANIPULATION
The pediatric airway is relatively cephalad compared to adults. As such, external manipulation of the larynx has the potential to improve the laryngeal view. There is no single technique or movement that has clearly been shown to be superior. Ideally, the laryngoscopist would direct the manipulation of the larynx to optimize the view and have another team member hold it in that position while the tube is delivered. Cricoid pressure may not be
 needed, because it has been associated with difficulty with intubation and BMV, and in children, cricoid pressure can occlude the pliable trachea. If cricoid pressure is applied, release pressure if laryngoscopy and intubation are difficult.
There is a tendency to insert the endotracheal tube too far in the very young child, in whom the distance from laryngeal cords to tracheal carina may just be a few centimeters. Right mainstem intubation is not always appreciated on auscultation, particularly in the infant, because breath sounds may be transmitted throughout the chest. Therefore, predetermine endotracheal tube depth and adhere to that depth during intubation. Depth can be estimated using the formula:
Tube internal diameter ×  = Tube depth at the lips
For example, a .0­mm internal diameter tube should be  cm at the lips. Length­based systems can also be used.
RAPID­SEQUENCE INTUBATION
Rapid­sequence intubation remains the preferred method of intubation in children in the ED and is associated with the highest success and lowest
 complication rates compared to other methods. Specific induction and paralytic agents for children are presented in Table 113­6. The indications and contraindications are the same as for adults.
TABLE 113­6
Common Rapid­Sequence Intubation Medications in Children* Medication Dose† Comments
Induction agents
Etomidate .3 milligram/kg Preserves hemodynamic stability; may suppress adrenal axis even in a single dose; short acting; requires anxiolysis or analgesia after intubation
Ketamine 1–2 milligrams/kg Bronchodilator; preserves respiratory drive; cardiovascular stimulant; drug of choice for intubation for asthma and early sepsis
Propofol 1–3 milligrams/kg Rapid push; higher dose in infants; may cause hypotension; short acting; requires ongoing anxiolysis or analgesia after intubation
Paralytics
Rocuronium  milligram/kg Nondepolarizing agent; longer duration than succinylcholine
Succinylcholine <10 kg: .5–2.0 Shorter duration than rocuronium; may cause bradycardia in children and hyperkalemic cardiac arrest in milligrams/kg children with undiagnosed neuromuscular disease
>10 kg: .0–1.5 milligrams/kg
Sedatives
Midazolam .1 milligram/kg Short­acting sedative
Lorazepam .1 milligram/kg Longer­acting sedative
Analgesics
Fentanyl 1–2 micrograms/kg Short­acting analgesic; preserves hemodynamic stability
Morphine .1–0.2 Longer­acting analgesic; may cause histamine release milligram/kg
*Premedication is no longer routinely recommended in children due to a lack of supporting evidence.
†Rapid­sequence intubation medications can be given IO when IV access cannot be obtained. Consider lower doses of induction agents in the critically ill infant or child with hemodynamic instability.
Succinylcholine and rocuronium are both commonly used neuromuscular blocking agents for paralysis during pediatric rapid­sequence intubation.
There are no comparative studies in children demonstrating benefit of one agent over another, although in practice, pediatric emergency medicine and critical care have largely adopted rocuronium as the paralytic of choice. Succinylcholine can cause fatal hyperkalemia in a number of conditions
(Table 113­7), usually apparent on patient presentation; however, the specific association of hyperkalemia with cardiac arrest in children with undiagnosed neuromuscular disease has caused many pediatric practitioners to prefer the use of rocuronium in children. In children, there is no evidence to support the use of pretreatment agents. Bradycardia in children is typically a sign of hypoxia, which should be corrected. Atropine does not
 prevent succinylcholine­associated bradycardia and should not be given prophylactically.
TABLE 113­7
Complications and Contraindications of Succinylcholine
Hyperkalemia
Burns >5 d old
Denervation injury >5 d old
Significant crush injuries >5 d old
Severe infection >5 d old
Neuromuscular diseases, myopathies
Preexisting hyperkalemia
Masseter spasm
Increased intragastric, intraocular, and possibly intracranial pressure
Malignant hyperthermia
Bradycardia
Prolonged apnea with pseudocholinesterase deficiency
Fasciculations
POSTINTUBATION AND VENTILATOR MANAGEMENT

Immediately after intubation, confirm endotracheal tube placement using a capnograph or a colorimetric end­tidal carbon dioxide detector. A smallsized colorimetric end­tidal carbon dioxide detector should be used for children weighing <15 kg. For larger children, weighing >15 kg, use the adultsized carbon dioxide detector, because using the smaller device with larger tidal volumes can increase resistance to flow (Figure 113­7). Continuous waveform capnography is optimal for confirmation of endotracheal tube placement, since in some clinical, albeit rare, scenarios the colorimetric detector may give a false­positive reading, such as after carbonated beverages are consumed or the detector becomes contaminated with stomach
,40 acid. It is also useful in postintubation monitoring.
FIGURE 113­7. Examples of a pediatric colorimetric end­tidal carbon dioxide detector for children <15 kg and a standard one for larger children.
Visualization of the tube through the cords or fogging of the tube is not adequate confirmation of tube placement in the trachea. Likewise, equal breath sounds do not preclude right mainstem bronchus intubation, and a chest radiograph should be obtained shortly after intubation to confirm appropriate depth.

Carefully secure the tube at the mouth, using either tape adhered to the maxilla with skin adhesive or available commercial devices. Because of the short distance between the glottic opening and the end of the endotracheal tube, infants are prone to displacement of the tube into the oral pharynx with head extension and into the right mainstem bronchus with head flexion. Immobilize the head and neck in a neutral position in intubated young children.
Most pediatric centers preferentially use pressure­limited ventilation, although practitioners must account for their own familiarity with different ventilatory modes when choosing the optimal mode for a particular child. For a child with relatively healthy lungs, a positive end­expiratory pressure of
 cm H O is generally sufficient; children with significant oxygenation defects may require much higher levels of positive end­expiratory pressure.

Inspiratory pressure or volume settings are usually titrated to achieve tidal volumes of  to  mL/kg, with an age­appropriate respiratory rate (often  or greater in infants). An initial inspiration­to­expiration ratio of 1:2 is suggested but may need to be adjusted, particularly in the presence of reactive airways, which will require a longer expiratory phase. Regardless of the initial settings, frequent reevaluation and monitoring of vital signs, including end­tidal carbon dioxide and blood gases, should guide ongoing ventilation parameters. Though ventilator management is beyond the scope of this chapter, a guide to initial settings based on physiology is provided in Table 127­10. TABLE 113­8
Initial ED Ventilator Settings for Infants and Children
Positive
Underlying Ventilator Tidal End­
Rate Comments
Pathophysiology Mode Volume Expiratory
Pressure
Normal lungs (e.g., Volume 6–8  cm H O Normal for age In cases of metabolic acidosis, rate may need to be
 intubation for altered control cc/kg increased to avoid worsening acidosis; target rate to level of consciousness) achieve EtCO 35–40 mm Hg for intracranial hypertension

Obstructive lung Volume 6–8  cm H O Slow (10–14 or lower Slow rate with increased expiratory time required to avoid
 disease (e.g., asthma) control cc/kg may be required) breath stacking (relative hypercapnia OK); keep plateau pressure to a maximum of  cm H O to avoid barotrauma

Lung protective Volume 4–6 8–10 cm May need to be faster Start at  cc/kg tidal volume and  cm H  and increase
 strategy (e.g., ARDS) control cc/kg H O than normal for age
 PEEP and decrease tidal volume as needed to maintain due to low tidal oxygenation; adjust rate to maintain eucapnea volumes
Provide adequate sedation and analgesia before the effects of induction and paralysis agents wear off. This is particularly important when rocuronium or other longer­acting muscle relaxants are used, because their duration is often much longer than most induction agents used in rapid­sequence intubation.
THE DIFFICULT PEDIATRIC AIRWAY
A difficult airway as defined by the American Society of Anesthesiologists is difficulty with BMV, difficulty with tracheal intubation,
 or both. Other characteristics of the difficult airway include (1) more than two attempts at intubation with the same laryngoscopic blade, (2) need for a change in blade or use of intubation stylet, and (3) need for an alternative intubation technique or rescue. The incidence of difficult pediatric airways in the emergency setting is not known, although the child who cannot be intubated and cannot be ventilated
 appears to be less common than the adult. As in adult patients, it is essential to anticipate difficult airway management in children in order to avoid the “can’t intubate, can’t ventilate” situation. Three questions will help guide management decisions:
. Will I be able to bag­mask ventilate to maintain oxygenation?
. Are laryngoscopy and intubation likely to be successful?
. What rescue device, if needed, is most appropriate for this patient?
CLINICAL FEATURES OF DIFFICULT PEDIATRIC AIRWAYS
Difficult pediatric airways often fall into four categories: acute upper airway infections, such as epiglottitis and retropharyngeal abscesses; acute airway obstructions, such as foreign bodies, trauma, or burns; congenital anatomic airway abnormalities, such as Pierre Robin syndrome; and airways contaminated with significant amounts of body fluids. An approach to each potential difficulty is beyond the scope of this chapter. However, an understanding of the principles of management and the rescue devices available in pediatric airway management will usually lead to an appropriate strategy.
Small changes in airway diameter can significantly increase airway resistance, and when airflow is turbulent, as in a crying, agitated child, the resistance to flow increases exponentially. This is why most significant partial pediatric airway obstructions potentially requiring intubation are best managed in the controlled setting of the operating room with assistance from appropriate consultants, such as anesthesiology and otolaryngology.
Until that time, maintain the child in a quiet, comforting environment, with minimal stimulation. The emergency physician must remain prepared for potential deterioration.
UPPER AIRWAY INFECTION
See Chapter 126, “Stridor and Drooling in Infants and Children,” for a detailed discussion of infectious causes of upper airway obstruction in children.
Acute upper airway infections, such as croup, are usually gradual in onset and may respond to medical intervention. Supraglottic infections, such as epiglottitis or pharyngeal abscesses, may make laryngoscopic visualization difficult, and rescue devices (see later section, “Supraglottic Devices”), such as a laryngeal mask airway, should be readily available. If respiratory failure should occur before intubation, BMV is usually successful because positive­pressure stents open the mobile soft tissues in extrathoracic airway obstructions.
FOREIGN BODY OBSTRUCTION
Patients with partial obstruction from a foreign body are another category in which expectant management is advised until care is transferred to a consultant skilled in endoscopic removal. Should complete obstruction occur before intervention, perform abdominal thrusts for children >1 year of age (see Chapter 109, “Resuscitation of Children”). For infants, perform five back blows followed by five chest thrusts and repeat these maneuvers and intersperse them with attempts at ventilation if the child remains conscious. If the child becomes unconscious, perform direct laryngoscopy. If the foreign body is supraglottic, it can possibly be removed using Magill forceps during laryngoscopy. If a child loses his or her pulse, then follow the appropriate Pediatric Advanced Life Support algorithm. If the obstruction is subglottic, intubation or BMV may push the foreign body into a mainstem bronchus, allowing temporary ventilation of the other lung until removal with bronchoscopy. Subglottic surgical approaches, such as needle cricothyrotomy and supraglottic rescue devices, are rarely helpful in this setting because the obstruction usually lies within the trachea, below the level of the cricothyroid membrane.
Partial obstruction may progress to complete obstruction with subsequent difficult laryngoscopy and BMV. Early subspecialty consultation may be needed before any transfer out of the emergency setting. Patients with burns, caustic ingestions, expanding hematomas, and anaphylactic reactions not responding to medical therapy fall into this category. Preparation for possible needle cricothyrotomy should be made in these cases.
CONGENITAL AIRWAY ANOMALIES
Children with congenital abnormalities associated with difficult laryngoscopy and BMV, such as Pierre Robin syndrome, are uncommon but challenging. The ideal management is aggressive medical treatment of the underlying disease, in hopes of obviating the need for intubation. Early subspecialty involvement is also needed in most cases. The most common issue is micro­ or retrognathia, which decreases the potential space into which the tongue and upper airway structures can be displaced during laryngoscopy and thereby makes direct laryngoscopy very difficult. Many pediatric patients with micro­ or retrognathia respond to noninvasive positive­pressure ventilation, BVM ventilation, or ventilation
 through a laryngeal mask airway.
TECHNIQUES FOR MANAGING THE DIFFICULT PEDIATRIC AIRWAY
Consider supraglottic airway devices when ventilation with BMV is inadequate and attempts at endotracheal intubation fail. Supraglottic airway devices generally function by creating a seal superior to the glottic opening. They usually allow for adequate oxygenation and ventilation while potentially providing some protection against aspiration of gastric contents. There are a number of supraglottic devices that are suitable for use in children
(Figure 113­8).
FIGURE 113­8. ® TM
Supraglottic airways in pediatric sizes. At the top of the figure is an Ambu AuraGain laryngeal mask with an inflatable cuff (Ambu, Columbia, MD).
® ®
Next is an i­gel laryngeal mask, which does not have an inflatable cuff (Intersurgical, Workingham, Berkshire, United Kingdom), followed by a King
Laryngeal Tube (Ambu).
The laryngeal mask airway has been used for decades to manage pediatric airways and is often included in airway management training courses. The traditional laryngeal mask airway seats over the glottic opening and has an inflatable cuff that helps provide a seal. There are many different brands of traditional laryngeal mask airways in addition to several generations of these devices, some of which include suction ports. Several other supraglottic airway devices are also available in comprehensive pediatric sizing.
®
The i­gel (Intersurgical, Workingham, Berkshire, United Kingdom) is one such device that is shaped similarly to a more traditional laryngeal mask but has a soft plastic cuff that is not inflatable as opposed to the inflatable cuff of the more traditional laryngeal mask. It is available with a suction port as well. Several studies have compared the more traditional laryngeal mask airway devices and the i­gel and have generally found them to be
44–47 comparable.
®
The King Laryngeal Tube (Ambu, Columbia, MD) is a supraglottic airway where the tip of the tube is designed to seat in the esophagus, with an air
® exchange port pointed toward the glottis, while two balloons provide a seal in the esophagus and in the oropharynx. The King LT is popular in adult out­of­hospital cardiac arrest patients, although it is also available in a comprehensive range of pediatric sizes. However, there are limited clinical data on its use in children. The Combitube device is generally not recommended for pediatric patients.
In some cases, the initial attempt to place a supraglottic airway may fail. This is often due to the epiglottis folding over the glottic opening. If this happens, the device will not seal well, and most of the air will leak out through the mouth. To correct this, the device should be removed and replaced with extra attention to patient positioning prior to the next attempt. Providers should use end­tidal carbon dioxide to confirm supraglottic device placement, similar to endotracheal intubation.
INTUBATION THROUGH A SUPRAGLOTTIC AIRWAY
Some supraglottic airways create a conduit that is suitable for the passage of an endotracheal tube or flexible endoscope through their lumen. This allows the provider to attempt to pass an endotracheal tube through a supraglottic airway blindly or with flexible endoscopic guidance with or without the use of an airway exchange catheter. The supraglottic device thus acts as a conduit past the soft tissues to the glottic opening. There are several important limitations of this technique. First, it is a complex multistep process that should be rehearsed prior to implementation in a patient. Next, the internal diameter of the supraglottic airway lumen limits size of the endotracheal tube and endoscope that can be passed. Finally, these procedures potentially expose the patient to longer periods where ventilation is not taking place compared to traditional methods, and thus a patient needs to be able to tolerate periods of apnea or hypopnea.
FLEXIBLE ENDOSCOPIC INTUBATION
Similar to adults, children with difficult airways may be suitable for flexible endoscopic intubation. Experience and practice are needed to obtain facility with these devices, and the occasion to use them is rare, especially in children, which makes it a challenge to ED application. Furthermore, many instances require an awake, cooperative patient, which is unlikely in the distressed young child, even with good topical anesthesia. Therefore, consultation with experienced subspecialists is often needed. Another aspect of this procedure that is different in children is that the diameter of the endoscope will limit the size of endotracheal tube that is able to be used. Many standard or “adult” size endoscopes will only fit endotracheal tubes that are >5.5 mm in size. Smaller endoscopes are also sold that fit smaller endotracheal tubes, although they may not be available in many EDs.
Providers should thoroughly familiarize themselves with the equipment that is available to them prior to clinical use.
SURGICAL AIRWAY
Cricothyrotomy is the final airway solution when traditional laryngoscopy and rescue airways have failed or are impossible and the patient cannot be oxygenated. The most common indication is the “can’t intubate, can’t ventilate” scenario, which is extremely rare in emergency pediatric airway management. Open surgical cricothyrotomy is not an option in children <10 years old due to the small cricothyroid membrane.
Needle cricothyrotomy is therefore recommended in children <10 years old. Actual experience in the ED is limited, but success has been described in case reports, animal studies, and the operating room.
The procedure involves placing a large­gauge, over­the­needle catheter through the cricothyroid membrane or upper trachea (Figure 113­9). A 14­ gauge needle is often described, although in infants and small children, a 16­ or 18­gauge needle may be more appropriate. Nonkinking catheters are available for this purpose and are preferred, but a standard over­the­needle catheter scan be used. Jet ventilation, through high­pressure oxygen tubing attached directly to wall­mounted oxygen, is commonly taught and rarely, if ever, performed. Due to its infrequent use, lowering the likelihood of success in a chaotic situation, and the potential for barotrauma, jet ventilation may not be the ideal technique for transtracheal ventilation and should never be used in children <5 years old. Instead, providers can ventilate through the transtracheal catheter with a bag ventilator. Use the adapter from a .0­mm internal diameter endotracheal tube to connect a standard catheter to the bag (Figure 113­9C). Alternatively, there are other commercial products suitable for transtracheal ventilation. Transtracheal ventilation is a temporary emergency measure to provide oxygenation
(albeit with minimal ventilation) until a definitive airway can be achieved. In some scenarios, an emergent tracheostomy may be the only or best airway access. This is typically performed by an otolaryngologist, although in an emergency, it may also be done by others who have been trained in this technique.
FIGURE 113­9. Technique for needle cricothyrotomy. A. Equipment required for a needle cricothyrotomy: a 14­gauge over­the­needle catheter (ideally nonkinking), a
.0­mm internal diameter endotracheal tube adapter, and a 10­mL syringe. B. Placement of catheter into trachea. C. Ventilation through the catheter using a .0­mm endotracheal tube adapter.
NEONATAL AIRWAY CONSIDERATIONS
Conceptually, intubation in neonates is similar to that in infants. The primary difference is that smaller equipment may be needed in premature infants, and the formulas for tube size and depth are different. Table 113­9 provides recommended equipment sizes for neonatal resuscitation. If time allows, precut the endotracheal tube proximally at the 13­cm mark at the endotracheal tube adapter site. This may eliminate the need to do so later, after the newborn has already been intubated. Uncut tubes allow for excessive “dead space” and are also prone to kinking. In contrast to older children, a stylet may not improve success rates of intubation, although existing data come from neonatal intensive care units and
 may not apply to the ED environment. It is reasonable to use an intubating stylet in order to have consistency in practice across all age groups.
TABLE 113­9
Selection of Intubation Equipment for Neonates
Gestational Age (wk) Weight (grams) Tube Size (mm) Laryngoscope Blade Size Suction Catheter Size
<28 <1000 .5 Miller 00–0 5F or 6F
28–34 1000–2000 .0 Miller  6F or 8F
34–38 2000–3000 .5 Miller  8F
>38 >3000 .5–4.0 Miller 0–1 8F or 10F


