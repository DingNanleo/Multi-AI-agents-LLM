## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 253: Skin Disorders: Extremities
Heather Holahan; Dean S. Morrell; Diana B. McShane
INTRODUCTION
This chapter focuses on common disorders of the hands, feet, and extremities.
EXTREMITY ULCERS
VENOUS STASIS DERMATITIS AND VENOUS LEG ULCERS

The vast majority of leg ulcers are venous stasis ulcers resulting from chronic venous insufficiency. Chronic venous insufficiency is usually caused by episodes of phlebitis or varicose veins, both of which damage venous valves. This results in poor venous return from the lower extremities, leading to increased hydrostatic pressure and lower extremity edema and stasis dermatitis.
Dependent edema, erythema, and orange­brown hyperpigmentation characterize early stasis dermatitis. The medial distal legs and the pretibial leg are the areas most frequently affected. More chronic and severe cases may have bright weepy erythema and even ulceration (Figure 253­1). Pruritus is common. Cellulitis and lymphangitis may complicate stasis dermatitis. The presence of honey­colored crust and pustules suggests secondary bacterial infection.
FIGURE 253­1. Venous stasis. [Photo contributed by University of North Carolina Department of Dermatology.]
Stasis ulcers often begin within areas of stasis dermatitis. The bilateral malleoli and the medial aspect of the calf are the most common sites of involvement. Diagnosis is clinical, and secondary infection is common. Table 253­1 lists the differential diagnosis of leg ulcers. Certain disorders, such as arterial ulcerations, pyoderma gangrenosum, and polyarteritis nodosa, require immediate attention. If peripheral pulses are diminished or
 absent, obtain vascular blood flow studies to exclude arterial ulcers. If the patient reports a rapidly developing ulcer that began as a pustule or
Chapter 253: Skin Disorders: Extremities, Heather Holahan; Dean S. Morrell; Diana B. McShane erythematous nodule and has violaceous overhanging borders, suspect pyoderma gangrenosum. If the diagnosis is in question, consult with a
. Terms of Use * Privacy Policy * Notice * Accessibility dermatologist.
TABLE 253­1
Clinical Features and Treatment of Common Extremity Ulcers
Condition Clinical Features Treatment Comments
Venous stasis Dependent erythema, edema and orange­ Compression stockings Medial distal leg and pretibial leg brown hyperpigmentation Leg elevation
Low­ to mid­potency topical steroid
Pyoderma Superficial pustule/nodule that grows into a Treat underlying disease, if Often associated with systemic disease: gangrenosum large, painful ulcer on lower extremity; present inflammatory bowel disease, rheumatoid purulent base with irregular, gun metal gray Topical steroid arthritis, and myeloproliferative disorders borders Intralesional steroid
Systemic steroid
Immunosuppressive/cytotoxic agents for recalcitrant disease
Diabetic/neuropathic Asymptomatic ulcer often occurring with Redistribution of pressure off Plantar surface underlying first and fifth ulcers diabetic neuropathy; “punched out” the wound metatarsal heads, great toe, and heel; may appearing with a thick rim of peripheral Creation of moist wound complain of burning, numbness, pruritus or callous environment paresthesia from associated neuropathy
Debridement of nonhealing tissue
PO antibiotics for simple soft tissue infection
IV antibiotics for cellulitis and/or osteomyelitis
Buruli ulcers Erythematous nodule that progresses to a Surgical excision is the Forms approximately  wk after inoculation; painless ulcer with deep white and yellow treatment of choice most common sites: face and extremities necrotic base with undermined edges Streptomycin and rifampin for surrounded by edema  wk but antimicrobial therapy often ineffective
Cutaneous Many varieties of cutaneous infection; Most lesions heal Endemic in North Africa, Mediterranean, leishmaniasis painless ulcer occurs often on unclothed skin spontaneously over several Middle East, India, Central Asia, and months Central/South America
Treatment of venous stasis dermatitis and ulcers begins with leg elevation and the use of support stockings. Treat weeping eruptions with an astringent compress. A low­ to mid­potency topical steroid, such as fluocinolone acetonide .025% or hydrocortisone .5% ointment, should be applied twice a day until erythema, scale, and pruritus resolve. Oral antihistamines, such as diphenhydramine or hydroxyzine, are useful for pruritus and for nighttime sedation. Treat secondary bacterial infection with cephalexin, dicloxacillin, or ciprofloxacin for  to  days. Do not use topical neomycin, antihistamine creams, and anesthetic creams because they may complicate the condition with allergic contact
 dermatitis. Cellulitis or lymphangitis may require hospitalization for IV antibiotics. Otherwise, arrange follow­up with a chronic wound care team.
PYODERMA GANGRENOSUM
Pyoderma gangrenosum is a recurrent cutaneous, necrotizing, and noninfective ulceration of the skin. Most cases are associated with underlying
 disease, such as inflammatory bowel disease, rheumatoid arthritis, and myeloproliferative disorders.
The classic lesion begins as a superficial pustule or erythematous nodule that expands into a large painful ulcer on the lower extremity with a purulent base and irregular, undermined borders and gun metal gray hue (Figure 253­2). A history of multiple surgical debridements with sterile cultures should suggest a potential diagnosis of pyoderma gangrenosum.
FIGURE 253­2. Pyoderma gangrenosum. [Reproduced with permission from Wolff KL, Johnson RA, Saavedra AP, Roh EK: Fitzpatrick’s Color Atlas & Synopsis of
Clinical Dermatology, 8th ed. © 2017, McGraw­Hill, Inc., New York. Fig 7­2.]
The diagnosis is clinical and one of exclusion. Search for associated conditions, such as inflammatory bowel disease and myeloproliferative disorders.

The onset of new skin lesions or ulcers at previous sites of trauma can also be helpful in identifying pyoderma gangrenosum.
Treatment of the underlying disorder and corticosteroids, either topical, intralesional, or combined local and systemic, are the standard therapy for pyoderma gangrenosum. Resistant disease may require adjunctive systemic therapy with immunosuppressive or cytotoxic agents.
DIABETIC AND NEUROPATHIC ULCERS

Most patients with diabetic foot ulcers have coexistent diabetic neuropathy. Other causes of neuropathic leg ulcers are much rarer and include leprosy, tabes dorsalis, medications, and spinal cord lesions. In most patients with foot ulcers, one will note a triad of neuropathy, deformity, and trauma. Neuropathy leads to atrophy of the intrinsic muscles of the foot, collapse of the arch, and loss of stability of the metatarsal­phalangeal joints.
The musculoskeletal alterations result in abnormal pressure points and greater friction on the foot during ambulation. Lack of sensation allows for
 repeat injury. The most common source of trauma is inappropriate footwear.
Classic locations for neuropathic ulcers are the plantar surface underlying the first and fifth metatarsal heads, great toe, and heel. Ulcers are usually asymptomatic and “punched out” with a thick rim of surrounding callous (Figure 253­3). However, patients may complain of burning, numbness, itching, or paresthesias. The architecture of the foot is also altered, with flexed toes and prominent metatarsal heads secondary to neuropathy of the intrinsic muscles of the foot. Hypo­ or anhidrosis from autonomic impairment may lead to dryness and fissuring of the surrounding skin. The diagnosis is clinical.
FIGURE 253­3. Diabetic foot and diabetic neuropathy. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of
Clinical Dermatology, 5th ed. © 2005, McGraw­Hill, Inc., New York.]
A diabetic foot infection is diagnosed clinically when there are systemic signs of infection, purulence, or multiple signs of local inflammation (redness,
 warmth, pain, tenderness, or edema). Osteomyelitis is suggested by the ability to probe bone with a blunt, sterile, stainless­steel probe and should be confirmed with imaging.
Treatment includes offloading or redistributing the pressure off the wound, maintenance of a moist wound environment, debridement of nonhealing tissue, and treatment of infection. Soft tissue infections can be treated for  to  days in an outpatient setting with oral cephalosporin, clindamycin,
 amoxicillin/clavulanate, or fluoroquinolones.
More severe ulcers or those with associated cellulitis or osteomyelitis require admission and treatment with IV antibiotics for  to  weeks, such as cefotetan, ampicillin/sulbactam, or clindamycin and a fluoroquinolone. Vancomycin should be given if methicillin­resistant Staphylococcus aureus is suspected. Further discussion is provided in Chapter 224, “Type  Diabetes Mellitus”; Table 224­2 lists the characteristics of diabetic foot ulcers.
BURULI ULCERS

Buruli ulcer is a new emerging disease and the third most common chronic mycobacterial infection in humans after tuberculosis and leprosy. Buruli ulcers are rapidly growing ulcers caused by the acid­fast bacillus, Mycobacterium ulcerans. It is usually confined to the tropical areas, with the highest
 rate in sub­Saharan Africa, but reports have come from subtropical and nontropical nations, including Australia, China, and Japan.

M. ulcerans is an environmental saprophyte that is present on lush vegetation in swampy areas. It infects humans after abrasions come into contact
 with contaminated soil, water, or vegetation. M. ulcerans produces mycolactone, a cytotoxic lipid and necrotizing immunosuppressive polypeptide
 toxin that induces both apoptotic and necrotic changes in fibroblasts, lipid cells, macrophages, and keratinocytes. Buruli ulcers are painless, and it is
 thought that mycolactone damages the peripheral nerves.
The Buruli ulcer begins as an erythematous nodule approximately  weeks after inoculation that eventually ulcerates. The lesions develop on exposed parts of the body, especially on the extremities and face. The resulting painless ulcer has a deep white or yellow necrotic base and undermined edges, as well as edematous surroundings (Figure 253­4). Regional lymphadenopathy and systemic symptoms are minimal to absent. Without treatment, ulcers may spontaneously heal within  to  months, or they may spread rapidly, causing extensive deformity.
FIGURE 253­4. Buruli ulcer. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology, 5th ed.
© 2005, McGraw­Hill, Inc., New York.]
Smears from the base of the ulcer or biopsy specimens should be cultured and examined for acid­fast bacilli. Visible growth by culture requires  to  weeks, and its success rate is low. Polymerase chain reaction performed on a fresh biopsy is the best method for early diagnosis. The World Health

Organization recommends rifampin and streptomycin dual therapy for  weeks, local wound care, and physical therapy. Another regimen used in

Australia is rifampin plus clarithromycin, ciprofloxacin, or moxifloxacin for  weeks. If antimycobacterial treatment is ineffective, surgical
 debridement with skin grafting is the next choice. New skin lesions may develop during antimicrobial therapy, and this is known as “paradoxical
 reactions,” which are thought to be an exaggerated immune response to mycobacterial antigens.
CUTANEOUS LEISHMANIASIS
Cutaneous leishmaniasis is transmitted by the bite of the sand fly, which is infected by protozoan parasites of the genus Leishmania. In tropical and subtropical regions, leishmaniasis is one of the most common and serious infectious diseases. It is endemic in North Africa, the Mediterranean, the
Middle East, India, Central Asia, and Central and South America. Reactivation of latent leishmaniasis can occur in immunosuppressed, human
 immunodeficiency virus, malnourished, or organ transplant patients. There are many varieties of cutaneous leishmaniasis. The typical cutaneous ulcer usually occurs on unclothed skin, is painless, varies in size from .5 to .0 cm in diameter, and is covered with an exudative crust (Figure 253­5).
Diagnosis is clinical but can be confirmed with culture, biopsy, or polymerase chain reaction test. Most lesions heal spontaneously over several
,15 months; however, for severe disease, treatment failures and resistance to antimonials, amphotericin B, and miltefosine are increasing worldwide.
FIGURE 253­5. Cutaneous leishmaniasis. [Reproduced with permission from Walter Reed Army Institute of Research.]
HANDS, LEGS, AND FEET
HAND AND FOOT DERMATITIS
Hand and foot dermatitis simply means inflammation of the skin of the hands and/or feet and consists of nonspecific and more specific disorders
(Tables 253­2 and 253­3). The most common causes are contact dermatitis (allergic and irritant), dyshidrosis, and atopic dermatitis. Most contact dermatitis is caused by irritants as opposed to allergens. Atopic dermatitis affects up to 20% of children, usually before  years of age, but only 2% to

3% of adults.
TABLE 253­2
Clinical Features and Treatment of Common Conditions Involving Extremities
Condition Clinical Features Treatment Comments
Irritant/allergic Irritant dermatitis: erythema, scaling, Removal of offending agent Avoid antihistamine, antibiotic, anti­itch contact and fissuring High­potency topical corticosteroids creams as they can cause secondary dermatitis Allergic contact dermatitis: erythema (ointments preferred) allergy with papules, vesicle and/or bullae; significant clinical overlap can occur depending on acuity/chronicity
Poison ivy/oak Linear streaks of erythematous Remove contaminated clothing, wash with For milder cases, oral antihistamines and
(a specific papules, vesicles, and/or bullae; lesions soap and water; for severe cases, oral topical steroids. aluminum subacetate allergic develop 48–72 h or more after prednisone starting at  milligrams for 5–7 d compresses; for acute exposure, an overcontact exposure, and minute amounts of and then taper over 2–3 wk (shorter courses the­counter skin cleanser Tecnu® is a dermatitis) urushiol can cause eruption result in relapse) popular remedy.
Dyshidrosis Deep­seated pruritic vesicles on lateral Aluminum acetate compresses In chronic cases, erythema and scale may aspects and volar surfaces of palms and High­potency topical corticosteroids become more prominent soles; vesicles may form pustules or Hydroxyzine desquamate over time
Atopic Erythematous, pruritic scaly patches on Aluminum acetate compresses Chronic atopic dermatitis will have dermatitis dorsal surfaces, palms, and soles; High­potency topical corticosteroids hyperpigmentation, lichenification, and common areas: antecubital, popliteal Hydroxyzine fissuring fossa, posterior neck, wrists, ankles No systemic steroids due to relapse
Psoriasis Plaque type: discrete plaques of High­/ultrahigh­potency topical Common sites: elbows, knees, scalp, lower erythema, scales, and fissures on corticosteroids back, gluteal cleft, umbilicus, nails extremities White petrolatum­based emollients Nail involvement can give clues to
Pustular type: erythema, sterile No systemic steroids (rebound, induction of diagnosis: onycholysis, nails pits, and pustules with minimal scale on palms pustular psoriasis) yellow discoloration of nails and soles
Erythema Tender, warm, ill­defined erythematous Leg elevation Pretibial area of lower extremities nodosum nodules NSAIDs Extensor aspect of arms and torso (less often)
Dermatitis Pruritic vesicles, papules, and urticarial Oral dapsone Cutaneous manifestation of gluten herpetiformis plaques on extensor surfaces of Gluten­free diet insensitivity extremities, back, and buttocks
Cutaneous Erythematous and serpiginous tracts Single oral dose of albendazole or ivermectin Occurs after walking barefoot in larva migrans on the skin (migration of hookworm environments contaminated by animal larvae); often complain of pruritus feces in tropical, subtropical climates
Lichen simplex Intensely pruritic, well­demarcated, High­potency topical corticosteroids Ankles, shins, dorsal feet, and hands chronicus lichenified plaque; minimal scale Oral antihistamines for itch
TABLE 253­3
Clinical Features and Treatment of Common Conditions of the Feet
Condition Clinical Features Treatment Comments
Corns and Corns: firm, dome­shaped papules with translucent central core on dorsal, Paring Both are most commonly calluses lateral, and interdigital toes Keratolytics (salicylic acid) located on the feet
Calluses: thickened plaque at areas of repetitive trauma Proper footwear
Tinea pedis Interdigital type: most common, maceration, scale in the web spaces between Interdigital/hyperkeratotic Predisposing factors: hot, toes; ulceration can be seen in severe cases, can be superinfected with types: topical antifungals humid weather, excessive bacteria, yeast Bullous type: oral sweating, and occlusive
Hyperkeratotic type: chronic, dry scales on palms and soles; can see “moccasin antifungal agent footwear distribution” involving lateral and medial aspects of feet; nails may be Onychomycosis: oral Disease is chronic and involved (onychomycosis) antifungal agent recurrences are common
Bullous type: acute, painful, erythematous, and pruritic vesicular eruption on Keep hands and feet palms or soles; toenails, web spaces spared including web spaces as dry as possible
Plantar Thickened papules and plaques on sole of foot, often over pressure points Salicylic acid Most spontaneously warts Can see “black dots” or thrombosed capillaries with paring Cryotherapy regress within 1–2 y
Electrodessication
Acral nevi Symmetric, well­circumscribed, often small, 5­ to 6­mm, uniformly pigmented No treatment needed These are benign growths macules or papules with only slight elevation; can often see linear striations on the surface; depending on skin type, range from brown to black in color
Acral Volar surface of palms or soles; can appear as growing “stain” during radial Excisional biopsy for lentiginous growth phase diagnosis by dermatology melanoma Subungual type: thumb or great toe, grows in the nail bed; can see nodules, Treatment may include ulceration, nail deformity, nail shedding surgical excision, immunotherapy depending on staging
IRRITANT AND ALLERGIC CONTACT DERMATITIS
Common irritants include soaps, detergents, friction, frequent hand washing, and cold, dry air, resulting in erythema, scaling, and fissuring, particularly of the dorsal hands. Strong irritants, such as an acid or alkali, cause immediate burning, followed by erythema, vesiculation, and bullae formation.
Causes of allergic contact dermatitis include nickel, chromate, rubber components of gloves and shoes, dyes in leather and socks, and dichromates used in tanning leather. Distribution is the most helpful clue to aid in diagnosis. When the hands or feet are involved in allergic contact dermatitis, the eruption tends to be present on the dorsal surfaces, sparing the palms, soles, and web spaces. The thick stratum corneum of the palms and soles prevents penetration of potential allergens. Sharp demarcation lines of footwear indicate a reaction to a component of the patient’s shoes. Treatment is the removal of offending agents. Antihistamine, anesthetic, antibiotic, and anti­itch creams should be stopped because they may cause a second allergy. Lubricate with petroleum jelly or thick ointments with a petroleum base frequently and liberally.
For acute eruptions with vesiculation, use aluminum acetate, two to three times per day. Mix one aluminum acetate powder packet or tablet with  pint of water, and then apply with a towel or gauze to the affected area for  to  minutes. Use a high­potency topical corticosteroid, such as clobetasol ointment, twice a day, after the compress. Hydroxyzine,  to  milligrams up to four times a day, can relieve itching.
In severe acute cases with debilitating eruptions, oral glucocorticoids are indicated. Treat chronic eruptions with high­potency topical corticosteroids two to three times a day, but do not give oral glucocorticoids in chronic cases and atopic dermatitis. Ointments are preferred because they help with lubrication and medication delivery.
POISON IVY/OAK
Poison ivy or oak is a type of allergic contact dermatitis to urushiol. The rash can result from direct contact of any part of the plant, contact with tools or clothes, or inhalation if the plant is burned. Rash develops  days or more after exposure. Exposures involving the face or neck are most serious (see
Chapter 250, “Skin Disorders: Face and Scalp”). Exposure results in erythema with papules, vesicles, and/or bullae. Pruritus is intense, resulting in excoriations. Distribution with linear streaks is common with poison ivy or oak (Figure 253­6). See Table 253­2 for treatment. Involvement of palms and soles is uncommon due to thickness of skin in those areas. For severe exposures, give oral prednisone, starting at  milligrams/d, for at least  days and then slowly tapering over a total of  to  weeks. Shorter courses of prednisone result in relapse.
FIGURE 253­6. Vesicular lesions produced after contact with poison ivy. [Reproduced with permission from Wolff KL, Johnson RA, Saavedra AP, Roh EK: Fitzpatrick’s
Color Atlas & Synopsis of Clinical Dermatology, 8th ed. © 2017, McGraw­Hill, Inc., New York. Fig 2­8.]
DYSHIDROSIS
Dyshidrosis initially begins as very small, deep­seated, pruritic vesicles on the lateral aspects and the volar surfaces of the palms and soles (Figure
253­7). The dorsal surface of the distal phalanges may also become involved. There is no erythema. Over time, the vesicles may form pustules or desquamate to leave small collarettes of scales. In chronic cases, erythema and scales become more prominent and may be difficult to distinguish from other forms of hand and foot dermatitis. See Table 253­2 for treatment.
FIGURE 253­7. Dyshidrosis. Clear, tapioca­like lesions with secondary encrustation. [Photo contributed by University of North Carolina Department of Dermatology.]
ATOPIC DERMATITIS

Atopic dermatitis is part of the “atopic triad” consisting of dermatitis, asthma, and allergic rhinitis. Atopic dermatitis of the hands and feet often presents as erythematous, pruritic, scaly patches with prominent involvement of the dorsal surfaces as well as the palms and soles. Chronic atopic dermatitis will also have hyperpigmentation, lichenification, and fissuring. Often, other areas of the body are involved. Common areas of involvement include the antecubital and popliteal fossae, posterior neck, and wrists and ankles (Figure 253­8).
FIGURE 253­8. Atopic dermatitis with lichenification. [Photo contributed by University of North Carolina Department of Dermatology.]
The diagnosis is clinical. See Table 253­2 for treatment. Do not give oral corticosteroids for atopic dermatitis. Differentiating contact dermatitis (allergic and irritant) from dyshidrosis and atopic dermatitis can be extremely difficult. More than one disorder may be present at a time, such as atopic dermatitis complicated by irritant dermatitis. Always consider a fungal infection (see later section, “Tinea Pedis and Tinea Manuum”), and a potassium hydroxide preparation can exclude this possibility. A biopsy cannot differentiate between the different types of dermatitis. See Table 253­4 for definitions of terms in superficial cutaneous fungal infections and Table 253­5 for causes of superficial cutaneous fungal infections. Dermatologic consultation is often necessary for specific diagnosis.
TABLE 253­4
Definitions of Terms for Superficial Cutaneous Fungal Infections
Dermatophytes: a group of fungi that infect nonviable keratinized cutaneous structures such as stratum corneum, nails, and hair. They most commonly include Trichophyton species, Microsporum species, and Epidermophyton species.
Dermatophytosis: an infection caused by dermatophytes
Tinea: a term used for specific clinical manifestations of dermatophyte or dermatophyte­like infections, with the addition of a term that usually indicates the anatomic area affected (tinea pedis, tinea manuum, etc.)
Malassezia species: a yeast causing tinea versicolor or pityriasis versicolor
TABLE 253­5
Causes of Superficial Cutaneous Fungal Infections
Dermatophytes
Trichophyton species (cause most superficial cutaneous fungal infections)
Microsporum species
Epidermophyton species
Candida
Malassezia species
PSORIASIS
Psoriasis vulgaris or plaque­type psoriasis may involve only the palms and soles but often extends to other areas, especially the elbows, knees, scalp, umbilicus, and gluteal cleft (see Chapter 251 for more discussion). If pustules are present, the disorder is called pustular psoriasis. Peak ages of onset are between  and  years old and between  and  years old.
Psoriasis is characterized by discrete plaques of erythema, scales, and fissures on the extremities (Figure 253­9). Extensive disease may extend over the entire palms, soles, and dorsal surfaces of the hands or feet (Figure 253­10). Onycholysis (separation of the nail plate from the nail bed), nail pits, and yellow discoloration of the nails help support the diagnosis of psoriasis (Figure 253­11).
FIGURE 253­9. Psoriasis vulgaris. [Photo contributed by University of North Carolina Department of Dermatology.]
FIGURE 253­10. Psoriasis vulgaris of the plantar foot. [Photo contributed by University of North Carolina Department of Dermatology.]
FIGURE 253­11. Psoriasis nails. [Photo contributed by University of North Carolina Department of Dermatology.]
In pustular psoriasis, the pustules are in various stages of evolution from small pustules to larger confluent “lakes of pus” to crusts to rings of scale
(Figure 253­12). Pustules are most commonly seen bilaterally on the instep of the foot and the thenar and hypothenar eminences of the hands.
FIGURE 253­12. Pustular psoriasis. [Photo contributed by University of North Carolina Department of Dermatology.]
Complete examination of the skin focusing on the sites commonly affected by psoriasis, including the elbows, knees, scalp, lower back, gluteal cleft, umbilicus, and nails, may reveal other areas of involvement to aid in diagnosing psoriasis. If no other psoriatic plaques are noted, differentiation from hand and foot dermatitis can be difficult (Table 253­6). A biopsy may be helpful in this instance. A potassium hydroxide examination should be performed to exclude a dermatophyte infection. Bacterial and viral cultures should be obtained when disease is pustular and localized to one area. See
Table 253­2 for treatment. Do not prescribe oral corticosteroids because of the risk of rebound or induction of pustular psoriasis. The disease is chronic and slow to respond to treatment. Arrange follow­up with a dermatologist.
TABLE 253­6
Differential Diagnosis of Psoriasis
Psoriasis vulgaris
Hand and foot dermatitis
Lichen simplex chronicus
Reiter’s syndrome
Pustular psoriasis
Tinea pedis and tinea manuum
Staphylococcus aureus infection
Herpes simplex infection
Dyshidrosis
ERYTHEMA NODOSUM
Erythema nodosum is an inflammatory eruption of the subcutaneous fat. It has many possible causes (Table 253­7) and is idiopathic in nearly half of cases. All age groups can be affected.
TABLE 253­7
Causes of Erythema Nodosum
Infectious Pharmacologic
Fungal Sulfonamides
Blastomycosis Oral contraceptive pills
Coccidioidomycosis Penicillin
Histoplasmosis Bromides
Dermatophyte Vaccines
Bacterial Sarcoidosis
Streptococcal infections Inflammatory bowel disease
Campylobacter Pregnancy
Yersinia species Behçet’s syndrome
Tuberculosis Leukemia and lymphoma
Leprosy Idiopathic
Parasitic
Leishmaniasis
Toxoplasmosis
Viral
Herpes simplex
Infectious mononucleosis
Tender, warm, ill­defined erythematous nodules characterize erythema nodosum (Figure 253­13). Nodules are most commonly seen on the pretibial area of the lower extremities, although the extensor aspects of the arms and torso can occasionally be involved. Ulceration is not a feature and suggests another diagnosis. Nodules can persist for weeks.
FIGURE 253­13. Erythema nodosum nodules on the legs. [Reproduced with permission from Wolff KL, Johnson RA, Saavedra AP, Roh EK: Fitzpatrick’s Color Atlas &
Synopsis of Clinical Dermatology, 8th ed. © 2017, McGraw­Hill, Inc., New York. Fig 7­9.]
The diagnosis is clinical and should include evaluation for possible causes (Table 253­7). Treatment is symptomatic, with leg elevation and NSAIDs.
Treat the underlying cause. Refer refractory or unclear cases to a dermatologist.
HERPETIC WHITLOW
Herpetic whitlow is a herpes simplex viral infection, due either to HSV­1 or ­2, located on the distal finger or hand. Typical transmission is skin­to­skin, typically through a break in the skin, from individuals who shed the virus but do not have lesions (Figure 253­14). Lesions are painful grouped vesicles on an erythematous base. Lesions may become confluent. Misdiagnosis is common. Paronychia is a localized bacterial infection under the nail bed. Treatment of herpetic whitlow is  week of valacyclovir,  gram orally twice a day. Lesions heal over  to  weeks.
FIGURE 253­14. Herpetic whitlow, grouped vesicles on an erythematous base, with clear discharge. Figure courtesy of Department of Dermatology, University of North
Carolina. [Photo contributed by University of North Carolina Department of Dermatology.]
MALIGNANT MELANOMA
Melanoma is a melanocytic tumor that most often originates in the skin and is most often caused by exposure to ultraviolet light. Involvement can also occur on oral, conjunctival, and vaginal surfaces, including the uveal tract of the eyes and leptomeninges. Clinical presentation includes brown to black
,19 tumors, attributed to melanin deposition (Figure 253­15), whereas some are flesh colored to pink­red and termed amelanotic. One type of aggressive melanoma that occurs on hairless skin, such as under the nails and on palms or soles, and is more common in dark­skinned individuals is called acral lentiginous melanoma. This is the type of melanoma that led to Bob Marley’s death at age . He noted a small spot under his nail that was thought to be from a trivial toe stub. Thus, any new or unusual spot on the body or extremities is worthy of dermatologic referral for definitive diagnosis.
FIGURE 253­15. Malignant melanoma. [Reproduced with permission from Wolff KL, Johnson RA, Saavedra AP, Roh EK: Fitzpatrick’s Color Atlas & Synopsis of Clinical
Dermatology, 8th ed. © 2017, McGraw­Hill, Inc., New York. Fig 12­3.]
LICHEN SIMPLEX CHRONICUS, CORNS, AND CALLUSES
Lichen simplex chronicus, corns, and calluses are all thickenings of the upper layer of the skin (stratum corneum) in response to chronic friction and scratching. Most commonly, the ankles, lower extremities, neck, scrotum, and vulva are involved. When friction occurs in the presence of pruritus, a plaque of lichen simplex chronicus is formed. When friction in the absence of pruritus is distributed over a large area, a callus is formed. When the same frictional forces occur over a localized area of the foot, a corn is formed. Calluses and corns are most commonly located on the feet.
Calluses and corns present as thickened plaques at areas of repetitive trauma. Corns form firm, dome­shaped papules with translucent central cores on the dorsal, lateral, and interdigital toes (Figure 253­16).
FIGURE 253­16. Corn. Painful, hyperkeratotic lesion. [Photo contributed by University of North Carolina Department of Dermatology.]
Diagnosis is clinical (Table 253­8). A potassium hydroxide examination can be helpful to rule out a dermatophyte infection. If the diagnosis is uncertain, refer for a skin biopsy. Paring of warts reveals punctuate thrombosed capillaries, which are not found in calluses or corns.
TABLE 253­8
Differential Diagnosis of Lichen Simplex Chronicus, Corns, and Calluses
Lichen simplex chronicus
Dermatophyte infection
Nummular eczema
Psoriasis
Squamous cell carcinoma
Corns and calluses
Plantar wart
Arsenical keratosis
Squamous cell carcinoma
Palmoplantar keratoderma
Punctuate palmoplantar keratoses
Punctuate porokeratosis
Poroma (benign hair follicle tumor)

Paring and keratolytics, such as salicylic acid, are first­line treatments for corns and calluses, as well as proper footwear and medical management.
For further treatment, refer to a podiatrist or dermatologist.
Lichen simplex chronicus presents as one or several intensely pruritic, well­demarcated plaques, with lichenification as a result of chronic scratching and rubbing (Figure 253­17). Erythema, hyperpigmentation, and excoriations are also present. Scale is minimal. The ankles, shins, dorsal feet, and hands may be affected.
FIGURE 253­17. Lichen simplex chronicus. [Photo contributed by University of North Carolina Department of Dermatology.]
Interrupting the scratch–itch cycle is the most important aspect of treatment for lichen simplex chronicus. High­potency topical corticosteroids such as fluocinonide or clobetasol ointment should be applied to the plaque two to three times a day. Oral antihistamines help for pruritus.
DERMATITIS HERPETIFORMIS

Dermatitis herpetiformis is a cutaneous manifestation of gluten sensitivity. It is most common in individuals of northern European descent. Often, there is familial involvement, and there is almost universal association with HLA­DQ2 or HLA­DQ8, located on chromosome , with close relatives being
 affected by either dermatitis herpetiformis or celiac disease.
Granular deposits of immunoglobulin A are found at the dermal–epidermal junction of all patients with dermatitis herpetiformis. These deposits are believed to attract neutrophils, which induce vesicle formation. The presence of immunoglobulin A antibodies to tissue transglutaminase is also highly
 sensitive and specific for the disorder.
Extremely pruritic vesicles, papules, or urticarial plaques are symmetrically distributed on extensor surfaces of the extremities, back, and buttocks
(Figure 253­18). Chronic scratching may result in excoriations and lichenification in these locations. Approximately 20% of patients will have clinical
 evidence of malabsorption. The diagnosis is supported by clinical, biopsy, and laboratory findings (Table 253­9). Diagnosis and treatment require dermatology referral.
FIGURE 253­18. Dermatitis herpetiformis. Papules and vesicles are grouped together, not in a dermatomal distribution, and are symmetrically distributed on extensor areas of elbows and knees. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical
Dermatology, 5th ed. © 2005, McGraw­Hill, Inc., New York.]
TABLE 253­9
Differential Diagnosis of Dermatitis Herpetiformis
Erythema multiforme
Bullous lupus erythematosus
Linear immunoglobulin A bullous dermatosis
Bullous pemphigoid
Atopic dermatitis (eczema)
Papular urticaria
Chronic prurigo
Scabies
Treatment for dermatitis herpetiformis includes oral dapsone and a gluten­free diet. Oral dapsone relieves pruritus within  hours of beginning therapy. Systemic steroids are ineffective.
CUTANEOUS LARVA MIGRANS
Cutaneous larva migrans is a cutaneous eruption caused by the migration of hookworm larvae within the epidermis. The disease is most commonly found in tropical and subtropical climates where people walk barefoot in environments contaminated with animal feces.
Erythematous and serpiginous tracks are formed as the larva migrates within the skin (Figure 253­19). The patient will often complain of pruritus. A
CBC may demonstrate peripheral eosinophilia; patients are otherwise well. Diagnosis is clinical. A single oral dose of albendazole or ivermectin is
 usually effective.
FIGURE 253­19. Cutaneous larva migrans with elevated serpiginous tracks caused by migration of the larva under the skin. [Photo contributed by University of North
Carolina Department of Dermatology.]
PLANTAR WARTS
Plantar warts are a common infection of children caused by the human papillomavirus. They may be acquired through direct contact with infected individuals or indirectly through contaminated surfaces. Most warts will spontaneously regress within  to  years.
Plantar warts occur on the sole of the foot, especially over pressure points, as thickened papules and plaques that disrupt normal skin lines (Figure
253­20). Black dots, representing thrombosed capillaries, will often cover the surface or become evident upon superficial paring. Diagnosis is clinical
(Table 253­10). Initial treatment is topical salicylic acid. Cryotherapy and electrodesiccation are other options.
FIGURE 253­20. Plantar warts. Painless papules with red­black dots of thrombosed capillaries. [Photo contributed by University of North Carolina Department of
Dermatology.]
TABLE 253­10
Differential Diagnosis of Plantar Warts
Callus
Corn
Epithelioma cuniculatum
Squamous cell carcinoma
Arsenic keratoses
Palmoplantar keratoderma
Punctuate palmoplantar keratoses
Punctuate porokeratosis
Verrucous carcinoma
Benign hair follicle tumor (poroma)
TINEA PEDIS AND TINEA MANUUM
Tinea pedis, or athlete’s foot, is a fungal infection of the feet, and tinea manuum involves the hand. Tinea manuum is often unilateral and associated with tinea pedis. Often, if one hand is involved, both feet are involved as well. It is unclear why the other hand is spared in this “two­foot, one­hand” type of fungal infection. Tinea pedis is very common and usually begins in early adulthood. It is rare in children. Predisposing factors include hot, humid weather, excessive sweating, and occlusive footwear. Trichophyton rubrum, Trichophyton mentagrophytes, and Epidermophyton floccosum are the most common organisms involved. T. mentagrophytes is most likely to cause inflammatory bullous tinea pedis. Infections are transmitted from person to person or from animal to person via fomites or direct contact.
There are three main clinical types: interdigital, hyperkeratotic (scaling), and bullous. Interdigital tinea pedis is the most common and is characterized by maceration and scale in the web spaces between the toes. Ulceration may even be present in severe cases that have a secondary infection with bacteria or yeast (Figure 253­21).
FIGURE 253­21. Interdigital tinea pedis. [Photo contributed by University of North Carolina Department of Dermatology.]
Hyperkeratotic, chronic, dry scales involve palms and soles, with little, if any, inflammation. When involving the medial and lateral aspects of the feet, it is called “moccasin” tinea (Figure 253­22). Nails may be affected.
FIGURE 253­22. Moccasin­type tinea pedis. [Reproduced with permission from Fleischer AB Jr, Feldman SR, McConnell CF, et al: Emergency Dermatology: A Rapid
Treatment Guide. © 2002, McGraw­Hill, Inc., New York.]
Bullous tinea consists of an acute, painful, erythematous and pruritic vesicular eruption on the palms or soles (Figure 253­23). Toenails and web spaces are usually not involved.
FIGURE 253­23. Bullous tinea pedis. [Photo contributed by University of North Carolina Department of Dermatology.]
Diagnosis is based on clinical examination and identification of fungal elements on a potassium hydroxide preparation or with fungal culture. If the clinical examination is highly suspicious for a fungal infection, empiric therapy is reasonable. If the diagnosis is uncertain, obtain scrapings for fungal cultures before beginning therapy because culture results (whether positive or negative) can help the follow­up physician choose the most appropriate therapy.
Although a potassium hydroxide examination appears to be a simple test, it is often difficult for clinicians to perform and interpret (see Table 248­6).
Scraping of scale can also be sent to the laboratory for potassium hydroxide examination and fungal culture. Hyphae appear as light­green, thin strands that cross over cells and have branches (see Figure 248­1).
Treat interdigital and hyperkeratotic (nonbullous) tinea with topical antifungals, such as clotrimazole, miconazole, ketoconazole, or econazole cream. Apply to affected areas twice a day and continue for  week after clearing. Although econazole cream is expensive, it is preferred for interdigital tinea pedis because it has antibacterial properties to treat secondary bacterial (often Corynebacterium) infection. Topical terbinafine cream is a nonprescription alternative and is applied once a day. Topical agents do not treat nail infections. For treatment of onychomycosis, an oral agent such as itraconazole, fluconazole, or terbinafine is needed, but this treatment is best managed by the primary care physician or dermatologist.
Bullous tinea pedis often does not respond to topical treatment. For mild cases, a topical agent can be tried initially. In more severe cases, oral antifungal treatment is necessary. Itraconazole, 200 milligrams PO each day for  days, or terbinafine, 250 milligrams PO each day for  days, is effective. Review the potential drug interactions and the uncommon, but serious, side effects before prescribing these medications. Baseline liver function studies are optional when prescribing terbinafine.
Hands and feet should be kept as dry as possible. After bathing, web spaces should be thoroughly dried. Socks should be changed any time they become wet with sweat. If the eruption is not clear in  to  weeks, dermatology referral is needed. The disease is chronic, and recurrences are common.
VASCULAR CUTANEOUS CONDITIONS
ROCKY MOUNTAIN SPOTTED FEVER
Rocky Mountain spotted fever is a potentially fatal multisystem illness caused by Rickettsia rickettsii. Symptoms begin  to  days after an infected tick bite. The organism disseminates through the bloodstream and invades the vascular endothelium, causing a necrotizing vasculitis. Fever, headache, and myalgias develop about  week after exposure. The rash in classic Rocky Mountain spotted fever is evident  to  days after the onset of fever and
 other symptoms. In most patients, some type of rash develops during the illness, but about 10% never develop a rash.
The rash first appears on the wrists and ankles and rapidly spreads to the palms and soles (Figure 253­24, A and B). As the rash moves centrally, the proximal extremities, trunk, and face become involved. The skin lesions at the onset are described as discrete macules or maculopapules that blanch with pressure. The initial lesions evolve into petechiae over  to  days, fade slowly over  to  weeks, and heal occasionally with hyperpigmentation.
Rarely, the petechiae may coalesce into ecchymotic areas with eventual gangrene of the distal extremities, nose, ear lobes, scrotum, and vulva— purpura fulminans. Treatment for adults is doxycycline, 100 milligrams PO twice a day; for children under  kg, treatment is doxycycline, .2 milligrams/kg twice a day. For further discussion of the treatment of this and other tickborne diseases, see Chapter 161, “Zoonotic Infections.”
FIGURE 253­24. A. Petechiae on the ankles of a patient with Rocky Mountain spotted fever. B. Petechiae involving hand, wrist, and forearm. [From the Centers for
Disease Control and Prevention; National Center for Emerging and Zoonotic Infectious Diseases; Division of Vector­Borne Diseases: Rocky Mountain
Spotted Fever. www.cdc.gov/rmsf/symptoms/. Updated September , 2013.]
PURPURA
Purpura is visible hemorrhage into the skin or mucous membranes. Small, flat lesions are petechiae, and large, flat lesions are ecchymoses. Palpable purpura has a physically palpable elevation. Diverse abnormalities of coagulation and blood vessel function lead to hemorrhage into the skin. These include abnormalities of platelet number or function, procoagulant defects, poor dermal support of vessels, increased pressure within vessels, trauma, vascular inflammation, and vascular occlusion.
The cutaneous and systemic causes of purpura are broad. Nevertheless, some broad generalizations can be made. Large ecchymoses generally signify coagulation defects or trauma and may be associated with signs of external or internal bleeding. Petechiae are often associated with thrombocytopenia and bleeding in other locations. Palpable purpura and persistent, localized purpura suggest vasculitis (Figure 253­25). Because vasculitis can affect any organ system, a complete history and physical examination and a detailed laboratory investigation are required.
FIGURE 253­25. Purpura from cutaneous vasculitis. [Photo contributed by University of North Carolina Department of Dermatology.]
Major coagulation defects and platelet disorders can be diagnosed through coagulation studies. Cutaneous vasculitis is diagnosed by skin biopsy.
Systemic vasculitis is diagnosed by laboratory investigation. Treatment and disposition are based on the underlying diagnosis. For additional discussion, see Chapter 142, “Rashes in Infants and Children” and Chapter 249, “Generalized Skin Disorders.”
PYOGENIC GRANULOMA
A pyogenic granuloma is a benign proliferation of immature capillaries occurring at the site of minor skin trauma. The name is a misnomer because it is neither an infection nor a granuloma. It most commonly occurs in children, young adults, and pregnant women. In pregnant women, it is called granuloma gravidarum. A pyogenic granuloma initially presents as a bright red, shiny papule with a surrounding thin collarette of hyperkeratosis
(Figure 253­26). It may be ulcerated and tends to bleed profusely with minor injury. Later, the lesion reepithelializes and becomes a dull red to purple color. Although lesions can occur anywhere on the body, the extremities, especially hands, are the most common sites of involvement. If the lesion is bleeding profusely, obtain hemostasis with pressure or suturing. Refer for a biopsy of the lesion to exclude other disorders, especially an amelanotic melanoma (Table 253­11). Lesions do not resolve without specific treatment by excision, laser therapy, or electrodesiccation.
FIGURE 253­26. Pyogenic granuloma. Solitary vascular nodule that develops after minor trauma. [Photo contributed by University of North Carolina Department of
Dermatology.]
TABLE 253­11
Differential Diagnosis for Pyogenic Granuloma
Amelanotic melanoma
Squamous cell carcinoma
Bacillary angiomatosis
Cutaneous metastasis
Kaposi’s sarcoma


