University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 26: Post–Cardiac Arrest Syndrome
Benjamin S. Abella; Bentley J. Bobrow
INTRODUCTION AND EPIDEMIOLOGY
Sudden cardiac arrest represents one of the most time­sensitive diseases in the practice of emergency medicine, requiring prompt recognition and
 rapid delivery of resuscitative care, including high­quality CPR, early defibrillation when appropriate, and appropriate airway management. Even with
,3 these interventions, aggregate survival to hospital discharge is less than 20% in most communities and hospital systems. Among survivors, neurologic injury is common (present in up to 50% of survivors) and widely varied, ranging from subtle memory deficits to persistent vegetative
,5 state. This chapter focuses on the pathophysiology of ischemia­reperfusion injury and the provision of targeted temperature management, also
 called therapeutic hypothermia.
PATHOPHYSIOLOGY OF ISCHEMIA­REPERFUSION INJURY
The brain is exquisitely sensitive to ischemia, such that disruption of blood flow for several minutes is sufficient to initiate a set of injury mechanisms
,8 that may lead to irreversible disabilities. The complete loss of blood flow, followed by the abrupt return of spontaneous circulation, rapidly leads to a complex pathophysiologic process known as ischemia­reperfusion injury, also known specifically in the sudden cardiac arrest setting as
,9 postresuscitation syndrome.
When blood flow is abruptly stopped and then restored, a number of overlapping mechanisms lead to clinical injury (Figure 26­1).
FIGURE 26­1. Schematic of postarrest pathophysiology, also called ischemia­reperfusion injury. The concepts shown here represent processes that occur at the subcellular, cellular, tissue, and organismal levels. The kinetics of these processes following cardiac arrest and the extent to which they affect clinical outcomes are still unclear.
CELLULAR RESPONSES TO RETURN OF SPONTANEOUS CIRCULATION

Chapter 26: Post–Cardiac Arrest Syndrome, Benjamin S. Abella; Bentley J. Bobrow 
A©t2 t0h2e5 c eMllcuGlarra lwev Heli,ll .m Aitllo Rchigohntdsr Riael sinetrevgerdit.y aTnedr mfusn octf iUons eb e * cPormivea cdya mPoalgiceyd , * wNitohti creel e * a Asec coef scsruibciilaitly enzymatic machinery such as cytochrome c and
,10 disruption of oxidative phosphorylation. Mitochondrial injury is implicated in the increased concentration of oxygen free radicals and downstream
,11 activation of programmed cell death pathways. At the humoral level, reperfusion triggers a broad array of immune activation, including increased
 blood levels of cytokines such as interleukin­6 and tumor necrosis factor­α. In addition, aberrant neutrophil and platelet activation can occur. These
 immune phenomena have led Adrie et al to describe the postresuscitation condition as a “sepsis­like syndrome,” in which inflammation plays a crucial role in injury. Immune activation, in turn, can lead to additional production of oxygen free radicals such as superoxide and hydrogen peroxide.
These molecules, produced in small quantities during normal cellular function, are usually converted to oxygen and water by the enzymes catalase and superoxide dismutase. However, enzyme systems become overwhelmed with the dramatic increase of free radical species generated during postresuscitation syndrome. Different tissues exhibit varying sensitivity to ischemia­reperfusion processes, with brain tissue and vascular
,9 endothelium appearing to be particularly vulnerable.
ORGAN SYSTEM EFFECTS OF RETURN OF SPONTANEOUS CIRCULATION
The biochemical and cellular phenomena described earlier lead to diverse clinical manifestations of injury in the minutes to hours following resuscitation. Inflammatory changes and immune cellular activation can lead to vascular leak and a drop in peripheral vascular resistance, with
 concomitant loss of fluid from the intravascular compartment and hypotension. Cellular injury in the brain, combined with endothelial damage, can
 trigger cerebral edema, a common and dangerous component of postresuscitation syndrome. Cerebral edema and increased intracranial pressure can cause cerebral herniation and serve as the cause of death, often in the initial  hours following resuscitation. Myocardial stunning is clinically
,17 evident on echocardiography as global hypokinesis and markedly reduced ejection fraction. Myocardial depression is usually transient and
,18 typically resolves over the first few days following resuscitation with appropriate hemodynamic support. Postresuscitation infection may be
 related to bacterial translocation into the bloodstream from loss of intestinal tissue integrity. Adrenal injury from ischemia may cause adrenal
 insufficiency furthering clinical deterioration.
CLINICAL FEATURES AFTER RETURN OF SPONTANEOUS CIRCULATION
Following initial resuscitation, the clinical condition of patients varies considerably. Some patients with prompt recovery after only brief periods of CPR can be awake and responsive; however, most patients are initially comatose or markedly obtunded following resuscitation. Neurologic assessment is limited in most cases because, in the course of clinical resuscitation care, patients are intubated and sedated and/or pharmacologically paralyzed.
Physical examination is limited in the immediate postresuscitation period as well. Most patients exhibit absent or abnormal papillary responses and
 absent gag reflex or doll’s eyes responses. Clinical neurologic reflexes are not predictive of cardiac arrest outcomes. Internation resuscitation guidelines strongly recommend that bedside neurologic examination should not influence decisions for continued care in
 the first  hours following successful resuscitation. Focus the physical examination after resuscitation on identifying clues to determine the possible cause of cardiac arrest, such as asymmetric lower extremity edema, which might suggest thromboembolic disease; absent or decreased lung sounds, which might implicate pneumothorax; or jugular venous distention and muted heart sounds, which might suggest cardiac tamponade.
Promptly obtain an ECG because myocardial ischemia is the most common cause of sudden cardiac arrest.
DIAGNOSIS OF ANOXIC BRAIN INJURY AFTER RETURN OF SPONTANEOUS CIRCULATION
Neuroprognostication after sudden cardiac arrest is a challenging and inexact process. A variety of radiographic, biochemical, and neurophysiologic tools are available to assess brain injury following sudden cardiac arrest, but most are poorly validated and require additional research to determine clinical utility.
,23
In the ED, perform head CT in survivors as soon as feasible. Head CT can identify subarachnoid hemorrhage or epidural and subdural hematomas.
23­25
The degree of cerebral edema can also be assessed by head CT. Because cerebral edema often peaks several days after resuscitation, swelling that
 is radiographically apparent on initial CT is a worrisome sign. Brain MRI is generally neither practical nor useful during initial ED management.
Many protocols for postarrest care involve the early institution of continuous electroencephalogram monitoring to assess for electrical convulsive
 activity, which is present in up to 25% of patients after resuscitation. The presence of seizures generally augurs a poor prognosis, but not all patients with electrical seizure activity sustain severe long­term injury. Bispectral index monitoring, a simple approach to electrical brain monitoring relative to
,29 electroencephalography, can be useful to predict neurologic outcome. Measurement of somatosensory evoked potentials, a bedside test of
 neuronal connectivity and function, can be performed several days following cardiac arrest and may also be useful to predict outcome.
TARGETED TEMPERATURE MANAGEMENT (OR THERAPEUTIC HYPOTHERMIA)
The key ED intervention for postresuscitation syndrome is the prompt delivery of systemic cooling therapy, also called therapeutic hypothermia or targeted temperature management. Systemic cooling of resuscitated adult cardiac arrest for  hours following arrest and return of spontaneous
31­34 circulation can dramatically improve survival and neurologic outcomes.
A multicenter, randomized, European study demonstrated that therapeutic hypothermia instituted for  hours following cardiac arrest and return of spontaneous circulation resulted in a Cerebral Performance Score of  or  (awake, alert, can work or perform independent daily activities) in 55% of hypothermia­treated patients, whereas only 39% of patients in the control group achieved a score of  or  (absolute difference, 16%; number needed
 to treat, about 8). Six­month mortality was 41% in the hypothermia group and 55% in controls. This trial only enrolled out­of­hospital cardiac arrest patients with ventricular fibrillation/ventricular tachycardia as an initial rhythm; no definitive trial has been performed for patients specifically with either pulseless electrical activity or asystole as the initial arrest rhythm. However, a body of clinical evidence suggests that targeted temperature
35­38 management also improves outcomes for patients with pulseless electrical activity or asystole.
Some controversy exists regarding the appropriate “target temperature” for postarrest care; most hospital protocols aim for a core temperature of

32°C to 34°C (89.6°F to .2°F). Modest cooling to 36°C (96.8°F) produces similar outcomes as cooling to 33°C (91.4°F), but there is still considerable
 debate about the best goal temperature for postarrest targeted temperature management.
INCLUSION AND EXCLUSION CRITERIA
Patients who are awake and appropriately alert following return of spontaneous circulation are excluded from consideration (Table 26­1). Patients with very poor neurologic status before arrest and resuscitation are often not considered for target temperature management, as treatment can at best only restore patients to their prearrest clinical state. Other inclusion and exclusion criteria are less well defined. For example, many hospital protocols for postarrest care exclude pregnant patients; however, several case reports have demonstrated good outcomes for postarrest pregnant
,42 patients. Because coagulopathy and bleeding can result from lowering of core body temperature, patients with clinically significant bleeding at the time of arrest or who have arrested from penetrating trauma are generally excluded from targeted temperature management, although therapeutic
 anticoagulation is not a contraindication. Target temperature management may benefit patients resuscitated from hanging­related asphyxial arrest.
TABLE 26­1
Suggested Inclusion and Exclusion Criteria for Postarrest Targeted Temperature Management41
Inclusion criteria Postresuscitation ROSC and GCS motor score <6
No other reason for coma
No DNR or DNI status
∗
Adult (age >17 y)
Exclusion criteria Awake/alert after cardiac arrest
Arrest of traumatic etiology
Arrest associated with significant bleeding
Coma or vegetative state prior to arrest
∗
Pregnancy
DNR/DNI status
Not an exclusion criterion Patient on warfarin or heparin
Initial arrest rhythm was nonshockable
Long QT syndrome
Note the inclusion of a category of clinical items that would not preclude the use of therapeutic hypothermia. These represent issues commonly asked about by practitioners but should not represent exclusion criteria.
Abbreviations: DNI = do not intubate; DNR = do not resuscitate; GCS = Glasgow Coma Scale; ROSC = return of spontaneous circulation.
∗
Criteria that are controversial and may vary from hospital to hospital.
PRACTICAL CONSIDERATIONS
The techniques of targeted temperature management require coordination of care between the ED, critical care units, and cardiology intensive care
 units. A standing hospital protocol is a crucial step for hospital systems; sample protocols are available on the internet. Protocols should delineate processes for hypothermia induction, maintenance, and rewarming; adjunctive pharmacologic interventions (sedation, paralysis) and monitoring; and goals for the time intervals of treatment (Figure 26­2). Incorporation of these protocols into electronic order sets for postarrest care encourages uniformity of treatment.
FIGURE 26­2. Timeline of postarrest therapeutic hypothermia induction, maintenance, and rewarming. Relevant clinical actions are shown in relation to these three phases of the treatment process. EEG = electroencephalographic; ROSC = return of spontaneous circulation; TTM = targeted temperature management.
Cooling and Supportive Care
An organized approach is desirable to safely cool and provide supportive care (Table 26­2). To lower core body temperature to 32°C to 36°C (89.6°F to
.8°F), apply commercially available clinical cooling systems (both surface­wrap or catheter­based cooling solutions exist), or apply chilled saline or ice packs to the axillae and groin. The aim is to reach goal temperature within several hours of resuscitation, so a combination of these approaches is often employed.
TABLE 26­2
Components of Cooling and Supportive Care
Lower core body temperature to 32°C–36°C (89.6°F–96.8°F) as soon as possible but within 4–6 h after return of spontaneous circulation
Surface cooling
Chilled saline or ice packs to the axillae, neck, and groin
Cooling blankets, vests, and leg wraps45
Cooling helmet46,47
Intravascular cooling48
IV  mL/kg normal saline at 4°C over  min48,49
Intubation and mechanical ventilation
Obtain ECG and provide continuous cardiac monitoring, pulse oximetry, and capnometry
Sedation and neuromuscular blockade
Central venous and arterial access
Continuous core temperature monitoring; use bladder catheter, central venous catheter, or esophageal probe
Maintain mean arterial pressure >60 mm Hg (>8 kPa)
Check electrolytes every  h
Maintain hypothermia for 12–24 h
Do not let core temperature drop to <32°C (89.6°F); avoid fever
Maintain hypothermia for  to  hours following lowering of core temperature. It is difficult to maintain a steady temperature with chilled saline or
 ice packs alone. Commercial cooling devices take input from temperature probes to modify cooling power and carefully hold core temperature
  steady. During hypothermia maintenance, check serum electrolytes frequently (every  h) as hypokalemia can result from cold­mediated diuresis.
Monitor hemodynamic parameters carefully to maintain a mean arterial pressure sufficient to enable cerebral perfusion; often a mean arterial
 pressure >60 mm Hg (>8 kPa) is considered minimum. After the maintenance phase, rewarm over  to  hours. More rapid rewarming can induce hypotension from vasodilation as well as electrolyte shifts.
Complications
Adverse effects are associated with temperature­targeted hypothermia (Table 26­3). Bradycardia is very common and often pronounced (heart rate

<50 beats/min) with induction, but usually is of little clinical consequence and requires no treatment. Tachyarrhythmias, atrial fibrillation, and nonsustained ventricular tachycardia are uncommon unless core body temperature is <32°C (89.6°F). QT prolongation has been observed, so c
 continuous cardiac monitoring and interval ECGs are necessary.
TABLE 26­3
Potential Adverse Effects of Targeted Temperature Management (Therapeutic Hypothermia)
More Common Less Common
Bradycardia Nonsustained ventricular tachycardia
Prolongation of QT interval Significant bleeding
Coagulopathy with PTT prolongation Skin injury/ulceration from surface cooling
Hypokalemia during cooling
Hyperkalemia during rewarming
Shivering
Shivering can impede the lowering of body temperature. A variety of treatment approaches to shivering exist, the most definitive being neuromuscular
,55 blockade. Bleeding can be exacerbated by lowered core temperature but occurs in <5% of cases. Hypokalemia and hypomagnesemia can result from intracellular shifts and diuresis mediated by lowered core temperature.
SPECIAL CONSIDERATIONS FOR TARGETED TEMPERATURE MANAGEMENT
Children
The indications for targeted temperature management after cardiac arrest in children are not well established. Although hypothermia improves
 outcomes after neonatal hypoxic­ischemic encephalopathy, a recent multicenter trial found that no significant outcomes benefit from lowering
 postarrest temperature in children, although a trend toward improved survival was present with cooling. A criticism could be that this multicenter study was underpowered, and postarrest temperature management is likely of benefit for pediatric patients. At the very least, careful avoidance of postarrest fever in children is likely important.
Prehospital Application

Some EMS systems have implemented protocols to initiate cooling prior to hospital arrival. Although this strategy has logical validity, recent
59­61 randomized trials found no improvement in outcomes and possibly a higher frequency of rearrest with prehospital cold saline infusion. Current resuscitation guidelines do not recommend prehospital induction of targeted temperature management.
Temperature Management in the Cardiac Catheterization Laboratory
Many postarrest patients should be considered for prompt cardiac catheterization given the likelihood of coronary occlusion, especially in the setting
 of ventricular fibrillation arrest in patients with coronary risk factors. Targeted temperature management started in the ED can be continued safely in
 the catheterization laboratory without untoward effects.


