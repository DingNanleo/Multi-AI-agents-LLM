## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 64: Acute Bronchitis and Upper Respiratory Tract Infections
Cedric W. Lefebvre
INTRODUCTION
Acute bronchitis is a self­limited respiratory infection causing inflammation of the large airways characterized by cough without evidence of pneumonia. The common cold is a viral infection of the upper respiratory tract, primarily affecting the nasal mucosa causing congestion, rhinorrhea, and sneezing. Influenza, or the flu, is a respiratory illness with fever, myalgias, cough, and fatigue. The clinical syndromes associated with these conditions overlap, and their causative pathogens are often similar. Infections of the upper respiratory tract also cause specific clinical conditions such as otitis media (see Chapter 242, “Ear Disorders”), pharyngitis and epiglottitis (see Chapter 246, “Neck and Upper Airway”), bronchiolitis (see Chapter
116, “Neonatal Emergencies and Common Neonatal Problems”), tracheitis (see Chapter 126, “Stridor and Drooling in Infants and Children”), and sinusitis (see Chapter 244, “Nose and Sinuses”).
ACUTE BRONCHITIS

Bronchitis is the ninth most common diagnosis for adult patients presenting to the ED in the United States and ranks as one of the  most common
 outpatient diagnoses worldwide.
PATHOPHYSIOLOGY
2­4
Respiratory viruses are the most common documented causative agent in acute bronchitis ; however, epidemiologic studies are hampered by
 inadequate specimen sampling. The most common viral isolates are influenza A and B viruses, parainfluenza virus, respiratory syncytial virus,
,3 ,4 coronavirus, adenovirus, and rhinovirus. Bacteria have been detected by polymerase chain reaction in 6% to .5% of acute bronchitis cases, excluding patients with chronic bronchitis, for whom bacterial detection rates are higher (see Chapter , “Chronic Obstructive Pulmonary Disease,”
 for management). Haemophilus influenzae and Streptococcus pneumoniae were the most common bacterial isolates. Atypical bacterial species such
,4 as Mycoplasma pneumoniae, Bordetella pertussis, and Chlamydia pneumoniae have also been isolated.
Epithelial infection of the bronchi leads to inflammation and thickening of the bronchial and tracheal mucosa. This inflammatory condition results in airflow obstruction and bronchial hyperresponsiveness, which can cause decreased forced expiratory volume in  second. These physiologic changes can manifest as cough, wheezing, and dyspnea. Sputum production may or may not be prominent. Expectorated sputum is composed of lower
 respiratory tract secretions along with nasopharyngeal and oropharyngeal secretions, cellular debris, and microorganisms. Discoloration of sputum
,6 from clear or white to a yellow or green color may be due to cellular debris or a combination of microorganisms and cellular debris.
CLINICAL FEATURES
The clinical manifestations of acute bronchitis include fever, mild dyspnea, and cough (with or without sputum production) persisting for more than 
 days and lasting up to  or  weeks. During the first few days of infection, the symptoms of an acute upper respiratory infection and acute bronchitis may be indistinguishable. However, the cough will persist for more than  days, and abnormal pulmonary function testing (e.g., reversible decrease in
7­9 forced expiratory volume in  second) consistent with bronchial hyperresponsiveness can be observed in acute bronchitis. Cough due to acute bronchitis can persist for  to  days. History of yellow or green sputum is a poor predictor of bacterial infection and may be present in patients with
,8 acute viral bronchitis.
DIAGNOSIS

ACchuatpet berr o6n4c:h Aitcisu ties aB crolinncichailt ids iaagnndo Usipsp. eArc uRtees bpriorantcohriyt iTs rias cdti aIngfneocstieodn sw, hCeend arcicu tWe .c Loeufgehb (vdrery or productive) is present for more than  days Panagde w 1h /e 1n2
. Terms of Use * Privacy Policy * Notice * Accessibility  evidence of bacterial pneumonia, acute asthma, and exacerbation of chronic bronchitis is absent. Routine sputum cultures are not necessary. Since
,10 bronchitis is a self­limited respiratory disorder, other diagnoses should be considered if cough persists for more than  weeks. Acute bronchitis and bacterial pneumonia can have very similar clinical characteristics. Unlike acute bronchitis, however, pneumonia is not self­limiting and is associated with significant morbidity and mortality if not treated properly. Therefore, it is important to distinguish between the two respiratory
 infections, especially in the elderly, among whom distinctive signs and symptoms of pneumonia may be lacking. If there is suspicion for pneumonia,
 obtain a chest radiograph. The absence of fever, tachycardia, tachypnea, hypoxia, and abnormalities on chest auscultation makes the diagnosis of
9­11 pneumonia unlikely. As a method of differentiating bacterial from viral etiology in lower respiratory tract infections and reducing unnecessary antibiotic prescribing, both calcitonin and rapid point­of­care molecular viral testing have been advocated as a trigger to guide antibiotic treatment
,13 decisions. However, large, well­conducted, randomized controlled trials failed to show reduction in unnecessary antibiotic prescriptions using
  calcitonin (ProAct) or rapid point­of­care molecular viral testing (ResPOC) as decision points.
TREATMENT
15­18
Antibiotics do not provide significant benefit in patients with acute bronchitis. Although patients given antibiotics report shorter mean cough
 duration and a reduction in days feeling ill, the net benefit is small (approximately  day), and adverse effects of antibiotic therapy are significant.
Despite the lack of evidence supporting antibiotic use for acute bronchitis in any patient population, the majority of acute bronchitis patients receive
,10,19­21 antibiotics, especially elderly patients and smokers. Antibiotics should be considered when there is strong suspicion for a specific treatable
,10 pathogen (e.g., B. pertussis; see “Pertussis” below). Additional study is needed to help clinicians determine which patients with acute bronchitis are
 most likely to benefit from antibiotic treatment.
,10,19,22
The routine use of β ­agonists for acute bronchitis should be avoided. However, among patients with evidence of airflow obstruction

,23
(wheezing), β ­agonist use is associated with lower symptom scores and faster resolution of cough. Recent evidence does not support the use of

 oral corticosteroids in acute bronchitis patients with no history of chronic obstructive pulmonary disease or asthma. Antitussives, expectorants, antihistamines, and mucolytics can be considered for cough relief in acute bronchitis; however, limited quality data exist on the efficacy of these
,19  agents. Benzonatate and guaifenesin may provide modest cough relief.
COMMON COLD
EPIDEMIOLOGY
The common cold afflicts adults up to two or three times every year, whereas children suffer up to eight colds annually, with peak activity during
,27 autumn months. Responsible for  million missed school days and  million lost work days, the common cold generates an enormous economic
 burden.
PATHOPHYSIOLOGY

Rhinovirus is the most common causal agent for the common cold. Coronavirus and adenovirus infection are also associated with the common
 cold. After these viruses are spread by contact with or inhaling aerosolized secretions from an infected individual, they invade the upper respiratory tract, triggering symptoms as soon as  to  hours after inoculation.
CLINICAL FEATURES
A common cold is commonly characterized by sore throat, malaise, rhinitis, rhinorrhea, and cough, which typically persist for up to  days. Fever is
,32 more common in children than in adults with the common cold. Clinical signs of rhinovirus infection include nasal discharge and hoarse voice.
DIAGNOSIS
The diagnosis of the common cold is made on clinical grounds alone, based on the typical symptoms listed earlier. Consider alternative causes of symptoms, such as allergic rhinitis, sinusitis, nonviral pharyngitis, Epstein­Barr virus, influenza, pertussis, and human immunodeficiency virus seroconversion illness.
TREATMENT
The goal of treatment for the common cold is supportive care. Decongestants and antihistamines provide modest symptom improvement in some
32­34 adults with the common cold. Topical nasal decongestants such as oxymetazoline provide moderate benefit in reducing nasal airway
,31,35  resistance. Cough and cold preparations are associated with harm in young children and should be avoided in children age  years or younger.
Natural remedies are widely advertised by manufacturers and used by patients, although strong evidence to support their use is lacking. Vitamin C, zinc, and Echinacea are purported to decrease the duration, frequency, and symptoms of the common cold. Studies examining their efficacy have had
,38 mixed and inconclusive results.
INFLUENZA
EPIDEMIOLOGY
The Centers for Disease Control and Prevention estimates that influenza has afflicted  to  million people and caused ,000 to ,000 deaths
 39­41 annually since 2010. In 2009, a swine­origin H1N1 influenza strain resulted in the century’s first global pandemic. This event signaled the emergence of a new pandemic threat, underscoring the importance of understanding the epidemiology of influenza and its potential to impact global health. Influenza viruses are unique pathogens because their evolution involves a complex process of antigenic shifts and sporadic cross­species transmissions between humans, swine, and birds. The intensity of seasonal influenza varies from one year to the next, and localized influenza
 outbreaks can occur during interpandemic years.
PATHOPHYSIOLOGY
The Orthomyxoviridae family includes a diverse array of influenza viruses capable of causing seasonal, endemic, and pandemic infections. Influenza
,43 viruses A and B account for most seasonal influenza epidemics. Direct contact and droplet transfer are the predominant modes of transmission for
 influenza into the upper respiratory tract. The incubation period for influenza is  to  days. Complications of influenza infection include primary
 influenza viral pneumonia, secondary bacterial pneumonia, and severe hypoxemic respiratory failure. The mortality associated with influenza
 infection rises in patients with immunosuppression and bacterial coinfection. Children with influenza­associated pneumonia are more likely than
 children admitted for influenza illness to develop respiratory failure and require intensive care unit admission. Influenza is also a significant cause of
,49 morbidity and mortality in pregnant and postpartum women.
CLINICAL FEATURES
Influenza infection is characterized by abrupt onset of fever, chills, malaise, headache, dry cough, sore throat, myalgias, rhinitis, and fatigue.
Oropharyngeal irritation and mild cervical lymphadenopathy may be present. Fever and intense myalgias are generally more prevalent during
 influenza infection than other viral upper respiratory infections. Up to one third of patients do not have fever. Healthy individuals with uncomplicated influenza illness generally experience resolution of symptoms in  to  days, although cough and malaise may persist beyond  weeks.
DIAGNOSIS
During seasonal influenza outbreaks, most cases of influenza can be diagnosed on clinical grounds alone. Testing should be performed on patients in whom results will influence management, such as hospitalized patients, pregnant women, and patients at higher risk for complications (Table 64­1).
TABLE 64­1
Persons at Higher Risk for Complications of Influenza Infection
Children <5 y (especially <2 y)
Adults ≥65 y
Persons with chronic illnesses and/or conditions* Persons with immunosuppression, including secondary to human immunodeficiency virus infection or medications
Women who are pregnant or postpartum (within  wk of delivery)
Persons <18 y receiving long­term aspirin therapy
Residents of nursing homes and other chronic care facilities
Persons who are morbidly obese (body mass index ≥40 kg/m2)
American Indians/Alaska Natives
*Includes persons with chronic pulmonary (including asthma, cystic fibrosis), cardiovascular (except hypertension alone), renal, hematologic (including sickle cell disease), and hepatic diseases; metabolic disorders (including diabetes mellitus); cancers; or neurologic and neurodevelopment conditions including disorders of the brain, spinal cord, peripheral nerve, and muscle such as cerebral palsy, epilepsy (seizure disorders), stroke, intellectual disability (mental retardation), moderate to severe developmental delay, muscular dystrophy, or spinal cord injury.
When testing for influenza, specimens should be obtained as close to symptom onset as possible, and nasopharyngeal swabs or aspirates are
 preferred. Commercially available rapid influenza diagnostic tests are the most practical in ambulatory settings. However, with reported sensitivities
,53 of <80%, rapid antigen detection influenza tests do not completely exclude infection. A study of a rapid molecular assay reported sensitivities of
54­56 over 90% for both influenza A and B; however, specificity was only 54% to 63% (Table 64­2).
TABLE 64­2
Rapid Influenza Testing Modalities
Time to
Test Comments
Results
Rapid influenza test–antigen detection (EIA) <15 min Sensitivity <80% in adults; follow­up testing with RT­PCR should be considered to confirm negative result
Rapid molecular assay (influenza viral RNA or 15–30 min Detects influenza viral RNA or nucleic acids with higher sensitivity than rapid antigen nucleic acid detection) detection tests (range 66%–94%)
RT­PCR  h High sensitivity and specificity; highly recommended test for influenza
Abbreviations: EIA = enzyme immunoassay; RNA = ribonucleic acid; RT­PCR = reverse transcription polymerase chain reaction.
TREATMENT
The antiviral neuraminidase inhibitors available in the United States for treating and preventing influenza A and B infections include oral oseltamivir, inhaled zanamivir, and intravenous peramivir (Table 64­3). Antiviral treatment for influenza infection within  hours of symptom onset shortens the duration of influenza symptoms (0.5 to  day), but increases the risk of nausea and vomiting (4% to 5%) and psychiatric symptoms (hallucinations,
  abnormal behavior; 1%). Approved in 2018, baloxavir marboxil inhibits an endonuclease involved in viral RNA replication. Single dose treatment
 with baloxavir reduces symptom duration (see Table 64­3), providing a benefit similar to oseltamivir, but may have 4% fewer side effects. Antiviral
,60 ,62 treatment may reduce the risk of complications and reduce mortality in hospitalized patients, but these benefits have been challenged.
Antiviral medication should be started as early as possible, preferably within  hours of illness onset, in patients with confirmed or suspected
 influenza infection who are hospitalized, have severe or progressive illness, and are at higher risk for influenza complications (Table 64­2). Antiviral
,65 treatment can provide benefit even after  hours in pregnant and other high­risk patients.
TABLE 64­3
Antiviral Medications for Influenza: Dosing
Medication Treatment Chemoprophylaxis
Oseltamivir (Tamiflu®)  milligrams orally twice daily ×  d*  milligrams orally once daily ×  d†
Zanamivir (Relenza®)  milligrams (2 inhalations) twice daily ×  d*  milligrams (2 inhalations) once daily ×  d†
Peramivir (Rapivab®) 600 milligrams IV over  to  minutes as a single dose No current recommendation for chemoprophylaxis
‡  milligrams single dose (two 40­milligram pills if weight over  No current recommendation for
Baloxavir Marboxil kg) chemoprophylaxis
(Xofluza®)
*Longer courses can be considered for patients who remain severely ill after  days of treatment.
†For controlling outbreaks in long­term care facilities, the Centers for Disease Control and Prevention recommends a minimum of  weeks of chemoprophylaxis and up to  week after the last identified case, and  days after most recent known exposure in other cases.
‡
Initial studies did not establish safety in pregnancy, patients <12 or >65 years of age.
Recommendations for the treatment of influenza are updated frequently based on epidemiologic data and antiviral resistance patterns. Consult the
Centers for Disease Control and Prevention for the latest updates on influenza treatment guidelines including pharmacotherapy, patient selection,
 dosing, and prophylaxis. Annual vaccination is recommended for all persons aged  months and older because it is the most effective method of
67­70 preventing influenza illness and decreasing all­cause mortality in those infected with influenza.
PERTUSSIS
Pertussis, or “whooping cough,” is an acute respiratory infection in humans caused by the aerobic gram­negative rod B. pertussis. Pertussis toxins cause respiratory epithelial and mucosal injury and interfere with immune cell function. Pertussis pneumonia can occur in children, but in school­age children, adolescents, and adults, upper respiratory infections are the rule.
IMMUNIZATION
Although pertussis is often considered a disease of infants (primarily in those <1 year old who have not completed three doses of vaccination) and a disease in developing countries where immunization is not universal, in North America, the disease is now more common in school­age children and
 adults. School­age children are the usual sources of infection, and adults may serve as carriers of disease. Cyclical outbreaks occur every  to  years.

However, the incidence and deaths due to pertussis have decreased over the past  years.
There are two types of vaccines, whole cell and acellular. Whole­cell pertussis vaccination is effective for about  years and is used in developing nations. The acellular diphtheria, tetanus, and pertussis vaccine (DTaP), developed to remove toxins from the cell membrane, does not protect as long
 as the whole­cell vaccine and is typically used in the developed world. The typical immunization schedule is at , , , and  months of age with a booster at age . Adolescents should receive a DTaP booster. Pregnant women should receive a booster of DTaP to protect neonates and infants and
 to prevent infection in the mother. For the unimmunized elderly (>65 years old), one dose of DTaP is recommended. Although the vaccine is specifically not registered for the elderly,  a study of nearly 120,000 individuals ≥65 years old did not demonstrate any increase in inflammatory or
 allergic events in those receiving DTaP compared with those receiving only the tetanus and diphtheria vaccine. There is no lifelong immunity after a clinical episode of pertussis.
CLINICAL FEATURES
Clinical features in adults are those of the common cold, but after  week, prolonged, paroxysmal, and sleep­disturbing cough develops. Whooping is uncommon in adults. Consider pertussis in situations of chronic cough >2 weeks in duration. Cough may last for several months. Since pertussis is highly communicable, with an attack rate of about 20% even in the immunized, suspect pertussis if there is contact with other individuals with prolonged cough. Except in the elderly, pertussis in adults is not associated with pneumonia. Clinical or radiologic evidence of pneumonia in adults or the elderly suggests secondary bacterial infection.
DIAGNOSIS
Diagnosis is often clinical, especially during epidemics; however, less than 10% of patients with prolonged cough or posttussive emesis will test
 positive. Definitive diagnosis is usually by polymerase chain reaction of nasopharyngeal secretions or serologic detection of antibodies. Other causes of respiratory illnesses with prolonged cough include Mycoplasma, Chlamydophila, influenza virus, and other respiratory viruses. In adults, chronic cough can be associated with angiotensin­converting enzyme inhibitors, gastroesophageal reflux, or asthma.
TREATMENT

Treatment of pertussis is azithromycin, 500 milligrams PO on day  and 250 milligrams PO on days  to . Trimethoprim­sulfamethoxazole, 160 milligrams/800 milligrams twice a day for  days (check renal dosing), is an alternative to those allergic to, or unable to tolerate, macrolides.
Treatment is best if started early, in the first week. After that, antibiotic treatment does not alter the duration of cough. Chemoprophylaxis (same
 regimen as for treatment) is typically given for household contacts. No antitussive agent has been shown to be clearly effective in reducing the
 symptoms of the spasmodic (whooping) cough.


