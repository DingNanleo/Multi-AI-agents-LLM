## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 79: Pancreatitis and Cholecystitis
Bart Besinger; Christine R. Stehman
PANCREATITIS
INTRODUCTION/EPIDEMIOLOGY
Pancreatitis is an inflammatory process of the pancreas that may be limited to just the pancreas, may affect surrounding tissues, or may cause remote
1­3 organ system dysfunction. Most patients will have only one episode of acute pancreatitis, whereas 15% to 30% will have at least one recurrence.
,3
Between 5% and 25% of patients will ultimately develop chronic pancreatitis.
Most cases (~80%) involve only mild inflammation of the pancreas, a disease state with a mortality rate of <1%, which generally
,4 resolves with only supportive care. A small proportion of patients suffer from more severe disease that may involve pancreatic necrosis,
,6 inflammation of surrounding tissues, and organ failure.
7­11
Factors associated with acute pancreatitis are listed in Table 79­1. Most cases are related to either gallstones or alcohol consumption. About 5% of
 all patients who undergo endoscopic retrograde cholangiopancreatography for treatment of gallstones develop pancreatitis within  days.
TABLE 79­1
Causes of Acute Pancreatitis
Common Gallstones (35%–75%)8
Alcohol (25%–35%)8
Idiopathic (10%–20%); increases with age9
Uncommon Hypertriglyceridemia (fasting triglycerides >1000 milligrams/dL) (1%–4%)10
Endoscopic retrograde cholangiopancreatography7
Drugs (1.4%–2%); usually mild disease
More uncommon (total <8% of cases) Abdominal trauma
Postoperative complications, especially post–cardiopulmonary bypass
Hyperparathyroidism
Infection (bacterial, viral, or parasitic)
Autoimmune disease
Tumor (pancreatic, ampullary)
Hypercalcemia
Cystic fibrosis
Rare Ischemia
Posterior penetrating ulcer
Toxin exposure
Unknown Congenital abnormalities11

Chapter 79: Pancreatitis and Cholecystitis, Bart Besinger; Christine R. Stehman 
. Terms of Use * Privacy Policy * Notice * Accessibility

Alcohol use and pancreatitis have a complex relationship, thought to be founded in toxicity and immunologic mechanisms.
MEDICATIONS
Over 500 drugs have been linked to acute pancreatitis, but together, they account for fewer than 2% of cases. Table 79­2 lists the drugs found to be
 most well linked to acute pancreatitis based on number of case reports and recurrence after drug reexposure.
TABLE 79­2
Drugs Associated With Acute Pancreatitis13
Acetaminophen
Amiodarone
Angiotensin­converting enzyme inhibitors and angiotensin receptor blockers (enalapril and losartan)
Antibiotics (erythromycin, metronidazoletetracycline, trimethoprim­sulfamethoxazole)
Antiepileptics (carbamazepine, valproic acid)
Azathioprine
Cannabis
Chemotherapy agents (6­mercaptopurine, cisplatin, L­asparaginase, ifosfamide, tamoxifen, cytarabine, pegaspargase)
Codeine (and other opiates)
Dexamethasone (and other steroids)
Didanosine
Diuretics (chlorothiazide, hydrochlorothiazide, furosemide)
Estrogens
Mesalamine
Methimazole
Pravastatin/simvastatin
Tuberculosis antibiotics (dapsone, isoniazid, rifampin)
Medications associated with acute pancreatitis can be categorized into three groups: antiretrovirals, chemotherapy, and immunosuppressants.
Patients taking these medications are at particular risk of severe disease because of the underlying disease combined with the medication side effects.

2′,3′­Dideoxyinosine can cause potentially fatal pancreatitis, whereas patients receiving the antiretrovirals lamivudine and nelfinavir are at lower risk.
Cancer patients undergoing chemotherapy with one or more of seven medications have a risk of pancreatitis complicating the disease course. These
 medications are L­asparaginase, cisplatin, cytarabine, ifosfamide, mercaptopurine, pegaspargase, and tamoxifen. These agents are used to treat leukemias, lymphomas, sarcomas, and breast, cervical, lung, ovarian, and testicular cancers.
Patients receiving azathioprine for posttransplantation immunosuppression or treatment of inflammatory diseases such as rheumatoid arthritis and
 inflammatory bowel disease are also at risk of developing pancreatitis.
PATHOPHYSIOLOGY
The pathophysiology of pancreatitis is not completely understood. Under normal circumstances, trypsinogen is produced in the pancreas and secreted into the duodenum where it is converted into the protease trypsin. In acute pancreatitis, for unclear reasons, although possibly related to transient obstruction of the pancreatic duct, trypsin is activated within the pancreatic acinar cells. Activation continues in an unregulated fashion, and elimination of activated trypsin is inhibited, resulting in high pancreatic levels of activated trypsin. Activated trypsin in turn activates other digestive enzymes, complements, and kinins, leading to pancreatic autodigestion, injury, and inflammation. Pancreatic injury activates local production of
,15 inflammatory mediators, which cause further inflammation. Fortunately, most cases never progress beyond local inflammation. However, in a
 minority of cases, termed necrotizing pancreatitis, pancreatic injury progresses to involve surrounding tissue or possibly remote organ systems. The release of inflammatory mediators from the pancreas, in particular from the acinar cells, and extrapancreatic organs such as the liver leads to remote
14­16 organ injury and failure, the systemic inflammatory response syndrome, multiorgan failure, and even death.
CLINICAL FEATURES
HISTORY AND PHYSICAL EXAMINATION
Acute pancreatitis causes acute, severe, and persistent abdominal pain, usually associated with nausea, vomiting, anorexia, and decreased oral
 intake. The pain is located in the epigastrium or occasionally in one or both upper quadrants. Pain may radiate to the back, chest, or flanks. Pain may
18­20 worsen with oral intake or lying supine and may improve with sitting up with the knees flexed. Other symptoms include abdominal distention, diaphoresis, hematemesis, and shortness of breath. Pain described as lower abdominal pain or dull or colicky pain is highly unlikely to be
 pancreatitis.

Vital signs may be abnormal, with tachycardia, tachypnea, fever, or hypotension. Pain is often associated with guarding and decreased bowel sounds.
Occasionally patients will be jaundiced, pale, or diaphoretic.
Rare physical findings associated with late, severe necrotizing pancreatitis include Cullen’s sign (bluish discoloration around the umbilicus signifying hemoperitoneum), Grey­Turner sign (reddish­brown discoloration along the flanks signifying retroperitoneal blood or extravasation of pancreatic
,21 exudate), and erythematous skin nodules from focal subcutaneous fat necrosis.
DIAGNOSIS
Formal diagnosis is based on at least two of three criteria: (1) clinical presentation consistent with acute pancreatitis, (2) a serum lipase or amylase value significantly elevated above the upper limit of normal, or (3) imaging findings characteristic of acute pancreatitis (IV contrast­enhanced CT, MRI,
,22 or transabdominal US). The differential diagnosis is wide and consists of all causes of upper abdominal pain, as detailed in Chapter , “Acute
Abdominal Pain.”
LABORATORY STUDIES
There is no gold standard laboratory diagnosis for acute pancreatitis. Two current guidelines recommend that the amylase or lipase value be at least
,22 three times the upper limit of normal ; some recommend a lipase of two times normal or an amylase of three times normal in a patient with the
  appropriate clinical presentation ; and some recommend that any elevation above normal is consistent with the diagnosis. Normal levels for amylase and lipase are based on values in young, healthy patients, making it difficult to determine applicable levels for older patients or those with
 multiple comorbidities. Consequently, the combination of an elevated laboratory value with a clinical presentation consistent with pancreatitis is key
 for diagnosis.

Amylase is not a good choice for diagnosis. Amylase rises within a few hours after the onset of symptoms, peaks within  hours, and normalizes in

 to  days. About 20% of patients with pancreatitis, most of whom have alcohol­ and hypertriglyceridemia­related disease, will have a normal
  amylase. Because of these facts, amylase has a sensitivity of about 70%, with a positive predictive value ranging from 15% to 72%. Amylase can be elevated in multiple non–pancreas­related diseases, such as renal insufficiency, salivary gland diseases, acute appendicitis, cholecystitis, intestinal
,24 obstruction or ischemia, and gynecologic diseases, lowering its specificity for pancreatitis.
Lipase is more specific to pancreatic injury and remains elevated for longer after the onset of symptoms than amylase. Although lipase may be elevated in diabetes and some nonpancreatic diseases such as renal disease, appendicitis, and cholecystitis, it is less associated with nonpancreatic
,25 diseases than amylase. Lipase is more sensitive both in patients with a delayed presentation and in pancreatitis associated with alcohol use and
 hypertriglyceridemia.
If a combination of elevated lipase and amylase is used to diagnose pancreatitis, the diagnosis is more specific and less sensitive than when using elevation in only one value; however, there is no evidence that adding amylase to a nondiagnostic lipase improves diagnostic accuracy over lipase
 alone.

The urine trypsinogen­2 dipstick test is a rapid, noninvasive test with high sensitivity (82%) and specificity (94%). However, given its current limited
 availability, it is not included as part of the diagnostic criteria for pancreatitis.
In addition to serum lipase and amylase, obtain blood studies to evaluate renal and liver function, electrolyte status, glucose level, WBC count, and hemoglobin/hematocrit. These lab results help the clinician predict disease severity and outcome (detailed below), optimize the clinical status of the patient, identify complications that need immediate treatment (cholangitis, organ failure), and assess effectiveness of treatment.
An alanine aminotransferase of >150 U/L within the first  hours of symptoms predicts gallstone pancreatitis with a greater than 85% positive
 predictive value.
IMAGING
Imaging can identify the cause of pancreatitis and can identify complications and severity. For patients with acute pancreatitis where gallstones have
,22,28 not been excluded, obtain a transabdominal US in the ED to detect gallstone pancreatitis. For any patient with respiratory complaints, obtain a chest radiograph to evaluate for pleural effusions and pulmonary infiltrates, both associated with more severe pancreatitis.
In patients who meet the clinical presentation and laboratory criteria, routine early CT, with or without IV or PO contrast, is not recommended for multiple reasons. Most patients have uncomplicated disease and are readily diagnosed by clinical and laboratory criteria. There is no evidence that early CT, with or without contrast, improves clinical outcomes, possibly because CT findings are delayed compared to clinical
,29,30 presentation and may underestimate disease severity. Peripancreatic fluid collections or pancreatic necrosis detected by CT of any kind within the first few days of symptoms generally require no treatment, and the complete extent of these local complications is usually not appreciated until at
 least  days after onset of symptoms. The magnitude of morphologic change on imaging studies does not necessarily correlate with disease severity.

Finally, IV contrast infusion can cause allergic reactions, nephrotoxicity, and worsening of pancreatitis.
If the clinical diagnosis of acute pancreatitis is in doubt, consider further evaluation with IV contrast abdominal CT. Characteristic findings include: (1) pancreatic parenchymal inflammation with or without peripancreatic fat inflammation; (2) pancreatic parenchymal necrosis or peripancreatic
,33 necrosis; (3) peripancreatic fluid collection; or (4) pancreatic pseudocyst. Figure 79­1A–D compares CT image of a normal pancreas to images in various complications. Although noncontrast MRI is not readily available to the ED, this imaging modality can identify the complications of pancreatitis
 and choledocholithiasis. It can be an alternative for patients with renal failure, patients who are allergic to IV contrast, or pregnant patients.
FIGURE 79­1. Abdominal IV contrast­enhanced CT scans showing: A. normal pancreas (arrow) with smooth outer contours, clear demarcation between pancreas and surrounding tissues, and without peripancreatic fluid; B. mild pancreatitis with indistinct pancreatic borders (left arrow), pancreatic edema, and peripancreatic fluid (right arrow); C. edematous pancreas with indistinct borders (left arrow) and area of nonenhancing parenchyma pancreatic necrosis with area of acute pancreatic necrosis (low attenuation representing nonenhancing parenchyma; right arrow); and D. edematous pancreas with indistinct pancreatic borders (left arrow) and a pseudocyst in the pancreatic tail (right arrow). [Images contributed by Bart Besinger, MD, FAAEM.]
TREATMENT
Treatment is supportive and symptom based (Table 79­3). No specific medication effectively treats acute pancreatitis; however, early
35­37 aggressive hydration decreases morbidity and mortality. The benefit of fluid resuscitation may result from increased micro­ and macrocirculatory
 support of the pancreas, which prevents complications such as pancreatic necrosis.
TABLE 79­3
Treatment of Acute Pancreatitis
Treatment Comments
Aggressive crystalloid therapy Lactated Ringer’s preferably .5–4 L, at least 250–500 mL/h or 5–10 mL/kg/h
Use caution in congestive heart failure, renal insufficiency
Monitor response:
– Hematocrit 35%–44%
– Maintain normal creatinine
– Heart rate <120 beats/min
– Mean arterial pressure 65–85 mm Hg
– Urine output .5–1 mL/kg/h (if no renal failure)
Vital signs/pulse oximetry Monitor closely/frequently; initially at least every  h, but patients may require more frequent monitoring
Electrolyte repletion Correct low ionized calcium, hypomagnesemia
Control hyperglycemia
Pain control Parenteral narcotics
Supplemental oxygen As needed for respiratory insufficiency
Antiemetics Control nausea/vomiting
NPO status with early transition back to oral intake
Nasogastric tube/suction typically not indicated
Antibiotics If known or strongly suspected infection, give appropriate antibiotics based on cause
Not indicated prophylactically or for mild pancreatitis
Consultation for endoscopic retrograde cholan​gio​­ In first  h for those with documented biliary obstruction or cholangitis pancreatography
Abbreviation: NPO = nothing by mouth.
Provide fluid resuscitation. Fluid loss results from vomiting, third spacing, increased insensible losses, and decreased oral intake. Patients generally
,22 need a total of .5 to  L of fluid over the first  to  hours. The specific rate of fluid delivery depends on the patient’s clinical status. In the situation of renal or heart failure, deliver fluid more slowly to prevent complications such as volume overload, pulmonary edema, and abdominal compartment syndrome. Crystalloids are the resuscitation fluids of choice. Normal saline in large volumes may cause a nongap hyperchloremic
,39 acidosis and can worsen pancreatitis, possibly by activating trypsinogen and making acinar cells more susceptible to injury. A single randomized study showed a decreased incidence of systemic inflammatory response syndrome in patients who received lactated Ringer’s instead of .9% normal
 saline. Regardless of which fluid is selected, monitor vital signs and urine output for response to hydration.
Control pain and nausea. Pain control is best achieved with IV opioid analgesics. Initially, place patients on NPO (nothing by mouth) status and administer antiemetics. There is no benefit to nasogastric intubation.

Prolonged bowel and pancreas rest increases gut atrophy and bacterial translocation, leading to infection and increasing morbidity and mortality. In
 the ED, if nausea and vomiting have resolved and pain has decreased, transition the patient to oral pain medications and small amounts of food. A
 low­fat solid foods diet provides more calories than a clear liquid diet and is safe.

Acute pancreatitis by itself is not a source of infection, and prophylactic use of antibiotics and antifungals is not recommended. Administer
 antibiotics if a source of infection is demonstrated, such as cholangitis, urinary tract infection, pneumonia, or infected pancreatic necrosis.
COMPLICATIONS OF ACUTE PANCREATITIS
Although most patients with acute pancreatitis have mild uncomplicated disease, a small percentage of patients have more severe disease. In the ED, it is difficult to distinguish disease severity, because most patients present so early in the disease course that complications that define moderately severe or severe disease are not evident. Moderately severe acute pancreatitis is characterized by transient organ failure (<48 hours), local complications, or systemic complications. Severe disease includes one or more local or systemic complications and persistent organ failure (>48
 hours). Critical acute pancreatitis is defined as persistent organ failure and infected pancreatic necrosis.
Local complications, including acute peripancreatic fluid collections, pancreatic pseudocyst, acute pancreatic or peripancreatic necrosis, walled off necrosis, gastric outlet dysfunction, splenic and portal vein thrombosis, and colonic inflammation/necrosis, are not usually well demonstrated on CT
 scan until at least  hours after the onset of symptoms. Suspect local complications in patients who have persistent or recurrent abdominal pain, an increase in pancreatic enzyme levels after an initial decrease, new or worsening organ dysfunction, or sepsis (fever, increased WBC count).
Organ failure can be seen in any system, but three organ systems are particularly susceptible: cardiovascular, respiratory, and renal. Because of the susceptibility of these three organ systems, pay special attention during the patient’s initial evaluation.
Other possible complications of acute pancreatitis are listed in Table 79­4. TABLE 79­4
Complications of Acute Pancreatitis
Pancreatic Peripancreatic Extrapancreatic
Fluid collection Fluid collection Cardiovascular GI
Necrosis Necrosis Hypotension Peptic ulcer disease/erosive
Sterile or Intra­abdominal or retroperitoneal hemorrhage Hypovolemia gastritis infected Pseudoaneurysm (of contiguous visceral arteries, e.g., Myocardial depression GI perforation
Acute or walled the splenic) Myocardial infarction GI bleeding off Bowel inflammation, infarction, or necrosis Pericardial effusion Duodenal or stomach
Abscess Biliary obstruction with jaundice Pulmonary obstruction
Ascites Splenic or portal vein thrombosis Hypoxemia Splenic infarction
Atelectasis Renal
Pleural effusion (with or without Oliguria fistula) Azotemia
Pulmonary infiltrates Acute renal failure
Acute respiratory distress Thrombosis of renal artery or syndrome vein
Respiratory failure Metabolic
Hematologic Hyperglycemia
Disseminated intravascular Hypocalcemia coagulation Hypertriglyceridemia
PREDICTION OF DISEASE SEVERITY
Many different scoring systems exist, including the Ranson criteria, Acute Physiology and Chronic Health Examination­II, modified Glasgow score,
Bedside Index for Severity in Acute Pancreatitis, and Balthazar CT Severity Index. These scoring systems include many data points, some of which are
 not collected until at least  hours after presentation, limiting their utility in the ED. None of these scoring systems is superior to another, and all
 have high false­positive rates. Systemic inflammatory response syndrome at admission and persistent at  hours predicts severe
,46,47 acute pancreatitis more simply and as accurately as the various scoring systems. Besides systemic inflammatory response syndrome, a number of other clinical findings at initial assessment are associated with severe disease. These findings include patient characteristics (age >55 years, obesity, altered mental status, comorbidities), laboratory findings (BUN >20 milligrams/dL or rising; hematocrit >44% or rising; increased creatinine), and radiologic findings (many or large extrapancreatic fluid collections,
,35,48 pleural effusions, pulmonary infiltrates).

Overall, acute pancreatitis has a mortality rate of approximately 1%. Moderately severe and severe disease mortality rates are 5% and 30%,
,49 respectively. Most patients who die do so from multiorgan failure. The sensitivity of systemic inflammatory response syndrome on admission for mortality is 100% with a specificity of 31%, whereas the sensitivity and specificity of systemic inflammatory response syndrome at  hours (persistent
,47 systemic inflammatory response syndrome) are 77% to 89% and 79% to 86%, respectively. Systemic inflammatory response syndrome at admission and  hours, combined with patient characteristics (age, comorbidities, and obesity) and response to treatment, helps predict outcome.
DISPOSITION AND FOLLOW­UP
Patients with nonbiliary pancreatitis whose pain can be controlled in the ED and who can tolerate oral feeding can be discharged. Patients who are discharged from the ED should be referred for appropriate follow­up to help prevent recurrence.
Consider admission for a first bout of acute pancreatitis, for any case of biliary pancreatitis, and for patients needing frequent IV pain medication, not tolerating oral intake because of vomiting or increasing pain, with persistent abnormal vital signs, or with any signs of organ insufficiency (e.g., increased creatinine).
Admit to the intensive care unit a patient with severe pancreatitis or anyone who meets local criteria for an intensive care or at least an intermediate care unit admission. Biliary pancreatitis requires either admission by surgeon or early surgical consultation for consideration of early
 cholecystectomy. Cholecystectomies in patients not suffering from documented gallstone pancreatitis are associated with increased recurrence of
 acute pancreatitis.

Patients with cholangitis or known biliary obstruction on admission may benefit from early endoscopic retrograde cholangiopancreatography. Early routine endoscopic retrograde cholangiopancreatography in patients without one of these two complications does not improve mortality or modify or
 prevent local complications.
SPECIAL CONSIDERATIONS
CHRONIC PANCREATITIS
,3
Chronic pancreatitis is a continuum of acute pancreatitis. From 5% to 25% of patients can progress to chronic pancreatitis. Progression is most
,3 common in alcohol­induced disease, but may happen in any situation.
Attacks are similar to acute pancreatitis. The goal of treatment is hydration and pain and nausea control. The mortality risk of chronic pancreatitis
,3 recurrences is generally lower than that of acute pancreatitis.
CHOLECYSTITIS
INTRODUCTION AND EPIDEMIOLOGY
Cholecystitis is inflammation of the gallbladder that is usually caused by an obstructing gallstone.
Gallstones produce disease states, including acute cholecystitis, that vary considerably in their severity, clinical presentation, and management
 strategies. In the United States, the prevalence of gallstones is 8% among men and 17% among women. Prevalence increases with age and with
 increasing body mass index. Bariatric surgery is also a risk factor for the development of gallstones. The vast majority of gallstones are asymptomatic. Asymptomatic gallstones may be discovered incidentally on diagnostic imaging. The risk of developing symptoms or complications is

1% to 4% per year.
Biliary colic is the most common complication of gallstone disease. Patients experience recurrent attacks of upper abdominal pain that typically last no more than a few hours and resolve spontaneously when the gallstone moves from its obstructing position. If the obstructing stone remains in place, acute cholecystitis may develop over time as the gallbladder becomes distended, inflamed, and in some cases infected. As acute cholecystitis evolves, it may result in necrosis and gangrene of the gallbladder wall (gangrenous cholecystitis). Emphysematous cholecystitis occurs when the inflamed gallbladder becomes infected with gas­producing organisms. Gallbladder perforation is an uncommon but life­threatening complication of cholecystitis. Gangrenous cholecystitis, emphysematous cholecystitis, and gallbladder perforation may occur with or without the presence of gallstones.
Choledocholithiasis, gallstones within the common bile duct, may be either primary (arising from within the bile ducts) or, more commonly, secondary (forming in the gallbladder and then migrating to the common bile duct). Choledocholithiasis or other causes of common bile duct obstruction, such as stricture or tumor, may be complicated by cholangitis, an infection of the biliary tree. Chronic cholecystitis is a state of prolonged gallbladder inflammation typically caused by recurrent episodes of cystic duct obstruction by gallstones. Biliary sludge is microlithiasis composed of cholesterol crystals, calcium bilirubinate pigment, and other calcium salts. Biliary sludge may be visualized on CT or US. The clinical course of biliary sludge is variable. It may resolve spontaneously or progress to cause complications including biliary colic, cholecystitis, cholangitis, or pancreatitis. Acute acalculous cholecystitis occurs in the absence of gallstones. It occurs much less commonly than calculous cholecystitis but is more likely to result in complications. It tends to occur in the setting of critical illness such as septic shock, burns, and major trauma or surgery. Old age, diabetes, and immunosuppression are also risk factors.
PATHOPHYSIOLOGY
Bile is produced by hepatocytes and transported via the biliary system to the small intestine where bile acids are necessary for the digestion and absorption of lipids. Bile is also the vehicle for eliminating a number of substances from the body including bile pigments (e.g., bilirubin), cholesterol, and some drugs. Bile is stored and concentrated in the gallbladder. When a meal is eaten, the gallbladder is provoked to contract by cholecystokinin and neural stimulation, resulting in the expulsion of bile into the cystic duct and then to the common bile duct, where it reaches the duodenum at the sphincter of Oddi.

Gallstone formation is a multifactorial process that involves supersaturation of bile components, crystal nucleation, and gallbladder dysmotility.
Gallstones are classified based on their composition into two categories: pigment stones and cholesterol stones. Pigment stones may be further divided into brown and black stones (Table 79­5).
TABLE 79­5
Gallstone Types
Cholesterol Stones Pigment Stones
Composition Cholesterol monohydrate crystals Black: Calcium bilirubinate
Brown: Mixed composition; usually occur in setting of bacterial or helminthic infection of bile
Relative frequency 80% 20%
Radiographic appearance Radiolucent Radiopaque
Typical patients and types of Obese, female, elderly, rapid Black stones: Chronic liver disease or hemolysis stones weight loss Brown stones: Bile duct stasis (sclerosing cholangitis, strictures); more common in Asia
Nonobstructing gallstones typically do not cause symptoms. As gallstones migrate through the biliary tree, they can obstruct the gallbladder neck, cystic duct, or common bile duct. The resultant distention and increased intraluminal pressure cause pain, nausea, and vomiting. Symptoms are relieved if the gallstone returns to a nonobstructing position within the gallbladder lumen or if it passes through the biliary tree into the duodenum. If the obstruction does not resolve, inflammation results from a complex process that involves mechanical distention, ischemia, and inflammatory mediators including prostaglandins. Interestingly, this long­held notion that gallbladder outlet obstruction is the inciting event in acute cholecystitis
 has been challenged.
58­60
Bile cultures are positive in about half of patients with acute cholecystitis. Gram­negative organisms predominate (Escherichia coli, Klebsiella),
 although gram­positive (Streptococcus, Enterococcus) and anaerobic (Clostridia, Bacteroides) infections occur as well. Polymicrobial infections are common.
CLINICAL FEATURES
HISTORY
Biliary colic presents with pain in the epigastrium or right upper quadrant of the abdomen that occasionally radiates to the back. Despite its name, the pain of biliary colic is more often described as steady than colicky. Pain is often accompanied by nausea and vomiting. Its association with food intake
,62 is variable. Fatty food intolerance is not a reliable predictor of gallstone presence. Biliary colic demonstrates significant circadian periodicity, with a
 peak in symptom occurrence around midnight.
Symptoms of biliary colic typically last a few hours or less. If pain persists longer, gallstone complications of greater severity, such as acute cholecystitis or cholangitis, must be considered. In acute cholecystitis, pain becomes more localized to the right upper quadrant and
 increases in severity as peritoneal irritation occurs.
PHYSICAL EXAMINATION
Patients with biliary colic typically have mild right upper quadrant tenderness without peritoneal signs. In acute cholecystitis, tenderness is more severe and may occasionally be accompanied by rigidity or rebound tenderness. Murphy’s sign (the sudden cessation of deep inspiration due to pain when examining fingers reach the inflamed gallbladder upon palpation of the right subcostal region) is 65% sensitive and 87% specific for acute
 cholecystitis. Patients with biliary colic are afebrile. Fever is classically described in acute cholecystitis but is in fact present in only about one third of
 cases. Jaundice is rarely seen in acute cholecystitis. Jaundice in the setting of biliary tract stone disease implies an obstruction of the common bile duct from choledocholithiasis or extrinsic compression of the bile duct by an impacted cystic duct or gallbladder stone or adjacent inflammation
(Mirizzi’s syndrome).
DIAGNOSIS
The diagnosis of gallstones can be readily established with radiographic studies. However, it is important to distinguish the patient with simple biliary colic from the patient with a more serious gallstone complication such as acute cholecystitis, choledocholithiasis, cholangitis, or gallstone pancreatitis.
Establishing the diagnosis of acute cholecystitis requires the integration of data from the history and physical examination with the results of
 laboratory and radiographic studies. There is no single clinical or laboratory finding that can be relied upon to rule in or rule out the diagnosis.

Diagnostic criteria for acute cholecystitis have been proposed (Table 79­6).
TABLE 79­6
Diagnostic Criteria for Acute Cholecystitis* Local signs Murphy’s sign
Right upper quadrant mass, pain, or tenderness
Systemic signs Fever
Elevated C­reactive protein
Elevated WBC count
Imaging Imaging findings characteristic of acute cholecystitis (see Table 79­7)
Diagnosis Suspected: One local sign and one systemic sign
Definite: One local sign, one systemic sign, and imaging findings of acute cholecystitis
Accuracy Sensitivity .2%, specificity .9% for definite diagnosis criteria compared with surgical pathology gold standard
*Acute hepatitis, chronic cholecystitis, and other acute abdominal disorders should be excluded.
The classic presentation of cholangitis is Charcot’s triad: fever, right upper quadrant abdominal pain, and jaundice. It is present in less than half of the
 cases. Most patients will have a fever and right upper quadrant pain; the presence of jaundice is less common, occurring in about two thirds of
  patients. Reynolds’ pentad adds altered mental status and shock to Charcot’s triad. It is seen in less than 10% of patients with cholangitis.
The differential diagnosis of acute cholecystitis includes other diseases of the biliary tract such as biliary colic, choledocholithiasis, and cholangitis and other conditions of the GI tract such as pancreatitis, hepatitis, peptic ulcer disease, gastritis, and functional dyspepsia. Appendicitis occasionally presents with right upper quadrant pain. Chest disease such as pneumonia, pleurisy, or pulmonary embolism may present with pain of the upper abdomen.
LABORATORY TESTING
Laboratory tests are typically normal in biliary colic. A leukocytosis may be seen in acute cholecystitis, but its absence does not exclude the diagnosis. A
  leukocyte count of >10,000/mm has a 63% sensitivity, 57% specificity, positive likelihood ratio of .5, and negative likelihood ratio of .6. The mean
369  leukocyte count in cholecystitis is ,600/mm . Elevation of C­reactive protein is associated with acute cholecystitis but is nonspecific.
Liver function tests, including bilirubin, alanine aminotransferase, aspartate aminotransferase, alkaline phosphatase, and γ­glutamyl transpeptidase, are often normal in acute cholecystitis. They are more likely to be elevated in the setting of choledocholithiasis or other cause of bile duct
,72  obstruction. Abnormal γ­glutamyl transpeptidase is the most sensitive and specific serum marker of choledocholithiasis. Marked elevations
(>1000 IU/L) of alanine aminotransferase or aspartate aminotransferase can occur in the setting of choledocholithiasis but are more suggestive of a
 hepatocellular necrotic process.
IMAGING
Plain radiography of the abdomen is of minimal value in assessing for biliary tract stone disease. Most gallstones do not contain sufficient amounts of calcium to be visible on plain radiographs. Plain radiography may demonstrate biliary tree air reflective of emphysematous cholecystitis or biliaryenteric fistula, but these are more reliably demonstrated with other imaging modalities.
Ultrasound

Abdominal US (Figure 79­2) is the imaging modality of choice for acute cholecystitis. Its sensitivity and specificity for acute cholecystitis
 are 81% and 83%, respectively. Advantages of US include its availability, lack of ionizing radiation, short study time, excellent sensitivity for gallstones, and ability to elicit tenderness with placement of the US probe. Sonographic Murphy’s sign, maximal tenderness over a sonographically identified gallbladder, is particularly important in the US diagnosis of cholecystitis. The presence of gallstones and a sonographic Murphy’s sign has a positive predictive value of 92% for acute cholecystitis. The absence of both gallstones and the sonographic Murphy’s sign has a negative predictive
 value of 95%. Gallbladder wall thickening and pericholecystic fluid are relatively nonspecific for cholecystitis and may result instead from conditions such as ascites, heart failure, liver disease, or pancreatitis.
FIGURE 79­2. Abdominal US demonstrating acute cholecystitis with a gallstone (arrowhead), gallbladder sludge (asterisk), and pericholecystic fluid (arrow). [Image contributed by Bart Besinger, MD, FAAEM.]

Point­of­care US (POCUS) of the right upper quadrant performed by emergency physicians is a useful modality for the diagnosis of cholelithiasis. For emergency physicians who are highly trained in its use, POCUS for cholecystitis is comparable to that performed by US technicians and interpreted by
  radiologists. Additionally, acute cholecystitis is highly unlikely if cholelithiasis is not found on POCUS.
CT, MRI, and Hepatobiliary Iminodiacetic Acid Scanning
Acute cholecystitis may be demonstrated on IV contrast­enhanced abdominal CT (Figure 79­3). The sensitivity and specificity of CT for cholecystitis
 are ill­defined, although in one retrospective study, the sensitivity of CT for cholecystitis was found to be superior to that of US. IV contrast­enhanced
CT may reveal complications of cholecystitis, such as gangrenous cholecystitis, emphysematous cholecystitis, gallstone ileus, and gallbladder
 perforation, that are not as reliably demonstrated on US. Limitations of CT include its relative insensitivity (~75%) for gallstones and its inability to detect a Murphy’s sign.
FIGURE 79­3. Enhanced abdominal CT showing acute cholecystitis with a radiodense gallstone at the gallbladder neck (arrow) and a thickened gallbladder wall
(arrowheads). [Image contributed by Bart Besinger, MD, FAAEM.]

Technetium­99m hepatobiliary iminodiacetic acid cholescintigraphy is 96% sensitive and 90% specific for acute cholecystitis. An injected radiotracer is excreted by the liver into bile, allowing visualization of the bile ducts and gallbladder. In acute cholecystitis, the obstructed cystic duct results in nonvisualization of the gallbladder. Cholescintigraphy may also reveal delayed gallbladder emptying (biliary dyskinesia). Cholescintigraphy requires hours to perform, limiting its use in the ED.
MRI, including magnetic resonance cholangiopancreatography, may be used to evaluate the gallbladder and biliary tree. The sensitivity and
 specificity of IV gadolinium­enhanced MRI for cholecystitis are similar to those of US. MRI, however, demonstrates more consistent visualization of
 the biliary tree, has less interpreter variability, and is an alternative for patients who are difficult to examine with US.
Imaging for Choledocholithiasis
Choledocholithiasis is difficult to exclude with US or CT. US fails to visualize the entire extrahepatic biliary tree in many patients and has a sensitivity for
 ,85 choledocholithiasis of about 60%. CT, although limited by its inability to detect poorly calcified stones, performs somewhat better than US. On either US or CT, the combined findings of gallbladder stones and common bile duct dilation provide indirect evidence of choledocholithiasis. Normal common bile duct diameter is <5 mm, although diameter is increased in patients with prior cholecystectomy and in the elderly. More definitive evaluation for choledocholithiasis can be accomplished by magnetic resonance cholangiopancreatography, endoscopic US, or endoscopic retrograde cholangiopancreatography.
Imaging findings in acute cholecystitis are summarized in Table 79­7. TABLE 79­7
Imaging for Acute Cholecystitis
Modality Findings Comment
US Sonographic Murphy’s sign Preferred initial imaging test.
Gallbladder wall thickening
>3 mm
Pericholecystic fluid
Gallbladder distention: short axis >40 mm
CT Gallbladder wall thickening Demonstrates complications such as gangrene, gas formation, and perforation. Insensitive for gallstones.
>3 mm Useful in evaluating alternative diagnoses.
Pericholecystic fluid
Pericholecystic fat stranding
Hyperdense gallbladder wall
Gallbladder distention
HIDA Nonvisualization of Excellent sensitivity and specificity. Time consuming, limited availability, ionizing radiation.
gallbladder
MRI/MRCP Gallbladder wall thickening Specificity and sensitivity similar to US. Excellent visualization of biliary tree. Time consuming, limited
>3 mm availability.
Pericholecystic fluid
Pericholecystic fat signal changes
Gallbladder distention: short axis >40 mm
Abbreviations: HIDA = hepatobiliary iminodiacetic acid cholescintigraphy; MRCP = magnetic resonance cholangiopancreatography.
TREATMENT
Asymptomatic gallstones generally require no treatment. Elective cholecystectomy is occasionally recommended for those at high risk for gallstone complications such as patients with sickle cell disease, patients with planned organ transplantation, or those belonging to ethnic groups at high risk for gallbladder cancer.
ED management of biliary colic includes symptom control and referral to a general surgeon for outpatient laparoscopic cholecystectomy. Symptom management includes antiemetics and analgesics. NSAIDs are first­line therapy. The analgesic efficacy of parenteral NSAIDs is comparable to that of
 opioids in biliary colic. Additionally, NSAIDs decrease the frequency of short­term gallstone complications such as cholecystitis. Opioid analgesics are
 often required for pain control. All opioids cause some degree of sphincter of Oddi spasm. The clinical significance of this is unclear, and there is no evidence that any particular opioid drug is superior in treating the pain of biliary colic. Anticholinergic agents such as atropine and glycopyrrolate do
,89 not improve biliary colic pain.
Acute cholecystitis and its complications are managed in the hospital with surgical consultation. Early laparoscopic cholecystectomy is often the treatment of choice. ED treatment includes the provision of analgesia, administration of antiemetics for nausea and vomiting, cessation of oral intake, volume and electrolyte replacement, and administration of antibiotics. Appropriate antibiotic regimens include second­ and third­generation
90­92 cephalosporins, carbapenems, β­lactam/β­lactamase inhibitor combinations, or the combination of metronidazole and a fluoroquinolone. The
 value of antibiotics in mild acute cholecystitis has been questioned.
Cholangitis can be a life­threatening disease that demands aggressive care including generous fluid resuscitation, the timely administration of antibiotics, and early biliary decompression. Endoscopic retrograde cholangiopancreatography is the decompression procedure of choice in most instances. When cholangitis is suspected, emergency consultation with a GI surgeon or gastroenterologist is needed. Percutaneous or surgical drainage is an alternative when endoscopic retrograde cholangiopancreatography is not feasible or is unsuccessful.
DISPOSITION AND FOLLOW­UP
Once symptoms are adequately controlled, patients with biliary colic are typically discharged from the ED to follow up with a general surgeon. They should be instructed to return to the ED if symptoms of gallstone complications (e.g., prolonged pain, fever, jaundice) arise. Patients who present to the ED with acute cholecystitis or cholangitis require hospital admission. For suspected cholangitis, emergency consultation or transfer to an institution with treatment capabilities for endoscopic retrograde cholangiopancreatography is necessary. Patients with severe illness, including many with cholangitis, should be admitted to a critical care unit.
SPECIAL CONSIDERATIONS
Emphysematous cholecystitis is characterized by gas in the gallbladder wall or lumen resulting from infection with gas­producing organisms such as Clostridium species, E. coli, and Klebsiella species (Figure 79­4). It is associated with underlying diabetes and is more common in older patients. Its association with gallstones is variable. Gas occupying the gallbladder may be seen on plain radiographs, US, or, more reliably, IV contrast­enhanced

CT. Emphysematous cholecystitis is notable for a mortality rate much higher than that for uncomplicated cholecystitis. In addition to broad­spectrum antibiotics, patients with emphysematous cholecystitis require prompt surgical consultation and consideration for urgent cholecystectomy.
Percutaneous cholecystostomy is an alternative therapy for severely ill patients.
FIGURE 79­4. Contrast­enhanced abdominal CT showing emphysematous cholecystitis with gallstones (arrowhead), intraluminal gallbladder gas (arrow), and pericholecystic inflammatory changes (plus sign). [Image contributed by Bart Besinger, MD, FAAEM.]
Gallstone ileus is a mechanical small bowel obstruction caused by an ectopic gallstone that has reached the intestinal lumen via a biliary­enteric fistula. Such a fistula may occur in the setting of inflammation secondary to cholecystitis. Gallstone ileus may be diagnosed on plain films of the abdomen or, more dependably, with CT. The classic radiographic appearance is Rigler’s triad: a small bowel obstruction, pneumobilia, and an ectopic
 gallstone. Operative therapy is typically indicated.
Acalculous cholecystitis represents a small minority of cholecystitis cases and most often occurs in the inpatient setting among patients with critical illness. Nevertheless, it may be occasionally encountered in the ED, particularly in immunocompromised patients. Diagnosis is challenging because the clinical presentation is variable and no test result is pathognomonic. US, IV contrast­enhanced CT, and cholescintigraphy are helpful in establishing the diagnosis, but sensitivity and specificity are less than for calculous cholecystitis. Acalculous cholecystitis runs a more fulminant course than
 cholecystitis associated with gallstones. Complications such as gangrene and perforation are common, and mortality is high.
Chronic cholecystitis is gallbladder inflammation and scarring that occurs over time, usually secondary to intermittent cystic duct obstruction. It presents in a manner similar to biliary colic or acute cholecystitis, although symptoms and examination findings may be more subtle. Patients may report recurrent episodes of pain.
Postcholecystectomy syndrome refers to a heterogeneous group of disorders that present with persistent abdominal symptoms after removal of the gallbladder. In the early postcholecystectomy period, bile leak is the principal concern. Choledocholithiasis is a common cause of postcholecystectomy pain. Symptom­producing common bile duct stones may be “retained” (present at the time of surgery) or may develop
 postoperatively, formed primarily in the bile ducts often in the setting of bile stasis. Postcholecystectomy syndrome may result from nonbiliary pain that was erroneously attributed to a biliary cause and therefore not remedied by cholecystectomy.


