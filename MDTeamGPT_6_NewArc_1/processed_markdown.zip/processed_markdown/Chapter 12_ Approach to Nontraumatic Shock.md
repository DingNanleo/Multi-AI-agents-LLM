University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 12: Approach to Nontraumatic Shock
Bret A. Nicks; John P. Gaillard
EPIDEMIOLOGY

Using a systolic blood pressure <90 mm Hg as criteria, .4% to .3% of patients presenting to EDs are in shock. Mortality depends on the inciting event.
 ,4
Septic shock has an estimated hospital mortality of 26%. Cardiogenic shock has an estimated hospital mortality of 39% to 48%. Neurogenic shock
 occurs in <20% of spinal cord injuries (cervical, .3%; thoracic, 7%; lumbar, 3%). The definition of and treatment approach to shock continue to evolve, but the initial approach to a patient in shock follows similar principles, regardless of the inciting factors or cause.
Patients present to the ED in varying stages of critical illness and shock. These stages are confounded by age, comorbidities, and delays in presentation. A focus on early recognition, rapid diagnosis, and empiric resuscitation is essential. Therapy and patient stabilization may need to occur simultaneously with evaluation.
PATHOPHYSIOLOGY
Shock is a state of circulatory insufficiency that creates an imbalance between tissue oxygen supply (delivery) and demand (consumption), resulting in end­organ dysfunction. Reduction in effective perfusion may be due to a local or global delivery deficiency or utilization deficiency with suboptimal
6­8 substrate at the cellular or subcellular level. The mechanisms that can result in shock are frequently divided into four categories: (1) hypovolemic, (2) distributive, (3) cardiogenic, and (4) obstructive.
CATEGORIES OF SHOCK
The four categories of shock can be described in terms of their respective physiologic changes and common causes, recognizing that a single etiology
,10 may manifest the clinical findings of more than one shock type (Table 12­1). Hypovolemic shock occurs when decreased intravascular fluid or decreased blood volume causes decreased preload, stroke volume, and cardiac output (CO). Severe blood loss (hemorrhage) can cause decreased myocardial oxygenation, which decreases contractility and CO. This action may lead to an autonomic increase in the systemic vascular resistance (SVR).
Hypovolemic shock can also occur due to volume loss from other etiologies. In distributive shock, there is relative intravascular volume depletion
 due to marked systemic vasodilatation. This is most commonly seen in septic shock. Compensatory responses to decreased SVR may include increased CO (increased contractility and heart rate) and tachycardia. The concurrent decreased SVR results in a decreased preload and may hinder CO
 overall. In sepsis, up to 40% of patients may have a transient cardiomyopathy characterized by decreased contractility and increased mortality.
Anaphylaxis, adrenal insufficiency, and neurogenic shock are additional causes of distributive shock. In cardiogenic shock, the left ventricle fails to
 deliver oxygenated blood to peripheral tissues due to variances in contractility, as well as preload, afterload, and right ventricular function.
Myocardial infarction is the most common cause of cardiogenic shock. Dysrhythmias are another common cause because they can lead to a decreased
CO. Bradyarrhythmias result in low CO, and tachyarrhythmias can result in decreased preload and stroke volume. Patients with cardiogenic shock may soon develop clinically evident infection (up to 46%) and/or demonstrate an inflammatory response similar to but less pronounced than with septic
 shock. Obstructive shock is uncommon (1%) and is due to a decrease in venous return or cardiac compliance due to an increased left ventricular outflow obstruction or marked preload decrease. Cardiac tamponade, pulmonary embolism, and tension pneumothorax are causes of obstructive shock.
TABLE 12­1
Categories of Shock

Type Percentage* Hemodynamic Changes Etiologies†
Chapter 12: Approach to Nontraumatic Shock, Bret A. Nicks; John P. Gaillard 
. Terms of Use * Privacy Policy * Notice * Accessibility
Distributive 33%–50% Decreased preload, decreased SVR, mixed CO Sepsis, neurogenic shock, anaphylaxis
Hypovolemic 31%–36% Decreased preload, increased SVR, decreased CO Hemorrhage, capillary leak, GI losses, burns
Cardiogenic 14%–29% Increased preload, increased afterload, increased SVR, decreased CO MI, dysrhythmias, heart failure, valvular disease
Obstructive 1% Decreased preload, increased SVR, decreased CO PE, pericardial tamponade, tension PTX
*Percentage of patients presenting to the ED; percentages will vary depending on hospital type and population.
†Etiologies may demonstrate findings of more than one type of shock.
Abbreviations: CO = cardiac output; MI = myocardial infarction; PE = pulmonary embolism; PTX = pneumothorax; SVR = systemic vascular resistance.
FACTORS AFFECTING CARDIAC OUTPUT
CO is determined by heart rate and stroke volume. Stroke volume is dependent on preload, afterload, and contractility. The mean arterial pressure is dependent on CO and the SVR. This is important because there is a mean arterial pressure threshold below which oxygen delivery is decreased. SVR directly impacts mean arterial pressure, but also impacts afterload and thus CO. Patients in shock may initially have normal blood pressures (cryptic shock), yet have other objective signs of shock (see later section “Clinical Features”). Tissue oxygenation is predicated on CO being sufficient enough to deliver oxygenated hemoglobin to the tissues. CO is dependent on the interplay of cardiac inotropy (speed and shortening capacity of myocardium), chronotropy (heart contraction rate), and lusitropy (ability of heart muscle to relax and heart chambers to fill). Determinants of inotropy include autonomic input from sympathetic activation, parasympathetic inhibition, circulating catecholamines, and short­lived responses to an increase in
 afterload (Anrep effect) or heart rate (Bowditch effect). Increases in the inotropic state help to maintain stroke volume at high heart rates. During shock states, higher levels of epinephrine will be produced and reinforce adrenergic tone. Epinephrine levels are significantly elevated during induced
 hemorrhagic shock, but these levels subsequently reduce to almost normal levels after adequate blood pressure is restored. An acidotic milieu,
 which is common in shock, further compromises ventricular contractile force and blood pressure. Chronotropy and lusitropy are both influenced by sympathetic input. Norepinephrine interacts with cardiac β ­receptors, resulting in increased cyclic adenosine monophosphate. This leads to a

 process of intracellular signaling with an increased chronotropy and sequestration of calcium, leading to myocardial relaxation.
LACTIC ACID
When compensatory mechanisms fail to correct the imbalance between tissue supply and demand, anaerobic metabolism occurs and results in the formation of lactic acid. Lactic acid is rapidly buffered, resulting in the formation of measured serum lactate. Normal venous lactate levels are <2.0 mmol/L. Most cases of lactic acidosis are a result of inadequate oxygen delivery, but lactic acidosis occasionally can develop from an excessively high oxygen demand (e.g., status epilepticus). In other cases, lactic acidosis occurs because of impaired tissue oxygen utilization (e.g., septic shock or the postresuscitation phase of cardiac arrest). Elevated lactate is a marker of impaired oxygen delivery or utilization and correlates with short­term
 prognosis of critically ill patients in the ED. Serial lactate assessments may be indicated because lactate clearance is associated with improved
 outcomes in septic shock and may assist with resuscitation.
COMPENSATORY MECHANISMS AND THEIR FAILURE
Shock provokes a myriad of autonomic responses to maintain perfusion pressure to vital organs. Stimulation of the carotid baroreceptor stretch reflex activates the sympathetic nervous system, triggering (1) arteriolar vasoconstriction, resulting in redistribution of blood flow from the skin, skeletal muscle, kidneys, and splanchnic viscera; (2) an increase in heart rate and contractility that increases CO; (3) constriction of venous capacitance vessels, which augments venous return; (4) release of the vasoactive hormones epinephrine, norepinephrine, dopamine, and cortisol to increase arteriolar and venous tone; and (5) release of antidiuretic hormone and activation of the renin­angiotensin axis to enhance water and sodium conservation to
 maintain intravascular volume.
These compensatory mechanisms attempt to maintain oxygen delivery to the most critical organs (heart and brain), but blood flow to other organs, such as the kidneys and GI tract, may be compromised. The cellular response to decreased oxygen delivery (adenosine triphosphate depletion) leads to ion­pump dysfunction, influx of sodium, efflux of potassium, and reduction in membrane resting potential. As shock progresses, the loss of cellular integrity and the breakdown in cellular homeostasis result in cellular death. These pathologic events give rise to a cascade of metabolic features including hyperkalemia, hyponatremia, azotemia, hyper­ or hypoglycemia, and lactic acidosis.
Inflammation plays an important role in several different types of shock, especially in septic shock, but also in shock associated with anaphylaxis,
 burns, trauma, and cardiogenic causes. Previously, the systemic inflammatory response syndrome was part of the definition of sepsis, but that
 changed with a revised definition of sepsis, Sepsis­3, in 2016. See Chapter 151, “Sepsis,” for detailed discussion.
As global tissue hypoxia progresses, shock ensues, followed by the multiorgan dysfunction syndrome, which is manifested by renal failure, respiratory failure, myocardial depression, liver failure, and then disseminated intravascular coagulation. The fulminant progression from global tissue hypoxia to multiorgan dysfunction syndrome is determined by the severity of inadequate tissue perfusion and the balance of anti­inflammatory and proinflammatory mediators (Figure 12­1).
FIGURE 12­1. The pathophysiology of shock, the inflammatory response, and multiorgan dysfunction.
CLINICAL FEATURES
HISTORY AND COMORBIDITIES
Although the clinical presentation of a patient in shock and the underlying cause may be quite apparent (e.g., acute myocardial infarction, anaphylaxis, or hemorrhage), it may be difficult to obtain a history from patients in shock. Assistance with medical history from EMS, family, or other sources may help determine the cause of shock. Some patients in shock may have few symptoms other than generalized weakness, lethargy, or altered mental status. If the patient is unresponsive, consider trauma as a primary or secondary complication.
PHYSICAL EXAMINATION
Shock is usually associated with systemic arterial hypotension—systolic blood pressure <90 mm Hg. Blood pressure may not drop if there is an increase in peripheral vascular resistance in the presence of decreased CO with inadequate tissue hypoperfusion. For this reason, blood pressure is an insensitive marker for global tissue hypoperfusion. Shock may occur with a normal blood pressure, and hypotension may occur without shock. No single vital sign is diagnostic of shock, and blood pressure is particularly insensitive in the presence of peripheral vascular disease, tachycardia with a small pulse pressure, or cardiac dysrhythmias. Composite physical findings are useful in the assessment of shock (Table 12­2).
TABLE 12­2
Composite Physical Examination Findings in Shock
Temperature Hyperthermia or hypothermia may be present. Endogenous hypothermia (hypometabolic shock) must be distinguished from exogenous environmental hypothermia.
Heart rate Usually elevated; however, paradoxical bradycardia can be seen in shock states due to hypoglycemia, β­blocker use, and preexisting cardiac disease.
Systolic blood May actually increase slightly when cardiac contractility increases in early shock and then fall as shock advances.
pressure
Diastolic Correlates with arteriolar vasoconstriction and may rise early in shock and then fall when cardiovascular compensation fails.
blood pressure
Pulse pressure Increases early in shock and decreases before systolic pressure begins to drop.
Mean arterial Often low, <65 mm Hg.
blood pressure
CNS Acute delirium, restlessness, disorientation, confusion, and coma secondary to a decrease in cerebral perfusion pressure.
Skin/capillary Pallor, pale, dusky, clammy, cyanosis, sweating, cool, and capillary refill time >2–3 s.
refill
Cardiovascular Neck vein distention or flattening depending on the type of shock. Tachycardia and arrhythmias. An S may result from high­output
 states. Decreased coronary perfusion pressures can lead to ischemia, decreased ventricular compliance, increased left ventricular diastolic pressure, and pulmonary edema.
Respiratory Tachypnea, increased minute ventilation, increased dead space, bronchospasm, and hyper­ or hypocapnia with progression to respiratory failure.
Splanchnic Ileus, GI bleeding, pancreatitis, and mesenteric ischemia can occur due to low­flow states.
organs
Renal Reduced glomerular filtration rate. Renal blood flow redistributes from the renal cortex toward the renal medulla leading to oliguria.
Metabolic Lactic acidosis, hyperglycemia, hypoglycemia, and hyperkalemia. As shock progresses, metabolic acidosis occurs with concurrent respiratory compensation.
DIAGNOSIS
LABORATORY EVALUATION
No single laboratory value is sensitive or specific for shock. Laboratory studies are driven by the clinical presentation and the presumptive cause.
Common studies are listed in Table 12­3. Arterial blood gases are useful to assess acid­base status and ventilation and oxygenation concerns,
 whereas a venous blood gas is limited to acid­base information. A rise in serum lactate correlates with mortality in many shock states ; typically this is due to anaerobic metabolism, but nonhypoxic causes of lactic acidosis due to cellular dysfunction occur in shock states. A wide range of laboratory abnormalities may be encountered in shock. The incidence of adrenal dysfunction can be as high as 30% in this subset of patients. Most abnormal values merely point to the particular organ system that is contributing to, or being affected by, the shock state.
TABLE 12­3
Initial Diagnostic Studies to Evaluate a Patient in Shock* CBC with differential
Electrolytes, glucose, calcium, magnesium, phosphorus
BUN, creatinine
Serum lactate
ECG
Urinalysis
Chest radiograph
Coagulation studies: prothrombin time, PTT, INR
Arterial blood gas (pH, carbon dioxide and oxygen levels, base deficit)
Hepatic function panel
Cultures: blood, urine, suspicious wounds, quantitative sputum culture
Cortisol level
Pregnancy test
CT of chest/abdomen/pelvis as indicated by history, physical exam
*Ordering of tests should be individualized by patient presentation and history (see also Chapter 151, “Sepsis”).
IMAGING
Chest Radiograph
The portable anteroposterior view chest radiograph is often used in the evaluation of unstable patients to avoid transporting the patient during resuscitation. While limitations exist, evaluation of the heart size, presence of pulmonary edema, free air under the diaphragm, pneumothorax, infiltrates, or effusions may provide useful clinical information.
US
Bedside US assessment is an important tool for developing a differential diagnosis, assessing volume status, defining cardiac function, and assisting with procedures. Various US methods are described to determine overall volume status by assessing right­sided filling pressures, including measuring inferior vena cava respiratory variation or end­expiratory vena cava respiratory variation, and other methods.
Bedside cardiac US to assess left ventricular ejection fraction can assist with determining the cause of shock. Emergency physicians trained in focused
 bedside cardiac US can provide an estimated ejection fraction with high relative correlation to cardiologists.
US may also be used to assess for vascular emergencies. Identifying an abdominal aortic aneurysm on US may lead to further evaluation. Findings of a deep vein thrombosis may increase the suspicion for a pulmonary embolism.
Additional US protocols, such as the Abdominal and Cardiac Evaluation with Sonography in Shock protocol and the Rapid Ultrasound in Shock
17­20 protocol, have been formulated using many of the aforementioned concepts. The Abdominal and Cardiac Evaluation with Sonography in Shock protocol looks at cardiac function, inferior vena cava dynamics, pulmonary congestion, lung sliding and consolidation, abdominal free fluid,
,18 abdominal aortic aneurysm, and leg venous thrombosis to assist in differential diagnosis generation or narrowing. The Rapid Ultrasound in Shock exam involves a three­part bedside physiologic assessment simplified as the pump (cardiac), the tank (volume status), and the pipes (arterial and
19­21 venous). However, as with any US intervention, operator competency is essential.
CT
Although CT is an accurate and noninvasive approach for detecting internal pathology, patients must travel from the ED to the radiology suite, which may be unadvisable in unstable shock. The potential benefits of CT must be weighed against the associated risks, including concerns about renal function due to hypovolemia and contrast­induced nephropathy. CT scans without IV contrast will add some information to the clinical picture, although not to the degree of a scan with IV contrast.
HEMODYNAMIC MONITORING
Hemodynamic monitoring helps assess the severity of shock and the response to treatment. Monitoring capabilities should initially include pulse oximetry, ECG monitoring, and noninvasive blood pressure monitoring. In the critical care arena, intra­arterial blood pressure monitoring, end­tidal carbon dioxide monitoring, central venous pressure, and central venous oxygen saturation from the superior vena cava (ScvO ) monitoring are
 frequently used. When obtaining central access, the average access time, number of attempts, and mechanical complications are reduced when a US­
 assisted approach is used.
TREATMENT
See Chapter 151, “Sepsis,” for treatment of sepsis. Comprehensive and timely ED care can significantly decrease the predicted mortality of critically ill
 patients in as little as  hours of treatment. Application of an algorithmic approach to optimize hemodynamic end points with early goal­directed
 therapy in the ED reduced mortality by 16% in patients with severe sepsis or septic shock in 2001. That original study, the Surviving Sepsis Campaign
  that followed, and other algorithmic efforts have changed the approach to sepsis and shock care on a worldwide basis. Two large, multicenter,
,28 randomized controlled trials published in 2014 failed to show additional benefits to a rigid algorithmic approach. However, we attempt to present below the most beneficial aspects of shock care demonstrated by the medical progress of the past  years. The ABCDE tenets of shock resuscitation are establishing airway, controlling the work of breathing, optimizing the circulation, ensuring adequate oxygen
 delivery, and achieving end points of resuscitation.
ESTABLISHING THE AIRWAY
Airway control is best obtained through endotracheal intubation. Sedatives used to facilitate intubation may cause arterial vasodilatation, venodilation, or myocardial suppression and may result in hypotension. Positive­pressure ventilation reduces preload and CO. The combination of sedative agents and positive­pressure ventilation will often lead to hemodynamic collapse. To avoid this unwanted situation, initiate volume resuscitation and vasoactive agents before intubation and positive­pressure ventilation.
CONTROLLING THE WORK OF BREATHING
Control of breathing is required when significant work of breathing accompanies shock. Respiratory muscles are significant consumers of oxygen during shock and contribute to lactate production. Mechanical ventilation and sedation allow for adequate oxygenation, improvement of hypercapnia, and assisted, controlled, synchronized ventilation. All of these treatments decrease the work of breathing and improve survival. When starting mechanical ventilation on a patient, it is essential to consider the patient’s compensatory minute ventilation prior to intubation to ensure appropriate initial settings are selected. After a patient is placed on mechanical ventilation, obtain an arterial blood gas to evaluate acid­base status, oxygenation, and ventilation. Neuromuscular blocking agents should be considered to further decrease respiratory muscle oxygen consumption and preserve
 oxygen delivery to vital organs, especially if patients are severely hypoxemic due to acute respiratory distress syndrome.
OPTIMIZING THE CIRCULATION
Fluids
Circulatory or hemodynamic stabilization begins with intravascular access through large­bore peripheral venous lines. The Trendelenburg position does not improve cardiopulmonary performance compared with the supine position. It may worsen pulmonary gas exchange and predispose to aspiration. Passive leg raising above the level of the heart with the patient supine may be effective. If passive leg raising results in an increase in blood
 pressure or CO, fluid resuscitation is indicated.

Fluid resuscitation should begin with isotonic crystalloid. Balanced crystalloids, such as lactated Ringer’s solution, may offer a small mortality
 advantage over normal saline solution (14.3% vs. .4% in a large trial of ,802 critically ill patients). The amount and rate of infusion are determined by an estimate of the hemodynamic abnormality. Most patients in shock have either an absolute or relative volume deficit. The exception is the patient in cardiogenic shock with pulmonary edema. Administer fluid rapidly (over  to  minutes), in set quantities of 500 or 1000 mL of normal saline, and reassess the patient after each bolus. Patients with a modest degree of hypovolemia usually require an initial  to  mL/kg of isotonic crystalloid, and current Centers for Medicare and Medicaid Services sepsis guidelines require  mL/kg; however, there are few data to support this
 uniform recommendation. More fluids may be needed for profound volume deficits. It is common for patients in septic shock to receive  L of crystalloid in the first  hours of hospital care. For large fluid volumes, consider using lactated Ringer’s or Plasma­Lyte® to avoid hyperchloremic
,36 metabolic acidosis associated with .9% sodium chloride solution (see later section “Controversies of Treatment”). In clinical situations where hypochloremia can be predicted, such as from GI losses due to vomiting or from urinary excretion due to diuretics, there may be an advantage to .9% sodium chloride rehydration.
Central venous access may aid in assessing volume status (preload) and monitoring ScvO . It is also the preferred route for the long­term
 administration of certain vasopressor therapy. However, there is no need for universal central access in patients with septic shock, and the need for
 central access should be individually determined.
Vasopressors

Vasopressors are used when there has been an inadequate response to volume resuscitation or if there are contraindications to volume infusion.
Vasopressors are most effective when the vascular space is “full” and least effective when the vascular space is depleted. Patients with chronic hypertension may be at greater risk of renal injury at lower blood pressures; however, in others, there appears to be no mortality benefit in raising
,38 mean arterial pressure above the  to  mm Hg range.
Vasopressor agents have variable effects on the α­adrenergic, β­adrenergic, vasopressin, and dopaminergic receptors (Table 12­4). Although vasopressors improve perfusion pressure in the large vessels, they may decrease capillary blood flow in certain tissue beds, especially the GI tract and peripheral vasculature. If multiple vasopressors are used, they should be simplified as soon as the best therapeutic agent is identified. In addition to a vasopressor, an inotrope may be needed to directly increase CO by increasing contractility and stroke volume. Careful vasopressor infusion initially
,40 through a peripheral IV is unlikely to result in tissue injury and will improve the time to achieve hemodynamic stability.
TABLE 12­4
Commonly Used Vasoactive Agents (all vasopressors increase myocardial oxygen demand; most should be titrated to desired effect)
Cardiac Cardiac
Drug Dose Action Vasoconstriction Vasodilation
Contractility Output
Dobutamine .0–20.0 β , some β and α in ++++ + ++ Increases
   micrograms/kg/min large dosages
Side effects and Inotrope only; causes tachydysrhythmias, GI distress, hypotension in volume­depleted patients; less peripheral vasoconstriction comments than dopamine; fewer arrhythmias than isoproterenol
Dopamine .5–20 α, β, and dopaminergic ++ at .5–5 ++ at 5–20 + at .5–2.0 Usually micrograms/kg/min micrograms/kg/min micrograms/kg/min micrograms/kg/min increases
Side effects and Tachydysrhythmias; a cerebral, mesenteric, coronary, and renal vasodilator at low doses; Surviving Sepsis Campaign second line, lot comments of overlap with α/β/dopaminergic receptors and dose
Epinephrine 2–10 α and β ++++ at .5–8 ++++ at >8 +++ Increases micrograms/min micrograms/kg/min micrograms/kg/min
Side effects and Causes tachydysrhythmia, leukocytosis; increases myocardial oxygen consumption; may increase lactate; no real maximum dose comments
Isoproterenol .01–0.1 β and some β ++++  ++++ Increases
  microgram/kg/min
Side effects and Inotrope; causes tachydysrhythmia, facial flushing, hypotension in hypovolemic patients; increases myocardial oxygen consumption comments
Norepinephrine .5–50 Primarily α , some β ++ ++++  Slightly
  micrograms/min increases
Side effects and Useful when loss of venous tone predominates; first­line agent for most situations comments
Phenylephrine 10–200 Pure α  ++++  Decreases micrograms/min
Side effects and Reflex bradycardia, headache, restlessness, excitability, rarely arrhythmias; used on patients in shock with tachycardia or comments supraventricular arrhythmias; not good comparatively for septic shock
Vasopressin .01–0.04 units/min Directly stimulates V  ++++  
 receptor on smooth muscle
Side effects and Primarily vasoconstriction; usually started at max dose and not titrated, typically added to norepinephrine comments
Note:  = no effect; + = mild effect; ++ = moderate effect; +++ = marked effect; ++++ = very marked effect.
ENSURING ADEQUATE OXYGEN DELIVERY
Control of oxygen consumption is important in restoring the balance of oxygen supply and demand to the tissue (oxygen consumption equation). A hyperadrenergic state results from the compensatory response to shock, physiologic stress, pain, cold treatment rooms, and anxiety. Pain further suppresses myocardial function, impairing oxygen delivery and increasing consumption. Providing analgesia, muscle relaxation, warm covering, anxiolytics, and even paralytic agents, when appropriate, decreases this inappropriate systemic oxygen consumption.
Once blood pressure is stabilized through optimization of preload and afterload, oxygen delivery can be assessed and further manipulated. Restore arterial oxygen saturation to ≥91%. In shock states, consider a transfusion of packed red blood cells to maintain hemoglobin ≥7 grams/dL.  If CO can be assessed, it should be increased using volume infusion or inotropic agents in incremental amounts until venous oxygen saturation (mixed venous oxygen saturation [SvO ] or ScvO ) and lactate are normalized.

Sequential examination of lactate and SvO or ScvO is a method to assess adequacy of a patient’s resuscitation. Continuous measurement of SvO or

ScvO can be used in the ED, although results from the ProCESS trial question the need for this in resuscitation management. A variety of technologic

41­47 tools may be used to assess tissue perfusion during resuscitation. These technologies may be available in some EDs, but are more often found in
,47 intensive care units. Transfer of the patient to the intensive care unit should not be delayed so that monitoring devices can be placed in the ED.
END POINTS OF RESUSCITATION
The goal of resuscitation is to use hemodynamic and physiologic values to guide therapy in order to maximize survival and minimize morbidity. No
,37,38 therapeutic end point is universally effective, and only a few have been tested in prospective trials, with mixed results. Hypotension at ED
 presentation is associated with poor outcomes. Noninvasive parameters, such as blood pressure, heart rate, and urine output, may underestimate
,37,38,48 the degree of remaining hypoperfusion and oxygen debt, so the use of additional physiologic end points may be informative. A goal­directed approach of mean arterial pressure >65 mm Hg, central venous pressure of  to  mm Hg, ScvO >70%, and urine output >0.5 mL/kg/h during ED
 resuscitation of septic shock has been shown to decrease mortality, but which of the metrics accounts for the mortality decrease remains in
,27,28,34 question. Source control, whether with infection, hemorrhage, or other state of shock, is essential in the initial stages of management. If shock or hypotension persists, reassessment at the patient’s bedside is essential while considering the important issues in Table 12­5. TABLE 12­5
Questions to Answer If There Is Persistent Shock or Hypotension
Equipment and monitoring
Is the patient appropriately monitored?
Is there an equipment malfunction, such as dampening of the arterial line or disconnection from the transducer?
Is the IV tubing into which the vasopressors are running connected appropriately?
Are the vasopressor infusion pumps working?
Are the vasopressors mixed adequately and in the correct dose?
Patient assessment
Do mentation and clinical appearance match the degree of hypotension?
Is the patient adequately volume resuscitated?
Does the patient have a pneumothorax after placement of central venous access?
Has the patient been adequately assessed for an occult penetrating injury?
Is there hidden bleeding from a ruptured spleen, large­vessel aneurysm, or ectopic pregnancy?
Does the patient have adrenal insufficiency?
Is the patient allergic to the medication just given or taken before arrival?
Is there cardiac tamponade in the dialysis patient or cancer patient?
Is there associated acute myocardial infarction, aortic dissection, or pulmonary embolus?
CONTROVERSIES OF TREATMENT
Fluid Therapy
Rapid restoration of fluid deficits modulates inflammation and, if the condition progresses to shock, decreases the need for subsequent vasopressor
,46 therapy, steroid administration, and invasive monitoring (e.g., pulmonary artery catheterization and arterial line placement). Although there is general agreement that volume therapy is an integral component of early resuscitation, there is a lack of consensus for the type of fluid, standards of
 50­ volume assessment, and end points despite care mandates that dictate otherwise. Table 12­6 compares the most commonly used fluid therapies.

TABLE 12­6
Fluid Therapy
Crystalloids
Normal Slightly hyperosmolar containing 154 mEq/L of both sodium and chloride.
saline (NS) Risk of inducing hyperchloremic metabolic acidosis when given in large amounts due to relatively high chloride concentration.
Lactated Sodium 130 mEq/L, potassium  mEq/L, calcium  mEq/L, chloride 109 mEq/L, lactate  mEq/L. Lactate can accept a proton and
Ringer’s (LR) subsequently be metabolized to carbon dioxide and water by the liver, leading to release of carbon dioxide in the lungs and excretion of water by the kidneys. LR results in a buffering of the acidemia that is advantageous over NS.
Theoretical risk of inducing hyperkalemia in patients with renal insufficiency or renal failure due to small potassium content (very small amount).
Plasma­Lyte® Balanced pH .4, sodium 140 mEq/L, chloride  mEq/L, potassium  mEq/L, magnesium  mEq/L, gluconate  mEq/L, acetate  mEq/L.
Colloids
Albumin Derived from human plasma.
Available in varying strengths from 4% to 25%.
Multiple studies have shown that there is no outcome difference whether colloids or crystalloids are used. Colloids cost significantly more than crystalloids. One study actually showed an increase in mortality in trauma patients with head injury.
Hydroxyethyl Synthetic colloid derived from hydrolyzed amylopectin.
starch These agents should be avoided in sepsis. Many harmful effects: renal impairment at recommended doses and impairment of longterm survival at high doses, coagulopathy and bleeding complications from reduced factor VIII and von Willebrand factor levels, impaired platelet function.
Colloids are high­molecular­weight solutions that increase plasma oncotic pressure. Colloids can be classified as either natural (albumin) or artificial
(starches, dextrans, and gelatins). Due to their higher molecular weight, colloids stay in the intravascular space significantly longer than crystalloids.
,50­54
The intravascular half­life of albumin is  hours versus  to  minutes for normal saline and lactated Ringer’s solution.
,49,50
Resuscitation with crystalloids requires two to four times more volume than colloids. The outcome advantage between crystalloid and colloids
,49­52 continues to remain unresolved in sepsis, despite multiple studies. Due to the equivalency and the higher cost of colloids, crystalloids would seem to be a better choice for resuscitation in the ED.
,36,55­58
Crystalloid type affects acid­base status and may have an effect on mortality, acute kidney injury, and the need for renal replacement therapy.
Two large, single­center, randomized controlled trials compared normal saline to balanced salt solutions (lactated Ringer’s or Plasma­Lyte®) in the resuscitation of patients in the ED prior to admission and found fewer major adverse events (persistent renal dysfunction, new renal replacement
,56 therapy, or mortality) in the balanced salt group. The difference favoring fewer adverse effects in the balance salt group was small (10.3% vs. .1%
,56 in those admitted to the intensive care unit and .7% vs. .6% in those admitted to the floor). Since then, a meta­analysis including those two studies, plus four prior randomized controlled trials, totaling ,332 patients, found no significant differences in the outcome measures of intensive
 care unit mortality, acute kidney injury, and new renal replacement therapy when comparing .9% normal saline to balanced salt solutions. Several
,60,61 ongoing randomized controlled trials comparing IV resuscitation fluids are pending completion. A randomized controlled trial of 157 patients receiving IV hydration with  L of .9% normal saline versus lactated Ringer’s solution before presumed discharge from ED found no difference in
  outcomes. The majority of the patients were healthy, with hypovolemia from vomiting or diarrhea. Most consistent in all the cited trials is a hyperchloremic acidosis associated with large­volume resuscitation with normal saline and, as of yet, no measured adverse effects of resuscitation with balanced salt solutions, despite a theoretical potential for metabolic alkalosis, hypotonicity from fluids with lactate, and cardiotoxicity from fluids
 with acetate.
Sodium Bicarbonate
Bicarbonate administration shifts the oxygen­hemoglobin dissociation curve to the left, impairs tissue unloading of hemoglobin­bound oxygen, and may worsen intracellular acidosis. However, despite no definitive clinical trials supporting benefit but perhaps harm, many clinicians remain
,65 uncomfortable withholding bicarbonate if the pH is <7.00. Animal studies of profound acidosis demonstrate decreased ventricular contractility
 and systolic blood pressure. If bicarbonate is given, recognize the risk of paradoxical intracerebral intracellular acidosis in the process. Consider situations, such as end­stage renal disease and renal tubular acidosis, that cannot reclaim bicarbonate through normal renal processes and whether bicarbonate may be indicated.
DISPOSITION
TRANSITION TO THE INTENSIVE CARE UNIT
Early recognition, treatment, and subsequent transfer of critically ill patients to the intensive care unit improves patient outcomes and improves ED
,47 throughput. Communicate and document all ED resuscitative efforts to the critical care team. Even when resuscitation is systematic and thoughtful, miscommunication can undo the benefits of initial ED treatment. Ideally, before transfer, verbally communicate and document a system­oriented problem list with an assessment and plan, including all procedures and complications. For prolonged or “boarded” ED stays, constantly reassess the critically ill patient, ensure that care plans are continuing, and consider creating a critical care patient checklist. Often, this will entail ordering tests that are not commonly performed on ED patients or ordering subsequent doses of medicines, particularly antibiotics.
PROGNOSIS
Some clinical variables are associated with poor outcome, such as severity of shock, temporal duration, underlying cause, preexisting vital organ dysfunction, and reversibility. Early recognition, intervention, source control, and smooth care transitions optimize outcomes. While associated morbidity and mortality remain high for patients with shock, integration of protocol­based care pathways with ongoing refinement in response to new
,28,34,47 information may lead to continued reductions over time. Additional outcome predictions related to physiologic scoring systems, ED­based
,66,67 shock interventions, and the balance between invasive and noninvasive or minimally invasive strategies are still being studied.


