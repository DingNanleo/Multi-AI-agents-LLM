## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 92: Acute Urinary Retention
David E. Manthey; David J. Story
INTRODUCTION AND EPIDEMIOLOGY
Acute urinary retention is a common painful urologic emergency characterized by an inability to pass urine, with lower abdominal distention or pain.
,2
Most patients with urinary retention are elderly men with benign prostatic hyperplasia. The incidence and risk of this etiology increase with age, with
 in  men in their 70s having an episode of acute urinary retention and  in  men having one in their 80s. There is a 20% recurrence rate within 
 months of an episode of urinary retention due to benign prostatic hyperplasia. Acute urinary retention in women is relatively uncommon, accounting for only  out of 100,000 cases of acute urinary retention each year, with the most common causes being bladder masses, gynecologic surgery, and
 pelvic prolapse.
PATHOPHYSIOLOGY
The voiding process, or micturition, involves the complex integration and coordination of high cortical neurologic (sympathetic, parasympathetic, and somatic) and muscular (detrusor and sphincter smooth muscle) functions. As the bladder fills, sensory input is transmitted to cortical centers in the brain, which responds by coordinating voluntary urination. The contraction of bladder detrusor muscle (by cholinergic muscarinic receptors) and relaxation of both the internal sphincter of the bladder neck and the urethral sphincter (through α­adrenergic inhibition) are both necessary for
 successful voiding. Continent urine storage in the bladder requires both relaxation of the detrusor muscle (through β­adrenergic stimulation and parasympathetic inhibition) and contraction of the bladder neck and internal sphincter (through α­adrenergic stimulation).
Urinary retention is the inability to void voluntarily despite a distended bladder resulting from dysfunction of the detrusor muscle and/or coordination of the bladder outlet. If extrinsic compression is the cause of the outlet obstruction (e.g., benign prostatic hyperplasia), the patient may report a history of a weakened urine stream despite forceful and prolonged detrusor contraction. In chronic decompensation of urination, diminished detrusor muscle contractility is more pronounced, with a large amount of residual urine volume, compared to acute decompensation. After prolonged complete
 bladder outlet obstruction, postobstructive acute kidney injury follows. Upon relief of prolonged obstruction, postobstructive diuresis occurs in .5%
 to 50% of acute urinary retention cases, depending on duration and comorbidities. This form of diuresis represents the normal physiologic response
 to excess volume and solutes accumulated during the period of prolonged obstruction. Absence of diuresis in patients with significant elevation in
 serum creatinine predicts poor kidney recovery.
CLINICAL FEATURES
The most common presentation is an elderly male with inability to void for several hours and lower abdominal distention or pain, secondary to benign prostatic hyperplasia. Consider urinary retention in patients complaining of lower abdominal pain, even if they do not offer urinary complaints. Also consider urinary retention as an underlying risk factor when finding a urinary tract infection.
The causes of urinary retention (Tables 92­1, 92­2, 92­3) are categorized into several domains: obstructive, neurogenic, traumatic, infectious,
,8­10 operative, psychogenic, structural anomalies, and pharmacologic. A detailed history and physical examination, especially the genitourinary and neurologic examination, supported by imaging, reveal the cause in the majority of patients.
TABLE 92­1
Gender­Specific Causes of Acute Urinary Obstruction

Men Women
Chapter 92: Acute Urinary Retention, David E. Manthey; David J. Story 
. Terms of Use * Privacy Policy * Notice * Accessibility
Obstructive Causes Obstructive Causes
Benign prostatic hypertrophy* Cystocele
Prostate cancer Ovarian tumor
Phimosis Uterine tumor
Paraphimosis
Operative Causes
Meatal stenosis
Incontinence surgery
Urethral strangulation
Infectious Causes
Infectious Causes
Pelvic inflammatory disease
Prostatitis
*Most common cause.
TABLE 92­2
Causes of Acute Urinary Retention in Both Sexes
Obstructive Causes Extraurinary Causes
Urethral stricture Perirectal or pelvic abscesses
Bladder calculi Rectal or retroperitoneal masses
Bladder neoplasm Fecal impaction
Foreign body, urethral or bladder Abdominal aortic aneurysm
Neurogenic Causes Psychogenic Causes
Multiple sclerosis Psychosexual stress
Parkinson’s disease Acute anxiety
Shy­Drager syndrome
Infectious Causes
Brain tumors
Cystitis
Cerebral vascular disease
Herpes simplex (genital)
Cauda equina syndrome
Herpes zoster involving pelvic region
Metastatic spinal cord lesions
Local abscess
Intervertebral disk herniation
Neuropathy (diabetes, other causes)
Operative Causes
Nerve injury from pelvic surgery
Postoperative bleeding (clots)
Postoperative retention
Epidural anesthesia
Traumatic Causes
Childhood Causes
Urethral injury
Posterior urethral valves
Bladder injury
Rhabdomyosarcoma of the bladder
Spinal cord injury
Urethral atresia
Pharmacologic Agents (Table 92­3)
TABLE 92­3
Pharmacologic Agents Associated With Urinary Retention
α­Adrenergic agents Carbamazepine
Amphetamines Decongestants
Androgens Estrogens
Anesthesia agents Hydralazine
Anticholinergics Muscle relaxants
Antihistamines NSAIDs
Antiparkinsonian agents Opiates
Antipsychotic agents Progesterone
Antispasmodics Selective serotonin reuptake inhibitors
Benzodiazepines Tetracyclic antidepressants
β­Adrenergic agents Tricyclic antidepressants
Calcium channel blockers
Assess for a history of prostatism, prostate or urinary bladder cancer, nephrolithiasis, indwelling urethral catheter or injury to urethra, prostate surgery, bladder prolapse, pelvic radiation therapy, or recent general or spinal anesthesia. Obtain a history regarding urinary urgency, frequency, or hesitancy; decreased force and caliber of stream; terminal dribbling; nocturia; and incontinence (typically due to overflow phenomena). Elicit a detailed neurologic history, looking for a causative lesion from high cortical function down to peripheral nerves that determine end­organ function.
Identify possible spinal cord injury by determining recent activities including any remote trauma. Inquire about Foley catheter insertion, cystoscopy, trauma, radiation therapy, or prior infection that may result in urethral stricture.
Review medication list for anticholinergic, sympathomimetic (common cold medications), nonsteroidal, and narcotic medications because these affect urinary flow via different mechanisms (Table 92­3).
Fever and hypotension are more suggestive of infection or sepsis than acute urinary retention. Alternatively, hypertension, tachycardia, and tachypnea may be pain related and may resolve after bladder decompression. On abdominal examination, palpitate or percuss from the epigastric area to the lower abdomen to identify a painful mass (distended bladder) in the lean patient. Examine the external genitalia to identify phimosis, paraphimosis, meatal stenosis or stricture, or evidence of urethral or penile trauma.
Perform digital rectal examination (either before or after relief of obstruction, depending on patient comfort) to evaluate the anal­rectal area and prostate, assessing anal tone, perineal sensation, prostate enlargement, stool impaction, or evidence of malignancy. A nodular or hard prostate may suggest prostate cancer, which need not be confirmed in the ED, but prompt follow­up should be recommended. Women with urinary retention should receive a pelvic examination to detect possible inflammatory lesions or pelvic or adnexal masses. Perform a neurologic examination to assess for a neurogenic cause. After successful drainage of the distended bladder, a repeat physical examination of the lower abdomen is indicated to evaluate for an unresolved extraurinary bladder problem (e.g., appendicitis) needing further management.
DIAGNOSIS
Bedside US can easily identify bladder distention. Measure bladder volume, and assess possible associated hydronephrosis. A urinalysis should be performed to assess for a urinary tract infection, which may be the cause or the result of the retention.
Beyond that, the need for further diagnostic tests will depend on the nature of the clinical presentation, precipitating factors, and the patient’s comorbidities. Gross hematuria may indicate infection, bladder calculi, or urinary tract neoplasm. Hematuria secondary to the physical trauma of catheter insertion that clears over time is common (see Chapter , “Urinary Tract Infections and Hematuria”). A CBC should be checked for patients with massive hematuria or in those presenting as septic. Prolonged obstruction may result in impaired renal function and electrolyte imbalance, so consider obtaining renal function studies and serum electrolytes in patients with prolonged retention, underlying risk factors for kidney injury
(diabetes, hypertension, prior renal insufficiency), or hydronephrosis on US. Formal abdominal CT may be indicated to identify pelvic or abdominal masses or bladder stones but is not routinely needed if symptoms resolve after catheter placement. Spinal imaging is needed if examination reveals concerns for cord compression or cauda equina.
TREATMENT
The goal of ED management is outlined in Table 92­4. Bladder decompression is most commonly by urethral or rarely by suprapubic catheterization.
Difficulty placing a urethral catheter in males can result from urethral stricture, prostatic enlargement, or postsurgical bladder neck contractures. If the patient recently underwent urologic surgery (e.g., radical prostatectomy or complex urethral reconstruction), consult the urologist before attempting catheter placement.
TABLE 92­4
Steps in Evaluation and Management of Acute Urinary Retention
Recognition Recognize a patient with possible acute urinary retention.
Initial Obtain complete history and physical examination to identify underlying diseases and precipitating factors: obstructive, pharmacologic, assessment infectious, neurogenic, traumatic, childhood, or psychogenic causes. Assess bladder volume with bedside US.
Initial Place a urethral or suprapubic catheter.
stabilization
Risk Assess for risk of recurrence, need for surgical intervention, and morbidity: age, severity of clinical presentation, causes, comorbidity, assessment prostate size, postvoid residual, and maximum urine flow rate.
Need for Admit for treatment of significant underlying medical illness or precipitating factors. Consider malignancy, spinal cord compression or inpatient injury, unresolved hematuria, or urinary tract infection with possible sepsis.
care
Need for Discuss with urology consultant in the event of urethral stricture, meatal stenosis, urethral injury, suspected prostate cancer, acute febrile urologic prostatitis, or urologic postoperative complications.
consultation
Outpatient Acute urinary retention without significant comorbidities and without evidence of complications, such as bleeding, infection, or renal management function impairment: discharge with Foley catheter, leg bag, and α­adrenergic receptor blocker (i.e., alfuzosin,  milligrams daily, or tamsulosin, .4 milligram daily), and follow up with urology in 3–7 d.
URETHRAL CATHETERIZATION TECHNIQUE
Most catheters are made of latex, but silicone catheters are available for patients with latex allergy. The retrograde injection of  to  mL of watersoluble anesthetic lubricant (e.g., 2% lidocaine jelly)  to  minutes before inserting the catheter can alleviate patient discomfort (Figure 92­1).
Retract the foreskin of an uncircumcised male when inserting the catheter, but remember to reduce the foreskin once the catheter is in place. Do not inflate the retention balloon until urine begins to flow through the catheter into the clear extension tube. Severe pain with catheter balloon inflation may indicate it was inflated prior to entering the bladder and could cause urethral damage, in addition to not effectively
 draining the bladder (Figure 92­2). Forceful attempts at catheter removal with the balloon still inflated can cause edema and tears to the urethra, so take care to adequately secure the catheter to the thigh after insertion.
FIGURE 92­1. Urethral catheter insertion. A. Insert the lubricated catheter into the urethra. B. Advance the catheter until the ports are at the meatus. C. Cross­section of the male pelvis showing the distal catheter and cuff positioned within the bladder. D. Urine aspiration confirms proper placement of the catheter. E.
If urine is flowing freely, inflate the balloon at the tip of the catheter. F. Gently withdraw the catheter to lodge the cuff against the bladder neck.
[Reproduced with permission from Reichman EF: Emergency Medicine Procedures, 3rd ed. New York, NY: McGraw­Hill Education; 2019.]
FIGURE 92­2. Foley catheter balloon inflated within the prostatic urethra. [Used with permission of Brady Pregerson, MD, and EMresource.org.]
If urethral catheterization using a standard 14F to 18F Foley catheter fails, passing a specialized coudé catheter can be attempted. A coudé catheter is firmer and has an angled tip, which should be pointed anteriorly during insertion, that more naturally follows the anatomy of the urethra as it courses through the prostate.
Unsuccessful passage of a Foley catheter may be the result of stricture, external urethral compression, kinking of the catheter within the urethra, or the creation of a false lumen, where the catheter tunnels through the urethral wall into the surrounding soft tissue. If catheterization produces gross blood and severe discomfort without returning urine, remove the catheter after ensuring the balloon is deflated. Do not attempt reinsertion because a false passage may have been produced. Urology should be immediately consulted to assess for urethral trauma and for assistance performing alternative methods of bladder decompression, such as passage of a urethral guidewire or flexible filiforms or suprapubic catheterization.
SUPRAPUBIC CATHETERIZATION TECHNIQUE
Suprapubic catheterization can be performed in patients after failure of urethral catheterization if there is no obvious pelvic trauma or abnormal anatomy in the lower abdomen. This may be the only option to decompress an extremely painful, distended bladder when urethral catheterization is
 not possible. US­guided suprapubic catheterization has a low complication rate.
Visualize the distended bladder with US and make sure no loops of bowel are present between the bladder and insertion site (Figure 92­3). The insertion site should be  to  cm superior to the pubic symphysis in the midline. Clean the area surrounding the insertion site with betadine or chlorhexidine and establish a sterile field. The skin and subcutaneous tract should be anesthetized by local infiltration. The needle should be advanced posteriorly and caudally at a 30­degree angle from true vertical (or  degrees from the horizontal plane of the abdomen). Alternatively, aspirate and inject anesthetic until you enter the bladder. Note needle direction and depth to bladder. A small skin incision may be necessary to facilitate passage of the catheter into the bladder. Both techniques described below should be performed with real­time US guidance.
FIGURE 92­3. US visualization of distended bladder. Make sure bladder measurement is at least  cm in two planes before attempting suprapubic aspiration. US visualization of the needle advancement into the bladder and return of urine indicate correct placement. [Reproduced with permission from Ma OJ,
Mateer JR, Blavais M: Emergency Ultrasound, 2nd ed. © 2008, McGraw­Hill, Inc., New York, NY.]
Obturator Technique
Insert the needle obturator into the urinary catheter and lock it into the port (Figure 92­4). The needle tip will be .5 mm beyond the end of the catheter. US visualization of the needle advancement into the bladder and return of urine indicate correct placement. After entering the bladder, advance the obturator/catheter system another  cm. Then unlock the obturator and advance the catheter an additional  cm before withdrawing the obturator needle, leaving the catheter in the bladder. Inflate the balloon and pull back on the catheter until slight resistance is met as the balloon engages with the anterior bladder wall.
FIGURE 92­4. The obturator technique. A. The obturator is within the catheter. The system is inserted  degrees to the skin and advanced into the bladder. B. The balloon is inflated. C. The obturator is removed while the catheter remains within the bladder. D. The collecting tube is attached to the catheter.
[Reproduced with permission from Reichman EF: Emergency Medicine Procedures, 3rd ed. New York, NY: McGraw­Hill Education; 2019.]
Peel­Away Sheath Technique
This technique uses the Seldinger technique for catheter insertion. Once placement of a finder needle in the bladder is confirmed by US and urine return, remove the syringe. Insert guidewire through the needle. Remove the needle, leaving the wire in the bladder. Advance the peel­away sheath over the guidewire into the bladder. Remove guidewire, and then insert the urinary catheter through the peel­away sheath. Inflate the catheter balloon once bladder placement is confirmed by urine return. Remove the peel­away sheath. Retract catheter until slight resistance is met as the balloon engages with the anterior bladder wall.
POSTCATHETERIZATION CARE
Reassess patients after urinary catheter insertion for resolution of symptoms. Patients with long­standing obstruction are at risk for postobstructive
  diuresis and postobstructive acute kidney injury, which are more common when large urine volumes are drained (800 to 1500 mL). Other risk factors for postobstructive diuresis include prior renal insufficiency, heart failure, altered mental status, and illness severity requiring intensive care unit
,7 admission. Monitor for  hours minimum for significant hourly urinary output (>200 mL/h over intake) after initial return. If this degree of output continues, admit the patient with volume replacement adjusted hourly according to urine output. Patients with significant elevations of BUN or creatinine should also be admitted; see Chapter , “Acute Kidney Injury.”
Routine use of antibiotics for the prevention of bacteriuria or for the treatment of asymptomatic bacteriuria is not suggested. Antibiotics are reserved
 for symptomatic urinary tract infection ; see Chapter , “Complications of Urologic Procedures and Devices.”
Pharmacologic therapy with α­adrenergic receptor antagonists, which exert effects on the bladder neck and prostate, may relax bladder smooth muscle, reducing outlet resistance to urinary flow (Table 92­4). Alfuzosin,  milligrams daily, and tamsulosin, .4 milligram daily, are possible agents
,15 to initiate that increase the success of spontaneous voiding after the catheter is removed. α­Adrenergic antagonism may also shorten the interval
 of time before a successful voiding trial and prevent recurrent episodes. Warn patients, especially the elderly, about possible postural hypotension that often accompanies use of these medications.
DISPOSITION AND FOLLOW­UP
Most patients with urinary retention are discharged home with a urinary catheter connected to a leg receptacle. Patients should be educated in Foley catheter care and bag drainage and given a list of concerning symptoms that should prompt a return to the ED. These include fever, persistent vomiting, abdominal pain, decreased urinary output, or penile pain. Penile pain suggests migration of the catheter balloon into the proximal urethra.
Feelings of urgency or bladder spasm can be treated with oxybutynin, .5 milligrams PO two or three times a day. However, oxybutynin has anticholinergic properties and can cause the same adverse effects as any anticholinergic agent, including urinary retention. There is no satisfactory treatment for urinary leakage around the Foley catheter. Placement of a larger catheter is not typically effective.
Patients presenting with urinary retention attributed to a pharmacologic or a postanesthesia cause may be candidates for a spontaneous voiding trial during the initial ED visit. If they are able to empty their bladder after catheter removal, discontinue the offending medications, if applicable, and discharge without further intervention. Inability to spontaneously void necessitates replacement of the Foley catheter. Urology follow­up is recommended within  to  days for a repeat voiding trial. A longer period of Foley drainage may be necessary in patients with retention volumes >1.3 L to improve chances of successful voiding.
SPECIAL CONSIDERATIONS
URINE LEAKAGE AROUND A SUPRAPUBIC CATHETER
Leakage of urine around an indwelling suprapubic catheter results in many difficulties for patients and caretakers. Some causes include bladder spasm; constipation, which can aggravate bladder spasms; infection; and urine calculi that cause catheter obstruction. Consult urology concerning choice of medication for spasms or about the use of fenestrated catheters as needed.
FEMALES WITH URINARY RETENTION
Urinary retention in women is uncommon. The obstructive causes of urinary retention in women are usually related to gynecologic problems (Table

92­1), but neurogenic causes can develop in both men and women.
The management of urinary retention in females involves catheterization and attending to any treatable cause. The ideal selection of catheterization method, including in and out catheterization, short­term indwelling urethral catheter followed by a trial of voiding, or clean intermittent selfcatheterization, depends on the clinical assessment of precipitating factors and underlying conditions. α­Adrenergic antagonists do not appear to be
 helpful in women with urinary retention. If there is no apparent cause, refer to a urologist for urodynamic studies.
GROSS HEMATURIA AND CLOT RETENTION
Gross hematuria can lead to clot formation within the bladder and acute urinary retention by obstructing outflow, resulting in pain, hypertension, and tachycardia from acute bladder distention. Management of gross hematuria includes placement of a 20F to 24F triple­lumen catheter (one port for
 urine drainage, one port for balloon inflation, and one port for bladder irrigation) and irrigation with saline until clear to ensure clot evacuation.
Hematuria catheters are also now available to allow for clot passage without obstructing the catheter. Patients with persistent clot burden may require admission, as obstruction may recur and require cystoscopic clot removal. Patients with gross hematuria from coagulopathy (i.e., warfarin) should have clotting parameters corrected as appropriate and be admitted.
POSTOPERATIVE URINARY RETENTION
Treatment is discussed in Chapter , “Complications of General Surgical Procedures.” For patients with retention after GU or pelvic procedures, consult with the operating surgeon. Otherwise, for patients with normal renal function and no obstruction, bladder catheterization to relieve symptoms and then removal of the catheter and a trial of voiding are usually all that is necessary.
Acknowledgment
The authors gratefully acknowledge the contributions of David Hung­Tsang and Yen Chen­Hsen Lee, the authors of the related chapter in the previous edition.


