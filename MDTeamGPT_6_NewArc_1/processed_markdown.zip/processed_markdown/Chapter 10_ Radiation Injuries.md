University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 10: Radiation Injuries
Annette M. Lopez; Jennifer A. Stephani
INTRODUCTION
Radiation exposures encountered in the ED setting may either be accidental or intentional. Accidental exposures can occur during transport, storage, or working with radioactive materials or with errors in dosing radiotherapy. Most civilian incidents involve industrial exposures from sealed radiation
 sources.
Historically, there have been multiple events that have resulted in radiation injuries. In August 1945, nuclear weapons were detonated over Hiroshima and Nagasaki, resulting in nearly 200,000 acute deaths and untold numbers of resulting injuries. The 2011 Fukushima Daiichi nuclear plant disaster
 involved about 1000 disaster­related deaths, although no deaths have yet been attributed to radiation injuries. The largest reported civilian accidental exposure took place in 1987 after a radiosource was left at an abandoned radiotherapy institute in Goiania, Brazil. Due to the source’s ability to glow in the dark, its contents were widely distributed, resulting in 112,000 individuals requiring evaluation, 249 contaminations,  individuals requiring
,4 hospital admissions, and four deaths. In 2006, Alexander Litvenko, a defected former KGB agent, suffered a protracted gastrointestinal illness associated with leukopenia after meeting with former colleagues. His death was ruled a murder after elevated levels of polonium­210 were identified.
Investigations into his murder revealed multiple rehearsals throughout England, leading to the contamination of multiple sites with potential
5­7 exposures to 1693 local and international individuals.
A potential intentional exposure involves the use of radiologic dispersal devices, or “dirty bombs,” that combine radioactive materials with conventional explosives. They are meant to cause injuries to those nearby, while generating massive panic and hysteria, overwhelming the local
 resources, damaging the local economy, and causing prolonged clean­up efforts.
FUNDAMENTALS OF RADIATION PHYSICS
Radiation energy includes the entire electromagnetic spectrum. Ionizing radiation contains enough energy to remove electrons from an atom, generating charged particles. Sources of ionizing radiation include alpha particles, beta particles, neutrons, and energy waves, including radiographs
 and gamma rays. Table 10­1 reviews the types of radiation.
TABLE 10­1
Types of Radiation
Type
Charge Penetration Shield Hazard Source
(Symbol)
Alpha +2 Few Paper, keratin layer Internal contamination only; Heavy radioisotopes (e.g., plutonium, centimeters in of skin requires special detection devices uranium, radon) air
Beta –1 ~8 mm into skin Clothing External (skin) and internal Most radioisotopes decay by beta contamination followed by gamma emission
Positron +1 ~8 mm into skin Lead, steel, or Interacts with electrons and releases Medical tracers concrete photons of energy

Chapter 10: Radiation Injuries, Annette M. Lopez; Jennifer A. Stephani 
©2025N MeuctGrornaw Hill. A0ll Rights RVaersiaebrlveed. TermMs aotfe Uriasle w * it hP hriivgahcy PolWichyo * le N­bootdicye ir r * a Adicactieonssibility Nuclear power plants, particle hydrogen content accelerators, weapons assembly plants
Gamma and  Several Concrete, lead Whole­body irradiation Most radioisotopes decay by beta radiograph centimeters in followed by gamma emission tissue
ALPHA PARTICLES
Alpha particles are relatively large in size (two protons and two neutrons), resulting in a limited travel potential and thus preventing penetration of the skin. Shielding is easily accomplished with a piece of paper. Pathology only develops through inhalation, ingestion, or absorption. Its detection can be
 challenging since a special Geiger counter attachment is needed.
BETA PARTICLES
Beta particles are much smaller (a single electron); thus, they have greater ability to travel and penetrate tissues. It is a significant hazard if internally
 deposited. It is a common exposure since most radioisotopes decay by beta radiation followed by gamma emission.
POSITRONS
Positrons are positively charged beta particles emitted from atomic nuclei. They are the antiparticles to an electron, and interactions with electrons
 lead to the generation of highly energetic photons requiring shielding with lead, steel, or concrete. Positron sources are commonly used in medicine.
NEUTRONS
Neutrons are uncharged particles that are able to generate radiation by altering the atomic nuclear proton­to­electron ratio. These particles are capable of traveling large distances; thus, shielding requires the use of helium, water, or paraffin. Exposures are rare and usually limited to nuclear
 fallout, research, industry, and weapons manufacturing.
GAMMA RAYS AND RADIOGRAPHS
Gamma rays and radiographs are able to travel meters in the air and can penetrate centimeters into human tissue. Shielding materials must be very
 dense (concrete or lead). Individuals exposed to high doses are at risk of developing acute radiation syndrome.
BIOLOGIC EFFECTS OF IONIZING RADIATION
Ionizing radiation leads to cellular effects at various levels of exposure. At high doses, ionizing radiation causes cell death, whereas at lower doses, it
 interrupts cellular reproduction through inhibition of mitosis, resulting in cellular injury with delayed onset of effects. Rapidly dividing cells with short
 life spans are the cells most vulnerable to radiation injury, because they are quickly depleted and new cells are unable to replete the population.
MEASURING RADIATION
There are many ways in which radiation can be measured: dose given, exposure received, absorbed dose, or activity generated. Each form of measurement generates its own unit, generating confusion between the units (Table 10­2).
TABLE 10­2
Radiation Units of Measure
Conventional
Description SI Unit Conversion
Units
Activity Curie Becquerel  Bq = ~2.7 ×
1011 Ci
Units of activity describe the amount of radioactivity present.  Ci = ~3.7 ×
1010 Bq
Exposure Roentgen Coulomb per  R = .58 × 104 kilogram cP/kg
Units of exposure measure the amount of radiographs or gamma radiation that produces a given number of ionizations in air.
Absorbed dose rad Gray  rad = .01 Gy
Units of absorbed dose can be applied to any type of radiation and reflect the energy  Gy = 100 rad imparted to matter.
Dose equivalent Roentgen Sievert  rem = .01 Sv equivalents man
Units that provide a common scale of measure for the different types of radiation.  Sv = 100 rem
Abbreviation: SI = International System of Units.
RADIATION MONITORING EQUIPMENT
Commonly used equipment includes dosimeters and survey meters (Table 10­3). During radiation emergencies, both of these devices should be used. Staff should wear dosimeters due to their small size and ability to measure and record cumulative exposure doses. In contrast, rate meters record the amount of radiation in an area over a particular time course and are suited to monitor environmental contamination.
TABLE 10­3
Radiation Monitoring Equipment
Equipment
Device Common Type of Measurement Units Commonly Recorded
Type
Dosimeter Thermoluminescent dosimeter or film Cumulative dose of beta, radiograph, and gamma Roentgen equivalents man or badge sieverts
Dosimeter Pocket dosimeter Cumulative exposure to radiogrpah and gamma Milliroentgen
Survey meter Geiger­Müller tube Low exposure rates of radiograph, gamma, and Counts per minute† beta* Survey meter Ion chamber Higher exposure rates of radiograph and gamma Milliroentgen per hour
* With special instrument probes, alpha radiation can also be detected.
†
2500 counts per minute equal approximately  mR/h.
ALLOWED ANNUAL DOSE OF RADIATION
Radiation exposures are an unavoidable hazard of living on our planet. The background radiation dose of individuals living in the United States is
 approximately .2 mSv (620 mrem). The U.S. Nuclear Regulatory Commission as well as other international regulatory agencies have accepted an annual radiation dose limit for the general public at  mSv per year (100 mrem) over natural background radiation. See Table 10­4 for selected approximate levels of radiation exposure.
TABLE 10­4
Selected Approximate Levels of Radiation Exposure
Natural background radiation 620 mrem/y (U.S. average)
Chest radiograph (effective dose)  mrem
Abdominal radiograph 120 mrem
Lumbar spine radiograph  mrem
CT head 200 mrem
CT chest 700 mrem
CT abdomen or pelvis 1000 mrem
Jet travel  mrem per 1000 miles traveled
Annual radiation dose limit (public) 100 mrem/y* Occupational exposure limit 5000 mrem/y
Lethal dose in 50% of exposed subjects within  d (3.5–4.5 Gy) 350,000–450,000 mrem (350–450 rad†)
* Over natural background radiation.
†
 rem (dose equivalent) =  rad (absorbed dose or exposure).
LETHAL DOSE OF RADIATION
The LD from exposure to ionizing radiation is defined as the dose of penetrating ionizing radiation that will result in the deaths (lethal dose) of 50% of the exposed population within  days without medical treatment. The most commonly cited human value is an LD of approximately 3.5 to 4.5 Gy (350 to 450 rad). The use of supportive medical therapy increases the value to .8 to .4 Gy (480 to 540 rad). During mass exposures, where resources may be limited, the LD falls to approximately .4 Gy (340 rad). Stem cell transplantation and the use of hematopoietic growth factors theoretically increases the LD to  Gy (1100 rad).

CLINICAL EFFECTS OF RADIATION
LOCAL RADIATION INJURY
Most radiation accidents are due to local radiation injury from partial­body exposure. This irradiation rarely causes systemic manifestations; rather, a dose­dependent cutaneous involvement is seen. Typically, these injuries tend to be asymptomatic in the first week, although, there may be transient erythema (6 Gy), hyperesthesia, and itching. Within the second week, erythema progresses to hair loss (3 Gy). Skin tenderness, swelling, and pruritus occur in the third week after exposure. Within the fourth week, the wound will develop dry (10 to  Gy) or wet (20 to  Gy) desquamation and
 radionecrosis with ulceration (>50 Gy).
These skin findings may be indistinguishable from thermal burns, except for the delayed onset of prolonged and severe pain. In exposures less than 
Gy (5000 rad), these injuries develop over a longer time period than thermal burns. At doses greater than  Gy, the onset of pain will occur
 immediately, and wounds will be indistinguishable from thermal burns. Surgical intervention, such as resection and grafting, may be required.
ACUTE RADIATION SYNDROME
Acute radiation syndrome occurs after a significant exposure (whole­body gamma dose exceeds  Gy) within a 24­hour time period (Table 10­5). It can also occur in the setting of neutron source exposure or internal contamination with alpha and/or beta radiation.
TABLE 10­5
Acute Radiation Syndrome
Approximate Onset of Duration of Latent
Manifest Illness
Dose Prodrome Phase
>2 Gy (200 rad) Within  d 1–3 wk Hematopoietic syndrome with pancytopenia, infection, and hemorrhage; survival possible
>6 Gy (600 rad) Within hours <1 wk GI syndrome with dehydration, electrolyte abnormalities, GI bleeding, and fulminant enterocolitis; death likely
>20–30 Gy (2000– Within minutes None Cardiovascular/CNS syndrome with refractory hypotension and circulatory collapse;
3000 rad) fatal within 24–72 h
Acute radiation syndrome develops in four distinct phases: prodrome, latent phase, manifest­illness, and recovery.
The prodrome involves a transient autonomic nervous system response to the exposure characterized by nausea, vomiting, anorexia, and diarrhea accompanied by hypotension, pyrexia, diaphoresis, cephalgia, and fatigue. It is directly related to the dose received: high doses cause acute and severe symptoms, whereas lower doses lead to milder symptoms and prolonged onset.
The latent phase follows and involves a symptom­free interval the duration of which depends on the received dose, with larger doses resulting in a shorter duration. Doses less than  Gy are associated with a period that may last  to  weeks, whereas with doses greater than  Gy, this phase may last only a few hours.
The manifest­illness phase is subdivided into three dose­dependent syndromes that are hallmarked by the affected organ system. They are not independent of one another and may overlap in clinical manifestations.
Hematopoietic Syndrome
With doses greater than  Gy, the hematopoietic system is the first affected organ system. The prodrome of this syndrome occurs within hours to a few
 days from the exposure, resolves within  hours, and is followed by a latent phase lasting  to  weeks.
Radiation damages the bone marrow stem cells, resulting in destruction of the circulating hematopoietic cells (Figure 10­1). Lymphocytes are preferentially destroyed. The peripheral lymphocyte count is the most readily available marker to grade the extent of the injury. Other cells lines are also affected. Since granulocytes and platelets are markers of inflammation, their counts initially rise following exposure, but reach a nadir within  days of the injury. Morbidity and mortality are dependent on the resulting pancytopenia, immunosuppression, and hemorrhage. Aggressive medical
 management with blood products and growth factors may increase survival.
FIGURE 10­1. Typical hematologic course and clinical stages after sublethal (~3 Gy/300 rad) exposure to total­body irradiation.
GI Syndrome
Doses greater than  Gy (>600 rad) are characterized by nausea, vomiting, and diarrhea within hours of exposure. A short latent phase lasting up to  week follows. A recrudescence of severe nausea, vomiting, diarrhea, and abdominal pain indicates the manifest illness phase that occurs after the failure to replenish the lost intestinal mucosa. Massive fluid and electrolyte shifts occur, as well as the translocation of enteric flora into the
 bloodstream, leading to the development of fulminant enterocolitis.
Neurovascular Syndrome
This occurs when doses exceed  Gy. It involves immediate persistent and intractable hypotension, prostration, nausea, vomiting, and explosive bloody diarrhea. CNS symptoms develop within hours and include seizures, lethargy, disorientation, ataxia, and tremors. The lymphocyte count
 quickly falls to near­zero levels, and death from circulatory collapse ensues within  to  hours.
If reached, the final stage of acute radiation syndrome is recovery.
EMERGENCY RESPONSE PLANNING
Emergency response plans should involve multiple community­wide organizations, including hospitals, EDs, and public safety, public health, and emergency management officials. Every EMS system should have a prehospital plan for the evacuation of victims from a radiation disaster. Every hospital is required by The Joint Commission to have a written protocol detailing instructions for receiving and treating radiation victims. Hospitals should stage regular disaster drills and train personnel in decontamination procedures, use of personal protective equipment, and radiologic
,14 monitoring. Planning templates exist to assist hospitals in developing appropriate radiation emergency response plans.
PREHOSPITAL EMERGENCY MEDICAL MANAGEMENT
Emergency responders should rapidly establish incident command in a situation involving radioactive materials. Personal protective equipment and respiratory protection should be used as the situation dictates. Care and transportation of seriously injured victims should not be delayed, even if the patient is contaminated. In medically stable patients, perform radiation monitoring and decontamination at the scene.
ED NOTIFICATION AND PREPARATION
First responders must communicate with hospitals prior to arrival to allow adequate preparation and provide incident information such as circumstances of the event, number of victims, traumatic injuries, type of radiologic insult, and identification of radioactive material. Extent of completed patient decontamination should also be relayed. The hospital disaster plan should include steps that need to be initiated by the ED upon notification to prepare for a radiologic event (Table 10­6).
TABLE 10­6
ED Preparation
Initiate hospital disaster plan
Mobilize hospital radiation experts (radiation safety officer, nuclear medicine and radiation oncology experts and staff).
Request dosimeters for staff and radiation monitoring and survey instruments.
Prepare the ED
Establish an ad hoc triage area based on the location designated in the hospital disaster plan.
Establish a “contaminated” area and “clean” area separated by a buffer zone using ropes, tape, and signs to designate areas.
Remove contaminated outer garments when leaving contaminated area and have your body surveyed with a radiation meter prior to leaving the area.
Cover floors with plastic or paper secured with heavy tape.
Remove pregnant women, nonessential personnel, and nonessential equipment.
Request extra gloves, other medical supplies, and extra large plastic bags for disposal.
Use standard precautions to protect staff
Staff should wear a water­resistant gown, cap, and shoe covers to keep contaminants off skin and clothes.
Double­glove with inner glove taped in place, changing the top pair after handling contaminated items and between patients.
N95 masks, if available, are recommended, but surgical masks should be adequate.
Survey hands and clothing at frequent intervals with a radiation meter.
Dosimeters, if available, should be worn at the collar, under protective clothing.
The hospital protocol should instruct ED personnel on how to contact predetermined local radiation specialists and health physics professionals.
These specialists may assist by monitoring radiation doses of personnel, surveying personnel and areas for contamination, directing contamination control and decontamination efforts, and disposing of contaminated wastes. If radiation monitors are not available, patients should undergo decontamination and then be surveyed for residual contamination when monitoring equipment is available.
TRIAGE PRINCIPLES
When there are multiple victims, field triage protocols will designate patients as minor, delayed, immediate, or deceased depending on physical trauma or burns. Do not alter triage principles based solely on radiation exposure. Because radioactive contamination is never immediately life­threatening, do not delay treatment of life­threatening injuries for radiologic surveying. Morbidity and mortality from ionizing radiation injuries increase dramatically in the face of physical trauma, thermal burns, and other significant medical conditions. In a mass­casualty event that could include blast injuries in addition to radiologic insult, resources may be limited and will require a coordinated approach to develop the
 best management plan.
TREATMENT
Because most radiation injuries are not immediately life­threatening, there is usually time to determine whether the patient was irradiated, externally contaminated, or internally contaminated. Early treatment decisions are based on biologic dosimetry, including the signs and symptoms evident in the
,16 first  to  hours and corresponding laboratory test results.
DECONTAMINATION OF EXTERNALLY CONTAMINATED PATIENTS
It is highly unlikely that the radioactivity from a contaminated patient would pose a significant risk to healthcare personnel. However, the goal of decontamination measures is to decrease total exposure of the patient and staff, by minimizing radiation exposure from a source external to the body to a level that is as low as reasonably achievable (Table 10­7). This is accomplished by minimizing time of exposure and the quantity of radioactive
,16 materials in the area, as well as maximizing distance and shielding from the source.
TABLE 10­7
Steps of Patient Decontamination
Assess external contamination
Contact radiation safety officer.
Assess contamination with radiation survey meter (Geiger counter).
Evaluate for radioactive shrapnel. Easily accessible pieces should be removed with a forceps and placed in a lead container.
Document contamination pattern on a body diagram.
Swab each nostril separately to estimate level of internal contamination of the lungs.
Decontaminate whole body
Carefully cut and roll clothing away from the face to contain contamination.
Double bag clothing and label as hazardous waste.
Wash wounds first with saline or water.
If facial contamination is present, rinse as appropriate.
Gently cleanse intact skin and avoid scrubbing.
Repeat patient scan with radiation survey meter. Repeat washing until radiation is <2 times background. Avoid scrubbing.
Cover wounds with waterproof dressing.
ACUTE RADIATION SYNDROME
Patients exposed to ionizing radiation but who are not internally or externally contaminated pose no risk to healthcare workers, and decontamination is not needed. Immediate treatment of the irradiated patient is directed toward alleviating the symptoms of the prodromal phase. Pain can be managed with acetaminophen and opioids. Because the patient may be at risk for significant GI bleeding if the exposure dose is more than  to  Gy,
  avoid using NSAIDs. Administer antiemetics for nausea and vomiting. Ondansetron or other 5­hydroxytryptamine­3 antagonists are effective. Use antidiarrheal agents such as loperamide as needed. Management of GI syndrome also includes use of a fluoroquinolone for  to  days after an acute
 exposure.
Perform a targeted history and physical exam. Note time of onset of all symptoms, especially vomiting and diarrhea, which are important in biologic dosimetry. Observe for abnormal vital signs suggestive of acute radiation syndrome, including fever, hypotension, tachycardia, and tachypnea.
Monitor for impaired level of consciousness, ataxia, motor or sensory deficits, reflex abnormalities or papilledema, abdominal tenderness, and GI bleeding.
Complete laboratory testing as soon as possible. Biologic dosimetry uses laboratory analyses (e.g., rate and nadir of lymphocyte depletion) and clinical signs to estimate absorbed dose. Cytogenetic analysis for chromosomal aberrations (dicentrics) is the gold standard for biodosimetry. Contact the

Radiation Emergency Assistance Center/Training Site for assistance with obtaining chromosomal testing.
Obtain a baseline CBC with differential and absolute lymphocyte count in the ED and check a CBC every  hours for  to  hours, monitoring for lymphocyte depletion. Also obtain a baseline serum amylase and C­reactive protein, because dose­dependent increases are expected after  hours in a significant exposure. If vomiting and diarrhea occur in the first  to  hours (dose estimated to >2 Gy), consider the need for human leukocyte antigen typing in anticipation of pancytopenia requiring further management. This could include administration of blood products, cytokines, colony­
 stimulating factors, bone marrow cells, or stem cell transplant. Consultation with a hematologist/oncologist is recommended.
Management of acute radiation syndrome is focused mainly on the support and recovery of the hematologic system, including bridging cytopenic gaps and managing subsequent infections. Patients may require prophylactic antibiotics, antifungals, and antivirals during their course or appropriate monotherapy for documented infections. Consultation of an infectious disease specialist is advised for management of radiation­induced
 neutropenia.
Monitor patients with large exposures who survive the acute phase for severe infectious and metabolic complications. Treat multiorgan failure from a
 large radiation exposure with standard supportive measures. Other management issues include maintaining strict environmental control and neutropenic precautions, minimizing invasive procedures, and early surgery and wound closure.
LOCAL RADIATION INJURY
Management of local radiation injury focuses on analgesia, meticulous wound care, and infection control. Analgesia is important in the early management of cutaneous radiation injury. Cutaneous radiation injury differs from thermal burns in that the cutaneous injury continues to evolve and may not be visible to the naked eye. The primary goal of treatment is interruption of radiation­induced inflammation in the dermis. Perform traditional burn care, including burn dressings, surgical debridement, and skin grafting, when indicated. Consider applying topical steroids such as betamethasone to control local inflammation, giving vitamin A, C, and E supplementation, and administering pentoxifylline to decrease blood viscosity
,19 and increase blood flow. Silver­based creams such as sulfadiazine can be used. Hyperbaric oxygen may be considered. Systemic steroids are not
 recommended. Although inpatient treatment may not always be required, close follow­up is essential given the potential for ongoing evolution of cutaneous injury.
INTERNALLY CONTAMINATED PATIENTS
Internal contamination generally does not produce early symptoms but should be considered if persistently high radiation survey readings are noted and with all nose or mouth contamination cases. Obtain a 24­hour urine collection for possible radionuclide identification. Collect other specimens depending on exposure with or without contamination (Table 10­8). Consult radiation experts for treatment with cathartics, activated charcoal, gastric lavage, and radionuclide­specific decorporation agents (Table 10­9). Duration of therapy is based on dose estimations from radiochemical measurements of urine and fecal samples.
TABLE 10­8
Specimens for Medical Assessment
Specimen/Type of Analysis Reason Mechanism
Suspected radiation exposure
Check a CBC every  h for 24–48 h Establish baseline and assess lymphocyte Venipuncture depletion as an early predictor of dose.
Serum amylase and CRP, repeat Parotid glands are sensitive to radiation; amylase Venipuncture daily for  d will rise if exposed to >0.5 Gy.
Blood: chromosomal analysis Gold standard for estimating dose. Venipuncture. Call REAC/TS for assistance.
(dicentrics)
Urine: routine urinalysis Establish baseline kidney function, especially if Clean catch internal contamination is suspected.
Suspected external contamination
Swabs of body orifices and samples Assess internal contamination and identify Use separate saline or water­moistened swabs to wipe the from dressings/wounds radionuclide. inside of each nostril, ear, and mouth.
Suspected internal contamination
Urine bioassay: 24­h specimen; Radionuclide identification Standard specimen containers repeat for  d
Consider feces bioassay in consult with radiation expert
Abbreviations: CRP = C­reactive protein; REAC/TS = Radiation Emergency Assistance Center/Training Site.
TABLE 10­9
Internal Contamination Treatment
Ionizing Mechanism of
Radionuclide Treatment Usual Administration
Radiation Action
Iodine β, γ Potassium iodide Block thyroid uptake 130 milligrams PO for adults
(I­131)
Plutonium α Ca­DTPA or Zn­ Chelation  gram in 250 mL NS or 5% dextrose in water over  min
(Pu­239) DTPA
Tritium β Water Dilution Oral: 3–4 L a day for  wk
(H­3)
Cesium β, γ Prussian blue Decrease GI uptake  gram in 100–200 mL water three times a day for several
(Cs­137) days
Uranium α Bicarbonate Urine alkalinization  ampules in  L NS at 125 mL/h
(U­235)
Abbreviations: DTPA = diethylenetriamine pentaacetate; NS = normal saline.
PRENATAL EXPOSURES
Fetal sensitivity to radiation depends on a number of factors, including radiation dose and gestational age. The radiation dose to the fetus may not be the same as the dose to the mother, because the fetus is shielded in part by the uterus and surrounding tissues. External exposure of alpha and beta particles is unlikely to reach the fetus, but gamma and radiographs directed toward a pregnant woman’s abdomen could harm the fetus. In addition, internal contamination could expose the fetus to higher radiation, as the radioactive material could accumulate in the bladder of the pregnant woman.
The health effects of radiation on the fetus are dependent on the gestational age. Before about  weeks of gestation, there is an all­or­none phenomenon, and if the exposure does not result in death of the embryo, no observable effects are expected. An exposure of greater than .1 Gy is expected to be lethal, resulting in resorption of the conceptus. From  to  weeks, organogenesis occurs. During this time, the embryo is at risk for congenital malformations and growth retardation. In cases of substantial exposures, there is a significant risk of major malformations of the neurologic and motor systems. After  weeks of gestation, exposures are associated with an increased risk of mental retardation and miscarriage.

Throughout gestation, an exposure of less than .05 Gy would not be expected to produce an increased risk of noncancer health effects. Consult with
 radiation medicine physicians regarding fetal dose estimation and risk assessment counseling for the expecting parents. For additional discussion, see Chapter , “Comorbid Disorders in Pregnancy.”
SOURCES OF ASSISTANCE
Two organizations provide medical advice for the treatment of radiation casualties. The Radiation Emergency Assistance Center/Training Site, sponsored by the Department of Energy and managed by the Oak Ridge Institute for Science and Education, provides training programs, consultation assistance, and treatment capabilities, and can dispatch an emergency response team of health professionals to assist at an accident site. After initial treatment and decontamination actions are complete, REAC/TS may also accept severely contaminated or irradiated patients for transfer to its facilities for more definitive care.
Radiation Emergency Assistance Center/Training Site (REAC/TS)
Oak Ridge Institute for Science and Education
P.O. Box 117, MS , Oak Ridge, TN 37831­0117
865­576­3131 (daytime phone; ask for REAC/TS)
865­576­1005 (24­hour emergency number)
Another organization available for consultation is the Medical Radiobiology Advisory Team, sponsored by the Department of Defense and managed by the Armed Forces Radiobiology Research Institute.
Medical Radiobiology Advisory Team
Armed Forces Radiobiology Research Institute
National Naval Medical Center
8901 Wisconsin Avenue, Building 
Bethesda, MD 20889­5603
301­295­0316
301­295­0530 (24­hour emergency number)
The U.S. Department of Health and Human Services sponsors the Radiation Emergency Medical Management Guidance on Diagnosis and Treatment for Health Care Providers. Information can be found at http://www.remm.nlm.gov.


