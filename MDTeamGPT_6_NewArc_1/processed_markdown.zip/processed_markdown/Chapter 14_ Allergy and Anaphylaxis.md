University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 14: Allergy and Anaphylaxis
Brian H. Rowe; Brian Grunau
INTRODUCTION
Content Update: Fresh Frozen Plasma for Angioedema January 2021
Table 14­6 has been corrected to include Fresh Frozen plasma as a treatment.
Content Update: tPA­induced Angioedema November 2020
Orolingual angioedema is a rare but well­documented adverse effect of tPA administration. Clinical features and treatment are discussed in this chapter, in the section in Angioedema; and in Chapter 167, under Monitoring and Complications in the section ‘Thrombolysis: Indications,
Exclusions, Dosage, Monitoring, and Complications. There is no evidence for treating tPA­induced angioedema with TXA (tranexamic acid).
Content Update: TXA for ACE­Inhibitor­ induced angioedema april 2020
Tranexamic acid (TXA) is a readily available, safe, and cost­effective therapy for acute trauma and bleeding. It has been used in ACE­Inhibitorinduced angioedema and idiopathic angioedema, and is recommended by some authors (1). The mechanism of action is unknown, but it may prevent the plasmin­dependent formation of bradykinin (2) No randomized controlled trials are available (3), but weak evidence from observational studies suggests that TXA can be an alternative strategy for ACEI or idiopathic angioedema. The effectiveness of TXA in hereditary Cl inhibitordeficiency angioedema is not as compelling as for ACEI angioedema (4,5) For a potential airway emergency, the dose is  gram IV. See Table 14­6. 1) van den Elzen M et al ‘Efficacy of treatment of non­hereditary angioedema.’ Clin Rev Allergy Immunol 2018:54 (3):412­431 PMID 276720782)
2) Sheffer AL et al ‘Tranexamic acid therapy in hereditary angioneurotic edema’ NEnglJMed 1972; 287:452­454
3) Beauchene C et al ‘TXA as first line emergency treatment for episodes of bradykinin­mediated angioedema induced by ACE inhibitors’ Rev Med
Interne 2018; 39(10):772­776 Doi .1016/j.revmed.2018.04.014
4) Zanichelli A et al ‘Standard care impact on angioedema because of hereditary C1 Inhibitor Deficiency: a 21­month prospective study in a sohort of
103 patients’ Allergy 2011; 66:192­96 PMID 21039598
5) Horiuchi T et al ‘The use of tranexamic acid for on­demand and prophylactic treatment of hereditary angioedema­A Systematic Review’ J
CutanImmunolAllergy. 2018; 1:126­138
ANAPHYLAXIS
INTRODUCTION
Anaphylaxis is a serious allergic reaction, with a rapid onset; it may cause death and requires emergent diagnosis and treatment. Consensus clinical
1–3 criteria provide consistency for diagnosis (Table 14­1).

Chapter 14: Allergy and Anaphylaxis, Brian H. Rowe; Brian Grunau 
TABLE 14­1
. Terms of Use * Privacy Policy * Notice * Accessibility
Clinical Criteria for Anaphylaxis
Urticaria, generalized itching or flushing, or edema of lips, tongue, uvula, or skin developing over minutes to hours and associated with at least  of the following:
Respiratory distress or hypoxia or
Hypotension or cardiovascular collapse or
Associated symptoms of organ dysfunction (e.g., hypotonia, syncope, incontinence)
Two or more signs or symptoms that occur minutes to hours after allergen exposure:
Skin and/or mucosal involvement
Respiratory compromise
Hypotension or associated symptoms
Persistent GI cramps or vomiting
Consider anaphylaxis when patients are exposed to a known allergen and develop hypotension
The terms anaphylactic and anaphylactoid were previously applied to immunoglobulin E (IgE)­dependent and IgE­independent events, respectively.

Because the final pathway in both events is identical, anaphylaxis is the term now used to refer to both. Hypersensitivity is an inappropriate immune response to generally harmless antigens, representing a continuum from minor to severe manifestations. Anaphylaxis represents the most dramatic and severe form of immediate hypersensitivity.
Foods, medications, insect stings, and allergen immunotherapy injections are the most common provoking factors for anaphylaxis, but any agent
,6 capable of producing a sudden degranulation of mast cells or basophils can induce anaphylaxis (Table 14­2). Latex hypersensitivity is increasing in prevalence in the general population, with a resultant risk for anaphylaxis. In addition, a significant number of anaphylaxis cases have no identified
 cause, termed idiopathic anaphylaxis. The lifetime individual risk of anaphylaxis is estimated to be 1% to 3%, but the prevalence of anaphylaxis may
  ,11 be increasing. Although allergic reactions are a common cause for ED visits, anaphylaxis is likely underdiagnosed.
TABLE 14­2
Common Causes for Anaphylaxis, Anaphylactoid, and Allergic Reactions
Drugs Foods and Additives
β­Lactam antibiotics Shellfish
Acetylsalicylic acid (ASA) Soybeans
Trimethoprim­sulfamethoxazole Nuts (peanuts and tree nuts)
Vancomycin Wheat
NSAIDs Milk
Virtually any drug Eggs
Salicylates
Others
Seeds
Hymenoptera stings
Sulfites
Insect parts
Mammalian meat (galactose­alpha­1,3­galactose [alpha­gal])
Molds
Radiographic contrast material
Vaccines
Latex
Blood products
PATHOPHYSIOLOGY
Anaphylaxis, for the most part, arises from the activation of mast cells and basophils through a mechanism involving crosslinking of IgE and
 aggregation of the high­affinity receptors for IgE. Upon activation, mast cells and/or basophils quickly release preformed mediators from secretory granules that include histamine, tryptase, carboxypeptidase A, and proteoglycans. Downstream activation of phospholipase A , followed by
 cyclooxygenases and lipoxygenases, produces arachidonic acid metabolites, including prostaglandins, leukotrienes, and platelet­activating factor. The inflammatory cytokine, tumor necrosis factor­α, is released as a preformed mediator and also as a late­phase mediator with other cytokines and chemokines.
These mediators are responsible for the pathophysiology of anaphylaxis. Histamine stimulates vasodilation and increases vascular permeability, heart rate, cardiac contraction, and glandular secretion. Prostaglandin D is a bronchoconstrictor, pulmonary and coronary vasoconstrictor, and peripheral
 vasodilator. Leukotrienes produce bronchoconstriction, increase vascular permeability, and promote airway remodeling. Platelet­activating factor is also a potent bronchoconstrictor and increases vascular permeability. Tumor necrosis factor­α activates neutrophils, recruits other effector cells, and
 enhances chemokine synthesis. These overlapping and synergistic physiologic effects contribute to the overall pathophysiology of anaphylaxis.
CLINICAL FEATURES
The classic presentation of anaphylaxis begins with pruritus, cutaneous flushing, and urticaria. These symptoms are followed by a sense of fullness in the throat, anxiety, a sensation of chest tightness, shortness of breath, and lightheadedness. A complaint of a “lump in the throat” and hoarseness heralds life­threatening laryngeal edema in a patient with symptoms of anaphylaxis. These major symptoms may be accompanied by abdominal pain or cramping, nausea, vomiting, diarrhea, bronchospasm, rhinorrhea, conjunctivitis, and/or hypotension. As the cascade progresses, respiratory distress, decreased level of consciousness, and circulatory collapse may ensue. In severe cases, loss of consciousness and cardiorespiratory arrest may result.
In most patients, signs and symptoms begin suddenly, often immediately and usually within  minutes of exposure. In general, the faster the onset of symptoms, the more severe the reaction—one half of anaphylactic fatalities occur within the first hour. After the initial signs and symptoms abate, patients are at a small risk for a recurrence of symptoms caused by a second phase of mediator release, peaking  to  hours after the initial exposure and manifesting symptoms and signs  to  hours after the initial clinical manifestations have cleared. The late­phase allergic reaction is primarily mediated by the release of newly generated cysteinyl leukotrienes, the former slow­reacting substance of anaphylaxis. The incidence of this biphasic phenomenon has been reported to vary widely up to 20%; however, prospective studies specifically searching for clinically important biphasic
,13 events report a much lower incidence (4% to 5%).
DIAGNOSIS
The diagnosis of anaphylaxis is clinical. Consider anaphylaxis when involvement of any two or more body systems is observed, with or without
,15 hypotension or airway compromise (Table 14­3). The diagnosis is easily made if there is a clear history of exposure, such as a bee sting, shortly followed by the multisystem signs and symptoms described earlier. Unfortunately, the diagnosis is not always easy or clear, because symptom onset may be delayed, symptoms may mimic other presentations (e.g., syncope, gastroenteritis, anxiety), or anaphylaxis may be a component of other diseases (e.g., asthma).
TABLE 14­3
Clinical Manifestations of Anaphylaxis
System Signs and Symptoms (approximate incidence)
ENT Oropharyngeal or throat fullness (50%)
Tongue swelling (1%–2%)
Uvular edema/hydrops (1%–5%)
Respiratory Shortness of breath and/or wheezing (45%–50%)
Pharyngeal or laryngeal edema (50%–60%)
Stridor (rare)
Rhinitis (30%–35%)
Cardiovascular Hypotension (30%–35%)
Chest pain (4%–5%)
Skin Urticaria and/or angioedema (60%–90%)
Flushing (45%–55%)
Pruritus only (2%–5%)
GI Nausea, emesis, cramps, or diarrhea (25%–30%)
Neurologic Headache (5%–8%)
Seizure (1%–2%)
Abbreviation: ENT = ear, nose, and throat; GI = gastrointestinal.
The differential diagnosis of anaphylactic reactions is extensive, including vasovagal reactions, myocardial ischemia, dysrhythmias, severe acute asthma, seizure, epiglottitis, hereditary angioedema, foreign body airway obstruction, carcinoid, mastocytosis, vocal cord dysfunction, and non–IgE­ mediated drug reactions. The most common anaphylaxis imitator is a vasovagal reaction, which is characterized by hypotension, pallor, bradycardia, diaphoresis, and weakness, and sometimes by loss of consciousness.

Laboratory investigations are of minimal utility and should be limited in the ED setting. Serum histamine levels, elevated for  to  minutes after reaction, are unhelpful because they are typically normal upon ED presentation. Tryptase is a neutral protease of unknown function in anaphylaxis that is found only in mast cell granules and is released with degranulation. Serum tryptase levels are elevated for several hours and have been proposed for later confirmation of a suspected anaphylactic episode. This test, however, has poor sensitivity; about one third of patients with an acute
 anaphylaxis episode have a normal serum tryptase level upon ED arrival, and some patients experience severe anaphylaxis without elevated tryptase
 levels.
TREATMENT

Triage for all acute allergic reactions should be at the highest level of urgency because of the possibility of sudden deterioration. Current treatment
,19–21 recommendations are derived from the clinical experience of experts as professed in consensus statements and guidelines.
FIRST­LINE THERAPY
Emergency management starts with assessment of airway, breathing, and circulation. Assess vital signs and pulse oximetry. Initiate IV access, oxygen administration, and cardiac rhythm monitoring in patients with severe symptoms. The first­line therapies for anaphylaxis (airway protection, oxygen,
20–23 decontamination, epinephrine, IV crystalloids) have immediate effect during the acute stage.
Airway and Oxygenation
In severe anaphylaxis, securing the airway is the first priority. Examine the mouth, pharynx, and neck for signs and symptoms of angioedema: uvula edema or hydrops, audible stridor, respiratory distress, or hypoxia. If angioedema is producing respiratory distress, intubate early, since any delay may result in complete airway obstruction secondary to progression of angioedema. Provide supplemental oxygen to maintain arterial oxygen saturation >90%.
Decontamination
If the causative agent can be identified, termination of exposure should be attempted. Gastric lavage is not recommended for foodborne allergens and may be associated with complications (i.e., aspiration) and delays in the administration of more effective treatments (e.g., epinephrine). In insect stings, remove any remaining stinging remnants because the stinger continues to inject venom even if it is detached from the insect (see Chapter 211,
“Bites and Stings”).
Epinephrine
Epinephrine (adrenaline) is a mixed α ­ and β­receptor agent. The α ­receptor activation reduces mucosal edema and treats hypotension, β ­receptor
   stimulation increases heart rate and myocardial contractility, and β ­receptor stimulation provides bronchodilation and limits further mediator

 ,19,24,25 release. Epinephrine is the treatment of choice for anaphylaxis. However, observational studies indicate that it is
,11 underused, often dosed suboptimally, and underprescribed upon discharge for potential future self­administration. Most of the reasons proposed to withhold epinephrine are flawed, and the therapeutic benefits of epinephrine exceed the risk when given in appropriate routes
 and doses, even in elderly patients.

In patients without signs of cardiovascular compromise or collapse, administer epinephrine IM (Table 14­4). Repeat every  to  minutes according to response or if relapse occurs. Injections into the thigh are more effective at achieving peak blood levels than injections into the
 deltoid area. Intramuscular dosing is recommended because it provides higher, more consistent, and more rapid peak blood epinephrine levels than
,27
SC administration. For convenience and accurate dosing, many EDs have adopted the use of epinephrine autoinjectors, such as EpiPen® (0.3 milligrams of epinephrine for adults; Dey, L.P., Napa, CA) and EpiPen Junior® (0.15 milligrams of epinephrine for children <30 kg; Dey, L.P.); however, recent shortages in production have demonstrated the need for multiple sources of the drug. Some evidence suggests that expired epinephrine
 autoinjectors retain potency many months to years after their expiration date. While retaining an expired EpiPen® may be a reasonable safety strategy for patients, it does not negate the need for a new prescription.
TABLE 14­4
Drug Treatment of Anaphylaxis and Allergic Reactions
Drug Adult Dose Pediatric Dose
First­Line Therapy
Epinephrine IM: .3–0.5 milligram (0.3–0.5 mL of 1:1000 dilution); or EpiPen® IM: .01 milligram/kg (0.01 mL/kg of 1:1000 dilution) or EpiPen
### .3 milligram epinephrine (or equivalent preformulated Junior® .15 milligram of epinephrine (or equivalent product) preformulated product)
IV bolus: 100 micrograms over 5–10 min; mix .1 milligram (0.1 mL of 1:1000 dilution) in  mL NS and infuse over 5–10 min
IV infusion: start at  microgram/min; mix  milligram (1 mL of IV infusion: .1–0.3 microgram/kg per min; titrate dose as
1:1000 dilution) in 500 mL NS and infuse at .5 mL/min; titrate needed; maximum, .5 micrograms/kg per min dose as needed
Oxygen Titrate to SaO ≥90% Titrate to SaO ≥90%

IV fluids: NS or LR 1–2 L bolus 10–20 mL/kg bolus
Second­Line Therapy
H Blockers

Diphenhydramine 25–50 milligrams IV, IM, or PO every  h  milligram/kg IV, IM, or PO every  h
H Blockers

Ranitidine  milligrams IV over  min .5 milligram/kg IV over  min
Cimetidine 300 milligrams IV 4–8 milligrams/kg IV
Corticosteroids
Hydrocortisone 250–500 milligrams IV 5–10 milligrams/kg IV (maximum, 500 milligrams)
Methylprednisolone 80–125 milligrams IV 1–2 milligrams/kg IV (maximum, 125 milligrams)
Prednisone 40–60 milligrams PO daily or 20–30 milligrams PO twice daily  milligram/kg/ PO daily as single morning dose, maximum,  milligrams
To be used after initial IV dose (for outpatients: 3–5 d; tapering To be used after initial IV dose (for outpatients: 3–5 d; tapering not required) not required)
Treatment of Bronchospasm, Add:
Albuterol Single treatment: .5–5.0 milligrams nebulized (0.5–1.0 mL of Single treatment: .25–2.5 milligrams nebulized (0.25–0.5 mL of
(salbutamol) .5% solution) .5% solution)
4–6 puffs from MDI with holding chamber 4–6 puffs from MDI with holding chamber
Both repeated every  min as needed Both repeated every  min as needed
Continuous nebulization: 5–10 milligrams/h Continuous nebulization: 3–5 milligrams/h
Ipratropium Single treatment: 250–500 micrograms nebulized Single treatment: 125–250 micrograms nebulized bromide
4–6 puffs from MDI with holding chamber 4–6 puffs from MDI with holding chamber
Both repeated every  min as needed Both repeated every  min as needed
Magnesium sulfate  grams IV over  min 25–50 milligrams/kg IV over  min
Treatment for Patients on β­Blockers with Refractory Hypotension, Add:
Glucagon  milligram IV every  min until hypotension resolves, followed  micrograms/kg IV every  min by 5–15 micrograms/min infusion
Abbreviations: H = histamine­1; H = histamine­2; LR = lactated Ringer’s; MDI = metered­dose inhaler; NS = normal saline; SaO = arterial oxygen saturation.

Most patients with anaphylaxis need only a single dose of epinephrine IM. Blood pressure should be checked in patients taking β­blockers, because epinephrine use may result in severe hypertension secondary to unopposed α­adrenergic stimulation. Age is not a barrier to epinephrine IM injections in patients with anaphylaxis.
If the patient is refractory to treatment despite repeated doses of epinephrine IM or has signs of cardiovascular compromise or collapse, then an epinephrine IV bolus and/or infusion should be instituted. The initial epinephrine IV bolus is a dilute solution of 100 micrograms (0.1 milligram) IV, given over  to  minutes.
If the patient is refractory to the initial bolus, institute an epinephrine IV infusion, starting at  microgram/min and titrating to effect. There is a higher
 risk of cardiovascular complications when epinephrine IV is used to treat anaphylaxis. It should be stressed that the initial IV bolus dose is very dilute, is given over  to  minutes, and should be stopped immediately if dysrhythmias or chest pain occur.
IV Crystalloids

Hypotension is generally the result of distributive shock and responds well to fluid resuscitation. A bolus of  to  L (10 to  mL/kg in children) of isotonic crystalloid solution should be administered concurrently with epinephrine. There is no evidence that albumin or hypertonic saline should
 replace crystalloids.
SECOND­LINE THERAPY
,19–21
The second­line anaphylaxis treatments include corticosteroids, antihistamines, inhaled bronchodilators, vasopressors, and glucagon. These
 drugs are used to treat anaphylaxis refractory to the first­line treatments or associated with complications and also to prevent recurrences.
Corticosteroids
Patients with anaphylaxis often receive corticosteroids to prevent protracted and biphasic reactions, although evidence for clinical benefit is scant and
19–21,23,31–33 primarily derived from acute asthma studies. Methylprednisolone,  to 125 milligrams IV (2 milligrams/kg in children; up to 125 milligrams), and hydrocortisone, 250 to 500 milligrams IV (5 to  milligrams/kg in children; up to 500 milligrams), are equally effective. The mineralocorticoid effects of corticosteroids are ranked in declining order. Hydrocortisone and cortisone have the strongest effects, followed by prednisone. Methylprednisolone and dexamethasone have the lowest mineralocorticoid effect and produce less fluid retention than hydrocortisone and cortisone and thus are preferred for the elderly and for those in whom fluid retention would be problematic.
Antihistamines
Consensus guidelines recommend that most patients with anaphylaxis should receive an H antihistamine, such as diphenhydramine,  to 

,19–21,23  milligrams IV by slow infusion or via IM injection, although clinical benefit is unproven. In severe cases, especially with circulatory shock,
19–21,23  guidelines recommend H antihistamines, such as ranitidine or cimetidine, although evidence for benefit is lacking. Cimetidine should not be
 used for patients who are elderly (side effects), have multiple comorbidities (interference with metabolism of many drugs), have renal or hepatic impairment, or whose anaphylaxis is complicated by β­blocker use (cimetidine prolongs metabolism of β­blockers and may prolong anaphylactic state). After the initial IV dose of corticosteroids and antihistamines, the patient may be switched to oral administration (Table 14­4).
Vasopressors
In patients with anaphylaxis and shock resistant to initial treatment, including repeated doses of IM epinephrine, oxygen, and IV crystalloids, initiate IV epinephrine infusion. If dangerous dysrhythmias or tachycardia result from epinephrine, other agents (e.g., dopamine, dobutamine, epinephrine,
,19–21 norepinephrine, phenylephrine, or vasopressin) may be effective, and superiority from a specific agent has not been demonstrated. Clinicians should use the agent they feel most comfortable with and titrate according to the clinical response.
AGENTS FOR ALLERGIC BRONCHOSPASM
A β bronchodilator, such as intermittent or continuous nebulized albuterol/salbutamol, should be instituted if wheezing is present. Asthmatics are
 often more refractory to the treatment of allergic bronchospasm. For severe bronchospasm refractory to inhaled albuterol/salbutamol, inhaled
,36 anticholinergics and IV magnesium sulfate can be added (Table 14­4). Bronchodilators should be given at a lower dose and at a slower rate in elderly patients. IV aminophylline is not recommended. Leukotriene receptor antagonists are not effective for the treatment of anaphylaxis.
GLUCAGON
Concurrent use of β­blockers is a risk factor for severe prolonged anaphylaxis. For patients taking β­blockers with hypotension refractory to fluids and
,19–21 epinephrine, glucagon IV should be used every  minutes until hypotension resolves, followed by an infusion (Table 14­4). The side effects of glucagon include nausea, vomiting, hypokalemia, dizziness, and hyperglycemia.
DISPOSITION AND FOLLOW­UP
,13
With appropriate initial treatment, admission to hospital is rare, only required in about 1% to 4% of acute allergic reactions treated in the ED. All unstable patients with anaphylaxis refractory to treatment or in whom airway interventions were required should be admitted to the intensive care
,13 unit. While patients who receive epinephrine IM should be observed in the ED, the precise duration of observation is unclear. Otherwise healthy patients who remain symptom free for one or  hours after appropriate treatment can be discharged home with less than 5% or 3% incidence,
 respectively of a biphasic reaction.
Consider prolonged observation in patients with a past history of severe reaction and those using β­blockers. Although the risk of important biphasic
 reactions after ED discharge is low, patients who live alone, reside long distances from medical care, have significant comorbidity (including but not limited to asthma), or are elderly should be observed longer before discharge.
Patients with severe allergic reactions or anaphylaxis are usually discharged with prescriptions for antihistamines and corticosteroids for  to  days and a prescription for an epinephrine autoinjector. Although prolonged corticosteroid treatment should not be required for most patients, an aggressive longer­term approach (1 to  weeks or until symptoms are controlled) appears to reduce the frequency of relapses in patients with
 idiopathic anaphylaxis.

Discharge instructions should provide recommendations to prevent future episodes (Table 14­5). For all allergic reactions, instruct the patient on how to avoid future exposure to the causative agent (if the agent is known). Prescribe an epinephrine autoinjector to patients with serious allergic reactions or anaphylaxis with clear instructions on the use of the autoinjector. Overall, less than one third of patients and parents of children with anaphylaxis can demonstrate the effective use of an epinephrine autoinjector device, so education is a key component of discharge instructions. If delay in filling a prescription is anticipated, patients can be discharged from the ED with an epinephrine autoinjector (EpiPen®). Reinforce this prescription with documentation in the ED discharge instructions. Because allergic occurrences are unpredictable, prescriptions should include sufficient samples for multiple locations (e.g., home, vehicle, work), and patients should be advised to carry epinephrine with them at all times.
Unfortunately, research in the United States suggests that fewer than half of children, adolescents, and adults carry their epinephrine autoinjector
 devices with them.
TABLE 14­5
Discharge Planning for Patients With Anaphylaxis
Education
Identification of inciting allergen, if possible
Instructions on use of medications and epinephrine autoinjector
Advice about personal identification/allergy alert tag
Prescriptions for current reaction
Antihistamines: Diphenhydramine, 25–50 milligrams PO every 6–8 h for 3–5 d
Corticosteroids: Prednisone, 40–60 milligrams PO daily or 20–30 milligrams PO twice daily for 3–5 d
Prevention
Instructions on avoiding future exposure
Prescription for future reactions
Epinephrine autoinjector (at least 2)
Referral of selected patients to allergist

Refer patients with severe or frequent allergic reactions to an allergist for in­depth preventive management and attempts at allergen identification.
Offer patients information about this syndrome (e.g., from websites), advice on advocacy groups, and education regarding food contamination for food allergies, and encourage wearing of personal identification alerts about this condition (e.g., MedicAlert® bracelets). Because of the potential for severe and prolonged future reactions, patients with anaphylaxis on β­blockers should be switched to an agent from a different therapeutic class.
ALLERGIES AND ANGIOEDEMA
URTICARIA
Urticaria, or hives, is a cutaneous reaction marked by acute onset of pruritic, erythemic wheals of varying size that generally are described as

“fleeting.” Erythema multiforme is a more pronounced variation of urticaria, characterized by typical “target” skin lesions. Although these manifestations may accompany many allergic reactions, they also may be nonallergic; many acute urticarial reactions are due to viruses, especially in children, and present as hives persisting or recurring for more than  hours. Obtain a detailed history; if an etiologic agent can be identified (e.g., cold, exercise, food), future reactions may be avoided.
Treatment of urticarial reactions is generally supportive and symptomatic, with attempts to identify and remove the offending agent. H

41–43 antihistamines, with or without corticosteroids, are usually prescribed; however, some evidence suggests the addition of corticosteroids to
 nonsedating antihistamines is no better than antihistamines alone in preventing relapse or reducing itch. Epinephrine can be considered in severe or refractory cases. The addition of an H antihistamine, such as ranitidine, may also be useful in more severe, chronic, or unresponsive cases. Cold
 compresses may be soothing to affected areas. Referral to an allergy specialist is indicated in severe, recurrent, or refractory cases.
ANGIOEDEMA
Angioedema is a similar reaction as urticaria, but with deeper involvement characterized by edema formation in the dermis, generally involving the
 face and neck and distal extremities. Angioedema of the tongue, lips, and face has the potential for airway obstruction. Although angioedema is caused by a variety of agents, an angiotensin­converting enzyme inhibitor is a common trigger, with angioedema occurring in .1% to .7% of patients
,46 taking angiotensin­converting enzyme inhibitors. The pathophysiology of angiotensin­converting enzyme inhibitor–induced angioedema
,46 is complex, involving both bradykinin and substance P.
Orolingual angioneurotic edema is a rare complication of tPA administration, with case reports and small case series reporting a <1% to >5% incidence. The pathophysiology appears to be the uploading of bradykinin B2 receptors in the dying neurons of the ischemic/infarcted area. ACE inhibitors are associated with tPA­induced angioedema. Clinically, symptoms are usually limited to the anterior oropharynx, lips and tongue. The angioedema is often unilateral. Most cases are mild, and life­threatening angioedema is rare. Onset of symptoms is generally within  hours of the infusion, although more delayed onsets have been reported. Stop tPA if angioedema develops. Do not give any ACE inhibitors. In most cases,
45A angioedema spontaneously subsides. For progressive and severe symptoms, icatibant, Cl esterase inhibitor, fresh frozen plasma are recommended
65–67 in case reports. There is no evidence supporting the use of tranexamic acid for tPA­induced angioedema .

Management of angiotensin­converting enzyme inhibitor–induced angioedema is supportive, with special attention to the airway, which can become occluded rapidly and unpredictably. Drugs used to treat allergic reactions, such as epinephrine, antihistamines, and corticosteroids, are not beneficial
,46 because angiotensin­converting enzyme inhibitor–induced angioedema is not mediated by IgE. Tranexamic acid is a good first­line agent.

Icatibant, a bradykinin­2 antagonist, is an effective agent to reduce swelling and shorten time to complete resolution (Table 14­6). C1 esterase
 inhibitor (human) at a dose of 1000 U IV also appears effective based on a case series compared to historical controls. Ecallantide, a kallikrein
 inhibitor, is not effective in angiotensin­converting enzyme inhibitor–induced angioedema.
TABLE 14­6
Pharmacologic Treatment of Angioedema in Adults
Agent* Recommended Adult Dose Comments
Tranexamic Acid  gram IV Effective in ACEI­induced angioedema and possibly in idiopathic angioedema; no evidence supporting use for tPA­induced angioedema
Fresh Frozen Plasma 2­4 Units, typically 275 mL/unit In low­resource environments or intractable angioedema; suggested dose is a large
Dose not standardized volume. May be more readily available than agents listed in table rows below.
C1 esterase inhibitor  U/kg IV for HAE Effective in HAE and ACEI­induced angioedema†
[human] 1000 U IV for ACEI­induced
Adverse side effects include headache, abdominal pain, nausea, diarrhea, and vomiting
(Berinert®) angioedema
C1 esterase  U/kg IV (maximum dose, 4200 Effective in HAE, but effectiveness in laryngeal attacks not established inhibitor[recombinant] U) No data for ACEI­induced angioedema
(Ruconest®) Adverse side effects include headache and vertigo
Icatibant  milligrams SC Effective in HAE and ACEI­induced angioedema†
(Firazyr®)
Bradykin­2 receptor antagonist
Single dose highly effective: about 10% require second dose
90% experience mild local reactions: pain, swelling, erythema
Ecallantide  milligrams SC (in  separate Effective in HAE, but not ACEI­induced angioedema
(Kalbitor®) 10­milligram or 1­mL injections) Kallikrein inhibitor
Risk of anaphylaxis in up to 4%
May repeat 30­milligram dose within  h if reaction persists
Adverse side effects include headache, nausea, fatigue, diarrhea, nasopharyngitis, injection site reactions, and vomiting
Abbreviations: ACEI = angiotensin­converting enzyme inhibitor; FDA = U.S. Food and Drug Administration; HAE = hereditary angioedema.
* names provided to aid in recognition
†Not FDA approved for ACEI­induced angioedema
Immediate withdrawal from the angiotensin­converting enzyme inhibitor is indicated, and another antihypertensive should be prescribed, with the important exception that angiotensin II receptor–blocking agents should not be used. Most cases resolve in a few hours to days, so patients with mild swelling and no evidence of airway obstruction should be observed for  to  hours and discharged if swelling diminishes. Rebound or recurrent swelling will not occur unless the patient takes an angiotensin­converting enzyme inhibitor again.
Hereditary angioedema is a rare autosomal dominant disorder due to deficiency in C1 esterase inhibitor, either low levels (type I) or a dysfunctional
,52  enzyme (type II). About 25% of cases are due to new mutations. The disorder is characterized by acute edematous reactions involving the upper respiratory system, soft tissue of extremities or trunk, or gastrointestinal tract. Attacks can last from a few hours to  to  days. Minor trauma often precipitates an acute episode; however, triggers are often elusive. Typical treatments for allergic reactions, such as epinephrine, corticosteroids, and antihistamines, are ineffective. The best screening test is the C4 level. A C4 level <30% of normal suggests hereditary angioedema.
Acute attacks can be shortened by a C1 esterase inhibitor (either human plasma derived or recombinant), the bradykinin­2 receptor antagonist
,54,55 icatibant, or the kallikrein inhibitor ecallantide (Table 14­6). Fresh frozen plasma may be used if C1 esterase inhibitor is not available, although
 the dosing is not standardized, with  to  units described in most case reports. Prophylaxis of acute attacks is possible with attenuated androgens, such as stanozolol  milligrams PO TID or danazol 200 milligrams PO TID. Treatment of patients is complex and best done in coordination with the appropriate specialist.
FOOD ALLERGY REACTIONS
Hypersensitivity reactions to ingested foods are generally caused by IgE­coated mast cells lining the GI tract reacting to ingested food proteins and, rarely, to additives. Their frequency is rising for unknown reasons and varies based on age (more common in children), country of origin, and
 ,58 definitions and confirmatory tests used. Dairy products, eggs, nuts, and shellfish are the most commonly implicated foods.
A detailed dietary history within the  hours of allergic symptoms may provide the best clues to food allergy, with particular attention to other allergic
 history and prior reactions. Diagnosis is often difficult, however, and it may require multiple episodes before an offending agent is identified.
Symptoms of food allergy include swelling and itching of the lips, mouth, and pharynx; nausea; abdominal cramps; vomiting; and diarrhea. Cutaneous manifestations, such as angioedema and urticaria, as well as anaphylaxis, can occur. Treatment for mild reactions is supportive, with the administration of antihistamines to lessen symptoms. More severe reactions and anaphylaxis are managed as described earlier.
Mammalian meat allergy or galactose­alpha­1,3­galactose (alpha­gal) allergy is an IgE­mediated allergic reaction to ingestion of red meat
 containing the mammalian oligosaccharide epitope alpha­gal. Alpha­gal is found in all mammals except Old World monkeys, apes, and humans. Bites
(often unrecognized) from certain ticks, such as the Lone Star tick in the United States, can transfer this carbohydrate to humans, stimulating the production of the antibody implicated in a delayed allergic response triggered by the consumption of mammalian meat products. The onset is usually
,61 about  hours (range,  to  hours) after eating meat, manifested by urticaria, angioedema, gastroenteritis, or anaphylaxis. Treatment is the same as for urticaria or anaphylaxis of any cause, and control is maintained by avoidance of eating any mammalian meat. Duration of allergy is unknown.
Alpha­gal allergy is an increasing cause of allergic and anaphylactic reactions, reported most commonly in the middle United States and the north,
 central, and southern Atlantic states, where the Lone Star tick is prevalent.
To identify this syndrome, ask the patient about recent meat ingestion within  hours prior to the onset of symptoms, as well as prior episodes.

Diagnosis is confirmed by blood testing with a positive reaction to specific IgE alpha­gal antibodies. The results of testing are not immediately available to the ED; however, it is definitely worthwhile obtaining the assay and ensure diagnostic follow­up along with epinephrine autoinjector prescription because repeated anaphylactic reactions can be life threatening.
ALLERGIC DRUG REACTIONS
Adverse reactions to drugs are common; however, true hypersensitivity reactions probably account for <10% of these occurrences, with the majority
 anaphylaxis from IgE­mediated drug reactions. Although most drugs are small organic molecules, generally unable to stimulate an immune response alone, when a drug or metabolite becomes protein bound, either in serum or on cell surfaces, the drug–protein complex can become an allergen and stimulate immune system responses. Thus, the ability of a drug or its metabolites to sensitize the immune system depends largely on the ability to bind to tissue proteins. Many different drugs and treatments can cause allergic reactions and anaphylaxis.
Penicillin is the drug most commonly implicated in eliciting true allergic reactions and accounts for approximately 90% of all reported allergic drug
 reactions and about 75% of fatal anaphylactic drug reactions. Fatal reactions can occur without a prior allergic history; <25% of patients who die of penicillin­induced anaphylaxis exhibited allergic reactions during previous treatment with the drug. Parenteral penicillin administration is more than twice as likely to produce fatal allergic reactions as is oral administration. The cross­reactivity of penicillin allergy with cephalosporins is about 10%, so patients with a previous life­threatening or anaphylactic reaction to penicillin should not be given cephalosporins.
The clinical manifestations of drug allergy vary widely. A generalized reaction similar to immune­complex or serum sickness reactions is very common, especially with trimethoprim­sulfamethoxazole and certain cephalosporins (cefaclor being the most frequent). While sulfa moieties are contained in many drugs, sulfa allergic reactions upon exposure to the nonantibiotic sulfas are uncommon. See Chapter 206, “Antimicrobials,” for more discussion of drug allergies.
Serum sickness usually begins in the first or second week after initiation of the drug and can take many weeks to subside after drug withdrawal.
Generalized malaise, arthralgias, arthritis, pruritus, urticarial eruptions, fever, adenopathy, and hepatosplenomegaly are common signs and symptoms. Drug fever may occur without other associated clinical findings and may also occur without an immunologic basis. Circulating immune complexes are probably responsible for the lupus­like reactions caused by some drugs.
Other reactions are possible. Cytotoxic reactions include penicillin­induced hemolytic anemia. Skin eruptions include erythema, pruritus, urticaria, angioedema, erythema multiforme, and photosensitivity. Severe reactions, such as those seen in Stevens­Johnson syndrome and toxic epidermal necrolysis, may also occur. Delayed hypersensitivity reactions may manifest as contact dermatitis from drugs applied topically.
Diagnosis is determined by a careful history. Treatment is supportive, with oral or parenteral antihistamines and corticosteroids. Drug cessation is important, but reactions can continue. Referral to an allergy specialist is indicated for severe reactions.


