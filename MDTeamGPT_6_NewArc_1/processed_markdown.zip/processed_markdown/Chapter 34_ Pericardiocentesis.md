## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 34: Pericardiocentesis
Carolyn K. Synovitz; Eric J. Brown
INTRODUCTION AND EPIDEMIOLOGY
Cardiac tamponade is a rare condition in daily ED practice but in need of recognition. If a pericardial effusion compromises hemodynamics, pericardiocentesis is lifesaving. Blood or fluid filling the pericardial space can cause tamponade, with the latter dictated by the pace and volume of
1­4 either material accruing. The cause of cardiac tamponade may be determined by fluid analysis after pericardiocentesis (Table 34­1). In oncology patients, look carefully for this as a cause of weakness, breathing difficulty, syncope, or chest pain.
TABLE 34­1
Causes of Pericardial Effusions
Sagrista­Sauleda et al1 (n = 322) Corey et al2 (n = 75) Levy et al3 (n = 204) Kil et al4 (n = 116)
Cause
(%) (%) (%) (%)
Acute idiopathic    —
Idiopathic   — 
Malignancy    
Chronic  — — —
Post–myocardial  — — — infarction
Uremia    
Autoimmune    
Radiation —  — —
Infection —   
Hypothyroidism — —  
Tuberculosis — — — 
In a small study of medical cardiac tamponade, the mean volume drained was 593 ± 313 mL; traumatic acute tamponade typically has much smaller
 volumes of pericardial fluid. When the primary cause was malignancy, the 1­year mortality was almost 80%. In Africa, up to 70% of pericardial
 effusions in patients with human immunodeficiency virus are caused by tuberculosis.

Blunt cardiac rupture is rare, occurring approximately in  in 2400 blunt trauma patients. Of this subgroup, 89% arrive alive to the ED. Those who
 arrive alive may benefit from a bedside US examination to detect a traumatic effusion. Tamponade from trauma is best treated with a
Chapter 34: Pericardiocentesis, Carolyn K. Synovitz; Eric J. Brown s©u2b0x2i5p MhociGdr awwin Hdioll.w A lpl rRoigchetdsu Rrees, etrhvoeudg. h T ae rtmems opfo Ursizei n * gP rpivearcicya Prodliiocyc e * nNtoetsicise c * aAnc caeidss wibhiliitlye preparing for this or definitive surgical repair.

In a South African study, the mortality rates from chest gunshot wounds and stab wounds were 81% and .6%, respectively. This comparison underlines the probability that patients with stab wounds to the heart are more likely to survive to the ED and may benefit from pericardiocentesis.
PATHOPHYSIOLOGY
The pericardium is a fibrocollagenous sac covering the heart that contains a small amount of physiologic serous fluid. The fibrocollagenous pericardium has elastic properties and will stretch in response to increases in intrapericardial fluid. Accumulation of fluid that exceeds the stretch capacity of the pericardium precipitates hemodynamic compromise and results in pericardial tamponade.
The initial portion of the pericardial volume–pressure curve is flat, so early on, relatively large increases in volume result in comparatively small changes in intrapericardial pressure. The pericardium becomes less elastic as the slope of the curve marches upward. As fluid continues to accumulate, intrapericardial pressure rises to a level greater than that of the filling pressures of the right atrium and ventricle. When this occurs,
 restricted ventricular outflow results in symptoms and cardiac tamponade.
Pulsus paradoxus is common in those with cardiac tamponade, defined as an abnormal decrease in systolic blood pressure and pulse wave amplitude. During normal respirations, systolic blood pressure drops less than  mm Hg. In pulsus paradoxus, systolic blood pressure drops >10 mm

Hg, resulting in a cardiac contraction that does not result in a normal radial pulse. This causes a paradoxical pulse.
In blunt trauma, forces within the thorax can compress the right atrium, resulting in rupture of the atrium or the right atrial appendage. This occurs when blood continues to fill the relatively inelastic pericardial sac. Deceleration injuries can lead to a cardiac or pericardial rupture, herniation, or a
 myocardial contusion with intrapericardial hemorrhage. Blast injuries can cause acute cardiac tamponade. During an acute rapidly expanding pericardial effusion, stroke volume will increase with removal of even a small amount of fluid (as little as  mL) from the pericardial sac (Figure 34­1).
FIGURE 34­1. Acute versus chronic pericardial effusion. Pericardial volume–pressure curve with acute (solid line) versus chronic effusion (dotted line). [Reproduced with permission from Reardon RF, Joing SA: Cardiac, in Ma OJ, Mateer J, Reardon R, Joing SA(eds): Emergency Ultrasound, 3rd ed. New York: McGraw­
Hill, Inc.; 2013.]
CLINICAL FEATURES
HISTORY
Trauma as a cause of pericardial tamponade is generally evident from history and clinical presentation. Postoperative or penetrating trauma patients
 may develop tamponade  weeks or more after surgery. Oncology patients are the largest group with pericardial effusions leading to hemodynamic compromise. Other conditions that may predispose a patient to pericardial effusion and tamponade include renal failure, acute infection (viral, bacterial, mycoplasma, fungal, parasitic, or endocarditis), or radiation exposure. Other chronic conditions in which this diagnosis may be considered
 include tuberculosis, autoimmune diseases, drugs that induce a lupus­like syndrome, hypothyroidism, or ovarian hyperstimulation syndrome. Many cases are idiopathic.
The key symptoms of tamponade are dyspnea and chest pain. Trauma patients may or may not exhibit pleuritic pain, tachypnea, and dyspnea
 before becoming confused, losing consciousness, or developing shock. Other symptoms include chest fullness, nausea, esophageal pain, or abdominal pain from hepatic and visceral congestion. Other nonspecific symptoms include lethargy, fever, weakness, fatigue, anorexia, palpitations, and shock. Be aware of these symptoms and focus the examination to exclude life­threatening conditions such as cardiac tamponade.
PHYSICAL EXAMINATION
Common clinical signs of cardiac tamponade resemble other severe cardiopulmonary disease processes such as tension pneumothorax or decompensated congestive heart failure. The sensitivities of examination findings are 82% for pulsus paradoxus >10 mm Hg, 77% for tachycardia, 76% for jugular venous distention, 28% for diminished heart sounds, and 26% for hypotension. The classic (but not common) Beck’s triad includes low
 blood pressure, elevated jugular venous distention, and decreased heart sounds. Detection of jugular distention may be difficult to appreciate in patients with a short, thick neck or if working under levels of low lighting. The combination of pulsus paradoxus and elements of the Beck’s triad should prompt imaging with bedside US to search for a pericardial effusion. Any disorder that increases intrathoracic pressure may result in pulsus paradoxus, including chronic obstructive pulmonary disease, obesity, tense ascites, severe asthma, congestive heart failure, mitral stenosis, and massive pulmonary embolism.
DIAGNOSIS
The diagnosis relies on considering this cause by recognizing the signs and symptoms of cardiac tamponade and then confirmation using bedside US.
The ECG is often normal or nondiagnostic; the classic ECG finding is electrical alternans, alternating high­ and low­voltage QRS complexes as the heart swings toward and then away from the ECG leads on the chest wall with each contraction (Figure 34­2). Other findings include nonspecific ST­T–wave changes or bradycardia, which can be seen in the late stages of cardiac tamponade progressing to pulseless electrical activity. In the absence of hypotension and tension pneumothorax in a patient with pulseless electrical activity, consider the diagnosis of cardiac tamponade.
FIGURE 34­2. ECG of electrical alternans, with alternating higher­ and lower­voltage QRS complexes. A. Initial ECG in the ED. Bedside echocardiography revealed a large pericardial effusion with right ventricular diastolic collapse. B. Resolution of electrical alternans after pericardiocentesis. [Reproduced with permission from Smith RF: Pericardiocentesis, in Reichman EF (ed): Emergency Medicine Procedures, 2nd ed. New York: McGraw­Hill, Inc.; 2013.]
IMAGING
Chest radiographs may show a normal or enlarged cardiac silhouette with clear lungs, as demonstrated in Figure 34­3. On lateral chest radiographs, a double lucency sign demonstrates the epicardial fat pad.
FIGURE 34­3. Pericardial effusion on posteroanterior chest film. Note how the cardiac silhouette is rounded in its lower portion and tapers at the base of the heart, resembling a plastic bag filled with water sitting on a table. [Reproduced with permission from Sorajja P: Pericardial disease, in Hall JB, Schmidt GA,
Kress JP (eds): Principles of Critical Care, 4th ed. New York: McGraw­Hill, Inc.; 2015.]
Echocardiography
Cardiac tamponade is best detected at the bedside with two­dimensional echocardiography and Doppler echocardiography. This allows for visualization of a pericardial effusion and the compression of the ventricles. The most characteristic sign on echocardiogram is right­sided heart collapse. During diastole, the right ventricle presses inward (Figure 34­4), and during systole, the right atrium presses inward. Right­sided collapse portends rapid development of cardiac tamponade. Right atrial collapse during at least 30% of the cardiac cycle is more sensitive than the finding of right ventricular collapse for cardiac tamponade. In 25% of patients with tamponade, a late finding is left atrium collapse. Doppler US can monitor the
 respiratory changes in flow between ventricle and atrium.
FIGURE 34­4. RV compression (arrow) in cardiac tamponade (apical four­chamber plane). E = effusion; LV = left ventricle; RA = right atrium; RV = right ventricle.
[Reproduced with permission from Fuster V, Harrington RA, Narula J, Eapen ZP: Hurst’s the Heart, 14th ed. New York: McGraw­Hill, Inc.; 2017. Figure 15­
135B.]
PROCEDURE: EMERGENCY PERICARDIOCENTESIS
When hemodynamic compromise is present, infusion of a crystalloid fluid bolus enhances right ventricular volume while preparing for emergency
 pericardiocentesis.
PURPOSE AND INDICATIONS
Emergency pericardiocentesis relieves hemodynamic compromise from cardiac tamponade. Emergency pericardiocentesis is also indicated during resuscitation from pulseless electrical activity after excluding other causes.
In one study of traumatic tamponade, the most common indication for pericardiocentesis was clinical tamponade (83%), with echocardiographic
 findings of ventricular diastolic collapse (69%) and right atrial collapse (33%). Pericardiocentesis for a traumatic effusion from penetrating cardiac trauma is done during resuscitation to stabilize a patient until surgery for definitive repair is available, but surgical drainage is preferred in traumatic
 effusions and purulent pericarditis. If the patient is hemodynamically compromised or close to or in cardiac arrest, perform emergency pericardiocentesis in the ED rather than delaying treatment by transporting to the operating room.
BEDSIDE US
16­22
Use two­dimensional echocardiographic imaging to guide pericardiocentesis and evaluate the size of the effusion and its effect on cardiac output.
The 2010 Focused Cardiac Ultrasound in the Emergent Setting guidelines state: “When emergency pericardiocentesis is indicated ultrasound can provide guidance by first imaging the fluid collection from the subxiphoid/subcostal or other transthoracic windows to define the best trajectory for
  needle insertion” (Table 34­2). Bedside US pericardiocentesis guidance results in fewer complications and greater success. The European Society of Cardiology’s 2015 Guidelines on the Diagnosis and Management of Pericardial Disease note that this procedure is lifesaving in cardiac tamponade and is indicated in effusions >20 mm by echocardiography, but also in smaller effusions for diagnostic purposes (pericardial fluid and tissue analyses, pericardioscopy, and epicardial/pericardial biopsy). The society also recommends the use of US guidance rather than blind approaches or the ECG­
 alone guided approach for pericardiocentesis.
TABLE 34­2
Characteristics of the Different Pericardiocentesis Approaches
Place of
Description Disadvantages Advantages
Puncture
Apical The needle insertion site is 1–2 cm lateral to the apex Risk of ventricular puncture, due to the proximity to The thicker left beat within the fifth, sixth, or seventh intercostal space. the left ventricle. ventricle wall is
Advance the needle over the superior border of the rib Increased risk for pneumothorax for the proximity to more likely to selfto avoid intercostal nerves and vessels. the left pleural space. seal after puncture.
Using US ensures avoiding the lung.
The path to reach the pericardium is shorter.
Parasternal The needle insertion site is in the fifth left intercostal Risk of pneumothorax and puncture of the internal US with phased space, close to the sternal margin. Advance the needle thoracic vessels (if the needle is inserted more than  array probe, perpendicular to the skin (at the level of the cardiac cm laterally). provides a good notch of the left lung). visualization of pericardial structures.
Subxiphoid The needle insertion site is between the xiphisternum A steeper angle may enter the peritoneal cavity and a Lower risk of and left costal margin. Once beneath the cartilage cage, medial direction increases the risk of right atrial pneumothorax.
lower the needle to a 15­ to 30­degree angle with the puncture. In some cases, the left liver lobe may be abdominal wall directed toward the left shoulder. transversed intentionally if an alternative site is not available.
The path to reach the fluid is longer.
Source: Reproduced with permission from Chiara De Carlini C, Maggiolini S: Pericardiocentesis in cardiac tamponade: indications and practical aspects. E­J Cardiol
Pract 15: , 2017. Available at: https://www.escardio.org/Journals/E­Journal­of­Cardiology­Practice/Volume­15/Pericardiocentesis­in­cardiac­tamponadeindications­and­practical­aspects.
RISKS AND PRECAUTIONS
Some consider aortic dissection as an absolute contraindication. Relative contraindications include uncorrected coagulopathy, anticoagulant therapy, thrombocytopenia, and small posterior loculated effusions.
Traditional blind subxiphoid approaches increase the risk of damage to adjacent structures, such as the liver, lung, diaphragm, and GI tract. Other potential cardiac injuries are chamber puncture, myocardial damage, and laceration of coronary arteries/veins. Resultant dysrhythmias may develop secondary to myocardial damage. Using US to guide reduces injury risks from the procedure. If bedside US is not available and the patient has cardiac
 or hemodynamic compromise, the blind subxiphoid approach for cardiac tamponade for acute hemopericardium is used. See Table 34­3 for a list of equipment needed.
TABLE 34­3
Equipment for Emergency Pericardiocentesis
Antiseptic (e.g., povidone­iodine, ChloraPrep®)
Local anesthetic (1%–2% lidocaine)
25­gauge needle, 5/ in. long

18­gauge catheter­type needle, 11/ in. long (for parasternal or apical approaches)

Syringes (10, , and  mL)
 ×  gauze squares
Plastic tubing
Collection system or basin
US machine
Sterile US probe cover (can be sterile glove)
Sterile drapes
Yankauer suction catheter
Suction tubing
Cardiac monitoring
Optional
18­gauge spinal needle, 31/ in. long (if needed for subxiphoid blind approach)

Alligator clips connected by wire (for ECG approach)
Bedside ECG
Nasogastric tube
Variable angle needle guide attachment for US
Towel clips
#11 scalpel blade
J­tipped guidewire .035 mm diameter
6F–8F pigtail catheter
Three­way stopcock
PATIENT PREPARATION AND POSITIONING
If time and conditions permit, obtain and review a stat portable chest radiograph to assess for other causes or complicating features such as mediastinal shift or pneumothorax. Traditional positioning for pericardiocentesis is with the head of the bed elevated to approximately  to  degrees, but in cardiac arrest or near­arrest, this may not be feasible and the patient may need to be supine. Before choosing the needle insertion site, any mediastinal shift will displace structures and alter normal anatomic locations. In some instances, very small effusion volumes (50 to 100 mL) precipitate cardiac tamponade, with fluid collecting in dependent portions of the pericardial space. If the size of the effusion is small, rolling a patient to the left lateral decubitus position allows fluid to collect around the apex and provides easier access. This positioning also allows the left lung to move laterally, thereby increasing cardiac exposure.
ANESTHESIA AND MONITORING
Patients undergoing emergency pericardiocentesis in the ED are often in distress and are being resuscitated. They may already be sedated or paralyzed; if not, use local anesthesia, 1% to 2% lidocaine injected subdermal and deeper along the plane of expected needle insertion. Aspirate during infiltration to avoid injection of lidocaine directly into vascular structures.
Use ongoing cardiac monitoring and pulse oximetry, and provide supplemental oxygen. Ask an aide to help monitor the pulse amplitude.
STEP­BY­STEP TECHNIQUE
. Use universal precautions (See Video: Pericardiocentesis).
. Organize needed materials.
. Position patient as needed.
. Identify point of maximal effusion with US (i.e., closest to transducer/skin and where accumulation is maximal). Pericardial effusions are dark, or anechoic, areas surrounding the heart. Usually the pericardium can be seen overlying the effusion. In addition, paradoxical motion of the right ventricular wall with collapse during diastole is noted in states of tamponade. Distance from the skin surface to the effusion border can be measured with most US models to better assess expected needle depth.
. Choose needle trajectory. Trajectory should coincide with the plane of the US beam. Identify any anatomic structure between the skin and pericardial space that lies within the expected needle path. The best approach should aim for the point of maximal effusion with the fewest intervening structures. For most patients, the optimal approach is the left chest wall. Most common is the left parasternal approach or the apical approach, both at the fifth intercostal space (Figure 34­5), or the subxiphoid approach. If using the left parasternal approach, select a site approximately  to  cm from the sternal edge to avoid the left internal mammary artery. Direct the needle over the superior margin of the rib to avoid injuring the neurovascular bundle on the inferior margin of each rib. Mark any site with a surgical pen for easier location after sterile preparation.
. Sterile preparation. Prepare area with an antiseptic. Drape the surrounding area with sterile towels or a premade drape.

. Inject local anesthetic. Inject 1% to 2% lidocaine with a 25­gauge, / ­inch needle at the selected site before the procedure. Produce a subdermal
 wheal, and then inject into deeper tissues while avoiding entry into the chest cavity. Aspirate before injection to avoid injection of anesthetic into vascular structures.
. Preparation of US. Using the cardiac probe, place a sterile cover over the probe (may use sterile glove) after placing US gel on the probe tip. Place sterile US gel over the planned site of entry. Using the nondominant hand, hold the US probe in the plane of planned needle insertion. A second operator technique may be used.
. Pericardial needle insertion. Under direct US guidance, insert an adequately long needle at the predetermined site at an approximately 45­degree angle to the skin at the transducer. Visualize the needle “tenting” the pericardium. Upon entry into the pericardial sac, a return of blood, serous fluid, or pus indicates the entry. Clotted blood may prevent aspiration, although this may be seen on US as echogenic material. If you suspect needle obstruction, attempt flushing the needle with  to  mL of normal saline to cleanse the needle. If aspiration of free blood is too easy, suspect ventricular puncture. To decrease complications of needle insertion, do not redirect the needle within the pericardium while aspirating. This may reduce the number of occurrences of inadvertent coronary artery lacerations or penetration of the pericardium.
. Collect fluid for diagnostic testing outside of trauma to assess for protein or albumin, cell types and counts, Gram stain, and cultures.
. Catheter removal. Once adequate fluid has been withdrawn from the pericardial space and hemodynamic equilibrium returns, you may remove the catheter. Dress the site after removal. Alternatively, you may place an optional indwelling flexible J­tip catheter (see step 2). Although recurrence rates decrease with indwelling or extended catheter drainage, this is not routinely performed in the ED secondary to patient acuity and ongoing resuscitative measures. Once stabilized, a cardiologist or cardiac surgeon may evaluate for other care and possible indwelling catheter placement.
FIGURE 34­5. Potential sites to perform a pericardiocentesis. [Adapted with permission from Smith RF: Pericardiocentesis, in Reichman EF (ed): Emergency Medicine
Procedures, 2nd ed. New York: McGraw­Hill, Inc.; 2013.]
Video 34­1: Pericardiocentesis
Used with permission from Henderson McGinnis, Wake Forest University Baptist Hospital.
Play Video
OPTIONAL STEPS
. Saline echo­contrast technique. When confirmation of the needle tip is necessary, use an agitated saline solution. Using a three­way stopcock, attach one end to the catheter. Attach one syringe with  mL of normal saline and one syringe with an equivalent amount of air to the remaining two ports. Quickly mix the saline and air together and then inject into the pericardial sac under US visualization. Alternatively, the saline is agitated by simply shaking a 10­mL syringe filled with  to  mL of normal saline and then injecting this into the pericardial space. An echo­contrasted medium should appear in the pericardial space. If the contrast disappears quickly after injection, suspect tip placement in ventricle. Rather than attempting to reinsert needle into the catheter, it is best to start again with a new needle should this complication arise.
. Catheter placement. Using the standard Seldinger technique, introduce a flexible J­tip guidewire through the catheter. Remove the catheter, and then make a small “stab” incision at the needle entry site. Introduce a 6F to 8F dilator over the guidewire, remove it, and then introduce a 6F to 8F pigtail catheter over the guidewire. Finally, remove the guidewire and confirm placement by saline echo­contrast as in step  above. Once confirmed, place the catheter on suction.
. Dressing. Secure the catheter to the chest wall with suture, dressing, or both.
. Aspirate pericardial fluid every  to  hours, avoiding continuous drainage. Flushing the catheter with saline after drainage will ensure patency.
BLIND SUBXIPHOID APPROACH
The blind subxiphoid approach starts with similar preparation and anesthetic. The point of needle insertion starts either directly below or adjacent to the xiphoid process. Insert a longer 18­gauge needle at a 45­degree angle to the patient’s skin, and direct the needle tip to either the left or right shoulder (Figure 34­6). Some authors advocate using the right shoulder as the direction of choice because this direction is parallel to the ventricular wall (in contrast to perpendicular for left shoulder direction), theoretically reducing the chance of myocardial injury. In either approach, aim the needle toward the heart and use continuous aspiration of the syringe until return of pericardial fluid.
FIGURE 34­6. The subxiphoid approach. The needle is inserted at a 45­degree angle to the midsagittal plane (A) and at a 45­degree angle to the abdominal wall (B).
[Adapted with permission from Smith RF: Pericardiocentesis, in Reichman EF (ed): Emergency Medicine Procedures, 2nd ed. New York: McGraw­Hill,
Inc.; 2013.]
ECG MONITORING TECHNIQUE
This technique uses ECG monitoring to detect myocardial injury patterns and localize needle location. However, ECG injury monitoring alone is not an
 adequate safeguard. The approach is similar to the blind approach in orientation. Attach the V monitor lead to the needle. Watch the monitor while
 introducing the needle. ST elevation on the monitor indicates that the needle tip has contacted the myocardium. Withdraw the needle slightly and aspirate. This technique is rarely used currently due to complexity in the emergent setting and advances in US allowing for safer alternatives.
OUTCOME ASSESSMENT AND COMPLICATIONS
A favorable outcome is the restoration of hemodynamic stability as indicated by blood pressure and heart rate. Two­dimensional echocardiography should also show decreased effusion, increased cardiac contractility, and increased cardiac output.
Complications depend on approach and the underlying cause of tamponade. Traditional blind techniques have an associated morbidity of 20%, with
 mortality as high as 6%. The overall complication rate of US­guided approaches is <5%.
Major complications include chamber lacerations requiring surgery, intercostal vessel injury requiring surgery, pneumothorax requiring chest tube placement, ventricular tachycardia, and bacteremia. Minor complications include transient chamber entries, small pneumothorax not requiring intervention, hypotension secondary to vasovagal response, sinus tachycardia, pericardial catheter occlusion, and possible pleuropericardial
 fistulas. Cardiac dysrhythmias, such as atrial fibrillation, ventricular tachycardia, or asystole, may occur when the needle penetrates the pericardium.
Monitor the patient closely for reaccumulation of pericardial fluid after pericardiocentesis.
DISPOSITION AND FOLLOW­UP
All patients undergoing ED pericardiocentesis require admission to the intensive care unit. Consult the trauma surgeon, cardiologist, or cardiothoracic surgeon early in patient evaluation.


