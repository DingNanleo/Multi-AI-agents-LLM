## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 239: Thrombotics and Antithrombotics
David E. Slattery; Charles V. Pollack, Jr
INTRODUCTION
Antithrombotic therapy (i.e., anticoagulants, antiplatelet agents, and fibrinolytics) is used to treat or reduce the risk of arterial and venous thromboembolic conditions, including acute coronary syndrome, deep venous thrombosis and pulmonary embolism (collectively, venous thromboembolic disease), transient ischemic attack, and ischemic stroke (Table 239­1). Moreover, antithrombotic agents help prevent occlusive vascular events in patients at risk for thrombosis due to atherosclerotic arterial disease, atrial fibrillation, medical illness with immobility, or surgical insult. These agents, however, can cause life­threatening complications, primarily serious or life­threatening hemorrhage. Detailed management strategies for thromboembolic disorders are discussed in their respective chapters (see Chapter , “Acute Coronary Syndromes”; Chapter ,
“Venous Thromboembolism Including Pulmonary Embolism”; and Chapter 167, “Stroke Syndromes”).
TABLE 239­1
Indications for Antithrombotic Therapy
Clinical Indication Comments
Treatment of Deep Venous Thrombosis and Pulmonary Embolism
Unfractionated heparin  units/kg IV bolus followed by  units/kg per h continuous IV In most cases, heparin and warfarin started infusion, with the aPTT checked after  h and the infusion adjusted to maintain anti­FXa simultaneously, with an overlap of 3–5 d.
activity .3–0.7 IU/mL or aPTT .5–2.5 times reference range (e.g., 68–106 s) with concurrent Warfarin is monitored and dose adjusted to a target INR of institution of warfarin .0–3.0 in most patients.
Enoxaparin  milligram/kg SC every  h or .5 milligrams/kg SC once a day Laboratory monitoring not routinely required (see text)
If CrCl <30 mL/min:  milligram/kg SC daily
Dalteparin 200 units/kg SC once daily or 100 units/kg SC twice daily Not FDA approved for this indication
Fondaparinux weight­tiered regimen Laboratory monitoring not routinely required
<50 kg:  milligrams SC once a day Avoid in patients with CrCl <30 mL/min
50–100 kg: .5 milligrams SC once a day
>100 kg:  milligrams SC once a day
Dabigatran 150 milligrams PO twice daily Following 5–10 d of initial therapy with parenteral anticoagulant
Avoid in patients with CrCl <30 mL/min or on hemodialysis
Rivaroxaban  milligrams PO twice daily for  d with food, followed by  milligrams PO Avoid use in patients with CrCl <30 mL/min once daily with food
Apixaban  milligrams PO twice daily for  d, followed by  milligrams twice daily Reduce dose by 50% if patient taking dual strong VYP3A4 and P­glycoprotein inhibitors.

Chapter 239: Thrombotics and Antithrombotics, David E. Slattery; Charles V. Pollack, Jr If Cr >1.5 milligrams/dL and either ≥80 years of age oPrage  / 
. Terms of Use * Privacy Policy * Notice * Accessbibodiliyt yweight ≤60 kg: .5 milligrams twice daily
Edoxaban  milligrams PO daily (if ≤60 kg) or  milligrams PO daily (if >60 mg) Following 5–10 d of initial therapy with parenteral anticoagulant
If CrCl  to  mL/min:  milligrams PO daily
If CrCl <15 mL/min: use not recommended
Streptokinase 250,000 units IV bolus, followed by 100,000 units/h continuous IV infusion for Fibrinolytic treatment of deep venous thrombosis and
1–3 d pulmonary embolism is recommended only in carefully or selected patients.
Alteplase 100 milligrams IV infused over  h or
Tenecteplase weight­tiered single IV bolus
<60 kg:  milligrams
≥60–<70 kg:  milligrams
≥70–<80 kg:  milligrams
≥80–<90 kg:  milligrams
≥90 kg:  milligrams
Prophylaxis for Deep Venous Thrombosis and Pulmonary Embolism
Unfractionated heparin 5000 units SC every 8–12 h Highest­risk patients for venous thromboembolism should receive every­8­h dosing.
Recommend using in patients with renal dysfunction
Dalteparin 2500 to 5000 IU SC once a day —
Enoxaparin  milligrams SC once daily (normal renal function),  milligrams SC twice daily —
(trauma), or  milligrams SC twice daily (obese patients)
Fondaparinux .5 milligrams SC once a day —
Rivaroxaban  milligrams PO once a day with or without food —
Apixaban .5 milligrams PO twice daily For prophylaxis after hip and knee replacement surgery, initial dose taken 12–24 h after surgery
Betrixaban 160 milligrams PO first dose, then  milligrams PO daily. If CrCl 15–30 mL/min, Approved for VTE prophylaxis, not treatment start  milligrams PO first dose, then  milligrams PO daily.
ST­Segment Elevation Myocardial Infarction
Aspirin (non–enteric coated) 162–325 milligrams PO once a day Dual therapy—aspirin plus another antiplatelet agent—is plus common.
Clopidogrel 300 milligrams PO loading dose (consider 600 milligrams if PCI is planned) Prasugrel is contraindicated for patients with a previous followed by  milligrams PO once a day stroke and not recommended in patients age ≥75 y.
or
Ticagrelor 180 milligrams PO loading dose, followed by  milligrams PO twice daily or
Prasugrel  milligrams PO loading dose followed by  milligrams PO once a day (in patients
≤60 kg, the recommended maintenance dose is  milligrams PO once a day)
Unfractionated heparin  units/kg IV bolus (maximum, 4000 units according to the ACC/AHA Optimal anticoagulation strategies are not completely guidelines or 5000 units according to the ESC guidelines) followed by  units/kg per h defined.
(maximum, 1000 units) continuous IV infusion adjusted to anti­FXa activity .3–0.6 IU/mL or Bivalirudin is recommended in patients with heparinaPTT .5–2.5 times reference range (e.g., 68–96 s) induced thrombocytopenia.
or
Enoxaparin  milligrams IV bolus, followed by  milligram/kg SC every  h (maximum, 100 milligrams for the first  doses only) for patients <75 y old or .75 milligram/kg SC every  h for patients >75 y old (no IV bolus is administered in this population) or
Bivalirudin .75 milligram/kg IV bolus followed by .75 milligrams/kg per h continuous IV infusion (FDA approved for use in cardiac catheterization laboratory only)
Streptokinase .5 million units IV over  min Early administration is more important than choice of or specific fibrinolytic agent.
Alteplase  milligrams IV bolus over 1–2 min followed by .75 milligram/kg IV over  min
(maximum,  milligrams) and .50 milligram/kg IV over  min (maximum,  milligrams) or
Reteplase  units IV bolus, then a second 10­unit dose at  min or
Tenecteplase weight­tiered single IV bolus
<60 kg:  milligrams
≥60–<70 kg:  milligrams
≥70–<80 kg:  milligrams
≥80–<90 kg:  milligrams
≥90 kg:  milligrams
Unstable Angina and Non–ST­Segment Myocardial Infarction
Aspirin (non–enteric coated) 162–325 milligrams PO once a day Optimal antiplatelet strategies are not completely defined.
Clopidogrel 300 milligrams PO loading dose (consider 600 milligrams if PCI is planned) Dual therapy—aspirin plus another antiplatelet agent—is followed by  milligrams PO once a day common.
or Prasugrel is contraindicated for patients with a previous
Prasugrel  milligrams loading dose followed by  milligrams PO once daily (in patients stroke and not recommended in patients age ≥75 y.
≤60 kg, the recommended maintenance dose is  milligrams PO once a day) or
Ticagrelor 180 milligrams PO loading dose, followed by  milligrams PO twice daily
Unfractionated heparin  units/kg IV bolus (maximum, 4000 units according to the ACC/AHA Optimal anticoagulation strategies are not completely guidelines or 5000 units according to the ESC guidelines) followed by  units/kg per h defined.
(maximum, 1000 units) continuous IV infusion adjusted to anti­FXa activity .3–0.6 IU/mL or Bivalirudin is recommended in patients with heparinaPTT .5–2.5 times reference range (e.g., 68–96 s) induced thrombocytopenia.
or
Enoxaparin  milligram/kg SC every  h or
Glycoprotein IIb/IIIa inhibitor, depending on risk and whether PCI is planned or
Bivalirudin .75 milligram/kg IV bolus followed by .75 milligrams/kg per hour continuous IV infusion (FDA approved for use in cardiac catheterization laboratory only)
Peripheral Arterial Disease
Aspirin 162–325 milligrams PO once a day —
Cilostazol 100 milligrams PO twice a day —
Acute Ischemic Stroke
Alteplase .9 milligram/kg (maximum,  milligrams) with 10% of total dose given as an IV Use of fibrinolytics in acute ischemic stroke requires strict bolus over  min followed by the remainder as an IV infusion over  min adherence to recommended guidelines and should be done with informed consent. Adjunctive use of anticoagulants should be avoided for  h.
Tenecteplace .25 milligrams/kg IV bolus Not FDA approved for this indication (see text).
Recommend informed consent. Adjunctive use of anticoagulants should be avoided for  h.
Postischemic Stroke
Aspirin  milligrams PO once a day —
Clopidogrel  milligrams PO once a day Use clopidogrel if aspirin allergic.
Dipyridamole 200 milligrams extended­release PO twice a day Usually combined with aspirin 25–50 milligrams PO twice a day
Transient Ischemic Attack
Aspirin  milligrams PO once a day Use clopidogrel if “aspirin failure” or aspirin allergic.
Clopidogrel  milligrams PO per day —
Stroke Reduction in Nonvalvular Atrial Fibrillation
Warfarin dose monitored and adjusted by INR Target INR is .0–3.0 in most patients.
Dabigatran 150 milligrams PO twice daily (patients with CrCl >30 mL/min) or  milligrams PO Routine laboratory monitoring not necessary twice daily (patients with CrCl 15–30 mL/min)
Rivaroxaban  milligrams PO once daily with evening meal (patients with CrCl >50 mL/min) Routine laboratory monitoring not necessary or  milligrams once daily with evening meal (patients with CrCl 15–50 mL/min)
Apixaban  milligrams PO twice daily or .5 milligrams twice daily in patients with at least  of Routine laboratory monitoring not necessary the following characteristics: age ≥80 y, body weight ≤60 kg, or serum Cr ≥1.5 milligrams/dL
Edoxaban  milligrams once daily (patients with CrCL between  and  mL/min) or  Avoid use if CrCl >95 mL/min.
milligrams once daily (patients with CrCl 15–50 mL/min) Routine laboratory monitoring not necessary
Abbreviations: ACC = American College of Cardiology; AHA = American Heart Association; aPTT = activated partial thromboplastin time; Cr = creatinine; CrCl = creatinine clearance; ESC = European Society of Cardiology; FDA = U.S. Food and Drug Administration; FXa = factor Xa; PCI = percutaneous coronary intervention; VTE
= venous thromboembolism.
Hemostasis—whether physiologic after accidental injury or pathologic after rupture of an atherosclerotic plaque—is initiated by platelet interaction with the vascular subendothelium and continues with a series of reactions among plasma coagulation proteins that generate the final product of cross­linked fibrin incorporated into the initial platelet plug (see Chapter 232, “Hemostasis”). Arterial thrombi, composed primarily of platelets bound by thin fibrin strands, develop under high­flow conditions, especially at sites of ruptured plaques. Both anticoagulants and platelet­inhibiting drugs may effectively prevent and treat arterial thrombosis. In contrast, venous thrombi tend to form in areas of sluggish blood flow and are composed mainly of red blood cells and large fibrin strands. Anticoagulant drugs are more effective than antiplatelet drugs in preventing venous thromboembolism.
Antithrombotic agents are classified by their mechanism of action. Anticoagulants block the synthesis or activation of clotting factors, interfering with the coagulation cascade at one or more steps. Antiplatelet agents interfere with platelet activation or aggregation. Fibrinolytic agents (often but inaccurately referred to as thrombolytic agents) stimulate the enzymatic dissolution of the fibrin component.
Thrombotics or hemostatic agents are used to diminish bleeding due to either an antithrombotic agent or an acquired or genetic bleeding disorder
(see Chapter 233, “Acquired Bleeding Disorders,” and Chapter 235, “Hemophilias and von Willebrand’s Disease,” respectively).
ORAL ANTICOAGULANTS
Oral anticoagulants are used to (1) stop further thrombosis when the condition already exists (e.g., venous thrombosis), (2) reduce the risk of embolism in patients with thrombotic disease (e.g., venous thrombosis or left ventricular mural thrombus), and (3) prevent thrombi from forming in patients with risk factors for their development (e.g., atrial fibrillation, prolonged immobilization, or prosthetic heart valve) (Table 239­1). Oral anticoagulants can be either indirect acting, such as the vitamin K antagonists (e.g., warfarin), or direct acting (termed direct­acting oral anticoagulants).
WARFARIN
PHARMACOLOGY
,2
Warfarin, a hydroxy coumarin compound, is a widely used oral anticoagulant. Warfarin is readily absorbed after ingestion, reaching peak blood concentrations in  to  hours, and has a circulating half­life of  to  hours. Warfarin is bound to albumin, metabolized by the liver, and excreted in the urine. Warfarin blocks activation of vitamin K and thereby interferes with hepatic carboxylation of coagulation factors II, VII, IX, and X. The decrease in these vitamin K–dependent cofactors impairs the extrinsic and common coagulation pathway. Warfarin also blocks the synthesis of proteins C and
S. Activated protein C (with protein S and phospholipid as cofactors) proteolyses factors Va and VIIIa, thereby inhibiting the coagulation cascade. Thus, warfarin has both an antithrombotic effect (by inhibiting the synthesis of factors II, VII, IX, and X) and a prothrombotic effect (through inhibition of proteins C and S production), but during maintenance therapy, the overwhelming effect is one of anticoagulation.
Warfarin dosing is guided by measurement of the INR, a standardized measurement of prothrombin time, with a desired therapeutic range of .0 to .0
 in most cases. Drugs and food that interfere with warfarin absorption, bind to albumin, or alter hepatic metabolism can have a profound effect on warfarin activity (Table 239­2). Warfarin is generally contraindicated in pregnancy because it is teratogenic (especially during the 6th to 12th weeks of gestation) and can cause fetal hemorrhage.
TABLE 239­2
Warfarin Interactions
Consideration Effect on PT or INR* Major
Vitamin K malabsorption or dietary deficiency ↑
Excess vitamin K ↓
Reduced gut bacteria (antibiotics)† ↑
Decreased warfarin absorption ↓
Altered warfarin metabolism (cytochrome P450) Variable
Drug effects† Variable
Other
Decreased clotting factor production (liver disease) ↑
Increased metabolism of clotting factors (fever) ↓
Confounding technical or laboratory factors (e.g., phlebotomy, handling in transport, thromboplastin reagents) Variable
*↑ = prothrombin time (PT) or INR prolonged; ↓ = PT or INR decreased.
†Consult drug­interaction reference for any new medications.
Protein C has a short half­life (8 hours), and plasma levels quickly fall after starting warfarin. The vitamin K–dependent coagulation factors have halflives that range from approximately  hours for factor VII to approximately  hours for prothrombin (factor II). The phase delay between the fall in levels of protein C (an antithrombotic protein) and the fall in levels of the four affected coagulation factors (prothrombotic proteins) results in a transient state of increased thrombogenesis at the start of warfarin therapy that persists for  to  hours.
This hypercoagulable state is mitigated by providing sufficient overlap with a parenteral anticoagulant (typically, a heparinoid) during the first  to 
,2 3­5 days of warfarin treatment and during any interruption of warfarin therapy for surgery or an invasive procedure. Because factors X and II have relatively long half­lives, the parenteral anticoagulant should not be discontinued until the INR is in the desired therapeutic range for  consecutive days. Thus, a noncompliant patient with the risk for catastrophic complications from sudden intravascular thrombosis—such as a patient with a mechanical prosthetic heart valve who has stopped oral anticoagulants—should be treated with a parenteral anticoagulant in addition to restarting warfarin.
There is also a prothrombotic rebound during the first  days after cessation of warfarin therapy. However, there is no increased incidence of clinical episodes of thrombosis with termination of warfarin therapy, and thromboembolic events that occur in patients after warfarin discontinuation are most likely related to the underlying condition.
The two major complications of warfarin therapy are bleeding and, less commonly, skin necrosis. The most important factor influencing the risk of
,2 bleeding is the intensity of anticoagulant therapy. The risk of clinically significant bleeding is increased when the INR is >4.5 to .0. Skin necrosis occurs primarily (but not exclusively) in patients with protein C deficiency. This complication usually develops  to  days after starting treatment and is caused by thrombosis of small cutaneous vessels. Treatment includes discontinuation of warfarin, administration of a parenteral anticoagulant to maintain desired anticoagulation, vitamin K administration, and screening for protein C and S deficiencies.

Patient­specific risk factors for increased risk of bleeding during warfarin treatment include hypertension, anemia, prior cerebrovascular disease, GI lesions, and renal disease. The relationship between advanced age and warfarin­associated bleeding is controversial. Elderly individuals who are otherwise appropriate candidates for anticoagulant therapy should not have warfarin withheld solely because of their age, although elderly patients require more frequent and careful monitoring. Medications that increase warfarin activity and antiplatelet medications increase bleeding risk during warfarin therapy (Table 239­2).
Potential drug–drug and drug–food interactions with warfarin are numerous and complex. Carefully review medications prescribed on ED discharge.
In addition, it is recommended that drug–drug interaction references be used whenever adding a new medication to a patient on warfarin. Drugs frequently prescribed upon ED discharge that should generally be avoided in patients on warfarin because of the increased risk of bleeding, include NSAIDs, sulfa­containing drugs (e.g., sulfamethoxazole), macrolides, and fluoroquinolones. Drugs that induce hepatic cytochrome
P450 activity may increase the metabolism and reduce the effect of warfarin. Because the effect may take several days to manifest, the following agents should only be prescribed upon ED discharge after careful review and with close follow­up: barbiturates, anticonvulsants (e.g., phenytoin, carbamazepine, primidone), antibiotics (e.g., dicloxacillin, nafcillin, rifampin), and antipsychotics or sedatives (e.g., haloperidol, trazodone).
WARFARIN COAGULOPATHY
The two important principles when warfarin­treated patients bleed with a prolonged INR are as follows: (1) attempt to identify and attenuate the cause of bleeding, and (2) lower the intensity of the anticoagulant effect. In patients with a modestly elevated INR without clinically evident bleeding,
,6,7 cessation of warfarin, careful observation, and periodic monitoring compose the safest course (Figure 239­1). Conversely, reversal is
,7 recommended when the INR is markedly elevated or there is clinically significant bleeding. The speed and extent of reversal should be balanced
 against the risk of recurrent thromboembolism in patients who require therapeutic anticoagulation. For example, an overanticoagulated patient with a prosthetic mitral valve may develop fatal thrombosis if supratherapeutic anticoagulation is rapidly and fully reversed.
FIGURE 239­1. Management of prolonged INR (warfarin­induced coagulopathy). *High risk of bleeding: age >75 years, concurrent antiplatelet drug use,
† polypharmacy, liver or renal disease, alcoholism, recent surgery, or trauma. There are no validated tools to predict risk of short­term major bleeding in patients with severe overanticoagulation. The decision to admit for observation relies on physician judgment. FFP = fresh frozen plasma; 4­factor
PCC = prothrombin complex concentrate (human) containing coagulation factors , , , and ; 3­factor PCC = coagulation factor IX complex containing coagulation factors , , and ; rFVIIa = coagulation factor VIIa (recombinant).
Three approaches used to reverse warfarin­induced coagulopathy are as follows: (1) stop warfarin therapy; (2) administer vitamin K (PO or IV); and

(3) replace deficient coagulation factors using either fresh frozen plasma, prothrombin complex concentrate (human), coagulation factor
,9­12
IX complex (human), or coagulation factor VIIa (recombinant) (Figure 239­1). In asymptomatic patients with an elevated INR of .5 to  due to warfarin, oral vitamin K .0 to .0 milligrams will produce a measurable reduction in INR by  hours, with a therapeutic level by the second

,7 day. In asymptomatic patients with an INR >10, oral vitamin K  milligrams is also effective, although the reduction in INR takes longer. Although low­
 dose oral vitamin K carries a small risk for patients who require therapeutic anticoagulation, it is reasonable to consult an appropriate specialist
 before using vitamin K to reverse anticoagulation in stable patients.

IV vitamin K carries a rare but serious, non–dose­dependent risk of anaphylaxis and should not be used for routine reversal of therapeutic

 overanticoagulation. For patients who require continued anticoagulation, IV administration also carries the risk of overcorrection not associated
 with oral use. IV vitamin K should be restricted to patients with life­threatening bleeding and to symptomatic patients poisoned by an excessive
 ingestion of warfarin (e.g., suicidal overdose). Generally, overdose patients do not require long­term therapeutic anticoagulation, and reversal does not carry the risk of recurrent thrombosis.
Administration of vitamin K to a warfarin­treated patient should not be considered reversal of anticoagulation. Vitamin K simply restores the patient’s ability to begin again to synthesize factors II, VII, IX and X, and reattaining physiologic levels and normal hemostasis may take hours to days to achieve.
The fastest method of reversing therapeutic overanticoagulation is with coagulation factor repletion by IV infusion, using either fresh frozen plasma, prothrombin complex concentrate (human) (PCC or four­factor PCC), or coagulation factor IX complex (human) (or three­factor PCC) with or without
9­12 coagulation factor VIIa (recombinant). For patients with intense anticoagulation (INR >10) who require only partial reversal, fresh frozen plasma  to  mL/kg would be expected to restore coagulation factors to about 30% of normal, corresponding to an INR of .7 to .8. Disadvantages of fresh frozen plasma include potential fluid overload, which can be difficult to reverse with furosemide. Some institutions provide “universal donor” fresh frozen plasma, which is derived from AB­Rh+ donors and thus contains no anti­A, anti­B, or anti­Rh antibodies. If available and indicated, it can be given without a type and cross­match of blood from the recipient and as soon as it is defrosted (20 to  minutes).
For patients with life­threatening hemorrhage who require rapid, complete reversal, such as those with warfarin­associated intracranial
,14,15 hemorrhage, give vitamin K  milligrams IV and PCC  to  milligrams/kg IV (Figure 239­1). If factor IX complex (or three­factor PCC) is used, consider the addition of coagulation factor VIIa (recombinant) to make up for the minimal amount of factor VII in factor IX complex. Additional doses of these products may be required depending on the degree of coagulopathy. PCC reverses the INR within  minutes, with the degree of INR reduction depending on the initial INR. The half­life of PCC is about  to  hours. The onset of action of IV vitamin K is about  hours, with maximal effect at  to  hours, so PCC and IV vitamin K act synergistically in INR reduction.
DIRECT THROMBIN INHIBITORS
Dabigatran etexilate, an oral direct thrombin inhibitor, is used to reduce the risk of stroke and systemic embolism in patients with nonvalvular atrial
,16­19 fibrillation, and the risk of recurrent deep venous thrombosis or pulmonary embolism after treatment of the acute episode. After ingestion, dabigatran etexilate is converted to the active agent dabigatran by esterase, achieving peak serum concentrations in  hours with a terminal elimination half­life of  hours. Dabigatran is a reversible inhibitor of both circulating and clot­bound thrombin. Dabigatran has more predictable pharmacologic activity than warfarin, a broad therapeutic window, low interpatient variability, and no significant drug–drug (except for rifampin) or drug–diet interactions. Monitoring with standard coagulation tests during therapeutic use is not required. In routine use in patients with atrial fibrillation, dabigatran is generally safer than warfarin, with the notable exception of a higher risk of major GI bleeding. As with warfarin, the concomitant use of NSAIDs and other antiplatelet medications greatly increases the risk of bleeding for patients taking dabigatran.
,20
Prothrombin time and the activated PTT are insensitive to the activity of dabigatran, whereas the thrombin clotting time is typically overly sensitive.
The ecarin clotting time has a linear dose response through the range of dabigatran concentrations seen during clinical use, but this test is not commonly available. For practical purposes, a normal thrombin time excludes a significant coagulopathy due to dabigatran. If
 available, a diluted thrombin time is even more specific.
Only about 15% to 20% of absorbed dabigatran is metabolized, and the remainder is excreted unchanged in the urine. It is therefore important to maintain urinary output in patients with active bleeding while taking dabigatran to enhance drug elimination.
Idarucizumab (Praxbind®), a monoclonal antibody fragment that binds dabigatran, is U.S. Food and Drug Administration approved when reversal of the anticoagulant effects of dabigatran is needed for life­threatening or uncontrolled bleeding or for emergency surgery or urgent procedures (Table
,22 
239­3). The recommended dose of idarucizumab is  grams, provided as two separate vials each containing .5 grams in  mL. If bleeding continues, consider a repeat dose of  grams. If idarucizumab is not available, observational experience suggests that either anti­inhibitor coagulant
 complex (FEIBA NF or activated PCC) or prothrombin complex concentrate (four­factor PCC) may reverse the anticoagulative effect of dabigatran,
 whereas fresh frozen plasma does not. If idarucizumab is not available, hemodialysis can be effective with removal of 60% or more of the drug within
,12,21
 hours; however, hemodialysis should be performed only if idarucizumab is not available.
TABLE 239­3
Reversal of Direct­Acting Oral Anticoagulants (DOACs)
Oral Direct Thrombin Inhibitors
Dabigatran Oral activated charcoal if recent or excessive ingestion
Maintain urine output
For severe bleeding or urgent reversal, idarucizumab  grams IV infusion or bolus (provided as two separate vials each containing .5 grams/50 mL)
If idarucizumab not available and life­threatening bleeding is present, consider  units/kg IV (maximum dose 5000 units) of either aPCC or four­factor PCC
Oral Factor Xa Inhibitors
Rivaroxaban Coagulant factor Xa (recombinant), inactivated (aka, andexanet alfa): Approved for major bleeding secondary to rivaroxaban or apixaban
Apixaban Low dose: (1) Last dose of rivaroxaban or apixaban was ≥8 h or (2) last dose was <8 h andrivaroxaban dose ≤10 milligrams or apixaban
Edoxaban dose ≤5 milligrams; 400­milligram bolus IV over  min, followed by a continuous infusion of  milligrams/min for 120 min (total dose,
Betrixaban 880 milligrams)
High dose: Otherwise, 800­milligram bolus IV over  min, followed by a continuous infusion of  milligrams/min for 120 min (total dose,
1760 milligrams)
The infusion should be started within  min of the bolus.
Andexanet alfa not approved for use in edoxaban­ or betrixaban­associated bleeding
If andexanet alfa not available, for major bleeding, consider four­factor PCC  units/kg IV (maximum dose 5000 units)
Abbreviations: aPCC = anti­inhibitor coagulant complex, FEIBA, or activated prothrombin complex concentrate; four­factor PCC = prothrombin complex concentrate.
FACTOR Xa INHIBITORS
Rivaroxaban, apixaban, and edoxaban are oral direct factor Xa (FXa) inhibitors used for the treatment of venous thromboembolism and for the
,24,25 reduction of the risk of stroke and systemic embolism in patients with nonvalvular atrial fibrillation (Table 239­4). Betrixaban is used for venous
 thromboembolism prophylaxis. These FXa inhibitors have predictable pharmacologic properties and do not require routine laboratory monitoring.
TABLE 239­4
Oral Factor Xa Inhibitors
Rivaroxaban Apixaban Edoxaban Betrixaban
Typical dose  milligrams PO once a day  milligrams PO twice a day  milligrams  milligrams
PO once a day PO once a day
Oral bioavailability Dose dependent: Approximately 50%, not affected Approximately Approximately
10­milligram tablets: 80%–100% not affected by by food 62%, not 34% food Peak serum concentrations 3–4 affected by Peak serum
15­ and 20­milligram tablets: about 66% without h food concentrations food and increases to >90% with food Peak serum 3–4 h
Peak serum concentrations 2–4 h concentrations
1–2 h
Serum protein binding 92%–95% 87% 55% 60%
Metabolism Oxidative degradation by hepatic cytochrome P450 About 25% with O­methylation Minimal, <15% Hydrolysis isoenzymes CYP3A4, CYP3A5, and CYP2J2 and hydroxylation by hepatic via hydrolysis, extensively, cytochrome P450, primarily conjugation, or minimal isoenzyme CYP3A4 oxidation CYP450 metabolism
Elimination About one third excreted unchanged in the urine, About 30% in urine and 70% in 50% in urine Feces 85%, about one third excreted as inactive metabolites in feces and 50% in urine 11% the urine, and one third excreted as inactive feces metabolites in feces
Elimination half­life 5–9 h  h 10–14 h 19–27 h
Drug concentration Peak: 189–419 Peak: 91–321 Peak: 120–250 No published ranges with therapeutic Trough: 66–87 Trough: 41–230 Trough: 10–40 data doses (5th to 95th percentile), nanograms/mL
The effect of the oral FXa inhibitors on standard coagulation tests is variable and not reliable for determining therapeutic effect or overanticoagulation. The preferred most clinically available test is drug level using the anti–FXa activity assay calibrated for the specific oral FXa inhibitor
 used. Drug level (anti­FXa activity) can be measured at either peak (3 to  hours after ingestion) or trough (1 to  hours before next dose). Levels associated with therapeutic doses have been published, but clinical laboratories have not established reference ranges, nor is there a consensus as to which levels denote inadequate anticoagulation or over­anticoagulation. The primary purpose of such assays is to determine drug presence prior to invasive procedures or thrombolytic therapy and assess compliance in cases of venous thromboembolism while on therapy.
Discontinuation of the drug for at least  hours could be sufficient when there is no imminent need for reversal, as in elective or nonurgent procedures. However, in patients with renal impairment and the elderly, additional time for clearance would be required before any surgical procedures are undertaken. There is an increased risk of stroke or other thrombotic event when rivaroxaban is suddenly discontinued in patients with
 nonvalvular atrial fibrillation. When possible, another anticoagulant should be substituted.
Coagulant FXa (recombinant), inactivated (andexanet alfa), is a recombinant modified human FXa decoy protein that is U.S. Food and Drug

Administration approved for treatment of life­threatening or uncontrolled bleeding due to rivaroxaban and apixaban. The dose of andexanet alfa is determined by (1) the timing of the last dose and (2) the dose (Table 239­3). The low­dose regimen is used if (1) the last dose was taken ≥8 hours previously or (2) if the last dose was taken within  hours and the dose of rivaroxaban was ≤10 milligrams or the dose of apixaban was ≤5 milligrams.
Otherwise, the high­dose regimen should be used. Two important potential complications were observed after andexanet alfa administration: thromboembolic events (18% of patients within  days of treatment, mostly related to non­reinstitution of therapeutic anticoagulation) and infusion­
 related reactions (e.g. flushing, feeling hot, cough, dyspnea, distorted taste, mild hives), which also occurred in 18% of patients.
Due to high plasma protein binding, FXa inhibitors are not readily removed by dialysis. If andexanet alpha is not available, other options for the
,8,24,29 emergency reversal include activated anti­inhibitor coagulant complex (FEIBA NF or activated PCC) or PCC (four­factor PCC).
Administration of activated charcoal within  hours of taking an oral anticoagulant may adsorb the drug from the intestines before it reaches the plasma. It would be reasonable to administer activated charcoal to a patient who has deliberately or accidentally ingested an inappropriate amount of dabigatran or an FXa inhibitor, and also in a patient with significant bleeding who has recently ingested even a therapeutic dose.
HEPARINS
UNFRACTIONATED HEPARIN
Unfractionated heparin (UFH) is a heterogeneous mixture of polysaccharides ranging in molecular weight from  to  kD, with most commercial
 preparations possessing a mean molecular weight of about  kD, corresponding to about  saccharide units. The anticoagulant effect of UFH
 requires binding to antithrombin (previously named antithrombin III), and heparins are therefore “indirect” anticoagulants. Although the UFH– antithrombin complex interferes with several activated factors in both the extrinsic and common coagulation pathways (factors Xa, IXa, XIa, and XIIa, and thrombin), the primary anticoagulant effect of heparin is due to thrombin and FXa inhibition. The majority of heparin’s anticoagulant effect is dependent on a unique pentasaccharide sequence found in only about one third of heparin molecules. Variations in polysaccharide chain lengths found in UFH likely contribute to the unpredictable nature of heparin’s dose–response relationship.
UFH is given parenterally with a half­life (30 to 150 minutes) that depends on the dose and route. Weight­based IV UFH dosing protocols are the most
 reliable approach for achieving a therapeutic effect and preventing further thrombosis during acute thromboembolic events. Subcutaneous UFH is not recommended for the treatment of acute thromboembolic disease because the bioavailability via this route of administration ranges from 10% to
90%, depending on the dose. However, subcutaneous UFH can be used to prevent thromboembolism (Table 239­1). Because UFH interferes with most laboratory investigations for hypercoagulable states, these tests should ideally be ordered before the patient is anticoagulated. Neither UFH nor low­molecular­weight heparin crosses the placenta; consequently, both are safe to use in pregnancy.
UFH has an unpredictable anticoagulation effect, requires frequent monitoring, binds nonproductively to vascular endothelium and ubiquitous plasma proteins, and actually activates platelets by interacting with platelet factor . The unpredictable inhibition of thrombin by heparin is attributable to a low bioavailability from extensive nonspecific binding to serum proteins, macrophages, and endothelial cells. Therapeutic IV UFH
,31 therapy is monitored using either anti­Xa activity or the PTT (Table 239­1). The therapeutic range for anti­FXa activity is .3 to .7 IU/mL for venous thromboembolism treatment, .3 to .6 IU/mL for acute coronary syndrome treatment, and .3 to .45 IU/mL for anticoagulation in the management of
 atrial fibrillation. The therapeutic range for an activated PTT is .5 to .5 times the reference range value, typically  to 100 seconds. UFH can increase the prothrombin time by a variable amount, typically  to  seconds depending on the heparin concentration and the thromboplastin reagent used in the assay.
LOW­MOLECULAR­WEIGHT HEPARIN
Low­molecular­weight heparins (LMWHs) are polysaccharide chains ranging in molecular weight from  to  kD, with commercial preparations
(enoxaparin, dalteparin, and tinzaparin) possessing a mean molecular weight of approximately  to  kD, corresponding to about  saccharide units.

LMWH possesses many clinical advantages compared to the parent compound (Table 239­5). Both UFH and LMWH exert their anticoagulant effect by binding to and enhancing the activity of antithrombin. This interaction is mediated by a unique pentasaccharide sequence that induces a conformational change in antithrombin, enhancing binding to and inactivation of thrombin and factors Xa, IXa, XIa, and XIIa. Inhibition of thrombin is facilitated by an additional 13­saccharide group that brings the key binding regions of antithrombin and thrombin into contact. However, only the specific pentasaccharide sequence is necessary to bind to antithrombin for effective inhibition of FXa. UFH inhibits FXa and thrombin in roughly equal proportions (anti­FXa to antithrombin activity ratio of about 1) because chains of at least  saccharide units predominate. In contrast, more than half of LMWH molecules are smaller than  saccharide units, resulting in a reduced ability to inactivate thrombin and an enhanced affinity for inactivating

FXa (anti­FXa to antithrombin activity ratio between 2:1 and 4:1).
TABLE 239­5
Advantages of Low­Molecular­Weight Heparin Over Unfractionated Heparin
Pharmacologic Effects Clinical Benefit
Quick and predictable SC absorption More reliable level of anticoagulation
More stable dose response Eliminates need for monitoring
Resistance to inhibition by platelet factor  Decreased incidence of thrombocytopenia
Decreased antiheparin antibody production Greater antithrombotic effects
Greater anti­FXa activity Potential for reduced bleeding
Less antithrombin activity Absence of “rebound”
Ease of administration Outpatient therapy
LMWH is cleared by the kidneys, so bleeding complications due to accumulation of the agent can occur in patients with significant renal impairment.
Appropriate dosing of LMWH in patients with severe renal insufficiency (creatinine clearance <30 mL/min) is unclear. In patients with severe renal
 insufficiency, it is suggested that either a reduced dose of enoxaparin (50% of the usual amount) be used or UFH be administered instead. Obese
 patients (body mass index >30) should receive weight­based LMWH dosing.
The plasma half­life of LMWH is two to four times longer than UFH, allowing for once­ or twice­daily dosing. LMWH has a decreased binding affinity for plasma proteins, endothelial cells, and macrophages, thus yielding a more predictable anticoagulant and dose–response relationship, allowing for SC administration at fixed dosages. There are greatly reduced interactions with the platelet factor  receptor, resulting in a much lower incidence of
 heparin­induced thrombocytopenia than that seen with UFH. Laboratory monitoring of the activity of LMWH is unnecessary in most patients, but is
 suggested in high­risk patients (e.g., trauma, burns, critically ill) and those who experience recurrent thromboembolism while on therapy. The gold
 standard for monitoring LMWH is the chromogenic anti­FXa assay, drawn  to  hours after SC injection. The therapeutic level of LMWH for venous
 thromboembolism prophylaxis is .2 to .5 IU/mL, and the therapeutic level for venous thromboembolism treatment is .5 to .1 IU/mL.
HEPARIN COMPLICATIONS
35­37
The two major complications of heparin are bleeding and heparin­induced thrombocytopenia. Up to one third of patients receiving UFH develop
 some form of bleeding complication, with a 2% to 6% incidence of major bleeding. An increased risk of up to 20% for major bleeding is associated with concomitant conditions, such as recent surgery or trauma, renal failure, alcoholism, malignancy, liver failure, and GI bleeding, as well as the concurrent use of warfarin, fibrinolytics, steroids, or antiplatelet drugs.
,30
Bleeding in patients being treated with UFH is managed according to the clinical severity and less by activated PTT level (Table 239­6). Heparinassociated bleeding is not always reflected by a supratherapeutic activated PTT, so if bleeding develops during UFH therapy, heparin administration should be stopped immediately. Although UFH half­life is dose dependent (30 to 150 minutes), its anticoagulation effect can last up to  hours. Observation may be appropriate in less severe cases, with serial activated PTT used to determine when therapy may be resumed. Although protamine can reverse the anticoagulant effect of UFH, adverse effects are common and include hypotension, bradycardia, dyspnea, nausea, vomiting, and urticaria. Protamine should be given slowly IV at a maximum rate of  milligrams/min. Monitor aPTT starting at 5–15 min after the protamine infusion; the onset of reversal is seen within  minutes and the duration of reversal activity is about  h. Additional doses may be required if bleeding persists or the aPTT remains elevated. Reversal of subcutaneously administered heparin may require repeated or prolonged protamine administration. Allergic reactions are common, and approximately .2% of patients receiving protamine develop anaphylaxis. Thus, protamine should be reserved for major bleeding complications.
TABLE 239­6
Reversal of Parenteral Antithrombotic Therapy
Agent Management
Heparins
Minor Immediate cessation of heparin administration bleeding Supratherapeutic aPTT not always present
Anticoagulation effect lasts up to  h from last IV dose.
Observation with serial aPTT may be sufficient.
Major Protamine dose:  milligram IV per 100 units of total amount of IV UFH administered within the past  h, maximum single dose  bleeding milligrams
Protamine administration: IV slowly, maximum rate  milligrams/min
Protamine has an anaphylaxis risk.
Protamine does not completely reverse LMWH.
Enoxaparin: Protamine  milligram IV (maximum dose,  milligrams) for every  milligram of enoxaparin given in the previous  h. If 8–12 h since last enoxaparin dose, give protamine .5 milligram IV for every  milligram of enoxaparin given.
Dalteparin and tinzaparin: Protamine  milligram IV per every 100 units of dalteparin or tinzaparin given. If aPTT (measured 2–4 h after the protamine infusion) remains prolonged, give a second dose of protamine .5 milligram IV per 100 units of dalteparin or tinzaparin.
Pentasaccharides
Fondaparinux Antithrombotic effect of fondaparinux is 24–30 h.
For life­threatening bleeding, anecdotal evidence suggests rFVIIa  micrograms/kg IV is effective.
Abbreviations: aPTT = activate partial thromboplastin time; LMWH = low­molecular­weight heparin; rFVIIa = coagulation factor VIIa (recombinant); UFH = unfractionated heparin.
Platelet count may fall in 10% to 20% of patients  to  days following initiation of UFH treatment due to nonimmunologic direct platelet aggregation.
This process is sometimes termed “heparin­associated thrombocytopenia” and was previously termed “type I heparin­induced thrombocytopenia.”

The platelet nadir is typically no lower than 100,000/mm (100 ×  /L), there is no risk for associated thrombosis, and platelet count recovers within  days despite continued heparin treatment.
Heparin­induced thrombocytopenia (HIT; previously termed “type II heparin­induced thrombocytopenia”) is a syndrome due to the formation of immunoglobulin G or immunoglobulin M autoantibodies directed against both heparin and platelet factor  that activates platelets, producing both
 thrombocytopenia and a tendency for thrombosis. Thrombosis may involve the skin (similar to warfarin­induced cutaneous necrosis), major arteries
(e.g., ischemic limbs), or the veins (e.g., recurrent venous thrombosis or pulmonary embolism). The onset of HIT is usually  to  days after heparin treatment is started, but may be sooner for patients who developed an antibody from a previous heparin exposure. Although rare, one of the earliest clues is an anaphylactoid reaction within  minutes of receiving an IV bolus of heparin, often while the patient is in the ED. Patients who exhibit acute systemic reactions such as fevers, chills, hypertension, tachycardia, dyspnea, or chest pain should be evaluated for HIT by immediately obtaining a platelet count. Because a decrease in platelet count may be transient under these circumstances, the diagnosis can be missed if there is a delay in
 obtaining the platelet count.
The incidence of HIT is variable and influenced by the specific heparin preparation used, dose, duration, and patient characteristics. In general, between 1% and 3% of postoperative patients treated with UFH for  to  days will develop HIT, compared with only .1% to .0% of medical or obstetric patients who receive UFH for a similar duration. HIT is approximately  times less frequent in patients treated with LMWH products. With HIT,
  the platelet count nadir is variable, typically ,000 to 150,000/mm (20 to 150 ×  /L). During treatment with UFH, it is recommended that a baseline platelet count be obtained and the count be repeated at  hours and every  to  days thereafter during the duration of therapy. A drop of 50% or more from baseline is considered evidence of HIT, even if the platelet count is within a normal range. It is recommended to assess for recent use of UFH or LMWH before instituting heparin therapy for a new venous thrombosis that may, in fact, be a thrombotic complication of HIT.

A scoring system (4Ts score) has been developed to assist in the diagnosis of HIT, scoring the severity of thrombocytopenia; the timing of platelet count fall; the presence of new thrombosis, skin necrosis, or systemic reaction after IV heparin bolus; and the lack of other causes for thrombocytopenia.
With HIT, all heparin therapy (including “heparin lock” IVs and heparin­coated catheters) should be stopped. Protamine is not effective against the immune­mediated response. Platelet transfusion is not indicated because bleeding is not usually a manifestation of HIT and may precipitate thrombosis. The platelet count generally returns to normal in  to  days after heparin discontinuation. During the recovery phase, the risk of arterial or venous thrombosis is substantially elevated, and the potential complications include gangrene, stroke, and myocardial infarction. LMWH is not recommended to prevent thrombosis during this recovery period because of cross­reactivity between LMWH and the antiplatelet antibody.
Additionally, warfarin should not be started until the platelet count has normalized and the patient is sufficiently anticoagulated by an alternative measure to avoid precipitating arterial or venous thrombosis or producing skin necrosis. Anticoagulation with a non­heparin anticoagulant, such as danaparoid, lepirudin, fondaparinux, or bivalirudin, is recommended for strongly suspected or confirmed cases of HIT,
,36,39 even in the absence of symptomatic thrombosis.
In general, LMWH preparations cause less bleeding than UFH. Other reported side effects of LMWH include local skin reaction, pruritus, and rarely skin necrosis. Protamine will neutralize the inhibitory effect of LMWH on thrombin but not the inhibitory effect on FXa. Thus, protamine will not completely reverse the anticoagulant effect of LMWH (Table 239­6).
FONDAPARINUX AND HIRUDINS
FONDAPARINUX
Fondaparinux is a synthetic pentasaccharide that binds to antithrombin and enhances its affinity for FXa, but not thrombin. It is not considered a heparin product and does not cause HIT. It is used in venous thromboembolism prophylaxis and treatment, and is typically recommended as one
,30,40 alternative antithrombotic that can be used in patients with a history of HIT. Fondaparinux is administered by SC injection using fixed doses stratified according to the indication and body weight (Table 239­1). The drug has a terminal half­life of about  hours, which allows for once­daily dosing. Laboratory monitoring of the activity of fondaparinux is unnecessary in most patients. If required, adequacy of anticoagulation is measured using anti–FXa activity assay obtained  hours after drug administration, with a therapeutic range for venous thromboembolism treatment of .8 to .2
IU/mL. For fondaparinux­associated bleeding, limited data suggest that coagulation factor VIIa (recombinant) and anti­inhibitor coagulant complex
,41,42
(activated PCC) can reverse the coagulopathy.
HIRUDINS
Hirudins (hirudin and lepirudin) and hirudin analogs (bivalirudin and argatroban) are polypeptides and parenteral direct thrombin inhibitors,
,30 possessing several potential advantages over heparin. Unlike heparin, direct thrombin inhibitors are capable of inhibiting both circulating and clot­bound thrombin, do not inhibit other coagulation pathway or fibrinolytic enzymes, do not require antithrombin as a cofactor for activity, and do not interact with platelet factor  or plasma proteins. Therefore, direct thrombin inhibitors have a more predictable anticoagulant effect than UFH.
,36
Hirudin, lepirudin, and argatroban are used for anticoagulation in patients with heparin­induced thrombocytopenia. Bivalirudin and argatroban
,44 are potential alternatives to UFH and LMWH for the treatment of acute coronary syndrome with percutaneous coronary intervention.
The primary adverse effect of direct thrombin inhibitors is bleeding, and the majority of bleeding events occur at invasive sites. Because the half­life of hirudin and its analogs is relatively short (<1 hour) and an antidote is not currently available, management of hemorrhage may require only stopping the IV infusion and waiting. Coagulation factor replacement with fresh frozen plasma or PCC can be used if bleeding persists.
ANTIPLATELET AGENTS
ASPIRIN
Aspirin irreversibly blocks cyclooxygenase, an enzyme that in platelets catalyzes the conversion of arachidonic acid to thromboxane A and in the

,46 blood vessel wall promotes prostacyclin synthesis (Table 239­7). The net effect of aspirin in ischemic arterial beds depends on the balance between reduction in thromboxane A (a vasoconstrictor and platelet­aggregation inducer) and reduction in prostacyclin (a vasodilator and platelet­
 aggregation inhibitor). Aspirin’s antithrombotic effect can be seen with doses as low as  milligrams, but for reliable antiplatelet effect, an initial dose of 162 to 325 milligrams is recommended (Table 239­1).
TABLE 239­7
Oral Antiplatelet Agents
Time
Duration of
Type of to Elimination
Class/Mechanism of Action Antiplatelet Typical Dose
Inhibition Peak Half­Life
Effect
Effect
Aspirin Nonselective cyclooxygenase Irreversible  min 15–30 min Up to  d 325 milligrams PO initial dose for ACS inhibitor Maintenance doses 81–162 milligrams
PO once per day
Clopidogrel ADP receptor inhibitor Irreversible 3–7 d  h Up to  d 300 milligrams PO loading dose
Prodrug; requires production of (consider 600 milligrams if PCI is active metabolite planned) followed by  milligrams PO once per day
Prasugrel ADP receptor inhibitor Irreversible  min  h 5–7 d  milligrams PO loading dose,
Prodrug; requires production of followed by  milligrams (5 milligrams active metabolite if <60 kg) PO once per day
Ticagrelor ADP receptor inhibitor Reversible .5 h  h 3–4 d 180 milligrams PO loading dose, followed by  milligrams PO twice per day
Dipyridamole Multiple: reduces platelet Reversible N/A Biphasic:  1–2 d 200 milligrams extended­release PO aggregation, vasodilator, weak min and  h twice per day (usually combined with phosphodiesterase inhibitor low­dose aspirin)
Cilostazol Phosphodiesterase inhibitor: Reversible N/A 11–13 h 3–4 d 100 milligrams PO twice per day reduces platelet aggregation, vasodilator
Abbreviations: ACS = acute coronary syndrome; ADP = adenosine diphosphate; N/A = not applicable; PCI = percutaneous coronary intervention.
Aspirin is quickly absorbed in the upper GI tract (unless consumed in an enteric­coated formulation), reaches peak blood concentrations in  to  minutes, and circulates with a half­life of  to  hours. However, cyclooxygenase inactivation is irreversible and lasts for the life span of the platelet.
46­48
Only non–enteric­coated aspirin should be administered when prompt onset of action is necessary, as in patients with acute coronary syndrome.
Side effects of aspirin use are mainly GI and are dose related. The side effects may be reduced in the maintenance therapy setting with concomitant use of antacids, enteric coating, and buffering agents. Aspirin should be avoided in patients with known hypersensitivity and used cautiously in those with bleeding disorders or severe hepatic disease. Active GI hemorrhage (e.g., bleeding peptic ulcer) is a contraindication to aspirin use. However, in acute coronary syndrome with occult GI bleeding (e.g., guaiac­positive stool), most experts favor aspirin use with careful monitoring. Daily aspirin therapy is advocated in the prevention of cardiovascular events in patients with known cardiovascular disease. The benefits in patients without cardiovascular
48­50 disease (termed primary prevention) are modest and almost offset by the risk of hemorrhagic stroke and major bleeding. In general, daily aspirin therapy does reduce recurrence of myocardial infarction, ischemic stroke, and sudden cardiovascular death (termed secondary prevention), with an increased risk of major bleeding events, primarily GI, and cerebral hemorrhage. The overall effect tends to be beneficial, although the magnitude of change with individual outcomes does vary with indication and between genders.
NSAIDs reversibly inhibit platelet cyclooxygenase and have the potential to reduce the antiplatelet efficacy of aspirin. Myocardial infarction patients
 have an increased risk of mortality, reinfarction, heart failure, and shock if taking NSAIDs within  days of presentation and up to  days after the
 52­55 acute event. Current acute coronary syndrome guidelines contain cautions about the use of NSAIDs.

Upper GI irritation is the most common side effect of aspirin therapy. Some patients are markedly sensitive to aspirin, such that even low doses lead to markedly prolonged bleeding times and risk of severe clinical hemorrhage, particularly related to surgery or trauma. Uremia and the combination of ethanol and aspirin are two circumstances where patients are especially sensitive to bleeding induced by aspirin.
Management of acute aspirin­induced or NSAID­induced hemorrhage involves the transfusion of enough normal platelets to increase the platelet
  count by ,000/mm (50 ×  /L), a level that will halt most bleeding (Table 239­8). While desmopressin can reverse the effect of aspirin on platelet
 function, it is not a safe option as it can lead to arterial vasospasm. Because of the irreversible effect of aspirin on platelets, the hemostatic compromise might last for up to  days after aspirin has been discontinued, and platelet transfusions may have to be repeated daily.
TABLE 239­8
Reversal of Oral Antiplatelet Agents
Aspirin and NSAIDs Desmopressin .3–0.4 microgram/kg IV over  min
Platelet transfusion to increase count by ,000/mm3 (typically requires one single donor apheresis­collected platelet concentrate or  units of random donor platelets)
Aspirin­induced platelet inhibition may last for  d, so repeat platelet transfusions are sometimes required.
Other antiplatelet agents: clopidogrel, Platelet transfusion to increase count by ,000/mm3 (typically requires one single donor apheresis­collected prasugrel, ticagrelor platelet concentrate or  units of random donor platelets)
Desmopressin .3–0.4 microgram/kg IV over  min
NSAID­induced platelet inhibition typically lasts <1 d.
Clopidogrel­, prasugrel­, or ticagrelor­induced platelet inhibition may last up to 5–7 d.
ADENOSINE DIPHOSPHATE RECEPTOR AGENTS (CLOPIDOGREL, PRASUGREL, TICAGRELOR, TICLOPIDINE)
,56
Clopidogrel, prasugrel, ticagrelor, and ticlopidine inhibit platelet activation by blocking the adenosine diphosphate receptor. These agents are also termed “membrane­deforming” agents because by inhibiting the adenosine diphosphate receptor, the adjacent region of the platelet membrane containing the fibrinogen receptor is deformed and the fibrinogen receptor is rendered ineffective.
Clopidogrel is a prodrug that is metabolized into an irreversible adenosine diphosphate receptor inhibitor. Rapidly absorbed from the GI tract, oral doses of 600 milligrams result in a full antiplatelet effect by  hours that is sustained for up to  hours. Platelet function typically returns to normal 
,56 days after the last clopidogrel dose. Clopidogrel is used for the treatment of acute coronary syndrome and established peripheral arterial
   disease, as well as for secondary prevention of myocardial infarction and ischemic stroke. Although clopidogrel is generally well tolerated, adverse effects include dyspepsia, rash, and diarrhea. Clopidogrel can also be used in patients who have a history of aspirin hypersensitivity or major
GI intolerance.
The active metabolite is produced by the cytochrome P450 system, principally isoenzyme 2C19 (CYP2C19). Patients with a diminished CYP2C19 metabolizer status have a lessened antiplatelet response to clopidogrel. The reported frequency for poor CYP2C19 metabolizer status varies by ethnic background: approximately 2% for whites, 4% for blacks, and 14% for Chinese. A patient’s CYP2C19 metabolizer status can be determined with genotype testing, and a higher dose regimen (600­milligram loading dose followed by 150 milligrams once daily) is suggested in poor metabolizers,
 although this dose regimen has not been validated in clinical outcome trials. Omeprazole and esomeprazole are inhibitors of CYP2C19 and reduce the antiplatelet activity of clopidogrel if given within  hours of each other. While the effect on clinical outcome from this interaction is variable according to the patient’s risk for cardiovascular events, it is prudent instead to give pantoprazole in the ED to patients receiving clopidogrel for acute
 coronary syndrome.
Prasugrel, like clopidogrel, is a prodrug that is converted to the active metabolite that is an irreversible inhibitor of the adenosine diphosphate
  receptor on platelets. Prasugrel is used in the treatment of acute coronary syndrome. Compared to clopidogrel, prasugrel has an increased risk of bleeding and is less effective in patients with a history of a stroke or transient ischemic attack, patients >75 years of age, and patients with a body weight of <60 kg.

Ticagrelor is a reversible adenosine diphosphate receptor antagonist that does not need to be converted by the liver into an active metabolite.
,62
Ticagrelor is used in a broad range of acute coronary syndrome patients. Compared with clopidogrel, ticagrelor reduces the subsequent deaths
 from all cardiovascular causes or myocardial infarction. There is a modest increase in the risk of major bleeding not related to coronary artery bypass graft surgery with ticagrelor and a trend toward more intracranial bleeding.
Ticlopidine is associated with significant risk for hematologic problems, such as neutropenia and thrombotic thrombocytopenic purpura. Therefore, ticlopidine is now rarely used in the United States.

Antiplatelet therapy is a risk factor for increased intracranial bleeding and worse outcome in closed head injury. The observed risk is highest with
 clopidogrel. Uncontrolled bleeding in patients on adenosine diphosphate receptor antagonist therapy should be treated with supportive therapy,
 and possibly platelet transfusions or desmopressin. (Table 239­8).
PHOSPHODIESTERASE INHIBITORS (DIPYRIDAMOLE)
,64
Dipyridamole is both a vasodilator and antiplatelet agent. The specific antiplatelet effects are multiple and include reversible phosphodiesterase
 inhibition. Clinical efficacy of dipyridamole appears to be enhanced by formation into an extended­release preparation. Current recommendations
,64 highlight the use of dipyridamole when combined with aspirin for the secondary prevention of stroke or transient ischemic attacks. A fixed combination of aspirin,  milligrams, and extended­release dipyridamole, 200 milligrams PO twice a day, is commonly used for this indication.
Dipyridamole is occasionally used in the standard formulation (not extended release) for angina prophylaxis and the prevention of prosthetic cardiac valve thrombosis when combined with warfarin or aspirin where doses of  to 100 milligrams PO three or four times a day are typical. Common adverse side effects include headache, dizziness, flushing, and abdominal pain.

Cilostazol is a strong reversible phosphodiesterase inhibitor in addition to having other effects on platelet metabolism. Cilostazol is used to
  increase walking distance in patients with peripheral arterial disease and reduce the incidence of stroke in patients with cerebrovascular disease.
GLYCOPROTEIN IIB/IIIA ANTAGONISTS (ABCIXIMAB, EPTIFIBATIDE, TIROFIBAN)
During platelet aggregation, fibrinogen binds to the glycoprotein platelet­surface IIb/IIIa receptor. Thus, fibrinogen attached to glycoprotein IIb/IIIa receptors connecting adjacent platelets represents the final common pathway for platelet aggregation. Three parenteral glycoprotein IIb/IIIa receptor
 inhibitors are currently available (Table 239­9) for use in primary coronary angioplasty. These agents are all administered as an initial IV loading dose (bolus for abciximab and eptifibatide and 30­minute infusion for tirofiban) followed by a continuous IV infusion. Abciximab is a noncompetitive glycoprotein IIb/IIIa inhibitor with a much longer platelet effect than its plasma half­life of  minutes; platelet function will take up to  hours to return to normal after discontinuing the infusion. Conversely, eptifibatide and tirofiban are competitive glycoprotein IIb/IIIa inhibitors, with a plasma half­life of approximately .5 and .0 hours, respectively, and functional platelet recovery is usually seen  to  hours after stopping either eptifibatide or tirofiban infusion.
TABLE 239­9
Glycoprotein IIb/IIIa IV Antagonists
Duration of
Mechanism of Half­
Type Antiplatelet Loading Dose Continuous Infusion
Action Life
Effect
Abciximab Monoclonal Noncompetitive  min 24–48 h .25 milligram/kg IV bolus .125 microgram/kg per min antibody inhibition (maximum,  micrograms/min) IV fragment
Eptifibatide Cyclic Competitive .5 h 3–5 h 180 micrograms/kg IV bolus over  micrograms/kg per min heptapeptide inhibition 1–2 min (maximum, .6 (maximum, 250 micrograms/min) milligrams) IV
CrCl <50 mL/min:  microgram/kg per min (maximum, .5 milligrams/h)
Tirofiban Nonpeptide Competitive  h 3–5 h  micrograms/kg per min IV for .15 microgram/kg per min inhibition  min CrCl ≤60 mL/min: .075 microgram/kg per min for up to  h
Abbreviation: CrCl = creatinine clearance.
,69
Glycoprotein IIb/IIIa inhibitors produce the greatest benefit in acute coronary syndrome patients undergoing percutaneous coronary intervention.
Delaying initiation of eptifibatide to the time of percutaneous coronary intervention results in less bleeding with otherwise similar outcomes,
 suggesting that the preferred time for administration of glycoprotein IIb/IIIa inhibitors is in the cardiac catheterization laboratory, not in the ED.
Patients receiving glycoprotein IIb/IIIa inhibitors have an increased risk for bleeding complications (often related to catheterization or coronary artery bypass surgery) but have no increased risk of intracranial hemorrhage. Treatment of major hemorrhage in patients on glycoprotein IIb/IIIa inhibitors requires red cell and platelet transfusions and replacement of coagulation factors as needed.
FIBRINOLYTICS
Although mechanisms vary, each fibrinolytic agent enhances the conversion of plasminogen to plasmin, which then enzymatically breaks apart the
70­72 fibrin component of thrombi. Currently approved fibrinolytic agents include streptokinase, anistreplase, alteplase, reteplase, and tenecteplase.
STREPTOKINASE AND ANISTREPLASE (FIRST GENERATION)
Streptokinase, derived from β­hemolytic streptococci, binds to and activates circulating plasminogen, converting it to plasmin, which in turn attacks fibrin. Circulating fibrinogen also undergoes plasmin­induced lysis, producing a state of “systemic fibrinolysis.” Streptokinase is administered as a slow infusion (usually .0 to .5 million units IV over  minutes) and has a serum half­life of approximately  minutes, but in most patients, the fibrinolytic effect persists for up to  hours. Because of the prolonged systemic fibrinolytic state and increased risk of hemorrhage, anticoagulation with heparin is usually delayed following treatment with streptokinase.
Anistreplase, a modified active plasminogen­streptokinase complex, has an effect similar to that of streptokinase, but its chief advantage is that it can be administered as a slow bolus (usually  units IV over  minutes) and has a serum half­life of approximately  minutes. Anistreplase has similar benefits and adverse effects compared to streptokinase.
Both streptokinase and anistreplase are antigenic, with allergic reactions occurring in approximately 6% of patients treated with streptokinase.
Antibodies to streptokinase develop approximately  days after treatment and persist for  months, so re­treatment with streptokinase or anistreplase is not advised during this interval. In addition, streptokinase or anistreplase should not be administered within  months of a streptococcal infection.
ALTEPLASE, OR TISSUE PLASMINOGEN ACTIVATOR (SECOND GENERATION)
Alteplase, or tissue plasminogen activator, is a naturally occurring enzyme in vascular endothelial cells that directly cleaves a specific peptide bond in plasminogen, converting it to active plasmin. Alteplase has binding sites for fibrin, which would suggest specificity for activity in the thrombus and less
 systemic fibrinolysis. Despite the in vitro clot specificity of alteplase, its clinical side effect profile is comparable to that of other fibrinolytics. The serum half­life of alteplase is <5 minutes, and it produces a shorter fibrinolytic state than streptokinase. Heparin is commonly administered shortly
,72 after the completion of alteplase infusion. Unlike streptokinase and anistreplase, alteplase is not antigenic; allergic reactions occur in <2% of patients treated with alteplase and IV heparin. Depending on the indication, alteplase is given as a weight­based dose via an IV infusion over  to  minutes.
RETEPLASE AND TENECTEPLASE (THIRD GENERATION)
Both reteplase and tenecteplase are derived from modifications of the parent alteplase molecule, with the intent of improving both efficacy and
 safety. Reteplase is a deletion mutant in which the fibronectin finger (high­affinity fibrin binding), epidermal growth factor, and kringle­1 (receptor binding) regions of the wild­type alteplase molecule have been deleted. These modifications prolong the half­life of reteplase to 13­16 minutes, nearly
,71,72 fourfold longer than alteplase, allowing for bolus administration of reteplase as opposed to infusion administration of alteplase.
Tenecteplase is created using amino acid substitutions in four different regions of the alteplase molecule, with the intention of producing a product
 with a longer half­life, higher level of fibrin specificity, and extended duration. The long half­life of tenecteplase (20­24 minutes) allows for weighttiered bolus dosing. The specific amino acid substitutions produce a 14­fold greater fibrin specificity than alteplase and reduced systemic plasmin generation. Tenecteplase has a plasminogen activator inhibitor  resistance  times greater than alteplase, thus allowing for a longer association of tenecteplase with the fibrin­rich clot. In addition, tenecteplase does not stimulate an increase in thrombin­antithrombin complexes, in contrast to a fourfold increase following administration of streptokinase and a twofold increase after administration of alteplase, with the potential for reduced bleeding complications with tenecteplase.
Despite theoretical advantages associated with genetic modification, neither reteplase nor tenecteplase demonstrates an absolute mortality or safety benefit in the treatment of ST­segment elevation myocardial infarction. Although bolus­dose fibrinolytics result in fewer medication errors, when
,74 compared with more complicated regimens, this has not translated into improved patient outcomes.
Tenecteplase is not FDA approved for acute ischemic stroke, but is used in other countries and the 2018 American Heart Association­American Stroke
Association (AHA­ASA) Guidelines for the Early Management of Patients with Acute Ischemic Stroke contained a level IIb recommendation that
 tenecteplase might be considered as an alternative to alteplase. Meta­analysis of five randomized controlled trials comparing tenecteplase to
 alteplase found equivalent rates of functional outcomes, mortality, and symptomatic intracranial hemorrhage. A tenecteplase dose of .25
 milligrams/kg was recommended based on benefits without the increased risk for intracranial hemorrhage seen with higher doses.
CONTRAINDICATIONS TO FIBRINOLYTIC THERAPY
All available fibrinolytic agents have systemic antithrombotic effects and possess the potential for serious hemorrhage. Fibrinolytic­induced bleeding can be minor (such as oozing at IV sites), major (defined as hemodynamic compromise or significant drop in hemoglobin), or catastrophic (intracranial hemorrhage). The prevalence with which bleeding occurs varies according to the condition being treated. For example, intracranial hemorrhage
 typically occurs in <1% of patients treated with fibrinolytics for acute myocardial infarction but is seen in approximately 6% of patients treated with
 alteplase for acute ischemic stroke. Also, the risk of hemorrhage is increased according to patient characteristics and the use of concomitant drugs
 that also vary according to the condition under treatment. General contraindications to fibrinolytic therapy are designed to reduce the risk of major and catastrophic bleeding (Table 239­10).
TABLE 239­10
General Contraindications to Fibrinolytic Therapy
Absolute
Active or recent (<14 d) internal bleeding
Ischemic stroke within the past 2–6 mo
Any prior hemorrhagic stroke
Intracranial or intraspinal surgery or trauma within the past  mo
Intracranial or intraspinal neoplasm, aneurysm, or arteriovenous malformation
Known severe bleeding diathesis
Current anticoagulant treatment (e.g., warfarin with INR >1.7 or heparin with increased activated PTT)
Current use of a direct thrombin inhibitor or direct factor Xa inhibitor with evidence of anticoagulant effect by laboratory tests
Platelet count <100,000/mm3 (<100 × 109/L)
Uncontrolled hypertension (i.e., blood pressure >185/110 mm Hg)
Suspected aortic dissection or pericarditis
Pregnancy
Relative* Active peptic ulcer disease
Cardiopulmonary resuscitation for longer than  min
Hemorrhagic ophthalmic conditions
Puncture of noncompressible vessel within the past  d
Significant trauma or major surgery within the past  wk to  mo
Advanced renal or hepatic disease
*Concurrent menses is not a contraindication.
COMPLICATIONS OF FIBRINOLYTIC THERAPY
The most significant complications of fibrinolytic therapy are hemorrhagic, and the most catastrophic complication is intracranial hemorrhage.
Allergic reactions such as urticaria and angioedema are seen in 1% to 5% of patients treated with alteplase. Treatment includes stopping the infusion, evaluating the airway to determine the need for intubation, and administering antihistamine (e.g., diphenhydramine  milligrams IV) and corticosteroids (e.g., methylprednisolone 125 milligrams IV). Hypotension occurs in up to 10% of patients treated with either streptokinase or alteplase and is treated by slowing the fibrinolytic infusion rate and administering IV crystalloid, paying close attention to the patient’s volume status.
To minimize the bleeding risks associated with fibrinolytic therapy, the following precautions should be observed: (1) avoid all unnecessary needle sticks; (2) avoid any arterial punctures; (3) limit venous access to easily compressible sites (e.g., avoid central venous lines, especially the jugular or subclavian veins); and (4) avoid both nasogastric tubes and nasotracheal intubation.
Careful monitoring of the patient is crucial. The hemoglobin level should be checked every  to  hours after fibrinolytic therapy is initiated. A fall in hemoglobin >1 to  grams/dL (0.6 to .2 mmol/L) should prompt a search for the source of blood loss. Most bleeding episodes (>70%) occur at vascular puncture sites, but intracranial, intrathoracic, retroperitoneal, GI, urologic, or soft tissue extremity hemorrhage may occur.
External bleeding at any site should be controlled with prolonged manual pressure (Table 239­11). Significant bleeding, especially from an internal site, mandates discontinuation of the fibrinolytic agent along with any antiplatelet agents and heparin. Volume replacement should be provided as necessary and supplemented with red blood cell transfusions if clinically indicated. The thrombin clotting time, activated PTT, platelet count, and fibrinogen level should be checked. Heparin administered within  hours of the onset of bleeding can be reversed with protamine.
TABLE 239­11
Reversal of Fibrinolytic­Induced Bleeding
Minor external
Manual pressure bleeding
Significant internal Immediate cessation of fibrinolytic agent, antiplatelet agent, and/or heparin bleeding Reversal of heparin with protamine, as discussed earlier
Typed and cross­matched blood ordered with verification of activated PTT, CBC, thrombin clotting time, and fibrinogen level
Volume replacement with crystalloid and packed red blood cells as needed
Major bleeding or All measures listed for significant internal bleeding hemodynamic Fibrinogen concentrate  milligrams/kg IV, and recheck fibrinogen level; if fibrinogen level <100 milligrams/dL, repeat compromise fibrinogen concentrate dose.
If bleeding persists after fibrinogen concentrate or despite fibrinogen level >100 milligrams/dL, administer FFP  units IV.
If bleeding continues after FFP, administer an antifibrinolytic such as aminocaproic acid  grams IV over  min followed by  gram/h continuous IV infusion for  h or until bleeding stops, or tranexamic acid  milligrams/kg IV every 6–8 h.
Consider platelet transfusion.
Intracranial All measures listed for significant internal and major bleeding with hemodynamic compromise hemorrhage Immediate neurosurgery consultation
Abbreviation: FFP = fresh frozen plasma
Massive bleeding with hemodynamic compromise necessitates empiric coagulation factor replacement with fibrinogen concentrate (human) and/or fresh frozen plasma. If bleeding persists after appropriate fibrinogen and fresh frozen plasma replacement, an antifibrinolytic agent (e.g., aminocaproic acid or tranexamic acid) with or without platelets should still be administered. Fibrinolytic­associated intracranial hemorrhage requires an aggressive response with protamine (if the patient received heparin), fibrinogen concentrate (human), fresh frozen plasma, platelet transfusion, and an antifibrinolytic agent.
ANTIFIBRINOLYTIC AGENTS
Two hemostatic agents are used clinically to inhibit the enzymatic degradation of fibrin by plasmin: tranexamic acid and aminocaproic acid (Table
239­12). Both agents are derivatives of the amino acid lysine, have low molecular weight, can be administered both orally and IV, attach to several sites on plasminogen, prevent plasminogen from binding to fibrin, are minimally metabolized, and are primarily excreted by the kidney, but tranexamic acid has roughly eight times the antifibrinolytic activity of aminocaproic acid.
TABLE 239­12
Antifibrinolytic Agents
Elimination Half­
Agent Suggested Initial Adult IV Dose for Emergent Indications* Excretion
Life
Tranexamic acid (TXA)  milligrams/kg IV over  min (maximum,  gram); repeat doses every 6–8 h 95% by  h kidney
Aminocaproic acid 4–5 grams IV over  h, then  gram/h for  h or until bleeding stops (maximum,  65% by  h
(ACA) grams/d) kidney
*Doses vary between indications and route; consult prescribing information for specifics.
INDICATIONS
78­
These agents are used in hemorrhagic states to stop excessive bleeding and reduce perioperative blood transfusion requirements (Table 239­13).

Both agents had minimal use in emergency practice until a randomized clinical trial of the effect of tranexamic acid on mortality and vascular
 thrombotic events in ,211 adult trauma victims was published in 2010. This study found that tranexamic acid (1 gram IV over  minutes followed by
 gram infused over  hours) reduced death due to bleeding and all­cause mortality, assessed at  weeks, with no observed increase in vascular
 ,84 thrombotic complications. Mortality reduction was dependent on timing; efficacy was seen if administered within  hours, but not afterward.

Based on this study and additional analysis, the World Health Organization added tranexamic acid to its List of Essential Medications in 2011. There is ongoing debate about the role of tranexamic acid in trauma care, with questioning about its value in the modern trauma care systems found in heavily
 resourced counties as opposed to the resource­limited hospitals that treated the bulk of patients in the CRASH­2 study.
TABLE 239­13
Emergent Conditions Where Antifibrinolytic Agents Have Been Used
Condition Comment* Adult trauma with significant hemorrhage (BP <90 mm Hg or HR >110 TXA IV reduces death from bleeding and all­cause mortality if administered beats/min) or considered at risk for significant hemorrhage prehospital or within  h.81­85
Postpartum hemorrhage TXA IV may prevent and treat excessive postpartum hemorrhage after vaginal and cesarean delivery.87­89
Hemoptysis TXA IV or PO may reduce the duration and volume of bleeding.90,91
Upper GI bleeding TXA IV may reduce mortality and rebleeding rate; there is no effect on transfusion requirement.92
Aneurysmal subarachnoid hemorrhage No proven benefit93
Traumatic intracranial hematoma TXA decreased hematoma growth rate and total hemorrhage, but there was no change in mortality or neurologic outcome.94
GI and nasal bleeding due to hereditary hemorrhagic telangiectasia ACA PO may reduce bleeding and transfusion requirements.95,96
Dental bleeding in hemophilia FDA­approved indication for TXA PO
Prevent bleeding in hemophilia patients during surgery TXA and ACA reduce bleeding and transfusion requirements.80
Traumatic hyphema FDA­approved indication for TXA PO; both TXA and ACA prevent secondary hemorrhage.97
Epistaxis Topical or PO TXA reduces rate of rebleeding.98,99
Heavy menstrual bleeding FDA­approved indication for TXA PO; TXA available without prescription in
Europe for menstrual bleeding.
When fibrinolysis contributes to bleeding FDA­approved indication for ACA IV
Abbreviation: ACA = aminocaproic acid; BP = blood pressure; FDA = U.S. Food and Drug Administration; HR = heart rate; TXA = tranexamic acid.
*Not an FDA­approved indication unless otherwise noted.
COMPLICATIONS OF ANTIFIBRINOLYTIC AGENTS

Both drugs have potential to cause vascular thrombosis, with reported rates that vary according to thrombus location and condition being treated.

The observed incidence of limb ischemia and myocardial infarction is low (<1%). The incidence of deep vein thrombosis and pulmonary embolism is
100 highest in patients with subarachnoid hemorrhage (2% and 3%, respectively). In adult trauma, the observed incidence of deep vein thrombosis or pulmonary embolism after treatment with IV tranexamic acid was not significantly increased compared to the control group (about 1% for each
 thrombotic event).


## Page 32

[PubMed: 30117036]
. Mehta RH, Alexander JH, Van de Werf F, et al: Relationship of incorrect dosing of fibrinolytic therapy and clinical outcomes. JAMA 293: 1746, 2005. [PubMed: 15827313]
. Lansberg MG, Albers GW, Wijman CA: Symptomatic intracerebral hemorrhage following thrombolytic therapy for acute ischemic stroke: a review of the risk factors. Cerebrovasc Dis 24: , 2007. [PubMed: 17519538]
. McCormack PL. Tranexamic acid: a review of its use in the treatment of hyperfibrinolysis. Drugs 72: 585, 2012. [PubMed: 22397329]
. Tengborn L, Blombäck M, Berntorp E. Tranexamic acid—an old drug still going strong and making a revival. Thromb Res 135: 231, 2015. [PubMed: 25559460]
. Coppola A, Windyga J, Tufano A, Yeung C, Di Minno MN. Treatment for preventing bleeding in people with haemophilia or other congenital bleeding disorders undergoing surgery. Cochrane Database Syst Rev 2015 Feb ;2:CD009961. [PubMed: 25922858]
. Hunt BJ. The current place of tranexamic acid in the management of bleeding. Anaesthesia  Suppl 1: e18, 2015. [PubMed: 25440395]
. CRASH­2 trial collaborators, Shakur H, Roberts I, Bautista R, et al. Effects of tranexamic acid on death, vascular occlusive events, and blood transfusion in trauma patients with significant haemorrhage (CRASH­2): a randomised, placebo­controlled trial. Lancet 376(9734): , 2010. University of Pittsburgh
[PubMed: 20554319]
Access Provided by:
. CRASH­2 collaborators, Roberts I, Shakur H, Afolabi A, et al. The importance of early treatment with tranexamic acid in bleeding trauma patients: an exploratory analysis of the CRASH­2 randomised controlled trial. Lancet 377(9771): 1096, 2011. [PubMed: 21439633]
. Roberts I, Prieto­Merino D, Manno D. Mechanism of action of tranexamic acid in bleeding trauma patients: an exploratory analysis of data from the
CRASH­2 trial. Crit Care 18: 685, 2014. [PubMed: 25498484]
. Roberts I, Shakur H, Ker K, Coats T; CRASH­2 Trial collaborators. Antifibrinolytic drugs for acute traumatic injury. Cochrane Database Syst Rev
2012;12:CD004896. [PubMed: 23418644]
. Pusateri AE, Weiskopf RB, Bebarta V, et al; US DoD Hemorrhage and Resuscitation Research and Development Steering Committee: Tranexamic acid and trauma: current status and knowledge gaps with recommended research priorities. Shock 39: 121, 2013. [PubMed: 23222525]
. Sentilhes L, Lasocki S, Ducloy­Bouthors AS, et al. Tranexamic acid for the prevention and treatment of postpartum haemorrhage. Br J Anaesth
114: 576, 2015. [PubMed: 25571934]
. Cross C, Singh M, Jones J: BET 1: Intravenous tranexamic acid for the treatment of post­partum haemorrhage. Emerg Med J 35:523, 2018. [PubMed: 30030237]
. Franchini M, Mengoli C, Cruciani M, et al: Safety and efficacy of tranexamic acid for prevention of obstetric haemorrhage: an updated systematic review and meta­analysis. Blood Transf 16: 329, 2018. [PubMed: 29757132]
. Prutsky G, Domecq JP, Salazar CA, Accinelli R. Antifibrinolytic therapy to reduce haemoptysis from any cause. Cochrane Database Syst Rev 2012
Apr ;4:CD008711. [PubMed: 22513965]
. Moen CA, Burrell A, Dunning J. Does tranexamic acid stop haemoptysis? Interact Cardiovasc Thorac Surg 17: 991, 2013. [PubMed: 23966576]
. Bennett C, Klingenberg SL, Langholz E, Gluud LL. Tranexamic acid for upper gastrointestinal bleeding. Cochrane Database Syst Rev 2014 Nov
;11:CD006640. [PubMed: 25414987]
. Baharoglu MI, Germans MR, Rinkel GJ, Algra A, Vermeulen M, van Gijn J, Roos YB. Antifibrinolytic therapy for aneurysmal subarachnoid haemorrhage. Cochrane Database Syst Rev 2013 Aug ;8:CD001245. [PubMed: 23990381]
. Weng S, Wang W, Wei Q, et al: Effect of tranexamic acid in patients with traumatic brain injury: a systematic review and meta­analysis. World
Neurosurg 123: 128, 2019. [PubMed: 30529516]
. Annichino­Bizzacchi JM, Facchini RM, Torresan MZ, Arruda VR. Hereditary hemorrhagic telangiectasia response to aminocaproic acid treatment.
Thromb Res 96: , 1999. [PubMed: 10554087]
. Longacre AV, Gross CP, Gallitelli M, Henderson KJ, White RI Jr, Proctor DD. Diagnosis and management of gastrointestinal bleeding in patients with hereditary hemorrhagic telangiectasia. Am J Gastroenterol 98: , 2003. [PubMed: 12526937]

. Gharaibeh A, Savage HI, Scherer RW, Goldberg MF, Lindsley K. Medical interventions for traumatic hyphema. Cochrane Database Syst Rev 2013
Chapter 239: Thrombotics and Antithrombotics, David E. Slattery; Charles V. Pollack, Jr 
. Terms of Use * Privacy Policy * Notice * Accessibility
[PubMed: 24302299]
. Joseph J, Martinez­Devesa P, Bellorini J, Burton MJ: Tranexamic acid for patients with nasal haemorrhage (epistaxis). Cochrane Database Syst
Rev 2018 Dec ;12:CD004328. [PubMed: 30596479]
. Gottlieb M, DeMott JM, Peksa GD: Topical Tranexamic Acid for the Treatment of Acute Epistaxis: A Systematic Review and Meta­analysis. Ann
Pharmacother 53: 652, 2019. [PubMed: 30577703]
100. Ross J, Al­Shahi Salman R. The frequency of thrombotic events among adults given antifibrinolytic drugs for spontaneous bleeding: systematic review and meta­analysis of observational studies and randomized trials. Curr Drug Saf 7: , 2012. [PubMed: 22663958]

