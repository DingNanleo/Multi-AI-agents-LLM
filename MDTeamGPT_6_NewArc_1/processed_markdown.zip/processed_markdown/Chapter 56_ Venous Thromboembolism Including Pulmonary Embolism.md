## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 56: Venous Thromboembolism Including Pulmonary Embolism
Jeffrey A. Kline
INTRODUCTION AND EPIDEMIOLOGY
Content Update: The YEARS Algorithm for Exclusion of Pulmonary Embolism February 2020
See discussion under the section 'Decision Rules and Clinical Assessment'
Pulmonary embolism (PE) occurs when clotted blood enters the pulmonary arterial circulation. Most PEs result from deep vein thrombosis (DVT) in the legs, arms, or pelvis and occasionally from the jugular vein or inferior vena cava. The term venous thromboembolism (VTE) includes PE and DVT.
In the United States, approximately 200,000 people will have new or recurrent PE diagnosed each year, and twice that many will have DVT without
 confirmed PE. About  in 500 children (age <18 years) are tested for VTE in EDs, with about 10% being diagnosed with VTE; the rate of diagnosis in children is rising, perhaps as a result of longer survival of children with chronic complex comorbidity and increased use of estrogen­containing oral
2–4  contraceptives. VTE incidence varies slightly with geography across the United States but varies widely among hospitals. EDs with older, sicker patients diagnose more VTE cases. The incidence of VTE increases with age, peaking at  in 100 per year at age . Based on autopsy data, PE is the
 second leading cause of sudden, unexpected, nontraumatic death in outpatients. The case fatality rate from PE depends on the hemodynamic severity of the PE, age, and comorbid conditions; the case fatality rate is 45% for PE with circulatory shock, but only about 4% to 5% of patients with PE have
 shock. In patients with hemodynamically stable PE who are less than  years old and without other comorbidities, the case fatality rate is 1%.
Morbidity from PE includes the post­PE syndrome, which occurs in about 25% of patients after PE and is characterized by chronic fatigue, dyspnea,
 exercise intolerance, and low perception of health status. An extreme form of post­PE syndrome, occurring in about 3% of PE patients, is chronic
 thromboembolic pulmonary hypertension, which causes disabling dyspnea. Morbidity from DVT includes PE and the postthrombotic syndrome, with
 the latter manifested as chronic leg swelling and pain; it occurs in about 20% of all ED patients with proximal DVT. Both PE and DVT have a spectrum
 of severity, with minor forms of the disease including distal PE (called subsegmental) and distal DVT (usually in the calf or saphenous veins).
PATHOPHYSIOLOGY
Blood clots occur when coagulation exceeds the removal by fibrinolysis. Thrombophilias are conditions that tip the balance of coagulation­fibrinolysis
 toward excessive clotting. Most guidelines categorize VTE as provoked or unprovoked (also called idiopathic). Provoked VTEs are a consequence of a triggering risk factor for clots, such as recent surgery, trauma, or any condition associated with limb or body immobility; active cancer can be a persistent provoking factor for VTE. Other provoking factors generally include diseases or conditions that impede venous blood flow, infection, chronic disease, estrogen use, pregnancy or initial postpartum interval, and age >50 years (each year after  increases the risk).
,13
Most VTEs diagnosed in the ED are unprovoked. Patients with unprovoked VTE have a 15% chance of recurrence in the next year compared with 5%
 for those with a provoked episode. Those with provoked VTE have a higher 1­year death rate, likely from the comorbid conditions (notably cancer).
Venous thrombi that are large enough to cause clinically important PE can form in the popliteal, common femoral, superficial femoral, pelvic, axillary,
 jugular, and great veins. At least one third of patients with DVT have concomitant PE, even when the patient lacks symptoms of PE. Although 75% to

80% of hospitalized patients with PE have image­demonstrated DVT, only 40% of ambulatory ED patients with PE have concomitant DVT.
 
Patients without prior heart or lung disease generally begin to experience symptoms from PE with at least 20% of lung vasculature occluded. With
Chapter 56: Venous Thromboembolism Including Pulmonary Embolism, Jeffrey A. Kline larger clot burden, the pulmonary arterial pressure increases, leading to right ventricular dilation and myocardial damage, causing the release of
. Terms of Use * Privacy Policy * Notice * Accessibility troponin and B­type natriuretic peptide. Right ventricular dilation or injury, detected by an increased right ventricular to left ventricular ratio on CT scan or echocardiography; right ventricular strain suggested by elevated troponin or B­type natriuretic peptide; or signs of an acute pulmonary
18–20 hypertension on 12­lead ECG indicate right heart failure and increased risk of circulatory shock and death. Patients with PE generally die from one of the following two mechanisms:
. Abrupt near­total pulmonary artery occlusion that leads to pulseless electrical activity or asystole from ischemic effect on the His­Purkinje conduction system.
. Progressive right heart failure and circulatory shock, which occurs over hours to days.
Blood clots in the femoral and iliofemoral veins usually form on the valves, leading to scarring and poor function of the venous valves. This causes venous reflux and pooling of venous blood in the legs, leading to varicose veins, pain, swelling, skin hyperpigmentation, and ulcers, known as the
 postthrombotic syndrome.
Inherited thrombophilias increase risk of first­time VTE, although most of these patients are unaware of this condition until a clot occurs. The risk of
 recurrent VTE in those with a known thrombophilia is the same as patients with unprovoked VTE and no known thrombophilia.
With limb immobility, VTE risk increases depending on joint, as follows: elbow (least), shoulder, ankle, knee, and hip (most). Acute immobilization of the hip and knee in one leg with non–weight bearing causes the greatest risk for VTE, whereas immobilization of the wrist alone probably causes no added risk. In addition to the presence of limb immobility, risk of VTE increases with whole­body immobility or neurologic immobility and with travel >8
 hours.
Over half of patients with postoperative PE are diagnosed after hospital discharge, and the average time from surgery to PE diagnosis is >10 days. Risk increases with patient age, longer surgery, open surgery, and surgery absent thromboprophylaxis. The highest­risk surgical procedures include abdominal surgery to remove cancer, joint replacement surgery, and surgery on the brain or spinal cord in the setting of neurologic deficits. The 4­year
 risk of postsurgical acquired PE recurrence ranges from 5% to 11% per year depending on the procedure.
Thrombogenic potential of cancer varies with host factors, tumor stage, and tumor type. In general, the risk of VTE increases with the more undifferentiated the cell type and the larger the tumor burden (especially distant metastasis). Adenocarcinoma (pancreatic, ovarian, and colon),
 glioblastoma, metastatic melanoma, lymphoma, and multiple myeloma are particularly thrombogenic. Cancers with lower risk of VTE include localized breast, cervical, prostate, and nonmelanomatous localized skin cancers such as squamous cell carcinoma and basal cell carcinoma not treated with chemotherapy. In general, patients with cancer are at their highest risk of developing VTE during chemotherapy.
 ,26
A family history of VTE increases longitudinal risk of VTE and may increase risk of VTE diagnosis in symptomatic ED patients. Although sex does
 not significantly modify the risk of first­time VTE, men have more recurrent VTE.
Table 56­1 presents a list of risk factors for VTE relevant to ED practice.
TABLE 56­1
Risk Factors for Venous Thromboembolism (VTE) That Are Generally Relevant to Emergency Medicine
Factor Comment
Age Risk becomes significant at  y and increases with each year of life until age  y.
Obesity In the general population, VTE risk starts at BMI >35 kg/m2 and increases with increasing BMI.
Pregnancy and postpartum PEs can occur in any trimester and postpartum.
state
Prior VTE Highest risk of recurrence is for unprovoked VTE in men, particularly if D­dimer remains elevated.
Solid cancers Risk greatest with adenocarcinomas and metastatic disease. A history of remote, inactive cancer probably does not increase risk.
Hematologic cancers Acute leukemias and myeloma confer the greatest risk, particularly when treated with L­asparaginase and the thalidomide derivatives.
Thrombophilias Non­O blood type, lupus anticoagulant, shortened aPTT, factor V Leiden, and familial protein C and S and antithrombin deficiency have the strongest risk.
Recent surgery or major Risk increased with endotracheal intubation or epidural anesthesia and continues at least  weeks after exposure. Risk trauma varies with type of surgery.
Immobility Acute limb immobility of two contiguous joints confers the highest risk.
Bed rest Becomes a risk factor at approximately  h.
Indwelling catheters Cause approximately one half of arm deep venous thromboses.
Long­distance travel Published data are controversial. In general, risk becomes significant after  h of continuous travel.
Smoking A population risk factor, but not a factor that increases probability of VTE in the ED setting. May increase risk of other factors such as obesity.
Congestive heart failure Related primarily to severity of systolic dysfunction.
Stroke Risk greatest in first month after deficit.
Estrogen Highest­risk period is in the first few months. All contraceptives containing estrogen increase risk of VTE including transdermal and transvaginal preparations.
Noninfectious inflammatory Examples are inflammatory bowel disease, lupus, and nephrotic syndrome. Risk of VTE increases roughly in proportion to conditions severity of underlying disease.
Abbreviations: aPTT = activated partial thromboplastin time; BMI = body mass index; PE = pulmonary embolism.
Although smoking causes conditions that increase risk (e.g., cancer) and acts synergistically with obesity and possibly oral contraceptive use, smoking
 alone does not increase the risk of VTE diagnosis in symptomatic ED patients.
Patients with missed PE who are admitted to the hospital for other reasons tend to have a higher frequency of altered mental status (either new or
28–31 existing) and preexisting heart and lung disease. One study examined patients discharged with PE and found they were more likely to not have dyspnea, but instead to have isolated pleuritic chest pain and hemoptysis together with a pulmonary infiltrate on imaging and a lower D­dimer
 concentration with a small distal clot seen on pulmonary vascular imaging.
CLINICAL FEATURES OF PULMONARY EMBOLISM
PE symptoms range from none to sudden death. Patients with similar comorbidities and clot burden may have drastically different clinical presentations. Table 56­2 lists factors that affect symptoms.
TABLE 56­2
Factors That Can Affect the Clinical Presentation of Patients With Pulmonary Embolism (PE)
Cofactor Clinical Impact Comment
Previously healthy Less severe signs and symptoms One half of previously healthy patients with first­time PE have normal vital sign values at and young age diagnosis.
Prior Can either amplify or obscure Most patients with PE complicating baseline cardiopulmonary disease describe dyspnea cardiopulmonary history and findings with PE as “worse than usual.” disease
Patient cognitive Causes the history to be less Approximately 20% of patients with PE missed by ED clinicians had baseline dementia.
dysfunction reliable
Clot size and location Affects severity of dyspnea, pain, Proximal clots cause ventilation–perfusion mismatch and dyspnea; distal clots cause and signs infarction with pain.
Gradual loading of PE Gradual onset of dyspnea on Has symptom overlap with left ventricular dysfunction. Fewer than one half of patients over time exertion and fatigue with PE describe symptom onset as sudden.
The hallmark of PE is dyspnea unexplained by auscultatory findings, ECG changes, and without a clear alternative diagnosis on chest radiograph. Chest pain with pleuritic features is the second most common symptom of PE, although about one half of all patients diagnosed with PE in the ED have no
 chest pain. The classic PE pain is in the thorax between the clavicles and the costal margin that increases with cough or breathing; it is not substernal and emanating from the skin or muscle. Pulmonary infarction (lung tissue destruction) can inflict severe focal pain, usually occurring  to  days after
 the embolic event. Pulmonary infarction in basilar lung segments can refer pain to either shoulder, or it can mimic biliary or ureteral colic. Proximal
PE without infarction can also cause pleuritic chest pain without focal pain.
HISTORY
In addition to the common symptoms of chest pain and dyspnea, approximately 3% to 4% of ED patients with PE have syncope, and another 1% to 2%
 present with new­onset “seizure” (or convulsion­like activity) or confusion. Because about 20% of people have a patent foramen ovale, PE that increases right­sided pressures can lead to right­to­left transit of thrombotic material in the atria and showers into the brain circulation, producing stroke­like symptoms called the paradoxical embolism syndrome. Neurologic symptoms can vary widely, from classic localized findings to staring spells, transient altered mental status, and atypical myelopathy symptoms (e.g., numbness in an extremity or below the waist), all of which can
 fluctuate. Presence of a patent foramen ovale worsens the prognosis in PE.
PHYSICAL EXAMINATION
On physical examination, abnormal vital signs suggest acute cardiopulmonary stress in a patient with PE; these include tachycardia, tachypnea, a lowered pulse oximetry reading, and sometimes mild fever. Unfortunately, PE does not predictably alter any vital sign; approximately one half of patients with proven PE have a heart rate of <100 beats/min at diagnosis, and approximately one third have abnormal early vital signs that normalize in
 the ED. The mechanism of altered vital signs results in obstruction to blood flow and clot­derived autacoids, which together stimulate adrenergic efferent fibers to the heart and cause ventilation–perfusion mismatch on the lungs. The amount of clot burden does not predict vital sign changes reliably, with no clear correlation between measured clot and initial heart rate or oximetry. Fever neither increases nor decreases the probability of PE diagnosis in symptomatic ED patients.
The physical examination, aside from vital signs, is most likely to be helpful through two findings:
. Unilateral limb swelling (with or without an indwelling catheter), which increases probability of PE diagnosis by three­fold
. Wheezing, which reduces probability of PE by one half
Most patients with PE have clear lungs on auscultation. Wheezes or bilateral rales make an alternative diagnosis of bronchospasm or pneumonia possible but do not completely exclude PE; pulmonary infarction may produce rales over the affected lung segment. The overall gestalt interpretation of “sick/not sick” appearance of ED patients with possible PE can be deceiving; one study found that patients diagnosed with PE were more likely to
 smile during their physical examination.
PULSE OXIMETRY, CHEST RADIOGRAPH, AND ECG
Pulse oximetry, chest radiograph, and ECG obtained in the ED generally demonstrate nonspecific findings in patients with PE. The mean pulse oximetry reading is lower in patients with proven PE than in those without PE; while lowered room air oxygen saturation is common, a pulse oximetry reading of
100% does not reliably exclude PE. Spontaneously breathing patients with PE also demonstrate a lower end­tidal carbon dioxide compared with
 healthy individuals.
Most patients with PE have a chest radiograph with one or more abnormalities, including cardiomegaly, basilar atelectasis, infiltrate, or pleural effusion; all are nonspecific for PE. In <5% of patients, a wedge­shaped area of lung oligemia (called Westermark’s sign—usually from complete lobar artery obstruction) or peripheral dome­shaped dense opacification (Hampton’s hump—indicative of pulmonary infarction) exists. The presence of hypoxemia or dyspnea with clear lungs on physical exam and chest radiography suggests the need to test for PE.
Findings of acute pulmonary hypertension on ECG increase the probability of PE. These findings are not typically recognized by computer interpretations and include a heart rate >100 beats/min, T­wave inversion in leads V to V , incomplete or complete right bundle branch block, and the

S ­Q ­T pattern (Figure 56­1). A clinical ECG score also allows severity assessment in those with diagnosed PE (higher score equates to higher

,39 mortality, Table 56­3; See Video: ECG: Pulmonary Embolism).
Figure 56­1
This 12­lead ECG shows many features of a severe pulmonary embolism: tachycardia, an incomplete right bundle branch block, an S ­Q ­T pattern,
   and T­wave inversion in the anterior leads. [Image contributed by Department of Emergency Medicine, Wake Forest Baptist Hospital.]
TABLE 56­3
ECG Scoring Method to Assess Severity of Pulmonary Embolism39
Characteristics Score
Tachycardia (>100 beats/min) 
Incomplete right bundle branch block 
Complete right bundle branch block 
T­wave inversion in leads V through V 

T­wave inversion in lead V * 
<1 mm 
1–2 mm 
>2 mm 
T­wave inversion in lead V * 
<1 mm 
1–2 mm 
>2 mm 
T­wave inversion in lead V * 
<1 mm 
1–2 mm 
>2 mm 
S wave in lead  
Q wave in lead  
Inverted T wave in lead  
If all S ­Q ­T pattern, add 

Total score (maximum: 21)
*If present, check maximum only.
Video 56­1: ECG: Pulmonary Embolism
Used with permission from Moshe Weizberg, MD.
Play Video
CLINICAL FEATURES OF DEEP VEIN THROMBOSIS
Patients with DVT complain of extremity pain, swelling, or cramping. A difference of ≥2 cm between right and left leg diameter at  cm below the tibial tubercle doubles the likelihood of DVT. Patients presenting with upper extremity catheter­related DVT often complain of hand swelling or tightness around finger rings. About one quarter of patients with DVT have tenderness and redness in the swollen extremity, findings that are like those of cellulitis. Calf or saphenous vein clots are more likely to cause thrombophlebitis, defined formally as inflammation (pain, tenderness, redness, and swelling) over a vein secondary to the presence of thrombotic material in the vein. Signs and symptoms of thrombophlebitis can persist after the venous recannulation and after the clot has dissolved entirely. Calf vein thrombosis may cause Homan’s sign, which is calf pain that occurs with passive foot dorsiflexion; this test has such low sensitivity and specificity that it has no predictive value.
Proximal DVT that causes complete venous obstruction can create elevated compartmental pressures, manifested as an extremely painful, swollen extremity. Phlegmasia alba dolens is a swollen, painful, and pale or white limb with a proximal venous thrombosis, whereas a limb with a dusky or blue color is phlegmasia cerulea dolens. Either condition poses the threat of limb loss, demanding aggressive treatment that can include clot disruption.
DIAGNOSTIC TESTING FOR VENOUS THROMBOEMBOLISM
DECISION RULES AND CLINICAL ASSESSMENT
Estimating the pretest probability for VTE in a patient is the first step in selecting a diagnostic pathway. Figure 56­2 shows the author’s diagnostic algorithm; no singular diagnostic test or algorithm perfectly excludes or diagnoses VTE. Aggressive diagnostic searches can cause harm from hemorrhage caused by anticoagulation for a false­positive result or self­limited small clot diagnosis or from toxicity related to testing
 itself, such as contrast allergies, kidney injury, or cancer risk. One approach is to test further only in those with pretest probabilities of >2.5% ; those with a pretest probability of PE of <2.5% are more likely to be harmed—either directly or by responding to a test result with more testing or care—than helped by a diagnostic test, including a simple D­dimer assay.
Figure 56­2
Proposed algorithm for evaluation of suspected pulmonary embolism. Begin with the pulmonary embolism rule­out criteria (PERC) rule—diagnostic algorithm for pulmonary embolism (PE). *Some physicians prefer to start with a clinical decision rule such as the Wells’ score (where <2, 2–6, and >6 are used instead of <15%, 15% to 40%, and >40%, respectively). Note: Determine renal function by clinical picture (healthy, no risk factors for reduced glomerular filtration rate [GFR]) or calculated GFR. Nondiagnostic ventilation–perfusion (V̇/Q̇) scan findings require confirmation from results of another test, such as CT pulmonary angiography (CTPA), if benefits outweigh risks. + = positive for PE; – = negative for PE; Bilat LE CUS = bilateral lower extremity compression US; Cr = creatinine; FEU = fibrinogen equivalent units; High = high­probability scan findings; LMWH = low­molecular­weight heparin; Nondiagnostic = any reading other than normal or high probability; quant = quantitative; SPECT = single­photon emission CT; sRGS = simplified, revised Geneva score; V̇/Q̇ = ventilation/perfusion ratio.
The PE rule­out criteria (Table 56­4) reliably forecast a probability of PE that is below the .0% test threshold in patients with a gestalt low clinical
41–43 suspicion. The American College of Emergency Physicians, the American College of Physicians, and the American Society of Hematology current
44–46 ,47 guidelines all recommend use of the PE rule­out criteria rule, which has been validated in multiple groups. The weight of the available information indicates that PE can be reliably excluded by the combination of a low gestalt pretest probability plus a negative PE rule­out criteria rule.
However, not all patients with any positive PE rule­out criteria must undergo an objective test for PE, since anyone over  years old would be tested with any finding even if suspicion was low. The key is generating a clinical gestalt first; if low, then use the PE rule­out criteria to guide testing.
TABLE 56­4
Pulmonary Embolism Rule­Out Criteria Rule (all nine factors must be present to exclude pulmonary embolism)41
Clinical low probability (<15% probability of pulmonary embolism based on gestalt assessment)
Age <50 years
Pulse <100 beats/min during entire stay in ED
Pulse oximetry >94% at near sea level (>92% at altitudes near 5000 feet above sea level)
No hemoptysis
No prior venous thromboembolism history
No surgery or trauma requiring endotracheal or epidural anesthesia within the last  wk
No estrogen use
No unilateral leg swelling, defined as asymmetrical calves on visual inspection with patient’s heels raised off the bed
Other PE and DVT prediction tools exist. The Wells’ original rules separate patients into low­, moderate­, and high­probability groups for PE and DVT, with a stepwise increase in probability of clot presence with higher scores (Tables 56­5 and 56­6). The newer modified Wells’ scoring system classifies patients into a low­risk (score ≤4) or a non–low­risk group (score >4)  and has become popular. 
TABLE 56­5
Original Wells’ Score for Pulmonary Embolism
Factor Points* Suspected deep venous thrombosis 
Alternative diagnosis less likely than PE 
Heart rate >100 beats/min .5
Prior venous thromboembolism .5
Surgery or immobilization within prior  wk .5
Active malignancy 
Hemoptysis 
*Risk score interpretation (probability of pulmonary embolism): >6 points = high risk (78.4%); 2–6 points = moderate risk (27.8%); and <2 points = low risk (3.4%).
Source: Adapted with permission from Wells PS, Anderson DR, Rodger M, et al: Derivation of a simple clinical model to categorize patients probability of pulmonary embolism: increasing the model utility with the SimpliRED D­dimer. Thromb Haemost 2000 Mar;83(3):416­420. Figure , Pg 418. TABLE 56­6
Wells’ Score for Deep Vein Thrombosis (DVT)
Clinical Feature Points* Active cancer (treatment within  mo, or palliation) 
Paralysis, paresis, or immobilization of lower extremity 
Bedridden for >3 d because of surgery (within  wk) 
Localized tenderness along distribution of deep veins 
Entire leg swollen 
Unilateral calf swelling of >3 cm (10 cm below tibial tuberosity) 
Unilateral pitting edema 
Collateral superficial veins 
Alternative diagnosis as likely as or more likely than DVT –2
Prior history of DVT or pulmonary embolism† 
*Risk score interpretation (probability of DVT) in original Wells DVT model: ≥3 points = high risk (75%);  or  points = moderate risk (17%); <1 point = low risk (3%).
†Only awarded in the modified (dichotomized) Wells DVT model: ≤1 point = DVT unlikely; >1 point = DVT likely.
Source: Adapted from Geersing GJ, Zuithoff NP, Kearon C, et al: Exclusion of deep vein thrombosis using the Wells rule in clinically important subgroups: individual patient data meta­analysis. BMJ 348: g1340, 2014. The Wells’ rule has a subjective component—clinical judgment of the likelihood of an alternative diagnosis. Both the Charlotte and the simplified,
 revised Geneva score (Table 56­7) exclude subjective assessments.
TABLE 56­7
Revised and Simplified, Revised Geneva Score (RGS) for Pulmonary Embolism50
Points
Clinical Variable RGS* Simplified RGS†
Age >65 y  
Previous venous thromboembolism  
Surgery requiring anesthesia or fracture of lower limb in past month  
Active malignancy  
Unilateral leg pain  
Hemoptysis  
Pain on lower limb deep vein palpation with unilateral leg edema  
Heart rate
75–94 beats/min  
>95 beats/min  
*Total score of 0–3 indicates low probability, score of 4–10 indicates moderate probability, and score of >10 indicates high probability of pulmonary embolism.
†Score ≤4 indicates that pulmonary embolism is unlikely.
Unstructured gestalt pretest probability, divided into low (<15%), moderate (15% to 40%), and high (>40%) categories, is an alternative and valid
 method to estimate pretest probability; ultimately, well­done estimation using any tool or gestalt is better than none.
THE YEARS ALGORITHM TO EXCLUDE PULMONARY EMBOLISM

The high sensitivity of the newer D­dimer assays can often lead to added imaging studies, often without benefit. Two large management trials assessed whether a doubling of the D­dimer threshold to trigger imaging would safely limit testing. The YEARS algorithm (Figure 56­3) used an adaption of the Wells score (no suspected DVT, no hemoptysis, and an alternative diagnosis more likely than PE) to predict the diagnosis of PE to be unlikely, followed by the use of D­dimer with a “twice normal” threshold (1000 ng/mL in fibrinogen equivalent units, FEUs). That study found that with both low pre­test features and a D­dimer < 1000 ng/mL, an extremely low false­negative PE detection rate existed while potentially reducing the CT
 angiogram use rate by 14%. Another trial found similarly positive results using a group identified by a low pretest probability, defined by a Wells
 score of 0–4. Recently, a multicenter adaptation study of the YEARS criteria confirmed doubling the d­dimer is a safe and efficient strategy for
 patients with low pretest probability for PE.
Figure 56­3
The YEARS algorithm for exclusion of pulmonary embolism (PE). Patients who have a clinical probability of “PE unlikely” determined by the combination of no suspected DVT, no hemoptysis, and an alternative diagnosis more likely than PE should undergo D­dimer testing, and if the result is less than 1000 ng/mL in fibrinogen equivalent units (FEUs), PE can be excluded. This assumes the standard cutoff for abnormal is 500 ng/mL. Similarly, the method of clinical probability assessment can include any patient with a Wells score of 0–4 as eligible for D­dimer exclusion at <1000 ng/mL.
D­DIMER TESTING
The D­dimer assay is the only useful blood test to exclude VTE, working on the principle that clots contain fibrin that is degraded naturally through the action of plasmin. D­Dimer levels are reported either as fibrinogen equivalent units in nanograms per milliliter or D­dimer units in nanograms per milliliter. In general,  D­dimer unit equals  fibrinogen equivalent units. Different D­dimer assays have different thresholds for normal, which can generate confusion, but in general, emergency physicians are advised to use the locally recommended threshold. For PE and DVT, the diagnostic
,56 sensitivity of automated quantitative D­dimer assays ranges from 94% to 98%, and the specificity ranges from 50% to 60%. TheD­dimer has a half­life of approximately  hours and can be elevated for at least  days after symptomatic VTE.
The most common causes of a false­negative or false­positive D­dimer result are listed in Table 56­8; notably, all risk factors for VTE may elevate the
D­dimer level. D­Dimer increases with age; the acceptable normal threshold is adjusted upward for age to increase exclusionary ability in older
 patients. The most common formula studied is age×10 nanograms/mL (e.g., an 80­year­old patient would have an adjusted threshold for abnormal
 at 800 nanograms/mL). This assumes the conventional D­dimer cutoff of 500 nanograms/mL; in a large multicenter study, this adjusted approach resulted in a very low false­negative rate (0.3%) when used in conjunction with a Wells’ score ≤4 or a simplified revised Geneva score <5.  The YEARS study reported that patients with a low pretest probability and a D­dimer concentration that is twice the usual cutoff value (e.g., at 1000 ng/mL instead
 of 500 ng/mL) have a <1% probability of PE.
TABLE 56­8
Factors Known to Alter the D­Dimer Level From Expected Values
Potential False­Positive Levels Potential False­Negative Levels
Age >70 y Symptoms lasting >5 d
Pregnancy Presence of small clots
Active malignancy or metastasis Isolated small pulmonary infarction
Surgical procedure in previous week Isolated calf vein thrombosis
Liver disease Lipemia
Rheumatoid arthritis
Infections
Trauma
IMAGING
CHEST CT ANGIOGRAPHY
Chest CT angiography is the most common imaging modality for PE, identifying a clot as a filling defect in contrast­enhanced pulmonary arteries
(Figure 56­4). The diagnostic sensitivity and specificity of a technically adequate multidetector CT pulmonary angiography scan are both
 approximately 90%. The sensitivity of CT is not adequate to exclude PE in patients with a high pretest probability. Most CT pulmonary angiography protocols require the patient to lie supine and hold their breath for a few seconds, and the scan requires injection of approximately 120 mL of contrast by a computer­controlled injection device. The patient must have a peripheral IV catheter (20 gauge or larger) or an approved indwelling line to allow injection of the contrast, and a central catheter cannot be used for injection.
Figure 56­4
Axial image from a chest CT angiogram demonstrating a filling defect consistent with acute pulmonary embolism. Two white arrowheads outline a circular filling defect in the right middle lobar pulmonary artery. The long white arrow projecting in the left lung points to a filling defect in a segmental artery in the posterior medial segmental artery.

In addition to clot recognition, a CT scan can detect alternative diagnoses, often pneumonia (8% to 22% of cases). Interobserver agreement in identifying segmental or larger filling defects is very good, but interobserver agreement for subsegmental clots is poor. In practice, approximately 10% of CT scans are inadequate from secondary motion artifact or poor pulmonary artery opacification, commonly in obese or very tachypneic patients.
,62
About 15% of patients undergoing contrast­enhanced chest CT scan develop mild contrast nephropathy. At present, no clearly helpful
63–65 prophylactic measure exists to reduce contrast nephropathy, including hydration with IV balanced crystalloid solutions. Other
CT angiogram complications include anaphylactoid reactions (<1:1000), contrast extravasation into a limb that can cause pain or compartment
 syndrome, and creation of a secondary thrombophlebitis.
PLANAR VENTILATION–PERFUSION LUNG SCANNING
Ventilation–perfusion ( V/Q) lung scanning can identify a perfusion defect when ventilation is normal. The perfusion images are usually obtained first and require a peripheral IV catheter for injection; the patient must be able to sit up and then lie down during the procedure. The ventilation component requires the patient to breathe a nebulized aerosol with isotope. A V/Q scan with homogeneous scintillation throughout the lung in the perfusion portion is nearly 100% sensitive in excluding PE, regardless of the appearance of the ventilation portion. A V/Q scan with two or more apex central wedge­shaped defects in the perfusion phase (Figure 56­5A) with normal ventilation in these regions indicates >80% probability of
PE. All other V/Q scan findings are nondiagnostic; taken alone, these cannot exclude or diagnose PE.
Figure 56­5
A. Planar ventilation–perfusion lung scan series consistent with a high probability of acute pulmonary embolism (PE) using standard criteria. The first and third rows project the perfusion phases of the examination, and the second and fourth rows show the ventilation phases. The black arrowheads point to wedge­shaped defects in the perfusion images. Comparison with the corresponding ventilation view immediately below shows relatively homogeneous scintillation activity in the anatomic segments that lack perfusion. These defects are consistent with an acute PE. B. Ventilation and perfusion single­photon emission CT (SPECT) images from a patient with PE. The red arrows point to the perfusion defects indicative of PE. The lower panel shows the color­mapped images produced by SPECT/CT; the segments of lung without blood flow appear black. [Part B: This research was originally published in JNM. Roach PJ, Schembri GP and Bailey DL. V̇/Q̇ scanning using SPECT and SPECT/CT. J Nucl Med. 2013;54(9):1588­1596. Figure
. © by the Society of Nuclear Medicine and Molecular Imaging, Inc.]
The V/Q single­photon emission CT technique produces three­dimensional images with better diagnostic accuracy and lower interobserver
 variability than planar V/Q. The pooled diagnostic accuracy of V/Q single­photon emission CT is extraordinarily good; a 2015 systematic review and meta­analysis of 3454 patients found a pooled sensitivity of 96% (95% confidence interval [CI], 95% to 97%) and a specificity of 97% (95% CI, 96% to

98%). V/Q single­photon emission CT detects subsegmental perfusion defects. Single­photon emission CT can also be combined with low radiation dose CT scanning to produce color­mapped images that can be even more revealing (Figure 56­5B).
MAGNETIC RESONANCE IMAGING
MRI is a zero­radiation option for imaging the pulmonary vasculature that may have utility in pregnant patients. However, pooled data suggest that the diagnostic accuracy of MRI for all examinations, regardless of technical adequacy of images, is too low (sensitivity of 75% with specificity of 80%) to
 consider as a first­line modality.
LUNG US
Lung US is an adjunctive modality to help diagnose and exclude PE at the bedside. One study found an improvement in the diagnostic accuracy of the

Wells’ score when using lung US to determine the presence or absence of an alternative diagnosis. Pooled data suggest that lung US has a sensitivity
 of 85% (95% CI, 78% to 90%) and specificity of 83% (95% CI, 73% to 90%).
VENOUS US
Venous US is the imaging test of choice in DVT; it can be done quickly, does not use ionizing radiation, and provides direct evidence of intravascular thrombus by observing noncompressibility of the vein (Figure 56­6). When performed by experienced ultrasonographers, compression venous US has a diagnostic sensitivity of 96% and a specificity of 96% for DVT; it also has a sensitivity of about 40% as a surrogate method to diagnose PE. The mean sensitivity for DVT of US performed by a trained emergency physician compared with the reference imaging test is .1% (95% CI, .6% to

.5%), with a weighted mean specificity of .8% (95% CI, .6% to .1%). However, the details of test performance and training remain important, because two­point compression US may miss some clots and new users require experience with at least  examinations before gaining adequate skill.
Figure 56­6
Compression venous US images showing normal findings and findings indicating deep venous thrombosis. A. Compression venous US of the common femoral vein and femoral artery. The left view shows a sonographic image of the right femoral artery (A) and common femoral vein (V) obtained immediately inferior to the inguinal ligament. The image on the right shows the same view after manual compression by the operator. The image demonstrates obliteration of the vein while the artery remains open. This is a normal US finding for the vein. B. Venous US image showing evidence of common left femoral vein thrombosis after compression (right panel). The common femoral vein (V) does not compress. Echogenic thrombolytic material can be observed within the vein.
Planar pulmonary angiography and venography directly visualize filling defects in the pulmonary arteries or extremity veins, respectively.
However, neither test is currently used as a first­line diagnostic modality.
INTEGRATED APPROACH TO DIAGNOSIS AND TREATMENT
STEP ONE
For a patient to enter a PE testing regimen, he or she should have at least one physiologic manifestation of PE. This may be a symptom
(e.g., pain in the chest or torso, a breathing problem, or altered mental status) or a finding (e.g., an abnormal vital sign) that could be produced by a clot in the lung. The physiologic manifestation must be placed in the context of the given patient—an untreated asthmatic patient with shortness of breath and wheezing should be treated first for bronchospasm and reevaluated and not immediately tested for PE. A risk factor or even multiple risk factors for VTE in the absence of a known sign or symptom or a positive PE rule­out criteria rule with a <2% gestalt pretest probability of PE does not mandate testing for PE or DVT.
STEP TWO
After finding a physiologic manifestation of PE, the next step is to ask, “Do I have more than a low initial suspicion for PE?” Low suspicion means that the physician’s gestalt interpretation of the overall clinical picture is PE likelihood of <15%. If the answer to this question is yes, then a diagnostic test is needed. If the answer is no, then it remains possible that PE can be excluded using the PE rule­out criteria rule. If all eight criteria of the PE rule­out criteria rule are met in the setting of a gestalt­based low suspicion, then no further testing is necessary. In general, if any one of the eight criteria is not met or if a prominent finding exists, order a diagnostic test for PE.
STEP THREE
If PE cannot be excluded with the PE rule­out criteria rule, choose a diagnostic test result that can produce a posttest probability of <2.0%. An ageadjusted quantitative D­dimer assay is the best diagnostic test in patients for whom clinical suspicion is low or moderate based on either gestalt estimation, a Wells’ or simplified revised Geneva score of ≤4, or a “safe” designation according to the PE rule­out criteria rule. Patients with a low pretest probability (e.g., a reasonable alternative diagnosis to PE, no hemoptysis, and no signs of DVT) can have PE excluded with a D­dimer at twice the
,56 usual threshold (Table 56­9).
TABLE 56­9
Likelihood Ratios (LRs) of Diagnostic Tests and Pretest Probabilities Required to Diagnose or Exclude Pulmonary Embolism (PE)
Test LR for PE if Test LR for PE if Test Examples of Scores on Published Methods That Would Allow Pretest
Result Is Negative Result Is Positive* Probability to Rule Out VTE if Test Result Is Negative
Qualitative D­ .25  Wells’ score <2, all pulmonary embolism rule­out criteria negative dimer
Quantitative D­ .1  Gestalt estimate low, Wells’ score ≤4, or Charlotte rule negative (“safe”) dimer† Age adjustment of the D­dimer cutoff using the formula age ×  nanograms/mL
CT angiography .12  Gestalt estimate low, Wells’ score ≤4, or Charlotte rule negative (“safe”)
V/Q scan: .05 NA Any normal
V/Q scan: NA  NA high probability
Abbreviations: FEU = fibrinogen equivalent units; NA = not applicable; V/Q = ventilation–perfusion; VTE = venous thromboembolism.
*A positive D­dimer result should not be used to rule in VTE.
†Assumes a U.S. Food and Drug Administration–cleared assay with cutoff of 500 FEU nanograms/mL as threshold.
STEP FOUR
Test further only those with a positiveD­dimer result or a high pretest probability; base the choice of the next test on patient and facility factors. The algorithm presented inFigure 56­2is one path. In general, the next best step for a patient with suspected PE and a positive D­dimer result is chest CT angiography. V/Q scan may be a preferred option in a pregnant patient or in a patient with renal insufficiency or prior adverse reaction to contrast material. Performing lower extremity venous US is another option; it lacks ionizing radiation, and its ability to diagnose DVT in a patient with
PE symptoms is tantamount to diagnosing PE directly. However, the diagnostic sensitivity of lower extremity US for PE is <40%, so all patients suspected of having PE for whom US findings are negative require pulmonary vascular imaging. A good­quality CT scan (adequately opacified vessels to the segmental artery level) or a normal V/Q scan excludes PE. Anticoagulation should be started for all patients with a segmental or larger filling defect consistent with PE seen on CT scan, a high probability V/Q scan, or a DVT seen on US.
If the patient has no image­detected DVT or PE and has an elevated D­dimer concentration, then further imaging before anticoagulation is an option, especially if the patient has any increased risk of bleeding complications. Commonly, a repeat venous US within  to  days is an alternative option to exclude VTE.
Figure 56­7 is one algorithm describing the diagnostic decision making for DVT. Patients with a low pretest probability (score <1) or patients without cancer, with a modified Wells’ DVT score ≤1 (Table 56­6), and with a normal D­dimer result are safely considered negative for DVT; any positive result requires US in this group. Patients with moderate to high Wells’ scores or DVT likely (modified Wells’ DVT score) should undergo US testing, assessing
D­dimer as additional confirmation at physician discretion only if the US result is negative. In these patients, assume no clot exists if both US and D­ dimer tests are negative; if patients have negative US findings and positive D­dimer results, repeat the US  to  days later.
Figure 56­7
Diagnostic algorithm for deep vein thrombosis (DVT), applied in patients with leg symptoms compatible with DVT. + = positive test result; – = negative
 test result.
VENOUS THROMBOEMBOLISM TREATMENT
TREATMENT OF PULMONARY EMBOLISM AND DEEP AND SUPERFICIAL EXTREMITY THROMBOSES
Treatment of VTE requires systemic anticoagulation to prevent further clot formation and allow endogenous fibrinolysis to proceed. In many cases, the initial treatment for VTE is heparin or a heparin­like drug. Patients with DVT diagnosed in the ED are typically discharged after receiving the first dose of low­molecular­weight heparin, apixaban, or rivaroxaban (Table 56­10), with anticoagulation continued as an outpatient. Indications for admission in patients with DVT are primarily dependent upon social determinants, comorbid conditions, and the presence of iliofemoral DVT with signs of phlegmasia.
TABLE 56­10
Antithrombotic Therapy for Deep Vein Thrombosis (DVT) and Pulmonary Embolism (PE)
Therapy Dosage Comments
Unfractionated  units/kg bolus, then  units/kg/h infusion Recommended if outpatient therapy not appropriate or in heparin cases of severe renal failure
LMWH Outpatient treatment with LMWH preferred
Dalteparin 100 IU/kg SC every  h or 200 IU/kg SC every day
Enoxaparin  milligram/kg SC every  h or .5 milligrams/kg SC every day
Tinzaparin 175 IU/kg SC every day
Factor Xa inhibitors
Fondaparinux <50 kg,  milligrams SC every day; 50–100 kg, .5 milligrams SC every day; Do not use in renal failure
>100 kg,  milligrams SC every day
Target­specific anticoagulants
Rivaroxaban  milligrams BID for  d, then  milligrams every day with food No heparin requirement; good choice for outpatient
(Xarelto®) treatment
Apixaban  milligrams BID for  days, then  mg BID No heparin requirement; good choice for outpatient
(Eliquis®) treatment
Dabigatran 150 milligrams BID Requires run­in of heparin for 5–10 d; renal excretion
(Pradaxa®)
Thrombolytic Tissue plasminogen activator or alteplase (Activase®), 10­milligram IV For PE with hemodynamic compromise; after infusion, therapy bolus followed by  milligrams infused over  h begin unfractionated heparin or LMWH
Abbreviations: BID = twice a day; LMWH = low­molecular­weight heparin.

The two most common options are unfractionated heparin or a low­molecular­weight heparin (Table 56­10). Initial anticoagulation treatment for VTE
 can also include oral apixaban or rivaroxaban. For detailed discussion of antithrombotic therapy, see Chapter 239, “Thrombotics and
Antithrombotics.”
Current data favor the use of low­molecular­weight heparins over unfractionated heparin for treatment of both PE and DVT in terms of composite
 outcomes (bleeding and death) and cost, although the magnitude of benefit is not large. If uncertain about PE presence, the likelihood can guide anticoagulation therapy; the benefit of empiric anticoagulation for  hours exceeds the risks (bleeding and heparin­induced thrombocytopenia) for
 any patient with a pretest probability of PE of >20%. Delay in administration of heparin to patients with PE is associated with increased mortality, but no study has found that heparin, administered early and prior to imaging, improves morbidity or mortality.

In patients with severe renal insufficiency and acute DVT or PE, most experts recommend unfractionated heparin over low­molecular­weight heparin.
Treat upper extremity DVT the same as lower extremity DVT, and consider removing any indwelling catheters associated with clot. Do not
 delay unfractionated heparin for thrombophilia testing.
Most DVT can be treated with anticoagulation, but iliofemoral DVT that causes phlegmasia cerulea dolens requires rapid action to reduce the venous pressure. In addition to initiating anticoagulation, place the affected limb at a neutral level; remove constrictive clothing, cast, or dressing; and
 arrange for vascular consultation and consultant­delivered catheter­directed thrombolysis. If no such service is available and emergency transfer cannot be arranged within  hours, consider systemic fibrinolytics if there are no absolute contraindications. One regimen for the latter is  to 100 milligrams of alteplase infused IV over  hours.
TREATMENT FOR SUPERFICIAL THROMBOPHLEBITIS
Treatment for localized superficial thrombophlebitis is an oral NSAID or topical diclofenac gel until symptoms resolve; there is no need for systemic
 anticoagulation. For extensive superficial vein involvement, full­dose anticoagulation is recommended. Compression stockings may provide some
 relief in selected individuals.
TREATMENT FOR ISOLATED CALF VEIN THROMBOSIS
There are no universally accepted treatment guidelines for thromboses isolated to the calf veins (soleal or gastrocnemius) or the saphenous vein,
 although many use  months of oral anticoagulation. Alternatives include no acute treatment, with repeat US in  week to identify progression of clot, or outpatient treatment with low­molecular­weight heparin (Table 56­10). Patients with a history of VTE or risk factors for VTE (Table 56­1) should
 receive  months of full­dose anticoagulation when calf thrombosis exists unless contraindications are present.
OUTPATIENT TREATMENT OF PULMONARY EMBOLISM
For carefully selected low­risk patients with PE, many centers have begun ED treatment protocols with a first dose of low­molecular­weight heparin, apixaban, or rivaroxaban given in the ED (Table 56­10), followed by a period of ED observation, and then ED discharge with anticoagulation continued as an outpatient, as long as patients are able to obtain the drug and adhere to therapy.
,79
Patients with PE and a low risk of death plus adequate home support can qualify for outpatient anticoagulation. The incidence of short­term
,81 mortality and the bleeding risk are very low with outpatient treatment, the overall cost of care is less, and the experience is preferred by patients.
,82,83
Select low­risk patients using either the modified Hestia criteria or the Simplified PE Severity Index criteria (Table 56­11). If low risk, assess the patient’s wishes and ability to comply; if no high­risk features exist (elevated troponin, a B­type natriuretic peptide >100 picograms/mL, pulmonary
 arterial hypertension on ECG, or bleeding risks ), outpatient care after an ED stay (up to  hours) is an option; otherwise, short­term hospitalization is a good choice.
TABLE 56­11
Two Prognostic Systems That Can Select Low­Risk Patients for Outpatient Treatment18,78,79
Simplified PE Severity Index Score
 = low risk;  = high risk
Age >80 y
History of cancer
History of heart failure or chronic lung disease
Pulse >110 beats/min
SBP <100 mm Hg
Oxygen saturation <90%
Modified Hestia Criteria
Identifies low­risk PE if:
SBP >100 mm Hg
No thrombolysis needed
No active bleeding
Oxygen saturation >94% on room air
Not already anticoagulated
No more than two doses of IV narcotics in ED
Absence of other medical or social reasons to admit
Creatinine clearance >30 mL/min
Not pregnant, no severe liver disease or HIT
Abbreviations: HIT = heparin­induced thrombocytopenia; PE = pulmonary embolism; SBP = systolic blood pressure.
FIBRINOLYSIS FOR PULMONARY EMBOLISM
PE is classified into three categories based on severity: massive, submassive, and less severe PE. The clinical criteria for Massive PE are: cardiac arrest; obstructive shock characterized by a systolic blood pressure of <90 mm Hg for >15 minutes despite adequate volume replacement; persistent hypotension characterized by a blood pressure drop of >  mm Hg for  minutes; and any requirement for vasopressors not due to shock from other causes. Submassive PE patients have normal or near­normal blood pressure, but with other evidence of cardiopulmonary stress (Table 56­12).
TABLE 56­12
Modalities to Risk­Stratify Pulmonary Embolism (PE)
Test Less Severe PE More Severe PE (massive and some submassive PE)
Hestia criteria All negative Any positive
PE Severity Index score <80 >120
Simplified PE Severity Index criteria All negative Any positive
Shock index (heart rate/systolic blood pressure) <1.0 ≥1.0
Pulse oximetry reading >94% <95%
Echocardiography Normal RV systolic function RV hypokinesis
Normal RV size RV dilation
No tricuspid regurgitation RVSP >40 mm Hg
Troponin I or T level Normal Elevated
B­type natriuretic peptide level <90 picograms/mL ≥90 picograms/mL
N­terminal pro­B­type natriuretic peptide <900 picograms/mL ≥900 picograms/mL
D­Dimer level <4000 nanograms/mL >8000 nanograms/mL
Serum sodium concentration <125 mEq/L ≥125 mEq/L
Abbreviations: RV = right ventricular; RVSP = right ventricular systolic pressure.
All other PE cases are “less severe.” Patients with low­risk PE should not receive fibrinolysis. Those with massive PE benefit from fibrinolysis.
Patients with more severe submassive PE (i.e., causing increased right ventricular to left ventricular ratio on CT scan or hypokinesis, elevated troponin or B­type natriuretic peptide, or persistent hypoxemia with distress) may also benefit from fibrinolysis, including higher survival and better quality of
 life, although at a higher bleeding risk.
SYSTEMIC FIBRINOLYSIS
The best evidence suggests considering systemic fibrinolysis in patients with no contraindications to fibrinolysisand any of the following: cardiac arrest; hypotension (any systolic blood pressure >90 mm Hg); respiratory failure, evidenced by severe hypoxemia (pulse oximetry reading
<90%) despite oxygen administration, together with evidence of increased work of breathing; or evidence of right­sided heart strain on echocardiography or elevated levels of troponin T or I, or both (Table 56­12). Major contraindications to thrombolytic therapy include intracranial disease, uncontrolled hypertension at presentation, recent major surgery or trauma (past  weeks), and metastatic cancer. Any patient with head trauma from syncope should have a CT scan prior to therapy to detect hemorrhage.
Alteplase (tissue plasminogen activator) is the only currently approved agent for PE, dosed at 100 milligrams IV over  hours. Either enoxaparin (1 milligram/kg SC) or unfractionated heparin (80 units/kg IV bolus followed by  units/kg/h) is the anticoagulant, with the activated partial thromboplastin time kept at <120 seconds for unfractionated heparin. Heparin or low­molecular­weight heparin is typically started after the thrombolytic infusion. Use of  mg of alteplase may reduce bleeding risk with similar outcomes as 100 mg of alteplase, although the safety and
,87 efficacy of this approach remain controversial. For further discussion of fibrinolytic agents, see Chapter 239, “Thrombotics and Antithrombotics.”
CATHETER­DIRECTED THROMBOLYSIS
Recent systematic reviews suggest that catheter­directed fibrinolysis for intermediate­risk PE produces good hemodynamic improvements and an
88–91 intracranial bleeding rate <2%. Catheter­directed thrombolysis for PE requires a far lower dose of alteplase (approximately  milligrams total), which may confer a lower bleeding risk. Catheter­directed thrombolysis is an option for patients over  years old, in whom intracranial bleeding risk is
 highest. Because of the time delay needed to activate the vascular intervention suite, intrapulmonary fibrinolytic delivery should not be used in most
 patients with massive PE.
SURGICAL EMBOLECTOMY
If available, surgical embolectomy is an option in young patients with large, proximal PE accompanied by hypotension. Because surgical embolectomy is often delayed, the reported mortality rate is approximately 30%. The amount of clot that can be extracted is often extensive, and removal may help limit later cardiopulmonary complications.
SPECIAL POPULATIONS
PREGNANCY
94–96
The clinical assessment of VTE in pregnant women is difficult because many signs and symptoms suggestive of VTE are seen in normal pregnancy.
Fewer than 2% of pregnant women with Wells’ score ≤4 had PE in prior retrospective studies. ,98 In one prospective study, the revised Geneva score resulted in a stepwise increase in probability of PE (7 of 192 [3.6%] in the low–pretest probability group,  of 200 [9.0%] in the intermediate­
 probability group, and  of  [100%] in the high­probability group). The PE rule­out criteria rule has not been adequately tested in pregnant patients to recommend its use in isolation to exclude PE.
100,101
The D­dimer has low specificity in pregnant patients; by the third trimester, almost all healthy pregnant women have a positive D­dimer. Studies that have examined the diagnostic sensitivity of the D­dimer have been hampered by low numbers and problems with D­dimer measurements made
102 after systemic anticoagulation, which degrades test sensitivity. Some have advocated for sequentially increasing the cutoff by approximately 50% for the D­dimer per trimester (first trimester, 750 nanograms/mL; second trimester, 1000 nanograms/mL; third trimester, 1250 nanograms/mL), although
101,103­105 this approach has not been tested in a management study.
106,107
The diagnostic accuracy of US for DVT appears to be similar to that of nonpregnant patients. The best choice of pulmonary vascular imaging in
108 pregnancy is controversial and uncertain. Both a normal CT pulmonary angiogram and V/Q scanning have shown 100% diagnostic sensitivity for
 technically adequate studies. MRI has not been adequately tested in pregnancy to provide any basis for recommendation, but it had too low of a
,109 sensitivity (78%) to rule out PE in nonpregnant patients.
Pregnant patients diagnosed with VTE in the ED should be anticoagulated with low­molecular­weight heparin. In the case of massive PE, options include systemic fibrinolysis, catheter­directed fibrinolysis, or the use of cardiopulmonary venoarterial extracorporeal membrane oxygenation.

Current literature suggests a >80% probability of survival of both mother and fetus with the use of systemic fibrinolytics in the setting of massive PE.
For additional discussion, see Chapter , “Comorbid Disorders in Pregnancy.”
ISOLATED SUBSEGMENTAL PULMONARY EMBOLISM
Isolated subsegmental PE is a filling defect seen in one small pulmonary artery, usually <3 mm in diameter and in the absence of DVT; radiologists often do not agree when viewing these images separately. The optimal treatment of subsegmental PE remains uncertain. Pooled data suggest that patients
111 without high risk of recurrence (e.g., prior unprovoked VTE, active cancer, or other major active risk factor) may not benefit from anticoagulation.
However, no randomized trial has been performed to test this hypothesis. The author’s choice is to treat subsegmental PE as an outpatient with apixaban or rivaroxaban and check a D­dimer in  month and, if normal, stop anticoagulation. It is best to discuss the risks and benefits of treatment of subsegmental PE with patients and their physicians to help make the best decision about anticoagulation.
CANCER PATIENTS WITH VENOUS THROMBOEMBOLISM

Current data and guidelines recommend treatment of patients with active cancer with low­molecular­weight heparin for at least  months. One randomized trial suggested that rivaroxaban can be used in patients with active cancer, with a reduction in VTE recurrence but increased risk of
113 bleeding.


## Page 32

94. Meng K, Hu X, Peng X, Zhang Z: Incidence of venous thromboembolism during pregnancy and the puerperium: a systematic review and metaanalysis. J Matern Fetal Neonatal Med 28: 245, 2014. [PubMed: 24716782]
. Kline JA, Richardson DM, Than MP, Penaloza A, Roy PM: Systematic review and meta­analysis of pregnant patients investigated for suspected pulmonary embolism in the emergency department. Acad Emerg Med 21: 949, 2014. [PubMed: 25269575]
. van Mens TE, Scheres LJ, de Jong PG, Leeflang MG, Nijkeuter M, Middeldorp S: Imaging for the exclusion of pulmonary embolism in pregnancy.
Cochrane Database Syst Rev 1: CD011053, 2017. [PubMed: 28124411]
. O’Connor C, Moriarty J, Walsh J, Murray J, Coulter­Smith S, Boyd W: The application of a clinical risk stratification score may reduce unnecessary investigations for pulmonary embolism in pregnancy. J Matern Fetal Neonatal Med 24: 1461, 2011. [PubMed: 21854126]
. Cutts BA, Tran HA, Merriman E, et al. The utility of the Wells clinical prediction model and ventilation­perfusion scanning for pulmonary embolism
University of Pittsburgh diagnosis in pregnancy. Blood Coagul Fibrinolysis 25: 375, 2014. [PubMed: 24434350]
Access Provided by:
. Righini M, Robert­Ebadi H, Elias A, et al. Diagnosis of pulmonary embolism during pregnancy: a multicenter prospective management outcome study. Ann Intern Med 169: 766, 2018. [PubMed: 30357273]
100. Murphy N, Broadhurst DI, Khashan AS, Gilligan O, Kenny LC, O’Donoghue K: Gestation­specific D­dimer reference ranges: a cross­sectional study. BJOG 122: 395, 2015. [PubMed: 24828148]
101. Kline JA, Hambleton GW, Hernandez J: D­dimer concentrations in normal pregnancy: new diagnostic thresholds are needed. Clin Chem 51: 825,
2005. [PubMed: 15764641]
102. Hunt BJ, Parmar K, Horspool K, Shephard N, Nelson­Piercy C, Goodacre S: The DiPEP (Diagnosis of PE in Pregnancy) biomarker study: an observational cohort study augmented with additional cases to determine the diagnostic utility of biomarkers for suspected venous thromboembolism during pregnancy and puerperium. Br J Haematol 180: 694, 2018. [PubMed: 29359796]
103. Parilla BV, Fournogerakis R, Archer A, et al. Diagnosing pulmonary embolism in pregnancy: are biomarkers and clinical predictive models useful?
AJP Rep 6: e160, 2016. [PubMed: 27119048]
104. Chan WS, Lee A, Spencer FA, et al. D­dimer testing in pregnant patients: towards determining the next “level” in the diagnosis of deep vein thrombosis. J Thromb Haemost 8: 1004, 2010. [PubMed: 20128870]
105. Chan WS, Ginsberg JS: Management of venous thromboembolism in pregnancy. In: van Beek EJR, Buller HR, Oudkerk M (eds): Deep Vein
Thrombosis and Pulmonary Embolism.Chichester, West Sussex: John Wiley & Sons; 2009:353–371. 106. Ratiu A, Navolan D, Spatariu I, Biris M, Miculita M, Motoc A: Diagnostic value of a negative single color duplex ultrasound in deep vein thrombosis suspicion during pregnancy. Rev Med Chir Soc Med Nat Iasi 114: 454, 2010. [PubMed: 20700985]
107. Le GG, Kercret G, Ben YK, et al. Diagnostic value of single complete compression ultrasonography in pregnant and postpartum women with suspected deep vein thrombosis: prospective study. BMJ 344: e2635, 2012. [PubMed: 22531869]
108. Leung AN, Bull TM, Jaeschke R, et al. An official American Thoracic Society/Society of Thoracic Radiology clinical practice guideline: evaluation of suspected pulmonary embolism in pregnancy. Am J Respir Crit Care Med 184: 1200, 2011. [PubMed: 22086989]
109. Stein PD, Chenevert TL, Fowler SE, et al. Gadolinium­enhanced magnetic resonance angiography for pulmonary embolism: a multicenter prospective study (PIOPED III). Ann Intern Med 152: 434, 2010. [PubMed: 20368649]
110. Martillotti G, Boehlen F, Robert­Ebadi H, Jastrow N, Righini M, Blondon M: Treatment options for severe pulmonary embolism during pregnancy and the postpartum period: a systematic review. J Thromb Haemost 15: 1942, 2017. [PubMed: 28805341]
111. Bariteau A, Stewart LK, Emmett TW, Kline JA: Systematic review and meta­analysis of outcomes of patients with subsegmental pulmonary embolism with and without anticoagulation treatment. Acad Emerg Med 25: 828, 2018. [PubMed: 29498138]
112. Bochenek T, Nizankowski R: The treatment of venous thromboembolism with low­molecular­weight heparins. A meta­analysis. Thromb Haemost
107: 699, 2012. [PubMed: 22318218]
113. Young AM, Marshall A, Thirlwall J, et al. Comparison of an oral factor Xa Inhibitor with low molecular weight heparin in patients with cancer with venous thromboembolism: results of a randomized trial (SELECT­D). J Clin Oncol 36: 2017, 2018. [PubMed: 29746227]

Chapter 56: Venous Thromboembolism Including Pulmonary Embolism, Jeffrey A. Kline 
. Terms of Use * Privacy Policy * Notice * Accessibility

