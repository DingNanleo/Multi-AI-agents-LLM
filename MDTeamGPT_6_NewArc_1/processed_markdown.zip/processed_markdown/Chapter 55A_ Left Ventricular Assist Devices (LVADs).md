## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 55A: Left Ventricular Assist Devices (LVADs)
Marina Boushra; Timothy Montrief; Brit Long; Alex Koyfman
INTRODUCTION
Mechanical circulatory support devices include implanted devices that assist the left ventricle (LVAD), the right ventricle (RVAD), and both ventricles
(BiVAD), as well as the total artificial heart (TAH). Most devices in current use are LVADs, and these are discussed in this chapter.
LVADs are used in the management of refractory heart failure with reduced ejection fraction (HFrEF) in children and adults, either as permanent

(destination) therapy or as a bridge to heart transplant. In the United States, LVAD­related ED visits increased 16­fold between 2010 and 2017 due to
 rising use of LVADs and 2­year survival >70% in patients with newer­generation devices. Nearly half of patients with LVADs seek medical care at the ED
,4 within the first month following implantation and, on average, patients come to the ED seven times in the first year following LVAD placement. LVAD risks include mechanical complications, conditions exacerbated by long­term anticoagulation and arterial remodeling from continuous­flow devices, and infections.
Early­generation LVADs were pulsatile­flow LVADs that produced a peripheral pulse in the patient. Continuous­flow LVADs, which generally do not produce a pulse, are currently the most widely used. The Heartmate  (HM3) and HeartWare devices, both continuous­flow pumps, are most popular in
,6 the United States and are also used in the Asia­Pacific regions. The Medtronic HeartWare Ventricular Assist Device (HVAD) was discontinued in 2021 due to mechanical and medical issues, but some patients may still have these in place. The Berlin Heart is used for children as a bridge to transplant.
LVAD use in Europe varies with country and funding.
DEVICE COMPONENTS
The HM3 will be used to illustrate the components of the LVAD device. The HM3 basic parts are the internal pump, controller, external power source,
,8 and percutaneous driveline (Figure 55A­1). The only moving part of the HM3 is the pump, which draws blood from the left ventricle and delivers up to
 L/min to the ascending aorta. The LVAD power source is two or more rechargeable battery packs. The percutaneous driveline is tunneled through the anterior abdominal wall and provides a conduit for electrical wiring, connecting the external system controller to the internal pump.
Figure 55A­1. LVAD components (HeartMate III). Specific components include the inflow cannula positioned at the left ventricular apex, pumping chamber, outflow cannula connected to the ascending aorta, percutaneous driveline, controller unit, and power source.

Chapter 55A: Left Ventricular Assist Devices (LVADs), Marina Boushra; Timothy Montrief; Brit Long; Alex Koyfman 
. Terms of Use * Privacy Policy * Notice * Accessibility

The LVAD controller regulates the LVAD function, including power source monitoring, system monitoring, data collection, and alarms. The controller has a display panel that provides important information about LVAD function (Figure 55A­2). The HM3 controller has three alarm icons: Low Battery
Alarm, Device Malfunction Alarm, and Device Function Warning Alarm (Figure 55A­2). Audible and visual alarms can indicate problems with the pump, connections, controller unit, or power supply (Table 55A­1).
Pump speed is the only adjustable LVAD parameter, is set by the patient’s heart failure specialist, and can be modified as needs change.
Figure 55A­2. LVAD controller (HeartMate 3).
TABLE 55A­1
Rapid Assessment Steps
Auscultation Auscultate the precordium for a continuous mechanical hum.
Battery Check that LVAD is connected to battery source.
Check that power source (battery) is charged.
Connect to wall outlet if battery is empty or malfunctioning.
Controller Listen for ongoing alarms.
Ask patient about controller alarms prior to presentation.
Inquire about the patient’s controller metrics and compare to current displayed metrics.
Driveline Ask about prior driveline infections, pain, or drainage from the area.
Examine the driveline site under sterile conditions, evaluating for signs of infection, fraying, or cord fracture.
Doppler Measure MAP using doppler flow (goal MAP 70–80 mm Hg)
ECG Evaluate for signs of ischemia, including ST elevations or depressions.
Evaluate for dysrhythmias, particularly ventricular dysrhythmias.
Compare ECG with prior ECGs in the records.
Echocardiogram Evaluate right and left ventricular size and function and compare with prior echocardiograms in the record.
PATIENT ASSESSMENT
Initial evaluation of patients with an LVAD includes contact with the LVAD coordinator and rapid assessment (Table 55A­1). If the rapid assessment elements are intact, proceed with systematic assessment. Otherwise, begin emergency resuscitation.
Contact the LVAD coordinator very early in the patient’s stay, as the coordinator can assist in interpretation of the alarms and assessment of the patient’s current condition. The coordinator can also mobilize resources, help determine the scope and direction of the workup, and facilitate communication and transfer if necessary. The LVAD coordinator is typically familiar with the patient’s baseline LVAD parameters and medical history.
In hospitals with dedicated LVAD units, bedside evaluation of LVAD patients (including clinical and device assessment) is often aided by the LVAD
 team.
Many patients with LVADs are knowledgeable regarding their equipment and baseline LVAD parameters, such as mean arterial pressure (MAP) and pulsatility index. Patients may be able to identify equipment malfunctions or driveline concerns and are a valuable resource for evaluating the LVAD controller.
RAPID INITIAL ASSESSMENT
Follow elements in Table 55A­1 for rapid assessment.
AUSCULTATION
In the LVAD patient, heart sounds are obscured, and the presence of the LVAD mechanical hum indicates the LVAD is functioning. However, presence of the hum does not itself indicate proper functioning, and device assessment is necessary (see below).
DOPPLER
Since contemporary LVADs provide continuous blood flow, in most patients no pulse is present. Even if pulses are present, the degree of pulsatility is variable. Therefore, automated blood pressure monitors will not accurately measure MAP. Use a manual blood pressure cuff along with a Doppler
 probe placed over the brachial or radial artery. Inflate the sphygmomanometer  mm Hg past when the arterial pulse is no longer detected by

Doppler. Then, slowly deflate the cuff until the Doppler signal returns. This corresponds to the patient’s MAP. A MAP of 70–80 mm Hg is desired.
ECG
,9
Assess heart rate and rhythm with an ECG. Many patients with an LVAD require a pacemaker or implantable cardioverter/defibrillator (ICD). While ventricular tachycardia or fibrillation may be physiologically well tolerated due to the presence of an LVAD, these require emergency treatment
 following ACLS protocols.
ECHOCARDIOGRAM
Perform POCUS echocardiogram to assess right ventricular (RV) size and function, and to determine presence or absence of tamponade or LV underfilling or distention.
CARDIAC ARREST
Cardiac arrest in patients with an LVAD may occur because of mechanical failure or decompensation of the underlying cardiac disease. Since pulselessness is not a reliable indicator of circulation in patients with an LVAD, lack of a pulse does not equate to cardiac arrest. Assess for non­LVAD
 causes for altered mental status, including hypoxia, hypoglycemia, overdose, stroke, or CNS bleed.

Assume cardiac arrest in patients who are unresponsive, with absent or agonal respirations.
Accurate SpO (oxygen saturation) requires pulsatile blood flow, so anticipate inaccurately low pulse oximetry readings in patients with LVADs who do
 not have a pulse. However, if pulse oximetry is in the normal range, interpret as clinically correct. PETCO (partial pressure of end­tidal carbon dioxide)
 is a reliable marker for perfusion. In patients with a normal cardiac output and no significant respiratory compromise, PETCO is typically 35–40 mm Hg.

In cardiogenic shock or cardiac arrest (low flow states), PETCO reflects systemic perfusion.

A PETCO <20 mm Hg in an unresponsive, properly intubated patient is a marker of cardiac arrest, LVAD failure, and the need for chest
 compressions.
A PETCO >20 mm Hg would suggest that LVAD malfunction is not the cause of unresponsiveness, and chest compressions are not indicated.

Quickly check to make sure the LVAD is connected to power, the driveline is connected, and there is an audible LVAD hum. Identify the underlying cardiac rhythm with ECG.
Immediately start CPR with chest compressions and follow ACLS steps.
,12
Defibrillate as rhythm indicates (and continue with ACLS maneuvers).
Do not place the defibrillator pads over the pump.
Use anterior­posterior pad placement; place left chest pad below the implanted AICD and above the LVAD itself.
Use standard ACLS energy for the condition.
If cardiac arrest occurs at a hospital with capability for extracorporeal membrane oxygenation (ECMO), consider emergent consultation for
 extracorporeal life support (ECLS).
SYSTEMATIC PATIENT ASSESSMENT
,9
Direct the history and physical examination using the patient’s chief concern and inspection of the LVAD components.
HISTORY
Important history elements include the following:
Type of LVAD and past problems
Pump thrombosis/deep vein thrombosis (DVT)/pulmonary embolism (PE)
Gastrointestinal bleeding
Driveline infections
Dysrhythmias
RV failure
Immediate availability of charged batteries or AC adaptor
Usual presence or absence of pulse and typical MAP (expected 70–90 mm Hg)
Current medications, including anticoagulation, and last administration
Presence of pacemaker
Presence of ICD and any recent discharges
Chief complaint
PHYSICAL EXAMINATION
Pay particular attention to signs and symptoms of heart failure and volume overload (extremity edema, ascites, elevated jugular venous pressure,
 pulmonary edema), as they can be indicative of LVAD malfunction or RV failure. Altered mental status, focal neurologic deficit, or new headache are
 concerning for cardioembolic strokes and intracranial hemorrhage. Bleeding complications, including epistaxis and gastrointestinal hemorrhage, are common and should be assessed.
DEVICE ASSESSMENT
Driveline
Determine the make and model of the pump and the operational status of the equipment and connections. Start with evaluation of the driveline as it enters the skin, working backward to the controller. Carefully examine the driveline exit site using sterile gloves. Remove the dressing with caution and
 avoid sharp tools such as trauma shears in order to prevent unnecessary trauma to the driveline. Examine the surrounding skin for signs of infection.
Patients are routinely instructed to anchor the driveline to the skin in order to prevent subcutaneous trauma from accidental tugging of equipment or the driveline. Some patients may have anchor devices that were originally designed to secure Foley catheters, while others may have an abdominal binder.Examine under the anchors, binders, and dressings so the entirety of the driveline and percutaneous insertion site is visualized. After inspection, re­maintain the driveline anchor or abdominal binder to stabilize the driveline during transport and patient care.

Next, examine the entirety of the external driveline to ensure that it is not severed, exposed, or frayed. The cable is subcutaneously tunneled to the
LVAD pump at one end and connected to the LVAD controller at the other end. Follow the driveline to the controller and assess all connections. If there is an apparent disconnect between the driveline and the controller module, as evidenced by an audible alarm and visual inspection, search for the
 patient’s LVAD carrying case and reconnect the controller and driveline.
Controller
LVAD controllers are connected to both the driveline and an external power source, the battery packs. Upon arrival to the ED, plug the patient’s controller into an external battery source. Patients typically carry their controller in an external pack, which may be branded with the model name of the system located on the inside pouch or pocket. Controller operating and review instructions can be found on the manufacturer’s websites and may
,11 be augmented by the patient’s LVAD coordinator. Note the current controller settings, pump parameters, and logged alarms. All patients should have a backup controller as well as 4–8 batteries. Exchange the primary controller (attached to the driveline) for the backup controller when instructed to do so by the alarms on the controller and under the guidance of an expert trained to perform controller exchanges.
Pulsatility Index
The pulsatility index represents the relationship between the maximum and minimum power of the LVAD compared with the average pump power in

15­s intervals. During systole, the LV contracts, increasing ventricular pressure that causes increases in pump flow and changes in power. The pulsatility index reflects the variability of pump power throughout the cardiac cycle. These changes are then converted into a dimensionless index
 ranging from  to , providing an indirect measure of the patient’s native cardiac contractility and LV preload.
Address Controller Alarms
Address alarms by first looking at the controller screen and reading the conditions. For further information or instructions contact the LVAD coordinator or, lastly, access instructions for use from the manufacturer’s website. While there are a variety of self­explanatory alarms (Table 55A­1), red hazard alarms indicate an emergency and require immediate attention. Critical alarms have an audible component that will sound continuously, indicating need for timely intervention, but will cease once the batteries are depleted. Alarms denoting low battery, controller fault, or driveline disconnection help identify the underlying problem quickly. Recognition of other alarm patterns helps identify other underlying pathophysiology, as most LVAD­associated complications can be identified by discerning whether the patient has high or low LVAD flow, followed by assessing for increased or decreased pulsatility (Figure 55A­3).
Figure 55A­3. Differential diagnosis for high­flow and low­flow LVAD alarms.
Check Battery Power
The controller requires two power sources: either two batteries or a battery and an AC/DC adapter for an external power source. When patients arrive at the ED, they typically rely on dual batteries, which provide 8–12 h of power. Evaluate batteries to determine the percentage of charge remaining.
After pushing the button on the top of the battery, percentage of charge is displayed with four bars, each one denoting 25% of total charge. If all four lights are displayed, the battery is at 100% charge; if three lights are displayed, the battery is at 75%, etc. While in the ED, transition to the AC/DC adapter if possible.
LABORATORY, ECG, AND IMAGING STUDIES
Obtain basic laboratory studies and determine which additional investigations are indicated by history, examination, and situation (e.g., trauma, possible stroke, infection) (Table 55A­2, Figure 55A­4). LVAD patients are maintained on warfarin with an international normalized ratio (INR) target of

.0–3.0 and daily aspirin 81–325 mg.
TABLE 55A­2
Proposed ED Workup for Patients with an LVAD
Laboratory Studies Imaging Studies Auxiliary Studies
Complete blood count Chest x­ray ECG
Type and crossmatch Abdominal x­ray POCUS
Comprehensive metabolic panel
Hepatic and renal function studies
Coagulation studies: PT, INR, and others as indicated
Hemolysis panel including LDH and haptoglobin
Lactic acid
VBG/ABG
Troponin
B­type natriuretic peptide (pro­BNP)
Consider viscoelastic testing if available
Figure 55A­4. Representative electrocardiogram (ECG) from a patient with a left ventricular assist device (LVAD). Demonstrated is marked baseline artifact generated from the electrical pump. ECG from Tim Montrief.

ECG may demonstrate electrical interference/artifact (Figure 55A­4). Nonspecific findings include low limb lead voltage, QRS notching, and evidence of underlying cardiomyopathy. The utility of different imaging modalities for the diagnosis of LVAD complications is discussed in detail by complication below.
POCUS ECHOCARDIOGRAM

See Table 55A­3. TABLE 55A­3
Point­of­care Ultrasound Examination for Patients with Left Ventricular Assist Device
POCUS
Features Diagnosis
Examination
Cardiac Function and size of left ventricle on PSLA, PSSA, and A4C views Left ventricular failure
Inadequate filling due to hypovolemia or right ventricular failure
Function and size of right ventricle on PSLA, PSSA, and A4C views Pulmonary embolism
Right ventricular failure
Size of aortic root and presence of dissection flap on PSLA view Aortic dissection
Pericardial effusion on PSLA and SX view Cardiac tamponade
Competency of aortic and mitral valves on PSLA view Aortic regurgitation
Mitral regurgitation
Presence of clots, position, and flow of inflow cannula on PSLA, PSSA, and A4C Device thrombosis views Cannula misalignment
Suction event
Cannula obstruction
Pump malfunction
Presence of clots, position, and flow of outflow cannula on a high left PSLA or Cannula misalignment suprasternal notch view Cannula obstruction
Pump malfunction
Inferior vena Size and collapsibility on SX view Hypovolemic or distributive shock cava Cardiogenic or obstructive shock
Hepatic veins Size and doppler flow on SX view Fluid overload with venous congestion
Cardiogenic or obstructive shock
Lung Presence of B lines and pleural effusions Fluid overload
Atelectasis or consolidation
FAST Presence of free fluid on RUQ, LUQ, or suprapubic views Intra­abdominal hemorrhage
Fluid overload with ascites
A4C, apical  chamber; FAST, focused assessment with sonography in trauma; LUQ, left upper quadrant; POCUS, point­of­care ultrasound; PSLA, parasternal long axis; PSSA, parasternal short axis; RUQ, right upper quadrant; SX, subxiphoid.
LVAD PATIENT­SPECIFIC COMPLICATIONS
LVAD­associated conditions can be assessed by first determining LVAD flow and then determining pulsatility (Figure 55A­3).
LVAD flow is dependent on adequate preload and impacted by afterload. LVAD flow can be identified from the controller unit. LVAD flow decreases during diastole and increases during systole, so even with a continuous­flow LVAD, there is an element of pulsatility due to LVAD functionality as well as
,9 through contribution of the native LV to cardiac output.

The pulsatility index is an indirect measure of the patient’s native cardiac contractility and intravascular volume status. To determine pulsatility index, press the display button (Figure 55A­2) on the controller three times. Values range from  to . Figure 55A­3 provides a differential diagnosis based on flow and pulsatility.
SUCTION EVENT
Suction events, also known as “suckdown” events, result in a collapse of the LV wall, which gets “sucked into” the inflow cannula and temporarily
 blocks blood flow. Causes include severe hypovolemia, cardiac tamponade, and RV failure with interventricular septal displacement. Patients with suction events may present with low­flow alarms or syncope.
The LVAD automatically responds to a suction event. The LVAD pump speed will transiently decrease to reduce the negative pressure in the left ventricle, decrease LV emptying, and release the myocardium from the inflow cannula. Once the myocardium is released, the LVAD will ramp up to the pump speed set on the controller. If the underlying cause of the suction event has not been addressed, the increase in speed may result in recurrent suction events. Irritation of the ventricular myocardium by the inflow cannula during suction events may lead to ventricular dysrhythmias and
 hemodynamic compromise, further contributing to the low­flow state caused by the suction event and its precipitating insult. An IV fluid bolus can
 increase the preload to the left ventricle, but the underlying precipitating cause should be addressed as soon as possible. In cases where excessive pump speeds are contributing to a suction event, manually reducing the pump speed can resolve the events but should be done only by the LVAD
 team.
MECHANICAL FAILURE
The rate of frequency of component failure varies with the type of LVAD, but any malfunction of any component can result in mechanical failure regardless of the type of LVAD. Cardiopulmonary resuscitation or hemodynamic support are often necessary while the cause of pump failure is identified and managed.

Precordial auscultation should reveal a continuous hum. An undetectable precordial device hum is concerning for mechanical failure, which can result from disruption of power to the LVAD, interruption of the peripheral cables, malfunction of the controller, pump failure, or internal or external driveline fracture (Table 55A­4). Mechanical failure can present with cardiac arrest, symptoms of decompensated heart failure, or a loud continuous
,9 alarm. Continuous­flow LVADs often lack pulsatility, and lack of pulses does not necessarily indicate failure of LVAD.
TABLE 55A­4
LVAD Complications
Component Assessment Management
Power failure Battery charge can be checked by pressing the button on Switch the battery (patients or their caretakers often carry a spare LVAD the physical battery battery) or transition to wall power
Peripheral Evaluate for integrity and connection of all cables extending Plug in any displaced cables cable from the controller unit to the power source Replace any cables that are damaged or fractured disruption
Controller Listen for controller alarms, turn on the controller screen, Controller exchange should be done by an LVAD specialist when possible malfunction and check for error messages Connect the patient’s spare controller to a charged battery or wall power
Disconnect the driveline from the malfunctioning controller and connect to the spare controller
If the patient does not have a spare controller, request emergent LVAD specialist consult for controller exchange
Pump failure Evaluate for other causes of LVAD failure as above; in the Ensure cardiopulmonary support until the pump can be exchanged absence of other causes, auscultate for mechanical device hum; if hum is absent, assume primary pump failure
Driveline Ensure that the driveline connection to the controller is not Request emergent LVAD specialist consult failure or kinked If internal fracture is suspected, attempt gentle manual manipulation of fracture Evaluate integrity of the external portion of the driveline the driveline; if this is successful in restoring pump function, fix the
Obtain two­view chest and abdominal x­rays to evaluate for driveline in position with tape until more definitive management disruption in the internal portion of the driveline
Pump failure usually occurs in the setting of pump thrombosis. Thrombus formation can result after even short periods of pump interruption. Consult
 the LVAD team in stable patients before restarting the pump in the ED. In unstable patients, restarting the pump takes precedence over potential risk
 for thromboembolism while resuscitation and device troubleshooting take place.
CANNULA MALPOSITIONING
Malpositioning of the inflow cannula may result in decompensation, but the diagnosis of a malpositioned cannula is difficult to confirm in the ED.
Apical inflow cannula positioning in the left ventricle is somewhat dynamic. Physiologically significant changes in position may occur over time with changes in patient body habitus, chronic ventricular remodeling, or traction by scar tissue. Such changes can also occur more acutely with the acute geometric reconfiguration of the left ventricle that results from acute left heart failure or right heart failure with interventricular septal deviation.
Malposition of the apical cannula with its orifice facing the interventricular septum or the ventricular free wall can result in obstruction of the cannula, with resultant insufficient LV unloading and a low­flow state. Malpositioning may also play a significant role in cannula and pump thrombosis.
Deviation of cannula away from the apical LV axis can lead to high shear, recirculation, and stagnation, promoting platelet activation and subsequent
 thrombosis. Patients with cannula malpositioning can present with positional or nonpositional syncope, refractory ventricular dysrhythmias, severe hemolysis, and thrombosis. Contrast CT in the ED may show gross obstruction of the malpositioned orifice by myocardium and may aid in confirmed
 associated thrombosis. Echocardiography showing turbulent flow abutting the septum or ventricular free wall also is suggestive of malpositioning.
Confirmation of cannula malpositioning and treatment is operative.
PUMP THROMBOSIS
All patients with LVADs require anticoagulation with warfarin. Direct oral anticoagulants (DOACs)are not yet approved for use in patients with LVADs.
Risk of thrombosis is increased in cases of inadequate anticoagulation, infection, cannula malpositioning or kinking, uncontrolled hypertension, and
,16,17 hypercoagulable states.
The presentation of pump thrombosis is variable and depends on the degree of thrombosis and associated complications. Patients with pump thrombosis may present with symptoms of heart failure or cardiogenic shock. Thrombosis may be complicated by stroke, hemolysis, embolic phenomena, and cardiac arrest. The diagnosis of pump thrombosis is made primarily through evaluation of the LVAD parameters and markers of hemolysis. Patients with incomplete pump thrombosis may present with high­flow alarms. The increase in flow in patients with pump thrombosis
 reflects increased power output in an attempt to overcome the obstruction; the high flow does not reflect an increase in cardiac output in this case. In patients who are operative candidates, replacement of the LVAD pump is the most effective treatment for pump thrombosis. In patients who are not candidates for surgical exchange, thrombolytic therapy has been used with some success, although the rate of thrombosis recurrence is high, and bleeding complications often preclude the use of this therapy.
DRIVELINE FRACTURE
Driveline fractures can occur in the external or internal portions of the driveline, so the fracture may not be readily visible on physical examination.
Driveline fractures are often associated with alarms for low flow, low speed, or low power. Patients with suspected internal driveline fractures should have anteroposterior and lateral plain films of the chest and abdomen, which will show disruption of the driveline. If the diagnosis of driveline fracture is suspected, do not manipulate unless in verbal, virtual, or on­site communication with the cardiothoracic surgeon or other LVAD specialist. In patients who are unstable, gentle manual manipulation of the driveline can be attempted to restore the electrical connection in an internal fracture. If this is successful, the driveline should be externally stabilized with tape in that position until more definitive therapy can be undertaken.
MEDICAL COMPLICATIONS OF LVAD PATIENTS
DYSRHYTHMIAS
Dysrhythmias are common in patients with LVADs, and the most powerful predictor of post­LVAD arrhythmias is occurrence of dysrhythmias prior to

LVAD placement.
Assess for causes, including acute myocardial ischemia, electrolyte abnormalities, mechanical induction from the inflow cannula, and suction
,18 events. Patients may tolerate severe ventricular and atrial dysrhythmias with minimal symptoms or change in vital signs due to the cardiac output
,18,19  generated by the LVAD. Dysrhythmias can also compromise pump flow secondary to RV failure or acute thrombus formation. Maintain continuous cardiac monitoring during patient assessment in the ED, and inquire about ICD events prior to the ED assessment.
POCUS echocardiography may show the presence of a decompressed left ventricle, complete LV collapse, and septal shift toward the left ventricle as
,20 the trigger for dysrhythmias. In hemodynamically unstable patients, follow ACLS protocols. Cardioversion is compatible with the LVAD. Do not
 place the defibrillation pads over the pump.
AORTIC REGURGITATION

Aortic regurgitation may develop after LVAD placement, even in those without aortic regurgitation pre­implantation. The hemodynamic consequence is the creation of a redundant circulatory loop whereby blood flow from the LVAD outflow graft flows retrograde into the left ventricle via the
 incompetent aortic valve, and then re­enters the LVAD. This ineffective recirculation increases the pump work and decreases systemic perfusion.
When evaluating the LVAD controller, reported variables (particularly pulsatility index and pump flow) may remain unchanged if the patient has only mild or moderate aortic regurgitation. In severe cases, the system controller will indicate higher flow, higher power, and lower pulsatility index for a given pump speed. LVAD flow is not measured directly but rather derived from a variety of factors, which leads the system to report increased flows that do not reflect total cardiac output. Aortic regurgitation leads to LV distention and worsening heart failure, which lowers the pulsatility index. This can also lead to mitral regurgitation, pulmonary edema, and RV failure. Patients will present with signs and symptoms of worsening heart failure with the LVAD parameter changes noted above, and bedside echocardiography will show the presence of a regurgitant jet through the aortic valve. Typical medical therapy using diuretics for hypervolemia and vasodilators for afterload reduction are used. Definitive treatment is often surgical correction or percutaneous intervention using either transcatheter aortic valve implantation or percutaneous occluder devices.
RV FAILURE

RV failure is a major cause of morbidity and mortality in LVAD patients, as the right ventricle remains “unprotected” by the LVAD. Many patients with LV dysfunction severe enough to warrant an LVAD have some element of RV dysfunction, and RV failure develops in many patients after LVAD
 implantation. RV failure may be due to ventricular dysrhythmias, pulmonary embolism, myocardial ischemia, worsening pulmonary hypertension, device malfunction or thrombosis, and new or worsening tricuspid regurgitation. RV failure leads to reduced preload to the LVAD and subsequent low
 flow. RV failure may present with signs and symptoms of heart failure or cardiogenic shock, as well as elevated liver function values, creatinine, and
 lactic acid. Management of RV failure in LVAD patients is similar to that in non­LVAD patients. A small number of patients will need to be considered for an RV assist device (RVAD), total artificial heart (TAH), or other forms of mechanical support.
GASTROINTESTINAL BLEEDING
The GI system is the most common site of bleeding. Patients requiring LVADs often have a history of renal or hepatic dysfunction, and the bleeding risk is augmented by exogenous anticoagulant and antiplatelet use in patients with LVAD. Non­physiologic continuous flow through an LVAD contributes to activation of the fibrinolytic pathway, endothelial and platelet dysfunction, vascular remodeling, angiogenesis, and shearing of von Willebrand factor
(vWF) multimers. Continuous flow and decreased pulse pressure from LVAD support contribute to the formation of arteriovenous malformations and
 angiodysplasia, mostly in the GI mucosa. Treatment is hemodynamic stabilization and blood products as needed.
Use leukoreduced and irradiated blood products if available, as these decrease the risk of sensitization. Avoid large­volume resuscitation if possible,
 as this may increase afterload and contribute to worsening heart failure. Give high­dose proton pump inhibitors. Octreotide appears to be effective.
Desmopressin or vWF concentrates also can be considered.
INFECTION
Sepsis (bacteremia, mediastinitis, and endocarditis) most often occurs within the first year, often within the first month, of implantation and can occur secondary to infection of device components, device­related infections, and non–device­related infections. Infections of the percutaneous driveline are the most common cause.
The most common pathogens are Staphylococcus aureus and Pseudomonas, but fungal infections with Candida account for some infections and are
 associated with high mortality. In patients with suspected LVAD­specific or LVAD­related infections, an antifungal should be added to the empiric
 antibiotic regimen.
Common non–device­related infections in patients with LVAD include pneumonia, urinary tract infections, and Clostridioides difficile infection. Follow current therapeutic guidelines for assessment and management. Driveline infection can involve the skin and superficial soft tissues or can extend
 more deeply, affecting the muscles and fascia of the abdominal wall. CT of the abdomen with IV contrast can evaluate the extent of the infection. The
 most commonly implicated organisms in driveline infections are staphylococcal and pseudomonal species. Gram­negative species are more likely to be associated with deep­space infections. Of note, fungal infection with Candida accounts for some driveline infections, so consider antifungal
 coverage in patients with suspected driveline infections. Remember to consider antibiotic interactions with warfarin.
STROKE
While the risk of stroke has decreased with newer­generation LVAD devices, stroke remains the most common cause of death in LVAD patients between

6­ and 24­months post­implantation. The most common causes of stroke in patients with LVAD are cardioembolic and primary intracerebral hemorrhage in the setting of anticoagulation. Septic or air embolism or ischemia from poor cardiac output are less common causes.
Hypercoagulability leading to ischemic stroke occurs through a combination of the activation of the extrinsic coagulation pathway by foreign pump
 materials, platelet activation, and stasis due to poor cardiac output. Vascular shear stress from non­physiologic flow may also damage the endothelium and accelerate atherosclerotic plaque formation. The risk for hemorrhagic stroke results from both the use of exogenous anticoagulants and endogenous physiologic alterations in response to LVAD placement. Impairment of cerebral autoregulation secondary to non­physiologic blood
 flow results in endothelial dysfunction and vascular smooth muscle proliferation. Acquired von Willebrand disease through shearing of vWF
 multimers in continuous­flow LVADs further contributes to coagulopathy.
Obtain CT and CTA of the head and neck in the patient with an LVAD who has neurologic symptoms. Current LVADs are not MRI compatible, and MRI is contraindicated in any patient with LVAD. Therapy for ischemic stroke in LVAD patients is complicated by baseline antiplatelet and anticoagulant use.
The presence of an LVAD is not a contraindication to the use of thrombolytics per se, but minimal data are currently available on risks and benefits of
 thrombolytic agents in patients with LVADs. While experience with endovascular therapy (EVT) in the LVAD population is limited, EVT is a viable
 treatment for eligible patients with large vessel occlusion.
Hemorrhagic stroke in patients with LVAD is treated similarly to stroke in the non­LVAD population. A decision to reverse anticoagulation is best made with an interdisciplinary team involving stroke neurology and cardiology. To prevent hemorrhagic propagation, systolic blood pressure should be
 between 140 and 160 mm Hg for the first 24–48 h using intravenous medications. Continuous blood pressure measurement with an arterial line is preferred to intermittent blood pressure cuff measurements.
HYPERTENSIVE EMERGENCY
LVADs are exquisitely afterload sensitive, and increases in blood pressure can lead to decreased pump flow and decompensated heart failure.

Guideline definitions for hypertension in patients with LVAD vary but define hypertension as MAP >80–90 mm Hg. Decreased forward flow in the setting of uncontrolled blood pressure increases risk for pump thrombosis, aortic regurgitation, hemorrhagic and ischemic strokes, and RV dysfunction. Increased filling pressures can result in subendocardial ischemia and increase the risk for ventricular dysrhythmias. The rate of hypertension­related adverse events increases significantly in patients with MAP >110 mm Hg. Intravenous vasodilators should be used to maintain
MAP <80 mm Hg to optimize afterload for LVAD function. When choosing intravenous vasodilators, consider the patient’s underlying condition. Nondihydropyridine calcium channel blockers and beta­blockers are not recommended due to their negative inotropic effects in this setting. Hydralazine,
 nitroglycerin, nicardipine, and nitroprusside are commonly used.
ACUTE KIDNEY INJURY
Acute kidney injury (AKI) is a frequent complication following LVAD implantation in the immediate and longer­term postoperative periods. Avoid
 nephrotoxic agents when possible. Maintain euvolemia.


