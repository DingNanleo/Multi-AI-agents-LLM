## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 149: Behavioral Disorders in Children
Quynh H. Doan; Tyler R. Black
INTRODUCTION
Pediatric mental health emergencies encompass a range of conditions, including psychiatric conditions such as mood and anxiety disorders
(depression, bipolar disorder, suicidal ideation, obsessive compulsive disorders, posttraumatic stress syndrome), exacerbations of behavioral disorders (attention­deficit/hyperactivity disorder, aggressive outbursts, conduct disorders), deteriorating neurodevelopmental disorders (autistic spectrum disorders, tic disorders, intellectual disabilities), addictive disorders, and eating disorders. The psychological and sometimes physical aftermath of child maltreatment, mass casualty incidents and disasters, and exposure to violence and unexpected deaths are also likely causes of
1­4 mental health emergencies.
Traditionally, the role of the emergency provider includes medically stabilizing children presenting with a mental health complaint, differentiating physical from mental health causes of symptoms, performing a psychosocial assessment, and directing patients and families toward appropriate resources for acute and long­term needs. Initial management may include pharmacologic therapy, physical restraint, and referral for inpatient
,5 admission. More recently, increased recognition of the burden of unidentified mental health concerns among vulnerable youth has led to calls for universal screening of psychosocial status for youth seeking medical care in the ED. Barriers to universal screening for mental health conditions in the
ED include time restrictions, lack of familiarity with screening instruments, often fragmented or limited local community resources, and reluctance to
 broach the subject of mental health on the part of families seeking urgent medical care.
Despite these barriers, a number of brief screening tools targeting specific conditions such as suicidal risk (Ask Suicide­Screening Questions and Risk of Suicide Questionnaire; see later section, “Suicidal Ideation and Attempts”), depression (Beck Depression Inventory­II), anxiety (revised parental and child versions of the Screen for Child Anxiety­Related Disorders), and alcohol use disorder (Diagnostic and Statistical Manual of Mental Disorders,

Fourth Edition, 2­Item Scale), have been validated in the ED population to identify youth requiring further assessment. Although concerns about privacy and ity are sometimes raised by families, a study of mental health screening in the ED suggests that most parents and youth find the
 process acceptable, and clinicians report that screening does not interfere with medical care.
EPIDEMIOLOGY
The mental health crisis involves all socioeconomic and ethnic groups and is not unique to any one geographic area, state, or region. A meta­analysis of worldwide prevalence of mental health disorders suggests that North America has the highest prevalence of mental health disorders in children and
 adolescents (19.9%) with lower rates in Europe (12%) and Africa (8.3%); there is a peak prevalence among youth age  to  years. National surveillance data from the United States and Canada report a prevalence of pediatric mental health disorders of 10% to 20% and suicide as the second
,11 most common cause of mortality among youth.
Although the prevalence of youth mental health disorders remains stable, acute care visits for mental health–related issues are on the rise. In the
United States, both the absolute number (from 565,000 to 823,000) and proportion of all ED visits (from .0% to .8%) by children and youth for a
 mental health problem are on the rise. The Pediatric Emergency Care Applied Research Network reported that .3% of all participating pediatric ED visits were made for psychiatric­related visits. These visits are more frequently arriving by ambulance, are associated with longer length of stay, and
 result in admission to the hospital more commonly than other causes for ED visits. Between 2006 and 2011, ED visits for a mental health–related
 concern increased in the United States by 21%, and hospitalizations for a mental health condition increased by 50%. In Canada, ED visits and hospitalizations for mental health conditions increased by 66% and 55%, respectively, from 2007 to 2017. Pediatric psychiatric emergencies show seasonal variation and are more common during the school year, peaking in May and November, while reaching a nadir in July and August. While the vDiosiwt dnilsotardibeudt i2o0n2 o5v­e7r­ d1 a6y:s1 o6f Pth eY wouere kIP a pisp 1e3a6rs. 1to4 2b.e1 5ev9e.1n2, 7visits occur more frequently in the evening, coinciding with a time period when most
Chapter 149: Behavioral Disorders in Children, Quynh H. Doan; Tyler R. Black 
 outpatient community mental health resources are not easily reachable.
. Terms of Use * Privacy Policy * Notice * Accessibility
The cause of the dramatic rise in pediatric mental health emergencies is multifactorial and complex. Factors contributing to the high prevalence of mental illnesses among youth include family instability or dysfunction, economic crisis or financial hardship, inadequate numbers of mental health professionals (especially those with pediatric expertise), lack of access to care, shortage of funding for mental health services, and failure to seek care
 due to cultural stigma. In addition, social networking exposes youths to cyberbullying, online harassment, social isolation, and “Facebook
 depression,” adding further risks for developing mental health illnesses. Multiple economic forces negatively impact the availability and delivery of
,4,5,17,18  mental health services and have transformed EDs into the safety net for a fragmented mental health infrastructure. A lack of mental health follow­up or aftercare further contributes to the problem: of patients discharged from psychiatric emergency facilities, 40% to 60% do not receive
 aftercare, increasing the risk of repeat ED visits.
CLINICAL ASSESSMENT
GENERAL GOALS
First, identify and treat acute life­threatening medical emergencies. Next, determine if the child poses an imminent threat to his or her own life or the life of others, as this determines the need for hospitalization. Finally, exclude organic causes for psychiatric presentations. Table 149­1 lists medical and psychiatric conditions that may present with agitation, psychosis, or obtundation. Table 149­2 enumerates some general characteristics that may distinguish organic from psychiatric causes of psychosis.
TABLE 149­1
Medical and Psychiatric Causes of Altered Mental Status in Children
Medical Conditions Psychiatric Conditions
CNS disorders Acute mania
Brain tumor Bipolar disorder
Temporal lobe epilepsy Depression
Trauma Acute psychosis (e.g., schizophrenia)
Infection (abscess, encephalitis, meningitis) Personality disorder
Metabolic/endocrine disorders Conduct disorder
Hyperglycemia, hypoglycemia
Thyroid disease
Uremia
Hepatic failure
Porphyria
Collagen vascular diseases
Lupus erythematosus
Vasculitis
Hyperpyrexia
Intoxication or withdrawal
Drugs of abuse (alcohol, stimulants, depressants, hallucinogens)
Medications (antipsychotics, corticosteroids)
Environmental substances (anticholinergics, heavy metals)
TABLE 149­2
Differentiation of Organic and Psychiatric Psychosis
Characteristic Organic Cause Psychiatric Cause
History: onset and progression Acute Gradual/progressive
Vital signs Often disturbed Usually normal
Physical examination
Focal neurologic symptoms May be present Usually absent
Mental status Delirium, visual hallucinations, agitation Anger, sadness, auditory hallucinations, agitation
Laboratory findings May be altered Usually normal
HISTORY
Focus the history on the chief complaint and details of the presenting symptoms, circumstances, and precipitating events (e.g., social stressors). The timing and sequence of events, associated symptoms, and review of systems may help to distinguish organic from psychiatric conditions. Auditory hallucinations are associated with psychosis, but visual hallucinations may indicate intoxication or organic causes. A history of head injury, chronic or progressive headaches, visual changes, vomiting (especially morning vomiting), and deterioration of motor skills or gait suggests an intracranial process such as a brain tumor or subdural hematoma. Constitutional symptoms that may provide clues to an organic etiology include temperature instability, palpitations, and changes in appetite, stool patterns, hair, or skin.
The past medical history and family history will help identify the pattern and chronicity of the presenting symptoms. Similarly, a review of medications, including adherence to prescribed medication regimens, and their efficacy will guide the treatment plan and disposition. A family history of psychiatric or organic disease may indicate a potential genetic predisposition.
In addition to noting these standard components of history, conduct a focused psychosocial assessment. Children and adolescents presenting to the
ED with behavioral or psychiatric emergencies should be asked about exposure to violence at home or school. See also Chapter 150, “Child Abuse and
Neglect.” Two assessment tools have been designed for this use in the ED: HEADS­ED and HEARTSMAP. HEADS­ED recommends a psychiatric assessment by a mental health clinician for a cumulative score of ≥7 and if the suicide risk score is ≥2.  HEARTSMAP provides specific recommendations for the type (social, youth health, psychiatric, and protective) and urgency (in ED consultation vs. community­based resources) of
,21 mental health service needs (Table 149­3).
TABLE 149­3
HEARTSMAP Structured Mental Health Screening Tool
Scoring (With Descriptors)
Psychosocial
Probing Questions Current Resources
Sections

Home Is there difficulty or fighting at No Supportive of Unsupportive Dysfunctional Social supports neither home between family concerns youth’s difficulties (parents at risk (parental requested nor initiated members? but some conflicts for burnout) burnout) Social supports
How do you get along with Frequent Homelessness involved (resource
[guardian/parents/family]? conflicts Major conflicts requested and services
How do you feel about your initiated) home environment?
Education and How is school going for you? No Struggle to Performance Failing/major Educational/activity activities Are there any difficulties going concerns maintain decline issues issues not yet to school or staying in class? Difficulty Missing Not attending addressed
What do you do for fun? Has attending classes/activities Completely Functional plan in that changed recently? Attends more than Misses more than truant (excluding place (counselor misses attends holidays) involved)
Alcohol and How much is alcohol use a part No Infrequent Regular Bingeing No detox or
Drugs of your life? concerns Mild recreational recreational use recreational use rehabilitation services
Do you use any substances like use Mild substance Substance abuse suggested yet marijuana? How about any misuse Substance use services others? in place (referred and
Do you ever use drugs or offered) alcohol to feel better or to make a problem go away?
Relationships How are things going for you No Minor Conflicts/bullying Conflicts/bullying No support or and bullying with friends and relationships? concerns conflicts/bullying Negative changes Negative changes resources initiated
Do you have a close Struggle to Educational or social person/group of people that maintain plan in place (school you can rely on? authority or social
Do you feel teased, bullied, or worker aware and excluded by others? addressing)
Do you have any struggles with your sexual identity or sexual preference?
Thoughts and Do you consider yourself a No Anxiety/odd Anxiety/odd Anxiety/odd No psychiatric anxiety worrier or think a lot about the concerns thoughts (minimal thoughts thoughts assessment or services past or future? impact) (minimal impact) (minimal impact) initiated yet (no
Do you ever experience appointment in sight) panic/extreme fear that comes A mental health out of the blue? clinician such as
Do you ever have times where psychiatrist, counselor, you feel your brain is playing or psychologist is tricks on you? involved or will be involved shortly and is available in the long term
Safety Do you sometimes feel No Fleeting or Fleeting or Fleeting or No plan for current hopeless or that life is not concerns improving improving improving safety concern worth living, or have you ever thoughts thoughts thoughts Safety planning in felt that you or your family Nonsuicidal self­ Nonsuicidal self­ Nonsuicidal self­ place and consistent would be better off if you were injury injury injury with current dead? suicidality/homicidality
In the past few weeks, have you seriously considered ending your life, or have you ever tried to end your life?
In the past few weeks, have you thought of harming yourself?
Sexual health Are you involved in any sexual No Sexually active Stable partner Multiple partners Sexual health issues activities, not limited to concerns and safe practice but inconsistent or no use of not yet approached penetration? (contraception use of protection protection or with healthcare
Do you use any mode of and sexually and contraception professional contraception? transmitted contraception Involved in sex Has a primary care
What of form of protection disease trade provider and issues of against sexually transmitted protection) sexual health/family disease do you use, if any? planning addressed
Do you get any counseling about sexual health from a doctor or nurse?
Mood and How would you rate your No Mood instability Mood instability Mood instability No psychiatric behavior mood, with  being as low as concerns (minor) (minor) (minor) assessment or services possible and  being perfectly initiated yet (no happy? appointment in sight)
Do you feel down or depressed A mental health recently? clinician such as
Do you feel really happy or psychiatrist, counselor, energetic lately? or psychologist is involved or will be involved shortly and is available in the long term
Abuse To child: Has anyone ever hurt No Concern has been raised and reported Current concern Notification has you by touching you in a way concerns to the ministry of abuse or occurred you didn’t like? Historical concerns neglect/not Notification has not yet
To adolescent: Have you ever reported occurred experienced abuse, either physical, emotional, or sexual?
To caregiver: Do you have any concerns of abuse or mistreatment?
Professionals Do you feel that there are Service Referred for service but access delayed Longitudinal services unavailable, but and resources people or places you can go to plan in (wait­listed) necessary for help? place or Not yet referred or refusing
Who is working with you on available services/treatment these issues?
Does the current plan to help make sense to you?
Note: For full functionality with scoring algorithm–triggered management recommendations, use the online version at www.openheartsmap.ca.
PHYSICAL EXAMINATION
Assess vital signs, airway, breathing, and circulation, and then perform a detailed neurologic examination. Alterations in vital signs may provide clues to potential intoxication, ingestions, or organic pathology (endocrinologic and metabolic). Tachycardia, hypertension, pyrexia, and tachypnea may suggest intoxication with stimulants such as amphetamines, cocaine, and “ecstasy” (3,4­methylenedioxymethamphetamine). Assess for other toxidromes including anticholinergic symptoms or signs of salicylate toxicity. Pupillary responses, the presence or absence of nystagmus, skin temperature and moisture, and the condition of the mucous membranes are all helpful in identifying toxidromes (see Chapter 176, “General
Management of Poisoned Patients”).
Focus the neurologic examination on level of consciousness, gait and coordination, and reflexes, and administer the Mini­Mental Status Examination as appropriate for age (Table 288­2). Note the child’s affect and general appearance, content and organization of thought, and articulation and expression of speech. Pressured speech with flight of ideas may signal acute mania, whereas echolalia, “word salad,” and other disordered thought may indicate acute psychosis.
LABORATORY TESTING AND IMAGING
Laboratory tests and imaging are dictated by the history and physical examination. Pubertal girls should have a urine pregnancy test. Urine drug screening can be helpful when intoxication from drugs of abuse is suspected. Obtain serum acetaminophen (Tylenol®) and salicylate (aspirin) levels in children who have ingested drugs or attempted suicide, as self­report of quantity and type of drug used is not always reliable. Hyperglycemia, hypoglycemia, and hyperammonemia can cause alterations in mental status, so check serum glucose and consider ammonia in obtunded patients.
Obtain a 12­lead ECG in cases of potential ingestion or intoxication to identify interval prolongation or conduction abnormalities. Document normal sinus rhythm at baseline before initiating psychotropic medications that may accentuate long QT disorders. Screening laboratory tests performed in psychiatric emergencies vary by institution, and many inpatient psychiatric facilities require basic chemistry panels and screening for thyroid disorders. See Chapter 140, “Altered Mental Status in Children,” for further discussion of the approach to altered mental status.
Imaging studies are rarely indicated or helpful except as directed by the history and physical examination. Chest radiographs may identify aspiration in the obtunded vomiting patient. Abdominal radiographs may identify radiopaque foreign objects or ingestions. Neuroimaging can exclude intracranial mass lesions in those with suggestive clinical signs and symptoms.
MANAGEMENT OF PSYCHIATRIC PRESENTATIONS
A detailed summary of child and youth mental health issues is beyond the scope of this book. Formal diagnoses of mental health conditions usually occur after the ED presentation. Therefore, this section will focus on the approach to, and treatment of, psychiatric presentations. Many care environments use social workers, youth care workers, nurses, and other clinicians to conduct significant portions of the mental health assessment in the ED.
SUICIDAL IDEATION AND ATTEMPTS
Suicide is complex. Contrary to belief, adolescents are not at higher risk for suicide than adults, and the risk for suicide completion starts at age  and
 increases throughout the teen years (Figure 149­1). Although it is one of the most common causes of death in youth (4.7 per 100,000 per year
 between the ages of  and , more than neoplasm, respiratory, and cardiovascular deaths combined), the vast majority of youth who have suicidal
23­25  thinking or behaviors do not go on to complete suicide (Table 149­4). Risk prediction is currently not possible. Therefore, focus on identifying risk/protective factors and acuity, collateral history, clinical synthesis, and safety management.
FIGURE 149­1. Suicide rates by sex, United States, 1999 to 2016. [From Centers for Disease Control and Prevention, National Center for Health Statistics. Underlying
Cause of Death 1999­2016 on CDC WONDER Online Database, released December 2017. Data are from the Multiple Cause of Death Files, 1999­2016, as compiled from data provided by the  vital statistics jurisdictions through the Vital Statistics Cooperative Program.]
TABLE 149­4
Frequencies of Suicide Items in Youth  to  Years of Age, in the United States
1­Year Prevalence Frequency
Feeling sad or hopeless for  weeks* .5% 1:3.2
Nonsuicidal self­injury .0% 1:5.6
Suicidal ideation* .2% 1:5.8
Suicide planning* .6% 1:7.4
Suicide attempt (any)* .4% 1:13.5
Suicide attempt (potentially lethal)* .7% 1:41.6
Death by suicide† .0059% 1:16,899
Note: Data is from 2017, except nonsuicidal self­injury (meta­analysis 2014) and death by suicide (2016).
*Females generally twice as likely.
†Males generally four times as likely.
A number of risk factors are associated with increased suicide risk, and suicide risk is fluid and can change rapidly. Identification of risk factors should be carried out with the goal of separating chronic (longstanding and unlikely to change) from acute (recent and possible to change) risk factors. Chronic risk factors convey ongoing risk and are important for informing systemic rather than individual approaches. Acute risk factors allow for individual approaches for suicide safety planning. Protective factors reduce risk overall and should be considered in risk factor identification. A
22­26 representative, noncomprehensive list of risk and protective factors is presented in Table 149­5. TABLE 149­5
Selection of Common Chronic and Acute Risk Factors and Protective Factors for Suicide
Chronic Risk Factors
History of suicidal thinking or Any suicidal factor by history is one of the only consistent predictive measures for suicide risk.
behavior
History of mental health Lifetime risk of suicide is increased in almost all mental health disorders.
disorder
Age Exceedingly rare <10 y of age. Risk starts at approximately age  and increases consistently until the age of . Adolescents are less at risk for suicide than adults.
Sex Males 4–5 times more likely by adolescence.
Ethnic or cultural risk group Aboriginal youth, homeless youth, LGBTQ (lesbian, gay, bisexual, transgender, or queer) youth.
Chronic illness Any chronic illness causing pain, disability, or fatigue.
Family history of suicide Closer­degree relatives infer a greater risk.
History of trauma, abuse, Duration, frequency, and severity of trauma is additive.
neglect, loss
Acute Risk Factors
Recent suicidal thoughts or Ideation < planning < nonlethal attempt < lethal attempt. New/changing suicidality should prompt full assessment.
behaviors
Suicide planning Passive (nonspecific wish to die) confers less risk than active (specific, formed plan).
Accessibility to lethal means Unsecured substances, medications, firearms. Feasibility of plan.
High agitation/anxiety Strong (yet poorly specific) prediction of acute suicide risk.
presentation
Current mental Those with lack of treatment response, noncompliance to treatment, or worsening or rapidly changing disorders health/substance use disorder should be targets of suicide risk reduction.
Family dysfunction/caregiver Chaotic, dysfunctional homes confer suicide risk. A responsible caregiver must be in place to institute safety unavailable management measures.
Lack of professional supports Can include supports that are not effective.
Recent crisis/major life change Conflicts, relationships, school, failures, losses, etc. Directly addressing these crises reduces risk.
Protective Factors
Parent connectedness Sport/activity participation Positive social supports
Safety of environment Strong professional supports Future orientation
Good therapeutic connection Strong cultural identity Responding to treatment
Assessment scales and tools for assessment should be used to gather information to contribute to the assessment process rather than rigid structures to guide decision making. In the ED, brief screening questionnaires such as the Ask Suicide­Screening Questions (Table 149­6) can help identify
 patients with suicidal thinking. The Ask Suicide­Screening Questions assess four areas: (1) current thoughts of being better off dead; (2) current wish to die; (3) current suicidal ideation; and (4) past suicide attempt. A positive response to any one question identified 97% of those at risk for suicide

(sensitivity .7%, specificity .6%). The Columbia–Suicide Severity Rating Scale (available for download at http://www.cssrs.columbia.edu/scales_practice_cssrs.html) can help guide assessment of suicidal thinking and behaviors and has been validated for
,29 use in multiple settings, including the ED, for both adolescents and adults. The internal validity and usability rates are high for such scales. Some more commonly used scales, such as the SADPERSONS, have little evidentiary support, contain many inaccurate assumptions about suicide risk, and
30­34 do not accurately predict suicide.
TABLE 149­6
Ask Suicide­Screening Questions Tool for Suicidality
Question (Yes/No) Interpretation
. In the past few weeks, have you wished you were dead? “No” to all  questions is a negative screen.
“Yes” to any question is a positive screen; proceed to question  below.
. In the past few weeks, have you felt that you or your family would be better off if you were dead?
. In the past week, have you been having thoughts about killing yourself?
. Have you ever tried to kill yourself? (If yes, how? When?)
. Are you having thoughts of killing yourself right now? (If yes, describe.) “Yes” is an acute positive screen and requires emergent mental health evaluation and safety plan.
“No” is a nonacute positive screen and requires further safety assessment.
Note: Ask Suicide­Screening Questions tool can be found at https://www.nimh.nih.gov/labs­at­nimh/asq­toolkit­materials/asq­tool/asq­screening­tool.shtml.
Clinical interview, impression, and analysis are crucial aspects of suicide risk assessment. Collateral history for the youth (e.g., parents, caregivers, clinicians, teachers) adds to the confidence of the assessment and can significantly affect the quality of the risk assessment. If an interview has poor reliability or rapport, the “collected data” may be inaccurate. The tone of the patients themselves, their family, and the support network around them can alter the impression of hope or despair. The importance of clinical and interpersonal factors cannot be understated and is why a reliance on rigid
 data, forms, or quantities is perilous.
Safety management, following an adequate risk assessment, flows naturally from identified risk and protective factors. By dividing risk factors into acute and chronic categories, targeted interventions for any acute risk factors can be made. Creating safety plans for families and youth to use
 when suicidal ideation occurs can increase compliance with follow­up programming, encourages appropriate re­presentation to the ED, and provides a sense of structure and support to families struggling with suicide concerns. Figure 149­2 provides an emergency approach to suicidal presentations, and the approach can be done in a multidisciplinary way—a physician is not required for any one step.
FIGURE 149­2. Approach to suicidality in the ED.
Determination of the risk factors will influence the services consulted; social issues require social support services, whereas psychiatric issues require mental health supports. Rigid consultation of all suicidal patients to psychiatric care is neither necessary nor effective; inpatient and involuntary approaches to patients are beneficial when the risk profile is simply too high to manage in the outpatient environment and inpatient services are required to reduce the identified risk factors. Examples of nonpsychiatric risk reduction maneuvers include removing lethal means, securing firearms, creating safety plans, referring to social support services, providing family supports, and addressing social and school concerns. Resolution of any triggering crisis severely reduces severity risk.
NONSUICIDAL SELF­INJURY

Nonsuicidal self­injury is “the deliberate, self­inflicted destruction of body tissue without suicidal intent and for purposes not socially sanctioned,” and refers to a wide variety of behaviors including cutting, burning, carving, punching, and picking. Approximately 18% of adolescents have engaged in nonsuicidal self­injury in the past year, and recent studies report that as many as 47% of females have tried it, even briefly. Nonsuicidal self­injury begins in puberty and is twice as common in females, peaking in middle adolescence and declining thereafter. Although it increases suicide risk, over

90% of youth presenting to crisis services with nonsuicidal self­injury have no intent of suicide. Biologic predispositions to self­injury include an absent stress cortisol response, sensitivity of opioid receptors, and genetics.
First, address the sequelae of the injury, and focus on the distress and events that led to self­injury. Avoid overreaction to superficial injuries; comments such as “You could have killed yourself” or “These injuries look awful” may harm the patient and even increase subsequent behavior. Such comments can confuse the message that self­injury is different from suicide. Second, conduct suicide risk assessment, especially for new or changing self­injury or in the presence of other developing mental health issues. Explain the difference between nonsuicidal self­injury and suicidal behaviors to caregivers. Finally, provide social and mental health support resources to improve distress tolerance, stress management, and family supports.
AGGRESSION
Aggression can occur prior to ED presentation, before or during assessment, and in subsequent care. Consider patient and environmental safety,
 potential trauma to the child or family, engagement and de­escalation whenever possible, and safe medication and restraint policies.
Pharmacologic interventions require consideration of the intention of the intervention. If the underlying issue is psychosis or mania, potent antipsychotic medications are warranted. However, if agitation is behavioral, reactionary, or anxiety driven in nature, and the goal of intervention is sedation, many less potent and potentially less dangerous approaches can be taken. An approach to aggression in the ED is outlined in Table 149­7,
,41 with pharmacologic options in Table 149­8. TABLE 149­7
Approach to the Pediatric Aggressive Patient
Safety Secure patient and staff safety. Recognize the compromise between security and safety: higher­security measures (e.g., pharmacologic or physical restraint) may also confer greater risk for patient harm. Use these measures when appropriate.
Engagement Youth often use aggression as their last resort to express or achieve something: expressing anger, being left alone, interfering in treatment, or receiving something desired. Engaging the youth whenever possible to help achieve these goals can reduce the need for further measures. ALWAYS allow the situation to “step down” (i.e., reoffer oral medications before injection).
Interventions, in the order they should be attempted when possible:
. Secure the environment for patient safety and to encourage engagement. Environments with safe furniture and objects, full observation
Environment abilities, and adequate staffing are required.
and engagement
. See Table 149­8. Consider low doses and reengage as necessary.
Pharmacology
(voluntary)
. See Table 149­8. Minimize the need for reinjection of medications by choosing dosing appropriately. Physical restraint is often necessary.
Pharmacology Offer oral medications immediately before intramuscular medications.
(involuntary)
. Seclusion Ensure the facility has appropriate seclusion and restraint policies. All seclusion and restraint policies require 1:1 observation. Remove and restraint restraints as soon as possible. Consider the possibility of rhabdomyolysis with physical restraints and asphyxia with person­to­person holds.
TABLE 149­8
Pharmacologic Management of the Agitated Child
Adolescent
Drug Child Dosing Notes
Dosing
Appropriate for Sedation in Children
Diphenhydramine 25–50 milligrams 50–100 milligrams Anticholinergic. Directly treats dystonia from antipsychotic treatment. Caution in
 PO/IM PO/IM suspected delirium as antihistamines are notoriously responsible for worsening and milligram/kg Maximum: 200 Maximum: 300 causing delirium. Liquid form available.
May repeat milligrams/24 h milligrams/24 h q30min
Lorazepam .5–2 milligrams 1–2 milligrams Paradoxical reaction can occur (but unlikely, and though vigilance is necessary, do not
### .05 PO/IM PO/IM withhold benzodiazepines to avoid this unless documented reaction). Respiratory milligram/kg Maximum: Until Maximum: Until depression. Sublingual tablet available.
May repeat sedated or sedated or q30min ataxic ataxic
Appropriate for Sedation and/or Psychosis in Children
Olanzapine .5 milligrams 5–10 milligrams QTc sparing. Dystonic reaction can occur but unlikely. Warning: IM preparation
### .1 PO/IM PO/IM coadministered with benzodiazepine IM is not recommended because it can cause milligram/kg Maximum:  Maximum:  bradycardia and hypotension. Dissolvable tablet available. Anticholinergic.
May repeat milligrams/24 h milligrams/24 h q30min
Risperidone .25–0.5 milligram .5–1 milligram PO QTc sparing. Dystonic reaction can occur. Dissolvable tablet and liquid form available.
### .05 PO Maximum:  milligram/kg Maximum:  milligrams/24 h
May repeat milligrams/24 h q60min
Methotrimeprazine .5­25 milligrams .5–50 milligrams Hypotension, QTc prolonging, lowers seizure threshold. Anticholinergic.
 PO PO milligram/kg .5­25 milligrams .5–50 milligrams
PO IM IM
### .5 Maximum: Maximum: milligram/kg 100 200
IM milligrams/24 milligrams/24
May repeat h PO h PO q30min  100 milligrams/24 milligrams/24 h IM h IM
Appropriate for Psychosis in Children (when other treatments unavailable or failed)
Haloperidol .5–2 milligrams 2–5 milligrams QTc prolonging. Extrapyramidal symptoms very likely in youth,42­46 especially
### .05 PO/IM PO/IM dystonia. Consider coadministration of prophylactic anticholinergic (e.g., milligram/kg Maximum:  Maximum:  diphenhydramine as above or benztropine 1–2 milligrams PO/IM).
May repeat milligrams/24 h milligrams/24 h q60min
ANXIETY AND DEPRESSION
ED presentations for anxiety and depression are common. For anxiety, this is often in the form of panic, dysregulation, or regressive behavior. In depression, common presentations include irritability, hopelessness, or sadness. Signs and symptoms of anxiety and depression vary with age; younger children exhibit more regressive, agitated, or withdrawn behaviors, whereas adolescents tend to be able to express their emotional state through direct conversation. Both anxiety and depression in youth can also present with impaired concentration, fatigue, and insomnia. Perform suicide risk screening and assessments as appropriate.
Anxiety or irritability can be relieved in the ED through the use of sublingual lorazepam. Most often, treatments of anxiety and depressive disorders are
 combination approaches ; proper treatment includes the use of therapeutic approaches (cognitive behavioral therapy, interpersonal therapy) and medications (selective serotonin reuptake inhibitors) that usually exceed the scope of an ED. Severe, disabling, or suicide­related anxiety or depression concerns should warrant a consultation to psychiatric service; for milder issues, referral to appropriate mental health supports can be made.
PSYCHOSIS
Psychosis is a generic term that describes a process in which someone’s thought or sensory process no longer conforms to reality. Often it is confused
 as a diagnosis (e.g., schizophrenia), when in fact, the presentation of psychosis can be brought about by a variety of conditions, including benign
(hypnagogic hallucinations that occur in sleep­wake transition, normal bereavement), medical (CNS tumors, delirium), psychiatric (schizophrenia, bipolar mania), and substance induced (steroids, drugs of abuse). Psychosis is a syndrome of exclusion; potentially dangerous medical diagnoses must be considered and ruled out prior to psychiatric treatment (Tables 149­1 and 149­2).
Psychiatric causes of psychosis are rare in prepubertal children; in fact, these disorders usually manifest at around  years of age. However, many adolescents can have prodromal presentations, and early­onset bipolar disorder, schizophrenia, and other psychiatric causes of psychosis are possible. Predictors of psychosis include a family history (especially first­degree relatives), progressive decline (rather than abrupt), and a history of
 subclinical psychotic symptoms.
The approach to psychosis varies depending on the cause (Table 149­9). In the ED, the antipsychotic medications listed in Table 149­8 can be tried for agitation or urgent symptom concerns; however, caution must be used, because delirium or substance intoxication as a root cause of the psychosis could be worsened by the addition of psychotropic medications.
TABLE 149­9
Approach to Psychosis in the ED by Suspected Cause
Unknown Rule out medical causes after thorough history and physical examination. Treat agitated patients or patients with distressing symptoms with antipsychotics as per Table 149­8. Consult psychiatry when medically appropriate.
Substances Use antidote/countering medication if available or necessary. Use environmental controls to reduce stimulation. May need to use medications as per Table 149­8, but cautiously due to interaction with intoxicant. Mental state often clears as substance is metabolized.
Medical Treat the underlying medical cause. Caution in using medications in Table 149­8 that have anticholinergic properties. Consult psychiatry to manage psychiatric comorbidities.
Psychiatric Primary psychosis (e.g., schizophrenia): use medications as per Table 149­8. Mania/psychotic depression: use antipsychotics as per Table
149­8 with combination of sedative medications as necessary. The goal in mania is to “settle the brain down” first; in psychotic depression, urgent psychiatric treatment is required.
When psychiatric causes are suspected, consult psychiatry.
BEHAVIORAL DISORDERS
Behavioral disorders is a broad term, generally focused on maladaptive behaviors that have progressed to a point of severe dysfunction, risk, or negative outcome. They are seen as a pathologic extension of normal behavioral issues. Oppositional defiant disorder is a persistent pattern of
 provocative, hostile, and noncompliant behavior characterized by low temper threshold. Conduct disorder is a more severe, antisocial pattern of
 rule­breaking behavior that includes aggression to people and animals, deceitfulness and theft, serious rule­breaking, and destruction of property.
Treatment is largely environmental and familial, and pharmacologic interventions are of mixed benefit. Behavioral disorders have extremely high psychiatric comorbidity, particularly with attention­deficit/hyperactivity disorder, and treatment of comorbid conditions is necessary. Stimulants, nonstimulant attention­deficit/hyperactivity disorder medications, clonidine, guanfacine, antiepileptic medications, and antipsychotic medications have mixed evidence, but trials are often necessary to reduce impulsivity and sometimes induce sedation, and many of these medications are used off­
 label.
SUBSTANCE MISUSE AND WITHDRAWAL
Alcohol use and misuse have decreased over the past  years in youth, with record­low numbers being seen in recent surveys, both in extreme (<13
 years) underage drinking and overall alcohol use. However, the 1­year prevalence of being drunk at least once is 20% in adolescence, and 6% of adolescents will drink more than  drinks in a row, making acute intoxication a common adolescent event. Marijuana use has remained stable, with
40% of adolescents reporting ever using marijuana. However, cocaine, hallucinogen, inhalant, ecstasy, and methamphetamine use has halved in the past  years.
The management of individual toxidromes is described in Section  (“Toxicology”) of this book. A very small percentage of adolescents with alcohol misuse experience any withdrawal symptoms, and an even smaller percentage require pharmacologic treatment. Paced alcohol discontinuation is a successful approach to managing alcohol withdrawal in teens, and treatment of severe symptoms can be carried out as in adults, using
 benzodiazepines such as diazepam and chlordiazepoxide. Refer any youth with a substance use problem to available substance misuse services; the remission rates are low, but a nonjudgmental, continuous, motivational approach reduces rates of misuse.


