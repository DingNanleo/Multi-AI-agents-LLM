## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 269: Wrist Injuries
Brit Long; Alex Koyfman
INTRODUCTION AND EPIDEMIOLOGY
The wrist is the area from the distal radius and ulna to the carpometacarpal joints. Wrist injuries are common, accounting for .5% of ED visits
1­3 annually, and up to 25% of all sports injuries include the hand or wrist. Clinical diagnosis is often difficult, and even subtle injuries may lead to significant impairment if not properly diagnosed and treated. Management options vary from conservative to surgical, so an understanding of the functional anatomy, mechanisms of injury, and clinical evaluation is needed for proper diagnosis and treatment.
ANATOMY
The wrist is a complex unit with articulations among the eight carpal bones and the distal radius and ulna that allows for flexion, extension, and
,5 radial/ulnar deviation. Not only does it consist of the carpal bones, radius, and ulna, but it also contains distal radioulnar joint, triangular fibrocartilage complex (TFCC), and thumb radial and ulnar collateral ligaments. The wrist has dual blood supply, although most carpal bones do not.
The radial nerve provides dorsal sensation and wrist/finger extension, the median nerve volar sensation to the first three digits and wrist/finger
,5 flexion, and the ulnar nerve sensation to the palm and last two digits and hypothenar and fourth/fifth digit lumbrical movement.
DISTAL RADIUS AND ULNA
The distal radius is the only forearm bone that articulates directly with the carpal bones (scaphoid and lunate). The distal radius has three articular surfaces: radiocarpal, distal radioulnar, and the triangular fibrocartilage complex. The radiocarpal surface is concave and tilted in two planes. It has an
,5 ulnar inclination, or tilt, of  to  degrees in the frontal plane, and a volar tilt of  to  degrees in the sagittal plane (Figure 269­1). The ulna is separated from the carpal bones by the triangular fibrocartilage complex, the main stabilizer of the distal radioulnar joint, on its distal end. The triangular fibrocartilage complex forms a smooth, continuous, ulnarly directed extension of the distal radial surface, and supports the lunate and triquetrum on the distal ulna. The distal radius has a concave sigmoid notch at its ulnar aspect that articulates with the curvature of the ulnar head,
 which permits wrist rotation during pronation/supination of the forearm. The distal radioulnar joint is also supported by dorsal and volar radioulnar
 ligaments that merge with the triangular fibrocartilage complex.
FIGURE 269­1. Wrist. Normal posteroanterior (PA) view. . The carpal bones are arranged in two rows forming three smooth arcs (Gilula lines). . The carpal bones are separated by a uniform 1­ to 2­mm space. . The scaphoid (S) is elongated. . The radius has an ulnar inclination of  to  degrees. . The radial styloid projects  to  mm. . Half the lunate articulates with the radius, with equal length over the ulna (neutral ulnar variance). C = capitate; H = hamate; L = lunate; P = pisiform; Tm = trapezium; Tq = triquetrum; Tz = trapezoid.

Chapter 269: Wrist Injuries, Brit Long; Alex Koyfman 
. Terms of Use * Privacy Policy * Notice * Accessibility
CARPAL BONES
Eight carpal bones are arranged in two rows. The distal carpal row (trapezium, trapezoid, capitate, and hamate) is joined tightly together and to the adjoining metacarpals. The distal row is quite stable and moves with the metacarpals as a unit in a relatively stable arch. The proximal carpal row
(scaphoid, lunate, triquetrum, and pisiform) is also arranged in an arch between the distal radius and the distal carpal row, functioning as a mobile link, or “intercalated segment,” and is potentially unstable by virtue of this position. The scaphoid is critical to wrist stability, acting as a stabilizing strut and linking the proximal and distal carpal rows at the radial aspect of the wrist. This position explains the scaphoid’s greater propensity for injury.
Forearm muscles that insert onto the bases of the metacarpals produce wrist motion. Except for the pisiform, a sesamoid bone of the flexor carpi
 ulnaris, there are no direct tendon insertions on the carpal bones. The carpal bones move passively in response to hand position. Often, the
 radiocarpal joint is referred to as the wrist joint. However, wrist motion is divided almost equally between the radiocarpal and midcarpal joints. This is best understood by viewing carpal movement from the sagittal view. During flexion and extension of the wrist, each row moves in the same direction with similar degrees of angulation.
The carpal bones are stabilized to one another by intrinsic ligaments and to the bones of the forearm by extrinsic ligaments. The key extrinsic ligaments are arranged in three arcades, two of which are volar and one dorsal. The two volar ligaments are arranged in two inverted V­shaped arches and are thought to play a major role in stabilizing the wrist. The apex of one arch inserts on the lunate supporting the proximal carpal row, whereas the other arch reaches to the distal carpal row, inserting on the capitate. The area between these two palmar arches is inherently weak and is known as the
,5 space of Poirier (Figure 269­2). This space lies at the junction of the capitate and lunate and widens upon dorsiflexion of the wrist. Forceful dorsiflexion may tear the capsule here and produce a lunate or perilunate dislocation. The single dorsal arcade has its origins on the rim and styloid of the radius on one side and distal ulna/triangular fibrocartilage complex on the other. This ligament is less important for wrist stability, acting as a sling
,9 across the dorsum of the wrist.
FIGURE 269­2. Ligaments of the wrist.
The space of Poirier on the volar aspect of the wrist is the site of disruption in perilunate and lunate dislocations. The intrinsic ligaments are largely responsible for holding the carpal bones together as a kinematic unit in their respective carpal rows, and these ligaments of the mobile proximal carpal row have high propensity for injury. The intrinsic ligaments of the proximal carpal row are named after the respective carpal bones they connect: the scapholunate and triquetrolunate. The palmar flexed posture of the scaphoid produces a flexion torque on the lunate that is counterbalanced by an extension torque from the triquetrum. This delicate balance is lost if either ligament is disrupted, producing a dorsal or volar tilt of the proximal carpal
 row and carpal instability.
PATHOPHYSIOLOGY
It is helpful to understand the mechanism of injury when assessing wrist injuries. Most injuries are caused by a fall creating an axial load on an outstretched arm and dorsiflexed wrist and hand. Impact on the thenar eminence is likely to injure the scaphoid and its supporting ligaments. An impact on the hypothenar eminence is likely to cause injury to the triquetrum, pisiform, and their supporting ligaments. Age affects the maturity of the
 bones and predisposes patients to certain types of injury. Children are likely to sustain injuries to the immature, weaker epiphyseal plate
 or metaphysis of the radius, sparing the still cartilaginous carpal bones. Young adults, particularly those with active lifestyles, are likely to
 be injured with greater force and disrupt either the scaphoid, proximal row intrinsic ligaments, or distal radial metaphysis. In the elderly, especially with underlying osteoporosis, the weak point is the brittle distal radial metaphysis, resulting in a Colles’ fracture, often
 with intra­articular involvement. The elderly possess the highest rate of injury to the carpal bones, primarily due to falls.
CLINICAL FEATURES
Begin assessment by looking at both wrists to assess for symmetry and range of motion in dorsiflexion, palmar flexion, and radioulnar deviation, in addition to obvious deformities and soft tissue swelling. Pinpoint areas of tenderness and correlate them to anatomic landmarks of the wrist to determine which structure may be injured and the best way to evaluate it radiographically (Figure 269­3).
FIGURE 269­3. Surface anatomy of the wrist. A. Dorsal aspect. B. Palmar aspect. APL = abductor pollicis longus; EPB = extensor pollicis brevis; EPL = extensor pollicis longus; FCR = flexor carpi radialis; FCU = flexor carpi ulnaris; LT = lunotriquetral joint; PL = palmaris longus; SL = scapholunate joint; STT = scaphotrapeziotrapezoid joint.
The most noteworthy landmark on the dorsum of the wrist is the anatomic snuffbox. The anatomic snuffbox is a triangle formed by the bony radial styloid at its proximal base, the extensor pollicis brevis tendon at its radial aspect, and the extensor pollicis longus tendon at
 its ulnar aspect. Palpate the scaphoid within this triangle, as well as the scaphoid tubercle. Tenderness in this area may suggest a
 scaphoid fracture. The extensor pollicis longus tendon wraps around a bony prominence of the distal radius, known as Lister’s tubercle. The area immediately distal to this point marks the location of the scapholunate joint. Tenderness in this area suggests scapholunate ligamentous injury or
 lunate fracture. The scaphoid shift test can further assess scapholunate ligament injury. To perform the scaphoid shift test, place the wrist in ulnar deviation and apply pressure with your thumb over the scaphoid tuberosity. Then move the wrist from ulnar to radial deviation; in the event of
,13 ligament injury, a palpable “clunk” will be felt.
Immediately ulnar to the scapholunate joint is a palpable indentation in the center of the wrist. This is the location of the lunate and capitate, which are
 palpable as they rise out of this space during wrist flexion. Wrist flexion allows lunate palpation distal to the radius in line with the third phalanx,
 ulnar to the scaphoid. Tenderness here may indicate lunate or triquetrolunate joint injury. The ulnar styloid is the bony prominence on the ulnar aspect of the wrist. The triquetrum and triangular fibrocartilage complex are located just distal to this prominence. The triquetrum can be palpated on
 the volar distal wrist (distal to the ulna and pisiform) in line with the fifth phalanx. Tenderness over the ulnar styloid may indicate ulnar styloid or triangular fibrocartilage complex injury. The ulnocarpal stress test can further evaluate the triangular fibrocartilage complex; apply a compression
 load to the wrist in ulnar deviation. Pain or clicking may indicate triangular fibrocartilage complex injury.
Pain with pronation and supination of the forearm may indicate distal radioulnar joint injury. The piano key sign, which is the ulnar head springing
 back when depressed while supporting the forearm in pronation, suggests distal radioulnar joint injury.
The crease on the volar aspect of the wrist marks the location of the proximal carpal row (Figure 269­3). The scaphotrapezial joint is palpable at the base of the thenar eminence. The pisiform is the palpable bony prominence at the base of the hypothenar eminence. The hook of the hamate is
 palpable in the soft tissue  to  cm distal and radial to the pisiform in the hypothenar eminence. Tenderness in these areas may require further
 evaluation than standard radiographic views.
IMAGING
Clinical examination determines which radiographic views will best support a diagnosis. Standard views of the wrist include posteroanterior, lateral,
,16 and oblique views. These views are adequate in most cases, but other projections may be necessary for specific injuries.
The key to interpreting the radiograph is to first ensure proper hand positioning, then identify specific features on each projection. On a properly positioned posteroanterior view, the distal radius and ulna should not overlap at their distal articulation, and the axis of the third metacarpal should parallel that of the radius. In addition to looking for disruption of the bony cortex, key elements on the posteroanterior view are illustrated in Figure
269­1. On the posteroanterior view, three smooth arcs (Gilula lines) outline the articular surfaces at the radiocarpal and midcarpal joints. Two of these arcs are formed by the proximal and distal surfaces of the scaphoid, lunate, and triquetrum. The first arc includes the proximal scaphoid, whereas the second arc includes the distal scaphoid. The third arc is formed by the proximal articular surface of the capitate and hamate in the midcarpal joint. Any
,15,16 distortion of these lines implies a fracture, dislocation, or subluxation at the site.
The carpal bones fit together much like a jigsaw puzzle, with the pieces separated by a uniform 1­ to 2­mm space. This space is increased or obliterated with ligament disruption, carpal instability patterns, or fracture/dislocations. This occurs most often around the lunate at the scapholunate and capitolunate joints.
The scaphoid has an elongated shape in its normal, palmarly flexed position. Fractures or ligament disruption may cause further palmar rotation, causing the scaphoid to appear shortened on the posteroanterior view. Injuries to the scaphoid also may obscure the scaphoid fat stripe, a linear or triangular radiolucent collection of fat distal to the radial styloid and parallel to the radial border of the scaphoid.
Unfortunately, incorrect positioning can produce overlap patterns that can be misinterpreted as pathologic. For example, radial deviation of the wrist causes normal physiologic rotation of the proximal carpal row, obliterating the capitolunate space. At the same time, the scaphoid that should appear elongated on the posteroanterior view appears shorter as it rotates palmarly and can be confused with a rotary subluxation of the scaphoid.
The radial styloid should project  to  mm beyond the distal radioulnar joint and create an ulnar inclination of  to  degrees on the posteroanterior view. Distal radius fractures can alter these measurements. At the distal radioulnar joint, the ulna and adjacent portion of the radius should be of equal length, forming a smooth articular surface, and the distal radius generally should articulate with at least half the lunate. The extrinsic ligaments along with the triangular fibrocartilage complex prevent ulnar translocation (migration of the carpal bones down the ulnar tilt of
 the radiocarpal surface). The lunate would have less contact and support from the radius if ulnar translocation were present. A shorter ulna

(negative ulnar variance) provides less support to the lunate and increases potential shear stress to the lunate, predisposing the lunate to injury.

A properly positioned lateral radiograph is important for determining carpal alignment and degree of fracture angulation. The radius and ulna should completely overlap one another, and the radial styloid should be centered over the distal radial articular surface. The key elements are illustrated in Figure 269­4A.
FIGURE 269­4. A. Normal wrist. Axis of the radius (R), lunate (L), and capitate (C) are collinear (three C’s sign). The capitolunate (CL) angle is <10 to  degrees. The scapholunate (SL) angle is between  and  degrees. The radial volar tilt is  to  degrees. B. Dorsal intercalated segment instability. The lunate tilts dorsal and slides palmar, increasing the capitolunate angle. The scaphoid (S) tilts more palmar and increases the scapholunate angle. The axes of the radius, lunate, and capitate take on a zigzag pattern (yellow line). C. Volar intercalated segment instability. The lunate tilts palmar and the capitolunate angle increases, but the scapholunate angle is maintained. The zigzag pattern is in the opposite direction.
The axis of the radius, lunate, and capitate is collinear on the lateral view. If the articular surfaces of these bones were highlighted, they would appear as three consecutive C’s. This provides a simple radiographic assessment of wrist dislocation. Measurement of the capitolunate and scapholunate angles is a more precise assessment of carpal alignment. The axis of the capitate, lunate, and scaphoid runs through the center of their proximal and distal articular surfaces. The axis of the lunate and capitate should nearly overlap and form an angle that is <10 to  degrees. The scaphoid is normally palmar­flexed on the lateral view; its axis should form an angle between  and  degrees with the lunate.

Deviation from either of these angles suggests ligament disruption and carpal instability patterns (Figure 269­4B and C).

Fracture of the distal radius is the most common fracture in the wrist. Although a displaced fracture is the obvious deformity, the alteration of the normal volar tilt of  to  degrees of the distal radial articular surface has greater long­term consequences for wrist function,
 resulting in carpal misalignment and, subsequently, the instability patterns mentioned above.
Other radiographic views profile specific areas of the wrist. Oblique views are performed in either partial pronation or supination and project the scaphotrapezial joint or pisiform away from overlapping adjacent carpal bones. The scaphoid view is a cone­down posteroanterior view of the scaphoid in ulnar deviation. This position extends the normal flexed posture of the scaphoid so that the bone is projected lengthwise. This view may
 assist in detecting subtle fractures and is used whenever scaphoid injury is suspected. The carpal tunnel view is a tangential view through the carpal tunnel and is helpful in visualizing the pisiform and hook of the hamate. Motion studies are dynamic views in flexion, extension, and radial and ulnar deviation. These views examine carpal movement relative to one another and stress the intercarpal ligaments for laxity, characterized by widening of
 the intercarpal space. Likewise, the grip compression or fist view is a stress view in the posteroanterior projection of the tightly clenched fist. The capitate is pushed into the proximal carpal row and forces the carpal bones apart if intrinsic ligaments are disrupted. CT is useful for defining fractures and dislocations, whereas MRI is useful for evaluation for both bony and soft tissue abnormalities such as occult fractures, avascular necrosis, and
 triangular fibrocartilage complex abnormality. Table 269­1 presents a summary of standard and supplemental wrist radiographs and the injuries they enhance.
TABLE 269­1
Wrist Radiography
View Injuries to Identify
Posteroanterior Distal radius/ulna fractures, carpal bone fractures, ligamentous disruptions
Lateral Radius/ulna fractures, lunate/perilunate dislocation, dorsal intercalated segment instability, volar intercalated segment instability
Scaphoid Scaphoid fracture, scapholunate dissociation
Carpal tunnel Pisiform and hamate fractures
Motion studies Scapholunate or triquetrolunate instability
Grip compression Scapholunate or triquetrolunate instability
CT All fractures and dislocations
MRI Occult fracture, avascular necrosis, soft tissue abnormality
LIGAMENTOUS INJURIES
The lunate is located in the middle of the wrist, so it is not surprising that the majority of ligamentous injuries are centered on the lunate. Injuries usually result from forceful dorsiflexion of the wrist, most often from a fall on an outstretched hand. The various injuries occur sequentially depending
,22 on the degree of force and range from isolated tears to perilunate and lunate dislocations. Although infrequent, they account for 7% of carpal
 ,24 injuries. Four distinct stages are present: scapholunate, perilunate, perilunate and triquetrum, and lunate dislocation.
SCAPHOLUNATE LIGAMENT INSTABILITY
The scapholunate ligament is the intrinsic ligament that binds the scaphoid and lunate. Because the scaphoid bridges the proximal and distal carpal rows, the scapholunate ligament has a marked propensity for injury and is the most commonly injured ligament of the wrist. Injury
 most often is from a fall on an outstretched hand with impact on the thenar eminence. Patients complain of pain and swelling on the radial side of the wrist and often a “clicking” sensation with wrist movement. Examination reveals localized tenderness on the dorsum of the wrist in the area
 immediately distal to Lister’s tubercle. Ballottement of the scaphoid may also produce pain in this area.
This injury is often referred to by the various radiographic appearances it may take. There are three different radiographic signs that may occur separately or in combination with one another (Figure 269­5A). Scapholunate dissociation is a widening of the scapholunate joint space of >3 mm on the posteroanterior view or >8 mm on the ulnar/deviation/clenched fist view. If it is not apparent on routine views, a grip
,22 compression view or motion study may be necessary to demonstrate the abnormal gap (Figure 269­5B). These maneuvers are particularly helpful in identifying an incomplete tear of the ligament. Rotary subluxation of the scaphoid is another radiographic finding that often accompanies scapholunate dissociation. A torn scapholunate ligament can cause the scaphoid to tilt more palmar and increase the scapholunate angle to >60 degrees on the lateral view. On the posteroanterior view, the scaphoid tilts toward the observer so that it appears shorter as it is viewed more on its end. This causes the circular cortex of the bone to become more prominent and appear as a ring, known as the “cortical ring sign” (Figure 269­5A). A third radiographic abnormality is a carpal instability pattern known as dorsal intercalated segment instability (Figure 269­4B). The normal flexed posture of the scaphoid produces a flexion torque on the lunate that is counterbalanced by an extension torque from the triquetrum. When the scapholunate ligament is torn, this balance is disrupted. The lunate tilts dorsal from the unopposed extension torque from the triquetrum, whereas the scaphoid tilts more palmar (rotary subluxation of the scaphoid) because it has lost support from the lunate. The dorsal tilt of the lunate also causes a slight flexion tilt of the capitate. In the lateral view, the normal collinear arrangement of the axes of the capitate, lunate, and radius is replaced by a characteristic zigzag pattern. Both the scapholunate and capitolunate angles are increased. The concept of the proximal carpal row being the middle link or “intercalated segment” in this system, combined with the lunate’s pathologic dorsal tilt and zigzag pattern (Figure 269­5C), is how this abnormality came to be named dorsal intercalated segment instability.
FIGURE 269­5. A. Scapholunate dissociation and rotary subluxation of the scaphoid. The scaphoid and lunate are separated by a gap of >3 mm (black arrow), and the scaphoid appears shorter from rotation with a dense ring, the “cortical ring sign” (white arrow). B. Grip compression view showing enhancement of scapholunate dissociation (arrow). C. Dorsal intercalated segment instability. Lateral view exhibiting dorsal intercalated instability with scapholunate dissociation. (See Figure 269­4.)
Refer to an orthopedist or hand surgeon. ED treatment is with a radial gutter splint or short arm volar posterior mold. Orthopedic referral is
 necessary because these injuries require either closed reduction with percutaneous pinning or open reduction and internal repair of the ligament.

Dorsal intercalated segment instability and subsequent early, severe degenerative arthritis can occur if left untreated. Failure to identify this injury
,26 may result in scapholunate advanced collapse and altered wrist biomechanics.
TRIQUETROLUNATE LIGAMENT INSTABILITY
The triquetrolunate ligament binds the triquetrum and lunate on the ulnar aspect of the wrist. Injury to this ligament is the ulnar equivalent of the scapholunate ligament injury. Triquetrolunate ligament injury occurs much less often than scapholunate ligament injury, is more stable, and can be
,19 confused with other causes of ulnar­sided wrist pain such as triangular fibrocartilage complex injury or distal radioulnar joint abnormality. This injury most often results from falls on the outstretched, dorsiflexed hand with impact on the hypothenar eminence. There will be localized tenderness
 on the ulnar aspect of the wrist just distal to the ulna. Ballottement of the triquetrum may produce a painful clicking sensation.

Subtle injuries may have a normal radiographic appearance. Complete disruption of the triquetrolunate ligament removes the ability of the triquetrum to counterbalance the flexion torque from the palmar­flexed scaphoid. The lunate then tilts palmar, and the capitate extends slightly in response. A zigzag pattern in the opposite direction of the scapholunate injury is produced. The capitolunate angle is increased >10 to  degrees; however, the scapholunate angle is unaffected because the scapholunate ligament is still intact. The lateral radiograph may reveal the “volar intercalated segment instability” pattern (Figure 269­4C and Figure 269­6). The posteroanterior view may reveal a widening of the triquetrolunate joint space and obliteration of the capitolunate joint space and the normal smooth arcs typically seen because of the volar tilt of the lunate.
FIGURE 269­6. A. Volar intercalated instability. Note widened capitolunate angle. B. Dorsal intercalated instability.
Refer to an orthopedist or hand surgeon. ED treatment is an ulnar gutter splint or short arm posterior mold and referral to an orthopedist.
Immobilization in a cast for  to  weeks, followed by a protective splint, is sufficient in most cases. Open reduction and internal fixation are generally
 reserved for chronic injuries. Unrecognized injuries can cause early degenerative arthritis, weakened grip, ulnar neuropathy, and chronic wrist
,28 pain.
PERILUNATE AND LUNATE DISLOCATIONS
Perilunate and lunate dislocations represent the final stages of midcarpal ligament disruption and are thought to account for 10% of all carpal
 injuries. These injuries are the result of forceful dorsiflexion and impact on the outstretched hand, but usually with great force, such as a fall from
 height, impact from a motor vehicle collision, or a sporting event. These injuries are often associated with other injuries, including scaphoid
,31  fractures (61% to 65%) and other upper extremity injuries (11%). Polytrauma involving other systems is present in 26% of these patients.
Perilunate dislocation is the posterior dislocation of carpal bones while the lunate maintains its position with respect to the distal radius. This is a very rare dislocation. Lunate dislocation produces posterior dislocation of carpal bones with the concavity of the lunate facing anteriorly.
The injury can begin on either side of the lunate, but typically begins on the radial aspect, with either a tear of the scapholunate ligament or a fracture of the scaphoid. Injury progresses around the lunate in a semicircular fashion, tearing the volar ligament arcade at the radiocapitate ligament.
Remember that the extrinsic ligaments form two strong volar arcades with an inherently weak area between them that widens with dorsiflexion of the wrist (Figure 269­2). The space of Poirier lies at the junction of the lunate and capitate. This space opens further as heavy loading disrupts the lunotriquetral ligament. Besides ligament disruption, any number of carpal bones may fracture along an arc around the lunate (Figure 269­7). If sufficient force is applied, the ligaments and carpal bones around the lunate are stripped away. The capitate is displaced dorsal to the lunate, producing a perilunate dislocation. If the capitate rebounds with sufficient force, it can push the lunate off the radius and into the palm, creating a
 lunate dislocation. These injuries are all part of a continuous spectrum of ligament disruption (Figure 269­7).
FIGURE 269­7. Four stages of perilunate instability. The first stage (I) is disruption of the scapholunate articulation (scapholunate dissociation). The second (II) and third (III) stages are separation of the capitolunate and triquetrolunate joints (perilunate dislocation). The fourth (IV) stage is a lunate dislocation.
On clinical examination, there is generalized swelling, pain, and tenderness of the wrist. However, a gross deformity, typical of many joint dislocations, is often absent. Radiographic interpretation is the key to diagnosis. The perilunate dislocation is best appreciated on the lateral view. The linear arrangement of the three C’s sign is disrupted with the capitate, represented by the third C, displaced dorsal to the lunate.
The lunate retains its contact with the radius. The scapholunate and capitolunate angles are increased. On the posteroanterior view, the three smooth arcs are disrupted, and the capitolunate joint space is obliterated as the bones overlap one another. The scapholunate and triquetrolunate joint space may either be increased because of torn ligaments or obliterated by rotation of the fractured carpal fragments. The scaphoid will appear shortened from rotary subluxation or fracture (Figure 269­8). A perilunate dislocation may also overshadow any associated carpal bone fracture. The scaphoid and capitate are most often involved, so carefully inspect these bones for fractures. Such fractures are designated by adding the prefix
“trans­” to the carpal bone name (e.g., transscaphoid perilunate dislocation) (Figure 269­9).
FIGURE 269­8. Perilunate dislocation. A. Posteroanterior view shows obliteration of the three smooth arcs as bones overlap one another (white hash marks). B.
Lateral view shows capitate dorsal to lunate, disrupting the “three C’s” (arrow).
FIGURE 269­9. A and B. Transscaphoid perilunate dislocation. [Photos contributed by Brooke Beckett, MD, Department of Radiology, Oregon Health & Science
University, Portland, OR.]
A lunate dislocation has many similar and several distinct radiographic features when compared with a perilunate dislocation. On the posteroanterior view, the lunate has a triangular shape (“piece­of­pie” sign) that is suggestive of lunate dislocation (Figure 269­10A). On the lateral view, it also disrupts the three C’s sign. The lunate (represented by the middle C) is pushed off the radius into the palm. This has been called the
“spilled teacup” sign because it resembles a cup spilling in the direction of the palm (Figure 269­10B). The capitate may rebound back and even rest on the radius. The signs of ligament disruption and the associated carpal bone fractures described with perilunate injuries may also be present.
FIGURE 269­10. Lunate dislocation. A. Posteroanterior view demonstrates pathognomonic triangular shape of the lunate (piece­of­pie sign; circle). B. Lateral view exhibits the lunate tilting into the palm (spilled teacup sign; circle) and the capitate positioned dorsal to the lunate (arrow).

Perilunate or lunate dislocations require emergency orthopedic/hand consultation. Treatment is determined by the extent of the injury.
Closed reduction and long arm splint immobilization are appropriate for reducible dislocations, although closed reductions are often
,31 unsuccessful. Open, unstable, and irreducible dislocations require open reduction and internal fixation, with repair of the ligaments and fractures.

Some orthopedists operate on all perilunate and lunate dislocations. The complications include development of carpal instability patterns that lead to early degenerative arthritis, delayed union, malunion, nonunion, avascular necrosis, and occasionally, median nerve
 compression from the volar dislocation of the lunate into the carpal tunnel.
CARPAL BONE FRACTURES
Carpal bone fractures are the most commonly missed wrist injuries. A careful examination is critical to recognize carpal bone fractures. The carpal fractures are listed in Table 269­2 in descending order of occurrence.
TABLE 269­2
Summary of Carpal Bone Fractures and ED Management
Carpal
Mechanism of Injury Examination Initial ED Management
Bone
Scaphoid Fall on outstretched hand or axial load on Snuffbox tenderness; pain with radial deviation If diagnosed, long arm thumb thumb metacarpal and flexion; scaphoid tubercle tenderness; pain spica splint in dorsiflexion with with resisted supination/pronation; pain with radial deviation active thumb movement If continued pain but no definitive radiograph findings, short arm thumb spica splint, in dorsiflexion with radial deviation
Triquetrum Avulsion fracture—twisting of hand against Tenderness at the dorsum of the wrist, distal to Short arm sugar­tong splint resistance or hyperextension and ulnar the ulnar styloid; axial compression along the deviation third metacarpal may cause pain
Body fracture—direct trauma
Lunate Fall on outstretched hand or trauma to the wrist Tenderness at shallow indentation of the mid­ Short arm thumb spica splint in hyperextension and ulnar deviation dorsum of the wrist, ulnar and distal to Lister’s tubercle
Trapezium Direct blow to thumb; force to wrist while Painful thumb movement and weak pinch Short arm thumb spica splint dorsiflexed and radially deviated strength
Snuffbox tenderness
Pisiform Fall or trauma directed on the hypothenar Tender pisiform, prominent at the base of the Short arm volar splint in  eminence hypothenar eminence; decreased grip strength; degrees of flexion and ulnar ulnar/median nerve paresthesias may occur deviation
Hamate Interrupted swing of a golf club, bat, or racquet; Tenderness at the hook of the hamate, just Short arm volar wrist splint with repeated microtrauma or acute fall distal and radial to the pisiform; positive hook of fourth and fifth metacarpal joints hamate test in flexion
Capitate Forceful dorsiflexion of the hand with radial Tenderness and swelling over the capitate just Short arm volar wrist splint impact; direct blow to the dorsum of the wrist; proximal to the third metacarpal force applied to the second to fourth metacarpals; flexion force to the wrist
Trapezoid Axial load onto the index metacarpal; second Tenderness over the radial aspect of the base of Short arm thumb spica splint metacarpal palmar hyperflexion the index metacarpal
SCAPHOID FRACTURE
,33
The scaphoid is the most common carpal bone fractured, with nonscaphoid fractures accounting for the other 13% to 38% of carpal bone fractures.
Scaphoid injuries result from a fall on either an outstretched dorsiflexed hand or from an axial load directed along the thumb’s metacarpal. There is
,35 pain along the radial aspect of the wrist and localized tenderness in the anatomic snuffbox. Examination of the wrist in ulnar deviation exposes more of the scaphoid to direct palpation within the anatomic snuffbox. Snuffbox tenderness demonstrates a sensitivity and specificity for scaphoid fracture of 90% and 40%, respectively, whereas tubercle tenderness demonstrates a sensitivity and specificity of 87% and 57%, respectively. Eliciting pain in this area when the patient resists supination or pronation of the hand (sensitivity 79% and specificity 58%) or pain with axial pressure directed along the thumb’s metacarpal also suggests injury. Pain at the snuffbox with thumb–index finger pinch possesses a sensitivity of 73% and specificity of
,35
75%. One study examined the combination of several findings for diagnosis of scaphoid fracture including anatomic snuffbox tenderness, scaphoid tubercle tenderness, tenderness with longitudinal compression of thumb on scaphoid, and pain with active thumb movement. The first three
 maneuvers demonstrated an individual sensitivity of 100%, whereas the fourth had a sensitivity of 69%. Specificities included 9%, 30%, 48%, and

66%, respectively, and if the first three maneuvers were combined, specificity increased to 75%.
Radiographic evaluation includes both standard and scaphoid views for cortical disruption (Figure 269­11). The scaphoid view profiles the bone lengthwise and may assist in detecting subtle fractures. Distortion of a soft tissue fat stripe adjacent to the radial aspect of the scaphoid is suggestive of
 injury. Two thirds of the fractures occur at the waist or middle third of the bone, 16% to 28% in the proximal third, and 10% in the distal third. CT
,37 possesses a sensitivity of 89% to 100% and specificity of 85% to 100%. MRI demonstrates a sensitivity of 98% to 100% and specificity up to 100%. A
 scaphoid fracture may also have an associated injury in 12% of cases. Associated injuries may include the radius, neighboring carpal bones, a carpal instability pattern, or a dislocation. In patients with initial negative plain films, yet in whom a high index of suspicion remains for fracture, MRI is
 considered the gold standard for definitive diagnosis.
FIGURE 269­11. Scaphoid fracture in the middle third or waist (arrow).

A scaphoid fracture can develop avascular necrosis of the proximal fracture segment that can lead to disabling arthritis. Because the vascular supply to the scaphoid enters the distal portion of the bone through small branches off the radial artery and palmar and superficial arteries, a fracture can easily disrupt the blood supply to the proximal segment. The more proximal, oblique, or displaced a fracture, the greater is the
,39,40 risk of developing avascular necrosis (up to 80% of proximal fractures result in necrosis). A scaphoid fracture is considered unstable if it is oblique, if there is as little as  mm of displacement, if there is rotation or comminution, or if a carpal instability pattern is present. Two thirds of the scaphoid’s surface is articular. This only adds to the scaphoid’s problems because articular fractures are more difficult to heal. Thus, the main complications of improperly healed scaphoid fractures are avascular necrosis, delayed union, nonunion, malunion, and subsequent early degenerative arthritis.
,36
Up to 16% of initial radiographs fail to detect a fracture, so initial treatment should be directed by clinical suspicion.
Immobilize scaphoid fractures in a long arm thumb spica splint with hand surgery consultation. If fracture is suspected despite
,39,40 negative radiograph, apply a short arm thumb spica splint, with repeat imaging in  to  days. Several studies have evaluated immediate CT or MRI for definitive diagnosis versus prolonged immobilization on costs (including patient lost income and productivity), suggesting
40­42 earlier advanced imaging is more cost effective.
TRIQUETRUM FRACTURE
Triquetrum fractures are the second most common carpal bone injury, accounting for up to 20% of carpal fractures, and occur as a fracture through
,43 the dorsal cortex, palmar cortex, or body. Avulsion fractures are produced when a twisting motion of the hand is suddenly resisted or a hyperextension shear stress pushes the hamate or ulnar styloid against the triquetrum. This may occur with a fall on an outstretched hand with
,33 hyperextension and ulnar deviation. Fractures of the body occur from direct trauma and are found in association with perilunate and lunate dislocations (part of the arc fractures). Localized tenderness is found over the dorsum of the wrist in the area immediately distal to the ulnar styloid.
The dorsal avulsion fracture is best seen on the lateral radiograph or an oblique view in partial pronation. The fracture appears as a tiny flake of bone on the dorsum of the triquetrum best seen on lateral view (Figure 269­12). Triquetrum body fractures are usually nondisplaced because numerous ligaments encase the bone; these are best seen on the posteroanterior view. Nonunion is possible, but avascular necrosis has not been reported.
FIGURE 269­12. A and B. Triquetrum fracture seen at tip of arrow. [Photos contributed by Brooke Beckett, MD, Department of Radiology, Oregon Health & Science
University, Portland, OR.]
Refer triquetrum fractures to an orthopedist or hand surgeon. Patients with a dorsal avulsion fracture have an excellent prognosis for full recovery.
Symptomatic patients are treated with a wrist splint for  to  weeks. Asymptomatic or minimally symptomatic patients may be treated with early range of motion. Stable body fractures are treated in a cast for  weeks. Unstable body fractures (>1 mm displacement) and those associated with
,44  perilunate/lunate dislocations may require internal fixation. Palmar cortical fractures are treated surgically.
LUNATE FRACTURE
Lunate fractures tend to occur with other carpal injuries. Isolated lunate injuries are rare, as 70% of the lunate rests on the radius and 30% articulates
,33 with the TFCC. The mechanism of injury is commonly the result of a fall on the outstretched hand or trauma to the wrist in hyperextension and ulnar
 deviation. The lunate is present in the shallow indentation on the mid­dorsum of the wrist. The lunate is easily palpable as it rises out of the floor of this indentation when the wrist is in a flexed position. Examination reveals tenderness at this point. Axial compression applied along the third metacarpal ray may also elicit pain in this area and is suggestive of injury. The lunate’s blood supply enters through the distal end of the bone. A fracture subjects the lunate to risk for avascular necrosis of the proximal portion.4,24
The lunate is seated in the middle of the wrist, so overlap with other carpal bones may make it difficult to identify an injury on a plain radiograph. On the lateral radiograph, the lunate, capitate, and distal radius should lie in the same vertical plane.
Refer suspected or actual lunate fractures to an orthopedist or hand surgeon. Clinical suspicion dictates the acute treatment. A short arm thumb spica splint should be applied when the diagnosis is unclear. MRI and CT may be used to identify occult fractures. The major complication is avascular
 necrosis (Kienböck’s disease), leading to lunate collapse, osteoarthritis, chronic pain, and decreased grip strength.
TRAPEZIUM FRACTURE
The trapezium is a saddle­shaped bone that articulates with the thumb metacarpal. Injuries are produced by a direct blow to the thumb or from a dorsiflexion and radial deviation force. Fractures occur either at the trapezial ridge or body and are often intra­articular. Vertical fractures occur and are analogous to a Bennett’s fracture (an intra­articular proximal thumb metacarpal fracture) (Figure 269­13). Examination reveals painful thumb movement and a weak pinch. There is tenderness at the apex of the anatomic snuffbox and at the base of the thenar eminence. This injury is best profiled on a 20­degree pronated oblique view. The major complication is nonunion.
FIGURE 269­13. Trapezium fracture seen at tip of arrow. [Photo contributed by Brooke Beckett, MD, Department of Radiology, Oregon Health & Science University,
Portland, OR.]
Refer to an orthopedist or hand surgeon. Initial ED stabilization of nondisplaced fractures is a short arm thumb spica splint. Displaced fractures >1
 mm or diastases >2 mm require surgery. Missed diagnosis or inadequate management can result in permanent pinch and grip strength
 impairment.
PISIFORM FRACTURE
The pisiform is a sesamoid bone within the flexor carpi ulnaris tendon. It is positioned immediately volar to the triquetrum and is the palpable bony prominence at the base of the hypothenar eminence. Injuries usually result from a fall or trauma directed on the hypothenar eminence. There will be
,47 localized tenderness on the pisiform itself, as well as decreased grip strength and ulnar/median nerve paresthesias. If the wrist is flexed, the pisiform can be grasped and palpated between the examiner’s fingers. This should elicit pain. The pisiform and hook of the hamate form the bony
 walls of Guyon’s canal that contains the ulnar nerve and artery; therefore, it is important to exclude injury to them. Radiographs in partial supination, or the carpal tunnel view, are optimal because they remove the overlap with the triquetrum that is present on standard views (Figure 269­

14). The pisiform is the last carpal bone to ossify, and it is usually complete by age  years old. Before the age of , multiple ossification centers in the pisiform may be confused with a fracture. The ossification centers differ in that they will have smoother margins and lack the perfect jigsaw­puzzle fit seen with fracture fragments. After age , any radiographic line is suggestive of fracture.
FIGURE 269­14. Pisiform fracture. [Photo contributed by Brooke Beckett, MD, Department of Radiology, Oregon Health & Science University, Portland, OR.]
Refer to an orthopedist or hand surgeon. ED treatment is either a compression dressing or a splint in  degrees of flexion with ulnar deviation that relaxes the tension from the flexor carpi ulnaris. Pisiform fractures have an excellent prognosis. Complications include diminished grip strength and
 ulnar nerve palsy.
HAMATE FRACTURE
Hamate fractures may involve the body of the hamate, the hook of the hamate, or any of its articular surfaces. Body fractures are rare and are generally associated with fracture dislocations of the fourth or fifth metacarpals (Figure 269­15). Most hamate fractures involve the hamate hook, which is a small bony prominence on its volar aspect. The classic mechanism is an interrupted swing with a golf club, bat, or racquet. The handle impacts against the hypothenar eminence and compresses the bone. Others include repeated microtrauma or fall. Localized tenderness over the hook of the hamate is found by palpating the soft tissue of the hypothenar eminence, distal and radial to the pisiform. Other findings suggesting fracture include the hook of hamate pull test, in which the hand is held in ulnar deviation as the patient flexes the distal interphalangeal joints of the fourth and fifth digits, which
,47 causes pain. Standard and carpal tunnel views are necessary to visualize the fracture, although sensitivity is 71%. Occult fractures
,33 may be identified by bone scan or CT (sensitivity approaches 100%). Physical examination should assess for injury to Guyon’s canal (Figure
269­16), which houses the ulnar nerve and artery.
FIGURE 269­15. Hamate fracture (arrow) is best seen on posteroanterior (PA) view. [Photo contributed by Brooke Beckett, MD, Department of Radiology, Oregon Health
& Science University, Portland, OR.]
FIGURE 269­16. Guyon’s canal.
Refer to an orthopedist or hand surgeon. In the ED, treat hamate hook fractures with a compression dressing or ulnar gutter splint. Nonunion is common, and excision of the bone may be necessary. Nondisplaced body fractures are treated by splint immobilization. Displaced body fractures or those with injury to Guyon’s canal are surgically treated. Complications include ulnar and/or median nerve neuropathy, as well as decreased grip strength.
CAPITATE FRACTURE
The capitate is the largest carpal bone. It is an elongated bone with a large proximal head that articulates with the lunate. The midportion of the bone is the neck, and the distal end, or body, articulates with the third metacarpal. Capitate fractures most often occur in the neck and usually occur in conjunction with a scaphoid fracture (Figure 269­17). The association of scaphoid and capitate fractures is called the scaphocapitate syndrome.

Isolated capitate fractures are rare. Capitate fractures result from forceful dorsiflexion of the hand with impact on the radial side, direct blow to the dorsum of the wrist, force applied to the second to fourth metacarpals, or flexion force to the wrist. The scaphoid fractures first, and then the neck of the capitate fractures. The fracture can continue around the lunate, creating other so­called arc fractures, eventually resulting in perilunate or lunate dislocation. The capitate’s blood supply enters through the distal end. Thus, capitate fractures also share the same potential avascular necrosis of the proximal fracture segment as the lunate and scaphoid.
FIGURE 269­17. A and B. Capitate fracture (arrow) is seen best on posteroanterior (PA) view. [Photos contributed by Brooke Beckett, MD, Department of Radiology,
Oregon Health & Science University, Portland, OR.]
Physical examination reveals diffuse swelling and tenderness over the capitate, just proximal to the third metacarpal. Radiographs include posteroanterior radial and ulnar deviation views. Capitate neck fractures are best seen on the lateral radiograph. If radiograph is negative, then CT or
MRI may be needed. The head of the capitate should be carefully identified because it can rotate as much as 180 degrees. A capitate fracture is often overlooked because of the accompanying scaphoid fracture or perilunate/lunate dislocation that overshadows it. Complications include avascular necrosis, delayed union, nonunion, and malunion.
ED treatment of undisplaced, isolated capitate fractures is splint immobilization (short arm thumb spica) and early orthopedic/hand surgeon
  referral. Most capitate fractures, however, are displaced or associated with the scaphocapitate syndrome and require surgical treatment.
TRAPEZOID FRACTURE
,33
Trapezoid fracture is extremely rare. The injury results from an axial load onto the index metacarpal or second metacarpal palmar hyperflexion.
There will be tenderness on the radial aspect that is augmented by applying pressure along the index metacarpal ray. Fractures are difficult to visualize
 on standard radiographs, and CT or MRI may be necessary. ED treatment is with a thumb spica splint.
DISTAL RADIUS AND ULNA FRACTURES
Fractures of the distal metaphysis of the radius and ulna are among the most common injuries affecting the wrist, with an annual incidence of 640,000
 in the United States. Women older than age  years possess a 15% lifetime risk of a distal ulna and/or radius fracture, and distal radius fracture is
 the most common pediatric fracture (<16 years). Among the factors that influence the type and amount of displacement of the fracture are the point and direction of impact, the degree of force, and the patient’s age (Table 269­3). Importantly, close to 50% of distal radius fractures involve the intra­
 articular surface.
TABLE 269­3
Radiographic Appearance of Distal Radius Fractures
Colles’ fracture
Dorsal angulation of the plane of the distal radius
Distal radius fragment is displaced proximally and dorsally
Radial displacement of the carpus
Ulnar styloid may be fractured
Smith’s fracture
Volar angulation of the plane of the distal radius
Distal radius fragment is displaced proximally and volarly
Radial displacement of the carpus
The fracture line extends obliquely from the dorsal surface to the volar surface 1–2 cm proximal to the articular surface
Barton’s fracture
Volar and proximal displacement of a large fragment of radial articular surface
Volar displacement of the carpus
Radial styloid may be fractured
In general, the thinner cortices of the elderly make them more likely to sustain extra­articular fractures, whereas younger adults often sustain more complicated intra­articular fractures.
COLLES’ FRACTURE
Colles’ fracture results most often from a fall on the outstretched, extended hand. This mechanism produces a distal radial metaphysis fracture that is dorsally angulated and displaced proximally and dorsally (Figure 269­18). Compression forces on the dorsal side often produce dorsal comminution of bone. The fracture line may also comminute and extend into the radioulnar or radiocarpal joint (“die­punch” fracture). A fracture of the ulnar styloid is often present and may be suggestive of injury to the triangular fibrocartilage complex.
FIGURE 269­18. Colles’ fracture. A. Anteroposterior view. B. Lateral view. [Photos contributed by Brooke Beckett, MD, Department of Radiology, Oregon Health &
Science University, Portland, OR.]
The wrist has the characteristic dorsiflexion, or “dinner fork,” deformity. Patients may complain of palmar paresthesias from pressure on the median nerve. Posteroanterior radiographs reveal a distal metaphyseal fracture of the radius that often appears shortened from the angulation or comminution. The lateral view provides the best view of the dorsal angulation and comminution. In general, unstable fractures have
>20 degrees of angulation, intra­articular involvement, marked comminution, or more than a centimeter of shortening. These injuries are more likely to develop loss of reduction, distal radioulnar joint instability, radiocarpal instability patterns, and subsequent arthritis. If the fracture has significant intra­articular extension, or comminution or if distal radioulnar joint instability is suspected, CT may provide important additional
,53 information for diagnosis and treatment.
Stable fractures may be treated with a compression dressing and splint until they can be evaluated by an orthopedic surgeon within  to  days; otherwise, closed reduction is performed. After adequate local anesthesia (see Chapter , “Local and Regional Anesthesia”), provide traction with finger traps while the fracture fragment is pushed distal and palmar and the patient’s forearm is held firmly (Figure 269­19). Finger traps relax the deforming forces from spasm, may perform the reduction alone, and hold the reduction in place during splinting. The goal is to restore the volar tilt, radial inclination, and proper length to the radius. This is particularly important in younger patients. The volar tilt ideally should be restored to its normal position, but a minimum of neutral or zero degrees of angulation is acceptable. Periosteal entrapment entails folding of the periosteum into the fracture site, preventing reduction to the anatomic position, and disrupting periosteal blood supply. This is corrected by re­creating the mechanism of injury and then reversing the mechanism under traction, unfolding the periosteum, and releasing it from the fracture site.
FIGURE 269­19. A and B. Arrows demonstrate application of force for proper reduction of Colles’ fracture. C. Figure demonstrates proper patient position with the use of finger traps. [Reproduced with permission from Reichman EF, Simon RR: Emergency Medicine Procedures. © 2004, McGraw­Hill, New York.]
Most Colles’ fractures can be treated with closed reduction and application of a sugar­tong splint. If a short arm cast is applied, it should be bivalved to allow for edema. Immobilization for  to  weeks is required. Fractures that are unstable, severely comminuted, or intra­articular may require surgery.
All open and neurovascularly compromised fractures require prompt evaluation by an orthopedic surgeon.
,55
A wide range of complications occur in 6% to 80% of cases; complications are more common with open fracture. The most common complication
 is immediate or delayed carpal tunnel syndrome, due to primary nerve damage or secondarily from tissue swelling. Fractures of the distal ulnar
,57 styloid occur in 60% of radius fractures, and ulnar styloid fractures may also occur but are typically reduced during reduction of the distal radius.
Complications include malunion, median nerve injuries (17%), triangular fibrocartilage complex injuries, radioulnar and radiocarpal instability, and arthritis. These complications may result in a weak, stiff, and painful wrist. Factors associated with long­term disability or instability include dorsal angulation ≥20 degrees and ≥5 mm of radial shortening.  Other complications are often iatrogenic. Splinting in extreme flexion can result in median
 nerve damage. A closed fracture may convert to an open fracture due to thin skin.
SMITH’S FRACTURE
Smith’s fracture, or reverse Colles’ fracture, is a volar angulated fracture of the distal radius. This may result from a fall or direct blow on the dorsum of the hand and wrist, or from a fall on the outstretched hand in flexed position or in supination that then shifts into a pronated position. The hand is displaced palmarly and produces a “garden­spade deformity” on physical examination. The posteroanterior radiograph looks much like the
Colles’ fracture, with a distal metaphyseal radius fracture that may be shortened and comminuted. The lateral radiograph shows the volar
,50,51 angulated and displaced fracture (Figure 269­20).
FIGURE 269­20. Smith’s fracture.
The treatment objectives and complications are much like those seen with the Colles’ fracture. In this case, however, the angulation is volar rather than dorsal, and during reduction, pressure is applied in the opposite direction. Urgent orthopedic follow­up is recommended due to higher incidence of instability.
BARTON’S FRACTURE
Barton’s fractures are dorsal or volar rim fractures of the distal radius. The dorsal rim fractures result from a dorsiflexion and pronation force, whereas the less common volar rim fracture is produced by a fall on the outstretched hand in supination. These injuries are often fraction­dislocations or subluxations, because the carpus is frequently displaced in the direction of the fracture. Accompanying ligamentous injuries create radiocarpal instability. This instability is not fully appreciated in the acute setting, but may lead to various secondary carpal instability patterns and premature degenerative arthritis.
The posteroanterior radiograph often shows a comminuted fracture of the distal radial metaphysis. The lateral view reveals an intra­articular fracture of the volar or dorsal rim of the radius, which may be accompanied by carpal subluxation in the same direction (Figure 269­21).
FIGURE 269­21. Volar Barton’s fracture. A. Posteroanterior view. B. Lateral view.

## Page 35

Minimally displaced fractures can be treated acutely in a sugar­tong splint until evaluation by an orthopedist. Unstable fractures involving >50% of the radial articular surface or those with accompanying carpal subluxation require open reduction and internal fixation. Emergent orthopedic consultation is recommended.
RADIAL STYLOID FRACTURE
A force directed along the radial aspect of the hand can produce a transverse or oblique fracture that extends from the scaphoid fossa to the metaphysis of the radius (Figure 269­22). Primary mechanisms of injury include direct blow to the dorsal surface of the wrist, fall on an outstretched
 hand with avulsion of the radial styloid, and fall on an outstretched hand with wrist extension and abduction. Radial styloid fracture is often accompanied by a dislocation of the lunate. It is best seen on the posteroanterior radiograph as a thin, lucent line beneath the radial styloid. Because the major carpal ligaments along the radial aspect of the wrist insert on the radial styloid, displacement of this fracture can produce carpal instability.
This instability is aided by the extracarpal ligaments (i.e., wrist/finger flexors and extensors causing further displacement of the styloid). Displaced fractures often require open reduction and internal fixation. Displacement of as little as  mm is often associated with accompanying scapholunate dissociation. Failure to recognize intercarpal ligament tears adds to the potential for subsequent posttraumatic arthritis. Refer to an orthopedist. In the ED, place a short arm splint positioning the wrist in mild flexion and ulnar deviation.
FIGURE 269­22. University of Pittsburgh
Access Provided by:
Radial styloid fracture with lunate dislocation. PA = posteroanterior. [Photos contributed by Brooke Beckett, MD, Department of Radiology, Oregon
Health & Science University, Portland, OR.]
ULNAR STYLOID FRACTURE
A forced radial deviation, dorsiflexion, or rotatory stress can fracture the ulnar styloid. The ulnar styloid fracture may be isolated or may accompany other injuries, such as a Colles’ fracture. Clinically, avulsion fractures are rarely significant, with the major consideration being the associated radial soft tissue and bony injuries. Displaced ulnar base fractures can be intra­articular and be associated with tears of the triangular fibrocartilage complex, which is the main stabilizer of the distal radioulnar joint. Patients complain of a painful clicking or locking sensation in the wrist. If the distal radioulnar joint is stable, ulnar styloid fractures are treated acutely in an ulnar gutter splint in slight ulnar deviation and neutral positioning of the wrist. If there is any question about stability, these patients should be referred acutely for surgical evaluation. Arthrograms or MRI imaging may be necessary to delineate the full extent of injury.
DISTAL RADIOULNAR JOINT DISRUPTION
Distal radioulnar joint disruption is associated with several conditions including ulnar styloid and distal ulna fractures, triangular fibrocartilage
 complex tear, ulnar impaction syndrome, Essex­Lopresti injury, and Galeazzi’s fracture. The primary stabilizers of the distal radioulnar joint include the volar and dorsal radioulnar ligaments and triangular fibrocartilage complex. Disruption of the triangular fibrocartilage complex of the distal
 radioulnar joint is generally seen with intra­articular or distal radial shaft fractures (Galeazzi’s fracture­dislocation) or with fractures of both
,53 bones of the forearm. Injury to the triangular fibrocartilage complex of the distal radioulnar joint is found in up to 84% of distal radius fractures.
These more apparent injuries often overshadow distal radioulnar joint disruption and, unfortunately, may remain unrecognized until subsequent pain and diminished wrist movement are appreciated.
Isolated radioulnar joint dislocations are uncommon and are often unrecognized acutely, although these may occur in isolation in the setting of distal
,53 ulnar dislocation. Dorsal dislocation of the ulna results most often from falls on the wrist in hyperpronation and is associated with pain with supination on examination. The rare volar dislocation results from forced hypersupination of the wrist and is associated with pronation on examination. Patients with disruption of the distal radioulnar joint present with pain at the distal radioulnar joint, weak grip, and restricted range of motion, especially pronation and supination. The ulnar head is often prominent but may be subtle and easily overlooked. A positive fovea sign has a sensitivity of 95% and specificity of 87% for triangular fibrocartilage complex instability, which is comprised of tenderness in the soft area between the ulnar styloid and flexor carpi ulnaris tendon. Signs of distal radioulnar joint instability include ulnar styloid fracture involving the base with ≥2 mm displacement, radius sigmoid notch fracture, wide distal radioulnar joint displacement, shortened radius, or failure to reduce distal radioulnar joint
,53 dislocation.
The posteroanterior radiograph reveals narrowing and overlap of the distal radioulnar joint. The lateral radiograph demonstrates either volar or dorsal displacement of the ulna, which is normally centered and overlapping the radius. Because slight oblique positioning of the wrist can produce a misleading appearance of ulnar displacement, make sure to obtain a properly positioned lateral view. A true lateral view should have superimposition of the four ulnar metacarpals, superimposition of the proximal pole of the scaphoid with the lunate and triquetrum, and the radial styloid centered over its distal articular surface. CT scanning may be necessary to establish the diagnosis if plain films are inconclusive.
Immobilizing the wrist in supination reduces dorsal dislocations, whereas volar dislocations are placed in pronation. Patients with acute distal radioulnar joint disruption are referred acutely for orthopedic follow­up. These injuries have a high recurrence rate and may require reconstructive surgery, particularly if there is a delay in diagnosis.

Chapter 269: Wrist Injuries, Brit Long; Alex Koyfman 
Acknowledgments
. Terms of Use * Privacy Policy * Notice * Accessibility
The authors wish to acknowledge the contributions of Robert Escarza; Maurice F. Loeffel, III; Dennis T. Uehara; Dean Wolanyk, MD; and Harold Chin,
MD, for their work on previous editions of this chapter.


