## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 279: Neck and Back Pain
David Della­Giustina; Jeffrey Dubin
INTRODUCTION
Ankylosing spondylitis is discussed in Chapter 282, “Systemic Rheumatic Diseases.”
EPIDEMIOLOGY

Patients presenting with low back pain account for 3% of all ED visits in the United States. Nearly one third of ED back pain patients receive
 radiographs, and 10% undergo CT or MRI imaging. Analysis of the 2010 Global Burden of Disease study reveals a point prevalence of 5% for low back
,4 pain and 9% for neck pain. Back pain is the number one cause of disability in the United States; neck pain is number four.
RISK FACTORS FOR SERIOUS CAUSES OF NECK AND BACK PAIN
There are many causes of neck and back pain, including trauma and biomechanical injuries, degeneration, inflammation (arthritides), infection (e.g., diskitis, meningitis, and epidural abscess), infiltration (e.g., metastatic cancer and spinal cord tumors), and compression (e.g., epidural hematoma and abscess). In many cases of atraumatic neck and back pain, no specific cause can be identified. However, due to the high volume of ED patients with neck and back pain, clinicians can develop an indifference to this complaint and potentially overlook serious causes. Take care to perform a systematic evaluation based on risk factors in the history and physical examination, and let findings guide diagnostic testing and management (Table 279­1).
Consider spinal anatomy while focusing on the presence or absence of neurologic signs to identify pathologic causes and prevent complications.
TABLE 279­1
Risk Factors for Serious Causes of Neck and Back Pain
Risk Factors Concern
Historical Risk Factors
Pain >6 wk Tumor, infection
Age <18, >50 y Congenital anomaly, tumor, infection
Major trauma Fracture
Minor trauma in elderly or rheumatologic disease Fracture
History of cancer Tumor
Fever and rigors Infection
Weight loss Tumor, chronic infection
Injection drug use Infection

Immunocompromised Infection
Chapter 279: Neck and Back Pain, David Della­Giustina; Jeffrey Dubin 
. Terms of Use * Privacy Policy * Notice * Accessibility
Night pain Tumor, infection
Unremitting pain, even when supine Tumor, infection
Incontinence Epidural compression
Saddle anesthesia Epidural compression
Severe/progressive neurologic deficit Epidural compression
Anticoagulants and coagulopathy Epidural compression
Physical Risk Factors
Fever Infection
Patient writhing in pain Infection, vascular cause
Unexpected anal sphincter laxity Epidural compression
Perianal/perineal sensory loss Epidural compression
Major motor weakness/gait disturbance Nerve root or epidural compression
Positive straight leg raise test Herniated disk
Radiculopathy and myelopathy are identified through pattern recognition of the motor and dermatome innervations and their associated spinal level
(see Figure 164­1 and Tables 164­1 and 164­2 in Chapter 164, “Neurologic Examination”).
CLINICAL FEATURES OF NECK PAIN
It is helpful to classify patients with neck pain into two groups: those with uncomplicated neck pain arising mainly from the joints, associated ligaments, and muscles of the neck, and those with neck pain and radiculopathy (signs and symptoms attributable to a single nerve root) and/or myelopathy (signs or symptoms due to a spinal cord lesion, stenosis, or compression).
HISTORY IN PATIENTS WITH NECK PAIN
Ask about the onset, duration, and location of the neck pain; recent or remote trauma; associated symptoms; stiffness; deformity; neurologic complaints (e.g., weakness, changes in sensation, gait, or vision); constitutional symptoms such as fever, anorexia, and weight loss; and comorbid conditions such as arthritis, cancer, and infections. See Table 279­1 for clues to serious pathology. Rheumatoid arthritis, ankylosing spondylitis, and psoriatic spondyloarthropathy may involve the C1–C2 joint, damage the transverse ligament, and erode the odontoid process, yielding instability of the atlantoaxial joint. Subluxation may occur spontaneously or following a trivial injury. Morning stiffness may signify arthritis. Identify precipitating and palliative factors, maneuvers, or activities. Inquire about prior episodes of neck pain, past diagnostic studies, and treatment. Determine the character of pain and its distribution. Patients with radiculopathy often complain of sharp, burning, intense pain that radiates to the trapezius, periscapular area, or down the arm. Weakness or paresthesias may develop weeks after pain onset. Patients with myelopathy may have neck pain that progresses insidiously and may complain of clumsy hands, gait disturbances, and sexual or bladder dysfunction. Table 279­2 summarizes important differences in symptoms between uncomplicated mechanical neck pain and neck pain associated with radiculopathy or myelopathy.
TABLE 279­2
Differentiating Cervical Radiculopathy From Uncomplicated Musculoskeletal Neck Pain
Factors Favoring Cervical Radiculopathy or Myelopathy* Factors Favoring Uncomplicated Musculoskeletal Neck Pain* Pain from the neck radiates down the arm in dermatome pattern. Tenderness of involved muscles; examiner may find a focal point of tenderness.
Sensory changes along dermatome distribution. Atrophy or thinning of shoulder muscles (may occur after rotator cuff injury).
Pushing down on top of head, with neck in extension (chin up) and head Pain increases with shoulder abduction on the side of neck pain leaning toward symptomatic side elicits pain, typically toward or down the (increased pain could derive from rotator cuff–related pain; radicular arm (positive Spurling’s sign); 90% specific, 45% sensitive. pain may decrease with this maneuver).
Pain may worsen with Valsalva, which increases intrathecal pressure. Repetitive movement of arm or shoulder at work or play; may be new activity.
Flex neck forward until chin meets chest or pain stops movement. An electric History of recent injury or recent event of awkward position (e.g., neck or shock sensation radiating down spine into both arms is a positive result head position during sleep in an unfamiliar setting) or awkward standing
(Lhermitte’s sign). Occasionally, paresthesias occur. posture to accommodate a special situation.
Depressed reflexes or, uncommonly, increased reflexes (see also Table 279­3). Pain is accompanied by “stiffness” of involved muscle group.
*Patient in either pain category is not expected to have all, or majority, of listed signs.
PHYSICAL EXAMINATION IN PATIENTS WITH NECK PAIN
Begin with a general assessment of the patient, noting evidence of weight loss, pallor, adenopathy, and abnormalities of posture, movement, and facial
 expression. Pain may cause splinting of the head on the shoulders during position change. Assess active and passive movement, including rotation
(chin to shoulder), lateral flexion (ear to shoulder), and flexion­extension (chin down, then up). Most mechanical causes of neck pain result in asymmetric lesions and asymmetrically limited or painful movements, whereas inflammatory or neoplastic disorders are typically more widespread,
 with pain and movement restriction being more symmetric. When localized ipsilateral neck pain is felt toward the side of head movement, suspect facet (zygapophyseal) joint irritability. Examine for Spurling’s sign (Table 279­2). The abduction relief sign, performed by having the patient place the hand of the affected upper extremity on the top of his or her head to obtain relief, may indicate soft disk protrusion causing radicular pain. When neck pain occurs on the side away from head movement, suspect a ligamentous or muscular source.
Palpate the posterior cervical triangle, the supraclavicular fossa, carotid sheaths, and the anterior neck. C5–C6 root lesions often elicit tenderness over the brachial plexus at Erb’s point,  to  cm above the clavicle, midway up the posterior border of the sternocleidomastoid muscle in the posterior triangle of the neck. A C8–T1 root lesion may cause tenderness over the ulnar nerve at the elbow.
Pathology in the lymph nodes, salivary glands, or thyroid gland may cause neck pain. A bruit over the subclavian arteries may be associated with thoracic outlet or vascular steal syndrome. Examine the temporal artery for tenderness, because temporal arteritis may be the cause of neck and shoulder pain (see also Chapter 165, “Headache”).
Sensory symptoms of pain or dysesthesias are difficult to evaluate, particularly when motor signs are absent, which is often the case in cervical spinal radiculopathies. The discrete separation of the motor and sensory roots at the cervical neural foramina can explain motor sparing despite severe sensory symptoms. For example, C7 root irritability without motor weakness can present as aching at the medial to middle scapular border; aching in the myotome distribution to the chest, axilla, or triceps; or numbness or tingling in the middle finger.
Early detection of cervical spinal myelopathies requires a complete neurologic examination. Hyperreflexia, a positive Babinski’s sign, clonus, gait disturbance, sexual or bladder dysfunction, lower extremity weakness, impaired fine hand movement, and upper and lower extremity spasticity may signal myelopathy. Examine for Lhermitte’s sign (Table 279­2), which is indicative of possible cord compression. Hoffman’s sign indicates an upper motor neuron lesion. With the patient’s hand and wrist supported at rest, the clinician holds the middle finger at the midpoint of the middle phalange, then flicks the tip of the middle finger downward, causing a quick forced flexion at the distal interphalangeal joint. A positive (abnormal) response is flexion of the thumb and index finger in a pinching motion.
Table 279­3 summarizes the sensory, motor, and reflex findings in cervical radiculopathy. This information should be used to determine the level of motor and sensory involvement and to compare findings in the affected and unaffected sides. Bilateral or multilevel involvement usually implies serious pathology.
TABLE 279­3
Signs and Symptoms of Cervical Radiculopathy
Disk Cervical Sensory
Pain Complaint Motor Weakness Altered Reflex
Space Root Abnormality
C1–C2 C2 Neck, scalp Scalp
C4–C5 C5 Neck, shoulder, upper arm Shoulder Infraspinatus, deltoid, Reduced biceps biceps reflex
C5–C6 C6 Neck, shoulder, upper medial, scapular area, proximal Thumb and index Deltoid, biceps, Reduced biceps and forearm, thumb, index finger finger, lateral pronator teres, wrist brachioradialis reflex forearm extensors
C6–C7 C7 Neck, posterior arm, dorsum proximal forearm, chest, Middle finger, Triceps, pronator teres Reduced triceps medial third of scapula, middle finger forearm reflex
C7–T1 C8 Neck, posterior arm, ulnar side of forearm, medial inferior Ring and little Triceps, flexor carpi Reduced triceps scapular border, medial hand, ring, and little fingers fingers ulnaris, hand intrinsics reflex
DIAGNOSIS OF NECK PAIN
Laboratory testing is rarely helpful, unless considering infection. See the “Epidural Compression Syndrome,” “Transverse Myelitis,” and “Spinal
Infection” sections later in this chapter, as well as Chapter 174, “Central Nervous System and Spinal Infections.”
The need for imaging studies depends on the clinical condition suspected and the duration of neck pain. Acute (days to weeks), uncomplicated, nonradicular, nonmyelopathic, atraumatic neck pain typically requires no imaging because the cause is likely benign and the treatment is
 conservative. Obtain three­view cervical spine films in patients with chronic (weeks to months) neck pain with or without a history of trauma, those
 with neck pain and a prior history of malignancy or remote neck surgery, and those with neck pain and preexisting spinal disorders such as rheumatoid arthritis, ankylosing spondylitis, and psoriatic spondyloarthropathy. Flexion­extension films may be useful if instability is suspected,
 especially in patients with rheumatoid arthritis or other inflammatory arthritides. Patients with normal radiographs, patients with radiographic evidence of degenerative changes without neck instability, or patients with radiographic evidence of previous trauma and no neurologic signs or
 symptoms require no further imaging. MRI is indicated for patients with chronic neck pain with new neurologic signs or symptoms
 regardless of the plain radiographic findings. MRI is also indicated when plain radiographs reveal bone or disk margin destruction, if there is
 cervical instability, and (with IV contrast) if epidural abscess or malignancy is suspected. CT myelography is recommended when contraindications to
MRI exist.
DIFFERENTIAL DIAGNOSES OF NECK PAIN
Mechanical Neck Disorders
Mechanical neck disorders are also called hyperextension strain, acceleration­deceleration injury, hyperextension­hyperflexion injury, neck strain, neck sprain, and whiplash. The most common precipitating events are motor vehicle collisions, falls, sports injuries, and work­related injuries (see
Chapter 258, “Spine Trauma” for discussion of acute injury). Strain injury, caused by an awkward position during sleep or prolonged abnormal headneck positions during work or recreation, is another cause.
Cervical Disk Herniations
Cervical disk herniations occur as the nucleus pulposus protrudes through the posterior annulus fibrosis, producing an acute radiculopathy or, occasionally, a myelopathy. Protrusions are usually confined by the posterior longitudinal ligament but can occasionally extrude through this ligament as free fragments. Direct posterior ruptures, although infrequent, can produce progressive myelopathy, whereas the more common posterolateral herniations can cause acute cervical radiculopathy. The levels of most frequent involvement are C5–C6 (C6 root) and C6–C7 (C7 root).
The symptoms of an acute cervical disk prolapse include neck pain, headache, pain distributed to the shoulder and along the medial scapular border, dermatome pain, and dysesthesia in the spinal root distribution to the shoulder and arm. Motor signs include fasciculations, atrophy and weakness in the dermatome distribution of the spinal root, loss of deep tendon reflexes, and, with cervical myelopathy, lower extremity hyperreflexia, Babinski’s sign, and in rare cases, loss of sphincter control. Cervical hyperextension and lateral flexion to the symptomatic side (Spurling’s sign; Table 279­2) may replicate the symptoms, as can a Valsalva maneuver, whereas manual cervical distraction in flexion alleviates them. A thorough physical examination, including strength, sensory, and reflex testing, may delineate the level of root involvement (Table 279­3). MRI is necessary for diagnosis.
Cervical Spondylosis and Stenosis
Cervical spondylosis (or degenerative disk disease or osteoarthritis) is a progressive, degenerative condition resulting in a loss of cervical flexibility, neck pain, occipital neuralgia, radicular pain, or occasionally progressive myelopathy. There is progressive degeneration of the disks, ligaments, facet joints (zygapophyseal joints), and uncovertebral joints (joints of Luschka). From a radiographic standpoint, cervical spondylosis may be diagnosed if any one of three findings is present: osteophytes, disk space narrowing, or facet disease. However, there is a high prevalence of cervical spondylosis in asymptomatic individuals. Do not assume painful syndromes are due to findings on imaging. Degenerative disk disease predisposes a patient to progressive osteoarthrosis of the cervical spine, joint instability, and incongruous joint motion during neck movement. Spondylosis most commonly occurs at the C5–C6 and C6–C7 levels.
Osteophytic spurs can encroach posteriorly on the spinal canal, producing cervical myelopathy; laterally on the intervertebral foramen, producing cervical radiculopathy; and anteriorly on the esophagus, producing dysphagia. Spurious osteophytes may also produce Horner’s syndrome, vertebrobasilar symptoms, severe radicular symptoms without associated neck pain, painless upper extremity myotome weakness, and chest pain mimicking angina. Neurologic findings (radiculopathy or myelopathy) may be gradual in onset unless there is a history of recent trauma.
Cancer of the Cervical Spine
Consider metastatic cancer in the differential diagnosis of chronic neck pain, especially unremitting night pain. Lung, breast, and prostate cancers, lymphoma, and multiple myeloma may involve the cervical spine. Although most cases of epidural cord compression occur in the thoracic spine, involvement of the cervical spine and multiple levels is not unusual. Myelopathy, which is commonly caused by disk or degenerative disease, is rarely
 caused by metastatic tumors. Plain films have inadequate sensitivity (10% to 17% false­negative rate) in detecting spinal metastases, but may reveal destruction of the vertebral bodies, lytic lesions of the pedicles, and pathologic compression fractures. MRI is the standard for the detection of spinal epidural metastatic disease and cord compression. Cancer patients with radiographic evidence of bone or disk margin destruction should undergo

MRI.
Cervical Myofascial Pain Syndrome
Myofascial pain syndrome is a cause of chronic neck pain and is often confused with radiculopathy. Myofascial pain symptoms may present or exacerbate acutely, especially after trauma. Psychological distress and specific personality traits are risk factors. Typically, patients complain of pain in the neck, scapula, and shoulder with or without nondermatomal radiation into the upper extremity. Tender spots, “trigger points,” may be evident on palpation of the head, neck, shoulder, and scapular region. Neurologic examination is normal. See Chapter , “Chronic Pain,” for management.
Other Conditions
Epidural abscess, osteomyelitis, and transverse myelitis are infectious and inflammatory causes of neck pain (see related sections later in this chapter).
Cervical spinal epidural hematoma often presents as neck pain followed by symptoms and signs of cord compression (see later section on epidural compression syndrome) and should be considered in the patient taking anticoagulants or in the patient with a bleeding diathesis. Pain from ischemic heart disease may radiate into the neck and shoulder. Peripheral nerve involvement, such as carpal tunnel syndrome, may present as a C6–C7 sensory radiculopathy, whereas multiple sclerosis, amyotrophic lateral sclerosis, subacute combined degeneration, and syrinx are in the differential of myelopathy.
TREATMENT AND DISPOSITION OF PATIENTS WITH NECK PAIN
Treatment issues can be divided into three categories: neck pain, neck and arm pain consistent with radiculopathy, and myelopathy. There is little evidence­based science to support many of the commonly recommended conservative treatment modalities (e.g., physiotherapy, acupuncture,
7­11 electrotherapy, manipulation, traction, thermotherapy, medicinal and injection therapies, exercises). A European guideline for the management of
 acute neck pain summarized the available evidence. Individual patients may indeed benefit from one or more of these therapies.
TREATMENT OF UNCOMPLICATED NECK PAIN
Most cases of neck pain without clear underlying pathology will improve with minimal intervention. The patient should be advised to “act as usual” and avoid activities that produce pain. Initial medications may include NSAIDs, muscle relaxants, and for significant pain, a short course of oral opioids; no
,12
NSAID, muscle relaxant, or opioid is clearly superior to another in its class. Encourage patients to follow up with their primary physician to assess the need for physical or manual therapies or additional medications.
Patients with acute neck pain following an acceleration­deceleration (whiplash) injury may benefit from a similar pharmacologic regimen. Treatment
 with a semi­rigid collar provided no measurable benefit. A soft collar reduces range of motion of the neck less than 20% and provides no measurable
 reduction of pain or shortening of recovery time. Spinal manipulation therapy or home exercises after two 60­minute physical therapy sessions may
 each be more effective than medication therapy for short­ and long­term pain relief.
Therapy for neck pain from myofascial pain syndrome should address both muscular tension and psychobehavioral issues. See Chapter , “Chronic
Pain,” for further discussion, including recommendations for alternative therapies.
TREATMENT OF CERVICAL RADICULOPATHY
In the absence of myelopathy, first­line treatment is conservative activity modification to prevent symptom exacerbation or injury and oral medications. Immobilization with a soft or hard cervical collar is controversial without clear evidence for or against its use. Encourage follow­up with a primary physician for possible referral to a spine specialist, an electrodiagnostic evaluation, and additional rehabilitation interventions. Oral medications may include NSAIDs, opioid analgesics, and muscle relaxants. A 7­ to 10­day course of oral steroids (e.g., methylprednisolone or
 prednisone) is commonly prescribed for acute radiculopathy, but steroid efficacy has not been demonstrated. Epidural steroid injections may be
 effective for chronic cervical radiculopathy when other treatments have failed. If the symptoms and signs of acute cervical root compression fail to
 respond to conservative treatment, or if they recur, and if imaging demonstrates concordant findings, surgery may be recommended. Indications for hospital admission include progressive upper extremity weakness, especially in the C7 distribution; acute or progressive symptoms or signs of myelopathy; and finally, in a small subset of patients, intractable radicular pain unresponsive to treatment.
TREATMENT OF CERVICAL MYELOPATHY
Treatment decisions for patients with symptoms and signs of cord compression should be made in conjunction with specialists. Cervical spondylotic myelopathy causes the greatest degree of impairment and disability in the continuum of spondylosis. In addition, myelopathy is the most common cause of spastic paraparesis in patients older than  years of age, thus paralleling the time course of spondylosis. The patient with myelopathy should be referred to a spine surgeon to discuss the possibility of decompressive surgery. Additional therapeutic considerations (e.g., steroids and radiation in spinal epidural metastases) will depend on the time course of symptoms and signs and etiology, but should be addressed in conjunction with a
 spine surgeon.
CLINICAL FEATURES OF THORACIC AND LUMBAR PAIN SYNDROMES
Back pain is categorized based on the duration of symptoms: acute back pain lasts <6 weeks, subacute pain lasts between  and  weeks, and chronic
 pain continues beyond  weeks. Pain lasting >6 weeks is an indicator of more serious disease, since most episodes of nonspecific back pain (80% to
90%) resolve within  weeks. Risk factors for serious causes of back and neck pain are listed in Table 279­1; specific historical factors that help to identify benign versus serious causes of back pain are listed in the following sections.
HISTORICAL RISK FACTORS IN BACK PAIN
Patient Age
Back pain secondary to tumor or infection is more common in patients <18 years old and >50 years old than in the 18­ to 50­year­old age group.
Patients <18 years old also have a higher incidence of congenital and bony abnormalities such as spondylolysis, spondylolisthesis, and Scheuermann’s kyphosis. Patients >50 years old are also more prone to fractures (age >65 years is more specific for fracture), spinal stenosis, and intra­abdominal processes such as an abdominal aortic aneurysm.
Pain Location and Radiation
Pain that originates from muscular, ligamentous, vertebral, or disk disease without nerve involvement is located primarily in the back, possibly with radiation into the buttocks or thighs. Sciatica, radicular back pain in the distribution of a lumbar or sacral nerve root, is often accompanied by sensory
 or motor deficits. Sciatica occurs in only 1% of patients with back pain and is associated with disk herniation or nerve root impingement below the L3 nerve root. Ninety­five percent of herniated disks occur at the L4–L5 or the L5–S1 lumbar disk spaces, impinging on the L5 or S1 nerve roots,
,18 respectively.
Occult or Minor Trauma
In the elderly, minor trauma, such as falling from standing or from sitting in a chair, may cause fracture due to associated osteoporosis. Risk factors for osteoporosis increase the incidence of compression fractures (i.e., female sex, steroid use, alcoholism).
Systemic Complaints
Systemic symptoms such as fever, chills, night sweats, malaise, and an undesired weight loss suggest infection, systemic rheumatologic disease, or malignancy. These symptoms are more concerning for infection if the patient has any of the following risk factors: recent bacterial infection (including urinary tract infection, pneumonia, and especially skin abscesses), recent GU or GI procedure, immunocompromised status, injection drug use,
19­21 alcoholism, renal failure, or diabetes. The most significant predictors of spinal infection in decreasing order are fever (or rigors), antimicrobial
 therapy use in the past  days, significant spinal pain, injection drug use, advanced age, and diabetes.
A rupturing abdominal aortic aneurysm is the most immediately life­threatening extraspinal cause of back pain. Other potential causes of pain referred to the back include pancreatitis, a posterior lower lobe pneumonia, nephrolithiasis, and renal infarct.
Pain Features
A dull, aching pain that generally worsens with movement but improves with rest and lying still is the typical description of benign back pain.
Symptoms suggestive of tumor and infection include pain that occurs at night and often awakens the patient from sleep or that is unrelenting despite
,23 appropriate use of analgesics and rest. Pain worsened by coughing, Valsalva maneuver, or sitting and that is relieved by lying in the supine position suggests herniation. Spinal stenosis is associated with bilateral sciatic pain that is worsened by activities such as walking, prolonged standing, and back extension and is relieved by rest and forward flexion. In the authors’ experience, night pain and unrelenting pain are worrisome symptoms that should be specifically queried as part of the history, because these symptoms are risk factors for serious disease and such queries are often omitted in history taking.
Neurologic Deficit by History
Neurologic complaints such as paresthesias, numbness, weakness, and gait disturbances must be further addressed in the history and delineated in the physical examination to determine whether the symptoms involve single or multiple nerve roots. Bowel or bladder incontinence is a serious symptom that raises concern for an epidural compression syndrome, such as spinal cord compression, cauda equina syndrome, or conus medullaris syndrome. If a patient has back pain and has a history of urinary incontinence (acute or chronic) but an otherwise completely normal history and evaluation, measure the postvoid residual volume with bedside US or by catheterization if US findings are in doubt. A large postvoid residual volume
(e.g., >100 mL) indicates overflow incontinence, which, when combined with the presence of low back pain, suggests neurologic compromise and an
,24 epidural compression syndrome.
Past Medical History

History of cancer is a risk factor because back pain is the initial symptom in the majority of those with spinal metastases. Malignant neoplasm is the most common systemic disease affecting the spine. Most patients with this diagnosis are >50 years old. In 20% of patients presenting with spinal cord
 compression, the primary malignancy has yet to be diagnosed. Thus, symptoms such as unremitting pain, night pain, and weight loss require further diagnostic testing.
PHYSICAL EXAMINATION RISK FACTORS IN BACK PAIN
Although fever is a marker of infection, sensitivity for infection is low, varying from 27% for tuberculous osteomyelitis to 50% for pyogenic
,23 osteomyelitis, 60% to 70% for pyogenic diskitis, and 66% to 83% for spinal epidural abscess. In patients with severe or excessive pain, consider acute spinal infection or abdominal aortic aneurysm. Examine the abdomen, listen for bruits, and palpate for masses, tenderness, and an enlarged aorta.
Examine the back for signs of erythema, warmth, skin abscesses, furuncles, and purulent drainage, which suggest an underlying spinal infection.
Contusion and swelling suggest trauma. Palpate the back from cervical spine to sacrum, and percuss the vertebral bodies. Consider fracture or bacterial infection if there is point tenderness to vertebral percussion. Perform straight leg raise testing. With the patient lying supine, lift each leg separately to approximately  degrees in an attempt to produce radicular pain. A positive straight leg raise test causes a radicular pain radiating below the knee of the affected leg. This pain is worsened by ankle dorsiflexion and improved with ankle plantar flexion or decreasing leg elevation.
Reproduction of the patient’s back pain or pain in the gluteal or hamstring area when the leg is raised is not a positive result. The straight leg raise test can be easily replicated with the patient in the seated position with similar leg extension and foot dorsiflexion (Figure 279­1). Straight leg raise testing is a screening examination for a herniated disk. One third of those with positive straight leg raising test and a negative sitting knee extension test have
  an MRI­proven herniated disk. A positive straight leg raise test is 68% to 80% sensitive for a L4–L5 or L5–S1 herniated disk. Radicular pain down the affected leg when lifting the asymptomatic leg is called a positive crossed straight leg raise test. A positive result is highly specific but insensitive for nerve root compression by a herniated disk.
FIGURE 279­1. Sitting knee extension test. With the patient sitting on a table and both hip and knees flexed at  degrees, slowly extend the knee as if evaluating the patella or bottom of the foot. This maneuver stretches nerve roots as much as a moderate degree of supine straight leg raising.
Neurologic Examination for Back Pain
The neurologic examination is directed to detecting deficits in each of the specific spinal nerve roots. Sensation may be tested by using light touch initially, followed more formally by pinprick, temperature, proprioception, and vibration testing if there are any questions regarding diminished sensation. Next assess strength, with a focus on those muscle groups innervated by individual nerve roots (Figure 279­2). Individually test the ankle dorsiflexors (L4), extensor hallucis longus (great toe dorsiflexion) (L5), and ankle plantar flexors (S1/S2). Finally, evaluate the patellar (L3–L4), Achilles
(S1), and Babinski’s reflexes. There is no easily obtainable reflex for the L5 nerve root.
FIGURE 279­2. Testing for lumbar nerve root compromise.
It is not necessary to perform a digital rectal examination on all patients with back pain. However, perform rectal examination in patients with neurologic complaints or findings on physical examination and those with risk factors for serious disease. Evaluate rectal sphincter tone and perianal sensation and the presence of prostatic and rectal masses. Poor rectal tone in association with back pain and saddle anesthesia indicates an epidural compression syndrome.
DIAGNOSIS OF BACK PAIN SYNDROMES
For most patients, no testing is required. However, laboratory testing is indicated in the ED if there is concern for infection, tumor, or rheumatologic causes of the back pain. Order a CBC, erythrocyte sedimentation rate, and urinalysis. With infection, the WBC count may be normal or elevated.
However, the erythrocyte sedimentation rate is typically elevated (>20 mm/h), even in immunocompromised patients, with a sensitivity of 90% to 98%
,23,27 for spine infection. The erythrocyte sedimentation rate will also be elevated in patients with a rheumatologic or neoplastic disease of the
,19 ,19,23 spine. The C­reactive protein will also be elevated with acute spinal infection. Obtain a urinalysis to identify urinary tract infection or renal disease causing pain referred to the back.
IMAGING
Plain Spinal Radiographs
Plain radiographs can be considered when one suspects fracture, tumor, or long­standing osteomyelitis, but sensitivity is only 83% for tumor and very poor for infection. Anteroposterior and lateral views are sufficient. The coned­down L5–S1 and oblique views rarely add clinically useful information while more than doubling gonadal radiation exposure and cost.
CT Scanning
CT imaging is most useful for evaluating vertebral fractures, the facet joints, and the posterior elements of the spine. It shows good detail of the vertebral bodies, but has poor resolution of the spinal canal and spinal cord in comparison with MRI. CT may be useful if MRI is unavailable or unsuitable, but CT myelography is the best substitute for conditions such as epidural abscess or cord compression when MRI is unavailable.
MRI
MRI provides the best resolution for lesions in the vertebral bodies, spinal canal, and spinal cord, and for disk disease. MRI is the standard study in cases of suspected spinal infection, neoplasm, and epidural compression syndromes. MRI is also used to determine progression of neoplastic processes of the spine and disk disease and for continued back pain for  to  weeks. In cases of suspected infection, tumor, or epidural compression,
,29 contrast enhancement with gadolinium should be used.
DIFFERENTIAL DIAGNOSIS AND MANAGEMENT OF BACK PAIN SYNDROMES
ACUTE NONSPECIFIC BACK PAIN
Nonspecific back pain is a symptom complex that has countless names, including back strain/sprain, mechanical back pain, and lumbago. However, because strain and/or sprain have no histopathologic findings, a more accurate term to use is idiopathic or nonspecific back pain. Nonspecific back pain is the authors’ choice of term, especially because most patients will never be given a more precise diagnosis.
Diagnosis is clinical. The pain is mild to moderate and is aggravated with movement and relieved with rest. Although the typical mechanism is usually minor exertion or lifting, the patient may not recall any remarkable etiology. There are no risk factors for serious disease on the history and physical examination, or if any risk factors are present, the diagnostic evaluation is normal.
General Management
Treatment focuses on restriction of activity, analgesia, manipulation, and other physical modalities. Monitor symptoms for  to  weeks before
 embarking on further diagnostics. In 80% to 90% of patients, symptoms will resolve on their own within this time period. Watchful waiting avoids wasting time and money and eliminates exposure to unnecessary radiation. This course of action should be discussed with patients because they may expect diagnostic testing.
Patients who resume their normal activities to the furthest extent tolerable recover more rapidly than those on  or  days of bed rest or those who
  perform back­mobilizing exercises. Thus, patients should continue daily activities using pain as the limiting factor. Withhold exercise programs until the acute painful episode has resolved or improved significantly.
NSAIDs
31­33 ,34,35
Medication should primarily be NSAIDs. Previously, acetaminophen was recommended; however, recent research shows no benefit. Most

NSAIDs are equally efficacious for back pain. However, there are significant differences in the side effect profiles and toxicity. Ibuprofen was reported
 to be the least toxic of the  NSAIDs studied, with regard to upper GI bleeding. However, a population study did not find a difference in bleeding
 rates between NSAIDs. Because there is a linear relationship between dose and toxicity, the lowest dose possible should be used in patients at risk. In
,32 patients at risk for GI bleeding, the addition of a proton pump inhibitor or misoprostol can reduce the risk.
We recommend ibuprofen, 400 to 800 milligrams three times daily, or naproxen, 250 to 500 milligrams twice daily. If there is a concern for GI bleeding, then add a proton pump inhibitor such as omeprazole,  milligrams once daily.
Opioid Analgesics
,31,33,35
Opioid analgesics should only be offered to patients with moderate to severe pain with a limited (3­day) duration. Guidelines do not
,33,35,39 recommend opioids as first­line treatment for acute back pain.
Muscle Relaxants
,33
Muscle relaxants are useful for treating back pain. Muscle relaxants, such as methocarbamol, 1000 to 1500 milligrams four times a day, provide
,33 some benefit. Benzodiazepines, while providing benefit similar to other muscle relaxants, have greater side effects and potential for addiction and
,33 therefore are not recommended by guidelines. There does not appear to be any additional pain relief or synergistic benefit when muscle relaxants
,33,40,41 and NSAIDs are used in combination. Corticosteroids taken systemically or injected locally or into the epidural space have no role in the
,33,42 treatment of nonspecific back pain.
Manipulative Therapy
Manipulative therapy, while not generally an ED treatment, is one of the more controversial treatment options for back pain. Clinical outcome of
 ,44,45 manipulation is no better than standard medical therapy according to a Cochrane review, but in other reviews, it was considered helpful.
Other Treatments

The application of heat or ice may provide temporary symptomatic relief in some patients, with evidence favoring heat. Other physical modalities include traction, diathermy, cutaneous laser treatment, exercise, US treatment, and transcutaneous electrical nerve stimulation; none of these has any proven efficacy in the treatment of acute low back symptoms.
CHRONIC NONSPECIFIC BACK PAIN
There is a higher concern for serious disease in patients with ongoing or intermittent symptoms for a time period of months to years. The best approach is to review the previous evaluations for completeness and to be sure that abnormalities were not overlooked. If the evaluation has been incomplete, then consider completing it in the ED at that visit, or facilitate referral for an outpatient evaluation, with urgency guided by the severity of symptoms. If the evaluation has been thorough but negative, then treat as described for nonspecific back pain. Opioid analgesics should not be prescribed for chronic back pain from the ED. Pharmacologic therapies shown to be effective and recommended for chronic back pain by guidelines
,33 include NSAIDs and the serotonin­norepinephrine reuptake inhibitor duloxetine,  milligrams once daily. Both gabapentin and pregabalin are
 commonly used for chronic back pain, but neither has been shown to be effective, both have significant sedation effects, and the potential for abuse
 has been raised. In contrast to the lack of proven benefit for acute back pain, exercise therapy, yoga, tai chi, and multidisciplinary management (at
,33 follow­up) have been shown to provide a small to moderate benefit in patients with chronic back pain.
LOW BACK PAIN WITH SCIATICA
Although sciatica affects only a very small proportion of all patients with back pain, it is present in the vast majority of patients with a symptomatic herniated disk. Although disk herniation is the most common cause of sciatica, anything that compresses or impinges on the spinal nerve roots, cauda equina, or spinal cord can cause sciatica. Other important etiologies to consider include intraspinal tumor or infection, foraminal stenosis, extraspinal plexus compression, piriformis syndrome (see Chapter 281, “Hip and Knee Pain”), and lumbar canal stenosis (spinal stenosis). Studies find little
,49 benefit for most therapy, including NSAIDs, corticosteroids, antidepressants, anticonvulsants, muscle relaxants, or opioids. A small study found
 benefit from gabapentin.
DISK HERNIATION
Diagnosis
The diagnosis is suspected clinically and confirmed with nonurgent MRI (urgent MRI only in the setting of suspected epidural compression). Patients who present with sciatica due to a herniated disk generally complain more about the radicular symptoms than about back pain. Because the vast majority of disk herniations occur at the L4–L5 (L5 nerve root) or L5–S1 (S1 nerve root) level, the radicular pain extends below the knee in the dermatomal distribution of that nerve root. A small proportion of patients (often the elderly) have disk herniation at the L2–L3 (L3 nerve root) and L3–
L4 (L4 nerve root) levels. The physical examination generally demonstrates localization of pain and a neurologic deficit in a unilateral single nerve root, usually L5 or S1, and frequently includes a positive result on straight leg raise testing.
If the patient has no risk factors in the history and physical examination for serious disease other than sciatica, treat conservatively
 and do not perform any diagnostic tests in the ED. If the patient has a demonstrable neurologic deficit, consider obtaining plain radiographs to look for other possible causes for symptoms such as tumor, fracture, spondylolisthesis, and infection. Guidelines recommend imaging (MRI preferred) in patients with severe or progressive neurologic deficits and those with serious underlying conditions suspected based on history or
,18 physical examination. If the symptoms have not progressed rapidly or the symptoms are not severe, the MRI can be ordered routinely or urgently
 rather than emergently.
Treatment
Management is similar as for nonspecific back pain. Routine daily activity is as good as  weeks of bed rest in terms of intensity of pain, distress
,30 associated with symptoms, and functional status. Recommendations for analgesics include primarily NSAIDs and limited opioids for more severe
,48  pain. NSAIDs are less effective in treating the symptoms of a herniated disk than they are in treating nonspecific back pain. There is insufficient
,48­50 evidence to recommend the use of muscle relaxants and antiepileptic drugs.
Corticosteroid therapy for herniated disk has limited benefit. Specifically, epidural corticosteroid injection provides a minor reduction in leg pain and sensory deficits in comparison with placebo. However, the improvement in symptoms is not associated with any significant functional benefit, and
,48 it does not reduce the need for surgery. Although epidural steroid injection is not an ED procedure, it offers an alternative for the moderately to
 severely symptomatic patient in follow­up. Although oral steroids are used widely, they have no lasting measurable benefit in patients with sciatica.
,44
Spinal manipulative therapy has had varying results. At this time, reviews show that it results in a small decrease in pain up to  weeks.
Most patients with a herniated disk may be treated and monitored by their primary care physician without specialist referral. Patients generally improve with nonsurgical therapy, with over half recovering in  weeks. Most spine surgeons agree that surgery is appropriate only when all three of the following criteria are met: definitive evidence of herniation on imaging study; corresponding clinical picture and neurologic deficit; and conservative treatment for  to  weeks that fails to produce improvement.
Emergency decompressive surgery is required only in patients with acute epidural compression syndromes. Patients who underwent surgery had improved function and fewer symptoms at  and  years postoperatively, compared with those treated conservatively; however, by  and  years
,52­54 postoperatively, both groups had comparable results. This is an important point to discuss with your patients to give them reassurance about your treatment plan.
SPINAL STENOSIS
Spinal stenosis is a narrowing of any part of the lumbar spine, including the spinal canal, nerve root canal, and intervertebral foramina, which may occur at single or multiple spinal levels. Degenerative disease causes narrowing and compression of vascular and neural structures. It is a cause of chronic back pain, with or without associated sciatica. The symptoms, which usually begin in the sixth decade, include low back pain that is aggravated by prolonged standing and spinal extension and is relieved by rest and forward flexion. Typically, symptomatic patients present with low back and lower extremity pain while walking that is symptomatically similar to vascular claudication. This symptom is termed neurogenic claudication or pseudoclaudication to distinguish it from vascular claudication. Neurogenic claudication is relieved with rest and forward flexing of the
 spine and worsened by extending the spine. Physical examination findings are often absent. The diagnosis is made principally by history with confirmation by CT scan or MRI. Symptomatic treatment is the same as for chronic back pain with primary care follow­up.
EPIDURAL COMPRESSION SYNDROME
Epidural compression syndrome is a collective term encompassing spinal cord compression, cauda equina syndrome, and conus medullaris syndrome.
Although the diagnosis of a complete epidural compression is obvious, the challenge is to make the diagnosis in patients with early signs and symptoms. The initial differential diagnosis is broad and includes most conditions that cause weakness, sensory changes, or autonomic dysfunction of the lower extremities. The history and physical examination should narrow the differential diagnosis to a compressive lesion of the spinal cord or cauda equina.
Possible causes of nontraumatic epidural compression include spinal canal hemorrhage with hematoma, tumors of the spine or epidural space, spinal canal infections including spinal epidural abscess, and massive midline disk herniation. Transverse myelitis is a noncompressive condition that may present clinically like a compressive lesion of the spinal cord.
Clinical Features
The history usually includes back pain with associated neurologic deficits. Specifically, it may include perianal sensory loss, fecal incontinence or urinary incontinence with or without retention, and sciatica in one or both legs. The duration of symptoms does not differentiate these syndromes from benign causes of back pain. In one small study, urinary retention of >500 mL alone or in combination with two of the following characteristics—bilateral sciatica, subjective urinary retention, or rectal incontinence symptoms—is the most important predictor
 of MRI­confirmed cauda compressions. In addition, a history of malignancy and a rapid progression of neurologic symptoms, especially bilateral symptoms, increase the likelihood of compression.
The physical examination findings vary depending on the level of compression and the amount and area of the spinal cord or cauda equina that is compressed. The most common finding in cauda equina syndrome is urinary retention with or without overflow incontinence, with a
 sensitivity of 90% and a specificity of about 95%. Other common findings for epidural compression include weakness or stiffness in the lower extremities, paresthesias or sensory deficits, gait difficulty, and abnormal results on straight leg raise testing. The most common sensory deficit occurs over the buttocks, posterosuperior thighs, and perineal regions and is commonly called saddle anesthesia. Anal sphincter tone is decreased in 60% to
80% of cases.
Diagnosis and Management
When one clinically suspects epidural compression, especially due to tumor, treat the patient with dexamethasone,  milligrams
,56
IV, before obtaining any confirmatory tests. After the patient has received dexamethasone, obtain an emergent MRI with gadolinium of the spine. If investigating the possibility of epidural compression due to neoplasm, obtain an MRI of the entire spine because 10%
,57 of patients with vertebral metastases have additional silent epidural metastases that would be missed by a localized imaging study. The presence of tumors remote from the symptomatic site may change patient management. In addition, the neurologic examination may falsely localize the spinal lesion(s) and limited regional MRI may not detect the lesion. If one suspects a pure cauda equina syndrome from a herniated disk, then it is reasonable to obtain an MRI localized to the lumbosacral spine.
The functional clinical outcome for epidural compression from tumor depends on patient symptoms at presentation. Patients who cannot walk before treatment rarely walk again. Those who are too weak to walk without assistance but who are not paraplegic have a 50% chance of walking again. Those
 who are able to walk when treatment begins are likely to remain ambulatory. Of those patients who require a catheter for urinary retention before treatment, 82% will continue to require the urinary catheter after treatment. The presence of cord compression is an indication for urgent consultation
,58 with a spine surgeon for decompression and/or radiation therapy for a tumor mass, determined by MRI findings.
TRANSVERSE MYELITIS
Transverse myelitis is an inflammatory disorder that involves a complete transverse section of the spinal cord. It usually presents with neck or back pain in association with neurologic complaints and findings on physical examination, depending on the level of the spinal cord that is involved. The typical clinical syndrome involves bilateral motor, sensory, and autonomic disturbances that may progress over a period of days to weeks. Fecal and
,60 urinary retention and incontinence are common. Transverse myelitis may result from viral infection, after vaccination, or as part of a systemic
 disease such as systemic lupus erythematosus, cancer, or, more commonly, multiple sclerosis. The most important issue regarding transverse myelitis is recognition of the potential for a compressive lesion of the spinal cord and managing the patient as outlined under epidural compression
,60 syndromes. The MRI may demonstrate lesions of the spinal cord, but MRI findings may lag the clinical presentation, especially early in the disease
 process. In those situations where the patient has definite neurologic findings that are consistent with epidural compression but has a normal MRI, transverse myelitis is one of the primary working diagnoses. In such cases, consult a neurologist for admission and consider performing a lumbar
 puncture to assist in the diagnosis. The spinal fluid most commonly demonstrates lymphocytosis and elevated protein. Treatment includes
,60  corticosteroids and plasma exchange at the direction of a neurologist. Disability is common despite treatment.
SPINAL INFECTION
Spinal infections, such as vertebral osteomyelitis, diskitis, and spinal epidural abscess, are uncommon but serious causes of back pain. Unfortunately,
,27 these infections are commonly missed on first assessment. Risk factors for infection include the following: immunocompromised states (diabetes, human immunodeficiency virus infection, and organ transplant recipients), alcoholism, recent invasive procedures, spinal implants and devices,
,23,27,29 injection drug use, and skin abscesses. See Chapter 174, "Central Nervous System and Spinal Infections for further discussion."
Vertebral Osteomyelitis
,63
Patients with vertebral osteomyelitis usually have had prolonged symptoms, and in many cases, pain has been present for >3 months. On
,63 physical examination, about half have fever and vertebral body tenderness to percussion. The WBC may be normal, but the erythrocyte
,23,29,63 sedimentation rate and C­reactive protein are almost always elevated, although this is nonspecific. Blood cultures are positive in approximately 40% of cases of vertebral osteomyelitis and should be routinely drawn as part of the management. In osteomyelitis, plain radiographs are normal until the bone demineralizes, which can take from  to  weeks. The most common radiographic abnormalities with vertebral
 osteomyelitis are bony destruction, irregularity of vertebral end plates, and disk space narrowing. See the section on osteomyelitis in
Chapter 281 for further discussion.
Diskitis
In patients with diskitis, >90% present with a complaint of unremitting back or neck pain, which awakens them at night and is relieved by neither rest
 nor analgesics. Fever is present in 60% to 70% of patients, whereas the percentage of patients with neurologic deficits is highly variable, from 10% to

50%. Elevation in the erythrocyte sedimentation rate occurs in >90% of patients, whereas elevated WBC count occurs in less than half of patients.
Spinal Epidural Abscess
The classic triad of symptoms suggesting spinal epidural abscess is severe back pain, fever, and neurologic deficits, but the triad occurs in only 8% to

13% of patients. Spinal epidural abscess is commonly found in association with vertebral osteomyelitis and diskitis in 62% and 38% of cases,
,64 respectively. Risk factors for epidural abscess include injection drug use, immunocompromise, alcohol abuse, recent spine procedure, distant site
,27 of infection, diabetes, indwelling catheter, recent spine fracture, chronic renal failure, and cancer. Erythrocyte sedimentation rate is elevated (>20
,24,29,64  mm/h) in >95% of patients, and the C­reactive protein is elevated in >90% of patients. For all suspected spinal infections, contrast­enhanced
MRI is the gold standard imaging study. For detailed discussion, see Chapter 174, “Central Nervous System and Spinal Infections.”
Treatment of Spinal Infections
Evaluation of all spinal infections should occur initially with a spine surgeon. To better understand the approach that your surgeon may direct, we outline the general management of the various spinal infections. Epidural abscess requires antibiotics and emergent evaluation by a spine surgeon with surgical evacuation being a primary consideration. The treatment for diskitis is long­term antibiotics, with surgery reserved for those with spinal cord compression or biomechanical instability. The treatment for vertebral osteomyelitis is primarily medical, consisting of  weeks of IV antibiotics followed by a 4­ to 8­week course of oral antibiotics. Empiric antibiotic therapy should be directed against methicillin­resistant Staphylococcus aureus.
Parenteral piperacillin­tazobactam, .375 grams IV, and vancomycin,  gram IV, or similar agents with broad­spectrum coverage can be given until
,21,29 culture results are available.


