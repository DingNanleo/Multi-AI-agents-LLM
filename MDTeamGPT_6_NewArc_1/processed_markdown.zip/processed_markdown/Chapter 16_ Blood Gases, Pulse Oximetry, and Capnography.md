University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 16: Blood Gases, Pulse Oximetry, and Capnography
Casey M. Glass
Content Update: Oxygen Delivery Methods May 2020
New Table 16­1 summarizes estimated FiO with common delivery methods.

INTRODUCTION
Blood gases provide important clinical information for patients with respiratory disorders, compromised circulation, or abnormal metabolism. This chapter briefly reviews respiratory physiology to aid selection of assessment options and discusses appropriate use of arterial and venous blood gases and the advantages and limitations of noninvasive monitoring methods. The material focuses on the evaluation of oxygen and carbon dioxide levels; for information on carbon monoxide, please refer to Chapter 222, “Carbon Monoxide.”
RESPIRATORY PHYSIOLOGY
Several factors contribute to overall gas exchange in the lungs.
Each breath (tidal volume) moves air in and out of the alveolus for gas exchange but also moves air through large airways and nonperfused areas of lung, the physiologic dead space. The physiologic dead space is approximately 30% of the tidal volume. The air remaining in the chest at the end of exhalation is the functional residual capacity. Dead space and the functional residual capacity do not contribute to gas exchange. Minute ventilation is a product of the respiratory rate and tidal volume. Relatively small changes in the usable alveolar space require large increases in the minute ventilation to maintain the same rate of gas exchange. Raising the fraction of inspired oxygen (FIo ) or increasing the surface area or functional residual capacity of the lung can increase total alveolar oxygen content. Positive­pressure ventilation increases the functional residual capacity through recruitment of collapsed nonventilated alveolar space.
ESTIMATING OXYGEN DELIVERY
The FIo is the percentage of oxygen in each breath. At sea level, room air is 21% oxygen. As FIo increases, so does the alveolar concentration of oxygen (PAo ). Each liter per minute of oxygen flow delivered via nasal cannula increases the FIo by about 4%. Flow rates >4 L/min through a nasal cannula are poorly tolerated because of upper airway irritation, although some noninvasive devices can supply a higher FIo via nasal cannula. A simple mask provides an FIo of 35% to 50% at flow rates of  to  L/min. A nonrebreather mask with a reservoir can deliver near 100% FIo with a supply flow rate of  to 15L/min (Table 16­1).
Table 16­1
Typical Oxygen Delivery Methods
Oxygen Flow Delivered F IO2 Comments
Standard Nasal Cannula 2­6L/min 24­44% F approximate
IO2

High­Flow Nasal Oxygen up to 60L/min up to 100% Heated,humidified
Chapter 16: Blood Gases, Pulse Oximetry, and Capnography, Casey M. Glass 
. Terms of Use * Privacy Policy * Notice * Accessibility
Simple Face Mask 5­10L/min 35­50% F approximate
IO2
Venturi mask or equivalent 9­15L/min* 35­50% F more accurate
IO2
Non­rebreather mask 10­15L/min near 100% Mask fit essential
Abbreviation: FIO2 = fraction of inspired oxygen.
*Required flow rates vary by manufacturer. See individual device specifications.
The nature and severity of respiratory disorders can be estimated by comparing the measured arterial concentration of oxygen to the expected concentration of oxygen. The approximate arterial oxygen concentration (Pao ) values that are expected in normal persons who are inhaling various
 concentrations of oxygen are listed in Table 16­2. Table 16­2
Expected Pao in Patients Inhaling Various Concentrations of Oxygen (mm Hg)

Fraction of inspired oxygen .21 (room air) .4 .6 .8 .0
Expected Pao * (approximate) 105† 200 300 400 500

Abbreviation: Pao = partial pressure of arterial oxygen.

*Assuming a patient with normal lung function at sea level and a partial pressure of carbon dioxide (Pco ) of  mm Hg.

†Calculation demonstrates small overestimation using this technique.
The expected Pao from supplemental oxygen can be roughly estimated by multiplying the actual FIo by , the Five Times Rule. Thus, a patient
  getting 60% O would be expected to have a Pao of about  × , or 300 mm Hg. For every 1000­ft (305­m) rise in altitude, the atmospheric partial
  pressure of oxygen (Po ) drops about  mm Hg, and the arterial oxygen estimate would therefore be reduced by that value. The total alveolar oxygen
 pressure cannot be greater than atmospheric pressure. See Chapter 214, “Diving Disorders,” and Chapter 216, “High­Altitude Disorders,” for further discussion of oxygenation and ventilation at altitude and depth.
Cardiac output and the patient’s hemoglobin level are the biggest determinants of oxygen delivery to the tissues. Relatively little oxygen is dissolved in the plasma itself. Both hypoxia and anemia stimulate intrinsic mechanisms to increase cardiac output. If this is insufficient, increasing the hemoglobin level or oxygen saturation will improve the systemic delivery of oxygen. Based on survival data and the known complications of transfusions, the
 recommended threshold for transfusion in the absence of acute bleeding is .0 grams/dL (70 grams/L). See Chapter , “Approach to Traumatic
Shock,” and Chapter 238, “Transfusion Therapy,” for further discussion of transfusion indications. Therefore, in most clinical situations, increasing the oxygen saturation of existing hemoglobin is the fastest method to increase oxygen delivery.
ALVEOLAR GAS EXCHANGE
Once oxygen and carbon dioxide reach the lung, the gases diffuse across the interstitial space to either the red blood cell or alveolar space, respectively. The efficiency of diffusion depends on the distance across the alveolar­capillary membrane (interstitial space), the partial pressure of the gas in the alveolar space, and the solubility of the gas. Both oxygen and carbon dioxide are highly soluble, and carbon dioxide is  times more soluble than oxygen. As a result, increases in the distance across the interstitial space (as in pulmonary edema, for example) have a greater effect on oxygen diffusion than carbon dioxide diffusion. Gas diffusion requires functioning alveolar space, and conditions that damage the alveoli prevent effective oxygen and carbon dioxide transport. Additionally, the alveolar space must be perfused by the pulmonary circulation. When portions of lung are perfused but not ventilated (as in pneumonia) or ventilated but not perfused (as in pulmonary embolism), there is a ventilation­perfusion mismatch.
Either scenario may lead to hypoxemia, the first as deoxygenated blood passes through the nonfunctional lung and mixes with oxygenated blood in the left atrium, and the second when too little perfused lung is available for adequate oxygen loading.
The alveolar­arterial gradient or the PAo /FIo ratio can estimate the effectiveness of alveolar oxygenation. The alveolar­arterial gradient is the difference between the partial pressure of oxygen in the alveolar space (estimated from FIo at atmospheric pressure) and the measured partial pressure of the gas in an arterial blood gas sample. The following formula estimates the alveolar­arterial gradient [the P ]:(A­a)O2
P(A­a)O2=[FIo2(Patm−PH2O)−(PaCO2×1.25)]−Pao2
FIo is the fraction of oxygen in the inspired air (21% if room air), P is the atmospheric pressure (760 mm Hg at sea level), P is the vapor pressure atm H2O at body temperature (47 mm Hg), and Pa and Pao are the partial pressures of carbon dioxide and oxygen (respectively) from the patient’s blood= CO2  gas. A normal gradient for young adults is <15 mm Hg. The gradient increases with age and is estimated with the following formula: age/4 + . The Pao /FIo ratio correlates with the relative venous shunt across the pulmonary circulation and is calculated as the measured Pao divided by the FIo in decimal form. A healthy person on 40% oxygen would be expected to have a ratio of approximately 600, representing a normal physiologic shunt of approximately 5%. As the shunt increases, the ratio decreases. Table 16­3 illustrates the decrease in the Pao /FIo ratio with increasing physiologic shunt in hypothetical patients all receiving oxygen with an FIo of 40%.

Table 16­3
Interpretation of Pao

/FIo

Pao  (mm Hg) FIo  (mm Hg) Ratio QS/QT (%) Impairment of Oxygenation
240 .4 600  None
120 .4 300  Minimal
100 .4 250  Mild
 .4 200  Moderate
 .4 150  Severe*  .4 100  Very severe* Abbreviations: FIo

= fraction of inspired oxygen; Pao

= partial pressure of arterial oxygen; QS/QT = venous­arterial admixture (shunt).
*Ventilatory support and positive end­expiratory pressure to increase functional residual capacity and reduce the QS/QT to 15% should be considered.
The Pao /FIo ratio is the most frequently used parameter for evaluating the severity of lung failure and is included in the current definition for acute

,3 lung injury/acute respiratory distress syndrome. Carbon dioxide is transported by the red blood cells bound to hemoglobin and other proteins and dissolved in the plasma. Most carbon dioxide (60% to 70%) combines with plasma water to form carbonic acid, which dissociates into bicarbonate and hydrogen ions. Carbonic anhydrase in the erythrocyte catalyzes this near­instantaneous reaction. The deoxygenated hemoglobin is a willing receptor for released hydrogen ions. As hemoglobin is oxygenated in the lung, hydrogen ions are returned to the plasma, driving the reaction back toward the production of carbon dioxide.

ARTERIAL BLOOD GAS ANALYSIS
The amount of oxygen and carbon dioxide in the blood can be sampled and reported as the partial pressure of the gas. Blood gas analysis also typically includes a direct measurement of the serum pH and estimates of serum bicarbonate derived from the measured partial pressure of carbon dioxide
(Pco ) and pH (see Chapter , “Acid­Base Disorders”). Current tests often include other useful information such as direct measurement of lactic acid as lactate, total hemoglobin, and serum electrolytes.
An arterial blood sample is the reference standard for pH, oxygen, carbon dioxide, and lactate content providing a description of the oxygen and carbon dioxide content of the blood after leaving the pulmonary circulation and before any gas exchange in the peripheral tissues has occurred. In scenarios that require precise determination of these variables, an arterial sample is necessary.
Arterial blood gas samples are sometimes used for evaluation of serum hemoglobin and electrolytes. Blood gas analyzers typically have good concordance with the reference laboratory autoanalyzer; however, there may be clinically significant variances depending on the equipment involved,
4–8 especially for sodium, hemoglobin, and chloride. Results should be interpreted with caution when they are significantly abnormal.

VENOUS BLOOD GAS ANALYSIS
Venous samples may be either centrally or peripherally obtained. Mixed venous blood samples from the central circulation provide a source of information regarding the systemic uptake of oxygen and can be used to calculate cardiac output. The ideal sampling site for a systemic venous sample is at the pulmonary artery because blood from all body sites is equally represented, but such a sample is rarely practical. More commonly, blood is sampled from the superior vena cava or right atrium after placement of a central venous catheter. Blood from the superior vena cava disproportionally represents cerebral and upper body blood flow, but is generally useful for determining systemic oxygen uptake and lactic acid production. Peripherally obtained venous samples are widely used in emergency medicine, and they correlate with arterial values closely enough to be clinically useful.
9–11
Significantly abnormal values should be confirmed with an arterial sample.
Venous blood gases are commonly used to monitor serum pH and, in certain situations, may be an appropriate substitute to monitor Pco and serum lactate. When compared to arterial blood gases, the venous pH correlates closely such that most differences are not clinically significant (+/– .05 pH
4–6,12,13 units). Venous carbon dioxide values trend along with arterial carbon dioxide, although they vary somewhat (up to +/–  mm Hg). Normal venous carbon dioxide is predictive of normal Paco ; however, the clinical outcomes of substituting venous carbon dioxide for evaluation of,14 hypercarbia have not been described in the literature. Venous Pao values do not correlate with arterial oxygen content and cannot be used for evaluation of oxygenation.
Regular monitoring of the venous oxygen saturation at the superior vena cava (S o ) or right atrium (S o ) had been recommended as part of the cv  ra Surviving Sepsis Campaign, but a failure to demonstrate a benefit from this approach led to a removal of that recommendation in the 2016,16 guidelines. Measurement of the oxygen saturation from the superior vena cava may not accurately reflect the S o , and neither the S o nor the ra  cv S o may accurately reflect the mixed venous oxygen saturation at the pulmonary artery (S o ) for critically ill patients.ra  v Venous measurements of serum lactate are widely used for patient care, but most studies describing the clinical utility of serum lactate reference an arterial sample. Normal and markedly abnormal venous lactate values correlate with the arterial lactate, but mildly elevated venous lactate may not 18–22 correlate. In the latter case, if necessary, it may be wise to confirm the result with an arterial sample.

PULSE OXIMETRY
It is not possible to directly measure the arterial oxygen concentration by noninvasive means, and the standard bedside tool for estimating arterial oxygen saturation is the photometric pulse oximeter.
Pulse oximetry measures the relative absorption of oxygenated hemoglobin and deoxygenated hemoglobin and reports the percentage of oxygenated hemoglobin compared to the total. Pulse oximetry is fairly accurate, typically within 2% to 5% of the directly measured value performed at blood gas analysis. Importantly, the discrepancy between peripheral pulse oxygenation results and arterial gas saturation increases with hypoxia and poor circulation. Pulse oxygenation values greater than 92% are highly predictive of arterial saturations greater than 90%. Borderline normal pulse
 oxygenation values (between 88% and 92%) do not necessarily reflect normal arterial saturations and may overestimate arterial oxygen saturation.
23–25
The pulse oximeter becomes more inaccurate when arterial saturations range between 80% and 90%. Carbon monoxide also causes hemoglobin to conform to the saturated state and will cause a false elevation in measured saturation (see Chapter 222).
Pulse oximetry does not allow for determination of the partial pressure of oxygen in the arterial blood, which, in combination with total hemoglobin content, is the primary determinant of peripheral oxygen delivery. A basic understanding of the oxygen saturation/dissociation curve is essential for practicing clinicians when using pulse oximetry to guide clinical therapy (Figure 16­1). Most notably, arterial oxygen content declines precipitously when the oxygen saturation falls below 92%.
FIGURE 16­1
The oxyhemoglobin dissociation curve. This curve demonstrates the relationship of the partial pressure of oxygen (Po ) in the plasma to the saturation
 of hemoglobin molecules with oxygen (O ). The P is the Po at which hemoglobin is 50% saturated and correlates with Po of  mm Hg normally.

Normal mixed venous blood has an oxygen partial pressure (Pmvo ) of  mm Hg and an oxyhemoglobin saturation of 75%. A partial pressure of
 arterial oxygen (Pao ) of  mm Hg normally results in approximately 90% saturation of hemoglobin.

Studies of pulse oximetry typically use a finger­applied probe as the measurement site. Alternative locations such as the ear or forehead are used when it is difficult to obtain a reliable tracing from the patient’s finger. To date there is no definitive literature describing the accuracy of such measurements,
 although limited results suggest that probe locations on the head may be preferable to the extremities for patients with compromised perfusion.
CAPNOGRAPHY
Noninvasive techniques, direct transcutaneous measurement, cutaneous photometric measurement, or sampling of expired gases can easily estimate the carbon dioxide content of arterial blood. Of these, only sampling of expired gases is in common in the ED.
The carbon dioxide content of expired gases at the end of the expiration phase of respiration (Etco ) proportionally approximates the Paco content in healthy individuals, because carbon dioxide rapidly diffuses into the alveolar space, and arterial levels are typically only about  mm Hg higher than alveolar samples when pulmonary ventilation and perfusion are normal. The carbon dioxide content of the entire volume of expired gas can be photometrically assessed by means of a mainstream detector, or a sample of the expired gases can be aspirated from the airway via a side stream detector. Mainstream detectors are larger and must be inserted into the breathing circuit, either in a ventilator circuit or with the patient breathing through an occlusive mask or other tube. Side stream detectors are smaller and have the advantage of ease of use in nonintubated patients.
Interpretation of the capnogram is not necessarily intuitive. A summary of typical capnogram waveforms is described in Figure 16­2. 
Figure 16­2
End­tidal capnogram. Capnogram A depicts a normal capnogram with inspiratory baseline (V), expiratory upstroke (W), expiratory plateau (X), endtidal concentration (Y), and inspiratory downstroke (Z). Capnogram B represents apnea, which appears as serially decreasing end­tidal concentrations as little gas is expired. Capnogram C represents hypoventilation, which appears as an upward trend in the plateau and end­tidal concentration.Capnogram D represents rebreathing or air trapping, which appears as an increase in the baseline phase of the capnogram.

End­tidal carbon dioxide measurements (Petco ) do not accurately represent Paco . Mainstream and side stream sampling may each include air that has not been involved in the gas exchange process, either from physiologic dead space or from environmental air that enters the sample. In either case, the Petco value will be lower than the arterial value. These errors may be exacerbated in the setting of obstructive pulmonary disease due to incomplete expiration of gases secondary to air trapping. In a study of ED patients with chronic obstructive pulmonary disease, end­tidal measurements did not significantly vary from presentation to admission and were not clinically different for patients discharged home as compared to those requiring admission. Studies assessing the accuracy of Etco measurements compared to arterial sampling are mixed. In one study of patients presenting to the ED with undifferentiated dyspnea, mainstream Petco did correlate closely with Paco . In a comparison of healthy individuals, neither mainstream nor side stream sampling accurately predicted the arterial Pco . A convenience sample of ED patients with an indication for arterial blood gas did not have a close correlation of side stream Etco with the Paco . Notwithstanding these specific limitations, capnography enjoys a multitude of well­described applications in the emergency setting. It is most useful for identifying respiratory compromise in patients undergoing sedation, as hypoventilation appears in the capnogram long before the patient develops hypoxia. Colorimetric carbon dioxide detectors have been used for over a decade to help identify tracheal intubation. End­tidal capnography has also been studied extensively for identification of the return of spontaneous circulation in patients suffering cardiac arrest. Numerous other applications are described in the literature, and further discussion of them is beyond the scope of this chapter.


