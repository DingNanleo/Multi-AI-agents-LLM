## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 32: Hemodynamic Monitoring
Bachar Hamade; David T. Huang
INTRODUCTION
Hemodynamic monitoring can identify cardiovascular insufficiency and facilitate optimal treatment of the critically ill. Advanced techniques help sort through various causes of hemodynamic instability and enable tailored interventions.
We focus on techniques applicable in the ED: blood pressure monitoring, central venous pressure (CVP) monitoring, cardiac output (CO) monitoring,
 and blood oxygenation and lactate monitoring (Table 32­1). In practice, it is best to use more than one approach and monitor therapeutic responses.
TABLE 32­1
Hemodynamic Variables Obtainable in the ED
Hemodynamic Variable Method of Measurement
Blood pressure, mm Hg Sphygmomanometry, oscillometry, intra­arterial catheterization
Central venous pressure, mm Hg Jugular venous pulsation, ultrasonography
Cardiac output, L/min Transthoracic echocardiography, pulse contour analysis
Central venous oxygen saturation, % Central venous catheterization for venous blood sampling
Lactate, mmol/L Blood sampling
ARTERIAL BLOOD PRESSURE
Blood pressure is the force exerted by circulating blood through a blood vessel. Assessing arterial pressure is important, as hypotension implies tissue hypoperfusion. Hypotension is always pathologic and reflects a failure of normal circulatory homeostatic mechanisms. Shock is a state of organ hypoperfusion; while often present with hypotension, it can occur in the setting of normotension. For example, a patient in cardiogenic or hypovolemic shock may remain normotensive because of a marked increase in vascular resistance.
OPTIMAL BLOOD PRESSURE
Arterial pressure is the input pressure for organ perfusion and is a function of peripheral vascular resistance and blood flow. Mean arterial pressure
(MAP) is measured directly by indwelling catheter or estimated (see below). Organ perfusion pressure often becomes compromised as MAP decreases
,3 below  mm Hg.

Optimal MAP varies depending on the underlying cause of hemodynamic instability. In septic shock, many target a minimum MAP of  mm Hg, and
 increasing MAP beyond  mm Hg with fluids and vasopressors increases oxygen delivery but does not improve mortality. However, aiming for a
,6 higher MAP (75 to  mm Hg) may reduce kidney injury in patients with chronic hypertension.
DDeobwantelo eaxdiestds 2re0g2a5r­d7i­n1g 4w:4h7et Phe rY MoAuPr IoPr issy 1st3o6li.c1 4b2lo.1o5d9 p.r1e2s7sure is a better target in trauma patients. In patients with hemorrhagic shock,
Chapter 32: Hemodynamic Monitoring, Bachar Hamade; David T. Huang recommendations seek a systolic blood pressure of  to  mm Hg until major bleeding stops. This concept, called permissive hypotension, decreases
. Terms of Use * Privacy Policy * Notice * Accessibility
7­9 complications and improves outcomes in trauma patients in the preoperative period. The Brain Trauma Foundation recommends maintaining a systolic blood pressure greater than 110 mm Hg for patients with traumatic brain injury, with a minimum systolic blood pressure of 100 mm Hg for
 patients between the ages of  to  years. For patients in hemorrhagic shock with concomitant severe traumatic brain injury, maintain a MAP
 greater than  mm Hg.
NONINVASIVE BLOOD PRESSURE MEASUREMENT
Blood pressure varies with each heartbeat. The systolic pressure is the maximum pressure during ventricular ejection, and the diastolic pressure is the lowest pressure in the blood vessels between heartbeats during ventricular filling. The difference between systolic and diastolic pressures is the pulse pressure. Because the vascular circuit is elastic, both systolic and diastolic pressures vary throughout the vascular system. Systolic pressure can increase by up to  mm Hg, whereas the diastolic pressure similarly decreases as the pressure wave moves peripherally from the aorta. However, MAP
(Formula 1) varies by only  to  mm Hg, whether measured centrally or peripherally; in practice, estimate MAP using the sum of the diastolic pressure
 and one third of the pulse pressure (Formula 1).
Formula 1:
PALPATION
Traditional teaching is that the ability to palpate the radial, femoral, or carotid pulse represents a minimum systolic pressure of , , or  mm Hg,
,14 respectively. However, two small studies showed that these values generally overestimate the patient’s systolic blood pressure and are not
 included in the current ninth edition of the Advanced Trauma Life Support guidelines.
SPHYGMOMANOMETRY
Auscultation for blood pressure began with the invention of the sphygmomanometer by Scipione Riva­Rocci in 1896 and later refined by Nicolai
Korotkoff in 1905. The cuff is placed around the upper arm, and the bell is held over the brachial artery as the cuff is gradually inflated to at least  mm
Hg above the point where the radial artery sound disappears. During cuff deflation, the first tapping sound (Korotkoff sound) corresponds to the systolic pressure, while the disappearance of these sounds corresponds to the diastolic pressure. An inappropriately small cuff results in falsely elevated blood pressure measurements, and an inappropriately large cuff results in falsely low measurements.
Sphygmomanometric measurements of blood pressure often report slightly higher systolic pressure and lower diastolic pressure than those reported from simultaneous direct measurement using an intra­arterial catheter. This is because the reflected pressure waves summate with cuff inflation and increase systolic pressure, whereas the ischemic vasodilation downstream from the occluded cuff decreases cuff opening diastolic pressure. In normotensive patients, use the arm or leg for noninvasive blood pressure measurements; in critically ill and hypotensive patients, noninvasive arm
 measurements are usually temporizing while establishing arterial line access.
OSCILLOMETRY
Most automated blood pressure monitors use oscillometry. The device analyzes the amplitude of the fluctuations (or oscillations) in blood pressure in a sphygmomanometer cuff and converts it to a pressure measurement without the need for auscultation. With gradual deflation of the cuff, oscillations begin above systolic pressure. The point of maximum oscillation corresponds to MAP. Noninvasive measurements overestimate the systolic blood pressure compared to invasive arterial monitoring, but the calculated MAP shows better correlation and thus is more reliable in the
 critically ill patient.
INVASIVE BLOOD PRESSURE MEASUREMENT
The arterial catheter measures MAP and pulse pressure, estimates CO, and enables repeated blood sampling. The International Consensus
Conference for Hemodynamic Monitoring in Shock recommends invasive blood pressure monitoring for patients with refractory shock receiving
  vasoactive agents ; however, the use of arterial catheters in the intensive care unit alone does not improve mortality. Some argue that noninvasive
 measurements are sufficient even in patients with dysrhythmias or receiving vasopressors, deferring arterial catheter placement. Large randomized trials validating these postulations do not exist, and it is reasonable to avoid placing an arterial line in cases where hypotension is expected to be short term.
Placement of an intra­arterial catheter requires knowledge of the anatomic landmarks of the selected site. US guidance aids placement. The catheter insertion is either directly over a needle or over a guidewire (called the Seldinger technique). The Allen test, compression of both the ulnar and radial arteries with subsequent release of the ulnar artery pressure to see if “pink” returns, confirms collateral blood flow before radial artery catheterization; however, the test does not predict postcatheterization hand ischemia reliably. In patients with profound hypotension, a cutdown aids cannulation. After successful arterial catheterization, connect the catheter to the pressure transducer and look for an arterial waveform. The square wave flush test is applied to determine if artifacts in the tubing and recording system are damping the pressure measurements. See Figure 32­1 for the square wave flush test with intra­arterial blood pressure measurement.
FIGURE 32­1. Square wave flush test with intra­arterial blood pressure measurement. During a flush bolus of the catheter tubing, a square wave is observed. The number of oscillations after the square wave at the end of the bolus and prior to returning of the blood pressure tracing may result in an overestimation or underestimation of blood pressure.
An overdamped system suggests that air bubbles in the tubing are falsely lowering pressure measurements. An underdamped system will overestimate systolic pressure and underestimate diastolic pressure. Flushing the system should remove the air bubbles. If this does not fix the problem, replace the tubing.
CENTRAL VENOUS PRESSURE MONITORING
CVP is the back pressure to systemic venous return. Multiple factors contribute to the CVP value (Table 32­2).
TABLE 32­2
Contributors to Central Venous Pressure Values
Central venous blood volume
Venous return
Cardiac output
Total blood volume
Compliance of the central compartment
Vascular tone
Right ventricular compliance
Myocardial disease
Pericardial disease
Tamponade
Tricuspid valve disease
Stenosis
Regurgitation
Dysrhythmia
Junctional rhythm
Atrial fibrillation
Atrioventricular dissociation
Reference level of transducer
Positioning of patient
Intrathoracic pressure
Respiratory changes
Intermittent positive­pressure ventilation
Positive end­expiratory pressure
Tension pneumothorax
OPTIMAL CENTRAL VENOUS PRESSURE

CVP measurements range from  to  mm Hg in normal healthy individuals but are affected by multiple factors (Table 32­2). A single absolute CVP value helps most when it is very low (such as to exclude right heart failure in a patient with a normal MAP) or very high (such as to suggest right heart
 failure and/or volume overload). In general, a CVP less than  mm Hg in the hypotensive patient prompts fluid resuscitation with careful monitoring.
However, CVP measurements do not correlate with circulating blood volume or changes in blood volume.
Volume expansion in a healthy volunteer with normal diastolic compliance will immediately increase blood volume, whereas the CVP remains relatively normal. On the contrary, the same volume expansion in an elderly patient with cardiomyopathy, decreased diastolic compliance, and low circulating volume will elevate CVP (Figure 32­2).
FIGURE 32­2. Right ventricular end­diastolic volume versus central venous pressure (CVP) varies with cardiac compliance. The same volume (80 mL) may result in different CVP measurements depending on diastolic compliance. The letters A to D designate response after a small fluid bolus of same size in these groups.
Always measure CVP at end­expiration for both spontaneously breathing and mechanically ventilated patients. During spontaneous inspiration, the decreased intrathoracic pressure decreases transmural pressure in the heart, resulting in a decreased CVP. Conversely, intrathoracic pressure increases during an inspiratory breath of mechanical ventilation, resulting in an increase in CVP. Significant variation in inspiratory and expiratory CVP measurements suggests a compliant heart wall that will most likely respond to volume infusion. Conversely, the lack of respiratory variation in CVP may indicate that the heart is on the flat part of the cardiac function curve and will no longer respond to fluids.
NONINVASIVE CVP MEASUREMENT
JUGULAR VENOUS PULSATION
Observing internal jugular venous pulsation can estimate right atrial pressure. The sternal angle is roughly  cm above the center of the right atrium regardless of the patient’s position. With the patient sitting at a 45­degree angle, add  cm (distance from the sternal angle to the right atrium) to the vertical distance between the jugular pulsation and the sternal angle to estimate CVP in centimeters of water (cm H O). A pulsation greater than .5 cm
 vertically above the sternal angle when the patient is sitting at  degrees indicates a CVP of greater than .5 cm H O (Figure 32­3). In patients with

 heart failure, an elevated jugular venous pressure is independently associated with adverse outcomes, such as hospitalization and death.
Visualization of internal jugular vein pulsation is not always possible in obese or uncooperative patients.
FIGURE 32­3. Internal jugular venous pulsation as an estimate of central venous pressure (CVP; or right atrial pressure). With the patient’s head slightly turned to the left, shine a light tangentially in front of the neck to obtain a jugular shadow. The oscillations observed reflect the changing pressures within the right atrium and the various wave components of the CVP. The first elevation in the jugular pulse indicates the a­wave, or atrial contraction. The venous pressure is more accurately seen on the right side than the left because the right internal jugular vein has a more direct path to the right atrium. If the jugular pulse is higher than .5 cm at a 45­degree angle, it indicates an elevated CVP.
ULTRASONOGRAPHY
Ultrasonography is a valuable tool to visualize the neck veins for central venous catheterization. It can also be used to determine elevated jugular venous pressure and provide a noninvasive method for measuring CVP. Examine the right jugular vein using a high­frequency linear transducer (7 to 
MHz), looking for the site where the vein tapers, resembling the neck of a wine bottle. Measure the vertical distance in centimeters between this point of vein collapse and the sternal angle and add  cm to obtain a CVP measurement in cm H O.

When a distended jugular vein that is larger than the adjacent common carotid artery is seen in the transverse plane with the patient in a semi­upright position, then the estimated CVP is greater than  cm H O. A nearly collapsed internal jugular vein on the transverse view in the supine position
 indicates a very low CVP.
Similarly, CVP estimation using ultrasonography of the inferior vena cava (IVC) throughout the respiratory cycle is possible. An IVC that is small and
 measures less than  cm in diameter that has greater than 50% collapsibility with inspiration correlates to a CVP of less than  cm H O.

INVASIVE CENTRAL VENOUS PRESSURE MEASUREMENT
CVP monitoring uses a fluid­filled catheter inserted in the internal jugular or subclavian vein proximal to the right atrium. The distal tip sits in the superior vena cava. Indications for central venous catheterization include fluid and vasopressor administration, unsuccessful or inadequate peripheral venous access, central venous oxygenation (ScvO ) measurement, pulmonary artery catheterization, and transvenous pacemaker
 placement. Further details regarding central venous cannulation are provided in Chapter , “Vascular access.”
After successful catheter insertion, connect the catheter to a manometer or a pressure transducer of a monitor for continuous CVP waveform display.
Place the transducer at the level of the right atrium, approximately  cm below the sternal angle. An acceptable CVP waveform allows accurate measured values (Figure 32­4). The c­wave represents bulging of the tricuspid valve into the right atrium and occurs at the onset of systole. The base of the c­wave determines a CVP value because it is the final pressure in the ventricle before the onset of contraction, reflecting preload.
FIGURE 32­4. Central venous pressure (CVP) waveform and its relationship to the ECG. a = a­wave due to atrial contraction during diastole, which is absent in atrial fibrillation, but enlarged in tricuspid stenosis, pulmonary stenosis, and pulmonary hypertension; c = c­wave due to bulging of tricuspid valve back into the right atrium at the onset of systole; v = v­wave due to rise in atrial pressure from venous return through the vena cavae during systole and before the tricuspid valve opens at the onset of diastole, which is enlarged in tricuspid regurgitation; x = x­descent due to atrial relaxation; y = y­descent due to atrial emptying into the ventricle during diastole.
CARDIAC OUTPUT MONITORING
Oxygen delivery is a function of arterial oxygen content and CO. Perfusion pressure is the most important driving force determining regional blood flow, which in the aggregate defines CO. Because the primary goal of resuscitation from shock is to reverse tissue hypoperfusion, CO is an ideal indicator of perfusion and oxygen delivery. There is no absolute level of normal CO in the unstable, metabolically active patient because CO is proportional to metabolic demand.
OPTIMAL CARDIAC OUTPUT AND DETERMINING FLUID RESPONSIVENESS

CO is the product of heart rate and stroke volume. Fluid, or volume responsiveness, is the response of stroke volume to fluid loading. Traditionally,
Starling’s law (Figure 32­5) guided resuscitation care, with an increase in CO of greater than 15% after a fluid challenge identifying fluid
 responsiveness.
FIGURE 32­5. Starling cardiac function curve illustrating the effects of increased preload on cardiac output. As illustrated in the Starling cardiac function curve, the first increase in preload (from A to B) results in a large increase in cardiac output (Δ) as the cardiovascular system operates in the “preload­dependent” portion of the curve. The second increase in preload (from B to C) only results in a small increase in cardiac output (δ), and further increase in preload
(from C to D) does not yield any increase in cardiac output as the cardiovascular system is now considered “volume resuscitated” or preload independent.
VOLUME RESPONSIVENESS IN SPONTANEOUSLY BREATHING PATIENTS
Volume responsiveness in spontaneously breathing patients may be assessed by passive leg raising. Postural changes transiently increase venous return when the legs are raised to  degrees above the chest and held for  minute. This maneuver approximates giving a 300­mL blood bolus to a 70­ kg patient. Changes in heart rate, blood pressure, CVP, or CO persist for approximately  to  minutes after passive leg raising. The dynamic increases in CO induced by passive leg raising are as sensitive and specific to predicting volume responsiveness as pulse pressure variation during positive­
 pressure mechanical ventilation.
US also assesses volume responsiveness in the spontaneously breathing patient. As described in the earlier section on CVP, a small­caliber (<2 cm diameter) IVC with low minimal respiratory variation correlates with a low CVP and potentially a hypovolemic state. Assess IVC diameter before and
 after fluid bolus, or look for little IVC changes with respiratory variation to identify fluid responsiveness.
VOLUME RESPONSIVENESS IN MECHANICALLY VENTILATED PATIENTS
Respiratory variations in blood pressure may aid in assessing volume status in the mechanically ventilated patient. Positive­pressure mechanical ventilation alters venous return and induces several predictable cyclic changes in vena caval diameters, pulmonary blood flow, and left ventricular
 output (Figure 32­6). This phasic variation in stroke volume results in arterial pressure variation, defined as the cyclic fluctuation in arterial pressure with a phase length equal to the respiratory rate. This variation in arterial pressure is a variation in the pulse pressure, defined by the
 difference between maximal and minimal pulse pressure values divided by the mean pulse pressure over one respiratory cycle. In the volumeresponsive patient, increasing intrathoracic pressure during positive­pressure inspiration decreases venous return, and thus preload. A pulse
 pressure variation greater than 13% predicts a greater than 15% increase in CO in response to a 500­mL crystalloid bolus.
FIGURE 32­6. Pulse pressure variation (PPV) on positive­pressure mechanical ventilation. PPV is defined as the maximal pulse pressure (PP ) during inspiration
Max minus the minimum pulse pressure (PP ) during expiration, divided by the average of these two pressures. P = arterial pressure; P = airway
Min A AW pressure. [Reproduced with permission from Gunn SR, Pinsky MR: Implications of arterial pressure variation in patients in the intensive care unit. Curr
Opin Crit Care 7: 212, 2001. Lippincott Williams & Wilkins, Inc. Copyright Wolters Kluwer Health.]
Fluid administration continued until the pulse pressure variation between inspiration and expiration decreases to less than 10% may improve
,31  outcomes. Because arterial pressure is directly proportional to stroke volume, stroke volume variation strongly predicts fluid responsiveness.
However, the patient must be breathing in synchrony with the positive­pressure mechanical breaths and without vigorous spontaneous breathing or dysrhythmia for stroke volume variation to be accurate. This technique aids assessing volume responsiveness in the sedated and ventilated patient.
Similar to the spontaneously breathing patient, US helps assess volume responsiveness in the mechanically ventilated patient with a few caveats. In mechanically ventilated patients, the IVC is less compliant and more distended throughout the respiratory cycle, and the dynamics reverse in comparison to spontaneous ventilation: the IVC expands on inspiration and collapses on expiration. Despite these limitations, an increase in IVC
 diameter with fluid administration seen with US over time reflects fluid responsiveness.
NONINVASIVE CARDIAC OUTPUT MEASUREMENT
Minimally invasive or noninvasive hemodynamic monitoring techniques to measure CO in the ED setting include transthoracic echocardiography and pulse contour waveform analysis.
TRANSTHORACIC ECHOCARDIOGRAPHY
,33­35
Transthoracic echocardiography is an accurate tool to estimate CO in the critically ill patient recommended by the American Society of

Echocardiography. Using the parasternal long axis to measure the left ventricular outflow tract diameter and pulse wave Doppler in the apical four­
 chamber view to measure stroke volume from the left ventricular outflow tract, one can reliably estimate CO.
PULSE CONTOUR ANALYSIS
Several minimally invasive hemodynamic monitoring devices can be easily used in the ED. Most common are devices using pulse contour analysis that quantify CO, stroke volume, and stroke volume or pulse pressure variation to help guide resuscitation. The devices require placement of an indwelling arterial catheter and a central venous catheter to obtain CVP measurement and derive systemic vascular resistance. These devices require a mechanically ventilated patient with a set tidal volume of  mL/kg. Also, because these devices rely on pulse contour analysis as the primary means of

CO measurement, they cannot be used in the presence of cardiac dysrhythmias (e.g., atrial fibrillation) or mechanical circulatory devices.
INVASIVE CO MEASUREMENT
CO is measured invasively with pulmonary artery catheterization and the thermodilution method. The benefit of using the pulmonary artery catheter for hemodynamic monitoring in the ED setting is understudied. Current expert consensus does not recommend the routine use of the pulmonary
,38 artery catheter in the management of the critically ill patient. For this reason, pulmonary artery catheterization is usually avoided in the ED.
ORGAN OXYGENATION AND PERFUSION MONITORING
Blood pressure, CVP, and CO serve as macrohemodynamic parameters. Venous oxygen saturation and blood lactate level help to indirectly assess tissue oxygenation or perfusion.
CENTRAL VENOUS OXYGEN SATURATION
Venous oxygen saturation monitoring assesses the relationship between tissue oxygen extraction, oxygen delivery, and oxygen consumption, with low values reflecting inadequate delivery and/or excessive consumption. It is ideally measured in the pulmonary artery as a mixed venous sample (SmVO );
 however, this is impractical in the ED, and central venous oxygen saturation (ScvO ) measured from the internal jugular or subclavian veins acts as a
 surrogate. A normal oxygen extraction ratio of 25% to 35% results in a venousoxygen delivery (reflected in venous oxygen saturation) of approximately
70% of arterial oxygen delivery.
In healthy individuals, ScvO is 2% to 3% less than SmVO ; in shock states, ScvO is typically 5% to 10% higher than SmVO as blood flow is redistributed

 from the abdominal vascular beds to the cerebral and coronary circulation. Although absolute values of ScvO and SmVO may be different, low
  values of either measurement reflect an imbalance in oxygen transport and portend worse outcomes. Most important, the two measures typically
 change in parallel and thus trends in ScvO closely reflect trends in SmVO .

Clinical Use of Central Venous Oxygen Saturation
The principal value of ScvO is to detect occult inadequate oxygen delivery. Regardless of the underlying pathophysiologic state (e.g., heart failure,
 septic shock, trauma), a low ScvO value represents inadequate oxygen delivery relative to oxygen consumption, which can be due to inadequate
 delivery due to hypoxemia, anemia, or impaired CO (low contractility, hypovolemia, or tamponade) and/or increased oxygen consumption due to increased metabolic demand (Table 32­3).
TABLE 32­3
Contributors to Abnormal Central Venous Oxygen Saturation (ScvO2 )
Low ScvO2 (<70%) High ScvO2 (>70%)
Low DO2 High V̇O2 High DO2 Low V̇O2
Hypoxia, suctioning (low SaO2 ) Exercise Hyperoxia (high FIO2 ) Hypothermia
Anemia, hemorrhage (low Hgb) Pain Erythrocytosis (high Anesthesia, pharmacologic paralysis
Hgb)
Cardiac dysfunction, hypovolemia, shock, Hyperthermia, shivering, Hyperdynamic state Arteriovenous shunting, mitochondria defect, arrhythmia (low CO) seizure (high CO) terminal shock
Note: Determining the causes of and treating a low or high ScvO2 clinical state involves troubleshooting for conditions resulting in abnormal oxygen delivery (DO2 ) and oxygenconsumption (V̇O2 ).
Abbreviations: CO = cardiac output; FIO2 = fraction of inspired oxygen; Hgb = hemoglobin; SaO2 = arterial oxygen saturation.
Normal (approximately 70%) or high ScvO values do not necessarily mean that the patient is well. ScvO is a global measure of oxygen transport, and
  regional areas of tissue hypoperfusion can exist with normal ScvO values, particularly in the lower half of the body. In several disease states (e.g.,
 hypothermia, terminal shock, cyanide poisoning), tissues oxygen extraction from the blood is impaired, leading to “arterialization” of the venous blood with high ScvO . Routine measuring of ScvO in sepsis is not recommended, but if a central venous catheter is in place, obtaining a single ScvO
   measurement is reasonable. A low ScvO is always abnormal.

LACTATE
In critical illness, an oxygen debt develops when oxygen delivery is inadequate to meet tissue demand and compensatory mechanisms are exhausted.
This results in global tissue hypoxia, anaerobic metabolism, and lactate production. High lactate is a prognostic marker in critically ill patients with
 various forms of shock, known since the 1800s. This type of acidosis due to anaerobic metabolism is called type A lactic acidosis.
In addition to shock, other causes of elevated lactate include seizure, diabetic ketoacidosis, malignancy, thiamine deficiency, malaria, human immunodeficiency virus infection, carbon monoxide or cyanide poisoning, and mitochondrial myopathies. Commonly used drugs, such as albuterol,
 propofol, metformin, simvastatin, lactulose, antiretrovirals, niacin, isoniazid, and linezolid, can also cause a lactate elevation. This type of acidosis is
 called type B lactic acidosis and is not due to hypoperfusion. However, all lactic acidosis is associated with poor outcome, and types A and B lactic acidosis can both be present. It is key to understand that not all lactic acidosis is due to hypoperfusion, and fluid administration is based on the global assessment, not just lactate value.
Blood lactate concentrations also reflect the interaction between its production and elimination. During critical illness, a patient with hepatic dysfunction may have a higher lactate level compared with another patient without liver disease due to impaired hepatic clearance. Lactate elevation in a patient with chronic liver disease still portends a poor prognosis, because patients with liver disease do not have a high lactate level in the absence of
 shock.
Hyperlactatemia is not always accompanied by hypotension or a low bicarbonate level and/or elevated anion gap. Most recently, a blood lactate level
≥2 mmol/L became part of the new definition of septic shock,  and an elevated lactate level in a normotensive patient requires further attention
 because a continued increase in lactate levels is associated with increased mortality. Lactate clearance (a drop of at least 25% within  hours of an
 initial elevated level) in patients with septic shock is associated with increased 60­day survival. When lactic acidosis accompanies low­flow disease
 states such as sepsis, mortality increases by almost threefold; thus, all lactic acidosis should be alarming to the emergency physician.


