## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 291: Eating Disorders
Gemma C. L. Bornick
INTRODUCTION AND EPIDEMIOLOGY
Eating disorders, such as anorexia nervosa, bulimia nervosa, and binge eating disorder, are psychological conditions characterized by a pathologic relationship with food that adversely affects psychosocial functioning. Eating disorders can be challenging in the ED because physical manifestations may be subtle and historical features may not be elicited unless a disorder is suspected from medical complications. The fifth edition of the Diagnostic
 and Statistical Manual of Mental Disorders refines the diagnostic criteria of eating disorders from the previous edition (Table 291­1).
TABLE 291­1
Diagnostic and Statistical Manual of Mental Disorders, Fifth Edition, Criteria for Eating Disorders
Anorexia Nervosa Bulimia Nervosa Binge Eating Disorder
Restriction of caloric intake relative to Recurrent episodes of binge eating characterized Recurrent episodes of binge eating characterized requirements, leading to a lower than expected by both: by both: body weight in the context of age, sex, Eating in a discrete time period an amount Eating in a discrete time period an amount development, and physical health (<85% of food that is larger than most people of food that is larger than most people predicted) would eat in the same period under the would eat in the same period of time under same circumstance the same circumstance
A feeling of lack of control over eating A feeling of lack of control over eating during an episode during an episode
Fear of weight gain or becoming fat, despite Recurrent, inappropriate compensatory The episodes are associated with three of the lower than predicted body weight behaviors to prevent weight gain including self­ following: induced emesis; abuse of laxatives, diuretics, or Eating much more quickly than normal other medications; caloric restriction; or Eating until feeling uncomfortably full or excessive exercise overfull
Eating large amounts of food even when not feeling hungry
Eating alone because of embarrassment about how much one is eating
. Feeling disgusted, depressed, or guilty afterward
Derangement in the way the patient’s body Bingeing and purging at least  time a week for  The patient exhibits marked distress regarding weight or appearance is experienced, undue weeks binge eating.
effects of body weight on self­evaluation, or denial of the dangerousness of the current low Self­evaluation is unduly influenced by body The binge eating occurs at least  time a week for body weight weight and appearance  months.
The disturbance does not occur exclusively The binge eating is not associated with
 during episodes of anorexia inappropriate compensatory behavior and does
Chapter 291: Eating Disorders, Gemma C. L. Bornick not occur exclusively during the course of
. Terms of Use * Privacy Policy * Notice * Accessibility anorexia, bulimia, or avoidant/restrictive food intake disorder.
Source: Data from American Psychiatric Association: Diagnostic and Statistical Manual of Mental Disorders: DSM­5, 5th ed. Washington, DC: American Psychiatric
Association; 2013. 
There are two subtypes of anorexia nervosa: restrictive and binge/purge, with crossover between the two. Restrictive patients minimize their food intake, whereas those with bingeing/purging make up for unacceptable food intake with diuretics, laxatives, enemas, or vomiting. There are also two subtypes of bulimia: purging and nonpurging. Those who purge do so by the above methods; those classified as nonpurging use other compensatory
 methods such as fasting or excessive exercise. Up to 50% of anorexia patients develop bulimia. Binge eating disorder is characterized by habitual, recurrent binge consumption episodes that cause significant distress. This is distinct from simple episodic overeating and must be both independent of anorexia or bulimia and free of compensatory mechanisms. The Diagnostic and Statistical Manual of Mental Disorders, fifth edition, also defines avoidant/restrictive food intake disorder, pica, and rumination disorder, which are not addressed here.
,5
Anorexia nervosa has an estimated lifetime prevalence of .9% in women and .3% in men, and median age of onset is  years old. Bulimia
 nervosa has an estimated lifetime prevalence of .5% in women and .5% in men, and median age at onset is also  years old. Binge eating disorder is more common in older individuals and males than both anorexia and bulimia, with a lifetime prevalence of .5% in women and .0% in
,5 men.
PATHOPHYSIOLOGY
,7
There is evidence that eating disorders run in families, possibly due to both genetic influences and similar underlying temperaments and behaviors.

For example, genetic locus (rs4622308) on chromosome  is associated with anorexia nervosa. MRI studies detect differences in brain behavior and
9­12 structure, and some implicate brain regions involved in reward processing.
CLINICAL FEATURES
HISTORY
Patients with eating disorders often present to the ED with vague signs and symptoms such as weakness, fatigue, pallor, dizziness, syncope, confusion,
 bloating, edema, or persistent nausea. Complaints may otherwise be due to medical complications, such as chest pain and hematemesis caused by a
Mallory­Weiss tear from purging; palpitations from dysrhythmias; dysmenorrhea from disruption of the hypothalamic­pituitary axis; or fractures from
,15 osteoporosis. Depression, anxiety, substance abuse, self­injurious behavior, or suicidality may coexist. Therefore, if an eating disorder is suspected, consider screening for depression and suicidality.
If clinical suspicion is raised for an eating disorder based on complaint cluster, physical examination, or family report, explore a more focused history.
Important data points to elicit include eating and dieting behavior; desire for weight loss; typical daily dietary intake; presence of calorie counting; compensatory exercise behavior; guilt patterns following eating; menstruation pattern; and use of over­the­counter dietary supplements or laxative agents. Certain sensitive history points may be difficult to elicit in the ED, such as early childhood GI issues or picky eating or obesity, self­esteem issues, societal thinness pressures, teasing, propensity toward perfectionism, or sexual abuse. Certain physical activities raise risk for eating disorders,
16­18 such as gymnastics, ballet and other dance, wrestling, swimming, and cross­country running. Because eating disorders are characterized by denial
 of symptoms and behaviors, take a nonjudgmental approach to encourage trust and truthful disclosure.
PHYSICAL EXAMINATION
Patients with anorexia are typically easily identifiable based on a very thin body habitus. Other signs include hypotension (resting or orthostatic), bradycardia or tachydysrhythmia, heart murmur and S “click” of mitral valve prolapse, or hypothermia. Patients may also exhibit signs of vitamin
 deficiencies such as brittle, flaking, or ridged nails (nonspecific malnutrition); stomatitis or cheilitis (B vitamin deficiency); or perifollicular petechiae
(scurvy). They may also develop fine, long hair on the arms and face, acral cyanosis (impaired thermoregulation), and/or pretibial edema secondary to
  malnutrition. Nonsuicidal self­injury is also common, and stigmata of cutting, picking, burning, or bruising may be present.
Patients with bulimia or binge eating disorder can be difficult to detect in the ED because they tend to be normal weight or overweight. Consider eating disorder diagnoses in the presence of other physical indicators, even in normal weight or overweight patients. Self­induced vomiting can cause painless hypertrophy of the parotid glands (sialadenosis), dental erosion, and trauma or callus formation to the dorsal hands

(Russell’s sign), as well as pharyngeal erythema or abrasions, gingivitis, facial petechiae or subconjunctival hemorrhage, and halitosis. Laxative abuse may cause peripheral edema, anal fissures, hemorrhoids, perianal dermatitis, and rectal bleeding. Patients with binge eating disorder will likely have no abnormalities apparent on physical examination.
DISEASE COMPLICATIONS
Eating disorders can be life threatening. Death by suicide is six and four times more common in patients with anorexia and bulimia, respectively,
 than in the general population. Medical complications are typically more severe in anorexia than in bulimia or binge eating. Complications of
  anorexia are generally directly due to malnutrition and can account for a large proportion of deaths. Bulimia medical complications are usually
 related to method and frequency of purging and are often the result of chemical derangements or structural damage to the GI tract. Patients with
 binge eating disorder describe significantly more somatic symptoms than the general population, but true medical complications are rare.
Cardiopulmonary Complications

Among the most deadly of the eating disorder complications in anorexia are structural and functional changes to the cardiovascular system.
Malnutrition causes decreased cardiac muscle mass and increased vagal tone. This leads to decreased contractility and cardiac output and, therefore,
 results in hypotension, bradycardia, and orthostasis. Relative decreases in cardiac muscle mass can lead to the development of mitral valve prolapse.

Rarely, patients with anorexia nervosa can develop myocardial fibrosis or pericardial effusion, which in a few cases has led to cardiac tamponade
 requiring pericardiocentesis. Syrup of ipecac, used as an emetogenic, is directly cardiotoxic and can cause an irreversible cardiomyopathy.
Prolongation of the QT interval on ECG has been described, but this is rare in the absence of electrolyte disturbance or congenital long QT syndrome
 and should prompt evaluation for these conditions. Increased QT dispersion (difference between maximum and minimum QT intervals seen in each
 lead of a single ECG) indicates heterogeneous ventricular depolarization and is a marker for increased arrhythmic risk. QT derangements as a result of eating disorders are reversed by adequate refeeding. QT resolution is associated with normalization of heart rate, heart rate variability, and exercise
  tolerance and, therefore, has been used as a marker to guide rehabilitation. Most other cardiac sequelae are also reversible with appropriate
,33 weight gain, but there is increased risk of cardiac complications during the first week of refeeding after severe nutrient depletion. Cardiac
,34 complications are only rarely seen in patients with bulimia nervosa or binge eating disorder.
Pulmonary Complications
,36
Anorexia can lead to weakness of respiratory muscles, decreased pulmonary and aerobic capacity, and aspiration due to pharyngeal muscle
 weakness. Aspiration pneumonitis and subsequent pneumonia can occur as a result of pharyngeal muscle weakness and from chronic purging.

There are case reports of pneumothorax and pneumomediastinum. Patients with bulimia and binge eating disorder are often smokers and may have
 pulmonary complications related to smoking.
GI Complications
Patients with anorexia are at increased risk of constipation, gastroparesis, acute gastric dilatation, gastroesophageal reflux, and acute
,40,41 pancreatitis. Gastroesophageal reflux and laryngopharyngeal reflux commonly occur in patients with bulimia or purging­type anorexia and may
,42  result in hoarseness or dysphagia. Forceful vomiting can result in Mallory­Weiss tears or, rarely, Boerhaave syndrome. Chronic stimulant laxative
43­45 abuse can lead to development of ileus, rectal prolapse, melanosis coli, or the cathartic colon syndrome.
Nutritional Complications
The proportion of eating disorder patients with vitamin deficiencies is difficult to determine because many take supplements. Decreased bone mineral
 density and skeletal fragility are common but are not associated with decreased vitamin D levels. Iron and vitamin B deficiencies can lead to anemia
 in severely food­restrictive patients but are uncommon. Skin erythema and pruritus with sun exposure, glossitis, epidermal desquamation, and
 diarrhea should raise suspicion of pellagra. Confusion, confabulation, ataxia, ophthalmoplegia, and/or nystagmus suggest Wernicke­Korsakoff encephalopathy. Other vitamin deficiencies reported in association with eating disorders include wet beriberi and scurvy, although these are
,49   extremely rare. Poor nutritional state can result in hypoplastic or aplastic bone marrow and resultant cytopenias.
Renal and Electrolyte Complications
Electrolyte derangements and other lab abnormalities are more common in purging­type eating disorders. Patients with restrictive­type anorexia may not demonstrate any laboratory abnormalities. Frequent vomiting can result in metabolic alkalosis, hyponatremia, and hypochloremia. Laxative and diuretic abuse and vomiting can lead to potassium and magnesium depletion. Hyponatremia may also develop in patients who abuse diuretics. Signs
,22,52,53 of starvation ketosis may be evident. In patients with very severe anorexia, hypoglycemia and hypophosphatemia can develop.
Refeeding following prolonged nutrient depletion can also cause electrolyte abnormalities, most commonly hypokalemia, hypophosphatemia, and hypomagnesemia, due to redistribution of electrolytes from the extracellular to the intracellular space triggered by insulin release and from depletion
 of phosphorus during protein synthesis. This can lead to arrhythmias, congestive heart failure, pericardial effusions, and cardiac arrest.
Endocrine Complications
Profound food restriction affects the hypothalamic­pituitary axis. Low levels of gonadotropins, loss of the normal pulsatile waves of luteinizing
 hormone, and estrogen deficiency lead to hypothalamic amenorrhea. Anorexia is also associated with the “euthyroid sick syndrome” in which thyroid­stimulating hormone is normal or slightly low, T is low, and sometimes T levels are also decreased. Thyroid deficiencies likely contribute to
  the bradycardia, orthostasis, and hypothermia in anorexia. High cortisol levels and low levels of insulin­like growth factor  (somatomedin C), T ,

 estradiol, and testosterone contribute to loss of bone mass. Refeeding and recovery from illness do not fully return bone mass to normal levels, and
 patients with anorexia remain at an increased risk of fracture for many years following initial diagnosis. The endocrine effects of bulimia and binge eating disorder are less well studied. Bulimia is associated with both type  and type  diabetes mellitus. There is some evidence to support an
,57 increased risk of dyslipidemia, glucose dysregulation, and diabetes in binge eating disorder. Repeated vomiting can lead to metabolic alkalosis,
 hypokalemia, and increased aldosterone secretion—a cluster described as pseudo­Bartter syndrome.
DIAGNOSIS
Diagnostic criteria are outlined in the fifth edition of the Diagnostic and Statistical Manual of Mental Disorders, but screening tools are more practical for presumptive diagnosis in the ED. The SCOFF Questionnaire (Table 291­2) is useful for screening for anorexia and bulimia in a brief encounter
 and can be remembered by its acronym: Sick, Control, One stone, Fat, Food. Other screening tools, such as the Eating Disorder Diagnostic Scale or
,61 the Eating Attitudes Test, are more extensive and are more useful in a primary care setting. The Questionnaire on Eating and Weight Patterns–

Revised is specific for binge eating disorder.
It is very important to search for, diagnose, and treat organic pathology as part of the assessment of a patient with a potential eating disorder (Table
291­3).
TABLE 291­2
SCOFF Questionnaire
Do you make yourself sick because you feel uncomfortably full?
Do you worry you have lost control over how much you eat?
Have you recently lost more than  stone (14 lb) in a 3­month period?
Do you believe yourself to be fat when others say you are too thin?
Would you say that food dominates your life?
Note: A score of  or more indicates a probable eating disorder with a sensitivity of .6% and a specificity of .6%.
Source: Reproduced with permission from Morgan JF, Reid F, Lacey JH: The SCOFF questionnaire: a new screening tool for eating disorders. West J Med
2000;172(3):164­165. TABLE 291­3
Differential Diagnosis of New­Onset Eating Disorders
Endocrine Adrenal insufficiency
Hyperthyroidism
Diabetes
GI Hepatitis
Pancreatitis
Celiac disease
Inflammatory bowel disease
Superior mesenteric artery syndrome
Infectious disease Mononucleosis
Human immunodeficiency virus
Tuberculosis
Cancer Nervous system malignancy
Ovarian malignancy
Intra­abdominal malignancy
Pregnancy Hyperemesis gravidarum
Psychiatric Substance abuse
Major depressive disorder
Bipolar disorder
Schizophrenia
Inborn error of metabolism Mitochondrial disorders
Enzyme deficiency
LABORATORY TESTING
Initial testing should include an ECG and a full chemistry panel including magnesium, calcium, and phosphorus; CBC; urinalysis; pregnancy test;
 hepatic function panel; serum albumin; lipase and amylase; and thyroid­stimulating hormone.
IMAGING
Obtain imaging only to rule out an underlying organic cause of presenting symptoms or to exclude medical complications. Nonspecific radiographic
  findings in patients with anorexia may include decreased muscle mass, paucity of subcutaneous fat, mild small bowel dilatation, and osteoporosis.
There are no specific radiographic findings diagnostic of binge eating disorder or bulimia, but a swallowed toothbrush or similar item suggests
 purging by induced vomiting.
TREATMENT AND DISPOSITION
The ED treatment of eating disorders is limited to stabilization of urgent medical complications, followed by hospital admission or outpatient referral
,67 to a mental health specialist. Tables 291­4 and 291­5 list guidelines for hospital admission. Most medical complications of anorexia nervosa can
252 be treated in an outpatient setting if the patient’s weight is >70% of ideal body weight or body mass index is >15 kg/m . Long­term treatment of all
 eating disorders requires a multidisciplinary approach, including psychotherapy, dietary interventions, and pharmacotherapy in certain cases. If pharmacotherapy is indicated, it should be initiated by a psychiatrist or primary care provider.
TABLE 291­4
Society of Adolescent Medicine Criteria for Hospital Admission
Anorexia Nervosa Bulimia Nervosa
Body weight <75% of ideal for age, sex, and height Potassium <3.2 mmol/L
Daytime heart rate <50 beats/min or nighttime heart rate <45 beats/min Chloride <88 mmol/L
Body fat <10% of body weight Esophageal trauma and hematemesis
Dehydration Vomiting unresponsive to antiemetics
Cardiac arrhythmia including QT prolongation Dehydration
Temperature <96°F Cardiac arrhythmia including QT prolongation
Orthostasis and syncope Temperature <96°F
Acute psychiatric emergencies such as hallucinations or suicidality Orthostasis and syncope
Systolic blood pressure <90 mm Hg Acute psychiatric emergencies such as hallucinations or suicidality
Ongoing weight loss despite outpatient treatment Ongoing purging despite outpatient treatment
TABLE 291­5
American Psychiatric Association Criteria for Hospital Admission
Medical status Adults: heart rate <40 beats/min, blood pressure <90/60 mm Hg, glucose <60 milligrams/dL (<3.3 mmol/L), potassium <3 mEq/L, temperature <97.0°F, end­organ compromise requiring acute treatment, poorly controlled diabetes
Children: heart rate near  beats/min, orthostasis, blood pressure <80/50 mm Hg, hypokalemia, hypophosphatemia, hypomagnesemia
Suicidality Specific plan with high lethality or intent
Weight Generally <85% of ideal body weight or acute weight change with food refusal
Motivation to Very poor motivation; patient preoccupied with intrusive repetitive thoughts and/or uncooperative with treatment recover
Comorbid Any existing psychiatric disorder requiring hospitalization disorders
Structure Needs supervision to ensure caloric intake, prevention of exercise, or prevention of purging behaviors required
Environmental Severe family conflict or absence of family, absence of appropriate outpatient resources in patient’s geographic region
SPECIAL POPULATIONS
PREGNANT WOMEN
Pregnancy can be a stressful time for a woman with an eating disorder, particularly with respect to maintaining adequate weight gain. There are conflicting data on whether the presence of eating disorders increases the risk of complications. The broadest study of its kind revealed that the majority of patients with anorexia and bulimia have normal pregnancies and healthy babies with, however, an increased risk of birth by cesarean section and an increased risk of postpartum depression. These differences remained between groups who had active symptoms and those with
 history of an eating disorder who were asymptomatic during pregnancy.
MEN

Do not neglect the possibility of eating disorders in men. Men may account for between 10% and 25% of cases of anorexia and bulimia, and binge eating is more prevalent in men than both anorexia and bulimia. The exact proportion of men with eating disorders is unknown because men are less likely to be diagnosed. Eating disorders in males are typically characterized by the drive to add muscle bulk and lean mass and are often associated with antecedent obesity, athletic performance concerns, bullying, and occasionally (but not always) sexual abuse. Men with eating disorders are more
 likely to abuse steroids and growth hormones, particularly when muscle dysmorphia is present.


## Page 2

Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 291: Eating Disorders
Gemma C. L. Bornick
INTRODUCTION AND EPIDEMIOLOGY
Eating disorders, such as anorexia nervosa, bulimia nervosa, and binge eating disorder, are psychological conditions characterized by a pathologic
University of Pittsburgh relationship with food that adversely affects psychosocial functioning. Eating disorders can be challenging in the ED because physical manifestations
Access Provided by: may be subtle and historical features may not be elicited unless a disorder is suspected from medical complications. The fifth edition of the Diagnostic
 and Statistical Manual of Mental Disorders refines the diagnostic criteria of eating disorders from the previous edition (Table 291­1).
TABLE 291­1
Diagnostic and Statistical Manual of Mental Disorders, Fifth Edition, Criteria for Eating Disorders
Anorexia Nervosa Bulimia Nervosa Binge Eating Disorder
Restriction of caloric intake relative to Recurrent episodes of binge eating characterized Recurrent episodes of binge eating characterized requirements, leading to a lower than expected by both: by both: body weight in the context of age, sex, Eating in a discrete time period an amount Eating in a discrete time period an amount development, and physical health (<85% of food that is larger than most people of food that is larger than most people predicted) would eat in the same period under the would eat in the same period of time under same circumstance the same circumstance
A feeling of lack of control over eating A feeling of lack of control over eating during an episode during an episode
Fear of weight gain or becoming fat, despite Recurrent, inappropriate compensatory The episodes are associated with three of the lower than predicted body weight behaviors to prevent weight gain including self­ following: induced emesis; abuse of laxatives, diuretics, or Eating much more quickly than normal other medications; caloric restriction; or Eating until feeling uncomfortably full or excessive exercise overfull
Eating large amounts of food even when not feeling hungry
Eating alone because of embarrassment about how much one is eating
. Feeling disgusted, depressed, or guilty afterward
Derangement in the way the patient’s body Bingeing and purging at least  time a week for  The patient exhibits marked distress regarding weight or appearance is experienced, undue weeks binge eating.
effects of body weight on self­evaluation, or denial of the dangerousness of the current low Self­evaluation is unduly influenced by body The binge eating occurs at least  time a week for body weight weight and appearance  months.
The disturbance does not occur exclusively The binge eating is not associated with during episodes of anorexia inappropriate compensatory behavior and does not occur exclusively during the course of anorexia, bulimia, or avoidant/restrictive food intake disorder.
Source: Data from American Psychiatric Association: Diagnostic and Statistical Manual of Mental Disorders: DSM­5, 5th ed. Washington, DC: American Psychiatric
Association; 2013. 
There are two subtypes of anorexia nervosa: restrictive and binge/purge, with crossover between the two. Restrictive patients minimize their food intake, whereas those with bingeing/purging make up for unacceptable food intake with diuretics, laxatives, enemas, or vomiting. There are also two subtypes of bulimia: purging and nonpurging. Those who purge do so by the above methods; those classified as nonpurging use other compensatory
 methods such as fasting or excessive exercise. Up to 50% of anorexia patients develop bulimia. Binge eating disorder is characterized by habitual, recurrent binge consumption episodes that cause significant distress. This is distinct from simple episodic overeating and must be both independent of anorexia or bulimia and free of compensatory mechanisms. The Diagnostic and Statistical Manual of Mental Disorders, fifth edition, also defines avoidant/restrictive food intake disorder, pica, and rumination disorder, which are not addressed here.

Chapter 291: Eating Disorders, Gemma C. L. Bornick 
,5
Anorexia nervosa has an estimated lifetime prevalence of .9% in women and .3% in men, and median age of onset is  years old. Bulimia
. Terms of Use * Privacy Policy * Notice * Accessibility
 nervosa has an estimated lifetime prevalence of .5% in women and .5% in men, and median age at onset is also  years old. Binge eating disorder is more common in older individuals and males than both anorexia and bulimia, with a lifetime prevalence of .5% in women and .0% in
,5 men.
PATHOPHYSIOLOGY
,7
There is evidence that eating disorders run in families, possibly due to both genetic influences and similar underlying temperaments and behaviors.

For example, genetic locus (rs4622308) on chromosome  is associated with anorexia nervosa. MRI studies detect differences in brain behavior and
9­12 structure, and some implicate brain regions involved in reward processing.
CLINICAL FEATURES
HISTORY
Patients with eating disorders often present to the ED with vague signs and symptoms such as weakness, fatigue, pallor, dizziness, syncope, confusion,
 bloating, edema, or persistent nausea. Complaints may otherwise be due to medical complications, such as chest pain and hematemesis caused by a
Mallory­Weiss tear from purging; palpitations from dysrhythmias; dysmenorrhea from disruption of the hypothalamic­pituitary axis; or fractures from
,15 osteoporosis. Depression, anxiety, substance abuse, self­injurious behavior, or suicidality may coexist. Therefore, if an eating disorder is suspected, consider screening for depression and suicidality.
If clinical suspicion is raised for an eating disorder based on complaint cluster, physical examination, or family report, explore a more focused history.
Important data points to elicit include eating and dieting behavior; desire for weight loss; typical daily dietary intake; presence of calorie counting; compensatory exercise behavior; guilt patterns following eating; menstruation pattern; and use of over­the­counter dietary supplements or laxative agents. Certain sensitive history points may be difficult to elicit in the ED, such as early childhood GI issues or picky eating or obesity, self­esteem issues, societal thinness pressures, teasing, propensity toward perfectionism, or sexual abuse. Certain physical activities raise risk for eating disorders,
16­18 such as gymnastics, ballet and other dance, wrestling, swimming, and cross­country running. Because eating disorders are characterized by denial
 of symptoms and behaviors, take a nonjudgmental approach to encourage trust and truthful disclosure.
PHYSICAL EXAMINATION
Patients with anorexia are typically easily identifiable based on a very thin body habitus. Other signs include hypotension (resting or orthostatic), bradycardia or tachydysrhythmia, heart murmur and S “click” of mitral valve prolapse, or hypothermia. Patients may also exhibit signs of vitamin
 deficiencies such as brittle, flaking, or ridged nails (nonspecific malnutrition); stomatitis or cheilitis (B vitamin deficiency); or perifollicular petechiae
(scurvy). They may also develop fine, long hair on the arms and face, acral cyanosis (impaired thermoregulation), and/or pretibial edema secondary to
  malnutrition. Nonsuicidal self­injury is also common, and stigmata of cutting, picking, burning, or bruising may be present.
Patients with bulimia or binge eating disorder can be difficult to detect in the ED because they tend to be normal weight or overweight. Consider eating disorder diagnoses in the presence of other physical indicators, even in normal weight or overweight patients. Self­induced vomiting can cause painless hypertrophy of the parotid glands (sialadenosis), dental erosion, and trauma or callus formation to the dorsal hands

(Russell’s sign), as well as pharyngeal erythema or abrasions, gingivitis, facial petechiae or subconjunctival hemorrhage, and halitosis. Laxative abuse may cause peripheral edema, anal fissures, hemorrhoids, perianal dermatitis, and rectal bleeding. Patients with binge eating disorder will likely have no abnormalities apparent on physical examination.
DISEASE COMPLICATIONS
Eating disorders can be life threatening. Death by suicide is six and four times more common in patients with anorexia and bulimia, respectively,
 than in the general population. Medical complications are typically more severe in anorexia than in bulimia or binge eating. Complications of
  anorexia are generally directly due to malnutrition and can account for a large proportion of deaths. Bulimia medical complications are usually
 related to method and frequency of purging and are often the result of chemical derangements or structural damage to the GI tract. Patients with
 binge eating disorder describe significantly more somatic symptoms than the general population, but true medical complications are rare.
Cardiopulmonary Complications

Among the most deadly of the eating disorder complications in anorexia are structural and functional changes to the cardiovascular system.
Malnutrition causes decreased cardiac muscle mass and increased vagal tone. This leads to decreased contractility and cardiac output and, therefore,
 results in hypotension, bradycardia, and orthostasis. Relative decreases in cardiac muscle mass can lead to the development of mitral valve prolapse.

Rarely, patients with anorexia nervosa can develop myocardial fibrosis or pericardial effusion, which in a few cases has led to cardiac tamponade
 requiring pericardiocentesis. Syrup of ipecac, used as an emetogenic, is directly cardiotoxic and can cause an irreversible cardiomyopathy.
Prolongation of the QT interval on ECG has been described, but this is rare in the absence of electrolyte disturbance or congenital long QT syndrome
 and should prompt evaluation for these conditions. Increased QT dispersion (difference between maximum and minimum QT intervals seen in each
 lead of a single ECG) indicates heterogeneous ventricular depolarization and is a marker for increased arrhythmic risk. QT derangements as a result of eating disorders are reversed by adequate refeeding. QT resolution is associated with normalization of heart rate, heart rate variability, and exercise
  tolerance and, therefore, has been used as a marker to guide rehabilitation. Most other cardiac sequelae are also reversible with appropriate
,33 weight gain, but there is increased risk of cardiac complications during the first week of refeeding after severe nutrient depletion. Cardiac
,34 complications are only rarely seen in patients with bulimia nervosa or binge eating disorder.
Pulmonary Complications
,36
Anorexia can lead to weakness of respiratory muscles, decreased pulmonary and aerobic capacity, and aspiration due to pharyngeal muscle
 weakness. Aspiration pneumonitis and subsequent pneumonia can occur as a result of pharyngeal muscle weakness and from chronic purging.

There are case reports of pneumothorax and pneumomediastinum. Patients with bulimia and binge eating disorder are often smokers and may have
 pulmonary complications related to smoking.
GI Complications
Patients with anorexia are at increased risk of constipation, gastroparesis, acute gastric dilatation, gastroesophageal reflux, and acute
,40,41 pancreatitis. Gastroesophageal reflux and laryngopharyngeal reflux commonly occur in patients with bulimia or purging­type anorexia and may
,42  result in hoarseness or dysphagia. Forceful vomiting can result in Mallory­Weiss tears or, rarely, Boerhaave syndrome. Chronic stimulant laxative
43­45 abuse can lead to development of ileus, rectal prolapse, melanosis coli, or the cathartic colon syndrome.
Nutritional Complications
The proportion of eating disorder patients with vitamin deficiencies is difficult to determine because many take supplements. Decreased bone mineral
 density and skeletal fragility are common but are not associated with decreased vitamin D levels. Iron and vitamin B deficiencies can lead to anemia
 in severely food­restrictive patients but are uncommon. Skin erythema and pruritus with sun exposure, glossitis, epidermal desquamation, and
 diarrhea should raise suspicion of pellagra. Confusion, confabulation, ataxia, ophthalmoplegia, and/or nystagmus suggest Wernicke­Korsakoff encephalopathy. Other vitamin deficiencies reported in association with eating disorders include wet beriberi and scurvy, although these are
,49   extremely rare. Poor nutritional state can result in hypoplastic or aplastic bone marrow and resultant cytopenias.
Renal and Electrolyte Complications
Electrolyte derangements and other lab abnormalities are more common in purging­type eating disorders. Patients with restrictive­type anorexia may not demonstrate any laboratory abnormalities. Frequent vomiting can result in metabolic alkalosis, hyponatremia, and hypochloremia. Laxative and diuretic abuse and vomiting can lead to potassium and magnesium depletion. Hyponatremia may also develop in patients who abuse diuretics. Signs
,22,52,53 of starvation ketosis may be evident. In patients with very severe anorexia, hypoglycemia and hypophosphatemia can develop.
Refeeding following prolonged nutrient depletion can also cause electrolyte abnormalities, most commonly hypokalemia, hypophosphatemia, and hypomagnesemia, due to redistribution of electrolytes from the extracellular to the intracellular space triggered by insulin release and from depletion
 of phosphorus during protein synthesis. This can lead to arrhythmias, congestive heart failure, pericardial effusions, and cardiac arrest.
Endocrine Complications
Profound food restriction affects the hypothalamic­pituitary axis. Low levels of gonadotropins, loss of the normal pulsatile waves of luteinizing
 hormone, and estrogen deficiency lead to hypothalamic amenorrhea. Anorexia is also associated with the “euthyroid sick syndrome” in which thyroid­stimulating hormone is normal or slightly low, T is low, and sometimes T levels are also decreased. Thyroid deficiencies likely contribute to
  the bradycardia, orthostasis, and hypothermia in anorexia. High cortisol levels and low levels of insulin­like growth factor  (somatomedin C), T ,

 estradiol, and testosterone contribute to loss of bone mass. Refeeding and recovery from illness do not fully return bone mass to normal levels, and
 patients with anorexia remain at an increased risk of fracture for many years following initial diagnosis. The endocrine effects of bulimia and binge eating disorder are less well studied. Bulimia is associated with both type  and type  diabetes mellitus. There is some evidence to support an
,57 increased risk of dyslipidemia, glucose dysregulation, and diabetes in binge eating disorder. Repeated vomiting can lead to metabolic alkalosis,
 hypokalemia, and increased aldosterone secretion—a cluster described as pseudo­Bartter syndrome.
DIAGNOSIS
Diagnostic criteria are outlined in the fifth edition of the Diagnostic and Statistical Manual of Mental Disorders, but screening tools are more practical for presumptive diagnosis in the ED. The SCOFF Questionnaire (Table 291­2) is useful for screening for anorexia and bulimia in a brief encounter
 and can be remembered by its acronym: Sick, Control, One stone, Fat, Food. Other screening tools, such as the Eating Disorder Diagnostic Scale or
,61 the Eating Attitudes Test, are more extensive and are more useful in a primary care setting. The Questionnaire on Eating and Weight Patterns–

Revised is specific for binge eating disorder.
It is very important to search for, diagnose, and treat organic pathology as part of the assessment of a patient with a potential eating disorder (Table
291­3).
TABLE 291­2
SCOFF Questionnaire
Do you make yourself sick because you feel uncomfortably full?
Do you worry you have lost control over how much you eat?
Have you recently lost more than  stone (14 lb) in a 3­month period?
Do you believe yourself to be fat when others say you are too thin?
Would you say that food dominates your life?
Note: A score of  or more indicates a probable eating disorder with a sensitivity of .6% and a specificity of .6%.
Source: Reproduced with permission from Morgan JF, Reid F, Lacey JH: The SCOFF questionnaire: a new screening tool for eating disorders. West J Med
2000;172(3):164­165. TABLE 291­3
Differential Diagnosis of New­Onset Eating Disorders
Endocrine Adrenal insufficiency
Hyperthyroidism
Diabetes
GI Hepatitis
Pancreatitis
Celiac disease
Inflammatory bowel disease
Superior mesenteric artery syndrome
Infectious disease Mononucleosis
Human immunodeficiency virus
Tuberculosis
Cancer Nervous system malignancy
Ovarian malignancy
Intra­abdominal malignancy
Pregnancy Hyperemesis gravidarum
Psychiatric Substance abuse
Major depressive disorder
Bipolar disorder
Schizophrenia
Inborn error of metabolism Mitochondrial disorders
Enzyme deficiency
LABORATORY TESTING
Initial testing should include an ECG and a full chemistry panel including magnesium, calcium, and phosphorus; CBC; urinalysis; pregnancy test;
 hepatic function panel; serum albumin; lipase and amylase; and thyroid­stimulating hormone.
IMAGING
Obtain imaging only to rule out an underlying organic cause of presenting symptoms or to exclude medical complications. Nonspecific radiographic
  findings in patients with anorexia may include decreased muscle mass, paucity of subcutaneous fat, mild small bowel dilatation, and osteoporosis.
There are no specific radiographic findings diagnostic of binge eating disorder or bulimia, but a swallowed toothbrush or similar item suggests
 purging by induced vomiting.
TREATMENT AND DISPOSITION
The ED treatment of eating disorders is limited to stabilization of urgent medical complications, followed by hospital admission or outpatient referral
,67 to a mental health specialist. Tables 291­4 and 291­5 list guidelines for hospital admission. Most medical complications of anorexia nervosa can
252 be treated in an outpatient setting if the patient’s weight is >70% of ideal body weight or body mass index is >15 kg/m . Long­term treatment of all
 eating disorders requires a multidisciplinary approach, including psychotherapy, dietary interventions, and pharmacotherapy in certain cases. If pharmacotherapy is indicated, it should be initiated by a psychiatrist or primary care provider.
TABLE 291­4
Society of Adolescent Medicine Criteria for Hospital Admission
Anorexia Nervosa Bulimia Nervosa
Body weight <75% of ideal for age, sex, and height Potassium <3.2 mmol/L
Daytime heart rate <50 beats/min or nighttime heart rate <45 beats/min Chloride <88 mmol/L
Body fat <10% of body weight Esophageal trauma and hematemesis
Dehydration Vomiting unresponsive to antiemetics
Cardiac arrhythmia including QT prolongation Dehydration
Temperature <96°F Cardiac arrhythmia including QT prolongation
Orthostasis and syncope Temperature <96°F
Acute psychiatric emergencies such as hallucinations or suicidality Orthostasis and syncope
Systolic blood pressure <90 mm Hg Acute psychiatric emergencies such as hallucinations or suicidality
Ongoing weight loss despite outpatient treatment Ongoing purging despite outpatient treatment
TABLE 291­5
American Psychiatric Association Criteria for Hospital Admission
Medical status Adults: heart rate <40 beats/min, blood pressure <90/60 mm Hg, glucose <60 milligrams/dL (<3.3 mmol/L), potassium <3 mEq/L, temperature <97.0°F, end­organ compromise requiring acute treatment, poorly controlled diabetes
Children: heart rate near  beats/min, orthostasis, blood pressure <80/50 mm Hg, hypokalemia, hypophosphatemia, hypomagnesemia
Suicidality Specific plan with high lethality or intent
Weight Generally <85% of ideal body weight or acute weight change with food refusal
Motivation to Very poor motivation; patient preoccupied with intrusive repetitive thoughts and/or uncooperative with treatment recover
Comorbid Any existing psychiatric disorder requiring hospitalization disorders
Structure Needs supervision to ensure caloric intake, prevention of exercise, or prevention of purging behaviors required
Environmental Severe family conflict or absence of family, absence of appropriate outpatient resources in patient’s geographic region
SPECIAL POPULATIONS
PREGNANT WOMEN
Pregnancy can be a stressful time for a woman with an eating disorder, particularly with respect to maintaining adequate weight gain. There are conflicting data on whether the presence of eating disorders increases the risk of complications. The broadest study of its kind revealed that the majority of patients with anorexia and bulimia have normal pregnancies and healthy babies with, however, an increased risk of birth by cesarean section and an increased risk of postpartum depression. These differences remained between groups who had active symptoms and those with
 history of an eating disorder who were asymptomatic during pregnancy.
MEN

Do not neglect the possibility of eating disorders in men. Men may account for between 10% and 25% of cases of anorexia and bulimia, and binge eating is more prevalent in men than both anorexia and bulimia. The exact proportion of men with eating disorders is unknown because men are less likely to be diagnosed. Eating disorders in males are typically characterized by the drive to add muscle bulk and lean mass and are often associated with antecedent obesity, athletic performance concerns, bullying, and occasionally (but not always) sexual abuse. Men with eating disorders are more
 likely to abuse steroids and growth hormones, particularly when muscle dysmorphia is present.


## Page 3

Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 291: Eating Disorders
Gemma C. L. Bornick
INTRODUCTION AND EPIDEMIOLOGY
Eating disorders, such as anorexia nervosa, bulimia nervosa, and binge eating disorder, are psychological conditions characterized by a pathologic relationship with food that adversely affects psychosocial functioning. Eating disorders can be challenging in the ED because physical manifestations may be subtle and historical features may not be elicited unless a disorder is suspected from medical complications. The fifth edition of the Diagnostic
 and Statistical Manual of Mental Disorders refines the diagnostic criteria of eating disorders from the previous edition (Table 291­1).
TABLE 291­1
Diagnostic and Statistical Manual of Mental Disorders, Fifth Edition, Criteria for Eating Disorders
Anorexia Nervosa Bulimia Nervosa Binge Eating Disorder
Restriction of caloric intake relative to Recurrent episodes of binge eating characterized Recurrent episodes of binge eating characterized requirements, leading to a lower than expected by both: by both: body weight in the context of age, sex, Eating in a discrete time period an amount Eating in a discrete time period an amount development, and physical health (<85% of food that is larger than most people of food that is larger than most people predicted) would eat in the same period under the would eat in the same period of time under same circumstance the same circumstance
A feeling of lack of control over eating A feeling of lack of control over eating during an episode during an episode
Fear of weight gain or becoming fat, despite Recurrent, inappropriate compensatory The episodes are associated with three of the lower than predicted body weight behaviors to prevent weight gain including self­ following: induced emesis; abuse of laxatives, diuretics, or Eating much more quickly than normal other medications; caloric restriction; or Eating until feeling uncomfortably full or excessive exercise overfull
Eating large amounts of food even when not feeling hungry
Eating alone because of embarrassment about how much one is eating
. Feeling disgusted, depressed, or guilty afterward
Derangement in the way the patient’s body Bingeing and purging at least  time a week for  The patient exhibits marked distress regarding weight or appearance is experienced, undue weeks binge eating.
effects of body weight on self­evaluation, or denial of the dangerousness of the current low Self­evaluation is unduly influenced by body The binge eating occurs at least  time a week for body weight weight and appearance  months.
The disturbance does not occur exclusively The binge eating is not associated with during episodes of anorexia inappropriate compensatory behavior and does not occur exclusively during the course of anorexia, bulimia, or avoidant/restrictive food intake disorder.
Source: Data from American Psychiatric Association: Diagnostic and Statistical Manual of Mental Disorders: DSM­5, 5th ed. Washington, DC: American Psychiatric
Association; 2013. 
There are two subtypes of anorexia nervosa: restrictive and binge/purge, with crossover between the two. Restrictive patients minimize their food intake, whereas those with bingeing/purging make up for unacceptable food intake with diuretics, laxatives, enemas, or vomiting. There are also two subtypes of bulimia: purging and nonpurging. Those who purge do so by the above methods; those classified as nonpurging useU ontivheerrs citoym opf Penitstsabtourrgyh methods such as fasting or excessive exercise. Up to 50% of anorexia patients develop bulimia.  Binge eating disorder is charactAecrciezses dP rbovyid heda bby:itual, recurrent binge consumption episodes that cause significant distress. This is distinct from simple episodic overeating and must be both independent of anorexia or bulimia and free of compensatory mechanisms. The Diagnostic and Statistical Manual of Mental Disorders, fifth edition, also defines avoidant/restrictive food intake disorder, pica, and rumination disorder, which are not addressed here.
,5
Anorexia nervosa has an estimated lifetime prevalence of .9% in women and .3% in men, and median age of onset is  years old. Bulimia
 nervosa has an estimated lifetime prevalence of .5% in women and .5% in men, and median age at onset is also  years old. Binge eating disorder is more common in older individuals and males than both anorexia and bulimia, with a lifetime prevalence of .5% in women and .0% in
,5 men.
PATHOPHYSIOLOGY
,7
There is evidence that eating disorders run in families, possibly due to both genetic influences and similar underlying temperaments and behaviors.

For example, genetic locus (rs4622308) on chromosome  is associated with anorexia nervosa. MRI studies detect differences in brain behavior and
9­12 structure, and some implicate brain regions involved in reward processing.
CLINICAL FEATURES
HISTORY
Patients with eating disorders often present to the ED with vague signs and symptoms such as weakness, fatigue, pallor, dizziness, syncope, confusion,
 bloating, edema, or persistent nausea. Complaints may otherwise be due to medical complications, such as chest pain and hematemesis caused by a
Mallory­Weiss tear from purging; palpitations from dysrhythmias; dysmenorrhea from disruption of the hypothalamic­pituitary axis; or fractures from
,15 osteoporosis. Depression, anxiety, substance abuse, self­injurious behavior, or suicidality may coexist. Therefore, if an eating disorder is suspected, consider screening for depression and suicidality.
If clinical suspicion is raised for an eating disorder based on complaint cluster, physical examination, or family report, explore a more focused history.
Important data points to elicit include eating and dieting behavior; desire for weight loss; typical daily dietary intake; presence of calorie counting; compensatory exercise behavior; guilt patterns following eating; menstruation pattern; and use of over­the­counter dietary supplements or laxative agents. Certain sensitive history points may be difficult to elicit in the ED, such as early childhood GI issues or picky eating or obesity, self­esteem issues, societal thinness pressures, teasing, propensity toward perfectionism, or sexual abuse. Certain physical activities raise risk for eating disorders,
16­18 such as gymnastics, ballet and other dance, wrestling, swimming, and cross­country running. Because eating disorders are characterized by denial
 of symptoms and behaviors, take a nonjudgmental approach to encourage trust and truthful disclosure.
PHYSICAL EXAMINATION
Patients with anorexia are typically easily identifiable based on a very thin body habitus. Other signs include hypotension (resting or orthostatic), bradycardia or tachydysrhythmia, heart murmur and S “click” of mitral valve prolapse, or hypothermia. Patients may also exhibit signs of vitamin
 deficiencies such as brittle, flaking, or ridged nails (nonspecific malnutrition); stomatitis or cheilitis (B vitamin deficiency); or perifollicular petechiae
(scurvy). They may also develop fine, long hair on the arms and face, acral cyanosis (impaired thermoregulation), and/or pretibial edema secondary to
  malnutrition. Nonsuicidal self­injury is also common, and stigmata of cutting, picking, burning, or bruising may be present.
Patients with bulimia or binge eating disorder can be difficult to detect in the ED because they tend to be normal weight or overweight. Consider eating disorder diagnoses in the presence of other physical indicators, even in normal weight or overweight patients. Self­induced vomiting can cause painless hypertrophy of the parotid glands (sialadenosis), dental erosion, and trauma or callus formation to the dorsal hands

(Russell’s sign), as well as pharyngeal erythema or abrasions, gingivitis, facial petechiae or subconjunctival hemorrhage, and halitosis. Laxative abuse may cause peripheral edema, anal fissures, hemorrhoids, perianal dermatitis, and rectal bleeding. Patients with binge eating disorder will likely have no abnormalities apparent on physical examination.
DISEASE COMPLICATIONS
Eating disorders can be life threatening. Death by suicide is six and four times more common in patients with anorexia and bulimia, respectively,
 than in the general population. Medical complications are typically more severe in anorexia than in bulimia or binge eating. Complications of

  aCnhoarpetxeiar 2a9re1 g: eEnaetrinagll yD disiroercdtelyr sd,u Ge etom mmaal nCu.t rLit. iBonorn aicnkd can account for a large proportion of deaths. Bulimia medical complications areP uasguea l3ly / 
. Terms of Use * Privacy Policy * Notice * Accessibility
 related to method and frequency of purging and are often the result of chemical derangements or structural damage to the GI tract. Patients with
 binge eating disorder describe significantly more somatic symptoms than the general population, but true medical complications are rare.
Cardiopulmonary Complications

Among the most deadly of the eating disorder complications in anorexia are structural and functional changes to the cardiovascular system.
Malnutrition causes decreased cardiac muscle mass and increased vagal tone. This leads to decreased contractility and cardiac output and, therefore,
 results in hypotension, bradycardia, and orthostasis. Relative decreases in cardiac muscle mass can lead to the development of mitral valve prolapse.

Rarely, patients with anorexia nervosa can develop myocardial fibrosis or pericardial effusion, which in a few cases has led to cardiac tamponade
 requiring pericardiocentesis. Syrup of ipecac, used as an emetogenic, is directly cardiotoxic and can cause an irreversible cardiomyopathy.
Prolongation of the QT interval on ECG has been described, but this is rare in the absence of electrolyte disturbance or congenital long QT syndrome
 and should prompt evaluation for these conditions. Increased QT dispersion (difference between maximum and minimum QT intervals seen in each
 lead of a single ECG) indicates heterogeneous ventricular depolarization and is a marker for increased arrhythmic risk. QT derangements as a result of eating disorders are reversed by adequate refeeding. QT resolution is associated with normalization of heart rate, heart rate variability, and exercise
  tolerance and, therefore, has been used as a marker to guide rehabilitation. Most other cardiac sequelae are also reversible with appropriate
,33 weight gain, but there is increased risk of cardiac complications during the first week of refeeding after severe nutrient depletion. Cardiac
,34 complications are only rarely seen in patients with bulimia nervosa or binge eating disorder.
Pulmonary Complications
,36
Anorexia can lead to weakness of respiratory muscles, decreased pulmonary and aerobic capacity, and aspiration due to pharyngeal muscle
 weakness. Aspiration pneumonitis and subsequent pneumonia can occur as a result of pharyngeal muscle weakness and from chronic purging.

There are case reports of pneumothorax and pneumomediastinum. Patients with bulimia and binge eating disorder are often smokers and may have
 pulmonary complications related to smoking.
GI Complications
Patients with anorexia are at increased risk of constipation, gastroparesis, acute gastric dilatation, gastroesophageal reflux, and acute
,40,41 pancreatitis. Gastroesophageal reflux and laryngopharyngeal reflux commonly occur in patients with bulimia or purging­type anorexia and may
,42  result in hoarseness or dysphagia. Forceful vomiting can result in Mallory­Weiss tears or, rarely, Boerhaave syndrome. Chronic stimulant laxative
43­45 abuse can lead to development of ileus, rectal prolapse, melanosis coli, or the cathartic colon syndrome.
Nutritional Complications
The proportion of eating disorder patients with vitamin deficiencies is difficult to determine because many take supplements. Decreased bone mineral
 density and skeletal fragility are common but are not associated with decreased vitamin D levels. Iron and vitamin B deficiencies can lead to anemia
 in severely food­restrictive patients but are uncommon. Skin erythema and pruritus with sun exposure, glossitis, epidermal desquamation, and
 diarrhea should raise suspicion of pellagra. Confusion, confabulation, ataxia, ophthalmoplegia, and/or nystagmus suggest Wernicke­Korsakoff encephalopathy. Other vitamin deficiencies reported in association with eating disorders include wet beriberi and scurvy, although these are
,49   extremely rare. Poor nutritional state can result in hypoplastic or aplastic bone marrow and resultant cytopenias.
Renal and Electrolyte Complications
Electrolyte derangements and other lab abnormalities are more common in purging­type eating disorders. Patients with restrictive­type anorexia may not demonstrate any laboratory abnormalities. Frequent vomiting can result in metabolic alkalosis, hyponatremia, and hypochloremia. Laxative and diuretic abuse and vomiting can lead to potassium and magnesium depletion. Hyponatremia may also develop in patients who abuse diuretics. Signs
,22,52,53 of starvation ketosis may be evident. In patients with very severe anorexia, hypoglycemia and hypophosphatemia can develop.
Refeeding following prolonged nutrient depletion can also cause electrolyte abnormalities, most commonly hypokalemia, hypophosphatemia, and hypomagnesemia, due to redistribution of electrolytes from the extracellular to the intracellular space triggered by insulin release and from depletion
 of phosphorus during protein synthesis. This can lead to arrhythmias, congestive heart failure, pericardial effusions, and cardiac arrest.
Endocrine Complications
Profound food restriction affects the hypothalamic­pituitary axis. Low levels of gonadotropins, loss of the normal pulsatile waves of luteinizing
 hormone, and estrogen deficiency lead to hypothalamic amenorrhea. Anorexia is also associated with the “euthyroid sick syndrome” in which thyroid­stimulating hormone is normal or slightly low, T is low, and sometimes T levels are also decreased. Thyroid deficiencies likely contribute to
  the bradycardia, orthostasis, and hypothermia in anorexia. High cortisol levels and low levels of insulin­like growth factor  (somatomedin C), T ,

 estradiol, and testosterone contribute to loss of bone mass. Refeeding and recovery from illness do not fully return bone mass to normal levels, and
 patients with anorexia remain at an increased risk of fracture for many years following initial diagnosis. The endocrine effects of bulimia and binge eating disorder are less well studied. Bulimia is associated with both type  and type  diabetes mellitus. There is some evidence to support an
,57 increased risk of dyslipidemia, glucose dysregulation, and diabetes in binge eating disorder. Repeated vomiting can lead to metabolic alkalosis,
 hypokalemia, and increased aldosterone secretion—a cluster described as pseudo­Bartter syndrome.
DIAGNOSIS
Diagnostic criteria are outlined in the fifth edition of the Diagnostic and Statistical Manual of Mental Disorders, but screening tools are more practical for presumptive diagnosis in the ED. The SCOFF Questionnaire (Table 291­2) is useful for screening for anorexia and bulimia in a brief encounter
 and can be remembered by its acronym: Sick, Control, One stone, Fat, Food. Other screening tools, such as the Eating Disorder Diagnostic Scale or
,61 the Eating Attitudes Test, are more extensive and are more useful in a primary care setting. The Questionnaire on Eating and Weight Patterns–

Revised is specific for binge eating disorder.
It is very important to search for, diagnose, and treat organic pathology as part of the assessment of a patient with a potential eating disorder (Table
291­3).
TABLE 291­2
SCOFF Questionnaire
Do you make yourself sick because you feel uncomfortably full?
Do you worry you have lost control over how much you eat?
Have you recently lost more than  stone (14 lb) in a 3­month period?
Do you believe yourself to be fat when others say you are too thin?
Would you say that food dominates your life?
Note: A score of  or more indicates a probable eating disorder with a sensitivity of .6% and a specificity of .6%.
Source: Reproduced with permission from Morgan JF, Reid F, Lacey JH: The SCOFF questionnaire: a new screening tool for eating disorders. West J Med
2000;172(3):164­165. TABLE 291­3
Differential Diagnosis of New­Onset Eating Disorders
Endocrine Adrenal insufficiency
Hyperthyroidism
Diabetes
GI Hepatitis
Pancreatitis
Celiac disease
Inflammatory bowel disease
Superior mesenteric artery syndrome
Infectious disease Mononucleosis
Human immunodeficiency virus
Tuberculosis
Cancer Nervous system malignancy
Ovarian malignancy
Intra­abdominal malignancy
Pregnancy Hyperemesis gravidarum
Psychiatric Substance abuse
Major depressive disorder
Bipolar disorder
Schizophrenia
Inborn error of metabolism Mitochondrial disorders
Enzyme deficiency
LABORATORY TESTING
Initial testing should include an ECG and a full chemistry panel including magnesium, calcium, and phosphorus; CBC; urinalysis; pregnancy test;
 hepatic function panel; serum albumin; lipase and amylase; and thyroid­stimulating hormone.
IMAGING
Obtain imaging only to rule out an underlying organic cause of presenting symptoms or to exclude medical complications. Nonspecific radiographic
  findings in patients with anorexia may include decreased muscle mass, paucity of subcutaneous fat, mild small bowel dilatation, and osteoporosis.
There are no specific radiographic findings diagnostic of binge eating disorder or bulimia, but a swallowed toothbrush or similar item suggests
 purging by induced vomiting.
TREATMENT AND DISPOSITION
The ED treatment of eating disorders is limited to stabilization of urgent medical complications, followed by hospital admission or outpatient referral
,67 to a mental health specialist. Tables 291­4 and 291­5 list guidelines for hospital admission. Most medical complications of anorexia nervosa can
252 be treated in an outpatient setting if the patient’s weight is >70% of ideal body weight or body mass index is >15 kg/m . Long­term treatment of all
 eating disorders requires a multidisciplinary approach, including psychotherapy, dietary interventions, and pharmacotherapy in certain cases. If pharmacotherapy is indicated, it should be initiated by a psychiatrist or primary care provider.
TABLE 291­4
Society of Adolescent Medicine Criteria for Hospital Admission
Anorexia Nervosa Bulimia Nervosa
Body weight <75% of ideal for age, sex, and height Potassium <3.2 mmol/L
Daytime heart rate <50 beats/min or nighttime heart rate <45 beats/min Chloride <88 mmol/L
Body fat <10% of body weight Esophageal trauma and hematemesis
Dehydration Vomiting unresponsive to antiemetics
Cardiac arrhythmia including QT prolongation Dehydration
Temperature <96°F Cardiac arrhythmia including QT prolongation
Orthostasis and syncope Temperature <96°F
Acute psychiatric emergencies such as hallucinations or suicidality Orthostasis and syncope
Systolic blood pressure <90 mm Hg Acute psychiatric emergencies such as hallucinations or suicidality
Ongoing weight loss despite outpatient treatment Ongoing purging despite outpatient treatment
TABLE 291­5
American Psychiatric Association Criteria for Hospital Admission
Medical status Adults: heart rate <40 beats/min, blood pressure <90/60 mm Hg, glucose <60 milligrams/dL (<3.3 mmol/L), potassium <3 mEq/L, temperature <97.0°F, end­organ compromise requiring acute treatment, poorly controlled diabetes
Children: heart rate near  beats/min, orthostasis, blood pressure <80/50 mm Hg, hypokalemia, hypophosphatemia, hypomagnesemia
Suicidality Specific plan with high lethality or intent
Weight Generally <85% of ideal body weight or acute weight change with food refusal
Motivation to Very poor motivation; patient preoccupied with intrusive repetitive thoughts and/or uncooperative with treatment recover
Comorbid Any existing psychiatric disorder requiring hospitalization disorders
Structure Needs supervision to ensure caloric intake, prevention of exercise, or prevention of purging behaviors required
Environmental Severe family conflict or absence of family, absence of appropriate outpatient resources in patient’s geographic region
SPECIAL POPULATIONS
PREGNANT WOMEN
Pregnancy can be a stressful time for a woman with an eating disorder, particularly with respect to maintaining adequate weight gain. There are conflicting data on whether the presence of eating disorders increases the risk of complications. The broadest study of its kind revealed that the majority of patients with anorexia and bulimia have normal pregnancies and healthy babies with, however, an increased risk of birth by cesarean section and an increased risk of postpartum depression. These differences remained between groups who had active symptoms and those with
 history of an eating disorder who were asymptomatic during pregnancy.
MEN

Do not neglect the possibility of eating disorders in men. Men may account for between 10% and 25% of cases of anorexia and bulimia, and binge eating is more prevalent in men than both anorexia and bulimia. The exact proportion of men with eating disorders is unknown because men are less likely to be diagnosed. Eating disorders in males are typically characterized by the drive to add muscle bulk and lean mass and are often associated with antecedent obesity, athletic performance concerns, bullying, and occasionally (but not always) sexual abuse. Men with eating disorders are more
 likely to abuse steroids and growth hormones, particularly when muscle dysmorphia is present.


