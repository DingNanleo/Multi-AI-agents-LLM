## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 50: Cardiogenic Shock
Andrew R. Petrilli; John Gaillard; David E. Manthey; Bret A. Nicks
Content Update: Cardiogenic Shock ­ May 2022
Text and references have been updated throughout in keeping with contemporary reports. See the section on Hypotension, and Table 50­4 for new information on vasopressors. Mechanical complications associated with cardiogenic shock are discussed in the section “Physical Examination”.
INTRODUCTION AND EPIDEMIOLOGY
Cardiogenic shock results from decreased cardiac output, leading to inadequate tissue perfusion despite adequate circulating volume, and it carries
,2 an in­hospital mortality rate of 27% to 51%. While the true incidence is unknown due to missing data from out­of­hospital associated deaths, cardiogenic shock occurs in up to 10% of patients with ST­segment elevation myocardial infarction (STEMI) and is the leading cause of in­hospital
3­6,63 death in patients with acute myocardial infarction (AMI). Cardiogenic shock occurs less frequently (2.5%) in those with non–ST­segment elevation
,8 myocardial infarction (NSTEMI). Only approximately 10% of AMI patients who will develop cardiogenic shock have it at initial ED presentation. With
,66 the median time of onset after ED arrival being  hours, prompt recognition and rapid intervention are essential. A strategy of early revascularization (percutaneous coronary intervention or coronary artery bypass surgery), mechanical circulatory support device when indicated, and
,10­13 optimal medical therapy, portend the best outcomes. The more individual risk factors (Table 50­1), and the greater amount of vulnerable
 myocardium, the greater the risk of cardiogenic shock. Cardiogenic shock is difficult to diagnose due to its diverse presentations, overlap with other shock states, multifactorial causes that may not be ischemic in nature, and variability in presenting hemodynamics.
TABLE 50­1
Risk Factors for Cardiogenic Shock
Elderly
Female
Acute or prior ischemic event associated with the following
Impaired ejection fraction
Extensive infarct (evidence of large myocellular leak)
Proximal left anterior descending coronary artery occlusion
Anterior myocardial infarction
Multivessel coronary artery disease
Prior medical history
Previous myocardial infarction
Congestive heart failure
Diabetes
Despite advances in pharmacologic and device­based approaches for patients with cardiogenic shock, only small improvement in mortality has been observed over the past decade. Limited randomized controlled trials have failed to show clear superiority of recommended therapeutic strategies in
 pCahrat pdtueer t5o0 t: hCea hrdetioegroegneicn eSithyo ocfk t, rAianl darnedw r eRg.i sPtreyt rdilali;t aJ.ohn Gaillard; David E. Manthey; Bret A. Nicks 
. Terms of Use * Privacy Policy * Notice * Accessibility
PATHOPHYSIOLOGY
The most common cause of cardiogenic shock is extensive myocardial infarction that depresses myocardial contractility. Additional causes are listed in
Table 50­2. Regardless of the precipitating cause, cardiogenic shock is primarily “pump failure,” resulting in diminished cardiac output, hypotension,
 systemic vasoconstriction, and increasing cardiac ischemia. The systolic blood pressure drops due to poor cardiac output, causing hypoperfusion of vital organs. Without a rise in systemic vascular resistance, the diastolic blood pressure drops, resulting in coronary artery hypoperfusion. This creates a deadly cycle of worsening myocardial ischemia and pump dysfunction and eventual decompensation.
TABLE 50­2
Causes of Cardiogenic Shock
Mechanical complications
Acute mitral regurgitation secondary to papillary muscle dysfunction or chordal rupture
Ventricular septal defect
Free wall rupture
Right ventricular infarction
Acute aortic insufficiency (aortic dissection)
Severe depression of cardiac contractility
Acute myocardial infarction
Sepsis
Myocarditis
Myocardial contusion
Cardiomyopathy
Medication toxicity (e.g., β­blocker overdose, calcium channel–blocker overdose)
Unstable dysrhythmia
Mechanical obstruction to forward blood flow
Aortic stenosis
Hypertrophic cardiomyopathy
Mitral stenosis
Left atrial myxoma
Pericardial tamponade
Both increased afterload and systolic/diastolic dysfunction of the heart can lead to increased left ventricular end­diastolic pressures (LVEDP) and pulmonary edema. Pulmonary edema leads to hypoxia and hypoxemia, which worsens ischemia and causes progressive cardiac dysfunction.
Decreased cardiac output due to decreased stroke volume leads to poor peripheral perfusion and vasoconstriction. Augmenting peripheral vasoconstriction may improve coronary artery and peripheral perfusion, but the resultant increased afterload can worsen cardiac contractility and further decrease cardiac output.
In addition, cardiogenic shock triggers a systemic inflammatory response, with release of nitric oxide and other mediators, that has a negative
15­19 inotropic effect and creates systemic vasodilation. The inflammatory response depresses pump function, dilates the peripheral vasculature, and
,21 increases the risk of death. Studies looking at directed interventions to blunt the inflammatory response, complement cascade, and vasodilation
,22 have to date failed to decrease mortality.
The classic and most common picture of acute cardiogenic shock is due to left ventricular (LV) infarction and is characterized by the physiologic triad of low cardiac index, high systemic vascular resistance indices, and increased pulmonary capillary wedge pressure, with peripheral vasoconstriction and
,24 pulmonary edema. When right ventricular (RV) infarction is the cause of cardiogenic shock, the RV filling pressures increase, and forward flow to the LV is decreased, resulting in lowered cardiac output. Euvolemic cardiogenic shock occurs subacutely in patients with heart failure; normotensive cardiogenic shock is rare.
CLINICAL FEATURES
HISTORY
Patients commonly have shortness of breath, chest pain, or weakness. Be sure to ask about and consider other causes of shock or pump failure (Table
50­3). Ask about a history of preexisting valvular disease, congestive heart failure, reduced ejection fraction (EF), recent illnesses, hypercoagulable states, substance abuse, and other risk factors (Table 50­1).
TABLE 50­3
Shock With Pump Failure: A Limited Differential Diagnosis
Cardiogenic Shock (see Table 50­2)
Acute pulmonary decompensation
Chronic obstructive pulmonary disease exacerbation
Cor pulmonale
Massive pulmonary embolism
Distributive shock
Sepsis
Anaphylaxis
Neurogenic shock (spinal cord injury)
Hypovolemic shock
Hemorrhage
Severe dehydration
Dissociative shock
Toxins/drugs of abuse (cyanide)
PHYSICAL EXAMINATION

Cardiogenic shock results in hypoperfusion due to a low cardiac index although it is not always…. accompanied by hypotension. Systolic blood pressure is usually <90 mm Hg, although it can be higher with preexisting hypertension or peripheral vasoconstriction response. A pulse pressure <20 mm Hg is another finding if systemic resistance has not plummeted, and sinus tachycardia is common unless the patient is on medications that block a tachycardic response. Until respiratory fatigue sets in, tachypnea is common. If there is LV compromise, chest examination demonstrates rales from pulmonary edema. Patients are usually pale or cyanotic and may have cool skin, mottled extremities, and/or other signs of hypoperfusion. Diaphoresis indicates activation of the sympathetic nervous system. Cerebral hypoperfusion may result in altered mental status, and renal hypoperfusion often creates low urine output.
In isolated RV infarction, the lungs are spared and venous congestion occurs, presenting as increased jugular venous pressure, a rise in jugular venous pressure with inspiration (Kussmaul sign) or compression of the liver (hepatojugular reflux), an enlarged liver, peripheral edema, and a third heart sound (S ) originating from the RV.

Mechanical complications account for about 10% of cardiogenic shock after AMI. A new murmur may be the only physical exam finding of mechanical catastrophe. Carefully listen for any loud or new systolic murmurs. Acute mitral regurgitation, characterized by a soft holosystolic murmur at the apex radiating to the axilla, can occur from chordae tendineae rupture or papillary muscle dysfunction. An acute ventral septal defect is associated with a new loud holosystolic left parasternal murmur, often with a palpable thrill, that decreases in intensity as the intraventricular pressures equalize.
Suspect acute aortic insufficiency when you find a soft diastolic murmur and a soft S sound.

DIAGNOSIS
Shock exists whenever there is evidence of tissue hypoperfusion (i.e., end­organ dysfunction/damage and a systolic blood pressure usually <90 mm Hg or mean arterial pressure <65 mm Hg). To identify the heart as the cause of the shock state, rapidly assess the heart with clinical exam (discussed earlier), ECG, and POCUS echocardiogram (Figure 50­1).
FIGURE 50­1. Approach to patient with cardiogenic shock. RV = right ventricle; SBP = systolic blood pressure; STEMI = ST­segment elevation myocardial infarction.
LABORATORY TESTING
There are no laboratory markers specific for the diagnosis, although a CBC, electrolytes, creatinine, lactate, serial cardiac troponin, hepatic studies, and a blood gas are commonly obtained. Biomarkers of cardiac myonecrosis (primarily troponin) are time sensitive and may not be elevated at initial presentation from an acute myocardial ischemic triggering event. A CBC identifies anemia, which can contribute to cardiac ischemia. Hypoperfusion may result in an elevated serum lactate, and serum electrolytes and renal and hepatic studies can identify end­organ dysfunction.
Serum B­type natriuretic peptide (BNP) is an indicator of LV dysfunction but does not identify the cause. Because of its high negative predictive value, a normal BNP level (<100 picograms/mL) eliminates cardiogenic shock as the cause of hypoperfusion unless very early after onset or with
,25 isolated right heart failure. Conversely, an elevated BNP does not diagnose cardiogenic shock.
Blood gas measurements help identify those at risk of acute respiratory failure/carbon dioxide retention, quantify the presence and severity of acidosis, and determine the contribution of metabolic or respiratory components to acidosis.
IMAGING AND ANCILLARY STUDIES
Electrocardiogram
The ECG may identify ischemia, STEMI, or rhythm abnormalities and give evidence of cardiac response to identify electrolytic abnormalities (e.g., hypokalemia) or drug toxicity (e.g., digoxin). Obtain right­sided ECGs to identify RV infarction accompanying inferior infarction, looking for ST elevation
,27 in lead V and ST­segment elevation in leads V R to V R; this finding elevates the short­term risk of death (Figure 50­2).

FIGURE 50­2. Right­sided leads demonstrating right ventricular infarction associated with inferior wall myocardial infarction. Right­sided leads have replaced the normal left­sided V leads. In this example, the ST­segment elevation is prominent in leads VR .
3­6
Chest Radiography
Chest radiographic findings are useful for excluding other causes of shock or chest pain. Pre­existing disease can also confound the radiographic appearance, with pulmonary edema difficult to detect in patients with severe COPD or interstitial lung disease. Most patients with cardiogenic shock demonstrate findings of LV failure such as pulmonary congestion or edema, alveolar infiltrates, and pleural effusions. Such findings may lag by hours, so their absence does not exclude cardiogenic shock. Cardiomegaly is the result of long­standing myocardial remodeling, and its presence may not explain the acute symptoms. The chest radiograph can suggest alternative or confounding diagnoses, such as pneumonia, pneumothorax, aortic dissection, or progressive pericardial effusion.
Bedside Point of Care Ultrasound
POCUS can help exclude alternative etiologies of shock, identify mechanical concerns, and guide therapy. Assessment should include a volume status evaluation of the inferior vena cava and estimation of right atrial pressure. A subcostal four­chamber view visualizes pericardial effusion and cardiac tamponade. When tamponade exists, there is a pericardial effusion, dilation of the inferior vena cava, and diastolic collapse of the RV with systolic collapse of the right atrium. When cardiac rupture occurs, there may be a visible clot in the pericardial space. Subcostal, parasternal, and apical views together can help estimate EF and cardiac contractility. An aortic root >3 cm is concerning for ascending aortic dissection, especially when associated with a pericardial effusion. Assess the valves for appropriate motion and flow characteristics, specifically the mitral valve. Apical four­chamber views are helpful for evaluating chamber size. In cases of acute right heart failure due to ischemia, the RV will be dilated and the LV will appear to be smaller than expected due to low filling pressures and RV dilatation. In left heart failure, there will be dilation of the LV secondary to decreased cardiac output
 and increased filling pressure. On lung assessment, B­lines (three B­lines in two bilateral lung zones) are the US equivalent of the Kerley B­lines
 found on chest radiograph and are commonly present with interstitial edema. The line will traverse the entire US screen in a vertical manner as well
 as cross any present A­lines.
Bedside echocardiography is an adjunct, not replacement, for emergent formal transthoracic echocardiography. Formal echocardiography uses color and spectral Doppler to identify mechanical complications and to characterize the nature of cardiac impairment. Echocardiography detects regional wall motion abnormalities and a lack of compensatory hyperkinesis in uninvolved cardiac segments. Loss of RV contractility, RV dilatation, and normal estimated pulmonary pressures occur more commonly with RV infarction.
Color flow Doppler transthoracic echocardiography identifies mechanical causes of cardiogenic shock, such as acute mitral regurgitation or ventricular septal defect. Echocardiography detects other causes of decreased cardiac output, notably pulmonary embolism. Acute RV dilatation, tricuspid insufficiency, paradoxical systolic septal motion, and high estimated pulmonary artery and RV pressures suggest pulmonary hypertension from an acute pulmonary embolus.
Mechanical Catastrophe Diagnosis
When suspecting a mechanical catastrophe, consult a cardiothoracic surgeon immediately while obtaining a bedside echocardiogram. In the case of myocardial free wall rupture, death is likely unless a pseudoaneurysm forms, which may present as an acute pericardial effusion on echocardiography. An acute ventricular septal defect appears on color Doppler echocardiography or right heart catheterization by showing oxygen
 saturation flow or step­up from the right atrium to the RV. Acute mitral regurgitation, from papillary muscle rupture or dysfunction, can complicate AMI.
Hemodynamic Monitoring
Patients in cardiogenic shock require continuous monitoring of blood pressure and other hemodynamic measures. Typically, patients with
 ,12,14 cardiogenic shock have a low cardiac index (<2.2 L/min/m ) and elevated LVEDP (pulmonary artery occlusion pressure >15 mm Hg). Cardiac output measurement via pulmonary artery catheterization provides continuous measurements of pulmonary artery occlusion pressure, vascular
,31 resistances, ventricular work, and other hemodynamic parameters. Although numerous trials have assessed the value of pulmonary artery
 catherization in intensive care patients, most have demonstrated no harm, but also no benefit. While noninvasive blood pressure measurements
 may underestimate systolic pressure by >30 mm Hg, mean arterial pressure varies by only  to  mm Hg whether central or peripheral. Arterial blood pressure monitoring allows accurate assessment of cardiovascular instability during resuscitation and is particularly useful when giving vasoactive medications. Central venous pressure, an indirect indicator of central blood volume, can aid assessment of global volume status, but isolated values
 outside extremes to guide resuscitation in critically ill patients are less helpful (see “Hemodynamic Monitoring”).
ED TREATMENT AND STABILIZATION
Elements for the optimal treatment of cardiogenic shock include early evaluation and recognition, integration of hemodynamic and clinical data for initiation of pharmacologic support, and a team­based approach for early PCI intervention and acute mechanical circulatory support devices when indicated.
The most important definitive intervention for acute ischemia­related cardiogenic shock is emergent
,11,14,15,34,65 revascularization. In anticipation of the need for revascularization, EMS should direct any suspected cardiogenic shock patient to a
 facility that has 24­hour full­service emergency cardiac revascularization capability (including a cardiac bypass team). Regionalized systems of care
,68,69 and multidisciplinary shock teams have shown benefits in both outcomes and mortality. Smaller rural and community EDs should consider stabilization and early transfer to tertiary care facilities with specialized critical care services and resources in place to treat this patient population.
Initial ED management focuses on airway stability and improving myocardial pump function to maintain end­organ perfusion while arranging
 definitive care such as revasculariation and early mechanical circulatory support.
AIRWAY
Give supplemental oxygen to keep saturations >91%, and monitor closely for impending or acute respiratory failure that will require immediate mechanical ventilation. Noninvasive ventilation using continuous positive airway pressure, bilevel positive airway pressure, or high­flow nasal cannula can provide temporary airway support.
Endotracheal intubation is often necessary to maintain oxygenation and ventilation. However, the change to positive­pressure ventilation may further decrease preload, decrease cardiac output, and worsen hypotension. Be prepared to administer a fluid bolus in the absence of severe pulmonary congestion and in the presence of RV infarction, while also considering the use of push dose pressors (small discrete doses of
,65 vasopressors) or the initiation of a vasopressor infusion prior to intubation to mitigate the potential hypotensive effects of intubation. Keep endexpiratory pressures and tidal volumes as low as possible (see Chapter 29B, “Mechanical Ventilation”) to avoid impairing preload. Recognize that patients may need additional vasopressor support after positive­pressure ventilation.
STABILIZATION

Continuous cardiac monitoring and IV access are necessary. Correct any hypoxemia, hypovolemia, rhythm disturbances, electrolyte abnormalities, and acid­base alterations rapidly. Although not needed immediately, many benefit from a urinary drainage catheter to follow renal output.

In AMI, give aspirin early (if not already taking long term) unless there is an absolute contraindication. If blood pressure is >90 mm Hg systolic, you may use IV nitroglycerin. Do not use α­blockers or β­blockers in patients with myocardial infarction in cardiogenic shock or
 who are at risk for cardiogenic shock (Table 50­1). Do not use angiotensin­converting enzyme inhibitors or other vasodilators.
HYPOTENSION
Guide initial therapy by the clinical findings. It is reasonable to trial a 250 mL IV crystalloid bolus if pulmonary congestion is absent, or for an RV infarct with hypotension. If there is no improvement with the fluid bolus or if pulmonary congestion develops, use vasopressors (for hypotension) or inotropes (for congestion without profound hypotension) (Table 50­4).
TABLE 50­4
Inotropic and Vasopressor Medications Used in Cardiogenic Shock
Drug Dose Comments
Norepinephrine Initial  micrograms/min, Vasoconstrictor and inotrope; preferred initial therapy in cardiogenic shock with SBP <90. Can use in titrate to response combination with dobutamine.
Dobutamine 2–5 micrograms/kg/min, Inotrope and potential vasodilator; lowers blood pressure; can give as individual agent as long as systolic titrated up to  blood pressure (SBP) ≥90 mm Hg. Can use with norepinephrine. Avoid if on chronic β­blocker therapy micrograms/kg/min
Dopamine 3–5 micrograms/kg/min, 2nd or 3rd line in cardiogenic shock. Inotrope and vasoconstrictor; increases left ventricular end­diastolic titrated up to 20–50 pressure and causes tachycardia. Can use with dobutamine. Increased risk of dysrhythmia, and some micrograms/kg/min as sources suggest increased mortality in shock attributable to cardiogenic shock.
needed
Levosimendan .05­0.2 Inotrope by calcium sensitization. Does not increase myocardial oxygen demand. Use with vasopressor.
microgram/kg/min Particularly useful if patient has been on chronic β­blocker therapy
Epinephrine .1–0.5 microgram/kg/min Inotrope and vasoconstrictor; second tier choice because it causes acidosis and dysrhythmias. Consider in cardiogenic shock with bradycardia.
Milrinone .5 microgram/kg/min Inotrope and vasodilator; lowers blood pressure. Second tier to dobutamine. Use if has been on chronic
β­blocker therapy
Vasopressin .02­0.04 units/min Stimulates V1 receptors in vascular smooth muscle. Can be a useful vasopressor in RV failure.
Inotropes and vasopressors do not change outcome alone but can temporize while the ED team arranges interventions to restore coronary artery
 perfusion and LV function. Current guidelines recommend norepinephrine as the initial vasopressor of choice in cardiogenic shock
,68,71 with systolic blood pressure <  mm Hg. Dobutamine is a useful addition as an inotropic agent but does cause some systemic vasodilation and should not be used in isolation in the setting of hypotension. Dopamine is a vasopressor with dose dependent inotropic and vasoconstrictor effects. It is considered a second­tier choice due to its association with dysrhythmias and potential for increased mortality in patients with cardiogenic
,65 shock. Levosimendan is a phosphodiesterase inhibitor and calcium sensitizer. It exerts its inotropic effect by sensitizing myocardial troponin C to
,71 intracellular calcium and thus increasing contractility. It does not increase myocardial oxygen demand, which is a downside of the catecholamine inotropes. Levosimendan should be paired with a vasopressor.
Epinephrine is associated with more systemic acidosis, tachycardia, and dysrhythmias compared to the combination of norepinephrine and
,39,41 dobutamine. It also increases mortality. Milrinone (a selective phosphodiesterase­3 inhibitor) can be substituted for the catecholamine if dobutamine is ineffective. Patients on β­blocker therapy may have an attenuated response to dobutamine, and thus milrinone is a better choice for them. Pure vasoconstrictors and α ­adrenergic receptor agonists, such as phenylephrine (often a push dose drug), are contraindicated because they
 increase cardiac afterload without augmenting cardiac contractility. In patients with RV failure, such as from decompensated pulmonary hypertension or acute pulmonary embolism, vasopressin may be a useful addition to first­line norepinephrine, as it acts as a peripheral vasopressor and may reduce
 pulmonary vascular resistance.
DEFINITIVE MANAGEMENT
EARLY REVASCULARIZATION
In ischemic cardiogenic shock, early revascularization by percutaneous coronary intervention or coronary artery bypass grafting is
,43 the treatment of choice. The greatest short­term benefit is reported in patients <75 years old, those without previous myocardial infarction, and those treated within  hours of symptom onset. Survival is higher in those receiving early revascularization compared with medical stabilization,
,65,66 ,43,45,46 even in the elderly. Current guidelines do not have an age cutoff for percutaneous coronary intervention.
THROMBOLYTIC THERAPY
Emergency coronary intervention in the catheterization laboratory or operating suite is the preferred definitive treatment for
42­45 cardiogenic shock. Thrombolytic therapy is not as effective in establishing reperfusion in AMI with cardiogenic shock as it is in uncomplicated
AMI. Survival from cardiogenic shock is highest with emergency coronary intervention, followed by intra­aortic balloon pump combined with
,46 thrombolytic therapy; thrombolytic therapy alone is least effective in reducing mortality.
Rescue percutaneous coronary intervention does not convey the same mortality benefit as primary percutaneous coronary intervention for these
,48 patients. If no other definitive treatment modalities for cardiogenic shock are available, if the hospital does not have a catheterization laboratory, or if there is prolonged transport time for coronary intervention, thrombolytics should be considered, but do not delay access to percutaneous
,15,48 coronary intervention.
INTRA­AORTIC BALLOON PUMP COUNTERPULSATION
Intra­aortic balloon pump counterpulsation provides hemodynamic support by decreasing afterload (which lowers myocardial oxygen consumption)
,49 and increasing diastolic blood pressure (which augments coronary perfusion). Intra­aortic balloon pump improves survival after thrombolytic
,51 therapy by augmenting diastolic perfusion pressure and unloading the LV. Outside of those receiving reperfusion, the long­term benefits of intra­
50­53,72 aortic balloon pump use are not clear.
In hospitals without direct angioplasty capability, stabilization with intra­aortic balloon pump and thrombolysis followed by transfer to a tertiary care
,53,54 facility may be the best management option in severe cardiogenic shock.
VENTRICULAR ASSIST DEVICES
When cardiogenic shock is refractory to medical therapy, discuss options for percutaneous mechanical circulatory support with a cardiac intensivist
,69 team. Acute cardiogenic shock devices range from intra­aortic balloon pumps to percutaneous ventricular assist devices to extracorporeal membrane oxygenation, and can aid, maintain, or restore adequate tissue perfusion. Current percutaneous ventricular assist devices include
55­59,72 nonpulsatile (e.g., Impella®, TandemHeart®) and pulsatile versions (e.g., iVAC®, HeartMate®) designed to provide LV unloading. Although the degree of hemodynamic support varies, they can effectively serve as a bridge to long­term devices, such as an LV assist device and/or heart transplantation. (See Video: Left Ventricular Assist Device.)
Video 50­1: Left Ventricular Assist Device (LVAD)
Used with permission from Daniel Renner, MD, University of North Carolina, Chapel Hill, NC; Heather Heaton, MD, University of North Carolina, Chapel Hill, NC.
Play Video
Current LV assist devices are continuous­flow pumps with noncontact bearings (magnetic levitation) to enhance rotation without friction or wear and decrease pump thrombosis and stroke. Increasingly, case studies and small cohort studies have described successful ventricular assist device support
56­60 and weaning of patients suffering from cardiogenic shock in the setting of acute infarction. However, despite current device improvements, there are no data demonstrating a mortality benefit for LV assist devices compared with intra­aortic balloon pumps in patients with cardiogenic shock
58­61,72 refractory to inotropic and vasopressor support; either is a stabilizing bridge to potential transplantation. Complications, including pump thrombosis, stroke, bleeding events, and driveline infection, remain a concern with these interventions.
EXTRACORPOREAL MEMBRANE OXYGENATION
Extracorporeal membrane oxygenation can provide almost total circulatory support for a failing heart. Extracorporeal membrane oxygenation usually follows emergency situations when maximum medical therapy has failed. The Survival After Veno­arterial Extracorporeal Membrane Oxygenation
 score can predict survival in patients receiving extracorporeal membrane oxygenation for refractory cardiogenic shock (www.save­score.com). In the best cases, extracorporeal membrane oxygenation provides support until percutaneous coronary intervention or until the heart begins to recover after intervention. In other cases, it can provide a bridge to decision for transplantation or permanent LV assist device placement.


