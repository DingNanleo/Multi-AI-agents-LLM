## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 176: General Management of Poisoned Patients
Shaun Greene
INTRODUCTION
Content Update: Clarification of single and multidose charcoal May 2020
Clarifications on the use of single­ and multi­dose activated charcoal administration are provided in the text and Tables 176­9 and 176­10. Poisoning is a worldwide problem that consumes substantial healthcare resources and causes many premature deaths. The burden of serious
,2 poisoning is carried by the developing world ; however, poisoning­related morbidity and mortality are also a significant public health concern in the
3–7 developed world.
Unintentional poisoning deaths in the United States are increasing, especially as a result of prescription analgesics. This increase has been ascribed to
8–10 increasing prescription rates and aging of the baby­boom population. Prevention is the key to reducing unintentional poisoning deaths.
Pharmacists can ensure that medications are labeled correctly, anticipate potential drug interactions, and educate patients to use medications safely.
Parents have the responsibility to ensure that poisons are placed in childproof, labeled containers stored in adult­only accessible nonfood storage areas to reduce pediatric exposures. Teachers and healthcare providers can provide age­appropriate education to children about the dangers of poisons. After an exposure, poison control centers staffed by highly trained individuals can provide customized advice to healthcare providers and the public. Poison control centers also participate in prevention, education, and toxico­surveillance activities.
Exposures occur most commonly by ingestion; other routes include inhalation, insufflation, cutaneous and mucous membrane exposure, and
 injection. Some exposures have minimal risk. The criteria used to determine whether the exposure is nontoxic are as follows: (1) an unintentional exposure to a clearly identified single substance, (2) an estimate of the dose is known, and (3) a recognized information source (e.g., a poison control center) confirms the substance as nontoxic in the reported dose. Asymptomatic patients with nontoxic exposures may be discharged after a short period of observation, providing they have access to further consultation and a safe discharge destination.

Serious clinical effects occur in <5% of acutely poisoned patients presenting to developed­world hospitals, and in­hospital mortality rates are <1%.
RESUSCITATION
Resuscitation is the first priority in any poisoned patient. After resuscitation, a structured risk assessment is used to identify patients who may benefit from an antidote, decontamination, or enhanced elimination techniques. Most patients only require provision of good supportive care during a period of observation in an appropriate environment.
Treatment of cardiac arrest in poisoned patients follows Advanced Cardiac Life Support guidelines with the addition of interventions potentially
 beneficial in toxin­induced cardiac arrest (Table 176­1). Prolonged resuscitation is generally indicated, as patients are often young with minimal preexisting organ dysfunction. Utilization of extracorporeal cardiac and respiratory assist devices until organ toxicity resolves may be lifesaving.
Table 176­1
Potential Interventions in Toxin­Induced Cardiac Arrest11
Toxin or Toxin/Drug Class Intervention

Chapter 176: General Management of Poisoned Patients, Shaun Greene 
©2025T MoxcinGs rwaiwth Ha silpl.e Acilfli cR aingthidtso tRe e(esxearmvpelde.s ) Terms of Use * Privacy Policy * Notice * Accessibility Antidote
Digoxin Digoxin Fab
Organophosphates Atropine
Envenomation Antivenom
Sodium channel blocker or wide­complex tachycardia Sodium bicarbonate
Calcium channel blocker or beta­blocker High­dose insulin infusion
Local anesthetic agents IV lipid emulsion
Lipophilic cardiotoxins
Other Therapies to Consider
Cardiac pacing
Intra­aortic balloon pump
Extracorporeal membrane oxygenation
Stabilization of airway, breathing, and circulation represents initial priorities. Compromised airway patency or reduced respiratory drive may lead to inadequate ventilation; provision of a mechanical airway and assisted ventilation is vital in these circumstances. IV crystalloid bolus (10 to  mL/kg) is first­line treatment of hypotension. Since most patients without toxin­induced fluid loss are generally not fluid depleted, avoid administration of excess fluid. Persisting hypotension despite an adequate volume infusion may respond to a specific antidote. Otherwise, cautious administration of an inotropic agent is indicated. Inotrope choice is guided by knowledge of the toxin’s toxicodynamic properties and assessment of circulatory status (e.g., cardiac pump failure vs. vasodilatory shock). Extracorporeal membrane oxygenation should be considered for cases of cardiovascular failure
 refractory to other treatment modalities.
ANTIDOTES
Stabilization of airway, breathing, and circulation allows further assessment of blood glucose concentration, temperature, and conscious state.
Although the proper use of antidotes (Table 176­2) is important, only a few are indicated before cardiopulmonary stabilization (e.g., naloxone for opiate toxicity, cyanide antidotes for cyanide toxicity, and atropine for organophosphate poisoning).
Table 176­2
Common Antidotes Used in Resuscitation of the Acutely Poisoned Patient
Antidote Initial Pediatric Dose* Initial Adult Dose* Indication
Calcium chloride .15 mL/kg IV  mL IV Calcium channel
10% blockers
### .2 milligrams/mL elemental Ca
Calcium gluconate .5–0.45 mL/kg IV 10–30 mL IV Hypermagnesemia
10% Calcium channel
 milligrams/mL blockers elemental Ca
Cyanide antidote Not typically used Crack vial and inhale over  seconds, or place Cyanide kit in chamber of ventilation bag and use  s
Amyl nitrite on/30 s off
Sodium nitrite Dosed according to hemoglobin level. If unknown,  mL IV Cyanide
(3% solution) assume hemoglobin level is  g/dL (120 g/L) and Hydrogen sulfide (use dose with .33 mL/kg IV only sodium nitrite)
Sodium thiosulfate .65 mL/kg IV  mL IV Cyanide
(25% solution)
Dextrose (glucose) .5–1.09 gram/kg IV  gram/kg IV Insulin
Oral hypoglycemics
Digoxin Fab 5–10 vials IV  vials Digoxin and other
Acute toxicity cardioactive steroids
Flumazenil .01 milligram/kg IV .2 milligram IV Benzodiazepines
Glucagon  micrograms/kg IV over 1–2 min for CCB toxicity  milligrams IV Calcium channel and 30–150 micrograms/kg IV over 1–2 min for BB blockers toxicity Beta­blockers
Hydroxocobalamin  milligrams/kg (maximum  grams) IV over  min  grams IV over  min Cyanide
Nitroprusside
IV lipid emulsion .5 mL/kg IV bolus over  min (may be repeated  100­mL IV bolus over  min (may be repeated  Local anesthetic
20% times at 5­min intervals), followed by .25 mL/kg per times at 5­min intervals), followed by  systemic toxicity min IV infusion for  min mL/min IV infusion for  min Rescue therapy for lipophilic cardiotoxins
Methylene blue  milligram/kg IV  milligram/kg IV Oxidizing toxins (e.g.,
Neonates: .3–1.0 milligram/kg IV nitrites, benzocaine, sulfonamides)
Naloxone As much as required As much as required Opioids
Start: .01 milligram IV Start: .1–0.4 milligram IV Clonidine
Pyridoxine Gram for gram if amount of isoniazid ingested is known, otherwise: Isoniazid
 milligrams/kg IV (maximum  grams)  grams IV
Sodium 1–2 mEq/kg IV over 1–2 min followed by .3 mEq/kg per hour IV infusion Sodium channel bicarbonate blockers
Urinary alkalinization
Thiamine 5–10 milligrams IV 100 milligrams IV Wernicke’s syndrome
Wet beriberi
*See specific chapter for details regarding use.
Abbreviations: BB = beta­blockers; CCB = calcium channel blocker.
HYPOGLYCEMIA
Treat hypoglycemia with IV dextrose (glucose). Patients at risk of Wernicke’s encephalopathy also require thiamine, but do not require that it be
 administered before the dextrose. Altered mental status when hypoglycemia cannot be excluded is an indication for IV dextrose. Supplemental oxygen, thiamine, glucose, and naloxone are often administered empirically as a cocktail in cases of altered mental status. Although relatively safe and affordable in the developed world, this approach may not be cost effective in developing countries. The decision to administer an antidote should be made after a rapid collateral history is obtained and targeted examination completed. Altered mental status not responding to an antidote or not consistent with exposure history requires further investigation. Metabolic, infective, and surgical (e.g., intracranial injury) causes of altered mental status should be considered.
CARDIAC ARRHYTHMIAS
In general, antidysrhythmic drugs are not first­line treatment for toxin­induced dysrhythmias, as most antidysrhythmic drugs have prodysrhythmic and negative inotropic properties. Most toxin­induced dysrhythmias respond to correction of hypoxia, metabolic/acid­base abnormalities, and administration of an antidote (e.g., digoxin Fab). Sodium bicarbonate is administered for sodium channel blocker toxicity with cardiovascular complications, such as wide QRS complex tachydysrhythmias. Ventricular tachydysrhythmias may respond to overdrive pacing.
SEIZURES
Drug­induced seizures are treated with titrated doses of IV benzodiazepines, with the exception that isoniazid­induced seizures require pyridoxine.
Metabolic disorders, such as hypoglycemia and hyponatremia, can also produce seizures and should be rapidly excluded. Propofol and barbiturates
 are second­line agents for benzodiazepine­resistant seizures (once isoniazid­induced seizures are excluded). A small study provided evidence for
 the safety of levetiracetam for treatment of toxin­induced seizures; however, larger studies are required to evaluate efficacy. There is no role for
 phenytoin in the treatment of toxin­induced seizures; it has neither theoretical nor proven efficacy, and it may worsen toxicity.
AGITATION
Agitation is treated with titrated doses of benzodiazepines. See Figure 287­1, Acute Agitation. Large doses may be required and are appropriate in monitored settings where advanced airway interventions are available if required. Although antipsychotic agents are often used as second­line agents
,18 for toxin­induced agitation, they have theoretical disadvantages, including anticholinergic and extrapyramidal effects. First generation antipsychotics, such as haloperidol have been associated with QT­interval prolongation and cardiac dysrhythmias; however, the incidence of adverse effects appears to be very low.
HYPERTHERMIA AND HYPOTHERMIA
Patients with core temperatures of >39°C (>102.2°F) require aggressive active cooling measures to prevent complications such as rhabdomyolysis, organ failure, and disseminated intravascular coagulation. Sedation, neuromuscular paralysis, and intubation are required if active measures are ineffective. Several toxidromes associated with hyperthermia are treated with specific pharmaceutical agents: sympathomimetic (benzodiazepines),
  serotonin (cyproheptadine ), and neuromuscular malignant syndrome (bromocriptine ).
Drug­induced coma with subsequent immobility and environmental exposure or inherent drug toxicity (opioids, phenothiazines, ethanol) may produce hypothermia. A core temperature <32°C (<90°F) is an indication for active rewarming.
NALOXONE

Naloxone is a nontoxic, diagnostic, and therapeutic antidote. It is a competitive opioid antagonist administered IV, IM, or intranasally to reverse opioid­induced deleterious hypoventilation. Naloxone can be used as a diagnostic agent when history and/or examination findings (respiratory rate of
<12 breaths/min is a predictor of response to naloxone) suggest possible opioid exposure. Naloxone is titrated to clinical effect using bolus doses, typically .1 to .4 milligram. Large initial bolus doses may precipitate vomiting and aspiration, acute opioid withdrawal, or an uncooperative, agitated patient. Miosis is an unreliable indicator of naloxone’s adequate clinical effect, as some opioids do not affect pupil size. Doses are titrated to achieve desirable ventilation and conscious state (adequate respiratory rate, normal arterial oxygen saturations on room air, and verbal or motor response to voice). Although naloxone may reverse the effects of opioids for  to  minutes, the effect of many opioids will outlast this time frame with possible return of respiratory depression. Patients should be observed for  to  hours after administration of IV naloxone.
IV LIPID EMULSION
IV lipid emulsion has been postulated to provide an intravascular “lipid sink,” sequestrating lipophilic toxins and preventing target receptor
 interaction. IV lipid emulsion should be used as part of management of cardiac arrest in bupivacaine toxicity. Current evidence does not support IV lipid emulsion as first­line treatment of life­threatening toxicity associated with other drugs, including amitriptyline, calcium channel antagonists, non–
 lipid­soluble beta­receptor antagonists, cocaine, diphenhydramine, lamotrigine, bupropion, malathion, and cocaine. IV lipid emulsion therapy may
 affect common laboratory analyses, which may potentially lead to unintentional treatment errors. IV lipid emulsion therapy may cause fat deposition
 in extracorporeal membrane oxygenation circuits and increase blood clot formation. Currently, IV lipid emulsion can be considered as a potential rescue therapy in life­threatening cardiotoxicity caused by lipophilic cardiotoxins that is resistant to conventional therapies.
ASSESSMENT
Following initial resuscitation and stabilization, a risk assessment is performed to predict course of clinical toxicity, interventions required, and patient disposition. Risk assessment is formulated using history, examination, and ancillary test results. Acute poisoning is a dynamic process; therefore, risk assessment may change with time and requires ongoing review.
HISTORY
Patients may not provide a clear history due to psychiatric illness, clinical effects of exposure, and fear of arrest or repercussions from family or friends. Information including identity of substances, doses, and route of exposure is crucial in formulating a risk assessment. Obtain collateral information from family, friends, previous medical records, and usual healthcare provider. Prehospital emergency services can provide information regarding empty medication containers or the scene environment (smells, particular materials or substances present). If possible, obtain knowledge of hobbies, occupation, presence of a suicide note, and recent changes in patient behavior.
EXAMINATION
A systematic physical examination can yield important clues to the nature and potential severity of an exposure (Table 176­3). Examine the skin folds, body cavities if appropriate, and clothing for retained tablets or substances.
Table 176­3
Examination of the Poisoned Patient
Organ System Examination Example of Finding (Possible Significance)
General Mental state and dress Unkempt (psychiatric illness)
Signs of injury Scalp hematoma (intracranial injury)
Odors Malnourished (IV drug use, human immunodeficiency virus infection)
Nutritional state Smell of bitter almonds (cyanide toxicity)
Vital signs
CNS Conscious state Miosis (opioids, organophosphates, phenothiazines, clonidine intoxication)
Pupil size and reactivity Nystagmus/ataxia (anticonvulsant and ethanol toxicity)
Eye movements
Cerebellar function/gait
Cardiovascular Heart rate/blood pressure Murmur (endocarditis/IV drug use)
Cardiac auscultation
Respiratory Oxygen saturation Fever/crepitations/hypoxia (aspiration pneumonia)
Respiratory rate Bronchorrhea/crepitations/hypoxia (organophosphate toxicity)
Chest auscultation
GI Oropharynx Urinary retention (anticholinergic toxicity)
Abdomen Oral cavity burns (corrosive ingestion)
Bladder Hypersalivation (cholinergic toxidrome)
Peripheral nervous Reflexes Tremor/fasciculations (lithium toxicity)
Tone “Lead pipe” rigidity (neuromuscular malignant syndrome)
Fasciculations Clonus/hyperreflexia (serotonin toxicity)
Tremor
Clonus
Dermal/peripheral Bruising Bruising (coagulopathy, trauma, coma)
Cyanosis Flushing/warm, dry skin (anticholinergic toxicity)
Flushing Warm, moist skin (sympathomimetic toxicity)
Dry/moist skin Bullae (prolonged coma, barbiturates)
Injection sites
Bullae
TOXIDROMES
Substances belonging to a particular pharmaceutical or chemical class often produce a cluster of symptoms and signs, or “toxidrome” (Table 176­4), enabling the identification of potential toxins when a clear history is unavailable.
Table 176­4
Common Toxidromes
Toxidrome Examples of Agents Examination Findings (most common in bold)
Anticholinergic Atropine, Datura spp., Altered mental status, mydriasis, dry flushed skin, urinary retention, decreased bowel antihistamines, antipsychotics sounds, hyperthermia, dry mucous membranes
Seizures, arrhythmias, rhabdomyolysis
Cholinergic Organophosphate and carbamate Salivation, lacrimation, diaphoresis, vomiting, urination, defecation, bronchorrhea, muscle insecticides fasciculations, weakness
Chemical warfare agents (sarin, VX) Miosis/mydriasis, bradycardia, seizures
Ethanolic Ethanol CNS depression, ataxia, dysarthria, odor of ethanol
Extrapyramidal Risperidone, haloperidol, Dystonia, torticollis, muscle rigidity phenothiazines Choreoathetosis, hyperreflexia, seizures
Hallucinogenic Phencyclidine Hallucinations, dysphoria, anxiety
Psilocybin, mescaline Nausea, sympathomimetic signs
Lysergic acid diethylamide
Hypoglycemic Sulfonylureas, insulin Altered mental status, diaphoresis, tachycardia, hypertension
Dysarthria, behavioral change, seizures
Neuromuscular Antipsychotics Lead­pipe muscle rigidity, bradyreflexia, hyperpyrexia, altered mental status malignant Autonomic instability, diaphoresis, mutism, incontinence
Opioid Codeine, heroin, morphine Miosis, respiratory depression, CNS depression
Hypothermia, bradycardia
Salicylate Aspirin Altered mental status, respiratory alkalosis, metabolic acidosis, tinnitus, tachypnea,
Oil of wintergreen (methyl tachycardia, diaphoresis, nausea, vomiting salicylate) Hyperpyrexia (low grade)
Sedative/hypnotic Benzodiazepines CNS depression, ataxia, dysarthria
Barbiturates Bradycardia, respiratory depression
Serotonin SSRIs Altered mental status, hyperreflexia and hypertonia (>lower limbs), clonus, tachycardia,
MAOIs diaphoresis
Tricyclic antidepressants Hypertension, flushing, tremor
Amphetamines
Fentanyl
St. John’s wort
Sympathomimetic Amphetamines Agitation, tachycardia, hypertension, hyperpyrexia, diaphoresis
Cocaine Seizures, acute coronary syndrome
Cathinones
Abbreviations: MAOI = monoamine oxidase inhibitor; SSRI = selective serotonin reuptake inhibitor.
DIAGNOSTIC TESTING
A serum acetaminophen concentration is a routine screening test in poisoned patients because early acetaminophen poisoning is often asymptomatic and does not have a readily identifiable toxidrome at the time when antidotal treatment is most efficacious. Acetaminophen screening is especially important in patients presenting with altered mental status or a self­harm ingestion, for whom an accurate history may not be available.
An ECG is a useful test to detect cardiac conduction abnormalities and identify patients at increased risk of toxin­induced adverse cardiovascular
 events.
Measurement of drug or toxin concentrations in body fluids is not required in most poisonings, but in some exposures, measurement of serum drug concentrations does influence management (Table 176­5).
Table 176­5
Drug Serum Measurements That May Assist Patient Assessment or Management
Acetaminophen Methemoglobin
Carbamazepine Methotrexate
Carbon monoxide Paraquat
Digoxin Phenobarbital
Ethanol Phenytoin
Ethylene glycol Salicylate
Iron Theophylline
Lithium Valproic acid
Methanol

Toxicologic screening tests of urine can be done in a central laboratory or performed with point­of­care assays. Urine drug screens most often use enzyme­immunoassays to detect typical drugs within each class. Cross­reactivity is common and some drugs within the class may not be detected
(Table 176­6). Dilute urine can make it difficult to detect low levels. Because some drugs are present in urine for an extended period of time, the positive test may not be related to the current clinical condition. Urine drug screen results seldom influence patient management in most adult overdoses and poisoning.
Table 176­6
Standard Enzyme­Immunoassay Urine Drug Screens
Drugs not in this class possibly Drugs in this class possibly not
Class (drugs typically tested) Comments detected (false positives)+ detected (false negatives)
Amphetamine and Amantadine Methylenedioxy­methylamphetamine Detectable up to  h after
Methamphetamine Bupropion [MDMA] single use
Chlorpromazine
Desipramine
Dimethylamylamine
Ephedrine
Fluoxetine
Isoxsuprine
Labetalol
Metformin
Phentermine
Phenylephrine
Phenylpropanolamine
Promethazine
Pseudoephedrine
Ranitidine
Selegiline
Thioridazine
Trazodone
Trimethobenzamide
Trimipramine
Barbiturates Ibuprofen N/A Detectable up to:
Naproxen Short­acting:  h
Long­acting:  d
Benzodiazepines (oxazepam, Oxaprozin Alprazolam Detectable up to: nordiazepam) Sertraline Clonazepam Short­acting:  days
Flunitrazepam Long­acting:  d
Lorazepam
Triazolam
Cannabinoids (delta­9­ Efavirenz Nabilone Detectable up to: tetracannabinol­9­carboxylic acid) Ibuprofen Synthetic cannabinoids (e.g., “K2” or Single use:  d
Naproxen “spice”) Moderate use: 5–7 d
Pantoprazole Daily use: 10–15 d
Promethazine Long­term use: >  d
Cocaine (benzoylecgonine) * * Detectable 2–4 d after single use
Methadone Chlorpromazine N/A Detectable up to  d
Clomipramine
Diphenhydramine
Doxylamine
Ibuprofen
Quetiapine
Thioridazine
Verapamil
Opiates (morphine, 6­ Dextromethorphan Buprenorphine Detectable 2–4 d acetylmorphine) Diphenhydramine Fentanyl depending on specific drug
Fluoroquinolones (ciprofloxacin, Meperidine levofloxacin, ofloxacin) Methadone
Poppy seed and oil Oxycodone
Rifampin Oxymorphone
Quinine Tramadol
Phencyclidine Dextroamphetamine N/A Detectable up to  d after
Dextromethorphan single use
Diphenhydramine
Doxylamine
Ibuprofen
Ketamine
Lamotrigine
Meperidine
Methylendioxyprovalerone
Thioridazine
Tramadol
Venlafaxine
Tricyclic Antidepressants Carbamazepine Clomipramine Detectable 2–7 days
Cyclobenzaprine
Cyproheptadine
Diphenhydramine
Hydroxyzine
Oxcarbazepine
Promethazine
Quetiapine
Thioridazine
Abbreviation: N/A = not applicable.
*Cocaine immunoassay is highly specific with low cross­reactivity.
+Agents with strongest evidence for false­positive results noted in bold.
Toxicologic screening may be appropriate for medicolegal reasons, especially in pediatric cases when inappropriate drug administration or nonaccidental injury is suspected. A positive urine drug screen for an illicit substance is an indication to involve local child protection services.
DECONTAMINATION
Decontamination is required for toxic exposures affecting large dermal areas. Healthcare providers wearing personal protective equipment
(if indicated) or observing universal precautions (gown, gloves, eye protection) should assist with undressing and washing the patient using copious amounts of water. Contaminated clothing is collected, bagged, and properly disposed. Decontamination ideally occurs in a separate area adjacent to the ED, minimizing cross­contamination.
OCULAR DECONTAMINATION
Eye exposures may require local anesthetic (e.g., .5% tetracaine) instillation and lid retractors to facilitate copious irrigation with crystalloid solution.
Alkalis produce greater injury than acids due to deep tissue penetration via liquefaction so that prolonged irrigation (1 to  hours) may be required.
Ten minutes after irrigation (allowing equilibration of crystalloid and conjunctival sac pH), conjunctival sac pH is tested. Irrigation continues until pH is between .2 and .4. Ophthalmologic consultation is indicated for all ocular alkali injuries.
GI DECONTAMINATION
Gastric decontamination is not a routine part of poisoned patient management; there is minimal evidence demonstrating positive benefit, and there are associated complications (Table 176­7). Gastric decontamination may be considered in individual patients after a three­question risk­benefit analysis: (1) Is this exposure likely to cause significant toxicity? (2) Is GI decontamination likely to change clinical outcome? (3) Is it possible that GI
,28 decontamination will cause more harm than good?
Table 176­7
Indications, Contraindications, and Complications of GI Decontamination Procedures
Orogastric Lavage
Indications Rarely indicated
Consider for recent (<1 h) ingestion of life­threatening amount of a toxin for which there is no effective treatment once absorbed
Contraindications Corrosive/hydrocarbon ingestion
Supportive care/antidote likely to lead to recovery
Unprotected airway
Unstable, requiring further resuscitation (hypotension, seizures)
Complications Aspiration pneumonia/hypoxia
Water intoxication
Hypothermia
Laryngospasm
Mechanical injury to GI tract
Time consuming, resulting in delay instituting other definitive care
Activated Adults  grams orally, children  gram/kg orally
Charcoal
Indications Ingestion within the previous hour of a toxic substance known to be adsorbed by activated charcoal, where the benefits of administration are judged to outweigh the risks
Contraindications Nontoxic ingestion
Toxin not adsorbed by activated charcoal
Recovery will occur without administration of activated charcoal
Unprotected airway
Corrosive ingestion
Possibility of upper GI perforation
Complications Vomiting
Aspiration of the activated charcoal
Impaired absorption of orally administered antidotes
Whole­Bowel Polyethylene glycol  L/h in adults, children  mL/kg per hour (maximum  L/h)
Irrigation
Indications Iron ingestion >60 milligrams/kg with opacities on abdominal radiograph
(potential) Life­threatening ingestion of diltiazem or verapamil
Body packers or stuffers
Slow­release potassium ingestion
Lead ingestion (including paint flakes containing lead)
Symptomatic arsenic trioxide ingestion
Life­threatening ingestions of lithium
Contraindications Unprotected airway
GI perforation, obstruction or ileus, hemorrhage
Intractable vomiting
Cardiovascular instability
Complications Nausea, vomiting
Pulmonary aspiration
Time consuming; possible delay instituting other definitive care
Emesis
Traditionally, ipecac syrup was administered to induce vomiting, theoretically emptying the stomach of poisons. No published evidence supports the
 induction of emesis, and adverse outcomes associated with emesis are documented. There is no role for the induction of emesis in the ED in
 the poisoned patient.
Orogastric Lavage
Once a widely practiced intervention, attempted removal of ingested toxin from the stomach by aspiration of fluid placed via an orogastric tube is now rarely indicated. No published evidence demonstrates that orogastric lavage changes outcome in the majority of poisoned patients, and the procedure
 has numerous complications. Gastric lavage may be considered in cases of ingestion of a life­threatening amount of poison within the previous hour where institution of supportive care and antidotal therapy would not ensure full recovery. Adherence to best­practice principles can minimize complications from orogastric lavage (Table 176­8).
Table 176­8
Principles to Minimize Complications From Orogastric Lavage
Ensure a protected airway if consciousness level is reduced.
Use a 36F­ to 40F­gauge orogastric tube (22F to 24F in children).
Position the patient on the left side with the head down  degrees.
Pass lubricated tube down the esophagus a distance equal to that between chin and xiphoid process.
Confirm tube position by insufflation of air.
Gently lavage with 200 mL (10 mL/kg in children) of warm tap water, allowing drainage after each aliquot.
Continue until returned fluid is clear.
Consider administration of activated charcoal via orogastric tube before removal.
Single­Dose Activated Charcoal
Super­heating carbonaceous material produces activated charcoal, a highly porous substance, which is suspended in solution and given PO as a
 slurry. Toxins within the GI lumen are adsorbed onto the activated charcoal and carried through the GI tract, limiting absorption. Activated charcoal does not effectively adsorb metals, corrosives, and alcohols. The decision to give activated charcoal requires individual patient risk assessment and is
 not routinely indicated following all oral exposures.
Activated charcoal may be effective in reducing GI absorption when given >60 minutes after ingestion of a potentially toxic amount of substances with
 serious toxicity anticipated; those known to slow GI motility (e.g., anticholinergics) ; ingestion of substances which adsorb charcoal for which there is no effective antidote; ingestion of a sustained release product; cooperative patient with intact airway; after massive ingestion of a substance associated with bezoar formation (e.g., salicylates). (Table 176­9) Activated charcoal mixed with ice cream improves palatability for children. Activated charcoal can be administered to intubated patients using an orogastric or nasogastric tube. The initial dose in adults in adults is  grams PO. The dose in children is  gram/kg PO and in adults is  grams PO.
Table 176­9. Agents that Form Bezoars, Delay Gastric Emptying, or Cause Pylorospasm
Anticholinergics Iron
Barbiturates Meprobamate
Bromides Methaqualone
Carbamazepine Opioids
Carisodoprol Phenytoin
Enteric­Coated Tablets Calcium Channel Blockers
Extended Release Preparations(acetaminophen,quetiapine) Salicylates
Glutethimide
​​​​​Multiple­dose activated charcoal is generally recommended for toxic ingestions listed in Table 176­9. The Initial dose is  grams PO followed by  grams PO every  hours.
Whole­Bowel Irrigation
Polyethylene glycol is an osmotically balanced electrolyte solution. Administration in large quantities mechanically forces substances through the GI
 tract, limiting toxin absorption. Polyethylene glycol can be administered orally to cooperative, awake patients, but consider formal airway control if consciousness is likely to deteriorate. Minimize risk of pulmonary aspiration during whole­bowel irrigation by patient positioning (head up  degrees), ensuring bowel sounds are present during fluid administration, 1:1 nursing with suctioning of the oral cavity during infusion, and utilization of cuffed endotracheal tubes.

Evidence supporting whole­bowel irrigation is limited to volunteer studies and case reports from which potential indications have been developed
(Table 176­7). Nonsurgical treatment of asymptomatic body drug packers using whole­bowel irrigation is increasingly common, although no
 randomized clinical trials exist. An antiemetic such as the prokinetic agent metoclopramide may be required to control polyethylene glycol–induced gastric distention and vomiting. The end point of whole­bowel irrigation treatment is clear rectal effluent and imaging demonstrating absence of foreign bodies.
ENHANCED ELIMINATION
MULTIDOSE ACTIVATED CHARCOAL
Multidose activated charcoal increases elimination of toxins with enteroenteric, enterohepatic, or enterogastric recirculation. Lipophilic drugs with low volume of distribution, protein binding, and molecular weight may pass down a concentration gradient between intravascular space and activated charcoal in the gut lumen. Multidose activated charcoal may also adsorb residual intraluminal toxins; this is more likely for substances slowing gastric motility or forming bezoars (Table 176­10). Although animal studies, volunteer studies, case reports, and case series demonstrate increased elimination rates (in some cases comparable to those of hemodialysis or charcoal hemoperfusion) of carbamazepine, dapsone, phenobarbital,
 phenytoin, quinine, colchicine, and theophylline, there is limited evidence that multidose activated charcoal changes clinical outcome.
Table 176­10
Indications, Contraindications, and Complications of Enhanced Elimination Procedures
Multidose Activated Initial dose:  grams (1 gram/kg children), repeat dose of  grams (0.5 gram/kg children) every
Charcoal  hours
Indications Carbamazepine coma (reduces duration of coma)
Phenobarbital coma (reduces duration of coma)
Dapsone toxicity with significant methemoglobinemia
Quinine overdose
Theophylline overdose if hemodialysis/hemoperfusion unavailable
Colchicine
Agents that form bezoars, delay gastric emptying, or cause pylorospasm.
Contraindications Unprotected airway
Bowel obstruction
Caution in ingestions resulting in reduced GI motility
Complications Vomiting
Pulmonary aspiration
Constipation
Charcoal bezoar, bowel obstruction/perforation
Urinary Alkalinization
Indications Moderate to severe salicylate toxicity not meeting criteria for hemodialysis
Phenobarbital (multidose activated charcoal superior)
Chlorophenoxy herbicides (2­4­dichlorophenoxyacetic acid and mecoprop): requires high urine flow rate of 600 mL/h to be effective
Chlorpropamide: supportive care/IV dextrose normally sufficient
Contraindications Preexisting fluid overload
Renal impairment
Uncorrected hypokalemia
Complications Hypokalemia
Volume overload
Alkalemia
Hypocalcemia (usually mild)
Multidose activated charcoal may be administered by an orogastric or nasogastric tube to intubated patients. Regular aspiration of stomach contents helps avoid gastric distention. Multidose activated charcoal should not be given when bowel sounds are absent. Continued requirement for further multidose activated charcoal should be reviewed regularly during therapy.
URINARY ALKALINIZATION
Alkaline urine favors ionization of acidotic drugs within renal tubules, preventing resorption of the ionized drug back across the renal tubular
 epithelium and enhancing elimination through the urine. Urinary alkalinization is most effective for weak acids primarily eliminated by the renal tract that are also readily filtered at the glomerulus and have small volumes of distribution. Hypokalemia will reduce the effectiveness of urinary alkalinization (Table 176­11). The primary indication for urinary alkalinization is moderate to severe salicylate toxicity when criteria for hemodialysis have not been met.
Table 176­11
Protocol for Urinary Alkalinization in Adults With Normal Renal Function
Correct existing hypokalemia.
Administer a  to  mEq/kg IV sodium bicarbonate bolus.
Infuse 100 mEq of sodium bicarbonate mixed with  L of D W at 250 mL/h.

 mEq of potassium chloride may be added to the solution to maintain normokalemia.
Monitor serum potassium and bicarbonate every 2–4 h to detect hypokalemia or excessive serum alkalinization.
Check urine pH regularly (every 15–30 min); goal is a pH of .5–8.5. A further IV bolus of  mEq/kg of sodium bicarbonate may be necessary if sufficient alkalinization of the urine is not achieved.
Abbreviation: D W = 5% dextrose in water.

Although urinary acidification can enhance the elimination of weak bases including amphetamines and phencyclidine, associated risks (e.g., rhabdomyolysis) outweigh potential benefit. Forced diuresis has no indication for any poisoning, with the exception of chlorophenoxy herbicides (see
Chapter 201, “Pesticides”).
EXTRACORPOREAL REMOVAL
Extracorporeal removal techniques, including hemodialysis, hemoperfusion, and continuous renal replacement therapies, have limited indications in poisoned patients (Table 176­12). These procedures require a critical care setting, are expensive and invasive, are not always available, and have
 complications. Extracorporeal removal techniques were used in .13% of cases reported to U.S. poison control centers in 2016. Table 176­12
Indications, Contraindications, and Complications of Extracorporeal Removal Techniques
Hemodialysis Movement of solute down a concentration gradient across a semipermeable membrane
Toxin requirements Low volume of distribution, low protein binding, low endogenous clearance, low molecular weight
Indications Life­threatening poisoning by:
Lithium
Phenobarbital
Salicylates
Valproic acid
Methanol/ethylene glycol
Metformin­induced lactic acidosis
Potassium salts
Theophylline
Contraindications Hemodynamic instability
Infants (generally)
Poor vascular access
Significant coagulopathy
Hemoperfusion Movement of toxin from blood, plasma, or plasma proteins onto a bed of activated charcoal (or other adsorbent)
Toxin requirements Low volume of distribution, low endogenous clearance, bound by activated charcoal
Indications Life­threatening poisoning caused by:
Theophylline (high­flux hemodialysis is an alternative)
Carbamazepine (multidose activated charcoal or high­efficiency hemodialysis also effective)
Paraquat (theoretical benefit only if instituted early after exposure)
Contraindications Hemodynamic instability
Infants (generally)
Poor vascular access
Significant coagulopathy
Toxin not bound to activated charcoal
Continuous Renal Movement of toxin and solute across a semipermeable membrane in response to hydrostatic
Replacement Therapies gradient. Can be combined with dialysis.
Indications (potential) Life­threatening ingestions of toxins when hemodialysis or hemoperfusion is indicated but is unavailable or hemodynamic instability precludes their utilization
Contraindications Hemodialysis or hemoperfusion is available
Poor vascular access
Significant coagulopathy
Complications of Extracorporeal Removal Techniques
Fluid/metabolic disruption Limited by hypotension (not continuous renal replacement therapy)
Removal of antidotes Infection/bleeding at catheter site
Limited availability Intracranial hemorrhage secondary to anticoagulation
A toxin must possess a number of properties to be effectively removed by an extracorporeal technique in a clinically meaningful time frame: low
 volume of distribution (<1.0 L/kg), low molecular weight (<500 Da), relatively low protein binding, and low endogenous clearance. In general, extracorporeal removal must improve endogenous clearance rate by >30% to be clinically beneficial. Hemoperfusion uses a charcoal (or other adsorbent) filter, which comes into direct contact with blood, partially overcoming molecular weight and protein­binding limitations.
Continuous renal replacement therapies (including venovenous hemofiltration and venovenous hemodiafiltration) are widely available and easily
 instituted in most hospitals. However, there is sparse evidence demonstrating any benefit in poisoning, primarily due to slow clearance rates. A patient who requires extracorporeal removal should undergo hemodialysis or hemoperfusion, if available. Continuous renal replacement therapy can
 be used if hemodialysis or hemoperfusion is unavailable or will not be tolerated (e.g., due to hypotension). Extracorporeal removal techniques including high­flux hemodialysis are constantly evolving, so discussion with an intensivist or nephrologist may be beneficial when this approach is considered. Expert consensus advice regarding optimum extracorporeal elimination techniques for individual toxins have been published by the

Extracorporeal Treatments in Poisoning group.
DISPOSITION
Planning for patient disposition from the ED should be part of initial risk assessment. Admission is indicated if the patient has persistent and/or severe toxic effects or will require a prolonged course of treatment. In most cases, a 6­hour observation period is sufficient to exclude the development of serious toxicity. Onset of clinical toxicity can be delayed after a number of exposures, including (but not limited to) modified­release preparations of calcium channel blockers, selective norepinephrine reuptake inhibitors (tramadol, venlafaxine), and newer antipsychotics (amisulpride); hence, a period of extended observation is indicated. In the developed world, toxicity will resolve within  hours in most poisoned patients requiring noncritical care inpatient management, and so these patients can be efficiently and safely managed in a toxicology or short­stay ward, if available.
Patients who have deliberately self­poisoned require appropriate mental health assessment before disposition.


