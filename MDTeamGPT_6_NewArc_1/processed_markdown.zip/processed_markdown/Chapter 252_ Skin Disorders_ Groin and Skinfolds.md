## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 252: Skin Disorders: Groin and Skinfolds
Alexandra E. Zeitany; Diana B. McShane; Dean S. Morrell
INTRODUCTION
Content Update October 2021
2021 CDC guidelines for Scabies and Pediculosis Pubis. See Table 252­1 and related text. (Centers for Disease Control and Prevention, Sexually
Transmitted Treatment Guidelines, July , 2021.)
The skinfolds of the body include the groin, intergluteal cleft, axilla, inframammary, and pannus regions. Although many skin diseases can affect the skinfolds to some degree, this chapter focuses on the most common skinfold eruptions (Table 252­1). Sexually transmitted infections are discussed in Chapter 153, “Sexually Transmitted Infections”. Molluscum contagiosum is discussed in Chapter 251, “Skin Disorders: Trunk”.
TABLE 252­1
Clinical Features and Treatment of Common Disorders of Groin and Skinfolds
Condition Clinical Features Treatment Comments
Tinea cruris Symmetric, annular, erythematous, scaly Topical antifungals for 1–6 wk Permanent cure is rare, patients require plaques periodic re­treatment
Candidiasis Well­demarcated erythema and Topical antifungals; oral fluconazole if Predisposing factors including obesity maceration with satellite pustules recalcitrant and/or recent oral antibiotics and endocrine disease such as diabetes involving the skinfolds or Cushing’s syndrome
Scabies Widespread, highly pruritic, erythematous Permethrin 5% cream (safe in pediatric patients A negative scabies prep does not rule papules; other common locations: older than  months) and apply from beck out this diagnosis; immunocompetent intergluteal cleft, digital web spaces, axilla, down, wash after  h hosts typically harbor less than  waistband Machine wash and machine dry any clothing, mites
Look closely for burrows: fine, thread­like linens, or towels that were worn in  days prior lines with a terminal black speck to treatment
Or
Ivermectin 1% lotion applied from neck down, rinse after  h
Or
Consider oral ivermectin for immunocompromised patients or refractory cases 200 micrograms/kg
PO repeated in  d do not use in pregnant or lactating mothers or children <15 kg
Pediculosis Erythematous macules or papules ± Permethrin 1% cream, apply to affected areas, Approximately 30% of those found to
 pubis wheals and inguinal lymphadenopathy wash off in  minutes. have pediculosis pubis also have
Chapter 252: Skin Disorders: Groin and Skinfolds, Alexandra E. Zeitany; Diana B. McShane; Dean S. Morrell 
Look closely for lice and nits Or concomitant infection with another
. Terms of Use * Privacy Policy * Notice * Accessibility
Pyrethrin piperonyl butoxide, apply to affected sexually transmitted infection areas, wash off in  mins Lindane not recommended. Ivermectin
Machine wash and machine dry any clothing, has limited ovicidal activity. Malathion linens, or towels that were worn in  days prior only for treatment failure, has bad odor.
to treatment Treat all sexual partners; notify all For eyelashes, apply petroleum jelly to sexual partners within the past  months eyelid margins bid x 10d
Seborrheic Erythematous plaques with loose greasy Antifungal shampoos or creams ± low­potency There is no cure, and the condition is dermatitis scale topical corticosteroid creams (hydrocortisone, expected to wax and wane desonide)
Intertrigo Erythema/erosions of opposing skin Conservative measures aimed at eliminating Diagnosis of exclusion; consider surfaces friction, moisture streptococcal infection, Candida, irritant
Barrier creams such as Desitin® dermatitis
May require antifungal treatment as it is often superinfected with Candida
Avoid combination antifungal–topical steroid creams as these often contain mid­potency steroids that are too strong for use in intertriginous areas
Hidradenitis Firm, tender nodules and abscesses often For acute flares: intralesional triamcinolone Because this is a chronic disease with suppurativa with extensive scarring and sinus tract injections or oral antibiotics (doxycycline or many social and psychological formation; often also found in axilla, combination therapy with clindamycin and implications, refer to dermatology and inframammary folds, and under the panus rifampin) plastic surgery for long­term management
The skinfolds have unique characteristics that set them apart from other regions of the body. For one, these areas are almost continuously occluded.
As a result, scale does not develop; maceration and fissuring develop instead. This situation alters the appearance of papulosquamous diseases and inflammatory processes. The occlusion also allows for the development of a warm, moist environment favorable to the growth of fungi, yeast, and bacteria.
An important point for treatment of intertriginous diseases is avoiding combination corticosteroid and antifungal products.
Although processes in the groin folds can be confusing and complicated by secondary change, using combination products may further cloud the clinical picture. If improvement is seen after application of combined products, it is difficult to determine which medication prompted the change.
Finally, the corticosteroid component of combined medications is too strong to be used in the occluded intertriginous skin and may produce
,2 irreversible striae with long­term use. Chronic use of potent topical corticosteroids should be followed by a dermatologist.
TINEA CRURIS
Tinea cruris is a fungal infection of the groin commonly called jock itch. It is very common in males, uncommon in females, and exceedingly rare in children. Tinea cruris results from invasion of the stratum corneum by the dermatophyte types of fungi (see Table 253­4). It is transmitted via direct contact (person to person or animal [usually kittens or puppies] to person) or fomites.
Lesions are characterized by symmetric erythema with a peripheral annular slightly scaly edge (Figure 252­1). The groin is typically involved, and the process may extend onto the inner thighs and even the buttocks. The penis and scrotum are typically spared, a distinguishing feature of tinea cruris because most other eruptions will affect the scrotum. Frequently, tinea pedis is also present, and the infection may spread from the feet to the groin when putting on clothes.
FIGURE 252­1. Tinea cruris. Note raised, sharp­edged margins. [Photo contributed by University of North Carolina Department of Dermatology.]
Scraping the leading edge and performing a potassium hydroxide examination will demonstrate branching hyphae, unless the patient has recently applied topical antifungal preparations.
Treatment is with antifungal creams, such as clotrimazole, ketoconazole, or econazole, twice a day (Table 252­2). Start with clotrimazole because it is low cost and available without a prescription. Econazole also has antibacterial properties and is preferred if maceration is present. Keep the affected area as cool and dry as possible, and recommend loose­fitting clothing. Use an antifungal powder daily to prevent recurrences. Recommend follow­up with a primary care provider or dermatologist if the eruption has not resolved in  to  weeks.
TABLE 252­2
Commonly Used Topical Antifungal Preparations
Generic Trade Formulations Status
Clotrimazole Lotrimin® 1% cream or solution OTC
Mycelex® 1% solution OTC
Ketoconazole Nizoral®; Xolegel® gel; Kuric gel® 2% cream, shampoo, gel Prescription
Econazole Spectazole 1% cream Prescription
Miconazole Zeasorb AF® 2% cream or powder OTC
Abbreviation: OTC = over the counter (no prescription required in United States).
CUTANEOUS CANDIDIASIS
Candidal infections of the skin favor moist, occluded areas of the body. Superficial Candida infections are commonly seen in the diaper area of infants, vulva and groin of women, glans penis (balanitis) of uncircumcised males, and inframammary and pannus folds of obese patients. Antibiotic therapy, systemic corticosteroid therapy, urinary or fecal incontinence, immunocompromised states, poorly controlled diabetes mellitus, and obesity are predisposing factors. Women with vulvar or inner thigh involvement will often have vaginal candidiasis as well. Frequently, Candida infection may complicate other inflammatory intertriginous disorders.
The typical presentation is erythema and maceration with peripheral small erythematous papules or satellite pustules (Figure 252­2). The rim of satellite pustules helps to distinguish Candida infection from other eruptions of the skinfolds.
FIGURE 252­2. Cutaneous candidiasis with satellite papules and pustules. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color
Atlas & Synopsis of Clinical Dermatology, 5th ed. © 2005, McGraw­Hill, New York.]
A potassium hydroxide preparation of the pustules or of the leading edge scale may demonstrate short hyphae and spores, but these may be difficult to find. If Candida is suspected and the diagnosis is in question, obtain a skin swab for fungal culture.
Treat with a topical antifungal cream, such as clotrimazole, ketoconazole, or econazole. Keep the affected area dry and cool. Clothing should be loose and lightweight. Astringent solutions (such as aluminum acetate [Burow’s solution]) aid in drying weepy inflammatory eruptions. Once the infection is controlled, recommend daily application of drying powders. Patients with vulvar candidiasis should be evaluated and treated for
Candida vaginitis (see Chapter 102, “Vulvovaginitis”). Patients with Candida balanitis often have a female sexual partner with Candida vaginitis, so evaluate and treat partners as well. In infants or adults with urinary or fecal incontinence, change diapers frequently. Zinc oxide paste applied over the antifungal agent provides a protective barrier to the irritation of urine and feces.
SCABIES
Infestation of the skin by Sarcoptes scabiei, or scabies mite, produces an intensely pruritic eruption. Symptoms manifest approximately  days following exposure to the organisms as a result of the host immune response to the mites and their excrement. History may elicit an encounter with another person, or with a new environment, about  to  weeks before the symptoms appear. Scabies infestation is a major problem in immigrants and
 asylum seekers, where both prevention and treatment are initiated to control the disease. Individuals with crusted scabies have very large numbers of mites and are quite contagious. Transmission can occur from brief skin or fomite contact.
The main presenting feature is intense, intractable pruritus, most notable at night. In adults, the typical findings are slightly longitudinal erythematous or brown papules, predominantly on the lateral feet, wrists, ankles, and interdigital spaces of the fingers and toes. Involvement may be evident within the axillae, groin, and extensor extremities (Figure 252­3). The head and neck are characteristically spared. A variant, crusted or
Norwegian scabies, can develop in the immunocompromised, those with dementia, or those who are institutionalized (Figure 253­4). Crusted scabies consists of thick, crusted, confluent plaques on the hands, feet, and scalp, with or without a generalized distribution. Pruritus is not a common feature of crusted scabies.
FIGURE 252­3. Scabetic papules and burrows. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical
Dermatology, 5th ed. © 2005, McGraw­Hill, New York.]
FIGURE 252­4. Norwegian or crusted scabies. [Reproduced with permission from Knoop KJ, Stack LB, Storrow AB, Thurman RJ (eds): The Atlas of Emergency
Medicine, 4th ed. McGraw­Hill Education, Inc., New York, 2016. Fig. .35, p. 709. (Photo Contributor: Larry Mellick, MD).]
To visualize the organisms by light microscopy, scrape a burrow with a scalpel blade, transfer to a glass slide, and cover with a drop of mineral oil and a coverslip (see Figure 251­15). Sensitivity of this test is limited, and a negative result does not rule out the diagnosis.
Treat with 5% permethrin cream (pregnancy category B), apply from the neck down, leave on for  hours, and then bathe with soap and water.
Repeat treatment in  week. Treat all resident family members and household and intimate contacts.
Do not prescribe lindane to children or pregnant women secondary to neurotoxicity.

Oral ivermectin is an alternative to permethrin cream, but it may have a slightly lower cure rate. It is given as a single oral dose, 200 micrograms/kg.
Oral ivermectin can be used as an adjunct to permethrin for refractory cases or in the setting of an immunocompromised or uncooperative patient. Do not prescribe ivermectin to pregnant and lactating women or to children weighing less than  kg.
Supportive care involves use of oral antihistamines and topical corticosteroids after use of the appropriate scabicidal agent. Symptoms gradually resolve over  to  weeks, although pruritus can sometimes persist for several weeks. Return of new lesions after initial improvement signifies incomplete treatment or reinfestation.
PEDICULOSIS PUBIS
Pediculosis pubis is infestation of the groin with Phthirus pubis. Rarely, the eyebrows, eyelashes, chest, or axillary hair may also be involved.
Close examination of the hair­bearing areas reveals multiple, small, flesh­colored or slightly reddish organisms grasping the hairs close to the skin surface (Figure 252­5). In severe infestations, small bluish­gray macules may be noted, called maculae caeruleae. Secondary infection and excoriations may also be present. Diagnosis of pediculosis pubis in children should prompt evaluation for sexual abuse.
FIGURE 252­5. Arrow points to louse on the skin. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical
Dermatology, 5th ed. © 2005, McGraw­Hill, New York.]
Treatment permethrin 1% cream or pyrethrin piperonylbutoxide, applied to affected areas, and wash off in  minutes. Topical treatments should be applied liberally to all affected hair­bearing areas, including the perirectal hairs. Involvement of the eyelashes is treated with application of an occlusive ophthalmic ointment or petroleum jelly to the eyelid margins. Apply twice a day for  days.
SEBORRHEIC DERMATITIS
Seborrheic dermatitis is one of the most common skin disorders. It most notably affects the scalp (“dandruff”) and creases of the face and ears; however, other skinfolds, such as the intergluteal cleft, groin, axilla, inframammary folds, and umbilicus, can be affected (see Chapters 250, “Skin
Disorders: Face and Scalp” and 251, “Skin Disorders: Trunk”). It is a chronic condition that typically reappears after stopping treatment.
Seborrheic dermatitis of the scalp and skinfolds of the face presents as erythema with a greasy yellow scale (see Figure 250­1). When seborrheic dermatitis affects other skinfolds, erythema and maceration are evident.
Diagnosis is clinical. By itself, groin or other skinfold involvement is hard to differentiate from cutaneous candidiasis, inverse psoriasis, allergic contact dermatitis, or streptococcal infection.
Treatment is symptomatic. Shampoos containing zinc pyrithione, selenium sulfide, salicylic acid, or tar preparations are used. Ketoconazole shampoo can be effective and is available by prescription (2%) or over the counter (1%). Hydrocortisone 1% cream can be used in mild cases, whereas hydrocortisone .5% cream or desonide cream or lotion may be required initially in more severe cases. Avoid long­term regular use of corticosteroids on facial or intertriginous skin, which may result in irreversible skin thinning and striae formation.
INTERTRIGO
Intertrigo is an irritant dermatitis of the skinfolds resulting from moisture, heat, friction, and irritating substances like urine and feces. Intertrigo presents as erythema, maceration, and fissures in the occluded area of skinfolds, especially the groin and inframammary folds (Figure 252­6).
Satellite papules and pustules are absent, and the affected areas are pruritic and may burn. Streptococcal superinfection should be considered if there is marked erythema and tenderness, especially in the extremes of age and the immunocompromised.
FIGURE 252­6. Intertrigo with possible streptococcal superinfection. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas &
Synopsis of Clinical Dermatology, 5th ed. © 2005, McGraw­Hill, New York.]
Intertrigo is a diagnosis of exclusion (Table 252­1). Bacterial infection, especially with Streptococcus, is common. Differentiating cutaneous candidiasis from inflammatory intertrigo can be difficult. A diagnosis of cutaneous candidiasis is supported by the presence of satellite pustules and a positive potassium hydroxide examination. However, a negative potassium hydroxide examination does not exclude the diagnosis because yeast is difficult to obtain and visualize. Obtain fungal culture when diagnosis is uncertain.
Clinically, irritant dermatitis cannot always be distinguished from allergic contact dermatitis. Ask about possible contact allergens or irritants such as neomycin­containing ointments, anesthetic creams, diphenhydramine cream, deodorants, feminine hygiene sprays, or other lotions, solutions, or home remedies.
Treat by keeping the affected areas dry and cool. Avoid potential irritants. Zinc oxide paste provides an excellent barrier to urine and fecal material.
Apply aluminum acetate (Burow’s solution) compresses for moist, weepy intertrigo. Treat secondary bacterial infection with oral antibiotics with staphylococcal and streptococcal coverage. Topical antiyeast preparations, such as ketoconazole, may be helpful. If significant inflammation is present, a short course of 1% hydrocortisone cream or lotion may be helpful.
HIDRADENITIS SUPPURATIVA
Hidradenitis suppurativa is an inflammatory condition typically affecting the apocrine gland–bearing areas of the skin with recurrent, painful, draining
 nodules. The inciting event is follicular occlusion, prompting rupture of the follicular contents and resulting in intense inflammation.
Axillary and inguinal skin demonstrates varying numbers of inflammatory nodules, many of which may form connecting tracts, with resultant drainage onto the skin surface (Figure 252­7). Lesions may heal with characteristic icepick scarring. Diagnosis is clinical. Treatment is clindamycin 1% lotion twice daily and use of antibacterial soaps, such as chlorhexidine, once to twice weekly. Incision and drainage may increase scarring. Refer to a plastic surgeon or dermatologist. Further systemic treatments, such as acitretin, finasteride, oral antibiotics, or prednisone, is best coordinated by a dermatologist.
FIGURE 252­7. Hidradenitis suppurativa involving the buttock region. [Photo contributed by University of North Carolina Department of Dermatology.]


