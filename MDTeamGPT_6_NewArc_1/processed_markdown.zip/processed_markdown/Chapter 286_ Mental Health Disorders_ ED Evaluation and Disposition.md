## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 286: Mental Health Disorders: ED Evaluation and Disposition
Veronica Tucci; Nidal Moukaddam
INTRODUCTION AND EPIDEMIOLOGY
This chapter is designed to provide the emergency provider with a general approach to the psychiatric emergency patient, identify potential pitfalls, and provide strategies for successfully managing this difficult patient population.
Psychiatric and behavioral emergencies have become a staple in every ED around the world. The busy emergency provider must successfully navigate encounters with patients who can exhibit a wide range of psychosocial pathology including substance use disorders, anxiety and agitation, depression and suicidal ideation, psychoses, neurocognitive disorders, and personality disorders, all of which can present with medical, psychiatric, or a combination of complaints.
Globally, according to the World Health Organization, one in four people suffer from mental illness or neurologic disorders, with depression as the
 number one cause of disability worldwide. The National Institute of Mental Health in the United States estimates that  in  Americans suffers from a
 mental, behavioral, or emotional disorder and  in  suffer from a severe mental illness. The Centers for Disease Control and Prevention announced
 a 24% increase in the rate of suicide in the United States from 1999 to 2014. 4­6 
Psychiatric patients have a higher incidence of medical conditions and a greater risk of injury than those without mental health or behavioral
 disorders. Fifty to 90% have at least one chronic medical condition and have a shortened life expectancy by anywhere from  to  years. Sixty percent of this shortened life expectancy is estimated to be due to physical illness. Moreover, the National Alliance on Mental Health reports that 26% of homeless people in the United States who live in shelters have a serious mental illness, and 24% of state prisoners had a “recent history of a mental
 condition.” This is of particular concern in urban, busy EDs and has special relevance for high ED users, discussed below.
GOALS OF CLINICAL EVALUATION
Anywhere from 7% to 10% of patients admitted to psychiatric wards have an organic condition that should have been identified, with higher figures
,11 often cited for patients at the extremes of life. Examples of missed life­threatening organic pathology include meningitis; sepsis; delirium; toxicologic processes including acetaminophen toxicity; neuroleptic malignant syndrome; metabolic abnormalities including hepatic encephalopathy,
,13 myxedema coma, or DKA; and traumatic conditions including epidural or subdural hematomas. The distinction between functional and organic causes is crucial because organic issues may be reversible with prompt intervention and failure to identify such pathology can have devastating outcomes. The evaluative process for identifying primary or comorbid medical conditions is often referred to as medical clearance.
Little disagreement exists over the evaluation of patients with no known psychiatric history who present with altered mental status or new­onset psychosis. Such patients are presumed to have an underlying medical disorder or an “organic” cause until proven otherwise. Clinical evaluation is needed to identify any medical or surgical emergencies. Assuming a psychiatric condition for first­time episodes is ill advised because a psychiatric condition is a diagnosis of exclusion. Evaluation should include appropriate reassessment and observation periods which, realistically, may not be entirely completed in the ED.
Controversy, however, arises on how in depth the ED evaluation needs to be for a patient with a known psychiatric history (with or without chronic medical problems) and who is presenting with a psychiatric or behavioral complaint. Because of missed organic pathology in patients admitted to psychiatric wards over the past  years, emergency providers have been tasked with completing a medical evaluation of patients with psychiatric or behavioral complaints. This initial medical evaluation may be the only one that the patient will receive and, by design, is meant to ensure that potentially serious medical problems will not be left unaddressed and untreated. This thorough evaluation is more commonly referred to as medical cDleoawrnalnocaed. eAds o2f0 t2h5is­7 w­1ri t9in:1g ,P t h Yeroeu irs IsPti lils n 1o3 i6n.t1e4rd2i.s1c5i9p.l1in2a7ry consensus on the necessary historical and physical examination elements, ancillary
Chapter 286: Mental Health Disorders: ED Evaluation and Disposition, Veronica Tucci; Nidal Moukaddam testing, and treatment that constitute an acceptable clearance process or medical stability examination. The lack of consensus is rooted in the fact that
. Terms of Use * Privacy Policy * Notice * Accessibility
14­16 the term itself is ambiguous and means different things to different providers. Regardless of the lack of interdisciplinary consensus, the medical clearance or medical stability assessment is critical in evaluation and treatment of patients with psychiatric and behavioral emergencies.
Two common situations are as follows: (1) Patients with chronic medical conditions can be viewed as stable as long as such conditions are not responsible for the patient’s psychiatric or behavioral issues or are incidental complaints. (2) Patients can be viewed as stable for psychiatric evaluation as long as medical illness has been treated and the patient’s condition has stabilized (e.g., diabetes, hypertension). For all patients, a thoroughly documented medical decision­making process, including specific ED treatment, further recommendations, and suggestions for follow­up,
 can facilitate placement in an inpatient facility.
ED MEDICAL STABILITY OR CLEARANCE EVALUATION
The end goal of the medical clearance or stability examination is to distinguish between an organic or psychiatric condition. Comorbid medical
,18,19 diseases may be causing or exacerbating psychiatric symptoms in 34% to 50% of patients who present with psychiatric emergencies. The journey of the patient with mental health complaint is summarized in Figure 286­1. FIGURE 286­1. Elements of ED evaluation.
ED ARRIVAL AND TRIAGE
Paramedics or police typically provide advance notice to the ED regarding patients with serious mental health issues or severe agitation, so preparations can be made for the patient’s arrival. For patients who threaten harm to others or who have altered mental status or severe agitation, hospital security and ED nursing and medical staff can be prepared to search the patient for weapons, secure an appropriate ED room, and provide verbal de­escalation, restraints, or medication as needed.
Place the patient in a room where there are no objects, liquids, or devices that can be used to harm the patient or others. Undress the patient and provide a hospital gown. If the patient has not already been screened for weapons, make sure it is done as soon as possible.
Many EDs have systems in place to flag patients at risk of eloping or those who cannot be released until assessment is complete. Terms such as protective custody or precautionary hold are sometimes used. Different color gowns, special area assignments, and special flagging of the chart are some means for identifying high­risk patients that are widespread.
For other more stable patients, triage is accomplished in the usual manner as for medical patients, to identify high­risk versus lower­risk patients or situations. High­risk situations include suicidal or homicidal ideation, psychotic or violent behaviors, and risk for elopement. The Emergency Severity
Index, the Canadian Triage Acuity Scale, the Manchester Triage System, the Australasian Triage Scale, and the South African Triage Scale are the most widely used ED triage systems worldwide.
HISTORY
Obtain a detailed description of recent symptoms from the patient. Explore the severity of symptoms including any changes in behavior identified by the patient himself or herself or an alternative storyteller, any provoking and palliative features, similar previous occurrences, and the timing and duration of symptoms.
Patients with psychiatric or behavioral issues may not be cooperative or may offer tangential responses. Patients may provide diagnostic terms for their disorder that are technically inaccurate. It is best to ask the patient to describe symptoms rather than ask about a diagnosis. Ask openly about substance use disorders.
Try to obtain collateral information from as many ancillary sources as possible. Additional sources can provide a baseline for the patient’s symptoms and confirm the story, especially if the patient’s mental capacity is impaired or not known or if the patient is uncooperative. Chart reviews can provide additional collateral. Table 286­1 lists historical features more likely to be characteristic of an organic pathology for psychiatric complaints.
TABLE 286­1
Historical Features Suggestive of Medical Causes for the Psychiatric Presentation20­24
No previous psychiatric history
Recently hospitalized or with symptoms suggestive of possible infections
Recent medication changes
Sudden changes in behavior
Visual hallucinations
Extremes of life; age >40 y or <12 y
New­onset seizure
Recent memory loss
History of substance abuse
In one study, investigators found that 63% of patients with new psychiatric symptoms had significant medical pathology, 42% of which could be
  diagnosed from a proper history alone. Identify current infections and consider delirium when faced with an acutely psychotic or agitated patient.
See Chapter 288, “Mental Health Disorders of the Elderly,” and Chapter 287, “Acute Agitation,” for further discussion of delirium, dementia, and agitation. Patients reporting any of the historical features noted in Table 286­1 should receive further focused testing.
REVIEW OF SYSTEMS
The review of systems can be accomplished in a more structured manner than the rest of the interview and sometimes can help redirect the patient.
Unfortunately, many avoid asking detailed questions on the review of systems because of concerns that the patient will endorse everything asked.
Specific targeted yes or no questions in this part of the encounter can help hone the differential diagnosis. Focus on elements of the review of systems most likely to point to organic problems (e.g., recent fevers, productive cough, rashes, headaches, trauma).
PHYSICAL EXAMINATION
The cornerstone of the medical stability assessment is the physical examination. Where the history and review of systems may prove troubling to decipher, the physical exam is more objective and can lead to an underlying medical disorder as the root or exacerbating cause of symptoms.
First, obtain a full set of vital signs and address any abnormalities. Obtain vital signs in the agitated or hostile patient as soon as feasible, and recheck
 before discharge. One study from 2008 noted a failure to document a complete set of vital signs in up to 50% of patients.
Perform a head to toe examination. For psychiatric patients, like most medical patients in the ED, the patient’s complaints and known medical comorbidities dictate the order of the exam and the amount of attention given to each element. Patients with limited histories or who have selfinflicted injuries (especially adolescents) should receive a comprehensive physical examination in a manner akin to a standardized trauma
,29 assessment. Table 286­2 summarizes physical examination features that may help the emergency physician differentiate organic from primary psychiatric disease.
TABLE 286­2
Physical Examination Features Suggestive of Organic Causes of Psychiatric Complaints
Abnormal vital signs
Fluctuating level of consciousness/alertness (e.g., clouded sensorium)
Significantly decreased level of consciousness (Glasgow Coma Scale score <8)
Focal neurologic findings (e.g., new­onset seizures, inability to walk unassisted)
Ophthalmologic abnormalities (e.g., rotary nystagmus)
Evidence of trauma (e.g., raccoon eyes, Battle’s sign, septal hematoma, abrasions, lacerations)
Abnormal dermatologic manifestations (e.g., rashes, purpura, jaundice, uremic frost, cool, mottled extremities)
Abnormal mental examination or Quick Confusion Scale
Presence of visual hallucinations
,30
Many inpatient psychiatrists expect the ED physical examination to include a mental status examination. Common mental status examinations include the Mini­Mental Status Examination, the Brief Mental Status Examination, and Quick Confusion Scale. These tools generally focus on seven
 major areas: affect, attention, language, orientation, memory, visual­spatial ability, and conceptualization. In the case of uncooperative or violent
 patients, a significant portion of the examination can be done by observing from the doorway.
LABORATORY AND ANCILLARY TESTING
Medical history, physical examination, review of systems, and tests for orientation have relatively high yield for detecting active medical problems, and routine laboratory testing is typically low yield. In general, testing is best left to the discretion of the emergency provider, with individualized
 assessments being the best guide to optimal evaluation. Most inpatient psychiatric facilities will still require extensive ancillary testing as part of the clearance process or otherwise will list specific test abnormalities as part of their exclusionary criteria in determining the patient’s suitability for admission. Most psychiatric facilities lack laboratories and imaging suites on their premises and do not have access to immediate turnarounds.
Therefore, in the interest of patient safety, they often require substantial testing as either part of the medical clearance process or as specific exclusionary criteria.
REASSESSMENT AND ANTICIPATION OF DECOMPENSATION
Like the ECG or a FAST examination, the initial assessment is a snapshot in time. Reassess patients and document the reassessments for the following reasons: (1) patients can decompensate in the in­hospitable ED environment; (2) withdrawal or overdose symptoms may develop (indeed, one study asserted that one third of cases of severe intoxication were missed and that .5% of patients with withdrawal or delirium tremens and .5% of
 patients with a medication overdose had not been identified on initial assessment) ; (3) a coexisting medical disorder will require attention (e.g., a diabetic requiring insulin or a patient with hypertension requiring twice­daily dosing of home medications); and (4) a coexisting medical disorder may reveal itself.
SPECIAL CONSIDERATIONS
DEFICIENCIES IN THE INITIAL ASSESSMENT
Although most impending medical disasters can be uncovered with a thorough history, review of systems, and physical examination including attention to abnormal vital signs, studies over the past  years have demonstrated poor quality assessments performed on patients presenting with psychiatric symptoms in the ED (Table 286­3).
TABLE 286­3
Medical Clearance Assessment Deficiencies
Obtaining an incomplete or inaccurate history
Failing to seek out collateral sources (e.g., family, EMS, police)
Failing to acknowledge and address abnormal vital signs
Failing to recognize immediate life and limb threats (e.g., respiratory failure due to narcotic overdose)
Performing a cursory or incomplete physical examination
Failure to develop and refine a differential diagnosis for the patient’s symptoms
Anchoring on psychiatric diagnoses
Failing to reassess the patient
Applying a “kitchen sink” mentality in ordering laboratory and radiographic tests

One group of investigators found that over one third of medical clearance assessments lacked a history. Another found that 8% of patients had no
 documented exam, and even when present, many did not include critical components. For example, complete sets of vital signs were often not documented, and even when abnormal, they were not reassessed or noted. Mental examinations (depending on whether they are defined as minimental or orientation status) are frequently missing, with statistics as high as 56%. Neurologic examinations were similarly neglected, with one study noting absence of cranial nerve testing in 50%, motor exam testing in 72% of cases, sensory exam testing in 88% of cases, and gait testing in 75% of
 cases.
INTERVIEWING TECHNIQUES
Table 286­4 summarizes interviewing basics. Time constraints are common in the ED, and the time to conduct a detailed interview is often lacking.
The recommended approach to the patient with mental health complaints focuses on safety first, followed by establishing and maintaining a therapeutic rapport.
TABLE 286­4
Interview Techniques in the ED
Safety
Know where the exits are before you talk to the patient; stand close to exit
Leave enough distance to avoid being physically hurt
Wear a badge clip that cannot be used to choke you
Cooperation/rapport
Always introduce yourself clearly
Establish eye contact; smile if possible
Reuse terms the patient uses to describe their condition before asking for clarification; this makes the patient feel heard
Start with open­ended questions because they are best to establish therapeutic rapport
Transition to close­ended questions if open­ended questions are not productive
Last resort: Yes or no and multiple­choice questions
VIOLENT RESTRAINTS
In some cases, no matter how well trained the ED staff is in de­escalation techniques, physical restraints will need to be applied rapidly and safely to protect the patient from self­harm and/or the staff from harm. The term sometimes used is violent restraints.
Application of violent restraints is ideally accomplished by a team of five staff members with one team leader and one person for each limb. Shows of force with multiple team members poised to act can at times be sufficient in themselves to subdue the patient without actually applying the restraints.
As with all elements of care, the patient and any family members present should be provided with clear, ongoing explanations of the procedure and reasons for it. Place the patient on a bed or stretcher, and secure all four limbs with leather restraints (soft restraints are more commonly used in nonviolent settings). Be careful to avoid injury to the patient and personnel assisting in the process. Elevate the patient’s head, if possible, to minimize risk of aspiration. Once the patient is restrained, offer medications, and if refused, administer medications involuntarily.
Emergency providers must familiarize themselves with hospital policies and laws regarding the frequency of reassessment and the elements that they must document in their face­to­face assessment (e.g., vital signs; airway, breathing, and circulation; range of motion; skin integrity; turning the patient as needed; attending to toileting and any other hygiene needs). The first face­to­face assessment is generally completed in the first hour after application. Computerized or written orders can specify the time limit for the restraint and protocols for removal. Many hospitals require a new order to maintain physical restraints at regular intervals for violent patients with restraints. Once the patient is calm and cooperative, the nursing or security staff under the direction of the emergency provider may remove the restraints. It is usually best to remove the restraints in a stepwise fashion, one at a time, while carefully monitoring the patient to ensure continued compliance and cooperation.
ASSESSING THE DEGREE OF AGITATION
Some patients may require medications either before or after the application of restraints. Pharmacologic treatment of violent or agitated patients is discussed in detail in Chapter 287, “Acute Agitation.” The Sedation Assessment Tool score is one method of grading behavior and assessing
 medication options. Treatment options can be selected based on behavior (Table 286­5).
TABLE 286­5
Sedation Assessment Tool and Treatment Suggestions* Sedation Assessment
Description Treatment
Tool Score
3+ Combative, violent, out of control with continual Physical restraint loud outbursts Lorazepam 1–2 milligrams IM
AND
Haloperidol 5–10 milligrams IM
OR
Olanzapine (Zyprexa®) 5–10 milligrams IM
OR
Droperidol  milligrams IM
2+ Very anxious and agitated with loud outbursts As above, or if will take PO, lorazepam 1–2 milligrams PO and haloperidol 5–10 milligrams PO
OR
Olanzapine orally disintegrating tablets (ODT)  milligrams
1+ Anxious and restless with normal to talkative If will take PO, lorazepam 1–2 milligrams PO and haloperidol 5–10 speech milligrams PO
OR
Olanzapine ODT  milligrams or  milligrams IM
 Awake and calm, cooperative with normal Not applicable speech
*Data from Calver LA, Stokes B, Isbister GK: Sedation Assessment tool to score acute behavioral disturbance in the emergency department. Emerg Med Australas 23:
732, 2011. [PMID: 22151672]
HIGH ED USERS
High users are a group of patients who present to the ED at much higher rates than expected for their conditions or severity of illness. Pejoratively dubbed frequent flyers, and often accused of malingering, these individuals are some of the most challenging to deal with in the ED. High users typically consist of a mix of individuals with chronic conditions, a background of trauma, broken families/poor social support, and severe psychosocial
36­38 stressors (e.g., homelessness). They tend to elicit strong, often negative feelings in providers (discussed below).

Families and communities are unable to take care of mentally ill individuals and ensure the necessary safety nets, and the ED becomes the go­to for crises and decompensations. “Bedless” psychiatry, embedded in outpatient and emergency care, has shown so many challenges that many have called
,41 for a return of long­term care, and although psychiatric asylums are not the answers, they did fulfill a stabilizing function for a very difficult and fragile population.
The advent of deinstitutionalization for psychiatric patients in the 1960s resulted in a dearth of inpatient psychiatric beds and outpatient and community outreach services, more hospital admissions, shorter hospital stays, and significant gaps in care. Many patients who would have previously been housed in long­term state hospitals or facilities were left with nowhere to live and nowhere to go to receive the kind of care to which they had
,43 become accustomed. Indeed, from 1970 to 2006, inpatient psychiatric beds decreased from an estimated 400,000 beds to less than ,000. The
 authors of the report “No Room at the Inn: Trends and Consequences of Closing Public Psychiatric Hospitals, 2005­2010” found that the number of state psychiatric beds continued to dwindle by another 14% from 2005 to 2010, effectively decimating the number of public psychiatric beds available
 to treat both chronic and acutely decompensated psychiatric patients. In 2016, Becker Hospital Review reported that the number of needed inpatient
 psychiatric beds in the United States is, at minimum, 123,300, and the number of beds actually available is ,679. With less than 30% of the needed inpatient beds available, demand for care for mental illness continues to reach new heights and is simply outstripping supply. Substance use disorders/addiction, depression, anxiety, and psychoses in the general population have exploded, with more ED visits for disadvantaged
 populations.
Consequently, the ED is the last beacon of hope and is a safety net for the community’s most vulnerable, with an estimated one in eight ED visits now
,48 involving mental and substance abuse disorders, according to the U.S. Agency for Healthcare Research and Quality.
49­51
There is no denying that high users sometimes derive emotional benefit from the ED visits, and there are (sadly not infrequent) anecdotal reports of patients who call their previous inpatient units on a regular basis to update on their progress. However, some strategies can help deal more effectively with this group.
Factors to consider in managing high users include the following. First, most of the individuals in this category have unresolved symptoms and low
 treatment adherence, as well as urgent social needs. Thus, social interventions such as supported housing may help more than purely medical
,54 interventions; providing housing reduces medical visits and ED­seeking behavior. Second, many of these patients have trouble navigating the
,55,56 health system and are often ignored or lack primary care resources. Programs that address these factors can reduce ED recidivism.
Third, chronic substance abuse and mental illness, alone or in conjunction, often have profound impacts on cognition. High ED users often present
 ,59 with an undisclosed or unexplored history of head trauma, as victimization rates are elevated in both substance use disorders and mental illness.
The natural corollary of this is a decreased ability to recall and comprehend instructions given in the ED. Simplifying instructions and making sure the patient understood the explanation are crucial. Provide a limited, singular­focused plan, without multiple steps or complicated follow­up provisions.

Simple planning applies to verbal, written, or even E­health/mobile­based interventions.
Beyond the social needs, however, high users often have unmet medical needs. To get to the point of providing proper medical care, the emergency provider must deal with the patient’s attitudes and behavioral difficulties. The difficult patient is a staple of every ED and every clinical practice. Intense patients can provoke negative feelings in providers.
61­64
Unconscious biases influence health decisions, cloud clinical judgment, and can lead to discrepancies and disparities in health care. Negative bias is an unconscious, automatic reaction to a patient’s preexisting attributes such as gender, race, obesity status, ED recidivism, socioeconomic status, or sexual orientation. Negative bias can alter care, even with the provider’s best intentions.
Dealing with difficult patients can be improved by adherence to existing protocols to the extent possible. Discussion of difficult cases with colleagues and the ED team can be helpful to develop effective strategies and to decrease provider isolation and burnout.
INVOLUNTARY PATIENTS
To consider an involuntary admission, the patient must be suffering from a severe mental disorder and must need treatment on an inpatient basis, and compulsory/involuntary treatment must be necessary in the interest of the patient’s health or safety or the protection of other persons. A crucial element that is often missed is that there must be a prospect of recovery if the patient is treated involuntarily. Thus, patients with intellectual disabilities, autism spectrum disorders, or substance use disorders may not qualify for involuntary admission no matter how dramatic their presentation.
The core criteria that dictate involuntary transport to the ED are typically divided into three categories: harm to self; harm to others; and continuing deterioration without treatment.
Harm to self, planned suicide, active suicidal attempt, or reason to believe the patient may harm himself or herself imminently if discharged is the first category. Although many interviewers evaluate this by asking the question “Do you feel you want to hurt yourself?” the assessment of self­harm risk is much more complex, so that suicidal ideations are usually linked to a specialized psychiatric consultation.
The second category of involuntary commitment is harm to others or risk of harm to others. Frank homicidal ideations are actually fairly rare, but irritability and impulsivity are dangerous when unbridled, especially when combined with substance use, access to weapons, or personal crises that compound the situation, such as recent breakups, divorces, custody battles, and perceived need for revenge.
Lastly, the third category that may allow involuntary detention of a patient in the ED is continued deterioration to the extent where self­care and self­preservation are doubtful. Such cases will lack open statement of self­harm but may include catatonia, self­starvation, eating disorders, or severe psychosis with distortion of reality. This group of patients will typically lack capacity to make full medical decisions for themselves. Table 286­6 illustrates the differences between capacity and competency. An involuntary commitment assumes (in most states) the patient lacks capacity to consent to an admission or emergency medications but is not linked to any competency determination, the latter being a legal term and decided on by the court.
TABLE 286­6
Capacity Versus Competency
Capacity
The ability to make a decision about a specific health matter at a discrete point in time.
The concept includes the ability to understand risks and benefits of the suggested intervention, medication, or procedure; the repercussions of declining it; and alternative choices.
Competency
Legal term decided by court and extends to financial, health, and personal matters. It is not a dynamic concept like capacity. Absence of competence usually implies the presence of a legal guardian, either an individual or a court­appointed entity. The concept is not to be confused with power of attorney.
The rules for involuntary commitment vary by state, both in scope and in the assignment of responsibility for who should fill out the court documents.
Commonalities shared by all states (and countries) are based on the principles from European Convention for the Protection of Human Rights and
Fundamental Freedoms (1950), the Principles for the Protection of Persons with Mental Illness (or MI Principles, 1991), The Declaration of Hawaii
(1983), and Ten Basic Principles for Mental Health Law published by the World Health Organization. Two sources of information are usually required for involuntary commitment, such as an affidavit filled by the police or physician and another filled by a family member or social worker. Psychiatric consultation is recommended for involuntary commitment situations.
EXCLUSIONARY CRITERIA FOR PSYCHIATRIC ADMISSION
Once it is determined that the patient requires psychiatric admission and medical clearance/stabilization has been accomplished, various processes are used to find an inpatient psychiatric facility bed. In some cases, an on­site social worker will help identify local inpatient facilities for consideration.
In other cases, a unit secretary will fax over the forms and facilitate the doctor­to­doctor calls to secure the patient a bed. The rules governing this process are very complex and, at times, elusory. Exclusionary criteria add yet another layer of complexity and add to the patient’s overall length of stay in the ED and can trigger the problem of ED boarding.
A protracted discussion is beyond the scope of this chapter. However, facilities can deny patients for a myriad of reasons ranging from preexisting medical conditions (i.e., pregnancy or intellectual delay), to inability to manage the patient’s medical comorbidities (i.e., patients requiring peritoneal dialysis), to requiring specific laboratory or ancillary testing irrespective of clinical need, to facility issues (i.e., requiring patients in the same room to be of the same gender). ED staff should familiarize themselves with the exclusionary criteria of local inpatient facilities. Failure to do so will lead to
 increased lengths of stay and further strain the ED staff and the patient.
DISPOSITION
The evaluation of the patient presenting with mental health complaints in the ED is a challenging process, because the complaints can indicate a medical issue, mental issue, or both. By following a rigorous process for evaluation and testing selection and seeking psychiatric consultation when needed, the emergency provider can untangle the case fairly reliably.
There are three types of disposition for patients with mental health complaints. The first and simplest is a discharge. Problems may arise in terms of destination of discharge for individuals with housing insecurity and inability to buy prescribed medications. Providers should be familiar with local pharmacy and supermarket generic/cheaper lists and discount programs and apps to help selected patients offset costs. The second potential disposition is an admission, whether psychiatric or medical. Bed availability is the main issue in this scenario, with inpatient facility shortages even for patients with insurance coverage. The extent of this problem has made headlines nationally. The third possibility is described differently across facilities and can be viewed as a reassessment or a brief observation period. This option may be the most useful for individuals who present with substance intoxication or crises expected to resolve in a period of time that is below the typical admission duration, but places pressure of increased length of stay and potential jurisdiction and liability issues on ED staff.
Lastly, cooperation between psychiatry and emergency medicine follows the same principles for any successful collaboration. We invite open communication and an effort to avoid stigma to enhance and optimize care for individuals with mental illness, one of the most vulnerable populations we are responsible for as a medical community.


