## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 120: Meningitis in Infants and Children
Amy Levine
INTRODUCTION AND EPIDEMIOLOGY
Meningitis is an inflammation of the leptomeninges, tissues that cover the brain and spinal cord. Untreated bacterial meningitis has a mortality of nearly 100%, so treat suspected bacterial meningitis promptly. Unfortunately, even with rapid antibiotic treatment, long­term neurologic sequelae occur. Viral meningitis has a range of severity: mild cases resolve without sequelae; however, some viruses, such as herpes virus, can cause severe infections. Meningoencephalitis is an inflammation of the brain as well as the meninges. It is less common than meningitis but can be devastating.
The most common causes of bacterial meningitis vary with the child’s age (Table 120­1). Vaccination programs have had a huge impact on the epidemiology of bacterial meningitis in developed countries. For instance, Haemophilus influenzae vaccine has almost eliminated H. influenzae
 meningitis in countries where the vaccine is utilized and has decreased overall bacterial meningitis rates by 55%. The introduction of the polyvalent vaccinations for Streptococcus pneumoniae (PCV7 in 2000 and PCV13 in 2010) has markedly decreased meningitis caused by that organism, although it
 remains the most frequent cause of pediatric meningitis. Neisseria meningitidis remains an important cause of meningitis in children, and vaccines against serotype B have recently been introduced. Other important causes of bacterial meningitis in children include Mycobacterium tuberculosis and
Borrelia burgdorferi, the causative agent of Lyme disease.
TABLE 120­1
Causes and Treatment of Bacterial Meningitis by Age Group
Most Common
Age Group Treatment Comments
Organisms
Neonates (0– Group B Ampicillin 100 milligrams/kg every  Less common organisms: Streptococcus pneumoniae, other gram­
 d) Streptococcus, h (age <7 d) or  milligrams every  negative organisms, Listeria monocytogenes, Haemophilus influenzae
Escherichia coli h (age 7–28 d) type b, Neisseria meningitidis
AND
Gentamicin  milligrams/kg every  h
Herpes simplex virus If herpes suspected, add acyclovir type  in infected  milligrams/kg every  h mothers
Young infants Group B Ampicillin 100 milligrams/kg every  Less common organisms: S. pneumoniae, N. meningitidis
(28–90 d) Streptococcus, h gram­negative bacilli AND
Gentamicin .5 milligrams/kg every
 h
OR
Cefotaxime 100 milligrams/kg every
 h

Herpes simplex virus If herpes suspected, add acyclovir
Chapter 120: Meningitis in Infants and Children, Amy Levine type   milligrams/kg every  h
. Terms of Use * Privacy Policy * Notice * Accessibility
Older infants S. pneumoniae, N. Vancomycin  milligrams/kg every Approximately half of meningitis in the United States is viral
(>3 months) meningitidis, H.  h Immunization makes infection with H. influenzae unlikely in the older and children influenzae type b AND infant and child
Ceftriaxone*  milligrams/kg every
 h
OR
Cefotaxime† 100 milligrams/kg every
 h
Herpes simplex virus If herpes suspected, add acyclovir type   milligrams/kg every  h
*For penicillin/β­lactam allergy, substitute chloramphenicol  milligrams/kg every  hours.11
†For penicillin/β­lactam allergy, substitute chloramphenicol  milligrams/kg every  hours.11
N. meningitidis commonly colonizes the upper respiratory tract, but does not commonly cause invasive disease in the Western hemisphere, although worldwide, there are endemic regions, such as the African meningitis belt. In childhood, there are two peaks of infection, one in children less than  years of age and another in adolescents. The disease can be rapidly progressive and fulminant or present with more nonspecific symptoms. For this
 reason, it is important to maintain a high index of suspicion.

Viral meningitis is much more common than bacterial meningitis. Enteroviruses are the leading cause worldwide. Meningoencephalitis can be caused by enteroviruses, arboviruses (including West Nile virus), and herpes viruses. Herpes simplex virus type  infection occurs sporadically and causes a severe meningoencephalitis in children and adults. Herpes simplex virus type  develops in neonates born to infected mothers. Varicellazoster virus can cause CNS infections including acute cerebellar ataxia. Many other viruses can cause CNS infections, including cytomegalovirus,
Ebstein­Barr virus, mumps virus, adenovirus, influenza virus, parainfluenza virus, rubeola virus, rubella virus, and rabies virus. More recently, chikungunya and Zika viruses have emerged as important pathogens to consider in patients with history of travel in South and Central America,
 although cases have been diagnosed elsewhere.
Fungal meningitis can occur in both normal and immunocompromised hosts. Important causes include Cryptococcus neoformans, Coccidioides
 immitis, and Candida albicans. Parasite infections can cause eosinophilic meningitis, defined as meningitis with at least  eosinophils/mm of cerebrospinal fluid (CSF). The main causes are Angiostrongylus cantonensis, Gnathostoma spinigerum, and Taenia solium. These are endemic in the
 tropics but are spreading due to travel.
PATHOPHYSIOLOGY
Bacterial meningitis in children usually results from bacteremia arising from organisms colonizing the nasopharynx. Less commonly, meningitis is caused by direct spread of bacteria from a contiguous site of infection, such as sinusitis, or from penetration of the CSF space from trauma, dermal sinus tracts, or open neural tube defects. Viral respiratory infections can increase the likelihood of meningitis when the nasopharynx is colonized.
Meningitis starts with breakdown of the blood–brain barrier. Then organisms enter the subarachnoid space. Once there, they can multiply quickly because the CSF has low levels of complement, antibodies, and other host defenses. Bacterial cell wall components and toxins produce an inflammatory response that increases vascular permeability and attracts leukocytes. The inflammatory response is responsible for much of the damage that ensues. Viral pathogens also produce damage by direct tissue destruction as well as inflammation.
CLINICAL FEATURES
HISTORY
Infants ≤30 days old are at risk for meningitis due to an immature immune response. Symptoms in this age group are variable and nonspecific and include both fever and hypothermia. Neonates can present with a history of lethargy, poor feeding, fussiness, bulging fontanelle, vomiting, diarrhea, seizures, grunting, or respiratory distress. Elements in the birth history that increase the likelihood of bacterial meningitis include prematurity, low birth weight, delivery complications, maternal infection, and maternal colonization with group B streptococci or herpes simplex. Some neonates present with few symptoms early in the course of their illness, so maintain a high degree of suspicion for early meningitis when confronted with a potentially sick newborn.
SIGNS AND SYMPTOMS OF BACTERIAL VERSUS VIRAL MENINGITIS
Bacterial Meningitis
Certain signs and symptoms are especially helpful for diagnosing bacterial meningitis in infants and children. Caregiver reports of bulging fontanelle
(likelihood ratio [LR] , 95% confidence interval [CI] .4–26), or neck stiffness (LR .7, 95% CI .2–19), or seizures (outside of the febrile seizure range of

 months to  years; LR .4, 95% CI .0–6.4), or reduced feeds (LR , 95% CI .2–3.4) are concerning for meningitis. Children with meningitis can present with the rapid onset of shock and altered mental status or with more gradual symptoms including fever, headaches, photophobia, upper respiratory symptoms, GI symptoms, irritability, and rash.
The World Health Organization’s Pocket Book of Hospital Care for Children reported the performance of signs and symptoms for bacterial meningitis in infants and children and did not find any single clinical feature distinctive enough to make a “robust diagnosis of bacterial meningitis.” However, the
 combination of fever, seizures, meningeal signs, and altered consciousness was consistently associated with bacterial meningitis.
Viral Meningitis
Infants with viral meningitis typically present with irritability and decreased activity. Headache and fever are the usual complaints in children. Other symptoms include photophobia, rashes, nausea, vomiting, and pain in the neck, back, and legs. Most children with West Nile virus will be
 asymptomatic or have mild illness. Severe neurologic illness from West Nile virus is more common in adults than in children. Arboviruses can cause
 viral meningitis, encephalitis, or acute flaccid paralysis. A recent outbreak of enterovirus D68 was also associated with acute flaccid paralysis.
Herpes simplex virus can cause devastating infection in neonates. Both type  and type  herpes simplex virus can cause neonatal disease. Infection can present in three ways: (1) as disseminated disease with involvement of the CNS in 60% to 75% of cases; (2) as primary CNS disease; or (3) as disease localized to the skin, eyes, and/or mouth. About two thirds of infants with disseminated or CNS disease will have skin lesions, but these may not be
 present at the time of diagnosis.
Herpes infection can be transmitted through an infected maternal genital tract but may also be transmitted from a nongenital infection as well. Herpes simplex encephalitis (herpes simplex virus type 1) beyond the neonatal period presents with fever, altered mental status, seizures, and focal neurologic findings. It occurs sporadically.
PHYSICAL EXAMINATION
Neonates and infants (<90 days old) may have fever, normal temperature, or hypothermia. A normal temperature does NOT exclude meningitis.
Toxic appearance, lethargy, mottling, bulging fontanelle, abnormal cry, grunting, respiratory distress, and increased or decreased tone are all supportive of the diagnosis, but these signs can be absent. Jaundice or rash may occasionally be seen. Infants in the first months of life are unlikely to have a stiff neck. Fever in neonates (rectal temperature of 100.5°F [38.0°C] or higher) should always prompt suspicion for meningitis.
In the absence of fever, a clinician should be concerned about infants who are ill appearing, have the signs or symptoms listed earlier, or are just not
“acting right” according to their caregivers.
Older infants (>90 days old) with meningitis may also have fever, hypothermia, toxic appearance, lethargy, mottling, bulging fontanelle, abnormal cry, grunting, and respiratory distress at presentation. Children (>36 months of age) may have fever and nuchal rigidity. The Kernig sign (with the patient lying supine and the hip flexed at  degrees, the patient cannot extend the knee fully without pain) and Brudzinski sign (with the patient lying supine, there is involuntary flexion of the legs with passive neck flexion) may be present. Patients may have altered mental status, shock, focal neurologic signs, or signs of increased intracranial pressure. Rash or another focal sign of infection may be present. Patients may have symptoms of an upper respiratory infection, myalgias, or arthralgias. Look for evidence of methicillin­resistant Staphylococcus aureus when examining the skin,
 although S. aureus meningitis is most commonly associated with a history of a neurosurgical procedure. Consider bacterial meningitis in the child with fever and seizures, outside the range of  months to  years.
DIAGNOSIS
DIFFERENTIAL DIAGNOSIS
In neonates, the most common causes of meningitis in the United States are group B Streptococcus and Escherichia coli. Other organisms that cause meningitis include S. pneumoniae, Listeria monocytogenes, other streptococci, nontypeable H. influenzae, Staphylococcus species, Klebsiella,

Enterobacter, Pseudomonas, Treponema pallidum, and M. tuberculosis. Neonates can develop meningitis from primary viral infection with herpes simplex virus or enteroviruses. The differential diagnosis of neonatal sepsis and meningitis includes infection from fungi (Candida) and protozoa
(malaria crosses the placenta, and maternal malaria can infect the neonate). Noninfectious illnesses that can appear similar to sepsis and meningitis include cardiac disease, necrotizing enterocolitis, congenital adrenal hyperplasia, inborn errors of metabolism, and intracranial hemorrhage.
In older infants and children, the usual dilemma is differentiating acute viral and bacterial meningitis. The typical bacterial causes are S.
pneumoniae, N. meningitidis, and H. influenzae type b. Less common organisms include M. tuberculosis, Nocardia species, T. pallidum, and B.
 burgdorferi. Fungal infections and parasitic infections can produce infection of the CNS. Infections around the brain and spinal cord may appear similar to meningitis. Collagen vascular disease, malignancy, and certain drugs and toxins should also be included in the differential diagnosis.
LABORATORY TESTING
Check a bedside glucose in all acutely ill infants and children with altered mental status. All children suspected of having meningitis should undergo a lumbar puncture when they are clinically stable. Although establishing a diagnosis is important, patients who are unstable but suspected of having bacterial meningitis should receive antibiotics as quickly as possible (Table 120­1). Defer lumbar puncture until the child is stabilized and can tolerate the procedure. Positioning an infant or child for lumbar puncture before stabilization can result in hypoxia and hypotension. There are a few contraindications to lumbar puncture in children besides hypoxia and clinical instability. These include focal neurologic findings, thrombocytopenia, local infection at the lumbar site, and vertebral abnormalities. See Chapter 119, “Fever and Serious Bacterial Illness in
Infants and Children,” for details of pediatric lumbar puncture.
Children with focal neurologic signs should receive antibiotics promptly, without waiting for a CT scan or lumbar puncture; the next step is a head CT scan prior to lumbar puncture. CSF abnormalities of meningitis, such as neutrophilic pleocytosis, low glucose, and high protein, will persist for days despite antibiotic treatment. Bacteria are generally not evident on Gram stain after antibiotics have penetrated the CSF (time intervals for clearance of bacteria in the CSF range from  minutes to several hours; see later section, “The Child Pretreated with Antibiotics”).
Spinal fluid should be sent for cell count, protein, glucose, Gram stain, and culture. In the event of a traumatic tap, send fluid for culture and use clinical judgment in the interpretation of other results. Decision rules correcting the WBC count based on the number of red cells may not be reliable.
The CSF of patients with bacterial meningitis tends to have lower glucose, higher protein, higher WBC counts, and a more frequent predominance of
 neutrophils relative to the CSF of patients with viral meningitis, but there is considerable overlap between the two groups. The Bacterial

Meningitis Score (Table 120­2) identifies any one risk factor associated with bacterial meningitis and has been independently validated in
16­18 multiple settings. A recent meta­analysis showed that procalcitonin had good differentiation between bacterial and viral meningitis. In the same analysis, C­reactive protein did not perform as well.  In another systematic review, procalcitonin levels of ≥2 ng/mL had a sensitivity of 40% to 50% and a specificity of 90% for predicting the presence of a bacterial infection. Using the cutoff of <0.5 ng/mL to predict low risk of bacterial infection had a
 sensitivity of 80% and a specificity of 70%. Polymerase chain reaction has been used in the past mainly for diagnosing viral meningitis. More recently,
,22 multiplex polymerase chain reaction diagnostics capable of detecting all of the major bacterial and viral causes of meningitis have been licensed.

Line probe assays based on hybridization of multiplex polymerase chain reaction have also been developed. As such diagnostics become more widely available, they can decrease the time to diagnosis and allow for the detection of causative organisms in patients pretreated with antibiotics.
TABLE 120­2
Pediatric Bacterial Meningitis Score14* Pediatric Bacterial Meningitis Score
Positive cerebrospinal fluid (CSF) Gram stain (2 points)
CSF protein >80 mg/dL (1 point)
Blood absolute neutrophil count ≥10,000 cells/mm3 (1 point)
Seizure at or before presentation (1 point)
CSF neutrophil count ≥1000 cells/mm3 (1 point)
Interpretation
 points: Aseptic meningitis very likely
 point: Aseptic meningitis less likely
 points: Bacterial meningitis more likely
Source: Adapted with permission from Nigrovic LE, Malley R, Kuppermann N. Cerebrospinal fluid pleocytosis in children in the era of bacterial conjugate vaccines.
Distinguishing the child with bacterial and aseptic meningitis. Pediatr Emerg Care 25: 112­120, 2009. [PMID: 19225382]. Copyright Lippincott Williams & Wilkins.
ED TREATMENT
ANTIBIOTICS
Antibiotics may have difficulty penetrating the blood–brain barrier. Therefore, doses used to treat meningitis are frequently higher than the doses used for other pediatric infections (Table 120­1).
For neonates, presumptive therapy for meningitis is generally ampicillin and cefotaxime or gentamicin. For older infants and children, Table 120­1 lists empiric treatment that will cover the three major bacterial causes of meningitis in the United States (N. meningitidis, S. pneumoniae, and H. influenzae
 type b).
Patients with viral meningitis and meningoencephalitis generally receive supportive treatment, although acyclovir should be used when HSV infection is suspected. Lyme disease, tuberculous meningitis, fungal meningitis, and parasitic infections of the CNS all require specific therapy.
STEROIDS
Much of the damage caused by bacterial meningitis results from the inflammatory response in the CNS. In particular, labyrinthitis can result from bacterial meningitis, producing sensorineural hearing loss. For that reason, dexamethasone therapy to reduce CNS inflammation has been proposed as an adjunct to antibiotic therapy. Data supporting the benefits of dexamethasone treatment have been mixed in children. Dexamethasone was shown to reduce the likelihood of hearing loss in children with meningitis due to H. influenzae type b in the 1980s, when that was the predominant
,26 organism. With the emergence of S. pneumoniae as the dominant strain, the data are less robust. A recent Cochrane review showed that patients with meningitis due to S. pneumoniae who were treated with dexamethasone had a lower death rate, whereas no effect on mortality was seen with meningitis due to H. influenzae or N. meningitidis. Steroids decreased the rate of hearing loss in patients with meningitis due to H. influenzae but not due to other bacteria. In the Cochrane analysis, patients in high­income countries treated with steroids were more likely to have reduced hearing loss
 or neurologic sequelae than patients in low­income countries. The American Academy of Pediatrics stated in 1990 that dexamethasone may be considered for treatment of infants and children with meningitis due to H. influenzae type b, but does not recommend steroid use in other bacterial
 forms of meningitis. If used for bacterial meningitis, dexamethasone needs to be given before or with the first dose of antibiotics to be most effective.
The dose of dexamethasone is .15 milligram/kg IV every  hours.
DISEASE COMPLICATIONS

Mortality from bacterial meningitis has been reduced to <10% with antibiotics and supportive care. However, survivors can experience sensorineural
 hearing loss, visual impairment, seizures, hydrocephalus, cognitive impairment, learning disabilities, and emotional problems. Factors predicting hearing loss include S. pneumoniae as the etiologic agent and low glucose levels in CSF. Factors predicting mortality include coma, seizures, shock, respiratory distress, neutropenia, and a high protein level in CSF. Factors predicting adverse neurologic consequences in general include coma, seizures, fever for at least  days, and a low WBC count in CSF. Additional, although less robust, predictors include symptoms for more than  hours,
 male gender, fever, and absence of petechiae.
In the ED, physicians may see respiratory compromise, shock, seizures, hypoglycemia, and hyponatremia in children with meningitis. Hypoglycemia results from sepsis and physiologic stress and is treated with administration of dextrose. Hyponatremia most commonly results from the syndrome of inappropriate antidiuretic hormone secretion due to brain inflammation. If syndrome of inappropriate antidiuretic hormone secretion is suspected, initiate fluid restriction to 75% of maintenance requirements after treating shock and dehydration. Low sodium can also be due to home oral rehydration with hypotonic liquids. Seizures can be due to brain inflammation, hypoglycemia, or hyponatremia, so correct glucose and sodium before administering antiepileptic medications.
Children with meningitis can also develop subdural effusions, empyemas, and strokes during treatment for bacterial meningitis, but these are not usually present at the time of ED presentation.
Viral meningitis and meningoencephalitis can range from mild to fulminant illness leading to death or permanent neurologic disability. Some lasting effects, such as learning disorders, can be subtle. Fungal meningitis can cause death or severe disability, particularly in immunocompromised hosts.
Eosinophilic meningitis from helminth infection is generally self­limited and does not require antifungal therapy.
DISPOSITION AND FOLLOW­UP
In almost all circumstances, admit children with suspected bacterial or viral meningitis for definitive diagnosis, treatment, and supportive care. After discharge, children need long­term monitoring for neurodevelopmental problems and hearing loss.
SPECIAL CONSIDERATIONS AND SPECIAL PATIENTS
THE CHILD WITH A VENTRICULOPERITONEAL SHUNT
One of the most common causes of shunt failure in patients with shunted hydrocephalus is shunt infection. Most infections occur soon after shunt placement. The predominant organism is Staphylococcus epidermidis, suggesting that the infecting organism is likely introduced at the time of surgery. Other infecting agents include S. aureus, gram­negative rods, Enterococcus faecalis, and Propionibacterium species. Predictors of shunt
 infection include premature birth, use of a neuroendoscope during shunt placement, and replacement of an infected shunt. Only about 10% of shunt
 infections occur more than  year after shunt surgery. Patients with late infections frequently develop peritonitis, often from appendicitis. Shunt infections can present with symptoms of increased intracranial pressure, fever, redness or swelling along the shunt, or abdominal pain. Treatment should include vancomycin and a third­generation cephalosporin. Add an aminoglycoside if the Gram stain shows gram­negative rods.
Transfer to a tertiary care center for CSF shunt tap is the best option (See Video: VP Shunt Aspiration). Imaging to assess whether the shunt is intact and is functioning should be pursued if there is any question about shunt integrity.
Video 120­1: Ventriculoperitoneal Shunt Aspiration
Used with permission from Samer Elbabaa, Division of Neurosurgery, University of North Carolina; Judith E. Tintinalli.
Play Video
THE UNVACCINATED CHILD
Widespread immunization against H. influenzae type b and S. pneumoniae has drastically reduced the rate of serious bacterial illness or meningitis from these two organisms. Children who are not immunized benefit from herd immunity. Nevertheless, when unvaccinated neonates or children develop fever, consider meningitis. Prior to the age of  months, children are less likely to develop meningismus, and it is difficult to exclude meningitis on clinical grounds alone. The septic­appearing infant or child with no immunizations should be managed conservatively with a lumbar puncture to exclude meningitis.
The real question is what to do with the unimmunized child with a fever who is not toxic appearing and has no obvious source for fever on physical examination. In children who have not been immunized, obtain a WBC count and blood culture and give ceftriaxone if the WBC count is ≥15,000/mm  .
Arrange 24­hour follow­up either in the ED or with the child’s primary provider.
THE CHILD PRETREATED WITH ANTIBIOTICS
Children who have signs or symptoms of meningitis but who have been pretreated with antibiotics present an important challenge. In one study, after receiving ≥50 milligrams/kg of a third­generation cephalosporin, sterilization of the CSF occurred as early as  minutes in meningococcal meningitis, about  hours in pneumococcal meningitis, and about  hours in group B streptococcal meningitis. Blood cultures obtained prior to antibiotic
 treatment were positive in 74% of cases. Antibiotic pretreatment was examined in another study, which showed that CSF WBC count and absolute neutrophil count were unaffected by antibiotic administration, but patients had higher CSF glucose levels and lower protein levels after about  hours
 of antibiotic administration. In the situation where a child has been pretreated, CSF assays with multiplex polymerase chain reaction may be helpful for the diagnosis of meningitis. As mentioned before, procalcitonin is emerging as a useful test for differentiating bacterial from viral meningitis. WBC count, C­reactive protein, lactate, and erythrocyte sedimentation rate have not performed as well.
THE CHILD WITH CSF LEAK
CSF leaks can occur spontaneously or in association with head trauma or surgical procedures. They can also occur as a complication of hydrocephalus. Children with CSF rhinorrhea or otorrhea are most likely to develop meningitis from S. pneumoniae. The signs and symptoms of meningitis tend to be milder in this group than in children with pneumococcal meningitis from bacteremia. Therefore, this is a situation in which meningitis is still a possibility despite a somewhat well­appearing child. Recommended treatment is with a third­generation cephalosporin and
 vancomycin.
THE CHILD WITH PENETRATING HEAD TRAUMA
Children who have experienced penetrating head trauma can get meningitis from S. aureus, coagulase­negative staphylococci such as S. epidermidis, and gram­negative rods. Initial therapy should consist of a combination of drugs including vancomycin; cefepime, ceftazidime, or meropenem; plus an
 aminoglycoside such as gentamicin or amikacin.
THE CHILD WITH A COCHLEAR IMPLANT
A cochlear implant increases the risk of meningitis in children. In most cases, the initial event is an acute episode of otitis media in the side with the implant, followed by the development of meningitis. In the first  months after cochlear implant surgery, treat otitis media with parenteral antibiotics.
After  months, treat nontoxic children with otitis media with oral antibiotics. S. pneumoniae is the most common cause of meningitis in children with
 implants. Obtain cultures of middle ear fluid and CSF in children with suspected meningitis.
Children with meningitis in the first  weeks after implantation are at risk of a greater range of pathogens than patients presenting later and should receive broad­spectrum antibiotics, such as meropenem and vancomycin. Children with symptoms of meningitis developing later than  weeks after implantation should receive the standard empiric treatment for meningitis. Consult ear, nose, and throat specialists for imaging recommendations and possible surgical management. For further discussion of cochlear implant complications, see Chapter 242, “Ear Disorders.”
THE CHILD WITH A FEBRILE SEIZURE
Children with meningitis can present with seizures. However, simple febrile seizures are more common. Simple febrile seizures occur in up to 5% of children between  and  months of age. About one third of children will experience a recurrence. The American Academy of Pediatrics defines simple febrile seizures as seizures that are generalized, last less than  minutes, and do not recur within  hours. Routine lumbar puncture is not indicated for simple febrile seizures, but should be performed if the child has an examination consistent with meningitis. Children between  and  months of age should be considered for a lumbar puncture if they are missing immunizations against H. influenzae type b or S.
pneumoniae or if their immunization status is not known. Clinicians should be able to recognize meningitis clinically after  months of age. A lumbar puncture should also be considered in children pretreated with antibiotics because antibiotics can mask the development of meningitis. Routine blood
 work, imaging, and electroencephalogram are not recommended.


