## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 42: Face and Scalp Lacerations
Wendy C. Coates
INTRODUCTION
Facial wounds are the most cosmetically apparent of all wounds and therefore warrant careful evaluation and meticulous repair technique for the best possible outcome. Most facial and scalp lacerations can be closed by the emergency physician, but consult with specialists if the technical aspects of closure are complex or exceed the skill of the individual practitioner.

Three common principles guide repair of facial and scalp lacerations. First, cleanse, irrigate, and remove foreign material to minimize infection.
Second, limit debridement of skin edges because the excellent blood supply enables tissues to recover that may initially appear nonviable. And third, consider regional nerve blocks or topical anesthesia if local anesthetic infiltration would distort anatomy or hinder wound edge alignment (see

Chapter , “Local and Regional Anesthesia”).
Use nonabsorbable monofilament suture for facial skin. Rapidly absorbable suture and tissue adhesives are alternatives in selected locations and in
,4 some patients (e.g., patients who are unlikely to return for suture removal or selected wounds in children) (Table 42­1). Use absorbable suture for mucosa and fascial layers. To minimize scarring, place percutaneous sutures on the face  to  mm from the wound edges,  mm apart, with everted edges. Place mucosal sutures  to  mm from the wound edges,  to  mm apart, and superficial including only the mucosa and not the underlying muscle or fascia. Magnification with surgical loupes may facilitate more accurate suture placement in facial wounds.
TABLE 42­1
Indications for Tissue Adhesives on the Face
Minimal tension
Not a hair­covered area
Epidermal closure only (no mucosa)
5­8
Ask about the possibility of domestic violence in patients with facial injuries, and notify appropriate authorities if suspected (Table 42­2).
TABLE 42­2
Maxillofacial Injuries and Domestic Violence in the ED
Most victims of domestic violence have maxillofacial injuries.
Women are more commonly affected than men.
Fist is most common weapon.
Left side of face is most common site of injury (from right­hand­dominant assailants).
Nasal bone is commonly fractured.
PATHOPHYSIOLOGY

Facial and scalp wounds are most often caused by a combination of sharp and blunt mechanisms. Lacerations caused by sharp objects likely have
Chapter 42: Face and Scalp Lacerations, Wendy C. Coates discrete edges, but may extend deeply and involve underlying structures, such as the muscles of facial expression, nerves, and arteries. Wounds
. Terms of Use * Privacy Policy * Notice * Accessibility caused by blunt forces burst the skin open, damage cells, and produce tissue edema, all of which slow the wound­healing process and increase risk for infection. Blunt forces are also more likely to cause diffuse underlying damage, such as fractures of the facial bones or skull.

In most patients with isolated facial trauma resulting in lacerations, the incidence of facial fractures is low, especially in children. However, in multiply injured patients, suspect underlying fracture in facial lacerations involving the infraorbital area, zygoma, nose, lips, and intraoral mucosa; perform a
,10 careful physical examination; and consider facial CT scans.
Facial and scalp lacerations have a low incidence of postrepair infection, so primary closure can usually be done in wounds up to  hours
11­13 ,15 after the injury, including most bite wounds. The presence of foreign bodies, such as soil, glass, or wood fragments, complicates
 wound healing.
SCALP AND FOREHEAD
ANATOMY
Both the scalp and forehead overlie bone with little cushioning fat and have thick skin (Figure 42­1). The one difference is that the scalp has abundant hair follicles and sebaceous glands. Three branches of the external carotid artery (occipital, superficial temporal, and posterior auricular) and two branches from the internal carotid artery (supraorbital and supratrochlear) provide a rich blood supply to the scalp and forehead. The fibrous dermal tissue limits vessel retraction after injury, so significant hemorrhage can result from an arterial laceration. The potential space between the pericranium (periosteum covering the external surface of the skull bones) and the galea aponeurosis that allows for easy movement of the scalp over the cranium also enables hematoma and infection to collect in this subaponeurotic space and spread to involve the entire forehead and scalp. This high degree of mobility sometimes leads to a scalping injury, in which a large segment of the scalp is torn off in one piece.
FIGURE 42­1. Layers of the scalp.
CLINICAL FEATURES
For some patients with scalp and forehead lacerations, the wound may be only a minor part of the overall injury. Perform a focused assessment looking for intracranial injury before definitive wound care. Control scalp hemorrhage by applying direct pressure, clamping the involved vessel(s) at
 the wound edges (e.g., using Raney clips; see Chapter , “Wound Preparation”), or placing a figure­of­eight suture at the bleeding wound edge.
Inspect scalp lacerations, and gently palpate with a gloved finger to determine depth and to identify galeal laceration or depressed skull fracture.
Evaluate palpable depressions with a CT scan. Orientation of forehead lacerations has important cosmetic implications. In general, forehead wounds that fall parallel to the lines of skin tension (and perpendicular to muscle fibers) yield the best cosmetic results. For example, the horizontal lines seen on the forehead when the brow is raised are perpendicular to the frontalis muscle underneath (Figure 42­2).
FIGURE 42­2. Skin tension lines. Skin tension lines are perpendicular to underlying muscles.
TREATMENT
Anesthesia can be provided by topical, local, or regional infiltration. Topical agents alone, such as lidocaine­epinephrine­tetracaine or lidocaine­
17­22 prilocaine (EMLA®), provide adequate anesthesia in many patients and reduce the pain of supplemental local anesthetic injection. Local anesthetics containing epinephrine are often used in highly vascular wounds to help control hemorrhage from small vessels. Children may need sedation for wound repair (see Chapter 115, “Pain Management and Procedural Sedation in Infants and Children”).
Irrigate to reduce contamination and lessen the risk of wound infection. However, in resource­poor situations, because the face and scalp are highly
 vascular, clean­appearing wounds have been repaired using adhesive strips, without prior cleansing and irrigation.
Repair of Scalp Lacerations

Do not shave hair before wound closure, as shaving increases the risk of infection. To visualize the injured area, brush the hair aside or matt it down
 with an ointment, such as bacitracin zinc or petrolatum. If visualization is still difficult, trim the adjacent scalp hair with scissors. Suture accessible
  lacerations of the galea to prevent formation of a subgaleal hematoma (Table 42­3).
TABLE 42­3
Suturing Guidelines for the Face and Scalp
Area Suture Size Anesthetic Removal
Scalp
Galea Absorbable 4­0 Local Not removed
Skin Staples Standard Local  d
Nonabsorbable 4­0 Local  d monofilament
Rapidly absorbing 4­0 Local Not removed
Forehead
Muscle fascia Absorbable 4­0 Local or supraorbital nerve block Not removed
Skin Nonabsorbable 5­0 or 6­0 Local or supraorbital nerve block  d monofilament
Tissue adhesive May need deep layer — Not removed
Cheek and face
Muscle fascia Absorbable 4­0 Local or infraorbital nerve block Not removed
Skin Nonabsorbable 6­0 Local or infraorbital nerve block  d monofilament
Rapidly absorbing 6­0 Local or infraorbital nerve block Not removed
Tissue adhesive May need facial layer — Not closure removed
Eyelids
Skin Nonabsorbable 6­0 or 7­0 Supra­ or infraorbital nerve block  d monofilament
Nose
Mucosa Rapidly absorbing 4­0 Intranasal Not removed
Cartilage Absorbable (if necessary) 5­0 Intranasal Not removed
Skin Nonabsorbable 6­0 Local or intranasal 3–5 d monofilament
Ears
Skin Nonabsorbable 6­0 Auricular block  d monofilament
Perichondrium Absorbable 5­0 Auricular block Not removed
Lips
Mucosa Rapidly absorbing 5­0 Local, infraorbital, mandibular, or mental nerve block Not removed
Muscle fascia Absorbable 4­0 or 5­0 Local, infraorbital, submandibular, or mental nerve Not block removed
Skin Nonabsorbable 6­0 Local, infraorbital, or mental nerve block 3–5 d monofilament
Close scalp lacerations with surgical staples or simple interrupted percutaneous sutures using nonabsorbable monofilament or rapidly absorbable
28­31 material. Leave suture tails long, and use sutures of a color different than the hair for easy suture removal.
,32,33
Hair braiding is a technique combining hair apposition and tissue adhesive. In this technique, bring together three to seven strands of hair from opposite sides of the wound, twist the strands once, and secure them with a drop of tissue adhesive. This technique requires the wound edges to approximate with little tension, so subcutaneous sutures are sometimes necessary before hair apposition is used to close the skin.
Consider a pressure dressing over a deep scalp laceration for the first  hours after repair, to prevent wound hematoma formation.
Repair of Forehead Lacerations
Forehead lacerations are categorized as either superficial, meaning the frontalis muscle is not injured, or deep, indicating the frontalis muscle is involved. Start repair by using key stitches to align skin tension lines and the hairline (Figure 42­3). For superficial lacerations, close the skin with 6­0
,34,35 nonabsorbable interrupted suture or tissue adhesive. For deep lacerations, close the muscle layer to avoid noticeable defects, especially when the facial muscles of expression are involved. Close the muscle fascia with buried 5­0 absorbable suture. The dermis may be approximated with a buried subcuticular stitch. Close the epidermal layer with 6­0 nonabsorbable sutures in a simple, interrupted fashion; with skin closure strips; or with
 tissue adhesive (Table 42­3). Adhesive strips or tissue adhesives are useful if the patient is at risk for keloids or hypertrophic scars.
FIGURE 42­3. Key stitches in the forehead to align natural skin tension lines and cosmetically important landmarks.
Repair of Eyebrow Lacerations
Do not clip or shave eyebrows because their delicate contour and form are valuable landmarks for wound edge reapproximation. Debridement of loose or nonviable skin in the eyebrow region should be minimal and, if necessary, done so that the remaining hairs preserve as much as possible of the original length, width, and curve of the eyebrow. Use care to align the hair margins. Use sutures that are a different color from the hair and leave long tails to facilitate removal.
EYELIDS
ANATOMY
The eyelid is composed of five layers: skin, subcutaneous tissue, orbicularis oculi muscle, tarsal plate, and conjunctiva. The muscular layer controls lid closure and forms both the medial and lateral canthus. Fibers of the orbicularis oculi wrap around the lacrimal system. Nerve supply to the eyelid arises from the temporal and zygomatic branches of the facial nerve. The tarsal plate forms the main body of the lower half of the lid and consists of elastic tissue in a dense matrix of connective tissue. Embedded in the tarsal plate are the meibomian glands, which open onto the white line just in front of the conjunctival edge of the lid margin. In the lid margin, the eyelashes are arranged in irregular rows with their follicles extending obliquely into the tarsal plate.
The lacrimal system begins at the upper and lower puncta that transition into the canaliculi. The canaliculi travel medially into the lacrimal sac that extends inferiorly to the nasolacrimal duct responsible for tear drainage into the nose (Figure 42­4).
FIGURE 42­4. Periorbital anatomy.
CLINICAL FEATURES
The structures surrounding the eye and eyelids are delicate as well as cosmetically and functionally important. The eyelids are thin and offer limited protection from injuries to the globe, so examine the eye’s structure and function before laceration repair. Once the integrity and function of the globe and orbital structures are verified, examine the lid for involvement of the canthi, the lacrimal system, or penetration through the tarsal plate or lid margin. Eyelid injuries within  to  mm of the medial canthus are at risk for canalicular laceration, especially if associated with
 medial wall blowout fractures. Refer the following injuries to an ophthalmologist or oculoplastic specialist: (1) injuries involving the inner surface of the lid, (2) wounds across lid margins, (3) injuries to the lacrimal duct, (4) wounds associated with ptosis, or (5) injuries extending into the tarsal plate (Figure 42­5).
FIGURE 42­5. Cross­section of the eyelid. [Reproduced with permission from Riordan­Eva P, Augsburger JJ, eds: Vaughn & Asbury’s General Ophthalmology, 19th ed. Figure 1­22, New York, NY: McGraw­Hill, 2018.]
Poor repair of the inside surface of the eyelid can lead to scar formation and persistent corneal irritation. Imprecise approximation of the lid margins leads to notching. Failure to recognize and properly repair the lacrimal system can result in chronic tearing (epiphora). Wounds through the tarsal plate or with ptosis require careful closure of the orbicularis oculi to preserve normal eyelid appearance. In general, wounds that are superficial, and especially those parallel to the lid margins, may be carefully repaired by the emergency physician.
TREATMENT
After topical anesthesia, gently irrigate the wound with normal saline. For closure, use 6­0 or 7­0 nonabsorbable monofilament for simple interrupted percutaneous sutures. Avoid deep penetration of the needle through the lid and into the underlying globe. Do not use tissue adhesive near the eye, as
 adhesives may abrade the cornea or bond the lids together. If tissue adhesive inadvertently finds its way onto the globe, instill topical ophthalmic anesthetic drops to numb the cornea and conjunctiva, apply ophthalmic erythromycin ointment to loosen the adhesive, and remove loose pieces of
 adhesive with cotton swabs. If the eyelids are unintentionally bonded, do not force the eyelids open. A conservative approach appropriate in children is to wash the lids thoroughly with warm water and apply an eyepatch; the tissue adhesive will loosen in  to  days, releasing the bond. Surgical
,40 debridement with trimming of the eyelashes to remove the glue is an alternative in adults and children under sedation.
NOSE
ANATOMY

The nose is especially vulnerable to blunt trauma, and nasal fracture is the most common fracture in victims of domestic violence and assault. The nose is composed of cartilaginous and osseous structures that support the overlying skin and musculature and the underlying mucosa. It is separated into halves by the septum. Two C­shaped alar cartilages that are covered directly by skin form the tip of the nose. The interior of the nose is covered by specialized skin with mucus­producing cells and thick, long hairs near the end, whereas the proximal portion of the nasal lining is made up of ciliated pseudostratified columnar epithelial cells.
CLINICAL FEATURES
The most important assessment of nasal lacerations is to determine their depth and the involvement of the deeper tissue layers
 and septum. Exposed cartilage or penetration through all tissue layers increases the risk of infection. Inspect the nasal septum and look for discolored lateral bulging indicating a septal hematoma. This hematoma develops between the cartilage and its protective mucoperichondrial layer and may produce complications such as (1) permanent thickening of the septum, causing partial airway obstruction of the nasal passage; (2) necrosis and subsequent erosion of the septum, resulting in communication between the nasal passageways; or (3) septal erosion leading to a saddle­nose deformity. With direct blunt trauma to the nose, assess for a cribriform plate fracture with cerebrospinal fluid rhinorrhea.
TREATMENT

Epinephrine­containing local anesthetics are acceptable for infiltrative anesthesia on the nose. Topical application of lidocaine into the nasal cavity may provide sufficient anesthesia for local wound repair. Insertion of multiple cotton­tipped swabs or plain nasal packing gauze soaked in 4% lidocaine solution is usually sufficient (Figure 42­6A). After several minutes in place and before repair, remove the swabs or gauze.
FIGURE 42­6. The nose. A. Nasal anesthetic technique using cotton­tipped applicators. B. Frontal view showing closure of skin edges.
Close superficial lacerations to the skin layer with 6­0 nonabsorbable monofilament simple interrupted sutures. Close lacerations over exposed cartilage promptly. Preserve any small pieces of loose cartilage under the skin for use in future revision.
If the laceration extends through all tissue layers and involves the nostril, begin closure with a 5­0 nonabsorbable monofilament suture that aligns the skin surrounding the entrance to the nasal canals at the alar margin (Figure 42­6B). Initially, leave the ends untied and long to facilitate the closure of the deeper structures. Gentle traction on this suture facilitates alignment of the mucosa and cartilage layers during placement of subsequent sutures.
Close the mucosal layer with 5­0 rapidly absorbable interrupted sutures, and reirrigate the area gently from the outside. Placement of sutures directly into the cartilage is rarely needed; in most cases, closure of the overlying skin is usually sufficient to align the cartilage. If necessary to align cartilage pieces, place a minimal number of 5­0 absorbable sutures through the cartilage. Reevaluate the initial stitch at the alar margin, and then tie it. Finally, suture the remainder of the skin with 6­0 nonabsorbable monofilament material close to the wound edges. With extensive wounds, consider a loose anterior nasal pack with antibiotic­impregnated gauze to prevent scar contracture.
Small unilateral septal hematomas can often be aspirated through an 18­gauge needle. Larger hematomas require an incision in the septal
 mucoperichondrium overlying the hematoma (Figure 42­7). After hematoma evacuation, place an anterior nasal pack to discourage reaccumulation of the hematoma. Bilateral hematomas are often drained in the operating room. There is no evidence to support the use of
,45 prophylactic antibiotics after nasal cartilage injury or septoplasty with anterior nasal packing.
FIGURE 42­7. Incision for drainage of septal hematoma. Septal hematoma with markings for a vertical incision through the mucoperichondrium. [Reproduced with permission from Reichman EF, ed: Reichman’s Emergency Medicine Procedures, 3rd ed. Figure 204­5. Copyright © 2019 McGraw­Hill Education. All rights reserved.]
EARS
ANATOMY
The external ear begins with the external auditory canal and extends to the fibrocartilaginous framework of the auricle and the soft fatty tissue of the earlobe. The blood supply to the ear arises from the superficial temporal and posterior auricular arteries. The majority of the sensory innervation is from the anterior and posterior branches of the greater auricular nerve. The auricular branches of the vagus nerve supply the posterior wall of the external auditory canal, so lacerations that involve this area cannot be anesthetized with auricular nerve blocks.
CLINICAL FEATURES
Lacerations caused by blunt forces to the ear can rupture the tympanic membrane or produce a subchondral hematoma even in the absence of a
,46 laceration. Lacerations caused by blunt or shear forces may also involve the cartilage. If a wound extends deep into the canal, verify the integrity of the tympanic membrane. The presence of hemotympanum, mastoid area ecchymoses, or cerebrospinal fluid otorrhea suggests a basilar skull fracture.
TREATMENT
Insert a cotton plug into the ear canal during wound preparation and irrigation. Regional anesthesia by auricular field block is ideal (see Chapter ,
“Local and Regional Anesthesia”). Hemostasis before repair of an auricular laceration is important to prevent the formation of a hematoma.

Close superficial lacerations to the skin with 6­0 nonabsorbable monofilament interrupted sutures. Cover any exposed cartilage to prevent subsequent infection. Do not remove crushed or loose pieces of cartilage under the skin, as the pieces may be beneficial if reconstructive surgery is necessary. Do not debride the edges of an auricular laceration because there is very little excess skin available to cover the existing cartilage.
In most through­and­through lacerations of the auricle, skin and perichondrial approximation will adequately support and align the underlying
,46 cartilage (Figure 42­8). If the overlying skin is avulsed, refer to a specialist for repair. Partial or complete avulsion of the auricle requires immediate consultation.
FIGURE 42­8. Repair of auricular laceration. A. Laceration through auricle. B. Interrupted 6­0 nonabsorbable sutures approximate the skin edges.
A perichondral hematoma is a potentially damaging complication after repair of auricular lacerations. The collection of blood and buildup of pressure may damage the cartilage and create a deformed external ear. A postrepair auricular pressure dressing can prevent hematoma formation (Figure
42­9). Reevaluate the dressing and the ear in  hours. If there is no hematoma, discontinue the pressure dressing.
FIGURE 42­9. Auricular pressure dressing. A. Apply a nonadherent dressing over the repair site. B. Conform this dressing to the shape of the ear using gentle pressure. C. Place opened and fluffed gauze pads behind the ear to fill the space between the skull and pinna and in front of the ear to fill the interior contours. D. Wrap the head and ear with gauze wrap. E. Cover with a light (not tight) elastic bandage wrap. Do not enclose opposite external ear.
An auricular hematoma may develop within the first few days after injury. The patient typically presents with pain and swelling; the ear may look purplish; and the repair site is swollen, warm, and boggy to touch, and blood often oozes when the area is squeezed. Treatment requires evacuation of the hematoma and bleeding control. If a specialist is not available, the emergency physician may choose to drain the hematoma. The initial step is to
 remove all the sutures, drain the blood, and thoroughly irrigate the wound. Then resuture the wound and apply a pressure dressing.
LIPS
ANATOMY
The external surfaces of the lips have three distinct regions: skin, vermilion, and oral mucosa. The cosmetically important junction of the skin and the red portion of the lip is the vermilion border. The orbicularis oris muscle surrounds the mouth. Its integrity is responsible for retaining the saliva inside the mouth, producing the bilabial sounds of speech, and providing facial expressions. The infraorbital nerve supplies the upper lip, and the submandibular nerve supplies the lower lip. Both are branches of the trigeminal nerve and can easily be blocked by regional anesthetic techniques.
The lips are richly supplied by the labial arteries.
CLINICAL FEATURES
Perform both extra­ and intraoral examinations to evaluate completely for injury. Fully explore lacerations, teeth, and mucosa. Identify missing, impacted, or fractured teeth (see Figure 245­2 in Chapter 245, “Oral and Dental Emergencies”) or exposed bone of the maxilla or mandible. If portions of the teeth are missing, after adequate anesthesia, explore the wound fully because broken­off pieces may become embedded in the laceration or
48­50 may be aspirated. Note if lacerations cross the vermilion–skin and/or the vermilion–mucosal borders.
TREATMENT
Mucosal lip lacerations may not need to be sutured if they are isolated and the wound edges spontaneously approximate. Large or gaping wounds should be closed with a rapidly absorbable 5­0 suture. Carefully place the suture to include only mucosa with entrance  to  mm from the wound edges, and use care to evert the edges. Larger tissue bites can bunch the mucosa and pucker the outside skin.
Through­and­through lacerations that do not include the vermilion border should be closed in layers. Close the mucosal layer with a 5­0 rapidly absorbable suture as described in the previous paragraph, followed by gentle reirrigation from the outside. Next, approximate the orbicularis oris muscle fascia with 4­0 or 5­0 absorbable suture material with a simple interrupted or horizontal mattress technique. Finally, after repeat irrigation, suture the skin with 6­0 nonabsorbable monofilament sutures in a simple interrupted fashion or use tissue adhesive.
Wounds that cross the vermilion border should be repaired by placing the first stitch with 6­0 nonabsorbable monofilament suture to precisely align
 the edges of the vermilion border (Figure 42­10). Even  mm of step­off will be cosmetically unappealing. After this first stitch, repair the vermilion and skin with the same 6­0 material, and repair the mucosa and underlying muscle with 5­0 rapidly absorbable suture. A useful technique in some cases is to leave the initial alignment suture untied and apply gentle traction on the ends to help approximate and align the underlying tissue as the skin and vermilion are closed.
FIGURE 42­10. Lip laceration repair. A. The first suture is placed to align the vermilion skin junction. B. The orbicularis oris muscle fascia is then repaired with 5­0 absorbable sutures. C. The irregular edges of the skin are then approximated with 6­0 nonabsorbable sutures.
INTRAORAL MUCOSAL LACERATIONS
ANATOMY
Two types of intraoral mucosal lacerations are common: those involving the buccal mucosa and those at the mucosal reflections. Buccal mucosal lacerations near the parotid duct opening, identified as a small papilla adjacent to the upper second molar, may injure that structure. Lacerations of the mucosal reflections are located at the transition from the cheek to the outside surface of the maxilla or mandible. Because of the loose attachment of the mucosa in this area, these lacerations may have great depth and extend deeper than initially suspected.
CLINICAL FEATURES
Visualize and explore intraoral lacerations to determine their depth and extent. Lacerations of the mucosal reflections are easily missed unless the lips are manipulated to see into all the recesses. Evaluate the adjacent teeth for fracture or avulsion, because missing tooth fragments may be embedded in the wound, swallowed, or aspirated into the airway.
TREATMENT
Small intraoral lacerations do not need routine repair and can be allowed to heal naturally. Suture closure of intraoral lacerations is indicated when wounds are large enough to trap food particles or have a tissue flap that interferes with chewing. Anesthesia may be achieved by
 dripping 1% lidocaine into the wound and waiting for  minutes before suture repair. Use 4­0 rapidly absorbing suture to close the mucosa with edges everted. To avoid bunching of the mucosa as the suture knot is tied, insert the needle about  to  mm from the edge of the wound. Include only the mucosa in the suture because an external pucker may be created if the underlying muscle is ensnared in the suture loop. Typically, sutures placed  mm apart are adequate.
CHEEKS AND FACE
ANATOMY

The cheek area has two structures that influence wound repair: the parotid duct and branches of the facial nerve (Figure 42­11). The opening of the parotid duct is adjacent to the second maxillary molar; wounds in this region can lacerate the parotid duct. As the facial nerve traverses the parotid gland, it divides into five major segments, the precise courses of which are difficult to predict. Therefore, lacerations or deeply placed sutures may ensnare one of these branches.
FIGURE 42­11. 
Cheek anatomy. The course of the parotid duct is along a line drawn from the lower border of the tragus to the corner of the mouth. The five branches of the facial nerve are the temporal, zygomatic, buccal, marginal mandibular, and cervical.
CLINICAL FEATURES
Evaluate wound depth and assess for damage to the parotid gland, parotid duct, and facial nerve. Assess the teeth for fracture, avulsion, or fragments embedded in the wound. Suspect parotid duct injury when the wound crosses a line from the tragus to the corner of the mouth and is posterior to a vertical line downward from the lateral canthus. The buccal branch of the facial nerve and a branch of the facial artery travel with the parotid duct, so facial paralysis or arterial bleeding from the wound should arouse suspicion that the parotid duct is also injured. Parotid duct laceration can be confirmed by inserting a 19­gauge silastic tube into the intraoral parotid duct papilla and seeing if the catheter is visible in the wound. Alternatively, a small amount of saline can be injected into the tube while observing for flow in the wound. These procedures require patient cooperation and are usually performed by the consulting specialist.
TREATMENT
Repair superficial lacerations that involve the cheek and surface of the face with 6­0 nonabsorbable monofilament, simple, interrupted, percutaneous sutures. Alternatives include adhesive strips, tissue adhesives, or in selected cases, subcuticular closure with rapidly absorbing suture. If there is significant skin tension, place intradermal absorbable sutures, and ensure the parotid duct is not caught in the suture (Figure 42­11). If the parotid duct is injured, operative repair is indicated.
A full­thickness cheek laceration traverses the skin and the underlying subcutaneous tissue/muscle and penetrates through the intraoral mucosa.
Such wounds are repaired in layers, starting with the intraoral mucosa. Once the mucosa is closed, reirrigate the wound before closure of the subcutaneous layer with 5­0 absorbable suture and skin with 6­0 nonabsorbable suture, tissue adhesive, or adhesive strips.
DISPOSITION AND FOLLOW­UP
Where possible, the wound should be dressed with either an antibiotic ointment or nonadherent dressing material to maintain moisture and
54­56 encourage wound healing.
Patients should be discharged with routine wound­care instructions (see Chapter , “Postrepair Wound Care”) and, if the injury resulted from a major blunt impact, closed head injury precautions. Remove scalp sutures or staples in  days, and remove nonabsorbable percutaneous sutures in the forehead, external ear, or lips in  days. Underlying absorbable sutures will maintain structural integrity for wounds that were under tension.
Percutaneous nonabsorbable sutures placed in the eyelid, nose, or face should be removed in  to  days. A thin layer of ophthalmic antibiotic ointment may be applied in place of a dressing; do not apply antibiotic ointment intended for routine use elsewhere around the eye. Remove intranasal packing in  to  days.
Auricular pressure dressings should be left undisturbed for  hours and then removed for inspection of the wound site. If the wound is healing without infection or hematoma, replacement of the pressure dressing is not necessary.
Patients with intraoral lacerations should practice good oral hygiene and rinse their mouth several times a day. There is no evidence to support the use
,58 of prophylactic antibiotics for intraoral lacerations and through­and­through facial wounds; their use is a matter of physician preference.


