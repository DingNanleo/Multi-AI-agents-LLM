University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 15: Acid­Base Disorders
Gabor D. Kelen; David M. Cline
INTRODUCTION
This chapter describes a practical approach to the clinical evaluation and treatment of acid­base disorders. We discuss the traditional approach recognizing that acid­base homeostasis is maintained by respiratory control of the partial pressure of carbon dioxide (PCO ) through changes in

– + ,2 alveolar ventilation and control of HCO reabsorption and H excretion by the kidneys. The traditional bicarbonate­centered model continues to be

 the most commonly used at the bedside.
PATHOPHYSIOLOGY
+
Plasma [H ]* is influenced by the rate of endogenous production, the rate of excretion, exogenous addition (e.g., acetylsalicylic acid ingestion), and the
 buffering capacity of the body. Buffers mitigate the impact of large changes in available hydrogen ion on plasma pH.
Buffer systems that are effective at physiologic pH include hemoglobin, phosphate, proteins such as albumin, and bicarbonate (Figure 15­1). One can
+ consider the [H ] to be the result of all physiologic buffers acting on the common pool of hydrogen ions.
FIGURE 15­1. Schematic representation of hydrogen ion homeostasis.
–
The quantity of [HCO ] in relation to carbonic acid buffer in the system is not fixed, but varies according to physiologic need. This flexibility is largely
 provided by pulmonary exhalation of carbon dioxide (CO ), which can vary significantly and change rapidly as required by alterations in the underlying
 acid­base status.

Chapter 15: Acid­Base Disorders, Gabor D. Kelen; David M. Cline 
– –
T©h2e0 k2i5d nMecyG reragwul aHtiells. AHlCl ORig hetxsc rReetisoenr vaendd. t h Tee fromrms aotfi oUns eo f * n Perwiv aHcCyO Po. lTichye * r aNtoet oicfe t h * eAscec persosciebsilsietys is dependent on the underlying acid­base status.

The renal response to pulmonary acid­base disturbances begins within  minutes of onset, but requires hours to days to achieve equilibrium.
+
Any condition that acts to increase [H ]—whether through endogenous production, decreased buffering capacity, decreased excretion, or exogenous
+ addition—is known as acidosis. Similarly, any condition that acts to decrease [H ] is termed alkalosis. The terms acidemia and alkalemia refer to the net
+ imbalance of [H ] in the blood.
Acid­base disturbances are further classified as respiratory or metabolic. Respiratory acid­base disorders are due to primary changes in PCO , and

– metabolic acid­base disorders reflect primary changes in [HCO ]. Compensatory mechanisms are, by definition, not “disorders,” but rather normal
 physiologic responses to acid­base derangements. Failure of appropriate compensatory response implies the presence of another primary acid­base disturbance.
THE ANION GAP
+
The principle of electrical neutrality requires that plasma have no net charge. The charge of the predominant plasma cation, Na , must therefore be
 – –
“balanced” by the charge of plasma anions. Although HCO and Cl constitute a significant fraction of plasma anions, the sum of their concentrations
 does not equal that of sodium. Therefore, there must be other anions present in the serum to maintain electrical neutrality. These anions are primarily albumin, phosphate, sulfate, organic anions such as lactate, and the conjugate bases of ketoacids. Because these substances are not commonly
2+ 2+ measured, they are termed unmeasured anions. Unmeasured cations also exist, largely in the form of Ca and Mg . The unmeasured anion
+ – – concentration, the anion gap (AG), that is, the difference between the serum [Na ] and the sum of serum [Cl ] and [HCO ], equals the concentration of

2+ 2+ + the unmeasured anions. There are other cations that could be considered in the equation, such as [Ca ], [Mg ], and [K ]; however, typically they are not included. Most laboratories now provide a calculated AG in their reports of blood chemistries; readers should check with their own laboratories for information on their institutional methods. As with other acid­base concepts, the accepted “normal” range for the AG is less important than whether it has changed in relation to the patient’s steady­state baseline value. Thus, a relative change in the AG, referred to as the delta gap, may be more important than the actual AG value. Virtually all AG values above  mEq/L can be considered abnormal, even when there are no previous comparison values available. The common laboratory threshold is  mEq/L.
Elevations of the AG are most commonly associated with metabolic acidosis (Table 15­1).
TABLE 15­1
Unmeasured Anions Associated With an Elevated Anion Gap Metabolic Acidosis
Diagnostic
Anion Species Origin Diagnostic Adjuncts
Category
Renal failure [PO 2–], [SO 2–] Protein metabolism BUN/creatinine

(uremia)
Ketoacidosis Ketoacids, lactate Fatty acid metabolism Serum/urine ketones
Diabetic β­ Fatty acid metabolism Specific test now available (older nitroprusside test yields false­negative hydroxybutyrate, result for β­hydroxybutyrate) lactate
Alcoholic Acetoacetate, Fatty acid metabolism lactate
Starvation β­ Consider coexistent volume depletion hydroxybutyrate
Lactic acidosis* Lactate Metabolism Lactate level for subtypes
Sepsis Lactate Hypoperfusion, anaerobic Culture/organism­specific tests metabolism
Cardiac Lactate Hypoperfusion/reperfusion injury Consider other acidosis arrest
Liver failure Lactate Decreased lactate clearance Liver function tests
Iron Lactate Disruption of cellular metabolism Serum iron level
Metformin Lactate Inhibition of gluconeogenesis
Cyanide Lactate Mitochondrial dysfunction, histotoxic hypoxia
Carbon Lactate Hypoxia, anaerobic metabolism Carbon monoxide level monoxide
Thiamine Lactate Aerobic metabolism interrupted, Assess peripheral sensory and motor function for neuropathy deficiency lactate accumulates
Exogenous poisoning* Methanol Formate Methanol metabolism Osmolal gap
Ethylene Oxalate and EG metabolism favors pyruvate Osmolal gap Oxalate crystals (urine) glycol (EG) organic anions conversion to lactate
Salicylate Salicylate Salicylate, lactate, ketoacids Concomitant respiratory alkalosis and metabolic acidosis
Isoniazid Lactate Anaerobic metabolism, lactate accumulation
*This is not an exhaustive list; several other causes exist.
Albumin is a major component of the AG. Critically ill patients are frequently hypoalbuminemic, which may decrease the AG into the normal range,
 effectively masking the presence of a wide AG acidosis. If the albumin is significantly low, then the normal range for the AG should be lower. For every
 drop in the albumin level by  gram/dL, the normal AG range should be lowered by approximately .5. ∗Standard nomenclature is used in this chapter. The presence of brackets, [ ], surrounding an element or molecule implies the term concentration.
Without the brackets, the chemical expressions simply refer to the element or molecule.
PARAMETERS REQUIRED FOR CLINICAL ACID­BASE EVALUATION
When taking a medical history, ask about events that may result in the gain or loss of acid or base, such as vomiting, diarrhea, medications, or ingestions of toxins, and seek evidence of dysfunction of the organs of acid­base homeostasis—the liver, kidneys, and lungs.
– + + – –
Obtain blood gases (pH, PCO , and [HCO ]), electrolytes ([Na ], [K ], [Cl ], and [HCO ]), and other tests that affect the patient’s acid­base status

(albumin, lactic acid, creatinine, BUN, drug levels of suspected ingestions such as salicylate). Based on current history and physical and past medical history, consider the need to obtain calcium, magnesium, phosphate, serum ketones, glucose, lactate, serum osmolality, and urine electrolytes and osmolality. Most clinical laboratories measure two of the parameters reported in blood gas results (most commonly the pH and PCO ) and use the

–
Henderson­Hasselbalch equation to calculate the third ([HCO ]).

Venous or capillary blood gases, rather than arterial samples, may be satisfactory for many clinical situations. Venous PCO may be a sensitive screen

 for hypercarbia (cutoff  mm Hg), but the venous and arterial PCO values exhibit wide variation and are not interchangeable. Confirming an elevated

 ,10 venous lactate with an arterial sample is not necessary. See the Box, “Clinical Approach to Acid­Base Disorders,” for one method of assessing acidbase disorders.
Clinical Approach to Acid­Base Disorders
Following is one method that has worked well for the authors. You will need results of a blood gas and serum sodium, chloride, and bicarbonate to apply this method. This method requires methodical interpretation of laboratory results and correlation with clinical findings.
. Look at the pH. If it is decreased below .35, the primary (or predominant) disturbance is acidemia; go to step . If the pH is increased above
–
.45, the predominant disturbance is alkalemia; go to step . If the pH is in the normal range, but the [HCO ] or the PCO is abnormal, consider a
  mixed acid­base disorder.
– –
. Acidemia. If the pH indicates acidemia, the acidemia type can be ascertained by examining the [HCO ] and PCO . If the [HCO ] decreased, go

– first to step ; if the PCO is elevated, but the [HCO ] is normal, go to step .  
. Metabolic Acidosis
– a. If the [HCO ] is lower than the laboratory normal range (implying a primary metabolic acidosis), then the anion gap (AG) should be examined

 and, if possible, compared with a known steady­state value.
+ – – b. Calculate the AG: AG = [Na ] – ([HCO ] + [Cl ])

If the AG is increased compared with the known steady­state value or is >12 (or above institutional threshold), then by definition, a wide
–
AG metabolic acidosis is present, and the absolute change in the AG should be compared with the absolute change in the [HCO ] from
 normal to detect other disturbances.
If the AG is unchanged (or in the normal range), then the disturbance is nonwidened or normal AG metabolic acidosis, typically associated with hyperchloremia.
– 
If the change in the AG (increase) is equal to the change in the [HCO ] (decrease), then the wide AG acidosis is termed pure. If the AG

– has risen more than the [HCO ] has decreased, then there is also likely to be a concomitant metabolic alkalosis. If the change in the AG

– is less than the change in the [HCO ], then a normal AG acidosis is also present. (This is a difficult concept, but two separate physiologic

+ mechanisms resulting in increased [H ] can occur simultaneously.) c. Next examine whether the ventilatory response is as expected.
–
The expected respiratory compensation is 1:1, the PCO decreases by  mm Hg for every  mEq/L decrease in [HCO ].

(1) If the measured PCO from the blood gas equals the expected value based on the calculated PCO (which is determined by the

– decrease in the [HCO ]), there is appropriate respiratory compensation. Note that the pH will not return to normal.

(2) If the measured PCO from the blood gas is higher than the expected value based on the calculated PCO (which is determined by

– the decrease in the [HCO ]), there is a concomitant respiratory acidosis. With higher than expected PCO , think respiratory
  acidosis.
(3) If the measured PCO from the blood gas is lower than the calculated PCO (which is determined by the decrease in the [HCO
–
]),
   there is also a concomitant primary respiratory alkalosis.
. Respiratory Acidosis
– a. If the PCO is elevated from normal (rather than the [HCO ] being decreased), the primary disturbance is respiratory acidosis.
  b. The next step is to determine if the respiratory acidosis is acute or chronic by examining the ratio of the downward change in pH (from
+ normal) to the upward change in PCO (from normal). By determining the drop in pH, you are examining the rise in [H ]. Subtract the
 measured pH on the blood gas from the institution’s lower limit of normal; use the number of hundredths (to the right of the decimal point).
Divide this number by the elevation in PCO in mm Hg (above normal range).

If the ratio is .8, it is considered acute.
If the ratio is .33, it is considered chronic.
If the ratio is between .8 and .33, it is probably an acute exacerbation of the chronic condition. An alternate explanation is that a
– metabolic acidosis is also present as evidenced by a decreased [HCO ].

+
If the ratio is >0.8, there must be a metabolic acidosis as an explanation for the excess [H ].
If the ratio is <0.33, a metabolic alkalosis must also be present.
– –
. Alkalemia. If the pH is >7.45, the alkalemia type can be determined by examining the [HCO ] and PCO . If the [HCO ] is increased, go to step 
   first; if the PCO is decreased, go to step . 
–
. Metabolic Alkalosis. If [HCO ] is elevated, there is a primary metabolic alkalosis.
 a. There is an expected ventilatory response, although it is quite varied.
– b. The ratio of the change upward in PCO (mm Hg) to the change upward in [HCO ] (mEq/L), each from the institutional norms, can be
  examined. If the ratio is much less than .7, there is also a respiratory alkalosis (in addition to the metabolic alkalosis). If the ratio is close to
.7, this is likely to be a compensatory ventilatory response. If the ratio is well above .7, respiratory acidosis is concomitantly present.
. Respiratory Alkalosis. If the PCO is lower than normal, there is a primary respiratory alkalosis.

+ a. The ratio of the change in [H ] to the change in PCO should be examined. Subtract the institution’s upper limit of normal pH from the
 measured pH on the blood gas; use the number of hundredths (to the right of the decimal point). Divide this number by the decrease in PCO
 in mm Hg (below normal range).
Acute respiratory alkalosis has a ratio of about .75. If the ratio is well above .75, there is probably also a concomitant metabolic
+ alkalosis to explain the greater than expected decline in [H ]. If the ratio is smaller, the condition is chronic or there may also be a metabolic acidosis component.
. Mixed Acid­Base Disorder. Every arterial blood gas that shows no or minimal pH derangement should still call for examination of the PCO ,

– –
[HCO ], and AG, because there may well be a mixed acid­base disturbance. It is quite possible for the pH, [HCO ], and PCO to be normal and yet

+ – + have significant acid­base disturbances. The only evident abnormality may be the AG. Take the example of an [Na ] of 145, [Cl ] of , [K ] of .5,
– and [HCO ] of  and a normal arterial blood gas. All the numbers look reasonably normal. However, the AG is , so by definition, there must
 be a wide AG metabolic acidosis. The explanation for the normal numbers is a concomitant metabolic alkalosis.
METABOLIC ACIDOSIS
–
Metabolic acidosis may result from HCO loss, administration of acid (parenteral nutrition), or endogenous production and accumulation of acid.

–
Loss of HCO occurs by externalization of intestinal contents (e.g., vomiting, enterocutaneous fistulae) and renal wasting of bicarbonate (e.g., renal
 tubular acidosis, carbonic anhydrase inhibitor therapy). Endogenous acids accumulate in renal tubular acidosis, ketoacidosis, and lactic acidosis.
– + +
Unopposed metabolic acidosis results in a decreased serum [HCO ] and an increase in serum [H ]. The increased [H ] stimulates the respiratory

+ center, resulting in increased minute ventilation. The physiologically based “respiratory compensation” is an attempt to lower the [H ] by a reduction in PCO through increased ventilation.

–
With normal respiratory compensation, PCO decreases by  mm Hg for every  mEq/L net decrease in [HCO ]. Using these relationships allows

– the clinician to calculate the expected PCO from the measured [HCO ], assuming respiratory compensation is normal. If the expected PCO value
   differs from the measured value in steady­state metabolic acidosis, then respiratory compensation is compromised, and a primary respiratory disorder exists in conjunction with the metabolic acidosis.
There are limits to the adequacy of respiratory compensation for metabolic acidosis. Respiratory minute volume actually declines when pH decreases below .10. It is particularly important to appreciate any contribution to the acidosis from an inadequate respiratory response. Administration of
– –
HCO in the presence of hypoventilation may exacerbate the respiratory acidosis, because the HCO converts to CO and water (H O).

The development of metabolic acidosis that drives the pH below .10 is likely associated with a very high risk of inadequate ventilation response, since there is a limit to respiratory compensation. The lowest PCO level achievable is approximately  mm Hg. This lower limit in obtainable PCO is due to
  resistance in airflow and increased CO generated by the exertion required for rapid ventilation, both offsetting the ventilator exhalation of CO . The
  superimposition of respiratory acidosis on a patient in such a condition will result in a rapid decline of pH to levels at which organ function drops and pharmacotherapy will fail. Noninvasive or mechanical ventilation usually should be instituted in such situations to ensure the ventilatory rate and volume are sufficient to prevent an increase in PCO at this critical time.

Symptoms of metabolic acidosis can result from acidosis itself or the underlying disease itself. Patients may complain of abdominal pain, headache, nausea with or without vomiting, and generalized weakness, and because acidosis stimulates the respiratory center, the patient may complain of dyspnea. Acute metabolic acidosis depresses cardiovascular function, can facilitate cardiac dysrhythmias, stimulates inflammation, and suppresses
 the immune response.
CAUSES OF METABOLIC ACIDOSIS
The causes of elevated AG metabolic acidosis are listed in Table 15­1. A comparison with the patient’s steady­state AG should be made whenever possible. Measurement and detection of specific anions may be indicated.
Differential Diagnosis of Wide AG Acidosis
The differential diagnoses to be considered in emergency practice fall into four broad categories: renal failure (uremia), ketoacidosis (diabetic ketoacidosis, alcoholic ketoacidosis, starvation ketoacidosis), lactic acidosis, and ingestions (methanol, ethylene glycol, salicylates, and many others).
Renal failure should be evident from the serum chemistries. Acidosis seen in initial stages of renal failure may be severe but tends to be stable, with
–
[HCO ] approximately  mEq/L in cases of chronic renal failure.

Positive serum ketones point to one of the ketoacidoses. In instances of known insulin­dependent diabetes mellitus, diabetic ketoacidosis is likely, although there is usually a component of lactic acidosis. In alcoholics who have recently stopped heavy drinking, alcoholic ketoacidosis should be considered; ketoacids contribute far less to the acidosis in ketoacidosis than lactate. Starvation ketosis will be found in patients with recent oral intake that is inadequate, such as in cases of fasting, dieting, or protracted vomiting, although the magnitude of acid­base disturbance in starvation ketosis should be small. The major ketone present in the serum of a patient with untreated diabetic or alcoholic ketoacidosis may be β­hydroxybutyrate. See
Chapter 223, “Type  Diabetes Mellitus,” for a detailed discussion.
Lactic acidosis occurs whenever lactate production exceeds lactate metabolism and is classified into two types. The first, in which tissue hypoxia is present and lactate production is elevated, is referred to as type A. Normal tissue oxygenation and impairment of lactate metabolism define the second, called type B. Severe acidosis that is resistant to treatment is seen in various type B lactic acidoses and ingestions. Lactic acidosis is not a diagnosis, but a syndrome with its own differential diagnosis. Causes of lactic acidosis are listed in Table 15­1. Lactate levels should be measured and accounted for in an adjustment of the AG. Ethanol is frequently cited as a cause of wide AG acidosis, but ethanol should never be considered the cause of any significant metabolic acidosis; look for other causes. Although ethyl alcohol metabolism may lead indirectly to very mild lactic acidosis, usually due to the same mechanism as alcoholic ketoacidosis, in which lactic acidosis is more substantial, neither the alcohol nor its metabolites directly contribute to the acidosis.
– –
The relation of [HCO ] to the AG and the [HCO ] to the expected Pco compensation must be examined in every patient with wide

AG acidosis to determine whether other acid­base disturbances, metabolic or respiratory, exist. For example, the triple acid­base disturbance of wide AG metabolic acidosis, metabolic alkalosis, and respiratory alkalosis is seen with sepsis (lactic acidosis) and salicylate poisoning.
Osmolal Gap
Determination of the osmolal gap will help identify methanol and ethylene glycol from other etiologies. The interpretation of serum osmolality
 + requires the measured (laboratory measurement) and calculated osmolality. The common formula is (2 × [NA ]) + [glucose] + [urea], but recently, a
+ study of several methods determined that the most accurate equation to identify true osmolal gap is as follows: (2 × [NA ]) + (1.4 × [glucose]) + (1.2 ×

[urea]) + (1.2 × [ETOH]). Increased osmolal gap can also be associated with an increased AG acidosis in the setting of acute kidney injury, lactic
 acidosis, and diabetic or alcoholic ketoacidosis.
Differential Diagnosis of Unchanged (Normal) AG Acidosis

The non­AG type of acidosis is often referred to as “normal” AG acidosis. Some texts refer to this as hyperchloremic metabolic acidosis, but not all cases of normal AG acidosis are associated with hyperchloremia. If the patient has hyponatremia with a normal AG acidosis, the chloride may be in the normal range. Abnormal chloride levels alone usually signify a more serious underlying metabolic disorder, such as metabolic acidosis (elevated
 chloride) or metabolic alkalosis (low chloride).
The causes of hyperkalemic and hypokalemic normal AG metabolic acidosis are listed in Table 15­2. TABLE 15­2
Causes of Normal Anion Gap Metabolic Acidosis
With a Tendency to Hyperkalemia With a Tendency to Hypokalemia
Subsiding diabetic ketoacidosis Renal tubular acidosis, type I (classical distal acidosis)
Early uremic acidosis Renal tubular acidosis, type II (proximal acidosis)
Early obstructive uropathy Acetazolamide; carbonic anhydrase inhibitor, causing functional renal tubular acidosis
Renal tubular acidosis, type IV Acute diarrhea with losses of HCO – and K+

Hypoaldosteronism (Addison’s disease) Ureterosigmoidostomy with increased resorption of [H+] and [Cl–] and losses of HCO – and

K+
Infusion or ingestion of HCl, NH Cl, lysine­HCl, or arginine­ Obstruction of artificial ileal bladder

HCl
Potassium­sparing diuretics Fluid resuscitation with unbalanced, high chloride content crystalloids (dilution acidosis)
+ +
One should be wary of traditional classification based on [K ], because serum [K ] itself is dependent on the actual pH. Thus, in severe acidosis, a
+ + normal range [K ] value may not represent true potassium levels. As acidosis is corrected and acidemia resolves, the [K ] will concordantly fall.
Because all diuretics may cause a contraction alkalosis, the metabolic acidosis that occurs simultaneously with potassium­sparing diuretics may not be evident, as the two may simply cancel each other out. Because the AG is unchanged, there is no indication that two distinct opposing processes may be occurring. As with wide AG–type acidosis, the expected PCO compensation must be examined in every patient with normal AG acidosis to determine
 whether other respiratory acid­base disturbances exist.
Acidosis with Large­Volume Normal Saline Resuscitation
It has been known for some time that large­volume fluid resuscitation with normal saline is associated with hyperchloremic acidosis (formerly called dilution acidosis). Two large, single­center, randomized controlled trials compared normal saline to balanced salt solutions (lactated Ringer’s or
Plasma­Lyte®) in the resuscitation of patients in the ED prior to admission and found fewer major adverse events (persistent renal dysfunction, new
,16 renal replacement therapy, or mortality) in the balanced salt group. Since then, a meta­analysis including those two studies plus four prior randomized controlled trials, totaling ,332 patients, found no significant differences in the outcome measures of intensive care unit mortality, acute
 kidney injury, and new renal replacement therapy when comparing .9 normal saline to balanced salt solutions. Most consistent in all the cited trials is the frequent development of hyperchloremic metabolic acidosis associated with large­volume resuscitation using normal saline.
TREATMENT
The treatment of acidosis reflects the treatment of the underlying disorder and the restoration of normal tissue perfusion and oxygenation. The most important step is to determine whether there is a respiratory component to the acidosis (i.e., a primary respiratory acidosis), because the treatment approach differs. If there is inadequate respiratory compensation, the most appropriate treatment will be to first correct the respiratory problem.
Address electrolyte disturbances, administer antidotes for toxins as appropriate, and initiate treatment for underlying causes such as sepsis (see
Chapter 151, “Sepsis”) or diabetic ketoacidosis (see Chapter 225, “Diabetic Ketoacidosis”).
Bicarbonate Therapy in Acidosis
Bicarbonate therapy results in the generation of significant quantities of CO , which diffuses readily into cells, in particular those of the CNS, which may

 cause paradoxical worsening of intracellular acidosis. An abrupt CO increase may exceed the ventilatory capacity of a patient already at maximum
 minute ventilation, thereby producing abrupt and worsening respiratory acidosis. After successful treatment with bicarbonate, “overshoot” alkalosis
 may result. Bicarbonate therapy imposes an osmotic and sodium load (1000 mEq/L of typical  N solution).
,19­25
Bicarbonate therapy may be appropriate for limited indications (Table 15­3).
TABLE 15­3
Potential Indications for Bicarbonate Therapy in Metabolic Acidosis
Indication Rationale
Severe hypobicarbonatemia (<4 mEq/L) Insufficient buffer concentrations may lead to extreme increases in acidemia with small increases in acidosis.
Severe acidemia (pH <7.00 to .15)* in cases of wide anion gap acidosis, with signs of shock or myocardial Therapy for the underlying cause of irritability that has not responded to supportive measures including adequate ventilation and fluid acidosis depends on adequate organ resuscitation as indicated by the patient’s clinical characteristics perfusion.
Severe hyperchloremic acidemia† Lost bicarbonate must be regenerated by kidneys and liver, which may require days.
*Presented as a range because recommendations differ among authors; data do not support a specific threshold for treatment.
†No specific threshold indication by pH exists. The presence of serious hemodynamic insufficiency despite supportive care should guide the use of bicarbonate therapy for this indication.
– – 
When given, HCO can be dosed at .5 mEq/kg for each milliequivalent per liter rise in [HCO ] desired. The goal is to restore adequate buffer

– capacity ([HCO ] >8 mEq/L) or to achieve clinical improvement in shock or dysrhythmias. Bicarbonate should be given as slowly as the clinical situation
 permits. Seventy­five milliliters of .4% sodium bicarbonate in 500 mL of dextrose 5% in water produces a nearly isotonic solution for infusion.
Adequate time should be allowed for the desired effect to be achieved, with monitoring of acid­base balance.
METABOLIC ALKALOSIS
Metabolic alkalosis is typically classified as chloride sensitive or chloride insensitive, thus indicating the treatment approach. Metabolic alkalosis results from gain of bicarbonate or loss of acid. The physiologic effects of alkalemia are substantial. Neurologic abnormalities, especially tetany,
+ neuromuscular instability, and seizures, are common. Reduction in [H ] results in reductions in ionized calcium, potassium, magnesium, and
+ phosphate levels. Serum proteins, largely polyanionic, buffer H ; with rapid acid loss, such as that which occurs in respiratory alkalosis, the newly
 available buffer capacity of those proteins binds calcium and other cations instead. Alkalemia may be of particular concern in patients with chronic obstructive pulmonary disease, because of the shift of the oxygen–hemoglobin dissociation curve to the left, which makes O less available to the
 tissues. Alkalemia depresses respiration, a serious effect in patients with compromised ventilation. Many patients with chronic obstructive pulmonary disease also take diuretics, leading to a contraction alkalosis.
Bicarbonate and chloride homeostasis is closely intertwined. Conditions that result in chloride loss, such as vomiting (which also causes acid loss), diarrhea, diuretic therapy, and chloride­wasting diseases (e.g., cystic fibrosis and chloride­wasting enteropathy), tend to reduce serum chloride concentration and extracellular volume. The reduction in extracellular volume increases mineralocorticoid activity, which enhances sodium reabsorption and potassium and hydrogen ion secretion in the distal tubule, which in turn enhance bicarbonate generation. The resulting increase in
– serum [HCO ] eventually exceeds the tubule’s maximum ability to reabsorb filtered bicarbonate. The resulting urine is alkaline, and because its
 anionic content is mostly bicarbonate, it is largely free of chloride (<10 mEq/L). (Nevertheless, the urine chloride may be normal when diuretics are administered.) The result is hypokalemic, hypochloremic alkalosis that responds to normal saline (chloride­responsive alkalosis).
Other diseases that cause metabolic alkalosis are usually associated with normovolemia or hypervolemia and often include hypertension. These diseases usually cause excess mineralocorticoid activity, resulting in the same pathophysiologic cascade described earlier. However, the excess mineralocorticoid activity is not associated with hypovolemia, so the urine chloride is generally normal or elevated (>10 mEq/L) and the alkalosis cannot be reversed with normal saline. Conditions producing “chloride­unresponsive alkalosis” and hypertension include renal artery stenosis, reninsecreting tumors, adrenal hyperplasia, hyperaldosteronism, Cushing’s syndrome, and exogenous mineralocorticoids (e.g., licorice, fludrocortisone).
+
The compensation for metabolic alkalosis involves reduction in alveolar ventilation, but the exact relationship between PCO and [H ] is not well
 established. Most studies to date have been conducted in dialysis patients or patients with conditions that predispose to alveolar hyperventilation
(e.g., sepsis, pneumonia). As a guideline, Pco in patients with significant metabolic alkalosis should rise by .7 mm Hg for each

– milliequivalent increase in [HCO ]. The Pco also rarely rises above  mm Hg in compensation for metabolic alkalosis.

TREATMENT
In the emergency setting, metabolic alkalosis rarely requires active management. Treat the underlying cause. Hydrate, and replace volume with sodium
 chloride and potassium. Aggressive therapy, such as IV hydrochloric acid, requires intensive care unit admission and monitoring.
RESPIRATORY ACIDOSIS
Respiratory acidosis is defined by alveolar hypoventilation and is diagnosed when the PCO is greater than the expected value. Regardless of underlying
 cause, the final common path is inadequate ventilation.
Inadequate minute ventilation most frequently results from head trauma, chest trauma, lung disease, or excess sedation. The chronic hypoventilation seen in extremely obese patients is often referred to as the Pickwickian syndrome or obesity hypoventilation syndrome. Patients with severe chronic obstructive pulmonary disease have increased dead space and frequently also have decreased minute ventilation.
In general, a rise in the PCO stimulates the respiratory center to increase respiratory rate and minute ventilation. However, if the arterial PCO
  chronically exceeds  to  mm Hg, as may occur in 5% to 10% of patients with severe emphysema, respiratory acidosis may depress the respiratory center. Under such circumstances, the stimulus for ventilation is provided primarily by hypoxemia acting on chemoreceptors in the carotid and aortic bodies. Giving oxygen could remove the main stimulus to breathe, causing the PCO to rise abruptly to extremely dangerous levels. Consequently, when
 administering oxygen to patients with chronic obstructive pulmonary disease, carefully monitor for apnea or hypoventilation; however, do not withhold oxygen in the case of severe hypoxemia. Evaluation of ventilation requires attention to several important clinical issues. First, the ventilation that would be expected based on assessment of the respiratory rate and depth should be compared with the actual ventilation of the patient (i.e.,
PCO ). A “normal” PCO of  mm Hg in a tachypneic, dyspneic patient likely reflects significant ventilatory insufficiency. Second, the impact of
  respiratory acidosis on partial pressure of oxygen in the alveoli (PaO ) in such a patient may be considerable. The alveolar gas equation suggests that if
 inspired oxygen concentration and respiratory quotient do not change, increases in PCO will result in reductions in PaO .

+
Each 1­mm Hg increase in PCO results in a 1­mmol increase in [H ]. Across the linear portion of the pH–hydrogen ion concentration relationship, each

1­mm Hg increase in PCO should theoretically produce a decrease in pH of .01. The actual relationship between changes in PCO (up to values of 

+ mm Hg) and changes in [H ] determined in normal humans is about  to . Thus, a 10­mm Hg increment in Pco produces an 8­mmol increase

+ + in [H ], with little change in bicarbonate concentration (usually  mEq/L) or urinary acid excretion. If the [H ] is higher or lower than that suggested by the change in the PCO , a mixed disorder is present.

The adaptation to chronic respiratory acidosis is complex. Over time, chronic elevation of PCO reduces carotid sinus sensitivity to hypercapnia, and

– ventilatory drive is then controlled by PaO . The acidosis results in significant increases in renal HCO generation and avid reclamation of filtered

–
HCO .

It is frequently uncertain whether a patient has an acute respiratory acidosis, a chronic respiratory acidosis, or a mixed disorder. Evaluation of the acid­
+ base status in such circumstances does not require “baseline” arterial blood gas values. Instead, the change in [H ] is compared with the change in
PCO . If this ratio is .3, the patient has a chronic respiratory acidosis; if it is .8, the patient has an acute respiratory acidosis. Other ratios suggest a
 mixed acid­base disturbance, as shown in Table 15­4. TABLE 15­4
Evaluation of Acid­Base Status in Respiratory Acidosis
*Ratio = Δ[H+]/ΔPCO2
Ratio < .3 Ratio = .3 .3 < Ratio < .8 Ratio = .8 Ratio > .8
Change in hydrogen ion Change in hydrogen Change in hydrogen ion concentration is Change in hydrogen Change in hydrogen ion concentration is less than ion concentration larger than accounted for by chronic ion concentration concentration is larger than accounted for by chronic matches chronic change in PCO2 . Chronic respiratory matches acute accounted for by acute or change in PCO2 . Metabolic change in PCO2 .
acidosis plus either acute respiratory change in PCO2 . chronic change in PCO2 .
alkalosis is also present. Chronic respiratory acidosis or metabolic acidosis is present; Acute respiratory Metabolic acidosis is also acidosis is present. examine pH. acidosis is present. present.
Abbreviation: PCO2 = partial pressure of carbon dioxide.
*See method of calculation in the Box, “Clinical Approach to Acid­Base Disorders,” in this chapter.
TREATMENT
Treatment of respiratory acidosis is the improvement of alveolar ventilation. In general, if the minute ventilation is doubled, the PCO will be reduced by

50%. Treat chronic obstructive pulmonary disease, and provide noninvasive ventilatory support or tracheal intubation as needed. See Chapter 29B,
“Mechanical Ventilation,” for further discussion.
In patients with chronic respiratory acidosis, the arterial PCO should not be reduced by more than .0 mm Hg/h. Rapid correction of a chronic
 respiratory acidosis can cause sudden development of a severe metabolic alkalosis, with resulting dysrhythmias. A rapid rise in pH can cause an abrupt decrease in ionized calcium levels and hypokalemia.
RESPIRATORY ALKALOSIS
Respiratory alkalosis is alveolar hyperventilation and exists when PCO is less than expected. It is caused by conditions that stimulate respiratory
 centers, including CNS tumors or stroke, infections, pregnancy, hypoxia, and toxins (e.g., salicylates). Anxiety, pain, and iatrogenic overventilation of patients on mechanical ventilators also cause respiratory alkalosis.
+
The clinical symptoms of acute respiratory alkalosis are predictable from its physiologic effects. Acute reduction in PCO produces a reduction in [H ],
 resulting in an increase in negative charge on anionic buffers. The now negatively charged proteins instead bind calcium, and if the effect is sufficiently
 large, the reduction in ionized calcium produces tetany (e.g., carpopedal spasm) and paresthesias. Hypocapnia also produces substantial reductions in cerebral blood flow and results in reduced tissue oxygen delivery due to a leftward shift in the oxygen–hemoglobin dissociation curve (i.e., increased hemoglobin­oxygen binding).
+ +
The predicted relationship of [H ] and PCO is that a 1­mmol decrease in [H ] results from each 1­mm Hg reduction in PCO .

Chronic respiratory alkalosis is unique among the acid­base disorders in that its compensation may be complete. Compensatory events include bicarbonaturia and a reduction in acid excretion, requiring  to  hours to develop fully and at least  week to normalize pH. The steady­state
+ relationship between [H ] and PCO in chronic respiratory alkalosis observed in normal human subjects at high altitude is roughly half that expected at

+ sea level. Each 1­mm Hg reduction in PCO results in a .4­mmol reduction in [H ].

TREATMENT
Treat the underlying cause. For patients with anxiety and hyperventilation, do not use “paper­bag” rebreathing because it may lead to hypoxia. Chronic respiratory alkalosis is seen at high altitudes, in particular among mountaineers climbing over 3700 m (12,000 ft), where the partial pressure of oxygen is significantly diminished. Acetazolamide is frequently prescribed to counter the physiologic respiratory effects of such ascents.


