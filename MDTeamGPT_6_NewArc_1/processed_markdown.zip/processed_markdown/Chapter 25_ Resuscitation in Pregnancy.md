University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 25: Resuscitation in Pregnancy
Boyd D. Burns; Emily C.S. Fisher
INTRODUCTION AND EPIDEMIOLOGY
Cardiac arrest in pregnancy is rare, and resuscitation of a pregnant woman is typically an unexpected and chaotic event, which ideally involves multiple consultants from different specialties with different levels and types of skills. Emergency care and lifesaving procedures for resuscitation and cardiac arrest should not be delayed if specialists are not available. Contact the closest center providing neonatal and maternal services as soon as possible to facilitate rapid transport and continued care of the newly delivered infant and the mother.
The World Health Organization defines maternal deaths as deaths while pregnant or within  days of the end of pregnancy, related to or aggravated
 by pregnancy or pregnancy management, regardless of the duration or site of the pregnancy and irrespective of the cause of death. Factors associated with pregnancy­related deaths in the United States include advanced maternal age, African­American race, increasing live birth order, and
 lack of prenatal care.

Recent U.S. data demonstrate that cardiac arrest, in the inpatient setting, occurs in 1:12,000 admissions. The trend in maternal mortality in the United
States, according to the Centers for Disease Control and Prevention, has seen a steady increase from .2 deaths per 100,000 live births in 1987 to .8
 deaths per 100,000 live births in 2009. Management of emergencies during labor and delivery is discussed in Chapter 101, “Emergency Delivery.”
PHYSIOLOGY OF PREGNANCY
Beginning early in pregnancy, virtually all major organ systems undergo changes (Table 25­1) that affect patient management.
TABLE 25­1
Physiologic Changes in Pregnancy Affecting Resuscitation
System Parameters Comment
Cardiovascular Cardiac output Increases 30%–50%
Peripheral resistance Decreases 20%
Blood pressure Decreases 10–15 mm Hg systolic in first half of pregnancy; then back to baseline
Blood volume 100 mL/kg or 6–7 L
Central venous pressure May be increased up to  mm Hg
Central venous oxygen saturation Increases as high as 80%5
Plasma volume Increases 30%–50%

Hematologic Fibrinogen, factors V, VII, VIII, X, von Willebrand factor Increase, with heightened risk for venous thromboembolism in
Chapter 25: Resuscitation in Pregnancy, Boyd D. Burns; Emily C.S. Fisher 
. Terms of Use * Privacy Policy * Notices e * c Aoncdc ehsalsf iobfi lpitryegnancy
Respiratory Upper airway edema, hyperemia, and friability Estrogen and volume effects; can result in difficult airway and pulmonary Diaphragm elevation Higher thoracostomy tube insertion site during pregnancy
Hemoglobin F has greater affinity for oxygen than maternal Fetal oxygen maintained at expense of maternal oxygenation; hemoglobin maintain maternal oxygen saturation >95%
Respiratory rate No change
Tidal volume, minute ventilation Increase
Renal and Progesterone dilates renal collecting system; ureteral Renal US may show mild hydronephrosis; increased risk for urinary peristalsis decreases ascending infection
GI Alkaline phosphatase rises from placental production; bile is Increased risk of cholecystitis/cholelithiasis more lithogenic
Decreased lower esophageal tone; decreased gastric emptying Increased likelihood of aspiration of gastric contents
Uteroplacental 25% of blood flow directed to uteroplacental unit; no Place patient in left lateral tilt position during third trimester; replace unit autoregulation of blood flow; enlarging uterus can compress volume adequately to account for increased blood and plasma vena cava and vessels below the diaphragm; supine volume in pregnancy; avoid femoral and lower extremity site for hypotension syndrome can occur after  min of supine blood and volume delivery in second half of pregnancy position
CARDIOVASCULAR CHANGES
Uterine blood flow is not autoregulated but is directly proportional to the maternal mean arterial pressure and inversely proportional to the resistance of the uterine vasculature. Conditions that decrease uterine blood flow during pregnancy include maternal hypovolemia, hypotension, uterine vasoconstriction, tetanic uterine contractions, and aortocaval compression.
As the uterus enlarges throughout pregnancy, compression of the pelvic and abdominal vasculature can occur, especially when the patient is supine.

Compression of the inferior vena cava can decrease maternal venous return and reduce cardiac output from 10% to 30% (Figure 25­1). This can contribute to supine hypotension syndrome, which is a constellation of findings including hypotension, tachycardia, dizziness, pallor, and nausea. It is
 reported to occur after  minutes in the supine position. Therefore, place any patient in the third trimester of pregnancy in the full left lateral tilt
 position when in hemodynamic distress or exhibiting hypotension. Left lateral tilt can be achieved by placing a roll under the patient’s right hip, inserting a Cardiff wedge, or placing the patient in full left lateral tilt while on a backboard (Figure 25­2). The Cardiff wedge provides a tilt of 
 degrees from the horizontal. Foam or hard wedges are better for maintaining the left lateral tilt position than are pillows or manual tilting. Because compression of the abdominal vasculature can compromise intravascular delivery of medications through sites below the diaphragm, avoid femoral or saphenous venous sites for IV access during the resuscitation of a pregnant woman at >20 weeks of gestation. The negative effects of great vessel compression on uteroplacental blood flow increase in the presence of maternal hypotension and uterine contractions.
FIGURE 25­1. Changes in maternal heart rate, stroke volume, and cardiac output during pregnancy (preg.), with the gravida in the supine and lateral positions. PP = postpartum. [Reproduced with permission from Barclay ML: Critical physiologic alterations in pregnancy, in Pearlman MD, Tintinalli JE (eds):
Emergency Care of the Woman. New York, The McGraw­Hill Companies, Inc., 1998, Chapter , Figure 2­3, p. . Copyright © 1998 by The McGraw­Hill
Companies, Inc. All rights reserved.]
FIGURE 25­2. Left lateral tilt position.
RESPIRATORY AND PULMONARY CHANGES
Respiratory changes occur early to help optimize fetal oxygenation. Progesterone drives an increase in resting minute ventilation and tidal volume. The respiratory rate, however, remains relatively unchanged, so do not dismiss tachypnea as a normal part of pregnancy. As pregnancy progresses,
 the diaphragm elevates approximately  cm with an increase of the transverse diameter of the thoracic cage by  cm. Changes in pulmonary physiology and increased metabolic oxygen consumption can result in the rapid development of hypoxia during respiratory illnesses or as a result of respiratory arrest.
Because the fetal oxyhemoglobin dissociation curve is shifted to the left relative to the maternal oxyhemoglobin dissociation curve, the bond of fetal hemoglobin to oxygen is stronger than maternal hemoglobin, which results in preservation and optimization of fetal oxygen delivery at any given partial pressure of oxygen. Strive to maintain maternal pulse oximetry readings >95% to maintain a partial pressure of oxygen in arterial blood of >70
 mm Hg to optimize maternal oxygenation and oxygen delivery to the placenta.

The fetus exists in a physiologically acidemic state relative to the mother, which allows preferential oxygen transfer at the fetal tissue level. Acidemia favors a rightward shift of the oxyhemoglobin dissociation curve, resulting in a greater amount of oxygen supplied to fetal tissues. Fetal cardiac output protects against brief periods of hypoxia, with increases in umbilical blood flow and placental gas exchange and preferential redistribution to vital tissues.
RESUSCITATION STEPS
The most common causes of pregnancy­related deaths in the United States are cardiovascular disease, cardiomyopathy, hemorrhage,
,11 infection/sepsis, hypertensive disorders of pregnancy, and thrombotic pulmonary embolism. Major trauma is the greatest risk for nonobstetric
 cause of death. Motor vehicle collisions account for almost half of trauma, followed by falls and assaults.
The best maternal care provides the best fetal care, so follow general principles of resuscitation when treating pregnant women. To accommodate the increase in blood and plasma volume that develops during pregnancy, make sure that the volume of resuscitative fluids increases by 50% above that required by the nonpregnant patient. Place two large­bore IVs above the level of the diaphragm, and provide rapid infusions of isotonic saline. Volume must be adequately replaced before considering vasopressors, especially in pregnancy, because the uterine arteries are maximally dilated and blood flow is pressure dependent.
The gravid uterus can cause aortocaval compression, leading to increased afterload and decreased cardiac return as early as  to  weeks of
 gestation. Place pregnant patients in the left lateral decubitus position to improve both ejection fraction and stroke volume whenever feasible from a resuscitation standpoint.
Select a vasopressor by the desired effects in the mother and the least harmful effects on the fetus (see Table 25­4). Vasopressors have variable effects on fetomaternal circulation, so if time allows, critical care or obstetrical consultation may be helpful before selecting vasopressors.
Studies of vasopressors in pregnancy are limited to either animal models or focus on the short­term use of pseudoephedrine or ephedrine for spinal anesthesia–induced hypotension during cesarean section. This makes available data difficult to extrapolate to other human hypotensive situations.
Phenylephrine (pregnancy category C) is an α ­selective agent without any β activity, so it raises blood pressure through vasoconstriction but can
 cause reflex bradycardia in some cases. It crosses the placenta, and effects on lactation are unclear. It appears to have a favorable fetal acid­base
,15 profile. Ephedrine (pregnancy category C) is a mixed α and β stimulator. It crosses the placenta and can induce fetal acidosis. Standard vasoactive agents such as norepinephrine, dopamine, and vasopressin are all pregnancy category C with limited data available on use in pregnancy. There is concern that use of these medications may decrease uterine blood flow as a result of vasoconstriction. However, the benefits of correcting maternal hemodynamic instability secondary to shock generally outweigh the risk to the fetus.
SEPSIS
Sepsis is a systemic inflammatory response to infection leading to acute organ dysfunction. Currently there are no sepsis guidelines specifically for pregnant women because this population has been excluded from early landmark sepsis studies. Pregnant women, when compared with nongravid women, are more likely to develop complications from serious infections. Maintain a high index of suspicion for sepsis in pregnant women because
 signs and symptoms of sepsis may not be as apparent when compared to the nonpregnant population. The clinical features of sepsis in pregnancy
 include fever or rigors, diarrhea or vomiting, rash, abdominal or pelvic pain, vaginal discharge, productive cough, or urinary symptoms.
The determination of the severity of sepsis in pregnancy can be challenging due to normal physiologic changes in pregnancy that mimic the changes in sepsis. These changes include a decrease in diastolic blood pressure during the second trimester, increase in heart rate, and increase in leukocyte
 count.
Septic shock in pregnancy is rare, occurring in a small number (0.002% to .01%) of deliveries and in only .3% to .6% of pregnant women (Table 25­

2). However, sepsis as a cause of mortality can vary between .7% in developed countries to .6% in developing countries. The most common causes of peripartum sepsis are pyelonephritis and pelvic infections such as chorioamnionitis. Less common causes include pneumonia and septic
,21  abortion. Malaria, human immunodeficiency virus, and tuberculosis are more common in developing countries.
TABLE 25­2
Some Causes of Maternal Sepsis
Pyelonephritis
Chorioamnionitis
Endometritis
Septic abortion
Pelvic abscess
Pneumonia
Influenza
Herpes
Varicella
Wound infection/abscess
Necrotizing cellulitis/fasciitis
Appendicitis
Cholecystitis
Pancreatitis
Malaria or HIV in developing countries
Prompt antibiotic therapy is key and should target suspected pathogens based on site of infection, likely causative organisms, and local resistance patterns. In general, β­lactams, aminoglycosides, and macrolides are preferred during pregnancy, if appropriate, due to their safety profile for the fetus.

Pyelonephritis is the most common cause of septic shock in pregnancy. Progesterone produces dilatation of the ureters, and mechanical compression of the urinary system by the enlarging uterus results in relative obstruction of the urinary tract. The most common causative agent is
Escherichia coli, with Klebsiella, Proteus, and Enterobacter responsible for most other cases. Consider renal US to assess for renal/ureteral stones and
 to assess for renal complications. Hospitalize pregnant women with pyelonephritis, because bacteremia is likely and the physiologic changes of
,26 pregnancy can rapidly cause hypoxia. Begin empiric antibiotics. Treatment needs to consider local resistance patterns. In general, for mild to moderate disease, standard regimens are amoxicillin/clavulanate, ampicillin plus gentamicin, ceftriaxone, or cefepime. For severe disease with immunocompromise, consider ticarcillin/clavulanate or piperacillin/tazobactam.
Pneumonia in pregnancy has a similar prevalence as in nonpregnant women, but can be particularly severe because a rapid decline in oxygen
,26 saturation can complicate the course whether or not sepsis is present. Follow standard community­acquired pneumonia protocols for pneumonia
 treatment (see Chapter , “Community­Acquired Pneumonia, Aspiration Pneumonia, and Noninfectious Pulmonary Infiltrates” for further discussion). All antibiotics cross the placenta. Select pregnancy risk category B agents for treatment.
Influenza infection in pregnancy carries higher morbidity and mortality than in nonpregnant patients due to an altered immune response to the virus
 involving increased proinflammatory cytokines. Pregnant patients with influenza have an increased risk for severe disease, resulting in higher rates of hospitalization, intensive care unit admission, and death compared with nonpregnant patients, in addition to an increased risk of miscarriage,
,30 preterm birth, and stillbirth. Lower disease severity is associated with women who receive influenza vaccination and those treated with antivirals
 within  days of symptom onset. Both vaccination and antivirals have been shown to be safe and efficacious in pregnancy.
AIRWAY IN PREGNANCY
ANATOMIC CHANGES AFFECTING INTUBATION
,33
Fluid retention causes edema within the structures of the upper airway, and weight gain with adipose deposition can contribute to landmark distortion. Anticipate difficulty with mask ventilation, laryngoscopy, glottic visualization, and endotracheal intubation. Desaturation occurs quickly as a result of maternal increased oxygen consumption and decreased functional residual capacity.
During pregnancy, the incidence of Mallampati class III airways increases (only the soft palate and base of the uvula are seen when the mouth is open and the tongue is protruding), making intubation more difficult (see Figure 29A­8 in Chapter 29A, “Tracheal Intubation”). Increased Mallampati
 scores correlate with gains in body weight, and because obesity in pregnancy is more common than in the nonpregnant state, this contributes to the
 likelihood of a difficult airway.
Mucosal engorgement and increased capillary friability make airway bleeding and swelling likely. Due to the engorgement and friability of the nasal mucosa, avoid blind nasotracheal intubation if possible. Pregnant women are likely to have full and intact dentition, and there may be little interdental distance in which to maneuver a laryngoscope. In addition, there are often redundant pharyngeal and palatal folds in the airways of obese gravid
,36 women. The rates of difficult intubation are reported to range from 1% to 6% and the incidence of failed intubation from .1% to .6%. Decreased lower esophageal tone, increased intra­abdominal pressure, decreased gastric emptying, and a full stomach increase the likelihood of gastric aspiration.
Supplemental oxygen via nasal cannula and facemasks often is insufficient for patients in severe respiratory distress and significant hypoxia. As in most cases, these patients will require positive pressure in addition to supplemental oxygen alone to optimize delivery and oxygenation. Oxygen
 delivered through a high­flow nasal cannula provides humidified, heated oxygen at flow rates up to  L/min, providing positive pressure and
,39 decreasing the work of breathing. High­flow nasal cannula helps in patients with hypoxemia and an intact respiratory drive, often as an alternative to intubation or noninvasive positive­pressure ventilation. It is best avoided in those not breathing or with bullous lung disease and
 pneumothoraces. Another option is flush rate oxygenation, where the wall oxygen unit is turned past  L/min to maximum flow rates of  to 
,42
L/min. The latter helps avoid desaturation during rapid­intubation techniques in addition to other respiratory distress events. Both high­flow nasal cannula and flush rate oxygenation are best seen as bridges to awaiting clinical improvement or other ventilation methods.
INTUBATION
The most experienced physician should undertake the intubation with adjunctive airway equipment, smaller­sized endotracheal tubes, a gum elastic bougie, short laryngoscope handles, and stylets readily available. A video laryngoscope system facilitates first­pass success and direct visualization
43­45 and decreases complications and prolonged hypoxia.
Preoxygenate to 95% oxygen saturation to prevent hypoxia during intubation. Provide supplemental oxygenation by nasal cannula set to deliver 

L/min during the procedure, even after paralysis, to continue oxygen delivery to the alveoli (passive apneic oxygenation).
Place the patient in the supine position; manually displace the uterus to the left. Elevate the head and shoulders with a pillow or folded sheets to achieve the sniffing position. This maneuver is particularly important in obese patients.
For rapid­sequence induction, use standard doses of induction agents and paralytics (see Chapter 29). The laryngeal mask airway was described as
  safe and effective in healthy selected patients undergoing elective cesarean section and has been used as a rescue device after failed intubation.
The determination of the initial ventilator settings should be the same as in the nonpregnant patient, with a Pco goal of  to  mm Hg. Avoid

 respiratory alkalosis because, in animal models, this decreases uteroplacental flow.
CARDIAC ARREST IN PREGNANCY
Pregnant women are typically younger than the traditional cardiac arrest patient but often have poor outcomes, with survival rates reported as low as
,11 ,51
.9%. The causes of cardiac arrest in pregnancy are listed in Table 25­3. TABLE 25­3
Pregnancy­Related Causes of Maternal Cardiopulmonary Arrest
Obstetric complications
Hemorrhage (17.2%)
Uterine atony
Placental abruption
Placenta previa, accreta, increta, or percreta
Disseminated intravascular coagulopathy
Severe pregnancy­induced hypertension (15.7%)
Amniotic fluid embolism
Idiopathic peripartum cardiomyopathy (8.3%)
Iatrogenic events
Failed intubation
Pulmonary aspiration
Intravascular local anesthetic overdose (1.6%)
Drug error, overdose, or allergy
Hypermagnesemia
Pulmonary embolism (19.6%)
Thrombus
Air
Fat
Stroke (5%)
Trauma
Homicide
Suicide
Motor vehicle accident
Infection or sepsis (12.6%)
Other (19.2%) (cardiovascular, pulmonary, and neurologic comorbidities)
Source: Reproduced with permission from Chang J, Elam­Evans LD, Berg CJ, et al: Pregnancy­related mortality surveillance—United States, 1991–1999. MMWR
Surveill Summ 52: , 2003. Cardiopulmonary arrest in pregnancy is broken down into two categories: before and after fetal viability. Typically, the onset of fetal viability varies between  and  weeks, with some institutional variation considering backup and available resources. By  weeks, the uterine fundus is palpable at the umbilicus; then from  to  weeks, the fundal height (in centimeters) approximates the gestational age (for singleton pregnancies). If the fundal height is at or below the umbilicus, resuscitative effort should focus on the mother with no modifications of CPR. If the uterus is palpable above the
,51 umbilicus, one person should provide manual left lateral displacement of the uterus while another is performing CPR.
DEFIBRILLATION AND VASOACTIVE MEDICATIONS
When left lateral decubitus positioning is not feasible due to ongoing CPR or intubation, maintain leftward uterine displacement with one team
 member manually and continuously displacing the gravid uterus toward the patient’s left. Chest compressions with the patient tilted to the side are
 less effective than those performed in the usual supine position (Figure 25­3).
FIGURE 25­3. Manual left uterine displacement by the one­handed technique from the right of the patient during adult resuscitation. [Reproduced with permission from Zelop CM, Einav S, Mhyre JM, et al: Cardiac arrest during pregnancy: ongoing clinical conundrum, Am J Obstet Gynecol. 2018 Jan . pii: S0002­
9378(17)32806­5. Copyright Elsevier.]
Treat pregnant women in cardiac arrest according to current Advanced Cardiac Life Support guidelines (Table 25­4). Perform defibrillation at recommended adult doses. Despite an increase in plasma volume and glomerular filtration rate, there is no evidence that the standard doses of
Advanced Cardiovascular Life Support medications should be altered. Place IV sites above the diaphragm secondary to aortocaval compression.

Vasopressin is no longer part of the 2015 Advanced Cardiac Life Support algorithms, and vasopressin can lead to uterine contractions. Amiodarone can be given at its usual doses as appropriate for management of refractory ventricular fibrillation or tachycardia. Defibrillate with the usual settings and paddle positioning. Pregnant patients have limited oxygen reserve, so provide airway management early in the resuscitation to rule out maternal
 hypoxia as a source of the patient’s deterioration. Perform perimortem cesarean section early in the management of any arresting patient with a uterus at or above the level of the umbilicus to improve both maternal and fetal outcomes.
TABLE 25­4
Medications Used During Resuscitation: Considerations in Pregnancy
Drug Indications Pregnancy Risk Category
Epinephrine Potentially beneficial in all forms of cardiac Category C. Teratogenic in animals in large doses; may induce uteroplacental arrest vasoconstriction and fetal anoxia.
Lidocaine Ventricular ectopy, tachycardia, and Category B. Use during pregnancy is not well studied; crosses the placenta, but in fibrillation therapeutic doses has no teratogenic effect on the fetus; may cause fetal bradycardia.
Atropine Symptomatic bradycardia Category C. Crosses placenta but results in no fetal abnormalities; can cause fetal tachycardia.
Sodium Cardiac arrest unresponsive to other Category C. No studies of risk. Use for hyperkalemia and selected toxic overdoses.
bicarbonate measures; documented preexisting metabolic acidosis
Calcium Cardiac arrest due to hyperkalemia, or as chloride or antidote to magnesium toxicity (a potential gluconate complication when giving high doses of magnesium for eclampsia)
Dopamine Hemodynamically significant hypotension in Category C. No teratogenic effects in animals, but sufficient studies in humans are the absence of hypovolemia lacking; use only when clearly indicated.
Dobutamine Short­term inotropic support of patients Category B. Not teratogenic in animal studies.
with depressed myocardial contractility
Norepinephrine Vasopressor for septic shock after adequate Category C. No animal reproductive studies done. Crosses the placenta.
volume replacement
Amiodarone Ventricular fibrillation, tachycardia, and Category D. Is part of Advanced Cardiac Life Support algorithm in pregnancy; use if supraventricular tachycardia benefit outweighs risk; serious fetal adverse effects of congenital goiter and hypothyroidism.
Adenosine Supraventricular tachycardia Class C. Multiple case reports of the safe use of adenosine to treat maternal and fetal supraventricular tachycardia.
Magnesium Torsades de pointes; prevention or Class D. Crosses the placenta, and levels in fetus are similar to the mother. Neonatal sulfate treatment of seizures in severe preeclampsia neurologic depression may occur with respiratory depression, muscle weakness, and or eclampsia loss of reflexes. Continuous maternal use for >5 days may cause fetal hypocalcemia or bone abnormalities.
Ephedrine Hypotension related to spinal anesthesia or Class C. Multiple reports of use during anesthesia­related hypotension in pregnancy.
unresponsive to fluids Maintains uterine blood flow. May cause dose­dependent increase in fetal acidosis, tachycardia, and abnormal variability in fetal heart rate (indicative of fetal stress), or an increase in metabolic activity.
Phenylephrine Hypotension related to spinal anesthesia or Class C. Superior to ephedrine for management of hypotension after spinal anesthesia unresponsive to fluids with a decrease in fetal acidosis.14
Vasopressin No longer recommended for cardiac arrest Class C. There are no controlled data in human pregnancy.
POST–CARDIAC ARREST HYPOTHERMIA AND EXTRACORPOREAL MEMBRANE OXYGENATION
Case reports describe successful use of post–cardiac arrest hypothermia during pregnancy. The 2010 American Heart Association guidelines, Cardiac
Arrest in Special Situations, recommend hypothermia in early pregnancy without emergency cesarean section (with fetal heart monitoring).
55­57
Hypothermia should be considered on a case­by­case basis based on the current recommendations for the nonpregnant patient. As the use of extracorporeal membrane oxygenation continues to increase, this modality may be considered in the appropriate facility setting (dedicated
 extracorporeal membrane oxygenation center).


