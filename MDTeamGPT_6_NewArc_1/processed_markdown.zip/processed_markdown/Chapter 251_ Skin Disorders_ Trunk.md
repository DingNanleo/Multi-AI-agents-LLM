## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 251: Skin Disorders: Trunk
Katharine Kenyon; Dean S. Morrell; Diana B. McShane
INTRODUCTION
There are many conditions that can have truncal involvement. This section focuses on some common eruptions that frequently affect the trunk: papulosquamous disorders; urticarial and morbilliform disorders; blistering disorders; and miscellaneous disorders. Urticaria and angioedema are discussed in Chapter , “Allergy and Anaphylaxis.” Although the truncal location of an eruption can be a helpful clue for diagnosis, the clinical appearance of the lesions and overall assessment of the patient are needed to make the correct diagnosis.
PAPULOSQUAMOUS DISORDERS
Scaling conditions include psoriasis, seborrheic dermatitis, tinea corporis, pityriasis (“tinea”) versicolor, eczema/atopic dermatitis, lichen planus, secondary syphilis, and scabies. Table 251­1 lists common features distinguishing these eruptions, and Table 251­2 summarizes common treatments.
TABLE 251­1
Comparison Features of Common Papulosquamous Eruptions
Condition Distinguishing Clinical Features Location Special Signs Comments
Psoriasis Erythematous, well­marginated papules Trunk, extensor surfaces, Auspitz sign, Koebner Hereditary predilection; onset and plaques with silvery scale scalp phenomenon, nail pitting in early 20s
Seborrheic Greasy, yellow scales Mid chest, suprapubic, Can overlap with psoriasis, Debilitated, elderly, or infants dermatitis scalp, facial creases “sebopsoriasis” (cradle cap)
Pityriasis Oval scaly macules with collarettes of Trunk, in Christmas tree Herald patch 1–2 wk before Spring and fall, age 15–40 y old; rosea scale following skin tension lines pattern general eruption viral exanthem, herpes  and 
Tinea Sharply demarcated, erythematous, scaly Trunk, legs, arm, neck May need KOH/culture to All ages; from pets, soil, or corporis annular plaques; may coalesce into gyrate diagnose; septate autoinoculation from patterns branching hyphae on KOH hands/feet; incubation days or months
Pityriasis Versicolored—red, salmon, light brown, Central upper chest and “Spaghetti and meatballs” Young adults, summer, hot
(tinea) dark brown, hypopigmented; well­ back on KOH; nonseptate humid environments versicolor demarcated scaly patches pseudohyphae and yeast cells
Atopic Erythematous scaly macules/patches; Flexures > trunk Spares the nose Pruritic “itch that rashes”; dermatitis chronic with lichenification atopic individuals
Contact Ill­defined vesicles forming plaques with Varies based on site of Burning > itching in irritant Common allergens: nickel, dermatitis scale; chronic lesions lichenified exposure; dorsal hands, contact (vs. allergic poison ivy, fragrances

Chapter 251: Skin Disorders: Trunk, Katharine Kenyon; Deafnac Se .c oMmomrroenlll;y D afifaencate dB. McSchoanntaect) Common irritants: soap, wPaetge  / 
. Terms of Use * Privacy Policy * Notice * Accessibility work/frequent hand washing, production work materials
Lichen  Ps: purple, pruritic, polygonal, planar Any skin, mucous Wickham striae, Koebner Age 20–60 y old planus papules membranes, hair follicles phenomenon
Secondary At 2–10 wk, macular erythema on trunk, Palms, soles, trunk Serology Great masquerader—can take syphilis abdomen, inner extremities; followed by any form; can be confused with papular or papulosquamous lesions pityriasis rosea
Scabies Pruritic papules and burrows with crusting Finger webs, wrists, axillae, Scrapings show mites, Can be chronic “7­year itch”; areolae, umbilicus, feces, eggs intensely pruritic, especially at abdomen, waistband, night genitals
Abbreviation: KOH = potassium hydroxide.
TABLE 251­2
Treatment of Common Papulosquamous Disorders
Condition Method Agent(s) Dosage Comments
Psoriasis Topical Clobetasol .05% cream or Twice a day Use clobetasol for thick plaques and triamcinolone ointment for thinner plaques.
Triamcinolone .1% cream or Avoid systemic steroids!
ointment
Seborrheic Topical Scalp and body: Scalp and body: May need to use low­potency topical steroid for dermatitis Ketoconazole 2% shampoo Apply to scalp twice a week. chest involvement until improved.
OTC selenium sulfide shampoo Let sit 3–5 min before rinsing.
(Selsun Blue®) or zinc Face: pyrithione shampoo (Head & Twice a day until improved
Shoulders®)
Face:
Ketoconazole 2% cream
Hydrocortisone .5% cream
Pityriasis Topical Triamcinolone .1% cream Twice a day rosea Hydrocortisone .5% cream
Oral Antihistamines
Tinea Topical Terbinafine cream (Lamisil®) Twice a day, extend ≥3 cm corporis (OTC) beyond edges; treat ≥4 wk and
Butenafine cream (Lotrimin until  wk after clearing
Ultra®) (OTC)
Ciclopirox cream (Rx)
Oral Terbinafine 250 milligrams PO daily for  Oral:
Fluconazole wk Check detailed references for adverse effects,
200 milligrams PO weekly for  contraindications, drug interactions, and pediatric wk dosing.
Therapy duration for tinea capitis and tinea unguium/onychomycosis differs from treatment duration for tinea corporis.
Pityriasis Topical Ketoconazole 2% shampoo Apply and let sit 3–5 min as a Treatment is successful with cessation of scaling.
(tinea) Ketoconazole 2% cream body wash daily for  d Pigment alterations may take several months to versicolor Miconazole 2% cream Twice a day for 2–4 wk resolve.
Econazole 1% cream
Oral Fluconazole 200 milligrams weekly for  wk
Itraconazole 200 milligrams daily for  d
Atopic Topical High­potency Twice a day These options are available in ointment and cream dermatitis corticosteroids: formulations.
Clobetasol .5%
Halobetasol .5%
Mid­potency steroids:
Triamcinolone .1%
Low­potency steroids:
Hydrocortisone .5%
Oral Antihistamines
Fexofenadine 180 milligrams every morning Encourage scheduled dosing during flares.
Zyrtec  milligrams every evening
Contact Topical Same as for atopic dermatitis Same as for atopic dermatitis dermatitis
Oral Prednisone 40–60 milligrams PO every For severe contact dermatitis.
morning tapered over  wk
Children: 1–2 milligrams/kg PO
(up to  milligrams) tapered over  wk
Antihistamines
Same as for atopic dermatitis Same as for atopic dermatitis
Lichen Topical Triamcinolone .1% ointment Twice a day planus (cutaneous) Fluocinonide .05% ointment
Topical Fluocinonide .05% gel Four times daily
(mucous Lidocaine 2% jelly Three times a day membranes)
Secondary Intramuscular Benzathine penicillin G Single dose of .4 million units Doxycycline for use in penicillin­allergic patients.
syphilis IM
Doxycycline 100 milligrams PO every  h for  wk
Scabies Topical Permethrin 5% cream One application at bedtime to Permethrin is acceptable in infants older than  entire body from neck down. months.
Wash off in 8–12 h. Repeat in  Patient and all household members/close contacts d. must be treated concurrently. Wash linens and recently worn clothes in hot water, dry on high heat.
Oral Ivermectin 200 micrograms/kg PO once.
Repeat in  d.
Abbreviation: OTC = over the counter.
PSORIASIS
Psoriasis is discussed in detail in Chapter 253, “Skin Disorders: Extremities.” Flares of psoriasis can be idiopathic or related to other factors including infection, stress, alcohol ingestion, and medications. The following medications can be related to an exacerbation: steroid withdrawal,
 lithium, β­blockers, interferon, and antimalarials. The differential diagnosis is listed in Table 251­1. Diagnosis is clinical. Psoriasis is characterized by well­demarcated erythematous papules and plaques with a silvery white scale (Figure 251­1).
Removal of the scale typically reveals minute bleeding points referred to as Auspitz sign. Chronic plaque psoriasis is the most common variety, and localization to the sacrum, gluteal cleft, or umbilicus can occur. In the skin folds, psoriasis often lacks the characteristic silvery scale and is present only as well­demarcated, red­ to salmon­colored plaques. Involvement of the scalp and nails is not uncommon. Lesions of psoriasis tend to be symmetric with a predilection for the extensor surfaces. Localized physical trauma can cause new lesions to form (Koebner phenomenon—scratching causes new lesions to form in linear distribution of the scratch). Small, scattered discrete lesions, like water droplets, represent a distinctive form of psoriasis called guttate psoriasis (Figure 251­2). This can be seen on the trunk as an abrupt eruption following an infection, such as streptococcal pharyngitis, and can also be associated with human immunodeficiency virus. Generalized pustular psoriasis (Figure 251­3) should be included in the differential diagnosis of the acutely ill patient with generalized pustules.
FIGURE 251­1. Psoriasis. Large, well­marginated scaling plaques. [Photo contributed by University of North Carolina Department of Dermatology.]
FIGURE 251­2. Guttate psoriasis. Note discrete erythematous scaly papules resembling raindrops on the trunk. [Photo contributed by University of North Carolina
Department of Dermatology.]
FIGURE 251­3. Pustular psoriasis. [Photo contributed by University of North Carolina Department of Dermatology.]
First­line topical treatment for localized plaques includes topical steroids (Table 251­2). Ointment­based products penetrate best into thick plaques. High­potency steroids, such as clobetasol ointment or cream, can be used on the trunk (avoid use in axillae). Prolonged use may result in atrophy, steroid acne, pyoderma, or rebound with abrupt discontinuation. Follow­up with a dermatologist is critical for continued management. Do not prescribe systemic steroids due to the great risk of rebound or induction of pustular psoriasis.
SEBORRHEIC DERMATITIS
Seborrheic dermatitis is a chronic inflammatory disease with a predilection for areas of increased sebaceous gland activity. Incidence increases with
 age and in specific disease states. Erythema with a greasy yellowish scale is seen in the sebum­producing areas, such as the scalp, eyebrows, ears, beard, midchest, and groin (Figure 251­4). The lesions are often well marginated and symmetric. Weeping, crusting, and pruritus may occur, especially in the body folds and ears. Severe involvement may occur in patients with Parkinson’s disease, trisomy , human immunodeficiency virus, or acquired immunodeficiency disease. In an otherwise healthy­appearing patient with severe or new­onset seborrheic dermatitis, consider human immunodeficiency virus testing.
FIGURE 251­4. Seborrheic dermatitis. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical
Dermatology, 5th ed. © 2005, McGraw­Hill, Inc., New York.]
The presternal area, axillae, and groin are common sites for truncal involvement. The axillary involvement typically starts in the apices, similar to a contact dermatitis to deodorants, whereas clothing dermatitis involves the periphery but spares the axillary vault. The inframammary regions and umbilicus may also be involved. Treatment is aimed at controlling disease (Table 251­2). Mild cases may respond to over­the­counter shampoos containing ketoconazole 1%, selenium sulfide, zinc pyrithione, or salicylic acid. These can be lathered into any affected area on the scalp or body.
Prescription­strength ketoconazole 2% shampoo can be used several times weekly, or ketoconazole cream for the face can be used twice daily.
Hydrocortisone 1% cream or lotion, or .5% cream or lotion for more difficult cases, can be used twice daily in combination with antifungals until improvement is seen.
PITYRIASIS ROSEA
Pityriasis rosea is a viral exanthema associated with herpesvirus  and . It may be a reactivation of the latent herpesvirus that triggers a viremia and
 subsequent eruption. Typically, it affects those between  and  years old, most often in spring and fall. Pityriasis rosea often begins with a “herald” patch, which is a single, fine scaling, erythematous to salmon­colored discrete oval patch  to  cm in size (Figure 251­5). In  to  weeks, a generalized eruption occurs on the trunk and proximal arms, with a characteristic “Christmas tree” pattern of macules and plaques, with the long axis of the lesions oriented along skin tension lines (Figure 251­6). A collarette of scale with the open edge of scale on the inside of the lesion is a helpful diagnostic finding. Rarely, the face, palms, soles, or oral cavity can be involved. Pruritus can be moderate to severe. Mild constitutional symptoms may also occur at the onset of the eruption. Spontaneous resolution occurs within  to  weeks. Relapses or recurrences are uncommon.
FIGURE 251­5. Herald patch in pityriasis rosea (arrow). [Courtesy of the Centers for Disease Control and Prevention.]
FIGURE 251­6. Pityriasis rosea. Fine scaly plaques along skin tension lines. [Photo contributed by University of North Carolina Department of Dermatology.]
Table 251­1 lists the major differential diagnoses. In addition, several medications can cause a pityriasis­like eruption, including captopril, barbiturates, lisinopril, ketotifen, arsenicals, interferon, imatinib mesylate, gold, and clonidine. Guttate psoriasis can mimic pityriasis rosea but does not have the characteristic collarette of scale. Syphilis is another key item on the differential, particularly with palm and sole involvement, and a rapid plasma reagin should be considered if the diagnosis is at all in question.
Treatment is symptomatic (Table 251­2). Oral antihistamines and topical steroid creams (triamcinolone .1% cream) with emollients (petroleum jelly– based preparations) can help the pruritus. Ultraviolet B phototherapy from a dermatologist or natural sunlight may speed the resolution of the lesions.
 ,6
Improvement with high­dose acyclovir has been reported. Macrolides are not indicated.
TINEA CORPORIS
All superficial dermatophyte infections of the trunk, neck, arms, and legs are referred to as tinea corporis. Specific names are used for eruptions involving the groin (tinea cruris), feet (tinea pedis), hands (tinea manuum), face (tinea faciei), and scalp (tinea capitis); see associated chapters in this section for more detailed information about these specific locations. All ages can be affected, and lesions can spread by autoinoculation from other parts of the body. Trichophyton rubrum and Trichophyton mentagrophytes are the most common organisms that can spread from involvement of the feet. Occupational or recreational exposure (gyms, locker rooms) occurs from contaminated clothing, furniture, and/or equipment. Exposure to animals or contaminated soil may also cause tinea corporis. Pets may harbor Trichophyton verrucosum or Microsporum canis, whereas T.
mentagrophytes from Southeast Asian bamboo rats can cause a very inflamed and highly contagious widespread eruption. The incubation period is
 variable and may be days or months after exposure. The eruption may be chronic with mild pruritus as the only symptom. Tinea corporis is characterized by one or more sharply demarcated, mildly erythematous, annular scaling plaques (Figure 251­7). Central clearing gives the name
“ringworm.” The advancing scaling border is a characteristic finding, and the border is an excellent area to demonstrate long branching hyphae with a potassium hydroxide preparation (see Figure 248­1). Abrupt onset of widespread tinea may be associated with acquired immunodeficiency syndrome or other immunosuppressive disorders, or use of topical steroids. Occlusion, shaving, or topical steroid use may result in a deep, purulent, boggy folliculitis. The differential diagnosis is provided in Table 251­1. FIGURE 251­7. Tinea corporis. [Photo contributed by University of North Carolina Department of Dermatology.]
Treatment of localized lesions is with topical antifungal preparations (Table 251­2). Apply twice a day and extend the application to at least  cm beyond the advancing margin. Treat for at least  weeks and continue for  week after resolution. If tinea pedis or unguium is also present, apply
 the antifungal to the feet and nails. Widespread tinea corporis or involvement of hair follicles warrants oral therapy (Table 251­2). Oral agents may be expensive and can have interactions and contraindications in specific patient populations. Refer to a drug reference manual for specific details.
Baseline or concurrent liver enzyme levels when prescribing terbinafine are optional. Drug­induced liver injury is reported to be between  in ,000
 and  in 120,000 prescriptions, and 1% of patients develop a transient asymptomatic elevation of liver enzymes. Safety profiles of both terbinafine and
,9 fluconazole in children are similar to those in adults. Provide scheduled follow­up with a dermatologist or primary physician to assess treatment response.
“TINEA” PITYRIASIS VERSICOLOR
Pityriasis versicolor is caused by the overgrowth of the yeasts Malassezia furfur (previously Pityrosporum ovale) and Malassezia globosa. Malassezia species are part of the normal cutaneous flora and reside in keratin of skin and hair follicles. They require oil to grow, so the disease is more prevalent in young adults when sebaceous gland activity is highest. Predisposing factors include high temperature/humidity, oily skin, and steroid treatment.
Asymptomatic, hypo­ or hyperpigmented, often coalescing scaly macules are seen on the trunk or proximal extremities. The central upper chest and back are the most common areas of involvement (Figure 251­8). Facial lesions may be present in infants and the immunocompromised. The
“versicolor” refers to the varying shades of erythema and pigmentation. In untanned individuals, the lesions may be salmon or light brown. On darkly pigmented skin, the lesions may be hypopigmented. The fine scale is best appreciated by gently abrading the lesions with a glass slide or blade. The condition may be present for months or years and is usually asymptomatic, although pruritus can occur. Patients usually present due to cosmetic concerns regarding the inconsistent pigmentation.
FIGURE 251­8. Tinea versicolor. Hypopigmented macules with fine scale. [Photo contributed by University of North Carolina Department of Dermatology.]
The hyperpigmented, scaling pink macules of pityriasis versicolor may appear similar to those found in tinea corporis, psoriasis, pityriasis rosea, seborrheic dermatitis, or nummular eczema. Hypopigmented lesions should be differentiated from pityriasis alba, leprosy, or postinflammatory conditions. A potassium hydroxide preparation obtained by gently scraping the surface of the lesion and examining under the microscope (Table 248­
6) will reveal the characteristic short chopped hyphae and yeast forms termed “spaghetti and meatballs” (Figure 251­9) characteristic of Malassezia infection.
FIGURE 251­9. Tinea versicolor. Potassium hydroxide preparation with pseudohyphae, showing “spaghetti and meatballs” pattern. [Photo contributed by University of North Carolina Department of Dermatology.]
Treat with ketoconazole 2% shampoo, applied daily for a week, washing off after  to  minutes, or consider twice­daily treatment with azole antifungal creams, such as clotrimazole (Table 251­2). Widespread involvement usually makes these less cost effective and more difficult to apply. Extensive or
,10 refractory pityriasis versicolor can be treated with oral fluconazole or itraconazole (Table 251­2).
Discoloration may take months to resolve after treatment and is not a sign of treatment failure. Relapses are frequent, and instructions on prophylactic regimens should be given to include once­weekly selenium sulfide .5% or ketoconazole 2% shampoo.
ECZEMA/ATOPIC DERMATITIS/CONTACT DERMATITIS
The terms eczema and atopic dermatitis are often used interchangeably and have a variety of presentations. This section focuses on truncal involvement. In chronic eczema, the hallmark is the “itch that rashes,” in which an itch–scratch cycle perpetuates the condition. Itching is common and often worse at night and is aggravated by heat and sweat. Atopic individuals have a personal or family history of asthma, allergic rhinitis, nasal polyps, or “sensitive” skin. The acute stage demonstrates erythematous plaques that may be edematous and with miniature vesicles, whereas subacute lesions have more scale. The chronic stage presents with thickened (lichenified) skin showing accentuation of the normal skin markings caused by chronic rubbing (Figure 251­10). Scratching causes excoriations.
FIGURE 251­10. Atopic dermatitis. Lichenification, excoriations, and ill­defined scaling erythema. [Photo contributed by University of North Carolina Department of
Dermatology.]
Chronic contact dermatitis may be misdiagnosed as eczema or atopic dermatitis (Table 251­1) or may actually be a factor in the flare of eczema. See
Chapter 253, “Skin Disorders: Extremities,” for further discussion. The acute stage is typically limited to the area of contact with well­marginated erythema and edema. Papules and vesicles may be present, and bullae may occur in severe reactions with secondary crusting and erosions. Linear
(such as from poison ivy) or geographic lesions (such as nickel allergy; Figure 251­11) are typical. Pruritus can be severe. Subacute lesions have mild erythema, dry scale, and fine papules. Chronic eruptions will be lichenified with accentuation of the skin markings and show postinflammatory pigmentary changes. The subacute and chronic stages are frequently confused with endogenous eczema. The distribution is initially confined to the site of exposure but later can spread to sites beyond.
FIGURE 251­11. Allergic contact dermatitis. Erythematous scaly papules and lichenified plaques on the lower abdomen (contact with belt buckles). [Photo contributed by University of North Carolina Department of Dermatology.]

Treatment is directed at disease control (Table 251­2). Avoid harsh soaps and other irritants or contactants. Moisturize within  minutes of bathing with plain petroleum jelly, Aquaphor®, or Eucerin® cream. Use topical steroids, such as .5% hydrocortisone ointment, for mild disease or intertriginous sites; medium­potency preparations, such as triamcinolone .1%, for moderate involvement; or higher potency steroids, such as clobetasol, for more severe eruptions. Ointments are the most effective vehicle, but creams are also effective if patients prefer not to use ointments.
Severe contact reactions may require an oral prednisone taper over  weeks. The usual dose in a child is prednisone,  to  milligrams/kg PO, up to  milligrams/d. Adults respond well to a tapering dose of prednisone, starting at  to  milligrams/d PO each morning. Oral antihistamines, such as diphenhydramine or hydroxyzine, can control nighttime pruritus and scratching. Staphylococcal or streptococcal superinfections typically present with crusting and exudates. Prescribe cephalexin or dicloxacillin because antibiotic resistance is common with erythromycin. Obtaining cultures prior to initiating antibiotics may be useful.
Treat for community­acquired methicillin­resistant Staphylococcus aureus based on cultures or local patterns of bacterial resistance.
LICHEN PLANUS
Lichen planus may affect the skin, mucous membranes, and hair follicles. It is idiopathic in most cases, although cell­mediated immunity and human leukocyte antigen genetic susceptibility probably play a role. Age of onset is usually between  and  years old, and there is a 1% to 2% familial
 incidence.
The hallmark of lichen planus is the constellation of the “5 Ps”: purple, polygonal, pruritic, planar papules. The onset may be abrupt or over several weeks. The course is variable and may last months to years. Spontaneous resolution may occur, but recurrences are also common. The violaceous flat­topped papules may be discrete or generalized (Figure 251­12). Common sites of involvement include the lumbar region, flexor wrists, pretibia, scalp, and penis. Koebner phenomenon, caused by scratching, may result in a linear array of papules. In pigmented skin, a deep brown hyperpigmentation may occur. Wickham striae are fine white lacy reticulate lines that adhere to the papules and are pathognomonic for this condition (Figure 251­13). Mucous membrane involvement occurs in approximately half of those with the disease, and oral involvement only is common. The posterior buccal mucosa is most commonly affected; however, gingiva, tongue, and lips may also be involved. Painful erosions may be present and carry a 2% to 3% lifetime risk of squamous cell carcinoma in these areas. Approximately 70% of patients with mucosal vulvovaginal lichen
 planus also have oral involvement, so it is important to ask about genital symptoms.
FIGURE 251­12. Lichen planus. Violaceous, flat­topped polygonal papules on the back. [Photo contributed by University of North Carolina Department of
Dermatology.]
FIGURE 251­13. Lichen planus. Wickham striae, lace­like striations. [Photo contributed by University of North Carolina Department of Dermatology.]
There are many other variants of lichen planus, with the most common being hypertrophic, which presents with thick, hyperkeratotic plaques on the shins. Annular lichen planus is more common in men and typically involves the axillae, penis, or groin. This variant presents with asymptomatic ringed lesions approximately  cm in diameter. Follicular involvement of the scalp can result in a scarring alopecia. Nail changes can result in destruction of the nail fold and nail bed, with longitudinal splintering (pterygia).
Other papulosquamous diseases are included in the differential diagnosis of lichen planus (Table 251­1). The oral mucosal involvement and Wickham striae are helpful in distinguishing lichen planus from psoriasis. Chronic discoid lupus and fungal infections may have similar cutaneous findings.
Lichenoid drug eruptions can be identical to lichen planus, except they tend to be more generalized and photodistributed and there is a history of drug ingestion. The latent period can be months to years, with an average of  months, and it may take years to resolve after withdrawal of the offending agent. Common medications are listed in Table 251­4. Chronic graft­versus­host disease, dermatomyositis, and malignant lymphomas may also have lichenoid eruptions.
Treatment is with topical or intralesional steroids. Mid­ to high­potency preparations, such as triamcinolone .1% ointment or fluocinonide .05% ointment twice a day, are helpful, although treatment does not cure the disease. Intralesional triamcinolone,  milligrams/mL, can be used for very symptomatic cutaneous or mucous membrane lesions. Fluocinonide or clobetasol .05% gel four times a day can be used in the mouth. Oral analgesics, such as lidocaine jelly 2%, can be applied to the erosions three times a day before meals. Severe erosions or oral involvement may require
PO prednisone,  to  milligrams every morning for  to  weeks. If oral or other mucosal erosions are present, prompt follow­up with a dermatologist is crucial for further management and monitoring. Other systemic treatments include cyclosporine, retinoids, azathioprine, methotrexate, and mycophenolate mofetil.
SECONDARY SYPHILIS
Although the lesions are transient and often clinically unimpressive, the inclusion of secondary syphilis in the differential diagnosis of papulosquamous conditions in the ED is important. Primary syphilis is discussed in Chapter 153, “Sexually Transmitted Infections.”
Secondary syphilis exhibits skin manifestations in most patients and consists of early and later manifestations. The early eruption appears  to  weeks after the appearance of the primary chancre and is an evanescent macular rash lasting only a few hours or days. The macular erythema commonly appears on the sides of the trunk, midabdomen, and inner extremities. The discrete round macules are of varying shades from light pink to rose or even brownish red. They may be faint and difficult to appreciate on darkly pigmented skin. This phase of the disease is often asymptomatic, although associated symptoms can include pruritus, fever, sore throat, fatigue, headache, meningismus, and shotty, firm, nontender lymphadenopathy of the posterior cervical, axillary, and epitrochlear regions. The macular eruption resolves spontaneously and may leave
 postinflammatory hyperpigmentation.
Later eruptions of secondary syphilis may present in a variety of forms, hence the name the great imitator. This phase typically lasts  to  weeks and resolves spontaneously. There is usually no itching. Multiple recurrences over a period of  year can occur before infection enters the latent stage. The later eruptions of secondary syphilis are often papular lesions  to  mm in size, may be generalized, and are reddish to copper in color. The papules may be subtle or deeply infiltrated and firm. The surface may be smooth and shiny or have a thick, adherent scale (Figure 251­14 and Figures 153­6 and 153­7). Palmar­plantar involvement is a helpful finding and is characterized by tender copper­colored discrete macules with a collarette of scale.
Postinflammatory hyperpigmentation can be prominent and persist for weeks to months. Psoriasiform, follicular, lichenoid, or acneiform lesions can occur. Patients with human immunodeficiency virus may have atypical presentations, including very large infiltrated, scaling, and crusted plaques.
Annular lesions may occur, most frequently around the mouth, and may mimic sarcoidosis. Patchy nonscarring “moth eaten” alopecia may be present.
Split papules at the corners of the mouth, asymptomatic white plaques on mucous membranes, and condyloma lata in the genitals are highly infectious stigmata.
FIGURE 251­14. Secondary syphilis. Papulosquamous eruption. [Photo contributed by University of North Carolina Department of Dermatology.]
In secondary syphilis, the nontreponemal serologic tests are strongly reactive. Exceptions include the prozone phenomenon, in which a false­negative result occurs with high antibody titers, and rarely, in patients with acquired immunodeficiency syndrome, seronegative syphilis may occur. Histologic stains of affected tissues can be performed to confirm the diagnosis in seronegative patients.
The various cutaneous manifestations of syphilis may resemble many other cutaneous diseases (Table 251­1). Pityriasis rosea is the most common condition to consider and can have very similar cutaneous findings. However, the lesions of syphilis tend to be more circular and randomly arranged on the trunk, whereas pityriasis rosea has the oval “Christmas tree” distributed pattern. Pityriasis rosea also lacks palmoplantar and mucous membrane lesions and lymphadenopathy.
Treatment is benzathine penicillin G (Table 251­2). Doxycycline, 100 milligrams PO twice a day for  weeks, can be used in penicillin­allergic patients.
Further discussion is provided in Chapter 153, “Sexually Transmitted Infections.”
SCABIES
Scabies is infestation by the Sarcoptes scabiei mite and should be considered in any patient with complaints of severe generalized pruritus. The mite burrows and multiplies within the upper layer of the skin, and itching results from an immunologic response to the mites or their feces. In classic scabies, there are only  to  live mites present on the skin. In immunocompromised patients, there may be more than  million mites present.
Scabies is usually spread by skin­to­skin contact and can occur in any age group. The mite can also remain alive for >48 hours on inanimate objects, such as clothing and linens. The eruption can vary, ranging from minimal findings to extensive secondary excoriations and eczematous lesions. Hypersensitivity to the mite occurs before the development of symptoms. The initial exposure may not produce symptoms for several weeks.
Reinfestation may produce pruritus within  to  days. Previous sensitization, inadequate treatment, and the host’s immune status can alter the appearance of the condition. Chronic, undiagnosed scabies is referred to as the 7­year itch.
Intense pruritus is common, especially at night, although immunosuppressed patients may be asymptomatic. Common sites of involvement include the finger webs, wrists, axillae, areolae, umbilicus, lower abdomen, waistband, and genitals (Figure 251­15, A and B). Women frequently complain of nipple itching, whereas men most frequently note the penile or scrotal pruritic lesions. Pruritic papules, secondary excoriations, and burrows
(especially of finger or toe webs) are the classic findings. Secondary infection with crusting may occur. The head and neck are typically spared, although they may be involved in infants and the immunocompromised. Red­brown papules and nodules may occur on the penis and scrotum.
FIGURE 251­15. A and B. Scabies. Erythematous scaling papules with excoriation. [Photos contributed by University of North Carolina Department of Dermatology.]
Crusted scabies occurs in immunosuppressed or debilitated patients. The lesions can be generalized and include the face and scalp, with marked crusting and heavy scaling. Pressure­bearing sites, such as the buttocks, elbows, and feet, are common areas of hyperkeratotic lesions. The tips of the fingers can be swollen, crusted, and have a psoriasiform scaling under the nails. See Chapter 252 and Figure 252­4 for more discussion of crusted scabies.
Atypical lesions can be seen in infants with involvement of the face and scalp, as well as vesicles or pustules on the palms and soles. An autosensitization­type reaction (“id”) can occur with widespread urticarial papules predominantly on the trunk and proximal extremities. Other pruritic disorders, including eczema, atopic dermatitis, contact dermatitis, urticarias, dermatitis herpetiformis, pediculosis infestation, lichen planus, and metabolic disorders such as uremia or hypo­ or hyperparathyroidism, should be considered in the evaluation. The presence of pruritus in other family members or close contacts is a helpful clue to scabies. A #15 blade can be gently scraped across a typical burrow and placed on a slide with mineral oil for microscopic confirmation. Diagnosis is made by the presence of the mite, feces, or ova (Figure 251­16).
FIGURE 251­16. Scabies eggs and feces. [Photo contributed by University of North Carolina Department of Dermatology.]
Treat with permethrin 5% cream applied overnight to the patient and all family members and close contacts (Table 251­2). Apply permethrin from the neck down, covering all areas of the body, including under the nails, in the umbilicus, around the nipples, and the genitals. Treat the face and scalp in affected infants and young children. Wash off in  to  hours. A second application administered  week after the first is recommended. Lindane®
 is no longer recommended because of potential neurotoxicity and resistance.
Ivermectin, 200 micrograms/kg PO single dose, is a very effective therapy for common and crusted scabies. Once­a­week dosage for two treatments is recommended. Three or more treatments may be required in the heavily infested or immunocompromised patient. This is also a convenient treatment for institutions or large groups.
Equally important in the treatment is the decontamination of the clothing, bed linens, and towels by hot water washing and machine drying. Items that cannot be washed should be sealed in plastic bags for  days. Itching may last for several weeks after treatment and is a sensitivity reaction to the remaining dead mites and mite products in the skin. Cortisone creams, such as triamcinolone .1%, or oral antihistamines can be given for the pruritus.
MORBILLIFORM/URTICARIAL ERUPTIONS
This section discusses the common morbilliform and urticarial eruptions: urticaria, pruritic urticarial papules and plaques of pregnancy, erythema migrans, and drug eruptions. See Table 251­3 for a summary of clinical presentations and treatments.
TABLE 251­3
Clinical Features and Treatment of Common Morbilliform/Urticarial Eruptions
Condition Clinical Features Treatment Comments
Urticaria/angioedema Urticaria: transient pruritic edematous Epinephrine (if associated with See Chapter  and Table wheals anaphylaxis) 14­4 for details
Angioedema: deeper, poorly defined First­generation edematous plaques antihistamines
(diphenhydramine, hydroxyzine)
Second­generation antihistamines (cetirizine, loratadine)
Prednisone  milligram/kg/d up to  milligrams PO daily
Polymorphic eruption of pregnancy (formerly Pruritic erythematous papules often Triamcinolone .1% cream Do not use fluorinated pruritic urticarial papules and plaques of in abdominal striae, progress to twice a day steroids in pregnancy pregnancy) plaques Diphenhydramine, loratadine, or cetirizine
Erythema migrans Expanding, annular, erythematous Doxycycline 100 milligrams Refer to Chapter 161, patch; may have concentric rings of twice a day for  wk “Zoonotic Infections” for erythema more details
URTICARIA AND ANGIOEDEMA
Urticaria is a vascular leak in the superficial dermis of the skin characterized by transient pruritic wheals and welts. Angioedema is the presence of larger edematous areas that involve the deeper dermis and the subcutaneous tissue. Both of these conditions may be acute or chronic, and the individual lesions come and go within  hours. The acute course is <6 weeks, whereas chronic urticaria/angioedema can last several years.
Acute urticaria can be immunoglobulin E–mediated or triggered by penicillins, sulfa drugs, minocycline, food allergies, stings or bites, and infections.
An unusual allergy characterized by acute urticaria or anaphylaxis is allergy to meat (beef, lamb, pork), resulting from immunoglobulin E–mediated
 allergy to galactose­α­1,3 galactose. It is thought that sensitization is mediated by a Lone Star tick bite (often not recognized), which introduces the oligosaccharide galactose­α­1,3 galactose into the bitten person, resulting in immunoglobulin E antibody production. About  hours after eating meat, urticaria or anaphylaxis develops. Treatment is the same as for urticaria or anaphylaxis of any cause, and control is maintained by avoidance of eating any meat. Duration of allergy is unknown. Galactose­α­1,3 galactose allergy is reported in the middle United States and the north, central, and southern Atlantic states where the Lone Star tick is prevalent. Nonimmunologic causes of urticaria, angioedema, and anaphylaxis include NSAIDs and radiocontrast material.
Angioedema occurring in the absence of urticarial wheals can occur in hereditary and nonhereditary forms. C1 esterase inhibitor deficiency is a hereditary cause of recurrent angioedema without wheals. Nonhereditary, non–immunologic­mediated triggers include NSAIDs, angiotensinconverting enzyme inhibitors, radiocontrast material, penicillins, and monoclonal antibodies. In the case of angiotensin­converting enzyme inhibitors, an angioedema reaction can occur more than a year after starting the medication and is a reason for discontinuation of
,17 the medication.
Chronic urticaria consists of recurring lesions for longer than  weeks. Intolerance to NSAIDs, benzoates, contrast dye, and opiates is common, but the
 cause is often unknown. Physical stimuli such as cold, pressure, and extreme exercise may produce urticarial reactions. Ask about reactions occurring  to  hours after eating meat (see above discussion).
Pruritic edematous papules coalescing into plaques can affect any area of the skin. The urticarial wheals are white, pink, or erythematous nonscaling lesions that range in size from <1 cm to >10 cm. The pattern can be annular, serpiginous, or confluent (Figure 251­17, A and B). Lesions wax and wane over  hours. Angioedema consists of deeper, less well­demarcated edematous plaques and can be associated with bronchospasm and hypotension. The diagnosis is clinical. Atypical erythema multiforme can resemble urticaria, but the lesions of erythema multiforme are not pruritic or transient. Contact urticaria can develop from specific allergies (latex) or chemicals.
FIGURE 251­17. A and B. Urticaria. Characteristic wheals. [Photos contributed by University of North Carolina Department of Dermatology.]
Treatment, summarized in Table 251­3, includes various antihistamines and systemic corticosteroids. H blockers have been a mainstay of treatment.

Long­acting, nonsedating (second­generation) antihistamines such as fexofenadine (Allegra®, 180 milligrams/d), loratadine (Claritin®,  milligrams/d), or cetirizine (Zyrtec®,  to  milligrams/d) can lessen new lesions and control pruritus. The short­acting (first­generation) H blockers
 diphenhydramine and hydroxyzine are helpful for breakthrough and nighttime pruritus. H ­blocking agents such as ranitidine can be used in chronic
 urticaria along with H ­blocking agents, but not as a monotherapy. Doxepin (10 to  milligrams), which has H ­blocking effects, can be used at night,
  but it is also sedating.
Prednisone may be required for angioedema and widespread urticaria. The dose is  to  milligrams daily for  to  days. However, a double­blind randomized ED clinical trial of 100 adults with acute urticaria of up to  hours in duration reported no clinical improvement with the addition of
 prednisone to an H antihistamine, levocetirizine. Reassure patients that acute urticaria nearly always resolves within several weeks. Refer refractory
 cases to a dermatologist or allergist. Please see Chapter  “Allergy and Anaphylaxis”, Table 14­6 for more details on urticaria and angioedema.
POLYMORPHIC ERUPTION OF PREGNANCY
Polymorphic eruption of pregnancy (formerly called pruritic urticarial papules and plaques of pregnancy) is an idiopathic, intensely pruritic eruption that usually begins in the third trimester of pregnancy. Primiparous women and women with multiple­gestation pregnancies are most often affected,
 but it rarely recurs in subsequent pregnancies. It does not affect fetal or maternal outcomes.
Intensely pruritic, erythematous, 1­ to 2­mm papules begin in the abdominal striae and quickly spread into plaques over several days. The abdomen, buttocks, proximal thighs, and, in some cases, arms can be involved (Figure 251­18, A and B). The face, mucous membranes, palms, and soles are spared. Urticarial plaques can be polycyclic or figurate and can sometimes have discrete tiny vesicles present. Most cases resolve within  days of delivery.
FIGURE 251­18. A and B. Polymorphic eruption of pregnancy (formerly called pruritic urticarial papules and plaques of pregnancy). Urticarial papules accentuated in the striae. [Reproduced with permission from Fleischer AB Jr, Feldman SR, McConnell CF, et al: Emergency Dermatology: A Rapid Treatment Guide. ©
2002, McGraw­Hill, Inc., New York.]
Conditions to consider in the differential diagnosis include drug reactions, erythema multiforme, cholestasis of pregnancy, atopic dermatitis, and the
 rare autoimmune condition pemphigoid gestationis.
Treatment is symptomatic. Frequent moisturization with over­the­counter creams and lotions, as well as mild­ to moderate­potency topical steroids,
 can be useful. Oral antihistamines may also be helpful. For severe symptoms, patients may require a short course of PO prednisone,  to  milligrams/d, for relief of the symptoms.
ERYTHEMA MIGRANS
Lyme borreliosis is caused by spirochetes in the genus Borrelia, and the Ixodidae tick is the vector. It is a complex multisystem disease and can present with cutaneous findings of erythema migrans in localized stage  disease (Figure 251­19). Stage  is disseminated infection involving multiple organ systems and can have numerous skin lesions. Stage  is persistent infection that can develop months to years later with lesions of acrodermatitis chronica atrophicans. For detailed discussion, see Chapter 161, “Zoonotic Infections.”
FIGURE 251­19. Erythema migrans. Well­defined erythematous plaque. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas
& Synopsis of Clinical Dermatology, 5th ed. © 2005, McGraw­Hill, Inc., New York.]
Early Lyme disease begins with a red macule or papule at the site of the tick bite. Disease transmission is more likely if the tick was attached for >36
 hours. Slow expansion of nonscaling erythema occurs over  to  days after the bite. It may become annular with central clearing around the bite site. Varying shades of red in concentric rings may be seen, and less commonly, the central portion may be indurated, blistering, or necrotic. There is usually no pain or itching. Patients may develop  to 100 multiple smaller lesions, sparing the palms and soles; this reflects disseminated infection.

Most lesions fade within  month, but recurrences can occur over the following months. Other cutaneous findings include diffuse urticaria, malar rash, or conjunctivitis. Mild flu­like symptoms of malaise, fever, headaches, arthralgias, GI symptoms, and lymphadenopathy may be present.
,21
Early Lyme disease diagnosis is clinical, due to poor test standardization and variable results of testing methods. Approximately 50% of
 biopsies may demonstrate spirochetes if obtained from the center of the lesion. Culture and polymerase chain reaction testing are specific but are neither sensitive nor widely available. Serologic testing is variable. Immunoglobulin M and G titers can be measured, with immunoglobulin M peaking between the third and sixth weeks of infection and immunoglobulin G developing over months. Enzyme­linked immunosorbent assay testing should
 be followed by Western blot testing if the results are equivocal or positive. The lesions of erythema migrans can resemble urticaria, cellulitis, insect bites, dermatophytoses, granuloma annulare, early morphea, erythema multiforme, or even annular subacute cutaneous lupus.
Avoid exposure by applying tick repellents containing N,N­diethyl­m­toluamide (DEET) to clothing and exposed skin. Check the skin after possible
,21 exposure and promptly remove ticks. Antibiotic prophylaxis for a tick bite is recommended if the tick was engorged at time of removal; if treatment can be given within  hours of the time the tick was removed; if the Ixodes tick was identified in a hyperendemic region; and in pregnant or immunocompromised patients. In nonpregnant patients, a single dose of doxycycline, 200 milligrams, after a known tick bite (with above risk factors)
,21 is recommended. Further information regarding treatment of tickborne diseases is found in Chapter 161, “Zoonotic Infections.” Most recommend at least  weeks of therapy for erythema migrans.
DRUG REACTIONS
Adverse cutaneous drug eruptions (Table 251­4) are a potential complication of nearly all medications. They can be immunologically mediated or nonimmunologic. Nonimmunologic reactions can be due to enzyme deficiencies, cumulative ingestion, photosensitivity, or topical irritants. Risk factors may include age, gender, dose, and the type of medication.
TABLE 251­4
Drug Reactions and Common Causative Agents
Type of
Common Drugs Comments
Reaction
Morbilliform Penicillins/cephalosporins, sulfonamides, minocycline, anticonvulsants Usually <14 d of exposure, resolves within  wk; trunk exanthem first, then extremities
Urticaria or Aspirin, NSAIDs, opiates, iodinated contrast material Usually <36 h since exposure, or within minutes of angioedema exposure
Photosensitivity Toxic: tetracyclines, NSAIDs, fluoroquinolones, amiodarone, psoralens, Sun­exposed areas; exaggerated sunburn responses eruption phenothiazides
Allergic: thiazides, sulfonamides, antimalarials, quinidine, quinine, tricyclic antidepressants, NSAIDs
Lupus Procainamide, phenytoin, minocycline, hydralazine, penicillamine Photodistributed eruption erythematosus– like
Acneiform β­Lactam antibiotics, steroids, contraceptives, phenytoin, halogens, lithium, No comedones; monomorphic papules and pustules eruption phenobarbital, haloperidol, ethambutol, isoniazid on back, shoulders, and chest; within  d of exposure
Pigmentation Zidovudine, heavy metals, phenytoin, oral contraceptives, minocycline, Chronic drug ingestion amiodarone, clofazimine, antimalarials
Fixed drug Tetracyclines, sulfas, NSAIDs, barbiturates, phenolphthalein Reexposure causes recurrence in same location eruption
Vesiculobullous Penicillamine, captopril, sulfas, thiols Hard to distinguish from bullous disorder eruption
Lichenoid ACE inhibitors (captopril enalapril), β­blockers (labetalol, propranolol), May occur months after exposure, oral lesions, slow eruption methyldopa, antimalarials, quinidine, TNF inhibitors (etanercept, infliximab), resolution up to  y hydrochlorothiazide, gold and other metals, penicillamine, NSAIDs
Anticoagulant Coumadin®, heparin Onset in 3–5 d, well­demarcated painful area of fatty necrosis tissue
Acute β­Lactam antibiotics, macrolide antibiotics, calcium channel blockers Onset <4 days after start of medication. Pustules start generalized (especially diltiazem), and antimalarials on face/intertriginous areas then rapidly generalize.
exanthematous Resolve in 1–2 wk, followed by desquamation.
pustulosis
Abbreviations: ACE = angiotensin­converting enzyme; TNF = tumor necrosis factor.
Cutaneous drug eruptions can mimic almost any other skin disease. Most reactions occur within  to  weeks of exposure, but hypersensitivity
 reactions may take longer to develop, so obtain a careful drug history when evaluating any type of rash. Patients may have taken the drug in the past without any problems.
The most common presentation is the morbilliform exanthem (Figure 251­20). Diffuse, symmetric, pruritic, erythematous macules and papules appear first on the trunk and then spread to the extremities. The initial eruption is usually within  to  days of exposure, usually resolves within  weeks after discontinuation, and resembles a viral exanthem. Pruritus is common with a drug eruption but often absent with a viral exanthem. Common offending agents are the semisynthetic penicillins, trimethoprim­sulfamethoxazole, and anticonvulsants. Ampicillin or amoxicillin given to patients with Epstein­Barr virus infection and sulfonamides administered to patients with human immunodeficiency virus have a high incidence of exanthems.
FIGURE 251­20. Drug eruption. [Photo contributed by University of North Carolina Department of Dermatology.]
Frequent offenders causing urticaria or angioedema are aspirin, NSAIDs, opiates, and iodinated contrast material. The eruptions usually occur within  hours of initial exposure or within minutes of rechallenge. Few to hundreds of lesions can be present, pruritus is prominent, and respiratory
 symptoms and serum sickness–like symptoms (fever, arthralgias, lymphadenopathy, and myalgias) can occur.
Photosensitivity eruptions are characterized by confluent erythema, macules, papules, or even vesicles in sun­exposed areas such as the chest,
 neck, face, and arms (Table 251­3). Photosensitivity can be divided into photoallergic and phototoxic reactions based on the mechanism. When prescribing drugs with a propensity for photosensitivity, advise patients to use skin protection and proper clothing to avoid sun exposure.
Pigmentation from drug ingestion can be striking in appearance. It may be related to postinflammatory changes, increased melanin production, or actual deposition of the drug or metabolites in the skin. Zidovudine is associated with both nail and generalized hyperpigmentation. Heavy metals, phenytoin, or oral contraceptives may cause pigmentation. Minocycline or amiodarone may give a gray­blue coloration. Clofazimine can cause a diffuse red hue and also blue­gray discoloration, especially in leprosy lesions. Antimalarials may produce gray or yellow discoloration.
Fixed drug eruptions (Figure 251­21) occur as solitary or occasionally multiple, discrete, round to oval erythematous patches that eventually turn dusky red or violaceous. Although the trunk may be involved, most cases occur in the oral mucosa or genitals. Lesions may become edematous, forming vesicles or bullae, and then erode. Reexposure to the causative drug results in recurrence of lesions in the identical location of the primary eruption within hours.
FIGURE 251­21. Fixed drug eruption. [Photo contributed by University of North Carolina Department of Dermatology.]
Anticoagulant necrosis may occur within  to  days of initiation of warfarin or heparin. It typically begins with a single painful area, followed by erythema that rapidly turns blue­black with subsequent necrosis of the skin. The lesion is very well demarcated. Common sites of involvement are regions of high subcutaneous fat distribution, including the buttocks, thighs, or breasts. Risk factors include high doses, obesity, female gender, and deficiency of protein C or S or antithrombin III.
Some drugs produce vesiculobullous eruptions that can be difficult to distinguish from pemphigus or bullous pemphigoid. Penicillamine, captopril, sulfa­based, and thiol drugs can cause a blistering eruption. A pseudoporphyria­like reaction with tense small blisters and vesicles on the extensor arms and dorsal hands is associated with furosemide, NSAIDs, tetracycline, and penicillamine exposure.
Acute generalized exanthematous pustulosis occurs within a few days (<4) of drug exposure. Patients develop fever and a generalized eruption of small, sterile pustules on a background of widespread erythema and edema (Figure 251­22). Pustules often start on the face, axillae, and/or groin before generalizing within a few hours (Figure 251­23). Rapid onset and lack of psoriatic nail changes help distinguish acute generalized
 exanthematous pustulosis from pustular psoriasis. Although edema of hands and face can be associated with acute generalized exanthematous pustulosis, rapid onset and widespread distribution of pustules distinguishes acute generalized exanthematous pustulosis from drug rash with
 eosinophilia and systemic symptoms (see below). Drugs most commonly implicated in acute generalized exanthematous pustulosis include β­lactam antibiotics, macrolides, calcium channel blockers, and antimalarials. Treatment involves discontinuing the offending drug, antipyretics, and topical corticosteroids.
FIGURE 251­22. Acute generalized exanthematous pustulosis. [Photo contributed by University of North Carolina Department of Dermatology.]
FIGURE 251­23. Acute generalized exanthematous pustulosis. [Photo contributed by University of North Carolina Department of Dermatology.]
Drug reaction with eosinophilia and systemic symptoms, drug­induced hypersensitivity syndrome, erythema multiforme, Stevens­Johnson syndrome, and toxic epidermal necrolysis are most commonly caused by the aromatic amines, phenytoin, carbamazepine, and phenobarbital, as well as sulfonamides. These reactions are discussed in Chapter 249, “Generalized Skin Disorders.”
For diagnosis, exclude exanthems triggered by infections, and then obtain a thorough history of exposure to prescription and over­the­counter agents.
The pattern of the eruption and the likelihood of particular agents associated with the clinical findings can be found in drug reference manuals.
Treatment is discontinuation of the suspected agent. When the patient is on multiple medications, simplify drugs and discontinue unnecessary agents.
Rechallenge, even at reduced dosages, may produce rapid recurrence of the reaction. Oral antihistamines can be helpful for pruritus. Severe symptoms may require topical or oral steroids. Patients may be referred for skin testing in evaluation of type  immunoglobulin E–mediated reactions, such as penicillin, anesthetics, or vaccines. Radioallergosorbent tests for immediate reactions and lymphocytotoxicity assays can also be performed to identify anticonvulsant or sulfonamide hypersensitivity reactions.
BLISTERING DISEASES
Blistering diseases can be divided into vesicular, bullous, and pustular. A small blister <1 cm is termed a vesicle. Primary vesicular diseases that may affect the trunk include herpes infection (both simplex and varicella), insect bites, and allergic contact dermatitis. Larger blisters, >1 cm, are called bullae and may actually begin as vesicles. The most common bullous disease to affect the trunk is bullous pemphigoid. Severe allergic contact dermatitis, Stevens­Johnson syndrome/toxic epidermal necrolysis, and bullous impetigo may also present with bullae. Blood­filled, or hemorrhagic, bullous diseases include necrotizing fasciitis, vasculitis, Vibrio vulnificus infection, and bite reactions to brown recluse spiders or rattlesnakes. Cloudy, whitish fluid within a blister is termed a pustule. Any blistering condition can become pustular as the lesion ages or becomes secondarily infected. Lifethreatening blistering conditions are discussed in Chapter 249. Varicella is discussed in Chapter 142, “Rashes in Infants and Children.”
HERPES ZOSTER
After primary exposure to varicella, the virus remains latent in the sensory dorsal root ganglia until it later reactivates and spreads down the sensory
 nerve to the skin. Reactivation of the latent varicella virus produces the unilateral, painful, localized, vesicular eruption of herpes zoster. It primarily affects one dermatome, although overlap to adjacent dermatomes can be seen. Herpes zoster is more common in the elderly and immunosuppressed.
More than half of cases affect the thoracic nerves, 20% affect the cranial or trigeminal region, 15% affect the lumbar region, and 5% affect the sacral
 region. Pain (can be severe), tingling, pruritus, or burning sensations may precede the eruption by several days or weeks.
The initial lesions are erythematous papules coalescing into plaques within a dermatome, followed by vesicles or bullae within  to  hours (Figure
251­24). Single lesions in varying stages resemble varicella. Lesions may become pustular, hemorrhagic, or necrotic over the following days. New lesions may develop for up to  week, and crusting of the lesions occurs within  to  days.
FIGURE 251­24. Herpes zoster. [Photo contributed by University of North Carolina Department of Dermatology.]

## Page 33

University of Pittsburgh
Access Provided by:
Herpes zoster can be difficult to clinically distinguish from herpes simplex. Herpes simplex more commonly involves the perioral, lumbosacral, or external genital areas, and a history of recurrent lesions with typical prodromal symptoms is helpful. Other diseases to include in the differential diagnosis of the dermatomal eruption are allergic contact reactions, erysipelas, and impetigo.
Diagnosis is clinical. A Tzanck test (Figure 248­6) can be performed, which is also positive in varicella. Definitive diagnosis can be made by polymerase chain reaction studies or viral cultures on the vesicle fluid or biopsy specimen.
Treatment is with oral acyclovir, valacyclovir, or famciclovir. Dose adjustment is required for patients with renal impairment. Combined treatment
 with gabapentin and acyclovir at the time of outbreak may be more effective at reducing postherpetic neuralgia than antivirals alone. In severe cases, such as ophthalmic zoster or disseminated disease, IV acyclovir should be given at a dose of  milligrams/kg three times a day. Topical antiviral therapy or antibiotics are not useful in the treatment of zoster. Application of moist dressings (Burow’s solution or petroleum jelly) may be soothing.
Rest and NSAIDs are recommended. Evaluate and treat associated pain, which may be severe. Herpes zoster is contagious several days before the lesions appear and until all the lesions have crusted over. Exposure may result in varicella infection in those without previous infection or in immunocompromised individuals. Refer to Chapter 154 for more details.
BULLOUS PEMPHIGOID
Bullous pemphigoid is the most common autoimmune blistering disease in the elderly. It mostly affects individuals between  and  years old and has equal incidence in males and females. Bullous pemphigoid is generally self­limited and typically resolves over  to  years. Relapses occur in 10% to
15% of patients.
Autoantibodies to the basal keratinocyte hemidesmosomal antigens cause blisters at the basement membrane zone between the epidermis and dermis. Circulating basement membrane zone immunoglobulin G antibodies can be detected in most patients, and blood eosinophilia is present in about half of patients.
Bullous pemphigoid often begins with pruritic urticarial plaques and papules. These are not transient like urticaria. Bullae evolve over weeks to months. The bullae are tense and firm­topped, appearing on normal or erythematous skin (Figure 251­25). They do not extend when lateral pressure is applied. Sites of predilection include the axillae, abdomen, inner thighs, flexural forearms, and lower legs. The eruption may be localized or generalized. Bullae eventually rupture, leaving a thin blister roof overlaying the lesion, crusts, and erosions.
FIGURE 251­25. Bullous pemphigoid. [Photo contributed by University of North Carolina Department of Dermatology.]
Bullous pemphigoid can be confused with urticaria or urticarial reactions in the early phase. Dermatologic consultation, with histopathology and immunofluorescence studies, is required for diagnosis and treatment.

Chapter 251: Skin Disorders: Trunk, Katharine Kenyon; Dean S. Morrell; Diana B. McShane 
Treatment is typically provided by a dermatologist. High­potency topical steroid (clobetasol) ointment can be used for localized disease. The
. Terms of Use * Privacy Policy * Notice * Accessibility mainstay of treatment for extensive disease is oral prednisone, l.0 to .5 milligrams/kg/d. This dose can be gradually tapered when the disease is in remission. Systemic dapsone, azathioprine, mycophenolate mofetil, cyclophosphamide, and methotrexate are useful steroid­sparing agents.
INSECT BITES
Bites can produce an inflammatory or allergic reaction. Sensitive individuals can develop an intensely pruritic papule, vesicle, or bulla within hours to days after the bite. The lesions can last for days to weeks. Patients are often unaware of exposure. Systemic symptoms may occur in some individuals, ranging from mild to severe, including anaphylactoid reactions. Spiders, centipedes, millipedes, shellfish, fleas, mosquitoes, and fire ants are responsible for most bites.
Each type of bite can cause a different type of reaction, and individuals will differ in their local response. Transient red macules may occur at the site of the bite. Urticarial papules and vesicles can form, and secondary excoriations are frequent (Figure 251­26). A central punctum may be noted at the site of the bite. Large bullae may occur, particularly in patients with chronic lymphocytic leukemia. Necrosis can develop and may be associated with systemic symptoms, including fever, headache, malaise, and arthralgias. Flea bites most commonly occur on the lower extremities, although children are more likely to have generalized bites. Mosquito bites occur on any exposed areas. Bedbugs will bite in linear groups (“breakfast, lunch, dinner”) on sites exposed during sleep. Fire ants produce a brisk inflammatory reaction that forms a sterile pustule and can be quite painful. Other causes of blistering reactions include the blister beetle, which contains the chemical cantharidin and, when crushed, can produce vesicles and blisters on exposed areas. The caterpillar family can cause an immunoglobulin E–mediated allergic contact dermatitis. Clinical features and treatment of bites with envenomation are discussed in Chapter 211, “Bites and Stings.”
FIGURE 251­26. Bug bites. [Photo contributed by University of North Carolina Department of Dermatology.]
Treat bites with NSAIDs to relieve pain and reduce the local reaction. Remove any stingers. Deflea animals and the house. Topical corticosteroids can be used, such as fluocinonide .05% or clobetasol .05% cream or ointment. Severe reactions may require a short course of oral steroids: prednisone,
 to  milligrams once a day (adults) or  to  milligrams/kg once a day (children) each morning for  to  days. Antihistamines can help control pruritus. Provide an EpiPen® to any patient who has had a severe bite reaction.
BOTFLY BITE
One unusual bite is that of the botfly or furuncular myiasis, caused by Dermatobia hominis. The condition is endemic to Mexico and Central America.
Botfly larvae are deposited onto the surface of a mosquito or fly. When an individual is bitten, the botfly larva painlessly penetrates the skin. Bites most commonly affect the trunk, followed by the head, legs, and arms—any exposed skin areas. The initial lesion is usually felt to be a generic “insect bite.”
In  to  weeks, the lesion evolves into a furuncle with a central pore, which clinically appears as an infected bite, inflamed cyst, or cellulitis. There may be a sensation of movement within the furuncle. Diagnosis is typically made when the furuncle is drained and the larva is seen. Completely extract the larva or infection or a foreign body reaction will develop. There are no systemic complications, and no specific prevention exists, other than the application of insect repellents.
SELECTED COMMON MISCELLANEOUS DISORDERS OF THE TRUNK
MOLLUSCUM CONTAGIOSUM
Molluscum contagiosum is a common viral infection of the epidermis occurring in children, atopics, sexually active adults, and immunosuppressed individuals (especially patients with human immunodeficiency virus). It is caused by poxvirus variants molluscum contagiosum viruses  to , with the most common being molluscum contagiosum virus  in children and molluscum contagiosum virus  in human immunodeficiency virus infections.
Transmission is by direct skin­to­skin contact and via fomites.
There can be a single skin­colored, pearly, umbilicated papule (1 to  mm) or multiple, scattered papules or nodules and plaques (5 to  mm) (Figure
251­27). Autoinoculation is evident by the clustering of lesions in areas of rub or friction, some with a linear array from scratching. The lesions may become crusted, inflamed, or pustular if irritated. An inflammatory reaction may precede the spontaneous resolution of the lesions. In children, the lesions may range in number from a few to >100. The face, trunk, and extremities are commonly affected. Generalized involvement may occur in atopic dermatitis. In sexually active adults, there are  or fewer lesions on the lower abdomen, thighs, and genital region. Other sexually transmitted diseases may coexist. In immunosuppressed patients, hundreds of lesions may be present, and involvement of the face, with lesions being spread by
 shaving, is common. In human immunodeficiency virus, this occurs when CD4 counts are less than 100 cells/mm . Giant molluscum lesions,
 involvement of the oral and genital mucosa, and facial disfigurement may occur (CD4 <50 cells/mm ).
FIGURE 251­27. Molluscum contagiosum. Centrally umbilicated papules. [Photo contributed by University of North Carolina Department of Dermatology.]
Diagnosis is clinical. If necessary, a Giemsa stain of the expressed keratotic core demonstrates intracytoplasmic inclusion bodies (“molluscum bodies”) (Figure 248­2). In the immunocompromised, if diagnosis is unclear, obtain a biopsy to exclude fungal infection.
Most patients require no treatment because spontaneous resolution of molluscum occurs within  months to  years. Avoid shaving the affected area. For bothersome cases, application of topical cantharidin (blister beetle fluid) will produce good resolution of lesions, although multiple
 treatments may be necessary. Curettage, cryotherapy, or electrodesiccation can also be done. In individuals infected with human immunodeficiency virus, treatment of the underlying human immunodeficiency virus infection may lead to resolution.
MILIARIA
Miliaria occurs due to obstruction of eccrine sweat glands and can be associated with pruritus. It can occur at any age but is more common in
  children. Miliaria rubra is the most common form and presents with small punctate vesicles overlying erythematous macules or papules. Miliaria
 crystallina is characterized by small, clear vesicles without underlying erythema. When ruptured with a needle, miliaria will drain clear sweat. This condition is self­limited and improves with a cool environment and avoidance of sweat duct occlusion.
FOLLICULITIS
Superficial folliculitis is a common inflammatory disorder of hair follicles that presents with multiple erythematous, follicularly based, scattered
 papules and pustules (Figure 251­28). It is sometimes associated with pruritus or pain. Areas of involvement include the trunk, buttocks, extremities, neck, and scalp. Treatment of common folliculitis can include over­the­counter topical benzoyl peroxide washes and topical clindamycin.

Oral doxycycline can be used for widespread involvement.
FIGURE 251­28. Folliculitis. [Photo contributed by University of North Carolina Department of Dermatology.]
“Hot tub folliculitis” (Figure 251­29) is due to Pseudomonas aeruginosa and occurs within  to  days of hot tub use. Pruritus is a common symptom. It is self­limited in otherwise healthy patients, but antibacterial soaps can be used as treatment. In immunosuppressed patients, treatment
 with ciprofloxacin, 500 milligrams twice a day for  to  days, is recommended.
FIGURE 251­29. Hot tub folliculitis. [Photo contributed by University of North Carolina Department of Dermatology.]
KAPOSI’S SARCOMA
Kaposi’s sarcoma is a vascular neoplasia characterized by endothelial cell proliferation with multisystem involvement. Human herpesvirus  has been identified in all variants of the lesions, although it is not known how this virus induces the proliferation of the microvasculature. Individuals infected with human immunodeficiency virus are at high risk for Kaposi’s sarcoma. The use of highly active antiretroviral therapy has reduced the incidence by
10­fold. The clinical presentation of Kaposi’s sarcoma is different from the classic form seen in elderly males of eastern European heritage. Patients with human immunodeficiency virus can present with widespread, numerous lesions. The lesions may be erythematous or violaceous macules that can progress to tumors or nodules. The lesions on the trunk may be arranged parallel to the skin tension lines and can occur in areas of trauma
(Figure 251­30). Erosions, ulceration, crusting, and hyperkeratosis may be secondary changes seen. The trunk is an area of predilection, as are the hard palate, penis, and lower extremities.
FIGURE 251­30. Kaposi’s sarcoma. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology,
5th ed. © 2005, McGraw­Hill, Inc., New York.]
Classical or European Kaposi’s sarcoma occurs in elderly males of Mediterranean or Ashkenazi Jewish heritage. This variant predominantly arises on the lower extremities and can be associated with edema. It can also affect the lymph nodes and abdominal viscera.
Treatment depends on the extent and severity of the disease and underlying cause. Referral to infectious disease and hematology/oncology specialists is necessary in most cases.


