## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 98: Ectopic Pregnancy and Emergencies in the First  Weeks of Pregnancy
Heather A. Heaton
INTRODUCTION
This chapter discusses common obstetric­related conditions in the first  weeks of pregnancy: ectopic pregnancy, spontaneous abortion, septic abortion, gestational trophoblastic disease, and nausea and vomiting of pregnancy. Ectopic pregnancy is the most important consideration until it can be either confirmed or excluded with conviction.
GENERAL APPROACH TO WOMEN OF CHILDBEARING AGE
The differential diagnosis for women of childbearing potential who present with abdominal or pelvic symptoms or abnormal vaginal bleeding is broad and provided in Table 98­1. Consider ectopic pregnancy in women of childbearing age who report abdominal or pelvic pain or discomfort, vaginal spotting or a cycle of amenorrhea, or unexplained signs or symptoms of hypovolemia.
TABLE 98­1
Differential Diagnosis of Ectopic Pregnancy
All Patients Pregnant Patients
Appendicitis Normal (intrauterine pregnancy)
Inflammatory bowel disease Threatened abortion
Ovarian pathology Inevitable abortion
Ovarian cyst Molar pregnancy
Ovarian torsion Heterotopic pregnancy* Pelvic inflammatory disease Implantation bleeding
Endometriosis Corpus luteum cyst
Sexual assault/trauma
Urinary tract infection
Ureteral colic
*Heterotopic pregnancy = combined intrauterine pregnancy and ectopic pregnancy.
PREGNANCY TESTING

The diagnosis of pregnancy is central to the diagnosis of ectopic pregnancy. Pregnancy tests currently in use rely on the detection of the β
Chapter 98: Ectopic Pregnancy and Emergencies in the First  Weeks of Pregnancy, Heather A. Heaton subunit of human chorionic gonadotropin (β­hCG) in the urine or serum. hCG is a hormone produced by the trophoblast. Intact hCG consists of the α
. Terms of Use * Privacy Policy * Notice * Accessibility and β subunits. Tests based on detection of the intact molecule or the α subunit can cross­react on immunologic assays with hormones found in the nonpregnant individual and are thus less specific than tests for the β­hCG subunit.
hCG preparations are currently standardized in relation to the Third International Reference Preparation. Other standard preparations are not equivalent. A preparation often referred to in earlier literature is the Second International Standard. The Third International Reference Preparation is roughly equal to .7 times the Second International Standard. To avoid confusion when interpreting the literature, pay attention to the standard used.
In this chapter, hCG and β­hCG concentrations refer to the Third International Reference Preparation unless otherwise noted.
Very early in either an intrauterine pregnancy (IUP) or an ectopic pregnancy, detectable amounts of β­hCG are released into the serum and filtered into the urine. The concentration of β­hCG is fairly closely correlated in the urine and serum, with urinary concentration also depending on urine specific gravity. Qualitative urine and serum tests for pregnancy usually use the enzyme­linked immunosorbent assay methodology. In the laboratory setting, enzyme­linked immunosorbent assay tests can detect β­hCG at concentrations <1 mIU/mL.
Qualitative tests in clinical use are typically reported as “positive” when the β­hCG concentration is ≥20 mIU/mL in urine and ≥10 mIU/mL in serum. A positive qualitative test therefore implies that β­hCG is present in at least this concentration. At this level of detection, the false­negative rate for detection of pregnancy will not be >1% for urine or .5% for serum. In clinical use, the performance of urine qualitative testing is 95% to 100% sensitive and specific compared with serum tests.
Dilute urine may cause a false­negative urine pregnancy test, particularly early in pregnancy when β­hCG levels are low (<50 mIU/mL).
Additionally, when hCG levels are present in large amounts (generally with concentrations of ,000,000 mIU/mL), a “hook effect phenomenon” can occur, giving false­negative results. This is thought to be related to excess hCG saturating both the fixed, solid­phase antibody and the labeled, soluble
 antibody of the assay, causing an absence of signal. The resultant false­negative test can be mitigated by diluting the sample. Point­of­care hCG whole­blood testing can reduce the total ED turnaround time compared to urine testing, with .6% concordance when compared with standard urine
 testing.
When a bedside urine test is negative and ectopic pregnancy is still being considered, perform a quantitative serum test. The sensitivity of quantitative serum testing for the diagnosis of pregnancy is virtually 100% when an assay capable of detecting ≥5 mIU/mL of β­hCG
 is used. Estimated β­hCG levels after conception are listed in Table 98­2. TABLE 98­2
Estimated β­Human Chorionic Gonadotropin (β­hCG) Levels After Conception4
Post Conception Week β­hCG Levels (mIU/mL)
<1 week 5–50
1–2 weeks 50–500
2–3 weeks 100–5000
3–4 weeks 500–10,000
4–5 weeks 1000–50,000
5–6 weeks ,000–100,000
6–8 weeks ,000–200,000
8–12 weeks ,000–100,000
ECTOPIC PREGNANCY
INTRODUCTION AND EPIDEMIOLOGY
Ectopic pregnancy occurs when a conceptus implants outside of the uterine cavity; ruptured ectopic pregnancies are a leading cause of maternal death
 in the first trimester of pregnancy.
Major risk factors for ectopic pregnancies are listed in Table 98­3, but a significant number of ectopic pregnancies occur in women in whom no risk
,6 factors are identified.
TABLE 98­3
Major Risk Factors for Ectopic Pregnancy
Pelvic inflammatory disease, history of sexually transmitted infections
History of tubal surgery or tubal sterilization
Conception with intrauterine device in place
Maternal age 35–44 (age­related change in tubal function)
Assisted reproduction techniques (cause unknown, as tube is bypassed in implantation)
Previous ectopic pregnancy
Cigarette smoking (may alter embryo tubal transport)
Prior pharmacologically induced abortion
PATHOPHYSIOLOGY
Fertilization of the oocyte usually occurs in the ampullary segment of the fallopian tube. In normal pregnancy, after fertilization, the zygote passes along the fallopian tube and implants into the endometrium of the uterus. An ectopic pregnancy occurs when the zygote implants in any location other than the uterus—the fallopian tube or extratubal sites (the abdominal cavity, cervix, or ovary). Death results from maternal exsanguination after tubal rupture.
The vast majority of ectopic pregnancies implant in the ampullary portion of the fallopian tube. The underlying cause is most often damage to the tubal mucosa from previous infection, preventing transport of the ovum to the uterus. Other causes include tubal surgery, defects in the ovum resulting in premature implantation, and elevated estradiol or progesterone levels, which inhibit tubal migration.
Tubal implantation results in the penetration of the ovum into the muscular wall of the tube, and maternal blood seeps into tubal tissue. Intermittent distention of the fallopian tube with blood can occur, with leakage of blood from the fimbriated end of the fallopian tube into the peritoneal cavity. The aborting ectopic pregnancy and associated hematoma can be completely or partially extruded out of the end of the fallopian tube or through a rupture site in the tubal wall.
Abdominal ectopic pregnancies (~1% of ectopic pregnancies) most commonly derive from early rupture or abortion of a tubal pregnancy, with subsequent reimplantation in the peritoneal cavity.
Cervical ectopic pregnancies occur in <1% of ectopic pregnancies, with predisposing factors similar to those associated with ectopic pregnancies
(previous dilatation and curettage, previous cesarean delivery, in vitro fertilization, adhesions or fibrosis of the endometrium, prior instrumentation, infertility, previous ectopic pregnancy). Patients develop profuse vaginal bleeding. Bimanual exam reveals a soft, large cervix when compared to the
,8 uterus or an hourglass­shaped uterus, and diagnosis is confirmed with US.
Cesarean scar pregnancy is rare but can cause massive maternal hemorrhage. Diagnosis is difficult and is based on US demonstrating an empty uterine sac and cervical canal and a gestational sac in the uterine isthmus.
HISTORY
Determine the timing and characteristics of the last few periods. The menstrual history is often, but not always, abnormal. The classic sign of amenorrhea from  to  weeks after the last normal period is reported in 70% of ectopic pregnancy cases. No missed menses are reported in
15% of ectopic pregnancy cases. Although vaginal bleeding is often scant, heavy bleeding does not exclude an ectopic pregnancy.
Ask about previous pregnancies, pregnancy problems, and miscarriages. Typical early pregnancy symptoms may occur and may not differ from symptoms of previous normal IUPs. Discuss previous medical and surgical history, and ask about substance abuse and smoking. Ask about sexual activity and contraception. Identify risk factors for ectopic pregnancy or spontaneous abortion. Determine current medications, including over­thecounter drugs.
Pregnancy in a patient with prior tubal surgery for sterilization is assumed to be an ectopic pregnancy until proven otherwise.
Patients are at particularly high risk if they have undergone laparoscopic partial salpingectomy or electrodestruction tubal ligation at a young age (age

<28 years), especially  to  years after the procedure.
In a woman of childbearing age, hysterectomy with oophorectomy excludes ectopic pregnancy. In the situation of hysterectomy without oophorectomy, ectopic pregnancy is exceedingly rare. A literature review identified only  such case reports since 1918, after both vaginal and
 abdominal hysterectomies. The theory is that a fistulous tract after hysterectomy enables embryo implantation in the tube or adnexae.

Abdominal pain or discomfort is the most common symptom of ectopic pregnancy and is reported in 90% of ectopic pregnancies. Pain is due to tubal distention or rupture. The classic pain of rupture is lateralized, sudden, sharp, and severe. Shoulder pain due to diaphragmatic irritation from a ruptured ectopic pregnancy can also occur. Any lateral or bilateral abdominal discomfort or tenderness in a woman of childbearing age requires consideration of ectopic pregnancy. Lack of pain in a woman with vaginal spotting or bleeding does not exclude ectopic pregnancy.
PHYSICAL EXAMINATION
Obtain vital signs and focus on the abdominal and pelvic examination. The physical examination in ectopic pregnancy is highly variable, and ectopic pregnancy is difficult to diagnose or exclude based on physical examination. In cases of ruptured ectopic pregnancy, patients may present in shock, with no findings on pelvic examination, or with peritoneal signs and an adnexal mass and tenderness. Cervical motion tenderness can be elicited on pelvic exam in some cases. Relative bradycardia may occur as a consequence of vagal stimulation. Vital signs may be normal due to compensatory
 mechanisms, despite significant hemoperitoneum. Fever is rare. In the more common situation of an unruptured ectopic pregnancy, the vital signs are likely to be normal.
If an adnexal mass or fullness with tenderness is detected, it may be due to ectopic pregnancy or to a corpus luteum cyst, a 3­ to 11­cm, thin­walled, unilocular cyst seen after ovulation that can cause pain and tenderness on exam as well as menstrual irregularities, mimicking an ectopic pregnancy.
Cervical motion tenderness may be seen, and blood is often present in the vaginal vault; however, the pelvic exam may be completely normal. The cervix may have a blue coloration, as in a normal pregnancy. Uterine size for estimated gestational age is most often normal. Vaginal examinations in stable women presenting with first­trimester bleeding may add little to the clinical diagnosis; some providers are moving away from routine use of
 vaginal examinations in initial patient assessment as long as a transvaginal US is obtained.
DIAGNOSIS
The definitive diagnosis of ectopic pregnancy is made by US, by direct visualization by laparoscopy, or at surgery. No single or combination of laboratory tests has a sufficient negative or positive predictive value to completely exclude ectopic pregnancy or to definitively establish the diagnosis.
SERUM β­HCG
Differences in the dynamics of β­hCG production in normal and pathologic pregnancy are useful in the diagnosis of ectopic pregnancy. Early in normal pregnancy, β­hCG levels rise rapidly until  to  weeks of pregnancy and then plateau. Expected postconception ranges of β­hCG are listed in Table 98­
. β­hCG levels decline in nonviable pregnancies and in successfully treated ectopic pregnancy. Absolute levels of β­hCG tend to be lower in pathologic pregnancies than in IUPs, but there is much overlap. Due to the variability in absolute levels and the overlap between normal and pathologic pregnancies, no single β­hCG level can reliably distinguish between a normal and a pathologic pregnancy. Doubling time refers to the time needed for β­hCG concentration in the serum to double. Absolute levels of β­hCG are lower and doubling times longer in ectopic pregnancy and other abnormal pregnancies. This and many other observations have led to the widely used rule of thumb stating that the serum concentration of β­ hCG approximately doubles every  days early in a normal pregnancy and that longer doubling times indicate pathologic pregnancy. Varying degrees of sensitivity (36% to 75%) and specificity (63% to 93%) are obtained using different criteria for evaluating the rate of increase of β­hCG levels for the
 diagnosis of ectopic pregnancy. The minimum hCG rise in normal pregnancy may be as low as 53% in  hours, and the median rise in β­hCG level
 was 53% in  day and 124% in  days. Conversely, in spontaneous abortion, hCG is expected to decrease by 21% to 35% in  days. Thus, hCG levels that fail to increase by 53% or more in  days are suggestive but not diagnostic of ectopic pregnancy or an abnormal IUP. However, an increase of
>53% does not rule out ectopic pregnancy.
In stable patients, serial measurements of β­hCG are used to either heighten or lower the suspicion for ectopic pregnancy but are not diagnostic.
Repeat serum β­hCG measurement made at least  days after the initial presentation is useful in characterizing the risk of ectopic pregnancy and the
 probability of a viable IUP. Although rates of decline vary depending on the initial hCG value, a decrease of less than 21% at  days or 60% at  days
 suggests retained trophoblasts or an ectopic pregnancy; additional testing should be performed.
PROGESTERONE
Progesterone is a steroid hormone secreted by the ovaries, adrenal glands, and placenta during pregnancy. During the first  to  weeks of pregnancy, ovarian production of progesterone predominates, and serum levels remain relatively constant. After the 10th week of pregnancy, placental production increases and serum levels rise. Absolute levels of progesterone are lower in pathologic pregnancies and fall when a pregnancy fails. This observation has led multiple authors to propose various progesterone levels as a diagnostic aid in differentiating an early normal from a pathologic pregnancy. Most pathologic pregnancies have progesterone levels of ≤10 nanograms/mL. With progesterone≤5 nanograms/mL, nearly
100% of pregnancies will be pathologic; there are no normal pregnancies reported with progesterone≤2.5 nanograms/mL. Progesterone levels >25 nanograms/mL have 97% sensitivity for viable IUP. An empty uterus or nonspecific fluid collection on US associated with progesterone≤5.0
 nanograms/mL is highly predictive of abnormal IUP or ectopic pregnancy.
There is considerable overlap between progesterone levels in normal and pathologic pregnancy. Thus, very low values for serum progesterone should increase the clinical suspicion for ectopic pregnancy or abnormal IUP, but as with β­hCG levels, no value is diagnostic or can completely exclude or definitively diagnose ectopic pregnancy. Progesterone levels may not be routinely available on an urgent basis, and as noted, many patients have intermediate values, thus limiting the usefulness of the test. Consequently, the role of serum progesterone assays is currently unclear.
Numerous other serum markers for the diagnosis of ectopic pregnancy have been investigated. These include secretory endometrial protein, estradiol, the pregnancy­associated proteins A to D, and others, as well as routine laboratory tests such as amylase, creatine kinase, erythrocyte sedimentation rate, and others. None has been accepted as equal or superior to β­hCG measurements at this time.
US AND ECTOPIC PREGNANCY
The primary goal of US in early pregnancy is determination of a viable IUP and exclusion of ectopic pregnancy (Figure 98­1).
FIGURE 98­1. Yolk sac (arrow) within an intrauterine gestational sac. Normal early pregnancy. Transvaginal image. [Reproduced with permission from Ma OJ, Mateer
JR, Reardon RF, Joing SA: Ma & Mateer’s Emergency Ultrasound, 3rd ed. © 2014, McGraw­Hill, Inc., New York.]
US findings may also be useful in planning therapy when an ectopic pregnancy is discovered. Additionally, US provides information regarding fetal age and viability when an IUP is present.
It has previously been assumed that if an IUP exists, the diagnosis of ectopic pregnancy has been excluded. This assumption is based on the historical incidence of heterotopic pregnancy (combined IUP and ectopic pregnancy), reported to occur in  in ,000 pregnancies. This is no longer a completely safe assumption, with heterotopic pregnancy now occurring in up to  in 3000 pregnancies in the general population. In vitro fertilization and other efforts to enhance fertility with the use of ovulation­inducing drugs have resulted in a higher incidence of heterotopic
 pregnancy. A study of 725 in vitro fertilization pregnancies found 4% to be ectopic pregnancies, with  of  heterotopic gestations. Heterotopic pregnancy should be considered even when US demonstrates an IUP in the assisted reproduction population. For other patients, demonstrating an
IUP still provides a high degree of confidence in ruling out ectopic pregnancy. This confidence should be somewhat tempered when a patient has risk factors for ectopic pregnancy.
Advances in sonographic imaging and the use of transvaginal US scanning allow earlier detection of an IUP or an ectopic pregnancy. These advances have contributed to increasing use of real­time, bedside US in the ED performed by emergency physicians. ED US has the further advantage of allowing a potentially unstable patient to remain under continuous observation in the ED. When performed by trained individuals, point­of­care ED US in the first trimester of pregnancy is accurate and can decrease ED length of stay, as long as a conclusive IUP is identified. Inconclusive bedside US requires
 radiology department–performed US.
The sequencing of transabdominal versus transvaginal US is situation and operator dependent. Usually, transabdominal scanning is performed first.
Among other differences, transabdominal scanning is less invasive and offers a wider field of view and easier orientation to the pelvic organs. A full bladder is required for an appropriate acoustic window.
When transabdominal US is not diagnostic, transvaginal scanning should be performed. A full bladder is not required. The shallower depth of field and higher frequencies made possible by the lack of interposed abdominal fat allow better visualization of early pregnancies. There are reports of negative transvaginal but positive transabdominal US in cases of ectopic pregnancy, so both studies should be performed if the study performed first is not diagnostic. However, in one study of >5000 women with early pregnancy, pregnancy location was accurately diagnosed in >90% with a single
 transvaginal scan.
When US reveals an unequivocal IUP and no other abnormalities, ectopic pregnancy is effectively excluded unless the patient is at high risk for heterotopic pregnancy. An embryo with cardiac activity seen within the uterine cavity is referred to as a viable IUP. When an embryo without cardiac activity is visualized within the uterus, the diagnosis of fetal demise can be entertained, provided that the crown–rump length is at least
 mm. Briefly, transvaginal scanning can usually visualize the early sonographic signs of pregnancy, the gestational sac, yolk sac, and fetal pole, at .5,
.5, and .0 weeks, respectively. Visualization by transabdominal scanning can be done approximately  week later.
No further diagnostic testing is needed when sonographic findings confirm or are highly suggestive of ectopic pregnancy. An empty uterus with embryonic cardiac activity visualized outside the uterus is diagnostic of ectopic pregnancy. This is seen in <10% of ectopic pregnancies using transabdominal scanning, but in up to 25% of cases when the transvaginal approach is used. When a pelvic mass or free pelvic fluid is seen in conjunction with an empty uterus, ectopic pregnancy is considered highly likely (Figure 98­2). The combination of an echogenic adnexal mass with free fluid in the setting of an empty uterus confers a risk of ectopic pregnancy near 100%, whereas a large amount of free fluid alone has an 86% risk
(Table 98­4). In addition to a living extrauterine pregnancy, an extrauterine gestational sac is highly predictive of ectopic pregnancy (Figure 98­3).
,21
Any adnexal mass (other than a simple cyst) seen with US also has high positive predictive value for the diagnosis of ectopic pregnancy. It has also been suggested that increased thickness of the endometrial stripe is predictive of ectopic pregnancy when no other diagnostic findings are noted on

US. However, the wide overlap between endometrial stripe thickness in normal and ectopic pregnancy limits the usefulness of this observation.
TABLE 98­4
Ancillary US Findings Suggestive of Ectopic Pregnancy in High­Risk Patients
Ancillary Findings Risk of Ectopic Pregnancy (%)
Any free pelvic fluid 
Complex pelvic mass 
Moderate/large amount of free pelvic fluid 
Tubal ring >95
Mass and free fluid 
Hepatorenal free fluid ~100
Source: Reproduced with permission from Ma OJ, Mateer JR, Reardon RF, Joing SA: Ma & Mateer’s Emergency Ultrasound, 3rd ed. New York: McGraw­Hill, Inc.; 2014;
Table 14­2, p. 404. FIGURE 98­2. Ectopic pregnancy: empty uterus and free fluid in the posterior cul­de­sac. Transvaginal sagittal image. Horizontal arrow points to empty uterus
(uterine stripe), and vertical arrow points to fluid in the cul­de­sac. [Reproduced with permission from Ma OJ, Mateer JR, Reardon RF, Joing SA: Ma &
Mateer’s Emergency Ultrasound, 3rd ed. © 2014, McGraw­Hill, Inc., New York.]
FIGURE 98­3. US of ectopic pregnancy. A living embryo in the adnexa and empty uterus is seen in this ectopic pregnancy (endometrial echo is visible in the left upper portion of the image). Embryonic cardiac activity was present on real­time imaging. Transvaginal image. Horizontal arrow points to empty uterus
(uterine stripe), and vertical arrow points to ectopic pregnancy in the adnexa. [Reproduced with permission from Ma OJ, Mateer JR, Reardon RF, Joing
SA: Ma & Mateer’s Emergency Ultrasound, 3rd ed. © 2014, McGraw­Hill, Inc., New York.]
THE DISCRIMINATORY ZONE
If US fails to reveal a definite IUP or fails to show findings strongly suggestive or diagnostic of an ectopic pregnancy, the test should be considered indeterminate and interpreted in light of quantitative serum β­hCG levels (Figure 98­4). The concept of the “discriminatory zone” was developed to
 relate β­hCG levels and US findings in a clinically useful way. The discriminatory zone is the level of β­hCG at which findings of an IUP are expected on
US. A β­hCG level higher than the discriminatory zone and an empty uterus on US suggest an ectopic pregnancy. An empty uterus with a β­hCG level below the discriminatory zone is indeterminate, neither confirming nor negating the diagnosis of ectopic pregnancy. The actual level of β­hCG representing the discriminatory zone is operator and technique dependent. With transvaginal scanning, the discriminatory zone is often considered to be 1500 mIU/mL. For transabdominal scanning, an IUP should be detectable when the β­hCG level reaches about 6000 mIU/mL. Clinicians should understand this concept and collaborate closely with imaging specialists in equivocal cases to avoid confusion. When ectopic pregnancy is suspected, US should be performed even in patients with low β­hCG levels, because ectopic pregnancy can occur even at very low (<500
 mIU/mL) β­hCG levels. Further, decision to intervene on a pregnancy should not be made solely on a single hCG level; if the patient is hemodynamically stable with a β­hCG greater than the discriminatory zone and no visible intrauterine or extrauterine pregnancy, watchful waiting is an
 appropriate management strategy with close follow­up and strict return precautions.
FIGURE 98­4. Diagnostic algorithm for suspected ectopic pregnancy. *Quantitative measurement of β subunit of human chorionic gonadotropin (β­hCG) before US
† ‡ may facilitate rapid patient disposition by saving time. There have been extremely rare reports of pregnancy with β­hCG <5 mIU/mL. Serial outpatient
β­hCG measurements are recommended only for stable patients judged to be at low risk for ruptured ectopic pregnancy. D&C = dilatation and curettage; EP = ectopic pregnancy; IUP = intrauterine pregnancy.
OTHER DIAGNOSTIC MODALITIES
MRI has high sensitivity and specificity for the diagnosis of ectopic pregnancy, but cost, availability, and the time to perform the study make the use of
MRI of only theoretical interest at the present time.
Culdocentesis has been supplanted by tests for β­hCG in combination with US. Sensitivity is poor, and false­positive results occur because of technical errors (entering a vein or other vascular structure with the needle) or from a ruptured corpus luteum cyst.
Laparoscopy may be both diagnostic and therapeutic. Laparoscopy is primarily useful in patients with suspected ectopic pregnancy and a nondiagnostic US. It may provide an earlier diagnosis and a possible route for definitive treatment when compared with serial β­hCG measurements and US.
TREATMENT
The treatment of ectopic pregnancy can be divided into surgical and medical approaches. If laparoscopy is needed for diagnosis, a surgical approach is most appropriate. For unruptured ectopic pregnancy, the most frequently used surgical approach is laparoscopic salpingostomy; the most frequently used medical approach is systemic methotrexate treatment. Medical therapy for ectopic pregnancy has comparable success rates to surgical therapies,
,26 while avoiding surgical complications in appropriately selected women with unruptured ectopic pregnancies.
METHOTREXATE
Methotrexate is the only drug currently recommended as a medical alternative to surgical treatment of ectopic pregnancy and is ideally used in patients with hemodynamic stability, minimal abdominal pain, the ability to follow up reliably, and normal baseline liver and renal function tests.

Contraindications to methotrexate use are listed in Table 98­5. Methotrexate is a folic acid antagonist that inhibits dihydrofolate reductase, causing
 depletion of cofactors needed for DNA and RNA synthesis. IM methotrexate is the most commonly used approach,  milligrams/m as a single IM dose.
The failure rate is .3% or higher with single­dose methotrexate when pretreatment β­hCG levels are >5000 mIU/mL, compared with .7% for levels

<5000 mIU/mL. If β­hCG levels are higher than 5000 mIU/mL, multiple doses may be appropriate. The success rate of the multiple­dose regimen is
 higher than a single dose of methotrexate (92.7% vs. .1%).
TABLE 98­5
Contraindications to Methotrexate Administration28
Absolute Contraindications Relative Contraindications
Intrauterine pregnancy Embryonic cardiac activity detected by transvaginal US
Evidence of immunodeficiency Human chorionic gonadotropin concentrations >5000 mIU/mL
Moderate to severe anemia, leukopenia, or thrombocytopenia Ectopic pregnancy >4 cm in size as imaged by transvaginal US
Sensitivity to methotrexate Refusal to accept blood transfusion
Active pulmonary disease Inability to reliably return for follow­up
Active peptic ulcer disease
Clinically important hepatic or renal dysfunction
Breastfeeding
Hemodynamic instability
The most common side effects associated with methotrexate include abdominal pain after treatment (up to 75% of patients) followed by flatulence and then stomatitis. Lower abdominal pain lasting up to  hours is common  to  days after methotrexate treatment and is thought to be secondary to
 methotrexate­induced tubal abortion or tubal distention due to hematoma formation (“separation pain”). The pain is usually self­limited and may respond to NSAIDs.
Abdominal pain after methotrexate treatment represents a clinical dilemma. It is difficult to differentiate expected pain from therapeutic tubal abortion
 and hematoma formation with fallopian tube distention (separation pain) from pain associated with rupturing persistent ectopic pregnancy.
Suggested evaluation of patients presenting with abdominal pain in this time frame after methotrexate administration includes a CBC and
 abdominopelvic US to rule out tubal rupture and hemoperitoneum and consideration of other causes of abdominal pain. Patients may need admission to the hospital for observation. Hemodynamic instability and/or falling hematocrit require consideration for surgical intervention. Many centers will proceed to surgical intervention in patients with moderate to severe pain, free fluid in the cul­de­sac, or rebound tenderness, although
 conservative treatment has proven successful in stable patients after methotrexate therapy. Prognostic factors associated with a higher failure rate
 for methotrexate treatment include larger tubal diameter, higher initial β­hCG levels, severe abdominal pain, and fetal cardiac activity.
Methotrexate administration in properly selected patients with ectopic pregnancy may be initiated in the ED, clinic, or obstetrician/gynecologist’s office. Treatment initiated in the ED should be in close conjunction with an obstetrician/gynecologist or other physician capable of providing follow­up care. Keep pelvic examinations after methotrexate treatment to a minimum to decrease the risk of tubal rupture. Patient instruction on discharge
 should include the following points :
Treatment failure occurs in up to 36% of cases.
Elective or emergency surgical treatment may be necessary if medical therapy fails or tubal rupture occurs (~5% of cases).
Vaginal bleeding, abdominal pain, weakness, dizziness, or syncope after treatment should be evaluated immediately as possible signs of tubal
 rupture.
Patients should refrain from sexual intercourse for  to  days after treatment (until β­hCG levels are undetectable), because it may increase the risk of tubal rupture.
RH SEROCONVERSION AND INDICATIONS FOR ANTI­D IMMUNOGLOBULIN
Rh (D) antigen can be detected as early as .5 weeks and certainly by  weeks of gestation. Alloimmunization can occur with as little as .1 mL of fetal
 blood admixing with the mother’s. Alloimmunization can occur from ectopic pregnancy. Circulating blood volume of the fetus is <5 mL in the first trimester. Both the American College of Emergency Physicians and the American College of Obstetricians and Gynecologists recommend treatment with  micrograms of RhoGAM® for Rh­negative women with ectopic pregnancy when diagnosed prior to  weeks of gestation due to the small volume of red cells in the fetoplacental circulation, although administration of a full dose of
300 micrograms is acceptable as well.
DISPOSITION AND FOLLOW­UP
Figure 98­4 summarizes the algorithm for management of suspected ectopic pregnancy. Unstable patients with suspected ectopic pregnancy should receive resuscitation, emergency consultation, and operative intervention.
For patients with unruptured ectopic pregnancy, a quantitative β­hCG level facilitates subsequent management. Stable patients with β­hCG levels above the discriminatory zone and an empty uterus on US, with or without other US findings of an ectopic pregnancy, are presumed to have an ectopic pregnancy. These patients should receive gynecologic consultation in the ED.
Management options for stable patients with a β­hCG level below the discriminatory zone and indeterminate US include consultation in the ED or discharge for follow­up in  days for reexamination and repeat β­hCG levels.
SPONTANEOUS ABORTION
The World Health Organization defines spontaneous abortion as loss of pregnancy before  weeks or loss of a fetus weighing <500 grams. Estimates of pregnancies that abort spontaneously range from 20% to 40%. Approximately 75% of spontaneous abortions occur before  weeks of gestation
(Table 98­6).
TABLE 98­6
Spontaneous Abortion Terminology
Terminology Definition
Threatened abortion Pregnancy­related bloody vaginal discharge or frank bleeding during the first half of pregnancy without cervical dilatation
Inevitable abortion Vaginal bleeding and dilatation of the cervix
Incomplete abortion Passage of only parts of the products of conception
More likely to occur between  and  weeks of pregnancy
Complete abortion Passage of all fetal tissue, including trophoblast and all products of conception, before  weeks of conception
Missed abortion Fetal death at <20 weeks without passage of any fetal tissue for  weeks after fetal death
Septic abortion Evidence of infection during any stage of abortion
The most common cause of fetal loss is chromosomal abnormalities. Other associations include advanced maternal age, prior poor obstetric history, concurrent medical disorders, previous abortion, infection (including syphilis and human immunodeficiency virus), and some anatomic abnormalities of the upper genital tract. Exposure to some agents, such as certain anesthetic agents, certain heavy metals, and tobacco, may also contribute to the incidence of abortion.
Bleeding with or without abdominal pain is the most common presenting complaint.
DIAGNOSIS
In addition to the standard medical history, determine the amount of bleeding as pads used per hour to anticipate blood loss, last menstrual period, and past obstetric history. A pelvic examination is needed to define the type of abortion and to determine the amount and site of bleeding, whether the cervix has dilated, and whether any tissue has been passed.
The diagnosis of pregnancy is central to the diagnosis of abortion. Obtain a quantitative serum β­hCG level, CBC to evaluate for blood loss, blood type,
Rh factor and antibody screen, and urinalysis (urinary tract infection has been associated with increased fetal wastage). US can help rule out ectopic pregnancy, aid as a prognostic tool for fetal viability, and diagnose retained products of conception. US studies combined with determinations of β­ hCG levels can be both diagnostic and prognostic. Although a β­hCG of 1500 mIU/mL is a somewhat arbitrary value when evaluating pregnancy, it is still useful when comparing with US findings. Although institution dependent, an IUP should be visible on transvaginal US at this concentration. Table 98­

 describes expected US findings at certain gestational ages and β­hCG values.
TABLE 98­7
Comparison of Gestational Age, β­hCG, and US Findings
Gestational Age β­hCG (mIU/mL) Transvaginal US Findings Transabdominal US Findings
4–5 weeks <1000 Intradecidual sac N/A
 weeks >2000 Yolk sac (± embryo) Gestational sac
 weeks ,000–20,000 Embryo with cardiac activity Yolk sac (± embryo)
 weeks >20,000 Embryonic torso/head Embryo with cardiac activity
Source: Reproduced with permission from Ma OJ, Mateer JR, Reardon RF, Joing SA: Ma & Mateer’s Emergency Ultrasound, 3rd ed. New York: McGraw­Hill, Inc.; 2014;
Table 14­1, p. 400. TREATMENT
Patients with threatened abortion can be discharged safely if follow­up is ensured. Although a low level of activity and even bed rest are sometimes
 advised, there is no proven effectiveness of this practice. Generally speaking, a miscarriage cannot be avoided. Patients should avoid intercourse and tampons to minimize risk of infection.
Patients with a diagnosis of incomplete abortion should have the uterus evacuated. The decision to proceed with medical treatment, such as PO misoprostol, 600 micrograms, or surgical treatment, such as dilatation and curettage, should be made in consultation with the patient and an
 obstetrician.
Patients with a complete abortion, as shown by US and complete passage of products of conception, can be discharged safely, with follow­up ensured.
If there is any doubt, obtain obstetrics consultation for possible dilatation and curettage.
Patients with a nonviable fetus can be either admitted or discharged to be followed up within  week, depending on the comfort level of the patient and physician with this decision. Patients should return immediately if there is heavy bleeding (more than one pad per hour for  hours), pain, or fever.
Pregnant women with vaginal bleeding who are Rh negative should be treated with Rh (D) immunoglobulin (RhoGAM). RhoGAM should be
 administered before discharge, if possible, but it also can be administered within  hours by the primary care physician or obstetrician when the woman presents several days or weeks after vaginal bleeding has begun.
SEPTIC ABORTION
A septic abortion is a spontaneous or other abortion complicated by a pelvic infection. Presenting complaints include fever, abdominal pain, vaginal discharge, vaginal bleeding, and history of recent pregnancy. The most common causes are retained products of conception due to incomplete spontaneous or therapeutic abortion and introduction of either normal or pathologic vaginal bacteria by instrumentation.
Perform a history and physical examination, including a pelvic examination. Obtain a quantitative serum β­hCG level, CBC to evaluate for anemia due to blood loss, blood type, Rh factor and antibody screen, urinalysis, and blood cultures. A US will help identify retained products of conception in the uterus, adnexal masses, and free fluid in the cul­de­sac. Treatment consists of fluid resuscitation, broad­spectrum IV antibiotics, and early obstetric consultation for evacuation of the uterus. Antibiotics, such as ampicillin/sulbactam,  grams IV, or clindamycin, 600 milligrams, plus gentamicin,  to  milligrams/kg IV, should cover both normal vaginal flora and those causing sexually transmitted disease.
GESTATIONAL TROPHOBLASTIC DISEASE
Gestational trophoblastic disease consists of a broad spectrum of conditions ranging from an uncomplicated partial hydatidiform molar pregnancy to
 stage IV choriocarcinoma with cerebral metastases. It is a neoplasm that arises in the trophoblastic cells of the placenta. It complicates  in 1700 pregnancies in North America and is more common in Asian women. The noninvasive form of the disease is the hydatidiform mole, which is either complete or partial. Complete moles are more common, and in this form, there is no actual fetus, whereas in the partial mole, a deformed, nonviable fetus is present. Both moles and invasive forms are composed of trophoblasts that produce β­hCG. Patients with a history of hydatidiform molar pregnancy are at increased risk of future molar pregnancies, with a risk of 1% in subsequent gestations after one molar pregnancy and a risk as high as
23% after two molar gestations.
Symptoms include vaginal bleeding in the first or second trimester (75% to 95% of cases) and hyperemesis (26%). Gestational trophoblastic disease, or molar pregnancies that persist into the second trimester, are associated with preeclampsia. When pregnancy­induced hypertension is seen before  weeks of gestation, consider the possibility of a molar pregnancy. The uterus is excessive in size for gestational age and shows a placenta with many lucent areas interspersed with brighter areas on US study. Because not all molar pregnancies are found on US, all tissue extracted from the uterus on suction curettage or during pelvic examination should be sent for histologic examination. If trophoblastic disease is suspected because of abnormally high β­hCG levels, a uterine size either larger or smaller than expected, and US findings suggestive of the diagnosis, obtain obstetric consultation. Treatment is by suction curettage in the hospital setting because of risk of hemorrhage. β­hCG levels that fail to decrease after evaluation are evidence of persistent or invasive disease necessitating chemotherapy. Metastasis to lung, liver, and brain may occur, but the prognosis for most patients is very good. Trophoblastic embolization, although extremely rare, may occur, with resulting rapid onset of respiratory distress resembling amniotic fluid embolus.
NAUSEA AND VOMITING OF PREGNANCY AND HYPEREMESIS GRAVIDARUM
EPIDEMIOLOGY

Nausea and vomiting of pregnancy is quite common, with these symptoms reported in up to 90% of pregnancies. Severe nausea and vomiting of pregnancy is known as hyperemesis gravidarum and is defined as intractable vomiting with weight loss, volume depletion, and laboratory values
 showing hypokalemia or ketonemia. It occurs in .3% to 3% of all pregnancies. Patients with gestational trophoblastic disease also may present with intractable vomiting for unknown reasons.
CLINICAL FEATURES
Findings on physical examination in nausea and vomiting of pregnancy are usually normal except for signs of volume depletion. Laboratory tests to consider include CBC, serum electrolytes, BUN, creatinine, and urinalysis. The finding of ketonuria is important because it is an early sign of starvation.
However, there is no evidence that ketosis per se is harmful to the fetus. Serial measurements of urinary ketones can be used to determine success of therapy.
The presence of abdominal pain in nausea and vomiting of pregnancy or hyperemesis gravidarum is highly unusual and should suggest another diagnosis. Ruptured ectopic pregnancies occasionally present with nausea and vomiting, as well as diarrhea and abdominal pain.
Gallbladder dilatation and biliary sludge increase in pregnancy, predisposing to stone formation. Cholelithiasis and cholecystitis are more common in pregnant women than in women of comparable age and health status who are not pregnant. Differential diagnosis of vomiting or vomiting with abdominal pain should include cholecystitis, cholelithiasis, gastroenteritis, pancreatitis, appendicitis, hepatitis, peptic ulcer, pyelonephritis, ectopic pregnancy, fatty liver of pregnancy, and the syndrome of hemolysis, elevated liver enzymes, and low platelets (HELLP syndrome).
TREATMENT
Treatment consists of IV fluids containing 5% glucose in either lactated Ringer’s solution or normal saline to replete volume and reverse ketonuria. A number of antiemetic drugs can be used (Table 98­8) for patients who remain nauseated or continue to vomit. Initially, the patient should be given nothing by mouth. Oral fluids should be started after the nausea and vomiting are controlled but before discharge.
TABLE 98­8
Antiemetics
U.S. Food and Drug
Antiemetic Brand Name Administration PO PR IV
Category
Promethazine Phenergan® C .5–25 .5–25 IV extravasation causes tissue injury; milligrams every milligrams .5–25 milligrams IM or IV every  h
 h every  h
Prochlorperazine Compazine® — 5–10 milligrams  milligrams  milligrams over  min every 3­4 h every  h Maximum of  milligrams every  h
Chlorpromazine Thorazine® C 10–25 milligrams 100 milligrams  milligrams in 500 mL NS at 250 mL/h every 4–6 h every 6–8 h
Ondansetron* Zofran® B 4–8 milligrams —  milligrams IV over  min every  h
Metoclopramide Reglan® B  milligrams —  milligrams over 1–2 min every 6–8 h orally every 6–8 h
Maintenance Therapy for Nausea and Vomiting
Doxylamine with Diclegis/Diclectin® A  tablets every — — pyridoxine evening
Vitamin B — —  milligrams — —
 every  h
Ginger — — 500–1000 — — milligrams daily
Diphenhydramine Benadryl® B 25–50 milligrams — — every  h
Abbreviation: NS = normal saline.
*Evidence is insufficient to support or refute the teratogenicity of ondansetron. For that reason, many attempt symptom control with other agents first.
Source: Adapted with permission from Pearlman M, Tintinalli JE (eds): Emergency Care of the Woman. New York: McGraw­Hill, Inc.; 1998. DISPOSITION AND FOLLOW­UP
The patient may be discharged after reversal of ketonuria, correction of electrolyte imbalance, and a successful trial of oral fluids. Discharge with antiemetic medication is usually necessary. There is no clear drug of choice.
Phenothiazines can cause drowsiness or dystonic reactions in some patients. Ondansetron (Zofran®),  milligrams IV or  milligrams PO three times daily, can cause headache, constipation, diarrhea, or light­headedness. It does not cause dystonia. Its chief disadvantage is cost. It is apparently no
 more effective than promethazine. Doxylamine and pyridoxine (Bendectin®), a mainstay of therapy in the past, was discontinued due to fears of teratogenicity, but with new information, it does not represent an increase in fetal risk and has been reintroduced on the North American market as
,39
Diclegis®/Diclectin®.
Admission guidelines include uncertain diagnosis, intractable vomiting, persistent ketone or electrolyte abnormalities after volume repletion, and weight loss of >10% of prepregnancy weight.


