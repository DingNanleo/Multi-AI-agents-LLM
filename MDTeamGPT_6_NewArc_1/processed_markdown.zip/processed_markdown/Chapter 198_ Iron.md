## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 198: Iron
Stephanie H. Hernandez; Lewis S. Nelson
INTRODUCTION
Iron supplements are widely available, particularly in homes with small children and young women. Women of childbearing age with iron available at home are at risk of intentional iron overdose due to the impact of maternal stress. The attractiveness of the brightly colored sugar­coated tablets and
 improper storage of iron make children susceptible to ingestion, serious toxicity, and death. The 1997 federal requirement that all preparations containing >30 milligrams of elemental iron be distributed only in blister packs and the implementation of mandated warning labels from the U.S.
,3
Food and Drug Administration coincided with the reduction of pediatric iron poisonings and deaths. Despite the rescindment of the blister pack
 requirement in 2003, serious iron poisonings in children have remained low.
PHARMACOLOGY
Excess iron in overdose may saturate the body’s mechanisms for iron homeostatis, allowing for unbound (“free”) iron to cause organ toxicity. Due to its reactivity with oxygen, iron is always bound to a carrier molecule under normal circumstances. Carrier molecules include transferrin (serum protein), ferritin (intracellular storage), and iron­containing proteins (hemoglobin, myoglobin, cytochromes, and other enzymes and cofactors). The body cannot directly excrete iron, so regulation of GI iron uptake and limitation of absorption by sloughing of mucosal cells containing surplus iron are the principal mechanisms for maintaining physiologic iron concentrations.
The oral bioavailability of iron depends on the formulation ingested (Table 198­1) along with body iron stores (increased with iron deficiency anemia)
2+ and ingestion with food or fasting (increased in fasting state). The bioavailability of ionic iron preparations is low, about 10% to 15% for ferrous (Fe )
3+ salts and about 5% for ferric (Fe ) salts. Most dietary iron is in the ferric form chelated to a heme moiety. Following ingestion, the ferric ion is separated from heme and reduced to ferrous iron by a brush border ferrireductase. Iron chelated with heme, such as that found in meat, is more readily absorbed than tablets of ionic iron or nonheme iron in plants. Commercially available formulations of iron chelated with amino acids (e.g., glycinate) mimic dietary meat, with bioavailability about twice that of ferrous sulfate.
TABLE 198­1
Iron Formulations and Elemental Iron Composition
Iron Formulation Elemental Iron Composition Typical Dose Size Amount of Elemental Iron
Ionic Ferrous fumarate (PO) 33% 324­milligram tablet 106 milligrams/tablet
Ferrous sulfate (PO) 20% 325­milligram tablet  milligrams/tablet
220 milligrams/5 mL solution .8 milligrams/mL
Ferrous gluconate (PO) 12% 324­milligram tablet  milligrams/tablet
Sodium ferric gluconate (IV) .25% .5 milligrams/mL
Ferric citrate (PO) 21% 1­gram tablet 210 milligrams/tablet

Nonionic Carbonyl iron (PO) 98%  caplet mixture  milligrams/caplet
Chapter 198: Iron, Stephanie H. Hernandez; Lewis S. Nelson 
. Terms of Use * Privacy Policy * Notice * Accessibility
Iron polysaccharide (PO) 46%  capsule mixture 150 milligrams/capsule
Iron dextran (IV)  milligrams/mL
Iron sucrose (IV) 2%  milligrams/mL
Chelated Ferrous bisglycinate (PO) 20% 125­milligram capsule  milligrams/capsule
Iron glycinate (PO) 27% 185­milligram capsule  milligrams/capsule
Ferrous iron is transported into enterocytes of the GI tract, oxidized to ferric iron, which binds to transferrin, and transported from the enterocytes into the circulation throughout the body. The serum total iron­binding capacity assay primarily measures the amount of serum transferrin and is generally two to three times the normal serum iron concentration (50 to 170 micrograms/dL or  to  micromol/L). Iron is stored within the body in the form of ferritin, a large intracellular storage protein that can reversibly bind as many as 4500 molecules of iron. In adults, about .5 to  gram of elemental iron is stored as ferritin and hemosiderin, primarily in the bone marrow, spleen, and liver, and mobilized from these stores in times of iron
 deficiency.
PATHOPHYSIOLOGY

Iron, as a transition metal, is a potent catalyst for the production of oxidants such as free radicals. Through this mechanism, iron is a direct GI tract irritant causing vomiting, diarrhea, abdominal pain, mucosal ulceration, and bleeding soon after a significant ingestion. As the mucosal surface is injured, the regulatory enterocyte barrier is compromised, and free iron passes unimpeded into the blood, becoming systemically available.
Free iron disrupts critical cellular processes and induces acidosis and widespread organ toxicity. In acute iron poisoning, with the appearance of free iron, a multifactorial metabolic acidosis with an elevated lactate appears due to inhibition of oxidative phosphorylation by disruption of the mitochondrial electron transport chain, production of toxic hydroxyl radicals, induction of membrane lipid peroxidation, liberation of hydrogen ions from reduction of ferrous iron, and hypotension. Hepatotoxicity occurs as the portal blood supply delivers a large amount of iron to the liver. In addition, coagulopathy unrelated to hepatotoxicity may occur through inhibition of thrombin formation and the effect of thrombin on fibrinogen.
Myocardial and vascular dysfunction result from vasodilation, negative ionotropic effect, and direct myocardial iron deposition.
TOXICITY
The amount of ingested elemental iron in ionic form correlates with the potential for toxicity (Table 198­2). In general, moderate toxicity occurs at doses of  to  milligrams/kg of elemental iron, and severe toxicity can be expected following ingestion of >60 milligrams/kg of elemental iron. The most commonly prescribed formulation, a ferrous sulfate 325­milligram tablet (20% elemental iron by weight), contains  milligrams of elemental iron, and approximately  tablets would be expected to produce moderate toxicity after an acute ingestion in an average­size
(65­kg) adult. Pediatric multivitamins typically contain less elemental iron per tablet (10 to  milligrams) and thus are associated with less fatality
 compared to adult iron supplements. Ferric chloride poisoning can occur with occupational inhalation, accidental ingestion through mislabeling, and
 suicidal ingestion. Ingestion of commercially available chemical hand warmers, containing  to 120 grams of reduced elemental iron (not an iron
 ,11 salt), may cause corrosive injury of the esophagus and stomach and result in significant iron absorption with potential toxicity.
TABLE 198­2
Predicted Toxicity of Ionic Iron Ingestion
Predicted Clinical Effects Elemental Ionic Iron Dose* Serum Iron Concentration†
Mild GI effects; low risk for systemic toxicity <20 milligrams/kg <300 micrograms/dL (<54 micromol/L)
Significant GI effects: moderate to severe systemic toxicity 20–60 milligrams/kg 300–500 micrograms/dL (54–90 micromol/L)
Severe systemic toxicity and increased morbidity >60 milligrams/kg >500 micrograms/dL (>90 micromol/L)
*Elemental iron dose by history.
†Serum iron concentration obtained within 4–6 h of ingestion; hourly measurement until peak.
Exceptions to the correlation of ingested dose and toxicity include chelated iron and carbonyl iron. Despite their increased iron content, chelated sources of supplemental iron are less toxic than nonchelated iron in overdose, because the ligand sterically limits the iron from participating in redox
 reactions. Similarly, carbonyl iron is a nonionic iron molecule that does not participate in redox reactions, and the limited experience with overdose
 of carbonyl iron suggests a lower incidence of toxicity compared with ingestion of an equivalent amount of ionic iron.
CLINICAL FEATURES
Five stages of clinical toxicity are traditionally described, although in more practical terms, acute iron toxicity can be considered to manifest in two clinical stages: local GI tract toxicity and systemic toxicity.

Stage  is characterized by abdominal pain, vomiting, and diarrhea. Iron is directly irritating and corrosive to the GI tract and typically induces vomiting within the first few hours following ingestion. Vomiting is the clinical sign most consistently associated with acute iron toxicity. Patients with symptoms of gastric irritation may either recover over several hours or progress to systemic toxicity. The absence of GI symptoms within  hours of ingestion essentially excludes a significant iron ingestion.
Stage , or the “latent” stage, occurs in more severe poisonings that progress to systemic toxicity within the 6­ to 24­hour interval following ingestion.
Resolution of GI symptoms may falsely reassure the patient and physician as this is not a truly quiescent phase. In severe poisonings, the latent stage is marked by ongoing clinical illness and progressive systemic deterioration secondary to volume loss and worsening metabolic acidosis. Alternatively, the resolution of GI findings may signal the end of mild poisoning, and in such a circumstance, the results of the patient’s laboratory studies should be normal.
Stage  is characterized by systemic toxicity from iron­induced disruption of cellular metabolism with resultant shock and lactic acidosis. Ironinduced coagulopathy may worsen bleeding and hypovolemia. The coagulopathy may be biphasic, with prolonged prothrombin time and partial thromboplastin time within the first  hours. This initial coagulopathy appears to be reversible with chelation therapy, because free iron initially interferes with the activity of factors in the coagulation cascade. Subsequent coagulopathy is from iron­induced hepatic injury that reduces coagulation factor production. During stage , renal failure, cardiomyopathy, and failure of other critical organ systems may also occur.

Stage , the hepatic stage, develops  to  days following ingestion. It results from iron uptake by the reticuloendothelial system with local lipid peroxidation; it manifests as elevation of aminotransferase levels and may progress to acute fulminant hepatic failure.
Stage  refers to delayed sequelae, including gastric outlet obstruction secondary to the corrosive effects of iron on the pyloric mucosa. Delayed
 sequelae are rare and occur  to  weeks after ingestion.
As noted earlier, patients who develop GI effects that resolve and who continue to look well clinically and have near normal laboratory findings will not develop significant systemic toxicity.
DIAGNOSIS
LABORATORY TESTING
Laboratory tests should include CBC, determination of serum electrolyte levels, renal and liver function studies, coagulation function tests, serum glucose, and serum iron levels, with the understanding that these results are to assess the overall condition of the patient, because iron toxicity is largely a clinical diagnosis.
Arterial blood gas analysis and serum lactate determination are usually unnecessary in mild cases, because determination of serum electrolyte levels
(anion gap evaluation) usually yields all the important information. However, in patients with moderate to severe toxicity or in those with respiratory compromise, arterial blood gas results yield useful information. With moderate to severe ingestions, the blood bank should perform blood typing and screening in anticipation of potential need.
Interpret serum iron levels to assess toxicity and direct management with caution. In general, serum iron levels measured within  to  hours after an acute ingestion correlate with the severity of toxicity (Table 198­2), but low serum iron levels do not exclude toxicity. Serum iron levels may be low because of variable times to peak level following ingestions of different iron preparations, and treatment with deferoxamine can artificially lower serum iron levels. Serum total iron­binding capacity has little value in the assessment of iron­poisoned patients. It becomes falsely elevated in the presence of elevated serum iron levels or deferoxamine, and significant organ damage occurs despite exceeding the serum iron level.
IMAGING

Standard ferrous sulfate tablets and reduced iron are radiopaque and frequently visible on routine radiographs, and this may help guide GI decontamination when present (Figure 198­1). However, many iron preparations are not routinely detected, including pediatric chewable and liquid
 preparations, and absence of radiopaque material on radiographs does not exclude iron ingestion.
FIGURE 198­1. A large number of radiopaque tablets in the left upper quadrant are visible on abdominal radiograph. [Used with permission from the Fellowship in
Medical Toxicology, New York University School of Medicine, New York City Poison Control Center.]
TREATMENT
Iron poisoning is a clinical diagnosis. Signs and symptoms consistent with iron poisoning should guide treatment, rather than serum iron concentrations alone (Figure 198­2). Patients who are asymptomatic on ED arrival, have not ingested a potentially toxic dose, and have normal findings on physical examination can be observed and do not require specific medical treatment. Patients who vomit once or twice from the gastric irritant effects of iron but who are otherwise asymptomatic, hemodynamically stable, and without metabolic acidosis can also be observed and may require no specific treatment.
FIGURE 198­2. Algorithm for clinical management of iron salt ingestion. Fe = iron; mcg = microgram. [Reproduced with permission from Nelson LS, Howland MA,
Lewin NA, et al: Goldfrank’s Toxicologic Emergencies, 11th ed. New York, NY: McGraw­Hill Education; 2019. Figure 45­3, Pg 673.]
Patients with clinical toxicity should first be stabilized with attention to airway, breathing, and circulation, after which GI decontamination and
,16 chelation therapy with deferoxamine may proceed. Antiemetics such as metoclopramide or ondansetron should be used for repetitive vomiting.
Patients with persistent vomiting and abnormal vital signs or other signs of poor perfusion or shock should undergo aggressive fluid resuscitation and treatment with deferoxamine. Coagulopathy should be treated with parenteral vitamin K and/or fresh frozen plasma, as indicated. Significant blood
 loss may require transfusion.
GI DECONTAMINATION
Do not give ipecac syrup, activated charcoal, cathartics, oral sodium bicarbonate, or phosphosoda. Ipecac syrup may obscure the initial
 signs of clinical toxicity and is no more effective at gastric emptying than is iron­induced vomiting. Activated charcoal does not adsorb significant
 amounts of iron, while vomiting charcoal may be aspirated, and its use may complicate endoscopy if that becomes necessary. Orogastric lavage may not be effective if the ingested tablets are large or if several hours have elapsed since ingestion, but it may be useful in rare cases if performed shortly
,18 after large ingestion, prior to significant vomiting, or if a modified­release formulation was ingested. There are no data to support the efficacy of
,17 oral sodium bicarbonate or phosphosoda in forming insoluble iron salts and preventing absorption.
Radiopaque tablets visible on radiography indicate potential for progressive toxicity and can guide decontamination measures (Figure 198­1). Whole­
,19 bowel irrigation with a polyethylene glycol solution may be effective in patients with large iron ingestions. Administration of 250 to 500 mL/h in
 children or  L/h in adults by nasogastric tube may clear the GI tract of iron pills before absorption can occur. Endoscopy can remove large iron loads
,21 or an iron­containing gastric bezoar. Laparoscopic gastrotomy is a rarely used option for removal of an iron­containing gastric bezoar in
 profoundly ill patients when other measures are unsuccessful or impractical.
DEFEROXAMINE
Deferoxamine is a chelating agent derived from Streptomyces pilosus used to treat iron toxicity. Deferoxamine binds free iron, iron from plasma, and iron from inside cells and mitochondria, but not iron bound to organic molecules. Upon binding, it forms the complex ferrioxamine, which is renally excreted. Deferoxamine can be safely administered to children and pregnant women. Although deferoxamine binds only a small amount of iron (9 milligrams of elemental iron for each 100 milligrams of deferoxamine) and thus chelates only a small fraction of the total amount of iron ingested, this
 generally proves clinically effective in restoring cellular function.
Administration of deferoxamine is indicated in the iron­poisoned patient with systemic toxicity, persistent emesis, metabolic
,16 acidosis, progressive toxicity, or a serum iron level predictive of moderate to severe toxicity (Figure 198­2). The manufacturer
 recommends IM administration for all patients not in shock, but most toxicologists advise IV administration rather than IM administration because of
,16 the unreliability of IM absorption and enhanced iron excretion following IV administration.
The initial deferoxamine adult dose is 1000 milligrams (children  milligrams/kg) IV. Begin the infusion slowly, starting at  milligrams/kg per hour to avoid producing a rate­related hypotension. Aggressive volume resuscitation may be required in the volume­depleted, hypotensive, iron­toxic patient who is in need of deferoxamine. Hypotension is not a contraindication to IV deferoxamine administration.
The infusion rate of deferoxamine IV can be titrated to  milligrams/kg per hour as tolerated. The recommended amount of deferoxamine for an acute iron overdose is a total of 360 milligrams/kg or  grams in an adult during the first  hours, typically ordered as 500­milligram infusions over  to
,23
 hours after the initial 1000­milligram dose. Amounts larger than this and/or administered longer than  hours are associated with
  complications, including renal insufficiency or failure and pulmonary toxicity.

As ferrioxamine is excreted, the urine color changes to what is classically called “vin rosé” but is more typically a brown or rusty hue. The disappearance of the “vin rosé” color suggests there is no more free iron available to be complexed with deferoxamine and excreted. False­negative
 results, color­change latency, and difficulty in visualizing a color change can limit the utility of this test.
,16,23
There is uncertainty regarding the duration of deferoxamine therapy. Clinical recovery of the patient is the most important factor guiding the decision to terminate deferoxamine therapy because measured iron levels are artificially depressed by the presence of deferoxamine and urine color change can be unreliable. Continue deferoxamine therapy in patients who continue to exhibit severe iron toxicity after
 hours of treatment, using a decreased rate to avoid the associated risks mentioned earlier.
OTHER THERAPIES

Oral iron chelators—deferiprone and deferasirox—reduce iron absorption when administered simultaneously or within  hour of iron ingestion.
However, there is no evidence of benefit in human overdoses, and oral chelation therapy would theoretically be of use only when taken promptly after the iron ingestion; thus, their use is limited by the time to presentation for treatment and the significant vomiting expected with clinical iron toxicity.
Oral iron chelating agents should not replace IV deferoxamine when chelation is indicated in clinical iron toxicity.
Although hemodialysis and hemofiltration do not remove iron, such treatment may be necessary to remove the deferoxamine–iron complex in
,28,29 patients with renal failure who are unable to excrete the complex in their urine. Severe iron poisoning can be treated with exchange transfusion
 in addition to deferoxamine therapy.
In patients with rapidly rising liver transaminases, coagulopathy, and acute kidney injury, there should be timely assessment for liver transplantation.
Progression to fulminant hepatic failure may be precipitous, and with delay, there is increased risk of clinical deterioration precluding liver
 transplant.
DISPOSITION AND FOLLOW­UP
Patients who have not ingested a potentially toxic amount of iron, who remain asymptomatic (other than transient vomiting from the gastric irritant effects of iron), and who have normal findings on physical and laboratory evaluation for a period of  to  hours can be safely discharged or transferred for appropriate mental health evaluation. Patients who receive deferoxamine therapy should be admitted. The regional poison control center or a medical toxicologist should be contacted for assistance with management.


