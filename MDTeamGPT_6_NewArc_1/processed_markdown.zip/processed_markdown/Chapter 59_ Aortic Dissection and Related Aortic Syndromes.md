## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 59: Aortic Dissection and Related Aortic Syndromes
Gary A. Johnson; Louise A. Prince
INTRODUCTION AND EPIDEMIOLOGY
Acute aortic syndromes encompass a number of life­threatening aortic emergencies. These include aortic dissection, penetrating atherosclerotic ulcer, intramural hematoma, and aortic aneurysmal leakage and ruptured abdominal aortic aneurysm (see Chapter , “Aneurysmal Disease”).
,2
Acute aortic syndromes are uncommon but frequently fatal. The incidence ranges from .9 to .7 cases per 100,000 people per year. The 1­, 5­, and

10­year actuarial survival rates are 92%, 77%, and 57%, respectively, for operative patients. Twenty­two percent of cases are undiagnosed prior to
 death. The most common cardiovascular complication of Marfan’s syndrome is aortic root disease and type A dissection (ascending aorta). The identification of gene mutations associated with Marfan’s syndrome, such as TGFBR2 and FBN1, combined with regular follow­up can reduce fatal
 outcomes.
PATHOPHYSIOLOGY
Acute aortic syndromes occur in the setting of chronic hypertension and other factors that lead to degeneration of the media of the aortic wall.
Bicuspid aortic valve, Marfan’s syndrome, Ehlers­Danlos syndrome, and familial history of aortic dissection all predispose to aortic syndromes. Chronic cocaine or amphetamine use accelerates atherosclerosis and increases the risk for dissection. Prior cardiac surgery is also a risk factor for aortic dissection. All mechanisms involve weakening of the medial layer and increasing intimal wall stress. Response to stress may include aortic dilation, aneurysm formation, development of a penetrating ulcer, intramural hemorrhage, aortic dissection, and aortic rupture.
Aortic dissection occurs after a violation of the intima allows blood to enter the media and dissect between the intimal and adventitial layers. The two most common intimal tear sites are the sinotubular junction at the start of the acending aorta (50% to 65%) and just beyond the left subclavian
 artery (20% to 30%) at the junction between the acending and descending aorta. The dissecting column of blood forms a false lumen and may extend distally (most common), proximally, or in both directions. Blood may dissect and reenter the intima, reestablishing blood flow, and this may falsely suggest to the clinician a spontaneous resolution of the patient’s presenting complaint. Alternatively, the blood may dissect through the adventitia, which nearly always proves rapidly fatal.

Aortic dissection has a bimodal age distribution. The first peak involves younger patients with specific predisposing conditions such as connective
 tissue disorders. The second peak includes those aged >50 years with chronic hypertension and/or ischemic heart disease. Prior aortic dissection is a
 risk factor for recurrent dissection.
Aortic dissections are classified using two separate systems, the Stanford and DeBakey systems. The Stanford classification considers any involvement of the ascending aorta a type A dissection. Stanford type B dissections are restricted to only the descending aorta. DeBakey type  dissections simultaneously involve the ascending aorta, the arch, and the descending aorta. DeBakey type  dissections involve only the ascending aorta, and type  involve only the descending aorta.
An aortic intramural hematoma results from infarction of the aortic media, usually from injury to the vasa vasorum. An intramural hematoma may
 resolve spontaneously or may lead to dissection. Penetrating atherosclerotic ulcer can lead to intramural hematoma, aortic dissection, or
 perforation of the aorta. There appear to be sex­related differences between patients with aortic dissections and intramural hematoma. Intramural
 hematoma affects female individuals in approximately 62% of cases. Aortic dissections in women appear to have a higher age of onset, frequent
,9 inpatient complications, and a higher in­hospital mortality.

CLINICAL FEATURES
Chapter 59: Aortic Dissection and Related Aortic Syndromes, Gary A. Johnson; Louise A. Prince 
. Terms of Use * Privacy Policy * Notice * Accessibility
HISTORY

The site of initial intimal disruption often predicts the initial symptoms. Symptoms may change as the dissection extends along the aorta or involves
  other arteries or organs. Classically, dissection presents with abrupt and severe pain in the chest that radiates to an area between the scapulae and
 may be accompanied by a feeling of impending doom. In a case series of 464 dissections, 60% of patients had anterior chest pain (more common in
Stanford type A); abdominal pain was more common in Stanford type B. Most patients describe the pain as severe or the worst they have ever
  experienced. Sixty­four percent describe sharp pain, and 50% describe tearing or ripping pain. A significant number of patients present without
  chest pain, as much as 40%, as reported in a study from Asia. Syncope occurs almost 10% of the time, which is more common in Stanford type A
 dissections. Twenty­two percent of dissections occur in patients with prior cardiac surgery.
Dissection in or near a carotid artery may present as a classic stroke, and 20% of patients with type A dissection display neurologic findings, which
,13 predicts a poorer prognosis. Interruption of blood supply to the spinal cord may lead to paraplegia. Further distal dissection may present as back, flank, or abdominal pain. A proximal dissection to the aortic root may lead to cardiac tamponade and is generally fatal.
PHYSICAL EXAMINATION

For most patients with aortic dissection, examination findings are relatively normal. An aortic insufficiency murmur may occur (32%), and a pulse
,14 deficit in radial arteries or femoral arteries may be found (15%). A blood pressure difference >20 mm Hg between arms is independently associated
  with aortic dissection ; however, 19% of ED patients without dissection also have this clinical finding. Hypertenstion is common (49%), but
 ,14 hypotension occurs in 18% to 25% of patients, which makes the diagnosis more likely and worsens prognosis. Aneurysmal dilation of the aorta may compress regional structures such as the esophagus, the recurrent laryngeal nerve, or the superior cervical sympathetic ganglion, causing dysphagia, hoarseness, or Horner’s syndrome.
Using retrospective data from the International Registry of Acute Aortic Dissection, three clinical categories (underlying condition, pain quality and
,18 location, and examination findings) were parsed into  features associated with acute aortic dissection (Table 59­1). The clinical features listed in Table 59­1 form the basis of the Aortic Dissetion Detection Risk Score;  point is given for each category with a feature present by history or physical exam, and scores range from  to . Two studies published in 2018 support the strong association of the features listed in Table 59­1 with
,14 acute aortic dissection in symptomatic patients.
TABLE 59­1
Acute Aortic Dissection: Features From the International Registry of Acute Aortic Dissection
Category 1: Underlying Category 2: Pain in Chest, Back, or
Category 3: Abnormal Examination
Condition Abdomen
Marfan’s syndrome Abrupt onset Pulse amplitude difference or systolic blood pressure differential in
Family history of aortic disease Severe in intensity extremities
Aortic valvular disease Ripping or tearing Focal neurologic deficit and chest, back, or abdominal pain
Recent aortic manipulation New murmur of aortic insufficiency and chest, back, or abdominal
Thoracic aortic aneurysm pain
Shock or hypotension
DIAGNOSIS
The large differential diagnosis for the complaint of chest pain plus the many end­organ ischemic manifestations associated with aortic dissections make the diagnosis challenging. The most important differential diagnoses are listed in Table 59­2. TABLE 59­2
Differential Diagnosis of Aortic Dissection
Myocardial infarction or acute coronary syndromes
Pericardial disease
Stroke
Musculoskeletal disease of the extremity
Spinal cord injuries and disorders
Intra­abdominal disorders
Pulmonary disorders, including pulmonary embolus, pneumonia, pleurisy, pneumothorax
Ischemic manifestations may change with time (as the dissection progresses), and this may distract the physician from making the correct diagnosis.
Rupture of the dissection into the true aortic lumen may cause a cessation of symptoms, and the correct diagnosis may then be inappropriately dismissed. History, physical examination, and chest radiography can suggest the diagnosis, but only if one is alert to aortic dissection as one of the diagnostic possibilities in a patient with acute chest, back, or abdominal pain; syncope; or acute focal neurologic signs. Factors associated with misdiagnosis include walk­in mode of admission, normal mediastinal width/aortic contour on chest radiograph, equal extremity pulse amplitudes,
19­21 and nonspecific symptoms.
ECG
It may be difficult to differentiate aortic dissection from acute coronary syndromes on ECG, because both conditions are associated with ECG changes and dissection may limit or obstruct coronary artery blood flow. Abnormal ECG findings include new Q waves or ST­segment elevation in 3% to 4%, ST­
,7,22 ,22 segment depression in 15% to 22%, and nonspecific ST­ and T­wave changes in 41% to 62%. The ECG is normal in only 19% to 31% of patients.
BIOMARKERS

Several potential biomarkers have been investigated for their utility to identify or exclude aortic dissection. D­Dimer is the marker most thoroughly investigated. A meta­analysis of five studies involving 473 subjects with acute aortic dissection and 1084 without acute aortic dissection found a sensitivity of 98% (95% confidence interval, 96% to 99%) and negative likelihood ratio of .05 (95% confidence interval, .03 to .09) using a D­dimer cut
 point of 500 nanograms/mL (1620 nmol/L). The specificity was low at 41% (95% confidence interval, 39% to 44%). Guidelines do not endorse the use
 25­27 of D­dimer as the sole means of excluding aortic dissection, and several authors have cautioned against this practice. The false­negative rate
  using D­dimer is as high as 18% and may be associated with a high platelet count. Despite extensive study, there is no clinical decision rule that can
 be reliably used to identify very­low­risk patients for whom no further diagnostic workup is needed. The Diagnostic Accuracy of the Aortic Dissection
Detection Risk Score Plus D­Dimer for Acute Aortic Syndromes study of 1850 patients clinically suspected of having aortic dissection found that patients
 with none or only one of the features listed in Table 59­1 and a negative D­dimer (<500 nanograms/mL) had a low rate of aortic dissection (0.3%). The
Diagnostic Accuracy of the Aortic Dissection Detection Risk Score Plus D­Dimer for Acute Aortic Syndromes study needs to be externally validated.
IMAGING
A plain chest radiograph may provide important clues for the diagnosis. However, 12% to 37% of patients have no abnormality, and this study should
 not be used to exclude dissection. The most common radiographic abnormality is a widened mediastinum or abnormal aortic contour. Other possible findings include pleural effusion, displacement of aortic intimal calcification, and deviation of the trachea, mainstream bronchi, or esophagus (Figure
59­1).
FIGURE 59­1. Abnormal aortic contour on chest radiography. Frontal and lateral radiographs of the chest in a patient with type B aortic dissection reveal an abnormal aortic contour (arrow). A right pleural effusion is present, and multiple postoperative clips and wires are also seen.
,23,30
CT is the imaging modality of choice for diagnosis of dissection. CT can reliably identify a false lumen (Figure 59­2) and can provide additional details such as the anatomy of the dissection, the location of the dissection flap, extension of the flap into great vessels (Figure 59­3), signs of aortic rupture, and signs of end­organ damage. CT protocols should be both with and without IV contrast. Individual physicians’ practice varies; the utilization of CT imaging of patients for presenting with possible dissection varies between .6% and 12% of patients with chest, back, or abdominal
 pain. Invasive catheter angiography is rarely necessary.
FIGURE 59­2. CT image of a type A aortic dissection. True and false lumens are present in the ascending aorta and descending aorta (descending false lumen at arrow) on noncontrast (left) and contrast (right) images. AF = ascending false lumen; AT = ascending true lumen; DT = descending true lumen.
FIGURE 59­3. Type B dissection into the iliac arteries. Contrast CT image of dissection extending into the iliac arteries (anterior to vertebral body). True and false lumens are visible in both arteries (arrows).

CT may also diagnose intramural hematoma and penetrating atherosclerotic ulcer. Penetrating atherosclerotic ulcer can be difficult to distinguish from large atheromatous plaques (Figure 59­4). CT diagnosis of penetrating atherosclerotic ulcer depends on extension of the ulcer past the intima.
Ulcers often have overhanging edges and focal outpouchings of the aorta itself. Intramural hematoma is often identified by a high­signal mass in the aorta on CT (Figure 59­5). This often appears as a crescent and is best seen on noncontrasted images.
FIGURE 59­4. Noncontrast CT image of a penetrating aortic ulcer in the descending aorta (arrows), demonstrating an outpouched, abnormal contour of the aorta in three sections. [Image used with permission of Dr. Ernest Scalzetti, MD.]
FIGURE 59­5. Contrast CT image of an intramural hematoma (arrows point to the crescent­shaped lesion along the posterior lateral aortic wall) in the descending aorta. [Image used with permission of Dr. Ernest Scalzetti, MD.]
In experienced hands, transesophageal echocardiography may be as sensitive and specific as CT. The procedure generally must be performed under moderate sedation or even general anesthesia. Known esophageal disease is a relative contraindication. Sound transmission is disrupted by air in the trachea or left bronchia, which may make evaluation of the ascending aorta difficult. The accuracy and precision of transesophageal
 echocardiography are highly operator dependent. MRI has been used to evaluate stable patients with suspected aortic disease.
Coronary/pulmonary/aortic CT angiography, or the “triple rule­out,” which is used to differentiate acute coronary artery disease, pulmonary
,33 embolism, and acute aortic dissection, has not been shown to improve diagnostic yield, reduce clinical events, or diminish downstream resource
 use. Therefore, in its current form, it cannot be recommended.
TREATMENT
ANTIHYPERTENSIVES: NEGATIVE INOTROPIC AGENTS
While aortic dissections may cause hypotension that requires fluid or blood product resuscitation, suspected aortic dissection commonly requires antihypertensive treatment. Initial treatment should be a negative inotropic agent in order to lower blood pressure without increasing the shear force on the intimal flap of the aorta. β­Blockade is ideal, and short­acting β­blockers such as esmolol or labetalol are preferred over long­acting β­blockers.
The ideal target blood pressure is undefined by controlled trials and must be tailored to each patient (see Chapter , “Systemic Hypertension” and
Chapter , “Pulmonary Hypertension”). However, a systolic pressure of 120 to 130 mm Hg is a reasonable starting point; some guidelines
,35 suggest a goal of 100 to 120 mm Hg (in the absence of aortic regurgitation).
Esmolol may be given as an initial bolus of .1 to .5 milligram/kg IV over  minute followed by an infusion of .025 to .2 milligram/kg/min. Labetalol
(a β­blocker with limited α­blocking characteristics in a 7:1 ratio) also may be used at an initial dose of  to  milligrams IV with repeat doses of  to
 milligrams every  minutes to desired effect or a maximum dose of 300 milligrams. β­Blocker use has been associated with improved survival in the

International Registry of Acute Aortic Dissection database.
VASODILATORS
Vasodilators may be added for further antihypertensive treatment after successful administration of esmolol or labetelol. IV nicardipine,
 clevidipine, nitroglycerin, or nitroprusside (see Chapters  and 58) are options.
DISPOSITION AND FOLLOW­UP
Rapid referral to a vascular surgeon is mandatory. Emergency open repair remains the treatment of choice for most patients; however, endovascular
38­43 repair is being used more frequently.
Patients with acute aortic syndromes are likely to require admission to an intensive care unit for hemodynamic therapy and careful monitoring. Acute intermural hematomas and penetrating ulcers have an unclear clinical course and natural history. Therefore, the management of patients with these
 disorders remains controversial. Clearly, no patient with an acute aortic syndrome should be discharged without speciality consultation.
SPECIAL CONSIDERATIONS
AORTIC DISSECTION COMPLICATING PREGNANCY
Aortic dissection in pregnancy is rare and usually occurs in the third trimester and postpartum period. Risk factors are bicuspid aortic valve, connective tissue disorders, hypertension, and a family history. Pregnancy increases the risk of dissection in patients with Marfan’s syndrome, complicating .4%
 of pregnancies in women with the syndrome. Simultaneous consultation with obstetrics and cardiovascular surgery is needed if the diagnosis is considered. See Chapter , “Comorbid Disorders in Pregnancy,” for further discussion.


