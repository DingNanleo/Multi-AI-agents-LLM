## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 238: Transfusion Therapy
Clinton J. Coil; Sally A. Santen
INTRODUCTION
Modern transfusion practice uses blood collected using a preservative–anticoagulant combination (usually citrate phosphate dextrose or citrate phosphate dextrose adenine­1). The collected whole blood is tested for transfusion­transmitted diseases and most often separated into specific
 components supplied as standardized preparations termed “units” (Table 238­1). Transfusion in the ED typically is done for acute blood loss and/or
 circulatory shock using packed red blood cells (PRBCs), with increasing interest in using stored whole blood in severely bleeding patients. Coagulation factors derived from human plasma or manufactured with recombinant technology are used to treat hemorrhage associated with a deficiency of one or more factors or to reverse the effect of antithrombotic medications (see Chapter 239, “Thrombotics and Antithrombotics”) (Table 238­2).
TABLE 238­1
Blood Products
Initial Dose Effect
Approximate
Shelf Initial Without Ongoing Loss
Component Volume/Unit Approximate Content/Unit* Life Dose or Destruction of Red
(mL)
Cells or Platelets
Stored whole blood (type O, with low  d for 500 Red cells 35%–38%, platelet count Adult: Raises hemoglobin titer of anti­A and anti­B antibodies CPD and 150,000–200,000/mm3 (150–200 × 109/L),  units concentration used for emergency unmatched  d for approximately  grams/dL coagulation factors approximately 85% transfusions) CPDA­1 (20 grams/L) or hematocrit of predonation levels by 6% in adults
Packed red blood cells 21–42 d 250–350 Red cells 65%–80% Adult: Raises hemoglobin
Plasma 10–20 mL  units concentration approximately  grams/dL
(20 grams/L) or hematocrit by 6% in adults
Platelets (apheresis­collected single­  d 250–300 Platelets 3–6 × 1011  unit Raises platelet count by up donor platelet concentrate) or  to ,000/mm3 (50 × 109/L), mL/kg but less in many cases
Platelets (pooled donor platelet  d 50–60 Platelets 8–9 × 1010  units Raises platelet count by up concentrate, rarely used in the United or  to ,000/mm3 (50 × 109/L),
States) mL/kg but less in many cases
Abbreviations: CPD = citrate phosphate dextrose; CPDA­1 = citrate phosphate dextrose adenine­1. *Unless specifically prepared, most blood­derived products contain small amounts of white blood cells, red blood cells, platelets, and plasma in addition to the
 specific component.
Chapter 238: Transfusion Therapy, Clinton J. Coil; Sally A. Santen 
. Terms of Use * Privacy Policy * Notice * Accessibility
Coagulation Factor Products
Type of Product* Initial Dose Comments and Approved Indications
Fresh frozen plasma  units or  mL/kg Volume 200–250 mL/unit
(FFP)  unit contains about 200–250 units of each individual coagulator factor and 400–500 milligrams of fibrinogen
Initial dose raises most coagulation factor levels approximately 20%
Shelf life:  y frozen and up to  d after thawing
Used for coagulation factor replacement
Cryoprecipitate  unit per 5–10 kg body weight; typically Volume 30–40 mL/unit
 units in an adult Each unit typically contains: factor VIII 80–140 units, fibrinogen 150–250 milligrams, von Willebrand factor 80–100 units, and factor XIII and fibronectin in variable amounts
Initial dose increases fibrinogen 50–100 milligrams/dL (0.5–1.0 gram/L)
Shelf­life:  y frozen and  h thawed
Used for replacement of fibrinogen, factor XIII, factor VIII, or von Willebrand factor
Fibrinogen Dosed to increase fibrinogen level from Each vial contains 900–1300 milligrams of fibrinogen concentrate baseline to >150 milligrams/dL (1.5 Used for acute bleeding episodes in patients with congenital fibrinogen deficiency
(human) grams/L)
RiaSTAP® (CSL If baseline fibrinogen level unknown,
Behring) administer  milligrams/kg
Factor IX complex Dosed according to desired factor IX Contains factors II, IX, and X
Profilnine SD® increase Used in hemophilia B (factor IX deficiency)
(Grifols Biologicals)
Bebulin VH® (Baxter
Healthcare
Corporation)
Prothrombin Dosed in factor IX units according to Contains factors II, VII, IX, and X and may also contain antithrombotic protein C and complex pretreatment INR protein S concentrate Used for urgent reversal of bleeding due to vitamin K antagonist (e.g., warfarin) in
(human) adult patients
Kcentra® or Beriplex®
P/N (CSL Behring)
Octaplex®
(Octapharma)
Anti­inhibitor 50–100 units/kg Contains factors II, IX, and X, mainly nonactivated, and factor VII, mainly in activated coagulant complex form
FEIBA NF® (Baxter) Used in hemophilia A or B patients with inhibitors
Coagulation factor  micrograms/kg Bleeding episodes and perioperative management in hemophilia A or B patients with
VIIa (recombinant) inhibitors
NovoSeven® RT Congenital factor VII deficiency
(Novo Nordisk) Glanzmann’s thrombasthenia with refractoriness to platelet transfusions
Bleeding episodes and perioperative management in adults with acquired hemophilia
*Commercial trade names provided for ease of product identification.
Safe transfusion practice uses informed consent (patient is informed about the risks, benefits, and alternatives to transfusion) and steps to ensure that the correct blood product is delivered to the correct patient. A best practice is to use two individuals to verify the identification of the patient and
 the unit before transfusion. Bar code identification along with verification by one individual is an alternative to two­person verification.
BLOOD TRANSFUSION
STORED WHOLE BLOOD
There is increasing interest in the practice of whole blood transfusion early in the resuscitation of patients with hemorrhagic shock, often before their
,5
ABO group is known. The possible advantage is that whole blood as the initial resuscitation fluid efficiently provides treatment for blood loss, coagulopathy, and platelet hemostatic function to patients losing large volumes of blood. In addition, whole blood transfusion is simpler to administer since all three components (red cells, platelets, and plasma) are in one bag. Whole blood transfusion has been used by the military to treat traumatic
 hemorrhagic shock since the Korean War. Based on this experience, several civilian trauma and EMS systems have started using whole blood transfusion. In response, the American Association of Blood Banks issued standards for whole blood transfusion in Standards for Blood Banks and

Transfusions, 31st edition, effective April , 2018. 
Whole blood transfusion uses either stored or fresh whole blood. Stored whole blood has a shelf life dependent on the anticoagulant used—21 days for citrate phosphate dextrose or  days for citrate phosphate dextrose adenine­1—although the hemostatic function of stored whole blood degrades after  weeks of storage. Fresh whole blood is collected via donation from prescreened donors (“walking blood donors”) immediately before transfusion. Because fresh whole blood does not undergo testing before transfusion, it is used solely by the military for severely bleeding patients when stored blood or component therapy is not available (e.g., resuscitative care initiated in active combat zones). Fresh whole blood is not approved for civilian use by the American Association of Blood Banks or U.S. Food and Drug Administration.
Although transfused whole blood can be matched to the blood type of the recipient patient before use, the most urgent need for whole blood transfusion is in the severely bleeding patient before blood typing (e.g., in the ambulance, helicopter, or ED). It is important to note that while type O is the universal donor for red cells, it is not the universal donor for plasma (see later section “Fresh Frozen Plasma”). As a result, donated units of type O whole blood are tested for levels of anti­A and anti­B antibodies, and units with low titers of anti­A and anti­B antibodies are used in unmatched whole blood transfusion to decrease the risk of hemolytic transfusion reactions. Similar to unmatched PRBCs, men and women over age  years may receive
Rh­positive blood, whereas women of childbearing age should receive Rh­negative blood. When unmatched stored whole blood transfusion is used, obtain a pretransfusion sample to establish the recipient’s blood group as it may be difficult to determine after transfusion. The practice of whole blood transfusion in civilian hospitals and EMS systems is currently limited to a few locations in the United States, but further expansion is anticipated.
PACKED RED BLOOD CELLS

Adult total blood volume is approximately .5 L/m ,  mL/kg, or about  L in a 70­kg person. Although whole blood would seem ideal to replace red cells, the platelets and plasma present are not usually necessary and could be separated and used for directed treatment of patients with thrombocytopenia or coagulopathy, respectively. Therefore, whole blood is most often fractionated to its components for storage and transfusion.
PRBCs are prepared by the centrifugation of whole blood collected with the preservative and anticoagulant solution to remove approximately 80% of
 the plasma (Table 238­1).
Emergency PRBC transfusion is usually performed for acute blood loss or profound anemia to restore intravascular oxygen­carrying capacity. A hemoglobin concentration of  grams/dL (70 grams/L) or greater is adequate to support oxygen delivery in most adults who are hemodynamically stable. Substantial evidence supports that the hemoglobin threshold of  grams/dL (70 grams/L) for PRBC transfusion—termed a restrictive threshold
,10
—is safe and effective. The 2023 AABB International Guidelines for Red Blood Cell Transfusion have modified the 2018 recommendations for
 hospitalized adults slightly. For patients undergoing cardiac surgery, the recommended threshold is .5 grams/dL (75 grams/L). For those with preexisting cardiovascular disease or who are undergoing orthopedic surgery, the recommended transfusion threshold is a hemoglobin
8­10 concentration of  grams/dL (80 grams/L). For those with hematologic and oncologic disorders, the recommended threshold is  grams/dL (70 grams/L). However, when making transfusion decisions, the updated recommendations stress the importance of considering overall clinical context, and alternatives to transfusion, for the individual patient.
For actively bleeding patients, transfusion is based on clinically estimated blood loss rather than hemoglobin levels, because the fall in measured hemoglobin will lag behind the clinical impact of acute blood loss. A loss of about 30% blood volume (1500 mL in an adult) generally produces symptoms and signs, but young, healthy patients can tolerate this degree of loss, especially when treated with crystalloid. However, patients with chronic illness such as underlying anemia, cerebrovascular disease, or cardiac diseases; those with pacemakers; and those on β­blockers or similar medications may not tolerate blood loss. Consider emergency PRBC transfusion for unstable trauma patients based on an inadequate response to an initial 2­L bolus of IV crystalloid (see Chapter , “Approach to Traumatic Shock”). Use the anticipated clinical course to guide the decision to transfuse the patient with acute hemorrhage, with a lower threshold if the source of bleeding cannot be controlled immediately compared to a patient whose acute hemorrhage has stopped.

Use the minimum amount of PRBCs to accomplish the desired clinical outcome. A single PRBC unit will raise the hemoglobin by  gram/dL (10 grams/L) and hematocrit by 3% in adults. In children,  to  mL/kg of PRBCs will raise the hematocrit by 6% to 9% and the
 hemoglobin level by approximately  to  grams/dL (20 to  grams/L).
One unit of PRBCs, approximately 250 mL in volume, is generally transfused over  to  hours in stable patients, with faster infusion rates in patients with hemodynamic instability. Single­unit PRBC transfusions should not exceed  hours to prevent contamination. If a slow transfusion is desired (e.g., in a patient at risk for volume overload), the blood bank should be asked to split a unit so that the first half can be transfused over  hours while the second half waits in the blood bank refrigerator. During standard transfusions, the initial infusion rate is slower over the first  minutes so that if there is a transfusion reaction, the infusion may be stopped.
Type, Screen, and Cross­Match
PRBC transfusion requires matching the recipient’s and donor’s red blood cells according to blood type (ABO and Rh) and screening the recipient’s plasma for antibodies to the minor red blood cell antigens. Screening is done using a mixture of commercially available red blood cells that have all the important minor antigens. If the screen is positive for antibodies, then the recipient’s plasma is cross­matched against the specific PRBC unit intended for transfusion. Blood type can be determined in approximately  minutes, whereas it takes about  to  minutes to perform a serologic crossmatch. If an anti–red blood cell antibody is found in the recipient’s plasma, cross­matching may take longer and require additional blood specimens from the patient.
Type O Rh­negative (universal donor) PRBC may be used in critical circumstances because these transfused red cells do not contain major blood group antigens (A or B). Type O Rh­positive blood may be used if type O Rh­negative is not available, but should be avoided in girls and women of childbearing potential. Approximately 20% of Rh­negative patients transfused with  unit of Rh­positive PRBCs will develop anti­Rh(D) antibodies, creating the risk for hemolytic disease of the newborn with subsequent pregnancies. This is usually clinically inconsequential for men or postmenopausal women.
Treated Red Blood Cells

PRBCs may be further treated for specific clinical applications: leukocyte­reduced PRBCs, irradiated PRBCs, washed PRBCs, and frozen PRBCs.
Leukocyte­reduced PRBCs have 70% to 85% of the white cells removed in order to (1) decrease the occurrence of nonhemolytic febrile reactions due to cytokines from transfused white cells; (2) prevent sensitization to human leukocyte antigen antibodies found on white cells in patients who may be eligible for bone marrow transplantation; and (3) minimize the risk of intracellular virus transmission, such as cytomegalovirus. Irradiation of PRBCs eliminates the capacity of T lymphocytes to proliferate, thereby preventing the donor’s T lymphocytes from reacting to the recipient’s cells and thus reducing the risk for graft­versus­host disease. Irradiated cells are used in transplant patients, neonates, and immunocompromised patients, and with directed donations from relatives of the patient. Washed PRBCs are indicated in patients who have a hypersensitivity to plasma, such as those with immunoglobulin A deficiency or persistent febrile reactions. For rare blood types, red cells may be frozen and saved for up to  years for later use.
MASSIVE TRANSFUSION
Massive transfusion in adults is variously defined as either the replacement of one blood volume (approximately  units of PRBCs) within a 24­hour
 period, replacement of 50% of blood volume within  hours, or ongoing transfusion during a period of rapid bleeding, such as >150 mL/min. If only
PRBCs were used, platelets and coagulation factors lost or consumed would not be replaced, potentially increasing bleeding. Massive transfusion
 protocols using fixed ratios of PRBCs, platelets, and fresh frozen plasma (FFP) are in common use (see Chapter , “Approach to Traumatic Shock”).

The optimal ratio of PRBCs to platelets to FFP is not established. Some protocols include cryoprecipitate, fibrinogen concentrate, coagulation factor

VIIa (recombinant), tranexamic acid, or prothrombin complex concentrate. Although most research on massive transfusion protocols has been in trauma, many institutions use similar strategies for other causes of hemorrhagic shock, such as postpartum hemorrhage or massive GI bleeding.
Draw sufficient specimens early in the course from massive transfusion patients because once the patient has received close to one blood volume of transfused products, new blood specimens will contain so much donor blood that it will confuse further cross­matching of subsequent units.
Hypothermia is a risk during massive transfusion, so blood and crystalloid should be warmed, in addition to instituting warming measures for the patient. Hypocalcemia from the preservative citrate chelating calcium may occur with a massive transfusion.
PLATELET TRANSFUSION
Platelet transfusions are used either prophylactically to prevent bleeding in thrombocytopenia or therapeutically when patients with thrombocytopenia are actively bleeding. One apheresis­collected, single­donor platelet concentrate is the standard product in developed countries
(Table 238­1). Platelets collected from six different donors can be pooled to create one unit for transfusion, but this practice is not recommended
 because this increases the risk of disease transmission and transfusion reaction.

One apheresis single­donor platelet unit will increase the platelet count by up to ,000/mm (50 ×  /L), an amount sufficient to provide prophylaxis or stop spontaneous and minor traumatic bleeding in most situations. Check platelet levels at  and  hours after transfusion completion because the response is variable. Transfused platelets should survive  to  days; failure of platelets to rise appropriately may be due to increased consumption of platelets from an underlying process, active thrombosis due to ongoing hemorrhage, destruction due to platelet antibodies, or sequestration due to hypersplenism.
The decision to transfuse platelets depends on the severity of thrombocytopenia and clinical circumstances. Among the evidence­based guidelines issued by the American Association of Blood Banks in 2015 and by the British Committee for Standards in Hematology in 2016, the indications most
15­17 relevant to emergency medicine are a combination of thrombocytopenia and bleeding or risk of bleeding (Table 238­3). Consult with a transfusion medicine specialist or hematologist if uncertain about platelet transfusion in a specific situation.
TABLE 238­3
General Indications for Platelet Transfusion
Platelet count <5000/mm3 (<5 × 109/L)
Platelet count <10,000/mm3 (<10 × 109/L) for therapy­induced thrombocytopenia (e.g., chemotherapy)
Platelet count <20,000/mm3 (<20 × 109/L) with a coagulation disorder or low­risk procedure (including central line placement)
Platelet count <50,000/mm3 (<50 × 109/L) with active bleeding, lumbar puncture, or major surgery
Platelet count <100,000/mm3 (<100 × 109/L) with neurologic or ophthalmologic surgery, intracranial hemorrhage, or major multisystem trauma
As part of a massive transfusion protocol
Platelets are generally not indicated for ITP, TTP, or HIT, except in the context of ongoing severe bleeding
Abbreviations: HIT = heparin­induced thrombocytopenia; ITP = immune thrombocytopenic purpura; TTP = thrombotic thrombocytopenic purpura.
There are variable recommendations concerning platelet transfusions in patients with nonfunctioning platelets, on antiplatelet medications, or with uremia, von Willebrand’s disease, or hyperglobulinemia. In von Willebrand’s disease, normal platelets may help deliver von Willebrand factor to the bleeding site. Conversely, in uremic patients, the transfused platelets may not function any better than native platelets. Platelets are of no benefit in
 patients with spontaneous cerebral hemorrhage associated with antiplatelet agents.
Relative contraindications to the transfusion of platelets are disorders associated with platelet activation, such as thrombotic thrombocytopenic purpura or heparin­induced thrombocytopenia, in which transfusion may worsen thrombosis. In these conditions, ongoing bleeding or the need to perform procedures may necessitate platelet transfusion in consultation with the appropriate specialist.
Platelet transfusions are usually ABO­type specific because the platelets are bathed in plasma, although a serologic cross­match is usually not done. As a result, patients receiving platelets are subject to many of the same complications described for plasma transfusion. Depending on availability, non– type­specific platelets may sometimes be transfused. This practice is usually avoided in children or patients receiving multiple transfusions because they are at higher risk for complications. Transfusing non–type­specific platelets may also shorten the half­life of the transfused platelets.
As with PRBCs, platelets can be leukocyte reduced or washed. Patients who have had repeated transfusions may become alloimmunized and refractory to platelet transfusion, noted by the lack of expected rise in platelet count after transfusion. Such patients need human leukocyte antigen–matched or cross­matched platelets. Other factors may affect the efficacy of platelet transfusion, including bacterial sepsis in the recipient, antibiotics forming an antigen complex epitope with the platelet, disseminated intravascular coagulation, and splenomegaly.
COAGULATION FACTOR TRANSFUSION
FRESH FROZEN PLASMA

FFP is obtained after the cells are separated from whole blood and then frozen within  hours of collection. FFP takes approximately  to  minutes to thaw, and this process cannot be sped up through artificial heating. Once thawed, FFP can be transfused up to  days later. Trauma centers and other specialty hospitals may keep prethawed units of FFP available.
Each unit of FFP has a volume of 200 to 250 mL and contains approximately  unit of each coagulation factor and  milligrams of fibrinogen per milliliter (Table 238­1). The increase in individual coagulation factors seen after FFP infusion varies with the specific factor. In general,  unit of FFP will increase most coagulation factors by 3% to 5% in a 70­kg adult. For clinically relevant correction of severe coagulation factor deficiencies, a dose of  mL/kg (or  units in a 70­kg adult) is often required (Table 238­1).
Transfused FFP should be ABO type compatible; however, Rh compatibility is unnecessary. It is a misconception that type O plasma is a universal donor, as it is for PRBCs. This is not the case, because type O plasma contains antibodies to A and B blood group antigens. Type AB is the universal donor for FFP, and in emergencies, universal donor FFP can be given minutes after thawing. Because it is hard to maintain a supply of
 type AB plasma, type A plasma can be used for emergencies if the recipient is type B or AB.
FFP is used for bleeding from warfarin­induced overanticoagulation when prothrombin complex concentrate is not available, for replacement of multiple coagulation deficiencies, for deficiency of an individual coagulation factor when a specific replacement is not available, and during massive
 transfusion (Tables 238­4 and 238­5). Other possible indications for FFP include hereditary angioedema if C1 esterase inhibitor is not available

(see Chapter , “Allergy and Anaphylaxis”). FFP is used during plasma exchange for treatment of diseases such as thrombotic thrombocytopenic
 purpura and Guillain­Barré syndrome. FFP is not recommended to reverse anticoagulation from direct oral anticoagulants such as dabigatran,
 rivaroxaban, apixaban, or edoxaban (see Chapter 239, “Thrombotics and Antithrombotics”). There is no evidence to support the use of FFP in
 coagulopathic patients for procedures such as central venous line placement.
TABLE 238­4
General Indications for Fresh Frozen Plasma Transfusion
Reversal of warfarin overanticoagulation when PCC not available
Bleeding with multiple coagulation defects
Correction of coagulation defects for which no specific factor is available
As a component of a massive transfusion protocol
As part of plasma exchange when treating thrombotic microangiopathies or neurologic disorders
Abbreviation: PCC = prothrombin complex concentrate.
Clinically adequate hemostasis is generally present with functional coagulation factor levels 30% to 40% of normal, which corresponds to an INR of about .7; thus, FFP administration to reverse coagulopathy should be restricted to patients with an INR of ≥1.8. 
TABLE 238­5
Replacement Therapy for Congenital Factor Deficiencies
Coagulation Approximate
Replacement Therapy
Factor Incidence* Factor I  per million Fibrinogen concentrate
(fibrinogen) Cryoprecipitate (if fibrinogen concentrate unavailable)
Factor II  per  million PCC
(prothrombin)
Factor V  per million FFP
Factor VII  per 500,000 PCC
Coagulation factor VIIa (recombinant)
Factor VIII†  per 5000–10,000 males Coagulation factor VIII (recombinant or human)
Desmopressin for mild hemophilia von Willebrand’s Up to  per 100 persons Desmopressin disease‡ von Willebrand factor (recombinant) or antihemophilic factor/von Willebrand factor complex (human); cryoprecipitate if either unavailable
Factor IX†  per ,000 males Coagulation factor IX (recombinant or human)
Factor IX complex
Factor X  per million FFP for minor bleeding episodes
PCC for major bleeding
‡  per ,000 Ashkenazi FFP
Factor XI
Jews
 per million in general population
Factor XII  per 1000 No bleeding manifestations; replacement not required
Factor XIII  per million FFP or cryoprecipitate
Abbreviations: FFP = fresh frozen plasma; PCC = prothrombin complex concentrate; vWF = von Willebrand factor.
*Source: van Herrewegen F, Meijers JC, Peters M, van Ommen CH: Clinical practice: the bleeding child. Part II: disorders of secondary hemostasis and fibrinolysis. Eur
J Pediatr 171: 207, 2012. †See Chapter 235, “Hemophilias and von Willebrand’s Disease.”
‡
Factor XI levels correlate poorly with bleeding complications; many patients have low levels but no bleeding complications.
CRYOPRECIPITATE
Cryoprecipitate is the cold­insoluble protein fraction of plasma containing primarily factor VIII and fibrinogen. There is significant variability in volume
 and content of cryoprecipitate units prepared from different centers. With the development of recombinant factor VIII products for use in hemophilia
 and fibrinogen concentrates for use in hypofibrinogenemia, there is a lesser role for cryoprecipitate. Cryoprecipitate may be used in bleeding patients with fibrinogen levels <100 milligrams/dL (<1 gram/L) due to severe liver disease, uremia, disseminated intravascular coagulation, and
,29 dilutional coagulopathy, although there is controversy over dosing and efficacy (Table 238­6). The typical adult dose is  units, administered in two doses, each containing five pooled units.
TABLE 238­6
General Indications for Cryoprecipitate Transfusion
Bleeding with a fibrinogen level of <100 milligrams/dL (<1 gram/L)
Dysfibrinogenemia
Bleeding in some subtypes of von Willebrand’s disease that are unresponsive to desmopressin, and factor VIII concentrates are unavailable
FIBRINOGEN CONCENTRATE (HUMAN)
Fibrinogen concentrate is derived from pooled human plasma and is used to treat bleeding episodes in patients with congenital fibrinogen
 deficiency. Fibrinogen has been investigated for benefit in other hemorrhagic conditions with an observed ability to reduce bleeding and transfusion
 requirements, but without a measurable effect on mortality. The advantages over cryoprecipitate are minimal risk of disease transmission due to viral inactivation, accurate dosing because each vial is assayed for fibrinogen content, a lower volume for infusion, no need for thawing, no requirement of ABO testing and compatibility, and a rapid reconstitution for infusion.

Fibrinogen is dosed according the patient’s baseline fibrinogen level, the target level (in most circumstances >150 milligrams/dL), volume of distribution, and body weight. If the baseline fibrinogen level is unknown, the initial dose is  milligrams/kg. The most common adverse reactions include allergic reactions, fever, chills, nausea, and vomiting.
FACTOR IX COMPLEX (HUMAN)
Factor IX complex is derived from human plasma and primarily contains factors IX, X, and prothrombin. This product is typically used to treat hemophilia B (factor IX deficiency) and has been studied to treat hemorrhage caused by excessive warfarin effect, because this product contains three of the four vitamin K–dependent coagulation factors. Factor IX complex is often identified as three­factor prothrombin complex concentrate to differentiate it from the four­factor prothrombin complex concentrate product.
PROTHROMBIN COMPLEX CONCENTRATE (HUMAN)
Prothrombin complex concentrate is derived from human plasma and contains the four vitamin K–dependent clotting factors: prothrombin and factors VII, IX, and X. During development and introduction into clinical use, this product was usually identified as four­factor prothrombin complex concentrate to differentiate it from factor IX complex, or three­factor prothrombin complex concentrate. Some prothrombin complex concentrate formulations may also contain anticoagulant proteins C and S and antithrombin, as well as heparin.

Prothrombin complex concentrate is approved for urgent reversal of overanticoagulation from vitamin K antagonists (such as warfarin). The prothrombin complex concentrate dose is calculated from pretreatment INR values and administered using factor IX units. Prothrombin complex concentrate can also be used as part of a protocol for reversal of direct oral anticoagulants such as rivaroxaban, apixaban, edoxaban, or dabigatran in
,34 the setting of life­threatening bleeding.
Prothrombin complex concentrate does not require thawing, does not necessitate ABO­compatibility testing, and does not carry the risk of volume overload, all of which can hinder FFP use. Because the effects of prothrombin complex concentrate are transient, vitamin K should usually be coadministered for sustained warfarin reversal. Thrombosis is the major complication of prothrombin complex concentrate and is observed in
 approximately .5% of treated patients, although this incidence is less than in similar patients treated with FFP.
ANTI­INHIBITOR COAGULANT COMPLEX
Anti­inhibitor coagulant complex is derived from human plasma and contains the four vitamin K–dependent factors: factors II, IX, and X (mainly in nonactivated form) and factor VII (mainly in activated form). This product is commonly known as FEIBA, an abbreviation for factor VIII inhibitor bypassing activity, and has also been termed activated prothrombin complex concentrate. Anti­inhibitor coagulant complex is approved for use in
 hemophilic patients with inhibitors and has been studied for reversal of direct oral anticoagulants and for treatment of bleeding in acquired
  hemophilia. The risk of adverse thromboembolic complications is low in patients with congenital hemophilia but higher in other populations.
COAGULATION FACTOR VIIa (RECOMBINANT)
Coagulation factor VIIa (recombinant) is approved for use in the treatment of bleeding in hemophilia A and B patients who have developed inhibitor antibodies to factors VIII or IX, respectively. Other uses for this agent have been investigated, such as acquired hemophilia, coagulation support in liver
38­40 failure, multisystem trauma, intracranial hemorrhage, and postpartum bleeding. The major drawback to this product is risk of thrombosis (up to
4% in patients with acquired hemophilia).
COMPLICATIONS OF BLOOD TRANSFUSIONS
,41
Up to 20% of all transfusions may result in some type of adverse reaction. Most reactions are minor; serious reactions are uncommon, and life­
 threatening ones are rare (Table 238­7). In critically ill patients, transfusion reactions may be difficult to identify; therefore, watch for unexpected changes in patient status during a transfusion. Two important first steps in any confirmed or suspected transfusion reaction are to (1)
 immediately stop the transfusion and (2) contact the blood bank that issued the transfusion product. The blood bank physician is an important resource for managing the suspected transfusion reaction.
TABLE 238­7
Transfusion Reactions
Reaction
Signs and Symptoms Management Evaluation
Type
Acute Fever, chills, low back pain, Immediately stop transfusion. Retype and repeat cross­match.
intravascular flushing, dyspnea, tachycardia, IV hydration to maintain diuresis; diuretics Direct and indirect Coombs test.
hemolytic shock, hemoglobinuria may be necessary. CBC, creatinine, prothrombin time, activated partial reaction Cardiorespiratory support as indicated. thromboplastin time.
Haptoglobin, indirect bilirubin, lactate dehydrogenase, plasma free hemoglobin.
Urine for hemoglobin.
Delayed Often have low­grade fever but Usually presents days to weeks after Hemolytic workup as above to investigate the extravascular may be entirely asymptomatic transfusion. possibility of intravascular hemolysis.
hemolytic Rarely causes clinical instability.
reaction
Febrile Fever, chills Stop transfusion. Hemolytic workup as above because may not be nonhemolytic Initially manage as in intravascular hemolytic able to initially distinguish febrile from hemolytic transfusion reaction (above) because cannot initially transfusion reactions.
reaction distinguish between the two.
Can treat fever and chills with acetaminophen.
Usually mild but can be life threatening in patients with tenuous cardiopulmonary status.
Consider infectious workup.
Premedication with acetaminophen can mask this reaction.
Allergic Mild: urticaria, pruritus Stop transfusion. For mild symptoms that resolve with reaction Severe: dyspnea, If mild, reaction can be treated with diphenhydramine, no further workup is necessary, bronchospasm, hypotension, diphenhydramine; if symptoms resolve, can although blood bank should be notified.
tachycardia, shock restart transfusion. For severe reaction, do hemolytic workup as above
If severe, may require cardiopulmonary because initially may be indistinguishable from a support; do not restart transfusion. hemolytic reaction.
A common error in management of a confirmed or possible transfusion reaction is to abandon all transfusion. Typically, transfusion reactions, such as hemolytic reactions or transfusion­related acute lung injury, are due to the interaction between a particular unit and a particular patient. Even patients with severe reactions can safely receive future blood products if they are appropriately matched to the patient. One of the first steps in management of
 a transfusion reaction is to draw a new specimen to retype and cross­match new units so that transfusion can resume as soon as possible.

Premedication with acetaminophen and/or diphenhydramine is done to prevent febrile and/or allergic transfusion reactions ; however, the effects
,45 are limited, and routine prophylactic premedication is not recommended in patients without prior reactions. However, premedication may be used for patients with previous febrile or allergic transfusion reactions.
HEMOLYTIC TRANSFUSION REACTIONS
,46,47
Hemolytic transfusion reactions occur when the recipient’s antibodies recognize and induce hemolysis of the donor’s red blood cells. The reaction is usually immediate when antibodies already exist as anti­A or anti­B immunoglobulin M antibodies or immunoglobulin G antibodies in very high titer. Reactions can be delayed when there is an amnestic response to a transfused red blood cell antigen to which the recipient has been
,10 previously sensitized. Immediate transfusion reactions caused by ABO incompatibility are usually the result of technical errors made during the
 collection of blood, pretransfusion testing, or patient identification, and are responsible for the majority of transfusion fatalities.
With acute hemolytic reaction, most of the transfused cells are destroyed, which may result in activation of the coagulation system, disseminated intravascular coagulation, and release of anaphylatoxins and other vasoactive amines. Clinical features of an acute hemolytic reaction include back pain, pain at the site of the transfusion, headache, alteration of vital signs (fever, hypotension, dyspnea, tachycardia), chills, bronchospasm, pulmonary edema, bleeding due to developing coagulopathy, and evidence of new or worsening renal failure.
Ongoing transfusion should be stopped immediately on first indication of potential problems. While laboratory confirmation is being performed, the sequelae of hemolysis are treated supportively. Check renal function, electrolytes, and coagulation status. Maintain renal blood flow and urine output with fluids, mannitol, and furosemide, as needed. Treat circulatory shock with IV infusions and vasopressors to support blood pressure.
The remaining donor blood should be sent, along with a posttransfusion blood specimen from the recipient, to the blood bank. The blood typing and cross­match are repeated, the patient’s serum is tested for blood group alloantibodies, and the donor’s plasma is tested for the presence of antibodies that react with the patient’s blood. With intravascular hemolytic transfusion reactions, serum haptoglobin will be decreased, serum lactate dehydrogenase will be elevated, and a direct antigen (Coombs) test usually will be positive. The blood bank will be able to test the blood, review records, confirm blood types, and determine if the patient’s syndrome is from a transfusion reaction.
Extravascular delayed hemolytic reactions occur in approximately  per 1000 to 6000 PRBC units transfused. Hemolysis most commonly occurs in the
,10 spleen and occasionally in liver and bone marrow. This type of reaction is less serious and rarely fatal. It may be identified by a positive Coombs test, elevated unconjugated (indirect) bilirubin level, and less than expected increase in hemoglobin from the transfusion.
FEBRILE NONHEMOLYTIC TRANSFUSION REACTIONS
,10,46,47
Febrile transfusion reactions are characterized by fever during or within  hours of a blood transfusion. Febrile reactions occur in <0.5% of FFP transfusions, <1% of red blood cell transfusions, and ≤5% of platelet transfusions. ,48 Febrile transfusion reactions are more common in patients who have been exposed to foreign blood antigens, such as multiparous women or multiply transfused patients. Febrile transfusion reactions result from a combination of recipient antibody against donor leukocytes and the release of cytokines that are produced during storage. Clinical presentation can range from a mild elevation in temperature to a high fever along with rigors, headache, myalgias, tachycardia, dyspnea, and chest pain. A severe febrile reaction may be difficult to initially differentiate from the more serious hemolytic transfusion reaction or sepsis.
For a febrile reaction during a patient’s first­time transfusion, or in any severe reaction, the transfusion should be stopped and the product returned to the blood bank for testing. Laboratory investigation similar to that done for possible hemolytic transfusion is done, and blood cultures should be obtained. The febrile transfusion reaction is usually self­limited and will respond to antipyretics. A mild fever in a patient who has been transfused before is usually not serious. In most cases, the transfusion can be restarted after consultation with the blood bank physician. For patients with recurrent febrile reactions, the use of leukocyte­reduced blood products and pretreatment with antipyretics may be helpful.
ALLERGIC TRANSFUSION REACTIONS
,10,46,47
Allergic transfusion reactions typically manifest with urticaria and pruritus during the infusion. A small percentage of patients will have more severe reactions, such as bronchospasm, wheezing, and anaphylaxis. These reactions are caused by an immune response to transfused plasma
 proteins. The incidence of allergic transfusion reactions varies widely.
Antihistamine therapy usually will control urticaria and pruritus. The transfusion should be stopped, but can usually be restarted after evaluation. For anaphylaxis with severe symptoms, the transfusion should be stopped and treatment with epinephrine, steroids, H blockers, and bronchodilators
 begun. Patients with immunoglobulin A deficiency may experience severe anaphylactic reactions in response to exposure from immunoglobulin A in donor products. Washing the plasma from the red blood cells minimizes this type of reaction.
INFECTIOUS COMPLICATIONS
Improved blood donor screening, serologic testing, safer handling of blood products, and viral inactivation of blood products have reduced the risk of
50­53 infection from transfusion. Despite screening donor blood for antibodies to the most concerning viral agents, there is still a small risk of viral transmission (Table 238­8). Most cases of transmission are thought to occur during the window period between infection and antibody production in the donor. This window can be reduced by antigen testing of donated blood for known viral antigens. In the United States, blood is tested for syphilis,
 hepatitis B and C, human immunodeficiency virus, human T­cell lymphotropic virus, West Nile virus, Chagas disease, and Zika virus.
TABLE 238­8
Approximate Risk of Infection From Blood Product Transfusion
Etiology Estimated Frequency: One Infection per Number of Units Transfused
HIV­1  per  million
Human T­cell lymphotropic virus types  and   per 640,000
Hepatitis B  per million
Hepatitis C  per 100 million
Parvovirus B19  per ,000
Abbreviation: HIV = human immunodeficiency virus.
Prevalence for cytomegalovirus antibodies in the general population is between 50% and 80%; therefore, a transfusable unit is not tested routinely for cytomegalovirus unless the recipient is seronegative and either pregnant, a potential or present transplant candidate, immunocompromised, or a
 premature infant. Leukocyte­reduced blood components further decrease the risk of cytomegalovirus transmission to susceptible populations because most of the virus resides in the leukocytes.
49­51
Other infections transmitted by blood transfusion include West Nile virus, variant Creutzfeldt­Jakob disease, babesiosis, and dengue. Additionally, blood can become contaminated with bacteria during storage or processing. Transfusion­associated bacterial infection was more commonly reported
 with platelet concentrates than PRBC or FFP. Evaluation of a possible septic reaction involves obtaining blood cultures from the patient and
,47 examination of material from the blood container by Gram stain with cultures of specimens from the container and the administration set.
TRANSFUSION­RELATED ACUTE LUNG INJURY
Transfusion­related acute lung injury is an uncommon but life­threatening complication of transfusion characterized by the development of acute respiratory distress associated with noncardiogenic pulmonary edema occurring within  to  hours after receiving a blood transfusion. Transfusionrelated acute lung injury is due to antileukocyte antibodies in the donor product that produce polymorphonuclear leukocyte degranulation within the
 lung. Transfusion­related acute lung injury is more common after plasma transfusion than red blood cell transfusion. Mitigation strategies with
 blood donor screening have been partially successful in reducing the risk of transfusion­related acute lung injury. Transfusion­related acute lung injury is self­limiting and generally resolves spontaneously with only supportive care, although severe, fatal cases can occur. Because the pulmonary edema is noncardiogenic, use care to distinguish transfusion­related acute lung injury from volume overload and avoid aggressive diuresis, which can cause rapid deterioration.
TRANSFUSION­ASSOCIATED CIRCULATORY OVERLOAD
Transfusion of blood products can cause rapid volume expansion when compared to similar volumes of crystalloid fluids, leading to transfusion­
 associated cardiovascular overload. Patients with limited cardiovascular reserve, such as those with severe chronic compensated anemia and the elderly, are at the highest risk. Clinical features include dyspnea, hypoxia, and pulmonary edema. Recognize the potential for volume overload so that blood can be transfused slowly, the patient can be monitored carefully, and treatment with diuretics can be initiated when necessary. The usual rate of
PRBC or FFP transfusion is  to  mL/kg per h, but it can be slowed to  mL/kg per h in more delicate patients. Blood product units may also be split, as described earlier.
ELECTROLYTE IMBALANCE
Large­volume transfusions may uncommonly cause hypocalcemia, hypokalemia, or hyperkalemia. The anticoagulant citrate is a component of many blood preservatives and chelates calcium, but the effect of infused citrate is clinically insignificant because patients with normal hepatic function metabolize the citrate to bicarbonate. Rarely with massive transfusions, hepatic metabolism is overwhelmed, and hypocalcemia can develop and/or
 the excess bicarbonate generated causes alkalemia, driving potassium into the cells and causing hypokalemia. The potassium content in stored blood products increases during storage, and uncommonly, patients with renal insufficiency or neonates can develop hyperkalemia from transfusion.


