## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 63: Hemoptysis
Troy Christian Sims
INTRODUCTION AND EPIDEMIOLOGY
Hemoptysis is the expectoration of blood. Severity ranges from mild to severe, and it can be difficult to stop. The challenge is to stabilize the patient while simultaneously determining the source and providing treatment. Most cases of hemoptysis are minor and resolve spontaneously; predicting which individual will develop massive, large­volume bleeding is difficult. Determining the cause and treatment of hemoptysis requires a
 multidisciplinary approach.
Assessing the amount of expectorated blood is difficult; patients may either exaggerate or be unable to quantify the amount. The definition of
,3 massive hemoptysis varies, with reported ranges from 100 mL per  hours to >1000 mL per  hours, and a midpoint value of 600 mL per 
  hours accepted by many. However, because even small volumes of blood can cause asphyxiation, any hemoptysis requires prompt attention.
Morbidity and mortality depend on the rate of bleeding, the ability of the patient to clear the blood, and the presence of underlying lung disease, which potentiates the effects of blood in the airways. We define “minor” hemoptysis as self­limited, small­volume expectoration of blood in a patient with no comorbid lung disease, normal/stable oxygenation and ventilation, normal vital signs, and no risk factors for continued bleeding.
PATHOPHYSIOLOGY
Hemoptysis results from disruption of blood vessels within the walls of the airways, from trachea to bronchi, bronchioles, and the lung parenchyma
(Table 63­1). The pulmonary arteries account for 99% of the blood flow to the lungs but are a low­pressure system involved in gas exchange and rarely the source of massive hemoptysis. The bronchial arteries accounts for only 1% of the blood flow to the lungs but 90% of the cases of hemoptysis
 because it is a high­pressure system. Bronchial arteries typically branch off the thoracic aorta at thoracic vertebrae levels  and  and are responsible for supplying oxygen and nutrients. Approximately one third of the time, they are ectopic and originate from other parts of the aorta. Extensive
 anastomoses occur between the bronchial and pulmonary arteries, producing a physiologic right­to­left shunt composing 5% of cardiac output.
TABLE 63­1
Causes of Hemoptysis
Infectious
Acute bronchitis
Tuberculosis
Fungal (aspergilloma)
Parasitic (paragonimiasis, echinococcus, schistosomiasis)
Structural
Bronchiectasis (cystic fibrosis, organizing pneumonia, chronic bronchitis)
Tracheoarterial fistula (tracheostomy)
Aortobronchial fistula (aortic aneurysm erosion)
Vasculitides
Goodpasture’s syndrome (also known as antiglomerular basement membrane disease)
Granulomatosis with polyangiitis (formerly Wegener’s granulomatosis)
Systemic lupus erythematosus (lupus pneumonitis)

Behçet’s disease (Hughes­Stovin syndrome)
Chapter 63: Hemoptysis, Troy Christian Sims 
Osler­Weber­Rendu disease (telangiectasias and arteriovenous malformations)
. Terms of Use * Privacy Policy * Notice * Accessibility
Takayasu arteritis
Cardiopulmonary
Pulmonary embolism
Pulmonary hypertension
Mitral stenosis
Congestive heart failure
Obstructive sleep apnea
Congenital heart disease
Neoplastic
Bronchogenic carcinoma
Bronchial adenoma
Iatrogenic
Lung biopsy
Pulmonary artery catheter injury (Swan­Ganz)
Bevacizumab treatment
Traumatic
Ruptured bronchus from deceleration injury
Lung contusion from blunt injury
Penetrating trauma
Miscellaneous
Nitrogen dioxide inhalation (ice arenas)
Cocaine inhalation
Catamenial (pulmonary endometriosis)
Dieulafoy’s disease
In general, hemoptysis develops from either airway, parenchymal, or cardiovascular processes. For example, coughing in the setting of transient airway inflammation (e.g., acute bronchitis) can lead to minor bleeding in otherwise healthy lungs. However, the most common causes of potentially
 massive hemoptysis are parenchymal in origin, such as tuberculosis, mycetoma, neoplasm, and bronchiectasis.
In chronic inflammatory states (e.g., chronic obstructive pulmonary disease), the bronchial arteries proliferate to enhance the delivery of blood to the alveoli, and this neoangiogenesis creates thin­walled, fragile vessels prone to rupture. In addition, chronic disease states can lead to bronchiectasis
(chronic bronchial wall inflammation), resulting in destruction of the cartilaginous support predisposing blood vessels to rupture. In the case of infection (e.g., Aspergillus and tuberculosis), there can be necrotic destruction of tissue resulting in cavitary lesions. Neoangiogenesis can occur in the
 cavity walls and bridge them. A Rasmussen’s aneurysm is a false aneurysm of dilated blood vessels crossing the wall of a tuberculosis cavity.
Neoplasms are protean and extensive, affecting airways and lung parenchyma while promoting neoangiogenesis. In particular, squamous cell
 carcinoma accounts for a large number of cases of massive hemoptysis.
Cardiopulmonary processes (e.g., pulmonary embolism and pulmonary hypertension) compromise the pulmonary artery blood flow, causing compensatory increased bronchial artery blood flow via dilation and hypertrophy at the anastomotic level and resulting in hemoptysis within the alveoli.
Bleeding from small vessels at the anastomotic level can be indolent or massive and may affect foci or be diffuse. Osler­Weber­Rendu disease manifests in friable telangiectasias comprised of pulmonary vessel arteriovenous malformations in the lungs as well as other organs, including the skin and mucous membranes.
Vasculitis and collagen vascular diseases such as Goodpasture’s syndrome and granulomatosis with polyangiitis (formerly Wegener’s granulomatosis)
 damage the lung parenchyma, predisposing to alveolar hemorrhage. Anemia can result from chronic alveolar hemorrhage.
Traumatic causes of hemoptysis include deceleration injuries and penetrating trauma leading to disruption of the tracheobronchial tree. Iatrogenic causes include direct arterial injury by pulmonary artery catheterization or biopsy of lung tissue during bronchoscopy. Biopsy of a carcinoid tumor can
 be associated with impressive hemoptysis.
Hemoptysis secondary to fistulae between the airways and an aortic aneurysm can precipitate catastrophic hemoptysis. Tracheoinnominate fistulae result from erosion of a tracheostomy into the innominate artery that courses posterior to the upper sternum.

Historically, the cause of hemoptysis in roughly 30% of the cases cannot be determined, and these cases are considered cryptogenic. Advances in CT, specifically multidetector CT, have led to a decrease in cryptogenic cases.
CLINICAL FEATURES
First, identify whether the condition is truly hemoptysis and exclude hematemesis and epistaxis. Upper GI bleeding is identified by a history of dark stools, nausea, or abdominal pain and a positive stool guaiac test. Epistaxis can be identified on examination. Expectorated blood is bright red if the source is the upper airway or lungs.
HISTORY
If hemoptysis resolves prior to ED evaluation, history is then paramount.
Patients give an accurate history regarding the source of bleeding about half the time. Ask about risk factors for hemoptysis, such as smoking, thromboembolic disease, connective tissue disease, and vasculitis. Tuberculosis is a leading cause of hemoptysis worldwide, so ask about a history of emigration or travel from a high­prevalence area including Africa, innercity New York, the Middle East, and Southeast Asia. Hematuria or renal insufficiency could suggest Goodpasture’s syndrome or granulomatosis with polyangiitis, which is also associated with saddle nose deformity from septal perforation. The lung fluke, Paragonimus species, infects humans after ingestion of infected crab and crayfish, leading to hemoptysis in chronic infection. The tapeworm, Echinococcosis species, is associated with hydatid cysts within the lungs. Cyclical hemoptysis coordinating with a woman’s menstrual cycle could indicate a catamenial source from pulmonary endometriosis.
Cocaine and heroin inhalation and nitrogen dioxide exposure in indoor ice arenas can trigger diffuse alveolar hemorrhage. Finally, ask about use of anticoagulants and recent procedures such as Swan­Ganz catheter insertion and bronchoscopy.
PHYSICAL EXAMINATION
Examine the sputum to see if it is blood­streaked or contains clots of blood. Patients often bring a sample of expectorated sputum to the ED, which helps assessment. Look for signs suggestive of massive hemoptysis or underlying lung disease, such as tachypnea, tachycardia, hypotension, labored respirations, and hypoxemia.
If airway, breathing, and circulation are adequate, focus on the physical exam. Evaluate the nares and posterior pharynx for evidence of epistaxis. Next, assess airway patency and potential difficulty of intubation. Auscultate the lungs for any wheezing suggesting airway inflammation or focally reduced breath sounds indicating a location of bleeding. Occasionally, crackles may be present, suggesting diffuse alveolar hemorrhage or heart failure. On the cardiac exam, auscultate for murmurs of valvular disease. Check for telangiectasia and petechiae on the skin exam.
DIAGNOSIS
Most patients with minor hemoptysis need no specific tests unless on anticoagulation medication. For patients with massive or recurring hemoptysis, obtain a metabolic profile, renal function tests, CBC, coagulation studies, and urinalysis. Baseline hemoglobin concentration may be falsely normal in acute, rapid bleeding as equilibration may not occur for  hours. Thrombocytopenia and coagulopathy increase recurrence risk and morbidity from hemoptysis. Urinalysis and renal function tests help in developing the differential diagnosis and can identify those at risk for contrast nephropathy since multidetector CT is often indicated.
IMAGING

Chest radiography is the initial imaging modality, yielding a diagnosis up to 50% of the time ; in massive hemoptysis, the radiograph is rarely normal.
Diffuse alveolar hemorrhage manifests as scattered alveolar infiltrates on chest radiograph, whereas focal alveolar hemorrhage, infiltrates, masses, and cavitation are potential sources of hemoptysis.
High­resolution CT delineates abnormal bronchial and nonbronchial arteries using reformatted images and limits scan time and respiratory motion
 artifact. Multidetector CT can be performed during a single breath hold using a 16­detector row or greater scanner. It can also identify bleeding from a pseudoaneurysm as in Rasmussen’s aneurysm or from an anomalous vessel as in Dieulafoy’s disease, a tortuous dysplastic artery within the
 submucosa. Bronchial arteries are the main source of bleeding amenable to treatment and are almost always detected on multidetector CT. Although
CT angiography has been preferred for diagnosing pulmonary embolism, multidetector CT is preferred in evaluating massive hemoptysis.
TREATMENT: MILD HEMOPTYSIS
Hemoptysis creates anxiety in the patient and family members, so the goal is to identify the cause, reassure those with minor features and no threat of imminent harm, and provide an appropriate ED disposition. The amount of blood expectorated, respiratory status, and risk factors for continued bleeding dictate the disposition. Assess patients with mild hemoptysis as described in Figure 63­1. FIGURE 63­1. Diagnosis and management of minor hemoptysis. CXR = chest radiograph; FU = follow­up; PCP = primary care physician; UA = urinalysis.
DISPOSITION AND FOLLOW­UP
Most cases of hemoptysis are mild and self­limited. For mild hemoptysis, arrange follow­up with a primary care physician, otolaryngologist, or pulmonologist. Choose a pulmonologist if suspecting lung cancer or lung structural disease, and treat acute bronchitis with appropriate antibiotics.
TREATMENT: SEVERE HEMOPTYSIS
Massive hemoptysis requires airway control, and consultation with interventional radiology (Figure 63­2) for consideration of bronchial artery embolization and with cardiothoracic surgery or pulmonology for emergent bronchoscopy. Recent studies suggest that both multidetector CT and
,12 bronchoscopy provide the best outcomes in treating massive hemoptysis, with most recommending multidetector CT prior to bronchoscopy.
FIGURE 63­2. Algorithm for massive hemoptysis. Determine whether patient is stable based on history provided by patient, rate of ongoing bleeding, ability of patient to clear the blood, and comorbidities. BAE = bronchial artery embolization; CT surgery = cardiothoracic surgery; CXR = chest radiograph; ICU = intensive care unit; IR = interventional radiology; MDCT = multidetector computed tomography.
AIRWAY CONTROL
In patients with more severe bleeding, assessing and ensuring the airway patency and ongoing oxygenation are key. If the patient has a tracheostomy, look for a trachea­innominate fistula; control this with direct digital pressure on the anterior portion of the trachea against the posterior aspect of the sternum using the tracheostomy as the point of access. If the patient does not have a tracheostomy and requires airway control, proceed immediately
 with rapid sequence intubation, using a larger­diameter endotracheal tube to allow for bronchoscopy. Once intubation is successful, place the patient so the affected lung is in a dependent position to prevent spilling of blood into the unaffected side. If bleeding is uncontrollable, you may preferentially intubate the main bronchus of the unaffected lung. Alternatively, to stop bleeding, some use a Fogarty catheter (14F/100 cm) to
 tamponade the bronchus of the affected lung. The latter can be accomplished by passing the Fogarty catheter adjacent to the endotracheal tube once the patient is intubated (Figure 63­3). If attempts at intubation fail, cricothyrotomy is an option.
FIGURE 63­3. These are examples of techniques to control bleeding from the left lung. A. Selective right main bronchus intubation for left­sided massive hemoptysis. B. Using Fogarty catheter to direct control of hemoptysis coming from affected lung. The same techniques are used to control bleeding from the right lung. [Adapted with permission from Lordan JL, Gascoigne A, Corris PA. The pulmonary physician in critical care. Illustrative case 7:
Assessment and management of massive haemoptysis. Thorax 58: 814, 2003. Copyright BMJ Publishing Group.]
Once the airway is secured, restore volume with crystalloid and transfusion of blood products to correct for coagulopathy as indicated.
BRONCHOSCOPY
Urgent bronchoscopy can identify the origin of bleeding and provide stabilizing treatment. Bronchoscopy is possible in the ED, usually by a consultant with a tenuous patient. Awake flexible, fiberoptic bronchoscopy provides visualization of the more peripheral and upper lobes but does not provide optimal suctioning and does not allow for local treatment. Rigid bronchoscopy usually requires general anesthesia but is possible with deep sedation; it allows for improved airway control. Rigid bronchoscopy cannot fully view the upper lobes and peripheral lesions, but it offers greater suctioning ability than fiberoptic bronchoscopy and can provide treatment, such as the passage of Fogarty balloon catheters for tamponade of bleeding, epinephrine instillation, and ice water lavage. After rigid bronchoscopy, a flexible bronchoscope through the lumen of a rigid bronchoscope allows for more detailed inspection. However, massive bleeding impairs visualization during bronchoscopy, compromising both diagnostic ability and treatment.
DEFINITIVE BLEEDING CONTROL
Historically, surgery was the treatment of choice if bronchoscopic interventions failed, but now it is reserved for massive hemoptysis resulting from specific conditions including iatrogenic pulmonary artery injury, thoracic trauma, or bleeding from a tracheoinnominate artery fistula at a
,13­15 tracheostomy site. Bronchial artery embolization followed by bronchoscopy, if necessary, is considered the initial and most effective treatment of
,16,17 massive and recurrent hemoptysis. Risks of bronchial artery embolization include transverse myelitis due to spinal cord ischemia and pulmonary
 artery infarction from spread of embolic material beyond its intended site.
DISPOSITION
Admission to an intensive care setting or transfer to a tertiary care center is necessary for management of severe hemoptysis.


