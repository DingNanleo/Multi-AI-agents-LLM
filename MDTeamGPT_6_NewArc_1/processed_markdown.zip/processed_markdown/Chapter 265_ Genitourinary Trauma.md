## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 265: Genitourinary Trauma
Regina C. Mysliwiec
INTRODUCTION
Falls, assaults, motor vehicle crashes, and sports injuries are the most common mechanisms for blunt GU injuries, whereas gunshot wounds and stab
 wounds are the most common causes for penetrating injuries. Seatbelt use and air bag deployment have increasingly been associated with decreased
 rates of nephrectomy in renal trauma patients. Epidemiologic data are different for civilian populations when compared to military personnel, whose
  exposure to explosive devices increases the risk of external genitalia trauma. GU organs are injured in approximately 5% of traumas. Isolated GU injuries are uncommon due to their relatively protected anatomical position. Significant damage is usually associated with other injuries. Due to lack of
 periadipose tissue and relatively large kidneys, children are anatomically more susceptible to GU injury than the general population. Appropriate management will minimize or prevent complications such as renal function impairment, urinary incontinence, and sexual dysfunction.
CLINICAL FEATURES
HISTORY
Obtain a detailed history to determine the time and mechanism of injury and the magnitude of forces involved. In motor vehicle crashes, seat location, use of restraints, vehicle speed, and crash details provide information about forces applied to the victim. Sudden deceleration can cause major vascular disruption and parenchymal damage to the kidneys and bladder, even in the absence of symptoms and physical findings.
Determine patient symptomatology whenever possible. An inability to urinate may be due to an empty bladder or inability to void because of pain, but can also result from bladder perforation, urethral injury, or spinal cord injury. Presence of preexisting genitorenal dysfunction may predispose to
 worse outcomes and should prompt consideration of more extensive workup.
PHYSICAL EXAMINATION
Inspect the perineum during the secondary survey. Blood on the underwear or pants is an important finding and may suggest genital trauma. Inspect the folds of the buttocks for ecchymoses, abrasions, or lacerations, which may be related to an open pelvic fracture. Do not deeply probe perineal injuries because probing could disrupt a clot.
Rectal examination identifies sphincter tone, position of the prostate gland, and presence of blood. If the prostate is “missing” or riding high or feels boggy, assume disruption of the membranous urethra until proven otherwise. In males, examine the scrotum for ecchymoses, laceration, and testicular disruption. Palpate and inspect the penis for ecchymoses, deformity, and blood at the meatus. In females, examine the vaginal introitus for lacerations and hematomas, which can accompany pelvic fracture. Perform a speculum examination when vaginal bleeding or hematoma is present to exclude vaginal laceration. Complications of missed vaginal injuries include infection, fistula formation, and hemorrhage.
KIDNEY INJURIES
DIAGNOSIS
,5
Renal injury is present in up to 10% of patients with abdominal trauma. Because of the protected position of the kidneys, most injuries are
 associated with other intra­abdominal injuries. Flank contusions or ecchymosis, palpable mass, lower rib fractures, and penetrating wounds in the flank mandate consideration of renal injury. Renal injuries consist of lacerations, avulsions, and hematomas to the kidney itself and renal pelvis. Renal vDaoswcunllaora idnejudr i2e0s2 (a5v­7u­l1si o8n:5, 1la Pce rYaotiuorn I, Po cisc l1u3si6o.n1)4 a2r.e1 5u9n.c1o2m7mon but must be considered in the specific diagnosis of kidney injury. 
Chapter 265: Genitourinary Trauma, Regina C. Mysliwiec 
. Terms of Use * Privacy Policy * Notice * Accessibility
URINALYSIS
Although urinalysis is a commonly ordered laboratory study for suspected renal injury, there is no direct relationship between the presence,
,8­11 absence, or degree of microscopic hematuria and the severity of injury. Microscopic and dipstick urinalysis are equally reliable for
,12 detecting the presence of hemoglobinuria. In blunt trauma, there is some evidence suggesting that gross hematuria has predictive value for more
,12 severe renal injury. In addition, patients with a systolic blood pressure of <90 mm Hg and microscopic hematuria have a higher likelihood of
 ,12 significant injury. Children with <50 red blood cells per high­powered field have a low likelihood of significant renal injury.
IMAGING
The main objectives of imaging are to (1) accurately stage the renal injury, (2) recognize preexisting pathology of the injured kidney, (3) document the
 function of the opposite kidney, and (4) identify associated injuries to other organs. Imaging guidelines are listed in Table 265­1. An IV contrast­
,6,9,11,13,14 enhanced CT scan of the abdomen and pelvis is the imaging “gold standard” for the stable patient with suspected renal injury. Contrastenhanced CT detects contusion, lacerations, hematomas, and perfusion abnormalities (Figure 265­1). Early contrast extravasation is consistent with ongoing hemorrhage. However, urinary extravasation cannot be detected until the contrast­enhanced urine is excreted into the collecting system, which usually can take up to  minutes. Therefore, a delayed scan of the kidney, ureter, and bladder is recommended to exclude urinary extravasation from any source. If the kidney is normal and there is no abnormal fluid collection in the perinephric, retroperitoneal, or peripelvic areas, then the delayed scan can be omitted.
TABLE 265­1
Imaging for Genitourinary Trauma
Injury Imaging Comments
Multisystem trauma or suspected renal Abdominal­pelvic IV Include pelvis to view entire GU tract parenchymal or vascular injury contrast CT scan Delayed films needed to identify urinary extravasation
Any visceral injury resulting in free FAST Identifies free fluid, but does not specify type of visceral injury and does not intraperitoneal fluid identify renal vascular injury
Renal artery injury Renal angiography Details vascular injuries
Ureteral injury Abdominal­pelvic IV Delayed films needed to identify extravasation; obtain IV pyelogram or contrast CT scan retrograde pyelogram if still suspicious with negative CT
Bladder injury Retrograde cystogram Can use plain radiographs or CT scan
Urethral injury Retrograde Discuss sequencing with radiologist, because if performed prior to abdominalurethrogram pelvic contrast CT scan, can interfere with diagnosis
Scrotal/testicular injury Color Doppler US Contrast­enhanced US or MRI if suspicion is high and initial US is negative
FIGURE 265­1. Renal laceration. Narrow arrow = renal laceration. Thick arrow = perinephric hematoma. [Image used with permission of Matthew C. Gratton, MD.]
The FAST examination is useful for identifying free intraperitoneal fluid, but does not specifically evaluate renal injury and does not identify renal
,14 vascular injury. Renal angiography can identify vascular injuries. Embolization of appropriate injuries can then be accomplished. Embolization can also be used to treat delayed traumatic arteriovenous fistulas.
GRADING OF RENAL INJURY

Grading of the renal injury is based on the American Association for the Surgery of Trauma organ injury scale (Table 265­2). This grading system correlates with the need for operative repair and nephrectomy. In a study of 2467 patients with renal trauma, .5% were grade I, .5% grade II, .8%
 grade III, .0% grade IV, and .1% grade V. The rate of nephrectomy ranged from 0% for grades I and II to 82% for grade V. Decreased kidney function
 is also directly correlated with renal injury grade.
TABLE 265­2
Renal Injury Scale
Grade Description
I Hematuria with normal anatomic studies (contusion) or subcapsular, nonexpanding hematoma; no laceration
II Perirenal, nonexpanding hematoma or <1 cm renal cortex laceration with no urinary extravasation
III >1 cm renal cortex laceration with no collecting system involvement or urinary extravasation
IV Laceration through cortex and medulla and into collecting system or segmental renal artery or vein injury with hematoma
V Shattered kidney or vascular injury to renal pedicle or avulsed kidney
TREATMENT OF RENAL INJURIES
Absolute indications for renal exploration and intervention include life­threatening hemorrhage due to a renal injury; expanding, pulsatile, or noncontained retroperitoneal hematoma (thought to be from a renal avulsion injury); and a renal avulsion injury (grade V vascular injury)
,6,12,18­20 demonstrated on imaging studies. High injury grade, high injury severity score, large blood transfusion requirement, and hemodynamic instability are predictive of the need for nephrectomy. Urinary extravasation alone is not an indication for exploration because it resolves spontaneously in the majority of cases. Extravasation from a renal pelvis or ureteral injury, however, does require repair.
Most authorities agree that grade I, II, and III renal injuries can be handled nonoperatively. Selected grade IV and V parenchymal injuries may be managed nonoperatively, although many of these patients have other indications for operative intervention.
If the trauma patient is hemodynamically stable and there is suspicion for renal injury with or without gross hematuria or if the patient has a penetrating injury, then CT imaging is indicated. If the CT scan reveals a renal pelvis, vascular, or ureteral injury, then surgical consultation is indicated.
Renal Vascular Injury
Renal vascular injury identified on CT scanning requires emergent surgical consultation in order to arrange treatment to minimize the time of renal
 ischemia.
COMPLICATIONS
Complications that may result from renal trauma include delayed bleeding, urinary extravasation, urinoma, perinephric abscess, and hypertension and failure of the affected kidney. Delayed bleeding can occur up to a month after injury and is most commonly due to an arteriovenous fistula that has developed after a deep parenchymal laceration. Arteriovenous fistula occurs in up to 25% of cases of grade III or IV injuries that are managed
,21 ,21,22 conservatively. Most can be managed with angiographic embolization, but renorrhaphy or nephrectomy may be necessary. A urinoma may develop from a few weeks to many years after injury and may have no symptoms or may cause a feeling of abdominal discomfort, mass, or low­grade fever. Treatment is usually percutaneous drainage or ureteral stenting. A perinephric abscess can present similarly and can also be treated with percutaneous drainage. Hypertension may occur due to renal artery injury, devascularized tissue, renal parenchymal compression by clot, or by arteriovenous malformation, and may occur from days to many years after injury. Nephrectomy is the most common treatment, but medical management may be indicated.
DISPOSITION AND FOLLOW­UP
Most patients with significant renal injury are admitted on the basis of associated injuries. For patients with isolated renal trauma, few data support specific recommendations for disposition and follow­up.
Patients with isolated renal trauma and a grade I injury can be separated into two groups after urology consultation. Those with a renal contusion
(microscopic hematuria with normal imaging) can be discharged home, as mentioned earlier. Patients with a subcapsular hematoma can be admitted for a short observation stay followed by a hematocrit and clinical reevaluation. Patients with gross hematuria usually need admission and require bed rest until the gross hematuria clears. Admit patients with grade II or higher injury to the hospital under the care of a trauma surgeon, general surgeon, or urologist as appropriate for the practice setting.
URETERAL INJURIES
DIAGNOSIS
Isolated ureteral injury is rare in trauma patients because the ureter is well protected in the retroperitoneum. Approximately 80% of ureteral injuries occur from intraoperative, iatrogenic damage. Of the 20% of injuries due to external trauma, almost 90% occur as a result of penetrating trauma (81% gunshot wounds, 9% stab wounds) and 10% occur due to blunt trauma. Because there are no history or physical examination findings that are specific
,14,23 for ureteral injuries, these injuries can be easily missed. Approximately 70% of patients with ureteral injuries have either gross or microscopic
,6,24 hematuria. The absence of hematuria does not exclude ureteral injury.
In the stable patient with suspicion of ureteral injury, obtain a CT of the abdomen and pelvis with IV contrast with a delayed phase. Extravasation of
,14,23 contrast along the course of the ureter is diagnostic for ureteral injury (Figure 265­2). If the CT is nondiagnostic and there remains a high index of suspicion for this injury, the next step is IV pyelography or retrograde pyelography.
FIGURE 265­2. Ureteral injury. Narrow single arrow = contrast material that has leaked from a transected ureter. Thick arrow = multiple metallic foreign bodies with artifact (shotgun pellets).
TREATMENT AND DISPOSITION
Treatment of ureteral injuries is operative. Partial tears can be stented, and simple lacerations can be primarily repaired over a stent. More complex injuries can be reconstructed using a variety of techniques. Complications include urinary leakage, urinoma, periureteral abscess, peritonitis, ureteral stricture, and urinary fistula. All cases require urology consultation and admission for operative management.
BLADDER INJURIES
DIAGNOSIS
,25­27
Bladder injury occurs in fewer than 2% of blunt abdominal trauma cases, and more severe injuries are often associated with pelvic fractures.
Suspect bladder injury in alcohol­intoxicated patients (bladder often distended) who are in a motor vehicle crash (potentially high­energy transfer
 resulting in pelvic fracture). Lower abdominal pain and tenderness and gross hematuria are commonly associated findings. Lower abdominal bruising, abdominal swelling from urinary ascites, perineal or scrotal edema from urinary extravasation, and inability to void are also common findings on examination of patients with bladder injury. Bladder injury also occurs secondary to penetrating trauma to the abdomen, rectum, and buttocks.
Gross hematuria is present in most significant bladder injuries. Gross hematuria in the setting of pelvic fracture requires investigation of the bladder
,11,24,27 with a retrograde cystogram. The presence of microscopic hematuria associated with a pelvic ring fracture can indicate a bladder injury, but the exact degree of microscopic hematuria warranting cystogram in this setting is undetermined and depends on clinical judgment.
A retrograde cystogram is the “gold standard” imaging study for the diagnosis of bladder rupture. This study can be performed with plain radiographs
,14,27 or with CT (Figure 265­3). The bladder must be filled in a retrograde fashion (through an indwelling bladder catheter) by gravity feed with enough contrast material (at least 350 mL) to distend the bladder. Obtain a postvoid film. The diagnosis is made when contrast material is seen spilling out of the bladder into the peritoneal cavity (intraperitoneal rupture) or into the retroperitoneal area surrounding the bladder (extraperitoneal rupture). A contrast­enhanced CT with passive bladder filling, even with a clamped catheter, is not sensitive enough to exclude bladder rupture.
Sonographic diagnosis of bladder rupture is not accurate.
FIGURE 265­3. Bladder rupture. Retrograde cystogram demonstrates an intraperitoneal rupture of the bladder.
TREATMENT AND DISPOSITION
Extraperitoneal ruptures of the bladder are most common (55%), followed by intraperitoneal (38%) and combined intra­/extraperitoneal ruptures (5%
,20,25 ,19 to 8%). Intraperitoneal ruptures always require surgical exploration and repair. Extraperitoneal ruptures can usually be managed with
 bladder catheter drainage alone. Table 265­3 lists conditions when operative repair may be needed for extraperitoneal rupture.
TABLE 265­3
Operative Repair May Be Needed for Extraperitoneal Rupture of the Bladder
Urinary catheter does not allow appropriate drainage
Associated rectal or vaginal injury
Associated bladder neck injury
Open fixation of a pelvic fracture (to avoid contamination of the hardware)
Pelvic fracture with bone spicules in bladder lumen

Missed intraperitoneal rupture can lead to urinary ascites, local abscess, peritonitis, or sepsis. If bladder neck injuries or rectal or vaginal injuries are missed, then incontinence or fistula may result. Associated injury to the sacral nerve roots or pelvic nerves can damage innervation of the bladder, resulting in a neurogenic bladder or impotence. Simple ruptures are less likely to produce complications, but may occasionally be associated with persistent bladder diverticulum, decreased bladder volume, or urinary tract infection.
Because bladder rupture is frequently associated with other injuries, admitting the patient for either operative intervention or catheter drainage under the care of a trauma surgeon, general surgeon, or urologist is the general rule.
URETHRAL INJURIES
DIAGNOSIS
Timely diagnosis and effective treatment of urethral injury are paramount to limiting long­term adverse outcomes, including impotence, stricture, urinary retention, or incontinence. Urethral injuries are less common in women primarily due to differences in urethral length (4 cm in women vs. 
 cm in men). Urethral injuries are classified anatomically as either anterior or posterior, an important distinction because comorbid injuries and treatment may vary.
POSTERIOR URETHRAL INJURIES
The posterior urethra consists of prostatic and membranous portions. Because the posterior urethra is relatively well insulated by bony and soft tissues, injuries here are generally the result of major blunt­force trauma from deceleration mechanisms such as motor vehicle collisions or falls from
 heights. Such mechanisms lead to shearing forces applied to the prostatic­membranous urethral junction. Posterior urethral injuries may occur in
 about 4% to 6% of patients with pelvic fractures.
ANTERIOR URETHRAL INJURIES
The anterior urethra is divided into the relatively fixed bulbar segment and the penile segment. Anterior urethral injuries are generally the result of direct perineal trauma, either blunt or penetrating. Straddle injury is the classic mechanism, although strikes or kicks to the perineum may lead to the
 same injury. The bulbar rather than penile segment is typically affected. Anterior urethral trauma can also occur as a result of penile fracture.
Penetrating trauma to the urethra usually occurs to the penile urethra. Evaluate for female urethral injuries in association with extensive pelvic
 fractures. Trauma to the anterior urethra may be missed initially, and patients may present years later with urethral stricture.
CLINICAL FEATURES

Suspect urethral injury from common mechanisms (straddle or penetrating perineal injuries), comorbid injuries (5% to 10% of pelvic fractures), or iatrogenic complications (traumatic catheterization). Symptoms may include hematuria, dysuria, or inability to void. Rectal and perineal examination may demonstrate a perineal hematoma or high­riding prostate. Posterior urethral injury is suggested by the triad of urinary retention, blood at the
 meatus, and a high­riding prostate. Intuitively, hematuria should be a helpful clue; however, this is neither specific nor sensitive enough to be used
,11,31 alone to diagnose or exclude a urethral injury. Difficulty passing a Foley catheter raises concern for a urethral injury; insertion should never be a forceful process. Female urethral injuries may present with vaginal bleeding, but should also be considered in patients with pelvic ring disruption,
 sacral spine injuries, or multiple pelvic fractures who present without bleeding. In women, no consensus exists on the best modality to detect
 urethral injury because cystography or urethrography may not be adequate.
DIAGNOSIS
If there are signs of possible urethral injury, such as high­riding prostate, meatal blood, perineal ecchymosis, scrotal hematoma, pelvic fracture, or gross hematuria, any resistance to gentle passage of a Foley catheter should indicate the need for consideration of suprapubic catheterization for
 bladder drainage and retrograde urethrogram for diagnosis of urethral injury.
Perform retrograde urethrogram by gently injecting  to  mL of contrast into the urethra and obtaining a radiograph. Extravasation identifies the existence and location of the urethral tear. In partial anterior urethral lacerations, the retrograde urethrogram reveals contrast extravasation at the site of injury and contrast material outlining the urethra proximal to the site of injury (Figure 265­4). In complete anterior urethral lacerations, the retrograde urethrogram reveals contrast extravasation at the site of injury without contrast proximal to the site of injury. Extravasation of contrast along fascial planes of the perineum is another indication of urethral disruption. Performing a retrograde urethrogram before completing a
CT of the abdomen and pelvis to evaluate for other life­threatening injuries can interfere with CT diagnosis and embolization treatment of pelvic arterial extravasation from pelvic fractures, so discuss the sequencing of studies with the trauma surgeon,
 urologist, or radiologist. If a Foley catheter has already been successfully inserted, and then a urethral injury is considered, keep the Foley catheter in place. Using a 16­gauge angiocatheter, inject contrast material at the meatus, around the urinary catheter, and then obtain radiographs in
 the standard fashion. In males, the location and displacement of anterior pelvic fractures, if present, can predict the risk of urethral injury. For every
 millimeter of symphysis pubis diastasis or inferomedial pubic bone fracture displacement, the risk of urethral injury increases by 10%.
FIGURE 265­4. A. Normal retrograde urethrogram. B. Extravasation of contrast.
TREATMENT AND DISPOSITION
Patients with urethral trauma often have multiple injuries, some of which take precedence over the urethra trauma. Prioritize treatment(s) according to standard Advanced Trauma Life Support guidelines. The treatment for male patients with posterior urethral injury secondary to pelvic fracture has generally been immediate placement of a suprapubic catheter (for bladder drainage) with delayed surgical repair (often weeks later). Suprapubic catheter placement allows for urinary drainage without urethral manipulation or disruption of a pelvic hematoma.
Most penetrating injuries to the anterior urethra require surgical exploration and repair. It is more difficult to perform urethrography in women due to the relatively short urethra; urethroscopy may be more helpful. Concomitant bladder injury needs to be excluded with CT cystography. Because urethral injury is frequently associated with other injuries, admit the patient for either operative intervention or catheter drainage under the care of a trauma surgeon, general surgeon, or urologist.
INJURIES TO THE EXTERNAL GENITALIA
CLINICAL FEATURES
Penile fracture, with or without urethral injury, occurs when the corpus cavernosum ruptures after being forcibly bent, usually during sexual
 intercourse. A cracking sound may be heard, followed by penile pain, rapid swelling, discoloration, and visible deformity (“eggplant deformity”).
Amputations are usually self­inflicted or result from clothing trapped by heavy machinery. Self­inflicted trauma to the penis can also result from vacuum cleaner injuries, which cause extensive injury to the glans penis and urethra, and strangulation from constricting penile rings used to enhance erections. Penetrating injuries are less common and may also involve the urethra.
Injuries to the scrotum may occur from blunt or penetrating trauma, burns, and avulsions. More than half of all testicular trauma is a result of sporting
 activity. Impingement of the testicles against the symphysis pubis is the primary cause of blunt testicular injuries. Resultant injury to the testicle ranges from contusion to rupture. In both conditions, the tunica vaginalis fills with blood, forming a hematocele. If the tunica albuginea is disrupted, a rupture has occurred.
Symptoms after a direct scrotal blow are usually scrotal pain and swelling. Other signs may include scrotal discoloration and a tender, firm scrotal mass that fails to transilluminate, which indicates a hematocele. An empty hemiscrotum suggests testicular dislocation. Many patients will be exquisitely tender, potentially limiting a thorough exam. Furthermore, the external signs of trauma may not correlate well with the degree of testicular
 injury; thus, there should be a low threshold for diagnostic imaging.
DIAGNOSIS

Color Doppler US is the diagnostic modality of choice in the evaluation of scrotal/testicular trauma. Although there is no advantage initially, contrastenhanced US and testicular MRI may be useful adjuncts if the Doppler US results are inconclusive and clinical suspicion remains high for testicular
,37 injury. CT plays an important role in the evaluation of concomitant abdominopelvic injuries. Penile injuries often result in urethral injuries; thus, consider retrograde urethrogram in this scenario. While the diagnosis of penile fracture is largely clinical, US may detect corpus cavernosum
 hematomas and can be an adjunct to both diagnosis and operative management.
TREATMENT
Most closed testicular contusions are managed conservatively with opiate analgesics, ice, elevation, scrotal support, and appropriate urologic followup. Testicular rupture requires immediate drainage and repair. Any patient with penetrating scrotal trauma should undergo immediate scrotal
,39 exploration. Obtain emergent urologic consultation for all confirmed or suspected penile fractures. With immediate surgical intervention, erectile
 function may be spared.
Loss of penile skin by avulsion injury or burns is managed by split­thickness skin grafts after the denuded penis is clean and sterile. Do not reapply avulsed skin, because avulsed skin invariably becomes necrotic and infected and must be subsequently removed. Penile amputations require repair by microsurgical reimplantation if the amputated segment is deemed viable by the urologist.
Strangulation injuries can usually be managed simply by removing the constricting agent. Zipper injury to the penis is caused when the penile skin is trapped in the trouser zipper. Mineral oil and lidocaine infiltration are useful in freeing the penile skin from the zipper. Otherwise, wire­cutting or bone­cutting pliers are used to divide the median bar (or diamond) of the zipper, which causes the zipper to fall apart, freeing the penile skin.
Contusions of the perineum or penis are treated conservatively with cold packs, rest, and elevation. Insert a Foley catheter if the patient is unable to void.
SPECIAL POPULATIONS
ELDERLY
As men age, they experience anatomic changes, including laxity of scrotal tissue, atrophy of the perineal muscles, and loss of collagen tissue. Changes in women are secondary to declining secretion of estrogen after menopause and include atrophy of the cervix and uterus, atrophy of the walls of the vaginal canal, decrease in vaginal length and width, and decrease in vaginal lubrication. These changes predispose the elderly to complex injuries of the external genitalia even with a minor mechanism of injury. Compared to younger trauma patients, trauma to the GU system in the elderly patient
 tends to be more common from blunt mechanisms and tends to result in higher rates of bladder and urethral injuries.

The presence of a penile prosthesis can transform a minimal blunt trauma genital injury into a complicated surgical issue for the patient. Extrusion and rupture of penile prostheses predispose patients to infection and complications of wound healing. This becomes a special concern in diabetic patients who are more likely to have prostheses. Obtain urologic consultation for any patient who has sustained trauma to the genitalia with a prosthesis in place (see Chapter , “Complications of Urologic Procedures and Devices”).
PREGNANT WOMEN
With pregnancy, women experience physiologic changes that predispose them to more severe injury in both blunt and penetrating trauma to the genitalia. During pregnancy, venous outflow from the perineal area is slowed because of the pressure on the vena cava from the enlarging uterus.
Slowed blood flow to the area can cause edema of the vulva. The increased level of progesterone during pregnancy also contributes to fluid retention and edema of the genitalia. Engorgement of the perineum predisposes pregnant patients to increased risk of hemorrhage from penetrating trauma to this anatomic region.
CHILDREN

Roughly 33% of males worldwide are circumcised. The aim of circumcision is to excise sufficient foreskin (both penile shaft and inner preputial epithelium) to leave the glans uncovered. Complications of circumcision are more common in older children. Early complications of circumcision
 include bleeding, infection, pain, and inadequate skin removal. Direct pressure alone is adequate to stop bleeding in most scenarios, although in some instances, the application of pressure alone is insufficient to control local hemorrhage and other methods of hemostasis must be employed.
Circumferential dressings may cause urinary retention and even necrosis of the distal penis if blood flow is compromised.

Genital trauma in children should prompt consideration of sexual abuse. The clinical evaluation of prepubescent females with blunt urogenital trauma may underestimate the severity of injuries when compared with examination under anesthesia. Consider consultation for examination under anesthesia for accurate diagnosis and to minimize psychological sequelae of examination. In boys, nonsexual trauma to the external genitalia most commonly occurs between ages  and  years. Bicycle accidents, kicks, and falls are the typical mechanisms, and scrotal and penile lacerations or
 testicular contusions are the most common injuries.


