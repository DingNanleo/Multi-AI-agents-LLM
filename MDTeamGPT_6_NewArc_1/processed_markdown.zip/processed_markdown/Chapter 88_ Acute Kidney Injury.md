## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 88: Acute Kidney Injury
Richard Sinert; Peter R. Peacock Jr.
INTRODUCTION AND EPIDEMIOLOGY
Acute kidney injury (AKI) is the deterioration of renal function over hours or days, resulting in the accumulation of toxic wastes and the loss of internal
1­4 homeostasis. Definitions based on renal function are listed in Table 88­1 ; AKI is classified using the Risk, Injury, Failure, Loss, and End­Stage Renal

Failure (RIFLE), the Acute Kidney Injury Network (AKIN), and the Kidney Disease: Improving Global Outcomes (KDIGO) classifications. These definitions assume that renal function has reached a steady state, which limits their applicability to ED patients with AKI whose renal function may be deteriorating.
TABLE 88­1
AKIN and RIFLE Criteria for Acute Kidney Injury
AKIN
RIFLE Category Change in Creatinine/GFR Criteria Urine Output Criteria
Stage
Stage  Risk Serum Cr increased .5 times* .5 mL/kg/h for  h or (AKIN only)
Cr increase >0.3 milligram/dL (≥26.5 µmol/L) over <48 h* or
GFR decrease 25%–50%* Stage  Injury Serum Cr increased .0–3.0 times* .5 mL/kg/h for  h or
GFR decrease 50%–75%* Stage  Failure Serum Cr increased >3.0 times* .3 mL/kg/h for  h or or
Cr >4 milligrams/dL (≥354 µmol/L) and acute increase >0.5 milligram/dL (44 Anuria for  h
µmol/L)* or
GFR decrease >75%* N/A Loss Complete loss of kidney function for >4 weeks
End­stage renal Need for renal replacement therapy for >3 months disease
Abbreviations: AKIN = Acute Kidney Injury Network; Cr = creatinine; GFR = glomerular filtration rate; N/A = not applicable; RIFLE = Risk, Injury, Failure, Loss, End Stage.
*All changes are relative to the patient’s premorbid baseline.
5­9
Reversible mechanisms, such as volume depletion, medications, infection, or urinary obstruction, cause the majority of community­acquired AKI

,6,10­12 cCahsaeps tperre 8s8e:n Atincugt teo K thiden EeDy (I5n5ju%ry t,o R 7ic9h%a)r.d Siner tD; ePseptieter Rfa.v Poeraabcloec rke nJar.l recovery rates, community­acquired AKI is associated with significaPnat gheo s1p /i t2a0l
©2025 McGraw Hill. All Rights1 3R,14eserved. Terms of Use * Privacy Policy * Not7ic,1e4 ,1 *  Accessibility mortality, from .3% to .6%, and 3­year mortality is as high as 45% to 66%. Hospital­acquired AKI by definition occurs or worsens in the
,10,12 hospital, where mortality ranges from 27% to 62%. For both types of AKI, mortality has a graded relationship with advancing age and severity of
,16
AKI.
PATHOPHYSIOLOGY
The functions of the kidneys are glomerular filtration, tubular reabsorption, and secretion. Normal glomerular filtration rate (GFR) in early adulthood
  is approximately 120 mL/min/1.73 m and typically decreases by  mL/min/1.73 m every decade thereafter. The driving force for glomerular filtration is glomerular capillary pressure, which depends on renal blood flow and autoregulation. For most causes of AKI, global or regional decrease in renal blood flow is the final common pathway. Recovery from AKI first depends on restoration of renal blood flow.
Renal insult is classified as prerenal (decreased perfusion of a normal kidney), intrinsic (pathologic change within the kidney itself), or postrenal
(also called postobstructive, due to obstruction of urine outflow).
In prerenal AKI, tubular and glomerular functions are initially maintained. Timely restoration of circulating blood volume or discontinuation of an implicated medication restores function in most cases. Postrenal AKI causes increased tubular pressure, which decreases the driving force for filtration. This pressure gradient soon equalizes; thereafter, the maintenance of the depressed GFR depends on vasoconstrictors. Rapid relief of urinary obstruction in postrenal AKI results in a prompt decrease of vasoconstriction and a return to normal renal function.
Diseases of the glomerulus, small vessels, interstitium, and tubule cause intrinsic AKI; all are associated with the release of renal vasoconstrictors.
The most common cause of intrinsic AKI is ischemic injury or ischemic tubular necrosis (also historically called acute tubular necrosis), when renal perfusion is decreased so much that the kidney parenchyma is affected.
During the period of depressed renal blood flow, the kidneys are especially vulnerable to further insults. Exposure at this time to known nephrotoxins such as NSAIDs or aminoglycosides can cause iatrogenic AKI. Figure 88­1 illustrates the cellular and subcellular events leading to ischemic tubular necrosis.
FIGURE 88­1. Ischemic tubular necrosis. Tubular injury is a direct consequence of vasoconstriction, inflammation, endothelial changes, disruption of cell–cell and cell–matrix connections, and apoptotic changes. ATP = adenosine triphosphate.
In intrinsic AKI, clearance of tubular toxins and initiation of therapy for glomerular diseases decrease vasoconstriction and help restore renal blood flow. Once the cause of injury is resolved, the remaining functional nephrons increase filtration and eventually hypertrophy. Depending on the size of the remnant nephron pool, GFR will proportionately recover. If the number of remaining nephrons is below some critical number, continued hyperfiltration results in progressive glomerular sclerosis, eventually leading to nephron loss. A vicious cycle of nephron loss then ensues until complete AKI occurs. This sequence explains the commonly observed scenario in which progressive AKI occurs after initial recovery from AKI, contributing to delayed mortality.
CLINICAL FEATURES
HISTORY AND COMORBIDITIES
AKI itself has few symptoms until severe uremia develops. Uremia causes nausea, vomiting, drowsiness, fatigue, confusion, and if untreated, coma.
Patients are more likely to present with symptoms related to the underlying cause of AKI, which should prompt assessment of renal function. See
6­10,12,16­19
Table 88­2 for risk factors for community­acquired AKI.
TABLE 88­2
Risk Factors for Acute Kidney Injury
Dehydration* Sepsis* Advanced age* Medications
Diuretics* NSAIDs* ACE inhibitors* Angiotensin receptor blockers* Antiretroviral therapy
Acyclovir, valacyclovir
Statins
Rhabdomyolysis
Trimethoprim/sulfamethoxazole
Aminoglycosides, vancomycin
Immunosuppressive drugs, kidney transplantation
Tacrolimus
Cyclosporine, others
Failure to dose medications for CKD
Antibiotics, metformin, proton pump inhibitors
Drugs of abuse
Cocaine, ethanol, ethylene glycol
Systemic disease
CKD (preexisting)* Cardiovascular disease* CAD, heart failure, hypertension, vascular disease
Diabetes
Hepatic disease
Autoimmune/rheumatologic disease
Gout, elevated uric acid
Outflow obstruction: prostatic/urethral disease
Malignancy
Renal parenchymal invasion, bladder obstruction
Multiple myeloma/hypercalcemia
Eclampsia and preeclampsia
Contrast agents
Iodinated contrast media
Gadolinium
Nephrogenic systemic fibrosis
Abbreviations: ACE = angiotensin­converting enzyme; CAD = coronary artery disease; CKD = chronic kidney disease.
*Most common risks for community­acquired disease.
Patients with prerenal AKI from volume depletion commonly develop thirst, orthostatic lightheadedness, and decreased urine output. Excessive vomiting, diarrhea, urination, hemorrhage, fever, or sweating can reduce circulating volume sufficiently to precipitate AKI. Causes of endothelial leak and third spacing, such as sepsis, pancreatitis, burns, and hepatic failure, can also result in prerenal AKI, although these settings may also be associated with renal parenchymal injury. Progression of heart failure from any cause or overdiuresis of the patient with compensated congestive heart failure may cause AKI. Decreased fluid intake from physical or cognitive disability can result in hypovolemia.
Intrinsic renal diseases can often be anticipated because of symptoms of the precipitating cause. Anticipate ischemic AKI after cardiac arrest, in severe sepsis, or with other causes of systemic hypotension. AKI from crystal­induced nephropathy, nephrolithiasis, and papillary necrosis
 can present as flank pain and hematuria. Suspect pigment­induced AKI in rhabdomyolysis (see Chapter , “Rhabdomyolysis”) or with hemolysis after recent blood transfusion. Darkening urine and edema, with or without constitutional symptoms such as fever, malaise, and rash, suggest acute glomerulonephritis, which may have been preceded by pharyngitis or cutaneous infection. Fever, arthralgia, and rash are common with acute interstitial nephritis. Acute renal arterial occlusion is usually marked by severe flank pain. Cough, dyspnea, and hemoptysis raise the possibility of Goodpasture’s syndrome or Wegener’s granulomatosis.
Suspect postrenal AKI in men with prostatic disease or advanced age and patients with indwelling bladder catheters. Anuria strongly suggests obstruction, although vascular obstruction and fulminant renal disease are also possible. Alternating oliguria and polyuria is virtually pathognomonic of obstruction.
PHYSICAL EXAMINATION
Assess for abnormal volume status. Evaluate mucous membranes, jugular vein distention, lung auscultation, peripheral edema, and tissue turgor to identify dehydration. Carefully assess for rashes, evidence of vasculitis, jaundice, abdominal or pelvic masses, or a distended palpable urinary bladder.
On cardiac exam, check for atrial fibrillation, abdominal aortic aneurysm, and signs of heart failure, and assess extremity pulses. Suspect fluid overload in patients with rapid weight gain, peripheral or facial edema, pulmonary rales, or dullness to percussion of the chest wall over the lower portions of the lungs (suggesting plural effusion).
DIAGNOSIS
In the ED, the goals are to identify patients at risk for AKI, correct metabolic effects, decrease ongoing renal injury, and prevent iatrogenic injury.
Determine if kidney injury is prerenal, postrenal, or intrinsic through history, physical, and diagnostic testing. Obtain CBC, electrolyte levels including magnesium and phosphorus, and hepatic function tests and blood cultures as clinically appropriate. Obtain urinalysis, urine osmolality, urine sodium and urea levels, and urine culture if infection is suspected. Indicators of hypovolemia include base deficit, increased lactate level, decreased central venous pressure, or an US showing collapse of the inferior vena cava (see “Imaging” section). If acute decompensated heart failure is suspected as a contributing factor to worsening renal function (see “Cardiorenal Syndrome” section), obtain a B­type natriuretic peptide level or pro–B­type natriuretic peptide level.

ECG is the fastest screening test for hyperkalemia, but sensitivity for a level over .5 mmol/L ranges from 14% to 60%. Peaked T waves are only seen
 in 34% of patients (see Chapter , “Fluids and Electrolytes”). Chest radiography helps evaluate for increased volume, effusions, and pneumonia, all of which can result from or precipitate AKI.
Obtain bedside US to assess urinary bladder volume. A large postvoid bladder residual volume (>125 mL) suggests bladder outlet obstruction, for which you would place a urethral catheter. See Chapter , “Acute Urinary Retention,” for further discussion. Anuria is defined as <100 mL of urine per day and can be present with prerenal, postrenal, or intrinsic AKI.
PRERENAL ACUTE KIDNEY INJURY
The causes of prerenal azotemia can be broken down into volume loss, hypotension, and diseases of the large and small renal arteries (Table 88­3).
Prerenal AKI is also a common precursor to ischemic and nephrotoxic conditions, leading to intrinsic AKI.
TABLE 88­3
Causes of Prerenal Acute Kidney Injury
Hypovolemia
GI: decreased intake, vomiting, diarrhea
Pharmacologic: diuretics
Third spacing
Skin losses: fever, burns
Miscellaneous: hypoaldosteronism, salt­losing nephropathy, postobstructive diuresis
Hypotension (overt and relative)
Septic vasodilation
Hemorrhage
Decreased cardiac output: ischemia/infarction, valvulopathy, cardiomyopathy, tamponade
Pharmacologic: β­blockers, calcium channel blockers, other antihypertensive medications
High­output failure: thyrotoxicosis, thiamine deficiency, Paget’s disease, arteriovenous fistula
Renal artery and small­vessel effects
Pharmacologic: NSAIDs, angiotensin­converting enzyme inhibitors, angiotensin receptor blockers, cyclosporine, tacrolimus (microvasculature effects that decrease renal blood flow; may lead to intrinsic AKI)
Hypercalcemia: vasoconstriction, may lead to intrinsic AKI
Embolism: thrombotic, septic, cholesterol* Thrombosis: atherosclerosis, vasculitis, sickle cell disease* Dissection* Microvascular thrombosis: preeclampsia, hemolytic­uremic syndrome, disseminated intravascular coagulation, vasculitis, sickle cell disease* Abbreviation: AKI = acute kidney injury.
*These causes include a component of ischemic AKI.
POSTRENAL ACUTE KIDNEY INJURY
In the elderly population, the rate of postrenal AKI is as high as 22%. The most common cause is prostatic hypertrophy. Consider this diagnosis in elderly patients of both sexes; patients with indwelling urinary catheters, GU surgery, known or suspected abdominal malignancy, nephrolithiasis, or retroperitoneal disease; or patients on medications known to affect the urinary sphincter. See Chapter , “Acute Urinary Retention,” for a detailed list of causes.
INTRINSIC ACUTE KIDNEY INJURY
Intrinsic kidney injury is not common in patients with community­acquired disease, but it is the most common cause in hospitalized patients. Intrinsic
AKI can result from injury to the glomerulus, tubule, interstitium, or vasculature. In community­acquired intrinsic AKI, drugs (Table 88­4), infection,
,17 and vascular events are common precipitants. Hospital AKI is due to toxic and ischemic insults in most cases.
TABLE 88­4
Intrinsic Acute Kidney Injury Due to Drugs
Reduced renal perfusion by altered Amphotericin B, ACE inhibitors, cyclosporine, interleukin­2, NSAIDs, radiocontrast agents, tacrolimus intrarenal hemodynamics
Direct tubular toxicity Aminoglycoside antibiotics, amphotericin B, cisplatin, cyclosporine, foscarnet, heavy metals, IV immunoglobulin methotrexate, organic solvents, pentamidine, radiocontrast agents, tacrolimus
Rhabdomyolysis Cocaine, ethanol, lovastatin
Intratubular obstruction Acyclovir, chemotherapeutic agents, ethylene glycol, methotrexate, sulfonamides
Interstitial nephritis Allopurinol, cephalosporins, cimetidine, ciprofloxacin, furosemide, NSAIDs, phenytoin, penicillins, sulfonamides, rifampin, thiazide diuretics
Hemolytic­uremic syndrome Cocaine, cyclosporine, conjugated estrogens, mitomycin, quinine, tacrolimus
Abbreviation: ACE = angiotensin­converting enzyme.
Contrast­Induced Nephropathy
Contrast­induced nephropathy is defined by a relatively small change in serum creatinine (25% increase from baseline or an absolute increase of .5 milligram/dL [44 µmol/L]  to  hours after infusion). The studies documenting contrast­induced nephropathy incidence, risks, and outcomes suffer biases common to many observational studies: confounding bias and selection bias. Confounding bias occurs when an exposure is inappropriately causally linked to an outcome, when a separate exposure (the confounding variable) other than the one of interest better explains the observed outcome. To account for this potential selection bias, multiple studies have compared the incidence of AKI between contrast­exposed and unexposed
 patients using propensity scoring matching to balance baseline outcome risks between groups. These studies failed to find a statistically higher
24­29 incidence of AKI in the contrast­exposed group compared to the unexposed group of hospitalized patients with similar comorbidities. These studies also found no differences in mortality, development of chronic kidney disease, or need for dialysis or renal transplantation in the future
24­29 between contrast­exposed patients and unexposed patients. Prevention of worsening renal function due to contrast exposure continues to serve
30­32 as an indication for hydration prior to contrast­enhanced imaging for patients with preexisting chronic kidney disease (see “Preventing Renal
Injury” section).
Crystal­Induced Nephropathy
Crystal­induced nephropathy is the precipitation of crystals within the renal tubules, resulting in mechanical and inflammatory injuries of the tubular epithelium. Chronic renal insufficiency and hypovolemia predispose patients to this form of renal injury, and urinary pH affects the formation of many of these crystals. Elevated uric acid levels in the setting of tumor lysis syndrome and some medications—in particular, acyclovir, sulfonamides, indinavir, and triamterene—are the most common causes of crystal­induced acute kidney injury.
Angiotensin­Converting Enzyme Inhibitors
Angiotensin­converting enzyme inhibitors can simultaneously decrease the GFR and increase renal blood flow, resulting in a 10% to 20% increase in serum creatinine. Because they inhibit angiotensin II, they cause a preferential efferent arteriolar vasodilation in the renal glomerulus. These arteriolar changes may precipitate significant AKI in a patient with undiagnosed bilateral renal artery stenosis, a condition that typically requires angioplasty and stenting or bypass surgery. Volume depletion and concomitant use of vasoconstricting medications are other common precipitators of angiotensin­converting enzyme inhibitor–induced AKI. Angiotensin receptor blockers have similar effects. Hyperkalemia, which is usually mild, is a relatively common complication of angiotensin­converting enzyme inhibitor administration.
NSAIDs
NSAIDs may cause AKI because they decrease both GFR and renal blood flow (prerenal AKI). With chronic use, they may cause interstitial nephritis
(intrinsic AKI). Risk factors for adverse reactions to these medications are older age, chronic renal insufficiency, congestive heart failure, diabetes, volume depletion, and concomitant use of diuretics or angiotensin­converting enzyme inhibitors.
Antibiotics
Antibiotics, particularly aminoglycosides, are another important cause of iatrogenic renal injury. Other antibiotics frequently implicated are
,33­35 vancomycin, ceftriaxone, sulfamethoxazole/trimethoprim, amoxicillin, cefazolin, and fluoroquinolones. The most common antiviral medications implicated in AKI are the antiretrovirals, acyclovir, and valacyclovir.
Pigment Nephropathy
Hemoglobin and myoglobin from hemolysis or rhabdomyolysis are deposited and concentrated in the renal tubules. Renal injury occurs through tubular obstruction and direct toxicity (pigment nephropathy).
Glomerulonephritis
Glomerulonephritis is an uncommon cause of acute kidney injury. Glomerulonephritis may present as a nephrotic syndrome with edema, proteinuria, hypoalbuminemia, and hyperlipidemia, or a nephritis syndrome with hematuria, red blood cell casts, decreased urine output, and hypertension.
Glomerulonephritis may be postinfectious, be associated with toxic exposure, or occur in association with an immune disorder, such as systemic lupus erythematosus.
DIAGNOSTIC TESTING
Creatinine and GFR
Creatinine is the mainstay for measuring renal function; it is a breakdown product of the skeletal muscle protein creatine, and its level is thus linked to muscle mass. In patients with no renal function (GFR = 0), serum creatinine level increases  to  milligrams/dL (88 to 265 µmol) a day. Lesser increases in creatinine indicate residual renal function, whereas faster increases suggest rhabdomyolysis. Elevation of serum creatinine may take  hours after onset of decreased function, and a patient with a very low baseline creatinine level can lose more than half of the functioning nephrons before serum creatinine elevates to an abnormal level.
In the ED, using automated laboratory devices, useful measures of kidney function (creatinine clearance and GFR) are estimated using equations that use information from the electronic medical record, including the measured creatinine level, age, weight, sex, and race. Patients with lower muscle mass (e.g., older patients and women) have lower actual GFRs for any given creatinine level. Acute changes in creatinine levels may be independent of renal function. For example, creatinine rises in rhabdomyolysis and fenofibrate use due to effects on muscle tissue, whereas in sepsis, creatinine production is decreased. These extrarenal changes in creatinine alter the relationship between creatinine and estimates of GFR. Glomerulonephritis increases tubular secretion of creatinine, but trimethoprim, cimetidine, and salicylates decrease tubular secretion of creatinine, thus altering the
  creatinine level independently of the GFR. Normal kidney function is a GFR >90 mL/min/1.73 m , where .73 m is used as the average body surface area. Stages of kidney disease are characterized in Table 88­5. TABLE 88­5
Stages of Chronic Kidney Disease
Stage GFR Comments
Stage  GFR ≥90 mL/min/1.73 m2 Non­GFR evidence of kidney damage present
Stage  GFR 60–89 mL/min/1.73 m2 Mild disease
Stage  GFR 30–59 mL/min/1.73 m2 Mild to moderate disease
Stage  GFR 15–29 mL/min/1.73 m2 Moderate to severe disease
Stage  GFR <15 mL/min/1.73 m2 Dialysis or transplant needed
Abbreviation: GFR = glomerular filtration rate.
Unfortunately, all GFR calculations are based on a steady­state creatinine level, severely limiting their applicability in AKI seen in the ED.
Cystatin C
A protein produced by all nucleated cells has been proposed as a replacement for creatinine in estimating GFR. Cystatin C is formed at a constant rate unchanged by infections, inflammatory, and neoplastic conditions and, unlike creatinine, is not affected by diet, drugs, or body mass. Estimated GFR can be calculated by the Chronic Kidney Disease Epidemiology cystatin C equation, which corrects for age and sex. As with creatinine, elevations of cystatin C are only detected  to  hours after AKI has already occurred. Cystatin C may be more accurate in predicting death and progression to
 chronic kidney disease or need for dialysis. Experts continue to search for a biomarker that could identify AKI early in the course of renal
 deterioration, but such a marker has yet to be identified.
Urine Output
Exact measurements of urine output require a urinary catheter to be in place for greater than  hours to meet the criteria of AKI as required from the
Risk, Injury, Failure, Loss, and End­Stage Renal Failure (RIFLE) criteria in Table 88­1, limiting the applicability of urine output in an ED setting.
BUN­to­Creatinine Ratio
The ratio of BUN to creatinine can suggest hypovolemia because of differences in the way each is handled in the nephron. Both substances are passively filtered at the glomerulus, but where creatinine remains within the tubule, the renal tubule is highly permeable to urea, which is passively reabsorbed with sodium. Therefore, in the setting of avid sodium retention, urea clearance is as low as 30% of GFR, whereas in the setting of adequate volume and sodium, urea clearance can increase to 70% to 100% of GFR. Thus, if the patient has normal concentrating ability, in the setting of prerenal
AKI, the serum ratio of BUN to creatinine is typically >10. BUN level is depressed in patients with malnutrition and hepatic synthetic dysfunction and can be increased in the setting of protein loading, GI hemorrhage, or trauma. Despite the use of the BUN­to­creatinine ratio by clinicians to identify
,39 prerenal disorders since the 1940s, two recent studies question its accuracy. The ratio fails to accurately identify AKI cases that resolve with volume
,39 replacement alone.
Fractional Excretion of Sodium
The fractional excretion of sodium (Fe = U /P ÷ U /P , where Na = sodium, Cr = creatinine, U = urine, and P = plasma) is another indicator that is
Na Na Na Cr Cr commonly used to identify hypovolemia, but it has important limitations. For example, in the setting of intrinsic AKI in which tubular concentrating capacity is retained, as in the case of glomerulonephritis, the fractional excretion of sodium may be depressed if there is concomitant volume depletion. With tubular injury such as ischemic acute tubular necrosis, the loss of concentrating ability results in a dilute urine, with a fractional excretion of sodium >1%, even if the patient is volume depleted (Table 88­6).
TABLE 88­6
Laboratory Findings in Conditions That Cause Acute Kidney Injury
Urine Osmolality Fractional Excretion
Category Dipstick Test Sediment Analysis
(mOsm/kg) of Sodium (%)
Prerenal Trace to no proteinuria, SG >1.015 A few hyaline casts possible >500 <1
Renal
Ischemia Mild to moderate proteinuria Pigmented granular casts, renal <350 >1 tubular epithelial cells
Nephrotoxins Mild to moderate proteinuria Pigmented granular casts <350 >1
Acute interstitial Mild to moderate proteinuria; White cells, eosinophils, casts, red <350 >1 nephritis hemoglobin, leukocytes cells
Acute Moderate to severe proteinuria; Red cells and red cell casts; red >500 Depends on volume glomerulonephritis hemoglobin cells can be dysmorphic status
Postobstrutcive or Trace to no proteinuria; hemoglobin Crystals, red cells, and white cells <350 >1 postrenal and leukocytes possible possible
Abbreviation: SG = specific gravity.
Urinalysis
Microscopic examination of urine is useful in establishing the differential diagnosis. In acute glomerulonephritis, red blood cells enter the filtrate at the glomerulus and, on microscopic urinalysis, appear as casts and dysmorphic cells due to the increased tonicity of the renal medulla. In acute tubular necrosis, the tubular epithelium breaks down and allows protein to leak into the filtrate, and tubular epithelial cells may be seen in the sediment.
Hyaline casts are common in prerenal AKI and can be a normal finding; pigmented granular casts are common with ischemic or toxic tubular injury.
Brown granular casts are common in hemoglobinuria or myoglobinuria. The finding of hemoglobin on urine dipstick analysis with no red cells on microscopy suggests myoglobinuria. Some crystals may be present in a normal urinalysis. Crystals are best seen with polarized light microscopy. Red cell casts and proteinuria suggest glomerulonephritis or an underlying autoimmune disease.
Imaging
Renal US is the test of choice for urologic imaging in the setting of AKI. It has approximately 90% sensitivity and specificity for detecting hydronephrosis due to mechanical obstruction. Figure 88­2 contrasts normal kidney US findings with US findings indicating hydronephrosis. If renal US detects hydronephrosis, a secondary imaging study to define the location of obstruction may be required. Bipolar renal length is easy to assess by US, and kidney dimension of <9 cm suggests chronic kidney disease. Renal parenchyma should be isoechoic or hypoechoic compared with that of the liver and spleen. Hyperechogenicity indicates diffuse parenchymal disease. Color flow Doppler US allows assessment of renal perfusion and can allow diagnosis of large­vessel causes of AKI. Resistive index is the ratio of the difference between systolic and diastolic flow to systolic flow [(V – max
V )/V ] as measured by color flow Doppler. In the vasoconstrictive phase of ischemic AKI, in which there may be no diastolic flow, the ratio may be min max as high as .0. The normal ratio is <0.7. FIGURE 88­2. US of normal kidney and kidney showing hydronephrosis. A. Normal kidney; capsule margin at arrows. B. Hydronephrosis as would be expected in obstructive uropathy; the dilated kidney fills the majority of the screen; capsule at arrows. [Image used with permission of Michael B. Stone, MD,
RDMS.]
In intermittent or partial obstruction, hydronephrosis may be present, and it may even be absent in complete obstruction in the setting of retroperitoneal fibrosis. Furthermore, functional dilatation can occur in the setting of chronic ureteral reflux.
Noncontrast CT has a sensitivity for hydronephrosis that is equivalent to that of US and has the added advantage of demonstrating the site and often the cause of obstruction. If functional obstruction is a consideration in the presence of a dilated GU tract, radionuclide scans and magnetic resonance urographs before and after administration of diuretics can be obtained.
TREATMENT
For the critically ill patient with AKI, resuscitation is the first priority, and multiple diagnostic and therapeutic processes advance simultaneously. Look for and treat hypovolemia, sepsis, myocardial ischemia, respiratory failure, acute decompensated heart failure, electrolyte disturbances, acidosis,
40­42 40­42 volume overload, and urinary obstruction, as clinically indicated. The initial priority is treatment of the underlying cause of AKI. While determination of the AKI type helps to determine priorities for treatment (i.e., prerenal AKI is most likely to require fluid resuscitation), this treatment section is organized based on the manifestations of AKI most likely to require acute management regardless of AKI type. See also “Cardiorenal
Syndrome” under the “Special Populations” section below. Rhabdomyolysis is discussed in Chapter . VOLUME DEPLETION

Correct intravascular volume deficits with crystalloids. Balanced crystalloids, such as lactated Ringers’ solution, may offer a small advantage over normal saline solution. In a large randomized trial involving ,802 critically ill patients, subjects receiving balanced crystalloids had a lower rate of the composite outcome of death from any cause, new renal replacement therapy, or persistent renal dysfunction after discharge (14.3%), compared to
 patients receiving normal saline (15.4%). A separate randomized trial involving ,347 non–critically ill patients, did not find a mortality difference;
 however, patients receiving balanced crystalloids had a lower rate of adverse kidney events (4.7% vs. .6%). Accurate determination of volume status
 is essential to prevent volume overload, which has been shown to worsen AKI and increase mortality. Using bedside US, inspiratory collapsibility of
,48 the intrahepatic segment of the inferior vena cava is one noninvasive measure of volume status and expected fluid responsiveness (Figure 88­3).
FIGURE 88­3. US of the inferior vena cava. A. Dilated inferior vena cava (arrows) with little respiratory variation as might be expected in volume overload. B. An almost fully collapsed inferior vena cava at inspiration (arrows) and expiration (arrowheads) as might be expected in prerenal acute kidney injury.
[Image used with permission of Michael B. Stone, MD, RDMS.]
PREVENTING RENAL INJURY
Hold medications that could be causing AKI (Tables 88­3 and 88­4). Make sure that renal dose adjustments are made for medication orders and that renal function is considered before ordering radiographic contrast studies. In general, for IV contrast studies in patients with GFR of  to 
  mL/min/1.73 m , weigh benefits of the study against the risk of renal function decline. For patients with GFR <30 mL/min/1.73 m , avoid IV contrast studies if possible. Emergency contrast studies for major trauma, aortic dissection, or ST­segment elevation myocardial infarction are examples in
 which benefits typically outweigh risk for most patients. Avoid gadolinium for GFR <30 mL/min/1.73 m . For patients with abnormal kidney function,
 for whom contrast­enhanced imaging is planned, the ideal rate and volume of fluid administration is not defined. Commonly used volumes are 500 to 1000 mL of crystalloid (lactated Ringer’s or .9% normal saline) prior to the procedure and an equal volume after the procedure; however, significantly dehydrated patients may need additional volume. The administration rate should be determined by the patient’s comorbidities, as well as any additional needs for urgent hydration.
RELIEVE URINE OUTFLOW OBSTRUCTION
Timely relief of obstruction is essential for the return of normal renal function. Permanent loss of renal function develops over the course of
 to  days in the setting of complete obstruction. The risk of chronic kidney disease increases significantly if obstruction is complicated by urinary tract infection. Consider both urethral and ureteral obstruction or sphincter dysfunction as potential causes. For additional discussion of postrenal AKI management, see Chapter , “Acute Urinary Retention.”
FLUID OVERLOAD
Diuretics are the mainstay of treatment for fluid overload in patients with normal kidney function. Fluid overload is associated with increased mortality
 40­42 in patients with AKI. In the absence of fluid overload, diuretics are not recommended for patients with AKI, nor have they been shown to prevent
 40­42,51
AKI. However, diuretics are used in the setting of mild to moderate AKI when fluid overload is present. The alternative to diuretics for the treatment of fluid overload is dialysis, and failure to respond to diuretics is frequently used as an indication for dialysis. A furosemide stress test can be used in the setting of mild AKI (AKIN stage ≤2) to determine diuretic responsiveness as well as to predict worsening renal function. Administer  milligram/kg of furosemide in naive patients or .5 milligrams/kg in those with prior exposure; a urine output of <200 mL over  hours has a sensitivity
52­55  of .1% and a specificity of .1% to predict progression to AKIN stage  AKI (Table 88­1). Mannitol has no role in the treatment of AKI. Low
,41
(“renal”)­dose dopamine does not improve renal recovery or decrease mortality.
HYPERTENSION
Fenoldopam and nicardipine are commonly used in this setting; see Chapter , “Systemic Hypertension,” for a detailed discussion of management.
METABOLIC ACIDOSIS
In cases where the pH is greater than .1, treat the underlying cause of the AKI first. If pH is ≤7.1, consider treatment. Dialysis is preferred in the setting of anuria, or fluid overload, because safe effective use of sodium bicarbonate requires urine flow and ability to tolerate a fluid load. See Chapter ,
“Acid­Base Disorders.”
ELECTROLYTE DISORDERS
Suspected hyperkalemia should be treated in the setting of prolongation of the PR interval, peaked T waves, or widening of the QRS complex; proven hyperkalemia should be treated. For the diagnosis and management of hyperkalemia and other electrolyte abnormalities, see Chapter , “Fluids and
Electrolytes.”
GLOMERULONEPHRITIS
Management includes consultation with nephrology, plan for renal biopsy, corticosteroids, cyclophosphamide, and consideration for
 plasmapheresis.
DISPOSITION AND CONSULTATION
Patients with mild prerenal AKI (AKIN stage 1) are eligible for treatment in ED observation protocols anticipating reversibility of renal dysfunction before discharge. Patients who do not improve or patients with more severe AKI require hospital admission for evaluation and treatment. For patients with severe AKI or for patients with uncertain etiology, nephrology should be consulted.
DIALYSIS/RENAL REPLACEMENT THERAPY
Timing of renal replacement therapy is controversial. The Early Versus Late Initiation of Renal­Replacement Therapy in Critically Ill Patients with Acute
Kidney Injury (ELAIN) Investigators’ study of intensive care unit patients meeting KDIGO stage  criteria with either severe sepsis or fluid overload refractory to diuretics found reduced mortality (39.3% vs. .7%) and improved renal recovery (53.6% vs. .7%) in the group treated with early renal replacement therapy (within  hours of KDIGO stage  diagnosis) versus the group receiving delayed renal replacement therapy (within  hours of
 ,59
KDIGO stage  diagnosis). However, two subsequent meta­analyses that included the ELAIN data found no improved mortality overall. Indications for emergency dialysis or renal replacement therapy are listed in Table 88­7. TABLE 88­7
Indications for Emergent Dialysis or Renal Replacement Therapy
Uncontrolled hyperkalemia (potassium >6.5 mmol/L or rising)
Refractory fluid overload in association with persistent hypoxia or lack of response to conservative measures
Uremic pericarditis
Progressive uremic/metabolic encephalopathy; asterixis, seizures
Serum sodium level <115 or >165 mEq/L (<115 or >165 mmol/L)
Severe metabolic acidosis with concomitant acute kidney injury; treat underlying source of lactic acidosis and tolerate pH >7.2 in setting of permissive hypercapnia
Life­threatening poisoning with a dialyzable drug, such as salicylates, lithium, isopropanol, methanol, or ethylene glycol
Bleeding dyscrasia secondary to uremia
Excessive BUN and creatinine levels: trigger levels are arbitrary; it is generally advisable to keep BUN level <100 milligrams/dL (<37.7 mmol/L), but each patient should be evaluated individually
SPECIAL POPULATIONS
CARDIORENAL SYNDROME
Cardiorenal syndrome is a complex pathophysiologic disorder of the heart and kidneys where acute or chronic dysfunction of one organ induces acute or chronic dysfunction of the other organ. Cardiorenal syndrome type  is characterized by acute deterioration in cardiac function that causes AKI.
Cardiorenal syndrome type  (also called acute renocardiac syndrome) is characterized by an AKI that causes acute cardiac injury and/or dysfunction, such as cardiac ischemia, congestive heart failure, or arrhythmias. Type  and  cardiorenal syndromes are chronic; type  is secondary to a separate systemic condition such as sepsis. Comparing prior serum creatinine and serum B­type natriuretic peptide to the current value can help determine if the acute presentation is more likely due to a primary heart disorder where the B­type natriuretic peptide will be elevated from baseline in a higher proportion than creatinine or due to a primary renal disorder where serum creatinine will be elevated from baseline in a higher proportion than B­type natriuretic peptide.
Treatment includes management of acute decompensated heart failure (see Chapter , “Acute Heart Failure”), with special consideration for the use of ultrafiltration to manage fluid overload. Ultrafiltration is a form of renal replacement therapy primarily used to remove excess fluid. A meta­analysis and systematic review of randomized trials including 608 patients comparing diuretics with ultrafiltration found similar outcomes between groups assessing mortality and risk for renal deterioration.  Most patients in the trials met criteria for AKIN stage ≤2 AKI, with creatinine ranging from .4 to
### .2 milligrams/dL. According to the Heart Failure Society of America, the European Society of Cardiology, and the Canadian Cardiovascular Society,
61­63 ultrafiltration should be reserved for patients refractory to diuretics. See “Furosemide Stress Test” above. Immediate ultrafiltration or other renal replacement therapy should be considered for life­threatening hyperkalemia or pulmonary edema unresponsive to less invasive treatment; otherwise,
 early renal replacement therapy has not been shown to improve survival or renal recovery.
IV CONTRAST IN PATIENTS TAKING METFORMIN
Metformin is one of the most frequently prescribed treatments for patients with type  diabetes mellitus. The most significant adverse effect of metformin therapy is a metformin­associated lactic acidosis, which is most likely to occur in patients who have been prescribed metformin despite an existing contraindication to the drug. Taking a more conservative approach, the U.S. Food and Drug Administration states that metformin should be
 withheld temporarily in patients receiving iodinated contrast media if their GFR is between  and  mL/min/1.73 m and restarted after creatinine
 has been checked  hours after contrast administration, and patients with lower GFRs should have metformin held and not restarted. In contrast, the American College of Radiology has reviewed the data on metformin­associated acidosis following the administration of contrast media and found the complication to be uncommon in patients with normal or near­normal renal function. The American College of Radiology has made the following recommendations. For patients with estimated GFR ≥30 mL/min/1.73 m  , there is no need to discontinue metformin prior to the procedure or following the procedure. For patients with eGFR ≤30 mL/min/1.73 m  , metformin should be withheld at the time of the contrast infusion and for 
 hours after the procedure. The renal function should be reassessed at  hours to determine the safe administration of subsequent metformin therapy.


