## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 31: Vascular Access
Chris Wyatt
INTRODUCTION
Multiple factors determine the route and site for vascular access, and knowing the basic anatomy, techniques, indications, and contraindications is essential.
Infusion rate is key in the resuscitation of those with severe hypovolemia or hemorrhage.1 Flow rates increase with larger catheter radius, use of more pressure (gravity, manual push­pull devices, pressure bag application, or commercial rapid infusing devices), decreasing viscosity (coadministration of crystalloid with viscous blood products), or decreasing catheter length
(peripheral angiocatheter vs. triple­lumen catheter). Maximal flow rates occur from shorter and wide catheters, although both may be hard to achieve.
PERIPHERAL VENOUS ACCESS AND ANATOMY
The most commonly accessed veins for peripheral catheterization of the upper extremity are in the dorsal hand and the antecubital fossa (Figure 31­1).
FIGURE 31­1. Venous anatomy of the upper extremity.
Peripheral catheterization of the superficial veins of the lower extremity is possible, sometimes overlooked, and occasionally more difficult. Avoid IV access of the lower extremity in adults, especially diabetics, due to an increased risk of infection and phlebitis. See discussion below of venous cutdown of the saphenous vein at the medial malleolus.
TECHNIQUE FOR PERIPHERAL VENOUS ACCESS
Gather all equipment before beginning the procedure (Table 31­1). Observe universal precautions. The procedure for peripheral IV line insertion is in Table 31­2. TABLE 31­1
DMoawtenrlioaalsd foerd P e2r0ip2h5er­a7l­ I1V L4i:n4e2 P lPac e Ymoenutr IP is 136.142.159.127
Chapter 31: Vascular Access, Chris Wyatt 
. Terms of Use * Privacy Policy * Notice * Accessibility
Personal protective equipment (gloves, face shield)
Tourniquet
Alcohol swabs or povidone­iodine
Appropriate­sized venous catheter
IV solution and tubing (if indicated)
2×2 gauze
Tape
Sterile transparent dressing
TABLE 31­2
Peripheral IV Line Insertion
Step Comment
. Apply tourniquet. Apply tourniquet tightly enough to facilitate adequate venous filling and distention without causing patient discomfort or ischemia.
. Locate vein. Inspect and palpate the vein.
Warm the skin, tap the vein, or apply topical nitroglycerin ointment to ease identification.
. Clean area with either an alcohol swab or povidone­iodine solution. —
. Apply gentle traction with the nondominant hand to anchor the vein. —
. Insert catheter needle into skin and vessel at a 15­ to 30­degree angle with Peripheral veins are easiest to access at the apex of the “Y” formed by merging veins or where veins are straight for dominant hand. several centimeters.
Use a more obtuse (60­degree) angle for deeper veins.
. Observe for blood flash in catheter hub. This indicates successful vessel penetration.
. Gently advance catheter into vessel lumen until the hub is flush against the See Figure 31­2. skin. If you meet resistance, withdraw the catheter slightly, as it may have penetrated the posterior vessel wall.
. Remove tourniquet. —
. Attach IV tubing and monitor for flow. —
. Secure catheter with tape and a sterile transparent dressing. —
FIGURE 31­2. Catheter­over­needle technique for venous access. A. Catheter needle is inserted into skin and vessel until blood flash. B. Catheter is advanced. C. Needle is withdrawn. D. Catheter is attached to IV tubing and secured.
Avoid venous access through or distal to areas of infection, injuries, or sites of potential vascular disruption (e.g., injury to the inferior vena cava from abdominal trauma). Also avoid using extremities with arteriovenous fistulas or grafts and those in which there have been previous lymph node dissections. If using peripheral access for vasopressors, make sure it is not distal and it is well secured; otherwise, this is safe and effective for the first minutes to hours. Do not use peripheral venous access to administer infusing sclerosing solutions, concentrated electrolyte or glucose solutions, or cytotoxic chemotherapeutic agents.
Flush peripheral catheters with normal saline every  hours, change dressings that are damp or soiled, and change the catheter site every  to  hours.2 Risk of infection and thrombophlebitis increases with time. Assess the skin for signs of infection (erythema) or infiltration (induration, edema). Reassess catheter function and neurovascular status of the distal extremity frequently.
The complications of peripheral venous access are listed in Table 31­3. The first step in treating complications is catheter removal.
TABLE 31­3
Complications of Peripheral Venous Access
Complication Comment
Hematoma formation and pain Prevent hematomas by removing the tourniquet before needle removal and applying direct pressure to site after removal.
Extravasation of fluids Apply cool or warm compresses and elevate extremity.
Monitor site for tissue damage and necrosis.
Phlebitis (vein inflammation) Occurs in 2%–13% of catheterized veins.3,4
Presents as discomfort or pain at the catheter site with warmth, erythema, and tenderness along the vein.
A palpable cord may also be present.
Give anti­inflammatory medications.
Apply warm compresses.
Cellulitis Infection rates with peripheral IVs are relatively low.
Typical organisms include Staphylococcus epidermidis, Staphylococcus aureus, and Candida.
Treat with antibiotics effective against suspected pathogens.
Infection can be reduced by using sterile technique during IV placement and routine handling.
Neurovascular injury —
Bacteremia/sepsis —
Deep vein thrombosis —
Tissue necrosis —
US­GUIDED PERIPHERAL ACCESS
US can localize veins with inconsistent anatomic relationships or those too deep to palpate. US­guided peripheral IV placement results in high success rates, fewer complications, and a decreased need for central vein cannulation.5,6 The cephalic, basilic, and brachial veins, which are not readily palpable, are easily located and cannulated using US guidance. (See Video:
Basilic Vein Cannulation.)
Video 31­1: Basilic Vein Cannulation
Used with permission from O. John Ma; Richard Butler, Department of Emergency Medicine, WakeMed Medical Center.
Play Video
When inserting an IV using US guidance, use a high­frequency linear transducer. Vascular structures are anechoic (black) in US imaging. Key sonographic characteristics help distinguish veins from arteries: Veins are more easily compressed, have thinner walls, and have no arterial pulsation. Color flow also helps differentiate between the two types of vessels. A centimeter scale on the US monitor indicates the depth of the vessel.
To locate a vessel, view it in short axis (transverse plane) and long axis (sagittal plane), and then center the vessel on the screen. The midpoint of the screen correlates with the midpoint of the transducer. Introduce the catheter into the skin at the transducer’s midpoint and direct it toward the vessel lumen. Use a longer catheter (2.5 inches or .4 cm) for deeper vessels. Watch the screen as the catheter enters the vessel lumen; it is best to save an image of the catheter inside the vein. Secure the catheter and apply a sterile dressing to the IV line.
CENTRAL VENOUS ACCESS AND ANATOMY
The indications for central venous catheterization are listed in Table 31­4. In cardiac arrest, the time to insert a central venous catheter creates a tradeoff in drug effectiveness if peripheral venous or intraosseous access exists.
TABLE 31­4
Indications for Central Venous Catheterization
Inability to obtain peripheral access
Access to central circulation needed for procedures (pulmonary artery catheter placement, transvenous pacemaker placement, or urgent hemodialysis)
Measurement of central venous pressure (sepsis, congestive heart failure, pericardial effusion)
Administration of sclerosing medications, continuous vasopressors, concentrated ionic solutions, or cytotoxic chemotherapeutic agents
The most frequent sites used for central venous access are the internal jugular, subclavian, and femoral veins (Figures 31­3 and 31­4). The external jugular vein, a superficial structure, also provides a route to the central circulation but is technically a peripheral site. Femoral vein cannulation is discussed separately below.
FIGURE 31­3. Vascular anatomy of the neck.
FIGURE 31­4. Vascular anatomy of the torso and lower extremities.
The clavicles, first ribs, sternum, sternocleidomastoid, platysma, and other strap muscles of the neck overlie the internal jugular and subclavian veins (Figure 31­3). The internal jugular vein lies lateral to the internal carotid artery inside the carotid sheath. The internal jugular vein joins the subclavian vein to form the brachiocephalic vein.
The subclavian vein crosses under the clavicle at the medial to proximal third of the clavicle. The subclavian artery lies posterior and superior to the brachiocephalic vein. The thoracic duct joins the left subclavian vein at its junction with the left internal jugular vein. The domes of the pleura lie posterior and inferior to the subclavian veins and medial to the anterior scalene muscles.
US TECHNIQUE FOR CENTRAL VENOUS ACCESS
US­guided central venous access increases first attempt success rates and decreases the number of attempts needed for success when compared to the unassisted standard method. The technique of US­guided central venous access is similar to peripheral venous access described previously.
Complications of central venous catheterization are listed in Table 31­5. TABLE 31­5
Complications of Central Venous Catheterization
Pneumothorax
Arterial puncture
Malpositioning
Catheter­associated infection
Thrombosis
Chylothorax (injury to the thoracic duct on left­sided attempts)
Hydrothorax/hydromediastinum (infusion into the pleural space)
Air emboli
Great vessel or right atrial perforation (hemothorax, tamponade)
Airway compromise (tracheal injury, hematoma with airway compression)
Complication rates increase with each additional attempt or percutaneous puncture. Femoral lines have the highest rate of infection, and they thrombose (nearly 20% each in some studies); for these reasons, many avoid this site for longer use. Do not use the subclavian approach in patients with coagulopathy because accidental arterial puncture or injury is not amenable to direct vascular compression.
After gaining consent when possible, identify the access site and approach and position the patient. Prepare all materials before the procedure (Table 31­6). Use a procedure checklist to optimize infection prevention practices. The techniques for all approaches are summarized in Table 31­7 and Table 31­8 and depicted in Figure 31­5. TABLE 31­6
Materials for Central Venous Catheterization
Sterile personal protective gear (gloves, gown, mask, hair cover)
Sterile drape and towels
Sterile prep solution (povidone­iodine or chlorhexidine)
 × 10­mL syringes containing sterile normal saline flush
Central venous catheter set containing:
1% lidocaine, small­gauge needle, and syringe
18­gauge introducer needle
Guidewire
#11 blade scalpel
Venodilator
Single­ or multilumen catheter
 ×  gauze pads
3­0 or 4­0 silk suture with straight needle or with needle driver
Sterile transparent dressing
TABLE 31­7
Preprocedure Checklist for Central Line Access
Before the procedure, did the provider:
Perform a time out to ensure right patient, right location/side?
Cleanse hands immediately prior?
Sterilize procedure site and allow site to dry?
 s for dry site
 min for moist site (femoral)
Drape the patient from head to toe with a large sterile drape?
During the procedure:
Did the provider wear sterile gloves, cap, mask, and gown?
Did assisting physician(s) follow the above precautions?
Did the provider maintain sterility of tray, site, field, and gloves at all times?
Did ALL staff in room wear a mask?
Was unnecessary traffic in and out of the room prevented during the procedure (did the door remain closed)?
After the procedure, did the provider:
Apply a dated sterile dressing?
TABLE 31­8
Seldinger Technique for Insertion of Central Venous Line
Step Comments
. Gown in sterile fashion. Use sterile gloves and gown.
Wear mask and hair covering.
. Identify vessel—US guidance preferred over landmarks. —
. Prep and drape patient using standard sterile procedure. Prep a wide area so an alternate site can be used if initial attempts fail.
Prep the entire ipsilateral neck and upper chest when preparing to insert an internal jugular or subclavian catheter.
. Open the central catheter kit. —
Inspect for content in a sterile fashion.
Place kit close to bedside and operator.
Maintain sterile conditions.
. Anesthetize area in all conscious patients. Inject area with 1%–2% lidocaine.
Anesthetize the periosteum of the clavicle if using the subclavian approach.
Reorient to landmarks after injection.
. Hold the 18­gauge introducer needle on a 10­mL syringe in the dominant hand and align the — needle to the target.
. Advance the needle slowly through the skin and subcutaneous tissue until a flash of dark Maintain steady constant aspiration of syringe.
venous blood appears.
. Stabilize the needle with the nondominant hand. —
. Check for continued free venous flow with aspiration. If no flow is noted, withdraw the needle slightly, as the needle may have breached the posterior vessel wall.
. Remove the syringe attached to the needle and immediately occlude the catheter with a This maneuver helps to prevent introducing air in the catheter and subsequent central system air finger. embolism.
. Insert the guidewire gently through the needle. Always maintain a firm grip on the wire—do The wire should advance with minimal resistance.
not let go of the wire for any reason. Do not force the wire for any reason.
If the wire does not pass easily, reattach the syringe and aspirate to confirm continued venous flow.
Reposition the needle as needed.
Premature ventricular contractions or dysrhythmias during wire advancement may indicate that the wire is in the right atrium or beyond.
. Remove the needle over the wire when the guidewire is inserted at least  cm into the — vessel.
. Incise the skin with a #11 blade scalpel at the entry site to accommodate the venodilator or Do not cut the guidewire.
catheter.
. Advance the dilator or catheter over the guidewire into the vessel lumen with a gentle — twisting motion.
. Remove the dilator (if used), and advance the catheter over the wire until the wire is Maintain a grip on the guidewire during this procedure.
advanced through the distal port.
. Grab the end of the guidewire. —
. Advance the catheter to the appropriate depth. —
. Remove the guidewire. It is easy to “lose” the wire; if you cannot find it after a procedure, immediately obtain a radiograph to seek retention.
. Aspirate and flush all ports to confirm catheter function. —
. Secure catheter with suture and apply a sterile transparent dressing. —
. Confirm catheter placement in the superior vena cava with chest radiograph. A catheter tip in the right atrium can perforate the right atrium and cause hemothorax or hemomediastinum with pericardial tamponade.
Examine the chest radiograph for signs of complications.
FIGURE 31­5. Seldinger technique. A. Needle is inserted through skin and vessel until venous blood is aspirated. B. Guidewire is inserted gently through the needle and advanced. C. Needle is removed over guidewire. D. The skin is incised. E. Dilator or catheter is inserted over the guidewire. F. The guidewire is removed.
EXTERNAL JUGULAR VEIN
The external jugular vein is readily available due to its superficial location in the subcutaneous tissue overlying the sternocleidomastoid muscle. Place the patient in the head­down position or use Valsalva maneuvers to distend the vein and improve visualization. Puncture the skin at a 10­degree angle. Placement is aided by tilting the head to the contralateral side and applying skin traction to “straighten” the course of the vein.
INTERNAL JUGULAR VEIN
The internal jugular vein is easily located with US guidance. The three approaches to internal jugular vein catheterization are central, posterior, and anterior. The right internal jugular vein has a shorter, straighter course to the superior vena cava and avoids injury to the thoracic duct on the left; use this site unless contraindications exist. See Table 31­9 for a summary of approaches to internal jugular vein catheterization. (See Video: Internal Jugular Vein Cannulation.)
Video 31­2: Internal Jugular Vein Cannulation
Used with permission from Sandra L. Werner and Jessica Resnick, Department of Emergency Medicine, MetroHealth Medical Center, Case Western Reserve University School of Medicine.
Play Video
TABLE 31­9
Summary of Approaches to Internal Jugular Vein Catheterization
Landmarks Direction of Aim Depth of Vein (cm)
Central Apex of triangle formed by the clavicle and sternal and clavicular components of the sternocleidomastoid muscle Ipsilateral nipple 1–3
Posterior Lateral aspect of the clavicular portion of the sternocleidomastoid, one third of the distance from the clavicle to the mastoid process Sternal notch 3–5
Anterior Midpoint of the medial aspect of the sternal portion of the sternocleidomastoid, lateral to the carotid artery Ipsilateral nipple 3–5
For the first step, place the probe on the sternocleidomastoid muscle (Figure 31­6). Identify the thyroid gland and carotid artery in addition to the internal jugular vein. Do not attempt needle insertion before visualizing all three structures.
FIGURE 31­6. US­guided localization of the internal jugular vein. US image of the large internal jugular vein and deeper carotid artery. Probe position (A) and corresponding US image (B). CA = carotid artery; IJ = internal jugular vein.
CENTRAL APPROACH
Place the patient in the Trendelenburg position, with head slightly tilted to the contralateral side. The landmark for the central approach is the triangle created by the clavicle and the sternal and clavicular heads of the sternocleidomastoid. The internal jugular vein lies just deep to this triangle. Insert the needle at a 30­ to 45­degree angle to the skin,  cm below the apex of the triangle, parallel to the carotid artery located medially, and directed toward the ipsilateral nipple (Figure 31­7). Successful venous return typically occurs within  to  cm of needle advancement.
FIGURE 31­7. Central approach to the internal jugular vein.
POSTERIOR APPROACH
The landmark for the posterior approach is the lateral aspect of the clavicular portion of the sternocleidomastoid, one third of the distance from the clavicle to the mastoid process. Direct the needle toward the sternal notch (Figure 31­8). Successful venous return typically occurs within  to  cm of needle advancement.
FIGURE 31­8. Posterior approach to the internal jugular vein.
ANTERIOR APPROACH
Identify the pulse and course of the carotid artery, which lies just medial to the site of entry for the anterior approach. Hold the carotid artery with fingers of the nondominant hand. Hold the needle and syringe in the dominant hand at an angle of  to  degrees and enter at the midpoint of the medial aspect of the sternal portion of the sternocleidomastoid muscle. Aim the needle toward the ipsilateral nipple (Figure 31­9). Successful venous return typically occurs within  to  cm of needle advancement.
FIGURE 31­9. Anterior approach to the internal jugular vein.
SUBCLAVIAN VEIN
The location of the subclavian vein allows patient mobility and is an excellent choice for longer­term use. The two traditional approaches to the catheterization of the subclavian vein are the infraclavicular and supraclavicular approaches (Figure 31­10). The infraclavicular approach to US­guided subclavian vein catheter placement is limited by the large acoustic shadow created by the clavicle (Figure 31­11), so surface anatomy is used as the guide. The supraclavicular approach allows good sonographic visualization of the proximal subclavian vein anatomy.
Subclavian vein cannulation by any approach carries the risk of pneumothorax. If attempts at subclavian venous access fail on one side, assess for pneumothorax using a chest radiograph or
US before attempting cannulation on the contralateral side. (See Video: Central Venous Catheter via the Subclavian Vein (Now Entitled Subclavian Cannulation.))
FIGURE 31­10. A. Anatomy of the subclavian vein. B. Cross­section of the subclavian vein with its relation to the clavicle.
FIGURE 31­11. US­guided localization of the subclavian vein. A. Placement of the transducer to facilitate visualization of the internal jugular/subclavian vein junction using a supraclavicular approach. In some patients, a more lateral probe position is required. B. Transverse view of the “venous lake” created by the combined subclavian (SUBCL) vein and internal jugular (IJ) vein.
Video 31­3: Subclavian Vein Cannulation
Used with permission from David Cline and Henderson McGinnis, Department of Emergency Medicine, Wake Forest University Baptist Medical Center.
Play Video
INFRACLAVICULAR APPROACH
Place the patient head down and in a neutral position with a small towel under the thoracic spine to help identify the clavicle. The landmark for the site of entry is the junction of the middle and medial thirds of the clavicle. Orient the bevel of the needle inferomedially to direct the guidewire to the brachiocephalic trunk rather than the internal jugular vein. Align the numbered markings on the syringe with the bevel of the needle to guide the orientation of the bevel once the needle has breached the skin. Place the index finger of the nondominant hand at the suprasternal notch and the thumb at the midpoint of the clavicle. Direct the needle toward the suprasternal notch at a 10­degree angle parallel to the surface of the chest (Figure 31­12). If you hit bone, “walk” the needle down the clavicle until the needle is posterior to it. Successful venous return occurs typically at a depth of  to  cm.
FIGURE 31­12. Infraclavicular approach to the subclavian vein.
SUPRACLAVICULAR APPROACH
The supraclavicular approach is often referred to as the “pocket shot.” The supraclavicular approach has fewer failures, fewer catheter malpositions, and less interference with CPR than the infraclavicular approach. It is possible in the upright position in patients unable to lay supine in the setting of severe orthopnea.
The landmark for entry is  cm lateral to the clavicular head of the sternocleidomastoid and  cm posterior to the clavicle. Enter at an angle of  degrees above horizontal. Orient the bevel of the needle medially, bisecting the angle formed by the clavicle and sternocleidomastoid toward the contralateral nipple. Successful venous return typically occurs at a depth of  to  cm
(Figure 31­13).
FIGURE 31­13. Supraclavicular approach to the subclavian vein.
FEMORAL VEIN
The femoral vein is the most accessible central access site during critical illness, notably cardiac arrest or trauma. It travels in the femoral sheath with the femoral artery, nerve, and lymphatics deep to the medial third of the inguinal ligament. A mnemonic for the anatomy of the femoral structures from lateral to medial is NAVEL: nerve, artery, vein, empty space, and lymphatics.
The femoral vein can be cannulated with the traditional approach, using surface anatomy and palpation as a guide, or by US.
SURFACE ANATOMY APPROACH
Place the patient supine in reverse Trendelenburg position with the hip slightly abducted and leg slightly externally rotated.7,8 Palpate the femoral artery, if possible. Classically, the femoral vein is just medial to the femoral artery and  to  cm below the inguinal ligament, although US often demonstrates an anomalous position, which is one reason why landmark­based insertions are less successful (Figure 31­14). Use a 45­degree angle of approach.
FIGURE 31­14. Technique for femoral vein access.
In pulseless arrest, locate the femoral vein using the “V” technique. Place the thumb on the pubic tubercle and the index finger on the anterior superior iliac spine. The femoral vein is typically located at the interdigital space (the “V” of the finger and thumb) just inferior to the inguinal ligament.
Always insert the needle below the inguinal ligament, because vascular injury above the inguinal ligament may cause hemorrhage into the retroperitoneal space.
Limit femoral vein cannulation because of the higher complication rates (notably infection and thrombosis) and the limits it places on patient mobility.
US­GUIDED APPROACH
Place the transducer in a transverse position just below the midportion of the inguinal ligament. Identify the femoral vein just below the inguinal ligament and medial to the femoral arterial pulsation. The vein is more easily compressed than the artery. The relationship among the vessels varies depending on limb position (Figure 31­15; See Video: Femoral Vein Cannulation).
FIGURE 31­15. US­guided localization of the femoral vein. A. Gentle pressure is applied to the transducer to identify venous structures by their easy compressibility. B. Femoral vein (FV) collapses with compression, and the femoral artery (FA) retains its shape even with compression. C. FV position is seen to vary with hip abduction and external rotation. In neutral position (left frame), the vein is closely opposed to the FA; however, when the hip is abducted and rotated, the vein is displaced from the artery (right frame). [Part A used with permission of Michael Blaivas, MD.]
Video 31­4: Femoral Vein Cannulation
Used with permission from Sandra L. Werner and Jessica Resnick, Department of Emergency Medicine, MetroHealth Medical Center, Case Western Reserve University School of Medicine, Ohio.
Play Video
VENOUS CUTDOWN
Venous cutdown is typically performed on the saphenous vein, anterior and superior to the medial malleolus. It is rarely used due to widespread use of IO techniques and US for peripheral vein cannulation of the upper extremities. To perform a venous cutdown, expose the vein surgically just above the medial malleolus. The vein’s location is predictable after careful dissection through the skin only, and there are no other nearby structures that can be injured. Free  to  cm of the vein, tie the distal portion, and cannulate the proximal portion and connect to an IV line. Place a secure suture around the cannula and proximal portion of the vein. (See Video: Venous Cutdown.)
Video 31­5: Venous Cutdown
Used with permission from David Cline and Henderson McGinnis; David Cline, Department of Emergency Medicine, Wake Forest University School of Medicine, Winston­Salem, North Carolina.
Play Video
IO VASCULAR ACCESS
IO vascular access is possible in patients of all ages when venous access cannot be quickly and reliably established during circulatory collapse.8 The commercial EZ­IO® (Vidacare Corp., San
Antonio, TX) eases procedure performance (Figure 31­16). Contraindications to IO access include proximal ipsilateral fracture, ipsilateral vascular injury, and severe osteoporosis or osteogenesis imperfecta. Complications of IO access include cellulitis, osteomyelitis, iatrogenic fracture or physeal plate injury, and fat embolism (rare). (See Videos: Intraosseous Line
Placement and Intraosseous Line Placement EZ­IO.)
FIGURE 31­16. IO drill device.
Video 31­6: IO Placement Jamshidi Needle
Used with permission from David Cline and Henderson McGinnis, Department of Emergency Medicine, Wake Forest University Baptist Medical Center; David Cline.
Play Video
Video 31­7: IO Placement EZ­IO
Used with permission from Lori J. Whelan, MD; Christopher Tainter, MD RDMS, University of Oklahoma, School of Community Medicine, Tulsa, OK.
Play Video
TECHNIQUE FOR IO ACCESS
Use either a standard bone marrow aspiration needle or specialized IO infusion needle. In children, the site of entry is two finger­widths (2 cm) below the tibial tuberosity on the medial, flat surface of the proximal tibia (Figure 31­17). Use other sites, such as the medial malleolus, distal femur, sternum, humerus, and ileum, in adults because the tibia is thick and difficult to penetrate.
FIGURE 31­17. Location for IO placement in the proximal tibia.
The procedure for manual insertion of IO venous needles is described in Table 31­10 and Figure 31­18. TABLE 31­10
Procedure for Manual IO Venous Access
Prepare site using routine sterile fashion.
Infiltrate area with 1%–2% lidocaine to anesthetize the skin and periosteum if the patient is conscious.
Support and stabilize the leg with the nondominant hand.
Grasp the needle in the palm of the dominant hand.
Direct the needle perpendicular to the bone and away from the joint space (to avoid injury to the physeal plate in pediatric patients).
Twist and apply constant pressure until resistance is abruptly decreased and the marrow cavity is breached.
Remove the stylet.
Confirm placement by either aspiration or continuous infusion.
Observe for signs of extravasation (Figure 31­18).
Secure the IO needle with gauze and a bulky dressing.
Confirm placement and exclude iatrogenic fracture with radiograph after stabilizing the patient.
FIGURE 31­18. Technique for IO placement. A. Needle is directed perpendicular to the bone with constant pressure and a twisting motion. B. Stylet is removed. C. Placement is confirmed with successful aspiration.
ARTERIAL ACCESS
The indications for arterial line placement are provided in Table 31­11. TABLE 31­11
Indications for Arterial Catheter Placement
Frequent laboratory testing, including arterial blood gas sampling for acid­base status or monitoring of oxygen saturations and carbon dioxide levels in patients with respiratory failure
Need for accurate, moment­to­moment blood pressure monitoring in hypotensive patients, patients on vasopressors, or hypertensive patients with intracranial hemorrhages or vascular catastrophes (i.e., aortic dissections, abdominal aortic aneurysms)
RADIAL ARTERY ANATOMY
The most common site for arterial line placement is the radial artery due to the ease of identifying its location and accessibility at the wrist. The collateral artery blood supply provided by the ulnar artery lowers the risk of complications (Figure 31­19). The anatomic landmarks for the radial artery are medial to the radial styloid process and lateral to the flexor carpi radialis tendon at the proximal flexor crease of the wrist. Palpate the radial pulse; many do a radial and ulnar artery compression test (release of latter to assess collateral circulation, looking for hand to “pink up” rapidly—called the Allen test) prior to any puncture, although these do not reliably predict later ischemic complications.
FIGURE 31­19. Arterial anatomy of the wrist and hand. [Reproduced with permission from Reichman EF: Emergency Medicine Procedures, 2nd ed. Chapter . Arterial Puncture and Cannulation. McGraw­
Hill, Inc., 2013, Figure 57­1.]
ALTERNATIVE ARTERIAL SITES
Other sites for arterial catheter placement include the dorsalis pedis artery and the brachial artery. Similar to the radial artery, the dorsalis pedis artery is superficial and easy to identify, and the foot has collateral circulation similar to the hand. The brachial artery is just medial to the biceps brachii muscle in the antecubital fossa adjacent to the medial nerve. Unless absolutely needed, avoid the brachial artery because the lack of collateral blood flow increases the risk of upper extremity ischemia.
TECHNIQUE FOR ARTERIAL ACCESS
After explaining the procedure and gaining consent, identify the access site and approach and position the patient with all materials at the bedside (Table 31­12).
TABLE 31­12
Materials for Arterial Access
Sterile personal protective gear (gloves, gown, mask, hair covering)
Sterile towels
Povidone­iodine or chlorhexidine cleaning solution
1% lidocaine, small­gauge needle, and syringe (e.g., a 1­mL tuberculin syringe)
20­gauge angiocatheter or integral­guidewire arterial catheter
 ×  gauze
3­0 or 4­0 nylon suture with straight needle or needle driver
Sterile transparent dressing
Arterial line setup (pressure bag, saline, tubing, transducer, and flushing system)
The technique for all approaches is provided in Table 31­13 and Figures 31­20, 31­21, and 31­22. The direct puncture approach is less often successful, takes longer, and requires more puncture attempts than the integral wire approach.
TABLE 31­13
Technique for Artery Cannulation
Step Comments
. Position the patient for the procedure. For radial artery approach, the wrist is extended. A towel roll under the dorsal wrist can maintain this position. See Figure 31­20. For femoral artery approach, the hip is slightly abducted and leg slightly externally rotated.
. Gown in standard sterile fashion. Use sterile gloves and gown. Wear mask and hair covering. Do not stand in direct line of the catheter.
. Identify artery using either landmarks or US guidance. A palpable pulse is a must for landmark approach.
Palpate pulse with  fingers of nondominant hand.
. Prep and drape patient using standard sterile procedure. Improper sterile technique increases risk of infection.
. Anesthetize area in all conscious patients. Inject 1% lidocaine with 1­mL tuberculin syringe.
. Hold the 20­gauge angiocatheter or integral­guidewire catheter in the dominant hand at a 30­ For direct angiocatheter cannulation, see Figure 31­21. to 45­degree angle to the skin surface. For use of an integral­guidewire catheter, see Figure 31­22. . Advance the needle slowly through the skin and subcutaneous tissue until pulsatile red — blood return is obtained.
. Stabilize the needle with the nondominant hand. —
. If an integral­guidewire catheter is used, advance the wire with the dominant hand. If resistance is encountered, STOP advancing the guidewire immediately, withdraw the entire unit, and apply pressure to the puncture site.
. Advance the catheter over the needle (or needle and guidewire if used). A gentle rotating motion of the catheter may be helpful.
. Remove the needle or needle­guidewire unit and immediately occlude the catheter with a Occlusion prevents arterial blood loss and air embolism.
finger.
. Attach arterial line setup/IV tubing to the catheter. Be sure to have arterial line setup prepared prior to start of the procedure.
. Secure catheter with suture and apply a sterile transparent dressing. —
. “Zero” the transducer. Align the stopcock to the level of the heart. Turn the stopcock off to the patient and open to air.
Adjust the monitor display to zero.
. Monitor for signs of bleeding, hematoma, or infection. Assess the continued need for the arterial line daily.
FIGURE 31­20. Correct positioning for radial artery cannulation. Flexion of the wrist is supported by a dorsal towel roll. [Reproduced with permission from Reichman EF: Emergency Medicine Procedures,
2nd ed. Chapter . Arterial Puncture and Cannulation. McGraw­Hill, Inc., 2013, Figure 57­5.]
FIGURE 31­21. Direct angiocatheter technique for arterial cannulation. A. The angiocatheter and needle are held at a 30­ to 45­degree angle to the skin with the dominant hand and advanced into the artery.
B. The catheter is advanced over the needle and into the artery with the nondominant hand. [Reproduced with permission from Reichman EF: Emergency Medicine Procedures, 2nd ed.
Chapter . Arterial Puncture and Cannulation. McGraw­Hill, Inc., 2013, Figure 57­7.]
FIGURE 31­22. Integral­guidewire technique for arterial cannulation. A. The integral­catheter unit is held at a 30­ to 45­degree angle to the skin and slowly advanced into the artery. B. The guidewire is advanced through the needle and into the artery with the nondominant hand. C. The catheter is advanced over the guidewire and into the artery with a gentle twisting motion. [Reproduced with permission from Reichman EF: Emergency Medicine Procedures, 2nd ed. Chapter . Arterial Puncture and Cannulation. McGraw­Hill, Inc., 2013, Figure 57­8.]
Secure the arterial catheter to the skin either by suture or adhesive catheter locking device with a sterile transparent protective dressing placed over the site. An arm board or wrist splint may aid securing a radial artery line. Monitor the site regularly for dislodgment, hematoma, bleeding, infection, or distal ischemia. Change the dressing regularly, and check for complications
(Table 31­14).
TABLE 31­14
Complications of Arterial Access and Cannulation
Pain at site
Hematoma formation
Hemorrhage
Artery laceration/injury
Arterial vasospasm
Pseudoaneurysm formation
Arteriovenous fistula
Infection
Limb ischemia
Thrombosis/embolization
Nerve damage/neuropathy
Air embolization from an arterial catheter is more likely to have adverse sequelae to whatever tissue is downstream compared to similar area venous catheterization because of no pulmonary filtration. Infection rates increase with poor aseptic technique and duration of catheter use. Thrombosis occurs in up to 25% of patients with an arterial catheter, although clinical morbidity occurs in less than 1%. Neuropathies can occur from direct nerve injury from cannulation attempts or hematoma formation causing nerve compression. The first step in treating all complications is catheter removal. Apply direct pressure for a minimum of  to  minutes after removal at all peripheral sites and  minutes for a femoral site.
US­GUIDED ARTERIAL ACCESS
US­guided arterial puncture aids cannulation, especially when a palpable pulse is difficult to identify.9 Key sonographic characteristics to identify arteries include round, pulsatile, thickwalled vessels that are difficult to compress. (See Video: Radial Artery Cannulation.)
Video 31­8: Radial Artery Cannulation
Used with permission from Sandra L. Werner and Jessica Resnick, MetroHealth Medical Center, Department of Emergency Medicine, Cleveland, Ohio.
Play Video


