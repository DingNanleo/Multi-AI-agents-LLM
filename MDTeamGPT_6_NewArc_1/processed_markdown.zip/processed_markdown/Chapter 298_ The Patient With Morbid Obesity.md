## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 298: The Patient With Morbid Obesity
Joanne Williams
INTRODUCTION AND EPIDEMIOLOGY
Since 1980, worldwide obesity has more than doubled. In 2008, more than .4 billion adults, age  and older, were overweight. Of these, over 200 million men and nearly 300 million women were obese. Sixty­five percent of the world population resides in countries where overweight and obesity
 kill more people than underweight. In 2010, more than  million children under the age of  were overweight.
In children, an age­ and sex­specific percentile for body mass index (BMI) determines weight status rather than the BMI categories used for adults, because children’s body composition varies as they age and varies between boys and girls.
The Centers for Disease Control and Prevention uses a BMI threshold of above the 85th percentile to define overweight and above the 95th percentile to define obese, compared to children of the same age and sex.  The World Health Organization defines overweight as a BMI ≥25 kg/m  , whereas obesity is defined as a BMI ≥30 kg/m  . 
Care for bariatric surgery patients is discussed in Chapter , “Complications of General Surgical Procedures.”
PATHOPHYSIOLOGY
,4
Obesity is an independent risk factor for acute coronary syndrome, especially in those <40 years old. Atypical symptoms may pose a problem with
,6  acute coronary syndrome diagnosis. Approximately 11% of cases of congestive heart failure are attributable to obesity alone. The physical deconditioning of obesity manifests with orthopnea, dyspnea, and lower extremity swelling mimicking acute congestive heart failure. Plain chest radiograph findings of congestive heart failure may be obscured by redundant overlying soft tissue and hypoventilation artifact. Brain natriuretic
,9 210 peptide levels are lower in the obese patient than in the nonobese. Cardiomyopathy may affect up to 10% of patients with a BMI >40 kg/m . Obesity
  is a risk factor for venous thromboembolism and its recurrence once anticoagulation therapy is withdrawn.

The increased prevalence of type  diabetes is closely linked to the upsurge in obesity. Excess weight accounts for 90% of type  diabetes. Obesity is
 strongly associated with insulin resistance in normoglycemic persons and in individuals with type  diabetes.
15­17
The accumulation of fat impairs the function of ventilation in obese children and adults. Reductions in forced expiratory volume in  second,
,16  forced vital capacity, total lung capacity, functional residual capacity, and expiratory reserve volume are associated with increasing BMI.
Obesity is a well­recognized risk factor for obstructive sleep apnea. Forty percent of people who are obese have obstructive sleep apnea, and
 approximately 70% of people with obstructive sleep apnea are obese.
Increased fat deposition in the pharyngeal area along with reduced operating lung volumes associated with obesity reduce upper airway caliber,
 modifying airway configuration, which in turn increases upper airway collapsibility. Thus, airways are predisposed to repetitive closure during sleep.

Daytime sleepiness increases and may be associated with accidental trauma.
Cor pulmonale and hypercapnic respiratory failure are common. Obesity hypoventilation syndrome (Table 298­1) was first described over  years
,22 22­24 ago. The most common symptoms are (1) respiratory failure, (2) severe hypoxemia, (3) hypercapnia, and (4) pulmonary hypertension.
TABLE 298­1
Diagnostic Criteria for Obesity Hypoventilation Syndrome

Chapter 298: The Patient With Morbid Obesity, Joanne Williams 
. Terms of Use * Privacy Policy * Notice * Accessibility
Body mass index  kg/m2
Daytime PaCO2 >45 mm Hg
Associated sleep­related breathing disorder (obstructive sleep apnea–hypopnea syndrome or sleep hypoventilation or both)
Absence of other known causes of hypoventilation
Abbreviation: PaCO2 = partial pressure of arterial carbon dioxide.
ESTIMATING PATIENT WEIGHT

The Broselow tape inaccurately predicts actual weight in one third of children. The significance of this inaccuracy has not been studied in depth. A
 weight­estimation formula based on mid­arm circumference is reliable for use in school­age children and may be an alternative to the Broselow tape.
The formula is as follows: weight (kg) = (mid­arm circumference [cm] – 10) × . When compared to the Argal, Advanced Pediatric Life Support, and Best

Guess formulas, Krieser et al found that parental estimation of weight was more accurate.
The concern for equipment weight capacity in the adult patient with obesity is an important determination for imaging. Scales in most EDs have a maximum weight capacity of 150 kg. Mechanized beds that weigh patients are not common in the ED but are a consideration for equipment. Patients with obesity tend to significantly underestimate their own weight. A variety of formulas are available to estimate weight in adults who are obese using
 height and waist, hip, and arm circumference. The formula developed by Crandall et al seems to require the least amount of time and patient manipulation. Two distinct formulas for nonpregnant females and males have been developed as follows:
SPHYGMOMANOMETRY
Improper blood pressure cuff width and circumference will artificially elevate pressure readings. The standard adult blood pressure cuff is too short for patients with an arm circumference of  cm or larger. Patients who are overweight or obese will require cuffs larger in size.
The American Heart Association recommends the following cuff widths when evaluating blood pressure in patients who are obese: (1) for arm circumferences ranging from  to  cm, a bladder measuring  cm in width is needed; (2) for circumferences from  to  cm, the bladder width
,30 should be  cm; and (3) in patients with short upper arm length, a 16­cm­wide cuff should be used.
MEDICATION DOSING
Little evidence­based literature is available for appropriate dosing in obesity, and nearly none is available in the obese child. Fortunately, many drugs used in resuscitation are not lipophilic, and lean body mass is a reasonable dosing guide. Altered physiology is characterized by an increased clearance of hydrophilic drugs, a larger volume of distribution for lipophilic drugs, and a decrease in lean body mass and tissue water content, as compared to
 their lean counterparts. Altered mechanics can predispose the morbidly obese to systemic toxicity due to either overdosing or lack of efficacy from
,33 underdosing.
A weight­based medication schedule uses ideal body weight, total body weight, or dosing weight to avoid systemic side effects and lack of clinical
 efficacy by underdosing. Ideal body weight according to the Devine formula is as follows:
Dosing weight is an adjusted body weight of overweight or obese patients and is used only for drugs for which there are recommendations specifying that the actual body weight should be adjusted to use in the dose calculation.

Table 298­2 divides select drugs into ideal body weight, total body weight, and dosing weight dosing. Fentanyl and the benzodiazepines are lipophilic and have a prolonged half­life in obese patients. With these drugs, the initial dose based on total body weight may be needed, but
 subsequent doses should be based on ideal body weight. It is best to check with a pharmacist for specific dosage regimens.
TABLE 298­2
Dosing of Select Drugs
Dosing Drugs
Ideal body Penicillins, cephalosporins, linezolid, corticosteroids, H ­blockers, digoxin, β­blockers, atracurium, vecuronium, fentanyl*, midazolam*,
 weight lorazepam*, phenytoin, propofol
Total body Succinylcholine, rocuronium, unfractionated heparin, enoxaparin, vancomycin weight
Dosing weight Aminoglycosides, fluoroquinolones
*Initial dose based on total body weight.
VASCULAR ACCESS
Vascular access is problematic. Patients who are critically ill and morbidly obese patients require fluid administration often guided by central venous
 pressure and urine output. Central venous pressure placement is extremely challenging even for the most skilled physician. In the obese patient, the distance from skin to vessel is much farther than normal, anatomic landmarks are obscured (Figure 298­1A and B), and the angle of approach may be too steep to allow cannulation even after reaching the vessel. There is no clear consensus as to the preferable site and approach to central venous
 catheterization. In general, there is an increased incidence of infection and deep venous thrombosis when using the femoral approach. If this proves to be the only option, then use this site.
FIGURE 298­1. A and B. Difficulties in landmark identification.
The internal jugular vein can be accessed with equal success to the subclavian approach in patients who are obese. The success rate might be
 increased with the head maintained in the neutral position, thereby reducing the risk of overlap of the internal jugular vein over the carotid artery.

A US­guided 15­cm catheter can be used to cannulate the brachial or basilic vein. Another approach is the use of a pediatric central venous catheter placed into the basilic vein. The pediatric central venous catheter is  cm (3.15 in.) in length, is a double­lumen catheter, and has 18­ and 20­gauge
 lumens. Longer catheters can also be considered to guard against inadvertent dislodgement.
IMAGING
Attenuation severely limits the image quality of plain radiographs (Figure 298­2). Increasing exposure time can improve the image but at the expense of increased radiation. Motion artifact increases with increased exposure time. Multiple cassettes may be required if the patient is too large for a single

 × 17–inch film. Patients may be able to stand for plain radiography if too large for the tables.
FIGURE 298­2. Attenuation can blur findings on plain radiographic films.
CT and MRI scanners have both patient weight and girth limits, consider patient shoulder and pelvis girth. Newer CT scanners can accommodate up to
660 lb. If the patient outweighs equipment capacity, consider transferring the patient to an institution with a larger­capacity scanner, or veterinary schools may be an option. Most standard MRIs have a maximum shoulder­to­shoulder width of  inches (137 cm) and weight limits of 300 to 350 lb
(136 to 159 kg), although open MRI scanners can sometimes be an option for large body diameters.
Diagnostic peritoneal lavage has been suggested as an option in the patient with obesity and blunt abdominal trauma who is too large for imaging
 equipment ; however, many surgeons are no longer accustomed to making decisions based on results, and in the morbidly obese patient, diagnostic peritoneal lavage is difficult to perform.
PROCEDURAL SEDATION
Give procedural sedation drugs and pain medications cautiously. Select doses at the lower end of the range, and titrate to effect. Local and regional
 anesthesia might be considered for complicated or prolonged procedures.
AIRWAY MANAGEMENT

Difficulty with mask ventilation, rapid oxygen desaturation, and altered pharmacokinetics can make airway management challenging. Impedance to airway management is caused by excess fatty tissue externally on the breast, neck, thoracic wall, and abdomen and internally in the mouth, pharynx,
 and abdomen. First­attempt success is significantly less in obese patients.
Patients who are obese have increased intra­abdominal pressure and increased incidence of hiatal hernia and gastroesophageal reflux disease. These
,46 characteristics render patients more prone to aspiration during airway management.
Patients who are obese will desaturate more rapidly after preoxygenation than their lean counterparts. When no cervical spine injury is suspected,
 desaturation may be partially prevented by keeping the patient in a 25­degree head­up position during preoxygenation.
Two­person bag­valve mask with a two­handed bilateral jaw thrust is recommended in patients who are morbidly obese. If tolerated, an oral airway may be used to prevent the tongue from occluding the airway. The early use of noninvasive positive­pressure ventilation may abate the need for endotracheal intubation. High expiratory positive pressures may be needed.
Obesity is not a contraindication for rapid­sequence intubation. Advance preparation is critical, and assessment for a potential difficult airway is of
 utmost importance.
The “sniffing” position results in suboptimal positioning for laryngoscopy in patients who are obese, and this may also confound results and falsely
 worsen graded views. The “ramping” position (Figure 298­3A) offers improved intubation conditions in patients who are morbidly obese compared to the “sniffing” position (Figure 298­3B). This position is achieved by placing multiple folded blankets under the upper body, head, and neck until
 the external auditory meatus and the sternal notch are horizontally aligned. Another option is elevating the patient’s head and thorax with the intubation physician standing on a stool behind the patient and essentially intubating with the patient semi­upright (see Chapter 29A, “Tracheal
Intubation”, Figure 29A­3).
FIGURE 298­3. The ramping position (A) is more effective for intubation than the sniffing position (B) in patients with morbid obesity.
First give consideration to awake intubation, given that patients who are obese may be difficult to mask ventilate and rapid oxygen desaturation may
251­53 occur after the ablation of spontaneous ventilation, especially in patients with a BMI greater than  kg/m . The awake intubation may be performed either by the nasotracheal or orotracheal routes.
The relative benefits and risks of the awake intubation approach must be weighed against the merits of rapid­sequence intubation, which reduces risk of aspiration, improves intubating conditions, and results in easier insertion of advanced and rescue airway devices. During rapid­sequence intubation, the chance for first­pass success can be optimized by video laryngoscopy. The intubating laryngeal mask airway is effective in obesity and
 should be readily available because surgical access to the airway may be difficult. The bougie is a good rescue device.
Percutaneous and open surgical access to the airway may be difficult when landmarks are obscured by excess soft tissue and a short neck in the

“cannot intubate, cannot ventilate” scenario. Obesity and a short neck are associated with difficult transtracheal needle ventilation and retrograde
,57 tracheal intubation. However, in the elective surgical airway management setting, cricothyroidotomy is technically feasible even in patients with
 difficult neck anatomy caused by obesity.
Until the proper size tracheostomy tube is located, a 6­mm­inner­diameter endotracheal tube passed through a cricothyroidotomy incision may serve
 as a temporizing measure. There is limited literature concerning the success rates of surgical airways in patients in the emergency setting. Even in an
  ideal setting, cricothyroidotomy requires more than 100 seconds to achieve ventilation, and most clinicians rarely perform the procedure.
With respect to ventilator management, calculate initial tidal volume using ideal body weight and begin with volumes of  to  mL/kg of ideal body
,62 weight. See Chapter 29B, “Mechanical Ventilation,” for detailed discussion of mechanical ventilation.
TRAUMA

Victims of motor vehicle accidents who are obese (BMI >31 kg/m ) have significantly more rib fractures, pelvic fractures, pulmonary contusions, and
 extremity fractures and fewer head and liver injuries. Even with seatbelt and airbag use, risk of death for morbidly obese patients was .52 times
 greater than that in nonmorbidly obese patients.
Mildly overweight patients, not the morbidly obese, are less prone to intra­abdominal injury because of the protective effect of the abdominal fat,
 known as the “cushion effect.”


