## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 66: Lung Empyema and Abscess
Sharon E. Mace; Eric Anderson
EMPYEMA
INTRODUCTION AND EPIDEMIOLOGY
Empyema is pus in the pleural space. A parapneumonic effusion is a pleural effusion associated with a lung infection, usually pneumonia but infrequently a lung abscess. Bacterial pneumonia with a parapneumonic effusion is the most common precursor, seen in about 60% of empyema
 patients. Other causes of empyema are complications of chest surgery (22%), trauma (4%), esophageal perforation (4%), complications of chest tube/thoracentesis (4%), an extension from a subdiaphragmatic infection (3%), and assorted triggers (7%), including a hemothorax, chylothorax, or
,2 hydrothorax that becomes infected due to a systemic infection with hematogenous spread such as septicemia.
Of the approximately  million pneumonia patients hospitalized each year in the United States, 20% to 40% develop a parapneumonic effusion; 5% to
,4 
10% of patients with a parapneumonic effusion develop an empyema. Mortality in adults is about 20%. With the advent of antibiotics, the incidence of empyema decreased in the first half of the 20th century, but since the 1990s, the incidence of empyema has increased in the United States and
,6 worldwide.
Predisposing factors for empyema include aspiration (and the conditions causing this event, notably altered swallowing), respiratory disease impairing ciliary function, immunocompromise, malignancy, IV drug abuse, alcoholism, diabetes, gastroesophageal reflux disease, and poor oral
 hygiene.
CLINICAL FEATURES
Suspect empyema if symptoms of pneumonia (fever, cough, dyspnea, pleuritic chest pain, and malaise) do not resolve with therapy. The onset of
 empyema may be insidious, with patients appearing chronically ill with weight loss, anemia, and night sweats.

Physical examination findings include decreased breath sounds, dullness to percussion, decreased tactile fremitus, and occasionally a friction rub.
Pain from an underlying effusion or empyema may cause splinting with respiration. If there is an underlying pulmonary infection, rales or rhonchi may exist.
DIAGNOSIS
Diagnostic criteria for empyema are aspiration of grossly purulent material on thoracentesis and at least one of the following: thoracentesis fluid with a positive Gram stain or culture, pleural fluid glucose <40 milligrams/dL, pH <7.2, or lactate dehydrogenase >1000 IU/L. For empyema from tuberculosis, absolute lymphocyte count on pleural fluid is useful, although other markers such as interferon release assays or adenosine deaminase
  show promise. Pleural biopsy is diagnostic in 55% to 70% of patients, demonstrating a granuloma and/or being culture positive.
A pleural­based opacity on a chest radiograph, including a lateral decubitus film, suggests a pleural effusion or empyema. POCUS accurately identifies pleural effusions and empyemas, differentiates a loculated effusion from a mass, and guides thoracentesis and chest tube placement. A chest CT scan with IV contrast can assess for a loculated effusion or empyema and identify any other abnormalities present.
TREATMENT
,8
The definitive treatment of an empyema is drainage and antibiotics. In addition, treat any underlying disease, especially pneumonia. NSAIDs or oDpoiwoindlso acadne dd e2c0r2e5a­s7e­ p1l e5u:2ri2t iPc p Yaionu. rT hIPo risa c1e3n6te.1s4is2 a.1n5d9 d.1ra2i7nage aid in the diagnosis and provide symptomatic relief for dyspnea. The common
Chapter 66: Lung Empyema and Abscess, Sharon E. Mace; Eric Anderson 
,9  organisms in empyema stratified by associated pathology are listed in Table 66­1. In about 40% of cases, cultures are negative, and anaerobic
. Terms of Use * Privacy Policy * Notice * Accessibility species are particularly difficult to culture. Newer molecular analysis or nucleic acid amplification technology may lead to a higher detection rate for the underlying pathogen(s).
TABLE 66­1
Common Organisms in Empyema and Associated Pathology2,9
Pathology Organism
Pneumonia Streptococcus pneumoniae
Staphylococcus aureus
Pneumonia (unimmunized with Haemophilus influenzae type B vaccine) H. influenzae
Lung abscess Mixed oropharyngeal anaerobes
Aspiration pneumonia S. aureus
Recent thoracotomy Gram­negative bacilli
Chest trauma S. aureus
Gram­negative bacilli
Contiguous abdominal infection Gram­negative bacilli
Anaerobes
Esophageal rupture Mixed oropharyngeal organisms
Postprocedure Methicillin­resistant S. aureus
Pseudomonas
Hospital­acquired empyema Methicillin­resistant S. aureus
Pseudomonas
Pneumonia in the setting of human immunodeficiency virus Tuberculosis
Fungal infections
The choice of antibiotics depends on the clinical presentation, local patterns, and results of diagnostic studies including cultures. Most antibiotics have
 adequate penetration into the pleural space with the exception of the aminoglycosides. The detection of an aerobic organism does not preclude
 antibiotic coverage for anaerobes because there is a 23% incidence of mixed aerobic and anaerobic infections, according to one study. Thus, empiric antibiotic coverage usually includes anaerobic coverage as well as coverage for other pathogens as indicated by the clinical situation, at least initially until culture results are known.
Choices for empiric therapy for anaerobes include a β­lactam with β­lactamase activity, such as piperacillin­tazobactam or ampicillin­sulbactam, a carbapenem, or clindamycin. Options for gram­negative aerobic pathogens are a second­ or third­generation cephalosporin plus metronidazole, a carbapenem, or a β­lactam aminopenicillin with β­lactamase activity (e.g., piperacillin­tazobactam or ampicillin­sulbactam). There are many antibiotic options for gram­positive organisms including a β­lactam, with the exception of coverage for methicillin­resistant Staphylococcus aureus, which requires vancomycin or other antibiotics that cover methicillin­resistant S. aureus. In patients with postprocedure or hospital­acquired empyema, consider coverage for methicillin­resistant S. aureus and Pseudomonas aeruginosa. Initial therapy often consists of two antibiotics to cover both
Staphylococcus and anaerobes; monotherapy with a penicillin derivative or metronidazole is inadequate coverage. After initial drainage of the empyema plus IV antibiotics, switch to oral agents until there is clinical and radiographic improvement. Modify empiric antibiotics once culture results return and the clinical course is apparent.
Fibrinolytics (e.g., urokinase, alteplase, or streptokinase) can improve drainage of loculated parapneumonic effusions and empyemas. The Multicenter
,14
Intrapleural Streptokinase Trial (MIST)  used intrapleural streptokinase, and MIST  used alteplase and DNAase for pleural infection. The results
15­17 are mixed, making fibrinolytics an option that may lessen the frequency of later surgical intervention. A blinded randomized trial comparing double placebo, alteplase and DNase, alteplase and placebo, or DNAase and placebo found that DNase alone or alteplase alone was ineffective, but the
 combination of alteplase and DNase improved fluid drainage, decreased the frequency of surgical referral, and decreased the length of hospital stay.

About one third of patients treated with antibiotics and chest tube drainage need surgical drainage. The MIST  found no difference in mortality or need for thoracic surgery between large (15F to 20F), medium (10F to 14F), or small (<10F) tubes, but did report that pain was much decreased with the
 smaller tube sizes. Video­assisted thoracoscopic surgery allows debriding of empyemas that fail tube thoracostomy drainage and antibiotic therapy.
Video­assisted thoracoscopic surgery can be followed by or converted to a thoracotomy if pleural fluid drainage remains insufficient.
LUNG ABSCESS
INTRODUCTION AND PATHOPHYSIOLOGY
Lung abscess is characterized by localized necrosis of the lung parenchyma and is typically caused by suppurative microbial infection. Initial infection is usually caused by aspiration of oral contents. Type  Streptococcus pneumoniae and S. aureus are major causes of lung abscess, with an increasing
 frequency of Klebsiella pneumoniae infection. In a Japanese study, Streptococcus spp. (59.8%), anaerobes (26.2%), and Gemella spp. (9.8%) all
 existed in community­acquired lung abscesses. Mycobacterium tuberculosis and Actinomycetes spp. were more common in lung abscesses that
 extended to the chest wall.

Primary lung abscess can occur in individuals in good health or in those prone to aspiration. Approximately 80% of lung abscesses are primary, and
,20,21 the overall reported mortality rate varies between 1% and .2%. Secondary lung abscess is associated with malignancy, immunosuppression, extrapulmonary infection, sepsis, or complications of surgery. The mortality rate in secondary lung abscess is often >50%. Lung abscesses present for

<1 month are termed acute, and those present for >1 month are chronic.
Lung abscess may also develop as a result of hematogenous spread of infectious material to the lung parenchyma or complicating lung infarction.
Think of hematogenous spread from another infectious focus, such as endocarditis, in those with multiple lung abscesses. Other less common causes of pulmonary abscess include penetrating chest trauma or fungal and parasitic infections. Primary and metastatic neoplasms and inflammatory conditions such as Wegner’s granulomatosis and sarcoidosis may also manifest as pulmonary cavitary lesions and become infected (Table 66­2).
TABLE 66­2
Cavitary Lung Lesions
Infectious
Bacterial Anaerobic abscess
Aerobic abscess
Infected bullae
Tuberculosis
Actinomycosis
Pleural empyema
Fungal Coccidioidomycosis
Histoplasmosis
Blastomycosis
Aspergillosis
Cryptococcus
Parasitic Echinococcosis, Entamoeba histolytica
Amebiasis, Paragonimus westermani
Neoplastic Bronchogenic carcinoma (squamous cell or adenocarcinoma)
Metastatic cancer (colorectal or renal)
Lymphoma or Hodgkin’s disease
Inflammatory Sarcoidosis
Wegener’s granulomatosis
Other Foreign body aspiration
CLINICAL FEATURES
Lung abscess typically has an indolent course, with patients presenting after  to  weeks of symptoms. Symptoms include cough, fever, pleuritic chest pain, hemoptysis, weight loss, and night sweats. The development of the infection is slow, so fever, tachycardia, and tachypnea are often absent. The cough may or may not be productive.
DIAGNOSIS
Chest radiograph may show an area of dense consolidation or an air­fluid level inside of a cavitary lesion, indicating that the abscess cavity communicated with a bronchiole. Bronchiole communication occurs in most patients with lung abscess. Chest CT will diagnose cavitary lesions with and without bronchiolar communication. Conditions that may appear cavitary on a chest radiograph include infected bullae, pleural fluid collection with bronchopleural fistula, loop of bowel extending through a diaphragmatic hernia, hiatal hernia, and objects lying on or behind the patient at the time of the radiograph. Causes of other cavitary lung lesions are noted in Table 66­2. Laboratory results are nonspecific.
TREATMENT
After stabilization of immediate life­threatening conditions, the next step is usually antibiotic therapy. Empiric therapy targets anaerobes and
 facultatively anaerobic streptococci. Ampicillin­sulbactam,  grams IV every  hours, or a carbapenem (imipenem, meropenem) are appropriate
,22  choices. Clindamycin is another option but is often avoided due to the risk of subsequent infection with Clostridium difficile. Clindamycin plus a
 cephalosporin is another option.
Drainage usually occurs spontaneously from communication of the abscess cavity with the tracheobronchial tree. This is signaled by the development of an air­fluid level on the chest radiograph.
Patients who fail to respond to antibiotics are candidates for percutaneous or transbronchial drainage or open drainage of the abscess cavity.

Approximately 11% to 21% of lung abscesses require surgical or percutaneous drainage. The overall success rate of percutaneous drainage of lung
 abscess is 84%, with a complication rate of 16%. Percutaneous abscess drainage with CT or US guidance is a simple method to drain the abscess
 cavity and provides more accurate material for culture of causative organism. Transbronchial drainage carries the complication of possible contamination of the unaffected lung. Open surgical techniques can resect the lung abscess.
DISPOSITION
Admit patients with newly diagnosed lung abscesses for antibiotic treatment. Reserve surgical interventions for large or complicated abscesses or for those failing antibiotic treatment (Table 66­3).
TABLE 66­3
Reasons for Medical Treatment Failure in Lung Abscess
Bronchial obstruction: neoplasm, foreign body
Nonbacterial cause: neoplasm, fungi, vasculitis, pulmonary sequestration
Large cavity size: >6 cm diameter
Empyema
Mycobacteria


