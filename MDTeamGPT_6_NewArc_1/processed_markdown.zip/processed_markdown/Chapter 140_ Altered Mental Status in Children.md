## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 140: Altered Mental Status in Children
Melisa S. Tanverdi; Sarah A. Mellion
INTRODUCTION
Altered mental status in children is characterized by the failure to respond to verbal or physical stimulation in a manner appropriate to the child’s developmental level. The ED incidence of altered mental status in children varies widely depending on the type of institution reporting, the patient
,2 population served, and the specific definition of altered mental status used. Children with altered mental status require simultaneous stabilization, diagnosis, and treatment. The objectives of treatment are to sustain life and prevent irreversible CNS damage. Once the patient is resuscitated, the goal is to determine the cause and stop disease progression.
PATHOPHYSIOLOGY
Arousal is mediated by the neural pathways of the ascending reticular activating system that project from the brainstem to the hypothalamus, thalamus, and cerebral cortices. The ascending reticular activating system regulates wakefulness in response to the environment, as well as homeostasis, cardiovascular, and respiratory functions. Altered mental status occurs through dysfunction of the ascending reticular activating system,
,4 an insult to bilateral cerebral cortices, or global depression of the central nervous system. There are many factors that can cause dysfunction in the ascending reticular activating system and cerebral hemispheres, including inadequate substrate for metabolic demand, insufficient blood flow,
 presence of toxins or metabolic waste products, or alterations of body temperature. Typical causes of bilateral cortical impairment are toxic and metabolic states that deprive the brain of normal substrates.
There are multiple pathologic conditions that affect awareness and arousal; etiologies can initially be described as traumatic or nontraumatic.
Nontraumatic causes can be further divided into structural and functional lesions. Structural lesions can be categorized as supratentorial or subtentorial. Signs and symptoms of supratentorial lesions include focal motor abnormalities, which are often present from the onset of the altered level of consciousness. Subtentorial lesions lead to reticular activating system dysfunction, in which prompt loss of consciousness is common. Cranial nerve abnormalities are frequent, and abnormal respiratory patterns are seen. Functional etiologies include infectious/inflammatory, metabolic/nutritional/toxic, and neurologic/psychiatric disorders. Depressed consciousness is typically seen before motor signs become depressed,
 and when present, motor deficits are typically symmetric.
CLINICAL FEATURES AND APPROACH
The spectrum of alteration of mental status ranges from confusion or delirium (disorders in perception) to lethargy, stupor, and coma (states of decreased awareness). A lethargic child has decreased awareness of self and the environment. Patients may be aroused from an apparent deep sleep, but they immediately relapse into a state of minimal responsiveness. A stuporous child has decreased eye contact, decreased motor activity, and unintelligible vocalization. Stuporous patients can be aroused with vigorous noxious stimulation. Comatose patients are unresponsive and cannot be
 aroused by verbal or physical stimulation, such as phlebotomy, arterial catheterization, or lumbar puncture.
Rapidly assess and support the airway, ventilation, and circulation. When the patient is stabilized, take a methodical and comprehensive history
(Table 140­1). Ask about the prodromal events before the change in consciousness as well as recent illnesses or infectious exposures, and determine the likelihood of trauma, abuse, or ingestion. Inquire about antecedent fever, headache, head tilt, abdominal pain, vomiting, diarrhea, gait disturbance, seizures, drug ingestion, palpitations, weakness, hematuria, weight loss, and rash. For infants and young children, review developmental milestones. The medical, immunization, and family histories are important in children of all ages. Be alert for any inappropriate responses,
,7 inconsistencies, or delays in seeking care that may arouse suspicion for child abuse (see Chapter 150, “Child Abuse and Neglect”).
DoTwABnLloEa 1d4e0­d1 2025­7­1 6:13 P Your IP is 136.142.159.127
Chapter 140: Altered Mental Status in Children, Melisa S. Tanverdi; Sarah A. Mellion 
Important Historical Elements for Evaluating Altered Mental Status in Children
. Terms of Use * Privacy Policy * Notice * Accessibility
Prodromal events Recent illnesses or infectious exposures
History of recent trauma
Risk factors Medications in the home
Social environment
Vaccinations
Family history
Developmental milestones
Associated symptoms
Constitutional Fever, weight loss
GI Vomiting, diarrhea, abdominal pain
Neurologic Headache, gait changes, seizure activity, weakness
Cardiac Palpitations
Musculoskeletal Head tilt
Dermatologic Rash
Proceed with a general examination only after respiratory, cardiac, and cerebral stabilization. The objectives of the examination are to identify occult infection, trauma, toxicity, or metabolic disease. The neurologic examination should document the child’s response to sensory input, motor activity, pupillary reactivity, oculovestibular reflexes, and respiratory pattern. Although several coma scales have been published, such as the Modified
Pediatric Glasgow Coma Scale (see Chapter 110, “Pediatric Trauma,” and Chapter 111, “Minor Head Injury and Concussion in Children”), the most simplified and functional scale in an emergency setting is the AVPU scale (Table 140­2). The Glasgow Coma Scale lacks good interobserver reliability
 and reproducibility and does not accurately predict outcomes in individual patients. The AVPU score has been validated and is currently
 recommended by the Pediatric Advanced Life Support guidelines. The A, V, P, and U values correspond to Glasgow Coma Scale scores of , , , and

, respectively.
TABLE 140­2
AVPU Score
A = Awake
V = Responds to verbal stimuli
P = Responds to pain
U = Unresponsive
After obtaining a comprehensive history and performing a complete physical examination, including thorough neurologic examination, anticipate and
 carefully observe for improvement or deterioration.
DIAGNOSIS
Once the child is stabilized, the history and physical should suggest either a medical disorder or structural lesion. The mnemonic AEIOU TIPS
(alcohol, encephalopathy, insulin,opiates, uremia, trauma, infection, poisoning, and seizure) is a useful tool for organizing the diagnostic possibilities of altered mental status in children (Table 140­3). If a metabolic cause is suspected, obtain serum electrolyte levels, renal and hepatic function studies, serum ammonia, CBC, and coagulation studies (see Chapter 146, “Metabolic Emergencies in Infants and Children”). If the history or examination suggests a toxic ingestion, obtain serum levels of suspected agents and a urine toxicology screen. Consider trial of an antidote, if available. Obtain arterial blood gas analysis, CBC, and pulse oximetry in cases of trauma, respiratory distress, or suspected acid­base imbalance.
Obtain a 12­lead ECG and provide continuous cardiac monitoring if there are pathologic auscultatory findings, rhythm disturbance, or suspected toxin exposure. For serious bacterial infection, obtain blood and urine cultures. Correct shock, hypotension, and hypoxia before attempting lumbar puncture (see Chapter 119, “Fever and Serious Bacterial Illness in Infants and Children”).
TABLE 140­3
AEIOU TIPS: A Mnemonic for Pediatric Altered Mental Status
A Alcohol. Ethanol. Isopropyl alcohol. Methanol. Concurrent hypoglycemia is common.
Acid­base and metabolic. Hypotonic and hypertonic dehydration. Hepatic dysfunction, inborn errors of metabolism.
Arrhythmia/cardiogenic. Stokes­Adams, supraventricular tachycardia, aortic stenosis, heart block, pericardial tamponade.
E Encephalopathy. Reye’s syndrome. Parainfectious encephalomyelitis. Autoimmune encephalitis, such as Anti­N­methyl­D­aspartate (Anti­
NMDA) receptor encephalitis.12 Posterior reversible encephalopathy syndrome (PRES) may be associated with hypertension, autoimmune disease, and Henoch­Schönlein purpura (HSP).13
Endocrinopathy. Addison’s disease can present with AMS or psychosis. Thyrotoxicosis can present with ventricular dysrhythmias.
Pheochromocytoma can present with hypertensive encephalopathy.
Electrolytes. Hypo­/hypernatremia and disorders of calcium, magnesium, and phosphorus can produce AMS.
I Insulin. AMS from hyperglycemia is seen in severe diabetic ketoacidosis, as well as hyperglycemic hyperosmolar syndrome. Hypoglycemia can be the result of many disorders. Irritability, confusion, seizures, and coma can occur with blood glucose levels <40 milligrams/dL (2.22 mmol/L).
Intussusception. AMS may be the initial presenting symptom.
O Opiates. Common household exposures are to Lomotil® (diphenoxylate hydrochloride and atropine sulfate), Imodium® (loperamide), diphenoxylate, and dextromethorphan. Clonidine, an α­agonist, can also produce similar symptoms.
Oxygen. Disorders of airway, breathing, or circulation may adversely affect oxygen delivery to the brain; hypercapnia from primary lung disease or neurologic dysfunction also may result in AMS.
U Uremia. Hemolytic­uremic syndrome can produce AMS in addition to abdominal pain. Thrombocytopenic purpura and hemolytic anemia also can cause AMS. In children with chronic renal failure, neurologic dysfunction may develop secondary to stroke, hypertension, or metabolic derangements.
T Trauma. Hypovolemia or hemorrhage from multisystem trauma may lead to insufficient cerebral perfusion and result in AMS. Consider concussion, hemorrhage, contusion, epidural or subdural hematoma. Consider nonaccidental trauma.
Tumor. Primary, metastatic, or meningeal leukemic infiltration. Intracerebral tumors commonly produce focal neurologic signs, and posterior fossa tumors typically block the ventricular system and create signs and symptoms of hydrocephalus. Shunt malfunction should be considered among patients with a ventriculoperitoneal shunt for hydrocephalus.
Thermal. Hypo­ or hyperthermia. Progressive hypothermia leads to insidious AMS.
I Infection. Bacterial meningitis, encephalitis, and brain abscess usually present with fevers. Brain abscess is characterized by fever and headache before AMS changes. Presenting symptoms also include generalized or focal seizures. Any systemic infection associated with vasculitis or shock may lead to AMS secondary to cerebral hypoperfusion.
Intracerebral vascular disorders. Subarachnoid, intracerebral, or intraventricular hemorrhages can be seen with trauma, ruptured aneurysm, or arteriovenous malformations. Venous thrombosis can follow severe dehydration or pyogenic infection of the mastoid, orbit, middle ear, or sinuses. Arterial thrombosis is uncommon in children, except in those with homocystinuria. Intracerebral and intraventricular hemorrhages may follow birth asphyxia or trauma in neonates, but in older children, they may signify a congenital or acquired coagulopathy.
Cerebral emboli from bacterial endocarditis may cause AMS. Acute confusional migraine may be associated with profound alterations in consciousness. Children with sickle cell anemia can develop cerebral thrombosis, status epilepticus, and coma.
P Psychogenic. Characterized by decreased responsiveness with normal neurologic examination including oculovestibular reflexes. Psychogenic unresponsiveness may be a conversion reaction, an adjustment reaction, a panic state, or malingering.
Poisoning/ingestion. Drugs, toxins, or illicit substances can be ingested by accident, through neglect or abuse, or in a suicidal gesture.
Intentional ingestion of recreational drugs, including synthetic cannabinoids, may be considered.14
S Seizure. Generalized motor seizures and absence status epilepticus are often associated with prolonged unresponsiveness in children.15 In a child with a history of seizures who presents with AMS, consider nonconvulsive status epilepticus. Febrile seizures are seen in children aged  months to  years.
Abbreviation: AMS = altered mental status.
The clinical scenario directs imaging. Immobilize the cervical spine and radiograph the cervical spine if spine injury is suspected or in the case of multiple system trauma. If an intracranial lesion is suspected or if there are focal neurologic signs, obtain a noncontrast CT scan of the head. If vascular injury is a possibility, consider CT angiography of the head and/or neck. A chest radiograph confirms or clarifies examination findings and documents endotracheal tube placement. Abdominal radiographs are indicated to assess for acute ingestion of radiopaque material. Abdominal US may be useful to screen for cases of intussusception (see Chapter 133, “Acute Abdominal Pain in Infants and Children”).
Other studies that may be useful in specific cases are serum osmolality, blood alcohol level, thyroid function tests, blood lead level, and skeletal survey for suspected abuse. Electroencephalogram will evaluate for nonconvulsive status epilepticus.
TREATMENT
Treatment principles are outlined in Table 140­4. Begin with airway, breathing, and circulation, and administer 100% oxygen until adequate oxygenation is confirmed. For suspected increased intracranial pressure, elevate the head of the bed to  degrees. Establish an IV and give normal saline to restore and/or maintain perfusion. Obtain a stat point­of­care glucose and treat hypoglycemia. If the history or the exam suggests
 opiate toxicity, give naloxone. For suspected meningitis, give antibiotics and/or acyclovir.
TABLE 140­4
General Treatment of Altered Mental Status
Assess airway, breathing, and circulation.
Immobilize cervical spine for suspected trauma.
Initiate continuous pulse oximetry; consider capnometry; administer oxygen.
Give dextrose for hypoglycemia; for children, give 25% dextrose in water  mL/kg IV; for newborns, give  mL/kg of 10% dextrose in water.
Provide fluid resuscitation,  mL/kg of isotonic crystalloid, and repeat to total of  mL/kg as needed.
Administer broad­spectrum antibiotics for suspected sepsis or meningitis.
Give naloxone for suspected opiate or clonidine overdose, .01 to .1 milligram/kg IV every  min.
Administer flumazenil for suspected pure benzodiazepine overdose, .01 milligram/kg IV.
Control seizures with benzodiazepines (lorazepam, .1 milligram/kg IV; diazepam, .1 milligram/kg IV; or midazolam, .1 milligram/kg IV).
Prevent/treat hypothermia with heat lamps during resuscitation; treat hyperthermia.
DISPOSITION AND FOLLOW­UP
Once the patient is stabilized, the child should be observed until his or her mental status improves. The patient’s clinical condition and specific
 disorder dictate whether further management can occur on the inpatient unit or in an intensive care unit. Only patients with transient, reversible causes may be treated, monitored in the ED, and discharged after observation and a return to their baseline mental status. Patients who are discharged (e.g., those with a closed head injury or simple febrile seizure) should receive disease­specific discharge instructions. Children who are evaluated for altered mental status and discharged home should have a repeat evaluation within  hours of discharge.


