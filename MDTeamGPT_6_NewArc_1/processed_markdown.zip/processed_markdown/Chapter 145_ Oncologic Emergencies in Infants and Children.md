## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 145: Oncologic Emergencies in Infants and Children
Jessica A. Bailey; Megan Mickley
INTRODUCTION
Children and adolescents develop different types of cancers than adults. The 5­year survival rate for all childhood (0 to  years of age) cancers in the

United States has been steadily increasing and is currently 83% to 84% ; however, malignant neoplasms remain the second leading cause of death for

U.S. children age  to  years. The most common childhood malignancies are discussed below.
LEUKEMIA
EPIDEMIOLOGY
Acute leukemias, including acute lymphoblastic leukemia (ALL) and acute myelogenous leukemia (AML), are the most common cancers in children,
3­6 accounting for over a quarter of all malignancies. Chronic leukemias are rare in children and adolescents. ALL accounts for approximately 75% to
4­7
80% of pediatric leukemias and, if diagnosed early, carries a 5­year survival rate of 85% to 90% in developed countries. The peak incidence of ALL is 
 to  years of age, with younger children having the best outcomes. In the United States, ALL is more common in boys and more common in white and
2­5
Hispanic children than in African American children. A number of inherited risk factors, including trisomy , are well documented.
,6,9
AML accounts for approximately 15% to 20% of childhood and adolescent leukemias in the United States. Cure rates have improved to 57% to 70%
,9 but remain lower than those for ALL. Relapsed AML accounts for greater than half of all childhood leukemia­related deaths. Incidence of AML peaks
,6 in the first  years of life. Environmental exposures, including chemotherapy agents and radiation received during treatment of other childhood cancers, are known causes of secondary AML. Patients being treated for AML have a higher incidence of complications than those with ALL, especially infections. This is primarily due to the greater intensity of chemotherapeutic regimens necessary to achieve remission.
CLINICAL FEATURES
Most signs and symptoms of acute leukemia are due to bone marrow infiltration by blasts, as well as infiltration of extramedullary sites. A detailed history may reveal nonspecific constitutional symptoms: fever, fatigue, anorexia, and weight loss. Cytopenias from marrow infiltration can present as pallor, easy bleeding/bruising with petechiae and ecchymoses, infections, or bone pain. The reticuloendothelial system is the most common site of extramedullary infiltration, manifesting as hepatomegaly, splenomegaly, and/or lymphadenopathy.
Other sites include the CNS and testes.
Consider leukemia in cases of recurrent or severe unexplained epistaxis or other mucosal bleeding or in children with unusually extensive or abnormally located bruising. Concerning symptoms include abnormal blood counts, a history of nighttime pain, and recurrent or persistent bony
 complaints. Bone and joint pain may present as limping or refusal to walk. In rare cases of AML, solid nodules of leukemic blasts (chloromas) may be noted, most commonly in the skin (leukemia cutis) or gingiva. For a subset of patients, diagnosis is made incidentally during an evaluation for infection, lymphadenopathy, priapism, or other presentations.
DIAGNOSIS
Evaluate suspected leukemia with a CBC with differential count, a peripheral smear, a coagulation profile, a type and screen, and serum chemistries including calcium, phosphate, magnesium, uric acid, liver function studies, and lactate dehydrogenase. Obtain a chest radiograph, because some children with T­cell ALL can have an anterior mediastinal mass of leukemic cells. If fever or clinical suspicion of infection is present, obtain a blood and
 urine culture. Although almost all children with leukemia have some form of hematologic abnormality including anemia,
Chapter 145: Oncologic Emergencies in Infants and Children, Jessica A. Bailey; Megan Mickley thrombocytopenia, leukocytosis, or neutropenia, very few have an extremely elevated WBC. Total WBC counts are often normal or only
. Terms of Use * Privacy Policy * Notice * Accessibility
 moderately elevated. Hyperleukocytosis is more likely in patients with AML and in infants with either ALL or AML. Definitive diagnosis requires a bone marrow aspirate.
The differential diagnosis of children with marrow suppression includes aplastic anemia, profound iron deficiency anemia (commonly noted in toddlers with excessive milk intake), viral infections (e.g., Epstein­Barr virus, cytomegalovirus, parvovirus B19), primary immune thrombocytopenia, and rheumatologic diseases. A good rule of thumb is that leukemias commonly involve abnormalities in more than one cell line, whereas other conditions are often restricted to a single cell line.
TREATMENT
The goal is to induce remission while minimizing treatment toxicity. Taking into consideration age and leukocyte count at the time of diagnosis, as well as other risk factors (e.g., genetic abnormalities of leukemic cells with important prognostic significance), children with ALL are usually stratified into
 different treatment groups. Children with AML receive intensive multiagent chemotherapy. Some receive hematopoietic stem cell transplantation.
,14
Molecularly targeted therapeutic approaches are in development.
DISEASE COMPLICATIONS
Most children suspected of having leukemia are stable and receive an initial diagnostic workup (see “Diagnosis” section) but no acute treatment.
Occasionally, acute treatment is needed for cytopenias, hyperleukocytosis, coagulopathy, electrolyte abnormalities, and infection. Initiate treatment after consultation with a pediatric oncologist.
Anemia
Anemia is extremely common and multifactorial, including impaired hematopoiesis due to leukemic marrow infiltration, decreased erythropoietin levels, iron deficiency, hemolysis, occult blood loss, and chronic inflammation. There is no universally recommended threshold for transfusion, and in
 the ED, the decision to transfuse should depend more on the appearance and clinical condition of the child than on any particular laboratory value.
Life­threatening hemorrhage, symptomatic anemia, or rapidly consumptive coagulopathy requires transfusion, with the addition of factor replacement as needed. The general goals of transfusion therapy are to raise the hemoglobin level to >8 to  grams/dL, depending on the child’s
 condition. However, in the setting of profound anemia and hyperleukocytosis, transfuse to a much lower level to minimize the effect on blood viscosity. The exact numbers will often depend on institutional protocols (see discussion on transfusion under “Blood Products”).
Thrombocytopenia

Mild to moderate bruising, petechiae, and/or mucosal bleeding may occur with platelet counts <20,000/mm , but the risk of spontaneous intracranial
 hemorrhage is extremely low until the platelet count dips to <5000/mm . Most protocols reserve prophylactic platelet transfusions in
 asymptomatic patients to platelet counts <10,000/mm in the absence of other bleeding risk factors. Invasive procedures require a
  platelet count >40,000 to ,000/mm .
Blood Products
A unit of packed red blood cells has a volume of about 250 mL and a hematocrit of 70% to 80%. The typical volume of packed red blood cells given to a child is  to  mL/kg. Generally,  mL/kg of packed red blood cells are expected to raise the hemoglobin level  grams/dL in a patient without active hemorrhage.
,17
A dose of platelets is .1 unit/kg random donor equivalent units and is expected to raise the platelet count by ,000 to ,000/mm . Some institutions release platelets as single apheresis units versus random donor units. Platelets express ABO antigens, and even though platelets do not express Rh antigens, Rh­negative donors are used for Rh­negative patients because red blood cell contamination may result in Rh alloimmunization.
Rh immunoglobulin can be given if Rh­negative platelets are unavailable. Institutions vary on the use of type­specific platelets and the need for Rh immunoglobulin (Table 145­1).
TABLE 145­1
Transfusion of Blood Products in Children
Blood Product Typical Transfusion
Volume Dose
Component Goals* Packed red blood cells Citrate phosphate dextrose adenine,  unit =  mL/kg increases Hb by  grams/dL Hb, 8–10 grams/dL
250 mL†
Adsol,  unit = 350 mL† .5–15.0 mL/kg increases Hb by  grams/dL
Platelets One apheresis unit = 200–400 mL‡ .1 unit/kg increases platelets by ,000– ,000–100,000/mm3
,000/mm3
Fresh frozen plasma  unit = 200–250 mL (centrifuged)  mL/kg will replace ~50% of most coagulation factors
 unit = 500 mL (apheresis)
Cryoprecipitate  unit =  mL .1 unit/kg increases fibrinogen by ~50 Fibrinogen, 100 milligrams/dL# milligrams/dL
 unit = 80–100 units factor VIII
 unit = 150–200 milligrams fibrinogen
Abbreviation: Hb = hemoglobin.
*Varies by clinical circumstance.
†The volume in a single unit of packed red blood cells depends on the additive/preservative used.
‡
The random donor platelet unit is used when there is a shortage of apheresis units. A single random donor unit contains a volume of  to  mL. One apheresis unit = 6–8 random donor units.
#In the absence of ongoing bleeding.
There are several product choices for packed red blood cells and platelets: irradiated, leukocyte reduced, and cytomegalovirus seronegative (Table
145­2). Irradiation of blood products is recommended for profoundly immunosuppressed individuals (e.g., severe immunodeficiency, high­dose chemotherapy, post–bone marrow transplant). Many pediatric cancer centers will transfuse only irradiated blood to all oncology patients. Consult with the pediatric oncologist for specific directions before administering blood products.
TABLE 145­2
Blood Component Therapy
Treatment Description Goal Target Recipient
Leukodepleted .9% reduction in Reduces incidence of febrile nonhemolytic transfusion Patients likely to receive multiple platelet or blood donor WBCs reactions packed red blood cell transfusions in future
Decreases sensitization to HLA­1 antigens
Significantly reduces transmission of CMV* CMV­ Gold standard for CMV­ Eliminates transmission of CMV* Patients at high risk for CMV­related seronegative negative blood complications now or in the future blood
Irradiated Destroys donor Prevent transfusion­associated graft­versus­host disease Profoundly immunocompromised patients blood lymphocytes’ ability to from donor WBCs (does not prevent CMV transmission) Stem cell transplant patients multiply
Abbreviations:CMV = cytomegalovirus; HLA­1 = human leukocyte antigen . *Patients at high risk for CMV­related complications include patients receiving stem cell or solid organ transplants and the severely immunocompromised.

Hyperleukocytosis is a WBC >100,000/mm . Leukocytosis can cause leukostasis, tumor lysis syndrome, and disseminated intravascular
 coagulation. Leukostasis is a clinical diagnosis. Intravascular aggregations of leukocytes lead to injury of many organs, most commonly the lungs and CNS. In the cerebral circulation, symptoms and signs include headache, mental status changes, visual changes, seizures, and stroke
(ischemic and hemorrhagic), whereas in the pulmonary circulation, leukostasis can cause dyspnea, hypoxemia, and respiratory failure. Chest radiographs may be normal or may show a diffuse, nonspecific interstitial infiltrate. AML patients are especially at risk because their leukemic blasts are larger, “stickier,” and more rigid.
ED treatment consists of aggressive IV hydration and treatment of tumor lysis syndrome (see discussion in “Tumor Lysis Syndrome” section and Table
145­4). Avoid treatments that increase blood viscosity such as diuretics and packed red blood cell transfusions. Platelets do not
 increase blood viscosity and should be administered for levels <20,000/mm to decrease the risk of cerebral hemorrhage. Leukapheresis is a temporizing measure until definitive antileukemic therapy can be given.
Disseminated Intravascular Coagulation
Disseminated intravascular coagulation is commonly associated with AML. Some subtypes release a procoagulant tissue factor that can lead to a lifethreatening consumptive coagulopathy. ED treatment includes replacement of platelets, depleted coagulation factors, fibrinogen with fresh frozen plasma, and cryoprecipitate.
HODGKIN’S LYMPHOMA
EPIDEMIOLOGY
Hodgkin’s lymphoma is a lymphoid neoplasm characterized by progressive enlargement of lymph nodes. Age distribution is bimodal, with peaks in
 young adulthood and older­aged adults. It is the most common malignancy in adolescents age  to  years. Risk factors include Epstein­Barr virus
(particularly in developing countries) and human immunodeficiency virus.
CLINICAL FEATURES AND DIAGNOSIS
Hodgkin’s lymphoma typically presents with painless, firm, “rubbery” lymph nodes, usually cervical or supraclavicular (Figure 145­1). If empiric antibiotics are prescribed for presumptive cervical adenitis, the mass continues to increase in size. The lack of overlying erythema and the absence of pain suggest lymphoma. Systemic “B” symptoms (fever >38°C [100.4°F], night sweats, and weight loss ≥10% over  months) are present
,20 in 39% to 50% of children and adolescents. Two thirds of pediatric patients will present with mediastinal involvement, which may manifest as
 cough, stridor, dysphagia, or dyspnea. Hepatomegaly or splenomegaly can be found due to hematogenous spread. Initial ED diagnostic studies should include lab evaluation similar to that of ALL, with the addition of a chest radiograph. Diagnosis is confirmed by lymph node biopsy. A CT of the soft tissues of the neck, chest, abdomen, and pelvis will help delineate the extent of disease. Subdiaphragmatic primary disease is uncommon; more
 than 97% of Hodgkin’s lymphoma patients present with a lesion above the diaphragm.
FIGURE 145­1. Hodgkin’s lymphoma. A 13­year­old adolescent male presented with a painless, rubbery, firm cervical lymphadenopathy of  months’ duration.
[Reproduced with permission from Shah BR, Lucchesi M: Atlas of Pediatric Emergency Medicine, © 2006, McGraw­Hill, Inc., New York.]
The differential diagnosis of cervical lymphadenopathy is extensive. See Chapter 125, “Neck Masses in Infants and Children.”
TREATMENT
ED treatment before confirmatory diagnosis is usually directed at acute complications such as superior vena cava syndrome or upper airway compression (see “Complications of Pediatric Cancer and Oncologic Emergencies” section). Use caution with sedation, given the risk of airway compromise with mediastinal involvement.Do not give steroids to patients with significant lymphadenopathy if lymphoma is in the differential diagnosis. Following risk categorization, therapeutic management of Hodgkin’s lymphoma incorporates chemotherapy and radiotherapy.
NON­HODGKIN’S LYMPHOMA
EPIDEMIOLOGY
Non­Hodgkin’s lymphoma accounts for 7% of cancer in children and adolescents in the United States, with a male predominance but little variation by
 age. Non­Hodgkin’s lymphoma includes a heterogeneous group of malignant neoplasms that can originate not only in the lymphatic system but also in almost any organ in the body, including the skin, cortical bone, GI tract, and CNS. The majority of cases have no known cause, although immunodeficiencies and previous exposure to immunosuppressive agents are known risk factors. In equatorial Africa, non­Hodgkin’s lymphoma
 accounts for almost 50% of childhood cancers and is almost universally associated with Epstein­Barr virus.
CLINICAL FEATURES AND DIAGNOSIS
The clinical presentation depends on the site and extent of disease. Constitutional symptoms are not common. Lymphadenopathy, a mass in virtually any location, hepatosplenomegaly, and cytopenias can all be seen. GI manifestations occur with abdominal tumors (usually Burkitt’s lymphoma).
Mediastinal involvement may lead to pleural or pericardial effusions, upper airway obstruction from mass effect, respiratory symptoms, or superior vena cava syndrome. Testicular, skin, and CNS or spinal manifestations are seen, but less commonly. The differential diagnosis is broad and includes infectious (tuberculosis, toxoplasmosis, Epstein­Barr virus, Bartonella henselae, human immunodeficiency virus) and oncologic (Hodgkin’s lymphoma, leukemia, rhabdomyosarcoma) processes. Diagnosis is by lymph node biopsy.
TREATMENT
Initial workup should include basic laboratory studies and a chest radiograph to evaluate for mediastinal disease. If there is concern for intraabdominal obstruction (bowel or ureteral), US or abdominal/pelvic CT may be indicated. A chest CT can further evaluate for chest mass or superior vena cava syndrome. The mainstay of treatment is multiagent chemotherapy.
CENTRAL NERVOUS SYSTEM TUMORS
EPIDEMIOLOGY

CNS tumors are the second most common pediatric cancer, accounting for approximately 21% of all childhood cancer diagnoses. They are also the
,24 leading cause of cancer­related death in children, with survival rates lowest for young children. For the emergency physician, the specifics of the tumor type are less important than tumor location and clinical effects.
The three most common categories of pediatric CNS tumors are astrocytomas, medulloblastomas, and ependymomas. Specific genetic syndromes, including neurofibromatosis, tuberous sclerosis, and Li­Fraumeni syndrome, are predisposing factors. CNS tumors can also be secondary to highdose cranial radiation for a previously treated childhood cancer.
CLINICAL FEATURES AND DIAGNOSIS
There is heterogeneity in the presentation of CNS neoplasms depending on the extent of the tumor, its location, and the age of the child. In children, tumors are more often infratentorial than supratentorial. Symptoms are often nonspecific (headache, irritability, emesis, behavioral changes), which can delay diagnosis.
The classic presentation of a posterior fossa tumor or other tumors causing obstructive hydrocephalus is early morning headacheand subsequent vomiting. These symptoms are believed to be due to a rise in intracranial pressure during sleep caused by increased cerebral blood volume in the recumbent position as well as hypoventilation with resultant hypercarbia and increased cerebral blood flow. Additional clinical signs such as a bulging fontanelle, rapidly increasing head circumference in an infant, sunsetting (preferential downward gaze due to obstructive dilatation of the third ventricle with resultant tectal pressure and paresis of upward gaze), cranial nerve palsies (usually sixth nerve), papilledema, or somnolence
 also suggest increased intracranial pressure. Infiltration of the brainstem can produce cranial nerve deficits, long tract corticospinal motor weakness, and cerebellar ataxia.
Symptoms of supratentorial neoplasms are dictated by location and may include headache, declines in school performance, personality changes, motor weakness, and seizures. Craniopharyngiomas arise in the sellar region and produce visual changes due to their proximity to the optic chiasm, as well as significant endocrinologic abnormalities from hypothalamic dysfunction (including diabetes insipidus, stunted growth and sexual development, and hypothyroidism).
Most CNS malignancies are identifiable on CT, but MRI provides superior visualization of tumors, particularly in the posterior fossa.
TREATMENT
Treatment of the most serious and life­threatening brain tumor threat—increased intracranial pressure leading to herniation—is addressed in the section “Complications of Pediatric Cancer and Oncologic Emergencies.” In the ED setting, manage acute seizures and consider giving IV dexamethasone to treat vasogenic edema surrounding the tumor. Consult with neurosurgery and pediatric oncology to arrange definitive treatment.
NEUROBLASTOMA
EPIDEMIOLOGY
Neuroblastoma is a malignant tumor that arises from primitive ganglion cells of the sympathetic nervous system. It accounts for 7% of all childhood
 cancers and is the most common neoplasm in the first year of life.
CLINICAL FEATURES
The clinical features are highly variable and depend on tumor size and location. Neuroblastoma may arise anywhere along the sympathetic nervous system. The adrenal gland is the most common primary site, but it may also arise from other intra­abdominal sites, the chest, or the neck. Metastasis is
 quite common to adjacent lymph nodes, liver, skin, bone, and bone marrow.
The variability in tumor location and extent explains the array of signs and symptoms that may lead to the diagnosis of neuroblastoma. Painless abdominal masses can lead to compression of the bowel, bladder, venous, or lymphatic structures. Compression from thoracic masses can cause respiratory distress or superior vena cava syndrome, while paravertebral tumors can invade the spinal canal, causing spinal cord compression.
Horner’s syndrome (ptosis, miosis, and anhidrosis) may result from disease involving the superior cervical ganglion.
Unique presentations of neuroblastoma that require a high index of suspicion include proptosis and periorbital ecchymoses
(“raccoon eyes”) or swelling, characteristic of orbital metastases. Opsoclonus­myoclonus is a paraneoplastic syndrome also highly associated with occult neuroblastoma.
DIAGNOSIS AND TREATMENT
Obtain basic laboratory studies. Cytopenias suggest bone marrow involvement. Radiographs, US, or CT may detect an intra­abdominal or thoracic mass. Because neuroblastomas often lead to increased levels of catecholamines, the metabolites of which are detectable in the urine, urine homovanillic acid and vanillylmandelic acid can aid in diagnosis. Bone marrow and tumor biopsies confirm the diagnosis.
Treatment includes surgical resection and/or radiation therapy and chemotherapy. Select patients undergo stem cell transplant.
WILMS’ TUMOR (NEPHROBLASTOMA)
EPIDEMIOLOGY

Wilms’ tumor, or nephroblastoma, is a malignant embryonal renal tumor that affects children predominantly under the age of  years. Overall survival
 rates are excellent, at approximately 90%.
CLINICAL FEATURES
The classic presentation of Wilms’ tumor is an asymptomatic abdominal mass, sometimes noted while dressing or bathing the child. As opposed to neuroblastoma (given that the age group and abdominal mass at the time of presentation can be similar), children often appear remarkably well with
 no systemic symptoms. Hypertension due to increased renin production is present in 25% of cases. There can be mass effect from the tumor, leading to respiratory distress or intra­abdominal obstruction. Less common symptoms include anorexia, weight loss, emesis, or hematuria. Metastases at the time of diagnosis are uncommon but can occur to the lungs, liver, or lymph nodes.
DIAGNOSIS AND TREATMENT
Obtain basic laboratory studies, urine catecholamines to rule out neuroblastoma, and urinalysis. Obtain a chest radiograph to identify pulmonary metastases (Figure 145­2). Ultrasonography is appropriate for initial abdominal imaging in the ED, although vigorous or excessive palpation of the mass can cause tumor rupture. CT or MRI identifies the extent of the disease. Definitive treatment is surgical resection and chemotherapy, with or without radiation therapy.
FIGURE 145­2. Wilms’ tumor. A. A 7­year­old child presented with a huge abdominal mass and respiratory distress. Pelvic CT scan followed by laparotomy confirmed the mass as Wilms’ tumor. Because of the retroperitoneal location of the kidney, these tumors can be quite large at diagnosis without significant impingement of other vital structures. B. Right­sided pleural effusion due to metastatic disease. Almost complete opacification of the right hemithorax with mediastinal shift to the left. [Reproduced with permission from Shah BR, Lucchesi M: Atlas of Pediatric Emergency Medicine, © 2006, McGraw­Hill,
Inc., New York.]
RETINOBLASTOMA
EPIDEMIOLOGY

Retinoblastoma is the most common pediatric intraocular malignancy, with 90% of cases diagnosed in children <3 years old. There are both heritable
 and nonheritable forms. The retinoblastoma (RB) gene was the first tumor suppressor gene discovered in the human genome. Heritable forms are usually due to a germline mutation in the RB1 gene and present within the first year of life with bilateral disease. The majority of cases of nonheritable disease are unilateral.
CLINICAL FEATURES
Leukocoria (“white pupil”), in which the white light reflects off of the tumor instead of red light reflecting off of the retina, is the most common presenting sign (see Figure 122­12). This may be noted by a primary physician or occasionally by family members when they note the leukocoria in photographs. Other signs may include strabismus, decreased visual acuity, redness, pain, glaucoma, and proptosis (late stage). Young children do not
 often report visual complaints. The retinoblastoma can spread into the surrounding orbit, as well as metastasize into the CNS and viscera.
DIAGNOSIS AND TREATMENT
If leukocoria or other signs suggestive of an intraocular tumor are noted, consult ophthalmology in the ED. Definitive diagnosis is usually obtained by exam and imaging under anesthesia. Obtain a CT or MRI if there is evidence of orbital inflammation. Treatment options depend on the extent of the
 disease and include enucleation, chemotherapy, cryotherapy, brachytherapy, thermotherapy, radiotherapy, and laser photocoagulation.
GERM CELL TUMORS
EPIDEMIOLOGY
Germ cell tumors are a heterogenous group of neoplasms that can develop at any age, although they are more common in adolescents and young
 adults. Extragonadal tumor locations, including sacrococcygeal, mediastinal, and intracranial, are more common in young children, whereas during
 and after puberty, the primary location is the gonads.

Testicular germ cell tumors are the most common solid tumor in young adult men (Figure 145­3). An undescended testicle increases the risk
 for testicular cancer 10­ to 50­fold. Prognosis for these tumors is extremely good, even if metastases are present, with an overall cure rate of

85% to 90%. Despite that fact, they remain a significant cause of death in young males. This highlights the importance of encouraging young male patients to perform testicular self­examinations.
FIGURE 145­3. Testicular tumor. This patient presented with a painless left testicular mass highly suspicious for cancer. [Photo contributed by Patrick McKenna, MD.
Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, Inc., New
York.]

The median age of diagnosis for ovarian germ cell tumors is  to  years. Due to the intra­abdominal location, ovarian tumors may go undetected
 for a longer amount of time than testicular tumors; this increases the potential for rupture.
CLINICAL FEATURES
Testicular tumors typically present with an asymptomatic, nontender testicular mass. Ovarian tumors are most likely to present with abdominal pain

(85%). Other ovarian symptoms include abdominal distention, vaginal bleeding, and weight gain. Ten percent of patients with ovarian tumors
 presenting with abdominal pain from tumor rupture, hemorrhage, or torsion are misdiagnosed. Tumors can metastasize, most commonly to the lymph nodes, liver, lungs, and CNS. Thus, it is important to complete a genitourinary exam on any patient presenting with lymphadenopathy or chronic pulmonary symptoms.
DIAGNOSIS AND TREATMENT
A testicular mass or abdominal mass may be palpated upon exam. Ultrasonography often identifies an ovarian or scrotal mass, whereas CT delineates the extent of disease. Serum tumor markers can be added to the basic laboratory tests. Treatment includes resection, chemotherapy, and/or radiotherapy. Given that many patients are of reproductive age, treatment attempts to preserve fertility if possible.
BONE AND SOFT TISSUE SARCOMAS
The term sarcoma refers to a diverse group of malignant neoplasms derived from mesenchymal cell origin that can arise from virtually any location at any age. Sarcomas are divided into two main types: soft tissue sarcomas and bone sarcomas. There are over  recognized subtypes. The most common subtypes diagnosed in pediatrics are rhabdomyosarcoma, osteosarcoma, and Ewing’s sarcoma.
RHABDOMYOSARCOMA

Rhabdomyosarcoma accounts for 3% of childhood cancers and 2% of adolescent cancers. Risk factors include a number of inherited cancer predisposition syndromes (e.g., Li­Fraumeni, neurofibromatosis type 1). The embryonal subtype (>75% of cases) is most common in children <5 years old, tends to occur in the head and neck, and has a better prognosis. The alveolar subtype can occur at any age, is more aggressive, and is commonly
 found in the trunk or extremities. Orbital rhabdomyosarcoma accounts for 10% of all rhabdomyosarcoma cases.
Signs and symptoms depend on location, but a painless mass is characteristic. Evaluation in the ED may begin with ultrasonography. More extensive evaluation steps are determined by the oncologist. Treatment includes a combination of surgical excision, chemotherapy, and radiotherapy.
OSTEOSARCOMA
Osteosarcoma, also called osteogenic sarcoma, is the most common primary pediatric bone tumor and is among the most frequent causes of cancer­
 related death. Incidence peaks in adolescence, particularly during a growth spurt. It can occur in any bone, but the majority of cases arise from the
 metaphyses of long bones. Over half of cases originate near the knee joint, either at the distal femur or at the proximal tibia. Twenty percent of
 patients have metastases at the time of diagnosis, most commonly in the lungs, followed by bone. Previous radiation during treatment for a different pediatric neoplasm increases the risk of osteosarcoma.
Nonspecific symptoms can lead to a delay in diagnosis. The most common presentation is an adolescent with persistent bone pain that worsens at night or with activity. Soft tissue swelling may be noted on exam.
Diagnosis is suggested by plain radiography, demonstrating a lytic lesion with cortical destruction near the metaphysis (Figure 145­4). The classic
 radiographic finding is the “sunburst” appearance of periosteal reaction. Pathologic fracture is an uncommon presentation. The differential diagnosis of radiographically similar lesions includes Ewing’s sarcoma as well as more benign lesions. Diagnosis is by biopsy, and treatment includes chemotherapy and limb­sparing surgery. Osteosarcoma is radiation resistant.
FIGURE 145­4. Osteosarcoma. Note the lytic femoral lesion with cortical destruction.
EWING’S SARCOMA
Ewing’s sarcoma is an aggressive tumor of uncertain origin that can occur in the bone or soft tissues. It is more common in older children and
 adolescents, but the incidence is half that of osteogenic sarcoma. Hematogenously spread metastases are present in approximately 25% of patients
 at the time of diagnosis and are most commonly located in the lungs, bone, and bone marrow. Metastatic disease is the most significant prognostic
 factor.
Ewing’s sarcoma typically presents with persistent pain at the tumor site. Tenderness or swelling may be noted on physical exam. The long bones
(femur, tibia, humerus) and the axial skeleton (pelvis, ribs, spine) are the most common sites of disease.
Plain radiographs of the primary tumor site may reveal the characteristic “moth­eaten appearance” of the destructive lesion or the “onion peel” appearance of the periosteal reaction (Figure 145­5). Diagnosis is by biopsy, and treatment is multidisciplinary, including chemotherapy and radiotherapy or surgery.
FIGURE 145­5. Ewing’s sarcoma. Note the destruction of the proximal fibula.
COMPLICATIONS OF PEDIATRIC CANCER AND ONCOLOGIC EMERGENCIES
For the child with cancer, the road to recovery is inevitably interrupted by complications. These complications can be generally classified as infectious
(e.g., fever and neutropenia), metabolic (including tumor lysis syndrome, hypercalcemia, and the syndrome of inappropriate antidiuretic hormone secretion), and structural (superior vena cava syndrome, spinal cord compression, and increased intracranial pressure).
INFECTION
Most pediatric cancer patients experience an infectious complication over the course of the illness. Neutropenia is usually seen as an effect of cytotoxic
 therapy, and many treatment protocols produce profound myelosuppression.

In the context of a febrile cancer patient, “neutropenia” is defined as an absolute neutrophil count <500/mm or an absolute
 neutrophil count <1000/mm with a predicted decline. Relative risk of infection is highest at this time. The absolute neutrophil count nadir typically occurs  to  days after chemotherapy.
Fever will occur in up to one third of neutropenic episodes, with a rate of documented infection between 10% and 40%. Fever in this setting is conservatively defined as a single oral temperature >38.3°C (101°F) or multiple temperatures ≥38.0°C (100.4°F) separated by more
 than  hour. Avoid rectal temperatures due to the risk of bacteremia induced by rectal trauma.
Many patients will not demonstrate a source of fever. Neutropenia, or a decrease in the ability to mount an inflammatory response, limits the development of infectious signs such as abscess, pulmonary infiltrates, or severe abdominal pain. Therefore, perform a meticulous physical examination with close attention to areas of pain, mucosal barriers, and the central line site. Chemotherapeutic regimens that produce profound neutropenia can cause severe mucositis with oral and/or perianal mucosal breakdown.
Typhlitis, or neutropenic enterocolitis, warrants particular attention (Figure 145­6). Inflammation usually involves the ileocecal region. The presentation can be as subtle as mild abdominal pain, and the physical exam may be relatively unrevealing; however, maintain a high index of suspicion for infection. Other signs and symptoms include fever, nausea, emesis, right lower quadrant pain, abdominal distention, and watery or bloody diarrhea. Due to bowel wall necrosis, bowel perforation with resulting pneumatosis intestinalis is possible. Bacteremia is common and is
 often polymicrobial.
FIGURE 145­6. Neutropenic enterocolitis. Asterisks indicate inflamed and thickened bowel wall.
ED TREATMENT
Children with fever history (even if afebrile upon presentation) and potential for neutropenia require immediateclinical evaluation, acquisition of appropriate laboratory studies and cultures, and prompt administration of broad­spectrum antibiotics. Table 145­3 summarizes management of
 neutropenic fever, including the 2017 updated recommendations from the International Pediatric Fever and Neutropenia Guideline Panel. Individual recommendations may differ across institutions. Administration of antibiotics in patients at high risk of neutropenia should not wait for laboratory confirmation of neutropenia.
TABLE 145­3
Management of Neutropenic Fever
Definition of neutropenia
Absolute neutrophil count (segs + bands) <500/mm3
Absolute neutrophil count <1000/mm3 and expected to decrease* Definition of fever†
Oral temperature ≥38.3°C (100.9°F) once
Or
Oral temperature ≥38°C (100.4°F) >2 times, measured  h apart
Caveats
Some add .5°C (1.0°F) to axillary temperatures for oral equivalent
Confirm with oral temperature when possible
Avoid rectal temperatures
Parental history of objective fever is sufficient
‡
Cultures
One culture from each central line lumen (label appropriately)
Peripheral culture in absence of central line or if recommended by oncologist
Consider urine culture and urinalysis (clean catch or bagged)
Antibiotics#
Well­appearingƒ
Broad­spectrum antipseudomonal monotherapy with β­lactam or carbapenem
Cefepime,  milligrams/kg (maximum dose,  grams), or ceftazidime,  milligrams/kg (maximum dose,  grams), or piperacillin­tazobactam,  milligrams/kg (maximum dose, .375 grams)§
Clinically unstable, suspected resistant infection, or center with high rate of resistant pathogens
Addition of second gram­negative agent and/or glycopeptide:
As above + gentamicin, .5 milligrams/kg, and/or vancomycin,  milligrams/kg (maximum,  gram)
Abdominal/perirectal pain
As above + metronidazole, .5 milligrams/kg (maximum,  gram)
*Based on serial measurements or history of chemotherapy in the previous 5–10 days.
†Definitions will vary by institution.
‡
Most patients will require only aerobic cultures. Consider anaerobic cultures if significant GI symptoms or visible mucositis.
#Do not wait for absolute neutrophil count results if patient is expected to be neutropenic.
ƒIndications for the addition of vancomycin include relapsed acute lymphoblastic leukemia or acute myelogenous leukemia patients, significant mucositis, evidence of skin or soft tissue or line infections, and presence of orthopedic appliances.
§Ceftazidime monotherapy should not be used if there are concerns for gram­positive or resistant gram­negative infections. Use vancomycin + aztreonam for cephalosporin­allergic patients.
Obtain blood cultures, if at all possible, before administering empiric antibiotics. Anaerobic cultures are very low yield, and many institutions do not require them unless there are specific concerns for an anaerobic infection. If a clean­catch, midstream urine specimen is available, obtain urinalysis
 and urine culture because febrile neutropenic patients with urinary tract infection are often otherwise asymptomatic. Other diagnostic studies are patient specific (e.g., chest radiograph, stool cultures, abdominal imaging, lumbar puncture).
As shown in Table 145­3, empiric therapy for febrile neutropenia begins with broad­spectrum antibiotics directed at the most common pathogens.
Antibiotic coverage can be tailored to the specific clinical situation and institutional resistance patterns and then be narrowed as more data become available. Given the high prevalence of central venous lines in this population, greater than 50% of bacteremias in neutropenic patients are caused by
 gram­positive bacteria. The most common gram­positive organisms are coagulase­negative staphylococci, Streptococcusviridans, Staphylococcus aureus, and enterococci. Gram­negative organisms, however, are known to be particularly virulent and have an association with sepsis. Intestinal flora
 provide the source of gram­negative organisms, including Escherichia coli, Klebsiella species, Pseudomonas aeruginosa, and Enterobacter species.
Special infectious considerations include treatment for possible Pneumocystis carinii in the immunocompromised patient with respiratory symptoms and broader anaerobic coverage for those suspected of having typhlitis or mucositis. Although some cancer patients (particularly those with AML, with relapsed leukemia, or undergoing stem cell transplant) are at high risk for fungal infections, there is little indication for beginning antifungal agents in
 the ED. Septic patients require immediate, broad­spectrum antipseudomonal antibiotic therapy in addition to vancomycin for coverage of grampositive organisms. Consider adding a second agent with activity against gram­negative organisms (e.g., gentamicin) in critically ill patients.
Careful monitoring and reevaluation are essential once treatment has begun. There is recent literature regarding risk stratification of pediatric patients to determine who can safely be treated as an outpatient. The majority of patients with fever and true neutropenia, however, are admitted to the hospital. The decision to discharge should only be made in consultation with the oncologist.
METABOLIC COMPLICATIONS
TUMOR LYSIS SYNDROME
Tumor lysis syndrome is a constellation of metabolic derangements resulting from the rapid turnover of tumor cells with cell lysis and subsequent release of intracellular potassium, phosphate, and uric acid. Tumor lysis syndrome is associated with rapidly proliferating malignancies, cancers with a high tumor burden, and cancers that are highly sensitive to chemotherapy such as ALL (with hyperleukocytosis), Burkitt’s lymphoma, and non­
Hodgkin’s lymphoma. It is most commonly precipitated by the induction of chemotherapy, but it can also be present at the time of diagnosis.

Symptoms are variable but can be life threatening, including cardiac dysrhythmias, seizures, and acute renal failure.
The large quantity of intracellular contents released into the circulation can easily overwhelm the excretory capacity of the kidneys. The metabolic derangements, including hyperkalemia, hyperuricemia, hyperphosphatemia, and hypocalcemia, are exacerbated by developing renal failure. Uric acid is insoluble at the low pH commonly found in the renal collecting duct, and crystals may precipitate in the collecting tubules, leading to acute
 kidney injury. Hyperkalemia is the most immediate threat to life and should be treated aggressively, even in the absence of overt ECG changes.

Lymphoblasts contain four times more phosphate than normal lymphocytes, and the resulting excess phosphate from cell lysis can bind ionized calcium, leading to hypocalcemia. In addition, calcium phosphate crystalluria and obstructive uropathy can worsen acute kidney injury. The signs, symptoms, and treatment of these electrolyte disorders are discussed in Chapter 132, “Fluid and Electrolyte Therapy in Infants and Children.”
Laboratory studies include CBC, renal function studies, electrolytes, calcium, phosphate, uric acid, lactate dehydrogenase, and urinalysis (Table 145­
4). Send laboratory studies every  hours in high­risk patients who remain in the ED for a prolonged period of time. ED treatment is directed at the prevention of renal failure, correction of electrolyte derangements, and reduction of uric acid levels. Coordinate management with an oncologist and include aggressive IV hydration, administration of allopurinol or recombinant urate oxidase (rasburicase) for hyperuricemia, and treatment of hyperkalemia and symptomatic hypocalcemia. Rasburicase is contraindicated in glucose­6­phosphate dehydrogenase deficiency due to its potential to
,48 ,48 precipitate hemolytic anemia or methemoglobinemia. Urinary alkalinization is no longer recommended. Avoid rectal Kayexalate®, because rectal medication administration increases the risk of bacteremia in neutropenic patients. Refractory electrolyte abnormalities or significant acute kidney injury requires dialysis.
TABLE 145­4
Initial Management of Tumor Lysis Syndrome
Labs (repeat every 4–8 h)
CBC
Electrolytes
Renal function studies
Calcium, phosphate, magnesium
Uric acid, lactate dehydrogenase
Urinalysis
ECG
IV fluids, often at >2× maintenance
Specific therapies, if indicated
Hyperuricemia: allopurinol, 100 milligrams/m2, or rasburicase,* .2 milligram/kg
Symptomatic hypocalcemia: calcium gluconate
Hyperkalemia: calcium/dextrose/insulin/bicarbonate
Poor urine output: loop diuretic†
*Contraindicated in glucose­6­phosphate dehydrogenase deficiency.
†Patient must be volume replete.
SYNDROME OF INAPPROPRIATE ANTIDIURETIC HORMONE AND HYPONATREMIA
Causes of hyponatremia in oncology patients include chemotherapeutic agents, adjunct treatments (e.g., diuretics), clinical conditions (e.g., GI losses), and syndrome of inappropriate antidiuretic hormone secretion (SIADH). SIADH is the leading cause of hyponatremia in children undergoing
 chemotherapy or stem cell transplant. SIADH can result from CNS disease, infection, drug toxicity, surgical intervention for CNS tumors, and the
 primary malignancy. Cerebral salt wasting is also a possible cause of hyponatremia with CNS disease or following intracranial surgery. Whereas syndrome of inappropriate antidiuretic hormone secretionis characterized by euvolemia, cerebral salt wasting is characterized by volume depletion; this distinction is critical in the ED setting, where excessive fluid administration could be catastrophic.
The presentation of hyponatremia depends on the rate and severity of the decline in sodium level. Patients may be asymptomatic, with low sodium levels incidentally noted on routine laboratory studies. Signs and symptoms of profound hyponatremia include fatigue, lethargy, confusion, coma, and seizures. Treatment must be tailored to the patient’s underlying cause of hyponatremia. Guidelines for ED management of hyponatremia are outlined in Chapter 132. For SIADH, treatment consists of fluid restriction and slow sodium correction to avoid inducing central pontine myelinolysis. For hypovolemic hyponatremic patients, isotonic fluids are administered. Treatacutely symptomatic patients with 3% normal saline.
SUPERIOR VENA CAVA AND SUPERIOR MEDIASTINAL SYNDROMES
Superior vena cava syndrome is the result of compression or obstruction of the superior vena cava causing impaired venous return (Figure 145­7).

Over 90% of cases are attributable directly to malignancy, but infection and thrombus are additional causes. Superior mediastinal syndrome is superior vena cava syndrome with associated tracheal compression. These two terms are used interchangeably in children because mediastinal
 pathology often leads to both. Although these entities are rare, the most common pediatric malignancies presenting with superior mediastinal
 syndrome are non­Hodgkin’s lymphoma, ALL, neuroblastoma, and germ cell tumors.
FIGURE 145­7. Superior vena cava syndrome. Note the prominent collateral veins of the chest and neck. [Photo contributed by William K. Mallon, MD. Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, Inc., New York.]
The signs and symptoms of superior mediastinal syndrome are dictated by the acuity and extent of the underlying process. Some patients are
 asymptomatic, but young children are at particular risk due to the small size and compliance of the airway. Signs and symptoms include dyspnea, cough, stridor, wheezing, chest discomfort, facial and upper body edema and/or plethora, neck/chest vein dilatation, presence of collateral veins, and syncope (from decreased cardiac output). The threat of acute cardiorespiratory failure makes this a true medical emergency. Equally
 concerning are neurologic symptoms suggestive of cerebral ischemia: headache, confusion, and altered mental status.
ED treatment depends on the clinical acuity. Confirm the diagnosis by chest radiograph or CT scan. Supine positioning for imaging may critically compromise the airway, so a prone position is a preferred alternative for older, cooperative children. Avoid any intervention, such as sedation, that could potentially compromise the airway. Superior mediastinal syndrome is one of the few conditions in which rapid­sequence induction and intubation for respiratory distress may be lethal if the endotracheal tube cannot bypass the site of compression.
Temporizing measures include elevating the head of the bed to maintain an upright posture, high­flow oxygen, bilevel positive airway pressure, and possible consideration of heliox where available. Definitive management is treatment of the underlying malignancy to reduce the amount of compression. In cases where the syndrome is due to thrombotic occlusion, fibrinolytic therapy can be considered. Emergency stents have been placed
 at centers with appropriate expertise.
NEUROLOGIC EMERGENCIES
SPINAL CORD COMPRESSION
Tumors involving the spine or spinal cord account for only 2% of childhood malignancies, but due to delays in diagnosis and deficits that are not
 always reversible, they are associated with a disproportionate degree of morbidity. The most common neoplasms involving the spinal cord are CNS tumors, neuroblastoma, sarcomas, lymphoma, and germ cell tumors. Spinal cord compression can present in a child with known malignancy or as an initial presentation of disease. Most commonly, spinal cord compression arises from a hematogenously spread metastasis to vertebral bodies, with
 subsequent expansion and erosion of the lesion into the epidural space (Figure 145­8). However, it can also result from direct extension of a paravertebral tumor through an intervertebral foramen into the spinal canal.
FIGURE 145­8. Spinal cord compression. MRI demonstrating spinal cord compression at T9 due to epidural extension of tumor. T10 vertebral body also has metastasis (decreased signal intensity). [Reproduced with permission from Schwartz D (ed). Emergency Radiology: Case Studies. Copyright © 2008 by
The McGraw­Hill Companies, Inc., New York.]
Back pain is the most common presenting symptom of spinal cord compression in children and often precedes other symptoms, providing an
,55,56 opportunity for early detection and intervention. Consider spinal involvement in any child with a history of cancer presenting with back pain. If the diagnosis is delayed, progressive symptoms include motor weakness, worsening scoliosis, and gait disturbance. Sensory impairments and sphincter dysfunction are extremely rare in young children. Physical exam findings depend on the location of the lesion(s), the degree of spinal cord impingement, and the rate at which compression takes place.
In patients in whom spinal compression is suspected, MRI is the gold standard imaging and should be obtained emergently. Plain
,55 films are ineffective for diagnosis. Given that a significant number of patients present with multiple spinal lesions, image the entire spinal cord.
Obtain brain imaging if a spinal neoplasm is identified. Obtain oncology, neurosurgery, and radiotherapy consultation. ED treatment is IV dexamethasone (0.1 milligram/kg to a maximum of  milligrams) to decrease vasogenic edema caused by obstruction of the epidural venous plexus and to improve symptoms. However, if leukemia or lymphoma is in the differential diagnosis for an initial presentation of a spinal tumor, do not administer steroids without consulting an oncologist; steroid administration can mask the tumor and prevent diagnosis and appropriate treatment. Neurologic damage is often irreversible once ischemia develops and the spinal cord infarcts. Even with
 aggressive interventions, studies report that 40% to 70% of children have residual impairment.
INCREASED INTRACRANIAL PRESSURE
Increased intracranial pressure in children with cancer is usually due to primary CNS tumors. Childhood CNS tumors are often infratentorial, a location
 where there is potential for cerebrospinal fluid flow obstruction. Clinical presentation and risk of herniation depend on the location and growth rate of the tumor, as well as the age of the child. Signs and symptoms are often nonspecific. Cushing’s triad is rare but requires emergent intervention.
Brain imaging with MRI or CT can identify a neoplasm, associated vasogenic edema and/or hydrocephalus, and alternative diagnoses; however, CT remains the test of choice in the emergency setting. Management is guided by the severity of the presentation. Initial focus in the ED should be a primary survey; in particular, ensure airway protection in a patient with high intracranial pressure and altered mental status. Use of hyperventilation is now debated, because hypercarbia causes cerebral dilation but hypocarbia is an independent predictor of mortality. Mild hyperventilation (pulmonary end tidal carbon dioxide,  to  mm Hg) is considered appropriate in cases of herniation. Elevate the head of the bed to  degrees to improve venous drainage and consult neurosurgery. Administer IV dexamethasone (0.1 milligram/kg to a maximum of  milligrams) to reduce tumor­
,60 associated vasogenic edema. There are no pediatric data clearly supporting antiepileptic administration for seizure prophylaxis, but fosphenytoin or another longer acting antiepileptic can be considered if the patient requires transport. Maintain appropriate electrolyte levels and correct thrombocytopenia or coagulopathy.
STROKE

Stroke, occurring within the first few years of a childhood cancer diagnosis, is rare. Overall prevalence is estimated at 1%. Hemorrhagic strokes and
 ischemic strokes occur with equal frequency. Risk factors include coagulopathy, thrombocytopenia, hyperleukocytosis, radiation, medications, and primary or metastatic CNS tumors. Stroke can be the sole clinical manifestation from hemorrhage into a previously occult CNS neoplasm.
Treatment depends on the underlying cause. Standard stroke management applies, including brain imaging. Modifiable risk factors should be
 addressed, including correction of thrombocytopenia to keep platelet levels >100,000/mm . Discuss anticoagulant therapy in consultation with neurology and oncology.
SEIZURES
Seizures are common in pediatric oncology patients and may have a number of causes: primary or metastatic CNS lesion, stroke, metabolic derangement (i.e., hyponatremia), infection (e.g., abscess, meningitis), chemotherapeutic agents, and radiation therapy. Fifteen percent of pediatric
 brain tumor patients experience seizures, and 12% of pediatric brain tumor patients present with seizures.
Initial evaluation of a seizure in a child with cancer should include brain imaging with CT or MRI to identify the cause. If there are no contraindications, perform lumbar puncture to exclude infection. See Chapter 138, “Seizures in Infants and Children,” for further discussion.
CATHETER­RELATED COMPLICATIONS
The vast majority of pediatric cancer patients undergo central venous line placement for their treatment. These devices include external catheters (e.g.,
Broviac®), totally implantable catheters (e.g., Port®), and peripherally inserted central catheters. Rates of catheter­related complications are 40% to
,64
50%, and the complications fall primarily into three categories: infectious, mechanical, and thrombotic.
Infection of the central line occurs from contamination of the hub and luminal migration of pathogens within the catheter, from hematogenous seeding of the intravascular portion of the catheter, or from fractures within the catheter itself. The morbidity and mortality attributable to central line–associated bloodstream infections is significant. The incidence of central line infections is three times greater in ambulatory pediatric oncology
 patients compared to inpatients. Risk factors include frequent access, poor hygiene and sterility, previous infection, and <1­month duration from line insertion. Tunnel infections of the soft tissue surrounding the catheter may also occur shortly after placement, with typical signs of infection.
,67
Totally implantable catheters are associated with the least catheter­associated infectious morbidity. Treatment requires IV antibiotics and possible device removal. For further discussion, see “Infection” section.

A central venous line is the single most important risk factor for developing thromboembolism in any child, and 50% of children
 with cancer are reported to have central line–associated thrombosis. Common morbidities from thrombosis include infection, embolism to other vessels (including pulmonary embolism), catheter malfunction, loss of venous access, and delay of treatment. Venous Doppler ultrasonography can identify upper extremity or jugular vein thrombosis, but ultrasonography is limited in its inability to visualize more proximal (i.e., central) thrombosis. CT or magnetic resonance venogram may also be used for diagnosis. Treatment of central line–associated thromboembolism may require tissue plasminogen activator (a small alteplase infusion administered to the catheter site if there are concerns for an intraluminal partial occlusion of the catheter), removal of the catheter, and/or anticoagulation for more significant thromboembolisms. ED staff should not infuse tissue plasminogen activator into a central line without consulting oncology and/or surgery. When anticoagulant therapy is indicated, low­molecular­weight
 heparin, using pediatric­specific dosing protocols, is usually the preferred choice in children.
Mechanical complications are also quite common in pediatric oncology patients, with a prevalence of 20% to 39%, and are an independent risk factor
  for poor outcomes. External catheters have increased rates of mechanical complications and failure. Potential nonthrombotic occlusions include intraluminal precipitation of calcium, bicarbonate, or drugs (e.g., phenytoin).
OTHER COMPLICATIONS OF MALIGNANCY
CARDIOPULMONARY COMPLICATIONS
There are a variety of cardiac and pulmonary oncologic complications that are not unique to pediatrics. These include malignant pericardial effusion through direct or metastatic involvement of the pericardium, treatment­induced transudative pericardial effusion, cardiac tamponade, and pleural effusions. These complications and their management are addressed in the adult chapters of this textbook. Chemotherapeutic agents and adjunct therapies can also be associated with cardiomyopathy, hypertension, arrhythmias, and pulmonary fibrosis.
GASTROINTESTINAL COMPLICATIONS
Mechanical bowel obstruction due to mass effect may occur with any intra­abdominal tumor, most commonly lymphoma. Malignancy should be on the differential for a child presenting with intussusception, because masses can act as lead points for telescoping of the bowel. Postoperatively, patients with oncologic abdominal surgery are at increased risk for developing a bowel obstruction due to adhesions. Patients are also at risk for constipation and ileus due to narcotic administration.
Any component of the GI tract, from mouth to anus, can be affected by mucositis induced by chemotherapeutic agents. Mucosal breakdown can lead to pain, infection, dehydration due to poor oral intake, and bleeding at any location. Herpetic or fungal esophagitis can develop. Typhlitis, or neutropenic enterocolitis, was previously discussed in this chapter (see “Infection” section and Figure 145­6). Appendicitis must remain a consideration in the oncology patient with right lower quadrant abdominal pain. Of note, the typical appendicitis presentation may be blunted in children with
 neutropenia and/or on corticosteroids. Imaging with CT or US can help to differentiate between appendicitis, typhlitis, and other intra­abdominal processes.
GI bleeding can result from mucositis, high­dose steroids or radiation in the treatment regimen, primary tumor or metastatic invasion, or tumor­ or treatment­related cytopenias or coagulopathies. Mallory­Weiss tears can develop from severe chemotherapy­related emesis. Primary colorectal cancers are extremely rare in children, but those numbers increase when including secondary GI malignancies following a previously treated pediatric cancer.
GENITOURINARY COMPLICATIONS
Mass effect from abdominal or pelvic tumors can lead to ureteral obstruction and hydronephrosis, necessitating urgent stent placement. Other causes of acute urinary retention include drugs (e.g., narcotics, anticholinergics) or spinal cord compression. Viruses, radiotherapy, and chemotherapeutic agents can all induce hemorrhagic cystitis. Hemorrhagic cystitis treatment requires IV hydration, correction of underlying cytopenias and coagulopathy, and antiviral medications if appropriate. Severe cases warrant urologic consultation for placement of a double­lumen Foley catheter for
 continuous bladder irrigation or for cystoscopy.


