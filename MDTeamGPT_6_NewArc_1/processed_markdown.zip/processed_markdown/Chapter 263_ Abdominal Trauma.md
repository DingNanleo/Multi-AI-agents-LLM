## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 263: Abdominal Trauma
Anthony A. Ferroggiaro; O. John Ma
INTRODUCTION

Abdominal trauma accounts for 15% to 20% of all trauma deaths. Although the liver is the most frequently injured abdominal organ, the spleen is the
 most frequently injured intra­abdominal organ from sports accidents. Death may occur as a consequence of massive hemorrhage and generally results in early demise soon after the injury. Patients who survive the initial traumatic insult are at risk for infection and sepsis.
PATHOPHYSIOLOGY
BLUNT ABDOMINAL TRAUMA
In blunt trauma, all abdominal structures are at risk, and ultimately the biomechanics of the traumatic force determine which organs are affected.
Compressive, shearing or stretching, and acceleration/deceleration forces impact the abdominal cavity and structures leading to abdominal wall, solid organ, or hollow viscous injuries. Abdominal organs may be relatively mobile or fixed. Injury is common in transition areas between these structures, such as the ligament of Treitz, where mesenteric or small bowel injuries may occur.

The most common mechanism for blunt abdominal trauma is a motor vehicle collision. Falls, second in frequency as causes of blunt trauma, produce injury due to the fall distance, the impact surface, and the manner of surface impact. Both solid and hollow organ rupture can occur with
 retroperitoneal injury and hemorrhage resulting when the force is transmitted along the axial skeleton. Pedestrians struck by vehicles or motorcyclists and bicyclists who crash generally have no protection to their abdomen and are at high risk for intra­abdominal injuries.
PENETRATING ABDOMINAL TRAUMA
Stab and gunshot wounds produce injury as the foreign object passes through tissue. With gunshot wounds, there may be additional injury from the transmitted energy of the blast. Furthermore, gunshot wounds create secondary missiles such as fragmented bone that may increase the traumatic burden.
The length, trajectory, and fragmentation of the penetrating object will not necessarily be known during the evaluation. Therefore, assume any penetrating injury to the chest, pelvis, flank, or back to have penetrated the abdominal cavity until proven otherwise.
CLINICAL FEATURES
Clinical signs may be obvious (such as evisceration) or occult. Factors making the diagnosis of an abdominal injury challenging include concomitant injuries (particularly significant head injuries), referred pain, intoxication with alcohol or other toxicologic substances, or language barriers. Young, healthy patients may be able to compensate for intra­abdominal hemorrhage before clinical signs become overt. Elderly patients may be on anticoagulation medications or on medications limiting physiologic response, such as antihypertensives (beta­blockers or calcium channel blockers).
PHYSICAL EXAMINATION
Inspect the abdomen for external signs of trauma (e.g., abrasions, lacerations, contusions, seatbelt marks). A normal­appearing abdomen does not exclude serious intra­abdominal injury. Following inspection, palpate the abdomen in all quadrants, making note of general or regional tenderness and signs of acute abdomen (rigidity, rebound, guarding). Regardless of imaging, document serial exams for patients who remain in the ED for several hours.

AC htraaputmera 2ti6c3 a:b Adbodmoimnainl aplr Tocraeussm ma,a Ay nptrhoognreys As .o Fveerr rhoogugrisa,r aon; dO n. eJwoh sny mMpatoms and signs may indicate the development of a surgical processP. aRgeeli a1n /c 1e0
. Terms of Use * Privacy Policy * Notice * Accessibility on physical exam alone, particularly with a worrisome mechanism of injury, may result in an unacceptably high misdiagnosis rate or delay in treatment.
As many as 45% of blunt trauma patients thought to have a benign abdomen on initial physical exam are later found to have a significant intra­
 abdominal injury.
ABDOMINAL WALL INJURIES
Contusions of the abdominal wall musculature may result either from a direct blow or indirectly via a sudden muscular contraction. Symptoms include pain and possibly soft tissue swelling or a hematoma. Abdominal wall injuries may mimic or implicate more extensive intra­abdominal injury. Imaging may be indicated to “rule out” intra­abdominal injury.
SOLID ORGAN INJURIES
Signs and symptoms of a solid organ injury are generally due to pain and blood loss. Exclusive reliance on the Advanced Trauma Life Support shock
 classification may lead to underrecognition of progressive instability. In general, early intra­abdominal hemorrhage may result in minimal change in vital signs. As blood loss continues, heart and respiratory rate increase and urinary output drops. Patients may also become anxious and confused.
Hypotension may not occur until the circulating blood volume significantly decreases.
Hepatic and splenic injuries are at high risk for hemorrhage in both penetrating and blunt abdominal trauma. Any blunt abdominal trauma
,7 patient with diffuse peritonitis or who is hemodynamically unstable should be taken urgently for laparotomy. Hepatic and splenic injuries are graded; low grades indicate less severe injury. CT imaging has improved the definition of injuries, and combined with the development of interventional radiology and catheter­based vascular management, many patients with hepatic or splenic injuries are managed nonoperatively.

Surgical consultation is required in any solid organ injury; transfer to a level  trauma center reduces mortality. Delayed rupture can occur in splenic and hepatic injuries, and at times, pain with solid organ injury may be referred to the shoulder/scapular region.
HOLLOW VISCUS AND MESENTERIC INJURIES
,10
In blunt abdominal trauma, the incidence of blunt bowel and mesenteric injuries is infrequent (1% to 12%). Hollow viscus injuries produce symptoms from the combination of blood loss and peritoneal contamination by GI contents. Hemorrhage from a mesenteric injury may be minimal and not be obvious on physical exam. Chemical irritation of the peritoneum from gastric acid contents may produce immediate pain, although bacterial contamination of the abdominal cavity may result in delayed signs and symptoms. Delays in diagnosis and operative management are
 associated with an increase in mortality.
RETROPERITONEAL INJURIES
The retroperitoneal structures discussed in this chapter include the pancreas (excluding the tail) and duodenum. See Chapter 265, “Genitourinary
Trauma” for a discussion of kidney, ureter, and bladder injuries.

Pancreatic injuries infrequently occur (4%) with abdominal trauma, yet are associated with significant morbidity and mortality. Pancreatic trauma often occurs from rapid deceleration, such as unrestrained drivers who hit the steering column or bicyclists who fall against a handlebar, and these patients are at risk for pancreatic injuries.
Similarly, duodenal injuries may be relatively asymptomatic and go undiagnosed. As the duodenal hematoma expands, signs and symptoms of obstruction may develop (abdominal pain, distention, and vomiting). Duodenal rupture generally occurs following high­velocity deceleration. The ruptured contents may be contained within the retroperitoneum and missed with studies that investigate the peritoneum exclusively. Fever and leukocytosis herald the development of an abscess or sepsis.
DIAPHRAGMATIC INJURIES
Diaphragmatic injuries are uncommon (0.8% to 5% of patients with thoracoabdominal injury). Diaphragmatic injury diagnosis is often delayed in blunt
 trauma due to concomitant severe injuries and may be incidentally identified during operative treatment for hemodynamic instability. CT imaging has variable sensitivity and specificity (ranging to a low of 60% and 70%, respectively). Delayed diagnosis may lead to herniation or strangulation of abdominal contents through the diaphragmatic defect, with mortality rates up to 50%.
DIAGNOSIS
Although multiple diagnostic modalities exist to detect intra­abdominal injuries, no study is fail­proof. Therefore, a combination of careful physical exam, attention to the mechanisms and circumstances of injury, and judicious selection of diagnostic studies is used for diagnosis. Hemodynamic instability may limit the immediate use of some diagnostic testing (CT). The FAST examination has become integral to early resuscitation and the diagnostic algorithms of abdominal trauma patients.
Indications to consider an expanded abdominal trauma evaluation are listed in Table 263­1. Often these evaluations include laboratory testing, imaging, further resuscitation, and reevaluation. Trauma service consultation may be invaluable.
TABLE 263­1
Abdominal Injuries That Need Expanded Evaluation
Presence of abdominal pain, tenderness, distention, or external signs of trauma
Mechanism of injury with a high likelihood of causing an abdominal injury
Suspicious lower chest, back, or pelvic injury
Inability to tolerate a delayed diagnosis (e.g., patients who are elderly, on anticoagulants, or have liver cirrhosis/portal hypertension)
Presence of distracting injuries
Altered consciousness/sensorium (e.g., CNS injury, intoxicating substances)
ULTRASONOGRAPHY
The FAST examination is a widely accepted primary diagnostic study. The underlying premise of the FAST exam is that many clinically significant injuries will be associated with free intraperitoneal fluid (Figure 263­1). The greatest benefit of FAST is the rapid identification of free intraperitoneal fluid in the hypotensive patient with blunt abdominal trauma.
FIGURE 263­1. Hemoperitoneum. The abdominal IV contrast CT. A. A fractured spleen with surrounding hematoma is demonstrated, but a small stripe of fluid is also present above the right kidney in Morison’s pouch. B. A right intercostal oblique US view from the same patient reveals a thin stripe of fluid in
Morison’s pouch. [Reproduced with permission from Ma OJ, Mateer JR, eds: Ma and Mateer’s Emergency Ultrasound, 3rd ed. © 2014, McGraw­Hill, Inc.
New York.]
The FAST examination is accurate, rapid, noninvasive, repeatable, and portable, and involves no nephrotoxic contrast material or ionizing radiation.
Massive hemoperitoneum is quickly detected with a single view of Morison’s pouch. FAST also evaluates for free pericardial or pleural fluid and for pneumothorax.
The main disadvantage of US compared to CT is the inability to identify the exact source of free intraperitoneal fluid. Other potential disadvantages of the FAST examination are the operator­dependent nature of the examination, the difficulty in interpreting the images in patients who are obese or have subcutaneous air or excessive bowel gas, and the difficulty in distinguishing intraperitoneal hemorrhage from ascites. Also, the FAST examination cannot evaluate the retroperitoneum as well as CT. Therefore, US and CT are complementary rather than competing technologies when time and stability permit, and the potential benefits of CT outweigh the risks.
Beyond diagnosis, US can be a clinically helpful tool for trauma resuscitation. US may guide the placement of central venous catheters, suprapubic catheters, and large­bore peripheral lines. The inferior vena cava diameter of trauma patients, as measured on initial CT imaging, is a marker of
,14 ,16 intravascular volume and a predictor of mortality, although the reliability of inferior vena cava diameter measurement is still debated.
Because the FAST examination can reliably detect small amounts of free intraperitoneal fluid and can estimate the rate of hemorrhage through serial examinations, US has replaced diagnostic peritoneal lavage (DPL) for blunt abdominal trauma in the majority of North American trauma centers. A positive DPL in isolation is no longer an absolute indication for exploratory laparotomy; the amount of hemorrhage and the hemodynamic status of the patient are important factors for determining further management steps.
COMPUTED TOMOGRAPHY
Abdominopelvic CT with IV contrast is the noninvasive gold standard study for the evaluation of abdominal injury (unless the patient has allergy to iodinated contrast). The addition of PO contrast can result in aspiration and is too time­consuming to be practical in trauma management. The major advantage of IV contrast CT over other diagnostic modalities is that the precise location(s) of specific injury can be identified (Figure 263­1). CT can quantify and differentiate the amount and type of free fluid in the abdomen. CT can also evaluate for retroperitoneal injuries; it is the ideal study for assessment of the duodenum, pancreas, and vascular and renal systems. The use of multiphasic CT (arterial, portal, and equilibrium phases)
 accurately identifies life­threatening mesenteric hemorrhage and transmural bowel injuries. CT evidence of a flat inferior vena cava suggests hypovolemia.
With a focus on patient safety, source EDs should transmit completed imaging with patient transfer to avoid repeat CT imaging whenever possible.

Outcomes and time to definitive care are not significantly improved when imaging is repeated at the accepting trauma center.
DIAGNOSTIC PERITONEAL LAVAGE
Despite the reproducibility and prospectively validated sensitivity of DPL to diagnose intraperitoneal injury, the advent and acceptance of other
 diagnostic modalities have significantly reduced the frequency of DPL. DPL can be performed using a closed (Figure 263­2) or open technique.
However, the open DPL technique requires advanced training and expertise. Some advocate the use of DPL in the hemodynamically unstable patient
 with concern for intra­abdominal injury when the FAST exam is negative or unavailable.
FIGURE 263­2. Closed diagnostic peritoneal lavage. Drain the urinary bladder. Infiltrate the area just below the umbilicus with lidocaine and epinephrine. Insert the needle two fingerbreadths below the umbilicus. Aspirate directly with a syringe attached to the needle, or insert a guidewire into the abdomen and place the peritoneal lavage catheter over the guidewire. Instill  L of normal saline through the catheter, and then aspirate.
DIAGNOSIS IN PENETRATING TRAUMA
The same diagnostic tools are available for evaluation of intraperitoneal injury in the patient with penetrating trauma (CT, US, and DPL). Mandatory
 exploration for patients sustaining a stab wound to the abdomen has yielded unacceptably high rates of nontherapeutic laparotomy, yet physical exam alone can miss important intra­abdominal injuries. The emergency physician or consultant surgeon may locally explore anterior
 abdominal stab wounds (Figure 263­3) to assess for violation of the peritoneum. Patients with transabdominal gunshot wounds almost always have intra­abdominal injuries. In the hemodynamically stable patient with penetrating trauma, CT can help guide the surgeon for operative versus
 nonoperative management.
FIGURE 263­3. Local abdominal wound exploration for anterior abdominal stab wounds. This is a surgical procedure requiring expertise, proper instrumentation, and lights. Use only for anterior abdominal stab wounds. Widen the stab wound and explore down to the level of the fascia to determine if the anterior fascia and/or posterior fascia have been violated.
TREATMENT
LAPAROTOMY
Laparotomy remains the gold standard therapy for significant intra­abdominal injuries. It is definitive, rarely misses an injury, and allows for complete evaluation of the abdomen and retroperitoneum. Table 263­2 describes generally accepted indications for exploratory laparotomy. All patients with persistent hypotension, abdominal wall disruption (peritoneal violation), or peritonitis need surgical exploration. In addition, the presence of extraluminal, intra­abdominal, or retroperitoneal air on plain radiograph or CT should prompt surgical exploration. Early surgical involvement in decision making and resuscitation may be valuable in blunt abdominal trauma patients; in smaller medical centers or community hospitals, transfer to a trauma center may best serve such patients.
TABLE 263­2
Indications for Laparotomy
Blunt Penetrating
Absolute Anterior abdominal injury with hypotension Injury to abdomen, back, and flank with hypotension
Abdominal wall disruption Abdominal tenderness
Peritonitis GI evisceration
Free air under diaphragm on chest radiograph High suspicion for transabdominal trajectory after gunshot wound
Positive FAST or DPL in hemodynamically unstable patient CT­diagnosed injury requiring surgery
CT­diagnosed injury requiring surgery
Relative Positive FAST or DPL in hemodynamically stable patient Positive local wound exploration after stab wound
Solid visceral injury in stable patient
Hemoperitoneum on CT without clear source
Abbreviations: DPL = diagnostic peritoneal lavage; FAST = focused assessment with sonography for trauma.
NONOPERATIVE MANAGEMENT OF BLUNT TRAUMA
Nonoperative management of trauma patients has been greatly advanced by the evolution of CT. CT can make the diagnosis of solid organ injury along with ruling out other injuries requiring surgery. Solid visceral injuries are graded according to their severity.
Both the Eastern Association for the Surgery of Trauma and the Western Trauma Association have published guidance on nonoperative management of blunt abdominal trauma. Nonoperative management is now the treatment of choice in hemodynamically stable blunt hepatic and splenic injured patients “irrespective of the grade of injury, patient age, or the presence of associated injuries.”
Several technologic advances have increased the sophistication of nonoperative therapy. The increased resolution of helical CT can identify intraparenchymal vascular injuries (i.e., pseudoaneurysms or arteriovenous fistulae) and active extravasation of contrast, further defining operative and nonoperative options. In patients in whom vascular injury is diagnosed, percutaneous transcatheter embolization with either stainless steel coils or Gelfoam® pledgets can reliably arrest hemorrhage and is advancing as a nonoperative modality within trauma centers. Also using intravascular techniques, resuscitative endovascular balloon occlusion of the aorta may be employed at level  trauma centers and represents an intravascular
“clamping” of the aorta with unresponsive shock due to intra­abdominal hemorrhage.
Medication­induced coagulopathy is a management challenge in abdominal trauma patients. Patients on warfarin or on non–vitamin K oral anticoagulants are at higher risk for hemorrhage. For patients on warfarin or factor Xa inhibitors (rivaroxaban, apixaban, and edoxaban), reverse
 anticoagulation with prothrombin complex concentrate is available for all situations of life­threatening hemorrhage or hemodynamic instability. For dabigatran, infusing the antidote idarucizumab is recommended.

Consider tranexamic acid in all patients with traumatic abdominal hemorrhage. Based on the CRASH­2 trial, the risk of death was most reduced with tranexamic acid administration within  hour and in those with the most severe hemorrhagic shock, whereas treatment beyond  hours implicated an
 increased risk of death. Physicians managing abdominal trauma should have tranexamic acid available within the ED.
DISPOSITION AND FOLLOW­UP
Patients with significant intra­abdominal injury need admission to the surgical or trauma service for definitive surgical intervention or observation.
Given the high rate of concomitant injuries, even patients who suffer minor abdominal injury may need hospitalization to manage other injuries. In patients in whom ED discharge is considered, discuss appropriate follow­up and careful instructions for return to the ED. Patients who develop fever, vomiting, increased pain, or symptoms suggestive of blood loss (e.g., dizziness, weakness, fatigue) should return promptly for reevaluation. Admission for observation may be the best option in some patients.


