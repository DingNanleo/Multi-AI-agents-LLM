## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 181: Lithium
Anita Mudan; David H. Jang
INTRODUCTION
Lithium is one of the most effective medications for the continuous treatment of bipolar disorder. It is particularly useful for the treatment of acute
,2 manic episodes and reduces rates of suicide associated with affective disorders. Among agents used to treat depression, lithium is associated with
 high morbidity and mortality indices (events per 1000 exposures).
PHARMACOLOGY
Lithium is a simple ion with a complex mechanism of action that is not fully understood. It is postulated to involve primary monoamine neurotransmission, via a direct interaction between the lithium ion and cellular enzymes, influencing the secondary signaling pathways of dopamine,
,4 serotonin, and norepinephrine. Lithium competes with other similar cations, including sodium, potassium, magnesium, and calcium, and displaces them from intracellular and extracellular sites. Interference with sodium ions at the sodium channel and the sodium­potassium pump on the cell membrane is responsible for lithium’s adverse effect on myocardial electrical activity. Lithium inhibits arginine vasopressin, an effect that is responsible for polyuria and nephrogenic diabetes insipidus seen during lithium therapy. Other pharmacologic effects include interference with the release and reuptake of norepinephrine at the nerve terminal site. Lithium may enhance serotonin release, particularly from the hippocampus, and has been implicated in serotonin syndrome when combined with other medications that alter serotonin metabolism. Lithium is handled by the kidney similar to sodium; anything that may increase sodium absorption, such as medications that reduce glomerular function, has the potential to contribute
 to lithium toxicity.
PHARMACOKINETICS
After oral ingestion of therapeutic doses, lithium is rapidly and almost completely absorbed, although delayed absorption may occur with sustained­
 release products and after ingestion of a large number of tablets. Lithium is not bound to plasma proteins and has an initial volume of distribution between .6 and .9 L/kg. Ingestion of a single tablet of lithium carbonate 300 milligrams containing .12 mEq of lithium ion is expected to increase the lithium concentration by approximately .1 to .3 mEq/L (assuming a normal volume of distribution in a patient with a weight of  to 100 kg).
Lithium exhibits a prolonged redistribution phase and tissue burden. Lithium distribution into and out of the brain is slower, resulting in neurologic
 effects that do not correlate with serum levels. The lithium concentrations in the brain and in the serum may differ by two­ to three­fold. Continuation of toxic effects, even after hemodialysis, can be due to the drug’s slow movement out of the CNS and redistribution. Serum concentrations can serve as a marker of exposure but are poor predictors for severity of toxicity. Thus, clinical signs and symptoms provide a more accurate indicator of CNS lithium concentrations compared to serum concentrations.

The elimination half­life after a single dose of lithium is about  to  hours in young adults and almost twice that in the elderly. After continued therapy of longer than a year, the lithium elimination half­life increases, up to almost  hours in all ages. Lithium is not metabolized and is excreted unchanged, primarily in the urine. Like other cations of similar size, lithium is reabsorbed in the proximal tubule. The therapeutic index of lithium is narrow, and risk factors for the accumulation of lithium and the development of toxicity include NSAIDs, diuretics, angiotensin­converting enzyme
,5,8 inhibitors, advanced age, low­output heart failure, and states that result in decreased sodium intake such as GI loss.
CLINICAL FEATURES
TOXIC EFFECTS

Chapter 181: Lithium, Anita Mudan; David H. Jang 
9­12
Lithium toxicity can be divided into three types: acute toxicity, chronic toxicity, and acute­on­chronic toxicity.
. Terms of Use * Privacy Policy * Notice * Accessibility
Acute ingestions of lithium produce findings similar to that of other metal salts, consisting primarily of GI symptoms of abdominal pain, nausea, vomiting, and diarrhea, which may result in significant volume depletion. The resulting hypovolemia decreases renal clearance of lithium, further increasing serum concentration. Acute lithium overdoses present with more GI toxicity and less neurologic toxicity because of the slower accumulation into the brain after ingestion and distribution in body water. Patients with acute overdose may have markedly elevated serum concentrations that do not correlate well with either symptom severity or prognosis. As lithium distributes from the serum into the CNS, neurologic symptoms of confusion, seizures, and coma become apparent. Cardiac abnormalities such as hypotension, bradycardia, atrioventricular block, and ventricular dysrhythmias
,14 have been described but are very uncommon, and co­ingestions should be considered before attributing abnormalities solely to lithium toxicity.

Rare cases of adult respiratory distress syndrome have been associated with acute lithium toxicity.
Lithium is a neurotoxin, and neurologic symptoms predominate in chronic toxicity. Common symptoms include postural tremor (exaggerated physiologic tremor), muscle fasciculation, clonus, choreoathetoid movements, ataxia, muscle weakness, dysarthria, nystagmus, agitation, and
,16­19 lethargy. Although most patients present with a slowing of cognitive function, cases of lithium toxicity presenting with mania or auditory, visual, or tactile hallucinations have been reported. As toxicity worsens, confusion, lethargy, stupor, seizures, and finally coma develop. Less common toxic effects include hyperthermia, hypothermia, peripheral neuropathy, and severe leukopenia. Recognizing chronic lithium toxicity is difficult because it predominantly causes neurologic symptoms that are indistinguishable from organic causes of delirium, and symptoms do not reliably correlate with
,17,20,21 serum levels.
Most patients recover from chronic toxicity as the body burden of lithium decreases. The syndrome of irreversible lithium­effectuated neurotoxicity describes the persistent neurologic dysfunction caused by lithium that persists for >2 months after cessation of the drug in patients without prior neurologic illness. Cerebellar dysfunction is the key finding with syndrome of irreversible lithium­effectuated neurotoxicity, manifested by truncal
 ataxia, unsteady gait, tremor of the hands and head, scanning speech, and diffuse incoordination.
Acute­on­chronic toxicity results from a disruption in the balance of serum lithium concentrations in patients with a stable body burden from chronic therapy, most often precipitated by decreases in glomerular filtration or intravascular volume depletion or when a patient intentionally or
 unintentionally ingests an increased amount of lithium. The resulting lithium load in the presence of already saturated tissue leads to toxicity, with clinical symptoms mimicking both acute (GI symptoms) and chronic (neurologic symptoms) toxicity (Table 181­1).
TABLE 181­1
Clinical Features of Lithium Toxicity
Category Features
Mild Nausea, vomiting, fatigue, lethargy, fine tremor
Moderate Confusion, agitation, dysarthria, ataxia, hypertonia, hyperreflexia, nystagmus, muscular weakness
Severe Coma, seizures, myoclonus, hyperthermia, ventricular dysrhythmias, atrioventricular block, cardiovascular collapse
ADVERSE EFFECTS OF CHRONIC THERAPY
Adverse effects during therapeutic lithium use are common, occurring in up to 90% of treated patients. The most frequent adverse effects include fine postural hand tremor, fatigue, polyuria due to loss of urinary concentration ability, hypothyroidism, and
23­25 hyperparathyroidism with hypercalcemia. Worsening of a baseline tremor and development of ataxia or dysarthria are important signs of developing toxicity and may signal a need to decrease the dose of lithium.
Lithium is a common cause of drug­induced nephrogenic diabetes insipidus, which is prevalent in up to 40% of patients receiving long­term lithium
,27 treatment. The decreased urinary concentrating ability is usually compensated in patients by increased thirst. The ability of the distal nephron to acidify the urine can be impaired, causing an incomplete distal renal tubular acidosis without acidemia. Long­term lithium treatment can lead to a
,28 progressive nephropathy, with a mild reduction in glomerular filtration and approximately a 1% absolute risk of requiring renal replacement
28­30  therapy. Maintaining serum lithium levels <0.8 mEq/L (0.8 mmol/L) may reduce long­term renal damage.

ECG abnormalities commonly reported with lithium use include QT interval prolongation, T­wave flattening or inversion, and significant bradycardia.
,33
Hypothyroidism is the most prevalent endocrine dysfunction, occurring at a rate almost six times that in the general populace.

Hyperparathyroidism and hypercalcemia are frequently reported and can be associated with stimulation of hyperplasia or adenomas.
DIAGNOSIS
The patient’s history, symptoms, and signs should guide therapy, as opposed to a lithium concentration, which primarily serves as a marker of an
 exposure. Blood samples should be sent in lithium­free tubes because the use of lithiated heparin tubes can lead to falsely positive
 results up to  mEq/L (4 mmol/L). Therapeutic lithium levels are considered to be .6 to .2 mEq/L (0.6 to .2 mmol/L), and most patients manifesting toxic effects have levels >2 mEq/L (>2 mmol/L). Additional tests to obtain if acute toxicity is suspected include a CBC where leukocytosis can be seen and a metabolic panel to evaluate kidney function. In chronic toxicity, consider assessing thyroid function (thyroid­stimulating hormone and thyroid hormone levels) and renal concentrating ability (simultaneous serum and urine sodium, creatinine, and osmolality). In acute overdose, additional tests may be useful (see Chapter 176, “General Management of Poisoned Patients”).
TREATMENT
Initial stabilization of the patient’s condition includes protection of the airway and provision of respiratory and hemodynamic support. Establish IV access, initiate cardiac rhythm monitoring, and obtain an ECG. Information regarding the lithium formulation can aid in further treatment, such as immediate­ versus sustained­release tablets, doses, and quantity of ingestion. Subsequent treatment depends on clinical severity (Table 181­2).
TABLE 181­2
Management of Lithium Toxicity
IV saline infusion Used in essentially all patients with toxicity
Reestablishes euvolemia and normal lithium renal elimination
Whole­bowel Used in awake patients who ingest sustained­release lithium preparations irrigation
Hemodialysis Used for patients with severe toxicity
Also used for patients with renal failure, patients who cannot tolerate IV saline infusion, and patients with high elevated serum lithium levels (>4.0 mEq/L in any type of overdose and >2.5 mEq/L in chronic toxicity)
IV Used for seizures seen in severe toxicity benzodiazepines
GI decontamination has a limited role in lithium toxicity. Activated charcoal does not readily bind with lithium. Gastric lavage has no role in most cases of lithium overdose because the sustained­release preparations are often too large to fit through the lavage tubes and the immediate­release
 preparations are too rapidly absorbed in the GI tract. Whole­bowel irrigation with polyethylene glycol solution at  L/h is the only method of GI decontamination that has shown some efficacy in removing lithium in the setting of acute ingestion of the sustained­release formulation provided
 there is no evidence of airway compromise or intestinal obstruction.
The critical principle of lithium poisoning treatment is assessment of volume status and restoration of intravascular volume. IV administration of
,37 normal saline is required in nearly all patients with significant toxicity because of sodium and volume deficits. Typical adult dosing is an IV bolus of normal saline  mL/kg, followed by continuous infusion at .5 to  times the maintenance rate. Volume repletion reestablishes normal renal elimination kinetics of lithium. Diuretic­induced diuresis does not enhance lithium elimination, and in fact, loop and thiazide diuretics promote water loss, which is followed by lithium retention.
,12
Lithium is amenable to extracorporeal removal. Consensus recommendations from the Extracorporeal Treatment in Poisoning Workgroup are to use extracorporeal treatment, such as dialysis, for severe lithium toxicity (coma, seizures, life­threatening dysrhythmias) or a serum lithium level >4.0
 mEq/L (>4 mmol/L) in the presence of renal insufficiency. Intermittent hemodialysis is the preferred modality, with continuous renal replacement
 being an acceptable alternative. The goal of hemodialysis is to reduce the total body burden of lithium, but because the molecule is primarily intracellular and slowly diffuses across the cell membrane, removal of extracellular lithium through intermittent hemodialysis results in redistribution from the intracellular to extracellular compartments, causing a postdialysis rebound increase in serum lithium concentrations. Therefore, it is essential to monitor serum lithium levels for up to  hours after hemodialysis, and if symptoms recur or serum levels rise significantly, consider repeat hemodialysis. Peritoneal dialysis is no longer recommended because the clearance rates are approximately the same as through normal renal clearance with potential for complications such as bowel perforation.
Treat seizures with IV benzodiazepines, such as lorazepam, because phenytoin is ineffective in controlling drug­induced seizures. Consultation with a medical toxicologist is recommended for patients with serious toxicity.
DISPOSITION

Admission decisions are made by considering acuity of the toxicity and the circumstances that led to the toxicity. Asymptomatic patients with acute ingestions should be monitored for  to  hours, with measurement of serial serum lithium levels. Admit patients with serum lithium levels of >1.5 mEq/L (>1.5 mmol/L) after an acute ingestion. Any patient with an acute ingestion of a sustained­release preparation should be admitted regardless of serum lithium level and observed for signs and symptoms of lithium toxicity.
Patients with mild toxicity who have no additional risk factors may be managed with IV saline treatment for  to  hours, often in an observation unit.
Once repeated serum lithium levels decrease to <1.5 mEq (<1.5 mmol/L), patients can be discharged after psychiatric evaluation, if needed. Patients with moderate toxicity require admission, and patients with severe toxicity require intensive care and consideration for extracorporeal removal.
Patients taking lithium may seek care in the ED for conditions not related to mental health or lithium toxicity. Take care to avoid prescribing any drugs that negatively impact glomerular filtration and renal function. Thiazide diuretics, loop diuretics, NSAIDs, angiotensin­converting enzyme inhibitors,
 and angiotensin receptor II blockers are common agents with potential for lithium interaction promoting toxicity.


