## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 54: Valvular Emergencies
William D. Alley
INTRODUCTION
Although acute valvular dysfunction may cause dramatic symptoms, most valvular heart disease encountered in the ED is chronic and incidentally noted on exam. Adaptive responses preserve cardiac function and delay the diagnosis of chronic valvular disease but contribute to eventual cardiac dysfunction. Compared with the general population, patients with clinically evident valvular heart disease have a .5­fold higher death rate and a 3­fold
 increased rate of stroke.
THE NEWLY DISCOVERED MURMUR
After discovering a new murmur, the first step in the ED is to determine its clinical significance. Seek a new murmur in patients with acute dyspnea or weakness. Benign or physiologic murmurs are common and do not cause symptoms or findings compatible with cardiovascular disease; they are generally soft systolic ejection murmurs that begin after S , end before S , and are not associated with other abnormal heart sounds. Systolic murmurs
  may be associated with anemia, sepsis, volume overload, or other conditions causing an increased cardiac output. Focus the evaluation and treatment on the trigger. Patients without chest pain, dyspnea, fever, or other signs attributable to valvular disease do not need emergent treatment.
Any diastolic murmur or new systolic murmur with symptoms at rest is pathologic and warrants emergent echocardiography (Figure
54­1). Think of endocarditis, especially in suspected valvular insufficiency. Table 54­1 presents a grading system for murmurs.
TABLE 54­1
A Grading System for Murmurs
Grade Description
 Faint, may not be heard in all positions
 Quiet, but heard immediately with stethoscope placement onto the chest wall
 Moderately loud
 Loud
 Heard with stethoscope partly off the chest wall
 Heard when stethoscope is entirely off the chest wall
FIGURE 54­1. Algorithm for evaluation of newly discovered systolic murmur. CXR = chest radiograph.

Chapter 54: Valvular Emergencies, William D. Alley 
. Terms of Use * Privacy Policy * Notice * Accessibility
MITRAL STENOSIS
EPIDEMIOLOGY AND PATHOPHYSIOLOGY
Mitral stenosis prevents normal diastolic filling of the left ventricle. Rheumatic heart disease remains the most common cause worldwide. Rheumatic carditis causes fusion of valvular commissures, matting of chordae tendineae, and eventual calcification and limited mobility of the valve. Valvular obstruction is slowly progressive, often with  to  years before onset of symptoms. Mitral valve obstruction causes left atrial pressure to rise, resulting in left atrial enlargement, pulmonary congestion, pulmonary hypertension, and frequently atrial fibrillation. In severe disease, pulmonary hypertension may lead to pulmonic and tricuspid valve incompetence, pulmonary edema, right­sided heart failure, and bronchial vein rupture.
Mitral annular calcification is a slowly progressive nonrheumatic cause of mitral stenosis. It is more common among women, the elderly, and those
 with hypertension or with chronic renal failure. Due to its slow progression, mitral annular calcification rarely causes severe symptoms.
CLINICAL FEATURES
Exertional dyspnea is the most frequent presenting complaint, and orthopnea and palpitations/premature atrial contractions are also common.
Symptoms associated with left­ or right­sided heart failure may occur with more severe obstruction. Systemic emboli are also a risk. Hemoptysis is a rare presenting symptom, although it can be massive.
Signs of mitral stenosis include a mid­diastolic rumbling murmur with crescendo toward S . With the onset of atrial fibrillation, the presystolic
 accentuation of the murmur disappears. Typically, the S is loud and is followed by a loud opening snap that is high pitched and best heard to the right
 of the apex (Table 54­2). The apical impulse is small and tapping due to an underfilled left ventricle. Systemic blood pressure is typically normal or low. If pulmonary hypertension is present, signs may include a thin body habitus, peripheral cyanosis, and cool extremities.
TABLE 54­2
Comparison of Heart Murmurs, Sounds, and Signs
Valve
Murmur Heart Sounds and Signs
Disorder
Mitral Mid­diastolic rumble, crescendos into S Loud snapping S , small apical impulse, tapping due to underfilled ventricle
  stenosis
Mitral Acute: harsh apical systolic murmur starts with S S and S may be heard
   regurgitation and may end before S

Chronic: high­pitched apical holosystolic murmur radiating into S

Mitral valve Click may be followed by a late systolic murmur Mid­systolic click; S may be diminished by the late systolic murmur
 prolapse that crescendos into S

Aortic Harsh systolic ejection murmur Paradoxical splitting of S , S , and S may be present; pulse of small amplitude
   stenosis with a slow rise and sustained peak
Aortic High­pitched blowing diastolic murmur S may be present; wide pulse pressure
 regurgitation immediately after S

DIAGNOSIS AND TREATMENT
The ECG is not diagnostic but may demonstrate notched or biphasic P waves and right axis deviation in patients with mitral stenosis (Figure 54­2). On chest radiograph, straightening of the left heart border, indicating left atrial enlargement, is a typical and early radiographic finding. Eventually, pulmonary congestion occurs.
FIGURE 54­2. The ECG in mitral stenosis, demonstrating left atrial enlargement and right axis deviation. Note abnormal P waves in lead V .

Echocardiography is the test to diagnose mitral stenosis (Figure 54­3). Before any interventions, transesophageal echocardiography offers the best
 assessment of any mitral regurgitation and the presence of a left atrial thrombus.
FIGURE 54­3. Parasternal long­axis view of mitral stenosis. The left atrium is enlarged, mitral opening is limited, and doming of the anterior mitral leaflet is present.
AO = aorta; LA = left atrium; LV = left ventricle; RV = right ventricle. [Reproduced with permission from Fuster V, O’Rourke RA, Walsh RA, Poole­Wilson P
(eds): Hurst’s the Heart, 12th ed. © 2008, McGraw­Hill, New York.]
Medical management focuses primarily on symptom control and anticoagulation. Patients in atrial fibrillation or with dyspnea on exertion may benefit from heart rate control with a β­blocker or calcium channel blocker. Experts recommend anticoagulation if the left atrial diameter is >55 mm or the patient has atrial fibrillation, a left atrial thrombus, or history of systemic emboli. In patients with hemoptysis from mitral stenosis–induced pulmonary hypertension, bleeding may be severe enough to require blood transfusion, emergent bronchoscopy, and consultation with a thoracic surgeon.
The most important ED action for patients with suspected but asymptomatic mitral stenosis is recognition and referral. The primary treatment for symptomatic disease is percutaneous mitral commissurotomy, optimally performed before onset of severe pulmonary hypertension.
MITRAL REGURGITATION
EPIDEMIOLOGY AND PATHOPHYSIOLOGY
Mitral regurgitation occurs when a dysfunctional valve allows retrograde blood flow from the left ventricle into the left atrium during systole. Most patients with mitral regurgitation follow a chronic and slowly progressive course. Fibroelastic deficiency syndrome is the most common cause, seen
 primarily in the elderly. Mitral valve prolapse is another cause and is typically found in younger patients. Secondary mitral regurgitation occurs when a dilated left ventricle causes papillary muscle displacement and valve dysfunction.
In chronic mitral regurgitation, the left atrium dilates to accommodate increasing regurgitant flow to keep left atrial pressure near normal. Stroke volume augments flow, maintaining effective forward flow despite a large regurgitant volume. In contrast, acute mitral regurgitation results in acute left­sided heart failure. Cardiogenic shock may ensue from impaired forward blood flow. Acute mitral regurgitation is typically caused by papillary muscle or chordae tendineae rupture from myocardial infarction or valve leaflet perforation from infective endocarditis. Blunt thoracic trauma and spontaneous chordae tendineae rupture are other rare causes.
CLINICAL FEATURES
Symptoms of acute mitral regurgitation are severe dyspnea, tachycardia, and pulmonary edema. Cardiogenic shock or cardiac arrest can develop rapidly. Typical signs include an S gallop and a harsh apical systolic murmur loudest in early or mid­systole, diminishing before S (Table 54­2),
  although the murmur may not be audible over breath sounds. A hyperactive apical impulse may be apparent. Overwhelming dyspnea may mask chest pain in the setting of ischemia.
Chronic mitral regurgitation can be tolerated for years without symptoms. Eventually exertional dyspnea develops, sometimes associated with palpitations or atrial fibrillation. Signs include a late systolic left parasternal lift and lateral displacement of the apical impulse. A high­pitched holosystolic murmur is best heard in the fifth intercostal space and mid­left thorax and radiates to the axilla. The first heart sound is soft and often obscured by the murmur. An S is usually heard and is followed by a short diastolic rumble, indicating increased flow into the left ventricle.

DIAGNOSIS AND TREATMENT
Think of acute mitral regurgitation in any patient with new­onset and marked pulmonary edema, especially in patients with near­normal heart size on chest radiograph or in those who do not respond to conventional therapy. Obtain an ECG to look for signs of ischemia, frequently in the inferior or anterior walls. In chronic mitral regurgitation, the ECG may demonstrate left atrial enlargement and left ventricular hypertrophy, and the chest radiograph shows left atrial and ventricular enlargement that is proportional to the severity of the regurgitant volume. Transthoracic echocardiography (Figure 54­4) diagnoses mitral regurgitation but may underestimate the severity of regurgitation. If nondiagnostic, cardiac MRI or
 transesophageal echocardiography may be undertaken. Exercise stress echocardiography may aid diagnosis.
FIGURE 54­4. A transthoracic echocardiogram demonstrating severe mitral regurgitation. Color flow Doppler shows regurgitant flow back into the left atrium.
For acute mitral regurgitation due to papillary muscle rupture, emergency surgery is the treatment of choice. In the ED, start therapy with oxygen and positive­pressure ventilation for respiratory failure (see Chapter , “Acute Heart Failure”). Nitrates provide afterload reduction, which results in increased forward flow into the aorta. Inotropic therapy with dobutamine may be necessary. Aortic balloon counterpulsation increases forward flow and mean arterial pressure while diminishing regurgitant volume and left ventricular filling pressure.

Treatment of severe mitral regurgitation from acute myocardial infarction includes emergent revascularization. Endocarditis causing acute mitral valve insufficiency requires additional antibiotic therapy (see Chapter 156, “Endocarditis”).
Medical therapy may improve regurgitant flow and allow a delay to surgery. The key is emergency cardiology and surgical consultation while medically optimizing care.
In patients with chronic mitral regurgitation, emergency treatment is based on acute symptoms. Control atrial fibrillation with rapid ventricular response with β­blockers or calcium channel blockers, and start anticoagulation to avoid embolization. Long­term management is best decided by the primary care provider or a cardiologist.
MITRAL VALVE PROLAPSE
EPIDEMIOLOGY AND PATHOPHYSIOLOGY
Mitral valve prolapse is a systolic billowing of one or both leaflets into the left atrium occurring with or without mitral regurgitation. It is characterized by myxomatous degeneration of the valve caused by heritable defects in connective tissue proteins. It is the most common valvular heart disease in
 industrialized countries, affecting approximately .4% of the population. Morbidity and mortality follow the presence of concomitant mitral
 regurgitation.
CLINICAL FEATURES
Most patients with mitral valve prolapse are asymptomatic, but symptoms may include chest pain, palpitations, fatigue, anxiety, and dyspnea unrelated
 to exertion. Signs such as scoliosis, pectus excavatum, and low body weight can exist. If exercise induces symptoms, morbidity increases.
The classic auscultatory finding is a mid­systolic click (Table 54­2). Maneuvers that decrease preload, such as Valsalva or standing, will cause the click to occur earlier in diastole. Increasing preload by squatting or afterload by hand grips causes the systolic click to move later in systole. A late systolic murmur that crescendos into S may be present.

DIAGNOSIS AND TREATMENT
The diagnosis is unlikely to be made in the ED. The emergency evaluation focuses on late complications such as atrial fibrillation or heart failure. The
ECG is usually normal. If suspecting mitral valve prolapse, refer the patient for outpatient echocardiography to confirm the diagnosis and to identify
 any complications.
ED treatment is rarely required. Patients with palpitations attributed to mitral valve prolapse may respond to oral β­blockers, but that is typically left to the cardiologist or primary care physician. Antithrombotic therapy is not routinely recommended unless complicated by transient ischemic attacks,
,11  stroke, or atrial fibrillation. Patients with concomitant mitral regurgitation require endocarditis prophylaxis (see Chapter 156).
AORTIC STENOSIS
EPIDEMIOLOGY AND PATHOPHYSIOLOGY
Aortic stenosis prevents left ventricular outflow. In the United States, the most common cause in adults is degenerative calcification (calcific aortic
,13 stenosis), associated with increasing age, hypertension, smoking, elevated cholesterol, and diabetes. Rheumatic heart disease is a major cause of aortic stenosis worldwide. Bicuspid aortic valves and congenital heart disease are causes as well, especially in younger patients.
The typical course involves a long asymptomatic period, during which the left ventricle hypertrophies to preserve ejection fraction. Ventricular hypertrophy eventually impairs diastolic filling and increases myocardial oxygen demand. Slowly, aortic valve obstruction worsens, cardiac output diminishes, and systemic blood flow and coronary blood flow are impaired.
CLINICAL FEATURES
The classic triad of aortic stenosis is dyspnea, chest pain, and syncope. However, many patients with severe stenosis (aortic valve area <1.0
 cm ) are asymptomatic. Often, a long asymptomatic period is followed by stepwise onset of symptoms starting with dyspnea followed by chest pain,
 then syncope, and finally signs of heart failure. Once symptoms start, mortality increases. Decreased exercise tolerance and exertional dyspnea or dizziness may be unnoticed or unreported prior to more ominous symptoms.
Classic physical examination findings are a late peaking systolic murmur at the right second intercostal space radiating to the carotids, a single or paradoxically split S , an S gallop, and a diminished carotid pulse with a delayed upstroke (pulsus parvus et tardus; Table 54­2). Brachioradial delay
  may also be a useful early finding, as is a narrowed pulse pressure.
Aortic stenosis with atrial fibrillation can have dire consequences given the common diastolic dysfunction and preload dependence to maintain cardiac output. Without effective atrial contraction, cardiac output drops dramatically, especially if the patient is given nitroglycerin to treat chest pain or dyspnea.
DIAGNOSIS AND TREATMENT
ECG and chest radiograph lack sensitivity and specificity. The ECG usually demonstrates left ventricular hypertrophy, and a left or right bundle branch block may be present. The chest radiograph is normal early in the disease, but eventually signs of left ventricular hypertrophy and acute heart failure develop. Echocardiography confirms the diagnosis and determines severity (Figure 54­5). Low­dose dobutamine stress echocardiography aids
 identification prior to the development of classic symptoms.
FIGURE 54­5. Parasternal long­axis plane demonstrating a thickened, stenotic aortic valve. Ao = aorta; LA = left atrium; LV = left ventricle. [Reproduced with permission from Fuster V, O’Rourke RA, Walsh RA, Poole­Wilson P (eds): Hurst’s the Heart, 12th ed. © 2008, McGraw­Hill, New York.]
Treat pulmonary edema with oxygen and positive­pressure ventilation as necessary. Negative inotropic drugs, such as β­blockers or calcium channel blockers, are often poorly tolerated. Use nitrates, vasodilators, and diuretics with close monitoring because reducing preload may cause significant hypotension. New­onset atrial fibrillation may require cardioversion to maintain cardiac output.
Surgical management, either open or by transcatheter approach, is a mainstay of treatment. Without surgery, 40% to 50% of patients with classic
,16 symptoms die within  year. Patients discharged from the ED should avoid vigorous physical activity and be seen promptly by a cardiologist.

Endocarditis in isolated aortic stenosis is uncommon, and antibiotic prophylaxis is not routinely recommended (see Chapter 156).
AORTIC REGURGITATION
EPIDEMIOLOGY AND PATHOPHYSIOLOGY
Aortic regurgitation occurs when valve leaflets fail to close fully, causing blood to flow from the aorta into the left ventricle during diastole. Over time, increased left ventricular wall stress leads to hypertrophy. Increased stroke volume followed by a rapid pressure drop during diastole causes wide pulse pressures. Tachycardia shortens diastole, which decreases regurgitant volume and mutes symptoms early in the disease. In contrast, increased afterload during stress or isometric exercise exacerbates regurgitant flow and may precipitate symptoms. Over time, the combination of increasing left ventricular dilatation and hypertrophy compromises systolic function, resulting in heart failure.
Among patients in the Framingham Heart Study receiving echocardiography, aortic insufficiency existed in 13% of men and .5% of women, mostly of
 trace or minor severity. Approximately half of cases are due to valvular leaflet problems from bicuspid aortic valves, infective endocarditis, or
 rheumatic disease. Nonvalvular causes include aortic dissection, Marfan’s syndrome, or aortitis. Aortic regurgitation is also frequently associated with aortic stenosis.
CLINICAL FEATURES
Acute aortic regurgitation generally presents rapidly, with dyspnea and pulmonary edema being the most common presenting symptoms. To maintain cardiac output, tachycardia develops but is often inadequate, resulting in cardiogenic shock or cardiac arrest. Sudden­onset ripping or tearing interscapular pain suggests aortic dissection. Fever or history of IV drug abuse suggests endocarditis.
On physical exam, the classic finding is a high­pitched blowing diastolic murmur heard immediately after S , in the second or third intercostal space at
 the left sternal border (Table 54­2). In acute disease, the murmur may be inaudible due to tachycardia, tachypnea, and rales. A systolic ejection murmur due to increased stroke volume and an S due to ventricular dilatation may exist. In the left lateral decubitus position, listen for a mid­diastolic rumble

(Austin Flint murmur) using the bell of the stethoscope at the cardiac apex. A widened pulse pressure is also common. The classic “water hammer pulse” (Corrigan pulse) is a peripheral pulse with a quick rise in upstroke due to increased stroke volume followed by collapse from a rapid fall in diastolic pressure. Other classic findings include accentuated precordial apical thrust, pulsus bisferiens, Duroziez sign (a “to­and­fro” femoral murmur), de Musset sign (pulsatile head bobbing), and Quincke sign (capillary pulsations visible at the proximal nail bed while pressure is applied at the tip).
Patients with chronic aortic regurgitation typically present with exertional dyspnea or fatigue. Chest pain may occur from myocardial ischemia due to low diastolic pressures that decrease coronary blood flow. Symptoms of left ventricular failure may occur late in the disease, but greater than one
 quarter of patients with chronic aortic regurgitation die or develop left heart dysfunction before symptoms occur.
DIAGNOSIS AND TREATMENT
ECG findings are generally nonspecific. The most common abnormality is left ventricular hypertrophy. Ischemic changes or ST elevation may be seen from aortic dissection involving the coronary arteries. In chronic aortic regurgitation, the chest radiograph reveals cardiomegaly, aortic dilatation, and,
 possibly evidence of congestive heart failure. Echocardiography confirms the diagnosis and determines the cause and severity of regurgitation.
Unstable patients require emergency echocardiography (Figure 54­6). Chest radiograph may show acute pulmonary edema without cardiac enlargement. If due to aortic dissection, the chest radiograph may show a widened mediastinum (see Chapter , “Aortic Dissection and Related Aortic
Syndromes”). If suspecting aortic dissection, perform CT angiogram.
FIGURE 54­6. Parasternal long­axis view with blue regurgitant jet demonstrating severe aortic regurgitant flow back into the left ventricle. [Reproduced with permission from Ma OJ, Mateer JR, Reardon RF, Joing SA (eds): Ma & Mateer’s Emergency Ultrasound, 3rd ed. New York: McGraw­Hill Education; 2014,
Figure 6­73B.]
Acute aortic regurgitation requires immediate surgical intervention. Treat pulmonary edema with oxygen and intubation for respiratory failure.
Vasodilators such as nitroprusside, combined with inotropic agents such as dobutamine or dopamine, may augment forward flow and reduce left ventricular end­diastolic pressure. Diuretics and nitrates are usually ineffective. Although β­blockers are commonly used in aortic dissection, avoid these in acute aortic regurgitation because they block the compensatory tachycardia that is critical in maintaining cardiac output. Intraaortic balloon counterpulsation is also contraindicated because it worsens regurgitant flow. Despite intensive medical management, death from ventricular dysrhythmias, pulmonary edema, or cardiogenic shock is common. In patients with only mild acute aortic regurgitation due to endocarditis, antibiotics may be adequate treatment without acute surgical intervention.
Chronic aortic regurgitation is usually treated with vasodilators such as angiotensin­converting enzyme inhibitors or dihydropyridine calcium channel
 blockers. If acute symptoms such as pulmonary edema or chest pain occur, admit the patient for stabilization and further management. Patients who become symptomatic, have a low ejection fraction, or have significant left ventricular dilatation are candidates for aortic valve replacement, either open or by transcatheter approach.
RIGHT­SIDED VALVULAR HEART DISEASE
EPIDEMIOLOGY AND PATHOPHYSIOLOGY
The incidence of true right­sided valvular heart disease is unknown because normal subjects frequently have a small amount of tricuspid and pulmonary valve regurgitation at baseline. Pathologic tricuspid regurgitation is usually due to elevated right heart pressure or volume overload, such as from pulmonary hypertension, chronic lung disease, pulmonary embolism, or atrial septal defects. Tricuspid stenosis is rare and is generally accompanied by regurgitation. The pulmonic valve is the least likely valve to be affected by acquired disease. Most pulmonic valvular disease is congenital (see Chapter 129, “Congenital and Acquired Pediatric Heart Disease”), although pulmonary hypertension, rheumatic heart disease, and carcinoid syndrome can rarely cause some degree of pulmonic valve disease. Acute onset of symptomatic tricuspid disease is most often due to endocarditis. Tricuspid valve endocarditis typically involves aggressive organisms, such as Staphylococcus aureus, which can cause rapid valve destruction.
CLINICAL FEATURES
Clinically significant right­sided valvular disease causes signs and symptoms of right heart failure such as jugular venous distention, peripheral edema, hepatomegaly, splenomegaly, and ascites. Exertional dyspnea is often the first symptom in patients with right­sided valvular disease associated with pulmonary hypertension. Patients with tricuspid valve regurgitation from endocarditis may have signs of sepsis. The murmur of tricuspid valve regurgitation is soft, blowing, and holosystolic. It is best heard along the lower left sternal border and increases with inspiration. A systolic waveform in the jugular vein, hepatic pulsations, and systolic eyeball propulsion may be seen in severe tricuspid incompetence. Tricuspid valve stenosis is associated with a rumbling crescendo­decrescendo diastolic murmur occurring just before S . This murmur is best heard along the lower left sternal
 border, increases with inspiration, and is often preceded by an opening snap.
Pulmonic stenosis often presents with exertional dyspnea, syncope, chest pain, and signs of right heart failure. There is a harsh systolic murmur, best heard in the left second intercostal space, which increases with inspiration. A loud ejection click may precede the murmur, and an S is often
 heard. Pulmonic regurgitation is associated with a high­pitched and blowing diastolic murmur (Graham Steell murmur), which increases in intensity during inspiration and is best heard over the left second and third intercostal spaces. An S gallop is often present. Patients with severe right­sided
 valvular disease typically have a palpable right ventricle thrill or heave.
DIAGNOSIS AND TREATMENT
The diagnosis of right­sided valvular heart disease requires echocardiography (Figure 54­7), with transesophageal echocardiography being the most sensitive modality. Chest radiograph and ECG are often nonspecific. Chest radiograph may show signs of right atrial and ventricular enlargement. In pulmonic stenosis, there may be dilatation of the left pulmonary artery. ECG may demonstrate right atrial enlargement and signs of right ventricular hypertrophy.
FIGURE 54­7. Apical view color flow Doppler echocardiogram of tricuspid regurgitation. The regurgitant jet is blue in color. [Reproduced with permission from Ma
OJ, Mateer JR, Reardon RF, Joing SA (eds): Ma & Mateer’s Emergency Ultrasound, 3rd ed. New York: McGraw­Hill Education; 2014, Figure 6­36.]
Treatment of right­sided valvular heart disease is aimed at the underlying cause. Treat endocarditis with antibiotics. For patients with functional tricuspid or pulmonic regurgitation, treat the cause of pulmonary hypertension or right­sided failure. Diuretics treat the effects of elevated venous
 pressure, such as lower extremity edema, ascites, and hepatic congestion. Patients with symptomatic pulmonic or tricuspid stenosis may be candidates for balloon valvotomy, and those with severe tricuspid regurgitation due to a structural valve abnormality may require valve replacement.
PROSTHETIC VALVE DISEASE
PATHOPHYSIOLOGY
Prosthetic valves are divided into two basic groups: mechanical and bioprosthetic. Mechanical valves are more durable with lower failure rates, but
 have a higher risk for thromboembolic complications. Life­long anticoagulation is necessary to reduce the thromboembolic risk. Mechanical mitral
,10 valves require an INR of .5 to .5, whereas bileaflet mechanical valves in the aortic position require an INR of .0 to .0. Without anticoagulation, the
,21 risk of valve thrombosis or thromboembolism is about 8%, falling to 1% to 2% per year with anticoagulation. Embolic risk is highest during the first
 postoperative months. Emboli are more common from mitral rather than from aortic valves. Bioprosthetic valves, from porcine, bovine, or human sources, are less thrombogenic but are more likely to fail and require repeat surgery. Antiplatelet therapy is recommended for all patients with prosthetic valves.
Prosthetic valves may malfunction in several ways, including thrombosis, dehiscence of sutures, gradual degeneration, or even sudden fracture.
Symptoms are often slowly progressive, but in acute failures, severe symptoms and death may occur rapidly. Prosthetic valve endocarditis occurs in up
,22 to 6% of patients within  years of surgery and carries high mortality.
CLINICAL FEATURES
Symptoms of prosthetic valve dysfunction depend on the type and location of the valve. Patients with prosthetic valves experience some symptoms specific to the presence of the artificial valve. Thromboembolism may cause systemic symptoms such as transient neurologic symptoms, amaurosis fugax, or self­limited ischemic episodes in the extremities or organs. Major embolic events include stroke, mesenteric infarction, or sudden death.
Prophylaxis against thrombotic complications of prosthetic valves with systemic anticoagulation causes major bleeding in approximately .4% of
 patients per year, with hemorrhagic stroke being the most common lethal bleeding complication.
Acute onset of respiratory distress, pulmonary edema, and cardiogenic shock may be associated with mechanical valve failure, tearing of a bioprosthesis, or a large clot obstructing the valve or preventing closure. Failures often result in sudden death. A paravalvular leak also presents with congestive heart failure. The severity of symptoms is dependent on leak size and how rapidly the leak develops.
Patients with bioprostheses usually have a normal S and S , with no abnormal opening sounds. Mechanical valves normally have a loud, clicking,
  metallic sound associated with valve closure. Systolic murmurs of prosthetic aortic valves are common, but loud diastolic murmurs should be considered pathologic; a “quiet” mechanical valve is concerning. A loud holosystolic murmur indicates prosthetic mitral valve dysfunction. Aortic bioprostheses usually cause a short mid­systolic murmur, and mitral bioprostheses may cause a short diastolic rumble.
DIAGNOSIS OF PROSTHETIC VALVE DYSFUNCTION OR COMPLICATIONS
Echocardiography is the diagnostic test of choice. Chest radiograph lacks sensitivity and specificity but may show a change in valve position or signs of heart failure. Obtain a head CT in patients with focal neurologic deficits to evaluate for hemorrhage or embolic stroke. Patients on anticoagulation require specific measures of that effect along with a CBC; in addition, obtain blood cultures for suspected endocarditis in these patients.
TREATMENT AND DISPOSITION
Emergency treatment for acute prosthetic valve dysfunction requires cardiology and cardiothoracic surgery consultation. Emergent surgery, thrombolytic therapy, and intensification of anticoagulation are potential therapies for acute valve thrombosis.
REVERSAL OF ANTICOAGULATION WITH PROSTHETIC VALVES
Patients with prosthetic valves seen in the ED are frequently on prophylactic anticoagulation. Emergency physicians must know how to treat supratherapeutic anticoagulation with or without bleeding. An INR >5 confers a high risk of excess bleeding, but rapid changes in anticoagulation pose an equally ominous risk of valve thrombosis and thromboembolism. Factor Xa levels help guide direct oral anticoagulant use, but these agents are not commonly used in valve care. Patients with an INR of  to  without bleeding have warfarin withheld; another possible added step is low­dose oral vitamin K reversal, .0 to .5 milligrams. Patients with severe bleeding complications are best treated with fresh frozen plasma or
  prothrombin complex concentrate. Avoid parenteral, high­dose vitamin K due to risk of overcorrection.


