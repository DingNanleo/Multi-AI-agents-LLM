## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 108: Resuscitation of Neonates
Marc F. Collin
INTRODUCTION AND EPIDEMIOLOGY
Resuscitation of the newborn is required to some extent in nearly 10% of all births. Extensive resuscitation is required in about 1%. Delivery room resuscitation is required for >50% of the high­risk population of very­low­birth­weight (<1500 grams) newborns. Worldwide, nearly 25% of neonatal
 deaths result from birth asphyxia. With proper antenatal and intrapartum surveillance, the potential need for active resuscitation at birth can often be identified before birth. Unfortunately, the arrival of a newborn to the ED is never planned. This chapter reviews the principles of emergency resuscitation of neonates.
PATHOPHYSIOLOGY
The transition from intrauterine to extrauterine life is a high­risk time. Even the normal laboring process places significant stress on the placental–fetal unit. Blood flow and, therefore, oxygen delivery are transiently impaired during uterine contractions. Compression of the umbilical cord, when it occurs, further impairs circulatory flow. Although antenatal/intrapartum US imaging and fetal heart tone monitoring have permitted better surveillance of fetal well­being, prediction of fetal status at birth remains inexact. Maternal complications of pregnancy can predispose newborns to complications and include infections, chronic or gestational disease (e.g., diabetes, lupus), and illicit or prescribed medication use. Complications of labor, such as preterm delivery and/or prolonged rupture of membranes, maternal fever, breech or transverse fetal position, placental abruption, and umbilical cord problems such as a nuchal cord (cord wrapped around the neck) or true knots in the cord, can significantly heighten the risk to the fetus.
Once delivery occurs, the newborn still faces a variety of risks as the transition to extrauterine life unfolds. Requirements of this transition include the onset of respiration, absorption of lung fluid, reduction of pulmonary vasculature resistance to allow flow to the pulmonary vascular circuit, and closure of the ductus arteriosus and foramen ovale. Premature infants and infants who are small for gestational age are at risk for additional challenges in transitioning from fetal to infant physiology including insufficient pulmonary surfactant, fragile germinal matrices within the cerebral ventricles, and thin skin that impairs thermoregulation. The transition from the sterile intrauterine environment to the extrauterine world teeming with bacteria places yet another burden on the newborn.
CLINICAL FEATURES
HISTORY
Obtain a brief history from the mother, including the date of last menstrual period/estimation of gestational age, number of fetuses, number of previous pregnancies and living children, history of diabetes, hypertension or pregnancy­related problems, prenatal care (including blood group, infectious serologies, genetic and US screening, and known congenital anomalies), prolonged rupture of membranes, fever, and meconium­stained amniotic fluid.
PHYSICAL EXAMINATION
The need for resuscitation or routine newborn care is determined by the initial physical examination. For the term infant who is crying or breathing and who has good muscle tone at delivery, provide routine newborn care with the infant skin­to­skin on the mother. A slightly more detailed examination using the Apgar scoring system has been used for generations to assist medical personnel in assessing newborns both for the need for resuscitation and the response to resuscitation. Evaluate the newborn at  and  minutes after delivery for heart rate (absent = , <100/min = ,
>100/min = 2), respiratory effort (absent = , weak = , crying or normal = 2), muscle tone (limp = ; some flexion = ; active, fully flexed = 2), reflex
 irritability (no response = , grimace = , crying or active = 2), and color (blue or pale = , acrocyanosis = , completely pink = 2). If the 5­minute Apgar
Chapter 108: Resuscitation of Neonates, Marc F. Collin score is <7, continue Apgar scoring at 5­minute intervals until a score of  or more is reached. The expanded Apgar scoring system includes a section to
. Terms of Use * Privacy Policy * Notice * Accessibility
 document resuscitative measures. For infants requiring resuscitation, monitor pulse oximetry with the probe placed on the newborn’s right hand
(preductal) (see discussion of targets for resuscitation below).
LABORATORY EVALUATION
Routine laboratory studies are not required for most term or preterm deliveries. However, obtain point­of­care glucose testing in infants born to diabetic mothers, infants who are small or large for gestational age, or depressed or irritable infants, or if there is poor response to the initial steps of resuscitation. Obtain a CBC and type and screen or cross­match of blood in infants requiring significant resuscitation in the setting of suspected blood loss.
IMAGING
Routine imaging is not required for most deliveries. In rare circumstances, a radiograph of the chest and abdomen may be useful to confirm endotracheal tube placement, suspected pneumothorax, and some congenital defects (e.g., diaphragmatic hernia).
PREPARATION AND EQUIPMENT
EQUIPMENT
Table 108­1 lists equipment that may be needed during neonatal resuscitation. A compressed air source, an oxygen blender with flow meter, pulse oximetry for neonatal use, bag­valve masks, and laryngeal mask airways are standard resuscitation equipment.
TABLE 108­1
Neonatal Resuscitation Equipment
Radiant warmer with servocontrol temperature sensor
Prewarmed towels/receiving blankets
Wall suction, suction catheters, bulb syringes
Heated, humidified oxygen source
Compressed air source and oxygen blender
Cardiorespiratory monitor/monitor leads
Pulse oximeter
Bag (T­piece, flow­inflating or self­inflating) with manometer
Masks (sizes , , , 4)
Laryngoscope (0,  blade)
Endotracheal tubes (2.5, .0, .5, .0)
Meconium aspirator
CO detector

Nasogastric tubes (5F, 8F)
IV infusion equipment
IV fluids (10% dextrose in water, normal saline)
Umbilical catheter tray
Curved hemostat
Two iris curved forceps, no teeth
Scalpel handle/blade
Needle holder
Scissors
Syringes
 ×  gauze sponges
.5F, 5F umbilical catheters
Three­way stopcock
Suture material
Umbilical tape
Povidone­iodine solution
Polyethylene bags or plastic wrap
UMBILICAL CORD CLAMPING
Do not clamp the umbilical cord of newborns (term or preterm) who do not require positive­pressure ventilation or immediate resuscitation for at least
 to  minutes after birth. Delayed cord clamping reduces the need for blood transfusion, increases neonatal iron stores, and may decrease the risk of
 requiring treatment for hyperbilirubinemia. For newborns requiring immediate intervention, the cord should be clamped and cut to allow for initiation of therapy.
ROUTINE NEWBORN CARE
Provide routine newborn care to term infants who are breathing or crying with good tone. Leave the newborn with the mother, provide warmth (skinto­skin or blankets), clear the nose and mouth with bulb suction only if signs of obstructed breathing are noted, dry the baby, and provide ongoing assessment of respiratory effort and tone. Even before initiation of the ABCs (airway, breathing, circulation) of resuscitation, provide a neutral thermal environment for the newborn. Although vigorous term infants may be placed skin­to­skin with their mother for warmth, preterm or depressed newborns should be placed under a preheated radiant heat source with care taken not to overheat. Place the infant on his or her back in the warmer.
Then, gently dry the newborn with a warm towel while preparing to initiate resuscitation. Very­low­birth­weight newborns and those <29 weeks of estimated gestational age should be placed in polyethylene bags that have been developed for that purpose (plastic food wrap or a food­grade 1­ gallon plastic bag may also be used). Avoid hyperthermia, which may precipitate apnea and worsen hypoxic­ischemic injury in depressed infants.
RESUSCITATION

Newborn resuscitation almost exclusively involves care of primary respiratory compromise (Table 108­2). Consensus guidelines recommend a timed sequence of steps (30, , and >60 seconds). Most important is the rapid establishment of effective ventilation and determining the heart rate before
,5 initiating CPR.
TABLE 108­2
Steps in Neonatal Resuscitation
Newborn Appearance Management Comments
Infant breathing, crying, good Routine care: warm, dry, delay cord clamping 1–3 min, observe Vigorous term babies may be warmed skin­to­skin tone with mother.
Stimulate nonvigorous babies after drying by
Poor tone/respiratory effort or Warm, open airway and clear nose and mouth (only if rubbing back vigorously several times.
respiratory distress obstructed), dry, stimulate
Labored breathing or persistent Clear the nose and mouth, monitor O saturation; provide O Oxygen monitor should be placed on right upper
  cyanosis with HR >100 beats/min extremity (preductal).
only to maintain levels in Table 108­3. Consider CPAP.
Apnea, gasping, or HR <100 PPV Provide PPV with bag­mask ventilation at a rate of beats/min Continue PPV for  s, taking corrective steps for ventilation if 40–60 breaths/min using room air.
no improvement in HR Provide  cm H O pressure for term infants and

20–25 cm H O pressure for preterm infants.

HR <60 beats/min Initiate CPR: 3:1 compression­to­ventilation ratio 90:30 Use thumb­encircling technique to provide chest compressions and ventilations per minute compressions to lower one third of sternum.
Consider intubation prior to chest compressions.
HR <60 beats/min after Administer epinephrine May be given IO, IV, or through a UV or ETT.
appropriate ventilation and CPR Consider volume expansion if blood loss; treat hypoglycemia
Abbreviations: CPAP = continuous positive airway pressure; ETT = endotracheal tube; HR = heart rate; O = oxygen; PPV = positive­pressure ventilation; UV =
 umbilical vein.
INITIAL STEPS (FIRST  SECONDS)

Within the first  seconds of birth, provide warmth, and dry and stimulate the baby. Current guidelines no longer advise the routine suctioning of the newborn nose and mouth. Infants who are spontaneously breathing, whether delivered through clear or meconium­stained amniotic fluid, do not require tracheal suctioning because tracheal suctioning can cause reflex bradycardia and apnea. If the infant is not breathing initially, dry and provide stimulation by rubbing the back two to three times; if there is no response, open the airway using jaw thrust and towels beneath the shoulders to provide a sniffing position. If there appears to be obstruction from amniotic fluid, gently suction the nose and throat with a bulb or 8F catheter.
After these initial steps, assess the respiratory effort and heart rate.
ONGOING RESUSCITATION (30 TO  SECONDS)
After warming, drying, and stimulating, reassess the respiratory effort and the heart rate. If the infant begins breathing without significant effort and with good color, return to the mother for routine care. If the heart rate is >100 beats/min but there is persistent cyanosis or labored breathing, open the airway and suction the nose and mouth if there is a visible obstruction; attach pulse oximetry to the right hand or wrist (preductal) and apply supplemental oxygen to achieve targeted preductal oxygen saturation goals as per Table 108­3. TABLE 108­3
Targeted Pulse Oxygen Levels During Newborn Resuscitation
Time After Birth Target Oxygen Saturation (preductal)
 min 60%–65%
 min 65%–70%
 min 70%–75%
 min 75%–80%
 min 80%–85%
 min 85%–90%
Apneic or depressed newborns delivered through meconium are at risk for meconium aspiration syndrome, but current evidence indicates that
 tracheal suctioning does not reduce morbidity or mortality. Naloxone is not recommended for treatment of neonatal respiratory depression, even
 after maternal opioid exposure or use, as naloxone may actually precipitate seizure activity in a newborn of an opiate­using mother. Provide usual respiratory support and ventilation.
Initiate positive­pressure ventilation using a bag and mask for infants with a heart rate of <100 beats/min or who are gasping or remain apneic after the initial steps of newborn resuscitation. Begin resuscitation using room air because newborn blood oxygen levels,
 even in healthy newborns, take time to reach extrauterine values and excessive oxygenation is associated with increased mortality. Table 108­3 provides subsequent oxygen saturation goals throughout neonatal resuscitation.
POSITIVE­PRESSURE VENTILATION
Provide positive­pressure ventilation with a self­inflating or flow­inflating infant bag or a T­piece resuscitator for all newborns with a heart rate <100 beats/min or who are gasping or apneic after  seconds. Bradycardia, even extreme, is typically the result of respiratory failure, and chest compressions or medications should not be initiated until effective ventilations have been provided. Administer positive­pressure ventilation if available. Use a manometer to monitor peak inspiratory pressures: a peak inspiratory pressure of  cm H O is usually sufficient, although initial peak
 inspiratory pressures as high as  cm H O may be required. Generally, T­pieces and flow­inflating bags are preferred, because they allow better
 control of inflation pressures. Self­inflating bags are superior if supplemental air or oxygen is unavailable; however, these cannot provide continuous positive airway pressure alone. Be careful when using a self­inflating bag, because pop­off valve pressures, usually set at  to  cm H O, can be
 exceeded if excessive pressure is applied. T­piece resuscitators have the advantage of delivering a consistent pressure with each artificial breath.
Excessive inflation pressures can cause pneumothorax and compromise resuscitation. Provide40 to  breaths/min. Good chest rise and an increase in heart rate (usually within  to  breaths) are the best indicators of effective ventilation.
Most infants will respond to initial positive­pressure ventilation as outlined above. The most likely reason for a poor response to positive­pressure ventilation is inadequate positive­pressure ventilation, and corrective steps should be taken to ensure effective ventilation prior to further resuscitation measures. The American Heart Association recommends use of the mnemonic “MR SOPA,” which stands for Mask (adjust to improve the seal), Reposition the head to open the airway, Suction the mouth then nose, Open the mouth with a jaw thrust, and increase the Pressure until chest rise is noted (maximum peak inspiratory pressure,  cm H O), and if none of these is effective, proceed to definitive Airway control (endotracheal
 intubation). Infants with significant labored breathing may benefit from continuous positive airway pressure ventilation.
ENDOTRACHEAL INTUBATION
In the absence of improvement with bag­mask ventilation, endotracheal tube insertion and ventilation are indicated. Other potential indications for endotracheal intubation in the newborn include (1) concomitant need for chest compressions, (2) administration of endotracheal medications, and (3)
 known or suspected congenital diaphragmatic hernia (to avoid inflating stomach/bowel situated in the chest).
The technique and equipment for endotracheal intubation are discussed in detail in Chapter 113, “Intubation and Ventilation in Infants and Children.”
ADVANCED RESUSCITATION: CIRCULATION (>60 TO  SECONDS)
If, despite adequate assisted ventilation for  seconds, the newborn remains severely bradycardic with a heart rate <60 beats/min, start chest compressions. Deliver chest compressions to the lower one third of the sternum to a depth of about one third of the anteroposterior diameter of the chest. The compression phase should be slightly shorter than the relaxation phase to allow for cardiac filling. Avoid simultaneous compressions and ventilation. Deliver chest compressions and ventilations in a ratio of three chest compressions to one breath for a total of
 compressions and  breaths/min.

There are two techniques to perform chest compressions. In the “two­thumb” technique, the chest is compressed with both thumbs with the fingers encircling the newborn’s back. In the “two­finger” technique, the operator’s second and third digits compress the lower one third of the sternum, often with the other hand supporting the newborn’s back. The two­thumb technique seems to be superior in generating greater peak systolic pressures. The two­finger technique may be more practical if a colleague is simultaneously attempting umbilical vessel catheterization.
Stop chest compressions when the heart rate exceeds  beats/min. Once chest compressions have been discontinued, increase the ventilation rate to  to  breaths/min, because interference from the chest compressions is no longer an issue. Slowly wean positive­pressure ventilation when the heart rate exceeds 100 beats/min and the newborn has begun to breathe spontaneously.
Medications and Volume Expansion
If bradycardia continues despite bag­mask ventilation followed by endotracheal intubation, adequate ventilation with 100% oxygen, and chest compressions for  to  seconds, then give epinephrine. Epinephrine is the primary drug used for neonatal resuscitation and should be administered IV or IO, although it can be given via the intratracheal route (use larger dose below) if vascular access cannot be obtained (see “Vascular Access” below for umbilical venous catheter placement). The dose of epinephrine is .01 to .03 milligram/kg IV/IO (0.1 to .3 mL/kg of 1:10,000 solution). Intratracheal dosing is .05 to .1 milligram/kg or .5 to  mL/kg of 1:10,000 solution. Naloxone and sodium bicarbonate are no longer recommended for routine use in neonatal resuscitation. Naloxone is contraindicated in the newborn when maternal narcotic addiction is suspected, because neonatal seizures may result. Sodium
,9 bicarbonate may worsen intracellular acidosis.
Consider volume expansion when there is known or suspected blood loss (pallor, poor perfusion, or weak pulses). Administer  mL/kg of .9% saline solution (normal saline) or O­negative blood. Volume should be given slowly (3 to  minutes), especially to premature infants who are at risk for intraventricular hemorrhage.
Hypoglycemia in neonates is associated with adverse outcomes following birth asphyxia, whereas hyperglycemia is not. The diagnosis and treatment of hypoglycemia are discussed in detail in Chapter 146, “Metabolic Emergencies in Infants and Children.”
Postresuscitation Care
Newborns with any degree of asphyxia, even those who respond to resuscitative efforts, require a period of close observation. Transfer or admission to a special care nursery or neonatal intensive care unit will depend on the degree of resuscitation required.
Several large trials have demonstrated significant decrease in mortality and improved 18­month neurologic outcomes among term (≥36 weeks of
,10­12 gestational age) newborns with moderate to severe hypoxic­ischemic encephalopathy treated with hypothermia. Consider inducing hypothermia
 at .5°C (92.3°F) for term (36 weeks or greater) neonates requiring extensive resuscitative care, and obtain emergency neonatologist consultation whenever possible. If cooling therapy is being considered, turn off the warmer to immediately initiate passive cooling and monitor temperature continuously.
VASCULAR ACCESS
Peripheral venous access is often difficult in the newborn, so IO access is a good alternative. The most readily available site for venous access in the newborn is the umbilical vein. Vascular access techniques, including both IO and umbilical vein cannulation, are discussed in detail in Chapter 114,
“Vascular Access in Infants and Children.”
WITHHOLDING AND DISCONTINUING NEONATAL RESUSCITATION
The ED is typically the site of precipitous, unplanned deliveries. It is difficult to identify with precision the week of gestation based exclusively on the anatomic features of the fetus. If there is uncertainty about gestational age, infant weight, or viability, it is best to err on the side of resuscitation and call for consultation.
A fetus at <22 weeks of gestation and weighing <400 grams is not viable. At  weeks of gestation, survival ranges from about 10%
,15 to 50%; at  weeks of gestation, survival is about 35% to 60%; and at  weeks of gestation, survival is about 60% to 80%. Begin resuscitation on newborns ≥22 weeks of gestation.
DISCONTINUING NEONATAL RESUSCITATION
Newborns with no sign of life after  minutes of continuous and active resuscitation are virtually certain to suffer severe morbidity and/or mortality if continued resuscitation is successful in restoring vital signs. Therefore, it is justified to cease resuscitative efforts after  minutes and,
 certainly, after  minutes of asystole.
SPECIAL PROBLEMS IN THE NEWBORN
NEONATAL CYANOSIS
Cyanosis is a common finding in the newborn. The first step is differentiating central cyanosis from peripheral cyanosis.
Peripheral cyanosis, or acrocyanosis, is a normal finding in the first few days of life secondary to vasomotor instability and requires no specific evaluation or intervention. Central cyanosis is cyanosis involving the mucous membranes/lips, tongue, and skin. It indicates the presence of at least  to  grams/dL of unsaturated hemoglobin. The very anemic newborn may present as pale but not cyanotic if the level of unsaturated hemoglobin is below the  to  grams/dL threshold.
The breathing pattern often provides valuable clues to the cause of cyanosis (Table 108­4). On auscultation, unilaterally decreased breath sounds with retractions are associated with a pneumothorax or a space­occupying lesion of the chest. Bilaterally decreased breath sounds with retractions may suggest upper airway obstruction. Stridor also suggests an upper airway etiology. Rales and rhonchi may be heard with pneumonia, respiratory distress syndrome, or meconium aspiration syndrome. A thorough knowledge of the differential diagnosis for cyanosis allows for quick, organized assessment, diagnosis, and treatment.
TABLE 108­4
Causes of Neonatal Central Cyanosis
Airway Obstruction Cardiac Disorders Pulmonary Disorders (tachypnea* CNS and Metabolic Disorders
(retractions and/or grunting (tachypnea*, no with grunting and/or retractions; (slow, shallow respirations respirations; stridor) grunting or retractions) rales or rhonchi) without retractions)
Choanal atresia Transposition of great Respiratory distress syndrome Intracranial hemorrhage arteries
Laryngeal web/cyst Tricuspid atresia Meconium aspiration syndrome Brain anomalies (Dandy­Walker malformation, congenital hydrocephalus)
Tracheal stenosis Truncus arteriosus Pneumonia Central hypoventilation syndrome
Pierre Robin sequence Total anomalous Congenital diaphragmatic hernia Polycythemia pulmonary venous return
Cystic hygroma/goiter Pulmonary atresia Pulmonary hypoplasia Hypoglycemia
Coarctation of aorta Congenital lobar emphysema Sepsis/shock
Hypoplastic left heart Congenital cystic adenomatoid Methemoglobinemia syndrome malformation
Primary pulmonary hypertension of the newborn
*Tachypnea defined as >60 breaths/min.
Obtain simultaneous preductal (e.g., right radial) and postductal (e.g., lower extremity) or arterial blood gases to help diagnose persistent pulmonary hypertension of the newborn: the postductal PaO is significantly lower than the preductal PaO . Using pre­ and postductal pulse oximetry may serve
  the same purpose.
A discrepancy between upper and lower limb blood pressures or reduced femoral pulses may suggest coarctation of the aorta. Babies with coarctation of the aorta often develop new­onset tachypnea and absent femoral pulses later in the first day of life or into the second day of life. Femoral pulses are palpable at birth but disappear after the ductus arteriosus has closed with coarctation of the aorta.
Patients with hypoplastic left heart syndrome may present with poor pulses in all four limbs, poor perfusion, and tachypnea after the immediate newborn period once the ductus arteriosus has closed (see Chapter 129, “Congenital and Acquired Pediatric Heart Disease”).
Stepped evaluation and treatment are described in Table 108­5. TABLE 108­5
Steps to Evaluate and Treat Neonatal Central Cyanosis
Identify breathing pattern to characterize infant into airway obstruction, cardiac pulmonary, or CNS/metabolic pattern.
Obtain peripheral oxygen saturation pre­ and postductal, check pulses in all  extremities, and obtain ABG.
Perform hyperoxia test. Deliver 100% oxygen for 5–10 min. Congenital cyanotic heart disease cannot increase oxygen saturation >20% or raise PaO to

100 mm Hg.
Obtain stat chest radiograph to identify pneumothorax, congenital diaphragmatic hernia, or pulmonary infiltrates, and assess cardiac size and shape and pulmonary vasculature for clues to congenital heart disease.
Establish vascular access in umbilical or peripheral vein, obtain POC glucose, CBC, and metabolic panel. Treat hypoglycemia (glucose <40 milligrams/dL [2.22 mmol/L]) with 10% dextrose in water,  mL/kg IV bolus, or .3 mL/kg/h.
Institute continuous positive airway pressure or intubate and ventilate if oxygen saturation does not improve with standard methods for oxygen delivery.
If oxygenation still does not improve, treat as presumptive congenital cardiac disease with prostaglandin E starting at .05 microgram/kg/min and
 titrate to the minimum effective dose.
Abbreviations: ABG = arterial blood gas; POC = point of care.
Evaluation
The hyperoxia test is a quick method to help differentiate a cardiac from a noncardiac cause for cyanosis. Place the newborn in a 100% hood for  minutes. Cyanotic newborns with a pulmonary disorder can increase their PaO to >100 mm Hg (or oxygen saturation >20% as a proxy). Those with a
 fixed shunt secondary to congenital cyanotic heart disease or the right­to­left shunting of persistent pulmonary hypertension of the newborn cannot do so.
Obtain a chest radiograph to identify pulmonary disease, abnormalities of pulmonary blood flow, and abnormalities of heart size and shape. If physical examination and chest radiograph have not pointed to a particular diagnosis, an echocardiogram will be needed later on. An echocardiogram is not necessary in the ED during the initial resuscitation.
Treatment
Although oxygen therapy is the mainstay of treatment for cyanosis, treat the underlying cause. Provide positive­pressure ventilation
(continuous positive airway pressure or endotracheal intubation and mechanical ventilation) to the cyanotic newborn with significant respiratory symptoms. Monitor blood gas and pulse oximetry. Establish vascular access and initiate 10% dextrose in water at .3 mL/kg/h (80 mL/kg/24 h) if in the first  hours of life. Check serum glucose every  to  minutes until stable. Administer empiric antibiotics for sepsis while obtaining appropriate labs
(CBC with differential count and platelets, blood culture, chest radiograph, and, possibly, urine culture and C­reactive protein).
If, after initial examination and testing, cyanotic heart disease cannot be ruled out, begin an infusion of prostaglandin E starting at .05
 microgram/kg/min, and titrate to the lowest effective dose to maintain ductal patency.
PNEUMOTHORAX
Pulmonary air leaks are seen more commonly in newborns with respiratory distress syndrome, meconium aspiration syndrome, pneumonia, pulmonary hypoplasia, and congenital diaphragmatic hernia. Pneumothoraces may occur in the otherwise normal newborn in the first few minutes after birth due to increased intrathoracic pressure created with the onset of respiration in the fluid­filled newborn lungs. Air can also dissect into the pulmonary interstitium, mediastinum, pericardium, peritoneum, and subcutaneous space. Pneumothoraces may also be iatrogenic secondary to overexuberant bagging during resuscitation, especially with already compromised lungs. Unfortunately, the disorders that most commonly lead to pneumothoraces are also associated with respiratory distress and cyanosis, which may delay the suspicion and diagnosis of the pneumothorax.
Clinical Features and Diagnosis
Tension pneumothorax requires rapid treatment to avoid severe respiratory compromise, cardiovascular collapse from impaired venous return to the heart, and, possibly, death. In the preterm newborn, tension pneumothoraces are also highly associated with subsequent intracranial hemorrhage, presumably secondary to venous backup into the cerebral circulation.
Tachycardia, tachypnea, and retractions are noted. On auscultation, breath sounds are decreased on the side of the pneumothorax. If there is a tension pneumothorax, heart sounds and point of maximum impulse may be displaced in the direction away from the pneumothorax.
Transillumination of the chest with a bright light is another method to help rapidly establish pneumothorax, by “lighting up” the pleural air. Bedside
US can also potentially identify pneumothorax. Chest radiograph will confirm the diagnosis.
Treatment
The management of a pneumothorax depends on pneumothorax size and the tension it creates in the pulmonary space. A nontension pneumothorax can be observed without evacuation. In a term or near­term newborn, the nitrogen washout technique, placing the baby in a 100% oxygen hood for  to
 hours, may accelerate clearance of the air leak. This technique is contraindicated in preterm newborns due to concerns of oxygen toxicity to the lungs and retinas.
Emergency evacuation of a tension pneumothorax may be performed with an 18­ or 20­gauge 1­inch percutaneous catheter. Instill local anesthetic at the insertion site before the procedure if the patient is not in extremis. After elevating the neonate’s affected side with towels under the back, insert the catheter into the fourth intercostal space at the anterior axillary line, which should correlate with the nipple line. Once the pleural space is penetrated, withdraw the needle, and attach the catheter to a three­way stopcock connected to a 10­ or 20­mL syringe. Open the stopcock to the syringe, and aspirate the pleural air. More than one syringe of air may be evacuated if a large pneumothorax is present. Clinical improvement should occur after removal of the pleural air. A 10F or 12F chest tube or an .5F pigtail catheter can then be placed.
CONGENITAL DIAPHRAGMATIC HERNIA
Congenital diaphragmatic hernias are frequently diagnosed prenatally with US, which expedites proper initial newborn resuscitation.
Anatomically, congenital diaphragmatic hernia is a diaphragmatic defect, either posterolaterally through the foramen of Bochdalek or, less commonly,
16­19 through the retrosternal foramen of Morgagni. Most are left­sided. The diaphragmatic defect allows intra­abdominal contents, including stomach, bowel, and, occasionally, liver, to enter the chest during the second trimester of gestation, leading to pulmonary hypoplasia.
The lung ipsilateral to the diaphragmatic defect is hypoplastic, although the degree of hypoplasia may vary. Ultimate morbidity and mortality are determined both by the extent of hypoplasia of the contralateral lung secondary to compression from the abdominal contents in the thoracic space
  and whether or not the liver is located in the thorax and associated anomalies. Total lung volumes >45% of normal are predictive of survival.
Significant associated malformations, especially cardiac defects, are seen in 25% to 50% of patients with congenital diaphragmatic hernia.
Clinical Features
The clinical hallmark is persistent respiratory distress at birth, often with a characteristic “seesaw” side­to­side respiratory pattern due to the severely hypoplastic ipsilateral lung. A halting, gasping type of respiratory pattern along with persistent cyanosis is frequently noted. The abdomen appears scaphoid, because abdominal contents are partially situated in the thoracic space. Auscultation of bowel sounds in the chest strongly suggests the presence of congenital diaphragmatic hernia. Radiographic examination is confirmatory.
Treatment
Rapid endotracheal intubation is the treatment of choice for respiratory distress. Bag­mask ventilation will inflate the GI contents in the chest and will further compromise ventilation. Endotracheal intubation followed by ventilation with a rate of  to  breaths/min and lowest peak inspiratory pressures that allow for normal chest rise will help avoid pneumothoraces due to barotrauma to the hypoplastic lungs. Gentle hyperventilation to a P between  and  mm Hg may help lower pulmonary vasculature resistance and allow for an easier stabilization phase
CO
 before surgical correction of the diaphragmatic defect. Place a large­bore (10F) orogastric tube set to low continuous suction to minimize further lung compression from overaerated GI contents.
Obtain chest and abdominal radiographs and blood gas analysis to confirm the initial diagnosis and guide stabilization and management. After initial stabilization, emergent referral to a pediatric specialty center is essential.
GASTROSCHISIS AND OMPHALOCELE
A gastroschisis is a defect located to the right of the umbilicus from which uncovered intestine is extruded. An omphalocele is a large, centrally located defect of the abdominal wall containing stomach, intestine, and, frequently, liver that is covered by the mesentery. The umbilical cord inserts directly into the omphalocele sac. Rarely, an omphalocele may be ruptured either before delivery or during delivery. Associated anomalies are seen in 10% to
20­22
21% of patients with gastroschisis and 40% to 75% of patients with omphalocele. Associated defects include cardiac defects (such as tetralogy of
Fallot), syndromes (Beckwith­Wiedemann), and chromosomal abnormalities (trisomy  and trisomy 18), in addition to associated intestinal atresias.
Treatment
The initial management of gastroschisis and omphalocele is similar: handle the covered sac and free intestine with care. Place the newborn on a radiant warmer to help prevent hypothermia due to increased heat loss from the exposed abdominal contents. The ABCs of stabilization should be performed as needed.
If an omphalocele is present, note its size and contents. Cover the sac with warmed saline gauze wrapped gently around the baby with Kerlix, and then place an additional cover with plastic wrap to help minimize evaporative losses. Start IV 10% dextrose in water at .5 times maintenance (i.e.,  to  mL/kg/h or 120 to 150 mL/kg/24 h) to compensate for the additional insensible water loss. Monitor urine output and electrolytes closely to determine ongoing fluid needs.
If a gastroschisis is present, immediately check for dusky or cyanotic intestine, which indicates reduced flow to the affected bowel due to torsion and vascular occlusion. Gently rotate the bowel to relieve torsion if necessary to prevent bowel infarction. Emergency pediatric surgical consultation is essential. If the intestine appears pink, cover with warmed saline gauze, wrap with Kerlix, and further cover with sterile plastic wrap. Be careful not to compress the intestine, which could result in obstruction of blood flow to the bowel. Insensible water loss is much greater in the newborn with gastroschisis due to the open defect with large amounts of extruded bowel. Therefore, IV 10% dextrose in water should be started at  to  mL/kg/h (150 mL/kg/24 h).
Check glucose periodically. Antibiotics, usually ampicillin,  to 100 milligrams/kg IV, and gentamicin,  to  milligrams/kg IV, should be given.
Immediate consultation with a neonatologist and pediatric surgeon is necessary. The overall outcome for gastroschisis is quite good, with survival
,24  exceeding 90%. Survival with omphalocele is somewhat less at 73% to 88%, depending largely on the presence of associated anomalies.
TRACHEOESOPHAGEAL FISTULA
Tracheoesophageal fistula develops secondary to a failure of separation of the developing foregut structures, the trachea and esophagus, during the embryologic stage of development. There are five types of tracheoesophageal fistula: (1) esophageal atresia with a distal tracheoesophageal fistula
(88% of cases), (2) isolated esophageal atresia without tracheoesophageal fistula (7%), (3) esophageal atresia with proximal tracheoesophageal fistula
(1%), (4) esophageal atresia with proximal and distal tracheoesophageal fistulas (1%), and (5) H­type fistula without esophageal atresia (3%).
Tracheoesophageal fistula is highly associated with several other malformations, designated as the acronyms VATER or VACTERL association: vertebral anomalies, anal atresia, cardiac anomalies, tracheoesophageal fistula, radial anomaly/renal anomalies, and limb anomalies.
Diagnosis
The diagnosis of tracheoesophageal fistula can be missed during prenatal US examination. When esophageal atresia is present, polyhydramnios is usually noted before or at delivery. Newborns with tracheoesophageal fistula/esophageal atresia will usually have excessive oral secretions noted shortly after birth. When attempting to pass a nasogastric tube, the tube coils in the esophageal pouch and often comes back out of the mouth. No air passage will be heard when a 5­mL air bolus is injected into the nasogastric tube. A chest radiograph with a nasogastric tube in place will demonstrate the esophageal pouch. Confirmatory contrast studies are not indicated and may actually be contraindicated because the esophageal contents can be aspirated into the lungs.
Treatment
Management of tracheoesophageal fistula includes placing the child in head­up (reverse Trendelenburg) positioning to help prevent passage of gastric contents through the tracheoesophageal fistula into the lungs, placing the nasogastric tube into the esophageal pouch on low intermittent suction to prevent buildup and possible aspiration of oral secretions, and giving the newborn nothing by mouth. Initially, standard 10% dextrose in water IV fluids are best. Immediate referral to a center with neonatologists and pediatric surgeons is essential.


