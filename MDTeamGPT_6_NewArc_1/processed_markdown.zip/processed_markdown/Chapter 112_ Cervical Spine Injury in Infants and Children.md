## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 112: Cervical Spine Injury in Infants and Children
Julie C. Leonard
INTRODUCTION AND EPIDEMIOLOGY
,2
Cervical spine injuries occur in approximately .8% of pediatric blunt trauma patients. Although the incidence of cervical spine injuries in children is
3­6 lower than adults (2.4%), children have higher rates of mortality (7.4%) compared to adults (1.2%). In children <8 years old, nearly three fourths of all
  spinal injuries occur in the cervical spine, and three fourths of the cervical spine injuries involve the axial cervical spine (occiput through C2). Cervical
,8 spine injuries in these younger children are more likely associated with neurologic deficits and head or other major organ injury. In addition, spinal cord injury without radiographic abnormality (SCIWORA) may occur in children and typically involves the cervical spine. The incidence of
,9­11
SCIWORA among pediatric trauma patients ranges from .15% to .2%, comprising .5% to 35% of pediatric spine injuries. Motor vehicle crashes
 are the most common mechanism of cervical spine injuries, followed by falls, and in teenagers, diving and sports injuries. Boys are affected more often than girls. Child abuse can result in cervical spine injuries in younger patients via a shaking mechanism, although this is a rare manifestation of
 inflicted injury. Note that injuries to the spine and spinal cord outside of the cervical spine are discussed in Chapter 110, “Pediatric Trauma.”
PATHOPHYSIOLOGY
A number of anatomic differences between the pediatric and adult cervical spine predispose children to different patterns of injury (Table 112­1). In particular, the larger head­to­body ratio in young children creates a fulcrum at C2–C3 (compared to C5–C6 in adults) that accounts for higher rates of cervical spine injury above C3 in children. Weaker muscles and ligaments combined with anterior wedging and shallow facets connecting cervical vertebrae and immature growth centers together allow for easier anterior­posterior slipping of the vertebrae than in adults.
TABLE 112­1
Anatomic Considerations in the Pediatric Cervical Spine
Large head
Ligamentous laxity
Absent cervical lordosis
Weak neck muscles
Anterior wedging of vertebrae
Shallow and horizontal vertebral facets
Ossification centers and synchondroses
Patients younger than  years of age incur high ligamentous injuries more often than older children and adults. Fractures tend to occur at the weak points in the bones—synchondroses and ossification centers. Dens fractures occur most commonly along the synchondrosis, especially in children younger than age  years. The mechanism of injury is usually a forward­facing child in a high­speed motor vehicle crash with rapid forward flexion.
Atlanto­occipital and atlantoaxial dislocation injuries are devastating vertical distraction injuries that occur in the very young child, most commonly from a motor vehicle crash, and usually result in rapid death (Figure 112­1).
FIGURE 112­1. Atlantoaxial dislocation in a 6­year­old boy involved in a motor vehicle crash. A. Lateral plain radiograph reveals atlantoaxial dislocation (blue arrow).

BC.h MapRtIe or f1 t1h2e :s Camerev ipcaatl iSenptin reev Ienajulsr ya inne Ianrf­acnotms apnledt eC thraildnrseenc,t iJounl ioef Cth. eL beoranianrsdtem at the level of the distal medulla, extensive ligamentous injPurayg we i1t h/ 
. Terms of Use * Privacy Policy * Notice * Accessibility resulting atlantoaxial dissociation, extensive intrathecal hematoma and hemorrhage, C1–C2 interspinous ligament tear, and prevertebral soft tissue swelling and edema around the nuchal ligament (blue arrows).
SPINAL MOTION RESTRICTION IN INFANTS AND CHILDREN
When cervical spine injury is suspected, measures to restrict the motion of the cervical spine can be challenging. Spinal motion restriction may be difficult in young children who are frightened or agitated, and placement of a cervical collar in young children while on a flat surface (e.g., rigid long board) may cause unwanted flexion of the cervical spine. A number of untoward effects have been associated with the use of a rigid long backboard including development of decubitus ulcers, flexion of the neck, and impedance of chest wall motion causing respiratory compromise, worsening of atlanto­occipital distraction injury, increased intracranial pressure, and musculoskeletal pain that may mimic injury and lead to increased radiologic
13­25 investigation.
For those at significant risk for cervical spine injury, neutral positioning of the neck is important; for those in the supine position, consider elevating the torso .5 cm (or more for children <4 years of age) in order to alleviate neck flexion caused by the large occiput. Neutral position is achieved by aligning the external auditory meatus with the shoulders. Proper sizing of pediatric cervical collars is equally important and varies depending on the device used. If the proper­size collar is not available or if cervical collar placement initially results in extreme agitation of the child, use padding such as towel rolls or foam blocks placed on both sides of the child’s head to help limit motion.
Due to the risks associated with the rigid long board, use should be restricted to children with injuries that limit their ability to self­extricate in the
,27 prehospital setting (e.g., obtunded or unable to ambulate). If used, upon arrival to the hospital, children should be quickly moved from the rigid long board to a mattress gurney using the log roll maneuver or a slide board.
CLINICAL FEATURES
HISTORY
Ask parents, witnesses, or prehospital personnel about the mechanism of injury: children with cervical spine injury will usually have a history of highforce acceleration/deceleration (as seen in motor vehicle crashes) or axial loading trauma (falls, diving injuries). Trivial mechanisms such as a groundlevel fall usually do not lead to serious spine injury unless the patient has a condition associated with cervical spine instability (see “Special
Considerations” later in the chapter). In the cooperative, verbal child, ask about symptoms such as neck pain, difficulty moving the neck, sensory deficits, or weakness.
PHYSICAL EXAMINATION
Examine the child with a primary survey of airway, breathing, and circulation, followed by a complete head­to­toe examination to identify major comorbid injuries that increase the risk of cervical spine injury, particularly injuries to the head and thorax.
Pay careful attention to breathing, because damage to C3–C5 can injure the phrenic nerve, impairing innervation to the diaphragm, compromising respiratory mechanics, and leading to apnea. Injury to the high cervical spine can affect hemodynamic stability from spinal shock. Spinal shock is characterized by hypotension in the setting of a normal heart rate. For intubated or obtunded trauma patients, leave a cervical collar in place and obtain imaging.
In children who are cooperative and alert, assess for midline neck tenderness, the presence of torticollis, and neurologic deficits while maintaining inline stabilization of the neck. Sensory symptoms such as numbness or tingling are the most common neurologic deficits among pediatric cervical spine injury patients, and persistent sensory deficits may help localize the level of the injury.
Test for motor function in the cooperative child: shoulder shrug is controlled by C5, elbow flexion and wrist extension by C6, elbow extension and wrist flexion by C7, and finger flexion by C8. Also check deep tendon reflexes; the biceps reflex tests C5, the brachioradialis reflex tests C6, and the triceps reflex tests C7. DIAGNOSIS
Distinguishing between radiographically apparent cervical spine injury, SCIWORA, and peripheral nerve injury (brachial plexus) can be challenging.
Transient burning sensation of the hands and fingers is a concerning complaint described by young athletes with neck injuries, particularly football players. These symptoms can be caused by either neck hyperextension and central cord contusion or stretching or direct blow (supraclavicular fossa) to the brachial plexus. Patients with brachial plexus injuries will not report lower extremity symptoms or posterior midline neck complaints, and compression to the top of the head may reproduce the symptoms (Spurling test).
Torticollis and neck pain are presenting findings of cervical spine injury in children. It can be difficult to differentiate decreased movement from direct muscle injury versus muscle spasms due to cervical spine injury. A common cervical spine injury in young children is atlantoaxial rotatory
 subluxation. These injuries can result from very minor traumatic events and present with neck pain and torticollis that is characterized by the head being tilted in one direction and turned in the other (cock robin deformity). Atlantoaxial rotatory subluxation can also occur in the setting of positioning for head and neck surgery or spontaneously in the setting of upper respiratory infection (Grisel’s syndrome). In most circumstances, atlantoaxial rotatory subluxation is self­limiting with rest and the use of NSAIDs and muscle relaxants.
LABORATORY TESTING
Routine laboratory testing is not helpful in the general evaluation of cervical spine injury in children but may be useful in the context of multisystem trauma.
IMAGING
Imaging should follow the U.S. Nuclear Regulatory Commission guidelines for using the “as low as reasonably achievable” principle. In practice, this means both selecting the right imaging study using clinical criteria and ensuring that imaging protocols are adapted to lower dosing for children.
Choice of imaging should be guided by the history and physical examination.
Adult decision rules such as NEXUS (National Emergency X­Radiography Utilization Study) and the Canadian Cervical Spine Rule (see Tables 258­4 and
258­5) for cervical spine clearance may be useful in guiding imaging practice in older children and teens but have limitations. The Canadian rule did not include children in its derivation, and NEXUS did not include children <2 years old and included only four patients <9 years
,29­33 old. A prospective study applying NEXUS in children showed that NEXUS did in fact miss two fractures, both in children under  years of age,
 highlighting the difficulty of ruling out cervical spine injury in the very young patient. The Pediatric Emergency Care Applied Research Network conducted a multicenter retrospective case­control study of 540 children with cervical spine injuries matched to noninjured children who underwent cervical spine imaging. This study identified eight factors that were 98% sensitive and 26% specific for cervical spine injury after blunt trauma (Table

112­2). If these risk factors had been used to guide clinical decision making, radiographic testing would have been reduced by approximately 25%.
The pediatric cervical spine injury risk factors are currently undergoing prospective evaluation for use in a clinical decision tool.
TABLE 112­2
Risk Factors for Pediatric Cervical Spine Injury
Altered mental status
Focal neurologic examination
Neck pain
Torticollis
High­risk motor vehicle crash
Substantial torso injury
Predisposing condition associated with cervical spine injury
Diving

Suggested clinical algorithms have been published by the Trauma Association of Canada’s Pediatric Subcommittee and more recently by the
Pediatric Orthopedic Society of North America Cervical Spine Clearance Working Group (see Figure 112­4).
Plain Radiographs
For patients in whom a cervical spine injury is suspected, plain radiographs should be considered first. The sensitivity of plain radiographs for identifying fractures, dislocations, and subluxations in children varies across the literature, ranging from 74% to 98%, with sensitivity increasing with
37­44 the number of views taken. Combining the cross­table lateral and anterior­posterior views identifies 87% of significant cervical spine injury in
 children younger than  years of age. Consider the addition of an odontoid (open mouth) view in cooperative older children, although the added
 value in children younger than age  years has been questioned.
Interpreting pediatric cervical spine radiographs can be challenging as a result of the anatomic differences across the spectrum of age. The principles of evaluation are similar to adults: assess the anterior and posterior vertebral lines, the spinolaminal line, and the spinous processes for alignment; and carefully examine the soft tissue spaces for swelling that might indicate subtle fracture. Widening of the soft tissue space >7 mm in the retropharyngeal space and >14 mm in the retrotracheal space on lateral radiograph may be an indirect sign of cervical spine injury. In addition, assess the pediatric cervical spine for atlantoaxial instability. Useful measurements include Wackenheim’s clivus line (a line along the posterior edge of the clivus should intersect the odontoid) and the rule of thirds (the dens, cord, and empty space should each occupy one third of the spinal space).
Craniocervical dislocation is suggested by a C1–C2:C2–C3 ratio >2.5. Important differences between pediatric and adult cervical spine radiographs include:
. Normal cervical lordosis may be absent in children when imaged in the supine position and/or when a rigid collar is in place.
. The posterior arch of C1 fuses by age  years and the anterior arch by age  years.
. Anterior wedging of the vertebrae caused by secondary growth centers may be mistaken for compression fractures in children under  years old.
. Posterior laminar fusion lines may be mistaken for fractures in children under  years old.
. Children younger than  years old may demonstrate pseudosubluxation (up to 46%) on lateral radiograph, usually at the C2–C3 level (Figure 112­

2).
FIGURE 112­2. Pseudosubluxation of C2 on C3. [Reprinted with permission from Yamamoto LG: Cervical spine malalignment—true or pseudosubluxation? In:
Yamamoto LG, Inaba AS, DiMauro R (eds): Radiology Cases in Pediatric Emergency Medicine, Vol. , Case . Honolulu, HI: University of Hawaii John A.
Burns School of Medicine, Department of Pediatrics, 1994. http://www.hawaii.edu/medicine/pediatrics/pemxray/v1c05.html.]
Swischuk developed a method for distinguishing between true subluxation and pseudosubluxation: draw a line connecting the posterior cortex of the spinous process of C1 to the cortex of the spinous process of C3 (Figure 112­3). If this line is >2 mm anterior to the spinous process of C2, suspect cervical pathology, such as a hangman’s fracture. There is little role for flexion/extension plain radiographs in the ED for children. Obtain an MRI if ligamentous instability is suspected.
FIGURE 112­3. Posterior cervical line of Swischuk. [Reprinted with permission from Yamamoto L: Cervical spine malalignment—true or pseudosubluxation? In:
Yamamoto LG, Inaba AS, DiMauro R (eds): Radiology Cases in Pediatric Emergency Medicine, Vol. , Case . Honolulu, HI: University of Hawaii John A.
Burns School of Medicine, Department of Pediatrics, 1994. http://www.hawaii.edu/medicine/pediatrics/pemxray/v1c05.html.]
Although CT is the most cost­effective modality for imaging the cervical spine in adults, it is unclear if this is true for children, in whom radiation exposure is of particular concern. CT scanning exposes a child to  to  times the radiation of plain films, with an estimated 18­fold increase in
,47 thyroid malignancy in a theoretical model if all plain films are replaced by CT scans. Given the potential risks and unclear advantages of CT in children, this modality should be reserved for those with abnormal or suspicious plain radiographs and those with significant mechanism of injury who are obtunded or intubated and undergoing CT evaluation for other injuries. MRI is the modality of choice for the diagnosis and evaluation of
 children with focal neurologic deficits on exam or those who report persistent severe cervical spine pain with normal plain radiographs. Patients with normal MRI examinations and SCIWORA have very favorable prognoses; those with minor findings such as cord edema or a minor hemorrhage have
,49 good prognoses, whereas those with major hemorrhage or cord transections have poor prognoses for recovery. MRI should also be strongly considered as an adjunct test when evaluating for abusive head trauma in infants and young children, as emerging evidence supports a higher rate of cervical spine injury in this subpopulation. The injury patterns in these children are typically multilevel ligamentous injuries and intraspinal
50­58 hemorrhages.
TREATMENT
The ED management of the child with potential cervical spine injury should follow the principles of advanced trauma life support with primary attention to assessment and management of the airway and breathing (especially with a high cervical spine injury, which may compromise respiratory effort) and circulation (particularly in spinal shock). Spinal shock is not responsive to volume expansion and must be treated with vasopressors.
In adult cervical spine injury, steroids are no longer favored (see Chapter 258, “Spine Trauma”), and no large studies have examined the efficacy of steroids in pediatric spine injury, so steroids are not standard of care for children.
Definitive management of cervical spine injury is primarily surgical, through consultation with pediatric neurosurgery or orthopedics.
DISPOSITION AND FOLLOW­UP
Unstable patients and those with radiographic evidence of cervical spine injury require admission, usually to intensive care, and consultation with a
 spine surgeon. Compared to adults, children’s cervical spine injuries infrequently require surgery (15.7%) or traction or halo (16.9%). Due to the agerelated variation in cervical spine injury patterns and management, transferring these children to pediatric trauma centers for definitive care is strongly recommended.
Children with persistent neck pain despite normal neurologic exam and normal radiographs and/or CT need further evaluation. If the mechanism of injury is mild, the child may be discharged with an appropriately sized cervical collar and close outpatient medical follow­up. If the mechanism of injury is severe, it is prudent to obtain a spine consultation to determine further evaluation.
Children without neck pain or neurologic symptoms or deficits who have normal radiographs and those who have been cleared clinically should be discharged with instructions to return for symptoms of numbness, tingling, or weakness in the arms, hands, legs, or feet.
SPECIAL CONSIDERATIONS
Certain conditions predispose patients to cervical spine injury as a result of associated abnormalities causing cervical spine instability. These are listed in Table 112­3. Children with these conditions should be considered at high risk for cervical spine injury and undergo conservative/extensive evaluation.
TABLE 112­3
Predispositions to Cervical Spine Injury in Children
Genetic syndromes associated with spine malformations; examples:
Down syndrome: 15% atlantoaxial instability
Klippel­Feil syndrome: cervical vertebral defects
Morquio’s syndrome (type IV mucopolysaccharidosis): odontoid hypoplasia
Connective tissue disorders associated with ligamentous laxity; examples:
Marfan’s syndrome
Ehlers­Danlos syndrome
Spondyloarthopathies; examples:
Ankylosing spondylitis
Rheumatoid arthritis
Disorders of bone metabolism; examples:
Osteoporosis
Rickets
Previous cervical spine surgeries
CLINICAL ALGORITHMS FOR CERVICAL SPINE CLEARANCE
In 2011, the Trauma Association of Canada’s Pediatric Subcommittee National Pediatric Cervical Spine Evaluation Pathway released a consensus
 guideline for evaluation of the pediatric patient and divided its algorithms into two parts: the reliable patient and the unreliable patient. More recently, the Pediatric Orthopedic Society of North America Cervical Spine Clearance Working Group released a consensus algorithm based on
Glasgow Coma Scale score rather than age (Figure 112­4).
FIGURE 112­4. Algorithm for evaluation of the pediatric cervical spine (C­spine) in the pediatric patient. GCS = Glasgow Coma Scale. [Reproduced with permission from Herman MJ, Brown KO, Sponseller PD, et al: Pediatric Cervical Spine Clearance: a consensus statement and algorithm from the Pediatric Cervical
Spine Clearance Working Group. J Bone Joint Surg Am 2018; Jan ;101(1):e1. REFERENCES
. Ahmad FA, Schwartz H, Browne LR, et al: Methods for collecting paired observations from emergency medical services and emergency department providers for pediatric cervical spine injury risk factors. Acad Emerg Med 24: 432, 2017. [PubMed: 27976464]
. Viccellio P, Simon H, Pressman BD, et al: A prospective multicenter study of cervical spine injury in children. Pediatrics 108: E20, 2001. [PubMed: 11483830]
. Leonard JR, Jaffe DM, Kuppermann N, et al: Cervical spine injury patterns in children. Pediatrics 133: e1179, 2014. [PubMed: 24777222]
. Goldberg W, Mueller C, Panacek E, et al: Distribution and patterns of blunt traumatic cervical spine injury. Ann Emerg Med 38: , 2001. [PubMed: 11423806]
. Young AJ, Wolfe L, Tinkoff G, Duane TM: Assessing incidence and risk factors of cervical spine injury in blunt trauma patients using the National
Trauma Data Bank. Am Surg 81: 879, 2015. [PubMed: 26350665]
. Brown RL, Brunn MA, Garcia VF: Cervical spine injuries in children: a review of 103 patients treated consecutively at a level  pediatric trauma center.
J Pediatr Surg 36: 1107, 2001. [PubMed: 11479837]
. Mohseni S, Talving P, Branco BC, et al: Effect of age on cervical spine injury in pediatric population: a National Trauma Data Bank Review. J Pediatr
Surg 46: 1771, 2011. [PubMed: 21929988]
. Easter JS, Barkin R, Rosen C, Ban K: Cervical spine injuries in children, part I: mechanism of injury, clinical presentation, and imaging. J Emerg Med
41: 142, 2011. [PubMed: 20493655]
. Pang D: Spinal cord injury without radiographic abnormality in children,  decades later. Neurosurgery 55: 1325, 2004. [PubMed: 15574214]
. Polk­Williams A, Carr BG, Blinman TA, et al: Cervical spine injury in young children: a National Trauma Data Bank review. J Pediatr Surg 43: 1718,
2008. [PubMed: 18779013]
. Martin BW, Dykes E, Lecky FE: Patterns and risks in spinal trauma. Arch Dis Child 80: 860, 2004. [PubMed: 15321867]
. Katz JS, Oluigbo CO, Wilkinson CC, et al: Prevalence of cervical spine injury in infants with head trauma. J Neurosurg Pediatr 5: 470, 2010. [PubMed: 20433260]
. National Association of EMS Physicians and American College of Surgeons Committee on Trauma: EMS spinal precautions and the use of the long backboard. Prehosp Emerg Care 17: 392, 2013. [PubMed: 23458580]
. Nypaver M, Treloar D: Neutral cervical spine positioning in children. Ann Emerg Med 23: 208, 1994. [PubMed: 8304600]
. Curran C, Dietrich AM, Bowman MJ, Ginn­Pease ME, King DR, Kosnik E: Pediatric cervical­spine immobilization: achieving neutral position? J
Trauma 39: 729, 1995. [PubMed: 7473965]
. Lerner EB, Billittier AJ, Moscati R: Effects of neutral positioning with and without padding on spinal immobilization. Prehosp Emerg Care 2: 112,
1998. [PubMed: 9709329]
. Sheerin F, de Frein R: The occipital and sacral pressures experienced by healthy volunteers under spinal immobilization: a trial of three surfaces. J
Emerg Nurs 33: 447, 2007. [PubMed: 17884474]
. Ben­Galim P, Dreiangel N, Mattox KL, Reitman CA, Kalantar SB, Hipp JA: Extrication collars can result in abnormal separation between vertebrae in the presence of a dissociative injury. J Trauma 69: 447, 2010. [PubMed: 20093981]
. Kwan I, Bunn F, Roberts IG: Spinal immobilization for trauma patients. Cochrane Database Syst Rev 2: CD002803, 2001. [PubMed: 11406043]
. Davues G, Deakin C, Wilson A: The effect of a rigid collar on intracranial pressure. Injury 27: 647, 1996. [PubMed: 9039362]
. Schafermeyer RW, Ribbeck BM, Gaskins J, Thomason S, Harlan M, Attkisson A: Respiratory effects of spinal immobilization in children. Ann
Emerg Med 20: 1017, 1991. [PubMed: 1877767]
. Cross DA, Baskerville J: Comparison of perceived pain with different immobilization techniques. Prehosp Emerg Care 5: 270, 2001. [PubMed: 11446541]
. Leonard JC, Mao J, Jaffe DM: Potential adverse effects of spinal immobilization in children. Prehosp Emerg Care 16: 513, 2012. [PubMed: 22712615]
. March JA, Ausband SC, Brown LH: Changes in physical examination caused by use of spinal immobilization. Prehosp Emerg Care 6: 421, 2002. [PubMed: 12385610]
. Mannix R, Nigrovic LE, Schutzman SA, et al: Factors associated with the use of cervical spine computed tomography imaging in pediatric trauma patients. Acad Emerg Med 18: 905, 2011. [PubMed: 21854487]
. National Association of EMS Physicians and the American College of Surgeons Committee on Trauma: EMS spinal precautions and the use of the rigid long backboard. Prehosp Emerg Care 17: 392, 2013. [PubMed: 23458580]
. Fischer PE, Perina DG, Delbridge TR, et al: Spinal motion restriction in the trauma patient: a joint position statement. Prehosp Emerg Care 22: 659,
2018. [PubMed: 30091939]
. Powell EC, Leonard JR, Olsen CS, et al: Atlantoaxial rotatory subluxation in children. Pediatr Emerg Care 33: , 2017. [PubMed: 28141768]
. Stiell IG, Clement CM, McKnight RD, et al: The Canadian C­spine rule versus the NEXUS low­risk criteria in patients with trauma. N Engl J Med 349:
2510, 2003. [PubMed: 14695411]
. Stiell IG, Clement CM, Grimshaw J, et al: Implementation of the Canadian C­spine rule: prospective  centre cluster randomised trial. BMJ 339: b4146, 2009. [PubMed: 19875425]
. Stiell IG, Wells GA, Vandemheen KL, et al: The Canadian C­spine rule for radiography in alert and stable trauma patients. JAMA 286: 1841, 2001. [PubMed: 11597285]
. Hoffman JR, Mower WR, Wolfson AB, et al: Validity of a set of clinical criteria to rule out injury to the cervical spine in patients with blunt trauma.
National Emergency X­Radiography Utilization Study Group. N Engl J Med 343: , 2000. [PubMed: 1443841]
. Hoffman JR, Schriger DL, Mower W, et al: Low­risk criteria for cervical­spine radiography in blunt trauma: a prospective study. Ann Emerg Med 21:
1454, 1992. [PubMed: 1443841]
. Vicellio P, Simon H, Pressman BD, et al: A prospective multicenter study of cervical spine injury in children. Pediatrics 108: e20, 2001. [PubMed: 11483830]
. Leonard JC, Kuppermann N, Olsen C, et al: Factors associated with cervical spine injury in children after blunt trauma. Ann Emerg Med 58: 145,
2011. [PubMed: 21035905]
. Chung S, Mikrogianakis A, Wales PW, et al: Trauma Association of Canada Pediatric Subcommittee National Pediatric Cervical Spine Evaluation
Pathway: consensus guidelines. J Trauma 70: 873, 2011. [PubMed: 21610393]
. Nigrovic LE, Rogers AJ, Adelgais KM, et al: Utility of plain radiographs in detecting traumatic injuries of the cervical spine in children. Pediatr
Emerg Care 28: 426, 2012. [PubMed: 22531194]
. Garton HJ, Hammer MR: Detection of pediatric cervical spine injury. Neurosurgery 62: 700, 2008. [PubMed: 18301348]
. Dietrich AM, Ginn­Pease ME, Bartkowski HM, King DR: Pediatric cervical spine fractures: predominantly subtle presentation. J Pediatr Surg 26:
995, 1991. [PubMed: 1919996]
. Jaffe DM, Binns H, Radkowski MA, Barthel MJ, Engelhard HH 3rd: Developing a clinical algorithm for early management of cervical spine injury in pediatric trauma victims. Ann Emerg Med 16: 270, 1987. [PubMed: 3813160]
. Blahd WH Jr, Iserson KV, Bjelland JC: Efficacy of posttraumatic cross table lateral view of the cervical spine. J Emerg Med 2: 243, 1985. [PubMed: 4086761]
. Shaffer MA, Doris PE: Limitation of cross table lateral view in detecting cervical spine injuries: a retrospective analysis. Ann Emerg Med 10: 508,
1981. [PubMed: 7283214]
. Jacobs LM, Schwartz R: Prospective analysis of acute cervical spine injury: a methodology to predict injury. Ann Emerg Med 15: , 1986. [PubMed: 3942356]
. Buhs C, Cullen M, Klein M, Farmer D: The pediatric C­spine: is the “odontoid” view necessary? J Pediatr Surg 35: 994, 2000. [PubMed: 10873052]
. Cattell HS, Filtzer DL: Pseudosubluxation and other normal variants in the cervical spine in children. J Bone Joint Surg Am 47: 1295, 1965. [PubMed: 5837630]
. Jimenez RR, Deguzman MA, Shiran S, Karrellas A, Lorenzo RL: CT versus plain radiographs for evaluation of c­spine injury in young children: do benefits outweigh risks? Pediatr Radiol 38: 635, 2010. [PubMed: 18368400]
. Adelgais KM, Grossman DC, Langer SG, Mann FA: Use of helical computed tomography for imaging the pediatric cervical spine. Acad Emerg Med
11: 228, 2004. [PubMed: 15001401]
. Keiper MD, Zimmerman RA, Bilaniuk LT: MRI in the assessment of the supportive soft tissues of the cervical spine in acute trauma in children.
Neuroradiology 40: 359, 1998. [PubMed: 9689622]
. Mahajan P, Jaffe DM, Olsen CS, et al: Spinal cord injury without radiologic abnormality in children imaged with magnetic resonance imaging. J
Trauma Acute Care Surg 75: 843, 2013. [PubMed: 24158204]
. Jauregui JJ, Perfetti DC, Cautela FS, et al: Spine injuries in child abuse. J Pediatr Orthop 2016 [Epub ahead of print].
[PubMed: 27662382]
. Choudhary AK, Bradford RK, Dias MS, et al: Spinal subdural hemorrhage in abusive head trauma: a retrospective study. Radiology 262: 216, 2012. [PubMed: 22069156]
. Governale LS, Brink FW, Pluto CP, et al: A retrospective study of cervical spine MRI findings in children with abusive head trauma. Pediatr
Neurosurg 53: , 2018. [PubMed: 29084406]
. Jacob R, Cox M, Koral K, et al: MR imaging of the cervical spine in nonaccidental trauma: a tertiary institution experience. AJNR Am J Neuroradiol
37: 1944, 2016. [PubMed: 27231224]
. Kadom N, Khademian Z, Vezina G, et al: Usefulness of MRI detection of cervical spine and brain injuries in the evaluation of abusive head trauma.
Pediatr Radiol 44: 839, 2014. [PubMed: 24557483]
. Kemp A, Cowley L, Maguire S: Spinal injuries in abusive head trauma: patterns and recommendations. Pediatr Radiol 44(suppl 4): S604, 2014. [PubMed: 25501732]
. Kemp AM, Joshi AH, Mann M, et al: What are the clinical and radiological characteristics of spinal injuries from physical abuse: a systematic review.
Arch Dis Child 95: 355, 2010. [PubMed: 19946011]
. Knox J, Schneider J, Wimberly RL, et al: Characteristics of spinal injuries secondary to nonaccidental trauma. J Pediatr Orthop 34: 376, 2014. [PubMed: 24172665]
. Koumellis P, McConachie NS, Jaspan T: Spinal subdural haematomas in children with non­accidental head injury. Arch Dis Child 94: 216, 2009. [PubMed: 18713794]

