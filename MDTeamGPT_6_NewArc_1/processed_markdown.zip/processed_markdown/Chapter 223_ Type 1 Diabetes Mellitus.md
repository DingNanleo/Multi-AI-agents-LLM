## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 223: Type  Diabetes Mellitus
Nikhil Goyal; Adam Schlichting
INTRODUCTION AND EPIDEMIOLOGY
Diabetes can be classified into type  diabetes (T1DM), type  diabetes (T2DM), gestational diabetes, and other specific types of diabetes based on the etiology (Table 223­1); however, many people with diabetes do not easily fit into a single class.1 About 5% of people with diabetes are estimated to have T1DM, which is about .25 million American children and adults.2,3
TABLE 223­1
Etiologic Classification of Diabetes Mellitus
Type  diabetes (β­cell destruction, usually leading to absolute insulin deficiency)
Immune mediated
Idiopathic
Type  diabetes (may range from predominantly insulin resistance with relative insulin deficiency to a predominantly secretory defect with insulin resistance)
Other specific types, such as
Genetic defects of β­cell function
Genetic defects in insulin action
Diseases of the exocrine pancreas (pancreatitis, trauma, cystic fibrosis, etc.)
Endocrinopathies (Cushing’s syndrome, pheochromocytoma, hyperthyroidism, somatostatinoma, glucagonoma, etc.)
Drug­ or chemical­induced (interferon­α, β­adrenergic agonists, diazoxide, phenytoin, glucocorticoids, nicotinic acid, pentamidine, thiazides, thyroid hormone, pyrinuron, etc.)
Infections (congenital rubella, cytomegalovirus, etc.)
Uncommon forms of immune­mediated diabetes (anti­insulin receptor antibodies in conditions like lupus, etc.)
Other genetic syndromes sometimes associated with diabetes (Down’s syndrome, Klinefelter’s syndrome, Turner’s syndrome, etc.)
Gestational diabetes mellitus
PATHOPHYSIOLOGY
T1DM is characterized by an autoimmune, cellular­mediated destruction of β cells of the pancreas. These patients usually have almost no circulating insulin.1 It is mostly diagnosed in children and young adults, but it can also develop in adults.4 Spontaneous ketoacidosis almost always develops in untreated cases, and insulin is required for survival.
Chapter 224, “Type  Diabetes Mellitus,” discusses T2DM in detail. Hyperglycemia is present in all types of diabetes mellitus and is the main factor responsible for chronic complications.
Therefore, maintaining euglycemic control is the cornerstone of management.
DIAGNOSIS
The American Diabetes Association criteria for diagnosis are listed in Table 223­2.1 Any one of these can be used to make the diagnosis. Patients with a fasting plasma glucose of 100 to 125 milligrams/dL (5.6 to .0 mmol/L), a hemoglobin A1C of .7% to .4%, or a 2­hour plasma glucose of 140 to 199 milligrams/dL (7.8 to .0 mmol/L) as part of an oral glucose tolerance test are classified as having prediabetes.4 This should be viewed as an increased risk for diabetes and cardiovascular disease rather than a clinical diagnosis.
TABLE 223­2
American Diabetes Association Criteria for the Diagnosis of Diabetes
A1C ≥6.5%* The test should be performed in a laboratory using a method that is NGSP certified and standardized to the DCCT assay.
Or
Fasting plasma glucose ≥126 milligrams/dL (7.0 mmol/L)* Fasting is defined as no caloric intake for at least  h.
Or
Casual plasma glucose ≥200 milligrams/dL (11.1 mmol/L) and symptoms of hyperglycemia or Classic symptoms of hyperglycemia include polyuria and polydipsia.
Downhylopeargdlyecedm 2ic0 cr2is5is­7­1 6:37 P Your IP is 136.142.159.127
Chapter 223: Type  Diabetes Mellitus, Nikhil Goyal; Adam Schlichting 
. Terms of Use * Privacy Policy * Notice * Accessibility
2­h plasma glucose ≥200 milligrams/dL (11.1 mmol/L) during an oral glucose tolerance test OGTT must be performed as described by the World Health Organization.
(OGTT)* Abbreviations: A1C = glycated hemoglobin; DCCT = Diabetes Control and Complications Trial; NGSP = National Glycohemoglobin Standardization Project.
*Should be confirmed by repeat testing unless unequivocal hyperglycemia is present.
Glycated hemoglobin (hemoglobin A1C) represents the average blood glucose level over a 2­ to 3­month period.1 It is an indirect measure, and age, race/ethnicity, pregnancy, hemoglobinopathies, and recent transfusions may impact interpretation.4
In the ED, it is common to encounter isolated elevations of blood glucose with no established relationship to a meal. If patients have classic symptoms of hyperglycemia (polydipsia, polyuria) or are in hyperglycemic crisis, they may indeed be diagnosed with diabetes.
TREATMENT
T1DM is characterized by an absolute insulin deficiency, so some form of insulin is required for survival. Select patients with T1DM may also be treated with additional prandial injections of pramlintide, a synthetic form of the β­cell–produced hormone amylin.5 Patients with T1DM may also benefit from β­cell transplantation or pancreas transplantation. Other noninsulin agents are useful in T2DM and are discussed separately in Chapter 224. INSULIN
As of 2006, all U.S. Food and Drug Administration–approved insulin preparations are recombinant human insulin or an analog.6 These insulins are highly pure and stable, and vials in use can be kept up to  days at room temperature.7 The most common concentration of insulin is 100 units/mL (“U100”), but other concentrations including 200 units/mL (“U200”), 300 units/mL
(“U300”), and 500 units/mL (“U500”) are available, allowing a smaller volume to be injected. Although unmodified “regular” insulin was the first type of human­derived insulin used, many new insulin analogues have now become available (Table 223­3, Figure 223­1).8,9 Regardless of the insulin analog,  unit of insulin can be substituted for a longer­ or shorter­acting analog, as long as the total daily dose is equivalent (e.g., neutral protamine Hagedorn [NPH]  units twice daily can be converted to glargine  units daily).7 There can be considerable variability in the onset and duration of action depending on the dose (e.g., regular insulin has a longer duration of action with larger doses), site of injection, degree of exercise, and presence of circulating anti­insulin antibodies.
FIGURE 223­1. Insulins: onset, peak, and duration of action. NPH = neutral protamine Hagedorn; NPL = neutral protamine lispro.
TABLE 223­3
Commonly Used Insulin Preparations, Their Pharmacokinetics and Unique Features* Pharmacokinetics
Category of Insulin or
Name Unique Properties
Analogue Onset Peak End
(hours) (hours) (hours)
Rapid acting Insulin lispro (Humalog®) .1–0.25 .0–1.5  Fixed duration of action, regardless of dose
Insulin aspart (NovoLog®) .1–0.25 1–2 4–6 More stable than other rapid­acting insulins
Insulin glulisine (Apidra®) .1–0.25 .0–1.5 3–4 Antiapoptotic; may counteract β­cell destruction
Regular insulin Technosphere® (Afrezza®) .1–0.25 .9 .5–3 Inhaled insulin; contraindicated in chronic lung disease
Short acting Regular insulin (Humulin R®, Novolin R®) .25–1.0 2–4 6–8 —
Intermediate acting NPH (Humulin N®, Novolin N®) 2–4 6–7 10–20 Inexpensive
Insulin detemir (Levemir®) 1–3 3–9 6–24 Action is relatively constant with gentle peak
Long acting Insulin glargine (Lantus®, Toujeo®) .5 No peak 24+ Cannot be mixed with other insulins in same syringe
Insulin degludec (Tresiba®)  No peak >42 Allows variation in time of injection from day to day
Mixtures 70/30 Humulin®/Novolin® (70% NPH, 30% regular) .5–1.0 3–12 10–20 —
75/25 Humalog® (75% NPL, 25% lispro) .2–0.5 1–4 10–20 —
50/50 Humalog® (50% NPL, 50% lispro) .2–0.5 1–4 10–20 —
70/30 NovoLog Mix® (70% protamine aspart, 30% .2–0.5 1–4 10–20 — aspart)
70/30 Ryzodeg® (70% degludec, 30% aspart) .1–0.25 2–3 >24 —
Note: All brand names are copyrighted by their respective owners.
Abbreviations: NPH = neutral protamine Hagedorn (also called isophane insulin); NPL = neutral protamine lispro.
*Ultralente, Lente, and 50/50 insulin formulations are no longer available in the United States.
A physiologic regimen of insulin generally starts with half of the daily requirement given as basal insulin (once­daily long­acting or twice­daily intermediate­acting insulin) and prandial doses of rapid­acting insulin administered  to  minutes before each meal (Figure 223­2).8 Most patients with T1DM require a total daily dose of insulin between .4 and  unit/kg/d, with approximately half given as basal insulin such as insulin glargine and half to be given in divided doses preprandially.10,11 This can provide a rough idea when a patient says, “I have no idea how much insulin I take.”
FIGURE 223­2. Representation of basal and prandial insulin dosing.
Prandial dosing is most often based on the anticipated amount of carbohydrate about to be consumed, for example,  unit of insulin for each  grams of carbohydrate; this is known as “carb counting.” Prandial dosing must also take into consideration the premeal measured glucose level. In this case, the patient adds an additional amount of insulin to correct for premeal hyperglycemia or reduces the prandial dose to account for premeal hypoglycemia. Some patients may be on a simplified, fixed amount of insulin for each meal.
Insulin can be given as intermittent subcutaneous dosing, IV infusion, inhalation, or continuous subcutaneous infusion using an insulin pump. Intramuscular injection of insulin is not approved by the U.S. Food and Drug Administration. Intermittent insulin doses are given subcutaneously with a syringe or pen. The syringe method is the least expensive but requires care and precision to give the correct dose. Pens provide more accurate dosing, and many patients consider these to be more convenient. Subcutaneous injection is the most common method of insulin administration. Absorption varies due to regional circulatory differences, and frequent use of a single site may lead to fibrosis or lipodystrophy. Patients are instructed to limit injections to one region of the body but rotate sites within that region. IV administration of regular insulin results in an onset of action within  to  minutes and rapid reductions in plasma glucose, and is the recommended method of administration in hyperglycemic crises—diabetic ketoacidosis and hyperglycemic hyperosmolar nonketotic state. See Chapters 225 and 227 for management of these conditions.
INHALED INSULIN
In 2006, inhaled insulin was marketed in the United States but was discontinued by the manufacturer. The U.S. Food and Drug Administration approved a new formulation of inhaled regular insulin in 2014 for prandial use in adults without pulmonary disease.12 This recombinant regular Technosphere insulin (Afrezza®) may be noninferior to injected prandial insulin combined with long­acting insulin injections, but there are minimal long­term data available.13
GLYCEMIC COMPLICATIONS IN INSULIN­DEPENDENT PATIENTS
The major hyperglycemic emergencies, hyperosmolar hyperglycemic state and diabetic ketoacidosis, are discussed in Chapter 227, “Hyperosmolar Hyperglycemic State,” and Chapter 225,
“Diabetic Ketoacidosis,” respectively. Here we discuss the common ED presentation of an “abnormal lab value” (i.e., patients with no acute symptoms of hyperglycemia found to have elevated plasma glucose levels).
HYPERGLYCEMIA IN PREVIOUSLY DIAGNOSED T1DM
For patients with T1DM with hyperglycemia noted on multiple ED visits, refer to the primary physician for insulin dose adjustment. In the interim, ask patients to keep a daily record of every meal, every dose of insulin administered (along with type of insulin), and blood glucose levels four times a day (after rising in the morning, before lunch, before dinner, and at bedtime).
If an insulin dose adjustment is made in the ED, the basic regimen should conform to a once­ or twice­daily dose of long­ or intermediate­acting insulin, combined with prandial doses of rapid­acting insulin. The magnitude of increase in the basal insulin dose should be carefully tailored to the degree of hyperglycemia in the patient and duration of time since the last meal, but typically should change by no more than 10%. For example, if a patient has a measured glucose of 300 milligrams/dL (16.6 mmol/L)  hour after consuming a meal, increasing longacting insulin may result in late hypoglycemia as the measured glucose is more attributable to recent carbohydrate ingestion; this episode of hyperglycemia may be better managed by recommending an increase in preprandial insulin dosing.
A conservative supplemental dose of rapid­acting insulin may be calculated as follows:  unit per  milligrams/dL (2.8 mmol/L) above target glucose level for T1DM, and  unit per  milligrams/dL (1.7 mmol/L) above target glucose level for T2DM.11
For example, to achieve a goal blood glucose of 100 milligrams/dL(5.5 mmol/L) in a patient with T1DM who has a glucose level of 350 milligrams/dL (19.5 mmol/L), administer  units of rapidacting insulin. Anticipated carbohydrate consumption would require additional insulin.
If the patient is using neutral protamine Hagedorn (NPH or isophane) insulin, inspect the insulin vial; if frosting is noted on the sides of the bottle, this may indicate denaturation, which renders the insulin ineffective. Provide the patient with a new prescription, and discard the old vial.
Falsely Elevated Capillary Glucose
Several substances can falsely elevate point­of­care and home blood glucose monitoring accuracy, including acetaminophen, ascorbic acid, and peritoneal dialysis solutions using icodextrin.14­17 Falsely elevated point­of­care glucose reading and reflexive insulin administration have been responsible for several reports of severe hypoglycemia. Point­of­care test strips for both home and hospital use are also sensitive to temperature and humidity and thus may provide inaccurate glucose levels. If the point­of­care glucose level does not fit the clinical presentation or if the patient receives peritoneal dialysis, obtain a laboratory plasma glucose level for treatment decisions.
HYPOGLYCEMIA IN INSULIN­DEPENDENT PATIENTS
Hypoglycemia (plasma glucose <70 milligrams/dL [<3.9 mmol/L]) is the major adverse effect of tight glycemic control. Apart from insulin administration, patients with T1DM are prone to hypoglycemia because the surge of glucagon is absent and epinephrine secretion may be blunted due to neuropathy, age, or autonomic dysfunction from prior hypoglycemic episodes.
Older insulin regimens used once­ or twice­daily injections of NPH, Lente insulin, or premixed combinations (70/30, 75/25, or 50/50) of basal insulin and regular insulin as the prandial dose.
These schedules mandated fixed meal times and activity schedules, so it was not unusual to develop hypoglycemia with missed meals or unusual stress. Modern physiologic regimens of insulin administration (once­daily long­acting insulin with short­acting doses immediately before meals) have significantly reduced the incidence of hypoglycemia.11 However, many patients remain on premixed dosing due to familiarity or financial limitations.
Determine the cause of hypoglycemia. Common causes include inadequate intake of food, inaccurate administration of insulin, infection, renal failure, acute coronary syndrome, and unusual physical or mental stress. Identify the timing and administration of insulin in relation to meals. Ask if the patient is measuring blood glucose at home; at a minimum, it should be checked daily before breakfast and recorded in a diary. There is great variation in the pattern of hypoglycemic signs and symptoms from patient to patient; however, individual patients tend to experience the same pattern from episode to episode. Common neuroglycopenic symptoms may include headache, irritability, drowsiness, confusion, dizziness, tiredness, inability to concentrate, and difficulty speaking. These symptoms may mimic an acute ischemic stroke. Adrenergic symptoms such as tremor, sweating, anxiety, nausea, palpitations, feelings of warmth, and shivering are also seen, as are other symptoms such as hunger, weakness, and blurred vision.18
Hypoglycemic unawareness or hypoglycemia­associated autonomic failure occurs when diabetic patients have deficient counterregulatory hormone excretion, resulting in a lack of symptoms of hypoglycemia.19 This results in frequent episodes of hypoglycemia and profound hypoglycemia. β­Blocker medication may also contribute to this condition by masking typical adrenergic symptoms of hypoglycemia.
Treatment of Hypoglycemia
Glucose is the preferred treatment, although any glucose­containing carbohydrate may be used. The initial dose is  to  grams of glucose (PO, IV, or IO), which can be repeated if hypoglycemia persists after  minutes. Sublingual glucose (40% dextrose gel preferred; teaspoon of sugar may suffice) may also be effective in resource­limited situations.20­22
Pure fructose does not cross the blood–brain barrier and does not significantly improve blood glucose levels. Most sweet foods or drinks contain both glucose and fructose; they are labeled as containing “sugars,” which includes glucose, fructose, or sucrose. Protein has a negligible contribution to serum glucose, so foods such as peanut butter or cheese are not recommended for hypoglycemia treatment. Once hypoglycemia has resolved, have the patient eat a meal or carbohydrate snack. Table 223­4 lists the sugar content of commonly used oral agents.
TABLE 223­4
Sugar* Content of Agents Available at Home or Over the Counter
Agent Dose/Route Sugar Content
Fruit juice  cup PO Variable depending on type of juice and manufacturer (mostly fructose)
 oz Mott’s® apple juice:  grams sugar
Honey  Tbsp PO  grams sugar (glucose and fructose)
Sugar­containing soda  oz (one can) PO (Non­diet) Pepsi®:  grams sugar (mostly fructose)
(Non­diet) Sprite®:  grams sugar (mostly fructose)
(Non­diet) Coca­Cola (Coke)® Original:  grams sugar (mostly fructose)
Glucose tablets  tablets PO  grams glucose
Glucose gel  tube PO/SL  grams glucose
*”Sugar” may include glucose, fructose, galactose, sucrose, lactose, or maltose.
Glucagon emergency kits are available for caregivers of patients with T1DM for emergency situations. One milligram of intramuscular glucagon stimulates glycogenolysis and is effective in
 to  minutes. Preliminary data show that intranasal glucagon may also be effective.23 Once the patient is alert enough to swallow, give oral glucose immediately. Glucagon is not effective in glycogen­depleted patients, and glucagon may induce nausea and vomiting, which can make it difficult to consume oral glucose subsequently.
Insulin Overdose
Short­acting insulin may have delayed and prolonged absorption; patients with a significant accidental or intentional overdose should be monitored for several hours. Patients with a significant overdose of a long­acting insulin should be admitted for monitoring of glucose levels. Most patients may be discharged if caregivers and family members can monitor symptoms and capillary glucose levels.
INSULIN PUMPS (CONTINUOUS SC INSULIN INFUSION)
The use of an insulin pump (continuous SC insulin infusion) (See Video: The Insulin Pump) is common, but prevalence of pump use varies from 14% to 70% depending on demographics and country.24­29 An insulin pump is a small device (about the size of a pager) that delivers rapid­acting insulin at a basal rate and boluses of insulin for prandial and hyperglycemia correction.
Once programmed, the pump can automatically calculate dosing for a certain amount of carbohydrates about to be consumed and correct for premeal hyperglycemia or hypoglycemia. The insulin is pumped through a flexible tube and infused via a subcutaneous catheter. The pump is usually attached to the patient’s waistband. The patient must refill the insulin reservoir and change the catheter every  to  days. Table 223­5 lists manufacturers of insulin pumps available in the United States. Some insulin pumps do not use tubing but directly attach to the patient with adhesive.30
Video 223­1: Insulin Pump
Used with permission from Camille Izlar.
Play Video
TABLE 223­5
Manufacturers of Insulin Pumps Available in the United States with Their 24­Hour Phone Numbers
Manufacturer Website Telephone Number
Animas* http://www.animas.com (877) 937­7867
Insulet OmniPod http://www.myomnipod.com (800) 591­3455
Medtronic MiniMed http://www.medtronicdiabetes.com (800) 646­4633
Roche Accu­Chek https://www.accu­chek.com/support/insulin­pumps (800) 688­4578
Sooil DANA http://www.sooil.com (866) 747­6645 ext. 102
Tandem Diabetes https://www.tandemdiabetes.com (877) 801­6901
*Animas insulin pump is no longer manufactured but is still in use. Telephone number is still active.
The basal rate of insulin (generally, .5 to .5 units/h) can be varied throughout the day; for example, increased to counteract an early morning cortisol surge or decreased before exercising.
Continuous insulin delivery eliminates the need for long­acting insulin injection such that the pump delivers all insulin required by the patient in the form of rapid­acting insulin. Rarely, patients requiring exceptionally high doses of insulin using an insulin pump, patients who wish to be disconnected from their pump for extended periods of time, or patients at higher risk of hyperglycemia or diabetic ketoacidosis (e.g., young children) may inject an additional once­ or twice­daily long­acting insulin.31,32 The pump can be manually activated to deliver a bolus for hyperglycemia and for prandial dosing. Insulin pumps are most appropriate for motivated patients who are mechanically adept, well educated about diabetes and carbohydrate counting, and able to monitor their capillary glucose four to six times a day. Benefits of insulin pump therapy over multiple daily injections include average reduction in hemoglobin A1C of .5% and reduction in hypoglycemic episodes (See Video: The Insulin Pump).24,33
INSULIN PUMP COMPLICATIONS
Insulin pump delivery can fail for a variety of reasons (disconnection, empty reservoir, kinked catheter, priming errors), although modern pumps have built­in alarms to detect these conditions.34 Because pumps use only rapid­acting insulin, onset of ketoacidosis can be very rapid after pump failure—an hour or less. If the pump is defective or needs to be removed for a procedure such as MRI, give the patient either a dose of rapid­acting insulin or long­acting insulin, especially if the insulin pump is to be interrupted for over an hour. If a patient on an insulin pump needs to be nothing by mouth (NPO), the insulin pump should not be removed and glucose levels should be checked every  to  minutes. If the patient has hypoglycemic episodes, the pump basal rate can be reduced; consultation with an endocrinologist is recommended.
Patients being switched from multiple daily injections of insulin to insulin pumps are typically handled as outpatients and will require special attention if presenting to the ED during this transition period. Specific considerations for patients on insulin pumps presenting with hyperglycemia or hypoglycemia are discussed elsewhere in this chapter.
Other important complications of insulin pump therapy include cellulitis at the infusion site or lipodystrophy. If patients using insulin pumps are incidentally found to have hyperglycemia or hypoglycemia, they should be allowed to treat themselves either by administering an insulin bolus through their insulin pump or by consuming carbohydrates, respectively.19,28,35 Their endocrinologist should have provided them instructions on how to address this.
CONTINUOUS INTERSTITIAL GLUCOSE MONITORING VERSUS POINT­OF­CARE (CAPILLARY) OR SERUM GLUCOSE MONITORING
Continuous glucose monitoring devices measure interstitial glucose concentrations with a subcutaneous sensor and then transmit glucose values to an insulin pump or other display device.
Interstitial glucose values are adjuncts to capillary glucose monitoring and typically require manipulation of the insulin pump to administer insulin. An even newer technology, the hybrid closed­loop system, was approved by the U.S. Food and Drug Administration in 2016. The hybrid closed­loop system adjusts insulin dosing based on continuous glucose monitoring data. The system can maintain the target glucose for a longer period, reduce episodes of hyper­ or hypoglycemia, and reduce hemoglobin A1C levels.36,37
Despite the substantial benefits of monitoring continuous interstitial glucose levels, it must be noted that interstitial glucose is a proxy, but not identical to, the more traditionally measured and validated serum glucose levels. There is about a 10­minute time lag for change between serum glucose and interstitial glucose levels.38 Several common medications may result in inaccurate continuous interstitial glucose sensor readings, notably including acetaminophen.39Measure capillary or serum glucose levels in the ED, and do not use interstitial glucose values (i.e., those displayed on the patient’s continuous glucose monitor) for diagnostic purposes.
HYPERGLYCEMIA IN PATIENTS USING INSULIN PUMPS
There are no widely accepted published guidelines for the ED management of patients with insulin pumps who present to the ED with hyperglycemia. Extrapolating from inpatient recommendations, we recommend that patients using insulin pumps who present to the ED with either hyperglycemia or hypoglycemia should be treated the same as patients who are on multiple daily doses of insulin, and the insulin pump should not be disabled.19,28
Once the patient has been stabilized, ask about dietary indiscretions and search for infections. Ask specific questions about the insulin pump: When was the insulin reservoir filled? When was the infusion set last changed? Is the insertion site of the infusion set periodically changed? When was the insulin reservoir last changed? Has the pump been submerged in water? Have any device alarms been sounding?40 Examine the device thoroughly to ensure the pump is on, the reservoir is not empty, no alarms are indicated, the tubing is not kinked, and the infusion site is well attached to the skin. The patient or caregiver may provide useful information on pump operation, diagnostics, and how to disconnect it if necessary. All pumps have a telephone number for 24­hour technical support from the manufacturer (Table 223­5). If there is suspicion for pump malfunction, consult endocrinology for consideration of replacement of the insulin pump with long­acting basal insulin.
DIABETIC KETOACIDOSIS IN PATIENTS USING INSULIN PUMPS
In the case of diabetic ketoacidosis in a patient using an insulin pump, assume a problem with the pump, disconnect the pump, and start an IV insulin infusion following protocols for management of diabetic ketoacidosis. We recommend against bolus IV insulin prior to initiation of an insulin drip because this provides no clinical benefit.41 Consider SC administration of long­acting insulin at the initiation of an insulin drip, particularly if re­initiation of insulin pump therapy is not expected after resolution of the diabetic ketoacidosis.42 If the patient remains in the ED and their ketoacidosis resolves, ensure that a dose of long­acting insulin is administered at least  hour before stopping the insulin drip unless the insulin pump is to be re­initiated—in that case, restart pump therapy approximately  hour before stopping the IV insulin drip. To re­initiate pump therapy, make sure that the pump is working appropriately by running diagnostics on the device, checking that the insulin reservoir is filled with fresh insulin, and placing a new SC insulin infusion catheter. Check serum glucose levels every  to  minutes. See Chapter 225 for further discussion of transition of insulin dosing in diabetic ketoacidosis.
HYPOGLYCEMIA IN PATIENTS USING INSULIN PUMPS
Treat hypoglycemia just as in other patients. Do not discontinue the pump, as diabetic ketoacidosis can rapidly develop. If recurrent hypoglycemia develops after initial treatment, pump malfunction may be the cause. Please see the earlier section “Hyperglycemia in Patients Using Insulin Pumps.”
SPECIAL CONSIDERATIONS
UNDIAGNOSED DIABETIC
A long asymptomatic period is common for T2DM, but T1DM typically has a short period before the disease becomes overt. If the patient is newly identified with severe and symptomatic hyperglycemia (>250 to 300 milligrams/dL [13.8 to .7 mmol/L]), insulin should be administered in the ED. Insulin can be given even if it is not known at the time whether the patient has T1DM or T2DM. Patients with severe or symptomatic hyperglycemia should be admitted or placed in an observation unit for further glucose control and education.
For patients with hyperglycemia but without ketoacidosis, a low dose of regular or rapid­acting insulin (1 unit subcutaneously for every  to  milligrams/dL above glucose of 250 to 300 milligrams/dL) may be given to reduce hyperglycemia, and a long­acting insulin (e.g., .1 to .2 units/kg of insulin glargine) should be given in the ED to prevent diabetic ketoacidosis.
For patients without severe and symptomatic hyperglycemia, regular or rapid­acting insulin can be given to reduce the glucose to about 250 milligrams/dL. Then, most patients may be discharged with a prescription for metformin and referral to their physician or clinic within  hours for further evaluation and care.19,43 For further discussion of T2DM care and noninsulin antidiabetic agents such as metformin, see Chapter 224. GLUCOCORTICOID THERAPY
Patients with T1DM who are started on glucocorticoids before discharge from the ED will likely develop hyperglycemia. They should be informed about warning signs of hyperglycemia and advised to seek close follow­up with their primary physician, with frequent monitoring of blood glucose at home and additional bolus doses of insulin. Routine increase in long­acting basal insulin dosage is not advised, as both the duration of action of the insulin as well as the steroid must be carefully considered.
Although previously undiagnosed patients with diabetes may develop hyperglycemia while on glucocorticoid therapy, the hyperglycemia will often resolve spontaneously once the glucocorticoid course is completed. If hyperglycemia is persistent or symptomatic, medication may be required after failure of dietary modification and exercise.
PRAMLINTIDE
Patients with T1DM who are unable to achieve optimal glucose control may also be treated with injections of prandial pramlintide in addition to prandial or continuous SC insulin.
Pramlintide, a synthetic form of the hormone amylin, is produced by β­cells. Amylin promotes satiety, slows gastric emptying, aids in suppressing postprandial glucagon secretion, and reduces hemoglobin A1C levels.5,44,45 Despite these benefits, the necessity for injection of a second prandial medication, incidence of nausea, and severe hypoglycemia, especially during dose titration, prevent the great majority of patients with T1DM from using this medication.46,47
TRANSPLANTATION
There are three methods of pancreas transplantation: simultaneous pancreas and kidney (75% of transplants), pancreas after kidney (18%), and pancreas transplant alone (7%).48 In 2016,
215 pancreas transplants and 798 combined kidney/pancreas transplants were performed in the United States.49 Life­long immunosuppression is required. One­year graft survival with insulin independence approaches 86% (simultaneous pancreas and kidney), 80% (pancreas after kidney), and 78% (pancreas transplant alone); 10­year graft survival is 68% (simultaneous pancreas and kidney), 46% (pancreas after kidney), and 39% (pancreas transplant alone).48,50
Another promising modality is islet cell transplantation. The Edmonton protocol has led to insulin independence in T1DM.51Insulin independence is short lived, however;  years after transplantation, 76% of patients again required the use of exogenous insulin. Some longitudinal studies have demonstrated insulin independence  years after Edmonton protocol islet cell transplant.52


