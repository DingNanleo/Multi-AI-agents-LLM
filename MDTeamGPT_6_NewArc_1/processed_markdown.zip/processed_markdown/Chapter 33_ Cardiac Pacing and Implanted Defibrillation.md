## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 33: Cardiac Pacing and Implanted Defibrillation
Swee Han Lim; Wee Siong Teo; Venkataraman Anantharaman
PURPOSE OF PROCEDURE
Cardiac pacing serves to maintain or restore myocardial depolarization and thus ensure adequate cardiac output. In the ED, pacing corrects rhythm
 disturbances or starts in anticipation of a conduction problem with hemodynamic impact.
Indications for emergency pacing are provided in Table 33­1. TABLE 33­1
Indications for Emergency Pacing
Indication Comments
Symptomatic or hemodynamically unstable bradycardia/AV block Symptoms include hypotension, change in mental status, angina, and pulmonary edema.
Pharmacologic therapy may be used to temporize while preparing to pace.
Severe sick sinus syndrome with prolonged asystole (generally >3 — s) and syncope
Ventricular standstill due to complete heart block or Mobitz type II —
AV block
Torsades de pointes Overdrive pacing.
Recurrent monomorphic ventricular tachycardia Overdrive pacing.
The technique is limited by:
Maximum pacing rate of the pacing device (usually 180 beats/min).
Potential of accelerating the ventricular tachycardia and inducing ventricular fibrillation.
Unstable supraventricular tachycardia Overdrive pacing should be used only after pharmacologic intervention and cardioversion have failed.
Abbreviation: AV = atrioventricular.
GENERAL EQUIPMENT

Cardiac pacemakers deliver an electrical stimulus to the heart through electrodes, causing depolarization and subsequent cardiac contraction. The modern implanted pacemaker only stimulates the heart chamber if it does not recognize (sense) intrinsic electrical activity from that chamber after a selected time interval. Impulses go to the atria, ventricles, or both.

CCohmapptoenr e3n3t:s C oaf rad ciaacrd Piaacc pinagc eamnda kImerp ilnacnltuedde :Defibrillation, Swee Han Lim; Wee Siong Teo; Venkataraman Anantharaman 
. Terms of Use * Privacy Policy * Notice * Accessibility
Pulse generator
Electronic circuitry for sensing and pacing
Lead system that connects the pulse generator to the electrode(s) and stimulates the myocardium
Relevant clinical details of these components are provided in Table 33­2. TABLE 33­2
Pacemaker Component Details
Pacemaker Type Pulse Generator Location Electrode Location
Transcutaneous External Skin of anterior chest wall and back or
Anterior chest wall below right clavicle and apex
Transvenous External Venous catheter with tip in right ventricle and/or right atrium
Transesophageal External Esophagus
Epicardial External or Internal Epicardium
Electrodes are usually placed on heart’s surface during surgery
Permanent Internal (subcutaneous in the prepectoral region) Venous or epicardial
TRANSCUTANEOUS PACING
Transcutaneous pacing is an emergency technique frequently chosen in patients presenting with hemodynamically significant bradycardia because of its easy application. It uses externally (chest wall) applied electrodes to deliver an electric impulse to stimulate the myocardium. Transcutaneous pacers differ from standard pulse generators: The pulse duration of the externally stimulating impulse is longer and the current output higher than in internal pacing. Muscle contraction (usually the chest wall or diaphragm) is notable during external pacing, especially at high outputs, and may be painful. The muscle twitching makes palpation of the radial, carotid, or femoral pulse difficult. Finally, cardiac monitoring with standard ECG monitors is difficult during external pacing due to interference from the large current outputs that create large­amplitude pacing spikes. Most of the newer transcutaneous pacing units have a monitor that filters pacing spikes, allowing simultaneous monitoring.
RISKS AND PRECAUTIONS
There is little risk of electrical injury to healthcare providers during transcutaneous pacing. The electrode insulation allows contact with the patient, including closed chest compressions, while pacing.
EQUIPMENT
Table 33­3 lists the equipment needed to perform transcutaneous pacing.
TABLE 33­3
Transcutaneous Pacing Equipment
Pulse generator and monitor (usually a combination defibrillator/cardioversion/pacemaker unit)
Pacemaker pads with pacing cables
ECG monitor and cables with ECG electrode pads
TECHNIQUE
If time and conditions allow, explain the procedure to the patient and administer IV sedation and analgesia before pacing. Vital signs and ECG monitoring are mandatory during the procedure.
Place the pacing pads on the patient’s chest either in the anterolateral or anterior­posterior position (Figure 33­1). The anterior­posterior position minimizes transthoracic electrical impedance by sandwiching the heart between the two pads. The same pads and electrodes allow pacing, cardioversion, and defibrillation in most of the newer defibrillator units.
FIGURE 33­1. Placement of the transcutaneous pacing electrodes. A. Anterior (negative) electrode position centered over the cardiac apex. B. Anterior (negative) electrode position centered over the V lead position. C. Posterior (positive) electrode position. [Reproduced with permission from Doukky R,

Rajanahally RS: Transcutaneous cardiac pacing, in Reichman EF, Simon RR (eds): Emergency Medicine Procedures. Figures 20­2 and 20­3. Copyright ©
2004. The McGraw­Hill Companies, Inc. All rights reserved.]
In bradyasystolic arrest or with depressed sensorium, turn the stimulating current to maximum output; after restoring pulses, you may titrate energy downward to a level just above loss of capture. In a still­conscious patient with a hemodynamically compromising bradycardia, slowly increase the output from the minimum setting until capture—usually between  and 100 mA. Continue pacing at about .25 times the threshold of initial electrical capture.
Transcutaneous pacing may be fixed rate (asynchronous) or demand (synchronous). Asynchronous pacing delivers an electrical impulse at a regular interval without regard to intrinsic cardiac pacemaker activity. This creates the potential risk of precipitating a dysrhythmia if the pacing stimulus occurs during the vulnerable period of ventricular repolarization. Although many state a preference for synchronous pacing, there are little outcome or safety data to support that preference.
OUTCOMES ASSESSMENT
Assess capture using the ECG on the filtered monitor of the pacing unit. Look for the presence of a consistent ST segment and T wave after each pacer spike. Palpate for carotid and femoral pulses with each such waveform. Bedside cardiac US can assess external pacer mechanical contraction, identifying capture. If these appear favorable, assess blood pressure by cuff or arterial catheter.
Failure to capture with transcutaneous pacing may be related to faulty electrical contact, inadequate current, poor pacing pad placement, or the underlying pathology. Recheck the lead connections, skin–electrode contact, and electrode placement. On occasion, pneumothorax, pericardial effusion or tamponade, severe myocardial ischemia, and metabolic derangements limit capture. Unless an easily resolved trigger exists, arrange for transvenous pacing as soon as possible.
TRANSVENOUS PACING
The indications for transvenous pacing are the same as for other methods of cardiac pacing. Transvenous pacing is an urgent rather than emergent intervention, with transcutaneous pacing serving as the bridge.
Gather all equipment needed, including that to insert a central venous catheter (see Chapter , “Vascular Access”). Resuscitation equipment and drugs and the pacing needs are listed in Table 33­4. TABLE 33­4
Equipment Needed for Transvenous Pacing
Central catheter kit—introducer sheath must be one size larger than the pacer catheter
Flexible transvenous cardiac pacing catheter
Pacemaker generator and battery (and spare battery)
Cardiac monitor
Insulated connecting wire with alligator clamps at both ends
TECHNIQUE
You should know the equipment and have practiced or done the procedure before starting. If conditions permit, explain the procedure to the patient and obtain informed consent. Next, identify the access site and approach and position the patient. The primary sites of catheter insertion in the
ED are the right internal jugular vein (preferred) and the left subclavian vein. The right internal jugular vein allows a relatively straight line of access through the superior vena cava and right atrium into the right ventricle.
The steps for transvenous pacemaker insertion are listed in Table 33­5. TABLE 33­5
Transvenous Pacemaker Insertion
Step Comments
. Gown in standard sterile fashion. Use sterile gloves and gown. Wear mask and hair covering.
. Identify vessel using US guidance. —
. Prep and drape patient using standard sterile procedure. Prep a wide area in case initial attempts fail and an alternate site is needed.
Prep the entire ipsilateral neck and upper chest when preparing to insert an internal jugular or subclavian catheter.
. Open a central catheter kit that contains an introducer catheter. The introducer catheter should be one size larger than the pacing catheter.
Inspect for content in a sterile fashion.
Place kit close to bedside and operator.
Maintain sterile conditions.
. Open pacing catheter and pacing kit (if available). Pulmonary artery catheters with dedicated atrial and ventricular ports may also be used.
Assess integrity of the pacing catheter balloon by inflating it with .5 mL of air and immersing it in sterile saline. Air bubbles indicate a leaky balloon.
. Attach the pacemaker to any of the V leads and ensure it is recording. —
. Anesthetize area in all conscious patients. Inject area with 1%–2% lidocaine.
Anesthetize the periosteum of the clavicle if using the subclavian approach.
Reorient to landmarks after injection.
. Hold the 18­gauge introducer needle on a 10­mL syringe in the — dominant hand and align the needle to the target.
. Advance the needle slowly though the skin and subcutaneous tissue Maintain steady constant aspiration of syringe.
until a flash of dark venous blood appears.
. Stabilize the needle with the nondominant hand. —
. Check for continued free venous flow with aspiration. If no flow is noted, withdraw the needle slightly, as the needle may have breached the posterior vessel wall.
. Remove the syringe attached to the needle, and immediately This maneuver helps to prevent introducing air in the catheter and subsequent occlude the catheter with a finger. central system air embolism.
. Insert the guidewire gently through the needle. Always maintain a The wire should advance with minimal resistance.
firm grip on the wire—do not let go of the wire for any reason. Do not force the wire for any reason.
If the wire does not pass easily, reattach the syringe and aspirate to confirm continued venous flow.
Reposition the needle as needed.
Premature ventricular contractions (PVCs) or dysrhythmias during wire advancement may indicate that the wire is in the right atrium or beyond.
. Remove the needle over the wire when the guidewire is inserted at — least  cm into the vessel.
. Incise the skin with a #11 blade scalpel at the entry site to Do not cut the guidewire.
accommodate the introducer.
. Advance the introducer over the guidewire into the vessel lumen Maintain a grip on the guidewire during this procedure.
with a gentle twisting motion.
. Remove the guidewire. —
. Insert and advance the pacing catheter approximately  cm. This ensures that the balloon is past the introducer catheter and within the vascular system.
Inflate the balloon with .5 mL of sterile saline.
. Slowly advance the catheter into the right ventricle. Use fluoroscopy or bedside US to guide placement.
The ECG tracing recorded from the electrode also helps localize the position of the catheter tip.
Inflate the balloon after the catheter enters the superior vena cava.
Stop advancing when the pacing catheter is in the apex of the right ventricle.
. Reassess balloon integrity. —
. Connect the pacemaker generator to the catheter. —
. Disconnect the negative terminal of the pacemaker catheter from — the ECG lead.
. Connect the proximal pacemaker catheter terminals to the — terminals of the pacemaker generator.
. Set the pacemaker generator on demand mode with a rate of 80– Start with  mA of energy on the output dial.
100 beats/min.
. Turn on the pacemaker. With optimal tip position, capture should occur at <2 mA.
Pacing spikes and a wide QRS complex in lead V reflect capture.

. After capture, decrease the pacemaker generator output to just Continue pacing at .5–2.0 times the threshold output required for capture.
below where pacing stops.
. Examine the chest radiograph for catheter tip placement and signs — of complications.
. Secure catheter and apply a sterile transparent dressing. —
The most commonly encountered difficulties with transvenous pacing are securing venous access and obtaining proper placement of the stimulating electrode in the right ventricle, both of which can be time­consuming. When patients have decreased or no forward blood flow, positioning of the pacer tip within the right ventricle is difficult. Balloon­tipped catheters do not aid during low­ or no­flow states. In an emergency, connect the pacemaker electrodes to the power source and advance the catheter until the tip encounters the endocardium of the right ventricle and creates capture.
Set the initial rate between  and 100 beats/min, using the asynchronous mode (sensitivity off) initially in patients requiring emergency pacing for hemodynamically unstable bradycardias. Follow the ECG to determine the presence or absence of capture (Figure 33­2). Adjust subsequent rate and sensitivity settings as clinically indicated by the response and underlying rhythm disturbance.
FIGURE 33­2. Pacing with intermittent capture. “P” indicates paced beats, and “A” indicates pacer artifact without capture.
COMPLICATIONS
Complications include perforation of the myocardium, cardiac dysrhythmias, air embolism, failure of the circuit, catheter dislodgement, and delayed infection, plus any complications possible with central venous access (see Chapter 31).
PERMANENT PACING

Permanent pacing is not performed in the ED. Permanent pacemaker pulse generator (battery) placement is usually on the side of the patient’s nondominant hand (thus, usually in the left prepectoral region below the left clavicle). The endocardial transvenous leads insert into the right ventricle at the apex, septum, right ventricular outflow tract, or His Bundle region and, in the case of a dual­chamber device, also in the right atrium. A subclavian or cephalic vein approach is common. An epicardial lead may be implanted during open heart surgery. Patients with heart failure may have a cardiac resynchronization therapy device and will have three wires, with one in the atrium, one in the right ventricle, and one in the coronary sinus pacing the left ventricle.
Pacemaker leads are either bipolar or unipolar in configuration; unipolar leads are prone to oversensing myopotential and electromagnetic interference.

A new form of pacing is the leadless pacemaker where insertion of a miniature device transvenously for right ventricle implantation occurs. There is no device noted externally.
PACEMAKER NOMENCLATURE

A five­letter code describes the features of the pacemaker. The first three code letters are most commonly used. The first letter refers to the chamber or chambers in which the pacing occurs: A = atrium, V = ventricle, and D = dual chamber or both A and V. The second letter refers to the chamber or chambers in which sensing occurs. The letters are the same as those for the first letter code. “I” indicates that a sense event inhibits the output pulse and causes the pacemaker to recycle the timing cycles, “T” means that an output pulse is triggered in response to a sensed event. “D” means that both
“T” and “I” responses can occur. The most common pacemakers are VVI and DDD. The fourth letter is used to indicate the presence or absence of an adaptive­rate mechanism (rate modulation). Pacemaker designations may be VVIR or DDDR. The fifth letter indicates whether multisite pacing is present and is rarely used. See Figures 33­3 and 33­4 for examples of ECGs with pacemaker spikes.
FIGURE 33­3. Single­lead pacemaker. Only the ventricle is paced.
FIGURE 33­4. Atrioventricular pacer spikes seen best in leads II and aVF.
RESUSCITATION IN PATIENTS WITH A PERMANENT PACEMAKER
If a patient who has a permanent pacemaker requires countershock, place the pads or paddles at least  cm from the pulse generator. The current normal positioning of the paddles—below the right clavicle and apex of the heart—is safe because most pulse generators are below the left clavicle. Alternatively, place adhesive electrodes in an anteroposterior configuration. After countershock, interrogate the pacemaker to ensure that it is still functioning normally.
Potential problems after defibrillation include:
Pacemaker inhibition due to reversion to noise mode
Deletion (reprogramming)
Circuit damage
Myocardial damage adjacent to the lead tip caused by current transmission via the electrode to the myocardial interface
Another reason that immediate return of pacing (capture) fails after defibrillation is that global myocardial ischemia increases pacing threshold. If this occurs, try transcutaneous pacing at higher delivered energy settings.
PACEMAKER COMPLICATIONS
Complications for which a patient may seek care in the ED early after pacemaker insertion are listed in Table 33­6. TABLE 33­6
Complications Seen After Pacemaker Insertion
Complication Comment
Infection Infection rate is <1%.
Infections are more common in patients after pacemaker replacement or prolonged procedure.
Early infections are most commonly caused by Staphylococcus aureus or Staphylococcus epidermidis.
Pacemaker infection presents as:
Local inflammation or abscess formation in the pacemaker pocket, as evidenced by pain, tenderness, or redness at the site. Skin adherence to the device, especially with discoloration of the skin over it, is highly indicative of localized infection. Do not aspirate the pocket because this can worsen the infection. If only a superficial infection is suspected, antibiotics and analgesics may be given with an early referral to the device implanter to review.
Erosion of the device or lead through the skin resulting in the leads or pulse generator being exposed. Complete device and lead removal is almost always required.
Cardiac device–related infective endocarditis involving the lead or valves. Patient may present with sepsis and positive blood culture without sign of local inflammation.
Thrombophlebitis Symptomatic thrombosis of the upper extremities and central veins is uncommon, possibly because of extensive venous collaterals and venous (0.3%–3.0% of patients).
obstruction Site of insertion does affect incidence.
Symptoms include edema, pain, or venous engorgement of the arm ipsilateral to lead insertion.
Treatment includes IV heparin therapy followed by long­term warfarin administration.
Pneumothorax 1% of patients.
More common with subclavian introducer technique.
Hemothorax and pneumomediastinum are rare.
Pacemaker 20% of patients.
syndrome New or worsening of symptoms such as syncope or near­syncope, orthostatic dizziness, exercise intolerance, dizziness, uncomfortable pulsation over the neck and abdomen, right upper quadrant pain, etc.
Pacemaker Syndrome
Atrioventricular synchrony and the presence of ventriculoatrial conduction are most common in the setting of VVI pacing but may occur with the DDI mode. With VVI pacing, the ventricle stimulation results in ventricular contraction. If sinus node functions are intact, the native sinus impulse causes contraction with closed tricuspid and mitral valves. This results in an increase in jugular and pulmonary venous pressures and may produce symptoms of congestive heart failure. Atrial distention can result in reflex vasodepressor effects mediated by the CNS. If the contribution of atrial contraction to late diastolic ventricular filling is important in maintaining an adequate cardiac output, orthostatic hypotension may occur. DDI pacing in a patient with atrioventricular block can result in pacemaker syndrome if the sinus node discharge rate exceeds the programmed rate of the pacemaker.
In most instances, symptoms are mild and patients adapt to them. In about one third of these patients, symptoms are severe. Treatment usually requires upgrading a VVI pacemaker to a dual­chamber pacemaker or lowering the pacing rate of the VVI unit so that ventricular pacing does not occur provided intrinsic conduction occurs. If symptoms occur in a patient paced in the DDI mode, optimizing the timing of atrial and ventricular pacing is best done by a consulting cardiologist.
PACEMAKER MALFUNCTION

Pacemaker malfunction occurs in four ways: failure to sense, failure to pace, failure to capture, or overpacing or pacemaker­associated tachycardia.
Failure to Sense (Undersensing)
Undersensing occurs when the pacemaker cannot detect the intrinsic electrical cardiac activity. This results from lead placement in an area of the heart with poor or variable conductivity, or if a lead is loose, dislodged, or physically broken. Sensing failure can occur if the programmed sensing threshold is set too high. With undersensing, if the pacer is set in an inhibit mode, it will fire at a set rate that is uncoordinated with the patient’s underlying cardiac cycle (Figure 33­5A).
FIGURE 33­5. Various pacemaker malfunctions. A. Undersensing. B. Oversensing. C. Failure to capture.
Failure to Pace (Oversensing)
Oversensing occurs when the pacemaker experiences interference from electrical signals within the body (i.e., skeletal or smooth muscle myopotentials) that are not related to the normal cardiac cycle. Sources of interference may include skeletal muscle, the diaphragm, nerve stimulators, broken pacer leads, and uncommonly, coarse atrial fibrillation. When oversensing, the pacemaker erroneously inhibits the pulse generator, and the patient may develop bradycardic rhythms (Figure 33­5B).
Failure to Capture
Failure to capture occurs when the pulse generator fires but the current delivered to the endocardium is too low to initiate depolarization and wavefront propagation. Dislodged or broken leads, poor cardiac conductivity due to myocardial disease (e.g., ischemia, acidosis, fibrosis), and programming problems are the most common reasons for this malfunction. Failure to capture can be intermittent (Figure 33­5C).
PACEMAKER­ASSOCIATED TACHYCARDIA
Occasionally the patient with an implanted device may present with a rapid paced rhythm. This may be due to:
Rapid atrial arrhythmia triggering an upper rate response in a patient with complete heart block
Pacemaker­mediated tachycardia
Runaway pacemaker
Unless preprogrammed to mode switch, pacemakers detect rapid atrial rhythms and track them, resulting in pacing at the upper rate limit. Pacemakermediated tachycardia can occur in a dual­chamber pacemaker when a premature ventricular ectopic beat triggers a retrogradely conducted atrial depolarization outside the atrial refractory period, then sensed by the pacemaker, initiating ventricular pacing. If this continues, it can cause an endless loop tachycardia. Rarely the pacemaker may malfunction with acceleration of pacing (runaway pacemaker). This occurs when the pulse generator discharges at a rapid rate above its preset upper limit and is most commonly associated with a battery failure or damage from external interference. Placing a magnet over the pacemaker may help in the pacemaker­mediated tachycardia or runaway pacemaker. However, interrogation of the device is usually required, and the device must be replaced if programming is not successful.
PACEMAKER PROGRAMMING ERRORS
Pacemakers are computer­controlled devices with complex software that requires adjustment and maintenance. Reprogramming is noninvasive through radio frequencies. Occasionally, settings are inadvertently altered, or software can fail. Software changes may occur in set rates, sensing thresholds, and current outputs.
IMPLANTABLE CARDIOVERTER­DEFIBRILLATORS
Implantable cardioverter­defibrillators are the treatment of choice for sudden cardiac death, reducing mortality from approximately 30% to 45% per
 year to <2% per year. This remarkable impact, coupled with the failure (and potentially prodysrhythmic effects) of pharmacologic therapy and the increasing sophistication and miniaturization of the devices, all add to implantable cardioverter­defibrillator use. The most common cause of death in patients with an implantable cardioverter­defibrillators is congestive heart failure.
An implantable cardioverter­defibrillator consists of a pulse generator, a lead system with both sensing and shocking electrodes, circuitry to analyze the cardiac rhythm and trigger defibrillation, and a power supply.
In the past, insertion of these devices generally was by thoracotomy or sternotomy, and defibrillation occurred through electrodes positioned inside or outside the pericardium. In newer implantable cardioverter­defibrillators, sensing­pacing­defibrillation electrodes are inserted transvenously, and the control device is placed subcutaneously in the subpectoral region or in an abdominal pocket. Newer implantable cardioverter­defibrillators are better at discriminating supraventricular tachycardia and are capable of a variety of responses to ventricular tachycardia and fibrillation. Most device programs follow a tiered approach to ventricular dysrhythmias: antitachycardia pacing, low­energy cardioversion, and finally defibrillation. Depending on the frequency of discharge and whether the pacemaker function is used, the latest implantable cardioverter­defibrillators have a projected life span of approximately  to  years, depending on whether they are single­ or dual­chamber devices.
Some newer devices may be implanted subcutaneously. These devices do not have pacing function and reside in the left axillary region, with the lead tunneled to the left sternal region. In such patients, place the defibrillation pad in the anterior­posterior region.
ED EVALUATION
The most common reason a patient with an implantable cardioverter­defibrillator comes to the ED is evaluation after a delivered shock. Causes of inappropriate shock delivery are listed in Table 33­7. Determine the number of shocks delivered, the activity of the patient at the time of shock, and any prodromal symptoms or postshock trauma. Ask about any recent changes in rhythm­directed drug therapy. Focus the physical examination on the vital signs, the cardiovascular status, the generator pocket, and evidence of incidental trauma. Place each patient on a continuous ECG monitor, and obtain a 12­lead ECG; any shock­related ST­segment elevations or depressions should resolve within  minutes; ongoing changes suggest new ischemia. Examine a chest radiograph for electrode migration, displacement, or fracture. Obtain rhythm­related drug levels and serum
,7 electrolyte levels.
TABLE 33­7
Potential Causes of Inappropriate Implantable Cardioverter­Defibrillator (ICD) Shock Delivery
False sensing
Supraventricular tachycardia with rapid ventricular response
Muscular activity (shivering, diaphragmatic contraction)
Extraneous source (tapping of chest wall, vibrations, pacer spikes)
Sensing T waves as QRS complex (double counting)
Sensing lead fracture or migration
Unsustained tachyarrhythmia
ICD–pacemaker interactions
Component failure
If the patient is receiving repeated inappropriate shocks for a nonlethal rhythm, temporarily deactivate the implantable cardioverter­defibrillator by placing a magnet over the device. Defibrillation can be reenabled by removing the magnet. Have a cardiologist evaluate all patients with implantable cardioverter­defibrillators after exposure to a magnet.
For a patient with an implantable cardioverter­defibrillator in cardiac arrest, follow standard resuscitation measures. If defibrillation is necessary, do not place either the paddle or pad directly over the implantable cardioverter­defibrillator pulse generator. Perform CPR in the usual fashion. If the implantable cardioverter­defibrillator discharges, the CPR provider may perceive a small electrical shock, but the shock is neither uncomfortable nor dangerous.
DISPOSITION AND FOLLOW­UP
Admission criteria depend on the reason for shock delivery. Consultation with the treating cardiologist is key with implantable cardioverterdefibrillator interrogation, which is manufacturer and model specific. Admit those with any sign of cardiovascular instability, a history of two or more new shocks in a 1­week period, correctable causes of dysrhythmia, and any sign of infection or mechanical disruption of the implantable cardioverterdefibrillator or lead system.


