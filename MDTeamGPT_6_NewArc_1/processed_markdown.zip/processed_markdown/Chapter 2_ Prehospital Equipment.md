
University of Pittsburgh
Access Provided by:

Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 2: Prehospital Equipment
Brett Boggust; Andy Boggust

INTRODUCTION
To a large extent, early EMS equipment began as hospital equipment that was extrapolated to the field; it was assumed that if something worked in the hospital, then it would work in the field. It soon became apparent that hospital equipment did not always perform under the more rigorous conditions of the prehospital environment. Over the past 30 years, equipment has evolved specifically for EMS that is better adapted to field use in terms of size, weight, and durability. This equipment is directed at resuscitating and sustaining the patient during emergency or interfacility transport. As the science of EMS continues to mature, more equipment will be scrutinized for effectiveness. The four basic questions regarding efficacy of EMS equipment are:
1. Does it do the job?
2. Is it safe?
3. Can it be applied to the field environment?
4. Can it be used effectively by prehospital personnel?

The nature of EMS equipment is changing due to the expanded scope of practice by paramedics and the blurring of care levels between basic life support (BLS) and advanced life support (ALS) personnel. Equipment once considered only for ALS care is now being carried on some BLS ambulances(e.g., defibrillators, vascular access adjuncts, and airway adjuncts).

VEHICLES
The vehicles may be ground ambulances, helicopters, fixed­wing aircraft, or a variety of first­response vehicles (fire engines, police cruisers, or sport utility vehicles). The most common vehicle used is the ground ambulance, categorized into three common varieties:

Type I: A standard truck (e.g., pick­up) chassis with a separate modular box to carry personnel, patient, and equipment
Type II: An enlarged van­type vehicle
Type III: A van chassis with an integrated modular box on the back for medical care and equipment

In types II and III, there is physical access between the driver’s and patient care compartments, as opposed to type I, in which these spaces are separate.

Ground vehicles typically have warning devices (lights and siren) as part of their equipment. Unwarranted use of red lights and sirens is dangerous for
2,3 the EMS crew, the patient onboard (if present), and the general public on the streets. Protocols or guidelines to limit the use of these devices only to times when they are medically indicated are important.

COMMUNICATIONS
The two­way radio is an important piece of equipment carried by prehospital providers. As the arena of wireless communication changes, EMS systems will need to adapt their communications system to best fit their needs. The spectrum of frequencies available for emergency services is limited and shared with other industries that require wireless communications. In the United States, EMS services may use specific frequencies (channels) in the very­high­frequency (around 170 MHz), ultra­high­frequency (around 460 MHz), and public safety (around 800 MHz) bands. In an attempt to create more channels for users, the Federal Communications Commission (FCC) has decreased channel spacing from 25 to 12.5 kHz, and there is an FCC mandate to continue spacing down to 6.25 kHz. Although newer radio equipment can be reprogrammed to allow for the change in channel spacing。

Historically, EMS systems in rural or suburban settings have had broad control over their communications systems; however, as they transport patients into urban settings and attempt to communicate with urban providers, the problems of compatible frequencies and channel congestion may develop.Trunked systems (typically used by urban EMS systems) may be analog, very­high­frequency/ultra­high­frequency digital radio, or 800­MHz digital radio. An 800­MHz digital trunked system is popular because of the advantages of shared equipment between different providers (EMS, police, and fire), enhanced radio coverage, shared or lowered cost, and wide­area communications. The main disadvantage with all trunked systems is the cost necessary to upgrade the current system.

The First Responder Network Authority (FirstNet) was created under the Middle Class Tax Relief and Job Creation Act of 2012 as an independent authority within the United States. FirstNet is charged with establishing, operating, and maintaining an interoperable public safety broadband network. To do this, Congress allotted $7 billion and 20 MHz of radio spectrum to build the network. FirstNet requires each state to have a Radio AccessNetwork connecting to FirstNet’s network core. FirstNet is responsible for consulting with states, local communities, and tribal governments to develop the requirements for its Radio Access Network deployment plan. FirstNet is creating the first nationwide high­speed broadband network providing a single interoperable platform for law enforcement, firefighters, paramedics, and other public safety officials in every state, county, locality, and tribal area.

ELECTRONIC MEDICAL RECORD
Use of the prehospital electronic medical record has increased substantially over the past 10 years. As usage of these electronic systems increases, bio­
7­11 surveillance, research, and system quality assurance analysis have become easier because of better data access.

Large systems with enough resources often have their own software specifically written for that system. Smaller EMS systems often use off­the­shelf alternatives. Using one of the latter products may require either modification of a vendor’s product or modification of the EMS system workflow to make the software fully functional. Many states are in the process of generating or have already generated a common data set and are collecting statewide data, which are submitted to the state EMS agency.

One common difficulty with the prehospital electronic medical record is incompatibility with the hospital electronic medical record. This means that the ambulance record cannot be expeditiously transferred to the hospital database. Long­term solutions need to be devised to ensure that all of these record systems are compatible.

PERSONAL PROTECTIVE EQUIPMENT
Every EMS provider must be educated about the risks of occupational exposure and protected against exposure to blood and other body fluids from patients. Equipment such as masks, goggles, and gloves for routine use should be carried on every EMS vehicle. On occasion, gowns or sturdy gloves may be needed.

Exposure to hazardous material or biologic or chemical weapons of mass destruction requires more protective equipment. Minimum personal protective equipment for such exposure should include a high­efficiency particulate air filter mask that filters 99.97% of airborne particles 0.3 μm in diameter (or an acceptable alternative for the purpose, such as an M95 military gas mask), goggles, gloves, and protective clothing. Protective clothing should be nonabsorbent and puncture resistant (Figure 2­1).

FIGURE 2­1. 
Personal protective equipment: filtered (high­efficiency particulate air, M95, N95, or chemical­specific) mask, goggles, gloves, and protective clothing.
[From Professional Paramedic Association of Ottawa, http://www.ottawaparamedics.ca/special­ops/]

Some urban EMS providers wear soft body armor as a standard part of the uniform. Suburban and rural providers can be placed in situations that necessitate similar protection. With advances in soft­armor technology, there are now a variety of styles and levels of protection from which to choose.Although each service must consider such variables as comfort, heat, weight, and cost, for EMS providers, a combination of ballistic/stab protection is optimal.

EQUIPMENT FOR STABILIZATION, RESUSCITATION, AND TREATMENT
This section reviews defibrillators, ECGs, airway and ventilation adjuncts, vascular access devices, spinal immobilization, and extremity immobilization.

DEFIBRILLATORS
Defibrillators have been an essential part of prehospital care since Pantridge showed that defibrillation could be done in the field on the streets of Belfast in 1965. Because early defibrillation is the most important factor in surviving a cardiac arrest, defibrillators have become smaller, less costly devices that are more appropriate for the prehospital setting.

An increasing percentage of BLS services carry automated external defibrillators. These devices are shock advisory defibrillators. Automated external defibrillators analyze the patient’s rhythm by computer algorithm, determine if the rhythm meets defibrillation criteria, inform the operator that a shock is advised, charge the capacitor, and deliver a defibrillation when the operator pushes the appropriate button. Automated external defibrillators are designed only to shock ventricular fibrillation and very fast ventricular or supraventricular tachycardias (usually >180 beats/min). Automated external defibrillators have become so easy to use and are so effective that many health and medical organizations are promoting these devices for first responder public safety personnel and for public access defibrillation by laypersons.

Automated external defibrillators are basic and relatively inexpensive. They often do not have monitor screens that display the patient’s rhythm. This actually may be better because a rhythm on the screen may serve only to distract a non­ALS operator. The device should have recording capabilities so that the cardiac arrest can later be reviewed for medical oversight and quality assurance reasons. The medical director should be involved in choosing such devices, training in their use, establishing protocols for their use, and reviewing their use afterward for quality assurance.

Defibrillators used by ALS personnel are typically more sophisticated devices, usually with additional functions. Defibrillation is facilitated using hands­off combination monitoring/defibrillation adhesive pads rather than with handheld paddles. Pads give better contact with the skin and decrease skin resistance to allow for a higher success rate of rhythm conversion. It is also safer for the operator who does not have direct contact with the patient when the shock is delivered. The ALS defibrillator has a screen for interpreting rhythms and so is also used for ongoing monitoring of patients’ rhythms. It may be used for cardioversion of nonlethal rhythms or pacing bradyasystolic rhythms. Additional critical care patient monitoring can be incorporated into an ALS defibrillator, including noninvasive blood pressure, pulse oximetry, end­tidal partial pressure of carbon dioxide in intubated patients, and other physiologic parameters. ALS personnel can use these machines for closely monitoring very ill patients during emergent calls or interfacility transfers.

Modern defibrillators use biphasic waveforms for shock delivery (as opposed to the traditional monophasic waveform). Biphasic defibrillators defibrillate and cardiovert at lower energy levels and thus decrease myocardial injury.

Prehospital 12­lead ECGs have become increasingly important in the management of ST­segment elevation myocardial infarctions.Both BLS and ALS ambulance services can perform ECGs in the prehospital setting. Analysis of ECGs provided immediately by the electrocardiograph has demonstrated limited sensitivity for detecting ST­segment elevation myocardial infarction. However, sensitivity can be increased using serial prehospital ECGs, training paramedics to interpret ECGs, and providing computer­assisted interpretation or remote physician overread of the ECG. Irrespective of the method of interpretation, patients with a prehospital 12­lead ECG showing ST­segment elevation myocardial infarction arriving at a hospital with a dedicated percutaneous coronary intervention team in place have reduced door­to­balloon time and
30­33 reduced mortality when compared with similar patients arriving without a prehospital 12­lead ECG.

AIRWAY AND VENTILATION ADJUNCTS
In a patient with acute respiratory failure or arrest, these devices maintain a patent airway that otherwise would have to be maintained by the paramedic. In addition, some airway adjuncts aid in preventing complications of airway management, such as gastric distention or aspiration. See Chapter 28, “Noninvasive Airway Management and Supraglottic Airways,” and Chapter 29A, “Tracheal Intubation” and Chapter 29B, “Mechanical Ventilation,” for detailed discussions of these topics.

Oral and Nasal Airways
The simplest devices for airway management after manual airway maneuvers are the oropharyngeal and nasopharyngeal airways. These basic airway adjuncts usually are paired in the field with a simple bag­valve mask device for ventilation and will work quite well together. Ventilation with the bagvalve mask can be difficult for a single person to both attain a good seal with the mask and compress the bag to produce an adequate tidal volume for the patient. It is probably more effective (especially for first responder and ambulance personnel who do not perform the skill often) to make this a two­person task (one person to maintain the seal and one person to compress the bag to maintain tidal volume). Along with these adjuncts, effective portable suction devices are available to be carried to the patient’s side to help clear the airway.

Supraglottic Airways
More advanced airway devices are used if the patient appears to need more prolonged airway management or is at greater risk for aspiration. At the BLS level, these airways include, most commonly, the esophagotracheal Combitube® or King LTS­D® airway or the laryngeal mask airway(LMA®) (Table 2­1) . Each of these is used in conjunction with a bag­valve mask for ventilation. Supraglottic devices improve the airway seal to promote better ventilation than the bag­valve mask with the oral airway and seal the airway off with a balloon to reduce the risk of aspiration.Supraglottic airways may decrease hands­off time during resuscitation, but there is limited prehospital evidence to suggest that any advanced airway offers a neurologic survival benefit compared to simple bag­valve mask use. Previous in­hospital evaluations of supraglottic devices have reported safety and efficacy. Future prehospital evaluations of supraglottic devices will need to address benefit, harm, and neurologic outcomes.

TABLE 2­1
Comparison of Combitube®, LMA®, and King LTS­D®
Device Use Comments
Combitube® Adults Prevents/minimizes aspiration
Adolescents >48 in. tall or age >14 y If inadvertently placed in trachea, will still ventilate
Cannot use if gag reflex present
Sturdy balloon
LMA® Sizes for adults and children May not prevent aspiration
Can cause respiratory obstruction if incorrectly placed
Cannot use if gag reflex present
King LTS­D® Sizes for adults and children Prevents/minimizes aspiration
If inadvertently placed in trachea, will still ventilate
Cannot use if gag reflex present
Sturdy balloon
Port for gastric decompression tube
Abbreviation: LMA® = laryngeal mask airway.

Although supraglottic devices are available for the pediatric population, a review of pediatric alternative airway devices used in prehospital care demonstrates the problems encountered in the field with airway management of children. No clear benefit exists for endotracheal intubation over simple bag­valve mask, and evidence of benefit for prehospital supraglottic device use is very limited.

Endotracheal Intubation
Endotracheal intubation is the “gold standard” for airway management in all patients and is especially useful in patients in whom the other airway
28 adjuncts are not satisfactory. The majority of ALS systems use endotracheal intubation as the airway of choice for patients in respiratory failure or with an unprotected airway. Numerous adjuncts to assist with endotracheal intubation can be found in the ED as well as the prehospital setting.However, provider procedural experience is a primary determinant for successful placement. For further discussion, see Chapter 29A, “Tracheal Intubation” and Chapter 29B, “Mechanical Ventilation.”

The basic emergency medical technician curriculum has an optional module for endotracheal intubation training. Therefore, intubation equipment may be found on some BLS ambulances. Increasing the number of ambulance personnel in need of endotracheal intubation training in an EMS system may cause logistic problems for the medical director. It is sometimes difficult to obtain adequate live intubation opportunities for the personnel in an EMS system to maintain skills. Some studies have shown that basic emergency medical technicians do not maintain endotracheal intubation skills and have low rates of successful completion. This might suggest that intubation should remain an ALS skill.

Rapid­Sequence Intubation
Another intubation­related modality that has bearing on the equipment carried on an ambulance is rapid­sequence intubation. Critical care transport services have been performing rapid­sequence intubation for more than a decade, and now this same level of care is provided in ALS systems as well. Rapid­sequence intubation raises the level of training, judgment, and psychomotor skills needed by the paramedic, but has the advantage of being able to secure more difficult airways. In addition to the usual equipment required for intubation, rapid­sequence intubation requires ALS services to carry the medications needed for sedation and paralysis. The technique increases the need for oversight and vigilance by the medical director. Numerous large EMS systems have all indicated difficulties with ALS prehospital intubation, with or without the assistance of neuromuscular junction blockade or sedation. Intubation, especially rapid­sequence intubation, is a training­intensive modality. Large systems with many paramedics may have difficulties with training type and intensity. Smaller services, such as air medical services, which have a smaller group to train, a smaller span of medical control, and more intubation experience per provider, may be able to attain and maintain the complex skills needed for rapid­sequence intubation.

CONTINUOUS POSITIVE AIRWAY PRESSURE AND BILEVEL POSITIVE AIRWAY PRESSURE
Continuous positive airway pressure maintains a continuous level of positive airway pressure throughout the respiratory cycle. Similarly, bilevel positive airway pressure delivers continuous positive airway pressure in a preset or measured inspiratory positive airway pressure phase and expiratory positive airway pressure phase. BLS and ALS services become competent in the use of this adjunct with additional training and a broadened understanding of respiratory physiology. Use of either modality in the ED and prehospital setting is lifesaving and cost­effective in the treatment of the severely dyspneic patient.

VASCULAR ACCESS EQUIPMENT
The equipment used to establish IV access is the same as at hospital: tourniquets, cleaning agent, IV catheters, IV fluid bags, and IV tubing. ALS ambulances need IV access for fluid resuscitation and for administration of medications. In general, vascular access for medication administration is completed as soon as possible after the patient is assessed and it is determined that pharmacologic intervention is needed. For fluid resuscitation, usually in trauma patients, vascular access usually is started en route to the hospital after the patient is immobilized, unless there is prolonged scene time due to extrication. This is to avoid prolonged scene times that may be detrimental to a trauma patient who may need intervention in the operating room. In any event, the amount of fluid that can be administered during transport is modest and may not be physiologically significant. Some data show that aggressive fluid resuscitation of hypovolemic trauma patients is detrimental, in that it may increase morbidity and mortality by enhancing exsanguination from vascular or organ injury requiring operative intervention. The difference between hospital and EMS usage of IV equipment is that the medical director must provide guidelines for when and how to institute vascular access to allow appropriate interventions at the appropriate time. Use of vascular access should be examined in the quality assurance process in an ongoing manner.

IO access devices are important adjuncts for rapid vascular access in the critically ill patient. Multiple recent works document the ability of ALS providers to quickly establish functional IO access. Guidance is provided in a position paper from the National Association of EMS Physicians (http://www.naemsp.org).

PREHOSPITAL ULTRASOUND
US is an important diagnostic tool in the practice of emergency medicine. New diagnostic applications for bedside US in the ED are reported in emergency medicine literature almost monthly. Moving US into the prehospital setting would seem like a logical next step. Multiple investigations demonstrate the feasibility of prehospital US in the United States and Europe. Some prospective observational data on prehospital US in EMS systems is available.

SPINAL IMMOBILIZATION
Preservation of the integrity of the spinal column and spinal cord is of paramount importance in the prehospital setting. The first person to assess the patient should immobilize the cervical spine immediately and, if necessary, simultaneously perform a modified jaw thrust to open the airway. Manual stabilization of the neck is not released until the patient has been transferred and securely strapped to a board. Short or long boards, either alone or in combination, are used to immobilize the spine depending on the initial position in which the patient is found by the emergency medical technician or first responder.

Carrying boarded patients takes a physical toll on emergency medical technicians and paramedics. Evaluation of the boarded patient is more expensive and time consuming in the ED because of the need to clear the cervical spine. A reasonable approach is for the medical director to develop protocols and guidelines for clearance of the spine in the field. A patient with no neck pain, tenderness, or discomfort (neck pain must be defined liberally and include stiffness or “feels funny”); not in the extremes of age (<10 years or >65 years); with no altered sensorium (no drugs or alcohol present, no head injury); and with no distracting injuries (long­bone fracture, abdominal or chest injury) may be cleared in the field because there is an extraordinarily low probability of neck injury (Table 2­2).

TABLE 2­2
Guidelines for Cervical Spine Clearance in the Field
Absence of neck pain, tenderness, or discomfort
Age between 11 and 65 y
No altered sensorium
No intoxication
No distracting injuries

Source: Data from Tatum JM, et al. Validation of a field spinal motion restriction protocol in a level I trauma center. J Surg Res, 2017. 211: p. 223­227. 

SPINAL BOARDS AND CERVICAL COLLARS
Long or short spinal boards are made from plastic or wood and provide a rigid surface to minimize movement of the cervical, thoracic, or lumbar spine. Straps secure the patient to the board for transport. Some boards are provided with firm rubber blocks on either side of the head with straps to go across the blocks to keep the head steady. Blanket rolls or sandbags secured to the board with tape are also effective head blocks. A popular and effective variation of the short board is the Kendrick Extrication Device® (KED®) (Figure 2­2), which consists of slats of rigid material bound together by heavy cloth.

FIGURE 2­2. 
Kendrick Extrication Device® (KED®) (Armstrong Medical Industries, Lincolnshire, IL). [Reproduced with permission from Armstrong Medical Industries,
Inc.]

This board immobilizes the cervical spine, wraps partly around the patient, and is then strapped the rest of the way around the thorax and around the thighs for secure immobilization. If necessary, the patient can be lifted by the straps, allowing for easier and safer upward extrication from the vehicle.

Rigid cervical collars are more accurately called cervical extrication devices. Multiple types are used in the field, such as the Philadelphia® collar, the
Miami J® collar (Figure 2­3), the Stifneck® (Laerdal Medical, Wappingers Falls, NY), and the Nec Loc® (Junkin Safety Appliance Co., Louisville, KY).

FIGURE 2­3. M
iami J® collar. [Reproduced with permission from Ossur Americas, Foot Hill Ranch, CO.]

The collars come in two asymmetric pieces, which are used and marked for back and front, or as a single piece that is folded into the correct shape. By themselves, collars are not adequate for cervical immobilization but require additional lateral support to avoid movement in that direction. For adequate immobilization, the patient needs to be strapped on the backboard and secured with head blocks and head straps. Once the patient is well secured to the board, the collar does not add a significant amount of stabilization and actually can be removed without compromise of the spine; however, it is often left in place for added protection. Patients with mandible or soft tissue neck injuries probably should not have a collar applied because of the potential for airway compromise, which could be masked by the collar. Newer collars have openings in the front to allow observation of the trachea and jugular veins, but this may not be adequate for observing other neck areas. Soft cervical collars are not adequate or appropriate for prehospital care.

SEQUENCE OF SPINAL IMMOBILIZATION
Prehospital personnel are taught to have a high index of suspicion for spine trauma. If the patient is sitting in a car after an accident and is stable from respiratory and circulatory standpoints, a short spine board and rigid cervical collar or Kendrick Extrication Device® are first used to get the patient out of the vehicle safely and onto a long spine board. If the situation at hand is a critical one because of the patient’s condition or the threat of hazards, such as chemicals, fire, or water, the patient can be extricated more rapidly using only the cervical collar.After applying the cervical collar, the patient is carefully rotated out and slid onto the waiting long board.

At a noncritical scene, when the patient is still sitting in the vehicle, one emergency medical technician secures the neck with his or her hands and applies the necessary airway maneuvers, while the second emergency medical technician applies the rigid cervical collar. The short board is then slid in behind the patient, and the patient is strapped to the short spine board. (Short boards are not used if the patient is not seated in a vehicle.) The first emergency medical technician maintains manual stabilization of the neck until the patient is secured to the short board. The patient’s head and trunk can then be rotated around as one unit and slid directly onto the long board positioned on the car seat or on the ambulance cot. The patient is then strapped to the long board and then to the cot. A properly boarded patient can be turned on the board or even stood on end if necessary to move the patient to the ambulance. If the patient vomits, for instance, the board can be partly log­rolled up to prevent aspiration.

Because of the difference in relative size and positions of head and body, adults and children need slightly different positioning on a backboard. A n adult needs more padding under the head, whereas a child needs more padding under the body to maintain neutral neck position.

If a patient is walking at the scene when the paramedical personnel arrive but complains of neck pain, the patient can be boarded from a standing position. If the patient is lying on the ground when the emergency medical technicians arrive, the patient can be carefully log­rolled by several attendants onto a long backboard. Immobilization on a rigid board produces midline cervical pain and tenderness, so examination and radiographs should be performed promptly on arrival. Radiographs can be done without difficulty through short and long boards. In general, patients should not be removed from immobilization until the spine has been cleared clinically and radiographically. Transfer from the hard prehospital board to a padded board at the hospital is desirable if the patient may spend prolonged time immobilized.

FOOTBALL HELMET REMOVAL
The National Athletic Trainers’ Association and the Inter­Association Task Force for the Appropriate Care of the Spine­Injured Athlete developed guidelines for the prehospital care of athletes with potential spine injury. These guidelines had recommended that the face mask of a football helmet be removed at the earliest opportunity, before transportation and regardless of respiratory status. However, because a properly fitted football helmet with shoulder pads holds the head in a position of neutral spinal alignment, field removal of these devices is no longer recommended by these guidelines, a tenet held in many EMS systems. It is recommended that the helmet and shoulder pads remain on as the athlete is immobilized and transported on a rigid backboard. Simultaneous removal of the helmet and shoulder pads should be done after clinical assessment and radiographs at the hospital, although radiographs may have to be repeated after equipment removal.

Removal of football shoulder pads and helmet requires several individuals to maintain spinal alignment (Figure 2­4). One individual stands at the head of the bed to stabilize the patient’s head, neck, and helmet, while others stabilize the spine and body. All straps and laces that secure the pads to the torso and arms are cut, not unbuckled or unsnapped. The laces or straps over the sternum are cut, allowing the right and left anterior portions to be spread open, exposing the chest. The posterior portion of the shoulder pads is kept in place to maintain spinal alignment with the helmet. Another individual cuts the chin strap from below while standing beside the patient’s chest. Accessible internal padding should be removed from inside the helmet and any air bladders deflated. The individual standing alongside the patient’s chest then reaches up into the helmet to stabilize the head by placing a hand with fingers and thumbs spread alongside the jaw, mastoid region, and occiput. (See Video: Football Helmet Removal.)

FIGURE 2­4. 
Helmet removal technique. [Reproduced with permission from American College of Surgeons, Committee on Trauma Brochure, April 1997.]
Video 2­1: Football Helmet Removal.

Used with permission from Dean Crowell and Meredith Petschauer, Department of Exercise and Sport Science, University of North Carolina; Judith E. Tintinalli

Two additional individuals stand alongside the patient’s chest and place their hands directly on the skin in the thoracic region. On command, the patient is lifted slightly, with all four individuals maintaining spinal alignment. The individual standing at the head of the bed can remove the helmet by a slight forward rotation to slide it off the occiput. Slight traction or anteroposterior motion may be necessary, but care should be taken not to move the head and neck unit. Attempting to assist removal by pulling on the ear holes tightens the helmet in the forehead and occipital regions and does not help. The posterior portion of the shoulder pads is removed, and the patient is lowered. A rigid cervical collar can then be placed.

TRACTION SPLINTS
Pelvic fractures and lower extremity fractures are potentially life and limb threatening. Fractures of the femur can damage vessels and nerves when bony fragments move. Stabilization in the field is important to minimize blood loss and soft tissue damage. The femoral traction splint is the preferred device for femur fractures.
Several leg traction splint variations are available for use. The two most commonly used types are the Hare® splint (Dynamed, Westbury, Tasmania) and the Sager® splint (Minto Research and Development, Inc., Redding, CA). The underlying technique is the application of traction by a hitch on the ankle against resistance when the splint impinges proximally on the pelvis. The padded proximal end of the Hare® splint abuts the ischial tuberosity (Figure 2­5). The proximal end of the Sager® splint rests against the pubic symphysis (Figure 2­6). These splints cannot be used if a pelvic fracture is suspected because the pressure on the pelvis may further displace a fracture and cause more bleeding. Also, do not apply a traction splint if there is open fracture, hip dislocation, suspicion for neurovascular injury to the extremity, or injury about the knee, because a traction splint may exacerbate neurovascular or knee injury. (See Video: Hare Traction Splint.)

FIGURE 2­5. Hare® traction splint. (Courtesy of Jan Smith, RN, MPH, NREMT­P; acknowledgments to Kara Smith and Lucky Bruton, EMT­P.)

Video 2­2: Hare Traction Splint.
Used with permission from Robert Bednar and Jerry Barlow, Carolina Air Care, UNC Hospitals; Judith E. Tintinalli.

FIGURE 2­6. Sager Emergency Traction Splint; Model S304, Form III Bilateral, Application step 3 “Secure.” [Used with permission from: Minto Research &
Development, Inc., Redding, CA.]

Leg traction splints also may be used for tibial shaft fractures. Traction splints should not be used for fractures near the knee because longitudinal traction may damage neurovascular structures in the popliteal region. Traction splints for the tibia should be reserved for angulated or displaced fractures; otherwise, an air splint or a pillow splint would suffice.

At the scene, clothing should be removed and the extremity assessed for injury and distal neurovascular function. If the Hare® splint is used, the proximal half ring is placed in the crease of the buttocks against the ischial tuberosity. Traction is placed on the ankle with the padded ankle strap by one rescuer while the splint is strapped to the leg. The ankle strap is then attached to a ratcheting mechanism, and traction is tightened. If a Sager® splint is used, the splint is placed on the medial side of the limb up against the groin. The padded ankle hitch is applied, and traction is applied until malalignment is reduced and pain is relieved. Elastic straps are then applied to hold the splint to the leg.

The Hare® splint can be longer than an ambulance cot when fully extended, and care needs to be taken when closing the rear door of the ambulance.
The Sager® splint is shorter than the Hare® splint, and one Sager® splint can be used to splint both legs simultaneously. The Sager® splint is less bulky and therefore takes up less room in an ambulance or a helicopter.

PELVIC STABILIZERS

Unstable pelvic fractures can be immobilized to minimize the risk of bleeding from patient movement and during transport. A sheet wrap, applied around the patient at the level of the trochanter and fastened with a clamp or hemostat, is the simplest stabilization method. Commercial devices, such as the SAM Pelvic Sling®, are also available.

PHARMACEUTICAL SUPPLIES
The basic emergency medical technician curriculum has modules that teach emergency medical technicians to administer a patient’s personal medication in specific circumstances. For example, modules are provided for administering nitroglycerin for chest pain, inhaled β­agonists for bronchospasm, glucagon for hypoglycemia, and epinephrine­preloaded injections for anaphylaxis. Some states have gone beyond this and allow BLS services to stock and provide the medications covered in these modules.

The medications carried by ALS services are more extensive, but prehospital pharmaceutical interventions are limited to the few that make a real difference before or during transport. These include oxygen, glucose, nitroglycerin, inhaled β­agonists, naloxone, parenteral narcotic and nonsteroidal analgesics, benzodiazepines, furosemide, epinephrine, lidocaine, magnesium, amiodarone, adenosine, diltiazem, calcium, and sodium bicarbonate. In the system that provides rapid­sequence intubation, neuromuscular junction–blocking agents (succinylcholine, vecuronium) are also provided.


