## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 40: Wound Preparation
Adam J. Singer; Judd E. Hollander
INTRODUCTION
All traumatic lacerations are contaminated to some degree; however, the level of contamination differs based on etiology, wound location, and time of injury. Wound preparation includes all of the steps required prior to wound closure (either by primary or secondary intention) aimed at reducing the risk of infection, optimizing cosmetic outcome, and minimizing patient pain and discomfort. For most wounds, adequate preparation requires some form of anesthesia, be it topical, local, or regional. For other patients (especially young children or the mentally disabled), anxiolysis using oral or intranasal midazolam or ketamine may be required. When patient cooperation is problematic and absolute immobilization is required (e.g., when repairing a laceration near the eye or in the mouth), procedural sedation or even general anesthesia should be considered.
Although the order of procedures may vary, in general, wound preparation starts with decontamination of the skin surrounding the laceration, followed by local anesthesia through the wound edges. After achieving adequate wound anesthesia, the wound is reexamined. When necessary, sharp debridement of obviously devitalized or heavily contaminated tissue should be performed. Finally, wound cleansing (e.g., scrubbing or irrigation) should be used to remove any remaining debris and bacteria. After excluding the presence of embedded foreign bodies and underlying tissue damage
(e.g., tendon injuries), the wound is repaired. With heavily contaminated wounds, irrigation with soap and water under running tap water may precede local anesthesia when tolerated by patients. Early application of a topical anesthetic may make this procedure less uncomfortable.
STERILE TECHNIQUE
Although routinely practiced in other settings (e.g., the operating room), full sterile technique (mask, cap, gown, and gloves) apparently does not
 reduce wound infection rates after laceration repair in the ED setting. Use of sterile gloves for laceration repair or outpatient surgical procedures does
 not reduce infection rates compared to clean, nonsterile gloves. Hand washing prior to patient contact is a tenet of infection control, but there is no
 firm evidence that one form of hand antisepsis is better than another for reducing postprocedure wound infections. Nonetheless, gloves protect the provider and should routinely be used, even if not sterile. Common sense suggests that masks should be used during wound preparation and closure when the practitioner has a respiratory infection or is otherwise potentially contagious.
SKIN DISINFECTION
Due to the presence of abundant normal microbial flora, skin disinfection is generally the first step in wound preparation. There is no evidence to
 support the historic practice of skin disinfection prior to ED laceration closure using povidone­iodine. Chlorhexidine is likely a better agent, as noted in a meta­analysis of  randomized controlled trials involving 6997 patients undergoing clean or clean­contaminated surgeries; preoperative
 chlorhexidine antisepsis was associated with a lower incidence of surgical site infections (relative risk, .70; 95% confidence interval, .60 to .83).
Regardless of which agent is used, avoid contact of the antiseptic agent with the wound or the eyes. The antiseptic should also be allowed to dry for  to  minutes for maximal efficacy.
WOUND ANESTHESIA
Most lacerations will require some form of anesthesia to allow meticulous examination, irrigation, debridement, and repair. Short lacerations requiring few if any sutures or staples may sometimes be managed without injection of a local anesthetic, especially when topical anesthetics are applied. Shared decision making between the practitioner and patient in these cases is encouraged. The specific choice of anesthetic and route of administration (local or regional) is determined by wound size, location, and patient condition (see Chapter , “Local and Regional Anesthesia”).
Importantly, a detailed sensory examination should be performed and documented prior to administration of any anesthetic. Consider the use of
 aCnhxaiopltyesri s4,0 p: rWocoeudnudra Pl rseepdaartaiotino n(s, eAed Cahma pJt.e Sr i3n7g, e“rP; rJoucdedd uEr.a Hl Soelldaantdioenr and Analgesia in Adults,” or Chapter 115, “Pain Management and ProPceadguer 1a l/ 
S©e2d0a2t5io Mn cinG Irnafwan Htsi lal.n Adl lC Rhiigldhrtesn R”e),s oerr evveedn. g Teneremrasl aonf Uessteh e * sPiar iivna ncoy nPcooloicpye * r aNtiovteic pea * t ieAnctcse (ses.gib.,i liintyfants, mentally disabled) and in sensitive or cosmetically important areas (e.g., mouth, eyes).
HAIR REMOVAL

Hair removal prior to wound repair does not reduce the incidence of infection and is not necessary before wound repair. However, removal of the hair may facilitate wound evaluation and closure, especially with long hair. If hair is to be removed, trim with scissors or clip away with a disposable hair clipper. Avoid shaving of hair since it injures the hair follicles, allowing dissemination of bacteria, and increases the risk of wound infection. The hair can also be matted down with an antiseptic solution or petrolatum­based ointment to prevent it from entering the wound. The presence of hair on either side of a wound may also serve as a landmark for meticulous approximation of the wound edges. Do not trim eyebrows since they may not grow
 back or grow back in an abnormal pattern. Scalp hair from both sides of the wound may also sometimes be used to close a scalp laceration. This method of closure also improves patient satisfaction and cosmetic outcome.
CONTROL OF BLEEDING
In addition to reducing blood loss, control of bleeding is necessary for optimal visualization of the wound. In most cases the bleeding can be controlled with local pressure with a gloved finger.
Physical means of applying pressure to bleeding include the use of gelatin, cellulose, or collagen sponges placed directly into the wound.
Denatured gelatin (Gelfoam®; Pfizer, Inc., New York, NY) has no intrinsic hemostatic properties and works by the pressure it exerts as it expands. A cellulose derivative (Oxycel®; Becton Dickinson Infusion Therapy Systems, Inc., Sandy, UT) or a collagen (Actifoam®; MedChem Products, Inc., Woburn,
MA) sponge reacts with blood, forming an artificial clot. These products are not particularly effective for actively bleeding wounds, as the blood flowing into the wound can wash them out.
Topical application of hemostatic agents is another approach to wound hemostasis. Kaolin, which initiates the closing process by activating factor XII of the coagulation cascade, is commercially available impregnated in polyester/rayon gauze pads and rolls (QuickClot®; Z­Medica, Wallingford, CT).

Compressed directly onto a bleeding wound, these pads achieve hemostasis typically in  minutes in clinical studies. Topical tranexamic acid can be applied directly to a bleeding wound by saturating a gauze pad with the liquid tranexamic acid (5 to  mL of the 100 milligrams/mL solution), or it
 can be applied as a powder (created by crushing tranexamic acid tablets) or a paste (created by mixing about 2000 milligrams of crushed tranexamic
 acid tablets with  mL of sterile water). For wound hemostasis, material is left on for  to  minutes; the paste, powder, or gauze is then removed so wound closure can proceed. Although widely used, tranexamic acid is not U.S. Food and Drug Administration approved for this indication.
A proximal tourniquet may be used as a temporizing measure when excessive bleeding is not controlled with pressure. Finger tourniquets using a rubber Penrose drain may be used when exploring and repairing finger lacerations (Figure 40­1). However, they should not be left on for more than
 minutes.
FIGURE 40­1. Construction of a finger tourniquet using a rubber Penrose drain.
When relevant, elevate the injured extremity. Infiltration of a local anesthetic containing epinephrine (in a concentration of 1:100,000 or 1:200,000) or the direct application of epinephrine (either as a single solution or as part of a topical anesthetic combination such as lidocaine­epinephrine­
 tetracaine) may also help control bleeding by inducing vasoconstriction.
Continued bleeding from the wound edges is best managed with sutures. Either a horizontal mattress suture or a figure­of­eight suture (Figure 40­2, left) may be required when simple interrupted sutures do not control the bleeding. Because tying the knot in a figure­of­eight suture will shorten the laceration line, opening it in the center, it should only be used in short lacerations (approximately  cm). For longer lacerations, after tying the first knot of a traditional stitch, continue with an over­and­over continuous suture. If after pulling on the suture there is still bleeding, the direction of the suturing should be reversed with cross­stitching backward over the previous stiches (Figure 40­2, right). Larger blood vessels may be tied off with an absorbable suture. If major arterial bleeding is identified or suspected, consult with a specialist.
FIGURE 40­2. “Figure of 8” stitch, used for hemostasis on short lacerations (1). For longer lacerations (2), we suggest that after tying the first knot (A) continue with an over­and­over continuous suture (B). If after pulling on it the bleeding does not stop, continue with cross stitching backward over the previous stitches (C), tying it to the free end of the first knot.
Special clips (Raney) are available to rapidly control bleeding from scalp lacerations prior to definitive repair. Alternatively, metal binder clips can used
 to control bleeding from the wound edges. In scalp lacerations, the sutures should include the underlying galea aponeurotica, since most bleeding vessels are within this layer. Large strong needles are best for this purpose.
WOUND IRRIGATION
Cleansing of traumatic wounds is considered an essential component of wound preparation. Irrigation is especially useful in heavily contaminated
 wounds. It removes not only bacteria but also particles (such as soil) that increase the susceptibility to infection. High­pressure irrigation (generally defined as pressures greater than  pounds per square inch or  kPa) is more effective at removing bacteria and debris than low­pressure irrigation.
However, high­pressure irrigation has the potential to cause further tissue trauma and distortion of the tissues, complicating meticulous wound
 closure, and exposes the provider to bloodborne splatter. Thus, high­pressure irrigation should be limited to heavily contaminated wounds. Do not use high pressure when irrigating areas with loose areolar tissue such as the eyelids. A retrospective ED study of approximately 2000 patients did not
 find an association between high­pressure irrigation and wound infection in patients with facial and scalp lacerations. Furthermore, a recent multicenter randomized controlled trial of nearly 2500 patients showed no benefit of pulsed high­pressure irrigation (8 to  pounds per square inch)
 over continuous irrigation using gravity alone in open fractures. High­pressure irrigation can most easily be achieved using a large syringe (30 to 
 mL) and splatter guard (Figure 40­3). Although the exact volume of irrigation is not clear, we suggest  to 100 mL/cm for contaminated wounds.

Irrigation using tap water directly from the faucet achieves both high volume and high pressure. Tap water is as effective as normal saline in reducing
 wound infection in both children and adults with traumatic lacerations.
FIGURE 40­3. Syringe and splatter guard set up for wound irrigation.
WOUND DEBRIDEMENT
,21
The presence of devitalized, nonviable tissue increases the risk of wound infection and poor cosmesis. Therefore, remove any nonviable tissue
 and any imbedded gross contaminants or foreign bodies. Debridement can reduce the bacterial burden in traumatic wounds. Debridement is performed using a surgical blade or fine scissors. In areas of cosmetic importance or where excess surrounding tissue is unavailable, take extreme care to limit debridement and consider specialty consultation (e.g., plastic surgery). Simple debridement of contused wound edges (also referred as refreshing the wound margins) is generally performed. Undermining of the wound may facilitate wound closure, especially if it is under tension. For wounds that cross the relaxed skin tension lines (also known as the lines of minimal tension) at an angle greater than  degrees, more complex W­
 plasty can improve cosmetic outcome. With this method, continuous W shapes are traced and later incised on both sides of the wound (Figure 40­
4). This creates multiple triangular flaps with lengths of  to  mm and angles of  to  degrees, which are then sutured together after undermining the wound edges (Figure 40­5).
FIGURE 40­4. A case of a 51­year­old male with laceration of the right infraorbital margin to lateral margin of nasal ala. Angle to the relaxed skin tension line is nearly
 to  degrees. The patient underwent W­plasty. A. Initial crush wound on face. B. W­shaped incision along the design line. C. State at  days after suture removal. D. State at  months after suture removal.
FIGURE 40­5. Laceration debridement using W­plasty. The basic technique is the same as that of W­plasty for scar revision. W­shaped patterns are sketched on either side of the intact skin surface close to the wound site (A), and a number of triangular flaps are prepared with a length of  to  mm (normally .5 mm) (B). The angle between the two lines should be drawn at  to  degrees (normally  degrees). [Reproduced with permission from Min JH, Park
KH, Choi HL, Park JS, Lee JH, Kim H, Lee BK, Lee DH, Lee TG (eds). Usefulness of direct W­plasty application to wound debridement for minimizing scar formation in the emergency department. Am J Emerg Med 2017 Dec;35(12):1804­1809. Copyright Elsevier.]
REMOVAL OF FOREIGN BODIES
Foreign bodies significantly increase the risk of wound infection and may also injure surrounding structures such as neurovascular bundles and tendons. Therefore, try to remove most foreign bodies at the time of wound exploration. Suspect the presence of foreign bodies with all injuries involving glass, especially in puncture wounds and after motor vehicle collisions. The sensation of a foreign body by the patient is reasonably specific for the actual presence of a foreign body and should be investigated. Point tenderness and increased pain with motion are also suggestive. Avoid blind probing of the wound with a finger to prevent provider injury. Close visual inspection of the entire depth and course of the wound and probing with a blunt metal instrument help exclude foreign bodies. Plain radiographs are helpful at identifying radiopaque foreign bodies such as glass fragments.
,25
However, bedside US, CT, or MRI may be required with radiolucent foreign bodies such as wood and rubber.


