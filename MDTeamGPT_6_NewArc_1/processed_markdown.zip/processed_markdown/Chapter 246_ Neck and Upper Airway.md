## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 246: Neck and Upper Airway
Nicholas D. Hartman
INTRODUCTION
This chapter reviews infectious and noninfectious conditions that can obstruct the upper airway. These disorders must be recognized quickly because early airway management may be lifesaving. Neck trauma is discussed in Chapter 260, “Trauma to the Neck,” and angioedema is discussed in Chapter
, “Allergy and Anaphylaxis.” Management of upper airway and neck infections in children are discussed in Chapter 124, “Mouth and Throat Disorders in Infants and Children,” and Chapter 126, “Stridor and Drooling in Infants and Children.”
NECK AND UPPER AIRWAY INFECTIONS
PHARYNGITIS/TONSILLITIS
Viruses account for most cases of pharyngitis or tonsillitis. Acute viral pharyngitis is most commonly caused by rhinovirus but can be caused by other
 viral agents (Table 246­1).
TABLE 246­1
Microbial Causes of Acute Pharyngitis
Estimated % of
Pathogen Syndrome/Disease
Cases* Viral
Rhinovirus (100 types,  subtype) Common cold 15–20
Coronavirus (3+ types) Common cold >5
Adenovirus (types , , , , 21) Pharyngoconjunctival fever, acute respiratory  disease
Herpes simplex virus (type , 2) Gingivitis, stomatitis, pharyngitis 
Parainfluenza virus (types 1–4) Common cold, croup 
Influenza virus (types A, B) Influenza 
Respiratory syncytial virus Bronchiolitis, pharyngitis 1–2
Coxsackievirus A (types , , , , , 10) Herpangina <1
Epstein­Barr virus Infectious mononucleosis <1
Cytomegalovirus Infectious mononucleosis <1

Chapter 246: Neck and Upper Airway, Nicholas D. Hartman 
Human immunodeficiency virus type  Acute retroviral syndrome <1
. Terms of Use * Privacy Policy * Notice * Accessibility
Bacterial
Streptococcus pyogenes (GABHS) Pharyngitis, tonsillitis, scarlet fever 10–23
Fusobacterium necrophorum Pharyngitis, tonsillitis, Lemierre’s syndrome 5–10
Streptococcus dysgalactiae subspecies equisimilis (formerly group C β­ Pharyngitis, tonsillitis 3–6 hemolytic streptococci)
Neisseria gonorrhoeae Pharyngitis <1
Corynebacterium diphtheriae Diphtheria <1
Arcanobacterium haemolyticum Pharyngitis <1
Chlamydial
Chlamydia pneumoniae Pneumonia, bronchitis, pharyngitis <1
Mycoplasmal
Mycoplasma pneumonia Pneumonia, bronchitis, pharyngitis <1
Abbreviation: GABHS = group A β­hemolytic Streptococcus.
*Estimates of percentage of all cases of pharyngitis due to the indicated organism.
VIRAL PHARYNGITIS

Features traditionally associated with viral pharyngitis include a vesicular or petechial pattern on the soft palate and tonsils, cough, and rhinorrhea. It remains difficult, however, to determine the causative agent based on clinical features alone. For example, in patients with nonstreptococcal
 pharyngitis (mostly viral), 16% have tonsillar exudate, 55% have cervical adenopathy, and 64% lack cough. Most cases of viral pharyngitis require no specific diagnostic testing. There are three notable exceptions where testing may be indicated: suspected influenza, infectious mononucleosis, or acute retroviral syndrome. See Centers for Disease Control and Prevention influenza website for testing and treatment recommendations (http://www.cdc.gov/flu/). Infectious mononucleosis, influenza, herpesvirus, and cytomegalovirus infections are discussed in
Chapter 154, “Serious Viral Infections.” The acute retroviral syndrome of early human immunodeficiency virus infection can also mimic mononucleosis. See Chapter 155, “Human Immunodeficiency Virus Infections,” for recommendations on testing and treatment. Apart from the viral causes of pharyngitis discussed earlier, viral pharyngitis should be treated symptomatically with oral hydration, antipyretics, analgesics, and rest.
Patients unable to tolerate oral fluids or who become dehydrated should be given IV fluids.
BACTERIAL PHARYNGITIS
Group A β­Hemolytic Streptococcus (GABHS) Pharyngitis
Group A β­hemolytic Streptococcus, the Lancefield group A species of Streptococcus pyogenes, is traditionally thought to be responsible for 5% to

15% of pharyngitis in adults, although recent studies reveal figures as high as 23%. After an incubation period of  to  days, patients develop the sudden onset of sore throat, painful swallowing, chills, and fever. Headache, nausea, and vomiting are common. Signs and symptoms of group A β­ hemolytic Streptococcus pharyngitis include marked swelling of the tonsils and tonsillar pillars (found in 62% of cases); tonsillar exudate (39%); and
 enlarged, tender cervical lymph nodes (76%). A 2012 epidemiologic study in an urgent care environment, however, found that only 6% of patients with
 group A β­hemolytic Streptococcus were febrile (>101°F) and that 28% had cough. Patients may have uvular edema, myalgias, and malaise but are less likely to have rhinorrhea or conjunctivitis compared to patients with viral pharyngitis.
The original Centor criteria listed four clinical indicators of group A β­hemolytic Streptococcus pharyngitis: (1) tonsillar exudates, (2) tender anterior cervical adenopathy, (3) absence of cough, and (4) history of fever. Increasing Centor scores have been repeatedly shown to predict higher likelihood
 of GAS infection. The Centers for Disease Control and Prevention and Infectious Diseases Society of America recommend performing testing on
 5­7 patients who lack viral features. Rapid antigen diagnostic tests have an overall sensitivity of 86% and a specificity of 94% to 96%. The
 sensitivity of the test is the same in patients with and without features of viral pharyngitis.
Untreated, group A β­hemolytic Streptococcus infection lasts  to  days. Antibiotic therapy of group A β­hemolytic Streptococcus improves
 symptoms within  to  hours of initiation of therapy and prevents suppurative complications and rheumatic fever in most patients, but does not
 prevent glomerulonephritis. Group A β­hemolytic Streptococcus has never been resistant to penicillin, so penicillin remains the
,10 recommended first­line drug for group A β­hemolytic Streptococcus. Adults who test positive for group A Streptococcus should receive a single IM dose of benzathine penicillin G .2 million units, penicillin VK 500 milligrams twice daily for  days, or amoxicillin. A first­generation
  cephalosporin or clindamycin may be used for penicillin­allergic patients, although resistance to these agents has been reported. A single dose of
PO or IM dexamethasone in immunocompetent patients with moderate to severe pharyngitis decreases time to pain relief and to complete resolution
,13,14 of pain, without significant increase in side effects.
Other Causes of Bacterial Pharyngitis
Several other bacteria can cause pharyngitis, although these infections are less common (Table 246­1). Streptococcus dysgalactiae subspecies equisimilis, previously known as β­hemolytic groups C and G streptococci, is an important pathogen causing pharyngitis, skin infections, and more
 serious infections such as meningitis or toxic shock syndrome in the elderly or immunocompromised. S. dysgalactiae subspecies equisimilis frequently colonizes the upper respiratory tract (60% who are culture positive are asymptomatic); thus, treatment is recommended for patients with
  acute symptoms. These infections also appear to be clinically indistinguishable from group A Streptococcus infections. S. dysgalactiae subspecies
 ,17 equisimilis pharyngitis is almost uniformly susceptible to penicillin. Clindamycin and fluoroquinolones are alternatives.
Fusobacterium necrophorum, a gram­negative anaerobe, is the causative agent in Lemierre’s syndrome, a complication of pharyngitis causing
 suppurative thrombophlebitis of the internal jugular vein, with or without bacteremia and septic emboli. Suspect F. necrophorum in adolescents or
,19  young adults, particularly smokers, with worsening symptoms and neck swelling. F. necrophorum resistance to macrolides is high. Evaluation for
Lemierre’s syndrome should include contrasted CT of the neck, broad­spectrum antibiotics (metronidazole plus ceftriaxone, or piperacillin­
 tazobactam), and consideration for surgical drainage.
Gonococcal pharyngitis is usually associated with genital infection and is treated by the same antibiotics (see Chapter 153, “Sexually Transmitted
Infections”). Diphtheria is caused by Corynebacterium diphtheriae and is rare in well­immunized populations. It is characterized by a slow onset of mild to moderate pharyngeal discomfort and low­grade fever. On physical examination, a gray membrane is seen adherent to the tonsillar or pharyngeal surface and may extend to the uvula, soft palate, pharynx, and larynx. Treatment is with diphtheria antitoxin and metronidazole to prevent transmission to others.
Uvula edema, sometimes referred to as Quincke’s edema, can be associated with upper airway infections such as group A β­hemolytic
Streptococcus pharyngitis, peritonsillar abscess, or epiglottitis. It can also be idiopathic. If it is an isolated finding and symptoms are uncomfortable to the patient, dexamethasone can be given as a single dose in the ED.
PERITONSILLAR ABSCESS
A peritonsillar abscess is a collection of purulent material between the tonsillar capsule, the superior constrictor, and palatopharyngeus muscles. Risk
 factors include periodontal disease, smoking, chronic tonsillitis, multiple trials of antibiotics, and previous peritonsillar abscess. Peritonsillar
,22 abscess develops primarily in adolescents and young adults without seasonal variation as previously thought. Although peritonsillar abscesses are
,23 typically polymicrobial infections, in patients  to  years of age, F. necrophorum has been the most common organism in many communities.
CLINICAL FEATURES AND DIAGNOSIS
Patients with peritonsillar abscess (adolescents and adults) appear ill and present with sore throat (99%), fever (54%), malaise, odynophagia, and/or
 otalgia. Physical signs include inferior and medial displacement of the infected tonsil(s) (46%), contralateral deflection of the swollen uvula (43%),
 tender cervical lymphadenopathy (41%), trismus (32%), muffled voice (“hot potato voice”), palatal edema, and dehydration (Figure 246­1). The differential diagnosis of a peritonsillar abscess includes peritonsillar cellulitis, mononucleosis, lymphoma, herpes simplex tonsillitis, retropharyngeal abscess, neoplasm, and internal carotid artery aneurysm. In peritonsillar cellulitis, erythema and edema of the tonsillar pillar and soft palate are evident, but pus has not yet formed. Diagnosis of a peritonsillar abscess is often made by history and physical examination alone. If the diagnosis is in
 question, intraoral US has a sensitivity of 89% to 95% with a specificity of 79% to 100% for peritonsillar abscess. CT scan with contrast is indicated if
 there is concern for spread beyond the peritonsillar space or lateral neck space complications.
FIGURE 246­1. Right peritonsillar abscess (PTA) displacing right tonsil medially and the uvula toward the normal left tonsil. Abscess is between the right tonsil and the superior constrictor muscles.
TREATMENT
Treatment options include drainage of the abscess by needle aspiration, incision and drainage, or, rarely, immediate tonsillectomy. Choice of treatment depends on clinical symptoms, degree of patient cooperation, history of previous tonsil disease, and healthcare personnel experience. No definite difference in outcome has been found when comparing needle aspiration with incision and drainage, although some studies show less
,26 recurrence with incision and drainage. Abscess tonsillectomy (“quinsy tonsillectomy”) should only be considered when patients have strong
 indication for tonsillectomy, such as sleep apnea, recurrent tonsillitis, or recurrent peritonsillar abscess. Approximately 90% of patients will be
,27 treated effectively after a single needle aspiration.
Needle Aspiration
Needle aspiration can be performed by an emergency provider trained in the technique. First, apply anesthetic spray or gel to the overlying mucosa.
Then inject  to  mL of lidocaine with epinephrine into the mucosa of the anterior tonsillar pillar using a 25­gauge needle. The drainage needle should penetrate no more than  cm because the internal carotid artery usually lies laterally and posterior to the posterior edge of the tonsil. The plastic sheath of the needle can be cut  cm from its tip to serve as a guard. If the internal carotid artery lies more medial and anterior, it can usually be palpated in this area. Once adequate anesthesia is achieved, introduce an 18­gauge needle just lateral to the tonsil, approximately halfway between the base of the uvula and the maxillary alveolar ridge, until the abscess cavity is encountered and pus is aspirated. Multiple aspirations may be required to find the abscess. If not done previously, a contrast CT scan of the neck is recommended when the results of needle aspiration are negative and a parapharyngeal or retropharyngeal space process is suspected.
Pharmacotherapy and Follow­Up
Initial therapy should include a 10­day course of antimicrobials effective against group A Streptococcus and oral anaerobes (including F.
 ,28 necrophorum). Proven agents are penicillin VK plus metronidazole or clindamycin for penicillin­allergic patients. Toxic patients or patients unable to take medicine PO should receive piperacillin­tazobactam or similar agent. Single IV use of high­dose steroid (dexamethasone,  milligrams)
 in addition to antibiotics and drainage improves severity and duration of pain. Provide follow­up within  to  hours of aspiration, with instructions to return to the ED if worse. If the patient is not improving, consider repeating the aspiration, obtaining otolaryngologic consultation for
 incision and drainage or tonsillectomy, or obtaining a CT scan to reconsider the diagnosis. Complications of a peritonsillar abscess include airway obstruction, rupture of the abscess with aspiration of contents, hemorrhage secondary to erosion of carotid sheath, retropharyngeal abscess,
 mediastinitis, and poststreptococcal sequelae.
ADULT EPIGLOTTITIS (SUPRAGLOTTITIS)
Epiglottitis is an inflammatory condition, usually infectious, primarily of the epiglottis but often including the entire supraglottic region (also termed supraglottitis). It can lead to rapid airway obstruction. Prior to the introduction of a conjugate vaccine for Haemophilus influenzae type b in the 1980s, most cases of epiglottitis affected children age  to  years. In the postvaccine era, the dramatic decline in pediatric cases has confined the disease
31­34 primarily to adults, with estimates of mean age ranging from  to  years. Adult cases frequently result in no causative organism being identified,
32­34 but H. influenzae, Streptococcus and Staphylococcus species, anaerobes, viruses, and fungi can be implicated. Risk factors for mortality in
 patients with epiglottitis are advanced age and male sex.
CLINICAL FEATURES AND DIAGNOSIS
Symptoms are typically a 1­ to 2­day history of worsening sore throat, odynophagia, and dyspnea, particularly in the supine position. The clinical triad of the “three Ds” (drooling, dysphagia, and distress) is a classic but infrequent presentation. Other symptoms are fever, tachycardia, cervical adenopathy, and anterior neck tenderness with pain on gentle palpation of the larynx and upper trachea. Stridor is primarily inspiratory. Patients often position themselves sitting up, leaning forward, mouth open, head extended, and panting.
Diagnosis is clinical and confirmed by radiographs or transnasal fiberoptic laryngoscopy. Lateral cervical soft tissue radiographs demonstrate obliteration of the vallecula, swelling of the aryepiglottic folds, edema of the prevertebral and retropharyngeal soft tissues, and ballooning of the hypopharynx (Figure 246­2). The epiglottis appears enlarged and thumb­shaped, with epiglottis width >6.3 mm found to strongly suggest
  epiglottitis. Patients who have been taking antibiotics prior to imaging are at risk for false­negative radiographic imaging. Direct laryngoscopy examination can confirm the diagnosis in adults if necessary, but should be done carefully to avoid sudden, unpredictable airway obstruction.
Patients with worsening dyspnea in the supine position should not be sent to the CT scanner; CT of the neck is not needed to make the diagnosis.
FIGURE 246­2. Acute epiglottitis. Arrow points to thickened epiglottis resembling a thumbprint on a soft tissue lateral radiograph.
TREATMENT
Obtain immediate otolaryngologic consultation for suspected epiglottitis. Be prepared to establish a definitive airway. Patients should not be left unattended, and they should remain sitting up. Initial treatment consists of supplemental humidified oxygen, IV hydration, cardiac monitoring, pulse oximetry, and IV antibiotics. Humidification and hydration can help decrease the risk for sudden airway blockage. Steroids are often given to decrease airway inflammation and edema (methylprednisolone, 125 milligrams IV).
In adults, the need for intubation usually can be determined by transnasal fiberoptic examination of the supraglottis. Intubation is generally accomplished by “awake” fiberoptic intubation in the operating room, with preparations for immediate awake tracheostomy or cricothyrotomy. In cases of airway obstruction in the ED, be prepared for a very difficult intubation secondary to the swollen, distorted anatomy. In the case of intubation failure, the last resorts for preserving the airway are cricothyrotomy and needle cricothyrotomy.
Current antibiotic recommendations are second­ or third­generation cephalosporins or other β­lactamase–resistant antibiotic such as piperacillin­
 tazobactam. Respiratory fluoroquinolones are an option for patients with severe penicillin allergies.
RETROPHARYNGEAL ABSCESS
The retropharyngeal space is a potential space anterior to the prevertebral fascia that extends from the base of the skull to the tracheal bifurcation. In adults, a retropharyngeal abscess is usually due to intraoral procedures, trauma, foreign bodies such as a fishbone, immunocompromise, or extension
 from odontogenic infection. Cultures from retropharyngeal abscesses are usually polymicrobial: group A β­hemolytic streptococci, Staphylococcus aureus (including methicillin­resistant S. aureus), H. influenzae, and Bacteroides, Peptostreptococcus, and Fusobacterium species.
CLINICAL FEATURES AND DIAGNOSIS
The most common symptoms in adults are sore throat, dysphagia, neck pain, and less commonly, stridor. In addition, patients may also have complaints of cervical lymphadenopathy, poor oral intake, muffled voice, and respiratory distress. Visible neck swelling is not common.
A lateral soft tissue radiograph of the neck taken during inspiration with moderate cervical extension can demonstrate thickening and protrusion of
 the retropharyngeal wall, classically with  to  cm of prevertebral widening at the second cervical vertebra. However, contrast­enhanced CT scan of
 the neck is the test of choice for diagnosis of a retropharyngeal abscess. Early CT findings may reflect reactive, nonsuppurative edema, mild fat stranding with discernible tissue planes, linear fluid, minimal mass effect, and no associated enhancement. Necrotic nodes with central low attenuation and ring enhancement reflect an abscess (Figure 246­3). A patient with airway distress should not be sent unobserved for CT scanning.
FIGURE 246­3. Contrasted CT of a left retropharyngeal abscess (arrow).
TREATMENT
Obtain immediate otolaryngologic consultation. Provide IV hydration and antibiotic treatment aimed at Staphylococcus, Streptococcus, and anaerobes; choices for initial therapy include clindamycin, 900 milligrams IV, plus metronidazole,  gram IV, or an extended­spectrum penicillin such as
  piperacillin­tazobactam, .375 grams IV, or ampicillin­sulbactam,  grams IV. Add vancomycin if the patient is in a high­risk group. Most patients will require surgical intervention. Catastrophic complications from retropharyngeal abscess include extension of the infection into the mediastinum and upper airway asphyxia from direct pressure or aspiration after sudden rupture of the abscess.
ODONTOGENIC ABSCESS
Odontogenic infections can arise from an infected tooth or after a tooth extraction. Development of the infection varies from <1 day to up to  weeks after the onset of tooth pain and may occur despite oral antibiotics. Odontogenic infections are polymicrobial; the most common bacteria are

Streptococcus viridians, Peptostreptococcus, Prevotella, and staphylococci. Most deep neck infections originate from an odontogenic source, usually the mandibular teeth. Dental abscesses may spread into the parapharyngeal and retropharyngeal spaces. Presenting features include neck mass, trismus, fever, leukocytosis, dysphagia, and dyspnea. Potential complications include necrotizing fasciitis, descending necrotizing mediastinitis, orbital infections, and hematogenous dissemination to distant organs.
CLINICAL FEATURES
See Chapter 245, “Oral and Dental Emergencies,” for management of dental infections isolated to the mandible or maxilla. See Chapter 243, “Face and
Jaw Emergencies,” for management of deep infections of the mid­face. Infections of maxillary molars tend to involve the masticator space, which can extend into the parapharyngeal space and downward into the neck and mediastinum. Infections of anterior mandibular teeth tend to spread into the neck. Infections of anterior teeth, bicuspids, and first molars of the mandible tend to enter the sublingual space, with edema of the floor of the mouth with little extraoral swelling. Involvement of the submandibular space is typically the result of second and third mandibular molar infections.
DIAGNOSIS AND TREATMENT

Diagnosis of superficial odontogenic abscesses can be aided by US at the bedside. For diagnosis of suspected deep space infections, contrastenhanced CT scan is recommended to identify the need for surgical management. Treatment of odontogenic infections includes appropriate antibiotic therapy (aerobic and anaerobic coverage) and surgical drainage of abscesses. Penicillin VK and amoxicillin remain appropriate options for outpatient
,44 treatment; amoxicillin­clavulanate, clindamycin, cefuroxime, and levofloxacin are second­line choices. Patients with deep neck infections require
IV antibiotics. Ampicillin­sulbactam  grams IV, piperacillin­tazobactam .375 grams IV, clindamycin 900 milligrams IV, or a β­lactam drug plus
 metronidazole are recommended regimens.
COMPLICATIONS
Ludwig’s Angina
Ludwig’s angina is infection of the submental, sublingual, and submandibular spaces. Patients usually present with poor dental hygiene, dysphagia, and odynophagia. Clinical examination reveals trismus and edema of the entire upper neck and floor of mouth. Infection progresses rapidly and can posteriorly displace the tongue, causing airway compromise. Definitive airway management should be considered early, including awake fiberoptic
,47 intubation or awake tracheostomy. Stridor, difficulty managing secretions, and cyanosis are late signs and require emergent airway management.

Systemic antibiotics are not a substitute for definitive airway management because it may take >1 week for edema resolution with antibiotic therapy.
Necrotizing Fasciitis
Patients with necrotizing infections are critically ill, with overlying skin discoloration, crepitus of the subcutaneous tissue, and systemic signs, including
,49 fever, tachycardia, hypotension, and confusion. CT reveals subcutaneous emphysema, deep tissue gas, and pockets of suppuration (Figure 246­
4). Aerobic and anaerobic cultures are necessary for identification of causative organisms. Therapy for necrotizing fasciitis is immediate surgery with fasciotomy with wide local debridement and broad­spectrum IV antibiotics. Mediastinal extension places the patient at risk for great vessel erosion,
 retroperitoneal extension, pleural abscess, pericardial effusion, and sepsis; mortality ranges from 10% to 40%. Tracheostomy should be performed
 if airway obstruction develops. Surgery can be lifesaving, and immediate surgical consultation is required for this rapidly progressing disease.
FIGURE 246­4. CT demonstrating necrotizing fasciitis with gas in the deep tissue of the anterior neck.
NECK AND UPPER AIRWAY MASSES
CLINICAL FEATURES
Neck masses (Figures 246­5 and 246­6) can result from congenital, infectious, glandular, or neoplastic disorders. Enlargement may lead to airway compromise, dehydration secondary to dysphagia and odynophagia, or secondary infection. Age of the patient and characteristics including location
 of the mass may aid in the diagnosis (Tables 246­2 and 246­3). Neck masses in children are discussed in Chapter 125, “Neck Masses in Infants and

Children.” In adults >40 years old, up to 80% of lateral neck masses persistent for >6 weeks are malignant.
TABLE 246­2
Common Neck Masses in Young and Older Adults
Young Adult Older Adult
Reactive lymphadenopathy Metastatic aerodigestive tract carcinoma
Mononucleosis Salivary gland infection or neoplasm
Lymphoma Lymphoma
Branchial cleft cyst Thyroid disorder
Thyroglossal duct cyst Tuberculosis
TABLE 246­3
Physical Findings, Pathology, and Management of Neck Masses in Adults
Disorder Physical Finding Pathology Management
Ranula Sublingual area swelling Mucus retention cyst due to ductal Surgical excision obstruction of the sublingual gland
Laryngeal Sessile, warty­appearing lesions on the Human papillomavirus type  or Surgical excision papillomas soft palate or tonsillar pillars  infection
Palatine Boney smooth painless mass of the Exostoses of the palate No treatment needed in most cases torus hard palate
Mandibular Boney smooth painless growth of the Exostoses of the mandible No treatment needed in most cases torus mandible under the tongue
Branchial Painless, fluctuant masses close to the Incomplete obliteration of the Antibiotics if infected, surgical excision cleft cysts angle of the mandible branchial apparatus during development
Thyroglossal Soft, mobile, subhyoid bone midline Remnant of the thyroid anlage Antibiotics if infected, surgical excision duct cysts mass
Lymphoma Multiple, rubbery low­neck masses, Malignant process Biopsy, referral to ENT and oncology night sweats, fever, malaise
Acute Generalized adenopathy, unprotected Human immunodeficiency virus Antiretroviral medication retroviral sex by history infection syndrome
Squamous Firm, possibly fixed cervical lymph Oral lesion metastatic to cervical Biopsy, referral to ENT and oncology cell node node carcinoma
Parotid Nonpainful masses under or anterior Benign or malignant process Biopsy, referral to ENT and oncology as needed tumors to the ear
Sialadenitis Tender swelling in area of parotid, Salivary gland infection Antibiotics, salivary stimulants. See Chapter 243, “Face submandibular, or sublingual salivary and Jaw Emergencies” gland
Thyroid Diffuse nodular thyroid enlargement Benign or malignant process See Chapter 228, “Hypothyroidism and Myxedema enlargement or solitary nodular thyroid Crisis,” and Chapter 229, “Hyperthyroidism and Thyroid
Storm”
Abbreviation: ENT = otorhinolaryngology.
FIGURE 246­5. Right plunging ranula presenting as a painless ballotable submandibular mass.
FIGURE 246­6. Hypopharyngeal squamous cell carcinoma metastatic to left cervical lymph nodes. Note the thrombosis of the left jugular vein with displacement of the airway to the right.
DIAGNOSIS AND MANAGEMENT
A number of management suggestions are listed in Table 246­3. The urgency for complete diagnostic evaluation of a neck mass depends on patient
 acuity. Patients with airway compromise or significant dysphagia and odynophagia should be evaluated by flexible nasopharyngolaryngoscopy before CT scan. CT scan will delineate the extent of the mass and likely will be required for surgical intervention. If no airway compromise or dehydration is present, the patient should follow up with primary care for outpatient imaging and further evaluation. All neck masses should have follow­up for diagnosis and treatment, particularly in light of the high risk of malignancy.

A superficial neck mass or enflamed lymph node suspected of being infectious in etiology may be further investigated by ultrasound at the bedside.
Presence of fluid may indicate an abscess, or a cobblestone pattern may indicate surrounding cellulitis. In the absence of these findings or a history that supports a bacterial infection, antibiotics are unlikely to benefit the patient with a neck mass. Directions should be given for follow­up with primary care or otolaryngology, with return precautions for respiratory distress, dysphagia, or unexpected fever prior to the outpatient appointment.
POSTTONSILLECTOMY BLEEDING
Posttonsillectomy bleeding is a well­known complication of tonsillectomy that can, rarely, lead to death from airway obstruction or hemorrhagic
 shock. Rate of secondary hemorrhage varies according to the method used for the procedure. Overall incidence of posttonsillectomy bleeding differs depending on age, procedure type, and location; estimates vary from <1% to 15%. Approximately half require surgical intervention for control of
,55 bleeding.
Although bleeding can be seen within  hours of surgery, most significant hemorrhage occurs between postoperative days  and

. There is a significantly higher incidence of bleeding in patients older than  years. Posttonsillectomy bleeding can be fatal and requires prompt intervention with control of the airway. An otolaryngologist should be consulted early.
TREATMENT
Keep the patient NPO (nothing by mouth) and sitting upright, monitor with pulse oximetry, and maintain IV access. Obtain a CBC and coagulation studies, and type and cross­match blood. Examine the oropharynx to see if bleeding can be visualized. A grayish­white eschar is normal following a tonsillectomy. Apply direct pressure to the bleeding tonsillar bed using a tonsillar pack or a 4×4 gauze on a long clamp, moistened with either thrombin or lidocaine and epinephrine. To prevent loss of the pack into the airway, place a suture through the pack and tape the suture to the face. Place pressure on the lateral pharyngeal wall, avoiding midline manipulation, to decrease stimulation of the gag reflex.
Pressure alone can be adequate for control of posttonsillectomy hemorrhage until the otolaryngologist arrives. Alternatively, if a bleeding site can be visualized, bleeding may be cauterized with silver nitrate after local infiltration with 1% lidocaine with epinephrine. Nebulized epinephrine or tranexamic acid is one option for serious hemorrhage control. The adult dose of nebulized tranxemic acid is 1000 milligrams in  mL of NS; for
 children, 250 milligrams if <  kg and 500 milligrams if >  kg. Give IV tranexamic acid for severe uncontrolled active bleeding. The dose in adults is
1000 milligrams IV, the same as for trauma­caused hemorrhage; dosage for children is not well validated. Massive bleeding is unusual, but when it occurs, intubation may be the only means of protecting the airway. This is always difficult, with oropharyngeal edema from recent surgery and blood obscuring visualization of the cords. Plans should be made for an emergent cricothyrotomy prior to attempting intubation.

Otolaryngologic consultation in the ED is always needed because patients may have a second or even third posttonsillectomy hemorrhage, and
 surgery or endovascular embolization may be necessary for definitive control.


