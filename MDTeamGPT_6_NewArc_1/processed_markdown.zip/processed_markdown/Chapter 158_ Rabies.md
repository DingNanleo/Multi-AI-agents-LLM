## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 158: Rabies
Zachary I. Willis; David J. Weber
INTRODUCTION AND EPIDEMIOLOGY
This chapter reviews the pathophysiology and epidemiology of rabies, pre­ and postexposure rabies prophylaxis, and clinical presentation and treatment of rabies. Current information is available from the Centers for Disease Control and Prevention (http://www.cdc.gov/rabies/).

More than  billion people are at risk of rabies in over 100 countries. Rabies is responsible for approximately ,000 fatalities annually worldwide, with
,3
India accounting for approximately one third of cases. The World Health Organization estimates that more than  million people receive a
 postexposure preventive regimen annually.
5­7
Rabies is primarily a disease of animals. The epidemiology of human rabies reflects both the distribution of the disease in animals and the degree of human contact with these animals. A summary of major rabies vectors is provided in Table 158­1. TABLE 158­1
Major World and U.S. Rabies Vectors
Vector Region
Dogs Asia, Latin America, Africa
Foxes Europe, Arctic, North America
Skunks Midwest United States, Western Canada
Coyotes Asia, Africa, North America
Mongooses Asia, Africa, Caribbean
Bats North America, Latin America, Europe
No rabies Hawaii, United Kingdom, Australasia, Antarctica

In the United States, rabies is endemic in many wild animal populations, with more than 5500 rabid animals reported in 2015. Although human rabies
 is rare in the United States, postexposure rabies prophylaxis is provided to between ,000 and ,000 persons each year. The cost of rabies
 prevention in the United States is greater than $300 million, most of which is spent on dog vaccinations. From January 2003 to September 2016,  cases of human rabies were reported in the United States, of which  cases were contracted in other countries. Bats represent the most common
  exposure for human rabies cases in the United States. Worldwide, greater than 99% of human rabies cases are acquired by dog bite.
PATHOPHYSIOLOGY
,12
Rabies virus is the prototype member of the genus Lyssavirus. All lyssaviruses are adapted to replicate in the mammalian CNS, are transmitted by
 direct contact, and are not associated with transmission by or natural replication in insects.
Chapter 158: Rabies, Zachary I. Willis; David J. Weber 
. Terms of Use * Privacy Policy * Notice * Accessibility
5­7,13
Viral infection of the salivary glands of the biting animal is responsible for the infectivity of saliva. After a bite, saliva containing infectious rabies virus is deposited in muscle and subcutaneous tissues. The virus remains close to the site of exposure for the majority of the long incubation period
(typically  to  days). Rabies virus binds to the nicotinic acetylcholine receptor in muscle, which is expressed on the postsynaptic membrane of the neuromuscular junction. Subsequently, the virus spreads across the motor end plate and ascends and replicates along the peripheral nervous axoplasm to the dorsal root ganglia, the spinal cord, and the CNS. Following CNS replication in the gray matter, the virus spreads outward by peripheral nerves to virtually all tissues and organ systems.
Histologically, rabies is an encephalitis, resulting in infiltration of lymphocytes, polymorphonuclear leukocytes, and plasma cells, and focal hemorrhage and demyelination in the gray matter of the CNS, the basal ganglia, and the spinal cord. Negri bodies, in which CNS viral replication occurs, are eosinophilic intracellular lesions found within cerebral neurons and are highly specific for rabies. Negri bodies are found in about 75% of proven cases of animal rabies. Although their presence is pathognomonic for rabies, their absence does not exclude it.
Transmission of rabies virus usually begins when the contaminated saliva of an infected host is passed to a susceptible host, usually by the bite of a
 rabid animal. Of note, the bite of a bat may escape notice; human rabies cases with no known animal exposure are most commonly attributed to bats.
Other, less common routes of documented transmission include contamination of mucous membranes (i.e., eyes, nose, mouth), aerosol transmission during spelunking (caving) in bat­infested caves, exposure while working in the laboratory with rabies virus, and infected organ transplantation (e.g., cornea, liver, kidney, vascular graft, lung).
PREEXPOSURE PROPHYLAXIS
Preexposure prophylaxis with rabies vaccine is highly recommended for persons whose recreational or occupational activities place them at risk
14­16 for rabies (Tables 158­2 and 158­3). Although the initial rabies preexposure vaccine regimen is similar for all risk groups, the need for booster doses, the timing of booster doses, and the need for and timing of serologic tests to confirm immunity differ based on the degree of individual risk for exposure to rabies. Preexposure prophylaxis may be obtained from the local health department or from a local physician or veterinarian. Preexposure vaccination does not eliminate the need for additional therapy after a rabies exposure but simplifies postexposure prophylaxis by eliminating the need for human rabies immunoglobulin (HRIG) and by decreasing the number of doses of vaccine required (see later section “Postexposure Prophylaxis in
Special Populations”). Individuals receiving preexposure prophylaxis should be counseled regarding the continued need for postexposure prophylaxis following an exposure.
TABLE 158­2
Rabies Preexposure Risk Assessment and Recommendations
Risk Preexposure
Nature of Risk Typical Population
Category Recommendations
Continuous Virus present continuously, often Rabies research laboratory workers,* rabies biologicals production Primary course: serologic in high concentrations; specific workers testing every  months; exposures likely to go booster immunization if unrecognized; bite, nonbite, or antibody titer is below aerosol exposure acceptable level†
Frequent Exposure usually episodic with Rabies diagnostic laboratory workers,* cavers, veterinarians and staff, Primary course: serologic source recognized, but exposure and animal­control and wildlife workers in rabies­endemic areas; all testing every  years; also might be unrecognized; bite, persons who regularly handle bats booster immunization if nonbite, or aerosol exposure antibody titer is below acceptable level†
Infrequent Exposure nearly always episodic Veterinarians and animal­control and wildlife workers working with Primary course: no
(greater with source recognized; bite or terrestrial animals in areas where rabies is uncommon or rare, serologic testing or booster than nonbite exposure veterinary students, travelers visiting areas where rabies is endemic immunization population and immediate access to appropriate medical care, including at large) biologicals, is limited
Rare Exposure always episodic with U.S. population at large, including persons in rabies­endemic areas No immunization necessary
(population source recognized; bite or at large) nonbite exposure
*Judgment of relative risk and extra monitoring of immunization status of laboratory workers is the responsibility of the laboratory supervisor.
†Minimum acceptable antibody level is complete virus neutralization at 1:5 serum dilution by the rapid fluorescent focus inhibition test. A booster dose should be administered if the titer falls below this level.
TABLE 158­3
Rabies Preexposure Prophylaxis Schedule—United States (2008)
Type of Immunization Route Regimen
Primary Intramuscular* HDCV or PCECV; .0 mL (deltoid area), one dose on days ,† , and  or 
Booster‡ Intramuscular* HDCV or PCECV; .0 mL (deltoid area), one dose on day 0† only
Abbreviations: HDCV = human diploid cell vaccine; PCECV = purified chick embryo cell culture vaccine.
*Use deltoid area for adults and older children. For young children, use anterolateral thigh. Do not administer vaccine in the gluteal area.
†Day  is the day the first dose of vaccine is administered.
‡
Persons in the continuous risk category should have a serum sample tested for rabies neutralizing antibody every  months, and persons in the frequent risk category should be tested every  years. An IM booster dose of vaccine should be administered if the serum titer falls to maintain the value of at least complete neutralization at a 1:5 serum dilution by rapid fluorescent focus inhibition test. See recommendations by the Centers for Disease Control and Prevention14 for more details.
POSTEXPOSURE PROPHYLAXIS
RISK ASSESSMENT
The risk of developing rabies following a bite or scratch by a rabid animal depends on whether the wound was a bite, scratch, or nonbite exposure; the
 number of bites; the depth of the bites; and the location of the wounds (Table 158­4).
TABLE 158­4
Risk of Rabies in the Absence of Postexposure Prophylaxis After Exposure to a Rabid Animal
Multiple severe bites around the face: 80%–100%
Single bite: 15%–40%
Superficial bite(s) on an extremity: 5%
Contamination of a recent wound by saliva: ~0.1%
Contact with rabid saliva on a wound older than  hours: 0%
Transmission via fomites (e.g., tree branch): theoretical* Indirect transmission (e.g., raccoon saliva on a dog): theoretical* *Literature review revealed no cases due to this theoretical method of transmission.
Risk assessment for postexposure prophylaxis includes determining the epidemiology of animal rabies in the area where the contact occurred; knowing the species of animal involved; understanding the type of exposure (e.g., bite vs. nonbite); clarifying the circumstances of the exposure
 incident; and determining if the animal can be safely captured and tested for rabies (Table 158­5). The distinction between a “provoked” and
“nonprovoked” attack should not be used for risk assessment. Most animal bites are “provoked” from the standpoint of the animal (e.g., interfering with the animal’s food, offspring, feeding habits). In addition, approximately 15% of animals with rabies do not exhibit aggressive behavior but are apathetic (“dumb rabies”). The local health department can provide information about the epidemiology of animal rabies in the area.
Evaluation for postexposure prophylaxis is indicated for persons bitten by, scratched by, or exposed to saliva from a wild or domestic animal that could be rabid (Figure 158­1).
TABLE 158­5
Rabies Postexposure Risk Assessment and Recommendations (2012)18
Evaluation and Disposition of
Animal Type Postexposure Prophylaxis Recommendations
Animal
Dogs, cats, and ferrets Healthy and available for  d of Persons should not begin vaccination unless animal develops clinical signs of rabies.* observations Immediate immunization.
Rabid or suspected rabid Consult public health officials.
Unknown (e.g., escaped)
Skunks, raccoons, foxes, Regard as rabid unless animal Consider immediate immunization.
and most other carnivores; proven negative for rabies virus by bats† laboratory tests‡
Livestock, horses, rodents, Consider individually Consult public health officials; bites of squirrels, hamsters, guinea pigs, gerbils, rabbits and hares, and chipmunks, mice, rats, rabbits, hares, and other small rodents almost never require other mammals rabies postexposure prophylaxis.
*During the 10­day observation period, begin postexposure prophylaxis at the first sign of rabies in a dog, cat, or ferret that has bitten someone. If the animal exhibits clinical signs of rabies, it should be euthanized immediately and tested.
†Provide postexposure prophylaxis immediately.
‡
The animal should be euthanized and tested as soon as possible. Holding for observation is not recommended.
FIGURE 158­1. Clinical guidelines for administration of postexposure prophylaxis. (*) Consider postexposure prophylaxis for persons who were in the same room as a bat and who might be unaware that a bite or direct contact had occurred. (†) The small mammals listed here have never been reported to transmit rabies to humans in the United States, but theoretically, such animals could acquire and transmit rabies. Therefore, postexposure prophylaxis following a bite or scratch from one of these mammals would be indicated only if such an animal had signs typical of rabies or a positive laboratory test for rabies. Consult with local public health officials for reports of rabies in atypical animals. FAT = fluorescent antibody testing; HRIG = human rabies immune globulin.
Give postexposure prophylaxis as soon as possible after exposure to rabies­prone wildlife (Tables 158­5 and 158­6).
TABLE 158­6
Summary of Risk of Acquiring Rabies in the United States
Risk Exposures
Moderate Bite by skunk, raccoon, fox, and other wild carnivores (unless animal tested negative for rabies) to high Bite or direct contact with bat (unless animal tested negative for rabies)
Exposure by percutaneous injury, mucous membrane exposure, or inhalation to live rabies virus in a laboratory
Dog bite in a country with endemic rabies and inadequate immunization of dogs (or bite by feral dog)
Very low Bite by inadequately vaccinated cat or dog that has access to the outdoors (or feral cat or dog) to low Contamination of open wound or abrasion (including scratches) with, or mucous membrane exposure to, saliva or other potentially infectious material (e.g., neural tissue) from a possibly rabid animal (skunk, raccoon, fox, and other wild carnivores, bat)
Awakening in a room with a bat present
No risk Contact of animal fluids (e.g., saliva, blood, neural tissue) with intact skin identified Indirect contact with saliva from a wild animal (e.g., by cleaning a dog or cat that has had contact with a wild animal)
Bites

For the purpose of rabies postexposure prophylaxis, a bite exposure is defined as any penetration of the skin by the teeth of an animal.
Bites to the face and hands carry the highest risk, but the site of the bite does not influence the decision to begin therapy.
Nonbite Exposures
A nonbite exposure is contamination of scratches, abrasions, open wounds, or mucous membranes with saliva or brain tissue from a rabid animal.
For example, animal licks to nonintact skin have transmitted rabies. Nonbite exposures from animals very rarely cause rabies. If the material containing the virus is dry, the virus can be considered noninfectious. Petting a rabid animal or contact with blood, urine, or feces (e.g., guano) of a rabid animal
 does not constitute an exposure and is not an indication for prophylaxis.
Exposures to Animals Previously Vaccinated for Rabies
A fully vaccinated dog or cat (i.e., two vaccinations) is unlikely to become infected with rabies. No documented vaccine failures have been reported in the United States among dogs or cats that received two vaccinations. Rare cases have been reported among animals that had received only a single dose of vaccine. In the United States, animals other than dogs, cats, and ferrets that can transmit rabies and are the source of an animal bite or scratch to a human should be euthanized and tested for rabies even if the animals have been vaccinated.
Exposures to Bats
Any direct contact between a human and a bat should be evaluated for a rabies exposure. Seeing a bat does not constitute an exposure.
Postexposure prophylaxis is not indicated if the person can be certain that a bite, scratch, or mucous membrane exposure did not occur or if the bat is available for testing and results are negative for the presence of rabies virus. All bats that might be a source of exposure, if available, should be sent to the public health department and tested for rabies, because approximately 94% of submitted bats in the United States have tested negative for
 rabies. The Advisory Committee on Immunization Practices recommends consideration of postexposure prophylaxis for persons who were in the same room as a bat and who were unaware if a bite or direct contact had occurred (e.g., a sleeping person awakens to
,18 find a bat in the room, or an adult witnesses a bat in a room with an unattended child, mentally disabled person, or intoxicated person). One article
 calculated the incidence of rabies following bedroom exposure with contact as .6 cases per billion person­years, whereas another article reported
 that the number needed to treat to prevent a single case of rabies in this context would be 314,000 to .7 million persons.
Bites From Healthy­Appearing Animals
The Centers for Disease Control and Prevention recommends that a healthy dog, cat, or ferret that bites a person be confined and observed for 
,18 days. At the first sign of illness during confinement, such animals should be evaluated by a veterinarian and a report immediately made to the local health department. If signs suggestive of rabies develop, the animal should be euthanized and its head removed and shipped under refrigeration (not frozen) for examination of the brain by a qualified laboratory designated by the local or state health department.
Bites From Stray Animals
Any stray or unwanted dog, cat, or ferret that bites a person may be euthanized immediately and the head submitted for rabies examination. Animals that might have exposed a person to rabies should be reported immediately to the local health department. An animal other than a dog, cat, or ferret that received prior vaccination may still require euthanasia and testing if the period of virus shedding is unknown for that species.
Person­to­Person Transmission
There are anecdotal reports of person­to­person transmission of rabies. Fluids from the upper and lower respiratory tracts of humans frequently test positive for rabies virus. Despite the lack of proven healthcare­associated transmission, about 30% of healthcare personnel who have had contact with a human diagnosed with rabies have received postexposure prophylaxis. Given the mechanism of disease transmission and concern among healthcare workers, contact isolation precautions should be used for patients with known or suspected rabies, and healthcare workers who care for such patients
 should wear either masks and eye protection or face shields. Healthcare personnel with nonintact skin or mucous membrane exposure to infective saliva or neural tissue from patients with rabies should receive postexposure prophylaxis.
Patients Concerned About Rabies
For unusual exposures, the state veterinarian or local public health agency can be contacted for more information. However, for patients who voice concern about rabies exposure even if the risk assessment is virtually nil (Table 158­6), vaccination can be offered, along with an explanation of the risks and benefits of vaccination. If the risk of rabies is virtually nil, we discourage the administration of HRIG.
WOUND CARE

First, assess wounds for the presence of a life­threatening condition, such as arterial laceration or pneumothorax. Provide proper wound care, including tetanus prophylaxis, wound cleansing with soap and water and (if available) a dilute solution of povidone­iodine (1 mL povidone­iodine in  mL of water or normal saline), antibiotics (if indicated) to prevent bacterial infection (see Chapter , “Puncture Wounds
 and Bites”), and rabies prophylaxis as indicated.
POSTEXPOSURE PROPHYLAXIS TREATMENT
In the United States, postexposure prophylaxis consists of a regimen of one dose of HRIG and four doses of rabies vaccine over a 14­day period,
,18 except for immunocompromised persons, who should receive a five­dose series of vaccine over a 28­day period (Table 158­7). The shift from a five­dose to a four­dose series of rabies vaccine occurred in 2010 and is based on rabies virus pathogenesis, experimental animal studies,
 clinical trials, epidemiologic surveillance, and economic analyses. No other aspects of postexposure prophylaxis were altered from the 2008 recommendations (e.g., use of HRIG, site of injection). HRIG and the first dose of rabies vaccine should be given as soon as possible after exposure, preferably within  hours. If HRIG was not administered when vaccination was begun, it can be administered up to  days after administration of the first dose of the vaccine.
TABLE 158­7
Rabies Postexposure Prophylaxis Schedule—United States, 2010
Immunization
Treatment Regimen* Status
Not previously Wound Cleanse all wounds with soap and water; irrigate wounds with 9:1 diluted solution of povidone­iodine (if available).
immunized cleansing
HRIG Administer  IU/kg actual body weight. If anatomically feasible, infiltrate the full dose around the wound(s) and give any remaining volume IM at an anatomic site distant from vaccine administration; do not give HRIG in the same syringe as vaccine. HRIG may partially suppress active production of rabies virus antibody, so do not give more than the recommended dose.
Vaccine HDCV or PCECV .0 mL (deltoid area†), one dose on days ,‡ , , and .#
Previously Wound Cleanse all wounds with soap and water; irrigate wounds with 9:1 povidone­iodine solution.
immunizedf cleansing
HRIG HRIG should not be administered.
Vaccine HDCV or PCECV .0 mL (deltoid area†), one dose on days 0‡ and . Abbreviations: HDCV = human diploid cell vaccine; HRIG = human rabies immunoglobulin; PCECV = purified chick embryo cell culture vaccine.
*These regimens are appropriate for all age groups, including children.
†The deltoid area is the only acceptable site of vaccination for adults and older children. For younger children, the outer aspect of the thigh (anterolateral aspect) may be used. Vaccine should never be administered in the gluteal area.
‡
Day  is the day the first dose of vaccine is administered.
#Day  vaccine dose no longer recommended by the Advisory Committee on Immunization Practices, unless the patient is immunocompromised (see later section, Immunocompromised Persons). See http://www.cdc.gov/rabies/resources/acip_recommendations.html.
fAny persons with a history of preexposure prophylaxis with HDCV or PCECV; prior postexposure prophylaxis with HDCV or PCECV; or previous immunization with any other type of rabies vaccine and a documented history of antibody response to the prior immunization.
Follow the Centers for Disease Control and Prevention recommendations for postexposure prophylaxis exactly (Table 158­7). Note that rabies vaccine should never be administered in the gluteal area; only the deltoid or anterolateral thigh (for younger children) is acceptable. Although no postexposure prophylaxis vaccine failures have been reported in the United States since the licensing of human diploid cell vaccine in 1980, several
 persons outside the United States have contracted rabies after postexposure prophylaxis with tissue culture–derived vaccine. Most of these cases involved deviation from the recommended protocol; wounds were not cleansed, passive immunization with HRIG was not provided, or rabies vaccine was injected into the gluteal rather than the deltoid area. A small number of failures of apparently properly administered postexposure prophylaxis
 have been reported; however, such cases are rare and factors such as use of HRIG of inadequate potency cannot be definitively ruled out.
Nonetheless in the context of the worldwide burden of human rabies exposure, the efficacy of timely, properly administered postexposure prophylaxis is very nearly 100%.
Rabies Vaccines
Rabies vaccines available in the United States include human diploid cell vaccine (produced in human diploid cells; Imovax®, Sanofi Pasteur, Lyon,
France) and purified chick embryo cell culture vaccine (produced in chick embryo cells; RabAvert®, Novartis Vaccines, Emeryville, CA). The active antibody response requires approximately  to  days to develop, and detectable rabies virus–neutralizing antibodies generally persist for several years. All currently used vaccines are produced in cell cultures and are significantly less toxic than older vaccines that were produced in neural tissue. Side effects of human diploid cell vaccine, including mild erythema, swelling, and pain at the injection site, have been reported in 10% to 90% of vaccine recipients. Systemic reactions, such as headache, nausea, abdominal pain, muscle aches, and dizziness, have been reported in 5% to 40% of recipients. Serum sickness–like reactions (type III hypersensitivity) have been noted in approximately 6% of persons receiving booster doses of human diploid cell vaccine and occur  to  days after administration of the booster dose. Such reactions have not been life threatening and have not been reported with purified chick embryo cell culture vaccine. Anaphylaxis and neurologic symptoms have only rarely been associated with the current rabies vaccines. Severe egg allergy is a contraindication to the use of purified chick embryo cell culture vaccine.

Rabies prophylaxis should not be interrupted or discontinued because of local or mild systemic adverse reactions to rabies vaccine. Usually such reactions can be successfully managed with anti­inflammatory and antipyretic agents. When a person with a history of serious hypersensitivity to rabies vaccine must be revaccinated, antihistamines may be given. Epinephrine should be readily available to counteract anaphylactic reactions, and the person should be observed carefully immediately after vaccination (as after any other injection given in a healthcare setting).
Human Rabies Immunoglobulin
HRIG is administered only once, at the beginning of antirabies prophylaxis, to provide immediate antibodies until the patient responds to rabies vaccine by producing antibodies. A passive antibody titer is evident in  hours. Failure to administer HRIG has led to rabies despite appropriate postexposure prophylaxis with human diploid cell vaccine. If HRIG was not given when vaccination was begun, it can be given through the seventh day
 after administration of the vaccine. Beyond the seventh day after vaccination is begun, HRIG is not indicated, because an antibody response is presumed to have occurred. The Centers for Disease Control and Prevention recommends that as much as possible of the full dose be infiltrated around the wound. HRIG should never be administered in the same syringe or into the same anatomic site as the vaccine, as the antibody and vaccine will neutralize each other. Even if the wound has to be sutured, it should be infiltrated locally with HRIG. This practice is safe and does not create an additional risk of infection. However, caution is needed when injecting into a tissue compartment, such as the finger pulp,
 because excessive HRIG can increase compartment pressure and lead to necrosis. Any remaining HRIG that cannot be administered into the local wound area should be injected intramuscularly at a site distant from vaccine administration. HRIG is prepared from plasma of hyperimmunized donors and screened for known viruses (e.g., human immunodeficiency virus, hepatitis). No cases of virus transmission from HRIG that is commercially available in the United States or Australia have been reported. HRIG should not be given to those with immunoglobulin A deficiencies and known antibodies of immunoglobulin A, because small amounts of immunoglobulin A may be present in HRIG and can cause a severe allergic reaction.
WORLD HEALTH ORGANIZATION POSTEXPOSURE PROPHYLAXIS GUIDELINES
In the United States, only regimens recommended by the Advisory Committee on Immunization Practices should be used. The World Health
,25
Organization has provided recommendations for rabies postexposure prophylaxis that also consider the cost and availability of vaccines and HRIG.
Per the World Health Organization, the indication for postexposure prophylaxis depends on the contact with the suspected rabid animal:
Category I: touching or feeding animals, licks on intact skin (i.e., no exposure)
Category II: nibbling of uncovered skin, minor scratches or abrasions without bleeding
Category III: single or multiple transdermal bites or scratches, contamination of mucous membrane with saliva from licks, licks on broken skin, exposure to bats
For category I exposures, no prophylaxis is required. For category II, immediate vaccination is recommended. For category III, immediate vaccination and administration of rabies immunoglobulin are recommended. Per the World Health Organization, factors that should be taken into consideration when deciding whether to initiate postexposure prophylaxis include the epidemiologic likelihood of the implicated animal being rabid, the category of exposure (i.e., I, II, or III), and the clinical features of the animal, as well as its availability for observation and laboratory testing. In most situations in developing countries, the vaccination status of the implicated animal alone should not be considered when deciding whether to give or withhold prophylaxis.
For IM administration, the World Health Organization recommends the following postexposure regimens. The postexposure vaccination schedule is based on injecting  mL or .5 mL (volume depends on the type of vaccine) into the deltoid muscle (or anterolateral thigh in children <1 year of age) of patients with category II and III exposures. Rabies vaccine should never be injected in the gluteal area. The recommended regimen consists of either a five­ or a four­dose schedule:
The five­dose schedule consists of one dose on each of days , , , , and . The four­dose schedule consists of two doses on day  (one dose in each of the two deltoid or thigh sites) followed by one dose on each of days  and . An alternative for healthy, fully immunocompetent, exposed persons who receive wound care plus high­quality rabies immunoglobulin plus World
Health Organization–prequalified rabies vaccines is a postexposure regimen consisting of four doses administered IM on days , , , and 
(consistent with current U.S. recommendations).
Intradermal administration requires a smaller dose and is used to reduce the cost of vaccine in some countries. However, intradermal administration is technically more demanding and requires appropriate staff training. For intradermal administration, the World Health Organization recommends the following postexposure regimen: The two­site regimen prescribes injection of .1 mL at two sites (deltoid and thigh) on days , , , and . This regimen may be used for people with category II and III exposures in countries where the intradermal route has been endorsed by national health authorities.
POSTEXPOSURE PROPHYLAXIS IN SPECIAL POPULATIONS
Persons With Prior Rabies Immunization
If exposed to rabies, persons previously vaccinated should receive two intramuscular doses (1 mL each) of vaccine, one immediately and one  days
,18 later. “Previously vaccinated” refers to persons who have received one of the recommended preexposure or postexposure prophylaxis regimens of human diploid cell vaccine or purified chick embryo cell culture vaccine, or those who have received another vaccine and had a documented acceptable rabies antibody titer. HRIG is unnecessary and should not be given in these cases, because an anamnestic antibody response will follow the administration of a booster regardless of the prebooster antibody titer.
Immunocompromised Persons
Immunization of immunocompromised persons presents special challenges. First, vaccines may represent a danger to the immunocompromised individual. Second, the immune response to vaccination may be insufficient. Higher doses or additional immunizations may be required, and even with these modifications, the immune response may be suboptimal. The severely immunocompromised are those who have congenital immunodeficiency, human immunodeficiency virus infection, leukemia or lymphoma, aplastic anemia, or generalized malignancy, or who are being treated with alkylating
 agents, antimetabolites, radiation, or large amounts of corticosteroids.
Because rabies vaccine is formulated with inactivated virus, it does not represent a danger to immunocompromised persons and may be administered to such persons using the standard recommended doses and schedule (Table 158­7). However, a five­dose schedule should be used in
 immunocompromised persons.
The recommendations for the use of HRIG are the same for immunocompromised and immunocompetent persons. However, corticosteroids, antimalarials, other immunosuppressive agents, and immunosuppressive illnesses can interfere with the development of active immunity and predispose the patient to developing rabies. Immunosuppressive agents should not be administered during postexposure prophylaxis, unless they are essential for the treatment of other conditions. When rabies postexposure prophylaxis is administered to persons receiving steroids or other immunosuppressive therapy, it is especially important that serum be tested for rabies antibody to ensure that an adequate response
 has developed. To confirm the adequacy of the immune response, serum collected  to  weeks after the postexposure prophylaxis course should
 completely neutralize challenge virus at a 1:5 serum dilution, as measured by a rapid fluorescent focus inhibition test. If no acceptable antibody response is detected, consult an infectious disease expert and appropriate public health officials.
Travelers
Preexposure prophylaxis is recommended for certain international travelers based on the local incidence of rabies in the countries to be visited, the
,27 availability of appropriate antirabies biologicals, and the intended travel activity. Such persons include veterinarians, animal handlers, field biologists, spelunkers, missionaries, and certain laboratory workers. It is recommended to consult the CDC Yellow Book
(https://wwwnc.cdc.gov/travel/page/yellowbook­home) prior to travel for updated guidance. Chloroquine phosphate (and possibly other structurally related antimalarials such as mefloquine, which is administered for malaria chemoprophylaxis) may interfere with the antibody response to intradermal rabies vaccine administered for preexposure prophylaxis. The IM route, not the intradermal route, should be used for people taking chloroquine concurrently (the intradermal route is not approved for use in the United States); ideally, the rabies preexposure vaccination series should be completed before beginning chloroquine.
Between 2003 and September 2016, nine persons died in the United States from rabies after having been exposed (most often via dog bite) while
 visiting a foreign country. For this reason, all persons who have returned from abroad should be questioned regarding whether they received an animal bite or scratch in an area with endemic rabies. Persons bitten or scratched by an animal in an area with endemic rabies should receive appropriate postexposure prophylaxis if the injury has occurred within the known incubation period (which may rarely extend up to  or more years).
U.S. citizens and residents who are exposed to rabies while traveling in countries where rabies is endemic may sometimes receive postexposure prophylaxis with regimens or biologicals that are not used in the United States. If postexposure prophylaxis is begun outside the United States using a regimen or biological of nerve tissue origin not approved by the U.S. Food and Drug Administration, it may be necessary to provide additional
 treatment when the patient reaches the United States. State and local health departments should be contacted for specific advice in such cases. The major modification used abroad, usually in an attempt to reduce cost, is the substitution of various schedules for intradermal injection or the use of vaccines not approved by the U.S. Food and Drug Administration.
Pregnant Women
Adverse pregnancy outcomes or fetal abnormalities have not been associated with rabies vaccination. Because of the potential consequences of inadequately treated rabies exposure and because adverse events have not been associated with rabies postexposure prophylaxis
 during pregnancy, pregnancy is not considered a contraindication to rabies postexposure prophylaxis or HRIG. If there is substantial risk of exposure to rabies, preexposure prophylaxis may also be indicated during pregnancy.
Children

The dose of rabies vaccine for preexposure and postexposure prophylaxis is the same in infants and children as in adults (Table 158­7). The dose of
HRIG for postexposure prophylaxis is based on actual body weight. For small children with multiple bites, the calculated dose of HRIG may be
 insufficient to infiltrate all wounds. However, sterile saline can be used to dilute the volume twofold or threefold to permit thorough infiltration.
CLINICAL RABIES
Rabies virus causes acute encephalitis in all warm­blooded hosts, including humans, and the outcome is almost always fatal. Although patients with rabies may manifest a variety of clinical symptoms and signs, the disease tends to follow a characteristic course (Table 158­8).
TABLE 158­8
Natural History of Clinical Rabies in Humans After Incubation Period
Clinical Stage Defining Event Usual Duration Common Symptoms and Signs* Prodrome First symptom 2–10 d Pain or paresthesia at site of bite
Malaise, lethargy
Headache
Fever
Nausea, vomiting, anorexia
Anxiety, agitation, depression
Acute neurologic phase First neurologic sign 2–7 d Anxiety, agitation, depression
Hyperventilation, hypoxia
Aphasia, incoordination
Paresis, paralysis
Hydrophobia, pharyngeal spasms
Confusion, delirium, hallucinations
Marked hyperactivity
Coma Onset of coma 0–14 d Coma
Hypotension, hypoventilation, apnea
Pituitary dysfunction
Cardiac arrhythmia, cardiac arrest
Death or recovery (extremely rare) Death or initiation of recovery Months (recovery) Pneumothorax
Intravascular thrombosis
Secondary infections
*Not every symptom or sign may be present in each case.

Most commonly, the incubation period after a bite ranges from  to  days. However, incubation periods have been reported that are as short as  days and as long as  years. For patients who died from rabies in the United States between 1980 and 1996 and in whom a definite animal bite
 occurred, the median incubation period was  days (range,  to 150 days). The incubation period is shorter when the site of the bite is on the head
 than when it is on an extremity.
CLINICAL FEATURES
During the prodrome, the symptoms and signs are nonspecific. Early in the course, some patients may report symptoms suggestive of rabies such as limb pain, limb weakness, and paresthesias at or near the presumed exposure site. The prodrome merges into the acute neurologic phase, which begins when the patient develops objective signs of CNS disease.

There are two clinical forms of rabies: an encephalitic form in 80% and a paralytic form in 20%. In encephalitic rabies, there are often episodes of generalized arousal or hyperexcitability, disorientation, hallucinations, and bizarre behavior, often separated by lucid intervals. Autonomic dysfunction is common and includes hypersalivation, hyperthermia, tachycardia, hypertension, piloerection, cardiac arrhythmias, and priapism.
Paralytic rabies generally begins with paresis in the bitten extremity with spread to quadriparesis and bilateral facial weakness. There is progression of
 paralytic rabies to coma and organ failure, typically with a longer clinical course than in encephalitic rabies. About 50% of patients have classic hydrophobia, in which attempts to drink fluids result in severe spasms of the pharynx, larynx, and diaphragm.
Coma almost always occurs within  days of the onset of symptoms. Death occurs due to a variety of complications, including pituitary dysfunction, seizures, respiratory dysfunction with progressive hypoxia, cardiac dysfunction with dysrhythmias and arrest, autonomic dysfunction, renal failure, and secondary bacterial infections.
Only  patients are known to have survived rabies; most survivors have had severe neurologic sequelae. In all but three cases, the patient had
 received postexposure prophylaxis with rabies vaccine (e.g., duck embryo, suckling mouse brain) before the onset of symptoms.
DIAGNOSIS AND TREATMENT
Rabies should be included in the differential diagnosis of any patient with unexplained acute, rapidly progressive encephalitis, especially in the
29­32 presence of anatomic instability, dysphagia, hydrophobia, paresis, or parasthesias. Diseases that may be confused with rabies include tetanus, poliomyelitis, Guillain­Barré syndrome, botulism, transverse myelitis, postvaccinal encephalomyelitis, intracranial mass lesions, cerebrovascular accidents, poisoning with atropine­like compounds, and infectious causes of viral encephalitis (e.g., herpes simplex, varicella zoster, arthropod­borne viral encephalitis such as eastern equine encephalitis). Emerging diseases that can be confused with rabies include West Nile virus (United States,
Europe, Middle East, Africa), Toscana virus (Europe), Japanese encephalitis (Asia), enterovirus  (Asia), human herpes virus  (worldwide),
,34 chikungunya fever (Asia, Africa, Europe), Nipah virus (Asia), and Hendra virus (Asia).
The diagnosis of rabies is frequently made postmortem. This occurs because of the rarity of the disease, the increasing number of persons without an obvious exposure, and clinical confusion with other disorders. Important clues to diagnosis include a history of an animal bite or bat exposure and the development of the pathognomonic signs of hydrophobia and aerophobia (precipitating grimacing and other signs by blowing air on the patient’s face).
During the incubation period of rabies, no diagnostic test is available for animals or humans that will indicate infection. Once symptoms become evident, antigen detection in biopsy specimens from highly innervated skin (i.e., nuchal skin), antibody detection in serum (if unvaccinated) or CSF (all
,35 people), isolation of virus from saliva, or detection of nucleotide sequences in saliva, skin, or other tissues can detect evidence of the disease.
Serum antibodies may be present as early as day  of clinical illness, but antibodies may be absent after  to  days or longer. CT of the brain is only useful to exclude other diseases. MRI of the brain may be normal or may show lesions in gray matter areas of the brain parenchyma, including the brainstem. Cerebrospinal fluid analysis often shows a mild mononuclear pleocytosis.

No specific therapy has been of demonstrated benefit in clinical rabies. Treatment with rabies vaccine, rabies immunoglobulin, IV ribavirin, or
 interferon is not effective. In animal models, use of corticosteroids shortens the incubation time and increases mortality, and for this reason, steroids are contraindicated. Survival with normal neurologic function was reported for a 15­year­old girl in whom coma was induced and
 treatment with ketamine, midazolam, ribavirin, and amantadine was provided. However, similar regimens have been used for more than  other
 patients without success. Most documented cases of rabies survival have occurred since 2000, suggesting that modern supportive care increases the likelihood of survival, particularly in resource­rich settings. Currently, treatment is directed at the clinical complications of the disease. Although rabies is not treatable, every attempt should be made to achieve rapid diagnosis, because it justifies public health measures to limit contacts with the patient and permits reconstruction of a history to identify others who may have been exposed to the same infective source.


