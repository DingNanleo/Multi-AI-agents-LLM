## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 184: Nonbenzodiazepine Sedatives
Frank LoVecchio
INTRODUCTION
The term sedative­hypnotic refers to any drug designed to produce sedation and sleepiness. These drugs can be divided into the benzodiazepines (see
Chapter 183, “Benzodiazepines”) and nonbenzodiazepines (Table 184­1).
TABLE 184­1
Nonbenzodiazepine Sedative­Hypnotics
Recommended Initial Adult Recommended Maximum Adult Time to Peak
Name Elimination Half­Life
Dose (oral; milligrams) Daily Dose (milligrams) Plasma Levels
Buspirone  three times a day  40–90 min 2–3 h
Carisoprodol 250–350 four times a day 1400 .5 h  h
Chloral hydrate 500–1000 Typically single dose  minutes  min  min for chloral hydrate and 6– before procedure  h for trichloroethanol
γ­ See text See text 30–60 min .3–1 h
Hydroxybutyrate
Melatonin .2–5 qhs 5–10 30–60 min 40–50 min
Meprobamate 400 TID or QID 2400 .6 h  h
Ramelteon  qhs   min 1–2.6 h
Tasimelteon  qhs  .5–3 h .3 h
Zaleplon  qhs  .7–1.4 h .9–1.2 h
Zolpidem  qhs  1–2 h .4–4.5 h
Zopiclone* .5 qhs .5 .5–2 h 5–6 h
Eszopiclone  qhs  1–1.5 h 6–7 h
Abbreviations: qhs = at bedtime; QID = four times per day; TID = three times per day.
*Not available in the United States.
One is most likely to encounter toxicity from these sedative drugs as part of accidental or nonaccidental overdose, as well as after an assault or trauma.
 
Many nonbenzodiazepines were developed and are marketed for the treatment of insomnia, anxiety, and sedation. Other agents with sedative effects,
Chapter 184: Nonbenzodiazepine Sedatives, Frank LoVecchio including antihistamines (e.g., diphenhydramine, doxylamine), antidepressants (e.g., amitriptyline, trazodone, mirtazapine), and antipsychotics (e.g.,
. Terms of Use * Privacy Policy * Notice * Accessibility quetiapine), are also used to promote sleep.
Three sedative agents used in the past have been removed from the legal U.S. and Canadian markets: ethchlorvynol, glutethimide, and methaqualone.

However, via Internet sites, these drugs are available to North American customers from locations in Eastern Europe, Africa, Asia, and South America.
BUSPIRONE

Buspirone is approved by the U.S. Food and Drug Administration for treatment of anxiety disorders. Off­label uses include treatment of depression and nicotine dependence. Buspirone is a partial agonist at the serotonin­1A receptor and an antagonist of the dopamine­2 receptor. The resultant effect on serotonin and dopamine neurotransmitter levels is complex, depending on the concentration of the drug and specific brain location, but overall effects are primarily suppression of CNS serotonergic activity and enhancement of dopaminergic and, possibly, noradrenergic activity.
Following ingestion, absorption is rapid and nearly complete, with significant first­pass metabolism in the liver (primarily via oxidation) resulting in a low bioavailability. Metabolism of buspirone (by cytochrome P3A4) produces several metabolites, including one active metabolite. Primary elimination is renal, with additional substantial fecal elimination.
Common adverse effects seen with buspirone include sedation, GI discomfort, vomiting, and dizziness. In therapeutic dosing, buspirone does not
 appear to cause psychomotor depression, and the drug has not been associated with any potential for abuse or withdrawal.
The effects observed with a buspirone overdose are an exaggeration of adverse effects observed during therapeutic dosing. In general, the drug is well
 tolerated in overdose, and the treatment is largely supportive. Animal toxicity studies indicate the potential for buspirone to provoke seizures, and one human case report noted the occurrence of a generalized tonic­clonic convulsion approximately  hours after a buspirone overdose (Table 184­

2). Because of its serotonergic properties, buspirone has been associated with serotonin syndrome, although the true occurrence
 is exceedingly rare.
TABLE 184­2
Selected Aspects of Nonbenzodiazepine Overdose
Agent Features Commonly Seen With Overdose Unique Toxicologic Effects
Buspirone Sedation Generalized seizures (rare)
Serotonin syndrome
Carisoprodol Sedation, coma, cardiovascular collapse, Myoclonic jerks pulmonary edema
Meprobamate Sedation, coma, cardiopulmonary depression Gastric bezoar with prolonged coma
Chloral hydrate Coma Cardiac instability, ventricular dysrhythmias, sensitivity to catecholamines, GI distress, hemorrhagic gastritis
γ­Hydroxybutyrate Amnesia, sedation, seizure, coma, cardiac and Steep dose–response curve respiratory depression Sudden awakening
Melatonin Sedation, disorientation None observed
Ramelteon Sedation None observed
Tasimelteon Unknown Limited experience, headache (possible)
Zolpidem Sedation, coma possible Limited experience, vomiting
Zaleplon Sedation, incoordination Limited experience, headache (possible)
Zopiclone and Sedation Limited experience, methemoglobinemia and hemolytic anemia (large eszopiclone overdoses)
CARISOPRODOL AND MEPROBAMATE
Carisoprodol and its primary active metabolite meprobamate have been used since the 1950s. Carisoprodol is marketed as a centrally acting muscle relaxant, whereas meprobamate is marketed as an anxiolytic drug.
The exact mechanism of action of carisoprodol is not known; animal data demonstrate its ability to block interneuronal activity within the spinal cord
 and descending reticular formation. Other evidence suggests that the primary mechanism of action is simply related to sedation. Carisoprodol may
 also have direct γ­aminobutyric acid activity, independent of its metabolite meprobamate.
Following ingestion, carisoprodol is rapidly absorbed, with an onset of action within  minutes and a duration of action between  and  hours.
Several formulations are marketed, sometimes combined with aspirin, caffeine, or codeine. Following metabolism in the liver, the carisoprodol metabolites are renally excreted.
Following ingestion, meprobamate is rapidly absorbed, with a duration of action of  to  hours. Following metabolism in the liver, the metabolites and 10% to 20% of the unchanged drug are eliminated by the kidneys.

With a carisoprodol overdose, there may be serious toxicity with sedation, coma, cardiovascular collapse, and pulmonary edema. Myoclonic jerks are frequently seen with carisoprodol toxicity, so suspect this ingestion in sedated or comatose patients with occasional jerking of the extremities. Serotonergic features of carisoprodol intoxication have been noted, but the mechanism by which these symptoms and signs are
 produced is not understood. Treatment of carisoprodol overdose and toxicity is supportive.
With meprobamate overdose, sedation, coma, and cardiopulmonary depression are seen, but there are no myoclonic jerks as described earlier with carisoprodol. Ingestion of a large number of meprobamate tablets has been reported to form a gastric bezoar, and prolonged coma
 has been attributed to such retained drug within the stomach. If this occurs, multidose activated charcoal or endoscopic removal of the mass may be useful.

Carisoprodol withdrawal mimics ethanol and benzodiazepine withdrawal in that they are all γ­aminobutyric acid type A agonists. Treatment of withdrawal is reinstitution of the carisoprodol or administration of other γ­aminobutyric acid type A agonists.
CHLORAL HYDRATE
Chloral hydrate was first marketed as a sedative in 1869, making it the oldest sedative­hypnotic agent still available. It remained quite popular until the early 1900s, when barbiturates largely supplanted its use. Chloral hydrate is primarily used as a sedative for painless procedures in young children
 because of its relatively wide therapeutic index, the lack of significant respiratory depression, and the ability for oral administration, but the agent is
 not without risk.
Following ingestion, chloral hydrate is quickly absorbed and rapidly reduced (by alcohol dehydrogenase) to the active metabolite trichloroethanol.
Trichloroethanol is further oxidized to trichloroacetic acid, which is an inactive compound. Renal excretion of chloral hydrate is minimal.
Co­ingested chloral hydrate and ethanol have a synergistic effect. The metabolism of ethanol results in increased amounts of the reduced form of nicotinamide adenine dinucleotide, which, in turn, promotes the conversion of chloral hydrate to trichloroethanol. In addition, because of competition by chloral hydrate for alcohol dehydrogenase, there is decreased metabolism of ethanol. These interactions result in more elevated levels of both trichloroethanol and ethanol than would be seen if either was ingested alone. The resultant profound sedation yields the terms “knock­out drops” or “Mickey Finn” for this combination.
At therapeutic doses, chloral hydrate results in mental status depression, but airway and respiratory reflexes are not impaired. Paradoxical
 hyperactivity occurs in 1% to 2% and vomiting is seen in 3% to 10% of children given doses of  to 100 milligrams/kg PO.
With an overdose, chloral hydrate can produce coma. An important feature of chloral hydrate overdose is cardiovascular instability,
 manifested by decreased cardiac contractility, myocardial electrical instability, and increased sensitivity to catecholamines.
Commonly encountered cardiac dysrhythmias include premature ventricular contractions, ventricular fibrillation, torsades de pointes, and asystole. GI irritation, manifesting as nausea, vomiting, or hemorrhagic gastritis, has also been observed. A diagnostic clue is the common presence of a pear­like odor.
Treatment of chloral hydrate overdose and toxicity is largely supportive. With coma, endotracheal intubation may be necessary. IV β­adrenergic
 blockers should be used to treat ventricular dysrhythmias seen with chloral hydrate overdose. Torsades de pointes should be managed with IV magnesium sulfate or ventricular overdrive pacing.
γ­HYDROXYBUTYRATE (GHB)
γ­Hydroxybutyrate (GHB) is an endogenous molecule as well as a drug. GHB was originally used as an IV anesthetic, primarily in several European countries. In recent years, it has been marketed as a drug for body builders to improve body mass and reduce fat, as well as for use as a hypnotic,
  antidepressant, anxiolytic, and cholesterol­lowering drug. GHB has been found in drug­facilitated sexual assaults. Sodium oxybate (the sodium salt
 of GHB) is currently approved only for use within a highly regulated setting for the treatment of narcolepsy. In some European countries, GHB or
 sodium oxybate is used as a treatment for alcohol dependence and withdrawal. GHB can be formulated as a clear liquid or in solid form as a capsule, tablet, or white powder. GHB has many vernacular names, including “liquid ecstasy,” “Georgia Home Boy,” “G,” and “Grievous Bodily Harm.”
Sodium oxybate is categorized a Schedule III drug by the U.S. Food and Drug Administration when used to treat narcolepsy, but GHB used for any purpose is considered a Schedule I drug. To circumvent laws, GHB precursors, namely γ­butyrolactone and ,4­butanediol, have been introduced into
 the drug scene. Following ingestion, lactonase enzymes in the blood convert γ­butyrolactone into GHB. Depending on the level of lactonase enzyme activity, this conversion can be rapid and produce a faster onset of symptoms compared with GHB. The conversion of ,4­butanediol to GHB is a twostep process: conversion via alcohol dehydrogenase to γ­hydroxybutyraldehyde, with subsequent conversion via aldehyde dehydrogenase to GHB.
GHB undergoes metabolism via GHB dehydrogenase to succinic acid semialdehyde, which in turn can either be converted to succinic acid (to enter the
Krebs cycle, yielding carbon dioxide and water) or to γ­aminobutyric acid, a primary inhibitory neurotransmitter. A small percentage of GHB will be excreted unchanged in the urine.

Following ingestion, GHB is rapidly absorbed from the GI tract, with peak plasma concentration occurring within an hour. GHB has a relatively low oral bioavailability due to significant first­pass metabolism. After absorption, GHB follows a two­compartment model, in which the initial serum levels decline due to redistribution. There is a subsequent slower decline in the serum concentrations following metabolic degradation. Because of its short
 half­life, GHB is difficult to detect in the urine >6 hours after ingestion and is virtually nondetectable >12 hours after ingestion. GHB has minimal protein binding and readily crosses the blood–brain barrier and placenta.
The body produces some endogenous GHB, both as a precursor and a breakdown product of γ­aminobutyric acid. At physiologic concentrations, GHB binds to a unique receptor that is distinct from γ­aminobutyric acid receptors. When the concentration of GHB in the brain exceeds the physiologic micromolar concentration, GHB can bind to (and activate) the γ­aminobutyric acid subunit B receptors.
GHB has a steep dose–response curve with a narrow therapeutic ratio; doses of  milligrams/kg result in short­term amnesia, doses of  to  milligrams/kg result in sedation and drowsiness, and doses exceeding  milligrams/kg result in seizure, coma, respiratory depression, and cardiac
,26  depression. Bradycardia, hypothermia, and either miosis or mydriasis can occur. During recovery, patients often wake up surprisingly quickly, as opposed to the more prolonged awakening phase seen after an overdose with other sedatives. Despite co­ingestants being commonly encountered,
 most patients fully regain consciousness within  to  hours. The co­ingestion of ethanol can worsen hypoxia, increase the elimination half­life of
 ,29
GHB, and prolong duration of toxicity.

Treatment is largely supportive. Intubation may be unnecessary, even in patients with severely depressed consciousness (Glasgow Coma Scale score
≤8) because patients are usually able to protect their airway and maintain ventilation.  Once the patient is awake and alert, assuming no co­ingestants or secondary complications such as aspiration, the patient can be medically discharged or transferred. Physostigmine or neostigmine are not
 recommended for reversal of known or suspected GHB intoxication. Fomepizole (a competitive antagonist of alcohol dehydrogenase) has little benefit in ,4­butanediol overdoses because preventing metabolism of the ingested drug into GHB is of little benefit due to the short expected duration of symptoms.

Toxicologic detection of GHB can be difficult because of its short half­life, the complexity of assay methodology, and the presence of the endogenous
,32 compound. If needed, toxicologic confirmation should be performed with blood or urine collected as soon as the individual arrives in the ED.
MELATONIN
Melatonin is an endogenous hormone that is normally secreted by the pineal gland and is believed to be involved with the circadian sleep–wake
 cycle. Melatonin is available without prescription in tablets or capsules at doses ranging from a physiologic dose of .2 milligram up to pharmacologic doses of  to  milligrams.

Two primary melatonin receptor subtypes are found in the human CNS. The MT receptor is located primarily in the hypothalamic suprachiasmatic
 nucleus and is involved in the effect melatonin has on circadian rhythm. The MT receptor is found primarily in the retina, presumably involved in the
 interaction between incoming light, melatonin, and the circadian cycle. The MT receptor is also found in the hypophysial pars tuberalis and is possibly
 responsible for the effects of melatonin on reproduction.
Following ingestion, peak plasma melatonin concentrations occur within  to  minutes. Melatonin has a short plasma half­life and a short duration of action in therapeutic doses. Melatonin is metabolized by initial conversion to O­desmethylmelatonin and 6­hydroxymelatonin. Both are subsequently conjugated as either a glucuronide or a sulfate before renal excretion.

At therapeutic dosing, side effects from melatonin include fatigue, headache, dizziness, and irritability. Data on melatonin overdoses are limited, but overdose would be expected to result in an exaggeration of therapeutic effects, primarily sedation and disorientation, without any significant life­
 threatening effects.
RAMELTEON

Ramelteon is a highly selective agonist at the melatonin MT and MT receptors, marketed for the treatment of insomnia. Ramelteon has no
  significant activity at the γ­aminobutyric acid, dopamine, serotonin, norepinephrine, or opiate receptor sites. An active metabolite does have weak activity at the serotonin­2B receptor but is thought to be clinically insignificant.
Ramelteon is rapidly absorbed following oral administration, but oral bioavailability is <2% due to extensive first­pass metabolism. Hepatic metabolism of ramelteon yields four metabolites, one of which is active. Metabolism is primarily through the cytochrome P1A2 enzyme, with minor contributions via P2C and P3A4. The coadministration of P1A2 inhibitors such as fluoroquinolones and verapamil has been shown to increase ramelteon concentrations. Protein binding is extensive, the volume of distribution is large, and excretion is primarily renal.

In overdose, sedation would be expected, and treatment is supportive. Ramelteon has not been associated with any potential for abuse and has
 minimal risk for producing withdrawal symptoms or rebound insomnia.
TASIMELTEON
Tasimelteon is an agonist at melatonin MT and MT receptors used for treatment of non–24­hour sleep–wake disorder, a syndrome characterized by
  insomnia or excessive sleepiness from abnormal synchronization between the 24­hour light–dark cycle and the endogenous circadian rhythms of
 sleep and wakefulness. The majority of patients with this syndrome are totally blind. Ramelteon and tasimelteon may have benefit in sleep disorders
 associated with comorbid psychiatric, neurologic, and cardiovascular conditions.
After ingestion, peak concentrations occur within .5 to  hours. There is a large volume of distribution, high protein binding, and extensive metabolism with an elimination half­life of .3 hours.
There is no reported experience with tasimelteon overdose. Adverse effects reported during clinical trials suggest headache may occur. There have
 been no observed findings suggestive of abuse potential, physical dependence, or withdrawal during clinical trials.
ZOLPIDEM, ZALEPLON, AND ZOPICLONE
,34
Zolpidem, zaleplon, and zopiclone are three nonbenzodiazepine sedative­hypnotics used to treat insomnia. All three promote sleep by enhancing
CNS γ­aminobutyric acid activity but differ in their pharmacodynamic and pharmacokinetic profiles.
All three drugs bind to the benzodiazepine binding site on the postsynaptic γ­aminobutyric acid subtype A1 receptor, although they have different
 binding affinities to the α­1 and α­2 subunits. Zaleplon has a very short half­life (about  hour), as opposed to the somewhat longer half­lives of zolpidem and zopiclone (Table 184­1).
All three drugs were initially promoted as an improvement upon benzodiazepines for the treatment of insomnia. They were to be safer, produce less psychomotor impairment with therapeutic doses, and not be addictive or associated with a withdrawal state. With experience, all three drugs have
,43 been found to impair psychomotor function, create tolerance and dependence, and be associated with withdrawal states characterized by
 insomnia, anxiety, agitation, and delirium. Zaleplon, presumably because of its shorter elimination half­life, appears to produce less
 tolerance and withdrawal symptoms than zolpidem or zopiclone.
Zolpidem undergoes hepatic metabolism into three inactive metabolites, so dosage restrictions are recommended for those with hepatic impairment and those with chronic renal insufficiency. Common adverse effects include somnolence and nausea. Because of occasional psychomotor impairment, individuals should not drive or engage in hazardous activity the day following use of zolpidem. There are numerous reports of sleepwalking or vivid
 dreams after its consumption. Following overdose, sedation (including coma) and vomiting can occur. Fatalities usually occur in the setting of co­
 ingestants, rather than with zolpidem by itself.
Zaleplon absorption occurs rapidly (Table 184­1) but can be delayed if zaleplon is co­ingested with a high­fat meal. Following absorption, zaleplon undergoes extensive first­pass metabolism in the form of oxidation via aldehyde oxidase to form inactive metabolites. Elimination is primarily renal, with some fecal elimination as well. In therapeutic doses, zaleplon is not associated with any dependence or withdrawal state when taken for up to 
 weeks. At doses up to  milligrams, no psychomotor or memory impairment is observed, but a dose of  milligrams is associated with some impairment. Reports of overdose with zaleplon are limited, but expected findings include sedation, incoordination, and possibly headache.
Zopiclone is not currently available in the United States, but eszopiclone, the S­configuration and active isomer of zopiclone, is marketed.
Zopiclone is rapidly absorbed and hepatically metabolized into active (N­oxide metabolite) and inactive (N­dimethyl metabolite) compounds. Nearly half of the parent drug is excreted in the lungs following decarboxylation. Reports of zopiclone or eszopiclone overdose indicate sedation to be the
  primary observed effect. Prolonged coma was reported in an elderly patient who ingested a large amount of eszopiclone. Rare cases of
 methemoglobinemia and mild hemolytic anemia have been reported after large zopiclone overdoses.
HISTORICAL SEDATIVES
Ethchlorvynol was marketed during the 1950s as an alternative to barbiturates. In 1999, the remaining U.S. manufacturer stopped production and sales of the drug, but availability elsewhere in the world persists. Following ingestion, ethchlorvynol is rapidly absorbed from the GI tract. A biphasic distribution process is characterized by an initial phase of adipose tissue deposition followed by a redistribution out of adipose stores and back into the plasma. Ethchlorvynol has a plasma half­life of  to  hours, undergoes hepatic metabolism, and is renally excreted. At therapeutic dosing, sedation and nystagmus can occur. Overdose can be characterized by prolonged deep coma, hypothermia, hypotension, bradycardia, and cardiovascular collapse. Similar to other severe coma states, bullous lesions have been seen with ethchlorvynol overdose. Abusers have been reported to inject the drug, sometimes producing acute pulmonary edema. Ethchlorvynol overdose may produce a vinyl­like odor that can be a useful diagnostic
 clue. Treatment is largely supportive, but charcoal hemoperfusion has been used in massive overdoses.
Glutethimide was withdrawn from the market in 1999 when the remaining U.S. manufacturer stopped production and sales. Availability overseas is suggested by listings on the Internet for sales of this drug. A unique aspect of this drug was that the combination of oral glutethimide with codeine produced a euphoria considered similar to that induced by heroin. In overdose, glutethimide produces a deep coma with periods of cyclic responsiveness. The cause of these cycles has been ascribed to an active metabolite, but evidence is not convincing. Following ingestion, absorption is variable and plasma half­life is  to  hours. Glutethimide possesses antimuscarinic properties, so toxic patients may have tachycardia, hypertension, mydriasis, urinary retention, and intestinal ileus. Treatment is primarily supportive.
Methaqualone was withdrawn from the U.S. market in 1984 when the remaining manufacturer stopped production. Continued use and abuse of methaqualone in South Africa is a significant problem, where the drug is often mixed with cannabis and smoked. As with the other two sedatives of historical interest, availability in other countries is suggested by Internet sites. A unique feature of a methaqualone overdose is muscular hyperactivity, with hyperreflexia and clonus and a lower rate of respiratory depression and hypotension compared with other sedatives. In severe overdoses, prolonged supportive treatment is often required.


