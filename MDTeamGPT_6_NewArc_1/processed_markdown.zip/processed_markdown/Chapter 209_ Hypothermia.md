## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 209: Hypothermia
Douglas J.A. Brown
INTRODUCTION AND EPIDEMIOLOGY
Accidental hypothermia is an involuntary drop in core temperature below 35°C (<95°F) and can often be associated with significant morbidity and
 mortality. Therapeutic hypothermia, also called targeted temperature management, is a purposeful drop in core temperature usually performed
,3 with the hope of ameliorating tissue damage associated with an ischemic event.
Accidental hypothermia can be subclassified as primary, due to simple environmental exposure, or secondary, due to impaired thermoregulation
(Table 209­1). Primary accidental hypothermia is commonly seen in cold climates, whereas secondary accidental hypothermia can be seen
 worldwide. The true incidence of accidental hypothermia and its related morbidity and mortality remains unknown, but estimates suggest it is .1 to 
 cases per 100,000 inhabitants in nontropical climates.
TABLE 209­1
Causes of Secondary Hypothermia
Predominantly Increased Heat Loss
Burns
Iatrogenic (i.e., blood transfusions and other cold infusions, cooling blankets, inadequate insulation)
Recent birth
Predominantly Impaired Thermogenesis
Impaired shivering (i.e., advanced or very young age, malnutrition, physical exhaustion, neuromuscular disease)
Multifactorial
Medications and toxins (i.e., alcohol, anesthetic agents, narcotics, sedatives, vasodilators)
Metabolic and endocrine disorders (i.e., alcoholic or diabetic ketoacidosis, hypoadrenalism, hypoglycemia, hypopituitarism, hypothyroidism lactic acidosis, Wernicke’s encephalopathy)
Neurologic (i.e., space­occupying lesion, stroke, spinal cord injury)
Sepsis (small subset of sepsis cases, more common in the elderly or cachectic patient)
Shock
Trauma
HYPOTHERMIA CLASSIFICATION
Historically, hypothermia has been classified as mild, moderate, severe, and profound, based on core temperature, shivering, level of consciousness,
6­8 and vital signs. Unfortunately, there is considerable variation in clinical features at any given temperature, and a reliable core temperature is sometimes unavailable during initial assessment. Shivering is particularly unreliable because it may be present or absent across a wide temperature
6­8  range. The modified staging system (mild, moderate, severe, and hypothermic cardiac arrest) described in Table 209­2 is a hybrid of the Swiss and

 classical systems that is based primarily on level of consciousness, the presence or absence of vital signs, and core temperature (when available).
Chapter 209: Hypothermia, Douglas J.A. Brown 
. Terms of Use * Privacy Policy * Notice * Accessibility
TABLE 209­2
Staging and Treatment of Accidental Hypothermia
Clinical
Stage Typical Core Temperature Treatment
Symptoms
Mild (HT I) Conscious, 35–32°C Warm environment and clothing, warm sweet drinks, and shivering active movement (if possible)
HT I patients with significant trauma or comorbidities or those suspected of secondary hypothermia should receive HT II treatment
Moderate Impaired <32–28°C Active external and minimally invasive rewarming techniques
(HT II) consciousness* (warm environment; chemical, electrical, or forced air heating
(may or may not be packs or blankets; warm parenteral fluids) shivering) Cardiac and core temperature monitoring
Minimal and cautious movements to avoid dysrhythmias
Full­body insulation, horizontal position, and immobilization
Severe (HT Unconscious*, vital <28°C HT II management plus:
III) signs present Airway management as required
Preference to treat in an ECLS center, if available, due to the high risk of cardiac arrest
Consider ECLS in cases with cardiac instability that is refractory to medical management
Consider ECLS for comorbid patients who are unlikely to tolerate the low cardiac output associated with HT III
Hypothermic Vital signs absent Cardiac arrest is possible below 32°C; the risk CPR and up to three doses of epinephrine and defibrillation cardiac increases substantially below 28°C and (further dosing guided by clinical response) arrest continues to increase with ongoing cooling Airway management
(HT IV) Transport to ECLS†
Prevent further heat loss (insulation; warm environment; do not apply heat to head)
Active external and minimally invasive rewarming (see HT II) during transport is recommended but controversial; do not apply heat to head
Abbreviations: ECLS = extracorporeal life support; HT = hypothermia.
*Consciousness may be impaired by comorbid illness (e.g., trauma, CNS pathology, toxic ingestion) independent of core temperature.
†Transfering an HT IV patient to an ECLS center may reduce mortality by 40% to 90% (number needed to treat, ∼2); if ECLS is not available within a few hours of transport,7,9 consider on­site rewarming with hot packs or forced air blankets, warm IV fluid, ± warm thoracic lavage, ± warm bladder lavage, and ± warm peritoneal lavage; do not apply heat to the head.
PATHOPHYSIOLOGY
Body temperature is tightly regulated by a combination of behavioral, neuroendocrinologic, and cardiovascular responses to cold stress. Core temperature will fall when the amount of heat lost to the environment exceeds the amount of heat produced.
HEAT LOSS
Heat is lost from a warm body by conduction, convection, evaporation, and radiation. Conduction occurs when a warm body makes direct contact with a cold object. Conductive heat loss can be minimized by avoiding contact with cold or poorly insulated objects (e.g., metal backboards or stretchers).
Convective cooling occurs when a fluid (usually air or water) comes in contact with a warm body. The amount of heat lost via convection can be considerable and is proportional to the amount of fluid that flows around the body, the specific heat capacity of the fluid, and the temperature difference between the fluid and the body. Practically, the emergency physician needs to understand that exposure to cool air or water will result in heat loss, that water can absorb a large amount of heat in a short period of time, and that windy conditions or flowing water can significantly increase the rate of cooling. Evaporative heat loss occurs due to the energy required for water to phase change from a liquid to a gas. The amount of heat lost to evaporation is proportional to the temperature difference between the body and the air and the wind speed over the body and is inversely proportional to the humidity. Therefore, a warm, moist body exposed to cold, dry, windy air will lose a significant amount of heat. A vapor barrier (e.g., a plastic bag or sheet) placed around the patient effectively prevents evaporative cooling but is often not practical when repeated access to the patient’s skin is required. Radiant cooling occurs because all warm bodies “radiate” heat in the form of electromagnetic waves. Increasing the temperature of the room can minimize radiant heat loss, and some losses can be recovered using special reflective fabrics (likely low yield in most clinical situations). In summary, it is important to minimize heat loss in the hypothermic patient, and a basic understanding of the physics of heat transfer can be helpful. Practically, heat loss can be minimized by heating the room, removing wet clothes, drying the patient (or wrapping the patient in a vapor barrier), providing insulation, and protecting the patient from wind.
HEAT CONSERVATION AND PRODUCTION
The most important responses to cold include behavior (e.g., putting on warm clothing, seeking a warm environment), peripheral vasoconstriction, increased metabolic rate, and muscular thermogenesis (voluntary or shivering). Shivering is a remarkably efficient method of heat production, and care is required to preserve this important source of heat. Unfortunately, shivering can be suppressed by medications (e.g., analgesics, sedatives), by the application of warming devices (e.g., hot packs, forced air blankets, warm humidified air), if energy stores are exhausted, or if the core temperature drops below a critical level (∼31°C).  The suppression of shivering by various warming methods is one of the reasons why the rewarming literature is so controversial.
CONTINUED CORE COOLING
,11
Core temperature may continue to drop after a patient is removed from the cold environment, a process often referred to as afterdrop. The amount of continued core cooling will depend on the stage of hypothermia, the degree of thermoregulatory dysfunction, the ongoing cold stress
(often significant in the prehospital care environment), and the physics of heat transfer (heat from the relatively warmer core will be transferred to the cooler periphery by direct conduction or by convection from blood flow). Careful experimental studies have demonstrated an approximately 1°C drop
  in core temperature during minimally invasive rewarming when shivering is inhibited with narcotics or during exercise, but case series have not
,14 demonstrated any clinically significant afterdrop or morbidity when minimally invasive rewarming is used. In general, healthy uninjured patients who are able to shiver and have adequate fuel reserves (or can drink warm sweet drinks) will be able to self­rewarm once removed from further cold stress. In contrast, patients who have lost the ability to shiver are at significant risk of further temperature decline unless active rewarming is
,15,16 used. The use of aggressive immersion rewarming techniques such as hot baths or showers should likely be avoided due to the potential risks of
 vasodilatory hypotension or convective cooling.
SECONDARY HYPOTHERMIA
Cases of secondary hypothermia can be conveniently organized into those caused predominantly by increased heat loss, those caused predominantly by impaired thermoregulation, and those caused by multiple factors (Table 209­1). This classification is somewhat arbitrary, but in general, the multifactorial cases have a higher risk of missed diagnosis and are less likely to fully resolve with rewarming and supportive care. Iatrogenic causes of hypothermia deserve special attention, particularly in trauma patients, where the loss of just a few degrees of core temperature can create a profound
 coagulopathy and more than double patient mortality. Massive transfusion and large­volume crystalloid resuscitation are common iatrogenic causes of hypothermia unless proper fluid warmers are used. Inadequate insulation, repeated or prolonged exposure to the cool air of the resuscitation or operating room, and inadequate core temperature monitoring all contribute to iatrogenic heat loss, which may increase morbidity and mortality.
COLD PHYSIOLOGY
The body attempts to preserve normothermia through mechanisms such as increased metabolic rate, peripheral vasoconstriction, increased preshivering muscle tone, or shivering. As the core temperature drops below approximately 35°C, progressive impairment occurs, affecting all of the body’s organ systems. CNS impairment can progress from poor judgment, amnesia, and dysarthria to ataxia, apathy, unconsciousness, areflexia, and
 eventually electroencephalographic arrest. Paradoxical undressing is a potentially deadly behavior that occurs in up to 30% of fatal hypothermia
 cases. Below approximately 29°C, the pupils may become dilated and fixed, and below approximately 23°C, corneal reflexes may be absent; neither is
 reliable for neurologic prognosis in hypothermia.
Cardiorespiratory Responses
Cardiovascular responses to cold include profound peripheral vasoconstriction and an initial increase in heart rate and blood pressure, usually followed by progressive bradycardia, hypotension, and myocardial irritability. Below approximately 32°C, the risk of cardiac arrest increases as
 malignant cardiac dysrhythmias become more common, particularly below 28°C. The term rescue collapse is used to describe cardiac arrest that can commonly occur during extrication, transport, or treatment of a deeply hypothermic patient. The cause of rescue collapse is multifactorial, but ultimately related to the profound irritability of the cold myocardium. Atrial fibrillation and flutter are expected dysrhythmias and not necessarily
 markers of cardiac instability. ECG changes in hypothermia are variable but classically include bradycardia with prolonged PR, then QRS widening, and then prolonged QT . ECGs are often complicated by muscle tremors or shivering, and hypothermia can cause almost any heart block or atrial or c ventricular dysrhythmias. The classic Osborn J waves (Figure 209­1) usually occur below 32°C, can be misdiagnosed as ST­elevation myocardial
 infarction, and can also be caused by intracranial pathology or sepsis. Occasionally patients may be in a low­flow state, with a very difficult to detect pulse that may provide some oxygen delivery. Asystole is the common final dysrhythmia, but in accidental hypothermia, it does not exclude the
 possibility of a successful resuscitation.
FIGURE 209­1. ECG strip from a patient with a temperature of 25°C (77°F) showing atrial fibrillation with a slow ventricular response, muscle tremor artifact, and
Osborn (J) wave (arrow).
Respiratory changes include initial tachypnea, followed by a progressive decrease in minute ventilation and eventual respiratory arrest. Pulmonary edema is an inconsistent complication of hypothermia, but is common after resuscitation from stage IV hypothermia. The gradient between end­tidal carbon dioxide (ETCO ) and uncorrected partial pressure of arterial carbon dioxide increases variably in severe hypothermia, making the

 interpretation of ETCO and titration of ventilation parameters challenging in the absence of blood gas measurements.

Metabolic Responses
The renal response to hypothermia is termed cold diuresis and is a response to vasoconstriction­induced hypervolemia. It results in significant fluid
 losses, which may be further increased in patients with a history of cold water immersion or alcohol intoxication. Rhabdomyolysis is a potential
 complication of hypothermia ; however, the clinician should always exclude a missed compartment syndrome or extensive frostbite when an elevated creatine kinase is detected. Hypothermia can also cause muscle rigidity, termed pseudo­rigor mortis; hence, rigor mortis cannot be used as a reliable marker of death in the cold patient. Hypothermia has a somewhat dramatic impact on coagulation and blood viscosity, and these effects are often underrecognized by clinicians because blood samples are heated to 37°C prior to analysis. Coagulopathy is a concern below 34°C, particularly in
 trauma patients in whom hypothermia can compromise the chance for a surgical cure and exponentially increase mortality, partly due to poor
 activity of clotting factors and platelet dysfunction. Hypothermic patients can also be hypercoagulable from a combination of increased viscosity, hemoconcentration, and an inflammatory cascade similar to disseminated intravascular coagulation; these factors can put hypothermic patients at an
 increased risk for venous thromboembolic disease as well as coronary and cerebral artery occlusion.
Cellular oxygen consumption decreases as core temperature drops and, in an otherwise healthy patient who has adequate oxygen delivery prior to cooling, may provide protection against ischemia. It is estimated that cerebral oxygen requirements are approximately 50% at 28°C, 19% at 18°C, and
,24
11% at 8°C. This neuroprotective effect of hypothermia is exploited in certain cardiac surgeries. The most dramatic technique is deep hypothermic
 circulatory arrest, where patients are cooled to approximately 18°C and cardiac arrest is induced and maintained for up to approximately  minutes.
The combination of the potential to survive prolonged periods of ischemia, with the uncertainty of knowing if a patient has been in a low­flow state
(difficult to detect cardiac activity that provides some oxygen delivery) versus cardiac arrest, increases the complexity of termination of resuscitation decisions for hypothermic patients unless the history clearly indicates death prior to cooling.
CLINICAL FEATURES
Patients with hypothermia will feel cold to touch; they will have a core temperature less than 35°C and may have a history of cold exposure or a history of a condition associated with secondary hypothermia (Table 209­1). Hypothermia can be staged clinically using level of consciousness and vital signs
(Table 209­2). Measure the core temperature as soon as possible. If the core temperature deviates significantly from the clinical features of the stage, then consider alternative diagnoses. For example, if a patient has a core temperature of 33°C but is unconscious, hypothermia is unlikely the main cause of coma.
CORE TEMPERATURE MEASUREMENT
Make sure that the device being used to measure core temperature is capable of extreme measurements and is properly calibrated (thermistor devices are usually preferred). Temperature measurement at different body sites will yield different readings depending on local perfusion and environmental conditions. In the intubated patient, the lower third of the esophagus (∼24 cm below the larynx in an adult) is the preferred site for core temperature
 measurement, because it closely mirrors the cardiac temperature. In the absence of an esophageal probe, a rectal probe inserted to a depth of  cm or a bladder probe is adequate, but realize that these temperatures often lag behind true core temperature during rewarming and that bladder or peritoneal lavage may falsely elevate the reading. Oral and infrared tympanic temperature measurements do not correlate well with core temperature and should not be used. When an accurate core temperature measurement is not available, management decisions should be made based on clinical staging (Table 209­2). Ongoing core temperature monitoring should be implemented as soon as possible for all moderate to severe hypothermia patients (stages II to IV).
DIAGNOSIS
Hypothermia causes dysfunction of every organ system, so the potential list of differential diagnoses is broad. A practical approach is to focus the differential diagnosis using a combination of history, physical exam, and expected degree of dysfunction for the clinical stage and measured core temperature. For the patient with absent vital signs, if the history indicates normothermic cardiac arrest prior to cooling, then hypothermia can be excluded as the cause of cardiac arrest, regardless of the patient’s core temperature (Figure 209­2). Similarly, in the patient with absent vital signs, asystole, and an accurate core temperature above 32°C, accidental hypothermia is not the cause of cardiac arrest. Classic diagnostic dilemmas in relation to accidental hypothermia often revolve around impaired cognitive function, level of consciousness, or declaration of death. Intoxication, head injury, and CNS infection are three examples of conditions that impair neurologic function directly, but can also cause secondary hypothermia and cold­related neurologic dysfunction. Vigilance is required with any decreased level of consciousness, particularly if the degree of neurologic impairment does not match the stage of hypothermia. Areflexia or paralysis should not be attributed to hypothermia until spinal injury has been ruled out.
FIGURE 209­2. 
Transport and management of accidental hypothermia. CPB = cardiopulmonary bypass; DNR = do not resuscitate; ECMO = extracorporeal membrane oxygenation; HT = hypothermia; MD = physician; ROSC = return of spontaneous circulation; SBP = systolic blood pressure.
Carefully consider secondary causes of accidental hypothermia, particularly if the measured core temperature is lower than expected based on the cold exposure history or the patient is slow or fails to rewarm with appropriate therapy. Tachycardia or tachypnea can be a marker of secondary pathology in moderate and severe hypothermia (stages II and III), because bradycardia with or without bradypnea is the normal response to hypothermia below a core temperature of approximately 32°C. Intoxication and sepsis are two common causes of secondary hypothermia, and depending on the patient presentation, routine screening and, in some cases, empiric therapy may be reasonable. Classic causes such as adrenal failure and myxedema coma are comparatively rare, and empiric testing or therapy is likely unwarranted in the absence of good historical or laboratory evidence. Hyperglycemia that persists after rewarming may indicate secondary pathology such as diabetic ketoacidosis or pancreatitis. The appropriate breadth of workup will vary considerably depending on the particular patient and the degree of clinical uncertainty.
DECLARATION OF DEATH
Declaration of death in the presence of hypothermia is particularly challenging due to the ability of hypothermia to mimic death (can cause fixed and dilated pupils, stiffness resembling rigor mortis, absent reflexes, or respiratory arrest) or cause death that may be reversible. Figure 209­3 provides a triage tool for stage IV (absent vital signs) patients to assist with clinical decision making. In general, patients with obvious signs of irreversible death or who are frozen solid, have a history of normothermic arrest with subsequent cooling, or have a potassium level >12 mmol/L are extremely unlikely to
 benefit from resuscitative efforts, and death can be declared without rewarming. An exception to the above statement is the child with simultaneous normothermic cardiac arrest and very rapid accidental cooling (e.g., a child pinned underwater in an icy creek); in such a case, prolonged resuscitation
 and expert consultation may be appropriate (see “Children” under the “Special Considerations/Special Populations” section).
FIGURE 209­3. Triage tool for hypothermia (HT) patients with absent vital signs. CPB = cardiopulmonary bypass; DNR = do not resuscitate; ECMO = extracorporeal membrane oxygenation. [© Doug Brown, MD, FRCPC.]
LABORATORY TESTING AND IMAGING
Laboratory testing and imaging studies should be targeted based on history, physical examination, and the differential diagnosis. It seems reasonable that every hospitalized hypothermia patient undergo point­of­care glucose testing, but additional routine tests are not necessarily required. An ECG should be obtained for moderate and severe hypothermia (stages II and III) patients, and a chest radiograph is likely reasonable depending on the suspicion for conditions such as aspiration or pulmonary edema. For cases where secondary hypothermia is suspected, measuring CBC, serum electrolytes, creatinine, glucose, lactate, lipase, thyroid­stimulating hormone, random cortisol level, osmolality, and levels of potential intoxicants (e.g., ethanol, aspirin, acetaminophen) and calculation of the anion and osmolar gap may be reasonable depending on clinical suspicion. Patients with suspected sepsis may benefit from blood culture. For patients with suspected compartment syndrome, frostbite, or prolonged immobility, measure serum creatine kinase. Severe hypothermia (stages III and IV) patients should be considered critically ill, and therefore, expanded laboratory testing including CBC, electrolytes, pH, lactate, blood gas levels, and creatine kinase may be considered. For patients in cardiac arrest (stage IV), a serum potassium level ≥12 mmol/L is strongly associated with nonsurvival. 
HYPOTHERMIA EFFECTS ON LABORATORY VALUES
Laboratory results from hypothermic patients can be difficult to interpret due to the fact that high, low, or “normal” values may be appropriate in different patients. In an otherwise healthy patient with primary hypothermia, most laboratory values will normalize with rewarming; therefore, treat the patient, not the numbers. For complex cases or those that do not respond to usual therapy, it may be helpful to have a sense of the “expected” abnormalities associated with hypothermia. Hematocrit classically increases approximately 2%/°C, secondary to decreased circulating plasma
 volume. WBC counts may be normal or decreased due to sequestration or secondary causes such as sepsis. Electrolyte abnormalities are inconsistent, and cold blood may be prone to sampling hemolysis; hence, rewarming and ongoing monitoring are often the best strategy. Glucose levels are somewhat unpredictable, with an early rise being common secondary to catecholamine­induced gluconeogenesis and hypothermia­induced insulin
 resistance. This increase is classically followed by a drop with the onset of resource depletion and metabolic failure. Acid­base disturbances in hypothermia are complex; some hypothermic patients will be acidotic, whereas others may be alkylotic, and both conditions may be an appropriate
 physiologic response to cooling or may be a marker of secondary pathology. Blood gas analyzers rewarm samples to 37°C, and in rewarmed samples, the partial pressure of gases increases and the pH is lower, compared with the cold in vivo sample (correction usually not required; see stage III treatment for details). It is also important to note that the coagulopathy of hypothermia (see earlier section, “Cold Physiology”) will not be apparent on laboratory results due to the warming of samples prior to testing.
TREATMENT
Treatment of accidental hypothermia varies depending on the clinical stage, but the general principles include basic or advanced life support,
 prevention of further heat loss, transport to an appropriate facility if indicated, rewarming (Table 209­2 and Figure 209­2), and in secondary hypothermia, treatment of the underlying cause.
MILD HYPOTHERMIA (STAGE I)
Otherwise healthy stage I patients (conscious, shivering, core temperature ≥32°C) can often be rewarmed locally using a warm environment, provision of dry clothes, warm sweet drinks, and active movement. Stage I patients with traumatic injuries or significant medical comorbidities or in whom secondary hypothermia is suspected should be transported to the nearest appropriate hospital and managed as per stage II guidelines.
MODERATE HYPOTHERMIA (STAGE II)
Stage II patients (impaired consciousness, may or may not be shivering, core temperature ∼28°C to 32°C) require careful handling, prevention of further heat loss, active external and minimally invasive rewarming (warm environment; forced air, electrical, or chemical warming blankets; warm parenteral fluids), cardiac monitoring, and core temperature monitoring (Figure 209­4). Careful handling to decrease the risk of cardiac dysrhythmia becomes important for stage II and III patients, due to the increasing irritability of the cold myocardium. For all stages of hypothermia, warmed crystalloids (38°C to 42°C) should be titrated based on clinical volume status. Significant volume might be required during rewarming. Warmed IV fluids do not provide significant heat, but do prevent iatrogenic cooling. Atrial fibrillation, atrial flutter, and bradycardia are common in accidental hypothermia, do not usually require specific therapy, and typically resolve with rewarming. Vasopressors are usually not indicated in early resuscitation because hypothermia already provides maximal vasoconstriction and the addition of vasopressors may increase the risk of dysrhythmia. Vasopressors may be indicated later in resuscitation if rewarming­induced vasodilation cannot be managed with fluids and is contributing to significant hypotension. Special care is required when assessing the risk­to­benefit ratio of sedatives and analgesics. Many medications
 will inhibit shivering, decrease sympathetic tone, and/or cause vasodilatation, all of which can contribute to a further drop in core body temperature.
Depending on the stage of hypothermia, the degree of thermoregulatory dysfunction, the cold stress, and the physics of heat transfer, continued core cooling is possible despite appropriate treatment, particularly in the prehospital care setting. Such a failure to rewarm should trigger the clinician to reconsider secondary causes of hypothermia and ensure that ongoing heat losses have been ameliorated (uninsulated backboard, wet clothing, cool or windy environment) and that rewarming techniques are actually delivering significant heat.
FIGURE 209­4. Practical tips for rewarming patients with moderate and severe hypothermia. ECLS = extracorporeal life support. [© Doug Brown, MD, FRCPC.]
SEVERE HYPOTHERMIA (STAGE III)
Stage III (unconscious, vital signs present, core temperature <∼28°C) patients require the same treatment as stage II patients and may require intubation for airway protection (Table 209­2). The role of invasive vascular rewarming methods that do not support circulation (dialysis, venovenous extracorporeal membrane oxygenation (ECMO), and commercial temperature management systems) remains uncertain due to unproven benefits and
 the potential for procedure­ and device­related morbidity. The use of body cavity lavage rewarming has mostly been replaced by minimally invasive
 rewarming methods for stable patients and by extracorporeal life support (ECLS), where available, for unstable patients or those in cardiac arrest. For stable patients who are slow to rewarm, it is reasonable to use warm saline (38°C to 42°C) bladder lavage because the potential for morbidity is very low, particularly when compared with peritoneal, thoracic, gastric, or rectal lavage. The use of warm humidified gases for ventilation is recommended;
,30 however, it does not contribute significantly to rewarming. Other invasive interventions, such as advanced airway management and central line placement, should be performed if required, despite the slight risk of triggering a malignant dysrhythmia (avoid guidewire or catheter tip contact with
 the heart).
Stage III patients are at high risk for cardiac arrest, so patients with a core temperature <28°C, hypotension out of proportion to the degree of
,9 hypothermia, or ventricular dysrhythmias should be transferred to an ECLS center if one is available within a few hours of transport unless comorbidities, such as major trauma, necessitate transfer to an alternate center. For stage III patients with vital signs, the minimum sufficient circulation is unknown, and there is no accepted threshold to transition a potentially unstable patient with vital signs onto ECLS. In studies involving
 mostly healthy young people, patients with stable vital signs do well with minimally invasive rewarming, but in older comorbid populations (who may have poor tolerance for low cardiac output), there is emerging evidence that ECLS may be beneficial for certain patients with a core temperature <28°C
,33
(Table 209­3).
TABLE 209­3
Criteria for ECLS Rewarming in Severe Hypothermia (HT III) Endorsed by the International Commission for Mountain Emergency Medicine32
Failure to improve with external active and minimally invasive rewarming methods
Life­threatening dysrhythmia
Hypotension (systolic blood pressure <90 mm Hg)
Respiratory failure
Refractory acidosis
Abbreviations: ECLS = extracorporeal life support; HT III = hypothermia stage III.
Treat acid­base disturbances in hypothermic patients primarily by rewarming and reassessment. For the intubated patient, respiratory parameters should target an uncorrected partial pressure of carbon dioxide of  mm Hg (this is known as an alpha­stat strategy, where correction factors are not
,34,35 applied to account for the temperature difference between patient temperature and blood gas analysis temperature). In situations where blood gas measurement is not possible, the role of ETCO measurements to guide ventilation is unclear. Some authors suggest the values should not be

 ,32 used, while others suggest targeting normal ETCO . Further research is ongoing, and this author’s current practice is to use blood gas results
 when available and, in their absence, to follow the recommendations for hypothermic cardiac surgery and titrate ventilation to a temperature­
,37 corrected ETCO . Do not give bicarbonate to correct pH, unless there is a clear alternate indication, as in certain toxic ingestions.

HYPOTHERMIC CARDIAC ARREST (STAGE IV)
Because hypothermia induces a low­flow state, it can be challenging to detect a pulse in a hypothermic patient, so perform a careful check for signs of life. If any breathing, movement, or pulse is detected, watchful waiting and supportive care are recommended; otherwise, start CPR. High­quality CPR, prevention of further heat loss, and transfer to an ECLS center when possible are the most important priorities for stage IV patients. When transfer to
ECLS is definitely not available and the patient is in cardiac arrest, thoracic lavage with normal saline (38°C to 42°C) using a single or dual chest tube
 method may be the second­best rewarming strategy when combined with ongoing CPR.
Controversy exists regarding the use of epinephrine and defibrillation in hypothermic cardiac arrest. The European Resuscitation Council 2010 guidelines recommend up to three defibrillation attempts, to withhold epinephrine until the core temperature exceeds 30°C, and to double the dose
 frequency until the temperature is above 35°C. In contrast, the American Heart Association 2010 guidelines state that it may be reasonable to use
 vasopressors during cardiac arrest. Given the conflicting animal and human data that each recommendation is based on, a reasonable approach is to use standard advanced cardiac life support protocols for up to three cycles and, in the absence of clinical response, defer further defibrillation or epinephrine until core temperature increases significantly or the patient’s clinical status changes.
One of the major challenges with stage IV hypothermia is to select the patient with cardiac arrest caused by hypothermia for prolonged resuscitation while avoiding futile resuscitation for patients with normothermic cardiac arrest and subsequent cooling. Measuring a serum potassium >12 mmol/L or a core temperature >32°C can help to avoid futile resuscitation, but in their absence, the clinician is dependent on the history and physical to select the patients who may benefit from prolonged resuscitation (Figure 209­3).
Stage IV patients with return of spontaneous circulation should be rewarmed to ≥32°C and receive standard postarrest management  with
  consideration given to targeted temperature management or therapeutic hypothermia based on institutional preference. Patients rewarmed to
≥32°C without return of spontaneous circulation who are in asystole can be considered for termination of resuscitation in the absence of other causes of reversible cardiac arrest.
DISEASE COMPLICATIONS
Early complications are those that develop during the rewarming process, whereas late complications occur after rewarming. Most early complications have been described in the previous “Cold Physiology” section and can be minimized by handling patients carefully and using minimally invasive or extracorporeal rewarming techniques. Early ECLS­related complications are mostly related to cannulation and include bleeding, vessel perforation,
 dissection, and distal limb ischemia. Possible late complications are numerous and can affect most organ systems. Common respiratory complications include pulmonary edema and infection. Common cardiac complications include prolonged hypotension or dysrhythmias. A variety of neurologic injuries, such as seizure disorders, peripheral neuropathy, impaired cognitive function, or persistent vegetative state, are possible in cases of severe or prolonged ischemia. Similar to other critically ill patients, multiorgan failure is possible, including, but not limited to, acute respiratory
 distress syndrome, renal failure, liver failure, rhabdomyolysis, disseminated intravascular coagulopathy, bowel ischemia, and adrenal insufficiency.

With stage IV hypothermia, colder core temperatures and longer durations of CPR generally predict increased complications. Cardiac stunning and
 respiratory failure are two important potential late complications of stage IV hypothermia due to the potential need for prolonged ECLS or ECMO.
DISPOSITION AND FOLLOW­UP
Patients suffering from primary hypothermia who are rewarmed in the ED can be discharged home with routine follow­up by a primary care provider.
Patients suffering from secondary hypothermia may require admission or specialized follow­up depending on the nature and severity of the underlying condition. Patients who are unable to be rewarmed within a reasonable period of time will require admission with cardiac and core temperature monitoring (stage III and IV patients require a critical care setting).
SPECIAL CONSIDERATIONS/SPECIAL POPULATIONS
CHILDREN
Pediatric stage IV hypothermia patients require special consideration, and in general, expert consultation is warranted prior to termination of resuscitation. They have a larger surface area–to–body mass ratio, which means they have the potential to cool more rapidly than adults. Additionally, children may have an increased ability to tolerate and recover from hypoxic brain injury. Therefore, prolonged resuscitation may be indicated, even in cases of normothermic hypoxic cardiac arrest, if there is simultaneous very rapid cooling. The classic outlier in the literature is the case of a .5­yearold girl who went immediately under the water of a 5°C creek and suffered a normothermic hypoxic cardiac arrest but was rapidly cooled (pinned against a rock under fast­flowing cold water);  minutes later, she was removed from the water in cardiac arrest, received  hours of CPR, had a core
 temperature of 19°C, was successfully resuscitated using ECLS, and had a good neurologic outcome.
EXTRACORPOREAL LIFE SUPPORT OR EXTRACORPOREAL MEMBRANE OXYGENATION
The use of ECLS/ECMO for the management of stage IV hypothermia can dramatically improve survival for patients, with a number needed to treat of
,9 approximately  (absolute risk reduction of death, 50% to 90%). Well­selected patients treated in an ECLS/ECMO center have an approximately 50%
,40 to 100% survival rate, compared with a rate of approximately 10% to 30% if treated in a center without extracorporeal rewarming. Hypothermic patients have tolerated prolonged periods of CPR (≥5 hours) with a good neurologic outcome. ,41,42 The combination of improved outcomes with extracorporeal rewarming and the prolonged patient tolerance for CPR argue for the early identification of stage III and IV patients and priority transfer to an ECLS/ECMO center. Unfortunately, many physicians are not aware of this benefit, and many healthcare systems are not prepared to transfer patients in cardiac arrest. The creation of critical care pathways that outline triage, initial management, transport destinations, and care goals within a
 given healthcare system has the potential to improve outcomes, in a similar manner to cardiovascular care pathways. A New England Journal of

Medicine current concepts article provides a preliminary framework, but considerable local and regional work is still required to create a functional
 system. The provincial health authority in British Columbia, Canada, has implemented a regional clinical practice guideline and care pathway, and

Poland has improved patient outcomes by creating the world’s first dedicated centralized severe hypothermia treatment center.
DROWNING, AVALANCHE, AND TRAUMA
Drowning, avalanche burial, and trauma are three situations that warrant special consideration in the context of hypothermia. Patients removed from cold water should be extracted in a horizontal position in an effort to decrease the risk of orthostatic and hydrostatic changes triggering rescue collapse. The majority of drowning is submersion, where the patient immediately goes under the water, suffers a hypoxic cardiac arrest, and then
 develops hypothermia. With the exception of children, who may undergo simultaneous hypoxic cardiac arrest and rapid cooling, most submersion patients are unlikely to benefit from prolonged resuscitation (normothermic hypoxic cardiac arrest with brain death prior to cooling). The less common immersion patient may benefit from prolonged resuscitation; this patient is initially immersed in cold water but able to breathe air, cooling ensues, and the patient eventually suffers a presumed hypothermic cardiac arrest and may or may not become secondarily submerged. A case series of
 survival in adolescents with prolonged CPR after cold water immersion has been reported. See Chapter 215, “Drowning,” for detailed discussion of drowning.

With avalanche burial, most episodes of cardiac arrest are caused by asphyxia or trauma. Avalanche burial results in much slower cooling than cold water exposure, and it will take from  minutes to several hours for the patient’s core temperature to drop below 32°C (assuming initial normothermia). Therefore, if the patient is recovered in cardiac arrest after less than  minutes of burial, hypothermia is not the cause of cardiac arrest. For patients recovered after  minutes of burial, in the absence of obvious traumatic death, an airway packed with snow, or an accurate core temperature >32°C, accidental hypothermia may be the cause of cardiac arrest and prolonged resuscitation may be indicated. Cardiac arrest secondary
  to blunt trauma has a dismal prognosis (<1% survival), and a core temperature <35°C further increases the odds of death by at least .4. Therefore, it is reasonable to apply normothermic termination of resuscitation guidelines to patients suspected of blunt traumatic arrest, even in the presence of hypothermia.
AUSTERE ENVIRONMENTS
In the rare circumstances of stage IV hypothermia in an austere environment, when ongoing CPR during transport is not possible, it may be reasonable to transport without CPR (particularly if the patient has pulseless electrical activity) until such a time as CPR can be maintained or a definitive care center is reached. The decision to not perform CPR in an austere environment may be risky given that prehospital CPR is performed in the vast majority
,48 of stage IV hypothermia literature; however, there are two published cases that have shown good outcomes despite CPR interruptions and one
 case where CPR was not performed at all during transport. There is considerable controversy about whether or not to perform CPR for stage IV
,51 patients with pulseless electrical activity. It is this author’s opinion that the benefits of CPR far outweigh the risks for the patient with absent vital signs, regardless of the ECG findings.


