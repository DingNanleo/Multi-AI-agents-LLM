## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 55: Cardiomyopathies and Pericardial Disease
Manpreet Singh; James T. Niemann
INTRODUCTION
Content Update: Chagas Disease July 2023
American trypanosomiasis, or Chagas disease, is endemic in Latin America. As a result of globalization, urbanization, and migration, the disease is now seen worldwide and affects more than  million individuals. Pathophysiology, clinical features, and treatment are discussed in the section
‘Chagas Cardiomyopathy,’ below.
Content Update: Stress Cardiomyopathy and Takotsubo Syndrome February 2021
Stress cardiomyopathy and its commonest form, Takotsubo syndrome, is acute and transient left ventricular systolic and diastolic dysfunction after a stressful emotional or physical event. Common presenting symptoms are chest pain, dyspnea, and dizziness. ECG abnormalities can mimic STEMI.
Diagnosis is confirmed by echocardiography and by lack of culprit vessel involvement on coronary arteriography. See full discussion below under the section 'Cardiomyopathies with Systolic and Diastolic Dysfunction.'
The term cardiomyopathy describes a heterogeneous group of diseases that directly alter cardiac structure, impair myocardial function, or alter myocardial electrical properties. Discoveries in molecular genetics and the description of (ion) channelopathies as diseases have prompted periodic revisions of definitions and classifications of cardiomyopathies. The MOGE(S) classification is the most recently proposed and describes the morphofunctional phenotype (M), organ(s) involvement (O), genetic inheritance pattern (G), etiology (E; which includes genetic defect or underlying
,2 disease), and functional status (S). In simple terms, primary cardiomyopathies are diseases that solely or predominantly involve the myocardium and are usually familial in origin; the most common disorders are listed in Table 55­1. Secondary cardiomyopathies include heart muscle diseases associated with specific systemic disorders. Secondary cardiomyopathies often present with morphofunctional phenotypes and hemodynamic findings similar to those of the dilated or restrictive forms of cardiomyopathy. The most common causes of secondary cardiomyopathies are listed in
Table 55­2. As a group, cardiomyopathies are the third most common form of cardiac disease encountered in the United States, following coronary
(ischemic) heart disease and hypertensive heart disease. Hypertrophic cardiomyopathy is the second most common cause of sudden cardiac death
 in the adolescent population and the leading cause of sudden death in competitive athletes.
TABLE 55­1
The Primary Cardiomyopathies
Genetic
Hypertrophic cardiomyopathy
Arrhythmogenic right ventricular cardiomyopathy/dysplasia
Left ventricular noncompaction
Conduction system disease
Long QT syndrome
Brugada syndrome
Short QT syndrome

Idiopathic ventricular fibrillation
Chapter 55: Cardiomyopathies and Pericardial Disease, Manpreet Singh; James T. Niemann 
. Terms of Use * Privacy Policy * Notice * Accessibility
Mixed (genetic and nongenetic)
Dilated cardiomyopathy
Primary restrictive nonhypertrophied cardiomyopathy
Acquired
Myocarditis (inflammatory cardiomyopathy)
Stress (takotsubo) cardiomyopathy
Peripartum cardiomyopathy
TABLE 55­2
Common Causes of Secondary Cardiomyopathies
Toxins
Ethanol
Chemotherapeutic agents (doxorubicin)
Antiretroviral agents (zidovudine, didanosine)
Phenothiazines
Cocaine
Methamphetamine
Infiltrative diseases
Amyloidosis
Storage diseases
Hemochromatosis
Autoimmune disorders
Scleroderma
Systemic lupus erythematosus
Rheumatoid arthritis
Dermatomyositis
Metabolic
Nutritional deficiency (thiamine, selenium)
Endocrine (diabetes mellitus, hypothyroidism, hyperthyroidism)
Electrolytic disturbance (hypophosphatemia, hypocalcemia)
Neuromuscular disorders
Muscular dystrophy
Friedreich’s ataxia
An in­depth discussion of each of the primary familial and secondary cardiomyopathies is beyond the scope of this chapter, and emergency providers are unlikely to make a specific diagnosis in the ED. This chapter discusses selected cardiomyopathies (Table 55­3). Arrhythmogenic ventricular cardiomyopathy is discussed in Chapter 130, “Syncope, Dysrhythmias, and ECG Interpretation in Children.” The cardiomyopathies usually present with signs of systolic and diastolic ventricular dysfunction. The ED evaluation will generally guide the need for urgent treatment, admission, or referral for
 further diagnostic evaluation.
TABLE 55­3
Features of Selected Cardiomyopathies
Type Cardiomyopathy Type Clinical Features ECG
Systolic and Dilated cardiomyopathy Heart failure LVH diastolic Stress cardiomyopathy and Chest pain Poor R­wave progression dysfunction Takotsubo syndrome Regurgitant murmurs
Myocarditis Fever Nonspecific ST­T–wave changes
Tachycardia
Myalgias
Chest pain
Diastolic Hypertrophic Dyspnea on exertion LVH dysfunction cardiomyopathy Chest pain Large septal Q waves
Palpitations
Syncope
Pulsus bisferiens
Systolic ejection murmur, increases with Valsalva and decreases with squatting
Restrictive Presentation as heart failure with preserved EF; may be In some, low voltage of QRS; conduction cardiomyopathies confused with constrictive pericarditis disturbances; atrial fibrillation
Abbreviations: EF = ejection fraction; LVH = left ventricular hypertrophy.
CARDIOMYOPATHIES WITH SYSTOLIC AND DIASTOLIC DYSFUNCTION
DILATED CARDIOMYOPATHY
Epidemiology and Pathophysiology
Dilated cardiomyopathy is not a single disease but should be viewed as a nonspecific phenotype. It may be familial or occur with specific cardiac or systemic disorders (Tables 55­1 and 55­2). Peripartum cardiomyopathy most commonly manifests as dilated cardiomyopathy and is discussed in
Chapter , “Comorbid Disorders in Pregnancy.” The dilated cardiomyopathies are a major cause of heart failure and are a major indication for cardiac transplantation in the United States. Most patients with a familial form of dilated cardiomyopathy are diagnosed between the ages of  and  years,
 and the majority have advanced symptoms at the time of initial presentation.
Dilated cardiomyopathy is characterized by systolic and diastolic dysfunction and diminished left ventricular (LV) and, often, right ventricular contractile force, resulting in a low cardiac output and increased end­systolic and end­diastolic ventricular volumes. A decrease in ventricular compliance leads to an increase in intracavitary pressures. LV and, often, right ventricular dilatation accompanied by normal LV wall thickness are the hallmarks of dilated cardiomyopathy.
Clinical Features
As a result of systolic pump failure, the patient presents with signs and symptoms of heart failure: dyspnea on exertion, orthopnea, paroxysmal nocturnal dyspnea, bibasilar rales, and dependent edema. Depressed ventricular contractile function and dilatation may result in the formation of mural thrombi, and the patient may develop signs of peripheral embolization (e.g., an acute neurologic deficit, flank pain, and hematuria or a pulseless, cyanotic extremity). Chest pain, if present, is felt to be due to limited coronary vascular reserve rather than atherosclerotic coronary artery disease, but the cause cannot be distinguished clinically.
Murmurs may be heard during auscultation but do not necessarily indicate primary valvular disease. Annular dilatation and displacement of the papillary muscles of the atrioventricular valves inhibit complete valve closure. Holosystolic mitral or tricuspid regurgitant murmurs are frequently heard at the apex or lower left sternal border. An apical diastolic rumble may be heard and is due either to accentuated, early diastolic atrial­toventricular flow (the result of mitral regurgitation and left atrial overload) or to a loud summation gallop. The liver will be enlarged and pulsatile if tricuspid insufficiency is significant.
Diagnosis
The diagnosis may be suspected in patients with typical clinical history, physical exam, and radiographic and ECG findings, but the diagnosis is typically
,5 made at follow­up with echocardiography and additional testing as indicated by individual characteristics. The chest radiograph invariably shows an enlarged cardiac silhouette and increased cardiothoracic ratio. Biventricular enlargement is common. Evidence of pulmonary venous hypertension
(“cephalization” of flow and enlarged hila) is also frequent and may serve to differentiate cardiac enlargement due to myocardial failure from that due to a large pericardial effusion.
The ECG is almost always abnormal. LV hypertrophy and left atrial enlargement are the most common findings. Q or QS waves and poor R­wave progression across the anterior precordium may produce a pseudoinfarction pattern. Atrial fibrillation and ventricular ectopy are common rhythm disturbances.
Echocardiographic studies in a symptomatic patient demonstrate a decreased ejection fraction, increased systolic and diastolic volumes, and ventricular and atrial enlargement. Echocardiography is indicated when the cause of heart failure is uncertain, to exclude known causes of heart failure that may be correctable (e.g., pericardial effusion or valvular disease), to estimate ejection fraction, and to rule out other potential complications (e.g., mural thrombi) that may be amenable to therapy. The acuity of the patient’s presentation determines the urgency of echocardiography.
Treatment and Disposition
For the treatment of acute decompensated heart failure, see Chapter , “Acute Heart Failure.” Chronic therapy may include diuretics and digoxin, but
 these drugs do not appear to improve survival rates. Guidelines from the American College of Cardiology for the management of heart failure (and other cardiovascular disorders) are available online at https://www.acc.org/guidelines. The use of angiotensin­converting enzyme inhibitors and β­
 blockers, specifically carvedilol and metoprolol, improves survival in patients with dilated cardiomyopathy and heart failure. Selected patients may
 benefit from cardiac resynchronization therapy. Patients with complex ventricular ectopy who are found to be at risk for sudden cardiac death may
 benefit from amiodarone therapy or an implantable cardioverter­defibrillator. Implantable cardioverter­defibrillator placement for primary prevention of sudden cardiac death is not decided solely on ejection fraction, but also by consideration of family history of dilated cardiomyopathy,
 sudden cardiac death, and cardiac MRI.

Patients with a known dilated cardiomyopathy and chronic heart failure may present to the ED with a mild to moderate worsening of symptoms. If the cause is noncompliance with medical therapy or diet, ED treatment with nitrates, IV diuretics, reinstitution of prescribed medications, patient counseling, and timely referral to the primary care physician are appropriate. However, life­threatening causes of acute exacerbations, such as cardiac
 ischemia, should be considered before assuming benign causes. Acutely symptomatic patients require hospitalization for definitive diagnosis and management. Important subsets of patients with dilated cardiomyopathy are treated with LV assist devices while awaiting heart transplantation or as
,9 destination therapy. Principles of patient assessment and management and device complications are described in the Left Ventricular Assist
Devices box.
STRESS CARDIOMYOPATHY AND TAKOTSUBO SYNDROME
EPIDEMIOLOGY AND PATHOPHYSIOLOGY
Stress cardiomyopathy, the most common form being Takotsubo syndrome, is characterized by acute and transient left ventricular systolic and diastolic dysfunction following an emotional or physical stressful event. Symptoms typically occur within  hours of the event , and regional left ventricular wall motion abnormalities resolve within 2­3 weeks. Emotional stress is causative in postmenopausal women (90% of cases). Physical stress is a more common trigger in males. Incidence is approximately 15­30 cases/100,000/year. Stress cardiomyopathy may be misdiagnosed as acute coronary syndrome (ACS) and up to 2­6% of all cases of suspected ACS are later found to have stress cardiomyopathy.
The pathophysiology is thought to be due to the acute release of catecholamines from sympathetic and adrenal medulla stimulation. This leads to microvascular endothelial and myocyte dysfunction, with transient and reversible left ventricular dysfunction and secondary myocardial inflammation.
Anatomic variants of stress cardiomyopathy are described depending upon the distribution of wall motion abnormalities. The most common is apical
 ballooning (Takotsubo syndrome). Other forms include midventricular, basal, or focal wall motion abnormalities.
CLINICAL FEATURES
The most common symptoms are chest pain, dyspnea, and dizziness. Chest pain is similar to ACS. Dyspnea is due to pulmonary congestion. Dizziness or syncope are the result of decreased cardiac output and cerebral hypoperfusion. Ventricular dysrhythmias may be present and sudden cardiac death has been reported. Physical examination in moderate to severe cases reveals findings of left heart failure. A systolic ejection murmur may be heard if left ventricular outflow obstruction and mitral regurgitation are present, due to basal hypercontractility and systolic anterior movement of the anterior mitral leaflet. The ECG is abnormal in >90% of patients. Deep symmetric T wave inversion in the precordial leads with QT prolongation is the most common ECG abnormality and is usually seen within  hours of symptom onset. Precordial ST segment elevation suggesting anterior STEMI has been reported in up to 40% of cases. A diagnosis of stress cardiomyopathy is favored if ST elevation is also seen in lead aVR. ST segment depression is uncommon. Cardiac troponins are elevated in most patients. Natriuretic peptides are also usually increased and reflect the degree of wall motion abnormalities.
DIAGNOSIS AND TREATMENT
Diagnosis is based upon the history, ECG, biomarker elevation, echocardiography, and the absence of a culprit lesion on coronary arteriography. The echocardiographic findings are transient or reversible left ventricular dysfunction (hypokinesis, akinesis, or dyskinesis) with apical ballooning
(Takotsubo syndrome—about 80% of cases) or midventricular, basal, or focal wall motion abnormalities. The RV is rarely involved. The regional wall
,34 motion abnormality nearly always extends beyond the distribution of a single coronary artery.
There is no specific therapy, other than treatment of underlying heart failure. Avoid inotropic drugs if left ventricular outflow obstruction is observed during echocardiography. This is more commonly observed in patients with the Takotsubo variant with apical ballooning. Inotropic drugs may worsen the hypercontractility of the basal LV segments and lead to a fall in cardiac output. LV thrombus formation is a complication of the apical form and anticoagulation is recommended in such cases.
CHAGAS CARDIOMYOPATHY
EPIDEMIOLOGY AND PATHOPHYSIOLOGY
American trypanosomiasis, or Chagas disease, is endemic in Latin America and is estimated to affect about  million people worldwide, including
>200,000 now living within the United States. Chagas disease is caused by the parasite Trypanosoma cruzi, which is transmitted to animals and people through skin or mucous membrane contact with the feces of triatomine bugs. The bugs live in mud, adobe, and straw. During the night, they emerge to bite, especially biting the face—hence the name kissing bugs. The disease can also be transmitted through salads, raw fruits, and vegetables, as well as through blood transfusions and sharing of syringes. Myocarditis results from direct parasitic or immune­mediated involvement. African trypanosomiasis (sleeping sickness), caused by Trypanosoma brucei gambiense or rhodensiense, is transmitted by bites of the tsetse fly but is now an uncommon disease within Africa.
CLINICAL FEATURES
In the acute phase, most patients are asymptomatic or experience self­limited fever, malaise, vomiting, diarrhea, or mild hepatosplenomegaly over 8–
 weeks. Unilateral conjunctivitis with painless upper and lower eyelid edema, called Romaña sign, is a classic finding from facial bites. High­grade parasitism can lead to acute myocarditis, meningoencephalitis, and encephalomyelitis, especially in children and immunocompromised persons.
,36
Chronic disease develops 10–30 years after the acute infection, leading to dilated cardiomyopathy, thromboembolism, and sudden cardiac death.
Dilation of the entire GI tract can occur from presumed enteric nervous system involvement.
DIAGNOSIS
Patients with suspected or newly diagnosed Chagas disease require serologic confirmation (two different assays for anti–T cruzi immunoglobulin G— such as ELISAs, PCR, indirect immunofluorescence, or hemagglutination) combined with history, physical examination, and ECG. ECG findings include right bundle branch block with or without left anterior fascicular block. More intensive evaluation includes an echocardiogram, cardiac MRI, and 24­ hour Holter monitoring.
Treatment and Disposition
The goal is to eradicate parasite burden completely to prevent chronic disease. Treatment is benznidazole,  milligrams/kg, taken PO in  divided doses every  h for  days, with a maximum daily dose of 300 milligrams. Nifurtimox is an alternative agent. Treatment provides a 60–100% cure rate
,36 in the acute phase but lower rates in the indeterminate phase. Treatment is ineffective once established cardiac disease develops.
MYOCARDITIS (INFLAMMATORY CARDIOMYOPATHY)
PATHOPHYSIOLOGY
Myocarditis is a common cause of dilated cardiomyopathy but is discussed separately to highlight its acute presentation and individual therapy.
Myocarditis is inflammation of the heart muscle and is most frequently characterized pathologically by focal infiltration of the myocardium by
 lymphocytes, plasma cells, and histiocytes. Varying amounts of myocytolysis and destruction of the interstitial reticulin network are also seen.
Because many episodes are mild, they do not always come to medical attention. Table 55­4 lists some common infectious causes of myocarditis.
Myocarditis may be accompanied by pericarditis.
LEFT VENTRICULAR ASSIST DEVICES
Left ventricular assist devices (LVADs) were originally designed as a bridge to transplant in end­stage heart failure patients but offer long­term quality of life improvement for patients who are not candidates for transplant (destination therapy). LVADs augment left ventricular output in patients with severe cardiomyopathy. There are several models of LVADs in current use that share many similar features.
In all LVADs, the implanted pump transfers blood from the apex of the left ventricle to the proximal aorta (Figure 1). The pump is powered by an external power source (battery or bedside unit), which is connected to a controller. Both the battery and controller reside outside of the body and can be carried or worn by the patient. The controller drives the pump through a driveline, which connects the implanted pump to the external controller through a surgical incision in the abdominal wall.
Most contemporary LVADs use pumps that drive blood through a continuous­flow mechanism (e.g., axial or centrifugal flow), maintaining a normal mean arterial blood pressure in the absence of a palpable pulse. However, many patients may still retain some cardiac contractility; in these individuals, the LVAD serves to assist (and not replace) normal physiologic cardiac output, and a pulse may be present. Because the LVAD can (in some patients) maintain systemic perfusion even with minimal cardiac function, an LVAD patient can sometimes be clinically stable even in the setting of ventricular fibrillation. LVAD patients still rely upon reasonable right ventricular function to pump blood to the lungs.
Patients and families are thoroughly trained on the management of the LVAD and its complications, and they should be involved during patient
 assessment and management. It is important to call the patient’s LVAD coordinator as soon as possible to assist with management decisions; this information should be present in the patient’s travel bag, along with a spare controller and batteries.
CLINICAL FEATURES
LVAD patients should have a normal mean arterial pressure of approximately  to  mm Hg. Blood pressure can be assessed by a mechanical cuff or by Doppler US. If using a Doppler, remember that blood flow has to be continuous and not pulsatile. When auscultating the heart, the continuous whirr of the pump is heard.
The ECG should have discernible QRS complexes (Figure 2).
The LVAD is visible on a chest radiograph (Figure 3). Bedside US can be used to assess right ventricular function and to evaluate for pericardial effusion/tamponade. Plain imaging and CT scans are safe, but MRIs are contraindicated.
THE HEMODYNAMICALLY UNSTABLE LVAD PATIENT
CAN ONE PERFORM CHEST COMPRESSIONS ON AN LVAD PATIENT?

Chest compressions can potentially dislodge the LVAD from the heart and aorta, causing left ventricular rupture and intractable hemorrhage.
Evaluate for causes of pump failure or lack of perfusion first. Avoid chest compressions if at all possible unless absolutely necessary; use your clinical judgment.
Immediately auscultate the precordium to hear an audible “whirr,” which indicates that the pump is functioning. If nothing is heard, search for a cause of mechanical LVAD failure. With the help of family if needed, check and/or change the batteries and/or controller. Do not disconnect anything. If unable to restart the LVAD, start CPR with special attention to proper positioning. Avoid excessively deep
 compressions.
If the pump is audible and functioning, obtain a blood pressure (by automatic cuff or manual Doppler) and place the patient on a cardiac monitor and continuous pulse oximetry. If the LVAD model does not provide pulsatile flow, it is difficult to obtain a reading by pulse oximetry.
For hypotension or low­perfusion states (mental status, skin temperature/color, capillary refill, etc.), give a small bolus of normal saline because
LVADs are preload dependent. Assess for bleeding (most common reason for ED visit), especially from GI hemorrhage, due to either an acquired von
Willebrand disease, supratherapeutic anticoagulation, or a GI arteriovenous malformation. If hypotension persists despite adequate fluid resuscitation or in the presence of right ventricular failure or LVAD malfunction, initiate IV inotropes. Dopamine and dobutamine are reasonable first­line inotropes. Obtain an ECG to rule out right ventricular myocardial infarction or strain. Obtain standard laboratory studies as clinically indicated. Bedside US can assess for right ventricular dilatation or failure. If there is right ventricular strain, consider pulmonary hypertension or pulmonary embolism. Give heparin if pulmonary embolism or device thrombosis is suspected and bleeding has been excluded. Consider tissue plasminogen activator for pump thrombosis, especially if the patient is decompensating and peri­code.
Ventricular fibrillation or ventricular tachycardia in an unstable patient requires defibrillation/cardioversion using standard advanced cardiac life support energy recommendations. Do not place defibrillator pads over the driveline. If the patient is clinically stable, give amiodarone according to advanced cardiac life support protocols.
MEDICAL COMPLICATIONS
Medical complications include anemia, bleeding, thromboembolism, or infection. Anemia can be caused by hemolysis (erythrocyte destruction from the pump) or bleeding. LVAD patients are typically anticoagulated with warfarin to an INR target of  to . Bleeding and coagulopathy are investigated and treated with standard measures. LVAD patients are also at risk for thromboembolism, such as pulmonary embolism, stroke, and mesenteric ischemia, especially in the setting of suboptimal anticoagulation. Heparin is safe and indicated for such events once bleeding has been ruled out. Infection is a common complication, especially at the driveline exit site. Treat sepsis with volume resuscitation, blood cultures, and antibiotics.
FIGURE 
A left ventricular assist device carries blood from the left ventricle to the aorta.
The left ventricular assist device is attached to the descending branch of the aorta and to the bottom of the left ventricle. The pump is positioned below the heart, with flow into he aorta and out of the left ventricle. The pump is connected by a drive line to the a controller unit outside and at the right side of the body. A battery is worn in a holster hanging from the right shoulder and is attached to the controller unit.
FIGURE 
ECG of a patient with a left ventricular assist device. QRS is evident, and baseline shows some electrical interference from the pump. [ECG used with permission of Daniel Renner, MD.]
An E C G from a patient with a left ventricular assist device installed. The Q R S wave is evident and the baseline shows some electrical interference from the pump.
FIGURE 
Posteroanterior chest radiograph of a patient with a left ventricular assist device and an implantable defibrillator. The outflow conduit to the proximal aorta is not radiographically visible. [Image used with permission of Daniel Renner, MD.]
Null
TABLE 55­4
Common Infectious Causes of Myocarditis
Viral Agents Bacteria
Coxsackie B virus Corynebacterium diphtheriae
Echovirus Neisseria meningitidis
Influenza virus Mycoplasma pneumoniae
Parainfluenza virus β­Hemolytic streptococci (rheumatic fever)
Epstein­Barr virus Lyme disease
Hepatitis B virus
Human immunodeficiency virus
CLINICAL FEATURES
Fever, myalgias, headache, and sinus tachycardia, often out of proportion with fever, are common signs and symptoms. Heart failure develops in severe cases. With less extensive myocardial involvement, the clinical manifestations of systemic illness (fever, myalgias, headache, and rigors) may overshadow clinical signs of myocardial dysfunction, leaving the diagnosis unsuspected. Retrosternal or precordial angina­type chest pain may occur and is usually due to pericardial inflammation (myopericarditis). A pericardial friction rub may be heard.
DIAGNOSIS

The gold standard for diagnosis of myocarditis is endocardial biopsy, but this invasive modality is uncommonly used. The diagnosis is more commonly made clinically based on symptoms with supportive testing. The chest radiograph is usually normal or nondiagnostic. Cardiomegaly and pulmonary venous hypertension or pulmonary edema are present with severe disease. ECG changes include nonspecific ST­T–wave changes, ST­ segment elevation or PR depression from associated pericarditis, atrioventricular block, and QRS interval prolongation. Troponin or B­type natriuretic
 peptide may be elevated. Echocardiographic studies are also nonspecific, with myocardial depression and wall motion abnormalities in severe cases.

Newer imaging modalities include nuclear imaging with positron emission tomography and cardiac MRI.
TREATMENT AND DISPOSITION
Admission is usually indicated in all cases to monitor progression of disease. Treatment for idiopathic or viral myocarditis is supportive. Antibiotics are needed for myocarditis complicating rheumatic fever, diphtheria, or meningococcemia. Immunosuppressive therapy (e.g., prednisone, azathioprine,
 and others) may be of value in selected patients, but large trials have not consistently demonstrated benefit. Immunosuppressive therapy is usually reserved for more severe cases and is rarely begun in the ED. Although most patients have a good long­term prognosis, those with fulminant myocarditis have a worse outcome and worse LV function at follow­up.
CARDIOMYOPATHIES WITH DIASTOLIC DYSFUNCTION
HYPERTROPHIC CARDIOMYOPATHY
Epidemiology and Pathophysiology
Hypertrophic cardiomyopathy is now generally defined as “a disease state characterized by unexplained LV hypertrophy associated with nondilated ventricular chambers is the absence of another cardiac or systemic disease that itself would be capable of producing the magnitude of hypertrophy
 evident in a given patient.” The echocardiographic hallmark of the disease is LV wall thickening, usually >15 mm. Cardiovascular magnetic resonance
 is also useful for diagnosis. Additional echocardiographic findings that might be observed include asymmetric septal hypertrophy and systolic anterior motion.
The disorder is usually familial, with autosomal dominant inheritance, or it can occur sporadically. There is no apparent sex or ethnic predilection.
Hypertrophic cardiomyopathy is a clinically and genetically heterogeneous disease associated with more than 1500 mutations in more than  major
 genes. Particular genotypes have more rapidly progressive courses. More benign genotypes may be associated with substantial risk of stroke and mortality in the setting of atrial fibrillation. The prevalence in the general population is approximately  in 500. The annual mortality rate in the overall hypertrophic cardiomyopathy population is <1% per annum.
Hemodynamically, hypertrophic cardiomyopathy is characterized by abnormal LV diastolic function due to reduced compliance of the hypertrophied left ventricle. Decreased compliance is reflected by an increase in LV filling pressure. Cardiac output, ejection fraction, and end­systolic volumes are usually normal. Most clinical symptoms are the result of impaired diastolic relaxation and restricted LV filling.
Clinical Features
Dyspnea on exertion is the most frequent initial complaint and is due to exercise­induced sinus tachycardia, which results in an abrupt elevation of LV diastolic pressure and pulmonary venous hypertension due to decreased LV filling time. Additional symptoms include chest pain, palpitations, and syncope. A family history of death due to cardiac disease is not uncommon.
Chest pain in hypertrophic cardiomyopathy patients is due to an imbalance between the oxygen demand of the hypertrophied left ventricle and the
 available myocardial blood flow. In older patients, associated atherosclerotic coronary artery disease may further limit myocardial perfusion.
Precordial or retrosternal chest discomfort in hypertrophic cardiomyopathy may mimic angina pectoris or may be “atypical.” Response to nitroglycerin is poor and highly variable.
The hypertrophic cardiomyopathy patient may be aware of forceful ventricular contraction and complain of an abnormal heartbeat or “palpitations.”
Atrial fibrillation is poorly tolerated because of the increased importance of the atrial contribution to LV filling.
Jugular venous pressure is usually not elevated. However, a prominent a (atrial) wave may be noted on close inspection of the neck veins. The upstroke of the carotid arterial pulse is rapid and frequently biphasic or bifid (pulsus bisferiens). The apical impulse is sustained and hyperdynamic, and a presystolic lift is common.
The first and second heart sounds are usually normal, with an S heard in most patients. A systolic ejection murmur may occur and is heard best at the
 lower left sternal border or at the apex, and rarely radiates to the carotid arteries. Easily performed bedside maneuvers can be used to increase the intensity and duration of the murmur (Table 55­5).
Interventions that decrease LV filling and the distending pressure in the LV outflow tract or that increase the force of myocardial contraction accentuate the murmur of hypertrophic cardiomyopathy. Such interventions include standing and the strain phase of the
Valsalva maneuver. Maneuvers that increase LV filling (squatting, passive leg elevation, and hand grip) decrease the murmur. The murmurs of hypertrophic cardiomyopathy and mitral valve prolapse, when associated with murmur, are similar and are compared in Table 55­5. TABLE 55­5
Effect of Bedside Interventions on the Murmur of Hypertrophic Cardiomyopathy Compared to Mitral Valve Prolapse
Intervention Hypertrophic Cardiomyopathy Mitral Valve Prolapse
Valsalva maneuver (strain phase) Murmur increased Click closer to S , murmur increased

Standing after squatting Murmur increased Click closer to S , murmur increased

Passive leg elevation in supine patient Murmur decreased Click closer to S , murmur decreased

Hand grip Murmur decreased Click closer to S , murmur increased

Squatting Murmur decreased Click closer to S , murmur decreased

Diagnosis
The diagnosis may be suspected in the ED based on symptoms, family history, and physical exam findings and confirmed with cardiac MRI or echocardiography. The chest radiograph is usually normal or nonspecific. The resting ECG is nonspecific in most, often demonstrating LV hypertrophy and left atrial enlargement. Q waves >0.3 mV, termed septal Q waves, may be seen in anterior, lateral, or inferior leads. Q waves may mimic those seen after myocardial infarction (pseudoinfarction pattern). The polarity of the T wave can differentiate between hypertrophic cardiomyopathy septal Q waves and Q waves due to myocardial infarction. Upright T waves in those leads with QS or QR complexes are usually found in hypertrophic cardiomyopathy (Figure 55­1), whereas T­wave inversion in such leads is highly suggestive of ischemic heart disease.
FIGURE 55­1
Hypertrophic cardiomyopathy ECG findings. Deep S­wave voltage (28 mm S in V , large arrow) signifies left ventricular hypertrophy, and narrow septal

Q waves in V and V (arrowheads) are noted. T waves are upright in the leads with the septal Q waves, with upright T waves in leads V and V , typical of
    hypertrophic cardiomyopathy. This patient also has atrial flutter with 2:1 block. The additional P waves appear in the ST segments (small arrows).
[Reproduced with permission from Knoop KJ, Stack LB, Storrow AB, Thurman RJ (eds): The Atlas of Emergency Medicine, 3rd ed. New York: McGraw­
Hill; 2010; Fig .40B.]
The E C G depicts hypertrophic cardiomyopathy. There is a deep S­wave voltage which signifies left ventricular hypertrophy. There are narrow septal Q waves in V  and V  indicated by arrowheads. Upright T waves are noted in the leads with septal Q, V  and V , signifying hypertrophic cardiomyopathy. P waves appear in the S T segment indicated by small arrows.
Echocardiography plays a substantial role in the diagnosis of hypertrophic cardiomyopathy, in the correlation of the auscultatory and hemodynamic events with LV anatomic changes, and in defining inheritance patterns. Cardiac MRI is recommended when echocardiography is inconclusive in
 patients clinically suspected of having the disease and is also helpful in risk stratification.
Treatment and Disposition
The majority of patients with hypertrophic cardiomyopathy who seek medical care typically do so because of declining exercise tolerance, chest pain, or syncope. The patient who presents complaining of exercise intolerance or chest pain in whom the typical murmur of hypertrophic cardiomyopathy is heard should be referred for echocardiographic evaluation after other causes have been considered. Syncope in patients with hypertrophic cardiomyopathy typically occurs during or immediately after exercise. If hypertrophic cardiomyopathy is suspected in a patient with
,19 syncope, hospitalization is indicated. Syncope in patients with hypertrophic cardiomyopathy may presage sudden cardiac death. The diagnostic evaluation is extensive and includes echocardiographic studies as well as extended cardiac monitoring, exercise stress testing
,20 to assess blood pressure response, and tilt testing. Beta­blockers are the mainstay of therapy for symptomatic patients.
RESTRICTIVE CARDIOMYOPATHY
EPIDEMIOLOGY AND PATHOPHYSIOLOGY
Restrictive cardiomyopathy is most commonly idiopathic, but may be of genetic origin with autosomal transmission and due to mutations in cardiac
 sarcomere protein genes. A restrictive cardiomyopathy may also result from systemic disorders that cause infiltration of the myocardium, resulting in replacement or displacement of normal myocardium. Systemic diseases that may be associated with a restrictive cardiomyopathy include amyloidosis, sarcoidosis, hemochromatosis, progressive systemic sclerosis (scleroderma), carcinoid heart disease, endomyocardial fibrosis, and hypereosinophilic
 syndrome.
Restrictive cardiomyopathy is characterized by “restricted” ventricular filling, with normal or decreased diastolic volume of one or both ventricles.
Systolic function is usually normal, and ventricular wall thickness may be normal or increased, depending on the underlying cause. The restrictive cardiomyopathies may account for up to 15% of cases of heart failure with preserved ejection fraction. The hemodynamic hallmarks include (1) elevated LV and right ventricular end­diastolic pressure, (2) normal LV systolic function (ejection fraction >50%), and (3) a marked decrease followed by a rapid rise and plateau in early diastolic ventricular pressure observed during invasive hemodynamic assessment. The rapid rise and abrupt plateau in the early diastolic ventricular pressure trace produce a characteristic “square root sign” or “dip­and­plateau” filling pattern due to increased myocardial stiffness. This pattern is not diagnostic, however, and may be seen in constrictive pericarditis, with which restrictive cardiomyopathy is commonly confused. Differentiation between the two is critical because constrictive pericarditis can be cured surgically. The diagnosis of restrictive
 cardiomyopathy should be considered in a patient presenting with congestive heart failure but no evidence of cardiomegaly or systolic dysfunction.
CLINICAL FEATURES AND DIAGNOSIS
Symptoms are typical of heart failure and include dyspnea, orthopnea, and pedal edema. Right­sided heart failure may predominate and results in hepatomegaly, right upper quadrant pain, and ascites. Chest pain is uncommon, except in amyloidosis.
Findings on physical examination depend on the stage or severity of myocardial involvement. An S and an S are often heard. Pulmonary rales, jugular
  venous distention, Kussmaul sign (jugular venous pulse rises during inspiration rather than falling), hepatomegaly, pedal edema, and ascites are also typical findings. On chest radiograph, there may be signs of heart failure but a normal heart size. Chamber enlargement due to wall thickening, but not dilatation, and nonspecific ST­T–wave changes are usually noted on the ECG. Cardiac conduction disturbances are common in amyloidosis and sarcoidosis. Atrial fibrillation may occur in the setting of atrial enlargement. Low­voltage QRS complexes (QRS amplitude <0.7 mV) are frequently described in patients with restrictive cardiomyopathy secondary to amyloidosis and hemochromatosis. The differential diagnosis includes constrictive pericarditis or diastolic LV dysfunction (most commonly due to ischemic heart disease, hypertension, or age­related changes in ventricular diastolic compliance). Doppler echocardiographic studies, cardiac MRI, and cardiac catheterization with hemodynamic assessment are often required for
 specific diagnosis.
TREATMENT AND DISPOSITION

CT and MRI of the heart can differentiate constrictive pericarditis from restrictive cardiomyopathy. Correct diagnosis is important because constrictive pericarditis can be surgically corrected, and diastolic LV dysfunction usually responds well to beta­blockers or calcium channel blockers.
The medical management of restrictive cardiomyopathy is less effective and symptom directed (diuretics and angiotensin­converting enzyme inhibitors) unless due to sarcoidosis (corticosteroid therapy) or hemochromatosis (chelation therapy). The need for admission is usually determined by the severity of symptoms and the availability of diagnostics. Genetic testing is often recommended.
PERICARDIAL DISEASE
ANATOMY AND PATHOPHYSIOLOGY
The pericardium consists of a serous or loose fibrous membrane (visceral pericardium) overlying the epicardium and a dense collagenous sac (parietal
 pericardium) surrounding the heart. The space between the visceral and parietal pericardium may normally contain up to  mL of fluid. Because its layers are serosal surfaces and because of its proximity and attachments to other structures, the pericardium may be involved in a number of disease processes (Table 55­6). In this section, the clinical manifestations and evaluation of acute and constrictive pericarditis and nontraumatic cardiac tamponade are discussed.
TABLE 55­6
Common Causes of Acute Pericarditis
Idiopathic
Infectious
Viral (coxsackie virus, echovirus, human immunodeficiency virus)
Bacterial (especially Staphylococcus, Streptococcus pneumoniae, β­hemolytic streptococci [acute rheumatic fever], Mycobacterium tuberculosis)
Fungal (especially Histoplasma capsulatum)
Malignancy (leukemia, lymphoma, metastatic breast and lung carcinoma, melanoma)
Drug induced (procainamide, hydralazine)
Systemic rheumatic diseases (systemic lupus erythematosus, rheumatoid arthritis, scleroderma, polyarteritis nodosa, dermatomyositis)
Radiation induced
Postmyocardial infarction (Dressler’s syndrome)
Uremia
Myxedema
ACUTE PERICARDITIS
CLINICAL FEATURES
The most common symptom of acute pericarditis is sharp or stabbing precordial or retrosternal chest pain. Pain may be of sudden or gradual onset; radiate to the back, neck, left shoulder, or arm; and aggravated by inspiration or movement. Referral of pain to the left trapezial ridge (due to inflammation of the joining diaphragmatic pleura) is a particular distinguishing feature. Chest pain due to acute pericarditis may be aggravated by inspiration or movement. Typically, chest pain is most severe when the patient is supine and is relieved when the patient sits up and leans forward.
Associated symptoms may include fever, dyspnea due to accentuated pain with inspiration, and dysphagia from irritation of the esophagus by the
,25 posterior pericardium.
A pericardial friction rub is the most common and important physical finding in pericarditis, but may be difficult to appreciate in a noisy ED. It is best heard with the diaphragm of the stethoscope at the lower left sternal border or apex when the patient is sitting and leaning forward. It may be audible only during a certain phase of respiration and characteristically is intermittent. A pericardial friction rub is most often triphasic, with a systolic component due to ventricular contraction, an early diastolic component during the early phase of ventricular filling, and a presystolic component synchronous with atrial systole. It is less commonly biphasic, with a systolic component with either an early diastolic or presystolic component. A monophasic rub is less common but is most often systolic.
DIAGNOSIS
The ECG is the most important tool for initial diagnosis. Serial ECG changes during acute pericarditis and its convalescence are characterized by four stages (Table 55­7 and Figure 55­2A and B).
FIGURE 55­2
This series of three ECGs shows the typical progression of changes associated with acute pericarditis. A. In stage I pericarditis, the ECG shows diffuse
ST­segment elevation and PR depression in leads I, II, III, and aVF. The ST­segment to T­wave amplitude ratio measured in V is  mm/4 mm, or .50,
 thus meeting criteria for pericarditis rather than early repolarization (see the text under “Diagnosis”). B. In stage II pericarditis, ST segments are returning toward the isoelectric point in most leads in which they had been elevated. C. In stage III pericarditis, we see resolution of ST changes and the appearance of diffuse T­wave inversion. These evolutionary changes are typical of and diagnostic for pericarditis and usually occur over several weeks.
 E C G's depict the typical progression of changes associated with acute pericarditis. Example A depicts stage  pericarditis. Diffuse S T­ segment elevation and P R depression in leads , ,  and a V F. Example B depicts stage  pericarditis. S T­segment are returning towards the isoelectric point in most leads. Example C depicts stage  pericarditis. S T­segment resolution changes and the appearance of diffuse T­wave inversion.
TABLE 55­7
Serial ECG Changes of Acute Pericarditis
Stage PR Segment ST Segment T Wave
 Depression, especially in II, aVF, and Elevation, especially in I, V , and V ; ST amplitude: T­wave —

(acute) V –V
  amplitude >0.25
 Isoelectric or depressed Returns to isoelectric line Amplitude decreases, inversion rare
 Isoelectric or depressed Isoelectric T­wave inversion, especially in I, V ,
 and V

 Isoelectric Isoelectric Normal
If a large pericardial effusion develops during the course of acute pericarditis, low­voltage QRS complexes and electrical alternans may be evident.
Pericardial fluid attenuates myocardial electrical signals, and the pendular motion of the heart within the fluid­filled pericardial space results in electrical alternans (see Figure 55­5 in the “Nontraumatic Cardiac Tamponade” section of this chapter).
Although serial ECG tracings are of diagnostic value in acute pericarditis, sequential ECG assessment is not a diagnostic luxury afforded the emergency physician. The classic ECG findings in acute pericarditis include diffuse ST­segment elevation (most pronounced in the lateral precordial leads), PR­ segment depression, and ST­segment depression in lead aVR. ST­segment elevation is due to the inflammation of the epimyocardium. Classic ECG changes are not observed in uremic pericarditis because the epicardium is not involved in the inflammatory process. The ST­segment/T­wave
 amplitude ratio in leads V , or I can differentiate pericarditis from early repolarization. Using the end of the PR segment as a baseline, or  mV, the
 amplitude or height of the ST segment at its onset (the J point) is measured in V or lead I and recorded in millivolts. The height of the T wave in the
 same lead is measured from the baseline to the T­wave peak. If the ratio of ST amplitude (in millivolts) to T­wave amplitude (in millivolts) is >0.25, acute pericarditis is likely (Figure 55­2), and if the ratio is <0.25, acute pericarditis is unlikely. Sensitivity at an ST/T ratio of >0.25 for acute pericarditis is over
85%, and the specificity is over 80% (positive likelihood ratio of about  and negative likelihood ratio of about .2). Pericarditis alone does not cause significant cardiac rhythm disturbances.
Chest radiographs are of limited value. The cardiac silhouette may be of normal size and contour in acute pericarditis and, in some instances, the setting of cardiac tamponade. If previous chest radiographs are available for comparison, a recent increase in the size of the cardiac silhouette or an increase in the cardiothoracic ratio without radiographic evidence of pulmonary venous hypertension can distinguish an expanding pericardial effusion from left heart failure. The “epicardial fat pad sign” is rarely seen on the lateral chest radiograph and has been reported in only 15% of cases of acute pericarditis during fluoroscopy with image intensification. If acute pericarditis is suspected on the basis of history, physical examination, or
ECG, a chest radiograph may help establish an underlying cause, such as neoplasm or infection.
Echocardiography is the procedure of choice for the detection and confirmation. Normally, the pericardial sac is only a “potential” space, and the myocardium is echocardiographically in direct contact with surrounding thoracic structures. The anterior right ventricular wall is in contact with the chest wall, and the posterior LV wall is in contact with the posterior pericardium and adjacent pleura. When a pericardial effusion is present, the pericardial space fills with echo­free fluid (Figure 55­3). For serial follow­up of patients with acute pericarditis and a pericardial effusion, CT and
 cardiac MRI may be complementary.
FIGURE 55­3
A. Pericardial effusion on parasternal long­axis view. Ant Eff = anterior effusion; AV = aortic valve; LA = left atrium; LV = left ventricle; Post Eff = posterior effusion; RV = right ventricle. B. Pericardial effusion (arrows) on parasternal short­axis view. [Reprinted with permission from Reardon RF, Joing SA:
Cardiac, in Ma OJ, Mateer JR, Blaivas M (eds): Emergency Ultrasound, 2nd ed. Copyright ,
Figure 6­24.]
Null
Echocardiographically, a separation is seen between the right ventricle and the chest wall and between the left ventricle and the posterior pericardium.
Quantitation of the size of the effusion is arbitrary and is determined by where the hypoechoic space is seen (anterior or posterior) and when in the cardiac cycle it occurs. For example, when a hypoechoic space is seen only posteriorly and only during systole, a small effusion is said to be present.
The sensitivity of CT for detecting pericardial effusion is similar to that of echocardiography (Figure 55­4).
FIGURE 55­4
This CT scan of the chest shows a large pericardial effusion (pe) predominantly posteriorly located in a patient with scleroderma and pericarditis. No pericardial thickening or calcification was detected. Esophageal (e) dilatation is noted. Cardiac function cannot be evaluated. H = heart; L = liver.
[Reprinted with permission from Roldan CA: Connective tissue diseases & the heart, in Crawford MH (ed): Current Diagnosis & Treatment in Cardiology,
3rd ed. Copyright , Figure 33­5.]
Null
Suggested laboratory studies are listed in Table 55­8. Serum troponins may be elevated in acute pericarditis due to associated
 myocarditis.
TABLE 55­8
Ancillary Diagnostic Studies in Acute Pericarditis
Diagnostic Study Considerations
Cardiac markers Indicate myocardial involvement (epimyocarditis)
CBC and differential WBC count May suggest infection or leukemia
BUN/creatinine May suggest a diagnosis of uremic pericarditis
Chest radiograph Infiltrate or mass suggests infection or malignancy as etiology
Blood cultures If bacterial infection suspected
Serologic studies Antinuclear antibodies, anti­DNA titers, or rheumatoid factor in patients with systemic symptoms
Erythrocyte sedimentation rate, C­ Will not determine specific diagnosis, but can confirm clinical suspicion of pericarditis and can be followed serially reactive protein to assess response to therapy
Acute and convalescent viral May suggest viral origin; titers would not be expected to change the course of treatment antibody titers
Thyroid function studies Thyrotoxicosis is a rare cause of pericarditis; hypothyroidism can cause pericardial effusion without the typical ECG changes and symptoms of pericarditis
TREATMENT AND DISPOSITION
,25
Treatment of pericarditis depends on the cause. Most patients with idiopathic or presumed viral pericarditis have a benign course lasting  to  weeks. Symptoms respond well to NSAIDs administered for  days to  weeks. However, this class of drugs should be used with caution due to known
 risks of acute coronary syndromes. Corticosteroid treatment can alternatively be used for patients with poor NSAID tolerance, contraindication, or failure of NSAIDs. Colchicine, .5 milligram orally twice a day, may be a beneficial adjuvant and may prevent recurrent episodes and symptoms
 persistent at  hours. Hospitalization is not necessary in most cases. Indicators of a poor prognosis include temperature >38°C (100.4°F), subacute onset over weeks, immunosuppression, history of oral anticoagulant use, associated myocarditis (elevated cardiac biomarkers, symptoms of heart failure), failure to respond to therapy with NSAIDs after  week of therapy, a large pericardial effusion (an echo­free space >20 mm), or cardiac
 tamponade. In general, patients with these risk factors or with an enlarged cardiac silhouette on chest radiograph should be admitted for serial echocardiography to assess changes in effusion size, degree of hemodynamic compromise, and cardiac dysfunction.
NONTRAUMATIC CARDIAC TAMPONADE
PATHOPHYSIOLOGY
An increase in the amount of fluid within the pericardial sac results in an increase in intrapericardial pressure. The normal fibrocollagenous parietal pericardium has elastic properties and stretches to accommodate increases in intrapericardial fluid. The initial portion of the pericardial volumepressure curve is flat: Relatively large increases in volume result in comparatively small changes in intrapericardial pressure. The curve becomes
 steeper as the parietal pericardium reaches the limits of its distensibility. If fluid continues to accumulate, intrapericardial pressure rises to a level greater than that of the normal filling pressures of the right heart chambers. When this occurs, ventricular filling is restricted and results in cardiac tamponade. The point at which this occurs is determined by the rate of fluid accumulation, pericardial compliance (a thickened parietal pericardium is less distensible), and intravascular volume (hypovolemia lowers ventricular filling pressure). Common causes of cardiac tamponade in nontrauma patients are listed in Table 55­9. TABLE 55­9
Common Causes of Cardiac Tamponade in Medical (Nontrauma) Patients
Cause Approximate Frequency (%)
Metastatic malignancy 
Acute idiopathic pericarditis 
Uremia 
Bacterial or tubercular pericarditis 
Chronic idiopathic pericarditis 
Hemorrhage (anticoagulant) 
Other (systemic lupus erythematosus, postradiation, myxedema, etc.) 
CLINICAL FEATURES
Symptoms are nonspecific, and patients most commonly complain of dyspnea at rest and with exertion. Additional symptoms may be due to the underlying disease (e.g., uremia or tuberculous pericarditis).
Physical examination may reveal tachycardia and low systolic arterial blood pressure with a narrow pulse pressure. Pulsus paradoxus may also be
 present. A paradoxical arterial pulse is said to be present when the cardiac rhythm is regular and there are apparent dropped beats in the peripheral pulse during inspiration. There is usually a <10 mm Hg decrease in systolic blood pressure during inspiration in the supine position. A value >10 mm Hg usually separates true tamponade from lesser degrees of restricted cardiac filling. Pulsus paradoxus is not diagnostic of cardiac tamponade and may be noted in other cardiopulmonary processes. In cardiac tamponade, the neck veins may be distended with an absent “y” descent. The apical impulse is indistinct or tapping in quality. Cardiac auscultation may reveal “distant” or soft heart sounds. Pulmonary rales are usually absent, and there may be right upper quadrant tenderness from hepatic venous congestion.
DIAGNOSIS
The chest radiograph may or may not reveal an enlarged cardiac silhouette because this finding depends on the amount of intrapericardial fluid accumulation. The pulmonary vasculature typically appears normal. An epicardial fat pad sign may occasionally be seen within the cardiac silhouette.
The ECG usually shows low­voltage QRS complexes (<0.7 mV) and ST­segment elevation (due to the inflammation of the epicardium) with PR­segment depression, as in pericarditis. Electrical alternans (beat­to­beat variation in the amplitude of the P and R waves unrelated to the respiratory cycles;
Figure 55­5) is a classic but uncommon finding.
FIGURE 55­5
This rhythm strip (lead II, top tracing) and plethysmograph (bottom tracing) were recorded in a patient who presented with dyspnea, hypotension, and clinical and echocardiographic evidence of cardiac tamponade. A paradoxical pulse was noted on palpation of the radial artery. The amplitude of the R waves varies from beat to beat (electrical alternans).
The E C G depicts dyspnea, hypotension. There is a paradoxical pulse on the palpation of the radial artery. The amplitude of the R waves varies from beat to beat.
Suspect the diagnosis based on the clinical examination and chest radiographs. Echocardiography is the diagnostic test of choice. In addition to a large pericardial fluid volume, typical echocardiographic findings described in cardiac tamponade are right atrial compression, right ventricular diastolic
 collapse, abnormal respiratory variation in tricuspid and mitral flow velocities, and dilated inferior vena cava with lack of inspiratory collapse.
TREATMENT AND DISPOSITION
Volume expansion with a bolus of normal saline solution (500 to 1000 mL) will increase intravascular volume, facilitate right heart filling, and increase cardiac output and arterial pressure. However, it is a temporary measure. Pericardiocentesis is necessary for definitive therapy and for specific diagnosis.
If there is hemodynamic instability, emergency pericardiocentesis is indicated in the ED. The technique is described in Section , “Resuscitative
Procedures,” Chapter , “Pericardiocentesis.” (See Video: Pericardiocentesis.)
However, pericardiocentesis is optimally performed in the cardiac catheterization laboratory using echocardiographic guidance to avoid cardiac perforation and coronary artery laceration. In addition, fluid samples for culture, cytology, and so on can be obtained in a more controlled setting, and following needle aspiration, a pigtail catheter can be inserted to allow continuous fluid drainage and prevention of reaccumulation.
CONSTRICTIVE PERICARDITIS
PATHOPHYSIOLOGY
Constrictive pericarditis results from pericardial injury and inflammation, resulting in fibrous thickening of the layers of the pericardium, which
 prevents passive diastolic filling of the cardiac chambers. Some causes include postcardiac trauma with intrapericardial hemorrhage, after pericardiotomy (open heart surgery, including coronary revascularization), in fungal or tuberculous pericarditis, and in chronic renal failure (uremic pericarditis), but in most cases, a specific cause is not determined.
CLINICAL FEATURES

The symptoms of constrictive pericarditis usually develop gradually and may mimic those of congestive heart failure and restrictive cardiomyopathy.
However, clinical signs may occur early if fluid also accumulates within the thickened, noncompliant pericardial sac (effusive constrictive pericarditis).
Common signs and symptoms include exertional dyspnea, pedal edema, hepatomegaly, and ascites. Examination of the neck veins with the patient at a
45­degree angle from horizontal will reveal jugular venous distention and a rapid “y” descent of the cervical venous pulse. Elevated venous pressure is also seen in congestive heart failure, but a rapid “y” descent is infrequently encountered. The Kussmaul sign (inspiratory neck vein distention) is frequent in constrictive pericarditis but rare in congestive heart failure. A paradoxical pulse is uncommon, and its absence does not exclude constrictive pericarditis. On cardiac auscultation, an early diastolic sound, a pericardial “knock,” may be heard at the apex  to 120 milliseconds after the second heart sound. The pericardial knock sounds like a ventricular gallop, but occurs earlier than the S of congestive heart failure, which it may
 mimic. The knock is due to accelerated right ventricular inflow in early diastole and early myocardial distention, followed by an abrupt slowing of further ventricular expansion.
DIAGNOSIS AND DISPOSITION
On the ECG, low­voltage QRS complexes and inverted T waves are common, but there are no specific diagnostic ECG signs. Chest radiographs most commonly demonstrate a normal or slightly enlarged cardiac silhouette, clear lung fields, and little or no evidence of pulmonary venous congestion.
Pericardial calcification may be seen. Thoracic CT and MRI may also demonstrate a thickened pericardium.
On occasion, two­dimensional echocardiography may demonstrate pericardial thickening and abnormal ventricular septal motion in a patient with suspected constrictive pericarditis. However, its diagnostic utility is much less than that in a patient with acute pericarditis. Doppler echocardiography, cardiac CT, and MRI are preferred.
In many instances cardiac catheterization with measurement of intraventricular pressures will be required to confirm the diagnosis. A characteristic
 dip and plateau (the “square root sign”) of the right ventricular pressure trace is characteristic of the disease.
In cases of significant constriction and impaired ventricular filling, admission for pericardiectomy is the treatment of choice.


