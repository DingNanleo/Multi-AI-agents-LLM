## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 69: Acute Asthma and Status Asthmaticus
Tadahiro Goto; Kohei Hasegawa
INTRODUCTION AND EPIDEMIOLOGY
Asthma is a chronic inflammatory disorder characterized by increased responsiveness of the airways to multiple stimuli. In susceptible individuals, the inflammation causes recurrent episodes of wheezing, breathlessness, chest tightness, and coughing, particularly at night or in the early morning.
These episodes—acute asthma—usually have widespread and varying airflow obstruction.
Although most acute asthma episodes improve spontaneously or within minutes to hours with treatment, with symptom­free intervals in between, many patients with asthma develop chronic airflow limitation. This impacts the diagnosis and management of episodes and the attempts to prevent recurrent acute asthma.
Asthma affects approximately 8% of the U.S. population, is the most common chronic disease of childhood (9% prevalence), and has a similar
1­3 prevalence in developed nations around the world. Approximately one half of asthma cases develop before the age of  years, and another one third develop by the age of  years.
PATHOPHYSIOLOGY
Asthma sufferers have an abnormal accumulation of eosinophils, lymphocytes, mast cells, macrophages, dendritic cells, and myofibroblasts in airways. The pathophysiologic hallmark of asthma is a reduction in airway diameter caused by smooth muscle contraction, vascular congestion, bronchial wall edema, and thick secretions. These changes create pulmonary function changes, increased work of breathing, and abnormal distribution of pulmonary blood flow (Table 69­1). Large and small airways contain plugs composed of mucus, serum proteins, inflammatory cells, and cellular debris. Inflammation affects all bronchial pulmonary structures.
TABLE 69­1
Physiologic Consequences of Airflow Obstruction in Acute Asthma
Increased airway resistance
Decreased maximum expiratory flow rates
Air trapping
Increased airway pressure
Barotrauma
Adverse hemodynamic effects
Ventilation–perfusion imbalance
Hypoxemia
Hypercarbia
Increased work of breathing
Pulsus paradoxus
Respiratory muscle fatigue with ventilatory failure
Asthma is a continuum from acute bronchospasm through airway inflammation to permanent airway remodeling. Airway remodeling, with subbasement membrane thickening, subepithelial fibrosis, airway smooth muscle hypertrophy and hyperplasia, angiogenesis, and mucous gland

 hCyhpaeprtpelra 6si9a: aAncdu htey pAesrtshemcrae tainodn ,S ctaantu bse cAosmthem aa ttircigugse, rT faodr anhoinror eGveortsoi;b Kleo lhoesis H oaf sluengga fwuanction. 
. Terms of Use * Privacy Policy * Notice * Accessibility
Acute allergic bronchoconstriction results from immunoglobulin E–dependent release of mediators from mast cells. These mediators include
 histamine, leukotrienes, tryptase, and prostaglandins that directly contract airway smooth muscle. Bronchospasm induced by aspirin and other

NSAIDs also involves mediator release from airway cells. Airway inflammation occurs as inhaled antigens activate immunoglobulin E, mast cells, dendritic cells, T helper cells, and epithelial cells in the airway and induce inflammatory mediators and cytokines. In turn, this initiates a cascade of inflammatory response, which is multicellular, redundant, and self­amplifying.
Acute asthma is an exaggerated airway response to a variety of external exposures. Viral acute respiratory infections are the most common acute
  asthma stimulus, accounting for 40% to 80% of episodes in adults and 80% in children. Exercise is another common precipitant of acute asthma.
Environmental conditions, such as atmospheric pollutants and indoor antigens (e.g., mold, house dust mites, cockroaches, and animal dander), trigger acute asthma and may result in severe cases. Occupational exposures, such as metal salt, wood and vegetable dust, pharmaceuticals, industrial chemicals, plastics, biological enzymes, vapors, gases, and aerosols, also may stimulate acute asthma. Agents such as aspirin, β­blockers, and NSAIDs may prompt acute asthma. Exposure to cold air alone can induce acute bronchospasm. Endocrine factors, such as changing levels of estradiol and
 progesterone during the normal menstrual cycle and pregnancy, contribute to the level of airway reactivity. Emotional stress also can produce acute asthma.
CLINICAL FEATURES
Early recognition of acute asthma and treatment before the exacerbation becomes severe are the essentials of acute asthma management in the ED.
Focus the initial assessment on history and physical examination; for most patients, an objective assessment of lung function (e.g., peak expiratory flow rate [PEFR]) aids assessment. The typical symptoms of acute asthma include dyspnea, wheezing, and cough. Many, but not all, patients will relay
8­11 the history of asthma. Other historical features guide care for acute asthma (Table 69­2). In addition, because patients who are at the highest risk for fatal asthma require special attention, seek out risk factors for a fatal exacerbation. The severity of acute asthma is categorized based on clinical
8­11 features (Table 69­3).
TABLE 69­2
Key History Points in Patients With Acute Asthma8­11
Symptoms Pattern Disease History Risk Factors for Death From Asthma
Cough Perennial and/or seasonal Cigarette smoking Past history of severe exacerbation
Wheezing Continual or episodic Present management and medications ≥2 hospitalizations for asthma in the past year
Shortness of Onset Medication regimen adherence >3 ED visits for asthma in the past year breath
Chest tightness Duration History of corticosteroid use (chronic and/or >2 canisters per month of inhaled short­acting intermittent) β ­agonist

Sputum Frequency Intensive care admissions Difficulty perceiving airflow obstruction or its production severity
Fever Aggravating factors History of intubation Low socioeconomic status or inner­city resident
Usual pattern of exacerbation and Best spirometry measures Illicit drug use outcome
Psychiatric disease or medical comorbidities
TABLE 69­3
Classifying Severity of Acute Asthma in Patients Aged >12 Years Old and Adults* Symptoms and Signs Initial PEF (or FEV  ) Clinical Course
Mild Dyspnea only with activity PEF ≥70% predicted or Prompt relief with inhaled SABA.
personal best
Moderate Dyspnea interferes with or PEF 40%–69% predicted Relief from frequent inhaled SABA. Symptoms for 1–2 d after oral limits usual activity or personal best corticosteroids begun.
Severe Dyspnea at rest; interferes PEF <40% predicted or Partial relief from frequent inhaled SABA. Symptoms for ≥3 d after oral with conversation personal best corticosteroids begun.
Subset: life­ Too dyspneic to speak; PEF <25% predicted or Minimal or no relief from frequent inhaled SABA; IV steroids; adjunctive threatening perspiring personal best therapy; needs ED or intensive care unit.
∗
The presence of several parameters, but not necessarily all, indicates the general classification of the exacerbation. Many of these parameters have not been systemically studied, so they serve only as general guides.
Abbreviations: FEV = forced expiratory volume in  second; PEF = peak expiratory flow; SABA = short­acting β ­agonist.

Source:www.nhlbi.nih.gov/files/docs/guidelines/asthsumm.pdf (National Heart, Lung, and Blood Institute; National Institutes of Health; U.S. Department of Health and Human Services: NIH Publication Number 08­5846, October 2007, Fig. 20). Accessed June , 2018. Physical examination includes general appearance (e.g., respiratory distress, level of consciousness), vital signs (e.g., tachycardia, tachypnea), and chest findings (e.g., wheezing). Wheezing can be an unreliable indicator of airflow obstruction in acute asthma. A silent chest without wheezing occurs
 in extremely severe airflow obstruction. Use of accessory muscles, inability to speak in full sentences or phrases, and presence of pulsus paradoxus
 help identify severe acute asthma. Look also for concomitant illnesses (e.g., pneumonia, pneumothorax) or mimicking conditions such as upper airway obstruction from foreign bodies and vocal cord dysfunction (Table 69­4). The latter is a common reason why patients who fail therapy and have frequent ED return visits get labeled as having “refractory asthma”; such patients simply do not have lower airway disease.
TABLE 69­4
Important Asthma Mimickers
Acute heart failure (“cardiac asthma”)
Upper airway obstruction
Pulmonary embolism
Aspiration of foreign body or gastric acid
Tumors/disorders causing endobronchial obstruction
Interstitial lung disease
Vocal cord dysfunction
DIAGNOSIS AND PATIENT MONITORING
Physical examination findings and subjective symptoms do not necessarily correlate well with the severity of airflow obstruction, making objective measures valuable. Forced expiratory volume in  second (FEV ) and PEFR are key objective measures of severity of acute asthma. The FEV advantage
  is that in contrast to PEFR, it can help distinguish between poor effort, restrictive lung disorders, vocal cord dysfunction, and obstructive disorders
(e.g., asthma). PEFR measurements using peak flow meter provide a reasonable estimate of the severity of acute asthma in the ED. In addition, PEFR measurements help monitor the response to the treatment. Repeat either FEV or PEFR because comparing measures at ED presentation and  hour

,14 after treatment is the best predictor of hospitalization in patients with acute asthma. Patient education and cooperation are essential for these
8­11 measurements to be reliable.
Pulse oximetry assesses oxygen saturation during treatment. Arterial blood gas measurement is not needed in patients with mild to moderate asthma exacerbation and should be reserved for suspected hypoventilation with carbon dioxide retention and respiratory acidosis. With acute asthma, ventilation is stimulated, resulting in a decrease in partial pressure of arterial carbon dioxide (PaCO ); if a normal or slightly elevated PaCO (e.g., >42
  mm Hg) exists, think of extreme airway obstruction, fatigue, and potential acute ventilatory failure. Patients with impending respiratory failure almost always have clinical evidence of severe acute asthma or spirometry demonstrating a PEFR or FEV of <25% predicted. The use of capnography in acute
 asthma management is unclear. One small study reported good concordance between expired carbon dioxide levels measured by capnography and
  arterial carbon dioxide concentration, but another reported differences of up to >10 mm Hg between the two approaches.
Chest radiographs help to detect pneumothorax, pneumomediastinum, pneumonia, or other causes for symptoms (e.g., acute heart failure) or complications of acute asthma. Plain radiographs are not needed for all patients with acute asthma, but are better selectively used when there is suspicion for the previously mentioned conditions. In patients hospitalized for acute asthma, less than one third of patients have an abnormal chest
 radiograph.
A CBC is not routinely needed and likely will show modest leukocytosis secondary to administration of β­agonist therapy and/or corticosteroids. For patients with severe acute asthma (e.g., those hospitalized for acute asthma), serum total immunoglobulin E level and eosinophil quantification may
,19 aid chronic asthma management using biologic agents (e.g., anti–immunoglobulin E monoclonal antibody). Routine ECG is also unnecessary and often normal or nondiagnostic, but may reveal right ventricular strain, abnormal P waves, or nonspecific ST­ and T­wave abnormalities, which resolve with treatment. Use cardiac monitoring in older patients and those with coexisting heart disease.
ACUTE ASTHMA STANDARD TREATMENT
The goal is a rapid reversal of airflow obstruction by repetitive or continuous administration of inhaled β ­agonists, adequate oxygenation, and

8­11  decrease in inflammation. Figure 69­1 shows the National Asthma Education and Prevention Program ED treatment algorithm.
FIGURE 69­1. Management of asthma exacerbations: ED and hospital­based care. FEV = forced expiratory volume in  second; ICS = inhaled corticosteroid; MDI =
 metered­dose inhaler; PEFR = peak expiratory flow rate; SABA = short­acting β ­agonist; SaO = oxygen saturation by pulse oximetry. [Source:
  http://www.nhlbi.nih.gov/guidelines/asthma/asthgdln.pdf (National Heart, Lung, and Blood Institute; National Institutes of Health; U.S. Department of
Health and Human Services: National Asthma Education and Prevention Program, Expert Panel Report 3: Guidelines for the Diagnosis and Management of Asthma. Publication No. 08­4051. Bethesda, MD, National Institutes of Health, 2007). Accessed November , 2014.]
β­ADRENERGIC AGENTS
Rapid­onset β ­adrenergic agonists are the preferred initial therapy for acute bronchospasm (Table 69­5). Stimulation of β ­receptors increases rate
  and force of cardiac contraction, whereas β ­adrenergic stimulation promotes bronchodilation and vasodilation.

TABLE 69­5
β­Adrenergic, Anticholinergic, and Steroid Dosages of Drugs for Asthma
Medication Dose Comments
Inhaled β ­Agonists

Albuterol
Nebulizer solution (0.63 .5–5 milligrams every  min for  Only selective β ­agonists are recommended. For optimal delivery, dilute
 milligram/3 mL, .25 doses, then .5–10 milligrams every 1–4 aerosols to minimum of  mL at gas flow of 6–8 L/min. Use large­volume milligrams/3 mL, .5 h, as needed, or 10–15 milligrams/h as nebulizers for continuous administration. May mix with ipratropium milligrams/3 mL, .0 continuous nebulization.
nebulizer solution.
milligrams/mL)
MDI (90 micrograms/puff) 4–8 puffs every  min up to  h, then In mild­to­moderate exacerbations, MDI plus valved holding chamber is as every 1–4 h as needed. effective as nebulized therapy with appropriate administration technique and coaching by trained personnel.
Levalbuterol (R­albuterol)
Nebulizer solution (0.63 .25–2.5 milligrams every  min for  Levalbuterol administered in one half the milligram dose of albuterol milligram/3 mL, .25 doses, then .25–5 milligrams every 1–4 provides comparable efficacy and safety. Has not been evaluated for milligrams/3 mL) h, as needed. continuous nebulization.
MDI (45 micrograms/puff) See albuterol MDI dose.
Systemic (Injected) Agents
Epinephrine (α­ and β­agonist) .3–0.5 milligram every  min for  No proven advantage of systemic therapy over aerosol.
1:1000 (1 milligram/mL) doses SC or IM.
Terbutaline (β­agonist) (1  micrograms/kg may be given over  No proven advantage of systemic therapy over aerosol.
 min, followed by continuous infusion of milligram/mL)
 micrograms/kg/h.
Anticholinergics/Combinations
Ipratropium bromide
Nebulizer solution (0.25 .5 milligram every  min for  doses, May mix in same nebulizer with albuterol. Should not be used as first­line milligram/mL) then as needed. therapy; should be added to SABA therapy for severe exacerbations. The addition of ipratropium has not been shown to provide further benefit once the patient is hospitalized.
MDI (18 micrograms/puff) Eight puffs every  min, as needed, up Should use with valved holding chamber and facemask for children <4 y.
to  h. Studies have examined ipratropium bromide MDI for up to  h.
Ipratropium with albuterol
Nebulizer solution (each 3­mL  mL every  min for  doses, then as May be used for up to  h in the initial management of severe vial contains .5 milligram of needed. exacerbations. The addition of ipratropium has not been shown to provide ipratropium bromide and .5 further benefit once the patient is hospitalized.
milligrams of albuterol)
MDI (each puff contains  Eight puffs every  min as needed up to Should use with valved holding chamber and facemask for children <4 y.
micrograms of ipratropium  h.
bromide and  micrograms of albuterol)
Systemic Corticosteroids Applies to all  corticosteroids for oral medications.
Prednisone For inpatients: oral “burst,” use 40–80 For outpatients: oral “burst,” use 40–60 milligrams in  or  divided doses milligrams/d in  or  divided doses for 5–10 d.
until PEFR reaches 70% of predicted or personal best.
Methylprednisolone IV:  milligram/kg every 4–6 h. For outpatients: a single IM dose of 150 milligrams depot methylprednisolone may be used.19
Prednisolone 1–2 milligrams/kg/d for 5–10 d; may be More frequently used over prednisone in children due to increased divided twice daily. palatability of available liquid formulations.
Notes: There is no known advantage for higher doses of corticosteroids in severe asthma exacerbations, nor is there any advantage for IV administration over oral therapy provided GI transit time or absorption is not impaired.
The course of systemic corticosteroids for an asthma exacerbation requiring an ED visit or hospitalization may last from  to  days. For corticosteroid courses of <1 week, there is no need to taper the dose. For slightly longer courses (e.g., up to  days), there probably is no need to taper, especially if patients are concurrently taking inhaled corticosteroids. Inhaled corticosteroids can be started at any point in the treatment of an asthma exacerbation.
Abbreviations: MDI = metered­dose inhaler; PEFR = peak expiratory flow rate.
Source:http://www.nhlbi.nih.gov/guidelines/asthma/asthgdln.pdf (National Heart, Lung, and Blood Institute; National Institutes of Health; U.S. Department of
Health and Human Services: National Asthma Education and Prevention Program, Expert Panel Report 3: Guidelines for the Diagnosis and Management of Asthma.
Publication No. 08­4051. Bethesda, MD, National Institutes of Health, 2007). Accessed June , 2019. β­Adrenergic drugs cause bronchodilation by stimulation of the enzyme adenyl cyclase, which converts intracellular adenosine triphosphate into cyclic adenosine monophosphate. β­Adrenergic drugs also inhibit mediator release and promote mucociliary clearance.
The most common side effect of β­adrenergic drugs is skeletal muscle tremor. Patients also may experience nervousness, anxiety, insomnia, headache, hyperglycemia, palpitations, tachycardia, and hypertension. Clinical toxicity is rare and less common than undertreatment complications.
Provoking dysrhythmias or myocardial ischemia is sporadic, especially in those without a prior history of coronary artery disease. The early­generation bronchodilators, such as epinephrine, are not β specific and have a short duration of action.

Albuterol (racemic mixture) and levalbuterol (isomer form, Xopenex®) are β ­adrenergic drugs. Both racemic albuterol and levalbuterol can be given as

20­22 intermittent or continuous nebulization. Levalbuterol costs  to  times more than albuterol, and it has no clear advantage over albuterol regarding improvement in symptoms, hospitalization, or tachycardia.
Aerosol therapy with β ­adrenergic drugs produces excellent bronchodilation and is favored over oral or parenteral routes. The aerosol route achieves
 topical administration of a relatively small dose of drug, thereby producing local effects with minimum systemic absorption and fewer side effects.

Aerosol delivery occurs with a metered­dose inhaler coupled to a spacing device or with a compressor­driven nebulizer. A spacing device attached to the inhaler improves drug deposition; when optimally used, metered­dose inhaler therapy delivers the most drug to target airways, better than nebulized therapy. Even with optimum technique, a maximum of 15% of the drug dose is retained in the lungs, regardless of the aerosol
 method used. Give aerosol treatments every  to  minutes or on a continuous basis. SC epinephrine and terbutaline are options for patients unable to coordinate aerosolized or metered­dose inhaler treatments, seen often in severe airflow­limited states. IV β­agonist infusions offer no
 advantage over aerosolized or metered­dose inhaler–delivered agents and carry an increased risk of systemic side effects.
Salmeterol xinafoate and formoterol are long­acting β ­adrenergic agonists that bind with greater affinity to the β ­receptor site than albuterol.

These are maintenance, not acute, therapy. Bronchodilator effects last at least  hours, and tachyphylaxis is undocumented with long­term use. Longacting β ­adrenergic agonists are an effective treatment for long­term control of asthma, especially in conjunction with inhaled corticosteroids. Use
 short­acting β ­adrenoreceptor agonists (e.g., albuterol) for infrequent or breakthrough symptoms that occur despite the use of long­acting β ­

8­11,24 adrenoreceptor agonists.
CORTICOSTEROIDS
Corticosteroids produce beneficial effects by restoring β­adrenergic responsiveness and reducing inflammation and are used in all but mild, easily fully reversed episodes of acute asthma. The peak anti­inflammatory effect occurs at least  to  hours after IV or PO administration. Early use is wise;
 corticosteroids given within  hour of arrival in the ED reduce the need for hospitalization. Although there is disagreement over the optimal dose in acute asthma, an initial dose of POprednisone of  to  milligrams or IV methylprednisolone of  milligram/kg is sufficient, and higher­dose
,27 corticosteroid therapy has no clear advantage. Give patients who are being discharged home after ED treatment a 5­ to 10­day nontapering course of prednisone (40 to  milligrams/d in a single daily dose or its equivalent) or a 2­day course of oral dexamethasone (16 milligrams/d
8­11,28­30  in a single daily dose). A single dose of depot methylprednisolone, 150 milligrams IM, is another option if compliance is a concern.
8­11,32
Current recommendations are to use inhaled corticosteroids for all patients with mild persistent asthma or more severe chronic asthma. This
33­35 means discharging patients with mild persistent or more severe asthma on maintenance inhaled corticosteroids in addition to any systemic bursts.
Inhaled corticosteroid options are beclomethasone,  to 240 micrograms/d; budesonide, 180 to 600 micrograms/d; flunisolide, 500 to 1000 micrograms/d; fluticasone,  to 264 micrograms/d; mometasone, 200 micrograms/d; and triamcinolone acetonide, 300 to 750 micrograms/d.
ANTICHOLINERGICS
Anticholinergics are additive therapy to β­adrenergic agents in ED patients with acute asthma. Anticholinergics affect large, central airways, whereas β­ adrenergic drugs dilate smaller airways.
The anticholinergic commonly used is inhaled ipratropium bromide, available as a nebulized solution and a metered­dose inhaler or in combination
8­11 8­ with albuterol (Table 69­5). Use an aerosolized ipratropium bromide solution, .5 milligram, in ED patients with moderate to severe exacerbation.

Adding multiple doses of ipratropium bromide to a short­acting selective β­agonist may improve bronchodilation and decrease
  the rate of hospitalization among patients with moderate­to­severe acute asthma, although this benefit is not universal.
Potential side effects with anticholinergics include dry mouth, tachycardia, restlessness, irritability, confusion, difficulty in micturition, ileus, blurring of vision, and an increase in intraocular pressure. Long­acting anticholinergic agents have no role in acute asthma care.
FOLLOW­UP OF PATIENTS WITH ACUTE ASTHMA
Disposition decisions should take into account a combination of subjective parameters, such as resolution of wheezing and improvement in air exchange, as assessed by auscultation and patient opinion; objective measures, such as normalization of PEFR; and historical factors, such as compliance, history of ED use, and hospitalization. Some degree of residual airflow obstruction, airway lability, and inflammation persists after treatment and discharge from the ED.
Advise discharged patients to use a short­acting β­agonist on a scheduled basis for several days and to complete any oral corticosteroid regimens.
33­35
Start inhaled corticosteroids in patients with a history of persistent asthma not already using this regimen.
A good response to treatment resolves symptoms and results in PEFR of >70% predicted; these patients can be safely discharged home. Patients with a poor response to treatment have persistent symptoms and FEV or PEFR of <40% predicted; these patients are usually best
 observed or hospitalized. An incomplete response to treatment, the middle ground, commonly has some persistence of symptoms and FEV or

PEFR between 40% and 69% predicted. Most patients with asthma treated in the ED fall into this category and may be discharged home safely, although
8­11 some benefit from prolonged observation or hospitalization (Table 69­2). Patients who fail to improve adequately over a period of several hours because they are in the late phase of their exacerbation and those with significant risk factors for death from acute asthma are best placed in an
 observation unit or hospital bed. Many patients can be successfully treated in an ED observation unit with evidence­based care protocols.
Arrange follow­up care by primary care physician or asthma specialist (within  to  weeks) to ensure resolution and to review the long­term
8­11 medication plan for the chronic management of asthma. Deliver an appropriate written discharge plan of action that addresses routine care and care of worsening symptoms (Table 69­6). Educate patients on asthma triggers (including smoking cessation education if indicated), and review all discharge medications and the correct use of the inhaler and a peak flow meter (for daily tracking).
TABLE 69­6
Checklist for ED Discharge in Patients With Acute Asthma
MD/RN
Intervention Dose/Timing Education/Advice
Initials
Inhaled medications Select agent, dose, and frequency (e.g., albuterol). Teach purpose.
(e.g., MDI with valved holding chamber; nebulizer)
Short­acting β ­ 2–6 puffs every  h for until symptoms completely Teach and check technique.
 resolve.
agonist
Corticosteroids Low to medium dose for patients with chronic For MDIs, emphasize the importance of using a spacing persistent asthma. device or holding chamber.
Oral medications Select agent, dose, and frequency (e.g., prednisone Teach purpose.
 milligrams once a day for  d). Teach side effects.
Peak flow meter For selected patients: measure a.m. and p.m. peak Teach purpose.
expiratory flow, and record best of  tries each Teach technique.
time. Distribute peak flow diary.
Follow­up visit If possible, make appointment for follow­up care Advise patient (or caregiver) of date, time, and location of with primary clinician or asthma specialist or advise appointment, ideally within  d of hospital discharge.
patient to make appointment in 1–4 wk.
Action plan Before or at discharge. Instruct patient (or caregiver) on simple plan for actions to be taken when symptoms, signs, and peak expiratory flow values suggest recurrent airflow obstruction.
Abbreviations: MD = physician; MDI = metered­dose inhaler; RN = nurse.
Sources: National Heart, Lung, and Blood Institute; National Institutes of Health; U.S. Department of Health and Human Services.
STATUS ASTHMATICUS (ACUTE SEVERE ASTHMA)
Status asthmaticus is an acute severe asthma that does not improve with usual doses of inhaled bronchodilators and corticosteroids. Findings include hypoxemia, tachypnea, tachycardia, accessory muscle use, and wheezing (although this may be absent when airflow is severely reduced). Rapid and aggressive bronchodilator treatment is the key to preventing cardiopulmonary arrest. In addition to bronchodilators and early corticosteroids, other treatment adjuncts are often necessary.
MAGNESIUM

IV magnesium sulfate can aid the management of acute, very severe asthma (FEV or PEFR of <25% predicted). The magnesium dose is  to  grams IV
 over  minutes. Nebulized magnesium is effective and may improve pulmonary function in severe acute asthma when it follows aggressive β­agonist
39­41 and corticosteroid therapy. Dosing regimens vary; one regimen is  milligrams of nebulized magnesium sulfate in four divided doses  minutes
 apart, and another is 384 milligrams of nebulized magnesium sulfate in sterile water. When using magnesium in any form, monitor blood pressure
 and deep tendon reflexes during administration because hypotension or neuromuscular blockade may occur, although this is exceptionally rare in the doses recommended.
NONINVASIVE POSITIVE­PRESSURE VENTILATION
Noninvasive positive­pressure ventilation (see Chapter , “Noninvasive Airway Management and Supraglottic Airways”) improves airflow and
,44 respirations compared with usual care. Despite little research, it is commonly used in clinical practice for status asthmaticus. Noninvasive positive­
 pressure ventilation may decrease the need for tracheal intubation and result in clinical improvement. Do not institute noninvasive positive­pressure ventilation when altered sensorium or near respiratory collapse exists; those situations require intubation. Exclude pneumothorax before beginning noninvasive positive­pressure ventilation.
KETAMINE
Ketamine inhibits reuptake of noradrenaline and increases circulating catecholamines, aiding some with severe acute asthma. An IV bolus dose of .15
 milligram/kg followed by an infusion of .25 milligram/kg/h is sometimes used. If intubation is needed, ketamine is a premedication and/or sedative agent to aid during the procedure and after mechanical ventilation starts. There are limited controlled trial data on ketamine and outcomes in treating severe acute asthma.
EPINEPHRINE
Although epinephrine is standard treatment for anaphylactic asthma, it is an adjunct to treat status asthmaticus. Give epinephrine SC or IM, .5
 milligram, in adults (standard adult EpiPen® dose) for refractory situations.
MECHANICAL VENTILATION
If the patient manifests progressive hypercarbia or acidosis or becomes exhausted or confused, intubation and mechanical ventilation (see Chapter
29A and 29B, “Tracheal Intubation and Mechanical Ventilation”) are necessary to prevent respiratory arrest. Mechanical ventilation does not relieve the airflow obstruction—it merely reduces the work of breathing and enables the patient to rest while the airflow obstruction is resolved.
The potential complications of mechanical ventilation in patients with acute asthma include high peak airway pressures with subsequent barotrauma and hemodynamic impairment (e.g., decreased preload). Mucous plugging is frequent, leading to increased airway resistance, atelectasis, and obstructive pneumonia. Due to the severity of airflow obstruction during the early phases of treatment, the tidal volume may be larger than the returned volume, leading to air trapping and increased residual volume (intrinsic positive end­expiratory pressure). Using rapid inspiratory flow rates at a reduced respiratory frequency (12 to  breaths/min) and allowing adequate time for the expiratory phase can mitigate these effects. Also, it is reasonable to target adequate arterial oxygen saturation (≥90%) without concern for “normalizing” the hypercarbic acidosis. This approach is called controlled mechanical hypoventilation or permissive hypoventilation. Ventilation of patients with acute asthma requires sedation. Neuromuscular
 blocking agents may be required, but extended use may cause postextubation muscle weakness.
AGENTS OF UNCERTAIN OR NO BENEFIT IN STATUS ASTHMATICUS
Heliox

A mixture of 80% helium and 20% oxygen (heliox) can lower airway resistance and aid treatment of severe acute asthma. Although there is no role for
,48 this intervention in routine care, it is an option for patients who do not respond to standard therapy.
Methylxanthines

Aminophylline (5 milligrams/kg IV over  minutes) is no longer a first­ or second­line treatment for acute asthma. The most common side effects of methylxanthines are tachycardia, nervousness, nausea, vomiting, anorexia, and headache. At plasma levels >30 milligrams/mL, there is a risk of seizures and cardiac dysrhythmias.
Other Agents
Mast cell modifiers, such as cromolyn and nedocromil, exert their anti­inflammatory action by blockage of chlorine channels, modulating mast cell mediator release and eosinophil recruitment. These agents inhibit early and late responses to allergen challenge and exercise. Neither is indicated for treatment of acute bronchospasm.
Leukotrienes are potent proinflammatory mediators that contract airway smooth muscle, increase microvascular permeability, stimulate mucus secretion, decrease mucociliary clearance, and recruit eosinophils into the airway. Several leukotriene modifiers, such as montelukast, zafirlukast, and zileuton, are available as oral medications for the treatment of asthma. Leukotriene modifiers improve lung function, diminish symptoms, and diminish the need for short­acting β ­agonists. They may be used as an alternative to low­dose inhaled corticosteroid therapy in mild persistent

7­10 asthma and as steroid­sparing agents with inhaled corticosteroids in moderate persistent asthma. Despite trials with adjuvant IV montelukast for
,51 acute asthma, there is limited evidence to support a role for PO or IV leukotriene modifiers in acute asthma management.


