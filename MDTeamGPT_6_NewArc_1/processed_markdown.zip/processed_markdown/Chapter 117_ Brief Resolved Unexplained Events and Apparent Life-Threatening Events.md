## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 117: Brief Resolved Unexplained Events and Apparent Life­Threatening
Events
Ilene Claudius; Joel Tieder
DEFINITIONS
It is quite common for infants to have events that are brief, self­resolved, and difficult to characterize. Sometimes these events appear respiratory, cardiovascular, or neurologic in origin, and caregivers may seek medical attention for reassurance that the event is not a sign of a serious underlying condition. Through a comprehensive history and physical, clinicians can explain many of these events as a benign or normal process such as choking or gagging from feeding or gastroesophageal reflux. Sometimes, however, the event remains poorly understood or unexplainable, and this uncertainty poses a diagnostic and management challenge.
APPARENT LIFE­THREATENING EVENT
In 1986, before the risk factors for sudden infant death syndrome were well understood, an expert consensus group from the National Institutes of
Health coined the term apparent life­threatening event (ALTE). ALTE was defined as an episode that is frightening to a caregiver and involves some
 combination of apnea, color change (cyanosis, pallor, or plethora), change in muscle tone (limp or stiff), choking, or gagging. Unfortunately, the term
ALTE described a constellation of presenting symptoms rather than a diagnosis and relied heavily on the subjective impression of nonmedical
2­5 caregivers. No differentiation was made between the ~80% of ALTE patients who are well­appearing at the time of presentation and patients with ongoing symptoms such as respiratory difficulty or an ill appearance. To address these concerns, in 2016, the American Academy of Pediatrics more precisely defined these events as brief resolved unexplained events (BRUEs).
BRIEF RESOLVED UNEXPLAINED EVENTS
A BRUE specifically includes infants <1 year of age who have experienced a brief (<1 minute), unexplained event consisting of one or more of the following features: cyanosis or pallor; absent, decreased, or irregular breathing; marked change in tone (hyper­ or hypotonia); and/or altered level of responsiveness. The infant must return to his or her baseline state of health after the brief
 event and have a reassuring history and physical exam after medical evaluation, including vital signs. The BRUE guideline provides risk stratification criteria and management recommendations for lower­risk patients (Figure 117­1).
FIGURE 117­1. Diagnosis, risk classification, and recommended management of a brief resolved unexplained event (BRUE). *See Tables  and  of the original article for the determination of an appropriate and negative family history (FH) and physical examination (PE). **See Figure  of the original article for the
American Academy of Pediatrics method for rating of evidence and recommendations. ALTE = apparent life­threatening event; CSF = cerebrospinal fluid; EEG = electroencephalogram; GER = gastroesophageal reflux. [Reproduced with permission from Tieder JS, Bonkowsky JL, Etzel RA, et al: Brief resolved unexplained events (formerly apparent life­threatening events) and evaluation of lower­risk infants, Pediatrics. 2016;137(5): pii:e20160590.]

Chapter 117: Brief Resolved Unexplained Events and Apparent Life­Threatening Events, Ilene Claudius; Joel Tieder 
. Terms of Use * Privacy Policy * Notice * Accessibility
BRUE patients considered lower risk for subsequent events or serious underlying diagnosis include those >60 days old, with gestational age ≥32 weeks and postconceptional age ≥45 weeks, only one event (no prior BRUE ever and not occurring in clusters), event duration <1 minute, no CPR required by trained medical provider, no concerning historical features, and no concerning physical examination findings (see “Risk Stratification”).
This chapter does not address patients with ongoing symptoms (e.g., fever [Chapter 119], failure to thrive, respiratory distress [Chapters 123, 124, 125], recurrent seizures [Chapter 138]) because these patients should be evaluated based on their symptoms. Because BRUE is a newer classification that has not yet been specifically studied, most of the studies cited in this chapter were performed using the previous definition of ALTE.
EPIDEMIOLOGY
It can be normal for infants to choke, gag, demonstrate skin discoloration, change tone, or exhibit periodic and irregular breathing. In healthy infants,
43% are reported to have a 20­second respiratory pause and up to 5% of parents recall seeing an apnea event. The incidence of ALTE ranges from
7­9
.05% to .0%, depending on the population studied. In Europe,  out of 250 to 400 children are hospitalized for an ALTE. The peak incidence is
  between  week and  months of age, with the majority of ALTEs occurring before  weeks of age. The male­to­female ratio is 2:1. Known risk factors for ALTE include respiratory syncytial virus infection, prematurity, recent anesthesia, gastroesophageal reflux, and airway/maxillofacial anomalies. The epidemiology using the more specific term BRUE has not yet been described.
PATHOPHYSIOLOGY AND EVENT CLASSIFICATION
It is important to characterize the event with a comprehensive history, paying particular attention to changes in breathing, skin color, muscle tone, and level of consciousness. To differentiate normal from potentially pathologic events, determine what occurred before, during, and after the event as well as the relationship of the event to feeding, sleeping, and upper and lower respiratory problems.
Many newborns experience physiologic patterns of breathing that can be frightening to a layperson but are normal. Healthy infants often have cyclic periods of rapid breathing interposed with respiratory pauses, termed periodic breathing. Periodic breathing is observed in nearly all preterm and most term infants, and lasts until about  months of age in term infants. In addition, irregular respirations are the hallmark of active sleep (later referred to as rapid eye movement sleep or dream sleep) at all ages. Irregular breathing during rapid eye movement sleep continues into adulthood and is normal.
Apnea is typically characterized as central, obstructive, or mixed. Apneic pauses of >20 seconds or those associated with changes in color, tone, or heart rate are considered pathologic. Apnea is difficult to characterize subjectively, so the new American Academy of Pediatrics BRUE guideline includes any brief and resolved irregularity in respiration as a component of BRUE, unlike the ALTE definition, which specified apnea. Central apnea implies a disruption in the central respiratory centers resulting in a cessation of respiratory effort; there is no attempt to breathe. This can be a manifestation of a number of disorders, including traumatic brain injury and infectious disorders (including both serious bacterial infections and respiratory diseases such as bronchiolitis and pertussis). Infants with obstructive apnea appear to be attempting to breathe through an occluded
 airway, with paradoxical movements of the chest and abdomen. This is commonly described in upper and lower respiratory tract infections. In cases of oral dysphagia or gastroesophageal reflux disease, infants may exhibit obstructive apnea in relationship to feeds. There can be, at least subjectively, components of both central and obstructive apnea, indicating a mixed picture. Apnea of prematurity is a disorder in the control of breathing in
 premature infants, occurring in up to 25% of this group. Its frequency decreases with increasing maturity, and it is usually outgrown by  weeks of postconceptual age.
Episodic changes in infant skin color are often difficult for observers to characterize, particularly in infants with darker skin tones. The color change may be a manifestation of normal infant physiology (e.g., acrocyanosis) or may indicate more serious problems with perfusion or oxygenation (e.g., central cyanosis). Cyanosis becomes apparent when at least  grams/100 mL of blood is deoxygenated. Because young infants are often polycythemic, this threshold is more easily met in this age group, and cyanosis may be observed in normal newborns, typically seen in the dense perioral veins. In the distal extremities, vasomotor instability can cause acrocyanosis without underlying pathology. Both of these entities are benign. Normal infant polycythemia can also lead to a ruddy appearance (plethoric), which, in the crying infant, may be misinterpreted by lay caregivers as cyanosis or
“purple” coloring. For this reason, plethora was not included in the definition of BRUE. Pallor is characteristic of the vasovagal response and can be seen in association with gastroesophageal reflux, choking on feeds, or a vagal event.
In neonates, changes in muscle tone are difficult to classify because baseline neurologic status varies due to immaturity. Seizures in infants uncommonly present as stereotypical tonic­clonic activity and are more likely to present with altered consciousness or intermittent high and low tone
(e.g., infantile spasms). In addition, infants may exhibit changes in tone (either decreased or increased) in the postictal state. Changes in tone may also be secondary to hypoxia resulting from apnea. Stiffening and arching behavior have been well described in infants with gastroesophageal reflux events (Sandifer’s syndrome).
An altered level of responsiveness is part of the definition of BRUE because it can be an important component of the event associated with a serious underlying disorder. It was not part of the ALTE definition. Infants may lose consciousness or become unresponsive from a seizure, hypoglycemia, or hypoxemia. However, reports of altered consciousness often represent normal physiology or benign events as well. Because of an immature nervous system, infants may normally appear somnolent, appear unresponsive briefly, or lose consciousness after a breath­holding spell.
DIFFERENTIAL DIAGNOSIS
There are many potential causes of a BRUE or ALTE. The vast majority of conditions attributable to events previously referred to as ALTEs are selflimiting and not life threatening. For example, most patients presenting with an ALTE are diagnosed as having an idiopathic cause or gastroesophageal
,15 reflux. However, some patients may have a serious underlying disorder or risk for recurrence. The risk of a serious underlying disorder or recurrence in BRUE patients is unknown. Table 117­1 lists common, uncommon, and rare diagnoses assigned to patients presenting with a concerning event previously termed an ALTE. Select processes are discussed independently below.
TABLE 117­1
Explanations for Events Previously Referred to as ALTEs
Common, Benign Explanation Common Serious Pathology Less Common Serious Pathology
Gastroesophageal reflux/vomiting episode Seizure/infantile spasm/febrile seizure Maxillofacial obstruction or tracheoesophageal fistula
Upper respiratory tract infection Lower respiratory infections Arrhythmia/cardiac
Coughing or choking episode Laryngotracheomalacia Pertussis
Periodic breathing Inflicted injury Serious bacterial infection
Oral dysphagia Metabolic disease
Breath­holding spell Electrolyte/glucose
Poisoning
GASTROESOPHAGEAL REFLUX
Gastroesophageal reflux is among the most common explanations for these events. Gastroesophageal reflux is the involuntary passage of gastric contents into the esophagus and occurs daily in infants during the first year of life. This form of reflux, or frequent “spitting up,” is entirely normal and should be considered physiologic. As a result of the temporal correlation between peak age for these events and that of gastroesophageal reflux and the fact that reflux of gastric contents into the hypopharynx can trigger laryngospasm, a diagnosis of gastroesophageal reflux disease provides an easy explanation for events. Pathologic gastroesophageal reflux disease is defined as regurgitation of gastric contents into the esophagus with accompanying symptoms and complications such as failure to thrive. If events are recurrent and appear to be associated with gastroesophageal reflux events or symptoms, then initiating “reflux precautions” may be helpful, including small frequent feedings, upright positioning after feedings, frequent burping, and avoidance of tobacco smoke. Routine use of medications to reduce the acidity of the gastric contents (proton pump
 inhibitors, histamine­2 blockers) is not recommended. If events persist despite conservative empiric treatment, then further evaluation for GI and other causes (see “Anatomic Causes” below) may be indicated. Unfortunately, testing has limitations, and causation is difficult to prove. Even
,18 when invasive testing has linked apnea to gastroesophageal reflux, a difference between acid and nonacid reflux has not been demonstrated.
ORAL DYSPHAGIA
Problems with feeding coordination commonly cause these events, particularly in newborn infants. If the events appear to be related primarily to
,19 feeding, evaluation by speech or occupational therapy to evaluate and manage feeding and swallowing is recommended.
UPPER AND LOWER RESPIRATORY TRACT INFECTIONS AND PERTUSSIS
Respiratory infections such as respiratory syncytial virus and pertussis can cause central, obstructive, or mixed apnea in infants by directly affecting the brain or by causing laryngospasm, coughing, choking, or oral dysphagia. In younger infants, the events can be difficult to characterize particularly because they can precede the typical viral prodrome(Chapter 128, “Pneumonia in Infants and Children”). Obstructive apnea commonly occurs when infants choke on respiratory secretions. Dysregulation of mucosal immune responses and sensorineural stimulation have been postulated as the
20­22 cause of central apnea. Wilwerth and colleagues reported a .7% rate of apnea among infants admitted with bronchiolitis, and apnea at
 presentation is a risk factor for subsequent apneic episodes. Most studies have been performed on clinical or respiratory syncytial virus–proven bronchiolitis, but recently, the same association was found with metapneumovirus­associated bronchiolitis and a spectrum of respiratory
 pathogens.
Bordetella pertussis, or “whooping cough,” causes a respiratory infection that persists despite vaccination due to waning immunity in older individuals, vaccine failures, and vaccine refusal. Infants <6 months old are particularly susceptible because the initial immunization series begins at  months of age. Classically, the infection begins with upper respiratory infection symptoms (catarrhal phase) and progresses to paroxysmal coughing

(paroxysmal phase) over  to  weeks. However, it is important to understand that infants may present with isolated apnea.
Diagnosis can be difficult because apnea may be the first presenting symptom of bronchiolitis or pertussis in younger infants. While routine testing of bronchiolitis patients for viral pathogens is not recommended, testing for subclinical viral causes and pertussis in unclear cases presenting with apnea may be beneficial if exposure is of concern and test results are readily available. Infants presenting with apnea associated with proven or probable bronchiolitis or pertussis should be admitted for observation.
SEIZURES
Seizures have been identified in 4% to 7% of infants with ALTEs. Most often, they are the initial presentation of epilepsy in this age group but can rarely be secondary to underlying causes such as congenital brain malformation, metabolic disorders, electrolyte abnormalities, prenatally acquired brain injury, or intracranial bleeding (including abusive head injury). In well­appearing patients, an electroencephalogram seldom leads to a diagnosis of epilepsy and performing it often requires a hospital stay. The American Academy of Pediatrics BRUE guideline recommends against routine testing for seizures, including electroencephalogram and head imaging for lower­risk patients. For patients with recurring events and no explanation, particularly those concerning for seizures, neuroimaging and electroencephalogram may be indicated (Chapter 138, “Seizures in Infants and Children”).
CHILD ABUSE/POISONING
Child abuse, including suffocation, abusive head injury, and poisoning, are potential serious causes of these events and are reported
26­28 in .4% to .5% of all infants presenting with ALTEs (Chapter 150, “Child Abuse and Neglect”). Clinicians should have a high index of suspicion for these diagnoses since they can be difficult to recognize early on. A careful history and physical examination can determine risk most of the time.
Patients meeting the criteria for a lower­risk BRUE and with a negative history and physical exam have an incidence <0.3% of abusive head trauma and
 likely do not warrant additional investigation for child abuse. However, higher­risk BRUEs and those with social concerns or recurrent unexplained
 events may warrant additional investigation. Truman and Ayoub reported an increased risk of future death or recurrent ALTEs among ALTE patients presenting with fresh blood from the nose/mouth and higher potential for nonaccidental trauma in infants >6 months of age. Vomiting, irritability, bruising, subconjunctival hemorrhage, rapid head enlargement or head circumference > 95% for age, a prior ALTE, a recent emergency services call,
30­35  and a discrepant history have also been found to be associated with abusive head injury. Southall et al performed covert video surveillance in a highly selective population of recurrent ALTE patients considered suspicious for abuse and found an association between intentional suffocation and bleeding from the nose and mouth, marital dissatisfaction and parental personality disorders, and unexplained sibling death. One small study found
 subsequent abuse­related death to occur in 9% of patients followed for  months after an ALTE, and another study found that 11% of hospitalized

ALTE patients became victims of child abuse over a 5­year follow­up period. This would seem to indicate that, while a small percentage of ALTE patients are found to be victims of nonaccidental trauma during their index visit, they are at long­term risk of abuse. It is extremely difficult to discern from the currently available data whether that indicates that the index visit represented subtle abuse or whether presentation with an ALTE may be associated with psychosocial issues that lead later to abuse.
Poisoning as a cause of an ALTE is also a concern and may be intentional or unintentional. Intentional poisonings frequently involve narcotics,
,39 benzodiazepines, or phenothiazines in an attempt to quiet or sedate a fussy infant. Unintentional poisonings may involve inappropriate dosing of medications or mixing of over­the­counter cough and cold preparations containing ingredients with similar activity. Homeopathic medications, such as
 colic preparations, have also been associated with ALTEs.
SERIOUS BACTERIAL INFECTIONS
Serious bacterial infections are an extremely rare cause of lower­risk BRUEs, and testing for bacterial infection, including cultures of blood, urine, and cerebrospinal fluid, chest radiographs, and WBC counts, is not recommended. In some situations, higher­risk infants, particularly those under  months, may warrant screening tests such as urinalysis. However, infants with fever, hypothermia, localizing symptoms and signs of infection, persistently ill appearance, or concerning comorbidities should receive appropriate testing for serious bacterial infections (see Chapter 119, “Fever and Serious Bacterial Illness in Infants and Children”).
Even for infants below  months of age with events previously referred to as ALTE, unless one of the above risk factors is present, a full “rule­out sepsis” will rarely identify an occult infection. A study of 112 infants <60 days old with ALTE who underwent testing for serious bacterial infection identified three cases of bacteremia and one urinary tract infection, as well as one case of pertussis. This constituted .7% of the sample, and four of
 the five affected patients had a history of prematurity.
Chest radiograph is rarely indicated in absence of any respiratory findings. The rare exception to this includes patients under  months of age who may
,43 present without classic findings for pneumonia. Additionally, respiratory symptoms and/or radiograph­proven pneumonia can develop after the
  initial presentation for ALTE, and a paper documenting two deaths after discharge of 176 infants found both to have succumbed to pneumonia.
However, neither had a radiograph deemed to be positive in the ED. Careful outpatient follow­up is preferable to identify these patients, not routine radiographs.
BREATH­HOLDING SPELLS
Breath­holding spells occur in 4% to 5% of children <8 years of age and entail a cessation of respiration at the end of expiration, usually in response to pain, anger, or fear. Spells typically last <1 minute and may be accompanied by cyanosis, pallor, syncope, and seizures. Breath­holding spells have not been associated with any underlying medical condition, although there is some literature supporting the finding that pallid spells are associated with pronounced QT dispersion and may have a cardiac etiology. Breath­holding spells are generally easily recognized in older children, but they may be diagnosed in infants as young as  months of age: one study found that in 15% of children with breath­holding spells, the age of onset was <6
 months.
ANATOMIC CAUSES
Anatomic anomalies of the airway such as laryngomalacia, tracheomalacia, tracheoesophageal fistulas, vascular rings, and clefts may cause obstructive apnea, oral dysphagia, gastroesophageal reflux, sleep­disordered breathing, and obstructive sleep apnea. Subtle dysmorphisms may lead
 to abnormal breathing and obstruction during sleep, presenting with snoring, apnea, and mouth breathing. An ear, nose, and throat evaluation is indicated for infants experiencing repeat and serious events, particularly those that indicate an unstable airway.
METABOLIC CAUSES
Inborn errors of metabolism rarely present as a BRUE in the face of negative newborn screens and a noncontributory history and physical examination.

Therefore, routine testing is not indicated. Inborn errors of metabolism might be suspected in patients who experience an event after their first period of prolonged fasting (e.g., an infant who just began sleeping through the night) or a history of poor feeding and somnolence throughout the neonatal period (see Chapter 146, “Metabolic Emergencies in Infants and Children” ). Importantly, these infants are often symptomatic upon
 presentation and would not qualify as having a BRUE.
CARDIAC CAUSES
Cardiac arrhythmias, channelopathies, Wolfe­Parkinson­White syndrome, cardiomyopathy, and myocarditis can present as a BRUE but are rare causes
,48 when there is a noncontributory history and physical examination. An ECG, when available, is an accurate and inexpensive test that can be helpful in diagnosing this life­threatening disorder (see Chapter 130, “Syncope, Dysrhythmias, and ECG Interpretation in Children”).
ED APPROACH
When a caregiver seeks medical attention for an event, the first step for the provider is to characterize the event as objectively as possible by taking a careful history. Ask targeted questions to understand the event including what happened before, during, and after the event and include any relationship to feeding, color change, central versus obstructive apnea, event duration, loss of consciousness, stereotypical seizure activity, and so on.
If patients are currently exhibiting symptoms such as fever or respiratory illness and/or if there is a clear explanation for the event such as gastroesophageal reflux or upper respiratory infection, then manage the patient accordingly. These events should not be called ALTEs or BRUEs. For children with an upper respiratory infection, cough and cold preparations are contraindicated in infancy, even when it appears that an infant has choked on mucus. Infants with a concern for an airway abnormality should be evaluated by an otolaryngologist. Infants presenting with a potential seizure in the first year of life will certainly need neurologic consultation; an immediate electroencephalogram need not be ordered and antiepileptic medications should not be empirically initiated for a lower­risk BRUE patient (see Chapter 138, “Seizures in Infants and Children”). These consultations can be arranged on an urgent, outpatient basis rather than requiring admission for inpatient consultation in a stable infant. Home monitoring is not indicated following discharge.
Infants for whom the diagnosis is not immediately clear but who appear unstable should be resuscitated aggressively, and the aforementioned causes should be considered. The well­appearing infants without an explanation who fall under the guidelines for a BRUE should be risk­stratified and managed in accordance with their risk category.
RISK STRATIFICATION
Once a child has met criteria for a BRUE, implying no current symptoms and no explanation for the event, the next step is to assess the infant for risk of recurrence or a serious underlying disorder in the same manner that a patient with chest pain or young infant with fever might be risk­stratified.

Patients who meet all the criteria in Table 117­2 are presumed to be lower risk. Infants not meeting all of these criteria are considered as having higher­risk BRUE. It is important to recognize that these criteria define a very low­risk group. Infants not meeting lower­risk BRUE criteria are a pleomorphic group to be assessed on an individual basis. Not every infant assigned to this “higher­risk group” is at substantial risk of future events.
TABLE 117­2
Criteria for Brief Resolved Unexplained Events (BRUE) and Lower­Risk BRUE
Criteria for BRUE Age <1 y
Sudden, brief episode
Patient at baseline state of heath after event
Event unexplained by history and physical exam
≥1 of the following
Cyanosis or pallor
Absent, decreased, or irregular breathing
Marked change in tone
Altered level of responsiveness
Criteria for lower­risk BRUE >60 d old
Born at a gestational age of ≥32 wk and currently at a postconceptual age ≥45 wk
First and single event
Event lasting <1 min
No CPR required by trained medical provider
No concerning historical features
No concerning physical exam features
DIAGNOSTIC TESTING AND DISPOSITION IN LOWER­RISK BRUE
It has been common to admit infants presenting with ALTE to the hospital for workup and monitoring. However, this is not without cost: the mean
 adjusted charge for children’s hospitals in the United States is $15,567 per admission (average length of stay, .4 days). The financial burden is compounded by the frequency of iatrogenic complications, including medical errors and nosocomial infections, and the social implications from unnecessary admission and added anxiety. The American Academy of Pediatrics BRUE guideline recommends against routine admission
50­53 of these infants. This is based on literature indicating which patients are at risk of a serious underlying pathology or recurrent event. Instead, a period of observation on pulse oximetry with serial exams lasting  to  hours can be offered. The duration of this period of observation is a good opportunity for shared decision making with caregivers. A follow­up exam in  hours is recommended. Reassurance that BRUE is not considered a precursor to sudden infant death syndrome and CPR instruction resources may provide additional reassurance to caregivers. Recommended laboratory and radiographic evaluation of the lower­risk BRUE patient is minimal (Table 117­3). In a child without referable symptoms, WBC count, cultures, electrolytes, chest radiograph, echocardiogram, and evaluation for metabolic disease are not indicated. Similarly, viral respiratory testing, blood glucose, bicarbonate, hemoglobin, and neuroimaging are not necessary. Providers are given the option of testing for pertussis and obtaining an
ECG in appropriate situations. These recommendations are based on a wealth of literature indicating a negligible yield of routine testing in ALTE
,42,54 patients, particularly those that the new guidelines would place in a lower­risk category.
TABLE 117­3
Recommendations for the Lower­Risk Patient With a Brief Resolved Unexplained Event (BRUE)
Clinician should: Educate caregivers about BRUE
Use shared decision making when possible
Offer CPR resources
Clinician may: Monitor for 1–4 h with pulse oximetry and serial exams
Perform pertussis testing
Perform ECG
Clinician need not: Admit patient solely for monitoring
Obtain respiratory viral testing
Obtain urinalysis
Obtain blood glucose, bicarbonate, or lactate
Obtain neuroimaging
Screen for anemia
Clinician should not: Obtain WBC
Obtain blood culture
Obtain cerebrospinal fluid studies
Obtain electrolytes
Obtain metabolic workup
Obtain chest radiograph
Obtain echocardiogram
Obtain electroencephalogram
Obtain studies for gastroesophageal reflux
Initiate home monitoring
Prescribe acid suppression therapy
Prescribe antiepileptics
DIAGNOSTIC TESTING AND DISPOSITION OF HIGHER­RISK BRUES

Testing and hospitalization are useful in higher­risk BRUE patients, compared to lower­risk infants. The risk of recurrence or an underlying condition is not well understood in this population, and there are no formal guidelines published for the management of the higher­risk
BRUE patient. While no evidence exists to support a wide battery of screening labs, testing and observation periods may be warranted for certain populations. In this group, obtain a careful history and physical to uncover potential diagnoses that should be pursued, with emphasis on excluding oral dysphagia, abuse, arrhythmia, and CNS and anatomic problems. Laboratory and radiographic evaluation should be pursued for reasonable differential diagnoses after the history and physical exam. While admission is not mandatory in these patients, have a low threshold for admission and monitoring. For patients experiencing events formerly referred to as ALTE, between 12% and 14% have a subsequent event or are diagnosed with a condition that requires hospitalization. This rate is probably much lower under the BRUE definition. Premature infants, infants  months old,
,56 infants with cyanosis, and those with chronic medical conditions seem to be at highest risk of recurrence. If events recur during hospitalization, events can be better explained. For example, oral dysphagia, sleep apnea, breath­holding spells, and seizures may be easily recognized by a medical provider during careful observation, and arrhythmias can be identified by monitoring.
POSTDISCHARGE OUTCOMES
ED physicians and caregivers may worry about subsequent sudden infant death syndrome or occult illness in infants who have experienced BRUE or
,57
ALTE. However, such patients are not at increased risk of sudden infant death syndrome. That said, an event may be an initial sign of an underlying serious condition, such as nonaccidental trauma, that would place the infant at increased risk of recurrence or death. Overall postdischarge mortality
,8,37  in ALTE studies is 0% to .4%. The likelihood of a subsequent ALTE after discharge ranges from .1% to .4%. In lower­risk BRUE patients, recurrent events or an underlying disorder are very unlikely. For all BRUE patients, it is important to impart reassurance without offering false guarantees that another event will not occur. Currently, home monitors are not recommended for lower­risk BRUE patients.


