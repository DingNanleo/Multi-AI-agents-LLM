## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 165: Headache
Alex Koyfman; Brit Long
INTRODUCTION AND EPIDEMIOLOGY

Headache is the fourth most common symptom presenting to the ED in the United States, accounting for close to 3% of total ED visits. Overall,
 headaches affect people across all ethnic, geographic, and economic levels, with an estimated global prevalence of 47% in adults.
In the ED, the approach to headache focuses on identifying patients at risk for rapid deterioration, morbidity, and mortality; rapidly identifying highrisk headache syndromes; and providing appropriate headache therapy.
PATHOPHYSIOLOGY

The brain parenchyma has no pain sensors. Early theories postulating vasoconstriction and rebound vasodilatation as the cause of migraine have
 been refuted. Numerous physiologic mechanisms play a role in the development of the various clinical headache syndromes. For example, occipital
 nerve irritation may lead to the development of occipital neuralgia. Similarly, headaches associated with disturbances in intracranial pressure (high
 and low) are related to compression of, or traction on, pressure­sensitive structures in the meninges. The pathophysiologic mechanisms of other headache syndromes, such as migraine headaches, cluster headaches, and toxic and metabolic headaches, are less clear. Discussion of these mechanisms is beyond the scope of this chapter.
CLINICAL FEATURES
Although headaches are typically classified as primary headaches when there is no underlying cause (such as migraine, tension, or cluster headaches) and secondary headaches if associated with an underlying cause (such as tumor, meningitis, or subarachnoid hemorrhage), this distinction is not clinically useful in the ED setting. Rather, the emergency physician should focus on evaluating for and ruling out secondary causes of headache. Most patients with headache have conditions that are painful but benign in etiology. Identifying those at high risk for a secondary headache is the first step in management (Table 165­1). A high­risk cause for headache accounts for only 4% of all headaches but 10% to 14% of acute­onset
,8
(“thunderclap”) headaches. Improvement of the patient’s pain with treatment does not predict benign cause of headache.
TABLE 165­1
High­Risk Features for Headache: Clinical “Red Flags”
Onset Sudden
Trauma
Exertion
Symptoms Altered mental status
Seizure
Fever
Neurologic symptoms
Visual changes
Medications Anticoagulants/antiplatelets
Downloaded 2025­7­1 6:21 P Your IRPe cise n1t3 a6n.t1ib4io2t.i1c 5u9se.127
Chapter 165: Headache, Alex Koyfman; Brit Long 
Immunosuppressants
. Terms of Use * Privacy Policy * Notice * Accessibility
Past history No prior headache
Change in headache quality, or progressive headache worsening over weeks/months
Associated conditions Pregnancy or postpregnancy status
Systemic lupus erythematosus
Behçet’s disease
Vasculitis
Sarcoidosis
Cancer
Physical examination Altered mental status
Fever
Neck stiffness
Papilledema
Focal neurologic signs
HISTORY
Features associated with high­risk headaches are as follows:
Patient Age

Patients >50 years of age, with a new or worsening headache, represent a high­risk group. The incidence of migraine, cluster, and tension headaches
 decreases with age, raising the likelihood of ominous pathology for older patients. Close to 15% of patients over age  will have a dangerous
  secondary headache on neuroimaging, and those over  have four times the rate of pathology.
Onset of Symptoms

The abrupt onset of severe headache, or “thunderclap” headache, requires immediate and thorough evaluation. A thunderclap headache is
 defined by pain that reaches  out of  in less than  minute. Thunderclap headache associated with intracerebral aneurysmal leak (“sentinel hemorrhage” or “herald bleed”) may precede catastrophic aneurysmal rupture by days to weeks. Associated symptoms may include neck stiffness,
 nausea, vomiting, loss of consciousness, neurologic deficit, or altered mentation. Onset of thunderclap headache during periods of exertion raises suspicion for subarachnoid hemorrhage or arterial dissection of the carotid or vertebrobasilar circulation. A headache with seizure, altered mental
 status, visual disturbance, or focal neurologic deficit may be due to posterior reversible encephalopathy syndrome or reversible cerebral
  vasoconstriction syndrome. Headaches associated with the Valsalva maneuver may herald an intracranial abnormality. Rarely, spontaneous
 intracranial hypotension and acute hydrocephalus associated with third ventricular colloid cyst may present with thunderclap headache. Other causes for thunderclap headache are listed in Table 165­2. TABLE 165­2
Causes of Thunderclap Headache
Hemorrhage Intracranial hemorrhage
“Sentinel” aneurysmal hemorrhage
Spontaneous intracerebral hemorrhage
Vascular Carotid or vertebrobasilar dissection
Reversible cerebral vasoconstriction syndrome (RCVS)
Cerebral venous thrombosis
Posterior reversible encephalopathy syndrome (PRES)
Other causes Coital headache
Valsalva­associated headache
Spontaneous intracranial hypotension
Acute hydrocephalus (e.g., colloid cyst obstructing third ventricle)18
Pituitary apoplexy
Acute angle­closure glaucoma
Headache Quality
A change in pattern, frequency, quality, or intensity of a preexisting headache syndrome needs the same evaluation as a new­onset headache syndrome.
Fever
Fever raises concern for CNS infection, such as meningitis, encephalitis, or brain abscess. However, the absence of fever does not exclude a CNS infection, especially in patients at the extremes of age and with immunocompromised states, such as human immunodeficiency virus. Headaches in
,20 patients with human immunodeficiency virus and CD4 count less than 200 cells/μL have a higher risk of intracranial pathology.
Past Medical History
The past medical history is essential in determining risk of secondary etiology for headache. A history of immunocompromised state (including human immunodeficiency virus, vasculitis, diabetes, among others) may prompt need for further evaluation. History of malignancy, trauma, current pregnancy, and recent pregnancy are suggestive of a secondary cause of headache.
Medication History
Inquire about over­the­counter medications, anticoagulants, antiplatelet agents, chronic steroids, immunomodulatory agents, or antibiotics
(prescribed or not) to identify patients at high risk for infection (e.g., eculizumab and its elevated risk for meningococcal infection). Chronic use of analgesic and anti­inflammatory agents may result in rebound or withdrawal headaches. Medication overuse is defined as use >10 times a month
 and is notable for ergots, triptans, and opioids. Anticoagulants and antiplatelet agents increase the risk for hemorrhage, both spontaneous and
 traumatic. The recent use of antibiotics may present with a falsely reassuring clinical appearance due to partial treatment of a potentially dangerous
CNS infection.
Prior Headache History
A prior history suggestive of migraine, tension, or cluster­type headaches and response to specific therapy may obviate the need for extensive ED evaluation (Tables 165­3 and 165­4).
TABLE 165­3
Clinical Features Suggestive of Migraine
Prior history of migraine Moderate/severe intensity
Younger age Unilateral
Multiple prior episodes Throbbing
Aura and prodrome Nausea/vomiting
Familiar triggers Photophobia/phonophobia
Family history Lasts hours
History of motion sickness
TABLE 165­4
Clinical Features Suggestive of Cluster Headache
At least  attacks that meet the following criteria: Associated ipsilateral symptoms (at least one):
Severe Lacrimation
Unilateral Conjunctival injection
Lasts 15–180 min (untreated) Nasal congestion or rhinorrhea
Circadian/circannual pattern Ptosis and/or miosis
Edema of the eyelid and/or face
Sweating of the forehead and/or face
Substance Use History
Use of adrenergic agents such as cocaine, amphetamine, or derivative compounds such as methamphetamine increases risk of intracranial
 hemorrhage or the less common entity of reversible cerebral vasoconstriction syndrome. Patients with a history of alcohol abuse are at increased risk of intracranial bleeding due to falls, interpersonal violence, and the potential for liver dysfunction associated with prolonged coagulation times and thrombocytopenia.
Family History

Known aneurysm or sudden death in first­degree relatives raises the suspicion for intracranial aneurysm. The incidence of aneurysm in patients with a family history is three to five times higher than in those without a family history. A personal or family history of autosomal dominant polycystic kidney disease also increases the risk for intracranial aneurysm. In patients with autosomal dominant polycystic kidney disease, aneurysmal rupture is more likely to occur at a younger age. The presence of migraine in a first­degree relative is associated with a two­ to fourfold increased risk of developing
 migraine.
PHYSICAL EXAMINATION
Vital Signs
Headache is a common symptom associated with fever, as headache is seen in up to 60% of patients with upper respiratory tract infection
,25 symptoms. The persistence of headache in the presence of a normalized temperature suggests consideration for further evaluation of a possible
CNS infection. The presence of fever in association with neck stiffness and altered mental status represents the classic triad of meningitis. Close to 95%
 of patients with bacterial meningitis present with at least two of the four findings (classic triad plus headache).
Severe hypertension can be associated with headache and the development of acute changes in mental status and neurologic function. Consider
 posterior reversible encephalopathy syndrome and hypertensive emergency in such patients (see “Posterior Reversible Encephalopathy Syndrome” section).
Examination of the Head and Neck

Meningismus is an important clinical clue to the presence of infection or hemorrhage. Examine the ears, nose, and throat to identify otitis media and sinusitis, both of which may cause headache and contribute to the extension of infection to the CNS. Palpate for scalp tenderness and tenderness over the temporal arteries to assess for possible temporal arteritis.
Examination of the Eye
Headache can occur with acute angle­closure glaucoma, scleritis, and endophthalmitis. Visual complaints require consideration of secondary etiology.
Consider acute angle­closure glaucoma even when there is no focal ocular complaint, as the pain can be so severe the patient may fail to localize pain to the eye. Measure intraocular pressure to exclude glaucoma. Check visual acuity and visual fields and examine the pupils and eyelids, checking for signs of Horner’s syndrome.
Funduscopic Examination
Papilledema can be seen in the presence of raised intracranial pressure. However, there is typically a delay in the onset of papilledema once
 intracranial pressure begins to elevate, and papilledema can persist once intracranial pressure returns to normal. The ability to recognize papilledema by routine direct ophthalmoscopy alone (particularly with nondilated pupils) is limited, but a panoptic ophthalmoscope provides a more
 ,31 reliable view of the retina. Bedside US of the optic nerve sheath can also assess for papilledema. The presence of papilledema requires CT
 imaging before lumbar puncture.
Neurologic Examination
A baseline neurologic assessment includes the following: mental status assessment; cranial nerve examination, including pupillary examination (for asymmetry or ptosis, which may suggest third nerve compression by posterior communicating artery aneurysms); assessment for other cranial neuropathies (which may raise suspicion for carcinomatous meningitis); motor examination to detect extremity weakness (particularly subtle weakness with pronator drift); reflex examination for subtle asymmetry or a Babinski reflex; and gait and coordination testing (which may be impaired
 in cerebellar lesions). Any neurologic deficit, including altered mental status, possesses the highest predictive value for CNS pathology.
DIAGNOSIS
There are many causes of headache, each of which is diagnosed and managed differently.
LABORATORY TESTING
Routine blood testing is of limited utility in the diagnosis of acute headache and should be guided by the patient’s age, history, relevant comorbidities, and medication history.
The laboratory evaluation of patients with high­risk headaches may include basic metabolic profile, CBC, coagulation panel, erythrocyte sedimentation rate, C­reactive protein, and blood cultures for possible infection.
IMAGING
34­36
Selecting an appropriate imaging study depends on the history, physical examination findings, and differential diagnosis of headache, as well as the resources available to the emergency provider. Table 165­5 summarizes some of the American College of Radiology and American College of
Emergency Physicians recommendations for appropriate imaging. When MRI is immediately unavailable and diagnostic uncertainty regarding the possibility of an underlying lesion prevails, further imaging may be necessary, the timing of which will depend on the clinical circumstances and
 likelihood of the patient being able to follow up in a reliable fashion.
TABLE 165­5
Choice of Imaging Modality
American College of Radiology
Noncontrast Head CT MRI of Brain With and Without Contrast
Trauma New­onset headache plus focal neurologic deficit/papilledema
Thunderclap headache Possible encephalitis
New headache plus focal neurologic deficit or papilledema Possible vertebral/carotid dissection
Chronic headache plus change in clinical features Horner’s syndrome
Valsalva or coital headache
Immunocompromised individual
Patient with cancer history/current cancer
Suspected temporal arteritis
Intracranial hypotension (low­pressure headache)
Headache with suspected intracranial complication of sinusitis/mastoiditis/oromaxillofacial origin
New­onset headache in pregnant woman (without contrast)
Headache of trigeminal autonomic origin
Chronic headache with new feature or focal deficit (CT can be first step)
American College of Emergency Physicians 2008 Clinical Policy: Which patients with headache require neuroimaging in the ED?
Patient Presentation Recommendation
Headache and new abnormal findings in neurologic examination (focal deficit, Level B (emergent noncontrast head CT) altered mental status, altered cognitive function)
New sudden­onset severe headache Level B (emergent noncontrast head CT)
HIV­positive patients with a new type of headache Level B (emergent noncontrast head CT)
Age >50 with new headache but with normal neurologic examination Level C (urgent noncontrast head CT)
If the patient presents with a typical history of headache that responds to typical measures and a normal neurologic examination, avoid neuroimaging to reduce radiation exposure. When appropriate, a noncontrast head CT is the fastest and most appropriate initial imaging study, as well as the most
,37 sensitive for detecting acute intracranial hemorrhage.
Gadolinium­based magnetic resonance contrast agents are contraindicated for patients with renal insufficiency due to risk of nephrogenic systemic fibrosis, and intravenous contrast for CT should be carefully considered in patients with renal insufficiency, although literature suggests no
,39 association of contrast with renal injury. Gadolinium is relatively contraindicated in pregnancy and breastfeeding women. MRI can be limited by claustrophobia. A discussion with the radiologist and/or radiology technical staff can clarify the safety of MRI in patients with devices or foreign bodies.
Magnetic resonance angiography is useful in detecting arterial disease (stenosis, congenital anomalies, dissection, CNS vasculitis) and should be considered in any case where there may be arterial pathology underlying the patient’s symptoms. Discuss concerns for dissection with the radiologist to determine the most appropriate MRI method.
If MRI is unavailable or not clinically feasible, consult radiology regarding other appropriate imaging modalities.
LUMBAR PUNCTURE
After the clinical assessment, blood work, and imaging, the next step is to determine whether to perform a lumbar puncture (LP) and, if so, the timing of LP. LP can serve as both a diagnostic tool (as in meningitis, subarachnoid hemorrhage, intracranial hypotension, carcinomatous meningitis) and therapeutic tool (as in idiopathic intracranial hypertension).
Ideally, perform the LP with the patient in the lateral decubitus position to allow for the accurate measurement of opening pressure. Seated LP does not allow for accurate assessment of opening pressure. Opening pressure provides critical information about the patient’s intracranial pressure and should be considered a routine procedure when performing LP.
The possibility of herniation in association with LP is a frequent concern of emergency providers. There is no randomized controlled trial assessing the question of when it is safe to perform an LP. The cumulative evidence suggests that in patients with normal sensorium, no focal neurologic deficit, and without a history of immunosuppression, it is safe to proceed with LP without imaging prior to the
,41 procedure.
In the evaluation of patients with suspected acute bacterial meningitis, clinical signs of “impending” herniation are the best predictors of when to delay an LP because of the risk of precipitating herniation. Risk of an abnormal CT scan is elevated in patients with any of the following clinical features: a deteriorating or altered level of consciousness (particularly a Glasgow Coma Scale score of ≤11), brainstem signs (including pupillary changes, posturing, or irregular respirations), focal neurologic deficit, history of recent seizure, history of a preexisting neurologic disorder, or history of immunocompromised state. In patients with these clinical features, imaging prior to LP is appropriate, but never delay antibiotic administration while imaging is obtained. In patients without such findings, it is usually safe to perform LP without obtaining a CT scan in cases of suspected bacterial
 meningitis.
DISPOSITION AND FOLLOW­UP
Most patients with headache can be treated and released from the ED with an appropriate follow­up plan. Identification of potential barriers to followup is an important step in ensuring that proper follow­up will be available to all patients, particularly for patients with limited resources or other barriers to accessing medical care. For some patients, inpatient care or observation may be warranted until symptoms improve or until testing is completed. A follow­up plan is important for patients with high­risk conditions, such as temporal arteritis or idiopathic intracranial hypertension.
Follow­up is similarly important for patients with chronic headaches, given the potential for substance abuse, overutilization of resources, and
 repeated unnecessary imaging with potentially harmful radiation.
SPECIFIC CAUSES OF HEADACHE
MENINGITIS/ENCEPHALITIS

Consider meningitis and encephalitis in patients with headache and the classic triad of fever, altered mentation, and neck stiffness. Meningitis is due to the meningeal infection and inflammation, while encephalitis results from infection and inflammation of the underlying neural tissue. The combination of headache, fever, and neck stiffness is present in 44% of cases of meningitis, although 99% of patients will have at least one of these
 symptoms. The source of infection in meningitis can be viral, bacterial, and less commonly, fungal or parasitic, with similar etiologies in encephalitis, although viral causes are most common. Have a high index of suspicion for meningitis in those with immunosuppression (particularly acquired immunodeficiency syndrome, human immunodeficiency virus, cancer history, chemotherapy, chronic steroids), which may be associated with more insidious types of meningitis such as Cryptococcus. An LP is indicated for suspected meningitis. If the LP is delayed (e.g., CT, coagulopathy,
,43 thrombocytopenia, agitation) and meningitis is strongly suspected, administer antibiotics without delay. For many patients who are awake and alert without evidence of papilledema or focal neurologic deficit and who have no history to suggest immunocompromised state or new­
 onset seizure, the head CT can be delayed until after the LP.
SUBARACHNOID HEMORRHAGE
,45
Subarachnoid hemorrhage resulting from rupture of an intracranial aneurysm carries only a 50% 30­day survival rate. Approximately half of survivors have some degree of neurologic impairment. Early detection and appropriate management lead to improved clinical outcome. Only 1% of patients presenting to the ED with headache have subarachnoid hemorrhage. However, 10% to 14% of those complaining of the “worst headache of
,8 ,14 their life” have subarachnoid hemorrhage. Acute onset of a severe headache is subarachnoid hemorrhage until proven otherwise.

Neck pain on history and stiffness on exam are suggestive. Inquire about a family history as outlined above. Obtain a noncontrast head CT as the
 first step in evaluation. With third­generation CT equipment, CT scan done within  hours of headache onset is reported to have a sensitivity
,48 approaching over 99% and specificity over 99%, with a negative predictive value of .4% and positive predictive value of 100%. If head CT is negative for blood but suspicion for subarachnoid hemorrhage is strong, or if the patient presents beyond  hours of headache onset, the next step is

LP to detect blood or xanthochromia in the cerebrospinal fluid. For further discussion, see Chapter 166, “Spontaneous Subarachnoid and
Intracerebral Hemorrhage.” Consultation with a neurologist or neurosurgeon may be appropriate if the history is highly suggestive of subarachnoid
50­52 hemorrhage, because both the CT and LP can be normal. CT angiogram, magnetic resonance angiogram, MRI with fluid­attenuated inversion
,54  recovery/susceptibility­weighted images, or four­vessel cerebral angiogram may be reasonable.
SUBDURAL HEMATOMA AND INTRACEREBRAL HEMORRHAGE
Intracranial hemorrhage may occur with or without a history of trauma, in the context of new or progressive headache, and with or without associated neurologic deficit. This is particularly important in the elderly, those with chronic alcohol and substance abuse, and patients using antiplatelet and anticoagulant agents. The antiplatelet agent clopidogrel increases the risk of acute intracranial bleeding immediately after trauma, so patients receiving antiplatelet agents and anticoagulants should be screened using head CT, regardless of symptoms. In a prospective trial of patients with blunt head trauma, 12% of those taking clopidogrel and .1% of those taking warfarin had acute intracranial hemorrhage noted on their initial CT scan.

The risk of delayed intracranial hemorrhage was small in both groups (0 of 296 patients taking clopidogrel and  of 687 patients taking warfarin).
Acute headache with associated vestibular symptoms (vertigo or ataxia) should be considered a cerebellar hemorrhage until proven otherwise.
Cerebellar hemorrhages make up approximately 10% of all intracerebral hemorrhages and may require prompt surgical evacuation of the hematoma
 to prevent rapid progression to severe disability or death.
BRAIN TUMOR

Headache in the setting of brain tumor is caused, at least in part, by cerebrospinal fluid flow obstruction and intracranial hypertension.

Headache alone is a rare presentation of brain tumor. Clinical signs and symptoms suggesting brain tumor include abnormal neurologic examination, headache worsened by Valsalva maneuver, headache causing awakening from sleep, seizures, recent cancer diagnosis, or mental status change. The absence of these features does not exclude the possibility of a brain tumor. In adults, nausea, vomiting, and neurologic deficit are more
,59 common than morning or nocturnal headache. MRI with and without gadolinium is the study of choice for detecting brain tumors, but cost and limited access make it unfeasible in many settings. A noncontrast CT will identify large masses and edema associated with large masses, but may fail to identify smaller masses. However, noncontrast CT can diagnose hemorrhage secondary to malignancy, accounting for up to 11% of intracerebral
 hemorrhages. Evaluate for potential barriers to access of medical care in clinical decision making, because additional imaging may be needed at follow­up.
CEREBRAL VENOUS THROMBOSIS
Cerebral venous thrombosis is a rare, but dangerous, cause of headache, with mean age of  years. Consider the diagnosis in patients presenting with new headache symptoms, especially in the presence of certain risk factors. Cerebral venous thrombosis is more common in women, especially in the peripartum period, and in patients with a recent surgical history. It is associated with hypercoagulable states such as use of oral contraceptives,
 hematologic disorders, factor V Leiden homozygous mutation, protein S or protein C deficiency, and anti–thrombin III deficiency. The presentation can vary widely, from a progressive headache developing over days to weeks to, in some instances, a “thunderclap” headache. Similarly, the patient’s clinical appearance can be quite benign, especially early in the course of the illness, or in more severe cases, patients may present with signs of
,63 elevated intracranial pressure, seizures (40%), stroke symptoms, and even coma (14%). Approximately one third will develop intracerebral
 hemorrhage.
In the presence of abnormal imaging (CT, MRI), focal neurologic deficit, or altered mental status, the diagnosis is made definitively with magnetic resonance venography. Given the rare nature of this diagnosis, patients suffering from cerebral venous thrombosis may be undergoing evaluation for other causes of severe headache. An elevated LP opening pressure should raise suspicion of cerebral venous thrombosis in the appropriate clinical
,66 setting and prompt further imaging with magnetic resonance venography or consultation with a neurologist. LP can safely be performed in patients with cerebral venous thrombosis.
Cerebral Venous Thrombosis in SARS­CoV­2 Vaccine­Induced Immune Thrombotic Thrombocytopenia
There have been several reports of cerebral venous thrombosis occurring within 4­42 days of receiving the SARS­CoV­2 vaccines ChAdOx1 nCov­19
66A­C
(Oxford­AstraZeneca) and Ad26.COV2.S (Janssen/Johnson & Johnson). Any arterial or venous thrombosis, including cerebral venous thrombosis, in the setting of mild­to­severe thrombocytopenia and a positive platelet factor­4 (PF4)­heparin enzyme­linked immunosorbent assay (ELISA)
66A,B occurring 4­42 days after vaccination with these SARS­CoV­2 vaccines is known as thrombosis with thrombocytopenic syndrome (TTS). Patients with cerebral venous thrombosis occurring in the setting of TTS more frequently present comatose and have higher rates of intracerebral
66C hemorrhage, concomitant thromboembolism, and mortality compared with other patients with cerebral venous thrombosis. TTS should be
 suspected in those with platelet count below 150 x  /L, venous or arterial thrombosis, positive PF4 ELISA, and elevated D­dimer levels (>  times the
66A,B upper limit of normal) 4­42 days after receiving the discussed SARS­CoV­2 vaccines. Assessment includes imaging based on the suspected site of thrombosis and laboratory evaluation, with treatment including intravenous immunoglobulin (IVIG), anticoagulation (parenteral direct thrombin inhibitors, direct oral anticoagulants without lead­in heparin phase, fondaparinux, or danaparoid), and avoidance of heparin and platelet
66A,B transfusion.
POSTERIOR REVERSIBLE ENCEPHALOPATHY SYNDROME
Patients with posterior reversible encephalopathy syndrome can present with severe headache, visual changes, seizures, and encephalopathy in the setting of marked blood pressure elevation (usually rapidly developing). It is most common in patients undergoing active treatment with immunesuppressing or ­modulating medications or chemotherapeutic agents, as well as in patients with end­stage renal disease. Imaging with MRI typically shows evidence of symmetrical vasogenic edema in the occipital area of the brain, although other areas of the brain can be involved. Treatment
 involves blood pressure control and supportive care.
REVERSIBLE CEREBRAL VASOCONSTRICTION SYNDROME
This condition can mimic subarachnoid hemorrhage (see Table 165­2). Characterized by the occurrence of one or more “thunderclap” headaches, the diagnosis should be considered only when the evaluation for subarachnoid hemorrhage has proven negative. The underlying pathophysiology of the syndrome is poorly understood, but it appears to coexist with a number of other cerebral angiopathies (including posterior reversible encephalopathy syndrome) that are characterized by diffuse cerebral vasospasm. The incidence is greater in women, and the peak age of onset is in the early 40s. Most patients will have more than one thunderclap headache over the course of a few weeks. Severe headache may be the only presenting feature, although some patients can present with seizure or focal neurologic deficit. The key diagnostic feature (multiple areas of cerebral vasoconstriction on cerebral
 angiography) is most commonly found on follow­up angiography between  and  weeks after symptom onset. In three published series, the rate of permanent neurologic disability was between 6% and 20%. Reversible cerebral vasoconstriction syndrome, although not widely known among nonneurologists, does not appear to be that rare. One prospective case series included  patients diagnosed at a single hospital over a 3­year period
 of data collection.
Initial neuroimaging in these patients may show evidence of nonaneurysmal subarachnoid hemorrhage, ischemic stroke, or intracranial hemorrhage.
However, head CT is most commonly normal in these patients. Ultimately, there will be magnetic resonance angiography evidence of cerebral vasoconstriction in all patients, but this may be delayed in appearance. As such, the clinical presentation of thunderclap headache without evidence of subarachnoid hemorrhage should be the main prompt to making this diagnosis or consulting with a neurologist.
TEMPORAL ARTERITIS
Temporal arteritis, also known as giant cell arteritis, is an inflammatory condition affecting the small and medium­sized intracranial and extracranial vessels. Primarily a disease of those >50 years old, its incidence increases with age. In addition to headache (over 80% of patients), associated symptoms may include fatigue, fever, proximal muscle weakness, jaw claudication, or transient ischemic attack symptoms, especially transient visual loss. Sedimentation rate may be elevated, as may C­reactive protein. Check intraocular pressure to exclude glaucoma. Diagnosis is made by the
 presence of three of the five criteria listed in Table 165­6, with sensitivity of .5% and specificity of .2%. Begin treatment with prednisone,  milligrams PO daily, to minimize morbidity from visual impairment and stroke. Consult with an ophthalmologist to determine optic nerve function and a rheumatologist. It is important to ensure rapid and appropriate follow­up for patients discharged from the ED, ideally with their primary care provider.
TABLE 165­6
American College of Rheumatology Criteria for Diagnosis of Temporal Arteritis
Clinical Features Comments
Age at disease onset ≥50 years
New headache Onset or type
Temporal artery abnormality Tenderness to palpation of temporal arteries
Decreased pulsation of temporal arteries
Erythrocyte sedimentation rate ≥50 mm/h Westergren method
Abnormal artery biopsy (can be done after initiating steroids) Vasculitis
Predominance of mononuclear cell infiltration or granulomatous inflammation
Multinucleated giant cells
MIGRAINE
The most common non–life­threatening headache in the ED is migraine (see Table 165­3). Migraine is defined as a headache of moderate to severe intensity that lasts hours (4 to  hours on average) and is usually unilateral, pulsatile in quality, typically associated with both photophobia and phonophobia, and generally made worse with physical activity. The POUND mnemonic (see Table 165­3) can be beneficial, as a patient who meets four
 of five criteria possesses a positive likelihood ratio of  for diagnosis of migraine. Migraine can be episodic or chronic and can occur with or without aura. The characteristics of migraine aura vary widely. Among the most common aura symptoms are lightheadedness and visual changes (scotoma and scintillations). Migraines usually start in childhood and peak around age  years, with gradual decline thereafter. Prevalence is approximately 5% for
 males and 15% to 17% for females.
Chronic migraine is defined as  or more migraine headache days per month over the past  months. Migraine sufferers who present to the ED are
,72 more likely to be chronic headache sufferers.
There are many effective treatment options for management of migraine headache, based on randomized controlled trials. Triptans are considered first­line abortive therapy for migraine at home. However, in the ED setting, most patients have failed abortive therapy and require rescue therapy.
ED Treatment of Migraine

Initial treatment includes IV treatment with dopamine receptor antagonist (droperidol, metoclopramide, prochlorperazine) and NSAIDs (Table 165­
7). Many combinations are effective. Combination with antihistamine (usually diphenhydramine  to  milligrams IV) is helpful to treat
,75 akathisias from antiemetics, although data suggest antihistamines alone are not helpful.
TABLE 165­7
Treatment Options for Migraine Headache
Precautions and Pregnancy
Drug Dosing Contraindications Notes
Category
Ketorolac 10–30 milligrams IV History of peptic ulcer Pregnancy category B , , and  milligrams are equivalent in or IM disease (especially in Avoid in third trimester pain relief elderly)
Prochlorperazine 5–10 milligrams IV Pregnancy category C Antiemetic or PR Drowsiness Concurrent: diphenhydramine
Dystonic reactions
Metoclopramide  milligrams IV Pregnancy category B Antiemetic
Drowsiness Concurrent: diphenhydramine
Dystonic reactions
Droperidol .5 milligrams IV Pregnancy category C Concurrent: diphenhydramine slow, or .5 QT interval prolongation and/or milligrams IM torsades de pointes
Chlorpromazine .5 milligrams IV Pregnancy not classified Antiemetic
Hypotension Pretreat with: normal saline bolus to
Drowsiness minimize hypotension
Dystonic reactions Concurrent: diphenhydramine
Magnesium sulfate  grams IV over  Pregnancy category D but Nonvalidated min effective in preeclampsia and eclampsia
Methylprednisolone 125 milligrams IV or Rescue therapy Nonvalidated
IM
Dexamethasone 6–10 milligrams IV Rescue therapy Adjunctive therapy to reduce recurrence
Sumatriptan  milligrams SC Ischemic heart disease Pregnancy category C
Uncontrolled hypertension
Basilar or hemiplegic migraine
Dihydroergotamine  milligram IV over Pregnancy Pregnancy category X Pretreat with antiemetic
(DHE)  min Uncontrolled Nausea hypertension Vomiting
Ischemic heart disease Diarrhea
Recent sumatriptan use Abdominal pain
(within  h)
Basilar or hemiplegic migraine
Valproate 500 milligrams IV Pregnancy Pregnancy category X Nonvalidated
Ketamine .1–0.3 Hypertension, tachycardia May be used in patients with head trauma, milligram/kg IV Emergence reaction as it does not increase intracranial
Pregnancy category B pressure
,77
Steroids may be useful to reduce the risk for headache recurrence after ED discharge.
Opiates and barbiturate­containing compounds should not be used routinely for abortive migraine therapy unless other standard treatments fail. Not recommended for routine use are ergotamine and codeine­ and tramadol­containing medications, as well as butorphanol and butalbital­containing
,79 medications.
In pregnancy, there are scant data on treatment of migraine. In general, triptans are contraindicated; acetaminophen, opioids, or corticosteroids can be used. Metoclopramide (U.S. Food and Drug Administration category B) may be used. NSAIDs may be also used until the third trimester. Ergotamines and combination agents with caffeine and isometheptene are absolutely contraindicated in pregnant women.
Upon discharge from the ED, more than half of patients will have some residual headache, and there is an increased rate of recurrence of headache
,77,80 within the first  days after discharge. A prescription for abortive medications should form part of the discharge plan for patients discharged from the ED with a diagnosis of migraine. Providers should be familiar with one or two fast­acting triptans (such as sumatriptan, sold as Imitrex® in the
United States, and rizatriptan, sold as Maxalt® in the United States), as well as combinations of triptans, such as sumatriptan/naproxen (sold as
Treximet® in the United States), or combination drugs, such as Midrin® (acetaminophen, 325 milligrams/dichloralphenazone, 100 milligrams/isometheptene,  milligrams).
OCCIPITAL NEURALGIA
Occipital neuralgia is characterized by paroxysms of lancinating pain at the back of the head, in the distribution of the greater and/or lesser occipital nerve. Patients describe the pain as stabbing or electric shock–like in quality, with hypersensitivity in the distribution of the affected nerve. Most cases are attributed to chronic neck tension or unknown causes. However, the condition can be associated with osteoarthritis or degenerative disease of the upper cervical spine. Occipital nerve block typically results in marked improvement of symptoms, and the results can persist for weeks after the injection. The procedure is both diagnostic and therapeutic. The procedure can be performed with ease in any setting and requires minimal expertise.
IDIOPATHIC INTRACRANIAL HYPERTENSION (PSEUDOTUMOR CEREBRI SYNDROME)
Idiopathic intracranial hypertension, also known as pseudotumor cerebri, is most common in obese women. The incidence is .3 per 100,000 obese women between the ages of  and  years and has increased with the obesity epidemic. The most prominent symptoms include headache (84%), transient visual obscurations (68%), back pain (53%), and pulsatile tinnitus (52%). Only 32% of patients report visual loss. Untreated, idiopathic
 intracranial hypertension can lead to permanent visual impairment if not recognized and treated appropriately.
The diagnostic criteria include papilledema with an otherwise normal neurologic examination and elevated opening pressure on LP (>25 cm H O in
 adults and >28 cm H O in children), in the setting of normal cerebrospinal fluid composition and normal imaging (having excluded other causes of
 raised intracranial pressure). Treatment is focused on preservation of vision. A variant of pseudotumor has been identified that does not present with papilledema but may present with the other clinical features of pseudotumor cerebri, along with abducens nerve palsy (unilateral or bilateral). In the absence of either papilledema or abducens nerve palsy, the diagnosis of pseudotumor without papilledema can be made if at least three of the following neuroimaging findings are present: empty sella, flattening of the posterior aspect of the globe, distention of the perioptic subarachnoid
 space with or without a tortuous optic nerve, and transverse venous sinus stenosis.
LP is necessary to make the diagnosis of idiopathic intracranial hypertension, and concomitant removal of a volume of cerebrospinal fluid can provide
 temporary relief of symptoms. However, subjective improvement of symptoms after LP is not reliable in establishing the diagnosis. Perform the LP with the patient in the lateral decubitus position, without sedation (which may cause mild hypercapnia and, subsequently, an elevated cerebrospinal fluid pressure measurement). The knees should be extended for measurement of cerebrospinal fluid pressure, and the base of the manometer should be level with the right atrium. Elevated cerebrospinal fluid pressures can occur in the setting of the Valsalva maneuver, such as breath holding and crying, and if the pressure is measured in the sitting position. Cerebrospinal fluid can be removed in multiple aliquots, measuring cerebrospinal fluid pressure after each removal, until a target pressure of  to  cm H O is achieved. Determine the opening pressure. In general, removal of  mL of

 cerebrospinal fluid will lower the cerebrospinal fluid pressure by about  cm H O. To avoid lowering the pressure excessively, first
 remove  mL for every  cm H O reduction desired, and then remeasure cerebrospinal fluid pressure. Excess cerebrospinal fluid removal can result in
 intracranial hypotension and a “low­pressure headache,” which may require epidural blood patch for relief.
Ultrasound assessment of the optic nerve sheath is helpful when considering the diagnosis of idiopathic intracranial hypertension as a cause of headache. Literature suggests US is sensitive for detection of increased ICP, with sensitivity over 90% and specificity ranging from 67% to 85%. A disadvantage is the lack of a uniform cut­off level for the diagnosis of increased ICP. Optic nerve sheath diameter <  mm diameter is considered normal and >  mm abnormal, but the significance of measurements between 5­6 mm are controversial. However, a normal sheath diameter does not exclude a life­threatening disease, and US should be used in conjunction with other clinical assessments.
Oral acetazolamide can be effective in lowering intracranial pressure and decreasing symptoms of idiopathic intracranial hypertension. Treatment is
 typically started at 250 to 500 milligrams twice a day. The dose can be increased to as much as  grams/d, but dose escalation is associated with significant side effects (paresthesias, fatigue, decreased libido, metallic taste) and should be done under the supervision of a neurologist or
 ophthalmologist for ongoing monitoring of papilledema and visual field testing to minimize the risk of visual loss. Long­term interventional management may include cerebrospinal fluid shunting and optic nerve sheath fenestration for failing vision. For obese patients, weight loss is
 recommended.
INTRACRANIAL HYPOTENSION
The headache of intracranial hypotension (low­pressure headache) is most commonly associated with recent dural penetration, either during LP,
 epidural anesthesia, or any operative procedure that involves opening the dura. Using a noncutting needle reduces the risk of post­LP headache.
87­89
Rarely, intracranial hypotension can occur spontaneously or in association with head or spine trauma. Clinical features include headache that increases in severity with upright posture but improves or resolves in the supine position. Associated symptoms, such as alterations in hearing or vision, nausea, vomiting, diplopia, and visual changes, may occur. MRI, with and without contrast, confirms the diagnosis by showing diffuse enhancement of the meninges. The LP, if performed, should have an opening pressure <6 cm H O. Most patients experience spontaneous resolution
 of their symptoms. Evidence to support treatments such as IV fluid resuscitation and IV caffeine is limited. The most effective therapy for low­pressure
,90 headache is an epidural blood patch, typically performed by anesthesiologists.
CARCINOMATOUS MENINGITIS
About 5% to 10% of patients with cancer develop leptomeningeal metastases. In addition to headache, cranial nerve abnormalities (typically more than one) and other neurologic findings may be present. Risk factors for carcinomatous meningitis include aggressive lymphoma subtypes and uncontrolled systemic disease. In suspected patients, the appropriate testing would include MRI with and without contrast (to evaluate for meningeal enhancement). Obtain MRI before LP, as MRI evidence of meningeal enhancement is common after LP and may confound the diagnosis. LP may reveal an elevated opening pressure (>20 cm H O). Cerebrospinal fluid analysis should include cytology (solid tumors) or flow cytometry (hematologic

 tumors). Malignant cells degrade quickly, so timely review of cerebrospinal fluid is important.
CLUSTER HEADACHE
Cluster headaches (Table 165­4) occur in about .4% of the general population and can mimic dental pain. More common in men, cluster headaches typically start in adulthood and tend to occur in “clusters,” with a circadian and circannual pattern, recurring daily for more than a week and remitting for at least  weeks. Episodes are typically unilateral and excruciating, but brief and self­limited. Up to 10% of patients will experience a more chronic form, with fewer episodes of remission. Associated ipsilateral symptoms are common (Table 165­4), and a distinguishing feature of this headache is the need for the patient to “pace,” in contrast to the patient with migraine, who prefers to lie still in a quiet and dark room. Treatment consists of
,93
100% oxygen administered at  L/min for  minutes through a nonrebreathing facemask. Sumatriptan,  milligrams SC, can also be used, as can
 single­dose intranasal lidocaine 10% solution (effective in over one third of patients).
HYPERTENSIVE HEADACHE
There is no compelling evidence linking mild to moderate hypertension with headache. Several studies using ambulatory blood pressure monitoring have found no association between mild to moderate high blood pressure (systolic blood pressure <180 mm Hg and/or diastolic blood pressure <120
 mm Hg) and patient self­reported headache. Uncontrolled hypertension can be associated with headache, especially in conditions where there is a
 rapid and marked rise in blood pressure, such as pheochromocytoma, posterior reversible encephalopathy syndrome, hypertensive crisis,
 preeclampsia, and eclampsia.
METABOLIC CAUSES OF HEADACHE
Metabolic headaches are hallmarked by deterioration in the setting of a disorder of homeostasis and typically improve after resolution of the disorder
 of homeostasis (Table 165­8).
TABLE 165­8
Metabolic Causes of Headache
History Examples Treatment
Hypoxia/hypercapnia High altitude Acetaminophen/ibuprofen
Acetazolamide 125–250 milligrams twice a day
Steroids (dexamethasone)
Prophylaxis: acetylsalicylic acid, 320 milligrams at 4­h intervals, starting  h prior to ascent; repeat  times
Air travel Nonsteroidal anti­inflammatory drugs (NSAIDs), pseudoephedrine, and nasal decongestants
Pulmonary disease
Congestive heart failure
Sleep apnea
Dialysis Analgesics during dialysis
Autonomic dysreflexia (typical in Seated position quadriplegia) Remove/loosen clothing
Scrutinize for bladder distention/bowel impaction
Other Hypothyroidism
Fasting
Cardiac cephalgia (associated with myocardial ischemia)
CAROTID AND VERTEBRAL ARTERY DISSECTION
Cervical artery dissection, including both the carotid and vertebral arteries, is an important diagnosis, although it can be difficult to make in the ED.
,97
Cervical artery dissection accounts for 2% of all strokes and up to one quarter of strokes in young adults. Cervical trauma, including coughing, sneezing, and physical activity, is associated in close to 40% of cases. Headache is the predominant symptom, although some patients may present
98­100 with neck or facial pain. Delayed onset of neurologic symptoms by several days is common.
Internal carotid dissection will present with anterior circulation symptoms, while vertebral artery dissection more commonly presents with posterior circulation symptoms. Other symptoms include cranial nerve palsies, vision changes, Horner’s syndrome, and pulsatile tinnitus. Diagnosis requires CT
101­103 with IV contrast or MRI/magnetic resonance angiography.
CARBON MONOXIDE TOXICITY
Carbon monoxide toxicity is a dangerous etiology of headache. Smoke inhalation, heating sources with inadequate ventilation, and engine exhaust exposure are the most common etiologies. Symptoms include headache, myalgias, nausea/vomiting, and dizziness, although confusion, loss of consciousness, focal neurologic deficit, and death can result from severe exposure. Carbon monoxide toxicity should be suspected in the setting of
104,105 multiple household members and pets with similar symptoms including headache and concerning exposure. Pulse oximetry should not be relied
106 on for screening or diagnosis, and co­oximetry is required. Treatment includes oxygen supplementation, although hyperbaric oxygen therapy may
107 be required in specific circumstances.
PITUITARY APOPLEXY

Pituitary tumor apoplexy is a rare clinical diagnosis that is usually due to spontaneous hemorrhage or infarction of a preexisting pituitary adenoma.
108­110
Pregnancy, head trauma, pituitary radiation, and dopamine agonist therapy are other risk factors. The earliest symptom is sudden, severe
108 headache. The headache location tends to be retro­orbital, bifrontal, or suboccipital. Between 63% and 100% of patients will experience headache.
Associated symptoms may include ophthalmoplegia, reduced visual acuity, visual field defects (up to 75% of patients), altered consciousness, meningismus, and nausea and vomiting. CT (noncontrast) and MRI may show a sellar mass and hemorrhage. In the first  to  hours, the hyperacute hemorrhage may be easier to see on CT than MRI. MRI should be pursued after negative CT. Pituitary adenomas and cerebral aneurysms have a co­
108 occurrence rate of .4%. Pituitary tumor apoplexy requires immediate treatment with corticosteroids and urgent neurosurgical consultation. The treatment usually requires consultations from endocrinology, ophthalmology, and neurology with intensive care monitoring.
THIRD VENTRICLE COLLOID CYSTS
Colloid cysts of the third ventricle are a rare cause of acute neurologic deterioration and sudden death. The colloid cyst is usually congenital, slow
111 growing, and benign, accounting for about .2% to 2% of all intracranial tumors, but it is the most common tumor of the third ventricle. The usual clinical presentation is a history of severe paroxysmal and episodic attacks of (typically frontal) headache associated with nausea and vomiting. The presumptive cause is the intermittent obstruction of cerebrospinal fluid flow through the foramina of Monro with associated rapid increase in
112 intracranial pressure.
ACUTE ANGLE­CLOSURE GLAUCOMA
Acute angle­closure glaucoma results from obstruction of aqueous humor flow due to narrow anterior chamber angle. This leads to increased intraocular pressure. Peak incidence occurs over age , and pupillary dilatation can precipitate an attack. Presentation includes abrupt eye pain, vision changes, and headache, although nausea and vomiting may occur. Decreased visual acuity, mid­fixed dilated pupil, and an edematous cornea
113­115 may be found on exam. Diagnosis includes ocular pressure greater than  mm Hg, although this is usually greater than  mm Hg.
PREECLAMPSIA
Preeclampsia may present with headache and should be considered in a female after  weeks of gestation up to  weeks postpartum with blood pressure greater than 140/90 mm Hg in combination with proteinuria or end­organ damage. Proteinuria is not required for diagnosis, and
116 hypertension with thrombocytopenia, renal insufficiency, impaired liver function, cerebral or visual disturbance, or pulmonary edema is diagnostic.
OTHER CAUSES
Other etiologies of headache include sinusitis, Valsalva­associated headache, and coital headache.


