## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 139: Headache in Children
David Sheridan; Garth D. Meckler
INTRODUCTION AND EPIDEMIOLOGY
Headache is pain in the scalp and cranium. Headaches in children can be mild, refractory, or life threatening, and can represent an acute, subacute, or chronic process. Headaches are broadly classified as primary headache disorders, which are intrinsic to the nervous system, and secondary headaches, which are caused by another condition such as trauma, infection, or intracranial or systemic disease (see later section, “Headache
Classification”).
Headaches are common in children, with an increasing prevalence through childhood and a peak in adolescence. The mean prevalence of headache in
1­3 childhood is .4%, with a range of 24% to 90%, and 17% of children in the United States reported frequent or severe headaches in the past year.
Headache prevalence is similar in girls and boys prior to adolescence, but after puberty, they are more prevalent in girls. Overall, primary headache
,5 disorders are more common than secondary headaches, and migraine and tension­type headaches are most common. The peak incidence of migraine is earlier for boys (10 to  years) than girls (12 to  years), and migraine with aura starts  to  years earlier than migraine without aura in
  both sexes. Tension­type headache has a mean age of onset of  years and is more common in girls. The estimated overall prevalence of migraine in
7­10 childhood is .76% to 18%, and the overall prevalence of tension­type headache is 10% to 25%.
Frequent or sustained headaches have a significant impact on children and their families, contributing to school absenteeism and missed parental
11­13 work, and may even induce behavioral disturbances. Migraine headaches are among the top five causes of years lost to disability according to the
 ,15
World Health Organization, and children with migraines experience similar impact on quality of life as those with cancer or juvenile arthritis.
16­18
There is an association between chronic headache and psychiatric comorbidity among children.
Headaches compose about 1% to 2% of all ED visits among children, and in the ED setting, secondary headaches are more commonly diagnosed than
,19­22 primary headaches. Infectious etiologies such as upper respiratory tract infection are the most common cause of secondary pediatric headache
,19­21,23­25 in the ED, whereas migraine is the most common primary headache disorder diagnosed in this setting. There appears to be some seasonal
26­28 variation in ED visits for headache, with peaks in September and January and lower visit rates in the spring and summer months.
PATHOPHYSIOLOGY
The pathophysiology of headaches is complex and varies according to cause. The cranium, most of the overlying meninges, brain, ependymal lining, and choroid plexus do not possess pain receptors. Extracranial pain may arise from cervical nerve roots, cranial nerves, or extracranial arteries, and intracranial pain may arise from intracranial venous, arterial, or dural structures. Cranial nerve or root pain can radiate to the occiput, ear, retroauricular areas, or throat.
HEADACHE CLASSIFICATION
Headaches are classified as primary or secondary based on the underlying cause. Primary headaches are physiologic or functional and are typically self­limited, although they may become persistent (e.g., status migrainosus) or chronic. Primary headache disorders include migraine, tension­type headache, chronic daily headache, and cluster headache; cluster headaches are more commonly seen in the adult than pediatric population. The gold
 standard diagnostic criteria are the International Criteria for Headache Disorders 3rd ed, beta version (Table 139­1). Although these diagnostic criteria rely on recurrent attacks, in an ED, a child may present with a first migraine headache due to intractable pain. One study investigated the utility of applying the International Headache Society criteria in the ED without the “recurrent” requirement (“Irma Criteria”) and fDoouwndn ltohaed cerdit e2r0ia2 5to­7 b­1e q6u:1it3e Pse nYsoituivr eI Pin i sd i1a3g6n.o1s4in2g.1 f5ir9st.1­t2im7e migraines when followed long term using the original International Headache Society
Chapter 139: Headache in Children, David Sheridan; Garth D. Meckler 
 criteria as the gold standard.
. Terms of Use * Privacy Policy * Notice * Accessibility
TABLE 139­1
International Headache Society Diagnostic Criteria for Common Primary Headache Disorders (3rd ed, Beta Version)29
Primary
Headache Diagnostic Criteria Comments
Disorder
Migraine . At least  attacks with features 2–3 below In children, pain is more often bilateral and less often pulsating. Usually without . Headache duration 2–72 hours frontotemporal in location. Photophonophobia may be inferred from aura . At least  of the following: behavior in young children.
a. unilateral Symptoms persisting >72 h are termed status migrainosus.
b. pulsating c. moderate or severe intensity d. made worse with activity
Migraine . At least  attacks with features below Visual and sensory symptoms are common in children, as are autonomic with aura . One or more reversible auras: symptoms. Systemic prodromal symptoms (e.g., fatigue, elated or depressed a. visual mood) may precede aura by 24–48 h.
b. sensory c. speech/language d. motor e. brainstem f. retinal
. At least  of the following: a. gradual spread of aura (>5 min) b.  or more symptoms may occur in succession c. individual symptoms last 5–60 min d. at least  symptom is unilateral e. at least  symptom is positive f. accompanied or followed by headache within  min
Probable . Attacks fulfilling all but  of the criteria for migraine Includes those not meeting required number of prior attacks for migraine migraine without aura with or without aura.
. Attacks fulfilling all but  criterion for migraine with aura
Tension­ . At least  episodes of headache occurring on <1 d per Probable tension­type headache is missing  of the required features for type month (infrequent episodic) or 1–14 d per month for at formal diagnosis. Chronic tension­type headache is defined as occurring ≥15 headache least  mo (frequent episodic) d per month for >3 mo.
. Headache lasting  min to  d
. At least  of the following: a. bilateral b. pressing or tightening quality (nonpulsating) c. mild or moderate intensity d. not worsened by routine activity
. Both of the following: a. no nausea or vomiting b. no more than  of photophobia or phonophobia
Cluster . At least  attacks with features below Attacks can occur in series and last weeks to months with symptom­free headache . Severe or very severe unilateral, orbital/supraorbital, intervals.
and/or temporal pain lasting 15–180 min (untreated) Usual age of onset is  y, but occasionally seen in children.
. Either or both of the following: a. at least  ipsilateral symptom or sign: i. conjunctival injection and/or lacrimation ii. nasal congestion and/or rhinorrhea iii. eyelid edema iv. forehead and facial sweating v. miosis and/or ptosis b. sense of restlessness
. Occurs with a frequency from  every other day to  per day
Secondary headaches are a symptom of another underlying disorder and include a wide range of etiologies. Table 139­2 lists common and life­
31­33 threatening causes of secondary headaches. Although primary headaches can be disabling, secondary headaches result in morbidity and mortality if not treated.
TABLE 139­2
Common and Life­Threatening Causes of Secondary Headache31­33
Etiology Serious or Life­Threatening Causes Common Causes
Infection Meningitis Viral upper respiratory tract infection
Encephalitis Sinusitis
Orbital or intracranial abscess Pharyngitis
Odontogenic infection
Trauma Traumatic intracranial hemorrhage Mild traumatic brain injury (concussion)
Vascular Intracranial hemorrhage
Stroke
Hypertension
Neoplastic Primary or metastatic intracranial tumor
Toxic Carbon monoxide Caffeine
Heavy metals
Cocaine
Systemic disease Diabetic ketoacidosis (cerebral edema)
Systemic lupus erythematosus
Vasculitis
Sickle cell disease
Other Idiopathic intracranial hypertension Temporomandibular joint dysfunction
Postictal headache
Fasting
Sleep apnea
CLINICAL FEATURES
Clinical characteristics of pediatric headache vary greatly by classification and etiology; however, the details of the headache including onset, pattern, location, quality, and associated symptoms are helpful in determining the cause and directing further investigation and treatment. Red flag clinical
33­37 features associated with life­threatening secondary headaches are listed in Table 139­3. TABLE 139­3
Red Flag Clinical Features of Serious Secondary Headaches
Clinical
Red Flags Potential Causes Comments
Features
Chronology Sudden onset Vascular etiology SAH
New­onset persistent Intracranial pain (>2 wk) pathology
Pattern Wakens from sleep Elevated ICP Medication overuse can exacerbate the pattern of primary headache disorders,
Early morning leading to progressive frequency/severity headache
Progressive frequency/severity
Location/quality Inability to describe Secondary Previously occipital location thought to be associated with secondary headaches, but pain headache no longer supported by recent evidence
Exacerbating Recumbency Elevated ICP Idiopathic intracranial hypertension is a less serious cause factors Valsalva
Associated Fever Serious infection Neurologic symptoms concerning for intracranial pathology symptoms Morning vomiting Intracranial
Behavior/cognitive pathology change Diabetic
Seizures ketoacidosis
Motor/gait dysfunction
Visual symptoms
Systemic symptoms
Demographics Age <4 y CNS tumor Primary headaches possible but less common; CNS tumors common in this age group
Medical history Sickle cell disease Stroke
Bleeding disorders Vasculitis
Rheumatologic Elevated ICP/bleed disease into tumor
Malignancy Intracranial mass
Cranial shunt lesion
Phakomatoses
Family history No primary headache Secondary Migraines have a strong genetic component and frequent family history of headaches history headache
Family history of SAH
Inherited genetic disorders
Other Medications Pseudotumor
Environmental/toxins Analgesic overuse
Carbon monoxide poisoning
Heavy metal poisoning
Abbreviations: ICP = intracranial pressure; SAH = subarachnoid hemorrhage.
TEMPORAL ASPECTS OF HEADACHE
Age of Onset
As mentioned earlier, headaches increase in incidence and prevalence throughout childhood, and initial onset varies by etiology. Although overall rare in children <5 years of age, primary headaches can and do occur in this age group; migraine with aura, for example, can begin as early as age  to 
,6,38,39 years for boys, and 37% to 50% of 7­year­old children report experiencing headache. Complex migraines (hemiplegic, confusional, or basilar type) may have their onset at a young age as well; however, incapacitating headache in a young child, especially when associated with vomiting or gait
 changes, suggests an intracranial mass with an infratentorial location being the most common location. Among a cohort of children age  to  years presenting to the ED with headache, the vast majority of headaches were associated with benign viral infections, and only  of 364 patients in the
 cohort was diagnosed with a tumor (this patient had an abnormal neurologic exam).
Temporal Pattern
Table 139­4 summarizes the association between overall temporal patterns of headaches and potential etiologies. In general, a pattern of acute recurrent or chronic nonprogressive headaches suggests a primary headache disorder.
TABLE 139­4
Temporal Patterns of Headache in Children
Type Temporal Pattern Causes
Acute headache Single episode of head pain without history of previous events Upper respiratory tract infection, sinusitis, first migraine, medication use, trauma
Acute recurrent headache Pattern of head pain separated by symptom­free intervals Migraine
Chronic progressive Gradual increase in frequency and severity; may be worse in the Space­occupying lesion, hematoma, pseudotumor headache morning or awaken at night cerebri
Chronic nonprogressive Frequent or constant headache Tension headache, cluster headache headache (chronic daily)
Mixed headache Acute recurrent headache superimposed on chronic daily Typically migraine (acute recurrent headache) background pattern; variant of chronic daily headache superimposed on chronic daily headache
Headache coinciding with the onset of fever suggests inflammation of some sort, typically infectious (e.g., sinusitis, pharyngitis, otitis, or meningitis), or may be associated with a more general viral syndrome. Abrupt occurrence of severe headache due to a serious underlying condition, such as a brain tumor or intracranial hemorrhage, is typically associated with one or more objective findings on neurologic
,20,33,36 examination (e.g., altered mental status, ataxia, nuchal rigidity, papilledema, or hemiparesis). Cluster headaches also tend to develop acutely, whereas tension headaches have a more subacute onset. Hormonal cycles can trigger migraine headaches in adolescent females.
Migraine headaches in children typically start relatively abruptly, intensify over several minutes, and then reach full intensity in
 about an hour. Young children often have headaches that begin in the late afternoon.
HEADACHE PRECIPITANTS
Viral illnesses and fever are among the most common causes of headache in children, and the associated headaches are most
,23­25,41 frequently frontal or temporal. A history of trauma may suggest posttraumatic headache or traumatic brain injury. Posttraumatic
42­45 headaches may be chronic as well. Migraines, more common and better studied in adults and adolescents, may be accompanied by premonitory
 symptoms (prodromes such as fatigue, mood changes, or GI symptoms) and have identifiable triggers. Children with prodromes tend to have more characteristic triggers as a whole, which may include specific foods (e.g., chocolate or monosodium glutamate), stress, light, specific odors, and
 weather changes. Headaches are among the most commonly reported symptoms in toxic exposures such as carbon monoxide poisoning. Additional precipitants include medications (e.g., methylphenidate, steroids, oral contraceptives, or anticonvulsants), infection (e.g., sinusitis, pharyngitis, or
31­33 meningitis), hypertension, anemia, and substance abuse (e.g., cocaine).
LOCATION OF HEADACHE
In a cohort of children with headaches presenting to a pediatric ED, only .5% of patients could identify a precise location of the pain. Among children
 with intracranial diseases, most either were unable to indicate the location of the pain or had an occipital headache. More recently, studies of
,49 occipital headache in children have not shown an increased association with serious secondary causes of headache. Medications, hypertension, and basilar­type migraines can also cause headaches in the occipital region. Pain at the vertex can be seen with sphenoid sinusitis. Ethmoid, maxillary, and frontal sinus infections tend to cause retro­orbital pain, as does meningitis (along with fever and neck stiffness) and dural sinus thrombosis. Pain seemingly in, around, or in front of the ear (or entire temporal region) is often seen with temporomandibular joint (TMJ) dysfunction and can be reproducible on exam. Migraine headaches are usually unilateral and involve the frontal or temporal region in adolescents. However,
 in younger children, they are usually bifrontal or generalized. Only about a third of children have unilateral migraines. Tension headaches tend to have the greatest variability in location. They may be generalized, frontal, or even occipital/posterior cervical.
QUALITY OF HEADACHE
Younger children and many developmentally normal, otherwise healthy children may have a difficult time describing the quality of their headaches. An ability to describe pain quality or a description of the headache as having a pulsating quality is more frequently associated with benign headaches. An
,32,36,50 inability to describe the pain or a description of the headache as constrictive indicates a greater likelihood of a more serious cause. Many different qualities of pain can be identified: stabbing or hyperesthetic pain has been associated with herpes zoster; aching pain with tension headaches, meningitis, or encephalitis; and constant pain with sinusitis in all locations. A pulsating quality is one of the diagnostic criteria for migraine headache set forth by the International Headache Society, but can also be seen with headaches caused by hypertension or intracerebral hemorrhage.
SEVERITY OF HEADACHE
The severity of a headache is neither a sensitive nor a specific characteristic in determining cause. Patients with tension headaches can complain of terrible pain, whereas a child with a brain tumor may complain of mild to moderate pain. Nonetheless, complaints of very intense pain should be taken seriously and assessed in context with other historical elements. Ask about and document presenting pain assessments in children with primary headache disorders because treatment end points will be dictated by improved pain scores in the ED.
DURATION OF HEADACHE
Although the duration of a headache is not particularly useful in assessing the majority of headaches, the International Headache Society definition of migraines requires a duration of symptoms of  to  hours in adults, but the duration may be less (1 to  hours) in children. A migraine that lasts >72 hours is known as status migrainosus. Children often present to the ED with this condition and should be treated appropriately (see later section,
“Treatment”).
ALLEVIATING AND EXACERBATING FACTORS

Patients with a sense of restlessness or agitation are more likely to have cluster headaches (rarer in children). They may pace about the room or rock back and forth in a chair. In contrast, patients with migraines typically prefer silence and darkness because the lack of stimulation provides some relief,
 and photophobia/phonophobia are part of the diagnostic criteria for migraine headache (Table 139­1). Tension headaches can be frequent and
 frustrating but tend not to be aggravated by routine physical activity. Positional preferences (such as a head tilt) may be noted in children with spaceoccupying lesions in order to avoid positions that increase intracranial pressure or exacerbate diplopia caused by cranial nerve dysfunction. In addition, children with increased intracranial pressure may be unable to look up or may avoid the Valsalva maneuver (e.g., defecation or coughing).
Analgesic rebound headaches worsen when the patient goes a certain period of time without taking long­term pain medication or overuses analgesics.
ASSOCIATED SYMPTOMS
Eliciting associated symptoms can help narrow the differential diagnosis. Migraine headache with aura, by definition, is associated with visual, sensory, or speech disturbances (all fully reversible; Table 139­1). Specific symptomatology may distinguish between types of migraines such as confusional
(e.g., distortions of visual size, space, or time) and hemiplegic (e.g., transient hemiparesis or aphasia). Hemiplegic migraines are uncommon, so think carefully about other causes of neurologic deficits when contemplating the differential diagnosis. Abdominal pain, nausea, or vomiting may occur
 along with migraine headache. Cluster headaches can be associated with multiple ipsilateral symptoms (Table 139­1). Headache with effortless vomiting but no GI complaints is characteristic of elevated intracranial pressure. Irreversible and progressive defects in visual acuity and diplopia are more suggestive of pseudotumor cerebri. Seizures and headache may indicate traumatic brain injury, concussion, arteriovenous malformation, subarachnoid hemorrhage, or tumor. A headache with fever and focal neurologic signs (with or without seizure) may suggest an intracranial abscess, encephalitis, or meningitis (especially with neck stiffness). Children who present with headache, altered mental status, and seizures must be evaluated
 for meningoencephalitis from herpes simplex virus.
DIAGNOSIS
The diagnosis of pediatric headache is primarily clinical and largely derived from a thorough history and physical examination.
HISTORY
Obtain a thorough history to elicit clinical features related to the presenting headache and past headaches as described earlier. Include a past medical history because acute headaches must be considered both independently and within the context of the child’s medical history: secondary headaches can occur even when there is a history of primary headaches; and although it is helpful if a child has a history of similar past headaches, a first­time headache does not preclude a primary headache disorder, as described previously. Concurrent chronic illness may predispose the patient to unique headaches (e.g., those associated with ventriculoperitoneal shunt malfunction or infection), headaches from infection (e.g., related to anatomic defects or immunosuppression predisposing to meningitis; or acute illness with sinusitis leading to brain abscess), or headaches caused by intracranial hemorrhage (e.g., due to hemophilia or anatomic arteriovenous anomalies).
Ask about family history as well. Headaches occur more often in children who have a family history of headaches in either first­ or second­degree
,32 relatives. This association is particularly true for children with migraines (family history of migraines in up to 90% of cases). Children with cluster headaches rarely have a family history of similar headaches (about 7%). Children with a parent who experienced a subarachnoid hemorrhage are at a four times greater risk of this type of intracranial bleed than the general population. Predisposing genetic disorders may provide some clue to a familial link in headaches (e.g., bleeding diathesis, familial dyslipidemias, or atherosclerotic events).
PHYSICAL EXAMINATION
The physical examination is the most important tool to distinguish benign from life­threatening headaches. Table 139­5 lists physical exam features and their relation to important secondary headache etiologies. While a careful neurologic examination with attention to cranial nerves (including vision), gait, strength, and mental status is essential to exclude intracranial causes of secondary headache, additional clues to serious secondary headaches include vital signs, growth parameters, and a thorough head­to­toe exam.
TABLE 139­5
Physical Examination Findings Associated With Potential Secondary Causes of Headache
Examination
Finding Potential Causes
Component
Growth Abnormal height, Failure to thrive indicative of systemic disease; enlarged head circumference suggestive of increased intracranial parameters weight, head pressure circumference for age
Vital signs Abnormal heart Bradycardia, hypertension, and irregular respirations (Cushing’s triad) indicative of intracranial hypertension and rate, blood impending herniation; severe hypertension associated with headache in hypertensive crisis; tachypnea possibly pressure, indicative of metabolic acidosis (e.g., diabetic ketoacidosis); fever possibly indicative of CNS or systemic infection respiratory rate, (meningitis, encephalitis, viral syndrome) temperature
Head and Cranial or carotid Arteriovenous malformation neck bruits
Bulging fontanelle Hydrocephalus
Splayed sutures
Macrocephaly
Signs of trauma Accidental or inflicted trauma
Head tilt Ocular nerve palsies from CNS tumor
Eyes Papilledema Increased intracranial pressure (pseudotumor, tumor, shunt failure, intracranial bleeding, hydrocephalus)
Inability to look up: Hydrocephalus
“sunset eyes”
Unilateral Cluster headache conjunctival injection, tearing, eyelid edema without tenderness
Retinal hemorrhage Nonaccidental trauma
Bilateral periorbital Sinusitis edema, facial tenderness, nasal discharge
Proptosis Orbital cellulitis or tumor
Ear, nose, Signs of infection Otitis media, mastoiditis, sinusitis, pharyngitis (including streptococcal pharyngitis), dental abscess or caries throat
Malocclusion, TMJ TMJ dysfunction tenderness
Heart Murmurs Potential shunting lesion with risk of embolic event or cerebral abscess
Skin Café­au­lait spots, Neurofibromatosis, tuberous sclerosis, congenital vascular malformations (risk for CNS hemorrhage) ash­leaf spots, vascular malformations
Neurologic Cranial nerve Any focal neurologic deficit may be associated with intracranial pathology or metabolic derangement (e.g., hyperdeficits /hypoglycemia)
Motor weakness
Abnormal tone or reflexes
Abnormal gait
Ataxia
Altered level of consciousness
Abbreviation: TMJ = temporomandibular joint.
LABORATORY TESTING
No laboratory testing is needed for primary headaches, which are a clinical diagnosis. If secondary headache is a consideration, obtain laboratory evaluation directed by the history and physical examination. Blood tests that may be useful in specific clinical situations include CBC, serum glucose level, electrolyte levels, renal function tests, liver function tests, blood culture, and drug screen. Perform a lumbar puncture if meningitis or encephalitis is suspected, and send cerebrospinal fluid for Gram stain, culture, appropriate viral studies, glucose, protein, and cell count (see Chapter
120, “Meningitis in Infants and Children”). If pseudotumor cerebri is suspected, perform a lumbar puncture with the patient in the lateral decubitus position and measure the opening pressure. A lumbar puncture may also be needed to rule out a subarachnoid hemorrhage if there is a high level of
,53 suspicion but the findings of a CT scan of the brain are normal. Focal neurologic deficits or signs of increased intracranial pressure warrant a CT scan prior to lumbar puncture; however, clinical signs of probable impending herniation are the best indicators of when to delay a lumbar puncture,
 even in the setting of normal CT scan results.
IMAGING
Imaging studies are not needed for primary headache disorders or recurrent headaches when the findings of the neurologic examination are normal. Despite the importance of history and examination, one study reported that almost 40% of all children with headache who
 were evaluated in the ED underwent head imaging with radiation. There is a very low incidence of positive findings on neuroimaging studies in
,34­37,56,57 children with headache who have normal findings on physical examination. Consider imaging in children with abnormal findings on neurologic examination, altered mental status, or concurrent seizures, or if medical history indicates the recent onset of severe (worst) headache, a
,32,34­37,58 change in the type of headache, or associated features that suggest neurologic dysfunction.
Reserve CT scans for instances in which there is a highly suspicious history, neurologic findings on examination are abnormal, or an intracranial hemorrhage or a space­occupying lesion is suspected. Noncontrast head CT is sensitive for detecting skull fracture and brain injury from trauma and may identify supratentorial tumors and stroke; give IV contrast if considering intracranial abscess.
A normal head CT does not exclude an intracranial mass because the posterior fossa is not well visualized. The posterior fossa is the most common location of brain tumors in children, and MRI of the brain provides better visualization of the posterior fossa.
Magnetic resonance angiography and venography are useful when vascular malformations or dural sinus thrombosis is suspected. MRI may require sedation based on the patient’s age. The decision to admit a child for MRI or to obtain outpatient imaging depends on the practice location and deserves a discussion with an inpatient team as well as a primary care provider.
TREATMENT
Treatment of headache in the ED depends on etiology. Treat the underlying cause of secondary headache and provide analgesia for pain. For secondary headaches, simple analgesics such as NSAIDs and acetaminophen are usually sufficient, although opioid analgesics may be needed for some severe secondary headaches (see Chapter 115, “Pain Management and Procedural Sedation in Infants and Children”).
Abortive therapy for primary headaches also varies by type. Few prospective randomized trials for migraine therapy have been conducted on children, and even fewer in the ED setting, so most recommendations are extrapolated from adult trials, and significant practice variation has been
,59­63 observed. Table 139­6 lists various pharmacologic options for migraine and cluster headache along with recommended dosing. Overall,
 abortive therapy in the ED is highly successful, with >85% of children successfully discharged and only a .5% ED return visit rate.
TABLE 139­6
Pharmacologic Abortive Therapy for Primary Headaches
Class Medication Dose
NSAIDs Ibuprofen  milligrams/kg: PO (max: 800 milligrams/dose or 2400 milligrams/d)
Ketorolac .5 milligram/kg: IV (max:  milligrams/dose)
Analgesics Acetaminophen  milligrams/kg: PO/PR (max:  gram/dose or  grams/d)
Dopamine antagonist Prochlorperazine .15 milligram/kg: IV (max:  milligrams/dose)
Metoclopramide .1 milligram/kg: IV (max:  milligrams/dose)
Other antiemetic Diphenhydramine  milligram/kg: IV (max:  milligrams/dose)
Promethazine .25–1 milligram/kg: IV (max:  milligrams/dose)
Triptans (more available than listed here) Sumatriptan Multiple routes:
5–20 milligrams: intranasal
3–6 milligrams: SC
50–100 milligrams: PO
Rizatriptan 5–10 milligrams: PO
Sumatriptan/naproxen combination Multiple combinations
 milligrams/500 milligrams: PO (sumatriptan/naproxen)
 milligrams/180 milligrams: PO
 milligrams/60 milligrams: PO
FIRST­LINE THERAPY
First­line therapy for all types of primary headaches includes oral NSAIDs and/or analgesics. Both ibuprofen and acetaminophen are effective first­line
 therapy, although ibuprofen is more effective when given as monotherapy. Ketorolac is an effective parenteral NSAID, although it should not be used if the patient has taken an oral NSAID within  hours. Although superior to placebo, ketorolac appears to be less effective than prochlorperazine (see
 below). Do not use narcotics for primary headaches. Long­term use of narcotics can change the pain­modulatory system in the brainstem and
,68 can lead to more intense pain.
The most widely studied migraine­specific abortive medications are the triptans and the dopamine antagonists. Triptans have demonstrated some efficacy in the outpatient and home setting and are considered first­line therapy in that setting; however, they are more effective when taken early in
,70 the course of headache and therefore of less utility in the ED setting. If used, intranasal and subcutaneous routes are more effective than oral
,65,69 administration.
SECOND­LINE THERAPY
Many children with primary headaches presenting to the ED have already tried and failed first­line therapy, and a significant proportion of those with migraine present with status migrainosus.
Dopamine antagonists are the most studied parenteral abortive medications for migraine in the ED and include prochlorperazine, metoclopramide, promethazine, and chlorpromazine. Small studies suggest differential effectiveness among this class, with highest treatment success for
,64,71,72 prochlorperazine, followed by metoclopramide; promethazine and chlorpromazine appear to be less effective. One large study using
 administrative data suggested higher rates of ED return visits among children treated with metoclopramide compared to prochlorperazine. These
,74 drugs can cause dystonic or extrapyramidal reactions, which are relieved or prevented by diphenhydramine.
Many emergency medicine providers use a “cocktail” of medications for migraine treatment that includes ketorolac, prochlorperazine or
 metoclopramide, and diphenhydramine. This combination is effective and safe. The authors recommend this approach for patients who have failed first­line therapy, and Table 139­7 summarizes combination therapy for migraine (cluster headache may be treated the same way) and tension­type headache.
TABLE 139­7
Suggested ED Treatment Algorithm for Primary Headaches* Migraine and Cluster Headache Tension Headache
Normal saline bolus (20 mL/kg IV; max of  L) Ketorolac (0.5 milligram/kg IV; max  milligrams)†
+
+
Ketorolac (0.5 milligram/kg IV; max  milligrams)† Acetaminophen PO (15 milligrams/kg; max 1000
+ milligrams)
Prochlorperazine (0.15 milligram/kg IV; max  milligrams) or
Metoclopramide (0.1 milligram/kg IV; max  milligrams)
+
‡
Diphenhydramine (1 milligram/kg IV; max  milligrams)
↓
If no significant relief, consider neurology consultation prior to other therapies such as dexamethasone
*For patients who have failed first­line therapy with oral ibuprofen or acetaminophen.
†Do not give ketorolac if ibuprofen taken within  h.
‡
Diphenhydramine may be given prophylactically as part of a “cocktail” or used only to treat extrapyramidal side effects of dopamine antagonists.
THIRD­LINE THERAPY

Subanesthetic dose propofol has been evaluated in the ED in a randomized controlled trial in children with encouraging results. This study found that propofol, given as a .25 milligram/kg IV push every  minutes to a maximum of five doses, achieved similar pain reduction as standard therapy with dopamine antagonists and NSAIDs, with significantly fewer 24­hour rebound headaches and a nonsignificant shorter median length of stay.
However, depending on institutional policies for propofol administration, monitoring or personnel requirements may make its use provider intensive in some settings, limiting its practicality.

Dihydroergotamine is effective in the inpatient setting, but no studies exist on ED treatment. Although effective in adults, data are lacking with regard
77­80 to the utility of dexamethasone for prevention of headache recurrence following abortive therapy. Antipsychotics such as droperidol and
 haloperidol are not recommended for children due to high rates of side effects.
Additional therapies specific to cluster headache include 100% oxygen via non­rebreather mask for  minutes at onset of headache; lidocaine  milligrams intranasal to the ipsilateral nostril, and prednisone  to  milligrams/kg for  days with a subsequent 7­day taper to terminate prolonged clustering of headaches.
PROPHYLACTIC TREATMENT
Children with chronic headaches that disrupt activities of daily living or school performance may benefit from prophylactic treatment. While initiation of daily prophylaxis is typically beyond the scope of ED management, Table 139­8 lists medications used for the prevention of migraines. Few of these medications are supported by quality evidence, and a recent multicenter randomized, double­blind, placebo­controlled trial comparing topiramate,
 amitriptyline, and placebo found no difference in headache frequency and higher rates of side effects in the medication arms. The decision to start prophylaxis should be made by the primary care physician or pediatric neurologist, in consultation with the child and the family, and should include a careful weighing of the risks and benefits of daily medication.
TABLE 139­8
Commonly Used Medications for Migraine Prophylaxis in Children
Class Medication Dosage
Calcium Flunarizine  milligrams/d channel blocker
Nimodipine  milligrams/d (<40 kg),  milligrams/d (40–50 kg),  milligrams/d (>50 kg)
β­Blocker Propranolol  milligrams PO twice a day up to  milligrams  times a day as tolerated for age <14 y;  milligrams twice a day to 120 milligrams twice a day as tolerated for age >14 y
Nitrogen Papaverine  milligrams/kg/d in divided doses twice a day alkaloid
Tricyclic Amitriptyline  milligrams PO at bedtime to maximum of  milligrams PO at bedtime for age <12 y and 100 milligrams PO at antidepressant bedtime for age >12 y
Antiepileptic Topiramate  milligrams/d titrated to 200 milligrams/d in divided doses  times a day
Divalproex 125–250 milligrams PO at bedtime to twice a day for age >10 y sodium
Nutraceuticals Riboflavin (B ) 400 milligrams/d

100–150 milligrams/d
Coenzyme Q10
6–12 milligrams before bed
Melatonin
Antihistamine Cyproheptadine  milligrams PO at bedtime to maximum of  milligrams at bedtime for age >6 y
NONPHARMACOLOGIC TREATMENT
For tension­type headaches and migraines, a range of nonpharmacologic therapy including biofeedback, relaxation techniques, and cognitive
,83 behavioral therapy can be effective. In general,  to  sessions are necessary to teach these techniques in the outpatient setting. Although acupuncture has been used to treat chronic migraine headaches in both children and adults, several randomized controlled studies failed to show benefit over placebo.
DISPOSITION AND FOLLOW­UP
Admit children with emergent, life­threatening causes of headache to the hospital for definitive treatment and pain control. Consider admission for children with primary headaches with intractable pain despite first­ and second­line treatment.
Patients with recurrent headaches who are successfully treated and discharged from the ED should be encouraged to keep a daily headache diary to document the frequency of headaches, impact on daily activities, and potential triggers. Healthy lifestyle changes may help reduce headache frequency
 and can be recalled using the SMART acronym: adequate sleep, regular meals and activity, relaxation techniques, and trigger avoidance. Remind them that first­line treatments are most effective when taken early in the course of headache. For those with frequent headaches, a trial of daily nutraceuticals (Table 139­8) may be reasonable and safe. Ensure follow­up with a primary care provider or headache specialist.


