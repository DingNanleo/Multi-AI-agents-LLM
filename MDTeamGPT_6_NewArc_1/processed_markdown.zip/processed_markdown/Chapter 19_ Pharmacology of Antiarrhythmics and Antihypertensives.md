University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 19: Pharmacology of Antiarrhythmics and Antihypertensives
Sara H. Shields; Rachel M. Holland; Benjamin Small
INTRODUCTION
This chapter reviews common antiarrhythmic and antihypertensive medications administered in the ED. Acute medical conditions presenting with systemic hypertension and the specific recommended antihypertensive agents are presented in Chapter , “Systemic Hypertension.” Antiarrhythmic medications treat cardiac rhythm abnormalities by modifying autonomic function or myocardial ion channels, leading to changes in conduction
 2­ velocity or duration of the effective refractory period. Long­term use of these agents to prevent arrhythmias has not been proven to reduce mortality

; however, this chapter focuses on medications used for acute pharmacologic conversion or rate control of common arrhythmias. In general, electrical cardioversion is preferable to pharmacologic conversion in patients who are hemodynamically unstable. The majority of antiarrhythmics are organized based on the Vaughan­Williams classification system (classes I to IV) (Table 19­1). This chapter also discusses the emergency applications of atropine, adenosine, magnesium, and isoproterenol.
TABLE 19­1
Vaughan­Williams Classification of Antiarrhythmic Medications
Action Class Selected Example Medications
Sodium channel blockers Class Ia Procainamide
Class Ib Lidocaine
Class Ic Flecainide, propafenone
β­Blockers Class II Esmolol, labetalol, metoprolol, propranolol
Potassium channel blockers Class III Amiodarone, dronedarone , dofetilide, ibutilide, sotalol*, vernakalant†
Calcium channel blockers Class IV Diltiazem, verapamil, nicardipine
*Also a β­blocker.
†Not available in the United States; available in Canada and Europe.
CLASS I ANTIARRHYTHMICS: FAST SODIUM CHANNEL BLOCKERS
Class I agents block fast sodium channels and are further categorized based on their degree of blockade into classes Ia (moderate blockade), Ib (weak blockade), and Ic (strong blockade). They increase the excitability threshold, requiring more sodium channels to open in order to overcome the potassium current and generate an action potential. This effect increases the refractory period and can be useful in terminating reentry currents. In addition, some class I agents block potassium channels and exhibit antimuscarinic effects.
PROCAINAMIDE

Chapter 19: Pharmacology of Antiarrhythmics and Antihypertensives, Sara H. Shields; Rachel M. Holland; Benjamin Small 
Actions
. Terms of Use * Privacy Policy * Notice * Accessibility
Procainamide increases the refractory period, decreases automaticity and conduction, and prolongs cardiac action potentials through intermediate blockade of open sodium and potassium channels. N­Acetylprocainamide, the active metabolite of procainamide, lacks sodium channel effects but does block potassium channels, which can lead to QT prolongation.
Pharmacokinetics

See Table 19­2. TABLE 19­2
Procainamide Pharmacokinetics (Adults)
Onset/Duration of
Distribution Metabolism Excretion Half­Life
Action
 L/kg Hepatic and renal Urine, Procainamide: .5–4.7 h NAPA: 6–8 h (prolonged with Onset (IV): immediate
Active metabolite: NAPA (renal feces renal impairment) Duration: 3–6 h elimination)
Abbreviation: NAPA = N­acetylprocainamide.
Indications
Procainamide is indicated for life­threatening ventricular arrhythmias and supraventricular arrhythmias. Although it can be used to treat supraventricular tachycardia, the proarrhythmic nature of this agent (including torsades de pointes) and the risk of toxicity make procainamide less desirable for this indication. For hemodynamically stable ventricular tachycardias, procainamide, at a dose of  milligrams/kg, was shown in the
PROCAMIO trial to be more effective than amiodarone,  milligrams/kg, for conversion to sinus rhythm (68% vs. 48%) with fewer adverse events (24%
 ,9 vs. 48%). Procainamide should be avoided in patients with prolonged QT intervals or symptomatic congestive heart failure (CHF). Procainamide is
 reported as an effective agent for rhythm control in atrial fibrillation of onset <48 hours. The dose is not standardized, but one method is administering  gram of procainamide in 250 mL of 5% dextrose in water over  to 120 minutes with continuous cardiac and blood pressure monitoring. Stop the infusion for blood pressure <100 mm Hg or heart rate <60 beats/min or rate conversion.
Dosing and Administration

See Table 19­3. TABLE 19­3
Procainamide IV Dosing and Administration (Adults) for Regular Wide­Complex Tachycardia* Initial: 20–50† milligrams/min OR 100 milligrams every  min until arrhythmia is suppressed, hypotension occurs, or the QRS complex is prolonged by
50% from its original duration (maximum dose:  milligrams/kg)
Maintenance infusion rate: 1–4 milligrams/min
*Not recommended in patients with pulseless ventricular arrhythmias due to prolonged administration rate and unclear efficacy.
†Slower administration preferred if patient is stable.
Adverse Effects
The most common adverse effects associated with procainamide are hypotension, cardiac conduction abnormalities, and rash. Serious adverse effects include prolonged QT interval, torsades de pointes, ventricular fibrillation, paradoxical increase in ventricular rate in atrial fibrillation/flutter, hepatotoxicity, and CHF.
LIDOCAINE
Actions
Lidocaine is a class Ib agent with weak sodium channel–blocker properties that preferentially acts on ischemic myocardial tissue to decrease conduction; in addition, it has local anesthetic properties. Effects exerted on the cardiac action potential are negligible, with very minimal decrease to no effect on the QT interval and the refractory period.
Pharmacokinetics

See Table 19­4. TABLE 19­4
Lidocaine Pharmacokinetics (Adults)
Onset/Duration of
Distribution Metabolism Excretion Half­Life
Action
.9–2.1 L/kg Hepatic Urine Initial: 7–30 min Onset: 45–90 s
Active Terminal: .5–2 h (prolonged in congestive heart failure, liver disease, and Duration: 10–20 min metabolites severe renal impairment)
Indications
Lidocaine is indicated in the acute management of ventricular arrhythmias. Consider lidocaine for patients with pulseless ventricular tachycardia or ventricular fibrillation as an alternative agent to amiodarone in patients unresponsive to CPR, defibrillation, and vasopressors. Also, consider lidocaine maintenance in the event of return of spontaneous circulation after lidocaine is used in the treatment of pulseless ventricular tachycardia/ventricular
 fibrillation.
Dosing and Administration

See Table 19­5. TABLE 19­5
Lidocaine IV Dosing and Administration (Adults)
Ventricular Arrhythmia Ventricular Fibrillation
Loading dose: 50–100 milligrams over 2–3 min. May repeat in  min (up to Initial dose: 1–1.5 milligrams/kg
300 milligrams in any 1­h period) If refractory VF/pulseless VT, repeat .5–0.75 milligram/kg every 5–10 min
Maintenance: 1–4 milligrams/min (start low in patients with liver (maximum total dose:  milligrams/kg) dysfunction or CHF)
Abbreviations: CHF = congestive heart failure; VF = ventricular fibrillation; VT = ventricular tachycardia.
Adverse Effects
Adverse effects of lidocaine are typically dose dependent or due to rapid bolus infusion rates. Lower infusion rates reduce adverse hemodynamic effects. Patients should be monitored for CNS effects, including numbness, speech impairment, somnolence, dizziness, and seizures.
PROPAFENONE AND FLECAINIDE
Class Ic agents, propafenone and flecainide, evoke strong blockade of fast sodium channels. They are most commonly used for supraventricular tachycardia because they slow conduction and frequently restore sinus rhythm. Propafenone has additional β­adrenergic–blocking properties; therefore, it can cause bradycardia and bronchospasm. It is more selective for cells with high rates of conduction. Flecainide reduces excitability primarily in the His­Purkinje system and ventricular myocardium. Both agents are indicated for the conversion of recent­onset atrial fibrillation (<7
 days) to sinus rhythm. They also carry indications for paroxysmal supraventricular ventricular tachycardia and ventricular tachycardia but are rarely used for these indications in the ED. Propafenone is given as a one­time oral dose of 450 milligrams (weight <70 kg) or 600 milligrams (weight ≥70 kg).
Adverse effects include hypotension, bradycardia, bronchospasm, atrial flutter, and ventricular arrhythmias. Propafenone should be avoided in patients with CHF, coronary artery disease, structural heart disease, bronchospasm, or hepatic dysfunction. Flecainide is given as a one­time oral dose of 200 milligrams (weight <70 kg) or 300 milligrams (weight ≥70 kg). Adverse effects are similar to propafenone with the exception of bradycardia and bronchospasm. Flecainide should be avoided in patients with hypokalemia, atrioventricular block, coronary artery disease, significant structural heart disease, or CHF. Long­term use of these agents for arrhythmia prevention in patients with cardiovascular disease, particularly after myocardial
,12 infarction, is associated with increased mortality.
CLASS II ANTIARRHYTHMICS: β­BLOCKERS
β­Blockers have various indications, including hypertension, supraventricular ventricular tachycardia and ventricular arrhythmias, rate control in recurrent atrial fibrillation, and symptom control in thyrotoxicosis. Although these medications share the principal characteristic of blocking catecholamine effects on β­receptors, individual agents differ with respect to their cardioselectivity, α­adrenergic–blocking activity, intrinsic sympathomimetic activity, membrane­stabilizing effect, and pharmacokinetic properties (Table 19­6). β­Receptors are divided into two subtypes. β ­

Receptors are found in heart muscle, and β ­receptors are found in bronchial and vascular smooth muscle. Nonselective β­blockers target all β­
 receptors, thereby affecting heart rate, conduction, and contractility, as well as smooth muscle contraction, thus increasing the risk of bronchospasm.
In contrast, cardioselective agents have relative selectivity for β ­receptors and decrease heart rate and blood pressure. These agents may be a better
 option for patients with a history of asthma, chronic obstructive pulmonary disease, or insulin­dependent diabetes because they are less likely to act on β ­receptors. Because cardioselectivity is dose dependent, it decreases or is lost at higher doses. This is variable between agents, and the dose at
 which this occurs has not been clearly established.
TABLE 19­6
Class II Antiarrhythmics: β­Blockers (Selected)
Onset Duration
Generic Halfof of Metabolism Indications Adverse Effects
Name Life
Action Action
Noncardioselective
Propranolol Oral: Oral: Hepatic, IR: 3–6 HTN, Bradycardia, heart block, hypotension, worsening heart
1–2 h IR: 6–12 h extensive h supraventricular failure, bronchospasm
IV: ≤1 ER: 24–27 first­pass ER: 8– arrhythmias, min h elimination  h ventricular
IV: 4–6 h tachycardias
Propranolol Tachyarrhythmias: 1–3 milligrams/dose slow IVP; may repeat every 2–5 min up to a total of  milligrams dose OR .5–1 milligram IV over  min; may repeat, if necessary, up to a total maximum dose of .1 milligram/kg
OR  milligram IV over  min; may be repeated every  min up to  doses for rate control in patients with AFib
Oral: 10–30 milligrams every 6–8 h for tachyarrhythmias
Cardioselective
Esmolol IV: 2– IV: 10–30 In blood by  min HTN, SVT, AFib/AFL Hypotension, bradycardia, heart block, injection site reaction,
 min min RBC esterases (rate control) nausea, bronchospasm, pulmonary edema; abrupt discontinuation may cause rebound HTN or angina
Esmolol 500 micrograms/kg bolus (optional) over  min followed by an infusion starting at  micrograms/kg/min titrated to therapeutic effect in  dose micrograms/kg/min increments every  min to a maximum of 200 micrograms/kg/min. To achieve more rapid response, two additional 500 micrograms/kg bolus doses may be given prior to increasing the infusion rate to 100 micrograms/kg/min (after second bolus) and 150 micrograms/kg/min (after third bolus), as required. After  min at the rate of 150 micrograms/kg/min, the infusion rate may be increased to a maximum rate of 200 micrograms/kg/min (without an additional bolus dose).
Metoprolol Oral Oral: Hepatic, 3–4 h HTN, acute MI, Bradycardia, heart block, hypotension, bronchospasm
(IR): ≤1 IR: extensive angina h variable first­pass
IV:  ER: ~24 h elimination min IV: 5–8 h
Metoprolol AFib/AFL (rate control): .5–5 milligrams IV every 2–5 min (maximum total dose:  milligrams IV over 10–15 min) dose SVT: .5–5 milligrams IV bolus over  min; may repeat within a 10­min period, up to  doses
HTN: .25–5 milligrams IV every 6–12 h; titrate to response
Oral: start  milligrams immediate release twice daily; maximum 200 milligrams twice daily
Vasodilatory, Noncardioselective
Labetalol Oral: Oral: 8–12 Hepatic, Oral: HTN Orthostatic hypotension, heart failure, hyperkalemia,
 h* extensive 6–8 h hepatotoxicity, bronchospasm, nausea, dizziness, fatigue min–2 IV: 16–18 first­pass IV: h h* elimination ~5.5 h
IV: ≤5 min
Labetalol Initial: 10–20 milligrams IVP over  min; may administer additional injections using double the dose (maximum:  milligrams/dose) at 10­ dose min intervals until target SBP is reached (up to 300 milligrams total cumulative dose)
Continuous infusion: Initial: .5–2 milligrams/min; titrate to response (range: 2–10 milligrams/min)
Oral: start 100 milligrams twice daily, maximum 400 milligrams twice daily
Carvedilol 30–60 IR 14–20 h Hepatic IR 7– HTN Hypotension, bradycardia, syncope, dizziness, hyperglycemia, min  h weight gain
Carvedilol .25 milligrams orally twice daily, reduce dose if heart rate drops to <55 beats/min; if tolerated, may double dose in  wk as needed dose
Abbreviations: AFib = atrial fibrillation; AFL = atrial flutter; ER = extended release; HTN = hypertension; IR = immediate release; IVP = IV push; MI = myocardial infarction; RBC = red blood cell; SBP = systolic blood pressure; SVT = supraventricular tachycardia.
*Dose dependent.
With the exception of sotalol (discussed below), all listed β­blockers are indicated for the treatment of hypertension. These agents are also used for ventricular rate control in atrial fibrillation because they slow atrioventricular nodal conduction by decreasing sympathetic tone.
PROPRANOLOL
Actions
Propranolol, a nonselective β­blocking agent, decreases heart rate, myocardial contractility, blood pressure, and myocardial oxygen demand.

For pharmacokinetics, indications, dosing and administration, and adverse effects, see Table 19­6. ESMOLOL
Actions
Esmolol is a short­acting, selective β ­antagonist that exhibits negative inotropic and chronotropic effects. By blocking β ­receptors, esmolol prevents
  excessive adrenergic stimulation of the myocardium, thus causing an increase in sinus cycle length, prolongation of sinoatrial nodal recovery time, and a decrease in conduction through the atrioventricular node.
For pharmacokinetics, indications, dosing, administration, and adverse effects, see Table 19­6. METOPROLOL
Actions
Metoprolol is a selective antagonist of β ­receptors and exerts its antihypertensive effects by decreasing cardiac output, reducing sympathetic outflow,
 and suppressing renin activity.
For pharmacokinetics, indications, and adverse effects, see Table 19­6. For dosing and administration, see Table 19­6 and Table 19­7. TABLE 19­7
IV to Oral Conversion of Metoprolol
Medication IV to Oral Conversion
Metoprolol  milligrams IV = .5 milligrams oral
LABETALOL
Actions
Labetalol is a combined selective α ­blocking and nonselective β­blocking agent with direct vasodilatory action. The β­blocking effects of labetalol are
 greater than the α ­blocking effects, with ratios of 3:1 in the oral and 7:1 in the parenteral formulation. Labetalol is useful as an antihypertensive agent
 because it decreases heart rate, contractility, cardiac output, and total peripheral vascular resistance.
For pharmacokinetics, see Table 19­6. Indications
Labetalol is used primarily for its antihypertensive effects. It is used in patients with acute hypertensive emergencies where rapid blood pressure reduction is indicated (see Chapter , “Systemic Hypertension”) and is considered safe for use in the treatment of hypertension in pregnancy (see
Chapter , “Comorbid Disorders in Pregnancy,” and Chapter 100, “Maternal Emergencies After  Weeks of Pregnancy and in the Peripartum Period”).
Dosing and Administration
See Table 19­6 and Table 19­8. Once control of blood pressure has been established with IV labetalol, patients may transition to PO labetalol (Table

19­8).
TABLE 19­8
IV to Oral Conversion of Labetalol
Medication IV to Oral Conversion
Labetalol Upon discontinuation of IV infusion, initiate 200 milligrams orally, followed in 6–12 h with an additional dose of 200–400 milligrams.
Thereafter, dose patients with 400–2400 milligrams/d in divided doses depending on blood pressure response
Adverse Effects
See Table 19­6. CARVEDILOL
Actions
Carvedilol is a nonselective β­blocker and α­adrenergic blocker. Carvedilol reduces cardiac output, reduces exercise­induced tachycardia, reduces reflex orthostatic tachycardia, and prompts vasodilation and decreased peripheral vascular resistance, thereby reducing blood pressure. For patients
 with CHF, carvedilol lowers heart rate, increases stroke volume index, and decreases right atrial pressure.
Indications
Carvedilol is indicated for hypertension. Carvedilol is recommended for patients with compensated heart failure with reduced ejection fraction as an
 alternative or in addition to an angiotensin­converting enzyme inhibitor or an angiotensin receptor blocker, which are considered first line.

For pharmacokinetics, dosing and administration, and adverse effects, see Table 19­6. CLASS III ANTIARRHYTHMICS: INHIBIT POTASSIUM CURRENTS

Class III antiarrhythmic medications inhibit inward potassium currents (Table 19­9), leading to a significantly longer refractory period. Myocardial tissue in a refractory state is resistant to reentrant conduction circuits that may produce arrhythmia. These agents prolong the QT interval, which is associated with significant risk for torsades de pointes. Clinical indications for class III antiarrhythmics are contrasted in Table 19­10. TABLE 19­9
Pharmacology of Class III Antiarrhythmic Agents
Ion Channels and Receptors Antagonized
K+ Channels Na+ Channels Ca2+ Channels β­Adrenergic α­Adrenergic
Amiodarone + + + + +
Dronedarone + + + + +
Sotalol + +
Dofetilide +
Ibutilide +* Activates a slow inward Na+ current
Vernakalant +† +†
*Lesser effect.
†Ultrarapid and acetylcholine K+ currents.
TABLE 19­10
Class III Antiarrhythmic Indications
Clinical Indications
Supraventricular Arrhythmias Ventricular Arrhythmias
Amiodarone Acute rate control or cardioversion and maintenance of sinus rhythm* Acute management of life­threatening arrhythmias; chronic suppression
Dronedarone AFib (history of paroxysmal or persistent, but currently in sinus rhythm) to No reduce risk of hospitalization
Sotalol AFib or AFL Monomorphic VT†
Dofetilide AFib or AFL; conversion to and maintenance of sinus rhythm No
Ibutilide Acute cardioversion of AFib or AFL No
Vernakalant Acute cardioversion of AFib‡ No
Abbreviations: AFib = atrial fibrillation; AFL = atrial flutter; VT = ventricular tachycardia.
*Off­label.
†Off­label in United States, but guideline recommended with IV formulation if available.
‡
Approved in Europe but not available in United States.
AMIODARONE
Amiodarone is a “broad­spectrum” antiarrhythmic indicated in the acute management and chronic suppression of supraventricular ventricular tachycardia and ventricular arrhythmias. Potential benefits of amiodarone must be weighed against an array of potentially serious adverse effects, and clinical use is further complicated by distinctive pharmacokinetics and significant drug interactions.
Actions
,14
Amiodarone possesses properties of all four classes of antiarrhythmics (Table 19­11).
TABLE 19­11
Electrophysiologic and Electrocardiographic Effects of Amiodarone
Effects on Cardiac
Ion Channels and Receptors Effects on the ECG
Electrophysiology
Blocks inactivated Na+ channels Prolongs the refractory period Decreases heart rate and may cause sinus
Decreases sinoatrial node function bradycardia
Noncompetitive blockade of α­ and β­adrenergic
Slows atrioventricular node conduction Prolongs: receptors
Modifies automaticity of Purkinje fibers PR interval
Blocks inward K+ channel rectifier
QRS interval* Blocks myocardial Ca+ channels
QT interval* *More common with chronic oral administration than with acute IV use.
Pharmacokinetics

See Table 19­12. Amiodarone is highly lipophilic and extensively distributed to bodily tissues. Although IV amiodarone produces a rapid
 antiarrhythmic effect, it quickly redistributes from the serum into tissue, causing a precipitous drop in serum concentration. Therefore, large oral or
IV loading doses, generally given over a week or more, are needed to fill this large tissue reservoir and achieve sustained serum concentrations. As tissue stores become saturated after long­term oral therapy, terminal­phase elimination dominates and is characterized by a long half­life and duration of action.
TABLE 19­12
Amiodarone Pharmacokinetics
Onset/Peak/Duration
Absorption Distribution Metabolism Excretion Half­Life of Action
Oral BA: 35%–65% Oral: V :  L/kg Hepatic via CYP450 Feces; urine (<1% as IV single dose: 9–36 Onset d
Slow and variable GI 3A4 and 2C8 unchanged drug) d Oral:  d–3 wk
(range: 18–148 L/kg) absorption Active metabolite Oral chronic IV: initial effects rapid
Plasma protein therapy: 40–55 d Peak binding: >96%
 wk–5 mo
Duration (variable)  wk to several mo
Abbreviations: BA = bioavailability; V = volume of distribution.
d
Indications
,11,17­19
See Table 19­13. TABLE 19­13
Acute Intravenous Amiodarone Clinical Indications
Indications Comments
Atrial fibrillation Consider the potential risks of cardioversion (thromboembolic complications)* Ventricular rate control Consider when other measures are ineffective or contraindicated†
Considered a first­line option in patients with HF†
Avoid IV amiodarone in patients with WPW syndrome who have preexcited atrial fibrillation as it is potentially harmful and can accelerate the ventricular rate†
Atrial fibrillation Not first line; considered a reasonable option for pharmacologic cardioversion†
Pharmacologic
Acceptable option in patients with structural heart disease†
Cardioversion
Slow onset; average time to cardioversion is  h
VT A first­line agent for hemodynamically stable VT* Monomorphic, sustained
VT If not associated with long QT interval (i.e., TdP)* Polymorphic, not associated with Polymorphic VT with normal QT interval may be associated with myocardial ischemia, and amiodarone may be long QT interval effective in arrhythmia suppression* Pulseless VT or VF Antiarrhythmic of choice in ACLS algorithm* Abbreviations: ACLS = advanced cardiovascular life support; HF = heart failure; TdP = torsades de pointes; VF = ventricular fibrillation; VT = ventricular tachycardia;
WPW = Wolff­Parkinson­White syndrome.
*2015 ACLS guideline recommendation.
†2014 American College of Cardiology Foundation/American Heart Association/Heart Rhythm Society atrial fibrillation management guideline recommendation.
Dosing and Administration

See Table 19­14. IV amiodarone is associated with bradycardia, hypotension, and phlebitis. Hypotension may be dose and infusion rate dependent; therefore, infusion rates should not exceed  milligrams/min, and total daily doses should not exceed .2 grams. Preparations of IV amiodarone
 should be mixed in 5% dextrose in water, as amiodarone has precipitated in compatibility studies with normal saline. Dose adjustments are not required for renal insufficiency but should be considered for severe hepatic dysfunction.
TABLE 19­14
Amiodarone IV Dosing and Administration by Indication
Indications Dosing and Administration
Cardiac Arrest (refractory to defibrillation) 300 milligrams rapid bolus (may give undiluted)
Pulseless ventricular tachycardia May give a single repeat 150 milligrams bolus if needed
Ventricular fibrillation
Ventricular tachycardia with pulses 150 milligrams in 100 mL of D5W over  min, followed by infusion at 
Stable monomorphic milligram/min for  h, then .5 milligram/min for the next  h
Polymorphic with normal QT interval If breakthrough arrhythmia occurs, may give repeat 150­milligram boluses over  min
Atrial fibrillation/atrial flutter Maximum total daily dose is .2 grams
Conversion to sinus rhythm
To control rapid ventricular rate due to accessory pathway conduction in preexcited atrial arrhythmias
Abbreviation: D5W = dextrose 5% in water.
Adverse Effects
,21
See Table 19­15. Long­term amiodarone has many common, serious, and potentially fatal adverse effects that limit widespread clinical use and require regular monitoring of liver, pulmonary, thyroid, and ocular function. Although amiodarone prolongs the QT interval, it has a relatively low
 incidence of torsades de pointes even in patients with structural heart disease.
TABLE 19­15
Amiodarone Adverse Effects* Cardiovascular Sinus bradycardia (5% with oral)
Ventricular arrhythmias
Torsades de pointes (<1%)
Increased risk with:
Concomitant QT ­prolonging agent c
Hypokalemia, hypomagnesemia
Female gender
Thrombophlebitis (consider in­line IV filter if given via peripheral IV)
Atrioventricular nodal block
Hypotension (16% with IV); may be related to infusion rate or the IV solution emulsifier polysorbate 
CNS Paresthesias and peripheral neuropathy
Dizziness
GI Nausea/vomiting, anorexia, constipation (10%–33% with oral)
Usually responds to a dose reduction or divided doses
Hepatic Increased liver enzymes (15%–50%)
Hepatic injury is typically mild and reversible, but liver failure and death have been reported
Monitor baseline LFTs and every  mo thereafter
Pulmonary Pulmonary toxicity (2%–7%, as high as 17%)
May be most serious adverse effect other than cardiac. Often reversible, but fatalities have been reported after only 8–14 d of treatment
Various manifestations
Pulmonary fibrosis, eosinophilia, interstitial pneumonia, allergic alveolitis
Monitor baseline PFTs and chest radiograph; repeat chest radiograph annually
Thyroid Hypothyroidism, more common (4%–22% in some studies)
Hyperthyroidism (3%–10%)
Hyperthyroidism may diminish antiarrhythmic effect
Monitor thyroid function at baseline and every 3–6 mo thereafter
Pregnancy Contraindicated in pregnancy
Abbreviations: LFTs = liver function tests; PFTs = pulmonary function tests.
*Incomplete listing: excludes nonacute/non–life­threatening dermatologic, ocular, and other effects.
Amiodarone is responsible for many clinically significant drug interactions. As a strong inhibitor of hepatic enzymes, amiodarone can increase serum concentrations of many other medications. Amiodarone may also augment the effects of medications that concomitantly prolong the QT interval or c cause bradycardia. Specific dose reductions are recommended for colchicine, digoxin, warfarin, procainamide, quinidine, simvastatin, and lovastatin when used concomitantly with amiodarone. Given the extremely long half­life of amiodarone, drug interactions may persist for months after discontinuation of therapy.
DRONEDARONE
Actions
Dronedarone is a noniodinated, less lipophilic derivative of amiodarone, designed to have fewer adverse effects. It is categorized as a class III antiarrhythmic, but has all four antiarrhythmic class effects and also blocks α­adrenergic receptors. Electrophysiologic action is primarily mediated
 through class III antiarrhythmic effects by prolonging the refractory period.
Pharmacokinetics
See Table 19­16. TABLE 19­16
Dronedarone Pharmacokinetics
Absorption Distribution Metabolism Excretion Half­Life
Bioavailability V : ~1400 L Hepatic via CYP450 3A4 Primarily as metabolites 13–19 h d
Fasting: 4% Active metabolite Feces: 84%
Plasma protein binding: >98%
High­fat Urine: ~6% meal: 15%
Abbreviation: V = volume of distribution.
d
Indications
Dronedarone is indicated to reduce the risk of hospitalization for atrial fibrillation in patients in sinus rhythm with a history of paroxysmal or persistent atrial fibrillation.
Dosing and Administration
The dose of dronedarone is 400 milligrams orally twice daily, and it should be administered with food to increase bioavailability. Coadministration with grapefruit or grapefruit juice is contraindicated, as this may increase serum concentrations.
Contraindications and Adverse Effects
See Table 19­17. Compared to amiodarone, dronedarone has lower rates of pulmonary toxicity and has not demonstrated adverse effects on thyroid function. Two clinical trials with dronedarone were prematurely discontinued due to significantly higher rates of serious adverse events in the dronedarone treatment groups, prompting black box warnings that dronedarone is contraindicated in severe or decompensated heart failure and in
,23 patients with permanent atrial fibrillation. It is also contraindicated in pregnancy. ECGs should be monitored every  months while on dronedarone.
If the patient is found to be in atrial fibrillation, he or she should be cardioverted (if clinically indicated) or dronedarone should be discontinued. Liver function should also be monitored periodically, especially during the first  months of therapy.
TABLE 19­17
Contraindications and Significant Adverse Effects of Dronedarone
Contraindications Patients with NYHA class IV HF or NYHA class II–III HF with recent decompensation requiring referral to a specialized HF clinic
Permanent AFib (in patients in whom sinus rhythm will not or cannot be restored)
Severe hepatic impairment or previous liver or lung toxicity with amiodarone
Bradycardia <50 beats/min, QT ≥500 ms or PR interval >280 ms, second­degree or third­degree AV block or sick sinus syndrome c
(except when used with a pacemaker)
Drug–drug interactions with strong CYP450 inhibitors and QT ­prolonging medications c
Pregnancy
Significant adverse Cardiovascular effects New­onset or worsening HF; QT prolongation c
Hepatic
Severe liver injury, including acute liver failure
Renal
Upon initiation, serum creatinine may increase ~0.1 milligram/dL
Respiratory
Interstitial lung disease; pulmonary fibrosis and pneumonitis
Abbreviations: AFib = atrial fibrillation; AV = atrioventricular; HF = heart failure; ms = milliseconds; NYHA = New York Heart Association.
SOTALOL
Actions
Sotalol is a noncardioselective β­blocker that exhibits electrophysiologic characteristics of class III antiarrhythmics, thus prolonging repolarization and refractoriness without affecting conduction.
Pharmacokinetics
The onset of action of sotalol is  to  hours for the oral formulation and  to  minutes after IV administration. The elimination half­life is  hours and increases with renal dysfunction. Sotalol is eliminated unchanged in the urine.
Indications
Sotalol is an effective agent for the suppression of life­threatening ventricular arrhythmias refractory to other antiarrhythmic drugs. It can suppress
 supraventricular ventricular tachycardia and atrial fibrillation, but is not indicated for cardioversion of atrial fibrillation.
Dosing and Administration
The recommended dose of IV sotalol for hemodynamically stable monomorphic ventricular tachycardia is .5 milligrams/kg infused over  minutes.
The usual oral starting dose is  milligrams twice daily, titrated to a typical maintenance dose of 160 to 320 milligrams per day. Patients with renal insufficiency (creatinine clearance of  to  mL/min) require a dose frequency reduction of 50%, and sotalol should not be used (except in special cases) if creatinine clearance is <40 mL/min. During initiation of sotalol therapy, pretreatment QT should be <450 milliseconds, QT intervals should c c be monitored after each dosage administration, and therapy should be discontinued or the dosage reduced if QT measures ≥500 milliseconds.
c
Hypokalemia and hypomagnesemia should be corrected prior to initiation to minimize the risk of torsades de pointes.
Adverse Effects
The most common adverse effects of sotalol are bradycardia and hypotension. Sotalol does possess a significant proarrhythmic effect with a .3% rate
 of new or worsened ventricular arrhythmias and a .4% rate of torsades de pointes.
DOFETILIDE
Actions and Indications
Dofetilide is a pure class III antiarrhythmic and is indicated for the conversion to, and maintenance of, normal sinus rhythm in patients with atrial fibrillation or atrial flutter. Because dofetilide has a significant proarrhythmic effect, it is reserved for patients in whom atrial fibrillation or atrial flutter
 is highly symptomatic and alternative safer agents are contraindicated or otherwise not desired. Hospitalization is required for  days upon initiation of therapy to allow for monitoring of QT interval, continuous ECG, and creatinine clearance. The U.S. Food and Drug Administration announced the c
 elimination of the Risk Evaluation and Mitigation Strategy for dofetilide (Tikosyn®) on March , 2016. Adverse Effects
Serious adverse effects of dofetilide are ventricular tachycardia and QT interval prolongation, which can result in torsades de pointes.
c
Drug Interactions
Dofetilide therapy is contraindicated with concomitant verapamil, hydrochlorothiazide, cimetidine, ketoconazole, trimethoprim, prochlorperazine, megestrol, and dolutegravir because these medications may cause an increase in dofetilide plasma concentration.
IBUTILIDE
Actions and Pharmacokinetics
Ibutilide prolongs the refractory period in atrial and ventricular cardiac tissues. This action is caused by activation of a slow inward sodium current.
Blockade of the delayed rectifier potassium current, which slows repolarization, may also contribute to its clinical effects. The onset of action of ibutilide is ≤90 minutes after starting the infusion. Ibutilide is metabolized in the liver, is excreted in the urine and feces, and has a half­life of approximately  hours after IV administration.
Indications, Dosing and Administration, and Adverse Effects

Ibutilide is indicated for the rapid conversion of recent­onset atrial fibrillation or atrial flutter to sinus rhythm. If effective, cardioversion is expected to occur within  hour of administration. Ibutilide is also recommended to restore sinus rhythm or slow ventricular rate for patients with preexcited
 atrial fibrillation and rapid ventricular rate who are not hemodynamically compromised. For patients with atrial fibrillation and an accessory
 pathway, ibutilide is considered a reasonable option for pharmacologic cardioversion. A 2018 ED trial reported a .5% conversion rate for atrial fibrillation and a 75% conversion rate for atrial flutter.  The loading dose is  milligram IV (weight ≥60 kg) or .01 milligram/kg IV (weight <60 kg) over
 minutes and may be repeated once every  minutes after completion of the first dose. ECG monitoring is continued for at least  hours or until the
QT interval returns to baseline. Cardiovascular adverse effects of ibutilide include hypotension, hypertension, bradycardia, sinus arrest, syncope, QT c c interval prolongation, CHF, and torsades de pointes. Hypokalemia and hypomagnesemia should be corrected prior to initiation to minimize the risk of torsades de pointes.
VERNAKALANT
Vernakalant is a class III antiarrhythmic that inhibits sodium and potassium currents. The atria are more susceptible to vernakalant­induced refractory
 period prolongation. Vernakalant is not U.S. Food and Drug Administration approved for use in the United States due to concerns over safety. In
Europe and Canada, vernakalant is indicated for rapid conversion of recent­onset atrial fibrillation in adults at a dose of  milligrams/kg over 
  minutes. Compared to other agents, vernakalant has the shortest median time to conversion (8 to  minutes).
CLASS IV ANTIARRHYTHMICS: CALCIUM CHANNEL BLOCKERS
Calcium channel blockers inhibit L­type calcium channels, resulting in slowing of atrioventricular nodal conduction and an increase in the refractory period of nodal tissue. In the myocardium, calcium channels primarily affect the action potential plateau and modulate the strength of muscle contraction. Calcium channel blockers are divided into two categories, dihydropyridine and nondihydropyridine. Nondihydropyridine calcium channel blockers have greater cardioselectivity and are generally used for paroxysmal supraventricular tachycardias and rate control in atrial fibrillation, whereas dihydropyridine calcium channel blockers are more selective for the vasculature at therapeutic doses and are used to treat hypertension.
DILTIAZEM/VERAPAMIL
Actions
Diltiazem and verapamil are nondihydropyridine calcium channel blockers that slow atrioventricular nodal conduction, increase the atrioventricular node’s refractory period, decrease automaticity, and prolong the PR interval. Verapamil is more potent than diltiazem, resulting in greater atrioventricular nodal depression.
Pharmacokinetics
See Table 19­18. Immediate­release oral diltiazem has a relatively rapid onset of action; therefore, transitioning from an IV infusion to an oral preparation can be accomplished with relative ease. In addition, IV diltiazem has a short duration of action, necessitating either a continuous infusion or repeat bolus doses.
TABLE 19­18
Diltiazem and Verapamil Pharmacokinetics
Onset/Peak/Duration
Absorption Distribution Metabolism Excretion Half­Life of Action
Diltiazem IR: ~98% V : 3–13 L/kg Hepatic via Urine (2%–4% as IR: 3–4.5 h Onset d
ER capsule: ~93% to CYP450 and unchanged drug); feces ER tablet: 6–9 h IV:  min
Plasma
>95% conjugation ER capsule: 4–9.5 h Oral, IR: 30–60 min protein
Oral BA: ~40% Active IV bolus: ~3.4 h Peak binding:
(undergoes extensive metabolites Continuous infusion: Oral, IR: 2–4 h
70%–80% first­pass metabolism) 4–5 h Oral, ER tablet: 11–18 h
Oral, ER capsule: 10–14 h
Duration
IV bolus: 1–3 h
Continuous infusion
(after discontinuation):
.5–10 h
Verapamil Oral: >90% V : .89 L/kg Hepatic via Urine (~70% as Injection (terminal): Onset/peak d
Oral BA: 20%–35% CYP450 metabolites, 3%–4% as 2–5 h IV: 3–5 min
Plasma
(undergoes extensive Active unchanged drug); feces Oral, IR: .8–7.4 h Oral, IR: 1–2 h protein first­pass metabolism) metabolites (≥16%) (single dose); .5–12 Duration binding: h (multiple doses) IV: .5–6 h
~90%
Oral, ER: ~12 h Oral, IR: 6–8 h
Abbreviations: BA = bioavailability; ER = extended release; IR = immediate release; V = volume of distribution.
d
Indications

Diltiazem and verapamil are indicated for paroxysmal supraventricular ventricular tachycardia as well as for rate control in atrial fibrillation ; however, verapamil is used more commonly to abort supraventricular ventricular tachycardia with a conversion rate to sinus rhythm similar to
  adenosine (90%), whereas diltiazem is used more commonly to control rapid ventricular rate in atrial fibrillation. Both agents are contraindicated for wide­complex tachyarrhythmias, which may be a result of Wolff­Parkinson­White syndrome due to the high risk of life­threatening ventricular arrhythmia when given to these patients. Other contraindications include sick sinus syndrome, second­ or third­degree AV block, severe hypotension, cardiogenic shock, administration concomitantly or within a few hours of IV β­blockers, and ventricular tachycardia.
Diltiazem Dosing and Administration
When initiating diltiazem, an IV bolus of .25 milligram/kg over  minutes is administered, and a continuous infusion is started at  to  milligrams/h
(if bolus is effective). A repeat bolus of .35 milligram/kg over  minutes may be given if there is inadequate response to initial bolus. The continuous infusion may be increased in increments of  milligrams/h until rate control is achieved to a maximum rate of  milligrams/h. Once rate control is achieved, patients may be transitioned to oral diltiazem (Table 19­19).
TABLE 19­19
Conversion From IV to Oral Diltiazem
Medication IV to Oral Conversion
Diltiazem After continuous infusion at typical rate of 5–15 milligrams/h has heart rate controlled, may convert to oral.
Oral dose (milligrams daily) is approximately equal to [rate (milligrams/h) ×  + 3] × . Discontinue infusion 2–3 h after oral dose is given.
Diltiazem Infusion Rate Equivalent Oral Dose (Immediate Release)
 milligrams/h 120 milligrams daily
 milligrams/h 180 milligrams daily
 milligrams/h 240 milligrams daily
 milligrams/h 360 milligrams daily
Immediate­release formulations should be used when initially starting a patient on oral diltiazem. Once stable on immediate­release diltiazem, patients can be transitioned to an extended­release formulation by giving an equivalent daily dose.
Verapamil Dosing and Administration
For acute treatment of supraventricular ventricular tachycardia and atrial fibrillation (rate control), administer  to  milligrams (0.075 to .15 milligram/kg) IV over  minutes. If no response, a second dose of  milligrams (0.15 milligram/kg) may be given  to  minutes after the initial dose.

If the patient responds to the initial or repeat bolus dose, a continuous infusion may be initiated.
Adverse Effects
Diltiazem is generally well tolerated by patients and has a favorable safety profile when compared to other antiarrhythmic agents. Adverse effects associated with diltiazem and verapamil administration are bradyarrhythmia, asystole, fatigue, headache, hypotension, atrioventricular block, peripheral edema, syncope, and dizziness.
NICARDIPINE
Actions
Nicardipine is a dihydropyridine calcium channel blocker that causes relaxation of smooth muscle, thereby lowering blood pressure. It has no antiarrhythmic properties and little to no effect on the myocardium at therapeutic doses.
Pharmacokinetics

See Table 19­20. TABLE 19­20
Nicardipine Pharmacokinetics (IV)
Distribution Metabolism Excretion Half­Life Onset/Peak/Duration of Action
V : .3 L/kg Hepatic via CYP450 3A4, Urine (49% as Follows dose­dependent Continuous infusion d
2C8, 2D6; extensive metabolites, <1% as (nonlinear) pharmacokinetics; Onset: within minutes
Plasma first­pass effect unchanged drug); half­life dependent on serum Peak: 50% of maximum effect seen by  min protein
(saturable) feces (43%) concentrations Duration: upon discontinuation, 50% binding:
After IV infusion, serum decrease in effect seen in ~30 min with gradual
>95% concentrations decrease tri­ discontinuing antihypertensive effects for ~50 exponentially h
α half­life:  min
β half­life:  min
Terminal half­life:  h (seen only after long­term infusions)
Abbreviation: V = volume of distribution.
d
Indications
Nicardipine is primarily used for the treatment of hypertension and is contraindicated in patients with aortic stenosis. It is especially useful in patients with acute neurologic emergencies where progressive rapid blood pressure reduction over  to  minutes is indicated.
Dosing and Administration
Nicardipine is administered as an IV infusion with an initial rate of  milligrams/h. The infusion may be titrated in increments of .5 milligrams/h every  to  minutes based on blood pressure response, with a maximum infusion rate of  milligrams/h.
Adverse Effect Profile
Nicardipine is generally well tolerated by patients. Common side effects include hypotension/orthostatic hypotension, edema, flushing, tachycardia, palpitations, and nausea.
CLEVIDIPINE
Actions
Clevidipine is a fourth­generation dihydropyridine calcium channel blocker with potent vasodilating activity that reduces blood pressure by decreasing systemic vascular resistance.
Pharmacokinetics
The onset of action after initiating a clevidipine infusion is  to  minutes, and the duration of action is  to  minutes. Clevidipine undergoes rapid metabolism via hydrolysis by esterases in the blood and has a half­life of  minute. Clevidipine is delivered in a lipid emulsion.
Indications
Clevidipine is indicated for the management of acute hypertension when oral therapy is not deemed desirable. It has been studied in the ED and found to be safe and effective in reducing blood pressure in the treatment of various hypertensive emergencies, stroke, heart failure, and aortic dissection
(adjunct to esmolol).
Dosing and Administration
Clevidipine should be initiated as an IV infusion, starting at  to  milligrams/h; the dose may be doubled at 2­minute intervals. The usual dose is  to  milligrams/h, with a maximum infusion rate of  milligrams/h. When the treatment goal is near, slow the rate of rise in stepped increases in therapy to stabilize blood pressure and avoid unwanted hypotension.
Adverse Effects
Adverse effects of clevidipine include atrial fibrillation, nausea, vomiting, hypotension, and elevation in serum creatinine.
OTHER ANTIARRHYTHMIC MEDICATIONS
ATROPINE
Actions

Atropine blocks the effects of acetylcholine at parasympathetic sites in smooth muscle thus increasing cardiac output.
Pharmacokinetics
See Table 19­21. TABLE 19­21
Atropine Drug Information
Onset of
Metabolism Half­Life IV Dose (Adult) Indications
Action
IM: ≤15–30 min Hepatic Adults: .1– .5 milligram every 3–5 min (maximum total dose:  milligrams or .04 Symptomatic sinus
IV: immediate .9 h milligram/kg) bradycardia
Indications
Atropine is considered first­line therapy for the treatment of symptomatic bradycardia. Atropine is no longer recommended for the treatment of
 asystole or pulseless electrical activity. Atropine may precipitate or worsen myocardial ischemia in patients with coronary artery disease, acute
 coronary syndrome, CHF, tachycardia, and hypertension.
Dosing and Administration
,8
See Table 19­21. IV doses <0.5 milligram and slow injection have been associated with paradoxical bradycardia.
Adverse Effects
The most common adverse effects of atropine include tachyarrhythmia, constipation, xerostomia, blurred vision, and photophobia.
ADENOSINE
Actions
Adenosine, an endogenous nucleoside, slows conduction time through the atrioventricular node, interrupts reentry pathways through the
 atrioventricular node, and restores normal sinus rhythm for patients in supraventricular tachycardia.
Pharmacokinetics

See Table 19­22. TABLE 19­22
Adenosine Pharmacokinetics
Metabolism Half­Life Onset/Duration of Action
Systemic <10 s Onset: rapid
Active metabolites Duration: very brief
Indications
Adenosine is used for the treatment of paroxysmal supraventricular ventricular tachycardia with or without reentry pathways, after failure of vagal
,30 maneuvers. It is ineffective for conversion of atrial fibrillation, atrial flutter, or ventricular tachycardia.
Dosing and Administration

See Table 19­23. TABLE 19­23
Adenosine Dosing and Administration
Indication Dosing and Administration
Paroxysmal supraventricular tachycardia Initial dose:  milligrams IV
If ineffective after 1–2 min, may give second dose of  milligrams IV
May repeat  milligrams IV if needed
Note. Rapid IV push over 1–2 seconds via peripheral line. Flush line after each dose with  mL of normal saline. Patients usually experience transient asystole (<5 seconds). Initial dose should be reduced to  milligrams in heart transplant patients, in patients taking dipyridamole or carbamazepine, and when administered via central line. Patients taking caffeine or theophylline may require larger doses.
Adverse Effects
Common adverse effects include chest discomfort/pressure, headache, flushing, and nausea and are usually temporary due to the short half­life of the drug. Bronchospasm and atrial fibrillation can also occur, but the incidence is rare. Severe adverse effects, including cardiac conduction abnormalities and hypotension, are more common with continuous infusion adenosine used in stress testing.
MAGNESIUM SULFATE
Actions, Indications, and Dosing and Administration
The antiarrhythmic activity of IV magnesium sulfate is mediated by inhibiting calcium currents that cause pathologic early afterdepolarizations and thereby cardiac dyssynchrony. Magnesium slows sinoatrial node activity, prolongs myocardial conduction time, stabilizes excitable membranes, and is
 a cofactor in ion movement. IV magnesium sulfate has a rapid onset of action and is indicated in the treatment of torsades de pointes, polymorphic ventricular tachycardia associated with a prolonged QT interval, and cardiac arrest when ventricular fibrillation/pulseless ventricular tachycardia is associated with torsades de pointes. In patients with a pulse,  to  grams IV are diluted in normal saline or 5% dextrose in water and administered as a rapid bolus. Rapid IV administration is associated with vasodilation, flushing, and hypotension.
ISOPROTERENOL
Actions, Pharmacokinetics, and Indications
Isoproterenol exerts antiarrhythmic effects by stimulating β ­ and β ­receptors. The β ­receptor interaction results in increased chronotropic and
   inotropic activities in the myocardium and vasodilation by β ­receptor–mediated relaxation of smooth muscle. IV isoproterenol has an immediate
 onset of action, a half­life of .5 to  minutes, and a duration of  to  minutes. It is indicated for refractory bradyarrhythmias, atrioventricular nodal block, and refractory torsades de pointes; however, it is rarely used in the ED. Isoproterenol is contraindicated in patients with angina, preexisting
 ventricular arrhythmias, tachyarrhythmias, or digoxin toxicity.
Dosing and Administration
A continuous IV infusion should be initiated at  micrograms/min and titrated every  to  minutes based on patient response (usual range,  to  micrograms/min).
Adverse Effects
Serious adverse effects of isoproterenol include hypotension, premature ventricular contractions, tachyarrhythmia, ventricular arrhythmia, dyspnea, and pulmonary edema.
DIGOXIN
Actions
Digoxin, a cardiac glycoside, has positive inotropic, negative chronotropic, and negative dromotropic effects on the myocardium due to inhibition of the sodium­potassium ATPase. It also causes direct suppression of the atrioventricular node, leading to an increased refractory period and decreased
 conduction velocity.
Pharmacokinetics

See Table 19­24. Many disease states such as CHF, hypokalemia, renal failure, and thyroid disease can have a substantial effect on the pharmacokinetics of digoxin. It has a narrow therapeutic index (therapeutic range, .5 to  nanograms/mL), and toxicity can develop at levels >2 nanograms/mL. In addition, digoxin has numerous drug interactions that can be clinically significant.
TABLE 19­24
Digoxin Pharmacokinetics
Onset/Peak/Duration of
Distribution Metabolism Excretion Half­Life
Action
Normal renal function: GI tract Urine (50%–70% as Age, renal, and cardiac function dependent Onset
6–7 L/kg Hepatic unchanged drug) Parent drug:  h Oral: 1–2 h
Plasma protein binding: Active Metabolites: digoxigenin (4 h); IV: 5–60 min
~25% metabolites monodigitoxoside (3–12 h) Peak
Oral: 2–8 h
IV: 1–6 h
Duration: 3–4 d
Indications

Digoxin is indicated for rate control in atrial fibrillation (not first line) and for symptom reduction in CHF unrelieved by diuretics and angiotensinconverting enzyme inhibitors. Although digoxin is only contraindicated in patients with ventricular arrhythmias, its use should be avoided in patients with Wolff­Parkinson­White syndrome (increased risk of ventricular fibrillation), acute myocardial infarction, untreated beriberi heart disease, electrolyte imbalances, sinus node disease, atrioventricular block, and renal impairment. Studies on mortality associated with long­term digoxin use
32­36 report conflicting results.
Dosing and Administration
There are several dosing strategies for digoxin initiation. For atrial fibrillation (rate control) in adults, current guidelines recommend .25 milligram IV
,11 with repeat dosing to a maximum of .5 milligrams over  hours, followed by an oral maintenance regimen (0.125 to .25 milligram once daily).
Dose adjustments are often necessary based on age, comorbidities, concomitant medications, and renal dysfunction. Digoxin levels should be monitored for safety and efficacy.
Adverse Effects
Adverse effects of digoxin are generally GI, including nausea, vomiting, and diarrhea. Other rarer adverse effects may include gynecomastia, skin rash, eosinophilia, and thrombocytopenia. Digoxin can also cause cardiac arrhythmias, such as sinus bradycardia, atrioventricular or sinoatrial nodal block, and ventricular arrhythmias.
Symptoms of digoxin toxicity include mental status changes, visual disturbances, delirium, hyperkalemia, and seizures. Many types of arrhythmias can occur as a result of digoxin toxicity, and clinicians must be able to recognize the signs and symptoms associated with toxicity and treat accordingly.
SELECTED ANTIHYPERTENSIVE MEDICATIONS
See earlier sections for discussion of β­blockers, nicardipine, and clevidipine. Eleven of the most commonly prescribed oral antihypertensive agents are listed in Table 19­25. TABLE 19­25
Selected Oral Antihypertensive Medications
Drug Dose* Frequency Onset Metabolism/Excretion Side Effects/Comments
Angiotensin receptor blockers
Valsartan Start  milligrams Daily, or divided  h; peak  h To inactive Hyperkalemia, renal impairment,
Max 320 milligrams/d twice daily metabolite/feces angioedema
Losartan Start  milligrams Daily  h; peak  h Hepatic/feces Hyperkalemia, renal impairment,
Max 100 milligrams/d angioedema
Angiotensin­converting enzyme inhibitors
Lisinopril Start  milligrams Daily  h; peak  h Not Angioedema, hyperkalemia, renal
Max  milligrams/d metabolized/unchanged impairment, cough in urine
Captopril Start  milligrams  times daily  min; peak Hepatic/urine Angioedema, hyperkalemia, renal
Max 450 milligrams/d  min impairment, cough
Benazepril Start  milligrams Daily, or divided  h; peak  h Hepatic/urine Angioedema, hyperkalemia, renal
Max  milligrams/d twice daily impairment, cough
Calcium channel blockers
Amlodipine Start .5 milligrams Daily  h; peak Hepatic/urine Peripheral edema, headache,
Max  milligrams 24–48 h palpitations
Nifedipine IR: Start  milligrams IR:  times daily  min; peak Hepatic/urine Hypotension, peripheral edema,
Max 120 milligrams/d ER: daily  h headache, palpitations, flushing
ER: Start  milligrams
Max 120 milligrams/d
Diuretics
Chlorthalidone Start .5 milligrams Daily  h; peak 4–6 Hepatic/urine Dizziness, headache, electrolyte
Max  milligrams/d h imbalance, hypokalemia
Hydrochlorothiazide Start .5–25 Daily  h; peak 2–6 Not Dizziness, headache, electrolyte milligrams h metabolized/unchanged imbalance, hypokalemia
Max  milligrams/d in urine
Smooth muscle relaxant, vasodilator
Hydralazine IV: 10–20 milligrams IV: every 4–6 h IV: 10–80 Hepatic/urine Tachycardia, dizziness, lupus­like
Oral: Start 10–25 Oral: divided 2–4 min syndrome at higher doses, fever milligrams per dose times daily Oral: 1–2 h
Max 300 milligrams/d
Centrally acting α ­adrenergic agonist

Clonidine IR: Start .1 milligram Twice daily 30–60 min; Hepatic/urine, 40%–60% Sedation, bradycardia, headache,
Max .4 milligrams/d peak 1–3 h unchanged dizziness, irritability
Abbreviations: ER = extended release; IR = immediate release.
*Dose is oral unless otherwise stated.
Actions of Selected Antihypertensive Classes
Lisinopril, captopril, and benazepril are angiotensin­converting enzyme inhibitors, which act by preventing the conversion of angiotensin I to
 angiotensin II (a potent vasoconstrictor), ultimately reducing aldosterone secretion and blood pressure. Valsartan and losartan are angiotensin
 receptor blockers, which reduce blood pressure by blocking the vasoconstrictor effects and aldosterone­secreting stimulus of angiotensin II.
Amlodipine and nifedipine are dihydropyridine calcium channel blockers, which lower blood pressure by relaxing vascular smooth muscle to
 produce arterial vasodilation and decreased systemic vascular resistance. Amlodipine and nifedipine have very few chronotropic effects.
Chlorthalidone, a thiazide­related diuretic, inhibits sodium and chloride reabsorption in the cortical­diluting segment of the ascending loop of Henle; hydrochlorothiazide, a thiazide diuretic, inhibits sodium reabsorption in the distal tubules, causing increased excretion of sodium and water as well as
 potassium and hydrogen ions. Clonidine stimulates α ­adrenoceptors in the brainstem, decreasing sympathetic outflow and thereby reducing

 peripheral resistance, heart rate, and blood pressure. Hydralazine is a smooth muscle relaxant that decreases tone in arterial walls, yielding
 vasodilation and a decrease in peripheral vascular resistance.
Indications
Medications from the antihypertensive classes of diuretics, angiotensin­converting enzyme inhibitors, angiotensin receptor blockers, and calcium
 channel blockers are considered preferred initial drugs for the initiation of antihypertensive therapy (Table 19­25), with a few important exceptions.
For patients with chronic kidney disease being started on an angiotensin­converting enzyme inhibitor or an angiotensin receptor blocker, there is a risk of hyperkalemia. Also, with these two drug classes, there is a risk of acute kidney injury in the setting of severe bilateral renal artery stenosis, a
 condition that affects up to .4% of the hypertensive population. Nifedipine and labetalol (discussed earlier) are preferred agents in hypertensive
 women who are pregnant or planning to become pregnant. Calcium channel blockers should be avoided in patients with a history of heart failure with reduced ejection fraction; the initial antihypertensive drug for these patients should be an angiotensin­converting enzyme inhibitor or an
 angiotensin receptor blocker. Of the diuretics, chlorthalidone is the preferred agent because of its long duration of action (40 hours) and trial­proven
 reduction of cardiovascular disease. Thiazide diuretics should be avoided in patients with a history of gout. Clonidine and hydralazine are frequently used in cases of hypertensive urgency (see Chapter , “Systemic Hypertension”). Hydralazine is not recommended as an initial drug for
   hypertension. Hydralazine is not recommended for hypertensive emergencies, except when associated with pregnancy (see Chapter 100,
“Maternal Emergencies After  Weeks of Pregnancy and in the Peripartum Period”). With abrupt discontinuation, clonidine is associated with rebound hypertension.
Most patients taking medication to control their hypertension will require at least two medications. While the dose of one medicine may be increased
,37 to its maximum recommended daily dose (Table 19­25), when lower doses do not sufficiently reduce blood pressure, two drugs of the same class should not be used simultaneously. Also, an angiotensin receptor blocker should not be combined with an angiotensin­converting enzyme inhibitor.
The most commonly prescribed two­drug antihypertensive combinations are a diuretic added to an angiotensin­converting enzyme inhibitor or an angiotensin receptor blocker. See Table 19­25 for dosing information and adverse effects.


