University of Pittsburgh
Access Provided by:

Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 6: Natural Disasters
Lisa D. Mills; Trevor J. Mills
INTRODUCTION AND EPIDEMIOLOGY
Natural disasters continue to be an unpredictable source of worldwide morbidity and mortality and present unique challenges for practitioners of emergency care. The 2005 to 2014 annual average worldwide mortality rate was 76,416 deaths per year from natural disasters, with an average of 199.2
1 million worldwide victims per year during the same time period and an economic cost of $70.3 billion in 2015. With the increase in rapidly mobilized recovery teams, emergency physicians are at the forefront of patient care after a natural disaster. It is here that we can have the greatest impact in treating survivors and minimizing secondary morbidity and mortality, often in the setting of a significantly impaired healthcare system. Research suggests that the burden of natural disasters is likely to rise in the coming years, due to increasing population density in high­risk areas and risks
2 associated with expanding technology (e.g., fires or earthquakes in larger and taller buildings or critical infrastructure).
Although the mechanics, warning period, and impact vary widely between types of natural disasters, there is a predictable pattern of events that occur and may be used to maximize the subsequent response. Natural disasters result in a combined loss of resources—infrastructure, economic, social, and health. Although this may be tempered by pre­event preparedness and infrastructure strength, this combination of resource loss has a synergistic impact on the health of and the delivery of health care to the affected population. Another commonality is the predictable pattern of pathology, seen in the progression from the impact of the event itself, through the acute aftermath, to the immediate postdisaster phase, and into the recovery phase
(Table 6­1). Perhaps most salient for emergency practitioners, relief efforts can be implemented based on data from previous disaster experience, while simultaneously being tailored to the type of disaster (e.g., hurricane, earthquake, tornado, flood, tsunami, or snow) and region affected. Finally, disaster responders should be prepared to face the duty of management of dead bodies, on a scale otherwise seen only in the setting of combat.
TABLE 6­1
Timing of Disease Presentation
Timing of
Presentation
Onset
Acute phase Trauma Stress reactions Drowning Inhalational Burns injury
Immediate Infectious Exacerbation of Acute stress Burns Inhalational postevent complications of chronic disease disorder injury phase trauma
Recovery phase Trauma Communicable Infectious Soft tissue Exacerbation of Vectorborne Posttraumatic disease complications of infections chronic disease disease stress disorder trauma
LOSS OF RESOURCES
Most natural disasters—whether by water, wind, fire, or snow—cause some disruption of power, communication, and transportation systems. In dDeovwenlolopaedde adn d2 0d2e5v­e7lo­1p i4n:g6 nPa t iYoonus,r eIPnt iisre 1 c3it6i.e1s4 c2a.n1 5b9e. 1d2es7troyed instantly, overwhelming nearby healthcare facilities and personnel. In such cases, the
Chapter 6: Natural Disasters, Lisa D. Mills; Trevor J. Mills 
3 traditional triage system may not be effective. A Centers for Disease Control and Prevention posthurricane assessment in 2012 determined that most
. Terms of Use * Privacy Policy * Notice * Accessibility
4 of the resulting public health emergencies were directly due to loss of public health infrastructure and related to clean­up and repair activities.
Because standard amenities, such as power, running water, and sanitation methods, may be unavailable for extended periods of time, all medical disaster planning must include practical, simple alternatives to technologies that are likely to fail during a disaster.
Lack of communication is a common feature of both the impact and delayed phases of a disaster. Even the most sophisticated equipment may fail due to regionwide outages or loss of electricity for charging devices. In our experience during the active phase of Hurricane Katrina, the only working means of communication within Charity Hospital was a single landline telephone. Difficulty in communication has led to recent innovation with
5 proposals for disaster­specific electronic medical records.
Evidence suggests that the predisaster level of preparedness and resources in a community has a significant impact on its response to a catastrophic event. Analysis of four earthquakes in different regions (developed and developing countries) found that regions with the least preparedness and
6 weakest preexisting medical infrastructure had the highest number of deaths per patients injured. Investment in targeted disaster preparedness efforts before an event occurs, particularly for the most vulnerable populations, is crucial in mitigating the effects of an inevitable disruption in
7 resources during a disaster.
DISEASE BURDEN
Understanding of the likely health emergencies to be encountered in the acute and postdisaster phases is crucial to any emergency response.
Although it is widely thought that outbreaks of rare and/or severe disease inevitably follow many types of natural catastrophe, evidence does not
8,9 support this belief. Common medical problems after natural disasters include traumatic injury, infectious disease, exacerbations of chronic medical conditions, and a surge in mental health issues (Table 6­2). In addition to the common medical problems previously listed, the handling of bodies has an additional unique impact on the health of the affected population.
TABLE 6­2
Common Disease Patterns
Trauma Communicable Disease Chronic Medical Conditions Infectious Disease Mental Health
Strains and sprains Respiratory infections Hypertension Soft tissue infections Stress reactions
Falls GI infections Diabetes Open fractures Depression
Lacerations Renal failure Vectorborne disease Exacerbation of chronic condition
Burns Chronic obstructive pulmonary disease Local diseases
Fractures
TRAUMA
Traumatic injuries frequently occur in the acute phase of a natural disaster, commonly from direct trauma from collapsing structures or flying debris. A second spike in trauma is seen during the recovery/clean­up phase, mainly due to unsafe infrastructure. However, this secondary spike in trauma may
10 also include violent injuries, depending on the level of civil unrest. Although most trauma is minor, management of severe injuries by healthcare professionals can prove especially challenging when resources are lacking, as they often require coordinated surgical care. This necessitates adequate resources of anesthesia, blood products, surgical equipment and the ability to sterilize it, intensive care capacity, and operating theaters. When these resources are unavailable, limb amputation, nonunion, and missed injury rates are high, and lack of safe blood
11,12 products hampers surgical capability. Recommendations for adequate surgical capability include mobile blood banks with adequate supply and well­trained staff, at least two units of blood available per operation, adequate supplies of appropriate anesthesia, strict adherence to national or
3,12,13 international quality and safety standards, and functioning critical care units.
INFECTIOUS DISEASE
Infectious diseases are commonly feared and should be anticipated after natural disasters. Although popular media often focuses on the possibility of
9,14 rare disease epidemics, most postdisaster infections are directly related to the usual pathogens of that region. One exception to this was the
15 outbreak of cholera after the 2010 earthquake in Haiti, which is believed to have been brought in by United Nations relief workers. Evidence indicates that the combination of communicable disease and population malnutrition is the major cause of morbidity and mortality in most disasters. Infectious
16 disease predominantly occurs in the extended postevent phase. Infectious disease risks are heightened by certain characteristics common to natural disasters: mass population movement and resettlement; overcrowding; poverty; sanitation and waste issues, including water contamination; absence of shelter, food, and healthcare access; and disruption of public health programs. Respiratory, GI, skin/soft tissue, and vectorborne infectious diseases are most commonly analyzed in disasters.
Respiratory illnesses range from direct aspiration of contaminated water (floods and tsunamis) to airborne droplet transmission to inhalation injuries caused by excess dust, allergens, or debris. In both the acute and postdisaster phases, reactive airway disease may be exacerbated. After one thunderstorm in 2016, nine patients died and the EMS system was overwhelmed in Melbourne, Australia, due to acute asthma exacerbations.

While infectious respiratory infections are mild, respiratory illness may account for 20% of all natural disaster deaths in children <5 years old. In the
17 acute phase of a flood or tsunami, inhalation of water with polymicrobial contamination may cause aspiration pneumonia. Most respiratory infections emerge several weeks after disaster as disease spreads through shelters and settlement camps. Both disaster victims and rescue
18,19 workers are at risk for respiratory illness due to crowded conditions and compromised sanitation. Some respiratory illnesses
(pertussis and measles) are preventable with adequate vaccination; thus, knowledge of the predisaster vaccination status of a population and sufficient vaccine stores may prevent severe outbreaks. Tuberculosis presents a special challenge for public health officials. To prevent outbreaks,
9 adequate stores of antimicrobials must be on hand, and strict adherence to surveillance of known infectious cases is essential.
GI illness—primarily diarrheal—is another common feature of postdisaster health care. Approximately 40% of deaths in the acute postevent phase
(with 80% of these being children) can be attributed to diarrhea. These diseases are mainly due to issues of water quality and availability, sanitation,
16 and cleaning materials; in one study, the mere presence of soap decreased diarrhea by 27% in a refugee camp. As with respiratory illness, the incidence of GI disease often peaks several weeks after the disaster, and the infections are generally mild. With good health surveillance and attention to typical endemic disease patterns, severe GI illness outbreaks requiring extraordinary public health resources are rare.
Skin and soft tissue infections are seen in a variety of natural disasters. Falling debris from wind, fire, or earthquake can cause traumatic abrasions or lacerations. With a disrupted healthcare system or contaminated water exposure to the wound, the incidence of infection is likely to increase. Although wounds are frequently seen in the acute phase of a disaster, they are also often encountered during the clean­up phase several
20,21 weeks to months after an event. Severe infections are not prevalent; however, organisms such as Vibrio vulnificus in water­based disasters and
9,22 gram­negative bacteria due to soil contamination of wounds in tornadoes and earthquakes have the potential for severe threats to life and limb.
Vectorborne illnesses, such as yellow fever, malaria, and dengue fever, generally have a higher incidence during water­based disasters but can
13 occur after any event in a vulnerable population. Although rare, the outbreak can occur up to 8 weeks after disaster. Regions without predisaster populations of vectors or disease are not likely to suddenly acquire such infections; thus, although there was intense media speculation of the
9 perceived risk of malaria, yellow fever, and other vectorborne illnesses after Hurricane Katrina, these illnesses were not seen in the Gulf Coast. In regions where these illnesses are endemic, vector control is key, and initial postdisaster public health efforts should direct resources toward appropriate programs.
CHRONIC MEDICAL CONDITIONS
Management of the chronic health conditions of a displaced population is a significant contributor to postdisaster morbidity. Separation from medications or health technology products, removal from the usual sources of care, and disruption of the healthcare infrastructure after a catastrophic event can all contribute to exacerbations of patients’ chronic disease. In an analysis of patients presenting to one of the few healthcare facilities available in the 2 months after Hurricane Katrina, 51% of all native patients had at least one preexisting medical condition, and half took at
20 least one regular medication. Other studies have shown that >25% of patients presenting after a variety of natural disasters have chronic medical
21,23 conditions, and “medication refill” or “chronic medical problem” is frequently among the top five diagnoses made in disaster relief health clinics.
Inability to properly control chronic diseases, such as hypertension, diabetes, asthma, or coronary artery disease, may well be the
7 biggest unanticipated health threat to a postdisaster population (Table 6­3). Understanding of the common chronic diseases of a region is essential for health relief efforts. In our experience, well­meaning donations of medications for conditions not normally experienced by our population (e.g., outdated psychiatric medications, older generation antiarrhythmics) went unused. Conversely, we were unable to keep enough antihypertensives or diabetic medications to supply the vast demand.
TABLE 6­3
Commonly Neglected Disaster Response Medications and Supplies
Antihypertensives
Tetanus prophylaxis
Soap
Analgesics—oral and parenteral
Insulin
Oral hypoglycemics and sulfonylureas
Antibiotics, especially for soft tissue infections
Albuterol and ipratropium inhalers
MENTAL HEALTH
An often­overlooked consequence of natural disasters is the psychological burden inflicted on survivors. Destruction of communities and property, witnessing terrifying and often fatal events, and disruption of normal life for days to years after the disaster can cause severe mental health consequences in survivors. In one study of post–Hurricane Katrina survivors, rates of posttraumatic stress disorder were 10 times the expected
24 population incidence and on par with rates in returning Vietnam War veterans. Psychological disorders may be exacerbated by lack of housing and
25 illness or death of a close family member due to the disaster. Disaster­related physical injury or illness may also contribute to mental health comorbidity. The number of emergency amputations due to the 2004 tsunami in an Indonesian surgical clinic quickly overwhelmed the ability of the
26 healthcare system to provide the necessary psychological counseling for patients. Conversely, mental health conditions, such as major depression, may exacerbate acute or chronic physical ailments due to weakened immune systems, disconnection with the larger community and healthcare systems, or attempts to cope by using drugs or alcohol. Suicide rates may also be elevated years after a significant disaster. Any appropriate healthcare response to disasters must include sufficient resources to deal with the degree and severity of psychological disorders suffered by survivors, including children, first responders, and those who have endured severe trauma or loss.
HANDLING OF BODIES
Any natural disaster with a significant number of casualties requires efficient and sanitary removal and proper burial of dead bodies. Although the fear of disease outbreak from survivor or rescue worker exposure to corpses is prevalent, such exposures are rare. Most initial victims of natural disasters die of traumatic injuries; few are likely to have acute, communicable diseases, although the standard transmission risks of chronic infectious diseases,
27 such as human immunodeficiency virus, tuberculosis, or hepatitis, to body­handling rescue workers are present. Universal precautions for protective coverings, hand washing, disposal bags, and vaccinations should be followed by anyone working with dead bodies; this includes having sufficient refrigerated trucks on standby should morgue capabilities be overwhelmed.
HURRICANES
Hurricanes are among the most destructive natural disasters, particularly in coastal areas. Morbidity in the acute phase may be due to wind forces
(collapsing buildings or flying debris) or water (storm surge or rapid flooding). Hurricanes tend to cause more structural damage than floods and
28 therefore can disrupt infrastructure and population resettlement more severely. Hospitals themselves are frequently damaged, but even if
29 structurally intact, they may be affected by loss of power. With catastrophic destruction of a densely populated region, such as in Hurricanes Katrina,
Sandy, and Maria, temporary medical facilities may be needed months after a disaster. Indeed, hurricanes may be the only natural disaster
30 where more injury and death occur during the recovery period than in the acute phase.
Most posthurricane illness and injury falls into predictable categories. Studies from eight different hurricanes over the past 15 years all list a handful of patient diagnoses that compose the vast majority (up to 75%) of visits to healthcare centers: infections (specifically respiratory, GI, and skin); treatment
19,20,28­34 of chronic medical conditions; wounds and lacerations; musculoskeletal injury and trauma; and rashes. In functioning healthcare facilities, ED visits peak several days to weeks after the hurricane as citizens are allowed reentry into the area; there may be an acute, brief influx of several times the
5,20,31 normal patient volume or a steady rise in visits over time.
Initial traumatic injury directly due to hurricanes is relatively uncommon, and simple supplies for minor sprain, strain, and fracture care are recommended. Although surgical units and personnel are an important adjunct, basic supplies and some radiographic capability may provide the best
28,30 investment of limited resources. Unintentional injuries predominate; a post–Hurricane Katrina evaluation of injuries found that only 2% were due
18 to intentional trauma. Causes of traumatic death in the acute period include falling objects, motor vehicle crashes, and electrocution. In the recovery period (weeks to months after the hurricane), clean­up–associated trauma predominates. One study after Hurricane Hugo found that one­third of all
32 wounds evaluated in an ED were caused by chainsaw accidents.
As with other disasters, infections are generally mild, are reflective of the typical local disease burden, and occur several weeks to months after the hurricane. Scattered outbreaks of mild respiratory and GI illness have been described, with overcrowding in shelters and sanitation issues the main predictors of disease. Unless hurricanes are associated with concomitant prolonged flooding in endemic areas, the risks of waterborne disease are
9 minor. Post–Hurricane Katrina incidence of V. vulnificus skin infection was consistent with typical nondisaster rates.
Individuals without transportation or with tenuous connection to community resources are potentially more likely to be negatively impacted by the effects of a severe hurricane. These individuals may not be able to evacuate in advance of a storm and thus suffer greater risks of direct trauma and water­ or wind­related morbidity during the initial impact. Effects may persist beyond the acute phase. A study of Hurricane Mitch survivors noted that

GI illness and emotional distress were more likely months after the storm in those without access to housing, food, or medical care. Other population concerns often seen in hurricanes include the healthcare burden of relief workers (civilian and military). Recovery efforts often require massive numbers of workers whose living conditions are often on par with storm victims. In one study, relief workers were nearly six times more likely than
18 natives to use nonhospital healthcare facilities, and a spike in respiratory illness was attributed to transmission through a military battalion. Our experience found that although younger than the native population, nearly half of relief workers seeking care had significant comorbidities that
20 further burdened the struggling medical system after Hurricane Katrina. Disaster planning should account for the needs of disenfranchised citizens as well as the expected influx of relief workers, many of whom may have chronic medical conditions.
EARTHQUAKES
Earthquakes are a unique disaster phenomenon in that there is no technology to detect a pending earthquake and thus no opportunity to provide a warning. Due to the lack of warning, supplies and a response plan must be continuously available. As was evidenced by the Haiti experience in January
2010, earthquakes can destroy water, electric, communication, gas, and sewage lines and cause structural instability. With no opportunity to evacuate before an earthquake, there is increased potential for casualties. People are at increased risk for being trapped in rubble or stranded. The first 1 to 14 days of response to an earthquake are dedicated to recovery of the injured. After an earthquake, the majority of fatalities occur within the first 3
35 hours.
36,37
Injuries after earthquakes are the result of falling structures and debris. The most common injuries are fractures and crush injuries. One hospital that registered 2892 patients after an earthquake reported that 37% of patients had musculoskeletal injuries. This hospital also reported the frequent
36 occurrence of scalp injuries with large tissue defects. Another hospital that registered 1500 patients in the first 72 hours after an earthquake reported that 78.4% of patients had extremity injuries; 50.4% of injuries were fractures, primarily closed. This same study reported that 37% of injuries required
12 extensive debridement. After the Mansehra earthquake in Pakistan in 2005, the medical equipment that the response teams found most useful was

“external fixators that are easily applied.”

As with all disaster areas, the most common “illnesses” are the “regular medical needs of the people living in the earthquake zone.” In undeveloped
37 regions recovering from large earthquakes, “preventable diseases, such as measles, are on the rise.” With proper sanitary and sewage techniques and adequate supplies of potable water, GI disease remains uncommon.
People with compromised mobility, including some geriatric patients, people with paralysis, amputees, people on ventilators, and people in wheelchairs and walkers, will be less likely to evacuate before the disaster and will have increased difficulty extracting themselves from the ruins.
These people are more likely to be stranded in debris and to sustain crush injuries (see also Chapter 7, “Bomb, Blast, and Crush Injuries”) by collapsing buildings. These populations are especially at risk after earthquakes, because there will be no opportunity to evacuate before the disaster. Rescue and health services coordinators should make provisions for larger numbers of patients with increased needs after earthquakes. One study analyzed a metropolitan area in the United States and found that 31.6% of people >65 years old had a disability and 16.6% of people >65 years required assistance
38 to evacuate. Planning for and responding to earthquakes requires an estimate of the number of citizens with special needs.
TORNADOES

The continent of North America sustains more tornadoes than any other location in the world. Nationally, 800 tornadoes are sighted annually. The
40 annual human toll is estimated to be 80 deaths and 1500 injuries. Tornadoes cause focal damage to buildings and lines above ground. It is unusual
41,42 for entire regions to lose power and communications capacity. It is unusual for multiple hospitals to be disabled by a single tornado. As a result, medical infrastructure in developed countries remains functional. Surge capacity may be tested in the immediate aftermath, but the provision of adequate chronic medical care is usually unhampered.
Most commonly, injuries from tornadoes result from being struck by flying debris or being thrown by the force of the tornado. Patients who were
43,44 thrown or airborne as a result of the tornado sustain more severe injuries than patients who are struck by debris. Additional risk factors for hospitalization or death include being struck by broken glass or falling objects, having one’s home lifted off of its foundation, collapsed ceiling or
44,45 floor, or loss of walls of the shelter structure. Injuries are commonly multisystem. Fractures and soft tissue trauma are the most common injuries
39,46­48 reported. In one study, most patients (91%) sustained injuries to the extremities. Head, chest, and abdominal injuries were also common,
43 39,47,48 occurring in 45%, 45%, and 27% of patients, respectively. Head injuries are the more common cause of death. Death from the impact after
49­51 being thrown by the tornado is thought to most often occur at the scene, rather than en route to or at the hospital.
39,46
Wound contamination is common among patients who are thrown by the tornado. Polymicrobial contamination is common. Gram­negative
43 organisms commonly infect the wounds of those injured by tornadoes. Studies that report low infection rates attribute this to meticulous attention
52 to open wounds.
40,53
Where functioning tornado warning systems exist, injury and loss of life are dramatically reduced. People in mobile homes or outdoors without
45,53,54 cover are more likely to sustain severe and fatal injuries during a tornado. Deaths are more common in patients who are in mobile homes or in
43,44,48,49,55 rooms above ground with windows, who are “older,” or who have less warning regarding the approaching tornado. Use of a tornado shelter
54 is associated with a significant reduction in tornado­associated injuries.
FLOODS AND TSUNAMIS
Water­based natural disasters, such as floods and tsunamis, can be extremely destructive. Although floods can occur from a storm or flowing body of water, tsunamis are formed when a massive force (e.g., an underwater earthquake, volcanic eruption, meteorite impact, or landslide) displaces a large amount of water in a rapid period of time. A spring flood of the Yangtze River in China in 1931 caused >3 million deaths, and more recently, deaths from the Indian Ocean tsunami in 2004 approached 300,000. Factors that contribute to the catastrophic nature of these events include the short (if any) warning period to vulnerable populations and their association with other natural events, such as an oceanic earthquake resulting in a tsunami. Key challenges faced by healthcare providers include severe and prolonged incapacitation of physical buildings due to structural damage or persistent standing water; handling and identification of large numbers of dead bodies; and the chronic needs of a large, displaced population in temporary
26,56,57 shelter.
Acute injuries may be caused by sheer force of water, drowning, and trauma from falling objects. A review of flood deaths from 1989 to 2003 found that morbidity and mortality after flood were related not only to direct physical impact but also the socioeconomic conditions of the affected area. Two thirds of fatalities were from drowning, mostly associated with motor vehicles in the acute phase (e.g., when floodwaters are still high); low crossings and bridges were most dangerous. Only 12% of deaths were from trauma, and the vast majority of cases occurred in the initial impact phase of the
58 disaster.
Illnesses from water­based disasters generally occur after the acute phase and are dominated by infectious disease. True epidemics are rare, and respiratory illnesses predominate. These are generally minor and self­limited, although uncommonly, severe pulmonary infections or pneumonitis directly related to aspiration of floodwaters (e.g., “tsunami lung”) may occur. As long as clean, safe, adequate supplies of potable water are available, acute gastroenteritis and diarrheal illnesses are relatively rare; a Sri Lankan refugee camp after the 2004 tsunami diagnosed GI
23 complaints in <1% of patients. Minor skin trauma is common and has the potential to progress to infected wounds if prolonged exposure to floodwaters and delayed access to care are present.
Certain population groups have been shown to have higher risks of morbidity and mortality after floods and tsunamis. Women had three times the risk of death compared with men after the 2004 tsunami due to heavier clothes impeding escape, risking lives to save their children, lack of swimming
26 ability, and increased dangers in settlement camps. In a comprehensive study of flood deaths, however, men had more than twice the mortality rate of women, which the authors surmised was due to increased risk­taking behavior during the storm (attempting to drive through flooded passages,
58 traveling to unsafe areas in an attempt to retrieve belongings). Public awareness of the rapidity and danger of water, simple swimming instruction, and clear warnings of the dangers of driving during floods may prevent at­risk populations in flood­prone areas from loss of life in future disasters.
BLIZZARDS AND SNOW DISASTERS
A blizzard is a winter storm with wind speeds of 35 miles per hour or higher accompanied by significant falling or blowing snow. The Mid­Atlantic, New
England, Midwest, Plains, Rocky Mountain states, and Alaska are affected by blizzards and snow disasters. Above­ground power and communication lines are the primary resources lost during winter storms. Traditionally, these are restored relatively quickly as compared with the duration without
59 resources after other natural disasters.
59­61
Generally, ED volumes do not significantly increase after blizzards and snow disasters. However, there is a shift in the presenting complaints.
Injuries after winter weather disasters most commonly result from slipping on the ice, falling from trees while clearing branches, and injuries from
62,63 clearing snow. The most common injuries are back injuries and fractures. In one study, the incidence of fractures increased until the sixth day after
64 the storm.
60,62,65­68
Carbon monoxide poisoning increases dramatically during and following winter weather disasters. Most people presenting with
69 65 carbon monoxide poisoning report using a portable generator. A smaller group reported burning charcoal in the house to generate heat. In one
62 study after a blizzard, the local hyperbarics services were overwhelmed and unable to respond to the sudden surge in carbon monoxide poisonings.
One study documented an increase in the number of myocardial infarctions and angina after a blizzard. This was primarily in association with shoveling snow. The majority of these cases were in people who did not have previously diagnosed coronary artery disease. One fourth of these
70 patients were women.
RELIEF EFFORTS
Of particular importance to the emergency medical practitioner is the experience and effect of postdisaster volunteer relief efforts. Although well meaning, the literature is filled with examples of emergency personnel who ended up burdening rather than assisting a fractured community. Any emergency practitioner who truly wishes to provide meaningful health care to a displaced and disenfranchised patient population should be mindful of the lessons learned from a variety of natural disasters.
Medical relief volunteers are often the first outside help to arrive in the aftermath of a disaster, and although some are well coordinated, many are not.
Volunteers are often exuberant, expecting dramatic rescues and emergency interventions. They may be unwilling to provide much­needed routine
71 medical care, unfamiliar with the region or local disease patterns, and unable to fully comprehend the loss of resources. Furthermore, the needs of rescue personnel often strain a fragile infrastructure, with demands on housing, food, health care, and essential resources; one analysis of relief efforts after the 2004 tsunami concluded that “personnel who do not bring essential skills are often a burden—much more should also be done to
26 ensure that the right type of people are sent on relief missions.”
Embedding locals familiar with the language, culture, and healthcare patterns of the affected region can significantly enhance the effectiveness of relief efforts and promote cooperation between disparate volunteer groups. Furthermore, appropriate anticipation by relief groups of the true population needs can be crucial: reproductive hygiene kits were distributed to women in a postflood refugee camp after an initial spike in sexual
26 assaults and were widely credited with improving patient morale and health.
The National Disaster Medical System, a government agency responsible for sending highly organized and often experienced teams to disaster areas, recommends the following for disaster response: teams with well­trained and organized support staff; the ability to be self­sufficient for at least 72 hours; clear communication with area hospitals and medical resources; individuals dedicated to transportation issues; a designated coordinator of
30 walk­in volunteers; and professional methods of record keeping, forms, and copy­making capability. Our experience during Hurricane Katrina also suggests that strong, coordinated partnerships between local emergency personnel and formal military medical units have great promise for sophisticated, expanded acute and delayed postdisaster medical relief as well as continuance of medical education and resident training programs in a devastated community.
