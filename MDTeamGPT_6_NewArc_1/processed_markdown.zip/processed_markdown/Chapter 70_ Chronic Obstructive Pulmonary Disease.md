## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 70: Chronic Obstructive Pulmonary Disease
Craig G. Bates
INTRODUCTION AND EPIDEMIOLOGY
Chronic obstructive pulmonary disease (COPD) is a common, preventable, and treatable disease characterized by persistent respiratory symptoms and
1­6 airflow limitation that is due to airway and/or alveolar abnormalities usually caused by significant exposure to noxious particles or gases. COPD often presents with symptoms of dyspnea, chronic cough or sputum production, and/or a history of exposure to known risk factors for the disease such as cigarette smoke. The World Health Organization Global Initiative for Chronic Obstructive Lung Disease COPD definition encompasses chronic bronchitis, emphysema, bronchiectasis, and asthma, recognizing that most patients have a combination of the different diseases. COPD is the third leading cause of death in the United States, with women now accounting for >50% of COPD­related deaths.
CHRONIC COMPENSATED OBSTRUCTIVE PULMONARY DISEASE
PATHOPHYSIOLOGY
Although tobacco smoke is the major risk factor for developing COPD, only 15% of smokers will develop COPD. Occupational dust, chemical exposure, and air pollution are other risk factors for developing COPD. α ­Antitrypsin deficiency accounts for <1% of COPD patients.

Irritants, notably tobacco smoke and air pollutants, trigger an increase in inflammatory cells in the airways, lung interstitium, and alveoli. Proteases break down lung parenchyma and stimulate mucus secretion. Mucus­secreting cells replace cells that normally secrete surfactant and protease inhibitors. These changes result in a loss of elastic recoil, narrowing, and collapse of the smaller airways. Mucous stasis and bacterial colonization then develop in the bronchi. The earliest objective changes in the evolution of COPD are often clinically imperceptible; these early changes are small increases in peripheral airway resistance or lung compliance. Because dyspnea and hypersecretion often progress insidiously, it may take decades before COPD becomes clinically evident. The Global Initiative for Chronic Obstructive Lung Disease guidelines are helpful for the early diagnosis and
 treatment of COPD (Table 70­1), although there is only a weak correlation between forced expiratory volume in  second (FEV ), symptoms, and

 health­related quality of life.
TABLE 70­1
Classification of COPD Severity2­6
Stage In Patients with FEV  /FVC <0.7:
Mild COPD FEV ≥80% predicted

Moderate COPD FEV between 50% and 79% predicted

Severe COPD FEV between 30% and 49% predicted

Very severe COPD FEV <30% predicted

Abbreviations: COPD = chronic obstructive pulmonary disease; FEV = forced expiratory volume in  second; FVC = forced vital capacity.

Chapter 70: Chronic Obstructive Pulmonary Disease, Craig G. Bates 
The central element of chronic lower airway obstruction is impedance to expiratory airflow due to increased resistance or decreased caliber of the
. Terms of Use * Privacy Policy * Notice * Accessibility small bronchi and bronchioles. Airflow obstruction results from a combination of airway secretions, mucosal edema, bronchospasm, and bronchoconstriction. Exaggerated airway resistance reduces total minute ventilation and increases respiratory work.
In emphysema, distortion or destruction of alveolar and capillary surfaces results in alveolar hypoventilation and ventilation–perfusion mismatch, creating arterial hypoxemia and hypercarbia. The right ventricle hypertrophies and dilates, resulting in pulmonary hypertension and right ventricular failure. Right ventricular pressure overload may trigger atrial or ventricular dysrhythmias. (See Chapter , “Systemic Hypertension,” and Chapter ,
“Pulmonary Hypertension.”)
CLINICAL FEATURES
2­6
The hallmark symptoms are chronic and progressive dyspnea, cough, and sputum production; these often vary from day to day. Minor hemoptysis is frequent, especially in those with chronic bronchitis and bronchiectasis, although it may herald lung cancer. Physical findings may include tachypnea, accessory respiratory muscle use, or pursed­lip exhalation. Lower airway obstruction causes expiratory wheezing, especially during maximum forced exhalation, and prolongation of the expiratory time. Patients with chronic bronchitis exhibit coarse crackles as uncleared secretions move about the central airways. In patients with emphysematous disease, there is expansion of the thorax, impeded diaphragmatic motion, and global diminution of breath sounds. Poor dietary intake and excessive caloric expenditure for the work of breathing cause weight loss, notably in emphysema. In the early stages, arterial blood gas analysis reveals mild to moderate hypoxemia without hypercapnia.
As COPD advances, especially when the FEV falls below  L, hypoxemia becomes more severe and hypercapnia develops. Arterial oxygenation worsens
 during acute exacerbations, exercise, and sleep. Clinical signs of severe COPD include facial vascular engorgement from secondary polycythemia, and tremor, somnolence, and confusion from hypercarbia. Right heart failure may occur and bring edema or ascites, and the signs are often disguised or underestimated by the seemingly more overwhelming signs of respiratory disease. If concomitant left heart failure exists, the cardiac auscultatory findings are sometimes hard to appreciate given the pulmonary inflation abnormalities of COPD.
DIAGNOSIS
Suspect chronic, compensated COPD based on symptoms and risk exposure profiles, and confirm it by spirometry with a postbronchodilator FEV –to–

 2­6 forced vital capacity ratio of <0.7. Once the disease progresses, the percentage of predicted FEV is a better measure of disease severity.

Chronic bronchitis is not radiographically apparent unless bronchiectasis is present. In emphysema, radiographs show hyperaeration, seen as increased anteroposterior chest diameter, flattened diaphragms, increased parenchymal lucency, and attenuation of pulmonary arterial vascular shadows (Figure 70­1).
It is important to acknowledge that COPD is underdiagnosed due to a variety of factors. More than 50% of patients with spirometric criteria for

COPD did not carry that diagnosis. Patients attribute declines in respiratory function or a chronic cough as simply due to aging and/or a normal side effect of smoking. ED clinicians will sometimes have to make a clinical assessment and treat undiagnosed COPD. Such a situation is especially true in patients with poor access to care and/or poor utilization of primary care resources.
FIGURE 70­1. Posteroanterior chest radiograph in a patient with chronic obstructive pulmonary disease.
Distinguishing acute heart failure from COPD can be difficult. A B­type natriuretic peptide level <100 picograms/mL supports a diagnosis of COPD; levels >500 picograms/mL have a sensitivity of 80% and positive predictive value of 47% for acute heart failure (see Chapter , “Respiratory

Distress”). The ECG detects dysrhythmias or ischemia, but does not accurately assess the severity of pulmonary hypertension or right ventricular dysfunction.
TREATMENT
Treatment for chronic compensated COPD includes oxygen, pharmacotherapy, measures to decrease mucus secretion, smoking cessation, and pulmonary rehabilitation.
Oxygen
Long­term oxygen therapy reduces COPD mortality. The goal is to increase the baseline partial pressure of arterial oxygen (PaO ) to ≥60 mm Hg or the
 arterial oxygen saturation (SaO ) to ≥90% at rest. Criteria for long­term oxygen therapy are a PaO ≤55 mm Hg, an SaO ≤88%, or a PaO between  and

 mm Hg when pulmonary hypertension, cor pulmonale (sustained right ventricular failure), or polycythemia is present.
Pharmacotherapy
Pharmacotherapy does not alter disease progression but provides symptomatic relief, controls exacerbations, improves quality of life, and improves
 exercise performance. Most prefer inhaled long­acting β ­agonists for baseline care over short­acting formulations. Long­acting inhaled β ­agonists,
  such as salmeterol, formoterol, olodaterol, and indacaterol, are options. Short­acting inhaled β ­agonists, usually albuterol, are added as needed.

Combining bronchodilators with different mechanisms and duration of action may increase bronchodilation without increasing side effects.
Combination inhalers of short­acting β ­agonists with anticholinergic agents include fenoterol/ipratropium and salbutamol/ipratropium.

Anticholinergic agents cause bronchodilation by blocking the effect of acetylcholine on muscarinic­3 receptors. Long­acting anticholinergic agents, such as tiotropium, aclidinium, umeclidinium, and glycopyrronium, are preferred over short­acting agents, such as ipratropium bromide or
,12 oxitropium bromide. Bronchodilators often improve FEV by 10%.

Experts do not recommend long­term systemic corticosteroid therapy for all COPD patients because only about 20% to 30% improve. Short­term steroid use (days) aids in treating exacerbations. Use daily inhaled corticosteroids for patients with a documented spirometric response to inhaled
 corticosteroids, with an FEV of <50%, or with predicted and recurrent exacerbations requiring antibiotic treatment or systemic corticosteroids. Long­
 term treatment with inhaled corticosteroids added to long­acting bronchodilators is best for patients at high risk of exacerbation. Combination inhalers with long­acting β ­agonists plus corticosteroids include formoterol/budesonide, formoterol/mometasone, salmeterol/fluticasone, and

 vilanterol/fluticasone.
Although retrospective studies suggest that statins decrease the rate and severity of exacerbations, rate of hospitalization, and mortality, a large
 prospective trial failed to demonstrate benefit of daily simvastatin over placebo. Daily azithromycin may decrease acute exacerbations in older
 patients and those with milder COPD.
Secretion Mobilization
Mobilize respiratory secretions with generous oral fluid intake and room humidification. Limit the use of antihistamines, antitussives, mucolytics, and decongestants. Expectorants are not of clear benefit.
Smoking Cessation, Pulmonary Rehabilitation, and Vaccination
 2­6
Smoking cessation is the only intervention that can reduce both the rate of decline in lung function and mortality from respiratory causes. The ED is
 one key site to attempt smoking cessation interventions. A combination of nicotine replacement therapy or medications and behavioral
 interventions can assist patients with smoking cessation, especially with referral to a program.
Pulmonary rehabilitation can improve exercise capacity and quality of life for patients with moderate to severe COPD. Pneumococcal vaccination and
 influenza vaccination are key to dampen acute infections.
ACUTE EXACERBATIONS OF CHRONIC OBSTRUCTIVE PULMONARY DISEASE

Acute exacerbations of COPD result in worsening of respiratory symptoms beyond normal day­to­day variations and are usually triggered by an infection or respiratory irritant. More than 75% of patients with acute exacerbations have evidence of viral or bacterial infection, with up to half
,20 specifically due to bacteria. There is also evidence for gastroesophageal reflux disease as an additional risk factor for COPD exacerbations,
,22 although there is no evidence that treatment of gastroesophageal reflux disease reduces exacerbations. Other important triggers for
 exacerbations are hypoxia, cold weather, β­blockers, opioids, or sedative­hypnotic agents.
The final common pathway for a COPD exacerbation is the release of inflammatory mediators that result in bronchoconstriction, pulmonary vasoconstriction, and mucus hypersecretion. The work of breathing increases due to higher airway resistance and lung hyperinflation. The oxygen
 demand of respiratory muscles increases, generating additional carbon dioxide and causing hypercapnia, resulting in further physiologic stress.
Acute exacerbations of COPD are primarily due to ventilation–perfusion mismatch rather than the expiratory airflow limitation seen with asthma
 exacerbations. Supplemental oxygen increases blood oxygen concentrations and can help reverse pulmonary vasoconstriction.
CLINICAL FEATURES
The most life­threatening feature of an acute exacerbation is hypoxemia (arterial saturation <90%). Signs of hypoxemia include tachypnea, tachycardia, systemic hypertension, cyanosis, and a change in mental status. With increased work of breathing, carbon dioxide production increases; alveolar hypoventilation creates arterial carbon dioxide retention and respiratory acidosis.
The patient tries to overcome severe dyspnea and orthopnea by sitting in an up­and­forward position, using pursed­lip exhalation, and engaging accessory muscles to breathe. Pulsus paradoxus (a decrease of >10 mm Hg in systolic blood pressure during respiratory cycles) may be noted during palpation of the pulse or during blood pressure recording. Complications, such as pneumonia, pneumothorax, pulmonary embolism, or an acute abdomen, may exacerbate COPD. Other acute triggers include asthma, congestive heart failure, pneumonia, pulmonary embolism, tuberculosis, and metabolic disturbances.
DIAGNOSIS
With the history, seek causes for exacerbation and triggers plus sputum changes; then assess oxygenation and acid­base status, and perform a physical examination.
Pulse oximetry may identify hypoxemia, and capnography may identify hypercarbia. Arterial blood gas analysis is the best tool in acute evaluation for assessing oxygenation, ventilation, and acid­base disturbances. Arterial blood gases clarify the severity of exacerbation and the probable clinical course. Respiratory failure typically shows an arterial PaO of <60 mm Hg or an arterial SaO <90% in room air. Respiratory acidosis is present if the
  partial pressure of carbon dioxide (PCO ) is >44 mm Hg. If the pH is <7.35, there is an acute and uncompensated component of respiratory or metabolic
 acidosis present. While arterial blood is best, the pH on a venous blood gas shows good agreement with that on an arterial blood gas, a potentially
 useful screening tool.
In acute respiratory acidosis, the serum bicarbonate rises by  mEq/L for each 10­mm Hg increase in PCO , and the pH will change by .008 × (40 – PCO ).

In chronic respiratory acidosis, the bicarbonate rises by .5 mEq/L for each 10­mm Hg increase in PCO , and the pH will change by .03 × (40 – PCO ).

Changes outside of these ranges suggest an accompanying metabolic disorder (see Chapter , “Acid­Base Disorders,” and Chapter , “Respiratory
Distress”).
Frequently, patients with an acute COPD exacerbation are too dyspneic to perform bedside pulmonary function tests, so measurements are often
2­6  inaccurate. Similarly, physical examination and physician estimates of pulmonary function are inaccurate.
Assessment of sputum includes questions about changes in volume and color, especially an increase in purulence. An increase in sputum volume and
,27 change in sputum color suggest a bacterial infection and the need for antibiotic therapy. Sputum cultures usually contain mixed flora and do not
2­6 help guide ED antibiotic selection.
Ancillary Studies
Radiographic abnormalities are common in COPD exacerbation and may identify the underlying cause of the exacerbation, such as pneumonia, or may
 identify an alternative diagnosis such as acute heart failure.
The ECG can identify ischemia, acute myocardial infarction, cor pulmonale, and dysrhythmias. Measure levels in patients who take theophylline. Obtain other tests, such as CBC, electrolytes, troponin, B­type natriuretic peptide, D­dimer, and CT of the chest based on clinical findings.
TREATMENT
The goals of treatment are to correct tissue oxygenation, alleviate reversible bronchospasm, and treat the underlying cause (Table 70­2). Factors that influence therapy in the ED include any mental status changes; the degree of reversible bronchospasm; recent medication usage and assessment for drug toxicity; prior history of exacerbation courses, hospitalization, and intubation; presence of contraindications to any drug or drug class; and specific causes or complications from the exacerbation. Patients who do not respond as expected to standard therapy need a prompt reevaluation for other potentially life­threatening issues. See Table 70­3 for an overview of the differential diagnosis of COPD exacerbations.
TABLE 70­2
ED Management of COPD Exacerbations2­6
Assess severity of symptoms
Administer controlled oxygen (target arterial oxygen saturation of 88%–92%)
Continuous cardiovascular status monitoring
Perform arterial blood gas measurement after 20–30 min if arterial oxygen saturation remains <90% or if concerned about symptomatic hypercapnia
Administer bronchodilators
β ­Agonists and/or anticholinergic agents by nebulization or metered­dose inhaler with spacer

Add oral or IV corticosteroids
Consider antibiotics if increased sputum volume, change in sputum color, fever, or suspicion of infectious etiology of exacerbation
Consider noninvasive mechanical ventilation
Evaluation may include chest radiograph, CBC with differential, basic metabolic panel, ECG
Address associated comorbidities
TABLE 70­3
Critical Differential Diagnosis of Chronic Obstructive Pulmonary Disease (COPD) Exacerbations2­6
Diagnosis Clinical Features Caveats
Asthma Earlier onset Can coexist with COPD.
Varying symptoms Many patients diagnosed with asthma
Family history actually have COPD or mixed asthma­
Reversible airflow COPD.
CHF Presence of orthopnea (LR, .0) and dyspnea with exertion (LR, .3) slightly favors CHF Can coexist with COPD.
Jugular venous distention, hepatojugular reflux, bibasilar rales Shares some historical elements also
Chest radiograph may show cardiomegaly or interstitial edema found in COPD.
BNP <100 picograms/mL not likely to be CHF; BNP >500 picograms/mL more likely to be Multiple conditions can falsely elevate or
CHF decrease the BNP level.
PE Risk factors include older age, recent surgery or trauma, prior venous thromboembolic 20%–25% of patients with a severe COPD disease, hereditary thrombophilia, malignancy, smoking, and use of medications exacerbation with an unclear trigger have containing estrogen a PE.
Patients with intermediate to high pretest probability may require further testing, such as Triad of PE (pleuritic chest pain, dyspnea,
CT angiography; D­dimer may be useful in ruling out PE in low­risk patients tachycardia, and hypoxemia) unusual.
ACS Obtain ECG or troponin in those with chest pain or dyspnea and risk factors for ACS Dyspnea may be the primary complaint in patients with ACS.
Pneumothorax Obtain chest radiograph, US, or CT COPD is a risk factor for spontaneous pneumothorax.
Pneumonia Obtain chest radiograph Frequently coexists with a COPD exacerbation.
Abbreviations: ACS = acute coronary syndrome; BNP = B­type natriuretic peptide; CHF = congestive heart failure; LR, likelihood ratio; PE = pulmonary embolism.
Oxygen

Administer oxygen to achieve a PaO of  to  mm Hg or an SaO between 88% and 92%. There is potential harm in targeting higher
  oxygen levels. Use any of the following devices: standard dual­prong nasal cannula, simple facemask, or Venturi mask. It may take  to  minutes from administration of supplemental oxygen for improvement to occur. Be aware that oxygen administration may produce hypercapnia through worsening ventilation–perfusion mismatching; this is one reason non­rebreathing masks are best used cautiously. Assess arterial blood gases and/or continuous end­tidal carbon dioxide and oxygen saturation monitoring with venous blood gases to allow optimal assessment of the PCO and acid­
 base status. If adequate oxygenation does not exist or respiratory acidosis develops, assisted ventilation is an option.
β ­Adrenergic Agonists

2­6
Short­acting β ­agonists are first­line therapies in the management of acute, severe COPD. Aerosolized forms, using nebulizer or metered­dose

2­6 inhalers, deliver drug to the target area optimally and minimize systemic toxicity. β ­Agonists are best given every  to  minutes if tolerated.

Nebulized aerosols every  minutes may result in more rapid improvement of FEV , but more frequent side effects, including tremor, anxiety, and
 palpitations. If the patient can cooperate, metered­dose inhalers (multiple puffs given closely together along with coaching on technique, then repeated) with a spacer deliver drug to target receptors most efficiently; reserve nebulizers for when this fails, cannot occur, or in extremes of age. Use
 air to drive nebulizers, supplementing oxygen as described earlier. Continuous cardiac monitoring is helpful, especially for patients with heart disease.
Anticholinergics
These agents are best combined with β ­agonists. There is moderate evidence showing benefit. Ipratropium bromide given as a single dose by
 metered­dose inhaler with a spacer or as an inhalant solution by nebulization (0.5 milligram or .5 mL of the .02% inhalant solution) is the usual agent of choice, although aerosolized glycopyrrolate (2 milligrams in  mL of saline) is also effective. Side effects are minimal and limited to dry mouth and an occasional metallic taste.
Evidence regarding the effectiveness of the combination of a β ­adrenergic agent and an anticholinergic agent compared with a single agent alone is
 conflicting, although many physicians favor using this combination initially and some favor using it if the response to maximal doses of a single bronchodilator is poor. Do not use long­acting inhaled anticholinergics, such as tiotropium, aclidinium, and glycopyrronium, for the acute
2­6 management of COPD.
Corticosteroids

A short course (5 to  days) of systemic steroids improves lung function and hypoxemia and shortens recovery time in acute COPD exacerbations. Use of corticosteroids in the ED does not affect the rate of hospitalization but decreases the rate of return visits. There appears to be no benefit from oral
 prednisone >  to  mg as a single or divided twice daily total dose. There is also no benefit to IV administration of glucocorticoids except in patients who cannot tolerate oral intake or are in shock and have impaired absorption of medication from the GI tract. Hyperglycemia is the most common adverse effect.
Antibiotics
Prescribe antibiotics in moderately or severely ill patients if there is evidence of infection, such as change in volume of sputum and increased
,27 purulence of sputum. There is little controversy about use of antibiotics in severely ill patients, but varying guidelines exist for guiding these decisions in moderately ill patients. Choose agents directed at the most common pathogens associated with COPD exacerbation:
,24,27
Streptococcus pneumoniae, Haemophilus influenzae, and Moraxella catarrhalis. There is no specific agent shown to be superior.
Initial antibiotics for uncomplicated COPD include macrolides (azithromycin), tetracyclines (doxycycline), or trimethoprim­sulfamethoxazole. Consider providing coverage for Pseudomonas aeruginosa in patients with one or more of the following risk factors: admission and/or antibiotic course in past

 months, prior culture showing Pseudomonas infection, or concomitant bronchiectasis. There is little evidence regarding the duration of treatment, which ranges from  to  days.
Noninvasive and Invasive Mechanical Ventilation
Indications and relative contraindications of noninvasive ventilation are in Table 70­4. See Chapter , “Noninvasive Airway Management and
Supraglottic Airways,” for more discussion on this option. All patients receiving noninvasive positive­pressure ventilation require continuous
 cardiorespiratory monitoring and frequent reassessment for setting changes and for tolerance of therapy.
TABLE 70­4
Indications and Relative Contraindications for Noninvasive Ventilation2­6
Selection criteria Acidosis (pH <7.36)/hypercapnia (PaCO2 >50 mm Hg)/oxygenation deficit (PaO2 <60 mm Hg or SaO2 <90%)
Severe dyspnea with clinical signs such as respiratory muscle fatigue or increased work of breathing
Exclusion criteria (any) Respiratory arrest
Cardiovascular instability (hypotension, arrhythmias, myocardial infarction)
Change in mental status; uncooperative patient
High aspiration risk
Viscous or copious secretions
Recent facial or gastroesophageal surgery
Craniofacial trauma
Fixed nasopharyngeal abnormalities
Burns
Extreme obesity
Abbreviations: PaCO2 = partial pressure of arterial carbon dioxide; PaO2 = partial pressure of arterial oxygen; SaO2 = arterial oxygen saturation.
Use assisted mechanical ventilation when there is evidence of respiratory muscle fatigue, worsening respiratory acidosis, deteriorating mental status, or refractory hypoxemia (Table 70­5). The goals of assisted mechanical ventilation are to rest ventilatory muscles and to restore adequate gas exchange. After endotracheal intubation, the methods most commonly used are assist­control ventilation, pressure support ventilation, or pressure support ventilation in combination with intermittent mandatory ventilation. See Chapter 29B, “Mechanical
Ventilation,” for more detail. Adverse events associated with invasive ventilation include pneumonia, barotrauma, and inability to wean the COPD patient from the ventilator.
TABLE 70­5
Indications for Intubation With Mechanical Ventilation2­6
Unable to tolerate noninvasive ventilation (NIV) or NIV failure
Respiratory or cardiac arrest
Respiratory failure
Decreased consciousness or increased agitation
Massive aspiration
Persistent inability to remove respiratory secretions
Hypotension
Persistent hypoxemia despite optimal respiratory treatment
Hemodynamic instability
Other Therapies
While selectively used, current evidence does not support the routine use of magnesium sulfate (2 to  grams IV over  minutes) or methylxanthines
(aminophylline  to  milligrams/kg IV over  minutes) in the treatment of an acute COPD exacerbation. The utility of high­flow nasal cannula, particularly as an alternative to nasal intermittent positive­pressure ventilation, is currently unclear.
DISPOSITION AND FOLLOW­UP
Admit patients who fail to improve, those who deteriorate despite medical therapy, those with significant comorbidity, and those without an intact social support system; the destination unit must have adequate nursing and respiratory monitoring ability. The Global Initiative for Chronic
Obstructive Lung Disease guidelines help guide the ED disposition decision­making process (Tables 70­6 and 70­7). Select patients without
 respiratory failure may avoid hospitalization with nurse­administered home care (“hospital at home care”). After ED discharge, 25% to 43% of
36­38 patients with COPD exacerbation show ongoing symptoms or relapse of symptoms.
TABLE 70­6
Indications for Hospital Admission6
Marked increase in intensity of symptoms, such as sudden development of resting dyspnea or inability to walk from room to room
Failure of exacerbation to respond to initial medical management
Significant comorbidities
Newly occurring dysrhythmias, heart failure
Frequent exacerbations and/or frequent relapse after ED treatment
Older age
Insufficient home support
TABLE 70­7
Indications for Intensive Care Admission6
Severe dyspnea that responds inadequately to initial emergency therapy
Changes in mental status (confusion, lethargy, coma)
Persistent or worsening hypoxemia (PaO2 <40 mm Hg) and/or severe/worsening respiratory acidosis (pH <7.25) despite supplemental oxygen and
NIPPV
Need for invasive mechanical ventilation
Hemodynamic instability
(Local resources and capabilities may dictate different decision making; with NIPPV patients in particular, different systems dictate different dispositions.)
Abbreviations: NIPPV = noninvasive positive­pressure ventilation; PaO2 = partial pressure of arterial oxygen.
The following are associated with a higher risk for relapse within  weeks after an ED visit: five or more ED or clinic visits in the past year, the amount of activity limitation (based on a 4­point scale), the initial respiratory rate (for each  breaths/min over  breaths/min), and use of oral corticosteroids
36­38 before arrival in the ED.
If discharging from the ED or observation unit, arrange the following: (1) a supply of home oxygen, if needed; (2) adequate and appropriate bronchodilator treatment (usually a metered­dose inhaler with a spacer and teaching; nebulized therapies are reserved for those who cannot use the
2­6 metered­dose inhaler); (3) short course of oral corticosteroids ; and (4) a follow­up appointment with the primary care physician or pulmonologist, preferably within a week. Reassess inhaler technique, reinforce importance of completion of steroid therapy and antibiotics, if prescribed, and review management plan.


