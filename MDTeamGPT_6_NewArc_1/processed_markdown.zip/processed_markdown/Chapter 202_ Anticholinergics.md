## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 202: Anticholinergics
Frank LoVecchio
INTRODUCTION
Anticholinergic properties are present in over 600 compounds, including prescription drugs, over­the­counter medications, and plants (Table 202­1).
Many of these substances possess anticholinergic activity as either a direct therapeutic effect or as an adverse effect in addition to their primary or predominant pharmacologic effect. Atropine (D,L­hyoscyamine), hyoscyamine, and scopolamine (L­hyoscine) are natural alkaloids that represent prototypical anticholinergic compounds.
TABLE 202­1
Major Groups of Substances With Anticholinergic Activity
Class and Subclass Prototypical Agent(s)
Cyclic antidepressants Amitriptyline hydrochloride, imipramine hydrochloride, doxepin hydrochloride
Antihistamines
Ethanolamines Diphenhydramine, dimenhydrinate
Ethylenediamines Tripelennamine
Alkylamines Chlorpheniramine
Piperazines Loratadine, meclizine, cetirizine
Phenothiazines Prochlorperazine, promethazine
Antiparkinson drugs
Tropanes Benztropine mesylate
Piperidines Trihexyphenidyl
Antipsychotics
Phenothiazines Chlorpromazine, thioridazine, perphenazine
Nonphenothiazines Clozapine, olanzapine, molindone, loxapine, quetiapine
Antispasmodics
Cyclohexane carboxylic Dicyclomine acids Methantheline bromide
Quaternary ammonium
Belladonna alkaloids
Tropanes Atropine, homatropine, scopolamine hydrobromide
Pyrrolidines Glycopyrrolate

Chapter 202: Anticholinergics, Frank LoVecchio 
Mydriatics
. Terms of Use * Privacy Policy * Notice * Accessibility
Phenylacetates Cyclopentolate hydrochloride
Pyridines Tropicamide
Skeletal muscle relaxants
Tricyclics Cyclobenzaprine hydrochloride
Ethylamines Orphenadrine citrate
Plants
Datura species Datura stramonium (Jimson weed), Datura candida (angel’s trumpet)
Mandragora species Mandragora officinarum (mandrake)
Brugmansia species Brugmansia suaveolens (angel’s tear, maikoa, or white angel’s trumpet), Brugmansia versicolor (angel’s tear or angel’s trumpet)
Mushrooms
Amanita species Amanita muscaria, Amanita pantherina

Antihistamine (particularly diphenhydramine) overdose is the most common overdose that produces anticholinergic toxicity. Toxicity in children may result from accidental ingestion of an anticholinergic medication, oral administration of hyoscyamine­containing agents to treat colic, topical use of
2­5 diphenhydramine­containing salves, or therapeutic application of a transdermal hyoscine patch. In the elderly, therapeutic doses of one or multiple medications with anticholinergic properties may produce anticholinergic symptoms, or they may simply cause ileus without other anticholinergic
,7 findings. Ophthalmologic instillation of anticholinergic mydriatics can cause toxicity, especially in the elderly or young children; patients are
 therefore instructed to lie down and apply  minutes of gentle pressure on the nasolacrimal duct when instilling these agents.

Atropine is the antidote for cholinergic syndromes produced from nerve agents or organophosphate insecticides. Administration of high­dose atropine to someone without cholinesterase poisoning can result in anticholinergic toxicity. This occurred in Israel during the first Gulf War in 1991, when frightened civilians dosed themselves with atropine fearing an incoming Scud missile chemical weapon attack.
Plant poisonings may result in an anticholinergic toxidrome. In Taiwan, the anticholinergic toxidrome is most commonly associated with plant
 exposures. Belladonna alkaloid­containing plants have potent anticholinergic effects and produce toxicity  to  hours after ingestion (sooner if
,12 smoked). Alkaloid plants are abused for their hallucinogenic effects. Group poisonings with anticholinergic plants are common in adolescents
,14 seeking psychoactive hallucinogenic effects. Inadvertent poisoning from the ingestion of belladonna­contaminated herbal teas and Chinese
,16 traditional medicines has been reported. Ingestion of seeds and berries, sometimes due to mistaken identity, can produce anticholinergic
,18  toxicity. Anticholinergics have been substituted for other abused psychoactive drugs and then sold to unwitting customers. Adulteration of
20­22 commonly abused drugs (e.g., heroin, cocaine) with scopolamine or atropine has been observed.
PHARMACOLOGY
Anticholinergic drug absorption can occur after ingestion, smoking, or ocular use. With oral ingestion, the onset of anticholinergic toxicity usually occurs within  to  hours. Because muscarinic blockade slows gastric emptying and decreases GI motility, absorption and peak clinical effects are often delayed. An example is diphenoxylate­atropine (e.g., Lomotil®), an antidiarrheal agent that may present with toxicity up to  hours after ingestion.
Cholinergic receptors exist as two major subtypes: muscarinic receptors and nicotinic receptors. Muscarinic receptors are found predominantly on autonomic effector cells that are innervated by postganglionic parasympathetic nerves, on some ganglia, and in the brain, particularly the hippocampus, cortex, and thalamus. Nicotinic receptors are found at peripheral autonomic ganglia, at neuromuscular junctions, and also in the brain.
Acetylcholine is the neurotransmitter that modulates both receptor types. Genes encode for five muscarinic receptors through G­protein receptor activation; four seem to be physiologically active (Table 202­2).
TABLE 202­2
Muscarinic Receptors
Receptor Target Organ Receptor Action When Stimulated
M Autonomic ganglia Decreases activity in autonomic ganglia

Brain Increases salivary and gastric acid secretion
Salivary glands
Stomach
M Heart Decreases sinus node rate and slows conduction through the atrioventricular node

Decreases the force of atrial contraction and possibly ventricular contraction
M Smooth muscle Bronchospasm

Endocrine/exocrine glands Mild vasodilation
Iris Increases saliva and gastric acid production
Constricts the pupil
M CNS Multiple actions

M Has not been elucidated

The structure of nicotinic receptors is complex, composed of several subunits that are encoded by multiple genes. The subunits are combined into four main families of nicotinic receptors: the muscle type, found at the neuromuscular junction; the ganglion type, found in autonomic ganglia; and two brain types found in the CNS.
Anticholinergic drugs and plant toxins competitively inhibit or antagonize the binding of the neurotransmitter acetylcholine to muscarinic acetylcholine receptors. The term anticholinergic is technically a misnomer. A more accurate term is antimuscarinic agents, because anticholinergic agents do not antagonize effects at nicotinic acetylcholine receptors such as those at the neuromuscular junction. Clinical manifestations from these drugs are modulated through disturbances in the CNS (central effects) and the parasympathetic nervous system (peripheral effects) (Table 202­3).
TABLE 202­3
Muscarinic and Antimuscarinic Effects
Organ Stimulation or Muscarinic Effect Antagonism or Antimuscarinic Effect
Brain Complex interactions Complex interactions
Possible improvement in memory Impairs memory
Produces agitation, delirium, and hallucinations
Fever
Eye ↓ Pupil size (miosis) ↑ Pupil size (mydriasis)
↓ Intraocular pressure ↑ Intraocular pressure
↑ Tear production Loss of accommodation (blurred vision)
Mouth ↑ Saliva production ↓ Saliva production
Dry mucous membranes
Lungs Bronchospasm Bronchodilation
↑ Bronchial secretions
Heart ↓ Heart rate ↑ Heart rate
Slows atrioventricular conduction Enhances atrioventricular conduction
Peripheral vasculature Vasodilation (modest) Vasoconstriction (very modest)
GI ↑ Motility ↓ Motility
↑ Gastric acid production ↓ Gastric acid production
Produces emesis
Urinary Stimulates bladder contraction and expulsion of urine ↓ Bladder activity
Promotes urinary retention
Skin ↑ Sweat production ↓ Sweat production (dry skin)
Cutaneous vasodilation (flushed appearance)
The signs and symptoms of anticholinergic toxicity are a result of both central and peripheral cholinergic blockade. The central anticholinergic syndrome refers to the clinical state when there is predomination of the central effects (fever, agitation, delirium, coma) of muscarinic receptor antagonism. The peripheral anticholinergic syndrome refers to peripheral muscarinic antagonism’s constellation of findings: tachycardia, flushed dry skin, dry mouth, ileus, and urinary retention.
The full range of clinical manifestations associated with anticholinergic overdose may be only partly explained by muscarinic receptor blockade. Many of these anticholinergic agents possess activity at other cell membrane receptors, and toxicity after overdose can be a mixture of pharmacologic mechanisms. For example, the clinical findings associated with cyclic antidepressant overdose are only partly characterized by anticholinergic effects that vary considerably among different cyclic antidepressants. The most life­threatening complications of cyclic antidepressant overdose do not result from anticholinergic effects, but are rather a result of myocardial sodium channel–blocking effects and wide­complex tachydysrhythmias.
IV injection of antihistamines, particularly of those (e.g., diphenhydramine) affecting H histamine receptor antagonists, seems to cause euphoria in
 some patients; this translates to abuse potential. The effect may be attributed to the drug’s increasing dopamine levels in the brain’s nucleus
 accumbens area (which stimulates the reward and motivation system).
CLINICAL FEATURES
The classic features of the anticholinergic toxidrome can be stated as:
Dry as a bone
Red as a beet
Hot as a hare
Blind as a bat
Mad as a hatter
Stuffed as a pipe
Dry skin (especially dry axillae) and dry mucous membranes (e.g., dry mouth) are the typical peripheral clinical manifestations, the result of impaired sweat gland and salivary gland secretions, respectively. The skin may be warm and flushed (red) from cutaneous vasodilatation. Other typical peripheral features of muscarinic blockade include hypoactive or absent bowel sounds secondary to decreased peristalsis and GI motility. A palpable bladder or enlargement on bedside US secondary to urinary retention may be seen.
Sinus tachycardia is usually present. More malignant dysrhythmias are less common. Ingestions of large amounts of diphenhydramine have been
,25 associated with wide­complex tachydysrhythmias from a sodium channel–blocking effect (not from an anticholinergic effect). Diphenhydramine
,27 overdose has been reported to cause QT­interval prolongation. Dilated pupils are often a delayed clinical finding (12 to  hours) that may not be observed despite the presence of other anticholinergic signs.
The delirium of the central anticholinergic syndrome is characterized by restlessness, irritability, disorientation, confusion, agitation, auditory and visual hallucinations, and incoherent speech. The anticholinergic toxic patient has great difficulty interacting appropriately with environmental stimuli.
Lilliputian (“little people”) hallucinations have been described in this setting. Repetitive picking at the bed clothes or imaginary objects is also characteristic. A characteristic feature of anticholinergic delirium is dysarthria, manifested by a staccato speech pattern and difficult­to­comprehend speech. This may be exacerbated by severe dysphasia from decreased mucous secretion. High­pitched cries may sometimes be heard. Patients may also exhibit jerking movements of the extremities and seizures.
Although this delirium is usually accompanied by the peripheral manifestations discussed earlier, clinical presentations vary. Tachycardia without delirium or delirium without tachycardia may occur. “Agitated depression” can occur from both central excitation and depression. Depression is usually associated with higher doses; features include lethargy, somnolence, and coma. Overdose with olanzapine, an atypical antipsychotic with significant anticholinergic properties, produces unpredictable mental status fluctuations that can range from somnolence to agitation lasting for
 hours.
Agitation­induced hyperthermia is a worrisome complication of anticholinergic toxicity, and its development may be significantly potentiated by decreased sweating, movement, and the inability to dissipate heat. A markedly elevated body temperature may lead to multisystem organ dysfunction and rhabdomyolysis, resulting in coagulopathy as well as liver, kidney, and brain injury. Fatalities associated with anticholinergic overdose are characterized by severe agitation, status epilepticus, hyperthermia, wide­complex tachydysrhythmias (usually from sodium channel–blocker effect),
 and cardiovascular collapse.
The risk of toxicity for most anticholinergic agents is typically dose related. For example, severity of diphenhydramine overdose correlates with the
  amount ingested, with moderate symptoms occurring after ingestion of 300 milligrams and .5 milligrams/kg in children, and severe symptoms
 seen only after ingestions of 1000 milligrams or more in adults.
DIAGNOSIS
DRUG SCREENING
In patients with altered mental status, obtain routine laboratory evaluation, including measurement of electrolytes, glucose, creatine kinase, and pulse oximetry. In most cases of isolated anticholinergic toxicity, these tests should be normal. Limited urine drugs­of­abuse screening generally does not detect anticholinergic agents, although some rapid screens may produce positive results for cyclic antidepressants due to the structural similarities of some anticholinergic compounds, particularly diphenhydramine and hydroxyzine. Comprehensive urine drug screens, usually performed by thin layer chromatography or mass spectrometry, may detect most antihistamines and phenothiazines, although such testing does not usually detect plant alkaloids, scopolamine, or atropine and, in general, is cost prohibitive and insufficiently timely to assist in care. A positive drug screen for an anticholinergic agent only indicates exposure, such as a therapeutic dose, and does not necessarily imply an overdose or supratherapeutic ingestion.
DIFFERENTIAL DIAGNOSIS
The differential diagnosis of anticholinergic toxicity includes life­threatening presentations such as viral encephalitis, Reye’s syndrome, head trauma, alcohol and sedative­hypnotic withdrawal, postictal state, other intoxications, neuroleptic malignant syndrome, and acute psychotic disorders. The difference between anticholinergic toxicity and sympathomimetic toxicity (e.g., cocaine toxicity, delirium tremens) can be subtle, because patients with either may develop tachycardia, mydriasis, and delirium. The presence of red dry skin and the absence of bowel sounds suggest anticholinergic
 poisoning. At times, patients presenting with acute psychotic disorders may have an abnormal mental status, suggesting anticholinergic toxicity, but true delirium and attention deficits are much more characteristic of the latter condition. Other CNS disorders, such as viral encephalitis, may also affect
 cholinergic outflow and produce similar anticholinergic clinical signs not related to a toxic exposure.
TREATMENT
Treatment of anticholinergic toxicity primarily includes observation, monitoring, and supportive care (Table 202­4). Temperature monitoring and treatment of hyperthermia are essential. GI decontamination with activated charcoal may be warranted to decrease absorption if the ingestion occurred within  hour of presentation. Although the benefit of activated charcoal is equivocal after  hour from ingestion, the decreased gut motility
34­36 associated with anticholinergic ingestions may warrant charcoal administration beyond this 1­hour window. Multidose activated charcoal is not
 recommended in patients with impaired GI motility, such as occurs with anticholinergic toxicity. Ipecac syrup, which has no indication in any
,38 overdose patient, is contraindicated in anticholinergic toxicity. A rare case of pharmacobezoar has been reported with diphenhydramine
 overdose; this should be a consideration if the toxidrome continues longer than expected.
TABLE 202­4
Treatment of Anticholinergic Toxicity
Action Agent Comments
GI decontamination Activated May be more effective due to the decreased GI motility charcoal
Sedation Benzodiazepines Decreases the risk of hyperthermia, rhabdomyolysis, and traumatic injuries
Wide­complex Sodium Arrhythmia due to sodium channel blockade; avoid class IA antiarrhythmics (procainamide) tachyarrhythmias bicarbonate
Cholinesterase inhibition Physostigmine Use for cases of severe agitation or delirium; avoid when cardiac conduction abnormalities are present
(see “Treatment” section)
The major therapeutic challenge in the treatment of moderate to severe anticholinergic poisoning involves obtaining adequate control of the agitated individual. Inadequate sedation may lead to worsening or prolonged hyperthermia, rhabdomyolysis, and traumatic injury.
Although physical restraints may be required to gain initial control, pharmacologic sedation is strongly recommended, because prolonged use of physical restraints in the struggling and agitated patient may lead to further complications.
Pharmacologic sedation should begin with IV administration of a benzodiazepine, such as lorazepam or diazepam. Benzodiazepines are not a specific antidote, and some patients may be refractory to large doses. Phenothiazines should be avoided because of their own anticholinergic effects. In severe cases of agitation when adequate sedation cannot be achieved without impairing respiration, mechanical ventilation and deep sedation may be necessary.
,25
IV sodium bicarbonate should be used to treat wide­complex tachydysrhythmias. Class IA antiarrhythmic agents should be avoided because of their own sodium channel blockade properties.
Physostigmine is a reversible acetylcholinesterase inhibitor (mechanistically related to the carbamate insecticides) that crosses the blood–brain barrier due to its lipophilic tertiary ammonium properties. Acetylcholinesterase inhibition results in acetylcholine accumulation that reverses both
,41 central and peripheral anticholinergic effects. Using physostigmine to reverse anticholinergic toxicity is controversial.
The major adverse effects of physostigmine—profound bradycardia and seizures—were historically touted as common, but evidence for this belief is
 lacking. Importantly, the risk of these adverse effects appears greater in patients without anticholinergic toxicity, so accurate
,42 diagnosis of anticholinergic toxicity is important before administering physostigmine.
 44­46
Evidence for benefits of physostigmine in anticholinergic toxicity is mixed. Retrospective analysis of  patients and case reports found that physostigmine was significantly better in controlling agitation and reversing delirium compared with benzodiazepines and was associated with fewer complications and a shorter recovery time. There was no difference in adverse effects between the two groups. Conversely, a different case series did not find that physostigmine use reduced complications or shortened length of stay in  patients with severe agitation and delirium after Jimson weed
 ingestion. However, no adverse effects or complications were observed from physostigmine use.
Physostigmine can be used in cases of severe agitation and delirium from pure anticholinergic toxicity, especially in cases
 necessitating physical restraints and manifesting resistance to benzodiazepines. The adult dose of physostigmine is .5 to  milligrams
(pediatric dose is .02 milligram/kg with a maximum dose of  milligrams) by slow IV administration over  minutes. When physostigmine is effective, a significant decrease in agitation should be apparent within  to  minutes. Provide continuous cardiac monitoring before and during administration of physostigmine to assess for potential bradycardia. Monitor the patient for signs of cholinergic excess, such as diarrhea, urination, miosis, bradycardia, bronchospasm, bronchorrhea, emesis, lacrimation, and salivation. In cases of uncertain anticholinergic poisoning, a diagnostic challenge with physostigmine is not recommended because of the small but increased risk of adverse effects in patients without
,42 anticholinergic toxicity.
Physostigmine may be repeated in the same dose if required. Patients who remain asymptomatic for more than  hours after the first dose of
 physostigmine will not require repeat physostigmine dosing. Contraindications to physostigmine use include asthma, nonpharmacologically mediated intestinal or bladder obstruction, cardiac conduction disturbances, and suspected concomitant sodium channel antagonist poisoning.
DISPOSITION AND FOLLOW­UP
Patients with mild symptoms of anticholinergic toxicity that resolve after  hours of ED observation may be medically cleared. Because the duration of action of physostigmine is generally shorter than the duration of action of many anticholinergic agents, the reversal effect may dissipate, resulting in recurrent toxicity.
Patients with more than mild symptoms, as well as those who have received physostigmine, require hospital observation until symptoms resolve or approximately  hours after the last dose of physostigmine.


