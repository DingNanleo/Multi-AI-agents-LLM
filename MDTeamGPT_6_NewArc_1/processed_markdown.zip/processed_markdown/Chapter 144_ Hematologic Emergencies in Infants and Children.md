## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 144: Hematologic Emergencies in Infants and Children
Jessica A. Bailey; Megan Mickley
INTRODUCTION
Bleeding in a child can be a diagnostic dilemma, because the causes range from benign to serious. Children with mild bleeding disorders may not experience an episode of bleeding until faced with a hemostatic challenge, such as an interventional procedure or trauma. On the other hand, children without an underlying bleeding disorder commonly present with complaints of bruising and bleeding such as epistaxis or menorrhagia. Red flags for a potential bleeding disorder include bleeding or bruising out of proportion to the injury, prolonged and/or recurrent bleeding
(particularly with unknown cause or after a small injury or procedure), spontaneous bruising or bleeding, uncommon sites of bleeding
(joints, GI) or bruising (proximal extremities, trunk), and a family history of a bleeding disorder. Consider nonaccidental trauma in the child with unusual bruising patterns (see Chapter 150, “Child Abuse and Neglect”). Figure 144­1 provides a basic approach for the initial ED assessment of a child with bleeding. The most common bleeding disorders presenting in childhood are discussed below.
FIGURE 144­1. Algorithm for the approach to a child with undiagnosed bleeding. aPTT = activated partial thromboplastin time; PT = prothrombin time; vWD = von
Willebrand’s disease.
HEMOPHILIA

AC hdaetpatieler d1 4d4is:c Husesmioant oolfo hgeicm Eopmheilrigae isn cpireosv iidne Idn fiann Ctsh aapntde rC 2h35ild, “reHne,m Joepshsiicliaas A a.n Bda violeny W; Milleegbarann Md’isc Dklieseyase.” Table 144­1 provides a summarPya ogfe t h1o /s 1e3
. Terms of Use * Privacy Policy * Notice * Accessibility bleeding disorders, which are also reviewed below.
TABLE 144­1
Coagulation Disorders
Disease Inheritance Defect Incidence Distribution Subtypes Inhibitors Diagnostics Symptoms Treatment
Hemophilia A
Factor X­linked Defect in 1:5000 live Males Severe: <1% 30% of Platelet Intracranial Factor VIII
VIII recessive factor VIII male factor VIII those with count, PT, hemorrhage replacement deficiency procoagulant births activity severe bleeding Hemarthroses Desmopressin activity Frequency: subtype time—WNL (large joints) (in pretested
Quantitative 50%–70% have PTT— Bleeding after mild and Bleeding inhibitors prolonged neonatal hemophiliacs) qualitative spontaneously Factor VIII circumcision Activated into joints or assay—low Muscle and soft prothrombin soft tissue or absent tissue complex
Moderate: 1%– amount hematomas concentrates
5% factor VIII Retroperitoneal (FEIBA®) activity bleeds Recombinant
Frequency: Epistaxis and activated factor
10% mucosal VIIa
Bleeding with bleeding from (NovoSeven®) minor trauma oral trauma Cryoprecipitate* or surgery Pharyngeal
Mild: >5% bleeding factor VIII (posttussive activity and after
Frequency: emesis)
30%–40% Hematochezia
Bleeding with and melena major trauma from GI or surgery bleeding
Hematuria
Menorrhagia
Hemophilia B (Christmas disease)
Factor IX X­linked Defect in 1:30,000 Males Severe: <1% 1%–3% Platelet Symptoms Factor IX deficiency recessive factor IX live male factor IX with count, PT, same as for replacement procoagulant births activity inhibitors bleeding factor VIII Activated activity Bleeding time—WNL deficiency prothrombin
Quantitative spontaneously PTT— complex and into joints or prolonged concentrates qualitative soft tissue Factor IX (FEIBA®)
Moderate: <1% assay—low Recombinant factor IX or absent activated factor activity amount VIIa
Bleeding with (NovoSeven®) minor trauma Fresh frozen or surgery plasma* Mild: >5% factor IX activity
Bleeding with major trauma or surgery von Willebrand’s disease vWF Autosomal Defect in vWF 1%–2% of Males = Type  von Inhibitors PT—WNL Types  and  vWF deficiency dominant Quantitative general females Willebrand’s rare PTT— (mild): replacement
(type  and and population (classic) prolonged or Mucocutaneous Desmopressin subtypes of qualitative disease: WNL bleeding for type  and
2); Variable Mild Factor VIII— Recurrent or some type  autosomal factor VIII quantitative borderline or prolonged Antifibrinolytic recessive activity deficiency of decreased epistaxis agents (ε­
(subtypes of vWF vWF activity, Bleeding after aminocaproic
 and type 3) Most common antigen and surgery or acid) form (80%) multimer trauma, e.g.,
Type  von evaluation dental
Willebrand’s procedures disease: GI bleeding
Variable Menorrhagia qualitative Type 3: abnormalities Spontaneous of vWF hemarthroses
Type  von Muscle
Willebrand’s hematomas disease: Severe bleeding
Severe quantitative deficiency of vWF
Rare (1–3 per million)
Abbreviations: PT = prothrombin time; PTT = partial thromboplastin time; vWF = von Willebrand factor; WNL = within normal limits.
*If concentrated factor products unavailable.
EPIDEMIOLOGY
Factor VIII (hemophilia A) and factor IX (hemophilia B) deficiencies are X­linked recessive hematologic disorders and predominantly affect males. One third
 of cases arise from spontaneous mutations; thus, patients may have a negative family history of bleeding disorders. These disorders are clinically indistinguishable but differ in their treatment.
CLINICAL FEATURES
The severity of disease, and thus risk of bleeding, is defined by the factor activity as a percentage of normal (which is defined as 50% to 100%). Patients with mild disease may never spontaneously bleed but have increased bleeding with trauma (Figure 144­2), whereas individuals with severe disease have spontaneous bleeding into the joints (hemarthroses; Figure 144­3) and soft tissue (hematomas) and may develop life­threatening hemorrhage.
FIGURE 144­2. Hemophilia A. Extensive bruising in a child with factor VIII deficiency. [Photo contributed by Ralph A. Gruppo, MD. Reproduced with permission from Knoop
K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, Inc., New York.]
FIGURE 144­3. Hemarthrosis. A child with hemophilia A who presented with bilateral knee hemarthroses. [Reproduced with permission from Shah BR, Lucchesi M: Atlas of Pediatric Emergency Medicine, © 2006, McGraw­Hill, Inc., New York.]
DIAGNOSIS
Most children with hemophilia have already been identified before an ED visit because of a positive family history of bleeding disorder (prenatal testing is possible through chorionic villus sampling or amniocentesis), intracranial hemorrhage, significant hematoma after birth trauma, or prolonged and excessive bleeding after circumcision. However, some cases, especially mild hemophilia, may escape detection until the child is several years old, when symptoms are provoked by an injury or a small interventional procedure. The event precipitating initial presentation could be as minor as a trip and fall in a newly ambulatory toddler, a common age of diagnosis due to the increased activity level. Suspect hemophilia in a child who presents with spontaneous bleeding, particularly in unusual locations (e.g., joints, areas not usually injured like the proximal extremities) or with bleeding that is out of proportion to the injury. Specific bleeding manifestations are listed in Tables 144­1 and 235­2. Hemarthroses are the
 hallmark of hemophilia, accounting for 80% of bleeding episodes in severe hemophiliacs. Older children and adolescents describe a burning or tingling
 sensation preceding signs of hemarthrosis development.
Differential diagnosis includes the spectrum of bleeding disorders. The screening test for hemophilia is an activated PTT, which will be prolonged in most patients. Platelet count, bleeding time, and prothrombin time will be normal. Quantitative factor levels confirm a diagnosis of hemophilia. Mixing studies identify whether factor inhibitors are present.
TREATMENT
The overall treatment goal is to increase levels of the deficient factor. Treatment of hemophilia depends on the specific factor deficiency, the baseline severity of the disease, and the nature and extent of the injury. In severe hemophiliacs, regular scheduled prophylactic administration of clotting factor
 concentrate is a well­established practice and significantly reduces the incidence of bleeding.
Even in the absence of physical findings, promptly order and initiate factor replacement for children with a presenting ED history that
 raises concern about high­risk sites for bleeding. A reliable adage in hemophilia is “When in doubt, treat,” preferably within  hours. In patients with known hemophilia, coagulation studies are not necessary upon presentation for a new bleeding episode. However, a level of factor VIII or IX or the presence of a factor inhibitor may be requested by the hematologist to assist in the patient’s evaluation and treatment.
The dose of factor replacement and goal level of factor percentage are based on the clinical scenario. A good rule of thumb is to aim for a desired factor level of approximately 40% to 50% following replacement. For high­risk and/or life­threatening bleeds (CNS, retropharyngeal, ophthalmic, iliopsoas/retroperitoneal, intra­abdominal, intrathoracic, and GI), that goal doubles to 80% to 100%. Specific factor replacement products are listed in Table 235­3, and factor replacement guidelines are listed in Table 235­4. Recombinant and human plasma­derived factors are available, and efforts should be made to use the patient’s home product. Treatment regimens will differ for factor VIII and factor IX products because they have different dosing requirements and different half­lives. In most patients,  unit/kg of factor VIII will increase the clotting activity of treated
 plasma by 2%;  unit/kg of factor IX will raise factor activity level by only 1%. Given the cost of these products, an effort should be made to use the whole unit dose. In the rare case in which factor replacement products are not immediately available, administer cryoprecipitate for factor VIII deficiency or fresh frozen plasma for factor IX deficiency.
Patients with mild hemophilia A who have been pretested to document a response may be treated with desmopressin instead of factor replacement.
Desmopressin releases stored factor VIII from the subendothelial compartment. The use of desmopressin is particularly advantageous for pediatric
 patients, due to its lower cost, availability in intranasal form, and the elimination of viral transmission risk as compared to frequent factor replacement.
See Table 235­5 for desmopressin dosing. Of note, desmopressin is an antidiuretic; patients must be monitored for water retention and hyponatremia.
For hemophilia patients requiring surgery and scheduled to go to the operating room from the ED, factor replacement must be given beforehand to optimize factor levels. Adjunctive management for bleeding in joints and muscles should also include rest, ice, compression, elevation, and splinting.
Minimal oral bleeding (e.g., after dental procedures) may be treated with topical thrombin or antifibrinolytic drugs such as tranexamic acid or
 aminocaproic acid. Minimal anterior epistaxis may respond to conservative therapies, such as direct pressure and phenylephrine, without factor replacement. Patients, usually with severe hemophilia A, who have factor inhibitors (antibodies) may require very high doses of standard factor products to overwhelm the inhibitors present. However, some patients will need to be treated with products that bypass factor VIII and factor IX in the clotting cascade (see Table 235­6). These include activated prothrombin complex concentrates (FEIBA®) and recombinant activated factor VIIa (NovoSeven®).
COMPLICATIONS
Hemarthrosis is the most common hemorrhagic complication of hemophilia and most commonly affects the knee, ankle, elbow, and shoulder. Minor, often unrecognized, trauma may precipitate spontaneous intra­articular hemorrhage with pain, swelling, and decreased range of motion. Unfortunately, the presence of blood in the joint precipitates a cascade of inflammation and synovial neovascularization. This increases vulnerability to bleeding and
 leads to synovium fibrosis, irreversible cartilage destruction, and hemophilic arthropathy (Figure 144­4). Aggressive measures must be taken to limit the number and extent of these events.
FIGURE 144­4. Hemophilic arthropathy. Note the extensive degenerative changes. [Image used with permission of J. Fitzpatrick, MD, Cook County Hospital. Reproduced with permission from Simon RR, Koenigsknecht SJ: Emergency Orthopedics: The Extremities, 5th ed. Copyright © 2007 by The McGraw­Hill Companies, Inc.
All rights reserved.]

Spontaneous muscle hematomas account for 10% to 25% of hemophilia bleeds and can also present with severe pain and limited range of motion.
Complications from ongoing bleeding include compartment syndrome and nerve compression. Particularly concerning are iliopsoas bleeds, which may mimic acute appendicitis or hip pathology, with radiation of pain to the back, groin, and hip. The hip is often held in flexion. Such bleeds can be particularly uncomfortable if there is compression of the femoral nerve or sacral plexus. They require aggressive factor replacement, given the potential for blood accumulation in the retroperitoneal space.

The leading cause of death in children with hemophilia is intracranial hemorrhage, which can be spontaneous or occur after even mild head trauma.
Because bleeding can progress slowly, patients may not yet have clinical manifestations of hemorrhage upon presentation. Maintain a high index of suspicion. Unless directed otherwise by the hematology consultant, treat all reports of head injuries, neurologic symptoms, or visible
 head trauma presumptively with 100% factor correction. Obtain immediate head CT imaging to identify intracranial hemorrhage.
Bleeding from the GI tract is rarely severe unless a specific anatomic lesion is present. Gross hematuria may require factor replacement. Obtain urinalysis to rule out infection and renal ultrasonography to identify a serious anatomic lesion. Other uncommon but critical lesions that require aggressive factor replacement (100%) and specialist intervention to avoid massive hemorrhage or permanent injury include tonsillar bleeding, solid organ bleeding from blunt abdominal or thoracic trauma, spinal hematoma, and intraocular hemorrhage.
DISPOSITION
Consult a hematologist for all children with hemophilia and active bleeding prior to disposition. Pediatric hemophilia patients and their families are often comfortable participating in that decision, because they may receive some treatments at home. Children with mild bleeding episodes may be discharged home with careful instructions and a concrete hematology follow­up appointment. Patients with moderate or severe bleeding and those with high­risk bleeds require hospital admission, because close monitoring and documentation of adequate response to factor replacement are necessary and repeat doses are frequently required.
VON WILLEBRAND’S DISEASE
A detailed discussion of von Willebrand’s disease (vWD) is provided in Chapter 235; vWD classification and basic treatment are outlined in Table 235­7. CLINICAL FEATURES vWD type  is usually associated with mild mucocutaneous bleeding, including easy bruising, recurrent or prolonged epistaxis, and prolonged postprocedural bleeding (e.g., gingival bleeding after dental work). Menorrhagia may be the sole presenting complaint in young women. In type  vWD, clinical features can closely resemble those of hemophilia, because significantly reduced amounts of von Willebrand factor (vWF) allow increased clearance of factor VIII. In general, the severity of bleeding correlates with the degree of reduction of factor VIII.
DIAGNOSIS
A high index of suspicion is necessary for the diagnosis of vWD because clinical features are mild in most patients, and mucocutaneous bleeding (e.g., bruising, epistaxis) is common in childhood. History should include frequency, duration, severity, and location of bleeding, as well as concurrent medications. Note any family history of “easy” bleeding. ED screening labs for vWD usually reveal a normal CBC and prothrombin time, a normal or prolonged activated PTT (if factor VIII is sufficiently reduced), and low vWF levels. More specific testing includes vWF antigen, vWF ristocetin cofactor
,7 activity, vWF multimers, and factor VIII level. Bleeding time, once the gold standard for vWD diagnosis, has difficulties with reproducibility and poor
,8  sensitivity and specificity. Levels of vWF can be affected by a variety of normal (e.g., stress) and medical (e.g., active bleeding) conditions. Repeat testing should be done if clinical suspicion is high.
TREATMENT
Treatment of active bleeding in a known vWD patient consists initially of localized measures to achieve hemostasis, including direct pressure on bleeding sites, packing dental extraction sites and nasal passages, and the application of topical hemostatic agents. Antifibrinolytic agents can be used to treat oral trauma. Oral contraceptive pills or an intrauterine device helps to control menorrhagia. Desmopressin (see earlier section on hemophilia treatment), which releases stored vWF from the endothelium, is the preferred initial treatment of bleeding in patients with type  vWD. It has no effect in those with
 type  vWD and variable effect in those with type . Pay attention to the fluid status of patients receiving desmopressin, because dilutional hyponatremia is a rare side effect due to its antidiuretic properties. Children with type  or  vWD or type  with inadequate response to desmopressin usually require treatment with purified plasma­derived vWF replacement. Other emerging therapies, such as recombinant vWF concentrate,
 have been approved for adults but are not yet routinely used in children. In emergencies only, administer cryoprecipitate if no vWF:factor VIII replacement is available. Cryoprecipitate is not recommended as standard therapy because it has a low concentration of vWF and carries infectious risks because it
 does not undergo viral inactivation. Advise all patients with vWD to avoid medications with known antiplatelet effects (e.g., aspirin, NSAIDs).
VITAMIN K DEFICIENCY BLEEDING
Vitamin K deficiency bleeding, formerly known as hemorrhagic disease of the newborn, is a neonatal bleeding coagulopathy resulting from vitamin K deficiency. Although the American Academy of Pediatrics has recommended intramuscular vitamin K prophylaxis as standard of care in newborns since

1961, there has been an increasing rate of parental refusal in the past decade. Risk factors include breastfed infants (because breast milk contains less vitamin K content than cow’s milk formulas), infants with malabsorption or hepatobiliary disorders, and maternal medications (e.g., phenytoin, isoniazid).

In classic cases, bleeding occurs  to  days after birth; however, there are reports of cases <24 hours after birth and up to  weeks after birth. Bleeding can present as mild oozing from the umbilicus or circumcision site or as life­threatening pulmonary and intracranial hemorrhage. Although vitamin K
 deficiency bleeding is rare in developed countries, 30% to 60% of reported cases are associated with intracranial hemorrhage. Labs reveal a decreased hematocrit, depending upon the severity and duration of the bleed, and prolonged prothrombin time and activated PTT. Treatment is the immediate administration of  milligram of SC, IM, or IV vitamin K (phytonadione). The IM route places the patient at risk for a significant hematoma, whereas the IV route carries a greater risk of an anaphylactoid reaction. Given the risk of intracranial bleeding, do not wait for laboratory results if your clinical suspicion is high. Life­threatening hemorrhage may require a transfusion of  to  mL/kg of fresh frozen plasma to increase serum procoagulant levels.
ANEMIA
Children may develop profoundly low hemoglobin levels (e.g.,  to  grams/dL) before coming to medical attention. Patients may be asymptomatic or present with symptoms ranging from pallor and decreased activity to congestive heart failure in an infant. This section reviews the ED diagnosis and management of some important types of anemia in children. The management of anemia due to hemorrhage is discussed in Chapters , “Approach to
Traumatic Shock” and 110, “Pediatric Trauma.” Hemoglobin levels vary with a child’s age, peaking at approximately  to  grams/dL in the full­term newborn period and at approximately  grams/dL (females) and approximately  grams/dL (males) in the teenage years. The dramatic increase in oxygen availability after birth briefly shuts down erythropoietin production, resulting in a physiologic nadir, or “physiologic anemia,” of about  to  grams/dL at approximately  months of age. Hemoglobin levels then rise steadily throughout childhood. After the first year of life, the normal reticulocyte
 count is 1% to 2% of circulating red blood cells, assuming normal red blood cell physiology. Refer to normal hemoglobin and red blood cell values when evaluating pediatric anemia.
ED TREATMENT OF SEVERE ANEMIA
Children with anemia unrelated to acute blood loss rarely require blood transfusion in the ED. Some children with very low hemoglobin levels and a presentation highly consistent with iron deficiency anemia, for example, may be managed as outpatients if close follow­up is ensured.
Exceptions include hemolytic anemias, bone marrow failure, hemodynamic instability, congestive heart failure, or other symptoms due to severe anemia.
Obtain a hematology consultation to assist with transfusion management.
The decision to transfuse must take into account whether the child has a chronic or acute anemia; those with chronic anemias are at risk for volume overload. For children with hemoglobin ≤8 grams/dL and signs of hemodynamic compromise, active bleeding, or consumptive coagulopathy, consider an initial transfusion of packed red blood cells in  to  mL/kg aliquots. With extremely low hemoglobin levels (<5 grams/dL) due to chronic anemia, the transfusion should be small (2 to  mL/kg packed red blood cells) and slow (1 mL/kg/h), with continuous monitoring and frequent reassessment. In cases of volume overload, diuretics can be considered, or an exchange transfusion can be performed in severe cases.
CLASSIFICATION OF ANEMIA
As with adults, a differential diagnosis for anemia in childhood can be broken down into microcytic, normocytic, and macrocytic categories (see Figures
231­2, 231­3, and 231­4). The pathologic causes can be classified as those that decrease red blood cell production and those that increase red blood cell destruction, in addition to blood loss and iatrogenic dilutional anemia from fluid administration. To help with those differentiations, a peripheral smear and reticulocyte count should always be sent with the CBC. A more detailed differential diagnosis of anemia is provided in Table 144­2. Selected common pediatric anemias are discussed below. For a more thorough discussion of specific etiologies, see Chapters 231, “Anemia and Polycythemia”; 233,
“Acquired Bleeding Disorders”; 236, “Sickle Cell Disease and Hereditary Hemolytic Anemias”; and 237, “Acquired Hemolytic Anemia.” Hemolytic­uremic syndrome is discussed in detail in Chapter 137, “Renal Emergencies in Children.”
TABLE 144­2
Classification of Anemia
Decreased red blood cell (RBC) production
Impaired RBC proliferation
Parvovirus B19 infection
Aplastic anemia (congenital or acquired)
Isolated pure red cell aplasia (Diamond­Blackfan syndrome)
Transient erythroblastopenia of childhood (TEC)
Bone marrow infiltration (e.g., leukemia)
Impaired erythropoietin production
Anemia of chronic disease
Chronic renal disease
Malnutrition
Abnormal hemoglobin synthesis
Lead poisoning
Iron deficiency
Thalassemia
Vitamin B or folate deficiency

Sideroblastic anemia
Increased RBC destruction
Hemoglobinopathy
Thalassemia
Sickle cell disease
Membrane defect (e.g., hereditary spherocytosis)
Extrinsic disease
Autoimmune hemolytic anemia
Glucose­6­dehydrogenase deficiency
Disseminated intravascular coagulopathy
Microangiopathic process (e.g., hemolytic­uremic syndrome)
Paroxysmal nocturnal hemoglobinuria
IRON DEFICIENCY ANEMIA
Iron deficiency anemia is the leading cause of anemia in childhood and can be profound. Healthy term infants have adequate iron storage for the first  to
 months of life. After this, iron stores are depleted. Decreasing prevalence of iron deficiency anemia may be attributable, in part, to the American Academy of Pediatrics recommendations regarding iron supplementation in breastfed infants, iron­fortified formulas and infant foods, delayed use of cow’s milk
 until after  year of age, and universal hemoglobin screening at  year of age. However, excessive whole­milk feeding and poor dietary intake of iron make iron deficiency anemia a diagnosis common in the toddler years. Milk proteins may also cause a low­grade colitis with occult GI bleeding.

Nutritional iron deficiency anemia is uncommon in children >3 to  years of age and is suspicious for occult bleeding. Iron deficiency anemia is diagnosed based on clinical suspicion, with labs demonstrating a hypochromic microcytic anemia and low reticulocyte count. Iron studies help to confirm the diagnosis. For hemodynamically stable children, treatment is outpatient oral ferrous sulfate supplementation and primary care follow­up.
For children with severe anemia and/or evidence of hemodynamic compromise, inpatient care may be necessary, and hematology should be consulted regarding transfusion guidelines.
PARVOVIRUS B19 INFECTION
Parvovirus, a common virus in childhood, replicates in erythroid progenitor cells and can cause transient red cell aplasia. In the normal host, parvovirus infection may go unrecognized or be identified by its characteristic reticular rash and slapped cheek appearance (erythema infectiosum, or fifth disease); see “Erythema Infectiosum” in Chapter 142, “Rashes in Infants and Children.” The red cell aplasia is so short lived that concomitant anemia is usually not discovered. However, in patients with hemoglobinopathy or hemolytic anemias such as sickle cell disease, in whom the life span of a red cell is decreased, even brief periods of red cell aplasia may result in severe anemia and aplastic crisis, often requiring transfusion.
TRANSIENT ERYTHROBLASTOPENIA OF CHILDHOOD
Transient erythroblastopenia of childhood is a gradually developing, self­resolving normocytic anemia caused by a temporary decrease in red blood cell precursors. The cause is unknown. It is most common in the toddlers and preschool age groups, but can be diagnosed in children  months to  years of
 age. Other cell lines should not be affected, and iron studies are normal. Bone marrow recovery usually occurs in  to  months, and transfusions are rarely needed.
AUTOIMMUNE HEMOLYTIC ANEMIA
Autoimmune hemolytic anemia is caused by the production of autoantibodies to red blood cells. In primary autoimmune hemolytic anemia (most common in infants and young children), there is no evidence of an underlying disorder; the disease may manifest after a simple viral illness. Older children are more likely to experience autoimmune hemolytic anemia secondary to an underlying systemic illness, such as malignancy, human immunodeficiency virus, or an autoimmune disorder. The clinical presentation may be abrupt and the anemia severe. White cells and platelets are unaffected, and reticulocytes are increased unless the hemolysis is sudden and recent. Labs reveal spherocytes and schistocytes on peripheral blood smear, an indirect hyperbilirubinemia, elevated lactate dehydrogenase, and urine bilirubin metabolites (hemoglobinuria in the absence of red blood cells on urine microscopy). Definitive diagnosis is made by a direct Coombs test. These patients should be hospitalized, and treatment usually begins with corticosteroids. If transfusion is required, the most compatible packed red blood cells are used.
THROMBOCYTOPENIA

A platelet count <150,000/mm should be considered abnormal, and patients with a count <20,000/mm are at high risk for spontaneous bleeding.
Consider thrombocytopenia in patients with petechiae (see Figure 233­1A), easy bruising, epistaxis, gingival bleeding, menorrhagia, hematuria, and GI bleeding. Perform a thorough physical exam to assess for signs of systemic disease. Refer to Figure 144­1 for the general approach. Common medications associated with thrombocytopenia are listed in Table 233­2. IMMUNE THROMBOCYTOPENIA
Immune thrombocytopenia, previously called idiopathic thrombocytopenic purpura, is an autoimmune disorder of antiplatelet antibodies leading to platelet destruction and, in some cases, decreased megakaryocyte platelet production. In the childhood form, over 80% of cases are self­limited and
 resolve within  months, and the incidence of life­threatening bleeds is <0.5%. Immune thrombocytopenia lasting >3 months after diagnosis is termed
 persistent, and the term chronic is now used for children with thrombocytopenia >12 months from the time of diagnosis.
The typical presentation is a preschool­ or school­age, previously healthy child with acute onset of petechiae and bruising, often following a viral illness.

However, 25% of children present with a more insidious course. Additional symptoms and signs are typically absent and, if found, should raise your concern for different diagnoses including hematologic, rheumatologic, oncologic, and infectious diseases. Laboratory studies typically demonstrate isolated thrombocytopenia.
Pharmacologic treatment is controversial and may include corticosteroids, IV immunoglobulin, or anti­Rh(D) immunoglobulin (WinRho®). There are limited data regarding the use of thrombopoietic agents in children. These treatment options are discussed in further detail in Chapter 233. Consult hematology prior to management, activity restrict patients, and avoid all medications with antiplatelet activity. Admission is necessary for any child with a
 platelet count <20,000/mm , with an IV medication regimen, or with spontaneous bleeding, regardless of platelet count.
If steroids are given, there are a variety of dosing regimens, ranging from  milligrams/kg/d of prednisone for  days, to  milligrams/kg of methylprednisolone daily for  days, to  milligrams/m2/d of dexamethasone for  days. Steroids should be started only if the possibility of leukemia or aplastic anemia can be completely excluded on clinical grounds; otherwise, a bone marrow aspirate is necessary to secure the diagnosis before initiating steroid therapy. IV immunoglobulin is superior to steroids in improving platelet numbers for immune
 thrombocytopenia patients. The typical IV immunoglobulin dose is  gram/kg/d. Anti­Rh(D) immunoglobulin is only effective in Rh­positive patients, and patients require admission due to the risk of severe intravascular hemolysis following infusion. The anti­Rh(D) dose is  to  micrograms/kg and can lead to a  to  gram/dL decrease in the hemoglobin concentration. Pretreatment with acetaminophen and diphenhydramine is recommended for both IV immunoglobulin treatments.
On the rare occasion that a child with immune thrombocytopenia develops life­threatening hemorrhage, administer an immediate single­donor platelet transfusion (two to three times normal dose), along with IV methylprednisolone and IV immunoglobulin or anti­Rh(D). The obvious disadvantage of platelet transfusion in immune thrombocytopenia is that platelets will be rapidly consumed by circulating antiplatelet antibodies and repeat transfusions may be necessary.
NEUTROPENIA
Isolated neutropenia in childhood is caused by a heterogeneous group of disorders, ranging from transient and benign to chronic and profound immunodeficiency. Neutropenia in the oncology patient is discussed in Chapter 145, “Oncologic Emergencies in Infants and Children.”

Neutropenia is an absolute neutrophil count <1500/mm . Lower counts can be noted in infants during the first year of life and in individuals of African and
317,18
Middle Eastern descent, but counts should not decrease to <1000/mm . Neutropenia can be stratified into categories that are associated with
 increasing risk of pyogenic infection: mild neutropenia with absolute neutrophil count of 1000 to 1500/mm , moderate neutropenia with absolute
  neutrophil count of 500 to 1000/mm , and severe neutropenia with absolute neutrophil count of <500/mm . Severe neutropenia places the patient at risk for life­threatening infections. Perform a through history and physical examination to identify a nidus of infection. Physical exam should include the oral mucosa, skin, ears, lungs, abdomen, and perineal region. Avoid digital rectal examinations and rectal temperatures, as well as catheter urine sampling, because these maneuvers can result in a portal of infection. Obtain a family history to evaluate for inheritable conditions.
The underlying cause of isolated neutropenia is critical in defining infectious risk. A benign, transient neutropenia is quite common in healthy children and usually arises in the context of a viral infection, resolving within weeks to months. A number of medications, including antiepileptic drugs, antibiotics, antipsychotics, and antithyroid drugs, can cause severe neutropenia and comorbidities, and reports of drug­induced neutropenia quote a .5% to 10%
 mortality rate. Neutropenia due to bone marrow depletion is a known entity in the septic child; therefore, suspect serious bacterial infection in a critically ill child with neutropenia. Typical symptoms and signs of infection (e.g., purulence) may be absent in a neutropenic patient due to reduced inflammatory response.
Chronic (>3 months) neutropenia can be idiopathic, autoimmune, nutritional, or associated with congenital or acquired bone marrow failure. Neonates may develop a self­resolving but significant isoimmune neutropenia from maternal/fetal antigen incompatibility or have placental transfer of antibodies
 from a mother with autoimmune neutropenia. A benign autoimmune neutropenia can also be noted during infancy or early childhood, when repeat
CBCs reveal persistent neutropenia. Children with autoimmune neutropenia tend to have more frequent (rather than more severe) infections, and the neutropenia resolves spontaneously within a few years. Lack of resolution should prompt further evaluation. If severe chronic neutropenia is noted in infancy, severe congenital neutropenia and other inherited marrow failure disorders must be excluded. Distinguishing benign neutropenia from worrisome neutropenia often requires a bone marrow examination to distinguish normal versus abnormal myelopoiesis.
Cyclic neutropenia, inherited as an autosomal dominant disorder, is characterized by episodic severe neutropenia on an approximately 21­day cycle.

Episodes typically last  to  days. Affected children are more likely to experience fevers and non–life­threatening infections such as stomatitis, pharyngitis, cellulitis, otitis media, and lymphadenitis. They are also at high risk for more profound infections.
For the otherwise healthy child with acute, asymptomatic neutropenia identified on routine CBC, close outpatient observation and serial blood counts are usually performed. Consult hematology for children with persistent neutropenia, concern for a heritable cause of neutropenia, neutropenia associated with syndromic features on clinical exam, or serious pyogenic infections associated with neutropenia.
Fever in children with neutropenia, regardless of etiology, must be treated as a medical emergency with broad­spectrum antibiotics.


