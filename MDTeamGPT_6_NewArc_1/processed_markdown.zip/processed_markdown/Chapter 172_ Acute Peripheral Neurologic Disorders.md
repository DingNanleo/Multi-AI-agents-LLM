## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 172: Acute Peripheral Neurologic Disorders
Nachi Gupta; Phillip Andrus
INTRODUCTION
Acute peripheral neurologic lesions are a diverse group of disorders. By definition, they involve injury or disease in sensory and motor fibers outside of the CNS extending to the neuromuscular junction. The peripheral nervous system (PNS) serves sensory, motor, and autonomic functions. Thus, the patient with a peripheral nerve lesion may have deficits in any combination of these functions. Exclude central processes, such as stroke or spinal cord injury, before considering an acute peripheral lesion.
DISTINGUISHING CENTRAL AND PERIPHERAL LESIONS
Use CNS and PNS neuroanatomy principles to distinguish lesions. Peripheral nerves contain varying amounts of motor, sensory, and autonomic fibers and follow well­described paths that make them prone to typical injuries. Thus, peripheral nerve lesions are more likely to be confined to one limb and to present with the involvement of multiple sensory modalities and motor symptoms. A typical example would be a nerve compression syndrome presenting with weakness, numbness, and tingling that developed after the arm was held in an unusual position for a prolonged period. However, weakness and numbness can be seen in both peripheral and central disorders. Hyporeflexia sometimes occurs with acute central lesions, but hyperreflexia and spasticity invariably develop with time. PNS disorders, like CNS diseases, can affect bulbar structures, resulting in diplopia, dysarthria, or dysphagia. Despite the overlap, CNS disorders have other features not seen in peripheral disease. For example, aphasia, apraxia, and vision loss are hallmarks of cortical disease. Most CNS lesions will result in upper motor neuron signs: hyperreflexia, hypertonia (spasticity), and extensor plantar (Babinski) reflexes. Although there can be many similarities between patients with CNS and PNS lesions, the distinctions are clear
(Table 172­1). Lateralization of weakness, hyperreflexia, positive Babinski’s sign, or any other CNS finding requires further investigation for a central rather than peripheral disorder.
TABLE 172­1
Differentiating CNS From Peripheral Nervous System Disorders
CNS Peripheral Nervous System
History Cognitive changes Weakness confined to one limb
Sudden weakness Weakness with associated pain
Nausea, vomiting Posture­ or movement­dependent pain
Headache Weakness after prolonged period in one position
Physical Examination
Reflexes Brisk reflexes (hyperreflexia) Hypoactive reflexes
Babinski’s sign Areflexia
Hoffman’s sign
Motor Asymmetric weakness of ipsilateral upper and lower extremity Symmetric proximal weakness
Facial droop
Slurred speech
Downl oaSdeendso 2ry025­7­1A 6s:y2m3m Pe t rYico suern sIPor yis l o1s3s 6in.1 ip4s2il.a1t5e9ra.l1 u2p7per and lower Reproduction of symptoms with movement (compressive
Chapter 172: Acute Peripheral Neurologic Disorders, Nachi Gupta; Phillip Andrus extremity neuropathy)
. Terms of Use * Privacy Policy * Notice * Accessibility
All sensory modalities involved
Discoordination without weakness Loss of proprioception
Coordination
LOCALIZING PERIPHERAL NERVE LESIONS
Patients with peripheral nerve disorders frequently require diagnostic evaluation unavailable during the initial ED encounter.
HISTORY
The elements required to localize the process will usually include the following: symmetry; proximal versus distal symptoms; sensory, motor, or autonomic involvement; and mono­ versus polyneuropathy. Sensory symptoms may include numbness, tingling, dysesthesias, pain, or ataxia. Motor symptoms manifest as weakness. Autonomic disability may present as orthostasis, bowel or bladder dysfunction, gastroparesis, or sexual dysfunction.
Associated findings will frequently narrow the differential diagnosis or suggest a specific diagnosis. For example, in the setting of a recent viral infection or vaccination, consider Guillain­Barré syndrome. Is there a history of diabetes or subacute trauma? Does the patient with thrush or wasting and undiagnosed immunodeficiency have a human immunodeficiency virus (HIV)­associated neuropathy? Patients with an attached tick may have tick paralysis.
PHYSICAL EXAMINATION
Perform a comprehensive neurologic examination on patients with peripheral nerve disorders, paying particular attention to the specific area and distribution involved. Evaluate for hypotonia, muscle wasting, fasciculations, and hyporeflexia. Is there focal weakness? What is the perception of light touch, vibration, and position sense? If there are sensory deficits, what spinal nerve levels do they involve?
DIAGNOSIS
Many patients with peripheral nerve disorders will require electromyography and nerve conduction velocity studies. Electromyography is used to differentiate primary muscular or neuromuscular junction problems from peripheral nerve disorders. Nerve conduction velocity studies, which measure the speed of conduction by observing the response to nerve stimulation by distally placed electrodes, can differentiate between axonal loss and demyelination. Combined with the history and physical examination, these tests allow the consultant to better localize the lesion and make a firm diagnosis. Lumbar puncture and cerebrospinal fluid analysis are frequently required to confirm the diagnosis in acute or subacute inflammatory and infectious processes. In certain cases, nerve biopsy may be required. In cases where biopsy is considered, MRI can direct the biopsy site to the area of greatest utility.
TREATMENT
Management of PNS disorders depends on the specific diagnosis; however, a few general principles apply. Initiate supportive care for severe, lifethreatening neuromuscular diseases in the ED. Monitor patients with the potential for respiratory failure, aspiration, and cardiac dysrhythmias. For patients at risk for diaphragmatic failure, measure baseline forced vital capacity or negative inspiratory pressure in the ED to assess whether there is an immediate need for respiratory support or admission to an intensive care unit. Admit patients with acute peripheral neurologic conditions if there is potential respiratory or autonomic compromise, or if they present with severe or rapidly progressing weakness. If a peripheral disorder is suspected and the patient does not require admission, arrange for neurologic follow­up within  to  days.
ACUTE PERIPHERAL NEUROPATHIES
GUILLAIN­BARRÉ SYNDROME
Guillain­Barré syndrome is an acute polyneuropathy characterized by immune­mediated peripheral nerve myelin sheath or axon destruction. The prevailing theory is that antibodies directed against myelin sheath and axons of peripheral nerves are formed in response to a preceding viral or bacterial illness. Symptoms are at their worst in  to  weeks, and recovery can vary from weeks to a year.
Clinical Features
Classically, Guillain­Barré syndrome is preceded by a viral illness, followed by ascending symmetric weakness or paralysis and areflexia or hyporeflexia. Paralysis may ascend to the diaphragm, compromising respiratory function and requiring mechanical ventilation in one third of patients. Autonomic dysfunction may be present as well.
The classic Guillain­Barré syndrome is a demyelinating disorder of the peripheral nerves. It is sometimes preceded by a viral or bacterial illness.
Common infectious precipitants include Campylobacter jejuni, Zika virus, Cytomegalovirus, Epstein­Barr virus, or Mycoplasma pneumoniae. The cause is unknown but thought to be associated with antiganglioside antibodies.
There are many variants of Guillain­Barré syndrome. The demyelinating form (lymphocytic infiltration of the myelin sheath of peripheral nerves) is common in the US and the axonal form (motor paralysis with sensory function intact) in Asia. The Miller­Fisher syndrome variant is characterized by ophthalmoplegia, ataxia, and areflexia. Severity of symptoms and duration of illness depend upon the form of the disease.
Diagnosis
The diagnosis is mostly historical, but lumbar puncture and electrodiagnostic information can improve confidence in the diagnosis. Table 172­2 lists the specific diagnostic criteria.
TABLE 172­2
Diagnostic Criteria for Classic Guillain­Barré Syndrome
Required
Progressive weakness of more than one limb
Areflexia
Suggestive
Progression over days to weeks
Recovery beginning 2–4 weeks after cessation of progression
Relative symmetry of symptoms
Mild sensory signs and symptoms
Cranial nerve involvement (Bell’s palsy, dysphagia, dysarthria, ophthalmoplegia)
Autonomic dysfunction (tachycardia, bradycardia, dysrhythmias, wide variations in blood pressure, postural hypotension, urinary retention, constipation, facial flushing, anhydrosis, hypersalivation)
Absence of fever at onset
Cytoalbuminologic dissociation of cerebrospinal fluid (high protein and low white cell count)
Typical findings on electromyogram and nerve conduction studies

Cerebrospinal fluid analysis shows high protein levels (>45 milligrams/dL) and WBC counts typically <10 cells/mm , with predominantly mononuclear
 cells. When there are >100 cells/mm , other considerations include HIV, Lyme disease, syphilis, sarcoidosis, tuberculous or bacterial meningitis, leukemic infiltration, or CNS vasculitis. Electrodiagnostic testing demonstrates demyelination. Nerve biopsy reveals a mononuclear inflammatory infiltrate. If MRI is performed to rule out alternative diagnoses, it will show enhancement of affected nerves.
Treatment
The first step in management is assessment of respiratory function. Airway protection in advance of respiratory compromise decreases the incidence of aspiration and other complications. A well­established monitoring parameter is vital capacity, with normal values ranging from  to  mL/kg. A simple bedside assessment of respiratory status is obtained by trending values reached when the patient counts from  to  with a single breath.
Avoid depolarizing neuromuscular blockers like succinylcholine for intubation in Guillain­Barré syndrome due to the risk of a hyperkalemic response.
,2
Both IV immunoglobulin and plasma exchange shorten the time to recovery. Neither has been shown to be superior to the other, nor are they more efficacious when used together. There are adverse effects seen with both modalities of treatment. IV immunoglobulin has been associated with thromboembolism and aseptic meningitis; plasma exchange is associated with hemodynamic instability and a small increase in the rate of relapse, though full recovery is still more likely. In general, IV immunoglobulin is more widely available and less cumbersome to administer. Corticosteroids are
 of no benefit and may be harmful.
Disposition
Admit patients with acute Guillain­Barré syndrome to a unit where cardiac, respiratory, and neurologic functions can be monitored. Even if a patient does not initially meet the criteria for intubation, intensive care unit admission may still be indicated in order to avoid sudden, unmonitored
 respiratory failure (Table 172­3).
TABLE 172­3
Managing Respiratory Failure in Guillain­Barré Syndrome
Indications for intubation
Vital capacity <15 mL/kg
Declining one breath count
PaO2 <70 mm Hg on room air
Bulbar dysfunction (difficulty with breathing, swallowing, or speech)
Aspiration
Indications for admission to intensive care unit
Patients with  or more of the following findings: inability to stand, inability to lift the head, inability to lift the elbows, insufficient cough, time from symptom onset to hospital admission <7 days, or elevated liver enzymes
Autonomic dysfunction
Bulbar dysfunction
Initial vital capacity <20 mL/kg
Initial negative inspiratory force less than –30 cm of water
Decrease of >30% of vital capacity or negative inspiratory force
Inability to ambulate
Treatment with plasmapheresis
Abbreviation: PaO2 = partial pressure of arterial oxygen.
BELL’S PALSY
Bell’s palsy is the most common cause of unilateral facial paralysis. There are  to  cases per 100,000 population annually, affecting men and women equally. Cranial nerve VII, the facial nerve, supplies motor innervation to the muscles of expression of the face and scalp and the stapedius muscle and taste to the anterior two thirds of the tongue. The cause of Bell’s palsy is not clear. Herpes simplex virus DNA and antigens have been discovered around the facial nerve of affected patients, leading to the suspicion that the herpes simplex virus may be the culprit.
Clinical Features
Idiopathic Bell’s palsy may be preceded by pain around or behind the ear. Onset of facial paralysis is acute, with maximal symptoms in  to  days.
Facial numbness or hyperesthesia can accompany paralysis. Subtle dysfunction of cranial nerves V, VIII, IX, and X may be associated; for example, patients may also complain of decreased taste or hyperacusis due to paralysis of the stapedius muscle. On exam, patients will have facial droop, effacement of wrinkles and forehead burrows, and inability to completely close the eye. Recurrent idiopathic Bell’s palsy occurs in a small number of patients.
Diagnosis
Diagnosis of idiopathic Bell’s palsy is based on the history and physical exam and is a diagnosis of exclusion of other conditions that can cause facial palsy. The most important alternative diagnoses to exclude are ear infections and stroke. Always perform an ear examination to identify otitis media and malignant otitis, and palpate the mastoids for tenderness, because infections of the ear and mastoids can affect the mastoid, tympanic, labyrinthine, or meatal segments of the cranial nerve VII (Figure 172­1).
FIGURE 172­1. Relationships of cranial nerve VII to the inner and middle ear. [Adapted with permission from Lalwani AK (ed): Current Diagnosis & Treatment in
Otolaryngology­Head & Neck Surgery, 3rd ed. New York: McGraw­Hill, Inc.; 2012. Sect XVI Facial Nerve Chapter . Figure 70­3, Part A.]
When a central process causes facial paralysis, the forehead will be spared, as the forehead is supplied by cranial nerve VII arising near the pontomedullary junction, with crossed innervation. Peripheral facial nerve palsies will manifest as weakness throughout the facial nerve distribution, including the forehead. Middle cerebral artery ischemia or stroke consists of hemiparesis, facial plegia sparing the forehead, and sensory loss all contralateral to the affected cortex. Rarely, a brainstem stroke may mimic Bell’s palsy if the stroke affects the area where the facial nerve wraps around the abducens (cranial nerve VI) nucleus. Brainstem stroke findings include peripheral facial nerve palsy and ipsilateral gaze palsy due to ischemia of the abducens nucleus. So, test extraocular muscle function in all patients suspected of having Bell’s palsy. Any patient with facial paralysis sparing the forehead or inability to abduct an eye should undergo neuroimaging to assess for stroke. No imaging or laboratory testing is needed in patients with high suspicion of Bell’s palsy unless further studies are required to exclude alternative diagnoses.
Treatment and Disposition

Treatment with corticosteroids has shown significant benefit in the treatment of Bell’s palsy. Evidence from randomized controlled trials suggests a benefit when giving antiviral medications in combination with steroids over steroid therapy alone. The combination also was associated with reduced sequelae of Bell’s palsy. Importantly, no significant increase in adverse events was noted when adding antivirals. As such, prescribe antivirals in
 conjunction with steroids.
Patients with facial paralysis are at risk for corneal abrasions and keratitis due to eyelid weakness and incomplete eye closure. Patients can use a patch to close the affected eye if there is incomplete closure. Prescribe ocular lubricants, such as an artificial tear replacement, to prevent the eye from drying out. Most patients begin to recover within  weeks, but about 15% will have permanent paralysis. Ensure follow­up within  days with a primary care physician or otolaryngologist.
RAMSEY HUNT SYNDROME (HERPES ZOSTER OTICUS)
Ramsey Hunt syndrome is a herpes zoster infection of the geniculate ganglion. Signs and symptoms include unilateral facial nerve palsy, severe pain, and a vesicular eruption on the face or in the auditory canal. Ramsey Hunt syndrome may be indistinguishable from Bell’s palsy if paralysis precedes the vesicular eruption. Cranial nerve VIII may also be involved with associated vertigo, nausea, and hearing loss. When active herpes zoster is
 suspected, prescribe both steroids and antivirals.
ACUTE NEUROPATHIES OF LYME DISEASE
Lyme disease may cause a broad range of nervous system disease, both peripheral and central, as well as acute and chronic. Consider Lyme disease as the causative agent in patients who have facial palsy with erythema migrans, tick bite, or arthritis. Some patients will have bilateral facial palsy.
Multifocal Lyme polyradiculopathy may occur in the acute phase of Lyme infection. Signs and symptoms include burning and painful neuropathy, plexopathy, and other mononeuropathies.
Diagnosis is based on history of tick bite and a physical examination that uncovers an attached tick or erythema chronicum migrans rash (see Figure
251­18). If cerebrospinal fluid is obtained, it will show the mononuclear pleocytosis typical of Lyme infection. Treatment is with doxycycline 100 milligrams twice daily for  to  days. Facial nerve palsies in Lyme disease represent the secondary stage of illness and require  month of treatment with doxycycline (100 milligrams PO twice a day) or amoxicillin, cefuroxime, ceftriaxone, or azithromycin.
FOCAL MONONEUROPATHIES
Focal mononeuropathies are most likely due to focal nerve compression, although systemic processes may also lead to mononeuropathy. Diabetes is the most common systemic cause of noncompressive focal neuropathy. Focal mononeuropathy can occur at any point of compression along the course of a peripheral nerve, but most commonly occurs along the ulnar, median, radial, lateral femoral cutaneous, and peroneal nerves.
MEDIAN MONONEUROPATHY (CARPAL TUNNEL SYNDROME)
The most common form of any focal mononeuropathy is median mononeuropathy, or carpal tunnel syndrome. Carpal tunnel syndrome results from compression of the median nerve at the wrist where it traverses the carpal tunnel. The boundaries of the carpal tunnel are the carpal bones and the flexor retinaculum. The most common etiology is injury due to repetitive use, but other causes include diabetes mellitus, pregnancy, amyloidosis, obesity, renal failure, rheumatoid arthritis, hypothyroidism, trauma, and edema.
Clinical Features
The classic signs of carpal tunnel syndrome are pain, paresthesias, and numbness in the distribution of the median nerve—the palmar aspect of the thumb, index, middle, and radial aspect of the fourth finger. Patients may report symptoms in the entire hand, but careful examination will reveal preserved sensation in the fifth and ulnar fourth digits. Symptoms are worsened by extension and flexion of the wrist and are worse at night. Weakness and wasting of the muscles of the thenar eminence may be noted on exam.
Diagnosis
Provocative testing, such as Tinel’s sign and Phalen’s maneuvers, can confirm the diagnosis of carpal tunnel syndrome. Tinel’s sign detects irritated nerves by percussing over the nerve and eliciting tingling. Tapping on the palmar aspect of the wrist will result in an electric shock sensation shooting into the hand when there is compression of the median nerve. Phalen’s maneuver is positive for carpal tunnel syndrome when holding the wrists in flexion for  seconds evokes or worsens symptoms. Electrodiagnostic testing demonstrates slowing of nerve conduction across the carpal tunnel.
Testing is typically performed on an outpatient basis to confirm the diagnosis or to aid in the decision for operative repair.
Treatment and Disposition
The initial treatment of carpal tunnel syndrome is conservative. Encourage evaluation of workplace ergonomics. Provide a neutral wrist splint, which can be worn at night only. Evidence shows short­term benefit from oral steroids, ultrasound, yoga, and carpal bone mobilization. NSAIDs have not
 been shown to be better than placebo for symptom improvement. Refer the patient to a hand surgeon if not improving with these treatments for consideration of surgical release.
ULNAR MONONEUROPATHY (CUBITAL TUNNEL SYNDROME AND GUYON’S CANAL SYNDROME)
The ulnar nerve extends from the medial cord of the brachial plexus and courses through the cubital tunnel behind the medial epicondyle at the elbow before entering the forearm. At the wrist, it passes through Guyon’s canal, bounded by the hamate and pisiform bones and the ligament connecting them. It supplies cutaneous innervation to the medial palm via the superficial terminal branch and to the fifth and medial fourth fingers via the deep terminal branch and innervates the palmaris brevis muscle. The ulnar nerve is most vulnerable to repetitive stress, inflammation, and trauma in the cubital tunnel and at Guyon’s canal.
Cubital tunnel syndrome is the most common ulnar mononeuropathy and the second most common compressive mononeuropathy. It results from pressure on the ulnar nerve at the medial epicondyle.
Guyon’s canal syndrome is caused by entrapment of the ulnar nerve in Guyon’s canal of the wrist. It is also called “handlebar palsy,” because it occurs in cyclists from prolonged compression of the wrist against the handlebars.
Clinical Features
The classic symptoms of ulnar mononeuropathy include tingling in the fifth and lateral fourth fingers. With time, numbness and weakness of the intrinsic muscles of the hand develop. In severe cases, paralysis and wasting of the intrinsic muscles of the hand may occur.
Diagnosis
Provocative testing is useful. Ulnar compression is possible if tapping on the cubital tunnel at the elbow provokes symptoms. A positive elbow flexion sign is seen when symptoms recur within  minutes of the elbow being held in flexion with the wrist in extension. Froment’s sign is an inability of the thumb to oppose or put pressure against the index finger. To perform this test, ask the patient to hold a piece of paper between thumb and index finger. If you can pull the paper away or the thumb flexes at the interphalangeal joint to compensate for weakness of the adductor pollicis brevis, the test is positive. In the patient with suspected cubital tunnel syndrome, consider C8 entrapment and thoracic outlet syndrome. C8 entrapment can be differentiated by the presence of neck pain and worsening symptoms with neck flexion. Thoracic outlet syndrome worsens with shoulder abduction. Electrodiagnostic testing serves to precisely localize the lesion. In Guyon’s canal syndrome, or handlebar palsy, compression of the ulnar nerve is more likely to spare sensory fibers that branch off before the canal. It presents as intrinsic weakness without sensory symptoms. Diagnosis of
Guyon’s canal syndrome is difficult, and MRI can sometimes aid in diagnosis.
Treatment and Disposition
In most cases of ulnar nerve mononeuropathy, the goal of treatment in the ED is to initiate conservative treatment and to ensure proper diagnosis and appropriate follow­up, usually with an orthopedist. Pain is not a common component of this syndrome, but anti­inflammatory medication may alleviate symptoms. Reduce repetitive use at work and home, and eliminate habits that cause pressure on the elbow or wrist.
DEEP PERONEAL NERVE ENTRAPMENT
The deep peroneal nerve may become entrapped at three locations along its course: the fibular head, anterior to the ankle joint as it passes beneath the extensor retinaculum (anterior tarsal tunnel syndrome), and distal to this point. Compression of the deep peroneal nerve may result from proximal fibular fracture or habitual crossing of the legs. Patients develop foot drop or numbness of the web between the great and second toes. Conservative treatment is recommended initially—provide a splint or brace to maintain the foot at a right angle with the leg. Prompt follow­up with a neurologist is important because nerve conduction studies should be performed to differentiate this syndrome from lumbar root or motor neuron disease.
MERALGIA PARESTHETICA
Meralgia paresthetica is entrapment of the lateral femoral cutaneous nerve in the inguinal canal. Entrapment causes numbness and pain of the anterolateral thigh. The cause can be pelvic (pregnancy, enlarging mass, aneurysm), extrapelvic (trauma, tight garment or belt, obesity), or systemic
(diabetes). On examination, the patient may complain of hyperesthesia in the area of pain, and Tinel’s sign may be evident when percussing over the anterior superior iliac spine. The pelvic compression test also supports this diagnosis: turn the patient on his or her side, compress the pelvis, and if the patient’s symptoms are relieved after  seconds of lateral compression of the pelvis, the diagnosis is confirmed.
Conservative management with NSAIDs, weight loss, relief from tight garments, and physiotherapy is usually successful. Local injection of lidocaine and corticosteroid near the insertion of the inguinal ligament into the anterior superior iliac spine provides relief. Surgical decompression or nerve resection may be required for relief of symptoms.
PLEXOPATHIES
The cervical, brachial, and lumbosacral plexuses are formed by the convergence of nerve roots, which then branch into peripheral nerves. In the case of the brachial plexus (Figure 172­2), the process of mixing and dividing is repeated in the stages of trunks and cords before peripheral nerves take off. Plexopathies share many of the same causes, the most common being trauma, surgery, neoplasm, and radiation therapy. Despite this similarity, plexopathies differ significantly in diagnosis and management.
FIGURE 172­2. The anatomy of the brachial plexus. [Reproduced with permission from Reichman EF, Tolson DR: Regional nerve blocks, in Reichman EF, Simon RR
(eds): Emergency Medicine Procedures. New York: McGraw­Hill, Inc.; 2004.]
BRACHIAL PLEXOPATHY
The brachial plexus, formed by the C5­T1 nerve roots, is the most common site of plexopathy. The brachial plexus is made complex by the nerve roots merging into upper middle and lower trunks, which split and merge into lateral posterior and medial cords that split again and form five peripheral nerves (see Figure 172­2). Injury at each of these anatomic locations will result in differing symptoms. Brachial plexopathies generally manifest as weakness first, but pain and paresthesias may also develop. On examination, the patient has weakness in various distributions of the brachial plexus.
The upper trunk is the more common site of involvement, affecting strength of proximal arm and shoulder musculature. Infraclavicular plexopathy due to trauma is frequently associated with injury to the axillary vessels. Causes of brachial plexopathy include trauma (penetrating trauma, humeral neck fracture, severe traction injury, or dislocation), shoulder reduction, neoplasm (Pancoast tumor), radiation, or surgery. A “burner” is burning pain involving one upper extremity, sometimes with numbness, paresthesias, or weakness, occurring after trauma to the neck and shoulder. It can occur in football players and other athletes during sports. A burner can be a brachial plexopathy, caused by traction to the shoulder or an injury to the cervical nerve roots caused by neck flexion­hyperextension. Brachial plexopathies can also result from cervical rib compression, midshaft clavicular fracture, or penetrating trauma. Assessment consists of careful neurologic examination, spine imaging, and consultation with neurology, neurosurgery, or orthopedics, depending on the specific injury identified.
LUMBOSACRAL PLEXOPATHY
The L1­S4 nerve roots form the lumbosacral plexus. Causes of lumbosacral plexopathy are less likely traumatic and more likely to include radiation, diabetic amyotrophy, aortic aneurysm, retroperitoneal hemorrhage, or compression from arteriovenous malformations. The differential diagnosis also includes the cauda equina and conus medullaris syndromes. Lesions affecting the lumbar portion of the plexus result in weakness of hip adduction and flexion and knee extension, decreased sensation at the top and inner thigh, and decreased patellar reflexes. Lesions affecting the sacral portion of the plexus result in inability to abduct the thigh at the hip joint, weakness of hip extension and knee flexion, and decreased sensation of the back of the thigh and below the knee. Plain radiographs of the lumbar spine are useful to screen for spine compression from degenerative or neoplastic disease. Perform MRI when cord injury or compression is considered. See Chapter 279, “Neck and Back Pain,” for detailed discussion of epidural compression syndromes, cauda equina syndrome, and conus medullaris syndrome. CT of the abdomen will exclude aortic aneurysm, psoas muscle masses, and retroperitoneal hemorrhage, which also present with asymmetric lower extremity weakness. Management of plexopathies is usually directed at the underlying cause.
CERVICAL PLEXOPATHY
The cervical plexus, formed by the C1­C4 nerve roots, is the least common plexopathy. Apart from trauma or neoplasm, the condition is occasionally seen postoperatively due to positioning during surgery. Patients may have few symptoms. Neoplastic lesions may cause a deep boring and constant pain. Due to anatomic parameters, electrodiagnostic assessment is difficult and unreliable. Order a CT or MRI scan if a neoplastic process is considered. The management of cervical plexopathy is usually nonoperative.
NEUROMUSCULAR JUNCTION DISORDERS
BOTULISM
Botulism is a toxin­mediated neuromuscular junction disorder that causes acute weakness leading to respiratory failure. In 2015, the Centers for
Disease Control and Prevention reported 199 cases of confirmed botulism. Of these, 71% were infantile botulism, 20% were foodborne, and 8% were
 wound botulism. Botulism affects infants between the ages of  week and  months and has been implicated as a cause of sudden infant death syndrome. The causative organism, Clostridium botulinum, is an anaerobic spore­forming bacterium found in soil and honey. In suitable environments, these spores germinate and release toxin that irreversibly binds the presynaptic membrane of peripheral and cranial nerves, inhibiting the release of acetylcholine at the peripheral nerve synapse. Three of the eight known toxins, types A, B, and E, produced by C. botulinum cause human disease. The most commonly implicated is toxin A, which is also used cosmetically in injection form. Most cases of botulism are isolated events associated with improperly preserved canned foods. In adults, botulism results from ingestion of preformed toxin. Infantile botulism occurs due to ingestion of spores that germinate in the higher pH of the infant GI tract. Botulism can result from wound infections, mostly occurring in injection drug
 users. In 2015, there were  reported case of wound botulism, with  occurring in people who inject drugs. Toxin type E is associated with preserved or fermented fish and marine mammals, and the latter are the most important sources of botulism in Alaska, Japan, Russia, and Scandinavia. C.
 botulinum is classified as a category A bioweapon by the Centers for Disease Control and Prevention, among the most lethal.
Clinical Features
Onset of symptoms occurs  to  hours after the poisoning with toxin. Patients experience nausea, vomiting, abdominal cramps, and diarrhea or constipation, which may easily be misdiagnosed as an acute gastroenteritis. Classically, botulism produces a descending, symmetric paralysis. Since the disorder is at the neuromuscular junction, there is no sensory deficit and no pain. The muscles first affected are the cranial nerves and bulbar muscles. The patient presents with diplopia, dysarthria, and dysphagia and may report blurred vision. Deep tendon reflexes are normal or diminished. Toxin­mediated decrease in cholinergic output causes anticholinergic symptoms, such as constipation, urinary retention, dry skin and eyes, and hyperthermia. Pupils are often dilated and nonreactive to light. Pupillary findings provide an important point of differentiation from myasthenia gravis, which does not affect the pupil. Infantile botulism presents as constipation, poor feeding, lethargy, and weak cry; consequently, this diagnosis must be in the differential of the “floppy” infant.
Diagnosis
The diagnosis of botulism is made based on clinical findings and exclusion of other processes. The toxin can be identified in both serum and stool, but the assay is not commonly available. If the suspected food source is available, it should be tested for toxin.
Treatment and Disposition
Initial treatment is supportive. Secure the airway if there is respiratory compromise. Severe botulism may necessitate mechanical ventilation for months. For infant intestinal botulism, human­derived botulinum immune globulin significantly reduces time of hospitalization and time on
,11 mechanical ventilation. For children older than  year of age and adults, equine serum botulism antitoxin similarly has been shown to reduce length of time in the hospital and on the ventilator. Administer antitoxin as soon as the diagnosis is made to prevent worsening of symptoms and shorten the time of recovery. If contaminated food is still in the GI tract, consider administering an enema. Wounds may require surgical treatment to
 remove the source of toxin­producing bacteria. Report suspected cases to the local health department so that further exposures can be prevented.
TICK PARALYSIS
Tick paralysis, or tick toxicosis, is an uncommon disease caused by a poorly defined neurotoxin secreted in the saliva of several tick species. It is most common in spring and summer and in the Pacific Northwest, western, and southeastern states. Most cases are in children.
Clinical Features
Initially,  to  days after tick attachment, patients experience nonspecific influenza­like symptoms including malaise and weakness. These symptoms progress to ataxia and then an ascending weakness and paralysis without sensory involvement. Infants and children may be listless or irritable.
When the bulbar nerves and diaphragm become involved, respiratory failure ensues.
Diagnosis
Tick paralysis is diagnosed based on typical symptoms and when the culprit tick is located. Perform a complete body search for ticks before initiating treatment for other possible diagnoses. The most common tick attachment site is the scalp. If no tick is found, the differential diagnosis of acute ataxia and ascending flaccid paralysis without sensory involvement includes Guillain­Barré syndrome, botulism, spinal cord tumor, and poliomyelitis.
Misdiagnosis of tick paralysis can lead to failure to find and remove the tick and unnecessary therapies such as central venous access, plasma
 exchange, and IV immunoglobulin. Tick paralysis and Guillain­Barré syndrome are indistinguishable even with nerve conduction studies.
Treatment and Disposition
Treatment involves complete removal of the attached tick. Remove ticks by taking hold of the very head of the tick with tweezers and applying gentle steady traction. If a tick is not found on the skin, use a fine­tooth comb to look through hair.
Admit patients with respiratory distress to the intensive care unit, and admit all patients to the hospital to ensure symptoms do not progress. Local
 wound care and supportive care (including intubation and mechanical ventilation if necessary) result in excellent recovery within hours to days.
INFLAMMATORY MYOPATHIES
Although not acute peripheral neurologic lesions, polymyositis and dermatomyositis present with similar symptoms to many peripheral neuropathies.
These diseases are rare inflammatory myopathies causing symmetric weakness that progresses over weeks to months.
Clinical Features
Patients develop weakness of the proximal limbs, trunk, and neck. Some experience dysphagia, myalgias, and rarely dyspnea when the respiratory muscles become involved. Sensation and reflexes are normal, and the ocular muscles are usually spared. Occasionally cardiac muscle may be involved with cardiomyopathy, heart failure, and conduction disturbances. The findings of dermatomyositis are similar with the addition of a diffuse violaceous rash often on the face and trunk.
Diagnosis
Diagnosis is mainly clinical, but certain laboratory findings are characteristic such as elevated erythrocyte sedimentation rate, elevated creatine kinase, and leukocytosis. The differential diagnosis includes Lambert­Eaton syndrome, endocrinopathies, toxic myopathies, and infectious myopathies.
Treatment and Disposition
To prevent irreversible muscle damage, both polymyositis and dermatomyositis require treatment with systemic corticosteroids or other immunosuppressants.
Admit patients with rhabdomyolysis, respiratory distress, or profound weakness. Otherwise, patients may be discharged with neurology or rheumatology follow­up within  days.
SUBACUTE AND ACUTE­ON­CHRONIC PERIPHERAL NERVE LESIONS
Neuropathies can also be associated with an underlying medical disorder, such as HIV and diabetes.
HUMAN IMMUNODEFICIENCY VIRUS–ASSOCIATED PERIPHERAL NEUROLOGIC DISEASE
HIV infection, its complications, and its pharmacologic treatments are associated with a number of peripheral neurologic disorders. The most common of these, HIV neuropathy and antiretroviral drug–induced neuropathy, are chronic processes that do not cause sudden disability or symptoms. HIV­ infected patients have a high rate of mononeuritis multiplex and an inflammatory myopathy resembling polymyositis. In late­stage acquired immunodeficiency syndrome, almost all patients manifest neuropathy. Patients in the early stages of HIV infection have greater susceptibility to
Guillain­Barré syndrome. The presentation is similar to that of the non–HIV­infected patient. Treatment is the same as in non­HIV Guillain­Barré syndrome, with an emphasis on identifying patients who are likely to need intubation and mechanical ventilation early in the ED stay followed by close monitoring of respiratory function.
CYTOMEGALOVIRUS RADICULITIS
In the latter stages of acquired immunodeficiency syndrome, cytomegalovirus may acutely infect the lumbosacral nerve roots, causing a polyradiculopathy or cauda equina syndrome. Evidence of systemic cytomegalovirus infection, including retinitis, is almost always present. As opposed to the more common chronic neuropathy of HIV, patients with cytomegalovirus radiculitis become acutely weak, with primarily lower extremity involvement, and may have variable degrees of bowel and bladder dysfunction. The examination shows primarily lower extremity weakness and hyporeflexia, with decreased sensation in the lower extremities and groin. Rectal tone may be impaired. Lumbar puncture reveals a pleocytosis with predominantly polymorphonuclear cells and modestly increased protein. Viral DNA is detected by polymerase chain reaction in most patients and is highly specific. MRI of the lumbosacral spine demonstrates swelling and clumping of the cauda equina. Imaging is recommended to exclude mass lesions of the lower spine or nerve roots. Early identification is important, as antiviral treatment is effective. The treatment of cytomegalovirus radiculitis is IV ganciclovir, started at  milligrams/kg every  hours for  to  weeks. Treatment can be initiated before definitive diagnosis.
DIABETIC PERIPHERAL NEUROPATHY
Diabetes mellitus remains the most common cause of noncompressive focal neuropathy. A variety of mechanisms contribute to the pathophysiology of diabetic neuropathy. Chronic hyperglycemia and glycemic variability lead to oxidative stress and neuroinflammatory processes that result in a variety of neuropathic syndromes.
Diabetic peripheral neuropathy is the term used for any neuropathy in a type  or type  diabetic patient. The most common manifestation of diabetic peripheral neuropathy is a distal symmetric polyneuropathy, but it may also lead to focal neuropathies and mononeuropathy multiplex.
Diabetic peripheral neuropathy is an example of a distal axonopathy resulting in length­dependent, centripetal “dying back” of the affected nerves.
This phenomenon produces the typical stocking and glove distribution of diabetic neuropathy.
Hyperglycemic neuropathy is seen in newly diagnosed diabetics and normally improves with glycemic control. Insulin neuritis is a reversible condition characterized by acute limb pain and paresthesias associated with rapid glycemic control with insulin. Painful diabetic neuropathy is usually intermittent and worse at night. It can be experienced variably as pins and needles, throbbing, burning, aching, or cramping. Duration is less than  months. After  months, the same process is termed chronic painful diabetic neuropathy. Diabetic neuropathic cachexia is a rare syndrome causing weight loss and painful dysesthesias of the limbs and trunk.
Diabetic amyotrophy is a lumbosacral plexopathy seen in patients with a long­standing history of diabetes and presents with back pain followed by weakness. Patients report the acute onset of ipsilateral back pain, followed within days by progressive leg weakness. Sensory findings are absent. The examination reveals decreased leg power in a variety of patterns reflecting impairment of plexus function with relatively symmetric sensation. There may be muscle wasting in affected limbs in long­standing disease. Deep tendon reflexes may be diminished on the affected side. Bowel and bladder functions are not affected.

Glucose control has been linked to a reduction in the development of neuropathy. The Diabetes Control and Complications Trial demonstrated a

60% reduction in risk of developing neuropathy with tight glycemic control, which persisted for  years. Emphasize strict foot care to the diabetic who has already developed neuropathy. Neuropathy­associated anesthesia may result in inadvertent trauma and subsequent development of ulcers, cellulitis, fasciitis, osteomyelitis, and eventual amputation. Symptomatic management is an ED patient’s most immediate concern. NSAIDs are ineffective in treating neuropathic pain and are relatively contraindicated in the diabetic patient due to their renal and cardiac effects. There is strong evidence for pregabalin in the treatment of painful diabetic neuropathy. Moderate evidence also exists for gabapentin, sodium valproate,
,17 amitriptyline, venlafaxine, duloxetine, opiates, capsaicin, and percutaneous electrical nerve stimulation.
Acknowledgment
The authors gratefully acknowledge the contributions of Andy Jagoda, MD, who authored this chapter in the 7th edition, and J. Michael Guthrie, MD, who contributed to this chapter in the 8th edition.


