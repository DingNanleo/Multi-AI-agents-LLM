University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 24: Cardiac Resuscitation
Brit Long; Alex Koyfman; Venkataraman Anantharaman; Swee Han Lim; Marcus E.H. Ong; Tan Boon Kiat Kenneth; James E. Manning
INTRODUCTION
Cardiac resuscitation is a rapidly changing clinical science. Recommendations of the 2015 American Heart Association Advanced Cardiac Life Support
 updates are provided in this chapter and are augmented by the most current resuscitation research literature. These recommendations are similar to the recent 2017 International Consensus on Cardiopulmonary Resuscitation and Emergency Cardiovascular Care Science With Treatment

Recommendations Summary. The guidelines are summarized as follows.
CHEST COMPRESSIONS
The recommended chest compression rate is 100 to 120 per minute, updated from 100 per minute.
Chest compression depth should be  to  cm, not >6 cm. Chest compression ratio should be >60 and as close to  as possible.
There does not appear to be an advantage to asynchronous or interpolated breaths as long as the highest possible compression ratio is maintained.
The compression­to­breath ratio is 30:2. If an adjunctive or definitive airway is in place, provide  breaths per minute.
DEFIBRILLATION
Early defibrillation is the most effective modality for return of spontaneous circulation (ROSC).
DRUGS
Amiodarone or lidocaine (lignocaine) may not provide added benefit to defibrillation.
Vasopressin has been removed from the Advanced Cardiac Life Support algorithm.
Routine use of β­blockers after cardiac arrest is not recommended, with benefits for ROSC only demonstrated through animal studies and case reports.
Steroids may provide some benefit when bundled with vasopressin and epinephrine in in­hospital cardiac arrest, although routine use is not recommended.
OXYGENATION AND CAPNOGRAPHY
Provide 100% fraction of inspired oxygen (Fio ) during cardiac arrest, with oxygen saturation titrated to >94% after ROSC.

End­tidal carbon dioxide (CO ) can be used to monitor for ROSC. Low end­tidal CO (<10 mm Hg) after  minutes is associated with low likelihood
  of survival.
EXTRACORPOREAL MEMBRANE OXYGENATION
Extracorporeal membrane oxygenation (ECMO) or extracorporeal CPR can be considered in patients with refractory cardiac arrest who have not responded to conventional CPR, where it can be rapidly implemented with suspicion of reversible cause of cardiac arrest.

Chapter 24: Cardiac Resuscitation, Brit Long; Alex Koyfman; Venkataraman Anantharaman; Swee Han Lim; Marcus E.H. Ong; Tan BooPna gKeia 1t / 
POST­ROSC CARE
Kenneth; James E. Manning
. Terms of Use * Privacy Policy * Notice * Accessibility
Emergency percutaneous coronary intervention is recommended for patients with ST­segment elevation on ECG and for hemodynamically or electrically unstable patients with no ST­segment elevation but suspected cardiovascular cause.
Targeted temperature management between 32°C and 36°C for comatose patients with ROSC for at least  hours is recommended.
SOCIAL MEDIA AND EDUCATION
Use of social media technologies that summon rescuers in close proximity to a victim of out­of­hospital cardiac arrest may be reasonable.
Audiovisual devices can be used to educate providers and improve CPR quality.
EPIDEMIOLOGY

Every year, approximately .8 to .5 million persons throughout the world sustain cardiac arrest. About 70% of cardiac arrests occur out of hospital.
The proportion of cardiac arrest patients who are treated varies from .6% (United States) to .3% (Asia). The proportions with ventricular fibrillation (VF) and survival vary from 11% and 2%, respectively, in Asia, to 28% and 6% in North America, 35% and 9% in Europe, and 40% and 11% in

Australia. Approximately half of cardiac arrest victims are <65 years old.
Ventricular tachydysrhythmias are the initiating event in approximately 80% of patients with out­of­hospital primary cardiac arrest. During ambulatory

ECG monitoring of 157 witnessed cardiac arrests, Bayés de Luna et al documented 70% with ventricular tachycardia (VT) and VF, 13% with torsades de
 pointes, and 17% with bradydysrhythmias. Untreated VF deteriorates to asystole in approximately  minutes. For patients with sudden cardiac arrest,
  the rate of survival declines rapidly by 7% to 10% for each minute without defibrillation. If delay to defibrillation exceeds  minutes, survival approaches 0% to 5%.
THE CHAIN OF SURVIVAL
The structured emergency care system concept for treatment of cardiac arrest is called the Chain of Survival and includes five components: recognition and activation of the emergency response system, immediate high­quality CPR, rapid defibrillation, basic and advanced
EMS, and advanced life support and postarrest care for out­of­hospital cardiac arrest (OHCA). If a community’s prehospital EMS can be activated promptly, reach the patient within  minutes of collapse, and deliver the first shock shortly thereafter, survival in excess of 15% to 20% can be
,10 expected, with recent reports of >30% survival. With delayed initiation of CPR, defibrillation, and access to the patient by EMS, the impact of advanced life support measures is small (Figure 24­1). Improved survival can only occur if structured emergency care systems allow trained providers to access the patient rapidly and deliver the appropriate treatment in a timely fashion. Delays in initiating the various links weaken the chain and adversely affect the next link, resulting in a decreased chance of a good outcome for the patient.
FIGURE 24­1. Incremental survival benefits by the links in the Chain of Survival. ACLS = Advanced Cardiac Life Support. [Reproduced, with permission, from the
National Resuscitation Council, Singapore.]
Based on the Chain of Survival, cardiac arrest can be divided into three separate time­sensitive phases: the electrical, circulatory, and metabolic
,12 phases. These phases affect treatment efficacy. The electrical phase is present in the first  minutes of arrest, where the cardiac system is most amenable to defibrillation if a shockable rhythm is present. The circulatory system consists of the next  minutes after arrest, when high­quality chest compressions and epinephrine provide the greatest benefit. The metabolic phase is >20 minutes after arrest and is marked by electrolyte and acidbase disorders; epinephrine delivered >20 minutes after arrest is associated with decreased cerebral blood flow, worse neurologic outcome, and increased cardiac ischemia.
ADVANCED CARDIAC LIFE SUPPORT (ACLS)
The basic life support assessments and interventions include the Primary Survey, and the advanced life support assessments and interventions include the Secondary Survey.
An organized approach to resuscitation begins with the Primary Survey and blends smoothly with the Secondary Survey. These are summarized in the
Universal Advanced Cardiac Life Support Algorithm (Figure 24­2). This method helps any Advanced Cardiac Life Support provider remember the sequence of resuscitation actions and be less likely to miss any of the vital steps in the care of the patient.
FIGURE 24­2. Universal Advanced Cardiac Life Support Algorithm. ACS = acute coronary syndrome; OD = overdose; VF = ventricular fibrillation; VT = ventricular tachycardia.
PRIMARY SURVEY
The Primary Survey addresses the identification of cardiac arrest and performance of good­quality CPR (including ventilation) and defibrillation.
Procedures for the Primary Survey are described in Chapters  and . The 2015 Advanced Cardiac Life Support guidelines and 2017 International
Consensus on Cardiopulmonary Resuscitation and Emergency Cardiovascular Care Science With Treatment Recommendations Summary emphasize chest compressions, starting with circulation­airway­breathing as opposed to airway­breathing­circulation. Maximize chest compression fraction to
>60% with minimal pauses in compressions.
Defibrillate as soon as possible for VF or pulseless VT. Start at 200 J biphasic or at maximum energy. Make sure CPR interruptions are as brief as possible when defibrillating. Maintain continuous compressions during rhythm analysis and defibrillator recharging. Resume one cycle of CPR immediately after defibrillation even with ROSC.
For ventilation, bag­valve masks (BVMs) deliver 21% oxygen if using room air, 60% oxygen when connected to an oxygen source with flow at  L/min, and 90% to 95% with a reservoir bag. Chest compressions should not be stopped to initiate or continue ventilation.
During cardiac arrest, 100% FIO during compressions is recommended due to unreliable measurement of oxygen saturation. The time required to

 perform endotracheal intubation may decrease compression fraction. Any airway device may be used during CPR, including BVM, supraglottic airway,
,15 or endotracheal intubation, with literature suggesting similar patient outcomes.
The 2015 updates and 2017 International Consensus on Cardiopulmonary Resuscitation and Emergency Cardiovascular Care Science With Treatment
Recommendations Summary recommend a 30:2 compression­to­breath ratio, maximizing compression time, with no pauses longer than 
,16 seconds. The target compression rate is 100 to 120 per minute, rather than at least 100 per minute. The maximum compression rate is 120 per minute because quality decreases with rates greater than this. The maximum depth of compressions is  cm, with a target of  to  cm, rather than at least  cm in the 2010 guidelines. Audiovisual devices may be used to optimize CPR quality.
For one­ and two­rescuer CPR, the 2015 Advanced Cardiac Life Support guidelines recommend  compressions followed by two breaths (30:2 ratio) in patients without an advanced airway, similar to the 2017 International Consensus on Cardiopulmonary Resuscitation and Emergency Cardiovascular

Care Science With Treatment Recommendations Summary. During breaths, compressions may be withheld. If an advanced airway is in place, the 2015 updates recommend a breath rate of  per minute, or one breath every  seconds, asynchronous from compressions. A 2015 study by the
Resuscitation Outcomes Consortium compared continuous chest compressions with asynchronous BVM ventilation versus CPR with compression pauses for breaths in patients without an advanced airway in place. This study found no significant difference between the two ventilation techniques with regard to survival to hospital discharge, as long as the chest compression fraction was >75%. A 2017 study suggests that endotracheal intubation
 within the first  minutes of arrest with a shockable rhythm may be associated with lower survival due to interruptions in chest compressions. The
 key point is to provide meticulous CPR, maximizing compressions, with the briefest of pauses (<10 seconds).
Mechanical CPR devices may also be used to provide cardiac compression. The two most common types of mechanical CPR devices used in clinical practice are the LUCAS­2®, with a piston attached to an active compression­decompression cup (Figure 24­3), and the load­distributing band
AutoPulse® (Figure 24­4). These devices allow provision of either 30:2 CPR or continuous chest compressions with interposed manual ventilations.
Apply defibrillator pads to the bare chest before placing a mechanical CPR device.
FIGURE 24­3. The LUCAS­2® chest compression gadget with its attached active compression­decompression device.
FIGURE 24­4. The AutoPulse® mechanical CPR device with its load­distributing band.
The evidence to date does not suggest benefit from mechanical versus high­quality manual chest compressions from trained individuals based on
19­21 several meta­analyses and Cochrane reviews. However, mechanical compressions are reasonable if sustained high­quality compressions compromise provider safety or are impractical. There is little evidence to support the use of impedance threshold devices.
The critical rhythms associated with cardiac arrest are VF (Figure 24­5), pulseless VT (Figure 24­6), asystole (Figure 24­7), and pulseless electrical activity (PEA) (Figure 24­8).
FIGURE 24­5. Ventricular fibrillation.
FIGURE 24­6. Pulseless ventricular tachycardia.
FIGURE 24­7. Asystole.
FIGURE 24­8. Pulseless electrical activity.
Defibrillation may be done with either an automated external defibrillator or a manual defibrillator (see Chapter , “Defibrillation and Electrical
Cardioversion”). Deliver shocks for VF or pulseless VT with minimal interruption of chest compressions only during actual shock delivery. Make sure that the position of the defibrillator pads (Figure 24­9) does not interfere with monitoring leads.
FIGURE 24­9. Placement of defibrillator pads.
After delivery of the first shock, resume CPR (Figure 24­10) immediately for  minutes before reviewing the ECG monitor for a rhythm diagnosis. If a viable rhythm has returned, check for pulse and breathing. If breathing and pulse have returned, begin care for post­ROSC management. If breathing is absent, continue rescue breathing with a BVM at the rate of about  breaths per minute; if pulse is not present, continue CPR and move to the
Secondary Survey.
FIGURE 24­10. Continuing CPR after shock using an automated external defibrillator.
SECONDARY SURVEY
Components of the Secondary Survey are listed in Table 24­1. TABLE 24­1
Components of the Secondary Survey
Component and
Detailed Components
Function
A: Securing the Airway Endotracheal intubation or other supraglottic airway, e.g., laryngeal mask airway, although BVM may be used
B: Breathing (ventilation) . Ventilation with BVM
. Oxygen
. Mechanical ventilation
C: Maintaining the Circulation . Continue CPR
. Provide defibrillation and cardioversion to correct life­threatening “shockable” rhythms
. Continuous ECG monitoring to monitor the circulation’s rhythm and identify dysrhythmias that need to be corrected
. Gain vascular access through IV/IO line
. Provide drugs to help maintain circulation
. Consider use of ECMO
D: Differential Diagnosis . Determine why the patient is not responding to the resuscitative efforts
. Look for correctible causes of collapse and provide necessary interventions
Specialized Care after ROSC Targeted temperature management, glycemic control, early goal­directed therapy, percutaneous coronary interventions
Abbreviations: BVM = bag­valve mask; ECMO = extracorporeal membrane oxygenation; ROSC = return of spontaneous circulation.
The Secondary Survey includes endotracheal intubation or the placement of another airway adjunct, assessment of ventilatory status, gaining IV access, identifying ECG rhythms, delivering drugs to enhance circulation, and addressing the reasons for the occurrence or persistence of cardiac arrest.

ECG and POCUS may assist in determining etiology of arrest, particularly in PEA. PEA with narrow QRS is generally due to mechanical problems caused by right ventricular inflow or outflow obstruction. PEA with wide­complex QRS is associated with metabolic pathology or myocardial ischemia with left ventricular failure. The use of US to assess cardiac contractility and arrest etiology may provide benefit, but make sure US assessment does not compromise compressions. US may also be used to confirm ROSC and endotracheal tube placement.
While the Secondary Survey is in progress, continue the basic resuscitative actions of the Primary Survey. Usually, defibrillation pads placed carefully left of the apex and to the right of the sternum just below the right clavicle (Figure 24­9) can also act as monitoring leads. Otherwise, true monitoring leads may be placed at the front of the right and left shoulders and over the left iliac crest. Such placement does not interfere with defibrillation or cardiac pacing procedures. Further management is based on the cardiac rhythm.
VASCULAR ACCESS
Vascular access techniques are discussed in Chapter , “Vascular Access.” A large peripheral vein allows a rapid rate of fluid administration, if needed.
If unable to cannulate a peripheral vein, establish IO access. Central venous lines take time to establish and, because of the length of the cannula, cannot deliver fluids as rapidly as a peripheral line; in addition, every bolus dose of drugs requires flushing with at least  mL of normal saline. Central lines are useful for central venous pressure monitoring to guide fluid resuscitation and circulatory management. The key is to provide high­quality compressions and defibrillate if necessary while obtaining rapid access (IV, IO, or central access).
In cardiac arrest, circulation of blood grinds to a halt. With good­quality CPR, one can expect to generate up to 30% of normal cardiac output, which is required to supply vital organs such as the heart, brain, and kidneys. The reduced circulation is associated with a slower circulation time. Therefore, drugs given during cardiac resuscitation are best administered through a proximal peripheral vein. Once drugs are given, flush the line with normal saline, and continue CPR for at least  to  seconds before repeat external defibrillation so that the heart is optimally primed to respond.
The optimal infusion fluid is normal saline and not dextrose, Ringer’s lactate, or sodium bicarbonate. However, unless hypovolemia is a contributing factor to cardiac arrest, fluid infusion is typically not necessary, but if provided, it should be slow. Drug dosages are the same whether given by the IO,
IV, or central line routes. The endotracheal tube route is no longer recommended for drug administration because drug absorption is limited in the setting of pulmonary edema.
CAPNOGRAPHY
Waveform capnography is the most reliable means of confirming and continuously monitoring tracheal tube placement, as well as monitoring
23­25 resuscitation and ROSC. An end­tidal reading <10 mm Hg CO after  minutes of resuscitation is associated with low chance of survival. However,
 this should not be used alone when deciding to cease resuscitation efforts. Capnography may also be used to monitor ventilation rate and CPR quality because high­quality compressions should produce an end­tidal CO of at least  to  mm Hg, if not greater. End­tidal CO readings >20 mm Hg at 

23­25 minutes predict a higher chance of ROSC, whereas readings <10 mm Hg at  minutes predict almost no chance of ROSC. A sudden rise in end­tidal
CO is an early indication of ROSC.

DRUGS USED FOR ROSC FROM CARDIAC ARREST
Drugs available for cardiac resuscitation and cardiac dysrhythmia management are also described in Chapters  and . This section will cover those drugs specifically used for resuscitation from cardiac arrest to ROSC. Drugs are an adjunct in the management of cardiac arrest patients. Good CPR, ventilation, and early defibrillation are the cornerstones of management of cardiac arrest. The effectiveness of standard resuscitative drugs on ROSC
26­28 and survival to hospital discharge has not been well demonstrated. Antidysrhythmic drugs for shockable cardiac arrest show no benefit versus
 placebo for survival to hospital discharge, survival with favorable neurologic function, and long­term survival. However, consensus documents recommend the standard resuscitative drugs described below with the presumptive rationale that drugs help “restart” the heart and preserve coronary and cerebral circulation.
EPINEPHRINE
Epinephrine (adrenaline) is an endogenous catecholamine. It has an important role in cardiac arrest, although the evidence base for improved
  outcomes in humans is weak. Epinephrine seems to improve ROSC and short­term survival but does not appear to improve survival to hospital
,33 discharge or neurologic outcome. A 2018 study suggested improved ROSC with epinephrine, but survivors demonstrated a higher rate of severe
 neurologic disabilities. Epinephrine may provide the most benefit within the first  to  minutes of cardiac arrest during the circulatory phase,
 based on its alpha effects of increasing peripheral vasoconstriction and coronary and cerebral blood flow. Potential adverse effects include an increase in myocardial oxygen consumption and an increase in pulmonary shunting. The most common adverse reaction is tachycardia. Epinephrine may worsen myocardial ischemia and induce ventricular ectopy and VT, especially when provided beyond  minutes after arrest. Epinephrine is used mainly to treat cardiac arrest from VF or pulseless VT unresponsive to the initial shock, asystole, PEA, and profoundly symptomatic bradycardia. The 2015 updates provide a class IIb recommendation, stating that standard­dose epinephrine may be reasonable for patients with cardiac arrest. The standard dose in cardiac arrest is .0 milligram diluted to  mL (10 mL of 1:10,000) given IV or IO. Repeat if needed at
3­ to 5­minute intervals. There is no maximum dose. Escalating doses to  to  milligrams IV every  to  minutes (high­dose epinephrine) has not
 resulted in increased long­term survival. For IV infusion in patients with cardiogenic shock or symptomatic bradycardia, the dose is  milligram in 500 mL of normal saline beginning at  to  micrograms/min and escalating as needed at 3­ to 5­minute intervals. Do not add epinephrine to infusions that contain alkaline solutions because epinephrine has ineffective clinical activity in alkaline solutions.
AMIODARONE
Amiodarone is considered a class III antiarrhythmic drug, but it possesses electrophysiologic characteristics of all four Vaughan­Williams classes. It causes coronary and peripheral artery vasodilation. Its main use in cardiac arrest is for persistent VT or VF after defibrillation and epinephrine. Although the 2015 Advanced Cardiac Life Support guidelines recommend amiodarone for refractory VF, in 2016 a large multicenter trial failed to demonstrate a difference in survival to hospital discharge for shock­refractory VF or pulseless VT with amiodarone or lidocaine compared to
 placebo.
Amiodarone can also be used for hemodynamically stable VT, hemodynamically stable polymorphic VT, and hemodynamically stable wide­complex tachycardia of uncertain origin. It is also used for the pharmacologic conversion of atrial fibrillation, control of rapid ventricular rate in preexcitation supraventricular dysrhythmias, and as an adjunct to electrical cardioversion of refractory paroxysmal supraventricular tachycardia/atrial tachycardia.
For pulseless VT or VF, the dose is a bolus of 300 milligrams IV followed by a 20­mL flush with 5% dextrose in water or saline. Give another 150­ milligram bolus if there is no response to the first dose. For stable ventricular and supraventricular dysrhythmias, administer amiodarone IV 150 milligrams over  to  minutes (not to exceed  milligrams/min), followed by a maintenance infusion of  milligram/min for  hours and then .5 milligram/min for the next  hours. Infusions exceeding  hours should be administered in glass or polyolefin bottles because the drug precipitates in plastic tubing. Hypotension and bradycardia are the most common unwanted effects. These may be addressed by slowing the infusion rate, giving an
IV fluid challenge, or using pressors or positive chronotropic agents. Occasionally, temporary pacing for refractory bradycardia from amiodarone may be required, especially if other measures are ineffective.
Recent literature suggests no improvement in survival or favorable neurologic outcome in patients with OHCA due to initial shock­refractory VF or
  pulseless VT with antidysrhythmic medications such as amiodarone or lidocaine. A meta­analysis published in 2016 found that amiodarone improves survival to hospital admission for OHCA, but it does not improve survival to discharge or neurologic outcomes compared to placebo or other antidysrhythmics. Patients with in­hospital cardiac arrest may receive some benefit when given steroids, vasopressin, and epinephrine as a bundle,
 although routine use is not recommended.
LIDOCAINE (LIGNOCAINE)
Lidocaine (lignocaine) (see also Chapter , “Approach to Nontraumatic Shock”) is a class I antidysrhythmic drug. It reduces automaticity, suppresses ventricular ectopy, and may be used for hemodynamically stable VT and refractory VF/pulseless VT. In the 2010 recommendations, lidocaine was the second­choice drug after amiodarone or was used if amiodarone was not available. However, a 2016 multicenter study suggests no
 improvement in survival or neurologic outcome with use of lidocaine (or amiodarone or placebo) for OHCA from VF or pulseless VT. In the 2010 guidelines for cardiac arrest, the dose was an IV bolus of  to .5 milligrams/kg body weight. A second bolus of .5 to .75 milligram/kg was provided if the rhythm persisted. The 2015 algorithm no longer contains lidocaine, and guidelines state that the routine use of lidocaine after ROSC is not recommended, although it may be considered in patients with ROSC after VF or pulseless VT. Upon ROSC, lidocaine may be given as an infusion at a rate of  to  milligrams/min.
If dysrhythmia reappears during the infusion of lidocaine, give a bolus of .5 milligram/kg and increase the infusion rate to  milligrams/min. Toxicity may occur with doses exceeding  milligrams/kg body weight bolus or in patients with liver disease, since the drug is hepatically metabolized.
Symptoms include neurologic changes such as drowsiness, disorientation, reduced hearing ability, perioral paresthesia, muscle tremors, and seizures. Myocardial depression and circulatory depression are also features of toxicity, and these may be illustrated by widening QRS complexes and falling blood pressures. In patients with known impaired liver function or patients >70 years old, give the same recommended bolus doses but decrease the normal infusion rate by 50%.
β­BLOCKERS
In animal studies, β­blockers can reduce myocardial oxygen requirements, decrease the number of shocks needed for defibrillation, and prolong survival from VF/pulseless VT. Successful use in humans is based primarily upon case reports. β­Blockade in cardiac arrest demonstrates the most benefit in patients with refractory VF or VT, known as electrical storm, which is defined by three or more sustained episodes of VF or VT in a 24­hour
38­40 ,41 period. Esmolol, metoprolol, and propranolol can be used in refractory VF or VT. One retrospective series of patients with refractory VF or VT who received at least three defibrillations, 300 milligrams of amiodarone, and  milligrams of adrenalin, without success, reported that esmolol given
,41 during resuscitation improved rate of ROSC, intensive care unit admission, survival to hospital discharge, and favorable neurologic outcome.
Further study is required.
MAGNESIUM
+ +
Magnesium is a cofactor in numerous enzymatic reactions. It is essential for the function of the Na ­K ­ATPase pump. Magnesium deficiency may be associated with cardiac dysrhythmias, sudden death, and precipitation of VF. Magnesium is used to treat hypomagnesemia, with or without dysrhythmias.
Magnesium is initial treatment for torsades de pointes and dysrhythmias secondary to hypomagnesemia, cardiac arrest from QT c
,42 prolongation, or cardiac glycoside toxicity. For patients in VF or pulseless VT due to the above conditions, give  to  grams in  mL 5% dextrose in water IV over  minute. Magnesium provides no benefit for routine use in cardiac arrest. For patients with a pulse, the dose is  to  grams in  mL of 5% dextrose in water over  minutes. Adverse reactions include flushing, sweating, mild bradycardia, hypotension, asystole with circulatory collapse (with too rapid administration), and respiratory depression. Hypermagnesemia may produce depressed reflexes, flaccid paralysis, diarrhea, respiratory depression, and circulatory collapse.
OTHER DRUGS IN CARDIAC ARREST
Atropine
Atropine is a parasympatholytic agent that enhances sinus node automaticity and atrioventricular conduction by direct vagolytic action. It is not recommended for PEA or for treatment of cardiac arrest. It is indicated for symptomatic bradycardia. The dose is .5 or .6 milligram IV (dose depends on formulation in country of use) and may be repeated at 5­ to 10­minute intervals up to a maximum of .04 milligram/kg body weight.
Atropine may induce tachycardia or premature ventricular contractions and cause worsening of myocardial ischemia. Symptoms of overdosage include tachycardia, delirium, coma, flushed and hot skin, ataxia, and blurred vision. Administration of low doses <0.5 milligram IV may produce paradoxical bradycardia and precipitate VF.
Calcium
Calcium is given during resuscitation only for cardiac arrest from hyperkalemia, hypocalcemia, or β­blocker/calcium channel–
,43 blocker overdose. Calcium is not recommended for routine administration for VF/pulseless VT or PEA. The dose of calcium chloride is .2 mL/kg of 10% calcium chloride, given as a slow IV bolus.
Sodium Bicarbonate
The use of sodium bicarbonate during cardiac arrest was advocated in the past to treat presumptive acidosis, because severe acidosis decreases
 myocardial contractility. However, routine use during cardiac arrest is no longer recommended due to a number of potential adverse effects.
Sodium bicarbonate causes hypernatremia, hyperosmolality, and alkalosis (which in turn induces a left shift of the oxyhemoglobin dissociation curve), and IV sodium bicarbonate produces carbon dioxide, resulting in hypercarbia unless ventilation is increased. It does not appear to improve defibrillation success. It may be given in cardiac arrest from hyperkalemia or cyclic antidepressant overdose or other agents that result in sodium channel blockade (cocaine toxicity). It is acceptable for intubated patients with a long arrest interval until ROSC and with persistent severe metabolic acidosis. However, a pilot study evaluating the use of sodium bicarbonate in patients with prolonged cardiac arrest with pH
<7.1 or bicarbonate <10 mEq/L found sodium bicarbonate did not improve rate of ROSC or neurologic survival, but further study is required in this
 population. In undifferentiated cardiac arrest, sodium bicarbonate does not benefit and may be harmful based on several randomized trials and
46­48 retrospective observation studies. The 2015 AHA guidelines recommend against routine use in cardiac arrest. If provided, the dose is  to .5 mEq/kg IV bolus, followed by .75 mEq/kg every  to  minutes as needed. If continuous infusion of sodium bicarbonate is used, check pH to guide therapy. Increased ventilatory rate is recommended to remove excess CO produced by sodium bicarbonate infusion.

Vasopressin
Vasopressin, also called antidiuretic hormone, is a naturally occurring neurohypophysial peptide hormone synthesized in the hypothalamus and stored in the pituitary gland. It increases water absorption in the nephron and increases peripheral vascular resistance. Vasopressin levels elevate during cardiac arrest, and this observation led to investigation of its role in resuscitation. Vasopressin has a longer duration of action and, in laboratory studies, maintains coronary perfusion pressure, myocardial blood flow, and cerebral blood flow better than epinephrine. However, most
,43 studies do not show superiority of vasopressin over epinephrine. Vasopressin as a first­line agent in cardiac arrest (40­unit dose) does not improve
 long­term survival when compared to epinephrine, although vasopressin might improve short­term survival in patients with prolonged cardiac
  arrest. Combining vasopressin (40 units) with epinephrine does not appear to improve outcomes. The 2015 updates remove vasopressin from all algorithms. A combination of vasopressin, epinephrine, and steroids is not recommended at this time for routine use, due to low quality of evidence.
COMMON CARDIAC ARREST ALGORITHMS
The algorithmic approach to cardiac arrest management allows a structured decision­making process when managing cardiac arrest victims. The cardiac arrest rhythms discussed here are pulseless VT/VF, asystole, and PEA. The use of US to assess contractility and ECG for length of the QRS interval (narrow vs. wide) has been evaluated and may provide benefit in determining etiology of arrest, although it is currently unclear if the use of US affects clinical outcomes. Periarrest US should not compromise compressions. Be meticulous with compressions because the literature suggests that
,52
US used in cardiac arrest is associated with delays in compressions. Pauses in compressions should be no longer than  seconds. US may assist in
,53 identifying reversible causes of arrest, and several dedicated US protocols are available. A relatively new US protocol, the Cardiac Arrest

Sonographic Assessment, assesses for cardiac tamponade (first pause in compressions), pulmonary embolism (second pause), and cardiac activity (third pause) during CPR pauses to minimize interruptions in compressions. During CPR, the ultrasonographer assesses for hypovolemia and
,53 pneumothorax. This protocol was associated with reduced interruptions in high­quality compressions.
VENTRICULAR FIBRILLATION/PULSELESS VENTRICULAR TACHYCARDIA
Once VF or pulseless VT is diagnosed, prepare for electrical conversion while CPR is in progress. If ROSC does not occur after the first shock, move to the mega­VF approach (Figure 24­11). Continue CPR for  to  minutes followed by rhythm analysis, and if VF persists or recurs, deliver electrical shocks, usually biphasic, beginning usually at 200 J and escalating, if needed, to 360 J. For monophasic defibrillators, begin at 360 J. After delivery of shock, follow with CPR again for  to  minutes before rhythm analysis. Maintain good­quality CPR for optimal coronary and vital organ perfusion.
Parallel to the CPR­analysis­shock­CPR­analysis­shock­CPR cycle, begin secondary ABCDs (airway, breathing, circulation, defibrillation) and give drugs that may help to lower defibrillation thresholds, such as epinephrine (adrenaline) and/or amiodarone, or perhaps lidocaine. Any or all of these drugs may be administered in any combination and repeated at roughly 3­ to 5­minute intervals. After administration of any of these drugs, provide at least
 to  seconds of effective CPR to allow the injected drug to reach the central circulation before the next shock. Continue the resuscitation cycle for as long as the rhythm remains as VF or pulseless VT.
FIGURE 24­11. Management of ventricular fibrillation (VF)/pulseless ventricular tachycardia (VT). PEA = pulseless electrical activity; ROSC = return of spontaneous circulation.
DOUBLE SEQUENTIAL EXTERNAL DEFIBRILLATION
Double sequential external defibrillation may be appropriate for patients with shock­refractory VF, defined as three or more sustained episodes of VT,
,40
VF, or implantable cardioverter­defibrillator shocks within  hours. This was initially described in the 1980s, with several current descriptions of
,55,56 success in patients with refractory VF. It is theorized that double sequential defibrillation reduces the VF threshold and overrides the relative refractory period of cardiac tissue. To complete this, a second set of defibrillator pads is placed in the anterior­posterior positions (if the first set is placed in the standard apex­sternum orientation), for a total of two sets (four separate pads). Both sets are charged to maximal settings, with simultaneous shock delivery, which requires coordination. This may be appropriate for patients in refractory VF after quality CPR and several attempts at defibrillation.
ASYSTOLE/PULSELESS ELECTRICAL ACTIVITY
For asystole or PEA (a condition in which cardiac contractions are absent in the presence of coordinated electrical activity), continue CPR and institute the secondary ABCDs. Give drugs to enhance the chances of ROSC (Figure 24­12). Epinephrine (adrenaline) .0 milligram as a bolus dose in  mL is the drug of choice. Vasopressin alone or in combination with epinephrine is no more effective than epinephrine alone. Repeat epinephrine as needed in 3­ to 5­minute intervals. Consider other possible causes of asystole or PEA, and identify and correct them. It is currently assumed that narrow­
 complex PEA could be the result of mechanical problems such as cardiac tamponade, pneumothorax, mechanical hyperinflation, pulmonary embolism, or myocardial rupture. Bedside ultrasound and assessment of the clinical scenario can direct specific treatment. Wide­complex PEA, on the other hand, can result from a metabolic problem (e.g., hyperkalemia), drug toxicity (e.g., sodium channel–blocker toxicity), cardiac ischemia, or left
 ventricular failure and should be treated as appropriate. Survival is low if patients in asystole do not achieve ROSC in the field or convert to a
58­60 shockable rhythm.
FIGURE 24­12. Asystole/pulseless electrical activity (PEA) management algorithm. IVC = inferior vena cava; LV = left ventricle; MI = myocardial infarction; PE = pulmonary embolism; PTX = pneumothorax.
DIFFERENTIAL DIAGNOSES OF CARDIAC ARREST
In every resuscitation, it is useful to identify important causes of cardiac arrest and reasons for lack of response to standard resuscitation algorithms.
Causes can be grouped as the  H’s—hypovolemia or hemorrhage, hypoxia, hydrogen ion (acidosis), hypo­ or hyperkalemia, and hypothermia—and the  T’s—trauma and tablets (overdose), cardiac tamponade, coronary thrombosis, tension pneumothorax, and thrombosis (pulmonary embolism). The use of US to assess contractility and ECG to assess for length of the QRS interval (narrow versus wide) has been evaluated and may benefit in determining etiology of arrest. Periarrest US should not compromise compressions, but it may assist in identifying reversible causes of arrest. It is currently unclear whether the use of US affects clinical outcomes. However, use of US in PEA may affect clinical decision
 making through identification of pathologies requiring emergent intervention.
H: HYPOVOLEMIA OR HEMORRHAGE
History of fluid or blood loss may be available. Rectal examination can identify massive lower GI bleeding; nasogastric intubation can identify massive upper GI bleeding; and bedside FAST can diagnose massive intraperitoneal bleeding. Treat with fluids and blood products.
H: HYPOXIA
Hypoxia occurs with lack of oxygen and alveolar ventilation. Make sure that the airway adjunct is placed correctly. Check breath sounds at intervals to ensure that the endotracheal tube has not slipped out of the trachea or to identify pneumothorax. Verify the source of oxygen—an oxygen cylinder or the piped oxygen supply.
H: HYDROGEN ION (ACIDOSIS)
The acidosis of cardiac arrest is a combination of respiratory and metabolic acidosis. Respiratory acidosis is addressed by early endotracheal intubation and alveolar ventilation. Metabolic acidosis can be somewhat addressed by good­quality CPR. Sodium bicarbonate can be administered for severe metabolic acidosis from prolonged or poor initial resuscitation, at a dose of  to .5 mEq/kg. Half the initial dose can be readministered after  to  minutes, depending on pH. However, data currently do not support routine administration of sodium bicarbonate for acidosis, with no controlled
 studies demonstrating improved hemodynamics with sodium bicarbonate. If administered, ventilatory rate should be increased to counteract the
 increased CO produced by sodium bicarbonate. Continuous venovenous hemodialysis may be required for severe acidosis.

H: HYPER­ OR HYPOKALEMIA, OTHER METABOLIC DISORDERS
Suspect hyperkalemia in patients on hemodialysis or peritoneal dialysis (look for presence of arteriovenous fistula or dialysis catheter). Other metabolic disorders are extremely difficult to confidently identify in cardiac arrest. If hyperkalemia is suspected, administer calcium chloride, sodium bicarbonate, insulin, and glucose. Treat hyperkalemia from suspected digitalis toxicity with IV magnesium sulfate or digoxin­specific Fab fragments
(Digibind®).
H: HYPOTHERMIA
Treat hypothermia with gradual rewarming with blankets and warm IV fluids. If there is no recovery of consciousness in the hypothermic patient following ROSC, maintain a body core temperature of 33°C until further assessment and decisions can be made.
T: “TABLETS” (DRUG OVERDOSE)
Drug overdose is rarely identified as a cause of cardiac arrest during the resuscitation process. In the event of antidepressant overdose, administer IV sodium bicarbonate. Lipid emulsion infusion may be useful in cardiac arrest associated with cyclic antidepressants or local anesthetics. β­Blocker or calcium channel–blocker overdose may require high­dose insulin therapy and lipid emulsion infusion.
T: CARDIAC TAMPONADE
Cardiac tamponade is best identified during resuscitation by bedside transthoracic US. This requires brief interruption of chest compressions.
Treatment of tamponade causing cardiac arrest is bedside pericardiocentesis.
T: TENSION PNEUMOTHORAX
Suspect tension pneumothorax during cardiac resuscitation if breath sounds are unequal on chest auscultation after verifying correct endotracheal tube placement. Treatment is immediate needle decompression.
T: CORONARY THROMBOSIS
Acute coronary thrombosis or acute myocardial infarction is one of the most common causes of cardiac arrest. Risk factors are a history of coronary
63­67  artery disease and initial rhythm of VF/VT. Cardiac catheterization after resuscitation is an underused procedure. A 12­lead ECG in the immediate post–cardiac arrest state can identify an ST­segment elevation acute myocardial infarction and allow arrangements for immediate coronary
 angiography. Myocardial and neurologic function can improve after percutaneous coronary intervention following cardiac arrest. The 2015 American

Heart Association/American College of Cardiology guidelines provide a class I recommendation to activate the cardiac catheterization laboratory in patients with OHCA with ST­segment elevation acute myocardial infarction on ECG. Thus, after ROSC, especially in the face of post­ROSC ECG evidence of acute myocardial infarction, advocate for cardiac catheterization and percutaneous coronary revascularization if available and appropriate. A few
 case reports describe fibrinolysis during CPR with resultant ROSC and good neurologic outcome. Coronary angiography is reasonable in select patients with suspected cardiac origin of arrest but without ST elevation or in those electrically unstable patients without ST­segment elevation with suspected cardiovascular lesions. The absence of ST­segment elevation on postarrest ECG does not exclude acute coronary thrombus, as approximately one third of patients without ST­segment elevation myocardial infarction on postarrest ECG demonstrate a culprit lesion on
 angiography. Reports are too few to determine whether thrombolysis together with CPR results in more severe bleeding than thrombolysis without

CPR.
T: THROMBOSIS (PULMONARY EMBOLISM)
Pulmonary embolism causing cardiac arrest requires fibrinolysis or embolectomy. However, the diagnosis is rarely made at time of collapse, and even then, most systems are not geared to make such prompt diagnosis and initiate the necessary procedures for embolectomy. Fibrinolytic agents could
 be considered during cardiac arrest from suspected pulmonary embolism on a case­by­case basis. A single­center case series of patients with diagnosed pulmonary embolism suffering PEA arrest found that rapid administration of alteplase  milligrams IV to be safe and effective, with  of 
73­75 patients demonstrating ROSC. High­quality compressions should be continued after thrombolytic therapy is administered, with several studies recommending  to  seconds of compression after the drug is given. Factors suggestive of pulmonary embolism causing cardiac arrest include two of three signs or symptoms (prearrest respiratory distress, altered mental status, or shock); arrest witnessed by a physician or emergency medical technician; and PEA as the first or primary arrest rhythm.
POST­ROSC COMPLICATIONS
After return of spontaneous circulation (ROSC), many factors affect survival, including anoxic brain injury, post–cardiac arrest myocardial dysfunction, the systemic reperfusion response, and the cause of cardiac arrest. Ischemic­reperfusion injury is discussed in Chapter , “Post–Cardiac Arrest
Syndrome.” Anoxic brain injury results in disturbance of cerebral microvascular hemostasis and manifests as coma, seizures, myoclonus, and varying degrees of neurocognitive dysfunction, including brain death. Post–cardiac arrest myocardial dysfunction results from myocardial stunning with cardiac hypokinesis and a low left ventricular ejection fraction. Clinical manifestations include tachycardia and elevated left ventricular end­diastolic pressures, progressing to hypotension and reduced cardiac output. The systemic ischemia­reperfusion response consists of inflammation, endothelial activation, and disturbed vasoregulation with generalized activation of immunologic and coagulation pathways, causing increased risk of multiple organ failure and infection. Clinical manifestations of the systemic ischemia­reperfusion response include impaired oxygen delivery and utilization and increased susceptibility to infection.
OXYGENATION AND VENTILATION
76­78
Hyperoxia during the early phase of reperfusion after ROSC harms postischemic neurons and increases brain lipid peroxidation. After ROSC,
 adjust the rate of ventilation and tidal volume to maintain arterial oxyhemoglobin saturation at 94% to 98%. Hyperventilation is not recommended because it can increase intrathoracic pressures and decrease venous return and cardiac output. In addition, hypocarbia resulting from hyperventilation decreases cerebral blood flow and aggravates anoxic brain damage. The suggested ventilator parameters during the post­ROSC
77­79 phase are as follows: Paco ,  to  mm Hg (5 to  kPa); Sao , 94% to 98%; tidal volume,  to  mL/kg ideal body weight; Petco ,  to  mm Hg,
   and  to  ventilations per minute.
HEMODYNAMIC MANAGEMENT
Obtain 12­lead ECG after ROSC and repeat at  hours or as needed. Administer IV fluids and drugs to optimize blood pressure, cardiac output, and urine output. The target for blood pressure is a mean arterial pressure of  to 100 mm Hg, and the target for blood oxygenation is an Scvo of ≥70%. 

Pharmaceutical agents to support the circulation include epinephrine, norepinephrine, dopamine, dobutamine, nitroglycerine, and esmolol. Routine use of lidocaine after ROSC is not recommended. Obtain an echocardiogram at  hours after ROSC to detect regional wall motion abnormalities and determine ejection fractions.
TARGETED TEMPERATURE MANAGEMENT (THERAPEUTIC HYPOTHERMIA)
Cooling of the CNS decreases cerebral oxygen demand, reduces cellular effects of reperfusion, and decreases the production of reactive oxide radicals.
Targeted temperature management (cooling to 32°C to 36°C; temperature goal is controversial) during the first  hours after ROSC improves survival
80­82 and neurologic recovery in patients who remain comatose soon after ROSC. The phases of temperature management are induction, maintenance,
 and rewarming. The most recent evidence suggests cooling for  hours is not associated with improved neurologic outcomes, and a greater degree
 of cooling (32°C vs. 36°C) is not associated with improved patient outcomes. Hyperpyrexia in the first  hours is associated with a lowered chance of optimal neurologic recovery, and avoiding hyperpyrexia is paramount. See Chapter , for detailed discussion.
GLYCEMIC CONTROL

Post­ROSC hyperglycemia is associated with increased mortality and worse neurologic outcomes. Hypoglycemia, similarly, is also associated with poor outcomes in critically ill patients. Maintain blood sugar levels between 100 and 180 milligrams/dL (6 and  mmol/L).
NEUROLOGIC ASSESSMENT
Features of brain injury after ROSC include coma, seizures, myoclonus, and various degrees of neurocognitive dysfunction ranging from memory deficits to a persistent vegetative state and finally brain death. Treat seizures promptly. The neurologic prognosis in the majority of comatose cardiac
 arrest survivors undergoing therapeutic hypothermia is challenging and typically cannot be reliably predicted in the ED. Cerebral imaging for
,88 prognostication has been studied, including MRI and CT in association with scoring systems or biomarkers, but requires further study.
ADVANCED RESUSCITATION TECHNIQUES
ECMO (Box 1) and SAAP (Box 2) are advanced resuscitation techniques available or practiced in some settings.
BOX  Extracorporeal CPR (ECMO) in Cardiac Arrest
ECMO, also known as extracorporeal life support, is a recent introduction in the management of cardiac arrest. Its use is well documented in the neonatal and pediatric population and in adults for refractory respiratory failure and cardiogenic shock. Use in refractory cardiac arrest is also known as extracorporeal CPR (Table 1). Extracorporeal CPR is a bridging therapy to definitive treatments, such as percutaneous coronary
 interventions, cardiac bypass surgery, or heart transplant. Current published results on effectiveness are inconclusive.
The ECMO equipment consists of a blood pump, a venous reservoir, an oxygenator for exchanging both oxygen and CO , and a heat exchanger to
 warm the blood used (Figure 1). The whole system is monitored through pressure, oxygen saturation, and temperature monitors. Three types of
ECMO circuits are available:
. Venoarterial ECMO pumps blood from the venous side to the arterial side to facilitate gas exchange and provide hemodynamic support. The blood is pumped from the venous circulation through a cannula inserted in either the inferior vena cava or right atrium and through the oxygenator where gas exchange occurs, and then is warmed and returned to the patient through a cannula placed in either the aortic arch or femoral artery into the arterial circulation. This is the modality that is used to support cardiac arrest patients.
. Venovenous ECMO removes blood from the right atrium, passes it through the gas exchanger, and returns it across the tricuspid valve into the right ventricle. It does not provide hemodynamic support. This modality is used primarily for refractory respiratory failure.
. Arteriovenous ECMO uses the patient’s own arterial pressure to pump the blood from the arterial to the venous side and facilitates gas exchange in the process. This does not require the use of a separate blood pump.
The ECMO circuit is initially primed with fresh blood, which is then pumped through the circuit. During maintenance of ECMO, hemodynamic parameters, urinary output, hematologic indices, fluids, and electrolytes are monitored.
Extracorporeal CPR complications can be mechanical, medical, or both. Mechanical complications consist of clots in the circuit; mediastinal bleeding from tears to the great vessels; oxygenator failure; and malfunction of the blood pump, oxygenator, heat exchanger, and sensors. Medical complications include intracranial and systemic hemorrhage, initial cardiac stunning that may occur soon after initiation of ECMO, pneumothorax, acute kidney injury, GI bleeding, sepsis, and metabolic derangement.
Extracorporeal CPR must also be accompanied by appropriate post–cardiac arrest management, including targeted temperature and hemodynamic management and early coronary angiography for definitive treatment. At present, survival rates are low, but can be improved with EMS and ED training, appropriate patient selection, and more widespread application of the technique.
TABLE 
General Indications and Contraindications for Extracorporeal CPR (Extracorporeal Membrane Oxygenation in Cardiac Arrest)
Indications Contraindications
Good premorbid status before cardiac arrest Advanced age; advanced malignancy; poor baseline neurologic function; baseline inability to perform activities of daily living; preexisting “do not resuscitate” order
Intervention to be curative, not palliative Suspect aortic dissection or severe aortic regurgitation; traumatic cardiac arrest
Reversible trigger event for cardiac arrest (dysrhythmia, Unwitnessed cardiac arrest and no bystander CPR
ST­segment elevation myocardial infarction, etc.) Long prehospital transport time
Prolonged cardiac arrest unless good perfusion and metabolic support is documented
FIGURE . Extracorporeal CPR in the ED of Singapore General Hospital.
BOX  Selective Aortic Arch Perfusion
Selective aortic arch perfusion (SAAP) (Figure 2) is an extracorporeal perfusion therapy providing effective blood flow during cardiac arrest,
90­92 improving chance of ROSC and limiting time­critical ischemic injury, and reducing cardiac and CNS damage.
SAAP can be used for cardiac arrest and hemorrhage­induced traumatic cardiac arrest (similar to resuscitative endovascular balloon occlusion of the aorta).
The procedure involves insertion of a femoral artery large­lumen balloon occlusion catheter advanced to the descending thoracic aorta.
Balloon inflation isolates the aortic arch vessels, perfusing the coronary, carotid, and vertebral arteries.
If the limit of the exogenous oxygen carrier is reached, oxygenated autologous blood can be provided with a closed­loop circuit.
Full ECMO can follow SAAP if prolonged extracorporeal perfusion is required.
FIGURE . Illustration of fluoroscopic image of selective aortic arch perfusion with descending thoracic aortic occlusions, competent aortic valve closure, and coronary artery perfusion. [Figure used with permission of James Manning, MD.]


