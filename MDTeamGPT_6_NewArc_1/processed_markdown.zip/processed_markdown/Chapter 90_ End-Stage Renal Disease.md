## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 90: End­Stage Renal Disease
J. Hayes Calvert; David M. Cline
INTRODUCTION AND EPIDEMIOLOGY
End­stage renal disease (ESRD) is the irreversible loss of renal function, resulting in the accumulation of toxins and the loss of internal homeostasis.
Uremia, the clinical syndrome resulting from ESRD, is fatal without some form of renal replacement therapy. At present, renal replacement therapy consists of two basic modalities: renal transplant and dialytic therapy, either hemodialysis or peritoneal dialysis (PD).
Hemodialysis is the initial therapy in the vast majority of new cases of adult ESRD, with a few starting PD and an even smaller number receiving predialytic renal transplants. The proportions are reversed in children, with most children receiving transplants. More than 100,000 Americans await a
 renal transplant, with a median time of .6 years on a transplant wait list.

One­year mortality for hemodialysis patients is 20% to 25%, with 5­year survival of 35%. Cardiac causes account for about half of all deaths. Infections trigger death in up to a quarter of patients, with cerebrovascular events and malignancy being other causes.
PATHOPHYSIOLOGY
Renal failure causes complex physiologic abnormalities (Table 90­1).
TABLE 90­1
Clinical Features Associated With Uremia and Dialysis
General
Diffuse muscle cramping, pruritus
Neurologic
Uremic encephalopathy: cognitive defects, memory loss, decreased attentiveness, slurred speech, reversal of sleep­wake cycle, asterixis, seizure, coma, symptomatic improvement with dialysis
Dialysis dementia: progressive neurologic decline, failure to improve with dialysis, fatal
Subdural hematoma: headache, focal neurologic deficits, seizure, coma
Peripheral neuropathy: singultus (hiccups), restless leg syndrome, sensorimotor neuropathy, autonomic neuropathy
Cardiovascular
Coronary artery disease
Hypertension: essential hypertension, glomerulonephritis, renal artery stenosis, fluid overload
Heart failure: fluid overload, uremic cardiomyopathy, high­output arteriovenous fistula
Pericarditis: uremic, dialysis related, pericardial tamponade
Hematologic
Anemia, decreased red blood cell survival, decreased erythropoietin levels
Bleeding diathesis
Immunodeficiency (humoral and cellular)

Chapter 90: End­Stage Renal Disease, J. Hayes Calvert; David M. Cline 
GI
. Terms of Use * Privacy Policy * Notice * Accessibility
Anorexia, metallic taste, nausea, vomiting
GI bleeding
Diverticulosis, diverticulitis
Ascites
Renal bone disease
Metastatic calcification (calciphylaxis)
Hyperparathyroidism (osteitis fibrosa cystica)
Vitamin D deficiency and aluminum intoxication (osteomalacia)

Excretory failure leads to elevated levels of >70 chemicals in uremic plasma, and these toxins, individually or in combination, cause uremic organ dysfunction and produce the symptoms of uremia. Besides urea, other potential uremic toxins include cyanate, guanidine, polyamines, and β ­

 microglobulin. If uremia were simply a toxidrome, then dialysis would reverse all its untoward effects; however, it does not, in part because many
 toxins are highly protein bound and nondialyzable. Because many uremia­related organ dysfunctions persist after dialysis, other processes are clearly important.
Biosynthetic failure refers to the aspects of uremia caused by loss of the renal hormones ,25(OH) ­vitamin D and erythropoietin. The kidneys are
  primarily responsible for the secretion of erythropoietin and 1α­hydroxylase, which is necessary to produce the active form of vitamin D . Because 85%
 of erythropoietin is produced in the kidneys, ESRD patients have depressed levels of erythropoietin, which contributes to anemia. Vitamin D
 deficiency results in decreased GI calcium absorption, inducing secondary hyperparathyroidism and leading to renal bone disease.
Regulatory failure results in an oversecretion of hormones, leading to uremia by disruption of normal feedback mechanisms. The uremic state produces excess free oxygen radicals, which react with carbohydrates, lipids, and amino acids to create advanced glycation end products, linked to
 atherosclerosis and amyloidosis in ESRD patients. This may explain the progressive nature of the atherosclerosis and amyloidosis seen in ESRD
 patients.
CLINICAL FEATURES OF UREMIA
Uremia is a clinical syndrome (Table 90­1), and no single symptom, sign, or laboratory test result reflects all aspects of uremia. Although a correlation
 exists between the symptoms of uremia and low glomerular filtration rate (GFR) (8 to  mL/min/1.73 m ), BUN and serum creatinine levels are inaccurate markers of the clinical syndrome of uremia. The decision to start long­term dialysis is based on the severity of the patient’s symptoms related to uremia. The most common reasons for emergency dialysis are fluid overload (51%), hyperkalemia (18%), and severe acid­base
  disturbances. Uremia is the most common indication for nonemergent dialysis.
NEUROLOGIC COMPLICATIONS
Stroke occurs in approximately 6% of hemodialysis patients, with about half being hemorrhagic and half ischemic. Subdural hematomas occur 
 times more frequently in dialysis patients than in the general population.
Uremic encephalopathy is a constellation of nonspecific central neurologic symptoms associated with renal failure. Onset may be sudden
 mimicking ischemic stroke, or the neurologic function may deteriorate gradually over several days. Uremic encephalopathy is best diagnosed after
 eliminating structural, vascular, infectious, toxic, and metabolic causes of neurologic dysfunction. MRI may show basal ganglia lesions. Neurologic
 findings of uremic encephalopathy improve with dialysis in 70% of patients.
Dialysis dementia is nonspecific in presentation from other encephalopathies. This manifestation of ESRD and treatment is progressive, with the 2­ to 4­year survival for these patients being 24%. This disorder usually becomes evident after at least  years of dialysis therapy and fails to respond to increases in dialysis frequency or renal transplantation.

Peripheral neuropathy is one of the most frequent neurologic manifestations of ESRD, with greater lower than upper limb involvement. The most frequent clinical features reflect large­fiber involvement, with paresthesias, reduction in deep tendon reflexes, impaired vibration sense, muscle wasting, and weakness. Autonomic dysfunction results in impotence, postural dizziness, gastric fullness, bowel dysfunction, and reduced sweating.
Reduced heart rate variability and baroreceptor control impairment occur.
Conventional hemodialysis does not seem to improve autonomic dysfunction; however, daily short hemodialysis and long nocturnal hemodialysis may
 reduce the elevated sympathetic activity. Treatment is only marginally effective, including vitamins, amitriptyline, gabapentin, and carbamazepine.
Because few treatments are effective and side effects are common, the patient’s nephrologist or a pain specialist should manage medications.
CARDIOVASCULAR COMPLICATIONS

The mortality from cardiovascular disease is  to  times higher in dialysis patients than in the general population. Coronary artery disease, left ventricular hypertrophy, and congestive heart failure are common. The etiology of cardiovascular disease in ESRD patients is multifactorial, related to preexisting conditions (e.g., hypertension, diabetes), uremia (e.g., uremic toxins, hyperlipidemias, homocysteine level, hyperparathyroidism), and
 dialysis­related conditions (e.g., hypotension, dialysis membrane reactions, hypoalbuminemia).
CARDIAC MARKERS
The diagnosis of ischemic cardiovascular disease in ESRD patients often has been clouded by the misconception that the traditional serum protein markers of myocardial damage (troponins I and T) are unreliable in dialysis patients. Elevated levels of troponin I and T are common even in asymptomatic hemodialysis patients and probably reflect left ventricular hypertrophy and microvascular disease. Asymptomatic elevations of cardiac
 biomarkers are, however, associated with long­term risks of coronary artery disease. To account for higher baseline levels of troponin T and I, many
 define myocardial infarction only by a 20% or more dynamic rise and with at least one value above the 99th percentile (see Chapter , “Chest Pain”).
HYPERTENSION
Hypertension is primarily due to increased total peripheral resistance. Increases in blood volume, decreased vascular compliance, the vasopressor
 effects of native kidneys, the renin­angiotensin system, and the sympathetic nervous system also play roles in ESRD hypertension.
Management of hypertension in ESRD patients begins with control of blood volume. If that is unsuccessful, most cases can be controlled with adrenergic blocking agents, angiotensin­converting enzyme inhibitors, or vasodilating agents, such as hydralazine or minoxidil. Bilateral nephrectomy is rarely necessary for blood pressure control.
HEART FAILURE
Hypertension is the most common cause of heart failure in ESRD patients, followed by coronary artery disease and valvular defects. Causes unique to
ESRD include uremic cardiomyopathy, fluid overload, and arteriovenous fistula–related high­output failure (see section “Complications of Vascular
Access” later in the chapter). Natriuretic peptide levels are elevated in hemodialysis patients, often from concomitant left ventricular hypertrophy and systolic dysfunction. Elevation of natriuretic peptides in hemodialysis patients correlates with higher short­term mortality rates, but there are no reliable thresholds to identify fluid overload.
UREMIC CARDIOMYOPATHY
Uremic cardiomyopathy is a diagnosis of exclusion when all other causes of congestive heart failure have been excluded. In most uremic patients, left ventricular dysfunction is related to ischemic heart disease, hypertension, and hypoalbuminemia. Dialysis rarely improves left ventricular function in uremic patients with congestive heart failure.
PULMONARY EDEMA

Pulmonary edema is most commonly ascribed to fluid overload, but acute myocardial ischemia can also trigger depressed left ventricular function.
Cornerstones of therapy are supplemental oxygen if needed, bilevel positive airway pressure, nitrates, and angiotensin­converting enzyme inhibitors.
Loop diuretics, such as furosemide (60 to 100 milligrams IV), may aid even in those with minimal urine output because loop diuretics have short­lived vasodilatory actions. Hemodialysis is the ultimate treatment for fluid overload in ESRD patients. Preload reduction by inducing diarrhea with sorbitol or by phlebotomy may help in low­resource situations. Removing as little as 150 mL of blood is safe and effective in some with pulmonary edema. Improved oxygenation produced by phlebotomy offsets the decrease in oxygen­carrying capacity due to the decrease in hemoglobin. Blood withdrawn during phlebotomy should be collected in transfusion bags, so plasma can be extracted by the blood bank and the red blood cells transfused back to the patient later during dialysis. PD does not remove volume fast enough to have a significant impact on pulmonary edema.
CARDIAC TAMPONADE
Cardiac tamponade is a concern in any critically ill ESRD patient, often presenting without classic findings. Instead, signs of cardiac tamponade include changes in mental status, hypotension, or shortness of breath. Increased interdialytic weight gain, increased edema, and intradialytic hypotension are other warning signs suggesting the diagnosis of tamponade. In addition to hypotension, an increased heart size on chest radiograph suggests effusion
 and potential tamponade. Bedside US is the best method to detect pericardial effusion and tamponade. Hemodynamically significant pericardial effusions require pericardiocentesis under fluoroscopic or US guidance. Bedside pericardiocentesis (see Chapter , “Pericardiocentesis”) is used only in hemodynamically unstable patients because of its high complication rate.
PERICARDITIS
Pericarditis is usually due to uremia. Uremic pericarditis is linked to fluid overload, abnormal platelet function, and increased fibrinolysis and inflammation. Pericardial contents are sterile unless infected and are abundant with fibrin and inflammatory cells.
Uremic pericarditis causes pericardial friction rubs, which are louder than in most other forms of pericarditis, often palpable, and frequently persist for some time after metabolic abnormalities have been corrected. BUN level is nearly always >60 milligrams/dL. One of the unique features of uninfected uremic pericarditis is that the inflammatory cells do not penetrate into the myocardium, so typical ECG changes of acute pericarditis are absent. Most often, the ECG demonstrates associated abnormalities, such as left ventricular hypertrophy, ischemia, and metabolic abnormalities (e.g., hyperkalemia and hypocalcemia). When the ECG has features typical of acute pericarditis, suspect infection.
Dialysis­related pericarditis is most common during periods of increased catabolism (trauma and sepsis) or inadequate dialysis due to missed sessions or vascular access problems. The pathophysiology of dialysis­related pericarditis is the buildup of middle molecules and hyperparathyroidism. Dialysis­related pericarditis is more common during hemodialysis than during PD, although now somewhat less frequent because of improved dialysis techniques. Fever and malaise are more common and severe than in uremic pericarditis. Pericardial effusion is the most important complication and tends to be recurrent. Due to the recurrent nature of dialysis pericarditis, adhesions and fluid loculations are common, which complicates the interpretation of echocardiographic scans and images obtained using other modalities.

Management of uremic and dialysis­related pericarditis in patients in hemodynamically stable condition is intensive dialysis. Hemodialysis is preferred over PD because of the higher clearance rates of the former, recognizing the risks of tamponade from heparin and rapid fluid shifts.
Hemodialysis is effective in the majority of cases of dialysis­related pericarditis, usually after  to  days. Systemic anticoagulation should be
 withheld if pericardiocentesis is being considered or effusion is worsening. Indomethacin, colchicine, and steroids are not useful for ESRD pericarditis. If pericardial effusion persists for longer than  to  days with intensive dialysis, anterior pericardiectomy is often used, with total pericardiectomy reserved for constrictive pericarditis.
HEMATOLOGIC COMPLICATIONS
ANEMIA
Anemia is multifactorial, caused by decreased erythropoietin, blood loss from dialysis, frequent phlebotomy, and decreased red blood cell survival times. In addition, the wide fluctuations in plasma blood volume seen in dialysis patients often cause factitious anemia. Without specific treatment, the hematocrit should stabilize at 15% to 20%, with normocytic and normochromic red blood cells. Bone marrow shows erythroid hypoplasia, with little effect on leukopoiesis or megakaryocytopoiesis. Anemia is treated with regular infusions of human recombinant erythropoietin. Erythropoietin replacement therapy improves the quality of life for ESRD patients by increasing exercise capacity and tolerance.
COAGULOPATHY
The bleeding diathesis of ESRD patients increases the risks of GI tract bleeding, subdural hematomas, subcapsular liver hematomas, and intraocular bleeding. Several mechanisms, including decreased platelet function, abnormal platelet–vessel wall interactions, altered von Willebrand factor, anemia, and abnormal guanidinosuccinic acid–dependent production of nitric oxide, create uremic bleeding. The skin bleeding test is the best predictor of clinically important defects in hemostasis. Patients receiving aspirin or warfarin are at greater risk of major bleeding. Improvement in bleeding times is seen with infusions of desmopressin, .3 microgram/kg IV/SC (benefit in  hour), or cryoprecipitate,  units given over 
 minutes (benefit in  hours). Conjugated estrogens,  milligrams IV or  milligrams/kg/d (benefit in  hours), are also described as an option.
,20
Tranexamic acid is another option.
IMMUNE DISORDERS
Immunologic deficiency in ESRD patients results in high morbidity and mortality from infectious diseases. Depressed leukocyte chemotaxis and phagocytosis from many causes are the key features, along with abnormal T­cell activation. Dialysis does not improve the immune function and may exacerbate immunodeficiency by complement activation after exposure to the hemodialysis filter membrane.
RENAL BONE DISEASE
As the glomerular filtration rate falls, phosphate excretion decreases, which results in increased serum phosphate levels. When the calcium­phosphate
2+ product [Ca (milligrams/dL) × PO (milligrams/dL)] is higher than  to , metastatic calcification can ensue. Joint pain from pseudogout
 develops from calcification of synovial membrane–lined joints. Metastatic calcification in small vessels results in skin and finger necrosis, and lifethreatening calcifications can occur in the cardiac and pulmonary systems. Short­term mortality rate is higher in ESRD patients with a calciumphosphate product of >72. Treatment consists of the use of low­calcium dialysate and phosphate­binding gels.
β ­MICROGLOBULIN AMYLOIDOSIS

Dialysis­related amyloidosis (β ­microglobulin amyloidosis) can occur in dialysis patients >50 years of age and on dialysis for >10 years. Advanced
 glycation end products appear central to the chronic inflammatory condition, leading to amyloidosis. Amyloid deposits are found in the GI tract, bones, and joints. Complications include GI perforation, bone cysts with pathologic fractures, and arthropathies, including carpal tunnel syndrome and rotator cuff tears. Patients with amyloidosis have higher mortality rates than do those without this disorder.
HEMODIALYSIS
TECHNICAL ASPECTS OF HEMODIALYSIS
Hemodialysis substitutes a filter for the glomerulus to produce an ultrafiltrate of plasma. Small amounts of IV heparin, 1000 to 2000 units, are used to
 prevent thrombosis at the vascular access site. Hemodialysis sessions typically take  to  hours. Adjustment of the pressure gradient across the hemodialyzer filter during hemodialysis controls the amount of fluid removal (ultrafiltration). Solute removal (clearance) during hemodialysis depends on the filter pore size, the amount of ultrafiltration (solute drag), and the concentration gradient across the filter (diffusion). During hemodialysis, blood is removed from the vascular access site by large­bore needles (typically  gauge), circulated through the dialysis machine at rates of 300 to 500 mL/min, and returned to the patient. The dialysate usually flows at a rate of 500 to 800 mL/min through the dialysis filter in the direction opposite to blood flow.
COMPLICATIONS OF VASCULAR ACCESS
In cases in which a native artery or vein is not suitable for arteriovenous fistula creation, an interposing vascular graft made of an autologous vein, polytetrafluoroethylene, or bovine carotid artery must be used for vascular access. Such grafts generally are associated with a higher complication rate and shorter functional life expectancies than are natural arteriovenous fistulas. The third form of vascular access for hemodialysis is the use of tunneled­cuffed catheters. The most common site for tunneled­cuffed catheter placement is the right internal jugular vein. Because of the cuff, tunneled­cuffed catheters should not be removed by pulling.

Complications of vascular access account for more inpatient hospital days than any other complication of hemodialysis. The most common
 complications of hemodialysis vascular access are failure to provide adequate flow (300 mL/min) and infection. If referred to the ED for inadequate access flow that impairs dialysis, missing a single session should not result in uremic encephalopathy, allowing emergency dialysis for those with hyperkalemia and fluid overload in the ED (see Chapter , “Acute Kidney Injury”).
INADEQUATE FLOW
Thrombosis and stenosis of the vascular access are the most common causes of inadequate dialysis flow. Grafts generally have a higher rate of stenosis than do fistulas. Stenosis or thrombosis presents with loss of bruit and thrill over the access. Stenosis and thrombosis can be treated within
 hours by angiographic clot removal or angioplasty. Thrombosis of vascular access can also be treated with direct injection of alteplase, usually in
 conjunction with a vascular surgeon.
INFECTIONS
Vascular access infections occur in 2% to 5% of arteriovenous fistulas and approximately 10% of grafts over their functional lifetimes. Infected
 arteriovenous fistulas are at increased risk of bleeding. Patients with an infected access often present with fever, hypotension, or an elevated WBC count. The classic signs of infection of pain, erythema, swelling, and discharge from an infected vascular access are often missing. Dialysis catheter– related bacteremia is very common and potentially life threatening. After  months with a dialysis catheter, approximately half of patients develop bacteremia, with a serious complication (death, endocarditis, osteomyelitis, septic arthritis, epidural abscess) occurring in 5% to 10% of patients with bacteremia. Most authorities prefer a trial of IV antibiotics in an attempt to maintain the dialysis access before removal, the latter often done if there is
 ongoing fever after  to  days of antibiotics. To narrow the potential source of bacteremia, peripheral and catheter blood samples for culture are drawn simultaneously. A fourfold higher colony count in the catheter blood culture than in the peripheral blood culture suggests the catheter as the source of bacteremia.
The most common infecting organism is Staphylococcus aureus, followed by gram­negative bacteria. Patients with access infections usually require hospital admission, and vancomycin is the drug of choice (15 milligrams/kg or  gram IV) because of its effectiveness against methicillin­resistant
,27 organisms and long half­life (5 to  days) in dialysis patients. An aminoglycoside (gentamicin 100 milligrams IV initially and after each dialysis treatment) is added if gram­negative organisms are suspected, but the patient is monitored closely because of toxicity. Alternatives or adjuncts to IV antibiotics include removal and delayed replacement of the catheter, catheter exchange over a guidewire, and the use of antimicrobial/citrate lock solutions, although limited controlled data exist.
BLEEDING
Life­threatening hemorrhage from a vascular access is a rare but serious complication. Hemorrhage can result from aneurysms, anastomosis rupture, and over­anticoagulation. Control bleeding immediately with manual pressure applied to the puncture sites for  to  minutes, and observe the
,29 patient for  to  hours if ceased. Table 90­2 lists further options for control of hemorrhage. Consult a vascular surgeon when simple methods fail to control hemorrhage or large­volume bleeding occurs.
TABLE 90­2
Treatment Options for Control of Vascular Access Hemorrhage
Technique Comments
Direct pressure to hemorrhage site using gloved finger Hold for 5–10 min minimum, longer if needed.
initially
Absorbable gelatin sponges soaked in reconstituted Apply pressure after application for  min minimum.
thrombin, or chemical thrombotic [HemCon®]
Protamine given at a dose of .01 milligram per unit of If the dose of heparin is unknown, protamine, 10–20 milligrams, will be sufficient to reverse the heparin dispensed during dialysis typical 1000–2000 units of heparin given at dialysis.
Urgent consultation to vascular surgery The need to consult vascular surgery depends on the severity and duration of the bleeding and failure of simple methods.
Tourniquet proximal and distal to vascular access Temporizing measure only, awaiting vascular surgery, or in preparation to place a suture.
Examine for ulceration of fistula wall; ulcerated fistula may not hold suture.
Apply figure­of­eight suture Tourniquets proximal and distal to bleeding will help complete this procedure.
If all other measures fail, consider tranexamic acid  Consult a vascular surgeon prior to administration if you are able to make verbal contact.
milligrams/kg IV
Consider implementing massive transfusion protocol if Administration of blood may be needed, especially in the case of preexisting anemia.
blood loss is severe
ULCERATED HEMODIALYSIS FISTULA
An ulceration may develop due to repeated punctures of the fistula wall, yielding significant weakening and a propensity to bleed or rupture. Placing a
 figure­of­eight suture may rip the vessel wall rather than close the bleeding point. Brisk bleeding from a fistula may obscure an ulceration until bleeding is controlled with proximal and distal tourniquets. Examine the integrity of the vessel prior to placing a figure­of­eight suture.
VASCULAR ACCESS ANEURYSMS
Aneurysms result from repeated punctures; true aneurysms are very rare. Most aneurysms are asymptomatic; however, when hemorrhage occurs, it is
 frequently life threatening. Control bleeding using a tourniquet (or a blood pressure cuff) proximal and distal to the access site. Call for emergency
 consultation to vascular surgery.
VASCULAR ACCESS PSEUDOANEURYSMS
Pseudoaneurysms result from subcutaneous extravasation of blood from puncture sites. Signs are bleeding and infection at the access site. Arterial
Doppler US studies identify an aneurysm or pseudoaneurysm, and if detected, a vascular surgeon should be consulted.
VASCULAR INSUFFICIENCY
Vascular insufficiency of the extremity distal to the vascular access occurs in approximately 1% of all patients. This “steal syndrome” is the result of preferential shunting of arterial blood to the venous side of the access. Signs and symptoms are exercise pain, nonhealing ulcers, and cool, pulseless
 digits. Doppler US or angiography is the best diagnostic approach, and treatment is surgical. Consult vascular surgery.
HIGH­OUTPUT HEART FAILURE
High­output failure can occur when >20% of the cardiac output is diverted through the access. The Branham sign, a fall in heart rate after temporary access occlusion, is useful for detecting this complication. Doppler US can accurately measure access flow rate and establish the diagnosis. Surgical banding of the access is the treatment of choice to decrease flow and treat heart failure.
COMPLICATIONS DURING HEMODIALYSIS
HYPOTENSION
Low blood pressure is the most frequent complication of hemodialysis, occurring during 50% of treatments (Table 90­3). Fluid removal during hemodialysis averages  to  L over a 4­hour session, but removal of up to  L/h is possible. Maintenance of a normal blood pressure during ultrafiltration depends on cardiovascular compensatory mechanisms and refilling of the vascular space by fluid shifts from the interstitial and intracellular compartments. Excessive ultrafiltration due to underestimation of the patient’s ideal blood volume (dry weight) is the most common cause of intradialytic hypotension. Optimal dry weight is often clinically defined when hypotension prevents further fluid removal.
TABLE 90­3
Differential Diagnosis of Peridialytic Hypotension
Excessive ultrafiltration
Predialytic volume loss (GI losses, decreased oral intake)
Intradialytic volume loss (tube and hemodialyzer blood losses)
Postdialytic volume loss (vascular access blood loss)
Medication effects (antihypertensives, opiates)
Decreased vascular tone (sepsis, food, dialysate temperature >37°C or .6°F)
Cardiac dysfunction (left ventricular hypertrophy, ischemia, hypoxia, arrhythmia, pericardial tamponade)
Pericardial disease (effusion, tamponade)
Sepsis
Myocardial dysfunction from ischemia, hypoxia, arrhythmias, and early pericardial tamponade are in the differential diagnosis of intradialytic hypotension. Abnormalities of vascular tone from sepsis or antihypertensive medications also contribute to hypotension. Vascular refilling can be enhanced by improving nutrition, performing ultrafiltration before dialysis, and increasing the sodium concentration of the dialysate solution.
The timing of intradialytic hypotension is often helpful in formulating a differential diagnosis. Hypotension early in the dialysis session is usually due to preexisting hypovolemia. Predialysis losses should be suspected when the patient starts hemodialysis at a weight below his or her dry weight; consider
GI bleeding, sepsis, vomiting, diarrhea, or decreased intake of salt and water. Intradialytic blood loss can occur from blood tubing or hemodialyzer filter leaks. Hypotension near the end of dialysis is usually the result of excessive ultrafiltration, but pericardial or cardiac disease is possible.
Intradialytic hypotension produces nausea, vomiting, and anxiety. Orthostatic hypotension, tachycardia, dizziness, and syncope may occur. Treatment of intradialytic hypotension includes halting hemodialysis and placing the patient in the Trendelenburg position. If hypotension persists, the patient is given salt by mouth (broth) or normal saline, 100 to 500 mL IV. If these conservative measures fail, a more extensive evaluation is the next step.
When the patient is transferred to the ED for further evaluation, assess for adequacy of volume status, impairment of cardiac function, pericardial disease, infection, and GI bleeding. Further volume expansion or the administration of vasopressors to support blood pressure may require invasive hemodynamic monitoring in an intensive care setting.
DIALYSIS DISEQUILIBRIUM
Dialysis disequilibrium is a clinical syndrome occurring at the end of dialysis and is characterized by nausea, vomiting, and hypertension, which can
 progress to seizure, coma, and death. Dialysis disequilibrium occurs when large solute clearances occur during hemodialysis, as during the patient’s first dialysis session or during hypercatabolic states. The cause of dialysis disequilibrium is believed to be cerebral edema from an osmolar imbalance between the brain and the blood. During high solute removal, the blood has a transiently lower osmolality than the brain, which favors water movement into the brain and causes cerebral edema. This condition can be prevented by limiting solute clearance when initiating hemodialysis.

Treatment is stopping dialysis and administering  mL of 10% to 23% sodium chloride or mannitol .25 gram/kg IV to increase serum osmolality.
AIR EMBOLISM
Air embolism is always a risk when blood is pumped through an extracorporeal circuit. The clinical presentation depends on the patient’s body position at the time of the incident. If the patient was sitting, air passes retrograde through the internal jugular vein to the cerebral circulation, causing increased intracranial pressure and neurologic symptoms. In a recumbent position, air goes into the right ventricle and pulmonary circulation, causing pulmonary hypertension and systemic hypotension. The passage of air through a right­to­left shunt (e.g., patent foramen ovale) creates an arterial air embolism, which can lodge in the coronary or cerebral circulation, causing myocardial infarction or stroke.
Symptoms of an air embolism are acute dyspnea, chest tightness, and loss of consciousness, and sometimes full cardiac arrest. Signs include cyanosis and a churning sound in the heart from air bubbles in the blood. If air embolism is suspected, clamp the venous blood line and place the patient
 supine. Give 100% oxygen to aid reabsorption of the air. Other therapies for vascular air embolism include percutaneous aspiration of air from the right ventricle, IV administration of steroids, full heparinization, and hyperbaric oxygen treatment.
ELECTROLYTE DISTURBANCES
Electrolyte abnormalities can occur due to errors in mixing the dialysate concentrate with water, which results in rapid osmolar shifts and hemolysis.

However, the most common electrolyte disturbance that requires intervention is hyperkalemia ; see Chapter , “Fluids and Electrolytes,” for management. Hypoglycemia occurs in diabetic and nondiabetic ESRD patients. In addition to drugs, malnutrition and sepsis are important causes of hypoglycemia.
ED EVALUATION OF HEMODIALYSIS PATIENTS
Patients treated with hemodialysis may develop complications related to ESRD or hemodialysis, or these conditions may be incidental to the reason for the ED visit. The medical history is very important, because many of the same diseases that caused ESRD (e.g., hypertension, diabetes) persist after the patient’s kidneys have failed. The patient should be asked about the ESRD and hemodialysis (Table 90­4). Repeated episodes of intradialytic hypotension may provide important early clues to pericardial tamponade or myocardial ischemia. Repeated access infections may represent a worsening immunologic status.
TABLE 90­4
Key Historical Elements for Hemodialysis Patients
Cause of end­stage renal disease
Dialysis schedule: any missed dialysis sessions?
Still producing urine?
Recent complications of hemodialysis
Dry weight, baseline laboratory values, and vital sign values
Average intradialytic weight gain
Does patient usually make dry weight by end of hemodialysis?
Does patient experience intradialysis hypotension? (Timing of hypotension?)
Which vascular access is currently functioning?
Symptoms of uremia
Retention of native kidneys?
Identify the hemodialysis schedule; most patients in the United States are on an every­other­day schedule, with each session lasting approximately  hours. Certain centers use high­flux hemodialysis machines with higher blood flows, allowing shorter sessions. Note all missed sessions and reasons, allowing identification about medical or social issues that need to be addressed.
Dialysis patients are often knowledgeable about their dry weights and baseline laboratory test results. If not, the center the patient uses should be contacted and asked about the dry weight, average interdialytic weight gains, and any recent complications. Ask about uremic symptoms as markers of inadequate hemodialysis, and ask if the native kidneys are retained since these can be sources of hypertension, infection, and nephrolithiasis.
Examine the access site (Table 90­5), looking for the presence of flow by identifying a bruit and thrill. The classic signs of infection—erythema, swelling, tenderness, and purulent discharge—are often limited until the infection is far advanced. Look for congestive heart failure, effusion, or highoutput fistula­related heart failure; peripheral edema, hepatojugular reflux, and jugular venous distention can be present in both fluid overload and pericardial tamponade. A loud cardiac murmur may just represent increased flow secondary to anemia or the arteriovenous access. Neurologic dysfunction in hemodialysis patients is generally diffuse and nonfocal. Any focal neurologic findings require neuroimaging. Assess for GI bleeding with rectal examination and occult blood testing and obtain Doppler US examination if any question about vascular insufficiency, aneurysm, or pseudoaneurysm exists.
TABLE 90­5
Key Elements of Physical Examination of Hemodialysis Patients
Vital signs: fever, tachycardia, hypotension, hypoxia
Vascular access: bruit, thrill, erythema, warmth, swelling, tenderness, discharge, bleeding
Branham sign: bradycardia in response to compression of an arteriovenous fistula
Cardiac: signs of heart failure, murmurs, muffled (distant) heart sounds
Neurologic: mental status changes, peripheral neuropathy, asterixis
PERITONEAL DIALYSIS
TECHNICAL ASPECTS OF PERITONEAL DIALYSIS
In PD, the peritoneal membrane is the blood–dialysate interface. The amount of ultrafiltration is determined by osmotic pressure differences between the blood and dialysate, which are manipulated by changing the dialysate glucose concentration. Similar to hemodialysis, PD relies on the separate processes of clearance (solute removal) and ultrafiltration (fluid removal) to replace the functions of the nephron. Most solute removal occurs via diffusion down chemical gradients established by altering dialysate electrolyte concentrations. Dialysate is supplied in .5% and .25% glucose formulations, which can be alternated to increase or decrease ultrafiltration.
Typical PD regimens use four exchanges daily, with  L of dialysate infused and left in place for several hours before draining. During the day, approximately  L are infused and about  L are drained, for a removal of approximately  L/d of fluid. PD can be accomplished in an acute setting, over the long term via exchanges of solution throughout the day (continuous ambulatory PD), or through multiple exchanges at night while the patient sleeps (continuous cyclic PD).
COMPLICATIONS OF CONTINUOUS AMBULATORY PERITONEAL DIALYSIS
PERITONITIS

Peritonitis is the most common complication of PD, with an incidence of about one episode every  to  patient care­months. Mortality rates from peritonitis range between .5% and .5%. Symptoms and signs of peritonitis in PD patients are fever, abdominal pain, and rebound tenderness.
Cloudy effluent suggests peritonitis, confirmed by Gram stain, cell count, and culture. The cell count in PD­related peritonitis is usually >100
 leukocytes/mm, with>50% neutrophils. Results of the Gram staining are positive in only 10% to 40% of cases of culture­proven PD­related peritonitis. Organisms isolated in PD­related peritonitis are Staphylococcus epidermidis (approximately 40% of cases), S. aureus (10%), Streptococcus
 species (15% to 20%), gram­negative bacteria (15% to 20%), anaerobic bacteria (5%), and fungi (5%).
Empiric therapy begins with a few rapid exchanges of fluid lavaged to decrease the number of inflammatory cells in the peritoneum, with added heparin (500 to 1000 units/L dialysate) to decrease fibrin clot formation. A first­generation cephalosporin (e.g., cephalothin) can be mixed with the dialysate, 500 milligrams/L with the first exchange and 200 milligrams/L with subsequent exchanges. In penicillin­allergic patients, use vancomycin 500 milligrams/L and maintenance doses of  milligrams/L per exchange. If seeking gram­negative coverage, add gentamicin 100 milligrams/L and maintenance doses of  to  milligrams/L per exchange. Most recommend treating for  days after the first negative culture results, usually resulting in a total of  days of therapy. Admission decisions are based on the patient’s clinical appearance. Parenteral antibiotics are not used.
ABDOMINAL WALL COMPLICATIONS
PD Access Site Complications
Infections around a PD catheter present with pain, erythema, swelling, and discharge around the catheter exit site. The most common causative bacteria are S. aureus and Pseudomonas aeruginosa. Empiric therapy consists of an oral first­generation cephalosporin or ciprofloxacin for outpatient therapy. Refer patients to their continuous ambulatory PD centers for follow­up the next day. Abdominal wall hernias occur in 10% to 15% of PD
 patients. Immediate surgical repair of pericatheter hernias is common because of the high risk of incarceration.
ED EVALUATION OF PERITONEAL DIALYSIS PATIENTS
Table 90­6 lists important elements of patient history for PD patients. As with hemodialysis patients, the disease that caused the renal failure frequently persists.
TABLE 90­6
Key Historical Elements for Peritoneal Dialysis Patients
Cause of end­stage renal disease
Type of peritoneal dialysis (continuous ambulatory peritoneal dialysis vs. continuous cyclic peritoneal dialysis)
Peritoneal dialysis parameters: concentration, number of exchanges per day
Recent complications of peritoneal dialysis
Baseline weight, laboratory values, and vital sign values
Symptoms of uremia
Retention of native kidneys?
Still producing urine?
The physical examination focuses on the abdomen: signs of infection of the peritoneum, tunnel, and exit site should be identified (Table 90­7).
TABLE 90­7
Key Elements of Physical Examination of Peritoneal Dialysis Patients
Abdominal examination: inspection for hernia, auscultation of bowel sounds, test for rebound tenderness
Peritoneal catheter: examination of surrounding skin, palpation of tunnel
Acknowledgment
The authors acknowledge Mathew Foley, Ninfa Mehta, and Richard Sinert for their contributions to this chapter in the previous edition.


