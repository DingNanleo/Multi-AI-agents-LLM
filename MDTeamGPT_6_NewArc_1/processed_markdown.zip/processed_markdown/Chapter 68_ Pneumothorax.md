## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 68: Pneumothorax
Bret A. Nicks; David E. Manthey
INTRODUCTION AND EPIDEMIOLOGY
Pneumothorax arises when free air enters the potential space between the visceral and parietal lung pleura. Primary pneumothoraces occur without clinically apparent lung disease, either spontaneously or from penetration of the intrapleural space by trauma. Secondary pneumothoraces happen in patients with underlying lung disease.
The incidence of primary spontaneous pneumothorax admissions is .1 per 100,000 population age  years and older with a higher rate for
,2 males (20.8) than females (7.6), reflecting an increase over earlier years. Associated factors increasing the risk of occurrence include cigarette smoking, male gender, mitral valve prolapse, Marfan’s syndrome, and changes in ambient pressure. Familial patterns also suggest an inherited
 association. Physical activity or exertion can precipitate pneumothorax but is not a common pneumothorax­triggering factor. Traumatic pneumothoraces are iatrogenic or noniatrogenic. Noniatrogenic pneumothoraces are discussed in the Chapter 261, “Pulmonary Trauma.”
,3
Causes of secondary spontaneous pneumothorax are listed in Table 68­1. Chronic obstructive pulmonary disease is the most common cause.
Pneumothorax occurs in 5% of patients with acquired immunodeficiency syndrome, often from subpleural necrosis secondary to Pneumocystis infection, and carries a high mortality. Because of a continued air leak due to necrosis of lung tissue, simple aspiration fails as treatment in this group of patients.
TABLE 68­1
Causes of Secondary Pneumothorax
Airway disease
Chronic obstructive pulmonary disease
Asthma
Cystic fibrosis (8%–20% will develop one in lifetime)
Interstitial lung disease
Sarcoidosis
Pulmonary fibrosis
Tuberous sclerosis
Infection
Human immunodeficiency virus infection, Pneumocystis pneumonia
Tuberculosis
Bacterial pneumonia, necrotizing
Lung abscess
Connective tissue disease
Marfan’s syndrome
Ehlers­Danlos syndrome
Scleroderma
Rheumatoid arthritis
Cancer

Chapter 68P: rPimnaeruym luontgh oorr maxe,t aBsrteatt icA d. iNseicaskes; David E. Manthey 
. Terms of Use * Privacy Policy * Notice * Accessibility
Catamenial pneumothorax
Hemopneumothorax occurs in 2% to 7% of patients with secondary pneumothorax; if associated with a large amount of blood in the pleural cavity, this
4­8 can be life threatening. Treating the underlying disease may help decrease the risk of future pneumothorax.
PATHOPHYSIOLOGY
Under normal conditions, the parietal and visceral pleura are in contact, sliding on each other. The pleural space is under negative and dynamic pressure (–5 mm Hg with fluctuations of  to  mm Hg between inspiration and expiration). The tendency of the chest wall is to expand and for the lungs to collapse from elastic recoil. With the loss of the normal negative pressure in the pleural space that “adheres” the visceral pleura (lungs) to the parietal pleura (ribs), the affected lung collapses. A primary spontaneous pneumothorax occurs when a subpleural bleb ruptures, disrupting pleural
7­9 integrity and usually involving the lung apex. In secondary spontaneous pneumothoraces, disruption of the visceral pleura occurs secondary to underlying pulmonary disease processes.
Once there is a break in the visceral pleura, air travels down a pressure gradient into the intrapleural space, until pressure equilibrium occurs with partial or total lung collapse. Altered ventilation–perfusion relationships and decreased vital capacity contribute to dyspnea and hypoxemia. If air continues to enter the pleural space, intrapleural pressure becomes positive. Tension pneumothorax develops as inhaled air accumulates in the pleural space but cannot exit due to a one­way valve system. As intrathoracic pressure (>15 to  mm Hg) increases, venous return and cardiac and lung
 function are severely restricted, resulting in hypoxemia and shock.
CLINICAL FEATURES
Classic symptoms of primary spontaneous pneumothorax are sudden onset of dyspnea and ipsilateral, pleuritic chest pain. The pleuritic component may resolve within the first  hours. Profound dyspnea is rare unless the patient has poor reserve due to underlying parenchymal disease or develops a tension pneumothorax. Sinus tachycardia is the most common physical finding. Other classic (albeit uncommon) findings include ipsilateral decreased breath sounds, hyperresonance to percussion, and decreased or absent tactile fremitus. In traumatic pneumothorax, the positive predictive
 value of decreased breath sounds is 86% to 97% for the diagnosis. Physical exam alone is not sensitive enough to exclude the diagnosis.
The clinical hallmarks of tension pneumothorax are tracheal deviation away from the involved side, hyperresonance of the affected side,
 hypotension, and profound dyspnea.
DIAGNOSIS
Pneumothorax is an important consideration in patients with chest pain or shortness of breath, especially in those with underlying lung disease.
Patients with pleurisy, pleural effusions, infiltrates, or shingles can present with symptoms like those with pneumothorax.
IMAGING
Chest Radiograph
A standard erect posteroanterior chest radiograph is the usual initial test and demonstrates loss of lung markings in the periphery and a pleural line that runs parallel to the chest wall (Figure 68­1). Ensure that the line does not extend outside of the chest cavity, suggesting a confluence of shadows
 or skin line. A lateral radiograph identifies an existing pneumothorax in an additional 14% of cases. An expiratory radiograph does not identify many additional pneumothoraces. The sensitivity of anteroposterior chest radiography, when compared with CT, was .5% (95% confidence interval, .7%
11­13 to .2%), with a specificity of 100% (95% confidence interval, .1% to 100%). In critically ill patients who cannot be moved to an erect position, look for the deep sulcus sign, a profound lateral costophrenic angle, on the affected side.
FIGURE 68­1. Spontaneous hemopneumothorax. Upright chest radiograph of a 19­year­old male college student with spontaneous hemopneumothorax. Note the large air­fluid level in the inferior portion of the right hemithorax in addition to the complete collapse of the entire right lung. [Reproduced with permission from Stone CK, Humphries RL (eds): Current Diagnosis & Treatment: Emergency Medicine, 8th ed. New York: McGraw­Hill Education, Inc. ©
2017. Fig 24­2.]
Large bullae in patients with chronic obstructive pulmonary disease may look like a pneumothorax, although a pneumothorax pleural line will run parallel with the chest wall, whereas bullae will have a medially concave appearance. Pneumothoraces usually cross more than one lung segment, whereas bullae follow a single lobe. A chest CT scan can differentiate these. Placing a chest tube inserted into a bulla mistaken for a pneumothorax
 results in a large pneumothorax, associated bronchopulmonary fistula, and other complications. Pleural adhesions can cement the visceral and parietal pleura together, changing the appearance of the pneumothorax.
Pneumothorax size calculations use measurement from the apex of the lung to the cupula of the thoracic cavity on an upright posteroanterior
,14 film. A measurement of <3 cm in this cephalad area is considered a small pneumothorax. Another method is to measure the interpleural distance
,15 at the level of the hilum; in this area, a distance of  cm correlates with a pneumothorax of approximately 50% by volume. The British Thoracic
Society defines a small pneumothorax as one with a <2­cm rim between the lung edge and chest wall; a large pneumothorax is defined as one with a
≥2­cm rim. ,15
US
US detects traumatic pneumothorax, with a reported sensitivity of .1% (95% confidence interval, .9% to .9%) and specificity of .2% (95%
,17 confidence interval, .6% to .9%). The movement of the lung (ocean) against the stationary chest wall (shore) is referred to as the “seashore.” In a normal lung, there is a sonographic reverberation distal to the pleura that looks like a comet tail and a sliding sign of the movement of the visceral pleura along the parietal pleura (Figure 68­2); these are not seen in pneumothorax. In loculated pneumothoraces (from adhesions), the sliding sign
,19 and the comet tail findings are altered and limit the specificity for pneumothorax. In addition, a bleb point may lose a sliding sign and inaccurately
 suggest a pneumothorax.
FIGURE 68­2. US with M­mode and B­mode imaging of normal (A) and abnormal (B) pleura. [Image used with permission of Casey Glass, MD, Wake Forest School of
Medicine.]
Chest CT

Chest CT detects an additional 25% to 40% of pneumothoraces not seen on plain chest radiographs. CT can detect other pathology such as pulmonary blebs. If a chest radiograph does not demonstrate pneumothorax but there is clinical suspicion for the condition (e.g., in symptomatic highrisk patients, those with underlying lung disease or positive­pressure ventilation, or after lung biopsy), obtain a chest CT (Figure 68­3).
FIGURE 68­3. Secondary spontaneous pneumothorax. CT of a large, left­sided secondary spontaneous pneumothorax. Note diffuse bullous emphysema.
TREATMENT
The ED treatment goal is the elimination of intrapleural air. Tension pneumothorax is a clinical diagnosis—ideally before a radiograph—and is immediately treated by needle decompression and/or a tube thoracostomy.
Treatment options are oxygen, observation, needle or catheter aspiration (either single or sequential aspirations), and tube thoracostomy (either small­size or standard chest tube) (Tables 68­2 and 68­3). Oxygen administration (>28%) increases pleural air resorption three­ to fourfold over the
20­22 base .25% reabsorbed per day by creating a nitrogen gas pressure gradient between the alveolus and trapped air. Without supplemental oxygen, a 25% pneumothorax would take approximately  days to resolve. Recommended oxygen dosing ranges from  L/min by nasal cannula to  L/min by mask. Monitor for hypercapnia in patients with chronic obstructive pulmonary disease.
TABLE 68­2
Criteria for Stable Patient With Pneumothorax
Respiratory rate <24 breaths/min
No dyspnea at rest, speaks in full sentences
Pulse >60 and <120 beats/min
Normal blood pressure for patient
Room air oxygen saturation >90%
Absence of hemothorax
TABLE 68­3
Aspiration and Thoracostomy Devices* Single aspiration Insertion of a needle or catheter, aspiration of air using an attached syringe, and immediate removal of the device
Needle aspiration 18­gauge needle (provided in kits as an 8F catheter over an 18­gauge needle)
Small­size catheter ≤14F
Small­size chest tube 10F–14F
Pigtail catheter 14F, placement using Seldinger technique
Moderate­size chest tube 16F–22F
Large­size chest tube 24F–36F
∗
The term “catheter” is used for a thin flexible tube; the term “chest tube” is used for a more rigid, larger tube. French (F) sizes represent tube or catheter diameter
(1 French = 1/ ­mm diameter), and the larger the French number, the larger the device.

Observation is appropriate for small, stable pneumothoraces. If selecting this option, observe the patient for at least  hours on supplemental oxygen, and repeat the chest radiograph. If symptoms and chest radiograph improve, the patient should return in  to  weeks for repeat examination.
First­time spontaneous pneumothorax of <20% lung volume in a stable, healthy adult is a scenario where initial oxygen therapy and observation are
20­25 possible.
Aspiration or tube thoracostomy therapy is based on the likelihood of recurrence and likelihood of spontaneous resolution. Pneumothoraces in patients with underlying pulmonary disease are likely to recur. Large (>2 cm) pneumothoraces and those with an air leak are also unlikely to resolve without drainage. Inability to return for care or to tolerate any pneumothorax increase (i.e., those with poor cardiopulmonary reserve) should prompt drainage.
Many factors guide interventions: The stability of the patient, the degree of symptoms, the size and relative change in size over time, the cause of the pneumothorax, the degree of underlying lung disease, the presence of a hemothorax, the likelihood of recurrence and resolution, and the need for
15­17,20­27 positive­pressure ventilation are factors to consider (Tables 68­2, 68­3, and 68­4).
TABLE 68­4
Treatment of Pneumothorax
Condition Treatment Options
Small primary pneumothorax (<20% or  cm Observation for >3 h on oxygen, repeat chest radiograph, discharge if no symptoms, and return for apex­cupula and asymptomatic) evaluation if symptoms recur or in  wk or
Small­size catheter aspiration with immediate catheter removal, then observe for >3 h, discharge if no symptoms, and return for evaluation if symptoms recur in  wk or
Small­size catheter aspiration or small­size chest tube insertion, Heimlich valve, or water seal and admission
Small secondary pneumothorax Small­size catheter or small­size chest tube insertion, Heimlich valve, or water seal and admission
Large pneumothorax, either primary or Moderate­size chest tube and admission; large­size chest tube if fluid or hemothorax present; water secondary, or bilateral pneumothoraces seal and admission
Tension pneumothorax Immediate needle decompression followed by moderate or large­size chest tube insertion, water seal drainage, and admission; immediate chest tube placement ideal
The selection of catheter or chest tube size is based on the flow rate of air that the device can accommodate. Select large­bore tubes for anticipated bigger air leaks, notably from mechanical ventilation. Tension pneumothorax can develop if a large air leak develops despite small­bore tubes or catheters. Every chest tube has a proximal hole, called the sentinel eye, which is visible radiographically and helps ensure that all drainage holes are
27­31 inside the pleural cavity.
NEEDLE DECOMPRESSION
To decompress, use a 14­gauge needle for adults at least  inches (5 cm) long to penetrate the pleural cavity. Two locations are optimal: into the second intercostal space just above the rib (to avoid the intercostal artery) at the midclavicular line, or in the fourth intercostal space just above the rib and at the anterior axillary line (Figure 68­4). Recent studies suggest a decompression success rate of only 65% using these
31­33 approaches and a 51­mm needle; a longer needle may be necessary. If the needle insertion is medial to the midclavicular line, mediastinal vessels can be injured.
FIGURE 68­4. Needle placement for decompression of a right­sided tension pneumothorax. A site for a needle thoracostomy is the 2nd intercostal space in the midclavicular line, or the 4th intercostal space at the anterior axillary line.
NEEDLE OR CATHETER ASPIRATION
Needle or catheter aspiration is as effective as thoracostomy for treating the first episode of small primary or secondary spontaneous
  pneumothorax, with success ranging from 37% to 75% and higher in those with primary spontaneous pneumothorax. Techniques include simple one­time aspiration with a large­gauge needle or a small­bore catheter, repeated aspirations through a small­size catheter, or chest tube attached to a one­way valve (including the Heimlich valve) or water seal drainage. The catheter technique has the advantages of both aspiration and chest tube
 placement.
Small­Size Catheters
The catheter technique involves placing a small catheter either into the second anterior intercostal space in the midclavicular line or laterally at the fourth or fifth intercostal space in the anterior axillary line after local anesthesia and sterile preparation. Attach a three­way stopcock and use a 60­mL syringe to aspirate the pleural space until resistance is met, often triggering a cough. Close the stopcock, secure the tube, and obtain a follow­up chest radiograph to ensure lung reexpansion. Aspiration of more than  L suggests continued air leak and failure of simple aspiration. Failure of the lung to fully expand warrants formal tube thoracostomy and admission.
Pigtail Catheters Using Seldinger Technique
Advantages of this technique are a smaller incision, less tissue dissection, and smaller scar. Insert the needle into the pleural space, making sure
,30 placement is in the “triangle of safety” (Figure 68­5). Aspirate fluid or air to verify location in the pleural space, and advance a guidewire through the needle. Place a dilator over the guidewire until entering the pleural space. Remove the dilator and place the chest tube over the wire into the pleural space. Remove the wire, secure the tube, and attach to suction.
FIGURE 68­5. Safe location of chest tube, within a triangle bordered by the fifth intercostal space, pectoralis major, and latissimus dorsi.
Tube Thoracostomy
Chest tube thoracostomy is best for treating a large pneumothorax, recurrent or bilateral pneumothorax, or coexistent hemothorax, or if there are abnormal vital signs or dyspnea. A chest tube aids care for those with small spontaneous secondary pneumothoraces where large air leak is anticipated or noted. Standard chest tube thoracostomy with underwater seal drainage is the most commonly used approach, with a low complication
,26 rate and a success rate of 95%. Most guidelines suggest a 10F to 14F chest tube for nontraumatic pneumothoraces, reserving larger 14F to 22F chest tubes if a large air leak is probable, such as from mechanical ventilation or with underlying pulmonary disease. Chapter 261, “Pulmonary
Trauma,” describes the procedure. (See Video: Chest Tube Insertion.)
Video 68­1: Chest Tube Insertion
Used with permission from Henderson McGinnis, Department of Emergency Medicine, Wake Forest University Baptist Medical Center; Judith E. Tintinalli, David Cline,
O. John Ma.
Play Video

There is no clear difference between simple aspiration and intercostal tube drainage in overall short­ and long­term outcomes, and simple aspiration
 is safe and effective for a small­volume air leak primary spontaneous pneumothorax. Pleurodesis helps prevent recurrence in those with first spontaneous pneumothorax with a persistent air leak, second spontaneous pneumothorax, bilateral spontaneous pneumothoraces, first episode of a
,9 secondary pneumothorax, or recurrent high­risk activities (flying or diving).
TREATMENT COMPLICATIONS
Complications of a pneumothorax can include those due to hypoxia, hypercapnia, and hypotension. Reexpansion lung injury is uncommon and seen more often when there is collapse of the lung for >72 hours, a large pneumothorax, rapid reexpansion, or negative pleural pressure suction of >20
,9  cm. Most patients need no treatment for reexpansion injury aside from observation or oxygen, with few adverse outcomes.
Intervention complications include intercostal vessel hemorrhage, lung parenchymal injury, empyema, and tube malfunction (development of an air leak or tension pneumothorax).
SPECIAL CONSIDERATIONS
IATROGENIC PNEUMOTHORAX
Iatrogenic pneumothorax is a subset of traumatic pneumothorax; it occurs more often than spontaneous pneumothorax and is common,
,27,35 underdetected, and underreported. Transthoracic needle procedures (needle biopsy and thoracentesis) account for approximately half of iatrogenic pneumothoraces, and subclavian vein catheterization accounts for one fourth. Factors associated with the increasing frequency of iatrogenic pneumothorax include the patient population, underlying disease, body habitus, and experience of the operator. US guidance for central venous catheter insertion for thoracentesis reduces the pneumothorax complication rate.
Although it is routine to obtain a chest radiograph after central line placement or transthoracic needle procedures, this may not identify a
 pneumothorax if supine or if there is inadequate time for the pneumothorax to develop, with up to one third detected later. Bedside US is an excellent rapid alternative to chest radiograph to detect central venous catheter misplacement and iatrogenic pneumothorax, with a reported
 specificity of 99% and sensitivity of 68%.
Treatment for iatrogenic pneumothorax is the same as that for spontaneous pneumothorax. Patients with a small pneumothorax after a needle puncture and those not requiring positive­pressure ventilation are often observed or treated with simple catheter aspiration (with or without a

Heimlich valve), which is adequate for 60% to 80% of patients. Long­term recurrence is not a concern with iatrogenic pneumothorax.
AIR TRANSPORT WITH PNEUMOTHORAX
Increased elevation causes an increase in gas volume (Boyle’s law), increasing the risk for tension pneumothorax in air transport patients with
 pneumothorax, particularly when transported in fixed­wing vehicles (airplane) given the altitudes reached. Air medical experts recommend no highaltitude flying for at least  to  days after pneumothorax resolution.
DIVING
Similarly and also due to Boyle’s law, development of a pneumothorax at depth may lead to a tension pneumothorax with ascent. Current guidelines suggest that a history of spontaneous pneumothorax is a contraindication to underwater diving unless treated by surgical pleurectomy and normal
 lung function exists.
DISPOSITION
Discharge to home patients with a primary spontaneous pneumothorax successfully treated with observation or with catheter aspiration if the pneumothorax does not increase in size over  to  hours and symptoms resolve or do not worsen. Observe for longer or admit the remaining patients.


