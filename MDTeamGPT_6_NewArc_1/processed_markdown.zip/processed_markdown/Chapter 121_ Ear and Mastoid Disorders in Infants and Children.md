## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 121: Ear and Mastoid Disorders in Infants and Children
Carmen M. Coombs
INTRODUCTION
Ear pain, or otalgia, is one of the most common pediatric outpatient chief complaints. The differential diagnosis is listed in Table 121­1. This chapter discusses acute otitis media, otitis media with effusion, otitis externa, acute mastoiditis, and foreign body. The ear is divided into three major parts: (1) the outer ear, which includes the auricle/pinna and the external auditory canal; (2) the middle ear, which is bound by the tympanic membrane laterally, contains the auditory ossicles, and is connected to the nasopharynx via the eustachian tube; and (3) the inner ear, which includes the semicircular canals, the cochlea, and the auditory nerve (Figure 121­1).
TABLE 121­1
Differential Diagnosis of Acute Ear Pain
Common
Acute otitis media
Otitis externa
Foreign body in the external ear canal
Impacted cerumen
Less common
Cholesteatoma
Referred pain from oral cavity pathology (e.g., dental caries and infections, pharyngitis)
Cellulitis of the auricle/pinna
Contact dermatitis (e.g., earrings)
Trauma to the auricle/pinna (e.g., hematoma with pressure necrosis of cartilage)
Physical trauma or barotrauma to the tympanic membrane and middle ear
Rare
Mastoiditis
Herpes zoster oticus (Ramsay Hunt syndrome)
Hemotympanum due to basilar skull fracture
Rhabdomyosarcoma of the ear or temporal bone
FIGURE 121­1. Anatomy of the outer, middle, and inner ear.

Chapter 121: Ear and Mastoid Disorders in Infants and Children, Carmen M. Coombs 
. Terms of Use * Privacy Policy * Notice * Accessibility
ACUTE OTITIS MEDIA
EPIDEMIOLOGY
Acute otitis media (AOM) is the acute onset of signs and symptoms of middle ear inflammation. Although the incidence is decreasing in the postpneumococcal vaccine era, otitis media remains the third most common diagnosis for ED visits in children under  years old, accounting for .1%
 of all ED visits.

The peak incidence of AOM is between  and  months of age. Recent U.S. studies found that 23% to 46% of children had at least one episode of AOM
,3  by the age of  year, and this rate increased to 60% by the age of  years. Risk factors include male sex, non­Hispanic white race, family history of
 recurrent AOM, day care attendance, and early occurrence of the first episode of AOM before  year of age. The incidence is also higher in children
 ,3 with atopy, craniofacial anomalies, and immunodeficiency syndromes. Breastfeeding in infancy is protective and decreases the risk of AOM.
PATHOPHYSIOLOGY
In the healthy state, the middle ear is aerated via the eustachian tube and its connection to the nasopharynx (Figure 121­1). If the eustachian tube becomes obstructed due to inflammatory edema and/or mucus (often associated with a viral upper respiratory infection), middle ear secretions build up and create conditions favorable to the development of AOM. Compared with adults, the eustachian tube in children is shorter and more horizontally oriented. This orientation is the anatomic rationale for the increased incidence of middle ear disease seen in children.
Microorganisms responsible for AOM originate from the nasopharynx and enter the middle ear space via the eustachian tube. Bacteria can be isolated in 55% of cases of AOM in young children. The most common bacterial pathogens include Streptococcus pneumoniae (23.6%), nontypeable

Haemophilus influenzae (29.1%), Streptococcus pyogenes (3.7%), and Moraxella catarrhalis (2.8%). Common viruses identified in cases of AOM
 include picornaviruses (e.g., rhinovirus, enterovirus), respiratory syncytial virus, and parainfluenza virus.
CLINICAL FEATURES
The classic symptom is rapid­onset ear pain. Young or nonverbal children may hold, tug, or rub the ear or be fussy and irritable. Fever is present in many but not all cases. Fever ≥40.5°C (104.9°F) is rare and should prompt consideration of alternative diagnoses.  Older children may complain of decreased hearing due to conductive hearing loss from middle ear effusion. An antecedent history of rhinorrhea, congestion, and/or cough is common because an upper respiratory tract infection creates conditions favorable to the development of AOM.
The most common acute complication is tympanic membrane perforation, which typically heals spontaneously after the AOM resolves. More serious acute complications are rare and include mastoiditis, spread to the intracranial cavity (meningitis, encephalitis, abscess, sinus thrombosis, otitis hydrocephalus, or facial or abducens nerve palsy), and involvement of the inner ear (labyrinthitis). Acquired sensorineural hearing loss can result from chronic or recurrent AOM and secondary inflammatory changes in the inner ear.
DIAGNOSIS
The diagnosis is clinical. Tympanocentesis is the gold standard for diagnosis, but is outside the scope of most pediatricians and emergency providers.

The three different clinical scenarios that meet the criteria for diagnosis are listed in Table 121­2. Erythema of the tympanic membrane alone is insufficient for the diagnosis of AOM because erythema can be caused by middle ear inflammation, crying, or fever.
TABLE 121­2
Clinical Criteria for the Diagnosis of Acute Otitis Media (AOM)
Scenario Moderate to severe bulging of the tympanic membrane

Scenario Mild bulging of the tympanic membrane and at least  of the following:
 Acute onset of ear pain (<48 h)
Intense erythema of the tympanic membrane
Scenario New onset of otorrhea not due to otitis externa or foreign body (indicating perforation of the tympanic membrane or AOM in a child with
 tympanostomy tubes)
For proper otoscopic examination, use a bright light source, clean otoscope head, and properly fitting speculum. To immobilize the child’s head, have the caregiver hold the child’s head against the caregiver’s shoulder or chest or place the child supine with the examiner controlling the head of the child and the parents holding the child’s arms. Remove impacted cerumen with a soft speculum or by gently irrigating the canal with warm water. Both procedures can cause pain and/or traumatic perforation of the tympanic membrane and must be done carefully. Adjunctive use of a topical
 ceruminolytic agent such as docusate may be helpful in some cases.
Assess for the presence or absence of discharge in the ear canal and the tympanic membrane’s position, color, and degree of translucency. A normal tympanic membrane is flat, pearly gray, and translucent (Figure 121­2). Erythema and bulging of the tympanic membrane are consistent with AOM
(Figure 121­3).
FIGURE 121­2. Normal right tympanic membrane (TM). TM is flat, pearly gray, and translucent. [Image used with permission of Dr. Shelagh Cofer, Department of
Otolaryngology, Mayo Clinic.]
FIGURE 121­3. Tympanic membrane findings consistent with acute otitis media. A. Severe bulging and opaque. B. Moderate bulging and opaque with intense erythema. C. Mild bulging with intense erythema. [Photos used with permission of Alejandro Hoberman, Department of Pediatrics, Children’s Hospital of Pittsburgh.]
TREATMENT

Most cases of AOM resolve spontaneously and without complications. Antibiotics are recommended for some but not all cases of AOM. Pain control, however, is an essential treatment modality and should be provided whether or not antibiotics are prescribed.
PAIN CONTROL
The medications most commonly used to treat ear pain are shown in Table 121­3. Ibuprofen and acetaminophen are the first­line agents and have the added benefit of also being antipyretics. Opioid medications such as oxycodone and hydrocodone may be considered for severe ear pain, but should be used rarely and reserved as second­line agents. Topical otic analgesic drops may be used in combination with systemic analgesics because
,10 they have a rapid onset and may provide temporary relief of ear pain, but they have a short duration of action. Topical analgesics are contraindicated in patients with perforation of the tympanic membrane and those with tympanostomy tubes.
TABLE 121­3
Treatment of Ear Pain From Acute Otitis Media
Medication Comments
Systemic
Ibuprofen (10 milligrams/kg PO every  h PRN) First­line agents
Also work as an antipyretic
Acetaminophen (15 milligrams/kg PO/PR every  h PRN)
Oxycodone (0.1 milligram/kg PO every  h PRN) Second­line agents
Consider for severe otalgia
Hydrocodone (0.2 milligram/kg PO every  h PRN)
Topical
Antipyrine/benzocaine (2–3 drops every 1–2 h PRN) Apply drops to a small piece of cotton and place in external ear canal
Provide rapid but short­term relief
Lidocaine (2% aqueous) (2–3 drops every 1–2 h PRN) Contraindicated with perforation or tympanostomy tubes
Abbreviation: PRN = as needed.
OBSERVATION OR ANTIBIOTICS
Some but not all cases of AOM require treatment with antibiotics. Consensus guidelines from the American Academy of Pediatrics and
American Academy of Family Physicians recommend an initial observation option (defined as withholding immediate antibiotics) for select children
 with AOM. An observational approach for AOM has been used successfully in areas of Europe with similar rates of mastoiditis (the primary
 suppurative complication of AOM) compared to the United States, and this approach is now supported by several randomized controlled trials,
 systemic reviews, and observational studies. Tables 121­4 and 121­5 describe which children can initially be observed without antibiotics and which children require initial antibiotics.
TABLE 121­4
Indications for Consideration of Initial Observation for Acute Otitis Media (AOM)7
Children 6–23 mo old with unilateral AOM without severe signs or symptoms
Mild ear pain for <48 h
Temperature <39°C (102.2°F)
Children ≥24 mo old with unilateral or bilateral AOM without severe signs or symptoms
Mild ear pain for <48 h
Temperature <39°C (102.2°F)
Note: When observation is used, a mechanism must be in place to ensure follow­up and initiation of antibiotics if the child worsens or fails to improve within  to
 hours of onset of symptoms.
TABLE 121­5
Indications for Initial Antibiotic Use for Acute Otitis Media (AOM): No Observation Period7
All infants <6 mo old
All children with severe signs or symptoms
Moderate or severe ear pain or
Ear pain for ≥48 h or
Temperature >39°C (102.2°F)
Children <24 mo old with bilateral AOM
Recurrent AOM (prior episode of AOM within 2–4 wk)
AOM with perforation
Patients with myringotomy (pressure­equalizing) tubes in place
Patients with craniofacial abnormalities
Immunocompromised patients
Any child with AOM if the provider or caregiver is not comfortable with initial observation
If acceptable to both the provider and caregivers, initial observation is appropriate for otherwise healthy children with uncomplicated AOM without severe signs or symptoms (mild ear pain for <48 hours and temperature <39°C [102.2°F]) who are  to  months old with unilateral AOM and children
≥24 months old with unilateral or bilateral AOM (Table 121­4).  Provide follow­up in  to  hours, and initiate antibiotics only for worsening symptoms or lack of improvement. A wait­and­see antibiotic prescription can be provided at the initial visit with instructions for the caregiver to initiate antibiotics if the child worsens or fails to improve. Patients who do not meet the criteria for an initial period of observation require prompt treatment with antibiotics and include children who are <6 months old, have severe signs or symptoms, are <24 months old with bilateral AOM, have recurrent

AOM, have AOM with perforation, have myringotomy tubes, and/or have underlying craniofacial abnormalities or immunodeficiencies (Table 121­5).
CHOICE OF INITIAL ANTIBIOTICS
Initial antibiotic treatment for AOM in which antibiotics are prescribed is shown in Table 121­6. High­dose amoxicillin (45 milligrams/kg per dose PO
 twice daily) for  to  days is the first­line treatment. The higher dose achieves concentrations in the middle ear that exceed the minimum inhibitory concentration for highly resistant forms of S. pneumoniae. Alternative regimens are appropriate for children with penicillin allergies, children who have received amoxicillin in the past  days, children with concurrent conjunctivitis, children with myringotomy tubes, and those unable to tolerate
 oral treatment (Table 121­6).
TABLE 121­6
Initial Antibiotic Treatment for Uncomplicated Acute Otitis Media (AOM)7
Antibiotic Dosing
First­line treatment
AOM (with or without tympanic membrane Amoxicillin 40–45 milligrams/kg/dose PO  times daily for 5–10 d perforation)
Special situations
Penicillin allergy Cefdinir  milligrams/kg/dose PO  times daily for 5–10 d
Cefuroxime  milligrams/kg/dose PO  times daily for 5–10 d
Cefpodoxime  milligrams/kg/dose PO  times daily for 5–10 d
Clindamycin  milligrams/kg/dose PO  times daily for 5–10 d
Amoxicillin received in past  d Amoxicillin­  milligrams/kg/dose PO of amoxicillin with .2 milligrams/kg/dose of clavulanate  or clavulanate times daily for 5–10 d
Concurrent purulent conjunctivitis or
History of recurrent AOM unresponsive to amoxicillin
Myringotomy tubes Ofloxacin otic  drops in affected ear twice daily for 5–10 d drops
Unable to tolerate PO antibiotics Ceftriaxone  milligrams/kg/dose IM or IV once daily for 1–3 d
With initiation of appropriate antibiotics, fever and ear pain should be expected to persist for  to  hours. If symptoms persist >48 or  hours after antibiotic therapy has been initiated, however, reevaluate and consider adjusting antibiotics. Management of AOM after failure of initial antibiotic is shown in Table 121­7. If high­dose amoxicillin fails, change to amoxicillin­clavulanate or ceftriaxone to provide coverage against β­ lactamase–producing M. catarrhalis and nontypeable H. influenzae. If the second antibiotic regimen fails, treat with clindamycin and a third­generation cephalosporin, or consult ear, nose, and throat for tympanocentesis and culture (Table 121­7).
TABLE 121­7
Management of Acute Otitis Media After Failure of Antibiotic Regimen7
Management Dosing
Failure of initial antibiotic (amoxicillin)
First­line Amoxicillin­clavulanate  milligrams/kg/dose of amoxicillin with .2 mg/kg/d of clavulanate  times treatment daily for  d
Ceftriaxone  milligrams/kg/dose IM or IV once daily for  d
Penicillin allergy Clindamycin 10–12 milligrams/kg/dose PO  times daily for  d
Failure of second antibiotic
Treatment Clindamycin + third­generation cephalosporin 10–12 milligrams/kg/dose PO  times daily for  d options
Consult an otolaryngologist for tympanocentesis and culture
A suggested algorithm for the diagnosis and treatment of AOM is illustrated in Figure 121­4. FIGURE 121­4. Algorithm for management of acute otitis media (AOM). TM = tympanic membrane.
OTITIS MEDIA WITH EFFUSION
Otitis media with effusion (OME) is fluid in the middle ear space without clinical signs of inflammation or acute symptoms of illness. OME can occur spontaneously as a result of poor eustachian tube function, but more commonly results from an inflammatory response after an episode of AOM.

More than  million episodes of OME are diagnosed annually in the United States, with an estimated annual cost of $4 billion. The peak incidence is
 between  months and  years of age, and 90% of children will be affected at some time before school age.
Many children with OME are asymptomatic. In some children, however, the effusion can cause mild intermittent ear pain, fullness, or a popping sensation. Because the effusion can impair the mobility of the tympanic membrane, mild to moderate conductive hearing loss in the range of  to  dB can occur and can have adverse effects on speech, language, and learning in the developing child. Children at higher risk of complications of OME include those with permanent hearing loss (independent of OME), speech and language delays, autism or other developmental disorders, Down
 syndrome, craniofacial abnormalities (e.g., cleft palate), and blindness.
DIAGNOSIS
Diagnosis is by pneumatic otoscopy. A cloudy tympanic membrane often with a visible effusion (visualized as either an air­fluid level or bubbles) and with significantly impaired mobility is the classic otoscopic finding of OME (Figure 121­5). Although there is overlap of some of the otoscopic findings of OME and AOM, it is important to remember that the disorders are separate entities and distinguishing between the two is essential. The critical distinguishing feature is that AOM has acute signs and symptoms of inflammation and OME does not.
FIGURE 121­5. Well­appearing toddler with middle ear effusion. Note slight bulging of tympanic membrane and visible fluid level. [Image used with permission of Dr.
Shelagh Cofer, Department of Otolaryngology, Mayo Clinic.]
TREATMENT

Close to 90% of episodes of OME resolve spontaneously and without complications. Management depends on whether or not children are at risk for
 complications. Watchful waiting is appropriate for children with OME who are not at risk for complications. Intranasal or systemic steroids,
 antibiotics, antihistamines, and decongestants can cause more harm than benefit and should not be used. Children should follow up with their pediatrician and be reexamined at 3­ to 6­month intervals until the effusion is no longer present, significant hearing loss is identified, or structural
 abnormalities of the eardrum or middle ear are suspected. Hearing and language testing is recommended if OME lasts >3 months or at any time that
 hearing loss or language delay is suspected in a child with OME.
Otolaryngology referral is important for all at­risk children with OME and any child with a complication from OME, recurrent OME, or symptomatic OME
,15 lasting >3 months. Tympanostomy tube placement may be indicated.
ACUTE OTITIS EXTERNA
Acute otitis externa is an infection of the external ear canal associated with diffuse inflammation and often significant edema. The peak incidence
 occurs in children between  and  years of age, and cases are more common in the summer than in the winter. The most common risk factor is hyperhydration and maceration of the epithelial layer lining the canal, often induced when a child is submerged during swimming (“swimmer’s ear”).
Mechanical debridement of the epithelial layer (e.g., as can occur with a cotton swab inserted in the canal to clean to the ear) is also an important risk factor. Approximately 98% of cases in North America are due to invasive bacteria, the most common of which is Pseudomonasaeruginosa followed by
17­19
Staphylococcus aureus and Staphylococcus epidermidis. Polymicrobial infection is common, and different bacteria often coexist. Fungal infection is rare in primary acute otitis externa and is more commonly associated with chronic otitis externa.
CLINICAL FEATURES
The early stages of otitis externa are characterized by a sense of ear fullness and itching. As the disease progresses, pain becomes prominent and is often severe and exacerbated by manipulation of the auricle as well as by any movement of the jaw. A purulent and sometimes foul­smelling discharge can develop and fill the canal. Because the discharge and canal edema can obstruct sound waves, temporary hearing loss may be present. In the severe form of otitis externa, further anterior spread can cause tenderness and inflammation of the surrounding lymphoid and subcutaneous tissue. Rarely, posterior spread can involve the mastoid or can cause osteomyelitis of the skull. Malignant otitis externa is osteomyelitis of the ear canal and should be suspected with the presence of fever >38.9°C (102°F), severe otalgia, and/or facial paralysis or meningeal signs.
DIAGNOSIS
Diagnosis is clinical. According to the American Academy of Otolaryngology–Head and Neck Surgery Foundation, a diagnosis of otitis externa requires the rapid onset (within  hours) in the past  weeks of at least one primary symptom (otalgia, itching, or fullness) and one primary sign (tenderness of
 the tragus/pinna or diffuse ear canal edema/erythema) of ear canal inflammation (Table 121­8).
TABLE 121­8
Diagnostic Criteria for Acute Otitis Externa18
Rapid onset (within  hours) in the past  weeks of
At least  primary symptom of ear canal inflammation AND
At least  primary sign of ear canal inflammation
Primary Symptoms of Otitis Externa Primary Signs of Otitis Externa
Otalgia (often severe) Tenderness of the tragus and/or pinna
Itching Diffuse ear canal edema and/or erythema
Sense of ear fullness
Acute otitis externa must be distinguished from other causes of ear pain, otorrhea, and inflammation such as foreign body and AOM with perforation of the tympanic membrane. Placing the speculum of the otoscope into the external ear canal may induce pain and should be done gently.
TREATMENT
PAIN CONTROL
Analgesic therapy should be based on the severity of the pain. Ibuprofen or acetaminophen is sufficient to reduce pain in most cases.
ANTIBIOTICS AND STEROIDS
Topical fluoroquinolone drops, such as ofloxacin or ciprofloxacin, instilled into the ear canal two to four times daily, are the standard treatment.
Ciprofloxacin drops are also available in preparations that include hydrocortisone or dexamethasone, which help relieve itching and pain. Polymyxin
B/neomycin/hydrocortisone preparations have also been traditionally recommended as first­line therapy, but they are not as effective as
 ciprofloxacin/hydrocortisone in eradicating P. aeruginosa and neomycin hypersensitivity is common, so fluoroquinolone drops are preferable.
Acidifying agents, such as 2% acetic acid drops, are also approved for treatment of otitis externa, but are painful upon application and are contraindicated in the presence of a suspected tympanic membrane perforation or tympanostomy tubes. Do not give systemic antibiotics for uncomplicated cases of acute otitis externa. Consider systemic antibiotics only if there is extension of the disease outside of the ear canal and/or
 there are specific host factors (e.g., immunocompromised) that indicate a need for systemic therapy. Parenteral therapy may be required in severe cases and should involve otolaryngology consultation.
When instilling antibiotic drops, lie the child down with the affected ear upward and have the child remain in this position for  minutes after application. Fill the ear with the topical agent and gently move the pinna back and forth to improve delivery throughout the entire external canal. If the external canal is extremely edematous and obstructed, perform aural toilet and/or place an ear wick to improve delivery of the drops (the wick should be removed in  days if it has not fallen out on its own as the edema improves).

Reexamine children who fail to improve within  to  hours of initial therapy and consider other diagnoses. Cultures of the external canal may be useful in such cases.
SUPPORTIVE MEASURES
Avoid swimming until the canal heals. Gentle cleaning and drying of the ear canal may be helpful but should be done cautiously to avoid secondary trauma. With repeated infections in children who swim, use of earplugs while swimming and daily prophylaxis with acidifying and drying drops (e.g., vinegar and isopropyl alcohol as 1:1 solution) during at­risk periods such as swimming season may prevent infection.
ACUTE MASTOIDITIS
Acute mastoiditis is a bacterial infection of the mastoid that almost always develops as a complication of AOM. The initial diagnosis of AOM may occur prior to or at the same time that mastoiditis is diagnosed. At birth, the mastoid consists of a single cell called the antrum, but air cells quickly develop during the first few years of life, and most children have well­developed mastoids by  years of age. The incidence of mastoiditis is highest in children
 younger than age  years. Risk factors for acute mastoiditis include recurrent AOM, immunocompromise, or the presence of a cholesteatoma.
Cholesteatomas are destructive, expanding growths in the middle ear consisting of keratinizing epithelial cells and can be congenital or acquired
(Figure 121­6).
FIGURE 121­6. Cholesteatoma. Cholesteatomas are destructive, expanding growths in the middle ear and/or mastoid that consist of keratinizing squamous epithelial cells. Note the yellow epithelial debris and distortion of anatomy. Cholesteatomas can be congenital or acquired. [Image used with permission of C.
Bruce Macdonald, MD; reproduced with permission from Knoop et al: Atlas of Emergency Medicine, 2nd ed. Jauch et al: Chapter , Ear, Nose, and
Throat Conditions, Figure 5­9.]
21­29
The relationship between antibiotic usage for AOM and the incidence of mastoiditis is not clear.
PATHOPHYSIOLOGY
Acute mastoiditis develops when inflammation and infection in the middle ear spread into the cells of the mastoid through the aditus ad antrum. This process can induce destruction of the mastoid bone and periosteum. The same bacterial organisms most commonly associated with AOM (S.
pneumoniae, nontypeable H. influenzae, and S. pyogenes) are common causes of acute mastoiditis, but other important bacteria implicated include S.
,31 aureus and P. aeruginosa.
CLINICAL FEATURES
In addition to the signs and symptoms of AOM, patients with mastoiditis have erythema, edema, and/or tenderness of the mastoid area posterior to the auricle. Mastoiditis is rare if the tympanic membrane is normal, but can occur if there is obstruction of the aditus ad antrum and the fluid in the middle ear has drained through the eustachian tube. As the inflammation and infection in the mastoid progress, the auricle becomes visually protruded outward (Figure 121­7). Advanced disease may cause palsies of the VI (abducens) or VII (facial) nerves.
FIGURE 121­7. Acute mastoiditis with postauricular erythema and edema and outward protrusion of the auricle. [Image used with permission of Dr. Shelagh Cofer,
Department of Otolaryngology, Mayo Clinic.]
Complications include subperiosteal abscess, facial nerve palsy, osteomyelitis of other parts of the skull, direct extension into the intracranial cavity
(e.g., intracranial abscess, meningitis), venous sinus thrombosis, hematogenous spread of infection to separate sites, and otitic hydrocephalus. Otitic hydrocephalus is due to thrombosis of the transverse sinus of the dura and should be suspected in children with mastoiditis with signs and symptoms of elevated intracranial pressure.
DIAGNOSIS

The diagnosis is clinical. Confirmation is by CT (with IV contrast) of the mastoid but is usually reserved for cases with suspected complications. MRI
 may be preferred in children with suspected intracranial complications, but is usually only obtained after CT if more information is needed.
Laboratory tests rarely change outcome. Consider blood cultures in children with fever. Aspiration and culture of middle ear fluid by tympanocentesis are useful to identify the specific organism.
TREATMENT
Treatment for uncomplicated cases involves broad­spectrum IV antibiotics and drainage of middle ear and mastoid fluid. Direct initial antibiotic therapy toward the most common bacteria (S. pneumoniae, nontypeable H. influenzae, S. pyogenes, S. aureus, and P. aeruginosa). Piperacillintazobactam plus vancomycin is an example of an appropriate regimen. Antibiotic therapy can be narrowed once a specific organism is identified.
Drainage is usually accomplished by myringotomy with or without placement of tympanostomy tubes. Mastoidectomy and more aggressive surgical intervention are typically reserved for cases in which there is no significant clinical improvement within  hours and for complications.
FOREIGN BODY IN THE EAR CANAL
Foreign bodies in the ear canal are a relatively common occurrence. The foreign body can be anything from a bead to a small toy to a corn kernel to a piece of paper to a button battery. On occasion, a live insect will crawl into the ear during sleep.
Some children will report putting something in their ear and come to medical attention before symptoms are present. Others will develop ear pain and/or discharge as the ear canal becomes inflamed and may also complain of hearing loss. In the case of an insect, acute onset of extreme pain often with the sensation of something moving in the ear is classic.
Diagnosis is confirmed by direct visualization with otoscopy.
Most foreign bodies can be easily removed at the bedside. An anxiolytic medication such as intranasal midazolam may be helpful in young children.
Many foreign bodies can simply be grasped and extracted with alligator forceps. An otoscope with an operational head through which the instrument can be introduced is helpful to allow direct visualization throughout the procedure. Foreign bodies that do not have easily graspable parts but are not
 deeply embedded can usually be removed with an ear curette, suctioning, or irrigation with warm water. For irrigation, thread a thin catheter attached to a syringe filled with warm water into the ear canal posterior to the foreign body, so that irrigation pushes the foreign body out of the canal.
Live insects should be killed by instilling mineral oil into the ear canal prior to removal. Consult otolaryngology if the foreign body is a hazardous material (e.g., button battery); if there is concern for associated injury to the canal, tympanic membrane, and/or middle ear; or if the above techniques are not successful. If inflammation is noted after removal of any foreign body, a short course of topical antibiotic­steroid otic drops (e.g., ciprofloxacin
.3% and dexamethasone .1%) is indicated to prevent otitis externa.
Acknowledgments
We are grateful to Dr. Shelagh Cofer for her otoscopic pictures and photographs of mastoiditis and Dr. Alejandro Hoberman for his otoscopic pictures.


