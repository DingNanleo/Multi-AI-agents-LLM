## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 107: Neonatal and Pediatric Transport
Daniel G. Ostermayer
INTRODUCTION
Regionalization, the organization of a coordinated system of care across a geographic area, combines all necessary components of care to optimize
 patient outcomes. Regionalized intensive care for neonatology and pediatric care focuses expensive, high­technology, labor­intensive therapies to a few regional centers. This model of care originated from trauma center regionalization demonstrating reduction of morbidity and mortality for trauma
,3 patients at designated trauma centers. Because patients in need of specialized services often present to other hospitals, interfacility transport is an
 important complement to regionalized intensive care. Specialized pediatric transport services improve safety, decrease unplanned adverse events
, , 
(especially airway events), and lower mortality. This chapter reviews the general and pediatric considerations for the interfacility transport of critically ill neonates and children.
THE TRANSPORT TEAM

The American Academy of Pediatrics has published transport guidelines based on expert consensus. Caring for critically ill children is best accomplished with at least two patient care providers on each team in addition to the driver or pilot. One of the patient care members should be a
 registered nurse with a minimum of  years of experience, typically at least  years of neonatal or pediatric critical care or ED training. Additional member(s) may include a respiratory therapist, physician, or paramedic. The condition of the child and local resources determine the exact composition of the specialized transport team. For helicopter EMS transports, the most common care arrangement involves a paramedic and neonatal or pediatric care nurse in addition to the pilot. Similar arrangements of one paramedic and a critical care nurse or two critical care nurses with neonatal and pediatric expertise are frequently used for ground transports. Accreditation agencies and professional associations will guide local and regional team compositions.
TRANSPORT ENVIRONMENT
Transporting critically ill patients adds to the risks of the illness or injury because of the hazards associated with the transport environment,
 particularly for neonates and children. The features of transport that distinguish the transport environment from the ED setting and the effects of these features on patients and caretakers are outlined in Chapter , “Air Medical Transport.” All the risks of transport still apply, with the additional need for awareness of the emotional and mental state of the child. Also, since one parent often accompanies the child, additional weight considerations must be accounted for during aeromedical transport.
PRECAUTIONS
Suggested guidelines to minimize the impact of the limitations inherent in a transport environment are:
. Prepare the transport vehicle. Transport vehicles should be prepared to meet the special needs of children (e.g., accessory lighting, controlled thermal environment) and should be stocked with the necessary equipment. A list of the minimum necessary equipment for ambulances, which
 can serve as a guide for EMS agencies, has been published by the Emergency Medical Services for Children program. Transport modality–specific risks should also be considered.
. Stabilize the patient before transport. Unless the immediate needs of the patient can only be met in the receiving hospital (e.g., emergent surgery), ample time should be devoted to stabilizing the patient in the referring hospital. Time spent undertaking goal­directed intensive care interventions
 early in the course of the patient illness at the referring hospital does not worsen patient outcomes.

Chapter 107: Neonatal and Pediatric Transport, Daniel G. Ostermayer 
. Monitor as many physiologic parameters as possible electronically. Because physical examination is difficult during transport and because children
. Terms of Use * Privacy Policy * Notice * Accessibility often are transported during dynamic changes in their physiologic condition, electronic monitoring is essential. Children are especially at risk for
 hypothermia and hypoglycemia. Important monitoring equipment commonly used during transport includes cardiorespiratory monitor
(selected based on its size, weight, battery life, and resistance to motion artifact); continuous pulse oximetry with a plethysmographic waveform to assist in identifying motion artifact; temperature monitor (of infants and incubator air temperature); continuous end­tidal carbon dioxide
 waveform monitoring, which can aid in early identification of unplanned extubation ; and invasive or noninvasive blood pressure monitoring.

Lowering endotracheal cuff pressures during aeromedical transport can help reduce excessive tracheal pressure.
. Anticipate deterioration. Preparation of the patient should include not only care for the identified problems but also anticipation of problems that may arise during transport. The application of this principle may lead to performance of procedures or therapies before transport such as gastric
 decompression, placement of a chest tube for pneumothorax, or transfusion (Table 107­1).
TABLE 107­1
Pediatric Conditions at Risk for Deterioration During Transport
Pneumonia
Recurrent brief resolved unexplained event
Foreign body aspirations
Airway obstructions
Epilepsy
Poisoning or overdose
Multisystem or severe intracranial trauma
Tracheitis
Severe asthma
Metabolic derangements
Severe sepsis
SITUATIONS REQUIRING TRANSPORT
There are severe conditions for which interfacility transports are more common, and neonates require more interfacility transports than older children. Although many community hospitals can care for a pregnant mother and child, premature infants require more resources and often need transfer to a neonatal intensive care unit for care. Likewise, pediatric and neonatal patients with sepsis, seizure disorder, shock, or severe neurologic and metabolic conditions can quickly overwhelm the clinical staff at a small hospital. Current expert consensus for transport of sick or injured children
 recommends physicians understand sending and receiving resources before deciding to transfer (Table 107­2).
TABLE 107­2
Pediatric Conditions Commonly Requiring Interfacility Transports
Intracranial trauma
Severe trauma
Airway (upper or lower) airway disorders
Sepsis/septic shock
Seizures
Developmental or neurologic condition
Poisoning or overdose
Intracranial trauma
Multisystem trauma
DECISION TO TRANSPORT
Children require transfer to a regional center if the current or anticipated medical care needs of the patient exceed the resources of the local hospital.
Arranging transfer to the regional center can occur simultaneously with assessment, resuscitation, and stabilization at the local hospital. Discussion with the receiving hospital and specialists can aid in decisions regarding the mode of transport and composition of the transport team. Preestablished transfer protocols should provide information about each regional center to which a patient might be referred, including (1) special services available;
(2) criteria for referral; (3) telephone numbers for consultation, referral, and transport; (4) distance and usual response time; (5) type of transport personnel and their capabilities; (6) type of transport vehicles; and (7) protocols for preparation of patients. Establish formal agreements with regional centers that outline the circumstances under which patients can be transported without prior administrative approval. As with adults, proper assessment of the patient’s injury pattern must factor into transport mode. Aeromedical transports have become increasingly more frequent with increased hospital emergency department closure and regionalization of pediatric specialty care facilities, especially for surgical services, trauma, and
,16 burns.
MODE OF TRANSPORT
In many areas, physicians have a choice between air and ground transportation. This decision should be made collaboratively between the referring
,18 and accepting physicians. The risks and benefits of air transport are discussed in Chapter , “Air Medical Transport.” Time, distance, traffic, weather, geographic constraints, and availability all factor into the decision regarding mode of transport. The most important factor determining the type of transport will be team availability and skill level. The most capable care team may not be available for a ground transport, making flight a safer option. When the transport team arrives, the referring physician and local ED staff should be available to coordinate the transition of care and ensure that any required ongoing therapy can be continued.
PREPARATION FOR TRANSPORT
Nearly all patients should have intravascular access during transport. Critically ill children should have at least two lines of vascular access in case one becomes dislodged or several medications need to be administered simultaneously. For newborns, consider using umbilical vessels for vascular access. Intraosseous cannulation is an alternative technique for fluid and drug administration when intravascular lines cannot be placed or the severity of illness demands immediate access (see Chapter 114, “Vascular Access in Infants and Children”).
In small children, IV lines should be infused with the use of pumps. Open “drips” should not be used, even with volumetric drip chambers, because of the risk of fluid overload from inadvertent administration of large boluses. The amount of fluid administered before and during transport should be monitored and carefully recorded.
A small subset of children may do better without IV placement, because IV placement can agitate the child and further compromise the airway. This is particularly true for children with a partial airway obstruction from croup, a foreign body, or epiglottitis. The best measure in the situation of partial airway obstruction may be to keep the child as calm as possible, allow the child to sit in the caregiver’s lap during transport, and refrain from IV placement.
CONDUCT OF A TRANSPORT
Once the decision has been made to transport a child, the referring hospital has certain legal obligations to the patient in addition to provision of
 medical care. In the United States, the referring physician is responsible for arranging an appropriate mode of transport to a hospital capable of providing the services needed by the patient and stabilizing the patient as best as possible before transport. The referring physician should inform caregivers of the need for transfer and the risks and benefits, and discuss the transport modality. Written consent for transport should be obtained from a parent or other legal guardian. Important documentation to provide for the receiving facility and care team includes a copy of the current medical record, laboratory data, radiographs, and old medical records, if available.
Clear communication between the referring and receiving physicians is essential. Standardized techniques can help mitigate communication errors, such as the ISBARQ(introduction, situation, background, assessment, recommendation, questions)model developed by Children’s
Hospital of Philadelphia: During the introduction, the referring physician and patient are identified; the situation is conveyed by the working diagnosis and current medical condition; background includes what is known about the patient, such as past medical history and past tests or treatments; assessment communicates what is happening at the time of transport (current findings, patient needs, treatments, new test results); recommendations are made by receiving physicians regarding further stabilization of the patient, sometimes at the request of the referring doctor
(although referring physicians are not obligated to follow these recommendations if they are considered to be medically inappropriate or beyond the capabilities of the referring hospital); and the process concludes with mutual questions that allow for further clarification.
For most critically ill children, ideal care is provided when the ED of the referring hospital devotes its energy to providing emergent short­term medical care and the responsibility for transport is left to a regional center. This is particularly true for neonates because of the special equipment and expertise required for transport. When transport services are not provided by the regional center or when time is critical, the only option may be for the referring hospital to provide transport. In these circumstances, it is the responsibility of the referring center to ensure the adequacy of care, as best as possible given available resources and personnel, during transport.
Referring providers should provide the family members with written directions to the receiving institution when they are not able to accompany their child in the transport vehicle. Additional helpful information includes parking information, nearby accommodations, and visiting policies of the receiving institution, if known. Allowing a family member to accompany the child during ground transport is valued by the patient and family and does
,21 not interfere with the delivery of care. Clear communication with family members about the medical needs of the patient, appropriate parental behavior, and logistics involved may help alleviate disruptions during transport. Ultimately, if it is anticipated that family member involvement will diminish the quality of care, it will be necessary to encourage them to meet their child at the receiving institution.
CONSENT FOR TRANSPORT
In most of the United States, the legal age of majority is  years old. However, in most states, mothers <18 years of age have authority to consent for medical therapies for their children unless specifically prohibited by court order. Likewise, in many states, medical care for minors can be given without parental consent when it is emergent or involves reproductive health. Thus, the definition of the age of majority is situational and must be addressed on an individual basis within the confines of both federal and state law. In situations in which transport of a minor patient is advisable and a parent or guardian is not available (often the case with pediatric traumas), the minor patient can be transported under the principle of beneficence. In these cases, legal authorization for interfacility transport requires documentation from the referring physician stating that failure to transport would endanger the patient’s well­being.
SHARED DECISION MAKING
Discussing clinical situations will help with solidifying an understanding of balancing potential benefit and risks of harm from transport. Shared decision making allows for both incorporation of patient and family values and preferences. For example, a family may wish to transport a child with an injured extremity to the pediatric hospital by private vehicle. If there is no need for monitoring or risk for decompensation while en route, a private vehicle will offer benefits of lower cost, immediate availability, and familiarity to the child. The disadvantage includes lack of neurovascular or hemodynamic monitoring. On the other extreme, take the example of a rural facility with access to only fixed wing transport that needs to transfer a child with multilobar pneumonia. The process involves waiting on the dispatch, transporting by ground to the runway, awaiting landing, preparation of a plane, and transport. Parents may consent to this delay and cost because the benefits involve the ability to cover a large distance quickly, pressurize the cabin for high­altitude travel, and greater space for safer clinical care. These situations highlight the need for shared family decision making and conversations with transfer centers and transport agencies to individualize pediatric care.


