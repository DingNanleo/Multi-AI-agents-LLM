## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 207: Dyshemoglobinemias
Brenna M. Farmer; Lewis S. Nelson
INTRODUCTION
Dyshemoglobinemias are disorders in which the hemoglobin molecule is functionally altered and prevented from carrying oxygen. The most clinically
 relevant dyshemoglobinemias are carboxyhemoglobin, methemoglobin, and sulfhemoglobin. Carboxyhemoglobin is created following carbon monoxide exposure and, because of its unique importance and prevalence, is discussed separately (see Chapter 222, “Carbon Monoxide”).
METHEMOGLOBINEMIA
PATHOPHYSIOLOGY
2+
The iron moiety within deoxyhemoglobin normally exists in the ferrous (bivalent or Fe ) state. Ferrous iron avidly interacts with compounds seeking
3+ electrons, such as oxygen or other oxidizing agent, and in the process is oxidized to the ferric (trivalent or Fe ) state. Hemoglobin in the ferric form is unable to bind oxygen for transport and is termed methemoglobin. Normally, <1% to 2% of circulating hemoglobin exists as methemoglobin; higher concentrations define the condition of methemoglobinemia.
Methemoglobin accumulation is enzymatically prevented by the rapid reduction of the ferric iron back to the ferrous form. Cytochrome b reductase is
 primarily responsible for this reduction, in which reduced nicotinamide adenine dinucleotide donates its electrons to cytochrome b , which
 subsequently reduces methemoglobin to hemoglobin (Figure 207­1). This pathway is responsible for reducing nearly 95% of methemoglobin produced under typical circumstances. Methemoglobinemia occurs when this enzymatic reduction is overwhelmed by an exogenous oxidant stress, such as a drug or chemical agent (Table 207­1).
FIGURE 207­1. 2+ 3+
Methemoglobin formation and mechanism of action of methylene blue. G6PD = glucose­6­phosphate dehydrogenase; Hb(Fe ) = hemoglobin; Hb(Fe )
+ +
= methemoglobin; NAD = oxidized nicotinamide adenine dinucleotide; NADH = reduced form of nicotinamide adenine dinucleotide; NADP = nicotinamide adenine dinucleotide phosphate; NADPH = reduced form of nicotinamide adenine dinucleotide phosphate; PO = phosphate.

TABLE 207­1

Drugs Causing Methemoglobinemia
Chapter 207: Dyshemoglobinemias, Brenna M. Farmer; Lewis S. Nelson 
. Terms of Use * Privacy Policy * Notice * Accessibility
Oxidant Comments
Analgesics
Phenazopyridine Commonly reported
Phenacetin Rarely used
Antimicrobials
Antimalarials Common
Dapsone Hydroxylamine metabolite formation is inhibited by cimetidine
Sulfamethoxazole Uncommon
Local Anesthetics
Benzocaine Most commonly reported of the local anesthetics
Lidocaine Rare
Prilocaine Common in topical anesthetics
Dibucaine Rare
Nitrates/Nitrites
Amyl nitrite Cyanide antidote kit and used to enhance sexual encounters
Isobutyl nitrite Used to enhance sexual encounters
Sodium nitrite Cyanide antidote kit
Ammonium nitrate Cold packs
Silver nitrate Excessive topical use
Well water Problem in infants, due to nitrate fertilizer runoff
Nitroglycerin Rare
Other
Rasburicase Treatment for hyperuricemia in tumor lysis syndrome
Methemoglobin can also be reduced by a second enzymatic pathway using the reduced form of nicotinamide adenine dinucleotide phosphate (or

NADPH) and NADPH­methemoglobin reductase. This pathway is normally of minimal importance and is responsible for <5% of total reduction under typical circumstances. However, this enzyme and pathway are crucial for the antidotal effect of methylene blue (Figure 207­1).
The limited role for NADPH partially explains why patients with glucose­6­phosphate dehydrogenase (G6PD) deficiency with a resultant deficit of
NADPH are not at increased risk of developing methemoglobinemia, although they are at risk of developing hemolysis following exposure to an oxidant stress. To a very limited extent, nonenzymatic reduction systems, such as vitamin C and glutathione, may participate in the reduction of methemoglobin to hemoglobin.
The primary adverse clinical effect of methemoglobin is the reduction in the oxygen content of the blood. Because hemoglobin­bound oxygen accounts for the vast majority of an individual’s oxygen­carrying capacity, as the methemoglobin concentration rises, oxygen­carrying capacity falls.
Patients with methemoglobinemia are often more symptomatic than patients with a simple anemia that produces an equivalent reduction in oxygencarrying capacity. This is caused by a leftward shift in the oxyhemoglobin dissociation curve, the consequence of which is a reduced release of oxygen
 from the erythrocyte to the tissue at a given partial pressure of oxygen (Figure 207­2).
FIGURE 207­2. Oxyhemoglobin dissociation curve.
The oxyhemoglobin dissociation curve of blood with a 50% reduction in erythrocytes (i.e., anemia) follows a curve similar to that of nonanemic blood; although the oxygen content is lower, unbinding of half of the oxygen (50% oxygen saturation) occurs at the same partial pressure of oxygen. With 50% methemoglobin, the leftward shift of the oxyhemoglobin dissociation curve means that hemoglobin is less willing to give up its oxygen, so that tissue hypoxia is more severe than in those with a 50% anemia.
Acquired Methemoglobinemia
Drugs in conventional doses rarely produce clinically significant methemoglobinemia (Table 207­1). Benzocaine is the local anesthetic most commonly
3­6 associated with methemoglobinemia. Methemoglobin induction with sodium nitrite is a therapeutic goal in the management of patients suffering from cyanide poisoning (see Chapter 204, “Industrial Toxins”). With certain compounds, particularly dapsone, metabolism to the “active” oxidant is
 required before induction of methemoglobinemia, so there may be substantial delay until toxicity is evident. Occupational methemoglobinemia
 usually involves exposure to aromatic compounds, primarily amino­ and nitro­substituted benzenes. Routes of absorption are typically dermal or inhalational due to the high lipophilicity and volatility of these compounds, respectively.
Neonates and infants are more susceptible to methemoglobin accumulation because of undeveloped methemoglobin reduction mechanisms. This accounts for the relatively common development of methemoglobinemia in infants given certain nitrogenous vegetables (e.g., spinach), who consume well water that contains high nitrate levels (generally from fertilizer use), or who experience gastroenteritis where GI flora can convert nitrate to the
,10 nitrite form.
Hereditary Methemoglobinemia
Hereditary methemoglobinemia results from either an enzymatic deficiency (i.e., cytochrome b reductase) or from the presence of an amino acid

 substitution within the hemoglobin molecule itself, termed hemoglobin M. Patients with cytochrome b reductase deficiency develop methemoglobin
 levels of 20% to 40%. Cyanosis in these individuals begins at birth, but they remain asymptomatic and develop normally.
Hemoglobin M, an abnormal form of hemoglobin, has altered tertiary structure so that the heme iron exists in an environment favoring the ferric form.
This disorder only occurs in the heterozygous form, because the homozygous form is incompatible with life. As with cytochrome b reductase
 deficiency, patients develop profound cyanosis but tolerate the elevated methemoglobin concentrations well due to compensatory mechanisms.
CLINICAL FEATURES
Healthy patients who have normal hemoglobin concentrations do not usually develop clinical effects until the methemoglobin level rises above 20% of
,12 the total hemoglobin. At methemoglobin levels between 20% and 30%, anxiety, headache, weakness, and lightheadedness develop, and patients may exhibit tachypnea and sinus tachycardia. Methemoglobin levels of 50% to 60% impair oxygen delivery to vital tissues, resulting in myocardial ischemia, dysrhythmias, depressed mental status (including coma), seizures, and lactate­associated metabolic acidosis. Levels above 70% are largely incompatible with life.
Cyanosis associated with methemoglobin is often described as a gray discoloration of skin, with a detection threshold for methemoglobin of .5 grams/dL, corresponding to methemoglobin levels between 10% and 15% in a nonanemic individual. Anemic patients may not exhibit cyanosis until the methemoglobin level rises well above 10% because cyanosis detection is dependent on the concentration of methemoglobin, not the percentage. Anemic patients may likewise develop clinical features at lower methemoglobin concentrations because the relative percentage of hemoglobin in the oxidized form is greater.
Patients with preexisting cardiopulmonary diseases that impair oxygen delivery will also manifest abnormalities with lesser elevations in their methemoglobin levels. Conversely, compensatory mechanisms that shift the oxyhemoglobin dissociation curve to the right, such as acidosis or elevated ,3­diphosphoglycerate, may result in somewhat better tolerance of methemoglobin.
DIAGNOSIS
,5,7,11,12
Consider methemoglobinemia in patients with cyanosis, particularly if cyanosis does not improve with supplemental oxygen (Figure 207­3). A useful clue is that patients with methemoglobin­associated cyanosis generally are less symptomatic than equivalently appearing patients with hypoxemia­induced cyanosis. This is due to the more deeply pigmented color of methemoglobin compared with deoxyhemoglobin; it takes about  grams/dL of deoxyhemoglobin to cause cyanosis, which equates to an oxygen­carrying capacity of approximately 67% of normal (in someone with a total hemoglobin of  grams/dL), compared with the cyanosis visible with a methemoglobin concentration of .5 grams/dL, which equates to an oxygen­carrying capacity of 90% of normal. Blood containing more than 20% methemoglobin has a characteristic “chocolate brown” color when
,14 phlebotomized. A color reference chart has been developed to estimate methemoglobin levels from drops of blood on white absorbent paper.
FIGURE 207­3. Toxicologic approach to the cyanotic patient. ABG = arterial blood gas; NADPH = reduced form of nicotinamide adenine dinucleotide phosphate.
[Reproduced with permission from Nelson LS, Howland MA, Lewin NA, Smith SW, Goldfrank LR, Hoffman RS, (eds): Goldfrank’s Toxicologic
Emergencies, 11th ed. New York: McGraw­Hill, Inc., 2019; Figure 124­7.]

Pulse oximetry results are not accurate in patients with methemoglobinemia. The standard pulse oximeter uses two wavelengths of light, 660 nm and
940 nm, to calculate the percentage of oxyhemoglobin. Methemoglobin is also detected by these wavelengths, so light absorption by methemoglobin confounds the calculation for the oxyhemoglobin percentage. In patients with methemoglobinemia, the pulse oximeter will report a falsely
 elevated value for arterial oxygen saturation percentage. The specific values vary by oximeter, but typically report approximately 85%.
Commercially available pulse co­oximeters and pulse spectroscopy use additional wavelengths of light to measure the total hemoglobin concentration
16­18 and percentages of carboxyhemoglobin and methemoglobin. Their accuracy for detecting methemoglobinemia has improved with additional wavelengths, improved probes, and more robust software.
Definitive identification of dyshemoglobinemias requires co­oximetry, a spectrophotometric method capable of differentiating
,12 oxyhemoglobin, deoxyhemoglobin, carboxyhemoglobin, and methemoglobin species. This widely available test can be performed on a venous or arterial specimen.
Arterial blood gas results may be initially deceptive because the partial pressure of oxygen, a measure of dissolved, not bound, oxygen, is normal. Thus, calculation of oxygen saturation from measured partial pressure by the blood gas analyzer will produce a falsely elevated result.
TREATMENT
Patients with methemoglobinemia require supportive measures to ensure oxygen delivery and administration of appropriate antidotal therapy, if
,12 indicated (Table 207­2). Gastric decontamination is of limited value, because there often is a substantial time interval between exposure to the toxic agent and the development of methemoglobin. If a source of continuing GI exposure is suspected, decontamination is indicated, and in most stable patients, a single dose of activated charcoal is likely sufficient. Dermal decontamination should be used as indicated. Antidotal therapy with methylene blue is reserved for symptomatic patients or for those asymptomatic patients with methemoglobin levels >25%.
TABLE 207­2
Management of Methemoglobinemia
Assess airway, breathing, and circulation; exclude other causes of cyanosis.
Insert an IV line.
Administer oxygen.
Attach the patient to a cardiac monitor and pulse oximeter or co­oximeter.
Obtain an ECG as indicated.
Decontaminate the patient as needed.
Administer methylene blue if symptomatic or methemoglobin >25%.
Consider cimetidine for patients taking dapsone.
Methylene blue indirectly accelerates the enzymatic reduction of methemoglobin by NADPH­methemoglobin reductase. NADPH­methemoglobin
3+ reductase reduces methylene blue to leucomethylene blue, which is then capable of directly reducing the oxidized iron (Fe ) back to the ferrous state
2+
(Fe ) (Figure 207­1). The initial dose of methylene blue is  milligram/kg (0.1 mL/kg of the 1% solution or approximately  mL in an adult) IV slowly over  minutes. The infusion should be slow because rapidly administered doses of methylene blue are painful. Clinical improvement should be seen within  minutes, and as the methemoglobin level falls, the most severe signs and symptoms will resolve first.
Resolution of the cyanosis occurs later only after the methemoglobin concentration falls below .5 grams/dL. Repeat dosing of methylene blue is acceptable if cyanosis has not cleared in  hour. Serotonin syndrome is a rare risk when methylene blue is administered to patients on serotonergic
,20 drugs such as antidepressants.
Treatment failures may result if the patient has G6PD deficiency, because this enzyme is critical for the production of NADPH by the hexose monophosphate shunt (Figure 207­1). Hemolysis may impede a response to methylene blue, which requires an intact erythrocyte to be effective.
Oxidant drugs with long serum half­lives, such as dapsone, with a half­life of approximately  hours, produce prolonged oxidant stress to the red
 blood cell. Therefore, dapsone­exposed patients may require repetitive dosing of methylene blue. Because the hydroxylamine metabolite of dapsone is responsible for the production of methemoglobin, inhibition of its formation by cytochrome P450 with cimetidine, in standard doses, is
 generally recommended.
In rare instances, patients may be deficient in NADPH­methemoglobin reductase, the required enzyme for methylene blue activation. Treatment failure may occur in patients with sulfhemoglobinemia, which is clinically indistinguishable from methemoglobinemia but which is not responsive to methylene blue. Methemoglobinemia due to chlorate poisoning is responsive to methylene blue when used early in mild cases, but less responsive in severe poisonings when hemolysis is present. Patients who do not respond to methylene blue should be treated supportively. If clinically unstable, the use of packed red cell transfusions or exchange transfusions may be indicated.
SULFHEMOGLOBINEMIA
PATHOPHYSIOLOGY
Sulfhemoglobinemia is a rare condition that occurs when a sulfur atom irreversibly binds to the porphyrin ring of the heme moiety and induces the
3+  permanent oxidation of iron to the ferric (Fe ) state. Many of the agents responsible for sulfhemoglobinemia are identical to those associated with methemoglobin. Because many of these drugs or chemicals do not contain sulfur, the origin of sulfur is speculative; hypotheses include alteration of
,23 intestinal flora with production of hydrogen sulfide and/or glutathione from bacteria such as Morganella morganii. Historically, sulfhemoglobinemia was most often associated with acetanilide, phenacetin, sulfonamide, and a mixture that contained sodium bromide.
Because these drugs are rarely used and the sodium bromide component in the mixture was removed in 1975, contemporary cases of
,25 drug­induced sulfhemoglobinemia are now most often reported with phenazopyridine, dapsone, metoclopramide, and sumatriptan.
Sulfhemoglobinemia has been associated with industrial chemicals, such as trinitrotoluene, hydroxylamine sulfate, dimethyl sulfoxide, and hydrogen
 sulfide.
CLINICAL FEATURES

Patients with sulfhemoglobinemia can have a clinical presentation similar to those with methemoglobinemia. However, the disease process itself is substantially less concerning because, although the reduction in the patient’s oxygen­carrying capacity is quantitatively similar, the sulfhemoglobin oxygen dissociation curve is shifted rightward, not leftward as in methemoglobinemia, favoring the release of hemoglobin­bound oxygen to the tissue
 with sulfhemoglobinemia. Because of the milder symptoms, it is likely that cases of sulfhemoglobinemia are often missed.
DIAGNOSIS
The pigmentation of the blood by sulfhemoglobin is substantially more intense than other colored hemoglobin species; only .5 gram/dL of sulfhemoglobin is needed to produce a cyanosis equivalent to that produced by .5 grams/dL of methemoglobin or  grams/dL of deoxyhemoglobin.
The color of blood drawn from a patient with sulfhemoglobinemia has been described as dark green­black. In sulfhemoglobinemia, standard
 pulse oximetry tends to report a falsely low value for arterial oxygen saturation percentage. The diagnosis of sulfhemoglobinemia may
 be difficult to confirm as special settings for laboratory co­oximetry are required to reliably measure sulfhemoglobin concentration.
TREATMENT
Sulfhemoglobin persists for the life of the red cell and the level is not reduced by treatment with methylene blue. Most patients require only supportive care, although exchange transfusion or packed red cell transfusion is occasionally recommended for patients with severe toxicity.


