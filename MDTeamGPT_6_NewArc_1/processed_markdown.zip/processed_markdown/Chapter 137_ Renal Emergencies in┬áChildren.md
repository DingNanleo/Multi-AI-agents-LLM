## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 137: Renal Emergencies in Children
Andrew Dixon; Brandy Stauffer
ACUTE KIDNEY INJURY
Acute kidney injury (AKI; previously called acute renal failure) is the sudden loss of renal function necessary to maintain normal fluid and electrolyte
,2 balance and clear metabolic waste. AKI is typically manifested by an increase in serum creatinine, although the increase will not necessarily cause the creatinine to be outside the normal range. Use of serum creatinine alone to define AKI, however, is problematic because creatinine is an inaccurate
 estimate of glomerular filtration rate, it can be removed by dialysis, and variable cutoff values for creatinine have been used in AKI. Therefore, the
,5 international classification system, Kidney Disease: Improving Global Outcomes (Table 137­1), is preferred. The system uses creatinine and urine
2­4 output criteria and can be applied to both children and adults, minimizing practice variation.
TABLE 137­1
KDIGO Classification of Renal Injury
Stage* Lab Criteria Urine Output Criteria Other Criteria Neonatal Criteria
I Serum creatinine .5–1.9 times baseline or Urine output <0.5 mL/kg/h Creatinine as per children. Urine output increase of ≥0.3 milligram/dL for  h <0.5 mL/kg/h for 6–12 h
II Serum creatinine 2–2.9 times baseline Urine output <0.5 mL/kg/h Creatinine as per children. Urine output for  h <0.5 mL/kg/h for ≥12 h
III Serum creatinine  times baseline or Urine output <0.3 mL/kg/h Initiation or renal Serum creatinine >3 times baseline or ≥2.5 increase in serum creatinine to ≥4 for  h or anuria for ≥12 h replacement milligrams/dL. Urine output as for children milligrams/dL therapy
Abbreviation: KDIGO = Kidney Disease: Improving Global Outcomes.
*Stage is determined by meeting any criterion (lab or urine output or other) in that row.
In neonates, baseline creatinine is influenced by maternal creatinine and clearance is decreased in premature kidneys. Suggested modifications to the
Kidney Disease: Improving Global Outcomes Classification for neonates are listed in Table 137­1. AKI is common in critically ill children, with an incidence of 27% overall among children hospitalized for intensive care; 12% have severe AKI, and .5%
,7  require renal replacement therapy. Among children admitted to non–intensive care settings, the incidence is approximately 5%. While the incidence
 is highest among adolescents, it is also common in neonates, and more common in boys than girls. The most common causes of AKI in developed countries include cardiac and oncologic disease and their complications as well as nephrotoxin exposure, whereas sepsis, hypovolemia, and
,10­12 glomerulonephritis are common in the developing world. Regardless of etiology, AKI is consistently associated with morbidity and mortality
,12,13 among survivors, as well as long­term loss of renal function.
PATHOPHYSIOLOGY
AKI is the result of nephrotoxic and/or hypoxic injury to the glomeruli and renal tubules. Reduced blood flow causes hypoxic injury and damages the
 pCrhoaxpimtear l1 t3u7b:u Rlaer ncaell lEs.m Ceormgmenocnie nse ipnh Crohtioldxrienns ,i nAcnluddreew a mDiixnoong;l yBcroasniddeys S, ctaounftfrearst agents, calcineurin inhibitors, amphotericin B, NSAIDs, anPda gcaen 1c e/ r20
. Terms of Use * Privacy Policy * Notice * Accessibility
,15 chemotherapeutics. Inflammatory mediators intensify renal tubular damage.
AKI is frequently classified based on three major anatomic locations of injury: prerenal, renal, and postrenal disease. Prerenal disease is typically caused by inadequate renal perfusion and is the most common class of AKI. Prerenal AKI is typically due to hypovolemia (e.g., bleeding or GI losses such as vomiting and diarrhea), decreased renal artery blood flow, or reduction in effective circulation (e.g., heart failure, cardiogenic shock, third spacing in septic shock). Renal disease or intrinsic renal disease occurs when there is structural damage to the renal parenchyma. Common causes of renal disease include glomerular diseases (e.g., pyelonephritis, nephrotic syndrome, glomerulonephritis, Henoch­Schönlein purpura), vascular diseases (e.g., hemolytic­uremic syndrome, thrombosis, vasculitides), interstitial diseases (e.g., interstitial nephritis, infections), and tubular injuries
(e.g., ischemia, nephrotoxins, hypotension). Lastly, postrenal disease is typically due to an obstruction caused by congenital or acquired anomalies to the lower urinary tract. Examples include nephrolithiasis, renal vein thrombosis, pelvic masses (e.g., lymphoma, rhabdomyosarcoma), and urethral obstruction (posterior ureteral valves).
CLINICAL FEATURES
History
Direct the initial history to determine risk factors or causes for AKI. Inquire about urine output, hematuria, and edema, which are the most common symptoms noted in AKI from intrinsic renal disease. Other symptoms and signs relate to the underlying disorder, although patients can also be asymptomatic. Vomiting and diarrhea may suggest intravascular depletion and a prerenal cause of AKI. Other important historical features include history of streptococcal infection (suggests poststreptococcal glomerulonephritis), bloody diarrhea (hemolytic­uremic syndrome), and joint symptoms, rash, or purpura (Henoch­Schönlein purpura). Signs of obstruction include complete anuria or poor urinary stream. Symptoms of renal failure itself include nausea, anorexia (secondary to uremia), changes in urine output or color, edema (may be dependent, periorbital, scrotal/labial, or generalized), and headache from hypertension. Perform a full review of systems and obtain the medical history and pertinent family history. Identify all medications used, including prescription and nonprescription drugs, herbals, and sport supplements.
Physical Examination
The physical examination should be thorough, with special emphasis on vital signs (especially blood pressure), weight, hydration status, and joint and skin findings. Note the presence or absence of edema. Auscultate the lungs for rales, which suggest fluid overload, and the heart for uremic rubs.
Palpate the abdomen for masses (e.g., palpable bladder suggestive of obstruction) and organomegaly, which may indicate fluid overload in young children. Examine the skin for rashes (e.g., palpable purpura of Henoch­Schönlein purpura).
DIAGNOSIS
Laboratory Evaluation
AKI laboratory findings include alterations of renal function, such as elevated creatinine and BUN or an abnormal urinalysis. Analysis of the urine can distinguish between prerenal, renal, and postrenal causes of AKI. In children who are not toilet trained, it may be necessary to obtain a urine specimen by catheterization. In prerenal AKI, urinalysis may be normal. Hematuria, presence of casts, and proteinuria characterize the “active sediment” of glomerulonephritis. Proteinuria alone suggests nephrotic syndrome. WBCs and bacteria suggest infection. A urine dipstick test positive for blood in the absence of observed red blood cells (RBCs) suggests myoglobinuria or hemoglobinuria. Hyaline casts may be seen in acute tubular necrosis. Urine specific gravity is often high (>1.025) in prerenal AKI and may be normal to low in acute tubular necrosis.
Obtain serum electrolyte levels, including calcium, magnesium, and phosphate, when AKI is suspected because hyperkalemia and other electrolyte abnormalities may require emergent treatment. Hyperkalemia may result from a combination of factors including reduced glomerular filtration rate, decreased tubular secretion of potassium, tissue breakdown with release of intracellular potassium, and metabolic acidosis resulting in transcellular movement of potassium. Other electrolyte abnormalities may include hyponatremia secondary to fluid retention or hypernatremia from dehydration in prerenal failure. Hyperphosphatemia from impaired renal excretion may lead to secondary hypocalcemia. A blood gas may show an anion gap metabolic acidosis secondary to impaired renal excretion of acid and reabsorption and regeneration of bicarbonate. A CBC is useful to identify anemia, hemolysis, and thrombocytopenia (characteristic of hemolytic­uremic syndrome), signs of systemic infection, or eosinophilia (interstitial nephritis).
Serum compliments (C3, C4, CH50) and serologic testing for streptococcal infections may be useful for immune­mediated AKI. Additional studies are dictated by the clinical picture.
An ECG will identify cardiac arrhythmias and hyperkalemia. Renal biopsy is the definitive study for most cases of intrinsic renal disease and may be done on an outpatient or inpatient basis.
Imaging
A chest radiograph can identify an increase in heart size or pulmonary edema. Renal US identifies anatomic abnormalities, hydronephrosis, and/or hydroureter. Voiding cystourethrogram is obtained in boys with suspected posterior urethral valves. Additional imaging depends on the differential diagnosis.
TREATMENT
Treatment of AKI is different for prerenal, renal, and postrenal failure. In all cases, careful monitoring of vital signs, including baseline weight and urine output, is necessary. In prerenal failure, treat dehydration and hypovolemia with a 10­ to 20­mL/kg crystalloid bolus of normal saline; if hemorrhagic
 shock is the cause for hypovolemia, initiate a crystalloid bolus until blood products are available. Packed RBCs are transfused at a volume of  mL/kg. Fresh frozen plasma and platelets may be necessary in massive hemorrhage (see Chapter 144, “Hematologic Emergencies in Infants and
Children”).
In renal failure from intrinsic renal disease, the specific cause must be identified and treated. Depending on the clinical state, manage oliguria and fluid overload with fluid restriction, limiting replacements to insensible losses only. Diuretics may be helpful to reduce fluid overload but are less effective in
,16 children with AKI and may require higher than usual doses. Discontinue all nephrotoxic medications or adjust dose for glomerular filtration rate.
Treat hypertension with antihypertensive agents or diuretics (see later section “Hypertension”).
Manage oliguria of postrenal failure with fluid restriction and treatment of hypertension. A Foley catheter may be necessary to relieve the obstruction.
In all types of AKI, electrolyte management is important. Do not administer potassium or phosphorus to children with oligoanuric AKI unless symptomatic from hypokalemia or hypophosphatemia. The management of life­threatening hyperkalemia and hyponatremia is discussed in Chapter 132, “Fluid and Electrolyte Therapy in Infants and Children.”
When conservative management fails, consider acute renal replacement therapy (dialysis). Indications for acute renal replacement therapy are severe electrolyte abnormalities, fluid overload not relieved by administration of loop diuretics, and intractable metabolic acidosis not responding to bicarbonate therapy. Peritoneal dialysis is the preferred method of acute dialysis for children because it is inexpensive and requires less expertise to
 perform than hemodialysis.
DISPOSITION AND FOLLOW­UP
Although the primary care physician can manage mild renal insufficiency caused by dehydration, pyelonephritis, postinfectious glomerulonephritis, or
Henoch­Schönlein purpura on an outpatient basis, consult a pediatric nephrologist for the management of more significant renal insufficiency, which
 often requires inpatient therapy. Pediatric urology consultation is needed for postrenal failure. Admit children with severe electrolyte abnormalities and fluid overload to a pediatric intensive care unit.
NEPHROTIC SYNDROME
Nephrotic syndrome is a chronic disease in children that alters permeability at the glomerular capillary wall, which causes a urinary loss of protein. The
 disease is classically characterized by proteinuria (>40 milligrams/m in  hours), hypoalbuminemia (serum albumin <25 grams/L), hyperlipidemia,
,18 and edema. However, hyperlipidemia and edema are not consistently present. Nephrotic syndrome can be primary (involving only the kidney) or secondary (multisystem). Primary nephrotic syndrome accounts for 95% of pediatric nephrotic syndrome and is idiopathic in 80% to 90% of children
,19 age  to  years old, but is genetic in the vast majority of neonates and young infants.
The classification of primary nephrotic syndromes includes minimal change disease, focal segmental sclerosis, membranous nephropathy, membranoproliferative nephritis, and proliferative nephritis (diffuse, focal, or mesangial). Secondary nephrotic syndrome is rare in children, but can be caused by autoimmune disease (Henoch­Schönlein purpura, lupus, diabetes), infections (hepatitis, human immunodeficiency virus, malaria,
,18 parasites), drugs, diabetes, or malignancy.
PATHOPHYSIOLOGY
When podocytes within the glomerular membrane are damaged by immune dysregulation or systemic circulating factors, the permeability of the
 glomerulus to proteins normally not able to pass through the glomerular capillary wall is increased. Increased permeability results in the two diagnostic hallmarks of nephrotic syndrome: proteinuria and hypoproteinemia. Nephrotic syndrome also leads to salt and water retention. The combination of low intravascular oncotic pressure from the loss of proteins, coupled with the retention of salt and water, gives rise to the clinical feature of edema. As fluids shift to the extracellular space, the kidney is stimulated through the renin­angiotensin­aldosterone system to increase distal sodium reabsorption, which exacerbates the cycle.
CLINICAL FEATURES
History and Complications
Edema is the most common complaint. Anasarca consists of marked peripheral edema, ascites, scrotal or vulvar edema, and severe periorbital edema.
Shortness of breath, cough, and orthopnea suggest a pleural effusion. Ask about urine output, because oliguria is often associated with more severe edema. Nausea, vomiting, and anorexia suggest ascites or edema of the bowel wall, and when accompanied by fever, raise concern for spontaneous bacterial peritonitis. Review of systems should note fever, fatigue, arthralgias or arthritis, rash, and the volume and character of the urine (foamy, bloody, or tea colored). The presence of hematuria, hypertension, or reduced renal function, age at onset, medical and family history of disease, and biopsy findings are all important predictors of disease outcome.
,20
The main life­threatening complications of nephrotic syndrome are severe infection and thromboembolic events (venous and arterial). Serum complements, antibodies, and coagulation factors are lost as protein in the urine, leading to relative immunocompromise. Steroid therapy for nephrotic syndrome increases the risk of infection. Hyperlipidemia may lead to hyperviscosity, and increased levels of fibrinolytic inhibitors increase thrombotic risks.
Physical Examination
Edema is the most common physical exam finding in nephrotic syndrome and is typically more prominent in the morning and in dependent areas.

Rebound abdominal tenderness and ascites are other potential findings. Auscultate for findings of pleural effusion and pulmonary edema. Examine the abdomen for signs of peritoneal fluid, and note tenderness or guarding, which may be signs of peritonitis. Be careful not to confuse facial swelling due to nephrotic syndrome with swelling secondary to allergic reaction.
DIAGNOSIS

The diagnostic criteria of nephrotic syndrome are as follows :
. Edema
. Proteinuria: Urine protein (milligrams/deciliter) to urine creatinine (milligrams/deciliter) ratio >2 in a first morning void or a 24­hour urine protein
 loss that exceeds  milligrams/kg or  milligrams/m
. Hypoalbuminemia: Serum albumin <25 grams/L
Renal biopsy is not indicated during the initial episode of acute nephrotic syndrome. Early renal biopsy should be considered for infants with nephrotic syndrome; those with persistent elevation in serum creatinine, hypocomplementemia, or gross hematuria; and those who are treatment
,22 resistant.
Laboratory Evaluation
In general, blood and urine samples are sent for study to confirm the diagnosis of nephrotic syndrome (tests for proteinuria, hypoproteinemia, and hyperlipidemia), distinguish primary from secondary causes (tests for hematuria, serum immunoglobulin and complement levels, and antinuclear
 antibody level; hepatitis serologic testing), and aid in management (CBC, serum electrolyte levels, renal function tests, coagulation studies). Serum creatinine may be normal for age and height. Total serum calcium is often low, although ionized calcium is usually normal. Serum sodium level is low secondary to increased triglycerides. Imaging studies are rarely indicated unless there is clinical concern for pulmonary edema or effusions. Symptoms or signs suggestive of potential thrombotic complications of nephrotic syndrome should prompt the appropriate evaluation (e.g., duplex US of renal vessels, CT angiography).
TREATMENT
ED Management
The goal is to treat acute symptoms, make the diagnosis of nephrotic syndrome, and arrange for appropriate follow­up. Treat hypovolemic shock with isotonic fluid, even if edema is severe. For the mildly to moderately dehydrated patient, provide oral rehydration with small, frequent aliquots of sodium­deficient solutions. Treat volume overload with sodium and fluid restriction and diuretics (furosemide,  to  milligrams/kg). Diuretics may not be effective when there is profound hypoalbuminemia, and in that situation, infusion of albumin (0.5 to .0 gram/kg) followed by furosemide may be effective, but intensive care monitoring is required. Treat infection or thrombotic complications as clinically indicated.
Specific Treatment of Nephrotic Syndrome
The mainstay of the treatment of nephrotic syndrome is oral corticosteroids, but the response to steroids varies with the cause. Minimal change disease and mesangial proliferative nephritis are often steroid responsive; membranous nephropathy may respond to steroids; focal segmental
 sclerosis is typically steroid resistant. When indicated, prednisone is often started at  milligrams/kg/d in two or three divided doses, or 
 milligrams/m (maximum  milligrams/d). The duration of initial therapy and subsequent tapering vary across national guidelines, but often continue
,24­26 for weeks to months. In patients with known steroid­responsive disease who experience relapse, the ED physician may restart steroids as above in consultation with a pediatric nephrologist. In steroid­dependent or steroid­resistant nephrotic syndrome, the nephrologist must be consulted for initiation of medications. Common second­line medications for refractory nephrotic syndrome include cyclosporine, cyclophosphamide,
,18,22,26 mycophenolate, tacrolimus, and rituximab.
DISPOSITION AND FOLLOW­UP
Admit patients with severe edema, pulmonary effusions or respiratory symptoms, or signs and symptoms suggestive of systemic infection or thrombotic complications to the hospital. Children with mild or moderate edema can often be treated as outpatients with a low­salt (<2 grams/d) diet and close follow­up with their primary care physician or pediatric nephrologist.
Children with nephrotic syndrome are at high risk for bacterial peritonitis from Streptococcus pneumoniae and should receive the pneumococcal (23­ valent) vaccine to avoid peritonitis. The varicella vaccine should also be administered to children with nephrotic syndrome once they are in remission and no longer receiving steroid therapy.
GLOMERULONEPHRITIS
Glomerulonephritis is a spectrum of inflammatory disorders characterized by hematuria and proteinuria. Signs of glomerulonephritis vary from asymptomatic proteinuria and microscopic hematuria to gross hematuria, nephrotic syndrome, hypertension, and impaired renal functioning requiring renal replacement therapy. Glomerulonephritis is caused by several disorders, all of which cause inflammation leading to glomerular injury.
It can be caused by immune­mediated disorders, inherited disorders, or postinfectious sequelae. Examples of hereditary glomerular diseases include systemic lupus erythematosus nephritis, thin glomerular basement membrane disease, and Alport’s syndrome. Poststreptococcal glomerulonephritis, immunoglobulin A (IgA) nephropathy, and Henoch­Schönlein purpura will be discussed in this section.
PATHOPHYSIOLOGY
Glomerulonephritis is an inflammatory process affecting the glomerulus. Glomerulonephritis usually results from deposition of immune complexes within the glomeruli. These immune complexes activate a number of processes including complement activation, leukocyte recruitment, and release of growth factors and cytokines. This leads to inflammation and injury. Sclerosis occurs within the glomeruli, and fibrosis occurs in the tubulointerstitial
 cells.
Glomerulonephritis may be classified as primary (isolated to the kidney) or secondary (a result of a systemic disorder). There are four main presentations: acute glomerulonephritis, rapidly progressive glomerulonephritis, recurrent macroscopic hematuria, and chronic glomerulonephritis.
Although glomerulonephritis caused by streptococcal disease or Henoch­Schönlein purpura usually resolves completely and without sequelae,
 glomerulonephritis from other causes can progress to renal damage and ultimately end­stage renal failure.
CLINICAL FEATURES
Hematuria is the most common symptom of glomerulonephritis but may be subclinical (microscopic). “Synpharyngitic” macroscopic hematuria refers
 to gross hematuria with concomitant pharyngitis and can be seen in IgA nephropathy. Glomerulonephritis is often associated with hypertension, which may cause headaches when severe. Symptoms related to hypertension may be the chief complaint of a child with undiagnosed
 glomerulonephritis. Patients may complain of bloody or foamy urine (a result of proteinuria), oliguria, nausea, fatigue, or lethargy. The physical examination is often normal.
LABORATORY EVALUATION
In glomerulonephritis, the urinalysis demonstrates macroscopic or microscopic hematuria, RBC casts, and proteinuria. Microscopic examination of urinary sediment shows dysmorphic RBCs and RBC casts. Send urine for culture, because proteinuria and hematuria may represent urinary tract infection, although RBC casts are not typical of infection. Other useful studies include a CBC, creatinine level, and electrolytes. Serum albumin level is often reduced. Send serum complement levels (C3 and C4), because complement proteins (C3) are decreased in >90% of patients with
,29,30 poststreptococcal glomerulonephritis, whereas levels are usually normal in patients with IgA nephropathy. Consider streptococcal serologic tests (antistreptolysin­I and streptozyme). More specific tests may be needed to make a clear diagnosis in illnesses with systemic manifestations such as systemic lupus erythematosus. A renal biopsy is often required for definitive diagnosis in glomerulonephritic disorders.
POSTSTREPTOCOCCAL GLOMERULONEPHRITIS
Poststreptococcal glomerulonephritis is caused by prior infection with group A β­hemolytic streptococci. Only certain strains of this group are
“nephritogenic,” and the pharynx and skin are the most common sites of infection leading to acute glomerulonephritis, occurring  to  days after
 pharyngitis and  to  weeks after skin infection. Group A β­hemolytic streptococci stimulate immune complex formation secondary to deposition of streptococcal nephritogenic antigens within the glomerulus. Other infections such as Staphylococcus aureus and Staphylococcus epidermidis may also lead to renal disease, usually with a longer latency period.
Clinically, poststreptococcal glomerulonephritis consists of microscopic or gross hematuria, proteinuria, hypertension, and edema. Children may give a history of a recent upper respiratory tract or skin infection or have tea­colored urine. The most common serologic markers include anti–streptolysin
O or anti–DNAse B titers (or the combined streptozyme test), which are typically elevated, and a serum C3 level, which is typically decreased.
Treatment is largely supportive. Symptoms of poststreptococcal glomerulonephritis usually resolve in a few weeks. Hypertension rarely requires longterm treatment and tends to resolve within  to  weeks. Renal biopsy is not indicated for diagnosis, unless atypical clinical features are present.
Asymptomatic patients with probable poststreptococcal disease and normal vital signs are eligible for discharge after consultation, and arrangement for follow­up, with a nephrologist.
IGA NEPHROPATHY
IgA nephropathy, also known as Berger’s disease, is an autoimmune disease that is responsible for up to 10% of acute glomerulonephritis in the

United States and is the most common single cause of glomerulonephritis worldwide. Initially, IgA is deposited on the mesangial cells of the kidney.
This alone is not enough to cause IgA nephropathy. In addition, there needs to be reduced IgA clearance, development of glomerular injury, and complement activation, all resulting from dysregulation of mucosal­type IgA immune responses. The cause is unknown.
Clinically, IgA nephropathy may present one of three ways: macroscopic hematuria, microscopic hematuria with mild proteinuria, or acute rapidly progressive glomerulonephritis with edema, hypertension, and renal insufficiency. Macroscopic hematuria is often concurrent with an upper respiratory tract infection (synpharyngitic hematuria). The diagnosis is typically based on the clinical history and laboratory data (including urinalysis).
Renal biopsy is confirmatory.
Treatment is symptomatic. Immunosuppressant therapy (e.g., corticosteroids) may be initiated to treat underlying inflammation, depending on disease severity. Angiotensin­converting enzyme inhibitors or angiotensin receptor blockers may be used to control blood pressure, particularly in
 patients with proteinuria. IgA nephropathy can either completely resolve or progress to end­stage renal disease. Concern for IgA nephropathy in the
ED warrants an outpatient referral to nephrology. Rapidly progressive glomerulonephritis requires admission.
HENOCH­SCHÖNLEIN PURPURA
Henoch­Schönlein purpura, also known as IgA vasculitis, is a form of systemic vasculitis associated with IgA deposition in the small vessels of the body.
Palpable purpura, arthritis/arthralgias, abdominal pain, and renal disease make up the classic presentation tetrad. Henoch­Schönlein purpura nephritis is often asymptomatic, and it is extremely important to follow up to detect persistent renal inflammation. Renal complications occur in 20% to
,33
54% of patients with Henoch­Schönlein purpura and include gross or microscopic hematuria, proteinuria, or nephritic syndrome. Of the children diagnosed with Henoch­Schönlein purpura, 40% have mild nephritis, manifested only by microscopic hematuria or low­grade proteinuria. Risk factors for the development of renal complications include male gender, age >10 years, abdominal pain, GI bleeding, persistent purpura, elevated anti–
   streptolysin O, WBC >15,000/mm , and platelets >500 ×  /L. Renal complications may develop any time over a period of  days, and 2% of children
 may develop long­term renal impairment. Obtain a urinalysis to identify RBCs, casts, and protein. Treatment focuses on hydration, rest, and analgesics. Although corticosteroids may provide symptomatic relief for severe abdominal pain, they do not prevent renal
,37 involvement or long­term renal damage and are not recommended. Further discussion of Henoch­Schönlein purpura can be found in
Chapter 133, “Acute Abdominal Pain in Infants and Children,” and Chapter 142, “Rashes in Infants and Children.”
HEMOLYTIC­UREMIC SYNDROME
Hemolytic­uremic syndrome is a multisystem disorder resulting in AKI, thrombocytopenia, and microangiopathic hemolytic anemia. Hemolytic­uremic syndrome is one of the most common causes of AKI in children and typically occurs in those <10 years old. It is classified as typical (diarrhea associated) or atypical. In children, Shiga toxin–producing Escherichia coli causes 90% of hemolytic­uremic syndrome cases, presenting with a prodrome of bloody diarrhea; 10% to 15% of children with Shiga toxin–producing E. coli develop hemolytic­uremic syndrome (see Chapter 131,
,39
“Vomiting, Diarrhea, and Dehydration in Infants and Children”). Other causes of hemolytic­uremic syndrome are S. pneumoniae infection, genetic disorders, oral contraceptive use, pregnancy, and malignancy. Despite widespread immunization for S. pneumoniae, the incidence of hemolytic­
 uremic syndrome associated with invasive disease has not decreased, and nonvaccine strains have replaced vaccine strains in these cases. Mortality and severe renal involvement are higher in S. pneumoniae–associated hemolytic­uremic syndrome than typical Shiga toxin–producing E. coli
 associated disease.
Pathophysiology
Epidemic hemolytic­uremic syndrome is usually caused by infection with E. coli O157:H7, an organism associated with ingestion of undercooked meat, unpasteurized milk, and contaminated fruits and vegetables. E. coli O157:H7 produces a Shiga toxin, which is absorbed from the intestines into the circulation, causing endothelial damage and leading to microangiopathic intravascular thrombosis, RBC hemolysis, thrombocytopenia (due to platelet
 consumption), and decreased glomerular perfusion. Microthrombi are deposited in kidney parenchyma, causing hypertension, oliguria, and anuria.
Renal involvement ranges from mild renal insufficiency to AKI requiring dialysis.
In atypical hemolytic­uremic syndrome associated with S. pneumoniae (5% of cases), pathogenesis is initiated by the pneumococcal enzyme neuraminidase. This enzyme cleaves N­acetylneuraminic acid from the surface of RBCs and endothelial cells, uncovering the T antigen on the surface
 of endothelial cells. This in turn leads to an immune response, initiating the cascade leading to hemolytic­uremic syndrome.
Clinical Features
The majority of hemolytic­uremic syndrome is associated with E. coli enteritis, and the disease starts with nausea, vomiting, and bloody diarrhea with or without fever. Within a week of the resolution of the GI symptoms, pallor, edema, oliguria, shortness of breath, and seizures or encephalopathy develop. S. pneumoniae–associated hemolytic­uremic syndrome can accompany severe invasive disease, typically in the setting of pneumonia, sepsis,
 or meningitis. Other complications include hypertension, heart failure, intussusception, diabetes mellitus, acidosis, and colitis. A careful dietary and travel history may identify a potential source of infection to aid public health officials assess epidemic outbreaks.
Laboratory Evaluation
Obtain a CBC and peripheral smear; microangiopathic hemolytic anemia, one of the cardinal features of hemolytic­uremic syndrome, may be profound with a hemoglobin level between  and  grams/dL; the smear demonstrates schistocytes, helmet cells, and burr cells. The platelet count is

<150,000/mm . The WBC count may be elevated (poor prognosis). If obtained, the Coombs test is negative. Check electrolytes and renal and hepatic function; hyponatremia and hyperkalemia develop as a result of metabolic acidosis from renal failure, and hyperbilirubinemia results from acute hemolysis.
Send a stool specimen for culture and to test for Shiga toxin. Urinalysis demonstrates gross or microscopic hematuria with granular and hyaline casts and variable proteinuria and leukocyturia.
Treatment
ED management is supportive, although some studies suggest that early aggressive volume expansion (in the absence of signs of fluid
,43 overload), may improve outcomes in typical hemolytic­uremic syndrome. Correct life­threatening electrolyte disturbances and treat hypovolemia with IV fluid boluses (10 to  mL/kg normal saline). Antibiotics are contraindicated in pediatric diarrheal illness and may
 increase the risk hemolytic­uremic syndrome. Antiperistaltic agents increase the risk for systemic complications associated with
E. coli infection and are also contraindicated. Blood transfusions may be needed for severe anemia. Platelet transfusion is not recommended because it could worsen the thrombotic process. Treatment with eculizumab or plasma exchange may be helpful.
All patients with hemolytic­uremic syndrome require hospitalization. Patients with neurologic symptoms and oliguric renal failure should be admitted
  to the intensive care unit. Renal replacement therapy is required in approximately half of cases of acute hemolytic­uremic syndrome. Most children
(95%) survive the acute phase of the illness, and most regain normal renal function.
RENAL TUBULAR ACIDOSIS
Renal tubular acidosis is rare. In the absence of diarrhea, it is defined as hyperchloremic metabolic acidosis with a normal anion gap and a normal to
 near­normal glomerular filtration rate.
In children, renal tubular acidosis is typically secondary to an inherited or acquired defect that affects the kidney’s ability to manage bicarbonate, acid, and ammonia. Renal tubular acidosis develops because of impaired distal acidification (type I), reduced proximal bicarbonate reabsorption (type II), or reduced production of ammonium from aldosterone deficiency or resistance (type IV). For example, Fanconi’s syndrome causes a type II renal tubular acidosis and may be associated with hypophosphatemia and rickets. Types I and II renal tubular acidosis result in hyperchloremic metabolic acidosis with hypokalemia, whereas type IV renal tubular acidosis results in hyperkalemia, acidemia, and a low urinary pH; the metabolic acidosis has a normal
,46 anion gap in all types.
There is no single symptom complex that brings children with renal tubular acidosis to medical attention. Chronic acidosis is associated with failure to thrive, and this may result in an ED visit. Depending on the type of renal tubular acidosis, symptomatic hypokalemia or hyperkalemia (weakness, nausea, constipation), rickets, or nephrolithiasis may prompt an ED visit. Often the diagnosis of renal tubular acidosis is suggested by abnormal results on serum chemistry and urine studies that are incidentally discovered in the process of evaluation for unrelated complaints. Table 137­2 describes
,46 the typical laboratory findings in each type of renal tubular acidosis.
TABLE 137­2
Laboratory Findings in Renal Tubular Acidosis (RTA)
Plasma Urinary Minimal Urine pH (in
Type of Serum
Anion Anion the presence of Additional Laboratory Tests
RTA Potassium
Gap Gap acidosis)
Distal or Normal Elevated Normal or >5.5 Arterial blood gas concentrations, urine pH (>5.3), urine type I RTA low calcium/creatinine ratio elevated
Proximal Normal Normal Normal or <5.5 Arterial blood gas concentrations, urine pH (>5.5, except in severe or type II low metabolic acidosis), serum K level, fractional excretion of HCO
RTA
Type IV Normal Elevated High <5.5 Arterial blood gas concentrations, urine pH (<5.5 with severe
RTA metabolic acidosis), urine to blood CO2 , creatinine clearance
Acute treatment consists of correcting the underlying electrolyte and acid­base abnormalities. Maintenance treatment includes oral bicarbonate therapy and monitoring of serum potassium for all types of renal tubular acidosis, vitamin D and sodium phosphate for type II renal tubular acidosis,
 and loop diuretics and fludrocortisone for mineralocorticoid deficiency in type IV renal tubular acidosis.
HYPERTENSION
,49
Pediatric hypertension is increasing in incidence, with prevalence estimates ranging from .3% to .5% in children. This increase is related to
 higher rates of childhood obesity, greater salt intake, hyperlipidemia, and decreased physical activity. Boys, adolescents, and Hispanic and African

American race are associated with higher rates of hypertension in the United States. The definition of hypertension in children has undergone several revisions, and the latest guidelines from the American Academy of Pediatrics (2017) are summarized in Table 137­3. TABLE 137­3
Definition of Elevated Blood Pressure and Hypertension in Children
Age  to <13 y* Age ≥13 y
Elevated blood pressure ≥90th to <95th percentile or 120/80 mm Hg to <95th percentile 120/<80 to 129/<80 mm Hg
Stage I hypertension ≥95th to <95th percentile +  mm Hg or 130/80 to 139/89 mm Hg 130/80 to 139/89 mm Hg
Stage II hypertension ≥95th percentile +  mm Hg or ≥140/90 mm Hg ≥140/90 mm Hg
*Use lower value.
Traditionally, hypertensive urgency was a severely elevated blood pressure without evidence of target organ damage that, left untreated, may cause end­organ damage, whereas hypertensive emergency was defined as blood pressures exceeding the 99th percentile for age and sex with
 acute end­organ damage that requires immediate treatment. With the updated American Academy of Pediatrics practice guidelines mentioned
 earlier, the term acute severe hypertension was suggested to describe any acute symptomatic presentation of hypertension. Generally, the CNS, kidneys, and cardiovascular system are the organs most likely to be damaged secondary to hypertension. Hypertensive crises in younger children are usually secondary to an underlying disease.
Essential hypertension is uncommon in younger children and is more prevalent in adolescents. Renal disease (glomerulonephritis, hemolyticuremic syndrome, chronic infections, obstructive lesions, and renal vascular disease) is the most common cause of secondary hypertension in children. Endocrine causes of hypertension include tumors that secrete vasoactive peptides (pheochromocytoma), abnormal levels of endogenous steroid hormones (Cushing’s syndrome), adrenocortical steroid therapy, and hyperthyroidism. Hypertension may also result from congenital heart disease such as coarctation of the aorta. Elevated intracranial pressure may also lead to hypertension in an attempt by the body to maintain cerebral perfusion pressure and can be caused by space­occupying lesions, acute hemorrhage, infection, or obstruction to cerebrospinal fluid flow. Exogenous medications or toxins may also cause hypertension. Table 137­4 outlines the common causes of hypertension by age group.
TABLE 137­4
Common Causes of Hypertension in Children
Age Group Cause
Newborn Renal: thrombosis, stenosis, polycystic kidney disease
Heart: coarctation of the aorta
Endocrine: pheochromocytoma, Cushing’s disease
Preschool/kindergarten Renal: parenchymal disease, vascular disease
(<6 y) Heart: coarctation of the aorta
Endocrine: pheochromocytoma, Cushing’s disease
School age (6–10 y) Endocrine: pheochromocytoma, Cushing’s disease, thyrotoxicosis
Adolescence Essential hypertension (especially in obese adolescents)
Renal: parenchymal, vascular
Endocrine: pheochromocytoma, Cushing’s disease, thyrotoxicosis
Drugs of abuse (e.g., cocaine, amphetamines), NSAIDs, monoamine oxidase inhibitors, steroids, calcineurin inhibitors
(cyclosporin/tacrolimus)
CLINICAL FEATURES
Children with hypertensive crisis range from having mild symptoms such as headache, nausea, vomiting, visual changes, and anxiety to life­threatening encephalopathy or focal neurologic deficits, chest pain and shortness of breath from acute heart failure and pulmonary edema, and anuria from AKI.
In neonates and young infants, feeding problems, irritability or lethargy, respiratory distress, or seizures may be manifestations of a hypertensive
 crisis.
History and Comorbidities
Obtain a detailed history of symptoms that suggest end­organ damage including neurologic symptoms, chest pain, shortness of breath, decreased urine output, or hematuria, as described earlier. Other symptoms may help to identify an underlying cause such as palpitations, weight loss, flushing, and diarrhea, which point to an endocrine disorder. Identify any medications or substances associated with blood pressure elevation, such as oral contraceptives, steroids, immunosuppressants, and illicit drugs (e.g., cocaine, amphetamines). Ask about a family history of essential hypertension, diabetes, obesity, renal disease, hyperlipidemia, stroke, or endocrinopathy. For those with an established diagnosis of hypertension, ask about medication adherence or abrupt withdrawal.
Physical Examination
Obtain an accurate height and weight and determine percentiles for age. Obtain four­limb blood pressures in infants (a lower blood pressure in the lower extremities compared to the upper extremities or left versus right arms may indicate aortic coarctation). Perform a comprehensive physical examination, including a funduscopic examination (for retinal hemorrhages, papilledema, infarcts) and a neurologic examination. Assess the heart and lungs for signs of congestive heart failure or structural disease (gallops, murmurs, rales). Palpate the abdomen to exclude masses or pregnancy.
Auscultation of an abdominal bruit may suggest renovascular disease.
Laboratory Evaluation
Assess renal function with a serum BUN, creatinine, electrolytes, glucose, plasma rennin activity, aldosterone levels, and microscopic urinalysis. Obtain a CBC and reticulocyte count to look for rheumatic disorders, appropriate marrow response, and signs of anemia. Perform a pregnancy test in pubertal girls. Ordering of more esoteric tests for endocrine abnormalities should be left to subspecialists.
Imaging
Obtain a chest radiograph and ECG. Obtain an echocardiogram to look for left ventricular hypertrophy and to rule out cardiac causes of hypertension.
Obtain a head CT if neurologic findings are present. Renal US is indicated to rule out structural kidney abnormalities. If suspicion for renovascular disease is high, then obtain a CT angiography or magnetic resonance angiography.
TREATMENT
Most patients with mild to moderate elevation of blood pressure in the ED are discharged with instructions for follow­up for outpatient evaluation and
 treatment. Hypertensive urgency may be treated with oral antihypertensives (Table 137­5).
TABLE 137­5
Oral Antihypertensives for Hypertensive Urgency in Infants and Children
Onset of
Drug Class Dosage Route Comments
Action
Isradipine Calcium channel .05–0.1 milligram/kg/dose PO 2–3 h Tachycardia, headache blocker up to  milligrams/dose Caution in those taking azole antifungals
(hypotension)
Nifedipine Calcium channel .1–0.25 milligram/kg/dose PO, Immediate Precipitous drop in blood pressure, tachycardia, blocker sublingual release, 20–30 headache min
Extended release, .5–5 h
Minoxidil Vasodilator .1–0.2 milligram/kg/dose PO Within  min Fluid retention
Doxazosin α­Blocker 1–2 milligrams/kg per dose PO 2–6 h Dizziness, orthostatic hypotension
Useful in hyperadrenergic states (e.g., pheochromocytoma)
Prazosin α­Blocker .02–0.04 PO 30–90 min Dizziness, headache milligram/kg/dose Useful in hyperadrenergic states (e.g., pheochromocytoma)
Clonidine Central α­agonist 2–10 micrograms/kg/dose PO 30–60 min Rebound hypertension, sedation, dry mouth every 6–8 h
Captopril Angiotensin­ .1–0.2 milligram/kg/dose PO 10–20 min Contraindicated in bilateral renal artery stenosis; converting enzyme .01–0.1 milligram/kg/dose not recommended in acute or chronic renal failure inhibitor in neonates
Treatment of hypertensive emergency begins with evaluation and stabilization of the airway, breathing, and circulation. Obtain IV or IO access and start cardiac monitoring; consider placement of a Foley catheter and arterial line. The goal is to reduce the mean arterial pressure by ≤25% over the
 first  to  hours, followed by a gradual reduction to normal values over the next  to  hours toward the 95th percentile for age. Reducing the blood pressure too aggressively can lead to ischemic complications such as acute neurologic issues, blindness, and renal failure. Recommendations
 regarding the most useful drugs for treating severe hypertensive emergency in children are listed in Table 137­6. Medications should be chosen according to their side effect profile, availability, and physician familiarity, as there are limited clinical data in children and infants.
TABLE 137­6
Parenteral Antihypertensives for Hypertensive Crisis in Infants and Children
Drug Class Dosage Route Onset Comments
Nitroprusside Vasodilator .5–8.0 micrograms/kg/min IV infusion IV Seconds May increase intracranial pressure. Monitor cyanide infusion and thiocyanate levels for patients with renal and liver disease when administering for >24–48 h.
Hydralazine Vasodilator .1–0.5 milligram/kg/dose; maximum, IV, IM 5–30 min Administer every  h when given as IV bolus. Not as
 milligrams/dose strong as other agents. Recommended dose is less than U.S. Food and Drug Administration–approved label. Reflex tachycardia
Diazoxide Vasodilator 1–3 milligrams/kg every 5–15 min IV bolus Within Risk of hypotension minutes
Nicardipine Calcium .0–3.0 micrograms/kg/min IV infusion IV Within May cause increased intracranial pressure, headache, channel infusion minutes nausea, and hypotension blocker
Labetalol α­ and β­ Bolus: .2–1.0 milligram/kg/dose to a IV bolus 2–5 min Contraindications include asthma, chronic lung blocker maximum of  milligrams/dose, then or disease, and evident heart failure; may mask infusion: .25–3.0 milligrams/kg/h infusion hypoglycemic symptoms
Urapidil α ­Blocker Initial dose .5–4.0 milligrams/kg/h IV 1–5 min Contraindicated in aortic stenosis; palpitations,

Maintenance dose .2–2.0 infusion nausea, sedation and central milligrams/kg/h
5­HT
1A agonist
Esmolol β­Blocker 100–500 micrograms/kg/min (initial IV Immediate May cause bronchospasm, congestive heart failure, dose), then 50–300 infusion and profound bradycardia micrograms/kg/min
Fenoldopam Dopamine .2–0.8 microgram/kg/min IV Within Tachycardia, flushing, headache receptor infusion minutes agonist
Furosemide Loop .5–5 milligrams/kg/dose IV bolus Within Useful for volume overload hypertension; may cause diuretic minutes hypokalemia
Diazoxide Vasodilator 1–3 milligrams/kg every 5–15 min IV bolus Within Risk of hypotension minutes
DISPOSITION AND FOLLOW­UP
Mild hypertension should be managed on an outpatient basis by the primary care provider or subspecialist. Hypertensive urgencies and emergencies require ED stabilization and initial pharmacologic treatment in the ED with subsequent admission to the intensive care unit or medical ward depending on the degree of end­organ damage and the response to initial interventions.
HEMATURIA
Hematuria is the presence of an increased number of RBCs (≥5 RBCs/µL of urine). Hematuria may be macroscopic (apparent to the naked eye) or microscopic (apparent only on urinalysis). It is frequently asymptomatic.
Hematuria can be divided into three types: macrohematuria, transient hematuria, and persistent microhematuria. Macroscopic hematuria is most frequently caused by urinary tract infections or blunt abdominal trauma. Other causes include nephrolithiasis, poststreptococcal glomerulonephritis,
IgA nephropathy, and malignancy. Transient hematuria may be caused by strenuous exercise, trauma, menstruation, bladder catheterization, and
 fever. Persistent microhematuria can be seen in benign familial hematuria, idiopathic hypercalciuria, IgA nephropathy, Alport’s syndrome, and sickle
 cell trait or anemia or with drugs or toxins.
CLINICAL FEATURES
History and Comorbidities

Obtain a complete history, because the differential diagnosis is broad. Distinguish between transient, persistent, and recurrent hematuria.
Associated dysuria, urinary frequency and urgency, fever, and abdominal or flank pain suggest infection or urolithiasis (see Chapter , “Urologic
Stone Disease”). A history of an upper respiratory tract infection, sore throat, or skin infection may suggest postinfectious glomerulonephritis. A current infectious process is suspicious for IgA nephropathy. For transient hematuria, ask about blunt abdominal trauma, recent catheterization, or menstruation. The color of the urine (pink, red, or tea colored) and the timing during micturition—at the beginning (associated with pathology of the urethra), throughout micturition (associated with bleeding above the bladder neck), or at the end of micturition (associated with pathology of the bladder neck, posterior urethra, or prostate)—provide useful diagnostic information. Ask about joint pain and rash (Henoch­Schönlein purpura or lupus). Some drugs associated with hematuria are NSAIDs, anticonvulsants, warfarin, diuretics, penicillin, and chlorpromazine. Recent vigorous exercise can cause hematuria, which resolves after a period of rest. Obtain a family history carefully, because many causes of hematuria in children are inherited. Questions about family history should be directed to information regarding deafness, hematuria, hypertension, coagulopathy,
 hemoglobinopathy, calculi, renal failure, dialysis, and transplant. Staining reported as “blood on the diaper” of an infant without other symptoms may represent benign urinary crystals, extra–urinary tract blood (e.g., vaginal bleeding in female neonates), or blood from the GI tract. The presence of amorphous crystals in the urine is a common and benign finding in neonates, and because these crystals are often pink or orange, they may be interpreted as blood by parents. Dipstick testing is negative for blood in this situation.
Physical Examination
The physical examination findings vary depending on the cause of hematuria suggested by historical information. Obtain vital signs to identify hypertension or a fever. Assess for signs of respiratory infection, joint swelling, and skin rashes. Perform a careful GU examination to identify a source of external bleeding such as a periurethral tear.
DIAGNOSIS
Laboratory Evaluation
The laboratory evaluation begins with confirmation of hematuria. Medications such as chloroquine, rifampin, isoniazid, malin, and nitrofurantoin may
 cause a red­brown discoloration of the urine. Similarly, foods such as beets, rhubarb, or blackberries may also cause discoloration. Because such urinary discoloration may be misinterpreted by parents as blood, screen with a urine dipstick test, which can exclude hematuria. A positive dipstick test result, however, must be followed by microscopic evaluation. Microscopic examination of the urine helps narrow the differential diagnosis: dysmorphic RBCs and casts suggest glomerulonephritis; WBCs and bacteria suggest infection; eosinophils may be seen in interstitial nephritis; and intact RBCs suggest lower tract causes of hematuria. Urinary crystals or stones may be seen in urolithiasis. A dipstick test result positive for blood without evidence of RBCs on microscopy suggests hemoglobinuria or myoglobinuria. Further evaluation of the urine includes rapid or quantitative evaluation for proteinuria, which can be seen in nephritis, nephrotic syndrome, and orthostatic proteinuria. Obtain other laboratory studies to identify serious causes of hematuria, such as hemolytic­uremic syndrome, acute poststreptococcal glomerulonephritis, or renal insufficiency.
Imaging
US is the imaging method of choice for macroscopic hematuria without proteinuria or RBC casts in the urine and is done to rule out malignancy or structural defects. For patients with trauma or macroscopic hematuria, a more complete anatomic evaluation is needed, including CT, angiography, or retrograde urethrography depending on the history and clinical suspicion.
TREATMENT
The treatment of hematuria, like its evaluation, depends on the suspected cause. Most children without signs of major or life­threatening etiologies can be managed as outpatients. Children with isolated microscopic hematuria do not require an extensive evaluation if the blood pressure and urine output are normal. Hematuria requires a more rigorous evaluation when the blood pressure is elevated or there is significant proteinuria, so consult with a nephrologist. Refer to a urologist if there is suspicion of a urogenital tract anatomic abnormality, obstructing calculi, tumor, or recurrent nonglomerular macroscopic hematuria.
CHRONIC KIDNEY DISEASE

Chronic kidney disease is defined as a glomerular filtration rate <60 mL/min/1.73 m for more than  months regardless of other markers of chronic
  kidney disease or >60 mL/min/1.73 m with evidence of structural damage, functional abnormalities, or pathologic abnormalities. End­stage renal disease occurs when the glomerular filtration rate is <10% of normal for age. Mortality in end­stage renal disease usually results from cardiovascular
 causes (40% to 50%) and infection (20%). The only definitive treatment for end­stage renal disease is transplantation; however, the morbidity and mortality associated with chronic renal replacement therapy have decreased.
Chronic kidney disease is classified into five separate stages based on glomerular filtration rate with the addition of categories of albuminuria and
 proteinuria (Table 137­7). The recommended method for determination of glomerular filtration rate is with spot urine and serum creatinine using either the Schwartz or Counahan calculation. Twenty­four–hour urine collections for creatinine are no longer recommended.
TABLE 137­7
Staging of Pediatric Chronic Kidney Disease
Glomerular Filtration Stage Albuminuria and Proteinuria Stage
G1: Normal GFR (≥90 mL/min/1.73 m2) A1: Normal to mildly increased (<30 milligrams albumin/gram creatinine)
A2: Moderately increased (30 to 300 milligrams albumin/gram creatinine)
G2: GFR between  and  mL/min/1.73 m2
A3: Severely increased (>300 milligrams albumin/gram creatinine)
G3a: GFR between  and  mL/min/1.73 m2
G3b: GFR between  and  mL/min/1.73m2
G4: GFR between  and  mL/min/1.73 m2
G5: GFR of <15 mL/min/1.73 m2 (kidney failure)
Abbreviation: GFR = glomerular filtration rate.
ETIOLOGY AND DIFFERENTIAL DIAGNOSIS
Congenital renal disease is the most common cause of chronic renal failure in young children, whereas glomerulonephritis and reflux nephropathy predominate in older children. Congenital structural lesions include dysplasias and cystic malformations (e.g., polycystic kidney disease). Obstructive uropathy leading to end­stage renal disease may be caused by posterior urethral valves in boys, severe vesicoureteral reflux with recurrent infection, and ureteropelvic junction obstruction. End­stage renal disease in children can be caused by hereditary nephritis or acquired nephropathies such as hemolytic­uremic syndrome, glomerulonephritis, and cortical necrosis (more common in children with sickle cell disease).
CLINICAL FEATURES
Take a complete history to obtain information about changes in urination, fatigue, swelling, anorexia, emesis, bone pain, muscle cramps, headache, and change in mental status. Ask about signs and symptoms related to potential complications from chronic kidney disease.
Complications associated with chronic kidney disease include disorders of fluids, electrolytes, and mineral metabolism. Anemia, hypertension, dyslipidemia, and endocrine abnormalities, including growth impairment, are present. End­stage renal disease is associated with cardiovascular problems and cerebrovascular events from malignant hypertension. Skeletal, hematologic, and intestinal abnormalities accompany renal failure.
Renal failure predisposes to non­Hodgkin’s lymphoma and skin cancer.
Pertinent physical findings in patients with end­stage renal disease include short stature, CNS problems, peripheral neuropathies, and rickets. Fever should prompt an aggressive search for a source. Fluid overload is suggested by peripheral edema and pulmonary congestion. Pericarditis is less common in children with end­stage renal disease than in adults. Abdominal pain and tenderness in children receiving peritoneal dialysis suggests peritonitis.
TREATMENT
The standard of treatment for most patients with end­stage renal disease is hemodialysis. Children <2 years of age are often treated with peritoneal dialysis because it is associated with fewer complications than hemodialysis in young children. Renal transplantation is the ultimate goal.
In dialysis patients presenting to the ED with fever, an aggressive search for infection must ensue. Use of empiric antibiotics is directed by the source of the infection (e.g., S. aureus, S. epidermidis), after cultures are drawn. If a patient on peritoneal dialysis presents with abdominal pain, suspect bacterial peritonitis. In patients presenting with severe electrolyte abnormalities, fluid overload, severe hypertension, or uremic pericarditis, urgent dialysis is indicated. Dialysis patients presenting with syncope should be evaluated for electrolyte abnormalities, hypovolemia, and cardiac dysrhythmias. See Chapter , “End­Stage Renal Disease,” in the adult section for detailed discussion.


