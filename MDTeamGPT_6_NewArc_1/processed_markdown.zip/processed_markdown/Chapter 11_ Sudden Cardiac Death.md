University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 11: Sudden Cardiac Death
Joseph P. Ornato
INTRODUCTION AND EPIDEMIOLOGY
This chapter focuses on the epidemiology and pathophysiology of sudden cardiac death in adults and strategies for prevention and treatment. See
Chapters  (“Cardiac Rhythm Arrhythmias”),  (“Basic Cardiopulmonary Resuscitation”),  (“Defibrillation and Electrical Cardioversion”), and 
(“Cardiac Resuscitation”) for detailed discussion of resuscitation pharmacotherapy.

Sudden, unexpected, out­of­hospital cardiac arrest occurs in approximately 341,397 adult Americans each year. Estimated national survival of EMS­ treated out­of­hospital cardiac arrest cases is .8%, yielding an estimated overall out­of­hospital cardiac arrest survival rate of .4% (EMS­treated plus
  deceased­on­EMS­arrival cases). There is substantial variability in the odds for survival across various geographic locations.
Most episodes of sudden cardiac death occur in the home, although victims who experience cardiac arrest in a public place have a much better chance
 of survival. The initial recorded cardiac arrest rhythm is more likely to be ventricular fibrillation when cardiac arrest occurs in a public location rather than in the home, likely because patients who experience cardiac arrest in the home are typically older and more likely to have one or more chronic
 diseases that limit or exclude participation in activities outside the home. Sudden cardiac death is 30% to 80% higher among residents in the lowest
 compared with the highest socioeconomic quartile. This association is likely due to lifestyle and healthcare disparity issues.
,6
There is a circadian pattern of sudden cardiac death and acute myocardial infarction, and both are most likely to occur within the first few hours after awakening from sleep, when there is increased sympathetic stimulation. β­Blockade provides some protection from sudden cardiac death,
 particularly in patients with known coronary artery disease who have had myocardial infarction and have a low ejection fraction.

Prevalence of sudden cardiac death in adults is greatest in the age group older than  to  years, with 60% occurring in males. There are multiple known factors contributing to the likelihood of sudden cardiac death (Table 11­1).
TABLE 11­1
Known Factors Contributing to the Likelihood of Sudden Cardiac Death
Cardiovascular pathology
Coronary artery disease
Severe left ventricular dysfunction
Cardiomyopathy
Hypertrophic cardiomyopathy
Arrhythmogenic right ventricular cardiomyopathy
Congenital heart disease, especially coronary artery anomalies
Valvular heart disease
Cardiac pacemaker and conducting system disease
Hereditary channelopathies
Brugada syndrome
Early repolarization syndrome (ERS)
Long QT syndrome (LQTS)
Short QT syndrome (SQTS)

Catecholaminergic polymorphic ventricular tachycardia (CPVT)
Chapter 11: Sudden Cardiac Death, Joseph P. Ornato 
. Terms of Use * Privacy Policy * Notice * Accessibility
Risk factors and triggers
Long­term risk factor management
Hypertension
Hyperlipidemia
Smoking
Diabetes mellitus
Socioeconomic status
Unstable atherosclerotic plaque
Psychological stress
Physical activity
Coronary artery disease (which is often undiagnosed before the event) is the major cause of sudden cardiac death in adults and is present in 80% of cases, followed by cardiomyopathy (10% to 15%) and other miscellaneous conditions (e.g., hereditary channelopathies, valvular disease, congenital
 anomalies), which account for most of the remaining 5% to 10% of cases.
PATHOPHYSIOLOGY
CORONARY ARTERY DISEASE

Coronary atherosclerosis is present on autopsy in 80% of sudden cardiac death victims. Coronary artery disease is also found in 70% to 80% of cardiac
9­12 arrest victims who survive and undergo coronary angiography. Approximately one third have evidence of acute plaque rupture in areas of long­
,11 segment coronary stenosis. A documented initial cardiac arrest rhythm of ventricular fibrillation (or shockable rhythm if an automated external defibrillator was applied) suggests that an acute coronary syndrome is the cause, since ventricular fibrillation is noted in the majority of cases in which
9­12  a coronary occlusion is found on angiography. However, ventricular fibrillation is present in only 23% of all cardiac arrests.
SEVERE LEFT VENTRICULAR DYSFUNCTION

Severe left ventricular dysfunction with a reduced ejection fraction is currently the best available predictor of sudden death risk. Patients with an ejection fraction ≤35% are the primary candidates for an implantable cardioverter­defibrillator. However, almost half of sudden deaths occur in individuals with normal left ventricular function.
CARDIOMYOPATHY
Cardiomyopathy with reduced left ventricular function, regardless of cause or presence of decompensated heart failure, is another predictor of sudden cardiac death. Dilated ventricles promote dispersion of ventricular depolarization and/or repolarization, allowing “islands” of ventricular tissue to depolarize and repolarize at different rates. The lack of homogeneity in electrical activation and recovery fosters the development of circus movement reentry, which can initiate and sustain ventricular tachyarrhythmias. Myocardial ischemia and/or infarction can also transiently diminish the homogeneity of left ventricular depolarization and repolarization. Left ventricular hypertrophy (often a result of hypertension and/or valvular heart disease) or conduction disturbances (left or right bundle branch block or a nonspecific intraventricular conduction disturbance) can create similar functional disturbances.
In­hospital cardiac arrest patients with heart failure are more likely to have ventricular fibrillation as the initial documented cardiac arrest rhythm
 compared with non–heart failure patients. New York Heart Association functional class II (symptoms with moderate exertion) and III (symptoms with mild exertion) patients are at higher risk of sudden cardiac death than death from pump failure, whereas class IV patients (symptoms at rest) are more
,15 likely to die of pump failure than sudden cardiac death.

Hypertrophic cardiomyopathy is characterized by unexplained left ventricular hypertrophy associated with nondilated ventricular chambers. The
 disorder can cluster in families, and the risk of sudden cardiac death increases at a rate of approximately 1% per year. Hypertrophic cardiomyopathy is the most common cardiovascular cause of sudden cardiac death in young athletes, accounting for one third of
 such events, and its presence disqualifies affected individuals from competitive sports. Implantable cardioverter­defibrillator placement is recommended for individuals with prior documented cardiac arrest; ventricular fibrillation; hemodynamically significant or nonsustained ventricular tachycardia; a first­degree relative who has had sudden cardiac death; one or more recent, unexplained episodes of syncope; a maximum left ventricular wall thickness ≥30 mm; or an abnormal blood pressure response to exercise in the presence of other sudden death risk factors or
 modifiers; and in high­risk children with unexplained syncope, massive left ventricular hypertrophy, or family history of sudden cardiac death.
Arrhythmogenic right ventricular cardiomyopathy is a hereditary form of cardiac muscle disease that is characterized by right­sided heart failure, ventricular arrhythmias of right ventricular origin (i.e., ventricular tachycardia with a left bundle branch block morphology), syncope, and
,18 sudden cardiac death. The ECG typically shows T­wave inversion in the right precordial leads (V ). Severe right heart failure develops
1­3 in the majority of cases. Patients suspected of having this disorder should be referred for cardiology evaluation. Implantable cardioverter­defibrillator placement is often the treatment of choice since β­blockers and other antiarrhythmics do not usually prevent symptomatic ventricular arrhythmias in
 these patients.
CONGENITAL HEART DISEASE

Congenital heart disease occurs in approximately .8% of all live births. Because many children with congenital heart disease survive to adulthood as a result of improvements in cardiac surgery, sudden cardiac death is a frequent cause of later morbidity and mortality. Congenital heart defects
 commonly associated with sudden cardiac death in children and adults are listed in Table 11­2. TABLE 11­2
Congenital Heart Defects Commonly Associated with Sudden Cardiac Death19
Coronary artery anomalies (anomalous left coronary artery from the pulmonary artery [ALCAPA] syndrome)
Aortic stenosis
Aortic coarctation
Tetralogy of Fallot
Transposition of the great arteries
Ebstein’s anomaly
Single ventricle
The most frequent coronary artery anomaly associated with sudden cardiac death is anomalous origin of the left coronary artery from the pulmonary artery syndrome, which results in the left coronary artery traversing between the aorta and main pulmonary artery. This
 disorder is being diagnosed more frequently in adults by cardiac CT and MRI. Ischemic symptoms, ventricular arrhythmias, and sudden death can be triggered during exercise as a result of increasing venous return, which dilates the main pulmonary artery and compresses the anomalous coronary artery in the space between the aorta and main pulmonary artery. Treatment is surgical correction.
The greatest risk of sudden cardiac death in children and adults with congenital heart disease exists in those with left heart obstructive lesions (e.g., aortic stenosis, aortic coarctation) and cyanotic defects (e.g., Ebstein’s anomaly, corrected transposition of the great
 vessels, tetralogy of Fallot). Most sudden death events in this population occur during exercise, with half of cases resulting from ventricular
 fibrillation. Nonventricular arrhythmias (e.g., sinus node dysfunction, atrioventricular block, supraventricular tachyarrhythmias) are also common,
 even after surgical correction.
VALVULAR HEART DISEASE
Hemodynamically severe aortic stenosis can cause effort­induced dyspnea, myocardial ischemia, and ventricular arrhythmias, which can trigger syncope and sudden cardiac death. The most common causes of aortic stenosis are a congenitally bicuspid aortic valve that typically calcifies and narrows its orifice in mid­adulthood or sclerosis/calcification of a tricuspid aortic valve, which can occur in individuals who are older than  or  years of age. A harsh, late­peaking systolic murmur at the upper­right sternal border with radiation to the neck is a typical finding in hemodynamically significant aortic stenosis.
CARDIAC PACEMAKER AND CONDUCTING SYSTEM DISEASE
Sick sinus syndrome affects the heart’s primary pacemaker and can cause intermittent lightheadedness, syncope, or sudden cardiac death. Although it is more common with advancing age, primary electrical failure of the heart can occur in infants and children. The cause is unknown, but pathologic studies reveal histologic degeneration of the sinoatrial node. In addition, the disorder often involves the atrioventricular node and the conduction tissue between the sinoatrial and atrioventricular nodes. Therefore, sick sinus syndrome should be thought of as a diffuse degenerative disease of the heart’s electrical generation and conduction system. Idiopathic sclerodegeneration of the atrioventricular node and the bundle branches (Lenègre’s disease) or invasion of the conduction system by fibrosis or calcification spreading from adjacent cardiac structures (Lev’s disease) can lead to bradyasystolic heart block with or without cardiac arrest. In rare cases, a clinical presentation resembling the sick sinus syndrome can occur when the heart’s electrical system is affected by systemic disease, vascular compromise, or tumor. Symptomatic bradycardia is treated with pacemaker placement.
HEREDITARY CHANNELOPATHIES
Sudden Arrhythmic Death Syndrome
The sudden arrhythmic death syndrome is characterized by sudden cardiac death occurring out of hospital in relatively young adults (mostly men), often during sleep or at rest, usually without any premonitory symptoms (including syncope) and with no
,19 anatomic abnormality identified at autopsy. Genetic disorders are associated with sudden arrhythmic death syndrome, and many cases can be identified clinically based on their characteristic ECG patterns.
Ion Channel Disease
Cardiovascular and genetic examination of first­degree relatives can identify an inherited form of heart disease known as a
“channelopathy” or “ion channel disease” in almost half of cases. Ion channel flux is responsible for the initiation, propagation, and repolarization of the cardiac action potential. Ion channel disease is caused by mutations in the genes that encode the proteins responsible for
 forming and interacting with the specialized sodium, potassium, and calcium ion channels within the heart. There are many known ion channelopathies, modulated by a variety of causative gene defects that can have variable phenotype penetration in a given family. Genetic testing is used to screen family members for a known mutation. Common subtypes are listed in Table 11­1. Brugada Syndrome
Brugada syndrome most commonly affects men and consists of a prominent J­wave with a characteristic downsloping ST­segment elevation in ECG leads V (Figure 11­1). This ECG pattern resembles a right bundle branch block and is associated with a 40% to 60% incidence
1–3 of life­threatening ventricular arrhythmias (particularly polymorphic ventricular tachycardia that degenerates into ventricular fibrillation) and sudden cardiac death. The syndrome exhibits an autosomal dominant inheritance that results in total loss of function of the sodium channel or in acceleration
 of recovery from sodium channel activation. Brugada syndrome is common in Southeast Asia (where it is called sudden unexplained nocturnal death syndrome), in the Philippines (bangungut, “to rise and moan in sleep”), in Japan (pokkuri, “sudden and unexpectedly ceased phenomena”), and in Thailand (lai tai, “death during sleep”). It is crucial for emergency physicians to identify this condition from its characteristic ECG pattern, because the risk of sudden cardiac death is high and can be prevented by
 internal cardioverter­defibrillator placement.
FIGURE 11­1. Brugada syndrome. Twelve­lead ECG typical of Brugada syndrome shows characteristic downsloping ST­segment elevation in leads V and V and QRS
  morphology resembling a right bundle branch block.
Early Repolarization Syndrome
Early repolarization syndrome is present in 1% to 2% of adults (mostly males) and has long been considered to be a benign variant of normal
 ventricular repolarization. Its prevalence is higher (10%) in general athletes and reaches as high as 100% in top­performing, endurance­trained
 individuals. Classic ECG diagnostic criteria are a prominent, notch­like J wave on the QRS downslope, followed by upsloping ST­segment elevation
(Figure 11­2). These changes are seen most prominently in the mid to lateral precordium but can also occur just laterally or inferiorly. There is commonly reciprocal ST­segment depression in aVR. Rapid ventricular pacing or exercise usually normalizes these changes.
FIGURE 11­2. Early repolarization syndrome. Note in V the prominent notch­like J wave on the QRS downslope and the upsloping ST segment.

There may be similarity or overlap between Brugada and early repolarization syndromes, but the clinical significance of early repolarization syndrome
 has not been established. Both syndromes are often familial and more prominent in males, and drugs alter their characteristic ECG patterns (sodium
,27 channel blockers and β­blockers increase the ST­segment elevation, whereas isoproterenol or mild exercise decreases the ST­segment elevation).
Referral for an outpatient cardiology evaluation might only be warranted in the case of a teenager or young adult with syncope of unknown origin and/or with a family history of sudden cardiac death at an early age and with an ECG pattern of early repolarization.
Long QT Syndrome
The long QT syndrome is characterized by prolongation of the corrected QT interval, syncope, and sudden death caused by
 torsades de pointes and ventricular fibrillation. The corrected QT interval can be calculated using Bazett’s equation: where QT is the corrected QT interval in seconds, QT is the measured QT interval in seconds, and R­R is the interval between any two consecutive R c m waves on the ECG in seconds. Because the QT interval is heart rate dependent, the formula “corrects” the measured QT interval to a heart rate of  beats/min (at which the R­R interval is  second). Because the square root of  = , the QT equals the QT at a heart rate of  beats/min (at which the c m normal QT interval limits are .35 to .44 second).
Prolongation of the corrected QT interval represents dispersion in ventricular repolarization and can be hereditary or acquired
(e.g., hypokalemia, hypomagnesemia, hypocalcemia, anorexia, ischemia, CNS pathology, levofloxacin, terfenadine­ketoconazole
,28 combinations, or certain antipsychotic or antiarrhythmic drugs). Hereditary long QT syndrome can have an autosomal recessive (Jervell
 and Lange­Nielsen syndrome with nerve deafness) or dominant (Romano­Ward syndrome without nerve deafness) mode of inheritance.
Management of patients with long QT syndrome involves avoidance of QT­prolonging drugs (an up­to­date list maintained by

AzCERT can be found at http://www.QTdrugs.org) and high­intensity sports, as well as cardiology/electrophysiology referral. A β­ blocker is typically prescribed as prophylaxis against sudden cardiac death. Long QT syndrome patients who have syncope, torsades de pointes, or
 ventricular fibrillation despite β­blocker therapy are candidates for implantable cardioverter­defibrillator placement.
Short QT Syndrome
An abnormally short corrected QT interval (i.e., <0.34 second) can be secondary to hypercalcemia, hyperkalemia, acidosis, systemic inflammatory syndrome, myocardial ischemia, or increased vagal tone or can be inherited in an autosomal dominant genetic
 pattern. The genetic variety, dubbed the “short QT syndrome,” is associated with atrial arrhythmia, including atrial fibrillation, syncope,
 polymorphic ventricular tachycardia, ventricular fibrillation, and sudden cardiac death. Early repolarization, especially in the inferolateral leads, is
 noted in 65% of patients. These individuals should also be referred for cardiology/electrophysiology evaluation and are candidates for cardioverter­
 defibrillator placement if syncope or life­threatening ventricular arrhythmias are documented.
Catecholaminergic Polymorphic Ventricular Tachycardia
Catecholaminergic polymorphic ventricular tachycardia is another genetically determined disorder involving defective myocardial cellular calcium handling. Affected individuals have exercise­ and stress­related ventricular tachycardia, syncope, and sudden cardiac death, usually in childhood or early adulthood. Although there are no characteristic abnormalities in the ECG pattern, a significant number of affected individuals have sinus bradycardia that is not otherwise explainable. Almost half of these individuals carry a diagnosis of epilepsy as the cause of their recurrent syncope
 before the true cause (i.e., catecholaminergic polymorphic ventricular tachycardia) is identified. β­Blockers are the mainstay of prophylaxis, with
 implantable cardioverter­defibrillator placement as the next step if syncope recurs.
PREVENTION OF SUDDEN CARDIAC DEATH
Unfortunately, the majority of sudden cardiac death victims cannot be identified in advance. Prodromal symptoms in the days to weeks preceding
 cardiac arrest are common but are usually too nonspecific to be of important predictive value. The most common premonitory symptoms reported by sudden cardiac death survivors or family members of victims are chest discomfort, dyspnea, and “not feeling well.”
Various tests have been used to try to “risk stratify” potential sudden cardiac death patients, but none are sensitive or specific enough to be useful.
Tests include invasive and noninvasive assessment of left ventricular ejection fraction, coronary angiography, ambulatory ECG monitoring, exercise testing, detection of ventricular late potentials by using signal averaging, programmed ventricular stimulation of the heart to test the inducibility of ventricular tachyarrhythmias, assessment of heart rate variability, and T­wave alternans (alternating T­wave amplitude from beat to beat on the ECG,
 which is visible only with special recording equipment). The best opportunity for prevention is to recognize signs and symptoms of the syndromes that place a patient at higher risk of sudden cardiac death and to admit or refer such patients for proper evaluation and prophylaxis.
ANTIARRHYTHMIC DRUG AND DEVICE THERAPY
The Cardiac Arrhythmia Suppression Trial showed that potent class I sodium channel–blocking antiarrhythmic drugs (encainide, flecainide, and moricizine) are proarrhythmic and paradoxically increase the odds of developing sudden cardiac death, as compared with placebo, in patients at
 relatively low risk for death. The American College of Cardiology/American Heart Association Task Force on Clinical Practice Guidelines and the Heart
Rhythm Society have developed an up­to­date comprehensive guide to the management of patients with ventricular arrhythmias and the prevention of
 sudden cardiac death. In general, the benefits of antiarrhythmic medications such as β­blockers, sotalol, and amiodarone in decreasing mortality
 from sudden cardiac death pale in comparison with the protective effects of the implantable cardioverter­defibrillator in high­risk patients, including
 those who have been resuscitated from ventricular fibrillation or cardioverted out of sustained ventricular tachycardia. Although these devices are expensive to insert, their effectiveness over conventional therapy results in a cost of less than $30,000 per year of life saved, which makes them relatively cost­effective for implantation in high­risk individuals. The Centers for Medicare and Medicaid Services is reevaluation whether to broaden its indications for implantable cardioverter­defibrillator insertion due to the efficacy and effectiveness of these devices for secondary and primary sudden cardiac death prevention in many patient populations, including patients ≥65 years. 
SUDDEN CARDIAC DEATH RESCUE
The outcome of resuscitation is influenced strongly by the patient’s initial cardiac rhythm. In most cases in which the event has been captured during monitoring, the initiating event is either pulseless ventricular tachycardia that degenerates rapidly to ventricular fibrillation or “primary” ventricular
 fibrillation.
EMS and in­hospital resuscitation systems are the most effective means currently known to rescue patients from sudden cardiac death. Survival from pulseless ventricular tachycardia or ventricular fibrillation is inversely related to the time interval between its onset and termination. Survival is optimal when both CPR and advanced cardiac life support, including defibrillation and drug therapy, are provided early. Community resuscitation strategies should include provision of early CPR, early activation of the EMS system, early defibrillation (including public access defibrillation), early advanced
,42 cardiac life support, and regionalized systems of postresuscitation care. The Public Access Defibrillation randomized clinical trial showed that laypersons trained and equipped to use automated external defibrillators in public places can double survival to hospital discharge compared with
 layperson rescuers who can only perform CPR while awaiting EMS arrival. These results have been confirmed in an analysis of ,769 out­of­hospital
 cardiac arrest registry cases.
PULSELESS VENTRICULAR TACHYCARDIA/VENTRICULAR FIBRILLATION
The likelihood of survival is relatively high if the initial rhythm is ventricular tachycardia or ventricular fibrillation (particularly if the ventricular fibrillation is “coarse,” the arrest is witnessed, and prompt CPR and defibrillation are provided). If the initial rhythm is not ventricular tachycardia or ventricular fibrillation, survival is typically <5% in most reported series. Asystolic patients whose cardiac arrest is unwitnessed rarely survive to hospital discharge neurologically intact. The only common exceptions are witnessed cardiac arrest patients whose initial asystole is a result of increased vagal tone or other relatively easily correctible factors, such as hypoxia of brief duration.
PULSELESS ELECTRICAL ACTIVITY
Some sudden cardiac death events begin with a bradyarrhythmia or an organized rhythm without a pulse (e.g., pulseless electrical activity).
Bradyasystole in adults is defined as a ventricular rate <60 beats/min or periods of absent heart rhythm (asystole). Bradyasystolic rhythms other than asystole can be accompanied by a pulse, or there can be no discernible pulse with each QRS (i.e., pulseless electrical activity). Bradyasystole with a pulse is often accompanied by a significant decrease in cardiac output, leading to hypotension and/or syncope. Bradycardia with or without a pulse occurs frequently during cardiac arrest, either as the initial rhythm, during the course of resuscitation, or after electrical defibrillation. Obviously, asystole occurs eventually in all dying patients. To ensure that ventricular fibrillation is not masquerading as asystole, rescuers can switch to another lead whenever a “flat line” is recorded on the ECG during resuscitation or use US if available.
Primary bradyasystole occurs when the heart’s electrical system fails to generate and/or propagate an adequate number of ventricular depolarizations per minute to sustain consciousness and other vital functions. Secondary bradyasystole is present when factors external to the heart’s electrical system cause it to fail (e.g., hypoxia). Common causes of bradyasystolic arrest are listed in Table 11­3. TABLE 11­3
Common Causes of Bradyasystolic Arrest
Myocardial ischemia or infarction
Sick sinus syndrome
Asphyxiation (including near­drowning)
Hypoxia
Hypercarbia
Stroke
Opiates, β­blockers, calcium channel blockers, adenosine, or parasympathetics
One of the most baffling mysteries of bradyasystolic cardiac arrest relates to myocardial mechanics. Bradyasystole, unlike ventricular fibrillation, is accompanied by very little myocardial oxygen consumption in animal models. Because of this, myocardial high­energy phosphate stores should decay relatively slowly during bradyasystole. This should theoretically result in a high incidence of return of spontaneous circulation after restoration of a more normal rhythm (e.g., with the early use of electrical pacing). It is unclear why conventional treatment of bradyasystolic cardiac arrest with atropine, epinephrine, or electrical pacemakers rarely results in survival to hospital discharge. Return of spontaneous circulation is infrequent, and long­term neurologically intact survival is rare in bradyasystolic cardiac arrest.
Other factors must play a determining role in the pathophysiology and subsequent outcome of bradyasystolic cardiac arrest. Bradyasystolic arrest is not just a disorder of rhythm generation or propagation; it is a perplexing syndrome characterized by such rhythm disturbances accompanied, in many cases, by profound depression of myocardial and vascular function. Suspected causes include endogenous myocardial depressants (including downregulation of catecholamine receptors and/or toxic influences of intense sympathetic stimulation), neurogenic influences, postischemic myocardial stunning, and/or free radical injury.
It is important to differentiate pulseless electrical activity from conditions in which the rescuer is unable to detect a pulse, but there is unmistakable evidence that there is adequate blood pressure and cardiac output to maintain vital organ perfusion (e.g., a conscious patient with profound
 vasoconstriction caused by hypothermia, or “pseudo pulseless electrical activity”).
The underlying physiologic cause of pulseless electrical activity is a marked reduction in cardiac output due to either profound myocardial depression or mechanical factors that reduce venous return or impede the flow of blood through the cardiovascular system. Common conditions that can cause pulseless electrical activity are shown in Table 11­4. The management of patients with pulseless electrical activity is directed at identifying and treating the underlying cause or causes.
TABLE 11­4
Conditions That Cause Pulseless Electrical Activity
Hypovolemia
Tension pneumothorax
Pericardial tamponade
Pulmonary embolism
Massive myocardial dysfunction due to ischemia or infarction, myocarditis, cardiotoxins, etc.
Drug toxicity (e.g., β­blockers, calcium channel blockers, tricyclic antidepressants)
Profound shock
Hypoxia
Acidosis
Severe hypercarbia
Auto positive end­expiratory pressure
Hypothermia
Hyperkalemia
Pseudo pulseless electrical activity


