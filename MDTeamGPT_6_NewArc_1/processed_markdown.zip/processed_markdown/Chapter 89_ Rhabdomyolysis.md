## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 89: Rhabdomyolysis
Francis L. Counselman
INTRODUCTION AND EPIDEMIOLOGY
Rhabdomyolysis is the destruction of skeletal muscle caused by any mechanism that results in injury to myocytes and their membranes. Acute necrosis of skeletal muscle fibers and the leakage of cellular contents into the circulation result in myoglobinuria.
Table 89­1 lists commonly recognized conditions associated with rhabdomyolysis. In general, the most common causes of rhabdomyolysis in adults are drugs of abuse and alcohol, followed by medications, muscle diseases, trauma, neuroleptic malignant syndrome,
,2 seizures, immobility, infection, strenuous physical activity, and heat­related illness. Multiple causes are present in more than half of
 ,4 patients. In children, rhabdomyolysis is less common and is more benign. In a large study of children, the most common causes of nonrecurrent
 rhabdomyolysis were viral myositis, trauma, and connective tissue disease. For adults and children, inherited metabolic disorders should be suspected with recurrent episodes of rhabdomyolysis, especially if associated with exercise intolerance.
TABLE 89­1
Common Conditions Associated With Rhabdomyolysis in Adults
Trauma Immunologic diseases involving Medications muscle
Crush injury Dermatomyositis Antipsychotics
Electrical or lightning injury Polymyositis Barbiturates
Drugs of abuse Bacterial infection Benzodiazepines
Amphetamines [including ecstasy (3,4­ Clostridium Chemotherapeutic agents methylenedioxymethamphetamine)]
Group A β­hemolytic streptococci Clofibrate
Caffeine Klebsiella Colchicine
Cocaine Legionella Corticosteroids
Ethanol Mycoplasma Diphenhydramine
Heroin Salmonella Hypnotics and sedatives
Lysergic acid diethylamide Shigella Isoniazid
Methadone Staphylococcus aureus Lithium
Methamphetamines Streptococcus pneumoniae Monoamine oxidase inhibitors

Opiates Viral infection Narcotics
Chapter 89: Rhabdomyolysis, Francis L. Counselman 
. Terms of Use * Privacy Policy * Notice * Accessibility
Phencyclidine Coxsackievirus Neuroleptic agents
Environment and excessive muscular activity Cytomegalovirus Phenothiazines
Contact sports Epstein­Barr virus Propofol
Delirium tremens Enterovirus Salicylates
Dystonia Hepatitis virus Selective serotonin reuptake inhibitors
Excessive exercise (e.g., CrossFit, spinning) Herpes simplex virus Statins
Immobilization Human immunodeficiency virus Theophylline
Psychosis Influenza virus (A and B) Tricyclic antidepressants
Seizures Rotavirus Zidovudine
Marathons, military basic training Ischemic injury
Heatstroke Compartment syndrome
Genetic disorders Compression
Glycolysis and glycogenolysis disorders
Fatty acid oxidation disorders
Mitochondrial and respiratory chain metabolism disorders
Patients in coma are at risk for rhabdomyolysis from unrelieved pressure on gravity­dependent body parts. Alcohol consumption can result in rhabdomyolysis secondary to coma­induced muscle compression and a direct toxic effect. Drugs of abuse and alcohol should be suspected as a primary or contributing cause of rhabdomyolysis in adults. Statin­related myopathies include myalgias with or without elevation of creatine kinase level, muscle weakness, and rhabdomyolysis. Statin­related rhabdomyolysis varies with the particular statin and is dose related. Polypharmacy, including combinations with cyclosporine, macrolide antibiotics, warfarin, digoxin, and dual statin therapy, carries an increased risk for
,5 rhabdomyolysis.
,6
A number of bacterial and viral infections including human immunodeficiency virus have been associated with rhabdomyolysis. Strenuous physical activity, as seen in athletes, marathon runners, military recruits, and outdoor laborers, is a common cause of rhabdomyolysis but is less likely than
 other etiologies to provoke acute kidney injury. Physical activity that produces high­force eccentric contractions (resistance), such as strength training or heavy lifting, leads to greater breakdown in muscle and higher levels of creatine kinase than concentric contractions, such as endurance­based

(aerobic) exercises. Factors that increase the risk in this group of patients include poor physical conditioning, male sex, inadequate fluid intake,
 wearing of restrictive clothing, high ambient temperatures, and high humidity levels.
PATHOPHYSIOLOGY
Rhabdomyolysis is a syndrome characterized by injury to skeletal muscle with subsequent effects from the release of intracellular contents. These contents include myoglobin, creatine kinase, aspartate aminotransferase, and potassium. Although numerous causes of rhabdomyolysis have been
+ + described, the common terminal event appears to involve the disruption of the Na K ATPase pump and calcium transport, which results in increased intracellular calcium and subsequent muscle cell necrosis. In addition, calcium activates phospholipase A and various vasoactive molecules and

,8 proteases and induces the production of free oxygen radicals.
CLINICAL FEATURES
The presenting symptoms of rhabdomyolysis are usually acute in onset and include myalgias, weakness, malaise, low­grade fever, and dark (usually
,4 brown) urine. Muscle symptoms, however, may be present in only half of cases. Nausea, vomiting, abdominal pain, and tachycardia can occur in severe rhabdomyolysis. Mental status changes may develop from urea­induced encephalopathy. Swelling and tenderness of the involved muscle groups and hemorrhagic discoloration of overlying skin may be observed but are not common. Muscle involvement may be localized or diffuse, depending on the cause. Commonly, the postural muscles of the thighs, calves, and lower back are involved. Muscle swelling may not become apparent until after rehydration with IV fluids. Acute rhabdomyolysis may be present without any signs or symptoms, with a normal physical examination.
DIAGNOSIS
An elevated serum creatine kinase is the most sensitive and reliable indicator of muscle injury. The degree of elevation correlates with the amount of muscle injury and the severity of symptoms, but not the development of acute kidney injury or other morbidity. Most authors consider a fivefold or greater increase above the upper threshold of normal in serum creatine kinase level, in the absence of cardiac or brain injury, as
 the requirement for the diagnosis of rhabdomyolysis (approximately 800 to 1000 IU/L). In general, the level begins to rise approximately  to 
 hours after the onset of muscle injury, peaks within  to  hours, and then declines at the relatively constant rate of 39% of the previous day’s value.
Ongoing muscle necrosis should be suspected in patients with elevated values that fail to decrease in this manner. The MB fraction of creatine kinase
(found primarily in cardiac but also in skeletal muscle) also may be elevated but should not exceed 5% of the total creatine kinase.

Myoglobinuria develops once skeletal muscle injury is >100 grams. Myoglobin elevation occurs before creatine kinase elevation, and then is rapidly cleared from the plasma through renal excretion and metabolism to bilirubin. Myoglobin causes the typical reddish brown discoloration when the
,9 urine myoglobin level is >100 milligrams/dL. Because myoglobin contains heme, qualitative tests such as the dipstick test do not differentiate among hemoglobin, myoglobin, and red blood cells. Therefore, suspect myoglobinuria when the urine dipstick test is positive for blood but zero or rare red blood cells are present on microscopic examination. Because myoglobin levels may return to baseline quickly, the absence of an elevated serum myoglobin level or of myoglobinuria does not exclude the diagnosis. In a study of 475 patients with rhabdomyolysis, only

19% were found to have myoglobinuria.
Urinalysis is essential. Other laboratory studies may be useful to identify the common complications of rhabdomyolysis and the underlying cause.
Obtain serum electrolyte, calcium, phosphorus, and uric acid levels to identify hyperkalemia, abnormal calcium and phosphorus levels, and hyperuricemia. Obtain an ECG if hyperkalemia is suspected clinically or confirmed with testing. Serum creatinine and BUN levels are needed to identify acute kidney injury. Because disseminated intravascular coagulation is a potential complication, obtain a baseline CBC and consider a coagulopathic screen (e.g., prothrombin time, partial thromboplastin time, fibrin split products, and fibrinogen level [see Chapter 233, “Acquired Bleeding
Disorders”]). Other common laboratory findings in rhabdomyolysis include elevated levels of lactate dehydrogenase, urea, creatine, and
 aminotransferases. In addition, a falsely elevated cardiac troponin I (TnI) is common, especially in elderly patients. Further laboratory testing to identify the underlying cause(s) of rhabdomyolysis should be based on the medical history and clinical presentation. Imaging plays a secondary role in
 the diagnosis, after clinical and laboratory studies. US and CT provide only nonspecific findings, unless being used to rule out vascular (or boney) injury that could have provoked rhabdomyolysis. MRI is the imaging modality of choice for evaluating focal muscle damage but is rarely needed for
 managment. See discussion below and Chapter 278, “Compartment Syndromes,” for diagnostic criteria of associated compartment syndrome.
DIFFERENTIAL DIAGNOSIS
Other causes of muscle pain and weakness besides rhabdomyolysis should be considered in the appropriate clinical setting. Such causes include acute myopathies, periodic paralysis, polymyositis or dermatomyositis, or Guillain­Barré syndrome. Rhabdomyolysis associated with strenuous
 exercise or fasting or repeat episodes of rhabdomyolysis suggest an inherited metabolic myopathy.
TREATMENT
PREHOSPITAL CARE
For victims of crush injury, patients strongly suspected of having rhabdomyolysis, or accident victims with prolonged extrication and transport times,
,13 early and vigorous IV fluid resuscitation is the most important treatment to prevent acute kidney injury. Once a limb is extricated, IV normal saline should be initiated at  L/h. After extrication, IV normal saline should be continued at 500 mL, alternating with 5% dextrose in normal saline at  L/h.
Because rhabdomyolysis may be associated with hyperkalemia and lactic acidosis, avoid potassium­ or lactate­containing solutions until electrolyte and acid­base status is known.
EMERGENCY DEPARTMENT CARE
Once the patient is in the ED, continue aggressive IV rehydration for the next  to  hours. One method is rapid correction of the fluid
,14 deficit with IV crystalloids followed by infusion of  mL/kg/h, with the goal of maintaining a minimum urine output of  to  mL/kg/h. Another
 method is a goal of 200 to 300 mL of urine output each hour.
No prospective controlled studies have identified ideal fluid choice or demonstrated benefit from alkalinization of the urine with
13­17 sodium bicarbonate or forced diuresis with mannitol or loop diuretics. However, one recent 10­year retrospective study found that the use of mannitol and bicarbonate in patients with a creatine kinase greater than ,000 IU/L decreased the development of acute renal dysfunction

(creatinine >2 milligrams/dL [152.50 µmol/L]). If bicarbonate is given, maintain an isotonic solution and avoid metabolic alkalosis or hypokalemia.
Mannitol may be harmful because it may cause osmotic diuresis in hypovolemic patients. In nontraumatic rhabdomyolysis, lactated Ringer’s solution
 was compared to normal saline in a cohort of  patients. The rate of reduction of creatine kinase and the prevalence of acute kidney injury was not different between groups; none of the  patients receiving lactated Ringer’s developed metabolic acidosis (mean serum pH .44), whereas many of
 the patients receiving normal saline developed acidosis (mean serum pH .25).
Place a urinary catheter in patients in critical condition and those with acute kidney injury to monitor urine output. Institute cardiac monitoring because electrolyte and metabolic complications can cause dysrhythmias. For patients with heart disease, comorbid conditions, or preexisting renal disease or for elderly patients, hemodynamic monitoring may be necessary to avoid fluid overload.
Hypocalcemia observed early in rhabdomyolysis usually requires no treatment. Calcium should be given only to treat hyperkalemia­induced
 cardiotoxicity or profound signs and symptoms of hypocalcemia. If hypercalcemia is symptomatic, continue saline diuresis. Hyperkalemia, which is usually most severe in the first  to  hours after muscle injury, can be significant and prolonged. Traditional insulin and glucose therapy, although recommended, may not be as effective in rhabdomyolysis­induced hyperkalemia. The use of ion­exchange resins (e.g., sodium polystyrene sulfonate) may be effective. Treat hyperphosphatemia with oral phosphate binders when serum levels are >7 milligrams/dL (2.25 µmol/L). See Chapter , “Fluids and Electrolytes,” for further discussion. Ultimately, dialysis may be needed; see Chapter , “Acute Kidney Injury,” for indications. Avoid prostaglandin inhibitors such as NSAIDs because of their vasoconstrictive effects on the kidney. Finally, treat the underlying cause of the rhabdomyolysis, which may require consultation.
DISEASE COMPLICATIONS
The complications of rhabdomyolysis include acute kidney injury, acid­base derangements (both acidosis and alkalosis) electrolyte disturbances
(potassium, calcium, phosphorus), disseminated intravascular coagulation, and mechanical complications (e.g., compartment syndrome or peripheral
 neuropathy). Factors that contribute to rhabdomyolysis­induced acute kidney injury include hypovolemia, acidosis or aciduria, tubular obstruction,
,15 and the nephrotoxic effects of myoglobin. Renal tubular obstruction occurs secondary to precipitation of uric acid and myoglobin. Over all, neither the presence of myoglobinuria nor the degree of creatine kinase elevation is predictive of acute kidney injury; however, the correlation of creatine
 kinase elevation and acute kidney injury is stronger in traumatic rhabdomyolysis. A risk prediction score for mortality or need for dialysis in patients
  with rhabdomyolysis was initially derived and validated in 2013 and was recently externally validated in 2016 (Table 89­2).
TABLE 89­2
McMahon Score to Predict Death or Dialysis
Laboratory Parameters at Time of Admission International Units (IU) Traditional Units Points
Creatinine 124–194 µmol/L .4–2.2 milligrams/dL .5
>194 µmol/L >2.2 milligrams/dL .5
Calcium <1.875 mmol/L <7.5 milligrams/dL 
Creatine kinase >40,000 IU/L >40,000 IU/L 
Phosphate .3–1.174 mmol/L .0–5.4 milligrams/dL .5
>1.74 mmol/L >5.4 milligrams/dL 
Bicarbonate <19 mmol/L <19 mEq/L 
Historical Variables Value Points
Etiology of rhabdomyolysis NOT seizures, syncope, exercise, statins, or myositis 
Sex Female 
Age 50–70 y .5
71–80 y .5
>80 y 
Note. A score of  or less indicates a 3% risk of either renal replacement therapy or death. A score of at least  indicates a 52% risk of renal replacement therapy or death.
The authors suggest that the score can be used to determine the need for aggressive resuscitation when faced with a patient who is at risk for the complications of resuscitation (e.g., a patient with heart failure).
The mechanical complications of rhabdomyolysis consist of compartment syndrome and peripheral nerve injury. The associated muscle swelling may exert pressure on peripheral nerves, resulting in neuronal ischemia and causing paresthesias or paralysis. Nerve injury is often proximal, and multiple
 nerves may be involved in the same extremity. Compartment syndrome occurs secondary to marked swelling and edema of the involved muscle groups and is discussed in Chapter 278. DISPOSITION AND FOLLOW­UP
The majority of healthy patients with exertional rhabdomyolysis and without comorbidities (e.g., heat stress, dehydration, trauma) can usually be
 treated with PO or IV rehydration, observed in the ED, and then released. Otherwise, patients should be admitted for IV hydration, management of complications of rhabdomyolysis, and treatment of the underlying cause. For at least the initial  to  hours, admission should be to a monitored bed to identify dysrhythmias as well as worsening renal function. The nephrology service should be consulted to evaluate the need for dialysis for patients with hyperkalemia unresponsive to therapy or for patients with a high McMahon risk score.


