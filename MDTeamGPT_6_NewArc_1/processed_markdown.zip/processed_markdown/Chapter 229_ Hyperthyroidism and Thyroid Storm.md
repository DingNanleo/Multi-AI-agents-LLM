## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 229: Hyperthyroidism and Thyroid Storm
Alzamani Mohammad Idrose
INTRODUCTION AND EPIDEMIOLOGY
Thyroid hormone affects virtually all organ systems and is responsible for increasing metabolic rate, heart rate, and ventricle contractility, as well as muscle and CNS excitability. The thyroid hormones are thyroxine (T ) and triiodothyronine (T ). The ratio of T to T released in the blood is 10:1.    
Peripherally, T is converted to the active T , which is three to four times more potent than T .

Hyperthyroidism is an excessive amount of thyroid hormones in the body. The terms hyperthyroidism and thyrotoxicosis are often used interchangeably. Hyperthyroidism is a clinical syndrome with a variety of signs and symptoms, and thyroid storm is its extreme manifestation.
Thyroid storm is an acute, severe, life­threatening hypermetabolic state caused either by excessive release of thyroid hormones causing adrenergic hyperactivity or an increased peripheral response to thyroid hormone in response to one or more precipitants. The most common underlying cause is
Graves’ disease (85% of all hyperthyroidism cases in the United States). It is caused by thyroid­stimulating hormone (TSH) receptor antibodies that stimulate excess and uncontrolled thyroidal synthesis and secretion of thyroid hormones. It occurs most frequently in young women (10 times more
 ,2 common in women compared with men) at any age group. The mortality of thyroid storm is in the range of 8% to 25%. This chapter will focus primarily on the treatment of thyroid storm.
HYPERTHYROIDISM
Primary hyperthyroidism is caused by the excess production of thyroid hormones from the thyroid glands or from external factors. Secondary hyperthyroidism is caused by the excess production of thyroid­releasing hormones or TSH in the hypothalamus and pituitary, respectively (Tables
229­1 and 229­2).
TABLE 229­1
Common Causes of Primary and Secondary Hyperthyroidism
Primary Hyperthyroidism
Graves’ disease (toxic diffuse goiter) Most common of all hyperthyroidism (85% of all cases)
Associated with diffuse goiter, ophthalmopathy, and local dermopathy
Toxic multinodular goiter Second most common cause of hyperthyroidism
Toxic nodular (adenoma) goiter An enlarged thyroid gland that contains a small rounded mass or nodules with overproduction of thyroid hormone
Thyroiditis Inflammation of the thyroid gland
Hashimoto’s thyroiditis Initially gland is overactive (hyperthyroidism) but is typically followed by a state of hypothyroidism
Secondary Hyperthyroidism
Thyrotropin­secreting pituitary Thyroid gland stimulated to produce hormones

Chapteard e2n2o9m: aHyperthyroidism and Thyroid Storm, Alzamani Mohammad Idrose 
. Terms of Use * Privacy Policy * Notice * Accessibility
TABLE 229­2
External Causes of Hyperthyroidism
Nonthyroidal Disease
Ectopic thyroid tissue A rare form of mature teratoma that contains thyroid tissue
(struma ovarii)/teratoma
Metastatic thyroid Production of extraglandular thyroid hormones cancer
Human chorionic Stimulates thyroid hormone secretion gonadotropin
Drug Induced or Iodine Intake
Iodine Iodine­induced thyrotoxicosis (called Jod­Basedow phenomenon): After treatment of endemic goiter patients with iodine or stimulation of thyroid hormones from use of iodine­containing agents such as radiographic contrast agents
Amiodarone Contains iodine; may cause either thyrotoxicosis or hypothyroidism
Interferon­α, interleukin­ During treatment for other diseases, such as viral hepatitis and human immunodeficiency virus infection

Thyrotoxicosis factitia Accidental or Munchausen­like, whereby thyroid hormone is taken by patient to fake illness
Ingestion of meat Cow thyroid tissue contains thyroid hormones containing beef thyroid tissue
Excessive thyroid hormone ingestion
CLINICAL FEATURES
The clinical features of hyperthyroidism are varied. The patient may only complain of constitutional symptoms such as generalized weakness and fatigue. Heat intolerance, diaphoresis, fever, voracious appetite but poor weight gain, anxiety, emotional lability, palpitations, diarrhea, and hair loss are common historical features. If there is a history of hyperthyroidism, ask about treatment and compliance with medication. The signs and symptoms of hyperthyroidism are as shown in Table 229­3. The severity of exophthalmos is not necessarily parallel with the magnitude of thyroid dysfunction but reflects the autoimmune process taking place. Not all hyperthyroidism patients present with goiter. A goiter is not present with exogenous administration of thyroid hormone and apathetic thyrotoxicosis. Likewise, the presence of a goiter does not necessarily confirm the diagnosis of thyrotoxicosis. Thyroid gland tenderness can be found in inflammatory conditions such as subacute thyroiditis.
TABLE 229­3
Symptoms and Signs of Hyperthyroidism
Affected System Symptoms Signs
Constitutional Lethargy Diaphoresis
Weakness Fever
Heat intolerance Weight loss
Neuropsychiatric Emotional lability Fine tremor
Anxiety Muscle wasting
Confusion Hyperreflexia
Coma Periodic paralysis
Psychosis
Ophthalmologic Diplopia Lid lag
Eye irritation Dry eyes
Exophthalmos
Ophthalmoplegia
Conjunctival infection
Endocrine: thyroid gland Neck fullness Thyroid enlargement
Tenderness Bruit
Cardiorespiratory Dyspnea Widened pulse pressure
Palpitations Systolic hypertension
Chest pain Sinus tachycardia
Atrial fibrillation or flutter
High­output heart failure
GI Diarrhea Hyperactive bowel sounds
Yellowish sclera Jaundice
Reproductive Oligomenorrhea Gynecomastia
Decreased libido Telangiectasia
Gynecologic Menorrhagia Sparse pubic hair
Irregularity
Hematologic Pale skin Anemia
Leukocytosis
Dermatologic Hair loss Pretibial myxedema* Warm, moist skin
Palmar erythema
Onycholysis
*Pretibial myxedema may be present in 5% of patients with Graves’ disease.
LABORATORY TESTING
Obtain a CBC, electrolytes, glucose, serum cortisol, renal and liver function tests, ECG, and chest radiograph. Obtain a pregnancy test in women of child­bearing age. Other general studies depend on clinical evaluation, comorbidities, and the differential diagnosis.
Serum TSH Level
In primary hyperthyroidism, the TSH level is low as a result of the negative feedback mechanism toward a high thyroid hormone level. Nevertheless, a low TSH level by itself is not diagnostic, as serum TSH may be reduced as a result of chronic liver or renal disease or the effect of certain drugs such as glucocorticoids, which reduce TSH secretion.
In secondary hyperthyroidism, TSH is increased because of increased production in the pituitary.
Free Thyroid Hormone Levels: Free T and Free T

A low TSH with an elevated free T confirms primary hyperthyroidism. A high TSH with high free T denotes secondary causes of hyperthyroidism. On
  the other hand, a low TSH with a normal free T but elevated free T is diagnostic of T thyrotoxicosis. T thyrotoxicosis occurs in <5% of patients who
    have thyrotoxicosis in North America. Thyroid hormone levels are not necessarily acutely elevated when the transition from uncomplicated thyrotoxicosis to thyroid storm occurs.
Total Thyroid Hormone Level of T and T

Total serum T and T (bound and unbound) are increased in thyrotoxicosis. Eighty percent of circulating T is derived from monodeiodination of T in
    peripheral tissues, whereas 20% emanates from direct thyroidal secretion. Both T and T are then bound to proteins in the form of thyroxine­binding
  globulin, transthyretin, and albumin. Only a small fraction of the hormones are free and unbound. Laboratory measurement of total T and total T
  measures mainly protein­bound hormone concentrations. In thyroid storm, total thyroid hormone level may or may not be increased. Results also may be affected by conditions that affect protein binding. With the improved assays for free T and free T , there is now little indication to measure total T
   and total T .

Thyroid Antibody Titers
Thyroid­stimulating antibodies are detected in Graves’ disease. Thyroid antibody titers (to thyroid peroxidase or thyroglobulin) will help determine diagnosis.
TREATMENT AND DISPOSITION OF UNCOMPLICATED HYPERTHYROIDISM
Further evaluation, treatment, and disposition of patients with uncomplicated hyperthyroidism depend on the patient’s age, comorbidities, disease severity, and identification of the underlying cause.
A thyroid sonogram with Doppler flow can be done to assess thyroid gland size, vascularity, and the presence of nodules. Typically, a thyroid gland secreting excessive hormones would be enlarged. However, in the setting of subacute postpartum thyroiditis, silent thyroiditis, or exogenous causes of hyperthyroidism, the thyroid gland is not expected to be enlarged. Nuclear medicine imaging with iodine­131 would reveal a greatly increased uptake of radioiodine as early as  or  hours after administration of the agent.
Ambulatory evaluation is usually appropriate for most patients. Consult with an endocrinologist or the patient’s primary care physician about the next diagnostic and therapeutic steps.
For patients with features suggesting impending thyroid storm, see discussion below on thyroid storm.
THYROID STORM
Thyroid storm is a clinical diagnosis for patients with preexisting hyperthyroidism. Do not rely on lab results for diagnosis or to start treatment. In determining whether or not a patient has thyroid storm, the main systems to concentrate on are the thermoregulatory system (rise in temperature), cardiovascular system (ranging from tachycardia to atrial fibrillation and congestive cardiac failure), CNS (ranging from being agitated to seizure), and the GI­hepatic system (ranging from nausea to vomiting and jaundice) (Figure 229­1). Search for a precipitating event (Table 229­4).
TABLE 229­4
Precipitants of Thyroid Storm
Systemic insult Cardiovascular insult
Infection Myocardial infarction
Trauma Cerebrovascular accidents
General surgery Pulmonary embolism
Endocrinal insult Obstetrics related
Diabetic ketoacidosis Labor and delivery
Hyperosmolar coma Eclampsia
Drug or hormone related Radioactive iodine therapy
Withdrawal of antithyroid medication
Iodine administration
Thyroid gland palpation
Ingestion of thyroid hormone
Unknown cause in up to 25% of cases
FIGURE 229­1. Clinical features of thyroid storm.
PATHOPHYSIOLOGY
The pathophysiologic mechanisms underlying the shift from uncomplicated hyperthyroidism to thyroid storm are not entirely clear. However, they involve adrenergic hyperactivity either by increased release of thyroid hormones or increased receptor sensitivity. Many of the signs and symptoms are related to adrenergic hyperactivity. Patients with thyroid storm have relatively higher levels of free thyroid hormones as opposed to those with uncomplicated hyperthyroidism. The total thyroid hormone level may or may not be increased in those with uncomplicated hyperthyroidism.
When there is excess of thyroid hormones, circulating T and T are taken into the cytoplasm of cells. T is converted to its active form, T . Within the
    cytoplasm, the T then exerts its effect by passing into the nucleus and binding to thyroid hormone receptors or thyroid hormone–responsive

,4 elements to induce gene activation and transcription. The receptors receiving the hormone will stimulate changes specific to the tissue.
In the pituitary gland, thyroid hormones exert negative regulation, resulting in TSH suppression.
During thyroid storm, precipitants such as infection, stress, myocardial infarction, or trauma will multiply the effect of thyroid hormones by freeing thyroid hormones from their binding sites or increasing receptor sensitivity.
PRECIPITANTS OF THYROID STORM
The precipitants of thyroid storm are as shown in Table 229­4. In some patients undergoing radioactive iodine therapy for hyperthyroidism, thyroid storm may ironically occur following treatment due to withdrawal of antithyroid drugs, release of thyroid hormones from damaged thyroid follicles, or the effect of radioactive iodine itself.
CLINICAL FEATURES OF THYROID STORM
The additional signs and symptoms of thyroid storm, apart from those evident in hyperthyroidism, are as shown in Figure 229­1. Fever is often present in thyroid storm. It may herald the onset of thyrotoxic crisis in previously uncomplicated disease. Palpitations, tachycardia, and dyspnea are common.
A pleuropericardial rub may be heard. The direct inotropic and chronotropic effects of thyroid hormone on the heart cause increased stroke volume, contractility, and cardiac output. Enhanced contractility produces elevations in systolic blood pressure. Thyroid storm may also cause widened pulse
 pressure due to high cardiac output and reduced peripheral vascular resistance. Atrial fibrillation occurs in 10% to 35%.
Table 229­5 provides the Burch and Wartofsky Point Scale (BWPS) for thyroid storm diagnosis. The system is practical because it is based on clinical and physical criteria and it is sensitive for thyroid storm, but it is not very specific.
TABLE 229­5
Burch and Wartofsky Diagnostic Parameters and Scoring Points for Thyroid Storm
Diagnostic Parameters Scoring Points
. Thermoregulatory dysfunction
Temperature °C (°F)
.2–37.7 (99–99.9) 
.7–38.3 (100–100.9) 
.3–38.8 (101–101.9) 
.9–39.4 (102–102.9) 
.4–39.9 (103–103.9) 
≥40 (≥104.0) 
. CNS effects
Absent 
Mild (agitation) 
Moderate (delirium, psychosis, extreme lethargy) 
Severe (seizures, coma) 
. GI­hepatic dysfunction
Absent 
Moderate (diarrhea, nausea/vomiting, abdominal pain) 
Severe (unexplained jaundice) 
. Cardiovascular dysfunction
Tachycardia (beats/min)
90–109 
110–119 
120–129 
≥140 
. Congestive heart failure
Absent 
Mild (pedal edema) 
Moderate (bibasilar rales) 
Severe (pulmonary edema) 
. Atrial fibrillation
Absent 
Present 
. Precipitating event* Absent 
Present 
*See Table 229­3. Scoring system: Score of ≥45: highly suggestive of thyroid storm. Score of 25–44: suggestive of impending storm. Score of <25: unlikely to represent thyroid storm.
Source: Reproduced with permission from Burch HB, Wartofsky L. Life­threatening thyrotoxicosis. Thyroid storm. Endocrinol Metab Clin North Am 22: 263, 1993.3,5

Apart from this scoring system, in 2012, Akamizu et al formulated diagnostic criteria for thyroid storm and clarified its clinical features, prognosis, and incidence based on nationwide surveys in Japan. After this, the Japanese Thyroid Association proposed diagnostic criteria of TS1 and TS2 for thyroid storm, taking into account laboratory evidence of increased free thyroid hormones with any CNS symptoms and non­CNS symptoms such as fever, tachycardia, heart failure presentation, or GI–hepatic derangement manifestations.  Nevertheless, a Burch and Wartofsky Point Scale score ≥45
5­7 appears more sensitive than a Japanese Thyroid Association classification of TS1 or TS2 in detecting patients with a clinical symptoms.
The major differential diagnoses of thyroid storm are shown in Table 229­6. TABLE 229­6
Differential Diagnosis of Thyroid Storm
Infection and sepsis
Sympathomimetic ingestion (e.g., cocaine, amphetamine, ketamine drug use)
Heat exhaustion
Heat stroke
Delirium tremens
Malignant hyperthermia
Malignant neuroleptic syndrome
Hypothalamic stroke
Pheochromocytoma
Medication withdrawal (e.g., cocaine, opioids)
Psychosis
Organophosphate poisoning
LABORATORY TESTING, IMAGING, AND ECG
Obtain a CBC, electrolytes, glucose, and renal and liver function tests to identify comorbidities. Obtain a pregnancy test in women of child­bearing age.
Except for pregnancy testing (see later treatment section, “Inhibition of New Thyroid Hormone Synthesis,” below), start treatment upon suspicion of the diagnosis without waiting for laboratory results. In thyroid storm, CBC typically shows leukocytosis with shift to the left. Hyperglycemia tends to occur because of a catecholamine­induced inhibition of insulin release and increased glycogenolysis and rapid intestinal absorption of glucose. Mild hypercalcemia and elevated alkaline phosphatase can occur because of hemoconcentration and enhanced thyroid hormone–stimulated bone
 resorption.
Thyroid storm also induces liver enzyme metabolism, causing raised liver enzymes, so obtain baseline values. In 30% of patients, treatment with an
 antithyroid drug such as propylthiouracil can cause transient elevation of liver enzymes. A high serum cortisol value is an expected finding. This should be the normal reaction of an adrenal gland to a body under stress. The finding of an abnormally low cortisol level should raise suspicion of coincidental adrenal insufficiency.
Imaging
Chest radiograph should be done to rule out infection as a precipitant for thyroid storm. Bedside echocardiography would typically show tachycardia, enhanced left ventricular contractility, and a dilated inferior vena cava in the presence of high­output cardiac failure. CT of the brain may be necessary to exclude neurologic conditions if diagnosis is uncertain, because CNS abnormalities causing altered mental status may precipitate thyroid storm.
ECG

ECG findings most commonly include sinus tachycardia and atrial fibrillation. Sinus tachycardia occurs in approximately 40% of cases. Atrial
 fibrillation occurs in 10% to 35% of patients and more commonly in patients >60 years old with underlying structural heart disease. Premature ventricular contractions and heart blocks may be present. Atrial premature contractions and atrial flutter may also occur. Institute cardiac monitoring.
TREATMENT OF THYROID STORM
The order of therapy in treating thyroid storm is very important with regard to the use of thionamide and iodine therapy. Obtain pregnancy testing before beginning ED treatment, and obtain consultation for treatment if the patient is pregnant or breastfeeding. If the patient is not pregnant, inhibit thyroid gland synthesis of new thyroid hormone with a thionamide (methimazole and propylthiouracil are thionamide drugs available in the United States) before iodine therapy is begun to prevent the stimulation of new thyroid hormone synthesis that can occur if iodine is given too soon.
Treatment aims are as follows:
Supportive care
Inhibition of peripheral adrenergic effects
Inhibition of new hormone synthesis
Inhibition of thyroid hormone release
Preventing peripheral conversion of T to T

Preventing free thyroid hormone reabsorption
Treating the precipitant
Definitive care
The treatment recommendations are shown in Table 229­7, with specific comments in the following sections.
TABLE 229­7
Treatment for Thyroid Storm
. Supportive care
General: oxygen, cardiac monitoring
Fever: external cooling with ice packs or cooling blankets; acetaminophen 325–650 milligrams PO/PR every 4–6 h (aspirin is contraindicated because it may increase free thyroid hormone)
Dehydration: IV fluids, IV saline with 5% dextrose may be used to replace glycogen depletion if blood sugar is low
Nutrition: glucose, multivitamins, thiamine, and folate can be considered (deficient secondary to hypermetabolism)
. Inhibition of peripheral adrenergic effects
Propranolol .5–1 milligrams IV over  minutes, then 1–2 milligrams every few hours adjusted to vital signs. For the less toxic patient, PO dose of 60–
 milligrams every  h (for reactive airway diseases, cardioselective β­blockers, such as atenolol or metoprolol, or calcium channel blockers can be considered) or
Esmolol 250–500 micrograms/kg IV load, then 50–100 micrograms/kg/min titrated doses to vital signs or
Reserpine .5–5.0 milligrams IM every 4–6 h, preceded by 1­milligram test dose while monitoring blood pressure (may consider if β­blocker is contraindicated but avoid in congestive heart failure or hypotension and cardiac shock) or
Guanethidine 30–40 milligrams PO every  h (may consider if β­blocker is contraindicated but avoid in congestive heart failure, hypotension, and cardiac shock)
. Inhibition of new thyroid hormone synthesis
Methimazole  milligrams every  h PO
(Avoid methimazole in pregnant women. Teratogenic risk is highest in first trimester. Methimazole is Food and Drug Administration pregnancy category
D. Obtain consultation if patient is breastfeeding.) or
PTU, a loading dose of 500–1000 milligrams given PO and followed by 250 milligrams every  h
(PTU is used for pregnant women in first trimester. PTU also has a boxed warning issued by the U.S. Food and Drug Administration in 2010 regarding rare but severe hepatic dysfunction. There are case reports of hepatic failure in mother/fetus.) Obtain consultation if the patient is breastfeeding.
. Inhibition of thyroid hormone release (at least  h after step 3)
Lugol solution 8–10 drops PO every 6–8 h or
Potassium iodide (SSKI) five drops (0.25 mL or 250 milligrams) PO every  h or
IV iopanoic acid (Telepaque®),  gram every  h for first  h, then 500 milligrams twice a day (Food and Drug Administration pregnancy category C) or
Ipodate (Oragrafin®), .5–3 grams/d PO (especially useful with thyroiditis or thyroid hormone overdose) or
Lithium carbonate (if allergic to iodine or agranulocytosis occurs with thionamides), 300 milligrams PO every  h (1200 milligrams/d) and subsequently to maintain serum lithium at  mEq/L
(Lithium is contraindicated for use in pregnant mothers; effects in breastfeeding uncertain, so obtain consultation.)
. Preventing peripheral conversion of T to T

Hydrocortisone 300 milligrams IV initially, then 100 milligrams every  h until stable (also for adrenal replacement due to hypermetabolism) or
Dexamethasone  milligrams IV every  h
. Prevention of free thyroid hormones reabsorption
Cholestyramine  grams every  h
. Treat precipitating event
All triggers of thyroid storm should be searched and treated accordingly (e.g., infection, myocardial infarct, diabetic ketoacidosis)
. Definitive therapy
Radioactive iodine ablation therapy or surgery may be necessary.
Note: Replacement therapy: dialysis and plasmapheresis are last resorts for patients who do not respond to treatments 1–5. Abbreviation: PTU = propylthiouracil.
TREATMENT AIM 1: SUPPORTIVE CARE
Fluid losses could result from the combination of fever, diaphoresis, vomiting, and diarrhea. With high metabolic rate in thyroid storm, check blood glucose, and if blood sugar is relatively low, IV fluids with dextrose (isotonic saline with 5% or 10% dextrose) may be given to replenish glycogen stores.
TREATMENT AIM 2: INHIBITION OF PERIPHERAL ADRENERGIC EFFECTS
Thyroid storm is a hyperadrenergic state with the risk of high­output cardiac failure. Therefore, reducing afterload and heart rate with a β­blocker is essential. Inotropic agents may have to be considered carefully as they may worsen the hyperadrenergic state.
Propranolol can be given IV in slow 1­ to 2­milligram boluses, which may be repeated every  to  minutes until the desired effect is achieved (i.e., clinical improvement or heart rate <100 beats/min). Orally, propranolol therapy usually begins at  to 120 milligrams per dose or 160 to 320
,9 milligrams/d in divided doses.
Propranolol can be given IV at .5 to  milligram over  minutes. This can then be increased to  to  milligrams over  minutes each time, adjusting
 the dose every few hours to the patient’s vital signs. For the less toxic patient, a PO dose of  to  milligrams every  hours can be given.
Alternatively, a short acting β­blocker such as esmolol may be used by administering an IV load of 250 to 500 micrograms/kg, after which  to 100 micrograms/kg/min are given in a titrated dose based on the vital signs. A short­acting β­blocker is preferable for patients with cardiac failure because
 the drug’s action could be curtailed if the patient deteriorates. Alternatively, IV landiolol or oral bisoprolol can be also be used.
Propranolol seems to be better than esmolol, because propranolol has the beneficial effect of preventing T to T conversion as well as being a

 nonselective β­blocker. Nevertheless, a recent study found evidence that, in severe thyroid storm, T to T conversion may already be reduced.

For other conditions contraindicated to β­blockers such as reactive airway diseases, cardioselective β­blockers, such as atenolol or metoprolol, or calcium channel blockers can also be considered.
Alternatively, reserpine .5 to .0 milligrams IM can be given every  to  hours, preceded by 1­milligram test dose while monitoring blood pressure.
Reserpine is an alkaloid agent that depletes catecholamine stores in sympathetic nerve terminals and the CNS. It can have CNS depressant effects. In severe asthmatics, IM reserpine, .5 milligrams every  hours, may be considered in lieu of peripheral blockade. Guanethidine,  to  milligrams PO every  hours, may also be an option. Guanethidine inhibits the release of catecholamines. These agents would be indicated only in rare situations in
 which β­adrenergic receptor antagonists are contraindicated and when there is no hypotension or evidence of CNS­associated mental status changes.
Side effects of both medications include hypotension and diarrhea. Avoid their use in congestive heart failure, hypotension, and cardiac shock as the blood pressure may drop.
The contraindications to peripheral blockade are the same as those for other medical conditions. Exercise caution in patients with congestive cardiac failure and thyrotoxic cardiomyopathy. Complicated patients with both a tachydysrhythmia and congestive heart failure can be managed first with rate control.
TREATMENT AIM 3: INHIBITION OF NEW THYROID HORMONE SYNTHESIS
Thionamides
Thionamides used for the treatment of thyrotoxicosis are either methimazole or propylthiouracil (PTU). Thionamide therapy decreases the synthesis
 of new hormone production but also has immunosuppressive effects. Thionamides inhibit synthesis of thyroid hormones by preventing organification and trapping of iodide to iodine and by inhibiting coupling of iodotyrosines.
Methimazole has a longer half­life than propylthiouracil, permitting less frequent dosing. It presents in free form in the serum, whereas 80% to 90%
 of propylthiouracil is bound to albumin. Methimazole is U.S. Food and Drug Administration pregnancy category D and is especially teratogenic in the first trimester of pregnancy.
,9
The dose for methimazole is  milligrams given PO every  hours. The total daily dose that should be given is  to  milligrams/d. If given PR, similar dose can be crushed in aqueous solution. Although there are no commercially available parenteral formulations of the thionamides, there are
 case reports of methimazole being administered IV in circumstances in which the PO and PR routes of administration could not be used. Methimazole was shown to have similar pharmacokinetics for both PO and IV use in normal subjects and in subjects with hyperthyroidism. In some centers, only
 carbimazole (which is the prodrug of methimazole) is available. If methimazole is not available, carbimazole can be used with the same potency. The initial dose is  to  milligrams, followed by a maintenance dose of between  and  milligrams daily.

As for propylthiouracil, the dose for thyroid storm is 500 to 1000 milligrams given PO as a loading dose followed by 250 milligrams every  hours.
The drug can be given by nasogastric tube or PR. Outside the thyroid gland, only PTU, not methimazole, can inhibit conversion of T to T , and this is
  the advantage of PTU.
Precautions on Use of PTU
In 2009, the Food and Drug Administration notified healthcare professionals of the risk of serious liver injury, including liver failure and death, with the use of PTU in adults and children. There is an increased risk of hepatotoxicity with PTU when compared with methimazole. Since 2010, the Food and
Drug Administration added a boxed warning to the prescribing information of PTU to include information about case reports of severe liver injury and
 acute liver failure, some of which had been fatal. The Food and Drug Administration recommends that PTU be reserved for patients who cannot tolerate methimazole.
PTU is currently used as a second­line drug therapy for hyperthyroidism in general. Its use as a first­line agent is still considered in thyroid storm in view of its advantage of blocking T to T conversion. Nevertheless, there is recent evidence that this conversion may already be reduced in thyroid

 storm. PTU is strictly preferred only in the case of pregnant patients during the first trimester, as methimazole use during this period had been
 associated with teratogenicity. Nevertheless, methimazole is again suggested for use during the second and third trimesters of pregnancy.
If PTU is used, signs and symptoms of liver injury should be closely monitored, especially in the first  months of therapy initiation. PTU medication may cause increased liver enzyme levels. It should not be used as therapy if transaminase levels reach more than three times the upper limit of normal
 or if the levels are elevated at the onset of therapy. PTU should not be used in children unless the patient is allergic to or intolerant of methimazole
 and no other treatment options are available.
TREATMENT AIM 4: INHIBITION OF HORMONE RELEASE
Iodine Lugol solution, potassium iodide, ipodate (Oragrafin®), or lithium carbonate can be given to stop thyroid hormone release. Thionamide therapy must be instituted first with these drugs only given at least  hour later. Iodine therapy blocks the release of prestored hormone and decreases iodide transport and oxidation in follicular cells.
Lugol solution can be given as  to  drops PO initially and then every  to  hours. Lugol solution provides  milligrams of iodide per drop.
Iodinated radiographic contrast dyes that contain ipodate (Oragrafin®) .5 to  grams/d orally or IV iopanoic acid (Telepaque®)  gram every  hours for the first  hours followed by 500 milligrams twice a day have also been used to inhibit hormone release, and they also have the added property to effectively prevent conversion of T to T (Food and Drug Administration pregnancy category C).

All of the iodine­containing agents listed here lead to rapid decreases in both T and T levels.

Nevertheless, iodine­containing solution should not be given to patients with iodine hypersensitivity, iodine overload, or iodineinduced hyperthyroidism or to those with amiodarone­induced thyrotoxicosis.
Alternative Drugs if Iodine Intake Is Contraindicated
Potassium Perchlorate
–
Potassium perchlorate blocks thyroid uptake of iodine and thus interferes with the production of new hormones. The perchlorate anion, ClO , is a
 competitive inhibitor of iodide transport. The recommended dose is .5 gram of potassium perchlorate per day. It is used in amiodarone­induced thyrotoxicosis for which iodine replacement is contraindicated. However, it has side effects of aplastic anemia and nephrotic syndrome.
Lithium
In severe thyroid storm conditions, lithium can also be used in combination with PTU or methimazole. Lithium inhibits thyroid hormone release from thyroid gland. Lithium also has added effects on the thyroid gland that decrease thyroid hormone synthesis, thereby increasing intrathyroidal iodine content and inhibiting coupling of iodotyrosine residues that form T and T . In thyroid storm, the dosing for lithium is 300 milligrams every  hours.

To avoid lithium toxicity, lithium level should be monitored regularly every day to maintain a concentration of approximately .6 to .0 mEq/L (0.6–1.0 mmol/L). Frequent monitoring of serum lithium levels is mandatory, especially because the serum lithium concentrations may change as the patient is
 rendered more euthyroid. Avoid lithium in pregnancy as it has teratogenic effects.
TREATMENT AIM 5: PREVENTING PERIPHERAL CONVERSION OF THYROXINE TO TRIIODOTHYRONINE
The peripheral conversion of T to T , which is responsible for 85% of T present in the circulation, is blocked by PTU, propranolol, and glucocorticoid.

Nevertheless, for PTU and propranolol, this effect is not quantitatively significant. Therefore, glucocorticoids such as hydrocortisone or
 dexamethasone are essential in treatment. Glucocorticoid use in thyroid storm also improves survival rates. In patients who have severe thyrotoxicosis, especially in conjunction with hypotension, treatment with glucocorticoids is a standard practice because of the possibility of relative adrenal insufficiency. Hydrocortisone 300 milligrams IV is given initially, followed by 100 milligrams every  hours until stable. Alternatively,
 dexamethasone  milligrams IV can be given every  hours.
TREATMENT AIM 6: PREVENTING REABSORPTION OR REMOVAL OF THYROID HORMONES
Cholestyramine is used to inhibit thyroid hormone reabsorption. Thyroid hormone is metabolized mainly in the liver, where it is conjugated to glucuronides and sulfates. These conjugation products are then excreted in the bile. Free hormones are released in the intestine and finally reabsorbed, completing the enterohepatic circulation of thyroid hormone. In states of thyrotoxicosis, there is increased enterohepatic circulation of thyroid hormone. Cholestyramine is an anion exchange resin that decreases reabsorption of thyroid hormone from the enterohepatic circulation.
Cholestyramine in combination with methimazole or PTU causes a more rapid decline in thyroid hormone levels than standard therapy with
 thionamides alone. Its dosage is  grams every  hours.
Thyroid Hormone Removal
In patients who have contraindications to PTU and methimazole, such as a prior severe reaction, direct removal of thyroid hormone has been described. Plasmapheresis, charcoal hemoperfusion, resin hemoperfusion, and plasma exchange may be effectively used to rapidly reduce thyroid
 hormone levels in thyroid storm patients who respond poorly to traditional therapeutic measures.
TREATMENT AIM 7: IDENTIFY PRECIPITATING FACTORS
Search for infection in febrile thyrotoxic patients. Obtain an ECG to identify myocardial infarction, ischemia, or arrhythmia.
In cases of thyroid storm precipitated by DKA, myocardial infarction, pulmonary embolism, or other acute processes, appropriate management of the
 specific underlying problem should proceed along with the treatment of the thyrotoxicosis.
TREATMENT AIM 8: DEFINITIVE THERAPY
Definitive therapy with radioactive iodine ablation or surgery may not be able to be done for several weeks or months after treatment with iodine for thyroid storm. Close follow­up and monitoring should continue, with plans for definitive therapy to prevent a future recurrence of life­threatening
 thyrotoxicosis.
RAPID PREPARATION OF THYROTOXIC PATIENTS FOR EMERGENCY SURGERY
In the event that a patient has thyrotoxicosis and requires emergent surgery, the recommendation of drug supplementation is as shown in Table 229­
,18
. The supplementation is important because surgery in a patient with hyperthyroidism may precipitate thyroid storm.
TABLE 229­8
Rapid Preparation of Thyrotoxic Patients for Emergent Surgery
Recommended
Drug Class Dosage Mechanism of Action Continue Postoperatively?
Drug
β­Adrenergic Propranolol 40–80 milligrams β­Adrenergic blockade; decreased thyroxine­ Yes blockade PO  to  times a to­triiodothyronine conversion (high dose) day or
Esmolol 50–100 β­Adrenergic blockade Change to PO propranolol micrograms/kg/min
Thionamide Propylthiouracil 200 milligrams PO Inhibition of new thyroid hormone synthesis; Stop immediately after near­total every  h decreased thyroxine­to­triiodothyronine thyroidectomy; continue after conversion nonthyroidal surgery or
Methimazole  milligrams PO Inhibition of new thyroid hormone synthesis Stop immediately after near­total every  h thyroidectomy; continue after nonthyroidal surgery
Oral Iopanoic acid 500 milligrams PO Decreased release of thyroid hormone; Stop immediately after surgery cholecystographic twice a day decreased thyroxine­to­triiodothyronine agent conversion
Corticosteroid Hydrocortisone 100 milligrams PO Vasomotor stability; decreased thyroxine­to­ Taper over first  h or IV every  h triiodothyronine conversion or
Dexamethasone  milligrams PO or Vasomotor stability; decreased thyroxine­to­ Taper over first  h
IV every  h triiodothyronine conversion or
Betamethasone .5 milligram PO Vasomotor stability; decreased thyroxine­to­ Taper over first  h every  h, IM or IV triiodothyronine conversion
Source: Reproduced with permission from Langley RW, Burch HB: Perioperative management of the thyrotoxic patient. Endocrinol Metab Clin of North Am 32: 519,
2003. Copyright Elsevier.
DISPOSITION AND FOLLOW­UP
Thyroid storm patients typically require admission to the intensive care unit. Patients with thyroid storm often have concomitant diseases precipitating the attack and require close monitoring. Complete recovery may take  week until circulating levels of thyroid hormones are depleted. Stable hyperthyroid patients with minimal symptoms can only be discharged for follow­up either by an endocrinologist or primary care physician, if the patient is already on medication with a clear plan of follow­up.
SPECIAL SITUATIONS
PREGNANCY AND LACTATION
Avoid methimazole during the first trimester of pregnancy in thyrotoxic patients in view of its teratogenic effects. PTU should be used during the first trimester. This can be converted back to methimazole from the second trimester onward. Lithium is contraindicated in pregnancy. Effects on breastfeeding infants are not well documented. Obtain consultation.
ELDERLY PATIENTS
Older patients may present with “apathetic” thyrotoxicosis (i.e., with some atypical symptoms, including weight loss, palpitations, weakness, dizziness, syncope, memory loss, and physical findings of sinus tachycardia or atrial fibrillation). Signs and symptoms of this condition are few and subtle, and the initial appearance of disease may be single­organ failure (e.g., congestive heart failure), producing diagnostic confusion by pointing to diagnoses other than thyrotoxicosis.
THYROTOXIC PATIENTS WITH ATRIAL FIBRILLATION
β­Blockers can provide rate control. Propranolol can be used if the patient is not in failure. Esmolol, with short­acting effect, is a safer choice. If β­ blockers are contraindicated, digoxin can be used. Calcium channel blockers can also be cautiously considered but can induce severe hypotension and reduce systemic vascular resistance. Amiodarone can be considered, but note that it has 37% organic iodine in weight. Ensure thionamides have been given to avoid synthesis of new thyroid hormones. As in any atrial fibrillation, thrombosis may ensue and heparinization should be instituted.
Thyrotoxic patients may require a lower maintenance dose of warfarin than euthyroid patients because of increased clearance of vitamin K–dependent clotting factors.
CONGESTIVE CARDIAC FAILURE IN THYROID STORM
Avoid vasodilators such as nitrates because thyrotoxicosis is associated with vasodilatation and decreased systemic vascular resistance. Avoid β­ blockers when the cardiac failure is associated with underlying ischemic, hypertensive, or valvular heart disease. A short­acting β­blocker such as esmolol is a safer choice.
DRUG INTERACTIONS IN THYROTOXIC PATIENTS
Many drugs interfere with protein binding, including heparin, furosemide, phenytoin, carbamazepine, diazepam, salicylates, opiates, estrogens, and

NSAIDs. Because of this interference with total thyroid hormone levels, free hormone concentrations are preferable in the diagnosis of thyrotoxicosis.


