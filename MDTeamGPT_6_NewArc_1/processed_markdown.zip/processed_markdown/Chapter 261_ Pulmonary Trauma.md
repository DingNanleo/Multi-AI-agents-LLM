## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 261: Pulmonary Trauma
Yvonne L. Wang; David Jones
INTRODUCTION AND EPIDEMIOLOGY
Blunt thoracic trauma produces damage by direct injury, compression, and forces of acceleration or deceleration, whereas penetrating thoracic trauma causes direct injury along the path of a stab wound or projectile. Injuries most often involve the lungs and, less frequently, the heart and great vessels. Regardless of mechanism, stabilization and treatment of these patients follow a similar pathway. In general, patients with penetrating injuries who survive to reach the hospital have better outcomes than those who have sustained blunt injuries. Blunt chest trauma from blast injuries is discussed in Chapter , “Bomb, Blast, and Crush Injuries.” Presume penetrating chest injuries in the “cardiac box” (see Figure 262­1), an area bounded by the sternal notch, xiphoid process, and nipples, to involve the heart or great vessels until proven otherwise.
,2
Blunt thoracic injuries account for up to one fourth of all deaths, and chest wall trauma is a component of 10% of trauma admissions. Penetrating injuries that violate the pleura typically result in pneumothorax, with an accompanying hemothorax in most cases. In polytrauma patients, thoracic
 trauma is the third leading cause of death after abdominal trauma and head trauma. The mechanism of injury and severity of tissue damage predict
,4 the clinical course and outcome.
ANATOMY
The thorax is bordered superiorly by the clavicles and inferiorly by the diaphragm. There are  paired sets of ribs projecting forward from the thoracic vertebrae, with the upper  ending in a cartilaginous joint with the sternum and the bottom  “floating” freely. The muscular diaphragm has muscle fibers inserting into ribs  to  and posteriorly into the T12, L1, and L2 vertebrae. The thoracic cavity is created by a pleural membrane covering the inner thoracic cavity (the parietal pleura) and folding back over the lungs and other intrathoracic structures (the visceral pleura). The lungs have three lobes on the right and two lobes on the left. The mediastinum in the center of the thoracic cavity between the lungs contains the heart and its associated blood vessels, the trachea, the phrenic and cardiac nerves, the esophagus, and the thoracic duct. The trachea descends from the larynx and branches into several tiers of bronchi before ending in alveoli where gases are exchanged in the lung (Figure 261­1).
FIGURE 261­1. Anatomy of the thorax.

Chapter 261: Pulmonary Trauma, Yvonne L. Wang; David Jones 
. Terms of Use * Privacy Policy * Notice * Accessibility
PATHOPHYSIOLOGY
Chest trauma can disrupt the respiratory mechanism, which can have an immediate negative impact on resuscitation and patient outcomes. Bleeding or free air in any portion of the thoracic cavity can limit lung excursion as well as lung volumes. Injury to the chest wall can decrease chest recoil, restricting the ability to generate the negative intrathoracic pressure needed for ventilation and gas exchange. Similarly, disruption of the diaphragm can inhibit the patient’s ability to initiate a breath. Injury to the trachea and bronchi prevent air flow, thereby creating areas of both dead space and physiologic shunting that can impede effective oxygenation and ventilation. Injury to the lung itself can result in disrupted gas exchange due to tissuelevel injury and create a ball­valve system resulting in a pneumothorax. As more gas becomes trapped in the extrapulmonary space, intrathoracic pressure increases, which limits venous return and disrupts respiratory mechanics.
CLINICAL APPROACH
HISTORY
The most frequent symptoms of thoracic trauma are chest pain and shortness of breath. Pain is most often localized to the involved area of the chest wall, but is sometimes referred to the abdomen, neck, shoulder, back, or arms. Dyspnea and tachypnea are nonspecific findings and may also be caused by blood loss, pain from other injuries, or anxiety.
PHYSICAL EXAMINATION
Rapidly perform the physical examination during the primary and secondary surveys to detect life­threatening injuries.
Inspect the chest wall for contusions, abrasions, and other signs of trauma, including a “seat belt sign” that can indicate deceleration and potential vascular injury. Examine the chest for signs of paradoxical segments or flail chest, intrathoracic bleeding, and open chest wounds. The patient must be making a reasonable ventilatory effort to demonstrate these injuries.
Distended neck veins may indicate the presence of cardiac tamponade, tension pneumothorax, or air embolism; however, in the setting of hypovolemia, this sign may be absent. If the face and neck are cyanotic or swollen, then suspect severe injury to the superior mediastinum with occlusion or compression of the superior vena cava. Subcutaneous emphysema from a torn bronchus or laceration of the lung can also cause severe swelling of the neck and face.
A scaphoid abdomen may indicate a diaphragmatic injury with herniation of abdominal contents into the chest. Excessive abdominal movement during breathing may indicate chest wall damage that might not otherwise be apparent.
Breath sounds are most readily heard in the axillae. Unilaterally decreased breath sounds may indicate the presence of hemothorax or pneumothorax.
If the patient has an endotracheal tube in place, assess for possible mainstem bronchus intubation (the usual depth should be no more than three times the inner diameter of the endotracheal tube—23 cm in adult males and  cm in adult females) before performing tube thoracostomy in these patients. Persistent decreased breath sounds on one side may also be due to a bronchial foreign body or ruptured bronchus. The presence of bowel sounds in the thorax usually indicates a diaphragmatic injury.
Palpate the neck to determine whether the trachea is midline or displaced. Palpation of the chest wall may reveal areas of localized tenderness or crepitus due to fractured ribs or subcutaneous emphysema. Localized and consistent tenderness over ribs should be attributed to rib fractures, even in the absence of findings on conventional chest radiography. Severe localized tenderness, crepitus, or a mobile segment of the sternum may be the only objective evidence of a sternal fracture. Palpation of the chest with the patient coughing or straining may detect flail, an abnormal motion of an unstable portion of the chest wall, better than visual inspection.
The sensitivity and specificity of most physical examination findings are not high enough to exclude common thoracic injuries. The sensitivity of
 auscultation for the detection of a traumatic hemopneumothorax is only 50%. Subcutaneous emphysema of the chest, however, has a specificity of
98% for underlying overt or occult pneumothorax. Consider patient symptoms, vital signs, and physical examination findings together to detect significant injuries in stable chest trauma patients and to guide further investigation with imaging. Obtain a chest radiograph. Perform an extended
FAST examination as an adjunct to the secondary survey because it can rapidly diagnose both pneumo­ and hemothorax with excellent sensitivity and specificity.
SPECIFIC PULMONARY INJURIES
PULMONARY CONTUSION
Pulmonary contusions, defined as direct injury to the lung resulting in both hemorrhage and edema in the absence of a pulmonary laceration, are a source of severe morbidity and mortality following penetrating and blunt trauma. CT has shown this entity to be much more prevalent than previously
 recognized. The most common cause of pulmonary contusions is a compression­decompression injury to the chest, such as seen in high­speed motor vehicle crashes.
There are two stages in the pathophysiology of pulmonary contusions. First, there is direct injury to lung parenchyma. Second, resuscitative measures, particularly IV crystalloid fluid administration directed at restoring intravascular volume loss due to hemorrhage, can precipitate cardiopulmonary decompensation. Fluid resuscitation in the setting of unilateral pulmonary contusion can cause extravasation of fluid into the contralateral (uninjured) lung. Increased capillary hydrostatic pressures result in leakage of blood and fluid into the interstitium and alveoli. Unfortunately, the process is selfperpetuating; as each proximate segment of lung sees the full force of right heart activity, it becomes functionally congested and contused, and the process continues to the next uninjured segment of lung. This process results in increased intrapulmonary shunting and resistance to airflow, decreased lung elasticity, and increased work of breathing, leading to hypoxia, hypercarbia, and respiratory acidosis. Cardiopulmonary decompensation may quickly ensue.
Chest pain, tachypnea, chest wall contusions, and hypoxia suggest underlying pulmonary contusion. Physical examination may reveal decreased or coarse breath sounds over the affected lung field. Chest radiograph and CT may show patchy, ground­glass opacities in mild or moderate contusion
 and widespread consolidation in severe contusion. Contusions are found in nonsegmental areas of the lung and across pleural fissures. Radiographic findings of pulmonary contusion may mimic those associated with aspiration pneumonia and fat embolism, but these entities are typically not seen for
 to  hours and usually have a segmental distribution. Areas of lung opacification on chest imaging within  hours of blunt trauma are usually considered diagnostic of pulmonary contusion (Figure 261­2). CT is more sensitive for the detection of pulmonary contusions than
 plain radiographs, with as many as 70% of pulmonary contusions not visible on the initial radiograph. In addition to the high diagnostic rate of CT scan for pulmonary contusion, it may also be possible to anticipate complications such as acute lung injury (also known as acute respiratory distress syndrome or noncardiogenic pulmonary edema), depending on the extent of the pulmonary contusion. Patients who have a contusion >20% of lung
 volume have up to an 80% risk of developing acute lung injury.
FIGURE 261­2. Pulmonary contusion. A. Chest radiograph shows pulmonary contusion from blunt chest trauma, along with ninth and tenth rib fractures. B. CT shows pulmonary contusions on the anterior part of the right lung and a sternal fracture with mediastinal hematoma.
Treatment primarily involves maintenance of adequate ventilation and pain control. Epidural analgesia is the preferred method of pain control;
 however, consider intercostal nerve blocks and paravertebral analgesia when an epidural is contraindicated. The volume of contused lung influences the need for mechanical ventilation. Patients with less than one fourth of total lung volume involvement (about one lobe) usually do not require such support. If ventilatory assistance is required, avoid overinflation of normal alveoli. Patients with extensive pulmonary contusion may be candidates for
 high­frequency oscillatory ventilation, a technique that can improve oxygenation, although it may not improve survival. Guidelines for the
 management of pulmonary contusion and flail chest are listed in Table 261­1. TABLE 261­1
Eastern Association for the Surgery of Trauma Practice Management Guideline for Pulmonary Contusion—Flail Chest
Level  recommendations (convincingly justifiable None.
based on the available scientific information alone)
Level  recommendations (reasonably justifiable by Unnecessary fluid administration should be meticulously avoided; a pulmonary artery catheter available scientific evidence and strongly supported may be useful to avoid fluid overload.
by expert opinion) Obligatory mechanical ventilation should be avoided.
The use of optimal analgesia and aggressive chest physiotherapy should be applied to minimize the likelihood of respiratory failure and ensuing ventilatory support.
Patients with pulmonary contusion requiring mechanical ventilation should be weaned from the ventilator at the earliest possible time.
Positive end­expiratory pressure/continuous positive airway pressures should be included in the ventilatory regimen.
Steroids should not be used in the therapy of pulmonary contusion.
Level  recommendations (supported by available A trial of mask continuous positive airway pressure should be considered in alert, compliant data but adequate scientific evidence is lacking) patients with marginal respiratory status.
Independent lung ventilation may be considered in severe unilateral pulmonary contusion.
Diuretics may be used in the setting of hydrostatic fluid overload as evidenced by elevated pulmonary capillary wedge pressures in hemodynamically stable patients or in the setting of known concurrent congestive heart failure.
Surgical repair may be considered in severe unilateral flail chest or in patients requiring mechanical ventilation when thoracotomy is otherwise required.
Patients with severe unilateral lung injury who are not responding to conventional mechanical ventilation may benefit from synchronous independent lung ventilation provided through a double­lumen endobronchial catheter. This technique helps prevent overinflation of the normal lung and underinflation of the damaged, poorly compliant lung.
HEMOTHORAX
Bleeding from direct lung injury is the most common cause of hemothorax. The compressing effect of the blood within the pleural space, high concentration of lung thromboplastin, and low pulmonary arterial pressure help limit bleeding as a result of torn lung parenchyma. Bleeding into the hemithorax may arise from mediastinal, diaphragmatic, pulmonary, pleural, or chest wall injuries. Bleeding of venous origin usually tamponades without intervention. Damage to intercostal or internal mammary arteries or pulmonary vessels causes more severe bleeding and almost always requires invasive management.
If the hemothorax is judged large enough to drain (>200 to 300 mL), tube thoracostomy remains the standard of care. Large clots in the pleural space can act as a local anticoagulant by releasing fibrinolysins from their surface. Bleeding from multiple small intrathoracic vessels often stops fairly rapidly after the hemothorax is completely evacuated. (See Video: Chest Tube Insertion.)
Video 261­1: Chest Tube Insertion
Used with permission from Henderson McGinnis, Department of Emergency Medicine, Wake Forest University Baptist Medical Center; Judith E. Tintinalli, David Cline,
O. John Ma
Play Video
Fluid collections >200 to 300 mL can usually be seen on upright or decubitus chest radiographs. However, if the patient is supine, >1000 mL of blood may be missed due to posterior layering of blood, producing only diffuse haziness on that side (Figure 261­3). POCUS may be used in the critically ill patient to detect hemothorax (Figure 261­4), showing a fluid density between visceral and parietal pleura normally occupied by lung tissue. CT has the highest sensitivity and specificity for detecting hemothorax.
FIGURE 261­3. Hemothorax. A. Anteroposterior view of the chest in patient with penetrating knife injury to the posterior left thorax. The site of injury is marked by a paper clip. Hazy opacity on the left, with associated volume loss in the left lung, is indicative of posteriorly layering hemothorax and atelectatic change.
B. CT image in the same patient showing large hemothorax layering dependently in the supine patient. [Reproduced with permission from Block J,
Jordanov MI, Stack LB, Thurman RJ (eds): The Atlas of Emergency Radiology. McGraw­Hill, Inc., 2013. Fig .23 & .24.]
FIGURE 261­4. Hemothorax. US can evaluate for pleural fluid, which usually represents hemothorax. Pleural fluid (hemothorax) can be seen superior to the diaphragm.
INDICATIONS FOR OPERATIVE INTERVENTION
Most patients with intrathoracic bleeding can be treated adequately by IV administration of fluids and evacuation of the hemothorax with a chest tube.
Fewer than 5% of patients will require operative management. Consider surgical exploration in the following circumstances: >1500 mL of blood is evacuated immediately after tube thoracostomy, chest tube drainage of blood at 150 to 200 mL/h for  to  hours, or persistent blood transfusion is required to maintain hemodynamic stability.
MASSIVE HEMOTHORAX
Common causes of massive hemothorax include injury to the lung parenchyma, intercostal arteries, or internal mammary arteries. Each hemithorax can hold 40% of a patient’s circulating blood volume. A massive hemothorax is defined in the adult as a volume of at least 1500 mL. Massive hemothorax is life threatening by three mechanisms. First, acute hypovolemia does not allow for sufficient preload to sustain left ventricular function and adequate cardiac output. Second, the collapsed lung results in hypoxia by creating alveolar hypoventilation, ventilation–perfusion mismatch, and anatomic shunting. Third, the hydrostatic pressure of the hemothorax compresses the vena cava and the pulmonary parenchyma, further impairing preload and raising pulmonary vascular resistance, respectively. Although the clinical signs and symptoms of hemothorax in the chest trauma patient can vary, suggestive findings include decreased or absent breath sounds and no chest movement with respiratory effort.
The diagnosis is made by plain chest radiography when complete opacification of a hemithorax is observed. POCUS may reveal a large fluid collection between the chest wall and lung (Figure 261­5). Lung collapse, due to intubation of the contralateral mainstem bronchus, can mimic the appearance of hemothorax on chest radiograph; always verify proper endotracheal tube placement. For symptomatic hemothoraces or hemothorax with greater than 500 mL of blood, treatment is tube thoracostomy and replacement of blood products as clinically indicated. For patients with hemothorax who
 are hemodynamically stable, early video­assisted thoracic surgery is beneficial.
FIGURE 261­5. Free pleural fluid. The right diaphragm appears as a bright hyperechoic structure along the border of the liver. Free pleural fluid can be identified as an anechoic stripe superior to the diaphragm. The pleural fluid allows visualization of the posterior chest wall (arrows) that cannot be visualized when the air­filled lung is normally present. The patient also has a circular defect in the liver (arrowheads) from a bullet wound and there is fluid in Morison’s pouch. [Reproduced with permission from Ma OJ, Mateer JR (eds): Ma and Mateer’s Emergency Ultrasound, 3rd ed. © 2014, McGraw­Hill, Inc., New
York. Fig 5­20.]
PNEUMOTHORAX
To establish the diagnosis of a pneumothorax with upright plain chest radiography, identify a thin white pleural line usually seen best in the upper lateral aspect of the affected hemithorax in the upright patient (Figure 261­6). If the radiograph is obtained with the patient supine, small pneumothoraces may not be apparent as air migrates to the anterior chest, resulting in loss of the interface between the parietal pleura and the airfilled pleural space. POCUS can diagnose a pneumothorax. Sonographic imaging of a normal lung with the high­frequency linear probe at the anterior superior aspect of the chest will reveal “ants marching in a line” or the “lung sliding sign,” a result of the movement of the pleural layers during the ventilatory phase. This movement is absent in the presence of pneumothorax. Occasionally, the “lung point” or “transition point,” where normal lung sliding transitions to absent lung sliding in a patient with a pneumothorax, can also be seen. Lung point is 100% specific but less sensitive for pneumothorax, whereas the absence of lung sliding is more sensitive but not 100% specific; patients with large pulmonary contusions or incorrect endotracheal tube placement may not demonstrate normal lung sliding.
FIGURE 261­6. Pneumothorax. A. The pleural line is seen in the left hemithorax, but lateral to the pleura, there is increased lucency (air density) and an absence of lung markings. These findings should prompt concern for a pneumothorax. B. Enlarged area of the same image to further illustrate the increased lucency and absent lung markings lateral to the pleural line.

Pneumothorax is found in approximately 20% of patients with significant chest trauma. Traumatic pneumothorax can be open, closed, or occult. In an individual without preexisting cardiopulmonary disease, an isolated pneumothorax usually does not cause severe symptoms unless it occupies
>40% of the hemithorax. Occult pneumothoraces may complicate the management of patients who are emergently taken to the operating room because intubation and positive­pressure ventilation may convert a small occult pneumothorax into a tension pneumothorax.
A pressure differential across the pulmonary pleura results in airflow down the gradient. Therefore, positive pulmonary pressure or negative intrapleural pressure during inspiration increases the tendency for air or blood to leak into the pleural cavity through any wound in the lung or chest wall. Any collection of air or blood within the pleural cavity may reduce vital capacity, increase intrathoracic pressure, and decrease minute ventilation and venous return to the heart. Additional air may be forced into the pleural cavity during expiration in patients with outflow obstruction, such as in chronic obstructive lung disease or airway occlusion, thus increasing the likelihood of tension pneumothorax.
Maintain a high suspicion for occult pneumothoraces in patients with more subtle injuries. Although chest radiography remains the most common diagnostic tool for detecting pneumothorax in the ED (Figure 261­7), it will miss between 17% and 80% of pneumothoraces for upright and supine chest radiographs, respectively. POCUS is more sensitive than a supine radiograph and is rapid and accurate for
12­14  detecting pneumothorax. Occult pneumothoraces are detected by CT (Figure 261­8). Importantly, with the exception of patients who may require intubation and positive­pressure ventilation (which may convert a small occult pneumothorax into a tension pneumothorax), the detection of
,16 occult pneumothoraces using chest CT has minimal clinical significance and does not improve outcome.
FIGURE 261­7. Pneumothorax. This right­sided pneumothorax can be diagnosed by the absence of lung markings and increased (air density) lucency lateral to the pleural line.
FIGURE 261­8. Pneumothorax. Pneumothorax of the right hemithorax, with small bilateral posterior pulmonary contusions.
If pneumothorax is suspected despite normal initial chest radiography, obtaining serial films or performing POCUS or CT may be helpful.
Pneumothorax after a stab wound may be delayed for up to  hours. Consequently, repeat chest imaging in  to  hours is indicated in these patients or at any time when symptoms worsen. Patients with initially asymptomatic stab wounds to the chest have a reported 12% incidence of
 delayed hemothorax or pneumothorax that requires tube thoracostomy. A common practice is to observe patients with asymptomatic thoracic stab wounds, repeat the chest radiograph in  to  hours, and discharge the patient if no delayed pneumothorax is seen in the absence of other concerns.
If the patient cannot be observed closely, requires intubation and mechanical ventilation, or will be transported by air or over a long distance, insert a chest tube or small pleural (pigtail) catheter. Small pneumothoraces (<1.0 cm wide, confined to the upper third of the chest) that are unchanged on two chest radiographs taken  to  hours apart in an otherwise healthy individual can usually be treated by observation alone.
Occult pneumothoraces (small pneumothoraces not apparent on conventional chest imaging but seen on a CT scan of the chest or abdomen) usually do not require chest tube drainage unless the patient requires mechanical ventilation. Avoid unnecessary tube thoracostomy because there is a 22%
 risk of major insertional, positional, or infective complications.
In general, small­ or moderate­sized pneumothoraces, once treated, do not cause significant problems unless there is a continuing air leak or preexisting cardiopulmonary disease. Even a small air leak usually will not result in serious complications, provided the lung is completely expanded.
However, the incidences of empyema and bronchopleural fistula are greatly increased in pneumothoraces with continued air leak persisting for >24 to
 hours.
If the lung does not completely expand or the pneumothorax does not evacuate, then investigate potential causes (Table 261­2). If a pneumothorax persists or there is a large air leak, perform emergency bronchoscopy to examine and clear the bronchi or to identify and repair any damage to the tracheobronchial tree. Continued large air leakage or failure of the lung to adequately expand, despite these measures, is an indication for early thoracotomy.
TABLE 261­2
Causes for Failure of Complete Lung Expansion or Evacuation of a Pneumothorax
Improper connections or leaks in the external tubing or water­seal collection apparatus
Improper positioning of the chest tube
Occlusion of bronchi or bronchioles by secretions or foreign body
Tear of one of the large bronchi
Large tear of the lung parenchyma
TENSION PNEUMOTHORAX
Diagnose and treat tension pneumothorax clinically, before the chest radiograph is obtained. Although the classic presentation includes distended neck veins, hypotension or evidence of hypoperfusion, diminished or absent breath sounds on the affected side, and tracheal deviation to the contralateral side (Figure 261­9), one or more of these elements may be absent in the presence of hypovolemia. Patients requiring assisted ventilation with a tension pneumothorax are more likely to be hypoxic, be hypotensive, and experience cardiac arrest than those who are breathing
 spontaneously. Perform immediate needle decompression, usually in the fourth intercostal space at the anterior axillary line,
 followed by chest tube insertion.
FIGURE 261­9. Tension pneumothorax. Supine chest radiograph of a tension pneumothorax. Note the deviation of the trachea and shifting of the mediastinal contents to the right. Tension pneumothorax should clinically be diagnosed prior to chest radiograph. [Reproduced with permission from Schwartz DT
(ed): Emergency Radiology, Case Studies. © 2008 McGraw­Hill Inc., Fig I­9­10.]
OPEN PNEUMOTHORAX
Open pneumothorax is a communication between the pleural space and surrounding atmospheric pressure. This is sometimes referred to as a
“sucking chest wound,” but also may be due to small rents in the parietal pleura or small air passages without an obvious penetrating injury.
Respiratory distress is due to lung collapse and subsequent inability to ventilate the affected lung. Air entry and breath sounds are often diminished on the affected side, and chest wall motion can be impaired. The initial therapeutic maneuver to treat a sucking chest wound is to cover the wound with a three­sided dressing such that air can exit but not enter the chest. Avoid complete occlusion, as this may convert the injury into a tension pneumothorax. Do not insert a chest tube through the trauma wound, as it is likely to follow the missile or knife tract into the lung or diaphragm.
PNEUMOMEDIASTINUM
Subcutaneous emphysema in the neck or the presence of a crunching sound (Hamman’s sign) over the heart during systole suggests the presence of a pneumomediastinum. This diagnosis can usually be made on chest radiography (Figure 261­10A) and is readily apparent on CT of the chest (Figure
261­10B). Pneumomediastinum in blunt chest trauma is most commonly the result of alveolar rupture, followed by dissection along the bronchoalveolar sheath and subsequent spread of air to the mediastinum, a process known as the Macklin effect. Traumatic pneumomediastinum may be asymptomatic or can cause mild to moderate chest pain, voice change, cough, or stridor. Pneumomediastinum alone does not require further diagnostic testing or intervention unless the patient is symptomatic, in which case a search for other serious injuries to the larynx, trachea, major bronchi, pharynx, or esophagus is essential.
FIGURE 261­10. Pneumomediastinum. A. Blunt trauma to the chest while playing basketball. Patient had sudden onset of chest pain and shortness of breath.
Subcutaneous emphysema was evident in the neck. Chest radiograph reveals mediastinal and subcutaneous air. B. In this same patient, a CT scan shows pneumomediastinum.
PULMONARY HEMATOMA
Pulmonary hematomas are parenchymal tears filled with blood. Although these generally resolve spontaneously over a few weeks, they sometimes can become infected and progress to lung abscesses. Infection is more likely in patients on a ventilator, who require prolonged chest tube drainage, or who are postthoracotomy.
PULMONARY LACERATION WITH HEMOPNEUMOTHORAX
Hemorrhage from pulmonary lacerations is most commonly seen in the setting of displaced rib fractures due to direct trauma from the exposed ends of bone. Hemorrhage may also be due to the effect of shear forces on preexisting pleural adhesions during rapid deceleration injuries or from penetrating chest injuries.
ASPIRATION
Aspiration of gastric contents is common after severe trauma, especially if the patient was unconscious at any time. Radiographic changes may be delayed for up to  hours and can include consolidation virtually anywhere in the lungs, with the most common sites being the right middle and lower lung fields. This is the result of a chemical pneumonitis as lung parenchyma is exposed to gastric contents. Frequent suctioning is indicated, as well as continual assessment of the need for endotracheal intubation if the patient is at further risk for aspiration. There is no evidence to support the use of prophylactic antibiotics to prevent pulmonary infection after gastric aspiration.
Aspirated opaque foreign bodies in the tracheobronchial tree may be diagnosed on plain radiographs, but even teeth can be easily missed due to size, relative lucency, and the presence of overlying bone and soft tissue densities. Once recognized, prepare for urgent bronchoscopy to remove tracheal or bronchial foreign bodies.
Expiratory chest radiographs may help diagnose foreign bodies that act as a one­way valve, causing air trapping and hyperinflation on the affected side. Undiagnosed bronchial foreign bodies lead to recurrent or difficult­to­treat pulmonary infections, sometimes taking months to discover.
Persistent or recurrent cough, atelectasis, and pneumonia after trauma are indications for bronchoscopy.
TRACHEOBRONCHIAL INJURY
INTRABRONCHIAL BLEEDING
Intrabronchial bleeding can lead to severe hypoxemia and rapid death. Hemorrhage into dependent alveoli hinders gas exchange in a mechanism similar to drowning. It is important to identify the involved lung and to keep the other lung as free of blood as possible. Bronchoscopy is often necessary to identify injury and control bleeding. Intubation with frequent tracheal suction may be effective. If the hemorrhage is severe, a doublelumen endotracheal tube can be used as a temporizing measure to confine the bleeding to one lung. If a double­lumen endotracheal tube is not available, a standard tube may be inserted over a flexible bronchoscope into the unaffected lung, or an endotracheal tube can be purposely passed into the right mainstem bronchus as a diagnostic measure and the patient placed with the affected lung in the dependent position.
LOWER (INTRATHORACIC) TRACHEA AND MAJOR BRONCHI
Injuries to the major bronchi occur primarily due to rapid deceleration injuries, which cause shear forces to mobile distal bronchi relative to more fixed proximal structures. Forced expiration against a closed glottis and compressive forces on the pulmonary tree against the vertebral column may also cause injury to these structures. Most tracheobronchial injuries occur within  cm of the carina or at the origin of lobar bronchi.
The most common presenting signs and symptoms are dyspnea, hemoptysis, subcutaneous emphysema, Hamman’s sign, and sternal tenderness. A large pneumothorax, pneumomediastinum, or deep cervical emphysema may also suggest tracheobronchial injury. On careful inspection, the endotracheal tube balloon may have a spherical rather than oval appearance on chest radiographs. Approximately 10% of patients present with very mild symptoms or are completely asymptomatic. When tracheobronchial injuries are suspected, bronchoscopy is the gold standard for diagnosis, and
 operative repair can prevent significant complications.
The air leak due to bronchopleural fistula following tube thoracostomy is continuous and massive. High­frequency oscillation is the ventilator modality of choice to maintain gas exchange and expand the alveoli in the face of the massive gas leak.
All lacerations of the bronchi involving more than one third of the circumference should be operatively repaired. Untreated tracheal tears may result in severe mediastinitis or can lead to severe bronchial stenosis with atelectasis and repeated pulmonary infections.
Intrathoracic tracheal transection is usually associated with two or more major injuries and is almost invariably fatal. Patients who survive a tracheal transection generally sustain an injury in the cervical trachea and have no other associated injuries. Concurrent esophageal injuries occur in almost
25% of penetrating tracheobronchial injuries and can be missed unless esophagoscopy or contrast studies are also performed.
CERVICAL TRACHEAL INJURIES
Blunt injuries to the upper (cervical) trachea are usually found at the junction of the trachea and cricoid cartilage. This most frequently occurs when the anterior neck strikes the steering wheel or dashboard in an automobile accident. However, hyperextension of the neck can also cause tracheal lacerations, fractures, and even laryngotracheal separation. Evidence of direct trauma to the neck, including contusions and subcutaneous emphysema, vocal cord paralysis, aphonia, and pneumothorax, should raise suspicion for this injury as well as accompanying
,22 nerve, vascular, esophageal, and spinal injuries. Laryngotracheal separation may not be suspected until attempts to pass the endotracheal tube past the cricoid cartilage are unsuccessful. Treatment and diagnosis are discussed in Chapter 260, “Trauma to the Neck.”
DIAPHRAGMATIC INJURY
Diaphragmatic injuries are caused most frequently by penetrating trauma, particularly gunshot wounds of the lower chest or upper abdomen.
Diaphragmatic rupture due to blunt trauma is much less common and occurs in <5% of patients hospitalized with chest trauma. If there is a fracture of the pelvis, the incidence of diaphragmatic hernia increases.

More diaphragmatic injuries following blunt trauma are diagnosed on the left hemidiaphragm. This left­sided predominance is likely due to the protective effect of the liver on the right hemidiaphragm and the possible increased weakness of the left posterolateral diaphragm.
The initial signs and symptoms of diaphragmatic hernia are often masked by other injuries and have a delayed presentation unless the defect is large.
Over time, the abdominal viscera can gradually migrate into the chest through even small diaphragmatic tears; patients may present years after the initial injury with a traumatic diaphragmatic hernia. The intrathoracic bowel may become obstructed or ischemic due to torsion or strangulation or cause severe compression of the adjacent lung, a phenomenon referred to as tension enterothorax.
If a penetrating wound of the abdomen is associated with intrathoracic injury or foreign body, it should be assumed that the injury traversed the
 diaphragm. Chest radiographs may display injury to the diaphragm in only approximately 25% of such patients. With blunt trauma, any abnormality of the diaphragm or lower lung fields on chest images should arouse suspicion of a diaphragmatic tear (Figure 261­11).
FIGURE 261­11. Diaphragmatic injury. Patient with diminished breath sounds of the left hemithorax after blunt thoracoabdominal injury. Chest radiograph shows left diaphragmatic injury.
Techniques for diagnosing diaphragmatic injuries include (1) orogastric tube placement with evaluation to see if the tube curves up from the abdomen into the chest; (2) upper GI series looking for displacement of viscera into the chest; (3) CT of the chest and abdomen with contrast (Figure 261­12);
(4) laparoscopy; and (5) thoracotomy or laparotomy. Laparoscopy is the favored approach for diagnosis of isolated traumatic diaphragmatic injury.
Laparoscopy or traditional laparotomy is necessary to repair the diaphragm, and thoracotomy may be necessary for associated chest injury, resuscitation, delayed repair of the diaphragm, or management of thoracic complications.
FIGURE 261­12. Diaphragmatic injury. Right diaphragmatic injury on CT.
ESOPHAGEAL AND THORACIC DUCT INJURIES
ESOPHAGEAL INJURIES
Injuries to the thoracic esophagus may occur through direct penetrating trauma and, less often, via blunt trauma. Mortality is high as a result of associated injuries to other organs in the chest. Lacerations of the esophagus occur iatrogenically as a result of endoscopic biopsy or dilatation of a narrowed or obstructed esophagus. Swallowed foreign bodies can also traumatize the esophagus.
Overall, esophageal injuries are rare after blunt thoracic trauma. In one large retrospective review of patients with incidental pneumomediastinum found on chest radiograph or CT scan, there was poor positive predictive value for either tracheobronchial or esophageal injury. Of over 9000 patients
 with pneumomediastinum, only a single case of esophageal injury was diagnosed.

If traumatic esophageal injury is suspected but there is no indication for immediate operative exploration, obtain CT angiography of the neck.
Despite the diagnostic and therapeutic advances, esophageal injuries are associated with significant morbidity and mortality, particularly if there is a delay in recognition and definitive management. For full discussion, see Chapter 260, “Trauma to the Neck.”
THORACIC DUCT INJURIES
Suspect thoracic duct injuries in patients with penetrating trauma near the left proximal subclavian vein. Although the diagnosis is rarely made in the
ED, the development of a chylothorax, accumulation of lymphatic fluid in the pleural space, is associated with metabolic, nutritional, and immunologic derangements, and has a mortality rate of 50%. Traumatic chylothorax should be considered in trauma patients, as early surgical intervention and
 thoracic duct embolization have demonstrated improved success in treating this rare injury.
INJURIES TO THE CHEST WALL
BLEEDING AND TISSUE LOSS
Probing of a penetrating chest wound to determine its depth or direction is not recommended and may not give an accurate picture of the depth of penetration. Such wounds, especially if there is continued bleeding, are better managed by local exploration in the operating room.
Injuries caused by high­powered rifles or close­range shotgun blasts may cause large tissue defects of the chest wall. In such patients, intubation and mechanical ventilation are required until the defect is definitively closed.
SUBCUTANEOUS EMPHYSEMA
Subcutaneous emphysema usually develops because air from lung parenchyma or the tracheobronchial tree gains access to the chest wall through an opening in the parietal pleura. The air may also reach the chest wall from an interstitial lung injury by dissecting back along the bronchi into the hilum and mediastinum and then into the extrapleural spaces. Extensive subcutaneous emphysema may also suggest an injury to the pharynx, larynx, or esophagus.
Presume patients with subcutaneous emphysema have an underlying pneumothorax, even if it is not visible on the chest radiograph. POCUS is more sensitive than chest radiograph for the detection of pneumothorax. If the patient requires intubation and subsequent positive­pressure ventilation, insert a chest tube on the involved side. If subcutaneous emphysema is severe, suspect a major bronchial injury and investigate further with bronchoscopy.
RIB FRACTURES
Rib fractures are the most common bony injuries in chest trauma and are diagnosed in approximately 50% of patients admitted to the hospital
  following chest trauma. Rib fractures are painful injuries, heal slowly, and are closely associated with mortality and morbidity. Rib fractures can be markers of potential internal injury; the principal diagnostic goal with clinically suspected rib fractures is the detection of significant associated complications, such as hemopneumothorax, pulmonary contusion, intra­abdominal injury, or major vascular injury. In the patient with severe chest trauma or significantly displaced rib fractures or in the presence of other injuries, perform serial chest imaging to evaluate for developing pneumothoraces or other injuries.
Assume the presence of rib fractures in any patient with localized pain and tenderness over one or more ribs after chest trauma. Up to 50% of rib fractures (especially those involving the anterior and lateral portions of the first five ribs) are not apparent on conventional radiography, particularly in
 the first few days after injury. Furthermore, injuries to the cartilaginous portions of the ribs may never be appreciated on plain radiographs. US is a
 promising diagnostic tool for evaluating rib fractures and even for cartilaginous injury.
The pain of rib fractures can greatly interfere with ventilation, leading to splinting and atelectasis. Rib fractures can also prolong the time for weaning from ventilator support. Do not immobilize the chest wall with tape or binders. Adequate analgesia is critical to maintain normal respiratory function
 during the healing process. A combination of opioids, benzodiazepines, topical lidocaine patch, and NSAIDs provides the most effective analgesia for mild to moderate chest wall pain.
An intercostal nerve block or serratus anterior plane block with a long­acting agent such as bupivacaine will relieve severe pain associated with muscle spasm and ventilation for up to  hours. For patients admitted to the hospital, epidural analgesia or intrapleural catheters for administration of local
  anesthetics also relieve chest wall pain. Epidural analgesia for blunt chest trauma may be a better choice than IV opioid analgesia.
With the exception of direct local trauma, it takes great force to fracture the first and second ribs, given their short length, relative immobility, and protection by other structures in the upper chest. Such fractures can be associated with significant injuries to underlying organs such as blunt myocardial injury, bronchial tears, or a major vascular injury, with 15% to 30% associated with poor outcome, usually from head injury or rupture of a major vessel.
In patients with multiple fractured ribs of the middle (ribs  to 8) and lower segments (ribs  to 12), unexplained hypotension may be the result of intra­
 abdominal bleeding from the liver or spleen. Consider imaging of the abdomen by CT or US in any patient with middle or lower rib fractures. Patients with multiple fractured ribs will often have difficulty coughing or adequately clearing secretions and should be considered for 24­ to 48­hour observation unit admission, especially the elderly or those with preexisting pulmonary disease.
FLAIL CHEST
Segmental fractures of three or more adjacent ribs anteriorly or laterally often result in an unstable chest wall physiology known as flail chest. This injury is characterized by a paradoxical inward movement of the involved chest wall segment during spontaneous inspiration and outward movement during expiration. Although paradoxical motion can greatly increase the work of breathing, the primary cause of the hypoxemia is contusion to the underlying lung. These patients may fatigue rapidly as a vicious cycle of decreasing ventilation, increased work of breathing, and hypoxemia may develop, resulting ultimately in sudden respiratory arrest.
Patients with mild to moderate flail chest and, importantly, little or no underlying pulmonary contusion or associated injury can often be managed without a ventilator. Adequate, multimodal pain relief by analgesics or nerve blocks allowing good ventilation and pulmonary toilet are important
 adjuncts when managing these patients. Indications for early ventilatory support include shock, severe head injury, comorbid pulmonary disease, fracture of eight or more ribs, other associated injuries, age >65 years, or arterial partial pressure of oxygen
(PO ) <80 mm Hg despite supplemental oxygen. Increased age and global injury severity as measured by the Injury Severity Score are poor

,37 prognostic signs in flail chest. Early intubation and ventilatory assistance in patients with flail chest reduce mortality compared with delaying intubation until the onset of respiratory failure.
38­42
There is mounting evidence for the benefit of surgical fixation of rib fractures causing flail chest. The aim of fixation is to reduce the need for ventilatory assistance, decrease complications (pneumonia and tracheostomy), and shorten hospital and intensive care unit length of stay; however,
,44 improved pain relief and ventilatory support may achieve a similar goal. The Eastern Association for the Surgery of Trauma recommends consideration of surgical fixation in flail chest patients requiring mechanical ventilation when thoracotomy is undertaken to manage other injuries

(Table 261­1).
STERNUM FRACTURE

Tenderness over the sternum may indicate sternal fracture. Sternal fractures usually occur at the body. Lateral chest radiography can detect a
 fracture (Figure 261­13), but diagnosis is usually made by CT (Figure 261­14). US is more sensitive and specific than chest radiographs for sternal
,47 fractures.
FIGURE 261­13. Sternal fracture. Lateral chest radiograph reveals a sternal body fracture after blunt chest injury.
FIGURE 261­14. Sternal fracture. Patient presents with seat belt sign on the chest wall and tenderness over the sternum. CT shows vertical fracture of sternum and mediastinal hematoma under the fracture.
Sternal fractures have historically been considered a marker of serious life­threatening injury, particularly cardiovascular injury. However, patients with isolated sternal fractures and otherwise negative workup (including chest CT, echocardiogram, cardiac US, and cardiac enzymes at the time of
48­51 presentation and  hours afterward) can safely be discharged home. Current experience with sternal fractures as a result of motor vehicle crashes
 notes a .5% incidence of cardiac dysrhythmias requiring treatment and a mortality rate of <1%. Such data suggest that sternal fractures are not an indicator of significant blunt myocardial injury. Patients with sternal fractures presenting with normal vital signs and an initial normal ECG should have
,54 a repeat ECG in  hours and, if unchanged, require no further workup for cardiac injury.
SYSTEMIC AIR EMBOLISM
Systemic air embolism is an acute complication of severe chest trauma and presents with disastrous circulatory and cerebral complications. Patients with penetrating chest wounds who require positive­pressure ventilation are at risk for developing air embolus. High ventilatory pressures, especially
>50 cm H O, may force air from an injured bronchus into an adjacent injured vessel. Air embolus may lead to severe dysrhythmias or CNS deficits.

Patients presenting with hemoptysis in the setting of penetrating chest trauma are at particular risk for this serious complication.
If systemic air embolism is suspected or diagnosed, place the patient in a flat supine position with 100% oxygen applied, which may decrease air bubble size by displacing nitrogen and promoting resorption of the embolus. There is no evidence to support the theoretical benefit of the
Trendelenburg (head down) position in arterial air embolism. Hyperbaric oxygen therapy, if available, helps to decrease size and increase resorption of air bubbles. Airway management of patients at risk for systemic air embolism should include maneuvers that can selectively ventilate each lung. In unilateral lung injury, isolating and ventilating the uninjured lung can, in theory, be used to prevent systemic air embolism. In the event of circulatory collapse, treatment begins with cardiopulmonary resuscitation protocols and an immediate thoracotomy to clamp the injured area of lung.
,56
This is followed by air aspiration from the heart and ascending aorta. Open cardiac massage with clamping of the ascending aorta may help push air through the coronary arteries. Initiate cardiopulmonary bypass promptly, if available.
BLAST INJURIES
Blast injuries can result in a variety of thoracic injuries through multiple mechanisms. An explosive blast can damage the chest through primary, secondary, tertiary, and quaternary blast injury patterns. The primary blast injury is due to barotrauma from rapidly increasing then decreasing atmospheric pressure, resulting in compression and shearing injuries in gas­filled structures such as the lung, ears, and bowels. Secondary blast injuries are blunt or penetrating injuries due to materials thrown from the explosive casing. Tertiary injuries are injuries sustained as a result of being thrown from the blast site or due to structural collapse. Quaternary injuries are burns, inhalational injuries, and radiation that can occur as a result of
 the explosion and combustible materials. Suspect occult and ongoing injuries. (See Chapter , “Bomb, Blast, and Crush Injuries.”)
DIAGNOSIS
CHEST RADIOGRAPH
Plain chest radiographs are helpful to screen for abnormal mediastinal contours, hemothorax, pneumothorax, pulmonary contusions, diaphragmatic injury, and osseous trauma. Mark penetrating surface wounds before imaging. Most chest radiographs are initially taken in the supine position at the bedside due to concern for occult spinal cord injuries and to facilitate resuscitation. Chest radiographs frequently underestimate the severity and extent of chest trauma and may fail to detect an injury. Up to 50% of blunt chest trauma patients with normal initial chest radiography
,7,15,16,58 have multiple injuries on CT; however, some of these occult injuries do not change management or outcome. Chest radiograph is obtained to identify findings such as pneumothorax, hemothorax, aortic or great vessel injury, multiple rib fractures, sternal fracture, diaphragmatic rupture, and pulmonary contusions or lacerations. The National Emergency X­Radiography Utilization Study (NEXUS) Chest Rules were developed in a manner similar to NEXUS Cervical Spine Imaging rules to identify patients with blunt chest trauma with very low risk of thoracic injury. The rules were developed and validated in a convenience sample of 9905 patients >14 years old. If all of the NEXUS Chest Rules criteria were absent, chest imaging
(plain radiography or CT) could be omitted (Table 261­3). Patients in this cohort were not evaluated with bedside US, and decision for plain chest radiography or chest CT was left to the discretion of the caring physician. Sensitivity and specificity were .8% and .3%, respectively, for thoracic injury. Only about half of the study group underwent CT, limiting any conclusions about plain radiography versus CT in patients with blunt chest trauma. However, in the majority of patients who have suffered minor trauma, only a single posteroanterior chest radiograph is required; dedicated rib
,60 radiographs rarely provide additional information that would alter clinical management.
TABLE 261­3
National Emergency X­Radiography Utilization Study Rules for Chest Radiography
Blunt trauma in patients >14 y old in whom chest imaging is considered to Presence of  or more criteria: cannot exclude intrathoracic injury and exclude intrathoracic injury obtain chest imaging:
Age >60 y old
Rapid deceleration: fall >20 ft (>6 m); motor vehicle crash >40 mph (>64 km/h)
Chest pain
Intoxication
Abnormal alertness or abnormal mental status
Distracting painful injury
Tenderness to chest wall palpation
US
POCUS can quickly diagnose pneumothorax, hemothorax, and pericardial tamponade as part of the extended FAST examination. In trained hands, US
 has greater sensitivity and equal specificity for detecting hemothorax in patients with chest trauma compared with chest radiography. Likewise, the sensitivity of US for detecting pneumothorax approaches 92%, with near 100% specificity (as compared with 50% to 80% sensitivity and 90% specificity
 ,62 for chest radiographs) ; thus, US appears to have greater “diagnostic performance” than clinical exam and chest radiograph together. US in the

ED can detect occult pneumothorax as accurately as CT. In addition, US has also been found helpful for describing small, medium, or large
 pneumothoraces with good agreement with CT (Figure 261­15). (See Videos: Lung Ultrasound and FAST.)
Video 261­2: Lung Ultrasound
Used with permission from Ashley S. Bean, MD, Gregory R. Snead, MD University of Arkansas for Medical Sciences, Little Rock, Arkansas
Play Video
FIGURE 261­15. Pneumothorax (7.5–10 MHz). Power Doppler is activated and the gain adjusted correctly by comparison with the normal right hemithorax. The patient’s left hemithorax showed a negative pleural sliding sign, no comet tail artifacts, and no power Doppler signal at the pleural interface. The specificity for pneumothorax is improved when an A­line is also visible (arrow). [Reproduced with permission from Ma OJ, Mateer JR, Reardon RF,
Joing S (eds): Emergency Ultrasound, 3rd ed. McGraw­Hill, Inc., 2014. Fig 5­26, p. .]
CT
CT can detect major and occult injuries and identify the need for additional interventions, but may demonstrate incidental findings that require follow­
  up and do not change acute care. CT is more sensitive for detecting pulmonary contusion and hemothorax than plain radiography. For penetrating lung injury, if the clinical condition allows, CT is performed to identify the extent of injury and involvement of the heart or great vessels. CT adds little to
 the evaluation of low­risk patients (fall from standing or sitting) with normal physical examinations.
OTHER DIAGNOSTIC STUDIES
Thoracic trauma often requires a contrast esophagogram to diagnose esophageal injury. Water­soluble contrast is preferred over bariumcontaining contrast in patients with high suspicion for esophageal rupture. Barium swallow imaging has fewer false positives, but may cause mediastinitis if there is leakage of contrast out of the esophagus.
In selected cases, such as in penetrating wounds of the chest or lower neck, bronchoscopy or esophagoscopy may be indicated to exclude an injury to the aerodigestive tract. Such studies may be deferred until the patient is resuscitated and hemodynamically stable.
GENERAL TREATMENT
INITIAL RESUSCITATION
Perform initial resuscitation and airway management according to established principles (see Chapter 254, “Trauma in Adults”). If the patient is making little or no respiratory effort, consider CNS dysfunction due to head trauma, intoxication, or spinal cord injury. In patients with respiratory effort but with little or no air movement, suspect upper airway obstruction. Absent or abnormal breath sounds may indicate flail chest, hemopneumothorax, diaphragmatic injury, or parenchymal lung damage. Although each of these has unique therapies, respiratory distress that is not immediately relieved by specific intervention should prompt intubation and ventilation. Suspect, diagnose, and treat specific life­threatening pulmonary injuries during the primary survey. These include tension pneumothorax, massive hemothorax, and open pneumothorax.
VENTILATORY SUPPORT
The management of chest trauma patients with respiratory instability is challenging. Hypoxia and hypoventilation are two preventable causes of mortality; therefore, maintaining adequate oxygenation and ventilation in the acute chest trauma patient is essential. Early goals while the lungs are still compliant should include pulmonary recruitment, normocapnea, and reversal of associated metabolic acidosis. However, if acute respiratory distress syndrome develops and the lung compliance decreases, or after the patient is out of the acute resuscitative phase, initiate a lung
 protective strategy to decrease barotrauma. See Chapter 29A, “Tracheal Intubation” and Chapter 29B, “Mechanical Ventilation,” for detailed discussion of ventilation parameters. Monitor all trauma patients by continuous noninvasive pulse oximetry to ensure adequate oxygen saturation. In patients with severe chest trauma or respiratory compromise, an arterial blood gas is helpful to monitor metabolic status and adequate oxygenation and ventilation. Metabolic acidosis with insufficient respiratory compensation is an indication for ventilatory support. Ventilatory support is indicated in chest trauma patients who continue to exhibit impaired ventilation despite measures to relieve chest wall pain and evacuate hemopneumothorax
(Table 261­4). Early use of noninvasive ventilation in patients with chest trauma and normal mentation, but no respiratory distress, may prevent
 progression of disease and decrease the need for intubation and intensive care.
TABLE 261­4
Considerations for Early Ventilatory Assistance After Thoracic Trauma
Altered mental status
Hypovolemic shock
Multiple injuries
Multiple blood transfusions
Elderly patient
Preexisting pulmonary disease
Respiratory rate >30–35 breaths/min
Vital capacity <10–15 mL/kg
Negative inspiratory force <25–30 cm H O

NEEDLE DECOMPRESSION
The most traditional approach to needle decompression is to introduce a 14­gauge IV needle and catheter into the pleural space in the midclavicular line just above the rib at the second intercostal space (Figure 261­16). An anterior midclavicular approach is important because this avoids the
67­69 internal mammary vessels that are located approximately  cm lateral to the sternal border and avoids mediastinal vessels. A standard needle and
 catheter, however, may not be long enough for decompression, as the mean chest wall thickness in the United States is .5 cm. A site that is being more commonly used is the fourth to fifth intercostal space at the anterior axillary line, which is the shortest distance from the skin
 to the pleura. A rush of air exiting the pleural space may be audible and is diagnostic of a pneumothorax. Needle depression converts the tension pneumothorax into an open pneumothorax; needle decompression is a temporizing measure and should be followed promptly with tube thoracostomy. If the patient’s hemodynamics fail to improve following decompression, consider other causes of hypoperfusion, such as pericardial tamponade.
FIGURE 261­16. Decompression of a tension pneumothorax with a catheter­over­the­needle. A. The catheter­over­the­needle is inserted through the second intercostal space and into the pleural cavity. B. The catheter is advanced while the needle is removed. [Reproduced with permission from Reichman EF
(ed): Emergency Medicine Procedures, 2nd ed. © 2013. McGraw­Hill Education, New York, NY. Fig 38­2A&B.]
TUBE THORACOSTOMY
Evacuate large hemothoraces or hemopneumothoraces as rapidly as possible to decrease their negative effects on ventilation and perfusion. Doublecheck clinical and radiographic findings to ensure placement of the chest tube is on the correct side of the patient. Historically, a 24F or 28F (8.0 or .3 mm) chest tube was recommended for a simple pneumothorax and a >32F (>10.7 mm) chest tube for a suspected hemothorax. Multiple studies suggest
,71 there are no differences in efficacy of drainage, complication rate, pain, or need for additional procedures when using small or large chest tubes.
(See Video: Chest Tube Insertion.)
Perform tube thoracostomy for treatment of traumatic pneumothorax or hemothorax in the anterior axillary line at the level of the nipple in men or inframammary crease in women (corresponding to the fifth intercostal space) just behind the lateral edge of the pectoralis major.
Make an oblique skin incision at least  to  cm below the interspace through which the tube will be placed. Insert a large clamp through the skin incision and into the muscles in the next higher intercostal space, just above the rib, thus avoiding the neurovascular bundle (Figure 261­17). The resulting oblique tunnel through the subcutaneous tissue and intercostal muscles usually closes promptly after the chest tube is removed, thereby reducing the chances of recurrent pneumothorax.
FIGURE 261­17. Chest tube insertion. The clamp is inserted through the incision and is tunneled up to the next intercostal space.
Once the clamp is pushed through the internal intercostal fascia, open it to enlarge the hole to at least .0 cm. Insert a finger along the top of the clamp through the hole to verify the position within the thorax and to verify that the lung is not adhering to the chest wall (Figure 261­18).
FIGURE 261­18. Chest tube insertion. Using the finger as a guide, place the tip of the clamp into the pleural cavity just above the rib to avoid intercostal vessels and nerves.
Advance the tube at least until the last side hole is .5 to .0 cm (1 to  inches) inside the chest wall. For a pneumothorax, direct the tube toward the apex, away from the hilum and mediastinum. For a hemothorax, direct the tube posteriorly and laterally. However, do not reposition any tube position that functions effectively unless indicated by abnormal or suboptimal placement identified on the chest radiograph. In general, do not clamp the chest tube. Any continuing air leakage can rapidly collapse the lung or cause a tension pneumothorax. Importantly, loss of vital signs and clinical deterioration after chest tube placement may indicate exsanguinating injury and loss of the protective vascular tamponade effect as the hemothorax is evacuated. In this circumstance, clamp the chest tube and transport the patient directly to the operating room for an emergency thoracotomy.
Classically, the open end of the tube was attached to a combination fluid­collection water­seal suction device, with  to  cm H O of suction. Recent
 studies have called into question the need for suction as opposed to a water seal without suction in patients with uncomplicated traumatic
 pneumothoraces and hemothoraces. If a significant hemothorax is known to be present or if a large amount of blood starts to drain immediately, consider collecting the blood in a heparinized autotransfusion device so that it can be returned to the patient.
Check the intrathoracic position of the chest tube and of its last hole and the amount of air or fluid remaining in the pleural cavity with a portable chest radiograph as soon as possible after the tube is inserted. Serial chest auscultation, chest radiographs, and careful recording of the volume of blood loss and the amount of air leakage are important guides to the functioning of chest tubes. If a chest tube becomes blocked and a significant pneumothorax or hemothorax is still present, replace the tube or place a second chest tube on the affected side. Irrigating an occluded chest tube or passing a Fogarty catheter through it in an effort to reestablish its patency is not advised.
Leave chest tubes in place on suction for at least  hours after all air leaks have stopped (if placed for a simple pneumothorax) or until drainage is
 serous and <200 mL/24 h (if placed for hemothorax). However, in intubated patients, maintain chest tubes throughout mechanical ventilation to prevent sudden development of a new pneumothorax.
The use of prophylactic broad­spectrum antibiotics in patients who require tube thoracostomy for a traumatic hemothorax or pneumothorax remains
74­76 controversial. Whether or not antibiotics are given, adhere to protocols for the placement, maintenance, and early removal of chest tubes to decrease the risk of infection.


## Page 32

32. Luchette FA, Radafshar SM, Kaiser R, et al: Prospective evaluation of epidural versus intrapleural catheters for analgesia in chest wall trauma. J
Trauma 36: 865, 1994. [PubMed: 8015010]
. Parris R: Towards evidence based emergency medicine: best BETs from the Manchester Royal Infirmary. Epidural analgesia/anaesthesia versus systemic intravenous opioid analgesia in the management of blunt thoracic trauma. Emerg Med J 24: 848, 2007. [PubMed: 18029522]
. Rostas JW, Lively TB, Brevard SB, Simmons JD, Frotan MA, Gonzalez RP: Rib fractures and their association with solid organ injury: higher rib fractures have greater significance for solid organ injury screening. Am J Surg 213: , 2017. [PubMed: 27663650]
. Dehghan N, de Mestral C, McKee MD, Schemitsch EH, Nathens A: Flail chest injuries: a review of outcomes and treatment practices from the
National Trauma Data Bank. J Trauma Acute Care Surg 76: , 2014. [PubMed: 24458051]
. Battle CE, Evans PA: Predictors of mortality in patients with flail chest: a systematic review. Emerg Med J 32: 961, 2015. [PubMed: 26188067]
. Battle CE, Evans PA: Predictors of mortality in patients with flail chest: a systematic review. Emerg Med J 32: , 2015. [PubMed: 26188067]
. Swart E, Laratta J, Slobegean G, Mehta S: Operative treatment of rib fractures in flail chest injuries: a meta­analysis and cost­effectiveness analysis. J Orthop Trauma 31: , 2017. [PubMed: 27984449]
. Unsworth A, Curtis K, Asha SE: Treatments for blunt chest trauma and their impact on patient outcomes and health service delivery. Scand J
Trauma Resusc Emerg Med 23: , 2015. [PubMed: 25887859]
. Schuurmans J, Goslings JC, Schepers T: Operative management versus non­operative management of rib fractures in flail chest injuries: a systematic review. Eur J Trauma Emerg Surg 43: , 2017. [PubMed: 27572897]
. Kocher GJ, Sharafi S, Azenha LF, Schmid RA: Chest wall stabilization in ventilator­dependent traumatic flail chest patients: who benefits? Eur J
University of Pittsburgh
Cardiothorac Surg 51: , 2017. [PubMed: 28007867] Access Provided by:
. Swart E, Laratta J, Slobogean G, Mehta S: Operative treatment of rib fractures in flail chest injuries: a meta­analysis and cost­effectiveness analysis. J Orthop Trauma 31: , 2017. [PubMed: 27984449]
. Marasco SF, Davies AR, Cooper J, et al: Prospective randomized controlled trial of operative rib fixation in traumatic flail chest. J Am Coll Surg
216: 924, 2013. [PubMed: 23415550]
. Doben AR, Ericksson EA, Denlinger CE, et al: Surgical rib fixation for flail chest deformity improves liberation from mechanical ventilation. J Crit
Care 29: 139, 2014. [PubMed: 24075300]
. Celik B, Sahin E, Nadir A: Sternum fractures and effects of associated injuries. Thorac Cardiovasc Surg 47: 468, 2009. [PubMed: 20013620]
. Jin W, Yang DM, Kim HC, Ryu KN: Diagnostic values of sonography for assessment of sternal fractures compared with conventional radiography and bone scans. J Ultrasound Med 25: 1263, 2006. [PubMed: 16998098]
. You JS, Chung YE, Kim D, et al: Role of sonography in the emergency room to diagnose sternal fractures. J Clin Ultrasound 38: 135, 2010. [PubMed: 20127877]
. Kouritas VK, Zisis C, Vahlas K, et al: Isolated sternal fractures created on an outpatient basis. Am J Emerg Med 31: 227, 2013. [PubMed: 22867815]
. Yeh DD, Hwabejire JO, DeMoya MA, Alam HB, King DR, Velmahos GC: Sternal fracture: an analysis of the National Trauma Data Bank. J Surg Res
186: , 2014. [PubMed: 24135374]
. Odell DD, Peleg K, Givon A, et al: Sternal fracture: isolated lesion versus polytrauma from associated extrasternal injuries—analysis of ,867 cases.
J Trauma Acute Care Surg 75: , 2013. [PubMed: 24089115]
. Perez MR, Rodriguez RM, Baumann BM, et al: Sternal fracture in the age of pan­scan. Injury 46: , 2015. [PubMed: 25817167]
. Brookes JG, Dunn RJ, Rogers IR: Sternal fractures: a retrospective analysis of 272 cases. J Trauma 35: , 1993. [PubMed: 8331712]
. Wright SW: Myth of the dangerous sternal fracture. Ann Emerg Med 22: 1589, 1993. [PubMed: 8214842]
. Chiu WC, D’Amelio LF, Hammond JS: Sternal fractures in blunt chest trauma: a practical algorithm for management. Am J Emerg Med 15: 252,
1997. [PubMed: 9148979]
. Hunt PA, Greaves I, Owens WA: Emergency thoracotomy in thoracic trauma—a review. Injury 37: , 2006. [PubMed: 16410079]
. Cothren CC, Moore EE: Emergency department thoracotomy for the critically injured patient: objectives, indications, and outcomes. World J Emerg
Surg 1: , 2006. [PubMed: 16759407]

. Singh AK, Ditkofsky NG, York JD, et al: Blast injuries: from improvised explosive device blasts to the Boston Marathon bombing. Radiographics 36:
Chapter 261: Pulmonary Trauma, Yvonne L. Wang; David Jones 
. Terms of Use * Privacy Policy * Notice * Accessibility
[PubMed: 26761543]
. Barrios C, Malinoski D, Dolich M, et al: Utility of thoracic computed tomography after blunt trauma: when is chest radiograph enough? Am Surg
75: 966, 2009. [PubMed: 19886146]
. Henry TS, Kirsch J, Kanne JP, et al: ACR appropriateness criteria rib fractures. J Thorac Imaging 29: , 2014. [PubMed: 25340388]
. Shuaib W, Vijayasarathi A, Tiwana MH, Johnson JO, Maddu KK, Khosa F: The diagnostic utility of rib series in assessing rib fractures. Emerg
Radiol 21: , 2014. [PubMed: 24297110]
. McEwan K, Thompson P: Ultrasound to detect haemothorax after chest injury. Emerg Med J 24: 581, 2007. [PubMed: 17652688]
. Alrajab S, Youssef AM, Akkus NI, Caldito G: Pleural ultrasonography versus chest radiography for the diagnosis of pneumothorax: review of the literature and meta­analysis. Crit Care 17: 208, 2013. [PubMed: 24060427]
. Soldati G, Testa A, Sher S, et al: Occult traumatic pneumothorax: diagnostic accuracy of lung ultrasonography in the emergency department.
Chest 133: 204, 2008. [PubMed: 17925411]
. Lavingia KS, Collins JN, Soult MC, Terzian WH, Weireter LI, Britt LD: Torso computed tomography can be bypassed after thorough trauma bay examination of patients who fall from standing. Am Surg 81: 798, 2015. [PubMed: 26215242]
. Hardcastle TC, Muckart DJJ, Maier RV: Ventilation in trauma patients: the first 24h is different! World J Surg 41: 1153, 2017. [PubMed: 27177646]
. Duggal A, Perez P, Golan E, Tremblay L, Sinuff T: Safety and efficacy of noninvasive ventilation in patients with blunt chest trauma: a systematic review. Crit Care 17: 142, 2013. [PubMed: 23876230]
. Wax DB, Leibowitz AB: Radiologic assessment of potential sites for needle decompression of a tension pneumothorax. Anesth Anal 105: 1385,
2007. [PubMed: 17951170]
. Sanchez LD, Straszewski S, Saghir A, et al: Anterior versus lateral needle decompression of tension pneumothorax: comparison by computer tomography chest wall measurement. Acad Emerg Med 18: 1553, 2011. [PubMed: 21951681]
. Harche H, Mabry RL, Mazuchowski EL: Needle thoracentesis decompression: observations from postmortem computed tomography and autopsy.
J Spec Oper Med 13: , 2013. [PubMed: 24227562]
. Inaba K, Lustenberger T, Recinos G, et al: Does size matter? A prospective analysis of 28­32 versus 36­40 French chest tube size in trauma. J
Trauma Acute Care Surg 72: 422, 2012. [PubMed: 22327984]
. Kulvatunyou N, Erickson L, Vijayasekaran A, et al: Randomized clinical trial of pigtail catheter versus chest tube in injured patients with uncomplicated traumatic pneumothorax. Br J Surg 101: , 2014. [PubMed: 24375295]
. Morales CG, Mejia C, Roldan LA, Saldarriaga MF, Duque AF: Negative pleural suction in thoracic trauma patients: a randomized controlled trial. J
Trauma Acute Care Surg 77: 251, 2014. [PubMed: 25058250]
. Younes RN, Gross JL, Aguiar S, et al: When to remove a chest tube? A randomized study with subsequent prospective consecutive validation. J Am
Coll Surg 195: 658, 2002. [PubMed: 12437253]
. Bosman A, de Jong MB, Debeij J, et al: Systematic review and meta­analysis of antibiotic prophylaxis to prevent infections from chest drains in blunt and penetrating thoracic injuries. Br J Surg 99: 506, 2012. [PubMed: 22139619]
. Moore FO, Duane TM, Hu CK, et al: Presumptive antibiotic use in tube thoracostomy for traumatic hemopneumothorax: an Eastern Association for the Surgery of Trauma practice management guideline. J Trauma Acute Care Surg 73: S341, 2012. [PubMed: 23114491]
. Bradley M, Okove O, DuBose J, et al: Risk factors for post­traumatic pneumonia in patients with retained haemothorax: results of a prospective, observational AAST study. Injury 4419: 1159, 2013. [PubMed: 23433600]

