University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 28: Noninvasive Airway Management and Supraglottic Airways
Jestin N. Carlson; Henry E. Wang
INTRODUCTION
Airway support is necessary in many acutely ill and injured patients. Optimal strategies assist with airway patency, oxygen delivery, and carbon dioxide excretion. Many classify airway management techniques into two categories: noninvasive (passive oxygenation, bag­valve­mask ventilation, and noninvasive positive­pressure ventilation) and invasive (supraglottic airways, endotracheal intubation, cricothyroidotomy, transcutaneous needle jet ventilation, and tracheostomy). This chapter discusses noninvasive airway management strategies and supraglottic airways. Detailed discussion of invasive airway management strategies is found in Chapter 29A (“Tracheal Intubation”), Chapter  (“Surgical Airways”), and Chapter 113 (“Intubation and Ventilation in Infants and Children”).
Patients may require airway management for a variety of conditions relating to hypoventilation (inadequate carbon dioxide excretion) and hypoxia
(inadequate alveolar oxygen content). Management of these conditions can incorporate multiple airway strategies ranging from passive oxygenation to endotracheal intubation, and the interventions best used may vary over time in the same patient and between patients.
Patients with hypoventilation and hypoxia may have varying symptoms including weakness, fatigue, chest pain, or shortness of breath. Inadequate oxygenation and ventilation can lead to altered mentation, including anxiety, confusion, obtundation, or coma. Patients with respiratory distress may
 have wheezing, stridor, or a silent chest. A subjective gauge of respiratory distress is the patient’s respiratory effort or “work of breathing.” Dyspnea, tachypnea, hyperpnea, or hypopnea; accessory muscle use; and cyanosis are signs of increased work of breathing.
There are two types of respiratory failure. Type  respiratory failure has hypoxia without hypercapnia. Type  respiratory failure may be the result of conditions that affect oxygenation but not necessarily ventilation (e.g., pneumonia, pulmonary embolism). Patients with type  respiratory failure require actions that optimize oxygenation. Type  respiratory failure has hypoxia with hypercapnia. Type  respiratory failure is often the result of conditions that affect ventilation (e.g., chronic obstructive pulmonary disease). Treatment of type  failure requires not only optimizing oxygenation but also supporting ventilation.
ASSESSMENT OF THE AIRWAY AND VENTILATORY EFFORT
The decision to initiate airway support is often based on the patient’s clinical condition. Do not delay management efforts for laboratory testing or other studies, although these can help guide treatment.
First, assess every patient for airway obstruction, which can be functional (e.g., unconscious patient) or mechanical (e.g., foreign body). The ability to spontaneously swallow and speak provides a basic indication of airway patency, and the absence of this ability is a potential sign of obstruction. Other potential signs of airway obstruction include anxiety, wheezing or stridor, and coughing. Many conditions can cause airway obstruction (Table 28­1).
Table 28­1
Causes of Upper Airway Obstruction
Congenital/Genetic Infectious Medical Trauma/Tumor
Large tonsils Tonsillitis Cystic fibrosis Laryngeal trauma
Macroglossia Peritonsillar abscess Angioedema Hematoma/masses
Micrognathia Pretracheal abscess Laryngospasm Smoke inhalation

Chapter 28: Noninvasive Airway Management and Supraglottic Airways, Jestin N. Carlson; Henry E. Wang 
©2025N MecckG mraaswse Hs ill. All Rights ResEeprvigelodt.t i t iTserms of Use * Privacy Policy * NoticInef l * a mAmccaetosrsyibility Thermal injuries
Large adenoids Laryngitis/respiratory syncytial virus Airway muscle relaxation Foreign body/hemorrhage
Ludwig angina
Retropharyngeal abscess
Some obstructions, such as foreign bodies or masses, are subglottic (below the vocal cords).
Laryngospasm is obstructive closure of the glottis by constriction of laryngeal muscles. Laryngospasm may result from stimulation of the upper airway receptors on the tongue, palate, and oropharynx. Other causes include chemical irritation; secretions; blood, water, and vomitus in the upper airway; and traction on the pelvic/abdominal viscera. Laryngospasm can persist after the causative stimulus departs.
PREDICTING THE DIFFICULT AIRWAY AND PREPARATION FOR AIRWAY MANAGEMENT
Assess and anticipate challenges with airway management before any attempts to intervene. Table 28­2 lists some factors that may complicate
 noninvasive airway management.
Table 28­2
Predictors of Difficult Noninvasive Airway Management Techniques2
BVM ventilation
M Mask seal Beard, trauma, or other situations that may cause BVM to not seal
O Obesity or Obstruction
A Age Age >55 y
N No teeth
S Stiff lungs or chest wall
Supraglottic airway
R Restricted mouth opening
O Obesity or Obstruction
D Disrupted or Distorted airway
S Stiff lungs or cervical spine
Abbreviation: BVM = bag­valve­mask ventilation.
PATIENT POSITIONING
The first step in airway management is to optimize patient positioning to facilitate airway patency and subsequent airway management efforts.
Upper airway obstruction occurs in the unconscious patient as the intrinsic muscles of the neck and upper airway relax, causing the epiglottis to
 obstruct the laryngeal inlet. Although the tongue displaces posteriorly during anesthesia in supine patients, it may not always occlude the pharynx.
The first relief step in upper airway obstructions is extension of the neck with anterior displacement of the mandible. This maneuver moves the hyoid bone anteriorly and lifts the epiglottis away from the laryngeal inlet. Forward flexion of the neck in addition to extension (“sniffing” position) may relieve upper airway obstructions and requires less neck extension. To achieve, place a folded towel (not rolled) or foam rubber device underneath the patient’s occiput. Do not attempt neck extension or sniffing positioning in patients when there is concern for cervical spine injury.
OXYGENATION
Provide supplemental oxygen to all critically ill patients requiring airway management. The method of oxygenation used depends on the patient’s clinical condition and oxygen requirement (Table 16­1 and Table 28­3). Even if the patient is apneic, providing supplemental oxygenation with nasal
 cannulae can extend the time to hypoxia and hypoxemia, allowing providers additional time to prepare for or attempt airway maneuvers. Many techniques augment oxygen delivery. Traditional approaches include nasal cannula and simple facemasks. Table 28­3 summarizes the oxygen delivery rates for simple methods. See Table 16­1 for more options. Traditional oxygen delivery methods such as nasal cannula and simple facemasks deliver variable and lower inspired oxygen amounts, which may not be adequate for select patients in severe respiratory distress. High­flow oxygenation delivered through a high­flow nasal cannula provides humidified, heated oxygen at flow rates up to  L/min, 5providing positive pressure while decreasing the work of breathing.,76 High­flow nasal cannula is best used in patients with hypoxia and an intact respiratory drive; it is an alternative to invasive ventilation in ED patients with hypoxia (oxygen saturation  breaths/min, while excluding patients with bullous lung disease and pneumothoraces.8 Another option is flush rate oxygenation, where the wall oxygen unit is turned past  L/min to maximum flow rates of  to 
L/min.,109 Both high­flow nasal cannula and flush rate oxygenation can bridge to other ventilation methods. High­flow nasal cannula may improve mortality rates in patients with nonhypercapnic, acute hypoxemic respiratory failure compared to noninvasive positive­pressure ventilation and
 conventional supplemental oxygen.
Table 28­3
Simple Oxygen Delivery Methods
Oxygen Flow FIO Delivered

Nasal cannulae 2–6 L/min 24%–44% approximate
Simple facemask 5–10 L/min 35%–50% approximate
Non­rebreather mask 10–15 L/min Near 100% mask fit essential
Abbreviation: FIO = fraction of inspired oxygen.

AIRWAY EQUIPMENT
Having key equipment at the bedside is a fundamental requirement for optimal airway management. Table 28­4 provides a model list of equipment.
Table 28­4
Sample List of Equipment for Noninvasive Airway Management
Oxygen source and tubing
Tongue blade
Bag­valve­mask device
Clear facemasks—various sizes and shapes
Oropharyngeal airways—small, medium, large
Nasopharyngeal airways—small, medium, large
Suction catheter
Suction source
Pulse oximetry
End­tidal carbon dioxide detector
Syringes
Magill forceps
Water­soluble lubricant or anesthetic jelly
CPAP/BiPAP mask and machine
Supraglottic airways: laryngeal mask airway, intubating laryngeal mask airway, i­gel® (Intersurgical Inc., Liverpool, NY), King LT® (King Systems,
Noblesville, IN)
Backup equipment in the case of unsuccessful NIPPV
∗†
∗
See Chapter 29A, “Tracheal Intubation” and Chapter 29B, “Mechanical Ventilation.”
†See Chapter , “Surgical Airways.”
Abbreviations: BiPAP = bilevel positive airway pressure; CPAP = continuous positive airway pressure; NIPPV = noninvasive positive­pressure ventilation.
Oropharyngeal (Oral) Airway
An oropharyngeal or oral airway (Figure 28­1) is a curved, rigid instrument used to prevent the base of the tongue from occluding the hypopharynx.
Use only in a comatose or deeply obtunded patient without a gag reflex. Properly sized oral airways should reach from the corner of the mouth to the angle of the mandible. Place an oral airway with the concave portion of the airway cephalad and rotate 180 degrees after passing the tongue.
Alternatively, orient the concaved portion horizontal and rotate  degrees, following the curvature of the tongue, after insertion.
FIGURE 28­1
An oral airway.
Nasopharyngeal (Nasal) Airway
A nasopharyngeal or nasal airway (Figure 28­2) is pliable and inserted into the nostril, displacing the soft palate and posterior tongue. Nasal airways are helpful in patients with an intact gag reflex absent any midface trauma. Properly sized nasal airways reach from the corner of the mouth to the angle of the mandible. After lubrication, insert the nasopharyngeal airway in the most patent nostril and horizontal to the palate with the bevel oriented toward the nasal septum; insert parallel to the nasal floor, not pointing cephalad.
FIGURE 28­2
A nasal airway.
BAG­VALVE MASK
Bag­valve masks (Figure 28­3) contain a self­inflating insufflation device coupled with a facemask and a valve to prevent reinhalation of exhaled air.
Although typically used with supplemental oxygen, the bag­valve mask can aid even when used with room air. Most bag­valve­mask systems deliver approximately 75% oxygen with optimal use. A demand valve attached to the reservoir port of the ventilation bag may help to deliver a higher
 concentration of oxygen. Adequate oxygenation and ventilation with a bag­valve mask requires upper airway patency and a good facemask seal, which may be difficult in patients with facial trauma, facial hair, or anatomic anomalies or in those who are edentulous.
FIGURE 28­3
Bag­valve mask.
Bag­valve­mask ventilation can be done using one­ or two­person techniques. Two­person techniques deliver greater tidal volumes than one­person
 techniques and are preferred.
With the one­person approach, the rescuer uses one hand to grasp and seal the mask and the other hand to squeeze the bag­valve­mask reservoir bag.
A common mask­sealing technique is to grasp the mask with the thumb and index finger in a “C” shape while placing the third, fourth, and fifth digits in an “E” shape to lift the mandible. During mask ventilation, be careful to keep the fingers on the mandible, not compressing the soft tissue beneath (and hence compressing the airway) (Figure 28­4A).
In the two­operator approach, one rescuer seals the facemask using both hands, while the other squeezes the reservoir bag. The rescuer sealing the mask may use the same “E­C” approach, but with both hands applied to the mask (Figure 28­4B). In an alternate modified two­handed technique, the practitioner places the thenar eminence and thumb of each hand on the mask while the remaining digits grasp the mandible (Figure 28­4C). Both
 two­handed techniques provide similar tidal volumes.
FIGURE 28­4
A. One­person bag­valve­mask ventilation. B. Two­handed mask seal. C. Modified two­handed mask seal.
NONINVASIVE POSITIVE­PRESSURE VENTILATION
Noninvasive positive­pressure ventilation (NIPPV) provides positive­pressure airway support through a face or nasal mask without the use of an endotracheal tube or other airway device. In adults, NIPPV includes continuous positive airway pressure (CPAP) and bilevel positive airway pressure
(BiPAP).
NIPPV helps to augment spontaneous respirations. Ideal patients for NIPPV are cooperative, have protective airway reflexes, and have intact ventilatory efforts. NIPPV is not appropriate in patients who have absent or agonal respiratory effort, impaired or absent gag reflex, altered mental status, severe maxillofacial trauma, potential basilar skull fracture, life­threatening epistaxis, or bullous lung disease. Use NIPPV with caution in hypotensive patients because any volume depletion effect on cardiac output can be worsened from the positive pressure, triggering more hypotension (Table 28­5).
Table 28­5
Advantages and Adverse Effects of Noninvasive Positive­Pressure Ventilation
Advantages Disadvantages
Reduces work of breathing Air trapping
Improves pulmonary compliance Increased intrathoracic pressure leading to decreased venous return, afterload, and cardiac
Recruits atelectatic alveoli output, and hypotension
Less sedation Pulmonary barotrauma leading to pneumothorax
Shorter hospital stay Respiratory alkalosis
Decreased rate of intubation without risks of Abdominal compartment syndrome endotracheal intubation
,15
NIPPV reduces work of breathing through multiple mechanisms. NIPPV improves pulmonary compliance and recruits and stabilizes collapsed
 alveoli, improving alveoli aeration and ventilation­perfusion mismatches. NIPPV increases both intrathoracic and hydrostatic pressure, shifting pulmonary edema into the vasculature. Increased intrathoracic pressure can also decrease venous return, transmural pressure, and afterload, leading to improved cardiac function. NIPPV also increases tidal volume and minute ventilation, leading to increased PaO and reduction in PaCO . NIPPV
  reduces work of breathing by 60% and dyspnea scores by 29% to 67%, while improving inspiratory muscle endurance by 14% to 95% over spontaneous
 16–18 respirations. The effect of NIPPV on forced expiratory volume and forced vital capacity is unclear.
CPAP delivers a constant positive pressure throughout the respiratory cycle. BiPAP provides different levels of positive airway pressure during inspiration (inspiratory positive airway pressure [IPAP]) and expiration (expiratory positive airway pressure[EPAP]). Although the terms expiratory positive airway pressure and positive end­expiratory pressure are often used interchangeably, positive end­expiratory pressure is specific to the end of the respiratory cycle, whereas expiratory positive airway pressure refers to the pressure administered via the BiPAP machine during the entire expiratory phase. Both CPAP and BiPAP are options in a variety of patient populations, with limited data directly comparing the two methods.
Be aware that different NIPPV devices exist with differing operating mechanisms. Many standard ventilators can provide NIPPV, although in these devices, the inspiratory and expiratory pressures are additive. For example, if the EPAP is set at  cm H O and the IPAP is set at  cm H O, the total
  delivered IPAP may be  cm H O (5 + 15). There are stand­alone NIPPV units that can provide both CPAP and BiPAP, allowing for independent setting of
 inspiratory and expiratory pressures. In this example, if the EPAP is set at  cm H O and the IPAP is set at  cm H O, the total delivered IPAP will be 
  cm H O. Specialized adapters that connect directly to oxygen tanks and wall­mounted oxygen units may provide CPAP for a brief period of time. These
 devices have a limited range of settings and are best used on a temporary basis.
INITIATING AND TITRATING NIPPV
Select the mask for NIPPV to create a tight seal while preserving patient comfort. Base the initial settings on the patient’s condition and type of respiratory failure. Typical starting settings for CPAP are  to  cm H O. Typical starting settings for BiPAP include “spontaneous” mode with IPAP set
 to  to  cm H O and expiratory positive airway pressure set to  to  cm H O. Be cautious when using NIPPV at pressures >15 cm H O because this may
   increase the intrathoracic pressure, leading to barotrauma along with decreased venous return, decreased preload and afterload, and eventually decreased cardiac output.
NIPPV requires frequent assessment for work of breathing, heart rate, respiratory rate, oxygen saturation, and blood pressure. Arterial blood gas analysis aids NIPPV titration but is not mandatory. Expiratory positive airway pressure can help open and stabilize collapsed alveoli and reverse hypoxemia. In patients in whom ventilation is an issue, adjust the IPAP settings to help decrease the work of breathing and improve ventilation.
If the patient is not tolerating NIPPV, look first for an air leak. NIPPV is a flow­limited, pressure support system, and therefore, leaks prevent the machine from reaching the preprogrammed flow rate for a set pressure. As a result, the inspiratory time may be prolonged, making each breath cycle less comfortable for the patient. Potential solutions for air leaks include programming the machine to limit the inspiratory time or selecting alternative
 modes of ventilation including proportional assist ventilation. Proportional assist ventilation is a form of synchronized ventilatory support where the
NIPPV machine generates pressure in proportion to the patient’s instantaneous effort such that as the patient generates a greater inspiratory effort, the machine generates greater IPAP. This allows the machine to adjust to air leaks that may impair ventilation and oxygenation with other modes (CPAP
 and BiPAP) and is better tolerated by some patients. If the patient is not improving with NIPPV, consider endotracheal intubation and mechanical ventilation.
NIPPV Applications
The most common use of NIPPV is for cardiogenic pulmonary edema; NIPPV may reduce rates of endotracheal intubation, hospital length of stay,
20–27  and mortality. In patients with chronic obstructive pulmonary disease, NIPPV is helpful in those with respiratory acidosis. NIPPV may
 benefit patients with moderate to severe asthma exacerbations, although data on effectiveness are limited. Because of the bronchospastic nature of chronic obstructive pulmonary disease and asthma, be vigilant for air trapping and subsequent barotrauma when using NIPPV.
30–32
NIPPV may reduce the rate of intubation and in­hospital death in patients with pneumonia. Exercise caution in this patient group because hypovolemia may coexist, with resultant NIPPV­induced hypotension.
33–35
There are reports of NIPPV use in blunt chest wall trauma, including flail chest. NIPPV is also reported in burn patients. Do not use NIPPV in
,37 patients with suspected or confirmed high esophageal or tracheal injuries, maxillofacial or basilar skull fractures, or severe facial burns.
Prehospital NIPPV
Prehospital NIPPV in patients with cardiogenic pulmonary edema and chronic obstructive pulmonary disease decreases the rate of subsequent
38–41 intubation and mortality. When such patients arrive in the ED, assess the response to NIPPV and determine whether to discontinue NIPPV, adjust the NIPPV settings, or change to invasive airway strategies.
NIPPV Complications
Complications of NIPPV include difficulty with mask seal, patient discomfort, aspiration (rare), air trapping, pulmonary barotrauma including pneumothorax, and increased intrathoracic pressure leading to decreased cardiac output and hypotension. Monitor patients carefully to determine

NIPPV effectiveness and to identify the need to further secure the airway with intubation. Minimize aspiration risk by proper patient selection ; make sure selected NIPPV patients have a gag reflex and do not have altered mental status. Gastric distention and increased intragastric pressure can lead to abdominal compartment syndrome, resulting in oliguria, hypoxia, hypercarbia, high peak inspiratory pressures, and even renal failure. A nasogastric
 tube can decompress the stomach and relieve this syndrome. Although uncommon, evaluate patients frequently to identify any of these complications early.
Occasionally, patients develop anxiety and agitation during NIPPV treatment due to the claustrophobic feeling of the mask or the discomfort of positive­pressure ventilation. Anxiety and agitation can increase the work of breathing and result in NIPPV asynchrony. Although often relieved with encouragement and verbal support, this may require sedatives or anxiolytics. There are limited data examining sedation during NIPPV, and choices are
,44 typically based on physician preference. Avoid agents or doses that cause excess sedation or respiratory depression. Dexmedetomidine, a centrally
 acting α agent, can provide sedation without decreasing respiratory drive, but its expense and availability limit general use. Benzodiazepines and

,44,45 opiates are commonly used but can be difficult to titrate and may cause respiratory depression. Haloperidol in low doses may aid anxiolysis with
 less respiratory depression than opioids or benzodiazepines. Ketamine decreases airway resistance and improves pulmonary function without
 respiratory depression. Patients should be closely monitored as ketamine can cause hypersalivation.
SUPRAGLOTTIC AIRWAYS
Supraglottic airways (SGAs) are devices placed in the oropharynx, allowing for oxygenation and ventilation without the visualized or surgical insertion of a tube into the trachea. SGAs are often a bridge to endotracheal intubation or a rescue device after unsuccessful intubation efforts. Although SGAs provide adequate oxygenation and ventilation for short periods of time, they are not used for prolonged ventilation. SGA should not be used in any
 patient needing high inspiratory pressures (e.g., chronic obstructive pulmonary disease) given seal issues and the potential for leaks to occur. In the out­of­hospital setting, these devices improve survival after cardiac arrest compared to endotracheal intubation, although their impact in the ED is less
 clear.
SGAs are most often placed in apneic, unconscious patients; their large cuffs can cause gagging and discomfort in awake patients. Another option is
 use after deploying a rapid­sequence induction medication regimen. After inserting, confirm proper position of any SGA with end­tidal carbon
50–52 dioxide and secure it with tape or commercial holders. A number of SGAs are commercially available (Figure 28­5A–D).
FIGURE 28­5
®
Esophageal airways. A. i­Gel. B. King LT. C. Laryngeal Mask Airway. D. Shiley esophageal tracheal airway. [Copyright ©2014 Covidien. All rights reserved. Used with permission of Covidien, Boulder, CO.]
I­GEL
®
The i­Gel (Intersurgical Inc., Liverpool, NY) (Figure 28­5A) has a soft, gel­like cuff that seals the perilaryngeal structures without inflation. This limits tissue compression caused by devices with large cuffs. Lubricate the gel­like cuff prior to insertion, and then advance the device into the posterior pharynx until resistance is met and the lips align with the lip line on the i­Gel. Data from operating room use suggest that complications of i­Gel use are
 infrequent but most commonly include laryngospasm and sore throat; there are rare reports of vasovagal asystole and glottic hematoma. The i­Gel is available in various sizes for patients from  to >90 kg.
®
KING LARYNGEAL TUBE (KING LT )
®
The King LT (King Systems, Noblesville, IN) (Figure 28­5B) is a single lumen tube with a proximal cuff that seals the posterior oropharynx while a distal cuff occludes the esophagus. The King LT is placed blindly (that is, without seeing beyond the mouth opening) into the oropharynx until the lip aligns with the device lip line. The balloon is then inflated to a pressure of  cm H O. After placement, the provider may need to withdraw the King LT slightly
 to allow it to fully occlude the oropharynx. The King LT resides in the esophagus >95% of the time, allowing ventilation of the trachea through the
 multiple fenestrations between the proximal pharyngeal and distal esophageal cuffs. Complications with the King LT include tongue engorgement
 whereby the proximal balloon can impair venous drainage of the tongue. Removing the King LT will relieve this condition. The King LT is available in several sizes depending on the patient’s height:  to  feet, size  (yellow);  to  feet, size  (red); and >6 feet, size  (purple).
®
LARYNGEAL MASK AIRWAY (LMA )
®
The Laryngeal Mask Airway (LMA ; Teleflex, Research Triangle Park, NC; Figure 28­5C) is another SGA placed blindly through the mouth; it occludes the structures around the larynx. The LMA consists of a single cuff inflated with  to  mL of air. To insert the LMA, place a gloved index finger into the oropharynx to guide the device into the oropharynx and position the cuff around the larynx. The LMA may be especially useful when the vocal cords
,57 cannot be visualized during intubation attempts and is successfully placed 88% to 100% of the time. There are various models, including an intubating LMA, that allow an endotracheal tube to be passed through the lumen. This permits conversion from an SGA to an endotracheal tube without visualizing the glottis. Complications of the LMA include partial or complete airway obstruction and aspiration of gastric contents, although
 animal data suggest the LMA may prevent aspiration. The LMA is available in several sizes based on the patient’s estimated body weight:  to  kg, size ;  to 100 kg, size ; and >100 kg, size . OTHER SUPRAGLOTTIC AIRWAYS
®
The Shiley esophageal tracheal airway (Covidien, Boulder, CO; Figure 28­5D) is a plastic double­lumen tube that is inserted blindly. It is a predecessor to the King LT and is still used by some EMS agencies. It has a proximal low­pressure cuff that seals the pharyngeal area and a distal cuff that seals the esophagus. After placement, the proximal balloon is inflated with  mL of air while the distal balloon is inflated with  mL of air. During insertion, the device may rest in the esophagus or trachea. To determine the location of the device, first ventilate through the longer blue port; this allows oxygen to be delivered through fenestrations between the proximal and distal balloons. If chest rise is absent, the endotracheal tube cuff is in the trachea; switch to ventilation through the shorter, clear/white port.
®
The CobraPLA (Engineered Medical Systems, Indianapolis, IN) is a cuffed SGA that is inserted blindly similarly to the King LT. The potential advantage of the CobraPLA is that providers can pass an endotracheal tube through the lumen of the device, easing conversion to an endotracheal tube. The
CobraPLA is available in various sizes for patients from .5 to >130 kg.
CONVERTING A SUPRAGLOTTIC AIRWAY TO AN ENDOTRACHEAL TUBE
In general, SGAs have a higher risk of aspiration than cuffed endotracheal tubes, and the large cuffs may cause hypopharyngeal mucosal damage.
Thus, endotracheal tubes are better suited for long­term ventilation. SGAsdo not need to be immediately changed to an endotracheal tube.
The urgency for conversion depends on the condition of the patient, the adequacy of oxygenation and ventilation through the SGA, and the reasons for SGA insertion. Strategies for converting an SGA to an endotracheal tube include the following:
Remove the supraglottic device and perform direct laryngoscopy. If the SGA placement was because of intubation difficulty, removing the SGA and attempting direct laryngoscopy is risky; it is better to choose an alternative technique. If attempting direct visualization to intubate the trachea after SGA removal, use airway adjuncts (e.g., gum elastic bougie, video laryngoscopy) to help make laryngoscopy efforts successful.
Convert the SGA (King LT or i­Gel) with a gum elastic bougie. Insert the gum elastic bougie though the King LT into the trachea and then remove the King LT, leaving the gum elastic bougie in place. Then pass a standard endotracheal tube over the bougie. This is a “blind” exchange, meaning that the operator does not visualize the glottis during the conversion. While this maneuver can be attempted with the standard LMA, it
 often fails. Limited data describe this technique with the i­Gel.
Convert the SGA (i­Gel, King LT, or LMA) with a fiberoptic bronchoscope. Use an intubating catheter (Aintree; Cook Medical, Inc.,
Bloomington, IN), which is similar to a bougie but is hollow, allowing placement over a fiberoptic bronchoscope. First, place the catheter over the fiberoptic scope, and then direct the scope into the trachea. Next, remove the fiberoptic scope and SGA, leaving the catheter in the trachea. Finally, direct a standard endotracheal tube over the catheter into the trachea. This technique allows for visualization of the glottis but requires expertise
® in the use of a fiberoptic bronchoscope. This technique is not possible with the Shiley .
Leave the SGA in place and perform a surgical airway (cricothyroidotomy or tracheostomy). This is often chosen after an SGA insertion followed difficulties with standard intubation and if the patient requires prolonged mechanical ventilation. This can be done either in the operating room or in the ED if needed, depending on the patient’s condition, available resources, and skills of the provider.


