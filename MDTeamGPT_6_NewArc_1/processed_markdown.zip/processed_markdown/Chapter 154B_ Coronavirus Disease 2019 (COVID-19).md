## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 154B: Coronavirus Disease 2019 (COVID­19)
Nicholas M. Mohr; Timothy J. Ellender
Content Update: October 2022
See Management section for current recommendations for Pharmacotherapy, Antivirals, Anticoagulation, and Monoclonal Antibodies
Content Update: COVID­19 February 2022
Contemporary information on COVID­19 is provided in the following sections: Pathophysiology; Monoclonal Antibodies; and Antivirals. New references are added in these areas.
Review current information on treatment guidelines at: https://www.covid19treatmentguidelines.nih.gov/therapies/statement­on­therapies­forhigh­risk­nonhospitalized­patients/
OVERVIEW
On December , 2019, public health authorities in Wuhan, China, reported a cluster of cases of severe atypical pneumonia. Over the next  months, experts identified and sequenced the Severe Acute Respiratory Syndrome Coronavirus type  (SARS­CoV­2) as the virus responsible, and Coronavirus

Disease 2019 (COVID­19) spread across the world, reaching pandemic status. COVID­19 was responsible for more than .8 million deaths worldwide in
,3
2020, and it was one of the leading causes of death in the United States. Public health authorities recommended social distancing, widespread testing, travel bans, stay­at­home orders, mask mandates, and restricted commerce to slow the spread of the infection.
PATHOPHYSIOLOGY
SARS­CoV­2 is an enveloped RNA β­coronavirus genetically similar to the virus that causes Severe Acute Respiratory Distress Syndrome (SARS). SARS­
CoV­2 has four structural proteins (spike, membrane, envelope, and nucleocapsid) and binds principally to the angiotensin­converting enzyme 

(ACE2) receptor, which is widely expressed in the lung and elsewhere. SARS­CoV­2 is transmitted between humans primarily through respiratory droplets (large droplets of secretions that can propagate from an infected individual) and close personal contact. The incubation period of COVID­19 is
2–7 days (median  in original SARS­CoV­2, but lower in some newer variants), and viral shedding occurs up to  days prior to the onset of symptoms
5­8, 8A with maximal production in the first week after symptom onset (Figure 154b­1). During the course of the pandemic, SARS­CoV­2 has evolved through genetic mutation into new variants. Each variant has slightly different transmission dynamics, severity, and response to therapeutics. Based on genetic and epidemiologic surveillance, the U.S. Centers for Disease Control and Prevention (CDC) refers to new variants by labels from the Greek alphabet and classifies important new variants into Variants of Concern (VOC) or Variants of High Consequence (VOHC) based on the transmissibility, severity, and effectiveness of vaccines or therapeutics.
FIGURE 154b­1
Time course of SARS­CoV­2 infection. Approximately 2­5 days after the initial exposure, patients develop symptoms, but viral shedding often occurs before symptoms. Viral replication peaks in the first week of infection, with severe illness manifesting during the second week.

(CRheapprotedru 1c5e4dB w: iCtho proenrmavisirsuios nD firsoemas Cee 2vi0k1 M9 , (KCuOpVpaIDll­i 1K9, )K, iNndicrhaoclhausk M J,. eMt oahl:r V; iTroimloogtyh,y t rJa. nEslmleinsdsieorn, and pathogenesis of SARS­CoV­2, BMJ 2P02a0g eO 1c t/ 
. Terms of Use * Privacy Policy * Notice * Accessibility

;371:m3862. Data from Oberfeld B, Achanta A, Carpenter K, et al: SnapShot: COVID­19, Cell 2020 May ;181(4):954­954.e1 and McGrath BA, Brenner MJ, Warrillow
SJ, et al: Tracheostomy in the COVID­19 era: global and multidisciplinary guidance, Lancet Respir Med 2020 Jul;8(7):717­725.)
COVID­19 severity of illness varies. Estimates are  in  of those infected with SARS­CoV­2 have no or minimal symptoms, yet asymptomatic infected
,10 individuals still shed virus and may trigger up to 60% of COVID­19 transmission. An estimated 5­17% of infected patients develop severe disease,
, 11A, 11B which can progress to a profound inflammatory lung injury consistent with acute respiratory distress syndrome (ARDS). In severe COVID­19, features include overwhelming systemic inflammation, hypercoagulability, septic shock, and multisystem organ failure.
CLINICAL PRESENTATION
Most symptomatic COVID­19 patients present initially with mild disease, with fever or fever history (78%), cough (57%), and shortness of breath (23%)
 being the most common symptoms. Fatigue (31%), myalgia (17%), and headache (13%) also are common (Table 154b­1). Loss of smell (anosmia) or taste (ageusia) are symptoms that are rare but more frequently reported in COVID­19 sufferers compared to other viral respiratory illnesses, and up to

18% of those infected have gastrointestinal symptoms including diarrhea. In patients who progress to severe illness, significant respiratory
 symptoms and hospital admission occur 3–9 days (median 7) after the onset of symptoms. Many other less common symptoms exist in COVID , including conjunctivitis, sore throat, rash with distal extremity discoloration, and chest pain. In some cases, the first healthcare contact is for severe respiratory failure.
TABLE 154b­1
Symptoms of Patients with COVID­19 Diagnosis
Prevalence Symptom
>50% Fever
Dry cough
25–50% Fatigue
Productive cough
Loss of smell
10–25% Dyspnea
Myalgias
Rigors
Diarrhea
Arthralgias
Wheezing
Sore throat
Headache
Confusion
<10% Chest pain
Rhinorrhea
Loss of taste
Nausea
Vomiting
(Adapted with permission from Grant MC, Geoghegan L, Arbyn M, et al. PLOS One 15(6): e0234765, 2020).12
Age and select comorbid conditions are predictors of severe disease. More than 30% of deaths occur in patients over the age of , and cardiovascular
15­17 disease, diabetes mellitus, hypertension, obesity, and chronic lung disease are particularly important comorbid risk factors. Approximately 14% of total diagnosed cases require hospitalization, but because of underdiagnosis in those with mild or asymptomatic disease, the proportion hospitalized
 may be much lower.
19­21
Young children may be less susceptible to COVID­19 infection than adults, and severe disease is uncommon in children. Multisystem inflammatory syndrome in children (MIS­C), however, is a rare condition characterized by fever and inflammation in multiple organs that has been associated with
SARS­CoV­2 infection, and MIS­C is described in more detail in chapter 129, Congenital and Acquired Pediatric Heart Disease, in the section entitled

Multisystem Inflammatory Syndrome in Children.
COVID­19 symptoms parallel closely other viral respiratory illnesses, such as influenza, respiratory syncytial virus, and human metapneumovirus.
Bacterial pneumonia also can mimic closely symptoms of COVID­19, especially among those with atypical bacterial pathogens. Noninfectious causes may mimic COVID­19, such as chronic obstructive pulmonary disease exacerbations, congestive heart failure, acute coronary syndrome, and pulmonary embolism.
CLINICAL CARE
PREHOSPITAL ASSESSMENT
The Centers for Disease Control and Prevention (CDC) recommend that emergency response systems ask callers about COVID­19 symptoms, and EMS providers should also screen patients for COVID­19 symptoms or exposure after arrival. These techniques can help prioritize response, minimize unnecessary staff exposure, and allocate resources across the system. EMS providers should use appropriate personal protective equipment (PPE) throughout patient encounters and between calls to limit staff transmission (see “Personal Protective Equipment (PPE) for Healthcare Personnel,”
 below).
Patients with less severe symptoms may be questioned about symptoms and recent exposures, although many COVID­19 patients present without
 typical symptoms or identified exposures. For patients with respiratory failure, supplemental oxygen or noninvasive ventilation aid those with distress or hypoxemia. When possible, limit the number of people in the patient compartment of the ambulance to reduce exposure. In communities with high COVID­19 hospitalizations, community­wide resource allocation helps distribute cases to hospitals with capacity to provide care.
After every patient transport (whether COVID­19 was suspected or not), clean the ambulance with an appropriate Environmental Protection Agency
(EPA)­registered hospital­grade disinfectant.
ALTERNATIVE LOCATIONS FOR CARE
During the COVID­19 pandemic, health systems developed triage and care locations distinct from the ED. The goals were to (1) reduce COVID­19 transmission, (2) expand testing and care capacity, (3) use PPE efficiently, and (4) decrease ED waiting times. Alternate care sites included COVID­19 telemedicine clinics for patients with mild symptoms, drive­through testing sites, and tents or other nearby structures to expand capacity.
TRIAGE
The roles of triage for potential COVID­19 patients are to identify critically ill patients who need urgent intervention and to reduce the risk of transmission to other patients and staff. In areas with widespread COVID­19 transmission, triage allows cohorting of patients into distinct COVID­19 waiting and treatment rooms. To limit exposure to patients, community members, and healthcare personnel, family and friends are often prohibited from the care setting. Staff should provide all patients with a surgical mask to wear in the ED with instruction on proper use. Either multi­layered cloth
 masks or disposable surgical masks can capture respiratory droplets. Universal masking can reduce spread from symptomatic and asymptomatic

COVID­19 patients.
Standardized triage algorithms aid in rapidly identifying patients at risk for COVID­19. One algorithm developed by the CDC recommends isolation in patients with either (1) fever and cough or (2) at least three other symptoms of COVID­19 (cough, myalgia, headache, sore throat, loss of smell or taste).
In areas with no or limited community transmission, patients are further risk stratified by asking about possible COVID­19 exposure (Figure 154b­2).
FIGURE 154b­2
Triage of patients with suspected COVID­19. This algorithm guides the triage of patients presenting to hospitals with suspected COVID­19. (Reproduced with permission from Standard Operating Procedure [SOP] for Triage of Suspected COVID­19 Patients in non­US Healthcare Settings:
Early Identification and Prevention of Transmission during Triage, National Center for Immunization and respiratory Diseases [NCIRD], Division of Viral diseases, The Centers for Disease Control and Prevention [CDC]. Available at https://www.cdc.gov/coronavirus/2019­ncov/hcp/non­us­
 settings/images/triage­sop­appendix2.jpg. Updated Feb , 2021.)
Early illness stratification is best done at triage, where vital signs (pulse oxygenation, blood pressure, and pulse rate) and work of breathing can identify illness severity early (Table 154b­2).
TABLE 154b­2
Classification of Illness Severity in COVID­19
Severity of Illness
Observations Asymptomatic Mild Moderate Severe Critical
Symptoms None At least one COVID­ Lower respiratory Lower respiratory Respiratory failure,
High risk factors  symptom, not disease (e.g., cough, disease (e.g., cough, septic shock, or multi­
Age ≥65 including shortness dyspnea, rhonchi) or dyspnea, rhonchi) or system organ
Chronic respiratory of breath, dyspnea, abnormal imaging abnormal imaging with dysfunction disease or abnormal chest involvement of 50% of
Chronic kidney imaging lung fields disease
Chronic cardiovascular disease
Immunosuppression
Diabetes
Cancer
Oxygen saturation on Normal ≥94% (or at baseline 89–92% (or less than ≤88% (or less than baseline in chronic lung disease) room air in chronic lung baseline in chronic lung disease) disease)
Respiratory rate Normal 10–22 8–10 or 23–28 <8 or >29
Heart rate Normal <100 40–50 or 101–120 <40 or ≥121
GCS Normal  ≤14 to 
Laboratory Findings No testing Normal PaO /FiO <300 mm Hg PaO /FiO <200
    necessary mm Hg
(Normal)
Lymphopenia (<1.1
× 109 cells/L)
Thrombocytopenia
(<50 × 109 cells/L)
D­dimer >1.0 mg/L
New acute kidney injury (creatinine 
× baseline)
Elevated ALT/AST
Elevated inflammatory markers (CRP,
WBC)
Elevated troponin
(late)
Elevated lactate
(VBG) >3.0 mmol/L
Testing COVID­19 PCR for nucleic acid detection (use local protocol)
Testing Additional Additional testing Chest x­ray Chest x­ray Chest x­ray testing not not recommended ECG ECG ECG recommended in most patients POCUS (if POCUS (if POCUS (if available)
Consider chest x­ray available) available) CMP, CBC for patients with CMP, CBC Blood culture if
Consider CBC, CMP in advanced age or Blood culture if febrile ≥38.5°C patients with advanced significant febrile ≥38.5°C Lactate age, significant comorbidities Lactate Troponin comorbidities, or those
VBG being admitted to the Consider “critical”
D­dimer* hospital testing if patient
CRP* appears toxic
Procalcitonin* Initial Management, Discharge Discharge Discharge Inpatient admission ICU admission/consult
Treatment, and Patients Follow all criteria for Follow all criteria for Follow
Disposition should asymptomatic and asymptomatic/mild and institutional remain in Patients If SpO ≥ 93% on protocols or level
 isolation at should remain of care and room air (or at home until in isolation at service selection.
baseline in chronic free of home until free lung disease), refer
ICU referral if: disease. of disease.
for daily follow­up
High­flow oxygen
Consider Strongly via local COVID­19 therapy or home pulse consider home service ventilatory oximetry pulse oximetry support is
If SpO <90% on room monitoring monitoring  required to
Arrange Arrange follow­ air or falls to <88% with maintain SpO follow­up up or activity, consider 
≥93% or virtual/in­ inpatient admission and
Intubated on virtual/in­ home steroid therapy mechanical home monitoring Inpatient admission ventilation monitoring Provide clear Follow
Requires
Provide and detailed institutional vasopressor clear and instructions for protocols support detailed prompt instructions return/re­
Meets normal referral for prompt evaluation criteria return/re­
Strongly consider evaluation incentive spirometry
Consider incentive spirometry
*Testing is optional and may be recommended by some institutional protocols. Note: Breakdown of illness progression based on symptoms/severity with suggested laboratory workup, treatment, and disposition for each level of severity.16,17,46­57
Abbreviations: PaO = partial pressure alveolar oxygen; FiO = fraction of inspired oxygen; ALT = alanine transaminase; ALT = aspartate aminotransferase; CRP = C­
  reactive protein; WBC = white blood cell count; VBG = venous blood gas; CMP = complete metabolic panel; POCUS = point of care ultrasound; LDH = lactate dehydrogenase; ICU = intensive care unit.
PERSONAL PROTECTIVE EQUIPMENT (PPE) FOR HEALTHCARE PERSONNEL
ED healthcare personnel treat undifferentiated patients, perform high­risk aerosol­generating procedures, and have additional exposures in
 congregating areas such as break and eating rooms. Because of that, universal mask use with well­fitting surgical masks or N95 masks (or Filtering
Facepiece  [FFP2]) and eye protection is recommended throughout healthcare facilities to reduce COVID­19 spread, both from patients to healthcare
,29 personnel and between staff members. Masks reduce environmental droplet concentration and droplet deposition on surrounding work
30­32 surfaces. Masks with exhalation valves release unfiltered exhaled air, so they do not protect others and should be avoided. Universal and continuous mask use, universal eye protection, maintaining physical distancing when possible, and frequent handwashing are essential risk
,34 management techniques.
For staff caring for patients known or suspected to be infected with COVID­19, the CDC recommends N95 (FFP2) use when available, or well­fitting surgical masks if sufficient N95 supply is not available. Additionally, staff should use eye protection, gowns, and gloves for encounters with these patients.
Because of supply chain disruptions, many healthcare facilities around the world have had limited PPE supplies. Approaches to limit PPE consumption
 include use of the same face mask and gown throughout a shift, reprocessing N95 masks with moist heat or vaporized hydrogen peroxide, and use of alternative PPE (surgical masks for COVID­19 patients or industrial particulate masks). With time, evidence continues to evolve regarding the protection afforded by different types of masks, in both community and hospital settings. Follow institutional recommendations and local public health guidance to protection with available PPE.
STEPPED APPROACH FOR HEALTHCARE PPE
A stepped approach is recommended for PPE for healthcare personnel, depending on exposure risk (Table 154b­3). Maintain physical distancing when possible and minimize the duration of patient exposure. Upon leaving the room of a suspected or confirmed COVID­19 patient, carefully remove
PPE to prevent self­contamination. Wash hands or use an alcohol­based hand sanitizer after each patient contact or exposure.
TABLE 154b­3
PPE for Healthcare Personnel
Protection Comments
Suspected or confirmed COVID­ N95 (FFP2) or higher­level respirator, or well­fitting surgical facemask Good fit
 infection if N95 not available
Eye protection Goggles or face shield that covers front and sides of face
Gloves Change and wash hands with each encounter
Isolation gown Careful doffing to prevent viral contamination
Aerosol­generating procedures N95 (FFP2) or higher level respiratory, powered air­purifying Follow CDC/WHO guidelines respiratory (PAPR)
Eye protection, gloves, isolation gown As above
Specific aerosol­generating procedures (e.g., endotracheal intubation, nebulized inhaled therapy, mouth or airway suctioning) are higher­risk events that require additional PPE (N95, FFP2, or high­level respirator or powered air­purifying respirator [PAPR]; eye protection, gowns, and gloves). Aerosolgenerating procedures are best done with caution and protection, and they should be avoided if possible. If necessary, use experienced staff with the door closed in an airborne infection isolation (negative pressure) room (if available) with the minimum number of staff in the room. After an aerosolgenerating procedure, respiratory aerosols can remain suspended in the room air, so limit further entry, and ensure all staff entering the room use similar precautions following local institutional guidance.
Clean patient rooms and work surfaces frequently using an EPA­registered hospital­grade disinfectant qualified under the Emerging Viral Pathogens
Program for use against SARS­CoV­2. Use similar disinfection procedures on a regular schedule in hospital workrooms or other places where employees congregate, as these can represent locations of HCP transmission.
Electronic PPE
Electronic PPE is the use of telemedicine tools to evaluate patients verbally and visually, but without direct physical proximity. Smart phones or tablet computers, and digital or electronic stethoscopes, are examples of devices that allow for medical evaluation, with medical personnel immediately available as needed. High­definition secure video connections can facilitate communication with registration staff, family and friends, and clinical
 evaluation by healthcare team members, or other functions.
SARS­COV­2 TESTING
COVID­19 testing can limit disease spread by allowing quarantine and isolation practices. Early in the COVID­19 pandemic, multiple SARS­CoV­2 tests
 were granted Emergency Use Authorization (EUA) by the U.S. Food and Drug Administration (FDA), and the test characteristics of these tests vary.
Broadly, testing falls into one of three categories: nucleic acid amplification tests (NAATs), antigen tests, and antibody tests (Table 154b­4). Several low­complexity, rapid molecular diagnostic tests exist for use by non­laboratory personnel, but the sensitivity of these tests compared with traditional
,39 laboratory­based techniques are usually lower.
TABLE 154b­4
Types of COVID­19 Tests and Test Characteristics
Test Type Sensitivity (%, 95% CI) Specificity (%, 95% CI) rt­PCR RS RS
Rapid molecular assays  (87–98)  (97–100)
Antigen  (30–80) .5 (98–100)
Antibody* (ELISA—IgG/IgM)  (76–91)  (93–99)
Antibody* (chemiluminescent immunoassay—IgG/IgM)  (46–100)  (85–100)
*Antibody test characteristics are time­dependent. These test characteristics are reported  weeks after infection.
Note: Individual test performance varies within each category, so it is important to understand the characteristics of the individual test being used under an FDA
Emergency Use Authorization (EUA).39,40
Abbreviations: rt­PCR = reverse transcriptase polymerase chain reaction; RS = reference standard.
NUCLEIC ACID AMPLIFICATION TESTS (NAATs)
The current best tests for the diagnosis of COVID­19 infection are NAATs. These tests are performed on an upper respiratory (nasopharyngeal preferred, oral or nasal alternatives acceptable) sample collected with a flocked swab to collect cellular material for testing. NAATs detect the presence of viral RNA. Tests in this category are both sensitive and specific, but they identify only patients who are actively shedding virus at the time of testing.
Patients in the incubation period may have negative tests, and patients who have recovered may continue to have positive tests because viral RNA is present even beyond the period of infectivity. NAATs require specialized laboratory techniques, equipment, and personnel, limiting their use outside high­volume laboratories.
ANTIGEN TESTS
Antigen tests are an attractive strategy for identifying patients with COVID­19 because they tend to be rapid (15 minutes) and inexpensive. They require
 limited training or equipment to perform. These tests screen for viral protein on a sample taken from an upper respiratory swab. Because viral proteins may not be present in the upper respiratory tract early in the course of infection (especially in those who are asymptomatic), the sensitivity of
 antigen tests is lower than that of NAATs. High specificity means that positive tests may be used to maintain isolation and treatment (especially in lowrisk patients), but the CDC recommends that negative antigen tests be confirmed using a NAAT.
ANTIBODY TESTS
These tests use patient serum or plasma to identify anti­SARS­CoV­2 IgM, IgG, or IgA antibodies. Antibodies may not be detected until  weeks after the
,43 onset of symptoms, so they are not useful in making the diagnosis of acute COVID­19 infection. Sensitivity and specificity vary, but the most common use of these tests is to identify patients with prior infection for population surveys or to help interpret the results of persistently positive
NAAT. It is currently unknown how long SARS­CoV­2 antibodies persist after infection or vaccination, but early data suggest that tests remain positive
 for at least  months in those with documented COVID­19 infection.
ED EVALUATION AND DISPOSITION
ED evaluation of the COVID­19 patient is best guided primarily by patient acuity and risk of COVID­19. Patients with symptoms consistent with COVID­19 should be tested for SARS­CoV­2, using NAATs (although a staged approach with an initial antigen test is acceptable to facilitate early diagnosis if positive). In low­acuity patients, testing may occur either in the ED or after discharge in a centralized testing center. Viral testing for other respiratory
 pathogens (e.g., influenza) may be considered, especially if results will impact destinations or treatment options, and since co­infection is possible.
Symptomatic COVID­19 patients may be classified into four severity categories: mild, moderate, severe, or critical. Diagnostic workup, management, and disposition are guided by severity assessment (Table 154b­2).
MILD ILLNESS
These patients may have respiratory and/or non­respiratory symptoms. Patients with mild illness do not have shortness of breath, hypoxemia
(ambient oxygen saturations <93%), dyspnea on exertion, or abnormal chest imaging. Healthy and younger patients with mild illness and no significant comorbidities often require COVID­19 testing only. Patients with risk factors for progression of disease can benefit from laboratory and imaging evaluation guided by history and physical examination.
In patients with abdominal pain, vomiting, diarrhea, or other non­respiratory symptoms, laboratory evaluation or imaging is best guided by clinical findings. Especially if COVID­19 test results are delayed, it is important to rule out important alternative causes of symptoms rather than waiting for a negative COVID­19 test to prompt broader evaluation.
Patients with mild illness will usually be discharged home.
MODERATE ILLNESS
These COVID­19 patients have respiratory findings, and they should have a chest radiography and electrocardiogram (ECG). Obtain a complete blood count (CBC) and complete metabolic panel (CBC) in those with advanced age, significant comorbidities, or those in whom hospital admission is being considered. For those with uncertain illness severity, consider blood cultures and serum lactate. Treat those with bacterial pneumonia superinfection or sepsis with empiric antibiotics. Previously healthy patients without hypoxemia may be monitored at home, but those with high­risk comorbidities may require hospital observation to monitor for progression of pulmonary disease. Some low­risk moderate illness patients with no concerning risk factors for progression of disease and modest hypoxemia (oxygen saturation ≥88% improved with supplemental oxygen) may be treated at home with oxygen in a system with careful home monitoring procedures. The potential for home monitoring depends on local resources, availability of outpatient
 or telemedicine follow­up, and patient factors.
SEVERE ILLNESS
Patients with severe COVID­19 illness have an oxygen saturation <88% on room air, a respiratory rate of >30 breaths/min, PaO /FiO <300 mm Hg (if
  measured), or lung infiltrates that involve more than 50% of radiographic lung fields. These patients are at risk for rapid deterioration and need oxygen therapy. Obtain chest x­ray, ECG, and full laboratory evaluation (CBC, CMP, lactate, blood cultures). Coagulation studies, including d­dimer, may be considered in this group as well if they will change diagnostic or treatment options. Admit to a floor bed with frequent monitoring. Consider admission to a step­down unit, depending upon monitoring needed.
CRITICAL ILLNESS
Patients who require more than simple supplemental oxygen have COVID­19 critical illness. Those with critical illness may have acute respiratory distress syndrome, cardiac dysfunction, cytokine storm, septic shock, and/or severe exacerbation of underlying comorbidities. Additionally, many with critical illness exhibit severe cardiac, hepatic, renal, central nervous system, or thrombotic complications. These patients require advanced ventilatory
 support or vasopressor therapy and are best treated in an intensive care unit (ICU).
TOOLS FOR RISK STRATIFICATION
Predicting clinical course is important for determining which patients require hospital admission and for prognosis prediction. Since the onset of the pandemic, many prediction models have been developed and reported to predict disease severity, progression, mortality risk, intensive care admission, intubation, or hospital length­of­stay. Most models report moderate to excellent discrimination but have a high risk of bias due to
 methodologic flaws. In this section, we will detail three scores applicable to ED patients. Taken together, these three scores may provide objective
,47,59,60 tools for informing COVID­19 decision­making, although validation and direct comparison to bedside clinical judgement are unreported.
4C Score
The 4C (Coronavirus Clinical Characterization Consortium) mortality score predicts hospital mortality using the following variables: age, sex,
 number of comorbidities, respiratory rate, oxygen saturation, level of consciousness, urea level, and C­reactive protein (score range 0–21 points).
The score defined four risk groups: low risk (score 0–3, mortality .2%), intermediate risk (score 4–8, .9%), high risk (score 9–14, .4%), and very high risk (score ≥15, .5%). Although the 4C score predicts mortality, some have attempted to extend its use in combination with other factors to guide patient disposition selection.
qCSI Score
The “quick COVID severity index” (qCSI) predicts the likelihood of intubation within  hours of admission. The qCSI uses three variables: lowest documented oxygen saturation; current respiratory rate; and current nasal cannula flow rate. The low risk group is characterized by a respiratory rate
≤22 breaths per minute, lowest oxygen saturation ≥92%, and oxygen flow rate ≤2 liters.  Low risk values for all three criteria were 79% (95% CI 65–
93%) sensitive and 78% (95% CI 72–83%) specific in identifying patients who did not progress to respiratory failure, with a 4% risk of critical illness at 
 hours.
COVID­19 Acuity Score

The “COVID­19 Acuity Score” (CoVA) predicts hospitalization, critical illness (intensive care unit or ventilation), or death within  days. CoVA incorporates age, diastolic blood pressure, blood oxygen saturation, COVID­19 testing status, and respiratory rate, and the score ranges from  to 100 points. The proportion with 7­day adverse events rises from 18% for scores 0–20 to 88% for scores 80–100. Critical illness and death also are higher, from 2% for scores 0–20, to 32% for scores 80–100. VTE ASSESSMENT
Venous thromboembolism is common in patients with COVID­19, but evaluation should be guided by suspicion of thromboembolic disease.
Coagulation markers (d­dimer, prothrombin time, platelet count, fibrinogen) are commonly measured in hospitalized patients, but the role of using these markers to select further diagnostic studies or treatment options in routine practice remains unclear.
Venous duplex ultrasound, CT pulmonary angiography, and bedside echocardiography may be used to identify patients with venous thromboembolism. d­dimer may be used to rule out thromboembolic disease in low­risk patients, but it is not diagnostic for venous thrombus if elevated.
Any patients who experience acute cardiopulmonary decompensation, new neurologic findings, or sudden localized loss of peripheral vision should be evaluated for thrombotic disease. Patients found to have acute arterial or venous thrombus should be treated with therapeutic anticoagulation.
MANAGEMENT
Current COVID­19 treatment guidelines from the National Institutes of Health are available at https://www.covid19treatmentguidelines.nih.gov/.
OUTPATIENT MANAGEMENT
Outpatient management consists of education, monitoring for worsening severity, and isolation. COVID19 patients should remain completely isolated at home for  days. Patients who live with family or roommates should remain in a separate room, use a separate bathroom if possible, and wear masks outside that room for the duration of the isolation period, to reduce the risk to cohabitants. Telemedicine follow up is often used for outpatients. Patients at high risk of progression to severe COVID­19 infection can be treated with antiviral therapy, and anti­SARS­CoV2 monoclonal antibody therapy may be considered for high­risk patients when antiviral therapy is unavailable or inappropriate (see below (1)). In health systems that have a program for ED discharge of acute COVID­19 patients with new supplemental oxygen, dexamethasone therapy is recommended, but corticosteroid therapy is not recommended for discharged patients not requiring new supplemental oxygen.
For All Patients who do not require hospitalization or supplemental oxygen (1):
All patients should be offered symptomatic management a
CDC recommends against the use of dexamethasone or other systemic corticosteroids in the absence of another indication.
b
For Patients Who Are at High Risk of Progressing to Severe COVID­19
Preferred therapies. Listed in order of preference: c,d
Ritonavir­boosted nirmatrelvir (Paxlovid) d,e
Remdesivir
Alternative therapies. For use ONLY when neither of the preferred therapies are available, feasible to use, or clinically appropriate. Listed in alphabetical order: f
Bebtelovimab d,g
Molnupiravir a
Currently lack of safety and efficacy data on the use of outpatients with COVID­19 b see ‘Underlying Medical Conditions at risk for Severe COVID­19: Information for HealthCare Professioinals c
Most interaction potential resolves in 2­3 days; strong CYP3A4 inducers (St. John’s wort, rifampin) may reduce concentrations of nirmatrelvir and ritonavir d
If patient requires hospitalization after starting treatment, full treatment course can be completed at PCP discretion e
Remdesivir requires 3­5 consecutive days of IV infusion f
Use Bebtelovimab only if preferred treatments not available or feasible g
Molnupiravir has lower efficacy than preferred treatment options
(1) NIH COVID­19 Treatment Guidelines, Table 2a. Therapeutic Managmeent of Nonhospitalized Adults with COVID­19 (updated August , 2022)
MANAGEMENT OF HOSPITALIZED, NON­ICU PATIENTS
Oxygen therapy and supportive care remain the primary focus for patients in the ED awaiting admission, and for hospitalized patients. In patients admitted to the hospital who require supplemental oxygen, dexamethasone and/or remdesivir may be used to reduce complications from COVID­19
(see “COVID19 Pharmacotherapy,” below). Neither therapy is thought to be time­sensitive, however, so treatment may start after hospital admission.
Other immune modulators and monoclonal antibodies also may be considered, and the NIH COVID­19 Treatment Guidelines outline indications for their use.
Management of Hospitalized Patients Not Requiring Supplemental Oxygen
Patients with COVID­19 who do not require supplemental oxygen may be hospitalized for their comorbidities or for reasons unrelated to their COVID status. As in outpatients, those at high risk for progression to severe COVID­19 disease may benefit from antiviral therapy with remdesivir, which has been approved for treatment in high­risk adult and pediatric patients. When administered to inpatients, remdesivir should be administered for  days
119­121 or until hospital discharge to reduce time to resolution and prevent disease progression . Additionally, these patients qualify for the same treatment strategies as those who are not hospitalized with COVID­19 disease (see Outpatient Management). At this time there is no clear evidence of benefit for corticosteroids in the treatment of patients with COVID­19 who do not require supplemental oxygen. Patients who are receiving
122­123 corticosteroids for other disease states should continue those therapies as prescribed .
Management of Hospitalized Patients Requiring Conventional Supplemental Oxygen
Patients with severe COVID­19 requiring oxygen therapy benefit from the early (<10 days from symptom onset) use of remdesivir therapy plus corticosteroid therapy. When dexamethasone is not available, other corticosteroids (prednisone, methylprednisone, and hydrocortisone) may be used. In patients who have rapidly increasing oxygen needs (e.g., nasal cannula to high flow nasal cannula), the addition of interleukin (IL)­6 inhibitors
124­127
(i.e., tocilizumab) or Janus kinase (JAK) inhibitors (i.e., baricitinib) is additionally recommended.
MANAGEMENT OF CRITICALLY ILL PATIENTS IN THE ED OR ICU
The primary manifestations of critical illness in the ED are acute hypoxemic respiratory failure and sepsis, and COVID­19 can lead to multisystem organ failure.
Pharmacotherapy
In patients who require advanced oxygen support (i.e., high­flow nasal cannula, non­invasive positive pressure ventilation, mechanical ventilation), additional immunomodulation is indicated in addition to corticosteroid therapy. Baricitinib or tocilizumab reduce the inflammatory cascade and have been shown to reduce mortality. Baricitinib has the best available evidence of success, but if neither are available tofacitinib or sarilumab may be used
128­130 as alternatives. These additional agents are recommended for all patients who require mechanical ventilation or extracorporeal support .
Remdesivir is additionally recommended for immunocompromised patients who require advanced oxygen therapy, with a longer recommended
131 duration of  days . In patients who require mechanical ventilation or extracorporeal membrane oxygenation support, it is strongly recommended that dexamethasone be started as soon as possible and that baricitinib, tocilizumab, tofacitinib, or sarilumab be added as available.
RESPIRATORY SUPPORTIVE CARE
Oxygenation and Ventilation
Critically ill patients with COVID­19 are often hypoxemic and require ventilatory support, and this support may be delivered with supplemental oxygen, high­flow nasal oxygen (HFNO), noninvasive positive pressure ventilation (NIPPV), or mechanical ventilation. Traditional recommendations for oxygen supplementation are to target saturations above 90–92%. Initial oxygen therapy usually starts with low­flow oxygen by nasal cannula (0.5–6 LPM), with a surgical mask over the cannula to reduce viral droplet escape. Patients who remain hypoxemic undergo graded escalation to a simple mask (6–10
L/min) or a non­rebreather mask (NRB) (10–15 L/min). For patients hypoxemic on  L of oxygen via a NRB or who have increased work of breathing
63­65
(even on lower flows of oxygen or without hypoxemia), more aggressive ventilatory support is necessary (Figure 154b­3).
FIGURE 154b­3
Algorithmic approach to respiratory failure in COVID­19.ABG = arterial blood gas; HFNC = high­flow nasal cannula; N/C = nasal cannula; NIV = noninvasive ventilation; NRB = nonrebreather; P/F = Pao/Fio ratio; RA = room air; Spo = arterial oxygen saturation as determined by pulse oximetry

(Reproduced with permission from Raoof S, Nava S, Carpati C, et al. Chest 158: 1992, 2020).
The purpose of noninvasive strategies is to improve oxygenation and reduce work of breathing, while avoiding the risks of mechanical ventilation.
Both HFNO and NIPPV require an alert patient who can participate in respiratory support.
High­Flow Nasal Oxygenation (HFNO)
HFNO allows flow rates adjusted between 10–60 L/min with adjusted humidity and temperature to deliver a fraction of inspired oxygen (FiO ) between

21% and 100%. In principal, HFNO reduces airway dead space, provides passive oxygenation, and induces continuous positive airway pressure (CPAP)­
,67 like alveolar recruitment. HFNO decreases work of breathing by 15% and may decrease airway obstruction. In adults, flow rates are set to 40–60
L/min during stabilization of acute distress at 100% FiO , and weaning can occur once clinical stability exists. HFNO is preferred over NIPPV in patients

 with acute hypoxemic respiratory failure based on an ARDS clinical trial in patients without COVID­19. HFNO reduced the rate of intubation (OR .48;

95% CI, .31–0.73) and ICU mortality (OR .36; 95% CI, .20–0.63) compared with NIPPV.
Non­Invasive Positive Pressure Ventilation (NIPPV)
NIPPV is described in Chapter . NIPPV, which reduces both work of breathing and airway resistance, may be used after HFNO failure and before
 mechanical ventilation. NIPPV by face mask can avert endotracheal intubation and improve mortality in patients with acute respiratory failure. An alternative to NIPPV by mask is NIPPV via a helmet interface with transparent hood that covers the entire head of the patient with a soft collar neck
 seal. This interface improves tolerability and results in less air leak due to the lack of contact with the face and improved seal at the neck. Recently
71­73
NIPPV via helmet interface has been tested in COVID­related acute respiratory failure and remains a therapeutic option.
Awake Prone Positioning

Prone positioning improves oxygenation and survival in mechanically ventilated severe ARDS patients. In a case series of COVID­19 patients who were not mechanically ventilated, however, awake prone positioning also improved oxygenation, leading many centers to adopt awake proning protocols
 for hypoxemic COVID­19 patients who have not been intubated. Awake prone positioning is well tolerated and improves oxygenation with low
,77 intubation rates. The most promising candidates for prone positioning are those with normal consciousness who can reposition themselves easily. Prone positioning has been used in patients on HFNO and on NIPPV. Awake prone positioning should not be used as an alternative to
,79 endotracheal intubation in patients with progressive respiratory failure and signs of hypercapnia.
Endotracheal Intubation
In patients who fail to improve with HFNO and/or NIPPV, deteriorate, or are in extremis, use endotracheal intubation and mechanical ventilation (see
Chapter 29). Before any intubation decision, discuss goals of care with patients and families. COVID­19 patients with advanced age (>70 years) who require mechanical ventilation have low survival, and selecting a course of therapy consistent with patient values and wishes should be initiated in the

ED.
Mechanical Ventilation
For patients requiring mechanical ventilation, preventing iatrogenic ventilator­induced lung injury is critical to COVID­19 survival. The principles of
 lung protective ventilation should be initiated in the ED because this early period is a vulnerable time in critical illness. Maintaining low tidal volumes
,83
(V 4–8 mL/kg of predicted body weight) and plateau pressures of <30 cm H O are recommended to reduce the risk of lung injury. Respiratory rate
T  changes may improve acid­base status and maintain passive ventilation, although permissive hypercapnia (pCO 45–55) is acceptable.

Adequate positive end­expiratory pressure (PEEP) is recommended to maintain open­lung physiology. PEEP is used to improve oxygenation through lung recruitment and improved ventilation­perfusion matching. It also may prevent lung injury associated with atelectasis and recurrent alveolar
 opening. Although many PEEP titration strategies exist, PEEP/FiO tables are one strategy to select PEEP based on the degree of hypoxemia and shunt

 by guiding PEEP titration with a stepwise increase in PEEP based on FiO requirements (Table 154b­5).

TABLE 154b­5
PEEP Table
FiO (%) PEEP (cm H O)

100 18­24
Data from Brower RG, Lanken PN, MacIntyre N, et al: Higher versus lower positive end­expiratory pressures in patients with the acute respiratory distress syndrome,
N Engl J Med 2004 Jul ;351(4):327­336(86).
87­89
For mechanically ventilated adults with refractory hypoxemia, prone positioning and neuromuscular blocking agents may help. These therapies often are applied after hospital admission but may be considered in persistently hypoxemic ED patients waiting for ICU bed availability. In patients with severe hypoxemic respiratory failure refractory to medical therapies, extracorporeal membrane oxygenation (ECMO) is an option, although it is
 recommended only in those under age  with a reasonable chance of recovery.
SEPSIS MANAGEMENT
Severe COVID­19 may also induce sepsis, a dysregulated host response that can cause multisystem organ failure, shock, and cardiac dysfunction.
COVID­19 sepsis can be viral or associated with bacterial pneumonia superinfection. Management should be similar to sepsis management in patients without COVID­19, as discussed in Chapter 151. In patients who do not benefit from fluid loading, conservative fluid targets may be used to limit
 extravascular lung water.
COVID­19 PHARMACOTHERAPY
CORTICOSTEROIDS
The best­supported pharmacotherapy for severe COVID­19 infection is corticosteroid therapy. Dexamethasone  mg daily for  days improved
 survival in hospitalized patients on supplemental oxygen, with the greatest effect observed in patients who require mechanical ventilation.
Dexamethasone can start after hospital admission, but it may be considered in qualifying ED patients with prolonged boarding. Some centers facilitate
ED discharge of low­risk COVID­19 patients requiring supplemental oxygen, and dexamethasone should be considered in these patients.
Dexamethasone is not indicated for patients discharged from the ED without supplemental oxygen.
ANTIVIRALS
Antiviral therapy is recommended in outpatients at high risk of progression to severe disease and in inpatients with requiring mechanical ventilation.
There are three currently available antiviral agents with activity against SARS­CoV­2: ritonavir/nirmatrelvir, remdesivir, and molnupiravir. Candidates for outpatient pharmacotherapy include those with mild to moderate COVID­19 and risk for progression to severe disease, defined as at least one of the following:
Age ≥65,
Body mass index ≥30,
Diabetes mellitus,
Cardiovascular disease or hypertension,
Chronic lung disease, or
Immunocompromising condition or immunosuppressive treatment.
Ritonavir/Nirmatrelvir (Paxlovid)

Nirmatrelvir is an orally bioavailable protease inhibitor that has demonstrated antiviral activity against all human coronaviruses . Nirmatrelvir is packaged with ritonavir (as Paxlovid), a strong cytochrome P450 (CYP) 3A4 inhibitor and pharmacokinetic boosting agent. Ritonavir/nirmatrelvir is an orally administered medication that has been shown to reduce hospitalization or death by 89% in unvaccinated adults and is currently recommended
132 as a first­line agent for those at high risk of progression to severe disease . Ritonavir has multiple drug interactions and requires renal dose adjustment, so an appropriate pharmacologic reference should be used to aid in safe prescribing. An NIH web site outlines drug interactions at https://www.covid19treatmentguidelines.nih.gov/therapies/antiviral­therapy/ritonavir­boosted­nirmatrelvir­­paxlovid­/paxlovid­drug­druginteractions/.
Remdesivir (Veklury)
Remdesivir is an intravenous antiviral agent that inhibits SARS­CoV­2 RNA­dependent RNA polymerase and prevents viral replication. Remdesivir has been shown to reduce time­to­recovery, COVID­related hospitalization, and death, and is recommended for outpatients at high risk of disease progression when ritonavir/nirmatrelvir is unavailable/contraindicated and in hospitalized patients on supplemental oxygen but who do not require
 mechanical ventilation. Outpatients are administered daily infusions for  days, which may require logistical planning at the time of ED discharge.
Molnupiravir (Lagevrio)
Molnupiravir is the oral prodrug of beta­D­N4­hydroxycytidine (NHC), a ribonucleoside that has broad antiviral activity against RNA viruses. Although molnupivir can reduce the rate of hospitalization, it is not recommended as a first­line agent because it has lower efficacy than other treatment options. Molnupavir is only recommended in those at risk of progression to severe disease when ritonavir/nirmatrelvir and remdesivir are unavailable or contraindicated.
MONOCLONAL ANTIBODIES
Multiple anti­SARS­CoV­2 monoclonal antibody treatments have been used under FDA EUA (Emergency Use Authorization) approval for the treatment of outpatients with COVID­19 and high risk of disease progression. In general, these medications contain monoclonal antibodies to domains of the
, 
SARS­CoV­2 spike protein, which is a protein that evolves through different SARS­CoV­2 variants . Although monoclonal antibody therapy failed to show benefit in hospitalized patients, outpatients at high risk of disease progression showed prevention of deterioration with early COVID­19 variants
, 
. Monoclonal antibody effectiveness appears to have degraded as newer strains with mutations in the spike protein have evolved, and newer preparations have received FDA EUA approval to better target more recent variants. Currently, monoclonal antibodies are not recommended in outpatients with COVID­19, unless they are at high risk of severe disease and antiviral therapy is not available or contraindicated. In those cases, bebtelovimab is the only currently available monoclonal antibody with activity against newer versions of the Omicron variant. Monoclonal antibody therapy is not currently recommended for inpatients. EUAs and treatment guidance is evolving quickly in this area in response to recent variant specific effectiveness of these medications, so consulting the current NIH treatment guidelines is recommended prior to use (http://covid19treatment guidelines.nih.gov).
ANTICOAGULATION
100­103, 133
COVID­19 has been associated with arterial and venous thrombosis including central venous thrombosis. However, thromboprophylaxis in
COVID­19 remains controversial. COVID­19 patients chronically taking anticoagulation therapy for another indication should remain on their current regimen.
For hospitalized patients who require supplemental oxygen, and who are at low risk of bleeding and who do not require intensive care, therapeutic anticoagulation (i.e., subcutaneous low molecular weight heparin or intravenous unfractionated heparin) is recommended for nonpregnant patients with D­dimer levels above the upper limit of normal. In patients who do not qualify for therapeutic anticoagulation (including those with pregnancy), prophylactic anticoagulation only is recommended unless contraindicated. Patients being admitted to the ICU should be treated with prophylactic
104 anticoagulation only, regardless of D­dimer, because of the risk of bleeding, unless a contraindication exists .
An up­to­date summary of COVID19 pharmacotherapy options from the Infectious Diseases Society of America is available at https://www.idsociety.org/practiceguideline/covid19guidelinetreatmentandmanagement/, the American Society of Hematology at https://www.hematology.org/education/clinicians/guidelines­and­quality­care/clinical­practice­guidelines/venous­thromboembolismguidelines/ash­guidelines­on­use­of­anticoagulation­in­patients­with­covid­19, or the NIH at https://www.covid19treatmentguidelines.nih.gov/.
POST­COVID SYNDROME AND POST–ACUTE COVID­19 ORGAN DYSFUNCTION
Some COVID­19 patients have reported persistent symptoms and/or organ dysfunction after acute COVID­19 infection. Common late sequelae symptoms include fatigue, joint pain, myalgia, chest pain, palpitations, shortness of breath, cognitive impairment, mood impairment, and worsened
105 quality of life. In a recent survey of recovered patients, 35% reported not having returned to their usual state of health  weeks or more after
106 testing. The presence of three or more chronic medical conditions or an age of over  years were linked to persistent symptoms. Pulmonary
107 function is impaired one month after discharge in over half of patients. An MRI screening study revealed cardiac involvement in 78% of patients and
108 ongoing myocardial inflammation in 60% of patients at a median of  days after diagnosis from COVID­19. Patients with severe disease may require
109­117 long­term follow­up and management, and emergency physicians may see survivors of acute COVID illness seeking care for persistent
105,118 symptoms.
ACKNOWLEDGMENTS
The authors would like to acknowledge Dr. Peter Georgakakos and Deb Roush for their assistance in the development and preparation of this chapter.


