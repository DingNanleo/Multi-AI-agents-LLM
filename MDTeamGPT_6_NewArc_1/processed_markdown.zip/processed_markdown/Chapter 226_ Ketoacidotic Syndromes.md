## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 226: Ketoacidotic Syndromes
Debra Perina; William A. Woods
INTRODUCTION
Ketones form a viable energy source used daily by the body in response to variations in carbohydrate intake and energy demand. There are several conditions that may result in excessive production of ketoacids that can result in a significant metabolic acidosis. The challenge for the clinician is to differentiate states of excessive, uncontrolled ketoacidosis from physiologic ketonemia, from states where excessive ketones may be produced, or
 from conditions or a toxin altering normal metabolism. The pathophysiology of ketoacidosis is poorly understood. Authors speculate about the hormonal milieu and pre­existing glycogen stores that, under some circumstances, will tip certain patients into pathologic ketoacidosis.
The benefits of controlled metabolic access to ketones (i.e., ketogenic diet) have been recently advocated for several conditions. Unfortunately, the timing and triggers for the exact tipping point from controlled to uncontrolled ketone production are not well understood. This chapter will discuss important conditions of uncontrolled ketone production and treatment of this pathologic state.
PATHOPHYSIOLOGY
Ketones may be produced through metabolism of long­chain fatty acids for energy within cells or made within the perivenous hepatocytes and then displaced into the serum for use by cells without mitochondria (i.e., red blood cells). Serum ketones are also used as an energy source for the brain because long­chain fatty acids cannot cross the blood–brain barrier and neurons cannot generate their own ketones. Once generated, ketones can be used as an additional energy source, entering the citric acid cycle as acetyl coenzyme A and taking the place of pyruvate generated through glucose metabolism. Ketone production is typically tightly regulated to prevent excessive ketoacid production and metabolic acidosis. Lower serum levels of
 insulin and ketones coupled with higher levels of cortisol and epinephrine may trigger an increase in ketone production. Regulation of ketone production is complex and incompletely understood. Additionally, the rate of ketone consumption can vary over time (minutes, hours, days) for
 unknown reasons. In general, with the exception of DKA, low levels of insulin are not found in ketoacidotic syndromes.
To understand ketone metabolism, first remember that ketones are made daily by the body for energy, and that production is tightly regulated to limit serum levels (Figure 226­1). The normal blood ketone level is about  milligram/dL. Ketones are metabolized as rapidly as they are formed.
Pathologic states arise when production exceeds metabolism or consumption, resulting in metabolic acidosis. Second, it is important to understand the ketone forms normally present in the human body. Acetyl coenzyme A, an energy source that can enter the citric acid cycle for metabolism, is produced in the liver and then converted to the ketones β­hydroxybutyrate and acetoacetate. These ketones spontaneously decay to acetone, which is a volatile chemical and thus exhaled and detected on the breath. Finally, the ratio of ketone production may vary. Typically, in most conditions
(pathologic or normal physiology), the balance of β­hydroxybutyrate and acetoacetate is relatively equal (1:1), with a little higher concentration of β­ hydroxybutyrate. One notable exception is alcoholic ketoacidosis, where β­hydroxybutyrate exceeds acetoacetate (see below). In all other pathologic ketoacidosis conditions, urinary or serum ketones are present and are necessary to diagnosis pathologic ketoacidosis. Ketones are osmotically active, and an elevation may result in an increased osmolal gap.
FIGURE 226­1. Formation and metabolism of ketone bodies. [Reproduced with permission from Barrett KE, Barman SM, Boitano S, Reckelhoff JF (eds.) Ganong’s
Medical Physiology Examination & Board Review. New York, NY: McGraw­Hill Education; 2018, Fig 1­13.]

Chapter 226: Ketoacidotic Syndromes, Debra Perina; William A. Woods 
. Terms of Use * Privacy Policy * Notice * Accessibility
Ethanol metabolism results in nicotinamide adenine dinucleotide depletion manifesting as a higher ratio of the reduced form of nicotinamide adenine dinucleotide to the nonreduced form. This high ratio also results in increased lactate production, so lactate levels are higher than normal in alcoholic ketoacidosis but not as high as seen in shock or sepsis.
COMMON KETOACIDOTIC SYNDROMES
Identifying the cause of excessive ketone levels producing metabolic acidosis may be complicated. Table 226­1 lists several possible conditions associated with elevated serum ketones. DKA is discussed in detail in Chapter 225, “Diabetic Ketoacidosis,” and toxins are discussed in their specific chapters.
TABLE 226­1
Differential Diagnosis of Ketosis with Metabolic Acidosis
Acidosis Due to Acidosis from an Underlying Ketone­ Acidosis from Chemicals Other Than Ketones; However,
Ketoacidosis Producing Condition Ketonemia May Be Present
DKA (see Chapter 225, “Diabetic Toxic ingestions: Dehydration
Ketoacidosis”) Acetone
Isoniazid
Isopropanol
Propylene glycol
Salicylic acid
Alcoholic ketoacidosis Inborn errors of metabolism: Gastritis/upper GI bleeding
Error in carbohydrate metabolism Hepatitis
Error in fatty acid metabolism Pancreatitis
Pneumonia
Seizures
Sepsis
Renal Failure
Starvation ketosis and eating disorders
Nutritional ketosis
Ketogenic diet
ALCOHOLIC KETOACIDOSIS
Alcoholic ketoacidosis is a condition occurring in alcoholic patients who enter a period of fasting after a dramatic period of ethanol binging. Alcoholic ketoacidosis results in metabolic acidosis and dehydration, with variable levels of serum glucose, depending on the amount of glycogen stored in the
 liver. Serum glucose levels may even be elevated.

Nausea, vomiting, abdominal pain, and constitutional complaints are common. Notably, the ratio of β­hydroxybutyrate to acetoacetate is elevated in both DKA and alcoholic ketoacidosis. However, the ratio is much higher in alcoholic ketoacidosis and may approach 10:1. This is largely due to the presence of more acetoacetate in DKA. Since urine tests for ketones detect acetoacetate only, patients with alcoholic ketoacidosis may have dramatic
 ketoacidosis with low or even undetectable levels of urine ketones. Point­of­care blood testing for ketones primarily measure β­hydroxybutyrate.
STARVATION KETOSIS
The human body goes through various rates of ketone production throughout the normal course of daily activities. During periods of fasting

(overnight) or increased energy demands (exercise), local ketone production increases. As the duration of carbohydrate fasting increases, hepatic ketone production and intracerebral ketone utilization increase. Typically, prolonged fasts of  days are well tolerated in those with adequate endogenous insulin and no other coexisting condition that alters the serum hormonal milieu. “Well tolerated” in this context implies that ketone production does not dramatically exceed metabolic demand, limiting any resultant metabolic acidosis and/or ketonuria with dehydration.
Pregnancy is the most frequently described condition where starvation ketosis may result in excessive ketone production with metabolic acidosis,
 ketonuria, and dehydration. This can occur with only  to  hours of vomiting and inadequate oral intake. Speculations regarding the increased susceptibility include the effect of additional maternal hormones as well as fetal/placental hormone secretion. However, conditions of higher metabolic demand have also been identified as triggers (e.g., breastfeeding, hyperthyroidism). There is a case report of a 16­year­old patient with

Duchenne muscular dystrophy and severe pre­existing malnutrition who developed significant ketoacidosis. In addition, bariatric surgery may pose a
 risk for pathologic ketoacidosis after brief episodes of inadequate intake, secondary to mechanical complications of surgery.
NUTRITIONAL KETOSIS
There are recent suggestions in the medical literature that athletic performance, especially endurance performance, may be enhanced by the ingestion of nutritional supplements rich in ketones in an attempt to alter intracellular energy preference. The safety of this practice is unclear, and it is not
 known if dietary supplements may contribute to pathologic acidosis.
KETOGENIC DIET
The ketogenic diet may be desired for several medical conditions; weight control and seizures are the two most common. Additional conditions
(Alzheimer’s disease and Parkinson’s disease) may warrant future trials of a therapeutic ketogenic diet. In healthy volunteers, the ketogenic diet does
 not routinely induce metabolic acidosis due to ketosis.
TOXIC INGESTIONS
In some toxin ingestions, ketone production is a primary result of the toxin, rather than the cause of the patient’s symptoms. Such ingestions include acetone, aspirin (salicylic acid), isoniazid, isopropanol , methanol, and propylene glycol. Thus, routinely consider toxic overdose as a cause of unexplained ketosis.
INBORN ERRORS OF METABOLISM
Consider inborn errors of metabolism in children with ketosis, especially if associated with hypoglycemia. Children who develop ketosis after a longer
 fast may have a fatty acid oxidation disorder. See Chapter 146, “Metabolic Emergencies in Infants and Children,” for detailed discussion of diagnosis and emergency treatment.
DIFFERENTIAL DIAGNOSIS
Urinary detection of ketones and an increased anion gap diagnose the presence of a ketoacidotic condition. History, physical examination, dietary review, and assessment of comorbidities are necessary to focus the diagnosis. As discussed earlier, lack of elevated urine ketone levels does not
  exclude the diagnosis in cases of alcoholic ketoacidosis. Elevated glucose levels are most commonly described in cases of alcoholic ketoacidosis and less commonly in other causes of pathologic ketoacidosis. There are no published large series of ketoacidotic conditions, so generalizations about serum glucose levels cannot be made.
The conditions listed in column  of Table 226­1 are often associated with significant dehydration and electrolyte disturbances, including hypokalemia,
 hyperkalemia, hypomagnesemia, and hypophosphatemia. Patients with alcoholic ketoacidosis often have underlying liver disease and may have abnormal liver enzyme levels.
Column  of Table 226­1 lists toxic ingestions and inborn errors of metabolism associated with ketonuria and metabolic acidosis. Elevated serum ketones may result from ingestion of an alcohol other than ethanol. Methanol and ethylene glycol ingestions do not produce ketosis, but the acidosis tends to be severe. Isopropyl alcohol ingestion results in production of ketones. The presence of a large osmolal gap suggests acute isopropyl, ethanol, methanol, or ethylene glycol ingestion. If the blood alcohol level is known, then its contribution to any osmolal gap can be calculated. Each
100 milligrams/dL (21.7 mmol/L) of ethanol raises the osmolal gap by . Details of osmolal gap are discussed in Chapter , “Fluids and
Electrolytes.”
The presence of a mixed acid­base disturbance suggests a comorbid disorder (column  of Table 226­1) .
TREATMENT
,5,7,11,12
Treatment of ketoacidosis is supportive. Reestablish intravascular volume. Published series of patients with pathologic ketoacidosis report the need for isotonic volume expansion, and supplemental dextrose is required.
Monitor and correct electrolyte abnormalities. Correct hypomagnesemia. Hypophosphatemia can slow the resolution of acidosis as phosphorus is necessary for mitochondrial utilization of glucose and for oxidation of the reduced form of nicotinamide adenine dinucleotide. However, phosphate
 replacement generally is unwarranted unless levels are very low (<1.0 milligram/dL or <0.323 mmol/L).
Administer supplemental dextrose. Insulin therapy is needed only for DKA, as brisk hypoglycemia can occur when insulin is given to patients with a
 starvation­type ketoacidotic syndrome. In alcoholic or malnourished patients, some feel that thiamine supplementation prior to glucose administration should be given to prevent Wernicke’s encephalopathy and Korsakoff’s syndrome.
Serum ketone levels, correlated with clinical status, may be used to help guide therapy and will decrease as the ketoacidosis resolves, while an increasingly positive reaction in urinary ketones during treatment signifies improvement, as results lag behind clinical status. Acidosis should clear within  to  hours.
For severe ketoacidosis in a patient on a ketogenic diet for seizure control, obtain consultation to weigh the risks and benefits of all aspects of supportive therapy.
DISPOSITION AND FOLLOW­UP
Adults with an uncomplicated ED course may be safely discharged home if there is resolution of acidosis and the patient is able to tolerate oral fluids.
When caring for complicated conditions (e.g., children with hypoglycemia, inborn error of metabolism, therapeutic ketogenic diet, toxic ingestions, medical comorbidities), coordinate care with the primary team treating the underlying disorder. Patients with alcoholic ketoacidosis should receive counseling on alcohol dependence, be encouraged to use multivitamins, and be offered treatment in an alcohol detoxification program. Patients with persistent acidosis or a complicated course will require hospital admission.


