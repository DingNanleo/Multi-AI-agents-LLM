## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 179: Monoamine Oxidase Inhibitors
Frank LoVecchio
INTRODUCTION
Monoamine oxidase inhibitors (MAOIs) were the first class of antidepressants, but current use of these agents is primarily limited to treating atypical
 and refractory cases of depression (Table 179­1). Newer antidepressants have a more favorable side effect profile, less overdose toxicity, and no dietary restrictions. The declining popularity of oral MAOIs for the treatment of depression is partially offset by their increasing use for the treatment of

Parkinson’s disease. In addition, a transdermal method of selegiline administration, approved for use in major depression, appears to avoid some of
3­5 the worrisome aspects associated with traditional oral therapy.
TABLE 179­1
U.S. Food and Drug Administration Approved Monoamine Oxidase Inhibitors
Average Daily Maximum Daily
Agent Indication Formulation Selectivity
Therapeutic Dose Therapeutic Dose
Isocarboxazid Major depression 10­milligram tablet 10–40 milligrams  milligrams Nonselective
Phenelzine Major depression 15­milligram tablet 45–75 milligrams  milligrams Nonselective
Tranylcypromine Major depression 10­milligram tablet 20–40 milligrams  milligrams Nonselective
Selegiline Major depression  milligrams,  milligrams, and   milligrams per 24­h  milligrams per 24­ Nonselective (as a skinmilligrams per 24­h patch patch h patch patch formulation)
Rasagiline Parkinson’s .5­ and .0­milligram tablets .5–1.0 milligram  milligram MAO­B disease
Selegiline Parkinson’s 5­milligram tablet  milligrams  milligrams MAO­B (as an oral disease formulation)
.25­milligram oral disintegrating .25 milligrams .5 milligrams MAO­B (as an oral tablet formulation)
Moclobemide* Major depression, 150­ and 300­milligram tablets 300 milligrams 600 milligrams MAO­A social anxiety
Abbreviations: MAO­A = monoamine oxidase isoenzyme A; MAO­B = monoamine oxidase isoenzyme B.
*Not available in the United States.
Safety and effectiveness of MAOIs in children have not been established, and the four agents used for treatment of depression have the identical U.S.
Food and Drug Administration–mandated black box warning stating that patients <24 years old may have increased suicidal thinking and behavior wDohwilen tloaakidnegd a 2n0y 2ty5p­7e­ o1f 6a:n2t5id Pe p Yreosusar nIPt mise 1d3ic6a.t1i4o2n..159.127
Chapter 179: Monoamine Oxidase Inhibitors, Frank LoVecchio 
. Terms of Use * Privacy Policy * Notice * Accessibility
MAOIs are associated with tyramine reactions, serotonin syndrome, and medication incompatibilities that are unique to this class of antidepressants. Overdoses of MAOIs are considered life­threatening emergencies, and even one pill could potentially kill a toddler. The onset of clinical toxicity is often delayed to between  and  hours after ingestion, which can lead to misdiagnosis and mismanagement.
MAOI antidepressants with improved safety and tolerability, such as moclobemide, are available in Canada, Australia, and Europe, but not the United
States. St. John’s wort (Hypericum perforatum) contains many active ingredients, some of which have the ability to inhibit monoamine oxidase

(MAO) and block serotonin reuptake. St. John’s wort is considered generally safe when taken at recommended dosages, but even modest MAO inhibition may become clinically significant in overdose, contribute to serotonin syndrome, or participate in a drug–drug interaction.
Medications with MAO inhibition as a pharmacologic action unrelated to their clinical indication (e.g., linezolid, procarbazine, furazolidone, and
,8 methylene blue) can precipitate serotonin syndrome when combined with other serotonergic agents.
PHARMACOLOGY
,10
MAO is an intracellular enzyme bound to the outer mitochondrial membrane. It has been identified in most human cells except erythrocytes (which do not contain mitochondria). MAO removes amine groups from both endogenous and exogenous biogenic amines. This oxidative deamination process is the primary mechanism by which endogenous biogenic amines, such as norepinephrine, dopamine, and serotonin, become inactivated. A second important function of MAO is to decrease the systemic availability of absorbed dietary biogenic amines (e.g., tyramine) via hepatic and intestinal metabolism. Thus, inhibition of MAO leads to the accumulation of neurotransmitters in presynaptic nerve terminals (both centrally and peripherally) and increased systemic availability of dietary amines. MAO has a negligible role in metabolizing circulating catecholamines, either secreted endogenously (e.g., by the adrenal gland) or administered parenterally (e.g., epinephrine). Circulating catecholamines are metabolized by the enzyme catechol­O­methyltransferase that is located extraneuronally and is not affected by MAOIs.
MAO exists as two different isoenzymes, designated monoamine oxidase isoenzyme A (MAO­A) and monoamine oxidase isoenzyme B (MAO­B). Each
 isoenzyme has its own relative preference for different neurotransmitters, dietary amines, and inhibitory drugs. During normal physiology, MAO­A is primarily responsible for the breakdown of serotonin and norepinephrine, whereas MAO­B preferentially metabolizes phenylethylamine; MAO­A and
MAO­B have equal ability to metabolize dopamine or tyramine. These preferences are entirely dose dependent and can be overcome at higher substrate concentrations or inhibitor doses (e.g., selegiline).
Overall, the human brain contains more MAO­B, and this predominance increases with advancing age. Dopaminergic neurons lack MAO­B activity and
 have limited MAO­A activity, but significant MAO­B activity is present in surrounding astrocytes and glial cells. Thus, dopamine inactivation depends on astrocyte and glial cell metabolism. Serotonergic neurons exclusively contain MAO­B, which allows more serotonin to be recycled intact while metabolizing other nonserotonin neurotransmitters. Intestinal MAO activity is mostly due to MAO­A, whereas approximately equal proportions of both isoenzymes are found in the liver, affording the body protection against ingested exogenous amines that can cause toxicity (e.g., tyramine reaction).
Blockade of MAO­A in the GI tract is responsible for a severe hypertensive crisis that can occur after patients on MAOIs ingest foods containing the sympathomimetic tyramine, and the use of transdermal formulations may avert these side effects. Tyramine is usually metabolized in the GI tract, but
 the blockade of MAO­A allows it to flow into the general circulation. Although the accepted “MAOI diet” has been liberalized in recent years, there are still several dietary restrictions to which patients on these medications must adhere.
MAOIs share structural similarities with endogenous amines that allow them to act as potential substrates for the enzyme. The antidepressant activity of phenelzine, tranylcypromine, isocarboxazid, and transdermal selegiline has been primarily attributed to their ability to increase norepinephrine and serotonin neurotransmission by increasing presynaptic concentrations of both amines. Their antidepressant effect correlates with >80% MAO­A inhibition. Additional mechanisms by which they exert their therapeutic effects are probably related to delayed postsynaptic receptor modifications
(e.g., downregulation), indirect release of neurotransmitters, and inhibition of neurotransmitter reuptake.
The therapeutic benefit of selective MAO­B inhibitors in Parkinson’s disease is related to increased striatal dopamine neurotransmission and
 protection against neuronal damage from oxidative stress. MAO­B inhibition of >80% correlates with the observed therapeutic effect of selegiline and rasagiline in Parkinson’s disease. At therapeutic doses, there is limited inhibition of MAO­A with modest effects on norepinephrine and serotonin
 metabolism. However, at large doses (e.g., selegiline >20 milligrams/d), increasing MAO­A inhibition increases presynaptic norepinephrine and serotonin concentrations and thus has the potential to produce drug­related toxicity similar to that of the nonselective agents (phenelzine, tranylcypromine, and isocarboxazid).
Traditional MAOIs, such as isocarboxazid, phenelzine, tranylcypromine, rasagiline, and selegiline, form irreversible covalent bonds with the enzyme, rendering it permanently inactive. Once an irreversible inhibitor drug has been discontinued, it takes approximately  weeks before new enzyme
 synthesis restores activity to 50% of normal and up to  days to regain 100% activity. Reversible inhibitors, on the other hand, competitively inhibit enzyme activity. After the reversible inhibitor drug is stopped, MAO function recovers over a period of hours as the drug–enzyme complex spontaneously dissociates. Moclobemide and toloxatone are reversible MAOIs available in most of the world, but not in the United States.
PHARMACOKINETICS
MAOI tablets are absorbed rapidly and completely from the GI tract but have relatively low bioavailability because of a large first­pass effect of hepatic
 metabolism. The skin patch form of selegiline allows for more parent drug to bypass first­pass liver metabolism; this results in elevated blood levels
 with nonselective MAO inhibition and antidepressant activity. The oral form of selegiline has lower blood levels secondary to first­pass effects, retains its MAO­B selectivity, and does not have antidepressant qualities. Metabolism by hepatic cytochrome P450 predisposes MAOIs to potential interactions with other drugs requiring similar hepatic enzyme pathways. Peak drug levels usually occur within  to  hours of ingestion. These drugs are highly protein bound and have relatively large volumes of distribution. Elimination half­life is relatively short, and an important feature of clinical toxicity is that it is usually delayed until well after most of the drug has already been metabolized. Hence, blood levels do not correlate with clinical toxicity.
,12
Selegiline has many active metabolites, including desmethylselegiline, amphetamine, and methamphetamine. Tranylcypromine does not produce amphetamine metabolites at normal therapeutic doses, but amphetamine has been noted in the serum following tranylcypromine overdose.
Phenelzine metabolism results in multiple active metabolites such as β­phenylethylamine, which is metabolized by MAO­B. Rasagiline does not have
 any active metabolites. Transdermal selegiline offers the advantage of continuous absorption over a 24­hour period without any peak effects.
,5
However, its absorption can be drastically increased by external heat application (e.g., sauna, heating pad). The pharmacokinetic profile of most
MAOIs indicates that attempts at extracorporeal removal (e.g., hemodialysis) or administration of repeat doses of activated charcoal would be unsuccessful in significantly reducing plasma drug levels.
DRUG INTERACTIONS
Long­term MAOI therapy predisposes to many potentially significant drug–drug interactions; some have been well established, whereas others are
 based on single case reports or solely on theoretical considerations. Controlled human studies are impossible due to the life­threatening nature of these reactions, and animal studies often have limited applicability to human toxicity. Therefore, emergency physicians should never administer new medications to patients taking MAOIs unless absolutely necessary. Compatibility should always be confirmed before a new drug is administered, and the lowest effective dose should be used.
Drug–drug interactions involving MAOIs can be grouped into two categories: pharmacodynamic or pharmacokinetic. The most common pharmacodynamic reaction involves indirect­acting sympathomimetics. They have the potential to produce a hyperadrenergic condition similar to the tyramine reaction and can be found in over­the­counter preparations, drugs of abuse, and some prescription products. Pharmacokinetic interactions have been noted between certain drugs and MAOIs because these drugs are metabolized through the cytochrome oxidase enzyme system and thus can inhibit the metabolism of each other. A notable example of this type of drug interaction is the ability of ciprofloxacin and cimetidine to inhibit the
 metabolism of rasagiline, which can double its serum concentration. Tranylcypromine and phenelzine have been shown to increase insulin release and predispose to hypoglycemia, especially in patients taking oral sulfonylurea agents.
SEROTONIN SYNDROME
Serotonin syndrome (see Chapter 178, “Atypical and Serotonergic Antidepressants”) is a potentially life­threatening, often iatrogenic reaction. With
MAOIs, serotonin syndrome most commonly occurs when combined with other serotonergic agents. The important principle for emergency physicians is not to use meperidine, dextromethorphan, tramadol, linezolid, propoxyphene, a selective serotonin reuptake inhibitor, or a selective serotonin­norepinephrine reuptake inhibitor in a patient on MAOI therapy. Patients should be warned about concomitant use of illicit drugs in general but especially cocaine, ,4­methylenedioxymethamphetamine (MDMA; popularly known as ecstasy), and methamphetamine. Even after a patient discontinues MAOI therapy,  weeks are required before 50% of MAO enzyme activity returns. In general, selective serotonin reuptake inhibitors and serotonin­norepinephrine reuptake inhibitors should be discontinued for  weeks prior to using an MAOI with the exception of fluoxetine, which should be stopped  weeks before using an MAOI. Consequently, there should be at least a 2­week abstinence period between the time an MAOI is discontinued and when any contraindicated drug is started; this recommendation is particularly important to prevent the development of serotonin syndrome.
Awareness of which medications are generally considered safe for patients taking MAOIs is useful (Table 179­2). Aspirin, acetaminophen, ibuprofen, morphine, and most antibiotics have been used in combination with MAOIs without complications.
TABLE 179­2
Medications Considered Safe in Combination With Monoamine Oxidase Inhibitors* Direct­Acting Sympathomimetics Miscellaneous Drugs
Albuterol aerosol Acetaminophen
Dobutamine Antibiotics (except linezolid and furazolidone)
Epinephrine Barbiturates
Isoproterenol Benzodiazepines
Methoxamine Calcium channel blockers
Norepinephrine Corticosteroids
Terbutaline Lidocaine
Vasopressin Morphine
Nitroglycerin
Nitroprusside
NSAIDs
Phentolamine
Procainamide
*Always use the lowest effective dosage.
CLINICAL FEATURES
MAOIs have a low ratio of toxic to therapeutic dose. This characteristic predisposes patients to significant drug toxicity with ingestions just slightly larger than normal therapeutic doses. For isocarboxazid, phenelzine, or tranylcypromine, acute ingestions of  to  milligrams/kg may produce mild to moderate toxicity, ingestions of more than  to  milligrams/kg can be life threatening, and the lethal dose is
 estimated to be between  and  milligrams/kg. Selegiline overdose experience is extremely limited, but because selectivity is lost after a 30­milligram
 ingestion, it should be assumed to produce toxicity similar to that of the traditional nonselective MAOIs. Rasagiline is a far more selective MAO­B inhibitor than selegiline. It was given to healthy volunteers at doses  times the normal therapeutic dose without any significant toxicity. However, as of this writing, there are no published cases of rasagiline overdose, so prudence dictates that it should be subject to the same precautions as other agents in this class. Toxicity from moclobemide overdose alone is usually mild, even with large ingestions. But when combined with a serotonergic
 agent, serotonin syndrome is common and can be severe.
An important clinical aspect of MAOI overdose is that the appearance of toxic symptoms is characteristically delayed to between  and  hours after ingestion, and the delay can be as long as  hours. The delayed onset of toxicity is attributed to the gradual accumulation of norepinephrine and serotonin in the brain and peripheral sympathetic neurons. Symptoms of MAOI overdose are most consistent with a hyperadrenergic state secondary to excessive stimulation of α­adrenergic and β­adrenergic receptors, but symptoms related to excessive serotonin receptor activity are also seen. Patients receiving long­term therapy may show earlier signs of toxicity due to preexisting enzyme inhibition.
In severe cases, the hyperadrenergic state can be followed rapidly by hypotension and CNS depression resembling a sympatholytic condition. Toxicity usually persists for  to  days after ingestion.
Published descriptions of MAOI toxicity indicate tremendous variation in presentation: there is no “typical” presentation of MAOI toxicity and
,13,15,16 no orderly progression of symptoms. The initial symptoms of overdose are reported to include headache, agitation, irritability, nausea, palpitations, and tremor. The earliest signs of toxicity include sinus tachycardia, hyperreflexia, hyperactivity, fasciculations, mydriasis, hyperventilation, nystagmus, and generalized flushing. In cases of moderate toxicity, opisthotonus, muscle rigidity, diaphoresis, chest pain, hypertension, diarrhea, hallucinations, combativeness, confusion, marked hyperthermia, and trismus may become evident. A peculiar ocular finding
 described as “ping­pong gaze” has been observed in some cases of MAOI toxicity and refers to bilateral wandering horizontal eye movements. The cause for this gaze disorder is unknown, and it resolves gradually as the patient improves.
Severe toxicity is accompanied by coma, seizures, bradycardia, hypotension, hypoxia, and worsening hyperthermia. Hypotension is an ominous finding and is commonly resistant to therapy. Fetal death, intracranial hemorrhage, and cerebral or pulmonary edema have been reported in association with MAOI overdoses. The most common ECG abnormality seen with toxicity is sinus tachycardia, but T­wave abnormalities are
 occasionally seen. Moclobemide overdose may produce QT­interval prolongation but without associated dysrhythmias. Death is usually secondary to multiorgan failure.
DIAGNOSIS
MAOI overdose is a clinical diagnosis based solely on history. Plasma drug levels do not correlate with clinical toxicity, nor are such tests routinely available in most hospital laboratories. Routine urine drug screens do not detect drugs of this class. Selegiline is likely to produce amphetamine metabolites, which can be detected on most urine drug screens. Tranylcypromine has the potential to produce amphetamine metabolites in overdose, but these are rarely detected. Laboratory tests can assist in the differential diagnosis and identify possible complications, including hypoxia, rhabdomyolysis, renal failure, hyperkalemia, metabolic acidosis, hemolysis, and disseminated intravascular coagulation.
Leukocytosis and thrombocytopenia are seen commonly with toxicity.
The differential diagnosis includes drugs and medical conditions capable of producing a hyperadrenergic state, altered mental status, and/or muscle rigidity (Table 179­3). In addition, toxicity can be associated with a sympatholytic presentation. As noted, MAOI toxicity is difficult to diagnose without a history of exposure to the drug.
TABLE 179­3
Differential Diagnosis of Monoamine Oxidase Inhibitor Overdose
Intoxications Medical conditions Adverse drug reactions
Amphetamines Heatstroke Dystonic reactions
Antimuscarinics Hypoglycemia Malignant hyperthermia
Cathinone Hyperthyroidism Serotonin syndrome
Cocaine Pheochromocytoma Tyramine reaction
Methylphenidate Withdrawal states Spontaneous hypertensive crisis
MDMA (3,4­methylenedioxymethamphetamine) Ethanol (delirium tremens) Neuroleptic malignant syndrome
Sedative­hypnotics Malignant catatonia
Phencyclidine Clonidine Infectious diseases
Phenylpropanolamine β­Blockers Encephalitis
Strychnine Meningitis
Theophylline Rabies
Tricyclic antidepressants (early) Sepsis
Tetanus
An elevated blood pressure in a patient receiving long­term MAOI therapy presents a dilemma. At therapeutic doses, hypertension can result from
 tyramine reactions, spontaneous hypertensive crisis, or serotonin syndrome. Tyramine reactions are likely to occur in close relation to ingestion of food or drugs containing indirect sympathomimetics. Spontaneous hypertensive crisis is a rare condition, usually occurring in relation to recent drug
 dosing. Serotonin syndrome most commonly occurs shortly after exposure to other serotonergic agents and usually is associated with significant cognitive­behavioral and neuromuscular abnormalities.
TREATMENT
GENERAL CARE
There are no known antidotes for MAOI toxicity. ED management is therefore directed toward supportive care and early treatment of complications. Place at least one (preferably large­bore) peripheral IV line and a cardiac monitor. Obtain laboratory studies, especially to identify hyperkalemia, metabolic acidosis, and rhabdomyolysis. Onset of toxicity is usually gradual and delayed, sometimes up to  hours after ingestion.
However, the abrupt development of seizures, coma, respiratory insufficiency, hyperadrenergic storm, and cardiovascular collapse is possible. For any given dose of inhibitor, toxicity is predicted to be greater for children, the elderly, and patients with co­ingestants or significant underlying medical problems.

There is no accepted need or best method for GI decontamination in an MAOI overdose. Ipecac syrup is contraindicated. Gastric lavage
,21 is generally not recommended. MAOIs are absorbed rapidly, so delayed gastric lavage or whole­bowel irrigation is unlikely to be of clinical
 benefit. If presentation is within  hour, consider activated charcoal administered as a single dose; however, multidose administration
 is not expected to be useful. Hemodialysis, hemoperfusion, and peritoneal dialysis have no established role in the treatment of MAOI poisoning.
Urinary acidification is not recommended because it is ineffective in enhancing MAOI elimination and predisposes to acute renal failure secondary to myoglobin precipitation within renal tubules.
HYPERTENSION
Treat hypertension only with short­acting IV antihypertensive agents because of the potential for development of precipitous hypotension. In many cases, an intra­arterial catheter is required for accurate blood pressure monitoring. The recommended antihypertensive agents are phentolamine and nitroprusside. Phentolamine is a nonspecific α­adrenergic receptor blocker usually administered in .5­ to .0­milligram IV boluses every  to  minutes until the blood pressure is controlled. It also can be given as a continuous infusion (0.2 to .5 milligram/min) for maintenance therapy.
Phentolamine use is commonly associated with reflex tachycardia.
Nitroprusside is as effective as phentolamine. It is given as a continuous IV infusion starting at a rate of  microgram/kg per minute and is then titrated according to blood pressure response. Prolonged administration of high doses of nitroprusside can predispose to cyanide toxicity, but this potential complication is not relevant to initial treatment. Nitroglycerin is indicated for the relief of anginal chest pain and in patients with signs of myocardial ischemia. β­Blockers pose a theoretical risk of increasing blood pressure (through unopposed vasoconstriction) and are relatively contraindicated.
HYPOTENSION
Hypotension indicates a poor prognosis after MAOI overdose. Give IV normal saline fluid boluses initially. When vasopressors are required, a direct­acting agent such as norepinephrine is preferred, and all indirect­acting agents such as dopamine should be avoided.
Patients receiving long­term MAOI therapy usually demonstrate an increased sensitivity to vasopressors, so use low initial dosages.
DYSRHYTHMIAS
Sinus tachycardia rarely calls for specific drug therapy unless it is producing cardiac ischemia. Lidocaine and procainamide are the most effective antiarrhythmics for treating the ventricular dysrhythmias seen with toxicity. Bradycardia may degrade quickly into asystole in the later stages of toxicity and requires pacemaker placement. Pharmacologic treatment of bradycardia includes atropine, isoproterenol, and dobutamine.
SEIZURES
Benzodiazepines such as lorazepam and diazepam are the anticonvulsants of choice in treating MAOI­induced seizures. Barbiturates such as phenobarbital are as effective as benzodiazepines but may cause hypotension, especially at higher dosages. Phenytoin is generally ineffective in stopping drug­induced seizures. General anesthesia and muscle paralysis may be necessary in cases of status epilepticus to prevent the metabolic acidosis, hyperthermia, and rhabdomyolysis that commonly accompany persistent seizure activity. Muscle paralysis is best accomplished using nondepolarizing neuromuscular blocking agents, because the action of succinylcholine may be enhanced by these MAOIs. Vecuronium is preferred to pancuronium because of the latter’s propensity to produce elevations in heart rate and blood pressure. Electroencephalographic monitoring is required when muscle paralysis is used to control the peripheral manifestations of seizure activity.
HYPERTHERMIA
Antipyretics are not effective in lowering drug­induced fever. Benzodiazepines such as lorazepam or diazepam are useful first­line agents to reduce muscle hyperactivity and thus decrease secondary heat production. Increasing evaporative and conductive heat loss is essential for the successful treatment of drug­induced hyperthermia. This is best accomplished by using cool mist sprays and evaporative fans or cooling blankets. Hyperthermia is often resistant to treatment as long as there is persistent muscle rigidity. Muscle paralysis (using nondepolarizing agents) should be considered when diffuse rigidity is refractory to benzodiazepine therapy. Anecdotally, dantrolene is an effective relaxant in resistant cases of muscle rigidity, given
,25 at a dose of .5 to .5 milligrams/kg IV every  hours, but should only be used when other measures have failed to relieve muscle rigidity.
DISPOSITION AND FOLLOW­UP
All patients with intentional MAOI overdoses or accidental ingestions of isocarboxazid, phenelzine, or tranylcypromine >1 milligram/kg require admission to an intensive care unit or equivalent. Patients with accidental exposures of <1 milligram/kg still require hospital admission but, because they are less likely to develop life­threatening complications, can be admitted to a bed with less frequent monitoring. Consultation with a medical toxicologist and regional poison control center is strongly recommended.
Asymptomatic patients should be monitored for at least  hours before discharge. Dietary and medication restrictions should be followed meticulously during the hospitalization. All patients should be instructed to avoid contraindicated foods and medications for a minimum of  weeks after MAOI drug exposure. Patients who require transfer to hospitals with intensive care units should be transferred as soon as possible to avoid the problems anticipated with delayed onset of toxicity. All patients being transferred should be accompanied by medical personnel capable of performing advanced life support and airway management. Even a single MAOI tablet may produce life­threatening drug interactions under the right circumstances.
TYRAMINE REACTION
,26,27
Tyramine is an exogenous dietary amine that is normally metabolized by intestinal and hepatic MAO. Tyramine can be found in small amounts in many foods but is present at much higher levels in aged, cured, smoked, pickled, or fermented dietary products. The body normally has multiple levels of protection to prevent tyramine and other similar exogenous amines from entering the systemic circulation, but this protection is lost once the normal activity of MAO­A is inhibited by >80%. Therefore, all nonselective inhibitors predispose to tyramine reactions; however, tranylcypromine is associated more frequently with tyramine reactions than either phenelzine or isocarboxazid. Selective MAO­B inhibitors and reversible inhibitors are associated with a much lower incidence of tyramine reactions because they leave intestinal and hepatic MAO­A unaffected to metabolize tyramine.
Selegiline (MAO­B selective) is unlikely to produce a tyramine reaction if taken in oral form at therapeutic doses, but at elevated doses, its selectivity is lost and it functions the same as the nonselective inhibitors. Dietary restrictions are unnecessary with rasagiline because of its greater selectivity for

MAO­B at therapeutic dosages and transdermal preparations of MAOIs.
Tyramine is structurally similar to amphetamine and is classified as an indirect sympathomimetic. Like most indirect sympathomimetics, tyramine enters the presynaptic neuron through amine uptake pumps. Once inside the neuron, indirect sympathomimetics are capable of releasing presynaptic stores of norepinephrine and, to a lesser degree, serotonin and dopamine. Tyramine also can displace epinephrine from the adrenal gland. A similar effect occurs with ingestion of foods that contain large amounts of dopamine, such as broad (fava) beans. It has been reported that <30% of patients taking MAOIs adhere to the recommended tyramine­restricted diet. In addition, approximately 4% to 8% of adherent patients experience a tyramine reaction during their course of therapy. Many of the previously restricted food sources are no longer considered dangerous, and newer guidelines call for avoiding only a few high­risk food groups such as meats or fish that are not fresh, sauerkraut, aged meats and cheeses, alcohol (tap or
,26,27 unpasteurized beers), pickled fish (herring), concentrated yeast extracts, banana peels, soy sauce, tofu, and broad beans.
CLINICAL FEATURES
The tyramine reaction is typically of rapid onset, occurring within  to  minutes of ingestion of the dietary amine. The severity of this reaction is highly variable and is partially related to the total amount of tyramine ingested. The hallmark symptom of the tyramine reaction is a severe occipital or temporal headache. Other associated symptoms include hypertension, diaphoresis, mydriasis, neck stiffness, pallor, neuromuscular excitation, palpitations, and chest pain. Most symptoms resolve gradually over  hours without specific therapy, but fatalities have been reported in rare cases, usually due to intracranial hemorrhage or myocardial infarction.
TREATMENT
An ECG should be obtained for all patients with tyramine­associated chest pain. Focal neurologic findings or a persistent, severe headache warrants investigation with a CT scan.
In cases of severe hypertension, the recommended drug is phentolamine, given as .5­ to .0­milligram IV doses every  to  minutes until the blood pressure is controlled. The half­life of phentolamine is approximately  minutes, and its duration of action is <1 hour. Nitroprusside is another rapidly acting direct vasodilator that is administered as a continuous IV infusion (1 to  micrograms/kg per minute). In cases of moderate hypertension, nifedipine and prazosin have been reported to be effective. β­Adrenergic blockers are contraindicated because of unopposed α­receptor stimulation.
DISPOSITION
Hospital admission should be strongly considered for patients whose symptoms do not resolve completely within  hours of onset. Patients who are asymptomatic after  hours of observation can safely be discharged home.


