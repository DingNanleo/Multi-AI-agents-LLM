## Page 1

University of Pittsburgh
Access Provided by:

Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 5: Disaster Preparedness
Robert G. Hendrickson; B. Zane Horowitz
INTRODUCTION
Disasters have claimed millions of lives and cost billions of dollars worldwide in the past few decades. Examples of large­scale disasters include the terrorist attacks of September 11, 2001; the 2004 Pacific Ocean tsunami; the 2010 earthquake in Haiti; the 2011 earthquake and tsunami in Japan; the
2015 earthquake in Nepal; Superstorm Sandy of 2012; and the refugee and civil war crises in Africa. Emergency physicians frequently have extensive responsibilities for community and hospital­level disaster preparedness and response. Planning for these may include smaller­scale disasters such as active shooters, explosions, building fires, or transportation accidents, and increased patient volume from predictable events (e.g., storms, blizzards, floods, large gatherings for major sporting events or music festivals, or protests of large scale with anticipated violence). This chapter discusses the definition of a disaster, disaster preparedness and planning, the hospital emergency operations plan, field disaster response, and the ED disaster response.
DISASTER DEFINITION
The World Health Organization defines a disaster as a sudden ecologic phenomenon of sufficient magnitude to require external assistance. A disaster is an event that overwhelms the resources of the region or location in which it occurs. Furthermore, a hospital disaster may similarly be defined as an event that overwhelms the resources of the receiving hospital. A hospital disaster may be of any size and is not limited to mass casualty incidents. A single patient who ingested an organic phosphorous pesticide may overwhelm the resources of a hospital if that hospital is not prepared to decontaminate external to the ED. A single patient with suspected smallpox or a single influential patient (e.g., world leader or a celebrity) may use so many ED resources that it affects the care of other patients.
Whether an event is a disaster further depends on the time of day, nature of the injuries, type of event, and the amount of preparation time before the arrival of patients. The ED “surge capacity” (ability of the ED to care for more patients than is typical) may be severely limited by hospital overcrowding.
When it appears that the normal procedures of an ED may be interrupted by an event, there must be policies and procedures in place to activate a disaster response, direct the mobilization of personnel and equipment, and permit the rapid triage, assessment, stabilization, and definitive care of victims.
TYPES OF DISASTERS
Disasters are subdivided into several categories (Table 5­1). External disasters occur at locations that are physically separate from the hospital (e.g., transportation accident, industrial accident). An internal disaster is an event that occurs within the confines of the hospital (e.g., bomb scare, laboratory accident involving radiologic agents, power failure). Disasters can be both internal and external
(e.g., earthquake with mass casualties as well as damage to the internal hospital). Further discussions of disasters are provided in the following chapters: Chapter 6, “Natural Disasters”; Chapter 8, “Chemical Disasters”; and Chapter 9, “Bioterrorism.”
TABLE 5­1
Types of Disasters
Disaster
Definition Examples
Type
Natural Disaster caused by a naturally occurring event Earthquakes, tsunamis, tornadoes, hurricanes/typhoons, volcanic
Downldoiasadsetedr 2025­7­1 4:6 P Your IP is 136.142.159.127 eruption, pandemic influenza
Chapter 5: Disaster Preparedness, Robert G. Hendrickson; B. Zane Horowitz 
. Terms of Use * Privacy Policy * Notice * Accessibility
Man­made Nonnatural events that are not purposefully produced Vehicle crashes (e.g., car, plane, bus), mass casualty events, disaster explosions, fires, industrial accident/chemical release
Terrorist­ Events that are purposefully produced in an effort to cause Events of September 11, 2001, as well as intentional chemical, related terror biological, radiologic, or toxin releases disaster
Internal An event that occurs within the hospital Hazardous materials spill in hospital laboratory, fire or explosion disaster within hospital, power failure
External An event that occurs external to the hospital Transportation accident, industrial accident disaster
Acute disaster Disaster that occurs in a narrow and well­defined time frame Explosion, industrial release, earthquake
Nonacute Disaster with no well­defined start point or continuous Pandemic infectious disease, incremental release of a biological or disaster production of casualties over a broad time frame toxin (e.g., anthrax sent through mail)
DISASTER CHARACTERISTICS
Regardless of the cause, most disasters have common characteristics that are important for disaster preparedness and planning. In an acute disaster, or a disaster with an identifiable time of onset that produces casualties (e.g., explosion, chemical release, fire, earthquake), the event is followed by a
1,2 large number of minimally injured patients presenting to the nearest hospitals, usually without prehospital triage or evaluation. This is typically
3 followed by prehospital transport of the most affected patients to the same hospitals. Initial patients can be expected within minutes, and peak
2,3 volumes can be expected at 2 to 3 hours after the event. The vast majority (~80%) of patients are not transported by prehospital agencies, but instead
2­4 self­transport by car, van, police vehicle, cabs, foot, or any means available to the nearest ED. Even in acute events, ED volumes tend to remain
3 elevated for days to weeks after events. In nonacute events, such as a pandemic of an infectious disease, ED volumes have a slower onset of surge, but
ED and hospital volumes remain elevated for extended periods.
Based on previous events, common factors that may hinder ED response are listed in Table 5­2. TABLE 5­2
Factors That May Hinder ED Response to Disasters
Poor communication between ED and disaster scene
Poor communication within the hospital (e.g., ED to emergency operations center, emergency operations center to patient care areas)
Inability to control volunteer healthcare personnel who are unfamiliar with the ED function and their roles in disaster response
Inability to engage and control convergence of media to the ED
Inability to engage, control, and direct visitors who are searching for loved ones
Inability to control large numbers of patients (i.e., crowd control)
Difficulty maintaining high staffing needs for extended periods
DISASTER PREPAREDNESS AND PLANNING
Planning for any type of disaster consists of common elements. A hospital disaster planning group is responsible for generating the hospital’s emergency operations plan. Include a diverse membership of hospital employees and decision makers. Table 5­3 lists some potential members and their roles. The group should meet on a regular basis to assess hazards, develop and update short­ and long­term disaster plans, plan exercises and training, and redesign the disaster plan based on evaluations of exercises and real events.
TABLE 5­3
Hospital Planning Group
Hospital Planner Role in Disaster Planning and Response
Public safety Crowd control, hospital lockdown, and hospital access control
Facilities/engineering Evaluate structural damage and advise on stability of facilities
Logistics/equipment Provide supplies/equipment; arrange for rapid ordering of additional supplies supply
Pharmacy Provide pharmaceuticals, antidotes, and antibiotics; arrange for rapid ordering of additional pharmaceuticals
Transportation Assist with patient transport
Clinical fields A wide array of clinical fields should be represented, including representatives from the ED, primary specialties (internal medicine, family medicine, pediatrics), and surgical specialties
Media/public Act as single point of contact for media; liaise between media and clinical areas, emergency operations center, and other hospital relations resources
Communications Coordinate communication to employees during a disaster through e­mail, website, paging groups, phone, or social media officer
Nonclinical patient Housekeeping and food services care
Safety officer Determine and ensure safe practices for employees (e.g., appropriate personal protective equipment for decontamination)
Radiation safety Prepare plan for and respond to radiologic emergencies officer
Infection control Prepare for and respond to infectious disease emergencies officer
The general components of the disaster plan include hazard vulnerability analysis, hospital–community coordination, integration with national response assets, and training and disaster exercises. Develop specific plans (for radiation, explosions, mass casualties, decontamination) based on an assessment of the potential disasters in the area as well as study of the events that would cause the most disruption to the ED and hospital.
HAZARD VULNERABILITY ANALYSIS
The hospital planning group should address those disasters that are most likely to occur in their community and geographic area. For example, planners on the West Coast of the United States may make earthquake planning a priority and those on the Gulf and Atlantic coasts may prioritize hurricane planning. Give consideration to the proximity of population centers to chemical release threats (military chemical weapons depots, large
5 industrial sites, or transportation hubs). Industrial sites that store large volumes of potentially harmful chemicals are required by Title III of the
Superfund Amendments and Reauthorization Act to participate in local emergency planning committees. Industries are required to report spills of potentially harmful chemicals, and the approximate location of these sites may be found at http://toxmap.nlm.nih.gov. Terrorist­related disasters may be prioritized in hospitals that are in proximity to sites that may be significant terrorist targets. Include factors such as proximity to transportation facilities (e.g., ports, airports) as well as locations where large numbers of people collect (e.g., festivals, stadiums, arenas) with the risk assessment.
The hazard vulnerability analysis can prioritize planning efforts because different disasters are characterized by different morbidity and mortality patterns and different challenges to the ED and hospital. For example, earthquakes may cause severe traumatic injuries requiring a concentration on surge capacity of the critically ill patient. Rescue operations may last several days. Unique needs, such as dialysis for renal failure for multiple crush injury victims, may need to be considered. Natural disasters often cause large numbers of homeless or displaced persons whose everyday medical needs are exacerbated by limited access to usual health care, as occurred after Hurricane Katrina. Chemical releases may require mass decontamination as well as large numbers of ventilators, oxygen, and specific antidotes that are not typically available in large quantities.
HOSPITAL–COMMUNITY COORDINATION
Every hospital should integrate its emergency operations plan with those of community disaster management agencies. This is especially important regarding disaster notification and communications, transportation of casualties, and provisions for dispatch of hospital medical teams to a disaster site. Strong relationships with community agencies (e.g., fire department, regional EMS system, local emergency management, or public health agency) are important to ensure a coordinated disaster response. There are a large number of community agencies that have some responsibility for disaster planning and response (Table 5­4).
TABLE 5­4
Community Agencies Involved in Disaster Planning
Community Agency Responsibilities
Federal Bureau of Investigation Incident command if a federal crime may be involved
FEMA Incident command in public health disaster
State governor Authority to declare health emergency; requests federal assistance (e.g., FEMA); responsible for public safety
State health department Authorized by governor to coordinate disaster response
State emergency management State­level equivalent of FEMA association
City/county health department May have jurisdiction for local disasters (variable); may be initial incident command for local health disasters
EMS Patient triage in field; decontamination in field (if necessary); stabilization and transfer to definitive care facility
Fire service Overall scene command in an acute disaster; victim rescue and hazard control
Police service Traffic management and scene security in an acute disaster
Public works Support equipment and personnel; structural safety expertise
Hazardous materials (HAZMAT) teams Initial incident command at scene of hazardous materials spill/exposure
Abbreviation: FEMA = Federal Emergency Management Agency.
Other organizations that a hospital may interact with during the disaster planning process include the military, local chapters of the American Red
Cross, local emergency planning committees, Citizen Corps Councils, and other volunteer agencies, along with state and federal agencies (e.g.,
National Disaster Medical System, Metropolitan Medical Response System, Centers for Disease Control and Prevention). Medical planning in a community is usually the responsibility of local and state health departments and EMS councils.
INTEGRATION WITH NATIONAL RESPONSE ASSETS
Some of the important federal response resources are listed in Table 5­5. During a response, these agencies may play pivotal roles and may interface and coordinate with hospitals and emergency physicians.
TABLE 5­5
Federal Response Resources
Agency Role
U.S. Public Health Service/Office of Emergency Response; Office within DHHS. Management and coordination of federal health and http://www.phe.gov/preparedness/pages/default.aspx medical activities related to preparation, response, and recovery from major emergencies or presidentially declared disasters.
Metropolitan Medical Response System Enhance local emergency preparedness systems by promoting coordination
For more information: www.ncbi.nlm.nih.gov/books/NBK220762/ between local responders (e.g., police, fire, hazardous materials agencies,
EMS, hospitals).
National Disaster Medical System; Asset­sharing program between DHHS, Federal Emergency Management https://www.phe.gov/Preparedness/responders/ndms/Pages/default.aspx Agency, U.S. Department of Defense, U.S. Department of Veterans Affairs, and public/private organizations—developed to provide surge capacity for natural disasters, wartime military casualties, and large­scale bioterrorism events.
DMAT; Multidisciplinary teams that deploy in response to federally declared https://www.phe.gov/preparedness/responders/pages/default.aspx disasters and emergencies to support a local jurisdiction’s response. Teams include physicians, nurses, medics, pharmacists, and logisticians.
National Disaster Medical System Response Teams; Specialty teams, based on the DMAT concept, developed to respond to https://www.phe.gov/preparedness/responders/pages/default.aspx chemical, biological, and radiologic events.
Disaster Mortuary Operational Response Teams; Teams that respond to federally declared disasters and emergencies to https://www.phe.gov/preparedness/responders/pages/default.aspx support a local jurisdiction’s ability to process large volumes of deceased patients.
Centers for Disease Control and Prevention; http://www.cdc.gov Centers within DHHS. Lead federal agency in developing and applying disease prevention and control. Advisory agency in bioterrorism response.
CDC Outbreak Response Teams Teams of CDC epidemiologists to assist with local efforts in investigating potential outbreaks, confirmation of cases and exposures, and environmental clean­up.
Laboratory Response Network; https://emergency.cdc.gov/lrn/index.asp Network that links local and state public health laboratories to advancedcapacity laboratories, including military, chemical, veterinarian, agricultural, water, and food testing labs.
National Notifiable Diseases Surveillance System; National public health surveillance system.
http://wwwn.cdc.gov/nndss/script/nedss.aspx
Health Alert Network; http://emergency.cdc.gov/han/ System that allows for rapid early warning broadcast alerts to health departments for potential emerging infectious diseases or outbreaks.
Strategic National Stockpile; Two­part system designed to provide local jurisdictions with medications, http://www.cdc.gov/phpr/stockpile/stockpile.htm vaccines, and equipment during a disaster.
Prepackaged cache—delivered within 12 h in the U.S.
Situation­specific cache—delivered within 36 h in the U.S.
Federal Bureau of Investigation Lead federal agency for crisis management. Has authority to conduct law enforcement investigations into acts of terrorism.
Abbreviations: CDC = Centers for Disease Control and Prevention; DHHS = Department of Health and Human Services; DMAT = Disaster Medical Assistance Teams.
TRAINING AND DISASTER EXERCISES
Regular training and exercises familiarize staff with their disaster roles and responsibilities and identify weaknesses or omissions in the plans that require additions or revisions. Exercises can range from full­scale, community­wide simulations, with moulage (use of makeup or theater techniques to represent injuries) victims, to tabletop triage scenarios, mini­exercises that test only certain components of the disaster plan (such as call­up of personnel), and tests of communications. The Joint Commission requires two annual exercises at least one of which involves the movement of patients. The scenarios should reflect incidents that are likely to occur in the community as determined by the hazard vulnerability analysis.
HOSPITAL EMERGENCY OPERATIONS PLAN
The hospital emergency operations plan provides for an organized response of the hospital from the time of notification of a disaster until the situation normalizes (Table 5­6).
TABLE 5­6
Components of the Hospital Emergency Operations Plan
Component Function
Activate emergency operations plan Notify and mobilize personnel and equipment
Set up emergency operations center Nerve center for hospital response and communication with outside agencies
Assess hospital capacity Determine safety of hospital itself; determine capabilities of hospital in all units
Create surge capacity Determine ways to handle the maximum number of patients
Establish communication systems Develop multiple and redundant systems, including cellular phones, satellite phones, two­way radios, runners
Provide supplies and equipment Deliver available supplies to proper areas and plan for resupplying or obtaining other needed materials
Establish support areas Volunteer, media, and family information centers
Establish decontamination, triage, and Decontamination, triage, resuscitation, acute care, and minor care areas; surgical triage and holding; treatment areas psychiatric area; morgue
Terminate disaster response and provide Return personnel and supplies to normal activity; provide emotional support for caregivers; improve for remediation emergency operations plan for future incidents
Functions include activation of the emergency operations plan, establishment of an emergency operations center, assessment of hospital capacity, surge capacity planning, communications, supply and resupply, triage and treatment of casualties, establishment of support areas, and termination of the disaster state to allow for recovery and the return to normal activities.
ACTIVATE THE EMERGENCY OPERATIONS PLAN
Clearly delineate the roles and responsibilities of all employees in the ED and any employees who may respond to the ED in the planning process; those roles must be clearly listed and easily accessed in the event of a disaster. Clarify the reasons for activation of the emergency operations plan. Activation of the emergency operations plan should provide for the immediate mobilization of supplies, equipment, and personnel.
ESTABLISH EMERGENCY OPERATIONS CENTER
The Incident Command System is a standard emergency management system used throughout the United States to provide a flexible command and
6 control structure upon which to organize a response. The Incident Command System is generally used when there is an identifiable single scene for a disaster event, such as the site of a plane crash. By standardizing an organizational structure and using common terminology, the Incident Command
System provides a management system that is adaptable to incidents involving a multiagency or multijurisdictional response. At the most basic level, there are five main components to the organizational structure: (1) incident command, (2) operations, (3) planning, (4) logistics, and (5) finance. With this type of organizational infrastructure and the flexibility to expand and collapse as needed, an orderly and efficient response to any incident can theoretically be implemented.
The Hospital Emergency Incident Command System is modeled after the Incident Command System. Upon declaration of a disaster, an emergency operations center within the hospital should be established in a predesignated area. This center should be able to communicate with the ED and triage area and with external authorities (regional EMS, police, fire, and public health agencies). There should be a primary emergency operations center as well as a secondary site to be used in the event that the primary site is damaged or inaccessible. Provisions for multiple redundant modes of communication should be made. Other responsibilities of the emergency operations center include opening up additional hospital wards or clinics, obtaining outside assistance, evacuating endangered patients, assigning staff to treatment areas, and terminating the disaster mode of operation.
ASSESS HOSPITAL CAPACITY
Before the hospital can receive casualties, it must be determined if the hospital itself has sustained any structural damage or loss of use as a result of a disaster. These include blocked passageways or inoperable elevators; potential for fire, explosion, or building collapse; failure of utilities; loss of equipment or supplies; contamination of water; and outside access problems. This damage assessment is usually the responsibility of the hospital safety officer or engineer. If the hospital’s structural integrity has been compromised, it may be necessary to initiate the evacuation plan to evacuate staff and patients.
Once it is determined that the hospital itself is safe, the hospital should determine how many casualties from the disaster site it can safely manage. This may be limited by available personnel, beds, operating room and intensive care unit capacity, and supplies, as well as by the type of disaster and the availability of other community resources. At the time of disaster notification, it is necessary to know the status of many of the hospital’s capabilities: how many beds are available, how much critical supplies and medications are available, how many personnel are on duty, what structural damage has occurred, how many operating rooms are in use, which clinicians are present in the hospital, and so forth.
CREATE SURGE CAPACITY
Surge capacity is the ability to increase hospital bed capacity over normal limits. Intrahospital surge may include doubling patients in rooms, converting an acute care ward to an intensive care level unit, opening previously closed wards, or caring for patients in typically nonclinical locations, such as the hallway or cafeteria. Interhospital or regional surge may include discharging hospitalized patients to an external low acuity unit, either
7,8 mobile or fixed, and altering standards of care (typically a role of the state governor and legislature and only during governor­declared disasters).
The standards of care should be altered only in the most extreme circumstances, as patient surge has been linked to somewhat worse outcomes for
9 individual patients.
ESTABLISH COMMUNICATIONS SYSTEMS
Establishment of good communications is critical in any disaster or mass casualty situation. Even the best disaster plans fail without wellestablished communications systems. Unfortunately, experience shows that this essential function is difficult to achieve for a variety of reasons. Many communication modes become inoperative during a disaster. Cellular telephones, in particular, are often overwhelmed in disasters. Disaster planning must include a multitiered plan for intrahospital (blackboard, two­way radios, messengers/couriers) and interhospital (citizen band groups, cellular telephones, satellite telephones, two­way radios) communication.
SUPPLIES
During a disaster, necessary supplies and equipment must be ready for immediate distribution to appropriate locations in the hospital. Each hospital will need to estimate the amount of supplies that will be needed in stock over and above their regular hospital supply. Unfortunately, due to “just in time” stocking, most U.S. hospitals do not have a surge of supplies that may be used in a disaster. The Centers for Disease Control and Prevention has arranged a series of medication push­packs throughout the United States that can be delivered to any area of disaster within 12 hours
(https://www.cdc.gov/phpr/stockpile/index.htm). Once delivered, additional time is necessary to unpack the supplies and deliver the supplies to individual hospitals. The regional/local disaster plan must include a mechanism to unpack the push­packs, determine the hospitals in greatest need of individual items, divide the push­pack contents, and deliver the supplies to the hospital. This logistical issue makes it necessary for most hospitals to rely on their own supplies for a period of at least 96 hours.
ESTABLISH SUPPORT AREAS
Family Information Center
During a disaster, families and friends will arrive at the hospital seeking information about victims. This convergence can seriously interfere with efforts of the hospital to respond effectively to the situation. For this reason, predesignate a separate area for family members seeking information.
This area may also be used to discharge in­hospital patients and treated disaster victims.
Volunteer Coordination Center
In major disasters, anticipate the potential for large numbers of volunteers, including those wishing to donate blood. Although some of these people may have appropriate clinical skills, they are unlikely to be familiar with the hospital functions and could be more hindrance than help. A separate place should be identified to handle these volunteers and, if appropriate, credential and decide how they may best be used. This area should include all equipment and personnel that are required to perform emergency credentialing (if appropriate and necessary).
Media Center
Identify a single hospital spokesperson to relay information to the media. This public information officer ideally should have some training in handling media questions and making clear statements to the press and public. Similar to the family information center, the media briefing room should be set up away from clinical care areas so that the press does not negatively impact on medical care while seeking a story. Direct members of the media to this area, and closely supervise their access to any treatment area by utilizing security personnel and either the hospital administrator or public information officer.
DECONTAMINATION, TRIAGE, AND TREATMENT
Certain areas of the hospital must be designated for specific functions, including decontamination, triage, care of major and minor casualties, presurgical holding and surgical triage, psychiatric care, and morgue facilities. The plan should be quite specific as to the function of these areas, staffing requirements, and basic supplies to be used.
Decontamination

Perform decontamination in an area that is outside of the clinical care area of the ED. Typically, this area is located external to the ED, but may be in internal locations. Use the decontamination facility to remove clothing and cleanse the skin and hair of patients exposed to a chemical or
10 radioisotope (Table 5­7). Provide patient coverage and protection from the environment. Make sufficient personal protective equipment available for hospital staff assisting with decontamination.
TABLE 5­7
Decontamination Guidelines
Decontaminate patients exposed to solids, liquids, vapors, or mists.
Patients exposed only to a fully dispersed gas need to be assessed for pulmonary symptoms and systemic toxicity and do not require decontamination. When uncertain if a substance is a gas or actually a vapor or mist, decontamination should occur.
Hospital personnel should have the initial ability to decontaminate one patient at a time with a shower or hose system while setting up a larger tent or a multiple­person decontamination system.
Perform decontamination outside of the ED in a way that prevents patients from entering the ED before decontamination.
Hospital personnel require level C personal protective equipment while performing decontamination. Higher levels of protection are not necessary and should only be used by hospitals that follow stringent training protocols and criteria, and use only personnel who have been specifically trained to use the equipment. Sufficient equipment for multiple personnel and rotations of personnel in and out of the decontamination zone every 30 min are suggested.
The first and a very effective method for decontamination is to disrobe, brush off solid dusts or powders, and wash and dry the face. Patient clothing and belongings should be individually bagged and labeled. Watches, earrings, body piercings, jewelry, and contact lenses should be removed. Hearing aids should be wiped with a moistened cloth and may be returned to patients after the decontamination procedure because the need to hear instructions outweighs any risk of wearing the hearing aid.
Warm water is the universal decontamination fluid. Hosing a patient from head to toe (or showering) for 5 min will decontaminate most ambulatory patients.
Patients with adherent materials will need additional scrubbing of hair and affected body parts with soap to remove these; medical assistance will be necessary in some circumstances. An additional check to ensure the removal of all earrings and body piercings should be done.
Young children need assistance and reassurance and should be decontaminated with the aid of a parent or guardian who can hold and reassure the child while medical personnel perform the decontamination.
After the decontamination procedure, provide hospital clothing (cloth or paper gowns) and triage patients to an area to await further assessment.
Retriage patients with eye pain after whole­body decontamination for individual irrigation of their eyes with sterile normal saline. Patients with contaminated wounds will likely need additional irrigation of debris in wounds.
Contain runoff water from the decontamination to prevent environmental contamination.
Critical medical devices (infusion pumps, hearing aids, ostomy bags, etc.) may remain with the patient unless a high­risk chemical has been identified.
Wash canes and walkers with soap and water or diluted household bleach and return to patients to ensure their mobility.
At least one radiation survey meter (e.g., Geiger­Müller counter) and staff that are trained in its use are necessary for events that potentially involve radioisotopes. Patients may need a radiation survey sweep before and after decontamination, and further decontamination may be needed until levels reach background radiation levels.
Staff involved in the decontamination process and systems need annual training and practice drills. Share an assessment of strengths and weakness learned from each drill with hospital personnel to improve preparedness and performance.
Triage
Restrict patient entry to only one location—the triage area. The primary functions of a disaster triage area are rapid assessment of all incoming casualties or ill patients, patient registration and identification, the assignment of priorities for management, and distribution of patients to appropriate treatment areas in the ED and hospital.
Treatment
Patient care in disasters requires alteration of scale and sometimes location of clinical care, but staff should perform the clinical roles that are familiar to them. Several exceptions to this rule may exist (decontamination); however, in general, staff are more efficient at performing typical tasks quickly than learning new tasks in real time.
Organize patient care stations so that clinicians who are familiar with the assessment and treatment of the clinical problems may staff them. One suggested method of organizing patient care stations includes “resuscitation” and “minor treatment” areas.
RESUSCITATION
From the triage location, most, if not all, of the seriously injured patients will be sent to the resuscitation area (trauma and cardiac resuscitation, treatment of hypovolemic or septic shock, severe respiratory distress). This is usually physically located in the ED and staffed by emergency physicians. Other areas that may be used include direct to operating room or postoperative recovery room triage.
PRESURGICAL HOLDING AREA AND SURGICAL TRIAGE
Send trauma patients who are initially stabilized in the ED to the presurgical holding area for preoperative preparation and observation. The number of operating rooms that can be staffed is the main limiting factor in the provision of definitive care for a large number of severely injured casualties. The most experienced surgeon available should take the responsibility to prioritize cases and to rapidly assign surgeons to individual cases.
MINOR TREATMENT AREA
In most disaster situations, the majority of patients are not very seriously injured. These low­acuity patients can be sent to an “urgent care” area for definitive care, including splinting of fractures, primary closure of lacerations, tetanus prophylaxis, and observation for delayed symptoms. This minor treatment area can be established in the hospital’s outpatient clinics and staffed by the clinic physicians.
MENTAL HEALTH
In the event of a disaster involving mass casualties, and even property damage with loss of possessions, it is common for patients to present with
11 episodes of anxiety and depression, or exacerbations of their psychiatric disorders. Agitated patients, visitors, or staff can be extremely disruptive to hospital disaster operations. Consider a separate isolated area to receive individuals in need of psychological intervention. Include consideration for assessing patients and hospital staff who are psychologically affected by the disaster. Consider providing a critical stress response team, including social workers and psychiatrists, to provide support and critical stress debriefing.
MORGUE FACILITIES
Disasters can result in a large number of fatalities. Morgue capacities may need to be expanded to other areas of the hospital (medical school anatomy area, auditorium), enhanced by mobilization of local freezer trucks (this must be prearranged during the planning stage), or enhanced by federal assets (Disaster Mortuary Operational Response Teams). Viewing of deceased patients should take place here, not in treatment areas.
TERMINATING DISASTER RESPONSE (RECOVERY)
As soon as appropriate, direct efforts toward returning the hospital to normal operations. Besides restocking and cleaning, give consideration to the emotional stress experienced by both the EMS and hospital staff. Critical incident stress debriefing can reduce the psychological impact of these events on medical responders and offer immediate emotional support to healthcare workers. Data from previous experiences suggest that such intervention
12 can assist providers in maintaining job performance and satisfaction, resulting in improved patient care. Provide all members who participated in the disaster, not just medical personnel, the opportunity to participate in critical incident stress debriefing.
Carefully record and review deficiencies in a hospital’s disaster plan that are revealed during a disaster, and write an after­action report. Take immediate steps to correct these flaws in the plan.
FIELD DISASTER RESPONSE
Elements of field disaster response are field triage and medical care, communications, distribution of casualties, and management of on­site disaster medical teams.
FIELD TRIAGE AND MEDICAL CARE
In the field, rescue personnel often use a simple triage and rapid treatment technique that depends on a rapid assessment of respiratory status,
13,14 perfusion, hemorrhage control, and mental status. Patients are then triaged to immediate care, delayed care, or dead/dying. Subsequently, determining how much and what type of care to administer at the disaster site depends on several factors. If the number of patients is small and there are sufficient prehospital personnel and transportation resources available, on­site medical care can proceed in a fairly normal manner, with rapid stabilization and transportation to nearby hospitals. When extrication will be prolonged, interventions such as fluid resuscitation and pain control should be instituted in the field. On the other hand, early, rapid transportation with a minimum of treatment should be practiced when there is danger to rescuers and casualties from fire, explosion, falling buildings, hazardous materials, and extreme weather conditions.
When patients are likely to have significantly delayed transport from a scene (e.g., number of casualties exceeds transportation capacity or damage to hospital infrastructure), the “Secondary Assessment of Victim Endpoint” triage system may be helpful to
15 identify patients who are most likely to benefit from the care available under austere field conditions. The Secondary Assessment of
Victim Endpoint triage system is intended to triage patients into categories that reflect a balance between resource use and probability of survival.
Category 1 includes patients who will die regardless of how much care they receive. Category 2 includes patients who will survive whether or not they
15 receive care. Category 3 includes patients who will benefit significantly from austere field interventions.
COMMUNICATION—DISASTER SITE TO HOSPITALS
The local emergency communications or emergency operations center should alert hospitals in the affected area of possible mass/multiple casualty situations or disasters. This report should include the total number of injured, the number of seriously injured (who may need intensive care unit capability), and the number for whom ambulatory treatment is sufficient. Hospitals should report to the local emergency communications center the following information: bed availability, number of casualties received thus far, number of additional casualties that the hospital is prepared to accept, and specific items in short supply.
DISTRIBUTION OF CASUALTIES TO RECEIVING HOSPITALS
Maintain good communication between hospitals and on­site EMS command in order to minimize unequal distribution of victims. Alert the onscene incident commander immediately of a potentially overloaded hospital. In this situation, the less injured and more stable can be sent a farther distance to outlying hospitals.
Casualties with special problems, such as major burns, carbon monoxide poisoning, spinal cord injuries, or victims of chemical or biological terrorism, may need to be transferred directly to specialized units, although it may not be possible for these units to accept a large number of ill or injured. For that reason, develop regional plans to allow for the care of specialty patients in nonspecialty hospitals.
MANAGEMENT OF ON­SITE DISASTER MEDICAL TEAMS FROM HOSPITALS
On­site disaster medical teams dispatched from local hospitals may be of value in situations in which victims require prolonged extrication; transportation routes are blocked, preventing easy evacuation to hospitals; or the number of casualties is of such magnitude that they exceed transportation capacities. Dispatch such a team with great caution. Physicians and nurses function optimally in an in­hospital setting. Few, however, are prepared to work under austere field conditions. Such hospital­based teams should probably not come from the ED staff until back­up staff has arrived to care for patients arriving from the disaster site or who are already present. Explicitly describe how such personnel are placed in action in the hospital emergency operations plan and coordinate with state and local agencies through memoranda of understanding.
Carefully map out the resources for such field response teams on a regional basis. At least one institution from each region should maintain an on­site triage team of physicians and nurses. The designated hospital should store disaster triage kits containing essential resuscitation and stabilization equipment for field use.
ED DISASTER RESPONSE
INITIAL RESPONSE
When a call is made to the hospital indicating the occurrence of a disaster or potential mass casualty–producing event, the incident must be verified by the appropriate predesignated official, who then puts the emergency operations plan into effect. In some events, the first sign of a disaster may be patients arriving at the hospital. In this case, contact the regional emergency communications center to notify the regional hospitals of the impending disaster and initiate the emergency operations plan.
This sets a series of activities into motion. The information obtained from the call is given to the charge nurse; the nursing and medical personnel in the ED are notified of the impending arrival of casualties; and the ED’s plan for calling additional staff is activated. If hospital telephone communications have been completely disrupted, ED personnel may have to be reached by radio, cellular phone, e­mail, or television announcement.
In many disasters, cellular phone and text messaging systems are quickly overwhelmed. Alternatively, a calling station remote from the hospital, such as at the residence of an administrator, physician, or nurse, may be able to handle this extensive calling job without taxing the hospital’s phone system.
An initial needs assessment is conducted by the nurse and/or physician in charge, given the information available. They should evaluate the current status of the patients in the ED and make the appropriate disposition decisions. The ED physician or charge nurse becomes the on­site incident commander until the plan­designated incident commander arrives. Among the decisions to be made are those related to the admission, discharge, or transfer of patients, and decisions about the priority of patient care. Discharge all nonemergency patients from the ED with responsible individuals.
Based on the initial assessment, the number of patients that the department can receive is determined and communicated to the prehospital disaster communications center. The nurse and the physician in charge then assign staff to those areas in the department to be used during the disaster.
Take all available litters and wheelchairs to the ambulance entrance immediately on announcement of the disaster status. Patients from the disaster site are met at the receiving area by hospital escorts who assist the emergency medical technicians in transferring patients to wheelchairs or stretchers.
Place essential equipment, such as endotracheal tubes, IV fluids, cervical collars, splints, and bandages, near the ambulance entrance to permit convenient restocking of the ambulance (when plans call for ambulance restocking from hospitals) and rapid return to the disaster site.
SECURITY
Hospital security diverts nonessential vehicles and ensures a smooth, one­way flow of traffic to the ambulance entrance. Once patients, family, and
4 media arrive, security is also responsible for protecting the treatment areas and inhibiting unplanned entry into the hospital.
TRIAGE
3,4
Triage establishes priorities for care and determines the clinical area of treatment. Many seeking help will arrive independent of the EMS system.
Triage will need to be performed at the ED entrance even if it was done at the scene.
Triage category is identified by use of a colored band or trauma/disaster tag that is placed on the patient to document that triage has been done.

The approach to patient evaluation and treatment is quite different when dealing with disaster situations that result in high casualties. To accomplish the most good for the most number of patients, the triage team should evaluate all patients arriving at the ED and classify their condition with regard to severity of injury and need for treatment. Some principles of medical care must be altered to achieve the best overall result. Patient care at triage should be limited to manually opening airways and controlling external hemorrhage.
The most common triage classification in the United States still involves assigning patients to one of four color­coded categories
(red, yellow, green, or black), depending on injury severity and prognosis (Table 5­8) . In addition to the nature and urgency of the patient’s systemic condition, triage decisions should be sensitive to factors affecting prognosis, such as age, general health, and prior physical condition of the patient, as well as the qualifications of the responders and the availability of key supplies and equipment.
TABLE 5­8
Triage Categories
Red
First priority
Most urgent
Life­threatening shock or hypoxia is present or imminent, but the patient can likely be stabilized and, if given immediate care, will probably survive.
Yellow
Second priority
Urgent
The injuries have systemic implications or effects, but patients are not yet in life­threatening shock or hypoxia; although systemic decline may ensue, given appropriate care, patients can likely withstand a 45­ to 60­min wait without immediate risk.
Green
Third priority
Nonurgent
Injuries are localized without immediate systemic implications; with a minimum of care, these patients generally are unlikely to deteriorate for several hours, if at all.
Black
Dead
No distinction can be made between clinical and biological death in a mass casualty incident, and any unresponsive patient who has no spontaneous ventilation or circulation is classified as dead. Some place catastrophically injured patients who have a slim chance for survival regardless of care in this triage category.
Catastrophically injured patients who have a minimal chance for survival despite optimal medical care should be classified as “expectant” (“black”: to include patients with burns involving 95% body surface area, and patients in full cardiac arrest or septic shock). Devoting time and resources to patients who are not likely to live jeopardizes other patients who are truly salvageable. The goal with these “expectant” patients should be adequate pain control and the opportunity to be with friends and family.
TRIAGE TEAM
A team consisting of an emergency physician, an ED nurse, and medical records or admitting clerks should receive every patient. In extraordinary situations, several triage teams may be required to handle the casualty load. Acknowledge the physician performing hospital triage as being in command of the triage area (clearly identified by a specially colored vest or other garment) and understanding all triage options.
Assign one member of the triage team (admitting or medical records clerk) the job of recording the victim’s name on the disaster tag along with the triage destination within the hospital. If identification of the patient is not available, ethnicity, gender, and approximate age should be noted on the tag.
An initial diagnostic impression should also be registered on the tag. This information is entered into a department log or into the electronic medical record, if possible. In some patient tracking systems, a scan of the bar code on the disaster tag may allow for immediate registration by disaster tag number and open an electronic medical record. Additional care can be recorded in the electronic medical record or in a paper disaster chart and kept with the patient at all times and later scanned into the electronic medical record.
ED DISASTER PATIENT CARE
Disaster care concepts often vary from the typical ED routine. Care that is not immediately time sensitive can be provided the next day. For example, wounds may benefit from delayed closure after copious irrigation due to delayed presentations or gross contamination. In the event of prolonged extrication from rubble, assess for delayed signs and symptoms, including cardiac dysrhythmias, hyperkalemia from crush injury, renal failure, and pulmonary blast injury.

Terrorist­related or industrial explosive events may lead to medical conditions or exposure to chemicals that are not familiar to clinicians. Patients may require prolonged observation (e.g., exposure to phosgene or ricin) or unique testing. For infectious exposures, the Centers for Disease Control and Prevention and local/state public health agencies can guide testing, observation time, and treatment. Immediately contact the local public health agency if a biological terrorist agent or a rare and potentially fatal infectious disease is seen or suspected in the ED. In the event of a chemical agent, the regional Poison Center (1­800­222­1222) can provide information and guidance on whether decontamination is necessary, as well as testing, observation time, and antidotal or supportive treatment. Fact sheets on biological, chemical, and radiologic agents are available at
4,17 http://www.cdc.gov.
Use radiographic and laboratory studies sparingly, if at all, in a mass casualty situation, and only if the results of such tests will change treatment. For example, possible closed, nonangulated fractures can be splinted, and radiographs can be safely delayed for 24 to 48 hours. A chest radiograph may be appropriate in patients complaining of chest pain, dyspnea, or abnormal chest wall motion, or who were potentially exposed to blast waves secondary to bombs. CT imaging may be quicker than plain radiographs in some injuries, and prioritization to CT may be required. Ultrasonography to detect free intraperitoneal fluid, pericardial fluid, and pneumothorax is time­ and cost­effective and has been used in earthquakes to triage operative
18 care.
With the exception of identification of biological and chemical agents, there are few indications for laboratory testing in disaster medicine. If testing will change management, use point­of­care testing to expedite care. For example, obtain a baseline hematocrit and type and cross­matching for blood in cases of hemorrhagic shock. Pulse oximetry monitors may need to be used as spot assessments, rather than continuous bedside monitoring of a single patient. Consider laboratory studies to be accessory and ordered only in specific circumstances (carboxyhemoglobin in cases of smoke inhalation).
In a disaster situation involving many casualties, the blood bank should have up to 50 units of blood available and should have access to volunteer donors who can be rapidly mobilized. Potential donors include friends and family members of patients, as well as mildly injured patients.


