## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 220: Mushroom Poisoning
Anne F. Brayer
INTRODUCTION AND EPIDEMIOLOGY
Mushrooms are a common toxic exposure, with an average of 7428 exposures per year from 1999 to 2016, with 62% of cases in children <6 years of
   age. Approximately  exposures per year result in major harm, averaging three deaths per year. Liver failure is the most common serious harm.
,2
Fortunately, the majority (86%) of reported mushroom exposures have a benign outcome. There are no easily recognizable differences between nonpoisonous and poisonous mushrooms. Mushroom toxins are not heat labile and so are not destroyed or deactivated by cooking, canning, freezing, drying, or other means of food preparation.
Depending on the type of mushroom, adverse effects from ingestion range from mild GI symptoms to major cytotoxic effects resulting in organ failure and death. Toxicity varies based on the amount ingested, the age of the mushroom, the season, the geographic location, and the way in which the mushroom was prepared prior to ingestion. One person may show significant effects, whereas others may be asymptomatic after ingesting the same mushroom (Table 220­1). Mushroom toxicity is divided into early toxicity (within  hours after ingestion) and delayed toxicity (6 hours to  days later).
TABLE 220­1
Mushrooms: Symptoms, Toxicity, and Treatment
Symptoms Mushrooms Toxicity Treatment
GI symptoms
Onset <2 h Chlorophyllum Nausea, vomiting, diarrhea (occasionally bloody) IV hydration molybdites Antiemetics
Omphalotus illudens
Cantharellus cibarius
Amanita caesarea
Onset 6–24 h Gyromitra Initial: nausea, vomiting, diarrhea IV hydration, glucose; monitor AST, ALT, bilirubin, esculenta Day 2: rise in AST, ALT levels BUN, and creatinine levels, prothrombin time, partial
Amanita Day 3: hepatic failure thromboplastin time phalloides For Amanita: multiple­dose activated charcoal
Amanita Consider N­acetylcysteine 150 milligrams/kg loading bisporigera dose (see text)
Consider penicillin G, 300,000–1,000,000 units/kg/d
Silymarin, 20–40 milligrams/kg/d, where available
Consider cimetidine, 4–10 grams/d
Consider transfer to a center with active liver
 transplant program (see text)
Chapter 220: Mushroom Poisoning, Anne F. Brayer 
. Terms of Use * Privacy Policy * Notice * Accessibility
Muscarinic Inocybe SLUDGE syndrome (salivation, lacrimation, urination, Supportive; atropine, .02 milligram/kg (minimum syndrome Clitocybe defecation, GI hypermotility, and emesis) dose .1 milligram, maximum dose  milligram),
Onset <30 min repeated as needed for severe secretions
CNS excitement Amanita Intoxication, dizziness, ataxia, visual disturbances, Supportive; sedation with benzodiazepines (e.g.,
Onset <30 min muscaria seizures, tachycardia, hypertension, warm dry skin, dry lorazepam .05 milligram/kg, maximum dose 
Amanita mouth, mydriasis (anticholinergic effects) milligrams) pantherina
Hallucinations Psilocybe Visual hallucinations, ataxia Supportive; sedation with benzodiazepines, external
Onset <30 min Gymnopilus cooling
Disulfiram reaction Coprinus Headache, flushing, tachycardia, hyperventilation, Supportive; IV hydration, β­blockers for
2–72 h after shortness of breath, palpitations supraventricular tachycardia mushroom, and Norepinephrine for refractory hypotension
<30 min after alcohol
Renal compromise Cortinarius spp GI symptoms initially, followed by flank pain, polyuria, Supportive; monitor urine output, renal status,
Amanitia anuria, delayed renal transplant; IV hydration smithiana β­Blockers for supraventricular tachycardia
Norepinephrine for refractory hypotension
Dermatitis Shiitake Whip­like, linear, erythematous wheals, blanching Oral antihistamines, .1% triamcinolone ointment
1–2 d after erythematous patches, scattered petechiae, pruritus twice daily; spontaneously resolves within 1–3 wk ingestion
Abbreviations: ALT = alanine aminotransferase; AST = aspartate aminotransferase.
Mushroom poisoning occurs in four main groups of individuals: young children who ingest poisonous mushrooms inadvertently, wild mushroom foragers, individuals attempting suicide or homicide, and individuals looking for a hallucinatory “high.” Identification of the mushroom ingested may be difficult and time consuming. Very often, foragers mix different species of mushrooms together, so it is not always clear that the species being identified is the same one that was ingested. Therefore, direct treatment by a patient’s symptoms rather than by attempts at mushroom identification.
In a patient with a history of mushroom ingestion and ongoing symptoms, observe or admit the patient until symptoms and signs resolve and end­organ damage is excluded, or the mushroom has been clearly identified as nontoxic. Treatment for mushroom
 poisoning is based on case reports and small series.
Nearly all fatalities in the United States and Europe occur from ingestion of mushrooms of the Amanita species (Amanita phalloides, Amanita virosa,
 and Amanita bisporigera). If Amanita ingestion is suspected, identification of the species may be helpful, but is difficult because there are many
Amanita mushrooms that are nontoxic. Amanita species generally have warts on the cap (remnants of the membrane covering the emerging mushroom), which give it a spotted appearance. The gills are “free,” ending before the stem begins. The stem characteristically has a membrane ring around it and widens as it enters the soil. In most cases, the stem of the mushroom is contained in a cup or volva, which may be underground (Figures
220­1, 220­2, and 220­3).
FIGURE 220­1. Amanita muscaria. [Photo used with permission of Jilber Barutciyan.]
FIGURE 220­2. Amanita pantherina. [Photo used with permission of Jilber Barutciyan.]
FIGURE 220­3. Amanita phalloides. [Photo used with permission of Jilber Barutciyan.]
EARLY­ONSET GI SYMPTOMS
PATHOPHYSIOLOGY
Most wild mushroom ingestions cause mild GI irritation, and mushrooms that cause GI irritation can be of many types. In North America and in almost
 every country, Chlorophyllum molybdites is particularly common and is sometimes mistaken for an Amanita. Many little brown mushrooms found commonly in lawns, and often accidentally ingested by children, are in this category. Omphalotus, Boletus, Entoloma, Gomphus, Hebeloma, Lactarius, and Verpa genera are other examples for this group (Figure 220­4). The actual toxin varies with the species of mushroom, but most toxins are poorly described.
FIGURE 220­4. Omphalotus olearius. [Photo used with permission of Jilber Barutciyan.]
CLINICAL FEATURES

The majority of mushroom­induced intoxications are mild and do not prompt a visit to the ED. C. molybdites, however, is an exception that may cause
 severe symptoms. Typically, patients present with acute onset of vomiting and diarrhea <2 hours after ingesting the mushroom. There may be intestinal cramping, chills, headaches, and myalgias. Diarrhea is usually watery, but occasionally bloody with fecal leukocytes. Most commonly, symptoms are mild and self­limited. Symptoms usually resolve within  hours but may last up to several days. Vomiting and diarrhea can cause dehydration and electrolyte imbalance. The presentation may be confused with acute gastroenteritis or acute food poisoning if the patient does not offer the history of mushroom ingestion.
TREATMENT
Treat with activated charcoal, supportive care, and antiemetics. Give activated charcoal .5 to .0 gram/kg PO within the first hour of
 ingestion. There is no role for prophylactic decontamination therapy of asymptomatic patients. Provide IV fluid and electrolyte replacement when
 necessary. Antiemetics can be given, but do not give antidiarrheal agents, because they may prolong exposure to the toxin. In most cases, symptoms are self­limited, resolving within  to  hours. Some cases of Amanita smithiana ingestion present with early GI symptoms (between 
 minutes and  hours) and can progress to renal failure within  to  days. Therefore, patients with toxicity or persistent symptoms should have laboratory evaluation for liver or renal dysfunction and observation for worsening.
Once vomiting has subsided and the patient is tolerating oral fluids, discharge from the ED is safe. Rarely, symptoms may persist and hospitalization may be needed for fluid and electrolyte replacement. Recommend outpatient follow­up within  days, and provide return precautions (urinary
 changes, lumbar or flank pain).
EARLY­ONSET NEUROLOGIC SYMPTOMS
PATHOPHYSIOLOGY
Several classes of mushrooms cause neurologic symptoms. These include the hallucinogenic mushrooms (“magic mushrooms”) that contain the
 chemical psilocybin, which is rapidly dephosphorylated by alkaline phosphatase to the more psychoactive chemical psilocin. Psilocin acts on serotonergic neurons in the CNS, causing effects similar to those of lysergic acid diethylamide. Mushrooms of the Psilocybe genus, which are the most commonly ingested in this class, are small brown or gold mushrooms that commonly grow on dung in warmer climates throughout the Pacific

Northwest and southeastern United States as well as warm regions of Central America, South America, Asia, and Australia. They characteristically turn a greenish blue when bruised or cut. Nontoxic mushrooms may also be laced with phencyclidine or lysergic acid diethylamide and sold as hallucinogenic mushrooms.
Mushrooms containing the isoxazole derivatives ibotenic acid and muscimol also possess neurologic effects, which are thought to be mediated by γ­ aminobutyric acid and anticholinergic activity. Amanita muscaria is the principle representative of this group of mushrooms and is easily identified
(Figure 220­1). It has an orange or red cap with white warts (remnants of the universal veil present in young specimens), as well as a ring (annulus) and cup (volva) on the stem. Amanita pantherina, another member of the group, is  to  cm in length and diameter, with a white to brown cap, and has the ring and cup on the stem (Figure 220­2). Both specimens grow under trees in woodlands throughout North America.
CLINICAL FEATURES
Symptoms typically develop within  hours of ingestion of hallucinogenic mushrooms. Euphoria, a heightened imagination, a loss of the sense of time, and visual distortions or hallucinations are common. Tachycardia and hypertension may be noted because of the presence of
 phenylethylamine in psilocybin­containing mushrooms. Fever and seizures have been reported in rare cases. Symptoms generally last  to  hours
 but can persist up to  hours. There are infrequent reports of flashbacks for up to  months after ingestion, particularly in association with other
 substances that alter cognition such as alcohol or marijuana.
Patients ingesting isoxazole­containing mushrooms usually present with symptoms within  minutes of ingestion. Signs of muscarinic poisoning are the first apparent (nausea, vomiting, diarrhea, vasodilation, diaphoresis, salivation). These are replaced by an atropine­like symptom complex about
 minutes after ingestion (mydriasis, xerostomia, elevated temperature, increased blood pressure), along with drowsiness, amentia, dizziness, photosensitivity, euphoria, motor hyperactivity, ataxia, muscle jerking, hallucinations, and delirium with difficulty with perception of size, time, and place. Seizures have been reported in children. Draw laboratory studies to assess liver and kidney function. Symptoms are typically self­limited, resolving within  to  hours after ingestion. Headache and fatigue are reported to occur the day following ingestion, with headache lasting up to a few
 weeks.
TREATMENT
Treatment for ingestion of hallucinogenic mushrooms is largely supportive. Place the patient in a darkened, quiet room, devoid of visual stimuli, and provide reassurance. If sedation is required, benzodiazepines such as diazepam or lorazepam are preferred. Do not give anticholinergic agents because they may aggravate delirium.
Treat symptomatic ingestion of isoxazole­containing mushrooms with activated charcoal. In patients with severe vomiting and diarrhea, replace fluids and electrolytes. Appropriately restrain patients who are agitated, and provide sedation as necessary with benzodiazepines (diazepam or lorazepam).
Treat seizures with benzodiazepines.
Consider treatment with physostigmine only for patients with severe anticholinergic symptoms. Physostigmine can produce bradycardia, hypotension, and seizures. The dose is  to  milligrams IV in adults and .01 to .03 milligram/kg IV in children, administered slowly. Monitor continuous cardiorespiratory effects and blood pressure during administration. Base the decision to discharge from the ED on duration of symptoms and need for ongoing pharmacologic sedation or intubation.
EARLY­ONSET MUSCARINIC SYMPTOMS

Muscarine was the first mushroom toxin to be identified. Mushrooms of the Inocybe and Clitocybe genera are common causes of muscarinic poisoning (Figure 220­5). The Inocybe mushrooms are small brown mushrooms with conical caps, typically found under hardwoods and conifers.
The Clitocybe mushrooms are usually found individually on lawns and in parks and are white to gray, with a cup­shaped cap. A. muscaria, despite its name, contains far less muscarine than these other groups and only rarely causes cholinergic poisoning symptoms. Isoxazole­containing mushrooms can cause transient muscarinic symptoms early after ingestion.
FIGURE 220­5. Clitocybe candicans. [Photo used with permission of Jilber Barutciyan.]
PATHOPHYSIOLOGY
Muscarine is a parasympathomimetic compound that is heat stable and acetylcholine like. It is not degraded by cholinesterase and, therefore, has a
  long duration of action. Acetylcholine receptors on the heart, apocrine glands, and smooth muscle are activated by muscarine. Mushrooms containing muscarine cause neurologic symptoms and muscarinic or cholinergic effects.
CLINICAL FEATURES
The symptoms of muscarinic intoxication are characterized by the SLUDGE syndrome (salivation, lacrimation, urination, defecation, GI hypermotility, and emesis). In addition to the SLUDGE syndrome, patients with muscarine ingestions can develop diaphoresis, muscle fasciculations, miosis, bradycardia, and bronchorrhea. Symptoms typically present within  minutes of ingestion and spontaneously resolve in  to  hours. Draw laboratory studies to assess for liver and kidney function.
TREATMENT
Treatment includes atropine and supportive care. In most cases, muscarinic symptoms are mild and self­limited. Supportive care is sufficient.
Because emesis is a common presenting symptom, activated charcoal administration is often difficult. Patients with severe vomiting may require IV fluid and electrolyte replacement.
Atropine is an antidote for muscarinic symptoms and can be administered to patients with severe symptoms. It can be effective in treating bradycardia and hypotension unresponsive to IV fluid administration. Atropine is helpful in the treatment of diaphoresis, increased oral secretions, and bronchorrhea. It may also help reduce GI cramping, emesis, and diarrhea. The dose is .5 to .0 milligram IV for adults and .02 milligram/kg IV for children (minimum dose, .1 milligram; maximum dose,  milligram). The dose can be repeated as necessary to control bronchorrhea, bradycardia, or hypotension. Large doses may be necessary to treat severe toxicity. Patients should be carefully monitored during administration. Oxygen and inhaled
β­agonists (albuterol) are recommended for the treatment of patients with increased pulmonary secretions and bronchospasm.
Symptoms of muscarinic poisoning frequently resolve within  hours of ingestion, and many patients can be safely discharged from the ED after observation when symptoms have subsided and clinical and laboratory parameters are normal.
DELAYED­ONSET GI SYMPTOMS
Mushrooms of two different genera, Gyromitra and Amanita, cause significant toxicity, which characteristically presents several hours after ingestion.

Gyromitra esculenta (the false morel) is an uncommon cause of poisoning in North America, but is more common in Scandinavia and Europe. G.
esculenta has a brown convoluted top resembling a brain and is often mistaken for the highly sought­after morel mushroom. A. phalloides and A.
bisporigera are common in the Northern Hemisphere and are found throughout the West Coast, Midwest, and parts of the Northeast of the United
States. Immigrants may mistake these mushrooms for edible varieties common in eastern Asia. Mushrooms of the Amanita genus are responsible for
95% of deaths associated with mushrooms, primarily due to liver failure and acute kidney injury. Toxic ingestions in North America occur most commonly in the autumn.
PATHOPHYSIOLOGY
Gyromitrin (N­methyl­N­formylhydrazone) is a volatile heat­labile toxin and primarily responsible for symptoms. Gyromitrin concentration decreases
 significantly after boiling and desiccation. Gyromitrin is hydrolyzed in the stomach to form N­methyl­N­formylhydrazine and N­methylhydrazine. N­
Methylhydrazine binds to pyridoxine and interferes with enzymes that require pyridoxine as a cofactor. γ­Aminobutyric acid is lowered in the CNS, which may be a cause of associated seizures. N­Methyl­N­formylhydrazine is converted into a free radical in the liver and causes local hepatic necrosis
 by blocking the activity of the cytochrome P450 system, glutathione, and other hepatic enzyme systems. These two chemicals explain the CNS and hepatic dysfunction characteristic of gyromitrin toxicity. The cause of the initial GI symptoms is not known.
A. phalloides contains several phallotoxins and amatoxins. Phallotoxin is a bi­cyclic peptide that alters the enterocyte cellular membrane, thereby
 causing early GI symptoms. Its effect is limited to the GI tract, because it is not absorbed by the intestine. Amatoxins are bi­cyclic octapeptides that are rapidly absorbed through the intestinal mucosa. They are carried to the liver and undergo enterohepatic circulation, which results in prolonged toxin
 exposure after ingestion. Nine amatoxins have been identified, but α­amanitin (amanitin) appears the most physiologically active. Kinetic studies in
  humans show that α­amanitin is cleared from the plasma within  hours. Free radical formation may also be involved in toxicity. α­Amanitin has the greatest effect on cells that undergo rapid protein synthesis and turnover, including cells of the GI tract mucosa, hepatocytes, and renal tubular
  epithelium. In adults, the dose that causes 50% mortality is .1 milligram/kg of body weight, which is commonly contained in a single mushroom.
Pathologic changes are noted in both gyromitrin and amatoxin toxicity. Patients who ingest gyromitrin­containing mushrooms show diffuse hepatocellular damage and interstitial nephritis. Patients who ingest amatoxin­containing mushrooms show fatty degeneration of the liver, with intranuclear collection of lipids and extensive hepatic necrosis. Electron microscopy shows vacuolization of the mitochondria and clumping of the chromatin in the nucleoli. There are extensive lipid peroxidation changes in both the nucleus and the cytoplasm.
CLINICAL FEATURES
The distinctive characteristics of gyromitrin­containing mushroom toxicity are intense GI signs and symptoms (nausea, vomiting, and watery diarrhea) that develop  to  hours after ingestion, typically between  and  hours.
Hypovolemia is common during this phase of toxicity. In severe cases, hepatic failure is evident on day  and may result in death as early as day . Serum transaminase levels may be significantly elevated. Hypoglycemia occurs during the GI phase and again in the acute hepatic failure phase.
Initial GI symptoms can be accompanied by dizziness, headache, seizures, incoordination, and muscle cramps. The initial GI symptoms resolve within 
 to  days. In a mild ingestion, the neurologic symptoms persist for several days and resolve without sequelae.
Patients who ingest amatoxin­containing mushrooms also have delayed onset of GI symptoms (6 to  hours). The gastroenteritis is intense, often requiring fluid and electrolyte replacement. There are four stages in amatoxin poisoning. The first (latent) stage is characterized by the absence of any signs or symptoms and lasts up to  hours after ingestion. During the  to  hours of the second stage, GI symptoms such as intense cramping abdominal pain, nausea, vomiting, and diarrhea dominate the clinical picture. Both stools and vomitus may become bloody. Although right upper quadrant tenderness and hepatomegaly may be noted, results of liver function tests are usually normal. Patients who present during this stage are frequently misdiagnosed with gastroenteritis. The third, or convalescent, phase lasts  to  hours. During this stage, the patient feels and looks better, but levels of liver enzymes, such as aspartate aminotransferase, alanine aminotransferase, and bilirubin, begin to rise, heralding the onset of liver damage and need for continued monitoring. Renal function may also deteriorate. In the fourth and final stage, which begins  to  days after ingestion, transaminase levels rise dramatically, and liver and renal function deteriorate. Hyperbilirubinemia, coagulopathy, hypoglycemia, acidosis,
 hepatic encephalopathy, and hepatorenal syndrome are noted.
In both Gyromitra and Amanita toxicity, prothrombin time may be elevated and unresponsive to administration of vitamin K or fresh frozen plasma.
Amylase and lipase elevation suggests pancreatic damage, although symptomatic pancreatitis is rare. Abnormal laboratory findings in amatoxin poisoning include a decrease in neutrophils, lymphocytes, and platelets, and abnormal thyroid function results. Hypophosphatemia (primarily noted in children), hypocalcemia, and elevated insulin levels occur. None of these laboratory abnormalities correlates with clinical disease, and their cause is unknown.
The mortality from Gyromitra ingestion is estimated at 15% to 35% and is generally attributed to hepatic failure, renal failure, or fluid and electrolyte
 disorders. More recently, mortality has been reduced to 10% to 15%, because of improved care for hepatic failure and liver transplantation. Patients who survive severe hepatic failure from amatoxin may develop signs of chronic active hepatitis with persistent elevation in liver transaminase levels, development of anti–smooth muscle antibodies, and presence of cryoglobulins. No prolonged effects from gyromitrin toxicity have been reported.
DIAGNOSIS
The diagnosis of gyromitrin toxicity is generally assumed from the clinical features and the identification of the mushroom ingested, either by the patient or from samples. Identification of Amanita species generally requires a trained mycologist. The Meixner colorimetric test is used to look for the presence of amatoxin. A drop of fresh mushroom pulp, methanol extract from dried mushrooms, or gastric material is placed on a high­lignin paper (e.g., newspaper) and allowed to dry. A drop of 10­N or 12­N hydrochloric acid is then applied to catalyze the reaction of the amatoxin with the lignin in the paper. The area will turn blue within  to  minutes if amatoxins are present, but the appearance of color may be delayed up to  minutes
 if the amatoxin concentration is low. Although the test is sensitive, it is not very specific, and other nontoxic mushrooms may give a positive test result.
Tests using thin­layer chromatography, high­performance liquid chromatography, and radioimmunoassay have been developed to detect amatoxin.

Unfortunately, these assays are not generally available to clinicians and are used most often in research settings. Amatoxin can be detected in plasma, urine, GI tract contents, and feces. However, its presence merely confirms amatoxin poisoning. Levels do not appear to correlate with clinical severity, and amatoxin is not detected in many patients, presumably because of rapid clearance.
TREATMENT
General treatment includes activated charcoal; continued monitoring for hypoglycemia, hepatic failure, renal failure, and coagulopathy; and supportive care. Administer activated charcoal to patients presenting with severe vomiting and diarrhea within a few hours of mushroom ingestion. Repeated doses of charcoal for at least the first  hours may be effective, particularly in the presence of amatoxin (because it
 undergoes enterohepatic circulation). Fluid and electrolyte replacement is mandatory. Glucose level should be monitored and glucose replaced as needed. Hypoglycemia is one of the most common causes of death in early mushroom toxicity.
All patients who have ingested amatoxin­ or gyromitrin­containing mushrooms (or suspected) should be closely monitored for  hours for the development of hepatic and renal failure. Electrolyte levels, liver enzyme levels, and prothrombin time should be monitored several times a day. Patients should be treated with a low­protein diet and should receive standard supportive therapy for hepatic failure. Fresh frozen plasma and vitamin K can be used for the treatment of prolonged prothrombin time, but in many cases, coagulopathy does not respond to treatment.
Patients who develop hepatic failure should be monitored closely, and in severe cases, preparations should be made for liver transplantation.
Although no firm criteria exist, progressive coagulopathy, encephalopathy, and renal failure despite maximal medical therapy are frequently listed
 indications for emergency liver transplantation. Consultation with a transplant center specialist is warranted for patients with aspartate aminotransferase level of ≥4000 IU/L.  Many patients have met these criteria and survived without transplantation, and many patients have died without meeting these criteria. Liver transplantation, however, does provide the only option for patients in fulminant hepatic failure and has been quite successful.
Gyromitrin­Specific Treatment
Treat the neurologic symptoms associated with gyromitrin with high­dose pyridoxine. Pyridoxine provides the cofactor required for the regeneration of γ­aminobutyric acid. High doses of pyridoxine,  milligrams/kg IV over  minutes up to a maximum of  grams/d, are recommended, but doses of
,22 pyridoxine in excess of  grams are associated with severe peripheral neuropathy. Pyridoxine does not affect the development or course of hepatic failure, and there is no specific therapy for gyromitrin­induced hepatic failure.
Amatoxin­Specific Treatment
Although multiple modalities have been tried in the past with mixed results, activated charcoal, Silybum marianum, and N­acetylcysteine are
,20,23 emerging as the best­supported treatment modalities. Early in the clinical course, repeated dosing of activated charcoal is thought to be beneficial by reducing the absorption of amatoxin as it undergoes enterohepatic circulation. S. marianum, a milk thistle isolate, is also thought to prevent toxicity by interfering with transmembrane transport during enterohepatic circulation and inhibiting the binding of α­amanitin to
,23 hepatocytes. There is some evidence that Silybum has additional hepatoprotective effects that result from stimulating protein synthesis and
 inhibiting tumor necrosis factor­α release in damaged liver cells. It is given as a loading dose of  milligrams/kg over  hour followed by  milligrams/kg/d for  days. This treatment is not currently approved by the U.S. Food and Drug Administration; it is available in Europe, and phase II/III clinical trials are in progress in the United States. N­Acetylcysteine is also beneficial as a means of reducing reactive metabolites by providing sulfhydryl groups for this purpose. It is given IV in three sequential doses of 150 milligrams/kg over  hour,  milligrams/kg over  hours, and 100 milligrams/kg over  hours.
Despite these therapies, amatoxin toxicity may lead to fulminant liver failure. In cases of amatoxin­induced liver failure, the amatoxin itself is rapidly absorbed and excreted, which limits the utility of hemoperfusion and/or hemodialysis. The Molecular Adsorbent Recirculation System® can support
 liver function while hepatocytes recover or until transplantation becomes feasible. Although randomized controlled trials are not available,
 numerous case reports have shown improved liver functioning coinciding with this device. Orthotopic liver transplantation (the entire organ is replaced with a graft) and auxiliary partial orthotopic liver transplantation (a portion of the native liver is removed and replaced with a graft until
 recovery occurs) are both surgical options.
,25
High­dose penicillin G and ceftazidime have both demonstrated a capacity for decreasing the uptake of amanitin by hepatocytes. However, these
 therapies appear to be less effective than using Silybum alone. Thioctic acid is a free radical scavenger and has been used for many years but has not yet gained support in the literature.
Patients suspected of ingesting amatoxin­ or gyromitrin­containing mushrooms should be admitted and monitored for  hours, with monitoring of hepatic and renal function.
DELAYED­ONSET RENAL FAILURE
Delayed­onset renal failure is seen after ingestion of Cortinarius (Cortinarius orellanus, Cortinarius speciosissimus, and Cortinarius gentilis and A.
 smithiana mushrooms. Cortinarius species are found primarily in Europe. A. smithiana mushrooms are common in forest areas of western North

America.
PATHOPHYSIOLOGY
Orellanine and ortinarin A and B are the nephrotoxic compounds in species of Cortinarius (C. orellanus, C. speciosissimus, and C. gentilis). These toxins are heat stable, and their mechanisms of action are not well known. Orellanine and its derivatives are believed to inhibit protein synthesis in the kidneys. Histopathologic examination indicates interstitial nephritis with edema and leukocyte infiltration, tubular necrosis, basal membrane rupture,
,22,27 and fibrosis without glomerular injury in patients poisoned with orellanine­containing mushooms.

Allenic norleucine (aminohexadienoic acid) and chlorocrotylglycine are the nephrotoxins found in A. smithiana. Allenic norleucine has been shown
 to induce renal tubular epithelial necrosis and tends to exert its effect earlier than orellanine in cultured cell lines.
CLINICAL FEATURES
Patients who ingest mushrooms containing nephrotoxins often present initially with GI symptoms, including nausea, vomiting, and nonbloody diarrhea. Symptoms begin several hours to days after ingestion and may persist for  days. Occasionally, paresthesias, abnormal taste, and cognitive dysfunction are reported. Symptoms of renal failure, including lumbar and flank pain, oliguria, or more rarely polyuria, begin between  and  days after ingestion. Patients who ingest A. smithiana tend to develop GI symptoms earlier, with a range of symptom onset between  minutes and  hours (median,  to  hours). Orellanine ingestion tends to present with GI symptoms later, with a range of  hours to  days after ingestion.

Similarly, renal failure is noted to develop earlier in allenic norleucine cases (within  to  days) and occurs within  to  days of orellanine ingestion.
Many patients who ingest these mushrooms never develop renal dysfunction, which suggests variability in host sensitivity to their toxic effects.
Consider allenic norleucine or orellanine toxicity from wild mushroom ingestion in a patient with unexplained acute renal failure.
TREATMENT
There is no specific treatment for patients who develop renal failure from ingestion of Cortinarius or A. smithiana mushrooms. Monitor urine output and electrolyte, calcium, magnesium, BUN, and creatinine levels. Hemodialysis is indicated for refractory hyperkalemia, refractory acidosis, uremic symptoms, or severe renal dysfunction. Supportive hemodialysis may be required, but many patients experience a spontaneous return of normal renal function. Because spontaneous improvement is reported, renal transplantation should be withheld for several months to monitor patient response.

Renal transplantation has been used in several patients with good success.
Monitor patients suspected of ingesting orellanine­ or ortinarin­containing mushrooms for at least  hours for electrolyte abnormalities and renal failure.
DELAYED­ONSET DISULFIRAM REACTION
Perhaps most interesting, although clinically least important, is a mushroom toxin contained in the Coprinus genus. This mushroom, which is very common in North America, is known as “inky cap” or “shaggy mane.” It is a tall, white, thin mushroom with a shaggy cap. As the mushroom ages, the cap liquefies and blackens, and black liquid drips from the necrosing cap. The mushroom contains coprine, which is chemically related to disulfiram.
PATHOPHYSIOLOGY
Coprine causes inhibition of alcohol dehydrogenase within  hours of ingestion, and activity may last up to  hours. If alcohol is consumed during this sensitive period, patients develop a typical disulfiram reaction. Mushrooms ingested at the same time as alcohol produce no toxicity.
CLINICAL FEATURES
Because of the delay between mushroom consumption and alcohol consumption, few patients link their symptoms to the ingestion of a mushroom.
Symptoms include headache, paresthesias of distal extremities, metallic taste, flushing, palpitations, chest pain, nausea, vomiting, and diaphoresis
 and generally occur within minutes to several hours after alcohol consumption. Symptoms generally last for  to  hours but may last up to  days.
Most symptoms are mild. Diagnosis is made based on presence of the symptom complex and its association with alcohol consumption.
Because alcohol is readily absorbed from the GI tract, GI decontamination has no role and charcoal administration is not beneficial. Patients occasionally become hypotensive and respond to administration of IV fluids or, in refractory cases, norepinephrine. Excessive sympathetic activity can
 be inhibited by β­blockers.
Most cases are self­limited, and patients can be discharged once they can tolerate oral fluids. Prior to discharge, educate patients about the link between alcohol consumption and mushroom ingestion.
SHIITAKE DERMATITIS
,30
Shiitake dermatitis is a well­known entity in Japan, China, and Korea, and cases have been reported in Europe and the United States. Shiitake dermatitis is a characteristic flagellate erythema appearing as whip­like, linear wheals that appear within  or  days of ingesting raw or cooked shiitake mushrooms. The rash tends to be pruritic and can also involve branching patches of erythema and scattered petechiae. The pathophysiology is not fully understood but is thought to be toxin­induced, involving the thermolabile polysaccharide lentinan that is found in the shiitake mushroom. Skin
,30  biopsy results are nonspecific. Allergy testing in affected individuals is negative.
Treat symptoms with .1% triamcinolone ointment twice daily and oral antihistamines. Regardless of treatment, the rash resolves spontaneously
,30 without hyperpigmentation in  to  weeks.
The rash is self­limited, and no sequelae have been reported.
SPECIAL POPULATIONS

Toxic mushroom exposure during pregnancy has been reported. In one series, a slightly lower birth weight was noted in infants born to mothers with toxic mushroom exposure than in infants of mothers with no such exposure. Most infants appeared to be healthy and developmentally normal, in
,32 keeping with the findings that amatoxins do not cross the placental barrier.


