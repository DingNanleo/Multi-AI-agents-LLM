## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 104: Breast Disorders
Bophal Sarha Hang
INTRODUCTION
The most common breast complaints in the ED involve breast pain, breast mass, nipple discharge, infection, or postoperative complications.

Approximately 30% of women will present to a physician with a chief complaint related to the breasts. Although the problems are rarely emergent except when systemic symptoms such as fever are present, concerns about the potential for breast cancer contribute to patient anxiety.
PATHOPHYSIOLOGY
Adult breast is composed of approximately 20% glandular tissue, and the remaining breast volume consists of fat and connective tissue that give the breast its characteristic texture and shape. Glandular lobules drain into lactiferous ducts, which converge and open at the nipple. The nipple is an important landmark located over the fourth intercostal space.
Normal breast tissue extends from the sternocostal junction medially to the midaxillary line laterally and from the second to the sixth ribs in the midclavicular line. An axillary tail of breast tissue often extends into the axilla. Blood supply arises from the internal mammary, lateral thoracic, thoracodorsal, and subscapular arteries, whereas venous drainage starts in the subareolar plexus and empties into the intercostals, internal mammary, and axillary veins. Lymphatic drainage of the breast is primarily to the axilla, with a small portion going to internal mammary lymph nodes.
Cyclic variances in estrogens, progesterone, follicle­stimulating hormone, and luteinizing hormone signal stromal and glandular changes in breast physiology.
CLINICAL FEATURES
HISTORY
Ask the patient about onset of any mass or pain, location of the affected area, and duration of the symptoms. Complaints that vary with menses suggest a benign cause, whereas cancers are often asymptomatic. Radiation of the pain to any other body site is particularly important when a malignancy is suspected. The presence of symptoms in the contralateral breast parenchyma is also more reassuring for a benign diagnosis. Assess the color and consistency of any nipple discharge. Changes that the patient notes on breast self­examination may be significant and should be correlated with the menstrual cycle. Ask about family history, specifically about first­degree relatives with breast cancer and other risk factors (delay of childbearing to after age  years, biopsy confirmation of atypical hyperplasia, or history of chest irradiation). However, most women who develop breast cancer have no obvious risk factors beyond the two strongest factors, namely, female gender and age. More than 50% of breast cancers are diagnosed in women ≥65 years of age, and women <30 years of age are diagnosed with <1% of all breast cancers. 
PHYSICAL EXAMINATION
The breast examination includes both inspection and palpation. Compare the breasts with the patient sitting upright, and note any breast asymmetry or skin dimpling. Also examine the axillae, including the mammary tail and lymph nodes, in the sitting position. Perform the rest of the examination with the patient supine and the ipsilateral hand behind the head. Examine the upper outer quadrant of each breast with extra care, because about half
,3 of breast carcinomas originate in that area, with a higher propensity for left­sided involvement. Examine the nipple­areola complex with gentle manipulation to detect subareolar masses and latent nipple discharge. Women with breast augmentation may be challenging to examine, but give attention to tissue changes or deviation of the implant.

DISORDERS OF THE LACTATING BREAST
Chapter 104: Breast Disorders, Bophal Sarha Hang 
. Terms of Use * Privacy Policy * Notice * Accessibility
ABNORMAL LACTATION
Any inappropriate secretion of milky discharge from the breast is called galactorrhea. Galactorrhea often results from abnormally elevated levels of prolactin, although some women have normal prolactin levels on testing. Hyperprolactinemia may be caused by inadequate inhibition of secretion or increased production of prolactin. Causes of elevated prolactin levels are listed in Table 104­1. TABLE 104­1
Causes of Elevated Prolactin Levels
Physiologic Sleep, stress, exercise, volume depletion, intercourse or orgasm, pregnancy, breast stimulation, seizures causes
Abnormal Surgery, trauma, herpetic infection stimulation of the chest wall
Damage to or — disruption of the pituitary stalk
Endogenous — hypothalamicpituitary signaling
Neoplasms Prolactinomas, renal cell carcinoma, lymphoma, craniopharyngioma, bronchogenic carcinoma, hydatidiform mole
Medications Antidepressants (monoamine oxidase inhibitors, selective serotonin reuptake inhibitors, tricyclic antidepressants), antihypertensives
(atenolol, methyldopa, reserpine, verapamil), antipsychotic phenothiazines, antihistamines, herbs and vitamin supplements (anise, fennel, nettle, clover, thistle, fenugreek seed), amphetamines, cocaine, opioids, marijuana
Systemic Chronic renal failure, hypothyroidism, hypercortisolism (Cushing’s disease), acromegaly disease
Prolactinomas, benign anterior pituitary neoplasms, are distinguished by symptoms of galactorrhea, amenorrhea, hirsutism, facial acne, visual field deficits, and headaches. Chronic renal failure results in a diminished capacity to clear circulating prolactin. Hypothyroidism causes increased levels of thyrotropin­releasing hormone, which results in increased pituitary secretion of prolactin. Hypercortisolism (Cushing’s disease) and acromegaly due to elevated growth hormone levels are both associated with galactorrhea.
Evaluation of the patient with galactorrhea focuses on any history of associated menstrual abnormalities and the presence of acne, hirsutism, infertility, or libido changes. Symptoms of increased intracranial pressure and hypothyroidism should be investigated. All medications and dietary supplements should be reviewed.
The physical examination includes evaluations of the visual fields, breasts, skin, and thyroid gland. ED studies include a urine or serum pregnancy test and may include neuroimaging (CT or MRI) and neurosurgical consultation if there is concern for an intracranial mass. Treatment for galactorrhea, other than the discontinuation of a medication suspected to be causative, is deferred to the primary care physician or the follow­up specialist.
COMPLICATIONS OF LACTATION
Breast engorgement usually presents on the third to fifth postpartum day, with symptoms of painful, hard, and enlarged breasts. The pain may be accompanied by nausea and low­grade fever. Engorgement results from inadequate removal of milk from the breast. This may be due to infant
 separation, sore nipples, or improper breastfeeding techniques. Ensuring proper latch­on while breastfeeding or pumping usually alleviates the pain and allows for decompression of the nipple­areola complex. Warm showers or manual massage may also help facilitate milk letdown and relieve pain due to engorgement.
Nipple irritation or soreness is common and usually caused by poor positioning or latch­on techniques. Other causes include trauma, plugged ducts, candidiasis, and inflammatory skin disorders. Purified lanolin cream, analgesics, and breast shields may help facilitate healing. There may be
,5 some benefit to applying expressed breast milk to nipples. Reynaud’s phenomenon can cause nipple pain in some women and may respond to
 topical nefedipine.
Puerperal mastitis presents with severe pain, tenderness, swelling, and redness. Patients may also develop fever, chills, and myalgias. Mastitis most commonly presents in the second postpartum week due to milk stasis and retrograde infection. Differentials include marked breast engorgement, clogged milk duct, and inflammatory carcinoma, a rare condition.
Mastitis, like other inflammatory processes, has the US appearance of hypoechoic fluid surrounding subcutaneous fat lobules without a discrete fluid collection (Figure 104­1), in contrast to abscess (Figure 104­2), which presents as a hypoechoic (dark) fluid collection in the tissue with the absence of vascular signals.
FIGURE 104­1. Mastitis, like other inflammatory processes, has the US appearance of hypoechoic fluid surrounding subcutaneous fat lobules without a discrete fluid collection (arrows).
FIGURE 104­2. Breast abscess presents as a hypoechoic (dark) fluid collection in the tissue (arrows) with the absence of vascular signals.
Puerperal mastitis is caused by Staphylococcus aureus in 40% of cases, although Escherichia coli and Streptococcus species are also known
 pathogens. Consider community­acquired methicillin­resistant S. aureus infections associated with puerperal mastitis and abscess. There is no need to interrupt breastfeeding. Treatment requires frequent analgesia, breast emptying, and antibiotics with antistaphylococcal penicillins or cephalosporins (Table 104­2). Sulfamethoxazole­trimethoprim cannot be given to lactating mothers with infants <2 months old. If the infection fails to respond rapidly to antibiotics, evaluate for abscess and broaden antibiotic coverage.
TABLE 104­2
Mastitis, Abscess, and Hidradenitis
Signs and Symptoms Treatment Comments
Puerperal Erythematous area on breast with area of Frequent breast Occurs during first few month or weeks postpartum.
mastitis well­localized pain emptying Breastfeeding may continue.
Fever, chills, myalgias, flulike symptoms Routine hand washing Early antibiotics and milk drainage are cornerstone of prior to breast treatment.
manipulation Must rule out abscess if rapid response to antibiotics does
Analgesia not occur. Cover for MRSA.
Antibiotics: US to differentiate mastitis from abscess.
Dicloxacillin, 500 Follow up with obstetrician.
milligrams four times a day for 10–14 d or
Cephalexin, 500 milligrams four times a day for 10–14 d or
Clindamycin, 300 milligrams four times a day for 10–14 d
Nonpuerperal Erythematous area on breast with area of Analgesia Must rule out abscess if rapid response to antibiotics does mastitis well­localized pain Antibiotics: not occur.
Fever, chills, myalgias, flulike symptoms Dicloxacillin, 500 US helps differentiate between mastitis and abscess.
milligrams four times a Follow up with surgeon.
day for 10–14 d or
Cephalexin, 500 milligrams four times a day for 10–14 d or
Clindamycin, 300 milligrams four times a day for 10–14 d or
TMP­SMX, 160/800 milligrams twice a day
Breast Erythematous area on breast with area of US­guided needle Needle aspiration is first­line treatment. Obtain surgical abscess well­localized pain aspiration for abscess consultation for treatment failure and multiloculated
Fever, chills, myalgias, flulike symptoms Analgesia abscesses.
Antibiotics: Immunocompromised patients and those with signs of
Dicloxacillin, 500 systemic illness require IV antibiotics, surgical milligrams four times a consultation, and admission.
day for 10–14 d Follow up with surgeon.
or
Cephalexin, 500 milligrams four times a day for 10–14 d or
Clindamycin, 300 milligrams four times a day for 10–14 d or
TMP­SMX, 160/800 milligrams twice a day
Periductal Varies with age: Analgesia Dilated or ectatic ducts with retained secretions.
mastitis Younger women—cellulitis or recurrent Antibiotics: Follow up with surgeon.
subareolar abscesses Dicloxacillin, 500
Perimenopausal and postmenopausal milligrams four times a women—nipple discharge, nipple retraction, day for 10–14 d or subareolar mass or
Cephalexin, 500 milligrams four times a day for 10–14 d or
Clindamycin, 300 milligrams four times a day for 10–14 d or
TMP­SMX, 160/800 milligrams twice a day
Hidradenitis Painful superficial cutaneous abscesses along Incision and drainage Chronic inflammatory disease involving the obstruction of suppurativa inferior, pendulous surface of breast sweat glands.
Antibiotics may be indicated in immunocompromised patients.
Abbreviation: MRSA = methicillin­resistant Staphylococcus aureus; TMP­SMX = trimethoprim­sulfamethoxazole.
Breast abscess is uncommon and complicates mastitis in approximately 3% of cases. If US examination identifies a subcutaneous fluid collection,
US­guided drainage is an initial first­line treatment (Figures 104­1 and 104­2). Breastfeeding should be continued throughout the course of
,7 treatment unless the antibiotic regimen is contraindicated with newborns. Surgical drainage is reserved as a last resort in lactating
 patients to avoid the potential for milk fistulas. Management also includes antibiotic coverage for possible drug­resistant Staphylococcus such as oral cephalosporins or clindamycin. Intravenous vancomycin is a good choice for septic patients requiring inpatient hospitalization. In a subset of patients
 with recurrent infections, the surgeon may need to perform an excisional biopsy of tissue to rule out an associated inflammatory carcinoma.
INFLAMMATORY BREAST CONDITIONS
The differential diagnosis of an inflamed breast includes infectious mastitis, breast abscess, periductal mastitis, ruptured breast cyst, inflammatory neoplasm, metastatic cancer from a primary lesion, tuberculosis, and Paget’s disease. Each entity can mimic the other, more benign conditions. A failure of the condition to improve with antibiotic therapy indicates the need for urgent surgical consultation and possible biopsy
 to exclude the presence of an inflammatory cancer.
CELLULITIS, ACUTE MASTITIS, AND BREAST ABSCESS IN NONLACTATING WOMEN
Cellulitis, mastitis, and breast abscesses exist along a continuum, with similar clinical presentation of pain, redness, swelling, fever, and malaise.
Cellulitis can be identified on US as diffuse thickened and hyperechoic skin and increased echogenicity of subcutaneous tissue. However, breast cellulitis is uncommon and requires referral to a breast surgeon for imaging and possibly biopsies. Initial treatment includes dicloxacillin, amoxicillin– clavulanic acid, or a first­generation cephalosporin. However, the increasing incidence of infection with methicillin­resistant S. aureus may necessitate the use of trimethoprim­sulfamethoxazole, clindamycin, or tetracycline depending on the patient’s history of infections and the local prevalence of
 methicillin­resistant S. aureus. Cellulitis requires follow­up with a breast surgeon.
Acute mastitis and abscesses in nonlactating women (Figures 104­1 and 104­2) are often seen in women with diabetes, obesity, or a history of smoking. Common organisms are Staphylococcus and Streptococcus. Follow­up mammography is recommended for
 patients older than  years and should be done after the acute phase has resolved. Initial recommended empiric parenteral antibiotics are third­generation cephalosporins (e.g., ceftazidime), clindamycin, vancomycin, fluoroquinolones, or linezolid with consideration of the addition of metronidazole for deeper abscesses. The prevalence of methicillin­resistant S. aureus infections continues to increase and has been reported in up to

20% of cases of breast abscess.
Patients without systemic toxicity can be treated as outpatients. Antibiotics should provide anaerobic coverage. Infections should respond to
12­15 antibiotics within  hours. Refer patients to a breast surgeon for US­guided needle aspiration and therapy.
HIDRADENITIS SUPPURATIVA
Hidradenitis suppurativa frequently presents with recurrent multiple cutaneous abscesses, sinus tracts, and scarring of the breast folds, axillae, and groin and perineum. It is a chronic inflammatory disease involving the obstruction of sweat glands and polymicrobial colonization, usually with
Staphylococcus and Streptococcus species. Frequently, patients present with painful superficial cutaneous abscesses along the inferior, pendulous surface of the breast and require surgical drainage for pain relief. Incision and drainage usually are adequate therapy for a limited area of abscess formation. Antibiotics are rarely used for outpatient management of hidradenitis abscesses in immunocompetent patients, although clindamycin or rifampin may be used by dermatologists or surgeons to decrease the frequency and severity of the disease. There is no cure, and the disease often requires extensive surgical excision of the apocrine tissue.
INFLAMMATORY BREAST CANCER
Of all the potential presentations of a breast malignancy, inflammatory breast cancer is the entity associated with the highest mortality and longest delay from initial presentation to definitive diagnosis. The clinical presentation is characterized by symptoms of mastalgia and breast inflammation due to tumor infiltration of dermal lymphatics and inflammation of the breast stroma. The combination of erythema and edema results in the classic peau d’orange appearance of the overlying skin and ultimately nipple retraction as the edema progresses. Initially, the patient presents with a clinical syndrome of breast enlargement, breast warmth, tenderness, edema, erythema, and sometimes discoloration of the overlying skin. The absence of a palpable underlying mass or axillary lymphadenopathy does not rule out the diagnosis. The signs of inflammatory breast cancer are often indistinguishable clinically from infection. Prompt mammography and biopsy of the skin and any palpable or radiographic breast lesions will be required by the follow­up physician. Similarly, the diagnosis of inflammatory breast cancer must be considered promptly if there is not an initial good response to antibiotics or if breast cellulitis or abscess fails to completely resolve.
NONINFLAMMATORY PAINFUL BREAST DISORDERS
MASTODYNIA
Breast pain is also termed mastodynia or mastalgia. Irritation to the intercostal nerves at T3­T5 can cause pain in the breast or nipple. The pain is bilateral and usually most severe in the upper outer quadrants of the breast. Pain may be referred to the axilla or scapula. Diagnosis relies on findings of the history and physical examination to confirm that the pain actually originates from the breast. Breast pain is an uncommon symptom of breast
 cancer. Cyclic mastodynia is usually most severe in the immediate premenstrual phase and decreases or resolves completely following menstruation.
At times, the examination reveals tender, nodular breasts, which suggests a diagnosis of fibrocystic changes, although breast cancer must remain in the differential diagnosis. For most patients, reassurance and use of a supportive bra provide adequate initial treatment. Refer to a primary care
,18 physician for follow­up treatment and consideration of imaging.
SKIN AND NIPPLE ABNORMALITIES
NIPPLE DISCHARGE
Table 104­3 lists some common causes of nipple discharge. In general, nipple discharge that is bilateral, occurs with nipple manipulation, and can be expressed from several ducts is not suggestive of cancer. Nipple discharge that originates in a single breast, emanates from a single duct, and is clear,
 pink, bloody, or serosanguineous is associated with an increased risk of carcinoma. Follow­up with the patient’s primary care physician for mammography and possible fluid analysis of the discharge is always needed.
TABLE 104­3
Possible Causes of Different Types of Nipple Discharge
Type of Discharge Cause
Purulent Infection
Periductal mastitis
Milky (galactorrhea) Pregnancy
Prolactinoma
Pituitary adenoma or intracranial mass
Drugs: hormones, psychotropics (phenothiazines), histamine­2 receptor antagonists, antiemetics (metoclopramide), antihypertensives (methyldopa, verapamil)
Serous or Intraductal papilloma serosanguineous Ductal ectasia
Cancer
Watery Papilloma
Cancer
Green, gray, black, or Duct ectasia or periductal mastitis tan
Intraductal papillomas usually present with a unilateral bloody nipple discharge in women from  to  years of age. Bleeding is secondary to increased tissue vascularity. A mass may not be palpable on examination. Other causes of bloody nipple discharge include mammary duct ectasia and breast cancer. Ductal ectasia involves the stasis or plugging of lactiferous ducts, which then progresses to an infiltrative inflammatory process. The cause of mammary duct ectasia is unknown.
Bilateral spontaneous milky nipple discharge can indicate an elevated serum prolactin level (see earlier discussion under “Abnormal Lactation”). Any postmenopausal nipple discharges are significant, so refer to a breast specialist.
MONDOR’S DISEASE
Mondor’s disease is a benign, self­limited superficial thrombophlebitis, usually seen in young women of childbearing age. Patients present with painful palpable cord or mass in the superficial tissue of the breast, most commonly in the lower quadrants. Skin discoloration, erythema, and nipple retraction may be present. Although the exact cause is unknown, trauma or a local inflammatory process has been linked to Mondor’s disease. US can establish the diagnosis of superficial thrombophlebitis. Treatment is nonsteroidal anti­inflammatory medication. Consider thrombophilic evaluation
 and treatment with low­molecular­weight heparins after hematology consultation. Refer for appropriate follow­up.
NIPPLE IRRITATION
Nipple irritation may be indicative of atopic dermatitis, erosive adenomatosis, or Paget’s disease. Erosive adenomatosis is a benign proliferation of the lactiferous ducts presenting with eczema or an erosion of the nipple. Referral to a breast specialist is needed for the latter condition because the treatment is surgical excision. Paget’s disease is often heralded by the appearance of a weeping, eczematoid lesion of the nipple. Paget’s disease is almost always associated with an underlying breast carcinoma and usually is diagnosed in postmenopausal women. Paget’s disease may present with an associated palpable breast mass, often correlating with the presence of an intraductal carcinoma. Because skin edema and inflammatory changes may respond transiently to incorrectly prescribed topical treatments, there is usually a delay of  to  months in diagnosis. Provide urgent referral for bilateral mammography and follow up with a breast specialist.
FIBROCYSTIC DISEASE AND THE EVALUATION OF A BREAST MASS
Fibrocystic breast disease is a constellation of symptoms linked by the pathognomonic finding of breast cysts. Breast nodularity and tenderness, which occur as a result of breast tissue responses to hormonal cycling, are referred to as fibrocystic breast disease or fibrocystic changes of the breast.
Fibrocystic changes do not include skin thickening, edema, discoloration, nipple retraction, or discharge. If the history and physical examination findings in the ED are normal, then outpatient mammography and follow­up with a specialist should occur, regardless of patient age. Further imaging, including additional mammography and MRI, may also be indicated. Women with recurrent or severe symptoms, skin changes, solid masses, nipple abnormalities, or anxiety about the possibility of cancer should be referred to a breast specialist.
Breast cancer is rare in patients <20 years of age and uncommon in women <30 years of age. Risk factors for young women include inheritance of the
BRCA1 or BRCA2 gene, a history of childhood malignancy, or a history of chest irradiation. A family history of a first­degree relative with breast cancer, increased exposure to endogenous estrogens (nulliparity or delay of childbearing until after age 30), or biopsy­confirmed atypical breast hyperplasia increases the risk for women ≥30 years old. However, most patients diagnosed with breast cancer have only two risk factors: age >50 years and female
 gender.
Physical signs that should prompt urgent surgical referral include a palpable mass with or without the following: lymphadenopathy, skin ulceration, mass fixation to the chest wall, fixed axillary nodes, and the presence of ipsilateral arm edema.
Characteristics associated with a delayed diagnosis and poorer survival of breast cancer are black race, lower socioeconomic status, unmarried state,
22­26 normal or false­negative mammogram results, presentation with nipple lesions or axillary mass, and younger age at time of diagnosis.
PERIOPERATIVE AND POSTOPERATIVE COMPLICATIONS
BREAST HEMATOMA
Postoperative hemorrhage or expanding hematoma formation is best evaluated immediately and treated by the operating surgeon. Up to .5 L of blood can extravasate into traumatized breast parenchyma. Emergent evaluation requires determination of whether the hematoma is expanding, tensely distended, or stable. Expanding hematomas, especially those occurring within the first few postoperative days, may signify the presence of continued bleeding and usually require surgical evaluation for evacuation of the hematoma or ligation of bleeding vessels. Later presentations of breast hematoma are usually managed conservatively with analgesics, a compressive bra, and the correction of any coagulopathy. Aspiration of the hematoma generally is not effective in the ED. The presence of an infected hematoma requires inpatient management with US­guided percutaneous drainage or open surgical drainage; parenteral antibiotics generally are indicated.
WOUND INFECTION
Postoperative wound infections may be treated with an oral first­generation cephalosporin on an outpatient basis if there is no evidence of abscess, systemic signs of toxicity, or immunocompromise. Worsening signs of cellulitis or systemic response to infection, development of purulent drainage, or failure to improve after  hours of treatment requires inpatient management. Infections of postoperative drains generally require drain removal and antibiotic therapy. Any fluid collections that develop subsequently usually require drainage either by repeated aspiration or by incision. The operating surgeon should be consulted regarding any postoperative complications.
BREAST IMPLANTS
Approximately .5 million people in the United States have breast implants. Patients may present to the ED with complications such as implant rupture, hematoma, seroma, or infection. The risk of implant rupture increases with age but usually occurs after  years. Rupture is most commonly spontaneous, but may also be associated with blunt trauma. For saline implants, rupture is easily detected on physical exam by noting the deflated breast on the affected side. This is typically painless, and outpatient follow­up is appropriate. Silicone implant ruptures are more difficult to diagnose on physical exam. US or MRI imaging confirms the diagnosis. Acutely ruptured silicone implants may present with an inflamed, painful breast mass due to silicone extravasation. Although treatment involves surgical removal, patients should be reassured that there is no danger from silicone
,28 leakage.
In the early breast implant postoperative period, complications such as seromas and hematomas may occur. Despite best practices, the rate of breast implant infections is about 6%, requiring readmission and additional surgery. Causative organisms are predominantly gram positive, with S. aureus being the most common agent. First­line treatment is vancomycin with gentamycin. For outpatient treatment, tetracycline and doxycycline are
 recommended.


