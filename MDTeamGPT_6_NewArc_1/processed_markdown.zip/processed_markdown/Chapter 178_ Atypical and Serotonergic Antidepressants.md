## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 178: Atypical and Serotonergic Antidepressants
Frank LoVecchio; Erik G. Mattison
INTRODUCTION
Atypical and serotonergic antidepressants are commonly referred to as newer or second­generation antidepressants to distinguish them from the first­generation monoamine oxidase inhibitors and cyclic antidepressants. As a group, these antidepressants are the most popular form of
 psychopharmacologic therapy for the treatment of major depression, obsessive­compulsive disorder, panic disorders, and eating disorders. These antidepressants produce less severe toxicity in overdose and are associated with fewer fatalities than either cyclic antidepressants or monoamine
2–4 oxidase inhibitors. This favorable overdose profile is tempered by the U.S. Food and Drug Administration black box warning regarding the use of some agents by patients <24 years old due to increased suicidal ideation and behavior.
This group of antidepressants is a heterogeneous collection of drugs that differ significantly in chemical structure, mechanism of action,
 pharmacokinetic characteristics, and adverse effect profile. Nonetheless, they also share many important similarities.
Most possess serotonergic activity and, especially in combination with other serotonergic agents, have the potential to produce serotonin syndrome.
These agents have negligible affinity for acetylcholine, dopamine, γ­aminobutyric acid, glutamate, and β­adrenergic receptors. These agents do not inhibit monoamine oxidase activity and are not associated with tyramine­like reactions. Most of these antidepressants do not significantly inhibit cardiac sodium, calcium, or potassium ion channels. Although their exact mechanism of action remains poorly understood, it is traditionally attributed to inhibition of neurotransmitter reuptake or interruption of negative feedback loops.
These antidepressants are metabolized primarily by hepatic enzyme systems (cytochrome P450 pathways). If two drugs are given that interact with a common metabolic pathway, drug levels can increase or decrease depending on the interaction. In addition, hepatic dysfunction can lead to elevated drug levels and subsequent drug toxicity. These antidepressants are not detected by routine hospital serum and urine drug screens. Specialty laboratories can measure parent drug and metabolite plasma levels, but this information is useful only for the confirmation of suspected drug overdose and does not affect patient management.
SPECIFIC AGENTS
ATYPICAL ANTIDEPRESSANTS
The atypical antidepressants have chemical structures different from each other and from the other antidepressant classes (Table 178­1). They possess some unique clinical features at therapeutic doses and with overdoses.
TABLE 178­1
Atypical Antidepressants
Recommended Maximum Daily Adult Dose Elimination Half­Life Parent Compound
Agent Major Active Metabolite
(milligrams) (h)
Bupropion 450 10–21 Hydroxybupropion
Mirtazapine  20–40 Desmethylmirtazapine
Nefazodone 600 2­4 Hydroxy­nefazodone

Chapter 178: Atypical and Serotonergic Antidepressants, Frank LoVecchio; Erik G. Mattison 
Trazodone 400 3–6 (first phase) Meta­
. Terms of Use * Privacy Policy * Notice * Accessibility
5–9 (second phase) chlorophenylpiperazine
Vilazodone   None
Vortioxetine   None
BUPROPION
Bupropion has a monocyclic phenylaminoketone chemical structure that resembles the phenylethylamines (e.g., amphetamine), but does not produce stimulant effects or drug­addictive behavior at therapeutic dosages. The therapeutic mechanism of action of bupropion is primarily inhibition of
 neuronal reuptake of norepinephrine and dopamine with very minimal serotonergic activity.
Bupropion is absorbed rapidly after oral administration, with peak plasma levels within  hours for regular­release tablets and within  hours for sustained­release preparations. Bupropion undergoes extensive first­pass hepatic metabolism, is highly protein bound, has an extremely large volume of distribution, and readily crosses the blood–brain barrier. The active metabolite, hydroxybupropion, although less potent than bupropion, preferentially inhibits norepinephrine reuptake and may contribute to seizure development.
Bupropion antidepressant therapy is well tolerated. The most commonly reported adverse effects at therapeutic dosages are mild and include dry
 mouth, dizziness, agitation, nausea, headache, constipation, tremor, anxiety, confusion, blurred vision, and increased motor activity. Bupropion infrequently produces catatonia, hallucinations, psychosis, and paranoia, which are likely related to its dopaminergic activity. Abrupt discontinuation of bupropion has not been associated with withdrawal symptoms, but as a dopamine agonist, it may pose a slight theoretical risk of precipitating neuroleptic malignant syndrome after discontinuation.
Clinical Features
Bupropion differs from other atypical antidepressants in that it has a narrow therapeutic index and possesses high morbidity and mortality indices
,7 after exposure. Toxicity can occur at dosages equal to or just slightly greater than the maximum therapeutic dose of 450 milligrams/d. Conversely, significant toxicity is not expected in pure bupropion overdose with adult ingestions of <450 milligrams. The most commonly reported
,9 symptoms in pure bupropion overdose include agitation, dizziness, tremor, nausea and vomiting, drowsiness, and tachycardia. Mild hyperthermia is reported occasionally. Sinus tachycardia is the most common ECG abnormality seen following overdose, but QRS widening and QT interval
,11 prolongation have been reported. Hypotension is unexpected in pure bupropion overdoses but has been reported in mixed­drug overdoses.
Hypertension may occur but is usually of only mild to moderate severity. Coma and cardiac arrest have been reported in severe bupropion overdoses.
,12
Seizures are more common with bupropion toxicity than with other atypical antidepressants and usually are accompanied by other
,9,13 signs such as sinus tachycardia or altered mental status. Seizures can develop suddenly in otherwise asymptomatic patients. Seizures
 usually occur within the first  to  hours after ingestion of immediate­release bupropion, but their appearance may be delayed for up to  hours.

Ingestions of extended­release preparations may predispose patients to seizures up to  hours after exposure.
Treatment
Establish a peripheral IV line, initiate cardiac rhythm monitoring, and obtain an ECG (Table 178­2). GI decontamination with activated charcoal is
 recommended provided it can be done within  hour of ingestion. There is no evidence to support multidose activated charcoal or whole­bowel irrigation, even in overdoses of sustained­release products. Ipecac syrup is contraindicated due to the risk of seizures. Early onset of generalized seizures should be anticipated in all cases of bupropion ingestion and treated with benzodiazepines followed by phenobarbital, if necessary.
TABLE 178­2
Treatment of Bupropion Overdose
IV access, cardiac rhythm monitor, and ECG
Anticipate seizures; be prepared to treat with benzodiazepines
Single­dose activated charcoal if ingestion within  h, especially if extended­release formulation
Sodium bicarbonate for QRS complex prolongation >110 ms
Magnesium sulfate for QTc interval prolongation >500 ms
Consider IV lipid emulsion therapy for refractory cardiovascular instability (case reports only)
Hospital admission is recommended for all patients with seizures, persistent sinus tachycardia, or lethargy. Asymptomatic patients who have ingested only regular­release bupropion should be observed for  hours before discharge. Adult patients ingesting >450 milligrams of extended­
 release bupropion require monitoring for approximately  hours.
MIRTAZAPINE

Mirtazapine is a tetracyclic compound that, in contrast to other atypical antidepressants, does not inhibit neuronal amine uptake. Instead, it blocks central presynaptic α ­adrenergic receptors and the postsynaptic serotonin 5­HT and 5­HT receptors. This has the therapeutic effect of increasing
   central norepinephrine and serotonin neurotransmission. Mirtazapine has a high affinity for blocking histamine­1 receptors and a moderate affinity for blocking muscarinic receptors. These effects commonly produce somnolence, especially in overdose.
Mirtazapine has a pharmacokinetic profile similar to other atypical antidepressants. It is absorbed rapidly with peak plasma levels within  hours after ingestion. Bioavailability is approximately 50% due to significant first­pass hepatic metabolism. The elimination half­life for mirtazapine is shorter in males than females, attributed to decreased cytochrome P450 metabolism in females. Mirtazapine is highly protein bound (85%) and has a large volume of distribution (5 L/kg). Agranulocytosis is a rare but potentially serious complication of chronic mirtazapine use.
Clinical Features
14–16
Mirtazapine produces limited toxicity in overdose; the most common features are sedation, confusion, sinus tachycardia, and mild hypertension.

The risk of coma and respiratory depression is greatest at larger doses or when mirtazapine is combined with other sedative drugs. Cardiac
14–16 abnormalities such as sinus tachycardia or QT interval prolongation are rarely of clinical significance.
Treatment
14–16
Isolated mirtazapine overdose is managed with supportive care alone in the majority of ingestions. Administer single­dose activated charcoal if the ingestion has occurred within the past hour. Ipecac syrup is contraindicated, and multidose activated charcoal or whole­bowel lavage is unnecessary. Symptomatic patients should be admitted to a monitored bed, but significant cardiac toxicity is very unlikely. Asymptomatic patients can be discharged after  hours of observation.
NEFAZODONE

Nefazodone overdose is relatively benign; the most common symptom is drowsiness. Hypotension, mild bradycardia, and prolonged QT interval can
,18 ,18 be seen in rare cases. In general, symptoms occurred within  hours of ingestion and resolved with time and minimal supportive care.
TRAZODONE
Trazodone is a triazolopyridine derivative with an antidepressant action believed to be due to a combination of serotonin reuptake inhibition and
 antagonism of postsynaptic serotonin 5­HT receptors. Trazodone is a moderately potent nonselective α­adrenergic receptor blocker with at least five
 times greater affinity for α ­adrenergic than α ­adrenergic receptors. Consequently, trazodone is frequently associated with orthostatic hypotension,
  which is maximal within the first  hours after ingestion, so the harmful consequences can be minimized by taking the medication at bedtime.
Sedation, which is a common side effect of trazodone therapy, is believed to be secondary to inhibition of central α­adrenergic and histamine receptors.
Trazodone is absorbed rapidly and completely, with peak plasma levels occurring between  and  hours following oral administration. It is highly protein bound (89% to 95%) and has a moderate volume of distribution (1.2 L/kg). Trazodone primarily undergoes hepatic oxidation by the cytochrome P450 isoenzyme system producing one active metabolite, meta­chlorophenylpiperazine, which has a complex pharmacologic profile, including inhibition of serotonin uptake, stimulation and inhibition of multiple postsynaptic serotonin receptors, and interactions with other neurotransmitter systems.
The adverse effect profile for trazodone during therapeutic use is very favorable except that trazodone is one of the most common causes of drug­induced priapism, with an estimated incidence ranging from  to  per ,000 patients. Trazodone should be discontinued immediately in any patient with a history of increased frequency of, increased duration of, or inappropriate penile or clitoral engorgement. Trazodone has been reported occasionally to be arrhythmogenic during therapeutic use, especially in patients with underlying cardiac risk factors such as conduction abnormalities or ischemic heart disease.
Clinical Features
The most common symptom of acute trazodone poisoning is CNS depression. Other neurologic symptoms include ataxia and dizziness, and rarely, coma and seizures. Coma and seizures are more common when another epileptogenic drug is co­ingested. Pupils are usually of normal size and remain reactive. Trazodone­induced neurologic symptoms show marked improvement within  to  hours after ingestion and almost always resolve by  hours. Orthostatic hypotension is the most frequently reported cardiovascular abnormality noted in trazodone overdose and usually responds
 to fluid administration. The most common ECG abnormality is moderate prolongation of the QT interval. Polymorphic ventricular tachycardia

(torsades de pointes) has been reported in rare cases. Commonly reported GI complaints include nausea, vomiting, and nonspecific abdominal pain.
Treatment
Establish IV access, initiate cardiac rhythm monitoring, and obtain an ECG (Table 178­3). GI decontamination with single­dose activated charcoal can be used in appropriate patients who present within  hour. Patients who ingest >2 grams of trazodone or co­ingest other substances are at increased risk for serious toxicity with coma, seizures, respiratory arrest, cardiac dysrhythmias, and cardiac arrest.
TABLE 178­3
Treatment of Trazodone Overdose
IV access, cardiac rhythm monitor, and ECG
Single­dose activated charcoal if ingestion within  h
Treat seizures with IV benzodiazepines
IV fluids for hypotension
Direct­acting vasopressor (norepinephrine) for persistent hypotension and circulatory shock
Magnesium sulfate for QTc interval prolongation and/or torsades de pointes
Hypotension is treated initially with isotonic IV fluid administration. For persistent hypotension, use a direct­acting vasopressor (e.g., norepinephrine).
Drugs with β­adrenergic receptor activity (e.g., dopamine) theoretically can worsen the hypotension in the presence of trazodone­induced α­ adrenergic receptor antagonism. Treat QT interval prolongation and/or torsades de pointes arrhythmia with IV magnesium sulfate, followed by cardiac
 pacing as needed.
Patients who have remained asymptomatic for at least  to  hours can be discharged safely from the ED, provided that necessary psychiatric evaluation has been completed or arranged. Patients with neurologic and/or cardiac symptoms require hospital admission to a monitored bed.
VILAZODONE
Vilazodone is an antidepressant with selective serotonin reuptake inhibition and partial serotonin 5­HT agonism. Following overdose, the most
1A
 common clinical features are drowsiness, vomiting, tachycardia, and agitation. Most patients have symptoms for between  and  hours, although
 some remain symptomatic for more than  hours. Serotonin syndrome rarely occurs in isolated vilazodone overdoses.
VORTIOXETINE
Vortioxetine selectively inhibits serotonin reuptake; antagonizes serotonin 5­HT , 5­HT , and 5­HT receptors; stimulates the serotonin 5­HT
 1D  1A
 receptor; and is a partial agonist at the serotonin 5­HT receptor. Common side effects with therapeutic use include nausea, constipation, and
1B
 vomiting. Clinical features in overdose are limited but appear to be minimal. Serotonin syndrome would be a risk based on the mechanism of
 action.
SELECTIVE SEROTONIN REUPTAKE INHIBITORS
Selective serotonin reuptake inhibitors (SSRIs) are a structurally heterogeneous group of drugs that share selective affinity for inhibiting presynaptic
 serotonin reuptake without significantly affecting norepinephrine or dopamine reuptake (Table 178­4). SSRIs are essentially devoid of direct presynaptic or postsynaptic receptor interactions. Thus, they are associated with fewer unwanted pharmacologic actions, in contrast with cyclic antidepressants.
TABLE 178­4
Selective Serotonin Reuptake Inhibitors
Recommended Maximum Daily Adult Dose Elimination Half­Life Parent
Agent Active Metabolite
(milligrams) Compound (h)
Citalopram   Monodesmethylcitalopram
Didesmethylocitalopram
Escitalopram  27–32 Desmethylcitalopram
Fluoxetine  96–144 Norfluoxetine
Fluvoxamine 300  None
Paroxetine   None
Sertraline 200  Desmethylsertraline

SSRIs are the most common form of pharmacotherapy for depression in the United States. This class of antidepressants is the most frequently
2–4 reported to be involved in drug overdoses, but fatalities are uncommon due to the high therapeutic index of these drugs.
The SSRIs have similar pharmacokinetic profiles, including rapid and complete oral absorption, peak plasma levels occurring  to  hours after ingestion (except citalopram and escitalopram, which achieve peak plasma levels at  to  hours), significant first­pass hepatic metabolism, a high degree of protein binding (except citalopram and escitalopram), and a large volume of distribution. Fluoxetine is unique in that the active metabolite, norfluoxetine, is as potent as the parent compound. The half­life of norfluoxetine is  to  days, so the clinical effects of fluoxetine may last for up to  weeks after the last fluoxetine dose.
The SSRIs are metabolized almost entirely by the hepatic cytochrome P450 isoenzyme system, and these agents can inhibit the metabolism of other drugs dependent on that system. The most serious drug­related adverse effect of SSRI psychopharmacotherapy is serotonin syndrome
(see later section, “Serotonin Syndrome”).

Adverse effects with therapeutic doses include hyponatremia, which is believed to be secondary to inappropriate secretion of antidiuretic hormone.
Priapism has been reported but is extremely rare. A withdrawal syndrome consisting of nonspecific neurologic, psychiatric, and GI symptoms has been described in conjunction with abrupt discontinuation. It is less likely to occur with fluoxetine due to its long­acting metabolite.
Other neurologic adverse effects associated with SSRIs include headache, sedation, insomnia, dizziness, weakness or fatigue, tremor, and
 nervousness. Seizures are uncommon but have been reported with all of these agents, with citalopram associated with the highest incidence of
 seizures among the SSRIs. Serotonin has varying effects on the dopaminergic system. In many cases, extrapyramidal symptoms such as dystonic
 reactions, akathisia, dyskinesia, hypokinesia, and parkinsonian symptoms have been reported in association with SSRI therapy. Consequently, SSRIs should be used cautiously with antipsychotic agents because they can potentiate antidopaminergic activity. Patients taking SSRIs commonly report GI complaints, such as nausea, diarrhea, constipation, vomiting, and anorexia. Other adverse effects less commonly reported include dry mouth, increased sweating, and blurred vision.
CLINICAL FEATURES

The greatest amount of human SSRI overdose experience has been with fluoxetine. Information from case series involving the other SSRIs is
,24 consistent with the information accumulated on fluoxetine. Fortunately, all of the SSRIs are characterized by a high therapeutic index, and
2–4 fatalities are uncommon with pure overdoses. Most adult and pediatric patients remain asymptomatic following SSRI overdose. The most common clinical features in symptomatic patients from overdose include nausea, vomiting, sedation, tremor, and sinus tachycardia. Less frequently observed are mydriasis, seizures, diarrhea, agitation, hallucinations, hypertension, and hypotension.
Sinus bradycardia is observed more frequently in fluvoxamine overdoses than in overdoses of other SSRIs. Prolongation of the QRS complex and
25–30
QT interval occurs in association with significant citalopram and escitalopram ingestions. In most cases, the ECG abnormalities gradually resolve over  hours. Tachycardia, mild hypotension, and lethargy are seen more commonly when SSRIs are combined with ethanol. Mixeddrug ingestions can produce a wide variety of additional symptoms depending on the toxicity of the co­ingestant. About 10% of reported instances of serotonin syndrome occur as a consequence of acute overdose.
TREATMENT
In patients who intentionally overdose, establish a peripheral IV line, initiate cardiac rhythm monitoring, and obtain an ECG (Table 178­5). Pure SSRI overdoses are associated with limited toxicity except for the infrequent development of life­threatening complications such as generalized seizures and serotonin syndrome. Based on the high therapeutic index and unlikelihood of serious toxicity, treatment with single­dose activated charcoal is logical for patients presenting within  hour of ingestion. Gastric lavage, ipecac syrup, multidose activated charcoal, and whole­bowel irrigation are not recommended.
TABLE 178­5
Treatment of Selective Serotonin Reuptake Inhibitor Overdose
IV access, cardiac rhythm monitor, and ECG
Single­dose activated charcoal if ingestion within  h
Treat seizures with IV benzodiazepines
Sodium bicarbonate for prolonged QRS complex
Magnesium sulfate for QTc interval prolongation and/or torsades de pointes
Benzodiazepines are recommended as initial anticonvulsant therapy, followed by phenobarbital if seizures persist. Prolonged QRS or QT intervals are
 usually seen with citalopram or escitalopram but have been reported with other SSRIs in polydrug ingestions. Delayed­onset serotonin syndrome,
,32 extrapyramidal reactions, and torsades de pointes are possibilities, especially with sustained­release compounds.
Patients should be observed for  hours, during which time supportive care is generally adequate. Hospital admission with continuous cardiac rhythm monitoring is recommended for all patients who remain tachycardic, have altered mental status, ingested citalopram or escitalopram, demonstrate cardiac conduction abnormalities, or have features of the serotonin syndrome.
SEROTONIN/NOREPINEPHRINE REUPTAKE INHIBITORS
The serotonin/norepinephrine reuptake inhibitors (SNRIs) are primarily nonselective inhibitors of serotonin and norepinephrine reuptake with a very
 small amount of dopamine reuptake inhibition (Table 178­6). These drugs have no significant direct effect on presynaptic or postsynaptic neurotransmitter receptors. The SNRIs differ in their degree of protein binding and apparent volume of distribution, from venlafaxine with 27% protein binding and  to  L/kg volume of distribution, to duloxetine with 95% protein binding and a 1640 L/kg volume of distribution. Venlafaxine is absorbed the fastest after ingestion, achieving peak levels at  hours, whereas duloxetine reaches peak blood levels  to  hours after ingestion.
TABLE 178­6
Serotonin/Norepinephrine Reuptake Inhibitors
Agent Recommended Maximum Daily Adult Dose (milligrams) Elimination Half­Life (h) Major Active Metabolites
Desvenlafaxine 100  None
Duloxetine 120  None
Levomilnacipran 120  None
Venlafaxine 375  Desmethylverlafaxine

The adverse effect profile during therapeutic use for these medications is similar to that for SSRIs. Venlafaxine is a notable exception and is able to produce mild to moderate hypertension when dosages exceed 225 milligrams/d, probably secondary to inhibition of norepinephrine reuptake.

Duloxetine appears to have more GI side effects, such as nausea, dizziness, and vomiting, but causes less hypertension than venlafaxine.
CLINICAL FEATURES
All SNRIs cause sympathetic nervous system stimulation via inhibition of norepinephrine reuptake, which predisposes patients to tachycardia, hypertension, diaphoresis, tremor, and mydriasis. Most of these effects are of moderate severity and can usually be managed with supportive care
 alone. Patients may display alterations in level of consciousness, with mild to moderate sedation being fairly common and progressing to coma on rare occasions. Generalized seizures tend to occur early after ingestion and are more common after overdose with venlafaxine than after most SSRI
 exposures. Subclinical rhabdomyolysis has been observed in about 25% of patients without seizures and 60% of patients with seizures following a
 venlafaxine overdose. Large overdoses of venlafaxine can produce severe global impairment of left ventricular systolic contraction with a markedly
 reduced ejection fraction.
ECG abnormalities are common following intentional SNRI overdoses. Sinus tachycardia is the most common ECG abnormality observed, but QRS
 ,38 widening and QT interval prolongation have also been reported. Mortality is low in isolated overdose.
TREATMENT
Establish a peripheral IV line, initiate cardiac rhythm monitoring, and obtain an ECG (Table 178­7). Single­dose activated charcoal is logical therapy
 for most SNRI overdoses if seen within an hour after ingestion. Gastric lavage and ipecac syrup are contraindicated due to the potential for seizures
 and aspiration. Consider whole­bowel irrigation with a large venlafaxine ingestion. Benzodiazepines are the anticonvulsants of choice. Hypertension and sinus tachycardia rarely require specific pharmacologic therapy, and β­blockers have the theoretical disadvantage of allowing unopposed α­ adrenergic receptor stimulation. Treat hypotension with fluids and direct­acting α­agonists.
TABLE 178­7
Treatment of Serotonin/Norepinephrine Reuptake Inhibitor Overdose
IV access, cardiac rhythm monitor, and ECG
Single­dose activated charcoal if ingestion within  h
Consider whole­bowel irrigation with large (>4000 milligrams) venlafaxine overdoses
Treat seizures with IV benzodiazepines
IV fluids for rhabdomyolysis
Sodium bicarbonate for prolonged QRS complex
Magnesium sulfate for QTc interval prolongation
IV fluids and direct­acting vasopressors for hypotension
Asymptomatic patients should be observed for  hours. Symptomatic patients should be admitted to a monitored bed. Patients ingesting extendedrelease preparations require additional observation for at least  hours due to the possibility of delayed onset of toxicity.
SEROTONIN SYNDROME
Serotonin syndrome is a potentially life­threatening adverse drug reaction to serotonergic medications. It can be produced by any drug or, more
40–44 commonly, by a combination of drugs that increase central serotonin neurotransmission (Table 178­8). Antidepressants are the drug class most commonly associated with serotonin syndrome. Serotonin syndrome is characterized by a combination of alterations in cognition and behavior,
40–44 autonomic nervous system function, and neuromuscular activity. The degree of abnormality in any one area is highly variable. The stimulation of specific postsynaptic serotonin receptors is required for full expression of this syndrome, primarily the serotonin 5­HT and 5­HT receptors, but
1A 2A other receptor subtypes may contribute. Drugs that block postsynaptic serotonin receptors are incapable of inducing this syndrome and are often used as a form of treatment.
TABLE 178­8
Serotonergic Drugs
Antidepressants
Monoamine oxidase inhibitors: phenelzine, tranylcypromine, isocarboxazid, pargyline, rasagiline, and selegiline
Selective serotonin reuptake inhibitors: fluoxetine, sertraline, paroxetine, fluvoxamine, citalopram, and escitalopram
Serotonin/norepinephrine reuptake inhibitors: venlafaxine, desvenlafaxine, levomilnacipran, and duloxetine
Cyclic antidepressants: amitriptyline, clomipramine, desipramine, doxepin, imipramine, nortriptyline, protriptyline, and trimipramine
Atypical antidepressants: trazodone (moderate potency), bupropion (low potency), and vilazodone (moderate potency)
Other Agents (potency to cause serotonin syndrome)
Amantadine (low potency) Lysergic acid diethylamide (moderate potency)
Amphetamines (moderate potency) Meperidine (high potency)
Bromocriptine (low potency) Mescaline (moderate potency)
Buspirone (moderate potency) Metoclopramide (low potency)
Carbamazepine (low potency) Pentazocine (low potency)
Cocaine (moderate potency) Pergolide (low potency)
Codeine (low potency) Reserpine (low potency)
Dextromethorphan (high potency) St. John’s wort (moderate potency)
Fentanyl (moderate potency) Sumatriptan and related triptans (high potency)
Levodopa (moderate potency) Tramadol (high potency)
Linezolid (high potency)
Lithium (high potency)
L­Tryptophan and 5­hydroxytryptophan (high potency)
CLINICAL FEATURES
The triad of cognitive, autonomic, and neuromuscular effects is a classic feature of the serotonin syndrome (Table 178­9). The vast majority of serotonin syndrome cases occur in patients taking serotonergic drugs at therapeutic dosages, but approximately 10% of cases develop after an overdose of serotonergic medication. Serotonin syndrome usually occurs within  to  hours after the dosage of a serotonin agonist
(e.g., a monoamine oxidase inhibitor or an SSRI) has been increased or after a second serotonergic agent (e.g., dextromethorphan) has been added.
TABLE 178­9
Clinical Features of Serotonin Syndrome
Major Minor
Cognitive Altered level of consciousness Insomnia
Agitation Restlessness
Anxiety
Autonomic Hyperthermia Tachycardia
Diaphoresis Hypertension or hypotension
Tachypnea
Mydriasis
Neuromuscular Muscle rigidity Akathisia
Hyperreflexia Incoordination
Myoclonus
Tremor
The importance of serotonin syndrome in emergency practice is twofold. First, the diagnosis of serotonin syndrome is very challenging because of its
,46 nonspecific symptomatology. Mild cases of serotonin syndrome frequently are misinterpreted as other psychiatric and medical disorders, and severe cases are often misdiagnosed as neuroleptic malignant syndrome because the two disorders share some features such as
,48 hypertension, tachycardia, tachypnea, fever, hypersalivation, and diaphoresis (Table 178­10). Without proper recognition of patients at risk for serotonin syndrome, one may inadvertently precipitate serotonin syndrome by administering serotonergic agents (e.g., meperidine, tramadol, dextromethorphan). To prevent iatrogenic precipitation of the serotonin syndrome, use drug databases and other resources to evaluate for potential drug interactions.
TABLE 178­10
Comparison of Serotonin Syndrome, Neuroleptic Malignant Syndrome, and Anticholinergic Toxicity
Serotonin Anticholinergic
Neuroleptic Malignant Syndrome
Syndrome Toxicity
Precipitating Addition of Addition of dopamine antagonist or withdrawal from dopamine agonist Addition of event serotonergic agent anticholinergic agent
Onset Usually within  h Usually within days to weeks Usually within 1–2 h
Distinguishing Myoclonus, tremor Bradyreflexia (sluggish reflex response) and bradykinesia (motor slowing or Dry skin and mucous features psychomotor retardation) membranes
Hyperreflexia Lead pipe rigidity Normal muscle tone and reflexes
The severity of serotonin syndrome varies (Table 178­11). The most commonly reported signs and symptoms associated with serotonin syndrome
40–44 are altered mental status, hyperthermia, and increased muscle tone. Myoclonus is a common finding in serotonin syndrome and is an important distinguishing feature, because myoclonus is rarely seen in other conditions that mimic serotonin syndrome (see Chapter
47–50
179, “Monoamine Oxidase Inhibitors,” Chapter 180, “Antipsychotics,” and Chapter 202, “Anticholinergics”).
TABLE 178­11
Severity Pattern of Serotonin Syndrome
Category Clinical Features
Mild Mild agitation, mild fever (<40°C), tremor, myoclonus, hyperreflexia, diaphoresis, mydriasis, elevated blood pressure and heart rate
Moderate Marked agitation, hyperthermia (>40°C), myoclonus, hyperreflexia, ocular clonus, increased bowel sounds
Severe Hyperthermia (>41.1°C), delirium, marked muscle rigidity, marked swings in blood pressure and heart rate
Muscle rigidity, when present, is especially prominent in the lower extremities, which serves as another valuable clinical marker for serotonin syndrome. Patients with ataxia should be examined carefully for lower extremity hypertonia. Unilateral muscle rigidity and focal neurologic findings are not expected. Seizures are always generalized and usually short lived. Hyperthermia is usually of moderate severity, but temperatures >41°C (106°F) have been reported and are a marker of a poor prognosis. Hypertension is twice as common as hypotension and is associated with a more favorable prognosis.
There are no confirmatory laboratory tests for serotonin syndrome. Therefore, the diagnosis of serotonin syndrome is based entirely on clinical assessment and exclusion of other psychiatric and medical conditions. Published diagnostic criteria for serotonin syndrome emphasize exposure to a
40–44 known serotonergic drug and the presence of muscle clonus alone or at least one or two of the other common features.
TREATMENT
The cornerstone of treating serotonin syndrome is discontinuing all serotonergic drugs and providing appropriate supportive care
40–44,50­52
(Table 178­12). All patients with serotonin syndrome should be admitted to the hospital until their symptoms have completely resolved.
Severely ill patients require admission to an intensive care unit. Approximately 25% of patients require endotracheal intubation and ventilatory support. Most patients show dramatic improvement within  hours of symptom onset. Mortality varies according to the severity of the syndrome and
41–44 aggressiveness of care. The most common cause of death is severe hyperthermia.
TABLE 178­12
Treatment of Serotonin Syndrome
Stop all serotonergic therapy
Initiate cardiopulmonary monitoring, establish peripheral IV access, and obtain ECG
IV fluid rehydration; evaluate for rhabdomyolysis
External cooling measures for hyperthermia
Benzodiazepines for agitation
Use short­acting IV antihypertensives (nitroprusside or esmolol) for severe hypertension
Use direct­acting IV vasopressors (norepinephrine, epinephrine, or phenylephrine) for hypotension resistant to IV fluid resuscitation
Cyproheptadine has been suggested in the past, but clinical evidence of benefit is lacking

Benzodiazepines are nonspecific serotonin antagonists and can be used to decrease patient discomfort and promote muscle relaxation. Patients with severe serotonin syndrome should be sedated, undergo neuromuscular blockade with a nondepolarizing agent, have an endotracheal tube placed, be started on mechanical ventilation, and be admitted to the intensive care unit.
41–44
Cyproheptadine, is an antihistamine and serotonin antagonist with anticholinergic effects. It can be used (off­label) for serotonin syndrome, but is only available in PO form. The initial dose is  milligrams, with repeat doses of  milligrams every  hours until clinical improvement is seen.

However, benefits of, and indications for, cyproheptadine are not known due to lack of supportive clinical evidence.
,43
Chlorpromazine is an antagonist of 5­HT receptors and there are reports of successful treatment of serotonin syndrome. The advantage of
2A chlorpromazine is that it is available in a parenteral form, but a potential disadvantage is that it can cause hypotension. It also blocks dopamine
 receptors, which can promote muscle rigidity, lower seizure threshold, and exacerbate neuroleptic malignant syndrome. The use of dopamine
 agonists (e.g., bromocriptine) has no accepted role in treating patients with serotonin syndrome. Dantrolene is a nonspecific muscle relaxant that is
 used occasionally in the management of serotonin syndrome, but clinical benefit is unproven.
Patients with muscle rigidity, seizures, or hyperthermia should be monitored closely for rhabdomyolysis and/or metabolic acidosis. Clinical features of the serotonin syndrome usually resolve within  hours after the inciting drug is stopped, with an exception being fluoxetine due to its long half­life and that of the active metabolite. Once a patient recovers from serotonin syndrome, avoid future exposure to serotonergic drugs (Table 178­4), although the risk of recurrence is unknown.


