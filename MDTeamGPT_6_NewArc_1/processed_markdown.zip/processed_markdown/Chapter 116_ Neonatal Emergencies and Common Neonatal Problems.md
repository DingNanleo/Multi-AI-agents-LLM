## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 116: Neonatal Emergencies and Common Neonatal Problems
Quynh H. Doan; Deepak S. Manhas
INTRODUCTION AND EPIDEMIOLOGY
Neonates, defined as infants ≤1 month old, or preterm infants within  days of their term due date, often visit EDs with vague and nonspecific symptoms and signs that may not point to a specific diagnosis. For example, respiratory distress can be caused by pulmonary or cardiac disease, generalized sepsis, abdominal pathology, or metabolic disorders. Many visits occur because of caregiver concerns about normal variants of newborn vegetative functions. Such concerns must be distinguished from potentially life­threatening congenital and acquired conditions that can present in the first month of life. This chapter reviews normal neonatal vegetative patterns, life­threatening neonatal emergencies, and common neonatal problems.
NORMAL NEONATAL VEGETATIVE FUNCTIONS
FEEDING PATTERNS
In the first few weeks of life, expect variation in times between feedings, but by the end of the first month, the vast majority of newborns establish a regular feeding schedule. Most healthy, bottle­fed infants eat  to  ounces (60–120 mL) every  to  hours, or six to nine feedings in  hours by the end of the first week of life; breastfed infants prefer shorter intervals—feeding every  to  hours. Intake is adequate if the neonate gains weight appropriately and appears content between feedings. Feedings are progressing well if the infant is no longer losing weight by  to  days of age and is gaining weight by  to  days of age.
WEIGHT GAIN
Weigh neonates completely undressed. Normal newborns may lose up to 12% of their birth weight during the first  to  days of life, with earlier and slightly more accentuated weight loss in exclusively breastfed newborns. A weight loss of up to 10% is acceptable if the infant’s examination, stooling, and voiding frequency and behavior are normal. On average, infants gain between  and  grams per day in the first  months of life and between  and  grams per day for the next several months.
STOOL PATTERNS
The number, color, and consistency of bowel movements can vary greatly in the same infant and between infants, regardless of diet or environment.

The median daily stools vary between types of nutrition (breast milk, formula, or mixed), ranging from  to . Stooling once a week or eight times per day may be normal if the clinical history and physical examination are also normal. Increased stools may be a result of excessive intake, concentrated or high sugar formula, maternal use of laxatives, malabsorption/enteropathy, or infection. Infrequent stooling may be normal (especially if breastfed) or may be a sign of constipation. Failure to pass meconium in the first  hours of life may suggest Hirschsprung’s disease or cystic fibrosis. Stool color has no significance unless it is acholic or bloody. The first stool, which consists of meconium, is usually passed within the first  hours after birth and is thick, sticky, and black. Transitional stools, which are greenish brown, appear after initiation of milk feeding and are replaced by typical yellow, seedy milk stools  to  days later.
BREATHING PATTERNS
The normal respiratory rate in neonates is  to  breaths/min. Newborn breathing is almost entirely diaphragmatic, and the soft front of the thorax is usually drawn inward during inspiration while the abdomen protrudes. Count the respiratory rate for a full minute with the infant resting or preferably asleep. Neonates increase minute ventilation almost entirely through an increase in respiratory rate rather than inspiratory volume; a neonate with a resting respiratory rate of >60 breaths/min during periods of regular, quiet breathing requires evaluation for the cDaouwsnelos aodfe tda c2h02y5p­n7e­1a .6 I:n7d Pra w Yionug ra InPd i tsa 1ch3y6p.1n4e2a. 1m5a9y. 1s2ig7nify intrathoracic or intra­abdominal pathology. Check the nares and upper airway, as nCehoanpateter s1 a1r6e: oNbeliognaateta nl oEsme ebrrgeeanthceierss, aanndd Cnaosmaml coonn gNeesotinoant,a ol rP crhoobalenmals s, tQenuoysnihs oHr. aDtroeasnia; ,D caene pcaaku sSe. rMesapnirhaatsory distress. 
. Terms of Use * Privacy Policy * Notice * Accessibility
Newborn infants, especially those born prematurely, may exhibit periodic breathing that is characterized by alternating periods of a normal or fast rate and periods of a markedly slow rate of respiration, with pauses of  to  seconds between breaths. Irregular respiratory patterns are seen in many premature babies during sleep, but are less common in term infants. Periods of apnea >20 seconds or apnea accompanied by bradycardia, cyanosis, or a change in muscle tone is abnormal and requires evaluation (see Chapter 118, “Sudden Infant Death
Syndrome,” and Chapter 117, “Brief Resolved Unexplained Events and Apparent Life­Threatening Events”).
SLEEPING AND FEEDING PATTERNS
Newborns awaken every  minutes to  hours, and sleep periods are spread evenly across the day and night. By  months of age, most sleep occurs at night, and by  months, most infants are sleeping through the night. When the child cries during the night, parents should make sure that there is no physical reason for crying. There are many methods of sleep training, none of which has been documented to be medically superior to others.
CRYING
The symptom complex of crying or irritability is fairly common yet difficult to treat, even in the presence of an identifiable cause. Most neonates exhibit varying degrees and periods of crying during a 24­hour period. Total crying time increases after birth, peaking at  to  months of age. Infants who present with an episode of acute, inconsolable crying, however, require careful evaluation for an underlying cause (Table 116­1).
TABLE 116­1
Conditions Associated With Inconsolable Crying, Irritability, and/or Lethargy in Neonates
System Emergent Less Serious
CNS Intracranial hemorrhage (neonatal alloimmune thrombocytopenia, birth trauma, — nonaccidental trauma, vitamin K deficiency)
Meningitis
Elevated intracranial pressure
Eye, ear, nose, Nasal obstruction (choanal atresia or stenosis) Corneal abrasion, ocular foreign body throat
Otitis media
Nasal congestion (upper respiratory infection)
Oral thrush
Stomatitis
Pulmonary Pneumonia —
Cardiac Supraventricular tachycardia —
Heart failure
GI Volvulus Gastroesophageal reflux disease (reflux)
Intussusception
Incarcerated hernia Gastroenteritis
Anal fissure
Colic
GU Testicular torsion Urinary tract infection
Genital hair tourniquets Diaper rash
Paraphimosis
Musculoskeletal Hair tourniquet of finger/toe Injuries (diaper pin, sharp or irritating objects from clothing)
Nonaccidental trauma
Infectious Sepsis Upper respiratory infection
Pneumonia
Meningitis
Metabolic Inborn errors of metabolism —
Hypoglycemia
Congenital adrenal hyperplasia
Babies with inconsolable crying are at higher risk of being physically abused or shaken. The Period of Purple Crying is a method for parents to deal
 with the stress of the crying and prevents babies from being shaken. This program suggests methods to help stop the baby from crying and also reminds parents that it is okay to put the crying baby down in a safe space and to take a few minutes to calm down.
THE CRITICALLY ILL NEONATE
Principles of Basic Life Support, Pediatric Advanced Life Support, and the Neonatal Resuscitation Program are reviewed in Chapter 108, “Resuscitation of Neonates.” A brief differential of critical neonatal illness is presented here (Table 116­2), with further discussion of specific complaint­based differential diagnosis and management to follow.
TABLE 116­2
Causes of Critical Illness in Neonates
Sepsis (bacteremia, urinary tract infection, meningitis)
Congenital heart disease (ductal­dependent lesions)
Pneumonia (bacterial, viral, chlamydia, aspiration)
Bronchiolitis
Air leak syndromes (pneumothorax, pneumomediastinum)
Congenital anatomic airway anomalies (cleft palate, laryngeal or tracheomalacia, laryngotracheal cleft, tracheal webs, tracheoesophageal fistula, tracheal hemangiomas, and vascular rings)
Neuromuscular disease (infant botulism, muscle weakness)
Inborn errors of metabolism
Congenital adrenal hyperplasia
Intracranial hemorrhage (vitamin K deficiency, nonaccidental trauma)
Abdominal catastrophe (malrotation, volvulus, necrotizing enterocolitis)
For the neonate with respiratory and/or cardiovascular distress, pay primary attention to adequacy of the airway and breathing. There are more stresses and fewer compensatory responses available to the neonate. The neonate has a compliant chest wall and cannot increase inspiratory force; the neonatal airway is small; functional residual capacity in the lungs is small; neonatal metabolism is characterized by high oxygen consumption; and abdominal distention can further impair ventilation. Consider the early use of positive­pressure ventilation or endotracheal intubation for respiratory insufficiency and nasogastric tube placement for gastric distention. Bradycardia in the neonate is almost always due to respiratory failure and hypoxia and usually corrects with restoration of adequate airway and breathing.
Tachypnea can be caused by minor problems, such as gaseous abdominal distention, or life­threatening illnesses, such as sepsis. True tachypnea
(respiratory rate >60 breaths/min) or grunting is an emergency; admit for further investigations, monitoring, and therapy in all but the mildest cases.
Cardiorespiratory symptoms in neonates are nonspecific and may be due to cardiovascular or respiratory failure or to systemic diseases. Search for pathologic conditions in all organ systems. For example, sepsis, meningitis, gastroenteritis, and metabolic acidosis may cause respiratory distress as the predominant symptom. Regardless of the cause, assess and stabilize the cardiac and respiratory systems before, or simultaneously with, further diagnostic evaluation.
When a specific cause cannot be identified, initiate a full sepsis evaluation (see Chapter 119, “Fever and Serious Bacterial Illness in Infants and
Children”), begin broad­spectrum antibiotics, and add IV acyclovir if there are any findings consistent with or suggestive of exposure to herpes simplex virus.
Conditions discussed in the following sections include common and uncommon symptom complexes in the critically ill neonate: neonatal sepsis; congenital heart disease; pneumonia; bronchiolitis; air leak sydromes; anatomic airway lesions; inborn errors of metabolism; congenital adrenal hyperplasia; neuromuscular disorders; intracranial hemorrhage; and abdominal catastrophe.
NEONATAL SEPSIS
Neonatal sepsis is the most common cause of neonatal cardiorespiratory distress. Fever or hypothermia signals serious infection in the neonate.
Fever in the first month of life is a rectal temperature ≥38°C (100.4°F), and hypothermia is a rectal temperature <36.5°C (97.7°F).
Neonates have about twice the risk of serious bacterial infection as do infants  to  weeks of age. Neonatal sepsis tends to appear as an “earlyonset” or a “late­onset” syndrome, with some overlap. Early­onset disease is seen in the first  days of life, tends to be fulminant, and is usually associated with maternal or perinatal risk factors, such as maternal fever, group B Streptococcus–positive vaginal swabs, prolonged rupture of membranes, and fetal distress. Late­onset disease usually occurs after  week of age, tends to develop more gradually, and is less likely to be associated with risk factors. Septic shock and neutropenia are more common with early­onset syndrome, and meningitis is more common in lateonset disease.
Clinical signs of early­ or late­onset sepsis are not specific. Septic infants may exhibit any of a variety of signs, as described in Table 116­3. Tachypnea and respiratory distress may be a sign of sepsis, meningitis, or urinary tract infection. Localizing signs may be absent—for instance, nuchal rigidity and
Kernig and Brudzinski signs are present in a small minority of neonates with meningitis.
TABLE 116­3
Signs of Neonatal Sepsis
Temperature instability (fever, hypothermia)
CNS dysfunction (lethargy, irritability, seizures)
Respiratory distress (apnea, tachypnea, grunting)
Feeding disturbance (vomiting, poor feeding, gastric distention, diarrhea)
Jaundice
Rashes
Bacterial causes of neonatal sepsis reflect organisms that colonize the female genital tract and nasal mucosa of caregivers. In general, the two groups of pathogens most frequently encountered are gram­positive cocci, such as β­hemolytic streptococci, and enteric organisms, such as Escherichia coli and Klebsiella species, and Haemophilus influenzae. Listeria monocytogenes also causes sepsis and meningitis in neonates. Viral infections are another cause of fever and are most likely due to enteroviruses (coxsackievirus and echovirus) acquired at the time of delivery or respiratory syncytial virus and influenza A virus acquired postnatally. The height of the temperature does not distinguish a viral versus bacterial cause in neonates.
The clinical investigation for neonatal sepsis is similar to that of an older infant except that the threshold for a full sepsis workup, including cerebrospinal fluid analyses, is lower. Admit all neonates to the hospital, and initiate treatment with empiric IV antibiotics. Initial treatment of a neonate with suspected bacterial septicemia or meningitis usually includes ampicillin (50 milligrams/kg to cover group B Streptococcus and
Listeria) and an aminoglycoside (gentamicin, .5 milligrams/kg) to cover E. coli and other gram­negative organisms and possible
 gram­negative meningitis. Avoid ceftriaxone in neonates as it can displace bilirubin and cause kernicterus. When gram­negative meningitis is strongly suspected, replace gentamicin with cefotaxime or ceftazidime (50 milligrams/kg), which have better CNS penetration. Add IV acyclovir for neonates with a maternal history of herpes or suspicious cerebrospinal fluid findings (predominance of
 lymphocytes and erythrocytes in a nontraumatic lumbar puncture) and all neonates who are ill appearing. For further detailed discussion, see
Chapter 119. CONGENITAL HEART DISEASE
Suspect congenital heart disease in a well­developed neonate who presents with unexplained cardiorespiratory collapse, cyanosis, and or tachypnea, especially without chest retractions or use of accessory muscles for breathing (see Chapter 129, “Congenital and Acquired Pediatric Heart
Disease”). Undiagnosed congenital heart disease may be first identified after discharge from the newborn nursery and typically becomes symptomatic at one of two distinct time frames: in the first week of life or after the second week of life (see Chapter 129). In the first week of life, lesions dependent on pulmonary or systemic blood flow through the ductus arteriosus (e.g., hypoplastic left heart syndrome, critical coarctation of the aorta) present with shock and acidosis as the duct begins to close. This can be mistaken for sepsis. Lesions that involve left­to­right shunting of blood
(ventricular and atrial septal defects) typically present after the second week of life with congestive heart failure as pulmonary vascular resistance falls, allowing pulmonary overcirculation and the onset of congestive heart failure.
PNEUMONIA
The lungs are the most common site of infection in neonates. Neonatal pneumonia contributes to significant mortality in developing countries, whereas the incidence of neonatal pneumonia in full­term infants in developed countries is lower. Table 116­4 displays the various causes, the
 associated clinical picture, and suggested management of neonatal pneumonia. Chapter 128, “Pneumonia in Infants and Children,” further addresses pneumonia after the neonatal period.
TABLE 116­4
Neonatal Pneumonia
Etiology Clinical Presentation Management Approach
Common bacterial [group B Streptococcus Fulminant illness with onset within  h of birth, with Full evaluation for sepsis (blood and
(most common), Escherichia coli, Listeria infection likely acquired in utero from contaminated urine cultures, chest radiographs, and monocytogenes, Haemophilus influenzae B, amniotic fluid environment. CBC). Blood culture results are typically
Streptococcus pneumoniae, Klebsiella negative. Two culture samples may species, Enterobacter aerogenes] increase diagnostic yield fourfold.
Respiratory distress, unstable temperature (high or low), A lumbar puncture should be done if irritability or lethargy, tachycardia, and poor feeding may be there are no contraindications.
present.
Hospitalization, supportive care (oxygen), and parenteral antibiotics (ampicillin and gentamicin; adjust as per culture and sensitivities when available).
Chlamydia Develops in 3%–16% of exposed neonates (in colonized Sepsis evaluation as indicated.
mothers).
CXR may show hyperinflation with interstitial infiltrates.
Usually occurs after  wk of age, accompanied by Definitive diagnosis by nasopharyngeal conjunctivitis in one half of cases. Often afebrile, tachypneic, swab for PCR or cultures.
with prominent “staccato” cough. Wheezing uncommon.
Eosinophilia may be seen on peripheral blood count.
Treatment: macrolide (erythromycin, clarithromycin, or azithromycin).
Bordetella pertussis In addition to pneumonia, may cause paroxysms of cough ± Sepsis evaluation as indicated.
cyanosis and posttussive emesis in otherwise well­looking infant. Characteristic whoop is not present in neonates. Diagnosis via nasopharyngeal swab for
Apnea may be the only symptom. Suspect when adult PCR and/or culture.
caregiver also has persistent cough.
Lymphocytosis in peripheral blood count is nonspecific but supports the diagnosis.
Macrolides are effective against B.
pertussis but are not approved by the
U.S. Food and Drug Administration for infants <6 mo.
No available data on efficacy of azithromycin or clarithromycin in infants
<1 mo old, but case series show less adverse effects with azithromycin.
Neonates should be admitted during treatment and monitored for adverse effects.
Mycobacterium tuberculosis Half of infants born to actively infected mothers develop TB Sepsis evaluation as for bacterial if not immunized or treated. pneumonia.
CXR, culture of urine, gastric and tracheal aspirates.
May be acquired by transplacental means, Skin testing not sensitive in neonates.
aspiration/ingestion of infected amniotic fluid, or postnatal airborne transmission. Routine anti­TB treatment.
Often presents with nonspecific systemic symptoms with Supportive treatment as needed.
multiorgan involvement (fever, failure to thrive, respiratory distress, organomegaly).
Viral pneumonia/pneumonitis (HSV, Initial upper respiratory illness progressing to respiratory Sepsis evaluation as indicated and IV respiratory syncytial virus, adenovirus, distress and feeding difficulty. acyclovir if HSV is suspected.
human metapneumovirus, influenza, parainfluenza) Hypoxia, apnea, and bradycardia (with HSV) may be present. Viral testing (direct antigen detection/PCR/cultures) of nasopharyngeal washings (swab).
Often indistinguishable from bronchiolitis. Rate of concurrent bacterial infections in confirmed viral infection is low.
CXR for significant respiratory distress.
Supportive therapy; monitoring for apnea in young and premature infants.
Abbreviations: CXR = chest roentgenogram; HSV = herpes simplex virus; PCR = polymerase chain reaction; TB = tuberculosis.
BRONCHIOLITIS
A detailed discussion of bronchiolitis can be found in Chapter 127, “Wheezing in Infants and Children.” Neonates are at particularly high risk for serious complications from bronchiolitis, because of obligate nose breathing and respiratory mechanics. Factors that predispose to complications of bronchiolitis include prematurity, underlying pulmonary or congenital heart disease, initial oxygen saturation
<92%, and bronchiolitis caused by respiratory syncytial virus.
Acute bronchiolitis is a clinical diagnosis, and neonates present with nasal discharge and sneezing followed by diminished appetite, difficulty with feeds, cough, dyspnea, irritability, and, occasionally, periods of apnea. Respiratory symptoms include hypoxia, wheezing, retractions, and possibly palpable liver and spleen due to pulmonary hyperinflation. Bronchiolitis caused by any virus can be associated with apnea, especially in
 neonates and preterm infants who are of corrected age <8 weeks old. While apnea usually presents within the first  days of illness, it may develop even if the neonate displays only minimal respiratory distress, and there are no reliable predictors for the development of apnea.
Routine ancillary testing (chest radiograph, blood tests, viral/bacterial cultures) is not recommended and should be used only in the context of clinical suspicion of concomitten severe bacterial infections (Chapter 119, “Fever and Serious Bacterial Illness in Infants and Children”). While bacterial pulmonary infection is not likely in confirmed viral bronchiolitis, a urinalysis should be obtained in febrile neonates (temperature >38.0°C
[100.4°F]), as up to 4% of febrile infants with bronchiolitis have concomitant urinary tract infection. The risk of bacteremia and meningitis associated with bronchiolitis is quite low, and full sepsis evaluation is not needed unless the neonate appears ill. There is no role for antibiotics, inhaled corticosteroids, or β­adrenergic bronchodilators. The evidence surrounding the use of inhaled epinephrine and hypertonic saline
,8 remains equivocal.
AIR LEAK SYNDROMES
Air leak sydromes such as pneumothorax and pneumomediastinum can occur in neonates who have previously had mechanical ventilation, but may also occur spontaneously or after aspiration or be associated with pneumonia or other underlying lung disease (including congenital anatomic lesions). Management is generally conservative, but may require drainage with needle decompression or chest tube (see Chapter 261, “Pulmonary
Trauma”).
ANATOMIC AIRWAY LESIONS
The anatomically correctable causes of respiratory distress in newborns are less common and include anomalies of the upper respiratory tract (e.g., choanal atresia, laryngomalacia, tracheomalacia, micrognathia, macroglossia, tracheoesophageal fistula, vascular slings) or lower respiratory tract
(e.g., congenital lobar emphysema, sequestration, congenital pulmonary airway malformation, congenital diaphragmatic hernia). Most of these anomalies are identified in the newborn nursery, but in the ED, these diagnoses should be considered in any infant with respiratory distress.
Admission is needed for diagnosis.
NEUROMUSCULAR DISORDERS
Any form of muscle weakness may be associated with shallow breathing and a compensatory increase in respiratory rate. Infantile botulism is one possible acquired cause and is usually preceded by constipation, followed by a weak cry and feeding difficulties. Ocular palsies, apnea, weakness or hypotonia, and lethargy are late symptoms of botulism. Other causes of hypotonia that may cause respiratory symptoms include trisomy ; hypoxicischemic encephalopathy; spinal cord lesions, such as myelomeningocele; spinal muscular atrophy; myasthenia gravis; metabolic disorders; and myotonic dystrophy.
INBORN ERRORS OF METABOLISM
Inborn errors of metabolism may manifest as lethargy or respiratory and/or cardiovascular collapse in the neonate. Although the differential diagnosis of inborn errors of metabolism is extensive, the ED evaluation necessitates only a few tests, including bedside glucose, electrolytes, blood gas analysis, serum ammonia, and urine for ketones. Follow up on newborn screening if available. More specific testing can wait until after resuscitation. Administer dextrose­containing IV fluids for suspected metabolic disease until specialty consultation can be obtained. In cases of neurologic signs and hyperammonemia, consider sodium benzoate and sodium phenylacetate because neurologic outcomes correlate with the duration of hyperammonemia. For further discussion, see Chapter 146, “Metabolic Emergencies in Infants and Children.”
CONGENITAL ADRENAL HYPERPLASIA
Congenital adrenal hyperplasia is one of the few acute life­threatening endocrine emergencies that present in the neonatal period (see Chapter
146, “Metabolic Emergencies in Infants and Children”). Although many newborn screens test for this disorder, infants may present in shock before screening results are known, typically in the first or second week of life. On examination, look for virilization, ambiguous genitalia, and hyperpigmentation. Hyponatremia and hyperkalemia occur in the salt­wasting form of congenital adrenal hyperplasia. Administer hydrocortisone
(12.5 to .0 milligrams IV/IM/IO) promptly, while undertaking other resuscitative measures. Treat hyperkalemia with standard measurements only if associated with ECG changes.
INTRACRANIAL HEMORRHAGE
Intracranial hemorrhage, either as a result of birth trauma or nonaccidental trauma, is another consideration in the critically ill neonate. Risk factors include home delivery without administration of vitamin K (associated with hemorrhagic disease of the newborn) or traumatic vaginal delivery.
Consider head CT after initial resuscitation if a diagnosis is not apparent or intracranial pathology is suspected.
ABDOMINAL CATASTROPHE
Consider abdominal catastrophe in the critically ill neonate with abdominal symptoms. Congenital malrotation can lead to midgut volvulus and intestinal infarction, with bilious vomiting, a distended rigid abdomen, sepsis, and circulatory collapse. Necrotizing enterocolitis, while typically a disease of premature infants, can present in the term neonate with poor feeding; abdominal distention, tenderness, and discoloration; lethargy or irritability; vomiting or diarrhea; temperature instability; apnea; and circulatory collapse. These and other abdominal considerations are discussed in
Chapter 133, “Acute Abdominal Pain in Infants and Children,” and are reviewed briefly later (see “GI Concerns”).
SYMPTOM­BASED NEONATAL PROBLEMS
Common symptom­based neonatal problems that may result in ED visits include irritability, colic, upper airway complaints, apnea and periodic breathing, GI symptoms, eye complaints, and abnormal movements.
IRRITABILITY
Normal crying was discussed earlier (see “Normal Neonatal Vegetative Functions”), and Table 116­1 lists the important causes of irritability in the neonate. Obtain a thorough history focusing on symptoms other than crying, such as changes in feeding, temperature instability, and vomiting, and perform a systematic head­to­toe examination. Palpate the fontanelles for signs of dehydration (sunken) or infection or intracranial hemorrhage
(bulging). If corneal abrasion is possible, examine the eyes with fluorescein staining. Inspect the mouth for oral thrush and check diaper area and groin for rashes, hair tourniquets (also check fingers and toes), and hernias or testicular torsion. Auscultate the heart to appreciate dysrhythmias or murmurs, and observe respiratory effort that may point to a pulmonary or metabolic cause of irritability. Obtain a bedside glucose in all neonates with altered mental status, vomiting, or a history of poor oral intake. Examine the abdomen for tenderness, distention, or discoloration suggestive of intraabdominal pathology and the extremities for signs of trauma.
If a careful history and complete physical examination reveal no source for the crying and the infant quiets during the ED visit, further testing is unnecessary and parents can be reassured and advised to follow up with their primary care physician.
INTESTINAL COLIC
Colic is a symptom complex consisting of the sudden onset of paroxysmal crying, a flushed face, circumoral pallor, tense abdomen, drawn up legs, cold feet, and clenched fists. The cause is not known. Colic is defined as a paroxysm of crying for ≥3 hours per day for ≥3 days per week over a
3­week period. It may begin as early as the first week of life but seldom lasts beyond  to  months of age. Infant colic is a diagnosis of exclusion. Physical examination is normal, and laboratory tests are not required. However, when the diagnosis is unclear, a careful history, physical examination, and appropriate laboratory investigations are necessary to rule out conditions listed in Table 116­1. There is no specific treatment for colic. Altering feeding practices (smaller volumes, slower feeds with burping, dairy/soy restriction, alternate hydorlyzed formula) may decrease symptoms. If symptoms do not resolve, restrictive diets are not recommended. Administration of drugs or sedatives is contraindicated. Infant colic can create significant caregiver stress and fatigue and is a risk factor for nonaccidental neonatal trauma.
Carefully assess the caretaker’s mental health and explore strategies to provide respite if needed.
UPPER AIRWAY CONCERNS
Cough and Nasal Congestion
Cough associated with sneezing and nasal congestion is usually due to viral upper respiratory infection. Neonates with underlying pulmonary or heart disease such as bronchopulmonary dysplasia or hypoplastic left heart may develop respiratory failure with even mild upper respiratory infections.
Inquire about sick siblings and perinatal infectious risk factors. Pay attention to the relation between respiratory symptoms and feeding that might suggest reflux and aspiration, or even congenital tracheoesophageal fistula, as a cause. Respiratory difficulty when quiet and improvement during crying suggest choanal atresia. Treat the underlying condition: cough is the infant’s primary protective reflex; do not give cough suppressants to neonates. Over­the­counter cold medications are not effective, may be dangerous in infants, and are contraindicated for children <6 years old. Treat nasal congestion with instillation of saline drops and bulb suctioning.
Noisy Breathing and Stridor
Noisy breathing is a common presenting complaint in neonates and is usually benign, but consider serious underlying pathology. Distinguish between inspiratory and expiratory sounds through careful listening in order to distinguish stertor, stridor, and wheezing. Stertor is an inspiratory sound like snoring or snorting that localizes to the nose or nasopharynx and is usually benign, but can be a symptom of choanal stenosis. Inability to pass a small nasogastric tube through the affected nostril is diagnostic of this condition. Stridor is a sign of upper airway obstruction and may be evident on both inspiration and expiration. The most common cause of stridor in neonates is laryngomalacia, which is characterized by noisy, crowing, inspiratory sounds, usually present from birth, that usually decrease during the first year of life. These sounds generally resolve when the baby is prone. Nasal pharyngoscopy by an otolaryngologist confirms the diagnosis.
Stridor may also be a symptom of congenital anomalies causing a fixed obstruction anywhere from the nose to the trachea and bronchi, such as webs, cysts, atresia, stenosis, clefts, and hemangiomas. Stridor from fixed lesions is often biphasic, although it may be predominant in either inspiration or expiration. Stridor worsening with cry or increased activity suggests laryngomalacia, tracheomalacia, or subglottic hemangioma
(which often become symptomatic after the first few weeks of life). Stridor accompanied by feeding difficulties suggests a vascular ring, laryngeal cleft, or tracheoesophageal fistula. Occasionally an H­type tracheoesophageal fistula may present in the first month of life or later with recurrent pneumonia, respiratory distress after feedings, and problems clearing mucus. Tracheal stenosis may present initially with noisy breathing or a highpitched cry and disproportionate respiratory distress with mild upper respiratory infections. Stridor with hoarseness or weak cry suggests vocal cord paralysis, which is typically present at birth. Infants who were intubated in the neonatal period may develop subglottic stenosis causing stridor.
Infection (e.g., croup, epiglottitis, and abscess) as a cause of stridor in neonates is rare and is associated with fever. When the diagnosis is in doubt, admit the neonate for further evaluation, which may include pharyngoscopy, bronchoscopy, radiographs, or even ultrasonography.
APNEA AND PERIODIC BREATHING
Periodic breathing and apnea are defined earlier (in “Breathing Patterns”), and both may occur in the same patient. Apnea signifies critical illness and warrants investigation and admission for monitoring and therapy. Apnea may be precipitated by any of the disease conditions listed in Table 116­3 and usually indicates respiratory muscle fatigue and impending respiratory arrest. Provide airway and ventilatory support, and search for the cause. If no obvious cause is found, presume sepsis, obtain cultures, and initiate broad­spectrum antibiotics and acyclovir if there is concern for herpes simplex virus. Chapter 118, “Sudden Infant Death Syndrome,” and Chapter 117, “Brief Resolved Unexplained Events and Apparent Life­Threatening Events” cover conditions associated with apnea in detail.
GI CONCERNS
Emergent surgical causes of vomiting in the neonate include malrotation with volvulus, intussusception, necrotizing enterocolitis, and incarcerated hernia, all of which are discussed in Chapter 133. Common GI symptoms that bring neonates to the ED include feeding difficulties, gastroesophageal reflux, vomiting, blood in the diaper, diarrhea and dehydration, abdominal distention, and constipation. Table 116­5 reviews common GI disorders with their corresponding frequent presenting concerns.
TABLE 116­5
GI Concerns in Neonates
Diagnosis Common GI Signs General Management
Gastroesophageal reflux disease Regurgitation and GER Supportive
Feeding difficulties
Cow milk protein allergy Regurgitation and GER Cow milk and soy milk avoidance
Abdominal distention
Blood in diaper
Tracheoesophageal fistula Feeding difficulties NPO/IV fluids
Regurgitation and GER ENT and bronchoscopy
Respiratory distress
Pyloric stenosis Vomiting US
Dehydration General surgery consult
Irritability
Bowel obstruction (incarcerated hernia, duodenal/ileal/jejunal atresia) Vomiting NPO/IV fluids
Feeding difficulties General surgery consult
Abdominal distention
Midgut malrotation with volvulus Vomiting NPO/IV fluids
Feeding difficulties Upper GI
Abdominal distention General surgery
Blood in diaper
Irritability
Necrotizing enterocolitis Feeding difficulties NPO/IV fluids
Vomiting Antibiotics
Abdominal distention General surgery
Blood in diaper
Intussusception Blood in diaper US
Irritability Air enema
General surgery
Hirschsprung’s Constipation Rectal biopsy
Abdominal distention General surgery
Gastroenteritis Diarrhea and dehydration Rehydration
Abdominal distention Uncommonly antibiotics
Sepsis Feeding difficulties IV fluids
Vomiting Antibiotics
Abdominal distention Acyclovir
Irritability
Hypothyroidism Constipation Thyroid replacement
Abdominal distention
Abbreviations: ENT = ears, nose, and throat; GER = gastroesophageal reflux disease; NPO = nothing by mouth.
Feeding Difficulties
Most visits for feeding difficulties occur because parents perceive that the infant’s food intake is inadequate; normal feeding and benign feeding problems are discussed earlier (see “Normal Neonatal Vegetative Functions”). Rarely, anatomic abnormalities may cause difficulty in feeding and swallowing. A careful history usually pinpoints such difficulties as having started at birth, and these infants appear malnourished and dehydrated.
Potential causes include upper GI abnormalities (e.g., stenoses, strictures, laryngeal clefts, or cleft palate) and compression of the esophagus or trachea by a double aortic arch. Infants with a recent decrease in intake usually have acute illness, most often infectious, and should be evaluated urgently.
Regurgitation and Gastroesophageal Reflux
Regurgitation of small amounts of milk or formula is common in neonates due to reduced lower esophageal sphincter pressure and relatively increased intragastric pressure. Regurgitation is independent of effort or muscular contraction and likely represents the ultimate degree of GI reflux.
Parents may confuse regurgitation with vomiting. As long as the neonate is gaining weight, parents can be reassured that regurgitation is of no clinical significance and will decrease as the infant grows. Strategies to reduce reflux include thickening of feeds and upright feeding positioning. Infants who are not thriving or have respiratory symptoms related to feeding should be investigated for anatomic causes of regurgitation or chronic aspiration.
Regurgitation rarely results from pathologic processes, such as intrinsic compression of the esophagus or, occasionally, compression of the trachea, in which case it is usually accompanied by stridor and cough. Dysphagia, irritability, feeding aversion, anemia, and malnutrition are sequelae of chronic regurgitation with esophagitis, but this condition is rare. Investigations such as pH monitoring, endoscopy, and biopsy confirm the diagnosis of reflux esophagitis. Medications such as H blockers or proton pump inhibitors increase risk of infection in neonates and should be reserved only for
 infants with failure to thrive or other major symptoms of reflux.
Vomiting
Vomiting results from forceful contraction of the diaphragm and abdominal muscles. A detailed discussion of vomiting in childhood is provided in
Chapter 131, “Vomiting, Diarrhea, and Dehydration in Infants and Children,” while surgical conditions that present with vomiting are discussed in
Chapter 133, “Acute Abdominal Pain in Infants and Children”; those specific to the neonatal period are briefly discussed here.
Vomiting beginning at birth is most likely due to an anatomic abnormality, such as tracheoesophageal fistula (with esophageal atresia), upper GI obstruction (e.g., duodenal atresia, which has a higher incidence among infants with trisomy 21), or midgut malrotation. Vomiting may be a symptom unrelated to the GI tract, such as increased intracranial pressure, metabolic disorders, or infections (e.g., sepsis, urinary tract infections, and gastroenteritis).
Projectile vomiting is usually seen in infants with pyloric stenosis and may assume its characteristic pattern, projectile vomiting at the end of feeding or shortly thereafter, after the second and third weeks of life. Pyloric stenosis classically presents between  weeks and  months of age and is the most common surgically correctible cause of vomiting in newborns. The vomitus does not contain bile or blood, and typically the infant appears well with an increased appetite. Perform an abdominal examination with the infant relaxed and the stomach empty. Observe for prominent gastric waves progressing from left to right. Palpate for a firm olive­shaped mass under the liver edge. Observe the neonate feeding to confirm projectile vomiting and distinguish this from regurgitation. Definitive diagnosis is most commonly made with ultrasound examination of the
 pyloric length and diameter.
The well­appearing infant without dehydration, malnutrition, or electrolyte abnormalities can be discharged with a plan for outpatient surgical correction. Admit ill­appearing or dehydrated infants.
Blood in the Diaper
Parents may come to the ED complaining of blood in the neonate’s diaper. Several important distinctions must be made: first, confirm that the discoloration is blood by testing with a guaiac card if possible; it is not uncommon in the neonatal period to find urinary crystals that may cause an orange or red discoloration in the diaper that can be mistaken for blood. If blood is confirmed, the next important distinction is whether the origin is the GI tract or, in girls, the vagina. Bloody or mucous discharge is common and normal in female neonates due to withdrawal from placental estrogen.
Physical examination may reveal a small anal fissure as the source of bleeding. In the first  to  days of life, blood in the diaper is most commonly due to maternal blood that is swallowed during delivery. This possibility may be confirmed by the Kleihauer­Betke or Apt­Downey test, performed on a stool sample or scraped from the diaper if possible, which differentiates fetal from maternal hemoglobin in the stool. After the first few days of life, most causes of blood in the diaper are idiopathic, but consider coagulopathies, necrotizing enterocolitis, allergic or infectious colitis, and congenital defects. Cow’s milk allergy is an immunoglobulin E–mediated disorder, but most infants have cow’s milk protein intolerance rather than true allergy. Both conditions cause changes in the bowel mucosa that result in gassy, bloody, and mucous bowel movements; painful feeds; and worsened reflux. Eosinophils may be present in the stool, and the diagnosis may be confirmed by resolution of the problem after cow’s milk is removed from the diet. For unresponsive or severe cases, endoscopy and biopsy may be needed for diagnosis. A newborn with a single event of hematochezia and no concerning findings may be observed as an outpatient. Persistent symptoms or concerning exam findings should be further evaluated, and depending on the infant’s condition (hydration status and weight gain), admission with appropriate subspecialty care may be necessary (see Chapter 134, “Gastrointestinal Bleeding in Infants and Children”).
Diarrhea and Dehydration
Diarrhea and dehydration are discussed in detail in Chapter 131, and fluid and electrolyte therapy in Chapter 132, “Fluid and Electrolyte Therapy in
Infants and Children.” Diarrhea is abnormally frequent and liquid stools. The modifier abnormal is critical because stools can normally be frequent and liquid in young children. Consider infection in addition to feeding­related causes, although infectious diarrhea is predominantly seen in older infants in the United States. Neonates are particularly susceptible to dehydration and electrolyte abnormalities associated with severe diarrhea. In an infant, the normal extracellular fluid volume is 25% of body weight; therefore, a loss of 8% of body weight as extracellular fluid results in severe dehydration.
Weigh all neonates with diarrhea unclothed to allow comparison with previous weights and to provide a baseline for monitoring subsequent weights during the course of the disease. Start the physical examination with a general assessment of mental status and hydration (see Table 126­6). Document rectal temperature, pulse, and blood pressure, which provide additional information concerning the degree of illness. Consider rectal examination to look for anal fissures as a potential source of blood, and obtain a stool sample for detection of occult blood, culture, examination for leukocytes, measurement of pH, and detection of reducing substances.
Obtain serum electrolytes, particularly sodium and glucose, in all neonates with diarrhea and dehydration. Markedly elevated serum urea nitrogen with a relatively normal creatinine may indicate recent or rapid dehydration. Serum creatinine values tend to be low in infants and young children, and a creatinine value of  milligram/dL may represent a doubling in the normal value. In addition to stool testing as above, obtain a urine sample in the setting of fever to evaluate for urinary tract infection.
Admit most newborns with ongoing GI losses to the hospital for rehydration, since the loss of even seemingly small volumes of stool may cause severe dehydration in the neonate. Diarrhea, particularly when bloody or containing mucus, may be a sign of a more severe surgical abdominal process, such as volvulus, intussusception, or necrotizing enterocolitis, although all three of these conditions typically present with vomiting as well.
Abdominal Distention
Abdominal distention may be normal in neonates and is usually due to lax abdominal musculature, relatively large intra­abdominal organs, and distention from swallowed air. If the infant is comfortable and feeding well and the abdomen is soft, there is no need for concern. Abdominal distention may also occur in association with bowel obstruction, constipation, necrotizing enterocolitis, or ileus due to sepsis or gastroenteritis.
Congenital organomegaly (e.g., hepatomegaly, splenomegaly, or renal enlargement) undetected in the perinatal period also may cause abdominal distention.
Constipation
Infrequent bowel movements in neonates do not necessarily mean that the infant is constipated. Infants occasionally may go without a bowel movement for  to  days and then pass a normal stool. However, if the neonate has never passed stools, especially if there has not been a stool in the first  hours of life, consider intestinal stenosis, Hirschsprung’s disease, or meconium ileus associated with cystic fibrosis. Constipation occurring after birth but within the first month of life suggests Hirschsprung’s disease, hypothyroidism, anal stenosis, or an anteriorly displaced anus. Correct anatomic positioning of the anus is determined by measuring the distance between the gluteal cleft and the posterior fourchette in girls or the median raphe in boys. The anus should be no more anterior than two thirds of this distance. Neonates with constipation should have a careful evaluation of the lumbosacral spine for evidence of occult dysraphism, which may be associated with neurogenic bowel or bladder. The diagnosis of Hirschsprung’s disease is supported by absence of feces on rectal examination, a tonic or tight sphincter tone, and an abrupt change in bowel luminal size on barium enema, and is confirmed by a rectal biopsy demonstrating absence of ganglion cells. Infants with hypothyroidism present with constipation, feeding problems, a weak or hoarse cry, a large anterior fontanelle, hypothermia, hypotonia, and peripheral edema. Thyroid testing as part of the routine newborn metabolic screen varies from state to state in the United States. Early treatement of neonatal hypothyroidism is critical to prevent permanent neurodevelopmental delay.
JAUNDICE (HYPERBILIRUBINEMIA)
Jaundice signifies hyperbilirubinemia and can represent normal newborn physiology or a pathologic process. Bilirubin is a breakdown product of hemoglobin that is conjugated in the liver by glucuronyl transferase before it is excreted with bile into the GI tract. Once bilirubin reaches the intestinal lumen, brush border enzymes deconjugate some of the bilirubin, which is then reabsorbed through enterohepatic circulation. The remainder of the bilirubin is either oxidized by intestinal bacteria to urobilinogen (which is excreted in the urine) or passed in the feces, creating the normal yellow color of neonatal stool. Physiologic jaundice is characterized by a slow rise in bilirubin (<5 milligrams/dL per  hours), with a peak of  to
 milligrams/dL during the second to the fourth days of life and a decrease to <2 milligrams/dL by  to  days. Decreased neonatal hepatic glucuronyl transferase activity, a shortened life span of neonatal red blood cells and relative polycythemia, and decreased intestinal bacterial colonization all lead to an increase in enterohepatic circulation that produces the normal rise in bilirubin seen in physiologic jaundice. Other processes, both benign and pathologic, often cause bilirubin levels that are significantly higher than  milligrams/dL, and excessive hyperbilirubinemia can lead to permanent brain injury—kernicterus. Practice parameters for the evaluation and treatment of neonatal jaundice are summarized in

Table 116­6. TABLE 116­6
Neonatal Risk and Bilirubin Treatment Threshold for Hyperbilirubinemia
Age of Neonate
Bilirubin Treatment Threshold (milligrams/dL)  h  h  h  h  d  d  d
Low­risk neonates*       
Intermediate­risk neonates†       
High­risk neonates‡    .5   
*Full­term, well­appearing, and no risk factors (isoimmune hemolytic disease, glucose­6­phosphate dehydrogenase deficiency, asphyxia, lethargy, temperature instability, sepsis, acidosis, hypoalbuminemia [<3.0 grams/dL if measured]).
†Thirty­five to  6/7 weeks estimated gestational age without risk factors, or term with risk factors.
‡
Thirty­five to  6/7 weeks estimated gestational age with risk factors.
Distinguishing between physiologic and pathologic neonatal jaundice is important, and the timing of the onset of jaundice in the newborn provides useful clues. Table 116­7 lists various causes of hyperbilirubinemia in the neonate and their timing.
TABLE 116­7
Causes of Jaundice in Neonates
<24 h Hemolysis due to ABO, Rh incompatibility
Congenital infection (rubella, toxoplasmosis, cytomegalovirus infection)
Excessive bruising from birth trauma (cephalohematoma or intramuscular hematoma)
Acquired infection (e.g., sepsis, pneumonia)
2–3 d Physiologic
 d–1 wk Acquired infection (e.g., sepsis, urinary tract infection, pneumonia)
Congenital decrease in glucuronyl transferase (e.g., Crigler­Najjar syndrome, Gilbert’s syndrome)
Congenital infections (syphilis, toxoplasmosis, cytomegalovirus infection)
>1 wk Breast milk jaundice
Acquired infection (e.g., sepsis, urinary tract infection, pneumonia)
Biliary atresia
Congenital and acquired hepatitis
Red cell membrane defects (e.g., sickle cell anemia, spherocytosis, elliptocytosis)
Red cell enzyme defects (e.g., glucose­6­phosphate dehydrogenase deficiency)
Hemolysis due to drugs
Endocrine disorders (hypothyroidism)
Metabolic disorders (galactosemia, fructosemia)
Pyloric stenosis
The evaluation of the jaundiced neonate begins with a thorough history, including maternal infections during pregnancy; maternal blood type and
RhoGAM® administration; estimated gestational age (i.e., term or preterm); feeding patterns, including formula or breast milk, frequency, duration, and whether maternal milk supply is adequate and latching successful; stool history, including timing of first stool and transitional stools, color
(yellow, acholic), and frequency; regurgitation or vomiting; urine output; and documented fever. A family history of hemolytic anemia or prior neonatal jaundice might indicate an inherited disorder. Review maternal and fetal medications. When possible, obtain results of the infant’s blood type and maternal antibody screen.
On physical examination, note the degree of jaundice, which progresses in a cephalocaudal direction, although the level of jaundice does not reproducibly correlate with serum bilirubin levels. Scleral icterus is typically noted with serum bilirubin >5 milligrams/dL. Examine the head for cephalohematoma and assess the fontanelles for signs of dehydration or possible infection. Palpate the abdomen for organomegaly that might signify congenital infection or liver disease.
It is important to distinguish unconjugated hyperbilirubinemia from conjugated hyperbilirubinemia. Unconjugated hyperbilirubinemia is much more common, presents earlier in the neonatal period, and is related to the normal or abnormal breakdown of hemoglobin, although inherited enzyme deficiencies or infection may be pathologic causes. Conjugated hyperbilirubinemia results from the inability to excrete bilirubin into the bile and intestines and is usually the result of primary hepatic or biliary disease such as biliary atresia or hepatitis. Conjugated hyperbilirubinemia is always pathologic and often presents later in the neonatal period with jaundice, acholic stools, and dark urine.
At a minimum, laboratory studies for the jaundiced neonate should include a direct and indirect bilirubin. Transcutaneous bilirubin measurements correlate well with total serum levels but do not distinguish conjugated and unconjugated bilirubin. Transcutaneous measurement is thus limited to
 very low­risk neonates with a normal physical examination. When other pathologic conditions are suspected, the evaluation should be determined by the differential diagnosis and may include a CBC for anemia and red cell indices, a blood smear for hemolysis, reticulocyte count, liver function tests, and thyroid hormone levels. When infection is a concern, obtain appropriate cultures and Gram stains (urine, cerebrospinal fluid).
Septic infants with hyperbilirubinemia may have an increase in bilirubin by greater than the acceptable  milligrams/dL per 24­hour period and have other features of sepsis, such as vomiting, abdominal distention, respiratory distress, and poor feeding. Breast milk jaundice is thought to be due to the presence of substances that inhibit glucuronyl transferase in the breast milk; it may start as early as the third to fourth day and reaches a peak of  to  milligrams/dL by the third week of life. Although cessation of breastfeeding will result in a rapid decline of bilirubin over  to  days, it is not routinely recommended. Breast milk jaundice is unlikely to cause kernicterus and usually can be treated with phototherapy, when necessary. This should be distinguished from breastfeeding jaundice, or starvation jaundice, which can occur when a newborn is exclusively breastfed and the mother’s milk supply is still inadequate. Poor oral intake resulting in reduced bowel movement and bilirubin excretion through the
GI tract, coupled with relative dehydration, may accentuate physiologic jaundice. Optimizing the neonate’s feeding pattern with controlled supplementation, whether with expressed breast milk, donated breast milk, or formula, usually resolves the problem, but severe hyperbilirubinemia may require treatment.
The treatment of hyperbilirubinemia depends on the cause, but for most cases of unconjugated hyperbilirubinemia, phototherapy is sufficient.
Phototherapy causes a configurational change in the bilirubin structure that allows it to be excreted in the urine. There is no additional benefit to IV fluids coupled with phototherapy, so enteral feeding should always be encouraged, although the dehydrated infant may require fluid resuscitation.
Extreme levels of hyperbilirubinemia are treated emergently with exchange transfusion and require admission to hospital.
Risk factors include hemolysis risks (e.g., isoimmune hemolytic disease, glucose­6­phosphate dehydrogenase deficiency, ABO incompatibility), sepsis
(lethargy, temperature instability, irritability), asphyxia, hypoalbuminemia, and acidosis. In the first  hours of life, response to phototherapy is less predictable, and specific exchange transfusion indications are less certain during this period.
EYE COMPLAINTS
Watery Eyes
Clear eye discharge, and occasionally crusting over of the eyelashes without associated conjunctival redness or irritation, is commonly seen in neonates and infants and results from narrow or obstructed nasolacrimal ducts. This condition usually resolves spontaneously and requires antibiotics only when complicated by conjunctival erythema and inflammation (conjunctivitis or dacryocystitis). Ophthalmologic consultation for nasolacrimal duct probing is appropriate if this problem persists past  months of age or earlier if complicated by recurrent infection.
Red Eye and Irritation
Corneal irritation or abrasion can result from an eyelash or scratch from a fingernail. Perform fluorescein staining and evaluate with a Wood’s lamp or a hand­held slit lamp to identify corneal abrasions. Acute glaucoma, although rare, also presents as a red, teary eye. The cornea is cloudy, the anterior chamber is shallow, and the intraocular pressure may be increased. Promptly consult pediatric ophthalmology for all suspected cases of glaucoma.
Red Eye and Discharge
Conjunctivitis is described in detail in Chapter 122, “Eye Emergencies in Infants and Children.” The most common causes of neonatal conjunctivitis are chemical irritation, bacterial or chlamydial infection, and herpes simplex infection. Chemical conjunctivitis due to ocular prophylaxis usually occurs on the first day of life and requires no treatment.
Gonococcal conjunctivitis generally has its peak time of onset between  and  days after birth. Despite antibiotic prophylaxis at delivery, the failure rate of prophylaxis is about 1%. Neisseria gonorrhoeae invades superficial layers of the conjunctiva and, if untreated, causes corneal ulceration and can result in permanent loss of vision. For diagnosis, obtain a Gram stain and culture for N. gonorrhoeae. Treat gonococcal conjunctivitis with cefotaxime (50 milligrams/kg IV or IM). Cefotaxime is recommended for neonates, as ceftriaxone can displace bound bilirubin and precipitate kernicterus. Perform septic workup including lumbar puncture. Disseminated disease should be suspected until cerebrospinal fluid cultures are negative. Supportive care includes ocular irrigation with normal saline as soon as diagnosis is suspected, with frequent irrigation until the discharge is eliminated. Admit the neonate and obtain ophthalmology consultation. Topical antibiotic treatment alone is inadequate and unnecessary when systemic antibiotic treatment is given.
Chlamydial conjunctivitis becomes evident by the end of the first week throughout the first month after birth. The disorder varies in severity, from mild to severe hyperemia with a thick, profuse mucopurulent discharge and pseudomembrane formation. There often is severe edema of both lids.
Because isolation of Chlamydia trachomatis requires specialized tissue cultures, ensure proper technique in collecting culture specimens (e.g., Dacron swabs) and specimens for antigen detection.
Treat chlamydial conjunctivitis and pneumonia in neonates with oral erythromycin (50 milligrams/kg PO per day in four divided doses, for  days).
Oral sulfonamides may be used after the immediate neonatal period for infants who do not tolerate erythromycin. Topical treatment is unnecessary.
Because the efficacy of erythromycin therapy is approximately 80%, a second course is sometimes required. A specific diagnosis of C. trachomatis infection in an infant should prompt the treatment of the mother and her sexual partners.
The finding of vesicles anywhere on the skin or mucous membranes in association with neonatal conjunctivitis suggests herpes simplex infection and warrants a full sepsis evaluation with cerebrospinal fluid evaluation for herpes simplex virus and treatment with acyclovir,  milligrams/kg/dose three times a day.
ABNORMAL MOVEMENTS AND SEIZURES
Seizures are covered in detail in Chapter 138, “Seizures in Infants and Children.” It is important to distinguish benign sleep myoclonus in infancy and the normal startle reflex from actual seizures. Sleep myoclonus consists of rhythmic myoclonic jerks observed when the infant is drowsy or in quiet sleep and can be suppressed upon touching and/or waking the infant; the startle reflex is a single myoclonic jerk with extension of the arms and legs triggered by noise or tactile stimulation. Tetany due to hypocalcemia is associated with congenital syndromes, such as DiGeorge’s syndrome, and must also be distinguished from seizure activity.
Recognition of seizures in the newborn period is important, because seizure management and outcome are different than at any other age. Neonatal seizures are likely to present with subtle manifestations, such as eye deviation, tongue thrusting, eyelid fluttering, apnea, pedaling movements, or arching, rather than generalized activity. Neonatal seizures usually indicate a severe underlying structural or metabolic problem and are rarely idiopathic. Common causes include hypoxic ischemic encephalopathy, neonatal stroke, electrolyte disturbances, and underlying metabolic and genetic conditions. Nonaccidental injury must be considered. If seizures occur in the first  hours of life, consult neonatology and/or neurology, and
,13 consider therapeutic hypothermia to improve neurodevelopmental outcomes in hypoxic ischemic encephalopathy.
Acknowledgment
The authors gratefully acknowledge the contributions of Tonia J. Brousseau, the lead author of this chapter in the previous edition.


