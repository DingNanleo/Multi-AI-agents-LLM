## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 297: The Transplant Patient
Brit Long; Alex Koyfman
INTRODUCTION
,2
Organ transplantation is growing in frequency, with the first successful kidney transplant in the early 1950s. As of the beginning of 2013, there were
,047 active candidates waiting for solid­organ transplants in the United States, with the kidney transplant waitlist being the largest at ,903
 candidates. The kidney is the most commonly transplanted organ (58%), followed by liver (21%), heart (8%), lung (5%), pancreas (5%), and, less commonly, combined organ transplants and intestine transplants. Annually, there are approximately ,000 hematopoietic stem cell transplants in the

United States, with about one third of these transplants being allogenic transplants and two thirds being autologous transplants. The recent opioid epidemic has produced several challenges for the transplant­awaiting population. The increase in opioid­related deaths has led to an increase in the number of available organs; however, the risk of infection from opioid­related donor organs is slightly higher than from non–opioid substance user donors. The U.S. Public Health Service states that organs obtained from opioid abusers are at slightly increased risk of infection, although recent data suggest these organs can be safely used for transplant. Potential recipients also may suffer from addiction, which is associated with worse outcomes
 with transplantation.
Most transplant patients require lifelong immunosuppression. Transplant patients can develop a number of acute to life­threatening emergencies, including (1) transplant­related infection, (2) medication side effects, (3) rejection, (4) graft­versus­host disease, and (5) postoperative complications or complications of altered physiology secondary to the transplanted organ. Transplant patients may also have common medical problems that
 require unique management. Adverse outcomes often are directly proportional to increasing age of the recipient and the donor organ. Patients with transplanted organs may present significant challenges due to anatomic and physiologic variations, immunosuppression, complications from
,6­8 transplantation, and comorbidities.
The most common acute disorders prompting ED visits are infection (39%), followed by noninfectious GI/GU pathology (15%), dehydration (15%),
9­12 electrolyte disturbances (10%), cardiopulmonary pathology (10%) or injury (8%), and rejection (6%). Acute graft­versus­host disease is an
 important complication, especially in those with hematopoietic stem cell transplantation. Coronary artery disease, sudden cardiac death, and heart failure are the result of premature cardiovascular disease in solid­organ recipients, due to underlying comorbidities and metabolic effects of
 immunosuppression. Preoperative and regular postoperative cardiovascular assessment identifies risk factors and enables treatment to mitigate
 risks.
GENERAL APPROACH TO EVALUATION
HISTORY AND COMORBIDITIES
Key historical elements for the management of transplant patients are listed in Table 297­1. TABLE 297­1
Key Historical Elements Specific to Transplant Patients
Historical Item Significance
Recent temperature increase or decrease from baseline Potential clue to onset of infection or rejection.
DownlCohaadnegde s2 f0ro2m5 ­b7a­s1e l9in:4e fPun cYtioounr IP is 136.142.159.127 Decreased urine may signify rejection in renal transplant patients or acute
Chapter 297: The Transplant Patient, Brit Long; Alex Koyfman dehydration.
. Terms of Use * Privacy Policy * Notice * Accessibility
Decreased exercise tolerance may signify rejection in heart transplant patients.
Change in skin color (jaundice specifically) may signify rejection in liver transplant patients or graft­versus­host disease.
Date of transplant surgery The date from transplant helps to predict typical infections and types of posttransplant complications (i.e., graft­versus­host disease).
Graft source for solid­organ transplant, special features of graft if any, prior These details predict the potential for certain infections and rejection.
infections; donor living related vs. cadaveric
Graft source for hematopoietic stem cell transplant: autologous, degree of These details predict potential graft­versus­host disease.
match, related donor
Rejection history May predict current rejection if similar presentation and difficulty in controlling a current episode of rejection.
Recent changes in dosages of antirejection and other medications Although a planned part of transplant management, rejection is very common when immunosuppression doses are reduced.
Chronic infections (CMV, Epstein­Barr virus, hepatitis B and C, other viruses) History of chronic infections increases the chances that current presentation is an exacerbation.
Recent exposure to infections (chickenpox, CMV, tuberculosis) Increases the chance of current infection.
Recent history of compliance with immunosuppressive medications Noncompliance increases chance of rejection.
Recent travel, exposure to persons arriving from countries with endemic Exposure may predict unusual infections not commonly considered.
infections, exposure to potential foodborne illness or insect vectors
Complete list of all medications, including over­the­counter medication Complex drug interactions are common causes of symptoms in transplant patients and must be evaluated.
Baseline: blood pressure, body weight, serum creatinine (for renal Changes in these parameters may predict rejection or acute illness.
transplants), and expected levels of immunosuppressive medication
Abbreviation:CMV = cytomegalovirus.
PHYSICAL EXAMINATION
Direct the physical examination to the chief complaint, present illness, and evidence of complications of the transplant or immunosuppressive
9­13,16,17 medications (Table 297­2).
TABLE 297­2
Physical Examination in Transplant Patients
Examination Comments
Volume status Check static vital signs, orthostatic blood pressures, and pulse. Use US to assess inferior vena cava diameter as a measure of intravascular volume status.
Head, ears, eyes, Periorbital edema (glomerulonephritis), retina (CMV or toxoplasmic chorioretinitis, Listeria endophthalmitis), sinuses (Staphylococcus nose, and throat aureus, mucormycosis, and invasive fungal disease), mouth (Candida, HSV), neck (meningismus, retropharyngeal abscess), lymphadenopathy (CMV, EBV, hepatitis, posttransplant lymphoproliferative disorder).
Lungs Pneumonia is a common source of infections in transplant patients. Streptococcus pneumoniae and other community­acquired agents are still common sources, but opportunistic infections, such as Pneumocystis jiroveci pneumonia, Aspergillus, tuberculosis, coccidioidomycosis, and viral pneumonias, should be suspected. Noninfectious pulmonary infiltrates may also cause dyspnea.
Heart Pericardial friction rubs as a complication of uremia and a wide range of viral infections. New heart murmur can represent infection.
Abdomen Peritonitis without a defined source is one of the most common sites for infection in transplant patients. Right upper quadrant tenderness associated with hepatitis B and C, CMV, and EBV. Varicella­zoster virus causes pancreatitis. If left in place, peritoneal dialysis catheters can be sources of infection.
Flank and The urinary tract was the most common site of infection identified.
suprapubic area
Graft Renal graft usually placed in abdominal flap; inspect (look for signs of wound infection), palpate (graft tenderness and swelling are often seen in acute rejection, outflow obstruction, and pyelonephritis), and auscultate (bruits suggest renal artery stenosis and AV malformation or AV fistula). Deep tenderness over liver graft could indicate abscess.
Rectal Perirectal abscess is a common, yet often overlooked, source of infection in transplant patients.
Extremities Access sites for hemodialysis can be sources of infection. Peripheral edema in the transplant patient can represent a number of different etiologies: recurrent versus de novo glomerulonephritis, renal graft failure, liver graft failure, cirrhosis, nephrotic syndrome
(from native kidneys), renal vein thrombosis, malnutrition, hypoalbuminemia, and heart failure.
Skin Rashes are commonly seen in graft­versus­host disease, viral syndromes (hepatitis B and EBV), cellulitis from indwelling catheter sites, nocardial cutaneous lesions, and drug reactions.
Mental Cyclosporine/tacrolimus neurotoxicity, steroid psychosis, HSV encephalitis, Listeria meningitis/encephalitis, and cryptococcal status/neurologic meningitis.
examination
Abbreviations: AV = arteriovenous; CMV = cytomegalovirus; EBV = Epstein­Barr virus; HSV = herpes simplex virus.
DIFFERENTIAL DIAGNOSIS
Consider complications of immunosuppressive medication, infection, solid­organ rejection, and graft­versus­host disease (Tables 297­3 and 297­4).
Chronic immunosuppressant medications, including corticosteroids, cause a wide range of physical changes evident on physical examination.
Medication changes should be made by, or in consultation with, the patient’s transplant team. Outpatient or inpatient management depends on the severity of illness; the need for ongoing immunosuppression often requires admission when symptoms interrupt maintenance of medication.
TABLE 297­3
Adverse Reactions to Immunosuppressant Medications
Body System Adverse Effects
Constitutional Fever, rigors, malaise, dizziness, anorexia
Ophthalmologic Blurred vision, conjunctivitis, cataracts, papilledema, blindness
Mouth/ears Gingival hyperplasia, stomatitis, hearing loss, tinnitus
Respiratory Cough, dyspnea, interstitial lung disease, pneumonitis, pleural effusion, noncardiogenic pulmonary edema
Cardiovascular Hypertension, tachycardia, bradycardia, cardiomyopathy, congestive heart failure, hypotension, syncope
GI Nausea, vomiting, diarrhea, epigastric pain, esophagitis, gastritis, hiccups, constipation, hepatotoxicity, ascites, pancreatitis, colonic necrosis, bleeding
Musculoskeletal Myopathy, osteoporosis, tendon rupture
Hematologic Neutropenia, lymphopenia, anemia, thrombocytopenia, bleeding, thrombosis
Renal Nephrotoxicity, oliguria, dysuria, renal failure
Neurologic Headache, vertigo, paresthesias, tremors, convulsions, agitation, neuropathy, confusion, generalized weakness, leukoencephalopathy, encephalopathy, cerebral edema
Skin Alopecia, hirsutism, thickening, thinning, necrosis, edema
Metabolic Electrolyte disturbances (sodium, potassium, calcium, magnesium, phosphorus), fluid retention, hypercholesterolemia, hyperlipidemia, hyperglycemia, hypoglycemia
Endocrine Adrenal suppression
Immunogenic Susceptibility to infection, acute allergic reactions, anaphylaxis
TABLE 297­4
Physical Examination Clues to Complications of Medications and Graft­Versus­Host Disease
Concern Signs and Symptoms
Edema and other Assess symmetry, pain, color, temperature, and active range of motion. Suspect infection, orthopedic conditions, deep vein swelling thrombosis (due to immobility).
Skin breakdown The back, pressure points, heels, elbows, and leg ulcers (due to corticosteroid­induced weakness).
Joint range of Shoulders, elbows, fingers, wrists, and knees (may be limited due to steroid­induced weakness or sclerodermatous skin changes).
motion
Thoracic Relatively noncompliant edema like swelling on the chest wall. If present, ask about associated dyspnea on exertion.
constriction
Abdominal Firm skin. History of bloating, gas, constipation, diarrhea, nonspecific pains.
constriction
Sclerodermatous Sclerodermatous skin changes can affect joint mobility and GI and respiratory function. Note the firmness of edema and skin, skin especially on the thorax and around joints. A firm, soft leather consistency of swelling, tougher than cardiogenic pitting edema, can be a serious problem. Assess for recent­onset dyspnea on exertion.
Dehydration Increased thirst, loss of appetite, chills, fatigue, weakness, skin flushing, dark or decreased volume of urine, dry mouth, tachycardia, weight loss.
Electrolyte Signs and symptoms of dehydration above, hypotension, headache, bradycardia or tachycardia, irregular heartbeat, tremor, muscle disturbance weakness, increased urination, constipation, altered tendon reflexes, mood changes, abdominal pain, weight loss, muscle cramping.
Solid­organ rejection and graft­versus­host disease are immune­medicated inflammatory reactions that may present with fever, signs and symptoms, and laboratory and radiographic findings that resemble infection (see later discussions). Infection and rejection (or an exacerbation of graft­versushost disease) can occur simultaneously, and treatment should be started for both. When suspecting acute rejection or acute graft­versus­host disease, consult the transplant team about treatment. Typically, high­dose corticosteroids are given, but the steroid, the dose, and the duration of therapy should be confirmed.
POSTTRANSPLANT INFECTIONS
Infections account for a large number of deaths in transplant patients, with many infections undiagnosed until autopsy. Patients are at increased risk
,18­21 of infection, with an incidence of infection within the first year after transplant of 25% to 80%. Although immunosuppressive regimens can reduce the risk of rejection, they can also increase risk of infection. The level of immunosuppression depends on current regimen, underlying diseases, presence of necrotic fluid/fluid collection, presence of an indwelling device, metabolic disease, and concomitant viral infection. The time
20­25 from transplant also affects risk of infection and type of infection. Viral and bacterial illnesses may occur concurrently. Febrile episodes in the early phase after allogenic stem cell transplantation are likely related to infections secondary to neutropenia. Immunosuppression­induced blunting of the inflammatory response may mask the classic signs, symptoms, and laboratory markers of infection if the patient presents early in the course of the illness. Later in the course of infection, patients may present with more advanced ominous signs such as seizure, obtundation, coma, and cardiac
,12,19,21,26,27 arrest. Solid­organ transplant recipients have risk of bacteremia, often in the setting of urinary tract infection.
CLINICAL FEATURES
9­12
The most common reason for an ED visit by a transplant recipient is fever. Fever may be masked by immunosuppressive agents and other factors,
 such as steroids, uremia, and hyperglycemia, and may be absent in half of those with infection. Fever may be due to factors other than infection, such as drug effects, hypersensitivity reaction, rejection, or malignancy. Even a low­grade fever in a transplant patient should prompt an aggressive workup.
10­12,28
Although in the setting of infection transplant patients demonstrate temperatures lower than those of nontransplant patients, those with transplant still demonstrate a physiologic response to infection (temperature of .9°C vs. .2°C for transplant vs. nontransplant patients,
28­30 respectively). Specifically, patients on regimens including mycophenolate mofetil and azathioprine demonstrate decreased temperatures.

Signs and symptoms of infection depend on the type of infection and can, in part, be predicted by the time frame since the transplant (Table 297­5).
The specific site of infection also depends on the transplanted organ. Combining all posttransplant period groups, urinary tract infections (43%) and
 pneumonia (23%) are likely to be the most common infections. In contrast, a study of 238 ED presentations of febrile pediatric heart transplant
 patients found pneumonia in 24%, bacteremia in 3%, cellulitis in 2%, and urinary tract infection in 1%; the majority had a negative workup.
TABLE 297­5
Infections Stratified by Post­transplant Period
Period After
Infection Comments
Transplant/Conditions
<1 mo: resistant MRSA Opportunistic infections are generally absent during this period as full effect of organisms Vancomycin­resistant immunosuppression not complete. MRSA important in HSCT patients.
Enterococcus faecalis
Candida species
(including non­albicans)
<1 mo: complications of Aspiration C. difficile common during this period. Early graft injuries may abscess. Unexplained early signs surgery and Catheter infection of infection such as hepatitis, encephalitis, pneumonitis, or rash may be donor derived.
hospitalization Wound infection
Anastomotic leaks and ischemia
Clostridium difficile colitis
<1 mo: colonization of Aspergillus Microbiologic analysis of aspirates or biopsy from surgery essential for therapeutic decisions.
transplanted organ or Pseudomonas
HSCT neutropenia Klebsiella
Legionella
<1 mo: HSCT­specific Additional bacterial Neutropenia and mucocutaneous injury increase risk for HSCT patients. Lungs, bloodstream, infections pathogens: and GI tract most commonly affected sites.
Streptococcus viridans and enterococci
Viral infections include respiratory syncytial virus and HSV
1–6 mo: in patients with Polyomavirus BK Activation of latent infections, relapse, residual, and opportunistic infections occur during this
Pneumocystis jiroveci infection, nephropathy period. Viral pathogens and allograft rejection cause the majority of febrile episodes during this pneumonia and antiviral C. difficile colitis period. Polyomavirus BK, adenovirus infections, and recurrent HCV are becoming more
(CMV, HBV) prophylaxis HCV infection common.
Adenovirus infection, influenza
Cryptococcus neoformans infection
Mycobacterium tuberculosis infection
Anastomotic complications
1–6 mo: in patients Pneumocystis Discontinuation of prophylaxis at the end of this period may prompt active infection, especially without prophylaxis Infection with CMV. Graft­versus­host disease and mucocutaneous injury increase risk for HSCT patients.
herpesviruses (HSV, varicella­zoster virus,
CMV, Epstein­Barr virus)
HBV infection
Infection with Listeria,
Nocardia, Toxoplasma,
Strongyloides,
Leishmania,
Trypanosoma cruzi
>6 mo: general Community­acquired Community­acquired organisms dominate during this period. Transplant recipients have a pneumonia and urinary persistently increased risk of infection due to community­acquired pathogens.
tract infections
Infection with
Aspergillus, atypical molds, Mucor species
Infection with Nocardia,
Rhodococcus species
>6 mo: late viral infections CMV infection (colitis and In some patients, chronic viral infections may cause allograft injury (e.g., cirrhosis from HCV retinitis) infection in liver transplant recipients, bronchiolitis obliterans in lung transplant recipients,
Hepatitis (HBV, HCV) accelerated vasculopathy in heart transplant recipients with CMV infection) or a malignant
HSV encephalitis condition such as PTLD or skin or anogenital cancers.
Community­acquired viral infections (severe acute respiratory syndrome, West Nile)
JC polyomavirus infection (progressive multifocal leukoencephalopathy)
Skin cancer, lymphoma
(PTLD)
Abbreviations:CMV = cytomegalovirus; HBV = hepatitis B virus; HCV = hepatitis C virus; HSCT = hematopoietic stem cell transplant; HSV = herpes simplex virus; MRSA
= methicillin­resistant Staphylococcus aureus; PTLD = posttransplantation lymphoproliferative disorder.
DIAGNOSIS AND TREATMENT

The evaluation should include routine testing as well as additional tests based on complaint, history, and physical examination (Table 297­6).
TABLE 297­6
Diagnostic Tests to Consider in the Evaluation of Infections in the Transplant Patient
Test Comments
CBC Leukocytosis or left shift of the WBC count may be blunted by immunosuppressive agents.
Renal function tests: BUN, Essential in the evaluation of renal transplant patients; may help determine dosing of antibiotics in all transplant patients.
creatinine
Liver function tests May show mild transaminase elevations with cytomegalovirus and Epstein­Barr virus infections and much higher elevations with hepatotropic viruses such as hepatitis B and C viruses. May be elevated in Legionella infections.
C­reactive protein Significant elevations more likely in infections versus noninfectious infiltrates.
Procalcitonin level Significant elevations more likely in infections versus noninfectious infiltrates.
CT of the brain Focal infections in the brain are much more common in this population, but CT should be used only as clinically indicated.
Cyclosporine or tacrolimus These levels may be deliberately low depending on the desired level of immunosuppression. Bioavailability may be level or other levels of variable.
immunosuppressants
Cultures of mouth, sputum, Collect as indicated by history and physical. Urine Legionella antigen should be considered before treatment of patients urine, blood, stool, vascular with pneumonia with GI complaints. Bacterial and fungal cultures of blood and urine should be obtained on all patients.
access, and wound sites
Cerebrospinal fluid cultures Collect as indicated by history and physical.
and antigen tests
Serology: cytomegalovirus, Because viral and fungal cultures are not very sensitive, clinicians should rely on their acumen to order organism­specific
Epstein­Barr virus, hepatitis, antigen assays and antibody titers. When contemplating viral or parasitic infections, these tests should be obtained to toxoplasmosis, allow identification of bacterial, fungal, and viral pathogens. May be useful in patients with diffuse lymphadenopathy.
cryptococcosis
Chest radiograph Infiltrates on chest radiograph may reflect infectious or noninfectious complications of hematopoietic stem cell transplant or organ transplant. Obtain in posttransplant fever to evaluate for source.
CT of the chest Patients with evidence of pulmonary infiltrates on chest radiograph or high­resolution CT, but without productive sputum, may ultimately require bronchoscopy with bronchoalveolar lavage and transbronchial biopsy for definitive diagnosis.
CT or US to include the These scans can be used to identify likely abscess formation or possible anastomotic leaks.
graft
Tests after admission Beyond the scope of this chapter, but may include biopsy of the transplanted organ, bronchoalveolar lavage on bronchoscopy, and focused imaging of suspected sites of infection.
Creatine kinase May have increased levels in infections with certain organisms, such as Legionella.
Urinalysis As dictated by history and examination. Recommended in patients with renal transplant.
Lactate Evaluate for severity of illness (sepsis and septic shock).
Biopsy Typical standard diagnosis requires biopsy of graft, which is not obtainable in ED but should be discussed with admitting physician.

Leukopenia can represent acute bacterial infection, and leukopenia with an increase in atypical lymphocytes is commonly seen with viral infections, especially cytomegalovirus. Pulmonary infections that are encountered frequently include Pneumocystis jiroveci, Nocardia, Legionella pneumophila, and Aspergillus; these require special stains and studies for accurate diagnosis.
Treatment recommendations should be determined by careful analysis of each individual patient for potential atypical infections requiring specific coverage. Resuscitation with intravenous fluids and broad­spectrum antimicrobials is recommended in patients with sepsis or septic shock. Empiric
32­34 antimicrobial therapy for transplant patients is outlined in Table 297­7. Empiric treatment prior to confirmatory studies should first involve antibacterial agents and then, especially if there is concern for meningitis or encephalitis, antiviral agents such as acyclovir. Discuss treatment of suspected fungal infections or atypical infections with the transplant team. The emergency provider should discuss the case with the patient’s
,7,18,19,35 transplant physician, and consultation with infectious disease specialist may improve outcomes and reduce mortality.
TABLE 297­7
Empiric Antimicrobial Therapy
Condition Antimicrobial Agent Comments* All patients Discuss agent(s) with The transplant team caring for the patient should always be consulted as soon as possible; transplant team. however, in certain life­threatening situations, empiric broad­coverage therapy may be indicated immediately.
Suspected Site­specific agents are The urgency for treatment should be based on the patient’s presenting condition; bacterial infection site preferable if predicted by infections are the most aggressive organisms requiring coverage, but some fungal infections may based on history initial findings, balanced by yield sepsis. In general, broad coverage for any suspected site infection is recommended initially and physical known pathogens as listed in pending cultures and further workup to define noninfectious causes of fever.
examination Table 297­5. Neutropenia in Third­generation Multiple alternative agents used, including an aminopenicillin plus a β­lactam inhibitor such as the absence of cephalosporin such as piperacillin­tazobactam or cefepime. Monotherapy has fewer complications, but concern for MRSA symptoms ceftazidime or a carbapenem remains high. Addition of antiviral and antifungal agents should be at the discretion of the suggesting site­ plus coverage for MRSA below. transplant team.
specific infection
Suspected MRSA Vancomycin In the majority of patients, MRSA infection should be seriously considered as a potential cause of infection, pending cultures. Linezolid is an alternative antibiotic.
Parasitic Trimethoprim­ Consider Toxoplasma gondii, Pneumocystis jiroveci.
infections sulfamethoxazole after discussion with transplant team
Viral infections Ganciclovir or valganciclovir Consider treatment for CMV pneumonia, CMV chorioretinitis, CNS or disseminated herpes simplex for CMV, acyclovir for herpes or varicella­zoster.
simplex and varicella­zoster
Fungal infections Discuss with transplant team; Consider Aspergillus, Candida albicans, Cryptococcus neoformans.
agent depends on site and severity of illness
Abbreviations:CMV = cytomegalovirus; MRSA = methicillin­resistant Staphylococcus aureus.
*Standard doses apply but may be altered by transplant team recommendations.
GRAFT­VERSUS­HOST DISEASE
Graft­versus­host disease is a major cause of morbidity and mortality, affecting approximately 50% of allogeneic hematopoietic
 stem cell transplantation patients, and is caused by donated T cells attacking antigens on host cells, but it also occurs after small
 bowel or liver transplantation, as well as transfusion of unirradiated blood products in high­risk groups. Hyperacute graft­versus­host disease is an unusual and severe form of acute graft­versus­host disease. Onset occurs in the first week after hematopoietic stem cell transplantation and is
38­41 characterized by fever, generalized erythroderma, severe hepatitis, fluid retention, widespread inflammation, and shock.
Acute graft­versus­host disease is classified as appearance of the disease up to 100 days after transplant. A well­appearing hematopoietic stem cell transplantation recipient with a nonspecific rash (most common symptom) or diarrhea (second most common symptom) should be suspected of
 having new­onset or an exacerbation of graft­versus­host disease. The most widely used graft­versus­host prophylaxis includes a combination of a
 calcineurin inhibitor (e.g., cyclosporine, tacrolimus) with methotrexate. In patients who recover from acute graft­versus­host disease, later long­term complications from chronic graft­versus­host disease are common.
Chronic graft­versus­host disease is a late complication characterized by immune dysregulation (>100 days after transplantation) and is a distinct
 clinical syndrome from the acute form. It results in severe morbidity, with complications affecting skin (sclerodermatous contractures), muscles
(myopathy), bone (osteoporosis), eyes (keratoconjunctivitis sicca), nerves (peripheral neuropathy), and the cardiopulmonary system (physical deconditioning), resembling autoimmune disorders. Risk factors include older age, CMV seropositivity, and a male who received a stem cell transplant
  from a multiparous woman. Management is similar to the acute form with prolonged immunosuppression.
ACUTE GRAFT­VERSUS­HOST DISEASE
The disease is typically characterized by involvement of three different systems: skin (rash), gastrointestinal, and liver (jaundice,
 hepatitis).Consider graft­versus­host disease in any patient with a rash. Rash is often misattributed as a drug reaction. The typical rash is maculopapular, frequently demonstrating a brownish hue and slight scaling (Figure 297­1). The rash can be pruritic and painful. The distribution varies greatly but often affects palms and soles initially, and later progresses to cheek, ears, neck, trunk, chest, and upper back. In the more severe
 forms, erythroderma or bullae develop. Mucositis has been reported to occur in 35% to 70% of patients.
FIGURE 297­1. Rash of acute cutaneous graft­versus­host disease. The maculopapular lesions have acquired a brownish hue, and there is slight scaling. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology, 6th ed. © 2009, McGraw­Hill, Inc.,
New York.]
Diarrhea, GI bleeding, or hepatic dysfunction can occur. Diarrhea, with or without upper GI symptoms such as anorexia, nausea, and emesis, is common and may appear green, mucoid, and watery. Symptoms include painful cramping, ileus, and, sometimes, life­threatening hemorrhage from the colon. Hepatic involvement is characterized by increase in liver function studies. GI hemorrhage in the early posttransplant period may be a result of coagulation abnormalities, especially thrombocytopenia. The differential diagnosis of GI bleeding in this setting includes all the usual causes of GI
,46 bleeding in addition to bleeding due to acute graft­versus­host disease–related damage to colonic tissues and infection (viral, fungal, or bacterial).
Diagnosis requires endoscopy.
Treatment is directed by the transplant team, typically PO prednisone or IV methylprednisolone, at  to  milligrams/kg daily, and possibly adjustment
 of other immunosuppressant doses. Patients may require resuscitation with balanced crystalloids, blood product resuscitation (leukocyte­depleted
 and irradiated red blood cells), electrolyte replacement, and broad­spectrum antibiotics.
Disposition and interval for follow­up are also determined by the transplant team. Survival approaches 50% at  year with intensive corticosteroid
,44,45 therapy, with 50% developing chronic disease.
TRANSFUSION­ASSOCIATED GRAFT­VERSUS­HOST DISEASE
Most living cells that are in transfused blood survive for no more than a few days or weeks. However, in some patients, transfused cells engraft, expand, and circulate. When immunocompetent T lymphocytes engraft in an immune­suppressed patient, transfusion­associated graft­versus­host disease
,49 may occur and is almost always fatal. It is possible to avoid transfusion­associated graft­versus­host disease by irradiating blood products before transfusion. Patients with immunocompromise or other risk factors (Table 297­8) should receive irradiated blood products.
TABLE 297­8
Significant Risk Factors for the Development of Transfusion­Associated Graft­Versus­Host Disease
Congenital and acquired immunodeficiency syndromes
History of bone marrow (stem cell) transplantation, whether allogeneic or autologous
Transfusions from blood relatives (“directed donation”)
Transfusions with fresh whole blood
Premature infants receiving any sort of transfusion
Human leukocyte antigen–matched platelet transfusions
Hodgkin’s disease, even when in remission
Leukemia not in remission
Patients treated with purine analogues; the effects of fludarabine and cladribine (2­CdA) persist for a year
POSTTRANSPLANTATION LYMPHOPROLIFERATIVE DISORDER
Posttransplantation lymphoproliferative disorders consist of lymphomas occurring after organ transplantation, particularly solid­organ and allogeneic hematopoietic stem cell transplants. Posttransplantation lymphoproliferative disorders are associated with poor outcomes and are not
,51 uncommon, accounting for up to 21% of all cancers in patients receiving solid­organ transplants. The incidence is increasing due to older age of transplant donors and recipients, increasing number of transplants, new immunosuppressive agents, newer types of stem cell transplantation, greater
 awareness of the disease, and improved diagnosis. Primary risk factors depend on the organ transplanted (kidney transplant has the lowest risk).
Specific T­cell depletion procedures display higher risk of posttransplantation lymphoproliferative disorders in the setting of haploidentical allogeneic hematopoietic stem cell transplantation, as does the specific immunosuppressive regimen used. Age greater than  years and Epstein­Barr virus
52­55 seronegative status before transplantation elevate the risk of posttransplantation lymphoproliferative disorders. The incidence of posttransplantation lymphoproliferative disorders follows a bimodal curve, with an initial spike during the first and second year and a second spike  to  years after transplantation. The presentation varies, ranging from asymptomatic to fulminant organ failure or tumor lysis syndrome.
Posttransplantation lymphoproliferative disorders display a high incidence of extranodal involvement often involving the GI tract (up to 30% of cases),
,56,57 solid allografts (15%), and the CNS (5% to 20%). Diagnosis typically includes histopathologic examination based on six subclasses. However, this is not available in the ED. Treatment varies but typically involves reduction of immunosuppression, surgical extirpation, local radiation, rituximab,
 chemotherapy, cellular immunotherapy, and/or stem cell transplantation.
TRANSPLANTATION MEDICATION EFFECTS
Transplant patients are typically on extensive medication regimens including immunosuppression. In the 1980s, this consisted of corticosteroids and azathioprine, but current regimens are more extensive, with many options dependent on the patient, specific organ transplant, and time from
 transplant (Table 297­9).
TABLE 297­9
Transplantation Medications
Medication Mechanism Adverse Effect
Cyclosporine Calcineurin inhibitor; decreases T Acute/chronic nephrotoxicity, electrolyte derangements (hyperkalemia,
(Sandimmune®, lymphocyte activity and IL­2 function hypomagnesemia), gout, hemolytic­uremic syndrome, gingival hyperplasia, generic) hirsutism, hypertension, hyperlipidemia
Tacrolimus (Prograf®) Calcineurin inhibitor; inhibits T Similar to cyclosporine lymphocyte activity and IL­2 function Neurotoxicity (headache, tremor, paresthesias, seizures), hair loss instead of hirsutism, less hypertension/hyperlipidemia
Azathioprine Blocks nucleotide production for Bone marrow suppression, macrocytosis, anemia, hepatotoxicity, pancreatitis
(Imuran®) immune cell replication
Mycophenolate Cytostatic effect on B and T cells; Abdominal pain, decreased oral intake, nausea/vomiting, diarrhea, anemia, mofetil (CellCept®) decreases proliferation by inhibiting leukopenia, thrombocytopenia nucleotide synthesis
Corticosteroids Impairs phagocyte function Weight gain, cataracts, acne, skin thinning, bruising, osteoporosis, GI bleeding,
Attenuates production of hyperglycemia, hyperlipidemia, psychologic effects, cushingoid appearance proinflammatory mediator
Decreases T­cell activity
Decreases cell signal transduction
Sirolimus Blocks mTOR receptor and immune cell Thrombocytopenia, leukopenia/anemia (less common), diarrhea, mucosal irritation,
(Rapamune®) signal transduction, reducing B­ and T­ buccal ulceration, interstitial pneumonitis, hyperlipidemia cell activity
Polyclonal antibodies Antilymphocyte antibody Fever, serum sickness, anaphylaxis, anemia, thrombocytopenia
(antithymocyte γ­ Used for immunosuppression when globulin) nephrotoxic agent is held
Used for treatment of corticosteroid resistant rejection
Monoclonal Antilymphocyte antibody OKT3: During first  days of therapy, may have headache, aseptic meningitis, antibodies (OKT3, IL­2 Used for prophylaxis against rejection in encephalopathy, seizures, nausea, vomiting, diarrhea, pulmonary edema, receptor antibody) early period nephrotoxicity
Used for immunosuppression when IL­2 receptor antibodies have rare adverse effects such as anaphylaxis nephrotoxic agent is held
Used for treatment of corticosteroid resistant rejection
Abbreviations: IL­2 = interleukin­2; mTOR = mammalian target of rapamycin.
TRANSPLANTATION REJECTION
A feared complication other than infection includes graft rejection, as many do not fully recover from an episode of rejection. Immunosuppressive regimens have reduced the risk of rejection, although this is balanced with the risk of infection. Several phases of rejection are present including hyperacute (minutes to hours after transplant due to preexisting antibodies), acute (within the first  months due to acute cellular rejection or humoral rejection), and chronic (months to years after transplant due to antibody and cell­mediated rejection). Presentations of rejection are demonstrated in

Table 297­10. TABLE 297­10
Presentations of Transplant Rejection
Transplant
Symptoms/Signs Management
Organ
Renal Many asymptomatic Acute rise in serum creatinine; electrolyte abnormalities.
Symptoms: US may demonstrate increased graft size, loss of
Hypertension corticomedullary junction, prominent hypoechoic
Fever, malaise, oliguria, graft pain, and tenderness over site pyramids.
Worsening renal function with decreased urine output and rising Renal Doppler studies may demonstrate elevated vascular serum creatinine resistance indices.
Biopsy needed during admission.
Liver Fever, malaise, abdominal pain, hepatosplenomegaly, ascites Laboratory abnormalities: elevated liver function tests and bilirubin.
US of graft and vasculature may find focal lesion or vascular abnormality.
Biopsy needed during admission.
Cardiac Dyspnea at rest/exertion, orthopnea, palpitations, near­syncope/syncope, Cardiac troponin and B­type natriuretic peptide often peripheral edema, or GI symptoms with right heart involvement elevated.
Chest pain is absent due to denervation during surgery ECG may demonstrate T­wave/ST­segment changes.
Dysrhythmias common Echocardiogram with systolic/diastolic dysfunction.
Chest radiograph may demonstrate findings of congestive heart failure.
Biopsy needed during admission.
Lung Shortness of breath and cough most common Eosinophilia suggestive on CBC with differential.
Lung examination variable: clear lung fields, crackles, or decreased breath Normal chest radiograph is not reliable to rule out disease.
sounds Chest CT often required.
May demonstrate stridor or wheezes Pulmonary function testing not helpful in differentiating
May present with respiratory distress or failure infection and rejection.
Effusion requires thoracentesis.
Bronchoscopy and biopsy needed during admission.
SPECIFIC TYPES OF TRANSPLANTATION
RENAL TRANSPLANTATION
Renal transplantation is the preferred treatment for end­stage renal disease. Kidneys obtained from deceased or living donors are most commonly
,6,8,58 placed in the recipient’s pelvis, with the ureters anastomosed to the bladder. Vascular complications that occur following renal transplantation include renal artery stenosis, allograft infarction, arteriovenous fistulas, pseudoaneurysm, graft hematoma, and renal artery or vein thrombosis.
Nonvascular complications include ureteral obstruction, urine leak, periallograft fluid collections (hematomas, lymphoceles, and abscesses),
 neoplasms, GI complications, and posttransplant lymphoproliferative disease. The major causes of renal transplant loss are death from vascular, malignant, or infectious disease, and loss of the allograft from chronic renal dysfunction associated with the development of graft fibrosis and glomerulosclerosis. Medication changes and use of an imaging contrast agent that may affect renal function (including gadolinium­based contrast
 agents) should be discussed with the patient’s transplant team.
DIAGNOSTIC TESTING
Table 297­6 lists recommendations on diagnostic testing in transplant patients, including renal transplant patients. The serum creatinine level is the most valuable prognostic marker of graft function at all times after transplantation and should be obtained whenever renal failure or infection is
 suspected, which is often elevated in the setting of transplant infection or rejection. The urinalysis provides important clues to acute changes in graft viability. Red blood cell casts and proteinuria are commonly seen in recurrent or de novo glomerulonephritis. The presence of WBCs, bacteria, and
,61 nitrites is helpful in diagnosing urinary tract infections, which is one of the most common complications with renal transplant. However, pyuria
,60,61 may present with rejection. Proteinuria may signal rejection, drug toxicity, glomerular disease, or other graft nephropathy, although proteinuria from a remaining native kidney should also be considered. Obtain cyclosporine or tacrolimus blood levels for all patients on these medications.
Contact the patient’s transplant team regarding abnormal drug levels, because low drug levels are sometimes deliberately used to reduce side effects.
IMAGING
US is the best test to detect urinary obstruction. Renal graft US can also be useful in patients suspected of having pyelonephritis, vascular abnormalities (stenosis, thrombosis, pseudoaneurysm, hematoma, and arteriovenous fistula), perinephric abscess, urine leak, wound infection, or an episode of rejection.
62­64
CT angiography may be used to diagnose vascular complication such as hematoma, artery stenosis, and vascular thrombosis.
MRI can be helpful in evaluating hematomas and other fluid collections, vascular abnormalities, and small infarcts caused by medication­induced vasculitis. Magnetic resonance angiography has the advantage of requiring either no contrast material or a gadolinium chelate that is less nephrotoxic
 than other agents. However, gadolinium­based contrast agents can cause acute renal failure in up to .5% of patients with underlying chronic renal
 insufficiency. Therefore, the patient’s transplant team should be consulted before using gadolinium­based contrast agents.
GRAFT DYSFUNCTION AND FAILURE
Chronic renal dysfunction precedes the majority of graft failures. Acute renal failure in transplant patients is defined as a 20% rise from baseline serum creatinine levels, as opposed to a 50% rise in other patients with acute renal failure. Consider the conditions described in Table 297­11 when
,67 evaluating possible graft dysfunction or even a small increase in serum creatinine.
TABLE 297­11
Differential Diagnosis of Renal Allograft Dysfunction
Differential Disorder Comments
Mechanical Presents with decreased urine output. At US, a urine leak (i.e., urinoma) appears as a well­defined,
Complications of surgery anechoic fluid collection with no septations that increases in size rapidly. Requires consultation with
Ureteral obstruction urology and transplant physician. Obstruction typically requires Foley catheter placement, followed
Urine leak: urinoma, ascites, or abscess by stent placement.
Lymphocele Results from perivascular lymphatic vessel leakage, which forms a collection of lymphatic fluid in up to
15% of patients within the first  months of transplant.
Vascular The transplanted kidney is usually placed extraperitoneally in the right iliac fossa. End­to­side
Renal artery stenosis or thrombosis (12%) anastomosis to the external iliac vasculature provides circulation. Color duplex imaging of the renal
Renal vein thrombosis artery and vein is helpful in assessing renal vascular stenosis or thrombosis. CT angiography can be
Renal artery and renal vein thromboses are utilized as well. Treatment often includes thrombolysis for vascular stenosis/thrombosis and surgery uncommon; they usually occur in the first for peritransplant hematoma.
month after transplant.
Peritransplant hematoma
Glomerulonephritis
Infection Urinary tract infections are the most common source of bacteremia in renal transplant recipients, and
Urinary tract infection infectious diseases are the second leading cause of death in this population. See “Posttransplant
Interstitial nephritis from polyoma BK virus, Infections” section. At least two antibiotics should be used for treatment of urinary tract infection.
cytomegalovirus, herpes viruses  and , and adenovirus
Rejection Most common presentation of rejection in renal transplant patients is hypertension and falling urine
Hyperacute output, but rejection may be asymptomatic. Fever, pain, malaise, oliguria, and site tenderness may
Acute occur. Comparison of creatinine at the time of presentation to prior levels is critical, as creatinine
Late (recurrent acute) elevation is common. Fever may be a presentation of rejection.
Chronic cellular
Chronic humoral
Recurrent pyelonephritis/vesicoureteral reflux Common problem threatening graft and patient survival
Nephrotoxic agents Drug serum levels do not correlate well with the degree of renal damage. NSAIDs are contraindicated
Aminoglycosides, fluoroquinolones, cidofovir, in this group. Avoid contrast agents if possible.
foscarnet, sulfonamides, calcineurin inhibitors
(cyclosporin A and tacrolimus), NSAIDs, gadolinium­based and some other contrast agents, herbal preparations
Noncompliance with Diabetes often follows transplantation; marked exacerbations in hypertension are frequently
Medications associated with graft failure.
Management of risk factors such as diabetes and hypertension
Chronic allograft nephropathy Common cause of graft dysfunction
LIVER TRANSPLANTATION

The most common reasons for ED visits are fever and abdominal pain. Hepatosplenomegaly, ascites, and malaise may also occur, specifically with
 rejection. Complications include bleeding, rejection, and infection, as well as biliary, vascular, and wound complications. Bacterial infection may
 accompany acute rejection. Specific complications of liver transplantation are listed in Table 297­12. Obtain a CBC with platelet count and differential; serum chemistries, including electrolytes, BUN, creatinine, basic coagulation studies, liver function tests, amylase, and lipase levels; and cultures of blood, urine, bile, and ascites. Radiographic testing as indicated may include chest radiograph and abdominal US with Doppler flow studies. US with Doppler can identify fluid collections, thrombosis of the hepatic artery or portal vein, and dilatation of the biliary tree (although the
69­73 absence of biliary dilatation does not exclude obstruction or other posttransplantation pathology). With partial obstruction, the intrahepatic ductal system often does not appear to be dilated appreciably by US. With complete obstruction, duct dilation is usually seen. CT with contrast may be
,69,70 required for diagnosis of vascular complication or biliary stricture. Patients often require cholangiography for complete evaluation. Patients with choledochocholedochostomy may be best evaluated by endoscopic retrograde cholangiopancreatography because it permits both a radiographic diagnosis and the potential for nonoperative intervention. Patients with a Roux­en­Y hepaticojejunostomy or those who cannot have endoscopic
72­75 retrograde cholangiopancreatography must undergo percutaneous cholangiography. Early, broad­spectrum prophylactic antibiotics should be administered before any biliary tract manipulation. Discuss treatment and disposition with the transplant team.
TABLE 297­12
Complications of Liver Transplantation
Complication Comments
Bleeding GI bleeding should be managed in the usual fashion but may signal graft dysfunction.
complications
Biliary Bile leaks present early, and biliary strictures present late (>2 mo from transplant). In both cases, cholestatic liver enzymes are complications elevated, typically with right upper quadrant pain (more pronounced with bile leak). Jaundice and fever may also be present. US with
Bile leak Doppler of hepatic vessels displays sensitivity of 38%–66%. If US is negative, cholangiogram may be needed, with patients often
Biliary stricture requiring endoscopic retrograde cholangiography (ERC). Strictures come in two forms, with anastomotic strictures occurring within
(anastomotic and the first year after surgery. Imaging includes CT, US, and MRI, with treatment including ERC and stent placement. Bile leaks occur in up nonanastomotic) to 25% of patients, with ERC needed for diagnosis and treatment (stent). Bilomas can be diagnosed with US and managed with
Biloma drainage and antibiotics.
Hepatic artery Vascular complications affect the hepatic artery or portal vein most commonly. CT with contrast (if renal function adequate) or US is complications helpful in the evaluation of these conditions. CT with IV contrast has greater sensitivity for arterial stenosis, but US displays a
Hepatic artery sensitivity up to 90% for venous thrombosis. Mortality reaches 80% for portal vein thrombosis if not diagnosed. For thrombosis, thrombosis thrombolysis may be required. Pseudoaneurysms are typically treated with transcatheter embolization.
Hepatic vein thrombosis
Portal vein complications
Pseudoaneurysm
Rejection Early alkaline phosphatase and bilirubin levels rise, followed by a rise in aspartate aminotransferase and alanine aminotransferase.
US may reveal focal lesion or vascular abnormality. Biopsy is needed during admission.
Neurologic Causes include hemorrhage, cerebrovascular infarct, cerebral abscess, hypertensive encephalopathy, osmotic demyelination complications syndrome, and sinus thrombosis. MRI is best for evaluation.
Malignancy Increased risk for squamous cell carcinoma, lymphomas, and posttransplant lymphoproliferative disorder.
LUNG TRANSPLANTATION
Lung transplantation involves three anastomoses: airway (the most vulnerable to complication, 2% to 33%), pulmonary arterial, and pulmonary vein to
,6,76­78 the left atrium. Fever, cough, and increasing dyspnea are common reasons for ED visits in lung transplant patients. Important clinical features to note are the respiratory rate, pulse oximetry measurement, and physical findings of cyanosis, diaphoresis, use of accessory muscles, signs of congestive heart failure, and adequacy of peripheral perfusion. Obtain a chest radiograph and arterial blood gas analysis when adequacy of ventilation is in question. Give β ­agonists and anticholinergics as indicated. Signs of infection often overlap with the signs and symptoms of rejection, and the
 management of infection is quite different from that of rejection. A drop in the forced expiratory volume in  second of >10% warrants clinical investigation, but pulmonary function testing cannot distinguish between acute rejection, infection, and nonimmunologic causes of respiratory
 dysfunction such as airway stenosis. Therefore, bronchoscopy is required for specific diagnosis. Lung transplant patients can deteriorate very quickly in the absence of the proper therapy. Thus, it is common practice to cover both infection and rejection until additional histopathologic and
 culture results are obtained.
COMPLICATIONS OF LUNG TRANSPLANTATION
Complications occur most frequently in the first year, but can occur at any time starting from the first few weeks after transplant and can continue
,81 throughout the lifetime of the patient (Table 297­13). Airway complications often occur with dyspnea, wheezing, or stridor or postobstructive pneumonia. A variety of mechanisms of airway obstruction may occur, such as bronchial stenosis, tracheobronchomalacia, hyperplastic granulation
76­78,82­84 tissue, and bronchial necrosis. Diagnosis typically includes chest CT and bronchoscopy. Vascular complications (stenosis, kinking, and
85­87 thrombus formation) are not as frequent but have poor outcomes and can present with hypoxemia, dyspnea, hypotension, and edema. US may reveal right­sided cardiac dysfunction with vascular complications, although definitive diagnosis includes CT angiography. Phrenic nerve dysfunction
88­91 is more common in heart­lung transplant (40% of cases) as compared to lung­only transplant (3% to 9%). Indications for hospital admission are listed in Table 297­14. TABLE 297­13
Time Course of Lung Transplant Complications
Days After
Complications Most Commonly Seen in Each Time Period
Transplant
0–3 d Hemorrhage from technical/mechanical problems
Reperfusion injury
Dysrhythmia
 d–1 mo Infection: bacterial, Mycoplasma, community respiratory viruses
Rejection
Anastomotic failure
Pulmonary embolism
Muscle weakness
Dysrhythmia
Starting at  Rejection mo Obliterative bronchiolitis
Infection
Bacterial, fungal, community respiratory viral (can occur at any later time)
Mycoplasma 0–4 mo
Mycobacteria after  mo
Other Cytomegalovirus infection and Pneumocystis jiroveci pneumonia may occur any time, but are more common when prophylaxis is not being given, especially when such treatment has been recently discontinued.
TABLE 297­14
Indications for Hospital Admission for Lung Transplant Patients
Pretransplant patients
Respiratory failure
Infiltrate
Systemic infection
Decompensated congestive heart failure or pulmonary edema
Pneumothorax
Posttransplant patients
Respiratory failure
Acute rejection
Rapidly progressive airflow limitation (forced expiratory volume in  second decreases >10% over  h)
Infiltrate
Systemic infection
Febrile neutropenia
Pneumothorax
Acute rejection is common and may occur three to six times in the first postoperative year. After the first year, the frequency of acute rejection decreases, but it can occur for several years after transplant. Signs of rejection include cough, chest tightness, increase or decrease in temperature from baseline of >0.28°C (0.5°F), hypoxemia, decline in forced expiratory volume in  second (10% or more), and infiltrates on the chest radiograph, although the chest radiograph may be normal. Lung auscultation is often variable, with examination revealing clear lung fields, crackles, or decreased
92­95 breath sounds. Patients may present in respiratory distress or failure. Eosinophilia may be present with rejection. Radiographic abnormalities are less common >6 weeks after transplant, and an acute rejection episode actually may be “radiographically silent” after this. Discuss treatment with the transplant team. If the maintenance immunosuppressant regimen has been tapered, it can be very helpful to return to pretaper dosages. In addition, high­dose corticosteroids are often used to treat acute rejection. The usual dosing regimen is  milligrams/kg of IV methylprednisolone each day for  consecutive days. After the corticosteroid bolus, if the maintenance prednisone had been tapered, increasing the prednisone to  milligram/kg/d and
,95,96 tapering over the next  days may be helpful. Clinical response to treatment is gauged by improvements in oxygenation, spirometry, and radiographic appearance and typically occurs within  to  hours after treatment is initiated. Failure to improve should suggest infection as an alternative diagnosis. After clinical improvement, the maintenance dose of prednisone is increased, with a slow taper back to baseline.
,98
Pulmonary infections from bacteria, fungi, or viruses are the most common causes of morbidity and mortality in lung transplant patients
(Tables 297­5 and 297­13). Lung transplant patients are at risk for pneumonia because of colonization of the recipient’s airway in the setting of
 transplantation for bronchiectasis and cystic fibrosis and at risk of aspiration in the presence of gastroesophageal reflux disease. Antibiotic selection is best left to the lung transplant specialist.
CARDIAC TRANSPLANTATION
Cardiac transplantation has been applied successfully to patients of all ages, from newborns through persons in their late 60s. Heart transplantation is indicated for patients with end­stage heart failure not remediable by standard medical or surgical therapy. Many in the latter group will have undergone previous coronary artery bypass or valve surgery or been bridged on mechanical assist devices. The leading causes of death in those age 
 to  years are graft failure and infection.
The success of a heart transplantation operation depends on the ability of the denervated heart to support the normal circulation. The lack of sympathetic and parasympathetic innervation does, however, induce an altered physiologic state. The denervated heart has a normal sinus rhythm with a heart rate between  and 100 beats/min. Denervation results in the absence of the initial centrally mediated tachycardia in response to stress or exercise, but the heart remains responsive to circulating catecholamines. Thus, the cardiac response to stress or exertion is blunted. With proper
100­103 conditioning, patients are able to resume normal activity levels, including vigorous exercise, following transplantation.
The donor heart is implanted with its own sinus node intact to preserve normal atrioventricular conduction. The technique of cardiac transplantation also results in preservation of the recipient’s sinus node at the superior cavoatrial junction, and the two sinus nodes remain electrically isolated from each other. Thus, ECGs frequently will have two distinct P waves (Figure 297­2). The sinus node of the donor heart is easily identified by its constant
1:1 relationship to the QRS complex, whereas the native P wave marches through the donor heart rhythm independently. The presence of the two separate P waves may lead to confusion about the patient’s rhythm, mistakenly interpreting sinus rhythm as second­degree heart block. The ECGs may also be interpreted erroneously as showing atrial fibrillation, atrial flutter, or frequent premature atrial complexes. Some patients may have evidence of “cardiomegaly” related to the transplantation of a heart from a donor who was larger than the recipient (Figure 297­3). Clinical evaluation is based on the reason for the ED visit. Patients may present with a variety of symptoms in the setting of rejection including dyspnea, orthopnea, syncope, and
 edema, but chest pain is typically absent due to denervation during surgery. Chest radiograph, ECG, and further evaluation are based on complications of cardiac transplantation (Table 297­15) and underlying patient comorbidities, especially in elderly transplant recipients. Cardiac
 biomarkers are typically elevated in rejection, with findings consistent with heart failure on echocardiogram and chest radiograph.
FIGURE 297­2. ECG in a heart transplant patient. ECG demonstrates donor and recipient P waves (arrowhead = donor P wave; arrow = recipient P wave).
FIGURE 297­3. Chest radiograph of healthy post–heart transplant patient with typical postoperative changes, including “cardiomegaly” due to transplantation of a heart from a donor who was larger than the recipient.
TABLE 297­15
Complications After Cardiac Transplant
Complication Comments
Altered See text in “Cardiac Transplantation” section.
physiology
Dysrhythmias Dysrhythmias after transplantation are frequently due to rejection. Treat the unstable patient presenting in extremis with  gram of methylprednisolone IV; delay rejection therapy in the stable patient for consult with the transplant team and biopsy. Atropine and vagal maneuvers have no effect due to denervation. Adenosine should be provided at half the normal dose in supraventricular tachycardia.
Sinus node Pacemaker usually required.
dysfunction
Pulmonary Diagnosis may require CT or more invasive diagnostic procedures.
complications
Pneumonia
Thromboembolic disease
Exerciseinduced hypoxemia
Pneumothorax
Interstitial fibrosis
Cardiac ischemia Patients do not experience pain due to denervation; symptoms typically occur with complications such as congestive heart failure.
Rejection Presents a variety of ways: dyspnea, syncope, orthopnea, palpitations, edema. Cardiac biomarkers typically elevated. Often presents with dysrhythmias and findings of heart failure. Treat the patient presenting in extremis; withhold treatment for biopsy if possible.
Infection See section “Posttransplant Infections.”
Congestive heart Echocardiography can help to determine etiology and therefore ideal treatment.
failure
Ischemic stroke Increased risk after heart transplant.
and intracranial hemorrhage
Complications Increased risk of infection and thromboembolism.
specific to ventricular assist devices
Cardiac Beyond  y after transplant, one of the major causes of graft failure due to rapid atherosclerosis. Pediatric heart transplant recipients allographic are at risk for graft coronary artery disease and ischemia. May occur with no symptoms or fulminant heart failure. Diagnosis includes vasculopathy angiography. May require retransplantation.
CORNEAL TRANSPLANTATION
Corneal transplantation (penetrating keratoplasty) is the most common form of human solid­tissue transplantation and is a key element in vision restoration. Unlike other tissue and organ transplants, corneal allotransplantation usually does not require systemic or permanent immunosuppression. Reasons for graft failure include corneal graft rejection (30.9%), corneal endothelial cell failure (21.0%), glaucoma (8.5%), and
104,105 other causes (26.2%). Ophthalmology consultation is required for any change in visual acuity or other ocular signs or symptoms in a patient with a corneal transplant.
Corneal graft rejection is a specific process in which a graft that has been clear suddenly develops graft edema with anterior segment inflammatory signs. Rejection can occur at any time starting at  days after transplant. The inflammatory process starts at the graft margin nearest to the most
104 proximal blood vessels and then moves toward the center to involve the entire graft. Signs and symptoms include eye pain, photophobia, corneal or scleral injection, and decreased visual acuity. Examination may reveal unilateral anterior chamber reaction with keratic precipitate or corneal edema in a previously clear graft. Late graft failure can present with gradual onset of graft edema with no associated inflammation or keratic precipitates.
Treatment includes topical or systemic steroids, cycloplegics, and immunosuppressive drugs such as local and systemic cyclosporine A and tacrolimus.
Wound dehiscence can occur early or late after corneal transplantation as a result of infection or after eye trauma. Trauma may be unrecognized or be a result of events such as motor vehicle airbag deployment or a fall with the patient’s glasses impacting the eye. There may be globe rupture, slight separation of part of the suture line, or just broken sutures.

Viral, bacterial, or fungal infection can threaten the transplanted cornea. In patients with a history of herpetic keratitis, consider
104 recurrence and examine with fluorescein for characteristic corneal staining and signs of anterior chamber inflammation. Ophthalmology consultation is needed for diagnosis and treatment.
Acknowledgment
The authors thank J. Hayes Calvert for his work on the previous edition of this chapter.


