## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 266: Trauma to the Extremities
James Heilman
INTRODUCTION AND EPIDEMIOLOGY
Trauma to an extremity with associated vascular injury has a 5% rate of mortality, 5% rate of primary limb amputation, and 17% rate of delayed limb amputation.1 Penetrating trauma with early shock from proximal arterial hemorrhage is more likely to lead to mortality. Blunt distal extremity trauma with associated distal vascular injury is more commonly involved in early limb loss and amputations. Risk factors for delayed amputation include major soft tissue injury, compartment syndrome, ischemia of more than  hours, and associated fracture.2 Injuries involving the lower extremities are more common than injuries involving the upper extremities. The two most commonly injured blood vessels are the femoral and popliteal vessels.3
Advances in diagnostic imaging4 and surgical management have dramatically reduced the rate of limb loss and disability due to limb ischemia.5 The extent of injury to extremity nerves, bones, and soft tissues now determines if the limb can be surgically salvaged. Identifying and detecting which injuries require surgical evaluation and/or imaging are essential skills for emergency physicians.
PATHOPHYSIOLOGY
Gunshot and knife wounds are the two most common causes of penetrating trauma. Stab wounds have a more predictable pattern of injury, making them more straightforward to manage.
Gunshot injuries are more difficult to evaluate due to the extent of tissue damage and wider range of patterns of injury. More sophisticated vascular surgical repair techniques of arterial injuries,6 advances made during military conflicts, improved imaging, and other factors have led to a decreased rate of limb amputations and limb disability associated with penetrating trauma.7
CLINICAL FEATURES
Perform the primary trauma survey, immediate resuscitation, and secondary survey before focusing on injuries to the extremities. Apply direct pressure, pressure dressings, or a tourniquet to any actively bleeding extremity (see Chapter 254, “Trauma in Adults”). Do not get distracted or deviate from the initial trauma management because associated injuries to other areas of the body are common with penetrating injuries. After identifying an injury during the secondary survey, thoroughly evaluate the affected extremity for vascular integrity, nerve function, skeletal injury, and soft tissue injury. The rapid evaluation of extremities for associated arterial injury is critically important for the management of these injuries. Note any hard or soft signs of vascular injury (Table 266­1). Use a Doppler flow device to detect a pulse if distal pulses cannot be palpated.
TABLE 266­1
Clinical Manifestations of Extremity Vascular Trauma
Hard signs
Absent or diminished distal pulses
Obvious arterial bleeding
Large expanding or pulsatile hematoma
Audible bruit
Palpable thrill
Distal ischemia (pain, pallor, paralysis, paresthesias, coolness)
Soft signs
Small, stable hematoma
Injury to anatomically related nerve
Unexplained hypotension
History of hemorrhage
Proximity of injury to major vascular structures
Complex fracture
Thoroughly evaluate nerve, tendon, and muscle function during the physical exam (Table 266­2). Pain on palpation or movement of bony structures or obvious deformities suggests an underlying fracture. Note any intra­articular hematomas or other signs of joint injury. Measure soft tissue lacerations and other associated injuries with a tape measure. Accurately describe injuries to consultants because measurement of the injury may change management in some situations.8
TABLE 266­2
Clinical Examination of the Nerves of the Extremities

Chapter 266: Trauma to the Extremities, James Heilman 
Nerve Test of Motor Function Test for Sensation
. Terms of Use * Privacy Policy * Notice * Accessibility
Axillary (C5­C6) Arm abduction Lateral aspect of shoulder
Arm internal, external rotation
Musculocutaneous (C5­C6) Forearm flexion Lateral forearm
Radial (C5­C8) Forearm, wrist, and finger extension Dorsoradial hand, thumb
Median (C6­T1) Wrist flexion, finger adduction Volar aspect of thumb and index finger
Ulnar (C7­T1) Finger abduction Volar aspect of little finger
Femoral (L1­L4) Knee extension
Obturator (L2­L4) Hip adduction
Superior gluteal (L4­S1) Hip abduction
Sciatic (L4­S3) Knee flexion
Deep peroneal (L4­S1) Ankle and great toe dorsiflexion
Superficial peroneal (L5­S1) Foot eversion
Tibial (L5­S2) Ankle plantar flexion
Posterior tibial (L5­S2) Great toe plantar flexion
Spinal L4 Medial calf
Spinal L5 Dorsal foot
Spinal S1 Lateral plantar foot
ANKLE­BRACHIAL INDEX
In the absence of hard signs, determine the ankle­brachial index for any injured extremity along with the nonaffected extremity for comparison (See Video: Ankle­Brachial Index). An anklebrachial index reading of <0.9 is considered abnormal and is concerning for associated arterial injury. The ankle­brachial index reliably detects occlusive arterial injury with accuracy as high as 95%, but the true sensitivity and specificity have varied in clinical studies.9,10 Use caution in relying on a normal ankle­brachial index to rule out arterial injury. It does not detect nonocclusive arterial injuries such as intimal flaps, focal narrowings, small pseudoaneurysms, and arteriovenous fistulas in up to 10% of cases.11
Video 266­1: Ankle Brachial Index
Used with permission from Henderson McGinnis
Play Video
DIAGNOSIS
Diagnosis of associated injuries depends on a complete history and physical exam of the involved extremity. If any hard signs of vascular injury are present, then consult vascular surgery immediately. If there are any soft signs of vascular injury and/or if the ankle­brachial index is <0.9, then order imaging tests to evaluate for associated vascular injuries, or transfer to an institution with vascular care capability (Figure 266­1).
FIGURE 266­1. Algorithm for penetrating extremity trauma. ABI = ankle­brachial index.
The differential diagnosis for injuries associated with penetrating trauma to the extremities includes arterial or venous injury, nerve damage, tendon lacerations, fractures, soft tissue injury, degloving injuries, damage to joint capsule, bullet embolization of artery, or vein and compartment syndrome.12
LABORATORY TESTING
No specific laboratory testing is indicated for isolated penetrating extremity injuries; in certain cases, type and screening, baseline renal function, and a CBC may be indicated. If the patient has soft signs of vascular injury or an ankle­brachial index <0.9, then obtain a creatinine to determine renal function in patients with risk for preexisting renal disease. Underlying renal insufficiency creates potential for contrast­induced nephropathy when performing CT angiography. See Chapter , “Acute Kidney Injury,” for discussion of radiocontrast­induced nephropathy.
IMAGING
Plain Radiographs
Obtain anteroposterior and lateral radiographs of extremities with suspected fracture, joint injury, or retained bullet or other foreign body fragments. Oblique views may add value if there is clinical suspicion of retained foreign body. Obtain radiographs of the joint above and below the site of injury. Evidence of air in the joint or an intra­articular fracture on the radiograph demonstrates that joint involvement has occurred.
There are four types of fracture patterns associated with low­energy gunshots13 (Figure 266­2). The drill­hole wound track pattern appears in lower­density cancellous bone and is most common in the distal femur, pelvis, and proximal humerus. Unicortical fractures appear in the metaphyses of long bones. Comminuted fractures occur most frequently in diaphyseal bone; multiple bone fragments are common. The fourth type of fracture is the distal spiral fracture, and this occurs most commonly in the femur.
FIGURE 266­2. Fracture patterns created by bullets: drill­hole (A), unicortical (B), distant spiral (C), comminuted (D).
For shotgun or blast injuries, obtain radiographs of the extremity and joint distal to the injury in order to detect any pellets that have embedded into the bone or soft tissues or entered into a joint capsule (Figure 266­3).
FIGURE 266­3. A. Gunshot wound to the shoulder and axilla. B. Embedded pellet of shotgun in the distal ulna, illustrating the importance of obtaining images of the extremity distal to such injuries.
CT Angiography
CT angiography is the primary diagnostic study for the evaluation of vascular injuries to the extremities.2 CT angiography is noninvasive, provides higher resolution images, and is less expensive when compared to catheter angiography. It provides three­dimensional reconstruction with minimal artifact. CT angiography also assists in the evaluation of extravascular injuries such as fractures, foreign objects, or joint involvement.14 Studies comparing CT angiography to catheter angiography have demonstrated that the CT angiography sensitivity and specificity rates for identifying clinically significant arterial injuries are equivalent to those with conventional catheter angiography.15­18 Limitations of CT angiography include scatter artifact interference caused by bullets, poor visualization of tibial vessels, and the inability to perform any therapeutic interventions during the study.
Ultrasonography
Historically, the sensitivity of color flow duplex ultrasonography has ranged from 50% to 100% for evaluating vascular injuries.19 However, the 2­Point Fast Doppler (2PFD) protocol appears promising to identify vascular injury.20 The presence of normal triphasic arterial flow in both the dorsalis pedis artery and posterior tibial artery had a sensitivity and specificity of 100% in ruling out arterial lesions in lower­limb penetrating trauma. Further studies are needed to determine generalizability of these results.10
TREATMENT
CONTROL OF BLEEDING
Patients with venous trauma can bleed profusely. Control bleeding with direct pressure, pressure dressing, or a tourniquet.21 Avoid clamping vessels in an attempt to control bleeding, as this risks nerve damage. Nerves are bundled with vascular structures and can be easily damaged by blind clamping or ligation during the initial trauma resuscitation.
ARTERIAL INJURY
Penetrating injuries to the extremities that involve any associated arterial injury are critically important to recognize early. Figure 266­1 outlines the approach to these injuries.
FRACTURES AND JOINT INJURIES
Penetrating trauma can cause joint sepsis and destruction, rapid chondrolysis, and loss of anatomic contours. These can lead to serious long­term consequences, including posttraumatic degenerative arthritis and partial or total loss of flexibility. Treat bone fractures from penetrating trauma as open fractures. Surgically debride the injury and admit the patient for IV antibiotics. Synovial joint fluid is an organic acid that causes lead bullets to become soluble in the joint, which can lead to systemic lead toxicity.22 If a patient has an obvious bony or joint capsule injury, obtain consultation to evaluate the injury.
WOUND MANAGEMENT
Careful wound management is critical to prevent infection after penetrating injuries. The most important component of wound management is irrigation. Copiously irrigate with saline or tap water (500 to 1000 mL) at high pressures (15 to  pounds per square inch). Antiseptic solution does not decrease infection rate and may actually be harmful.23
Heavily contaminated wounds may require more fluid and/or more pressure. If the wound is older than  to  hours, gently scrub the wound. Despite the importance of irrigation and wound management, there are many other factors that play a role in infection risk and proper healing, including bacterial inoculum, tissue devitalization, blood supply, time to presentation and treatment, presence of foreign bodies, and host immune status.
WOUND CLOSURE
The decision to close associated open wounds depends on the time that has elapsed since the injury and the degree of contamination. If there is minimal contamination and the wound is well irrigated, it can be closed. It is important to arrange close follow­up in  to  hours in order to check for developing wound infection. Extremity wounds with retained foreign bodies, major tissue destruction, or contamination should be closed after a delay of  to  hours. Do not routinely administer antibiotics for uncomplicated extremity gunshot and knife wounds because there is an approximately 2% rate of infection in these injuries.24 However, antibiotics may be beneficial for treating hand injuries, joint or bony involvement, immunocompromised patients, and wounds with significant contamination.25
SOFT TISSUE FOREIGN BODIES
Plain radiographs will detect glass, metal, bone, or gravel. Wood and other organic material may be missed on plain films, and US is better at identifying these objects. CT scanning is the best modality for identifying both radiolucent and opaque foreign bodies. Several factors impact whether the foreign body should be removed. The benefit of exploring the wound and removing the substance must be weighed against the associated damage to surrounding tissues and the increased risk of infection. Organic material is more reactive and has a higher rate of infection than metal or glass. A bullet generally should not be removed unless the bullet has potential to migrate into surrounding vital structures or if it is in the joint capsule.
DISPOSITION, FOLLOW­UP, AND DISEASE COMPLICATIONS
Hard signs of arterial injury require immediate surgical consultation, and such patients will need further imaging, surgery, and hospital admission. All other patients with penetrating extremity trauma should undergo a period of observation with associated serial examinations to detect any delayed or missed injuries. There is no consensus on the required observation time required, but a minimum of  hours is reasonable.17
Wound healing may be complicated by infections, missed nerve injuries, tendon or joint injuries, delayed vascular injury, and compartment syndrome. Discuss return precautions with patients before discharge. State these precautions as clearly as possible. Recommend that patients return to the ED for increasing pain, numbness, weakness, redness, or pus drainage from the wound site. Ensuring follow­up with the appropriate surgical service, a primary care provider, or the ED is essential, especially in uninsured patients or patients transported long distances from home, as well as for other high­risk populations.


