University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 30: Surgical Airways
Keith Murray; Alanna C. Peterson; Donald M. Yealy
INTRODUCTION
Establishing a surgical airway by front­of­neck access is an indicated intervention in patients who cannot be intubated via the oral or nasal routes and also when faced with a cannot intubate–cannot oxygenate scenario. With the many devices available to improve laryngoscopy, offer oxygenation, or allow a supraglottic path for respiration, emergent surgical airways are rarely performed. When needed, absence of knowledge or preparation can
,2 lead to delays in performing this lifesaving procedure. The key is preparation and repetition through use or training in a laboratory setting.
Surgical cricothyrotomy uses the cricothyroid membrane (CTM) as an insertion route, inserting a tracheal tube either directly through an incision or by using the Seldinger technique after puncture. Percutaneous transtracheal jet ventilation/oxygenation is an alternative to surgical airway establishment whereby a 12­ to 16­gauge catheter is inserted into the trachea through the CTM and connected to a high­pressure (35 to  psi) oxygen source for both oxygenation and ventilation.
PATIENT SELECTION
The primary indication for surgical airway placement is a cannot intubate–cannot oxygenate scenario, often following failed attempts to establish an oral/nasal endotracheal airway. Cricothyrotomy and jet ventilation can be used before laryngoscopy and direct glottic intubation if the latter is likely to fail because of anatomic distortion or any other cause that impedes visualization, notably blood, secretions, vomitus, swelling, or foreign matter.
Attempting tracheal intubation prior to cricothyrotomy may increase the risk of harm to the patient by delaying oxygenation or increasing the risk of failure of a surgical airway. If standard intubation seems unlikely to succeed, it is not always necessary to attempt it prior to establishing a surgical airway.
Many things, often combined, add to difficulty of establishing a traditional endotracheal airway; the LEMON acronym helps organize those factors
(Table 30­1). In addition, trauma can distort the neck anatomy by hematoma (e.g., cervical fracture, major vessel injury), create aspiration of blood or active oropharyngeal bleeding (facial trauma), or lessen the integrity of supporting structures (e.g., mandible fracture, LeForte fractures). Look for these features and have a preplanned difficult airway algorithm to include surgical airway to mitigate impending or actual respiratory failure. Often,
,4 predicting difficult laryngoscopy in the emergency setting is unreliable. Clinical signs and symptoms of airway obstruction—one common reason to perform a surgical airway—are listed in Table 30­2. TABLE 30­1
LEMON Airway Assessment Method
L Look externally (facial trauma, large incisors, beard, large tongue)
E Evaluate the 3­3­2 rule
Incisor opening distance:  fingerbreadths
Hyoid­mental distance:  fingerbreadths
Thyroid­to­mouth distance:  fingerbreadths
M Mallampati score ≥3
O Obstruction: Presence of condition such as epiglottitis, peritonsillar abscess, or trauma

Chapter 30: Surgical Airways, Keith Murray; Alanna C. Peterson; Donald M. Yealy 
N Neck mobility (limited neck mobility)
. Terms of Use * Privacy Policy * Notice * Accessibility
TABLE 30­2
Clinical Manifestations Associated With Acute Airway Obstruction
Etiology Manifestation
Vascular Hematoma
External hemorrhage
Hypotension
Hemoptysis
Laryngotracheal Stridor
Subcutaneous air (massive)
Hoarseness
Dysphonia
Hemoptysis
Pharyngeal and/or hypopharyngeal Subcutaneous air
Hematemesis
Dysphagia
Sucking wound
Pregnant patients, specifically at or near term, are at increased risk of regurgitating gastric contents secondary to reduced lower esophageal sphincter tone, will desaturate faster by virtue of having a decreased functional reserve capacity (reduced by 20% near term), will have edematous tissues
 secondary to increased total body water and decreased oncotic pressure, and may be malpositioned for ideal intubation if lying in a lateral tilt.
Children are another special population with limited surgical options, especially when younger than  years old.
PATIENT AGE
Inserting any airway into the trachea in children under age  years has specific challenges, including a shorter neck, more relative soft tissue, more compressible proximal airway structures, and less distinctive thyroid and cricoid cartilages. Hyperextension of the neck to increase the sagittal length of the CTM may mitigate some of these factors. Cricothyrotomy is more challenging in children, leading to increased risk of laryngeal and tracheal
6­8 injuries. Due to these complications, tracheotomy is preferred in children under  years old, particularly those under age . Because few emergency physicians are skilled in this technique due to the uncommon need for an emergency physician to perform the procedure in a pediatric patient, we will discuss alternatives for when an experienced pediatric airway surgeon is not available to assist.
The American Heart Association and others recommend attempting percutaneous transtracheal jet ventilation first, with surgical cricothyrotomy as a
6­9 7­10 second­line option. Despite this recommendation, data supporting any one approach in children over another are limited and conflicting. We believe the key to successful rescue airway placement in children is advance planning and training for this specific scenario.
INJURIES REQUIRING CRICOTHYROTOMY
Trauma is a common reason to consider a surgical airway. Penetrating trauma to the neck affecting a major artery (carotid, vertebral, or thyroid) may create an expanding hematoma and obstruct the airway. If free blood spills into the oro­ or hypopharynx, direct visualization for intubation is often not possible. Placing a cuffed tracheostomy tube after cricothyrotomy is the best option to restore gas exchange and limit aspiration. Difficulty in
 establishing an airway occurs in approximately 10% of patients with penetrating cervical trauma.
Blunt trauma to the neck or face may cause hemorrhage of the soft tissues or injury to the trachea/larynx, including rupture. If the trachea or larynx is disrupted, do not attempt cricothyrotomy; in this rare setting, an emergency tracheostomy is needed. In blunt facial trauma, the principal cause of death is airway obstruction from bleeding (often from fractures) or soft tissue swelling; a surgical airway can prevent death and harm if deployed quickly and with skill.
TYPE OF EMERGENCY AIRWAY AND TUBE SELECTION
Cricothyrotomy is preferred over percutaneous approaches (except for children <12 years old). The most skilled provider should perform this procedure to optimize success and limit harm.
Although any large­bore tube is adequate, we suggest using a tracheostomy tube because it has an obturator to ease insertion, is shorter and easier to suction, and is easier to secure (Figure 30­1). Endotracheal tubes placed during cricothyrotomy may be inadvertently directed cephalad or advanced too deeply and are more difficult to secure. To avoid endotracheal tube malposition, many use a gum elastic bougie to ensure tracheal
 placement and the correct tube direction. If a standard endotracheal tube is used, many prefer to change later to a tracheostomy tube. Use a gum bougie or endotracheal tube stylet as an obturator for endotracheal tube removal and tracheostomy tube insertion.
FIGURE 30­1. Tracheostomy tube with obturator. [Photo used with permission of David Effron, MD.]
The diameter of the tube inserted is crucial. A common choice for an adult is a 6­mm tracheostomy or 5­ to 6­mm endotracheal tube. Do not choose a larger (≥7 mm) tube or one smaller than  mm, the latter excepted in pediatric patients. Larger tubes are difficult to insert in the narrow space between the cricoid and thyroid cartilages. If airway pressures are high with the small­diameter tube or if ventilation is inadequate, consider changing to a larger diameter tube using a tube exchange device or bougie. Ventilation problems in adults may occur when a smaller tube is used (3­mm internal diameter or less). Any tube with a 4­ or 5­mm or larger internal diameter will allow adequate volume ventilation in most patients, although at  mm, there is limited area for suctioning and aggressive minute ventilation. For these reasons, select a 4­ to 5­mm size only if a 6­mm tube is unavailable or cannot be placed.
SURGICAL (OPEN) CRICOTHYROTOMY
ANATOMY
The CTM is located between the thyroid and cricoid cartilages (Figure 30­2A). Both structures are easily palpated but are not directly seen because they are covered with the pretracheal fascia. In men, the thyroid cartilage is prominent and creates the “Adam’s apple”; in women and children, the thyroid and cricoid cartilages can be hard to distinguish from each other.
FIGURE 30­2. A. Neck anatomy. B. Location of the cricothyroid membrane.
The CTM is found approximately one third of the distance from the manubrium to the chin in the midline in patients with normal habitus (Figure 30­
2B). In a patient with a short, obese neck, the membrane may be hidden at the level of the manubrium. In a patient with a thin, long neck, it may be midway between the chin and the manubrium. The thyroid gland overlies the trachea; both structures are difficult to palpate. One easy way to find the cricoid membrane is to slowly palpate the trachea as you move up toward the head from the sternal notch; when your fingers “fall off” after a firm structure, you have palpated the thyroid cartilage. Next, slowly palpate back toward the feet, and the first “soft spot” after that thyroid cartilage is the cricoid membrane. Additionally, a very rough approximation of where to find the CTM should landmarks be skewed is to take your outstretched four fingers held together and place your fifth finger on the superior aspect of the manubrium. With the rest of your fingers directed cephalad, the most superior aspect of the index finger is roughly juxtaposed to the CTM.
The vascular structure often injured during cricothyrotomy is the thyroidea ima artery, a branch of the aorta running up to the thyroid gland in the midline. This vessel infrequently reaches the level of the CTM. A carotid injury usually results from attempts using poor landmarks (either indistinct or not carefully sought) or when technique is poor. The first step after recognizing any vascular injury during cricothyrotomy is immediate direct pressure to stop the bleeding and avoid catastrophe.
EQUIPMENT
The equipment needed to perform a surgical cricothyrotomy is listed in Table 30­3. TABLE 30­3
Equipment Needed to Perform a Surgical Cricothyrotomy
Personal protective equipment
Scalpel with a #10 (preferable because of its greater width) or #11 blade
A 6­mm endotracheal tube or tracheostomy tube (latter preferred), plus a smaller one available
Tape to secure the tube in place
Cloth ribbon and sutures to secure tracheostomy tube in place
Bag­valve­mask device and oxygen source
Gum elastic bougie for guiding tube
Suction devices
PATIENT PREPARATION AND POSITIONING
Place the patient supine, with the neck slightly hyperextended if no cervical trauma is present (neutral if there is suspected trauma); this optimizes neck structure palpation and recognition. If time permits, apply antiseptic solution to the skin. Ventilate with a bag­valve mask connected to 100% oxygen while preparing. For the patient in extremis, do not delay initiating the procedure to achieve any of these preparations.
PROCEDURE
The procedure summary for performing a surgical cricothyrotomy is provided in Table 30­4. (See Video: Cricothyrotomy.)
Video 30­1: Cricothyrotomy
Use with permission from David Cline and Henderson McGinnis, Department of Emergency Medicine, Wake Forest University Baptist Medical Center.
Play Video
TABLE 30­4
Performing a Surgical Cricothyrotomy
Step Comment
. Stand to one side of the patient at Right­handed practitioner—stand on the patient’s right side.
the level of the neck. Left­handed practitioner—stand on the patient’s left side.
. Locate the cricothyroid membrane. Locate the cricoid ring.
Place the index finger at the sternal notch and palpate cephalad until the first rigid structure is felt (cricoid ring).
Roll the index finger one fingerbreadth above to locate the membrane between the cricoid and thyroid cartilages (Figure 30­3).
. Using the thumb and middle finger Once the two cartilages are secured in between the thumb and middle finger, this hand should not move until of the nondominant hand, stabilize the the entire procedure is finished.
two cartilages.
. Use the scalpel to make a vertical Incise through the skin and subcutaneous tissues.
incision in the midline between the two The structures are superficial, so do not incise deep to avoid damage to the cricoid or thyroid cartilage or cartilages, extending if needed. vascular structures (Figure 30­4). The membrane is felt, not directly seen, after incision.
. With the scalpel blade positioned The horizontal orientation is in anatomic alignment with the membranes to avoid vascular injury (Figure 30­ horizontally, perforate the cricothyroid 5). Once the membrane is perforated, do not leave it empty; slide forceps, dilator, or tracheal hook membrane so that the blade goes in around the blade or place a bougie before removing the scalpel. In addition, the index finger of the securing approximately half its length. hand can be inserted into the space to mark position.
. Widen the incision opening. A dilator or mosquito or Kelly clamp may be used (Figure 30­6).
. Place the tube in the opening. Although instinct may guide you to direct the tracheostomy tube posterior, remember that the trachea is superficial and the tube should follow the tracheal axis (Figure 30­7).
. Connect to a bag­valve­mask device If no ventilation is heard bilaterally, pull the tube out and reinsert it.
for ventilation. Check for breath sounds Recheck for breath sounds to ensure that the endotracheal tube is correctly positioned after any with ventilation. manipulation.
When inserting a standard endotracheal tube, listen for asymmetry of breath sounds. If breath sounds are absent on the left side, then the tube has been inserted down the right mainstem bronchus and needs to be pulled back a few centimeters. If using an endotracheal tube, insert no more than 2–3 cm to avoid mainstem bronchus placement.
. Secure the tube carefully with a More challenging with a standard endotracheal tube.
ribbon and/or adhesive tape.
. Apply dressing and further secure If a tracheostomy tube has been used, fashion a simple dressing by cutting a slit halfway down the middle of a the tube. 4×4 gauze dressing and placing it under the tracheostomy tube.
Secure the tube with a ribbon placed through the flanges of the tracheostomy tube.
For added security, use 2­0 nylon sutures to fix the tube to the skin.
Consider changing endotracheal tubes to tracheostomy tubes whenever possible.
FIGURE 30­3. Locate the cricothyroid membrane. [Photo used with permission of Jennifer McBride, PhD, and Michael D. Smith, MD.]
FIGURE 30­4. Make a midline vertical incision. The pretracheal fascia is seen through the incision. Bleeding is less likely with a vertical incision. [Photo used with permission of Jennifer McBride, PhD, and Michael Phelan, MD.]
FIGURE 30­5. Perforate the cricoid membrane with a horizontal incision. [Photo used with permission of Jennifer McBride, PhD, and Michael Phelan, MD.]
FIGURE 30­6. Widen the opening. [Photo used with permission of Jennifer McBride, PhD, and Michael Phelan, MD.]
FIGURE 30­7. Insert a tracheostomy tube with obturator. [Photo used with permission of Jennifer McBride, PhD, and Michael Phelan, MD.]
SURGICAL CRICOTHYROTOMY USING SELDINGER TECHNIQUE
This method (Figure 30­8) uses a kit most often and starts with a small vertical incision through the skin at the CTM. Next, insert the needle at a 30­ to
45­degree angle pointing to the feet and aspirate air to make sure the needle is in the trachea. Once air aspiration is free, pass the guidewire through the needle, directing the guidewire caudally (toward the feet). Place a tracheostomy tube over the dilator, and make another “nick” in the skin to ease penetration. Pass the dilator, with the tracheostomy tube, over the guidewire into the trachea. Once the dilator is in the trachea, remove the guidewire, direct the tracheostomy tube into the trachea, and verify correct placement. Indications and complications are similar to the open method. Multiple different commercial kits exist, but proper use depends more on deliberate, repetitive training. (See Video: Needle Cricothyrotomy.)
Video 30­2: Needle Cricothyrotomy
Use with permission from David Cline and Henderson McGinnis, Department of Emergency Medicine, Wake Forest University Baptist Medical Center.
Play Video
FIGURE 30­8. Placement of a percutaneous cricothyrotomy with a commercial kit and the Seldinger technique. [Photo used with permission of David Effron, MD.]
COMPLICATIONS

Acute complications after emergency cricothyrotomy occur in up to 15% of cases. Venous bleeding usually occurs from small veins and stops spontaneously. Arterial bleeding can be from the thyroidea ima artery or from a small artery at the base of the CTM. The first step in controlling ongoing bleeding is to apply pressure. If bleeding persists, topical hemostatic agents or ligation may help stop it. A small amount of bleeding usually creates no hemodynamic concerns, but it can make the procedure more challenging.
In an obese patient, it is possible to place the tube anterior to the larynx and trachea into the mediastinum (false passage), making ventilation impossible. Signs of an incorrectly positioned tube are high airway pressures, absent breath sounds, and massive subcutaneous emphysema. If suspected, remove the tube and make a second attempt at insertion. Surgical consultation is recommended quickly as revision can be even more
 challenging than the initial approach.
Laceration of the trachea, esophagus, or recurrent laryngeal nerves is rare and often occurs when the procedure is performed by someone unfamiliar with the neck anatomy. Pneumothorax is usually secondary to barotrauma caused by ventilation initiated immediately after tube placement.
A tube left in the narrow space between the cricoid and thyroid cartilages can erode both cartilages over time, and bacterial chondritis may occur. The cartilages degrade and scar, leading to stenosis and loss of the function of the larynx. Because cricothyrotomy has a high incidence of airway
 stenosis, a change to tracheotomy is common after  to  days. In addition, if using an endotracheal tube, right mainstem intubation is common after a surgical airway given the relatively longer tube length. The key when using a standard endotracheal tube is to only insert deep enough to inflate the balloon within the trachea and achieve a seal; then, careful auscultation of breath sounds, assessment of carbon dioxide in expelled gas, and confirmation of placement above the carina follow.
PERCUTANEOUS CRICOTHYROTOMY AND TRANSTRACHEAL JET INSUFFLATION
If percutaneous access is pursued by “needle cricothyrotomy”—a poor but common term that is defined as a 12­ to 16­gauge needle catheter inserted into the trachea—the catheter must be attached to a higher­pressure oxygen source (≥35 psi); it cannot simply be attached to a standard wall oxygen outlet and be turned up or to wide open. Attachment of a 12­ to 16­gauge catheter directly to a wall
14­16 oxygen source or bag­valve mask will not reverse ventilation gaps and may only modestly aid oxygen delivery.

The proper equipment for jet ventilation must exist and be maintained, and the procedure requires practice, just like other surgical interventions. Do not perform jet ventilation without the correct equipment ready in advance and without antecedent practice; one cannot simply “put this together” at the time of critical need.
Jet ventilation uses a small catheter attached to either a pressure regulator attached directly to a wall oxygen source or cylinder via pressure tubing.
Jet ventilation can also be done using the VBM Manujet III or a commercial oxygen insufflator attached to high­flow oxygen (≥15 L or greater), such as
 the Enk® Oxygen Flow Modulator or the Rapid O Insufflator® (Figure 30­9). Set the oxygen pressure at  to  psi; if setting pressure for a small
 adult or child, use .5 psi/kg body mass and observe. In jet ventilation, the catheter and high­pressure gas provide volume for inhalation, and the
 native airway is the passive exhalation route. With proper jet ventilation, adequate oxygenation and ventilation occur. Duration is limited only by airway desiccation from nonhumidified gas, an effect that takes hours to a day to occur. Properly performed jet ventilation does not create hypercarbia or the need for rapid reestablishment of another airway; only poorly performed or “needle cricothyrotomy” low­pressure techniques create those situations.
FIGURE 30­9. A. VBM Manujet III. [Photo cropped from https://www.vbm­medical.com/products/airway­management/manujet­iii­jet­ventilation­catheters/. Used with permission from VBM Medical, Inc., Noblesville, IN.] B. Meditech Rapid­02. [Photo from http://www.diathermy.net/index.php/product/rapid­02/.
Meditech Systems Limited, unit  Shrublands, shearstock, Shaftesbury Dorset SP79PT UK.] C. Cook Medical ENK Oxygen Flow Modulator Set. [Photo from https://www.cookmedical.com/products/cc_efms_webds/. Permission for use granted by Cook Medical, Bloomington, Indiana, not available in
U.S.]
ANATOMY, INDICATIONS, AND CONTRAINDICATIONS
Anatomy and general indications were described earlier in this chapter. The only absolute contraindication is complete airway obstruction (i.e., expiration is blocked); this is exceptionally rare because most upper airway obstruction is inspiratory, including obstruction from masses. Relative contraindications are unfamiliarity, not having the equipment ready, and local infection at puncture site.
EQUIPMENT NEEDED
Equipment needed for transtracheal jet ventilation is listed in Table 30­5. Do not try to use standard oxygen tubing, three­way stopcocks, or bag­valve devices or attach to wall outlets turned to highest liter flow.
TABLE 30­5
Equipment Needed to Perform Jet Ventilation
Personal protective equipment
A 16­gauge or larger sheathed needle catheter or a commercial jet catheter
A 3­mL syringe
Connective tubing and connectors designed for high pressure (not standard oxygen tubing/securing attachments; these will not allow jet ventilation)
High­flow regulator with insufflation control
A high­pressure oxygen source; your respiratory technician can have the jet insufflator attached to an E cylinder or wall unit before downregulation to ensure high­pressure (35–50 psi) gas
PROCEDURE
The steps of performing jet ventilation are listed in Table 30­6. Optimize preprocedural oxygenation and ventilation when possible (although often failure is the reason for the procedure).
TABLE 30­6
Performing Jet Ventilation
Step Comment
. Stand to one side of the patient at the level of the Right­handed practitioner—stand on the patient’s right side.
neck. Left­handed practitioner—stand on the patient’s left side.
. Locate the cricothyroid membrane. Locate the cricoid ring.
Place the index finger at the sternal notch and palpate cephalad until the first rigid structure is felt (cricoid ring).
Roll the index finger one fingerbreadth above to locate the “hollow” between the cricoid and thyroid cartilages, locating the cricothyroid membrane (Figure 30­3).
. Attach a 3­mL syringe to the catheter. Smaller catheters tend to kink easily, as noted in photos, and limit gas flow. Use of a 16­gauge or larger commercial catheter is preferred (commonly a 13­gauge device).
. Introduce the catheter into the subcutaneous Figure 30­10. tissue at a 45­degree angle to the skin, aiming toward the patient’s feet.
. Aspirate gently while advancing the catheter over the needle.
. When air suddenly returns (indicating entry into the Free air aspiration = intratracheal placement; any resistance means not clearly in trachea.
airway), advance the catheter over the needle into the larynx.
. Once fully inserted, remove the needle and If resistance to air aspiration occurs after advancement, remove catheter and retry. Once the reaspirate to ensure ongoing free air aspiration. catheter is fully inserted, a stabilizing hand must always be present; do not ever let the proximal end be unsecured.
. Attach the high­flow regulator via connective Connect to a high­pressure source (35–50 psi); bag­valve devices and standard wall oxygen tubing to the catheter and start ventilation with a 100% valves opened to  L/min do not deliver 35–50 psi. The jet device is attached directly oxygen source. If a child, use .5 psi/kg to start and a 16­ to wall unit before standard regulators or directly to E cylinder (latter will allow >30 min of gauge catheter. ventilation if full).
Insufflate by holding valve down (open) for maximum of  s, and then release the occlusion for
 s. Listen for symmetric breath sounds, watch the chest rise and fall, and measure exhaled carbon dioxide if desired.
. Hold the catheter securely to avoid dislodgement. An inspiration:expiration ratio of 1:4 allows passive exhalation and avoids overventilation.
The catheter tends to kink easily, so maintain care with Monitor like any volume ventilation technique.
positioning.
. Stabilization is similar to cricothyrotomy, and plan Dressings are not necessary, and commercial kits have straps like tracheostomy tubes.
for next airway; gas exchange will be adequate for a The exhaled gas offers some aspiration protection.
prolonged interval, allowing a careful and controlled approach.
FIGURE 30­10. Introduce the catheter into the larynx. A. Introduce the catheter into the larynx skin at a 90­degree angle to the skin. B. When air returns, change the angle to  degrees. [Photo used with permission of Jennifer McBride, PhD, and Michael D. Smith, MD.]
COMPLICATIONS
,17
Damage to the trachea during insertion may occur, including perforation of the lateral or posterior wall, particularly in children. Failure to secure the catheter can lead to displacement. Bleeding at the puncture site and infection may occur. Massive subcutaneous emphysema can develop during ventilation, especially if the catheter is improperly inserted or misplaced in the soft tissues of the neck. Finally, delivery of excessive ventilatory force is
 associated with barotrauma, and equipment used in jet ventilation requires constant surveillance of chest rise and appropriate exhalation. Even if the cricoid membrane is not used (from misidentification), jet punctures rarely cause long­term airway complications, which is an advantage over cricothyrotomy.
DEVICE REMOVAL
Jet ventilation allows a more controlled approach to airway management; one can plan the next step(s) carefully and without fear of ventilation failure if done properly, avoiding any rush to another procedure. Often, a better laryngoscopic attempt or a formal tracheostomy can occur once time pressures are abated with jet ventilation.


