## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 230: Adrenal Insufficiency
Alzamani Mohammad Idrose
INTRODUCTION
The adrenal gland synthesizes steroid hormones in the cortex and catecholamines in the medulla. Primary adrenal insufficiency, or Addison’s disease, is due to intrinsic adrenal gland dysfunction and results in decreased cortisol, aldosterone, and gonadotropin production.
About 90% of the gland must be destroyed for clinical adrenal insufficiency to develop.
Secondary adrenal insufficiency is due to hypothalamic–pituitary dysfunction with failure to secrete corticotropin­releasing hormone
 and/or adrenocorticotropic hormone (ACTH) and results in cortisol deficiency only.
Adrenal crisis is a life­threatening exacerbation of adrenal insufficiency when an increased demand fails to increase hormone production. The risk of
2­4 death is higher in those who are older, diabetic, or present with impaired consciousness.
PHYSIOLOGY
The adrenal gland is made up of the cortex and medulla, which produce steroid hormones and catecholamines, respectively. The adrenal cortex produces three categories of steroids: the glucocorticoids (cortisol), mineralocorticoids (aldosterone), and gonadocorticoids (sex hormones).
Glucocorticoids are produced in the zona fasciculata, and mineralocorticoids and gonadocorticoids are respectively produced in the zona glomerulosa and zona reticularis of the adrenal cortex. The adrenal medulla produces adrenalin, noradrenalin, and a small amount of dopamine in response to stimulation by sympathetic preganglionic neurons.
Cortisol is secreted in response to direct stimulation by ACTH. ACTH secretion is stimulated by corticotropin­releasing factor released from the hypothalamus. Secretion occurs in a diurnal rhythm, with higher levels secreted in the morning and lower levels in the evening. In normal circumstances, the daily cortisol equivalent is about  milligrams/d of hydrocortisone. Plasma cortisol suppresses the release of ACTH through negative feedback inhibition. Cortisol facilitates the stress response by affecting the heart, vascular bed, water excretion, electrolyte balance, potentiation of catecholamine action, and control of water distribution. It affects fat, protein, and carbohydrate metabolism by stimulating glycogenolysis and neoglycogenesis. It is involved in immunologic and inflammatory responses and affects calcium metabolism. It promotes growth and development but, in excess, interferes with the GI tract mucosa maintenance, leading to peptic ulcer.
Aldosterone secretion is controlled primarily by the renin–angiotensin system and serum potassium concentration. The renin–angiotensin system controls aldosterone levels in response to changes in volume, posture, and sodium intake. Serum potassium (hyperkalemia) influences the adrenal cortex directly to increase aldosterone secretion. Aldosterone maintains sodium and potassium plasma concentrations, regulates extracellular volume, and controls sodium and water balance.
Gonadocorticoids include androgen hormones and estrogen. Androgens produced include testosterone, dehydroepiandrosterone, and dehydroepiandrosterone sulfate, which are present in both men and women. In women, androgens are produced in the adrenal glands as well as the ovaries and promote the development of sex characteristics such as axillary and pubic hair and libido. In men, most androgens (testosterone) are produced in the testes. Androgens made by the adrenal glands are less important for normal sexual function.
PRIMARY ADRENAL INSUFFICIENCY
Causes of primary adrenal insufficiency (Addison’s disease) are shown in Table 230­1. In the United States, autoimmune disorders are responsible
,3 for most cases. Autoimmune disorders may occur as an isolated process or as a component of polyglandular autoimmune syndrome types I and II.

Drugs such as etomidate, aminoglutethimide, mitotane, and ketoconazole suppress cortisol synthesis by the adrenal gland. Etomidate can precipitate
Chapter 230: Adrenal Insufficiency, Alzamani Mohammad Idrose 
 a©c2u0t2e5 a dMrceGnarla iwn sHuiflfli.c Aielln Rcyig ihnt sa dRoessee­rdveepde. n dTeenrtm ms aonf nUesre. * D Prurgivsa scuyc Ph oalsic pyh * e Nnyottoicine, * p Ahecnceosbsairbbiilittayl, rifampicin, and thyroid hormone replacement may increase glucocorticoid metabolism.
In terms of infection, worldwide, tuberculosis is the most common cause of primary adrenal insufficiency. Human immunodeficiency virus may cause adrenal insufficiency through opportunistic infections (principally cytomegalovirus) or use of medications, such as ketoconazole. Secondary adrenal insufficiency can develop through inhibition of the hypothalamus–pituitary–adrenal axis.
Infiltrative diseases such as amyloidosis, hemosiderosis, and bilateral metastasis from cancer may also cause primary adrenal insufficiency.
Thrombosis and/or hemorrhage of the adrenals may occur as a complication of anticoagulation therapy, sepsis, disseminated intravascular coagulation, meningococcemia (Waterhouse­Friderichsen syndrome), or antiphospholipid syndrome.
TABLE 230­1
Causes of Primary Adrenal Insufficiency
Etiologies Examples
Autoimmune Isolated adrenal insufficiency or associated with polyglandular insufficiencies (polyglandular autoimmune syndrome type I or II)
Adrenal hemorrhage or Necrosis caused by meningococcal sepsis thrombosis Coagulation disorders
Overwhelming sepsis (Waterhouse­Friderichsen syndrome)
Drugs Adrenal enzyme inhibitors (affect those with limited pituitary or adrenal reserve)
Etomidate
Aminoglutethimide (used by body builders)
Mitotane (orphan drug used to treat adrenocortical carcinoma)
Ketoconazole
Infections Tuberculosis
Fungal, bacterial sepsis
Acquired immunodeficiency syndrome involving adrenal glands
Infiltrative disorders Sarcoidosis
Hemochromatosis
Amyloidosis
Lymphoma
Metastatic cancer
Surgery Bilateral adrenalectomy
Bariatric surgery
Hereditary Adrenal hypoplasia
Congenital adrenal hyperplasia
Adrenoleukodystrophy
Familial glucocorticoid deficiency
SECONDARY ADRENAL INSUFFICIENCY
,7
Secondary adrenal insufficiency can develop through inhibition of the hypothalamus–pituitary–adrenal axis. Causes are shown in Table 230­2. Secondary adrenal failure is usually characterized by depressed ACTH secretion, which reduces cortisol production, but aldosterone levels remain normal because of preserved stimulation by both the renin–angiotensin axis and potassium. Adrenal sex hormone production is also preserved.
Intracranial disorders such as brain tumor, pituitary disease, postpartum pituitary necrosis, or major head trauma may affect the hypothalamic–
 pituitary function, resulting in secondary adrenal insufficiency.

The most common cause of secondary adrenal insufficiency is long­term therapy with pharmacologic doses of glucocorticoids. Severity of adrenal suppression is variable and depends on the dose and potency of the glucocorticoid and the time of day the drug is taken (suppression is greater when taken in the evening). Recovery of the hypothalamus–pituitary–adrenal axis may take a few months to  year after steroid cessation. Although hypothalamus–pituitary–adrenal axis suppression is related to duration of treatment, steroid dose, and total cumulative dose, there is no strict
 correlation with any of these factors. Some critically ill patients demonstrate reduced cortisol clearance and suppression of ACTH release.
TABLE 230­2
Causes of Secondary Adrenal Insufficiency
Etiology Examples
Prolonged glucocorticoid therapy Chronic use of steroids inhibits CRH and ACTH production
Pituitary necrosis or bleeding Postpartum pituitary necrosis (Sheehan’s syndrome)
Brain tumors Pituitary/hypothalamic tumor
Local invasion (craniopharyngioma)
Pituitary irradiation/surgery/head trauma Disrupts CRH and ACTH production capacity in hypothalamic–pituitary axis
Infiltrative disorders of the pituitary or hypothalamus Sarcoidosis
Hemosiderosis
Hemochromatosis
Histiocytosis X
Metastatic cancer
Lymphoma
CNS infections involving hypothalamus or pituitary Tuberculosis
Meningitis
Fungus
Human immunodeficiency virus
Abbreviations: ACTH = adrenocorticotropic hormone; CRH = corticotropin­releasing hormone.
ADRENAL CRISIS
Adrenal crisis is a life­threatening state caused by insufficient levels of cortisol. It can result from acute destruction of the hypothalamic–pituitary axis or the adrenal glands or from acute stressors in the setting of underlying primary or secondary adrenal insufficiency. Reported stressors include acute infection, especially GI infection; surgery; extreme physical activity; acute severe injury or burns; and cessation of chronic glucocorticoid
  replacement. Infections are the most common precipitants.
Acute adrenal crisis is characterized by severe hypotension refractory to vasopressors. Other symptoms include severe abdominal pain, nausea, and vomiting, mimicking an acute abdomen. CNS symptoms of confusion, disorientation, and lethargy may be present. There may be associated sepsis, even without fever. Consider adrenal crisis in situations of unexplained hypotension, especially in patients with a history of glucocorticoid therapy; those with acquired immunodeficiency syndrome, tuberculosis, autoimmune disease, or severe head trauma; those with a history of chronic fatigue and hyperpigmentation; and those with disorders known to cause acute adrenal crisis (as seen in Tables 230­1 and 230­2).
CLINICAL FEATURES
Primary and secondary adrenal insufficiency have dissimilar clinical presentations (Table 230­3). Primary adrenal insufficiency presents with symptoms of diminished cortisol, aldosterone, and gonadocorticoids, and increased ACTH, which causes skin hyperpigmentation. On the other hand, secondary adrenal insufficiency presents with symptoms of diminished cortisol and possibly with related symptoms of intracranial lesions (e.g., headache, visual changes, galactorrhea). Cortisol deficiency symptoms depend on the cause and can include weight loss, lethargy, weakness, mental status changes, and GI symptoms (anorexia, nausea, vomiting, abdominal pain, and diarrhea). Mineralocorticoid (aldosterone) deficiency symptoms include dehydration, syncope, salt craving, and hypotension (usually with orthostatic changes). Gonadocorticoid deficiency symptoms are observed more in women, who present with decreased axillary and pubic hair and decreased libido.
TABLE 230­3
Features of Primary and Secondary Adrenal Insufficiency
Features Primary Secondary
Volume depletion and hypotension Marked Not as severe unless crisis is present
Serum potassium Hyperkalemia Hypokalemia
Serum sodium Hyponatremia Hypernatremia (aldosterone present) or hyponatremia
(due to water retention)
Cushingoid appearance Absent May be present (if due to long­term glucocorticoid use)
Symptoms of other pituitary hormone deficiencies (e.g., Absent May be present (depends on the hypothalamic–pituitary hypothyroidism and amenorrhea) site of lesion)
Skin pigmentation Present (due to high Absent
ACTH level)
Serum glucose Low Low
ACTH High Low
Cortisol Low Low
Abbreviation: ACTH = adrenocorticotropic hormone.
LABORATORY STUDIES AND IMAGING
Obtain a bedside glucose determination to identify hypoglycemia. Obtain CBC, serum electrolyte and calcium levels, serum cortisol, hepatic function
 studies, ECG, and urinalysis. Additional studies are determined by the presumptive underlying cause such as sepsis, hemorrhage, or CNS abnormality. Chest radiograph can assess for tuberculosis or bacterial pneumonia. An abdominal CT scan can identify adrenal gland hemorrhage or infarction. Head CT or MRI can assess CNS causes of secondary adrenal insufficiency.
Primary adrenal insufficiency is typically characterized by hyponatremia and hyperkalemia due to mineralocorticoid (aldosterone) deficiency.
Reduced cortisol and aldosterone also cause increased antidiuretic hormone release, which causes hyponatremia. The serum potassium may also be affected by the dilutional effect, and thus sometimes the potassium level may be normal. Secondary adrenal insufficiency is characterized by either hypernatremia from functioning aldosterone causing renal sodium reabsorption or hyponatremia following water retention. In both primary and secondary adrenal insufficiency, cortisol deficiency can lead to hypotension or hypoglycemia. Mild metabolic acidosis is evident due to tissue hypoxia from hypovolemia and hypotension. ECG changes are generally related to potassium imbalances. Hypercalcemia can occur, from calcium mobilization from bone stores and calcium resorption in the proximal tubule.
Serum cortisol or ACTH levels are not usually readily available at ED presentation. If available, a serum cortisol >18 micrograms/dL generally rules out
  adrenal insufficiency. A high ACTH level is seen in primary adrenal insufficiency, but ACTH is low in secondary adrenal insufficiency. The ACTH stimulation test can also differentiate primary from secondary adrenal insufficiency. After obtaining a baseline cortisol level, 250 micrograms of cosyntropin (synthetic form of ACTH) is administered IV. Significant increase in serum cortisol (>18 micrograms/dL) confirms secondary adrenal
12­15 insufficiency. If an ACTH stimulation is contemplated and emergent steroids are necessary, give dexamethasone, as it has minimal cross­reactivity with cortisol.
TREATMENT
ADRENAL INSUFFICIENCY
For primary adrenal insufficiency, treatment requires daily dosing of glucocorticoid and mineralocorticoid, usually for life. Mineralocorticoids are replaced with an oral, synthetic mineralocorticoid drug such as fludrocortisone (Florinef ®). The dose is tailored to manage blood pressure and fluid balance. Androgen replacement may be recommended for women. For secondary adrenal insufficiency, only glucocorticoid replacement is required. Typical glucocorticoid dose is  milligrams/d of oral hydrocortisone or prednisolone equivalent. Dexamethasone is not used for
 maintenance because dose titration is difficult and cushingoid effects can be pronounced.
For patients receiving chronic steroids, increase the maintenance dose during periods of stress (e.g., illness, surgery, trauma, GI upset) to satisfy the increased physiologic need for cortisol. Dosage recommendations vary and are based on expert opinion. A typical stress dose is three times the
 daily maintenance dose of glucocorticoid. Mineralocorticoid dosage generally stays the same. Endocrinology consultation can be helpful for further recommendations.
ADRENAL CRISIS
Treatment is outlined in Table 230­4. Begin therapy immediately in any suspected case of adrenal crisis, because prognosis is related to the rapidity of treatment onset. Give IV fluids and steroids early. If hypoglycemia is present, give dextrose­containing solutions.
TABLE 230­4
Treatment for Adrenal Crisis
Administer IV Fluids for Hypotension
Use dextrose­containing saline if hypoglycemic (begin with D5/NS).
↓
Give Steroids
Hydrocortisone, 100­milligram IV bolus, is the drug of choice for cases of adrenal crisis or insufficiency, especially for underlying primary insufficiency
(provides both glucocorticoid and mineralocorticoid effects). If no IV access, 100 milligrams can be given IM. Follow with IV infusion of 200 milligrams/24 h of hydrocortisone or 100 milligrams IV every  h. Obtain consultation for further dosing.
or
Dexamethasone, 4­milligram bolus (preferred if rapid ACTH stimulation test is contemplated). However, if dexamethasone is given, add fludrocortisone
100 micrograms/d as dexamethasone does not have mineralocorticoid properties.
↓
Supportive Care
Maintain airway, breathing, and circulation; consider bolus glucose, thiamine, naloxone, etc., for altered mental status. Correct potassium, sodium, and calcium.
↓
Consider Vasopressors
Administer only after steroid therapy in patients unresponsive to aggressive fluid resuscitation (choice of norepinephrine, dopamine, or phenylephrine
[Neo­Synephrine®]).
↓
Determine Underlying Cause
Investigate as appropriate—sepsis, adrenal hemorrhage, CNS abnormality.
↓
Optimize Maintenance Dosage of Steroids
Patients may require lifelong glucocorticoids ± mineralocorticoid ± androgen supplementation. During periods of stress, increase maintenance doss of chronic steroids up to  times the daily dose, to satisfy increased physiologic need for cortisol.16
Abbreviations: ACTH, adrenocorticotropic hormone; D5/NS, 5% dextrose/normal saline.
DISPOSITION AND FOLLOW­UP
Admit patients with adrenal crisis to an intensive care unit for careful clinical monitoring, IV steroid administration, and confirmation of diagnosis and identification of etiology. Discharge can only be considered for mild cases of adrenal insufficiency with identified etiologies and after a clear plan of management is established, often with endocrinology consultation.
SPECIAL POPULATIONS
PATIENTS ON CHRONIC CORTICOSTEROIDS
Hypothalamus–pituitary–adrenal axis function is inhibited with chronic use of steroids. Always consider adrenal insufficiency in patients with chronic steroid use presenting with any acute illness. Hypothalamus–pituitary–adrenal axis function should recover within about  month after the last dose of steroid intake but may be longer in some cases. Patients who receive steroids by topical, intranasal, inhalational, or PR routes are not at risk for hypothalamus–pituitary–adrenal axis suppression.
PATIENTS WITH CHRONIC ADRENAL INSUFFICIENCY WITH ACUTE ILLNESS OR INJURY

Patients with chronic adrenal insufficiency who present to the ED with a minor illness or injury require special attention to steroid dosing. In normal circumstances, about  milligrams/d of hydrocortisone is equivalent to the daily production of cortisol. For a minor illness or injury, triple the daily
 glucocorticoid dose for  to  hours until symptoms improve. Increasing the mineralocorticoid dose, if the patient is receiving one, is usually not necessary. Arrange follow­up care in  hours with the primary care physician or endocrinologist. Patients should return to the ED if nausea, vomiting, fever, weakness, or any other untoward symptoms develop or if they cannot retain their medications.
PREGNANCY WITH ADRENAL INSUFFICIENCY
Most women with primary adrenal insufficiency are able to undergo healthy pregnancy, labor, and delivery. During the third trimester, the glucocorticoid dose may require adjustment. Give hydrocortisone bolus, 100 milligrams, during labor. Women with hyperemesis gravidarum may need to switch from oral medication to parenteral medication until symptoms subside.
SEPSIS
Intravenous hydrocortisone is not necessary to treat septic shock if adequate fluid resuscitation and vasopressor therapy restore hemodynamic
 stability. Intravenous hydrocortisone at a dose of 200 milligrams/d is only recommended if these are not achievable.
Etomidate, which is used in rapid sequence induction, suppresses adrenal synthesis of cortisol by inhibiting adrenal mitochondrial 11­β hydroxylase,
 the enzyme responsible for the final conversion of 11­deoxycortisol to cortisol. Previous studies have evaluated the effect of etomidate on adrenocortical suppression in septic patients; however, none of the studies have been sufficiently powered to determine the effects on mortality. A
,19 single dose of etomidate does not increase mortality in patients with sepsis.


