## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 243: Face and Jaw Emergencies
Stephanie A. Lareau; Corey R. Heitz
INTRODUCTION
This chapter will discuss facial infections and disorders involving the mandible. Bell’s palsy is discussed in Chapter 172, “Acute Peripheral Neurologic
Disorders.” Trigeminal neuralgia is discussed in Chapter , “Chronic Pain.” Nonfacial cellulitis and erysipelas are discussed in Chapter 152, “Soft
Tissue Infections.” Impetigo in children is discussed in Chapter 142, “Rashes in Infants and Children.” Orbital cellulitis is discussed in Chapter 241, “Eye
Emergencies.”
FACIAL CELLULITIS, ERYSIPELAS, AND IMPETIGO

The differential diagnosis of facial infections is provided in Table 243­1. TABLE 243­1
Differential Diagnosis of Superficial Facial Infection
Historical Features
Onset/Timing Risk/Inciting Factors Physical Findings
Infectious
Cellulitis Gradual Skin breaks, foreign bodies, prostheses, immunosuppression Diffuse erythema without clear borders, pain
Impetigo Acute Infants, children Discrete vesicles or bullae; patches of crusty skin
Erysipelas Acute Elderly, infants and children, immune deficiency, diabetes, Well­defined, raised area of erythema, alcoholism, skin ulceration, impaired lymphatic drainage pain
Viral exanthem Often acute Preceding or concurrent viral illness, fever Variable
Parotitis Gradual Dehydration, diabetes, immunosuppression Swollen angle of mandible, potentially visible sialolith
Necrotizing fasciitis Rapid Trauma, may be minor or not apparent Crepitus, skin necrosis, may be subtle
Cutaneous anthrax Gradual Animal contact Black eschar with surrounding erythema
Herpes zoster Acute Elderly, immunosuppression Exquisitely tender erythematous or vesicular rash following a dermatome

Malignant otitis externa Gradual Diabetes, water exposure Ear pain with drainage, facial swelling,
Chapter 243: Face and Jaw Emergencies, Stephanie A. Lareau; Corey R. Heitz tragal tenderness
. Terms of Use * Privacy Policy * Notice * Accessibility
Inflammatory
Insect envenomation Acute Environment supporting insect life Diffuse, red, puffy
Apical abscess with Gradual Usually associated dental pain/caries Similar to cellulitis; may have secondary buccal intraoral/gingival findings swelling
Contact dermatitis Gradual or Often identifiable exposure Variable; maculopapular, itchy rash acute
Immunologic
Systemic lupus Gradual Female­to­male ratio, 9:1 Erythema in classic “malar” distribution erythematosus
Angioneurotic edema Acute Exposure to angiotensin­converting enzyme inhibitor, allergen Lip, oral mucosal swelling, sometimes facial
Vancomycin flushing Acute Recent exposure to vancomycin Facial erythema, warmth reaction
CELLULITIS
2­4 
Cellulitis is a superficial soft tissue infection that lacks anatomic constraints. Facial cellulitis is caused most commonly by Streptococcus species,
 including Streptococcus pyogenes (group A β­hemolytic) and group G Streptococcus, and Staphylococcus aureus, with an increasing predominance
 of methicillin­resistant S. aureus. An important consideration for facial cellulitis is the potential for an odontogenic source of the infection in the
,7 midface. Anaerobic bacteria account for 24% to 62% of the odontogenic infections. Methicillin­resistant S. aureus is the most common cause of
 purulent cellulitis, identified by purulent drainage, purulent bulla, or suspected abscess. Methicillin­resistant S. aureus also is suspected when risk factors are present (see Chapter 152, “Soft Tissue Infections”). Less commonly, cellulitis may represent extension from deep space infections (see
“Masticator Space Infection” section later in this chapter). Bedside US can exclude or identify facial abscess (Figure 243­1). CT can identify deepseated infections incompletely imaged by US.
FIGURE 243­1. Cellulitis versus abscess. The image on the left shows the cobblestoned appearance of cellulitis, while the one on the right shows a heterogenous fluid collection of abscess. [Photo contributed by R. Gordon, MD.]
,6­12
Treatment options organized by infection type are provided in Table 243­2. The selection of an antibiotic for cellulitis is based on differentiation
,10 ,6,7,10­12 of purulent from nonpurulent forms. Duration of therapy is incompletely studied, but recommendations range from  to  days, extended
,10 to  to  days for immunocompromise or inadequate response. Treatment failures range from 15% to 20% for β­lactams (amoxicillin­clavulanate,
 cephalexin, and dicloxacillin) as well as for the anti–methicillin­resistant S. aureus therapies due to the failure to cover methicillin­resistant S. aureus and streptococcal species, respectively. In selected cases, traditional β­lactam therapy may be added to anti–methicillin­resistant S. aureus therapy,
 ,7,9 but this strategy does not improve outcome. Include coverage for anaerobic bacteria when suspecting an odontogenic source (Table 243­2).
Incision and drainage is the most effective treatment for abscess (see Chapter 152, “Soft Tissue Infections”). Antibiotic dose recommendations are listed in Table 243­3. TABLE 243­2
Antibiotic Therapy for Facial Infections
Infection Type Recommended Antibacterial Therapy
Nonpurulent cellulitis Oral therapy: dicloxacillin, cephalexin, amoxicillin­clavulanate, clindamycin
Parenteral therapy: nafcillin, cefazolin, clindamycin
Total duration 5–7 d, extend if slow to respond or immunocompromised
Purulent cellulitis (MRSA Oral therapy: trimethoprim­sulfamethoxazole, doxycycline, minocycline, clindamycin, linezolid predominate)
Parenteral therapy: vancomycin, daptomycin, linezolid, ceftaroline
Total duration 5–7 d, extend if slow to respond or immunocompromised
Facial cellulitis of Oral therapy: amoxicillin­clavulanate, clindamycin, β­lactam drug plus metronidazole odontogenic origin
Parenteral therapy: ampicillin­sulbactam, piperacillin­tazobactam, clindamycin, β­lactam drug plus metronidazole
Total duration 5–7 d, extend if slow to respond or immunocompromised
Erysipelas Oral therapy: amoxicillin or penicillin (only if MRSA is unlikely)
Methicillin­sensitive Staphylococcus aureus suspected: amoxicillin­clavulanate, cephalexin, dicloxacillin
Bullous erysipelas (or MRSA suspected): trimethoprim­sulfamethoxazole, clindamycin, doxycycline, or minocycline
Parenteral therapy: vancomycin, nafcillin, clindamycin
Total duration 5–7 d, extend if slow to respond or immunocompromised
Impetigo Topical: mupirocin or retapamulin ointment alone or with oral therapy
Oral therapy: dicloxacillin, amoxicillin­clavulanate, cephalexin
Alternative: azithromycin
MRSA suspected: clindamycin or trimethoprim­sulfamethoxazole
Total duration 5–7 d, extend if slow to respond or immunocompromised
Suppurative parotitis Oral therapy: amoxicillin­clavulanate, clindamycin, or cephalexin with metronidazole
Parenteral therapy: nafcillin, or ampicillin­sulbactam; if penicillin allergic, clindamycin or the combination of cephalexin with metronidazole, or vancomycin with metronidazole
Hospital acquired or nursing home patients: consider vancomycin
Total duration: 10–14 d
Masticator space infection Parenteral therapy: IV clindamycin, ampicillin­sulbactam, piperacillin­tazobactam, or the combination of ampicillin with metronidazole
Oral therapy: clindamycin or amoxicillin­clavulanate
Total duration: 10–14 d
Abbreviation: MRSA = methicillin­resistant Staphylococcus aureus.
TABLE 243­3
Antibiotic Doses for Facial Infections
Antibiotic Dosage
Oral Antibiotics
Amoxicillin/clavulanate 875/125 milligrams twice per day
Azithromycin 500 milligrams first day, 250 milligrams  more days
Cephalexin 500 milligrams four times per day
Clindamycin 300 milligrams three or four times per day
Dicloxacillin 500 milligrams four times per day
Doxycycline 100 milligrams twice per day
Metronidazole 500 milligrams every  h
Minocycline 100 milligrams twice per day
Penicillin V 500 milligrams four times per day
Trimethoprim­sulfamethoxazole  double­strength tablet twice per day
Parenteral Antibiotics
Ampicillin­sulbactam .5–3.0 grams every  h
Piperacillin­tazobactam .375 grams every  hours
Clindamycin 600 milligrams every  h
Ceftaroline 600 milligrams IV every  h (with CrCl >50 mL/min)
Cefazolin  gram every  h
Daptomycin  milligrams/kg IV every  h (with CrCl >30 mL/min)
Linezolid 600 milligrams IV every 12h
Metronidazole  gram loading dose, then 500 milligrams every  h
Nafcillin 1–2 grams every  h
Penicillin G 2–3 million units every  h
Vancomycin  milligrams /kg every  h with adjustment for renal function
Abbreviation: CrCl = creatinine clearance.
ERYSIPELAS
15­17
Erysipelas is most common in the lower extremities (66% to 76%) but is classically described as a disease of the face (see Figure 152­3). Erysipelas is
,15 caused by group G S. pyogenes, group C and group G Streptococcus, and S. aureus. Bullous erysipelas is a more severe form of the disease and
 most commonly is caused by methicillin­resistant S. aureus. Penicillin is the antibiotic treatment of choice for presumed non–methicillin­resistant S.
,17 ,15­17 aureus infections but is chosen as empiric therapy in a minority of cases. If the suspicion exists of a staphylococcal infection (i.e., bullae, trauma, or the presence of a foreign body), include coverage for methicillin­resistant S. aureus (Table 243­2).
IMPETIGO
Impetigo is a discrete, superficial bacterial epidermal infection characterized by amber crusts (nonbullous) or fluid­filled vesicles (bullous) (see Figure
142­15). It is most common in children. S. aureus alone or in combination with S. pyogenes (group A β­hemolytic) is the most common cause of
,20 ,22 nonbullous impetigo. Bullous impetigo is typically caused by S. aureus. Treatment should cover streptococcal and staphylococcal species.

Topical therapy is sufficient for uncomplicated patients with nonbullous lesions. Mupirocin, retapamulin, or fusidic acid ointment is recommended;
22­24 however, some resistance exists. Consider oral antibiotics for extensive lesions or lesions that do not respond to topical therapy alone. There is no
,21 clear preference between macrolides, β­lactamase–resistant penicillins, and cephalosporins. Preferred choices are penicillinase­resistant
 penicillins (dicloxacillin, amoxicillin­clavulanic acid) or first­generation cephalosporins (cephalexin). For methicillin­resistant S. aureus, treat with
 trimethoprim­sulfamethoxazole or clindamycin (Table 243­3). In endemic regions (e.g., areas of Australia), scabies infestation frequently coexists with
  impetigo. Consider adding ivermectin, 200 micrograms/kg, single dose, in addition to antibacterial therapy for impetigo.
SALIVARY GLAND INFECTIONS
There are three groups of salivary glands: the parotid, submandibular, and sublingual. The facial nerve passes through the superficial portion of the parotid gland, and the parotid (Stensen’s) duct opens into the mouth opposite the upper second molar. The submandibular and sublingual glands lie below the plane of the tongue. The submandibular ducts open into the mouth at either side of the frenulum of the tongue. The multiple sublingual
 ducts open into the sublingual fold or directly into the submandibular duct.
Signs of salivary gland infections are unilateral or bilateral facial swelling. Recurrent symptoms, dry mouth and eyes, or joint symptoms suggest etiologies such as immunologic or collagen vascular disorders. Other medical conditions, such as nutritional disorders, toxic exposures, diabetes, dehydration, medication usage (e.g., phenothiazines), pregnancy, and obesity, can result in salivary gland enlargement. On physical examination, determine the location of the swelling to identify the gland involved. Multiple gland involvement suggests infection. A palpable tender mass may be a
,28 sign of tumor or obstruction by a stone. The differential diagnosis of salivary gland swelling is provided in Table 243­4. TABLE 243­4
Differential Diagnosis of Salivary Gland Swelling
Historical Features
Disorder Onset Risks/Inciting Factors Clinical Features
Infectious
Viral parotitis Gradual Nonimmunized Prodromal illness, unilateral tense swelling, absent
(mumps) warmth/erythema
Buccal cellulitis Gradual Haemophilus influenzae infection in nonimmunized Erythematous, tender
Suppurative Rapid Dehydration, immunosuppression, chronic illness, recent Painful buccal swelling, fever, pus expression from parotitis anesthesia Stensen’s duct
Masseter space Gradual Dental infection, post trauma Trismus, posterior inferior facial swelling abscess
Tuberculosis Gradual Exposure, immunosuppression Chronic crusting plaques
Immunologic
Sjögren’s Gradual — Dry mouth, eyes, sclerosis syndrome
Systemic lupus Gradual Female sex, Asian or African American race No signs of infection
Sarcoidosis Gradual Female sex, African American race No signs of infection
Other
Neoplasm Gradual — No erythema, warmth
Sialolithiasis Gradual Dehydration, chronic illness Swelling, tenderness, no signs of infection
VIRAL PAROTITIS (MUMPS)
Viral parotitis is an acute infection of the parotid glands, characterized by unilateral or bilateral parotid swelling. It is most often caused by the paramyxovirus and may be caused less commonly by influenza, parainfluenza, coxsackie viruses, echoviruses, lymphocytic choriomeningitis virus, and
 even human immunodeficiency virus. It is most common in children under the age of  years old, but since November 2014, clusters of mumps have been reported in adult members of professional hockey teams. The virus is spread by airborne droplets, incubates in the upper respiratory tract for  to  weeks, and then spreads systemically. Vaccine protection is not 100%, and outbreaks occur in settings of close contact, such as schools, colleges,
 sports teams, and camps.
After a period of incubation, one third of patients experience a prodrome of fever, malaise, headache, myalgias, arthralgias, and anorexia during a 3­ to

5­day period of viremia. The classic salivary gland swelling then follows. Unilateral swelling is typically followed by bilateral parotid involvement. The
 gland is tense and painful, but erythema and warmth are notably absent. Stensen’s duct may be inflamed, but no pus can be expressed.
Diagnosis is clinical and treatment is supportive. Salivary gland swelling typically lasts from  to  days. The patient is contagious for  days after the onset of parotid swelling, and children with mumps should be excluded from school or day care for this interval.
Mumps is usually benign in children but can be severe in adults. Unilateral orchitis affects 20% to 30% of males (with a predisposition of ≥8 years of age), whereas oophoritis affects only 5% of females. Other complications of the mumps virus include mastitis, pancreatitis, aseptic meningitis,
 sensorineural hearing loss, myocarditis, polyarthritis, hemolytic anemia, and thrombocytopenia. Immunocompetent patients with isolated viral parotitis or orchitis can be managed as outpatients. Admit patients with systemic complications.
SUPPURATIVE PAROTITIS
Suppurative parotitis is a serious bacterial infection of the parotid gland that occurs in patients with compromised salivary flow. It is caused by the
 retrograde migration of oral bacteria into the salivary ducts and parenchyma. Predisposing factors include recent anesthesia, dehydration,
 prematurity or advanced age, sialolithiasis, oral neoplasms, salivary duct strictures, tracheostomy, and ductal foreign bodies. Medications that cause either systemic dehydration or decreased salivary flow specifically can cause parotitis. These include diuretics, antihistamines, tricyclic
 antidepressants, phenothiazines, β­blockers, and barbiturates. Several chronic illnesses also predispose patients to suppurative parotitis, such as human immunodeficiency virus, hepatic or renal failure, diabetes mellitus, hypothyroidism, malnutrition, Sjögren’s syndrome, depression, anorexia,
 bulimia, hyperuricemia, and cystic fibrosis.
Most cases of suppurative parotitis are caused by S. aureus, with Streptococcus pneumoniae, S. pyogenes, and Haemophilus influenzae as more
,28 ,31 infrequent pathogens. Anaerobes such as Bacteroides species, peptostreptococci, and fusobacteria are common. In the immunocompromised
,31 host, gram­negative organisms such as Escherichia coli and Pseudomonas may be seen.
The onset of suppurative parotitis is rapid, and the skin over the parotid gland is red and tender. Pus may be expressed from the Stensen’s duct. There is often fever and trismus.
Suppurative parotitis is diagnosed clinically, with evidence of purulent drainage from Stensen’s duct. Cultures of Stensen’s duct drainage can guide
 therapy in the patient not responding to first­line antibiotics. Imaging is not helpful unless an abscess is suspected, in which case US or CT is diagnostic.
Because suppurative parotitis is caused by states of decreased salivary flow, treatment should optimize salivary flow. Hydrate the volume­depleted patient. Massage and apply heat to the affected gland. Stimulate salivation using sialagogues, such as lemon drops. When possible, discontinue drugs
,31 that cause dry mouth, and attempt to correct underlying medical problems.
Treat patients with oral antibiotics if they can tolerate oral liquids and have no evidence of systemic illness. Admit for parenteral antibiotics patients who have trismus and cannot tolerate oral liquids, are immunocompromised or incapable of complying with an outpatient treatment regimen, or have
,31 not shown improvement after  hours of outpatient treatment.
Antimicrobial therapy consists of agents that cover both staphylococcal and streptococcal species (Tables 243­2 and 243­3). The initial choice for oral
,30,31 therapy includes amoxicillin­clavulanate; in penicillin­allergic patients, use clindamycin or a combination of cephalexin with metronidazole.
When parenteral therapy is indicated, choices include nafcillin, ampicillin­sulbactam, or a combination of vancomycin with metronidazole. In
 hospitalized or nursing home patients, the possibility of methicillin­resistant S. aureus, for which vancomycin is appropriate, must be considered. In neonates, treat with gentamicin and antistaphylococcal antibiotics combined with hydration. If there is no improvement in  to  hours, surgical drainage is required.
SIALOLITHIASIS
Sialolithiasis is the development of a calcium carbonate and calcium phosphate stone (sialolith) in a stagnant salivary duct. Salivary calculi can develop
 in any age group, but usually are symptomatic in men between the third and sixth decades. More than 80% of stones occur in the submandibular gland, with most of the remainder in the parotid.
The symptoms of pain, swelling, and tenderness may resemble those of parotitis. It may be hard to distinguish parotitis from sialolithiasis, and the two conditions may coexist. Sialolithiasis is typically unilateral. The pain and swelling of sialolithiasis are colicky and exacerbated by meals.

The diagnosis is clinical. A stone may be palpated within the duct, and the gland is firm. Intraoral radiographs are more sensitive than extraoral films in identifying salivary calculi. The calculi are radiopaque in about 70% of cases. US and thin­cut CT also will identify sialoliths but are usually obtained only if abscess is in the differential diagnosis. ED bedside US has been shown to be a useful diagnostic tool to determine number, size, and location of
 stones (Figure 243­2). A conservative course of treatment should precede imaging studies. Occasionally on CT, the diagnosis of sialolithiasis is made by the typically glandular swelling and inflammatory changes (signifying ductal obstruction) without an obvious stone seen in the duct (Figure
243­3).
FIGURE 243­2. US image of sialolithiasis (the bright hemi­circular structure). [Photo contributed by R. Gordon, MD.]
FIGURE 243­3. Marked enlargement of the right submandibular gland. This contrasted CT image shows marked enlargement of the right submandibular gland and surrounding inflammatory changes without an obvious stone or abscess formation. [Image used with permission of John Wightman, MD.]

Treatment is outpatient therapy with analgesics, antibiotics if there is concurrent infection, massage, and sialagogues, such as lemon drops.
Palpable stones in the distal duct may be digitally “milked” from the duct. Complications of salivary duct obstruction include recurrent or persistent
 obstruction, strictures, infection, and gland atrophy.
MASTICATOR SPACE INFECTION
The masticator space consists of four potential spaces bounded by the muscles of mastication (Figure 243­4). These spaces include the masseteric

(or submasseteric), superficial temporal, deep temporal, and pterygomandibular spaces. The spaces are all contiguous. Bacteria may gain entry to the space from dental infections, trauma, surgery, or injections. Infections of the masticator space are polymicrobial and generally anaerobic, although
,33 aerobic oral streptococcal species may predominate briefly. Typical organisms include species of Streptococcus, Peptostreptococcus, Bacteroides,
,33
Prevotella, Porphyromonas, Fusobacterium, Actinomyces, Veillonella, and anaerobic spirochetes.
FIGURE 243­4. Masticator space.
The most frequent acute clinical findings are trismus associated with facial swelling, pain, and erythema. When infection occurs in the masseteric space, there is facial swelling posteriorly and inferiorly, with mild to moderate trismus. If the temporal space is infected, there is soft tissue swelling over the temporalis muscle and trismus. Trismus without swelling suggests pterygomandibular space abscess. In chronic infection, the patient can be
 afebrile but may complain of intermittent trismus. Constitutional signs may include fever, malaise, dehydration, dysphagia, nausea, or vomiting. In more advanced cases, systemic signs of sepsis are present. The differential diagnosis includes other sources of lateral facial pain and swelling (Table
243­4).
Ultrasonography is helpful in differentiating abscesses from cellulitis (Figure 243­1), for the diagnosis of lymphadenitis, and to identify internal jugular
33­35 thrombosis. However, contrast­enhanced CT is the preferred diagnostic tool for masseteric and related deep space infections. CT can define the
 extent of the abscess and distinguish cellulitis from abscess in all spaces except the retropharyngeal. MRI can be considered if infection is thought to
 reach the skull base.
The patient’s condition determines therapy. Because all the subordinate spaces of the masticator space communicate with each other and ultimately with the tissue planes that extend down the neck to the mediastinum, the extent of the infection should be defined efficiently and treatment begun promptly. Airway compromise is rare in unilateral masticator space infection. Administer antibiotics in the ED (Table 243­3), resuscitate for sepsis when present, and admit the patient. IV clindamycin is recommended, with alternatives including ampicillin­sulbactam, piperacillin­tazobactam, or the
,33 combination of penicillin with metronidazole. Antibiotics are continued for  to  days. Consult otolaryngology for surgical intervention and management.
TEMPOROMANDIBULAR JOINT DISORDERS
The temporomandibular joint combines both a hinge and gliding action. The articular surfaces of the joint are separated by the articular disk, or meniscus, which assists in the hinge action between the mandibular condyle and the disk and in the gliding action between the disk and temporal
 bone.
TEMPOROMANDIBULAR JOINT DYSFUNCTION
Temporomandibular joint dysfunction causes pain of the joint and its surrounding anatomic structures. Assess for temporomandibular joint injury
 when evaluating direct jaw trauma or acute dental injury. Most studies have found no significant correlation between occlusal parameters or bruxism
 and signs or symptoms of temporomandibular joint disorders. Over time, degenerative joint disease (osteoarthritis) may result from chronic internal
 derangement or occur secondary to systemic disease such as rheumatoid arthritis or systemic lupus erythematosus.
The chief complaint is usually pain localized to one of the muscles of mastication or pain with chewing in one or both temporomandibular joints. The masseter muscle is the most frequently identified painful area, followed by the temporalis, sternocleidomastoid, splenius capitis, and trapezius
 muscles. Physical findings may include limitation in the range of motion of the mandible. Palpate the muscles of mastication to find areas of sensitivity, induration, rigidity, and swelling. Palpate the condylar heads with the teeth together and then with the teeth apart. The differential diagnosis of temporomandibular joint dysfunction includes jaw trauma, including fracture and dislocation; odontogenic pain, including from abscess, caries, or trauma; otologic referred pain, including from otitis media, otitis externa, and foreign body; and temporal arteritis.
Temporomandibular joint dysfunction is diagnosed by history and physical examination. Isolated temporomandibular joint clicking without pain or
 other dysfunction is not diagnostically sufficient. For acute trauma, the panoramic radiograph view of the mandible (panorex) identifies most
 fractures. CT is appropriate in the assessment of potentially complex fractures, infections, and neoplastic disease. CT is often the imaging modality of choice in the ED as panorex is typically not available.
The oral maxillofacial surgeon manages fractures and should be consulted for trismus, significant mandible displacement, and open fractures. For
 nontraumatic conditions, give simple analgesics, including NSAIDs. Advise the patient to eat soft foods until definitive treatment is provided. The management of chronic temporomandibular dysfunction may ultimately require referral to a dentist, maxillofacial surgeon, or pain specialist.
MANDIBLE DISLOCATION
The mandible can be dislocated in an anterior, posterior, lateral, or superior direction. Anterior dislocation is most common and occurs when the mandibular condyle is forced in front of the articular eminence. Muscular spasm then traps the mandible in anterior dislocation, and the mandible is elevated before retraction. Spasm of the temporalis and lateral pterygoid muscles tends to prevent reduction once dislocation has
 occurred. Dislocations are usually bilateral but can be unilateral. Posterior dislocations are rare. They follow a blow that may or may not break the condylar neck. In posterior dislocation, the mandibular condyle is thrust backward against the mastoid, and the condylar head may prolapse into the
 external auditory canal. Lateral dislocations are often associated with mandibular fracture. With a lateral dislocation, the condylar head is forced laterally and then superiorly into the temporal space. Superior dislocations occur from a blow to the partially open mouth that forces the condylar head upward. Associated injuries include cerebral contusions, facial nerve palsy, and deafness.
Acute jaw dislocation causes severe pain, difficulty in speaking or swallowing, or malocclusion after a blow to the jaw or a seizure or, sometimes, spontaneously. There may be loose or missing teeth and areas of sensory deficit at the chin or mouth. With anterior dislocation, pain is localized anterior to the tragus. Symptoms may develop after extreme mouth opening from laughing, yawning, vomiting, taking a large bite, or trauma, or
 iatrogenically during dental extraction, general anesthesia, and tonsillectomy. With anterior dislocations, the lower jaw is prominent appearing, and there is visible and palpable preauricular depression from the displacement of the mandibular condyle. There also will be difficulty with jaw movement. If the dislocation is unilateral, there is deviation of the jaw away from the dislocation. When a posterior dislocation is considered, examine the external auditory canal. Confirm that hearing is at baseline. With lateral dislocations, the condylar head is palpable in the temporal space, and there are always signs of jaw fracture (e.g., malocclusion). Posterior, lateral, or superior dislocations result from severe trauma.
The differential diagnosis includes mandibular fracture, traumatic hemarthrosis, acute closed locking of the temporomandibular joint meniscus, and
 temporomandibular joint dysfunction.
In the cooperative patient with a spontaneous atraumatic anterior dislocation, the diagnosis is clinical. In other dislocations, including any traumatic dislocation, obtain radiographs. The panoramic view (panorex) or a maxillofacial CT should be obtained for any significant trauma.

Perform reduction in the ED for closed anterior dislocations without fracture. A short­acting IV muscle relaxant (e.g., midazolam) may help to
 decrease muscle spasm. Appropriate airway and hemodynamic monitoring should be initiated. Full procedural sedation may be required.
Alternatively, local anesthetic can be placed into the joint space. Using aseptic technique, place a 21­gauge needle into the preauricular depression just
 anterior to the tragus and inject  mL of 2% lidocaine (Figure 243­5).
FIGURE 243­5. Site for injection of local anesthesia for reduction of dislocated mandible. Place a 21­gauge needle into the preauricular depression just anterior to the tragus and inject  mL of 2% lidocaine.
REDUCTION OF ANTERIOR TEMPOROMANDIBULAR JOINT DISLOCATION
,42,43
Most publications concerning techniques of mandibular joint relocation are descriptive or case reports. A single randomized controlled trial of
 patients found that the wrist pivot method was most successful (96.7% vs. .7% for the conventional method and .7% for the extraoral
 method). In addition, the authors found that the extraoral method was more difficult for the provider and the patient. The three methods are described in the following sections.
Conventional Method
The most commonly used technique requires the patient to be firmly seated with the head against the wall or chair back, positioned so that the examiner’s flexed elbow is at the level of the patient’s mandible. Apply a few layers of gauze (or plastic syringes) over gloved thumbs for protection, in
 case the mandible snaps closed after reduction.
Facing the patient, place gloved thumbs in the patient’s mouth, over the occlusal surfaces of the mandibular molars, as far back as possible. Curve your fingers beneath the angle and body of the mandible. Using the thumbs, apply pressure downward and backward (toward the patient). Slightly opening the jaw may help disengage the condyle from the anterior eminence (Figure 243­6). When the dislocation is bilateral, it may be easier to relocate one side at a time.
FIGURE 243­6. Reduction of dislocated mandible technique in a seated patient. The thumbs are placed over the molars, and pressure is applied downward and backward.
In an alternative version of the conventional method, with the patient recumbent and supine, stand at the head of the bed, place the thumbs on the
 molars, and apply downward and backward pressure (toward the stretcher) (Figure 243­7).
FIGURE 243­7. Alternative mandibular reduction technique, with the examiner behind and above the reclined patient. Place the thumbs on the molars and apply downward and backward pressure (toward the stretcher).
Wrist Pivot Method
The patient sits, as does the operator. The healthcare provider’s thumbs are placed on the mentum, applying upward force, while the fingers apply downward force on the lower molars, forcing the body of the mandible inferiorly (Figure 243­8). The operator flexes the wrist, and thus the mandible rotates, and the condyle goes inferiorly, allowing the condyle to slip back into the mandibular fossa.
FIGURE 243­8. Wrist pivot method for mandibular reduction. The operator’s thumbs are placed on the mentum, applying upward force, while the fingers apply downward force on the lower molars, forcing the body of the mandible inferiorly.
Extraoral Method

The patient should be seated. The provider stands in front of the patient. The provider places their thumb on the patient’s cheek, on the mandibular ramus and coronoid process of the dislocated mandible, and applies persistent pressure posteriorly. The fingers are placed behind the angle of the mandible to stabilize the grip. At the same time on the opposite side, the provider places their fingers from the other hand on the angle of the mandible
 and pulls, applying anterior force. Note that this maneuver causes further anterior dislocation of the ipsilateral temporomandibular joint, rotates the jaw, and facilitates contralateral temporomandibular joint reduction.
Once one side of the dislocation is reduced, the other side usually goes back spontaneously. If that does not work, repeating the same maneuver with minimal force will usually result in reduction. Another consideration is to apply posterior force on both coronoid processes at the same time if the above strategy does not work.
Postreduction Care
After successful reduction, the patient should be able to close his or her mouth immediately. Postreduction radiographs usually are not needed unless the procedure was difficult or traumatic or there is significant postreduction pain. Complications from the reduction itself are unusual, but can include iatrogenic fracture or avulsion of the articular cartilage.
Dislocations that are open, superior, associated with fracture, have any nerve injury, or are irreducible by closed technique should be referred urgently to an otolaryngologist or maxillofacial surgeon.
Following successful reduction of an acute dislocation, patients may be discharged home, placed on a soft diet, and cautioned against opening their
 mouths >2 cm for the following  weeks. Advise patients to support the mandible with a hand when they yawn. Nonsteroidal analgesics may help with discomfort. Elective referral to an oral maxillofacial surgeon is recommended. In severe cases, intermaxillary fixation may be required to control jaw motion during healing. Chronic dislocations may require operative intervention.


