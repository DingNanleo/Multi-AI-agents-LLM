## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 73: Disorders Presenting Primarily With Diarrhea
Nicholas E. Kman; Howard A. Werman; Sarah M. Greenberger
GENERAL ASSESSMENT OF PATIENTS WITH DIARRHEA
INTRODUCTION AND EPIDEMIOLOGY
This chapter discusses the general assessment of patients with diarrhea and the special considerations of acute infectious and traveler’s diarrhea,
Clostridium difficile diarrhea and colitis, inflammatory bowel disease, ileitis and colitis, and ulcerative colitis.
Acute diarrhea is the sudden onset of an increase in the normal water content of stool. In general, humans lose approximately  mL/kg/d of fluids in stool. The increased water content of diarrhea results in an increased frequency of stools from three or more times daily to more than  bowel movements in a 24­hour period. Diarrhea is an increased frequency of defecation, usually greater than three bowel movements per day for a daily stool
 weight exceeding 250 grams. Practically speaking, however, diarrhea is present when the patient is making more stools of lesser consistency more frequently.
PATHOPHYSIOLOGY
There are four basic mechanisms of diarrhea: increased intestinal secretion, decreased intestinal absorption, increased osmotic load, and abnormal intestinal motility. Normally, the jejunum receives between  and  L per day of fluid in the form of oral intake and gastric, pancreatic, and biliary secretions. Dietary intake actually constitutes a small portion of the jejunal load (1.5 L). A healthy small intestine absorbs nearly 75% of the fluid to which it is exposed. The  L of fluid not absorbed by the small intestine then enters the colon, where fluid is absorbed at an even higher rate. The absorptive power of the colon approaches 90% efficiency and far exceeds that of the small intestine. In fact, the colon can make up for a decrease in
 small intestinal absorption. Under normal conditions, very little fluid (<100 mL) is lost in the stool each day.
In diarrheal states, normal intestinal physiology is disrupted. At a cellular level, intestinal absorption occurs through the villi, and secretion occurs through the crypts. Fluids are absorbed by two mechanisms: passively with the transport of sodium and actively with the absorption of glucose.
Selected enterotoxins block the passive sodium resorption and specifically stimulate sodium excretion, resulting in a net loss of fluid. The glucosedependent mechanism of water absorption, however, is unaffected by these toxins and can be exploited by including glucose in the rehydration treatments. The composition of oral rehydration therapies recommended by the World Health Organization is based largely on this physiology. In addition, diarrheal states, enterotoxins, inflammation, or ischemia disrupt the structure of the intestinal villi preferentially with less involvement in the crypts. As a result, diarrhea occurs because of diminished intestinal villi absorption and unopposed crypt secretion (the crypts are more resilient after
 injury).
Another mechanism by which disease processes cause diarrhea is by the delivery of an osmotic load to the intestine. For example, administration of a laxative results in the collection of an osmotically active, nondigestible agent within the intestinal lumen. Other substances such as diet products and medications (e.g., colchicine) have similar effects. Osmosis occurs, drawing fluid into the intestinal lumen, and results in diarrhea. Increased intestinal motility also causes diarrhea. This mechanism is responsible for diarrhea in patients with irritable bowel syndrome, neuropathies, or a shortened intestine secondary to surgery.
Diarrheal illness is primarily a viral infection (norovirus) but can also be caused by bacteria and parasites. Antibiotic and nosocomial diarrhea is most often caused by C. difficile. Many drugs affect gastrointestinal function. Erythromycin accelerates gastric emptying. Clavulanate stimulates small bowel motility. Other drugs that cause diarrhea are laxatives, sorbitol, lactose, nonsteroidal anti­inflammatory drugs, and cholinergics. Inflammatory bowel disease, ulcerative colitis, and Crohn’s disease are characterized by diarrhea. If patients have fecal evidence of inflammation and
Shigella, Salmonella, Campylobacter, C. difficile, or Entamoeba histolytica have been excluded, suspect inflammatory bowel dDioswenalsoea.d Leeds s2 c0o2m5­m7­o1n  c:a5u1s ePs oYfo suerv IePre i sd i1a3rr6h.1e4a 2in.1c5lu9d.1e2 G7I bleeding, thyrotoxicosis, toxin exposure, and mesenteric ischemia, which are addressed eClhseawptheerr 7e 3in: Dthiseo tredxet.rs Presenting Primarily With Diarrhea, Nicholas E. Kman; Howard A. Werman; Sarah M. Greenberger 
. Terms of Use * Privacy Policy * Notice * Accessibility
CLINICAL FEATURES
History
After confirming a diarrheal illness, focus on identifying the cause. Determine whether the diarrhea is acute (<3 weeks) or chronic (>3 weeks). The acute diarrheas are of greatest concern to the emergency physician as they are more apt to be a manifestation of an immediately life­threatening
 illness (infection, ischemia, intoxication, or inflammation). In the United States, most infectious diarrheal illnesses are caused by noroviruses or
 rotaviruses and occur in the winter.
Ask directed questions to characterize the diarrhea: Is the diarrhea bloody or melenic? Is it associated with possible food poisoning or the ingestion of certain foods, such as milk or sorbitol? Does it resolve or persist with fasting? If so, this can indicate an osmotic or secretory diarrhea, respectively. Are the stools of smaller volume, localizing to the large intestine, or of larger volume, indicating small intestine pathology? What symptoms accompany the diarrhea? Is there fever or abdominal pain, which may suggest diverticulitis, infectious gastroenteritis, or inflammatory bowel disease? Seizures accompanying diarrhea often point toward shigellosis but could also indicate theophylline toxicity or hyponatremia. Does the patient have heat intolerance and anxiety, suggesting thyrotoxicosis, or paresthesias and reverse temperature sensation, suggesting ciguatera poisoning?
Next, define the host by obtaining the medical and surgical history. The differential diagnosis for diarrhea is broadened if the patient is immunocompromised. Is the patient taking medication that may cause diarrhea? Has the patient recently traveled outside the United States or to a rural area? Rural hiking places the patient at risk for Giardia, particularly if water­purification procedures were not strictly followed, and travel to developing countries increases the chances of parasitic infection and traveler’s diarrhea. A patient’s occupation may be a clue to a diagnosis of organophosphate poisoning.
Physical Examination
Some examination findings helpful for diagnosis include thyroid enlargement, masses, oral ulcers, erythema nodosum, episcleritis, or an anal fissure, which would point toward inflammatory bowel disease. Reiter’s syndrome, the triad of arthritis, conjunctivitis, and urethritis or cervicitis, should cause concern for Salmonella, Shigella, Campylobacter, or Yersinia infection.
Abdominal and rectal examinations are critical. Especially in the elderly, fecal impaction may result in diarrhea as liquid stool passes around the impaction. Pay attention to the presence or absence of surgical scars, tenderness, masses, or peritoneal signs. Check the stool for blood, because bloody diarrhea can be caused by inflammation, infection, or ischemia. An elderly patient with bloody diarrhea and abdominal pain out of proportion to the physical examination may have mesenteric ischemia—a true emergency.
DIAGNOSTIC STOOL EVALUATION
Diagnostic testing is rarely immediately helpful in the ED, but it can be helpful at patient follow­up. Since most diarrheal illnesses are self­limited, viral, or last less than  hours, most patients who present within  hours of onset need no microbiologic examination. Patients who have severe abdominal pain, fever, and diarrhea that is voluminous, purulent, or bloody may have acute infectious diarrhea associated with the
 following pathogens: Salmonella, Campylobacter, Shigella, Shiga toxin–producing Escherichia coli, Yersinia, Vibrio, or C. difficile.
Patients fitting this subset will require microbiologic evaluation, as described next. In the past, authors have described Wright’s stain for fecal leukocytes and ova and parasite evaluation of the stool. These are not included as they have poor sensitivity and specificity and better tests have emerged.
Bacterial Stool Culture
Bacterial stool culture is expensive and labor intensive and plays a minor role in the ED evaluation of diarrhea. The diagnostic yield of stool cultures is
 probably <5%, unless there is careful patient selection. Obtain stool cultures for bacteria in ill children; toxic, dehydrated, or febrile patients; patients with a diarrheal illness >3 days; patients with blood or pus in the stool; and the immunocompromised. For systemic illness, fever, or bloody stools, test
 for Salmonella, Shigella, Campylobacter, Shiga toxin–producing E. coli, or amoebic infection. Most laboratories are capable of detecting Shigella,
Salmonella, Campylobacter, Shiga toxin–producing E. coli O157:H7 strains, Giardia, Cryptosporidium, E. histolytica, and rotavirus. In patients with
 persistent diarrhea due to a presumed parasitic infection, three separate stool samples should be collected to detect the causative organism.
Clostridium difficile Toxin Assay
C. difficile infection is the most common cause of antibiotic­associated or nosocomial diarrhea. Diagnosis is by the C. difficile toxin assay.
Unfortunately, this assay has a 10% false­negative rate, and the current recommendation is to include other testing such as glutamate dehydrogenase
,10 detection along with nucleic acid amplification testing to confirm the diagnosis.
Other Diagnostic Tests
If diarrhea is not infectious in origin, data acquisition should be dictated by the differential diagnosis. Severely dehydrated patients need serum electrolyte and renal function measurements. Serum drug levels can assist the physician in making the diagnosis of theophylline, lithium, or heavy metal intoxication. In patients with a history of abdominal surgery, abdominal films may help rule out partial obstruction as a cause of diarrhea. A chest radiograph may help diagnose Legionella pneumonia in a patient with diarrhea and a cough. For patients in whom mesenteric ischemia is suspected, obtain a serum lactate, IV contrast CT scan, or mesenteric angiography.
TREATMENT
Severely dehydrated patients need IV hydration. Oral rehydration with a glucose­based electrolyte solution can be initiated in patients without associated nausea or vomiting and without severe dehydration. Glucose­containing, caffeine­free beverages are the fluids of choice. The glucose transport mechanism is unaffected by enterotoxins, allowing for water absorption in the small intestine. For patients who can afford to buy it,
Gatorade® is a good rehydration choice for patients with mild dehydration. The World Health Organization recommends a solution with a higher sodium concentration for more extensive dehydration. Ingestion of 400 to 600 mL/h may be needed to treat dehydration and keep up with stool fluid
 losses in severe diarrhea. Nausea and vomiting should be treated because they may compromise oral rehydration therapy.
Counsel patients to avoid caffeine, which stimulates gastric motility, and sorbitol­containing chewing gum or raw fruits, which can worsen osmotic diarrhea. Initially, avoid lactose until the colonic villi are able to recover and produce the necessary digestive enzymes. Encourage patients to attempt
 early solid food intake, but with the previously mentioned restrictions, because eating expedites the recovery from diarrheal illnesses.
ACUTE INFECTIOUS AND TRAVELER’S DIARRHEA
INTRODUCTION AND EPIDEMIOLOGY
Viruses cause the vast majority of infectious diarrheas, followed by bacterial and parasitic organisms. Norovirus causes 50% to 80% of all infectious diarrhea in the United States, followed with much less frequency by non–Shiga toxin–producing E. coli, C. difficile, invasive bacteria, Shiga
,4 toxin–producing E. coli, and protozoa.
The incidence of traveler’s diarrhea during a 2­week trip remains 10% to 40%, depending on destination and traveler. Improved hygiene and
 awareness have reduced the risk of traveler’s diarrhea in many destinations. The most important risk factor for traveler’s diarrhea is the destination of travel, with the risk increasing with travel to areas of lower socioeconomic status. South Asia and West and Central Africa remain the destinations
 with the highest risk of traveler’s diarrhea. Decreasing rates are being seen in South America and East and Southeast Asia. Other risk factors include the level of food contamination, the season of travel (rainy seasons are associated with a higher risk of traveler’s diarrhea), use of a proton pump inhibitor, previous contraction of traveler’s diarrhea (suggests genetic susceptibility), and the type of travel (adventure travel, camping, backpacking,
 and living with native inhabitants are associated with higher risk). The major bacteria responsible are the toxin­ and non–toxin­producing strains of E.
coli. These strains of E. coli make up most identifiable cases in Mexico and South America. The invasive bacteria, such as Campylobacter jejuni,

Shigella, and Salmonella, are more commonly seen in travelers to southern Asia.
CLINICAL FEATURES

The presence of severe abdominal pain, fever, or bloody stool requires microbiologic studies to rule out bacterial or amoebic infection.
Laboratory Testing
Obtain stool culture for Salmonella, Shigella, Campylobacter, and E. coli O157:H7; assay for Shiga toxin; and microscopy or antigen assay for E.
 histolytica.
Exposure of a traveler or hiker to untreated water and illness that persists for more than  days should prompt evaluations for protozoal pathogens.
Test stool for E. histolytica antigen, Giardiaintestinalis antigen, and Cryptosporidium parvum antigen by enzyme immunoassay. Rarely, helminthes such as Ascaris, Enterobius, and Strongyloides have been implicated.
TREATMENT
Treatment of infectious diarrhea includes antibiotics, antimotility agents, restoration of fluid balance, and avoidance of agents that worsen diarrhea

(Table 73­1). Loperamide and antibiotics improve outcome.
TABLE 73­1
Empiric Treatment of Traveler’s Diarrhea in the Adult
Rehydration
Fluids: chicken broth with fruit juices, Gatorade®, noncaffeinated sodas, packages of salts and glucose to be reconstituted with boiled or treated water,
CeraLyte 90®, Pedialyte®
Foods: complex carbohydrates (bananas, bread, rice, apple juice, and tortillas), potatoes, crackers, Lactobacillus­containing yogurt
Trade Dosage Comments
Name
Antimotility Agents
Bismuth Pepto­  mL or  tablets every  min for  doses; Salicylate toxicity may occur with excessive dosing; may cause bismuth subsalicylate Bismol® repeat on day  encephalopathy in HIV­positive patients.
Loperamide Imodium®  milligrams initially, then  milligrams after Preferred first­line agent for antimotility, with minimal central opiate each unformed stool for no more than  days; effects.
maximum,  milligrams per day Can be used with antibiotics.
Lomotil®  milligrams four times a day for  days Second­line agent with more central opiate effects (narcotic related to
Diphenoxylate meperidine); may potentiate the action of barbiturates, tranquilizers, and atropine and alcohol.
Antibiotics
Cipro® 500 milligrams single dose or 500 milligrams For moderately severe illness in adults; complete 3­day course if single
Ciprofloxacin twice a day for  days dose fails; significant drug–drug interactions may occur. Often first choice for use except in South and Southeast Asia.
Zithromax® 1000 milligrams in a single dose First choice for use in South and Southeast Asia. Safe for children and
Azithromycin pregnant women.
Rifaximin11 Xifaxan®, 200 milligrams PO three times daily for  days For moderately severe illness; do not use for fever or bloody stools;
Salix® class C in pregnancy.
Abbreviation: HIV = human immunodeficiency virus.

Antibiotics shorten the duration of illness by about  hours. Even though most cases of infectious diarrhea are self­limited, because of the inconveniencing and debilitating nature of the disease, we recommend ciprofloxacin treatment for all patients believed to have an infectious diarrhea who do not have a contraindication to the drug (e.g., children, allergy, pregnancy, or drug interaction). There are reports
  of growing fluoroquinolone resistance in bacterial pathogens. Concerns remain about the impact of ciprofloxacin on the intestinal flora and its side
 effect profile, and other non–GI­absorbed agents such as rifaximin are an option. (See Table 73­2 for specific treatments.)
TABLE 73­2
Antimicrobial Recommendations for Infectious Pathogens in Adults
Organism Primary Treatment Alternative Treatment
Empiric treatment—but not for Ciprofloxacin 500 milligrams PO twice a day for  days Trimethoprim­sulfamethoxazole DS,  tab PO twice a bloody diarrhea; not for Shiga day for  days toxin E. coli 0157:H7
C. difficile Vancomycin 125 milligrams PO  times a day for  days Fidaxomicin, 200 milligrams PO two times a day for  days
E. coli 0157:H7 No antibiotics No antibiotics
Listeria monocytogenes No antibiotics No antibiotics
Yersinia No antibiotics; usually self­limited Ciprofloxacin 500 milligrams PO twice a day for  days; or trimethoprim­sulfamethoxazole DS,  tab PO twice a day for  days
Salmonella non­typhi Ciprofloxacin 750 milligrams PO twice a day for  days Azithromycin 500 milligrams PO once a day for  days
Shigella Ciprofloxacin 750 milligrams PO twice a day for  days Azithromycin 500 milligrams PO once a day for  days
V. cholerae Doxycycline 500 milligrams PO for one dose Trimethoprim­sulfamethoxazole DS,  tab PO twice a
OR day for  days
Azithromycin  gram PO for one dose
E. histolytica Metronidazole 750 milligrams PO three times a day for  Metronidazole AND iodoquinol 650 milligrams PO days AND paromomycin  milligrams/kg three times a three times a day for  days day PO for  days OR
Tinidazole  grams PO once a day for  days AND paromomycin or iodoquinol
Cyclospora Trimethoprim­sulfamethoxazole DS,  tab PO twice a day for  days
Giardia Tinidazole  grams PO for one dose Nitazoxanide 500 milligrams PO twice a day for  days
OR
Metronidazole 750 milligrams PO three times a day for
 days
OR
Paromomycin  milligrams/kg/d PO three times a day for  days
Note: Length of treatment often varies with different sources.
Loperamide shortens the duration of symptoms when combined with an antibiotic regimen. Loperamide, bismuth subsalicylate, and kaolin are the only agents that are labeled as antidiarrheals. Do not use antimotility agents in the subset of patients with bloody diarrhea or suspected inflammatory diarrhea because of the possibility of prolonged fever, toxic megacolon in C. difficile patients, and hemolytic uremic syndrome in
 children infected with Shiga toxin–producing E. coli.

Probiotics are safe and beneficial when used alongside rehydration therapy. Proton pump inhibitors are not effective.
DISPOSITION
Admit the toxic patient and any patient who cannot comply with oral rehydration. Be conservative in admitting those at extremes of age. Most patients with diarrhea can be discharged home.
The best way to combat many infectious diarrheas is with prevention. Counsel families about frequent hand washing to minimize spread of disease and about the proper selection and preparation of food and beverages consumed while traveling as a cornerstone of prevention. Encourage the use of boiled, bottled, and carbonated water for drinking, brushing teeth, and preparing food and infant formula. Water can be made safe by boiling, treating
 it chemically, or filtering. A quick phrase for prevention is, “Peel it, boil it, cook it, or forget it!”

In addition, vaccines against the most common etiologic agent, rotavirus, are now available.
Provide work excuses for patients employed in the food, day­care, and healthcare industries.
CLOSTRIDIUM DIFFICILE–ASSOCIATED DIARRHEA AND COLITIS
INTRODUCTION AND EPIDEMIOLOGY
C. difficile is a spore­forming obligate anaerobic bacillus that causes infection ranging from mild diarrhea to severe pseudomembranous colitis. The
 frequency of C. difficile infection increased from .5 cases per 1000 discharges in 2001 to .2 in 2010, with a mortality rate of approximately 7%.
Although many cases are found among hospitalized adults, up to one third of cases occur in the community. A more virulent strain of C. difficile called
B1/NAP1/027 causes more severe disease that often progresses to toxic megacolon.
The organism secretes two toxins, A and B, that cause a secretory diarrhea. At the most severe end of the spectrum, three different syndromes have been described: neonatal pseudomembranous enterocolitis, postoperative pseudomembranous enterocolitis, and antibiotic­associated pseudomembranous colitis. In pseudomembranous colitis, membrane­like yellowish exudative plaques overlie and replace necrotic intestinal mucosa. A pseudomembrane is present in only 50% of laboratory­confirmed cases of C. difficile colitis. Recent antibiotic use, GI surgery or manipulation, severe underlying medical illness, chemotherapy, gastric acid suppression with proton pump inhibitors or H blockers, and advancing
 age are risk factors for pseudomembranous colitis. Transmission of the organism is by direct human contact as well as contact with inanimate objects
(commodes, telephones, rectal thermometers).
PATHOPHYSIOLOGY
Hospitalized patients are colonized with C. difficile in 20% to 50% of cases, so the development of diarrhea in recently discharged patients is suggestive of C. difficile infection. There is a linear relationship between the length of hospital stay, colonization with C. difficile, and the development of C.
difficile diarrhea. Up to 70% of residents of long­term health facilities are C. difficile carriers. Broad­spectrum antibiotics reduce fecal anaerobes, which are needed for carbohydrate metabolism and bile acid breakdown. One study ranked cephalosporins, clindamycin, carbapenems,
 trimethoprim/sulfonamides, fluoroquinolones, and penicillin combinations as the most frequent offenders. Accumulation of gut carbohydrates can cause osmotic diarrhea, and the accumulation of bile acids, which are colonic secretory agents, also results in diarrhea. Toxin­producing C. difficile then flourishes within the colon. Almost any antibiotic (including metronidazole and vancomycin) can lead to pseudomembranous colitis, and chemotherapeutic agents, proton pump inhibitors, and antiviral agents have also been implicated. Bowel ischemia, inflammatory bowel disease, recent bowel surgery, uremia, malnutrition, shock, advanced age, peripartum status, and Hirschsprung’s disease also contribute to the development of C. difficile infection and pseudomembranous colitis. Probiotics have been implicated in reducing the incidence of C. difficile infection if taken concomitantly with antibiotics but have no role in treating active or recurrent disease.
Most disease­producing strains of C. difficile produce two toxins—toxin A, an enterotoxin, and toxin B, a cytotoxin—that interact in a complex way to produce pseudomembranous colitis and its associated symptoms. B1/NAP1/027 produces a third (binary) toxin, contributing to its more virulent course.
CLINICAL FEATURES
The disease typically begins  to  days after the institution of antibiotic therapy, although symptoms may occur up to  days after the antibiotic is discontinued.C.difficile colitis results in a spectrum of clinical manifestations that vary from frequent, mucoid, watery stools to a toxic picture that includes profuse diarrhea (20 to  stools per day), crampy abdominal pain, fever, leukocytosis, and dehydration. Stool examination may demonstrate fecal leukocytes, which are not generally found in more benign forms of antibiotic­induced diarrhea. In 3% of patients, toxic megacolon or colonic perforation may occur in patients with pseudomembranous colitis.
DIAGNOSIS
The diagnosis is suggested by a history of diarrhea that develops during administration of antibiotics or within  weeks of their discontinuation. The patient should experience a minimum of three unformed stools in a 24­hour period to be considered as having an active infection.
Stool Assays
Cell culture cytotoxicity assays remain the “gold standard” but take up to  hours for results. The organism is best identified by stool culture using a selective growth medium. This technique has a sensitivity approaching 100% but lacks specificity because the presence of C. difficile does not necessarily implicate it in the cause of the disease.
Instead, C. difficile toxins are detected directly using a number of techniques including enzyme­linked immunosorbent assays, latex agglutination, dotimmunobinding assays, and polymerase chain reaction. Tests vary in their sensitivity, specificity, and time to completion. Many laboratories are using
 polymerase chain reaction technology, which has excellent sensitivity (71% to 100%) and specificity (73% to 100%) and rapid test turnaround, usually
  within  hour. As noted, confirmatory testing should be included in establishing the diagnosis.
Colonoscopy
Colonoscopy reveals characteristic yellowish plaques within the intestinal lumen. Lesions may be seen throughout the entire alimentary tract, although they are typically limited to the right colon. Colonoscopy is not routinely needed to establish a diagnosis and carries the risk of perforation in severe colitis but may be used in patients who require a rapid diagnosis and those who cannot produce a stool specimen due to ileus or in whom the initial assay is negative.
TREATMENT
Mild C. difficile infection in an otherwise healthy patient is treated by discontinuing the offending antibiotic. This is effective in only about 20% of cases, however. Severely ill persons must be hospitalized. For specific antibiotic regimens, see Table 73­3. Fidaxomicin (macrolide antibiotic) 200 milligrams

PO twice a day for  days has replaced metronidazole as a primary agent.
TABLE 73­3
Treatment of Clostridium difficile Infection Based on Severity of Illness5
Disease
Treatment
Severity
Asymptomatic No treatment carrier
Initial episode Discontinue inciting antibiotics
Mild: WBC Vancomycin 125 milligrams PO four times a day for  days
<15,000 mm3
Moderate: WBC Fidaxomicin 200 milligrams PO twice daily for  days
>15,000 mm3, patient able to tolerate PO
First relapse Fidaxomicin 200 milligrams twice daily for  days if vancomycin was used for the initial episode OR tapered and pulsed vancomycin regimen if a standard regimen was used for the initial episode (e.g., 125 milligrams four times per day for 10–14 days, two times per day for a week, once per day for a week, and then every  or  days for 2–8 weeks)
Second relapse Tapered and pulsed vancomycin regimen of 125 milligrams four times per day for 10–14 days, two times per day for a week, once per day for a week, and then every  or  days for 2–8 weeks OR vancomycin 125 milligrams four times per day by mouth for  days followed by rifaximin 400 milligrams three times daily for  days OR fidaxomicin 200 milligrams given twice daily for  days
Severe disease or Vancomycin 500 milligrams IV or via nasogastric tube every  hours AND vancomycin 500 milligrams per rectum every  hours; also, complicated metronidazole 500 milligrams IV every  hours or fecal microbiota transfer disease
Note: Assume the offending antibiotic is discontinued.
Source: Data from McDonald LC, Gerding DN, Johnson S, et al: Clinical Practice Guidelines for Clostridium difficile Infection in Adults and Children: 2017 Update by the Infectious Diseases Society of America (IDSA) and Society for Healthcare Epidemiology of America (SHEA), Clin Infect Dis 2018 Mar ;66(7):987­994. Rarely, emergency colectomy may be required for patients with severe C. difficile infection. Indications for emergency colectomy based on 30­day
 mortality include leukocytosis >20,000 mm , lactate >5 mmol/L, age >75 years, immunosuppression, shock, toxic megacolon, colonic perforation, rapidly progressive disease, or multiorgan system failure. This procedure carries a high mortality rate. Recently, creation of a loop ileostomy with colonic lavage has been reported to be an effective surgical approach.
Relapses occur in 20% to 30% of patients. Patients with prolonged antibiotic use, prolonged hospitalization, advanced age, diverticulosis, or multiple
 comorbidities are at increased risk for relapse. The addition of monoclonal antibodies against the toxin to antibiotics reduces infection recurrence.
The use of antidiarrheal agents is contraindicated. Steroids are rarely needed. Finally, fecal microbiota transfer has emerged as a therapy for
 refractory cases of recurrence.
Ensure contact isolation, use of personal protective equipment, and good hand washing with soap and water when caring for patients with suspected
C. difficile–associated disease. Alcohol­based rubs are not effective in eliminating the spores of C. difficile.
DISPOSITION
Hospitalize patients with severe diarrhea, clinical toxicity, or symptoms that persist despite appropriate outpatient management. Consult the surgeon for acutely ill patients with C. difficile infection, especially those with suspected toxic megacolon or intestinal perforation for consideration of colectomy. For patients who are discharged, discontinue antibiotics and encourage good oral hydration. Follow the antibiotic recommendations in
Table 73­3. INFLAMMATORY BOWEL DISEASE/ILEITIS/COLITIS/CROHN’S DISEASE
INTRODUCTION AND EPIDEMIOLOGY
Crohn’s disease is a chronic granulomatous inflammatory disease of the GI tract of unknown origin, but genetic and environmental factors have been implicated in causing the disease. Crohn’s disease can involve any part of the GI tract from the mouth to the anus. The ileum is involved in the majority of cases. In 20%, the disease is confined to the colon, making differentiation from ulcerative colitis difficult. The terms regional enteritis, terminal ileitis, granulomatous ileocolitis, and Crohn’s disease are all used to describe the same disease process.
The peak incidence of Crohn’s disease occurs between  and  years of age, with a secondary peak from  to  years. The incidence has remained steady in the past several years. The disease is four times more common among Jews than non­Jews and is more common in whites than blacks,
Asians, or Native Americans. A family history of inflammatory bowel disease is present in 10% to 15% of patients, particularly with early onset of disease. Ulcerative colitis as well as Crohn’s disease may be present in other family members, and siblings of patients with Crohn’s disease have a higher incidence of the disease. Smoking, oral contraceptive use, and the use of nonsteroidal anti­inflammatory agents worsen the course of the disease. Smoking is also associated with a two­fold increased risk of developing Crohn’s disease.
PATHOPHYSIOLOGY
The most important pathologic feature of Crohn’s disease is the involvement of all the layers of the bowel and extension into mesenteric lymph nodes.
The disease is discontinuous, with normal areas of bowel (“skip areas”) located between one or more involved areas. Longitudinal, deep mucosal ulcerations are characteristic. If ulcerations penetrate the bowel wall, fissures, fistulas, and abscesses result. Late in the disease, a cobblestone appearance of the mucosa results from the criss­crossing of ulcers with intervening normal mucosa.
CLINICAL FEATURES
Patients presenting to the ED do so because of chronic symptoms such as abdominal pain and weight loss that remain undiagnosed, acute flares in patients with known disease, and most commonly, complications of Crohn’s disease. Occasionally, side effects and complications of therapy bring the patient to the ED.
The clinical course of Crohn’s disease varies and in the individual patient is unpredictable. There are three general types of Crohn’s presentations: inflammatory, stricturing, and penetrating disease. The disease is classified as mild, moderate, and severe based on the Clinical Disease Activity

Index. Abdominal pain, anorexia, diarrhea, and weight loss are present in most cases. Chronic abdominal pain, weight loss, fever, and diarrhea may be present for several years before definitive diagnosis is established. Perianal fissures or fistulas, hematochezia, abscesses, or rectal prolapse can develop, particularly with colonic involvement. Patients may also present with complications of the disease, such as obstruction with vomiting, crampy abdominal pain, and obstipation, or an intra­abdominal abscess with fever, abdominal pain, and a palpable mass. In children with Crohn’s disease and ulcerative colitis, growth retardation and delay in the onset of puberty are prominent.
In 10% to 20% of patients, the extraintestinal manifestations of arthritis, uveitis, or liver disease may be presenting symptoms. Crohn’s disease should also be considered in the differential diagnosis of patients with fever of unknown etiology. The incidence of stroke, ischemic heart disease, chronic obstructive pulmonary disease, and thromboembolic disease is increased in patients with inflammatory bowel disease and should be considered
 when such patients present to the ED.
The clinical course and manifestations of the disease appear to be related to its anatomic distribution: in 30%, the disease involves only the small bowel; in 20%, only the colon is involved; and in 50%, both the small bowel and colon are involved. A small percentage of patients present with disease involving the mouth, esophagus, and stomach. Crohn’s disease of the stomach may cause symptoms of dyspepsia.
Extraintestinal manifestations are seen in up to 50% of patients with Crohn’s disease (Table 73­4), The types of extraintestinal complications are similar in patients with Crohn’s disease and ulcerative colitis, although they are most commonly seen in Crohn’s disease patients with colonic involvement.
TABLE 73­4
Common Extraintestinal Manifestations of Inflammatory Bowel Disease
Manifestation Description
Arthritic
Peripheral arthritis Migratory monoarticular or polyarticular pain in peripheral joints (hip, knee, ankle, wrist) with effusion
Ankylosing Pain and stiffness of spine, hips, neck, and rib cage with limitation in truncal motion, loss of lumbar lordosis; decreased chest spondylitis expansion and forward cervical flexion in advanced disease
Sacroiliitis Low back pain with morning stiffness, relieved by exercise; progressive joint sclerosis
Ocular
Episcleritis Eye burning or itching without visual changes or pain; scleral and conjunctival hyperemia
Uveitis Acute blurring of vision, photophobia and pain; perilimbic scleral injection
Dermatologic
Erythema nodosum Painful, red, raised nodules on extensor surfaces of arms or legs
Pyoderma Ulcerative lesions with a necrotic center and violaceous skin typically found in pretibial region or trunk gangrenosum
Hepatobiliary
Cholelithiasis Varies from asymptomatic stones to right upper quadrant pain, fever, vomiting
Fatty liver Mild right upper quadrant pain; hepatomegaly
Pericholangitis Mild elevation in serum alkaline phosphatase, asymptomatic
Chronic active Autoimmune elevation of liver aminotransferase enzymes, may progress to cirrhosis hepatitis
Primary sclerosing Pruritus progressing to jaundice, fatigue, and lethargy; laboratory findings vary from mild elevations of alkaline phosphatase to cholangitis cirrhosis, portal hypertension, and liver failure; male predominance
Cholangiocarcinoma Extrahepatic biliary mass, evidence of biliary obstruction, jaundice, right upper quadrant pain, fever, malaise
Pancreatitis Varies from painless elevation of serum amylase to clinically apparent central abdominal pain radiating to back; may be associated with drugs such as azathioprine, 6­mercaptopurine, sulfasalazine, mesalamine, olsalazine, metronidazole
Vascular
Thromboembolic Symptoms of deep venous thrombosis and pulmonary emboli; portal vein, mesenteric vein, and hepatic venous thrombosis disease reported
Other
Malnutrition Fatigue, malaise, muscular wasting, cachexia
Chronic anemia Fatigue, malaise, pallor, dyspnea; may be microcytic (blood loss), macrocytic (B deficiency), or autoimmune hemolytic

Nephrolithiasis Flank pain, nausea, vomiting, hematuria; stones result from increased dietary oxalate absorption (calcium oxalate stones) and dehydration (urate stones)
DIAGNOSIS
In most patients, the definitive diagnosis of Crohn’s disease is established months or years after symptom onset. A provisional diagnosis of appendicitis or pelvic inflammatory disease may change to Crohn’s disease after imaging or at the time of surgery. A detailed history asking about previous bowel symptoms that preceded the onset of acute right lower quadrant pain provides clues to the correct diagnosis.
ED evaluation focuses on determining the severity of the attack; identifying significant complications such as obstruction, intra­abdominal abscess, life­threatening hemorrhage, or toxic megacolon; and eliminating other possible causes of the patient’s complaints.
Laboratory Testing
Laboratory evaluation should include a CBC, serum electrolytes, BUN, creatinine, and a type and cross­match where appropriate. C­reactive protein levels and erythrocyte sedimentation rate can be obtained to monitor disease activity. Other studies should include electrolytes, calcium, and liver
 function studies. Fecal markers of inflammation (calprotectin and lactoferrin) are other markers of disease activity. Anemia is common in Crohn’s disease and may be caused by iron deficiency, chronic disease, and vitamin B deficiency. Stool cultures and C. difficile toxin can be obtained if
 diarrhea is a prominent symptom.
Imaging
Plain radiographs have essentially been replaced by abdominal and pelvic CT scanning with PO and IV contrast, which can identify bowel wall thickening, segmental narrowing, destruction of the normal mucosal pattern, mesenteric edema, fistulas, and abscesses, suggestive of Crohn’s disease. However, be vigilant about the cumulative radiation risk (severe exposure defined as lifetime accumulation of >50 mSv) in patients with inflammatory bowel disease. MRI has similar diagnostic accuracy as CT. MRI is more expensive and has limited availability but involves less radiation exposure and avoids the use of iodinated contrast. Additionally, pelvic MRI is the best modality for imaging perianal fistulae. Ultrasound can be used to identify bowel wall thickening in the small intestine and portions of the large bowel. It is the diagnostic modality of choice for biliary complications.
Extraintestinal complications such as gallstones, renal calculi, sacroiliitis, and osteomyelitis can also be seen on CT scan. Diagnosis is confirmed by colonoscopy.
Differential Diagnosis
The differential diagnosis of Crohn’s disease includes lymphoma, ileocecal amebiasis, sarcoidosis, deep chronic mycotic infections involving the GI tract, GI tuberculosis, Kaposi’s sarcoma, Campylobacter enteritis, and Yersinia ileocolitis. Fortunately, most of these are uncommon conditions and can be differentiated by appropriate laboratory tests and imaging. Yersinia ileocolitis and Campylobacter enteritis may cause chronic abdominal pain and diarrhea similar to Crohn’s disease but can be diagnosed by appropriate stool cultures. It is not uncommon that a bout of acute bacterial diarrhea may uncover a diagnosis of inflammatory bowel disease. Acute ileitis should not be confused with Crohn’s disease. Young patients with acute ileitis usually recover without sequelae and should not undergo surgery. When Crohn’s disease is confined to the colon, ischemic bowel disease (particularly in the elderly) and pseudomembranous colitis as well as ulcerative colitis must be included in the differential diagnosis. Concomitant infection with C.
difficile colitis is more common in patients with inflammatory bowel disease and is associated with refractory C. difficile infection and a greater incidence of surgery and disease flares in these patients. Some clinical guidelines call for C. difficile testing in any inflammatory bowel disease patient
 with a disease flare.
TREATMENT
The aim of therapy for this incurable disease includes relief of symptoms, induction of remission, maintenance of remission, prevention of complications, optimizing timing of surgery, and maintenance of nutrition.
Initial treatment (Table 73­5) consists of adequate fluid resuscitation and restoration of electrolyte balance. Place a nasogastric tube for obstruction, peritonitis, or toxic megacolon. Administer broad­spectrum antibiotics for fulminant colitis or peritonitis. Patients with severe disease should receive
IV steroids such as hydrocortisone 300 milligrams per day or an equivalent dose of methylprednisolone (48 milligrams per day) or prednisolone (60 milligrams per day).
TABLE 73­5
Treatment of Fulminant Colitis
Restore fluid and electrolyte balance
Nothing by mouth
Nasogastric suction for
Obstruction
Adynamic ileus
Suspected toxic megacolon
Parenteral corticosteroids
Hydrocortisone 300 milligrams per day or methylprednisolone  milligrams per day or prednisolone  milligrams per day
Broad­spectrum antibiotics
Piperacillin­tazobactam .5 grams IV four times a day OR
Ampicillin  grams IV four times a day + metronidazole 500 milligrams IV three times a day + ciprofloxacin (Cipro®) 750 milligrams IV once a day
Observe for complications
Obstruction
Perforation
Toxic megacolon
Life­threatening hemorrhage
Intra­abdominal abscess
Outpatient management (nontoxic patients)
Liquids only for first  h
Oral antibiotics
Ampicillin, trimethoprim­sulfamethoxazole, ciprofloxacin, cephalexin, or rifaximin
AND
Metronidazole or clindamycin
Salicylates
Sulfasalazine  to  grams per day is for mild to moderate Crohn’s disease. Sulfapyridine is a by­product of the colonic breakdown of sulfasalazine.
Many of the toxic side effects of sulfasalazine (e.g., vomiting, anorexia, nausea, headache, diarrhea, epigastric distress, pancreatitis) are attributable to sulfapyridine.
The active moiety in sulfasalazine is mesalamine. Many of the newer 5′­acetyl salicylic acid drugs feature a derivative of mesalamine without the sulfapyridine component. Oral mesalamine, rectal mesalamine, olsalazine, and balsalazide are first­line agents in treating Crohn’s disease. The mesalamine formulations are most effective in patients with colonic disease and particularly in those with mild disease.
Corticosteroids
Oral glucocorticoids such as prednisone (40 to  milligrams per day) have traditionally been reserved for more severely affected patients but are now used as induction therapy. An ileal­released form of budesonide (9 milligrams per day) may be beneficial in inducing a remission in patients with ileal and right colon disease. Glucocorticoids are not preferred for maintaining remission because of their complications, but 50% of patients may ultimately be steroid dependent.
Immunosuppressives
Immunosuppressive drugs such as 6­mercaptopurine, azathioprine, and thioguanine are useful in maintenance, as steroid­sparing agents, in healing
 fistulas, and in patients in whom there are serious contraindications to surgery. These agents have been associated with leukopenia, fever, hepatitis, and pancreatitis, necessitating the need for close follow­up, particularly during the initial phase of therapy. Parenteral methotrexate (25 milligrams per week) is considered third line and has been used following steroid and thiopurine metabolite failure.
Antibiotics
Antibiotics are first­line agents for perianal disease and help induce remission. Ciprofloxacin (500 to 1000 milligrams per day) induces remission in approximately 55% of cases. Metronidazole (750 to 1500 milligrams per day) is also effective for perianal complications and fistulous disease.
Combination therapies with antibiotics and biologic agents (see next section) have produced dramatic improvements in response. Rifaximin is a broad­spectrum antibiotic that is not absorbed from the GI tract. Rifaximin 800 milligrams twice daily for  weeks is effective for mild to moderate disease. However, antibiotics raise concerns about precipitating C. difficile colitis infection.
Biologics
Patients with medically resistant moderate to severe Crohn’s disease may benefit from the anti–tumor necrosis factor antibodies infliximab, adalimumab, and certolizumab pegol. These agents have been used to induce remission in patients who fail conventional therapy with steroids or 5­ aminosalicylic acid and in patients with exclusively colonic disease. Additionally, biologics are particularly effective in cases of disease relapse and
 fistulizing disease. Anti­adhesion therapies, natalizumab and vedolizumab, and the anti­interleukin agent ustekinumab have been used when anti–
,26,27 tumor necrosis factor agents fail. All biologics increase the risk of infections, especially those caused by hepatitis B and tuberculosis. Both immediate and delayed hypersensitivity reactions are possible, especially with infliximab. Concern about the emergence of lymphomas and progressive multifocal leukoencephalopathy, especially with natalizumab, has limited the long­term use of these agents.
Maintenance therapy and the effectiveness of various therapeutic agents in Crohn’s disease are variable. A reduced dose of 5­aminosalicyclic acid derivatives is used for the maintenance of remission of colonic disease. The addition of sulfasalazine, azathioprine, and 6­mercaptopurine to prednisone does not improve the response rate and increases side effects. Infliximab or adalimumab and an immunosuppressive (azathioprine, 6­ mercaptopurine, or methotrexate) can maintain remission.
Antidiarrheal Agents
Diarrhea can be controlled by loperamide (Imodium®)  to  milligrams per day, diphenoxylate (Lomotil®)  to  milligrams per day, and in some cases, cholestyramine (Questran®)  grams one to six times a day. The mechanism of action of cholestyramine is binding bile acids and eliminating their known cathartic action.
DISEASE COMPLICATIONS
More than three out of four patients with Crohn’s disease will require surgery within the first  years of the onset of initial symptoms. Abscess and fissure formation is common. Abscesses can be characterized as intraperitoneal, visceral, retroperitoneal, interloop, or intramesenteric. Signs and symptoms are worsening abdominal pain and tenderness, fever, and possibly a palpable mass. Retroperitoneal abscesses may cause hip or back pain and difficulty ambulating.
Fistulas are the result of extension of the intestinal fissures seen in Crohn’s disease into adjacent structures. The most common sites are between the ileum and the sigmoid colon, the cecum, another ileal segment, urinary bladder, vagina, or the skin. Suspect an internal fistula when there are changes in the patient’s symptom complex, such as bowel movement frequency, amount of pain, or weight loss.
Obstruction is the result of both stricture formation due to the inflammatory process and of edema of the bowel wall. It is the most common reason for emergent surgery in Crohn’s disease. The distal small bowel is the most common site of obstruction. Symptoms include crampy abdominal pain, distention, nausea, and bloating.
Perianal complications include perianal or ischiorectal abscesses, fissures, fistulas, rectovaginal fistulas, and rectal prolapse. Perianal fistulas occur in 20% to 30% of Crohn’s patients. These are more commonly seen in patients with colonic involvement.
Major GI bleeding is rare. Bleeding results from erosion into a vessel in the bowel wall. Toxic megacolon is also uncommon but is associated with massive GI bleeding in over half the cases.
When bowel symptoms are present, malnutrition, malabsorption, hypocalcemia, and vitamin deficiency can be severe. In addition to the complications of the disease are complications associated with the treatment of the disease with mesalamine, steroids, immunosuppressive agents, and antibiotics.
These include leukopenia, thrombocytopenia, fever, infection, profuse diarrhea, pancreatitis, renal insufficiency, and liver toxicity.
The incidence of malignant neoplasm of the GI tract is three times higher in patients with Crohn’s disease than for the general population, especially in patients with disease involvement of more than one third of their colon.
DISPOSITION
Patients with colitis, peritonitis, or complications such as obstruction, significant GI hemorrhage, severe dehydration, or fluid/electrolyte imbalance should be hospitalized. Hospital admission should be considered in less severe cases that cannot be managed successfully with outpatient management. Surgical intervention is indicated in patients with complications of the disease, including intestinal obstruction or hemorrhage, perforation, abscess or fistula formation, toxic megacolon, and perianal disease.
Before discharging patients with Crohn’s disease, discuss alterations in the therapeutic regimen with the gastroenterologist. Ensure close follow­up after discharge.
ULCERATIVE COLITIS
INTRODUCTION AND EPIDEMIOLOGY
Ulcerative colitis is a chronic inflammatory disease of the colon. The inflammation tends to be progressively more severe from the proximal to the distal colon. The rectum is involved nearly 100% of the time. The characteristic symptom is bloody diarrhea. The cause is unknown.
The disease is more prevalent in the United States and northern Europe than in other parts of the world, and peak incidence occurs in the second and third decades of life. It is more common in men. First­degree relatives of patients with ulcerative colitis have a 15­fold risk of developing ulcerative colitis and a .5­fold risk of developing Crohn’s disease.
PATHOPHYSIOLOGY
Ulcerative colitis involves primarily the mucosa and submucosa. Microscopically, the disease is characterized by mucosal inflammation with the formation of crypt abscesses, epithelial necrosis, and mucosal ulceration. The submucosa, muscular layer, and serosa are usually spared. In the usual case, the disease increases in severity more distally, with the rectosigmoid being involved in the vast majority of cases. In the early stages of the disease, the mucous membranes appear finely granular and friable. In more severe cases, the mucosa appears as a red, spongy surface dotted with small ulcerations oozing blood and purulent exudate. In very advanced disease, one sees large oozing ulcerations and pseudopolyps (areas of hyperplastic overgrowth surrounded by inflamed mucosa).
CLINICAL FEATURES
The clinical features and course of ulcerative colitis vary and depend on the anatomic distribution of the disease in the colon. Crampy abdominal pain, bloody diarrhea, and tenesmus are typical symptoms. The disease is classified as mild, moderate, or severe depending on the clinical manifestations.
Of all patients with ulcerative colitis, 60% have mild disease; in 80% of cases, the disease is limited to the rectum. Occasionally, constipation and rectal bleeding are the presenting complaints. Progression to pancolitis occurs in 10% to 15% of patients with mild disease.
Moderate disease is seen in 25% of patients. Patients demonstrate a good response to therapy. These patients usually have colitis extending to the splenic flexure (left­sided colitis) but may develop pancolitis.
Patients with severe disease constitute 15% of those with ulcerative colitis and are most likely to be seen in the ED. Severe disease is associated with greater than six bowel movements per day, tachycardia, fever (>37.8°C), anemia (hemoglobin <10.5 milligrams/dL), an elevated erythrocyte sedimentation rate, low serum albumin, and more frequent extraintestinal manifestations. Patients with severe disease account for 90% of deaths from ulcerative colitis. Virtually all severely affected patients have pancolitis.
Ulcerative colitis is usually characterized by intermittent attacks of acute disease with complete remission between attacks. Sometimes, the first attack is followed by a prolonged period of inactivity, or the disease is chronically active. The factors associated with an unfavorable prognosis and increased mortality include higher severity and extent of disease, a short interval between attacks, systemic symptoms, and onset of the disease after  years of age.
Extraintestinal complications are listed in Table 73­4. Peripheral and axial arthritis and skin lesions including erythema nodosum and pyoderma gangrenosum are the most common extraintestinal complications.
DIAGNOSIS
Laboratory findings in patients with ulcerative colitis are nonspecific and may include leukocytosis, anemia, thrombocytosis, decreased serum albumin, and abnormal liver function studies. There are many biomarkers, such as antineutrophil cytoplasmic antibodies, for diagnosis and prognosis, but none are available in the ED. These serologic markers also lack sensitivity. Therefore, the diagnosis of ulcerative colitis rests on the following: a history of abdominal cramps and diarrhea, mucoid stools, stool examination negative for ova and parasites, stool cultures negative for enteric pathogens, and confirmation of diagnosis by colonoscopy.
Differential Diagnosis
The major diseases that should be considered in the differential diagnosis of ulcerative colitis include infectious colitis, Crohn’s colitis, ischemic colitis, radiation colitis, toxic colitis from antineoplastic agents, and C. difficile infection. When the disease is limited to the rectum, consider rectal syphilis, gonococcal proctitis, lymphogranuloma venereum, and inflammations caused by herpes simplex virus, E. histolytica, Shigella, and Campylobacter.
TREATMENT
Patients with severe ulcerative colitis should be treated with IV steroids, replacement of fluids, correction of electrolyte abnormalities, broad­spectrum antibiotics (ciprofloxacin, metronidazole, and ampicillin), mesalamine, and steroids (Table 73­5). IV cyclosporine (4 milligrams/kg per day) or infliximab (5 to  milligrams/kg per dose) can be effective in fulminant colitis nonresponsive to IV corticosteroids. Triple­antibiotic therapy has been
 used for pediatric patients with severe ulcerative colitis.
When toxic megacolon is suspected, place a nasogastric tube and obtain imaging and surgical consultation.
The majority of those with mild and moderate disease can be treated as outpatients. In the treatment of patients with mild active proctitis, proctosigmoiditis, and left­sided colitis (<60 cm of active disease), topical treatment with mesalamine suppositories or enemas is effective. Topical glucocorticoid enemas or 5­aminosalicylic enemas (Rowasa®,  to  grams/60 mL per day for  weeks) or suppositories (500 milligrams twice a day) are quite effective in inducing remission in mild to moderate attacks of distal proctosigmoiditis and have lower systemic side effect profiles. If topical therapy is unsuccessful, oral glucocorticoids are effective in inducing a remission in the majority of cases. Daily doses of  to  milligrams of prednisone are usually sufficient and can be adjusted depending on the severity of the disease.
Infliximab (5 milligrams/kg per dose) is the only biologic indicated for ulcerative colitis. It should be used in patients with mild to moderate disease who
 are corticosteroid dependent or refractory and in patients who have immunomodulator refractory disease.
Hydrophilic bulk agents such as psyllium (Metamucil®) can be used in some patients to improve stool consistency. Antidiarrheal agents are generally ineffective and may precipitate toxic megacolon.
DISEASE COMPLICATIONS
Blood loss from sustained hemorrhage is the most common complication, but toxic megacolon, which occurs in up to 10% of patients with ulcerative colitis, must not be missed.
Toxic megacolon develops in advanced cases of colitis when the disease process extends through all layers of the colon (Figure 73­1). This complication occurs in patients with severe ulcerative colitis. Toxic megacolon results from a loss of muscular tone within the colon, with dilatation and localized peritonitis. If the colon continues to dilate without treatment, signs of toxicity will develop. Plain radiography of the abdomen demonstrates a long, continuous segment of air­filled colon greater than  cm in diameter. Loss of colonic haustra and “thumb printing,” representing bowel wall edema, may also be seen. The distended portion of the atonic colon can perforate, causing peritonitis and septicemia. Mortality is high.
FIGURE 73­1. Abdominal distention due to toxic megacolon. Arrows point to mucosal nodules. [Reproduced with permission from Schwartz DT (ed): Emergency
Radiology: Case Studies. © McGraw­Hill, Inc., 2008. Chapter II­2, Fig. .]
A patient with toxic megacolon appears severely ill; the abdomen is distended, tender, and tympanic. Severe diarrhea (>10 bowel movements per day) is often seen but may have ceased. Fever, tachycardia, and hypotension are typically part of the clinical picture. Leukocytosis, anemia, electrolyte disturbances, and hypoalbuminemia are the supporting laboratory results.
Some of the more prominent features of toxic megacolon, such as leukocytosis and peritonitis, can be masked in the patient taking corticosteroids.
Antidiarrheal agents, hypokalemia, narcotics, cathartics, pregnancy, enemas, and recent colonoscopy have been implicated as precipitating factors in toxic megacolon. Medical therapy with nasogastric suction, IV prednisolone  milligrams per day or hydrocortisone 400 milligrams per day, parenteral broad­spectrum antibiotics active against coliforms and anaerobes, and IV fluids should be attempted as initial therapy, along with early surgical consultation. Cyclosporine A (4 milligrams/kg per day) and infliximab have been used as rescue therapy to prevent colectomy if steroids are not
 effective. Cyclosporine A should not be given to patients with hypertension, renal impairment, epilepsy, sepsis, and age >80 years.
Perirectal fistulas and abscesses may occur in up to 20% of patients with ulcerative colitis. Massive GI hemorrhage, obstruction secondary to stricture formation, and acute perforation are other complications of the disease.
There is a 10­ to 30­fold increase in the development of carcinoma of the colon in patients with ulcerative colitis. The major risk factors for the development of carcinoma of the colon are extensive involvement and prolonged duration of the disease. The cumulative risk of cancer after  and  years is 5% to 10% and 12% to 20%, respectively. Additional factors that constitute increased risk of cancer in patients with ulcerative colitis include early onset of the disease and a family history of colon cancer.
DISPOSITION
Patients with fulminant attacks of ulcerative colitis need hospitalization for aggressive fluid and electrolyte resuscitation and careful observation for the development of complications. Patients with complications such as GI hemorrhage, toxic megacolon, and bowel perforation must also be admitted with consultation to both a gastroenterologist and a surgeon. In addition to toxic megacolon, the indications for surgery include colonic perforation, massive lower GI bleeding, suspicion of colon cancer, and disease that is refractory to medical therapy (large doses of steroids required to control the disease).
Patients with mild to moderate disease can be discharged from the ED. Close follow­up should be arranged with the patient’s physician or gastroenterologist, and any adjustment in medical therapy should be discussed prior to discharge.
Acknowledgments
The authors gratefully acknowledge the contributions of Hagop S. Mekhjian, Douglas A. Rund, Annie T. Sadosty, and Jennifer J. Hess, the authors of this topic in the prior editions.


