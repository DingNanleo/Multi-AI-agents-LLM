## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 99: Comorbid Disorders in Pregnancy
Lori J. Whelan
Content Update: YEARS Algorithm for PE in Pregnancy March 2021
See Pulmonary Embolism section and Figure 99­1 for discussion of the YEARS algorithm adaptation when considering pulmonary embolism (PE) in pregnancy.
INTRODUCTION
This chapter reviews the most common comorbid conditions encountered in pregnant women in the ED environment: diabetes and hypoglycemia; thyroid disorders; cardiac disorders and dysrhythmias; thromboembolism; asthma; urinary tract infections; headache; seizures; substance abuse; and intimate partner violence. Drug risk during pregnancy, lactation, and fetal effects of radiation are summarized based on currently available data.
Resuscitation is covered in Chapter , “Resuscitation in Pregnancy.”
DIABETES IN PREGNANCY
The growing prevalence of gestational diabetes mellitus reflects the increase in obesity, sedentary lifestyles, and type  diabetes in the general population. Due to this increased prevalence and proposed new diagnostic criteria, it is estimated that any type of diabetes affects between 8% and
 ,3
17% of pregnancies, with 86% categorized as gestational diabetes mellitus. Because many women do not receive screening for diabetes before pregnancy, it can be challenging to distinguish gestational from preexisting diabetes. Pregnant diabetics are at increased risk for several pregnancy complications, including pregnancy­induced hypertension, preeclampsia, preterm labor, spontaneous abortion, pyelonephritis, and diabetic ketoacidosis (DKA). The goal of treatment during pregnancy is to prevent spontaneous abortions, hyperglycemia­induced congenital abnormalities, and ketoacidosis and hypoglycemia.
The American College of Obstetricians and Gynecologists recommends the following goals for maintaining euglycemia in pregnant diabetic patients: a fasting blood glucose concentration of ≤95 milligrams/dL (5.27 mmol/L) and a 2­hour postprandial glucose concentration ≤120 milligrams/dL (6.66 mmol/L). 
A significant portion of gestational diabetics can be managed with diet alone if they can maintain glycemic goals with frequent glucose monitoring.
When pharmacologic treatment is indicated, insulin is the preferred treatment for diabetes in pregnancy.
Among patients with preexisting type  and type  diabetes, the need for insulin increases throughout the course of pregnancy. In general, during the
 first trimester, the initial insulin requirement is .7 unit/kg/d. By late pregnancy, patients generally require  unit/kg/d.
For basal insulin coverage, intermediate­acting neutral protamine Hagedorn (NPH) insulin has historically been considered first­line therapy and has been widely studied in this patient population. There is also recent literature supporting the use of long­acting insulin analogues, particularly insulin detemir (Levemir®), as an alternative. Insulin detemir is approved by the U.S. Food and Drug Administration for use in pregnancy and is category B.
Compared to NPH insulin, it improves fasting plasma glucose and decreases hypoglycemic events. There is a strong evidence base to recommend insulin detemir in pregnancy, but the lack of definitive fetal benefit means that there is no pressing need to switch a woman whose diabetes is well controlled by NPH insulin to insulin detemir.
Insulin glargine (Lantus®) was previously a pregnancy category C medication and was generally not initiated during pregnancy due to concerns of
 potential mitogenic activity. However, in 2015, the U.S. Food and Drug Administration started phasing out pregnancy class categories, and insulin
Chapter 99: Comorbid Disorders in Pregnancy, Lori J. Whelan glargine is now labeled “No human pregnancy data,” requiring evaluation and use on an individual basis. Recent studies have shown it to be as safe as
. Terms of Use * Privacy Policy * Notice * Accessibility insulin detemir, and it seems reasonable to initiate and continue insulin glargine if it is successful in maintaining excellent glycemic control in a woman
5–7 who is now pregnant.
For postprandial glycemic control, rapid­acting insulin analogues, such as insulin lispro and insulin aspart, do not cross the placenta and have been safely used in pregnancy. The American College of Obstetricians and Gynecologists recommends that these be used preferentially over regular insulin because both have a more rapid onset of action, enabling the patient to administer her insulin right at the time of a meal rather than  to  minutes
 before an anticipated meal. This should provide less hypoglycemia from timing issues and better glycemic control.
In women who decline insulin therapy, are unable to safely administer insulin, or cannot afford insulin, metformin is a reasonable alternative choice.

Glyburide treatment is not recommended as a first choice because it does not have equivalent outcomes to insulin.
Recent studies in gestational diabetes have not shown metformin or glyburide to have any harmful fetal effects, but these agents are still not approved by the U.S. Food and Drug Administration for use in gestational diabetes, and long­term safety studies are still needed.
HYPOGLYCEMIA

Women with type  diabetes have three to five times more hypoglycemic episodes than the period prior to pregnancy. Risk factors for severe hypoglycemia during pregnancy include a history of severe hypoglycemia in the year preceding pregnancy, impaired hypoglycemia awareness, long
 duration of diabetes, low hemoglobin A in early pregnancy, fluctuating plasma glucose levels, and excessive use of insulin injections between meals.
1c
Hypoglycemia generally presents as sweating, tremors, blurred or double vision, weakness, hunger, confusion, paresthesias, anxiety, palpitations,
 nausea, headache, or stupor. Moderate and infrequent hypoglycemic episodes are generally well tolerated by the fetus. Pregnant diabetic women should be educated about the symptoms and treatment of hypoglycemia. Treat mild hypoglycemia (i.e., a glucose level of <70 milligrams/dL [3.89 mmol/L] in patients who are able to follow commands) by giving juice, glucose, or food by mouth. Provide standard treatment for more severe hypoglycemia, with IV glucose or PO glucose or glucagon  to  milligrams SC, IM, or IV (see Chapter 223, “Type  Diabetes Mellitus,” and Chapter 224,
“Type  Diabetes Mellitus”).
DIABETIC KETOACIDOSIS IN PREGNANCY
DKA is a serious medical and obstetrical emergency previously considered typical of type  diabetes but now reported also in type  and gestational
,11 diabetes patients.
The incidence of DKA in pregnancy decreases with early diagnosis of insulin­dependent diabetes, improved prenatal counseling, and care with an
 identifiable primary care provider. DKA still most commonly affects women in the second or third trimester or pregnant women with new­onset type

 diabetes.
A pregnant diabetic who is ill appearing, has persistent nausea and vomiting, and/or has a blood glucose level≥180 milligrams/dL
[9.99 mmol/L] should be screened for DKA with serum or urine ketones and a serum chemistry panel. Diabetic pregnant women at more than  weeks of gestation are more prone to develop more severe and rapidly progressive episodes of DKA (usually over hours) and at lower glycemic
  levels (<300 mg/dL [<16.65 mmol/L]). Management guidelines for pregnant women with DKA are the same as for nonpregnant patients (see Chapter
225, “Diabetic Ketoacidosis”). In addition to the usual care, obtain fetal heart tones, administer oxygen, and for third­trimester patients, place patient in the left lateral decubitus position to displace the uterus and improve uterine blood flow. Most fetal heart rate abnormalities subside after correction of maternal hypovolemia and acidosis. Consult with the patient’s physician, and admit the patient to the hospital.
Women who use continuous SC insulin infusions (the insulin pump) can develop DKA whether they are pregnant or not. DKA can develop very quickly
,15 and unexpectedly, especially in patients who have recently started using the pump. Use of continuous insulin pumps during pregnancy is equivalent, but not superior, to scheduled injections. Management of DKA in a pregnant woman with an insulin pump is the same as in the nonpregnant patient.
DKA is not an indication for delivery. Although fetal heart rate monitoring in maternal DKA may initially demonstrate a nonreassuring pattern, patterns
 usually improve as maternal ketoacidosis is corrected, and mother will tolerate delivery or cesarean section better once acidosis resolves.
THYROID DISORDERS
Please refer to Chapter 229, “Hyperthyroidism and Thyroid Storm,” for treatment of thyroid storm in pregnancy.
TRANSIENT HYPERTHYROIDISM OF HYPEREMESIS GRAVIDARUM
Women in the first trimester with weight loss, tachycardia, and vomiting consistent with hyperemesis gravidarum may also demonstrate laboratory evidence of hyperthyroidism or biochemical or transient hyperthyroidism. The most likely cause is thyrotropin receptor stimulation from high human chorionic gonadotropin serum concentrations. Women with transient hyperthyroidism have no previous history of thyroid disease, no palpable goiter, and except for tachycardia, no other symptoms or signs of hyperthyroidism. Test results for thyroid antibodies are negative. With transient hyperthyroidism of hyperemesis gravidarum, thyroid­stimulating hormone may be suppressed and free thyroxine elevated, but triiodothyronine is lower than in true hyperthyroidism. With true hyperthyroidism, both free thyroxine and triiodothyronine are usually elevated, and thyroid antibody tests will usually be positive. Only symptomatic treatment is suggested for transient hyperthyroidism, but hospitalization may be required for
 management of dehydration. Antithyroid medication is not recommended, although beta­blockers may be considered.
HYPERTHYROIDISM
True hyperthyroidism in pregnancy increases the risk of preeclampsia, low birth weight, maternal congestive heart failure, and possibly congenital malformations. Symptoms of hyperthyroidism can mimic symptoms of normal pregnancy and may consist of nervousness, palpitations, heat intolerance, and inability to gain weight despite a good appetite. Methimazole and propylthiouracil are equally efficacious in the treatment of pregnant women. However, both medications have potential adverse effects. Methimazole is associated with congenital abnormalities during first­trimester organogenesis and has been linked to esophageal and choanal atresia and aplasia cutis. Propylthiouracil can cause hepatotoxicity. Recent studies
 revealed that children exposed to propylthiouracilalso developed birth defects. Therefore, current recommendations are to confirm potential pregnancies as soon as possible in patients currently on methimazole and propylthiouracil and evaluate the risk of withholding any antithyroid medication during the first trimester against the risk of thyroid storm. For patients requiring therapy, several expert committees recommend the use of
 propylthiouracil through  weeks of pregnancy, followed by transitioning to methimazole for the second and third trimesters. Agranulocytosis, liver failure, and aplastic anemia are rare but serious complications in patients treated with antithyroid drugs. If such conditions develop, immediately discontinue the medication and obtain obstetrical consultation.
CARDIAC DISORDERS
DYSRHYTHMIAS
Pregnancy can precipitate cardiac arrhythmias not previously present in seemingly well individuals. The risk of arrhythmias rises during labor and delivery. Factors that promote arrhythmias in pregnancy include the direct cardiac electrophysiologic effects of hormones, changes in hemodynamics or autonomic tone, hypokalemia, and underlying heart disease. Reduction of uterine blood flow during prolonged tachyarrhythmic episodes may adversely affect the fetus. The incidence of arrhythmias in pregnancy is rising due to increasing maternal age and pregnancies in women successfully
 treated for congenital heart disease. Just as in a nonpregnant patient, treat any hemodynamically unstable arrhythmia in pregnancy
 with direct­current cardioversion (50 to 200 J). Treat hemodynamically stable arrhythmias medically. The chronic use of beta­blockers in pregnancy can influence fetal and newborn size, but only atenolol is singled out as being a U.S. Food and Drug Administration class D drug in this regard (some evidence for harm to the fetus). Other beta­blockers are U.S. Food and Drug Administration class B (sotalol) or C. Digoxin, verapamil,
 diltiazem, and adenosine have their usual efficacy without adverse fetal effects.
CARDIAC DYSRHYTHMIA TREATMENT
Paroxysmal supraventricular tachycardia is the most common nonsinus tachycardia in women of childbearing age. The treatment of
 supraventricular tachycardia in pregnant women is the same as for nonpregnant women. If vagal maneuvers are ineffective, give adenosine at usual
 doses. Case reports show both efficacy and a lack of any direct adverse or teratogenic side effects to the fetus. Additionally, acute treatment with beta­blockers, verapamil, and diltiazem is safe in pregnancy when used in standard dosage.
The goal of management of atrial fibrillation in pregnancy is rate control or conversion to sinus rhythm. Use diltiazem, beta­blockers, and/or
 digoxin, all of which are safe in pregnancy and with unchanged dosages. Procainamide has not been associated with teratogenicity. Anticoagulation with unfractionated or low­molecular­weight heparin is safe in pregnancy and should be used if the patient meets criteria for anticoagulation described for nonpregnant patients.
Ventricular arrhythmias may occur during pregnancy, particularly in patients with congenital heart disease, cardiomyopathy, or valvular disease. In hemodynamically stable patients with sustained ventricular tachycardia, both IV procainamide and lidocaine can be used for acute management.
Procainamide has the same risks in pregnancy of hypotension and QT prolongation requiring ECG monitoring. Although there are reports that lidocaine may be associated with an increase in myometrial tone, decrease in placental blood flow, and fetal bradycardia, the use of the drug has not
 been linked to an increased incidence of birth defects. Amiodarone is categorized as class D because its main metabolite (desethylamiodarone) and iodine cross the placenta. Chronic fetal exposure to amiodarone and its subsequent iodine overload is associated with neurotoxicity, fetal/neonatal hypothyroidism, and less frequently, goiter. Therefore, the use of amiodarone in pregnancy is limited to maternal/fetal
,23 tachyarrhythmias that are resistant to other drugs or are life threatening because short­term use has not been linked to any harmful effects.

The presence of an artificial pacemaker or implantable cardiac defibrillator does not affect the course of pregnancy.
CHEST PAIN AND HEART FAILURE
The differential diagnosis of chest pain is similar in pregnant and nonpregnant women. However, aortic dissection and cardiomyopathy are actually more common in pregnancy. Advancing maternal age has made acute coronary syndrome in pregnancy more prevalent. Acute coronary syndrome is estimated to occur at least three times more often in pregnancy when compared to nonpregnant women of the same
 age group. Acute coronary syndrome in pregnancy is especially challenging because it is not only seen in patients over  with coronary artery disease risk factors but also presents in younger, healthy women with no risk factors. Acute coronary syndrome in younger pregnant women is more likely caused by spontaneous coronary artery dissection, coronary vasospasm, or coronary embolus, which are all extremely rare in the younger, nonpregnant patient.
Spontaneous coronary artery dissection is the most common cause of pregnancy­related acute myocardial infarction, being the documented
 cause in >40% of cases. The occurrence of spontaneous coronary artery dissection is thought to be due to progesterone and other hormone­related vessel wall changes and shear forces secondary to increased blood volume. It is most frequent in the third trimester or postpartum period.
Spontaneous coronary artery dissection is frequently found in multiple vessels and is associated with an increased incidence of cardiogenic shock,
 life­threatening arrhythmias, and a high maternal and fetal mortality. Coronary vasospasm is more prevalent in patients with migraine headaches, suggesting an overall “vasospastic” propensity coupled with an overall increase in reactivity of the vessels in pregnancy. Coronary emboli are simply
 due to the fact that pregnancy itself is a hypercoagulable state, and reports indicate that close to 10% occur in otherwise normal coronary arteries.
Treatment of acute coronary syndrome in pregnancy is complicated given the multiple etiologies discussed earlier. Additionally, many drugs in current acute coronary syndrome guidelines are not recommended in pregnancy (angiotensin inhibitors and statins) or have limited to no human safety data
(beta­blockers, nitroglycerin, and novel anticoagulants). Resuscitate and stabilize as you would for any nonpregnant patient and obtain emergent cardiology consultation. Although they may worsen a dissection, aspirin and heparin are reasonable choices because you will be unaware of a dissection until imaging is obtained. Use of thrombolytics during pregnancy can cause maternal hemorrhage, placental abruption, uterine bleeding, and postpartum hemorrhage. As of this writing, thrombolytic therapy is not recommended due to lack of reversibility and the risk of worsening a possible coronary dissection. Thrombolytic therapy could be considered for patients with life­threatening acute coronary syndrome when there is no
  access to percutaneous coronary intervention. Therefore, immediate transfer to a hospital with catheterization laboratory capabilities is advised.
Debate continues regarding whether medical management or stent placement is the best treatment option for spontaneous coronary artery dissection given recent data showing iatrogenic dissections and propagation of dissection during stent placement and successful medical management in stable
 patients. Overall outcomes are significantly worse for acute coronary syndrome in pregnancy, and many who survive will eventually require emergent coronary artery bypass graft, so prompt and accurate diagnosis and referral are imperative.
Peripartum cardiomyopathy is a dilated cardiomyopathy resulting in left ventricular dysfunction that usually develops in the third trimester or the first few months after delivery. Diagnosis is made when there is no apparent cause or preexisting history of cardiac disease. Risk factors include multiparity, maternal age >40 years old, and gestational hypertension. Peripartum cardiomyopathy needs to be considered in any postpartum patient with dyspnea, especially a younger patient, because is it easily misdiagnosed as an upper respiratory infection or pneumonia. Diagnose and treat
 congestive heart failure and pulmonary edema with standard modalities (see Chapter , “Acute Heart Failure”).
Sympathetic crashing acute pulmonary edema is an extreme form of flash pulmonary edema, preceded by long­standing hypertension and ventricular dysfunction, and can accompany preeclampsia or eclampsia. Sympathetic catecholamine release causes worsening of ventricular stiffening, and the physiologic plasma increase associated with pregnancy may make it easier for sympathetic crashing acute pulmonary edema to present in pregnancy even without preceding hypertension. Initial treatment is the same for the nonpregnant patient: high­dose IV nitroglycerin (500 to

1000 micrograms) until stabilization and ventilatory support with bilevel positive airway pressure, high­flow nasal cannula, or intubation, as needed.
VENOUS THROMBOEMBOLISM
Venous thromboembolism includes deep venous thrombosis (DVT) and pulmonary embolism and is the leading cause of maternal morbidity and
 mortality in industrialized nations as well as developing countries. The risk of venous thromboembolism increases fivefold during pregnancy and is
,34 increased by even more in the first  months after delivery.
Pregnancy­related hypercoagulability, which is necessary to prevent maternal hemorrhage, is due to increased levels of clotting factors, increased platelet and fibrin activation, and decreased fibrinolytic activity. Pregnancy increases venous pooling and uterine compression of the inferior vena cava and iliac veins. Clots develop in the deep venous system of the legs and pelvis. Up to 20% of DVTs may be complicated by pulmonary embolism, so
 early DVT diagnosis is important.
DEEP VENOUS THROMBOSIS
CLINICAL PRESENTATION
The clinical assessment of DVT is difficult because many of the typical clinical signs and symptoms are seen in normal pregnancy, including leg edema, shortness of breath, and tachycardia. Proximal extension of the DVT into the pelvic veins can result in abdominal or back pain, which is also very common in a normal pregnancy. DVT in pregnant women is more often left­sided (85% vs. 55% nonpregnant) and is more commonly found in proximal
 iliofemoral veins (72% vs. 9% nonpregnant). Up to 10% of pregnancy­related DVTs may be found in the pelvic veins, which is uncommon in
 nonpregnant patients. However, any patient with unilateral calf pain and swelling, swelling of the entire leg, or groin or back pain needs to be evaluated for DVT. Additional risk factors include a previous history or family history of DVT, obesity, maternal age >35 years, smoking, sickle cell disease, diabetes, hypertension, immobility, in vitro fertilization (greater for twins than for single gestation), and preeclampsia.
WELLS’ SCORE
The Wells’ score for DVT (see Table 56­6), the most validated clinical decision rule in the diagnosis of DVT, has not been validated in pregnant
,39 women. Chan’s LEFt clinical prediction tool is the only pregnancy­specific, validated prediction tool available. Three variables—symptoms in the left leg (L), calf circumference difference >2 cm (edema [E]), and first trimester (Ft) presentation—are predictive of positive imaging for DVT in pregnant
 women. However, the LEFt rule does not help after the first trimester and has not yet been applied prospectively in clinical trials. Therefore, it should not be used in isolation to rule out DVT.
D­DIMER
D­dimer levels normally increase throughout pregnancy, and there is no agreed­upon cutoff for a venous thromboembolism–associated D­dimer increase in pregnant women. The high negative predictive value of a normal D­dimer in pregnancy has many wanting to forgo imaging; however,
 thromboembolism has been reported with normal D­dimer levels. As of this writing, the American College of Obstetricians and Gynecologists, the
Society of Obstetricians and Gynaecologists of Canada, the Royal College of Obstetricians and Gynaecologists, and the American Thoracic

Society/Society of Thoracic Radiology recommend against the use of D­dimer alone to rule out pulmonary embolism in pregnant women.
COMPRESSION DUPLEX ULTRASOUND
Compression duplex US with color flow Doppler is the first­line imaging technique given the safety profile, and sensitivity and specificity for detecting
 proximal DVT are 96% and 99%, respectively.
Compression US is less sensitive in detecting DVT below the knee just as in nonpregnant patients. Therefore, repeat imaging is recommended if clinical concerns remain. There is a large prospective study under way to evaluate the use of whole­leg US to catch distal DVTs, which have a 10% to 20% risk of
,43 propagation in the nonpregnant patient. There is continued debate on whether to treat distal (below the knee) DVT or to repeat US to rule out
 progression; however, it is recommended to treat any DVT found in pregnancy. Emergency physicians have become proficient at performing their own DVT US exams at the bedside and have published considerable literature showing the utility of a limited 2­point exam (and D­dimer) to rule out
,45
DVT. However, there have been no studies of limited US on pregnant patients.
Iliac or pelvic vein thrombosis is more difficult to diagnose if isolated and not associated with clot in the femoral vein. Magnetic resonance venography is an MRI that uses a special technique to specifically look at blood vessels. Magnetic resonance venography has been shown to be sensitive and
46–48 specific for the detection of pelvic vein thrombosis without the need for gadolinium contrast. MRI or magnetic resonance venography without contrast should be the preferred method to evaluate pelvic vein thrombosis with the addition of contrast only if absolutely necessary.
PULMONARY EMBOLISM
Pregnant women with symptoms suggestive of pulmonary embolism who are positive for DVT by compression US should receive anticoagulation without waiting for further confirmatory diagnostic studies. In hemodynamically stable patients, consider no further imaging to spare the mother and fetus from additional radiation exposure. In unstable patients, further imaging may be required to eliminate other causes of hypotension and evaluate the need for aggressive treatment. Bedside or formal echocardiography can detect acute right ventricular dysfunction, which suggests a large
,50 clot burden that may benefit from more aggressive therapy than standard anticoagulation alone.
Pregnant patients with symptoms suggestive of pulmonary embolism with a normal compression US of the extremities have historically required further diagnostic imaging since the PERC rule, Wells score, and trimester­specific D­dimer levels have not been validated in pregnancy. The YEARS
,52 protocol is a simplified algorithm that aims to reduce advanced imaging to rule out PE. The pregnancy­adapted YEARS protocol (Figure 99­1) recommends a D­dimer on all patients and evaluation for three risk factors: (1) clinical signs of deep­vein thrombosis, (2) presence of hemoptysis, and
(3) pulmonary embolism as a likely diagnosis. If there are clinical signs of DVT, then compression US should be performed. If compression ultrasound is positive, begin anticoagulation. If compression US is negative, one of the YEARS criteria is negative. If the answer to all three YEARS questions is no, then a D­dimer threshold of ≥1000 ng/mL in fibrinogen equivalent units (FEUs) should lead to further imaging, and a level <1000 supports no imaging.
If the answer to one or more of the YEARS questions is yes, then a lower D­dimer level of >500 ng/mL FEU should lead to further imaging. As of this writing, there is no general consensus or widespread adoption of this protocol in pregnancy due to concerns that “PE as a likely diagnosis” is a subjective opinion, and/or Wells or Geneva scores (not validated in pregnancy) have been used to assess clinical PE risk. In nonpregnant patients, the use of a higher D­dimer cut­off level is accepted and is discussed in Chapter , Venous Thromboembolism Including Pulmonary
Embolism.
Figure 99­1. Adaptation of YEARS algorithm in pregnancy.
If further imaging is necessary, the current acceptable options are CT pulmonary angiography and pulmonary ventilation­perfusion scanning. CT pulmonary angiography has somewhat higher maternal breast radiation than the latter, and ventilation­perfusion scans have higher fetal radiation exposure than the former. However, as of this writing, the fetal and maternal radiation dose with either modality is felt to be within
 acceptable limits. Typically, in most institutions, a consensus is obtained between emergency physicians, obstetricians, and radiologists for imaging decisions. Table 99­1 lists advantages and disadvantages of different imaging modalities.
TABLE 99­1
Imaging Modalities for Diagnosis of Pulmonary Embolism in Pregnancy
Radiation Limitations Disadvantages Advantages Lactation
Chest Minimal Nonspecific and nonsensitive Results determine next imaging study, May identify No change radiograph requiring more time to diagnosis another cause of pulmonary symptoms
CTPA High maternal breast Contrast allergy and renal Hyperdynamic state in pregnancy can High sensitivity No need to radiation; lower fetal insufficiency affect interpretation and specificity; discard radiation than V̇/Q̇ needed if breast milk scan abnormal chest radiograph
V̇/Q̇ scan Low breast radiation Not useful if abnormal chest If negative or inconclusive and suspicion Negative Discard but higher fetal radiograph, asthma, COPD, for PE remains, will need a CTPA; limited perfusion study breast milk radiation than CTPA or underlying pulmonary availability and time for isotope effectively rules for  h disease preparation, which delays diagnosis out PE
MRI/MRV No radiation and no Gadolinium during any time Limited availability Can detect pelvic No need to evidence of of pregnancy associated with and iliac discard uncontrasted MRI an increased risk of negative thrombosis breast milk if having adverse fetal fetal outcomes14 uncontrasted effects14 MRI
Abbreviations: COPD = chronic obstructive pulmonary disease; CTPA = chest CT pulmonary angiography; MRV = magnetic resonance venography; PE = pulmonary embolism; V̇/Q̇ scan = ventilation­perfusion scan.
,54
CT pulmonary angiography is frequently recommended as the first­line diagnostic test of choice. However, there are also published algorithms that suggest proceeding to ventilation­perfusion first, if chest radiograph is normal in pregnancy, as there is a lower incidence of artifact or
,55 concomitant chronic disease, which typically impedes accuracy in older patients. However, if the ventilation­perfusion scan is nondiagnostic, then the patient will need CT pulmonary angiography, and any perceived benefit of less harmful radiation exposure is lost. Time to completion of imaging should also factor in the imaging decisions as there should be as little delay as possible in making the correct diagnosis and initiation of treatment.
TREATMENT OF DEEP VENOUS THROMBOSIS AND PULMONARY EMBOLISM
Treatment of venous thromboembolism in pregnancy currently includes unfractionated heparin or low­molecular­weight heparin because neither
 crosses the placental barrier. Most published guidelines recommend low­molecular­weight heparin as the first­line treatment of pregnant women
 with acute venous thromboembolism. Low­molecular­weight heparin is highly efficacious, has a low risk of bleeding complications, and has negligible risk of heparin­induced thrombocytopenia, and most patients do not need daily drug activity monitoring.
Unfractionated heparin may be used for patients at extremes of body weight or patients with recurrent venous thromboembolism while on therapeutic anticoagulation, since the activated PTT or anti–factor Xa levels will be monitored and doses can be adjusted to ensure therapeutic effect.
Unfractionated heparin can be given IV through a continuous infusion or SC twice­daily injections. Protamine sulfate may be used safely in pregnancy for patients who require rapid reversal of heparin anticoagulation.
Fondaparinux, a synthetic, selective anti–factor Xa inhibitor, is recommended in the United States for the prevention and treatment of venous
 thromboembolism in heparin­allergic or heparin­intolerant pregnant patients.
Do not use warfarin in pregnancy because it crosses the placenta and is associated with embryopathy in the first trimester; in the second and third trimesters, it may lead to CNS and ophthalmologic abnormalities. Warfarin should only be considered for women with mechanical heart valves who demonstrate a very high risk of venous thromboembolism despite treatment with unfractionated heparin or low­molecular­weight heparin.
An inferior vena cava filter is indicated when anticoagulation is contraindicated, when an acute embolic event occurs despite anticoagulation, or when acute venous thromboembolism occurs with impending delivery of the fetus.
TREATMENT OF LIFE­THREATENING PULMONARY EMBOLISM
Massive or high­risk pulmonary embolism is defined as sustained hypotension (systolic blood pressure of <90 mm Hg for more than  minutes) with the patient showing symptoms of shock. Thrombolytic therapy is a key treatment option for patients in extremis from pulmonary embolism, with treatment options ranging from systemic and catheter­guided thrombolysis to surgical or catheter­guided embolectomy. Although data are limited,
,59 thrombolytics have been used successfully and data regarding maternal­fetal outcomes are limited to case reports. As of this writing, there is no formal consensus on whether systemic versus catheter­guided treatment is preferred. Catheter­guided thrombolysis and embolectomy require precious time for preparation. Recombinant tissue plasminogen activator (10­milligram bolus, 90­milligram infusion over  hours) does not cross the placenta, and reported rates of maternal bleeding complications are between 1% and 6% with no maternal deaths, and rates of fetal loss are
58–61 between 2% and 5%. Streptokinase (250,000­unit bolus, 100,000 units/h infusion for  hours) is also used, but with higher rates of subchorionic hemorrhage and allergic complications and longer infusion duration than tissue plasminogen activator. Catheter­directed thrombolysis allows for earlier reperfusion and likely improved long­term pulmonary function compared with systemic therapy.
ACUTE ASTHMA
,63
Asthma is the most common medical disease in pregnancy and complicates between .7% and .4% of all pregnancies. The clinical course may improve, remain unchanged, or worsen during pregnancy. Women with asthma have higher odds of preeclampsia, gestational diabetes, placental
 abruption, placenta previa, preterm delivery, low birth weight, maternal hemorrhage, pulmonary embolism, and intensive care unit admission.
Symptoms of cough, wheezing, and dyspnea are the same as in nonpregnant patients. Initial assessment should include history of asthma exacerbations and intubation, peak expiratory flow rate measurements or forced expiratory volume in  second, physical examination, assessment of oxygen saturation, and a fetal assessment (if >20 weeks’ gestation). Peak expiratory flow rate is not altered in pregnancy, with normal rates ranging between 380 and 550 L/min. Use peak expiratory flow rate as a guide to therapy. If the pregnancy has reached viability, apply continuous electronic fetal monitoring.

Treat rapidly and aggressively to reduce readmission rates and improve fetal outcomes. The principles of management are the same as in nonpregnant patients. Maintain oxygen saturation >95%, administer repetitive or continuous inhaled β ­agonist (albuterol/salbutamol); give
 inhaled ipratropium and systemic corticosteroids; give IV magnesium; monitor maternal response to therapy; and monitor the fetus for signs of
 distress. Terbutaline sulfate, .25 milligram every  minutes, administered SC, may be used if needed. Avoid epinephrine because concerns exist about epinephrine vasoconstriction of the uteroplacental circulation.
Admission and discharge criteria are the same as in the nonasthmatic patient. For discharged women, prescribe oral prednisone,  to  milligrams per day (or equivalent), for  to  days, and a short­acting rescue beta­agonist. Anticipate maternal hyperglycemia when systemic corticosteroids are given. Inhaled corticosteroids reduce recurrence during pregnancy and decrease readmission rates following a hospitalization for asthma.

Budesonide has been safely used in pregnancy. Emphasize close follow­up and development of formal asthma treatment plans to minimize
 exacerbations as the pregnancy progresses.
ASYMPTOMATIC BACTERIURIA, CYSTITIS, AND PYELONEPHRITIS
Hormonal and mechanical changes of pregnancy increase the risk of urinary stasis and subsequent urinary tract infection. After mid­pregnancy, mild right­sided hydronephrosis is found in 75% of women, and mild left­sided hydronephrosis is found in 33%.
Asymptomatic bacteriuria is diagnosed by urine culture, demonstrating the presence of bacteria in the urine in the absence of maternal symptoms of urinary tract infection. Reagent strips have limited sensitivity, and use in screening depends on resources available, but in general, a positive leukocyte
,70 esterase or urinary nitrite should be treated and a negative specimen should be cultured. Treatment reduces the incidence of pyelonephritis and
 low birth weight.
Causative organisms of symptomatic cystitis and pyelonephritis are similar to those in the general population and include Escherichia coli (75%),
Klebsiella pneumoniae, Proteus, and gram­positive organisms such as group B Streptococcus. Obtain a urinalysis and culture with drug sensitivities in pregnant women with urinary tract symptoms and also in those with hyperemesis. Urinary tract infections need prompt treatment because acute pyelonephritis can precipitate preterm labor, bacteremia, or septic shock.
Recurrent infections can occur as a result of bacteriuria, glycosuria, and mechanical compression of the ureter in the third trimester. Reflux
 nephropathy increases the risk of sudden escalating hypertension and worsening renal function. Urolithiasis is associated with recurrent urinary tract infections.
First­line treatment for asymptomatic bacteriuria and simple cystitis is either amoxicillin, 500 milligrams PO two to three times daily for  to  days, or
 cephalexin, 500 milligrams two to four times daily for  to  days.
Recent studies have raised concerns about possible nitrofurantoin­linked birth defects, and although it is still pregnancy class B, current American
College of Obstetricians and Gynecologists guidelines recommend to avoid nitrofurantoin in the first trimester unless there are no other options
,75 available.
Trimethoprim­sulfamethoxazole is also not a good choice in pregnancy. Trimethoprim, a folate antagonist, can be used after the first trimester; sulfonamides can be taken during the first and second trimesters but not during the third trimester because sulfonamides can cause kernicterus in the infant. Do not use fluoroquinolones and tetracyclines during pregnancy. Fluoroquinolones are avoided because of observed fetal malformations in animal studies. Tetracyclines impair bone and tooth calcification.
Pregnant women with pyelonephritis are generally hospitalized, aggressively hydrated, and treated with parenteral antibiotics. The antibiotic of choice is a second­ or third­generation cephalosporin. Continue IV antibiotics until the patient is afebrile for at least  hours and costovertebral angle tenderness has resolved. The most common reason for treatment failure is antibiotic resistance. Patients discharged after hospitalization need to complete a 10­day course of therapy. Many providers choose to continue women with an episode of pyelonephritis on antibiotic suppression for the remainder of pregnancy.
HEADACHE AND STROKE SYNDROMES IN PREGNANCY
In pregnant women, headaches can be a symptom of a variety of neurologic or systemic disorders. Table 99­2 lists the differential diagnosis of headaches in pregnancy (see Chapter 165, “Headache”).
TABLE 99­2
Causes of Headaches in Pregnancy
Life threatening
Subarachnoid hemorrhage
Intraparenchymal hemorrhage
Central venous thrombosis
Ischemic stroke
CNS tumor or infection
Preeclampsia/eclampsia
Meningitis
Non–life threatening
Tension headache
Migraine
Sinus headache
Benign intracranial hypertension (pseudotumor cerebri)
Warning symptoms and signs of a potentially life­threatening disease are important to elicit during the initial evaluation and are listed in Table 99­3. TABLE 99­3
Warning Symptoms and Signs of Headaches
New­onset headaches in pregnancy
Postpartum headaches
Visual disturbance or visual field defect
Headaches with different characteristics from previous headaches
Worst headache of life, reaching maximum intensity in <1 min
Focal neurologic deficit or seizure
Meningismus
Fever
Altered consciousness or personality changes
Papilledema or other signs of increased intracranial pressure
Retinal hemorrhages
Increased blood pressure (may herald preeclampsia or eclampsia)
Obtain imaging studies if concerning signs or symptoms are encountered. CT scan of the brain can be safely performed with appropriate shielding of the fetus. CT scan is best to evaluate acute intracranial or subarachnoid hemorrhage, whereas MRI is superior for evaluation of cerebral infarct, tumor, infection, or cerebral vein thrombosis.
INTRACEREBRAL HEMORRHAGE

In pregnancy, the incidence of intracerebral hemorrhage ranges from .01% to .05%, but is the cause for 5% to 12% of all maternal deaths. The risk
 of cerebral hemorrhage extends from pregnancy through the 6­week postpartum period. Risk factors include older maternal age, African­
American race, and alcohol or cocaine use. The most common cause for spontaneous intracerebral hemorrhage is hypertension. If there is no history of hypertension, then consider other causes such as neoplasm, hemorrhagic disorder, and vascular malformation.
Presenting symptoms vary with the location and extent of hemorrhage, so consider cerebral hemorrhage in a woman with an abrupt neurologic change. For diagnosis, obtain CT/MRI and consult the neurosurgeon. Treatment is blood pressure control and correction of coagulopathy.
SUBARACHNOID HEMORRHAGE
Subarachnoid hemorrhage during pregnancy is the third most common cause of nonobstetric maternal death, and more than half of cases occur
  postpartum. Causes include hypertension, aneurysm, vascular malformation, tumors, and venous thrombosis.
Independent risk factors for subarachnoid hemorrhage from all etiologies include advancing age; African­American race; Hispanic ethnicity; hypertensive disorders; coagulopathy; tobacco, drug, or alcohol abuse; intracranial venous thrombosis; sickle cell disease; and hypercoagulability.
Suspect subarachnoid hemorrhage in a woman with severe headache, nausea, vomiting, decreased level of consciousness, or seizure. Diagnosis is by
CT/MRI and/or lumbar puncture. In general, pregnant women should be treated the same as nonpregnant patients with bed rest, analgesia, sedation,
 neurologic monitoring, and control of blood pressure.
STROKE
Pregnancy is associated with an increased risk of ischemic and hemorrhagic stroke, and stroke contributes to more than 12% of all maternal deaths,
  with the majority occurring in the third trimester or puerperium. Arterial occlusion is the most common cause of pregnancy­related stroke.
Risk factors include hypertension, heart disease, smoking, diabetes, lupus, sickle cell disease, African­American heritage, substance abuse, and cesarean delivery. Consider stroke in women with neurologic deterioration or new focal neurologic deficits.
Once hemorrhage and eclampsia are excluded, consider thrombolytic therapy after consultation with neurology and obstetrics. To date, there are no randomized controlled trials of thrombolytics for stroke in pregnancy; however, recombinant tissue plasminogen activator (risk category C) does not
 cross the placenta, and there is no evidence of teratogenicity in animal studies. There are more than 200 reports in the literature of pregnant women who have received thrombolytic therapy for various indications including myocardial infarction, pulmonary embolism, superior vena cava syndrome,
 and ischemic stroke. Use of thrombolytics in pregnancy is not without its risks, although the overall maternal mortality and fetal loss are relatively
,80 low at 1% and 6%, respectively.
CENTRAL VENOUS THROMBOSIS
Central venous thrombosis usually presents in the second and third trimesters and may occur up to  weeks postpartum. Symptoms include severe headache, focal neurologic deficit, vomiting, or seizure, depending on which veins are occluded. Venous thrombosis increases venous pressure and cerebral blood volume, elevating dural sinus pressure and leading to rupture of small cortical veins. Treatment is low­molecular­weight heparin, unless there is associated intracranial hemorrhage. Once the patient has been stabilized and hemorrhage from an aneurysm is excluded, the mainstay
 of treatment for the underlying thrombosis is still anticoagulation for the duration of the pregnancy.
MIGRAINE HEADACHE
Most patients see an improvement in migraine frequency as the pregnancy progresses; therefore, address red flag symptoms and consider other lifethreatening causes of severe headache (central venous thrombosis) especially in the second or third trimester before diagnosing migraine. Although the ergot alkaloids are contraindicated in pregnancy, acute migraine headaches can be successfully treated in pregnancy with the same first­line antiemetics that are used in nonpregnant patients. Metoclopramide (Reglan®) is class B, and prochlorperazine (Compazine®), promethazine
(Phenergan®), and droperidol (Inapsine®) are all class C. Avoid NSAIDs. Sumatriptans (class C) do not appear to increase fetal malformations, and if
 already prescribed by the obstetrician or primary physician during pregnancy, sumatriptans can be continued as an outpatient.
GI DISORDERS IN PREGNANCY
GASTROESOPHAGEAL REFLUX DISEASE
Gastroesophageal reflux disease is extremely common in pregnancy and is characterized by epigastric pain or burning radiating into the chest and neck, pain with recumbency, and pain exacerbated by acidic foods. Symptoms increase in the second trimester and peak in the third trimester due to loosening of the lower esophageal sphincter and delayed gastric emptying from pregnancy­related hormones. Always reinforce lifestyle modifications such as elevating the head of bed, not eating  hours before bed, eating small meals, and eliminating trigger foods. Over­the­counter antacids are safe and effective and should be first­line medical therapy. Treat mild, persisting symptoms with H antagonists such as cimetidine or ranitidine. Moderate
 to severe symptoms can be treated with sucralfate and proton pump inhibitors. H antagonists, proton pump inhibitors, and metoclopramide have

 been extensively studied for teratogenic effects, and no significant abnormal findings have been associated with their use in pregnancy.
HEMORRHOIDS
Hemorrhoids are common during pregnancy and are caused by a combination of constipation due to slowed bowel transit from progesterone effects in the last trimester and elevated pressure in the veins below the level of the enlarged uterus. Most symptoms are mild and can be treated with prevention of constipation with increased fluids and high­fiber intake, sitz baths, and topical medications including witch hazel compresses,
 suppositories, corticosteroids, or topically applied anesthetics. Do not use agents containing epinephrine or phenylephrine. Proctofoam has
 specifically been studied and is safe. Consider surgical or obstetric referral for prolapsed, bleeding, or incarcerated hemorrhoids or when conservative measures fail. There are no studies of the risks versus benefits of ED excision of a thrombosed clot in pregnancy. Risks include hemorrhage and recurrence.
CHOLECYSTITIS
During pregnancy, approximately  in 1000 women will develop cholecystitis. Pregnancy­related hormones affect gallbladder contractility and increase residual gallbladder volume and sludge, which in turn can lead to gallstone formation. Many women ultimately require cholecystectomy during pregnancy for persistent symptoms. It is preferable to wait until the second trimester if the patient’s condition allows, as surgery during the first
 trimester carries a risk of spontaneous miscarriage, and cholecystectomy in the third trimester is technically difficult and can result in preterm labor.
APPENDICITIS
Appendicitis occurs about once in every 500 to 2000 pregnancies and is the most common extrauterine condition requiring abdominal operation in pregnancy. The diagnosis is often missed or delayed because mild abdominal discomfort, nausea, and vomiting occur frequently in normal pregnancies. Additionally, the appendix shifts in location from the right lower quadrant to the right upper quadrant during the second and third trimesters. US has become the first diagnostic test of choice in children and many adults. However, in pregnant patients, adequate visualization of the appendix is difficult, especially later in pregnancy. Recent studies suggest using MRI as the initial imaging modality given the high rate of inconclusive
87–89
US results. Noncontrast MRI (without gadolinium) is recommended due to recent concerns of fetal effects from gadolinium exposure. If US or
MRI is unavailable, CT should be performed without delay. Focal appendiceal CT may be considered since it provides less radiation to the fetus than full abdominopelvic CT. However, focal abdominal imaging may limit discovery of an alternative diagnosis. An abdomen or pelvis CT confers about 
 mGy of radiation, and  mGy of radiation is generally accepted to be safe in pregnancy.
OVARIAN TORSION
Torsion of the ovary is a true gynecologic emergency, and up to one fifth of ovarian torsion occurs during pregnancy. Torsion can occur in any
 trimester, although it is most common in the first trimester. Infertility treatment is a risk factor. Ovarian torsion can recur in the same pregnancy, in
 particular in enlarged multicystic ovaries. The corpus luteal cyst and enlarged ovaries stemming from the pregnancy hormones are thought to increase the risk. Tissue necrosis can occur rapidly, so timely diagnosis is essential to preserve ovarian function and the pregnancy. The diagnosis is often missed due to the vague clinical presentation of moderate unilateral lower abdominal pain, which may also be intermittent or constant. US may show an enlarged or edematous ovary with absent or decreased blood flow. However, the presence of ovarian blood flow does not exclude
 the diagnosis of torsion if symptoms are suggestive. Therefore, consult an obstetrician/gynecologist as soon as the diagnosis is clinically suspected.
SEIZURE DISORDERS
Seizure frequency can increase in pregnancy because of the increased volume of distribution and plasma clearance of antiepileptic drugs in pregnancy or because of poor medication compliance.
Most of the antiepileptic drugs can cause a range of birth defects. Valproic acid, carbamazepine, and phenytoin are still listed under the old
U.S. Food and Drug Administration classification as class D. Yet, discontinuing these drugs can increase morbidity and mortality for both the mother and fetus. Therefore, the risks and benefits of chronic treatment should be discussed and managed by the primary physician. Medication doses may need to be increased in pregnancy. Therapeutic serum target levels remain unchanged. Monotherapy with levetiracetam or
 lamotrigine should be used whenever possible. Acute treatment of seizures in the pregnant woman is similar to that in the nonpregnant patient (see Chapter 171, “Seizures and Status Epilepticus in Adults”). Even though lorazepam and diazepam are class D medications, they are so
,95 categorized based on long­term use. Use of benzodiazepines for an acute seizure outweighs any potential risk to the fetus.
If the seizure if self­limited, administer oxygen and position the patient in the left lateral decubitus position and provide supportive care. Fetal bradycardia lasting for up to  minutes may follow a single brief maternal seizure. Status epilepticus poses a real threat to both mother and the fetus, with a significant maternal and fetal mortality. Provide aggressive management, including intubation and ventilation, early in the management of pregnant women with status epilepticus (see Chapter 171).
HUMAN IMMUNODEFICIENCY VIRUS INFECTION
Pregnancy does not appear to alter the natural course of human immunodeficiency virus (HIV) disease, nor do uninfected babies born to HIV­positive women appear to be at increased risk for neonatal complications when compared with appropriate control patients. With over  million women of childbearing age living with HIV in the United States, it is important to initiate antiretroviral therapy as soon as possible not only for the health of the
 mother but also because appropriate therapy can eliminate mother­to­child transmission.
In general, women who are already on a fully suppressive regimen when they become pregnant should continue their regimens. Key
 exceptions include medications with high risk for toxicity in pregnancy (didanosine, stavudine, and treatment­dose ritonavir). Another exception would be efavirenz, which is a highly recommended drug as part of a three­drug regimen, but it is not recommended until after the first  weeks of pregnancy. However, if an HIV­infected woman who is already taking efavirenz becomes pregnant, the regimen may be continued because changing it
 risks loss of virologic control. Additionally, some common drug regimens, such as elvitegravir/cobicistat, are not as effective in pregnancy. These
 drugs should be replaced with antiretrovirals recommended in pregnancy.
Recommended optimal initial regimens for most patients include three different drugs: two nucleoside reverse transcriptase inhibitors plus an
 integrase strand transfer inhibitor. Other effective regimens include nonnucleoside reverse transcriptase inhibitors or boosted protease inhibitors with two nucleoside reverse transcriptase inhibitors. There are many current drug combinations that can be safely used in pregnancy and that have different side effect profiles, number of pills or doses per day, and price points. The treatment plan should be individualized to optimize compliance and efficacy while minimizing side effects and drug interactions.

Prophylaxis for opportunistic infections is similar to that for nonpregnant patients. Patients with CD4+ T­cell counts of <200/mm should be maintained on prophylaxis for Pneumocystis jirovecii pneumonia using trimethoprim­sulfamethoxazole. Although a small increased risk of birth defects may be associated with first­trimester exposure to trimethoprim, women in their first trimester with P. jirovecii pneumonia still should be treated with trimethoprim­sulfamethoxazole because of its considerable benefit. Additional folate supplementation (higher than usual doses in pregnancy) may be added, but it is unclear whether the higher doses of folate supplementation lower risk. Alternatively, aerosolized pentamidine may
 be used in the first trimester, as it is minimally systemically absorbed.
Treatment of overt opportunistic infections in HIV­infected pregnant women is addressed in the same way as in nonpregnant women. Early intubation to reverse hypoxemia may be necessary to improve maternal­fetal outcome in women with respiratory infections.
SUBSTANCE ABUSE DURING PREGNANCY

Substance abuse in pregnancy results in approximately 225, 000 infants yearly with prenatal exposure. Refer pregnant women identified in the ED as substance abusers to a high­risk obstetrics clinic and offer them substance abuse counseling.
COCAINE
Cocaine use is associated with placental abruption, fetal death in utero, intrauterine growth restriction, preterm labor, premature rupture of membranes, spontaneous abortion, and cerebral infarcts in the fetus. Maternal complications of cocaine use include myocardial infarction, hypertension (which can result in aortic dissection), pulmonary edema, and cardiac dysrhythmias. Subarachnoid hemorrhage, ruptured aneurysms, and strokes are reported in cocaine users and are most likely related to transient hypertension. Treatment of the pregnant woman with acute cocaine intoxication is handled in the same manner as in the nonpregnant patient (see Chapter 187, “Cocaine and Amphetamines”).
OPIOIDS
Although acute opioid withdrawal poses minimal maternal risk, there is significant risk to the fetus, including meconium, hypoxia, preterm labor, and
 fetal demise. Illicit opioid use can cause intermittent fetal withdrawal when there is maternal lack of access to the drug.
Therefore, it is standard to refer opioid­addicted pregnant patients for supervised methadone or buprenorphine therapy for the duration of the pregnancy. Even though methadone/buprenorphine will cause neonatal abstinence syndrome (opioid withdrawal) after birth, this is a treatable condition and carries less harm to the infant than acute opioid withdrawal in utero. Maternal detoxification from opioids should be done in a
100 supervised inpatient setting, and only for select patients, as the relapse rate is very high.
Mild maternal opioid withdrawal can be treated with clonidine, .1 to .2 milligram every  to  hours, until the signs of withdrawal resolve. Severe maternal opioid withdrawal may require administration of an opioid agonist and admission for fetal monitoring and induction of methadone
100,101 therapy.
ALCOHOL
Alcohol consumption during pregnancy is a risk factor for fetal alcohol syndrome, birth defects, and low birth weight. Binge drinking is particularly harmful to fetal neurodevelopment.
In the United States, the prevalence of fetal alcohol syndrome has been estimated at .5 to .0 cases per 1000 births, but even with conservative
102 estimates, the prevalence may be close to  cases per 1000 births in certain communities in the United States.
Pregnant women who present in coma due to acute alcohol intoxication or in alcohol withdrawal are managed in the same way as nonpregnant
103 patients. Disulfiram (Antabuse®) is a potential teratogen. Do not prescribe in pregnancy. There are no data on disulfiram, acamprosate, or naltrexone in pregnancy, and these agents are not recommended.
INTIMATE PARTNER VIOLENCE
One in four women and one in nine men in the United States have experienced rape, physical violence, or stalking by an intimate partner in their
104 lifetime. Factors associated with intimate partner violence during pregnancy are late entry into prenatal care, unintended pregnancy, drug and alcohol use, depression, and housing problems. Violence increases the risk for preterm labor, placental abruption, fetal fractures, uterine rupture, chorioamnionitis, delivering a low­birth­weight infant, and homicide. The American College of Obstetricians and Gynecologists recommends routine
105 screening for intimate partner violence during pregnancy. See Chapter 294, “Intimate Partner Violence and Abuse, ” for more discussion.
Pregnant women with injuries should be treated according to usual trauma protocols. Institute fetal monitoring for direct or indirect blunt abdominal trauma and major multiple trauma. Administer Rh immunoglobulin to Rh­negative women with blunt abdominal trauma (see Chapter ,
“Resuscitation in Pregnancy”).
MEDICATIONS IN PREGNANCY AND LACTATION
The classic teratogenic period is  to  weeks of gestation. During this critical time, organs are forming, and teratogens may cause malformation. Administration of drugs early in the period of organogenesis affects the organs developing at that specific time, such as the heart or neural tube. Teratogens given closer to the end of the classic teratogenic period will affect the ear and palate. Before week , exposure to a teratogen produces an all­or­none effect (i.e., the conceptus either does not survive or survives without anomalies). If the organism remains viable after exposure before week , organ­specific anomalies do not develop because repair or replacement permits normal development. A similar insult at a later stage of development may produce organ­specific defects.
In 1979, the U.S. Food and Drug Administration established five letter risk categories (A, B, C, D, or X) to indicate the potential of a drug to cause birth defects if used in pregnancy (Table 99­4). In 2015, the U.S. Food and Drug Administration replaced the former risk letter categories with the
Pregnancy and Lactation Labeling Rule, which provides more information in a new format to assist providers in assessing benefit versus risk to aid in counseling of pregnant women who need medication (Table 99­5). All medications approved after 2015 will be required to use the new format in the package labeling, which gives detailed information about the drug. Medications approved on or after 2001 will be phased in gradually but will eventually be required to provide all the same information. However, all prescription drugs were required to remove pregnancy letter categories as of June 2018. The new labeling still does not provide a definitive yes or no answer in most cases, and clinical interpretation will be required on a case­by­case basis.
TABLE 99­4
U.S. Food and Drug Administration Pregnancy Drug Categories, 1979
Drug
Risk During Pregnancy
Category
A Controlled studies show no fetal risk in any trimester, and so the possibility of fetal harm is remote.
B Animal studies show no fetal risk, but there are no controlled human studies.
Or
Animal studies have shown an adverse effect that was not confirmed in controlled human studies in women in the first trimester (and there is no evidence of risk in later trimesters).
C Animal studies have shown adverse fetal effects (teratogenic or embryocidal), and there are no controlled studies in humans.
Or
No human or animal studies are available. Drugs should be used only if the potential benefit justifies the potential fetal risk.
D Evidence of human fetal risk exists, but the benefits of use in pregnant women may be acceptable despite the risk.
X Studies in animals or humans have shown fetal risk, or there is evidence of fetal risk based on human experience. The risk of use in pregnancy clearly outweighs any possible benefit. Drugs are contraindicated for use in women who are or may become pregnant.
TABLE 99­5
2015 U.S. Food and Drug Administration Pregnancy and Lactation Labeling Rule Required Information on Package Insert for Every Medication
In Both Pregnancy and Lactation
Risk summary: What are the known risks in context with background risk?
Risk statement based on human data
Risk statement based on animal data
Risk statement based on pharmacology
Background risk information in general population
Background risk information in disease population
Clinical considerations: What medical/disease factors should be considered?
Disease­associated maternal and/or embryo/fetal risk
Dose adjustments during pregnancy and the postpartum period
Maternal adverse reactions
Fetal/neonatal adverse reactions
Labor or delivery
Data: Human and animal data and pregnancy drug registries that support the summary
Human data: Description includes study type, number, duration, exposure information, and limitations.
Animal data: Description includes study type, species, animal doses and basis for the exposures, duration and timing, findings, presence of maternal toxicity, and limitations.
In Reproductive Potential
Contraception
Infertility
Pregnancy testing
Some therapeutic agents with adverse effects during pregnancy are listed in Table 99­6. The National Library of Medicine provides a detailed reference list in the Developmental and Reproductive Toxicology Database.
TABLE 99­6
Drugs Used in Emergency Settings With Known Adverse Effects in Human Pregnancy
Drug Effect
Angiotensin­converting enzyme inhibitors and angiotensin receptor blockers Renal failure, oligohydramnios
Aminoglycosides Ototoxicity (gentamicin class D, Black Box Warning)
Androgenic steroids Masculinize female fetus
Anticonvulsants (carbamazepine, hydantoins, valproate) Dysmorphic syndrome, anomalies, neural tube defects
Antithyroid agents Fetal goiter
Aspirin (high doses) Bleeding, antepartum and postpartum
Cytotoxic agents (e.g., methotrexate) Multiple anomalies
Erythromycin estolate Maternal hepatotoxicity
Fluoroquinolones Fetal cartilage abnormality
Isotretinoin Hydrocephalus, deafness, anomalies
Lithium Congenital heart disease (Ebstein’s anomaly)
NSAIDs (prolonged use after  wk) Oligohydramnios, constriction of fetal ductus arteriosus
Streptomycin Fetal cranial nerve VIII damage
Sulfonamides Fetal hemolysis, neonatal kernicterus (near term)
Tetracyclines Fetal teeth and bone abnormalities
Trimethoprim, methotrexate Folate antagonist (first trimester)
Thalidomide Phocomelia
Warfarin Embryopathy—nasal hypoplasia, optic atrophy
Table 99­7 lists some general cautions for using drugs during lactation. When prescribing, check each drug individually. Because information can change, we recommend referring to the following sources for information about drug safety in lactation:
TABLE 99­7
World Health Organization General Cautions for Drugs and Breastfeeding106
Guideline Drugs
Breastfeeding Anticancer drugs, radioactive substances, amphetamines, ergotamines, statins, and nitrofurantoin (for <1 mo old and for contraindicated those with glucose­6­phosphate dehydrogenase deficiency)
Avoid unless absolutely Chloramphenicol, tetracyclines, fluoroquinolones necessary
Monitor infant for Selected psychiatric and anticonvulsant agents drowsiness
Monitor infant for jaundice Sulfonamides, dapsone, sulfadoxine/pyrimethamine (Fansidar®), mefloquine
May inhibit lactation; use Estrogens, thiazides alternative drug
Drugs and Lactation Database (LactMed), U.S. National Library of Medicine—http://toxnet.nlm.nih.gov/cgi­bin/sis/htmlgen?LACT (accessed April
2018)
World Health Organization, Breastfeeding and Maternal Medication, http://www.who.int/maternal_child_adolescent/documents/55732/en/ (last updated 2003; accessed July 2018)
Thomas Hale, Medications and Mothers’ Milk, ISBN­13 (978­0984774630), Hale Publishing, May 2013, 15th ed.
FETAL RADIATION EFFECTS
For radiation imaging during pregnancy, weigh the risks of exposure and subsequent fetal adverse effects against the risk of incorrect maternal diagnosis. The major factor determining the degree of risk to the fetus is the quantity of ionizing radiation exposure during imaging. Fetal exposure to low­dose radiation, defined as <5 rads (<50 mGy), DOES NOT increase the risk of fetal or infant death, mental defects, or growth retardation. More than  rads (>50 mGy) is considered the threshold for human teratogenesis. By using typical imaging parameters, it is unlikely that a single­phase CT scan would reach this dose level. The fetus is most vulnerable to teratogenicity between  and  weeks of gestation at doses >10 rads (>100 mGy) (Table 99­8).
TABLE 99­8
Teratogenic Radiation Effects
Gestational Age Effect of 5–10 rads (50–100 mGy) Effect of >10 rads (>100 mGy)
0–2 wk Probably none Possible spontaneous abortion
3–8 wk Unknown; probably none detectable Possible malformations with increasing dose
9–15 wk Unknown; probably none detectable Possible mental development defects with increasing dose
≥16 wk None None detectable or none
,107,108
The estimated radiation doses involved in procedures commonly used for ED diagnosis are listed in Table 99­9. TABLE 99­9
Radiation Exposure to the Uterus/Fetus
Procedure Dosage in mGy
Threshold for human teratogenesis 100
Accepted as safe in pregnancy 
Abdominal/pelvis CT 25–35
CT, kidney­ureter­bladder protocol (reduced radiation dose) 
Lumbosacral spine series (three view) .6–3.5
Ventilation­perfusion scan (total) .1
Abdominal series (two view) 
Lung perfusion scan with technetium .7
Normal background radiation over  months 
Head CT <0.5
Lung ventilation scan with xenon .4
Anteroposterior pelvis x­ray .4
Chest CT (10­mm slices,  slices), for standard or pulmonary embolism protocol .2
Cerebral angiography .1
Mammography—diagnostic for suspected breast cancers .07–0.2
Chest radiography (two view) with shielding of the maternal abdomen <0.001
Cervical spine (two view) <0.001
Note:  rad =  mGy =  mSv.
MRI IN PREGNANCY
The 2013 American College of Radiology guidance document on magnetic resonance safe practices states that MRI can be used in pregnant patients regardless of gestational age when the information gained is likely to alter treatment, when it cannot be obtained through other nonionizing means,
 and when MRI cannot be delayed until completion of the pregnancy. Noncontrast MRI (abdomen/appendicitis, pelvis/pelvic vein thrombosis) should
 be used unless contrast is deemed absolutely necessary given the recent concerns with gadolinium exposure to the fetus.
LACTATION AFTER IMAGING
The American College of Radiology and the American College of Obstetricians and Gynecologists advise that patients continue breastfeeding after administration of IV iodinated or gadolinium­based contrast agents. Both have low lipid solubility, and less than 1% of iodinated contrast agents and

.04% of gadolinium­based contrast agents are excreted into breast milk (Table 99­1).


