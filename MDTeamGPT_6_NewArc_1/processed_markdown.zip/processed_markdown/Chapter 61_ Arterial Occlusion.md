## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 61: Arterial Occlusion
David Carr; Anna K. Nowacki; Jessica Pelletier; Alex Koyfman; Brit Long
Content Update: Upper Extremity Ischemia, December 2023
Upper extremity ischemia is a high­risk, low­occurrence disease that requires careful evaluation and diagnostic consideration to prevent limb dysfunction and even limb loss. See expanded discussion at the end of the chapter, Upper Extremity Ischemia.
INTRODUCTION AND EPIDEMIOLOGY
Limb ischemia occurs when blood flow—and by extension, tissue perfusion—is limited enough to create symptoms; acute limb ischemia denotes rapid new event or a progression of a flow deficit, requiring recognition and rapid therapy for limb salvage. Critical limb ischemia is one end of the spectrum of peripheral arterial disease, when pain at rest, ulceration, or gangrene exists. Smoking and diabetes are the most important risk factors for peripheral arterial disease.1 Additional risk factors include hyperlipidemia, hypertension, elevated blood homocysteine, and an elevated C­reactive protein level.2
The severity of peripheral arterial disease is linked to the risk of myocardial infarction, ischemic stroke, and death from vascular disease.3 The most frequently diseased arteries leading to limb ischemia are, in order of occurrence, the femoropopliteal, tibial, aortoiliac, and brachiocephalic vessels. Despite improvements in the management of peripheral arterial disease, current
1­year mortality after the onset of critical limb ischemia is 25%, and up to one quarter of survivors require amputation.4,5
Over 200 million people are living with peripheral artery disease globally, with 70% of those in low­ and middle­income countries. Between 2000 and 2010, the number of individuals with peripheral artery disease increased by nearly 30% in low­ and middle­income countries and by 13% in high­income countries.6 Data from the Global Burden of Disease projects show that on a global scale, there has been a significant increase in both disability and mortality associated with peripheral arterial disease, with a greater increase among women than among men.7 In the
United States, it is estimated that critical limb ischemia has an annual incidence of .35% and an average prevalence of .33%. This exceeds previous estimates and parallels the incremental increase in cardiovascular risk factors.8
PATHOPHYSIOLOGY
Acute limb ischemia results from a sudden decrease in blood supply to a limb, leading to tissue hypoperfusion and threatening limb viability. As time proceeds, cell death or irreversible tissue damage occurs. Without the presence of collateral vessels, peripheral nerves and skeletal muscle may suffer irreversible changes within  to  hours of vessel occlusion.
Following restoration of blood flow, reperfusion injury can occur and may manifest as compartment syndrome, rhabdomyolysis, or metabolic derangements. Often, hyperkalemia, myoglobinemia, metabolic acidosis, and an elevation in creatine kinase level exist. The extent of reperfusion injury depends on the duration and location of the arterial blockage, the amount of collateral flow, and the previous health of the involved limb. Approximately one third of all deaths from occlusive arterial disease are secondary to metabolic complications after revascularization.9
Disorders that can lead to arterial occlusion are listed in Table 61­1. TABLE 61­1
Disorders Associated With Acute Arterial Occlusion
Disorder Cause Symptoms/Signs Management
Thrombus Atherosclerosis or thrombosis of bypass grafts Intermittent claudication Medical first, then consider interventional
Embolism Cardiac source: atrial fibrillation, rheumatic heart disease, mechanical Sudden onset of territorial arterial symptoms Preventive anticoagulation, valves, post–myocardial infarction thrombus, atrial myxomas, and embolectomy leaflet vegetations/endocarditis
Catheterization complication Can occur during standard angioplasty, angiography, or arterial blood Expanding hematoma, pain, temperature and pulse Conservative vs. operative
(brachial or femoral) gas changes repair
Trash foot or blue toe syndrome Cholesterol/platelet aggregate emboli Painful cyanotic discoloration of isolated portion of Conservative therapy foot; remainder of the foot is warm

Vasculitis: rheumatoid arthritis, Autoimmune inflammation of small arteries Systemic symptoms and multiorgan ischemia Steroids, immunosuppressive
Chapter 61: Arterial Occlusion, David Carr; Anna K. Nowacki; Jessica Pelletier; Alex Koyfman; Brit Long lupus, polyarteritis nodosa agents
. Terms of Use * Privacy Policy * Notice * Accessibility
Raynaud’s disease Vasospasm in small arteries or arterioles provoked by cold or stressors Local pain, pallor, cyanosis, numbness, Rewarming, medications: paresthesias in hands usually resolving in 30–60 calcium channel blockers, α­ min blockers, vasodilators
Takayasu’s arteritis Autoimmune vasculitis of aortic arch and branches Young Asian women: peripheral ischemia and Steroids, immunosuppressive necrosis leading to pulseless phase; may have agents fever, rash, muscle aches, arthritis
Thromboangiitis obliterans Nonatherosclerotic segmental inflammation of small/medium vessels; Painful nodules, ulceration, and gangrenous digits Smoking cessation
(Buerger’s disease) typically, seen only in smokers in young adults (age 20–40 y)
HIV arteritis10 Chronic inflammation of arteries associated with low CD4 counts Intermittent claudication Optimization of HIV management, angioplasty, or vein graft
Hypothenar hammer syndrome Repeated trauma to the hypothenar area with hammering in laborers, Painful discoloration of one or more ulnar fingers Aspirin, nifedipine, intra­arterial as well as those using vibrational tools, causing narrowing of ulnar with sparing of thumb fibrinolysis, interposition vein artery or aneurysmal degeneration graft
Popliteal artery entrapment Anatomic crowding of popliteal fossa with anomalous relationships Pain in anterior aspect of lower one third of leg Surgical repair of popliteal
(young males) and popliteal between popliteal artery and surrounding muscle and fascia or luminal with exercise, reproducible with active ankle fossa or aneurysm and grafting aneurysms (older males)11 narrowing and thrombosis of aneurysm plantar flexion or passive dorsiflexion
External iliac artery External iliac artery fibrosis secondary to prolonged hip flexion Thigh pain and numbness in cyclists and Surgical management or endofibrosis12 triathletes: measure pre­ and postcycling ankle­ catheter dilatation brachial indexes
Local arterial trauma13,14 Penetrating or blunt damage to vessel Suspect in patients with knee dislocation or Surgical repair penetrating extremity trauma
Shock­related arterial ischemia Low cardiac output states: congestive heart failure, sepsis, cardiogenic Generalized hypoperfusion Resuscitation with fluids, blood or hypovolemic shock products, vasopressors, inotropes; treat infection
Thoracic aortic dissection False lumen of dissection occludes arteries Chest or back pain Surgical repair
Abbreviation: HIV = human immunodeficiency virus (infection).
THROMBOSIS
Thrombotic occlusion is the most common cause of acute limb ischemia and can occur in native vessels and bypass grafts. In the lower limbs, thrombotic occlusion accounts for >80% of cases.15 In the upper limbs, about half of all cases of acute limb ischemia are due to thrombosis, while about one third are due to embolism.16 The clinical distinction between thrombosis and embolism in any given patient is not always clear. Thrombosis most often occurs in the presence of atherosclerosis; due to the presence of collateral vasculature, thrombotic ischemia presents more gradually than an acute embolic event. However, it is also possible for plaque to embolize directly or to foster thrombus formation that embolizes and creates an acute high grade.
Other than plaque rupture, progression of ischemic injury can occur by: (1) propagation of clot to occlude collateral vessels, (2) ischemia­related distal edema leading to high compartment pressures (compartment syndrome), (3) fragmentation of clot into the microcirculation, and (4) edema of the microvasculature cells. Large­vessel reperfusion may not resolve obstruction of the microvasculature.
Uncommonly, arterial thrombosis develops in an apparently normal vessel without plaque; these patients should be evaluated for an underlying hypercoagulable condition. Subclinical vessel injury (from injections, catheters, or other mechanical events) or early atherosclerosis may still exist in these patients.
EMBOLISM
Occlusion from embolism is less common than occlusion from thrombosis. The heart is the predominant source of peripheral emboli, with atrial fibrillation being responsible for most cases.
Another cardiac source is a mural thrombus in the ventricle after recent myocardial infarction. Both atrial fibrillation and acute myocardial infarction predispose to poor cardiac wall motion and stagnant blood flow that promote clot formation. Patients with an acute myocardial infarction may develop a left ventricular thrombus as early as  hours and as late as  months after the event, with overall rates reported as about 3%, with anterior infarct thrombi rates as high as 9%.17 Less common causes include emboli from mechanical valves, tumor emboli from atrial myxomas, vegetations from valve leaflets, and parts of prosthetic cardiac devices.
Noncardiac sources of arterial emboli include thrombi from aneurysms and atheromatous plaques. Mural thrombi in aneurysms of aortoiliac, femoral, popliteal, and subclavian arteries are the most notable sources. Atheroemboli consist of cholesterol­laden debris and platelet aggregates and result from plaque fragmentation that causes obstruction of the microcirculation, producing symptoms in the hands, feet (blue toe syndrome), or cerebral circulation (transient ischemic attack). Paradoxical embolization occurs when a venous clot passes from the right to the left side of the heart through an intracardiac shunt, most commonly a patent foramen ovale.
An embolus may fragment and embolize distally, or it may propagate locally and create a larger clot. Emboli tend to lodge in places where vessels taper or branch, with the most common location in the leg being the bifurcation of the common femoral artery, followed by the popliteal artery. In the upper limb, the brachial artery is most commonly affected by an embolism.
OTHER CAUSES
Intentional or accidental intra­arterial drug injections can result in local vasospasm, infectious arteritis, thrombosis, pseudoaneurysm, endocarditis, and mycotic aneurysm. Inert particles or drug crystals can embolize to obstruct end arteries, which can lead to gangrene of the digits. The prolonged use of vasopressor medications may result in arterial ischemia; when using these agents, observe closely for adequate extremity perfusion, particularly in patients with known preexisting vascular disease.
An aortic dissection can propagate into the subclavian or iliofemoral systems and present with neurologic dysfunction and/or extremity ischemia findings. The false lumen created by the dissection occludes flow in the involved artery.
CLINICAL FEATURES
Patients with acute limb ischemia exhibit one or more of the “six Ps”: pain, pallor, paralysis, pulselessness, paresthesias, and poikilothermia (for cold). A lack of one or more of these findings does not exclude ischemia. Pain alone may be the earliest symptom of ischemia, localized in the limb distal to the site of obstruction.
Skin changes include pallor first, followed by blotchy and mottled areas of cyanosis, and then associated petechiae and blisters. Late findings consist of skin and fat necrosis.
With vessel occlusion, severe and steady pain in the involved extremity associated with decreased skin temperature is common. Hypoesthesia or hyperesthesia due to ischemic neuropathy is typically an early finding, as is muscle weakness. Two­point discrimination, vibratory sensation, and proprioception are often diminished prior to the loss of deep sensation. Absence of a palpable distal pulse is not a particularly helpful sign in a patient with long­standing vascular disease unless accompanied by skin changes compatible with acute arterial obstruction. An abrupt loss of a previously strong pulse is suggestive of acute embolization.
Atheroemboli present clinically with several different areas of involvement, with pain and cyanosis in the involved digit, petechiae, and local muscle pain and tenderness at the site of infarction (blue toe syndrome). Pulses are generally preserved, assuming they were present prior to the event. Table 61­1 notes symptoms of other related disorders.
As ischemic injury progresses, anesthesia and paralysis become evident and foreshadow impending gangrene and the loss of limb viability. Preservation of light touch on skin testing is a good guide to tissue viability. A patient with an acute ischemic limb with signs of muscle paralysis, sensory loss, and prolonged ischemia has a limb that is likely nonviable. The Rutherford criteria (Table 61­2) provide a more formal prognostic stratification of the clinical stages of acute limb ischemia.
TABLE 61­2
Rutherford Criteria for Acute Limb Ischemia
Findings Doppler Signals
Category Description/Prognosis Sensory Loss Muscle Weakness Arterial Venous
I. Viable Not immediately threatened None None Audible Audible
II. Threatened a. Marginally Salvageable if promptly treated Minimal (toes) or none None Inaudible Audible b. Immediately Salvageable with immediate revascularization More than toes, associated with rest pain Mild, moderate Inaudible Audible
III. Irreversible Major tissue loss or permanent nerve damage inevitable Profound, anesthetic Profound, paralysis (rigor) Inaudible Inaudible
Source: Reproduced with permission from Rutherford RB, Baker JD, Ernst C, et al: Recommended standards for reports dealing with lower extremity ischemia: revised edition. J Vasc Surg 26: 517, 1997. Limb viability is dependent on the effectiveness of collateral circulation, and no arbitrary time period can exclude treatment options despite the common belief that “treatment must occur in
 to  hours.”2
ACUTE VERSUS CHRONIC ARTERIAL DISEASE
Acute limb ischemia is defined as symptoms starting within a 2­week period. Pain over the distal forefoot waking the patient at night or requiring the patient to hang his or her feet over the bed is suggestive of severe arterial occlusion and requires prompt consultation and treatment.
In contrast to acute disease, chronic peripheral arterial disease has intermittent claudication, which may progress to intermittent ischemic pain at rest. Claudication is a cramp­like pain, ache, or tiredness that is brought on by exercise and relieved by rest, similarly to angina in the heart. It is reproducible, resolves within  to  minutes of rest, and recurs at consistent walking distances. Unlike claudication, the pain of acute limb ischemia is not relieved by rest or gravity, is not well localized, and can present as marked worsening of chronic pain.
Classical teaching suggests that single­vessel disease in one of the segments noted in Table 61­3 may result in localized claudication, whereas multivessel disease results in less focal rest pain or tissue loss. Table 61­3 lists symptom sites of commonly compromised arteries.
TABLE 61­3
Artery­Specific Claudication Sites
Artery Involved Claudication Site
Iliac artery Buttocks, thigh, and sometimes calf (if bilateral, may cause impotence in men)
Common femoral artery Thigh
Superficial femoral artery Upper two thirds of calf
Popliteal artery Lower one third of calf
Infrapopliteal (tibial and peroneal) artery Foot
OTHER DIAGNOSES THAT MIMIC ARTERIAL ISCHEMIA
The pain of intermittent vascular claudication can be confused with other triggers (Table 61­4) including spinal stenosis or lumbosacral radiculopathy. Other causes of extremity pains include chronic compartment syndrome, venous claudication, nerve root compression, Baker’s cyst, or foot, hip, or ankle arthritis.
It is important to consider the following three steps in the differential diagnosis of acute limb ischemia:
. Look for conditions mimicking acute limb ischemia.
. Consider nonatherosclerotic causes of arterial occlusion.
. If neither of the above exists, determine if the ischemia is caused by an arterial thrombus or embolus.2
TABLE 61­4
Differential Diagnosis of Acute Limb Ischemia
*Conditions mimicking acute limb ischemia
Systemic shock (especially if associated with chronic occlusive disease)
Phlegmasia cerulea dolens
Acute compressive neuropathy
Differential diagnosis for acute limb ischemia (other than acute peripheral arterial disease)
Arterial trauma
Aortic/arterial dissection
Arteritis with thrombosis (e.g., giant cell arteritis, thromboangiitis obliterans)
HIV arteriopathy
Spontaneous thrombosis associated with a hypercoagulable state
Popliteal adventitial cyst with thrombosis
Popliteal entrapment with thrombosis
Vasospasm with thrombosis (e.g., ergotism)
Compartment syndrome
Acute Peripheral Arterial Disease
Thrombosis of an atherosclerotic stenosed artery
Thrombosis of an arterial bypass graft
Embolism from heart, aneurysm, plaque or critical stenosis upstream (including cholesterol or atherothrombotic emboli secondary to endovascular procedures)
Thrombosed aneurysm with or without embolization
*Two of the three conditions (deep vein thrombosis, neuropathy) that may mimic arterial occlusion should be expected to have arterial pulses, except if occult chronic peripheral arterial disease existed prior to the acute event.
Low cardiac output makes the chronic arterial ischemia more manifest in terms of symptoms and physical findings.
Source: Reproduced with permission from Norgren L, Hiatt WR, Dormandy JA, et al: Inter­society consensus for the management of peripheral arterial disease (TASC II). J Vasc Surg 45: S5A, 2007. Abbreviation: HIV = human immunodeficiency virus.
DIAGNOSIS
Obtain an adequate history, focusing on the timing and acuity of symptom onset, pattern of claudication, any previous revascularization or diagnosis of ischemia, and assessment of risk factors. Patients with known peripheral arterial disease or previous revascularization may have subacute symptoms due to the development of collateral vessels. A history of an abruptly ischemic limb in a patient with atrial fibrillation or recent myocardial infarction strongly suggests an embolus. Acute ischemia in the limb of a patient known to have advanced peripheral arterial disease is more likely due to thrombosis or a low cardiac output state. In patients without antecedent claudication and a normal uninvolved limb, embolic occlusion is likely (Table
61­5).
TABLE 61­5
Embolic Versus Thrombotic Occlusion
Factor Embolism Thrombosis
History of No Yes claudication
Physical examination Normal contralateral limb Marked signs of occlusive arterial disease bilaterally
Source identified Often None
Timing Sudden, exact time known More gradual
Radiologic features Sudden abrupt cutoff in blood flow with no collateral circulation and minimal diseased Widespread disease with collaterals present and gradual narrowing of blood flow vessel seen
On physical examination, look at the skin and palpate peripheral pulses of both extremities, comparing the less or unaffected and the affected limbs. Shiny, hyperpigmented skin with hair loss and ulceration, muscle atrophy, and poor pulses are the hallmarks of chronic peripheral arterial disease.
Listen to the heart and abdomen, seeking bruits and murmurs. POCUS helps detect an abdominal aortic aneurysm. Use a hand­held Doppler US device over pulse areas to detect presence or absence of blood flow and the amplitude. Approximately 10% of patients have only one pedal or ankle pulse present secondary to an anatomic variation. If Doppler­detected blood flow is in the affected limb, measure the ankle­brachial index to assist in risk­stratifying the patient. The ankle­brachial index is the ratio of the systolic blood pressure with the cuff just above the malleolus (with the Doppler probe over the posterior tibial or dorsalis pedis artery) to the highest brachial pressure in either arm. Patients with chronic peripheral arterial disease have an ankle­brachial index of <0.9, while values of <0.4 suggest severe disease. An ankle­brachial index of >1.3 is likely secondary to a noncompressible vessel. In such cases, do more detailed pressure measurements like a toe­brachial pressure using specialized equipment. (See Video: Ankle Brachial Index)
Video 61­1: Ankle Brachial Index
Used with permission from Henderson McGinnis.
Play Video
LABORATORY EVALUATION
Aside from seeking markers of cellular ischemia or injury (e.g., creatine kinase, myoglobin, and serum lactate), assess the metabolic status (electrolytes and glucose), renal function (BUN and creatinine plus urinalysis), potential anemia and infection (CBC), and bleeding tendency (prothrombin and partial thromboplastin times). Levels of cardiac injury markers and ECG may identify triggers including infarction or rhythm change.
IMAGING
Acute critical limb ischemia is a time­sensitive diagnosis; once suspected, consult a surgeon as soon as possible, even while obtaining diagnostic imaging. Duplex US is very accurate for detecting complete or incomplete arterial obstruction. Sensitivity declines for localization of thromboembolic occlusion at or below the calf level. Emergency physician–performed POCUS focusing on the aorta, iliac vessels, and femoral artery bifurcation may localize emboli or thromboses, expediting diagnosis and management.18 Transthoracic cardiac echocardiography can help detect embolic sources, and transesophageal approaches add the ability to detect aortic root pathology.
Arteriography often occurs in the operating room or intervention lab just prior to direct therapy. CT with contrast is the most readily available study in the ED, and it has a sensitivity similar to that of conventional uniplanar contrast studies in large vessels. MRI has higher sensitivity and specificity than CT angiography but is less readily available. The selection of most timely and appropriate imaging technique is best a joint decision between the ED physician, vascular surgeon, and/or interventional radiologist.
TREATMENT
The objectives of therapy for acute arterial obstruction are restoration of blood flow to preserve limb and life and prevention of recurrent thrombosis or embolism (Table 61­6).
TABLE 61­6
ED Medical Therapy for Acute Limb Ischemia
Intervention Comments
Unfractionated heparin19  units/kg IV bolus followed by infusion of  units/kg/h
Antiplatelet therapy19 Aspirin 325 milligrams PO first dose or clopidogrel  milligrams if patient is allergic to aspirin
Pain control As needed for patient comfort and cooperation
Optimize perfusion Treat low­flow states and shock
Place extremity in dependent position
Environment protection Protect ischemic limb from temperature extremes
In the ED, IV unfractionated heparin (weight­based  units/kg bolus followed by an infusion of  units/kg/h) is the initial therapy of choice. It prevents clot extension, recurrent embolization, venous thrombosis, microthrombi distal to the obstruction, and reocclusion after reperfusion.19,20 Direct thrombin inhibitors, such as lepirudin or argatroban, are an alternative treatment option when heparin­induced thrombocytopenia with thrombosis is of concern.19,21 Aspirin (325 milligrams in naive patients) may enhance clot reduction through antiplatelet actions. Pain management and optimization of limb perfusion by treating low­flow states such as heart failure are also important steps in care.
Stratifying patients with acute limb ischemia by Rutherford criteria (Table 61­2) in conjunction with early surgical consultation guides initial care. Patients with stage I and stage IIa limb ischemia may undergo diagnostic imaging workup prior to more definitive treatments. Patients with stage IIb ischemia often require immediate revascularization without additional prior diagnostic imaging. Patients with stage III ischemia have irreversible damage and likely require amputation. The vascular surgeon will determine definitive treatment, which can include catheter­directed thrombolysis, percutaneous mechanical thromboembolectomy, revision of an occluded bypass graft, and revascularization with either percutaneous transluminal angioplasty or standard surgery.2,18 Catheter­directed intra­arterial thrombolysis is more common now than systemic IV thrombolysis for peripheral artery embolic or thrombotic disease.19,20
In a subacute thrombotic occlusion with a well­developed collateral blood supply, medical management is common.
The longer­term nonsurgical management of peripheral arterial disease focuses on the combination of smoking cessation, structured exercise, and pharmacotherapy. Antiplatelet therapy with either aspirin (75 to 100 milligrams daily) or clopidogrel (75 milligrams daily) can reduce mortality from cardiovascular causes in patients with peripheral arterial disease. Dual antiplatelet therapy is not initially recommended.19
The American College of Cardiology/American Heart Association 2016 guidelines include cilostazol, a phosphodiesterase inhibitor, as a Class I recommendation for the treatment of intermittent claudication. Pentoxifylline is no longer recommended.19,20
A multidisciplinary approach including a team of specialists, wound care experts, and nutritionists helps to decrease morbidity and improve long­term outcome.22
DISPOSITION AND FOLLOW­UP
Patients with acute or worsening chronic ischemia require observation, hospital admission, or immediate transfer to a center with vascular surgery capability. Patients with chronic peripheral arterial disease without an immediate threat to limb viability absent other acute illness can be discharged home to follow up with a vascular surgeon or primary care physician. Instruct patients to return immediately for worsening of symptoms (especially pain) and to start aspirin (81 milligrams daily after first dose of 325 milligrams if there are no contraindications).
UPPER EXTREMITY ISCHEMIA
INTRODUCTION
Acute upper limb ischemia is much less common than lower limb ischemia, and prompt recognition and treatment can prevent limb dysfunction or limb loss. Collateral circulation around the shoulder and elbow results in better tolerance of ischemia involving the large arteries of the upper arm, as opposed to ischemia involving the smaller vessels of the forearm and hand.23
PATHOPHYSIOLOGY
Upper limb ischemia can result from arterial embolism, thrombosis, vasospasm, or upper extremity venous thrombosis.24
Arterial embolism is the most common cause, typically from atrial fibrillation, recent myocardial infarction, or valvular heart disease. Atheroma from the aorta can dislodge and embolize.
Thrombosis of the large arteries can also lead to downstream embolization.
Arterial thrombosis most commonly occurs at the level of the subclavian or axillary arteries.25 The most common causes of large artery disease are atherosclerosis or arteritis of the subclavian artery and thoracic outlet syndrome. There are many underlying causes of small and large vessel involvement, including repetitive sport or occupational motion injuries, upper extremity injection of medications and illicit substances, subclavian or axillary artery aneurysms, cervical rib, vasculitis, hypercoagulable states, electrical and thermal injuries, or radiation therapy.23,26
Vasospasm can result from primary Raynaud’s syndrome, or as secondary Raynaud’s disease related to a large number of underlying disorders, especially autoimmune disease.24
Upper extremity deep venous thrombosis may lead to phlegmasia cerulea dolens or phlegmasia alba dolens resulting in acute upper limb ischemia.27,28 Risk factors include central venous catheterization, coagulopathy, and repeated upper extremity movement compressing the subclavian vein.28
CLINICAL FEATURES
Symptoms are primarily arm or hand claudication, hand or finger pain, and/or Raynaud’s phenomenon. Suspect large artery disease if there is exercise­induced pain in large arm muscle groups. Symptoms in the hand or fingers suggest small artery disease. Raynaud’s phenomenon is characterized by pallor due to cessation of digital artery flow, followed by cyanosis, and then hyperemia. Primary Raynaud’s syndrome typically occurs in healthy young women as a response to cold and is benign. Secondary Raynaud’s disease can occur secondary to autoimmune disease.23
Chronic arterial disease may cause poorly localized arm or hand pain with exercise that improves with rest. Associated signs may include fibrosis of the skin, muscular atrophy, hairlessness,23 or ulcerations and necrosis of the fingers.27
DIAGNOSIS
Identify pallor, cyanosis, or coolness of the affected extremity. Evaluate pulses at the radial/ulnar, brachial, and axillary levels and compare with the unaffected arm.27 Assess neuromuscular function to identify paresthesias or weakness. Obtain blood pressure in both arms. Assess pulses with Doppler evaluation, and obtain duplex venous and arterial ultrasonography of the arm to include subclavian vessels. CT angiography is needed to further direct therapy for the vascular surgeon.
TREATMENT
Consult vascular surgery if acute upper limb ischemia is suspected or diagnosed. ED treatment is outlined in Table 61­6: unfractionated heparin, aspirin, pain control, and crystalloid infusion
(if the patient is volume­depleted). Re­evaluate and assess for compartment syndrome. Definitive treatment is surgical, as is outlined in this chapter for acute lower limb ischemia.23,27
Surgical procedures such as excision of the first rib, cervical ribs, or fibromuscular bands that inhibit arterial inflow or venous outflow may be required for thoracic outlet syndrome.23
Primary Raynaud’s phenomenon is treated with measures to avoid cold exposure. Severe cases require followup, assessment for secondary Raynaud’s disease, and possible treatment with calcium channel blockers.


