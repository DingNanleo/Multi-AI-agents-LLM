## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 75: Upper Gastrointestinal Bleeding
Christopher M. Ziebell; Andrew D. Kitlowski; Janna Welch; Phillip Friesen
INTRODUCTION AND EPIDEMIOLOGY
Upper GI bleeding is any GI bleeding originating proximal to the ligament of Treitz. The overall annual incidence of upper GI bleeding ranges from  to
1­3
172 per 100,000 in Western countries. Difference in prevalence between countries is attributed to variations in Helicobacter pylori rates,
 socioeconomic conditions, and prescription patterns of ulcer­healing and ulcer­promoting medications. Increasing age, coexistent organ system
 disease, and recurrent hemorrhage are factors associated with increased morbidity and mortality.
PATHOPHYSIOLOGY
PEPTIC ULCER DISEASE
Despite a downward trend in prevalence over the past  years, peptic ulcer disease, which includes gastric, duodenal, esophageal, and stomal ulcers,
,4 is still considered the most common cause of upper GI bleeding. However, the Analysis of Clinical Outcomes Research Initiative found gastric and
 duodenal ulcers in only .6% of 7822 endoscopies performed for suspected upper GI bleeding. This number is much lower than previous estimates
,6 of up to 50%. Awareness that aspirin, NSAIDs, and smoking cause bleeding and increased recognition and treatment of H. pylori infection may be
7­10 responsible for decreased incidence.
EROSIVE GASTRITIS AND ESOPHAGITIS

Erosive gastritis, esophagitis, and duodenitis are also common causes of GI hemorrhage. Common predisposing factors include alcohol, salicylates, and NSAIDs. Infection, toxic ingestion, radiation, and stress from severe illness may also cause erosive gastritis. Stress­related mucosal disease occurs in patients with overwhelming sepsis, trauma, or respiratory failure requiring mechanical ventilation. Candida, herpes simplex virus, cytomegalovirus, and human immunodeficiency virus are potential sources of esophageal bleeding from infection.
ESOPHAGEAL AND GASTRIC VARICES

Esophageal and gastric varices result from portal hypertension and, in the United States, are most often a result of alcoholic liver disease. Although varices account for a small percentage of all cases of upper GI hemorrhage, they can rebleed and carry a high mortality rate. However, many patients with end­stage cirrhosis never develop varices; many patients with documented varices never bleed; and many patients with a documented history of varices presenting with upper GI bleeding will actually bleed from nonvariceal sites. Variceal bleeding is the cause of upper GI bleeding in cirrhotics

59% of the time, followed by peptic ulcer disease in 16% of cases. In­hospital mortality rates for any type of GI bleed in cirrhotics are essentially
 double those of noncirrhotic patients.
MALLORY­WEISS SYNDROME
Mallory­Weiss syndrome is bleeding secondary to a longitudinal mucosal tear at the gastroesophageal junction. The classic history is repeated vomiting followed by bright red hematemesis. The syndrome can be associated with alcoholic binge drinking, DKA, or chemotherapy administration.
The Valsalva maneuver, such as from coughing or seizures, is also a reported cause.
DIEULAFOY LESIONS
DDioewulnalfooayd leedsi o2n0s2 a5r­e7 ­a1r t5e:r5ie1s P o f Ythoeu Gr II Ptr aisc t1 t3h6a.t1 p4r2o.1tr5u9d.e1 2th7rough the submucosa. They are most commonly found in the lesser curvature of the
Chapter 75: Upper Gastrointestinal Bleeding, Christopher M. Ziebell; Andrew D. Kitlowski; Janna Welch; Phillip Friesen 
 stomach but may be found anywhere in the GI tract; 80% to 95% are found within  cm of the gastroesophageal junction. These lesions are
. Terms of Use * Privacy Policy * Notice * Accessibility characterized by intermittent massive GI bleeding, without the standard predisposing factors of liver disease or NSAID use. Dieulafoy lesions are difficult to diagnose endoscopically, and sometimes patients report multiple previous diagnostic maneuvers with negative results.
OTHER CAUSES
Arteriovenous malformation and malignancy are other causes of upper GI hemorrhage. Significant bleeding from ear, nose, and throat sources can also masquerade as GI hemorrhage. An aortoenteric fistula secondary to a preexisting aortic graft is an unusual but important cause of bleeding to keep in mind. Classically, this presents as a self­limited “herald” bleed with hematemesis or hematochezia, which precedes massive hemorrhage and exsanguination.
DIAGNOSIS
HISTORY
Ask about hematemesis, coffee­ground emesis, or melena. Classically, hematemesis and coffee­ground emesis suggest an upper GI source. The
 presence of melena and age <50 years old more likely indicate an upper GI bleed versus a lower GI bleed, even in patients without hematemesis.
Vomiting and retching, followed by hematemesis, suggest a Mallory­Weiss tear. Be sure to ask about prior episodes of GI bleeding and any interventions performed. A history of an aortic graft should suggest bleeding from an aortoenteric fistula. Review the patient’s medication list carefully. Salicylates, glucocorticoids, NSAIDs, and anticoagulants all place the patient at high risk for GI bleed. Alcohol abuse is strongly associated with a number of causes of bleeding, including peptic ulcer disease, erosive gastritis, and esophageal varices. Ingestion of iron or bismuth can simulate melena. Liquid medications with red dye, as well as certain foods, such as beets, can simulate hematochezia. In such cases, stool guaiac testing will be negative. Inquire about past history of GI bleeding, even though recurrent bleeding episodes may originate from different sources.
Although the medical history may suggest the source of bleeding, history can also be misleading. For instance, what initially appears to be lower GI bleeding may actually be an upper GI bleed in disguise. Bright red or maroon rectal bleeding unexpectedly originates from upper GI
 sources about 14% of the time. Although patients volunteer complaints of hematemesis or melena, if there is no vomiting or the patient has not noted tarry stools, signs may be subtle. Patients with hypotension, tachycardia, angina, syncope, weakness, confusion, or cardiac arrest may have underlying GI hemorrhage.
PHYSICAL EXAMINATION
Visual inspection of the vomitus for a bloody, maroon, or coffee­ground appearance is the most reliable way to diagnose upper GI bleeding in the ED. Consider keeping a sample of the vomitus or nasogastric aspirate at bedside for the gastroenterologist to view.
Vital signs may reveal obvious hypotension and tachycardia or more subtle findings such as decreased pulse pressure or tachypnea. Younger patients and those without comorbidities can tolerate substantial volume loss with minimal or no changes in vital signs. Paradoxical bradycardia may occur even in the face of profound hypovolemia. Remember that comorbid conditions and medications may mask the body’s physiologic response to volume loss. β­Blockers, for example, will prevent tachycardia. Patients with baseline hypertension may have relatively normal blood pressure in the setting of hypovolemia.
Cool, clammy skin is an obvious sign of shock. Spider angiomas, palmar erythema, jaundice, and gynecomastia suggest liver disease. Petechiae and purpura suggest an underlying coagulopathy. Facial lesions, cutaneous macules, or telangiectasias may be suggestive of the Peutz­Jeghers, Rendu­
Osler­Weber, or Gardner’s syndromes. A careful ear, nose, and throat examination can reveal an occult bleeding source that has resulted in swallowed blood and subsequent coffee­ground emesis. Abdominal examination may disclose tenderness, masses, ascites, or organomegaly.
Perform rectal examination to detect the presence of blood and its appearance, whether bright red, maroon, or melanotic.
LABORATORY TESTING
In patients with significant bleeding, the single most important laboratory test is to obtain blood for type and cross­match in case transfusion is needed. A CBC is also important, although the initial hematocrit level may not reflect the actual amount of acute blood loss. In addition, consider BUN, creatinine, electrolyte, glucose, coagulation, and liver function studies. Upper GI hemorrhage will elevate BUN levels through digestion and absorption of hemoglobin. A BUN:creatinine ratio ≥30 suggests an upper GI source of bleeding.  Coagulation studies, including INR, partial thromboplastin time, and platelet count, are useful in patients taking anticoagulants and those with underlying hepatic disease. Obtain an ECG in patients with underlying coronary artery disease. Silent cardiac or mesenteric ischemia can develop if bleeding decreases cardiac or mesenteric perfusion. A single elevated lactate level is a sentinel sign of severe illness. The success or failure of resuscitation efforts can be assessed by following dynamic lactate levels,
 because a rising lactate level in the hospital setting is a clear predictor of in­hospital mortality.
Routine abdominal and chest radiographs are of limited value and are not needed in the absence of specific clinical indications. Barium contrast studies are contraindicated because barium may hinder subsequent endoscopy or angiography.
In cases where traditional endoscopy is unavailable or endoscopic visualization is unable to find the source, consider tagged red­cell scintigraphy or visceral angiography. Both of these tests will demonstrate the source only in cases of active bleeding. Scintigraphy and angiography help localize the source of bleeding to determine whether medical or surgical management is optimal.
NASOGASTRIC LAVAGE
A negative nasogastric aspirate does not conclusively exclude an upper GI source. Intermittent bleeding, pyloric spasm, or edema preventing reflux of duodenal blood can cause false­negative results. Ultimately, nasogastric aspiration yields a positive result in only 23% of patients without
 hematemesis who have occult upper GI bleeding.

Nasogastric intubation and aspiration are diagnostically useful. In patients without a history of hematemesis, a positive aspirate provides strong evidence for an upper GI source of bleeding. High­risk lesions are more likely in patients with bloody aspirates. Visual inspection of the aspirate to identify bloody, maroon, or coffee­ground material verifies upper GI bleeding. Early nasogastric lavage is associated with decreased time to
 endoscopy. Nasogastric tube placement and lavage can confirm the diagnosis of upper GI bleeding and correlate with risk of high­risk lesions on
 endoscopy.
Guaiac testing of nasogastric aspirate can yield both false­negative and false­positive results. Conventional stool guaiac cards may be falsely negative.
However, guaiac cards specifically designed for upper GI sources are available. Conversely, even minimally traumatic nasogastric intubation can result in positive guaiac testing even in the face of a clear aspirate. Visual inspection of the aspirate for a bloody, maroon, or coffee­ground appearance is the most reliable way to diagnose upper GI bleeding in the ED.
If bright red blood or clots are found in the nasogastric aspirate, perform gentle gastric lavage. Room temperature water is the preferred irrigant.
Maintain the nasogastric tube on mild, intermittent suction. Suction that is too vigorous may produce gastric erosions that can confuse findings on subsequent endoscopy.

As of this writing, there is no evidence to support concerns that nasogastric tube passage may provoke bleeding in patients with varices.
RISK STRATIFICATION
Risk stratification depends on clinical judgment. There are no universally accepted pre­endoscopy risk stratification practice guidelines. However, the literature does seem to agree on those individuals that qualify as very low risk (Table 75­1). Pre­endoscopic predictors of higher risk include advanced age, comorbidities, red hematemesis, hematochezia, red blood on nasogastric aspirate, hemodynamic instability, and abnormal laboratory
24­28 studies. Other high­risk factors include prior variceal banding, clamping or cauterization of an ulcer bed, or the transjugular intrahepatic portosystemic shunt procedure.
TABLE 75­1
Upper GI Bleeding Risk
Very Low Risk High Risk
<60 y old Advanced age
No major comorbidities Comorbidities and prior endoscopic or transjugular intrahepatic portosystemic shunt procedures
No history of red hematemesis Red hematemesis
No hematochezia Hematochezia or melena
Negative nasogastric aspirate Positive nasogastric aspirate
Hemodynamically stable at ED presentation Hemodynamically unstable
Normal laboratory studies Abnormal laboratory studies
TREATMENT
Initial management is stabilization. Patients in hemorrhagic shock require emergent resuscitation, including two large­bore IVs, typed and crossmatched blood with the consideration of massive transfusion protocols, and in selected cases, early airway management. Intubating a patient with an upper GI bleed who is hemodynamically unstable can be a perilous procedure. Aggressively resuscitate prior to intubation, and consider using smaller
 doses of the induction agent to minimize peri­intubation hypotension or arrest. ED treatment is summarized in Table 75­2. TABLE 75­2
Treatment of Upper GI Bleed
Treatment Dose Comments
Blood Transfuse if ≤7 grams/dL in most; ≤9 grams/dL in older patients or patients with comorbidities transfusion
Correct Correct if INR is elevated or platelets <50,000; or if bleeding severe, correct coagulopathy unless coagulopathy contraindications to correction (e.g., stents, valves)
Omeprazole 80­milligram IV bolus then infusion Labeled use for ulcer bleeding of  milligrams/h
Octreotide 50­microgram bolus then infusion of Unlabeled use for varices; for elderly, begin at lower dose range of 25­microgram bolus and
25–50 micrograms/h infusion of  micrograms/h
Antibiotics Ciprofloxacin 400 milligrams IV or Antibiotics for cirrhotics with upper GI bleeding ceftriaxone  gram IV
BLOOD TRANSFUSIONS
When upper GI bleeding is severe, blood transfusions can be lifesaving. If a large amount of blood product is anticipated, use massive transfusion
 protocols. See Chapter , “Approach to Traumatic Shock,” for discussion of massive transfusion. In less severe cases, the decision to transfuse can be difficult because hemoglobin concentrations do not fall until after hemodilution has occurred. Individualize thresholds for transfusion based on
 underlying comorbidities and hemodynamic status. Liberally transfusing all bleeding patients using a high threshold (hemoglobin <9 grams/dL) can
 cause harm. A restrictive transfusion threshold using hemoglobin concentrations of <7 grams/dL in most patients and <9 grams/dL in older patients
,31 with comorbidities who are not tolerating the acute anemia is recommended.
COAGULOPATHY
In patients with life­threatening bleeding receiving anticoagulants, reverse the coagulopathy without concern for the INR unless there are contraindications to reversal, such as cardiac or vascular stents or prosthetic valves. In less severe bleeding, carefully consider the risks of reversal therapy. An INR ≥1.5 is a significant predictor of mortality in patients with an upper GI bleed who are receiving anticoagulants.  International
,33 consensus guidelines recommend reversal of coagulopathy for upper GI bleed patients who have an elevated INR or platelet counts <50,000/μL.
Coagulopathies from other causes such as the newer oral antithrombin and Xa inhibitors should be managed according to institutional protocols. See
Figure 239­1 and Table 239­4 in Chapter 239, “Thrombotics and Antithrombotics,” for recommendations for anticoagulant reversal. Reversal should not delay time to endoscopy. Tranexamic acid, in a small systematic review study, has been shown to reduce the risk of death in patients with upper GI
 bleeding, but a much larger randomized controlled trial is due to be published soon.
PROTON PUMP INHIBITORS

Consensus guidelines continue to recommend proton pump inhibitors for patients with nonvariceal bleeding from peptic ulcer disease. When
 proton pump inhibitors are given at high dose, the gastric pH remains neutral. Clot formation from platelet aggregation is dependent on a pH >6.0. 
Administer a high­dose proton pump inhibitor such as omeprazole  milligrams IV bolus followed by infusion of  milligrams/h because the cause of bleeding cannot be determined without endoscopy. In patients with peptic ulcer bleeding, proton pump inhibitors reduce the need for surgery, the
 length of stay in the hospital, and signs of bleeding.
SOMATOSTATIN ANALOGUES/OCTREOTIDE
Octreotide is a long­acting analogue of somatostatin that elicits several actions in patients with upper GI bleeding. It inhibits the secretion of gastric
 acid, reduces blood flow to the gastroduodenal mucosa, and causes splanchnic vasoconstriction. The dose is a 50­microgram bolus followed by a
 continuous infusion of  to  micrograms/h. Octreotide does not appear to provide a clear benefit on mortality, but when combined with early
 endoscopy, it may reduce bleeding.
ANTIBIOTICS
Patients with cirrhosis have an impaired immune system and have an increased risk of gut bacterial translocation during an acute bleeding episode.
Prophylactic antibiotics (e.g., ciprofloxacin 400 milligrams IV or ceftriaxone  gram IV) reduce infectious complications, rebleeding, days of
 hospitalization, mortality from bacterial infections, and all­cause mortality, and should be started as soon as possible.
PROMOTILITY AGENTS

Erythromycin and metoclopramide are examples of promotility agents used to enhance endoscopic visualization. Consider administration if the
 patient is undergoing endoscopy in the ED and the patient is suspected to have large amounts of blood in the upper GI tract.
ENDOSCOPY
Upper GI endoscopy is the diagnostic study of choice. Endoscopy allows visualization of the source of bleeding (in most cases) and administration of
 hemostatic therapy. The optimal timing relates to the severity of the bleeding. Early endoscopy (within 6–24 hours of presentation for unstable
 patients if adequately resuscitated and 12–36 hours for stable patients ) is recommended for most patients because it is associated with decreased in­
,20,44­47 hospital mortality, a significant cost reduction, and decreased length of stay.
Endoscopic treatment options commonly used for variceal bleeding include variceal ligation and sclerotherapy. Clips, thermocoagulation, and sclerosant injections alone or in combination with epinephrine injections are commonly used in ulcerative lesions.
In some practices, the ED physician is asked to provide sedation for the endoscopist. Pretreat with an antiemetic such as ondansetron. Use short­acting titratable drugs with both analgesic properties (fentanyl) and sedative properties (midazolam or propofol). Ideal agents can be reversed if the patient’s
48­50 condition changes. In unstable patients, consider using cardiovascular stable agents such as etomidate or ketamine. While providing sedation, consider that the most noxious part of the procedure is when the scope is passed around the tongue.
BALLOON TAMPONADE
Balloon tamponade is an effective short­term solution for life­threatening variceal bleeding. Today, it is generally reserved for temporary stabilization of patients for transfer to an appropriate institution or until endoscopy can be done. The Sengstaken­Blakemore tube (which has a 250­mL gastric balloon, an esophageal balloon, and a single gastric suction port) and the Minnesota tube (with an added esophageal suction port above the esophageal balloon) are examples of balloons that have been used. Tube placement is discussed in Chapter , “Gastrointestinal Procedures and
Devices.”
SURGERY
Patients who do not respond to both pharmacologic and endoscopic treatments may require emergent surgery. In patients with variceal bleeding, there are two basic types of operations: shunt operations (transjugular intrahepatic portosystemic shunt procedure) and nonshunt operations
(esophageal transection or gastroesophageal junction devascularization). In nonvariceal bleeding, percutaneous embolization or subtotal or total gastrectomy can be performed. Emergent surgical consultation is considered prudent in case of uncontrolled bleeding.
DISPOSITION AND FOLLOW­UP
Patients with significant upper GI bleeding require intensive care unit admission and early endoscopy. Very­low­risk patients (Table 75­1) may be eligible for ED observation or be discharged home with adequate outpatient follow­up.


