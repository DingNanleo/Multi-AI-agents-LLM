## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 195: Calcium Channel Blockers
Clifford P. Masom; Christian Tomaszewski
INTRODUCTION
Calcium channel blockers (CCBs) are commonly used for the treatment of hypertension and angina pectoris and for ventricular rate control in supraventricular dysrhythmias. Less common uses include migraine prophylaxis and treatment of esophageal spasm, pulmonary hypertension, or
 arterial vasospasm due to Raynaud’s disease.
PHARMACOLOGY
Understanding the physiology of calcium in the cardiovascular system is crucial to understanding the effects of CCBs. Influx of calcium is regulated by
L­type calcium channels, which are found predominantly in the heart, vascular smooth muscle, and pancreatic β islet cells. Intracellular calcium facilitates sinoatrial node depolarization and propagation of the electrical signal through the atrioventricular node. Additionally, myocytes rely on L­ type channels to allow intracellular calcium influx during the plateau phase (phase 2) of the action potential, which signals the release of stored calcium from the sarcoplasmic reticulum, allowing myocardial contraction. Calcium influx is also necessary for the release of insulin. Therefore, CCBs have multiple effects by blocking the entry of calcium required for normal pacemaker activity, atrioventricular nodal conduction, myocardial
 contraction, and insulin release.
At therapeutic concentrations, CCBs bind to the α subunit of the L­type calcium channel, causing the channel to favor the closed state and thereby
 decreasing calcium entry. At very high concentrations, some CCBs (notably verapamil) may occupy the channel canal and completely block calcium entry. The results are profound smooth muscle relaxation, weakened cardiac contraction, blunted cardiac automaticity, and intracardiac conduction
 delay. Clinically, these effects produce hypotension and bradycardia. Animal data suggest that verapamil overdose also impairs myocardial
 carbohydrate intake, which contributes to the negative cardiac inotropy. All CCBs undergo hepatic metabolism through CYP3A4. The three main pharmacologic classes of CCBs are phenylalkylamines, benzothiazepines, and dihydropyridines (which is the class that includes most newer CCB agents) (Table 195­1). It is easiest to think of CCBs as dihydropyridines (all CCBs with generic names ending in “pine”) and nondihydropyridines.
TABLE 195­1
Oral Calcium Channel Blockers
Standard Preparation (IR) Maximum Adult Daily Dose
Class Comments
Half­Life (h) (milligrams)
Nondihydropyridines More cardioselective
Phenylalkylamines
Verapamil 2–5 480 for IR and ER Most potent negative inotrope of all CCBs
Benzothiazepines

Diltiazem 3–5 480 for IR and 540 for ER
Chapter 195: Calcium Channel Blockers, Clifford P. Masom; Christian Tomaszewski 
. Terms of Use * Privacy Policy * Notice * Accessibility
Dihydropyridines (most newer calcium channel More selective for blockers fall into this class) vasculature
Nifedipine  180 for IR and  for ER
Amlodipine 30–50 
Nicardipine 8–14 120 for IR and ER
Felodipine  
Isradipine 
Nimodipine Early: 1–2; terminal: 8–9 360
Nisoldipine 7–12 
Abbreviations: ER = extended release; IR = immediate release.
All CCBs relax vascular smooth muscle, reduce pacemaker activity, and decrease cardiac contractility. However, these effects occur at different dose
 ranges for each drug. All three CCB classes increase coronary blood flow in a dose­dependent fashion. Each group binds a different region of the calcium channel and has different affinities for calcium channels in various tissues. Verapamil is the most potent negative inotrope of all CCBs. At any
 concentration, it causes at least as much depression of heart contraction as it does vascular smooth muscle dilatation. The combined cardiovascular
 effect may be one reason that verapamil overdose causes more deaths than all other CCBs combined.
Dihydropyridines bind more selectively to vascular smooth muscle calcium channels than to cardiac calcium channels and therefore relax smooth muscle at concentrations producing almost no negative inotropy. The difference in the effects of these agents is the reason for preferential use of
 specific agents in particular clinical situations. The nondihydropyridines, verapamil and diltiazem, are used to manage hypertension, achieve rate control in atrial flutter and atrial fibrillation, and abolish supraventricular reentrant tachycardias. Dihydropyridines are typically used to treat diseases
 with increased peripheral vascular tone, such as hypertension, Prinzmetal’s angina, and vasospasm after subarachnoid hemorrhage.
The original three CCBs—verapamil, nifedipine, and diltiazem—all have relatively short serum half­lives (Table 195­1). Consequently, extended­release
(ER) formulations have been developed for all three. Because ER formulations prolong drug absorption, onset of effect may be delayed and toxicity
,9 may be prolonged following overdose. Several of the newer dihydropyridines have prolonged duration of action and, therefore, are generally not formulated as ER products. Because newer formulations are released frequently, it is helpful to consult with the ED pharmacist or contact a regional poison control center for help in determining if a given product ingested in an overdose is formulated as an immediate­release (IR) or ER preparation.
CLINICAL FEATURES
The most prominent and life­threatening effects are an extension of the therapeutic effects on the cardiovascular system, particularly decreased cardiac output and peripheral vasodilation. Hypotension is the most common physiologic abnormality after
,11 overdose. Patients with moderate verapamil or diltiazem (nondihydropyridines) poisoning often have sinus bradycardia, varying degrees of
 atrioventricular block, and hypotension. Atrioventricular block occurs more often with verapamil than with diltiazem or nifedipine. Mild or moderate
 dihydropyridine overdoses usually cause peripheral vasodilatation with resultant hypotension and reflex tachycardia. Like all CCBs, dihydropyridines lose their selectivity in large overdoses and may present with sinus bradycardia or normal rate in severe toxicity. All CCBs may cause complete heart block, depressed myocardial contractility, and vasodilatation that ultimately results in cardiovascular collapse.
Pulmonary and CNS effects are generally secondary to decreased myocardial function and impaired organ perfusion. Cardiogenic pulmonary edema is sometimes observed in severe overdoses, especially if large volumes of crystalloid are infused during resuscitation. Acute lung injury (noncardiogenic
,14 pulmonary edema) has also been reported. Seizures, delirium, stroke, and coma have been described and are presumed to be secondary to cerebral hypoperfusion. Alteration in consciousness in the absence of hypotension should not be attributed to CCB toxicity; in such a scenario,
 evaluate for other causes of mental status alteration. Nausea and vomiting are common. Life­threatening GI complications include bowel necrosis and ischemia, even without hypotension. ER products can cause development of bezoars.
DIAGNOSIS
POTENTIAL TOXICITY
Adults receiving long­term therapy with CCBs can develop hypotension, bradycardia, or cardiac conduction abnormalities if they ingest as little as twice
 their regular daily dose. It is hypothesized that patients receiving long­term CCB therapy have comorbidities and may be taking additional medications, such as other antihypertensives, that render these patients sensitive to adverse effects from relatively small increases over their usual
,17
CCB regimen. Children may be sensitive to CCB toxicity, and deaths have been reported after even single­tablet ingestion. Therefore, all pediatric
CCB ingestions should be referred for medical attention and observation.
ER preparations complicate overdose management by delaying the onset of toxicity. IR CCBs generally display toxicity within  to  hours and up to 
 ,12,15,18 hours after ingenstion. ER preparation may delay toxicity to  to  hours after ingestion, with reports up to  hours after ingestion. It is therefore important to determine the exact formulation of the ingested agent to guide management decisions. If the history cannot identify the exact formulation, the clinician should assume it is ER and modify treatment conservatively. In addition to the exact formulation ingested, other important aspects in the history are the time of ingestion and the possibility of co­ingestants that may contribute to toxicity.
ECG findings include sinus bradycardia, varying degrees of atrioventricular block, and slowing of intraventricular conduction. Because dihydropyridines initially have greater effects on smooth muscle dilation then they do on myocardium, reflex tachycardia is commonly seen with low to moderate toxic ingestions of these agents. In contrast, significant overdoses of verapamil or diltiazem are frequently associated with junctional and ventricular escape rhythms.
Laboratory testing and imaging are done to assess the overall metabolic state of the patient and to identify systemic complications of ingestion. Review all patient medications, and obtain digoxin levels if there is access to, or the patient is taking, digoxin. Determine if β­blockers are part of the patient’s therapy or are also ingested as part of the overdose. Hyperglycemia is often noted after CCB ingestion, which differentiates it from β­blocker ingestion, which typically results in euglycemia or rarely hypoglycemia. CCBs inhibit calcium­mediated insulin secretion from the β islet cells in the pancreas,
 impeding the use of carbohydrates; CCBs also increase insulin resistance by unclear mechanisms. Hyperglycemia in the setting of a CCB overdose is
 considered a poor prognostic indicator.
Systemic hypoperfusion may cause a lactic acidosis with an elevated anion gap and low serum bicarbonate level. Hypokalemia may be observed in severe overdoses. Serum calcium levels are usually normal. Ionized serum calcium levels may be followed during treatment with IV calcium preparations, but the optimum serum calcium level for patients with severe CCB poisoning is unknown. CCB serum concentrations are not routinely available and are not used in management. Screen blood and urine for other potential toxins after suicidal overdose.
DIFFERENTIAL DIAGNOSIS
A few conditions and other drug toxicities can produce bradycardia, atrioventricular block, and hypotension (Table 195­2). Hypothermia should be detected during vital sign assessment. Myocardial infarction may be evident on the initial or subsequent ECG. Suspect hyperkalemia in patients with renal failure.
TABLE 195­2
Differential Diagnosis of Bradycardia, Atrioventricular Block, and Hypotension
Hypothermia
Acute coronary syndrome
Hyperkalemia
Hypothyroidism
Cardiac glycoside toxicity
β­Blocker toxicity
Antiarrhythmic drugs class IA and IC toxicity
Central α ­adrenergic agonist (clonidine or tetrahydrozoline) toxicity

Large overdoses of sedative­hypnotics and muscle relaxants
It may be difficult to distinguish CCB toxicity from cardiac glycoside toxicity; patients may be taking these drugs for the same indications and at the same time (see Chapter 193, “Digitalis Glycosides”). In general, patients with chronic digoxin poisoning have greater ventricular excitation, including rate and ectopy, than patients with CCB toxicity. In acute overdose, digoxin toxicity may be distinguished by hyperkalemia. However, because the main manifestations of acute cardiac glycoside poisoning are heart block and bradycardia, bedside differentiation may be difficult.
Toxicity from β­adrenergic antagonists may be clinically indistinguishable from CCB toxicity (see Chapter 194, “Beta­Blockers”). In general, β­blocker toxicity is not as severe, and patients tend to have low to normal glucose and normal to elevated serum potassium levels. On physical exam, a patient with β­blocker toxicity may appear “cool and clammy” as compared to a patient with CCB toxicity who may be warmer with flushed skin (due to arteriolar vasodilation). However, these findings are not consistent enough to have reliable diagnostic value. Fortunately, the treatment for these two
 poisonings is similar, with calcium, adrenergic agonists, glucagon, insulin, and pacing considered useful therapy for both.
TREATMENT
Begin resuscitation, obtain an ECG, and institute cardiopulmonary monitoring (Table 195­3). Evaluate all patients, especially those with altered mental status, for hypoglycemia and opioid toxicity. Decreased level of consciousness following CCB ingestion is a result of cerebral hypoperfusion or co­ingestion. Administer oral activated charcoal if within  hour of ingestion of IR and ER preparations, provided patient can protect his or her airway, or intubate as needed as mental status deteriorates. Provide early airway management in patients with mental status change or hemodynamic
 instability. Endotracheal intubation may minimize the risk of aspiration associated with GI decontamination. Vomiting is not just associated with decontamination; glucagon administration may also precipitate vomiting.
TABLE 195­3
General Treatment for Calcium Channel–Blocker Overdose* Treatment Comments
Monitoring Initiate cardiopulmonary monitoring and obtain ECG.
CBC; serum electrolytes and metabolic panel; magnesium, calcium, and phosphorus; For all patients with potentially toxic overdose. Follow glucose
VBG and serum lactate; glucose; digoxin level as indicated levels.
Naloxone If signs of opioid toxicity.
Single­dose activated charcoal; protect airway If ingestion within  h and no vomiting or altered mental status; for children even if one tablet ingested.
Multidose activated charcoal; protect airway For ER preparations.
IV crystalloid for hypotension Overaggressive treatment can cause pulmonary edema.
Endotracheal intubation Early intubation if altered mental status or hemodynamic instability.
Abbreviations: ER = extended release; VBG = venous blood gas.
*See Figure 195­1 for treatment of severe toxicity.
Following airway management, provide cardiovascular stabilization. Give IV crystalloids for hypotension, but overaggressive fluid administration may produce or worsen pulmonary edema. The goal of treating bradycardia is to increase end­organ perfusion rather than restore a specific heart rate; some patients with heart rates of  to  beats/min can maintain adequate blood pressure and perfusion and therefore require only monitoring.
Conversely, patients may respond to cardiac pacing with an increase in heart rate to  to 100 beats/min without improvement in blood pressure or perfusion; they may require additional therapy to improve inotropy.
Therapies to increase heart rate include medications and cardiac pacing. Atropine alone is rarely effective for CCB­induced bradycardia, but
 administration is commonly recommended. Calcium salts may improve both heart rate and blood pressure, but the response is variable.
Transvenous or transcutaneous pacing is indicated for hypotensive patients with severe bradycardia (heart rate <30 beats/min), and may improve rate but may not correct hypotension.
Persistent hypotension after infusion of crystalloids, administration of calcium salts, and treatment of bradycardia should be treated with adrenergic vasopressors, high­dose insulin (HDI), or both. Recommendations for HDI and additional therapies are based on animal data and human case reports
21–23 or series, with the caution that case reports often document the use of multiple therapies simultaneously. In critically ill patients, it is helpful to have early consultation with a toxicologist or the poison control center to assist with the administration of infrequently used treatments.
GI DECONTAMINATION
Activated Charcoal
Given the lethality of CCBs and lack of an effective antidote, perform GI decontamination with activated charcoal. CCBs bind well to activated charcoal, and activated charcoal should be given to adults following any potentially significant IR or ER exposure, especially if presentation is within an hour of
 ingestion. Give activated charcoal after accidental ingestion of verapamil in children, because life­threatening toxicity has occurred from a single tablet. Give multiple­dose activated charcoal after ingestion of an ER preparation.
Ipecac

Ipecac syrup to induce emesis is not recommended.
Gastric Lavage
Routine gastric lavage is not recommended because risks outweigh benefits. Late gastric lavage is recommended by some toxicologists for a patient who presents within an hour of ingesting an amount significantly in excess of toxic exposure or for any patient who requires intubation after CCB ingestion.
Whole­Bowel Irrigation
Given the potential for severe toxicity, consider whole­bowel irrigation (WBI) with polyethylene glycol for patients with large ingestions of ER
 products. A large amount of medication may be removed through WBI. Monitor closely, because complications from WBI may contribute to
 hemodynamic instability.
CALCIUM SALTS
Exogenous calcium increases the extracellular calcium concentration and increases the transcellular gradient, driving calcium intracellularly through unblocked calcium channels. Administration of calcium salts has improved blood pressure in animal models and in human case reports of CCB
26­29,18 toxicity. However, the effects are variable, and patients with significant toxicity may not respond to calcium therapy alone.
Calcium chloride (13.6 mEq per 1­gram ampule) is preferred to calcium gluconate (4.5 mEq per 1­gram ampule) because it provides triple the amount of calcium per volume. Use a central line for infusion of calcium chloride to avoid soft tissue necrosis that can be associated with extravasation. The dose of calcium chloride is a 1­gram (10 mL of 10% solution) IV bolus over  minutes in adults (pediatric dose is  milligrams/kg or .15 mL/kg of the
10% solution). Calcium gluconate can be given at three times this amount. The effects of calcium administration may be transient, and repeat dosing up to every  to  minutes is commonly required. Alternatively, a continuous infusion of calcium chloride  to  grams/h may also be used in adults (pediatric dose is  to  milligrams/kg per hour). Measure ionized serum calcium levels every  minutes after the initial infusion is started and every  to  hours thereafter. A calcium concentration goal of approximately .5 to  times normal should be achieved.
However, for patients who do not respond to other therapies, it is reasonable to continue calcium administration even when serum calcium levels are considerably elevated.
An acceptable level for hypercalcemia has not been defined. Published case reports of CCB poisoning describe survival following administration of 
 grams of calcium chloride over  hours resulting in a serum calcium level of  milligrams/dL (5.94 mmol/L) and death from iatrogenic
 hypercalcemia with a serum calcium level of .3 milligrams/dL (8.07 mmol/L). A safe but effective dose of calcium salts to use in the treatment of CCB toxicity is unclear. If repeat dosing or continuous infusions are used, hypercalcemia and/or hypophosphatemia can occur. Although monitoring of serum ionized calcium and phosphorus concentrations during repeated or prolonged calcium therapy is recommended, it is unclear if such electrolyte abnormalities have clinical consequence or should be treated. Consultation with toxicology can assist with this management.
ADRENERGIC AGENTS
Patients who do not respond to calcium administration or who require repeated doses require adrenergic agonists, typically
21–23 epinephrine or norepinephrine, titrated to a mean arterial pressure of  mm Hg (Figure 195­1).
FIGURE 195­1. Treatment algorithm for severe toxicity. After giving fluids and calcium, if inadequate response, give glucagon for hypotension. Give atropine and institute cardiac pacing for bradycardia. Consider pretreatment with an antiemetic when giving glucagon. When a patient is refractory to these treatments, high­dose insulin (HDI) and vasopressors are the next treatments recommended. HDI can be given in lieu of vasopressors; however, the recommendation is to give in concert with vasopressors because HDI response takes  to  minutes. Once there is a response, wean vasopressors first. Extracorporeal membrane oxygenation (ECMO) or lipid emulsion therapy is usually warranted if the previous modalities fail, with the authors’ preference being ECMO. If patient is to start ECMO, discuss the use of lipids with managing team before starting. If patient is not at an ECMO facility and patient cannot be transferred, lipid emulsion therapy can be started. See also Table 195­4. No single adrenergic vasopressor is consistently effective. A response may occur with dopamine, epinephrine, norepinephrine, vasopressin,
31–33 dobutamine, or isoproterenol. Patients with decreased contractility and peripheral vasodilatation, especially in the face of relative bradycardia, may benefit from an agent with both α­ and β­agonist effects, such as epinephrine or norepinephrine (Figure 195­1). Methylene blue, a nitric oxide scavenger and guanylate cyclase inhibitor used for vasoplegia, and phosphodiesterase inhibitors such as amrinone, milrinone, and enoximone have
34–39 been reported to improve blood pressure in animal studies and human case reports.
When standard doses are inadequate, it is reasonable to use high doses or multiple agents titrated to achieve a mean arterial blood pressure of  mm

Hg, although there is risk of ischemic complications. Alternatively, another approach, such as HDI, glucagon, or lipid emulsion, can be considered.
HIGH­DOSE INSULIN THERAPY
40–47
HDI is a promising treatment for the myocardial suppression associated with CCB poisoning. Potential mechanisms of action include positive
 inotropic effects of insulin, increased calcium entry, and improved myocardial use of carbohydrates as an energy source. Insulin increases
 intracellular transport of glucose into cardiac and skeletal muscle and has inotropic properties. There are no clinical trials comparing HDI therapy directly to other treatments, but multiple human case reports show that HDI improves perfusion in CCB poisoning unresponsive to other therapies,
42–48 with a therapeutic response noted within  to  minutes. The main adverse effect is potential hypoglycemia, which is easily detected with pointof­care glucose testing and treated with dextrose. Hypokalemia is also seen from intracellular potassium shifts. Replace potassium if potassium falls to
<2.8 mEq/L (<2.8 mmol/L).
Given benefit seen in animal models and clinical reports, begin HDI for hypotensive patients, especially if they do not respond to vasopressor therapy (Figure 195­1).

Doses of insulin used for HDI are greater than those for diabetic treatment (Table 195­4). An initial insulin bolus is followed by a continuous infusion along with a dextrose infusion to prevent hypoglycemia (Table 195­4). Although traditional infusion doses were started at  unit/kg per hour,
,51 several protocols use a higher dose of up to  units/kg per hour, which is considered high­dose therapy. A recent randomized controlled trial of pigs poisoned by propranolol showed a dose response over time, with improvements of cardiac output with increasing HDI doses up to  units/kg per
  hour. No ceiling dose has yet been established. Page et al showed no significant increase in complications between use of lower­ and higher­dose insulin in a retrospective study. The hemodynamic response to HDI is usually seen in  to  minutes, so begin the infusion at  unit/kg per hour, and increase the infusion rate if there is no clinical improvement within  minutes. Monitor the serum glucose concentrations and adjust the dextrose infusion to maintain an acceptable glucose range. Maintain the HDI infusion until toxicity has resolved; durations of  to  hours may be necessary.
The insulin infusion may be reinstituted if toxicity recurs. Due to persistent elevated insulin concentrations, dextrose supplementation may be required for up to  hours after the infusion is discontinued.
TABLE 195­4
Protocol for High­Dose Insulin Therapy in Severe Calcium Channel Blocker Overdose
Check serum glucose, and if <200 milligrams/dL (<11 mmol/L), administer  mL of 50% dextrose (0.5 gram/mL) in water IV (children,  mL/kg of 25% dextrose).
Administer regular insulin  unit/kg IV bolus.
Begin regular insulin infusion at  unit/kg per hour along with dextrose 10% (0.1 gram/mL) in water at 200 mL/h (adult) or  mL/kg per hour
(pediatric).
Titrate insulin infusion rate up to  units/kg per hour according the hemodynamic goal of HR >50 beats/min and SBP >100 mm Hg (>13.3 kPa).
Monitor serum glucose every 15–20 min.
Titrate dextrose infusion rate to maintain serum glucose level between 100 and 200 milligrams/dL (5.3 and .7 mmol/L).
Once dextrose infusion rates have been stable for  min, glucose monitoring may be decreased to hourly.
Monitor serum potassium level and start IV potassium infusion if serum potassium level is <2.8 mEq/L (<2.8 mmol/L).
Maintain serum potassium between .8 and .2 mEq/L (2.8 and .2 mmol/L).
Abbreviations: HR = heart rate; SBP = systolic blood pressure.
GLUCAGON
Glucagon, a hormone synthesized by the pancreas, is the therapy of choice for β­adrenergic blocker poisoning because of its ability to bypass the β­ adrenergic receptor and stimulate cardiac activity via activation of adenylate cyclase (see Chapter 194, “Beta­Blockers”). In CCB poisoning, the inhibition is downstream from glucagon’s binding site; therefore, glucagon theoretically offers no advantage over other agents. Nevertheless, glucagon administration improves blood pressure in animal models, and several case reports have also noted improvement in hemodynamics after
53–56  glucagon therapy. However, failure to respond has also been reported.
The recommended glucagon dose is an initial IV bolus of  milligrams in adults and .03 milligram/kg in children given over  to  minutes (Figure 195­
1). A response is usually seen within  minutes. If there is no response, the bolus dose may be repeated. If there is hemodynamic improvement, a maintenance infusion should be initiated at  milligrams/kg per hour in adults and .05 milligram/kg per hour in children.
The main adverse effects of glucagon are vomiting and hyperglycemia; empirically give ondansetron, once it is determined that there is no QT c prolongation, hypokalemia, or hypomagnesemia. Because of the large amounts of glucagon required, hospital supplies of the drug are often rapidly depleted; plan ahead and consider making arrangements (e.g., with nearby centers) for additional glucagon.
IV LIPID EMULSION THERAPY
Lipid emulsion therapy was first described in the management of local anesthetic toxicity. Lipid emulsions appear to create a pharmacologic sink for
 fat­soluble drugs. Therapy may also provide fatty acid substrate for cardiac energy supply and improve myocyte function by increasing intracellular
 calcium levels. Lipid emulsion therapy prolonged survival in an animal model of verapamil poisoning, and several case reports described benefit in
,60
CCB ingestions unresponsive to standard therapy. There are many different commercial lipid emulsion preparations, with the major components typically being soybean oil, egg yolk phospholipids, and glycerin.
The recommended dose is a 20% lipid emulsion given as a .5 mL/kg bolus over  to  minutes, followed by a .25 mL/kg per minute infusion. If the blood pressure remains low, an additional .5 mL/kg bolus may be repeated followed by an increase in the infusion rate to .5 mL/kg per minute. The recommended upper limit for lipid emulsion infusion is about  mL/kg over the initial  minutes. If the patient’s hemodynamic stability is dependent
 on continued lipid infusion, the treatment may be continued. Case reports suggest that if sudden cardiac arrest occurs in the setting of overdose, a bolus can be given in the hope of restoring spontaneous circulation. In addition to interference with laboratory parameters (e.g., blood cell count,
 electrolytes, liver transaminases), there are rare adverse effects such as hypertriglyceridemia, hypoxemia (with high doses), and hyponatremia.
EXTRACORPOREAL CIRCULATORY SUPPORT
With lack of response to aggressive medical therapy, consider circulatory support measures, such as the placement of intra­aortic balloon pumps, the use of left ventricular assist devices, and even extracorporeal membrane oxygenation, which may provide adequate blood pressure to allow clearance
,62,63  of the drug and resolution of symptoms. Lipid emulsion therapy can cause complications with extracorporeal membrane oxygenation. Contact the extracorporeal membrane oxygenation team before starting lipid emulsion, if extracorporeal membrane oxygenation is to be used. Due to CCB’s large volume of distribution and high affinity for protein binding, hemodialysis and hemoperfusion are not beneficial in the treatment of CCB
 overdoses.
DISPOSITION AND FOLLOW­UP
In general, patients usually manifest toxicity within  hours of ingestion of IR products. Therefore, those who are asymptomatic and who have normal
 vital signs and normal ECG after a 6­hour observation period can be discharged after appropriate psychiatric evaluation. Toxicity may be delayed for
,9 up to  hours after ingestion of ER products. As a rule, patients who ingest potentially toxic amounts of ER products should be monitored for at least  hours. Contact the regional poison control center for assistance with management.


