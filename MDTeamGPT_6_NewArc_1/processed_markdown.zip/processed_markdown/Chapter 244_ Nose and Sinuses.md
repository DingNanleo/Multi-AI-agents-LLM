## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 244: Nose and Sinuses
Henderson D. McGinnis
EPISTAXIS
EPIDEMIOLOGY
,2
Epistaxis is a common occurrence, affecting 60% of the population at some point during their lifetime. The patients who seek medical attention are
,2 most commonly under  years of age and over  years of age. Common causes of epistaxis include digital trauma, a deviated septum, dry air
 exposure (lack of humidity), rhinosinusitis, neoplasia, or chemical irritants such as inhaled corticosteroids or chronic nasal cannula oxygen use.
Systemic factors that increase the risk of bleeding include chronic renal insufficiency, alcoholism, hypertension, vascular malformations such as
 hereditary hemorrhagic telangiectasia, any kind of coagulopathy, anticoagulation use, von Willebrand’s disease, and hemophilia.
ANATOMY AND PATHOPHYSIOLOGY
The superior labial branch of the facial artery joins the anterior ethmoidal and terminal branch of the sphenopalatine artery to form Kiesselbach plexus on the anterior nasal septum, which is the source of 90% of nosebleeds and can usually be visualized with anterior rhinoscopy (Figure 244­1).
The most likely source for posterior bleeds is the sphenopalatine artery, which is a terminal division of the internal maxillary artery (branch of the
,4 external carotid system). Endoscopic or open surgical techniques are needed to visualize the vessel. Sensory innervation is detailed in Figure 244­
. FIGURE 244­1. Arterial blood supply to the nasal cavity. The most common site of nasal hemorrhage is at Little’s area of the nasal septum. The most common origin of posterior epistaxis is from the sphenopalatine artery.
FIGURE 244­2. Sensory innervation of the external nose. [Reproduced with permission from Reichman EF, Simon RR: Emergency Medicine Procedures. © 2004, Eric F.
Reichman, PhD, MD, and Robert R. Simon, MD.]

Chapter 244: Nose and Sinuses, Henderson D. McGinnis 
. Terms of Use * Privacy Policy * Notice * Accessibility
CLINICAL FEATURES
Identify an anterior or posterior source of acute epistaxis with a directed history and physical examination. Ask about previous or recurrent epistaxis as well as duration and severity of the episode. Collect history concerning alcohol, drug, or medication use especially NSAID, anticoagulation, antiplatelet, or aspirin use. Review any history of trauma, prior head and neck procedures, and a personal and family history of coagulopathy.
The evaluation and management of the patient with epistaxis will be much easier and efficient if your department has a well­stocked and easily accessed ear, nose, and throat (ENT) procedure tray, kit, or cart so that you can examine the patient and attempt to control the bleeding. The kit should include a nasal speculum, bayonet forceps, headlamp, suction catheter, cotton pledgets, .05% oxymetazoline and 4% lidocaine solutions, silver nitrate swabs, and some combination of absorbable and nonabsorbable materials for anterior and posterior packing.
If there is active bleeding, wear gloves, gown, and facemask with eye shield. Assemble a focused light source, suction, and a nasal speculum. Have the patient seated and in the “sniffing” position. The sniffing position is achieved by having the patient flex and extend the head while keeping the base of the nose straight ahead. With the patient in this position, brace the speculum by resting the index finger on the tip of the nose and insert the speculum with the handle parallel to the floor. Open the blades in a cephalad­to­caudad direction to visualize the bleeding site and facilitate the performance of direct hemostatic techniques.
DIAGNOSIS
Differentiating an anterior versus posterior source of bleeding is important for treatment and disposition; failure to identify the source of bleeding is
 associated with rebleeding and return for treatment. The ability to visualize the site of bleeding depends on the adequacy of the light source and
 exposure afforded by the nasal speculum. Generally, the diagnosis of posterior hemorrhage is only made in the ED once measures to control anterior bleeding have failed. Clinical features suggestive of a posterior source include elderly patients with either inherited or acquired coagulopathy, a significant amount of hemorrhage visible in the posterior nasopharynx, hemorrhage from bilateral nares, or epistaxis uncontrolled with either
 anterior rhinoscopy or an anterior pack. Laboratory evaluation or other ancillary studies are not required unless management of comorbid illness requires it or the hemorrhage is poorly controlled. If drawing blood, obtain a CBC (with platelet count) to assess blood loss, a type and cross­match if you anticipate that the patient will require blood, a comprehensive metabolic panel looking for uremia or liver disfunction, and coagulation studies if patient is on warfarin or if coagulopathy is suspected.
TREATMENT
The initial management for epistaxis in the ED starts with a rapid primary survey addressing potential airway or hemodynamic compromise. You should obtain IV access in patients with severe bleeding and request cross­matched blood if there is hemodynamic instability. The need for transfusion
,9 is more common in patients with posterior epistaxis and those on anticoagulants. Reversal of coagulopathy with blood products can be considered based on clotting studies and individual patient context. Rapid reduction of blood pressure during an episode of acute epistaxis is generally not
 advised. In uncontrolled epistaxis requiring packing or surgical intervention, gentle reduction of persistent hypertension reduces hydrostatic
 pressure and thereby may aid clot formation.
DIRECT NASAL PRESSURE
First, ask the patient to blow the nose to expel clots to prepare mucosa for topical vasoconstrictors. Instill a topical vasoconstrictor such as oxymetazoline or phenylephrine. The patient should lean forward in the “sniffing” position and pinch the soft nares between the thumb and the middle finger for a full  to  minutes and breathe through the mouth. If the patient is uncooperative or unable to pinch their nose, fashion a handsfree pressure device made from two tongue depressors that are taped together between halfway and two thirds of the way up the depressors. Place the device on the nose and leave it undisturbed for  to  minutes. These initial measures are often sufficient to achieve hemostasis and facilitate further examination by anterior rhinoscopy.
CHEMICAL CAUTERIZATION
If two attempts at direct pressure have failed, chemical cauterization with silver nitrate is the next appropriate step for mild bleeding. Before cautery,
 anesthetize the nasal mucosa using three cotton pledgets soaked in a 1:1 mixture of .05% oxymetazoline and 4% lidocaine solution. Do not attempt chemical cautery unless the bleeding vessel is visualized. Electrical cautery should be left to the otolaryngologist due to the risk of septal perforation.
After visualizing the (anterior) bleeding site, silver nitrate sticks may be judiciously placed just proximal to the bleeding source on the anterior nasal septum. Silver nitrate requires a relatively bloodless field, as the chemical reaction leading to precipitation of silver metal and tissue coagulation cannot proceed in the setting of active hemorrhage due to washout of substrate. You may use suction to help visualize the source of the bleeding. Once a relatively bloodless field is achieved, gently and briefly (a few seconds) apply silver nitrate directly to the bleeding site. Chemical cautery should never be attempted on both sides of the nasal septum. Subsequent attempts on the same side of the nasal septum should be separated by  to  weeks to
 avoid perforation.
THROMBOGENIC FOAMS AND GELS AND TRANEXAMIC ACID
Thrombogenic foams and gels are a good option, and they may be considered after attempts have failed or in place of chemical cautery or insertion of nasal tampons. Gelfoam® and Surgicel® (oxidized cellulose) are effective hemostatic agents that can be placed simultaneously on visualized bleeding mucosa, and they are bioabsorbable, so removal is not needed. FloSeal®, another biodegradable agent, is a hemostatic gelatin matrix that is mixed in
 ,13,14 a syringe with thrombin and injected into the nasal cavity. Topical use of injectable tranexamic acid is an excellent agent for nosebleed control.
There is no standardized approach to the application of nasal tranexamic acid. Effective options described in the literature include: 200 milligrams (100 milligrams/mL concentration) atomized into the affected nostril; cotton pledget or nasal tampon saturated with 500 milligrams of tranexamic acid and
,14 placed into the affected nostril; and 500 milligrams of tranexamic acid diluted with 5cc of NS and atomized into the affected nostril.
ANTERIOR NASAL PACKING
Anterior nasal packing can be placed if direct pressure, vasoconstrictors, or chemical cautery are unsuccessful in controlling epistaxis and if thrombotic foams and gels are not available. A variety of nasal balloons or sponges are available, or an anterior pack created by layering ribbon gauze in the nasal cavity can be used.
ANTERIOR EPISTAXIS BALLOONS
Anterior epistaxis balloons (Rapid Rhino®) are easy to use and more comfortable for the patient than layered strip gauze or nasal sponges. Anterior epistaxis balloons are available in different lengths and are coated with cellulose or other materials that promote platelet aggregation. Soak the balloon with water, insert it gently along the floor of the nasal cavity, and inflate slowly with air until the bleeding stops. Read the package insert for inflation volume. Stop inflation if the patient develops discomfort. Do not inflate with saline; if a saline­filled balloon ruptures, aspiration could result.
Read specific insertion instructions for each product before use. If there is a drawstring at the distal end, tape the drawstring to the face to secure the balloon in place.
PREFORMED NASAL TAMPONS OR SPONGES
Preformed nasal tampons or sponges are made of synthetic material that expands after hydration (Figure 244­3). These devices are commercially available in 5­ and 10­cm lengths, for anterior and posterior packing, respectively. One product is Merocel®, a compressed dehydrated polyvinyl acetate sponge. Coat the sponge with water­soluble antibiotic ointment and insert it gently along the floor of the nasal cavity. If the tampon has not expanded within  seconds of placement, gently irrigate it (while in place) with  mL of normal saline to promote expansion. An alternative method is to cut the Merocel® pack lengthwise in two equal halves and coat each half with lubricating ointment. Insert the two halves parallel to each other and
 parallel with the nasal septum; irrigate each half with about  mL of normal saline. This method may provide better compression of septal bleeding.
Whichever method is used, tape the drawstring to the face (Figure 244­3) to secure the tampon in place and prevent inadvertent aspiration. Merocel®
 nasal packs work effectively but sometimes cause more pain than balloons with removal.
FIGURE 244­3. The Merocel® nasal sponge in its desiccated (left) and hydrated (right) forms.
RIBBON GAUZE PACKING
If the preceding devices are unavailable, ribbon gauze packing can be placed to control epistaxis (Figure 244­4).
FIGURE 244­4. The key to placement of an anterior nasal pack that will control epistaxis adequately and stay in place is to lay the packing into the nasal cavity in an accordion­like manner so that part of each layer of packing lies anteriorly, preventing the gauze from falling posteriorly into the nasopharynx. A. The
 first layer of / ­inch petrolatum­impregnated gauze strip is grasped approximately  to  cm from its end. B. The first layer is then placed on the floor
 of the nose through the nasal speculum (not pictured here). The bayonet forceps and nasal speculum are then withdrawn. C. The nasal speculum is reintroduced on top of the first layer of packing, and a second layer is placed in an identical manner. After several layers have been placed, it is often useful to reintroduce the bayonet forceps to push the previously placed packing down onto the floor of the nose, making it tighter and more secure. D.
A complete anterior nasal pack can tamponade a bleeding point anywhere in the anterior nasal cavities and will stay in place until removed by the provider or patient.
POSTERIOR NASAL PACKING
Failure to control hemorrhage after direct pressure, optimal use of vasoconstrictors, cautery, and anterior packing suggests (but is not diagnostic of) posterior bleeding. Bilateral anterior packing may help augment tamponade of the nasal septum. If that is not successful, the previously mentioned devices are usually available in longer lengths to provide posterior packing. If longer posterior­length packs do not work, obtain ENT consultation.
Posterior packing is associated with higher complication rates, including pressure necrosis, infection, hypoxia, and cardiac dysrhythmias, especially in patients with underlying cardiopulmonary disease, and thus, posterior packing is generally applied as a temporizing measure while awaiting ENT support. A formal nasal block may be required for analgesia, as posterior packing is often quite uncomfortable for the patient, but topical anesthesia may be sufficient if applied properly. The Rapid Rhino® has both an anterior (5.5 cm) and posterior (7.5 cm) balloon that can be inflated as required to tamponade bleeding. Figure 244­5 shows the placement of a dual balloon catheter. All posterior packing should be accompanied by an anterior pack.
FIGURE 244­5. A dual balloon epistaxis catheter providing anterior and posterior compression. There are separate ports for inflation of the anterior and posterior balloons. The anterior port can hold  mL, and the posterior balloon holds  mL. Read package insert for proper inflation volume, as dual balloon catheters vary in size. (Reproduced with permission from Reichman EF (ed): Reichman’s Emergency Medical Procedures, 3rd ed. New York, NY:
McGraw­Hill; 2019, Figure 205­19.)
If resources are limited, a satisfactory posterior pack can be achieved using a 14F Foley catheter. The procedure is as follows. Place the patient in
“sniffing position,” and anesthetize the nasal mucosa by placing three cotton pledgets soaked in a 1:1 mixture of 4% lidocaine solution and .05% oxymetazoline intranasally for  minutes. Consider cutting off the Foley tip beyond the balloon as the tip may stimulate the gag reflex. Lubricate the distal third of the catheter with lidocaine gel and advance the Foley catheter along the floor of the nasal cavity until the end is visualized in the posterior oropharynx. Inflate the balloon with  mL of air, and gently retract the catheter approximately  to  cm until it is lodged in the choanal arch of the posterior nasopharynx. Do not use saline for balloon insufflation because rupture could result in aspiration. If the balloon slides back into the nasal cavity, deflate the balloon, and advance the catheter as before. Inflate with  mL of air in total and retract to secure the balloon. Avoid using more than
 mL of air to prevent risk of pressure necrosis. Secure the pack by taping the catheter to the patient’s cheek.

In patients requiring posterior packing or in cases of uncontrolled anterior epistaxis, obtain early ENT intervention. Approximately 10% of patients admitted for epistaxis require invasive therapy; success is similar for arterial ligation or embolization, but cost and risk of stroke are higher for patients
 receiving embolization.
DISPOSITION AND FOLLOW­UP
If hemorrhage is controlled and hemodynamic stability is ensured over a period of observation (1 hour or more in the ED), patients with anterior epistaxis can be discharged home with primary care or ENT follow­up within  to  hours for removal of nonbiodegradable packing. Provide patients with instructions for simple techniques to control repeat hemorrhage and consider a short­term prescription of inhaled vasoconstrictors such as
 oxymetazoline for rebleeding. Patients on warfarin with INR levels in the desired range may continue medication. Discontinue NSAIDs for  to  days.
If anterior packing with either absorbable or nonabsorbable material is going to be in place for more than  hours, an antibiotic with staphylococcal coverage such as amoxicillin­clavulanic acid has been traditionally recommended to prevent infection with Staphylococcus aureus and possible
 ,22 associated toxic shock syndrome. However, antibiotic benefit is not clear. If the packing will be removed in  to  hours, prophylactic
  antibiotics may not be needed. Consider potential drug interactions that may increase bleeding. If the patient requires posterior packing, admission is strongly advised to monitor for complications.
NASAL FRACTURES AND SEPTAL HEMATOMA
ANATOMY
The nasal pyramid is formed by two rectangular­shaped bones that articulate with the frontal bone, the frontal process of the maxilla, and the perpendicular plate of the ethmoid to form a “tent­like” configuration (Figures 244­6 and 244­7). A large proportion of the structural integrity is maintained by a cartilaginous framework of the nasal septum, lateral processes, and medial and lateral crura of the alar cartilages (Figure 244­8).
FIGURE 244­6. A and B. Lateral impact nasal injury. [Reproduced with permission from Reichman EF, Simon RR: Emergency Medicine Procedures. © 2004, Eric F.
Reichman, PhD, MD, and Robert R. Simon, MD.]
FIGURE 244­7. Frontal impact nasal injury. [Reproduced with permission from Reichman EF, Simon RR: Emergency Medicine Procedures. © 2004, Eric F. Reichman,
PhD, MD, and Robert R. Simon, MD.]
FIGURE 244­8. The nasal cartilages and the keystone area where they articulate with the nasal bones. [Reproduced with permission from Reichman EF, Simon RR:
Emergency Medicine Procedures. © 2004, Eric F. Reichman, PhD, MD, and Robert R. Simon, MD.]
CLINICAL FEATURES
Determine the mechanism of injury to evaluate the potential location of displaced bony fragments and to assess other associated pathology, especially head and neck injury. Assess the midface, zygomatic arch, orbits, sinuses, teeth, and cervical spine. Malocclusion and midface instability suggest Le
Fort’s fracture (see Chapter 259, “Trauma to the Face”).
NASAL EXAMINATION
After a general exam, perform an examination of the nose to include an external assessment for bony crepitus, deformity, and edema (Figure 244­9).
Periorbital ecchymosis in the absence of other findings of orbital injury is suggestive of nasal fracture. Profuse epistaxis may also suggest nasal fracture. Nasal bone mobility, which is virtually diagnostic of fracture, is appreciated by grasping the dorsum of the nose between the thumb and index
 finger and attempting to rock the nasal pyramid back and forth. Perform anterior rhinoscopy after obtaining a relatively bloodless field with topical vasoconstrictors and evacuation of clots. Key components of the internal examination should include assessment for mucosal lacerations, septal fractures or deviation, and septal hematoma.
FIGURE 244­9. Nasal fracture clearly identifiable on physical examination with deformity and periorbital ecchymosis. [Photo contributed by David W. Munter.
Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, New York.]
DIAGNOSIS AND IMAGING
The diagnosis of nasal fracture is clinical, and radiologic confirmation of isolated nasal fracture is not required. The results of plain films rarely change
,24 management. The indications for closed reduction are limited to alleviation of nasal obstruction and correcting deformity to improve cosmesis.
,24
These indications are best evaluated clinically at the bedside and usually are not emergency procedures. Ultrasonography is an alternative to plain
25­27 radiographs for the diagnosis of nasal fractures and has sensitivities and specificities similar to plain radiography (Figures 244­10 and 244­11).

CT scanning is not needed for isolated nasal fractures and is best reserved when there is concern for intracranial injury or other facial fractures.
FIGURE 244­10. US still image of nasal fracture demonstrating cortical disruption. A large gap is seen between bone fragments. [Reproduced with permission from Ma
OJ, Mateer JR, Blaivas M: Emergency Ultrasound, 2nd ed. © 2008, McGraw­Hill, New York.]
FIGURE 244­11. Nasal radiograph lateral view demonstrating depressed nasal fracture with cortical disruption. [Photo contributed by Lorenz F. Lassen, MD.
Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, New York.]
TREATMENT
The main priority is the exclusion of other associated traumatic injuries (see Chapter 259) and nasal septal hematoma (see later section on septal
 hematoma). Nasal fractures with overlying lacerations should be treated similarly to other open fractures. Cerebrospinal fluid rhinorrhea is difficult to diagnose. Fluid can be sent for β­transferrin analysis. Suspicion of leaks requires further imaging and otolaryngologic or neurosurgical consultation
(see Chapter 257, “Head Trauma,” for more discussion).
Once serious injury is excluded, the management of uncomplicated nasal fractures is dictated by the timing of the examination in relation to the injury and ability to evaluate for significant displacement of the nasal pyramid. Early in the course, significant soft tissue swelling may obscure an adequate physical examination. If the patient presents immediately after the injury event, there may be opportunity to reduce a displaced nasal fracture before edema distorts the landmarks. Otherwise, it is prudent to recommend ENT consultation for an elective closed reduction within  to  days of the initial insult. Because of the development of fibrous connective tissue along the fracture line, failure to perform an adequate reduction within this time frame
 may result in an unacceptable cosmetic outcome and may ultimately require rhinoseptoplasty. Most nasal fractures do not require immediate intervention and can be managed at ENT follow­up within the specified time frame of  to  days. Closed reduction is best left to the ENT specialist.
Even simple nasal fractures in children deserve ENT follow­up because nasal deformity may develop during puberty when nasal growth accelerates.
NASAL SEPTAL HEMATOMA
Vascular supply to the septal cartilage is provided through the perichondrium. A hematoma lifts the perichondrium, disrupting blood supply to the cartilage. If a septal hematoma is identified, incise and drain the hematoma urgently to avoid ischemic necrosis of the nasal septum (Figures 244­12 and 244­13). Necrosis can lead to saddle deformity and nasal obstruction, ultimately requiring rhinoseptoplasty. Because pooled, clotted blood is a nidus for infection, unidentified septal hematomas can develop into abscesses. Systemic symptoms developing after facial trauma should prompt investigation for nasal septal abscess, and any suspicion should prompt ENT referral, urgent surgical drainage, and IV antibiotics to avoid serious complications. Untreated infected hematomas not only increase risk for saddle deformity and a poor functional outcome but can also spread
 contiguously, leading to osteomyelitis, cavernous sinus thrombosis, meningitis, and intracranial abscesses.
FIGURE 244­12. Graphic depiction of nasal septal hematoma. [Reproduced with permission from Reichman EF, Simon RR: Emergency Medicine Procedures. © 2004,
Eric F. Reichman, PhD, MD, and Robert R. Simon, MD.]
FIGURE 244­13. Trauma patient with nasal septal hematoma in the right nares. [Photo contributed by Lawrence B. Stack, MD. Reproduced with permission from Knoop
K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, New York.]
DRAINAGE OF NASAL SEPTAL HEMATOMA
The procedure for incision and drainage of a nasal septal hematoma is as follows:
. Place patient in “sniffing position,” and be prepared to perform adequate anterior rhinoscopy with a nasal speculum, light source, suction, irrigation, and packing materials.
. Properly anesthetize the nasal mucosa by placing three cotton pledgets soaked in a 1:1 mixture of 4% topical lidocaine and epinephrine 1:1000 solution for  minutes, followed by infiltrative anesthesia if required.
. Although sterile technique cannot be fully achieved in the nasal cavity, use sterile instruments, and keep the operative area as clean as possible with irrigation of foreign debris.
. While obtaining adequate visualization of the hematoma with the nasal speculum, make a small horizontal incision superficially through the mucosa, making sure you do not incise the cartilaginous septum.
. Evacuate the clot with Frazier suction or with forceps.
. Perform bilateral anterior nasal packing with nasal tampons coated in topical antibiotic ointment to prevent reaccumulation of the clot and keep the septum midline.

. Discharge with 24­hour ENT or ED follow­up. Some recommend the use of prophylactic antibiotics for patients with packing in place, but this is not necessary if the packing will be removed in  to  hours.
NASAL FOREIGN BODIES
,33
Although nasal foreign bodies are most common in children, they should also be considered in psychiatric and intellectually disabled adults.
Morbidity of undiagnosed nasal foreign bodies includes aspiration, infection, pressure necrosis, or perforation. Consider a nasal foreign body in patients with purulent unilateral nasal discharge or recurrent unilateral epistaxis. It is important to recognize button battery impaction because it may
 cause liquefaction necrosis and septal perforation. Plain radiography is a potential tool for foreign body identification, but many objects are not
 radiopaque. Nasal foreign body removal is discussed in Chapter 123, “Nose and Sinus Disorders in Infants and Children.”
SINUSITIS AND RHINOSINUSITIS
Sinusitis is inflammation of the mucosal lining of the paranasal sinuses. There are six nasal sinuses: two maxillary and two frontal sinuses, and a single ethmoid and frontal sinus. Rhinosinusitis is defined as an inflammation of the paranasal sinuses and the nasal cavity. The term rhinosinusitis is
 preferred because sinusitis is almost always accompanied by rhinitis. Depending on the duration of the disease, rhinosinusitis is classified into acute
37­40
(<4 weeks), subacute (4 to  weeks), or chronic (>12 weeks).
PATHOPHYSIOLOGY
All six paranasal sinuses are coated by respiratory mucociliary epithelium, and the sinuses drain through the ostia into the nose. Any type of acute inflammation of the mucosa leads to obstruction of the ostia, accumulation of secretions within the sinuses, and reabsorption of air, resulting in negative pressure in the sinuses and clinical symptoms. Acute rhinosinusitis, like otitis media, is usually viral. Haemophilus influenzae and

Streptococcus pneumoniae are the usual organisms in acute bacterial rhinosinusitis. Chronic infections are usually due to anaerobes, gram­negative
 bacteria, Staphylococcus aureus, and, occasionally, fungi, especially in the immunocompromised.
CLINICAL FEATURES
Acute rhinosinusitis is defined by two or more of the following symptoms: blockage or congestion of the nose, facial pain or pressure, diminished
 ability to smell or detect odors, and either anterior or posterior nasal discharge, for  days to  weeks. Additional symptoms can include tooth pain,
,38,39 fever, halitosis, and sinus pressure while bending forward or changing head position. The American Academy of Otolaryngology guidelines list the cardinal signs of rhinosinusitis as being purulent nasal drainage (not clear) accompanied by nasal obstruction or by facial pain, pressure, or
 fullness, or both. On physical examination, the patient may have pain and tenderness over the sinuses with percussion. Inspect the face for swelling and redness, and inspect the nose for mucosal swelling, anatomic abnormality, and foreign bodies. Also perform a neurologic examination, and examine the ears, eyes, and teeth to evaluate for extension of disease. Subacute and chronic sinusitis persist for  weeks or more.
DIAGNOSIS
,38,41 
The diagnosis of uncomplicated acute rhinosinusitis is based on clinical findings ; most cases are viral in etiology. Plain sinus radiographs or
CT scans are not needed. The symptoms of acute rhinosinusitis are similar to a common cold or viral upper respiratory infection, but symptom
 duration ranges from  days to up to  weeks and may present after a recent viral upper respiratory tract infection.
American Academy of Otolaryngology guidelines recommend reserving the diagnosis of acute bacterial sinusitis for patients with symptoms persistent
  for  days or more. Experts acknowledge that the evidence proving symptom duration alone can identify a bacterial etiology is weak. However, the
,42 guideline panel considered this limitation on the diagnosis as appropriate, acknowledging the low specificity of the criteria.
If a complication of rhinosinusitis is suspected by clinical presentation or duration of symptoms, CT scan (with contrast) is helpful to identify or rule
 out intracranial extension. The differential diagnosis of rhinosinusitis includes migraine headache, craniofacial neoplasm, foreign body retention, and dental caries.
TREATMENT
Supportive treatment is the most common and effective treatment for acute uncomplicated rhinosinusitis. Nasal saline irrigation alone or in
 conjunction with other adjunctive measures, such as nasal decongestants, may decrease symptom severity. Restrict the use of topical decongestants such as oxymetazoline to approximately  days to avoid rebound mucosal congestion or edema (rhinitis medicamentosa). Topical (intranasal spray)
 corticosteroids may shorten the duration of illness.
In a 2014 Cochrane database systematic review analyzing the efficacy of antibiotic therapy, the authors concluded that antibiotics may provide a small
 treatment effect in patients with symptoms of rhinosinusitis lasting >7 days. However, because 80% of patients treated with placebo also improved within  weeks, it is unclear whether the treatment effect is clinically significant. In general, antibiotics should be reserved for patients with purulent nasal secretions and severe symptoms for ≥7 to  days. 36­38 If antibiotics are prescribed, amoxicillin is recommended as first­line
 therapy for most adults, at a dose of 500 milligrams PO three times per day. Patients with penicillin allergies may receive macrolide antibiotics,
,41 cephalosporins, or fluoroquinolones. For patients who have received antibiotics within the past  to  weeks, consider a fluoroquinolone or high­
  dose amoxicillin­clavulanate. Use caution in selection of antibiotics in patients who are on oral anticoagulation. In the aforementioned Cochrane
 review, comparisons between different classes of antibiotics showed no significant difference. Follow­up with a primary care provider is advised.
Patients with subacute, chronic, or recurrent rhinosinusitis should be evaluated for conditions that modify management, such as allergy, cystic
 fibrosis, or immunocompromise. Outpatient CT of the sinuses can evaluate for invasion of neighboring tissues and neoplasms. ENT follow­up is
,44 advised.
COMPLICATIONS
Complications of rhinosinusitis are mostly related to extension of the infection beyond usual anatomic boundaries. Meningitis, cavernous sinus thrombosis, and intracranial abscesses are rare but important complications associated with contiguous spread of sinus disease. Up to 75% of cases
 of orbital cellulitis, which can lead to blindness through venous congestion and ischemia of the optic nerve, are attributable to disease of the sinuses.
Frontal sinusitis can lead to osteomyelitis of the frontal bone with a doughy swelling of the forehead called Pott’s puffy tumor and can also be associated with an extradural or subdural empyema. In general, patients with these deeper infections usually appear systemically ill or have focal neurologic signs and require admission and IV antibiotics.


