## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 248: Initial Evaluation and Management of Skin Disorders
William Rushton; William J. Brady
INTRODUCTION
Most dermatologic emergencies presenting to the ED involve skin lesions resulting from infections, irritants, and allergic etiologies, with a smaller
 subset related to malignancy. Visual pattern recognition is the key to diagnosis. The recommended approach for the diagnosis of a skin disorder in the ED (assuming resuscitation or stabilization is not required) is to:
. Determine the chief complaint.
. Obtain a brief history (duration, rate of progression, and location of lesions).
. Perform the dermatologic examination (morphology and extent of distribution).
. Formulate the age­appropriate differential diagnosis based on lesion morphology and distribution.
. Elicit additional concerns from the history (associated complaints, comorbidity, medications, or exposures), and include or exclude syndromes in the differential diagnosis based on this information.
. Evaluate for systemic involvement, and consider ancillary investigations, if necessary.
. Obtain dermatologic consultation, if necessary, and arrange for appropriate referral (primary care or dermatologic).
DIAGNOSTIC APPROACH
HISTORY
Determine the chief complaint and obtain a brief history (discomfort, duration, rate of progression, percentage of body surface involvement, and location of lesions). The secondary history should include issues relating to the lesion: morphology, evolutionary nature, rate of progression, and distribution. Associated systemic complaints and mucosal systems must be identified. Ask about exposures, immunizations, toxins, chemicals, foods, animals, insects, plants, and ill contacts. Review sexual history, if appropriate, and medical and family histories. If applicable, obtain a detailed occupational history as industrial exposure may be causative. Asking about medication use, sun exposure, travel history, or particular food ingestion also may yield helpful information. Be sure to include any other housemates or partners in your history of exposures; contact dermatitis can occur
 from exposure to fragrances or other products that a partner is using. The patient should also be asked about the degree of discomfort of the
 dermatoses; a painful dermatitis is often a red flag and may not be associated with a self­limiting lesion.
A detailed medication history is important, and particular attention should be paid to recently started drugs or dosage increases. Erythema multiforme, exfoliative dermatitis, photosensitivity reactions, toxic epidermal necrolysis, and vasculitis are common medication­induced drug reactions. Dermal necrosis should prompt consideration of anticoagulant use, whereas a diffuse rash in a patient on sulfa drugs, anticonvulsants, or some antimicrobials may aid the clinician in diagnosing Stevens­Johnson syndrome, drug reactions with eosinophilia and systemic symptoms, or toxic epidermal necrolysis.
EXAMINATION
The patient should be gowned and in a room with adequate lighting and appropriate privacy to allow entire skin examination. Inspect all skin and mucosal surfaces, including hair, nails, scalp, and mucous membranes. Then evaluate the specific skin lesions. A magnifying lens and a portable light
 are helpful aids.
Chapter 248: Initial Evaluation and Management of Skin Disorders, William Rushton; William J. Brady 
. Terms of Use * Privacy Policy * Notice * Accessibility
Examine the skin systematically. Determine the distribution, pattern, arrangement, morphology, extent, and evolutionary changes of the lesions. Distribution is the location of the skin findings, and the pattern is their anatomic, functional, and physiologic arrangement. For example, a unilateral band­like arrangement of lesions on the thorax suggests varicella­zoster virus infection. Skin diseases often present with a predilection for certain body areas; the distribution of lesions will assist in narrowing the diagnostic possibilities. From the anatomic perspective, the skin surfaces that are usually considered as separate areas of distribution are generalized body; face and scalp; trunk and axillae; groin and skin folds; and hands, feet, and nails. The extremities may be further subdivided into upper versus lower, proximal versus distal, wrists versus ankles, and hands versus feet.
In a patient with diffuse erythema in whom toxic shock syndrome is suspected, identify the presence of a foreign body such as a retained tampon.
Petechiae should prompt investigation for meningococcemia or Rocky Mountain spotted fever. Rashes on exposed portions of the skin should prompt inquiries about sun exposure, jewelry, topical agents, or exposures. See Table 248­1 for a differential diagnosis of skin lesions as a function of location, including both distribution and pattern considerations.
TABLE 248­1
Differential Diagnosis Relative to Lesion Distribution and Pattern
Distribution and Pattern Differential Diagnosis
Flexor surfaces Atopic dermatitis, candidiasis, eczema, ichthyosis
Sun exposure (face, upper thorax, distal Sunburn, photosensitive drug eruption, photosensitive dermatitis, systemic lupus erythematosus, viral extremities) exanthem, porphyria
Distal extremities Viral exanthem, atopic or contact dermatitis, eczema, Rocky Mountain spotted fever, gonococcemia
Front and back of chest Pityriasis rosea, secondary syphilis, drug eruption, atopic or contact dermatitis, psoriasis
Clothing covered (thorax and distal lower Contact dermatitis, psoriasis, folliculitis extremities)
Acneiform (face and upper thorax) Acne, drug­induced acne, irritant dermatitides
Use the burn rule of nines (see Chapter 217, “Thermal Burns”) to estimate the degree of skin involvement in disorders with widespread distribution.
This calculation also may be used to determine the amount of topical medication required for a specific treatment course or whether an oral medication might be more appropriate. Extensive erythroderma (often >90% of body surface area) is a dermatologic emergency, particularly when accompanied by a fever. Severe erythroderma can represent underlying severe infectious dermatitis, toxic shock syndrome, cutaneous T­cell lymphoma, drug reaction, psoriasis, or seborrheic dermatitis.
Lesion arrangement refers to the symmetry and configuration. Bilateral symmetry suggests a systemic internal event or symmetric external exposure, as seen in erythema multiforme, with plaque­like lesions on the flexor surfaces of the extremities, or contact dermatitis related to a lotion application. An asymmetric arrangement supports a localized process. Configuration may apply to a single lesion with reference to its individual features or, alternatively, to multiple lesions and their relation to one another. For instance, internal configuration is illustrated by the relation between the central papule relative to the erythematous ring in the target lesion of erythema multiforme; on the total­body scale, configuration is demonstrated by clustering of lesions in a herpesvirus infection or by a linear arrangement as with a reaction from poison ivy or oak. Other terms used to describe the lesion configuration are listed in Table 248­2. TABLE 248­2
Lesion Configuration Descriptors
Descriptor Configuration
Annular Ring­like or pertaining to the outer edge
Arcuate Curved or pertaining to the curve
Circinate Circular
Confluent Blending together
Dermatomal Belt­like or limited to one side of the body in anatomic dermatome
Discoid Solid, round, slightly raised, or pertaining to a disk
Discrete Separate or individual
Grouped Clustered
Guttate Scattered
Gyrate Coiled or winding
Herpetiform Creeping
Iris Concentric circles
Linear In a line
Polycyclic Overlapping circles or borders of irregular curves
Retiform Net­like
Serpiginous Snake­like
Recognition of the primary lesion is vital in establishing the diagnosis; the use of the primary lesion’s morphology is very important regarding the generation of an appropriate differential diagnosis and ultimately the correct dermatologic diagnosis. The primary lesion is the one that has not been altered by secondary issues, including healing, complicating infection, medication application, or scratching. Examples of primary skin lesions are macules, papules, nodules, tumors, cysts, plaques, wheals, vesicles, bullae, and pustules. Careful attention should be paid to a nonblanching lesion.
Secondary lesions have had their appearance altered due to disease evolution or various external factors, as noted earlier, and include crusts, scales, fissures, erosions, ulcerations, excoriations, atrophy, scarring, and lichenification. See Table 248­3 for a listing and descriptions of the various morphologic descriptors of dermatologic lesions; see Tables 248­4 and 248­5 for a differential diagnosis of the various skin disorders relative to primary and secondary lesion morphologies.
TABLE 248­3
Lesion Morphology
Table 248­3. Lesion Morphology
Descriptor Morphology Lesion Height Image
Nature Relative to
Adjacent
Skin
Excoriation Linear marks from Secondary Flat scratching
Erosion Ruptured vesicle or Secondary Depressed bulla with denuded epidermis
Fissure Linear cracks on skin Secondary Flat surface
Ulcer Epidermal or dermal Secondary Depressed tissue loss
Macule Flat, circumscribed Primary Flat discoloration ≤1 cm in diameter; color varies
Petechiae Nonblanching purple Primary Flat spots <2 mm in diameter
Sclerosis Firm, indurated skin Secondary Flat or elevated
Telangiectasia Small, blanchable Primary Flat superficial capillaries
Purpura Nonblanching purple Primary Flat discoloration of the skin
Abscess Tender, erythematous, Primary Elevated fluctuant nodule
Cyst Sack containing liquid Primary Elevated or semisolid material
Nodule Palpable solid lesion Primary Elevated
<1 cm in diameter
Tumor Palpable solid lesion Primary Elevated
>1 cm in diameter
Scar Sclerotic area of skin Secondary Flat or elevated
Wheal Transient, edematous Primary Flat or papule or plaque with elevated peripheral erythema
Vesicle Circumscribed, thin­ Primary Elevated walled, elevated blister <5 mm in diameter
Bulla Circumscribed, thin­ Primary Elevated walled, elevated blister >5 mm in diameter
Pustule Vesicle containing Primary Elevated purulent fluid
Papule Elevated, solid, Primary Elevated palpable lesion <1 cm in diameter; color varies
Plaque Flat­topped elevation Primary Elevated formed by confluence of papules >0.5 cm in diameter
Comedo Papule with an Primary Elevated impacted pilosebaceous unit
Source: Images reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology, 5th ed. © 2005,
McGraw­Hill, Inc., New York; and Fleischer AB Jr, Feldman SR, McConnell CF, et al: Emergency Dermatology: A Rapid Treatment Guide. © 2002, McGraw­Hill, Inc., New
York.
TABLE 248­4
Differential Diagnosis of Selected Skin Disorders Relative to Primary Lesion Morphology* Table 248­4. Differential Diagnosis of Selected Skin Disorders Relative to Primary Lesion Morphology* Lesion Differential Considerations Images
Morphology
Macule Drug eruption (fixed or photosensitive), nevus, tattoo
(ink), rheumatic fever, syphilis (secondary), viral exanthema, toxic or infectious erythemas, meningococcemia (early), external trauma
(ecchymosis), vitiligo, tinea versicolor, cellulitis (early)
Papule Acne, basal cell carcinoma, melanoma, nevus, warts, molluscum contagiosum, skin tags, atopic dermatitis, urticaria, eczema, folliculitis, insect bites, vasculitis, psoriasis, scabies, Toxicodendron dermatitis (poison ivy, oak, sumac), erythema multiforme, varicella
(early), gonococcemia
Plaque Eczema, pityriasis rosea, tinea corporis and versicolor, psoriasis, seborrheic dermatitis, urticaria, syphilis
(secondary), erythema multiforme
Nodule Basal cell, squamous cell, or metastatic carcinoma; melanoma; erythema nodosum; furuncle; lipoma; warts
Wheal Urticaria, angioedema, insect bites, erythema multiforme
Pustule Acne, folliculitis, gonococcemia, hidradenitis suppurativa, herpetic infection (herpes simplex, herpes zoster, varicella), impetigo, psoriasis, rosacea, pyoderma gangrenosum
Vesicle Herpetic infection (herpes simplex, herpes zoster, varicella), impetigo, Toxicodendron dermatitis (poison ivy, oak, sumac), thermal burn, friction blister, toxic epidermal necrolysis, bullous pemphigoid, pemphigus vulgaris
Bulla Bullous impetigo, Toxicodendron dermatitis (poison ivy, oak, sumac), thermal burn, friction blister, toxic epidermal necrolysis, bullous pemphigoid, pemphigus vulgaris
*This list is not exhaustive, but it represents the more common syndromes likely to be encountered by the emergency physician.
Source: Images reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology, 5th ed. © 2005,
McGraw­Hill, Inc., New York; and Fleischer AB Jr, Feldman SR, McConnell CF, et al: Emergency Dermatology: A Rapid Treatment Guide. © 2002, McGraw­Hill, Inc., New
York.
TABLE 248­5
Differential Diagnosis of Selected Skin Disorders Relative to Secondary Lesion Morphology* Table 248­5. Differential Diagnosis of Selected Skin Disorders Relative to Secondary Lesion Morphology* Lesion Differential Considerations Images
Morphology
Scales Psoriasis, pityriasis rosea, toxic and infectious erythemas, syphilis (secondary), dermatophytic infection (tinea), tinea versicolor, xerosis (dry skin), thermal burn (first degree)
Crusts Eczema, dermatophytic infection (tinea), impetigo, contact dermatitis, insect bite
Erosions Candidiasis, dermatophytic infection (tinea), eczema, toxic epidermal necrolysis, toxic­infectious erythemas, erythema multiforme, primary blistering disorders
(bullous pemphigoid and pemphigus vulgaris), brown recluse spider envenomation
Ulcers Aphthous lesions, chancroid, decubitus ulcer, thermal or friction injury, subacute or chronic ischemia, malignancy, chancre (primary syphilis), primary blistering disorders (bullous pemphigoid and pemphigus vulgaris), brown recluse spider envenomation, pyoderma gangrenosum, stasis ulcer, factitial ulcer
*This list is not exhaustive, but it represents the more common syndromes likely to be encountered by the emergency physician.
Source: Images reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology, 5th ed. © 2005,
McGraw­Hill, Inc., New York; and Fleischer AB Jr, Feldman SR, McConnell CF, et al: Emergency Dermatology: A Rapid Treatment Guide. © 2002, McGraw­Hill, Inc., New
York.
DIAGNOSTIC TECHNIQUES
A potassium hydroxide preparation is used in patients with suspected molluscum contagiosum and dermatophytic infections. The test is performed on loose skin scales, nail parings, subungual debris, short residual hairs, or small pearly globules (from a molluscum body). Test steps are in Table 248­
. TABLE 248­6
Potassium Hydroxide (KOH) Examination
Collect scale with a scalpel edge, place in small heap on slide, cover with coverslip.
Apply KOH 10%–40% solution to edge of coverslip; it will be drawn under coverslip.
Apply heat to underside of slide (match or lighter) until bubbles appear under coverslip.
Visualize under 10× magnification.
The material is then viewed under a microscope at low power, with the condenser and light at low levels. As the slide is scanned, rapidly focus up and down. True hyphae (Figure 248­1), seen in dermatophytic infections, are long, branching, green rods of constant width that cross the borders of epithelial cells. Molluscum bodies are oval discs with homogeneous cytoplasm (Figure 248­2). In hair fragments, the organisms appear as small, round spores packed closely within the hair shaft.
FIGURE 248­1. Hyphae in scraping from tinea pedis. [Photo contributed by University of North Carolina Department of Dermatology.]
FIGURE 248­2. Molluscum bodies. [Reproduced with permission from the Centers for Disease Control and Prevention Public Health Image Library: http://phil.cdc.gov/phil/home.asp.]
Scabies and lice preparations are useful in patients with possible infestation. In scabies infestations, the rash itself may resemble other dermatologic syndromes; microscopic analysis will confirm the diagnosis. The donor site for skin specimen selection is very important. The best sites include burrows (10 mm, elongated papule with a pustule or vesicle) and papules on the fingers, wrists, and elbows (Figure 248­3). Within the vesicle or pustule, a small black dot is noted, which is the mite. The point of the scalpel is scraped across the lesion while holding the skin taut; the mite is then removed. A single drop of mineral oil may be applied to the blade to ensure that the scrapings adhere to the instrument. The material is then placed on the microscope slide with an additional drop of mineral oil; gentle pressure on the coverslip will flatten thick specimens. Using low power, the slide is scanned for presence of the mite, eggs, or feces. Mites are eight­legged creatures that are easily identified on thin smears; thick specimens may require additional viewing to look for the mite. Additional findings supportive of the diagnosis include eggs (smooth ovals) and feces (clusters of red­brown pellets; Figure 248­4). Lice are usually found on the scalp, eyelashes, and pubic areas and may be visible to the unaided eye (Figure 248­5).
FIGURE 248­3. Classic burrows of scabies. [Reproduced with permission from Fleischer AB Jr, Feldman SR, McConnell CF, et al: Emergency Dermatology: A Rapid
Treatment Guide. © 2002, McGraw­Hill, Inc., New York.]
FIGURE 248­4. Microscopic view of a scabies mite with visible eggs and feces. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color
Atlas & Synopsis of Clinical Dermatology, 5th ed. © 2005, McGraw­Hill, Inc., New York.]
FIGURE 248­5. Adult head lice. [Reproduced with permission from the Centers for Disease Control and Prevention Public Health Image Library: http://phil.cdc.gov/phil/home.asp.]
The Tzanck smear, useful in blistering disorders, assists in establishing the diagnosis of a herpes infection: herpes simplex, herpes zoster, and varicella. The choice material for examination is obtained from the base of a recently unroofed lesion; purulent fluid at the base of the lesion is removed with a scalpel and placed on a microscope slide. The material is allowed to air dry and then is stained with Giemsa or Wright stain. Using low power, the slide is scanned for epithelial cells. Multinucleated giant cells (Figure 248­6), indicative of a herpes infection, are a syncytium of epidermal cells with multiple overlapping nuclei. The presence of the multinucleated giant cell does not distinguish between herpes simplex, herpes zoster, and varicella syndromes.
FIGURE 248­6. Tzanck smear under microscopy showing a multinucleated giant cell, indicative of a herpetic infection. [Reproduced with permission from Wolff KL,
Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology, 5th ed. © 2005, McGraw­Hill, Inc., New York.]
Wood’s light examination is helpful in several different situations, including erythrasma (a superficial Corynebacterium infection of moist skin in the groin, axilla, and web spaces), fungal infections caused by Malassezia species or Microsporum species, certain pseudomonal skin infections, and porphyria cutanea tarda. Wood’s light is an ultraviolet source that emits light at a wavelength of 365 nm. The following fluorescent findings are noted in these conditions: erythrasma, red or pink; tinea, green or yellow; Pseudomonas, yellow or green; and porphyria cutanea tarda, urine fluoresces orange or red.
Ancillary studies may also be required to assess for systemic involvement. Fever and leukocytosis may be indicative of an underlying infectious disorder or an underlying autoimmune reaction. In patients on anticonvulsants, elevated transaminases may represent underlying DRESS syndrome

(drug reaction with eosinophilia and systemic symptoms). Furthermore, disseminated intravascular coagulation, thrombocytopenia, and acute
 kidney injury may alert the astute clinician to underlying bacteremia or toxic shock syndrome. Imaging may be required to rule out foreign bodies or to assess the depth of tissue involvement in conditions such as Fournier’s gangrene.
ED TREATMENT
SYSTEMIC CORTICOSTEROIDS
Systemic corticosteroids are the treatment of choice for some generalized conditions and are discussed in the chapters dealing with specific diagnoses. Some severe widespread dermatologic syndromes, such as erythema multiforme, toxic epidermal necrolysis, and vasculitis, are best treated with systemic steroids only after consultation with a dermatologist. Other disorders, including urticaria, angioedema, Toxicodendron dermatitis (rhus, poison ivy, or poison oak), and other contact or allergic disorders, are potential indications for systemic corticosteroids when an
 extensive area of skin is involved. Patients with severe disease can see significant relief with oral corticosteroids within  to  hours. Patients with
 poison ivy or oak eruptions who require systemic steroids should be treated with oral prednisone (1 milligram/kg body weight) for  weeks. Other contact or allergic dermatitides may benefit from an abbreviated course (4 days) of oral prednisone. Efficacy of a short course of corticosteroids in addition to antihistamines remains controversial. A 1995 randomized controlled study showed improvement within  hours with  milligrams of
 prednisone twice a day for a total of  days. A more recent randomized trial, however, showed no difference with  milligrams of prednisone daily for

 days. Expert guidelines still recommend prednisone for refractory cases of acute urticaria, although specific doses and duration are not well
 defined. However, oral corticosteroids are relatively contraindicated, or must be used with great care in those with diabetes, hypertension, active peptic ulcer disease, psychiatric disease, and immunodeficiency. Follow­up within  to  days with the primary care physician or a dermatologist is needed if oral corticosteroids are prescribed to patients with these comorbidities.
TOPICAL CORTICOSTEROIDS
Topical corticosteroids are powerful and useful tools in the management of dermatologic disease. Numerous agents are available for use. They differ in concentration, base components, and cost. Familiarity with a single agent in each potency class is sufficient to treat any steroid­responsive skin ailment safely and effectively. Corticosteroid potency or strength (i.e., the anti­inflammatory property) is measured by the agent’s ability to induce vasoconstriction. Agents’ strengths are rated by vasoconstricting ability on a scale of  to ; group  agents are the most powerful corticosteroids, and group  medications are the least potent (Table 248­7). In general, ointments are more potent than creams or lotions.
TABLE 248­7
Examples of Topical Corticosteroid Agents by Potency Group* U.S. Classification British Classification Representative Topical Agent Formulation
1: Superpotent 1: Very Potent Clobetasol (Temovate®, Clobex®) .05% cream or ointment
Halobetasol (Halonate®, Ultravate®)
Betamethasone (Diprolene®)
2: Potent 2: Potent Fluocinonide (Lidex®, Vanos®) .05% ointment
Halcinonide (Halog®) .1% cream
Mometasone (Elocon®) .1% ointment
3: Upper mid­strength Betamethasone (Diprolene®) .05% lotion
Fluticasone (Cutivate®) .005% ointment
Triamcinolone (Kenalog®) .1% ointment
4: Mid­strength Mometasone (Elocon®) .1% cream, lotion
5: Lower mid­strength 3: Moderate Betamethasone (Diprolene®) .1% cream
Fluocinolone (Synalar®) .025% cream
Fluticasone (Cutivate®) .05% cream
6: Mild Alclometasone (Alclovate®) .05% cream or ointment
Desonide (Desonate®, Desocort®) .05% cream
Triamcinolone (Kenalog®) .025% cream
7: Least Potent 4: Mild Hydrocortisone 1% or .5% cream, lotion or ointment
Note: Trade names vary. Strength classification can vary. Strength also depends upon the product itself, amount applied, and nature of skin at the application site.
*Preparations are listed by U.S. and British potency groups: Group  is most potent; group  (British 4) is least potent.
Topical Corticosteroid Strength
Marked variation in potency is seen across various corticosteroids, whereas much smaller differences in strength are encountered for different concentrations of individual agents. Many corticosteroids are fluorinated. Fluorination greatly increases the potency, but also increases the risk of adverse reactions, and fluorinated formulations should not be used in pregnancy.
Use of the appropriate­strength topical steroid is strongly encouraged at the start of therapy. Starting with a less powerful agent is not likely to spare the patient from potential adverse effects or to produce adequate control of the disease. Hydrocortisone, perhaps the most frequently used topical corticosteroid in the outpatient setting, is available over the counter in strengths up to 1% and by prescription in strengths to a maximum of .5%.
Hydrocortisone is safe and may be used on most body surfaces, including the face, genitalia, flexure creases, and intertriginous zones. It also is safe for use in infants and children. For the treatment of diseases involving the palms and soles, hydrocortisone is a poor choice, because the thickened skin does not allow adequate penetration of this relatively low­potency steroid. Corticosteroids of moderate potency, including triamcinolone acetonide and fluocinolone acetonide, are useful in treating severely inflamed skin and the thicker skin of the scalp, trunk, extensor surfaces, palms, and soles. These agents should not be applied to the face or genitals or used in infants because of the risk of skin atrophy. See Table 248­8 for recommendations on the potency of corticosteroid to use in treating various dermatologic diseases. When using agents found in group  or , consultation with a dermatologist may be advised.
TABLE 248­8
Recommended Corticosteroid Potency for Treatment of Various Dermatologic Diseases
Groups  and  Groups  to  Groups  and 
Psoriasis Atopic dermatitis Nonspecific dermatitis of face, eyelids, and perineum
Eczema of hand (severe) Stasis dermatitis
Poison ivy dermatitis (severe) Seborrheic dermatitis
Tinea
Atopic dermatitis (severe) Scabies
Nonspecific dermatitis of face (severe)
Different skin surfaces respond differently to topical corticosteroid therapy; this differential response relates to the absorption of the steroid into the deeper tissues. The relatively thin skin surfaces of the face respond very rapidly to the use of group  agents, whereas the thicker skin of the palms and soles requires a highly potent steroid. Irritations for which a low­potency agent may provide the same treatment effectiveness as a higher potency agent include those involving raw, inflamed skin (such skin absorbs medication more rapidly and readily); treatment regions with skin surfaces in frequent contact, such as intertriginous areas (the apposition of two skin surfaces produces enhanced absorption of drug, similar to the effect of an occlusive dressing); and areas of skin under tight clothing, such as the diaper area (absorption of the agent is enhanced due to the occlusive effect of the garment). In general, lower potency agents are acceptable in these situations.
Application of Topical Steroids
The application of creams, ointments, gels, and lotions is relatively straightforward. The medication is applied in a thin layer and should be massaged daily into the skin, as directed. Washing the skin before corticosteroid application is unnecessary. Advise patients to follow directions closely both early and late in the treatment course. Using extra medication per dose or applying medication more frequently early in the treatment period is not desirable; likewise, reducing the frequency of application or decreasing the amount of medication as the disease process responds to therapy can cause relapse. Optimal application regimens have not been determined for topical corticosteroids in most dermatologic syndromes. The more potent agents are best applied two to three times daily for  to  weeks followed by a drug­free week; additional therapy may be required as determined by the disease and by the particular patient’s response to the initial therapy. Agents from the less potent steroid groups may be applied three times daily for  to  weeks followed by a 7­day steroid­free period.
Prescribing the Correct Amount of Topical Steroid
Determining the correct amount of topical steroid to prescribe is at times difficult. The burn rule of nines may be used to estimate the amount of topical corticosteroid to prescribe. Calculate the percentage of body surface area requiring therapy and then multiply the percentage by a correction factor of . This calculation provides the amount of topical corticosteroid in grams for a single application. Next, determine the number of administrations required in the treatment course. For example, a three­times­daily regimen for a duration of  days requires  applications. The number of applications is multiplied by the grams required for a single dose to yield the total amount to be prescribed (Table 248­9). In general,  grams of topical steroid cover 9% of the body surface area for  day with a thrice­daily application. See Table 248­10 for a description of the amount of topical corticosteroid to be dispensed relative to the coverage area and duration of therapy.
TABLE 248­9
Determination of the Correct Amount When Prescribing Topical Steroids
Use burn rule of nines to determine percentage of body surface area affected.
Percentage of body surface area ×  = grams of topical corticosteroid per application.
Application times per day × number of days of treatment = total number of applications.
Total grams to prescribe = [% body surface area × 30] × [times per day × number of days].
TABLE 248­10
Amount of Corticosteroid Cream to Dispense* Body Area Suggested Potency Amount to Dispense (grams)
Face Low 
Arm Intermediate or low 
Leg Intermediate or low 180
Hand or foot Intermediate or low 
Forearm Intermediate or low 
Chest or back Intermediate or low 180
*Based on application three times a day for  days of therapy.
Avoid Tachyphylaxis
Tachyphylaxis refers to the decrease in responsiveness to a drug as a result of enzyme­mediated events. The term is used in relation to topical corticosteroids to describe the early development of tolerance to vasoconstricting ability. In general, vasoconstriction has been demonstrated to decrease progressively over time after a topical steroid has been applied. Such reductions in strength due to tolerance are encountered as soon as  days into the treatment course in all potency groups, but are thought to be more important for corticosteroids in groups  and . A reasonable strategy to counter the development of tachyphylaxis is the use of interrupted application schedules. An interrupted treatment course might include an initial three­times­daily application for  weeks, followed by  week without use of the drug, and then a repeat of the cycle.
ANTIHISTAMINES
Antihistamines (histamine­1 antagonists) are frequently used in clinical practice to control pruritus. These drugs include first­generation antihistamines such as diphenhydramine and hydroxyzine as well as second­generation antihistamine agents, including astemizole, cetirizine,
9­11 fexofenadine, and loratadine. Second­generation histamine­1 antihistamines, while purporting a longer duration of action, do not have the
 therapeutic sedation found in the first­generation class. Placebo effect and verbal cues have also been implicated in reducing pruritus. True refractory cases of pruritus may require drugs treating anti–immunoglobulin E antibodies, mast cell modulators, mast cell mediator blockers, and
 immunomodulators; however, consultation with a dermatology expert is advised before commencement of these agents.
The use of topical antihistamine preparations is discouraged, because these agents are readily absorbed and dosing is difficult to predict. See Table
248­11 for suggested dosing, administration schedules, and routes of therapy for these antihistamines. Histamine­2 antagonists (ranitidine or famotidine) also have demonstrated some benefit in patients with a true histamine allergic­mediated event, in particular urticaria, and therefore are recommended in combination with histamine­1 antagonists in the more severe allergic reactions.
TABLE 248­11
Antihistamines Useful in the Management of Dermatologic Disease
Medication (trade name) Adult Dosage Pediatric Dosage
Diphenhydramine (Benadryl®) 25–50 milligrams PO/IV/IM four times a  milligrams/kg/d PO/IV/IM in four divided doses; maximum dose, day 300 milligrams/d
Hydroxyzine (multiple trade 25–100 milligrams PO three or four times  milligrams/kg/d PO in four divided doses names) a day
Cetirizine* (Zyrtec®) 5–10 milligrams PO once a day For children ≥6 y, 5–10 milligrams PO once a day†
Fexofenadine* (Allegra®)  milligrams PO twice a day For children ≥6 y,  milligrams PO twice a day
Loratadine* (Claritin®)  milligrams PO once a day For children ≥6 y,  milligrams PO once a day†
Famotidine (Pepcid®)  milligrams PO twice daily .5 milligram/kg/d in two divided doses; maximum dose,  milligrams/d
Ranitidine (Zantac®) 150 milligrams PO twice daily 5–10 milligrams/kg/d PO in two divided doses; maximum dose,
300 milligrams/d
*Indication limited to chronic idiopathic urticaria (see package inserts for details).
†Pediatric use is recommended only in children ≥6 years old (see package inserts for details).
™
Numerous other antipruritic therapies are recommended, including Domeboro solution (aluminum sulfate diluted 1:10 with water) soaks and oatmeal baths.
ANTIMICROBIAL AGENTS
Topical antibacterial agents are used primarily as adjuncts to wound dressing and are rarely useful as primary therapy for superficial bacterial infections of the skin. The exception to this statement is topical mupirocin, which is as effective as oral antimicrobial agents in the management of impetigo. For wound dressing, the agents commonly used include polymyxin B, bacitracin, neomycin, and silversulfadiazine. Do not use silver sulfadiazine on the face because it will stain. When reapplying silversulfadiazine, thoroughly wipe off the prior medication before applying a new dose to avoid silver staining of the skin. Benefits of topical antibacterial agents include reduced adherence of bandaging material to the wound, reduced coagulum, and decreased bacterial colonization. The impact on the rate of wound healing and the prevention of wound infection is less well characterized. Another application of topical antibacterial agents is in the treatment of aphthous stomatitis, for which oral tetracycline rinses are used.
Other disorders treated with topical agents include Candida infections, dermatophyte infections, herpes simplex, and lice infestations and scabies.
Diagnostic features and specific treatment are discussed in other chapters by the specific diagnosis.
NONANTIMICROBIAL TOPICAL AGENTS
In general, the maxim “If it’s dry, wet it, and if it’s wet, dry it” applies to the initial treatment of many rashes. Water, protein, and lipid losses characterize dry skin diseases. Emollient creams and lotions restore water and lipids to the epidermis, hasten the healing process, and reduce pruritus and pain.
Emollients are moisturizers that reduce skin dryness and decrease skin friction and the sensation of tightness. In patients with chronic drying dermatitides, ointments are best, particularly in the winter months. In warm climates, less viscous, less oily preparations, such as a cream, are better tolerated. Open wet dressings using tap water or normal saline not only reduce discomfort due to the drying but also cleanse the skin by painlessly loosening crusts and exudates. The various wet cutaneous syndromes involve similar protein and lipid losses due to excessive flow of transudative or exudative fluid from the diseased skin with leaching of the complex macromolecules of the epithelial cells. Drying agents retard this flow of fluid and associated biologic materials from the body, thus assisting in the curative process.
Capsaicin, a topical agent derived from chili peppers that affects the release of substance P, can desensitize local nerve fibers and has been
 recommended as an antipruritic agent. A topical preparation of .025% three times a day for up to  weeks is well tolerated by most patients.

Capsaicin is not recommended for patients under  years of age. Topical local anesthetic treatments such as pramoxine 1% or .5% or the mixture of lidocaine and .5% cream have been reported in case series to improve pruritus; however, studies with high level of evidence are lacking, and the
 long­term safety profile is unknown.
Topical Agent Medication Base (Vehicle)
The vehicle, or medication base, is the substance in which the active ingredient is dispersed. The base determines the rate at which the active ingredient is absorbed through the skin. Components of some bases may cause irritation or allergy.
Creams, a mixture of oils, water, and preservative, are white and greasy in texture. Creams are the most versatile vehicle and can be applied to any body surface area. They are particularly useful in the intertriginous areas. Creams are best used for acute therapy only; chronic application may cause excessive drying. Some patients are allergic to the preservatives in creams; in these patients, consider switching to an ointment preparation of the medication.
Ointments are composed of greases such as petroleum jelly and are free of preservative. Little water is added to this vehicle. Ointments are translucent and, when applied to the skin, remain greasy. This greasy consistency lubricates particularly dry lesions. In general, ointment vehicles allow deeper tissue penetration compared with cream bases. Ointments also are occlusive, providing very thorough coverage with deep tissue penetration and allowing little movement in moisture and other material into and out of the skin. Acute exudative syndromes and intertriginous areas of the body should not be treated with topical steroids formulated using an ointment vehicle.
Gels are greaseless mixtures of propylene glycol and water and at times contain alcohol. Gels have a translucent appearance and are described as
“sticky.” Alcohol­containing gels are best for acute exudative lesions, such as poison ivy dermatitis, whereas alcohol­free combinations should be used for dry, scaling conditions. In denuded areas, the alcohol component may cause discomfort. Gels are sometimes preferred for the scalp, because they do not alter the hairstyle and are cosmetically tolerable.
Solutions or lotions may contain water or alcohols in addition to other agents. They are clear or milky in appearance and are most useful for the scalp and other dense hair­bearing areas because they leave no significant residue on the hair. In denuded areas, the alcohol component may cause discomfort.
Some topical steroids are available as foams. Clobetasol (a very potent topical steroid) is safe and effective as a foam. It is important to note that the
 absorption rate of clobetasol is greater for the foam vehicle formulation than for the topical solution.
Topical Agent Toxicity
Topical agents with certain active ingredients must be used with caution. These ingredients are often very effective, but the delivery is uncontrolled.
Although the patient can control the amount and frequency of application, the actual amount of systemic absorption is not easily managed. For instance, certain agents are well absorbed through normal skin and mucous membranes, whereas other medications are absorbed only through
™ irritated skin or mucosa. Topical formulations containing agents absorbed through irritated skin include the Lidoderm patch (containing lidocaine),
™ ™ ™
Caladryl lotion (containing pramoxine, a local anesthetic), Bengay (containing methyl salicylate), and Icy Hot (containing menthol and methyl salicylate). Reports of significant toxicity, including death, have been reported with these and similar agents when excessively applied topically.


