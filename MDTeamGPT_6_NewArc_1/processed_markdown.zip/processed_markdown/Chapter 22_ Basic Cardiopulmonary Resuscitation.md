University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 22: Basic Cardiopulmonary Resuscitation
Maite Anna Huis in’t Veld; Jon Mark Hirshon
INTRODUCTION
,2
The time sensitivity of CPR in sudden cardiac death is emphasized in the American Heart Association Chain of Survival (Table 22­1). This chapter reviews basic CPR for adults and children ≥8 years old, including the approach to an unresponsive patient; the physiology and mechanics of closed chest compression techniques; and basic airway opening procedures, including initial management of an obstructed airway. This chapter is specifically directed toward healthcare providers, although key updates for lay rescuers are noted, given the healthcare provider’s role in layperson education. Table 22­2 outlines the sequence of steps to be taken when someone is found unresponsive.
TABLE 22­1
American Heart Association Chain of Survival1­4
Links in Chain Comment
Recognition and activation of the emergency response Early recognition of the emergency and activation of the EMS or local emergency response system (EMS) system are vital.
Phone the local emergency medical telephone number.* Immediate high­quality CPR Immediate bystander CPR can double or triple the victim’s chance of survival.
Rapid defibrillation CPR plus defibrillation within  to  min of collapse can produce improved survival rates.
Basic and advanced emergency medical services High­quality resuscitative care is provided by EMS personnel.
Advanced life support and postarrest care High­quality, integrated post–cardiac arrest clinical care by healthcare providers.
*For a global list of emergency numbers and mobile phone use, see https://en.wikipedia.org/wiki/List_of_emergency_telephone_numbers.
TABLE 22­2
Systematic Approach to CPR
CPR Steps Comments
Step 1: Recognition Assess for responsiveness, lack of breathing, or presence of abnormal breathing/gasping.
Step 2: Activate the emergency medical If possible, call for an assistant to activate EMS and obtain an AED.
response system and get an automatic It is recommended that dispatchers help determine if there is presence of a cardiac arrest and help initiate external defibrillator (AED) dispatcher­guided CPR if indicated.
Step 3: Assess circulation (healthcare If no pulse after 10­second maximum check, go to step . (Pulse checks are for healthcare providers only.) provider only)

ChapteSrte 2p2 4:: BBeagsinic c Cycalerd oifo 3p0u cllmosoenda crhye sRtesuscitatiCoonm, Mpraesitseio Ansn:n “aPu Hshu hisa rind’ at nVde flads;t .J”on Mark Hirshon 
. Terms of Use * Privacy Policy * Notice * Accessibility compressions 100–120 compressions/min.
Compress 2–2.5 in. (5–6 cm).
Allow for complete chest recoil, <10­second compression interruption.
Ratio of  compressions to  breaths.
Alternate compressors every  minutes or when the compressor becomes fatigued if an assistant is available.
Step 5: Use the defibrillator when available A defibrillator should be used as soon as available.
and indicated It is recommended that while the AED is being retrieved and applied CPR is initiated and continued until the device is ready for use.
Step 6: Continue high­quality CPR Continue CPR between rhythm checks, while the defibrillator is being applied and immediately restart compressions after defibrillation. This is to maximize compression times and decrease interruptions.
Step 7: Rescue breathing Rescue breaths are to be initiated only by a trained lay rescuer that is able to perform rescue breaths or by a healthcare provider. Untrained lay rescuers and trained lay rescuers unable to provide rescue breaths should perform compression­only CPR.
Administer  breaths following a cycle of  chest compressions.
Deliver each breath over  second with sufficient tidal volume to see a visible chest rise.
Continue cycles of  closed chest compressions and  breaths, minimizing interruptions.
*For a global list of emergency numbers and mobile phone use, see https://en.wikipedia.org/wiki/List_of_emergency_telephone_numbers.
SEQUENCE OF STEPS FOR BASIC CPR
. C­A­B (chest compressions, airway, breathing) is the recommended sequence for a single rescuer. Provide chest compressions before giving rescue breaths.
. Compression rate should be 100 to 120 per minute.
. Compression depth should be  to .5 in. (5 to  cm).
. Do not lean hands on the chest between compressions to allow complete recoil between compressions.
. Continue compression­only CPR until arrival of automated external defibrillator or rescuers with additional training.
. If trained in rescue breathing, add rescue breaths after  compressions, using two breaths then and every  compressions until skilled help arrives.
. Naloxone may be given for suspected life­threatening opioid­associated emergencies.
. Assessment of breathing and pulse checks may be done first by basic life support healthcare providers, but must be done in <10 seconds.
STEPS OF BASIC CPR
STEP  AND STEP  IN BASIC CPR: RECOGNITION AND CALL FOR HELP
Before approaching a collapsed individual, assess the scene for risks to healthcare providers. Potential risks include the presence of hazardous materials, an unstable physical environment, or personal violence. Once the patient is reached, determine the patient’s level of responsiveness to noxious stimuli. If the patient is without normal breathing, get help first before starting chest compressions. In a hospital, this may mean calling for the arrest team and requesting the arrest cart. Outside the hospital, this is likely to mean asking a bystander to activate the local EMS system. Look around to see if an automatic external defibrillator (AED) is nearby. Rapid application of defibrillation for unstable ventricular tachycardia or ventricular fibrillation is critical for patient survival.
STEP  IN BASIC CPR (HEALTHCARE PROVIDER ONLY): ASSESS CIRCULATION
The carotid artery is generally the most reliable and accessible location to palpate a pulse. The artery is located by placing two fingers on the trachea and then sliding them down to the groove between the trachea and the sternocleidomastoid muscle. Simultaneous palpation of both carotid arteries should not be performed because, in low­pressure states, this could obstruct cerebral blood flow and may interfere with the ability to detect a pulse.
The femoral artery may be used as an alternative site to palpate a pulse. This can be found just below the inguinal ligament approximately halfway between the anterior superior iliac spine and the pubic tubercle. If no definite pulse is felt within  seconds, chest compression should begin.
STEP  IN BASIC CPR: BEGIN CARDIAC COMPRESSIONS
Physiology of Closed Chest Compressions
There has been an active debate as to the exact mechanism that causes blood flow since the technique of closed chest compressions was put forth in
,6 the 1960s. In a closed system, liquid flows when pressure gradients develop. There are three basic theories for how pressure gradients and flow are
,8 produced during closed chest cardiac massage. The conventional theory of blood flow during compressions is called the cardiac pump theory. The pump theory postulates that direct compression of the heart between the spine and the sternum leads to increased pressure in the ventricles. This causes closure of the mitral and tricuspid valves, leading to blood flow into the aorta and the pulmonary arteries. The thoracic pump theory postulates that compressions lead to an increase in pressure throughout the thoracic cavity, leading to a pressure gradient from intrathoracic to extrathoracic arteries. The third mechanism described is the abdominal pump theory, which has both an arterial and a venous component. The arterial component postulates blood flow into the peripheral arterial system from increased arterial pressure caused by abdominal compressions that forces blood from the abdominal aorta against the closed aortic valve. The venous component leads to blood return via the inferior vena cava from abdominal pressure. However, regardless of the mechanism, conventional chest compressions generate one fourth to one third of physiologic cardiac output. Lower ratios can be expected with delays in initiating compressions.
Technique of Closed Chest Compression
When the lack of a pulse is confirmed, begin serial rhythmic closed chest compressions (Table 22­3). Place the victim supine on a firm surface, with the rescuer at the victim’s side. Place the heel of one hand midline on the lower half of the sternum,  to  cm (∼2 in.) cephalad of the xiphoid process
(Figure 22­1). The heel of the hand should be parallel with the long axis of the patient’s body. Then place the second hand on top of the first hand, so the hands are parallel with each other. The fingers of the two hands may be interlaced if desired, but they should not be touching the chest. Keep the arms straight and the elbows locked. The vector of the compression force should start from the rescuer’s shoulders and be directed downward.
Lateral compressive forces will decrease the efficiency of the compressions and increase the likelihood of complications. Depress the sternum  to
### .5 in. (5 to  cm) in an adult at a rate of 100 to 120 compressions per minute. Rates lower than this are inadequate. The compressionrelease phases should be roughly equal in length. With a single rescuer or with two rescuers if the patient is not intubated, give two ventilations after every  compressions. With two rescuers assisting an intubated patient, ventilate at a rate of  to  per minute, without interrupting chest compressions. Of note, although assisting ventilation is important, not everyone is willing to perform mouth­tomouth breathing due to concerns over infectious disease transmission. Chest compressions alone can be effective and should be provided
,2,9,10 even if rescue breathing is not being performed.
TABLE 22­3
Techniques of Closed Chest Compression
Closed chest compressions Depth: 2–2.5 in. (5–6 cm).
Rate: 100–120/min.
Allow complete recoil of the chest between compressions, with approximately equal compression and relaxation times.
Minimize interruptions.
Ventilations Single rescuer or  rescuers, nonintubated patient: give  breaths after every  compressions.
Two rescuers, intubated patient: give breaths at a rate of 8–10 breaths/min.
Do not pause chest compressions during ventilations.
FIGURE 22­1. Proper hand (A) and rescuer (B) positioning for chest compression. [Image used with permission of Rita K. Cydulka, MD, MS, MetroHealth Medical
Center.]
Open Chest Cardiac Compressions
Open chest cardiac massage is an alternative to standard CPR and improves blood flow in animal models. This technique may be considered in a number of situations, including (1) after penetrating chest trauma; (2) in the perioperative period before or after cardiothoracic surgery; (3) during cardiac arrest caused by hypothermia, pulmonary embolism, pericardial tamponade, or abdominal hemorrhage; (4) in cases of chest deformity in which closed chest CPR is ineffective; (5) in penetrating abdominal trauma with deterioration and cardiac arrest; and (6) in blunt trauma with cardiac
  arrest. However, opening the chest solely to perform open cardiac massage does not provide benefit over closed chest compressions. Moreover, the use of this technique requires a well­coordinated multidisciplinary team (see Chapter 262, “Cardiac Trauma”).
STEP  IN BASIC CPR: DEFIBRILLATE
Defibrillation is discussed in Chapter , “Defibrillation and Electrical Cardioversion.”
STEP  IN BASIC CPR: CONTINUE HIGH­QUALITY CARDIAC COMPRESSIONS
Continuing high­quality compressions as much as possible while minimizing interruptions is critical to increase the chances of achieving return of
 spontaneous circulation and optimizing the chance of survival to hospital discharge. Chest compressions fraction refers to the proportion of time
 spent performing compressions. Current guidelines recommend a chest compression fraction of at least 60%. Interruptions can be minimized by continuing compressions between pulse checks, while applying the AED, and immediately restarting CPR after defibrillation. When performing US in cardiac arrest, minimize the time spent on the chest by the US probe. Techniques to minimize the time on the chest include loading the probe with gel and having it ready at the bedside, counting the time on the chest, and having a towel ready to wipe off the gel so as to not create a slippery surface for the compressor.
STEP  IN BASIC CPR: OPEN THE AIRWAY AND RESCUE BREATHING
The seventh step is to assess the upper airway of the victim. This usually requires positioning the individual supine on a flat, firm surface with the arms along the sides of the body. Unless trauma can be definitely excluded, any movement of the victim should consider the possibility of a spine injury. As the patient is placed supine, stabilize the cervical spine by maintaining the head, neck, and trunk in a straight line. If the neck is not already straight, then it should be moved as little as possible to establish the airway. If the patient cannot be placed supine, the jaw thrust maneuver (see “Jaw
Thrust Maneuver” section) can be applied with the rescuer at the victim’s side. Common causes of airway obstruction in an unconscious patient are occlusion of the oropharynx by the tongue and laxity of the epiglottis. With loss of muscle tone, the tongue or the epiglottis can be forced back into the oropharynx upon inspiration. This can create the effect of a one­way valve at the entrance to the trachea, leading to airway obstruction. After positioning the patient, inspect the mouth and oropharynx for secretions, foreign objects, loose (floppy) dentures, partial dentures, or broken teeth. If dentures fit properly, keep them in place if possible, as they will allow for a better seal. If secretions are present, they can be removed with the use of oropharyngeal suction if available; a visualized foreign body may be dislodged by use of a finger sweep and then manually removed. In contrast to earlier recommendations, a blind finger sweep should never be performed as there is a risk of worsening airway obstruction (see “Finger Sweep” section).
Once the oropharynx has been cleared, two basic maneuvers for opening the airway may be tried. These are the head tilt–chin lift and the jaw thrust.
These maneuvers help to open the airway by mechanically displacing the mandible and the attached tongue out of the oropharynx.
Head Tilt–Chin Lift Maneuver
To perform the head tilt–chin lift maneuver, gently extend the patient’s neck by placing one hand under the patient’s neck and the other on the forehead and extending the head in relation to the neck. This maneuver should place the patient’s head in the sniffing position, with the nose pointing up. In conjunction with the head tilt, perform the chin lift. The chin lift is done by carefully placing the hand that had been supporting the neck for the head tilt under the symphysis of the mandible, taking care not to compress the soft tissues of the submental triangle and the base of the tongue. Then lift the mandible forward and up, until the teeth barely touch. This supports the jaw and helps tilt the head back.
Jaw Thrust Maneuver
The jaw thrust is the safest method for opening the airway if there is the possibility of cervical spine injury. This maneuver helps to maintain the cervical spine in a neutral position. The rescuer, who is positioned at the head of the patient, places the hands at the sides of the victim’s face, grasps the mandible at its angle, and lifts the mandible forward (Figure 22­2). This lifts the jaw and opens the airway with minimal head movement.
FIGURE 22­2. Jaw thrust maneuver. [Image used with permission of Rita K. Cydulka, MD, MS, MetroHealth Medical Center.]
Suspected Opioid Overdose
In the setting of the opioid epidemic, including the demographic data showing a rise in opioid­related deaths, the use of prehospital naloxone has become more prevalent. Laypersons and healthcare providers are encouraged to administer intranasal or intramuscular naloxone using an
 autoinjector in patients with a pulse but no effective breathing in the setting of a known or suspected opioid overdose. Medication administration to patients in cardiac arrest is ineffective without high­quality chest compressions. Hence, administration of naloxone in patients in cardiac arrest should
 be considered only after CPR has been initiated.
Rescue Breathing
After opening the airway, assess respiratory effort and air movement. Look for chest expansion, and listen and feel for airflow. The simple act of opening the airway may be adequate for the return of spontaneous respirations. However, if the victim remains without adequate respiratory effort, then further intervention is required. If rescuers are reluctant to perform mouth­to­mouth ventilation and the patient is in cardiac arrest, chest compressions alone can be effective (Table 22­3).
Two breaths over  second each should be given with sufficient volume to cause visible chest rise. At this point, if a foreign body obstruction is noted, as indicated by a lack of chest rise or airflow on ventilation, the obstruction requires removal (Figure 22­3). Agonal respirations in an individual who has just suffered a cardiac arrest are not considered adequate for ventilation. Intermittent positive­pressure ventilation, with oxygen­enriched air if possible, should be initiated.
FIGURE 22­3. Determine breathlessness. [Image used with permission of Rita K. Cydulka, MD, MS, MetroHealth Medical Center.]
,2
Table 22­4 outlines the recommendations for delivery of rescue breaths during cardiac arrest. When an advanced airway (e.g., endotracheal tube,
Combitube, or laryngeal mask airway) is in place during two­person CPR, ventilate at a rate of  to  breaths per minute without attempting to
,2 synchronize breaths between compressions. There should be no pause in chest compressions for delivery of ventilations.
TABLE 22­4
Delivery of Rescue Breaths During CPR
Deliver each rescue breath over  second.
Give a sufficient tidal volume (by mouth to mouth/mask or bag mask with or without supplementary oxygen) to produce visible chest rise.
Avoid rapid or forceful breaths.
Avoid hyperventilation.
In an adult with normal perfusion,  to  mL/kg tidal volume is required for adequate oxygenation and ventilation. However, in the setting of CPR, where cardiac output is only 25% to 33% of normal, a lower minute ventilation, and thus tidal volume, can be satisfactory. Approximately  to  mL/kg will suffice. Use an appropriately sized bag for bag­valve­mask ventilation. A pediatric bag will provide inadequate tidal volumes for an adult.
There are a number of techniques for ventilating an individual, including mouth to mouth, mouth to nose, mouth to stoma, and mouth to mask.
Rescue breaths with an inspiratory time of  second each should be given at a rate of  to  per minute, with a volume adequate to make the chest rise visibly (approximately  to  mL/kg; 500 to 600 mL in adults). Supplemental oxygen should be delivered as soon as possible. Expired air has a fraction of expired oxygen of 16% to 17%. Too large a volume or too rapid an inspiratory flow rate can cause gastric distention, which can lead to regurgitation and aspiration.
Mouth­to­Mouth Ventilation
With the airway open, gently pinch the patient’s nose shut with the thumb and index finger (Figure 22­4). This prevents air escape. After taking a deep breath, place the lips around the patient’s mouth, forming an airtight seal. Slowly exhale. Release the seal and allow adequate time for passive exhalation by the victim, and then repeat the procedure. Protective devices such as face shields decrease the risks to the provider of contracting an infectious disease and can be purchased from most medical equipment stores.
FIGURE 22­4. Mouth­to­mouth rescue breathing. [Image used with permission of Rita K. Cydulka, MD, MS, MetroHealth Medical Center.]
Mouth­to­Nose Ventilation
In some cases, as with severe maxillofacial trauma, mouth­to­nose ventilation may be effective. With the airway open, lift the patient’s jaw, closing the patient’s mouth. After a deep breath, place the lips around the patient’s nose, forming an airtight seal. Slowly exhale.
Mouth­to­Stoma or Tracheostomy Ventilation
After laryngectomy or tracheotomy, the stoma or tracheostomy becomes the patient’s airway. As with the other techniques, a seal is made around the stoma or tracheostomy tube, and the rescuer slowly exhales.
Mouth­to­Mask Ventilation
Proper and secure placement of the mask on a victim’s face is important when using a mask for ventilation, either with a bag or via mouth to mask.
Place the mask over the bridge of the patient’s nose and around the mouth. Place the thumb on the part of the mask that is sitting on the patient’s nose and place the index finger of the same hand on the part of the mask sitting on the patient’s chin (Figure 22­5). The three other fingers of the same hand are then placed along the bony margin of the jaw. The mask can then be firmly sealed to the patient’s face. Two hands may be used for this technique if a second rescuer is available. Ventilations are then performed through the mask. Some masks also allow for supplemental oxygenation.
FIGURE 22­5. Mouth­to­mask rescue breathing with proper mask placement. [Image used with permission of Rita K. Cydulka, MD, MS, MetroHealth Medical Center.]
FOREIGN BODY OBSTRUCTION

It is important to recognize and be able to assist someone with an airway obstruction due to a foreign body. An individual in distress from a compromised airway is likely to use the universal sign for an airway obstruction, which is for the individual to grab his or her neck with both hands. Foreign bodies can cause partial or complete obstruction. With a partial airway obstruction, air exchange may be adequate or inadequate. If the victim is able to speak, cough, and exchange air, then he or she should be encouraged to continue spontaneous efforts. Obtain assistance, such as activation of the local EMS system. Do not interfere with the patient’s attempts to cough or expel the foreign body and do not perform a blind finger sweep. If air exchange becomes inadequate, as indicated by an inability to speak, increased difficulty breathing, weak and ineffective cough, worsening stridor, or cyanosis, immediate medical intervention is needed (see next section, “Obstructed Airway (Heimlich) Maneuver”). Inadequate air exchange from a severe partial or a complete airway obstruction should be managed the same way. In an unconscious person, the presence of airway obstruction may be ascertained by noting inadequate airflow and poor chest rise with efforts to ventilate.
Maneuvers used to relieve foreign body obstructions include the Heimlich maneuver (subdiaphragmatic abdominal thrusts), chest thrusts, and the finger sweep. In a conscious individual, the obstructed airway (Heimlich) maneuver is the recommended maneuver in most adults for relieving airway obstruction due to a solid object. It is not useful for liquids. In an unconscious individual suspected of having an aspirated foreign body and in whom the foreign body is visualized, the recommended first step is the finger sweep. A blind finger sweep is no longer recommended as it may worsen airway obstruction by pushing an unseen object into an even less favorable position. Otherwise, in an unconscious patient, the recommended sequence is to perform the obstructed airway maneuver up to five times, open the mouth and perform a finger sweep if a foreign body has become visible, and then attempt to ventilate. This sequence may be repeated as often as needed until the patient recovers or additional assistance arrives.
OBSTRUCTED AIRWAY (HEIMLICH) MANEUVER

The Heimlich maneuver creates an artificial cough by forcefully elevating the diaphragm and forcing air from the lungs. It may be repeated multiple times. Each individual thrust should be performed aggressively, with the intention of removing the obstruction. The maneuver can be performed with the victim standing, sitting, or lying down, or it can be self­administered (Figure 22­6). To perform the maneuver with the patient standing or sitting, stand behind the patient and place the thumb side of a fist against the victim’s abdomen midline just above the umbilicus and well below the xiphoid process (Figure 22­6). Grasp the fist with the other hand, and forcefully push the fist into the victim’s abdomen with a quick upward thrust. Repeat until the item is dislodged or the patient becomes unconscious. For an unconscious patient, place the victim supine on a firm surface and sit astride the victim’s thighs (Figure 22­7). Place the heel of the dominant hand midline just above the patient’s umbilicus, and the other hand directly on top of the first. Then deliver quick upward thrusts. To self­administer thrusts, the individual can either use his or her own fist to deliver the thrusts or lean forcibly against a firm object, such as a porch rail or the back of a chair. Potential complications of the Heimlich maneuver include injury or rupture of abdominal or thoracic viscera and regurgitation of stomach contents.
FIGURE 22­6. Standing Heimlich maneuver administered to conscious victim of foreign body airway obstruction. [Image used with permission of Rita K. Cydulka, MD,
MS, MetroHealth Medical Center.]
FIGURE 22­7. Prone Heimlich maneuver administered to unconscious victim of foreign body airway obstruction. [Image used with permission of Rita K. Cydulka, MD,
MS, MetroHealth Medical Center.]
CHEST THRUSTS
The chest thrust maneuver is used primarily if someone is morbidly obese or in the late stages of pregnancy and the rescuer cannot reach around the patient’s abdomen to perform abdominal thrusts (Figure 22­8). To perform chest thrusts with the patient standing or sitting, stand behind the patient and place the thumb side of a fist against the victim’s sternum, avoiding the costal margins and the xiphoid process. Grasp the fist with the other hand, and press the fist into the victim’s chest with a quick backward thrust. Repeat until the item is dislodged or the patient becomes unconscious. For an unconscious patient, place the victim supine on a firm surface and kneel close to the victim’s side. Place the hands in the same position as for chest compression (i.e., the lower sternum), and deliver quick thrusts.
FIGURE 22­8. Standing chest thrust maneuver administered to conscious victim of foreign body airway obstruction.
FINGER SWEEP
The finger sweep maneuver is used only in unconscious patients (Figure 22­9). Using the thumb and fingers of one hand, grasp both the tongue and the mandible and lift them. This may partially relieve the obstruction by lifting the tongue away from the back of the throat. With the other hand, insert the index finger into the back of the throat, and use a hooking action in an attempt to dislodge the foreign body to move it into the mouth for manual removal. Use care so the foreign object is not pushed deeper into the throat.
FIGURE 22­9. Finger sweep maneuver administered to unconscious victim of foreign body airway obstruction. [Image used with permission of Rita K. Cydulka, MD,
MS, MetroHealth Medical Center.]
MECHANICAL DEVICES FOR CHEST COMPRESSIONS
Mechanical piston devices are designed to deliver chest compressions in place of manual chest compressions. They consist of an automated compressed gas­ or electric­powered plunger that is placed over the sternum and delivers compressions to the chest at a set rate. Certain devices have a suction cup at the end of the piston to actively decompress the chest following a chest compression. The Lund University Cardiac Arrest System is the most widely used and studied mechanical piston device, but other devices are available as well. A load­distributing band is a circumferential chest compression device composed of a pneumatically or electronically constricting band and backboard. The AutoPulse is an example of a loaddistributing device.
Thus far, studies have not shown that the use of a Lund University Cardiac Arrest System device improves either early (4­hour) or late (1­ and 6­month)
,18 ,20 survival. Literature has shown possible negative effects on outcomes with use of the AutoPulse. Therefore, the American College of

Cardiology/American Heart Association guidelines recommend manual chest compressions as the preferred compression method. The guidelines only recommend the use of a mechanical device by properly trained personnel in specific settings. These settings would include scenarios where compressions are difficult or dangerous for the provider, such as limited provider availability, prolonged CPR, during hypothermic arrest, in a moving ambulance, in an angiography suite, or during preparation for extracorporeal CPR. When using a mechanical device, interruptions should be strictly limited to placement and removal of the device.
COMPLICATIONS OF CPR
Ventilations can cause insufflation of the stomach, leading to regurgitation and aspiration and possibly to gastric rupture. Closed chest compressions can lead to fractures of the sternum or the ribs, separation of the ribs from the sternum, pulmonary contusion, pneumothorax, myocardial contusion, hemorrhagic pericardial effusions, splenic laceration, or liver laceration. Proper techniques can minimize these complications but cannot totally prevent them. Late complications include pulmonary edema, GI hemorrhage, pneumonia, and recurrent cardiopulmonary arrest. Anoxic brain injury can occur in a resuscitated individual subjected to prolonged hypoxia; it is the most common cause of death in resuscitated patients.
TERMINATING RESUSCITATION
Efforts at resuscitation should be continued until the patient recovers spontaneous respirations and cardiac output, the rescuer becomes exhausted, or the patient is pronounced dead. An atraumatic individual who recovers spontaneous respirations and circulation should be placed on his or her side—the recovery position. Recovery from cardiac arrest depends on time to CPR and rhythm­specific intervention. Resuscitation and long­term outcome in normothermic patients with arrest times of  minutes or more are very poor.
ETHICAL CONSIDERATIONS IN RESUSCITATION

During the initiation of resuscitation attempts, try to discover whether or not the victim has advance directives that prohibit CPR.

Family members may wish to be present during resuscitation attempts, and support from social services and clergy should be sought early (see
Chapter , “Ethical Issues of Resuscitation”).


