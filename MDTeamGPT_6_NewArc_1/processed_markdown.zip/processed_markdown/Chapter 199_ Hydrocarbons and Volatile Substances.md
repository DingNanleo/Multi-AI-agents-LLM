## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 199: Hydrocarbons and Volatile Substances
C. William Heise; Frank LoVecchio
INTRODUCTION
Hydrocarbons are a diverse group of organic compounds consisting primarily of carbon and hydrogen atoms. The two basic forms of hydrocarbons are aliphatic (straight­ or branched­chain carbon arrangement) or aromatic (carbon arranged in a ring). Hydrocarbons are in many household and occupational products (Table 199­1). While all hydrocarbons can be toxic, aromatic and halogenated hydrocarbons are associated with the most severe systemic toxicity. Volatile agents are associated with the highest aspiration risk. Identification of the specific hydrocarbon or class can help anticipate specific potential toxicity and guide management.
TABLE 199­1
Common Products That Contain Hydrocarbons
Hydrocarbon and State at Room Temperature Commercial Use
Aliphatic–linear structure, toxicity varies depending on volatility
Gasoline (petrol)–liquid Motor fuel
Kerosene (paraffin)–liquid Stove and lamp fuel
Mineral seal oil–liquid Furniture polish
Petroleum ether–liquid Industrial solvent
Diesel fuel–liquid Motor fuel n­Hexane–liquid Plastic cement, rubber cement
Methane, butane, propane, and ethane–gas Fuel
Mineral spirits (white spirits)–liquid Solvent, paint thinner
Turpentine–liquid Solvent, paint thinner
Mineral oil (liquid paraffin)–liquid Lubricant, laxative
Paraffin wax–solid Industrial uses, candles
Petroleum jelly (petrolatum or soft paraffin)–solid Skin lotion
Aromatic–ring structure, high toxicity
Benzene–liquid Chemical intermediate, gasoline (small amount, .8% on average)

ChapteTro l1u9en9e: –Hliyqduridocarbons and Volatile Substances, C. William HeiAsirep;l aFnrea nglku eL, opVlaestcicc hceioment, acrylic paint 
. Terms of Use * Privacy Policy * Notice * Accessibility
Xylene–liquid Solvent, cleaning agent, degreaser
Halogenated–high toxicity
Carbon tetrachloride–liquid Solvent, refrigerant, aerosol propellant
Chloroform–liquid Solvent, chemical intermediate
Methylene chloride–liquid Paint stripper, varnish remover, aerosol paint, degreaser
Trichloroethylene–liquid Spot remover, degreaser, typewriter correction fluid
Trichloroethane–liquid Spot remover, degreaser, typewriter correction fluid
Tetrachloroethylene (perchloroethylene)–liquid Dry cleaning agent, degreaser
Chain length and branching determine the phase of the hydrocarbon at room temperature. Short­chain aliphatic compounds (up to  carbons), such as methane, ethane, propane, and butane, are gases; intermediate­chain aliphatic compounds (5 to  carbons), such as solvents, lamp oil, lighter fluid, and gasoline, are liquid; and long­chain aliphatic compounds (>19 carbons), such as waxes, are solids. Liquid hydrocarbons account for most
 exposures seen in the ED.
,2
Most hydrocarbon exposures occur as liquid ingestions or inhalations and usually have a benign clinical course. Serious toxicity and deaths associated with hydrocarbon exposure are usually due to ingestions rather than inhalation. Symptoms and signs of pulmonary injury develop in up to
,4 
50% of children who ingest hydrocarbons, and hydrocarbon aspiration can produce acute respiratory distress syndrome. Suicidal injection of
,7 gasoline or kerosene with severe multiorgan toxicity has been reported.
Volatile substances, usually hydrocarbon solvents contained in household or commercial products, can be inhaled for their euphoric effects (Table

199­2). Abusers are typically teenagers and younger adults, especially those in lower socioeconomic groups. Inhalation occurs by three different methods: (1) in “huffing,” the individual soaks a rag with the inhalant and then places it over the mouth and nose; (2) in “bagging,” the individual puts the hydrocarbon in a bag (usually a plastic bag) and repeatedly inhales deeply from the bag; and (3) in “sniffing,” the hydrocarbon is directly inhaled
  via the nostrils. In addition to causing deaths, abuse of volatile agents is associated with crimes such as homicide, sexual assault, and child abuse.
The most commonly abused volatile hydrocarbons are paints, solvents, and gasoline.
TABLE 199­2
Commonly Abused Volatile Substances
Product Volatile Agent
Acrylic spray paint Toluene
Adhesives, glue Toluene, trichloroethylene
Aerosol propellants Propellants and butane
Cigarette lighter refills Butane
Degreasing agents Trichloroethylene
Dry cleaning agents Tetrachloroethylene
Fire extinguishers Bromochlorodifluoromethane
Inhalational anesthetics Nitrous oxide, halothane
Lighter fluid Naphtha
Motor fuel Gasoline (petrol)
Nitrites (“poppers”) Isobutyl nitrite, amyl nitrite
Paint stripper Methylene chloride
Plastic modeling cement Methyl ethyl ketone, toluene
Spot removers Trichloroethylene, trichloroethane
Typewriter correction fluid Trichloroethane, trichloroethylene
PATHOPHYSIOLOGY
The toxic potential of hydrocarbons depends on their physical characteristics (viscosity, surface tension, and volatility), chemical characteristics
(aliphatic, aromatic, or halogenated), presence of toxic additives (pesticides or heavy metals), routes of exposure, concentration, and dose. The physical characteristics contribute the most to aspiration risk.
Viscosity refers to the general “thickness” of a liquid; fluids with a lower viscosity flow more easily than ones with high viscosity. Viscosity is measured in Saybolt universal seconds (SUS); fluids such as gasoline, kerosene, mineral seal oil, and turpentine have low viscosity (<60 SUS), whereas diesel fuel,
 grease, mineral oil, paraffin wax, and petroleum jelly have high viscosity (>100 SUS). Surface tension refers to the property where liquid molecules tend to cohere to each other. Liquids with high surface tension in contact with a solid surface tend to ball up, creating the smallest surface area rather than spreading out. Volatility refers to the ability of the liquid or solid to vaporize and is inversely related to the boiling point; highly volatile liquids have a low boiling point. Ingestion of liquids with low viscosity and surface tension and high volatility increases the risk for aspiration because these substances flow easily, spreading out widely on the oral mucosa, and vaporize at body temperature. Inhalation of aromatic hydrocarbons or halogenated hydrocarbons can result in systemic absorption and the potential for significant toxicity.
CLINICAL FEATURES
Ingestion or aspiration of hydrocarbons mainly impairs the pulmonary system, but depending on the specific compound, the central nervous,
,14 peripheral nervous, GI, cardiovascular, renal, hepatic, dermal, and/or hematologic systems may be affected (Table 199­3).
TABLE 199­3
Clinical Manifestations of Hydrocarbon Exposure
System Clinical Manifestations
Pulmonary Tachypnea, grunting respirations, wheezing, retractions
Cardiac Ventricular dysrhythmias (may occur after exposure to halogenated hydrocarbons and aromatic hydrocarbons)
Central Slurred speech, ataxia, lethargy, coma nervous
Peripheral Numbness and paresthesias in the extremities nervous
GI and Nausea, vomiting, abdominal pain, hepatotoxicity, loss of appetite (mostly with halogenated hydrocarbons) hepatic
Renal and Muscle weakness or paralysis secondary to hypokalemia in patients who abuse toluene metabolic
Hematologic Lethargy (anemia), shortness of breath (anemia), neurologic depression/syncope (carbon monoxide from methylene chloride), cyanosis
(methemoglobinemia from amine­containing hydrocarbons)
Dermal Local erythema, papules, vesicles, generalized scarlatiniform eruption, exfoliative dermatitis, “huffer’s rash,” cellulitis
PULMONARY TOXICITY
Hydrocarbon aspiration causes chemical pneumonitis by direct toxicity to the pulmonary parenchyma and alteration of surfactant function.
Destruction of alveolar and capillary membranes results in increased vascular permeability and edema. The clinical manifestations of pulmonary aspiration are usually apparent soon after exposure from irritation of the oral mucosa and tracheobronchial tree. Symptoms include coughing, choking, gasping, dyspnea, and burning of the mouth. Patients with these symptoms should be assumed to have aspirated.
Signs include tachypnea, grunting respirations, wheezing, or retractions depending on the severity of aspiration. An odor of the hydrocarbon may be noted on the patient’s breath. Hyperthermia of ≥39°C (≥102.2°F) is likely and may occur initially or  to  hours after exposure. The fever is usually an inflammatory response due to pneumonitis. Necrotizing pneumonitis and hemorrhagic pulmonary edema may develop within minutes to hours in patients with severe aspiration. In most fatalities, these complications occur rapidly. With less severe damage, symptoms usually subside within  to  days, except in the case of pneumatoceles and lipoid pneumonias, the symptoms of which may persist for weeks to months.
In most patients with clinically significant aspiration, chest radiography results are eventually abnormal, but the time course of radiographic changes varies and correlation with physical examination findings may be poor. Changes may be seen as early as  minutes after aspiration, but the initial radiograph in a symptomatic patient may be deceptively clear. Conversely, an asymptomatic patient can still have abnormal chest radiographic findings. Radiographic changes usually appear by  to  hours; if they are going to occur, they are almost always present by  hours
(Figure 199­1). The most common radiologic finding is bilateral infiltrates at the bases. Multilobar involvement is more common than single­lobe
15­17 involvement, and right­sided involvement is more common than left­sided involvement. Hydrocarbon­induced aspiration pneumonitis can lead to
 lung necrosis and the creation of a pneumatocele.
FIGURE 199­1. Two chest radiographs of a child who aspirated lamp oil and developed aspiration pneumonitis. A. Day 1: intubated, left lower lobe infiltrates. B. Day 3: intubated, worsening perihilar and bibasilar patchy infiltrates and new right small pleural effusion.
CARDIAC TOXICITY
Life­threatening dysrhythmias, such as ventricular tachycardia and ventricular fibrillation, may occur with systemic absorption. Dysrhythmias occur most commonly after exposure to halogenated hydrocarbons and aromatic hydrocarbons. Exposure to short­chain aliphatic hydrocarbons
 occasionally causes dysrhythmias (mainly ventricular fibrillation). The most worrisome acute complication found in solvent abusers is “sudden
 sniffing death syndrome,” which occurs within minutes of exposure. The mechanism of toxicity is believed to be catecholamine sensitization of the
,10,19 heart by hydrocarbons (especially halogenated hydrocarbons), resulting in ventricular dysrhythmias. Other mechanisms for sudden death include simple asphyxia, respiratory depression, and vagal inhibition. Ventricular akinesia and polymorphic ventricular dysrhythmias have also been
 described after overdose of chloral hydrate (a halogenated aliphatic hydrocarbon).
CNS TOXICITY
CNS effects, primarily depression of consciousness, result from a combination of: (1) direct toxic response to the systemic absorption of the hydrocarbon, (2) indirect result of severe hypoxia secondary to aspiration, (3) simple asphyxiation due to the displacement of oxygen by the volatile hydrocarbon, or (4) volatile substance abuse with a plastic bag that prevents adequate oxygenation. Systemic effects occur through GI absorption, the inhalation of highly volatile petroleum distillates, or direct dermal penetration.

Signs of neurologic toxicity include slurred speech, ataxia, lethargy, and coma. Although hydrocarbons are central neurologic depressants, they often have an initial excitatory effect manifested as hallucinations, tremor, agitation, and convulsions. Individuals who abuse volatile solvents or workers who experience long­term hydrocarbon exposure may present to the ED complaining of recurrent headaches, ataxia, emotional lability, cognitive impairment, or psychomotor impairment.
PERIPHERAL NERVOUS SYSTEM TOXICITY
Exposure to n­hexane, methyl n­butyl ketone, and other six­carbon aliphatic hydrocarbons is associated with the development of a characteristic
 peripheral polyneuropathy caused by demyelinization and retrograde axonal degeneration. Onset of symptoms may be delayed for weeks, and toxicity is attributed to a metabolite, ,5­hexanedione, produced by the cytochrome P450–mediated biotransformation of the parent compounds. This neurotoxic metabolite is thought to inhibit glutaraldehyde­3­phosphate dehydrogenase, which supplies energy for axonal transport.
Clinically, the patient may complain of chronic numbness and paresthesias in the extremities. The key component in making the diagnosis is a history of exposure to solvents, usually through occupations and hobbies. The compound n­hexane is found in gasoline, quick­drying glues, rubber cement,
 and various solvents used in the printing, shoemaking, textile, and furniture industries.
GI AND HEPATIC TOXICITIES
Most hydrocarbons are GI irritants. Vomiting, which occurs in many patients with aliphatic hydrocarbon ingestions, increases the risk of pulmonary
 aspiration. Gastric perforation has been reported after accidental ingestion of chlorofluorocarbons.
,24
Hepatic damage resulting from ingestion of halogenated hydrocarbons is well described. Chlorinated hydrocarbons, such as carbon tetrachloride (CCl ), methylene chloride, trichloroethylene, and tetrachloroethylene, are especially hepatotoxic. For example, CCl
  causes centrilobular liver necrosis similar to acetaminophen toxicity. Free radical metabolites of these agents that cause lipid peroxidation are responsible for hepatocellular destruction. The time course of hepatic dysfunction with acute exposures appears to be similar to that of acetaminophen hepatotoxicity—within  to  hours after ingestion.
Clinically, patients may come to the ED complaining of nausea, vomiting, abdominal pain, or loss of appetite. Depending on the severity, the physical examination may reveal a patient with jaundice, lethargy, and/or abdominal tenderness, especially in the right upper quadrant. Results of serum transaminase tests and other hepatic synthetic function tests may be abnormal within  hours after ingestion.
RENAL AND METABOLIC TOXICITIES
Solvent abuse and occupational exposure to hydrocarbons may result in renal dysfunction. Chlorinated hydrocarbons, such as chloroform,
CCl , and trichloroethylene, are also nephrotoxic. Toluene, an aromatic hydrocarbon that is commonly abused, may cause renal tubular

,25 acidosis in patients who inhale toluene­containing substances. The mechanism of toluene­induced renal tubular acidosis is not clear. The typical metabolic profile of renal tubular acidosis is a normal anion gap hyperchloremic acidosis with hypokalemia and a urine pH of >5.5. The metabolites of
 toluene (hippuric acid and benzoic acid) can be the cause of an elevated anion gap metabolic acidosis.

Clinically, habitual toluene abusers may complain of muscle weakness caused by hypokalemia. The serum potassium level may be so low (<2 mEq/L)
 that severe weakness develops, occasionally resulting in muscle paralysis. Significant rhabdomyolysis may also result. Toluene abuse should be considered in individuals (especially young patients) who come to the ED with symptoms similar to hypokalemic periodic
,27 paralysis.
HEMATOLOGIC TOXICITY
Hydrocarbon­induced hemolysis rarely occurs after the acute ingestion of gasoline, kerosene, and tetrachloroethylene, and after inhalation of mineral spirits. Exposure to benzene (an aromatic hydrocarbon) is associated with an increased incidence of hematologic disorders, including aplastic anemia,
 acute myelogenous leukemia, and multiple myeloma. Naphthalene exposure is associated with hemolytic anemia. Delayed methemoglobinemia is associated with occupational exposure to hydrocarbons containing amine functional groups such as aniline (see Chapter 207,

“Dyshemoglobinemias”). Delayed carboxyhemoglobinemia is associated with methylene chloride exposure due to its metabolism to carbon
 monoxide, which takes a few hours. This is unlike ordinary carbon monoxide exposure from exogenous sources in which the maximum carboxyhemoglobin level occurs at the time of the exposure. Clinically, patients may come to the ED with malaise, headache, dyspnea, or cyanosis depending on the exposure and the severity of the toxicity.
DERMAL TOXICITY
Dermal toxicity from exposure to hydrocarbons is most often associated with the short­chain aliphatic, aromatic, and halogenated hydrocarbons.
These agents act as primary irritants and as sensitizers. Occasionally, highly permeable hydrocarbons can penetrate the skin, resulting in systemic toxicity. Skin findings can range from local erythema, papules, and vesicles to a generalized scarlatiniform eruption and an exfoliative dermatitis (Table

199­3). A “huffer’s rash” may be noted over the face of patients who habitually abuse the volatile hydrocarbons. Frostbite of the face may develop during the inhalational abuse of fluorinated agents. A defatting dermatitis, similar to chronic eczematoid dermatitis, may occur.
Cellulitis and sterile abscesses have been associated with the injection of hydrocarbons, and even a small amount of injected hydrocarbon can cause
 significant injury. Hydrocarbon­induced soft tissue necrosis has recently been seen in patients using “krokodil,” which is desomorphine
 synthesized from codeine using hydrocarbon solvents. Dermal exposure to heated high­viscosity, long­chain aliphatics, such as tar, asphalt, or bitumen, presents a particularly challenging problem because of their association with thermal burns, hyperthermia, and difficulty with
 decontamination. Tar burns are discussed in the Chapter 218, “Chemical Burns.”
DIAGNOSIS
Diagnosis of hydrocarbon toxicity incorporates the findings of the history, physical examination, bedside cardiac and pulmonary monitoring, laboratory tests, and chest radiography. Determine the specific hydrocarbon­containing product, because identification can help anticipate specific potential toxicity and guide management. Pulse oximetry is useful to evaluate oxygenation status, and blood gas analysis can be used to assess ventilation and acid­base status. Cardiac rhythm monitoring and an ECG are indicated in symptomatic patients and patients who ingest halogenated hydrocarbons. A chest radiograph is indicated in a symptomatic patient after hydrocarbon aspiration. Chest radiography is not required in asymptomatic patients.
There are no specific quantitative hydrocarbon tests for standard use when evaluating suspected hydrocarbon intoxication. A basic metabolic panel is indicated in patients with a history of toluene abuse or in whom electrolyte abnormalities and renal insufficiency are suspected. Obtain hepatic function studies, serum ammonia, and prothrombin time in patients who ingest or inhale halogenated hydrocarbons. A CBC is indicated if anemia, bleeding disorder, hemolysis, or leukemia is considered. Measure carboxyhemoglobin level in patients with exposure to methylene chloride; repeat measurements may be necessary. Determination of methemoglobin level is indicated in patients with exposure to hydrocarbons containing amine functional groups. Abdominal radiographs may show evidence of ingestion of chlorinated hydrocarbons such as CCl or chloroform because of the

 radiopaque nature of polyhalogenated substances.
TREATMENT
Securing the airway and maintaining ventilation are the critical maneuvers in patients who present with respiratory depression and/or significant neurologic depression (Table 199­4). Swelling of the lips and tongue due to irritant effect or freeze injuries can complicate airway management.
Administer oxygen to correct hypoxia. Inhaled β ­agonists may also be useful, especially in the setting of bronchospasm, but their role in the treatment
 of hydrocarbon pneumonitis has not been studied. Positive end­expiratory pressure or continuous positive­pressure airway ventilation may sometimes be required to maintain oxygenation, but may increase potential for further (barotrauma) injuries such as pneumothorax or pneumatocele.
In cases of severe pulmonary aspiration resulting in refractory hypoxemia, there are case reports of successful treatment with high­frequency jet
,36 37­ ventilation or extracorporeal membrane oxygenation. Surfactant therapy has been used to treat acute lung injury from hydrocarbon aspiration.

TABLE 199­4
Management of Hydrocarbon Exposures
Airway and Secure airway.
breathing Antidotes: Administer oxygen for carboxyhemoglobinemia and methylene blue for methemoglobinemia.
Provide supplemental oxygen.
Administer inhaled β ­agonists.

Ventilatory support: Provide positive end­expiratory pressure or continuous positive airway pressure as needed to achieve adequate oxygenation.
Cardiac Circulation: Administer IV crystalloid fluid for initial volume resuscitation of hypotensive patients.
Do not use catecholamines in cases of halogenated hydrocarbon exposure.
Consider propranolol, esmolol, or lidocaine for ventricular dysrhythmias induced by halogenated hydrocarbon exposure.
Consult the poison control center, toxicologist, and other appropriate specialists as needed.
Decontamination Dermal: Remove hydrocarbon­soaked clothes, decontaminate skin with soap and water, and decontaminate eyes with saline irrigation.
GI: Not indicated. See discussion below.
Other Laboratory tests: Order CBC, basic metabolic panel, liver function tests (serum transaminase, bilirubin, albumin levels), prothrombin time, partial thromboplastin time, carboxyhemoglobin level, methemoglobin level, and/or radiologic studies as indicated (see text).
Correct electrolyte abnormalities.
Do not give steroids.
Administer blood products as needed.
Treat hypotension with aggressive fluid resuscitation. Avoid administration ofcatecholamines such as dopamine, norepinephrine, and epinephrine. Catecholamines may cause dysrhythmias, especially after exposure to halogenated hydrocarbons and aromatic hydrocarbons. Hydrocarbon­induced dysrhythmias are generally seen shortly after the exposure, especially with inhalational use. Continuous cardiac monitoring should be initiated, and an ECG should be obtained. For hydrocarbon­induced ventricular dysrhythmias, class IA (procainamide) or
 class III (amiodarone, bretylium, and sotalol) antiarrhythmics should be avoided because of the risk of QT interval prolongation. Propranolol,
,19,41 esmolol, and lidocaine have all been reported to successfully treat these ventricular dysrhythmias in case reports.

There is no indication for gastric lavage because risks of aspiration far outweigh any theoretical benefits. Activated charcoal is not recommended; it does not adsorb hydrocarbons well and poses a risk for vomiting and aspiration. In the rare case where a recent (<1 hour) exposure has occurred with a highly toxic hydrocarbon (e.g., aromatic or halogenated chemical) or in which a hydrocarbon has been combined with another highly toxic substance
(e.g., pesticide), consultation with a poison center may result in recommendation for gastric lavage; even in these cases, benefit from gastric lavage is unproven.

There is no clear evidence that corticosteroids are helpful in hydrocarbon­induced pneumonitis. One meta­analysis advocating low­dose steroids for
 acute lung injury and respiratory distress has been criticized because the patients were not generally treated with current lung­protective ventilation
 strategies. Antibiotics are not indicated unless there is clinical suspicion of superimposed bacterial pneumonitis.
In summary, exogenous catecholamines (e.g., epinephrine), prophylactic antibiotics, and corticosteroids should be avoided.
In dermal exposures, decontamination is preferably done at the scene or before entering the ED to avoid spreading fumes to patient treatment areas.
The patient needs to be fully undressed to prevent ongoing contamination from hydrocarbon­soaked clothes. Make sure staff wear protective gloves and aprons to prevent secondary exposure, especially to organophosphate­containing mixtures. Dermal decontamination with soap and cold water and eye decontamination with saline irrigation should be performed.
DISPOSITION AND FOLLOW­UP
If feasible, consult a medical toxicologist or regional poison control center for symptomatic hydrocarbon exposures and asymptomatic exposures to aromatic hydrocarbons or hydrocarbons with toxic additives. In cases of inhalation or aspiration of nonhalogenated aliphatic hydrocarbons, asymptomatic patients may be discharged home after about  to  hours of observation with instructions to return if delayed symptoms develop.
Further observation or hospitalization is required for patients who are symptomatic after hydrocarbon exposure. For pediatric hydrocarbon
 ingestions, the presence of wheezing, altered consciousness, or tachypnea within  hours predicts the need for further treatment. Hospitalization is also recommended for those who ingest hydrocarbons capable of producing delayed complications (e.g., halogenated hydrocarbons causing hepatic toxicity) or hydrocarbons with toxic additives (organophosphates and organic metal compounds). Patients with suicidal intent or with complications of solvent abuse need behavioral health evaluation.


