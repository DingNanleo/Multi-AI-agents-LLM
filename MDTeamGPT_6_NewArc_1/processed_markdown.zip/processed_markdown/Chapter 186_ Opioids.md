## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 186: Opioids
Jennifer S. Love; Jeanmarie Perrone
Content Update: Xylazine. November 2023
Xylazine, a central α­2­agonist, a nonopioid anesthetic/analgesic used in veterinary medicine, has emerged as a common adulterant in opioids and other street drugs. Clinical effects of xylazine and emerging non­fentanyl synthetic opioids are discussed in Special Considerations under Xylazine.
Detailed discussion of Opiate Withdrawal treatment is found in Chapter 292, and Figure 292­4. INTRODUCTION
Opioids refers broadly to all compounds related to opium that possess analgesic and sedative properties. Opiate describes the alkaloids codeine and morphine found naturally in the opium poppy plant, Papaver somniferum.Narcotic refers to a broader group of soporific drugs, a term predominantly used by law enforcement to refer to controlled substances with abuse or addictive potential; use of this term in medical practice is discouraged.
Opioid use and opioid use disorder are significant public health issues in the United States with a dramatic increase in ED visits related to opioids in the
,2 past  years. Over ,000 people died in the United States from opioid overdose in 2021. In recent years, opioid overdose deaths are primarily due
 to the rise in synthetic opioids, including fentanyl. Synthetic opioids were reported in over ,000 US deaths in 2021. PHARMACOLOGY
Opioids modulate nociception at the terminals of afferent nerves in the CNS, peripheral nervous system, and GI tract. Opioids are agonists at the three primary opioid receptors: µ (mu), κ (kappa), and δ (delta). Opioid receptors are similar to other G protein­coupled receptors; transmembrane proteins that undergo conformation change when activated by external molecules that then alters some aspect of intracellular function. Opioid receptors vary widely in morphology and distribution. In addition, the specificity and affinity of an opioid for a particular receptor are variable. For example, tramadol possesses 1/6000th the affinity of morphine at the µ­receptor site.
Stimulation of the µ­receptors results in analgesia, sedation, miosis, respiratory depression, cough suppression, euphoria, and decreased GI motility.
Stimulation of κ­receptors results in weaker analgesia, sedation, miosis, decreased intestinal motility, dysphoria, and hallucinations. Stimulation of the δ­receptors results in some analgesia and antidepressant effect. All currently available opioid agonists possess µ­receptor activity and result in some degree of respiratory depression.
Opioids can be categorized as naturally occurring compounds (termed opiates), chemical modifications of natural compounds (semisynthetic), and the synthetic derivatives (Table 186­1). Some opioids are agonists at all opioid receptors (e.g., morphine and hydromorphone), whereas others are partial agonists–antagonists (e.g., pentazocine, butorphanol, nalbuphine, and buprenorphine) at the opioid receptors.
TABLE 186­1
Classification and Characteristics of Major Pharmaceutical Opioids
Oral Dose Equianalgesic to Parenteral Dose Equianalgesic to Duration of
Elimination Half­Life* Morphine  milligrams SC Morphine  milligrams SC Analgesic

(h)
Chapter 186: Opioids, Je(mnnililfiegrr aSm. Ls)ove; Jeanmarie Perrone(milligrams) Action* (h) 
. Terms of Use * Privacy Policy * Notice * Accessibility
Opiate
Codeine 200 120 4–6 .5–4
Morphine   3–4 2–4
Semisynthetic
Buprenorphine  SL .3 6–24 20–44
Hydrocodone  Not available 4–6 
Hydromorphone .5 .5 2–4 2–3
Oxycodone  Not available 3–6 3–4
Oxymorphone  .5 4–6 7–11
Synthetic
Diphenoxylate .5 Not available Not applicable  h for diphenoxylate and
12–14 h for difenoxin†
Fentanyl .125 .100  3–4
Meperidine 300 100 1–3 3–4 h for meperidine and
15–30 h for normeperidine†
Methadone   8–12 12–18
Tapentadol  Not available 4–6 4–5
Tramadol 100 100 4–6 5–7
Abbreviation: SL = sublingual.
*Initial doses in therapeutic amounts.
†Active metabolite.
PHARMACOKINETICS
Opioids are readily absorbed, achieving peak blood levels  to  minutes after ingestion of standard oral formulations. But other pharmacokinetic elements can vary depending on whether the opioid is a short­acting, long­acting, or sustained­release formulation. Long­acting opioids, such as methadone, reach peak blood levels in  to  minutes, but have a long duration of effect and half­life. Sustained­release forms take longer to achieve peak blood levels; for example, morphine sulfate controlled­release tablets reach peak blood levels at  minutes compared with  minutes for standard morphine tablets. As the name implies, sustained­release forms also have a long duration of effect compared to the immediate­release formulations.
After GI absorption, most opioids undergo first­pass hepatic metabolism, so bioavailability can vary from as low as 10% to as high as 80% after PO administration. Thus, at equal doses, most opioids are more potent given parenterally than PO. The opioids with good oral bioavailability are codeine, oxycodone, methadone, hydromorphone, and tapentadol.
The metabolism of codeine, meperidine, methadone, morphine, and oxycodone is primarily hepatic and subject to drug interactions and genetic variations. For example, antiretroviral medications can enhance the metabolism of methadone, which results in lower plasma methadone concentrations. As another example, codeine is metabolized to morphine via cytochrome P450 isoenzyme 2D6, an enzyme with genotypic and phenotypic variability. Patients with rapid cytochrome P450 enzyme 2D6 metabolism produce more morphine after a fixed dose of codeine. These interactions and genetic variations may influence the therapeutic effect of opioids (see Chapter , “Acute Pain Management”).
In drug misuse, unconventional routes of administration (insufflating or injecting ground opioid tablets, heating fentanyl patches or applying multiple patches to the skin) may alter the drug’s pharmacokinetics and often increase the rate of opioid absorption. Similarly, in opioid overdoses resulting in high plasma levels, the pharmacokinetics are altered due to enzymatic saturation. This may increase the severity of poisoning, delay the onset, and prolong the duration of action, as compared with the expected therapeutic actions.
OPIOID INTOXICATION
CLINICAL FEATURES
The brief descriptor of the widely recognized opioid toxidrome would include the triad of miosis, lethargy, and respiratory depression. The full effects associated with opioid intoxication also can include orthostatic hypotension, nausea and vomiting
(especially in opioid­naive patients), histamine release resulting in localized urticaria (Figure 186­1) bronchospasm, ileus
,5 secondary to decreased GI motility, and urinary retention secondary to increased vesical sphincter tone. The depression in mental status can be profound. The respiratory depression is characterized by slow and shallow respirations that can produce hypercarbia, hypoxia, and cyanosis. Miosis is not universally present from intoxication with every opioid; normal or even enlarged pupils have been documented secondary to pentazocine and meperidine toxicity. Mydriasis may also signal severe cerebral hypoxia or result from co­ingestants (diphenoxylate, heroin, scopolamine). Other possible findings in opioid toxicity include hypothermia, rhabdomyolysis, compartment syndrome, myoglobinuric renal failure, and seizures associated with overdoses of tramadol and meperidine.
FIGURE 186­1. Urticaria on a forearm from local histamine release due to IV morphine. [Photo used with permission of J. S. Stapczynski, MD.]
Opioid­induced acute lung injury, previously known as noncardiogenic pulmonary edema, is an uncommon complication associated with opioid
,6 overdose. Acute lung injury can occur immediately or be delayed up to  hours after overdose and presents with tachypnea, rales, decreased
 oxygen saturation, and bilateral pulmonary infiltrates with a normal cardiac silhouette on chest radiograph. The incidence of acute lung injury is 10%
 in patients with severe overdose requiring naloxone. The pathophysiology of opioid­induced acute lung injury is poorly understood and may be multifactorial. Pulmonary edema may result from direct alveolar injury from hypoxia, opioid­induced histamine release, capillary leak due to negative
,9 inspiratory pressure, or neurogenic injury. Treatment includes oxygen supplementation and ventilatory support, with either noninvasive or invasive modalities. Additional naloxone, diuretics, and digoxin are not indicated.
The combination of meperidine, tramadol, or dextromethorphan with monoamine oxidase inhibitors, selective serotonin reuptake inhibitors, or
 linezolid can result in serotonin syndrome (see Chapter 178, “Atypical and Serotonergic Antidepressants”). Serotonin syndrome is characterized by a spectrum of altered mentation from anxiety to delirium, hyperthermia, autonomic instability, and hyperreflexia, especially in the lower
,11 extremities. Although uncommon, deaths have been reported. Naloxone is not effective in treating opioid­induced serotonin syndrome.
DIAGNOSIS
The triad of lethargy, miosis, and respiratory depression strongly suggests opioid intoxication, and in many clinical scenarios, specific evidence of opioid use is present. The combination of a respiratory rate of <12 breaths/min, miosis, and circumstantial evidence of opioid use (drug
 paraphernalia, needle marks, presence of a tourniquet, bystander corroboration) was highly sensitive for opioid overdose in the prehospital setting.
Physical examination should be thorough: patients should be undressed completely yet carefully because drug use paraphernalia including needles and syringes may be hidden within clothing. Look for evidence of injection drug use, concealed opioids, or fentanyl patches on all parts of the body, including mucous cavities. Listen for auscultatory findings suggestive of pulmonary edema; palpate muscle groups to detect signs of compartment syndrome.
The differential diagnosis of opioid intoxication includes toxicologic exposure to drugs and compounds that produce similar findings, such as clonidine, organophosphates and carbamates, phenothiazines and atypical antipsychotic medications, sedative­hypnotic medications, and carbon monoxide. Clonidine overdoses are characterized by coma, bradycardia, hypotension, miosis, and periods of apnea that respond to tactile or auditory stimulation. Organophosphate and carbamate overdoses cause the cholinergic toxidrome: miosis, muscle fasciculations, profuse vomiting and
 diarrhea, and sweating. Phenothiazines, olanzapine, and risperidone cause neurologic depression and miosis from decreased adrenergic tone.
Gamma­hydroxybutyrate intoxication is associated with profound CNS depression, bradypnea, and, occasionally, miosis. Sedative­hypnotic agents and carbon monoxide cause profound neurologic depression but are not usually associated with miosis. Hypoglycemia, hypoxia, CNS infections, postictal states, and pontine and intracranial hemorrhages should also be considered in the differential diagnosis.
OPIOID SCREENS
A qualitative urine opioid screen may aid in the diagnosis, but available tests have limitations. The assay in most commercially available urine opioid
 screens recognizes morphine. Opioids that are metabolized to morphine, such as codeine and heroin, as well as hydromorphone are detected by
,16 this urine assay as opiates. Specific immunoassay screens are available for oxycodone, fentanyl, or methadone. Confirmation of a positive immunoassay screen requires gas chromatography/mass spectroscopy testing. Some common medications will produce false­positive results on opioid drug screens (Table 186­2).
TABLE 186­2
Medications Causing False­Positive Results on Urine Opioid Screens14
False­Positive Urine Opioid Screen False­Positive Urine Methadone Screen
Poppy seeds Chlorpromazine
Rifampin, rifampicin Clomipramine
Quinine Diphenhydramine
Diphenhydramine Doxylamine
Fluoroquinolones Ibuprofen
Dextromethorphan Quetiapine
Thioridazine
Verapamil
A urine opioid screen can be positive up to  to  days after a single use of codeine, morphine, or heroin. The oxycodone, fentanyl, and methadonespecific screens can be positive up to  days after ingestion. As with most urine drug screening in the ED, detection of a drug taken in the recent past may not correctly identify the toxicologic cause of the patient’s current condition. Serum acetaminophen concentration should be obtained in all suicidal ingestions and all cases of combination opioid–acetaminophen ingestions.
TREATMENT
Airway protection and ventilatory assistance are the most important treatment steps for opioid intoxications, because respiratory depression is the
,5 major morbidity and the cause of mortality. Use bag­valve mask ventilatory support as needed to initially maintain adequate oxygenation and ventilation. After adequate ventilation is ensured, administer naloxone (Table 186­3). Endotracheal intubation may be necessary in some cases of opioid or polysubstance overdose with respiratory depression unresponsive or poorly responsive to naloxone or in cases in which acute lung injury is
,5 suspected. Intubation offers the advantages of airway protection, easy access for suctioning, and provision of an alternate route of administration for some medications.
TABLE 186­3
Naloxone
Drug Route Initial Dose* Onset of Action Duration of Action†
Naloxone IV .04 milligrams if breathing spontaneously and suspected of chronic opioid use 1–2 min 20–90 min
### .4 milligrams if breathing spontaneously and opioid naive
 milligrams if apneic or cyanotic
IM or SC  milligrams 5–6 min
Intranasal  milligrams (1 milligram in each nostril) 6–8 min
Nebulized  milligrams in  mL normal saline  min
*See text regarding subsequent dosing.
†Duration dependent on amount of opioid agonist present.
Single­dose activated charcoal (1 gram/kg PO) may be indicated in some patient populations, such as pediatric oral ingestion, if the patient is fully awake, or after the airway is protected with an endotracheal tube. Under special circumstances, delayed and multiple doses of activated charcoal may
 be useful, as in diphenoxylate hydrochloride–atropine sulfate overdoses and in cases of large ingestions of sustained­release preparations.
OPIOID ANTAGONISTS
Naloxone, a derivative of oxymorphone, is a pure competitive antagonist at all opioid receptors, with particular affinity for µ­receptors. Therefore, naloxone fully reverses all the effects of opioids, including respiratory depression, sedation, miosis, and analgesia. The elimination half­life of naloxone is  to  minutes, but the duration of action is as short as  minutes if a large amount of opioid agonist is present.
Naloxone has poor oral bioavailability but is well absorbed when given by injection (IV, SC, or IM), inhaled, or deposited on mucosa (intratracheally or intranasally, but not sublingual). Inhaled naloxone by nebulization is reasonably effective in reversing depressed mental status and respirations in
18­20 opioid toxicity, with about 10% requiring additional rescue parenteral naloxone. Intranasally administered naloxone provides a pharmacokinetic
21­24 profile similar to that of IM or SC naloxone and is used by EMS personnel and in bystander naloxone administration programs.
Naloxone effectiveness is dependent on the dose administered and the amount of opioid that needs to be reversed, balanced against the risk of
 precipitating withdrawal. There is wide variation in recommended naloxone doses to treat opioid toxicity. It is prudent to use a small starting dose of naloxone, .04 milligram IV, in opioid­dependent patients who present with mental status depression and modest respiratory depression, because
 larger doses can induce opioid withdrawal symptoms in these individuals. An initial dose of naloxone, .4 milligram IV, is recommended in non– opioid­dependent patients who present with mental status depression and modest respiratory depression. Subsequent doses of naloxone of .04 milligram to .4 milligram IV are administered every  to  minutes until the desired effect is reached. Incremental dosing of naloxone mitigates the
 precipitation of acute opioid withdrawal.
For patients presenting with apnea or near­apnea or cardiac arrest, a large starting dose of naloxone,  milligrams IV, should be administered regardless of drug use history. Repeated doses of  milligrams IV every  minutes are recommended until a maximum of  milligrams IV is reached or respiratory depression is reversed. Exposures to fentanyl, novel synthetic opioids, and sustained­release preparations may require these larger­thanordinary doses. Toxicity from leaking opioid­containing packets in the intestinal tract (i.e., in “body packers”) can be extremely severe, and such patients can require a larger total naloxone dose and sustained naloxone treatment until the drug­containing packets are expelled or removed.
The duration of action of naloxone may be shorter than that of the offending opioid, so naloxone infusions are occasionally required to support respiration over several hours as the opioid is metabolized. This is especially true for certain long­acting opioids, such as buprenorphine and methadone; for exposures to sustained­release preparations; and for ingestions of transdermal fentanyl patches. A continuous infusion should be considered only if the patient responded to the initial naloxone bolus and subsequently required repeat administration. To calculate the naloxone continuous infusion dose, determine the “wake­up dose” and administer two thirds of that dose per hour by IV infusion.
Adjustments may be required if the patient develops respiratory depression (by repeating a bolus and increasing infusion rates) or withdrawal symptoms (by decreasing infusion rates). It is recommended that patients on naloxone infusions be admitted to a monitored unit.
Naloxone has a remarkable safety profile. When administered to opioid­naive patients, naloxone has no adverse effects. Although adverse effects are
 seen in about one third of patients who receive it for a suspected opioid overdose, serious complications are rare. The most common adverse effects associated with naloxone are anxiety, nausea, vomiting, diarrhea, abdominal cramps, piloerection, yawning, and rhinorrhea, which are expected signs
,29 and symptoms of opioid withdrawal. Careful dosing of naloxone can prevent the precipitation of opioid withdrawal symptoms.
Naltrexone, an oral opioid antagonist, is primarily used to maintain opioid abstinence after detoxification. Naltrexone, compounded into an extended­release monthly injection (Vivitrol®), is available to treat alcohol or opioid abstinence. Nalmefene, both an oral and parenteral opioid antagonist, has not been available in the United States since August 2008 but is available in Europe. Both naltrexone and nalmefene are long­acting reversal agents, so opioid­dependent patients who receive either of these reversal medications intentionally or inadvertently may require protracted management of withdrawal symptoms.
DISPOSITION AND FOLLOW­UP
The optimal observation period after an opioid intoxication is determined by the history and clinical picture. Patients with presumed isolated heroin intoxication who respond to naloxone can be safely discharged  hour after administration of naloxone if they have independent mobility, normal vital
30­32 signs, and normal mental status.
In cases of exposure to opioids other than heroin, such as fentanyl, an observation period of  to  hours in the ED is recommended after the last naloxone administration. Some patients who have been exposed to synthetic opioids may be safely discharged following a shorter observation time,
 but current safety data are limited. In long­acting opioid overdose, observation should be extended for a minimum of  hours. Moderate to severely symptomatic patients usually require hospital admission to monitored settings and may require continued administration of naloxone. A behavioral health evaluation is needed in cases with suicidal intent.
SPECIAL CONSIDERATIONS
BUPRENORPHINE
Buprenorphine is a mixed opioid agonist–antagonist, with partial agonist activity at µ­receptors and antagonist activity at κ­ and δ­receptors. Because
 buprenorphine is only a partial agonist at µ­receptors, it has decreased intrinsic activity that causes its clinical effects to plateau at higher dosages.
Buprenorphine has high affinity for and slow dissociation from the µ­receptor, which results in a long duration of action. Furthermore, other opioid agonists (such as heroin) or antagonists (such as naloxone) cannot easily displace buprenorphine from the µ­receptor. Buprenorphine has poor oral bioavailability because of extensive first­pass metabolism and is therefore administered using sublingual films or tablets or parenterally. The most frequently prescribed sublingual buprenorphine formulation is in combination with naloxone in a 4:1 ratio. Because naloxone has poor bioavailability from PO or sublingual administration, it was introduced into the preparation to discourage and limit parenteral abuse of the buprenorphine portion while not interfering with therapeutic use in the form of the sublingual film.
Buprenorphine can be associated with three distinct clinical scenarios. First, the opioid­naive patient who overdoses on buprenorphine will experience mental status depression, nausea, vomiting, miosis, and respiratory depression (usually with a plateau). Children exposed to
 buprenorphine do not have a ceiling effect and respiratory depression may occur with single ingestions. In opioid­naïve patients,
 low­dose naloxone may not be fully effective in reversing mental status and respiratory depression. Because of the long duration of action of buprenorphine, naloxone infusions are necessary, and admission to the hospital is necessary in symptomatic patients. The second possible scenario is buprenorphine exposure in the opioid­dependent patient. In this case, buprenorphine will precipitate opioid withdrawal symptoms, because the partial agonist buprenorphine behaves like an antagonist in the presence of an agonist. Buprenorphine­induced withdrawal is best managed with additional buprenorphine doses, frequent and rapid withdrawal reassessments and symptom­driven therapy, including antiemetics, nonopioid analgesics, antidiarrheal medications, and nonbenzodiazepine sedatives. The third possible clinical scenario is buprenorphine exposure in the opioid­dependent patient who is suffering from opioid withdrawal, in whom buprenorphine will act as a partial agonist and alleviate the symptoms of opioid withdrawal. Thus, buprenorphine is unique in that it can both induce and treat opioid withdrawal, depending on
 the timing of its administration. Buprenorphine can be used in the ED to alleviate opioid withdrawal and be prescribed upon ED discharge to
 transition treatment seeking patients to medications for opioid use disorder (MOUD).
METHADONE
Methadone is a synthetic opioid used as opioid replacement therapy in opioid dependence and can be prescribed as an analgesic for chronic pain. The initial analgesic duration is  to  hours with an elimination half­life of  to  hours. With repetitive dosing, analgesic action duration and elimination half­life increase to approximately  to  hours and up to  hours, respectively. The long duration of activity enables once­a­day dosing
,38 during chronic therapy. Methadone has a higher risk for overdose­related deaths than other opioids, often with co­ingestants. Acute methadone overdoses present similarly to other opioid intoxications, but the duration can be much longer, requiring naloxone infusions with close neurologic and
 respiratory monitoring.

Methadone has several drug–drug interactions that can precipitate toxicity or withdrawal in patients on chronic therapy. Interactions between methadone and human immunodeficiency virus medications are common and complex, creating potential for both increased toxicity and withdrawal.
The relevant interactions for emergency physicians include ciprofloxacin, fluconazole, ketoconazole, and omeprazole, which can increase toxicity.
Drug–methadone interactions that have potential to precipitate withdrawal include macrolides (especially clarithromycin), phenobarbital, phenytoin, spironolactone, and verapamil.
Methadone prolongs the QT interval in acute overdose or during long­term methadone treatment, providing the potential for cardiac
 dysrhythmias, such as torsades de pointes. In patients with acute methadone overdose resulting in QT interval prolongation, serum electrolytes should be optimized and the patient should be admitted to a monitored unit until the condition resolves. Patients on long­term methadone therapy who develop a QT interval between 450 and 500 milliseconds do not require a dosage adjustment, but electrolyte imbalances should be corrected if c present, and patients should be followed on an outpatient basis with frequent ECGs. Patients who develop a QT interval of >500 milliseconds should c
 be considered for methadone dosage reduction or discontinuation.
TRAMADOL
Tramadol is being increasingly prescribed in the United States for chronic pain. Tramadol binds norepinephrine and serotonin reuptake inhibitors to contribute to its analgesic effects. Tramadol has no direct opiate­binding capacity, but after it is metabolized by cytochrome P450 enzymes, the active metabolite, O­desmethyltramadol, binds the µ­opioid receptor. Tramadol’s opioid effects can vary widely because of genetic variation, liver disease,
,44 renal disease, and co­prescribed drugs that affect cytochrome P450 metabolism capacity.
,46
Tramadol overdoses are associated with lethargy, nausea, tachycardia, and seizures. At doses exceeding 500 milligrams, coma, hypertension,
,47  respiratory depression, and apnea are seen. Features consistent with serotonin syndrome have been seen in isolated tramadol overdoses.
Tramadol­induced seizures are common, and naloxone is ineffective in preventing them. Fortunately, tramadol­induced seizures are usually single,
,50 and anticonvulsants are not necessary. Tramadol has also been associated with higher rates of hypoglycemia compared to codeine, especially
,51 within the first  days of use. Dependence during chronic therapy and withdrawal symptoms upon discontinuation have been reported with
 tramadol.
MIXED AGONISTS–ANTAGONISTS
The mixed agonists–antagonists include pentazocine, butorphanol, and nalbuphine. These agents have variable but mostly antagonist activity at the µ­ receptor and agonist effects at the κ­receptor. They may cause significant respiratory depression in overdose, and naloxone will reverse this respiratory depression. Mixed agonists–antagonists usually precipitate withdrawal when taken by an opioid­dependent individual, which reduces their
 potential for abuse. Pentazocine overdose can cause seizures.
DIPHENOXYLATE HYDROCHLORIDE–ATROPINE SULFATE
Diphenoxylate hydrochloride–atropine sulfate is a frequently prescribed antidiarrheal agent. The medication is formulated as a combination tablet or liquid, containing diphenoxylate, .5 milligrams, and atropine, .025 milligram, in each tablet or  mL of liquid. In an overdose, initially the anticholinergic toxidrome dominates the clinical picture (see Chapter 202, “Anticholinergics”). The second phase of intoxication is characterized by the opioid toxidrome. Children <6 years of age can be symptomatic after ingestion of a single tablet. In pediatric patients, absorption can be delayed up to
 to  hours in some cases because of the effect of atropine on GI motility. Admission and observation for  hours are recommended for children <6 years of age after ingestion of a combination tablet of diphenoxylate and atropine. Older children and adults should be observed in the ED for  hours.
Administration of activated charcoal is recommended unless contraindicated.
FENTANYL AND FENTANYL ANALOGS

Fentanyl and novel synthetic opioids have contributed to rising opioid overdose deaths since 2016. Novel synthetic opioids include both fentanyl analogs (acetylfentanyl, butyrlfentanyl, furanylfentanyl, carfentanil) and nonfentanyl µ­opioid agonists (U47700), all with varying and usually high
55­57 potencies. Illicitly manufactured fentanyl is  to 100 times more potent than morphine and has been detected in >50% of opioid overdose deaths
  in some states. Illicitly manufactured fentanyl has been found as a contaminant in opioids, benzodiazepines, and cocaine. Due to their ultrapotency, overdoses of illicitly manufactured fentanyl and novel synthetic opioids may require administration of more rapid naloxone boluses,
,56 higher total doses of naloxone, or prolonged naloxone treatment, to reverse respiratory depression related to overdose.
XYLAZINE
Xylazine or “tranq,” a nonopioid anesthetic and analgesic medication used in veterinary medicine, has emerged in the unregulated opioid supply in the
United States. Xylazine is a potent central α­2­agonist and is not approved for use in humans. Xylazine is used as an adulterant in opioids and other street drugs, and it reportedly extends opioid effects. It has been identified admixed with a variety of opioids (fentanyl, heroin) and with
,81 benzodiazepines and stimulants. It can be used IV, IM, SC, PO, and by inhalation through smoking and snorting. Xylazine use is spreading
 throughout the United States and is also reported to be in Canadian street drugs. On April , 2023, the White House Office of National Drug Control
Policy declared fentanyl adulterated with xylazine an emerging toxicologic threat.
Clinical effects observed in human case reports of isolated xylazine overdose are variable and sometimes include hypotension, bradycardia, and respiratory depression. But, xylazine more consistently causes drowsiness, lethargy, and coma. In human case series of overdose, patients primarily experience sedation. Hypotension and bradycardia are reported less frequently.
Xylazine exposure is also associated with skin ulcerations and skin necrosis, primarily on the extremities. The pathophysiology of the skin ulcerations are unclear but may be due to vasoconstriction of cutaneous vessels. Ulcerations may occur in areas remote from the injection site and have been
,84 reported among those with inhalational and intranasal use.
Treatment is supportive. Naloxone is the first­line antidote, since most of the respiratory depressant effects are driven by the co­presence of
 fentanyl. Although naloxone has no effect on xylazine, supportive care for persistent lethargy after naloxone administration is often sufficient. There is no xylazine­specific antidote. Wound care includes topical antibacterial ointments and tissue sparing debridement.
Xylazine testing may be obtained through some specialized academic hospital centers or reference laboratories. It is currently not standard through most hospital labs. Community substance use clinics or overdose prevention sites may provide xylazine checking through drug paraphernalia or donated drug sample testing which can inform local approaches. Xylazine test strips, which employ immunoassay technology similar to urine
 pregnancy tests, may be occasionally available for drug product checking. Currently, there is no point­of­care testing for blood or urine samples to detect xylazine.
Many users report withdrawal symptoms, including irritability, restlessness, anxiety, or dysphoria starting 6–12 h after last xylazine use. Symptoms overlap with opioid withdrawal and complicate interpretation of the COWS. Treatment is medications for opioid withdrawal—either buprenorphine or
 methadone and adjunctive medications for symptom management.
Novel and potent non­fentanyl synthetic opioids (NSO), such as nitazenes and brorphine, are rapidly emerging and are being detected in fatal and non­
 ,88 fatal overdoses. Standard immunoassays do not detect these agents. Treatment is naloxone and supportive care.
MIXED DRUGS AND CONTAMINANTS
Heroin is often mixed with other compounds, such as cocaine, scopolamine, clenbuterol, and fentanyl, which may contribute to varied opioid toxidromes. Adulterants found in illicit heroin may include strychnine, quinine, lactose, and talc. Scopolamine is an antimuscarinic agent that produces the anticholinergic toxidrome. Clenbuterol is a long­acting β­adrenergic agonist similar to albuterol and is used in veterinary medicine. A
 potent neurotoxin, 1­methyl­4­phenyl­1,2,3­tetrahydropyridine, has been used as a meperidine adulterant, producing parkinsonism in users.
Starting in Russia in 2010, episodes of deaths and gangrene were reported associated with IV desomorphine or “Krokodil,” a synthetic alternative to heroin crudely made from codeine tablets with a high concentration of tissue­toxic impurities. The colloquial name is derived from the appearance of
 the skin after it is injected.
KRATOM
Kratom (Mitragyna speciosa) has mitragynine as its principal alkaloid, with stimulating effects at low doses (cocaine­like effect) and sedative effects

(opioid­like effect) at high doses. Kratom has been used since the early 1930s in Africa and Southeast Asia for medicinal purposes and more recently
 to prevent opioid withdrawal symptoms by smoking, consuming, brewing, or mixing into drinks. There has been growing use of kratom in Western
 countries due to its availability in smoke shops and on the Internet. Since 2010, there has been a 10­fold increase in reported use in the United

States.
Kratom is used in the United States for three distinct indications: (1) to help manage chronic pain, (2) to mitigate withdrawal symptoms from opioids or
 ,66 alcohol, and (3) for acute euphoric effects. Daily kratom use can lead to dependence, craving, and withdrawal symptoms. Kratom can produce
  seizures, serious toxicity, or even death, often associated with other drug use, such as decongestants, antidepressants, and benzodiazepines.

Krypton, a combination containing kratom, O­desmethyltramadol, and caffeine, has also been associated with fatalities.
LOPERAMIDE
,71
Loperamide, also known as “the poor man’s methadone,” has seen rising rates of misuse, abuse, and suicide ingestion since 2010. At high doses
(between  and 300 milligrams,  to 150 times the therapeutic dose of  milligrams), loperamide binds the µ­opioid receptor and has greater CNS penetration, leading to euphoria and mental depression. It can also cause severe cardiotoxic effects, including QT prolongation, QRS widening, c
,72 ventricular tachycardia, ventricular fibrillation, and other cardiac dysrhythmias, due to both sodium and potassium channel blockade.
Treatment of loperamide overdose should target three modes: GI decontamination, respiratory depression, and cardiotoxicity. Activated charcoal may be used for GI decontamination and repeated because loperamide inhibits peristalsis. Standard doses of naloxone (0.04 to .4 milligram) should be used to reverse respiratory depression. Cardiotoxicity due to sodium channel blockade potential with widened QRS complex is treated with sodium bicarbonate  to  mEq/kg IV, along with potassium and magnesium replacement. For patients with torsades de pointes, case reports have
,73 demonstrated success with cardiac overdrive pacing and isoproterenol IV infusions at  to  micrograms/min. Other advanced therapies
 including intravenous lipid emulsion therapy and extracorporeal membrane oxygenation have had limited success in individual cases.
OPIOID WITHDRAWAL
Downregulation of endogenous endorphins, dynorphins, and opioid receptors occurs with long­term use of opioids. Abrupt cessation of opioid use does not allow time for upregulation of receptors and results in increased neuronal firing and the opioid withdrawal syndrome.
Opioid withdrawal typically starts  to  hours after last use of short­acting opioids and  hours after abstinence from long­acting opioids. Opioid withdrawal can be abruptly precipitated by the administration of antagonists such as naloxone or naltrexone or the administration of partial agonist– antagonists such as buprenorphine. Opioid withdrawal usually starts with anxiety and progresses with development of additional symptoms over the
 next  to  hours (Table 186­4). Opioid withdrawal symptoms usually peak on the third day of abstinence and resolve by the fifth or sixth day.
Opioid withdrawal symptoms are very uncomfortable but are not life­threatening and rarely fatal. Vomiting and aspiration of gastric contents can cause pneumonitis and dehydration.
TABLE 186­4
Clinical Features of Opioid Withdrawal
Initial Features Additional Features About  h After Onset Subsequent Features About 12–24 h After Onset
Peak effects: 36–72 h Peak effects:  h Peak effects:  h
Anxiety Irritability Insomnia
Yawning Tremor Muscle spasms
Drug craving Piloerection Abdominal pain
Lacrimation Mydriasis Nausea, vomiting, diarrhea
Rhinorrhea
Diaphoresis
Myalgias

Clinical scoring tools have been developed to assist in the assessment of opioid withdrawal. The commonly used Clinical Opiate Withdrawal Scale calculates a score based on the severity of  symptoms and can be used to assess appropriateness for buprenorphine or methadone and to monitor
 response to treatment (Table 186­5).
TABLE 186­5
Clinical Opiate Withdrawal Scale (COWS)
Resting Pulse Rate (beats/min) GI Upset
Measured after patient is sitting or lying for  min Over last 1/2 h
 – Pulse rate ≤80  – No GI symptoms
 – Pulse rate 81–100  – Stomach cramps
 – Pulse rate 101–120  – Nausea or loose stool
 – Pulse rate >120  – Vomiting or diarrhea
Sweating  – Multiple episodes of diarrhea or vomiting
Over past 1/2 h not accounted for by room temperature or patient activity
 – No report of chills or flushing Tremor
 – Subjective report of chills or flushing Observation of outstretched hands
 – flushed or observable moistness on face  – No tremor
 – Beads of sweat on brow or face  – Tremor can be felt, but not observed
 – Sweat streaming off face  – Slight tremor visible
Restlessness  – Gross tremor or muscle twitching
Observation during assessment
Yawning
 – Able to sit still
Observation during assessment
 – Reports difficulty sitting still, but is able to do so
 – No yawning
 – Frequent shifting or extraneous movements of legs/arms
 – Yawning once or twice during assessment
 – Unable to sit still for more than a few seconds
 – Yawning  or more times during assessment
Pupil Size
 – Yawning several times per minute
 – Pupils smaller or normal size for room light
 – Pupils possibly larger than normal for room light
Anxiety or Irritability
 – Pupils moderately dilated
 – None
 – Pupils so dilated that only the rim of the iris is visible
 – Patient reports increasing irritability or anxiousness
Bone or Joint Aches
 – Patient obviously irritable or anxious
If patient was having pain previously, only the additional component attributed
 – Patient so irritable or anxious that participation in the assessment to opiate withdrawal is scored is difficult
 – Not present
 – Mild diffuse discomfort
Gooseflesh skin
 – Patient reports severe diffuse aching of joints/muscles
 – Skin is smooth
 – Patient is rubbing joints or muscles and is unable to sit still because of
 – Piloerection of skin can be felt or hairs standing up on arms discomfort
 – Prominent piloerection
Runny Nose or Tearing
Not accounted for by cold symptoms or allergies
Total Score is the sum of all  items
 – Not present
Assessment: 5–12 = mild; 13–24 = moderate; 25–36 = moderately
 – Nasal stuffiness or unusually moist eyes severe; >36 = severe withdrawal.
 – Nose running or tearing
 – Nose constantly running or tears streaming down cheeks
Patients with mild opioid withdrawal are treated with symptomatic therapy, usually antiemetics and antidiarrheals as needed. Symptoms of moderate
 opioid withdrawal can be rendered more tolerable by the administration of the central α ­agonist clonidine. Clonidine should not be used if the

 patient is hypotensive or bradycardic.
Opioid replacement therapy, usually with buprenorphine or methadone, should be considered for moderately severe withdrawal and is recommended
,79 for severe withdrawal. To treat withdrawal in the ED or outpatient setting, see Figure 292­4, ED­Initiated Buprenorphine, and Chapter 292,
Substance Use Disorders, in the section Opioid Use Disorder Management.
The management of opioid­dependent individuals hospitalized for medical or surgical reasons can be challenging. Detoxification from opioids during the course of an acute medical illness is usually unsuccessful, so alleviation of withdrawal symptoms with opioid replacement is generally the goal. For patients already enrolled in an outpatient buprenorphine or methadone program, daily administration of the verified dose is recommended to inhibit withdrawal symptoms and reduce craving. A patient who uses high doses of opioids but who is not enrolled in methadone maintenance therapy can be given methadone  to  milligrams PO or  milligrams IM; this dose should inhibit withdrawal symptoms but not induce euphoria. Buprenorphine,
### .3 to .2 milligrams IV or IM every  hours or  to  milligrams sublingual, can safely be administered to a medically ill opioid­dependent patient
 experiencing withdrawal who is being admitted to the hospital. No methadone or buprenorphine should be administered to an opioiddependent patient until withdrawal symptoms appear.


