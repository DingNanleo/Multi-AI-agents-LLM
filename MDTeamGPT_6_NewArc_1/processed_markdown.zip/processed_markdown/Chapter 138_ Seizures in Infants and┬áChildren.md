## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 138: Seizures in Infants and Children
Maija Holsti
INTRODUCTION AND EPIDEMIOLOGY
Unusual movements and changes in behavior in children often lead to an ED visit. Most seizure activity stops before the child is seen in an ED; therefore, history is key to the correct diagnosis. Although seizures account for many of these events, as many as 30% or more of paroxysmal events
,2 may be misdiagnosed as seizures.
There are many different causes of pediatric seizures. The goal is to identify and treat the underlying cause. Some seizures require emergency management and extensive evaluation (e.g., status epilepticus, neonatal seizures), whereas others are common, benign, and need little or no ED evaluation (e.g., febrile seizures, first­time seizure in an otherwise well child). This chapter focuses on the diagnosis and management of ongoing seizures first and then discusses the approach to febrile seizures, neonatal seizures, and seizures in special populations (e.g., children with epilepsy, neurologic shunts, and trauma) under “Special Considerations/Populations.”
The prevalence of pediatric seizures in the United States is approximately 1% of all children up to the age of  years and is highest in children <1 year
2­4 old (120 cases per 100,000) and in certain high­risk groups. Febrile seizures, the most common type of pediatric seizure, affect 3% to 4%
 ,5 of all children between  months and  years of age. Epilepsy is defined as recurrent unprovoked seizures. Roughly 326,000 American
 children <15 years old have epilepsy, and the lifetime prevalence of epilepsy is roughly 1%. The incidence of status epilepticus in developed countries
 is between  and  cases per 100,000 and is higher for younger children.
PATHOPHYSIOLOGY
Seizures represent abnormal, excessive, paroxysmal neuronal activity in the brain, primarily the cortex. Glutamate released from firing neurons
 activates N­methyl­D­aspartic acid receptors that subsequently initiate and propagate seizure activity. Seizures are inhibited by γ­aminobutyric acid,
 and failure of this inhibition facilitates seizure spread. Incomplete myelination of the brain may limit secondary generalization of seizure activity in young infants, and a relative imbalance between glutamate and γ­aminobutyric acid with paradoxical excitation from γ­aminobutyric acid makes
,7 younger children more susceptible to seizures.
,10
Seizures can be primary (unprovoked) or secondary (provoked). Primary seizures are often idiopathic or may be caused by congenital developmental abnormalities, in utero CNS insult (e.g., infection, infarct), or genetic factors. Secondary seizures may result from trauma or injury,
 infection, metabolic abnormalities (e.g., hypoglycemia, electrolyte abnormalities, inborn errors of metabolism), toxins, or systemic illness.
CLINICAL FEATURES
TYPES OF SEIZURE
The clinical manifestation of seizures depends on the area(s) of the brain that are affected and whether the seizure activity is localized (focal) or widespread (generalized). Generalized seizures involve both hemispheres of the brain and lead to loss of consciousness, usually followed by a period
 of postictal drowsiness. In convulsive generalized seizures or grand mal seizures, rhythmic motor activity affects both sides of the body.
Nonconvulsive generalized seizures produce loss of consciousness without motor activity and can only be recognized on
,11 electroencephalogram. In one study, nonconvulsive status epilepticus appeared in  of 117 critically ill patients, with 75% of these patients
 showing no clinical evidence of seizure activity. Other examples of generalized seizures in children include absence seizures (brief episode of

,7 staring without a postictal state), atonic seizures (sudden loss of muscle tone with a sudden “drop” to the floor), and myoclonic seizures.
Chapter 138: Seizures in Infants and Children, Maija Holsti 
. Terms of Use * Privacy Policy * Notice * Accessibility
Partial seizures represent focal neuronal activity, and clinical features correlate with the affected area. In simple partial seizures, the patient remains
 awake, whereas complex partial seizures are focal but produce alterations of consciousness. Partial seizures may secondarily spread and become generalized. Young children with new­onset focal seizures are at increased risk for structural anatomic abnormalities, and neuroimaging is more likely
 to be abnormal in these children.
Although status epilepticus was originally defined as a seizure lasting longer than  minutes, today any “prolonged” seizure or recurrent
,14 seizures lasting >5 minutes without return to full consciousness are considered status epilepticus. Status epilepticus is a medical
 emergency, and rapid termination is important to prevent irreversible neuronal damage. Refractory status epilepticus is a prolonged seizure that
 cannot be controlled with two or more doses of standard treatment. Nonconvulsive status epilepticus may present as a prolonged postictal
 state and must be considered in any patient with altered mental status; morbidity and mortality increase when nonconvulsive status
,11 epilepticus is untreated, although less so than with untreated convulsive status epilepticus.
HISTORY

Obtain a detailed history of the event from a reliable observer. Table 138­1 lists historical clues that may help identify the etiology of a seizure.
Patient age alone is an important consideration in the potential cause of seizures (Figure 138­1). Other important details include the events surrounding the seizure (e.g., emotional upset and crying that may indicate breath holding in a toddler), the nature of the seizure activity (e.g., tonic stiffening, clonic jerks, generalized or focal characteristics), the duration of the event (often difficult for frightened parents to accurately report), and postictal observations and duration. Seizure­provoking events can include recent illness, possible trauma, ingestions, and medications (both over­thecounter and prescribed). In addition to the past medical history (especially epilepsy), recent changes or missed doses of medication can also provoke seizure activity. A developmental history is important, as children with underlying developmental delay are at increased risk for epilepsy. A family history of febrile seizures, epilepsy, or neurologic disease is also important for prognosis.
TABLE 138­1
History Relevant to the Child Presenting With Seizure
Age of child
Seizure duration and description of seizure activity prior to arrival
History of trauma
History of possible ingestion
History of fever
History of associated illness (vomiting or diarrhea)
Feeding problems (especially in an infant)
Changes in behavior
History of seizures and type of seizures
History of developmental delay
Other medical history
Medications
Anticonvulsants with milligrams per kilogram dose and recent changes or missed doses
Recent new medications (may alter metabolism of antiepileptic drugs)
Allergies
Developmental history
Family history of seizures
FIGURE 138­1. Age­based approach to the evaluation of pediatric seizures. VP = ventriculoperitoneal.
PHYSICAL EXAMINATION
Perform a complete head­to­toe examination with the patient undressed. The physical examination should be focused on whether the patient is actively seizing and identify potential causative factors (e.g., head trauma, rash indicative of infection, neurocutaneous lesions). Table 138­2 outlines a number of clinical signs and symptoms of seizures. Rhythmic repetitive movement, incontinence of bowel or bladder, postictal state after a seizure, and tongue biting are strong clues to a seizure. Lateral tongue biting was found to have a specificity of 100% and a sensitivity of 24% for the occurrence
,16 of a seizure.
TABLE 138­2
Signs and Symptoms Associated With Seizures
Head deviation
Eye deviation
Rhythmic or repetitive arm or leg movement
Posturing
Stiffening
Jerking
Change in breathing pattern
Increase in heart rate
Increase in blood pressure
Cyanosis or apnea
Eye dilatation
Vomiting
Lip smacking
Tongue biting
Incontinence of bowel or bladder
Postictal or sleepy period after a seizure
Mood or behavior changes before a seizure
Subjective aura before seizure (noted in older patients)
DIAGNOSIS
DIFFERENTIAL DIAGNOSIS AND CONDITIONS MASQUERADING AS SEIZURES
A number of benign conditions may masquerade as seizures, leading to an ED visit; up to 30% of new­onset paroxysmal events may be misdiagnosed
,2 as epileptic. Syncope is the most common condition that may be mistaken for seizures; however, there are many differentiating
,2 features. Syncope is commonly preceded by dizziness, weakness, tunnel vision, pallor, and diaphoresis (presyncopal aura). It is also associated with a brief loss of consciousness and a quick recovery with no postictal state (see Chapter 130, “Syncope, Dysrhythmias, and ECG Interpretation in
Children”). Seizures, on the other hand, may be preceded by an aura but usually do not have a provoking factor noted before the event. Seizures are associated with tongue biting, rhythmic motor activity, incontinence, and a slow recovery and postictal state. Table 138­3 lists nonepileptic causes of syncope and abnormal movements that can mimic seizures. In infants, myoclonic jerks, sleep myoclonus, shudder attacks, and Sandifer’s syndrome

(gastroesophageal reflux) are common. In toddlers, breath­holding spells become more prevalent. Self­stimulation and night terrors should be
 considered in preschool and young school­age children, whereas tic disorders typically begin in older children. Psychogenic nonepileptic seizures
 may present in adolescents with and without epilepsy.
TABLE 138­3
Events Masquerading as Seizures
Syncope
Breath­holding spells
Cataplexy
Narcolepsy
Vasovagal event
Standing for long periods of time
Standing quickly from lying or sitting
Hair­grooming syncope
Earring­changing syncope
Micturition syncope
Emotional distress or pain
Hypoglycemia
Hypovolemia
Sandifer’s syndrome (gastroesophageal reflux)
Acute life­threatening event
Acute dystonic reactions/drug reactions (i.e., promethazine [Phenergan®])
Movement disorders
Tics
Myoclonic jerks
Chills or rigors
Shudder attacks
Mannerisms
Self­stimulation
Choreoathetosis
Night terrors, sleep walking
Migraine variants
Benign paroxysmal vertigo
Nonepileptic paroxysmal event (pseudoseizures)
Note. Events in bold are more common.
LABORATORY TESTING
Check bedside glucose on all seizing or postictal patients. Additional laboratory evaluation is directed by the history and is not routinely indicated for febrile seizures or first­time afebrile seizures that are nonfocal in a child with a normal examination (see “Special Considerations/Populations”
,17 below). If indicated by the history and examination, labs that may be helpful include electrolytes (including calcium), serum antiepileptic
 medication levels, toxicologic testing, and spinal fluid for evaluation of possible CNS infection in the appropriate setting. Urine culture and analysis may be indicated in the evaluation of febrile seizures in the child with fever and no identifiable source.
IMAGING
Similar to laboratory testing, imaging should be directed by the history and examination. Routine neuroimaging is rarely indicated or helpful. When
 trauma is suspected, in infants less than a year old (inflicted injury), or in the setting of focal deficits, obtain a head CT. Todd’s paralysis is a temporary condition characterized by a focal deficit of unknown etiology that can last up to  hours after a seizure. The paralysis is usually unilateral and lasts on average  hours; however, it can be bilateral and involve a patient’s speech or vision. It may be impossible to distinguish Todd’s paralysis from stroke or hemorrhage, and emergent imaging should be considered. Most first­time seizures in the well­appearing child with a normal
,18 examination can follow up with neurology to determine if further imaging is necessary. If necessary, outpatient MRI avoids ionizing radiation and
,18 provides better anatomic detail.
ANCILLARY TESTS

Consider obtaining an ECG for evaluation of syncope with seizure activity to rule out arrhythmia. Emergent electroencephalogram monitoring may be required for patients with refractory status epilepticus (especially those requiring rapid­sequence intubation with a paralytic) or concern for
19­21 nonconvulsive status epilepticus ; otherwise, outpatient electroencephalogram may help identify specific epilepsy syndromes and guide future treatment.
SUMMARY OF APPROACH TO EVALUATION
Figure 138­2 summarizes the approach to the evaluation of pediatric seizures.
FIGURE 138­2. General approach to the evaluation of pediatric seizures. AVM = arteriovenous malformation.
TREATMENT
PREHOSPITAL
,22
Children may have been treated at home or by EMS personnel. Take this into consideration when treating refractory status epilepticus.

Benzodiazepines (Table 138­4) are the first­line treatment for prolonged seizures because of their rapid onset and effectiveness ; however, their
,10,15 effectiveness is inversely related to the duration of the seizure, and treatment should not be delayed. Not all benzodiazepines or routes are available in the prehospital setting, and establishing IV access can be difficult in a child who is having a seizure. Benzodiazepines may be given by the intranasal, buccal, rectal, or intraosseous route when an IV is difficult to place. Although not significantly different in efficacy, lorazepam is recommended if an IV has been placed; midazolam is recommended if intramuscular, intranasal, or buccal administration is performed; and diazepam
,6,7,10,15,23­28 is recommended if given rectally.
TABLE 138­4
Benzodiazepines for Initial Treatment of Prolonged Seizures
Drug Route Dose* Maximum Onset of Action Duration of Action
Lorazepam IV, IO, IN .1 milligram/kg  milligrams 1–5 min 12–24 h
IM .1 milligram/kg  milligrams 15–30 min 12–24 h
Diazepam IV, IO .1–0.3 milligram/kg  milligrams 1–5 min 15–60 min
PR .5 milligram/kg  milligrams 3–5 min 15–60 min
Midazolam IV, IO .1–0.2 milligram/kg  milligrams 1–5 min 1–6 h
IM .2 milligram/kg  milligrams 5–15 min 1–6 h
IN .2 milligram/kg  milligrams 1–5 min 1–6 h
Buccal .5 milligram/kg  milligrams 3–5 min 1–6 h
Abbreviation: IN = intranasal.
*Initial and repeat doses are the same.
Rectal diazepam is one “rescue” medication commonly used at home and by EMS personnel. The advantage is that no refrigeration or IV line is needed.
The disadvantage is the need for rectal administration. Midazolam, also an effective rescue medication, can be given via the intranasal route using a
,25 ,10,15,27 mucosal atomization device. Midazolam can also be given buccally. Lorazepam is not generally used in the prehospital setting because of its need for refrigeration. Although IV lorazepam is generally preferred, there is evidence that intranasal lorazepam using a mucosal atomization device
 may be as effective as IV lorazepam in the treatment of status epilepticus.
ED TREATMENT
Most seizures stop within  minutes and do not require medical treatment. Status epilepticus is a medical emergency, however, and is more
,10,15 responsive to medications when treated early, and treatment becomes less effective with time. To expedite therapeutic decisions and avoid treatment delays, status epilepticus management guidelines are recommended; an overview of one treatment algorithm for status
,29­31 epilepticus is depicted in Figure 138­3. FIGURE 138­3. Initial treatment of status epilepticus: an example of one approach. IN = intranasal; PE = phenytoin sodium equivalents.
Administer oxygen by facemask and institute continuous pulse oximetry and cardiac monitoring. Establish IV or IO access, but administer medication
,6,10,15,32 early via alternative routes (intranasal, IM, PR, buccal) if there is delay. Providers should obtain bedside glucose testing for afebrile seizures
,6 because hypoglycemia represents an easily correctable cause of seizures. Additional laboratory studies and imaging should be directed by the
,6,7 history and examination as the yield for routine testing is abysmally low. Subtherapeutic antiepileptic drug levels are found in almost one third of
 children with epilepsy presenting in status epilepticus. Meningitis and encephalitis should be considered in all children who present with fever and status epilepticus or multiple seizures; however, research supports using clinical judgment when deciding to do a lumbar puncture because the rate of
,33 bacterial meningitis is low (0.5% to .4%) in a fully immunized patient.
The decision to intubate is clinical. Intubate for apnea and persistent hypoxia. Blood gas concentrations are not needed to guide the decision to
,6,10 intubate because the seizure itself causes a metabolic and respiratory acidosis. The use of a paralytic with intubation obscures the ability to assess ongoing seizure activity, so arrange continuous electroencephalogram monitoring for intubated patients with status
,21 epilepticus.
,6,7,10,22
Administer a benzodiazepine (Table 138­4) as the initial treatment for status epilepticus. Benzodiazepines are effective in terminating
 seizure activity and act by binding to γ­aminobutyric acid receptors ; they are preferred over other medications because of their rapid onset of
,7,10,15,22,23 action. The decision of which benzodiazepine to give should be dictated by the route readily accessible. A particular benzodiazepine has not proven to be more or less effective in the cessation of seizure activity; however, delays in treatment make seizures increasingly harder to
,6,7,10,15,22,23 stop.
Generally, if two doses of benzodiazepines are administered without effect, additional doses are unlikely to be successful and increase the risk for
,6,7,10,15,22,23,31 respiratory depression. Because there is no standard treatment for refractory status epilepticus, approaches to treatment and order of
,6,10,17,31,32,34­36 medication administration may vary. Figure 138­3 represents one approach to refractory status epilepticus.
If a seizure persists after two doses of a benzodiazepine have been given, fosphenytoin, levetiracetam, or valproic acid are preferred second­line
,6,10,17,31,34­36 treatment choices. The National Institutes of Health–funded Established Status Epilepticus Treatment Trial will compare these three treatment choices for convulsive status epilepticus. A provider should generally choose two of the four medications for refractory status epilepticus and then move on to a fourth­line treatment option if a seizure persists. Table 138­5 summarizes the medications used for refractory status epilepticus.
TABLE 138­5
Medications for Refractory Status Epilepticus
Drug Route Loading Dose Repeat Dose Maximum IV Infusion
Fosphenytoin IV, IM  milligrams/kg PE 5–10 milligrams/kg PE  milligrams/kg PE  milligrams/kg/min PE
Phenobarbital IV 20–30 milligrams/kg 5–10 milligrams/kg  milligrams/kg 1–30 milligrams/min
Valproic acid IV 20–40 milligrams/kg 15–20 milligrams/kg  milligrams/kg  milligrams/kg/h
Levetiracetam IV 20–40 milligrams/kg —  grams —
Pentobarbital IV 5–10 milligrams/kg 1–2 milligrams/kg  milligrams/kg .5–5.0 milligrams/kg/h
Propofol IV .5–2.0 milligrams/kg .5–1.0 milligram/kg  milligrams/kg .5–4.0 milligrams/kg/h
Midazolam IV .1–0.3 milligram/kg .1–0.2 milligram/kg  milligrams .05–0.4 milligram/kg/h
Ketamine IV .5–2 milligrams/kg May repeat loading dose — 5–20 micrograms/kg/min
Abbreviation: PE = phenytoin sodium equivalents.
Second­ And Third­Line Treatments
Phenytoin and valproic acid, metabolized hepatically, and levetiracetam, metabolized renally, may affect second­ and third­line choices in patients with
,7,10,15 hepatic and renal dysfunction. Phenytoin and its prodrug, fosphenytoin, inhibit neuronal firing by stabilizing sodium channels and reducing
,7,10,15,34­36 neuronal calcium uptake. Fosphenytoin is safe and effective; it can be administered more rapidly with fewer cardiac effects than
,7,10,15 phenytoin, which can precipitate in an IV line and cause significant tissue injury with extravasation. Phenobarbital is not preferred as a secondline treatment, except in neonates, because both phenobarbital and benzodiazepines have the same mechanism of action and bind γ­aminobutyric
,7,10,15 acid receptors and can cause significant risk for respiratory failure.
Levetiracetam is also safe and effective for treatment of status epilepticus, although it has not been prospectively compared with other
,10,15,34,37­44 anticonvulsants. Levetiracetam is eliminated solely via renal excretion and has no hepatic metabolism, and it has few adverse effects and
,37­44 essentially no drug and food interactions. Another advantage of levetiracetam over fosphenytoin (phenytoin) and phenobarbital is that it is
,37­44 commonly used for maintenance therapy for multiple seizure types.

Phenobarbital is most commonly used in neonates who are often maintained on daily phenobarbital for subsequent seizure control. Side effects
,10,15 include sedation and cardiorespiratory depression, which may be amplified by benzodiazepines.
Valproic acid is approved by the U.S. Food and Drug Administration for treatment of status epilepticus and is also effective for partial and generalized
 seizures. Consider valproic acid for treatment of children already taking this medication who are suspected of having subtherapeutic levels. A dose of
,6,7,10,15,46,47
 to  milligrams/kg of IV valproic acid effectively terminates seizure activity with few side effects or less sedation. Use with caution in children at risk for metabolic disease, because in rare cases it may cause hepatic failure and has rarely been associated with
,6,7,10,15,46,47 thrombocytopenia.
Fourth­Line Treatment
Propofol is an IV anesthetic agent that acts on γ­aminobutyric acid receptors differently from benzodiazepines or barbiturates and has been shown to
,15,35,48 effectively treat refractory status epilepticus better than pentobarbital. Propofol has a rapid onset of action, but it is quickly metabolized and should be followed by continuous infusion if seizure activity persists and must be infused slowly because of the potential for serious side effects,
,15,35,48 including bradycardia, apnea, and hypotension. Prepare for intubation and provide continuous cardiopulmonary monitoring when
,15,35,48 administering propofol for seizures. Patients receiving sustained propofol administration (>24 hours) should be monitored for development
 of “propofol infusion syndrome” (metabolic acidosis, rhabdomyolysis, renal failure, and cardiac failure).
Ketamine, a noncompetitive N­methyl­D­aspartate–type glutamate receptor antagonist, may be effective in later stages of refractory status
  epilepticus. It is also commonly used for intubation. Recently, literature does not support concerns that ketamine causes increased intracranial
,15,50 pressure.
A “pentobarbital coma,” or continuous infusion, has been used for refractory status epilepticus not responsive to multiple anticonvulsant
 treatments with reported efficacy between 74% and 100%. Side effects include respiratory depression, hypotension, and decreased cardiac
,10,15,35,36 contractility, and most patients require intubation and inotropic support.
Midazolam infusion has a low rate of adverse effects; however, compared with propofol and pentobarbital, midazolam has a higher rate of seizure
,7,10,15,35 recurrence.
Treatment of Glucose and Electrolyte Abnormalities
Most laboratory results are not immediately available when treating status epilepticus; however, a glucose should be checked at a minimum (see

Chapter 146, “Metabolic Emergencies in Infants and Children”). Abnormal glucose, sodium, calcium, and magnesium, especially low levels, can cause
 seizures, particularly in infants. Seizures caused by abnormal electrolytes respond poorly to conventional medication but do respond to replacement
,6,10,15 electrolyte therapy (see Chapter 132, “Fluid and Electrolyte Therapy in Infants and Children”).
Hypoglycemia can be the cause or an effect of prolonged seizures, and bedside testing is essential in seizing patients. Treat hypoglycemia with a rapid infusion of  mL/kg of 25% dextrose in water or  to  mL/kg of 10% dextrose in water.
Hyponatremia (serum sodium <135 mEq/L) is most commonly seen in infants <6 months of age and sometimes in athletes and can cause seizures,
 especially if the serum sodium is <120 mEq/L. The goal of therapy is to correct the level to >120 mEq/L quickly and then correct to normal levels over the next  hours (see Chapter 132, “Fluid and Electrolyte Therapy in Infants and Children”). Treat the seizing patient with hyponatremia with 3% NaCl
 to  mL/kg over  minutes or begin an infusion of  mL/kg of .9% NaCl if 3% NaCl is not immediately available. The sodium level should be rechecked after the bolus to determine whether a second bolus is necessary.
Hypocalcemia is more common in neonates and young infants and may be associated with congenital anomalies such as DiGeorge’s syndrome.
Calcium gluconate, 100 milligrams/kg (rate <100 milligrams/min), is preferred over calcium chloride when infusing through a small peripheral IV
 because calcium chloride can cause local irritation.
Hypomagnesemia (serum magnesium <1.5 mEq/L) is treated with magnesium sulfate,  milligrams/kg IV infused over  minutes.
DISPOSITION AND FOLLOW­UP
Infants >6 months of age with febrile seizures (see later) and children with single seizures lasting <15 minutes who return to baseline mental status and have no focal neurologic deficits or secondary cause of seizure requiring ongoing treatment are candidates for discharge and outpatient follow­up with their primary care provider or a pediatric neurologist (in the case of new­onset seizures or breakthrough seizures in children with epilepsy).
Parents of discharged children should be given guidance to prevent injury in association with subsequent seizures: children should not be in a position where they could drown, fall, or injure someone else during a seizure. Caregivers should never allow their children to bathe or swim alone. If they are old enough to take a shower, children should not lock the bathroom door. Those old enough to drive should not be allowed to do so until cleared by a neurologist.
Information about recurrence risk should also be provided in the ED. Although the recurrence risk for a particular child cannot be predicted, population statistics pertaining to febrile seizures and first­time seizure recurrence can be shared with parents (see the following section “Special
Considerations/Populations”).
In many cases, children treated for seizures who return to their baseline may go home with close follow­up. Some children may need to be monitored in the hospital for recurrence or side effects from medication, especially if they have not returned to baseline. Children with refractory status epilepticus usually require intensive care for continuous infusion of antiseizure treatment or induction of a “pentobarbital coma.”
SPECIAL CONSIDERATIONS/POPULATIONS
FEBRILE SEIZURES

Febrile seizures are common in the general pediatric population, with an incidence of 2% to 5%.
Simple Febrile Seizures
The definition of a simple febrile seizure is a generalized tonic­clonic seizure lasting <15 minutes with a fever 38°C (100.4°F) in a child  months to 
 years of age that occurs only once in a 24­hour period. The American Academy of Pediatrics holds that no blood studies, neuroimaging, or electroencephalogram is necessary for simple febrile seizures and the evaluation should focus on identifying the source of fever (e.g.,
,17,33,51­54 urinalysis and culture). The American Academy of Pediatrics does recommend that a lumbar puncture be strongly considered in these children when there are clinical signs or symptoms that suggest meningitis or intracranial infection (see Chapter 120, “Meningitis in Infants and
,33,51­53
Children”). Although bacterial meningitis is rare even in children with fever and seizures, the American Academy of Pediatrics recommends consideration of lumbar puncture for infants  to  months of age who are unimmunized for Haemophilus influenzae
,33,51­55 type B or Streptococcus pneumoniae and those taking antibiotics, which can mask the signs and symptoms of meningitis.
Parents of children experiencing a simple febrile seizure need education regarding the natural history of febrile seizures. Only 50% of children <12
,52,55 months old and 30% of children >12 months old will have another simple febrile seizure. Having a febrile seizure does not mean that a child will develop epilepsy. Children who experience a simple febrile seizure have roughly the same 1% risk as the general population of developing epilepsy by
,52,55 the age of  years. Factors that increase that risk up to 7% include a family history of seizures, complex or multiple febrile seizures, and first
,17,51,53,54 febrile seizure before  months of age. Other factors that increase the risk of recurrence include developmental delay, focal seizures,
,17,51,53,54
Todd’s paralysis, focal neurologic findings on examination, and abnormal findings on electroencephalogram, CT, or MRI.
Complex Febrile Seizures
Complex febrile seizures are defined as seizures with fever that last >15 minutes, recur within a 24­hour period, are focal, or occur in children <6
,17,51­55 months or >6 years of age without any signs of serious infection. Routine blood tests, lumbar puncture, and imaging are not
,33,52,54,55 indicated, even in the setting of complex febrile seizure, in the absence of other signs or symptoms. One study noted that children with fever and seizures lasting >30 minutes had a significantly higher incidence of bacterial meningitis (15% to 18%) than children with simple
 ,33 febrile seizures (0.4% to .2%). Other studies, however, found meningitis to be rare without clinical signs and symptoms of meningitis ; one study found only two patients with meningitis among 526 patients with complex febrile seizures, and both patients had clinical signs and symptoms of
 meningitis.
Children with a prolonged seizure associated with a fever who appear ill should undergo evaluation to rule out serious bacterial infection in the blood
 and cerebrospinal fluid, although parenteral antibiotics should not be delayed while sick children are being evaluated (see Chapter 119, “Fever and
,52,55
Serious Bacterial Illness in Infants and Children” and Chapter 120, “Meningitis in Infants and Children”).
Treatment of Febrile Seizure
,53
Anticonvulsant therapy is not recommended for simple febrile seizures because side effects outweigh the minor risks of seizure recurrence.
,51,53,57
Although antipyretics are indicated in children with fever, there is no evidence that antipyretics can prevent subsequent febrile seizures.
FIRST AFEBRILE SEIZURE
Practice guidelines for the evaluation of a first unprovoked seizure in a child who returns to baseline following the seizure suggest that routine
,18,58 laboratory evaluations and emergent neuroimaging are not necessary. If there is evidence that the child had vomiting or diarrhea, is dehydrated, or has failed to return to baseline, laboratory tests are recommended. A toxicology screen should also be included if there is concern for drug exposure or substance abuse or the cause of the seizure cannot be determined. Lumbar puncture is unnecessary unless there is a clinical
 concern for meningitis or encephalitis. An electroencephalogram should be performed, although availability may be limited and the timing is unclear
,15 in a child who has returned to baseline and it is rarely indicated in the ED. An electroencephalogram within  hours of the seizure is most likely to
,6,47,59 show abnormalities and can help identify patients suspected of being in continuous convulsive and nonconvulsive status epilepticus.
Indications for emergent head CT include children with a condition predisposing them to intracranial abnormalities, trauma, and children with focal
 seizures who are younger than  months of age. Patients who do not meet the criteria for high risk and are well appearing may be discharged with outpatient follow­up. Outpatient MRI should be considered in any child with any of the following: significant cognitive or motor impairment, abnormal
,58 findings on neurologic examination, abnormal electroencephalogram findings, partial seizure, or infants <1 year of age.

The overall risk of recurrence after a single afebrile seizure is approximately 54%. Factors that increase this risk are a family history of seizures, previous febrile seizures, developmental delay, abnormal CT or MRI findings, presence of focal deficits on neurologic examination, Todd’s paralysis,
,58 abnormal electroencephalogram findings, and seizure occurring during sleep. Most neurologists do not recommend initiating daily anticonvulsant
,58 medications after a first seizure. Noninitiation of treatment does not increase the risk of epilepsy, affect prognosis, or increase the risk of intractable epilepsy or death, but does allow the physician to better clarify the type and frequency of seizures and also avoids the side effects of
,58 unnecessary daily anticonvulsant medications in those not destined to experience recurrence.
NEONATAL SEIZURES
Neonates do not have a fully developed neurologic system, and seizures in this age group (<1 month) can be subtle, are more likely to be focal, and
,45,60 often carry a poor prognosis.
Identifying seizure activity in the neonate and distinguishing it from normal newborn myoclonus and jitters can be challenging. Subtle focal movements or stereotyped activities (e.g., lip smacking, eye deviation, or bicycling) may represent 50% of seizure activity; neonates less often have
,45,60 generalized tonic­clonic seizures. Apparent life­threatening events with pallor or cyanosis and a change in muscle tone may be a manifestation of
,19,49,61 seizure activity.
A birth and maternal history may identify risks for congenital or neonatal infection (e.g., herpes simplex virus, cytomegalovirus, or group B
 streptococci) or potential withdrawal from maternal narcotics. Complications with labor and delivery may suggest birth asphyxia with subsequent seizures. Regardless of the history or presence of fever, neonates with witnessed seizures require extensive evaluation. Obtain cultures of blood,
,45 urine, and cerebrospinal fluid; test for herpes simplex virus; and begin empiric parenteral antibiotics and acyclovir. Toxicologic evaluation may provide the physician with evidence of withdrawal or overdose of abused substances. Neonates with seizures are more likely to have electrolyte
,45 abnormalities than older children, and electrolytes including calcium and glucose should be measured. Consider head CT for concerns of
,45 nonaccidental trauma, intracranial hemorrhage, infarction, or mass (even without external signs of injury). Finally, if inborn errors of metabolism are suspected, obtain serum levels of lactate and ammonia, as well as serum amino acids and urine organic acids (see Chapter 146, “Metabolic
,45
Emergencies in Infants and Children”). Neonates with witnessed seizure require admission to the hospital.
Treat the actively seizing neonate with benzodiazepines as with older children; consider phenobarbital for second­line therapy because many will be sent home on phenobarbital. Identify and treat hypoglycemia and electrolyte abnormalities.
SEIZURES IN CHILDREN WITH EPILEPSY
Parents, old records, and pediatric neurologists can be very helpful in identifying past causes of seizures, successful (and unsuccessful) treatments,
 and other issues that can help direct the care of patients with epilepsy presenting to the ED with seizure. Table 138­6 lists common anticonvulsants prescribed for children with epilepsy. Subtherapeutic drug levels may result when a child outgrows a previously prescribed dose, vomits medications due to an intercurrent illness, starts a new medication (due to changes in drug pharmacokinetics from drug interactions), or does not adhere to the original drug regimen. Subtherapeutic drug levels are a common cause of breakthrough seizures, and serum levels of home antiepileptic medications should be checked as part of the routine ED evaluation of these patients, although results may not be readily available for some newer agents. When low levels are identified, the cause should be determined so that proper adjustments in daily anticonvulsant dosing can be made with advice from the patient’s neurologist.
TABLE 138­6
List of Anticonvulsants Commonly Used in Children
Before 1993 1993–2005 2009–2011
Carbamazepine Felbamate Vigabatrin
Clonazepam Gabapentin Rufinamide
Diazepam Lamotrigine Lacosamide
Ethosuccimide Levetiracetam Clobazam
Lorazepam Oxcarbazepine Ezogabine
Phenobarbital Pregabalin
Phenytoin Tiagabine
Primidone Topiramate
Valproic acid Vagus nerve stimulation
Children with epilepsy may have a lower seizure threshold with febrile illness, even with therapeutic anticonvulsant levels, and the ED evaluation in these situations may be limited to determining the source of fever. Lumbar puncture is unnecessary unless there are clinical signs or symptoms of
,8,33 meningitis.
SEIZURES IN CHILDREN WITH VENTRICULOPERITONEAL SHUNTS
Many children with ventriculoperitoneal shunts also have a medical history of seizures. Considerations include underlying epilepsy, shunt malfunction, and CNS infection. The standard approach to the evaluation for a shunt malfunction consists of a radiographic ventriculoperitoneal shunt series and a head CT or “quick brain MRI” to evaluate for increased ventricular size. If CNS infection is a concern, a pediatric neurosurgeon should be consulted and the shunt tapped for cerebrospinal fluid analysis and culture. Seizures in children with ventriculoperitoneal shunts are more
,64 likely to be related to shunt infection than to mechanical shunt malfunction, especially if associated with fever, and the risk of infection increases in
,64 children with a history of a prior shunt infections. In most cases, consulting past medical records, parents, and the neurosurgeon who placed the shunt is needed for prudent decision making (see Chapter 148, “The Child with Special Healthcare Needs”).
SEIZURES IN TRAUMA
“Impact seizures” (seizures that occur within minutes of head trauma) do not, by themselves, increase the risk of having an
 intracranial injury; seizures that occur in a more delayed fashion, however, are more indicative of severe injuries. Guidelines for the
ED evaluation and management of head injury increasingly focus on strategies for risk stratification in order to avoid the potential long­term effects of ionizing radiation and are discussed in detail in Chapter 111, “Minor Head Injury and Concussion in Children.” Children with identified intracranial injury and a witnessed seizure should be treated with a loading dose of antiepileptic medication, typically fosphenytoin or levetiracetam, to prevent
 short­term recurrence that can worsen traumatic brain injury and increase intracranial pressure ; benzodiazepines remain first­line treatment for active seizures in the setting of trauma.
Abusive Head Trauma
Infants and toddlers presenting with vague complaints and seizures may be the victims of abusive head trauma (see Chapter 150, “Child Abuse and
Neglect”), which can present without external signs of injury. Most children with abusive head trauma are <2 years of age, and the majority of cases
67­69 occur in the first year of life (shaken baby syndrome). Subdural hematoma is the most often identified inflicted intracranial injury in these
,69 infants. Maintain a high index of suspicion for trauma in the setting of afebrile seizures in infants. If intracranial injury is identified, a more complete evaluation for other abusive injuries is necessary, including skeletal survey, retinal examination by an ophthalmologist, screening for
 blunt abdominal trauma (liver and pancreatic enzymes), and bleeding studies.


