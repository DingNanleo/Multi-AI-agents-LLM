## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 37: Procedural Sedation and Analgesia in Adults
Justin G. Myers; Jennifer Kelly Sutherland
Content Update: May 2023
Table 37­4 has decreased dosing requirements for Midazolam
INTRODUCTION
,2
Procedural sedation and analgesia (PSA) for unscheduled, time­sensitive procedures is a standard practice in the ED. The accepted definition and goals of PSA are “the use of anxiolytic, sedative, hypnotic, analgesic, and/or dissociative medications(s) to attenuate anxiety, pain and/or motion. These agents are administered in order to facilitate amnesia or decreased awareness and/or patient comfort
1­5 and safety during a diagnostic or therapeutic procedure.” Levels of sedation are defined by the patient’s level of responsiveness and
 cardiopulmonary function, not by the agents used (Table 37­1). Although these are the currently accepted definitions of levels of sedation, sedation
,7,8 is a continuum, and responsiveness alone is not a perfect tool to judge the level of sedation. By definition, patients receiving PSA do not require routine airway protection with endotracheal intubation or other airway adjuncts. This is in contrast to provision of general anesthesia, which typically requires airway protection. This chapter focuses on PSA in adults. For children, see Chapter 115, “Pain Management and Procedural Sedation in
Infants and Children.”
TABLE 37­1
Levels of Sedation and Analgesia
Responsiveness Airway Breathing Circulation
Minimal sedation Normal but slowed response to verbal stimulation Unaffected Unaffected Unaffected
(“anxiolysis”)
Moderate sedation Purposeful response to verbal or physical stimulation Usually maintained Usually Usually adequate maintained
Dissociative sedation Trance­like state with variable responsiveness Usually maintained Usually Usually maintained maintained
Deep sedation Purposeful response after repeated or painful physical May be impaired May be Usually stimulation suppressed maintained
General anesthesia Not arousable, even by painful stimulation Usually requires Often impaired May be impaired assistance
Minimal sedation is characterized by anxiolysis but with normal or slowed responses to verbal stimuli. Minimal sedation is typically used for minor procedures that require patient cooperation and for those in which pain is controlled by local or regional anesthesia. During minimal
 sedation, ventilatory function is usually maintained with a low risk of hypoxia or hypoventilation.
Chapter 37: Procedural Sedation and Analgesia in Adults, Justin G. Myers; Jennifer Kelly Sutherland 
. Terms of Use * Privacy Policy * Notice * Accessibility
Moderate sedation is characterized by a depressed level of consciousness and a slower but purposeful motor response to simple verbal or tactile stimuli. Patients at this level generally have their eyes closed or demonstrate ptosis and respond slowly to verbal commands.
Moderate sedation can be used for procedures in which patient cooperation is not necessary and muscular relaxation is desired. During moderate
  sedation, the patient is usually able to maintain a patent airway with adequate respirations, and cardiovascular function is usually maintained.
Dissociative sedation does not easily fit into the PSA continuum outlined in Table 37­1. Dissociation is a state of detachment from immediate surroundings, in which the cortical centers are prevented from receiving sensory stimuli. It is a trance­like cataleptic state characterized by
 profound analgesia and amnesia, with retention of protective airway reflexes, spontaneous respirations, and cardiopulmonary stability.
Nonresponsiveness of dissociated patients to stimuli, even when repeated or painful, means that such patients do not fit the “moderate sedation” or
“deep sedation” categories. Ketamine and nitrous oxide are the ED PSA agents characterized by dissociative sedation.
Deep sedation is characterized by a profoundly depressed level of consciousness, with a purposeful motor response elicited only after repeated or painful stimuli. Deep sedation may be required with painful procedures that require muscular relaxation and patient unresponsiveness. The risk of losing airway patency or developing hypoxia or hypoventilation is greater with deep sedation than with moderate or
 minimal sedation. Examples of ED procedures sometimes requiring deep sedation include burn wound care and reduction of open fractures or fracture dislocations. Deep sedation generally is achieved in the ED with the same agents as moderate sedation, but with larger or more frequent doses.
General anesthesia is defined as a “drug­induced loss of consciousness during which patients are not arousable, even by painful stimulation. The ability to independently maintain ventilatory function is often impaired. Patients often require assistance in maintaining a patent airway, and positivepressure ventilation may be required because of depressed spontaneous ventilation or drug­induced depression of neuromuscular function.
,12,13
Cardiovascular function may be impaired.”
PSA SEDATION POLICIES AND GUIDELINES
PSA is a multidisciplinary activity. Formation of a hospital sedation committee allows for diverse representation to create collaborative, evidence­
,14 based, institution­specific policies. The logistics and roles for PSA at each institution should be determined in advance, allowing the ED physician
,15 the freedom to create a situationally appropriate sedation plan for each patient.
In the emergency medicine model of PSA, clinical experience indicates that one emergency physician—providing monitoring and sedation and
,16,17 performing the procedure—is as effective as two physicians, one providing monitoring and the other performing the procedure. Thus, one emergency physician simultaneously administering sedation and performing the procedure with a nurse or respiratory therapist monitoring the
 patient is an appropriate practice. However, the physician must be ready to resuscitate the patient immediately. Nurses who have demonstrated the
19­22  appropriate competencies can safely administer procedural medications, even in resource­limited settings. Emergency physicians and nursing
,20 leadership should conjointly develop policies regarding the scope of nursing practice in PSA sedation at their institutions.
CLINICAL APPROACH TO PROCEDURAL SEDATION
PROCEDURAL SEDATION NEEDS ASSESSMENT
As you consider PSA for an ED procedure, consider the urgency, the depth of sedation required, and the duration needed. Is analgesia, anxiolysis, or immobility required? Do the patient’s clinical condition or comorbidities place them at higher risk of adverse events? Can sedation be avoided altogether? Alternatives to PSA include systemic analgesics, regional nerve blocks, or local anesthesia. Some patients may be better served with general anesthesia.
Decisions regarding the procedural sedation plan should balance the urgency of the procedure and the likelihood of difficult complications. These
24­26 decisions should be made with the patient and/or caregivers when possible, with appropriate consent. If the situation is deemed too high­risk for
,27,28
ED PSA, consult anesthesiology or other specialists for assistance or sedation in the operating room.
A common tool for assessing the patient’s suitability for procedural sedation is the American Society of Anesthesiologists (ASA) physical status
 ,30­32 classification system (Table 37­2). The risk of a significant complication from ED PSA in ASA class I and II is usually less than 5%. The risk of an
,34 ,35 adverse PSA event increases as the ASA classification rises, although safe ED procedural sedation for classes III and IV has also been reported.
TABLE 37­2
American Society of Anesthesiologists (ASA) Classification System
ASA
Description Examples
Class
Class I Healthy
Class II Mild systemic disease Mild asthma, pregnancy, obesity, controlled diabetes
Class III Severe systemic disease Pneumonia, moderate to severe asthma, premature infant with postconceptional age <60 wk, end­stage renal disease
Class IV Severe systemic disease that is a constant Sepsis, severe cardiac dysfunction, disseminated intravascular coagulation threat to life
Class V Moribund and not expected to survive Massive trauma, intracranial hemorrhage with mass effect, ischemic bowel with multiple organ without surgery system dysfunction
Class VI Declared brain dead whose organs are being harvested
Source: asa­physical­status­classification­system.pdf (American Society of Anesthesiologists: ASA Physical Status Classification System). Retrieved May , 2019. PRE­SEDATION PATIENT EVALUATION

Perform a focused history and physical examination to identify a potentially difficult airway or cardiorespiratory problem. Ask about prior experiences with sedation or anesthesia, current medications, and allergies. A potentially difficult airway should be anticipated when the following findings or conditions are present: short neck, micrognathia, large tongue, trismus, morbid obesity, a history of difficult intubation, or anatomic
37­39  anomalies of the airway and neck. The implications of these individual factors vary, partially due to the weak interobserver reproducibility.
Studies on the association between these findings and difficult intubation are usually done on patients going to the operating room for general
 anesthesia, and these findings may not be entirely relevant to the ED patient.
Predisposing conditions affect the selection and dose of the sedative agent and also the timing of the procedure. Routine laboratory studies are not necessary in otherwise healthy patients. Directed ancillary testing may be useful in patients with comorbidities or dehydration. Ask about pregnancy in
 females of childbearing age, due to physiologic changes in pregnancy and the potential for fetal distress with PSA.
Most sedative agents can cause vasodilatation and hypotension, particularly in patients with preexisting hypovolemia. Clinically active obstructive pulmonary disease or upper respiratory infections may predispose the patient to periprocedural hypoventilation or heightened airway reactivity. Drug or alcohol intoxication or reduced level of consciousness increases the risk of hypoxemia and hypoventilation. If possible, delay PSA in intoxicated patients until mental status improves. These various conditions may increase the risk of hypotension, prolonged sedation, and/or hypoxemia with PSA.

The ASA guidelines for fasting prior to general anesthesia are of limited relevance to the risk of aspiration with ED procedural sedation. Pre­
,18,43­47 procedural fasting for any duration has not demonstrated a reduction in the risk of emesis or aspiration. It is not necessary to delay ED
,2
PSA for time­sensitive procedures in adults or children based on fasting time.
After pre­PSA patient evaluation, discuss general PSA risks and any specific risks attendant to the particular patient (e.g., older patient with airway disease) or selected drug regimen (e.g., delayed vomiting with ketamine) with the patient and/or family. Obtain informed consent for PSA just as for any other ED procedure and with the same caveats (e.g., intoxication and patient capacity to consent).
PREPARATION OF EQUIPMENT AND SUPPLIES
The sedation area should include ready access to necessary size­appropriate equipment for airway management and resuscitation: oxygen, a bagmask ventilation device, suction, oral/nasal airway(s), intubation equipment, physiologic monitoring equipment, resuscitation medications, and a
,14,36 defibrillator.
IV fluids should be initiated or readily available, particularly if the PSA regimen will include drugs (e.g., propofol) often associated with hypotension.
If using an opioid, have naloxone available. For benzodiazepines, have flumazenil on hand. Other drugs include antiemetics, agents used to treat
,48,49 allergic reactions, and push­dose vasopressors. (See later section “Rescue Medications and Reversal Agents.”)
The incidence of oxygen desaturation during ED procedural sedation without supplemental oxygen varies widely, depending on the patient and PSA
50­52 50­52 agent, from 6% to 40%. Supplemental oxygen reduces the incidence of hypoxemia and has no adverse clinical effects. However, the administration of oxygen may mask hypoventilation, since oxygen saturation can be maintained despite rising carbon dioxide (a finding that would be
50­52 readily identified by capnography).
PATIENT MONITORING AND INTERVENTION

The safe practice of PSA requires both interactive and physiologic monitoring. Interactive monitoring includes direct visualization of the patient’s airway (mouth, face) and chest wall motion, chest auscultation, monitoring patient responsiveness, and providing appropriate maneuvers to maintain
,8,18 the patient’s airway and ventilation. Physiologic monitoring includes continual tracking of arterial oxygenation, ventilation, blood pressure, and
,53 cardiac rate/rhythm.
Cardiac monitoring is particularly recommended for patients with preexisting cardiac disease or dysrhythmias or during procedures such as cardioversion. Monitor arterial oxygen saturation with pulse oximetry. Pulse oximetry is not a substitute for monitoring ventilation because
,51,54,55 hypoventilation or apnea develops before oxygen saturation decreases, especially in patients who receive supplemental oxygen. Airway repositioning and bag­valve­mask ventilation are effective and usually the only interventions required.
Once PSA has begun, observe the patient until the peak effect of the initial sedative dose has been reached; with ketamine PSA, monitor until dissociation occurs. If necessary, titrate with additional medications to the desired sedation level. Once the patient has achieved the target sedation level, the actual procedure may begin. If the patient begins to regain alertness before completion of the procedure, additional sedative doses may be required. However, additional sedative doses given to extend procedural sedation are usually associated with an increased risk of respiratory depression. Depending on the agent selected, as larger cumulative doses of the drug are given, the half­life of each bolus increases. As the patient recovers from sedation, administer analgesics as needed for patient comfort.
The recommended extent of monitoring is determined by the level of sedation (Table 37­3). Check patients after each dose of medication to assess the response, determine the need for further doses, and make appropriate interventions if needed. The risk of adverse events increases with deeper levels of sedation. However, targeting moderate versus deep sedation is clinically difficult and unnecessary. Fortunately, no differences in pain, satisfaction, or recollection of procedures have been reported in patients who were sedated to a moderate versus a deep
,34,56 level.
TABLE 37­3
Recommendations for Procedural Sedation and Analgesia Monitoring by Target Sedation Level
Target Level Level of Respiratory Oxygen Capnography
Heart Rate Blood Pressure of Sedation Consciousness Rate Saturation End­Tidal CO 
Minimal Observe Record every Record every  Record every  min and after Monitor No frequently  min min sedative boluses continuously recommendation
Dissociative Observe Monitor Continuous Record at initiation, frequent Monitor Recommend constantly continuously direct monitoring generally unnecessary continuously continuous observation monitoring
Moderate Observe Monitor Continuous Record every  min and after Monitor Recommend constantly continuously direct sedative boluses continuously continuous observation monitoring
Deep Observe Monitor Continuous Record every  min and after Monitor Recommend constantly continuously direct sedative boluses continuously continuous observation monitoring
Capnography
,55,57­59
The interactive observation of ventilation may be improved through physiologic monitoring of ventilation with electronic capnography (see
Chapter , “Blood Gases, Pulse Oximetry, and Capnography”). The partial pressure of carbon dioxide detected at the nares during the respiratory cycle is represented by the carbon dioxide waveform (capnogram) that is displayed on a monitor (Figure 37­1). The end­tidal carbon dioxide correlates with arterial partial pressure of carbon dioxide, so that an end­tidal carbon dioxide >50 mm Hg or an increase in end­tidal carbon dioxide
>10 mm Hg indicates hypoventilation. Capnography can assess the severity of ventilatory abnormalities and the response to interventions. Most
,54,55,60 importantly, capnography can detect changes in ventilation before clinical observation.
FIGURE 37­1. Normal capnogram. Phase I: At the start of exhalation, carbon dioxide concentration in the exhaled gas is essentially zero, representing gas from the anatomic dead space that does not participate in gas exchange. Phase II: As the anatomic dead space is exhaled, carbon dioxide concentration rises as alveolar gas exits the airway. Phase III: For most of exhalation, carbon dioxide concentration is constant and reflects the concentration of carbon dioxide in alveolar gas. Phase IV: During inhalation, carbon dioxide concentration decreases to zero as atmospheric air enters the airway. [Reproduced with permission from Krauss B, Hess DR: Capnography for procedural sedation and analgesia in the emergency department. Ann Emerg Med 50: 172,
2007 (Table , p. 176). Copyright Elsevier.]
Variations in the capnogram can identify specific conditions, such as apnea, upper airway obstruction, laryngospasm, bronchospasm, and respiratory
 failure. A flat­line capnogram can be due to apnea, upper airway obstruction, complete laryngospasm, or faulty equipment. Normalization of the waveform after airway alignment maneuvers (chin lift, jaw thrust, or oral airway placement) confirms that apnea was due to upper airway obstruction.
As of this writing, no cases of unexpected death or hypoxic neurologic injury from ED procedural sedation have been reported, with or without
,61,62 capnography. There is a lack of evidence that capnography use, despite being possibly associated with increased airway intervention rates,
,63 reduces the incidence of serious adverse events such as hypoxic brain injury, aspiration, or death. However, capnography is still recommended
,62 and may improve patient safety by reducing mild and severe oxygen desaturations as well as the need for assisted ventilation.
DOCUMENTING PSA
Vital signs (pulse, blood pressure, and respiratory rate) and oxygen saturation should be obtained and recorded before the procedure, after each dose
,36 of medication, upon completion of the procedure, at the beginning of the recovery period, and before discharge. For minimal sedation,
 intermittent measurements are sufficient. For other levels of sedation, assess blood pressure every  minutes (unnecessary for ketamine dissociative sedation) and monitor heart rate, capnography, and pulse oximetry continuously. Predesigned documentation templates are good practice because
  such forms can guide providers through the procedure, improve documentation quality, and facilitate quality auditing for PSA­related events.
PRE­PROCEDURAL ANALGESICS

It may be necessary to give a short­acting opioid, such as fentanyl (often at doses of  to  micrograms/kg), for pain control before the start of a
 procedure. If an opioid is to be used, it is best to initiate and titrate early to attain pain relief peak effect. Delay the start of the procedure until after
 the peak effect of the opioid has been reached (2 to  minutes for IV fentanyl) to minimize the risk of respiratory depression and apnea. It may be unnecessary to await pain control by opioids if analgesia will be provided by the PSA regimen. Ketamine alone or in combination with propofol
,67,68
(ketofol) provides analgesia while avoiding concomitant use of opioids. A further review of ketamine­based regimens will be discussed later in the chapter. (See Chapter , “Acute Pain Management,” for further discussion.)
SELECTION AND DOSING OF PROCEDURAL SEDATION AGENTS
Select the most appropriate agents for the PSA, taking into account the type and length of the procedure, the patient’s age and comorbidities, the
 sedation target level, and potential for adverse events during sedation. (See Table 37­4 and section titled “Agents for Procedural Sedation.”)
TABLE 37­4
Agents for Procedural Sedation in Adults.68–105 Times May Vary With Different Dosing
Average Average
Advantages/Ideal
Agent Recommended IV Dose Onset of Effective Disadvantages/Side Effects
Procedures
Action Action
Propofol .5–1.0 milligram/kg 10–50 s <10 min Rapid onset, short Does not provide analgesia, may
(elderly: .25–0.5 duration of action; good cause respiratory depression milligram/kg) agent for orthopedic (increased risk in elderly patients),
Repeat dosing: .25–0.5 reductions may burn on injection; lidocaine milligram/kg added to syringe can decrease pain
(see discussion below)106
Ketamine .0–1.5 milligrams/kg (give 30–40 s 5–10 min Provides sedation, Emergence reaction, vomiting, over 30–60 s) analgesia, cardiac stimulation may increase
Repeat dosing: .5–1.0 cardiorespiratory stability; blood pressure, heart rate, and milligram/kg may be safer if comorbid cardiac output; rare muscle
For analgesia only conditions; may be useful hypertonicity/rigidity; avoid in
(subdissociative dose): for longer procedures; psychotic or schizophrenic patients;
.1–0.3 milligram/kg useful for patients at risk respiratory depression with rapid IV
(same repeat doses as initial for bronchospasm bolus push dose)
Etomidate .1–0.2 milligram/kg 10–20 s 2–3 min for Minimal cardiovascular Myoclonus, adrenal suppression in
Repeat dosing: .05 .15 and respiratory critically ill milligram/kg milligram/kg depression; ideal for dose min shorter procedures, cardioversion
Ketamine + Same total milligram dose <1 min <10 min Ketamine adds analgesia Higher ketamine:propofol ratios lead propofol (“single for two agents together as without opioids; ketamine to longer recovery; do not reduce syringe” ketofol, when using single agent component blunts clinically important adverse events;
1:1) alone (ie, 1:1 = .5 propofol­induced while not harmful, objective benefits milligram/kg of ketamine + hypotension; combination have mixed evidence
### .5 milligram/kg of good for prolonged propofol) procedures
Midazolam 1–2.5 milligrams over  min; 3–5 min 30–80 min Preferable for longer Provides no analgesia (must be reduce dose by 50% in procedures requiring combined with analgesic if pain elderly deeper sedation reduction is desired)
Repeat dosing: .5–2.5 Increased cardiovascular and milligrams; can repeat ≥5 respiratory depression when min (longer interval for combined with opioids elderly) Limited data on weight­based dosing
Usual total dose .5­5 mg
Fentanyl .5–1.5 micrograms/kg; start Effect in 1– 30–60 min Given in combination with Monotherapy for moderate or deep with .25 microgram/kg in  min sedatives that lack sedation will not provide adequate elderly analgesic properties; sedation/amnestic effects
Repeat dose: .5–1.5 monotherapy may be Respiratory depression micrograms/kg, can repeat used for minimal sedation every 1–3 min (longer between­dose intervals are recommended if larger initial doses are given)
Alfentanil  micrograms/kg; decrease Effect in <1 7–9 min Fast onset, short duration Increased risk of apnea dose in elderly min of action
Repeat dose:  Studied for moderate micrograms/kg; decrease sedation alone or in dose in elderly combination with propofol
Remifentanil .16 microgram/kg/min Nearly 3–10 min Fast onset, short duration Poor muscle relaxation infusion immediate of action Increased risk of apnea or Does not rely on renal or
 microgram/kg bolus; hepatic function for decrease dose in elderly metabolism or clearance
Repeat dose (when using Studied for moderate bolus dosing): .5 sedation alone or in microgram/kg; decrease combination with dose in elderly propofol
Dexmedetomidine  microgram/kg over  min, 4–5 min 45–90 min Potentially useful when Hypotension (common); longer then maintenance infusion cooperation is required or readiness to discharge; limited of .6 microgram/kg/h in a patient experiencing evidence for adults in ED setting
(range, .2–1.0 respiratory depression micrograms/kg/h) with opioids
Nitrous oxide 50%/50% mixture with Immediate Seconds Mild anesthetic, strong Risk for occupational exposure; oxygen self­administered by analgesic, causes should be given in well­ventilated patient through a mask euphoria, anxiolytic room with scavenging system;
Repeat dosing: when Nearly immediate onset potential for abuse by staff needed and recovery
Ideal procedures: dressing changes, lumbar punctures, wound closure, vein puncture, IV placement, urine catheterization, gastric tube placement
Methohexital .75–1.5 milligrams/kg <1 min <10 min Short procedures Respiratory depression (common)87;
Repeat dosing: .5 requiring moderate to myocardial depressant; avoid in milligram/kg every 2–5 min deep sedation hemodynamically unstable patients
Data adapted from Rahman, N.70 References for table: 68–105. COMPLETION OF PROCEDURAL SEDATION
At the completion of sedation and the procedure, patients should be monitored until they return to their baseline mental status and cardiopulmonary
©,107 function. A structured assessment, such as the Aldrete Score can be used to assess the patient’s recovery and safety for discharge. Such assessment tools are typically part of procedural sedation documentation forms.
The duration of observation before terminating monitoring or discharge is variable. It depends on the quantity of sedatives given, the patient’s response, the duration of the procedure, and the occurrence of any adverse events. Generally, patients who have returned to a baseline level of consciousness are unlikely to have further negative changes in level of consciousness. Most adverse events occur during procedural sedation itself, typically within a few minutes of sedative administration. The occurrence of major adverse events >5 minutes after completion of the procedure is rare

(<1%). The occurrence of life­threatening adverse events after discharge of an ED patient who has undergone procedural sedation has not been reported. Patients should be instructed to return if they develop respiratory complaints or nausea or repetitive vomiting. The follow­up interval required for patients who undergo ED procedural sedation is usually related to the procedure rather than the sedation.
AGENTS FOR PROCEDURAL SEDATION
PROPOFOL
,18,34,71,109­114
Propofol is a safe and efficacious medication for providing moderate and deep procedural sedation in the ED. Predictable, ultra­rapid onset; short duration of action; and the combined effects of sedation, amnesia, and muscle relaxation render propofol an excellent choice for most
,18,56,71,109,115­118 procedures requiring moderate or deep sedation in the ED.
,119
Because the most serious adverse effects of propofol are rapidly developing respiratory depression and apnea, have ventilatory support equipment at the bedside. Propofol can produce hypotension as a result of both negative inotropy and vasodilatation. Hypotension is more common
 in hypovolemic patients and those with ASA physical status scores of III or IV. Correct hypovolemia before propofol administration.
Sedation from propofol occurs within  to  seconds after injection and lasts for about  to  minutes. Propofol is rapidly distributed into tissues, and once tissues are saturated, subsequent doses will have a greater effect than the initial bolus. The recommended dose for ED procedural sedation in healthy nonelderly adults is .5 to .0 milligram/kg IV, followed by .5 milligram/kg IV every  minutes if needed. Higher doses are associated with more respiratory depression. Exercise caution with subsequent doses, because repeat dosing can lead to variable depths of sedation and prolonged
 duration of action. In elderly patients, use 50% lower doses (0.25 to .5 milligram/kg) and titrate more slowly. (See section titled
“Dosing Considerations in Special Populations”).
Propofol target­controlled infusion, an alternative to bolus dosing, is executed using a targeted plasma concentration from a loading dose (based on volume of distribution and targeted drug concentration), which is followed by a decreasing rate of infusion. Propofol target­controlled infusion may be
120­122 a safer route of delivery and is undergoing further study for ED sedation.
Propofol Safety With Soy and Egg Allergies
Propofol was previously considered contraindicated for patients allergic to eggs or soy protein. The contraindication was based on case reports of
123 possible allergy and also on theoretical risk based on propofol’s formulation with soybean oil, glycerol, and egg lecithin emulsion. However, during
124 the manufacture and formulation of the soybean oil and egg lecithin in propofol, clinically significant allergy­mediating proteins are likely removed.
125­128
Furthermore, propofol has been administered safely to patients with soy, egg, and peanut allergies. The American Academy of Allergy, Asthma, and Immunology supports the safety of propofol in patients with soy and egg allergies, and recent emergency medicine practice guidelines state that
,129 propofol’s only true immunologic contraindication is an allergy to the drug itself.
Pain on Injection
Propofol may cause local pain at the IV site during administration. Suggested methods to reduce propofol infusion burning include pretreating the injection­site vein with lidocaine or mixing the lidocaine with the initial propofol injection. With pretreatment, a tourniquet is placed proximal to the injection­site vein and .5 milligram/kg of lidocaine is injected approximately  seconds prior to propofol infusion. When the alternative method of
130,131 combining lidocaine with the initial propofol dose is used, add .5 to .0 milligram/kg of lidocaine to the first bolus of propofol.
KETAMINE
Ketamine produces a state of dissociation, or detachment from immediate surroundings, characterized by profound analgesia, sedation, and amnesia.

Unlike other agents used for procedural sedation, ketamine possesses both analgesic and anxiolytic properties. Ketamine is an effective agent for ED
,132­136 and prehospital PSA and is safe and versatile.
Ketamine is a derivative of the drug phencyclidine and is an N­methyl­D­aspartate glutamate receptor antagonist. It exerts its effects through a wide
137­139 range of spinal and cortical pathways via dopamine, norepinephrine, serotonin, and opioid receptor antagonism. Reported psychotropic effects of ketamine include hallucinations, synesthesia, pronounced derealization and depersonalization, a “detachment from the body,” and a
140 preoccupation with unimportant sounds. At higher doses, users have described being “lost in the K­hole,” a term used for the pronounced
139,141 depersonalization or “out of body” experience, perceptions that can be quite frightening to patients.
Ketamine does not have a typical dose­response continuum with progressive titration. At low doses, between .1 and .3 milligram/kg, analgesia and
142­149 142­149 minimal sedation occur. Low­dose ketamine for minimal sedation or analgesia is a reasonable choice either with or without opioids. Side
150,151 effects, such as dizziness or psychoperceptual disturbances, are seen with higher doses (see below) and may also occur during emergence.
Other side effects to be prepared for when using ketamine are increased muscle tone, clonus, or the rare case of sudden muscle rigidity, which can be
152 alleviated with midazolam.
Once a critical dosing threshold is exceeded (about .0 to .5 milligrams/kg IV or  to  milligrams/kg IM), ketamine’s characteristic dissociative state abruptly appears. This dissociation has no observable levels of depth. The only value of additional ketamine is to prolong the dissociative state for extended procedures. Ketamine can be given either IV or IM. The IM route allows for approximately  minutes of sedation, compared with  minutes by the IV route.
Ketamine preserves a patient’s ventilatory effort and has minimal depressant effect on blood pressure. However, ketamine can
101,150,153,154 cause transient apnea (approximately  seconds), particularly when administered rapidly IV.
Ketamine Emergence Reactions and Other Effects
134,155
Emergence reactions after ketamine range from mild agitation to nightmares and hallucinations. Midazolam or propofol can be given along
155,156 with ketamine to minimize the development of emergence reactions. In one study, coadministered IV midazolam in adults (0.03 milligram/kg IV)
156 who were receiving IV ketamine (1.5 milligrams/kg) reduced recovery agitation by about 4% without an increase in respiratory events. A single dose of propofol (30 to  milligrams for adults younger than age  years, with lower doses in older adults), given when distressing symptoms are
157 recognized, has anecdotally been reported to reduce the incidence and severity of emergence reactions, hypertension, and muscle rigidity. Further evidence of propofol’s mitigation of ketamine­associated recovery agitation is supported by the finding that ketofol produces fewer emergence
158 reactions than ketamine alone. It is sufficient to give ketamine without midazolam or propofol and then treat patients who develop emergence reactions with midazolam as they occur. It is also reasonable to coadminister a dose of .03 milligram/kg of midazolam when ketamine is used in adults, both to reduce risk of emergence reactions and also to potentially reduce chances of postprocedural vomiting. Because of the possibility of
 emergence reactions, do not use ketamine in patients with schizophrenia and psychosis.

Anorexia, nausea, and vomiting have been reported with ketamine use in approximately 5% to 15% of patients. However, these effects are not
159 normally severe, with most patients able to drink shortly after regaining consciousness. Emesis typically occurs during the recovery phase when the
 patient is alert and can clear his or her airway. Consider using an antiemetic when using ketamine for PSA.
Ketamine induces a hypersympathetic state, leading to hypertension and an increase in intraocular pressure. Blood pressure elevations begin shortly following administration, reaching peak levels in a few minutes. Blood pressure typically returns to preanesthetic levels  minutes following
159 administration of the last dose. Systolic and diastolic pressures typically peak at 10% to 50% above preanesthetic levels. However, elevations may be higher or last longer in individual cases. For this reason, avoid ketamine in patients in whom a significant elevation in blood pressure
,159 159 would constitute a serious hazard (e.g., coronary artery disease). Increases in intraocular pressure with ketamine are minimal, but
,69 the evidence for use of ketamine in patients with acute globe injury or glaucoma is inconclusive. There is some evidence that the hypersympathetic
 state resulting from ketamine administration may be more profound in patients with porphyria and thyroid disorders.
Although rare, hypersalivation and bronchorrhea have been reported with ketamine administration through the stimulation of tracheobronchial
,69  secretions. Be prepared to suction patients with respiratory tract concerns and those with an impaired ability to mobilize secretions.
Glycopyrrolate or atropine can be given to blunt this effect, but these drugs are not routinely or prophylactically recommended because they are
,69 associated with significantly more airway and respiratory events.
160,161
It is historically stated that ketamine increases intracranial pressure (ICP), limiting its use in emergent situations. The experimental data from
160,161 animal studies and human observations are conflicting, depending on the specific circumstances. However, prospective controlled data in patients with brain injury and ICP monitoring demonstrate that ketamine does not increase ICP (it may actually decrease ICP), and the drug blunts
162 adverse ICP response to stimulation. At least two systematic reviews since 2014 have concluded that there is no evidence to support concerns that
163,164 ketamine has an adverse ICP effect. Experts in the use of ketamine in the ED have concluded that in the absence of hydrocephalus, there is no
165 evidence to support concerns about ketamine and adverse ICP effect. The weight of available evidence, including expert opinion, favors use of ketamine without concerns over ICP when the drug is otherwise the correct choice for PSA. Thus, there is no clear evidence that ketamine is harmful as an induction or sedation agent in patients with a potential head injury if it is the appropriate sedative choice based on other considerations.
166­168
There are growing reports of successful use of ketamine in resource­limited settings including the prehospital environment. In austere settings,
169­172 ketamine can facilitate procedures such as fracture splinting, chest tube placement, extrication, and field amputations.
ETOMIDATE
,95,173
Etomidate is a unique nonbarbiturate sedative­hypnotic agent with minimal side effects, a rapid onset, and short duration of action. It is an
 excellent tool for clinicians and is frequently used for rapid­sequence intubation (RSI) in the ED. The recommended dose for etomidate in procedural
,90,92,95,100,173 173 sedation is .1 to .2 milligram/kg, with optional repeat doses of .05 milligram/kg administered every  to  minutes. Etomidate has
,90,92,95,100,173 an onset of less than  minute and a duration of  to  minutes.
When compared with propofol for procedural sedation, etomidate appears equally effective at achieving deep sedation and enabling successful procedure completion (89% with etomidate, 97% with propofol). Respiratory adverse event rates appear similar between the two drugs. Propofol
173 results in more hypotension, whereas etomidate results in more myoclonus.
When compared with midazolam use for shoulder reduction, etomidate PSA has similar rates of successful reductions. However, patients experienced
174 faster recovery rates when receiving etomidate (10 minutes) as compared to midazolam (23 minutes).
Etomidate is typically well tolerated and has a uniquely neutral cardiovascular profile when compared to other PSA sedatives. Its minimal hemodynamic effects, combined with a short duration of action, make etomidate an excellent agent for procedures such as
  cardioversion. Etomidate’s short duration of action makes it an unfavorable choice for procedures requiring a longer duration of sedation.
Etomidate is characterized by two issues, adrenocortical suppression and myoclonus, that are not commonly seen with other PSA agents.
,95,175
Etomidate’s known effect of adrenocortical suppression has long been a source of controversy. Even one dose of etomidate has been
176 associated with lowering of cortisol levels after surgery, but without adverse outcomes. Many surveys, emergency RSI series, and expert editorials worldwide have highlighted the high frequency with which etomidate is endorsed for use in stable or unstable patients, including patients with sepsis
177­180 or trauma. However, a 2018 survey of emergency medicine physicians and anesthesiologists identified the etomidate issue as “significant and
181 not adequately resolved.” Fortunately, septic patients, the group for which there is the most support for risk due to etomidate’s adrenocortical axis
180 effects, are infrequent candidates for ED PSA.

Myoclonus is sufficiently frequent (seen to some degree in up to half or more of patients receiving the drug ) that PSA planning with etomidate should account for the side effect. Myoclonus is likely due to subcortical disinhibition. Pretreatment with midazolam, suggested for over a decade as
182 effectively blocking disinhibition, can reduce the incidence and severity of myoclonus. Depending on situational characteristics related to the patient and procedure, PSA using etomidate may be accompanied by pretreatment with midazolam in a 1­ to 2­milligram IV dose for adults.
Other etomidate side effects include emergence nausea and vomiting (up to 40% of patients), which can be severe and interfere with the procedure
,69,90,95,173,174 being performed. Consider coadministration of an antiemetic when etomidate is being used for PSA.
KETAMINE AND PROPOFOL (KETOFOL)
,73,158,183­190
The combination of ketamine and propofol for ED procedural sedation has a well­documented safety and efficacy profile. Propofol is an excellent sedative, but respiratory depression and hypotension are important adverse events. In addition to providing analgesia (which propofol does not), ketamine coadministration may mitigate propofol’s respiratory and hemodynamic depression. In turn, the adverse events associated with ketamine (vomiting and emergence reactions) can be mitigated by propofol’s antiemetic and hypnotic properties.
,73,158,183,185,186,188­190
The “ketofol” combination is safe and effective for ED PSA. Published ketofol ED procedural sedation studies have used a variety of combinations, from equal mixtures of propofol and ketamine to normal doses of propofol with subdissociative doses of ketamine (used for analgesia only).

Adding ketamine to propofol promotes hemodynamic stability, which is reassuring in patients with known or potentially reduced cardiac function.
There is also evidence of synergism between the two drugs; data indicate that as compared to propofol alone, ketofol provides improved, less erratic
187,191,192 ,73,193 sedation. The analgesic properties of ketamine preclude the need for (and risks of) opioids that are administered with propofol.
Most studies to date have failed to demonstrate a consistent difference in complications between ketofol (mixtures of ketamine and propofol from 1:1
189,191 to 1:4) compared with propofol alone. However, a meta­analysis of five randomized controlled trials published between 1990 and 2017 found
193 that, as compared to propofol alone, ketofol was associated with fewer respiratory adverse events. Editorialists assessing the ketofol evidence base have also concluded that the combination agent is arguably preferable (as compared to propofol or ketamine alone) in patients with risk of
194 hypotension; propofol alone risks hemodynamic depression, and ketamine alone risks recovery agitation.
Another advantage of ketofol is that it may be able to achieve adequate sedation with lower total doses, as compared with either propofol or ketamine used alone. Ketofol prolongs the duration of sedation beyond that expected with propofol alone; this may reduce the need for repeat propofol boluses and be useful for procedures anticipated to take more time.
MIDAZOLAM
Benzodiazepines have amnestic, anxiolytic, and sedative properties. Midazolam is the preferred agent in this drug class because of its rapid onset,
,96 short duration of action, and ability to be given via multiple routes (IV, IM, intranasal, and PO).
,103
Midazolam is not an analgesic, so the drug is often combined with analgesics such as fentanyl or ketamine. The combinations of midazolam/ketamine and midazolam/fentanyl have both been found to be effective for ED orthopedic procedures, although there was more
103 hypotension seen in the midazolam/fentanyl group. When compared to combination propofol/fentanyl PSA, midazolam/fentanyl combination
,104 therapy is equally efficacious (although with longer recovery time).
Recommended dosing for midazolam in procedural sedation is .5 to .5 milligrams IV given over 2­3 min. Weight­based dosing of .01­0.1
103,104,71,133 milligram/kg has been described, but larger doses (e.g.,  milligrams in a 70­kg adult) have may be associated with hypoxia.
,96,105
Titrate midazolam slowly, with the dose repeated if needed every  to  minutes. The onset of action is  to  minutes, with peak effect seen in  to  minutes. The duration of sedation correlates linearly with the amount of drug administered, with sedation times reported to be as long as  to 
,96,105,195  minutes. The IV route is preferred because other administration routes are subject to erratic absorption and corresponding delayed onset.
Common side effects include hypotension, hypoventilation, and hypoxia. These effects are exacerbated when midazolam is combined with other
 medications such as opioids.
SYNTHETIC OPIOIDS
Synthetic opioids, such as fentanyl, alfentanil, sufentanil, and remifentanil, have a role in procedural sedation as both monotherapy and in
 combination with sedative agents. Opioids alone may be sufficient in procedures where deep levels of sedation are not required. The analgesia
,196 provided by the opioid complements the sedation and amnesia (which is not expected with opioids) provided by the sedative.
Synthetic opioids are rapid­acting opioids and are the preferred analgesics for PSA. Their pharmacokinetic profiles make them easily titratable and offer advantages over other common opioids such as morphine. As compared to fentanyl, for instance, morphine and hydromorphone have longer
,196 times to onset, longer durations of action, and higher incidences of emesis and are associated with more hemodynamic effects.

Fentanyl is a synthetic opioid  to 100 times as potent as morphine. Fentanyl has become the analgesic of choice for PSA in the ED. It is highly
,97 lipophilic, which results in a very rapid onset of action (typically  to  minutes) and a short duration of action (30 to  minutes). Dosing for fentanyl is recommended to start at .5 to .5 micrograms/kg in most patients (with a .25 microgram/kg lower dose in elderly patients) and can be
,91,97 repeated every  to  minutes. Although typically not associated with hypotension and respiratory depression when used as monotherapy, fentanyl can cause these effects in certain patient populations; the incidence of hemodynamic or ventilatory depression is higher when fentanyl is used
,67,69 in combination with sedatives.
Alfentanil and remifentanil are ultra­short­acting opioids that have been used for the induction of moderate sedation. As compared to fentanyl,
,98 alfentanil is one­fourth as potent, has one­third the duration, and exerts a more rapid onset of sedation. The recommended dose for alfentanil in

PSA is  micrograms/kg, with an expected duration of sedation of  to  minutes. Alfentanil has been studied as both monotherapy and in combination with propofol for moderate sedation. When used for ED PSA, alfentanil and propofol have similar major airway and respiratory adverse
74­76 events, but alfentanil has higher rates of reported pain and patient recall of the procedure.
Sufentanil is more lipid soluble than either fentanyl or alfentanil. Its onset is rapid, and its half­life falls between that of fentanyl and alfentanil.

Although used primarily for analgesia, sufentanil (by infusion) is useful for intensive care sedation. There are few data reporting on acute care sufentanil use, and the drug’s potential role in ED PSA remains to be seen.
Remifentanil offers some pharmacokinetic advantages over both alfentanil and fentanyl. Its onset of action is nearly immediate, and its recovery time is equally rapid. It is metabolized by plasma esterase in the blood and therefore does not rely on hepatic metabolism, as do fentanyl and
,94,97,98,198 199 alfentanil. This allows for fast clearance and recovery, even in the setting of organ dysfunction, comorbidities, or advanced age. Due to the pharmacokinetics of remifentanil, it is typically administered as a continuous infusion. A study evaluating remifentanil given as a continuous
 infusion in the ED found efficacy in short, painful procedures using a dose of .16 microgram/kg/min.
,79,200 
Multiple trials have evaluated bolus dosing of remifentanil for procedural sedation in the ED in adult patients. In one study, remifentanil  microgram/kg was combined with propofol .5 milligram/kg with rescue doses of .5 microgram/kg and .25 milligram/kg, respectively. This regimen was found to have equal efficacy and a faster recovery when compared to the combination of midazolam/morphine. Another study compared
 monotherapy of remifentanil to the combination of propofol and fentanyl for anterior shoulder reductions. In this study, the bolus dose for remifentanil was  microgram/kg with a .5 microgram/kg rescue dose. The results showed equal efficacy for pain management when compared to propofol/fentanyl for shoulder reduction. However, as compared to the other agents, remifentanil demonstrated a lower success rate in muscle
 relaxation as well as a significantly higher rate of apnea.
Rigid Chest Syndrome
A rare side effect of synthetic opioids is skeletal muscle rigidity, which primarily affects the chest and abdominal muscles. Chest wall rigidity decreases
201 chest wall compliance and may result in the inability to effectively ventilate. Although the exact mechanism is unknown, skeletal muscle rigidity is
,98,201 related to both the dose and rate of administration.
Chest wall rigidity has been reported with low doses of synthetic opioids. However, the rigid chest syndrome is predictably seen only with high doses
(exceeding  to  micrograms/kg of fentanyl, 130 micrograms/kg of alfentanil, and >1 microgram/kg of remifentanil), particularly if given by rapid IV
,93,94,97,201 push. To prevent this complication, administer synthetic opioids in multiple low doses, each by slow IV push, rather than rapidly administering them as a single large dose.
If chest wall rigidity occurs, stop administration. The use of concurrent propofol or thiopental may attenuate the rigidity, and naloxone has been
201 occasionally reported to be of use. In rare cases, administration of a neuromuscular blocker (e.g., succinylcholine) and intubation may be
,97,98 required.
LESS COMMONLY USED AGENTS
The medications previously discussed in this chapter demonstrate suitable pharmacodynamics and evidence for procedural sedation and have
 optimized the care patients receive. As with many older drugs, a gap of evidence develops over time comparing older to newer agents. Despite an evidence base that may be more limited than that addressing some of the medications discussed earlier, these drugs remain plausible agents for adult
,85,86 procedural sedation in the ED.
Dexmedetomidine

Dexmedetomidine achieved U.S. Food and Drug Administration approval for procedural sedation in 2003. It can provide sedation without
203,204 respiratory depression. It has not been extensively studied in the ED. Some emergency medicine investigators have found high rates of hemodynamic compromise with dexmedetomidine use in the ED, and there are insufficient data to currently support a recommendation for its routine use for ED PSA.
Dexmedetomidine is an α ­adenoreceptor agonist and possesses sedative, anxiolytic, sympatholytic, and analgesic­sparing effects, with minimal

,202 respiratory depression. It exerts its anxiolytic and sedative properties by reducing sympathetic tone. The sedative effects are reversible: The patient can be easily roused to a lucid state with stimulation, and then can fall back into a state similar to natural sleep when stimulation is removed.
,83
The degree of sedation is dose dependent, with effects ranging from minimal to deep sedation.
The U.S. Food and Drug Administration approved dose for dexmedetomidine in procedural sedation is a  µg/kg loading dose given over  minutes followed by a maintenance infusion of .6 microgram/kg/h. It can then be titrated to clinical effect with a dosing range of .2 to 
,83,202 microgram/kg/h. Although clinical trials have not studied bolus dosing in the setting of ED PSA, case reports have demonstrated success using
 bolus dosing of dexmedetomidine  to  micrograms/kg for shoulder reductions. Intranasal administration may also be effective, but the long time to
205 peak sedation (20 to  minutes) and long duration of sedation (45 to  minutes) limit intranasal dexmedetomidine use in the ED.

Dexmedetomidine has moderately slow pharmacokinetics compared with other agents used for procedural sedation. It is hepatically cleared, so
202 ,202 elimination may be affected with hepatic impairment. The half­life is relatively short at  minutes. However, time to sedation following a bolus
 dose is typically longer at  to  minutes. When compared to propofol (in pediatric patients), dexmedetomidine was found to have longer time to
  recovery. Even during recovery, patients may be drowsy when not stimulated.
Dexmedetomidine does not directly impair respiratory drive, but it may alter respiratory responses to hypoxia and hypercapnia. This effect can be
 more profound when given concomitantly with other sedatives or opioids.
Hemodynamic effects include hypertension, hypotension, and bradycardia as a result of vasoconstriction, sympatholysis, and
,99,202 baroreflex­mediated parasympathetic activation.
Nitrous Oxide

Nitrous oxide (N O) is one of the oldest drugs still used in medicine and remains the fastest “in/out” anesthetic drug in use today. It possesses mild
 anesthetic, dissociative, and muscle relaxant properties. N O works by stabilizing axonal membranes to partially inhibit action potentials, leading to

,99 sedation. Its analgesic properties are similar to morphine through its action on opiate receptor systems.
N O has been used in the ED for mildly painful procedures, including dressing changes, lumbar punctures, wound closure, vein puncture, IV

 placement, urine catheterization, and gastric tube placement. It does not work well for orthopedic procedures. It does not provide adequate
 analgesia or sedation for procedures of moderate to severe pain intensity.
There is also an issue surrounding occupational N O exposure for staff administering the medication. Administer in well­ventilated areas with

,86 scavenger systems available to minimize risk to staff. Because of the euphoria induced by N O, there is a high potential for abuse in healthcare

 workers.
N O is typically administered as a 50%/50% mixture with oxygen through a mask. Patients can self­administer the medication through the mask

 provided. N O use in adult patients in the ED has been criticized due to difficulties with administration and a lack of recent evidence. However, N O
  may see increased utilization in the prehospital setting based on evidence of efficacy in prehospital acute traumatic pain relief and improved delivery
206 systems.
Barbiturates
Barbiturates have intermittently had a role in PSA. Barbiturates work by depressing the sensory cortex, decreasing motor activity, and altering cerebellar function. These actions produce drowsiness, sedation, and hypnosis. Of the barbiturates, methohexital is the best drug for adult ED
,86 procedural sedation. Methohexital’s overall risk profile renders it an unusual agent for IV ED PSA, but it remains a viable choice in selected circumstances.
Methohexital is an ultra­short­acting barbiturate that provides sedation while leaving airway protective measures intact. It does not deposit in fat
207 tissue to the extent of other barbiturates, resulting in faster clearance.
Older ED PSA trials demonstrated some potential utility for methohexital but with concerns for respiratory depression. The usual IV dose range is .75
86­88 to .5 milligrams/kg; additional doses of .5 milligrams/kg can be given every  to  minutes as needed. The time to onset is less than  minute, and
,87 sedation typically lasts less than  minutes.
One report of IV methohexital reported the drug potentially useful for adult PSA in a trial in which a mean dose of  milligrams was used. Apnea
 requiring bag­valve­mask ventilation was noted in .5% of cases. Another older series of methohexital use for ED orthopedic procedures reported that methohexital (mean dose of .4 milligrams/kg) facilitated PSA in 81% of patients; .2% had complications, mainly respiratory depression and
208 vomiting.
Methohexital has a direct myocardial depressive effect, which can decrease blood pressure with a compensatory rise in heart rate. For this reason, it
 should be avoided in hemodynamically unstable patients. ED PSA expert reviews caution that adding methohexital to opioids increases risk of
 respiratory depression. As compared to propofol when used for orthopedic sedation, methohexital exhibited similar rates of recall, sedation, pain
 relief, satisfaction, and time to return of baseline mental status.
DOSING CONSIDERATIONS IN SPECIAL POPULATIONS
OBESITY
Obesity remains a widespread problem, and clinicians should be aware that the physiologic changes associated with obesity can affect the
209 distribution, clearance, and binding of many medications. This includes many sedatives and analgesics, which are highly fat soluble, and obese patients exhibit marked changes in clearance and volume of distribution. There is no consensus or ED evidence on the optimal dosing strategy based on body habitus.
Despite an absence of data directly addressing PSA drug dosing in obese ED patients, clinical decisions may be informed by pharmacokinetic drug
210 properties and data extrapolated from the anesthesia evidence base. Standardized dosing equations used to modify dosing weight are detailed in

Table 37­5. TABLE 37­5
Standardized Dosing Equations in Obesity
Total body weight (TBW) Measured body weight (kg)
Ideal body weight (IBW) Men (kg) =  + (2.3 [height (in.) – 60])
Women (kg) = .5 + (2.3 [height (in.) – 60])
Lean body weight (LBW) Men (kg) = (9270 × TBW)/[6680 + (216 × BMI)]
Women (kg) = (9270 × TBW)/[8780 + (244 × BMI)]
Body mass index (BMI) Weight (kg)/height (m)2
Source: Modified with permission from Willis S, Bordelon GJ, Rana MV. Perioperative pharmacologic considerations in obesity. Anesthesiol Clin 2017 Jun;35(2):247­
257. Copyright Elsevier.

Propofol is highly lipophilic and distributes rapidly to the tissues from the plasma. Data from morbidly obese subjects undergoing anesthesia induction have shown a similar response to doses based on lean body weight as lean control subjects who received doses based on total body
213 weight. Additionally, studies evaluating procedural sedation in children with obesity revealed that children could be successfully sedated with less propofol on a per­weight basis compared with children of normal weight, suggesting that dosing propofol by ideal body weight is an appropriate
210 strategy.
Etomidate, ketamine, and synthetic opioids such as fentanyl possess very similar pharmacodynamic properties to propofol, because they are also
211,214 highly lipophilic and protein bound. Anesthesia studies evaluating etomidate in obese patients have found that using lean body weight and ideal
211,214 body weight was equally as effective as using total body weight. Pharmacokinetic data for fentanyl in morbidly obese patients found a correlation
209 between clearance of fentanyl and lean body weight, concluding that dosing should be based on lean body weight. Ketamine has not been thoroughly investigated in obesity. However, based on its lipophilicity and large volume of distribution, ketamine is recommended (in the anesthesia
211,215 literature) to be dosed based on ideal body weight.
Benzodiazepines, while similarly lipophilic as the other sedative agents used in procedural sedation, have a volume of distribution that correlates with excess fat tissue. When single IV boluses are given, regardless of which benzodiazepine is used, the dose should be increased in
195,209 proportion with total body weight.
Integration of pharmacokinetic data from non­ED settings should potentially inform, but not dictate, EM PSA. Many other factors besides body habitus influence drug dosing. In balancing a common­sense approach of sound pharmacology and practice based on EM evidence, two recommendations can be made. First, scale the dose based on ideal body weight or lean body weight for propofol, fentanyl, etomidate, and ketamine in obese patients.
209­211,213,214
Second, benzodiazepines should be dosed based on total body weight.
ELDERLY, UNDERWEIGHT, AND COMORBID CONDITIONS
Patient age, weight, and comorbidities can have marked effects on the pharmacokinetics of anesthetics. Changes in cardiac output, total blood
213 volume, and alterations of plasma protein binding can affect peak plasma concentrations, metabolism, and elimination half­life. In addition, elderly
216 patients may demonstrate a low physiologic reserve, potentially leading to increased adverse event rates. It is prudent for a clinician to consider patient­specific factors when choosing the appropriate drug and dose in procedural sedation.
Elderly and underweight individuals can have a more profound response to anesthetic agents. This is largely due to a small central compartment and a
217 lower body fat percentage. Medications such as propofol, ketamine, benzodiazepines, etomidate, and fentanyl are highly lipophilic with large volumes of distribution. In situations where there is less fat mass and therefore a smaller peripheral compartment, larger quantities of drugs remain in
210 the serum and are available to cross the blood–brain barrier. This can be further exacerbated by hypoalbuminemia as many anesthetics are highly
,97,159,195,212 protein bound.
ED studies evaluating propofol in elderly patients recommend using half the dose recommended in healthy adults (0.5 milligrams/kg with additional
,216,217 doses of .25 milligrams/kg as needed). Although guiding ED data are sparse, the lower dosing may be prudent for medications (e.g., fentanyl,
,159 ketamine) with pharmacokinetics similar to those of propofol.
Etomidate has demonstrated higher free serum levels in the setting of cirrhosis, renal failure, and advanced age. However, a study specifically evaluating its use in elderly patients found similar efficacy and adverse event rates as seen in young, healthy patients receiving the same dose (average
100 dose .14 milligram/kg for both groups). Elderly patients between the age of  and 101 years old have been safely sedated for procedures in the

ED.
The volume of distribution for midazolam fluctuates in patients with advanced age, obesity, congestive heart failure, hepatic impairment, and renal
,195 failure. It also has decreased clearance in patients with cirrhosis. It may be preferred to choose another agent over midazolam in these patient populations. If midazolam is to be used, lower initial doses of .5 to .5 milligrams should be administered, repeat doses should not exceed  milligram, and more time should be allowed between repeat doses (at least  to  minutes) when titrating to the desired level of sedation. Total doses
,195 in these patient populations typically do not exceed .5 milligrams.
PREGNANCY
Pregnant woman present unique challenges in PSA. Maternal physiologic changes impact functional residual capacity, oxygen consumption, and ventilatory compensation. Pregnant women may develop hypotension when placed in the supine position due to aortocaval compression from a
 gravid uterus. See Chapter , “Comorbid Disorders in Pregnancy,” Chapter 256, “Trauma in Pregnancy,” and Chapter , “Resuscitation in
Pregnancy,” for detailed discussions of the physiologic changes in pregnancy that would affect PSA in pregnancy.
Acute fracture/dislocations, sprains, and severe open wounds are examples of situations that may require PSA for effective treatment. Unfortunately, there is no specific evidence base to specifically guide PSA in pregnancy. None of the medications discussed below have been studied in wellcontrolled trials to evaluate their use in pregnancy. Because of this, use medications for PSA only when clearly indicated.
If possible, consult with obstetrics or obstetrical anesthesia to help determine the best PSA agent. However, such consultation may not be available in real emergencies or in rural, low­resource, or community settings. Although no specific recommendations exist for PSA in pregnancy, the following information regarding monitoring and drug selection provides a guide for how to proceed.
The adage “the best maternal care is the best fetal care” applies. Follow the general principles of patient evaluation and monitoring for PSA. Discuss risks and benefits. Maternal vital sign monitoring, including capnography; fetal tocodynamometry or, if not available, intermittent fetal heart tone auscultation; maintenance of maternal oxygenation and ventilation; and fluid resuscitation are mainstays of treatment.
Exposure to PSA medication is typically brief, and the exact effects of these medications in pregnancy are unknown. Rapid­acting, short duration of action synthetic opioids such as remifentanil or fentanyl are not considered to be human teratogens. They cross the placenta but should be rapidly
,97 metabolized by the fetus. Propofol is not considered a teratogen and is considered safe in pregnancy, but is associated with maternal
212  hypotension. However, propofol reportedly dilates fetal placental blood vessels and maintains umbilical blood flow. This likely mitigates some of the hypotensive effects on the fetus. Administer pre­PSA fluids to minimize hypotension associated with propofol. Neonatal depression may occur
212 from propofol used close to delivery. There are no human data about the teratogenicity of ketamine, and therefore, its use cannot be
159 recommended. Additionally, ketamine can increase blood pressure and therefore is not a good choice in hypertensive pregnant women or those with eclampsia or preeclampsia. Neonatal depression can occur if ketamine is given close to delivery. Effects on uterine contractility are reported as
 206,207 variable. Nitrous oxide and methohexital appear to be safe in pregnancy when exposure is short, like that seen in PSA. There is no data
,195 regarding the use of etomidate in pregnancy, so its use is not recommended at this time. Although medications such as N O and methohexital

206,207,212 have shown no teratogenic effects in animals, the results are not always predictive of human response.
RESCUE MEDICATIONS AND REVERSAL AGENTS

All sedatives and analgesics used for procedural sedation carry some risk of transient hypotension. Although the prevalence is highest with propofol, blood pressure drops can be seen even with drugs such as ketamine and etomidate (which are typically viewed as hemodynamically
 neutral). For any drug reducing sympathetic outflow, hemodynamic depression will be more likely and more profound in a volume­depleted patient.

For patients with a history of dehydration, blood loss, or a prolonged fasting state, the clinician should optimize volume status before sedation.

Most incidents of transient hypotension associated with ED PSA can be easily reversed with an infusion of crystalloid; sequalae are rare. If a fluid bolus is inadequate or contraindicated, bolus­dose vasopressors, often referred to as “push­dose pressors,” can be considered. Push­dose pressors are administered in a titratable fashion, with incremental dosing by manual, intermittent, slow IV push from a syringe. Dosing can be repeated
 ,49 according to patient response. Preferred agents for short­lived hypotension are phenylephrine and epinephrine.
Phenylephrine is a pure vasoconstrictor through agonism of α ­adrenergic receptors. The onset of effect is less than  minute. Duration of effect can

,219 be up to  minutes but is typically less than  minutes. The recommended dose of phenylephrine is  to 200 micrograms (0.5 to  mL based on a
,49,219
 to  micrograms/mL concentration) given every  to  minutes.
Epinephrine causes both vasoconstriction and inotropy through its effects on both α­ and β­adrenergic receptors. Epinephrine’s β activity may render the drug preferable to phenylephrine in patients benefiting from an increase in heart rate and cardiac output. The onset of effect is less than 
,220 minute, with a duration of less than  minutes. The recommended dose is  to  micrograms (0.5 to  mL based on a  micrograms/mL concentration) every  to  minutes.
Push­dose pressors have a role in increasing patient safety in ED PSA. However, because some of the dosing will be less familiar to EM clinicians, meticulous attention must be paid to confirming proper drug administration. Mixing and dosing should be done carefully because high doses (such as
,49 those used in resuscitation) can lead to malignant hypertension, dysrhythmias, and cardiac arrest.
,195
Flumazenil and naloxone are the two most commonly discussed pharmacologic reversal agents with PSA applicability. In ED PSA, both of these
102  agents should be readily available. However, routine use is not encouraged. Reasons for this are based on practical considerations if the reversal agents work. A PSA patient receiving naloxone may pose pain control challenges, and flumazenil administration can precipitate seizures in patients
,195 chronically exposed to benzodiazepines. Reversal agents should be used only when there is concern for a major complication, such as aspiration,
 need for intubation, or cardiovascular decompensation.
If the situation allows, when reversal agents are used in the setting of PSA, use these drugs at the lower end of the effective range. Dosing for naloxone is .1 to .4 milligram IV, with peak effect seen after  to  minutes. The dosing for flumazenil is .2 milligram IV, and its peak effect is seen in  to  minutes. Effects of both agents should last  to  minutes, but be vigilant for possible recurrent sedation as early as  minutes after giving reversal
 drugs.
COMPLICATIONS OF ED PSA

A 2016 meta­analysis evaluated  studies with 9652 procedural sedations. Rates of adverse events with ED PSA are quite low, and there have been no
,216,218,221­223 ,216,221­223 known deaths reported. Prior single studies reported complication rates between .3% and 11%. However, pooled complication rates from  randomized controlled trials found rates of adverse events between 0% and .7%; adverse event rates were even lower (0%
 to 4%) when all  studies were included (Table 37­6).
TABLE 37­6
Estimated Rate of Adverse Events in ED Procedural Sedation
No. of Studies/No. of Estimate per 1000 Approximate % of All Agent with Most Frequent
Agent
Sedations Sedations Sedations Adverse Event
Agitation 33/6631 .8 1% Ketamine, ketamine/propofol
Apnea 22/3264 .4 1% Midazolam, midazolam/opioid
Aspiration 10/2370 .2 .1% Propofol and fentanyl (n = 1)
Bradycardia 5/837 .5 .5% Etomidate, midazolam/opioid
Hypotension 27/5801 .2 2% Propofol, midazolam/opioid
Hypoxia 42/7116 .2 4% Propofol, midazolam/opioid
Intubation 19/3636 .6 .2%
Laryngospasm 5/883 .2 .4% Ketamine (n = 1)
Vomiting 25/3319 .4 2% Ketamine
Source: Table adapted from Bellolio et al47 and Rezaie.225
Most ED PSA complications can be categorized as minor adverse events. These include sedation to a deeper level than intended, agitation, transient
,221,223 222,223 hypoxia, hypotension, or emesis. Factors associated with an increased rate of complications include age >65 years, level of sedation,
223 premedication with fentanyl, use of short­acting agents, and sedation for a procedure (as compared to imaging). Analgesia performed at night may
222 be another risk factor for adverse events; this is likely due to PSA being administered by inexperienced providers.
Serious adverse events include the need for assisted ventilation, endotracheal intubation, or treatment of hypotension or cardiac dysrhythmias. In pooled analysis, serious adverse events requiring emergent intervention were rare and included one case of aspiration (out of 2370 sedations), one
 case of laryngospasm (out of 883 sedations), and two intubations (out of 3636 sedations). Although drug­specific content (i.e., particular risks associated with the planned PSA approach in a given case) should constitute the main basis for PSA discussions with patients, the pooled­review data can inform conversations about general ED PSA risks, benefits, and alternatives. The estimated incidences of adverse events per 1000 procedural sedations are shown in Table 37­6. Failure to successfully complete a procedure during ED procedural sedation occurs in about 5% of patients and is more common with certain joint
224 reductions (hips, mandibles) and with increased patient body weight >100 kg.
These overarching summary data for ED PSA success and complications are based on the best available data, but data are heterogenous due to variation in individual study approaches and even definition of important terms such as respiratory depression. Further research and multicenter collaboration are underway to standardize adverse event definitions and reporting, and these endeavors will improve quality monitoring and patient
,5,225­227 safety in ED PSA.
COMMON PROCEDURAL SEDATION ERRORS IN THE ED
CHOOSING THE WRONG DRUG FOR THE PROCEDURE

All sedatives and analgesics offer different benefits and have different side effect profiles. For example, propofol offers excellent muscle relaxation and may be a preferred option for a joint reduction, but etomidate’s hemodynamic profile may translate into preference for this drug in a patient in whom there is significant concern for hypotension. On the other hand, etomidate’s myoclonus may render the drug suboptimal for procedures (e.g., lumbar puncture, fine suturing) for which patient immobility is important (Table 37­4).
CHOOSING THE WRONG DOSE FOR THE PATIENT

A patient’s age, weight, and comorbidities will impact response to medications. Account for these factors in PSA drug selection and dosing. In particular, elderly patients have a lower physiologic reserve and have more profound effects to sedation; consider empirically decreasing sedation
,210,216,217,228 doses and titrate based on patient response. (See section titled “Dosing Considerations in Special Populations.”)
NOT BEING PREPARED
Prepare for procedural sedation by ensuring the right people, equipment, and drugs are in the room. ED PSA safety is enhanced when there is ready
,228 availability of airway equipment, IV fluids, and situationally indicated rescue or reversal drugs.
NOT USING CAPNOGRAPHY
End­tidal carbon dioxide monitoring is a low­cost, minimally invasive, easily used tool allowing early recognition of hypoventilation. Capnography provides earlier indication of respiratory depression than either pulse oximetry or physical assessment. The presence of a waveform may provide
,102,218,228,229 more utility than pulse oximetry alone in determining respiratory status.
NOT OPTIMIZING FLUIDS
Any sedative or analgesic can cause hypotension in volume­depleted patients due to decreased sympathetic outflow and blocking of compensatory
 mechanisms. Volume status should be corrected prior to ED PSA if this is feasible. In most cases (ketamine IM sedation being a noteworthy exception), IV access is necessary for ED PSA, and crystalloids should be readily available.
AGGRESSIVE USE OF THE BAG­VALVE MASK
During PSA, hypoventilation is likely due to airway and ventilation issues. Repositioning the patient, performing a chin lift or jaw thrust, or suctioning may be adequate. Bag­valve mask may be used to facilitate ventilation while awaiting medication clearance. However, bag­valve mask carries a risk of vomiting and aspiration (in nonparalyzed, nonintubated PSA cases) and thus should be employed only when necessary for oxygenation and
,228 ventilation.
Acknowledgments
The authors would like to thank Chris Weaver and Andrew Beckman for previous work on this chapter.


## Page 30

[PubMed: 23695645]
118. Haeseler G, Störmer M, Bufler J, et al: Propofol blocks human skeletal muscle sodium channels in a voltage­dependent manner. Anesth Analg
92: 1192, 2001. [PubMed: 11323345]
119. https://www.asahq.org/standards­and­guidelines/statement­on­safe­use­of­propofol. (American Society of Anesthesiologists. Statement on safe use of propofol, published 2014.) Accessed April , 2019. 120. Burton FM, Lowe DJ, Millar J, Corfield AR, Sim MAB: A study protocol for a feasibility study: Propofol Target­Controlled Infusion in Emergency
Department Sedation (ProTEDS)—a multi­centre feasibility study protocol. Pilot Feasibility Stud 5: , 2019. [PubMed: 30820338]
121. Schnider TW, Minto CF, Struys MMRF, Absalom AR: The safety of target­controlled infusions. Anesth Analg 122: , 2016. [PubMed: 26516801]
122. Green SM, Krauss BS: Target­controlled infusions could improve the safety and efficacy of emergency department propofol sedation. Anesth
Analg 122: 283, 2016. [PubMed: 26678474]
123. Dziedzic A: Is propofol safe for food allergy patients? A review of the evidence. SAAD Dig 14: 430, 2016. [PubMed: 27145556]
124. Baker MT, Naguib M: Propofol: the challenges of formulation. Anesthesiology 103: 860, 2005. [PubMed: 16192780]
125. Molina­Infante J, Arias A, Vara­Brenes D, et al: Propofol administration is safe in adult eosinophilic esophagitis patients sensitized to egg, soy, or peanut. Allergy 69: 388, 2014. [PubMed: 24447028]
126. Wiskin AE, Smith J, Wan SKY, Nally MWJ, Shah N: Propofol anaesthesia is safe in children with food allergy undergoing endoscopy. Br J Anaesth
115: 145, 2015. [PubMed: 26089466]
127. Lambert R, Maffei F, Wadams H: Safety of propofol sedation in children with known food allergies. Crit Care Med 39: 234, 2011. 128. Murphy A, Campbell DE, Baines D, Mehr S: Allergic reactions to propofol in egg­allergic children. Anesth Analg 113: 140, 2011. [PubMed: 21467558]
129. https://www.aaaai.org/conditions­and­treatments/library/allergy­library/soy­egg­anesthesia (Pongdee T: Soy allergic and egg allergic patients can safely receive anesthesia. American Academy of Allergy Asthma and Immunology.) Accessed May , 2019. 130. Nathanson MH, Gajraj NM, Russell JA: Prevention of pain on injection of propofol: a comparison of lidocaine with alfentanil. Anesth Analg 82:
469, 1996. [PubMed: 8623944] University of Pittsburgh
Access Provided by:
131. Picard P, Tramèr MR: Prevention of pain on injection with propofol: a quantitative systematic review. Anesth Analg 90: 963, 2011. [PubMed: 10735808]
132. Sih K, Campbell SG, Talion JM, Magee K, Zed PJ: Ketamine in adult emergency medicine: controversies and recent advances. Ann Pharmacother
45: 1525, 2011. [PubMed: 22147144]
133. Jamal SM, Fathil SM, Nidzwani MM, Ismail AK, Yatim FM: Intravenous ketamine is as effective as midazolam/fentanyl for procedural sedation and analgesia in the emergency department. Med J Malaysia 66: 231, 2011. [PubMed: 22111446]
134. Newton A, Fitton L: Intravenous ketamine for adult procedural sedation in the emergency department: a prospective cohort study. Emerg Med J
25: 498, 2008. [PubMed: 18660398]
135. Vardy JM, Dignon N, Mukherjee N, Sami DM, Balachandran G, Taylor S: Audit of the safety and effectiveness of ketamine for procedural sedation in the emergency department. Emerg Med J 25: 579, 2008. [PubMed: 18723707]
136. Bredmose PP, Lockey DJ, Grier G, Watts B, Davies G: Pre­hospital use of ketamine for analgesia and procedural sedation. Emerg Med J 26: ,
2009. [PubMed: 19104109]
137. https://www.ncbi.nlm.nih.gov/pmc/articles/PMC2148883/pdf/anesthprog00225­0014.pdf. (Bergman SA: Ketamine: review of its pharmacology and its use in pediatric anesthesia.) Accessed April , 2019. 138. Lindefors N, Barati S, O’Connor WT: Differential effects of single and repeated ketamine administration on dopamine, serotonin and GABA transmission in rat medial prefrontal cortex. Brain Res 759: 205, 1997. [PubMed: 9221938]
139. Sassano­Higgins S, Baron D, Juarez G, Esmaili N, Gold M: A review of ketamine abuse and diversion. Depress Anxiety 33: 718, 2016. [PubMed: 27328618]
140. Hartvig P, Valtysson J, Lindner K­J, et al: Central nervous system effects of subdissociative doses of (S)­ketamine are related to plasma and brain concentrations measured with positron emission tomography in healthy volunteers. Clin Pharmacol Ther 58: 165, 1995. [PubMed: 7648766]
141. Platt CW: Beneath the furrowed brow. Anesthesiology 125: 599, 2016. 142. Motov S, Mann S, Drapkin J, et al: Intravenous subdissociative­dose ketamine versus morphine for acute geriatric pain in the emergency department: a randomized controlled trial. Am J Emerg Med 37: 220, 2019. [PubMed: 29807629]
143. Motov S, Rockoff B, Cohen V, et al: Intravenous subdissociative­dose ketamine versus morphine for analgesia in the emergency department: a randomized controlled trial. Ann Emerg Med 66: 222, 2015. [PubMed: 25817884]
144. Motov S, Mai M, Pushkar I, et al: A prospective randomized, double­dummy trial comparing IV push low dose ketamine to short infusion of low dose ketamine for treatment of pain in the ED. Am J Emerg Med 35: 1095, 2017. [PubMed: 28283340]
145. Pourmand A, Mazer­Amirshahi M, Royall C, Alhawas R, Shesser R: Low dose ketamine use in the emergency department, a new direction in pain management. Am J Emerg Med 35: 918, 2017. [PubMed: 28285863]

Chapter 37: Procedural Sedation and Analgesia in Adults, Justin G. Myers; Jennifer Kelly Sutherland 
146. Beaudoin FL, Lin C, Guan W, Merchant RC: Low­dose ketamine improves pain relief in patients receiving intravenous opioids for acute pain in the
. Terms of Use * Privacy Policy * Notice * Accessibility emergency department: results of a randomized, double­blind, clinical trial. Acad Emerg Med 21: 1194, 2014. [PubMed: 25377395]
147. Miller JP, Schauer SG, Ganem VJ, Bebarta VS: Low­dose ketamine vs morphine for acute pain in the ED: a randomized controlled trial. Am J
Emerg Med 33: 402, 2015. [PubMed: 25624076]
148. Ghate G, Clark E, Vaillancourt C: Systematic review of the use of low­dose ketamine for analgesia in the emergency department. Can J Emerg Med
20: , 2018. [PubMed: 28655364]
149. Ahmadi O, Isfahani MN, Feizi A: Comparing low­dose intravenous ketamine­midazolam with intravenous morphine with respect to pain control in patients with closed limb fracture. J Res Med Sci 19: 502, 2014. [PubMed: 25197290]
150. Strayer RJ, Nelson LS: Adverse events associated with ketamine for procedural sedation in adults. Am J Emerg Med 26: 985, 2008. [PubMed: 19091264]
151. Zanos P, Moaddel R, Morris PJ, et al: Ketamine and ketamine metabolite pharmacology: insights into therapeutic mechanisms. Pharmacol Rev
70: 621, 2018. [PubMed: 29945898]
152. Vien A, Chhabra N: Ketamine­induced muscle rigidity during procedural sedation mitigated by intravenous midazolam. Am J Emerg Med 35:
200.e3, 2017. [PubMed: 27595173]
153. Green SM, Roback MG, Kennedy RM, Krauss B: Pain management and sedation/concepts clinical practice guideline for emergency department ketamine dissociative sedation: 2011 update. Ann Emerg Med 57: 449, 2011. [PubMed: 21256625]
154. Driver BE, Reardon RF: Apnea after low­dose ketamine sedation during attempted delayed sequence intubation. Ann Emerg Med 69: , 2017. [PubMed: 27692755]
155. Sim TB, Seet CM: To study the effectiveness and safety of ketamine and midazolam procedural sedation in the incision and drainage of abscesses in the adult emergency department. Eur J Emerg Med 15: 169, 2008. [PubMed: 18460960]
156. Sener S, Eken C, Schultz CH, Serinken M, Ozsarac M: Ketamine with and without midazolam for emergency department sedation in adults: a randomized controlled trial. Ann Emerg Med 57: 109, 2011. [PubMed: 20970888]
157. Strayer RJ, Shy BD: Best practice during procedural sedation with ketamine. Am J Emerg Med 35: 315, 2017. [PubMed: 27852527]
158. Andolfatto G, Willman E: A prospective case series of single­syringe ketamine­propofol (ketofol) for emergency department procedural sedation and analgesia in adults. Acad Emerg Med 18: 237, 2011. [PubMed: 21401785]
159. https://www.accessdata.fda.gov/drugsatfda_docs/label/2017/016812s043lbl.pdf. (U.S. Food and Drug Administration: Product Information:
KETALAR [Ketamine Hydrochloride] Injection. Chestnut Ridge, NY 10977.) Accessed April , 2019. 160. Himmelseher S, Durieux ME: Revising a dogma: ketamine for patients with neurological injury? Anesth Analg 101: 524, 2005. [PubMed: 16037171]
161. Hughes S: BET 3: is ketamine a viable induction agent for the trauma patient with potential brain injury. Emerg Med J 28: 1076, 2011. [PubMed: 22101599]
162. Bar­Joseph G, Guilburd Y, Tamir A, Guilburd JN: Effectiveness of ketamine in decreasing intracranial pressure in children with intracranial hypertension. J Neurosurg Pediatr 4: , 2009. [PubMed: 19569909]
163. Zeller FA, Teitelbaum J, West M, Gillman LM: The ketamine effect on ICP in traumatic brain injury. Neurocrit Care 21: 163, 2014. [PubMed: 24515638]
164. Cohen L, Athaide V, Wickham ME, et al: The effect of ketamine on intracranial and cerebral perfusion pressure and health outcomes: a systematic review. Ann Emerg Med 65: , 2015. [PubMed: 25064742]
165. Green SM, Andolfatto G, Krauss BS: Ketamine and intracranial pressure: no contraindication except hydrocephalus. Ann Emerg Med 65: , 2015. [PubMed: 25245275]
166. Waack J, Shepherd M, Andrew E, et al: Delayed sequence intubation by intensive care flight paramedics in Victoria, Australia. Prehosp Emerg
Care 22: 588, 2018. [PubMed: 29405806]
167. Coralic Z, Sawe HR, Mfinanga JA, et al: Ketamine procedural sedation in the emergency department of an urban tertiary hospital in Dar es
Salaam, Tanzania. Emerg Med J 35: 214, 2018. [PubMed: 29358491]
168. Wood­Thompson DK, Enyuma OA, Laher AE: Procedural sedation and analgesia practices in the emergency centre. Afr J Emerg Med 9: , 2019. [PubMed: 30873345]
169. Zietlow J, Berns K, Jenkins D, Zietlow S: Prehospital use of ketamine: effectiveness in critically ill and injured patients. Mil Med 184: 542, 2019. [PubMed: 30901477]
170. Lawthaweesawat C, Harris R, Isara W, Pongpirul K: Prehospital care of the  hypothermic, anesthetized patients in the thailand cave rescue. N
Engl J Med 380: 1372, 2019. [PubMed: 30943344]
171. Emerson L, Coogle C: A 54­year­old man entrapped in a truck. J Emerg Nurs 44: 292, 2018. [PubMed: 28943078]
172. https://www.emrap.org. (Swadron S, Bugg W: Emergency medicine reviews and perspectives: a case of entrapment—field amputation.
emergency medicine reviews and perspectives.) Accessed May , 2019. 173. Miner JR, Danahy M, Moch A, Biros M: Randomized clinical trial of etomidate versus propofol for procedural sedation in the emergency department. Ann Emerg Med 49: , 2007. [PubMed: 16997421]
174. Burton JH, Bock AJ, Strout TD, Evie Marcolini BG: Etomidate and midazolam for reduction of anterior shoulder dislocation: a randomized, controlled trial. Ann Emerg Med 40: 496, 2002. [PubMed: 12399793]
175. Walls RM, Murphy MF: Clinical controversies: etomidate as an inducation agent for endotracheal intubation in patients with sepsis: continue to use etomidate for intubation of patients with septic shock. Ann Emerg Med 52: , 2008. [PubMed: 18565378]
176. Du Y, Chen YJ, He B, et al: The effects of single­dose etomidate versus propofol on cortisol levels in pediatric patients undergoing urologic surgery: a randomized controlled trial. Anesth Analg 121: 1580, 2015. [PubMed: 26496368]
177. Wahlen BM, El­Menyar A, Asim M, et al: Rapid sequence induction (RSI) in trauma patients: insights from healthcare providers. World J Emerg
Med 10: , 2019. [PubMed: 30598714]
178. Warnecke T, Dobbermann M, Becker T, et al: Performance of prehospital emergency anesthesia and airway management: an online survey.
Anaesthesist 67: 654, 2018. [PubMed: 29959500]
179. Upchurch CP, Grijalva CG, Russ S, et al: Comparison of etomidate and ketamine for induction during rapid sequence intubation of adult trauma patients. Ann Emerg Med 69: , 2017. [PubMed: 27993308]
180. Dettmer MR, Dellinger RP: The use of etomidate for rapid sequence induction in septic patients J Thorac Dis 7: 1684, 2015. [PubMed: 26623082]
181. Clinkard D, Priestap F, Ridi S, et al: Anesthesiologist and emergency medicine physician attitudes and knowledge regarding etomidate for intubation. J Intensive Care Med 18: 885066618804989, 2018. [PubMed: 30336713]
182. Zhou C, Zhu Y, Liu Z, et al: Effect of pretreatment with midazolam on metomidate­induced myoclonus: a meta­analysis. J Int Med Res 45: 3999,
2017. [PubMed: 28415947]
183. Thomas MC, Jennett­Reznek AM, Patanwala AE: Combination of ketamine and propofol versus either agent alone for procedural sedation in the emergency department. Am J Heal Pharm 68: 2248, 2011. [PubMed: 22095813]
184. Miner JR, Gray RO, Bahr J, Patel R, McGill JW: Randomized clinical trial of propofol versus ketamine for procedural sedation in the emergency department. Acad Emerg Med 17: 604, 2010. [PubMed: 20624140]
185. Willman EV, Andolfatto G: A prospective evaluation of “ketofol” (ketamine/propofol combination) for procedural sedation and analgesia in the emergency department. Ann Emerg Med 49: , 2007. [PubMed: 17059854]
186. Arora S: Combining ketamine and propofol (“ketofol”) for emergency department procedural sedation and analgesia: a review. West J Emerg
Med 9: , 2008. [PubMed: 19561698]
187. David H, Shipp J: A randomized controlled trial of ketamine/propofol versus propofol alone for emergency department procedural sedation. Ann
Emerg Med 57: 435, 2011. [PubMed: 21256626]
188. Green SM, Andolfatto G, Krauss B: Ketofol for Procedural Sedation? Pro and Con. Ann Emerg Med 57: 444, 2011. [PubMed: 21237532]
189. Miner JR, Moore JC, Austad EJ, Plummer D, Hubbard L, Gray RO: Randomized, double­blinded, clinical trial of propofol, 1:1 propofol/ketamine, and 4:1 propofol/ketamine for deep procedural sedation in the emergency department. Ann Emerg Med 65: 479, 2015. [PubMed: 25441247]
190. Nejati A, Moharari RS, Ashraf H, Labaf A, Golshani K: Ketamine/propofol versus midazolam/fentanyl for procedural sedation and analgesia in the emergency department: a randomized, prospective, double­blind trial. Acad Emerg Med 18: 800, 2011. [PubMed: 21843215]
191. Andolfatto G, Abu­Laban RB, Zed PJ, et al: Ketamine­propofol combination (ketofol) versus propofol alone for emergency department procedural sedation and analgesia: a randomized double­blind trial. Ann Emerg Med 59: 504, 2012. [PubMed: 22401952]
192. http://www.who.int/gho/publications/world_health_statistics/2013/en/. (World Health Organization: World Health Statistics, 2013.) Accessed May
, 2019. 193. Ghojazadeh M, Sanaie S, Paknezhad SP: Using ketamine and propofol for procedural sedation of adults in the emergency department: a systematic review and meta­analysis. Adv Pharm Bull 9: , 2019. [PubMed: 31011553]
194. Miner J: Ketamine or ketofol: do we have enough evidence to know which one to use? Acad Emerg Med 24: 1511, 2017. [PubMed: 28802082]
195. https://www.accessdata.fda.gov/drugsatfda_docs/label/2017/208878Orig1s000lbl.pdf. (Product Information: MIDAZOLAM Injection, USP. Lake
Zurich, IL 60047.) Accessed April , 2019. 196. Aminiahidashti H, Shafiee S, Hosseininejad SM, et al: Propofol­fentanyl versus propofol­ketamine for procedural sedation and analgesia in patients with trauma. Am J Emerg Med 36: 1766, 2018. [PubMed: 29397258]
197. Conti G, Arcangeli A, Antonelli M, et al: Sedation with sufentanil in patients receiving pressure support ventilation has no effects on respiration: a pilot study. Can J Anaesth 51: 494, 2004. [PubMed: 15128638]
198. https://www.micromedexsolutions.com/micromedex2/librarian/PFDefaultActionId/evidencexpert.DoIntegratedSearch?
navitem=topHome&isToolPage=true#. (Remifentanil Drug Result Page.) Accessed April , 2019. 199. Kisilewicz M, Rosenberg H, Vaillancourt C: Remifentanil for procedural sedation: a systematic review of the literature. Emerg Med J 34: 294, 2017. [PubMed: 28249938]
200. Dunn MJG, Mitchell R, De Souza C, Drummond G: Evaluation of propofol and remifentanil for intravenous sedation for reducing shoulder dislocations in the emergency department. Emerg Med J 23: , 2006. [PubMed: 16373806]
201. Çoruh B, Tonelli MR, Park DR: Fentanyl­induced chest wall rigidity case report. Chest 143: 1145, 2013. [PubMed: 23546488]
202. http//www.fda.gov/medwatch. (Product Information: PRECEDEX (Dexmedetomidine Hydrochloride) Injection Label. Lake Forest, IL 60045.)
Accessed April , 2019. 203. Chawla N, Boateng A, Deshpande R: Procedural sedation in the ICU and emergency department. Curr Opin Anaesthesiol 30: 507, 2017. [PubMed: 28562388]
204. http://clinicaltrials.gov. (Gerlach AT, Murphy CV, Dasta JF: Critical care an updated focused review of dexmedetomidine in adults, 2009.) Accessed
March , 2019. 205. Bailey AM, Baum RA, Horn K, et al: Review of Intranasally administered medications for use in the emergency department. J Emerg Med 53: ,
2017. [PubMed: 28259526]
206. https://www.boconline.co.uk/en/images/entonox_tcm410­43539.pdf. (Product Information: ENTONOX® Essential Safety Information. Worsley,
Manchester, UK, 2011.) Accessed April , 2019. 207. https://www.accessdata.fda.gov/drugsatfda_docs/label/2008/011559s041lbl.pdf. (Product Information: Brevital ® Sodium Methohexital Sodium for Injection, USP for Intravenous Use. Bristol, TN 37620.) Accessed April , 2019. 208. Austin T, Vilke GM, Nyheim E, et al: Safety and effectiveness of methohexital for procedural sedation in the emergency department. J Emerg Med
24: 315, 2003. [PubMed: 12676304]
209. Leykin Y, Therapy P, Miotto L, Pellis T: Pharmacokinetic considerations in the obese. Best Pract Res Clin Anaesthesiol 25: , 2011. [PubMed: 21516911]
210. Rogerson CM, Abulebda K, Hobson MJ: Association of BMI With propofol dosing and adverse events in children with cancer undergoing procedural sedation. 7: 542, 2017. [PubMed: 28798230]
211. Willis S, Bordelon GJ, Rana MV: Perioperative pharmacologic considerations in obesity. Anesthesiol Clin 35: 247, 2017. [PubMed: 28526146]
212. https://www.accessdata.fda.gov/drugsatfda_docs/label/2014/019627s062lbl.pdf. (Product Information: DIPRIVAN (Propofol) Injection Emulsion,
USP. Lake Zurich, IL 60047.) Accessed April , 2019. 213. Ingrande J, Lemmens HJM: Dose adjustment of anaesthetics in the morbidly obese. Br J Anaesth 105: i16, 2010. [PubMed: 21148651]
214. Gaszynski TM, Jakubiak J, Szewczyk T: Etomidate can be dosed according to ideal body weight in morbidly obese patients. Eur J Anaesthesiol 31:
713, 2014. [PubMed: 25101716]
215. Sultana A, Torres D, Schumann R: Special indications for opioid free anaesthesia and analgesia, patient and procedure related: including obesity, sleep apnoea, chronic obstructive pulmonary disease, complex regional pain syndromes, opioid addiction and cancer surgery. Best Pract Res
Clin Anaesthesiol 31: 547, 2017. [PubMed: 29739543]
216. Homfray G, Palmer A, Grimsmo­Powney H, Appelboam A, Lloyd G: Procedural sedation of elderly patients by emergency physicians: a safety analysis of 740 patients. Br J Anaesth 121: 1236, 2018. [PubMed: 30442250]
217. Patanwala AE, Christich AC, Jasiak KD, Edwards CJ, Phan H, Snyder EM: Pharmacology in emergency medicine: age­related differences in propofol dosing for procedural sedation in the emergency department. J Emerg Med 44: 823, 2013. [PubMed: 23333181]
218. Bellolio MF, Gilani WI, Barrionuevo P, et al: Incidence of adverse events in adults undergoing procedural sedation in the emergency department: a systematic review and meta­analysis. BMJ Open 6: e011384, 2016. [PubMed: 27311910]
219. http://www.fda.gov/medwatch. (U.S. Food and Drug Administration: Product Information: VAZCULEP [Phenylephrine Hydrochloride] Injection for
Intravenous Use. Chesterfield, MO 63005.) Accessed April , 2019. 220. http://www.fda.gov/medwatch. (U.S. Food and Drug Administration: Product Information: ADRENALIN [Epinephrine] Injection. Rochester, MI
48307.) Accessed April , 2019. 221. Weaver CS, Terrell KM, Bassett R, et al: ED procedural sedation of elderly patients: is it safe? Am J Emerg Med 29: 541, 2011. [PubMed: 20825829]
222. Jacques KG, Dewar A, Gray A, Kerslake D, Leal A, Lees F: Procedural sedation and analgesia in a large UK emergency department: factors associated with complications. Emerg Med J 28: 1036, 2011. [PubMed: 21109703]
223. Taylor DM, Bell A, Holdgate A, et al: Risk factors for sedation­related events during procedural sedation in the emergency department. Emerg
Med Australas. 23: 466, 2011. [PubMed: 21824314]
224. Holdgate A, Taylor DM, Bell A, et al: Factors associated with failure to successfully complete a procedure during emergency department sedation.
Emerg Med Australas 23: 474, 2011. [PubMed: 21824315]
225. http://rebelem.com/complications­of­procedural­sedation/. (Rezaie S: Complications of procedural sedation. REBEL EM. Published 2016.)
Accessed September , 2019. 226. Williams MR, Ward DS, Carlson D, et al: Evaluating patient­centered outcomes in clinical trials of procedural sedation, part  efficacy. Anesth
Analg 124: 821, 2016. [PubMed: 27622720]
227. Ward DS, Williams MR, Berkenbosch JW, et al: Evaluating patient­centered outcomes in clinical trials of procedural sedation, part  safety: sedation consortium on endpoints and procedures for treatment, education, and research recommendations. Anesth Analg 127: 1146, 2018. [PubMed: 29782404]
228. http://www.emdocs.net/top­10­errors­of­procedural­sedation­in­the­emergency­department/. (Vetter N, Sturm J: Emergency Medicine
Education 10: procedural sedation errors in the emergency department.) Accessed April , 2019. 229. https://lifeinthefastlane.com/procedural­sedation/. (Rothwell S, Dodds M: Procedural sedation. Life in the Fast Lane. Medical Blog.) Accessed
April , 2019.

