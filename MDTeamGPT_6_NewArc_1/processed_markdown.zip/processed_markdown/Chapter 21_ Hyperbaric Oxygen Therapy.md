University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 21: Hyperbaric Oxygen Therapy
Tracy Leigh LeGros; Heather Murphy­Lavoie
INTRODUCTION
Hyperbaric oxygen (HBO) therapy is a medical intervention in which a patient breathes continuous or intermittent 100% oxygen while inside a
 hyperbaric chamber that is pressurized to an ambient pressure greater than sea level. HBO therapy results in the systemic delivery of oxygen that produces supraphysiologic oxygen tension in perfused tissues. The effects of HBO therapy are due to the combined effects of both increased ambient
 pressure and increased oxygen tension.
Monoplace chambers accommodate a single occupant. An attendant monitors the patient from the outside and communicates via intercom. Specially designed cardiopulmonary monitoring devices, IV infusion pumps, and ventilators enable critically ill patients to be treated in monoplace chambers.
Multiplace chambers (Figure 21­1) can simultaneously treat multiple patients and will accommodate medical personnel inside the chamber to perform hands­on patient assessment and care. Monoplace chambers generally use 100% oxygen for pressurization, whereas multiplace units are pressurized with air and patients breathe oxygen using a tight­fitting facemask, a hood, or an endotracheal tube while inside.
FIGURE 21­1. The outer and inner configurations of a multiplace hyperbaric chamber at the University of Pennsylvania Department of Hyperbaric Medicine,
Philadelphia, Pennsylvania.
Ambient pressure is an important concept in HBO therapy. At sea level, the pressure exerted by the air column (the atmosphere) above is quantified as
 atmosphere absolute of pressure (ATA), 760 mm Hg, 760 torr, or 101 kPa. Once a patient is placed inside a chamber, the ambient pressure is increased by the gradual inflow of compressed gas, either oxygen or air. Most HBO therapy uses pressures between .0 and .0 ATA (202 to 303 kPa). A typical HBO treatment lasts  to 120 minutes. HBO therapies are performed using preset protocols that define pressurization level, treatment duration, use of air breaks, and the number of HBO sessions in a course of therapy.
The oxygen content of the blood is the sum of the oxygen carried by hemoglobin and oxygen dissolved in the plasma. Hemoglobin becomes fully saturated around a PO of 100 mm Hg (13.3 kPa); fully saturated hemoglobin carries approximately  mL of oxygen per 100 mL of blood, which is
 expressed as  vol%. At  ATA breathing room air, dissolved oxygen in the plasma is typically only .3 vol%. At a pressure of  ATA inside an HBO chamber pressurized with 100% oxygen, the arterial oxygen tension (PaO ) will approach 2200 mm Hg (293 kPa), which will bring the dissolved oxygen

 content up to about .4 vol%. This amount of dissolved oxygen can sustain basal metabolic functions in the complete absence of hemoglobin.
PHYSIOLOGIC EFFECTS
HBO therapy should be viewed as a drug and the hyperbaric chamber as a delivery device. HBO affects tissues in two ways: there are effects related to
 mechanical forces of increased pressure and effects due to hyperoxygenation. Of the two, elevated tissue oxygen tension is thought to be the primary
Chapter 21: Hyperbaric Oxygen Therapy, Tracy Leigh LeGros; Heather Murphy­Lavoie effect. Hyperoxygenation reverses tissue ischemia, but also induces the formation of reactive oxygen species, including superoxide, hydrogen
. Terms of Use * Privacy Policy * Notice * Accessibility peroxide, hypochlorous acid, hydroxyl, and reactive nitrogen species (primarily nitric oxide). This stimulates the body’s natural antioxidant defenses,
 strongly mobilizing the antioxidant enzyme system and thus improving defense from oxidative damage. Highly elevated oxygen levels generated
 during HBO therapy have therapeutic beneficial effects seen after tissue oxygen levels return to normal (Table 21­1). Reactive oxygen species are natural by­products of metabolism that can oxidize proteins and membrane lipids, damage DNA, and mediate tissue and organ damage seen in oxygen toxicity. The body has scavenger antioxidant systems to reverse the oxidative damage caused by reactive oxygen species generated during HBO therapy
,5
(making oxygen toxicity rare) and that continue to protect the body against oxidative stress upon completion of HBO therapy.
TABLE 21­1
Beneficial Effects of Hyperbaric Oxygen Therapy
Provides hyperoxygenation: reverses tissue ischemia
Limits toxin production: inhibits microbial endotoxin and exotoxin production
Bacteriostatic and bactericidal: to obligate anaerobic microorganisms
Reduces tissue edema: induces vasoconstriction­mediated reductions of inflow without reducing outflow in posttraumatic tissue beds
Stimulates angiogenesis: promotes production of oxygen­dependent collagen matrix, increases wound growth factors synthesis, and mobilizes stem/progenitor cells from bone marrow
Promotes osteogenesis: in hypoxic bone by providing osteoblast simulation and bone tissue regeneration
Promotes wound healing: by impairing B2 integrin function and the amplifying oxygen gradients surrounding ischemic wounds
Diminishes inflammatory responses: by lowering monocyte chemokine synthesis and ischemic preconditioning changes in heme oxygenase­1, heat shock proteins, and hypoxia­inducible factor
Augments fibroblast replication: increasing collagen formation
Blunts ischemia­reperfusion injury: to endothelial tissue
Increases red blood cell flexibility: facilitating increases in elastic deformation
Enhances leukocyte bactericidal activity: improves neutrophil oxygen­dependent peroxidase bactericidal activity
Enhances antibiotic transport: increases antibiotic penetration into target bacteria
Preserves intracellular adenosine triphosphate: supporting intracellular functions
Terminates lipid peroxidation: obviating tissue destruction
INDICATIONS
The Undersea and Hyperbaric Medical Society has defined clinical indications for HBO therapy, some of which are within the scope of emergency
 medicine practice (Table 21­2).
TABLE 21­2
Indications for Hyperbaric Oxygen Therapy
Acute ischemic events Gas toxicities
Arterial gas embolism Carbon monoxide poisoning
Decompression sickness Cyanide poisoning
Central retinal artery occlusion Infections
Sensorineural hearing loss Clostridial myonecrosis (gas gangrene)
Select problem wounds* Necrotizing soft tissue infections
Exceptional blood loss anemia Intracranial abscess* Traumatic injuries Refractory osteomyelitis* Crush injury and compartment syndrome Radiation injuries* Other acute ischemias Osteoradionecrosis
Acute thermal burns Soft tissue radionecrosis
Compromised grafts and flaps* *These usual nonemergent indications for hyperbaric oxygen therapy are not discussed in detail.
AIR OR GAS EMBOLISM
 7­10
Air or gas embolism can occur as a consequence of a deep­sea dive–related accident or as the result of a medical procedure (Table 21­3), including emergent or urgent procedures performed within the ED. Diving accidents are discussed in Chapter 214, “Diving Disorders,” and this chapter will focus primarily on iatrogenic embolism. Air or gas embolism can occur either on the venous or arterial side of the circulatory system.
TABLE 21­3
Iatrogenic Air or Gas Embolism
Emergency Department Procedures Surgical Procedures
Mechanical ventilation Cardiac surgery Hip replacement
Chest tube placement Bronchoscopy Arthroscopy
Cardiopulmonary resuscitation GI endoscopy Spine surgery
Lumbar puncture Laparoscopy Neurosurgery in sitting position
Arterial or central line insertion/removal Hysteroscopy Endoscopic vein harvesting
Penetrating chest trauma Cesarean section Vitrectomy
Contrast mechanical injection Prostatectomy Liver resection or transplantation
Hemodialysis/dialysis catheter placement Transurethral surgery Percutaneous organ puncture
,10
Venous gas embolism can occur after surgical procedures. The amount of gas is typically small, and the air bubbles trapped in the pulmonary capillaries are resorbed without symptoms. Large quantities of gas in the pulmonary vasculature can stimulate cough, dyspnea, and pulmonary edema and, in severe cases, cause vapor lock. A paradoxical arterial gas embolism may develop when a venous gas embolism travels to the arterial system

(right to left shunt) by way of an intrapulmonary shunt or through an atrial septal defect or a patent foramen ovale.
The consequences of an arterial gas embolism depend on location and magnitude of arterial occlusion. Arterial gas embolism is a potentially
 catastrophic event with a reported mortality rate of 20%. Skeletal muscle, connective tissue, and skin can often tolerate small emboli, but air entering the coronary, cerebral, or spinal circulation can precipitate acute coronary syndrome, stroke, or paralysis, respectively. The introduction of
 intravascular sheaths, such as at the start of an interventional radiologic procedure, accounts for the greatest proportion of iatrogenic gas embolism.
When suspected, administer supplemental oxygen to support arterial oxygenation and hasten bubble resorption. Place the patient in the supine position; there is no proven benefit to a head­down position to lower the risk of additional cerebral air embolization or a left lateral decubitus position to trap gas within the apex of the right ventricle and minimize migration. Catheter aspiration of trapped air may be attempted in those rare instances
 when it is visualized and a preexisting catheter is in place; de novo placement of a vascular catheter to attempt air aspiration is controversial.

HBO is definitive treatment for arterial gas embolism and is recommended when there is neurologic or cardiovascular impairment. Start treatment as
13­15 soon as possible, but there is evidence of improved outcomes out to  hours or longer. The most common protocol used is the U.S. Navy
Treatment Table , which begins at .8 ATA, with a subsequent decompression to .8 ATA (total treatment time of 285 minutes). For patients whose symptoms are not improved or worsen, the U.S. Navy Treatment Table 6A (initial pressurization up to  ATA in a multiplace chamber) may be considered. For patients with residual symptoms after the initial HBO treatment, additional treatments are recommended until there is no further
 neurologic improvement.
DECOMPRESSION SICKNESS
Decompression sickness is due to the formation of nitrogen bubbles in body tissue and circulation during decompression (see Chapter 214, “Diving
Disorders”). These bubbles cause direct mechanical disruption of tissue, occlusion of blood flow, platelet deposition and activation of the coagulation
 cascade, endothelial dysfunction, capillary leakage, endothelial cell death, complement activation, and leukocyte­endothelial interaction.
HBO treatment is the definitive treatment for decompression sickness and recommended in all cases of diving decompression sickness. If HBO therapy is not available, patients with mild symptoms who are stable for longer than  hours may be treated with supplemental oxygen alone. If a patient must be transported by air to a hyperbaric facility, use pressurized aircraft to maintain sea­level pressure or transport at the lowest possible altitude in a nonpressurized craft, such as a helicopter.

A variety of HBO regimens are used to treat decompression sickness, but most centers use the U.S. Navy Treatment Table  and most patients with decompression sickness who receive rapid HBO therapy will respond to a single treatment. The U.S. Navy Treatment Table  may be used in patients with residual symptoms.
CENTRAL RETINAL ARTERY OCCLUSION
Central retinal artery occlusion is rare, usually presenting as painless vision loss in one eye; without treatment, vision loss can be permanent. Poor outcomes occur because the occlusion is often the result of a cholesterol embolus that is not treatable with thrombolysis. HBO therapy produces a
 clinically significant visual improvement especially when instituted within  hours of onset. There are no other central retinal artery occlusion
,20 therapies with similar outcomes.
Adjunctive therapies (i.e., supplemental oxygen and lowering intraocular pressure) are recommended until HBO can be initiated. The HBO central retinal artery occlusion protocol is .0 ATA for  minutes. If vision improves, the patient is treated for a total of  minutes. Treatments are done twice daily and continued until there is no visual improvement for  consecutive days. If vision does not improve at .0 ATA for  minutes, the pressure is
 raised to .4 to .8 ATA (titrating to effect with at­depth visual acuities) for a total of  minutes with air breaks. If there is no improvement after eight treatments, visual recovery is unlikely.
SUDDEN SENSORINEURAL HEARING LOSS
Sudden sensorineural hearing loss is hearing loss of at least  dB occurring over  days involving at least three contiguous auditory
 frequencies. The usual presentation is of a patient awaking from sleep with a sudden unilateral hearing loss, aural fullness, and at times tinnitus and vertigo. The cause is unclear, and many mechanisms have been described, including ischemia, trauma, toxins, vascular occlusion, viral infections,
 immune­associated disease, abnormal tissue growth, and labyrinthine and/or cochlear membrane damage.
HBO therapy is effective primarily by achieving extremely high arterial perilymphatic oxygen concentrations. In combination with steroids, HBO therapy
,23 produces hearing gains over all frequencies.

HBO therapy is indicated for profound sudden sensorineural hearing loss (>40 dB) within  days of symptom onset. Patients with longer delays in presentation may benefit; the American Academy of Otolaryngology–Head and Neck Surgery advocates HBO therapy for up to  months after symptom
 onset. It is essential that both corticosteroids (e.g., prednisone,  milligrams, orally, daily for  to  days and then tapered over  to  weeks) and

HBO therapy (e.g., 100% oxygen at .0 to .5 ATA for  minutes daily for  to  sessions) be used together.
EXCEPTIONAL BLOOD LOSS ANEMIA
In cases of acute severe anemia where transfusion cannot be used to improve oxygen content to sustainable levels (e.g., Jehovah’s Witness, Rh
 incompatibility/transfusion reactions, patient refusal), HBO aids in sustaining life. The benefits of HBO include rectifying the oxygen debt, providing a bridge that corrects end­organ damage, and allowing time for the patient’s endogenous erythropoietin levels and baseline hemoglobin to rise. The
HBO treatment protocol is 100% oxygen at .5 to .0 ATA for  to  hours (with air breaks) up to four times daily to raise PaO in plasma to meet

27­30 metabolic needs until red blood cell concentration improves. Both animal studies and human clinical experience support the use of HBO for severe
 blood loss anemia.
CRUSH INJURIES
Crush injuries damage multiple tissues, creating a cycle of edema and ischemia. Approximately half of patients with severe injuries develop complications such as osteomyelitis, fracture nonunions, amputations, and failed flaps despite optimal surgical and medical care. HBO treatment is
 effective in reducing complications and promoting healing in such patients. The HBO protocol for crush injuries is .4 ATA for 100 minutes three
 times daily for  days, and then twice daily for  days, followed by once­daily sessions for  days.
COMPARTMENT SYNDROME
Standard therapy for compartment syndrome is a fasciotomy to decompress the compartment and reverse ischemia of enclosed muscles and nerves. Fasciotomy itself has associated complications, and in the situation of impending compartment syndrome, HBO can improve oxygenation to
34­36 hypoperfused tissues, promote arterial hyperoxia, decease vasoconstriction and edema, and prevent progression requiring fasciotomy. After fasciotomy for established compartment syndrome, HBO can prevent wound healing complications and accelerate recovery. Approximately three to
 five HBO treatments are usually required.
OTHER ACUTE TRAUMATIC ISCHEMIAS
HBO therapy has been reported to be beneficial in other acute traumas that involve a self­perpetuating cycle of accelerating tissue damage from edema
,38  ,40 41­43 and ischemia, such as frostbite injuries ; threatened grafts and flaps ; in­jeopardy digit amputations or replantations ; ear amputations ;
,45 46­49  nose amputations ; penis injuries and amputations and postsurgical penile gangrene ; snake envenomation ; high­pressure water gun
  injection ; and electrical injury complications. HBO therapy is a noninvasive, economically advantageous, and clinically efficacious adjunctive therapy to consider when complications or poor outcomes are likely despite appropriate surgical and medical care.
ACUTE THERMAL BURN INJURY
Animal models have shown significant benefits of HBO for thermal burns, including reducing partial­ and full­thickness skin loss, hastening
 54­56 epithelialization, and lowering mortality. Although some uncontrolled series have reported mixed results, many clinical trials have reported
,58 59­61 ,59,62 ,60,62 ,59 significant improvement in healing, decreased length of stay, decreased mortality, reduced cost of care, improved morbidity,
,62,63 ,63,65 decreased fluid requirements (30% to 35%), and decreased surgical procedures. Overall, in clinical trials, HBO showed benefit in  or 
 studies. The HBO protocol for the treatment of thermal burns is .4 ATA for 100 minutes with two air breaks. Treatments begin three times daily and
 then decrease to twice daily and then once daily as healing occurs.
CARBON MONOXIDE POISONING
Carbon monoxide toxicity develops from impairment of hemoglobin function and direct carbon monoxide–mediated cellular damage that poisons the electron transport chain and inhibits adenosine triphosphate formation (see Chapter 222, “Carbon Monoxide”). After removal from continued carbon monoxide exposure, the carbon monoxide slowly dissociates from the hemoglobin and the electron transport chain and is metabolized or exhaled. Treatment with HBO enhances elimination of carbon monoxide from the body.
,67
Professional hyperbaric medicine organizations recommend HBO treatment for appropriate carbon monoxide–poisoned patients. Two HBO protocols have been studied for carbon monoxide poisoning. The Salt Lake City protocol uses  ATA for  minutes, with two air breaks, followed by a
  reduction to  ATA for  minutes with one air break. Two additional treatments are given in 6­ to 12­hour intervals. The Philadelphia protocol uses
 a single treatment at .8 ATA for  minutes followed by .0 ATA for  minutes.
CYANIDE POISONING
Concomitant cyanide and carbon monoxide poisoning may be seen in patients rescued from closed­space fires in which synthetic materials are
70­72 burned. Experimental evidence suggests that cyanide and carbon monoxide can produce synergistic toxicity. HBO may directly reduce cyanide
,74  toxicity and/or augment other antidote treatments. However, clinical experience with HBO for pure cyanide toxicity is sparse, and there are no
75­80 controlled trials. Cyanide is among the most lethal poisons, and toxicity is rapid, so standard antidotal therapy for isolated cyanide poisoning is of primary importance (see Chapter 204, “Industrial Toxins”). HBO can be considered in case of dual carbon monoxide and cyanide poisoning and in cyanide poisoning when vital signs and mental status do not improve with antidote treatment.
NECROTIZING SOFT TISSUE INFECTIONS
Necrotizing soft tissue infections, including necrotizing fasciitis and Fournier’s gangrene, are rapidly spreading, deep, typically mixed infections that result in profound morbidity and mortality (see Chapter 152, “Soft Tissue Infections”). Over the past  years, advances in surgical technique and antibiotic therapy and a higher index of suspicion regarding presentations and at­risk populations have improved survival.
HBO is a valuable adjunct to surgical debridement and antibiotic therapy in necrotizing soft tissue infections, reducing mortality, improving recovery
81­90 rates, and decreasing both amputation rates and the number of required surgical interventions. HBO is beneficial due to its ability to suppress growth of anaerobic microorganisms, improve bactericidal action of leukocytes that function poorly in hypoxic conditions, and enhance antibiotic
91­94 penetration into target bacteria. The HBO protocol for necrotizing soft tissue infections is twice­daily treatments at .0 to .5 ATA for  minutes
 with two air breaks until the extension of the necrosis is halted, and then daily until the infection is well controlled, for up to  sessions.
CLOSTRIDIAL MYONECROSIS (GAS GANGRENE)
Gas gangrene is an acute, rapidly progressing clostridial infection of muscle tissue characterized by profound toxemia, edema, tissue death, and
 variable gas production. The induction of gas gangrene requires only the presence of clostridial spores and a region of lowered oxidation reduction
 potential caused by local circulatory failure or extensive soft tissue damage and muscle necrosis. Under the conditions of low oxygen tension, the
 clostridial spores can develop into the vegetative form.
97­99
The pathogenesis of gas gangrene involves the production of clostridial exotoxins, of which more than  have been identified. Alpha toxin is the
 most prevalent exotoxin and causes platelet and leukocyte destruction, widespread capillary damage, hemolysis, tissue necrosis, and often death.
Alpha toxin can be detoxified within hours after its elaboration, with natural host defenses conferring active immunity with production of a specific
,100  antitoxin. However, death often occurs because the infection is so rapidly progressive that the patient dies before immunity can develop.
101­103
The primary benefit of HBO therapy for gas gangrene is that inducing an oxygen tension of 250 to 300 mm Hg (33.3 to  kPa), achieved at .0 ATA,
104 halts alpha­toxin production, inhibits clostridial growth, and allows normal host factors to swiftly detoxify the patient so that a moribund patient can
,104­110 rapidly be made nontoxic.
111­113
The addition of HBO to standard treatment for gas gangrene shows consistently beneficial results, with survival rates between .9% and 81%
111,114­117 and limb salvage rates between 80% and 82% (compared to 40% to 50% with primary surgery). Results decline progressively when HBO is delayed.
Treatment begins with an index of suspicion and a positive gram­stained smear of the wound fluid revealing gram­positive rods and a paucity of leukocytes. Although treatment with gas gangrene involves a three­pronged approach—antibiotics, surgery, and HBO—the initial surgery can be restricted to opening of the wound or an initial fasciotomy, followed by immediate HBO therapy. Lengthy and extensive procedures in gravely ill patients may be deferred, with necrotic tissue debridement performed between HBO sessions when a clear demarcation between dead and viable
 tissues is appreciated. The HBO protocol for treatment of gas gangrene is .0 ATA for  minutes three times a day in the first  hours and then twice
115,118 daily for the next  to  days. In several series, no mortality has been shown after the third HBO session (end of day 1).
COMPLICATIONS OF HBO THERAPY
BAROTRAUMA

Middle ear barotrauma is the most common adverse effect of HBO treatment. As the ambient pressure within the hyperbaric chamber increases, a patient must be able to equalize the pressure within the middle ear by autoinsufflation or else ear pain, tympanic hemorrhage, serous effusion, or rupture will develop. Standard protocols include instruction on autoinsufflation techniques and medical therapy when needed. When these interventions fail, tympanostomy tubes must be placed in order for HBO therapy to continue. The reported overall incidence of aural barotrauma is
120,121 122 between .2% and 7% of patients who undergo HBO therapy. One series reported a 4% incidence of tympanostomy tube placement.
Pulmonary barotrauma during HBO treatment is extremely rare but should be suspected when significant chest or hemodynamic symptoms occur during, or shortly after, decompression. If symptoms develop and the patient is in a multiplace chamber, stop decompression and evaluate for pneumothorax. If the patient is in a monoplace chamber, slowly decompress and provide supplemental oxygen upon returning to ambient pressure.
OXYGEN TOXICITY
Biochemical oxygen toxicity can injure the brain, lungs, and eyes. Acute oxygen toxicity manifests as a grand mal seizure, reported to occur
120,123­125 approximately one to four times per ,000 patient treatments. The risk of seizure is higher in hypercapnic patients and possibly those who are acidotic or septic. Seizures are managed by reducing the inspired oxygen tension while leaving the patient at the same pressure (to avoid pulmonary overexpansion injury when a patient is in tonic convulsion phase). Chronic oxygen toxicity can impair lung mechanics (elasticity), vital
126 127­129 capacity, and gas exchange. These changes are typically observed only when treatment duration and pressures exceed typical HBO protocols.
Progressive myopia has been reported in patients who undergo prolonged daily therapy and typically reverses within  weeks after stopping HBO
130 therapy. There is a risk for nuclear cataract development, typically when treatments exceed a total of 150 to 200 hours, but they may arise with less
131,132 provocative exposures. Current evidence does not indicate that typical HBO protocols have detrimental effects on neonates or the unborn
133 fetus.
MISCELLANEOUS COMPLICATIONS
Confinement anxiety may occur and is typically managed with sedating agents. Any environment with an elevated concentration of oxygen presents a
134 risk for fire. Scrupulous avoidance of an ignition source is standard in HBO therapy programs.


