## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 135: Urinary Tract Infection in Infants and Children
Benetta Chin; Sim Grewal
INTRODUCTION AND EPIDEMIOLOGY
Pediatric urinary tract infections (UTIs) are now the most common serious bacterial infections in young children since the introduction of successful immunizations and the resultant decrease in pediatric sepsis, meningitis, and occult bacteremia. UTI should be considered as a possible diagnosis in all febrile infants and young children presenting to EDs and in all older children with abdominal or urinary symptoms whether or not there is fever.
Estimates of UTI prevalence are highly variable depending on the population. Pediatric UTI occurs in up to 8% of febrile children presenting to the ED
1­3  with no obvious source of infection. Approximately 1% of boys and 3% of girls are diagnosed with a UTI before puberty. The highest incidence
 ,2,5­11 occurs during the first year of life for both genders. Some of the baseline characteristics that increase the risk of UTI are listed in Table 135­1. It
 is unclear why African American children have a lower risk of UTI, but this difference is consistently noted.
TABLE 135­1
Risk Factors for Pediatric Urinary Tract Infection (UTI)
Factor Risk
Gender  times higher risk in females
Age Variably increased risk in infants and younger children
Circumcision status 4–20 times higher risk in uncircumcised males
Race/ethnicity Half the risk in African American children compared with nonblack children
Fever Increased risk with fever >39°C (102.2°F) for both boys and girls, and with fever duration >24 h in boys or >48 h in girls
History of UTI 2­fold increased risk
Genital sexual activity Increased risk
Previous urinary tract infection Increased risk
PATHOPHYSIOLOGY
Bacteria most commonly cause UTIs, although viruses and other infectious agents can also be urinary pathogens. The vast majority of UTIs in all age groups typically occur from retrograde contamination of the lower urinary tract with organisms from the perineum and periurethral area. In neonates, however, UTIs typically develop after seeding of the renal parenchyma from hematogenous spread.
Escherichia coli is the most common cause of UTI in children, and this is likely because of its ubiquitous presence in stool combined with bacterial
 virulence factors that improve adhesion to and ascent of the urethra. Additional pathogens include Klebsiella, Proteus, and Enterobacter species.

Enterococcus species, Staphylococcus aureus, and group B streptococci are the most common gram­positive organisms and are more common in
Chapter 135: Urinary Tract Infection in Infants and Children, Benetta Chin; Sim Grewal neonates. Staphylococcus saprophyticus can cause UTI in adolescents, and Chlamydia trachomatis may be present in adolescents with urinary tract
. Terms of Use * Privacy Policy * Notice * Accessibility symptoms and microhematuria. Adenovirus may cause culture­negative acute cystitis in young boys.
Mechanical defenses in humans, such as normal urinary outflow, clear most bacteria that are introduced into the bladder. Anatomic abnormalities can make bacterial proliferation or persistence in the bladder more likely. Additional factors influencing the development of UTI include virulence of the pathogen, vesicoureteral reflux, urolithiasis, poor hygiene, voluntary urinary retention, and abnormal bladder function due to constipation. There are occasionally patients, usually preschool­ or school­aged females, who have recurrent UTI without a clear anatomic abnormality or identifiable risk
 factors. Genetic investigation may allow identification of these at­risk individuals. Rare causes of UTI in children include indwelling urinary catheters or UTI from embolism or secondary to infection of other body areas.
CLINICAL FEATURES
HISTORY AND COMORBIDITIES
Clinical features vary markedly by age. Focus the initial history on the acute illness, including the presence of fever, vomiting, or abdominal or back pain, and identify symptoms that may suggest another source of fever such as rhinorrhea, cough, or diarrhea. Neonates with UTIs may appear septic,
 with fever, jaundice, poor feeding, irritability, and lethargy. In young infants, fever may be the only sign of UTI, while older infants and young children typically develop GI complaints, with fever, abdominal pain, vomiting, and a change in appetite. GU symptoms in a verbal child should always trigger consideration of a UTI. In school­aged children and adolescents, cystitis and urethritis (lower tract disease) typically present with urinary frequency, urgency, hesitancy, and dysuria, although abdominal pain, back pain, and new­onset urinary incontinence are also associated with UTI in this age group. Pyelonephritis (upper tract disease) typically presents with fever, chills, back pain, vomiting, and dehydration. A parental report of “smelly”
 urine does not appear to be helpful. In nonverbal children, a history of high (>39°C [102.2°F]) or prolonged fever appears to be one of
  the most predictive symptoms of UTI. Recently, a risk calculator, UTICalc (https://uticalc.pitt.edu/), was developed and validated to estimate the pretest probability of a UTI based on variables in the clinical history of a child suspected to have a UTI. These variables include the age, sex, and race of the patient; the height of the temperature; and whether another source for the fever exists. The tool then incorporates the results of urine testing and provides guidance to treatment by giving a posttest probability of a UTI.
Ask about past medical history including whether a late­term prenatal US was obtained because a normal late­term US decreases the likelihood of some GU abnormalities that increase the risk of UTI. Identify additional predisposing factors including chronic constipation, dysfunctional voiding, known vesiculoureteral reflux, previous UTIs, and sexual activity in adolescents.
PHYSICAL EXAMINATION
Assess the child’s health and degree of acute illness. If the child is lethargic, dehydrated, or in respiratory distress, then institute appropriate therapy.
Examine the genitalia for anatomic abnormalities (e.g., labial adhesions, phimosis) or other causes of GU symptoms. Note circumcision status in male
 infants. Perform a careful abdominal and groin examination to evaluate for suprapubic tenderness, costovertebral angle tenderness, hernias, and any abnormal masses. A complete physical examination helps to exclude other causes of illness. Although the presence of another source of fever lowers the risk of UTI, it does not eliminate it, and UTI can coexist with common viral syndromes such as respiratory syncytial
,16,17 virus bronchiolitis.
DIAGNOSIS AND DIFFERENTIAL DIAGNOSIS
In infants and young children, the only cardinal feature of UTI is a febrile illness without another definitive source. UTI is a possible diagnosis in all infants with fever. In children with dysuria but no fever, the most common concerns are listed in Table 135­2. TABLE 135­2
Causes of Culture­Negative Dysuria and Pyuria in Children
Culture­Negative Dysuria
Viral urethritis/cystitis
May be hemorrhagic in some viral infections such as adenovirus
Meatitis/urethritis
Often in young boys due to irritation from clothes or self­stimulation
Can be from vaginitis in the vaginal vault in girls. The common causes of vaginitis in young girls include irritant vaginitis from poor hygiene and residual urine that is persistently not cleaned after voiding or irritant vaginitis from soaps or other chemicals. Occasionally, premenarchal girls have bacterial vaginitis. Candidal vaginitis generally does not occur in prepubertal girls.
Balanitis
Culture­Negative Pyuria
Kawasaki’s disease (from urethritis)
Pelvic abscess or infection
Appendicitis, pelvic inflammatory disease, colitis, etc.
Sexually transmitted infections (e.g., Chlamydia, gonorrhea*)
In sexually active adolescents, strongly consider these if there is pyuria with a negative culture.
Intrinsic renal disease (e.g., glomerulonephritis)
Allergic bladder or renal disease (e.g., interstitial nephritis)
*Sexually transmitted infection can cause both dysuria and pyuria.
The approach to neonates and infants <3 months of age with fever and no identifiable source is discussed in detail in Chapter 119, “Fever and Serious
Bacterial Illness in Infants and Children.” Urine testing (including microscopy and culture) is an important part of a more comprehensive evaluation in this age group. As mentioned earlier, UTI should be considered in infants with bronchiolitis, particularly in the presence of high fever (temperature of
,18
39°C [102.2°F]). In verbal children, dysuria combined with suprapubic tenderness on examination is the classic constellation of symptoms and signs suggestive of cystitis.

There are no clinical criteria that confirm the diagnosis of UTI in children without urinary testing and culture. Evidence­based clinical practice guidelines for the evaluation and treatment of pediatric UTI from the American Academy of Pediatrics are limited to infants and young children  to  months of age and require both pyuria and bacteriuria with ≥50,000 colonies/mL of a single uropathogenic organism for definitive diagnosis of a UTI. 
Positive urine cultures in the absence of pyuria/bacteriuria may represent asymptomatic bacteriuria. For infants <2 months old, a positive urine culture is the gold standard for diagnosis.
In adolescents, symptoms of dysuria without vaginal or urethral discharge, or an examination consistent with UTI or pyelonephritis, such as suprapubic or costovertebral angle tenderness, in the presence of a positive urine chemical strip for pyuria and/or nitrites, allow a presumptive diagnosis of UTI. A careful sexual history is important in this age group, because urethral symptoms (such as dysuria) may predominate in both UTI and sexually transmitted infections. Urine culture remains important for definitive diagnosis, and pyuria without uropathogenic culture growth may suggest sexually transmitted infection. Consider pelvic examination for sexually active girls and appropriate testing in both boys and girls with dysuria who are sexually active (see Chapter 153, “Sexually Transmitted Diseases”).
LABORATORY EVALUATION
Urine Sample Collection
If children can void on command, then collection of clean catch urine is appropriate. Perineal cleaning before voiding and midstream collection reduce
 the rate of false­positive urinary dipstick tests and the rate of contaminated culture results.
In infants and children who are not able to void on command, bladder catheterization is the preferred method for urine collection. Suprapubic aspiration, although invasive, is also acceptable. The value of perineal bag specimens is limited by the high false­positive results with a high likelihood of significant contamination with perineal bacterial flora. In infants, clean catch urine collection can be time consuming and unsuccessful. Methods such as the Quick­Wee method, using gentle suprapubic cutaneous stimulation with gauze soaked in cold fluid, have been shown to increase the
 speed and success of obtaining a clean catch urine. In infants, particularly if less than  days old, using a stimulation technique involving gentle
 tapping over the suprapubic area and lumbar paravertebral massage has also been shown to be effective. The only (rare) circumstance where a perineal bag specimen may be used is to exclude disease when the pretest probability of UTI is very low, in which case a negative test rules out disease; if the results are positive, confirmation before giving antibiotics requires culture of a specimen collected in a sterile manner. Due to this diagnostic delay, many clinicians prefer obtaining a definitive specimen initially.
Urine Culture
The definitive test for UTI is a urine culture, and colony counts indicating infection are based on the type of sample collection (Table 135­3).
Do not give antibiotics until a urine culture is obtained using a sterile method. Based on the clinical scenario, length of illness, and urinalysis results, lower colony counts or mixed­growth cultures cannot necessarily be dismissed.
TABLE 135­3
Urine Culture Results Indicating Urinary Tract Infection20
Sample Collection Positive Culture* Clean catch ≥50,000 cfu/mL
Catheterization ≥50,000 cfu/mL
Suprapubic catheterization Any single species bacterial growth if combined with acute symptoms or signs of urinary tract infection
Abbreviation: cfu = colony­forming unit.
*Urine culture results listed here should be considered indicative of urinary tract infection only in the setting of pyuria.
Rapid Urine Tests (Dipsticks or Urinalysis)
Urine culture results are not available at the first ED visit, so chemical test strips that can detect leukocyte esterase and urinary nitrites, in conjunction with microscopic urinalysis, help predict the results of the urine culture. Leukocyte esterase is an indirect measure of pyuria and can be negative if leukocytes are present in low concentration. Nitrite in the urine depends on coagulase­splitting bacteria that can reduce urinary nitrate to nitrite. A
 positive nitrite test makes UTI very likely (specificity 98%; range, 90% to 100%). Enterobacteria generally reduce nitrate to nitrite only if the urine has been in the bladder long enough (about  hours), but most gram­positive bacteria do not reduce nitrate to nitrite, so nitrite testing has insufficient
 sensitivity for detection of UTI (53%; range, 15% to 82%). Urinary nitrites and leukocyte esterase alone are not sensitive markers for children who empty their bladders frequently. Urine microscopy for leukocytes and bacteria, and/or Gram stain of unspun urine are also helpful for immediate diagnosis. Table 135­4 summarizes the test characteristics of the urinalysis.
TABLE 135­4
Characteristics of Urinary Diagnostic Tests, Alone and in Combination20
Test Characteristic Ranges
Sensitivity (%) Specificity (%) Test Result Likelihood Ratio* Individual Tests19
Leukocyte esterase 67–94 (83) 64–92 (78) + .8
− .2
Nitrite† 15–82 (53) 90–100 (98) + .5
− .5
Leukocytes on microscopy 32–100 (73) 45–98 (81) + .8
− .3
Bacteria on microscopy 16–99 (81) 11–100 (83) + .8
− .2
Combined19
Leukocyte esterase, nitrite or microscopy positive 99–100 (99.8) 60–92 (70) + .3
*Positive and negative likelihood ratio calculated from mean sensitivity and specificity.
†Test characteristics are for all subjects. However, test likely has no use if urine infection is due to gram­positive organism or if urine has not stayed in the bladder.
Regardless of the results from the rapid urine tests, send the sample for a urine culture. There are two situations where one might not send urine for culture: (1) in low­risk patients with a completely normal urinalysis and another explanation for the symptoms; and (2) in older adolescent females with a very high posttest probability of UTI, without severe illness or complicating medical problems, and in an area with a predictable antibiotic resistance pattern. Because pyuria alone does not confirm a UTI, refer to Table 135­2 for some causes of culture­negative pyuria.
Imaging
Acute imaging of the urinary tract is rarely necessary in UTI assessment or treatment. If children have persistent fever or are worsening despite appropriate therapy or symptoms are unusually severe, then renal US is indicated to rule out abscess, stone, or obstruction. Recommendations for renal and bladder US vary. The American Academy of Pediatrics recommends follow­up US for all children  to  months old after the first UTI, whereas the National Institute for Health and Care Excellence in the United Kingdom suggests US for those <6 months of age and those with recurrent
 ,25 or atypical UTI. Routine urethrocystography after first UTI is not recommended. Voiding cystourethrography is useful to identify and classify vesiculoureteral reflux and is indicated if renal­bladder US reveals hydronephrosis, scarring, or other findings that would suggest either high­grade vesicourethral reflux or obstructive uropathy. This testing can be arranged on an outpatient basis or is performed during hospitalization.
Other Suggested Testing
Testing beyond urinalysis and culture is not necessary for afebrile children with isolated UTI before initiating treatment. Children with atypical presentations or significant comorbidities may require further investigation as directed by the clinical picture. Febrile neonates and young infants (<2 months of age) require further evaluation prior to initiating antibiotics. Approximately 10% of young infants with febrile UTI admitted to the hospital
,27 demonstrate a sterile cerebrospinal fluid pleocytosis thought to be due to systemic release of inflammatory mediators. Less than 1% of febrile infants with UTI will also have bacterial meningitis. Perform lumbar puncture and obtain blood cultures in febrile neonates with UTI before starting empiric antibiotics (see Chapter 119). Lumbar puncture is not needed in febrile older infants and children with UTI unless there
 are signs or symptoms suggestive of meningitis or if the child is clinically ill or the illness does not respond to treatment.
Most febrile infants with UTI have upper tract involvement, and laboratory tests are unlikely to differentiate those with bacteremia from those without
  bacteremia. About 5% to 10% of febrile infants with UTI have bacteremia. There is low risk of bacteremia and adverse events in well­appearing
,30,31 infants and children with febrile UTI, and blood cultures are not necessary in these children who are candidates for oral outpatient therapy.
TREATMENT
Obtain a urine culture before giving antibiotics in stable infants and children as typical choices for antibiotics quickly sterilize the
 urinary tract and make specific bacteriologic diagnosis difficult. Treatment and disposition depend on the age of the patient and severity of
,33 the illness. Most children can be treated orally. Goals of therapy are to reduce symptoms, eliminate the acute infection, prevent complications and septicemia, and decrease the risk of renal scarring. The odds of new renal scarring increase significantly if treatment is delayed  hours or more.
Renal scarring may be associated with adverse long­term outcomes such as hypertension, proteinuria, risk of preeclampsia in pregnant women, and renal insufficiency. Pyelonephritis can be demonstrated by renal scan in up to 61% of children <2 years old with febrile UTI, so children <2 years old
 with febrile UTI have presumptive pyelonephritis. Treatment guidelines for first UTIs are listed in Table 135­5. Table 135­6 lists suggested parenteral and oral antibiotics. For children with relapsing or recurrent UTI or with underlying GU anatomic abnormalities, treat according to culture and sensitivity reports.
TABLE 135­5
Treatment of First Urinary Tract Infection in Children With Normal GU Anatomy
Age Comment
<2 mo Hospital admission and IV antibiotics for 3–5 d followed by variable course of oral antibiotics for  d.
2–24 If toxic, admit to hospital and treat with IV antibiotics. If nontoxic, not vomiting, and well hydrated, treat with oral antibiotics (Table 135­6). An mo initial dose of ceftriaxone,  milligrams/kg in ED, can be considered. Ensure follow­up in 24–48 h.
>2 y Select an oral antibiotic from Table 135­6 based on local resistance patterns.
old Children >2 y old to age  y, treat for  d. Follow up in 2–3 d.
Adolescent girls (≥13 y old), option to treat for  d.
TABLE 135­6
Antibiotic Treatment of Pediatric UTI33,35
Parenteral Antibiotics
Antimicrobial Dosage in Normal Renal Function Neonatal Considerations
Ampicillin* 25–50 milligrams/kg per dose IV every  h (every  hours  milligrams/kg per dose IV every  hours for neonates for neonates <7 d old) up to  days of age
Gentamicin .5 milligrams/kg per dose IV given every 8h or .5  milligrams/kg per dose every  hours for neonates <7 milligrams/kg per dose IV every  hours days of age
 milligrams/kg per dose every  hours for neonates 7–
 days old
Ceftriaxone 50–75 milligrams/kg per dose IV every  h Contraindicated
Cefotaxime  milligrams/kg per dose IV every  h Ampicillin + Gentamicin preferred
Ceftazidime 50–75 milligrams/kg per dose IV every  h Ampicillin + Gentamicin preferred
Cefepime  milligrams/kg per dose IV every  h to a maximum of Ampicillin + Gentamicin preferred
1g per dose
Oral Antibiotics
Antimicrobial Dosage in Normal Renal Function Oral antibiotics not recommended for neonates and infants <2 months of age
Cephalexin  milligrams/kg per dose PO every  h, max 500 milligrams/dose
Cefdinir  milligrams/kg per dose PO every  h
Cefixime  milligrams/kg per dose PO on day one followed by  milligrams/kg every  h
Cefpodoxime  milligrams/kg per dose PO every  h
Cefibuten  milligrams/kg per dose PO every  h
Amoxicillin­clavulanate  milligrams/kg per dose PO every  h
Trimethoprim/Sulfamethoxazole  milligrams/kg PO every  hrs
*Ampicillin should be added to empiric treatment with another parenteral agent when enterococcal infection is suspected.
E. coli is the most common etiologic agent causing UTI, so antibiotics should be directed toward its eradication. Medications listed in Table 135­6 are generally acceptable, but emerging resistance is a continuing problem, and local sensitivities should guide antibiotic selection. Typical effective firstline agents to treat E. coli include cephalosporins, aminoglycosides, and extended­spectrum penicillins. Many strains of E. coli are now resistant to amoxicillin and trimethoprim­sulfamethoxazole, limiting the use of these two agents for empiric UTI treatment. A fluoroquinolone should be used in children only if sensitivities indicate that this is the sole effective agent. Agents that do not achieve therapeutic concentrations in the bloodstream, such as nalidixic acid or nitrofurantoin, should not be used for UTI in febrile children. Once culture results with sensitivities for the infection are known, antimicrobial therapy should be tailored and simplified, based on the actual bacteria isolated. Children with anatomic urinary tract abnormalities need individualized treatment.

Enterococcus faecalis is a gram­positive organism that can cause UTI in children approximately 5% of the time, and S.
saprophyticus can cause UTI in adolescents. When Enterococcus is suspected because of prior infections with that organism or gram­positive bacteria are identified on urine Gram stain, add ampicillin­amoxicillin or vancomycin to other therapy. The presence of Enterococcus increases the
 likelihood of an underlying urinary tract abnormality in a patient. S. saprophyticus is typically sensitive to standard treatments.
DISPOSITION AND FOLLOW­UP
Admit all neonates and infants <2 months of age as well as those who appear septic or have known immunodeficiency to the hospital for parenteral antibiotics. Infants and children over  months of age with uncomplicated UTI may be appropriate for outpatient care with oral antibiotics if they appear well, can tolerate oral medication, are not dehydrated, and are not immunocompromised. Outpatient IM or IV ceftriaxone (75 milligrams/kg) or gentamycin can be used as an alternative to hospitalization for patients who are unable to tolerate oral therapy but are otherwise nontoxic and well hydrated. Length of antimicrobial therapy should be  to  days with close pediatric follow­up to ensure appropriate antibiotic use and to consider the need for imaging. Adolescent girls (>13 years old) with UTI may be treated like adults with the option for a 3­day oral antibiotic regimen. Outpatient repeat urine testing as proof of cure is not routinely necessary or recommended.
Of note, after confirmation of a febrile UTI in infants, parents or guardians should be counseled to bring back their child (ideally within  hours) for future febrile illnesses to ensure prompt medical evaluation and treatment of possible recurrent UTI.
SPECIAL SITUATIONS
PEDIATRIC UTI WITH UROLITHIASIS
Although uncommon, urolithiasis occurs in children, and the incidence is increasing and may be associated with the increasing prevalence of
37­39 childhood obesity. Children with symptoms suggestive of urolithiasis (colicky abdominal or flank pain, often radiating to the groin, and gross or microscopic hematuria) require imaging to evaluate for the possibility of stones (see Chapter 133, “Acute Abdominal Pain in Infants and Children,” and
Chapter 137, “Renal Emergencies in Children”). While non–contrast­enhanced CT is the imaging modality of choice in adults, consideration of the
 potential long­term effects of radiation exposure must be weighed carefully, and renal US or MRI should be considered as alternatives. In the setting of fever, pyuria, and an obstructing stone, initial treatment should be parenteral with inpatient management and consultation with pediatric urology.
Additional urine studies may be obtained to identify predisposing factors and chemical composition of stones, which may guide future management.


