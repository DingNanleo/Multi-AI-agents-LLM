## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 105: Complications of Gynecologic Procedures
Nikki M. Binz
INTRODUCTION AND EPIDEMIOLOGY
Advancements in minimally invasive gynecologic surgical techniques, such as laparoscopy and hysteroscopy, have allowed more outpatient procedures for patients. Postoperative complications among inpatients are now commonly seen out of the hospital. The prevalence of all
 postoperative complications after gynecologic procedures is reported to be 9%, whereas .7% are considered major complications. Hysterectomy is the most common gynecologic surgical procedure performed in the United States, and although considered a safe operation, it results in
 complications in one of every two to six patients. The most common reasons for ED visits during the postoperative period after gynecologic procedures are pain, fever, and vaginal bleeding.
CLINICAL FEATURES
HISTORY
Patient risk factors for postoperative complications include age >80 years, medical comorbidities, dependent functional status, and obesity or
 unintentional weight loss. Key historical questions are listed in Table 105­1. The interval between surgery and the onset of symptoms is very
 important in determining the cause of symptoms. For example, postoperative fever is very common, occurring in about 40% of hysterectomy patients.
Most cases of early postoperative fevers (<24 hours) are not infectious but rather result from pulmonary atelectasis, hypersensitivity reactions to antibiotics, pyogenic reactions to tissue trauma, or hematoma formation. Fever occurring on postoperative days  to  may be due to a urinary tract infection. On postoperative days  to , consider venous thromboembolism, and ≥7 days after surgery, consider a surgical site infection. 
TABLE 105­1
Key Historical Questions to Assess Postoperative Complications
Surgical procedure performed
Route of procedure
Abdominal
Vaginal
Laparoscopic
Reason for procedure
Time of symptom onset
Proximity of symptom to the surgery
Complications already experienced
Other postsurgical history
Medications prescribed
PHYSICAL EXAMINATION
Examine all appropriate body systems. Do not assume that the complaint is gynecologic, and investigate other potential explanations of symptom.
PDooswtonploeardateidve  p0a2i5n­ a7n­1d 6te:4n dPe r Yneosusr cIPan i sb e1 3d6if.f1ic4u2lt.1 t5o9 a.s1s2e7ss. After laparoscopy, patients may have shoulder or upper abdominal pain because of
Chapter 105: Complications of Gynecologic Procedures, Nikki M. Binz carbon dioxide bubbles trapped between the liver and diaphragm after insufflation for the procedure, with 50% to 70% of patients still being affected
. Terms of Use * Privacy Policy * Notice * Accessibility

 hours after surgery. Postoperative pain and tenderness are concerning if associated with fever, nausea and vomiting, and a change in bowel sounds.
Examine the surgical wound and perform a pelvic examination, including both a sterile speculum and a bimanual examination. In patients undergoing fertility treatment, defer the pelvic examination until consulting with the gynecologist, due to the possibility of rupturing enlarged ovarian follicles. During sterile speculum examination, the cervix or vaginal cuff must be visualized. After vaginal hysterectomy, no special precautions are needed for a speculum examination. Note any evidence of bleeding, discharge, erythema, and cuff or labial cellulitis. After a vaginal or abdominal hysterectomy, record the presence of tenderness, masses, and an intact cuff. After hysteroscopy or dilatation and curettage, evaluate cervical motion, uterine, and adnexal tenderness. Perform a rectal examination to assess for tenderness, masses, or fecal impaction.
LABORATORY TESTING
Laboratory studies should be directed toward the patient’s complaints. A CBC with a manual differential count is almost always indicated. Obtain a serum β­human chorionic gonadotropin level for all women with childbearing potential. A clean­catch or catheterized urine specimen along with urine, blood, wound, and cervical (if present) cultures should be obtained if the patient is febrile. A complete chemistry panel may be necessary to evaluate hepatic and renal function.
Imaging is often necessary. A chest radiograph can confirm pneumonia or inappropriate air under the diaphragm. Air or insufflated carbon dioxide should be completely absorbed by the third postoperative day. Supine and erect abdominal series help confirm bowel obstruction.
Although pelvic sonogram is helpful for visualizing the pelvic structures, CT is the gold standard for diagnosing most postoperative abdominal
 complications, with a sensitivity and specificity of >90%. MRI may be indicated in the evaluation of septic pelvic thrombophlebitis.
COMPLICATIONS OF ENDOSCOPIC PROCEDURES
LAPAROSCOPY
Gynecologic laparoscopy is used for diagnosis and treatment. Indications for laparoscopy are listed in Table 105­2. Laparoscopy is almost always an ambulatory surgical procedure and is performed under general anesthesia with endotracheal intubation.
TABLE 105­2
Common Indications for Laparoscopy
Sterilization
Lysis of adhesions
Carbon dioxide laser ablation of endometriosis
Uterine surgery (including myomectomy)
Tubal surgeries (including salpingectomy)
Ovarian surgery (including oophorectomy and oophorocystectomy)
Paraovarian cyst excision
Hysterectomy
After cesarean section, abortion, cholecystectomy, and coronary angioplasty, surgical tubal sterilization is the next most common operation in the

United States, with over 600,000 procedures performed annually. When not performed postpartum with cesarean sections, the procedure is almost
 always performed laparoscopically. Laparoscopic hysterectomy is another common procedure, usually performed for abnormal uterine bleeding and
 fibroids.

Reported overall laparoscopic complication rates range from .2% to .3%. Major laparoscopic procedures are associated with a higher rate of
 complications compared with minor procedures (0.6% to 18% vs. .06% to .0%, respectively). Robotic­assisted laparoscopy is becoming more
 common in gynecologic procedures and may have even lower rates of complications than general laparoscopy (6.3% vs. .3%, respectively).
Both diagnostic and therapeutic gynecologic laparoscopy are accomplished by passing a rigid endoscope through a trocar that is inserted bluntly through a small infraumbilical incision into the abdominal cavity after a Veress needle has been used to insufflate the abdomen with carbon dioxide.
The pneumoperitoneum must be sufficient to displace the bowel and is maintained throughout the surgery. Additional trocars may be placed so that other accessories can be used during the surgery. The majority of complications occur during entry of these instruments.
All laparoscopic procedures entail the same potential complications (Table 105­3), but more complex surgeries carry considerably more risk.
TABLE 105­3
Major Complications Associated With Laparoscopy
Bowel injury
Thermal injury
Vascular injury
Urinary tract injuries
Incisional hernia
Wound dehiscence
,9
Bowel injury is uncommon (<1%), but may not be noted at the time of surgery. Patients with greater than expected pain after laparoscopy should be considered to have a bowel injury until proven otherwise. Signs and symptoms include abdominal pain and distention, fever, nausea, vomiting, and an elevated WBC count. Plain radiographs may show an ileus or free air under the diaphragm. Complications include peritonitis, abscess, enterocutaneous fistula, and septic shock. There are three major types of bowel injury: traumatic, thermal, and vascular.
Although many significant complications of laparoscopy are recognized in the operating room under direct visualization, thermal injury can easily be
10­12 missed. Patients may not develop symptoms for several days or weeks postoperatively. Early gynecologic consult is critical if a thermal injury is suspected, because damage is usually more extensive than may be apparent.
10­12
Vascular injury is uncommon and is usually recognized during the operation. Patients may later present with a postoperative hematoma, which requires wound exploration by the gynecologist.

The rate of urinary tract injuries is about 4%. Injuries can occur from mechanical or thermal trauma. Trocar or dissection injuries to the bladder are typically recognized intraoperatively. Thermal injuries, however, may not be initially apparent and may present later as peritonitis or fistula. The diagnosis of a ureteral injury is usually delayed. Thermal injury may present up to  days postoperatively with abdominal or flank pain, fever, and peritonitis. An abdominopelvic CT with IV contrast shows extravasation of urine or a urinoma. Mechanical obstruction of the ureter from sutures or staples may be recognized intraoperatively by direct visualization but may also present up to  week postoperatively with fever and flank pain. An IV pyelogram or CT helps define the site and degree of obstruction.
Incisional hernias and dehiscence are rare complications after laparoscopy. Incisional hernias are more common when defects >10 mm are made and can develop within the first postoperative week. Patients may be asymptomatic or may note pain, mass, evisceration, or signs and symptoms of a mechanical bowel obstruction. Fever may present if the bowel is incarcerated, and peritonitis may develop after bowel perforation. Dehiscence usually involves protrusion of the omentum and, in rare cases, the small bowel. Immediate incisional repair by a gynecologist is usually sufficient; however, a laparotomy is needed for bowel incarceration or perforation.
Wound infection after laparoscopy is uncommon. Most infections are minor skin infections that can be managed with oral antibiotics and possible drainage. Antibiotics should cover against staphylococci, including methicillin­resistant Staphylococcus aureus and streptococci. Excluding minor skin infections, pelvic infection is quite rare and includes pelvic cellulitis, abscess, and necrotizing fasciitis.
HYSTEROSCOPY
Hysteroscopy is the direct visualization of the cervical canal and endometrial cavity using a rigid or flexible fiberoptic instrument. Hysteroscopy can be done as an office procedure under IV sedation or in an operating room. Complications (Table 105­4) are uncommon and occur more frequently as a
 result of operative hysteroscopy than diagnostic hysteroscopy.
TABLE 105­4
Complications Associated With Hysteroscopy
Fluid overload
Uterine perforation
Postoperative bleeding
Gas embolism
Infection
The most common indication for hysteroscopy is abnormal vaginal bleeding. Other indications include uterine leiomyomata, intrauterine adhesions, proximal tubal obstruction, removal of intrauterine devices, müllerian anomalies, and infertility evaluation. Therapeutic applications include directed biopsies, removal of small myomata or polyps, and endometrial ablation for menorrhagia. In addition, hysteroscopic sterilization is growing in popularity. The Essure® microinsert system is currently the only method available in the United States. The device is deployed in the fallopian tube and stimulates surrounding tissue growth, resulting in fallopian tube occlusion and permanent sterilization. The failure rate to prevent pregnancy is
  reported as high as .5%. Approximately 4% to 8% of Essure® patients develop new pelvic pain and frequently need subsequent surgery.
With hysteroscopy, uterine perforation is rare and usually noted at surgery. Infection is very rare and most commonly occurs in patients with concurrent genital tract infections. Postoperative bleeding can be uterine or cervical in origin. Cervical lacerations are caused by forceful dilation or tears from the tenaculum. Uterine bleeding can result from resection procedures. Gas embolism is the most feared complication of using carbon
 dioxide gas as a distention medium for laparoscopy. This complication is likely to occur during or shortly after insufflation.
COMPLICATIONS OF MAJOR GYNECOLOGIC­ABDOMINAL SURGERY
Complications from major abdominal procedures that lead to ED visits usually occur at least  days postoperatively (Table 105­5).
TABLE 105­5
Common Complications Related to Major Gynecologic­Abdominal Surgery
Wound infection
Infected vaginal cuff hematoma, cellulites, or abscess
Ovarian abscess
Dehiscence and evisceration
Bleeding
Phlebitis
Urinary tract infection/urinary retention
Bladder and ureteral injury
Ileus, bowel injury, and bowel obstruction
Pneumonia and atelectasis
Hysterectomy remains one of the most common major surgical procedures in the United States, with the abdominal approach composing 60% of cases
,17
(14% laparoscopic and 26% vaginal). A total hysterectomy is removal of the uterus and part or all of the cervix and is unrelated to removal of the ovaries. A subtotal hysterectomy involves removal of the uterus without removal of the cervix. Patients may be unsure of the type of hysterectomy that was performed.

The risk of postoperative infection after hysterectomy is 3% to 10%, with higher rates in the abdominal versus the vaginal approach. Risk factors for
 postoperative infections include obesity, diabetes, and long operative time. The overall rate of all complications after hysterectomy is much higher
 for malignant versus benign indications (19.4% vs. .9%, respectively).
WOUND INFECTION
Most wound infections occur within the first  postoperative weeks; however, they can present several months after surgery. Symptoms include fever and increased pain at the incision site. Examination reveals wound tenderness, skin erythema, induration, purulent discharge from the incision, and possible dehiscence.
Empiric antibiotics should provide coverage against staphylococci, including methicillin­resistant S. aureus, and streptococci. If an incisional abscess is diagnosed, first open and drain the wound. Probe the wound with a sterile cotton swab to confirm an intact fascia. Then, irrigate the wound copiously with normal saline and pack with saline­soaked wet­to­dry dressings. If staples have been placed, they should be removed. Obtain aerobic and anaerobic cultures to tailor antibiotic therapy.
For invasive infections, consult with the operating gynecologist. Give parenteral antibiotics and, usually, admit to the hospital.
WOUND SEROMA AND HEMATOMA
Wound seromas and hematomas are very common. They are characterized by drainage, rather than fever or pain, and can be visualized by bedside US.
Small seromas and hematomas can be managed by observation and will usually resolve spontaneously. Large seromas can be aspirated. Infected hematomas typically present  to  days postoperatively. If there are any signs of infection, the wound should be opened and drained and then packed with wet­to­dry dressings.
VAGINAL CUFF CELLULITIS AND PELVIC ABSCESS
The vaginal cuff formed during hysterectomy is composed of the contiguous retroperitoneal space immediately above the vaginal apex and the surrounding soft tissue. Vaginal cuff cellulitis usually occurs early after surgery. Patients complain of fever; purulent vaginal discharge; and pelvic, back, or abdominal pain. Pelvic examination reveals tenderness and induration of the vaginal cuff and purulent discharge.
Vaginal cuff and pelvic abscesses and infected hematomas are rare and usually present  to  days postoperatively. Symptoms include fever, chills, tachycardia, pelvic pain, and rectal pressure. Examination findings include lower abdominal and vaginal cuff tenderness, a tender or fluctuant mass near the cuff, and bloody or purulent drainage from the cuff. US or CT can define the size and location of an abscess or hematoma.
Admit patients for parenteral antibiotics and possible drainage by interventional radiology or colpotomy. Give broad­spectrum antibiotics, such as imipenem­cilastatin, gentamicin and clindamycin, or ciprofloxacin and metronidazole, to cover gram­negative and gram­positive bacteria and
 anaerobic organisms.
DEHISCENCE AND EVISCERATION
Wound dehiscence is the failure of normal healing and the disruption of fascia and peritoneum. Evisceration occurs when omentum or bowel presents through the incision. The classic sign of impending dehiscence is the sudden outpouring of serosanguineous blood from the incision. The patient may
 describe a “pop” or tearing sensation. Most often, dehiscence occurs between postoperative days  and  for abdominal surgeries.

Vaginal cuff dehiscence usually occurs .5 to .5 months after hysterectomy. Patients complain of postcoital bleeding, watery discharge, and pelvic pain. If bowel evisceration has occurred, patients note vaginal and pelvic pressure or a bulge.
When abdominal evisceration has occurred, cover the abdomen with moist sterile towels and support the dressing with tape to prevent further gut extrusion. The patient should be taken directly to the operating room for closure. In cases in which there is a sudden appearance of blood but no bowel, it is best to follow the same procedure because evisceration usually is imminent. Vaginal cuff dehiscence can be managed conservatively if small or partial, whereas large or complete vaginal cuff dehiscence usually requires surgical closure.
GENITOURINARY INJURY
Genitourinary injury occurs more often during the performance of abdominal hysterectomy than during any other pelvic surgery. Most bladder injuries are apparent at the time of surgery, but some ureteral injuries go unrecognized. Ureteral injury occurs less frequently than bladder injury but is generally underestimated. Operative injury to the ureter results from one of three types of trauma: crushing, transection, or ligation. Each type of injury can be either partial or complete.
Suspect ureteral injury in women who develop flank pain shortly after surgery. Fever, hematuria, and costovertebral angle tenderness may also be present. Obtain a urinalysis and abdominopelvic CT with IV contrast. Admit to the hospital for ureteral catheterization under cystoscopic guidance and possibly exploratory laparotomy. Percutaneous nephrostomy with delayed repair may also be considered. Provide parenteral antibiotics if infection is suspected.
Vesicovaginal fistulas can become evident  to  days after surgery with a watery vaginal discharge. The diagnosis can be confirmed by inserting a cotton tampon into the vagina and then instilling methylene blue or indigo carmine dye via a transurethral catheter. If the tampon stains blue, a vesicovaginal fistula is present. If no staining occurs, a ureterovaginal fistula must be ruled out by injecting  mL of indigo carmine dye IV. If a ureterovaginal fistula is present, the tampon should stain blue within  minutes.
Gynecologic consultation is necessary. Patients with a vesicovaginal fistula require prolonged urinary drainage with a Foley catheter. Although some fistulas close spontaneously, most require surgical repair.
OTHER COMPLICATIONS

Urinary tract infection is a common complication. For detailed discussion, see Chapter , “Urinary Tract Infections and Hematuria.” Urinary retention in a healthy female after gynecologic surgery is uncommon. Urinary retention is usually a temporary result of pain or bladder atony resulting from anesthesia. However, many women experience either an inability to void or incomplete emptying of the bladder during the postoperative period, most frequently after radical hysterectomy or surgeries that involve the urethra and bladder neck (i.e., anterior repair or any modification of the retropubic urethropexy). Retention is initially relieved with insertion of a Foley catheter for  to  hours. Most patients are able to void after this period. For further discussion, see Chapter , “Acute Urinary Retention.”

Pulmonary emboli account for nearly 40% of all deaths after gynecologic surgery. The prevalence of postoperative deep venous thromboembolism
 is 11% to 25%. Fifty percent of venous thromboembolic events occur in the first  hours after surgery, and 75% occur in the first  postoperative days.
There is no difference in the incidence of venous thromboembolism between abdominal, vaginal, or laparoscopic hysterectomy, but risk factors
 include age >60 years, cancer, and other comorbidities. For complete discussion of diagnosis and treatment, see Chapter , “Venous
Thromboembolism Including Pulmonary Embolism.”

Septic pelvic thrombophlebitis complicates .1% to .5% of gynecologic procedures, more commonly after cesarean delivery than hysterectomy.
The two forms of septic pelvic thrombophlebitis, ovarian vein thrombosis and deep septic pelvic thrombophlebitis, often occur together. Signs include
,25 abdominal pain and fever. The diagnosis may be aided by CT and MRI, but a negative study does not exclude disease. Treatment is anticoagulation and parenteral antibiotics. Long­term anticoagulation is not needed unless septic pulmonary emboli develop.
POSTCONIZATION BLEEDING
High­grade squamous intraepithelial lesions of the cervix are treated by loop electrocautery, laser ablation, or cold­knife conization. The most common complication of conization procedures is bleeding, which can be rapid and severe. Delayed hemorrhage may occur  to  days postoperatively.
Visualization of the cervix is the key to controlling bleeding. Application of Monsel solution (a commercially available ferrous subsulfate solution) is a reasonable first step if it is readily available. Monsel solution should be available from the hospital pharmacy. Direct pressure for  minutes with a large cotton­tipped swab may also be effective. Alternatively, cauterization with silver nitrate may be attempted. If these maneuvers are unsuccessful, consult the gynecologist for suturing or cauterization of the bleeding arteriole. The vagina can be packed with gauze if the bleeding is severe while waiting for definitive therapy. Often the patient must be taken to the operating room for repair because adequate visualization is difficult in the ED.
INDUCED ABORTION
There are three major methods for termination of pregnancy: instrumental evacuation by vaginal route, stimulation of uterine contraction, and major
 surgical procedures. Overall, less than 1% of women have complications. Complications can be categorized by time after procedure: immediate, delayed, or late (Table 105­6).
TABLE 105­6
Complications Associated With Induced Abortion
Timing Complication Possible Etiologies
Immediate complications: within  h after Bleeding, pain Uterine perforation, cervical lacerations procedure
Delayed complications: between  h and  wk Bleeding Retained products of conception, postabortive after procedure endometritis
Late complications: >4 wk after procedure Amenorrhea, psychological problems, Rh — isoimmunization

Due to the approval of mifepristone in 2000, medical abortions now account for 36% of abortions at  or fewer weeks of gestation. The evidencebased regimen of mifepristone 200 milligrams orally followed by a single dose of buccal misoprostol 800 micrograms  to  hours later results in a

.6% efficacy of pregnancy termination. Common side effects include nausea, vomiting, diarrhea, headaches, dizziness, and fatigue. Methotrexate, in combination with misoprostol, is an alternative therapy. A higher frequency of complications occurs in medical induction versus surgical abortion,
 most notably infection and retained placenta.

Incomplete abortion and retained products of conception occur in .5% of medical abortions and .29% to .96% of all abortions. Women present with abdominal pain, bleeding, and possibly fever. On physical examination, the cervical os is usually open, and the uterus is boggy, enlarged, and tender. A pelvic US is the diagnostic test of choice and can identify a thickened endometrium and retained echogenic contents. Treatment consists of dilatation and curettage or medical management with misoprostol. If coexistent endometritis is present, treatment with broad­spectrum antibiotics is required for at least  to  days.
Postabortal endometritis not associated with retained products of conception presents with a closed cervical os and a firm yet tender uterus.
Uncomplicated endometritis is treated with antibiotics.

Uterine perforation occurs in approximately .1 to  per 1000 abortion procedures. Most perforations are noted at the time of surgery; however, small perforations may go unnoticed. Patients can present with pain and/or bleeding and, possibly, signs of shock.
If a cervical laceration is noted, treatment includes pressure, followed by application of Monsel solution or use of silver nitrate sticks. Suturing may be necessary if there is no resolution of bleeding.
Women who are Rh negative require Rh0 (D) immunoglobulin, 300 micrograms IM, after spontaneous or induced abortion. If it is not prescribed within  hours, the overall risk of sensitization in the second pregnancy is approximately 3%.
Obtain gynecologic consultation for all patients with complications after induced abortion.
INTRAUTERINE DEVICES
Serious complications from intrauterine devices are rare, occurring in less than 1% of patients, and include pelvic inflammatory disease, ectopic
 pregnancy, and uterine perforation. In the event that an intrauterine device string is not visible on pelvic examination, transvaginal ultrasonography
 should be performed, as it detects translocation of the intrauterine device in 55% to 85% of patients. If left untreated, translocated intrauterine devices may lead to life­threatening complications such as a pelvic abscess or less commonly bladder or bowel injury; therefore, all patients with
 extrauterine or fractured intrauterine devices should have urgent referral to a gynecologist for surgical removal.
The risk of pelvic inflammatory disease in intrauterine device users is more related to preexisting sexually transmitted infections rather than the
,34 intrauterine device itself. Patients may present to the ED for intrauterine device removal for other reasons, such as irregular menses or pain; however, patients should be referred to their gynecologist for removal.
If referral is impractical, grasp the string of the intrauterine device with a Kelly clamp or long forceps and pull with steady, gentle force until the intrauterine device emerges from the uterus. Do not jerk the string because it may detach from the intrauterine device, making removal more difficult.
ENDOMETRIAL ABLATION
Endometrial ablation is used to treat abnormal uterine bleeding. Although there are numerous technologies, they share similar postoperative complications, including pregnancy after ablation, pain­related obstructed menses, and infection. Pregnancy incidence after endometrial ablation is

.7%. There is a much greater risk of complications during these pregnancies, including preterm birth, intrauterine scarring, and postpartum hemorrhage. Also, the ectopic rate is .5%, almost three times the baseline risk. Persistent endometrium is common after ablation, as are uterine contracture and scarring. This results in obstructed egress of menses, causing cyclic cramping and pain. The incidence of infectious complications
 ranges from 1% to 2%, including endometritis, myometritis, pelvic inflammatory disease, and pelvic abscess. Patients present with fever, uterine and/or adnexal tenderness, and vaginal discharge usually within  days of surgery.
PELVIC ORGAN PROLAPSE SURGERY AND SYNTHETIC MESH
Surgery using transvaginal mesh can be used to treat pelvic organ prolapse. Associated complications include bladder perforation, mesh erosion and
 vaginal exposure, chronic pelvic pain, dyspareunia, infection, and fistula formation. This has prompted the U.S. Food and Drug Administration to release several public notifications on the safety and effectiveness of transvaginal mesh for treatment of prolapse; therefore, many surgeons have
 decreased or eliminated its use.
ASSISTED REPRODUCTIVE TECHNOLOGY
Transvaginal US­guided aspiration of oocytes is used during in vitro fertilization. Complications related to US­guided retrieval and preparation for retrieval of oocytes are rare and include ovarian hyperstimulation syndrome, pelvic infection, intraperitoneal bleeding, and adnexal torsion.
Occasionally, complications develop hours to weeks after the procedure and require prompt surgical intervention.
Ovarian hyperstimulation syndrome is a clinical diagnosis that commonly occurs in women going through in vitro fertilization. Symptoms may
 begin as soon as  hours after human chorionic gonadotropin administration but become most severe after  to  days. Mild disease occurs in 20% to 33% of in vitro fertilization cycles, presenting with abdominal distention, ovarian enlargement <8 cm, and weight gain; however, mild ovarian
  hyperstimulation has little clinical consequence. The moderate­to­severe form is seen in 1% to 6% of patients undergoing assisted reproduction.
Symptoms of severe disease include rapid weight gain, ovarian enlargement >12 cm, tense ascites due to third spacing of fluid into the abdominal cavity, pleural effusions, tachypnea, orthostatic hypotension due to hypovolemia, tachycardia, progressive oliguria, and electrolyte abnormalities.
Increased coagulability and decreased renal perfusion are also noted. Rarely, it can be a life­threatening complication.
Bimanual pelvic examination is contraindicated due to extremely fragile ovaries that are at high risk of rupture or hemorrhage.
Defer examination until after discussion with the gynecologist. Laboratory evaluation includes a CBC, chemistry panel, coagulation studies, and blood for type and cross­match. An ECG to evaluate hyperkalemia should also be obtained.
Treatment in the ED consists of IV volume repletion, respiratory support, pain control, and possibly paracentesis and/or pleuracentesis. Consult the gynecologist for admission. Patients with suspected adnexal torsion should undergo evaluation with Doppler US.
POSTEMBOLIZATION SYNDROME
Uterine artery embolization is a safe, effective approach for treating symptomatic uterine fibroids that may help patients avoid myomectomy and hysterectomy. It is an outpatient procedure performed by interventional radiologists in collaboration with the gynecologist. Compared to hysterectomy, uterine artery embolization is less expensive, results in a move favorable short­term quality of life, and has a significantly lower rate of
 major complications.

Postembolization syndrome is characterized by abdominal pain, fever, and leukocytosis after embolization and occurs in .8% of patients. It is likely caused by an inflammatory response to myometrial and fibroid ischemia and necrotic tissue. Symptoms begin  to  days after the procedure and can last up to  days. In the ED, control pain and consider other possible causes for symptoms, particularly infection such as endometritis. Evaluation may include a CBC and a CT scan. Vaginal discharge and fibroid expulsion may be seen on pelvic exam. Approximately 1% of patients require hysterectomy due to infection. Some patients may require admission for pain control and IV antibiotics.


