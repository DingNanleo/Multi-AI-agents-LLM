## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 160: Food and Waterborne Illnesses
Lane M. Smith; Simon A. Mahler
FOODBORNE ILLNESSES
INTRODUCTION AND EPIDEMIOLOGY
Foodborne illness occurs after consumption of a food contaminated with bacteria, viruses, or protozoans. Outbreaks from contaminated food are often widespread due to advances in modern food logistics. International travel contributes to foodborne illnesses as travelers are exposed to new
 pathogens and migrants may introduce diseases, making foodborne disease a global public health concern.
The Centers for Disease Control and Prevention estimates that foodborne diseases affect  million Americans each year, leading to 128,000
,3 hospitalizations and 3000 deaths. Children have the highest frequency of foodborne illness. Viruses are the most common cause of foodborne
 disease, with the norovirus causing more than half all cases and 26% of all admissions. Other viral sources of infection include rotavirus, astrovirus, and enteric adenovirus.
,3
Although less frequent, bacterial causes tend to be more severe, with nontyphoidal Salmonella and Listeria most often resulting in fatality. Other common bacterial causes of foodborne illness include Clostridium perfringens, Campylobacter spp., Toxoplasma gondii, Shigella, Staphylococcus aureus, and Shiga toxin–producing Escherichia coli (STEC). The most common foods associated with foodborne illness outbreaks from any pathogen
,3 reported in the United States are poultry, leafy vegetables, and fruits/nuts. For further discussion, see Chapter , “Disorders Presenting Primarily
With Diarrhea.”
PATHOPHYSIOLOGY
There are three basic mechanisms by which microbes cause illness. First, some pathogens such as S. aureus, Bacillus cereus, and Clostridium botulinum (botulism) produce toxins causing illness. These toxins are present in the food before ingestion and result in the rapid onset (1 to  hours) of symptoms. Preformed toxins such as staphylococcal enterotoxin stimulate the host immune system to release inflammatory cytokines within the
 intestine. These cytokines trigger the accompanying nausea and vomiting.
The second method involves toxin production after ingestion, which interacts with intestinal epithelium; this occurs with Vibrio, Shigella, and STEC.
These cause diarrhea (sometimes bloody) and lower abdominal cramping, with onset at approximately  hours after exposure. Some toxins
 produced by Vibrio and enterotoxigenic E. coli alter chloride and sodium transport across intestinal mucosal surfaces without destroying cells. The resulting osmotic gradient produces a large fluid shift into the intestinal lumen, which overwhelms the absorptive capacity of the colon causing watery diarrhea. Other toxins produced disrupt host cell protein production, which causes death of the intestinal epithelium, resulting in bloody diarrhea and
 extraintestinal symptoms.
Finally, direct invasion of the intestinal epithelium is a mechanism for the enteric viruses, notably Salmonella, enteroinvasive E. coli, and

Campylobacter. These pathogens enter host cells and destroy intestinal epithelium. This causes diarrhea due to transient malabsorption that is frequently bloody and accompanied by fever. Illness requires ingestion of just a few pathogens to cause disease. The upper and lower GI symptoms from invasive organisms last from  hours to weeks (Table 160­1).
TABLE 160­1
Etiologic Agents for Foodborne Diseases and Usual Incubation Periods

1–6 Hours 6–24 Hours 24–48 Hours 2–6 Days 1–2+ Weeks
Chapter 160: Food and Waterborne Illnesses, Lane M. Smith; Simon A. Mahler 
. Terms of Use * Privacy Policy * Notice * Accessibility
Astrovirus Bacillus cereus diarrhea toxin Clostridium botulinum Campylobacter Brucella
B. cereus preformed toxin C. perfringens Enterotoxigenic Escherichia coli Shigella Cryptosporidium
Ciguatoxin Vibrio parahaemolyticus Salmonella Enterohemorrhagic E. coli Entamoeba
Heavy metals Trichinella Vibrio cholerae Giardia
Monosodium glutamate Yersinia Hepatitis A
Norovirus Listeria
Scombroid toxin Salmonella typhi
S. aureus toxin
Tetrodotoxin
The normal human digestive system defends against illness in many ways. The low gastric pH of  to  kills many ingested pathogens, whereas the
,9 intestinal flora competitively inhibits pathogens and secretes bactericidal fatty acids and other chemicals. Intestinal motility prevents pathogens from having prolonged contact with mucosal surfaces and mixes organisms with mucus­containing protective glycoproteins. Immunologic cells also
 directly attack pathogens attempting transmural migration.
Alteration of these protective mechanisms can increase susceptibility to foodborne disease. For example, proton pump inhibitors, histamine­2
,9 blockers, and antacids reduce gastric acid production and increase susceptibility in foodborne illnesses. Recent antibiotic use, chemotherapy or radiation therapy, and recent surgery alter the intestinal flora. Decreased intestinal motility from opioids, antiperistaltic drugs, or surgery encourages
 pathogen growth and migration.
CLINICAL FEATURES
Suspect a foodborne disease when two or more people in a household or close association (e.g., the same workplace or communal eating arrangement) develop GI symptoms at or near same onset time. The most common symptoms are nausea, vomiting, diarrhea, and abdominal cramping. Systemic symptoms of fever, dehydration, and malaise also occur. Neurologic symptoms of seizures and altered mental status are seen in
 approximately 10% of pediatric patients with Shigella and are associated with worse outcomes.
Question patients about the types of food they have recently ingested, frequency of restaurant meals, consumption of public­vended or street­vended foods, ingestion of seafood, and consumption of raw foods. Ask about recent travel or camping, contact with food handlers, and diaper changing.
Children who attend day care centers and residents of long­term care facilities are at increased risk for foodborne diseases. Individuals working in the food industry are other frequent victims or sources; ask them about their personal hygiene and food­handling practices. Finally, seek a history of comorbid conditions or influencing therapies, including human immunodeficiency virus (HIV) infection or immunosuppressive drug use.
On exam, look for dehydration and systemic findings. Carefully look for blood in the stool and for alternative causes of symptoms such as appendicitis.
The clinical features of specific foodborne infections are listed in Table 160­2. TABLE 160­2
Clinical Features of Foodborne Infections
Clinical Presentation Foodborne Pathogens
Gastroenteritis with vomiting as the primary Viral pathogens: norovirus, rotavirus, and astrovirus; preformed toxins: Staphylococcus aureus and symptom Bacillus cereus
Noninflammatory diarrhea (watery nonbloody) Can be any enteric pathogen, but classically:
ETEC
Giardia
Vibrio cholerae
Enteric viruses
Cryptosporidium
Cyclospora
Inflammatory diarrhea (grossly bloody, fever) Shigella
Campylobacter
Salmonella
EIEC
Shiga toxin–producing Escherichia coli O157:H7 and non­O157:H7
Vibrio parahaemolyticus
Yersinia
Entamoeba
Persistent diarrhea (>14 d) Parasites:
Giardia
Cyclospora
Entamoeba
Cryptosporidium
Neurologic manifestations Botulism (Clostridium botulinum toxin)
Scombroid fish poisoning
Ciguatera fish poisoning
Tetrodotoxin
Toxic mushroom ingestion
Paralytic shellfish poisoning
Guillain­Barré syndrome
Shigella (pediatric seizures, encephalopathy, and rarely coma)
Systemic illness Listeria monocytogenes
Brucella
Salmonella typhi
Salmonella paratyphi
Vibrio vulnificus
Hepatitis A, E
Abbreviations: ETEC = enterotoxigenic E. coli; EIEC = enteroinvasive E. coli.
DIAGNOSIS
Most patients with foodborne diseases do not require diagnostic testing; illnesses are usually self­limited. Routine stool testing is not
 indicated for uncomplicated, watery diarrhea. However, electrolytes and a CBC aid in patients with systemic illness findings, serious comorbid conditions, or those with prolonged symptoms. Obtain a stool test in those with:
Watery diarrhea with signs of hypovolemia
Bloody diarrhea
Fever ≥38.5°C (101.3°F)
Duration of illness >1 week
Severe abdominal pain or tenderness
Hospitalized patients or recent antibiotic use
Elderly (≥70 years of age) or the immunocompromised
Pregnant women or those with comorbid conditions such as inflammatory bowel disease
Diagnostic testing for a specific pathogen uses either stool staining/culture or multipathogen molecular panel. Routine stool cultures will identify
Salmonella, Campylobacter, and Shigella but may not detect enterotoxigenic E. coli, vibrios, fungi, and viruses. Newer molecular panels using polymerase chain reaction are sensitive and less dependent on sample quality than routine stool cultures and help identify a wide array of
 pathogens. These assays have become the test of choice at most institutions since they can detect bacterial, viral, and parasitic infections in a single
 stool sample. Indirect tests for bacterial causes of diarrhea such as fecal leukocytes or lactoferrin are not recommended.
Add testing for ova and parasites selectively (e.g., in the immunocompromised, travelers, patients with symptoms lasting longer than  weeks,
 community waterborne outbreaks, or men who have sex with men). The newer multipathogen molecular panels are sensitive and specific for these parasites.
Elderly patients, young children, and the immunocompromised are more likely to have severe illness, atypical presentations, and long­term sequelae.
Patients with acquired immunodeficiency syndrome or other immunocompromised states can rapidly develop life­threatening symptoms and should undergo additional testing for Cryptosporidium, Cyclospora, Microsporidia, Mycobacterium avium complex, and Cytomegalovirus.
TREATMENT
Most episodes of acute gastroenteritis require adequate hydration and supportive care. The World Health Organization recommends initial oral
 hydration with a glucose­containing fluid (i.e., Pedialyte® or equivalent). Reserve parenteral rehydration for patients with severe dehydration or with
,15 continued vomiting and inability to tolerate oral fluids. Antiemetics may reduce vomiting, ED length of stay, and need for admission. Antimotility medications, such as loperamide, may decrease illness duration for mild to moderate nonbloody diarrhea in adults without fever; avoid these in
 children and patients with dysentery (fever and bloody diarrhea) due to concerns of prolonging the illness.
Empiric antibiotics do not dramatically alter the course of illness since most cases are viral or self­limited bacterial in origin. The 2017 Infectious

Diseases Society of America guidelines recommend empiric treatment for patients with bloody diarrhea under the following circumstances :
Infants less than  months of age
Immunocompromised patients with severe illness
Ill immunocompetent people with documented fever, abdominal pain, bloody diarrhea, and bacillary dysentery presumptively due to Shigella
Recent international travelers with fever ≥38.5°C or signs of sepsis
Avoid empiric antibiotics if you believe illness is from STEC O157 and other STEC that produce Shiga toxin due to increased risk of hemolytic­uremic syndrome (HUS). Empiric antibiotics are an option for well­appearing patients with watery diarrhea and a history of international travel, but these are not needed for most with other diarrheal illnesses, even when prolonged more than  days. A common bacterial enteritis regimen is oral ciprofloxacin, 500 milligrams twice daily, or levofloxacin, 500 milligrams once a day, each for  to  days. Azithromycin, 500 milligrams once daily for 
 days, is an alternative. See Tables 160­3, 160­4, 160­5, and 160­6 for detailed treatment recommendations.
TABLE 160­3
Clinical Features, Diagnosis, and Management of Bacterial Foodborne Illness
Duration
Associated Laboratory
Etiology Signs and Symptoms of Treatment
Foods Testing
Illness
Bacillus anthracis Nausea, vomiting, bloody Weeks Poorly cooked Blood Ciprofloxacin or doxycycline IV + PCN, diarrhea, abdominal pain, meat vancomycin, rifampin, or clindamycin malaise
Bacillus cereus Sudden onset of nausea,  h — Clinical Supportive care
(preformed toxin) vomiting; can have diagnosis; diarrhea assay must be ordered specifically
B. cereus (diarrheal Watery diarrhea, cramping, 1–2 d Meats, gravies, Not Supportive care toxin) nausea stew, vanilla sauces necessary
Brucella Fever, chills, myalgias, Weeks Raw milk, Serology, Doxycycline 100 milligrams PO twice daily + arthralgias, weakness, unpasteurized blood culture streptomycin  gram IM for 14–21 d bloody diarrhea goat’s milk or cheese, contaminated meat
Campylobacter Diarrhea, cramping, 2–10 d Contact with raw Routine stool Ciprofloxacin 750 milligrams PO twice daily or nausea, vomiting, fever, poultry, culture on levofloxacin 500 milligrams PO daily or often bloody diarrhea undercooked special media azithromycin 500 milligrams daily for 3–5 d poultry, and unpasteurized temperature; milk, contaminated MMP water
Clostridium Vomiting, diarrhea, blurred Days to Canned foods, Stool, serum, Supportive care (may require intubation), botulinum vision, diplopia, dysphagia, months canned fish, foods or food assay botulism antitoxin
(preformed toxin) descending muscle kept warm in for toxin; weakness, paralysis dishes, herbed oils, stool culture cheese sauce
C. botulinum— Infants <12 mo, lethargy, Variable Honey, home Stool, serum, Botulism immunoglobulin; antitoxin not infants weakness, poor feeding, canned vegetables, or food for recommended in infants head control, and suck corn syrup toxin; stool culture
Clostridium Watery diarrhea, nausea, 1–2 d Meat, poultry, dried Stools for Supportive care perfringens cramping or precooked enterotoxin, foods, poor stool culture temperature control
Enterohemorrhagic Severe, often bloody 5–10 d Undercooked beef Stool culture; Supportive; avoid antibiotics due to risk of
Escherichia coli and diarrhea; abdominal pain; (hamburger), may require hemolytic­uremic syndrome
Shiga toxin– vomiting; little or no fever unpasteurized special producing E. coli, milk, juices, raw media; toxin
O157:H7 fruits and assay; MMP vegetables
Enterotoxigenic E. Watery diarrhea, cramping, 3–7 d Water or food Stool culture; Supportive; ciprofloxacin 500 milligrams PO coli vomiting contaminated with MMP twice per day or levofloxacin 500 milligrams human feces PO once daily for  d
Listeria Fever, myalgias, nausea, Variable Fresh soft cheeses, Blood or Supportive care; ampicillin or penicillin G; monocytogenes diarrhea; premature poorly pasteurized cerebrospinal TMP­SMX for PCN allergic delivery if pregnant; dairy products, deli fluid culture; meningitis meats, hot dogs listeriolysin O antibody assay
Salmonella Diarrhea, vomiting, 4–7 d Eggs, poultry, Routine stool Supportive care; ciprofloxacin 500 milligrams abdominal pain, fever, unpasteurized culture; MMP PO twice daily or levofloxacin 500 milligrams myalgia dairy products, raw once daily for 3–5 d; ceftriaxone IV for severe fruits and disease or immunocompromised; vaccine for vegetables, street­ Salmonella typhi vended food
Shigella Abdominal cramping, fever, 4–7 d Fecal Routine Supportive care; ciprofloxacin 500 milligrams diarrhea with blood and contamination of culture; MMP PO twice per day or levofloxacin 500 mucus any food or water, milligrams once per day for 3–5 d or person to person, azithromycin 500 milligrams PO daily for  d prepared food
Staphylococcus Sudden­onset severe 1–2 days Improperly Clinical Supportive care only aureus (preformed nausea, vomiting, diarrhea, refrigerated meats, diagnosis; toxin) fever potato or egg assay for salad; left out toxin; culture pastries if indicated
Vibrio cholerae Profuse watery diarrhea 3–7 d Contaminated Specifically Aggressive PO or IV fluid replacement, and vomiting; life­ water, fish, ordered stool azithromycin  gram PO once or doxycycline threatening dehydration shellfish, street­ culture; MMP 300 milligrams once or ciprofloxacin  gram vended foods PO once
Vibrio Watery diarrhea, cramping, 2–5 d Undercooked or Stool culture Supportive care; antibiotics in severe illness: parahaemolyticus vomiting raw fish or shellfish (special ciprofloxacin 500 milligrams PO twice daily or media TMP­SMX double strength PO twice daily or required); doxycycline 100 milligrams PO twice daily for 
MMP d
Vibrio vulnificus Vomiting, abdominal pain, 2–8 d Undercooked or Specifically See Table 160­8 diarrhea, skin infections; raw fish or shellfish ordered can be fatal in liver disease stool, blood, or immunocompromised or wound patients cultures;
MMP
Yersinia Pseudoappendicitis, fever, 1–3 wk Undercooked pork Stool, blood, Supportive care; antibiotics usually not abdominal pain, vomiting, products, tofu, or vomitus required; if septic: gentamicin,  milligrams/kg diarrhea, rash contaminated cultures IV daily + ceftriaxone  grams IV daily water (special media); MMP
Abbreviations: MMP = multipathogen molecular panel; PCN = penicillin; TMP­SMX = trimethoprim­sulfamethoxazole.
TABLE 160­4
Clinical Features, Diagnosis, and Management of Viral Foodborne Illness
Duration
Etiology Signs and Symptoms of Associated Foods Laboratory Testing Treatment
Illness
Hepatitis A Diarrhea, jaundice, dark urine,  wk to  Shellfish, raw produce, Liver profile, bilirubin, Supportive care; flulike illness, abdominal pain mo contaminated water, infected positive immunoglobulin, prevention with contacts and antihepatitis A immunization antibodies
Norovirus, Nausea, vomiting, abdominal  h to  Fecal contaminated foods; foods Clinical diagnosis; Supportive care, rotavirus, and cramping, diarrhea; d touched by infected workers multipathogen molecular good hygiene, other sometimes fever, malaise, (salads, sandwiches, produce); panel adequate fluid enterovirus headache shellfish replacement
TABLE 160­5
Clinical Features, Diagnosis, and Management of Parasitic Foodborne Illness
Duration
Signs and Associated
Etiology of Lab Testing Treatment
Symptoms Foods
Illness
Cryptosporidium Watery Weeks to Any Specific stool Supportive care and HAART in HIV infected; nitazoxanide 500 diarrhea, months— contaminated examination; milligrams PO twice daily for  d + azithromycin in patient with HIV cramping, may be uncooked MMP and severe symptoms fever relapsing food, water
Cyclospora Watery Weeks to Various types Specific stool TMP­SMX­DS PO twice per day or ciprofloxacin 500 milligrams twice diarrhea, months, of fresh examination; daily for 7–10 d; nitazoxanide 500 milligrams PO twice daily for  d weight loss, relapsing produce MMP In HIV patients: TMP­SMX­DS PO  times a day for  d cramping, vomiting, fatigue
Entamoeba Bloody Weeks to Any Examination Metronidazole 750 milligrams PO  times daily for 5–10 d or histolytica diarrhea, months contaminated of stool for paromomycin 500 milligrams PO  times daily for  d or tinidazole frequent uncooked cysts and  grams PO for  d or nitazoxanide 500 milligrams PO twice daily for stools, lower food, water parasites;  d abdominal serology; pain MMP
Giardia Diarrhea, Months Any Examination Metronidazole 250 milligrams PO  times daily for 7–10 d or cramping, contaminated of stool for tinidazole  grams PO once or nitazoxanide 500 milligrams PO twice copious flatus uncooked ova and daily for  d or paromomycin 500 milligrams PO  times daily for  food parasites; d or albendazole 400 milligrams PO once daily for  d
MMP
Abbreviations: HAART = highly active antiretroviral therapy; HIV = human immunodeficiency virus; MMP = multipathogen molecular panel; TMP­SMX­DS = trimethoprim­sulfamethoxazole double strength.
TABLE 160­6
Clinical Features, Diagnosis, and Management of Toxinogenic Foodborne Illness
Etiology Signs and Symptoms Duration Foods Lab Tests Treatment
Ciguatera Abdominal pain, vomiting, diarrhea, Days to Large reef fish Clinical Supportive care; high­dose toxin paresthesias, reversal of hot and cold months (barracuda most diagnosis atropine for bradycardia; IV sensation, weakness, hypotension, common) mannitol for severe neurologic bradycardia symptoms
Tetrodotoxin Paresthesias, headache, vomiting, diarrhea, Death in Puffer fish Detection of Emergent supportive care;
(puffer fish) abdominal pain, ascending paralysis, 4–6 h tetrodotoxin in anticholinesterases such as respiratory failure, death fish neostigmine and edrophonium
Scombroid Flushing, rash, burning sensation, dizziness, 3–6 h Pelagic fish— Clinical Antihistamines, supportive care
(histamine) paresthesias tuna, mackerel, diagnosis, can swordfish, mahi­ assay for mahi histamine in fish
Shellfish Diarrhea, vomiting, abdominal pain, fever,  h to  d Shellfish, Detection of Supportive care, self­limited toxins numbness, dizziness, myalgias, confusion, mussels, clams toxin in memory loss, coma shellfish
DISPOSITION AND FOLLOW­UP
Admit or observe for prolonged intervals those who have systemic symptoms, comorbid conditions, or severe dehydration with inability to tolerate oral fluids. Have a low threshold for admitting immunocompromised patients. Pregnant patients have increased risk of complications, especially with

Listeria infection, and may require further monitoring.
Discharged patients should receive instructions on proper hygiene, notably frequent hand washing to protect non­ill family members and contacts.
Patients discharged with pending stool culture or other studies should have a clear plan for follow­up.
SPECIAL CONSIDERATIONS
ENTEROHEMORRHAGIC E. COLI AND HEMOLYTIC­UREMIC SYNDROME

Enterohemorrhagic E. coli that produces Shiga toxin is the most common cause of HUS in children. The STEC strain O157:H7 is most commonly
 associated with pediatric HUS, but other organisms such as O104:H4, O111, and Shigella are also associated with adult HUS­like illnesses. The Shiga toxin produced by these organisms halts protein synthesis in renal glomerular cells as the precipitating event in HUS. Toxin binding to the glomerular
 endothelium produces a thrombogenic environment, leading to microangiopathic hemolysis through multiple cellular mechanisms. Antibiotics may promote Shiga toxin release, which increases the incidence of HUS; for this reason, avoid antibiotics when suspecting this pathogen. In addition, avoid antimotility agents. Treatment of HUS is supportive, although eculizumab, a monoclonal antibody to complement factor C5 that blocks complement
 activation, shows promise in severe cases. Approximately 50% of pediatric patients with HUS require dialysis, and dehydration at the time of
 admission increases the frequency and duration of renal support.
SCOMBROID AND CIGUATERA POISONING
Scombroid fish poisoning occurs after ingestion of fish of the family Scombridae (tuna, mackerel, and bonito). Other non­Scombridae fish such as mahi­mahi, bluefish, herring, and sardines are triggers. The disease occurs when histidine is metabolized by bacteria into histamine and other
 bioactive amines. Improper temperature control allows high concentrations of these substances to accumulate in the fish. Symptoms usually begin
 minutes to  hours after ingestion and include flushing, headache, abdominal cramping, vomiting, and diarrhea. Symptoms are usually self­limited for  to  hours. However, severe cardiac and respiratory symptoms may occur in the elderly or patients with comorbid conditions. Treatment is with
 antihistamines (H and H blockers) such as diphenhydramine and cimetidine. Laboratory testing is not indicated in most cases.

Ciguatera poisoning is caused by eating reef fish contaminated with the dinoflagellate Gambierdiscus toxicus, which produces ciguatoxin. The toxin is heat resistant and accumulates in large predatory fish such as grouper, snapper, amberjack, and barracuda. Ciguatoxin acts on sodium channels, resulting in membrane depolarization. Nausea, vomiting, and diarrhea occur  to  hours after ingestion, followed by hypesthesias, paresthesias,
 numbness, malaise, generalized weakness, and sensitivity to temperature extremes. Bradycardia and hypotension are possible. The GI symptoms
 typically resolve over a few days, whereas the neurologic symptoms may persist in a waxing and waning pattern for  months to years. Acute treatment is supportive. A consensus review of nine articles reported that IV mannitol may aid severe acute cases, but the evidence is conflicting and
 mannitol doses were not well described.
CHRONIC SEQUELAE OF FOODBORNE ILLNESS
,26
Approximately 2% to 3% of patients with foodborne diseases have longer sequelae thought to be related to autoimmunity. Protein virulence factors (superantigens) can initiate extreme immune responses. Salmonella, Shigella, and Campylobacter result in a seronegative reactive arthritis in
 approximately 2% of those infected. Campylobacter infection is associated with Guillain­Barré syndrome, with a reported rate as high as .4 per
 ,26
100,000 cases. Symptoms of Guillain­Barré syndrome typically occur  to  days after the GI symptoms resolve. Other autoimmune disorders
,27 potentially related to superantigens from foodborne pathogens include multiple sclerosis, rheumatoid arthritis, psoriasis, and Graves’ disease.
Infections with Salmonella, Yersinia, and Campylobacter may increase short­ and long­term risk of death, even after accounting for comorbid
 diseases.
WATERBORNE ILLNESSES
INTRODUCTION AND EPIDEMIOLOGY
Waterborne illnesses occur from ingestion or contact with contaminated water found in swimming pools, hot tubs, spas, and naturally occurring
 freshwater and saltwater during recreational use. Numerous bacteria, viruses, and protozoans arrive in the water by fecal contamination and cause infections. However, some species of bacteria are indigenous aquatic organisms such as Pseudomonas aeruginosa, Vibrio, Aeromonas,
 nontuberculous Mycobacterium, and Legionella.
Physiologic mechanisms intended to prevent infection from waterborne pathogens are the same as those discussed earlier for foodborne diseases in the pathophysiology section.
There were 493 recreational waterborne disease outbreaks in the United States reported to the Centers for Disease Control and Prevention in 2000 to

2014, which resulted in at least ,219 cases of disease and eight deaths. The majority of these outbreaks started in treated water sources (such as swimming pools) or from chlorine­tolerant organisms such as Cryptosporidium (which accounted for more than half of all cases). Legionella caused

16% of illnesses and 75% of deaths.
BACTERIA AND WATERBORNE ILLNESS

Implementation of water disinfection and filtration treatments reduced waterborne outbreaks from enteric bacteria. Waterborne infections from V.
 cholerae and S. typhi are now extremely rare in the developed world, but both remain a major cause of illness in developing nations.
Several enteric bacteria are commonly implicated in waterborne disease outbreaks in the United States. Campylobacter is found in virtually all surface waters due to contamination from wild bird feces and is the most common bacteria associated with recreational waterborne disease
  outbreaks. Several outbreaks of human campylobacteriosis came from contaminated drinking water. STEC can also be transmitted from ingestion
 or contact with water contaminated by farm animal feces. Shigella species, Salmonella species, and Yersinia enterocolitica are other enteric bacteria
 that can cause waterborne outbreaks. Most enteric bacteria, including E. coli O157:H7 and Campylobacter, are susceptible to chlorination.
Although V. cholerae is an enteric organism acquired from water with fecal contamination, many other Vibrio species are endemic in marine and
 estuarine waters. Vibrio species can cause diarrheal illnesses or skin infections. Vibrio vulnificus is associated with life­ and limb­threatening necrotic wound infections. The organism is found predominantly along the Gulf Coast and is acquired by patients with open wounds that are exposed to seawater. The wound infections are associated with a high rate of sepsis and amputation. Cirrhosis and high iron levels are associated with worse
 outcome.

Found in fresh and marine waters, Aeromonas species can cause gastroenteritis and wound infections. The majority of wound infections are simple
,37 cellulitis, but necrotizing infections and septic arthritis occur. In addition, immunocompromised patients may progress to develop peritonitis,
 cholangitis, and meningitis.
P. aeruginosa is an opportunistic pathogen found in freshwater, with immunocompromised patients at particular risk. In normal hosts,

Pseudomonas can cause otitis externa, keratitis in contact lens wearers, and folliculitis. Although Pseudomonas can contaminate drinking water, it does not cause a diarrheal illness in normal hosts.

Nontuberculous Mycobacterium exists in saltwater and freshwater and can cause illness. Mycobacterium marinum is associated with
 granulomatous skin infections, also called fish tank or aquarium granuloma (Figure 160­1). Mycobacterium avium complex is associated with

GI, pulmonary, or disseminated disease in immunocompromised patients, particularly patients with HIV.
FIGURE 160­1. Skin infection from Mycobacterium marinum (fish tank or aquarium granuloma). A painful indurated plaque is noted on the dorsal surface of the proximal thumb. (Reproduced with permission from Wolff K, Johnson RA: Color Atlas and Synopsis of Clinical Dermatology, 5th ed, © 2005, McGraw­
Hill, Inc., New York.)

Legionella is a common inhabitant of freshwater, including water that meets the standards for drinking. Infection occurs from inhalation of contaminated aerosols, resulting in one of two syndromes: Legionnaires disease and Pontiac fever. Pontiac fever is a flulike illness contracted by breathing mist that comes from a water source (e.g., air conditioning cooling towers, whirlpool spas, and showers) contaminated with the bacteria.
Further discussion of Legionnaires disease is available in Chapter , “Community­Acquired Pneumonia, Aspiration Pneumonia, and Noninfectious
Pulmonary Infiltrates.”
PROTOZOA AND WATERBORNE ILLNESS
Giardia lamblia is a common protozoal cause of waterborne disease in the United States and accounts for ,000 cases of diarrheal disease
 annually. It is frequently found in surface waters from mountain streams to municipal reservoirs and is resistant to common chlorination.
A form of giardiasis, often called “beaver fever,” can result from contamination of natural waters by animals such as beavers. Backpackers, campers,
 and travelers to disease­endemic areas are at high risk for waterborne giardiasis, as are children under  years of age. Community outbreaks often start out as a waterborne disease, but subsequent transmission commonly occurs from person to person. Giardia is associated with acute and chronic forms of gastroenteritis, although many patients infected with Giardia remain asymptomatic.

Cryptosporidium is an intracellular protozoan parasite and the most common cause of recreational waterborne GI illness in the United States. The
Centers for Disease Control and Prevention estimates 748,000 cases of cryptosporidiosis occur each year and result in hospital admissions costing

$45.8 million. The inoculum required to cause infection is low, and large numbers of oocysts are excreted in the feces of infected hosts. Standard doses of chlorine and zonation used in water treatment are not effective against Cryptosporidium, which explains its association with recreational
 water sources. Water filtration reduces the number of oocysts, but occasionally enough remain to be infective. Infection with Cryptosporidium in a normal host results in a self­limited diarrheal illness, and many exposures are asymptomatic. Immunocompromised patients may experience chronic
 diarrhea or life­threatening complications. Cyclospora, Isospora, and Microspora are other protozoan parasites that can cause severe disease in
 immunocompromised patients.
Entamoeba histolytica is a protozoan that causes intestinal amebiasis. It is a significant waterborne pathogen in developing countries, but in the
,46
United States, it is most commonly seen in migrants, travelers to endemic areas, men who have sex with men, and institutionalized patients.

Symptoms range from asymptomatic infection to severe dysentery. Fulminant colitis with bowel necrosis and perforation occurs in <1% of cases but
 has a mortality rate >40%. Seeding of the liver or brain can occur, particularly in men with underlying liver disease, resulting in the formation of
 amoebic hepatic abscesses.
Naegleria fowleri is a thermophilic organism found in warm and hot freshwater ponds that is responsible for rare but often fatal primary amoebic
 meningoencephalitis. Human disease occurs after inhalation of the trophozoites that invade the nasal cribriform plate, later digesting neurons.
Symptoms begin after a 1­ to 7­day incubation and include fever, headache, and altered mental status. Mortality rates approach 95% even with
 treatment.
ENTERIC VIRUSES AND WATERBORNE INFECTION

More than 100 enteric viruses are pathogenic in humans, many of which can be transmitted by drinking water and recreational water. Several enteric
 viruses, including the Norwalk virus and rotaviruses, are chlorine resistant. Outbreaks can happen with contamination of private wells and
 community water systems.
Hepatitis A and E trigger epidemic and sporadic infections from contaminated water. Infection from the hepatitis A virus typically results in an acute self­limited hepatitis, rarely leading to fulminant hepatic failure. Several outbreaks attributed to contaminated food led to an increased incidence of
 hepatitis A after a period of decline. Once considered a disease confined to tropical regions, the incidence of hepatitis E in developed countries is
 rising. In endemic and underdeveloped countries, morbidity and mortality from hepatitis E associated with pregnancy or preexisting liver disease are high due to hepatic failure.

Noroviruses, including the Norwalk virus, are the leading cause of acute gastroenteritis across all age groups. Outbreaks are often linked to
 contaminated drinking and recreational water, including on cruise ships. Rotavirus and enteric adenoviruses are other important waterborne enteric viruses. Noroviruses, rotaviruses, and enteric adenoviruses typically cause a self­limited gastroenteritis, although dehydration from these infections can be severe in children.
CLINICAL FEATURES OF WATERBORNE INFECTIONS
The majority of patients with waterborne disease present with nausea, vomiting, and diarrhea. Think of this cause in symptomatic patients with recent travel, outdoor activities such as camping or backpacking, recent recreational water use, or those using a private drinking water supply rather than municipal drinking water or bottled water. Patients with severe or chronic gastroenteritis symptoms may have immune deficiency caused by HIV or
 immunosuppressive drugs. In patients with bloody diarrhea, suspect invasive enteric organisms. Suspect Giardia and other protozoan parasites in
 patients with diarrhea lasting  or more weeks. Consider invasive amoebic organisms in patients presenting with altered mental status, meningeal signs, or peritonitis after recreational water exposure.
Physical examination seeks to identify signs of dehydration and any open skin wounds acquired in fresh or marine waters. The waterborne skin infections range in severity from simple cellulitis to necrotizing fasciitis. Patients with V. vulnificus present after recent exposure to saltwater with
 hemorrhagic bullae or signs of necrotizing infection (Figure 160­2). Clinical features of waterborne pathogens are summarized in Table 160­7. FIGURE 160­2. Skin infection from Vibrio vulnificus. V. vulnificus was cultured from the bulla aspirates from this patient with hemorrhagic and bullous skin lesions of the lower legs. (Reproduced with permission from Wolff K, Johnson R: Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 6th ed, © 2009
McGraw­Hill, Inc., New York.)
TABLE 160­7
Type of Transmission and Clinical Features Associated With Waterborne Pathogens
Drinking Recreational
Pathogen Clinical Features
Water Water
Campylobacter + + Gastroenteritis; can be associated with Guillain­Barré syndrome
Escherichia coli O157H7 + + Gastroenteritis; can be associated with hemolytic­uremic syndrome
Salmonella species + + Gastroenteritis, typhoid fever
Shigella species + + Gastroenteritis
Yersinia species + + Gastroenteritis
Vibrio species + + Gastroenteritis; skin infections
Aeromonas species + + Gastroenteritis; skin infections
Pseudomonas _ + Skin infections; nosocomial infections
Nontuberculous +/– + Skin infections; disseminated disease in immunocompromised
Mycobacterium
Giardia + + Acute and chronic gastroenteritis; asymptomatic carriage
Cryptosporidium + + Acute and chronic gastroenteritis, severe among immunocompromised
Entamoeba + + Acute and chronic gastroenteritis; rare fulminant colitis; liver or rare brain abscess
Naegleria fowleri +/– + Acute meningoencephalitis
Hepatitis A + + Acute hepatitis; rare liver failure
Hepatitis E + + Acute hepatitis; fulminant and severe in pregnancy
Enteric viruses + + Gastroenteri
DIAGNOSIS
Criteria for testing are the same as noted in foodborne illness and usually not needed. Viral antigen tests for rotavirus may be helpful in children with severe or persistent symptoms to distinguish viral from bacterial pathogens. Testing with a multipathogen molecular panel is indicated in patients with recent travel to endemic countries, immunocompromised status, or diarrheal illness of  or more weeks; during community­wide waterborne
,30 outbreaks; or in men who have sex with men. Because parasite excretion may not be continuous, three specimens separated by at least  hours may be needed to identify the causative pathogen when performing stool microscopic inspection.
The diagnosis of waterborne skin infections is based primarily on the patient’s physical examination findings and history of water exposure.
Identification of the causative agent can be attempted by Gram stain and wound culture (acid­fast staining if M. marinum is suspected). Reserve blood
 cultures for systemically ill patients and children less than  months of age.
TREATMENT
In most cases of acute gastroenteritis from waterborne pathogens, treatment is rehydration. Use empiric antibiotic therapy for patients with moderate
 to severe disease, recent travel history, or symptoms lasting more than  week; those needing hospitalization; and immunocompromised hosts.
Avoid antibiotics in cases of suspected E. coli O157:H7 due to an increased risk of development of HUS. Appropriate antibiotic regimens are  to  days of oral ciprofloxacin 500 milligrams twice daily, levofloxacin 500 milligrams once daily, or double­strength trimethoprim­
 sulfamethoxazole twice daily. Azithromycin 500 milligrams orally once daily for  to  days is used in pregnant women, children, and patients with
 travel to areas with fluoroquinolone­resistant Campylobacter (Thailand).

Antimotility agents can be given to adults without signs of invasive bacterial infection (bloody stools or fever). Probiotics, such as lactobacilli, may
 shorten the duration of diarrheal illnesses in adults and children.
Metronidazole is a common first­line treatment for infections from Giardia and Entamoeba. However, tinidazole is more effective and better tolerated
 for Giardia treatment (Table 160­5). Parenteral metronidazole is still used initially for invasive disease from Entamoeba. Paromomycin is an
 alternative to metronidazole and tinidazole in pregnant women. Other alternatives for Giardia and Entamoeba treatment include nitazoxanide and
 furazolidone. Albendazole is also effective for giardiasis, but not amebiasis.
Infections from Cryptosporidium are generally self­limited and usually do not require specific treatment in immunocompetent patients. However, use
 nitazoxanide or paromomycin in patients with prolonged infections, children, and the immunocompromised. For immunocompromised patients with Cryptosporidium, nitazoxanide or paromomycin alone or in combination with azithromycin is used. Initiation of highly active antiretroviral
 therapy is the first priority for Cryptosporidium treatment in patients with HIV. Treatment of meningoencephalitis from Naegleria fowleri includes
 amphotericin B (including intrathecal), rifampin, fluconazole, miltefosine, and azithromycin.
Treatment of waterborne skin infections includes empiric antibiotic administration (Table 160­8) and tetanus vaccination if needed. Consensus is that initial empiric antibiotic therapy is broad spectrum, including clindamycin in combination with a fourth­generation cephalosporin, an extended­
 spectrum fluoroquinolone (i.e., moxifloxacin), or an antipseudomonal penicillin (i.e., piperacillin­tazobactam). If V. vulnificus is suspected, treat with
 doxycycline and a fourth­generation cephalosporin. Use clarithromycin or doxycycline for most M. marinum infections, adding rifampin or
  ethambutol if severe. Patients with evidence of necrotizing infections need surgical consultation for operative debridement.
TABLE 160­8
Treatment of Waterborne Skin Infections
Clinical Features of Skin
Pathogen Treatment
Infection
Vibrio Cellulitis with hemorrhagic Doxycycline 100 milligrams IV twice per day plus fourth­generation cephalosporin; necrotizing vulnificus bullae, septicemia infections require emergent surgical debridement
Aeromonas Cellulitis, necrotizing wound Mild infections: ciprofloxacin 500 milligrams PO twice per day; severe infections: ciprofloxacin 400 species infections milligrams IV twice per day plus an IV antipseudomonal penicillin or fourth­generation cephalosporin; necrotizing infections require emergent surgical debridement
Pseudomonas Hot­tub folliculitis, cellulitis in Hot­tub folliculitis is usually self­limited. Severe infection: ciprofloxacin 400 milligrams IV twice per aeruginosa immunocompromised/diabetics day plus an IV antipseudomonal penicillin or fourth­generation cephalosporin
Mycobacterium Granulomatous skin infections Clarithromycin 500 milligrams PO twice per day or doxycycline 100 milligrams PO twice per day for  marinum mo; severe cases: combine with rifampin or ethambutol
DISPOSITION AND FOLLOW­UP
Most episodes of acute gastroenteritis secondary to waterborne pathogens are self­limited. Patients with systemic symptoms, severe dehydration, or comorbid illnesses or patients unable to tolerate oral fluids are bedded (admission or longer observation). Admit those with waterborne skin infections accompanied by systemic illness, suspected necrotizing findings, or comorbid conditions such as immunocompromised states.


