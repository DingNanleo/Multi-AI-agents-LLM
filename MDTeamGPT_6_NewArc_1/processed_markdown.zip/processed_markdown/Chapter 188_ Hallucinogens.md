## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 188: Hallucinogens
Utsha Khatri; David H. Jang
INTRODUCTION
The term hallucinogen is misleading. Hallucinogenic compounds rarely produce true hallucinations. Instead, users experience profound distortions in body image, sensory perception, and time perception, in addition to rapid, intense alterations in mood, increased intensity of any emotions, and heightened suggestibility. Hallucinogen is sometimes used interchangeably with the term psychedelic.
Hallucinogens are widely perceived as safe by the public and thus continue to be widely used. In fact, about  million Americans have used a
 psychedelic drug at least once in their lifetimes, or approximately 17% of all Americans between the ages of  and  years. In addition, hallucinogens
 account for approximately 7% of U.S. ED visits involving illicit drugs. However, these substances can cause dangerous physiologic effects resulting in
3­5 serious health consequences. The identity, purity, and amount of hallucinogenic compound are usually uncertain, and individual response can be unpredictable.

Hallucinogens in current use consist of both natural and synthetic compounds. The proliferation of “designer drugs”—chemical analogs or derivatives of illicit drugs marketed to circumvent existing drug laws—is a growing problem. Manufacturers of designer drugs try to circumvent U.S.
federal drug laws by stamping their product with advisories such as “not intended for human consumption” or by identifying the products as plant food, bath salts, or potpourri. Prosecution through the Federal Analog Act, a section of the Controlled Substance Abuse Act, can occur only if the drug is “intended for human consumption.” Because of this limitation in federal law, some states have moved to ban the sale of such agents.
In the past decade, there has been a renewed interest in studying the potential therapeutic effects of hallucinogens. Clinical studies have demonstrated efficacy of hallucinogens such as psilocybin and lysergic acid diethylamide (LSD) in treating depression, anxiety, and substance
 addiction, but this area of research is in its infancy.
Conditions that mimic hallucinogen intoxication include sedative­hypnotic withdrawal, anticholinergic poisoning, thyrotoxicosis, CNS infections,
 structural brain lesions, acute psychosis, hypoglycemia, and hypoxia. Some prescription and nonprescription medications can cause hallucinations.
,10
The identity of street drugs is often misrepresented, and substitution or adulteration of product is common.
,12
Drug­induced psychosis may be difficult to distinguish from primary psychotic disorders. A patient with substance­induced psychosis is more likely
 to have a diagnosis of dependence on any drug, report visual hallucinations, and have a history of parental drug abuse.
GENERAL APPROACH TO TREATMENT
ASSESSMENT
The assessment of the hallucinogen­intoxicated patient should begin with assessment of vital signs and general clinical stability. Although severe vital sign abnormalities are rare with hallucinogens, the most common disturbances are hypertension and tachycardia resulting from sympathomimetic surge. A core temperature should also be obtained. While rare in isolated hallucinogen use, hyperthermia suggests severe poisoning and requires immediate intervention to avoid complications.
Hypoxia and hypoglycemia, both alternative explanations for altered mental status, should be quickly identified and corrected. Serum chemistries, a venous blood gas, and a creatine phosphokinase should be considered, particularly if there is a concern for co­ingestions causing metabolic derangement or rhabdomyolysis. An ECG will be necessary to identify QRS or QT interval prolongation related to co­ingestants. Qualitative urine immunoassays are readily available for some of the described hallucinogens such as amphetamine analogs, but these tests are hampered by so many
 limitations (inaccuracy and inability to pinpoint remote versus recent hallucinogen use) that they rarely contribute to the management of acutely
Chapter 188: Hallucinogens, Utsha Khatri; David H. Jang p©o2i0so2n5e Md cpGatraiewn tHs.i lTl.h Ael lu Rseig ohft su rRinees iemrvmedu.n o Tasesramyss oshf Uousled * n Potr igvaucidye P colilnicicya * l mNoatnicaeg e * m Aecncte osfs pibailtiiteynts with suspected hallucinogen poisoning.
TREATMENT
Supportive care is the mainstay of treatment in most situations. Creating a calm environment with few external stimuli and providing reassurance until the drug effects wear off are often sufficient in mild cases. Because most hallucinogens are rapidly absorbed and most patients with adverse events do not present until several hours after ingestion, gastric decontamination is rarely indicated.
In moderate to severe cases, benzodiazepines are the preferred choice for chemical sedation because they possess no significant drug interactions, have no dystonic or anticholinergic adverse effects, do not prolong the QT interval or promote arrhythmias, and are reversible by flumazenil if oversedation occurs (although risk of inducing withdrawal in the benzodiazepine­tolerant individual should be a consideration). In the moderately to severely agitated patient in whom IV access has not been obtained, IM midazolam  to  milligrams should be given. In patients with IV access, starting doses of benzodiazepines are as follows:  to  milligrams IV of midazolam or lorazepam and  to  milligrams IV of diazepam. If the patient is severely agitated or hypertensive, doubling these doses is reasonable provided that continuous monitoring and frequent reassessments are made. See Chapter 287, “Acute Agitation,” for detailed discussion of agitation.
Antipsychotics such as haloperidol are frequently recommended as adjuncts for drug­induced delirium. Many antipsychotics (e.g., haloperidol) are potent dopamine receptor antagonists, which allows them to antagonize the psychiatric and psychomotor effects of select hallucinogens such as amphetamines. However, caution should be exercised when using antipsychotics because they can lower the seizure threshold, cause dystonia,
 precipitate dysrhythmias, and alter temperature regulation.
Hypertension often responds to judicious use of sedation with a benzodiazepine, but in refractory cases, it can be treated with phentolamine or a calcium channel blocker. Provide active cooling for significant hyperthermia. Treatment of severe agitation, hyperthermia, or seizures may require neuromuscular paralysis, ice baths, and endotracheal intubation. Seizures are treated with benzodiazepines or propofol. Patients with rhabdomyolysis require aggressive IV hydration to maintain urine output. Dantrolene is a potential treatment option for hallucinogen­induced
 hyperthermia, but evidence is limited.
DISPOSITION AND FOLLOW­UP
Compared with other abused psychoactive agents, hallucinogens have some of the largest acute safety ratios when lethal doses are measured against
 the doses customarily used to produce the desired effects. Most patients seen in the ED due to adverse reactions from hallucinogen use can be discharged into the custody of family or friends if they are lucid and in medically stable condition after a period of observation. Patients with persistent psychotic symptoms or comorbid psychiatric illnesses require psychiatric evaluation.
COMMON HALLUCINOGENS
Common hallucinogens are listed in Table 188­1. TABLE 188­1
Common Hallucinogens
Typical Hallucinogenic Duration Clinical Specific
Drug Complications
Dose of Action Features Treatment
Lysergic acid diethylamide (LSD) 20–80 micrograms 8–12 h Mydriasis Coma Reassurance
Tachycardia Hyperthermia Benzodiazepines
Anxiety Coagulopathy
Muscle tension Persistent psychosis
Hallucinogen persisting perception disorder
Psilocybin 5–100 mushrooms 4–6 h Mydriasis Seizures (rare) Reassurance
4–6 milligrams of psilocybin Tachycardia Hyperthermia (rare) Hydration
Muscle tension Benzodiazepines
Nausea and vomiting
Mescaline 3–12 “buttons” 6–12 h Mydriasis Rare Supportive
200–500 milligrams of Abdominal Benzodiazepines mescaline pain
Nausea and vomiting
Dizziness
Nystagmus
Ataxia
Methylenedioxymethamphetamine 50–200 milligrams 4–6 h Mydriasis Hyponatremia Benzodiazepines
(MDMA, “ecstasy”) Bruxism Hypertension Hydration
Jaw tension Seizures Active cooling
Ataxia Hyperthermia Dantrolene
Dry mouth Arrhythmias Specific
Nausea Rhabdomyolysis serotonin antagonists
Synthetic cathinone derivatives 50–300 milligrams of 2–4 h Agitation Paranoia Benzodiazepines
(“bath salts”) mephedrone Tachycardia Panic reactions Hydration
Hypertension Hyperthermia Active cooling
Diaphoresis Seizures
Mydriasis Hyponatremia
Rhabdomyolysis
Phencyclidine (PCP, “angel dust”) 1–9 milligrams 4–6 h Small or Coma Benzodiazepines midsized pupils Seizures Hydration
Nystagmus Hyperthermia Active cooling
Muscle rigidity Rhabdomyolysis
Hypersalivation Hypertension
Agitation Hypoglycemia
Catatonia
Marijuana (cannabis) 5–15 milligrams of 2–4 h Tachycardia Acute psychosis (rare) Supportive tetrahydrocannabinol (THC) Conjunctival Panic reactions (rare) Benzodiazepines injection
Synthetic cannabinoids (“K2,” 2–5 milligrams of JWH­018* 3–4 h Tachycardia Acute psychosis Supportive
“spice”) Conjunctival Panic reactions Benzodiazepines injection Seizures (rare)
Arrhythmias (rare)
Bromo­benzodifuranyl­ 200–800 micrograms 10–14 h Agitation Seizures Supportive isopropylamine (Bromo­DragonFLY) Hallucinations Vasoconstrictor with Benzodiazepines necrosis and gangrene
*One of the first synthetic cannabinoids (1­pentyl­1H­indol­3­yl)­1­naphthalenyl­methanone, goes by the term JWH­018. LYSERGIC ACID DIETHYLAMIDE
LSD is a potent psychoactive drug. As little as  micrograms produces psychedelic effects. The hallucinogenic effects are believed to be mediated
,17 through agonism at the serotonin type  (5­HT ) receptor.

LSD is a colorless, tasteless, odorless, water­soluble substance that is sold in various forms, but most commonly as small squares of dried blotter paper printed with colorful graphics and cartoons that have been perforated and soaked in liquid LSD solution. Each square typically delivers a dose of
 to  micrograms. Other forms include “microdots” (tiny tablets), “windowpane” (gelatin sheets), impregnated sugar cubes or candy, and small bottles of “breath drops” (the drug in solution).
,19
The psychedelic effects begin within  minutes of ingestion, peak within  hours, and last between  and  hours. Sympathomimetic stimulation
,19 with mydriasis and elevations of pulse, blood pressure, and temperature usually precede the psychedelic effects. While severe symptoms are uncommon in recreational use, marked facial flushing, mild gastric distress, piloerection, increased muscle tension, and hyperreflexia may occur. In
 massive overdoses (approximately >400 micrograms), coagulopathy, hyperthermia, seizure, coma, and respiratory arrest have been reported.

Although very rare, vasospasm resulting in peripheral ischemia and strokes has also been reported.
The psychedelic effects of LSD depend on the user’s prevailing mood, expectations, and surrounding environment. Effects may be perceived as pleasurable or horrifying. Predominant effects induced by LSD include visual hallucinations, audiovisual synesthesia, and derealization and depersonalization phenomena. Subjective well­being, happiness, and closeness to others are increased by LSD. However, profound distortions in perception of sensory stimuli, time, emotions, and memories also occur and may cause users to experience paranoia, depression, extreme panic, or an acute psychotic reaction known as a dysphoric reaction or “bad trip,” which can result in serious physical trauma or suicide. Prolonged and sometimes
 permanent psychosis, known as “flashbacks” or “hallucinogen­persisting perception disorder,” can result.
Diagnosis is based on history of use, the presence of sympathomimetic signs, and reported psychedelic effects. LSD can be detected in the urine for several days after ingestion using specific radioimmunoassay and enzyme immunoassay techniques. Reassurance and observation in a quiet, safe environment are generally the only interventions required to manage a dysphoric reaction. Oral or parenteral benzodiazepines are indicated for patients with extreme agitation or signs of excessive sympathomimetic stimulation. Patients with paranoid or psychotic symptoms lasting longer than  to  hours may require hospital admission. Medical complications due to massive overdose are rare, and recovery is usually rapid and requires only
18­20 supportive care. An important consideration is that certain drugs may also be sold for use on blotting paper as LSD such as the 2C­series (2C­I) and
N­2­methoxybenzylphenylethylamines (NBOMe). These agents are considered to be considerably more potent than LSD, and deaths have been
 reported.
PSILOCYBIN
Psilocybin is a naturally occurring hallucinogenic compound found in at least six genera of mushrooms, but most notably the Psilocybe genus.
Psilocybin is an indolealkylamine that is metabolized to the pharmacologically active compound psilocin. Both psilocybin and psilocin are believed to act as serotonin type  receptor agonists, similar to LSD.

Psilocybin­containing mushrooms grow naturally in the southern United States and Europe but can also be grown from kits sold over the Internet.
Most species of psilocybin­containing mushrooms turn bluish when bruised, but this is not a definitive method of identification or determination of potency. Psilocybin­containing mushrooms may be dried or cooked without losing potency. Hallucinogenic mushrooms sold on the street are often
 nonpsychoactive mushrooms that have been adulterated with LSD or phencyclidine (PCP). Because of the variation in mushroom size and concentration of psychoactive compounds, there is little correlation between the number of mushrooms ingested and the hallucinogenic effects. A user may ingest as few as five or as many as 100 mushrooms for a single “dose,” but the typical recreational dose is  to  milligrams, which corresponds to  to  grams of fresh mushrooms or  to  grams of dried mushroom powder.
,26
Hallucinogenic effects begin within  minutes of ingestion and last  to  hours. The hallucinogenic effects are similar to, although less powerful than, those produced by LSD. Other common effects include mydriasis, tachycardia, nausea, and vomiting. Serious medical complications are
 extremely rare but include seizures, hyperthermia, rhabdomyolysis, and renal failure. Mistaken identity and ingestion of highly toxic mushrooms are
 possible and can lead to serious outcomes.
Management is supportive. There is no routinely available screening test for psilocybin or psilocin in the urine. If the patient’s symptoms are not consistent with psilocybin ingestion, consider the possibility that a toxic mushroom (see Chapter 220, “Mushroom Poisoning”) or other psychoactive
 substances were ingested.
MESCALINE AND PEYOTE
Mescaline is found in many cacti, most notably the Mexican Peyote cactus (Lophophora williamsii) and the Peruvian San Pedro cactus (Trichocereus pachanoi). Peyote is used in Native American religious ceremonies, and its legal use is restricted to the Native American Church. Mescaline is a
 phenylethylamine, structurally related to amphetamines, making it chemically distinct from LSD. Mescaline is believed to act as a serotonin type  receptor agonist but is much less potent than LSD.
Peyote is most commonly sold as raw cactus or “buttons,” 2­ to 3­cm disks sliced off of the top of the cactus. Each button contains approximately  milligrams of mescaline. A typical hallucinogenic dose is 200 to 500 milligrams. Pills or capsules sold on the street as “mescaline” are unlikely to be
 genuine and may instead contain LSD or PCP. Peyote exposures reported to poison control centers are relatively rare compared with other drugs of
 abuse. In 2007, for example, only 116 peyote or mescaline exposures were reported out of more than .4 million total drug exposures.
Peyote is bitter tasting and within an hour of ingestion causes uncomfortable physical side effects—nausea, vomiting, abdominal discomfort, diaphoresis, dizziness, nystagmus, ataxia, and headache—that generally resolve after about  hours. Adrenergic stimulation causes mydriasis and mild elevations in pulse, blood pressure, and temperature. Hallucinogenic effects begin several hours after ingestion and persist for  to  hours.
Significant morbidity or mortality caused by the physiologic effects of mescaline has not been observed, but death can result from aberrant behavior
 while under the influence of the drug. Mescaline­intoxicated patients are managed supportively. Routine urine drug screens do not detect mescaline.
HALLUCINOGENIC AMPHETAMINES
More than  “designer” amphetamines have been created for their hallucinogenic properties. Very briefly, many amphetamine analogs share a phenylethylamine backbone. Phenylethylamines are chemical structures with an ethyl group that has an aromatic group and a terminal amine.
Additions and substitutions of select groups occur to modify the pharmacologic properties and can help to predict toxicity from these substitutions.
Best known is ,4­methylenedioxymethamphetamine (MDMA), a synthetic phenylethylamine derivative structurally related to both amphetamines and mescaline and commonly known by the street names “ecstasy,” “E”, “Adam,” “XTC,” “Molly,” and “MDM.” Other amphetamines similar to MDMA include ,4­methylenedioxy­N­ethylamphetamine (MDEA or “Eve”) and methylenedioxyamphetamine (MDA or “love drug”). MDMA is known for both its
 psychedelic properties and unique effects on mood and intimacy, which have led to its reputation as a “love drug” popular in dance clubs. MDMA has complex effects, interacting with dopamine, norepinephrine, acetylcholine, and β ­adrenergic and serotonin type 2A receptors and affecting the

 release of several hormones, including prolactin, oxytocin, adrenocorticotrophic hormone, dehydroepiandrosterone, and antidiuretic hormone.
MDMA is usually ingested as tablets in doses of  to 200 milligrams. The drug is colorless and tasteless—properties lending to its use as a date­rape
 drug. Symptoms occur within  minutes of ingestion and last about  to  hours. These include feelings of euphoria, inner peace, enhanced sociability, verbosity, and heightened sexual interest. The drug rarely causes actual hallucinations but can produce sensory effects such as alterations in the intensity of colors or sensation of textures. Other common effects include mydriasis, tachycardia, elevated blood pressure, nausea, jaw tension, bruxism, dry mouth, muscle aches, and ataxia. Current urinary amphetamine immunoassays incorporate a specific monoclonal antibody for MDMA and should routinely detect this drug.
35­38
MDMA and related amphetamines can produce serious complications and death. As with other amphetamines, large­quantity overdoses can cause
 severe hypertension, intracranial hemorrhage, and ischemia in the heart or brain. Fatal arrhythmias and sudden cardiac death have been reported,
,36 39­42 even in the absence of underlying heart disease. The most frequently cited causes of death are hyperthermia and hyponatremia. A syndrome of MDMA toxicity manifested by hyperthermia, seizures, disseminated intravascular coagulation, rhabdomyolysis, and hepatotoxicity has been
 described. This pattern shares many features of the serotonin syndrome, and combining MDMA with selective serotonin reuptake inhibitors
(see Chapter 178, “Atypical and Serotonergic Antidepressants”) or monoamine oxidase inhibitors (see Chapter 179, “Monoamine

Oxidase Inhibitors”) can precipitate serotonin syndrome. A purified or crystallized form of MDMA, known as Molly, is typically sold as a powder and is often taken orally. It is often viewed as a “safer form” of MDMA due to lack of adulterants, but it has been associated with adverse
 effects.
,40
Hyponatremia is predominantly due to excessive water consumption and inappropriate antidiuretic hormone secretion. Excessive water drinking
,41 from thirst can occur if the drug is taken at hot and crowded club venues, with vigorous dancing and profuse sweating. Chronic MDMA use results
 in permanent damage to serotonergic neurons. Neuropsychiatric studies of habitual users demonstrate long­lasting cognitive impairment and mood
 dysfunction, including memory impairment, diminished learning ability, and depression.

GI decontamination with activated charcoal may be useful if the drug was ingested within  minutes of ED arrival. Weigh benefits of charcoal against risk of vomiting and aspiration. Hypertension and tachycardia often respond to benzodiazepines. Severe hypertension is treated with IV phentolamine or nitroprusside. Rapid IV titration with high doses of benzodiazepines or propofol may be required to control symptoms in patients with refractory agitation or seizures. Arrhythmias are managed with standard therapy.
Check serum electrolyte concentrations and anticipate and treat abnormalities, especially hyponatremia (see Chapter , “Fluids and Electrolytes”).
,41
Hyperthermia is managed with cooling measures and fluid resuscitation. Patients with temperatures exceeding 40°C (104°F) have increased
 morbidity and mortality, so rapid cooling is important. Due to the lack of supportive evidence from controlled studies and the potential harms of administration of dantrolene, including significant respiratory muscle weakness, expert opinion no longer supports use of dantrolene in
  amphetamine­induced hyperthermia. Cyproheptadine has been suggested for treatment of the serotonin syndrome. See Chapter 178, “Atypical and Serotonergic Antidepressants,” for further discussion of serotonin syndrome.
SYNTHETIC CATHINONE DERIVATIVES: “BATH SALTS”
The abuse of cathinone is not new, as the young leaves and shoots of Catha edulis (khat) have been consumed for centuries in areas of Africa and the
Arabian Peninsula in order to achieve stimulant effects. The use of synthetic cathinones, particularly in Europe and the United Kingdom, however, gained popularity in the late 2000s. Calls to U.S. poison control centers peaked in 2012, and use has slightly declined in the subsequent years, but this
 ingestant remains a public health concern, especially among “club­goers” and young adults. Although cathinones were banned, manufacturers have
 frequently introduced new analogs; it has been estimated that nearly 250 such novel analogs are produced each year. Cathinone and synthetic derivatives, including mephedrone, methylenedioxypyrovalerone, and methylone, are chemically similar to amphetamines. The synthetic cathinones differ structurally from other amphetamines by the addition of a ketone at the β position; this decreases penetration of the blood–brain barrier due to increased polarity. These drugs likely stimulate the release and inhibit the uptake of biogenic amines such as norepinephrine, dopamine, and serotonin.
Synthetic cathinone derivatives are abused by individuals seeking a “legal” high with stimulatory effects similar to those of cocaine or methylenedioxymethamphetamine. To avoid legal complications, synthetic cathinones are described as “not for human consumption” and are often intentionally mislabeled as “bath salts,” “plant fertilizer,” “research chemicals,” or “plant food.” These drugs are given glamorous trade names such as “Bliss,” “Ivory Wave,” “Blue Silk,” or “Vanilla Sky” and sell for approximately $25 to $35 per 500­milligram package.
Synthetic cathinones are most commonly insufflated (“snorted”), ingested, or inhaled, and less commonly injected or absorbed. Duration of effects
 depends on method of use—1 to  hours with nasal insufflation and up to  hours if ingested. Users seek the subjective effects of increased alertness, openness, empathy, and libido. However, the adverse clinical effects can be very dangerous and are most commonly cardiac, psychiatric, and neurologic in origin. Due to the similarity to amphetamines, patients may exhibit a sympathomimetic toxidrome including agitation, psychosis, tachycardia, hypertension, and seizures. Hyperthermia and hyponatremia may also be present. Other reported symptoms include sweating, nausea, headache, chest pain, palpitations, tremor, memory loss, and suicidal ideation. Repeated use in some can lead to the development of “excited
 delirium,” a syndrome with symptoms of extreme agitation and violent behavior, which can rarely lead to cardiac arrest. Synthetic cathinones are not detected on routine urine toxicology screens.
Treatment is primarily supportive and includes cardiovascular monitoring as well as the general approach outlined earlier. Admission to a monitored or intensive care unit setting is appropriate for patients with severe and persistent symptoms.
In September 2011, the U.S. Drug Enforcement Administration issued an emergency order to place three synthetic cathinones (mephedrone, methylenedioxypyrovalerone, and methylone) temporarily into Schedule I under the Controlled Substances Act. This rendered illegal the manufacture, sale, or possession of these agents; this administrative action subsequently became law. In subsequent years, additional synthetic cathinones have been similarly assigned Schedule I status.
PHENCYCLIDINE
PCP is a synthetic piperidine derivative that is structurally related to ketamine. PCP does not fit easily into a single classification, as the drug combines
 features of hallucinogens, depressants, and stimulants. Unlike classic hallucinogens, PCP causes a clouding of the sensorium rather than heightened sensory awareness. The primary pharmacologic action is blockade of N­methyl­D­aspartate receptor channels. At high concentrations, PCP also interacts with other receptors and channels, including the opioid and acetylcholine receptors and voltage­gated electrolyte channels. PCP exhibits sympathomimetic effects by blocking reuptake of norepinephrine and dopamine.
PCP is easily and inexpensively synthesized. Powdered (“angel dust”) or liquid (“dippers”) drug is often combined with tobacco, marijuana, or other
 leafy materials and is usually smoked. PCP can also be ingested orally, snorted, or intravenously injected. PCP may be unknowingly ingested, due to
 its being sold as another drug or used as an adulterant in another illicit drug product. The onset of action depends on the mode of administration.
With smoking, a rapid initial peak in plasma concentrations occurs in  minutes, with a second peak (likely due to absorption from the lungs) at about
 minutes; effects generally last  to  hours. With large doses, effects can persist for days due to the drug’s lipid solubility and accumulation in fat
,58 stores.
,59
Patients may experience CNS stimulation or depression, with clinical presentations ranging from physical violence to catatonic or comatose states.
A combination of cholinergic, anticholinergic, and sympathomimetic effects causes a confusing clinical toxidrome. PCP is often coadministered with
 other drugs such as crack cocaine (“beam me up”), marijuana (“crystal supergrass”), or ethanol, which also complicates the clinical picture. The most common findings in PCP­intoxicated patients are altered mental status, hallucinations, multidirectional nystagmus, retrograde amnesia,
 hypertension (generally mild), and agitation. Feelings of detachment (dissociation) from the environment and self may give the user feelings of strength, power, and invulnerability. Violent actions, agitation, bizarre and unpredictable behavior, and hallucinations or delusions are frequent.
Diaphoresis, tachycardia, muscle rigidity, dystonic reactions, ataxia, and a decreased response to painful stimuli can occur. About 10% of patients are
 described as comatose. Pupil size is variable; it is noteworthy that widely dilated pupils (which may be expected due to sympathomimesis) are
 uncommon with PCP toxicity.
,59,60
Medical complications from PCP toxicity are frequent. Seizures occur in about 3% of patients, and up to 70% of cases exhibit rhabdomyolysis

(occasionally producing acute renal failure). Hypoglycemia, hypertension causing intracerebral hemorrhage, hyperthermia causing hepatic necrosis,
,58,60,61 and multiorgan failure can occur. Violent behavior can result in self­injury.
,56,59
Evaluate patients with suspected PCP toxicity for occult injury, hypoglycemia, and rhabdomyolysis. PCP can be detected by commercially
 available urine drug screens up to  days after single use and up to several weeks after long­term use. Cough and cold medications
(dextromethorphan, diphenhydramine, and doxylamine), analgesics (ibuprofen, meperidine, and tramadol), and psychotropics (imipramine, mesoridazine, thioridazine, and venlafaxine) cross­react with the drug screen and produce false­positive results.
Sedation and physical restraints are frequently required to control violent and aggressive behavior. Parenteral benzodiazepines are preferable to physical restraints because fighting against restraints may contribute to rhabdomyolysis. Treatment is generally supportive and follows the general outline provided earlier. Patients exhibiting only minor clinical features of PCP intoxication and no medical complications can be discharged when
,56,58,59 behavior normalizes. In a case series of 184 patients, 84% went home, 8% were admitted, and the rest were transferred to a crisis center.
MARIJUANA OR CANNABIS
Marijuana or cannabis consists of the dried leaves and flowers of the hemp plant Cannabis sativa. Hashish is prepared from the dried resin from the
 flower tops of this plant. The psychoactive ingredient in marijuana is tetrahydrocannabinol (THC).

Marijuana is most often smoked but can also be ingested. Symptoms persist for  to  hours after smoking, or longer if ingested. Clinical effects include drowsiness, euphoria, heightened sensory awareness, paranoia, and distortions of time and space. Hallucinations do not usually occur at usual doses. Common physiologic effects of marijuana are mild tachycardia, injected conjunctiva, bronchodilation, orthostatic hypotension, and
 impaired motor coordination. Medical complications, which are rare, include panic reactions, brief toxic psychoses, pneumomediastinum, and
,67 pneumothorax. Reporting of acute cardiac events associated with marijuana use is possibly the result of aging in the population of marijuana users and the increasing availability of medical marijuana. As of November 2017,  U.S. states, the District of Columbia, Puerto Rico, and Guam have authorized the medical use of marijuana, and as of January 2019, nine states and the District of Columbia have authorized its recreational use. Early
 studies in locations that have legalized marijuana have demonstrated increases in hospital admissions, ED visits, and calls to poison centers. An unintentional and concerning consequence in states that have adopted legalization has also been a significant increase in the number of pediatric
 exposures and ingestions.
Marijuana is used for treatment of medical conditions such as glaucoma and chemotherapy­related nausea and to promote weight gain in patients with human immunodeficiency virus infection and acquired immunodeficiency syndrome. Chronic cannabis use is associated with psychiatric,
 respiratory, cardiovascular, and bone effects. Cyclic vomiting syndrome, also called cannabinoid hyperemesis syndrome, is increasingly recognized
71­73 as an entity associated with cannabinoid overuse; it is characterized by cyclical vomiting, diffuse abdominal pain, and relief with hot showers.
Symptoms are often misdiagnosed as gastroparesis or opiate withdrawal, and patients often undergo extensive laboratory testing and advanced imaging. Expert consensus recommends that treatment should focus on education on the need for cannabis cessation. Capsaicin as a topical
 preparation is reasonable as a first­line treatment. Antipsychotics, including haloperidol and olanzapine, have been found to provide symptom relief
 in limited case studies.
Acute psychiatric symptoms due to marijuana use can generally be managed with reassurance alone, but benzodiazepines can be used for severe symptoms. Standard urine drug screens are unreliable indicators of acute marijuana intoxication. High lipid solubility results in extensive deposition within body fat and slow excretion in the urine. After a single use, THC is detected by commercially available urine screens for up to  days. With long­
 term use, cannabinoids can be detected up to a month or longer after abstinence. False­positive urine cannabinoid screening can occur due to use of ibuprofen, naproxen, pantoprazole, or efavirenz (a nonnucleoside reverse transcriptase inhibitor used to treat human immunodeficiency virus infection).
SYNTHETIC CANNABINOIDS
Around the world, there has been a dramatic increase in the demand, availability, and abuse of novel psychoactive drugs. This class includes synthetic cannabinoids, cathinone, and piperazine. Unlike THC, synthetic cannabinoids (variably known as “K2,” “spice,” or “fake marijuana”) are extremely potent. These synthetic agents are full agonists of the cannabinoid receptors, and as compared to THC, they cause more severe physiologic and psychological effects. One of the first synthetic cannabinoids, (1­pentyl­1H­indol­3­yl)­1­naphthalenyl­methanone, goes by the term JWH­018 for the
 initials of J.W. Huffman, who developed this compound to investigate drug–receptor interactions.
After being produced in the laboratory, synthetic cannabinoids are dissolved in a solvent and then sprayed on an assortment of dried plant leaves

(often with other preservatives and additives such as synthetic opioids and caffeine). They are sold in shops and on the Internet and labeled as
“incense” and “not for human consumption.” The appeal of such products is driven by the desire for a legal “high” that is not detectable by current urine drug assays.
The product is usually rolled in paper and smoked in a manner similar to marijuana. Effects begin within minutes and may last for several hours,
 generally disappearing within  hours. Most users will not seek or require medical attention, but some have experienced adverse reactions, with
 anxiety and tachycardia being the most common. Other reported adverse effects include hypertension, diaphoresis, tremulousness, and
,81 agitation. In 2018, there was an outbreak of unexplained and severe (including fatal) bleeding that was postulated to be due to contamination of synthetic cannabinoids with brodifacoum (a vitamin K antagonist).

In severe cases, patients may present in a semi­catatonic state and can be at risk for bradycardia, hypotension, renal failure, or secondary trauma.

Synthetic cannabinoids can precipitate psychosis in patients with prior mental illness. Symptoms are usually self­limited and short lived, and treatment is supportive. Tachycardia, agitation, and anxiety can be treated with benzodiazepines titrated to effect. Patients with severe psychosis may be treated with antipsychotics if deemed necessary. Patients with severe and persistent symptoms may require admission, but the vast majority can be discharged once they are awake and have normal vital signs.
In 2012, the enactment of the Synthetic Drug Abuse Prevention Act permanently placed  types of synthetic cannabinoids and stimulants into
Schedule I (most restrictive) of the Controlled Substances Act. However, effective regulation is difficult because new products (with unpredictable chemical formulas) are rapidly proliferating.
DESIGNER ALKALOIDS

Bromo­benzodifuranyl­isopropylamine, or Bromo­DragonFLY, is another phenylethylamine analog. Bromo­DragonFLY stimulates serotonin receptors in the brain, similar to LSD. Bromo­DragonFLY was developed as a research chemical to study the relationship between molecular structure and psychedelic activity. The name comes from its chemical structure—two furanyl rings with double bonds and a side amphetamine arm—which gives it the appearance of a dragonfly. In 2005, Bromo­DragonFLY became available in human experimental markets and was soon diverted to hallucinogenic use.
Bromo­DragonFLY is sold as a white to pink powder that can be snorted, smoked, or injected. Bromo­DragonFLY may also be sold on blotter paper, similar to LSD, which has led to confusion in users seeking LSD and mistakenly consuming Bromo­DragonFLY instead. Bromo­DragonFly is often used in combination with other drugs in an effort to enhance or prolong effects. The hallucinogenic dose of Bromo­DragonFLY ranges from 200 to 800 micrograms, with the onset of action within  to  minutes and a typical duration of hallucinogenic effects up to  to  hours. However, accounts of
 experiences lasting  to  days after consumption of a single dose have been reported. Toxicity includes agitation, hallucinations, and tonic­clonic
 seizures that may be delayed in onset. Bromo­DragonFLY acts as a long­acting vasoconstrictor that can cause necrosis and gangrene several weeks
 after use. Bromo­DragonFLY has been associated with fatalities in several countries. Two similar compounds, 2C­B­FLY and 3C­B­FLY, are also abused as hallucinogens.
Benzylpiperazine and trifluoromethylphenylpiperazine are synthetic phenylpiperazine analogs used as substitutes for amphetamine­derived designer
,88 drugs. These two compounds are usually combined and sold as “Legal X” in attempt to mimic the effects of MDMA. These drugs are legally available in many countries. Clinical findings include sympathomimetic effects such as palpitations, agitation, anxiety, confusion, dizziness, headache,
,89 tremor, mydriasis, insomnia, urinary retention, vomiting, and seizures.
Across Europe and the United States, Bromo­DragonFLY has been associated with deaths and delayed complications due to severe peripheral
 vasoconstriction and limb ischemia. Such complications are likely due to the agent’s potent serotonergic properties.
LESS COMMONLY ABUSED HALLUCINOGENS
Other drugs with hallucinogenic properties (Table 188­2) are enjoying increasing popularity due to Internet promotion of these “natural”
,90 psychoactive agents.
TABLE 188­2
Less Commonly Abused Hallucinogens
Onset of Duration of Additional Features
Hallucinogen Typical Route of Use
Action Action of Acute Toxicity
Salvia divinorum: salvinorin A Smoking of dried leaves 20–60 s 20–30 min Headache
(smoking) (smoking)
Chewed leaves held in sublingual (SL) or 10–20 min (SL 30–90 min (SL buccal location or buccal) or buccal)
Toad venom or eggs: bufotoxins Ingestion of toad venom extract or food 30–60 min 1–3 d Abdominal pain, made with toad eggs (nausea and (untreated) vomiting vomiting) Sympathomimetic effects
Features similar to cardiac glycoside toxicity
Ipomoea species (morning glory): lysergic acid Ingestion of seeds 1–2 h 6–10 h None amide
Nutmeg: myristicin Ingestion of seeds or ground spice 3–6 h 6–24 h Some features resemble anticholinergic toxicity
Datura species (Jimson weed and angel’s Ingestion of seeds 1–3 h 24–48 h Anticholinergic effects trumpet): scopolamine, atropine, and Smoking dried plant parts (ingestion) hyoscyamine  min
(smoking)
Ketamine Snorting dried powder or smoking of 5–15 min (nasal 45–60 min Sympathomimetic powder admixed with marijuana or insufflation) (nasal effects tobacco 1–3 min insufflation)
(smoking) 30–45 min
(smoking)
Dextromethorphan Ingestion of liquid 20–60 min 4–6 h Nausea, vomiting, and
Nasal insufflation of powder (ingestion) (ingestion) diarrhea
SALVIA

Salvia divinorum (“salvia,” “Sally,” “magic mint”) is a perennial herb in the mint family. Salvia is sold as seeds, plant cuttings, whole plants, fresh and dried leaves, and liquid extracts purported to contain the active ingredient salvinorin A. Although salvia and salvinorin A are not currently regulated under the U.S. Controlled Substances Act, a number of states have placed controls on the plant and extract. When chewed, the leaf mass and juice are retained within the mouth, and absorption of the active ingredient is rapid, causing clinical effects within  to  minutes. Dried leaves, as well as extract­enhanced leaves, can be smoked. Smoking pure salvinorin A at a dose of 200 to 500 micrograms results in effects that begin within  seconds and last up to  minutes. Desired effects include perceptions of bright lights, vivid colors and shapes, body movements, and object
,92,93  distortions. Adverse effects may include dysphoria, incoordination, dizziness, and slurred speech. Treatment is supportive.
BUFOTOXINS
Bufotoxins (bufotenine and 5­methoxy­dimethyltryptamine) are hallucinogenic tryptamines found in the venom, skin, and eggs of many toads (e.g.,

Bufo alvarius, Bufo marinus). Toad venom has also been used as an aphrodisiac (“love stone” or “rock hard”) and in some traditional Chinese medicines (chan su and kyushin). Venom can be obtained by “milking” the toad’s parotid glands and drying the liquid venom to form an extract. 5­
Methoxy­dimethyltryptamine is a powerful psychedelic, whereas bufotenine has weaker effects. In addition to psychoactive substances, the venom contains cardioactive steroids (bufagins or bufadienolides), catecholamines (epinephrine and norepinephrine), and noncardiac sterols (e.g.,
 cholesterol). Bufagins are cardioactive steroids that can cause cardiac toxicity similar to digoxin. Toxicity from toad venom varies considerably depending on the toad species and its geographic location.
Symptoms of toad venom poisoning occur almost immediately. Effects may be restricted to local GI irritation, with copious salivation, nausea, vomiting, and abdominal discomfort persisting for hours. Systemic toxicity may develop due to sympathomimetic effects. Cardiac toxicity is similar to acute digoxin poisoning, with hyperkalemia, bradycardia, atrioventricular conduction block, ventricular tachycardia, ventricular fibrillation, and
,98 cardiac arrest.
Serum digoxin immunoassay often yields a positive result. Bradyarrhythmias are initially treated with atropine and may require pacemaker placement.
Antiarrhythmic drugs should be used for ventricular arrhythmias. Digoxin­specific Fab antibody treatment has been effective in animal models and
,100 human cases.
MORNING GLORY SEEDS AND IPOMOEA SPECIES
Morning glory seeds (Ipomoea violacea, Ipomoea tricolor, and others) contain lysergic acid amide (ergine), a compound closely related to LSD. The seeds can be ingested for their hallucinogenic effects; typically, several hundred seeds are ingested as one “dose.” Physical and psychological manifestations closely resemble the effects of LSD, and patients are managed similarly.
MYRISTICIN
Nutmeg is the dried seed from the tropical Myristica fragrans tree. Accidental or intentional ingestion of large amounts of nutmeg can cause delirium
101 with hallucinations. Misuse of nutmeg is more commonly encountered among college students, adolescents, and prisoners, often when ethanol or
102 other recreational drugs are not available. The hallucinogenic properties of nutmeg may be due to the component myristicin, but the mechanism is not well understood. Ingestion of one to three nutmeg seeds (or  to  grams of the ground spice) produces psychological effects that begin  to  hours later and last for  to  hours. Symptoms include tachycardia, flushing, dry mouth, nausea, and abdominal pain. Signs and symptoms may resemble anticholinergic poisoning, but pupils are usually small or midsized. Management is supportive care.
DATURA SPECIES
Jimson weed (Datura stramonium) and angel’s trumpet (Datura candida) are plants that originated in the United States and Mexico but have spread worldwide throughout areas with warm and temperate climates. All Datura species contain the anticholinergic alkaloids atropine, scopolamine, and hyoscyamine. Seeds or other parts of the plant can be ingested or smoked and produce delirium, hallucinations, and seizures along with other classic anticholinergic effects, such as mydriasis, tachycardia, dry mouth and skin, blurred vision, urinary retention, and hyperthermia (see Chapter
103,104
202, “Anticholinergics”). Gastric emptying is often delayed, and the small, plentiful seeds can become trapped among the GI folds after ingestion; thus, GI decontamination can be considered in select cases. Whole­bowel irrigation is recommended for patients who have ingested a large number of seeds. Medications with anticholinergic properties, such as phenothiazines, should be avoided. Physostigmine, a reversible
104 acetylcholinesterase antagonist, is a potential treatment for severe anticholinergic poisoning. For further discussion, see Chapter 202,
“Anticholinergics.”
KETAMINE AND DEXTROMETHORPHAN
Ketamine and dextromethorphan are chemically related to PCP. Ketamine and PCP are described as dissociative drugs because they distort
,105 perceptions of sight and sound and produce feelings of detachment from the environment and self. Ketamine, known by the street names
“vitamin K” and “special K,” can be abused by SC or IM injection, nasal insufflation of the dried powder, or smoking of the dried power admixed with
106 107 marijuana or tobacco. Ketamine abusers may come to the ED because of anxiety, palpitations, and chest pain. Ketamine is thought to be psychologically addictive. Chronic abuse can cause GI toxicity including epigastric pain, hepatic dysfunction, and impaired gallbladder activity; urinary
108 tract effects include ketamine cystitis.
109,110
Dextromethorphan, available in over­the­counter cough suppressants, has become popular among adolescents. A large quantity must be ingested for the user to experience hallucinogenic effects. Abuse among youths has prompted many states to enact restrictions regarding the buyer age and the maximum amount that can be purchased; most retailers and pharmacists keep dextromethorphan­containing cough medicines behind the counter. Since dextromethorphan­containing symptomatic relief products often contain other ingredients (e.g., antihistamines, acetaminophen), investigate for toxic amounts of a co­ingestant in any patient who has ingested hallucinogenic doses of dextromethorphan. Medical care is primarily supportive with treatment as outlined earlier in the general approach section.


