## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 81: Acute Appendicitis
E. Paul DeKoning
INTRODUCTION AND EPIDEMIOLOGY

Between 250,000 and 300,000 appendectomies for acute appendicitis are performed each year in the United States, with an additional 700,000
 patients affected in the European community. The lifetime risk of acute appendicitis in the United States is an estimated 12% for males and 25% for
 females. Yet, the epidemiology of this common ED diagnosis continues to change. Data suggest a reversal of a previous decline in incidence, with the
  annual rate increasing from .62 to .38 per ,000 between 1993 and 2008, whereas the rate of negative appendectomy has declined. Similarly,
,6 between 2001 and 2008, the rate of perforation decreased, but this declining trend has not been consistent. Acute appendicitis is most common in
  patients age  to  years, remains the most frequent cause of atraumatic abdominal pain in children >1 year old, and is the most common
,9 nonobstetric surgical emergency in pregnancy, complicating up to  in 1500 pregnancies. Despite advances in lab testing and imaging, accurate diagnosis is a challenge. Both “missed appendicitis” and unnecessary surgery for a false diagnosis are not without consequence. Thus, consider appendicitis in any patient with acute atraumatic abdominal pain without prior appendectomy.
PATHOPHYSIOLOGY
Luminal obstruction of the vermiform appendix, typically by a fecalith, is considered the traditional cause of appendicitis. Continued secretion from the luminal mucosa results in increased intraluminal pressure and appendiceal vascular insufficiency, leading ultimately to bacterial proliferation and inflammation. Left unchecked, perforation may occur. While certainly the cause in many instances, the traditional pathophysiology of luminal
,11 obstruction may be more the exception than the rule; the full range of specific causes remains unknown. Other known causes include obstruction by lymphatic tissue, gallstone, tumor, or parasites.
Visceral innervation produces the vague, hard to localize periumbilical or central abdominal discomfort frequently observed early in the clinical course. Progressive inflammation and subsequent irritation of the somatically innervated parietal peritoneum produces the classic migration of pain to the right lower quadrant, to McBurney’s point, located one third of the distance from the anterior superior iliac spine to the umbilicus. Up to 50%
 of patients may have an atypical presentation due in part to anatomic variation. For example, a retrocecal appendix produces right flank or pelvic pain, whereas malrotation of the colon results in transposition of the appendix and, subsequently, pain to the left upper quadrant. Abdominal organ displacement from a gravid uterus may lead to right upper quadrant tenderness in pregnancy. Even so, a right lower quadrant location of pain remains
 the most common location of pain in pregnant women with appendicitis.
CLINICAL FEATURES
The signs and symptoms of acute appendicitis lie along a spectrum that correlates with pathophysiology. Early on, patients classically complain of nonspecific symptoms of general malaise, indigestion, or bowel irregularity. Anorexia is common but not universally present. Alterations in bowel
 function are highly variable and can include constipation, diarrhea, and even obstruction as a late complication. Periumbilical or central abdominal
 pain generally develops after nonspecific symptoms. If nausea develops, it typically follows the onset of pain. Vomiting may or may not be present.
Subjective or objective fever is frequent.
As the clinical course progresses, discomfort traditionally migrates to the right lower quadrant. Flank pain, dysuria, or hematuria can occur, given the
 typical proximity of the appendix to the urinary tract.
Aggravating and alleviating features can help establish the diagnosis: worsening pain with deep inspiration may be present if there is peritoneal
 irritation, and individuals may state that the trip to the hospital was painful, particularly when encountering bumps in the road. Such features suggest
Chapter 81: Acute Appendicitis, E. Paul DeKoning a peritoneal process is under way. The release of intraluminal obstruction with perforation often results in sudden alleviation of pain; consider
. Terms of Use * Privacy Policy * Notice * Accessibility
 appendiceal perforation if the patient’s pain has suddenly improved. Examination findings evolve with the clinical course. Progressive inflammation and peritoneal irritation yield reproducible tenderness to palpation in the right lower quadrant. The exception to right lower quadrant pain is a
 retrocecal appendix, which does not contact the anterior parietal peritoneum. Rebound tenderness and involuntary guarding suggest peritonitis.
Patients may have costovertebral tenderness, and percussion of the right heel or shaking of the hospital stretcher may elicit abdominal pain. There is
 no evidence that the digital rectal exam aids significantly in the diagnosis of acute appendicitis. Rovsing’s sign reproduces pain over McBurney’s point as the clinician palpates the descending colon in the left lower quadrant. A positive psoas sign or obturator test suggests an inflammatory peritoneal process. The psoas sign is elicited if abdominal pain is produced with passive extension of the right leg at the hip while the patient lies on the left side. The obturator test elicits pain with passive internal and external rotation of the flexed right thigh at the hip. The presence of abdominal rigidity, a positive psoas sign, fever, or rebound tenderness increases the likelihood of acute appendicitis. Prior episodes of similar pain, the absence of right lower quadrant pain, and the absence of classic pain migration make appendicitis less likely. The presence or absence of any exam finding in isolation is neither sufficiently sensitive nor specific to rule out or rule in the diagnosis.
In a systematic review of  studies investigating appendicitis in patients age  years or younger, fever was the single most useful sign, with a positive likelihood ratio [LR(+)] of .4 (95% confidence interval [CI], .4 to .8), whereas its absence decreased the likelihood of appendicitis (negative likelihood
 ratio [LR(–)], .32; 95% CI, .16 to .64). Rebound tenderness and pain migration to the right lower quadrant were also strong predictors. In comparison, a classic study of exam findings in adult patients showed right lower quadrant pain as the single most useful sign (sensitivity, .81; specificity, .53; LR(+), .31 to .46; LR(–),  to .28), followed by rigidity and migration of pain. Fever in adults had an LR(+) of .94 (95% CI, .63 to .32)
 and a LR(–) of .58 (95% CI, .51 to .67). In both children and adults, however, no single historical or physical examination finding is
,17 sufficient to rule in or rule out appendicitis. Their utility is increased in combination.
DIAGNOSIS
Despite the advent of cross­sectional radiographic imaging and high­definition ultrasonography and a more than doubling of their use in recent years,
 detection rates for appendicitis have essentially remained the same. There are numerous appendicitis mimics, and the differential diagnosis is broad
(Table 81­1). Perform a complete physical examination, including a pelvic examination in women of childbearing age. Acute appendicitis is largely a clinical diagnosis, and no one adjunctive test is universally indicated.
TABLE 81­1
Differential Diagnosis of Right Lower Quadrant Pain
GI
Cecal/Meckel’s diverticulitis
Cecal volvulus
Colitis/terminal ileitis
Constipation/ileus/bowel obstruction
Crohn’s/ulcerative colitis flair
Epiploic appendagitis
Functional abdominal pain
Incarcerated inguinal hernia
Intra­abdominal abscess
Intussusception
Malrotation
Mesenteric lymphadenitis
GU
Ectopic/heterotopic pregnancy
Ovarian torsion
Ovarian vein thrombosis
Pyelonephritis
Referred testicular pain
Renal colic
Tubo­ovarian abscess/salpingitis
Musculoskeletal
Abdominal wall/rectus sheath hematoma
Psoas abscess
Consider appendicitis in any patient with atraumatic right­sided abdominal, periumbilical, or flank pain who has not previously undergone appendectomy. Available diagnostic adjuncts include peripheral WBC and other acute inflammatory markers (e.g., C­reactive protein or erythrocyte sedimentation rate), urinalysis, and a pregnancy test. Diagnostic imaging should be considered in atypical presentations or if significant diagnostic uncertainty exists after thorough history and examination.
SCORING SYSTEMS
Scoring systems, such as the Alvarado and Samuel scores, have been developed to aid in diagnosis. The modified Alvarado score for acute appendicitis ranks symptoms (migration,  point; anorexia or urinary acetone,  point; nausea or vomiting,  point), signs (right lower quadrant
 tenderness,  points; rebound,  point; fever,  point), and WBC count (>10,000/mm ,  points) into low­risk appendicitis (score,  to 4) and possible or probable appendicitis (score,  to 9). However, the low­risk score (score,  to 4) was demonstrated as only 72% sensitive compared to a sensitivity of

93% for clinical judgment when appendicitis was either the most likely or second most likely diagnosis. Despite continued technologic advances and development of decision rules, different scoring systems often yield conflicting results and should not replace clinical judgment; the clinical
20­23 impression of the experienced physician has the highest impact on patient outcome.
LABORATORY TESTING

An increase in peripheral WBC may be the earliest marker of inflammation. A study of 722 children identified both prospectively and retrospectively
 found acute appendicitis to be the most common diagnosis in children >4 years old with nontraumatic abdominal pain and leukocytosis. However, a
 normal WBC is not uncommon, and leukopenic presentations have been documented. While numerous studies have evaluated the use of the
,25,27­29 
WBC, there is no clear consensus on its utility. WBC does not distinguish between simple and perforated appendicitis. A C­reactive
 protein >10 mg/L in children <6 years old may be of value in predicting acute appendicitis ; however, C­reactive protein and the erythrocyte sedimentation rate used alone lack the sensitivity and specificity to rule in or rule out the diagnosis. If the only diagnostic consideration is acute
 appendicitis (yes or no), the greatest utility of laboratory tests may be in combination ; an elevated WBC and/or C­reactive protein may have a combined sensitivity as high as 98%. Normal values of both in patients with a low pretest probability of acute appendicitis make pathologically
,32­35 confirmed appendicitis very unlikely. However, WBC and C­reactive protein levels are elevated in a number of other appendicitis mimics, so
,37 these markers are not useful if the differential diagnosis of pain is broad. Other novel biomarkers have not yet demonstrated consistent utility in
,31 the diagnosis of acute appendicitis to warrant routine use.
Obtain a urinalysis because isolated microscopic hematuria may support a diagnosis of renal colic, and pyuria may suggest pyelonephritis. However,
 hematuria or sterile pyuria can be present in acute appendicitis. Document a negative pregnancy test in females of reproductive age to rule out ectopic or heterotopic pregnancy. Other laboratory tests are not routinely indicated but may be beneficial when considering other diagnoses.
IMAGING
Obtain early surgical consultation before imaging in straightforward cases of suspected appendicitis in adults. Imaging is not
38­40 universally necessary but may be of benefit in certain populations. In children, some centers prefer pediatric surgery consultation prior to imaging with ionizing radiation.
When adjunctive imaging is indicated, early surgical consultation may aid guidance in imaging selection. The goal of imaging is to establish the diagnosis of appendicitis, avoid a negative appendectomy, identify perforation, and exclude other causes of abdominal pain with minimal radiation, cost, and time.
Plain radiography is not helpful. Findings are typically nonspecific but may demonstrate a nonspecific bowel gas pattern or adynamic ileus. An
 appendicolith may be visualized in up to 50% of children with appendicitis.
US
 ,43
Graded compression US should be the initial imaging modality of choice in both pregnant females and children. It should
 likewise be considered in young, nonobese adults. Reports of the effectiveness of US diagnosis of appendicitis in pregnancy are conflicting,
  with some reporting US as useful and others reporting it as ineffective for diagnosis. POCUS is increasingly present in EDs, and more emergency physicians are experienced in performing and interpreting these studies. POCUS can be of utility in experienced hands in ruling in appendicitis.
46­48
However, like other testing modalities, it should not be used as a stand­alone test to rule out the diagnosis. Regardless, US is safe, fast, welltolerated, and cost­effective.
The appendix is oval in the axial plane, ends blindly in the longitudinal plane, and should be compressible with a maximal diameter not exceeding 
 mm. The normal appendix is typically differentiated from small bowel on US by the absence of peristalsis and the lack of change in configuration over time; its small size distinguishes it from large bowel. Typical findings in appendicitis are a thickened, noncompressible appendix >  mm in
 diameter (Figure 81­1). Doppler US may illustrate hyperemia. It is important to image the entire length of the appendix, because inflammation
 may be more pronounced at or localized to the distal end. Given the highly operator­dependent nature of US, centers treating larger volumes of children may have greater reproducibility of high­quality studies. The diagnostic accuracy of abdominal US in children is better at ruling in acute
 appendicitis than excluding it. Besides operator skill, other limitations to accuracy include cases of retrocecal appendicitis or perforation, excessive abdominal guarding or bowel gas, a gravid uterus or obese habitus, a decompressed bladder, and lack of patient cooperation. Perforation may lead to disappearance of specific imaging hallmarks and difficult visualization of the appendix on US. Pelvic US may be useful in cases of
  suspected appendicitis and a nondiagnostic abdominal US or CT, or in the differentiation of appendicitis from pelvic inflammatory disease (see
Chapter , “Abdominal and Pelvic Pain in the Nonpregnant Female”).
FIGURE 81­1. Ultrasonographic demonstration of acute appendicitis. A noncompressible, inflamed appendix (red circles) is shown in a cross­sectional view (A; .5
MHz) and a longitudinal section (B; .5 MHz). Mural lamination of the swollen appendix is maintained in the early stages of acute appendicitis. C. An appendicolith (arrow) with acoustic shadowing is demonstrated (5 MHz). [Reprinted with permission from Ma OJ, Mateer JR, Reardon RF, Blaivas M.
Emergency Ultrasound. 3rd ed. Copyright . Chapter , General Surgery Applications, Figures
11­31A&B & 11­33.]
Abdominopelvic CT
In most adult males and nonpregnant females for whom the diagnosis of appendicitis is not sufficiently clear, consider abdominal CT that includes the abdomen and pelvis. Typical CT findings include a dilated appendix >6 mm with a thickened wall, periappendiceal inflammation, and potential
 visualization of an appendicolith or abscess. Luminal obstruction and dilation may be relieved in cases of perforation, leading to disappearance of
 specific imaging hallmarks and difficult visualization of the appendix on CT.
The accepted sensitivity of CT (composite studies using PO or IV contrast or no contrast) for the diagnosis of acute appendicitis is typically >94%, with a
,40 positive predictive value >95% (Figure 81­2). In a comparison of CT versus US, the overall sensitivity of CT in patients >2 years old was 96%, with a
96% positive predictive value; graded compression US had an overall sensitivity of 86%, with a 95% positive predictive value. In this same study, women who had preoperative imaging had a statistically significant lower negative appendectomy rate than women who had no imaging, suggesting that
 women with suspected acute appendicitis derive the greatest benefit from preoperative imaging. The 2015 American College of Radiology
Appropriateness Criteria for right lower quadrant pain state that although US is the preferred initial imaging modality in children, CT is overall the most
 accurate imaging modality for suspected appendicitis. Appendiceal CT, a less frequently used protocol, uses rectally administered contrast only with acquisition of thin cuts through the right iliac fossa. This avoids the difficulties of PO contrast administration in patients with active emesis and prevents potential adverse reactions of IV contrast. Time to acquisition of images is much shorter, typically around  minutes after administration of
,56 rectal contrast, but may produce significant patient discomfort.
FIGURE 81­2. Acute appendicitis on contrast CT scan as evidenced by dilated and inflamed appendix (red circle).
PO and IV Contrast Versus Nonenhanced CT
PO contrast medium has historically been recommended for CT of the abdomen and pelvis when investigating a broad differential of GI or pelvic diagnoses, and many centers continue to recommend CT imaging with both IV and PO contrast. Yet, the current body of literature does not support this
57­62 as routine practice, and multiple studies indicate that nonenhanced CT has excellent performance in the diagnosis of acute appendicitis. The imaging evaluation of abdominal pain is time intensive and impacts ED overcrowding. Unenhanced studies can significantly decrease the time to diagnosis and eliminate patient discomfort from PO (especially in vomiting patients) or rectal contrast, and avoids altogether the risk of renal injury from IV contrast. More than 52% of 462 patients who underwent CT imaging in at least one study had no PO, IV, or rectal contrast administered, with a combined sensitivity of 93% and a positive predictive value of greater than 92%, supporting the suitability of nonenhanced CT imaging for making the
 diagnosis. A comparison of nonenhanced CT with findings on laparoscopy reported 95% sensitivity and 100% specificity of nonenhanced CT in
 suspected appendicitis, whereas another systematic review reported a pooled sensitivity of .7% (95% CI, .5% to .0%) and specificity of .1%

(95% CI, .2% to .5%). Another systematic review of  studies showed equivalent or improved diagnostic performance of nonenhanced CT when
 compared to PO contrast. PO contrast frequently does not reach the terminal ileum at the time of imaging, yet in this group of patients, at least one
 author has shown no diagnostic compromise in the performance of imaging. Several studies attribute disagreement between nonenhanced CT and
,63 contrasted studies more to interobserver variability than contrast medium. Furthermore, the 2015 American College of Radiology Appropriateness

Criteria favor the use of IV contrast but do not endorse enteric contrast when IV contrast is used. Noncontrast CT should be considered an acceptable imaging modality in the workup of acute appendicitis. In patients with renal insufficiency or dye allergy, administration of IV contrast is contraindicated. Body habitus may limit reproduction of noncontrast CT test characteristics; intraperitoneal fat serves as an intrinsic
,55,64 contrast medium in unenhanced CT, and its paucity in very thin patients can affect imaging interpretation.
MRI
Consider MRI as another reliable imaging technology in the evaluation of acute appendicitis, particularly in pregnant women. MRI may be applicable to
 pediatric patients >5 years of age at tertiary hospitals with MRI capability and is also a reasonable option after equivocal US. MRI avoids ionizing radiation and visualizes the entire abdomen in multiple planes. In a survey of U.S. academic medical centers with radiology residency programs, MRI was preferred over CT (39% vs 32%) for evaluation of appendicitis in the first trimester of pregnancy. This preference reversed in the second and third
  trimesters. IV gadolinium crosses the placenta and is not used in pregnancy given the teratogenic effects seen in animal studies.
Gadolinium is not given to patients with renal insufficiency because it may cause nephrogenic fibrosing dermopathy. Avoid MRI in the evaluation of the unstable patient given the time necessary for study acquisition. Sedation may be required for small children, rendering it impractical in many pediatric cases. However, the continued advancement of technology and scanning technique has resulted in the ability to perform faster
 studies without the need for contrast media or sedation and the traditional adverse impact on ED throughput.
TREATMENT
Patients with acute appendicitis typically require appendectomy, so immediate surgical consultation is needed. Patients should be maintained as
“nothing by mouth” to avoid operative delay. Provide resuscitation and maintenance IV fluids with appropriate antiemetics and analgesia. Initiate perioperative antibiotics upon diagnosis or if the patient exhibits signs of peritonitis. Appropriate choices should broadly cover aerobic and anaerobic gram­negative organisms. Acceptable regimens include ampicillin/sulbactam  grams IV (pediatric dose,  milligrams/kg IV); piperacillin/tazobactam

### .5 grams IV (100 milligrams/kg IV); cefoxitin  grams IV (40 milligrams/kg); or metronidazole 500 milligrams IV plus ciprofloxacin 400 milligrams IV.
Given the nonoperative management of uncomplicated diverticulitis, salpingitis, and neonatal enterocolitis with antibiotics, some suggest a similar
 nonoperative approach to uncomplicated acute appendicitis. A nonoperative approach is also occasionally used for older, sicker patients who are considered high­risk surgical candidates. However, recent reports suggest that the features that make these patients “high risk” in the first place may
,68 actually make them even higher risk nonoperative patients with worse outcomes. Numerous studies including randomized clinical trials have yet to provide sufficient evidence to support the routine use of nonoperative management. While an antibiotics­only approach
69­74 may be feasible and safe in select, uncomplicated patients, surgical management remains the accepted standard of care.
DISPOSITION AND FOLLOW­UP
Surgery is the accepted standard of care for acute appendicitis. If the local surgical services are inadequate or unavailable, transfer the patient to an appropriate institution. For the patient in whom the diagnosis remains elusive despite a rigorous diagnostic evaluation, consider extended observation in the ED or hospital with serial examinations, allowing for evolution of the patient’s condition. Alternatively, the stable, reliable patient without significant comorbidities may be a candidate for discharge provided they have a scheduled return visit to the ED or their primary physician
(typically within  hours) for repeat examination. Patients must have adequate pain control and be able to tolerate oral hydration. Provide clear abdominal pain discharge instructions, including a list of concerning signs or symptoms that should prompt earlier return to the ED.
SPECIAL POPULATIONS
Uninsured/underinsured patients, individuals from low­income communities, and some ethnic minorities may be more likely to develop
,75 appendiceal perforation, but previously observed trends have been inconsistent in recent years. The elderly are likely to have preexisting comorbidities that alter presentation, management, and outcomes. Institutionalized patients, those with communication difficulties, those with poor access to medical care, and the elderly may have more vague complaints, including diffuse pain, fever, or alteration in mental status. Such individuals
 commonly present later in the course of the disease and are more likely to have worse outcomes. In such patients, an “atypical” presentation should be considered the norm. A low threshold for prolonged observation or admission can avoid unnecessary morbidity and mortality.
Pregnant women warrant special attention. Acute appendicitis is the most common surgical emergency in pregnancy, and delay in diagnosis is the
,9,77 greatest cause of increased morbidity in the pregnant woman with an acute abdomen. Ovarian torsion and ectopic or heterotopic pregnancy are additional considerations. If abdominal US is nondiagnostic, consider pelvic US, CT, or MRI. Consult with the radiologist to select the most appropriate
 imaging study. Many radiologists avoid CT in the first trimester given teratogenic concerns of ionizing radiation. In addition, although iodinated
 contrast material is safe in pregnancy, avoid IV gadolinium.
Children are a diagnostic challenge, particularly if they cannot adequately verbalize their complaints. In such cases, physical examination, parallel history from the parent or guardian, and a high index of suspicion are the keys to accurate diagnosis. Pediatric imaging should begin with US, but many centers advise early surgical consultation before any ionizing imaging if appendicitis is a consideration.


