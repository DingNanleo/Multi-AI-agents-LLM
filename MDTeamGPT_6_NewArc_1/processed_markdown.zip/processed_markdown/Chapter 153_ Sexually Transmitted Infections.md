## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 153: Sexually Transmitted Infections
Karen D. Serrano
INTRODUCTION
Content Update: December 2020 CDC Treatment Changes January 2021
As of December , 2020, the Centers for Disease Control and Prevention has changed treatment recommendations for gonorrhea and chlamydia due to increasing antimicrobial resistance. Table 153­2 lists new treatment recommendations. For full information, see references  and , or go to
MMWR, Dec , 2020, vol , #50, 1911­1916. Sexually transmitted infections (STIs) are a major public health problem. In 2016, there were .59 million cases of chlamydia infection, 468,514 cases of
 gonorrhea, and ,814 cases of syphilis reported in the United States. The World Health Organization estimates that 357 million people are infected
 each year by a curable STI.
The primary medical goals are identifying and treating STIs, but important secondary goals include preserving future health (including fertility), protection of any sexual contacts, preventive education, and provision of instructions for future screening. Lack of treatment can contribute to infertility, cancer, and urogenital complications, as well as pregnancy complications and potential harm to a fetus in pregnant women with STIs. Failure of patients to follow up and adhere to a prescribed medical regimen complicates individual care and public health reduction efforts.
Multiple STIs frequently occur together. Once an STI is diagnosed, further testing for human immunodeficiency virus (HIV) infection and hepatitis B is
 warranted.
Because of frequent changes in treatment guidelines and resistance patterns, we recommend that the reader access the Centers for Disease Control and Prevention Morbidity and Mortality Weekly Report (http://www.cdc.gov/mmwr) to check any modifications for treatment and also to obtain patient information in several languages.
GENERAL PRINCIPLES FOR DIAGNOSIS AND SCREENING
The signs and symptoms of an STI may be obvious, such as a genital lesion or vaginal discharge, or less specific, such as dysuria, lower abdominal pain, painful intercourse, or spotting between periods. Less specific signs lead to frequent STI underrecognition. Obtain a thorough sexual history in an objective, nonjudgmental manner to determine the risk of STI, HIV infection, or hepatitis. The young (13 to  years old), pregnant women, and homosexual men are all at higher risk of STI and subsequent morbidity. The Centers for Disease Control and Prevention has questions that providers can use when obtaining a sexual history and determining a patient’s risk for an STI (Table 153­1).
TABLE 153­1
Centers for Disease Control and Prevention Recommended Questions for the Five Ps of Sexually Transmitted Infection (STI) Prevention4
. Partners“Are you currently sexually active?” “If no, have you ever been sexually active?”“In recent months, how many sex partners have you had?”“Are your sex partners men, women, or both?”
. Prevention of pregnancy“Are you currently trying to conceive or father a child?”“Are you concerned about getting pregnant or getting your partner pregnant?”“Are you using contraception or practicing any form of birth control?”“Do you need any information on birth control?”
. Protection from STI“Do you and your partner(s) use any protection against STI?” “If not, could you tell me the reason?”“If so, what kind of protection
 do you use?”“How often do you use this protection?” “If ‘sometimes,’ in what situations or with whom do you use protection?”“Do you have any other
Chapter 153: Sexually Transmitted Infections, Karen D. Serrano 
©2025 McqGuerastwio nHsi,l lo. rA alrl eR tihgehrtes o Rtheesr eforvrmeds .o f pTreortmecst ioonf Ufrsoem * S PTIr tivhaatc yyo Pu owliocuyl d * lNikoe ttioc ed is * cAuscsc teosdsaiyb?i”lity
. Practices“What kind of sexual contact do you have or have you had? Genital (penis in the vagina)? Anal (penis in the anus)? Oral (mouth on penis, vagina, or anus)?”
. Past history of STI“Have you ever been diagnosed with an STI?” “When?” “How were you treated?”“Have you had any recurring symptoms or diagnoses?”“Have you ever been tested for HIV or other STI?” “Would you like to be tested?”“Has your current partner or any former partners ever been diagnosed or treated for an STI?”“Were you tested for the same STI(s)?” “If yes, when were you tested?” “What was the diagnosis?” “How was it treated?”
Abbreviation: HIV = human immunodeficiency virus.
Perform a pregnancy test in all females of childbearing potential, because pregnancy may affect treatment options. As appropriate, have chaperones present whenever breast, genital, or rectal examinations are performed. In women, perform a vaginal speculum examination, bimanual examination, and rectal examination. In males, retract the foreskin in uncircumcised patients to fully examine the area. Examine the areas between skinfolds, particularly in obese patients. Obtain directed site test specimens, which may include urine, vaginal, rectal, and urethral samples.
GENERAL RECOMMENDATIONS FOR TREATMENT AND FOLLOW­UP
3–5
Based on advice from the Centers for Disease Control and Prevention, we recommend the following (Table 153­2):
. Patients with symptoms suggestive of cervicitis or urethritis who are high risk for STIs should be treated presumptively for gonorrhea and chlamydia in the ED.
. Obtain a pregnancy test and consult or refer promptly if the patient is pregnant.
. If one STI is suspected or diagnosed, screen for other STIs (HIV infection, syphilis, and hepatitis) in the ED or through follow­up.
. Report any notifiable infections such as Chlamydia trachomatis, gonorrhea, HIV infection, and syphilis. This is often based on final laboratory testing and can be automated.
. Counsel all patients with suspected STIs about prevention and coinfection risks (notably HIV and hepatitis) in the ED and ensure follow­up options.
Although no method aside from abstinence is 100% effective for STI prevention, male latex condoms and female condoms are useful in preventing
STIs.
. Advise that the partner(s) must seek treatment before any reengagement in sex.
. Arrange follow­up to ensure relief of symptoms, compliance, and STI cure.
TABLE 153­2
Treatment of Sexually Transmitted Infections
Sexually Transmitted First­Line Treatment Alternative(s) Pregnancy/Lactation
Infection
Bacterial vaginosis Metronidazole, 500 milligrams PO Tinidazole,  grams PO daily ×  d Metronidazole, 500 milligrams two times daily ×  d PO two times daily ×  d or or or
Metronidazole vaginal gel .75%,  Tinidazole,  gram PO daily ×  d Metronidazole vaginal gel grams intravaginally daily ×  d .75%,  grams intravaginally daily ×  d or or
Clindamycin vaginal cream 2%,  Clindamycin, 300 milligrams PO twice daily ×  grams intravaginally at bedtime × d
 d or
Clindamycin ovules, 100 milligrams intravaginally at bedtime ×  d
Chancroid Azithromycin,  gram PO single Azithromycin,  gram PO single dose dose or or
Ceftriaxone, 250 milligrams IM Ceftriaxone, 250 milligrams IM single dose* single dose* or
Ciprofloxacin, 500 milligrams PO, two times daily ×  d or
Erythromycin base, 500 milligrams
PO three times daily ×  d
Chlamydia (treat for Neisseria Doxycycline, 100 milligrams PO Erythromycin base, 500 milligrams PO four Azithromycin,  gram PO single gonorrhoeaeconcurrently) two times daily ×  d times daily ×  d dose PLUS test of cure in 3–4 wk or
Erythromycin ethylsuccinate, 800 milligrams
PO four times daily ×  d or
Levofloxacin, 500 milligrams PO once daily ×  d or
Ofloxacin, 300 milligrams PO twice daily ×  d
Gonorrhea (treat for Ceftriaxone*, 500 milligrams IM Gentamicin, 240 milligrams IM, AND Ceftriaxone*, 500 milligrams IM
Chlamydia azithromycin,  gram PO single dose singledose if weight <150 single dose, AND azithromycin,  trachomatisconcurrently) kilograms, 1000 milligrams IM gram PO single dose single dose if weight <150 kg
AND Doxycycline, 100 milligrams
PO two times daily ×  d
*If pharyngeal gonorrhea, test of cure should be performed 7­14 days after initial treatment or
Cefixime, 800 milligrams PO single dose, AND
Doxycycline, 100 milligrams PO twice a day for
 d
Granuloma inguinale Azithromycin,  gram PO weekly Doxycycline, 100 milligrams PO two times daily Erythromycin base, 500
(donovanosis) for at least  wk and until lesions for at least  wk and until lesions completely milligrams PO four times daily completely healed healed for at least  wk and until lesions completely healed or or or
Azithromycin, 500 mg PO daily Ciprofloxacin, 750 milligrams PO two times Azithromycin,  gram PO weekly for at least  wk and until lesions daily for at least  wk and until lesions for at least  wk and until completely healed completely healed lesions completely healed or or
Erythromycin base, 500 milligrams PO four Gentamicin  milligram/kg IV times daily for at least  wk until lesions every  h (if the above therapy is completely healed ineffective) or
Trimethoprim­sulfamethoxazole,  doublestrength (160/800 milligrams) tablet PO two times daily for at least  wk and until lesions completely healed
Herpes simplex First episode Acyclovir, 400 milligrams PO three Acyclovir, 400 milligrams PO times daily × 7–10 d three times daily × 7–10 d or or
Acyclovir, 200 milligrams PO five Acyclovir, 200 milligrams PO five times daily × 7–10 d times daily × 7–10 d or or
Valacyclovir,  gram PO two times Valacyclovir,  gram PO two daily × 7–10 d times daily × 7–10 d or
Famciclovir, 250 milligrams PO three times daily × 7–10 d
Suppressive therapy for Acyclovir, 400 milligrams orally Acyclovir, 400 milligrams PO recurrentgenitalherpesin twice a day three times daily patients without human immunodeficiency virus or or
Valacyclovir 500­1000 milligrams Valacyclovir, 500 milligrams PO orally once a day (500 milligrams daily may not be as effective as 1000) or
Famciclovir 250 milligrams orally twice a day
Severe Acyclovir, 5–10 milligrams/kg IV Acyclovir, 5–10 milligrams/kg IV every  h × 2–7 d then oral every  h × 2–7 d then oral medications for total treatment medications for total treatment time of  d time of  d
Lymphogranuloma Doxycycline, 100 milligrams PO Erythromycin base, 500 milligrams PO four Erythromycin base, 500 venereum two times daily ×  d times daily ×  d milligrams PO four times daily ×
 d
Syphilis Benzathine penicillin G, .4 million Doxycycline, 100 milligrams PO two times daily Benzathine penicillin G, .4
Primary, secondary, and early units IM single dose ×  d million units IM single dose latent or
Tetracycline, 500 milligrams PO four times daily ×  d or
Ceftriaxone, 1–2 grams IM or IV daily × 10–14 d or
Azithromycin,  gram PO single dose. Use only if treatment with penicillin or doxycycline is not feasible.
Latent BenzathinepenicillinG,2.4 million Doxycycline, 100 milligrams PO two times daily Benzathine penicillin G, .4 units IM one time a week × 3wk ×  d million units IM one time a week
×  wk
>or
Tetracycline, 500 milligrams PO four times daily ×  d
Trichomoniasis Metronidazole,  grams PO single Metronidazole, 500 milligrams PO two times Metronidazole,  grams PO dose daily ×  d single dose (weigh risks and benefits of treatment) or
Tinidazole,  grams PO single dose
*Ceftriaxone is painful IM and may be mixed with lidocaine 1% to decrease patient discomfort with administration.
Although the Centers for Disease Control and Prevention recommends that healthcare providers in all settings routinely screen for HIV infection in all
 patients aged  to  years, the ED remains an underused venue for HIV screening. Rapid HIV testing in the ED is not routine but is becoming more
 prevalent.
SEXUALLY TRANSMITTED INFECTIONS PRESENTING WITH URETHRITIS, CERVICITIS, AND/OR
DISCHARGE
CHLAMYDIAL INFECTIONS
Clinical Features
In the United States and the United Kingdom, C. trachomatis infection is the most frequently reported STI. It is one of the causes of nongonococcal urethritis and commonly coexists with gonorrhea infections. It is most prevalent in people <25 years of age and is often asymptomatic, especially in
 women, but also in men.
Chlamydial infections in men can cause urethritis, epididymitis, proctitis, or Reiter’s syndrome (urethritis, conjunctivitis, and rash). Women generally have asymptomatic cervicitis when infected with Chlamydia, although if present, symptoms include vaginal discharge, bleeding between menses, and dysuria. The discharge may be mucopurulent (Figure 153­1) when Neisseria gonorrhoeae coinfection is present. Consider urethral chlamydial infection in the differential diagnosis of sterile pyuria. Complications of chlamydia in women include pelvic inflammatory disease, ectopic pregnancy, and infertility.
FIGURE 153­1
Viscous, opaque discharge emanating from the cervical os, consistent with mucopurulent cervicitis. The string from an intrauterine device is seen descending through the os in this patient. [Reproduced with permission from Knoop KJ, Stack LB, Storrow AB, Thurman RJ: The Atlas of Emergency
Medicine, 3rd ed. © 2009 by McGraw­Hill, Inc., New York.]
Diagnosis
Chlamydia can be diagnosed in testing first­catch urine in both men and women or by collecting swab specimens from the endocervix or vagina in women and urethral swabs in men. Nucleic acid amplification testing is the preferred test for diagnosis, with a high sensitivity (90%) and specificity (99%) for Chlamydia. Nucleic acid amplification tests that are U.S. Food and Drug Administration cleared for use with vaginal swab specimens can be self­collected by the patient, with equal sensitivity and specificity to provider­collected swabs, a screening strategy that
,9 patients may find more tolerable.
Treatment

The Centers for Disease Control and Prevention recommends twice­a­day doxycycline for  days to treat chlamydia. Previous guidelines recommended single­dose azithromycin  gram, but the new recommendations forego this single­dose treatment due to increasing antimicrobial resistance. However, azithromycin is still the treatment of choice for chlamydia in pregnancy, and pregnant women should undergo a test of cure  to 
,11 weeks after treatment.Table 153­2 lists dosages and alternative treatment options.
Refer partners for testing and treatment if there was sexual contact in the last  days. Providers may elect to give the patient medication or a prescription to deliver to their partners. Known as expedited partner therapy, this approach is endorsed by the Centers for Disease Control and
Prevention as a way of preventing the spread of this STI. Universal adoption of this method at this time is incomplete because of ethical issues and
 medicolegal consequences including some state prohibitions. Providers should visit www.cdc.gov/std/ept to obtain updated information for their state.
Counsel patients to avoid sexual contact until  days have elapsed after completion of antibiotic treatment and their symptoms have resolved.

Encourage women to be retested approximately  months after treatment because of the high incidence of recurrence.
GONOCOCCAL INFECTIONS
Gonorrhea is the second most commonly reported STI, caused by N. gonorrhoeae, a gram­negative diplococcus.
Clinical Features
Most gonococcal infections in women are asymptomatic and often coexist with chlamydial infection. Gonorrheal infections result in complications ranging from ectopic pregnancy to chronic pelvic pain to pelvic inflammatory disease. Symptoms, if present, may include nonspecific lower abdominal discomfort and mucopurulent cervicitis after a 7­ to 14­day incubation period. In contrast to women, gonorrheal infection is usually symptomatic in men, and 80% to 90% of men develop symptoms within  weeks of exposure. Dysuria and profuse, purulent penile discharge (Figure 153­2) are the most common presenting symptoms, but symptoms of acute epididymitis and prostatitis may also result. Rectal infection with mucopurulent anal discharge and pain occurs in 30% to 50% of women with gonococcal cervicitis, and the rectum can be the only site of infection in homosexual men. N.
gonorrhoeae also can be isolated from the pharynx but rarely causes pharyngitis.
FIGURE 153­2
Gonococcal urethritis in a male. Mucopurulent ureteral discharge is caused by infection with Neisseria gonorrhoeae. [Reproduced with permission from Goldsmith LA, Katz SI, Gilchrest BA, et al: Fitzpatrick’s Dermatology in General Medicine, 8th ed. © 2012 by McGraw­Hill, Inc., New York.]
Signs and symptoms of disseminated gonococcal infection include petechial or pustular acral skin lesions on an erythematous base (Figure 153­
3), asymmetric arthralgias, tenosynovitis or septic arthritis, and fever or general malaise. Infection with N. gonorrhoeae and other STIs is associated
 with increased HIV shedding.
FIGURE 153­3
Disseminated gonococcal infection. A. Maculopapules on the hands. B. Lesion on the extensor surface of the wrist in a sexually active adult female.
The macropapule has a petechial component and an erythematous periphery.
Diagnosis
The Centers for Disease Control and Prevention recommends that nucleic acid amplification testing be performed on cervical, vaginal, urethral, or urine specimens. Specimens can be self­collected by the patient. Not all nucleic acid amplification testing is the same; some tests can be used only on certain specimen types, so know what is available at your institution. Culture and nucleic acid hybridization tests require endocervical or urethral swab specimens
In men, a Gram stain of urethral secretions that demonstrates polymorphonuclear leukocytes with the classic intracellular diplococci confirms the diagnosis. However, absence of this finding is not sufficient to rule out the gonococcal infection, and it is therefore not recommended as a screening tool. Additionally, this diagnostic method is not sufficient for endocervical, pharyngeal, or rectal specimens. Diagnosis of disseminated gonococcal infection is difficult, with only 20% to 50% of cultures of blood, lesion, and joint specimens yielding positive results. Culture of cervical, rectal, and pharyngeal specimens may improve the chance of diagnosis.
Treatment
Given emerging resistance patterns, the Centers for Disease Control and Prevention recommends ceftriaxone 500 milligrams IM for patients <150 kg, and 1000 milligrams IM patients > 150 kg for the treatment of gonorrhea. If chlamydial infection has not been excluded, doxycycline 100 milligrams PO
BID X  days should be added. For patients who cannot tolerate a cephalosporin, single­dose gentamicin 240 milligrams IM plus single­dose azithromycin  grams PO can be used. An alternative is single­dose cefixime 800 milligrams PO, plus doxycycline 100 milligrams PO X  days. (Table 153­
,5
2).
Pregnant women should be treated with a cephalosporin plus azithromycin or, if allergic to cephalosporins, with  grams of either azithromycin PO or
 grams of spectinomycin IM (not available in the United States) in a single dose.
Instructions to sexual contacts are the same as with chlamydial infections. Treat disseminated disease with higher doses of ceftriaxone (1 gram IM or IV every  hours for  to  days) followed by cefixime 400 milligrams PO twice a day for a minimum of  week. Gonococcemia requires hospitalization for
IV administration of antibiotics and evaluation for possible endocarditis and meningitis. Patients with gonococcal arthritis rarely require surgical drainage and irrigation of affected joints.
NONGONOCOCCAL URETHRITIS
Nongonococcal urethritis is diagnosed when N. gonorrhoeae is absent in someone with clinical symptoms. Although nongonococcal urethritis is usually caused by C. trachomatis, other causes of nongonococcal urethritis include Ureaplasma urealyticum, Mycoplasma genitalium, Trichomonas vaginalis, herpes simplex virus, and adenovirus. Alternative pathogens are seen more often in older men, and often no singular pathogen is identified.
Specific tests for U. urealyticum and M. genitalium are not indicated.
If a patient’s urethral specimen has five or more WBCs per oil immersion field or the first­void urine specimen suggests infection, treat empirically as chlamydial urethritis. If the symptoms persist, the patient was noncompliant with their prior treatment regimen, the patient was exposed to a new sexual partner, or the previous partner was not treated, repeat treatment for chlamydial urethritis. Otherwise, obtain a specimen for culture for T.
vaginalis and treat with metronidazole,  grams as a single oral dose, or with a combination of tinidazole,  grams PO, plus azithromycin,  gram PO as a single dose.
TRICHOMONAL INFECTIONS
T. vaginalis is a flagellated protozoan that causes urogenital infections mostly in women, with a prevalence of approximately 3%. T. vaginalis infection is associated with a high prevalence of coinfection with other STIs, notably HIV, and trichomonas has been identified as a cofactor in HIV
,15 transmission. Trichomonas is also covered in Chapter 102 “Vulvovaginitis.”
Clinical Features
Trichomoniasis can range from asymptomatic carrier states to severe, inflammatory disease. Symptoms include a malodorous, thin watery discharge, vulvar irritation, pruritus, dysuria, urinary frequency, dyspareunia, and occasionally low abdominal pain. The classic yellow­green, frothy discharge is
 infrequently found, and many women have minimal symptoms. Physical examination may demonstrate vulvar irritation, inflamed vaginal mucosa, and punctate cervical hemorrhages. In men, the disease is often asymptomatic, but may present as urethritis.
Diagnosis
Nucleic acid amplification tests and other highly sensitive tests are recommended for diagnosis of trichomoniasis, preferred over wet­mount microscopy, a method with poor sensitivity. Culture is the most sensitive and specific test available, although it may take up to  days to obtain results.
Because of this delay to diagnosis, commercially available tests using DNA probes and monoclonal antibodies are used in some institutions.
Treatment
All patients with Trichomonas infection should be treated irrespective of symptoms, and sexual partners should be treated to prevent reinfection.

Metronidazole,  grams PO in a single dose or 500 milligrams PO twice daily for  days, cures 90% to 95% of patients. Single­dose regimens are generally preferred due to better adherence, decreased cost, and less vaginal candidiasis, whereas the lower dose, prolonged course has fewer
 systemic side effects. Patients must avoid alcohol when taking metronidazole given the disulfiram­like reaction. Metronidazole gel is less effective
 than oral treatment.
Trichomonas infections are linked to an increase in pregnancy­related complications. Because metronidazole is a pregnancy category B drug, it is the drug of choice for treating symptomatic pregnant patients, with no high­quality evidence linking metronidazole exposure with teratogenic
 effects. Despite the Centers for Disease Control and Prevention recommendations of a 2­gram singular dose coupled with evidence supporting the safety of metronidazole treatment in symptomatic pregnant women, some clinicians avoid oral treatment in the first trimester. Treatment of partners includes administration of the same medications as for the patient plus an STI clinic referral given the high rate of cotransmission of other STIs.
SEXUALLY TRANSMITTED INFECTIONS PRESENTING WITH GENITAL ULCERS
Genital ulcers are caused by syphilis, herpes virus infection, chancroid, lymphogranuloma venereum, and granuloma inguinale (donovanosis). These infections have high rates of coinfection with HIV. Not all infections associated with genital ulcers are sexually transmitted. Characteristics of the lesions and their accompanying signs and symptoms are provided in Table 153­3. TABLE 153­3
Clinical Features of Genital Ulcerative Infections
Disease Clinical Diagnosis Presence Inguinal Adenopathy Comment of Pain
Syphilis Indurated, relatively clean base; No Firm, rubbery, discrete Primary: chancre heals spontaneously nodes; not tender Secondary: rash, mucocutaneous lesions, lymphadenopathy
Tertiary: cardiac, ophthalmic, auditory, CNS lesions
Herpes simplex Multiple small, grouped vesicles Yes Tender bilateral adenopathy Cytologic detection insensitive; false­negative virus infection coalescing and forming shallow culture results common; type­specific serologic ulcers; vulvovaginitis test
Chancroid Multiple painful, irregular, Yes 50% painful, suppurative, Cofactor for human immunodeficiency virus
(Haemophilus purulent ulcers with potential inguinal lymph nodes transmission; 10% have coinfections with ducreyi) exudative base potentially requiring herpes simplex virus infection or syphilis drainage
Lymphogranuloma Small and shallow ulcer, No Tender lymph nodes Caused by Chlamydia trachomatis L1, L2, L3 venereum associated proctocolitis with fistulas and strictures
Granuloma Painless, beefy red, bleeding No No Endemic in Africa, Australia, India, New Guinea; inguinale ulcers rare in United States
(donovanosis)
SYPHILIS
Syphilis is a systemic disease caused by the spirochete Treponema pallidum. The organism enters the body through mucous membranes or nonintact skin. T. pallidum remains very sensitive to penicillin. The incidence of syphilis in the United States has been on the rise from 2000 to 2016. This was initially attributed to increased cases of male­to­male transmission; however, between 2013 and 2016, there was a significant increase in cases among
 women. The spike in cases in women is of particular concern because rising syphilis rates in women correlate with a rise in congenital syphilis.
Clinical Features
Syphilis is divided into three stages of infection—primary, secondary, and tertiary—and the disease may be diagnosed in any of these stages. Latent syphilis is characterized by absence of clinical manifestations but positive serologic testing.
Primary syphilis, or the initial stage of infection, is characterized by a painless chancre with indurated borders on the penis (Figure 153­4), vulva
(Figure 153­5), or other areas of sexual contact.
FIGURE 153­4
Painless chancre. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology,
5th ed. © 2005, McGraw­Hill, Inc., New York.]
FIGURE 153­5
Syphilis chancre in a female. A painless ulcer is seen on the vulva. [Reproduced with permission from Goldsmith LA, Katz SI, Gilchrest BA, et al:
Fitzpatrick’s Dermatology in General Medicine, 8th ed. © 2012 by McGraw­Hill, Inc., New York.]
The incubation period is approximately  days, with lesions disappearing after  to  weeks. There are no constitutional symptoms, and a lesion may even be absent with primary disease. The lesion resolves spontaneously.
Secondary syphilis develops  to  weeks after the end of the primary stage and is characterized by rash and lymphadenopathy. Nonspecific symptoms of sore throat, malaise, fever, and headaches are common. The rash often starts on the trunk (Figure 153­6) and flexor surfaces of the extremities, spreading to the palms (Figure 153­7) and soles. The rash takes on many forms but is often dull red­pink and papular. Secondary syphilis resolves spontaneously.
FIGURE 153­6
Disseminated papulosquamous eruption on the right chest wall characteristic for secondary syphilis. [Reproduced with permission from Wolff K,
Johnson RA, Saavedra AO: Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 7th ed. © 2013 by McGraw­Hill, Inc., New York.]
FIGURE 153­7
Papulosquamous eruption on the right palm characteristic for secondary syphilis. [Reproduced with permission from Goldsmith LA, Katz SI, Gilchrest
BA, et al: Fitzpatrick’s Dermatology in General Medicine, 8th ed. © 2012 by McGraw­Hill, Inc., New York.]
Tertiary or latent syphilis develops in about one third of patients after secondary syphilis, occurring  to  years after the initial infection.
Involvement of the nervous and cardiovascular systems is characteristic, with widespread granulomatous lesions (gummata). Specific manifestations include meningitis, dementia, neuropathy (tabes dorsalis), and thoracic aneurysm.
Diagnosis
T. pallidum cannot be cultured in the laboratory, and there is no single optimal test. The sensitivity and specificity of tests for syphilis depend on the stage of the disease and the type of test. Direct visualization of the organism using darkfield microscopy is diagnostic of primary, secondary, or early congenital syphilis, no matter what the results on serology. However, failure to visualize the organism does not exclude syphilis. Nontreponemal tests
(Venereal Disease Research Laboratory test, rapid plasma reagin test) detect nonspecific antibodies to cardiolipins, which are released as a result of infection. The Venereal Disease Research Laboratory and rapid plasma reagin tests are used as screening tests and also, once diagnosis is made, to assess disease activity and response to treatment. If used for screening, the Venereal Disease Research Laboratory and rapid plasma reagin tests are associated with both false­negative and false­positive results. Tests do not become positive until about  to  weeks after a chancre appears. Positive results must be confirmed with an immunoassay specific for T. pallidum antibodies. Some laboratories now begin the testing sequence with sensitive
 and specific Treponema­specific assays (reverse screening) and follow response to treatment with nontreponemal tests.

For secondary syphilis, nontreponemal antibody tests are nearly 100% sensitive with high specificity. The blood of treated patients usually becomes nonreactive on nontreponemal antibody tests. Patients who develop disease and have a reactive result on a specific treponemal antibody test will have a reactive test result for life regardless of disease activity or treatment.
A presumptive diagnosis of syphilis is made if a positive result on a nontreponemal antibody test (i.e., rapid plasma reagin or Venereal Disease
Research Laboratory test) is supported by a positive confirmatory result on a treponemal antibody test (i.e., fluorescent treponemal antibody
,19 absorption test). Treat based on strong clinical grounds while results of confirmatory tests are pending, if follow­up is uncertain. When uncertain about testing interpretation, review the Centers for Disease Control and Prevention website (http://www.cdc.gov/STD/syphilis/default.htm) for detailed clarification of laboratory diagnosis or contact the local health department.
Treatment
For primary and secondary syphilis, treat with penicillin G benzathine, .4 million units IM in a single dose. Doxycycline twice daily for  weeks may be used in penicillin­allergic patients (Table 153­2). Pregnant women should be treated with parenteral penicillin G; if allergic, they should be desensitized and then given this medication. The Jarisch­Herxheimer reaction occurs most frequently in treatment of early syphilis and is characterized by an acute febrile reaction associated with headache and myalgias within the first  hours after treatment. Inform patients about this possible reaction. Recommend treatment of sexual partner(s) exposed in the previous  days. For a more detailed explanation of partner treatment, please refer to the Centers for Disease Control and Prevention website (http://www.cdc.gov/std/ept/default.htm).
Treat tertiary syphilis with .4 million units of penicillin G benzathine IM weekly for  weeks. Either a primary care physician or the department of public health should closely follow all patients for repeat serologic testing at  and  months.
HERPES SIMPLEX INFECTIONS
Herpes simplex virus (HSV) type  or type  infections are lifelong. Genital herpes results from exposure of mucosal surfaces or nonintact skin to the
HSV virus. While most genital infections are caused by the HSV­2 virus, the incidence of anogenital infections caused by HSV­1 virus is on the rise,
 especially among young women and men who have sex with men. Only 10% to 25% of individuals who are HSV­2 seropositive report a history of genital herpes, which suggests that most infected people have unrecognized or asymptomatic infections. Viral shedding in persons who are unaware
 that they are infected is likely responsible for the majority of HSV transmission. HSV is also covered in Chapter 102. Clinical Features
“Classic” outbreaks of primary genital HSV infection begin with a prodrome lasting  to  hours that is characterized by localized or regional pain, tingling, and burning. Next, constitutional symptoms of headache, fever, painful inguinal lymphadenopathy, anorexia, and malaise develop. As the disease progresses, papules and vesicles on an erythematous base become evident, which eventually ulcerate. Patterns of HSV­1 and HSV­2 infection appear identical: vesicles usually are uniform in size, and the tense center umbilicates to form a depressed center. Lesions usually crust and then reepithelialize and heal without scarring.
In men, HSV ulcers often appear on the shaft or glans of the penis (Figure 153­8). In women, ulcers can occur on the introitus (Figure 153­9), urethral meatus, labia, and perineum. Lesions are exquisitely painful and may be associated with serous discharge. In both sexes, lesions may be found on the perianal area, thighs, or buttocks. Dysuria is common in women, and urinary retention may develop secondary to severe pain.
FIGURE 153­8
Genital herpes in a male. These formerly vesicular lesions have crusted over. [Reproduced with permission from Goldsmith LA, Katz SI, Gilchrest BA, et al: Fitzpatrick’s Dermatology in General Medicine, 8th ed. © 2012 by McGraw­Hill, Inc., New York.]
FIGURE 153­9
Genital herpes in a female. These formerly vesicular lesions have crusted over. [Reproduced with permission from Goldsmith LA, Katz SI, Gilchrest BA, et al: Fitzpatrick’s Dermatology in General Medicine, 8th ed. © 2012 by McGraw­Hill, Inc., New York.]
Complete healing usually occurs within  weeks, and viral shedding persists for  to  days after the onset of the rash. Recurrent outbreaks are typically milder than the initial episode. There are typically fewer lesions, and viral shedding occurs at a lower concentration and for a shorter duration

(i.e., about  days).
Diagnosis
Diagnosis is usually made based on clinical features. Laboratory diagnosis is either by cell culture or polymerase chain reaction. When obtaining a
 specimen for analysis, puncture the vesicle and swab the fluid. Swab the base of the lesion vigorously, because the virus is cell associated.
Importantly, lack of HSV detection does not confirm absence of HSV infection because viral shedding is intermittent.
Treatment
Treatment shortens the duration of outbreaks but is not curative. Antiviral medications decrease the time until all lesions are crusted and healed,
 decrease pain and constitutional symptoms, and decrease the period of viral shedding by several days.
Treat the first clinical episode of genital herpes with acyclovir, famciclovir, or valacyclovir (Table 153­2). To treat proctitis or oral infections, use higher dosages (acyclovir, 400 milligrams five times a day for  to  days). For hospitalized patients with severe disease, administer acyclovir,  to  milligrams/kg IV every  hours, for at least  days before transitioning to oral therapy.
Treat episodic recurrent infection for  days with acyclovir, famciclovir, or valacyclovir at dosages reduced from primary therapy (Table 153­2). For individuals with frequent recurrences, suppressive therapy is a good option and reduces the frequency of recurrences by 70% to 80% (according to the
Centers for Disease Control and Prevention). Treat severe recurrent infections (seen primarily in immunocompromised patients) with acyclovir,  to  milligrams/kg every  hours IV, for at least  days before switching to oral therapy. A primary diagnosis of HSV should prompt the search for other
STIs including HIV.
CHANCROID
Chancroid is a disease characterized by painful genital ulcers and lymphadenitis that is caused by the pleomorphic gram­negative bacillus

Haemophilus ducreyi. The disease is on the decline in the United States, and infections are usually seen in association with sporadic outbreaks.
Chancroid increases HIV transmission and often is accompanied by other infections. When chancroid is present, 10% of infected patients in the United

States also have HSV or T. pallidum.
Clinical Features
A painful erythematous papule appears at the site of infection (usually confined to the genital region) after an incubation period of  to  days. One to
 days later, the lesion becomes eroded, ulcerated, and often pustular. The ulcers are usually  to  cm in diameter with sharp, undermined margins and are very painful (Figure 153­10). The friable base of the ulcer is covered with yellow­gray necrotic exudates. Multiple lesions are present in up to
50% of patients, especially in women, and “kissing lesions” (infection of adjacent skin areas due to autoinoculation) are frequent. Painful inguinal lymphadenopathy develops  to  weeks after primary infection, and lymph nodes may become necrotic or pus­filled, known as buboes. (Figure 153­
11). Constitutional symptoms are rare, and ulcerations are rarely recurrent.
FIGURE 153­10
Painful, punched­out ulcer of chancroid. [Reproduced with permission from Fleischer AB Jr, Feldman SR, McConnell CF, et al: Emergency Dermatology:
A Rapid Treatment Guide. © 2002, McGraw­Hill, Inc., New York.]
FIGURE 153­11
Chancroid with characteristic penile ulcers and associated left inguinal adenitis. [Photo contributor: H. Hunter Handsfield. Atlas of Sexually
Transmitted Diseases. New York: McGraw­Hill, Inc.; 1992. Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of
Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, Inc., New York. Fig 9­22.]
Diagnosis
Diagnosis can generally be made on clinical grounds with a painful ulcer and regional lymphadenopathy, but other infections (such as HSV infection and syphilis) are possible. A swab of a lesion or pus from a suppurative lymph node can be cultured, but a special medium is required that is not widely available, and culturing has a sensitivity of <80%. There is no current U.S. Food and Drug Administration–approved polymerase chain reaction test, but some clinical laboratories have developed their own polymerase chain reaction tests.
Treatment
Azithromycin PO in a single dose, ceftriaxone IM in a single dose, ciprofloxacin for  days, or erythromycin base for  days are all effective in the treatment of H. ducreyi infection (Table 153­2). Treatment choice should be based on local antibiotic resistance patterns and patient factors. Generally, azithromycin and ceftriaxone are used in patients without HIV infection, with ciprofloxacin as an alternative. Erythromycin is inexpensive, but the need for multiple doses and GI toxicity make it less desirable. Incision and drainage or aspiration of buboes can be considered for symptomatic relief, prevention of fistulas, and secondary ulcers.
Symptoms improve in about  days, and lesions are visibly improved within a week. Larger ulcers may require  to  weeks to heal. Partners should be
 treated if they have had sexual contact in the past  days, regardless of symptoms. Pregnant women should be treated with azithromycin or ceftriaxone. All patients should be tested for HSV, syphilis, and HIV at the time of diagnosis of chancroid and again  months later if tests are initially negative.
LYMPHOGRANULOMA VENEREUM
Lymphogranuloma venereum is a sexually transmitted infection caused by three specific serotypes of C. trachomatis (L1, L2, and L3). It is also known as struma, tropical bubo, or Durand­Nicolas­Favre disease. Lymphogranuloma venereum is endemic worldwide, but is seen only sporadically in the

United States. The Netherlands has seen an increased incidence of this STI in men who have sex with men. The primary lesion can take many forms and be confused with the lesions of other STIs (Table 153­3).
Clinical Features
The painless primary chancre usually goes unnoticed and lasts only  to  days (Figure 153­12). Generally,  to  weeks after the appearance of the initial lesion, unilateral inguinal lymphadenopathy is noted (60% of cases) (Figure 153­13). Often the overlying skin has a purplish hue. The initial lesion progresses to suppurative lymphadenopathy, resulting in either spontaneous abscess rupture or firm inguinal masses. Lymphogranuloma venereum proctitis (rectal ulcers, bleeding, and discharge) is also seen, primarily in homosexual men, and can be mistaken for inflammatory bowel disease. Scarring of these masses may cause linear depressions parallel to the inguinal ligament, forming the so­called groove sign (Figure 153­14).
Lymphogranuloma venereum infections can cause fever, chills, arthralgias, erythema nodosum, or rarely meningoencephalitis. Lymphogranuloma venereum is easily confused with syphilis, chancroid, and HSV, and it also facilitates the transmission and acquisition of HIV.
FIGURE 153­12
Lymphogranuloma venereum chancre. This ulceration was painless to the patient. [Reproduced with permission from Goldsmith LA, Katz SI, Gilchrest
BA, et al: Fitzpatrick’s Dermatology in General Medicine, 8th ed. © 2012 by McGraw­Hill, Inc., New York.]
FIGURE 153­13
Lymphogranuloma venereum. Marked lymphadenopathy with small central eschar/ulcer. [Reproduced with permission from Wolff KL, Johnson R,
Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology, 5th ed. © 2005, McGraw­Hill, Inc., New York.]
FIGURE 153­14
An example of the linear depression parallel to the inguinal ligament in lymphogranuloma venereum, the groove sign. [Reproduced with permission from Goldsmith LA, Katz SI, Gilchrest BA, et al: Fitzpatrick’s Dermatology in General Medicine, 8th ed. © 2012 by McGraw­Hill, Inc., New York.]
Diagnosis
Diagnosis is based on clinical suspicion, epidemiologic data, and exclusion of other causes. Chlamydia serologic testing for lymphogranuloma venereum is not standardized and not helpful except to support the diagnosis in the appropriate setting. Culture, direct immunofluorescence testing, and nucleic acid detection of a lesion swab or bubo aspirate are not widely available, nor is genotyping. Given these diagnostic constraints, patients with a clinical picture suggestive of lymphogranuloma venereum and epidemiologic information should simply be treated. The Centers for Disease Control and Prevention may be able to assist with testing.
Treatment
Doxycycline for  days is the preferred regimen, with erythromycin base as an alternative (Table 153­2). Mild untreated cases resolve spontaneously in
 to  weeks. Treat pregnant or lactating women with erythromycin or azithromycin. Refer partners with whom the individual has had sexual contact within the past  days for treatment. Sexual activity should be avoided until the full course of antibiotic treatment is completed and lymphadenopathy
 has resolved.
GRANULOMA INGUINALE (DONOVANOSIS)
Granuloma inguinale, also called donovanosis, is caused by Klebsiella granulomatis, a gram­negative intracellular bacterium. The disease is rare in the
United States but is endemic in India, the Caribbean, southern Africa, and central Australia.
Clinical Features
After a variable incubation period of  weeks to  months, granuloma inguinale begins as subcutaneous nodules on the penis or vulva. The nodules then progress to the more classic painless, ulcerative lesions (Figure 153­15). These lesions are highly vascular, which explains both their beefy red appearance and their tendency to bleed easily on contact. Lymphadenopathy is not usually present, but subcutaneous granulomas may occur and mimic lymphadenopathy. Superinfection may complicate these open, bleeding lesions and obscure the diagnosis. Granuloma inguinale is not highly contagious, and multiple exposures are required to contract the disease. Autoinoculation can occur, leading to oral and GI tract involvement.
FIGURE 153­15
Granuloma inguinale in a male. The painless, ulcerative lesion is classically beefy red and bleeds easily. [Reproduced with permission from Goldsmith
LA, Katz SI, Gilchrest BA, et al: Fitzpatrick’s Dermatology in General Medicine, 8th ed. © 2012 by McGraw­Hill, Inc., New York.]
Diagnosis
K. granulomatis is difficult to culture, and diagnosis often requires visualization of characteristic Donovan bodies on tissue biopsy.
Treatment
Treatment of choice is azithromycin  gram PO weekly or 500 mg PO daily for at least  weeks and until all lesions have healed (Table 153­2).
Doxycycline, ciprofloxacin, erythromycin base, and trimethoprim­sulfamethoxazole are alternatives for at least  weeks and until the lesions heal.
Doxycycline, ciprofloxacin, and sulfonamides are contraindicated in pregnancy. Erythromycin base is the recommended treatment for pregnant or lactating women with the potential addition of a parenteral aminoglycoside. Individuals with whom the patient had sexual contact within  days of the
 appearance of the lesions should also be treated if symptomatic.
HUMAN PAPILLOMAVIRUS INFECTION
Over  different genotypes of human papillomavirus (HPV) can infect the human genital tract. It is estimated that just under 25% of the U.S.
  population is currently infected with genital HPV. As many as half of these infections are in adolescents and young adults, age  to  years. HPV infection is so common that most sexually active adults become infected at some point in their lives, and the majority of infections are asymptomatic.
HPV infection is clinically important because oncogenic, high­risk subtypes of HPV (e.g., HPV types  and 18) cause most cases of cervical, vulvar,
 penile, anal, and oropharyngeal cancers. Nononcogenic subtypes, such as HPV types  and , cause genital warts.
Several vaccines with activity against HPV have been developed, with a primary goal of preventing cancer. The bivalent vaccine (Cervarix®) works against oncogenic genotypes  and  only. The quadrivalent vaccine (Gardasil®) works against genotypes  and  as well as genotypes  and  associated with genital warts. A 9­valent vaccine (Gardasil­9®) protects against infection with genotypes , , , and , as well as five additional types
 associated with cervical cancer. A two­dose vaccine series is recommended for girls and boys who initiate the vaccination series between ages  and

. Three vaccine doses are recommended for those who began the series between ages  and  and immunocompromised individuals.
Clinical Features
The majority of cases of HPV infection are asymptomatic, and most people clear serologic evidence of HPV spontaneously. Infection with subtypes leading to genital warts may prompt patients to seek care. Genital warts are flesh­colored papules or cauliflower­like projections that usually appear after an incubation period of  to  months and may coalesce to form condylomata acuminata (Figure 153­16). In women, they are seen on the external genitalia (Figure 153­17) and in the perianal region. Genital warts are usually painless, but depending on their anatomic location, they can be friable, painful, or pruritic and often enlarge during pregnancy. Infected males often complain of nonhealing penile lesions, occasionally with pruritus and urethral discharge. Perianal condylomata have been seen in up to 80% of women with vulvar condylomata and are seen frequently in homosexual males.
FIGURE 153­16
Condylomata acuminata in a 25­year­old male with a 3­month history of penile lesions. Multiple cauliflower floret–like papules are seen on the penile shaft and foreskin. [Reproduced with permission from Wolff K, Johnson RA: Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 6th ed. ©
2009 by McGraw­Hill, Inc., New York.]
FIGURE 153­17
Condylomata acuminata of the vulva. Multiple pink­brown, soft papules are seen on the labia. [Reproduced with permission from Wolff K, Johnson RA,
Saavedra AO: Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 7th ed. © 2013 by McGraw­Hill, Inc., New York.]
Diagnosis
Diagnosis is clinical.
Treatment
Many topical treatments for genital warts exist that can be used for days to weeks, but these are not usually initiated in the ED. Treatment decisions are based on the size and number of lesions, the amount of discomfort they are causing, and patient preferences. The treatment of external genital warts may help reduce viral load but is not a cure. All treatment options are considered equally effective and chosen based on the discretion of the patient and provider.
Patients with HPV infections rarely require emergent management. However, counseling in the ED regarding this distressing condition is relatively common. It is important to emphasize that it is common for sexually active people to have HPV at some point in their lives, and most people clear the infection spontaneously. Condoms are protective with HPV, but they are not preventive, and the only way to decrease exposure is to limit the number of sexual partners. It is an incorrect assumption that having HPV indicates an oncogenic certainty or a change in fertility.
VIRAL SEXUALLY TRANSMITTED INFECTION TRANSMISSION
Numerous viral infections may be transmitted sexually, including HIV, hepatitis B, herpes simplex virus and HPV (discussed earlier), molluscum contagiosum, and Zika virus.
HUMAN IMMUNODEFICIENCY VIRUS
HIV is an RNA retrovirus in the Retroviridae family. HIV infection involves a spectrum of illness, from asymptomatic individuals to those with profound immunosuppression resulting in a wide array of opportunistic infections and clinical development of AIDS. The World Health Organization estimates
 that as of 2016,  million people are infected with HIV. Sex with an infected partner is the most common method of transmission of HIV worldwide, but the virus may also be spread parenterally and vertically from mother to child during birth or breastfeeding. In the United States, male­to­male sexual contact is the most common method of transmission, accounting for 78% of new infections, although the incidence of infection in women is
 rising. In sub­Saharan Africa, where the burden of HIV infection is highest worldwide, heterosexual transmission accounts for most new cases, and
 mother­to­child transmission remains a significant problem.
Acute HIV infection, also called acute retroviral syndrome, causes a mononucleosis­like illness with fever, malaise, headache, sore throat, and sometimes rash and lymphadenopathy. Due to the nonspecific symptoms that resemble many other viral infections, HIV is not usually diagnosed in the acute phase of infection, and affected individuals are unaware of their HIV status. This has important public health implications, because the acute infection is when viral shedding and transmissibility is highest. Epidemiologic studies suggest that up to half of all cases of HIV were contracted from
 persons with acute HIV infection who likely did not know they carried the virus. The clinical manifestations, diagnosis, and treatment of HIV are discussed in detail in Chapter 155, “Human Immunodeficiency Virus Infections.”
HEPATITIS B
The hepatitis B virus may be transmitted sexually, parenterally by blood transfusion or contaminated needles, or vertically from mother to child. Acute hepatitis B may produce acute symptoms, causing a hepatitis­like picture with malaise, nausea, vomiting, fever, abdominal pain, and jaundice. Chronic infection develops in 6% to 10% of patients who contract hepatitis B as adults, but a much higher percentage of patients who become infected as
 children go on to develop chronic hepatitis, underscoring the importance of vaccination of infants and women of childbearing age. Hepatitis is discussed in detail in Chapter , “Hepatic Disorders.”
MOLLUSCUM CONTAGIOSUM
Molluscum contagiosum is a viral skin infection that is common in healthy children and may also be seen in immunosuppressed individuals, especially those with HIV. Molluscum is caused by poxvirus variants molluscum contagiosum virus  to . It is spread by direct skin­to­skin contact or by contact with an object, such as a towel, which has virus on it. When molluscum is seen in teenagers and adults, it is often due to sexual contact with exposure to
  lesions in the genital area. Molluscum lesions in the genital area in children may be due to sexual abuse but may also be from autoinoculation.
Molluscum appears as skin­colored, pearly, umbilicated papules, which may be scattered or in clusters (Figure 251­24). Immunosuppressed individuals may have extensive involvement. Molluscum contagiosum is discussed in detail in Chapter 251, “Skin Disorders: Trunk.”
ZIKA VIRUS
The Zika virus garnered international attention in 2015 due to outbreaks in South and Central America, the Caribbean, Mexico, and the United States that were associated with severe birth defects. Zika is contracted through the bite of the Aedes aegypti mosquito but has subsequently been
 demonstrated to be transmitted sexually and parenterally.
After an incubation period of  to  days, symptoms may include headache, fever, malaise, maculopapular rash, and conjunctivitis. While infection tends to be mild and self­limited, a major concern surrounding Zika is potential for teratogenicity when pregnant women acquire the virus. Zika infection in pregnancy is associated with CNS abnormalities such as microcephaly, seizures, clubfoot, and arthrogryposis. Prevention efforts focus on avoiding mosquito bites with use of mosquito repellent and mosquito netting, avoiding travel to Zika­infested areas when pregnant, and avoiding unprotected sexual intercourse with individuals who have traveled to Zika­infested areas. Zika is discussed in Chapter 151, “Sepsis.”
ACKNOWLEDGEMENTS
The author gratefully acknowledges the contributions of Flavia Nobey and Susan Promes, coauthors of this chapter in the previous edition.


