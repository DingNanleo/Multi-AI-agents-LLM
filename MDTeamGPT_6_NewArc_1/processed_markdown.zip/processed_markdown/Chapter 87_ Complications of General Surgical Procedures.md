## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 87: Complications of General Surgical Procedures
Edmond A. Hooker
Content Update: Post­operative Pneumoperitoneum April 2020
Patients undergoing laparoscopic and open abdominal surgery have residual intra­abdominal pneumoperitoneum for varying amounts of time after surgery. Post­operative patients presenting to the ED with abdominal or chest pain may have pneumoperitoneum discovered on CT scanning or upright chest radiographs. Differentiating normal, from pathologic pneumoperitoneum related to perforation or anastomotic failure, can be difficult. Free air may be pathologic if the patient is more than 3­5 days post­op, if there is a large amount of air, or if the patient has evidence of peritoneal irritation, fever, or leukocytosis (1,2,3). For such patients consult surgery to help determine the next steps.
(1) Malgras, B et al 'Natural History of Pneumoperitoneum after Laparotomy: findings on multidetector­row computed tomography' World Journal of Surgery .1 (2017):56­63 PMID 27456496(2) Gayer, G et al 'Post­operative Pneumoperitoneum as Detected by CT: Prevalence, duration, and relevant factors affecting its possible significance' AbdomImaging (2000) 25:301­305 doi:10.1007/s002610000036(3) Bernstein L et al 'Postoperative
Pneumoperitoneum: Clearing the Air' J Surg (Jan, 2014):2 (1), . INTRODUCTION
Outpatient surgical procedures are common, and with increasing pressure for cost containment, admitted patients are being discharged earlier in their postoperative course. As a result, more patients are coming to the ED with postoperative fever, respiratory complications, GU complaints, wound infections, vascular problems, and complications of drug therapy (Table 87­1). This chapter reviews the complications common to all surgical procedures and those specific to a specific procedure.
TABLE 87­1
Complications of General Surgical Procedures
Complication Important Points
Fever “Five Ws” (wind, water, wound, walking, wonder drugs) are common causes
Pulmonary complications
Atelectasis <24 h, treat with pulmonary toilet, discharge unless ill or hypoxemic
Pneumonia 2–7 d, polymicrobial, most require admission
Pneumothorax Multiple causes, consider expiratory views, consider needle aspiration
Pulmonary embolism Dyspnea is main symptom, high index of suspicion
GI complications
Intestinal obstruction Obtain radiographs, search for causes

Chapter 87: Complications of General Surgical Procedures, Edmond A. Hooker 
Intra­abdominal abscess CT diagnosis, early administration of broad­spectrum antibiotics
. Terms of Use * Privacy Policy * Notice * Accessibility
Pancreatitis Always consider in postoperative patients with abdominal pain
Cholecystitis Usually in older patients, can be acalculous
Fistulas Can be high output, admit if concerns over output
GU complications
Urinary tract infection 2–5 d, oral antibiotics, most discharged
Urinary retention Rapid catheter drainage, most discharged
Acute renal failure Prerenal, renal, and postrenal causes, most admitted
Wound complications
Hematoma Caused by poor hemostasis, can drain most, but be careful with neck hematomas and hematomas after vascular surgery
Seroma Painless swelling, clear fluid, drain and discharge
Infection Open, drain, and culture specimens; be careful with wounds associated with respiratory tract, GI tract, or GU tract, or secondary to trauma
Necrotizing fasciitis Pain out of proportion to physical findings
Dehiscence Be careful with abdominal incisions (potential for evisceration)
Vascular complications
Superficial Usually aseptic, provide local therapy and discharge thrombophlebitis
Deep venous thrombosis Upper and lower extremity, perform Doppler studies
Complications of drug therapy
Diarrhea Consider pseudomembranous colitis
Drug fever Many drugs implicated, requires admission
Tetanus Can occur after GI surgery
Procedure­specific See text complications
The operating surgeon should be called when one of his or her patients appears in the ED with a surgical complication. This is not just a courtesy, but provides continuity of care important for the patient’s well­being.
FEVER
Fever is a common presenting complaint (Table 87­2). A mnemonic for the common causes of postoperative fever is the “five Ws”: wind (atelectasis or
 pneumonia), water (urinary tract infection), wound, walking (deep vein thrombosis), and wonder drugs (drug fever or pseudomembranous colitis).
Respiratory complications, such as atelectasis, and IV catheter–related problems, such as thrombophlebitis, are the predominant causes of fever in the first  hours. Necrotizing streptococcal and clostridial infections also occur in surgical wounds early in the postoperative course.
TABLE 87­2
Common Causes of Postoperative Fevers in General Surgical Patients
Cause of Fever Presentation Signs and Symptoms Diagnostic Test Treatment
Atelectasis First  h Isolated fever; may have tachypnea, Chest radiography Pulmonary toilet; admission if dyspnea, and/or tachycardia unsure or patient is ill appearing
Pneumonia 3–7 d Dyspnea, chest pain, productive cough, Chest radiography Admission and coverage with fever, and/or tachypnea broad­spectrum antibiotics
Urinary tract 2–5 d Often none; possibly dysuria Urinalysis Admission if patient is elderly or infections toxic
Skin and soft tissue 5–10 d Increasing pain, erythema, swelling, Examination, aspiration Drainage, packing, and outpatient infection drainage, and tenderness at incision site and/or opening of wound antibiotic therapy
Thrombophlebitis <3 d Warm, tender, and swollen vein None If not septic, warm soaks
(septic and sterile) If septic, surgical removal
Deep vein 4–6 d Extremity swelling and pain US Admission and anticoagulation thrombosis
Intra­abdominal 4–21 d Fever and elevated WBC count without CT Admission and antibiotic abscesses specific focal abdominal findings administration
Pseudomembranous Anytime Diarrhea Stool testing using Metronidazole or vancomycin colitis immunoassay
Peritonitis 4–21 d Tachycardia and abdominal pain, CT Admission and antibiotic peritoneal irritation administration
Pulmonary Anytime Shortness of breath, tachypnea, and/or CT or ventilation– Admission and anticoagulation embolism hemodynamic instability perfusion scanning
Transfusion reaction First  h Fever, chills Transfusion check for Admission depending on condition incompatibility of patient
Urinary tract infections become evident  to  days postoperatively. Seven to  days postoperatively, clinical manifestations of wound infections develop. Deep venous thrombosis can result in fever any time but usually not until the fifth postoperative day. Antibiotic­induced pseudomembranous colitis occurs up to  weeks postoperatively. An approach for evaluating and managing fever in postoperative patients is presented in Table 87­3. TABLE 87­3
Evaluation and Management of Postoperative Fever
History
Presenting signs and symptoms
Onset of symptoms, time since procedure
Procedures performed and complications
Medications
History of blood transfusion
Physical examination
Particular attention to
Operative sites and contiguous areas
Sites of catheters and invasive monitors
Signs of deep venous thrombosis and pulmonary embolism
Decubitus ulcers
Lungs
Ancillary studies
CBC with differential
Chest radiograph
Gram stain and culture of wound exudate
Urinalysis (urine culture if infected)
Sputum Gram stain and culture
Blood cultures
CT to exclude intra­abdominal pathology
If diarrhea present, consider immunoassay of specimen for Clostridium difficile toxin
Further tests as indicated (e.g., CT, radionuclide studies, venography, arteriography)
Treatment
If source identified, start antibiotics; admission based on condition of patient
If no source identified, consider admission, change all catheters and culture catheter specimens, stop all medication that might cause fever
RESPIRATORY COMPLICATIONS
ATELECTASIS
Atelectasis, the collapse of pulmonary alveoli, is very common. Contributing factors include inadequate clearance of secretions after general anesthesia, decreased intra­alveolar pressure, and postoperative pain, which results in hypoventilation. Although atelectasis can occur after any procedure, it frequently occurs after upper abdominal and thoracic surgery. The presentation varies from an isolated fever to tachypnea, dyspnea, and tachycardia.
Evaluation includes chest radiography, pulse oximetry, and a CBC. Chest radiographs may show normal findings or exhibit platelike linear densities, triangular densities, or lobar consolidation. CT scan can be done when other diagnoses are a consideration. US may be useful in confirming the
 diagnosis of atelectasis. Mild hypoxemia from ventilation and perfusion mismatch is common, but hypercarbia is uncommon. Patients with mild atelectasis and no evidence of hypoxemia may be managed as outpatients with pain control and increased deep breathing. Admission is indicated for aggressive pulmonary toilet and supplemental oxygenation in debilitated patients, patients with underlying lung disease, patients with hypoxemia, or those in whom the diagnosis is in question.
PNEUMONIA
Pneumonia usually becomes evident between  and  hours postoperatively. Predisposing factors include prolonged ventilatory support and atelectasis. Presenting symptoms can include dyspnea, chest pain, productive cough, fever, and tachypnea. Postoperative pneumonia is likely to be polymicrobial. After specimens of sputum and blood are obtained for culture, parenteral antimicrobial therapy is given. There are many options for polymicrobial coverage. Follow local recommendations for hospital­acquired pneumonia.
PNEUMOTHORAX
Pneumothorax can occur as a complication of thoracic wall surgery, breast biopsy, laparoscopic abdominal surgery, abdominal paracentesis, nasogastric and feeding tube insertion, thoracic surgery, central venous catheter insertion, endoscopic procedures, shoulder arthroscopy, and tracheostomy. For further discussion, see Chapter , “Pneumothorax.”
PULMONARY EMBOLUS
Pulmonary embolism may present any time during the postoperative period. For further discussion of signs, symptoms, and treatment, see Chapter
, “Venous Thromboembolism Including Pulmonary Embolism.”
GU COMPLICATIONS
URINARY TRACT INFECTION
Urinary tract infections can occur after any surgical procedure, but the incidence increases in patients who have undergone instrumentation of the GU tract or bladder catheterization. The cause is direct contamination of the urinary bladder, most commonly with Escherichia coli. Other organisms isolated include Staphylococcus aureus, Staphylococcus epidermidis, Proteus mirabilis, Klebsiella, Pseudomonas, and enterococci. Oral antibiotics
(ciprofloxacin, 500 milligrams PO twice daily, or levofloxacin, 750 milligrams PO once daily) are appropriate for most infections, and choice of antibiotic should be based on local susceptibility patterns. Elderly or debilitated patients and those with sepsis require admission for parenteral administration of antibiotics (usually levofloxacin, 750 milligrams IV once daily).
URINARY RETENTION
Postoperative acute urinary retention is a common problem for surgical patients. Urinary retention occurs as the result of catecholamine stimulation of α­adrenergic receptors in the bladder neck and urethral smooth muscle. Increased incidence of urinary retention is likely to occur in elderly patients, females, patients receiving excessive fluid administration during surgery, those undergoing anorectal surgery, patients undergoing longer
,4 procedures (>2 hours), and those for whom spinal or epidural anesthesia was used.
Patients with urinary retention present with lower abdominal discomfort, urinary urgency, and inability to void. The diagnosis is confirmed by US. The bladder can be safely drained quickly with a Foley catheter, and there appears to be no foundation for the fears of hematuria, postobstructive diuresis, and hypotension. For patients with normal renal function and no anatomic obstruction, continued catheter drainage is not necessary. For patients with retention after GU procedures, a urologist should be consulted prior to instrumentation. Antibiotics can be given if the GU tract has been instrumented, if retention is prolonged, or if the patient is at risk for infection (see “Urinary Tract Infection” section above).
ACUTE RENAL FAILURE
Acute renal failure is classified according to the primary cause: prerenal, intrinsic, or postrenal. Volume depletion is the most common prerenal cause.
Treatment is a fluid bolus. Intrinsic causes include acute tubular necrosis and drug nephrotoxicity. Obstructive uropathy is a common cause of postrenal failure. In patients with urinary outlet obstruction, placement of a urinary catheter is diagnostic and therapeutic. Renal US is needed to identify hydronephrosis or hydroureter.
WOUND COMPLICATIONS
Inform the operative surgeon about all postoperative wound complications.
HEMATOMAS
Wound hematomas result from unrecognized inadequate hemostasis. Patients have pain, pressure, and swelling within the wound. Patients with wound hematomas may be febrile and have sanguineous or serous wound drainage. Differentiating between hematoma and wound infection can be difficult. A few sutures should be removed to allow the hematoma to drain, and culture of wound specimens should be performed. If there is no evidence of infection and hemostasis can be maintained, the patient can be discharged. In patients who have a hematoma of the neck or who have undergone vascular surgery, extreme caution and consultation are appropriate.
SEROMAS
A seroma, a collection of serous fluid, is usually the result of inadequate control of lymphatics during dissection but can occur under split­thickness skin grafts and in areas with large dead spaces (e.g., axilla, groin, neck, or pelvis). Patients have painless swelling below the wound or graft, and needle aspiration yields a serous fluid. Aspiration confirms the diagnosis and alleviates the problem, although aspiration may have to be repeated later.
INFECTION
Systemic factors (e.g., extremes of age, poor nutrition, or diabetes) contribute to wound infections. However, local factors (e.g., necrotic tissue, poor perfusion, foreign bodies, and hematomas) are of greatest significance. In nontraumatic, uninfected operative wounds in which the respiratory, alimentary, and GU tracts were not entered, infection rates are low. In such cases, the infecting organism is usually from the skin but can originate from remote infected sources (e.g., urinary tract infection). If there is a remote infected source, the organism is probably the same in both infections.
Wounds associated with entering the respiratory, alimentary, or GU tract or wounds secondary to trauma have a higher risk of infection.
Presenting signs and symptoms of wound infections include increasing pain, erythema, swelling, drainage, and tenderness at the incision site. Wounds not involving the perineum and not associated with entry into the GI or biliary tract are most often infected with S. aureus or streptococci. Such wounds can be safely managed with drainage, culture of a wound sample, irrigation, loose packing with gauze, and outpatient administration of antibiotics. Wounds involving the perineum or associated with the GI or biliary tract are often infected with multiple organisms, including gramnegative bacteria and anaerobes. Parenteral broad­spectrum antibiotics are administered, and hospital admission is necessary.
NECROTIZING FASCIITIS
Necrotizing fasciitis is a feared complication. The usual cause is direct contamination of the wound with group A streptococci or S. aureus. However, mixed aerobic and anaerobic infections have been reported. Risk factors include diabetes mellitus, hypertension, obesity, alcoholism,
 immunosuppression, and peripheral vascular disease, but necrotizing fasciitis also occurs in young, otherwise healthy individuals. Early clinical differentiation from cellulitis can be difficult. CT may show asymmetric fascial thickening, gas tracking along fascial planes, or focal fluid collections.

MRI is sensitive but not totally specific for necrotizing fasciitis and can be a useful adjunct. Hallmarks of fasciitis are the presence of marked systemic toxicity and pain out of proportion to local findings. In more advanced cases, there may be deep pain with patchy areas of surface hypesthesia, crepitation, or bullae. Treatment should include antibiotics and immediate surgical debridement. Antibiotic choice is controversial, but triple antibiotic
 therapy with penicillin or a cephalosporin, an aminoglycoside, and clindamycin probably should be used. For further discussion, see Chapter 152,
“Soft Tissue Infections.”
WOUND DEHISCENCE
Wound dehiscence can be superficial or can extend into the deeper fascial planes. Dehiscence is caused by inadequate closure or intrinsic host factors, such as malnutrition, glucocorticoid use, or diabetes. Serosanguineous fluid may leak from the wound. Dehiscence of abdominal incisions has the potential for evisceration. If evisceration is not present, conservative management using abdominal binders is appropriate. However, if there is any uncertainty about the extent of dehiscence, operative exploration is indicated.
VASCULAR COMPLICATIONS
SUPERFICIAL THROMBOPHLEBITIS
Superficial thrombophlebitis of the lower extremities is most frequently secondary to stasis in varicose veins. It is usually aseptic. There is redness and warmth of the affected vein. If there is no evidence of surrounding cellulitis or lymphangitis and no evidence of deep vein involvement on US, treatment is local heat, elevation, and NSAIDs. Suppurative superficial thrombophlebitis is characterized by erythema, palpable tender cord, lymphangitis, and pain. Suppurative thrombophlebitis requires excision of the affected vein.
DEEP VENOUS THROMBOSIS
When lower extremity superficial thrombophlebitis is seen in a postoperative patient, consider the possibility of concurrent deep venous thrombosis.
Deep venous thrombosis is typically characterized by leg pain or swelling, or both. For suspected deep venous thrombosis, Doppler US is the preferred diagnostic test. Patients with normal color flow Doppler study results should be treated with elevation and bed rest. Repeat color flow Doppler US studies should be performed in  days if symptoms persist, but sooner if symptoms worsen. For further discussion, see Chapter , “Venous
Thromboembolism Including Pulmonary Embolism.”
COMPLICATIONS OF DRUG THERAPY
Complications of drug therapy are numerous, but the most common implicated classes of drugs are anticoagulants, diabetic medications, antibiotics,
 and opioids. Another common problem is antibiotic­associated diarrhea. Many antibiotics can cause diarrhea, but the greatest concern in postoperative patients is pseudomembranous colitis. Pseudomembranous colitis is due to the toxin produced by the bacterium Clostridium difficile.
Pseudomembranous colitis is related to antibiotic use, which destroys the normal enteric bacterial flora, allowing an overgrowth of C. difficile. Even short courses of antibiotics have been associated with pseudomembranous colitis. Patients have watery and sometimes bloody diarrhea, fever, and crampy abdominal pain. There are three common ways to diagnose C.difficile: nucleic acid amplification tests, glutamate dehydrogenase, and enzyme immunoassay. The current recommendation for symptomatic patients is to use a nucleic acid amplification test technology like polymerase chain
 reaction. For patients with moderate disease, discontinue the offending antibiotic and prescribe metronidazole. For severe disease, discontinue the
 offending antibiotic and give vancomycin. For further discussion, see Chapters , “Acute Abdominal Pain” and , “Disorders Presenting Primarily
With Diarrhea.”
Many medicines can cause drug fever, but antibiotics are the drug class most commonly implicated. The mechanisms proposed are hypersensitivity reactions, pyogenic effect, and disturbed thermoregulation. In patients in whom no source for fever can be found, it is appropriate to consider stopping medications known to cause drug fever. Most often, the patient will require admission to rule out this diagnosis.
COMPLICATIONS OF BREAST SURGERY
Complications of breast surgery are infrequent, but patients can develop minor wound infections and hematomas. Rarely, pneumothorax has been reported. Wound hematomas frequently require operative control for proper evacuation and hemostasis.
Early complications seen with mastectomies include wound infection, necrosis of skin flaps, and the accumulation of seromas. The incidence of
 postmastectomy lymphedema ranges from a low of .5% to a high of 80%, and it is increased with the more extensive the surgery.
COMPLICATIONS OF GI SURGERY
In addition to the complications already reviewed, patients who have undergone any GI surgery may have intestinal obstruction, intra­abdominal abscess, pancreatitis, cholecystitis, fistulas, and tetanus. Certain procedures, such as anastomoses, bariatric surgery, placement of gastrostomy tubes, biliary tract surgery, other laparoscopic surgery, stoma creation, colonoscopy, and rectal surgery, are associated with specific complications.
INTESTINAL OBSTRUCTION
Ileus, a functional obstruction of the bowel, is postulated to be the result of stimulation of the splanchnic nerves, leading to neuronal inhibition of coordinated intrinsic bowel wall motor activity. It is expected after any operation in which the peritoneal cavity is violated. After GI surgery, small bowel tone usually returns to normal within  hours, and colonic function returns within  to  days. Ileus can also occur after non­GI procedures and is usually secondary to anesthetic agents; function returns to normal after  hours. Prolonged ileus can be caused by peritonitis, intra­abdominal abscess, hemoperitoneum, pneumonia, electrolyte imbalance, sepsis, and medications.
Presenting symptoms of ileus include nausea, vomiting, obstipation, constipation, abdominal distention, and abdominal pain. When these symptoms are present in the first few days after surgery, they are most often due to adynamic ileus. The symptoms of adynamic ileus are most often mild and respond to nasogastric suction, bowel rest, and IV hydration. However, in cases of prolonged ileus, look for an underlying cause. Evaluation includes abdominal radiography to identify air­fluid levels, chest radiography, CBC, measurement of electrolyte levels, and urinalysis to search for secondary causes of ileus.
Mechanical ileus of the bowel is most often secondary to adhesions, and is discussed in detail in Chapter , “Bowel Obstruction.” In the ED, differentiating between functional ileus and mechanical bowel obstruction can be difficult. Abdominal CT scanning is helpful to identify ischemia or
 obstruction due to bowel strangulation. Although CT is still more definitive, US has a sensitivity of approximately 85% and does not involve exposing
 the patient to radiation. The results of CT may have an impact on the decision to manage the obstruction expectantly or not. Once the diagnosis of mechanical obstruction is suspected or confirmed, surgical consultation is indicated.
INTRA­ABDOMINAL ABSCESS
Intra­abdominal abscess is caused most frequently by preoperative contamination, spillage of bowel contents during surgery, contamination of a hematoma, or postoperative anastomotic leaks. Patients may have abdominal pain, nausea, vomiting, ileus, abdominal distention, fever, chills, anorexia, and abdominal tenderness. If the diagnosis is suspected, obtain CT or US of the abdomen. The patient should receive broad­spectrum antibiotics (see Chapter , “Acute Abdominal Pain”). Treatment is percutaneous drainage or surgical exploration.
PANCREATITIS
Pancreatitis after abdominal surgery is secondary to direct manipulation or retraction of the pancreatic duct. Pancreatitis most commonly occurs after gastric resection, biliary tract surgery, and endoscopic retrograde cholangiopancreatography. Clinical presentation varies from mild nausea, vomiting, and abdominal discomfort to intractable vomiting, leukocytosis, and left­sided pleural effusion. Severe hemorrhage can cause lumbar pain accompanied by blue­gray discoloration of the skin in the flank area (Turner sign) or similar changes around the umbilicus (Cullen sign). Although the serum amylase level rises in acute pancreatitis, it is also elevated in patients with severe cholecystitis, renal insufficiency, intestinal obstruction, perforated ulcer, or ischemic bowel. A serum lipase measurement may help to identify those with true pancreatitis, although it may be elevated in a patient with a perforated viscus and other conditions. Abdominal radiographs may show localized ileus in the region of the pancreas (sentinel loop).
US and CT are useful in defining pancreatic fluid collections or abscesses. In general, the treatment of postoperative pancreatitis is similar to the treatment of nonoperative pancreatitis (see Chapter , “Pancreatitis and Cholecystitis”).
CHOLECYSTITIS
Postoperative complications related to the gallbladder include biliary colic, acute calculous cholecystitis, or acute acalculous cholecystitis. The cause of these disorders in the postoperative period is not clear. US studies of the gallbladder and pancreas should be performed to aid in the diagnosis.
Acalculous cholecystitis is of particular concern in the postoperative period. The disorder seems to be more common in elderly men, but can occur in any sex and age group. There is no single test with adequate diagnostic accuracy to either diagnose or exclude the possibility of acalculous
 cholecysticis. Clinicians must use a combination of high diagnostic suspicion, a good history and physical, as well as appropriate diagnositic testing.
Signs and symptoms are similar to those for calculous cholecystitis. Results of liver function studies and the neutrophil count may be normal.
Important findings on US include gallbladder enlargement, wall thickening, and pericholecystic fluid collection, but no gallstones. Hepatobiliary scintigraphy may be helpful. Early diagnosis is critical because early operative intervention can reduce morbidity and mortality.
FISTULAS
Enterocutaneous fistulas can occur almost anywhere in the GI tract and are usually the result of technical complications or direct bowel injury. Highoutput fistulas can result in electrolyte abnormalities and volume depletion. Fistulas involving the proximal GI tract are frequently high output and are of the greatest concern. Sepsis is the other major complication. Most patients require admission, although many fistulas ultimately close spontaneously.
TETANUS
Although most cases of tetanus in the United States occur after minor trauma, there have been numerous reports of tetanus after general surgical
 procedures. Clostridium tetani is found in the GI tract of 1% of the population. During GI surgery, there is spillage of C. tetani. Proliferation of the organism is facilitated by the presence of devitalized tissue, blood clots, and surgical suture. Incubation can take from  to  days, at which time the toxin leads to clinical tetanus. The classic symptoms of tetanus, trismus, and opisthotonos may not be evident initially. Patients may present with nonspecific symptoms of abdominal discomfort, fever, and abdominal wall rigidity. Diagnosis is based on physical examination and a history of inadequate immunization.
ANASTOMOTIC LEAKS
Anastomotic leaks occur most frequently after esophageal and colonic surgeries and least frequently after gastric and small intestinal anastomoses.
The cause of anastomotic leakage is related mainly to surgical technique.
Intrathoracic esophageal anastomotic leaks usually manifest within  days of surgery. The presentation is dramatic, with fever, chest pain, tachypnea, tachycardia, and possibly shock. Chest radiograph may reveal a pneumothorax with pleural effusion. Disruption can be confirmed by contrast esophagography using a water­soluble contrast agent. Even with immediate reoperation, morbidity and mortality rates are high.
The signs and symptoms of gastric anastomotic leaks include abdominal pain, fever, leukocytosis, gastric outlet obstruction, hyperamylasemia, hyperbilirubinemia, peritonitis, and shock. Plain radiographs may reveal pneumoperitoneum or air­fluid levels. Provide volume resuscitation, parenteral broad­spectrum antibiotics, and nasogastric tube drainage. Immediate surgery is required.
Small intestinal anastomoses infrequently leak because of the excellent blood supply and rapid healing of the area. However, if a leak occurs, the patient usually presents with local abscess formation or peritonitis. Treatment is immediate reoperation.
Colorectal anastomoses are prone to disruption because of the large number of pathogenic bacteria found, the propensity for colonic distention, and the presence of only a single thin layer of circular muscle to support sutures. Patients usually present  to  days postoperatively with fever and abdominal pain. CT confirms the diagnosis. Patients should receive broad­spectrum parenteral antibiotics, nasogastric tube drainage, and adequate fluid resuscitation in preparation for surgery.
BARIATRIC SURGERY COMPLICATIONS
Four main bariatric procedures are currently being performed for morbid obesity: laparoscopic adjustable gastric banding using the LAP­BAND ® device (Allergan, Inc., Irvine, CA), sleeve gastrectomy, Roux­en­Y gastric bypass, and biliopancreatic diversion with duodenal switch. Overall operative
 mortality is <2%, but postoperative complications are common and are likely related to the technical skill of the surgeon. Common complications are
,16 listed in Table 87­4. TABLE 87­4
Complications of Gastric Bypass Procedures
Complication Presentation Signs and Symptoms Diagnostic Test
Anastomotic leak 0–28 d Tachycardia, fever, abdominal pain, nausea, vomiting, Clinical suspicion. CT scan or upper GI hypotension study is useful, but may be negative
Intra­abdominal bleeding 0–28 d Tachycardia, abdominal pain, hypotension CT scan or upper GI study
Intraluminal GI bleeding Hours to Melena, hematemesis, hypotension, altered mental status Emergent endoscopy months
Ventral hernia Anytime Pain at incision site or palpable hernia Clinical diagnosis
Bowel obstruction  wk to  mo Nausea, vomiting, abdominal pain Plain radiography or CT looking for air­fluid levels
Stomal stenosis  mo to  y Postprandial abdominal pain, nausea, vomiting Endoscopy or upper GI study
Stomal ulcer Months to Abdominal pain, upper GI bleed Endoscopy years
Stomal obstruction Months to Nausea and vomiting with solids and liquids Endoscopy years
Cholelithiasis/cholecystitis Months to Abdominal pain with fatty foods, fever, tachycardia US years
Dumping syndrome Anytime Diarrhea, abdominal cramps, nausea, vomiting, Clinical diagnosis or endoscopy tachycardia, palpitations, flushing, dizziness, syncope
Vitamin deficiencies Months to Weakness, bone loss, anemia, fractures, neuropathy, CBC, iron studies, parathyroid hormone years hypercalcemia studies, vitamin levels
Gastric slippage Days to years Abdominal pain, dysphagia, food intolerance, reflux Upper GI study
Esophageal, gastric pouch After band Epigastric abdominal pain, dysphagia, reflux Upper GI study dilation adjustment
Gastric necrosis Anytime Abdominal pain Upper GI study
Nausea, vomiting, and abdominal pain are common symptoms in ED patients with a history of bariatric surgery. In the first few postoperative weeks, consider life­threatening problems such as anastomotic leak and intra­abdominal bleeding. In patients with abdominal pain, tachycardia, or abdominal tenderness in the early postoperative period, a CT scan is often required to rule out these diagnoses.
A common complication of the Roux­en­Y gastric bypass is dumping syndrome, which can occur either right after the meal (early) or  to  hours later
(late). Dumping symptoms occur when the pylorus is bypassed or removed. The hyperosmolar chyme contents of the stomach are dumped into the jejunum, causing rapid influx of extracellular fluid and an autonomic response. Patients experience nausea, epigastric discomfort, palpitations, colicky abdominal pain, diaphoresis, and, in some cases, dizziness and syncope. Patients with early dumping symptoms experience diarrhea, whereas those with late dumping symptoms,  to  hours postprandially, usually do not. The late dumping syndrome is believed to be due to a reactive hypoglycemia.
The mainstay of treatment is dietary modification; consumption of small, dry meals; and separation of solids from liquids. In refractory cases, pyloroplasty can be tried. Most patients with dumping syndrome do not require hospital admission.
Patients with gastroesophageal reflux disease present with burning epigastric pain that is aggravated by meals and unrelieved by vomiting. The syndrome is caused by reflux of bile into the stomach. Diagnosis is made clinically, but other potential diagnoses are often ruled out with endoscopic examination.
Wernicke’s encephalopathy is a rare, but serious, complication that must be considered in a patient with a history of bariatric surgery who presents with any cerebellar signs, ophthalmoplegia, weakness, and/or memory disturbances. Although vitamin deficiencies are common with both Roux­en­Y gastric bypass and biliopancreatic diversion, vitamin B deficiency is the only one that requires emergent intervention.

NONBARIATRIC GASTRIC SURGERY
Patients who have undergone partial or complete gastrectomy for nonbariatric reasons can present with a few distinct syndromes: dumping syndrome, alkaline reflux gastritis, afferent loop syndrome, and postvagotomy diarrhea. Although these complications are rare, the symptoms can be disabling. Dumping syndrome as a result of nonbariatric gastric surgery is treated in the same way as dumping syndrome after bariatric procedures.
Patients with afferent loop syndrome also develop severe epigastric pain  to  hours after eating, which is relieved by vomiting. The vomitus is bilious, without food. The syndrome occurs in patients who have undergone gastroenterostomy (Billroth II) reconstruction after partial gastrectomy. Diagnosis is made by contrast radiography or endoscopy. Operative reconstruction is required.
Truncal vagotomy usually results in increased bowel movements, but occasionally results in diarrhea. Diarrhea is variable in occurrence and not associated with food intake. It is often unpredictable and explosive, which can lead to weight loss, malnutrition, and severe social complications. The incidence of the diarrhea decreases with time, and treatment is mostly symptomatic.
LAPAROSCOPIC SURGERY
BILIARY TRACT SURGERY
More than 90% of all cholecystectomies are now performed laparoscopically. Complications can occur after open and laparoscopic cholecystectomies

(Table 87­5); complications can also be related to the laparoscopic technique (Table 87­6).
TABLE 87­5
Complications of Cholecystectomy
Bile leak
Bile duct stricture
Bleeding
Bowel injury
Intra­abdominal abscess
Acute myocardial infarction
Pancreatitis
Peritonitis
Pulmonary complications
Retained common duct stones or stones spilled into peritoneum
Splenic injury
Umbilical hernia
Wound infection
TABLE 87­6
Complications of Laparoscopy
Related to pneumoperitoneum
Cardiac arrhythmias during the procedure
Subcutaneous emphysema
Pneumothorax
Pneumomediastinum
Carbon dioxide embolization
Related to insertion of needle and trocar
Bleeding from trocar site
GI tract injuries
Laceration
Intestinal burns
GU tract injuries
Major vessel injuries
Hernia from trocar site
Wound infection
Miscellaneous
Retained intra­abdominal gallstones
Biliary cutaneous fistula
Chronic pain
Infertility
Cholelithiasis
Metastases to the trocar site
The evaluation of abdominal pain after cholecystectomy depends on the clinical condition of the patient. If there are signs of peritoneal irritation or fever, an injury to the biliary system is likely. Obtain an abdominal CT in addition to a CBC, electrolyte measurements, liver function tests, and serum lipase level. A collection of bile can be seen on CT, but endoscopic retrograde cholangiopancreatography is required to identify the specific site of the injury. Depending on the endoscopic retrograde cholangiopancreatography results, reoperation may be necessary. Small collections of bile may require only observation or percutaneous drainage.
Patients presenting soon after cholecystectomy with pain, pancreatitis, and/or jaundice may have retained common duct stones. If US does not demonstrate a dilated common bile duct or if CT does not reveal an intra­abdominal collection of fluid, an endoscopic retrograde cholangiopancreatography should be performed. Endoscopic sphincterotomy is usually an effective means of dealing with retained stones. Patients presenting late after cholecystectomy with fever, pain, and jaundice may have bile duct stricture. Diagnosis requires endoscopic retrograde cholangiopancreatography. Insertion of stents is usually tried first, but surgical repair may be necessary. A more recent concern has been the spillage of gallstones into the peritoneal cavity at the time of surgery. Initially, such stones were thought to be innocuous. However, they have been linked to abdominal pain, pelvic pain, dysmenorrhea, intra­abdominal abscess, colocutaneous fistula, and implantation into the ovary with subsequent infertility.
OTHER LAPAROSCOPIC SURGERIES
Laparoscopic techniques are used for cholecystectomy, appendectomy, colon resection, antireflux surgery, herniorrhaphy, fundoplication, and most gynecologic and urologic surgical procedures. As with any laparoscopic procedure, there are risks related to the pneumoperitoneum and insertion of the trocar (Table 87­6). In addition to the potential for bowel injury, major vessel injury, and splenic injury, gynecologic and urologic procedures carry a risk of injury to the urinary bladder and ureters.
STOMAS
The two most commonly placed stomas are the ileostomy and the colostomy. Problems with stomas can be quite debilitating. Most acute complications are related to technical errors of stoma placement. Other complications include the development of Crohn’s disease or carcinoma at the stomal site, stomal ischemia and necrosis, peristomal skin irritation, peristomal hernia, and stomal prolapse.
Ischemia and stomal necrosis are manifested very early in the postoperative course. The cause is inadequate blood supply to the stoma. Normally, the stoma is pink, without evidence of cyanosis. Any evidence of compromised blood flow requires surgical evaluation.
Peristomal maceration and skin destruction are most likely secondary to a poor seal of the stomal appliance. Consult an enterostomal therapist for a properly fitting appliance.
Stomal prolapse can occur with ileostomies and colostomies. The cause is usually inadequate fixation of the intra­abdominal portion or too large an abdominal wall opening. Patients present with stoma protrusion, with or without pain. Examine the stoma for viability. It should be pink and painless.
If the tissue is viable, attempt reduction and follow with surgical consultation. Definitive therapy requires surgical revision.
Parastomal hernias can develop if the abdominal wall opening is too large. Determine if the hernia is incarcerated, attempt reduction, and consult a surgeon. Definitive therapy requires local reconstruction of the orifice.
COLONOSCOPY
Potential complications of colonoscopy include hemorrhage, perforation, retroperitoneal abscess, pneumoscrotum, pneumothorax, volvulus,
 postcolonoscopy distention, splenic rupture, appendicitis, bacteremia, and infection. Hemorrhage is the most common complication and can be secondary to polypectomy procedures, biopsies, laceration of the mucosa by the instrument, or tearing of the mesentery or spleen. If the bleeding is intraluminal, the patient will develop rectal bleeding. Patients with mesenteric or splenic injury have signs of intra­abdominal bleeding. Treatment of intraluminal bleeding depends on the magnitude of hemorrhage. Intra­abdominal bleeding requires emergency laparotomy. Colon perforation with
 pneumoperitoneum usually is evident immediately, but can take several hours to manifest. Perforation is usually secondary to intrinsic disease of the colon (e.g., diverticulitis) or to vigorous manipulation during the procedure. Most patients require immediate laparotomy, but in some patients presenting late (1 to  days later) without signs of peritonitis, hospital observation may be appropriate.
RECTAL SURGERY
Patients who have undergone hemorrhoidectomy frequently have problems with postoperative urinary retention, the management of which has been discussed previously in the section “Urinary Retention.” Three other problems that can occur are constipation, rectal hemorrhage, and rectal prolapse.
The management of constipation in a patient who has undergone rectal surgery is no different from management in any other patient. Perform gentle rectal examination to identify fecal impaction, and if present, remove the impaction. Otherwise, enemas can be used. Posthemorrhoidectomy rectal hemorrhage can occur immediately postoperatively but may be delayed up to weeks after the surgery. Causes of delayed bleeding include sepsis of the pedicle, disruption of a clot, and sloughing of tissue. Bleeding can be scant or massive. Temporary balloon tamponade using a Foley catheter may temporize until surgical ligation of the involved vessel is performed.
Mucosal prolapse occurs when the surgeon has not removed all redundant mucosa during hemorrhoidectomy and is much more common than rectal prolapse. Local treatment by a surgeon is usually corrective. Rectal prolapse can occur after any anorectal surgical procedure and likely is related to injury of the puborectalis muscle. The diagnosis is obvious on examination. The treatment is reduction (see Chapter , “Anorectal Disorders”) and surgical consultation.
Infection after anorectal surgery is surprisingly uncommon. The patient usually complains of increasing pain and fever. Examination of the area is necessary to detect an abscess or cellulitis. Fournier’s gangrene may follow anorectal surgery. If this is suspected, give broad­spectrum parenteral antibiotics immediately. The patient must undergo immediate surgical debridement.


