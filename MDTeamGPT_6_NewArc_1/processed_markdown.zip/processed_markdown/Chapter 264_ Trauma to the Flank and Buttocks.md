## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 264: Trauma to the Flank and Buttocks
Amy M. Stubbs
INTRODUCTION
Penetrating trauma to the flank or buttocks may result in a number of serious retroperitoneal, intraperitoneal, or vascular injuries, many of which require operative repair. Further complicating the evaluation, the signs and symptoms may be subtle or delayed in retroperitoneal, diaphragmatic, bowel, or rectal injuries. The decision to pursue an operative versus conservative course is informed by the emergency evaluation and imaging.
PENETRATING FLANK TRAUMA
ANATOMY AND PATHOPHYSIOLOGY
The flank is defined as the region between the anterior and posterior axillary lines, bordered superiorly by the sixth ribs and inferiorly by the iliac
 crests, containing retroperitoneal organs, soft tissue, ribs, and spine. Although a penetrating wound to the flank can produce intraperitoneal injury with the associated findings of peritonitis or hemoperitoneum, it is possible that a penetrating flank injury could injure only the retroperitoneal organs or musculoskeletal tissue, which can be difficult to ascertain from exam alone. The thoracic cavity, spine, intra­abdominal, and retroperitoneal organs are all at risk for injury from a penetrating flank wound depending on the depth, trajectory, velocity, and construct of the projectile. Bullet or missile
 wounds, especially high­velocity wounds, may cause damage from direct trauma, kinetic energy, or cavitation. Stab injuries are low velocity and cause
 injury through direct tissue damage.
CLINICAL APPROACH
Perform a primary survey using the Advanced Trauma Life Support protocol. Obtain information about the mechanism of injury, how much time has passed since the event, and the nature of the weapon. For gunshot wounds, attempt to ascertain the type of gun, number of wounds, and patient distance from the weapon. Examining the location of wounds may assist in estimating the bullet path and structures at risk for injury; however,
,5 trajectory estimates can be unreliable as bullets can fragment or ricochet. For stab wounds, attempt to determine the size and trajectory of the weapon as well as the depth of penetration. Examine for abdominal tenderness and peritoneal signs that may indicate intraperitoneal injury along with signs of injury to the GI or GU tracts, such as gross blood on rectal exam, at the urethral meatus, or in the urine. Spinal tenderness or neurologic deficits mandate further evaluation of the spine (Figure 264­1). Wounds near the costal margin or superior flank should raise concern for possible thoracic or diaphragmatic injury.
FIGURE 264­1. Bone windows of abdominopelvic CT after a gunshot wound to the flank. Comminuted fracture of L3 with retained bullet fragments and hematoma in spinal canal are visible (arrows). The patient was paraplegic and also had a perinephric hematoma. [Photo contributed by Truman Medical Center­
Hospital Hill, Kansas City, MO.]

Chapter 264: Trauma to the Flank and Buttocks, Amy M. Stubbs 
. Terms of Use * Privacy Policy * Notice * Accessibility
DIAGNOSIS
Patients with penetrating flank trauma who do not require emergent laparotomy need further evaluation to establish the extent of injury and to determine if the projectile has violated the peritoneum. Evaluation of flank trauma represents challenges related to its anatomic position and potential for retroperitoneal injury with late manifestations. Sparse data exist on isolated penetrating flank trauma; most of the recommendations for
 management come from studies of both flank and back trauma or flank and abdominal trauma. Several diagnostic modalities exist to further evaluate penetrating flank trauma, each with some degree of limitation in its ability to exclude injury. Table 264­1 lists the diagnostic modalities available as well as their advantages and disadvantages (see also Chapter 263, “Abdominal Trauma”). No single method is currently considered sufficient to rule
6­9 out significant injuries and a combination of modalities, along with observation, is recommended. Blind probing of the wound(s) with swabs or digits is not recommended.
TABLE 264­1
Diagnostic Modalities for Evaluation of Flank Trauma
Modality Advantages Disadvantages
CT Sensitive and specific for injury of peritoneal and retroperitoneal Can miss diaphragmatic injury or colon injuries organs Oral/rectal contrast, time consuming
Useful for ascertaining injury path
Ultrasound Rapid, portable, noninvasive Not sensitive for retroperitoneal or hollow viscous
Sensitive and specific for hemopericardium and intraperitoneal fluid injuries
Insufficient to rule out specific organ injury
Diagnostic peritoneal Sensitive for intraperitoneal injury Invasive, high false­positive rate lavage Unable to detect diaphragmatic or retroperitoneal injuries
Local wound Sensitive for peritoneal violation in abdominal trauma when Limited utility in flank/back due to no discernable exploration technically adequate fascial planes3
Can lead to nontherapeutic laparotomy
Laparoscopy Highly sensitive and specific for peritoneal and diaphragmatic injury6 Invasive
Not as sensitive for retroperitoneal injury
Can avoid unnecessary laparotomy
LABORATORY TESTING AND IMAGING
Initial laboratory testing and imaging often follow institutional protocols. At minimum, obtain a hemoglobin/hematocrit, type and screen, urinalysis, urine pregnancy test (if applicable), and chest radiograph. Radiographs of the abdomen or pelvis are of minimal use unless attempting to determine
 trajectory.
,6,10
CT is the imaging modality of choice in hemodynamically stable patients with penetrating flank trauma. Historically, double contrast (PO and IV) or triple contrast (PO, IV, and PR) has been recommended. However, some evidence demonstrates that single contrast (IV) with
,12 modern multirow detector CT is sufficient to detect significant injuries (Figures 264­2 and 264­3). The choice of imaging is dependent on trauma and radiology protocols at the specific facility, as well as consideration of the drawbacks of PO/PR contrast administration. CT angiography is used in many medical centers now for suspected vascular injury. Free intraperitoneal fluid or air suggests peritoneal perforation. Bowel wall thickening with adjacent hematoma or contrast extravasation from the bowel suggests bowel injury. Delayed images of the GU tract are useful to detect urinary
 extravasation. The presence of a wound track near either the diaphragm or bowel mandates inspection for injury to either of those organs.
FIGURE 264­2. Abdominopelvic CT with IV contrast after stab wound to left flank. Contrast extravasation is seen in the left paraspinous muscles with an adjacent retroperitoneal hematoma. [Photo contributed by Truman Medical Center­Hospital Hill, Kansas City, MO.]
FIGURE 264­3. Abdominal CT with IV contrast demonstrating a renal laceration from a stab wound. [Reproduced with permission from Block J, Jordanov MI, Stack LB,
Thurman RJ (eds): The Atlas of Emergency Radiology. New York: McGraw­Hill, Inc.; 2013, Fig. 6­21.]
TREATMENT AND DISPOSITION
Evaluate and resuscitate patients with penetrating trauma to the flank according to standard protocols (see Chapter 254, “Trauma in Adults”). Obtain emergent surgical consultation. Administer broad­spectrum IV antibiotics, such as a carbapenem, to cover for gram­negative aerobic and anaerobic
 organisms for suspected intraperitoneal injury. Exploratory laparotomy is indicated for patients who are hemodynamically unstable or who exhibit peritoneal signs after sustaining a penetrating wound to the flank. Resuscitative endovascular balloon occlusion of the aorta, if
 available, may also be considered as an option for signs of shock or hemorrhage.
Selective nonoperative management, which combines serial exams and other diagnostic modalities, is appropriate for patients with stab wounds to the flank who are hemodynamically stable and have no abdominal tenderness. Traditionally, all patients with a gunshot wound to the flank underwent exploratory laparotomy; however, studies have demonstrated that selective nonoperative management is safe for specific patients with tangential injuries and no signs of instability or peritonitis. Benefits of this approach are decreased length of stay and lower rates of nontherapeutic
14­16 laparotomies. Appropriate patient selection, trauma center experience, and surgical staff availability are all key aspects to successful outcomes
,8,9,14,15,17 with selective nonoperative management.
Patients with penetrating trauma to the flank who are managed nonoperatively typically require admission to the hospital for observation and serial
,9 abdominal exams, which have been shown to be highly sensitive for significant abdominal injury. The ability to obtain a reliable exam is essential; factors such as examiner experience, body habitus, and patient mental status should be considered.
PENETRATING BUTTOCK TRAUMA
ANATOMY AND PATHOPHYSIOLOGY
The gluteal region extends from the iliac crest to the gluteal fold and is bordered by the greater trochanters. The gluteal region is divided into an upper zone and a lower zone by a line drawn at the level of the trochanters. Depending on trajectory, any pelvic or intra­abdominal structure is susceptible to injury following a penetrating injury to the buttocks; however, gunshot wounds most commonly cause injury to the small bowel, colon, and rectum.
18­21
Stab wounds more frequently cause injuries to the rectum or vasculature, with the superior gluteal artery being injured most commonly.
Most of the major pelvic vasculature and organs reside in the upper zone; therefore, penetrating wounds in the upper zone have a higher risk of major
 injury compared to wounds in the lower zone, which contains the lower bladder, prostate, vagina, urethra, external genitalia, and the distal rectum.
An important component of the history is information regarding the weapon used and the patient’s position at the time of injury, as this can help determine the trajectory of the bullet or knife.
DIAGNOSIS AND TREATMENT
As discussed above, exploratory laparotomy and broad­spectrum antibiotics are indicated for patients with hemodynamic instability or peritoneal signs. The evaluation of penetrating buttock wounds focuses on identification of potential injury to the lower GI and GU tract, as well as to pelvic vasculature. Perform a rectal examination to identify gross blood and perform stool guaiac testing, although a negative guaiac test does not rule out rectal injury. Evaluate for the presence of hematuria. Assess the peripheral pulses in the lower extremities for decreased pulses or pallor as evidence of a more proximal injury. Assess the ankle­brachial index if there is concern for vascular injury. Perform a thorough neurologic examination of the lower
 extremities, searching for any signs of injury to the sciatic or femoral nerves.
Patients with penetrating buttock injury who do not meet criteria for emergent laparotomy may be candidates for selective nonoperative management using a combination of serial exams and adjunctive modalities, including the FAST exam, CT or CT angiography, sigmoidoscopy, and cystourethrogram. Upper zone gluteal stab wounds can undergo local wound exploration to evaluate for muscle violation. Patients without muscle violation can be observed with serial exams, whereas those with muscle violation require CT and sigmoidoscopy, plus cystography for hematuria.
A similar conservative approach is appropriate for lower zone gluteal stab wounds and gluteal gunshot wounds. Order a CT scan, preferably with triple contrast, to evaluate for injury in the stable patient. Obtain a cystourethrogram, either as a separate study or in conjunction with contrasted CT, if there
,21,22 is blood on urinalysis or the wound is close to the GU tract.
In most cases, sufficient diagnostic workup may be obtained with CT (Figure 264­4), but sigmoidoscopy under anesthesia is advised if there is any concern about injury to the rectum based on exam findings, wound location, or imaging. If the CT demonstrates a pelvic hematoma, angiography or venography may be indicated to document a significant vascular injury. In many centers, CT angiography has replaced these techniques, but
 endovascular intervention may be required for extensive pelvic bleeding.
FIGURE 264­4. Pelvic CT with IV contrast in patient with gunshot wound to buttocks. Bullet fragments are visible in the soft tissue as well as in the presacral region.
Hematoma is causing anterior displacement of the rectum (arrows). [Photo contributed by Truman Medical Center­Hospital Hill, Kansas City, MO.]


