## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 219: Electrical and Lightning Injuries
Caitlin Bailey
INTRODUCTION
Electrical injuries are divided into high­voltage injuries (≥1000 V), low­voltage injuries (<1000 V), and electric arc flash burns, which by definition do not result in passage of current through the tissues. Lightning injury is an extreme and unique form of electrical injury. This chapter also discusses injuries caused by electronic control devices, such as the Taser®. Burns from electrical accidents can result from heating due to electric current flow through tissues, explosions, and burning of flammable liquids, clothes, and other objects. Burns are discussed in Chapter 217, “Thermal Burns.”
EPIDEMIOLOGY
Approximately 6500 electrical injuries occur per year in the United States, accounting for 4% of total burns. Of these, the majority are work related

(61%), mostly industrial injuries. The overall complication rate is .6%, with the fewest complications among children aged  to  years (2%). There
,3 were 134 fatal electrical injuries reported by the Electrical Safety Foundation International in 2017, a slight decline from previous years. The most common high­voltage injuries in the United States are also work related and include arc burns in electricians and high­voltage injuries in power line
 workers. High­voltage power line injuries are particularly disabling because they often lead to deep muscle necrosis and the need for fasciotomy and
 amputation.
BASICS OF CURRENT FLOW
Electric current is the movement of electrical charges. Table 219­1 lists a few key terms related to electricity.
TABLE 219­1
Electrical Terms and Units of Measure
Term Unit of Measure
Electric current Amperes
Movement of electrical charges
Current flow Volts
Driven by voltage or electrical potential difference
Resistance Ohms
Hindrance to flow of current
Ohm’s law (current = voltage/resistance)
The current is proportional to voltage.
The current is inversely proportional to resistance.
Current flow is measured in amperes. Current flow is driven by an electrical potential difference, which is measured in volts. Intervening material
 between two or more contact points resists electric current flow; this resistance is measured in ohms. Ohm’s law describes the relationship between
Chapter 219: Electrical and Lightning Injuries, Caitlin Bailey c©u2r0re2n5t M(I)c, Gvoraltwag He i(llV. )A, alln Rdi grehstsis tRaensceer (vRe)d a.n d T setramtess otfh Uats teh e * Pcurirvraecnyt tPhorolicuyg h * Na cootinced u * c Atocrc beestswibeielinty two points is directly proportional to the potential difference or voltage drop across the two points and inversely proportional to the resistance between them. For example, a person who grasps a grounded pipe in one hand and a metal cable connected to a 120­volt source in the other hand will experience a current flow through the body, the magnitude of which varies inversely with the resistance of the circuit. If the total resistance from the power source, through the person, and to the ground is estimated to be 1000 Ω, the current (I) would be calculated as follows: I = (120 V)/(1000 Ω) = .120 A = 120 mA.
Conductors are materials that allow electric current to flow easily. Insulators are materials that do not allow electric current flow. Tissues with high fluid and electrolyte content conduct electricity better than tissues with less fluid and electrolyte content. Bone is the biologic tissue with the greatest resistance to electric current, while nerves and vascular structures have low resistance. Dry skin has high resistance, but sweaty or wet skin has much less resistance.
Many of the physiologic effects of electric shock are related to the amount, duration, and type of current [alternating current (AC) or direct current
(DC)], and the path of current flow (Table 219­2). DC current flows in a constant direction, whereas AC current alternates direction in a cyclical fashion. Standard household electricity is AC. Electricity in batteries and lightning is DC. Low­frequency (50­ to 60­Hz) AC can be more dangerous than similar levels of DC because the alternating current fluctuations can result in ventricular fibrillation. The identification of electric shock as due to AC or DC is also important to reconstruct the mechanism of injury. AC current can produce muscular tetany, during which the victim cannot let go of the electrical source. Both AC and DC current can hurl the victim away from the current source, which results in severe blunt force injury.
TABLE 219­2
Effects of Current
Minimum Current:  Hz
Effect Current Path
AC (mA)* Tingling sensation, minimal perception Through intact skin .5–2.0
Pain threshold Through intact skin 1–4
Inability to let go: tetanic contractions of hand and forearm tighten grasp, From hand through forearm muscles 6–22 decreasing skin resistance into trunk
Respiratory arrest: can be fatal if prolonged Through chest 18–30
Ventricular fibrillation Through chest 70–4000
Ventricular standstill (asystole): similar to defibrillation; if current stops, sinus Through chest >2000 rhythm may resume
Abbreviation:AC = alternating current.
*Ranges are approximate and depend on various factors.
For current to flow through an individual, a complete circuit must be created from one terminal of a voltage source to a contact area on the body, through the subject, and then from another contact on the person to the other terminal of the voltage source (or to a ground that is connected to the voltage source). Current flows through a person from one contact area to another along multiple, somewhat parallel paths. For example, electrical power source contacts just on the left hand and left leg would result in current flow through those limbs and the trunk, including the heart, muscles of respiration, and other tissues in the trunk. Current would not flow through the other limbs or head, because they are not in an electrically conductive path between the two power source contacts. The pattern of current flow through the body, if known, can be used to raise or lower suspicion of injury to certain body parts; for instance, hand­to­hand flow involves crossing the thorax and heart.
ELECTRICAL INJURIES
MECHANISMS OF ELECTRICAL INJURY
HIGH­ AND LOW­VOLTAGE INJURIES
The risk for serious and fatal electrical injury increases with voltage, especially >600 V (Table 219­2). High voltage is usually defined as >1000 V. Power lines in U.S. residential areas typically carry 7620 V AC. This is stepped down by transformers to 240 V AC before entering most residential and nonindustrial buildings. In the United States, home outlets are 120 V, and in Europe and Australia, they are 240 V. Highvoltage injuries are more often associated with severe musculoskeletal, visceral, and nervous system injury than are low­voltage injuries.
Electricity­induced injuries can occur via several mechanisms: (1) direct tissue damage from the electrical energy, (2) tissue damage from thermal energy, and (3) mechanical injury from trauma induced by a fall or muscle contraction.
ELECTRICAL BURNS
Electrical burns are severe when high voltages are involved, because only a fraction of a second of current flow is necessary for
 severe damage to occur. Burns are less common with low­voltage injuries, because low­voltage contact produces little heat energy in the skin and
 other tissues.
ELECTRIC ARC INJURIES
Electricity arcing from one conductor to another may radiate enough heat to burn and even kill persons  or more feet from the arc. There can also be a blast force that throws the person. Arcs that do contact a person directly will have heating due to current flow through the body, in addition to the
 flash burn and mechanical blast forces. Serious burns often result. The voltages that create an electric arc are usually in the thousands of volts.
Temperatures as high as ,000°C (35,000°F) are created. Serious, and sometimes fatal, burns may result from heat radiated by the arc and clothing ignited by the arc.
TETANIC CONTRACTIONS
Electric current can induce sustained muscular contraction, or tetany. The overall effect varies according to type (AC or DC), frequency, voltage, and
,8 extent of contact. For example, AC current flowing through the forearm can cause flexor tetany of the fingers and forearm that overpowers actions of
 the extensor muscles. Forceful muscle contractions can cause fractures and joint dislocations, especially around the shoulders. If the hand and fingers are properly positioned, the hand will grasp the conductor tightly, leading to prolonged, low­resistance contact with the power source because the person cannot let go. This allows current to flow for many seconds or minutes.
The increased duration of contact and the decreased contact resistance caused by a tight sustained grasp greatly increase the heat­related damage to deep tissues. Heating due to electric current builds over time. Because heating is directly proportional to the duration of current flow and proportional to the square of the current amplitude (until burning and other tissue changes occur), a person who is unable to let go of a conductor for  seconds receives about  times as much tissue heating as a person who recoils from the voltage source in one third of a second. To make injury still more severe, a tight grasp on a conductor decreases contact resistance, which leads to an increase in current flow. Thus, heat­related injury to deep tissues is often more than a hundred times worse when there is a history of the patient’s being unable to let go of the conductor.
Current flow through the trunk and legs may cause brief, but strong, opisthotonic (arching) posturing and leg movements. The person appears to be thrust from the voltage source due to these muscle contractions and may sustain mechanical trauma in addition to electrical injury. If a person does manage to hold on to a high­voltage source, severe tissue damage occurs.
CLINICAL FEATURES OF ELECTRICAL INJURY
Electric current can induce immediate cardiac dysrhythmias, respiratory arrest, and seizures. Current that traverses the chest vertically (hand to foot or head to toe) or horizontally (hand to hand) can produce arrhythmias and respiratory arrest.
CARDIAC INJURY
Arrythmias are the most common cardiac manifestation of electrical injury. Fatalities due to asystole or ventricular fibrillation usually occur prior to
 arrival in the ED. Asymptomatic patients with normal ECGs on arrival to the hospital do not develop later dysrhythmias after low­
10­14 voltage (<1000 V) injuries. Myocardial injury can also occur from vascular damage (spasm, thrombosis, or dissection), resulting in ischemia.

Conduction blocks can occur.
CNS AND SPINAL CORD INJURY

Neurologic impairment is common in electrical injuries, occurring in approximately 50% of patients with high­voltage injuries. Given the multisystem dysfunction present in many electrical injury patients, take care to perform and document a careful neurologic exam, if possible, before intubation and sedation.
Transient loss of consciousness is common after electrocution and may be followed by seizures. Victims may be confused and agitated or deeply comatose and require airway protection. Patients may also demonstrate focal neurologic deficits such as quadriplegia, hemiplegia, aphasia, or visual disturbances. Head and cervical spine CT should be performed to rule out traumatic etiologies for these deficits; MRI may be necessary for purely
 ,18 electrical damage. Electrical injury has been known to cause blindness due to occipital lobe injury as well as direct injury to the optic nerve.

Neurologic deficits may be transient, but survivors may have persistent difficulties with attention, working memory, and learning.

Spinal cord injury occurs in up to 8% of high­voltage electrical injuries. Mechanisms include compressive vertebral fractures, purely electrical
 23­25 damage, or vascular injury. Initial MRI findings may be normal in electrical trauma patients with permanent spinal cord injury, although newer

MRI imaging protocols may detect abnormalities missed on standard MRI.
27­29
Neurologic deterioration can occur days to months after the initial injury and generally has incomplete resolution. There is a motor predominance in the deficit in most cases. Delayed onset of spinal cord dysfunction may be due to progressive vascular injury (especially to the spinal artery branch supplying the anterior horn cells) or delayed cell membrane damage via the cumulative effect of free radicals (electroporation), leading to progressive
,30  demyelination. The clinical features may take the form of transverse myelitis, amyotrophic lateral sclerosis, or a Guillain­Barré–like illness.
PERIPHERAL NERVE INJURY
Nerve tissue has the lowest resistance in the body, encouraging electrical passage through these tissues and causing associated damage. Peripheral nerve injuries often involve the hands after the individual touches a power source. Paresthesias may be immediate and transient or delayed in onset,
,32 appearing up to  years after injury. Extensive peripheral nerve damage may occur with minimal thermal injury. Electrical contact with the palm
 produces median or ulnar neuropathy more often than radial nerve injury. Brachial plexus lesions have also been reported, as well as a case of
  trigeminal neuralgia. Persistent symptoms related to peripheral nerve damage can occur despite normal results on nerve conduction studies.
CUTANEOUS BURNS
Cutaneous burns are often seen at the electrical contact areas (often referred to as entry and exit wounds in the case of DC current or contact wounds in the case of AC current). Many seriously injured patients have burns on either the arm or skull, paired with burns on the feet. These burns are typically painless, gray to yellow, depressed areas. Most patients with burns from electrical injury need admission and care by a burn specialist. See
Chapter 217, “Thermal Burns,” for management of cutaneous burns.
ORTHOPEDIC INJURY
Fractures may be caused by tetanic muscle contractions or associated falls. While fractures are more likely to result from high­voltage injury, fractures of the wrist, forearm, humerus, femoral necks, shoulders, and scapulae have been reported from exposure to household voltages (120 to 220 V AC)
,36,37 without associated trauma. Posterior shoulder dislocations are commonly seen with electrical injury.
VASCULAR AND MUSCLE INJURY
Vascular and muscle injury occur most commonly in the setting of high­voltage injury, such as power line contact. Electric current passing along
 peripheral arteries may cause early spasm and persistent deficits in endothelial and smooth muscle function, as well as subsequent thrombosis, stenosis, or aneurysm formation. Because of concomitant vascular and muscular destruction, patients with high­voltage shocks are at significant risk for development of compartment syndrome, even if the contact (or arcing) lasted <1 second. Compartment syndrome has also been noted in patients with injuries from ≥120 V AC who sustain contact for longer than a few seconds. Patients typically exhibit ongoing
 muscle pain with movement.
Contact with >1000 V, prehospital cardiac arrest, crush injury, and full­thickness skin burns are associated with significant tissue damage requiring surgical intervention. Fasciotomy and amputation are frequent sequalae of high­voltage injuries, occurring in up to 29% and 41% of patients,
,40 respectively. High­voltage electrical injury is associated with rapid loss of body fluids into the areas of tissue damage, requiring aggressive resuscitation.
COAGULATION DISORDERS
Thermal injury or tissue necrosis from electric current can cause a variety of coagulation disorders. Low­grade disseminated intravascular coagulation may be a result of hypoxia, vascular stasis, rhabdomyolysis, and release of procoagulants from damaged tissue. Transient coagulopathies have also
 been reported with high­voltage injury, including acquired, transient factor X deficiency. Electrical injury may unmask underlying vascular injury and
 has been reported in association with ischemic stroke at low voltage.
BLAST INJURY
Electric arcs in the industrial environment or near a power line can produce a strong blast pressure, similar to those seen in other types of
 explosions. Cognitive complaints following blast injury may resemble those that result from moderate mechanical head trauma. Mechanisms of brain injury include mechanical trauma related to the blast, as well as arterial air emboli associated with blast­related alveolar disruption (see Chapter ,
“Bomb, Blast, and Crush Injuries”).
INHALATION INJURY
Chemical toxins such as ozone can be produced by coronas and arcs. Acute effects of ozone exposure include mucous membrane irritation, temporarily reduced pulmonary function, and pulmonary hemorrhage and edema. Fires and explosions associated with electrical incidents may lead to inhalation of carbon monoxide and other toxic substances.
OCULAR INJURY
Electrical shock can cause a wide range of ocular trauma, most commonly to the cornea (epithelial erosion/defect, keratitis, scarring), as well as uveitis,
,44,45 retinal detachment, macular edema, optic nerve damage, and intraocular bleeding and thrombosis. Providers should have a low threshold for full ophthalmologic evaluation for any electric shock patient with an ocular complaint to document related injury. Cataract formation has been
 described weeks to years after electrical injury to head, neck, or upper chest. Cataracts have also occurred after electric arc or flash burns.
AUDITORY INJURY
The auditory system may be damaged by current or by hemorrhage in the tympanic membrane, middle ear, cochlea, cochlear duct, and vestibular apparatus. Delayed complications include mastoiditis, sinus thrombosis, meningitis, and brain abscess. Hearing loss may be immediate or develop later as a result of complications. Hearing should be briefly checked in the ED, with follow­up formal testing arranged for any patient who appears to have a deficit.
GI INJURY

Pain due to bowel perforation and intra­abdominal hemorrhage may be attributed to more obvious coexisting injuries. There are reports in the literature of lethal intra­abdominal injuries from electric current that were found only at autopsy. Ileus may develop in association with spinal cord injury.
SCENE AND PREHOSPITAL CARE
Table 219­3 outlines prehospital care of the patient with electrical injury.
TABLE 219­3
Scene and Prehospital Care
Stay at least  m (32 ft) from downed power lines, jumping power lines, and support structures.
Turn off the source of electricity prior to rescue, if possible.
If electrical source cannot be quickly turned off, take precautions to prevent electrical injury to the rescuer.
Wear gloves and shoes rated for the power line voltage.
Initiate rescue breathing and resuscitation efforts while injured person is still on pole, if no contact with source of electricity is ensured.
Maintain spinal immobilization of injured person, if possible.
RESCUER SAFETY
The recommendations in Table 219­3 should be followed strictly to protect rescuers while managing the patient. Reapplication of voltage to downed lines sometimes occurs as circuit breakers automatically reset, which makes the lines jump many feet with great force. Be aware that support structures such as cables may be electrically alive.
Victims still in contact with a source of voltage may transmit an electric current to would­be rescuers. With voltages above about 600 V, dry wood and other materials may conduct significant amounts of electric current and therefore cannot be used to remove the person from a voltage source. A rescuer standing on the ground touching any part of a vehicle that is in contact with a power line is likely to be killed or seriously injured.
Electric shock is not prevented in this situation by the rescuer wearing rubber gloves and boots, unless these are designed for the voltage present and have been recently tested for insulation integrity.
SCENE RESUSCITATION AND STABILIZATION
Low­voltage AC can produce ventricular fibrillation by direct stimulation of the heart, or ventricular fibrillation can occur after several minutes of respiratory arrest resulting from paralysis of respiratory muscles (Table 219­2). High­voltage AC and DC are more likely to produce transient ventricular asystole. The asystole sometimes reverts spontaneously to normal sinus rhythm with pulses, but prolonged apnea may continue.
Apnea with pulses sometimes occurs in linemen working above the ground near high­voltage lines. Supporting respirations above ground may be all that is needed to stabilize the patient’s condition. Vigorous resuscitation efforts should be initiated in patients with cardiac arrest from electric
 shock, because there may be insignificant tissue damage despite the potentially lethal dysrhythmia.
Maintain spinal immobilization during resuscitation to the extent possible, because spinal fractures can be caused by tetanic muscle contractions, falls, and other secondary trauma.
ED DIAGNOSIS AND TREATMENT
Provide the usual evaluation (airway, breathing, circulation) and resuscitation for major trauma victims. Maintain spinal immobilization during resuscitation until adequate imaging and examination can be done.
Cardiac arrhythmias can be treated according to standard protocols (see Chapter , “Defibrillation and Electrical Cardioversion,” and Chapter ,
,11
“Cardiac Resuscitation”). Maintain cardiac monitoring for patients with high­voltage injuries as well as all symptomatic patients. Cardiac complications are more common in patients with high­voltage injuries and in those with loss of consciousness and include ventricular and atrial
48­50 dysrhythmias, bradydysrhythmias, and QT­interval prolongation. Admission for cardiac monitoring is not needed for asymptomatic patients with normal ECG on presentation after a low­voltage electrical injury, because the risk of developing a subsequent malignant
,15,51 rhythm requiring intervention is very low.
Assess for tissue damage and identify associated complications. A careful vascular and neurologic examination of involved extremities is important.
Normal findings on initial assessment do not exclude serious injury or the possibility of delayed spinal cord injury following high­voltage contact.
Focus next on systematic assessment and treatment, especially for injuries specific to or common in electrical injury, as outlined in Table 219­4. Laboratory and radiographic evaluation of high­voltage injuries should follow standard trauma guidelines (see chapters in Section , “Trauma,” and
Section , “Orthopedics”).
TABLE 219­4
Assessment and Treatment of Complications Associated With Electrical Injuries
Organ or System Assessment/Treatment/Comments
Circulatory Start with Parkland fluid resuscitation formula.∗
Renal Initiate fluid resuscitation.
Myoglobinuria Initiate fluid resuscitation.†
Central and peripheral nervous Order head CT if mental status is abnormal; assess for spinal cord and peripheral nerve injury.
Skin Assess and treat cutaneous burns.∗
Musculoskeletal Perform careful assessment of spine, pelvis, long bones, and joints.
Assess for compartment syndrome and need for fasciotomy.
Vascular Spasm may occur leading to delayed thrombosis, aneurysm formation, or muscle damage.
Coagulation Treat coagulation disorders by eliminating the precipitating factor through early surgical debridement.
‡
If bleeding is present, replace coagulation factors.
Lungs Assess for inhalation injury, carbon monoxide, or alveolar injury from blast.
Eyes Document complete eye examination.
Delayed cataracts may develop.
Ears Assess for blast injury.
Document hearing.
Middle and inner ear disorders may occur.
GI Intra­abdominal injury may occur from current or blast.
Lips and oral cavity Watch for delayed bleeding.
∗
Refer to Chapter 217, “Thermal Burns.”
†Refer to Chapter , “Rhabdomyolysis.”
‡
Refer to Chapter 254, “Trauma in Adults.”
In the case of low­voltage injuries, laboratory testing and imaging are usually not required unless the patient is symptomatic or has abnormal physical examination findings. Symptoms such as chest pain, palpations, loss of consciousness, altered mental status, confusion, weakness, dyspnea, abdominal pain, weakness, burn with subcutaneous damage, vascular compromise, or abnormal results on ECG require further testing.
FLUID RESUSCITATION
Fluid resuscitation guided by the Parkland formula (4 mL/kg multiplied by the percentage of body surface area burned, administered over  hours) is only a rough starting point in fluid management. Extensive deep tissue damage resulting from high­voltage injury may be present even when the cutaneous burn seems limited. Therefore, fluid requirements are often greater than predicted by external injuries using the Parkland formula.
MYOGLOBINURIA
Patients with suggestive symptoms or high­voltage injury should be monitored for the onset of compartment syndrome, rhabdomyolysis, and renal failure. If myoglobinuria is suspected, institute aggressive IV fluid resuscitation to maintain a urinary output of between  and  mL/kg/h, with attention to correction and prevention of electrolyte abnormalities. Maintain a high urine output until the serum creatine kinase level is less than five times normal or urine myoglobin measurements return to normal.
Prognostic factors associated with the need for a fasciotomy within  hours of injury are (1) myoglobinuria, (2) burns over 20% of total body surface
 area, or (3) a full­thickness burn over 12% body surface area. Presence of any one of these three factors is predictive of development of the need for fasciotomy. The International Society for Burn Injuries 2018 guidelines recommend that patients with myoglobinuria should be transferred to a burn
 center with expertise in escharotomy and fasciotomy.
DISPOSITION AND FOLLOW­UP
LOW­VOLTAGE INJURIES <600 V
Although there is no universally accepted protocol for management and disposition of patients with low­voltage injuries, in general, asymptomatic patients who sustain an electric shock of ≤240 V AC can be discharged home if they have a normal ECG on presentation and normal
,11 ,11 examination findings. Patients who feel unwell or have any new ECG abnormality should be monitored and reassessed.
HIGH­VOLTAGE INJURIES ≥600 V
All patients having contact with ≥600 V AC should be admitted for observation, even if there is no apparent injury. Routine cardiac monitoring is not required unless the patient is symptomatic or the initial ECG findings are abnormal. Low­voltage injury patients with symptoms beyond superficial skin injury or abnormal lab or ECG results may have systemic injury and require admission as well. Patients with extensive
 cutaneous burns should be transferred to a specialized burn center after initial trauma stabilization. This is especially true in children. The
International Society for Burn Injuries 2018 guidelines recommend that patients sustaining electric shock >1000 V AC should be transferred to a burn
 center for evaluation and management.
SPECIAL POPULATIONS
PREGNANT WOMEN
In addition to the measures recommended earlier, in pregnant patients beyond  to  weeks of gestation, fetal heart rate and uterine activity should
,53­ be monitored for at least  hours because of the possibility of mechanical trauma related to the electric shock and electrical discharge to the fetus.

CHILDREN
Children are more likely to sustain household current electrical injury than high­voltage injury. Overall outcome appears to be better, including a lower incidence of amputation and fasciotomy than in adults, although skin grafts may be required (25% in one 10­year study of pediatric burn center
 referrals).
Oral and Lip Burns
Serious oral injury can occur in a child who places the end of a power cord in the mouth. The electric field and current flow created between the two wires near the end of the cord can produce high temperatures and significant tissue damage. Most injuries are unilateral, involving the lateral
,56,57 commissure, tongue, and/or alveolar ridge (Figure 219­1). Systemic complications of oral burns are uncommon. Vascular injury to the labial artery is not immediately apparent because of vascular spasm, thrombosis, and overlying eschar. Severe bleeding from the labial artery
 occurs in up to 10% of cases when the eschar separates, usually after  days. If the parents are reliable, can monitor the child, and can be shown how to control bleeding, outpatient management may be considered. Parents should be educated that bleeding may occur up to  weeks after injury. Prior to discharge, however, specialty consultation should be obtained and follow­up secured, because of the risk of deforming scar formation during the healing process, in which new cells tend to migrate medially, reducing the span of mouth opening. Splinting and other measures are often needed to prevent the development of this deformity and dysfunction. Home care includes saline or hydrogen peroxide rinses and gentle swabbing to debride necrotic tissue and promote formation of healthy granulation tissue. Topical application of petrolatum­based antibiotics may have a soothing effect.
FIGURE 219­1. Oral burn in a child from power cord. A 2­year­old boy sustained a third­degree burn to the commissure of the mouth after biting down on an electrical cord. This photograph was taken  days after initial treatment. [Reproduced with permission from Shah BR, Lucchesi M: Atlas of Pediatric Emergency
Medicine. © 2006 by McGraw­Hill, Inc., New York.]
Hand Wounds

Hand wounds are common electrical injuries in children. Children who sustain hand wounds from electrical outlet injuries with no other injury and no evidence of cardiac or neurologic involvement can be discharged after local wound care is provided and careful follow­up is ensured.
LIGHTNING INJURIES
EPIDEMIOLOGY

Lightning causes approximately 500 injuries each year in the United States, with  to  deaths per year in the past decade. Lightning fatalities
 constitute fewer than 3% of weather­related deaths, which are more commonly due to extreme heat or cold. Lightning fatalities are most common in
 fishermen, but also occur in other outdoor recreational activities such as golf and camping. Lightning injury reporting is inexact and biased toward the more severe and fatal events. Approximately 70% to 90% of persons struck by lightning survive, but as many as three quarters of these survivors
,64 have permanent sequelae.

Lightning most often occurs during thunderstorms. However, approximately 10% of lightning occurs without rain and when the sky is blue. In addition, lightning can occur during dust storms, sandstorms, tornados, hurricanes, snowstorms, and nuclear explosions, and in the clouds over volcanic eruptions. Lightning injuries can also occur while riding in airplanes. Lightning injury associated with indoor telephone use during lightning
  storms has been reported. A study in Australia identified up to  such injuries yearly without any reported fatalities.
Even though lightning is electrical energy, lightning injuries differ substantially from high­voltage electrical injuries seen in association with human­
,67,68 generated sources. There are differences in injury patterns, injury severity, and emergency treatment (Table 219­5).
TABLE 219­5
Comparison of Lightning and Electrical Injuries
Factor Lightning High­Voltage AC Low­Voltage AC
Current duration  µs to  ms Generally brief (1–2 s), but may be .3 s or many minutes prolonged
Typical voltage  million to  billion V, 3000 to 200,000 A 600–200,000 V, <1000 A <600 V, usually <20–30 A and current range
Current Unidirectional (DC) Alternating (AC) Alternating (AC) characteristics
Current pathway Skin flashover; deeper pathways can result in Horizontal (hand to hand), vertical Horizontal (hand to hand), vertical burns (hand to foot) (hand to foot)
Tissue damage Superficial and minor if no deep tissue pathway Deep tissue destruction Sometimes deep tissue destruction
Initial rhythm in Asystole Asystole more than ventricular Ventricular fibrillation cardiac arrest fibrillation
Renal Myoglobinuria is uncommon, and renal failure is Myoglobinuria and renal failure are Myoglobinuria and renal failure occur involvement rare. relatively common. occasionally.
Fasciotomy and Rarely necessary Relatively common Sometimes necessary amputation
Blunt injury Caused by explosive shock wave that can throw Caused by falls, being thrown from Caused by tetanic contraction, falls, the person and cause eardrum rupture current source, tetanic contractions being thrown from current source
Immediate cause Prolonged apnea, blunt injury, deep tissue Prolonged apnea, ventricular Ventricular fibrillation, prolonged of death burns fibrillation, blunt injury, deep tissue apnea, blunt injury burns
Abbreviations:AC = alternating current; DC = direct current.
PATHOPHYSIOLOGY
Lightning often travels over the surface of the body in a phenomenon called flashover and is therefore less likely to cause internal cardiac injury or muscle necrosis than is human­generated electrical energy. Wet skin may actually decrease the risk of internal injury, helping the current travel along the outside of the body. Flashover explains how victims may survive a lightning strike with little or no injury. Lightning causes internal injury through blunt mechanical force, current flow through the body, and other mechanisms. The large current flow in lightning creates a pulsed magnetic field that
 can induce current flow in a nearby person. This current can produce destructive effects.
Lightning emits brief but intense thermal radiation that produces rapid heating and expansion of the surrounding air. Tympanic membrane perforation and internal organ contusion may occur. Vaporization of sweat from the skin can occur with tearing of clothing, giving the appearance of
 an assault. Lightning may inflict thermal injury as moisture on the victim’s skin is transformed into steam, as electric current flows through deeper tissues, and through resistance heating of metal objects on the body or in clothing pockets. Lightning may melt metallic objects on the victim. Lightning can be conducted along metal fences, bleachers, plumbing pipes, and other structures. Intense photic stimulation may damage the retina or produce cataracts.
STUNNING (KERAUNOPARALYSIS)
Neurologic and muscular “stunning,” referred to as keraunoparalysis, can follow lightning strike and may initially produce a variety of neurologic signs
 and symptoms. Keraunoparalysis is associated with successful resuscitation after cardiorespiratory arrest. In cases of keraunoparalysis that resolve within an hour, there can be lower limb weakness that is greater than upper limb weakness. Other extremity­related signs and symptoms include sensory abnormalities, pallor, coolness, and diminished and absent pulses. Excessive autonomic nervous system stimulation may be responsible for
 these transient symptoms. In some cases, keraunoparalysis persists for a longer time. In such cases, there is typically amnesia and “neurotic” behavior that slowly clears over a week. More persistent and sometimes permanent sequelae can include muscular weakness and pain, photophobia,
 and disturbances of neurologic control.
TYPES OF LIGHTNING STRIKES
Lightning strikes in a number of different ways, some of which injure multiple victims. A direct strike occurs when the victim is struck directly by the lightning discharge. A side flash occurs when a nearby object is struck and current then traverses through the air to strike the victim. A side flash may injure multiple victims at once, as when a group huddles close to a structure that is struck. A contact strike occurs when lightning strikes an object the victim is holding and current is transferred from the object through the person to the ground. Lightning injury from indoor telephone use during a lightning storm is an example of contact strike. A ground current occurs when lightning hits the ground and current is transferred through the ground to nearby victims. The amount of electrical voltage and current decreases as the distance between the victim and strike point increases. This ground current can create a stride potential or step voltage between the victim’s separated feet. The foot closer to the strike point will experience a higher electrical potential than the foot farther away. Therefore, electrical current can enter one foot, travel up that leg, through the torso, and down the other leg and exit the other foot. This can result in isolated neurovascular injury to the legs. Recently, a fifth mechanism, in which a weak upward streamer
 does not become connected to the completed lightning channel, was implicated in a fatal lightning injury.
Immediate cardiac arrest from lightning strike results from depolarization of the myocardium and sustained asystole. Immediate respiratory arrest after lightning strike may be a result of depolarization and paralysis of the medullary respiratory center. Both cardiac and respiratory arrest may be present without evidence of external injury. Although cardiac automaticity may spontaneously return, concomitant respiratory arrest may persist and lead to a secondary hypoxic cardiac arrest.
CARE AT THE SCENE

Lightning can produce multiple victims because of multiple lightning strikes, stride potentials, and side flashes. In contrast to patients with cardiac arrest caused by mechanical trauma, persons with lightning injury who appear to be dead (in respiratory arrest, with or without cardiac arrest) should be treated first. Such victims may have little physical damage, and they have a reasonable chance of successful resuscitation. Use of automated external defibrillators and other defibrillators along with CPR can be lifesaving. Prolonged CPR is sometimes successful.
During a storm, power lines may fall to the ground as a result of high winds, lightning­related damage to power lines and their support structures, and vehicular damage to power line support structures. Therefore, a person thought to have been hit by lightning may actually have been shocked by the stride potential related to a nearby power line lying on the ground. Physical findings suggestive of lightning injury may be subtle or nonexistent.
Therefore, information about the scene of the accident may be just as informative as examination of the patient.
ED DIAGNOSIS AND TREATMENT
The usual advanced cardiac and trauma treatment principles apply, including assessment and stabilization of the airway, breathing, and circulation. Lightning victims in cardiac arrest have a better prognosis than those in cardiac arrest from coronary
 artery disease, so aggressive resuscitative efforts are indicated. Hypotension is not an expected finding following lightning injury and
 warrants an investigation for hemorrhagic blood loss. Perform a careful secondary examination to detect occult injuries. Cutaneous burns may help identify the current path and suggest potential organ injury. Initial ancillary studies include CBC, serum electrolyte levels, creatinine level, BUN level, glucose level, creatine kinase level, urinalysis, and ECG. Imaging studies (plain radiography, US, or CT) should be performed as dictated by suspected
 injuries. Other ancillary studies may be indicated depending on clinical circumstances.
CARDIAC EFFECTS
In the victim with spontaneous circulation, hypertension and tachycardia are common findings, presumably because of sympathetic nervous system activation. Specific treatment is usually not necessary, because blood pressure and pulse rate will spontaneously decrease. Cardiac effects reported after lightning injury include global depression of myocardial contractility, coronary artery spasm, pericardial effusion, and atrial and ventricular arrhythmias. The ECG may show acute injury with ST­segment elevation and QT­interval prolongation. T­wave inversions may be seen, especially in the presence of neurologic injury. Myocardial infarction after lightning injury is unusual. CPR, automated external defibrillators, and other resuscitative
  measures should be used promptly. Prolonged resuscitative efforts are sometimes successful. Therapeutic hypothermia can be considered as well.
NEUROLOGIC INJURY
Many lightning­strike victims are rendered unconscious or have temporary lower extremity paralysis. Seizures may result from the passage of electric current through the brain or may be the result of mechanical brain injury or hypoxia. The most lethal neurologic injuries involve heat­induced coagulation of the cerebral cortex, development of epidural or subdural hematoma, and intracranial hemorrhage.
Autonomic dysfunction caused by lightning may produce pupillary dilation or anisocoria not related to brain injury, and these signs have no prognostic significance in comatose lightning­strike victims. Most neurologic injury related to lightning strike can be classified as immediate and transient or delayed and permanent, although some effects may be immediate and permanent. Transient effects that typically resolve in  hours include loss of consciousness, confusion, amnesia, and extremity paralysis. Delayed and often progressive disorders include seizures, muscular atrophy and amyotrophic lateral sclerosis, parkinsonian syndromes, progressive cerebellar ataxia, myelopathy with paraplegia or
 quadriplegia, and chronic pain syndromes. Lightning can cause intracranial injury directly when passing through the head, as well as by secondary trauma. Therefore, CT scan is indicated in cases of coma, altered mental status, or persistent headache or confusion.
VASCULAR EFFECTS
Vasomotor spasm in an extremity is sometimes seen as a local response to lightning exposure. Possible mechanisms include sympathetic nervous stimulation, local arterial spasm, and ischemia of peripheral nerves. Skin color changes, from white to blue to red, may occur in extremities after lightning strike. Such changes are presumably from cycles of vasoconstriction and vasodilatation, with pallor and cyanosis followed by hyperemia.
Severe vasoconstriction is thought to be responsible for loss of pulses, mottling of skin, coolness of extremities, loss of sensation, and paralysis due to ischemia of peripheral nerves. As vasoconstriction resolves spontaneously, these signs and symptoms often resolve. Because skeletal muscle injury is rare in lightning strike, compartment syndromes are less likely. If doubt exists, the presence of compartment syndrome and the need for fasciotomy may be confirmed by measurement of intracompartmental pressures and close clinical monitoring.
OCULAR INJURY

Ophthalmic injuries are common in lightning­strike victims, and lightning­induced cataracts are the most frequently observed ocular sequela.
Cataracts caused by lightning are usually bilateral. Cataract formation without evidence of current flow through the head or eyes, such as after brief exposure to an electric arc, has been described. Perhaps this is a result of damage of the lens by radiant energy. Cataracts may form weeks to years after the lightning injury. Lightning can affect any part of the eye, producing hyphema, vitreous hemorrhage, corneal abrasion, uveitis, retinal detachment or hemorrhage, macular holes, and optic nerve damage. A patient with discomfort or visual changes deserves a careful examination with follow­up.
AUDITORY INJURY
Blast effect producing tympanic membrane rupture is relatively common. Victims sustaining lightning strike via a conventional corded telephone are at
 higher risk for otologic injury, including persistent tinnitus, sensorineural deafness, ataxia, vertigo, and nystagmus. In patients who are sleeping with an ear or eye on the ground near a lightning strike, temporary deafness or blindness can result.
MUSCULOSKELETAL INJURY
A variety of skeletal fractures can be seen from the blunt force injury associated with lightning strike. Intense myotonic contractions can produce shoulder dislocations. Rhabdomyolysis after lightning strike is unusual. Spinal fractures can be caused by tetanic muscle contractions, as well as by falls and other secondary trauma. Therefore, spinal immobilization should be maintained during resuscitation, to the extent possible under the circumstances, until spinal stability can be assessed. Because spinal fractures often occur at multiple levels in the same patient, the entire vertebral column should be imaged when a fracture is found at one level.
CUTANEOUS INJURY
There are six main dermatologic manifestations of lightning injury. Lichtenberg figures are considered pathognomonic for lightning strike and consist of a red superficial feathering or ferning pattern (Figure 219­2). These figures are the result of electron showering over the skin and are not true thermal burns; they disappear within  hours. Flash burns are similar to those found in arc welders, appearing as mild erythema, and may involve the cornea. Punctate burns (Figure 219­3) look similar to cigarette burns in that they are usually <1 cm and are full­thickness burns. Contact burns occur when metal close to the skin is heated from the lightning current. Superficial erythema and blistering burns have been described. Linear burns, <5 cm wide, occur in areas of skinfolds such as the axilla or groin. Contact wounds characteristic of electrical injury from human­produced sources are not commonly seen in lightning injuries. Cutaneous wounds are treated with customary wound or burn care, including tetanus prophylaxis, irrigation, debridement, and dressing.
FIGURE 219­2. Lichtenberg figures with red lacy ferning pattern seen on the upper chest. [Reproduced with permission from Knoop KJ, Stack LB, Storrow AB: The
Atlas of Emergency Medicine, 2nd ed. © 2002 by McGraw­Hill, Inc., New York.]
FIGURE 219­3. Punctate lightning burns. [Reproduced with permission from Knoop KJ, Stack LB, Storrow AB: The Atlas of Emergency Medicine, 2nd ed. © 2002 by
McGraw­Hill, Inc., New York.]
DISPOSITION AND FOLLOW­UP
Patients should be carefully assessed for injuries. ECG and other monitoring are indicated as for any electric shock. Admission should be considered for most patients with persistent muscle pain, as well as those with persistent neurologic, cardiac rhythm, or vascular abnormalities. Follow­up is recommended to assess delayed effects of lightning, even for patients with no apparent injury.
SPECIAL POPULATIONS
In some cases, fetal injury and death have been noted to follow lightning strike with little or no maternal injury. One review reported that among 
 pregnant women who survived being struck by lightning, there were five cases of fetal death in utero, abortion, stillbirth, or neonatal death. Abruptio placentae has also been reported. Monitoring of maternal uterine activity and fetal heart rate is recommended for at least  hours after a lightning strike to a pregnant woman. Such monitoring will alert the physician to the development of abruptio placentae, which can occur following any physical trauma.
INJURY DUE TO ELECTRONIC CONTROL DEVICES
PATHOPHYSIOLOGY
Electronic control devices (ECDs, also known as conductive energy devices or CEDs), such as the cattle prod, stun gun, and the Taser®, can lead to injuries. Approximately 11% of “legal intervention injuries” (i.e., injuries sustained while being taking into custody) are related to ECDs. The vast
 majority of ECD­injured patients are treated and released, but 6% are hospitalized. TASER International, Inc. (Scottsdale, AZ) produces a series of devices that deliver high­voltage, low­amperage electrical pulses, typically at  to  cycles per second (subtetanic rate). The pulses are designed to
79­82 induce involuntary muscle contraction, neuromuscular incapacitation, and/or pain. The likelihood of electrical injury is minimal ; however, reports
,84 have been published that attribute or associate cardiac arrest with these devices. In addition, falls or other forceful movements resulting from
 electric current can lead to injury, as can use in flammable and other hazardous environments. Some devices shoot wires with fishhook­like barbs on the ends that penetrate and hook into the skin; penetrating injuries can result from this mechanism. (See Video: Fishhook and Taser Removal.)
Video 219­1. Fishhook and Taser Removal.
Used with permission from Moira Davenport, Richard Walz, and Cory Heidelberger, Department of Emergency Medicine, Allegheny General Hospital.
Play Video
CLINICAL FEATURES
Most ECD injuries are limited to superficial punctures and minor lacerations and cutaneous burns. Reported significant injuries have included skull
 ,88     penetration, eye perforation, retinal detachment, testicular torsion, miscarriage, and pneumothorax, as well as blunt trauma from falls and burns. Burns may occur when ECDs are used in flammable environments or when they are used to incapacitate someone on a hot surface.
Clinical evaluation should address the agitation underlying the use of the ECD. Patients may be agitated due to stimulant intoxication or other causes of medical delirium (including alcohol withdrawal or thyroid storm) and should be fully evaluated for both the underlying cause and the metabolic
 consequences of delirium, including hyperthermia, electrolyte abnormalities, rhabdomyolysis, and acidosis.
TREATMENT AND DISPOSITION

A series of human studies (and some in healthy volunteers ) have suggested that ECDs do not cause or worsen hyperthermia, hyperkalemia, hypoxia,
94­97 acidosis, and a variety of other problems often seen with in­custody deaths. However, many underlying medical or mental health conditions may be at play in the patient who has required ECD discharge for restraint. Deaths reported after ECD use are typically in subjects with preexisting cardiac
 disease, history of agitation and long struggles with police, or acute substance use. Determine why the ECD was used, obtain a past medical and mental health history, and obtain a good description of the patient’s behavior before and after the incident. Careful evaluation and monitoring are needed in the patient with abnormal vital signs or who is ill­appearing, had prolonged struggle, may have mental health issues, or appears to be in agitated delirium. Assess for musculoskeletal injury. Because incidents involving the Taser or ECDs are likely to involve higher levels of overall scrutiny by police or legal officials, it seems most reasonable to be conservative in ED evaluation for symptoms other than burning at the skin site, and to obtain
ECG, CBC, electrolytes, metabolic panel, total creatine phosphokinase, and other studies (perhaps toxicology) as suggested by the history or physical examination.
There are no reported guidelines or evidence­based studies relative to ED care. Patients who remain asymptomatic (i.e., have no symptoms other than burning at the skin site), have calmed down by the time of original assessment, have no history of loss of consciousness or significant cardiac disease or other comorbidities, have no signs of mental health issues, and appear well can usually be discharged. Patients who were severely agitated can be discharged if they have calmed down, maintained stable vital signs for  hours, have a normal physical and mental status exam, and have a normal 12­lead ECG and normal electrolytes and creatine phosphokinase. Those with abnormal vital signs, labs, or ECG, or with history of loss of consciousness or significant underlying cardiac disease, should be admitted for further observation.


