## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 119: Fever and Serious Bacterial Illness in Infants and Children
David M. Rodriguez; Jo­Ann O. Nesiama; Vincent J. Wang
INTRODUCTION AND EPIDEMIOLOGY
Content Update September 2024: Hospital for Sick Children Algorithm (University of Toronto, Toronto, Ontario, Canada) to Discriminate
Bacteremia from Contaminants in a positive blood culture
The algorithm exhibited 100% sensitivity and 11% specificity to detect children with bacteremia. See discussion at the very end of this chapter.
Content Update April 2024: Phoenix Sepsis Score
The Phoenix Sepsis Score, updated by the Society of Critical Care Medicine Pediatric Sepsis Definition Task Force in January 2024, is discussed at the end of this chapter.
Fever is the most common chief complaint of children presenting to the ED, accounting for approximately 30% of pediatric outpatient visits. It is critical to differentiate mildly ill from seriously ill children with fever, especially in the neonate and infant. This challenge is compounded by the nonspecific symptoms and lack of a focus of infection in most children with fever. Many factors influence evaluation and management, including clinical assessment, physical examination findings, patient age, immunization status, and height of the fever.
This chapter focuses on the management of a neonate, infant, or child with acute fever at risk for serious bacterial illness, because morbidity and mortality are high if serious bacterial illness is missed or not properly treated. Neonates, defined as infants <1 month old, are at highest risk. Infants between  and  months of age are also at risk due to relative immunosuppression. The significance of age groups is discussed in the subsequent sections.
FEVER
Any elevation in temperature above normal is commonly considered a fever. A cutoff temperature formally defining fever is not universally accepted. In infants, the threshold for relative concern has traditionally been 38°C (100.4°F). In the neonate or infant <2 to  months of age, temperature
<36°C (96.8°F) is equally concerning. Historically, occult bacteremia criteria used 39°C (102.2°F) in those  to  months in age, and a temperature
>41°C (105.8°F) was considered to confer increased risk for serious bacterial infection.
In children >36 months old, sources of serious bacterial infection can be reliably ascertained by specific signs or symptoms. In infants and younger children, or children with developmental delay, who have limited ability to demonstrate specific signs and symptoms, the cause of fever may be difficult to determine, and more testing is often necessary.
Axillary temperatures are .6°C (1°F) lower than oral temperatures, which are .6°C (1°F) lower than rectal temperatures. Temperatures taken with
,2 infrared thermometers are of variable reliability and reproducibility.
Fever is treated with acetaminophen or ibuprofen. The dosage of acetaminophen is  milligrams/kg/dose PO or PR (maximum daily dose,  milligrams/kg) every  to  hours, up to five times per day. Acetaminophen may also be given IV with dosages, intervals, and maximum daily dose differing by age. The dosage of ibuprofen is  milligrams/kg/dose (maximum daily dose,  milligrams/kg) every  to  hours. Ibuprofen can be given to children older than  months of age.

Chapter 119: Fever and Serious Bacterial Illness in Infants and Children, David M. Rodriguez; Jo­Ann O. Nesiama; Vincent J. Wang 
SERIOUS BACTERIAL ILLNESS
. Terms of Use * Privacy Policy * Notice * Accessibility
Infants ≤3 months of age, and especially neonates, are relatively immunodeficient. Neonates and young infants demonstrate decreased opsonin
 activity, decreased macrophage and neutrophil function, and bone marrow insufficiency. Infants and children demonstrate a poor immunoglobulin G antibody response to encapsulated bacteria until  months of age. Immune development is a continuum and improves as the child matures.
Therefore, the age of the patient and the virulence of the bacteria are considerations for the evaluation of fever in children and the identification of serious bacterial illness. The most common manifestations of serious bacterial illness in children include urinary tract infection (UTI), bacteremia and sepsis, pneumonia, and meningitis. Of note, the following discussion applies primarily to developed countries.
Urinary Tract Infection
Overall, the most common serious bacterial illness is UTI with or without pyelonephritis. The incidence among young children <24 months of age presenting to EDs with fever and no obvious source of infection is between 3% and 8%. In the first  months of life, the incidence of UTI is even higher; in a recent study, UTI was found in 11% of infants who presented to the ED with fever and .6% among those with a history of parent­reported fever,
 but no fever on arrival to the ED. Because UTIs may not produce symptoms other than fever, routinely obtain a urinalysis and culture in the evaluation of the febrile neonate or infant without other source. Additional details regarding the epidemiology, risk factors, testing, and treatment of UTI can be found in Chapter 135, “Urinary Tract Infection in Infants and Children.”
One study reported that 13% of infants (15 of 117 infants) <3 months of age with a febrile UTI admitted to the hospital had a sterile pleocytosis of the
 cerebrospinal fluid thought to be due to systemic release of inflammatory mediators or low bacterial virulence in the subarachnoid space. A report by
 the Pediatric Emergency Medicine Research Collaborative Committee in 2011 showed similar findings. However, another study did not replicate these
 findings. Less than 1% of febrile infants with UTI will have bacterial meningitis, but concomitant infection of the urine and cerebrospinal fluid has
 been reported.
Bacteremia and Sepsis
Most studies of febrile infants ≤3 months old cite a bacteremia/sepsis incidence of 1% to 3%. ,9 The most common causes of bacteremia in this age group are Escherichia coli, group B Streptococcus, and Listeria monocytogenes. Ill­appearing neonates or those identified as high risk because of
 laboratory testing have an incidence of serious bacterial illness of 13% to 21%. Overall, however, viral infections are the most frequent cause of fever
10­12 in infants. Many studies have shown that infants with viral illnesses are less likely to have serious bacterial infections.
Most studies of bacteremia/sepsis also cite an incidence of 2% to 3% in febrile infants  to  months of age. Prior to the widespread use of heptavalent pneumococcal conjugate vaccine in 2000, a temperature of ≥39°C (102.2°F), WBC >15,000/mm  , and absolute neutrophil count >10,000/mm  were
 independent predictors of occult bacteremia in febrile infants and children between  and  months old. The presence of any of these factors
 increased the incidence of bacteremia to 8% to 17%.
Administration of the Haemophilus influenzae type b vaccine and the pneumococcal conjugate vaccines (currently in use in the United States is the 13­
14­17 valent pneumococcal conjugate vaccine) has decreased the occult bacteremia rate of febrile children  to  months of age to .5% to .7%. The incidence of serious bacterial illness in children  to  months old who were incompletely or not immunized decreased because the widespread use of
 the vaccines resulted in herd immunity. In 2009, a decavalent pneumococcal conjugate vaccine was released in Europe, and in 2010, the 13­valent pneumococcal conjugate vaccine was introduced in the United States. Both of these are expected to further decrease the incidence of invasive pneumococcal disease. The Centers for Disease Control and Prevention reports a 90% reduction in invasive infections from Streptococcus
 pneumoniae in children <5 years old when comparing 2016 with 1998 data in the United States. Given these declines and the fact that 80% of pneumococcal bacteremia resolves spontaneously, the traditional standards for routine evaluation of the febrile infant  to  months old have changed. Guidelines now recommend urine testing only (at the discretion of the treating provider); routine WBC count and chest radiography are not indicated, and the use of routine antibiotics is discouraged.
Pneumonia and Sinusitis
Pneumonia and sinusitis are common bacterial infections of childhood, frequently associated with or following upper respiratory tract symptoms (see
Chapter 123, “Nose and Sinus Disorders in Infants and Children”; Chapter 124, “Mouth and Throat Disorders in Infants and Children”; and Chapter 128,
“Pneumonia in Infants and Children”). Pneumonia occurs in all age groups, with the most common causative agents being the same as those for bacteremia or meningitis in each age group. The incidence of pneumococcal pneumonia in all ages has decreased since the introduction of the
19­21 pneumococcal conjugate vaccines. Sinusitis is uncommon in children <3 years of age because sinus formation is incomplete.
Plain chest radiographs remain the gold standard for diagnosis of pneumonia. In neonates and young infants, routine chest radiographs are not necessary unless the patient has specific physical examination findings suggestive of pneumonia, such as respiratory distress, rales, grunting,
,22,23 significant tachypnea, or hypoxemia. In older children with chronic medical problems, such as cystic fibrosis, congenital heart disease, chronic lung disease, or malignancy, consider pneumonia in the differential diagnosis of fever and upper respiratory tract symptoms, even if there are no signs
 of lower tract infection. In one study performed before the widespread use of the pneumococcal conjugate vaccine, a WBC count of ,000/mm was
 associated with occult pneumonia in 19% of patients without focal findings. Without predisposing conditions or abnormal test results, the decision to obtain a chest radiograph can otherwise be made clinically. Pneumonia in a febrile but otherwise asymptomatic child is unlikely.
Meningitis
In developed countries, most studies of febrile infants <3 months old cite a bacterial meningitis incidence of 1%. The most common organisms are the same as those for bacteremia/sepsis: E. coli, group B streptococci, and L. monocytogenes. For children >3 months old, the most common organisms are S. pneumoniae, Neisseria meningitidis, and Staphylococcus aureus. There is a lower incidence of S. pneumoniae meningitis since routine vaccinations with the conjugate pneumococcal vaccines, and near elimination of H flu type b meningitis since the introduction of that vaccine decades ago.
Outside of North America, the epidemiology of meningitis is more complex, depending on the region of the world in which the patient has been living or traveling. N. meningitidis and Mycobacterium tuberculosis are the more common causes. Although N. meningitidis rarely occurs in North America, incidence may be higher elsewhere, especially in the “meningitis belt” of sub­Saharan Africa. In patients with symptoms of meningitis and recent travel to Africa, meningococcal meningitis should be considered as a diagnosis. Treatment is similar to other causes of bacterial meningitis. Tuberculosis meningitis is discussed in Chapter 174, “Central Nervous System and Spinal Infections.”
The diagnosis of meningitis is made by cerebrospinal fluid analysis (see later section, “Procedures in Children: Lumbar Puncture”). It is often difficult to distinguish between viral and bacterial meningitis because there is a wide overlap in cerebrospinal fluid and peripheral blood findings. Because of the serious morbidity of missed meningitis, administer appropriate antibiotics in the ED and admit any ill­appearing patient or any patient <2 months old with any degree of cerebrospinal fluid pleocytosis.
Infants with aseptic meningitis generally should be hospitalized and ensured adequate long­term follow­up because they are at greater risk for dehydration and subsequent neurologic and learning disabilities. For older children with cerebrospinal fluid pleocytosis and likelihood of viral meningitis, if the child is to be discharged from the ED, it is wise to administer a long­acting parenteral antibiotic (ceftriaxone, 100 milligrams/kg IM or

IV) and ensure follow­up in  hours. Chapter 120, “Meningitis in Infants and Children,” describes the diagnosis and treatment of meningitis in infants and children in more detail.
GENERAL TREATMENT AND DISPOSITION PRINCIPLES FOR FEVER BASED ON AGE
The clinical challenge is to distinguish the cause of fever: a benign viral infection, serious bacterial illness, or a noninfectious illness. Most fevers are due to viral infections, but bacterial infections are not infrequent. The significance of fever depends on multiple factors. If the physical examination identifies the source of infection, evaluation, testing, and treatment are dictated by the presumptive diagnosis. If the physical examination does not identify a source of infection causing fever, decision making is based first on age and then by height of fever. There are no absolute rules in the evaluation and management of fever, but the guidelines in Table 119­1 are suggested for the management of neonates, infants, and children who are well appearing, have had all relevant immunizations, and have no obvious cause for the fever. Again, this discussion should be applied judiciously to nondeveloped countries or patients recently emigrated from nondeveloped countries, because the epidemiology of fever may be more diverse in international settings and is beyond the scope of this chapter. Detailed discussion of evidence­based information is provided later in the section,
“Decision Rules for Assessment of Fever in Neonates and Infants <3 Months Old.” Any ill­appearing infant or child should have a complete sepsis evaluation performed and should be admitted for parenteral antibiotic therapy.
TABLE 119­1
Suggested Guidelines for the Evaluation and Management of Neonates, Infants, and Children With Fever Who Are Well Appearing, Have Had
All Relevant Immunizations, and Have No Clinical Source for Fever
Age Group Evaluation Treatment and Disposition
Neonate, 0–28 d* of CBC and blood culture Admit and treat with: age, ≥38°C (100.4°F) and Parenteral antibiotic therapy with ampicillin,  milligrams/kg, and either cefotaxime, 
SBI incidence of ill Urinalysis and urine culture milligrams/kg, or gentamicin, .5 milligrams/kg. Do not give ceftriaxone to infants <1 appearing: 13%–21%; if not and month old because it may displace bilirubin and worsen hyperbilirubinemia.
ill appearing: <10% CSF cell count, Gram stain, and culture.
Chest radiograph is optional, if no respiratory symptoms.
Stool culture if diarrhea is present.
Infant 29–56 d* of age, Same as for neonates. Discharge if:
≥38.2°C (100.8°F) WBC ≤15,000/mm3 and ≥5000/mm3 and <20% band forms.
(Philadelphia Protocol)
Urinalysis negative.
SBI incidence of ill
CSF WBC <10 cells/mm3. appearing: 13%–21%; if not
Negative chest radiograph or fecal leukocytes if applicable.
ill appearing: <5%
Admit if:
Any of above criteria is not met, and treat with parenteral ceftriaxone,  milligrams/kg with normal CSF, 100 milligrams/kg with signs of meningitis.
Infants  d to  mo* of Urinalysis and urine culture Discharge if negative.
age, ≥38°C (100.4°F) alone. Treat for UTI with oral antibiotics as outpatient (see Table 135­6).
Non­UTI SBI incidence is or Admit and treat with parenteral ceftriaxone if patient fails conservative criteria for discharge.
estimated to be negligible. For conservative
UTI is 3%–8%. management, treat infants
57–90 d using Philadelphia
Protocol above.
Infants  d to  mo* of Urinalysis and urine culture Discharge if negative.
age ≥39°C (102.2°F) alone. Treat for UTI as above.
SBI incidence is estimated or If WBC ≥15,000/mm3, consider treatment with ceftriaxone,  milligrams/kg IV/IM, and as <1%; non­UTI SBI Urinalysis and urine culture follow­up in  h.
incidence is estimated to in addition to CBC and
If WBC ≥20,000/mm3, consider chest radiograph and CSF testing.† be negligible. blood culture.
UTI is 3%–8%.
Infants/children 6–36 Urinalysis and urine culture. Discharge if negative.
mo of age Girls 6–24 mo Treat for UTI as above as outpatient.
Non­UTI SBI incidence is Boys 6–12 mo
<0.4% Uncircumcised boys 12–24
UTI in girls ≤8% mo
UTI in boys (<12 mo) ≤2%
Uncircumcised boys (1–2 y) remains 2%
Children >36 mo and No workup is routinely Discharge and treat with antipyretics: acetaminophen,  milligrams/kg PO/PR every  h, or older necessary. ibuprofen,  milligrams/kg PO every  h as needed.
Abbreviations: CSF = cerebrospinal fluid; SBI = serious bacterial illness; UTI = urinary tract infection.
*For preterm infants, count age by estimated postconception date and not by actual delivery date for the first  days of life.
†Meningismus is difficult to discern in infants <6 months of age, and especially in infants <2 months of age, and its absence does not exclude meningitis. Because of the declining prevalence of meningitis in the United States as infants age, we recommend routine CSF testing in infants <2 months of age, but selective CSF testing in infants  to  months of age. Peripheral WBC count (whether elevated or low) does not predict the risk for meningitis, and the decision to perform a lumbar puncture should be made independently of the peripheral WBC count.26­28
Reproduced with permission from Tenenbein M, Macias CG, Sharieff GQ, Yamamoto LG, & Schafermeyer RW (Eds). Strange and Schafermeyer's Pediatric Emergency
Medicine,  ed. McGraw­Hill, Inc. © 2019. Table 59­1, Pg 389. FEVER EVALUATION IN NEONATES AND INFANTS ≤3 MONTHS OLD
In infants <3 months of age, review the birth history, including the length of the gestation, the use of peripartum antibiotics in the mother or infant during labor or delivery, and the presence of neonatal complications, such as fever, tachypnea, or jaundice. Signs and symptoms of serious bacterial illness are typically nonspecific in this age group. For example, vomiting and diarrhea accompany many problems, including gastroenteritis, otitis media, UTI, and meningitis. Alternatively, crying may be either a manifestation of serious bacterial illness or a benign condition of infancy (colic or hunger).
Undress infants completely. Assess age­appropriate normal vital signs. Tachypnea or hypoxemia may be a clue to lower respiratory tract infection.
Inconsolable crying or increased irritability when handled is frequently seen in infants with meningitis. Although fullness of the anterior fontanelle may be noted in some infants with meningitis, other signs of meningeal irritation, such as nuchal rigidity, are usually absent. Perform a head­to­toe evaluation to identify a focus of infection, such as an inflamed tympanic membrane or evidence of cellulitis.
Treatment of neonates and infants <3 months old with a focal source for fever is controversial. In a small study of tympanocentesis­confirmed acute
 otitis media, there were no cases of bacteremia or meningitis, but UTI was found in 9%. The sample size of this study was not adequate to determine
 that blood testing or lumbar puncture was not necessary. A recent study in Europe that used a step­by­step approach in the evaluation of febrile infants without a source of fever identified a population of infants at low risk for serious bacterial illness that could be managed on an outpatient basis without the use of antibiotics or lumbar puncture. This study used physical appearance (well­appearing or not), age (cutoff of  days), urinalysis, and biomarkers in a stepwise fashion to identify these infants. The low­risk group of infants still had a rate of missed serious bacterial illness of .7%.
Therefore, even with an identified source, laboratory testing, close monitoring, and follow­up, especially in children <3 months old, are recommended to detect occult infection.
DECISION RULES FOR ASSESSMENT OF FEVER IN NEONATES AND INFANTS <3 MONTHS OLD
Clinical assessment of the severity of illness in neonates and young infants is difficult. The three most commonly applied outpatient criteria for the management of fever in well­appearing neonates and young infants are the Rochester Criteria, the Philadelphia Protocol, and the Boston
Criteria (Table 119­2). All three have limitations for clinical decision making. A comparison of these decision rules is difficult because of differences in inclusion criteria, laboratory testing, and clinical implications for decision making. In addition, the routine administration of antibiotics to pregnant women who test positive for group B Streptococcus on vaginal cultures and improved immunization practices have decreased the incidence of serious bacterial illness, making it difficult to extrapolate these three decision rules to current practice.
TABLE 119­2
Comparison of Low­Risk Rochester Criteria, Philadelphia Protocol, and Boston Criteria for Assessment of Fever in Well­Appearing Neonates and Infants* Low­Risk
Criteria for
Serious Rochester Criteria Philadelphia Protocol Boston Criteria
Bacterial
Infection* Fever T ≥38°C (100.4°F) T ≥38.2°C (100.8°F) T ≥38°C (100.4°F)
Age ≤60 d 29–56 d 28–89 d
Past medical Term infant ≥37 wk gestation No immunodeficiency No immunizations within  h history No perinatal or postnatal antibiotics syndrome No recent antibiotics
No treatment for jaundice
No chronic illnesses or admissions
Not hospitalized longer than mother
Physical Well appearing Same Same examination Unremarkable examination
Laboratory values
Blood count WBC ≥5000/mm3, ≤15,000/mm3 WBC ≤15,000/mm3 WBC ≤20,000/mm3
Absolute band count ≤1500/mm3 Band­to­neutrophil ratio
≤0.2
Urinalysis WBC ≤10 per high­power field WBC ≤10 per high­power WBC ≤10 per high­power field field
Stool WBC ≤5 per high­power field — —
Lumbar None WBC ≤8 per high­power WBC ≤10 per high­power field puncture and field Negative Gram stain cerebrospinal fluid findings
Chest radiograph None Negative Negative if obtained
Comments Excluded lumbar puncture, so number of missed Sensitivity of low­risk 5% of low­risk neonates and infants had meningitis cases is unknown. UTIs missed in those with criteria for SBI 98%; SBI (8 bacteremia,  UTI,  bacterial negative urinalysis. The least sensitive of the low­risk specificity 44%; PPV 14%; gastroenteritis); 96% sensitive to criteria. NPV .7% ceftriaxone
Abbreviations: NPV = negative predictive value; PPV = positive predictive value; SBI = serious bacterial illness; T = temperature; UTI = urinary tract infection.
*Any single deviation from the criteria is interpreted as failure of low­risk criteria.
The Rochester Criteria state that in well­appearing neonates and infants ≤60 days old, without prior or peripartum illness and with a normal CBC, a
 negative urinalysis and negative chest radiograph (if indicated) are sufficient to exclude serious bacterial illness. However, the Rochester Criteria miss 1% of patients with serious bacterial illness and do not include lumbar puncture as one of the diagnostic tests. The Rochester Criteria are the least sensitive of the three guidelines.
In the largest validation study of the Rochester Criteria, the cohort of 1057 patients included 511 who met low­risk criteria (Table 119­2). Five patients, or 1% of patients identified as low risk, had serious bacterial illness that was missed. Lumbar puncture was not included in the rules, so the criteria do not provide the ability to exclude meningitis. Of note, the incidence of meningitis was .3% of the entire cohort of 1057 patients, which is lower than the
1% meningitis incidence cited in most other studies. In summary, the Rochester Criteria miss 1% of patients with serious bacterial illness and do not exclude meningitis.
The Philadelphia Protocol (Table 119­2) includes the results of lumbar puncture in clinical decision making and includes young infants age  to 
 days old. The sensitivity of the low­risk criteria for excluding serious bacterial illness (neonatal bacteremia, UTI, or meningitis) is 98%; specificity is
44%; positive predictive value is 14%; and negative predictive value is .7%. The temperature criterion for fever was .2°C (100.8°F), not 38°C
(100.4°F). The incidence of meningitis in this cohort was .2%. Using the Philadelphia Protocol, all patients with meningitis were identified. One of 288 patients, who had otherwise met low­risk criteria, was identified by an elevated cerebrospinal fluid WBC alone. In addition, all cases of bacteremia and
UTI were identified by the Philadelphia Protocol.
The Boston Criteria (Table 119­2) attempted to identify young infants at lower risk of serious bacterial illness and safely treat them as outpatients
  with empiric ceftriaxone. The Boston Criteria included infants  to  days of age and accepted a peripheral WBC up to ,000/mm as normal.
Lumbar puncture was performed in all patients, and all patients with meningitis were excluded. In those who met low­risk criteria, <1% of patients had a missed serious bacterial illness, and none had complications after empiric treatment with ceftriaxone. By using the Boston Criteria, a greater number of patients are discharged.
,34
Subsequent studies applying the Rochester, Philadelphia, and Boston decision rules missed serious bacterial illness in neonates  to  days old.
The safest course for 0­ to 30­day­old infants is sepsis testing, admission, and empiric antibiotic treatment (Table 119­1).
The recognition of occult serious bacterial illness in well­appearing neonates and infants <3 months of age is difficult. No single clinical variable or diagnostic test can correctly or reliably identify it in this age group. In addition, as noted earlier with the Rochester, Philadelphia, and Boston decision rules, these rules differ in their inclusion criteria. Combinations of variables can be helpful. A study from Boston chose statistically significant cutoff
  points for predictive variables for SBI. In order of greatest statistical significance for prediction were positive urinalysis, WBC >20,000/mm ,
 temperature >39.6°C (103.3°F), WBC <4100/mm , and age <13 days old. No variable or cutoff point was 100% sensitive or specific, and the number of meningitis cases was too small to lead to the inclusion of results of lumbar puncture in the decision rule. This study challenges the previous study protocols by introducing clinical and diagnostic test variables that were determined to be statistically significant. Although this is not standard of care, this added information may help determine different thresholds for fever evaluation in the neonate or for admission and antibiotic therapy.
TREATMENT, DISPOSITION, AND FOLLOW­UP FOR FEVER IN NEONATES AND INFANTS ≤3 MONTHS OLD
There is no community standard of practice regarding the need for hospitalization of infants  months of age and younger. Some physicians hospitalize all febrile infants <3 months old, and others hospitalize selectively. Some have attributed this difference in management to a difference in bias, with physicians in private practice having a bias toward wellness (the infant is basically healthy) and emergency physicians having a bias toward
 illness (worst­case scenario approach). Because the differentiation between sick and well infants <28 days of age is difficult, with varying reports of missed serious bacterial illness, all febrile infants <28 days of age should have sepsis evaluations, including CBC, blood culture, urinalysis, urine culture, cerebrospinal fluid cell count, Gram stain and culture, and admission for parenteral antibiotics. Infants who are ill appearing or fail to meet the low­risk criteria (Table 119­2) should be admitted and administered parenteral antibiotics. Ampicillin (50 milligrams/kg/dose every  hours) and cefotaxime (50 milligrams/kg/dose every  hours) is a common antibiotic regimen (or ampicillin and gentamicin, .5 milligrams/kg/dose), but choose antibiotics based on regional susceptibility patterns for group B Streptococcus, E. coli, and L. monocytogenes. Do not give ceftriaxone to infants
<1 month old because it may displace bilirubin and worsen hyperbilirubinemia.
The decision to discharge a febrile infant home must be made after careful clinical and appropriate laboratory assessment and after ensuring the reliability of follow­up. Utilization of the Rochester Criteria, the Philadelphia Protocol, or the Boston Criteria may be considered. No missed cases of meningitis have been described with the Philadelphia Protocol and the Boston Criteria. The Philadelphia Protocol is recommended due to its high sensitivity.
If low­risk criteria are met for the Philadelphia Protocol, the patient may be discharged home without antibiotic administration, with evaluation in  hours. Additional factors for outpatient management are a reliable caretaker with a telephone and an infant who can maintain hydration. Any child who is ill appearing should be admitted and given parenteral antibiotics, regardless of the age.
Utilization of the data from viral testing may also influence the decision to discharge to home or admit for observation.

In a large, multicenter, retrospective study, Schnadower et al proposed that febrile infants  to  days old who demonstrate evidence of UTI, but meet low­risk criteria, may be safely discharged with antibiotic therapy. Significant adverse events, such as meningitis and sepsis, requiring critical care intervention occurred in .8% of patients. Bacteremia occurred in .5% of patients. Low­risk criteria for both adverse events and bacteremia were lack of ill appearance in the ED and lack of high­risk past medical history. Additional low­risk criteria for bacteremia included peripheral band count of
<1250 cells/mm  and peripheral neutrophil count of ≥1500 cells/mm  . 
Antibiotics are administered for clinically evident bacterial disease, such as pneumonia, meningitis, otitis media, cellulitis, and septic arthritis. Specific management is outlined in Chapter 121, “Ear and Mastoid Disorders in Infants and Children”; Chapter 128, “Pneumonia in Infants and Children”; and
Chapter 142, “Rashes in Infants and Children.”
SPECIAL SITUATIONS: NEONATES AND INFANTS <3 MONTHS OLD WITH FEVER AND RECOGNIZABLE VIRAL ILLNESS
Many studies have shown that infants with bronchiolitis may still have a serious bacterial illness, although the risk of serious bacterial illness is
,11,38­41 significantly lower in febrile infants with bronchiolitis compared to febrile infants without bronchiolitis. ED evaluation should therefore also include a minimum of a urinalysis and urine culture in patients with bronchiolitis. Consider urinalysis, urine culture, CBC, and blood culture in patients with suspected or proven enterovirus or parainfluenza infection.
SERUM BIOMARKERS
Although the serum WBC count, absolute neutrophil count, and band­to­neutrophil ratio remain the standard biomarkers for serious bacterial illness in young infants (see previous section on decision rules), the value of several other potential biomarkers deserves mention. C­reactive protein has been widely studied, but recent studies suggest that procalcitonin may be better. Procalcitonin is emerging as the best biomarker currently available to
42­46 detect bacterial infections in febrile children, including in infants with fever without a source. However, these studies have used varying cutoff levels. In addition, procalcitonin is not widely available, particularly within the United States. An approach combining clinical decision and serum
 biomarkers, as in the study by Gomez et al, may be the best approach to the evaluation of these infants.
FEVER EVALUATION IN INFANTS  TO  MONTHS OLD
CLINICAL FEATURES
Clinical assessment is more reliable for older infants and young children than for young infants. Viral illnesses, including respiratory infections and gastroenteritis, account for most febrile illnesses and usually have system­specific symptoms, such as vomiting, diarrhea, rhinorrhea, cough, or rash.
Characteristics to note are willingness of patients to make eye contact, playfulness and positive response to interactions, negative response to noxious stimuli, alertness, and ease of consolation. Toxic infants will not respond appropriately.
Otitis media is usually caused by S. pneumoniae or nontypeable H. influenzae. Although pneumonia is commonly viral, it is difficult to distinguish bacterial from viral causes. In older infants or young children with UTI, fever is usually the only presenting sign, but a history of foul­smelling urine or crying with urination may be noted. Cellulitis is clinically apparent. Abscess may be associated with these patients as well. Bacterial pharyngitis is unlikely under the age of  years.
Nuchal rigidity and Kernig or Brudzinski signs may be absent in children with meningitis even up to the age of  years old. A bulging fontanelle, vomiting, irritability that increases when the infant is held, inconsolability, or a complex febrile seizure may be the only signs suggestive of meningitis. Infants with aseptic meningitis generally should be hospitalized and provided with long­term follow­up because they are at greater risk for dehydration and subsequent neurologic and learning disabilities.
Petechiae noted on physical examination are concerning for infection by N. meningitidis. However, most children with fever and petechiae will have a viral cause, such as adenovirus, whereas purpura fulminans (see Chapter 142, “Rashes in Infants and Children”), hypotension, lethargy, and meningismus predict meningococcemia. For the well­appearing child with fever and petechiae, there are no good predictors for serious bacterial illness. Time may be the best diagnostic test, with a brief observation period or admission warranted for cases that are indeterminate.
DIAGNOSIS
The American Academy of Pediatrics practice guidelines that advocate testing for UTI in children  months to  years of age may be broken down into
 guidelines for girls and boys. Ill appearance and history of UTI exclude patients from these guidelines. For girls, testing should be done if they have two or more of the following risk factors: (1) white race; (2) age <12 months; (3) temperature ≥39°C (102.2°F); (4) fever ≥2 days; and (5) absence of another source of infection. Uncircumcised boys should be tested if no apparent focus of infection is present. Circumcised boys should be tested if two or more of the following risk factors exist: (1) nonblack race; (2) temperature ≥39°C (102.2°F); (3) fever >24 hours; and (4) absence of another source of infection.
Many would advocate that empiric blood testing and treatment for these patients is no longer necessary. Although reports of decreased bacteremia incidence have been published, as of this writing, no studies to determine predictors of bacteremia, outcome of empiric antibiotic use, reduction of complications, or outcome of nontreatment protocols have been published since the introduction of the pneumococcal conjugate vaccines. In addition, no practice parameters have established a current standard of care, and the American Academy of Pediatrics has not renewed its practice guideline since 1993. The physician is therefore left with evidence of decreased incidence of bacteremia, but no studies or practice parameters supporting a selective testing or nontesting protocol.
,18,47,48 ,49,50
Given the decrease in invasive pneumococcal disease and the limited predictive value of an elevated WBC for bacteremia, three options exist. The first option is following the previous practice parameters and obtaining a CBC and blood culture on all children between  and  months old
351 with a fever >39°C (102.2°F), and then treating with ceftriaxone only if the WBC is >15,000/mm . Because of the low positive predictive value of an elevated WBC, the second option is obtaining a blood culture and waiting for results before beginning empiric treatment. The third option is to assume that the incidence of pneumococcal disease has decreased so substantially that laboratory evaluation in a well­appearing child is unnecessary, so discharge with primary care follow­up is reasonable. Variants on the first and second options may be to evaluate children between  and  months of age because these children have not received the first three vaccine series.
TREATMENT, DISPOSITION, AND FOLLOW­UP IN INFANTS  TO  MONTHS OLD
Any child who appears ill or toxic, is unable to maintain oral hydration, or has inadequate follow­up after discharge should be admitted for IV hydration and/or parenteral antibiotic therapy. Choices for antibiotics depend on the organism and the regional susceptibilities.
For recognized bacterial infections, use appropriate antibiotics based on the type of infection and regional and national standards. Treatment with high­dose amoxicillin (30 milligrams/kg/dose given three times daily, to a maximum adult dose) is recommended for otitis media, pneumonia, and sinusitis. Alternatives include amoxicillin/clavulanic acid, basing the dosing on high­dose amoxicillin, or azithromycin (10 to  milligrams/kg on day one (max 500 mg/dose) followed by  to  milligrams/kg once daily on days  to 5) for penicillin­allergic patients.
Patients with cellulitis should be treated with appropriate antistreptococcal and antistaphylococcal antibiotic therapy (Chapter 142, "Rashes in
Infants and Children"). Cephalexin (20 to  milligrams/kg per dose four times a day for  days) or amoxicillin/clavulanic acid (22.5 milligrams/kg/d per dose twice daily) are appropriate choices. Given the increase in methicillin­resistant S. aureus, consider using an antibiotic regimen effective against this organism: clindamycin (10 milligrams/kg per dose three times a day for  days) or a combination of cephalexin and trimethoprimsulfamethoxazole (trimethoprim,  milligrams/kg per dose twice a day for  days). The choice of antibiotic therapy for UTIs should be based on regional antibiotic susceptibility testing. Table 135­6 lists common treatment options.
Approximately 80% of patients with S. pneumoniae bacteremia will have spontaneous resolution, but in 20% of patients, complications will arise, such as meningitis, pneumonia, or sinusitis. Each of these factors may be considered if occult bacteremia is suspected. If treatment is indicated, obtain a blood culture before administration of ceftriaxone at a single dose of  milligrams/kg. Ceftriaxone reduces the risk of complications from
,52,53 bacteremia. While reducing the incidence of infectious sequelae, the difficulty with empiric antibiotic treatment arises when the blood culture returns as positive but no cerebrospinal fluid studies were sent.
POSITIVE BLOOD CULTURES IN CHILDREN  TO  MONTHS OLD
Recall all children with positive blood cultures. In the case of positive S. pneumoniae cultures, if the child is receiving appropriate antibiotics, is clinically well, and is afebrile, the child should complete the course of therapy. If the child is afebrile and clinically well but not receiving antibiotics, opinions differ regarding the need for additional blood cultures and antibiotic therapy. In general, neither is necessary unless the child has developed a specific focus of infection.
The febrile child with a positive blood culture should receive evaluation (repeat blood culture, CBC, and consider urinalysis and lumbar puncture). For the persistently febrile patient who is well appearing and has a normal evaluation, admission is usual, although empiric treatment with ceftriaxone and follow­up as an outpatient may be considered.
For any patient who is ill appearing, obtain the sepsis evaluation and admit for parenteral antibiotics. Likewise, children who are thought to be at risk for serious bacterial illness and do not have reliable follow­up or the ability to return to the hospital should also be admitted for inpatient management.
Children with cultures positive for N. meningitidis or methicillin­resistant S. aureus should be admitted for parenteral antibiotic therapy. For organisms other than S. pneumoniae, N. meningitidis, or methicillin­resistant S. aureus, more conservative management may be warranted.
FEVER IN CHILDREN >36 MONTHS OLD
Children >36 months old are easier to evaluate, and their complaints are usually more specific. Children with infections such as UTI, meningitis, pneumonia, pharyngitis, and otitis media are more likely to complain of symptoms typical for these diagnoses. Pharyngitis due to group A
Streptococcus becomes more common in this age group, especially in the school­aged child (Chapter 124, "Mouth and Throat Disorders in Infants and
Children"). However, infectious mononucleosis also becomes more prevalent in this age group and may mimic the signs and symptoms of group A streptococcal pharyngitis. Treatment for group A streptococcal infection is amoxicillin (25 milligrams/kg twice daily for  days), penicillin G benzathine (50,000 units/kg IM single dose, up to 900,000 units IM for older pediatric patients), or azithromycin (10 to  milligrams/kg on day one (max
500 mg/dose) followed by  to  milligrams/kg once daily on days  to 5) for penicillin­allergic patients.
Kawasaki’s disease (see Chapter 129, “Congenital and Acquired Pediatric Heart Disease”) is the most common cause of acquired cardiac disease in children and typically presents in children <5 years of age. Patients usually have high fevers for  days, strawberry­appearing tongue, conjunctivitis and iritis, red mucous membranes in the mouth and dry cracked lips, and swollen lymph nodes. Peeling of the skin in the hands, feet, and genital area may also occur in the later phases. Variants of Kawasaki’s disease also occur, with fewer of these classic signs. Untreated patients with Kawasaki’s disease may develop life­threatening coronary aneurysms. Treatment for Kawasaki’s disease involves aspirin and IV immunoglobulin.
PHOENIX SEPSIS SCORE: DEFINING AND RECOGNIZING PEDIATRIC SEPSIS

In January 2024, the Society of Critical Care Medicine Pediatric Sepsis Definition Task Force updated the pediatric sepsis definition and criteria. The conceptual definition adopted by the task force was suspected infection with life­threatening organ dysfunction involving the cardiovascular, respiratory, neurologic, and coagulation systems. Individual organ dysfunction sub­scores that best predicted mortality were then identified and integrated into models to predict mortality. An integer­based score (the Phoenix Sepsis Score) was then developed from the best performing model. The criteria can be applied to children <  years old. Criteria are not to be used for newborns or neonates <  week postconceptional age.
The data analysis used electronic health record data from multiple sites — both nationally and internationally — in both low­ and high­resource settings, representing .6 million pediatric hospital encounters from a racially diverse patient population. The primary outcome was in­hospital
(emergency and in­patient) mortality in children with suspected or confirmed infection. The secondary outcome was a composite of early mortality
(within  hours of hospitalization) or requirement of extracorporeal membrane oxygenation (ECMO) support. The variables used to calculate the sepsis score were respiratory (PaO and SpO ), cardiovascular (use of vasoactive medications, serum lactate level, and age­based mean arterial
  pressure), coagulation abnormalities (platelets, INR, D­dimer, and fibrinogen), and neurologic changes (GCS or fixed pupils bilaterally). Scores range from  to  points.
A Phoenix Sepsis Score of  or greater (with suspected infection) was adopted as the new pediatric sepsis definition. Likewise, septic shock was defined as sepsis with  or more cardiovascular points. This model has improved performance for the diagnosis of pediatric sepsis and septic shock
 when compared to the previous 2005 International Pediatric Sepsis Consensus Conference (IPSCC) criteria. However, the Phoenix Sepsis Score is not a screening tool to identify sepsis but is a tool for identifying complex life­threatening organ dysfunction from infection in children. It has not been
 determined if the new score improves patient care, and the score does not substitute for physician clinical judgement.
POSITIVE BLOOD CULTURES OBTAINED IN A PEDIATRIC ED: BACTEREMIA VS
CONTAMINATION
When pediatric blood cultures are obtained, contamination with non­pathogenic bacteria is a common complication. Up to 60% of preliminarily positive pediatric blood cultures are ultimately determined to be contaminated. This problem is especially important for children who are discharged home. Having patients return for evaluation, repeating the blood culture, and administering antimicrobials or requiring hospitalization can have negative consequences for health and care. The Hospital for Sick Children in Ontario, Canada created and validated an institutional guideline to
 standardize practice and optimize care .
All children younger than  years of age with a positive blood culture obtained in the one Canadian tertiary care pediatric ED between 2018 and 2022 were eligible for inclusion. Of 375,428 ED visits, 574 cases were identified. Duplicate cultures were excluded. The primary outcome was the presence of definitive bacteremia, defined as blood cultures growing a bacterium capable of causing clinically significant bacteremia in previously healthy children.
Contaminating organisms were those not considered pathogenic in healthy children. Equivocal organisms were those that could be a contaminant in children without any previous medical condition but could also be clinically significant in some situations. In cases with equivocal bacterial growth, investigators assessed the medical chart to classify the blood culture as bacteremia or contaminant based on the presence of a second positive culture in a normally sterile sample, final diagnosis of the treating physician, outcome of a patient who did not receive antibiotics, and treatment provided to the patient (e.g., immunocompromised patients who received antibiotics for many days).
Suspicion of an osteoarticular infection, presence of any internal hardware, and gram­negative bacilli or gram­positive cocci in pairs/chains on Gram stain were the most important predictors of true bacteremia. The variables that distinguish high­ and medium­risk patients are important factors to determine which patients can be treated safely by eliminating repeat blood cultures (and thus running the risk of contamination again), repeat hospitalizations, or unnecessary antibiotics (Table 119–3).

The Hospital for Sick Children study determined that half of preliminary positive blood cultures in their single pediatric ED were contaminants. The algorithm demonstrated a sensitivity of 100% in identifying true bacteremia but a specificity of 11% when applied to all children with preliminary positive blood cultures. A sub­analysis restricted to children discharged home demonstrated 100% sensitivity and 25% specificity.
Use of this risk stratification tool improves identification of children at risk for true bacteremia, but at the risk of low specificity. Generalizability of results to a variety of EDs needs to be validated.
TABLE 119­3
Risk Stratifying for discriminating bacteremia from blood culture contaminants in children63
High Risk Medium Risk Low Risk
Risk Factors Gram stain shows: Central line Call the family to ask if child is well
– Gram­negative organism Internal hardware: (no fever, normal energy level,
– Gram­positive cocci in pairs and chains Prosthetic heart valve, normal behavior)
– Yeast endovascular prosthetic material, scoliosis repair
OR
Chronic illness:
Patient is immunocompromised:
Heart failure, chronic
Solid organ or bone marrow transplant, kidney injury, primary immunodeficiency, neutrophils rheumatologic condition,
<0.5, immunosuppressants, sickle cell treatment with biologic disease, or hyposplenia therapies
GIFT patient* Suspect endocarditis
Patient <  months old
Musculoskeletal pain
Reassessment Return to ED Return to ED Watch and wait and Repeat blood cultures Repeat blood cultures Provide instructions for
Disposition Administer antimicrobial Clinical decision: Admit and returning to ED
Admit or transfer treat with antibiotics When culture results are available, call family and
OR explain if antimicrobial
Discharge to home observation with treatment is needed instructions to return if worsening
Advise follow­up with PCP
If discharged, when culture results available, call family and inform if antibiotics are needed or not
*GIFT= gamete intrafallopian transfer
# Gravel J et al. Validation of the Hospital for Sick Children algorithm for discriminating bacteremia from contaminant in children with a preliminary positive blood culture. Ann Emerg Med 2024 https://doi.org/10.1016/j.annemergmed.2024.05.005
PROCEDURES IN CHILDREN: LUMBAR PUNCTURE
The usual goal of lumbar puncture in children is to obtain cerebrospinal fluid to test for markers of infection. Measuring opening pressure is not necessary, and therefore, the procedure is straightforward. The condition of children with hypoxemia, respiratory distress, hypotension, and tachycardia may deteriorate when they are positioned for lumbar puncture, so resuscitation and empiric administration of IV antibiotics is needed prior to lumbar puncture. In children with thrombocytopenia or factor deficiencies, replace platelets or factor before attempting lumbar puncture.
PATIENT PREPARATION
Anticipate the procedure and its difficulties. Assemble a needle of the correct size, the appropriate specimen containers, and preprinted labels, and ensure a quiet environment without interruptions. Explain the procedure to the caregivers. In some institutions, written informed consent for lumbar puncture is required. Describe the process of procedural sedation if it is needed and obtain consent.
,55
Apply a topical anesthetic cream or spray prior to needle insertion to reduce pain and improve the success rate of the lumbar puncture. For infants, sucking on a pacifier dipped in sucrose solution is analgesic and calming and decreases crying. Prepare the skin using sterile technique.
POSITION
Have an experienced healthcare provider, the “holder,” restrain the infant or child. Wrapping the child in sheets may help limit leg movement. Flexing the hips is more important than flexing the neck. In addition, flexing the neck may lead to respiratory difficulty. Continuous pulse oximetry may be helpful in monitoring for airway obstruction. Whether to choose the lateral recumbent position or the sitting position depends upon the preference of the physician. In some studies, using US to measure the width between the spinous processes in the sitting position was found to be better than the
,57 lateral decubitus position. Although the sitting position may improve flexion of the hips, this position may be more difficult for the holder to maintain.
LUMBAR PUNCTURE TECHNIQUE
Most lumbar punctures are performed with a 22­gauge lumbar puncture needle, usually  in. in length for infants,  in. for children  years to  years, and  in. for older children. In obese patients, choosing a lumbar puncture needle may be more difficult. One study calculated that a lumbar
 puncture needle length (in centimeters) of  + [17 × (weight in kilograms/height in centimeters)] was most accurate. Lumbar puncture depth was measured on abdominal CT scans to derive this formula. Lumbar needles with a clear hub show cerebrospinal fluid flow sooner than those with metal or opaque hubs.
Insert the LP needle between the L4 and L5 spinous processes in the intervertebral space in the midline of the back and direct the needle toward the umbilicus. This interspace is easily located because it lies in line between the iliac crests. Introduce the needle with the bevel of the needle up. Insert the needle until the characteristic “pop” identifies introduction into the subarachnoid space. An alternative method is to remove the stylet from the needle after the needle pierces the skin. Advance the needle, without the stylet, incrementally until cerebrospinal fluid flows. Occasionally rotating the lumbar needle clockwise or counterclockwise up to 360 degrees may help improve flow if the bevel of the needle is sideways. When removing the lumbar needle, replace the stylet.

Bonadio originally reported early stylet removal as the “Cincinnati method” in 1992. Early experience with hollow­bore needles without a stylet associated this technique with the development of epidermoid tumors after the procedure. However, by puncturing the epidermis with the stylet in place and removing the stylet after introduction through the epidermis, this complication should be eliminated. Two separate reports found that the
,55 use of this Cincinnati method and the administration of topical anesthetics were associated with improved success rates.
After successful entry into the subarachnoid space, collect three tubes of cerebrospinal fluid, each with at least .5 mL of fluid. Send the first tube for cell count, which includes WBC and red blood cell counts; send the second tube for protein and glucose measurement; and send the third tube for routine bacterial culture and Gram staining (Table 119­4). Additional tubes may be collected for polymerase chain reaction testing for bacteria and viruses as needed (e.g., enterovirus, herpes simplex virus). If the child has been pretreated with antibiotics, latex agglutination testing may be performed for H. influenzae type b, S. pneumoniae, group B streptococci, E. coli, and N. meningitidis serogroups A, B, C, Y, and W135. However, latex agglutination testing has poor sensitivity for bacterial infection. Polymerase chain reaction assays for pathogenic organisms, including panels for multiple viral and bacterial pathogens, are also available.
TABLE 119­4
Normal Cerebrospinal Fluid (CSF) Values by Age
CSF Parameter 0–4 wk 4–8 wk >8 wk
WBCs/mm3 0–19 cells/mm3 0–9 cells/mm3 0–9 cells/mm3
Glucose (milligrams/dL) 30–60 40–70 50–80
CSF/blood glucose ratio 60% 60% 60%
Protein (milligrams/dL) 60–100 50–80 15–45
Source: Adapted with permission from Tenenbein M, Macias CG, Sharieff GQ, Yamamoto LG, Schafermeyer RW (eds): Strange and Schafermeyer’s Pediatric Emergency
Medicine, 5th ed. New York: McGraw­Hill Education, Inc. © 2019. Table 59­1, p. 389. After a failed attempt, obtain a new needle and restart the procedure. Insertion into the L3 to L4 intervertebral space or the L5 to S1 intervertebral space may be successful. US­ or fluoroscopy­guided lumbar needle insertion may be necessary when all else fails.


