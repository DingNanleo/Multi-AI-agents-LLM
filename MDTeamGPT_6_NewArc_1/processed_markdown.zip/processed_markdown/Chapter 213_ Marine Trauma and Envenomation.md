## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 213: Marine Trauma and Envenomation
John J. Devlin; Kevin J. Knoop
MARINE TRAUMA
Human contact with the marine environment is becoming more frequent as recreational and commercial use of the world’s oceans increases. In addition to the hazards of drowning and cold exposure, the marine environment provides the habitat for dangerous marine fauna. Many marine animals have evolved sharp teeth and spines or venom glands for defense and predation. Encounters with marine life may result in traumatic injury or envenomation, requiring emergency medical management. Providing care for these conditions may be further complicated by the marine environment’s geographic isolation from locations with definitive health care.
EPIDEMIOLOGY
The most common reported U.S. exposures are to jellyfish (31%), stingrays (16%), venomous fish (including lionfish, catfish, and others) (28%), and
 gastropods (6%). However, data likely favor the reporting of more severe injuries and the exclusion of common minor injuries. Human impact may be altering the geographic distribution of marine fauna as climate change affects migration patterns and artificial waterways connect previously
,3 separated bodies of water and their ecosystems.
The International Shark Attack File recorded 2944 unprovoked shark attacks between 1958 and 2017, with the United States reporting the most attacks.
Within the United States, 56% of attacks occur in the waters off Florida, with Hawaii, California, and the Carolinas rounding out the top five states
 reporting unprovoked shark attacks. Despite the public perception, the risk of shark attack is extremely small compared with almost any other injury,
,5 with only  to 100 shark attacks worldwide each year, resulting in only  to  deaths. Although the incidence of shark attacks has steadily risen
 since 1900, the mortality has fallen from 40% in the  years following World War II to current rates of approximately 10% to 20%. Death is usually a result of a lack of prehospital resuscitation, hemorrhagic shock, or drowning.
Other marine creatures implicated in traumatic injuries to humans include barracuda, giant groupers, sea lions, seals, crocodiles, alligators, and piranhas. Some fish with sharp spines and fins (needlefish, wahoo, and triggerfish) can inadvertently injure humans. Wounds resulting from interactions with such creatures are a combination of crush injury, abrasion, puncture, and/or laceration.
BACTERIOLOGY OF MARINE SOFT TISSUE INFECTIONS
Marine soft tissue infections are often polymicrobial, halophilic, gram­negative infections that may be resistant to first­ and second­generation
 penicillins and cephalosporins. Infecting bacteria are numerous and can vary with the environment, type of injury, and marine organism. Bacteria include staphylococci, streptococci, Aeromonas hydrophilia, Escherichia coli, Pseudomonas species, Erysipelothrix species, Chromobacterium,
8­10
Edwardsiella, Shewanella, Mycobacterium species, Mycoplasma species, and Vibrio species. Marine­associated infections are frequently diagnosed late because the history of marine exposure or injury is poorly recalled, and patients are often initially given inappropriate antibiotics, which potentially increases the morbidity of an already virulent infection. Patients with underlying conditions such as liver disease, immunosuppression, and
 diabetes are more susceptible to halophilic Vibrio infections. Vibrio skin infections can progress rapidly from initial contact and local painful inflammation, through subepidermal bullae containing hemorrhagic fluid and vasculitis, to necrosis and small­vessel thrombosis, bacteremia, and
,11 septicemia.
MAJOR MARINE TRAUMA
Encounters with sharks, skates, stingrays, barracuda, moray eels, and giant groupers can result in major trauma. Of these animal­related injuries, sDhoawrkn lboiatedse adr e2 0th2e5 ­b7e­s1t 6ch:3a4ra Pc t eYroizuerd I.P12 ,i1s3 1S3h6a.r1k4 a2tt.1a5ck9s.1 c2a7n result in neurovascular injury and significant tissue loss. Sharks typically attack the
Chapter 213: Marine Trauma and Envenomation, John J. Devlin; Kevin J. Knoop appendages (in either seals or humans), which tend to dangle lower than the head and torso while the victim is swimming on the surface. In 70% of
. Terms of Use * Privacy Policy * Notice * Accessibility surface swimmers, only the lower limb is involved. The upper limb can be subsequently injured when the victim tries to fend off the attacker. Sharks
 are unable to chew their prey and so sequentially strip and tear the prey to eat it. In more serious attacks, substantial tissue loss and extremity
 amputation are common. However, .6% of shark attacks in the United States are nonfatal.
Stingrays possess spined tails that reflexively whip upward when the animal is stepped on or startled. These encounters typically result in foot and ankle injuries. However, serious thoracoabdominal injuries have been reported. Morbidity and mortality result from penetrating trauma to internal
14­16 organs. Imaging should be obtained to rule out a rare retained spine tip.
Victims of marine animal–associated trauma should be removed sufficiently from the water to allow immediate resuscitation. As in trauma settings, place a tourniquet on limbs with evidence of uncontrolled arterial hemorrhage, because the survival benefit after tourniquet placement outweighs the
  low risk of neurologic injury from compression. At the hospital, manage injuries according to institutional trauma protocols.
There are two trauma caveats with respect to marine injuries. First, teeth and spines may be retained in bone and soft tissue and be a source of infection. Obtain plain radiographs of all injured regions to identify fractures, periosteal stripping, and retained foreign bodies. If radiographs are unremarkable but there is still a high clinical suspicion for a retained foreign body, US may be helpful. US may be particularly helpful in identifying
,19 radiolucent fragments of sea urchin spines and stingray barbs. The second trauma caveat is that the mouths and integument of marine fauna can be heavily colonized with marine bacteria. Swab wounds and send specimens for culture. Many marine microorganisms require special selective media for culture and sensitivity testing, so alert the microbiology laboratory that a marine­acquired organism might be present. Infections from marine microorganisms can be more serious than usual soft tissue infections. Irrigate open wounds and debride devitalized tissue. Do not suture lacerations or puncture wounds sustained in marine environments.Provide early antibiotic treatment (usually antibiotic combinations) for wounds from major trauma, in those at risk for infection, in the immunocompromised or those with hepatic disease, and for established infection
,9,11,20,21 
(Tables 213­1 and 213­2). Provide postexposure tetanus prophylaxis. Obtain early surgical consultation for thorough debridement for suspected Vibrio vulnificus infections or any necrotizing infection. Regardless of the antibiotic choice, close clinical follow­up is essential to identify treatment failures early.
TABLE 213­1
Recommendations for Antibiotic Treatment of Marine­Associated Wounds
No Antibiotic Indicated Prophylactic/Outpatient Antibiotics Hospital Admission for IV Antibiotics
Healthy patient Late wound care Predisposing medical conditions
Prompt wound care Large lacerations or injuries Long delays before definitive wound care
No foreign body Early or local inflammation Deep wounds, significant trauma
No bone or joint involvement Wounds with retained foreign bodies
Small or superficial injuries Progressive inflammatory changes
Penetration of periosteum, joint space, or body cavity
Major injuries associated with envenomation
Systemic illness
TABLE 213­2
Antibiotics for Marine­Associated Wound Infections* Seawater Associated: Vibrio Freshwater Associated: Aeromonas
For All: Staphylococci and Streptococci Coverage
Species Coverage Species Coverage
First­generation cephalosporin Fluoroquinolone Fluoroquinolone or or or
Methicillin­resistant Staphylococcus aureus coverage Third­generation cephalosporin Trimethoprim­sulfamethoxazole depending on prevalence or
Carbapenems
*Patients should receive both an antibiotic from the first column and a second agent from either the second or third column. Most marine bacteria are resistant to cephalosporins and antibiotic combinations are needed for serious infections. Antibiotic choices have not been robustly investigated. Antibiotic sensitivities vary, and in vitro antibiotic susceptibility data and clinical outcomes may not relate. Marine infections are polymicrobial.
MINOR MARINE TRAUMA
Most marine injuries and stings do not cause serious injury. Treatment depends on the agent and the seriousness of injury (Table 213­2). Coral cuts are probably the most common injuries sustained underwater and usually involve the hands, forearms, elbows, and knees (Figure 213­1). The initial reaction to a coral cut is stinging pain, erythema, and pruritus. Within minutes, the break in the skin may be surrounded by an erythematous wheal, which fades over  to  hours. With or without treatment, the local reaction of red, raised welts and local pruritus may progress to cellulitis with ulceration and tissue sloughing. The wounds heal slowly over  to  weeks.
FIGURE 213­1. These injuries occurred when the swimmer was thrown up against coral by wave action. Coral wounds should be evaluated for retained foreign body.
[Photo contributed by Kaitlin Pala, MD.]
Promptly and vigorously irrigate cuts to remove all foreign matter. Fragments that remain can become embedded and increase the risk of infection or foreign­body granuloma. Instruct patients to clean superficial wounds daily, and to return to the ED for any signs of inflammation. Give antibiotics if infection develops (Tables 213­1 and 213­2).
MARINE ENVENOMATIONS
Venomous marine animals produce venom in specialized glands. The venom can then be applied to or injected parenterally into other organisms using a specialized venom apparatus. Venom is not a pure substance but a mixture of mainly protein and peptide toxins. The effect of a specific toxin depends on its site of action; it may be neurotoxic, hemotoxic, dermatotoxic, cytotoxic, or myotoxic. Unlike thermostable ingestible seafood poisons,
 marine venoms are typically high­molecular­weight, heat­labile proteins.
STINGRAYS AND VENOMOUS FISH
STINGRAYS

All stingrays’ tails house venomous spines. Inflicted lacerations allow the injection of venom. Stingray injuries cause immediate intense local pain that may radiate and last for many hours. There is often significant bleeding depending on the site of injury, and the wound may be erythematous or dusky. Systemic effects are uncommon, but have been reported and relate more to the systemic response to severe pain. Submerging the affected extremity in hot water between 110°F (43.3°C) and 114°F (45.6°C) can denature the venom protein and provide pain relief within  to 
,25 minutes. Topical lidocaine can be applied for additional pain relief, and systemic analgesics can blunt the pain of hot water submersion.
VENOMOUS FISH STINGS
Venomous fish are found in tropical and, less commonly, temperate oceans and private aquariums. The important venomous fish include stonefish, weeverfish, scorpionfish, and lionfish. The effects of the stings range from severe with stonefish to minimal with some types of catfish and other fish
,26 with nonvenomous spines.
Stonefish (Synanceia species) and scorpionfish (Scorpaenidae) occur throughout tropical and warmer temperate oceans from the central
Pacific, west through the Indo­Pacific, to the East African coastline. They are a diverse group of fish, with differing habitats, swimming patterns, and
,26 ability to camouflage. The venom apparatus varies among species, but most have  to  dorsal spines. Stonefish are stationary bottom dwellers usually frequenting shallow water.
Clinical effects are characterized by immediate severe and increasing local pain, which may radiate proximally. Untreated, the pain typically peaks at  to  minutes and persists for  to  hours, but this varies considerably for different fish. The wound site usually has significant local edema and erythema. Nonspecific systemic effects such as sweating, nausea, vomiting, and even syncope may occur. Extensive tissue necrosis is not seen unless a secondary infection develops.
Weeverfish (or weaverfish) are all saltwater fish and are the most venomous fish in the temperate zone. They are found in the Mediterranean and
European coastal areas and are bottom dwellers that sting when stepped on. Their five to seven envenoming dorsal spines can penetrate leather boots, producing pain severity similar to stonefish injuries. Wounds may eventually necrose.
TREATMENT OF VENOMOUS FISH AND STINGRAY INJURIES
Irrigate the wound immediately, and remove any visible pieces of the spine or integumentary sheath. Control bleeding and immerse in hot water as soon as possible (Table 213­3). During the hot water soak, the wound can be explored and foreign material removed. Provide oral or parenteral analgesics as needed. The wound can also be infiltrated with lidocainewithout epinephrine, or a regional nerve block can be applied to help control pain.
TABLE 213­3
Early Treatment of Marine Envenomations
Organism Detoxification Further Treatment
Penetrating Envenomations
Catfish, lionfish, scorpionfish, stingray Hot water Usual wound care†; irrigate with seawater or normal saline (NS) immersion*, topical
Observe for development of systemic symptoms lidocaine
Assess for deep penetration from stingray spines; consider surgical consultation
Stonefish, weeverfish Hot water Usual wound care†; irrigate with seawater or NS immersion*, topical
Stonefish antivenom for severe systemic reaction (CSL Ltd., lidocaine
Melbourne, Australia); be prepared to treat anaphylaxis
Sea snake — Pressure immobilization
Polyvalent sea snake antivenom (CSL Ltd., Melbourne,
Australia) for systemic reaction; be prepared to treat anaphylaxis
Supportive care; observe for  h for myotoxicity and neurotoxicity; may need intensive care unit (ICU) care
Blue­ringed octopus — Pressure immobilization; flaccid paralysis and respiratory failure can develop in minutes
Provide respiratory support and ICU care
Cone snail Consider hot water Pressure immobilization; observe for paralysis and respiratory immersion* failure; supportive care
Sea urchin and starfish Hot water Explore wound and remove any spines, tufts, or pincers immersion*, topical lidocaine
Fireworms Topical 5% acetic Consider topical corticosteroids acid (vinegar) Remove bristles
Nonpenetrating Envenomations
Fire coral, hydroids Irrigate with Topical corticosteroids for itching seawater or saline
Portuguese man­of­war, bluebottle jellyfish Irrigate with Topical corticosteroids for itching seawater or saline Observe for development of systemic symptoms
Remove tentacles Supportive care
‡ and nematocysts
Hot water immersion* Topical lidocaine
Box jellyfish (Indo­Pacific Chironex species, Carybdeaalata Remove tentacles Topical corticosteroids for itching
[Hawaiian box jellyfish] and Australian Carukia species) ‡ Observe for development of systemic symptoms and nematocysts
Supportive care
Topical 5% acetic acid (vinegar)§
Topical lidocaine
Consider hot water immersion* Irukandji syndrome (Australian Carukia species) Remove tentacles Administer Chironex antivenom; be prepared for anaphylaxis
‡ Magnesium for cardiac arrest and nematocysts
Parenteral opioids for pain
Hot water immersion* *Hot water immersion = 111°F (43.3°C) to 114°F (45.6°C) water until pain is relieved.
†Usual wound care = Irrigate, explore, debride, consider antibiotics and analgesics, update tetanus immunization, elevate extremity.
‡
Remove tentacles and nematocysts = scrape, sticky tape, seawater or saline irrigation.
§Controversial; depends on species. Treatment of life­threatening Carybdea species stings is recommended.
Once pain is controlled, cleanse the wound using an aseptic technique, reexplore and remove foreign material, and debride necrotic tissue. Obtain soft tissue imaging when possible to visualize retained foreign material.
The conclusions of the few study series involving venomous fish stings and the experience of aquarium workers are that most injuries are minor and
 do not require antibiotics. Although some authors routinely recommend antibiotic prophylaxis, the majority do not unless the wound is large or there is considerable foreign material. This situation is more likely with stingray wounds, which have the greatest potential to cause necrosis and infection. Prevention of infection by careful cleaning of the wound and debridement, if required, is more important. An antivenom exists for stonefish envenomation (CSL Ltd., Melbourne, Australia) and should be used in cases of severe systemic reactions to stonefish and possibly other
,28 venomous fish. Although it is registered for IM and IV administration, IV is more likely to be effective, based on experience with other antivenoms.
Like other marine antivenoms, stonefish antivenom is prepared from horse serum, so be prepared to treat anaphylaxis and serum sickness.
SEA SNAKES
There are numerous species of sea snakes that are closely related to terrestrial elapids, all of which are venomous. They occur in the tropical warm temperate Indian and Pacific Oceans (including Hawaiian waters). None are found in the Atlantic Ocean, the Carribbean, or North American coastal waters. Probably the most important species medically is the beaked sea snake (Enhydrina schistosa), which has caused fatalities in Southeast Asia.
Sea snakes can be distinguished from land snakes by their flat tails and valve­like nostril flaps, and from eels by the presence of scales and the absence of gills and fins. The venom apparatus consists of two to four short, hollow maxillary fangs, and a pair of associated venom glands. About 20% of bites cause significant envenomation, and up to 40% of these are potentially fatal without treatment. The venom of sea snakes contains neurotoxins and myotoxins; one tends to dominate the clinical features. However, there are no toxins that affect coagulation.
Bites are typically painless and may go unnoticed. Symptoms typically become apparent  minutes to  hours after the bite. The first complaint is usually related to myotoxicity, with severe myalgia and nonspecific muscle weakness. Other symptoms include nausea, vomiting, and malaise. The muscle pain may become so severe that movement is limited, which is typified by trismus that develops in the jaw. Immobility secondary to pain should be distinguished from weakness or paralysis caused by neurotoxicity. Rhabdomyolysis and secondary renal failure develop in more severe cases, which may be complicated by hyperkalemia. Neurotoxicity without myotoxicity has been reported in some sea snake envenomations, with ascending flaccid or spastic paralysis accompanied by ophthalmoplegia, ptosis, facial paralysis, and pupillary changes. Death is most commonly a result of respiratory failure.
Diagnosis of a sea snake bite is based on the combination of snake identification and the presence of a puncture bite wound that was initially painless and occurred in a marine setting. Suspect envenomation if severe myalgia develops. The presence of myoglobinuria and an elevated creatine kinase level is also typical, indicating rhabdomyolysis. Neurotoxic symptoms are rapid in onset and usually appear within  to  hours. If no symptoms develop by  to  hours, envenomation is unlikely to have occurred.

First aid treatment is pressure immobilization of the affected limb. Elastic bandages are preferred. Administer polyvalent sea snake antivenom

(CSL Ltd., Melbourne, Australia) for systemic envenomation. The antivenom is made from horse serum, so be prepared to treat anaphylaxis and delayed serum sickness. Intensive supportive care and monitoring of renal, metabolic, and respiratory functions are critical.
OCTOPUS INJURIES
Injuries from the octopus or squid are unusual. All octopuses have venom, but the only dangerous octopus is the blue­ringed octopus. The venom tetrodotoxin, introduced by a bite, causes respiratory arrest within minutes. Treatment is supportive. Pressure immobilization at the bite area is the recommended first aid treatment.
The bite of the Australian blue­ringed octopus (Hapalochlaena species) has caused at least two deaths. The saliva of the octopus contains tetrodotoxin
,32 and produces effects clinically identical to those of tetrodotoxin poisoning seen most commonly with puffer fish ingestion. Octopus bites typically occur on the upper extremity, almost always when the animal is picked up (Figure 213­2). The bite causes small, painless puncture marks, and many go unnoticed. In most cases, no symptoms develop or only mild local numbness and paresthesia occur. In more severe envenomations, vomiting and
 progressive flaccid paralysis with eventual respiratory failure may begin within  minutes of envenomation. Wrap the limb with a lymphatic occlusive bandage to provide pressure immobilization until definitive care is reached. Treatment is supportive, with mechanical ventilation as required, and full recovery usual occurs over  to  days. No antivenom or antidote is available.
FIGURE 213­2. This acute octopus bite (A) was initially treated with ciprofloxacin, but persisted with a scab (B) and regional adenopathy for several months. After treatment with doxycycline, adenopathy resolved, but a chronic nonhealing ulcer remained. [Photo contributed by Steven Whelpley, MD.]
CONE SNAIL INJURIES
Cone snails have intricate shell patterns, making them attractive to handle. Cone snails are predators that feed by injecting a potent mixture of neurotoxins using detachable, dart­like radicular teeth. Stings by cone snails are rare. Most stings occur after prolonged contact with the shell or when breaking the shell. With significant envenomation, local pain is followed immediately by local numbness, which quickly spreads from the extremity to the trunk and then to the head and neck region. Partial paralysis develops within  minutes, progressing to complete voluntary muscle paralysis and
 respiratory failure. Mortality following Conus geographus envenomation may be as high as 65%. Less severe envenomations cause muscle pain, partial paralysis, or ataxia, or in mild cases only local effects. Treatment is pressure immobilization with a lymphatic­occlusive bandage until definitive care is reached.
SEA URCHINS AND STARFISH
Sea urchins with blunt tips generally have solid nontoxic spines, whereas those with sharp spines tend to have venom in the spine. Injury from the
 spines causes localized pain, which is exacerbated by pressure, even if there are no retained spines in the wound (Figure 213­3). If a spine enters a joint, it may cause severe synovitis. Wounds from black sea urchin spines may leave a black discoloration of the skin. Contact with venomous spines causes immediate, intense burning pain, with erythema, swelling, and often bleeding of the skin surrounding the puncture sites. The acute pain usually subsides over hours. Secondary infection and granuloma formation from remaining spine fragments are well­described delayed effects.
Systemic features have been reported rarely, often when multiple spines are involved, but may be due to severe pain.
FIGURE 213­3. Sea urchin sting in the foot showing the entry sites. [Used with permission of Vidal Haddad Jr., MD, PhD.]
Some starfish have surface spines, tufts, or pincers. The crown­of­thorns starfish (Acanthaster planci) can be found on most reefs in the Indo­Pacific
 region and has caused outbreaks of envenomation in Japan and Australia. Crown­of­thorn starfish are covered with sharp, rigid spines that can passively deliver a variety of substances when they penetrate skin. Introduced substances can include venom (produced in special glandular tissue), mucus, bacteria, or dermal tissue. Injury by the spines produces  to  hours of severe burning pain that is often greater than expected for the degree of mechanical injury. Other local effects include bleeding, erythema, and mild edema. In more severe cases, particularly with multiple punctures, the wound may become dusky or discolored. Pruritus and persisting edema can occur, perhaps as a result of allergy. Systemic effects are uncommon but
,6 may include paresthesias, nausea, vomiting, lymphadenopathy, and muscular paralysis.
Treatment is immediate immersion in hot water to tolerance (45°C [113°F]) for  to  minutes or until pain is relieved. Topical or locally injected lidocaine can provide additional pain relief. Give analgesics; IV analgesia is often needed. Remove retained spines or tufts as well as possible, without causing more tissue injury. Soft tissue radiographs, US, or MRI may be helpful in locating retained spines. US may be particularly helpful in identifying
 radiolucent fragments of sea urchin spines. Arrange follow­up, because further surgical removal of spines may be required if there are ongoing symptoms. Spines in joints require immediate orthopedic consultation.
FIREWORMS OR BRISTLEWORMS
Fireworms, or bristleworms, are segmented worms covered with cactus­like bristles that can penetrate the skin. These bristles easily detach in the skin and can be difficult to remove. Envenomation causes intense inflammation with a burning sensation and erythema. Untreated, the pain generally resolves within a few hours, but erythema may last for  to  days. Bristles should be removed with forceps or adhesive tape. Vinegar (5%) may be applied topically. The inflammatory response may require a course of corticosteroids.
HYDROIDS AND FIRE CORAL
Hydroids are colonies of tiny jellies attached to a feather­like or seaweed­like base. They are abundant on seaweed, reefs, pilings, floating docks, or lines. Coastal storms can break off feather hydroid branches and cause infestation of a local swimming area. Fire corals look like corals, are often mistaken for seaweed, and are small brush­like growths on rocks and coral itself. Contact with nematocysts or stinging threads results in an immediate sting after even a superficial brush contact, followed by itching pain, associated with the development of painful wheals and urticaria after  minutes.
The welts may last for up to a week but leave no permanent mark. With more extensive exposure, blistering and a hemorrhagic and zosteriform reaction can occur. Lesions crust over after a few days. Vinegar can inhibit nematocyst discharge. Pain relief can be provided with analgesics. Treat itching with topical steroids.
JELLYFISH
There are many types of jellyfish, but the most important groups affecting humans are the Portuguese man­of­war or bluebottle jellyfish, the box jellyfish, and those jellyfish causing Irukandji syndrome.

Jellyfish are characterized by their unique stinging nematocysts, which number in the thousands and are found mainly on the tentacles, but also in lesser numbers on the body or bell. The nematocyst contains a minute dose of venom, in some cases highly potent, and a harpoon­like mechanism. A physical or chemical stimulus triggers the rapid release of a hollow, sharply pointed, threadlike tube from the nematocyst, which penetrates the skin and delivers venom subcutaneously. There are a number of genera worldwide causing local and systemic reactions, all with similar toxic effects.
The clinical features of jellyfish envenomation vary in severity. The severity depends on the venom dose, the marine species, and the victim (age and size). Mild envenomation results in bothersome acute skin reactions, with immediate stinging pain and erythema or wheal formation at the site.
Lesions usually resolve spontaneously over days to a couple of weeks, with occasional postinflammatory hyperpigmentation.
Treatment of jellyfish stings is not well studied. A treatment helpful for one species may worsen effects from another species. Irrigation with seawater to remove nematocysts and hot water immersion and application of topical lidocaine appear to be the most universally beneficial treatments. Do not irrigate with freshwater because the hypotonic solution is thought to stimulate nematocyst discharge. Other applications, such as sodium bicarbonate or vinegar, may worsen stinging from some species.
PORTUGUESE MAN­OF­WAR AND BLUEBOTTLE JELLYFISH
This group of jellyfish (Physalia species) has a large gas­filled float, which suspends multiple tentacles. The nematocysts are found on the tentacles but not on the float. Physalia species are the most widely distributed jellyfish and are responsible for thousands of human envenomations in Florida, parts
,2,36 of Asia and Africa, Australia, and Western Europe. All species occur in swarms in shallow water and usually cause stings in the surf or are washed up on the shore. Nematocysts from fractured tentacles may remain active for months.
The Portuguese man­of­war is technically a siphonophore (colony of specialized organisms) rather than a true jellyfish. However, from a medical perspective this marine hydrozoan can be considered with the jellyfish. The Portuguese man­of­war has multiple tentacles that can be as long as  m
(Figure 213­4). The bluebottle jellyfish is smaller and single­tentacled and found commonly in Australia and Hawaii.
FIGURE 213­4. Portuguese man­of­war. This specimen was discovered washed up on a Florida beach. Tentacles are capable of stinging for days after washing ashore.
Application of vinegar (4% to 5% acetic acid) has been found to trigger nematocyst discharge in this species. [Photo contributed by John J. Devlin, MD.]
Stings from Physalia species cause immediate, intense pain that often fades over an hour but may persist for many hours, particularly with larger
 specimens. The sting causes a characteristic linear erythematous eruption, classically referred to as a “string of pearls” pattern. Respiratory distress
,37 and death have been reported following Physalia envenomation, and delayed effects have been reported in rare instances.
Treatment is to first wash the area with seawater and then immerse in hot water, as the venom is heat labile. Vinegar is not recommended for Physalia
 stings. Remove tentacles and nematocysts by scraping the skin with a sharp object (e.g., razor or credit card) or by applying adhesive tape. If adhesive tape is used, the adherent nematocysts can later be identified.
There is no specific antidote for Physalia envenomation, and care is supportive.
BOX JELLYFISH AND IRUKANDJI SYNDROME
The box jellyfish is the most dangerous jellyfish and includes two important members: the Indo­Pacific box jellyfish (Chironex fleckeri) and the
,40
Australian jellyfish (Carukia barnesi) that causes Irukandji syndrome. Box jellyfish are also found in the Philippines, Japan, and the U.S. Atlantic coast. The Hawaiian box jellyfish (Carybdea alata) causes numerous stings to beachgoers in Hawaii, although no deaths have been confirmed from this
 organism.

The Indo­Pacific box jellyfish (Chironex) has been described as the world’s most venomous animal. It has caused over  deaths in the past century.
The exact mechanism of toxicity and toxins involved in death—which can occur rapidly, within  to  minutes—remains unclear, but a primary
 ,44 cardiotoxic role is likely. Severe reactions or death can occur following skin contact with tentacles, especially in children. However, the vast
 majority of stings are mild to moderate, consisting of skin welts and immediate, sometimes severe pain. The toxic skin reaction may be quite intense, with rapid formation of wheals, vesicles, and a darkened reddish brown or purple whip­like flare pattern with stripes  to  mm wide. With more severe stings, blistering occurs, and superficial necrosis develops after  to  hours. Severe box jellyfish stings cause a pathognomonic crosshatched pattern, classically referred to as a “frosted ladder” pattern (Figure 213­5). Following the acute toxic reaction, a delayed hypersensitivity reaction
,45 occurs in approximately 60% of cases, with papular urticaria at the sting sites.
FIGURE 213­5. Box jellyfish sting. This 24­year­old woman was snorkeling off of Koh Tao, Thailand, when she was stung by a box jellyfish  minutes prior to this photograph being taken. She presented with severe extremity pain and chest tightness. [Photo contributed by Sittidet Toonpirom, MD, and Rittirak
Othong, MD.]

The Australian jellyfish (Carukia barnesi) causes the Irukandji syndrome. The sting initially causes mild local effects with localized pain and erythema. Approximately  to  minutes later, severe generalized pain in the abdomen, back, chest, head, and limbs develops. The pain is usually associated with systemic signs of catecholamine excess, including tachycardia, hypertension, sweating, piloerection, and agitation. In severe cases,
,44 cardiogenic shock with pulmonary edema and serum troponin elevation occur.
Treatment consists of deactivation of attached nematocysts, tentacle removal, reversal of venom effects if possible, and symptomatic and pain relief.
All victims with systemic signs or symptoms should be observed for ongoing envenomation or delayed reactions (Table 213­3).
Irrigate with seawater or normal saline to remove and deactivate undischarged nematocysts. Remaining visible tentacles can then be removed. Do not irrigate with freshwater because the hypotonic solution is thought to stimulate nematocyst discharge. Best methods for removal are scraping the skin
 with a sharp object (e.g., razor or credit card) or application of adhesive tape. If adhesive tape is used, the adherent nematocysts can later be
 identified. Treat with hot water immersion (111°F [43.3°C] to 114°F [45.6°C]) and apply topical lidocaine.
,47
Effective topical decontaminants appear to be species specific. Because the species is often unknown, the geographic location of the envenomation guides decontamination. In Indo­Pacific waters, particularly those surrounding Australia, nematocyst deactivation therapy with
,48
5% acetic acid (vinegar) is recommended, and 5% acetic acid is the first­line management recommendation by the Australian Resuscitation
,49,50
Council.
Treatment for severe Chironex envenomation consists of standard resuscitative measures and administration of sheep­derived antivenom specific for

C. fleckeri (CSL Ltd., Melbourne, Australia). Be prepared to treat anaphylaxis. Fatalities despite antivenom administration may be related to the
 rapidity of onset of cardiovascular collapse after Chironex envenomation. Therefore, antivenom should be administered IV as early as possible. The initial dose may be repeated if there is no clinical response, and some clinicians recommend three or more doses in severe envenomations associated
 with cardiovascular collapse. Magnesium improves outcome in animal studies and should be considered in refractory cases of severe Chironex
,45 envenomation with cardiac arrest.
Severe generalized pain in Irukandji syndrome requires titrated IV opioid analgesia, often with large and repeat doses. Magnesium bolus and infusion
,51 have been used for treatment of the pain and hypertension associated with Irukandji syndrome. However, adverse effects due to
,52 hypermagnesemia have been reported, and the treatment has not been as effective as originally suggested. A recent systematic review of
 magnesium sulfate administration in the management of Irukandji syndrome found no clear evidence of benefit, and its use is not recommended.
Obtain an ECG and troponin testing on admission; echocardiography is useful in patients with myocardial involvement. Manage pulmonary edema with oxygen supplementation, positive­pressure ventilation, and inotropes.
Controversies in Jellyfish Envenomation Management
The application of topical commercial vinegar (4% to 5% acetic acid solution) in the treatment of jellyfish and stinging hydroid envenomation is
,47 controversial. A 2012 systematic review and a 2013 Cochrane review both found no benefit from the intervention. Further, an in vivo study
 observed increased jellyfish nematocyst discharge after application of vinegar, particularly from Physalis physalis tentacles. Similarly, in a randomized controlled trial of multiple topical treatments for Chrysaora chinesis stings in  human subjects, application of 5% acetic acid failed to
 56­ improve pain as compared to placebo. This appears to contradict field observations and recommendations by authorities in wilderness medicine.

It is possible that nematocysts from different jellyfish species respond differently to vinegar, and the intervention is a subject of ongoing scientific investigation. However, at this time, topical application of vinegar for jellyfish envenomation cannot be universally recommended as standard care. For
 jellyfish stings, “hot water and lidocaine appear more universally beneficial in improving pain symptoms and are preferentially recommended.” The
,41,47 venoms are heat labile, and heat reduces toxicity in most jellyfish envenomations. Chironex stings are the exception. Recent evidence suggests
 hot water immersion is “no more effective than icepacks for reducing the acute pain of box jellyfish stings.” In waters surrounding the United States,
,60 application of 5% acetic acid solutions to tentacles from Chrysaora species appears to increase nematocyst discharge. For Chrysaora (e.g., sea nettle) or Cyanea (e.g., lion’s mane) jellyfish, a slurry of baking soda (sodium bicarbonate) is thought to be effective.


