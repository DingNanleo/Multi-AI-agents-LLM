University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 20: Pharmacology of Vasopressors and Inotropes
Sara Haney Shields; Rachel M. Holland
INTRODUCTION
Vasopressors are potent pharmacologic agents that are used to increase blood pressure and mean arterial pressure by vasoconstriction, thus increasing systemic vascular resistance. They should be reserved for cases of persistent hypotension and tissue hypoperfusion after volume resuscitation has failed. Most vasopressors have proarrhythmic potential and exert effects on both the heart and vasculature. Some agents also have inotropic properties and are used to improve cardiac output, particularly in patients with left ventricular pump failure or cardiogenic shock. In patients
 2­8 with septic shock, the cumulative vasopressor dose to maintain blood pressure is a predictor for early death. Table 20­1 provides a summary of vasopressors and inotropic agents.
TABLE 20­1
Summary of Common Vasopressors, Doses, Effects, and Contraindications
Cardiovascular
Medication Dosing Contraindications
Effects
Dopamine Hemodynamic support ↑ HR, BP, CO, SVR Hypersensitivity to sulfites
IV infusion: 2–20 micrograms/kg/min; titrate by increments (dose Pheochromocytoma of 5–10 micrograms/kg/min to desired response (maximum, dependent) Uncorrected tachyarrhythmias
 micrograms/kg/min) VF
Epinephrine Asystole/pulseless arrest, pulseless VT/VF ↑ HR, BP, MAP, No absolute contraindications in a life­threatening
 milligram IV/IO every 3–5 min until ROSC; 2–2.5 milligrams SV, SVR, CO situation
ET every 3–5 min until IV/IO access established or ROSC
(dilute in 5–10 mL NS or SW)
Bradycardia
IV infusion: 2–10 micrograms/min; titrate to desired response
Septic shock
IV infusion (initial): .05–2 micrograms/kg/min; titrate every
10­15 min by increments of .02–0.05 microgram/kg/min to desired MAP
Hypotension after intubation or sedation
5–20 micrograms/bolus dose over 20–30 s every 2–5 min as needed
Anaphylaxis .3–0.5 milligram IM by epinephrine autoinjector or equivalent; IV infusion, mix  milligram in 500 mL D5W and infuse at .5 mL/min and titrate dose as needed
Norepinephrine Hypotension/shock ↑ BP, MAP, SVR, Hypotension from hypovolemia except as an
IV infusion (initial): 8–12 micrograms/min; titrate to desired CO emergency measure to maintain coronary and response; usual maintenance range: 2–4 micrograms/min cerebral perfusion until volume can be replaced

Post–cardiac arrest care
Chapter 20: Pharmacology of Vasopressors and Inotropes, Sara Haney Shields; Rachel M. Holland 
©2025 McGraw Hill. AllI nRitiigahl:t 0s. 1R–e0.s5e mrvicerdog. r a Tme/rkmg/sm oinf ;U tistrea t * e Ptor idveascirye dP roelsicpyo n * s Ne otice * Accessibility
Sepsis/septic shock* Start .02–0.04 microgram/kg/min; typical range, .02–1.0 microgram/kg/min; titrate every 5–10 min by .02–0.04 microgram/kg/min; wean at rate .01–0.03 microgram/kg/min
Phenylephrine Hypotension/shock ↑ BP, MAP, SVR Severe hypertension
IV infusion (initial): 100–180 micrograms/min or .5 VT microgram/kg/min; titrate to desired response
Hypotension after intubation or sedation
IV bolus: 40–100 micrograms/bolus dose over 20–30 s every
2–5 min as needed
Vasopressin Septic shock (SSC recommendations) ↑ BP, SVR Hypersensitivity to vasopressin or chlorobutanol†
≤0.03 unit/min with concomitant norepinephrine to raise
MAP to target or to decrease norepinephrine dose
Angiotensin II Septic shock (not first line) ↑ BP, MAP No absolute contraindications; manufacturer
Initial dose 10–20 nanograms/kg/min, titrate in increments warning: because of the risk of thromboembolic of 5–10 nanograms/kg/min every  min; maximum initial events, angiotensin II should be used in dose,  nanograms/kg/min during initial  h combination with venous thromboembolism
After improvement in blood pressure, down­titrate to  prophylaxis nanograms/kg/min every 5–15 min to minimum effective dose; maximum maintenance dose (after first  h),  nanograms/kg/min
Dobutamine Decreased CO ↑ BP, CO Hypertrophic cardiomyopathy with outflow tract
IV infusion (initial): 1–3 micrograms/kg/min; maintenance: 2– ↔/↑ HR obstruction
 micrograms/kg/min; titrate to desired response ↔ MAP
ACLS (immediately after cardiac arrest) ↓ SVR
IV infusion (initial): 5–10 micrograms/kg/min; titrate to desired response
Milrinone Congestive heart failure, acute bridge to definitive ↑ CO Hypersensitivity to milrinone treatment ↔/↑ HR
Loading dose (optional):  micrograms/kg over  min ↓ SVR, BP
Maintenance (continuous IV infusion): .375–0.75 ↔/↓ MAP
‡ microgram/kg/min ; titrate to desired response
Abbreviations: ACLS = advanced cardiovascular life support; BP = blood pressure; CO = cardiac output; D5W = dextrose 5% in water; ET = endotracheal; HR = heart rate; HTN = hypertension; MAP = mean arterial pressure; NS = .9% normal saline; ROSC = return of spontaneous circulation; SSC = Surviving Sepsis Campaign; SV = stroke volume; SVR = systemic vascular resistance; SW = sterile water; VF = ventricular fibrillation; VT = ventricular tachycardia.
*There is no defined maximum norepinephrine dose for refractory shock, but doses above .5­1.0 micrograms/kg/min are considered high, and may be associated with worse outcomes. SSC recommends adding vasopressin to reduce the dose of norepinephrine.
†Not available in the United States.
‡
Dose adjustment in renal impairment.
ADMINISTRATION RECOMMENDATIONS AND COMPLICATIONS
,10
In general, vasopressors should be given via a central venous catheter to reduce the incidence of complications. Most complications resulting in
 tissue loss due to necrosis result from vasopressor infusions below the antecubital or popliteal sites. Short­term use, using an antecubital or more
 proximal site, has a complication rate of 2%. Treatment with phentolamine injection locally using a fine needle and nitroglycerin ointment topically
 can reduce tissue loss.
BOLUS­DOSE ADMINISTRATION OF VASOPRESSORS
Bolus­dose vasopressors, also called push­dose pressors, have been used by anesthesiologists for the treatment of sudden hypotension during surgical procedures for many years. Only recently has bolus­dose vasopressor use for ED patients received attention in the emergency medicine
,13­18 ,15­17 literature. Authors urged caution because safety is questioned. Phenylephrine is the most commonly used vasopressor in the setting of
 acute onset of hypotension; epinephrine is used when the patient could benefit from an increase in pulse rate as well as cardiac output. Dose errors
,15­17 are common, highlighting the importance of careful dose calculations (Table 20­1). A systems approach to standardize vasopressor
,16 concentration across an institution is recommended to prevent dose errors. Assistance from an on­site pharmacist to prepare and clearly label
,15,16 drug concentration on a bolus syringe or IV bag is recommended if available.
VASOPRESSORS
DOPAMINE
Actions
Dopamine is an endogenous catecholamine and a metabolic precursor of norepinephrine and epinephrine that acts on dopaminergic α ­, β ­, and β ­
   receptors in a dose­dependent fashion. At intermediate doses (5 to  micrograms/kg/min), dopamine increases renal blood flow, heart rate, cardiac contractility, and cardiac output. At high doses (>10 micrograms/kg/min), the α­adrenergic effects of dopamine dominate, leading to vasoconstriction and increased blood pressure. Low­dose (1 to  micrograms/kg/min) dopamine is no longer recommended for renal protection due to lack of patient
 outcome evidence.
Pharmacokinetics

See Table 20­2. TABLE 20­2
Dopamine Pharmacokinetics
Half­ Onset/Duration of
Metabolism Excretion
Life Action
Renal, hepatic, plasma; 75% to inactive metabolites by monoamine oxidase (MAO) and 25% to Urine (as ∼2 min Onset: ≤5 min norepinephrine (active) metabolites) Duration: <10 min
Indications
Dopamine increases cardiac output, blood pressure, and peripheral perfusion and is indicated for reversing hemodynamically significant hypotension caused by myocardial infarction, trauma, heart failure, and renal failure, when fluid resuscitation is unsuccessful or inappropriate. Surviving Sepsis
Campaign guidelines no longer recommend dopamine as an initial vasopressor for septic shock, based on data showing lower short­term mortality
 and decreased incidence of tachyarrhythmias in patients receiving norepinephrine versus dopamine. Dopamine can be considered as an alternative vasopressor agent to norepinephrine only in highly selected patients (i.e., patients with low risk of tachyarrhythmias and absolute or relative
 bradycardia). Although not considered a first­line agent, dopamine can also be used for the treatment of symptomatic bradycardia that is
 unresponsive to atropine.
Dosing and Administration
See Table 20­1. Adverse Effects
Adverse effects include chest pain, hypotension (low doses), hypertension (high doses), ectopic beats, palpitations, nausea, vomiting, headache, tissue ischemia, and tachycardia.
EPINEPHRINE
Actions
Epinephrine, an endogenous catecholamine, is an α ­ and nonselective β­adrenergic agonist that increases systemic vascular resistance, heart rate,
 cardiac output, and blood pressure.
Pharmacokinetics
,6
See Table 20­3. TABLE 20­3
Epinephrine Pharmacokinetics
Half­ Onset/Duration of
Metabolism Excretion
Life Action
Hepatic, other tissues: rapidly inactivated and degraded by enzymes Urine (mostly as inactive <5 min Onset: 1–2 min
Hepatic: metabolized by monoamine oxidase and catechol­O­methyl metabolites) Duration: 2–10 min transferase
Indications
Epinephrine is indicated in the treatment of cardiac arrest and can also be used for symptomatic bradycardia unresponsive to atropine or transcutaneous pacing. Sepsis guidelines recommend epinephrine when an additional agent is needed to maintain adequate blood pressure in
 patients with severe sepsis or septic shock. It is an essential agent for the treatment of anaphylaxis.
Dosing and Administration
See Table 20­1 and Figure 20­1. Epinephrine concentration varies depending on the formulation, and dosing is described both as milligrams and as micrograms. Microgram doses are described primarily for IV infusions. Epinephrine is pre­prepared for cardiac arrest treatment (0.1 mg/mL,  mL in
1:10,000 dilution) because the 1:10,000 solution is specifically used for bolus IV administration. Epinephrine in vials or autoinjectors is typically supplied as  mg/mL in the 1:1000 dilution specifically for IM injection, with doses of .15 milligram for children and .3 milligram for adults. To avoid errors in dosing, be familiar with the formulations of epinephrine used in your ED.
FIGURE 20­1. Examples of epinephrine (adrenalin) formulations. A. Epinephrine for cardiac arrest, 1:10,000. B. Epinephrine in vials, 1:1000. C. Epinephrine autoinjectors. Dosing may be described in micrograms or milligrams.
Adverse Effects
Adverse effects include angina, palpitations, arrhythmias, hypertension, tachycardia, nausea, vomiting, headache, anxiety, and pulmonary edema.
NOREPINEPHRINE
Actions
Norepinephrine is an endogenous catecholamine that stimulates α­adrenergic receptors, resulting in peripheral vasoconstriction and increased blood pressure. Norepinephrine also activates β­adrenergic receptors (β > β ), leading to inotropic stimulation of the heart and coronary artery
  vasodilation.
Pharmacokinetics
,6
See Table 20­4. TABLE 20­4
Norepinephrine Pharmacokinetics
Metabolism Excretion Half­Life Onset/Duration of Action
Via monoamine oxidase and catechol­O­methyl transferase Urine (as inactive metabolites) 1–2 min Onset: very rapid
Duration: 1–2 min
Indications
Norepinephrine is indicated for the treatment of acute hypotension and shock. It is recommended as the initial vasopressor of choice for the treatment
 of severe sepsis and septic shock refractory to adequate fluid resuscitation based on the sepsis guidelines.
Dosing and Administration
See Table 20­1. Adverse Effects
Adverse effects include bradycardia, arrhythmias, peripheral ischemia, hypertension, nausea, vomiting, headache, anxiety, and cardiac arrest.
PHENYLEPHRINE
Actions
Phenylephrine is a selective α ­adrenergic agonist that increases systemic vascular resistance and elevates systolic and diastolic blood pressure
 through systemic arterial vasoconstriction. Phenylephrine has no direct effects on heart rate; however, reflex bradycardia and reduced cardiac output
,6 may occur, especially in patients with heart failure or cardiogenic shock.
Pharmacokinetics

See Table 20­5. TABLE 20­5
Phenylephrine Pharmacokinetics
Onset/Duration
Metabolism Excretion Half­Life of Action
IV: hepatic via oxidative deamination (50%); undergoes sulfation (8%) and some Urine (mostly as inactive Alpha phase: Onset: immediate glucuronidation; forms inactive metabolites metabolites) ∼5 min Duration: ∼15–20
Terminal min phase: 2–3 h
Indications
,6
Phenylephrine is indicated for the treatment of hypotension and vascular failure in shock, but is not recommended in the treatment of septic shock.
Dosing and Administration
See Table 20­1. The dose of phenylephrine in the setting of anesthesia or after intubation or rapid sequence induction is an IV bolus of  to 100
 micrograms per dose over  to  seconds every  to  minutes as needed.
Adverse Effects
Adverse effects include hypertension, low cardiac output, reflex bradycardia, and arrhythmias. Phenylephrine can also lead to renal, mesenteric, myocardial, and peripheral ischemia.
VASOPRESSIN
Actions
Vasopressin, an endogenous nonadrenergic vasopressor, stimulates V receptors in vascular smooth muscle, causing direct peripheral
 vasoconstriction, increases in systemic vascular resistance and blood pressure, and improved cerebral and cardiac perfusion. It does not exhibit inotropic or chronotropic effects on the heart and can cause a decrease in heart rate and cardiac output. Vasopressin also acts on V receptors in the
 kidneys, causing an antidiuretic effect.
Pharmacokinetics
,6
See Table 20­6. TABLE 20­6
Vasopressin Pharmacokinetics
Metabolism Excretion Half­Life Onset/Duration of Action
Hepatic, renal (inactive metabolites) Urine (∼6% as unchanged drug) 10–20 min Onset: rapid
Duration: ≤20 min
Indications

Vasopressin is no longer recommended in the advanced cardiovascular life support cardiac arrest algorithm. According to sepsis guidelines, vasopressin (up to .03 unit/min) may be added to norepinephrine either to raise mean arterial pressure to target or to decrease norepinephrine dose, but should not be used as the single initial vasopressor for treatment of sepsis­induced hypotension (weak recommendation; moderate quality
 evidence).
Dosing and Administration
See Table 20­1. Adverse Effects
Adverse effects include diaphoresis, nausea, vomiting, headache, urticaria, arrhythmias, mesenteric and peripheral ischemia, chest pain, myocardial infarction, bronchoconstriction, and cardiac arrest.
ANGIOTENSIN II
Actions
Angiotensin II is an octapeptide hormone component of the renin­angiotensin­aldosterone system that raises blood pressure by stimulating
,20  vasoconstriction and release of aldosterone. The U.S. Food and Drug Administration approved angiotensin II for use in the United States in 2017. ATHOS­3, a randomized trial, demonstrated that angiotensin II increases blood pressure when given to patients in septic or distributive shock who
 remain hypotensive despite fluid resuscitation and norepinephrine. Seventy percent of the angiotensin group compared to 23% of the placebo
 group reached target blood pressure over  hours; however, there was no mortality benefit.
Pharmacokinetics
,20
See Table 20­7. TABLE 20­7
Angiotensin II Pharmacokinetics
Half­
Metabolism Excretion Onset/Duration of Action
Life
Enzymes found in the plasma, red blood cells, kidney, liver, Not reported by <1 min Onset  min with infusion (median); duration up and lungs manufacturer to  h
Indications
Angiotension II is indicated for septic or other distributive shock when other drugs such as norepinephrine have failed to increase mean arterial
,20,21 pressure to target levels.
Dosing and Administration
See Table 20­1. Adverse Effects
Adverse effects include thromboembolic events (12.9%), thrombocytopenia (9.8%), tachycardia (8.6%), fungal infection (6.1%), delirium (5.5%), and
,22 acidosis (5.5%).
INOTROPES
DOBUTAMINE
Actions
Dobutamine is a synthetic dopamine analogue with potent inotropic and mild vasodilatory and chronotropic effects. It competitively binds and stimulates α­ and β­receptors (β > β > α ), resulting in increased contractility and heart rate with neutral effect or possible decrease in blood

 pressure.
Pharmacokinetics

See Table 20­8. TABLE 20­8
Dobutamine Pharmacokinetics
Metabolism Excretion Half­Life Onset of Action/Peak Effect
In tissues and hepatically to inactive metabolites Urine (as metabolites)  min Onset: 1–10 min
Peak: 10–20 min
Indications
Dobutamine is indicated for the short­term management of patients with acute cardiac decompensation, particularly in patients presenting with cardiogenic shock. Dobutamine can also be used for patients with persistent hypoperfusion despite adequate fluid resuscitation and the use of
 vasopressor agents.
Dosing and Administration
See Table 20­1. Adverse Effects
Adverse effects include hypertension, tachyarrhythmia, headache, angina, and hypokalemia.
MILRINONE
Actions
Milrinone is an inotrope with vasodilator properties (inodilator) that selectively inhibits the phosphodiesterase type III enzyme, resulting in the inhibition of cyclic adenosine monophosphate breakdown in myocardial and vascular smooth muscle cells. Increased cyclic adenosine monophosphate levels result in increased cardiac contractility, peripheral arterial and venous vasodilation, increased cardiac output, and reduced
 systemic vascular resistance.
Pharmacokinetics

See Table 20­9. TABLE 20­9
Milrinone Pharmacokinetics
Metabolism Excretion Half­Life Onset of Action
Hepatic (minor); majority is not metabolized Urine (83% as unchanged drug; 12% as metabolites) .3–2.4 h Onset: 5–15 min
Indications
Milrinone is used for the short­term treatment of acute decompensated heart failure. It is typically encountered in the ED when used as a short­term bridge to heart transplant or left ventricular assist device placement or as a continuous pump infusion for patients at home. In the ED, it is most
 commonly ordered in conjunction with cardiology or the heart failure service.
Dosing and Administration
See Table 20­1. Adverse Effects
Adverse effects include ventricular and supraventricular arrhythmias, hypotension, angina, and headache.


