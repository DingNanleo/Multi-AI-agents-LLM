## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 83: Bowel Obstruction
Timothy G. Price
INTRODUCTION
Intestinal obstruction is the inability of the intestinal tract to allow for regular passage of food and bowel contents secondary to mechanical obstruction or adynamic ileus.
Mechanical obstruction is caused by either intrinsic or extrinsic factors. It requires identification of the cause and definitive intervention in a relatively short period of time to minimize morbidity and mortality (Tables 83­1 and 83­2). Adynamic ileus (paralytic ileus) is usually self­limiting and does not require surgical intervention.
TABLE 83­1
Common Causes of Intestinal Obstruction
Duodenum Small Bowel Colon
Stenosis Adhesions Carcinoma
Foreign body (bezoars) Hernia Fecal impaction
Stricture Intussusception Ulcerative colitis
Superior mesenteric artery syndrome Lymphoma Volvulus
Stricture Diverticulitis (stricture, abscess)
Intussusception
Pseudo­obstruction
TABLE 83­2
Key Features of Ileus and Mechanical Bowel Obstruction
Ileus Bowel Obstruction
Pain Mild to moderate Moderate to severe
Location Diffuse May localize
Physical examination Mild distention, ± tenderness, decreased bowel sounds Mild distention, tenderness, high­pitched bowel sounds
Laboratory Possible dehydration Leukocytosis

Imaging May be normal Abnormal
Chapter 83: Bowel Obstruction, Timothy G. Price 
. Terms of Use * Privacy Policy * Notice * Accessibility
Treatment Observation, hydration Nasogastric tube, surgery
Both large and small intestines may be obstructed by various pathologic processes (Table 83­1). Extrinsic, intrinsic, or intraluminal processes precipitate mechanical obstruction. Differentiating small bowel obstruction from large bowel obstruction is important, because the incidence, clinical presentation, evaluation, and treatment vary depending on the anatomic site of obstruction. Intestinal pseudo­obstruction (Ogilvie’s syndrome) may
 mimic bowel obstruction.
PATHOPHYSIOLOGY
Normal bowel contains gas as well as gastric secretions and food. Intraluminal accumulation of gastric, biliary, and pancreatic secretions continues even if there is no oral intake. As obstruction develops, the bowel becomes congested and intestinal contents fail to be absorbed. Vomiting and decreased oral intake follow. The combination of decreased absorption, vomiting, and reduced intake leads to volume depletion with hemoconcentration and electrolyte imbalance and may lead to renal failure or shock.
Bowel distention often accompanies mechanical obstruction. Distention is due to the accumulation of fluids in the bowel lumen, an increase in intraluminal pressure with enhanced peristaltic contractions, and air swallowing. When intraluminal pressure exceeds capillary and venous pressure in the bowel wall, absorption and lymphatic drainage decrease, the bowel becomes ischemic, and septicemia and bowel necrosis can develop. Shock ensues rapidly. Mortality is high if bowel obstruction has progressed to this degree. This sequence of events may occur more rapidly in a closed­loop obstruction with no proximal escape for bowel contents. Examples of closed­loop obstruction include an incarcerated hernia and complete colon obstruction in the presence of a closed ileocecal valve.
SMALL BOWEL OBSTRUCTION
Small bowel obstruction accounts for most bowel obstructions. The most common cause of small bowel obstruction is adhesions after abdominal surgery. Although in most cases, several months to years have passed from the time of the previous surgery, small bowel obstruction may occur within the first few weeks after surgery. The second most common cause of small bowel obstruction is incarceration of a hernia. See Chapter , “Hernias,” for detailed description of types of hernias. In the elderly, adhesions and hernias are still common causes of small bowel obstruction.
,3
Bariatric surgery may be complicated by internal hernias after Roux­en­Y gastric bypass. Other causes of small bowel obstruction are much less common and generally are the result of intraluminal or intramural processes. Primary small bowel lesions include polyps, lymphoma, or adenocarcinoma. Hamartomatous polyps are common in Peutz­Jeghers syndrome; polyps occur in patients between the ages of  and  years and
 can cause obstruction. An unusual cause of intraluminal obstruction is gallstone ileus, in which a gallstone has eroded from the gallbladder through the bowel wall and causes obstruction at the ileocecal valve. Signs of gallstone ileus include bowel obstruction and pneumobilia. Lymphomas may be the leading point of intussusception and present as small bowel obstruction. Bezoars are most commonly composed of vegetable matter or pulp from persimmons. Patients who have undergone GI pyloroplasty or pyloric resection are most susceptible to intraluminal obstruction by bezoars.
Inflammatory bowel disease or its complications may obstruct the small bowel at various sites. Radiation enteritis is a possible cause of small bowel obstruction in patients who have undergone radiation therapy. Blunt abdominal trauma may cause a duodenal hematoma. This condition is seen in individuals restrained solely by a lap belt or as a result of striking the handlebar of a bicycle and may present as intra­abdominal pain and vomiting similar to other causes of small bowel obstruction.
Capsule endoscopy, used to visualize the entire small bowel, may be complicated by capsule retention, with literature­reported frequencies of 1% to

20%. Capsule retention can lead to obstruction and perforation, so patients with abdominal pain after capsule introduction should be carefully
 evaluated for these complications.
LARGE BOWEL OBSTRUCTION
Neoplasms are by far the most common cause of large bowel obstruction, especially in the elderly. However, incidence is rising in younger patients, even those <40 years old. Colonic obstruction is almost never caused by hernia or surgical adhesions and should prompt an evaluation for a neoplasm.
Diverticulitis may create significant mesenteric edema and secondary obstruction. Stricture formation may occur with chronic inflammation and scarring. Fecal impaction is a common problem in the elderly or debilitated and may present with symptoms of colonic obstruction.
The next most frequent cause of large bowel obstruction after cancer and diverticulitis is sigmoid volvulus. Elderly, bedridden, or psychiatric patients
 who are taking anticholinergic medication are most at risk for volvulus. Cecal volvulus has been reported in pregnant patients.
CLINICAL FEATURES
HISTORY
The site and nature of the obstruction and the preexisting condition of the patient will determine the clinical presentation. Although some
 generalizations are possible, there are no components of the history able to reliably predict small bowel obstruction. Abdominal pain is nearly universal. Pain generally is crampy and intermittent. Pain of mechanical small bowel obstruction is often episodic, lasting for a few minutes at a time, and may be periumbilical or diffuse. Pain tends to be less intense and more constant in adynamic ileus. Proximal obstruction usually causes vomiting.
Vomitus is usually bilious in proximal obstruction but is feculent in distal ileal or large bowel obstruction. The pain of large bowel obstruction is usually hypogastric.
Other features that are consistently present with obstruction of small bowel or colon include the inability to have a bowel movement or pass flatus.
“Constipation” is a common symptom of bowel obstruction. Partial bowel obstruction, however, is often associated with regular passage of stool and flatus. Additional risk factors are advanced age and anticholinergic or tricyclic antidepressant use, which depress bowel motility.
PHYSICAL EXAMINATION
Physical findings vary depending on the site, duration, and cause of obstruction. In small bowel obstruction, distention is the most reliable sign, and
 some distention is usually present early in the disease process. Abdominal tenderness may be minimal to severe and localized or diffuse. Peritonitis causes severe pain. The abdomen may be tympanitic to percussion. Mechanical obstruction produces active, high­pitched bowel sounds with occasional “rushes.” If obstruction has been present for several hours, peristaltic waves and bowel sounds may be diminished. Localized or rebound tenderness may be a sign of gangrenous or perforated bowel, which requires immediate surgical intervention. Patients with an adynamic ileus may have some abdominal distention associated with diminished or absent bowel sounds.
Careful examination coupled with radiographic investigation will often distinguish bowel obstruction from ileus. Emptiness of the left iliac fossa is a reliable sign of sigmoid volvulus. Organomegaly or masses may suggest a cause of the obstruction. The absence of stool or air in the rectal vault supports a diagnosis of obstruction and may aid in the diagnosis of bowel obstruction, but its presence does not eliminate a more proximal obstruction. A rectal examination may identify fecal impaction, rectal carcinoma, occult blood, or stricture. Consider a pelvic examination in women to
 identify gynecologic pathology causing obstruction. A vaginal pessary can cause colonic obstruction due to extrinsic compression of the colon. See
Table 83­2 for the key causes of ileus and mechanical bowel obstruction.
DIAGNOSIS
Consider bowel obstruction or ileus in any patient with abdominal pain and distention. Numerous other pathologic processes may also cause these symptoms, but additional evaluation guided by the history and physical examination may be necessary to confirm or rule out obstruction or ileus.
LABORATORY TESTING
Laboratory studies usually include a CBC and electrolyte levels, the results of which may vary widely depending on the duration and site of obstruction
 and the presence of bowel necrosis. A leukocytosis of >20,000/mm or left shift should make one suspect bowel gangrene, intra­abdominal abscess, or
 peritonitis. Extreme leukocytosis (>40,000/mm ) suggests mesenteric vascular occlusion. The serum amylase and lipase levels may be mildly elevated.
Increases in hematocrit, BUN, and creatinine are consistent with volume depletion and dehydration. Other indications of the severity of obstruction or secondary complications include increased urine specific gravity, ketonuria, elevated lactate levels, and metabolic acidosis. Small studies suggest that
 procalcitonin may predict bowel ischemia or failure of conservative management.
IMAGING
In the ED, flat and upright abdominal radiographs with an upright chest radiograph or a lateral decubitus view are of little utility. Plain films may reveal severe constipation, but be cautious of prematurely attributing symptoms to the presence of colonic stool, even large burdens. Perhaps the greatest value of the plain radiograph is in demonstrating free air secondary to rupture, and expediting surgical management. CT scan with IV contrast is the
 imaging method of choice in the ED(Figures 83­1and 83­2) and can identify the presence of an obstruction and often the location, severity, and cause.
In the presence of renal insufficiency or contrast allergy, non­contrast or oral contrast alone may provide sufficient diagnostic information. US can
10–12  identify small bowel obstruction, but management relies on further imaging with CT.
Small bowel obstruction is demonstrated by visualizing the valvulae conniventes, which cross the bowel lumen; by the presence of multiple air­fluid levels; and by dilation >  cm. Large bowel contains haustrae which do not cross the lumen. Large bowel obstruction is indicated by diameter >  cm.
Cecal or sigmoid volvulus may appear as a 'bird's beak' proximal and distal to the point of volvulus, where the colon has torsed. Sigmoid volvulus is often described as a 'coffee bean' shaped massive large bowel dilation.
FIGURE 83­1. Distended loops of small bowel are evident, and decompressed loops are visible in the right lower quadrant. Findings suggest the presence of a transition point. [Reproduced with permission from Block J, Jordanov MI, Stack LB, Thurman RJ (eds): The Atlas of Emergency Radiology. New York,
NY: McGraw­Hill Education, Inc.; 2013. Fig .38 Part B.]
FIGURE 83­2. CT scan of large bowel obstruction. Arrow indicates an apple core lesion; C shows dilated colon proximal to the stricture; and F shows fluid in the right paracolic gutter. [Reproduced from Butler KL, Harisinghani M (eds): Acute Care Surgery: Imaging Essentials for Rapid Diagnosis. New York, NY: McGraw­
Hill, Inc., 2015. Fig. 10­11.]
TREATMENT AND DISPOSITION
Many patients with small bowel obstruction may be successfully managed nonoperatively, whereas most patients with large bowel obstruction will
 require surgery. For colonic obstruction due to malignancy, tumor resection is the gold standard treatment. Self­expanding endoluminal stents can
 be used to relieve the obstruction and avoid emergent surgery. Use of a nasogastric tube is often unnecessary, but should be considered in the presence of severe distention and vomiting. Local surgeon preference continues to dictate local practice with regard to nasogastric tube use. Vigorous
IV fluid replacement is needed because of loss of absorptive capacity, decreased oral intake, and vomiting. Monitor adequacy of fluid resuscitation by the response of blood pressure, heart rate, and urine output. Closed­loop obstruction, bowel necrosis, and cecal volvulus are surgical emergencies. Sigmoid volvulus is first typically treated endoscopically. Administer preoperative broad­spectrum antibiotics in the ED. There are many possible regimens. Monotherapy could be tazobactam­piperacillin, .375 grams IV every  hours, ticarcillin­clavulanate, .1 grams IV every  hours, or a carbapenem.
If adynamic ileus is suspected or the diagnosis is uncertain, conservative inpatient management, including IV fluids and observation, generally is effective in allowing the bowel to resume normal activity and function. Discontinue medications that inhibit bowel mobility.
Admit patients with bowel obstruction to the hospital. Surgical consultation should generally be obtained in the ED or at the time of admission.
Patients with adynamic ileus should also be admitted for the treatment of the underlying cause and until resolution of the ileus.


