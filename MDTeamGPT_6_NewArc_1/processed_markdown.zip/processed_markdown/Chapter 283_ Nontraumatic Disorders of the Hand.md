## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 283: Nontraumatic Disorders of the Hand
Carl A. Germann
HAND INFECTIONS
PATHOPHYSIOLOGY

The most common pathogens causing hand infection are Staphylococcus aureus, Streptococcus species, and gram­negative species. Most routine infections involve a single gram­positive organism, whereas infections from IV drug use or mouth flora are usually polymicrobial. In most U.S. cities,
 community­associated methicillin­resistant S. aureus is the most common pathogen cultured from patients with skin and soft tissue infections in EDs,
3­8 including 47% to 78% of hand infections.

Injection drug users typically present with abscesses or deep space infections secondary to S. aureus and gram­negative organisms. These infections are most commonly caused by direct introduction, but hematogenous spread from bacterial endocarditis is a possibility (see Chapter 296, “Injection
Drug Users”).
Paronychia and felons are caused by minor trauma, chewing fingernails, or exposing minor injuries to saliva. Most of these infections are
,9 polymicrobial, including S. aureus (most common) and anaerobic bacteria.
Infections caused by animal bites reflect the oral flora of the involved species. Bites introduce a broad range of bacteria, including gram­positive, anaerobic, and gram­negative organisms. Common pathogens include streptococci, staphylococci, Haemophilus, Eikenella, Fusobacterium,
 peptostreptococci, Prevotella, and Porphyromonas species. Cat and dog bites harbor Pasteurella multocida, which typically produces an aggressive, rapidly spreading cellulitis that becomes suppurative. Hand infections are also discussed in Chapter , “Puncture Wounds and Bites.”
Patients with diabetes or acquired immunodeficiency syndrome have common bacterial infection or develop atypical infections, including those caused by Mycobacterium or Candida albicans. Those who are immunocompromised or asplenic are at risk for rapid progression and require prompt source control and antibiotics.
PRINCIPLES OF EVALUATION AND MANAGEMENT
Hand infections are most commonly introduced by an injury to the dermis. The infection initially may remain superficial and broader, termed cellulitis, or may be localized, as seen in a paronychia or felon. Left untreated, infections may spread along anatomic planes or to adjacent compartments in the hand. Deeper injuries may directly seed underlying structures, creating rapidly spreading infections such as those seen with closed fist injuries or cat bites.
Obtain a directed history to delineate a likely cause of the infection. The physical examination should note the anatomic limits of the infection. Look for skin, subcutaneous tissue, tendon, joint, or bone involvement. If deep structures of the hand are involved, emergently consult a hand specialist because treatment likely will involve inpatient care and operative drainage.
With the exception of superficial cellulitis, hand infections are managed using basic principles. First, incise and drain any abscess. Superficial and discrete infections, such as paronychia and felons, can be drained in the ED. Deep infections are better treated in the operating room by a hand surgeon. Second, immobilize and elevate the extremity. This will rest the hand, reduce inflammation, avoid secondary injury, and limit extension of the infection. Immobilize by applying a bulky hand dressing and splinting the hand in a position of function: the wrist at  to  degrees of extension, the metacarpophalangeal joints at  to  degrees of flexion, and the interphalangeal joints at  to  degrees of flexion (Figure 283­1). Elevate the hand on pillows or suspended using stockinette. Third, use broad­spectrum antibiotics initially targeting possible common and serious bacteria, altering only based on response and culture results (Table 283­1). Empiric treatment for these infections should be based on local antibiotic
 rCehsaisptatenrc 2e8 p3a:t Nteornnstr.a Fuomuarttich ,D ifi sthoerd peartsi eonf tt hise n Hota anddm, Citaterld A t.o G theerm hoasnpnital, ensure reexamination within  hours. 
. Terms of Use * Privacy Policy * Notice * Accessibility
FIGURE 283­1. Positioning the hand during immobilization. Top position is used when splints are applied in fractures or severe sprains. Bottom position is the position of function used when applying a soft bulky dressing.
TABLE 283­1
Initial Antibiotic Coverage for Common Hand Infections
Infection Initial Antimicrobial Agent(s) Likely Organisms Comments
Cellulitis MSSA coverage: Cephalexin, 500 milligrams PO four times per Staphylococcus aureus Clindamycin is an option, but day for 7–10 d,* or dicloxacillin, 500 milligrams PO four times (MRSA) increasing MRSA resistance to daily for 7–10 d, orclindamycin 300–450 milligrams PO four Streptococcus pyogenes clindamycin has been reported.
times daily for 7–10 d Consider local resistance patterns.
MRSA coverage†: Clindamycin, 300–450 milligrams PO four Consider vancomycin for injection drug abusers.
times daily for 7–10 d, or doxycycline, 100 milligrams PO twice a day for 7–10 d, orminocycline, 100 milligrams PO twice a day for 7–10 d, or TMP­SMX double strength, 1–2 tablets twice per day PO for 7–10 d
‡
For severe cellulitis : Vancomycin,  gram IV every  h, or linezolid, 600 milligrams IV every  h
Felon/paronychia TMP­SMX double strength, 1–2 tablets twice per day PO for 7– S. aureus (MRSA), S. Antibiotics indicated for infections
 d* pyogenes, anaerobes, with associated localized cellulitis;
Plus/minus cephalexin, 500 milligrams PO four times per day polymicrobial otherwise, drainage alone may be for 7–10 d,* or dicloxacillin, 500 milligrams PO four times daily sufficient. Culture recommended by for 7–10 d* hand surgeons.4­7
Consider addition of clindamycin or amoxicillin­clavulanate to
TMP­SMX (rather than cephalexin) if anaerobic bacteria are suspected
Flexor Ampicillin­sulbactam, .5–3 grams IV every  h, or cefoxitin,  S. aureus, streptococci, Parenteral antibiotics are indicated; tenosynovitis grams IV every  h, or piperacillin­tazobactam, .375 grams IV anaerobes, gram negatives consider ceftriaxone for suspected every  h Neisseria gonorrhoeae.
Plus: Vancomycin,  gram IV every  h, if MRSA is prevalent in community
Deep space Ampicillin­sulbactam, .5–3 grams IV every  h, or cefoxitin,  S. aureus, streptococci, Inpatient management.
infection grams IV every  h, or piperacillin­tazobactam, .375 grams IV anaerobes, gram negatives every  h
Plus: Vancomycin,  gram IV every  h, if MRSA is prevalent in community
Animal bites If no visible signs of infection: amoxicillin/clavulanate, 875/125 S. aureus, streptococci, All animal bite wounds should
(including milligrams PO twice daily for  d Eikenella corrodens receive prophylactic oral antibiotics.
human) For active signs of infection: ampicillin­sulbactam, .5–3 grams (human), Pasteurella
IV every  h, or cefoxitin,  grams IV every  h, or piperacillin­ multocida (cat), anaerobes, tazobactam, .375 grams every  h and gram­negative
For penicillin allergy, use clindamycin plus moxifloxacin or bacteria
TMP­SMX and metronidazole
Herpetic whitlow Acyclovir, 400 milligrams PO three times daily for  d Herpes simplex No surgical drainage is indicated.
Abbreviations: MRSA = methicillin­resistant Staphylococcus aureus; MSSA = methicillin­sensitive Staphylococcus aureus; TMP­SMX = trimethoprim­sulfamethoxazole.
*Although many sources recommend  to  days of therapy, the Infectious Diseases Society of America recommends  days of therapy if symptoms resolve and to continue therapy if symptoms persist.
†For patients whose cellulitis is associated with purulent drainage, penetrating trauma, evidence of MRSA infection elsewhere, nasal colonization with MRSA, injection drug use, or systemic inflammatory response syndrome, vancomycin or another antimicrobial active against both MRSA and streptococci is recommended.
‡
Severe infection: failed oral antibiotic treatment, systemic signs (sepsis), immunocompromised, or clinical signs of deeper infection.
CELLULITIS
Cellulitis is the most superficial of hand infections and is treated with oral antibiotics absent widespread involvement or systemic signs. Microbes most commonly breach the cutaneous surface through cracked skin, local trauma, or surgery. Diagnosis is made by documenting erythema, warmth, and edema in the affected portion of the hand without any involvement of deeper structures in the hand. Specifically, range of motion of the digits, hand, or wrist should not be painful, and palpation of the deeper structures of the hand should not produce any tenderness.
1­8
The most common offending organisms are S. aureus(predominantly methicillin­resistant) and Streptococcus pyogenes. Initial treatment is listed in Table 283­1. Cases of cellulitis without systemic signs of infection and a low suspicion for methicillin­resistant S. aureus should receive an
 antimicrobial agent that is active against streptococci. For patients with cellulitis associated with purulent drainage, penetrating trauma, evidence of methicillin­resistant S. aureus infection elsewhere, nasal colonization with methicillin­resistant S. aureus, injection drug use, or systemic inflammatory
 response syndrome, antimicrobial treatment effective against methicillin­resistant S. aureus and streptococci is recommended. Empiric monotherapy with trimethoprim­sulfamethoxazole or doxycycline is not recommended given the limited published efficacy data and concerns about
,11 effectiveness against streptococci. Given the increasing rates of methicillin­resistant S. aureus and difficulty distinguishing among the types of S.
aureus cellulitis, routine empiric treatment of methicillin­resistant S. aureus may be considered. In addition, the choice of antibiotic should be based on cultures (if available) and local resistance patterns. Consider empiric broad­spectrum antibiotics such as vancomycin and piperacillin­tazobactam
(Table 283­1) and admission for the immunocompromised, those with clinical toxicity, and those with rapidly spreading infections. Hospitalization is recommended if there is concern for a deeper or necrotizing infection, for patients with poor adherence to therapy, for infection in a severely immunocompromised patient, or if outpatient treatment is failing.
For all cases of cellulitis, immobilize the hand in a position of function, and make sure the patient keeps the hand elevated as much as possible.
Remove digit rings and give tetanus prophylaxis as needed. For those discharged, arrange reexamination within  hours.
FLEXOR TENOSYNOVITIS
Infectious flexor tenosynovitis is a surgical emergency. Failure to accurately diagnose and manage flexor tenosynovitis may result in adhesions, tendon vascular compromise and necrosis, or extension into adjoining deep spaces. This can lead to loss of function of the digit and eventually loss of
 function of the entire hand. The diagnosis is supported by the presence of the classic clinical signs described by Kanavel ; however, the absence of
Kanavel’s signs does not exclude the diagnosis of flexor tenosynovitis (Table 283­2).
TABLE 283­2
Kanavel’s Four Cardinal Signs of Flexor Tenosynovitis
Percussion tenderness Tenderness over the entire length of the flexor tendon sheath
Uniform swelling Symmetric finger swelling along the length of the tendon sheath
Intense pain Intense pain with passive extension
Flexion posture Flexed posture of the involved digit at rest to minimize pain
The infection usually is associated with penetrating trauma of the affected area  to  days prior to presentation, although the patient may be unaware of injury. Staphylococcus is the most common bacterium isolated; however, infections often harbor anaerobes or are polymicrobial. Suspect disseminated Neisseria gonorrhoeae in a patient with a recent history consistent with a sexually transmitted infection (see Chapter 153, “Sexually
Transmitted Infections”).
Initiate treatment with parenteral antibiotics because the infection can spread rapidly through deep fascial spaces (Table 283­1). The use of vancomycin is recommended because of the high prevalence of methicillin­resistant S. aureus in most communities. Send any spontaneous exudate for Gram stain and culture with sensitivities. An agent active against enteric gram­negative bacilli should be added for infection in immunocompromised patients or following open trauma to the muscles.
Immobilize and elevate the hand, and consult the hand surgeon in the ED. If the infection is identified early in its course, nonoperative therapy with parenteral antibiotics, immobilization, elevation, and reevaluation is a common path.
DEEP SPACE INFECTIONS

Deep space infections arise from penetrating inoculation, contiguous spread, and rarely, hematogenous seeding. S. aureus and Streptococcus
 species are the most common organisms isolated.
Compartments where infection may propagate and migrate include the thenar space, midpalmar space, radial bursa (sheath for the flexor pollicis longus), and ulna bursa (common flexor sheath); see Figure 268­9 in Chapter 268, “Injuries to the Hand and Digits.”
The volar aspect of the hand is covered by the tough and fixed tissues. The veins and lymphatics course through the softer tissues on the dorsum of the hand. Therefore, the dorsum of the hand often swells whenever there is an inflammatory or infectious process. For this reason, a deep space infection initially may be misdiagnosed as a cellulitis over the dorsum of the hand. An ideal examination includes palpation of the volar surface of the hand to elicit tenderness, induration, or fluctuance. Range of motion of the digits often produces marked pain for patients with deep space
,13 infection. Point­of­care US can assist in differentiating simple cellulitis from deep space infections.
Occasionally, infections will arise in the web space. These “collar button” abscesses present with pain and swelling of the web space causing separation of the affected digits. Examination reveals induration or fluctuance in the dorsal and/or volar web space, along with erythema, warmth, and tenderness.
Give parenteral antibiotics (Table 283­1) and analgesia, and immobilize and elevate the hand. Operative draining is often needed, requiring emergent hand surgeon consultation.
INFECTIONS FROM CLOSED FIST INJURIES
Human bite injuries to the hand may occur due to accidental trauma or purposeful biting, but are often the result of striking another individual’s teeth with a clenched fist (Figure 283­2). These injuries, termed “fight bite infections,” usually occur over the dorsal aspects of the third, fourth, and fifth metacarpophalangeal joints. Although these injuries may at first appear innocuous, morbidity can result from late presentation or inadequate initial management.
FIGURE 283­2. Clenched fist injury. The lacerations in this photograph were sustained from teeth during a fight. Note the subtle black ink stamp across the proximal metacarpals, possibly revealing a clue about the wound’s etiology. [Photo contributor: Lawrence B. Stack, MD. Reproduced with permission from
Knoop KJ, Stack LB, Storrow AB, Thurman RJ (eds): The Atlas of Emergency Medicine, 3rd ed. New York, NY: McGraw­Hill; 2010, Fig 11­30.]
Because of the force and the penetrating nature of the human incisor, closed fist infections tend to occur in multiple planes and spread rapidly to adjacent compartments. Skin, extensor tendons, joint space, bone, and surrounding deep spaces often are involved because the inoculum may traverse all these structures.
On examination, document the extent of the infection. Plain radiographs will detect fractures or foreign material including tooth fragments. The most common organisms reflect the natural flora of the mouth and include Streptococcus species, S. aureus, Eikenella corrodens, Fusobacterium,
Peptostreptococcus, and Candida species; polymicrobial sources are common. Early antimicrobial therapy against both aerobic and anaerobic bacteria is recommended for patients with animal bites to the hand (Table 283­1). If you suspect any deep space, palmar space, joint, or tendon infection, give broad­spectrum antibiotics and consult a hand surgeon for open debridement and irrigation in the operating room. Closing animal bite wounds of the hand may be associated with a high infection rate. Treat all infections with hand elevation and splinting in the position of function.
PARONYCHIA
Paronychia is an infection of the lateral nail fold or perionychium, occasionally extending to the cuticle or eponychium. It is usually caused by minor trauma such as nail­biting, manicures, or embedded lateral nails (“hangnails”). The infection often starts as a small area of induration that progresses to eponychial swelling, tenderness, erythema, and drainage. Most cases of paronychia contain both aerobic and anaerobic bacteria, with S. aureus and
Streptococcus species the most common aerobic bacteria cultured. Chronic paronychia (>6 weeks) can occur, particularly in patients who are
 immunocompromised, and may include usual pathogens or atypical bacteria and fungi such as with C. albicans.
Absent fluctuance, treat the paronychia with warm soaks, elevation, and antibiotics (Table 283­1). Suppuration leads to either fluctuance or identifiable pus requiring drainage. Recommendations for drainage include the use of a digital nerve block and avoidance of incision across the eponychial fold to prevent nail deformity (Figure 283­3). Minor infections can be treated with elevation of the perionychium or eponychium with a flat probe to encourage drainage. If drainage is successful, use warm soaks for days after care. In general, only nonviable tissue can be incised without provoking pain.
FIGURE 283­3. Paronychia. A. The eponychial fold is elevated using a flat probe or a #11 blade to allow the wound to drain. B. Alternatively, for more extensive infections, a #11 blade may be used to incise the area of greatest fluctuance directly into the eponychium. The wound may then be gently probed with a small clamp to ensure drainage.
More extensive infections that do not communicate directly with the nail fold require digital block and incision directly into the area of greatest fluctuance. Severe infections with pus beneath the nail require removal of a portion of the lateral or proximal nail to ensure adequate drainage. Rarely, a free­floating nail will be encountered on a bed of pus, necessitating removal of the entire nail.
Following incision and drainage, keep the hand elevated and immobilized. Warm soaks may be initiated to keep the wound open and clean. Routine antibiotics are not needed unless cellulitis, immunocompromise, or vascular insufficiency exists; when used, a 7­day course is common or until
 resolution of the infection. In complicated or drained cases, reassess the wound within  hours. Chronic paronychia (>6 weeks) should be treated
 with topical corticosteroids and topical antifungal agents, by avoiding wet environments, and with referral to dermatology. (See Video: Paronychia
Incision and Drainage.)
Video 283­2: Paronychia Incision and Drainage
Used with permission from Moira Davenport and Nkeiruka Onyenekwu, Department of Emergency Medicine, Allegheny General Hospital Medical
Play Video
FELON

A felon is a subcutaneous pyogenic infection of the pulp space of the distal finger or thumb. The septa of the finger pad produce multiple individual compartments and confine the infection under pressure. This results in a red, tense, and markedly painful distal pulp space. Infection typically begins with minor trauma, often a puncture wound, to the dermis overlying the finger pad. The infection can start and spread between septae, forming multiple compartmentalized abscesses. Left untreated, the infection may spread to the flexor tendon sheath, causing flexor tenosynovitis, or to the underlying periosteum, resulting in osteomyelitis.

S. aureus is the most common organism (primarily methicillin­resistant S. aureus), but Streptococcus species, anaerobes, and gram­negative organisms are frequent. If possible, obtain a Gram stain and culture because these infections may be difficult to eradicate and chronic infections may be caused by atypical organisms. If osteomyelitis occurs, identification of the offending organism guides long­term antibiotic therapy.

Drain the infection if the finger pad is swollen and tense or if there is any palpable fluctuance. A digital block using a long­acting anesthetic is ideal for comfort (see Chapter , “Local and Regional Anesthesia”). A unilateral longitudinal approach spares the sensate volar pad and achieves adequate drainage (Figure 283­4A). Do not incise the distal end of the finger pad because this can cause instability and loss of sensation to the fingertip. Dissect the septa using a small clamp to ensure complete drainage. A small wick encourages continued drainage.
FIGURE 283­4. Felon. A. The unilateral longitudinal approach is the most frequently used method for draining felons. This approach minimizes interference with sensate areas of the finger pad. B. If the felon is pointing toward the volar surface of the finger pad, the longitudinal volar approach may be used.
If the felon is pointing toward the volar fat pad, an option is a longitudinal volar approach, depicted in Figure 283­4B. Avoid extending the incision to the flexor crease of the distal interphalangeal joint. More extensive incisions such as the “fishmouth,” “hockey stick,” and through­andthrough incisions are not indicated because these can alter sensation to the fingertip or compromise pulp vascularity.
Following drainage, irrigate the wound and place a dry, sterile dressing; ask the patient to keep the extremity elevated. Reevaluate the wound within  hours, and use warm soaks to keep the wound clean and promote continued drainage.
Most felons have associated cellulitis that should be treated with oral antibiotics (Table 283­1). Refer chronic felons or felons not responding to the previously discussed treatments to a hand specialist for more definitive management and long­term follow­up. (See Video: Felon Incision and
Drainage.)
Video 283­1: Felon Incision and Drainage
Used with permission from Moira Davenport and William Drocklehurst, Department of Emergency Medicine, Allegheny General Hospital
Play Video
HERPETIC WHITLOW
Herpetic whitlow is a viral infection of the distal finger caused by the herpes simplex virus, usually from contact with oral herpetic infections. Herpetic whitlow in children tends to be associated with gingivostomatitis and herpes simplex virus type , whereas adults most commonly harbor herpes simplex virus type . Healthcare workers, often nurses and respiratory and dental technicians, are at increased risk of this infection given their exposure to orotracheal secretions.
The patient develops a burning, pruritic sensation similar to all herpes simplex infections. On examination, the lesion is erythematous and tender, with
 vesicular bullae (Figure 283­5). The infection occurs  to  days after contact, usually maturing in  days. The finger may be indurated, but is not tense, as is seen in a felon. Do not mistake herpetic whitlow for a felon because incision and drainage may result in a secondary bacterial infection and prolonged failure to heal. If there is any question concerning the diagnosis of herpetic whitlow, a vesicle may be unroofed, and the drainage fluid may be used for a Tzanck smear or direct antibody testing to confirm the diagnosis.
FIGURE 283­5. Herpetic whitlow. Note the cluster of vesicles on an erythematous base located at the distal finger. Tzanck smear is positive. [Photo contributor:
Lawrence B. Stack, MD. Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ (eds): Atlas of Emergency Medicine, 3rd ed. New
York, NY: McGraw­Hill; 2010.]
Treatment consists of immobilization, elevation, and pain medication. Treat with antiviral agents such as acyclovir or valacyclovir for  week to abort
 recurrent infections and decrease the course of protracted cases (Table 283­1). The finger should be kept in a clean dressing to prevent autoinoculation or spread of the herpes infection to other individuals.
NONINFECTIOUS INFLAMMATORY STATES OF THE HAND
Noninfectious inflammatory states of the hand often present as an acute exacerbation of symptoms related to recent overuse. Inflammatory states of joints and tendons are painful and difficult to distinguish from acute septic arthritis or suppurative tenosynovitis. If the diagnosis is in doubt, treat for infection, and consult a hand specialist.
If an inflammatory state is diagnosed, treat with rest, immobilization, elevation, and anti­inflammatory agents.
TENDINITIS AND TENOSYNOVITIS
Inflammatory tendinitis may involve the flexor or extensor tendons of the hand. Most often, the patient is able to recount a history of repetitive motion directly affecting the inflamed tendon. Palpation of the tendon produces tenderness. Active or passive movement of the tendon produces significant pain.
Treatment is splinting in the position of function with elevation of the affected area and prescribing NSAIDs, with referral for care from the primary care physician or a hand surgeon. Remind patients to return to the ED for worsening pain, increased swelling, or any signs of infection, including fever and erythema.
TRIGGER FINGER
Tenosynovitis can develop in the flexor sheaths of the fingers and thumb as a result of repetitive use. The ring finger and thumb are most frequently
 affected. Scarring or inflammation may cause the tendon to become nodular, which results in friction and catching between the tendon and its sheath, usually in the vicinity of the A1 pulley at the volar crease at the base of each digit. The A1 pulley is the proximal portion of the tendon sheath.
This is referred to as stenosing tenosynovitis or trigger finger. The patient experiences binding of the tendon, usually as the finger extends, relieved by a painful “snap” as the tendon nodule clears the first annular pulley. Occasionally, this condition may progress to the point that the finger locks, usually in flexion. Conservative treatment includes rest, anti­inflammatory medications, and immobilization (buddy tape or finger split) to reduce inflammation and swelling of the flexor tendon sheath. Early stages of trigger finger have been treated successfully with corticosteroid injection into
,19  the tendon sheath. If conservative treatment and steroid injection fail, surgical release of the A1 pulley is often curative.
DE QUERVAIN’S STENOSING TENOSYNOVITIS
De Quervain’s tenosynovitis involves the extensor pollicis brevis and abductor pollicis tendons and occurs in patients who have experienced excessive use of the thumb or wrist. This condition is often associated with pregnancy, the postpartum period, and activities involving repeated radioulnar
 deviation such as hammering, cross­country skiing, or lifting a child.
The patient presents with pain along the radial aspect of the wrist that may radiate to the thumb or extend into the forearm. The diagnosis of De
Quervain’s tenosynovitis is supported by a history of pain in this location along with a painful range of motion of the thumb and local tenderness over the distal portion of the radial styloid. Further confirmation of the diagnosis may be provided by a positive Finkelstein test (Figure 283­6), in which the patient grasps the thumb in the palm of the hand and the examiner ulnar deviates the thumb and hand. This stretches the tendons over the radial styloid and produces sharp pain along the involved tendons.
FIGURE 283­6. The Finkelstein test. The thumb is cupped in the closed fist, and ulnar deviation reproduces pain along the extensor pollicis and abductor pollicis.
Immobilize the thumb and wrist with a thumb spica splint or similar device. Instruct the patient to remove the splint briefly each day and perform range­of­motion exercises to prevent joint stiffness. In addition, start an anti­inflammatory medication for  to  days. Recurrence of this condition is common, particularly when related to occupational stress. Persistent cases may benefit from local corticosteroid injection or surgical decompression
 by a hand specialist.
CARPAL TUNNEL SYNDROME
Carpal tunnel syndrome is a peripheral mononeuropathy involving entrapment of the median nerve in the carpal canal or tunnel, which is covered by the tense transverse carpal ligament. Whenever a condition causes swelling in the carpal tunnel, the median nerve is compressed, causing paresthesias extending into the index and long fingers, the radial aspect of the ring finger, and along the palmar aspect of the thumb. Pain may also radiate proximally into the forearm or shoulder. The patient often complains of awakening at night with burning pain and tingling in the hand or numbness when driving a car or maintaining the wrist in prolonged flexion.
Carpal tunnel syndrome may develop from traumatic, hematologic, rheumatologic, anatomic, and infectious causes. A common scenario is overuse, in which the patient recounts a history of repeated flexion and extension of the wrist. In addition, edematous conditions such as pregnancy and congestive heart failure may acutely exacerbate symptoms in patients with a predisposition for carpal tunnel syndrome. The final common pathway consists of a space­occupying lesion that increases intracanal pressures. As the pressure increases, perfusion of the epineurium decreases, causing ischemia and nerve conduction block.
Pain or paresthesia in the median nerve distribution suggests carpal tunnel syndrome and may be confirmed by electrodiagnostic testing. The median nerve sensory distribution is illustrated in Chapter , “Local and Regional Anesthesia,” Figures 36­5 and 36­6. Two­point discrimination in this
 distribution is described as one of the most useful physical examination maneuvers for diagnosing carpal tunnel syndrome. In addition, Tinel’s sign supports the diagnosis and involves tapping the volar aspect of the wrist over the median nerve. A positive sign produces paresthesias that extend into the index and long finger. Phalen’s sign is more sensitive and specific and involves flexing the wrist maximally and holding it in this position for at least

 minute. A positive test occurs when the patient complains of tingling and numbness along the median nerve distribution. Both tests are subject to false­positive and false­negative results.
The presence of median nerve motor deficit requires emergency hand consultation. Otherwise, initial treatment is a volar splint to maintain the wrist in neutral position coupled with anti­inflammatory medications for  to  days. Refer those with persistent symptoms to a hand surgeon for surgical
 decompression. Most patients have complete resolution of their symptoms following surgical decompression, with around 5% requiring revision.
DUPUYTREN’S CONTRACTURE
Dupuytren’s contracture is a relatively common yet poorly understood disorder characterized by fibroplastic changes of the subcutaneous tissues of the palm and volar aspect of the fingers. The fourth and fifth fingers are affected earliest. The condition is found most commonly in men of northern

European descent. Dupuytren’s contracture is seen in those with tobacco use, alcoholism, diabetes mellitus, and repetitive handling or overuse.
This progressive fibrosis eventually may lead to tethering and joint contracture (Figure 283­7). Firm longitudinal thickening and nodularity of the superficial tissues over the distal tendon sheath of the palm are usually readily appreciated as the scarring process advances. The diagnosis is made by identifying a nodule in the palm, usually at the distal palmar crease of the ring or small finger, which is held in the classic flexion contracture. Refer to a
,27 hand specialist for surgical excision options.
FIGURE 283­7. Dupuytren’s contracture. This chronic problem is seen at the most common site: the ring finger. [Photo contributor: Alan B. Storrow, MD. Reproduced with permission from Knoop KJ, Stack LB, Storrow AB, Thurman RJ (eds): The Atlas of Emergency Medicine, 3rd ed. New York, NY: McGraw­Hill, Inc.;
2010, Fig. 12­36.]
GANGLION CYSTS
A ganglion or synovial cyst is a cystic collection of synovial fluid within a joint or tendon sheath (Figure 283­8). It is common, often following an injury or repetitive microtrauma. Ganglion cysts arise from a herniation of synovial tissue from a joint capsule or tendon sheath. The patient presents with a tender cystic swelling over or near a tendon sheath. Common locations are the dorsal and volar wrist, flexor surface of the metacarpophalangeal joint, or the base of the nail. Involvement of the thumb may appear as generalized thumb pain, pain with movement, and edema. Treatment is pain control and anti­inflammatory medications. About one third of cysts resolve spontaneously, with referral to a hand surgeon for those with persistent or recurrent pain or cosmetic deformity. Treatment options include observation, cyst aspiration, or surgical excision. Surgical excision offers significantly
 lower chance of recurrence compared with aspiration.
FIGURE 283­8. A dorsal ganglion cyst. [Reproduced with permission from Simon RR, Sherman SC (eds): Simon’s Emergency Orthopedics, 7th ed. New York, NY:
McGraw­Hill, Inc.; 2014.]


