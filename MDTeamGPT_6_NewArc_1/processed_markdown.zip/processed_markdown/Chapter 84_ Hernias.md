## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 84: Hernias
Don Byars; Turan Kayagil
INTRODUCTION

With nearly 10% of the population developing some sort of hernia during their lifetime, this is among the most common of surgical problems. Hernias
 are classified by anatomic location, hernia contents, and the status of those contents (e.g., reducible, strangulated, or incarcerated).
A hernia is called reducible when the hernia sac itself is soft and easy to replace back through the hernia neck defect. A hernia is incarcerated when it is firm, often painful, and nonreducible by direct manual pressure. Strangulation develops as a consequence of incarceration and implies impairment of blood flow (arterial, venous, or both). A strangulated hernia presents as severe, exquisite pain at the hernia site, often with signs and symptoms of intestinal obstruction, toxic appearance, and, possibly, skin changes overlying the hernia sac. A strangulated hernia is an acute surgical emergency. This chapter discusses hernias in adults. Hernias in children are discussed in Chapter 133, “Acute Abdominal Pain in Infants and Children.”
ANATOMY OF COMMON HERNIAS
INGUINAL HERNIA
Seventy­five percent of all hernias occur in the inguinal region, making it the most common form of hernia, with two thirds of these being of the indirect type (Figure 84­1). Although there is a clear male predilection, inguinal hernias are also the most common hernias in women. Inguinal hernias present as a groin mass. Typically the mass has been present for some time, but may have recently become larger or the patient may have begun to develop symptoms of incarceration or strangulation. The differential diagnosis for a groin mass is somewhat broad and includes, in addition to hernia, hidradenitis, other abscess, sebaceous cyst, lymphoma, hydrocele, varicocele, femoral hernia, and femoral aneurysm. Thankfully, the physical examination for most hernias is fairly straightforward. Bedside US can be very helpful in the identification of an inguinal hernia if the diagnosis remains in question (Figure 84­2). One study reported 100% sensitivity and 100% specificity of bedside emergency US for the diagnosis of
 groin hernia.
FIGURE 84­1. Groin hernia.

Chapter 84: Hernias, Don Byars; Turan Kayagil 
. Terms of Use * Privacy Policy * Notice * Accessibility
FIGURE 84­2. Incarcerated hernia. A. An incarcerated femoral hernia is demonstrated as a small­bowel segment herniated through the femoral canal. B. In an incarcerated incisional hernia, a small­bowel segment (arrow) is demonstrated as herniated through a small orifice in the abdominal wall. Dilated small­bowel loops are evident proximal to the incarceration. C. In an umbilical hernia, a herniated small­bowel segment is demonstrated within the fluid space in the hernia sac. The segment was softly strangulated at the hernia orifice (arrow) formed by a defect of the fascia and was easily reduced by manipulation in this case. D. An incarcerated obturator hernia is demonstrated deep in the femoral region. It locates posterior to the pectineus muscle (arrows) and medial to the femoral artery (A) and vein (V). [Reproduced with permission from Ma OJ, Mateer JR, Blaivas M (eds): Emergency
Ultrasound, 2nd ed. Copyright . Chapter , General Surgery Applications, Common
Abnormalities, Incarcerated Hernia. Figure 9­16.]
A direct inguinal hernia passes directly through a weakness in the transversalis fascia in the Hesselbach triangle. Hesselbach triangle is constructed with the lateral border of the inferior epigastric arteries, a medial border with the rectus sheath, and an inferior border of the inguinal ligament

(Figure 84­3).
FIGURE 84­3. Direct inguinal hernia.
The hernia sac from an indirect inguinal hernia passes from the internal to the external inguinal ring through the patent process vaginalis, and then to the scrotum (Figure 84­4).
FIGURE 84­4. Indirect inguinal hernia.
VENTRAL AND INCISIONAL HERNIAS
Ventral hernias develop as a result of a defect in the anterior abdominal wall and can be either spontaneous or acquired. They are typically
 characterized by their anatomic location as epigastric, umbilical, incisional, or hypogastric (Figure 84­5).
FIGURE 84­5. Anterior abdominal wall hernia.
Incisional hernias account for up to 20% of all abdominal wall hernias. They are often the result of excess wall tension or inadequate wound healing.
They are also associated with surgical wound infections. Risk factors for the development of incisional hernias include obesity, age, wound infection,
 and medical conditions (i.e., chronic obstructive pulmonary disease) that increase intra­abdominal pressure. Incisional hernias can become quite large and produce symptoms varying from discomfort to extrusion of abdominal contents to incarceration and strangulation. Despite primary repair, incisional hernias can recur.
UMBILICAL HERNIA
The adult form of umbilical hernia is largely acquired and due to medical conditions that increase intra­abdominal pressure, including ascites, pregnancy, and obesity. Although strangulation is unusual in most patients, those with chronic ascites (i.e., cirrhotics) are at risk for umbilical hernia
 strangulation, rupture, and death from peritonitis.
ANATOMY OF UNCOMMON HERNIAS
FEMORAL HERNIA
Femoral hernia (Figure 84­1) is so named because the hernia sac protrudes through the femoral canal and produces a mass that is typically below the inguinal ring. Femoral hernias are more common in women, with a  to  female predilection. The femoral hernia is particularly prone to complications, such as incarceration and strangulation. One study reported a 40% emergency surgery rate due to such complications in patients with a
 known femoral hernia. All femoral hernias should be urgently referred for elective repair. Delays in femoral hernia repair lead to increasing rates of
  strangulation, reaching 45% at  months. A small study by Malek et al reported worrisome complication rates (31%) and surprising high mortality
(13%) from delayed repair of femoral hernias.
SPIGELIAN HERNIA
Spigelian hernia (Figure 84­5), also known as a lateral ventral hernia, arises at the lateral edge of the rectus muscle and the arcuate (semilunar) line.
Spigelian hernias are nearly always acquired conditions due to comorbidities that increase intra­abdominal pressure. These hernias are very difficult to diagnose, especially given the variability in presentation. The classic presentation is abdominal pain associated with an anterior lateral abdominal
 wall mass or bulge. Physical examination is unreliable, and accurate diagnosis often requires diagnostic imaging. Bedside emergency US can
 accurately and quickly make the diagnosis. CT scan remains the best imaging for diagnosis. Spigelian hernias should be surgically corrected given their high rates of incarceration.
OBTURATOR HERNIA
Obturator hernia is bowel herniation through the obturator canal (Figure 84­6) and nearly always presents as either a partial or complete bowel obstruction. The typical patient is an elderly frail female with signs and symptoms of intestinal obstruction. Although physical examination findings, such as the Howship­Romberg sign (pain in medial portion of the thigh due to obturator nerve compression), are well documented in the literature, the sign is not as useful in routine practice. Diagnosis is made by CT scanning of the abdomen and pelvis. It is important to properly diagnose this hernia
 given its high complication rate reported as perforation in >50% of cases and mortality approaching 20%.
FIGURE 84­6. Obturator foramen. [Reproduced with permission from Pansky B: Review of Gross Anatomy, 6th ed, © 1995, The McGraw­Hill Companies, 1995, p. 511.]
RICHTER HERNIA
Richter hernia involves only the antimesenteric border of the intestine and involves only a portion of the wall circumference. The Richter hernia presents differentially from a traditional incarcerated/strangulated hernia, as it often presents without vomiting or intestinal obstruction due to the incomplete involvement of the circumference of the intestine. Thus, the Richter hernia more often leads to strangulation and gangrene than other
 more standard hernias. Surgical repair is indicated.
DIAGNOSIS
Traditional laboratory studies, such as a CBC, serum chemistries, and urinalysis, are routinely ordered but are of minimal value in the evaluation unless seeking an alternative diagnosis or for preoperative clearance.
IMAGING
Plain films are not required in hernia patients without significant symptoms. The acute abdominal series can reveal the presence of free air and signs of intestinal obstruction, but otherwise, plain films are usually indeterminate or nondiagnostic.
US has many advantages for diagnosis, but US is both operator and body habitus dependent. The primary role of US is the identification of the hernia itself. The dynamic abdominal sonography for hernia examination has good results in experienced hands as compared to CT for hernia
  diagnosis. When a hernia is identified by US, note hernia size, contents, reducibility, location of the facial defect, and tenderness. In addition to
16­18 determining whether bowel is present in a hernia sac, US can sometimes identify signs of incarceration and strangulation. Strangulated bowel, by definition, has vascular compromise. In the natural history of an incarcerated hernia, the thin­walled veins and lymphatics become compressed and compromised before the thick­walled arterial supply. Doppler US can detect the arterial flow to the loop of bowel, but is usually not sensitive enough
,17,18 to detect venous flow and cannot detect lymphatic flow. Thus, Doppler US can be insensitive for strangulation. However, preservation of arterial inflow with obstruction of venous outflow causes increased intravascular pressure and extravasation of fluid into the extracellular space. This manifests itself as free fluid in the hernia sac on B­mode US, which is a sensitive finding for incarceration and strangulation. The specificity of free fluid in the hernia sac is good per se, but may be confounded by patients with ascites. Other US findings associated with incarceration and strangulation include hyperechoic fat, isoechoic thickening of the hernia sac, thickening of the wall of the herniated bowel, and free fluid within the herniated bowel
,18 loop. Absence of peristalsis in a herniated bowel loop is suggestive of incarceration, and the presence of peristalsis implies that bowel resection is
 less likely to be necessary when the patient undergoes operative intervention. US is most useful for diagnosis in children and pregnant women given
 its lack of ionizing radiation.
It can be clinically difficult to differentiate hernia from hydrocele when assessing a scrotal mass. Obtaining a scrotal US in the standing position, with and without Valsalva maneuver, is a good way to demonstrate hernia.
CT is the best­performing radiographic test for hernia diagnosis and can identify uncommon hernia types (e.g., Spigelian or obturator) as well as
 demonstrate incarceration and strangulation.
TREATMENT
If the hernia is easily reducible on physical examination, then refer the patient for elective outpatient surgical repair.
If the hernia is exquisitely tender and is associated with systemic signs and symptoms, such as intestinal obstruction, toxic appearance, peritonitis, or
 sepsis, then assume hernia strangulation. Consult general surgery immediately. Administer broad­spectrum IV antibiotics, provide fluid resuscitation and adequate narcotic analgesia, and obtain preoperative laboratory studies.
If the hernia is incarcerated but the patient does not yet show signs of strangulation, then make one or two attempts at reduction in the ED. Steps for
 hernia reduction are listed in Table 84­1. TABLE 84­1
Steps for Hernia Reduction
NPO status in case reduction attempts are unsuccessful.
Adequate IV narcotic analgesia.
Apply cold packs to the hernia site to reduce swelling and make reduction attempts easier.
Grasp and elongate the hernia neck with one hand, and with the other hand, apply firm, steady pressure to the proximal part of the hernia at the neck at the site of the fascial defect. US can aid in the identification of the fascial defect if it is not clinically obvious. Applying pressure on the most distal part of the hernia can cause bulging (or ballooning) at the hernia neck and prevent reduction.
Consult surgery if the reduction is unsuccessful after one or two attempts.
After ED reduction of an incarcerated hernia, it is reasonable to observe the patient in the ED for a period of time for serial abdominal examinations.

Persistent significant abdominal pain must raise clinical concern for “reduction en mass.” Although a rare complication of reduction attempts, it
,24 has been reported in the literature from the early 1900s to the present day. A reduction en mass occurs when an incarcerated hernia is reduced back into the peritoneal cavity but a loop of bowel remains inside the hernia sac even after reduction, so that the retained bowel remains
,24 incarcerated. In cases of reduction en masse, the patient will continue to exhibit signs and symptoms of incarceration despite apparent clinical reduction. Imaging can assist in the detection of this distinctly uncommon but serious diagnosis.
If there is any concern for strangulation, do not attempt hernia reduction. The reintroduction of ischemic, necrotic bowel back into the peritoneal
 cavity can result in subsequent perforation and sepsis. Bedside US using a linear high­frequency probe with color or power Doppler of the hernia sac
 can be useful in borderline cases to establish the presence or absence of arterial blood flow.
Acknowledgments
The author gratefully acknowledges the contributions of Frank W. Lavoie and Mary Harkins Becker, the coauthors of the chapter on hernias in adults and children in the previous edition. (Hernia in children is now discussed in Chapter 133.)


