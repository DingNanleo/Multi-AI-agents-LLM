## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 150: Child Abuse and Neglect
Margaret Colbourne; Michelle Clarke
INTRODUCTION AND EPIDEMIOLOGY
Child maltreatment is, unfortunately, a common global problem. In the United States, over 675,000 children suffer some form of child abuse or neglect
 each year, and approximately 12% of these children will present to a hospital with injuries. It is estimated that between 2% and 10% of children visiting
 the ED are victims of child abuse or neglect. According to the World Health Organization, .3% of children experience emotional abuse, .3%
 experience physical neglect, and .6% of adults report suffering physical abuse as a child. The lifetime prevalence of childhood sexual abuse ranges
 from 8% to 31% for girls and 3% to 17% for boys. Therefore, emergency providers are in a unique position to identify nonaccidental injuries and potentially prevent further abuse. Child maltreatment takes many forms, including neglect, physical abuse, sexual abuse, emotional abuse, and caregiver­fabricated illness (previously called Munchausen syndrome by proxy).
NEGLECT
Child neglect is the most common form of child maltreatment and the most difficult to evaluate and manage; it contributes to as many as 50% of
 fatalities from child maltreatment. Neglect occurs when a caregiver fails to meet a child’s basic needs in provision of food, shelter, clothing, health
5­7 care, education, supervision, and nurturance. Further, this failure either results or is very likely to result in serious impairment of a child’s health or development. While many types of neglect may occur, seldom does any one form exist on its own. Carefully consider each neglect risk factor individually, identifying whether there is overt historical or physical evidence of each subtype of neglect (Table 150­1).
TABLE 150­1
Types of Neglect
Types of
Description
Neglect
Physical Failure to provide the basic physical necessities of food, shelter, and adequate clothing.
Emotional Failure to provide necessary nurturing, affection, and stimulation.
Educational Failure to provide an educational program; this may include chronic truancy.
Medical/dental Failure to provide basic medical and dental care, which results, or has the potential to result, in harm; this may include noncompliance with healthcare recommendations.
Supervisory Failure to adequately supervise and ensure safety of a child, given the child’s developmental needs.
Given that neglect is rarely a single act, but is rather an accumulation of harm over time, the often brief, single encounter of an ED assessment cannot provide the comprehensive assessment required. The goals of the ED encounter are to recognize when child neglect may be at issue, to clearly document the presenting concerns, and to trigger the appropriate multidisciplinary team approach for the investigation and management of these
6­9 complex cases. The recognition of child neglect in the ED requires knowledge of the multiple risk factors associated with neglect (Table 150­2).
PDoovwenrtloy,a pdaerde n2t0a2l 5su­7b­s1t a6n:1ce6 aPb u Ysoe,u ar nIPd mis e1n3t6a.l 1h4e2a.l1th5 9is.s1u2e7s are three of the most common risk factors for child maltreatment and neglect. ,8 Although
Chapter 150: Child Abuse and Neglect, Margaret Colbourne; Michelle Clarke not all poor families are neglectful, poverty has an overwhelming effect on the parents’ ability to provide basic care for their children and may
. Terms of Use * Privacy Policy * Notice * Accessibility
 contribute to social isolation and a lack of supports. Substance abuse may result in a parent who is both physically and emotionally unavailable to the child, and substance abuse may divert funds for basic necessities.
TABLE 150­2
Risk Factors for Child Maltreatment
Child risk factors Premature birth
Young age
Multiple gestation (twin/triplet) births
Chronic disability
Adolescents with emotional/behavioral problems
Parent risk factors Substance abuse
Cognitive impairment
Adolescent parents
Domestic violence
Mental health issues
Lack of education/unrealistic expectations
Family/social risk factors Isolation
Single­parent families
Unemployment
Family illness
History of involvement with child welfare services
CLINICAL FEATURES
Children and adolescents may be brought to the ED for a variety of reasons when neglect is the underlying problem. Presenting symptoms may include failure to thrive, malnutrition, chronic respiratory or skin infections, repeated injuries, poisonings, behavioral problems, or mental health concerns.
Children with chronic disabilities or chronic medical conditions may present repeatedly with clinical deterioration if a parent is noncompliant with healthcare recommendations.
History
Review the hospital record prior to obtaining the medical history from the parent. Be alert to chronic health problems, repeated accidents or injuries, and missed medical appointments. The medical history must address both the presenting complaint as well as any past illnesses or injuries. Note whether the parents are able to provide a clear history and are knowledgeable about their child’s health and developmental milestones. Document the child’s immunization status and any past or current medications. The young infant or child who presents with feeding problems or failure to thrive requires a thorough perinatal history as well as a detailed dietary record. In the case of maternal depression, the history provided by the mother may be vague and difficult to obtain. Inquiries into the family history should specifically address known risk factors for child neglect including parental mental health issues and substance abuse.
Physical Examination
The physical examination begins during the process of gathering the history, with observations of the interaction between the parents and child and notes on the child’s clothing and hygiene. Observe for unusual demeanor or extreme behaviors such as flat affect, listlessness, overt fear, or out­ofcontrol behavior. Document objective growth parameters including weight, height, and head circumference, and compare with previously reported measures when possible. In general, weight is the first growth parameter to be adversely affected by inadequate nutrition.
The physical examination is typically focused on the system of chief complaint; however, concern for neglect should prompt special attention to the skin (bruises, scars, infection, diaper rash), hair (alopecia, lice infestation), and teeth (dental caries). Determine if muscular tone is decreased or increased. Ear, nose, throat, and respiratory examinations may reveal evidence of chronic, untreated infection. Abdominal exam should note any distention, organomegaly, or unusual masses. Look for evidence of peripheral edema. Note the presence of adequate subcutaneous fat as well as muscular development, particularly over the suprascapular and buttock regions.
Laboratory Testing and Imaging
Investigations vary depending on the severity of illness or injury. For failure to thrive, a comprehensive nutritional and metabolic profile is generally indicated. A complete skeletal survey should be considered in any situation of serious neglect to identify physical abuse and to assess skeletal abnormalities from nutritional deficiency or undiagnosed metabolic disease.
TREATMENT AND DISPOSITION
Focus on initial stabilization of acute medical illness and injury. For severe malnourishment with fluid and electrolyte imbalance, initial management may require intensive care support to manage metabolic complications such as “refeeding syndrome.” Most infants with failure to thrive due to environmental neglect will respond rapidly to appropriate feeding.
Educate the parents in a thoughtful, respectful, and culturally sensitive manner on the most urgent problems and need for further investigation and treatment. Early consultation with pediatric specialists or child abuse pediatricians is warranted for all concerns of child neglect, even if hospitalization is not indicated. Comprehensive management of child neglect requires frequent ongoing reevaluation, which goes beyond the routine duties of the emergency physician.
PHYSICAL ABUSE
CLINICAL FEATURES

Physical abuse accounts for approximately 18% of all cases of child abuse and is the most easily identified type of maltreatment. Child physical abuse is defined as injury inflicted on a child by a caregiver. Injuries can occur to all parts of the body, but the more commonly injured areas are the skin
(bruising, burns), skeleton (fractures), head, and abdomen. Evaluate the child medically and treat injuries. Medical evaluation and treatment of the child always take precedence over the legal investigation. Although the forensic or legal evaluation is best performed by trained investigators or child abuse specialists, data gathered in the ED often guide and inform further investigation.
History
Obtain a detailed history from all involved including the child, parents, caregivers, and any witnesses. Document details of the onset and progression of symptoms leading to the ED visit. Especially in young infants, pinpoint the last time the child was completely well. In a critically ill child, provide immediate resuscitation. In most cases of accidental injury, there is a clear and consistent history of an accident with the child presenting for care soon afterward. Historical features concerning for abuse include no history of trauma, changing important details of the history, explanations inconsistent with the injury or with the developmental stage of the child, discrepancies in the history provided by
10­12 different caregivers, or a significant delay in seeking care.
Obtain past medical history including the birth history, chronic or congenital conditions, previous injuries, and previous hospitalizations and surgeries. Document any family history of bleeding or bone disorders and any relevant metabolic or genetic conditions. Review the diet and medication history including vitamin K at birth and any subsequent vitamin or nutritional supplementation. Note current developmental status and progress. The social history should identify the primary caregiver and other caregivers, household composition, any history of past abuse to the child or siblings, and previous child protective services involvement.
Physical Examination
Begin with a general assessment of the child’s alertness and demeanor. A brief evaluation of the work of breathing, cardiovascular perfusion, and level of consciousness will identify a critically ill child in need of resuscitation. Note whether there is spontaneous and symmetric movement of the extremities. Lack of use of an extremity or pain with examination or movement may indicate a fracture. Document head circumference and examine the scalp, noting any hematomas or step­offs, which may indicate a skull fracture. Funduscopic exam may reveal retinal hemorrhages, although it is often difficult to perform an undilated exam in a child. Injuries to the mouth, such as a torn frenulum, may be indicative of forced feeding. Fully expose the skin and document the precise location, size, and shape of any bruises, burns, bite marks, or scars. Palpate the chest, abdomen, spine, and extremities for any tenderness. Perform and document a neurologic examination if there is concern for head trauma.
DIAGNOSIS
Bruises

Bruising is the most common manifestation of physical abuse and is often overlooked. Up to a third of children with fatal or near­fatal abusive injuries
,14 have previous medical assessments in which bruising was noted. Because bruising is also very common in nonabused children, distinguishing between nonaccidental and accidental bruising requires careful consideration of the child’s age and developmental level, the history, and any other associated injuries. Accidental bruises occur on the front of the body, over bony prominences, on the extremities, and on the
 forehead. Nonaccidental bruises, on the other hand, are more commonly found on the torso, neck, and ears (Figure 150­1) and the soft parts of the body such as the cheeks and the buttocks. Nonaccidental bruises are also more likely than accidental bruises to be found
 in clusters, to be on the back of the body, and to be symmetrical. In addition, nonaccidental bruises tend to be larger and more numerous than
 accidental bruises. Patterned bruises may be evident if a child has been struck with a hand or an implement (Figure 150­2). Although the presence of bruises of different colors was previously thought to indicate bruises of different ages, the dating of bruises is highly inaccurate. The examiner
 should document the location, color, size, and shape of bruises but should not comment on the timing of the injury.
FIGURE 150­1. Bruising and petechiae on the ear from physical abuse.
FIGURE 150­2. Multiple bruises to the back and buttock from physical abuse. Note the patterned loop bruising from impact with a cord.
Bruises in young infants deserve special consideration because infants very rarely sustain accidental bruises. The adage those who don’t cruise rarely bruise is supported by the observation of bruising in only .6% of infants less than  months of age and in only .2% of infants not yet able to walk,
 while bruising is present in over half of toddlers. Bruising in infants is associated with more serious abusive injuries. Additional injuries are
 diagnosed in up to one half of infants with isolated bruising. The TEN­4 bruising clinical decision rule identifies bruises to the thorax, ears, and neck,
 as well as any bruising in infants less than  months, as particularly concerning for abuse (Figure 150­3).
FIGURE 150­3. 
TEN­4 bruising clinical decision rule for bruises concerning for abuse. LR+ = positive likelihood ratio.
The differential diagnosis of bruises includes skin conditions such as congenital dermal melanocytosis (Mongolian spots) and cultural practices such as cupping and coining. Both acquired and inherited bleeding disorders, such as idiopathic thrombocytopenic purpura and hemophilia, predispose children to bruising from inconsequential trauma. These conditions are readily diagnosed through the history, family history, and basic screening blood work including a CBC and coagulation profile. Other medical conditions causing bruising include infections (e.g., meningococcemia), leukemia, nutritional deficiencies, and Henoch­Schönlein purpura.
Burns
Burns account for 6% to 20% of maltreatment­related fatalities in children. Most burns, both accidental and abusive, are scalds and affect children age

 to  years old. Accidental scalds typically occur when young children pull hot beverages off tables or stovetops, spilling the hot liquid onto themselves. The resulting burns are generally asymmetric, have irregular borders, are of varying depth, and are distributed over the face, neck, and
  upper torso. In contrast, most inflicted burns are caused by immersion in hot tap water. Abusive burns are often in a glove and stocking distribution with a sharp line of demarcation between the burned and uninjured skin. The child may have been held seated in a tub of hot water, resulting in burns to the perineum and feet with ring­shaped sparing of the buttocks where the skin was in contact with the cooler surface of the tub.
When assessing nonscald burns, consider the distribution and extent of the burn. Children usually burn themselves when they reach out and touch a hot object. Most accidental burns, therefore, occur on the palms and the fingers and have an indistinct contour. In contrast, inflicted burns tend to be on the dorsal surface of the hands and on the back of the body. The margins of inflicted burns are often more distinct and may take the shape of the
 heated object used to inflict the burn.

Burns due to neglect are nine times more common than inflicted burns. Even when a burn itself does not appear inflicted, it is important to consider whether lack of adult supervision or exposure to an unsafe environment or substances played a role in the injury.
The differential diagnosis of burns includes bullous impetigo, Stevens­Johnson syndrome, and severe diaper dermatitis.
Fractures
Fractures are the second most common manifestation of physical abuse. Over 80% of abusive fractures occur in children less than  months of age,
,23 and 12% to 20% of fractures in infants and toddlers are caused by physical abuse. Because fractures are also very common accidental injuries, accounting for between 8% and 12% of all pediatric injuries, distinguishing between accidental and abusive fractures can be challenging, particularly
,24 when the caregiver may not provide an accurate history. In children <3 years old, up to 20% of abusive fractures were initially attributed to
 accidents or other causes. Children with abusive fractures may present with nonspecific complaints such as irritability, swelling, not using a limb, or refusal to weight bear. Fractures may also be discovered incidentally during evaluation for other conditions or injuries.
There are a number of historical and clinical factors associated with an increased likelihood of physical abuse; however, the single most important
 ,24 risk factor for abusive fractures is young age (Table 150­3). It is very unusual for nonmobile infants to sustain fractures. Abuse accounts for one in two femur fractures in children less than  year of age, whereas the likelihood of abuse as a cause of femur fractures in 2­ to 3­year­olds
25­28 drops to less than one in five.
TABLE 150­3
Risk Factors for Physical Abuse in a Young Child With Fracture
Age <1 year old with fracture
No history/inconsistent history of trauma
High­risk fractures:
Rib fractures
Metaphyseal fractures
Humerus fracture in child <15 months old
Femur fracture in nonambulatory child
Multiple fractures or fractures of different ages
Presence of other injuries
Any fracture can be caused by either accidental or nonaccidental means; however, certain fracture types are more specific for abuse and should prompt further investigation. Rib fractures are rare in infants and young children and are generally seen only in cases of severe trauma such as
 motor vehicle collisions (Figure 150­4). In the absence of severe trauma, a child with rib fractures has a  in  chance of having been abused.

Posterior rib fractures are most highly correlated with physical abuse.
FIGURE 150­4. Acute left clavicle and healing rib fractures in an infant.
Classic metaphyseal fractures are shear injuries to the immature ends of growing bones in infants caused by the rapid acceleration and
 deceleration associated with yanking or shaking (Figure 150­5). They are highly specific for child abuse.
FIGURE 150­5. Classic metaphyseal fracture of the humerus with bucket handle appearance.
Additional injuries, such as linear skull fractures and long bone fractures, are common in both accidental and nonaccidental injuries. Knowledge of possible injury mechanisms resulting in each fracture type guides the clinician in assessing whether the reported history accounts for the injury.
Consider the differential diagnosis of fractures. Although the lack of any reported history of trauma should raise concern about abusive injuries, toddler’s fractures are an exception to this rule. Toddler’s fractures are nondisplaced spiral fractures occurring in the distal third of the tibia in ambulatory children between  months and  years of age (see Chapter 141, “Pediatric Orthopedic Emergencies”). These are accidental fractures that occur when the child twists and falls on a planted foot. Certain medical conditions such as inherited bone diseases (osteogenesis imperfecta), chronic medical conditions (renal osteodystrophy), or nutritional deficiencies result in weaker bones that may fracture with relatively minor trauma. These conditions are far less common than child abuse and are often easily identified by the medical history, the physical exam, and the radiographic appearance of the bones.
Abusive Head Trauma
31­33
Abusive head trauma is the most common cause of traumatic death and disability in infancy and early childhood. Although a number of terms have appeared in the medical literature over the years to describe the spectrum of cranial and ocular injuries that occur due to inflicted head injury in children, the American Academy of Pediatrics currently recommends the term abusive head trauma as the appropriate medical diagnostic
 terminology.
Abusive head trauma demonstrates a distinct pattern of injuries characterized by intracranial injury (hemorrhage, edema, or infarction) and ocular
34­38 injury (retinal hemorrhage or retinoschisis). Skull, rib, or long bone fractures may be present; however, remarkably, there may also be no external evidence of trauma at all. Retinal hemorrhages occur in up to 80% of patients with abusive head trauma and typically are extensive, occurring in
,38 multiple layers of the retina and extending out to the ora serrata.
Infants and children with abusive head trauma are brought to the ED with a broad spectrum of clinical concerns and findings. Children may present in extremis, with obvious signs of physical trauma. Alternately, they may present with only very subtle suggestions of irritability or feeding problems and
 no history of trauma at all. Apnea and seizures both have a significantly higher association with abusive head trauma than with accidental trauma.
Unfortunately, a substantial number of cases of abusive head trauma go unrecognized due to the mild, nonspecific nature of the presenting symptoms
 and signs. The clinician must be careful not to overlook signs such as bruising, large head circumference (>85th percentile), or unexplained mild
 anemia in infants presenting with nonspecific complaints as these features may identify children who would benefit from neuroimaging.
The differential diagnosis of abusive head trauma includes a number of conditions, but perhaps the two most common are birth­related and
,41 accidental trauma. Subdural and retinal hemorrhages secondary to birth are typically asymptomatic, resolving well within the first month of life.
Accidental falls may cause head injury and, very rarely, sparse retinal hemorrhage usually isolated to the posterior pole. Accidental falls are extremely unlikely to result in severe intracranial injury and typically result in focal damage with clear evidence of blunt impact to the head. Other underlying medical conditions such as coagulopathies and metabolic or congenital abnormalities will very rarely present with features similar to abusive head trauma.
Abdominal Trauma
Although abdominal injuries due to child abuse are less common than other types of abusive injuries, abdominal trauma is the second leading cause
 of death in abused children, after abusive head injury. Injuries to virtually every organ have been reported; however, liver and small bowel injuries are the most commonly seen. While no single feature allows identification of children with intra­abdominal trauma, features associated with a higher
 likelihood of abusive trauma than of accidental abdominal injuries include young age and small bowel injury. Abdominal injuries due to abuse are much more common in toddlers (median age, .6 years), whereas accidental injuries are more common in older children (median age, .8 years).
Accidental injury to the small intestine is exceedingly rare in children less than  years of age. In older children, accidental small bowel injuries most commonly are the result of motor vehicle collisions or handlebar injuries. Duodenal injuries in particular are very concerning for abuse in young
 children. The mechanism of injury is typically a direct blow to the abdomen compressing the fixed duodenum against the spine.
Because many cases of abdominal trauma are asymptomatic or have other confounding injuries and there is often no history of trauma provided, be alert for any potential sign of injury and have a low threshold for investigation. Although bruising to the abdomen is a clear sign to consider intra­
 abdominal injury, it is present in only 20% of cases. Signs and symptoms of intra­abdominal injury range from nonspecific irritability, lethargy, vomiting, poor feeding, and abdominal discomfort or distention to shock with frank peritonitis.
The gold standard for diagnosis of intra­abdominal trauma is a CT scan of the abdomen; however, given the difficulty in identifying abdominal injuries due to abuse, some advocate screening for intra­abdominal injuries using hepatic transaminases in all young children where there are concerns
,42,43 about physical abuse. Because hepatic transaminases may not be elevated in cases of small bowel injury, obtain abdominal CT scan if clinical suspicion warrants.
LABORATORY TESTING AND IMAGING FOR SUSPECTED ABUSE AND NEGLECT
Investigations for any form of injury are guided by the nature and severity of the injury, the age of the child, and the physical examination findings. In general, the more severe the injury and the younger the child, the more extensive the investigations required and the more likely they are to reveal additional injuries. Consultation with a pediatrician or child abuse specialist is recommended.
Laboratory Testing
Laboratory investigations include a CBC with differential and coagulation studies, including a platelet count, a prothrombin time, and a partial thromboplastin time. Results may reveal anemia secondary to an intracranial or intra­abdominal hemorrhage or an abnormal coagulation profile due to the brain injury itself. Further coagulation studies may be indicated in cases of extensive bruising or intracranial hemorrhage. In the child with unexplained fractures, obtain a serum calcium, phosphate, and alkaline phosphatase. Children with severe injuries, including those suspected of abusive head trauma or occult abdominal trauma, should undergo a complete trauma panel including hepatic transaminases.
Imaging
A skeletal survey is a specific series of radiographs of all the long bones, chest, spine, hands, feet, pelvis, and skull that is indicated
,12,18 in all infants and young children when there is a concern for inflicted trauma. A properly performed skeletal survey frequently reveals previously unsuspected injuries including multiple fractures or fractures at various stages of healing.
Noncontrast head CT is indicated for any child suspected of sustaining acute intracranial trauma. Radiologic features with significant association for abusive head trauma include subdural hemorrhage, particularly if diffuse, interhemispheric, or infratentorial; hypoxic ischemic injury; and cerebral
 edema. MRI may further delineate the extent of brain injury and may offer some guidance for the timing of injuries. Inclusion of the neck and spine in

MRI studies may identify ligament injury or spinal hemorrhage.

Abdominal CT should be included when there is concern for intra­abdominal injury. Although it may be tempting to screen for intra­abdominal injury
,46 by US, US is not sensitive enough to identify all clinically significant intra­abdominal injuries in both abusive and accidental injuries.
TREATMENT AND DISPOSITION
Rapidly identify and resuscitate life­threatening injuries. Once the child has been stabilized, attention shifts to further medical and legal evaluation.
Because the comprehensive investigation of child abuse requires a multidisciplinary approach, most potential victims of serious physical abuse should be admitted to the hospital while the appropriate medical, surgical, and child protection teams complete their respective investigations. Children with
,47 head and abdominal injuries due to abuse have both longer hospitalizations and higher mortality compared with children with accidental injury.
Older children with minor or superficial injuries may be discharged provided they have been assessed by child protective services and a safe environment can be ensured.
CHILD SEXUAL ABUSE

Reports suggest that 26% of girls and 5% of boys have experienced some form of sexual abuse by the age of  years. When there is concern for possible sexual abuse, the role of the ED provider is to identify children requiring urgent medical and forensic evaluation, to decide when to refer to other professionals and child protection authorities, and to counsel the parents or caregivers. The child’s ED visit may be triggered by a broad spectrum of issues including anogenital bleeding, vaginal/urethral discharge, dysuria, urinary tract infection, sexualized behaviors, suicidality, or as commonly happens, a recent disclosure of sexual abuse without any specific physical symptoms. The sexual abuse may be either recent or remote relative to the time of presentation and may have involved numerous contacts over a period of time. The offender is typically well known to the child
48­50 and, indeed, is often a parent or family member. As a result, the child’s caregivers typically present in emotional crisis, even though the child may not be suffering any physical trauma. The family requires a patient, supportive individual to listen to their concerns and provide appropriate guidance and reassurance.
First begin by assessing the urgency of the situation and determining when and where the full assessment should most appropriately be performed. In some jurisdictions, sexual assault nurse examiners or child abuse pediatricians are available. Emergency evaluation with collection of forensic evidence is indicated if the abuse has been recent, the child has genital bleeding or concerns of acute trauma, or there are other concerns for occult trauma. As yet, there is no consensus on the outside limit for the timing of forensic evidence collection in the pediatric patient. Research suggests that physical examination should be performed as soon as possible after an assault, yet evidence collection is unlikely to produce positive results in child
,51 victims outside the first 24­hour period. Whether or not forensic evidence is collected, an immediate physical examination is recommended for all
,53 children disclosing sexual abuse within  hours of the last event. Physicians should be aware of the policies for the timing of forensic evidence collection within their own jurisdiction.
CLINICAL FEATURES
There are numerous factors that make conclusive evaluation of alleged child sexual assault challenging:
,52,54
The medical diagnosis of sexual abuse is heavily reliant on the history provided by the child. A proper forensic interview should be conducted by trained child protection investigators.
,54­57
The absence of physical findings does not exclude abuse. Many sexually abusive activities leave no physical marks on the child, and in the rare instances where traumatic injuries do occur, they often heal well, with no obvious evidence of prior injury.
50­52,58
Forensic specimens are typically not positive in child sexual abuse but should be collected when possible. Forensic evidence may include blood, seminal fluid, sperm, saliva, or other foreign debris. The majority of evidence will be found on linens or
,51,58 clothing.
History
Obtain the initial historical details from ancillary personnel (parents, guardians, police, or social workers) without the child present. Often the most compelling evidence for criminal prosecution is the detailed, forensic interview of the child performed by child protection investigators. Thus, direct questioning of the child should be limited to a medical history that addresses acute physical symptoms or concerns only. Record verbatim any spontaneous disclosures or statements of significance that the child makes during the course of the history or physical examination.
Document past medical history including any previous genitourinary trauma, urinary tract or anogenital infections, discharge, or toileting concerns.
Note immunization status and any recent medications.
Physical Examination
Much emphasis is placed on the importance of the physical examination, even though most pediatric victims of sexual abuse have a normal examination. If the child’s disclosure suggests the abuse was remote to the time of presentation, then a straightforward physical examination to ensure that the child is currently physically well may be all that is required in the ED. All children should have a parent or supportive adult who is known to them present during the examination. Explain the procedure for the assessment prior to beginning the examination, addressing any parental concerns in advance. For the child, a simple age­appropriate review of systems generally guides them through the various body parts being evaluated.
Do not force the examination. Subtle distraction techniques and frequent gentle reassurance are helpful. If the child remains uncooperative, decide whether the examination should continue under procedural sedation or general anesthesia or whether the assessment can be rebooked for a future time.
A complete examination begins with a comment on the child’s overall appearance including emotional state and demeanor. Prior to palpation, ask the child about any painful areas. Thoroughly inspect all parts of the skin and hair and document bruises, petechiae, abrasions, areas of swelling, or bite marks. Carefully examine the oropharynx for signs of trauma.
Anogenital Examination
Examination of the anogenital area can generally be accomplished with inspection only. The supine, frog­leg position optimizes visualization of the genital structures. Speculum examinations are not required in the prepubescent child. If the hymenal margin is not well visualized while supine or if abnormalities are suspected, then examine the child in the prone knee­chest position. This position allows gravity to pull the margins of the hymen down into clearer view. Toddler­age children who are reluctant to undergo genital examination may be examined while lying supine in the parent’s lap.
A systematic approach to anogenital examination is helpful to ensure complete documentation. Initial inspection details the appearance of the labia majora, labia minora, and the posterior fourchette. With gentle separation and traction of the labia, the clitoris, urethra, hymen, vaginal vault, and fossa navicularis come into view (Figure 150­6). Describe relevant findings using a “clock face” orientation, with  o’clock being anterior/superior and  o’clock being inferior/posterior. Document any evidence of trauma including bruising, bleeding, edema, lacerations, or abrasions. Accidental genital trauma typically results in bruises or abrasions to the labia or posterior fourchette. The hymen is rarely injured with accidental trauma given its more protected, recessed position. Note all nonspecific findings of erythema, ulceration, hypopigmentation, or discharge. Describe the hymen by noting both the shape and the integrity of the hymen margin (Figure 150­7). Typically, the hymen is thickened and redundant at both infancy and puberty, due to maternal hormonal effect at birth and endogenous hormonal effect later. Small mounds (bumps), tags, or rolled edges are common
 nonspecific findings contributing to a wide degree of variation in normal genital morphology. Note any deep notches or clefts to the rim of the hymen as well as any transections, either acute or healed, that extend to the base of the hymen. Acute superficial lacerations generally heal well with no intervention; however, deeper lacerations with extension into the vagina are less common and should be assessed by a gynecologist and may require exam under anesthesia.
FIGURE 150­6. Normal prepubertal genital anatomy.
FIGURE 150­7. Normal hymen morphology.
Genital examination of young boys is generally more straightforward. Note the presence of past circumcision and document any evidence of acute trauma including bruises, bite marks, or petechiae.
Anal examination of both boys and girls is most often normal or nonspecific; however, make note of any acute physical findings including bruising, abrasions, fissures, or edema. Recent anal trauma may result in either spasm of the anal sphincter or anal dilatation. Minor anal dilatation is a normal
 finding, particularly if there is stool present in the rectal vault.
Laboratory and Forensic Investigation
Initial investigation is dictated by history and clinical findings. If the child appears stable, laboratory investigations may be limited to assessment for sexually transmitted infections and/or forensic evidence collection.
Sexually Transmitted Infections
,60
The prevalence of sexually transmitted infections in the pediatric abuse population is exceedingly low, often less than 1% to 4%. Current
 recommendations suggest testing for the presence of sexually transmitted infections in high­risk situations only. High­risk situations include the following: presence of genitourinary symptoms or injury; assailant has or is at high risk for sexually transmitted infection; a sibling has a sexually transmitted infection; or parents and/or patient request testing. A non–clean catch urine should be sent for nucleic acid amplification technique testing for gonorrhea and Chlamydia. Although urine nucleic acid amplification technique testing is an acceptable standard for vaginal infections, it is not yet approved for rectal or oral swabs. For forensic purposes, positive tests should be confirmed with culture or with a second nucleic acid amplification technique probe. Vesicles or ulcerations are not common in the pediatric patient and, if present, should be swabbed for viral studies.
Serologic studies for syphilis and the human immunodeficiency virus are not routinely indicated but may be considered if clinical suspicion warrants or if requested by the patient or parent.
Forensic Specimens
Be familiar with the forensic evidence collection kits provided by the criminal investigation units in your area. All forensic specimens must be properly labeled and packaged, with appropriate chain­of­evidence documentation. Place the child’s underwear and clothing (if worn at the time of the assault) in a paper bag and then seal the bag. Obtain forensic swabs from any areas suspicious for oral, genital, or ejaculatory fluid contact. Examination with an ultraviolet light source may help guide collection of specimens.
TREATMENT AND DISPOSITION
Treatment begins at initial contact with the family. A timely assessment performed by a reassuring health professional is often the first step toward a positive therapeutic outcome for both the patient and family. If the history involves significant behavioral or emotional concerns, a referral to mental health professionals may be indicated on either an urgent or elective basis depending on the child’s current state.
Pharmacologic treatment should be dictated by the individual’s history and physical examination findings. Pregnancy and sexually transmitted infection prophylaxis are not routinely recommended in the young pediatric patient following a disclosure of sexual abuse; however, prophylaxis
,61 should be considered for older girls and adolescents. Arrange counseling and follow­up in an outpatient setting to ensure appropriate repeat assessment. It is important to ensure resolution of any physical injuries, to assess for any new symptoms, and to inquire as to any emotional or behavioral sequelae.
CAREGIVER­FABRICATED ILLNESS
Caregiver­fabricated illness, which has been known in the past as Munchausen syndrome by proxy or pediatric condition falsification, has
 also been termed medical child abuse. This condition is an uncommon form of child abuse in which a parent or caregiver induces and/or fabricates illness or injury in a child. Cases are generally highly complex, often necessitating detailed, comprehensive assessments by multiple subspecialty pediatric teams. Although the role of the emergency physician may seem minor, it is often the detailed emergency documentation of numerous clinical presentations and responses to investigation and intervention that provides objective information needed for eventual diagnosis.
Be alert to the possibility of this condition when presented with a pediatric case that involves persistent or recurrent illness that is not adequately explained and yet results in multiple medical or surgical procedures. Often the medical diagnoses that the caregiver describes do not match the objective findings, and the child tends not to respond to the usual therapies. Hospitalization is often required to coordinate a multidisciplinary evaluation.
REPORTING
Although laws governing the reporting of suspected child maltreatment vary around the world, in all states and provinces in the United States and
Canada, any physician who has reason to believe that a child is at risk of abuse or neglect has a legal obligation to report to local child welfare authorities. The legal duty to report overrides any duty of patient ity. It is not necessary to be certain of the diagnosis of abuse, but one should have reasonable suspicion that abuse or neglect may have occurred. Healthcare providers reporting concerns of suspected maltreatment are protected from civil litigation. Reports must be made in a timely manner due to the risk of future maltreatment to other children in the home.
Informing parents of your obligation to report to child protection services should be respectful and nonaccusatory. Communication should focus on accurately identifying the underlying medical problem, managing the child’s injuries, and providing honest, straightforward medical information.
In some cases, particularly when parents are engaged in legal custody disagreements, the history may be quite vague and the physical examination may be entirely normal. If the only concern for abuse or neglect is with the parent or guardian and there is no disclosure from the child and no witnessed abuse or concerning physical findings, then the emergency physician may provide the parent with the appropriate information to make a report on their own. Be familiar with local laws and the methods for reporting. If uncertainty exists about the need to report, consult with a child abuse pediatric specialist.


