## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 242: Ear Disorders
Kathleen Hosmer
INTRODUCTION
This chapter discusses common nontraumatic conditions affecting the external, middle, and inner ear. Lacerations to the ear are discussed in Chapter
, “Face and Scalp Lacerations.” Ear disorders in children are discussed in Chapter 121, “Ear and Mastoid Disorders in Infants and Children.”
ANATOMY
EXTERNAL EAR
The auricle, or pinna, is the visible external portion of the ear, whose trumpet shape enables it to collect air vibrations. It consists of a thin plate of elastic cartilage with a tightly adherent covering of skin. The external auditory canal is an S­shaped, skin­lined tube that extends from the auricle to the tympanic membrane (TM). The outer one third of the external auditory canal is composed of an incomplete cartilaginous tube. Its thick skin supports hair follicles plus apocrine and sebaceous glands. The inner two thirds of the canal is composed of bone covered by a thin layer of tightly adherent skin, which is easily torn by minimal trauma.
The blood supply to the external ear is derived from the posterior auricular, superficial temporal, and deep auricular arteries. Venous drainage of the external ear is into the superficial temporal and posterior auricular veins, which then drain into the external jugular vein. The posterior auricular vein frequently connects to the sigmoid sinus, providing a route for extension of infected material into the intracranial cavity.
MIDDLE EAR
The middle ear is an air­containing cavity in the petrous temporal bone. It contains the auditory ossicles, which transmit vibrations of the TM to the perilymph of the internal ear. It communicates with the nasopharynx anteriorly via the eustachian tube and with the mastoid air spaces posteriorly via the aditus ad antrum (Figure 242­1).
FIGURE 242­1. Sagittal section of the middle ear and related structures.

Chapter 242: Ear Disorders, Kathleen Hosmer 
. Terms of Use * Privacy Policy * Notice * Accessibility
The TM is a thin, pearly gray, fibrous membrane that produces a cone­shaped light reflex anteroinferiorly when illuminated. Superiorly, the pars flaccida is the relatively slack portion of the membrane between the malleolar folds; the remainder of the membrane is tense and is called the pars tensa. The auditory ossicles are the malleus, incus, and stapes. Both the incus and the handle and lateral processes of the malleus are typically visible through the TM (Figure 242­2). Figure 242­1 shows the relationships of the facial nerve, sigmoid sinus, and internal carotid artery to the middle ear.
FIGURE 242­2. Right tympanic membrane as seen through the otoscope.
INNER EAR
The inner ear consists of the cochlea, which contains the auditory sensory receptors, and the vestibular labyrinth, which contains balance receptors.
Cristae in the semicircular canals detect angular acceleration, and macules detect linear acceleration. Afferent nerves from the vestibular labyrinth connect to brainstem nuclei to maintain smooth movement of the eyes during head movement and to the cerebellum to control oculomotor and postural functions. Blood supply is from the vertebrobasilar system (Figure 242­3). The otolithic organs (utricle and saccule) lie in the vestibule. The internal auditory artery divides into the common cochlear artery and the anterior vestibular artery. The anterior vestibular artery provides the blood supply to the anterior and horizontal semicircular canals but not to the cochlea. Isolated occlusion of the anterior vestibular artery may therefore cause acute vestibular syndrome without hearing loss.
FIGURE 242­3. Schematic of the bony labyrinth containing the vestibular and auditory sensory organs.
OTALGIA

Primary otalgia is caused by auricular and periauricular disease, whereas referred otalgia is caused by disease originating from remote structures.
Referred otalgia is common because the ear and several structures of the head and neck share sensory innervation from the fifth, seventh, ninth, and
 tenth cranial nerves, as well as by the cervical plexus. Table 242­1 lists common causes of primary and referred otalgia, including related neuralgias.
TABLE 242­1
Causes of Otalgia
Primary Referred
Trauma Temporomandibular dysfunction syndrome
Infection Dental
Otitis externa Abscessed teeth/dental carries
Otitis media Malocclusion
Mastoiditis Bruxism
Bullous myringitis
Pinna cellulitis Retro­ and oropharyngeal
Cerumen impaction Tonsillitis
Cholesteatoma Abscess
Neoplasms
Neoplasm
Eustachian tube dysfunction
Foreign bodies Nasal cavity
Sinusitis
Facial neuralgias with periauricular pain Deviated septum
Trigeminal Throat and neck
Herpetic geniculate (Ramsay Hunt syndrome) Foreign body
Great auricular neuralgia Thyroid disease
Neoplasm
TINNITUS
Tinnitus is the perception of sound without external stimulation. It may be constant, pulsatile, high­ or low­pitched, hissing, clicking, or ringing. It is
 most prevalent between the ages of  and  years old.
Tinnitus is divided into two types: objective and subjective. Objective tinnitus may be heard by the examiner. Subjective tinnitus is more common. Its
 exact origin is unknown, although it is believed to result from damage to cochlear hair cells. Table 242­2 outlines causes of tinnitus.
TABLE 242­2
Common Causes of Tinnitus
Objective Subjective
Vascular Sensorineural hearing loss
Arteriovenous malformations Hypertension
Arterial bruits Conductive hearing loss
Mechanical Head trauma
Enlarged eustachian tube Medication side effects
Palatomyoclonus Temporomandibular joint disorders
Stapedial muscle spasm Depression, anxiety
Neurologic
Acoustic neuroma
Multiple sclerosis
Benign intracranial hypertension
Ménière’s disease
Cogan’s syndrome

A number of drugs are associated with tinnitus, and some also cause hearing loss (Table 242­3).
TABLE 242­3
Ototoxic Agents Causing Tinnitus or Hearing Loss
Loop diuretics Chemotherapeutic agents
Ethacrynic acid Cisplatin
Furosemide Carboplatin
Bumetanide Vinblastine
Salicylates* Vincristine
NSAIDs* Topical agents
Quinine Solvents
Antibiotics Propylene glycol
Aminoglycosides* Antiseptics
Erythromycin Ethanol
Vancomycin Erectile Dysfunction Drugs
Polymyxin B Tadalafil
Neomycin Sildenafil
*Most commonly implicated agents.
Accurate diagnosis usually requires referral to an otolaryngologist. Many medications have been suggested as therapies; antidepressants may help patients tolerate tinnitus but do not change the course.
SUDDEN HEARING LOSS
Sudden hearing loss occurs over  days or less and is divided into sensorineural (cochlea, auditory nerve, or central auditory processing) and conductive (external ear, TM, and ossicles). Conductive hearing loss is more likely due to a reversible cause, such as otitis media, serous otitis, or a
 cerumen impaction. Indicators of poor prognosis include more severe hearing loss on presentation and the presence of vertigo. Table 242­4 lists causes of sensorineural hearing loss.
TABLE 242­4
Causes of Sudden Hearing Loss
Cause Examples
Idiopathic (71%)
Infection (12.8%) Mumps
Epstein­Barr virus
Herpes simplex virus
Toxoplasma gondii
Syphilis
Group A Streptococcus
Meningitis
Otologic disease (4.7%) Ménière’s disease
Skull base or otologic surgery
Autoimmune disease
Trauma (4.2%) Head Injury
Acoustic trauma
Barotrauma
Vascular or hematologic (2.8%) Cardiovascular disease
Neurovascular disease
Hemorrhage (brain)
Neoplastic (2.3%) Vestibular schwannoma
Cerebellar angioma
Other causes (2.2%) Pregnancy related
Nonotologic surgery

Viral infections, most typically mumps, have long been associated with sudden hearing loss. Because of the terminal branches and interosseous location of the blood supply to the inner ear, the ear is uniquely vulnerable to a variety of vascular and hematologic diseases. Sudden hearing loss may also be caused by rupture of the TMs.
The evaluation begins with a complete history and physical examination. Differentiate conductive hearing loss from sensorineural hearing loss with a tuning fork. To perform the Weber test, place a vibrating tuning fork on the forehead and ask the patient where it is heard. It is normal to hear it equally in both ears; if the sound lateralizes to one ear, there is conductive hearing loss in that ear, or there is sensorineural loss in the opposite ear. To perform a Rinne test, place the tuning fork on skin over the mastoid bone, and then move the tuning fork to the entrance of the ear canal on the same side. The sound is normally heard better through air conduction at the entrance of the ear. If the sound is heard better over the mastoid bone, there is conductive hearing loss. Sudden conductive hearing loss may result from obstruction of the external auditory canal or from disturbances of the TM or ossicles. Evaluate all current medications for possible ototoxic agents. A history of trauma or recollection of a “popping” noise preceding the hearing loss may indicate perforation of the TM or ossicle dislocation. Coexistent tinnitus or vertigo may point to Ménière’s disease.
The differential diagnosis includes both potentially reversible and potentially ominous causes (Table 242­4). If the physical examination does not identify the cause, otolaryngology consultation is necessary. Initial treatment of idiopathic sensorineural hearing loss is  milligrams of prednisone
5­8 once daily for  to  days with follow­up arranged within  weeks.
ACUTE DIFFUSE OTITIS EXTERNA
Otitis externa includes infections and inflammation of the external auditory canal and auricle. It is divided into acute diffuse and malignant types.
PATHOPHYSIOLOGY AND MICROBIOLOGY
Predisposing factors for the development of otitis externa are trauma to the skin of the external auditory canal and elevation of the local pH. Factors include frequent contact with water from swimming or bathing in hot tubs, pools, or freshwater lakes, and living in a humid environment. Trauma is most commonly due to scratching or overzealous disimpaction of cerumen. Cerumen is an acidic mixture of sebaceous and apocrine gland secretions and desquamated epithelial cells. It forms a physical barrier that protects the skin of the external auditory canal, whereas the acidic pH has antimicrobial properties.
,10
The most common organisms are Pseudomonas aeruginosa, Staphylococcus aureus, Staphylococcus epidermidis, and Enterobacteriaceae.
Otomycosis, or fungal otitis externa, is found in tropical climates and in the immunocompromised or after previous long­term therapy with antibiotics.

Most cases are caused by Aspergillus or Candida. Noninfectious causes include contact dermatitis from topical medications or resins in hearing aids, seborrhea, and psoriasis.
CLINICAL FEATURES
Otitis externa, or swimmer’s ear, is characterized by pruritus, pain, and tenderness of the external ear. Physical signs include erythema and edema of the external auditory canal, which may spread to the tragus and auricle. Other signs are clear or purulent otorrhea and crusting of the external canal.
As the disease progresses, the pain may become intolerable and occur with mastication or any movement of the periauricular skin. Increasing edema may eventually narrow the canal lumen and can lead to hearing impairment. In severe cases, infection may spread to the periauricular soft tissues and lymph nodes, and there may be lateral protrusion of the auricle secondary to inflammation.
TREATMENT
The treatment consists of analgesia, cleansing of the external auditory canal, acidifying agents, topical antimicrobials with or without steroids, and, in
,13 cases of edema obstructing the canal, adding an ear wick. Cleansing may be done with gentle irrigation using hydrogen peroxide or saline or gentle
 suction under direct visualization. Nonototoxic ototopical antibiotics are first­line therapy, particularly when the integrity of the TM is unknown or in
 the presence of a known TM perforation or tympanostomy tubes. Recommended topical agents are listed in Table 242­5. Although there are few established cases of ototoxicity, there is a theoretical risk of both auditory and vestibular toxicity with the use of aminoglycosides, polymyxin, and
 acetic acid preparations.
TABLE 242­5
Topical Agents for Acute Otitis Externa
Agent Comments
Ciprofloxacin, dexamethasone Safe with perforations
Ofloxacin Safe with perforations
Ciprofloxacin, hydrocortisone Not safe with perforation
2% acetic acid solution pH .5–6.0 (not safe with perforation)
Acetic acid, hydrocortisone pH .0 (not safe with perforation)
Neomycin/polymyxin B/hydrocortisone Ototoxic; avoid in chronic otitis externa
If cost is a factor and there are no known contraindications, acetic acid drops may be used. In this case, a suspension should be used and not a solution; theoretically, this has less chance of middle ear penetration and resultant ototoxicity.
Instill the medication into the cleansed ear with the ear facing up, with this position held for  minutes.
For cases unresponsive to initial treatment, cultures should be obtained. Oral antibiotics are reserved for febrile patients and those with periauricular
 extension. Instruct patients with otitis externa to avoid predisposing factors to eliminate recurrences. Strategies include earplugs while swimming or bathing (cotton wool impregnated with petroleum jelly or commercial earplugs), brief use of a hair dryer to remove water from the ear canal, and avoiding cotton­tipped applicators or other devices to remove cerumen.

If fungal infection is suspected, topical clotrimazole 1% solution can be used, although its safety in perforated TMs has not been established.

Alternatively, systemic treatment with an antifungal agent such as fluconazole can be used. Instruct patients to follow up with their primary physician or an otolaryngologist in  week to be reevaluated; they should return to the ED for sudden worsening with fever or marked swelling.
MALIGNANT OTITIS EXTERNA
Malignant otitis externa is a potentially life­threatening infection of the external auditory canal involving the pinna and soft tissues with variable extension to the skull base.
PATHOPHYSIOLOGY AND MICROBIOLOGY
Malignant otitis externa begins as a simple otitis externa that then spreads to the deeper tissues of the external auditory canal and infects cartilage, periosteum, soft tissue, and bone, with the normal anatomy of the ear serving as the conduit for the spread of infection. The majority of cases are
  caused by P. aeruginosa, but methicillin­resistant S. aureus now accounts for 15% of cases. Fungal disease occurs in diabetics and patients with
 immunocompromise. The cerumen of diabetic patients has a higher pH than that of normal controls and represents an additional breakdown in local defense mechanisms. Small blood vessel disease of diabetics may lead to cartilaginous degeneration, further promoting the spread of infection.
CLINICAL FEATURES AND DIAGNOSIS
An individual with persistent otitis externa despite  to  weeks of topical antimicrobial therapy should be suspected of having malignant otitis externa.

The typical presentation is severe otalgia (90%) and edema of the external auditory canal with otorrhea (70%). Granulation tissue may be evident on the floor of the external auditory canal.
Examine both ears, inspecting both pinnas from the anterior, lateral, and posterior aspects. The infected ear will be erythematous, edematous, and more prominent than the unaffected ear. Assess nearby structures. Parotitis may be present, and trismus indicates involvement of the masseter muscle or temporomandibular joint. Cranial nerve involvement is a serious sign. The seventh cranial nerve is usually the first nerve affected by cranial extension, and the presence of dysfunction of the ninth, tenth, or eleventh cranial nerve implies even more extensive disease. Lateral or sigmoid sinus thrombosis and meningitis are more serious possible complications. Clinical diagnosis and staging are confirmed with CT or MRI of the head. Ten
 percent of admitted patients develop sepsis, mostly in the elderly.
TREATMENT

Start ciprofloxacin 400 milligrams IV every  hours in adults. Selected cases of early infection may be managed as outpatients with oral quinolones,

750 milligrams of ciprofloxacin two to three times daily. Mild cases are likely to completely resolve with a single course of antibiotic therapy, whereas more advanced stages may require IV antibiotics and possible surgical debridement with otolaryngology. If septic, resuscitate with fluids, and start broad­spectrum antibiotics to cover methicillin­resistant S. aureus and P. aeruginosa (see Chapter 151, “Sepsis”).
OTITIS MEDIA
Otitis media (OM) is primarily a disease of infancy and childhood (see Chapter 121 for management of OM in children). Although the management of
OM in children and adults is similar, there are important differences in adults, highlighted in the following section, especially for the management of
OM with effusion.
PATHOPHYSIOLOGY AND MICROBIOLOGY
,22
Acute OM is much less common in adults than children, by a factor of  to  times. The most common bacterial pathogens recovered in adults
,22,23 with acute OM are Streptococcus pneumoniae, Haemophilus influenzae, methicillin­sensitive S. aureus, and P. aeruginosa. Only young adults have received the H. influenzae type b vaccine, and thus older adults remain unprotected from all Haemophilus strains. The predominant organisms
 involved in chronic OM are S. aureus, P. aeruginosa, Aspergillus, and less commonly, anaerobic bacteria. OM with effusion is differentiated from acute OM. In adults, OM with effusion is frequently associated with significant pathology: acute or chronic sinusitis in 66% of cases, smoking­induced
 nasopharyngeal lymphoid hyperplasia and adult­onset adenoidal hypertrophy in 19%, and head and neck tumors in .8%. Adult patients with OM
 with effusion may also have symptoms of gastroesophageal reflux.
CLINICAL FEATURES AND DIAGNOSIS
Unlike children, adults with OM frequently lack the prodrome of an upper respiratory infection and may present simply with significant otalgia, with or
,22,23 without fever. Otorrhea and hearing loss are variably present, whereas tinnitus, vertigo, and nystagmus are uncommon but possible findings.
The TM may be retracted or bulging. It may be red in color, indicating inflammation, or it may be yellow or white, as a result of middle ear fluid.
Pneumatic otoscopy almost uniformly demonstrates impaired mobility. Always assess facial nerve function because of its proximity to the middle ear.
TREATMENT

There are no treatment guidelines specifically for adults. The “wait­and­see” method recommended in children has not been evaluated in adults.

The preferred initial treatment is amoxicillin 1000 milligrams three times daily. Alternative agents include extended­release amoxicillin­clavulanate
2000/125 milligrams twice daily, cefdinir 300 milligrams twice daily, or cefpodoxime 200 milligrams twice daily. For OM unresponsive to initial therapy after  hours, consider changing to amoxicillin­clavulanate, levofloxacin, or moxifloxacin. OM with effusion requires treatment with the same
 antimicrobials but for  weeks. Oral corticosteroids for OM with effusion provide a limited benefit in children (number needed to treat = 14), but the benefit in adults is not known.
Adults with simple acute OM should receive follow­up to assess treatment efficacy and to ensure that there is no anatomic obstruction to the eustachian tube, as, for example, from occult neoplasm. Any patient who presents with complications of OM or who appears septic should have urgent consultation for diagnostic and therapeutic tympanocentesis and admission for IV antibiotics.
COMPLICATIONS OF OTITIS MEDIA
Complications of OM are intratemporal and intracranial. Perforation of the TM is a common intratemporal complication and most often occurs in the pars tensa from the increased pressure of middle ear secretions, with resultant otorrhea. Healing usually occurs in  week, although a chronic perforation may result. A temporary conductive hearing loss may occur secondary to fluid in the middle ear. Hearing loss should resolve as the fluid is resorbed. Acute serous labyrinthitis may occur when bacterial toxins enter the inner ear via the round window. Facial nerve paralysis is an uncommon complication but requires emergent otolaryngology consultation.
Acute Mastoiditis
Acute mastoiditis results from spread of infection from the middle ear to the mastoid air cells by the aditus ad antrum. When this opening becomes blocked, the mastoid cavity becomes a closed space, and the mastoid air cells become inflamed and fill with fluid. In addition to otalgia, fever, and otorrhea (especially in patients with Pseudomonas), patients with mastoiditis will have postauricular erythema, swelling, and tenderness, and if it progresses, protrusion of the auricle and obliteration of the postauricular crease. Diagnosis is suspected based on the history and physical examination and confirmed with a contrasted CT. Mastoiditis with bony involvement requires admission for IV antibiotics, tympanocentesis, and
,29 myringotomy. The most common pathogens are S. pneumoniae, Streptococcus pyogenes, and P. aeruginosa. For an initial episode, treat with
  ceftriaxone  grams IV or levofloxacin 750 milligrams IV. For recurrent episodes, treat with vancomycin and piperacillin/tazobactam, or imipenem.
Incision and drainage of subperiosteal abscess or mastoidectomy may ultimately be required.
Intracranial Complications
Intracranial complications of OM are more likely with chronic than with acute OM and are, in general, decreasing with the widespread use of antibiotics in the treatment of OM. However, suppurative intracranial extension is a severe complication, and suggestive signs and symptoms should be investigated appropriately. Meningitis and brain abscess are the most common intracranial complications of OM, with an incidence of .42 per 100,000
  per year. The most prevalent causative organisms are S. pneumoniae and Neisseria meningitidis. Extradural abscess and subdural empyema are also potential complications.
Lateral Sinus Thrombosis
Lateral sinus thrombosis is another ominous complication of acute OM. It arises from extension of infection and inflammation in the mastoid, with eventual inflammation of the adjacent lateral or sigmoid sinus. Reactive thrombophlebitis with mural clot formation, intraluminal empyema, or perforation of the venous wall may occur.
Headache is the most common symptom, with papilledema, sixth­nerve palsy, and vertigo being less frequently present. Angiography with venous phase and MRI are more sensitive than CT in diagnosing lateral sinus thrombosis. The employed antibiotic regimen should cover Staphylococcus,
Streptococcus, and upper respiratory anaerobes (Bacteroides fragilis) and have good penetration of the blood–brain barrier. A combination of
 cefepime  grams IV, metronidazole 500 milligrams IV, and vancomycin  gram IV is one regimen recommended. Otolaryngology should be consulted
 for expected mastoidectomy.
BULLOUS MYRINGITIS
Bullous myringitis is a painful condition of the ear characterized by bulla formation on the TM and deep external auditory canal. The blisters are believed to occur between the highly innervated outer epithelium and the inner fibrous layer of the TM, explaining the severe otalgia. The blisters may be blood filled, serous, or serosanguineous. Reactive middle ear effusions may accumulate. Otorrhea as a result of ruptured bullae is short lived. A reversible hearing loss is commonly associated with the condition and may be conductive, sensorineural, or mixed. This disorder is not caused by

Mycoplasma pneumoniae, as commonly believed, but is a severe manifestation of the typical organisms that cause OM. Treatment is as the same as for acute OM, discussed earlier.
EAR HEMATOMA
An auricular hematoma can develop from almost any type of trauma to the ear. As a result of the lack of subcutaneous fat on the anterior surface of the auricle, blunt force applied to this area tends to shear the perichondrium from the underlying cartilage and tear the adjoining blood vessels. Any interruption of the nourishing blood supply can result in necrosis. The resultant deformed auricle has been referred to as “cauliflower ear,” which is commonly seen in boxers or wrestlers secondary to repeated head/ear trauma. The auricular hematoma itself is a painful swelling, which obscures the normal contour of the ear. The hematoma may accumulate immediately or several hours following an injury. Aspiration alone does not completely evacuate the clot and therefore leads to deformity and increased morbidity. The goal of treatment is to remove the fluid collection and maintain pressure in the area for several days to prevent reaccumulation of fluid.
Using sterile technique after local anesthesia, make a semicircular incision through the skin, and be careful not to incise the underlying perichondrium. The incision should be the minimal necessary to drain the underlying hematoma and be positioned in an area with the least chance of cosmetic deformity. This is usually accomplished by incising the skin inside the inner curvature of the helix or anthelix. The hematoma can then be removed by gentle suction or curettage. Suture the incision after hematoma removal.
There are a few ways to prevent the hematoma from recurring. Place a dental roll or a firm sterile pledget coated with antibiotic ointment over the resutured site with through­and­through sutures connected to a similar bolster on the opposite side of the ear. Apply a light nonpressure dressing and reevaluate the ear within  hours to ensure there has been no reaccumulation of the hematoma. A pressure dressing can also be used if you do not want to suture a dental roll though the cartilage. Simply pack the helix with petroleum jelly–impregnated gauze and then place regular gauze both in front of and behind the ear. Lastly circle the head with a compressive wrap (Figure 242­4). Prophylactic antibiotics can be reserved for immunocompromised patients and should cover P. aeruginosa and S. aureus, the two likely participants in posttraumatic chondritis.
FIGURE 242­4. Stepwise progression to build an auricular bandage to help compress a drained hematoma in the auricle of the ear. Use a petroleum jelly–impregnated gauze inside the helix of the ear (A) and then add dry gauze to both the back (B) and front (C) of the ear. D. Wrap it lightly to add slight compression to hold the perichondrium to the auricular cartilage.
EAR FOREIGN BODIES
Cerumen loops/scoops, a right­angle hook, and alligator forceps are the instruments of choice for the removal (Figure 242­5). Live objects should be drowned with a 2% lidocaine solution, which immediately paralyzes the offending insect and provides modest topical anesthesia. The liquid can then be suctioned out with butterfly tubing and the insect removed with gentle suction or forceps under direct visualization. Remove all insect debris from the canal.
FIGURE 242­5. Different­shaped ear scoops and loops are useful to remove cerumen from an impacted ear. Miniature alligator forceps can be used to extricate foreign bodies from the external ear canal.
Irrigation with room­temperature water is adequate for small particles such as hard sand or cerumen and can mobilize distally positioned objects.
Irrigation should not be used unless the TM is completely visualized and free of perforation. Organic matter that can expand when moistened is also a relative contraindication to irrigation.
Inspect the ear canal after removal of the foreign body to exclude injury to the canal skin, TM, and ossicles caused by the foreign body or its extraction.
Small abrasions heal spontaneously. Topical antibiotics should be considered in cases where there was more serious cutaneous damage or where the foreign body consisted of organic material or generated a local inflammatory reaction (Table 242­5).
CERUMEN IMPACTION
Symptoms of cerumen impaction are decreased hearing, a sensation of pressure or fullness in the ear, dizziness, tinnitus, or otalgia. Most of the time, cerumen loops/scoops can be used to remove impacted cerumen (Figure 242­5). In particularly difficult cases or when the canal is completely occluded, softening of the material can be accomplished using half­strength hydrogen peroxide, docusate sodium, sodium bicarbonate, mineral oil, or an over­the­counter preparation such as Debrox® (carbamide peroxide otic). Left in place for  minutes, such preparations soften the cerumen and facilitate its removal. If irrigation is the treatment of choice, it can usually be accomplished with an ear syringe, a flexible 18­gauge IV catheter, or a syringe attached to the tubing of a butterfly infusion catheter. Pretreatment with agents such as triethanolamine polypeptide oleate (Cereuminex®)
 improves success rates, but no pretreatment is superior to another. Use body­temperature irrigant to minimize the development of vertigo. Insert the catheter into the cartilaginous canal (external third) and gently irrigate along the superior portion of the external auditory canal. Using this technique, the pressure of the stream is directed toward the wall of the canal and not the TM. Irrigation of the canal when the middle ear is not infected often causes a temporary redness of the TM.
The most common iatrogenic injury associated with syringing of the ear is traumatic TM perforation. Predisposing factors for perforation include previous ear surgery, a previous or current history of OM, and severe otitis externa. When in doubt, it is safer to defer irrigation/cerumen removal to an otolaryngologist. When determining if a perforation has occurred, it is important to rely on symptoms (sudden hearing loss, severe otalgia, or vertigo) rather than signs, because visualization of the TM may be impaired by the irrigating fluid and debris. In case of suspected perforation, reassurance, analgesia, and otolaryngology referral in  week are indicated. Prophylactic antibiotics are not necessary.
TYMPANIC MEMBRANE PERFORATION
TM perforations can occur secondary to middle ear infections or as a result of barotrauma, blunt/penetrating/acoustic trauma, or, on rare occasions, lightning strikes. When it is secondary to blunt or noise trauma, the perforation almost always occurs in the pars tensa, usually anteriorly or inferiorly.
The pars tensa, the largest area of the TM, is only a few cell layers thick and thus is easily torn.
Symptoms are acute onset of pain and hearing loss, with or without bloody otorrhea. There may also be associated vertigo or tinnitus, but this is usually transient unless there has been injury to the inner ear or rupture of the round or oval windows. The TM should be completely visualized and the canal must be cleared of blood and debris.
Most TM perforations heal spontaneously. Patients with perforations secondary to blunt or noise trauma that are isolated injuries can be safely discharged and referred to a specialist for further evaluation and a formal audiogram as soon after the injury as possible. Patients should be instructed not to allow water to enter the canal of the ear. Topical or systemic antibiotics are not needed unless foreign material is suspected of remaining in the canal or in the middle ear. Perforations in the posterosuperior quadrant or those secondary to penetrating trauma have a greater likelihood of ossicular chain damage and should be referred to an otolaryngologist within  hours.
COMPLICATIONS OF COCHLEAR IMPLANTATION
Cochlear implantation functions through electronic stimulation of the auditory nerves in the cochlea in patients with bilateral moderate to severe
 sensorineural hearing loss. Common complications include vestibular complaints, device failure, and infection. Infections include skin infection, OM,
34­39 mastoiditis, and meningitis. If infection is a concern, then a CT with IV contrast is needed to evaluate position of the implant, fluid collections, bony
 involvement, and subperiosteal abscess. Recurrent OM in patients with cochlear implants can result in meningitis. Meningitis can occur days to years
34­42 after implantation, with the greatest risk in the first  months.
,40,41
The most common complication is dizziness or vestibular symptoms, which occur in close to 4% of patients. Facial nerve weakness is rare but
 can present acutely or as a delayed complication. Device failure is the next most common complication and may require CT and device integrity
,43  testing. Other rare complications include cholesteatoma, seroma, hematoma, cerebrospinal fluid leak, and TM perforation.


