## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 71A: Acute Abdominal Pain
David A. Masneri; Mary Claire O’Brien
INTRODUCTION AND EPIDEMIOLOGY
More adult patients visit the ED for “stomach and abdominal pain, cramps, or spasms” than for any other chief complaint.1 Demographics (age, gender, ethnicity, family history, sexual orientation, cultural practices, geography) influence both the incidence and the clinical expression of abdominal disease.1 History, physical examination, and laboratory studies can be helpful, but imaging is often required to make a specific diagnosis. Clinical suspicion for serious disease is especially important for patients in high­risk groups.
PATHOPHYSIOLOGY
Abdominal pain is divided into three neuroanatomic categories: visceral, parietal, and referred.
VISCERAL PAIN
Obstruction, ischemia, or inflammation can cause stretching of unmyelinated fibers that innervate the walls or capsules of organs, resulting in visceral pain. Visceral pain is often described as “crampy, dull, or achy,” and it can be either steady or intermittent (colicky). Because the visceral afferent nerves follow a segmental distribution, visceral pain is localized by the sensory cortex to an approximate spinal cord level determined by the embryologic origin of the organ involved (Table 71­1).
TABLE 71­1
Visceral Pain Features
Embryologic Origin Involved Organs Location of Visceral Pain
Foregut Stomach, first/second parts of duodenum, liver, gallbladder, pancreas Epigastric area
Midgut Third/fourth parts of duodenum, jejunum, ileum, cecum, appendix, ascending colon, first two thirds of transverse colon Periumbilical area
Hindgut Last one third of transverse colon, descending colon, sigmoid, rectum, intraperitoneal GU organs Suprapubic area
Because intraperitoneal organs are bilaterally innervated, stimuli are sent to both sides of the spinal cord, causing intraperitoneal visceral pain to be felt in the midline, independent of its right­ or left­sided anatomic origin. For example, stimuli from visceral fibers in the wall of the appendix enter the spinal cord at about T10. When obstruction causes appendiceal distention in early appendicitis, pain is initially perceived in the midline periumbilical area, corresponding roughly to the location of the T10 cutaneous dermatome.
PARIETAL PAIN
Parietal (somatic) abdominal pain is caused by irritation of myelinated fibers that innervate the parietal peritoneum, usually the portion covering the anterior abdominal wall. Because parietal afferent signals are sent from a specific area of peritoneum, parietal pain—in contrast to visceral pain—can be localized to the dermatome superficial to the site of the painful stimulus. As the underlying disease process evolves, the symptoms of visceral pain give way to the signs of parietal pain, causing tenderness and guarding. As localized peritonitis develops further, rigidity and rebound appear. Patients with peritonitis generally prefer to remain immobile.
REFERRED PAIN
Referred pain is felt at a location distant from the diseased organ. Referred pain patterns are also based on developmental embryology. For example, the ureter and the testes were once anatomically contiguous and therefore share the same segmental innervations. Thus acute ureteral obstruction is often associated with ipsilateral testicular pain. Referred pain is usually perceived on the same side as the involved organ, because it is not mediated by fibers that provide bilateral innervation to the cord. Referred pain is felt in the midline only if the pathologic process is also located in the midline.
CLINICAL FEATURES
CLINICAL RISK
To determine the urgency and method of the diagnostic approach, we recommend the use of a pragmatic scheme based on patient acuity and the identification of risk factors.
Patient Acuity: Is this patient critically ill? If so, simultaneously resuscitate and evaluate.
Risk Factors: Are there special conditions or risk factors that affect clinical risk or mask the disease process?

Patient Acuity: Is This Patient Critically Ill?
Chapter 71A: Acute Abdominal Pain, David A. Masneri; Mary Claire O’Brien 
. Terms of Use * Privacy Policy * Notice * Accessibility
Critically ill patients need immediate stabilization. Markers of high acuity include extremes of age, severe pain of rapid onset, abnormal vital signs, dehydration, and evidence of visceral involvement (e.g., pallor, diaphoresis, vomiting). The intensity of abdominal pain may bear no relationship to the severity of illness. Serious illness may be present even if vital signs are normal, particularly in high­risk groups such as the elderly and the immunocompromised. Shock that develops rapidly after the onset of acute abdominal pain is usually the consequence of intra­abdominal hemorrhage. Systolic pressure does not drop until blood loss reaches 30% to 40% of normal blood volume. Tachycardia is a useful parameter for the assessment of volume depletion, but its absence does not exclude blood/fluid loss. Tachypnea may indicate a cardiopulmonary process, metabolic acidosis, anxiety, or pain. Temperature is neither sensitive nor specific for disease process or patient condition. The presence or absence of fever cannot be used to distinguish surgical from medical disease.
Resuscitation of the critically ill patient with abdominal pain includes a cardiac monitor, oxygen (2 to  L/min via nasal cannula or mask), large­bore IV access, and an isotonic fluid bolus adjusted for age, weight, and cardiovascular status. For critically ill patients, blood samples should be drawn at the time of IV insertion, including, at a minimum, electrolytes, BUN and creatinine, CBC with platelets, clotting studies, and a type and antigen screen of blood. Order cross­matched blood if hemorrhage is suspected or if urgent transfusion is anticipated. A bedside US should be performed rapidly in an attempt to expedite identification of emergent causes of abdominal pain in the patient with hemodynamic collapse. The presence of an abdominal aortic aneurysm and intra­abdominal hemorrhage can be quickly discovered.2 Bedside US can also be used to help assess hemodynamic status by focused evaluation of heart function and inferior vena cava size and respiratory response. This information can help guide resuscitative efforts.
Risk Factors: Are There Special Conditions or Risk Factors That Affect Clinical Risk or Mask the Disease Process?
Identify pertinent past medical illness (diabetes, heart disease, hypertension, liver disease, renal disease, human immunodeficiency virus status, sexually transmitted diseases), previous abdominal surgeries, menstrual history and pregnancies (deliveries, abortions, ectopic), medications (steroids, immune suppressants, acetylsalicylic acid/nonsteroidal anti­inflammatory drugs, antibiotics, laxatives, narcotics, fertility agents, intrauterine devices, chemotherapeutic agents), allergies, and any recent trauma. Ask about previous episodes of similar abdominal pain, diagnostics, and treatments. Review previous medical records. Obtain a social history that includes habits (tobacco, alcohol, other drug use), occupation, possible toxic exposures, and living circumstances (homeless, dwelling heat source, running water, living alone, other family members ill with similar symptoms).
A number of conditions camouflage critical illness in patients with acute abdominal pain. High­risk groups include patients with cognitive impairment secondary to dementia, intoxication, psychosis, mental retardation, or autism; patients who cannot communicate effectively because of aphasia or language barriers; patients in whom physical or laboratory findings may be minimal (the elderly) or obscured (patients with spinal cord injury); asplenic patients; neutropenic patients; transplant patients; patients whose immune systems are impaired by illness
(human immunodeficiency virus; chronic renal disease; diabetes, cirrhosis, hemoglobinopathy; malnutrition, chronic malignancy, autoimmune disease, mycobacterial infection); and patients taking immune­suppressive or immune­modulating medications, such as steroids, calcineurin inhibitors, tumor necrosis factor inhibitors, antimetabolic agents, monoclonal and polyclonal antibodies, and chemotherapeutic agents.
In general, patients with mild to moderate immune dysfunction have delayed or atypical presentations of common diseases. Patients with severe immune dysfunction are more likely to present with opportunistic infections. The CD4 count is the most important measure of immune competency in patients with acquired immunodeficiency syndrome. Patients with CD4 counts over 200/mm3 are much less likely to have opportunistic infections.
HISTORY AND PHYSICAL EXAMINATION
Obtain a clear description of the pain itself (OP2QRST2: onset, provocative/palliative factors, quality, radiation, associated symptoms, timing, and what the patient has taken for the pain).
Before the complete physical examination, take a few moments to gain the patient’s trust by explaining what needs to be done, exposing only what needs to be seen, and re­covering exposed parts of the body sequentially. Provide patient privacy. Note the patient’s skin (color, temperature, turgor, perfusion status), and perform a targeted heart and lung examination.
Inspection
Inspect the abdomen for signs of distention (ascites, ileus, obstruction, volvulus), obvious masses (hernia, tumor, aneurysm, distended bladder), surgical scars (adhesions), ecchymoses
(trauma, bleeding diathesis), and stigmata of liver disease (spider angiomata, caput medusa).
Auscultation of Bowel Sounds
Bowel sounds are nonspecific diagnostic signs. Decreased bowel sounds suggest ileus, mesenteric infarction, narcotic use, or peritonitis. Hyperactive bowel sounds may be noted in small bowel obstruction.
Percussion
Liver size can be estimated by the presence of percussion dullness in the midclavicular line, except in cases of severe bowel distention. A fluid wave may suggest ascites, and tympany may suggest dilated loops of bowel.
Palpation
The vast majority of clinical information is acquired through gentle palpation, using the middle three fingers, and saving the painful area for last. Voluntary guarding (contraction of the abdominal musculature in anticipation of or in response to palpation) can be diminished by asking patients to flex the knees. Those who remain guarded after this maneuver will often relax if the clinician’s hand is placed over the patient’s, and the patient is then asked to use his or her own hand to palpate the abdomen. Distracting the patient with conversation may divert attention from the examination. Optimally, the patient’s tenderness will be confined to one of the four traditional abdominal quadrants (right upper, right lower, left upper, left lower), and pain location can be used to generate a differential diagnosis. Often, this is not the case, and one finds more diffuse tenderness involving two or more of the four abdominal quadrants.
Peritoneal irritation is suggested by rigidity (involuntary guarding or reflex spasm of abdominal muscles), as is pain referred to the point of maximum tenderness when palpating an adjacent quadrant. Rebound tenderness, often regarded as the sine qua non for peritonitis, has several important limitations. In patients with peritonitis, the combination of rigidity, referred tenderness, and pain with coughing usually provides sufficient diagnostic confirmation such that little additional information is gained by eliciting the unnecessary pain of rebound. More than one third of patients with surgically proven appendicitis do not have rebound tenderness.3 False positives occur without peritonitis, perhaps due to a nonspecific startle response. One might reasonably question whether rebound has sufficient predictive value to justify the discomfort it causes patients.
Evaluate the abdominal aorta, particularly in patients >50 years of age with acute abdominal, flank, or low back pain. Palpation cannot reliably exclude abdominal aortic aneurysm, and the presence or absence of femoral pulses is generally not helpful in the clinical diagnosis of abdominal aortic aneurysm.
It is wise to perform a pelvic examination in the evaluation of lower abdominal pain in women of reproductive age who have not had a total hysterectomy. The presence of peritoneal signs, vaginal discharge, cervical motion tenderness, and unilateral or bilateral abdominal and/or pelvic tenderness suggests pelvic infection, or ectopic gestation in pregnant women. In males, hernia, testicular, and prostate examinations are indicated because disorders of these structures can cause lower abdominal pain.
The rectal examination does not increase diagnostic accuracy beyond what has already been obtained by other components of the physical examination. The main value of the rectal examination is the detection of grossly bloody, maroon, or melanotic stool.
One common approach to the evaluation of acute abdominal pain is to use the location of the pain (diffuse, right upper quadrant, right lower quadrant, left upper quadrant, left lower quadrant) to guide the generation of a differential diagnosis (Figure 71­1).4
FIGURE 71­1. Differential diagnosis of acute abdominal pain by location. AKA = alcoholic ketoacidosis; DKA = diabetic ketoacidosis; LLL = left lower lobe; RLL = right lower lobe.
Alternatively, abdominal crises may be grouped according to presenting symptomatology: pain, vomiting, abdominal distention, muscular rigidity, and/or shock (Table 71­2).
TABLE 71­2
Groupings of Known Abdominal Diseases by Symptoms
Pain/vomiting (± rigidity) Pain/vomiting/distention Pain (± vomiting)
Acute pancreatitis Bowel obstruction Acute diverticulitis
Diabetic gastric paresis Cecal volvulus Adnexal torsion
Diabetic ketoacidosis Mesenteric ischemia
Incarcerated hernia Myocardial ischemia* Testicular torsion
Pain/shock Pain/shock/rigidity Distention (± pain)
Abdominal sepsis Perforated appendix Elderly with bowel obstruction/volvulus
Aortic dissection Perforated diverticulum
Hemorrhagic pancreatitis Perforated ulcer
Leaking/ruptured abdominal aortic aneurysm Ruptured esophagus
Splenic rupture
Mesenteric ischemia (late)
Myocardial ischemia* Ruptured ectopic pregnancy
Note: These symptoms and etiologic groupings are a guideline and are not intended to be a rule.
*The symptoms of myocardial ischemia are variable.
Although the location of the patient’s pain and the grouping of symptoms can both help to differentiate among known diseases, clinical suspicion and an understanding of the individual are paramount, because the causes of acute abdominal pain vary considerably with patient demographics. For example, older adults are more likely than younger adults to have biliary disease, diverticulitis, and bowel obstruction. Appendicitis occurs more commonly in younger adults. In the words of Sir William Osler, it is important to know “what sort of patient has the disease.”
SYMPTOM TREATMENT AND FURTHER CLINICAL DIAGNOSIS
At this point, provide symptomatic relief. Do not withhold analgesia from patients with acute undifferentiated abdominal pain. The choice of analgesia agent is dependent upon patient condition, clinical situation, and provider preference. Opioid analgesia relieves pain and will not obscure abdominal findings, delay diagnosis, or lead to increased morbidity/mortality.5,6
The information on the safety of opioids cannot be extrapolated to NSAIDs such as parenteral ketorolac because NSAIDs are not pure analgesics and can mask early peritoneal inflammation.
Opioid medications are not benign. The practice of high­intensity opioid prescribing by EMS providers can contribute to long­term opiod use in their patients.7 Opioids have adverse side effects and potential for abuse. A recent trend toward a decrease in EMS provider prescribing of opioids may reflect increased public awareness of the disadvantages of these medications.1
Administer antiemetics as needed. A Cochrane review reported that ondansetron and metoclopramide reduced postoperative nausea and vomiting.8 Both drugs had equivalent effects.
The dosage of IV ondansetron is  or  milligrams (0.45 milligram/kg total daily) to a maximum of  milligrams daily. Headache is a reported side effect. The dosage of IV metoclopramide is
 milligrams, given slowly to minimize extrapyramidal side effects. Sometimes,  to  milligrams of IV diphenhydramine are administered as prophylaxis against dystonia. Patients with akathisia or dystonic reactions from metoclopramide cannot tolerate any other agents of the same class and should be given ondansetron. Such reactions are extremely rare from ondansetron. (See Chapter , “Nausea and Vomiting,” for further discussion of antiemetics.)
Consider placement of nasogastric and urinary catheters. Nasogastric aspirate may confirm upper GI bleeding, and nasogastric suction may be used to decompress a bowel obstruction. A urinary catheter will relieve bladder obstruction, and hourly urine output helps to gauge renal perfusion.
LABORATORY TESTING
Laboratory testing does not take the place of a conscientious history and physical examination, and there is no evidence to support the usefulness of “routine abdominal labs.” Information obtained by laboratory testing should help refine the differential diagnosis or alter the plan of treatment. Table 71­3 lists laboratory studies that may be appropriate in the evaluation of acute abdominal pain based on the clinical suspicions. Obtain an ECG for patients with upper abdominal pain, especially in elderly patients.
TABLE 71­3
Suggested Laboratory Studies for Goal­Directed Clinical Testing in Acute Abdominal Pain
Laboratory Test Clinical Suspicion
Amylase (if lipase not available) Pancreatitis
Lipase Pancreatitis
β­Human chorionic gonadotropin Pregnancy
Serum or urine Ectopic or molar pregnancy
Qualitative or quantitative
Coagulation studies (prothrombin time/partial thromboplastin time) GI bleeding
End­stage liver disease
Coagulopathy
Electrolytes Dehydration
Endocrine or metabolic disorder
Glucose Diabetic ketoacidosis
Pancreatitis
Gonococcal/chlamydia testing Cervicitis/urethritis
Pelvic inflammatory disease
Hemoglobin GI bleeding
Lactate Mesenteric ischemia
Sepsis
Liver function tests Cholecystitis
Cholelithiasis
Hepatitis
Platelets GI bleeding
Renal function tests Dehydration
Renal insufficiency
Acute renal failure
Urinalysis Urinary tract infection
Pyelonephritis
Nephrolithiasis
ECG Myocardial ischemia or infarction
(Reproduced with permission from Fitch M: Utility and limitations of laboratory studies, in Cline DM, Stead LG (eds): Abdominal Emergencies. New York, NY: McGraw­Hill Medical; 2008, p. .)
Be aware of the limitations of laboratory studies. The CBC does not offer sufficiently powerful likelihood ratios to revise disease probability. In a review of adult patients with appendicitis, only 65% had a serum WBC ≥12,000/mm3.9 A higher degree of leukocytosis was not associated with perforation. One approach to the use of the WBC is to take note only of high threshold abnormalities (e.g., a very elevated WBC [>20,000/mm3]) and to resist the temptation to draw any reassurance from a “normal” WBC. A single WBC cannot exclude serious or surgical disease. Among patients with acute mesenteric ischemia, up to 25% have a normal serum lactate on initial presentation,10 and studies on the utility of serum lactate values are limited by
(among other things) varying intervals from the onset of symptoms to ED presentation. In a large study of patients with acute pancreatitis, serum lipase was 90% sensitive and 93% specific when drawn at the time of ED presentation.11 Nineteen patients had pancreatitis with normal initial lipase levels;  of these had elevated lipase levels when the test was repeated later on the day of admission.11
DIAGNOSTIC IMAGING
Diagnostic imaging does not take the place of a conscientious history and physical examination. Not all patients with abdominal pain require imaging. Moreover, if the clinical impression suggests that the need for surgery is obvious, surgical consultation should be initiated immediately. It is not necessary to wait for diagnostic imaging before surgical consultation.
Plain Radiographs
In some institutions, an “abdominal series” includes an upright abdomen; in others, an upright chest; in still others, only a single supine film is obtained. If plain radiographs are obtained, make sure the inguinal region is included to help identify incarcerated hernia. Radiographic evidence of small bowel obstruction may be seen  to  hours before symptoms develop.
However, signs may be absent in up to half of patients with developing small bowel obstruction.12,13 Although an upright chest film is better to detect free air than an abdominal film, the sensitivity for small amounts of free air is only about 30%.12,13 The use of plain abdominal radiographs should be limited to screening for obstruction, sigmoid volvulus, perforation, or severe constipation.
Ultrasound
In adults, an abdominal US examination can visualize the gallbladder, pancreas, kidneys and ureters, urinary bladder volume, and aortic dimensions. Abdominal US is not useful for diagnosis of small or large bowel disorders. The detection of free air or appendicitis by US is operator dependent and limited by patient obesity and bowel gas.14
US is the preferred modality for the evaluation of biliary tract disease. When acute cholecystitis or biliary dyskinesia is strongly suspected but the US is normal, cholescintigraphy is recommended.
POCUS
EMS POCUS use continues to rise, and many ED physicians have incorporated this modality into routine practice.15 Abdominal resuscitative POCUS involves rapid assessment for free intraabdominal fluid (FAST), abdominal aortic aneurysm, and cardiac/inferior vena cava status. Abdominal diagnostic POCUS studies are focused urinary tract and biliary evaluations.15
Abdominal­Pelvic CT Scanning
CT scanning is a sensitive and specific diagnostic tool for many causes of abdominal pain. Its clinical usefulness is balanced by delays in surgical management and increase in ED times if oral contrast is used and by radiation dose.16 The radiation dose of abdominal CT is about  mSv, about  times that of plain abdominal radiographs.12
Options for CT scanning include noncontrast studies, or PO, PR, and/or IV contrast. Protocols vary depending on institutional, surgical, and radiology protocols; the prior probability of specific GI disorders in the patient population served; and individual radiologist preference. There are many contradictory studies on the best approach, especially for undifferentiated abdominal pain, for which the differential diagnosis is broad. Most studies have focused on the CT diagnosis of appendicitis.17
Noncontrast abdominopelvic CT has about 97% specificity for the diagnosis of acute appendicitis, with the possible exception of patients with a low body mass index (<25 kg/m2).
Noncontrast CT is the preferred imaging modality for the diagnosis of kidney and ureteral stones.
The use of oral contrast for the ED diagnosis of acute abdominal pain as a general protocol has been called into question.17,18 Factors that affect the usefulness of oral contrast include patient vomiting, type and volume of oral contrast administered, transit time to the distal colon (variable, may be several hours), gastric emptying time (delayed induction of anesthesia, several hours), inadequate bowel opacification, and prolonged ED throughput time.17 However, PO contrast CT is the imaging modality of choice in many institutions for suspected GI abscess, perforation, or fistula.
Rectal contrast CT can identify distal large bowel obstruction if that is the focused question.
IV contrast CT provides superior visualization of bowel mucosa, visceral organs, and vascular structures. It can identify small and large bowel obstruction and the transition point. It is the initial test of choice for suspected abdominal aortic aneurysm rupture or mesenteric ischemia. The risks of IV contrast are nephrotoxicity and allergic reactions. The association of IV contrast with acute kidney disease has been questioned.19 Limitations regarding IV contrast use, renal function cutoff values, and pretreatment guidelines vary depending on institutional, ED, and radiology department practice protocols. A common practice is if the serum creatinine is >1.5 milligrams/dL or the glomerular filtration rate is <60 mL/min/1.733 m2, then the use of IV contrast is generally not recommended except in life­threatening situations. IV contrast is contraindicated in patients with a history of allergy to IV contrast or to iodine. There is no literature to support an allergy to shellfish as a contraindication to the use of IV contrast.
Common diagnoses for acute abdominal pain are listed in Table 71­4.20­25
TABLE 71­4
Common Diagnoses for Acute Abdominal Pain in Adults
Typical Typical Typical
Diagnosis Epidemiology Helpful Cautions Laboratory Imaging Complications
Location Radiation Quality
Appendicitis Peak age: adolescence and Early: — Initially dull, RLQ pain; Anorexia, No WBC count or CRP CT preferred Perforation, young adulthood periumbilical; becomes severe pain vomiting, level can exclude or in adults and abscess late: RLQ. If migrated fever, and confirm the diagnosis20 nonpregnant retrocecal or from elevated women third periumbilical WBC have trimester area; pain poor pregnancy before individual may be RUQ vomiting; sens rigidity
Biliary colic F >> M before age  y old, RUQ > Right Initially colicky, Bloating and — Suspect common bile US Cholecystitis
Hispanic > white > black epigastric subscapular becomes dyspepsia duct stone if elevated area continuous; colic are not bilirubin typically related to resolves <6 h gallstones
Bladder outlet Benign prostatic Suprapubic — — — — — Bedside US — obstruction hypertrophy
Bowel History previous Diffuse — Colicky Vomiting, — — Plain films: Incarceration, obstruction abdominal surgery distention 77% sens; strangulation
CT: 93% sens21
Cholecystitis Most common surgical RUQ > Right Continuous (+) Murphy Up to 90% No single test can exclude US: 81% Common bile cause of abdominal pain in epigastric subscapular sign afebrile; diagnosis; elevated sens; duct elderly area increases elevated bilirubin/aspartate hepatobiliary obstruction; likelihood of WBC only aminotransferase/alkaline iminodiacetic ascending cholecystitis 63% sens phosphatase each only acid scan: cholangitis;
(odds ratio and 57% 70% sens and 42% spec 96% sens22 gangrene
.3–2.8); spec.
jaundice Cholangitis: suggests elevated obstruction WBC only
80% sens
Diverticulitis M > F before age  y old; Sigmoid — — 50% report Temperature WBC may be normal CT: sens Perforation; incidence increases with (85%): LLQ; previous may be 93%–100%; abscess; fistula; age cecal/Meckel: episode of normal; 25% spec 100% obstruction
RLQ similar pain (+) fecal occult blood
Epiploic Middle age; M > F LLQ — — Fever In general, — CT — appendagitis unusual; n/v pts are not infrequent; systemically diarrhea ill
25%
Mesenteric Atrial fibrillation Any — Severe Pain out of Atrial Lactate: 86% sens; not Selective CT Metabolic arterial occlusion proportion fibrillation specific23; elevated WBC: angiography: acidosis to physical 90% 94% sens23 findings; n/v
Mesenteric Hypercoagulable states, Most — — — — — Contrast­ — venous liver disease commonly: enhanced CT thrombosis generalized or epigastric
Mesenteric Critically ill pts; vasoactive — — — — — — Angiography — ischemia drugs
(nonocclusive)
Myocardial — Upper — Steady, dull Abnormal ECG may be Troponin sens and spec — — ischemia midline ECG normal vary based on available assay
Pancreatitis M > F. Risks: alcohol; biliary Epigastric Back Severe, constant Nausea and May have Lipase: 90% sens first  h Contrasted Hemorrhage; disease; drugs; endoscopic vomiting low­grade CT is the pseudocyst; retrograde common fever gold adult cholangiopancreatography standard24; respiratory
US may show distress edema syndrome; sepsis
PID Sexually transmitted RLQ and/or — — Vaginal Fever not Elevated WBC not — Tubo­ovarian diseases; prior PID; LLQ discharge; necessary for necessary for diagnosis abscess; multiple partners dyspareunia; diagnosis perihepatitis; cervical infertility; motion ectopic tenderness pregnancy; chronic pain
Peptic ulcer Peak age: 50s; M > F; Epigastric — Severe, Vomiting, Nonulcer — — Perforation disease chronic aspirin or NSAIDs; persistent tachycardia dyspepsia bleeding smoking; alcohol; more likely if:
Helicobacter pylori age <40 y old, no weight loss, no night pain, no vomiting
Perforated viscus — Any — Severe — — — CT excellent —
Plain radiography has clinical utility25
Ovarian torsion — RLQ or LLQ Back, flank, or Sudden onset, Adnexal — — Pelvic US Ovarian salvage groin severe, sharp; mass with Doppler decreases with may have flow delay in nausea/vomiting diagnosis
Renal/ureteral Average age: 30–40 y old; Right or left Ipsilateral Severe; colicky; 85%–90% — Urinalysis CT, US Obstruction colic white > black; family flank groin/scrotum nausea and have Infection history of stones vomiting hematuria; common only 30% have gross hematuria
Ruptured ectopic Previous ectopic; PID; RUQ or LLQ — Sudden onset; Pelvic mass Pelvic exam Pregnancy test Transvaginal Shock pregnancy infertility treatment; severe pain may be US intrauterine device <1 y; normal tubal surgery
Ruptured/leaking Older; male; Mid­ Back, groin, or Severe; sudden Pulsatile Only 50% are — Bedside US Shock abdominal aortic atherosclerotic abdomen or thigh onset; constant mass hypotensive 100% sens aneurysm cardiovascular disease; flank detected: at smoker; (+) family history 22%–96% presentation.
sens Normal pulses do not exclude diagnosis
Tubo­ovarian PID Unilateral or — — — Fever may be Leukocytosis may be Transvaginal Rupture, abscess bilateral absent absent US peritonitis, lower shock abdominal or pelvic pain
Abbreviations: > = more than; >> = much more than; < = less than; + = positive; CRP, C­reactive protein; F = female; LLQ = left lower quadrant; M = male; n/v = nausea and vomiting; PID = pelvic inflammatory disease; pts = patients; RLQ = right lower quadrant; RUQ = right upper quadrant; sens = sensitivity; spec = specificity; US = ultrasound.
TREATMENT
ANTIBIOTICS
Antibiotics are indicated for suspected abdominal sepsis and peritonitis. Endogenous gut flora cause abdominal infections in the GI or GU tract. In all intra­abdominal nongynecologic infections, coverage should minimally be targeted at anaerobes and facultative aerobic gram­negative bacteria. High­risk community­acquired (septic, elderly, comorbid conditions, immunosuppressed, delayed presentation, known resistant organism) and healthcare­associated intra­abdominal infections require broader­spectrum antibiotic coverarge.26,27 Antibiotic treatment is summarized in Table 71­5. TABLE 71­5
Antibiotic Regimens for Intra­abdominal Infections
Antibiotic Comments
Combination Therapy
Cephalosporin Cefepime and ceftazidime are indicated for high­risk or healthcare­associated intra­abdominal infections.
Cefazolin 1–2 gram IV every  h or
Ceftriaxone,  gram IV once daily or
Cefotaxime 1–2 grams IV every  h or
Cefepime  grams IV every  h or
Ceftazidime  grams IV every  h plus
Metronidazole 500 milligrams IV every  h
Fluoroquinolone
Ciprofloxacin 400 milligrams IV every  h or
Levofloxacin 750 milligrams IV once daily plus
Metronidazole 500 milligrams IV every  h
Single­Agent Therapy
Ertapenem1 gram IV once daily —
Piperacillin­tazobactam .375–4.5 grams IV every  h Higher dose for high­risk or healthcare­associated intra­abdominal infections
Imipenem­cilastatin 500 milligrams IV every  h Indicated for high­risk or healthcare­associated intra­abdominal infections
Meropenem  gram IV every  h Indicated for high­risk or healthcare­associated intra­abdominal infections
Additional Agent
Vancomycin  to  milligrams/kg every 8–12 h Add to provide MRSA and increased enterococcal coverage.
Abbreviation: MRSA = methicillin­resistant Staphylococcus aureus.
The treatment of pelvic inflammatory disease (PID) requires different antibiotic combinations than do GI and GU infections. (For a detailed discussion, see Chapter 103, “Pelvic Inflammatory
Disease.”)
DISPOSITION AND FOLLOW­UP
Surgical consultation is required once a surgical diagnosis is made. Otherwise, consider hospital admission or observation for high­risk patients with acute abdominal pain. Patients who are elderly, immunocompromised, unable to communicate, or cognitively impaired are especially high risk. Patients who appear ill, have intractable pain or vomiting, are unable to comply with discharge or follow­up instructions, or who lack appropriate social support should also be considered for admission. Patients with an unclear diagnosis at discharge, even if the CT scan is “negative” (or for whom response to treatment is a concern), should be asked to return to the ED or their primary care physician for re­evaluation within  hours. Discharge instructions should address diet (e.g., clear liquids only, push fluids, no fatty foods, no acidic foods) and medications (e.g., antacids, analgesics, avoid narcotics). The patient and the patient’s family should understand that the diagnosis is uncertain, and they should know which symptoms warrant a return to the ED (e.g., increased/different pain, fever, vomiting, syncope, bleeding).
SPECIAL POPULATIONS
WOMEN
Gynecologic and nongynecologic disease can cause acute lower abdominal or pelvic pain in women (Table 71­6).
TABLE 71­6
Common Gynecologic Causes of Lower Abdominal/Pelvic Pain
Adnexal torsion* Endometriosis
Endometritis/salpingitis (pelvic inflammatory disease)* Myoma (degenerating)
Ruptured ectopic pregnancy* Ruptured ovarian cyst* Tubo­ovarian abscess* Adnexal/uterine masses
*Potential threat to life.
Hemorrhage from an ectopic gestation is the leading cause of pregnancy­related maternal death in the first trimester, despite improved diagnostic and treatment modalities. Obtain a qualitative or quantitative urine or serum pregnancy test in women of childbearing age with acute abdominal pain who have not had a hysterectomy. If the qualitative human chorionic gonadotropin is positive, transvaginal sonography should be the next diagnostic test to answer the question: Is this pregnancy in the uterus? Either inside or outside the uterus, a gestational sac is typically visible if the patient’s serum β­human chorionic gonadotropin is >1500 mIU/mL (the operator­dependent “discriminatory zone”). Detailed discussion of ectopic pregnancy is provided in Chapter , “Ectopic Pregnancy and Emergencies in the First  Weeks of Pregnancy.” Suspect ectopic pregnancy in a woman of reproductive age with hemodynamic collapse. The presence of right lower quadrant pain in a woman who has an appendix is a common diagnostic dilemma. In general, the results of pelvic examination, consideration of patient risk factors for gynecologic versus GI disease, and the clinician’s best estimate of pretest probability for gynecologic versus GI disease are the best guides for further imaging. If pretest probability favors gynecologic disease, a transvaginal US would be the next step. If pretest probability favors GI disease or appendicitis, abdominopelvic CT scanning would be the next step.
ELDERLY PATIENTS
Symptoms in the elderly may be mild, vague, or underreported, and presentations may be late and atypical. Among those >80 years old, mortality almost doubles if the diagnosis is incorrect at the time of admission.28 Poor hearing, decreased vision, and impaired cognition may affect the ability to give an adequate history. Surgical complications are more common: perforated viscus, gangrenous gallbladder, necrotizing pancreatitis, strangulated hernia, and infarcted bowel. Fever is not a reliable marker for serious disease, and the elderly may be hypothermic in the presence of serious abdominal infection. Fewer than 20% of elderly patients with perforated appendicitis have a “classic” presentation.29 A WBC has a low predictive value for surgical disease in the elderly. Although certain variables have been associated with poor outcome (age >84 years old, bandemia, free air) and others with the need for surgery
(hypotension, abnormal bowel sounds, massively dilated loops of bowel, extreme leukocytosis), the absence of these variables does not preclude significant disease.
Cholecystitis is the most common surgical entity in elderly patients with abdominal pain, followed by small bowel obstruction, perforated viscus, appendicitis, and large bowel obstruction.
Viral gastroenteritis is uncommon among the elderly, but diarrhea occurs in 31% to 40% of patients with mesenteric ischemia.10,30
Any acute abdominal pain is important in an elderly patient. No single test can distinguish among patients who should be admitted and patients who can be safely discharged. A liberal imaging/admission/observation policy is strongly advocated when the diagnosis is in doubt or follow­up is uncertain.
BARIATRIC SURGERY PATIENTS
The purpose of bariatric surgery is to limit the absorption of nutrients from ingested food by reducing the size of the stomach, with or without a degree of associated malabsorption (Table
71­7). The refinement of laparoscopic surgical technique has resulted in decreased perioperative morbidity and mortality after gastric bypass surgery.31 Bariatric surgery complications are provided in Chapter , “Complications of General Surgery.”
TABLE 71­7
Types of Bariatric Surgical Procedures
Restrictive Primarily Malabsorptive; Mildly Restrictive Primarily Restrictive; Mildly Malabsorptive
Vertical banded gastroplasty (“stomach stapling”) Biliopancreatic diversion Roux­en­Y gastric bypass
Laparoscopic adjustable gastric banding Duodenal switch
Staple breakdown after gastroplasty and band slippage after laparoscopic adjustable gastric banding may present as sudden intolerance to food or gastroesophageal reflux. Obstruction and erosion may also occur at the site of a gastric band. Diarrhea is a frequent complaint with predominantly malabsorptive procedures, and long­term malabsorption may result in protein depletion and vitamin deficiencies (particularly fat­soluble vitamins: A, D, and K).
Several specific problems can occur after successful Roux­en­Y gastric bypass (Table 71­8).
TABLE 71­8
Complications After Roux­en­Y Gastric Bypass
Anastomotic leak
Bowel obstruction (includes internal hernia and volvulus of Roux limb)
Cholelithiasis
Dumping syndrome
Enteric leak
Marginal ulcer
Metabolic complications (vitamin B , iron, thiamine, vitamin and mineral deficiencies; hyperoxaluria)

Stenosis of gastrojejunostomy site
The most common early complications are leakages, stenosis, and bleeding.31 The diagnosis of enteric leak requires a high index of suspicion, because the clinical presentation varies widely.31,32 With Roux­en­Y gastric bypass, leaks occur most commonly at the gastrojejunostomy anastomosis. Patients with enteric leak typically present with features suggestive of sepsis
(tachycardia, fever, abdominal pain, hypotension). CT may show extravasation of oral contrast material, a finding highly suggestive of leak in the early postoperative period. Primary repair is the treatment of choice. The mortality for undiagnosed enteric leak is extremely high.
Bowel obstruction may be caused by internal hernia, anastomotic stenosis, or adhesions. Symptoms may be nonspecific (nausea, bloating, abdominal pain). Bowel obstruction in the immediate postoperative period after Roux­en­Y gastric bypass is a surgical emergency, as distention of biliopancreatic limb and distal stomach can result in gastric rupture and peritonitis.
Bilious emesis after Roux­en­Y gastric bypass is pathognomonic for common channel obstruction, which requires immediate surgical intervention.33 Gallstone formation is increased during the period of rapid weight loss after bariatric surgery. “Dumping syndrome” is caused by rapid postprandial gastric emptying, the release of gastric hormones, and splanchnic vasodilation.
Patients with early dumping complain of nausea, vomiting, bloating, abdominal cramps, diarrhea, and sweating  to  minutes after a meal. Late dumping occurs  to  hours postprandially. It is a hyperinsulinemic and hypoglycemic state. Dietary modification is the initial treatment for dumping syndrome; patients should be advised to avoid highly concentrated foods, to separate eating and drinking, and to avoid rapidly absorbed sugars and lactose.34 Severe cases of dumping syndrome have been successfully treated with subcutaneous octreotide.35
EPIPLOIC APPENDAGITIS
Epiploic (omental) appendages are fatty pedicular structures, typically  cm in length, that are found on the serosal surface of the normal colon. Their function is not known. It is estimated that each person has  to 100 epiploic appendages, most commonly on the sigmoid colon and cecum.36 Acute epiploic appendagitis is a self­limited inflammatory condition usually caused by the torsion of an epiploic appendage. The cardinal sign is pain, which can mimic acute diverticulitis or acute appendicitis. In general, patients do not appear systemically ill, and fever is unusual. Nausea and vomiting are infrequent, but diarrhea has been reported in up to 25% of cases.36 On US, epiploic appendagitis appears as an oval noncompressible hyperechoic mass at the site of maximal abdominal tenderness, with no color Doppler blood flow.37 Normal epiploic appendages are not visualized on abdominal CT images in the absence of significant intraperitoneal fluid (e.g., hemoperitoneum, ascites).37 Epiploic appendagitis appears on CT as an oval fatty mass with a slightly hyperdense rim and surrounding mesenteric stranding suggestive of inflammation.37 The treatment is supportive and nonoperative. Pain control should be provided. Antibiotics are not indicated. Most cases resolve spontaneously within  to  weeks.
THE POSTOPERATIVE PATIENT WITH ACUTE ABDOMINAL PAIN
ILEUS AND EARLY POSTOPERATIVE BOWEL OBSTRUCTION
Anesthesia and surgical manipulation of the bowel decrease the normal propulsive activity of the gut. In the absence of precipitating factors, no specific treatment is necessary, and normal bowel function returns  to  days postoperatively. Mild cramps and flatus signal the return of peristalsis. A delay in the return of normal GI function may be caused by electrolyte abnormalities, intra­abdominal inflammation or infection, pancreatitis, or medications (particularly opioids, anticholinergics, phenothiazines, and psychotropics). The clinical findings of adynamic postoperative ileus are nausea, vomiting, abdominal distention, cramps, and obstipation. Plain radiographs of the abdomen demonstrate diffusely dilated loops of bowel, with air present in the distal colon and rectum. Adynamic ileus is treated supportively and by correction of precipitating factors.
The clinical differentiation of adynamic ileus and mechanical small bowel obstruction can be difficult. Patients with obstruction may report a temporary return of GI function postoperatively.
The symptoms of obstruction are similar to those of adynamic ileus, but vary depending on the location and extent of the obstruction. Proximal obstruction is usually associated with early emesis and less abdominal distention, distal obstruction with later (sometimes bilious or feculent) emesis, and significant abdominal distention. High­pitched bowel sounds suggest mechanical obstruction. Plain abdominal radiographs show air­fluid levels (which suggest but are not pathognomonic for obstruction), thickened valvulae conniventes proximal to the obstruction, and little air in the bowel distal to the obstruction. The amount of dilated bowel is variable. Abdominal CT can reliably identify the transition point of normal to abnormal bowel, the degree of mechanical obstruction, and the presence of complications (perforation, abscess). In the absence of complications, partial small bowel obstruction is managed with observation. Surgery is generally required for high­grade obstruction or peritonitis. Mechanical small bowel obstruction is most often caused by adhesions.
ACUTE URINARY RETENTION
Acute urinary retention after ambulatory surgery should be an obvious diagnosis based on the patient’s report of inability to urinate. Bedside bladder US confirms the diagnosis. Treatment is urinary bladder drainage.
ABDOMINAL COMPARTMENT SYNDROME
Abdominal compartment syndrome is a serious condition seen in critically ill patients. Intra­abdominal hypertension is defined as persistent intra­abdominal pressure above  mm Hg.
Abdominal compartment syndrome occurs as increased intra­abdominal pressure, often above  mm Hg, causes associated organ dysfunction. It is most often seen in critically ill septic, trauma, burn, and postoperative patients who receive aggressive fluid resuscitation. The diagnosis of abdominal compartment syndrome should be considered in the critically ill unstable patient with a tense abdomen, although a tense abdomen is not required to make the diagnosis. Abdominal compartment syndrome is confirmed by assessing intra­abdominal pressure, which is most often measured via urinary bladder pressure monitoring. Medical management involves identification and treatment of the contributing factors of abdominal compartment syndrome, evacuating intraluminal contents, improving abdominal wall compliance, and optimizing fluid administration and perfusion.38,39 Surgical decompression is required in patients with severe or refractory abdominal compartment syndrome.


