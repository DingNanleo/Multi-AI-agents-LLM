## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 225: Diabetic Ketoacidosis
Andrew Nyce; Richard Byrne; Cary L. Lubkin; Michael E. Chansky
INTRODUCTION AND EPIDEMIOLOGY
Diabetic ketoacidosis (DKA) is an acute, life­threatening complication of diabetes mellitus. DKA occurs predominantly in patients with type  (insulindependent) diabetes mellitus. The incidence of DKA in the United Kingdom, United States, and other developed countries is comparable, with an
 annual incidence between .4 and .9 cases per 1000 type  diabetics. There has been an increased number of DKA cases in patients with newly diagnosed type  (non–insulin­dependent) diabetes mellitus, especially in African Americans and Hispanics. Ketosis­prone type  diabetics have
 significant impairment in insulin secretion and action that subsequently recovers after resolution of DKA. Over the past decade in the United States,
 the frequency of DKA has increased by 30%, with close to 140,000 hospitalizations per year. A better understanding of the pathophysiology of DKA and
 an aggressive, uniform approach to its diagnosis and management have reduced mortality to <1% of reported episodes in experienced centers.

However, mortality is higher in patients from developing countries, those with comorbidities and the elderly.
PATHOPHYSIOLOGY
Figure 225­1 illustrates the complex relationships between insulin and counterregulatory hormones. DKA is a response to cellular starvation brought on by relative insulin deficiency and counterregulatory or catabolic hormone excess (Figure 225­1). Insulin is the only anabolic hormone produced by the endocrine pancreas and is responsible for the metabolism and storage of carbohydrates, fat, and protein. Counterregulatory hormones include glucagon, catecholamines, cortisol, and growth hormone. Complete or relative absence of insulin and the excess counterregulatory hormones result in hyperglycemia (due to excess production and underutilization of glucose), osmotic diuresis, prerenal azotemia, worsening hyperglycemia, ketone
 formation, and an elevated anion gap metabolic acidosis.
FIGURE 225­1. Insulin deficiency. Pathogenesis of diabetic ketoacidosis secondary to relative insulin deficiency and counterregulatory hormone excess. GFR = glomerular filtration rate.

Chapter 225: Diabetic Ketoacidosis, Andrew Nyce; Richard Byrne; Cary L. Lubkin; Michael E. Chansky 
. Terms of Use * Privacy Policy * Notice * Accessibility
INSULIN
Ingested glucose is the primary stimulant of insulin release from the β cells of the pancreas. Insulin’s main action occurs at the three principal tissues of energy storage and metabolism—the liver, adipose tissue, and skeletal muscle. Insulin acts on the liver to facilitate the uptake of glucose and its conversion to glycogen while inhibiting glycogen breakdown (glycogenolysis) and suppressing gluconeogenesis. The net effect of these actions is to promote the storage of glucose in the form of glycogen. Insulin increases lipogenesis in the liver and adipose cells by producing triglycerides from free fatty acids and glycerol while inhibiting the breakdown of triglycerides. Insulin stimulates the uptake of amino acids into muscle cells with subsequent incorporation into muscle protein while preventing the release of amino acids from muscle and hepatic protein sources.
Deficiency in insulin secretion due to loss of islet cell mass is the predominant defect in type  diabetes mellitus. In the initial stages of diabetes mellitus, the secretory failure of β cells impairs fuel storage and may be evident only during a glucose tolerance test. As levels of insulin decrease, fuel stores are mobilized during fasting, resulting in hyperglycemia. When pancreatic β­cell reserve is present, hyperglycemia may trigger an increase in insulin and a return to normal glucose concentration. With further disease progression, hyperglycemia can no longer trigger an increase in insulin activity. Despite the presence of elevated intravascular glucose, in the absence of insulin, cells are unable to use glucose as a fuel source. The body responds by breaking down protein and adipose stores to try to produce a usable intracellular fuel. Loss of the normal physiologic effects of insulin leads to secretion of catabolic (counterregulatory) hormones and resulting hyperglycemia and ketonemia.
KETOACIDOSIS
The response to cellular starvation seen with insulin insufficiency is increased levels of glucagon, catecholamines, cortisol, and growth hormone.
Glucagon is the primary counterregulatory hormone. The catabolic effects of these hormones include increased gluconeogenesis and glycogenolysis, breakdown of fats into free fatty acids and glycerol, and proteolysis with increased levels of amino acids. Increased levels of glucogenic precursors, such as glycerol and amino acids, facilitate gluconeogenesis, worsening hyperglycemia.
Free fatty acids released in the periphery are bound to albumin and transported to the liver, where they undergo conversion to ketone bodies. The primary ketone bodies β­hydroxybutyrate (βHB) and acetoacetic acid (AcAc) account for the metabolic acidosis seen in DKA. The two are in equilibrium: AcAc + NADH ⇋ βHB + NAD. AcAc is metabolized to acetone, another major ketone body. Depletion of hepatic glycogen stores favors ketogenesis. Low or absent insulin levels decrease the ability of the brain and cardiac and skeletal muscle to use ketones as an energy source, increasing ketonemia. The persistently elevated serum glucose level eventually causes an osmotic diuresis. The resulting volume depletion worsens hyperglycemia and ketonemia.
The renin­angiotensin­aldosterone system, activated by volume depletion, exacerbates renal potassium losses already occurring from osmotic diuresis. In the kidney, chloride is retained in exchange for the ketoanions being excreted. The loss of ketoanions represents a potential loss of bicarbonate. In the face of marked ketonuria, a superimposed hyperchloremic acidosis is also present. As adipose tissue is broken down, prostaglandins I and E are produced. Both account for paradoxical vasodilation that occurs despite profound levels of volume depletion.

CAUSES OF DKA

Factors known to precipitate DKA are listed in Table 225­1. Additional risk factors include poor economic background, lack of insurance or minority
 status, drug abuse, depression, and the presence of an eating disorder. In many patients, no clear precipitating cause is found.
TABLE 225­1
Important Causes of Diabetic Ketoacidosis
Omission or reduced daily insulin injections
Dislodgement/occlusion of insulin pump catheter
Infection
Pregnancy
Hyperthyroidism, pheochromocytoma, Cushing’s syndrome
Substance abuse (cocaine)
Medications: steroids, thiazides, antipsychotics, sympathomimetics
Heat­related illness
Cerebrovascular accident
GI hemorrhage
Myocardial infarction
Pulmonary embolism
Pancreatitis
Major trauma
Surgery
CLINICAL FEATURES
The clinical manifestations of DKA are related directly to hyperglycemia, volume depletion, and acidosis. The metabolic alterations of

DKA tend to evolve within  hours. Osmotic diuresis gradually leads to volume loss in addition to renal losses of sodium, chloride, potassium, phosphorous, calcium, and magnesium. Initially, patients may compensate by increasing fluid intake, and polyuria and polydipsia are usually the only symptoms until ketonemia and acidosis develop. As acidosis progresses, ventilation is stimulated physiologically by acidemia to diminish the PCO and
 to counter metabolic acidosis. Acidosis combined with the effects of prostaglandins I and E leads to peripheral vasodilation despite profound levels
  of volume depletion. Prostaglandin release is also felt to play a role in unexplained nausea, vomiting, and abdominal pain that are seen frequently at presentation, especially in children. Vomiting, which may be a maladaptive physiologic response to diminish the acid load, unfortunately exacerbates potassium losses. As volume depletion progresses, poor absorption of SC insulin renders its administration less effective. Impaired mental status may develop and is most likely multifactorial, related to metabolic acidosis, hyperosmolarity, low extracellular fluid volume, and poor hemodynamics.
Alteration of consciousness seems to correlate better with elevated serum osmolality (>320 mOsm/L or >320 mmol/kg) than with
 severity of metabolic acidosis.
Tachycardia, orthostasis or hypotension, poor skin turgor, and dry mucous membranes result from volume depletion. Kussmaul respirations, increased rate and depth of breathing, may be observed. Acetone produces the characteristic fruity odor on the breath found in some patients. The absence of fever does not exclude infection. Hypothermia is present occasionally because of peripheral vasodilation.
Abdominal pain and tenderness associated with DKA generally correlate with the level of acidosis. Pain can be due to gastric dilatation, ileus, or pancreatitis, but any other acute abdominal disorder can also develop. Due to the frequency of abdominal pain and the presence of an elevated serum amylase or lipase level in both DKA and pancreatitis, distinguishing these two conditions may be difficult. An elevated serum lipase level is more specific to pancreatitis, but it may also be elevated in DKA.
DIAGNOSIS
A blood glucose level >250 milligrams/dL (13.9 mmol/L), an anion gap >10 to  mEq/L (>10 mmol/L), a bicarbonate level <15 mEq/L
,4,6
(<15 mmol/L), and a pH <7.3 with moderate ketonuria or ketonemia constitute the diagnosis of DKA. Traditionally, DKA is divided into mild, moderate, and severe states based on total­body deficits of water and electrolytes. Mild DKA is defined as an arterial pH of .25 to .3, a serum bicarbonate of  to  mEq/L (15 to  mmol/L), and an anion gap >10 mEq/L, whereas moderate DKA is defined as arterial pH between .0 and .24, a serum bicarbonate of  to  mEq/L (10 to  mmol/L), and an anion gap >12 mEq/L in an alert to drowsy patient. Severe DKA is defined as a pH <7.00,
 bicarbonate <10 mEq/L (<10 mmol/L), and anion gap >12 mEq/L in a stuporous to comatose patient.
EUGLYCEMIC DKA
In contrast to the above DKA criteria, euglycemic ketoacidosis (euDKA) (glucose <250 milligrams/dL or <13.9 mmol/L) can create a diagnostic challenge. Situations in which euDKA occurs include pregnant patients, young type  diabetics who are vomiting, patients who present just after receiving insulin, patients with impaired gluconeogenesis (alcohol abuse or liver failure), and patients with low caloric intake or starvation. Suspect
,8 euDKA in such patient populations even in the presence of relative normoglycemia (Table 225­2). euDKA has also recently been described as a potential adverse side effect in patients taking sodium­glucose cotransporter  (SGLT­2) inhibitors (e.g., canagliflozin, dapagliflozin, or empagliflozin).

Potential mechanisms include decreased insulin dose requirements and higher glucagon levels. SGLT­2 inhibitors increase glucose secretion in the urine, thereby decreasing carbohydrate availability. The subsequent drop in insulin release inhibits gluconeogenesis in the liver, in turn resulting in ketogenesis and the lower serum glucose levels commonly seen in euDKA. A clinical suspicion for ketosis (nausea, vomiting, malaise) in this unique
7­9 subset of patients combined with the measurement of serum βHB (generally >3 mEq/L [>3 mmol/L]) can aid in the prompt diagnosis of DKA. As outlined below, treatment includes dextrose containing fluids coupled with insulin therapy until ketosis resolves.
TABLE 225­2
Risk Factors for Diabetic Ketoacidosis Patients with Initial Glucose <250 milligrams/dL (13.9 mmol/L) (Euglycemic Ketoacidosis)
Patients presenting shortly after receiving insulin
Type  diabetics who are young and vomiting
Patients with impaired gluconeogenesis (alcohol abuse or liver failure)
Low caloric intake/starvation
Depression
Pregnancy
SGLT2 inhibitors* *SGLT2 inhibitors = inhibitors of sodium­glucose transport protein  (e.g., dapagliflozin, canagliflozin, empagliflozin).
DIFFERENTIAL DIAGNOSIS
The differential diagnosis of DKA (Table 225­3) includes any cause of a high anion gap metabolic acidosis. Patients with hyperosmolar, nonketotic coma tend to be older, have a more prolonged course, and have prominent mental status changes. Serum glucose levels generally are much higher

(>600 milligrams/dL or >33.3 mOsm/L), and there is little to no anion gap metabolic acidosis. The ketosis in alcoholic ketoacidosis and starvation ketosis tend to be milder (βHB generally <3 mEq/L [<3 mmol/L], serum bicarbonate usually >18 mEq/L [>18 mmol/L]), and the serum glucose level is usually low or normal. βHB predominates in alcoholic ketoacidosis, so the urinary ketone test may be negative or trace positive.
TABLE 225­3
Differential Diagnosis for Diabetic Ketoacidosis
Alcoholic ketoacidosis
Starvation ketoacidosis
Renal failure
Lactic acidosis
Ingestions
Salicylates
Ethylene glycol
Methanol
Various toxic ingestions may also cause a high anion gap acidosis, so if a toxic ingestion cannot be excluded, serum osmolarity or drug­level testing is required. Renal failure, anion gap acidosis, and liver function abnormalities may be due to acetaminophen toxicity. Depending on the hemodynamic status, lactic acidosis (poor perfusion) may occur simultaneously with DKA; in these cases, determination of the serum lactate level is indicated.
Patients taking metformin with new­onset renal insufficiency are at risk for developing type B (aerobic) lactic acidosis.
LABORATORY TESTING
Obtain a rapid bedside glucose level, and ECG to assess for evidence of hyperkalemia, and obtain a CBC, serum electrolytes, BUN and creatinine, urinalysis, venous blood gas, and phosphate, magnesium, and calcium levels. Calculate the anion gap [Na – (Cl + HCO )]. Blood cultures and other
 laboratory tests should be done as clinically indicated. Arterial blood gas determinations are optional but may be required for the diagnosis and monitoring of critically ill patients.
Ketone Bodies
In DKA, elevated serum levels of βHB and AcAc cause acidosis and ketonuria. The nitroprusside reagent normally used to detect urine and serum ketones only detects AcAc; acetone is only weakly reactive and βHB not at all. Gas chromatography can be used to detect serum acetone but is expensive and time consuming.
NADH accumulation in mitochondria, as may occur with lactic acidosis or alcohol metabolism, favors the βHB side of equilibrium noted earlier (AcAc +
NADH ⇋ βHB + NAD). Paradoxically, as the patient is being treated and clinically improves, ketone levels will increase as the body converts the more acidic βHB to AcAc. Therefore, the urine and/or blood ketone test (Acetest®) that uses the nitroprusside reaction is not a reliable measure for diagnosis or monitoring of DKA. Compared to a urine dipstick for ketones, a more reliable and preferred test for ketonemia in DKA is a quantitative βHB serum level. In general, during DKA, the βHB level is greater than  mEq/L (3 mmol/L), and this test should be obtained with other initial laboratory testing, as
 outlined above. Drugs with a sulfhydryl group, such as the angiotensin­converting enzyme inhibitor captopril, interact with the reagent in the nitroprusside test, producing a potential false­positive urine test for ketones. Consider the clinical presentation and other biochemical markers when
 interpreting a positive urine nitroprusside test in this subset of patients.
Acid­Base Abnormalities
DKA leads to a wide anion gap metabolic acidosis. Hyperchloremic acidosis also occurs on the basis of ketoanion exchange for chloride in the urine and is especially common in patients who maintain good hydration status and glomerular filtration rate despite ketoacidosis. Metabolic alkalosis may occur secondary to vomiting, osmotic diuresis, and concomitant diuretic use. Rarely, some patients with DKA may present with normal­appearing
– –
[HCO ] or even an elevated [HCO ], if coexisting metabolic alkalosis is severe enough to mask the acidosis. In such situations, an elevated anion gap
  may be the only clue to the presence of an underlying metabolic acidosis otherwise masked by the concomitant volume contraction–related metabolic alkalosis.
Venous pH has essentially replaced arterial blood gases in the assessment of the acid­base status of the DKA patient. A strong correlation exists
 between venous and arterial pH in patients with DKA, and the arterial blood gas value does not impact therapy. Venous pH is about .03 lower than arterial pH. Venous pH obtained during routine phlebotomy should be used to avoid arterial puncture, which is painful and may cause arterial vascular complications.
A low PCO determination usually reflects respiratory compensation for metabolic acidosis. If it is lower than explained by the degree of acidosis, a
 primary respiratory alkalosis exists, which may be an early indication of pulmonary disease (e.g., pneumonia, pulmonary embolus) or sepsis as a possible trigger of DKA. Chapter , “Acid­Base Disorders,” details how compensatory changes in PCO can be distinguished from a primary respiratory
 alkalosis.
Potassium

Total­body potassium is depleted by renal losses. However, the measured serum potassium level is normal or elevated in most patients because of two important factors: extracellular shift of potassium secondary to acidemia and increased intravascular osmolarity caused by hyperglycemia. Although the actual incidence of initial hypokalemia on laboratory testing in DKA is not known, a few studies report an occurrence of
,11,12
4% to 6%. The decrease in serum potassium during therapy is reported to be about .5 mEq/L (1.5 mmol/L) and parallels the
,11 drop in glucose and the dose of insulin.
ECG changes of hyperkalemia or hypokalemia may be seen. The ECG also should be evaluated for ischemia because myocardial infarction may precipitate DKA.
Sodium and Other Electrolytes
Osmotic diuresis leads to excessive renal losses of sodium chloride in the urine. However, the presence of hyperglycemia tends to artificially lower the serum sodium levels. Standard teaching is that .6 mEq (1.6 mmol) should be added to the reported sodium value for every 100 milligrams (5.55 mmol) of glucose >100 milligrams/dL (>5.5 mmol/L). However, the correction factor is probably .4, especially for
 blood glucose levels >400 milligrams/dL (>22.2 mOsm/L). Osmotic diuresis also causes urinary losses and total­body depletion of phosphorous, calcium, and magnesium. Hemoconcentration frequently leads to initially elevated levels of these electrolytes in serum. As therapy progresses, lower serum levels of each will be evident.
Other Laboratory Values
Serum creatinine frequently may be elevated factitiously if the laboratory assay for creatinine is interfered with by the nitroprusside assay. Some elevation in creatinine is expected due to prerenal azotemia. Liver function studies may be elevated because of fatty infiltration of the liver, which gradually corrects as the acidosis is treated. Leukocytosis is often present because of hemoconcentration and stress.

However, a WBC count >25,000 mm and/or an absolute band count of ,000 mm or more is suggestive of infection. Elevation of C­reactive protein may reflect the proinflammatory state found in DKA; elevated levels of cytokines may also be present.
TREATMENT

The diagnosis of DKA should be suspected at triage. Begin aggressive fluid therapy before receiving laboratory results (Figure 225­2). The goals of therapy are (1) volume repletion, (2) reversal of the metabolic consequences of insulin insufficiency, (3) correction of electrolyte and acid­base imbalances, (4) recognition and treatment of precipitating causes, and (5) avoidance of complications. Place patients on a cardiac monitor and begin at least one large­bore (16­ to 18­gauge) IV infusion of isotonic crystalloid. A second IV line with .45% normal saline at minimal rate to keep the IV line open can be considered. The order of therapeutic priorities is volume first and foremost, correction of potassium deficits, and then insulin administration. Metabolic disturbances should be corrected at the approximate rate of occurrence or over  to  hours.
FIGURE 225­2. Timeline for the typical adult patient with suspected diabetic ketoacidosis (DKA). *IV insulin infusion <1.0 unit/kg/h may require a bolus dose of regular
 insulin (0.1 unit/kg). AG = anion gap; ARDS = acute respiratory distress syndrome; BS = blood sugar; ICU = intensive care unit; I/Os = inputs/outputs; NS
= normal saline; TKO = to keep vein open; VBG = venous blood gas.
Meeting the goals of safely replacing deficits and supplying missing insulin requires monitoring every  hours of electrolytes (glucose, potassium, and anion gap), vital signs, level of consciousness, and volume input/output until recovery. The goal of treatment is glucose <200 milligrams/dL
(<11.1 mmol/L), bicarbonate ≥18 mEq/L (≥18 mmol/L), and venous pH >7.3. VOLUME REPLETION
Fluid helps restore intravascular volume and normal tonicity, perfuse vital organs, improve glomerular filtration rate, and lower serum glucose and
  ketone levels. Rehydration improves the response to low­dose insulin therapy. The average adult patient has a water deficit of 100 mL/kg (5 to  L)
 and a sodium deficit of  to  mEq/kg (7 to  mmol/L/kg). Normal saline is the most frequently recommended fluid for initial volume repletion even
 though the extracellular fluid of the patient is initially hypertonic. Normal saline does not provide “free water” to correct intracellular fluid loss, but it does prevent an excessively rapid fall in extracellular osmolarity and the potential devastating transfer of excessive water into the CNS. Large­volume resuscitation with normal saline may result in hyperchloremic metabolic acidosis, prolonging time to resolution of acidosis in DKA. Further, there is a possible association between normal saline resuscitation and increased mortality in septic shock patients when compared to balanced fluid
 resuscitation. Replacing normal saline with lactated ringer’s solution or another balanced electrolyte solution may help to slightly speed resolution
  of acidosis and prevent hyperchloremic acidosis without any reduction in mortality. Without clear evidence of superiority, it is reasonable to select either normal saline, lactated ringer’s, or a commercially available balanced crystalloid solution for volume replacement in
DKA. There is no consensus on the best fluid choice in DKA. A recent large randomized trial comparing outcomes with use of balanced crystalloid or
 normal saline was not specific to DKA patients, but supports the use of balanced crystalloids in critically ill patients. After initial resuscitation with
,7 isotonic crystalloid, change fluids to .45% normal saline once the corrected serum sodium is normal or elevated.
Based on clinical suspicion alone and before initial electrolyte results, administer theinitial fluid bolus of isotonic crystalloid at a rate of 
 to  mL/kg/h during the first hour unless there are mitigating circumstances. The rate of hydration should depend on hemodynamic stability, hydration status, urine output, and serum electrolytes. After the initial bolus, administer normal saline at 250 to 500 mL/h in hyponatremic patients, or
 give .45% normal saline at 250 to 500 mL/h for eunatremic and hypernatremic patients. In general, the first  L are administered rapidly over
 to  hours, the next  L over  to  hours, and then an additional  L over  to  hours. This replaces approximately 50% of the total water deficit over the first  hours, with the remaining 50% water deficit to be replaced over the subsequent  hours.
When the blood glucose level falls to about 250 milligrams/dL (13.9 mmol/L), change to 5% dextrose in .45% normal saline. Patients without extreme volume depletion can be managed safely with a more modest fluid replacement regimen such as 250 to 500 mL/h for  hours. Closely monitor the volume status in the elderly or in those with heart or renal disease. Excess fluid may contribute to the development of adult respiratory distress syndrome and cerebral edema.
POTASSIUM REPLACEMENT

Patients in DKA usually present with profound total­body potassium deficits in the range of  to  mEq/kg (3 to  mmol/kg). This deficit is created by insulin deficiency, metabolic acidosis, osmotic diuresis, and frequent vomiting. Only 2% of total­body potassium is intravascular. The initial serum concentration is usually normal or high because of the intracellular exchange of potassium for hydrogen ions during acidosis, the total­body fluid deficit, and diminished renal function. Initial hypokalemia indicates severe total­body potassium deficits, and large amounts of replacement potassium are usually necessary in the first  to  hours.
Correction of the acidosis predicts the change in serum potassium concentration. For each .1 decrease in pH, serum potassium concentration rises approximately .5 mEq/L (0.5 mmol/L), and the same relationship holds as the pH increases. This can be used as a guide for estimating the serum potassium concentration when pH balance is restored.
Hypokalemia
During initial therapy for DKA, the serum potassium concentration may fall rapidly, primarily due to the action of insulin promoting reentry of potassium into cells and, to a lesser degree, the dilution of extracellular fluid, correction of acidosis, and increased urinary loss of potassium. If these changes occur too rapidly, precipitous hypokalemia may result in fatal cardiac arrhythmias, respiratory paralysis, paralytic ileus, and rhabdomyolysis.
The rapid development of severe hypokalemia is potentially the most life­threatening electrolyte derangement during the
 treatment of DKA.
As a general guideline, an initial serum potassium level >3.3 mEq/L (>3.3 mmol/L) but <5.2 mEq/L (<5.2 mmol/L) (before fluid resuscitation and insulin,
 coupled with urine output) calls for  to  mEq/L (20 to  mmol/L) for at least  hours to keep potassium between  and  mEq/L (4 and  mmol/L).
Because the most rapid changes occur during the first few hours of therapy, measure the plasma potassium level initially every  hours. If oliguria or renal insufficiency is present, withhold or decrease potassium replacement.

Initial hypokalemia (<3.3 mEq/L or <3.3 mmol/L) is uncommon but necessitates a more aggressive replacement before insulin therapy. In this setting, give potassium IV at  to  mEq/h (20 to  mmol/h) and hold insulin until [K + ] is ≥3.5 mEq/L (≥3.5 mmol/L). ,7 There is no advantage to using potassium phosphate (K PO ) compared to potassium chloride because K PO may result in hypocalcemia and metastatic precipitation of calcium
    phosphate in tissues. Oral potassium replacement is safe and effective and is the preferred route of replacement as soon as the patient can tolerate oral fluids. In DKA, initial potassium replacement is usually by an intravenous line. Each institution may have specific guidelines for potassium replacement, but a general approach is a rate no faster than  mEq/h (10 mmol/h) via peripheral IV or  mEq/h (20 mmol/h) via central line access.
Continuous cardiac monitoring is generally recommended while replacing potassium in the severely hypokalemic patient. During the first  hours,
100 to 200 mEq (100 to 200 mmol) of KCl is usually required.
Hyperkalemia
Obtain an ECG immediately and check for signs of hyperkalemia once DKA is suspected.
Giving potassium to a patient in a hyperkalemic potentiating state (e.g., acidemia, insulin deficiency, volume contraction, renal insufficiency) may dangerously increase the extracellular potassium level and precipitate fatal dysrhythmias. The initial measurement of serum electrolytes, ECG review for signs of hyperkalemia, and the presence of urine output determine initial potassium therapy. An initial serum potassium level >5.2 mEq/L usually reflects a more profound acidemia and volume depletion or renal insufficiency. Fluid and insulin therapy alone usually will lower the serum potassium level rapidly. Albuterol nebulization can provide an additional quick potassium­lowering effect. See Chapter , “Fluids and Electrolytes,” for further treatment of hyperkalemia.
INSULIN
Low­dose regular insulin administration by an infusion pump is simple and safe, ensures a steady blood concentration of insulin, allows flexibility in
 adjusting the insulin dose, and promotes a gradual decrease in serum glucose and ketone body levels. The half­life of IV insulin is  to  minutes, with an effective biologic half­life at the tissue level of approximately  to  minutes.
IV Insulin
After the initial fluid bolus, or simultaneously in a second IV line, administerinsulin at a rate of .1 to .14 unit/kg/h with no insulin bolus once hypokalemia ([K+] <3.3 mEq/L [<3.3 mmol/L]) is excluded. An alternative insulin regimen is .1 unit/kg bolus IM, if it is difficult to
  establish another IV line, followed by a drip rate at .1 unit/kg/h. An IV loading dose of insulin is not recommended in children and new­onset young
,20 adult diabetics and is optional in adults. Plasma glucose concentration typically decreases by  to  milligrams/dL/h (2.8 to .2 mmol/L/h), but if the blood glucose fails to drop by 10%  hour after initial therapy, or  mmol/L/h, (assuming adequate hydration), give a .14 unit/kg bolus and resume
,7  insulin drip rate. Another option is to increase the insulin infusion rate by  unit/h. The incidence of nonresponse to low­dose continuous IV insulin administration is 1% to 2%, with infection being the primary reason for failure to respond.
Resolution of hyperglycemia usually occurs earlier than resolution of the anion gap, so once the serum glucose is 250 milligrams/dL (11 mmol/L), add dextrose to the IV fluids and reduce the insulin drip rate to .02 to .05 unit/kg/h. Maintain the serum glucose between 150
 and 200 milligrams/dL (8.3 and  mmol/L) until the resolution of DKA. Occasionally, a 10% dextrose solution may be needed to maintain glucose
 levels. Continue the insulin infusion until the resolution of DKA—glucose <200 milligrams/dL (<11 mmol/L) and two of the
,7 following: a serum bicarbonate level >15 mEq/L, a venous pH >7.3, and/or a normal calculated anion gap. Monitor laboratory values every  to  hours to ensure that insulin is being administered in the desired amount.
Transition from IV Insulin After DKA Correction
A transition from the IV insulin infusion to SC insulin is necessary to avoid relapse to hyperglycemia or DKA when the insulin infusion is stopped.Relapse can occur quickly, within an hour after IV insulin is stopped due to the short duration of action of IV insulin. The method of insulin transition varies, and there is no set protocol. Once the patient eats, the glucose infusion can be stopped, but it is important to overlap the IV and SC insulin for  to  hours to avoid potential relapse to hyperglycemia or DKA. It is best to collaborate with the inpatient team or endocrinologist to develop a protocol for the transition to SC insulin. New­onset diabetics can be started on a total daily dose of .5 to .8 unit/kg/dL, whereas previously treated diabetic patients can be restarted on their previous insulin dosage. It is generally preferred to transition from IV to SC by using long­acting (glargine) and rapid­acting (lispro, glulisine) SC insulin regimens that mimic normal insulin physiology as opposed to
 intermediate­acting insulin (NPH) and regular human insulin. The long and rapid acting insulin analogs may have a lower incidence of hypoglycemia.
One method is to give 50% of the usual long­acting insulin dose  hours before the IV insulin infusion is stopped (see Figure 223­1 for onset and duration of action of long­acting insulins). Additional glucose coverage can be provided with short­acting insulin as needed. Continue glucose checks every hour for  hours. Further intervals for glucose checks and the need for additional SC regular insulin dosing depend on the patient’s response and institutional protocols.
SC Insulin
In carefully selected cases of uncomplicated mild to moderate DKA, the use of rapid­acting SC insulin may be another treatment option. Small studies have demonstrated no difference in terms of time to resolution of hyperglycemia or acidosis when comparing serial doses of SC short­acting insulins
22­26,
(lispro, aspart) with IV infusions of regular insulin. Suggested dosing regimens of SC lispro include an initial injection of .3 unit/kg followed by .1
  unit/kg every hour, or an initial dose of .3 unit/kg followed by .2 unit/kg every  hours until blood glucose is <250 milligrams/dL (<13.9 mmol/L).
,26
Then, the insulin dose is decreased by half and administered every  or  hours until resolution of DKA. This can avoid intensive care admissions and lower hospital costs but still requires close nursing monitoring that is difficult to accomplish in the ED or nonmonitored setting.
HYPOPHOSPHATEMIA
Serum phosphate levels often are normal or increased on presentation of DKA and do not reflect the total­body phosphate deficits secondary to
 enhanced urinary losses. Phosphate (similar to glucose and potassium) reenters the intracellular space during insulin therapy, resulting in low phosphate concentrations. Hypophosphatemia is usually most severe  to  hours after the start of insulin therapy. Acute phosphate deficiency (<1.0 milligram/dL) can result in hypoxia, skeletal muscle weakness, rhabdomyolysis, hemolysis, respiratory failure, and cardiac dysfunction.
,7,11
There is no established role for initiating IV K PO for DKA in the ED. In general, do not give IV phosphate unless the serum phosphate
  concentration is <1.0 milligram/dL (0.323 mmol/L). Significant hypophosphatemia tends to develop many hours into therapy, after the patient is already admitted. Undesirable side effects from IV phosphate administration include hyperphosphatemia, hypocalcemia, hypomagnesemia, metastatic soft tissue calcifications, hypernatremia, and volume loss from osmotic diuresis. If absolutely necessary (a phosphate level <1.0
 milligram/dL early in therapy), IV phosphate replacement should be administered as IV K PO , .5 to  milligrams/kg (0.08 to .16 mmol/kg). Monitor
  serum calcium level if giving supplemental phosphate.
HYPOMAGNESEMIA
Osmotic diuresis may cause hypomagnesemia and deplete magnesium stores from bone. Hypomagnesemia may inhibit parathyroid hormone secretion, causing hypocalcemia and hyperphosphatemia. If the serum magnesium concentration is <2.0 mEq/L (<1.0 mmol/L) or symptoms are suggestive of hypomagnesemia, give magnesium sulfate  grams IV over  hour. Obtain serum magnesium and calcium levels on presentation and  hours into therapy. Monitor levels every  hours if there is initial hypomagnesemia or hypocalcemia or if symptoms suggestive of hypomagnesemia or hypocalcemia occur.
BICARBONATE

Acidotic patients routinely recover from DKA without alkali therapy. Although it may take hours, the slowing of ketoacid production from infused insulin allows the generation of bicarbonate ions as ketoacids are oxidized. This production in bicarbonate during DKA treatment may be decreased if the brain and kidney oxidize fewer ketoacids.  Give bicarbonate if the initial pH is <6.9, but do not give bicarbonate if the pH is ≥6.9. ,3,7,29
Severe metabolic acidosis is associated with numerous cardiovascular (impaired contractility, vasodilation, and hypotension) and neurologic (cerebral vasodilation and coma) complications. Theoretical advantages of bicarbonate include improved myocardial contractility, elevated ventricular fibrillation threshold, improved catecholamine tissue response, and decreased work of breathing. The disadvantages of bicarbonate include worsening hypokalemia, paradoxical CNS acidosis, worsening intracellular acidosis, impaired (shift to left) oxyhemoglobin dissociation, hypertonicity
 and sodium overload, delayed recovery from ketosis, elevation of lactate levels, and possible precipitation of cerebral edema.
Although there is a lack of literature supportive of improved outcome measures with the use of bicarbonate in the severely acidotic DKA patient, the
,30 decision to use bicarbonate should be based on the clinical condition and pH of the patient. Potential benefits of bicarbonate in the elderly with
 cardiovascular instability must be balanced against the potential disadvantages. There may be selected patients who benefit from cautious alkali therapy, including those with decreased cardiac contractility and peripheral vasodilatation, and patients with life­threatening hyperkalemia and coma.
Patients with severe acidosis may be at higher risk for clinical deterioration, so adults with a pH <6.9 can be given 100 mEq (100 mmol) of sodium bicarbonate in 400 mL of water with  mEq (20 mmol) KCl at 200 mL/h for  hours until the venous pH >7.0. If the pH remains
,7 +
<7.0 despite the infusion, repeat the infusion until pH >7.0. Remember to check [K ] every  hours. Severe acidosis (pH <7.0) and worsening pH despite aggressive therapy for DKA should prompt investigation for other causes of metabolic acidosis (see Chapter 15).
DISEASE COMPLICATIONS
COMPLICATIONS RELATED TO ACUTE DISEASE
In general, the greater the initial serum osmolality, BUN, and blood glucose concentrations, and the lower the serum bicarbonate level (<10 mEq/L), the greater is the mortality.
Infection and myocardial infarction are the main contributors to mortality. Additional factors that increase morbidity include old age, severe hypotension, coma, and underlying renal and cardiovascular disease. Severe volume depletion leaves the elderly at risk for deep venous thrombosis.
COMPLICATIONS RELATED TO THERAPY
Major complications related to therapy of DKA are listed in Table 225­4. These include hypoglycemia, hypokalemia, hypophosphatemia, acute respiratory distress syndrome, and cerebral edema. Check QTc intervals before giving symptomatic pharmacotherapy.
TABLE 225­4
Potential Pitfalls During Treatment of DKA
Pitfall Guideline (See Text for Details)
Delay in diagnosis Blood glucose may be 250–300 milligrams/dL (13.9–16.6 mmol/L); urine ketones may initially be negative
Unrecognized precipitating illness Check ECG for infarction; examine patient for site of infection
Inadequate fluids Majority of adult patients tolerate 15–20 mL/kg/h normal saline for first hour (1–2 L normal saline), additional fluids by clinical condition/serum Na+
Unrecognized low K+ Check K+ prior to insulin
; K+ supplement before insulin for [K+] <3.3
Overemphasis on insulin Follow insulin guidelines
Hypoglycemia Goal for glucose decrease 50–75 milligrams/dL/h (2.8–4.2 mmol/L); add dextrose when glucose <250 milligrams/dL
(<13.9 mmol/L)
Unrecognized electrolyte During first  h of treatment, check glucose hourly and electrolytes every  h; check QTc intervals derangements
Overzealous use of bicarbonate and NaHCO not indicated for pH >6.9; no routine indication for phosphate supplementation
 phosphate
Recurrent DKA Avoid stopping insulin drip before anion gap resolves. Give SC insulin, feed patient, then stop insulin drip 1–2 h later
Cerebral edema NOT recognized See TABLE 225­5. Very young and new­onset patients at risk; perform frequent neurologic checks for mental early status change
Acute respiratory distress syndrome is a rare complication of therapy but may develop particularly in the elderly and those with impaired myocardial contractility. Overly aggressive fluid therapy decreases plasma oncotic pressure and raises left atrial end­diastolic pressure, favoring a shift of fluid across the pulmonary capillary membrane.
31­35
In very young children, new­onset diabetics, and adolescents with DKA, cerebral edema remains the most common and feared cause of mortality
(see Chapter 147, “Diabetes in Children”). Young age and new­onset diabetes (particularly in young adolescents) are the only identified potential risk
 factors. There are no evidence­based recommendations for adults. Cerebral edema usually develops within  to  hours but can present up to  to
,33­35
 hours after starting treatment and carries a high mortality. One hypothesis is that the osmotic diuresis promotes loss of water and sodium from both intra­ and extracellular spaces. Hyperglycemia leads to a hyperosmolar extracellular state. Brain cells enzymatically produce osmotically active particles that protect cells from further loss of water and shrinkage. During therapy with IV fluid and insulin, water moves into brain cells faster than osmotically active particles can dissipate, promoting cellular swelling.
,33
There are no specific presentation or treatment variables that predict or contribute to the development of cerebral edema. Monitor the relationship between the increase in sodium compared to the decrease in plasma glucose levels during the initial treatment phase of DKA. Gradual replacement of water and sodium deficits and slow correction of hyperglycemia may lessen the risk of cerebral edema by avoiding rapid changes in
 water movement between the intracellular and extracellular spaces.
TABLE 225­5
Best Practice to Prevent Cerebral Edema
Slow reduction of osmolality during treatment
Avoid large volumes of hypotonic fluid
Drop blood glucose slowly during treatment
Do not allow plasma Na+ to fall during treatment
Avoid unnecessary bicarbonate during treatment
Avoid hypoxia, hypo­K+, PO , Mg

Premonitory symptoms are severe headache, incontinence, change in arousal or behavior, pupillary changes, blood pressure changes, seizures, bradycardia, or disturbed temperature regulation. Any change in neurologic function early in therapy is an indication for IV mannitol (1 to 
 grams/kg). Mannitol should be given before respiratory failure or obtaining confirmatory CT scans because serious morbidity and mortality may be
,29,33 prevented. Hypertonic saline (3%),  to  mL/kg over  minutes, may be an alternative to mannitol. Intubation and fluid restriction are generally necessary. There are no data supporting glucocorticoid use in DKA­related cerebral edema.
LATER COMPLICATIONS
Metabolic acidosis refractory to routine therapy may be secondary to unrecognized infection (lactic acidosis), rarely insulin antibodies, or improper preparation or administration of the insulin drip. Shock that is unresponsive to aggressive fluid therapy suggests gram­negative bacteremia or silent myocardial infarction. Hyperchloremic non–anion gap metabolic acidosis can develop during therapy due to rapid volume expansion in the face of reduced bicarbonate. In addition, bicarbonate equivalents are excreted in the urine as ketones and are replaced with chloride provided by the normal saline. This emphasizes the importance of monitoring the anion gap during therapy. The non–anion gap metabolic acidosis resolves during recovery as bicarbonate is regenerated and excess chloride is excreted in the urine.
Late vascular thrombosis may occur in any muscular artery, although the cerebral vessels appear to be most susceptible. Volume depletion, low cardiac output, increased blood viscosity, and underlying atherosclerosis may predispose the elderly to this complication. Thrombosis may occur several hours or days after institution of therapy and after resolution of ketoacidosis. Despite this increased risk, no studies support prophylactic
,14 anticoagulant use, although some experts suggest the use of heparin may be beneficial in DKA if there is no associated bleeding disorder.
Mortality in DKA results mainly from sepsis or pulmonary and cardiovascular complications in the elderly and fatal cerebral edema in children and young adults (Table 225­6).
TABLE 225­6
Complications of Diabetic Ketoacidosis
Related to Acute Disease Related to Therapy Later Complications
Loss of airway Hypokalemia Recurrent anion gap metabolic acidosis
Sepsis Hypophosphatemia Non–anion gap metabolic acidosis
Myocardial infarction Acute respiratory distress syndrome Vascular thrombosis
Hypovolemic shock Cerebral edema Mucormycosis
Hypoglycemia
DISPOSITION AND FOLLOW­UP
The great majority of patients require hospitalization in a monitored setting where there is nursing experience with IV insulin infusions. In many institutions, patients are cared for initially in an intensive or intermediate care unit. A select group of patients with an anion gap of <25, a glucose level of <600 milligrams/dL (<33.3 mmol/L), and no comorbidity at the time of disposition decision may be managed safely on an inpatient unit with nursing expertise using insulin infusions and managing diabetic patients. Some institutions may have protocols for the use of SC rapid­acting insulin on a medical floor. Patients presenting early in the course of their illness who can tolerate oral liquids may be managed safely in the ED or observation unit and discharged after  to  hours of therapy.
SPECIAL POPULATIONS
RECURRENT DKA PATIENTS
Patients who present to the ED with recurrent episodes of DKA should have barriers to care access addressed while in the ED or during their hospital stay. In urban settings, insulin noncompliance is a major trigger for recurrent DKA. Cocaine is an independent risk factor for DKA, and patients who use
,7 illicit drugs may benefit from drug rehabilitation. Using social workers to assist patients with drug access and affordability, drug rehabilitation when
 indicated, and education provided by the diabetic care team can promote improved glycemic control.
PATIENTS WITH INSULIN PUMPS
See Chapter 223 for a detailed discussion of insulin pumps (See Video: Insulin Pump). Patients with insulin pumps who are suspected to have
DKA should have their pumps disconnected and turned off and should be treated just like any other patient. Reinstitution of pump therapy should start in the same time frame as switching over to SC insulin in the non–pump user.
DKA IN PREGNANCY
,37
DKA in pregnancy is a leading cause of fetal loss, with a fetal mortality rate of approximately 30%. Several physiologic changes make diabetic pregnant women prone to DKA. Maternal fasting serum glucose levels are normally lower than in the nonpregnant state, which leads to relative insulin
 deficiency and an increase in baseline free fatty acid levels in the blood. DKA is triggered at lower sugar levels in pregnancy, so the provider should
,38 recognize signs and symptoms of DKA and check a serum βHB level. Pregnant women normally have increased levels of counterregulatory hormones. In addition, the chronic respiratory alkalosis seen in pregnancy leads to decreased bicarbonate levels due to a compensatory renal
 response, resulting in a decrease in buffering capacity. Pregnancy is associated with vomiting and urinary tract infections, which can precipitate DKA.
Maternal hyperglycemia causes fetal hyperglycemia and osmotic diuresis. Maternal acidosis causes fetal acidosis, decreases uterine blood flow and fetal oxygenation, and shifts the oxygen­hemoglobin dissociation curve to the right. Maternal hypokalemia also can lead to fetal dysrhythmias and death. Correcting maternal hyperglycemia, acidosis, and electrolyte balance is the first priority.


