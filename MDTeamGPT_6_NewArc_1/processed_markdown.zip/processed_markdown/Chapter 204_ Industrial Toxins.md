## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 204: Industrial Toxins
Chip Gresham; Frank LoVecchio
Content Update: March 2023
The February , 2023 crash site of the Norfolk Southern Railway in East Palestine, Ohio, USA, released a number of toxic chemicals. Review of exposure effects from vinyl chloride, butyl acrylate, ethylene glycol, isobutylene, and ethylnexyl acrylate are provided at the end of this chapter, in the section entitled ‘Vinyl Chloride and additional toxic chemicals from railway derailment’.
INTRODUCTION
A hazardous chemical is defined by the U.S. Occupational Safety and Health Administration as any chemical that has been scientifically shown to be a health hazard (causes acute or chronic health effects) or a physical hazard (e.g., combustible liquid, explosive, flammable). The Occupational Safety
 and Health Administration estimates that there are 575,000 chemicals in the workplace, with ,000 being potentially hazardous. Considering that unplanned exposures and contamination can occur at any time during manufacturing, transport, storage, usage, or disposal of these chemicals, inevitably, emergency physicians can expect to occasionally be responsible for the management and care of a hazardous materials patient (see

Chapter , “Disaster Preparedness”).
When managing a patient exposed to an industrial chemical, it is helpful to refer to the Material Safety Data Sheet and adhere to the recommendations regarding decontamination. Although the Material Safety Data Sheet will also include “first aid” recommendations (Table 204­1), the provider should also consult with a medical toxicologist or a regional poison control center to discuss case­specific hazards, optimal treatments, and dispositions.
Although many exposures produce immediate effects, some agents may result in delayed onset of symptoms that require at least  hours of observation (Table 204­2).
TABLE 204­1
Agents Absorbed Through Intact Skin That May Result in Systemic Toxicity* Acrylamide Methyl bromide
Acrylonitrile, acetonitrile, propionitrile Methylene chloride (slow)
Aniline Nerve agents
Chlordane Nitrates
Dinitrophenol Nitrobenzene
Hydrocarbons: benzene, gasoline, toluene, xylene (all slowly absorbed) Pesticides
Phenol
Hydrogen cyanide, cyanide salts T2 toxin (biologic)

ChapteHry d2r0o4g:e Inn fdluuosrtirdiae l( hTyodxrionfslu,o Crihc iapc iGd)resham; Frank LoVecchio 
. Terms of Use * Privacy Policy * Notice * Accessibility
Metals (organic mercury, thallium)
*Many toxins may be absorbed through abraded skin.
TABLE 204­2
Toxins With Delayed Onset of Symptoms or Requiring Prolonged Monitoring
Agent Potential Delayed Toxicity
Acrylonitrile, acetonitrile, propionitrile Cyanide toxicity
Aniline Methemoglobinemia
Arsine Hemolysis
Ethylene oxide Pulmonary edema and neurotoxicity
Methyl bromide Pulmonary edema
Methylene chloride Carbon monoxide toxicity, dysrhythmias
Phosphine Pulmonary edema
Zinc phosphide Pulmonary edema
Children are more sensitive to chemical exposures; higher minute volumes, smaller airway diameters, and lesser ability to clear secretions make them more susceptible to inhaled toxins, and thinner, more permeable skin with a larger body surface­to­mass ratio increases the potential for dermal
3­5  absorption. A pregnant woman should be treated as any other adult patient.
This chapter discusses industrial toxins that produce primarily respiratory toxicity (Table 204­3) or metabolic toxicity. Toxic chemicals discussed elsewhere include nerve agents and vesicants (see Chapter , “Chemical Disasters”); hydrocarbons (see Chapter 199, “Hydrocarbons and Volatile
Substances”); acids and alkalis (see Chapter 200, “Caustic Ingestions”); organophosphates and carbamates (see Chapter 201, “Pesticides”); metals
(see Chapter 203, “Metals and Metalloids”); oxidants (see Chapter 207, “Dyshemoglobinemias”); and carbon monoxide (see Chapter 222, “Carbon
Monoxide”).
RESPIRATORY TOXINS
Determinants of airborne agent toxicity primarily include factors such as concentration of the inhaled toxin, duration of exposure, and whether the exposure occurred in an enclosed space (Table 204­3). Other influential factors include vapor density, allergic or nonallergic bronchospastic response, exertional state or metabolic rate of the victim, and unique host susceptibility such as underlying reactive airway disease, history of smoking, or extreme age. Aspiration of gastric contents may cause further pulmonary insult.
TABLE 204­3
Toxic Industrial Exposures That Cause Respiratory Symptoms
Agent Irritant Signs/Symptoms/Findings Treatment
Phosgene Mild/none I—Eye and upper airway irritation; possibly none Supplemental oxygen only if hypoxemic
D—Dyspnea, noncardiogenic pulmonary edema (SaO2 <92%)
Respiratory supportive care
Consider nebulized β­agonists
Mandatory rest
Ocular care
Chlorine Yes I—Eye and upper airway irritation, nausea and vomiting (low­level exposure) Humidified oxygen
D—Pulmonary edema (high­level exposure) Respiratory supportive care
Consider nebulized β­agonists
Consider nebulized sodium bicarbonate
Ocular care
Nitrogen Yes I—Dyspnea with transient improvement Humidified oxygen dioxide D—Worsening dyspnea due to pulmonary edema 24–72 h after exposure; Respiratory supportive care methemoglobinemia Consider early corticosteroid treatment
Ammonia Yes I—Coughing, hoarseness, bronchospasm, eye and upper airway irritation Humidified oxygen
Consider nebulized β­agonists
Consider nebulized anticholinergics
Respiratory supportive care
Ocular care
Abbreviations: D = delayed; I = immediate; SaO2 = arterial oxygen saturation.
General management of the patient with toxic inhalation injury begins with removal from the source and supplemental oxygen for hypoxemia. Irrigate the eyes and skin as appropriate. Toxin­specific treatments are discussed later in this chapter, although in general, inhaled bronchodilators and steroids for bronchospasm may be considered, especially if the patient has underlying reactive airway disease. Prophylactic antibiotics are not indicated.
The physical examination should include inspection of the upper airway for evidence of singed nasal hair, soot in the oropharynx, facial or oropharyngeal burns, stridor, hoarseness, dysphagia, cough, carbonaceous sputum, tachypnea, retractions, accessory muscle use, wheezing, or cyanosis. Copious airway secretions, hypoxia, bronchospasm, and pulmonary edema indicate lower airway injury, and with the potential for sudden deterioration in patients with upper airway injury, there should be a low threshold for endotracheal intubation.
Pertinent laboratory studies include arterial blood gas analysis with carboxyhemoglobin, methemoglobin, and lactate levels; whole­blood cyanide levels if persistent acidosis occurs (although this will not change immediate management); ECG monitoring; and chest radiography. The role for diagnostic or therapeutic bronchoscopy in inhaled toxin exposure is controversial.
PHOSGENE
Phosgene was first used as a chemical agent of warfare in World War I, where it was responsible for 80% of all chemical gas fatalities. Phosgene is no longer stockpiled by the U.S. military; however, it has widespread use in manufacturing and industry as a chemical precursor in the production of
,8 plastics, pharmaceuticals, dyes, polyurethane, and pesticides. The heating of chlorinated fluorocarbons (Freon®) will also form phosgene gas and
 has caused poisonings in the refrigerator/air conditioner manufacturing and repairing industry.
Phosgene release and contamination can be insidious. The gas is relatively water insoluble and therefore has poor warning properties. Only mild
 initial eye, nose, throat, and upper airway irritation are expected, and these may be entirely absent. Classically, when released, phosgene forms a white cloud with a characteristic odor of newly mown hay. The major injury is an acid burn to lower airways as phosgene reaches the alveoli and
 hydrolyzes to carbon dioxide and hydrochloric acid. Acylation of alveolar capillary membranes results in diffuse capillary leak and noncardiogenic
,11 pulmonary edema, which may be delayed for up to  hours.
Symptoms are typically dyspnea and chest tightness. If the exposure is massive, immediate dyspnea and mucous membrane and eye irritation may
 occur. The onset of dyspnea or pulmonary edema within  hours of exposure suggests a very poor prognosis.

Recovery usually occurs with respiratory supportive care and management of acute lung injury (noncardiogenic pulmonary edema). Do not provide supplemental oxygen until symptoms and signs of hypoxia develop or arterial oxygen saturation falls, and then administer at the lowest fraction of
 inspired oxygen to maintain arterial oxygen saturation above 94%.
Pharmacologic therapy recommendations, based on case reports and animal models, include early corticosteroids and nebulized β­agonists,
,14,15 nebulized N­acetylcysteine, and NSAIDs.

Exertion increases pulmonary edema from phosgene, so rest is mandatory. If patients require intubation and mechanical ventilation for respiratory
,17 failure, a protective ventilation strategy with low tidal volume, low plateau pressures, and high positive end­expiratory pressure should be used.
Observe and monitor even asymptomatic patients for  hours after acute exposure.
CHLORINE
Chlorine is widely available in the industrial sector, in the setting of laboratories, paper manufacturing, swimming pool maintenance, and municipal
18­21  water treatment. Chlorine gas also has potential for use as an unconventional weapon. When dispersed, this dense green­yellow gas has an acrid, pungent odor and, unlike phosgene, has excellent warning properties. Chlorine gas has intermediate water solubility, which is consistent with
 the observation that moderately exposed World War I soldiers exhibited both central airway damage and pulmonary edema.

Early inflammatory injury results from the formation of hydrochloric and hypochlorous acids and oxidants upon contact with moist membranes.
,25,26
Immediate ocular and upper airway irritation along with nausea and vomiting are common following mild exposures. More significant exposure results in coughing, hoarseness, and pulmonary edema, usually within  hours, with some exposures leading to acute respiratory distress
,27  syndrome. Severe exposures may produce pulmonary infiltrates or edema visible on radiographs or CT scan.

Care is primarily supportive, with the use of humidified oxygen and bronchodilators as needed. Prophylactic antibiotics are not recommended.
Nebulized sodium bicarbonate as a neutralizing therapy may improve pulmonary function during the initial  hours of treatment, but the long­term
,29,30 benefits are unproven. Uncontrolled studies of both parenteral and inhaled steroids show improvement in airway resistance and arterial
 oxygenation but no improvement in the outcome with severe lung injury. Chlorine causes dermal injury at high concentration, and skin decontamination may be required. In patients with ocular symptoms, the cornea should be evaluated for a chemical burn. A moderately symptomatic patient should be observed for  hours, monitoring for delayed onset of respiratory complications.
NITROGEN DIOXIDE
Nitrogen dioxide and other nitrogen oxides are encountered in the form of silo gas (“silo filler disease”), as products of combustion, in
,33 industrial processes, or as components of military blast weapons, smokes, and obscurants. These oxides have limited water solubility that results
 in primarily lower airway toxicity. Initial exposure may produce only very mild initial discomfort, but slow conversion of nitrogen dioxide to nitric acid
,35­37 in the alveoli results in delayed alveolar injury and pulmonary edema. Thus, a triphasic illness typically is seen with initial dyspnea and flulike
,35,37­39 symptoms, transient improvement, and then worsening dyspnea, which heralds the onset of pulmonary edema  hours after exposure.

Treatment is supportive. Case reports describe benefit with early corticosteroid treatment for acute lung injury following nitrogen dioxide exposure,
 although overall evidence is inconclusive.
AMMONIA

Ammonia is widely available; it is found in household and industrial chemicals and fertilizers and used in the synthesis of plastics and explosives.
Ammonia is a highly water­soluble, colorless, alkaline, corrosive gas with a characteristic pungent odor that rapidly reacts with wet surfaces to form ammonium hydroxide. Ammonia has good warning properties due to its odor and immediate symptoms of mucous membrane, eye, and throat irritation. Lower airway involvement resulting in bronchospasm, pulmonary edema, residual reactive airway disease, and even permanent lung injury
 has been described following massive exposures, especially in those who were entrapped in enclosed spaces.

Treatment is supportive with humidified oxygen and bronchodilators. The use of anticholinergics to control airway secretions has been reported.
Concentrated ammonia, such as .4% ammonia hydroxide, is hazardous to the eyes, and symptomatic patients should undergo ocular irrigation followed by evaluation for corneal burns.
METABOLIC TOXINS
CYANIDE
Cyanide has an infamous history. It was the agent used by Nazi Germany (Zyklon B) in the gas chambers during the Holocaust, by Jim Jones in the mass cult suicide at the People’s Temple in Guyana (commonly called “Jonestown”), for murder in over­the­counter drug­tampering incidents, and at
,44 the World Trade Center bombing in 1993. Cyanide can be generated through natural and industrial processes and house and structure fires
(Table 204­4).
TABLE 204­4
Sources of Cyanide
Burning of: wool, nylon, silk, acrylic, polyurethane, melamine, polyacrylonitrile, polyamide plastics
Industries: fabrication of plastics, electroplating, mining, photography, precious metal reclamation, solvents, hair removal from hides
Fumigants and fertilizers
Vermin extermination: cyanide spread into burrows and dens
Chemistry laboratories
Medicinal: laetrile (amygdalin),* sodium nitroprusside
Plants: seeds from Prunus species (apricots, cherries, plums, peaches), cassava, bamboo shoots
Illicit phencyclidine manufacturing
Cigarette smoke
Vehicle exhaust
*No longer available in the United States, but widely available via the Internet and sold outside the United States.
PATHOPHYSIOLOGY
Cyanide inhibits many metabolic processes, with its most toxic effect from binding with very high affinity to the ferric ion cytochrome a portion of
 cytochrome oxidase within the mitochondria, resulting in an abrupt cessation of electron transport and oxidative phosphorylation, thus inhibiting
 aerobic metabolism. Thus, following an acute exposure, organs and tissues with high oxygen consumption are the first and most severely affected.
Cassava, a tropical root that is the food staple in many countries, contains the cyanogenic glycosides linamarin and lotaustralin that liberate cyanide
 when metabolized in the body. Chronic exposure to dietary cyanide is linked to tropical ataxic neuropathy and is endemic in countries where
,47 cassava consumption is high.
The primary mechanism for detoxification of cyanide is its metabolism in the liver by rhodanese to thiocyanate, a nontoxic compound that is renally excreted. Toxicity occurs when this mechanism is rapidly overwhelmed.
CLINICAL FEATURES
Clinical presentation of the cyanide­poisoned patient depends on the cyanide­containing compound, the route, concentration and duration of
 exposure, and the time since exposure. The onset of symptoms following inhalational exposure to hydrogen cyanide gas is immediate. Exposure to
 concentrations <50 parts per million causes restlessness, anxiety, palpitations, dyspnea, and headache. Higher concentrations of hydrogen cyanide gas cause severe dyspnea, loss of consciousness, seizures, and cardiac dysrhythmias. Coma, cardiovascular collapse, and death may occur immediately on exposure to very high levels. The median lethal dose for humans from hydrogen cyanide gas is estimated to be 200 parts per million for
 a 30­minute exposure and 600 to 700 parts per million for a 5­minute exposure. The onset of symptoms following ingestion of a cyanide salt typically occurs within minutes. The median lethal dose of potassium or sodium cyanide in an untreated adult is estimated at 140 to 250 milligrams, but death
 has been reported with ingestion of as little as  milligrams, and survival has been reported with much larger ingestions when antidotes are used.
,50
The typical seriously poisoned patient has an altered level of consciousness and is hyperventilating, hypotensive, and bradycardic (Table 204­5).
Cutaneous manifestations vary, but, importantly, the patient is not initially cyanotic, as cyanide does not significantly alter the oxygen­carrying capacity of hemoglobin. However, cyanosis does follow if there is significant respiratory compromise or arrest. The smell of bitter almonds and a cherry­red skin color (attributed to an increased venous hemoglobin oxygen saturation) are often used in describing cyanide poisoning; however, these findings
 are unreliable and should not be used to exclude cyanide poisoning.
TABLE 204­5
Signs and Symptoms of Acute Cyanide Toxicity
Table 204­5. Signs and Symptoms of Acute Cyanide Toxicity
Cardiovascular
Tachycardia
Hypertension
Bradycardia
Hypotension
Cardiovascular collapse
Asystole
CNS
Headache
Drowsiness
Seizures
Coma
Pulmonary
Dyspnea
Tachypnea
Apnea

Severe unexplained metabolic acidosis is a consistent clinical feature (Table 204­6). In victims of smoke inhalation, toxic cyanide levels
 correlate with plasma lactate levels >90 milligrams/dL (>10 mmol/L), independent of the carbon monoxide level. The decision to institute antidotal treatment of cyanide poisoning must be made long before confirmatory laboratory studies can be obtained. Although cyanide levels are not closely correlated with toxicity, they can be used to retrospectively confirm a clinical diagnosis or for forensic purposes. A variety of methods are available to
 measure cyanide in the environment and in biologic fluids, but whole­blood cyanide level is the most commonly available test.
TABLE 204­6
Anticipated Laboratory Findings in Cyanide Poisoning
Test Result Cause
Serum electrolytes Elevated anion gap Lactic acidosis from anaerobic metabolism
Arterial blood gases Metabolic acidosis Oxygenation initially normal
Normal PaO2
Lactate >90 milligrams/dL (>10 mmol/L) Correlates with toxic cyanide level
Measured oxygen saturation by co­ Normal Hemoglobin retains normal oxygen­carrying capacity oximetry
Measured arterial­mixed venous oxygen Decreased Decreased tissue oxygen consumption difference
Whole­blood cyanide level Toxic >0.5 microgram/mL (>12 Note: plasma cyanide levels are roughly one tenth of the whole­blood mmol/L) cyanide levels
Fatal >2.5 micrograms/mL (>60 mmol/L)
Fire victims Elevated carboxyhemoglobin Carbon monoxide generated by incomplete combustion level Synergistic toxicity with cyanide
Abbreviation: PaO2 = partial pressure of arterial oxygen.
Symptoms of poisoning are delayed following the ingestion of compounds that require metabolic activation to release free cyanide, such as
  acetonitrile, a solvent sold commercially as a cosmetic nail remover, and amygdalin from apricot pits. The slow release of cyanide by the spontaneous degradation of sodium nitroprusside, which is increased by exposure to sunlight, also results in delayed toxicity, particularly during
 prolonged or high­dose infusions.
TREATMENT

Good supportive care with 100% oxygen along with crystalloids and vasopressors for hypotension is paramount. There are multiple antidotes for
,57­59 cyanide poisoning with variation in regional availability. The two antidotes most commonly used in the United States are hydroxocobalamin
(Cyanokit®) and the cyanide antidote kit (containing nitrites and thiosulfate). While their efficacy is similar, their mechanisms of action vary greatly and are described in further detail later in this chapter. Due to the production of methemoglobin by the nitrites in the cyanide antidote kit, hydroxocobalamin should be considered the first­line therapy in cyanide poisoning if exposure involves fire smoke or any other
60­64 potential source of concomitant carbon monoxide poisoning.
The decision to administer a cyanide antidote is straightforward when faced with a critically ill patient with clear history of cyanide exposure. More difficult management decisions arise in patients with smoke inhalation who may have carbon monoxide exposure as well as suspected cyanide exposure and in patients who are critically ill and acidotic without any known history of cyanide exposure. Consultation with a toxicologist or the regional poison control center is advised. However, there are some cases that should be treated empirically without delay. Patients who have been exposed to smoke and/or fire and present with a Glasgow Coma Scale score of <10 with signs of end­organ damage (i.e., cardiac arrest, seizures, respiratory distress) should be empirically treated with hydroxocobalamin or thiosulfate; a carboxyhemoglobin level >10% and/or lactate level of >8
,65 mmol/L strengthen this decision.
Hydroxocobalamin (vitamin B ) is a metalloprotein with a cobalt center that binds cyanide, removing it from cytochrome oxidase and forming
12a cyanocobalamin, which is then eliminated via the kidneys. The dose of hydroxocobalamin in an adult patient is  grams IV over  minutes (Table 204­

7). A second dose of  grams IV may be repeated once (for a total of  grams) if the patient’s condition warrants. The pediatric dose is 
 milligrams/kg (maximum dose of  grams) IV over  minutes and may be repeated once if the patient’s condition warrants. Hydroxocobalamin has a low toxicity profile; side effects include transient hypertension, a reddish discoloration of the skin and mucous membranes, and rare anaphylactic reactions. Due to the discoloration of body fluids caused by hydroxocobalamin, interference with chemistry and co­oximetry tests as well as
68­71 hemodialysis machines has been reported; therefore, blood samples should be collected prior to administration.
TABLE 204­7
Treatment of Cyanide Poisoning With Hydroxocobalamin
100% oxygen
IV crystalloids and vasopressors for hypotension
+/– Sodium bicarbonate for acidemia
And
Hydroxocobalamin Adults:  grams IV over  min. If needed, may repeat  grams for a total of  grams.
Children:  milligrams/kg (maximum,  grams) IV over  min. If needed, may repeat once.
The cyanide antidote kit has been well established for cyanide poisoning, although its use is declining and it has been removed from the
72­74 commercial market in some countries. The antidotes contained in the cyanide treatment kit include ampules of amyl nitrite for inhalation, 10­mL vials of 3% sodium nitrite (300 milligrams), and 50­mL vials of 25% sodium thiosulfate (12.5 grams) (Table 204­8). Treatment of profound acidemia
 with sodium bicarbonate appears to enhance the effect of the nitrites and thiosulfate.
TABLE 204­8
Treatment of Cyanide Poisoning With Cyanide Antidote Kit
100% oxygen
IV crystalloids and vasopressors for hypotension
+/– Sodium bicarbonate for acidemia
And
Adults Amyl nitrite inhaler; crack vial and inhale over  s.* Sodium nitrite 3% solution:  mL (300 milligrams) IV given over no less than  min.†
Sodium thiosulfate 25% solution:  mL (12.5 grams) IV. Repeat sodium thiosulfate once at half dose (25 mL) if symptoms persist.
Children Amyl nitrite inhaler; crack vial and hold in front of nose for 15–30 s.*†
Sodium nitrite 3% solution: adjusted according to hemoglobin level, given IV over no less than  min† (monitor methemoglobin level <30%).
Hemoglobin (grams/100 Sodium Nitrite 3% Solution (mL/kg) mL)

Sodium thiosulfate 25% solution: .65 mL/kg IV.
Repeat sodium thiosulfate once at half dose (0.825 mL/kg) if symptoms persist.
*Not necessary if IV is in place.
†Avoid nitrites in the presence of severe hypotension if diagnosis is unclear or there is potential concomitant carbon monoxide poisoning; use sodium thiosulfate only.
The rationale for using nitrites is based on their ability to form methemoglobin, which binds cyanide more avidly than the ferric iron of cytochrome
 oxidase, thus removing cyanide from the cytochrome and enabling the mitochondria to reactivate electron transport and oxidative metabolism.
Inhaled amyl nitrite is a temporizing measure when IV access has not been established, but amyl nitrite is not needed when sodium nitrite can be given IV. Nitrites do have significant side effects, including hypotension and the development of excessive methemoglobinemia, which will further
,75,77 decrease oxygen delivery with concomitant carbon monoxide poisoning. However, hypotension is not a contraindication to nitrite therapy in severe cyanide poisoning. In children, the sodium nitrite dose is adjusted according to the hemoglobin level to keep the methemoglobin level less than
,77
30% (Table 204­8). If hemoglobin values are not available, the empiric dose of sodium nitrite for a child less than  kg is based on the 10­gram
 hemoglobin concentration.
Sodium thiosulfate, given after the administration of sodium nitrite, enhances the activity of the enzyme rhodanese, which catalyzes the transfer of
,72,75 sulfate from sodium thiosulfate to cyanide to form thiocyanate, a less toxic form that is excreted by the kidneys. Animal studies using lethal
,73,75 doses of cyanide demonstrate that the therapeutic effects of sodium nitrite and sodium thiosulfate are synergistic. However, sodium thiosulfate has very limited toxicity in comparison with nitrites and should be used as a sole therapy for victims of cyanide poisoning from inhalation injury if there
,79 is a concern for concomitant carbon monoxide exposure if hydroxocobalamin is unavailable.
The fetus is sensitive to the adverse effects of methemoglobinemia, so nitrate therapy should be avoided. Animal models have shown that sodium
 thiosulfate does not cross the placenta and appears to protect the fetus from nitroprusside in cyanide toxicity ; if available, it should be considered
 first in early pregnancy. There are limited data on the safety of hydroxocobalamin in pregnancy, but its benefits outweigh the risk in significant
 cyanide poisoning and should be administered if it is the only antidote available.
Two other antidotes are available, which are primarily used in Europe. Dimethylaminophenol is a rapid methemoglobin inducer developed in
57­59,75
Germany for the treatment of cyanide poisoning. Clinical efficacy is similar to sodium nitrite. The adult dose is 250 milligrams (5 mL of 5% solution) IV over  minute, used in combination with sodium thiosulfate. Dicobalt edetate is a cobalt compound with a high affinity for cyanide.
Although highly effective as a cyanide antidote, the toxicity of dicobalt edetate is greater when cyanide is not present, limiting its use to cases where the
,44,57­59,75 presence of cyanide is unequivocal. The adult dose for dicobalt edetate is 300 milligrams IV over approximately  minute. If there is inadequate clinical response after  minutes, a second dose of 300 milligrams IV may be given.
The data on hyperbaric oxygen for treatment of cyanide poisoning are conflicting, because studied patients also received multiple therapies, so
81­83 improvement cannot be contributed solely to hyperbaric oxygen. The lack of supportive evidence and impracticality make hyperbaric oxygen therapy an unproven endeavor in acute cyanide toxicity.
DISPOSITION AND FOLLOW­UP
Patients who receive cyanide antidotal therapy should be admitted for observation. Patients who have ingested a substance that may result in delayed toxicity (up to  hours) should also be admitted. Full recovery is anticipated in many cases of severe poisoning in which treatment is initiated rapidly and cardiac arrest has not yet occurred. Recovery despite cardiac arrest also has been reported, but anoxic encephalopathy may ensue.
HYDROGEN SULFIDE
Hydrogen sulfide is a colorless, flammable gas that may be encountered in industries such as oil and gas or as a natural product of organic
,85 decomposition, such as sewer or manure gas. Hydrogen sulfide can be made by mixing common household products, a method well documented
 in suicides. Regardless of its source, it is among the most common causes of fatal gas inhalation exposures. Fatal exposures usually occur in
 enclosed spaces that may claim additional victims as would­be rescuers are poisoned upon entering. Large industrial or natural releases of hydrogen
 sulfide may produce fatalities in unconfined spaces.
PATHOPHYSIOLOGY
The mechanism of toxicity is similar to that of cyanide, with disruption of oxidative phosphorylation through inhibition of cytochrome oxidase a ,

 except this impairment reverses rapidly when hydrogen sulfide exposure ceases. Cellular asphyxia and impaired adenosine triphosphate production promote anaerobic metabolism with lactate accumulation and metabolic acidosis.
CLINICAL FEATURES
Hydrogen sulfide is one of the few chemical asphyxiants that also possesses irritative properties, such that respiratory and ocular irritation are
,90 common following exposure. However the characteristic odor of “rotten eggs” may not be noticed due to olfactory fatigue from persistent lowlevel exposures or from acute olfactory paralysis seen at high hydrogen sulfide levels. In high concentrations, rapid loss of consciousness, seizures,
 and death occur after only a few breaths. Delayed pulmonary edema and corneal injury should be anticipated in survivors of massive exposures.
TREATMENT

Treatment begins with removal from the source, administration of high­flow oxygen, and decontamination of the skin and eyes, as appropriate. For patients still conscious, symptoms resolve with this treatment alone. For patients with altered sensorium or impaired cardiovascular function after hydrogen sulfide exposure, administration of sodium nitrite 300 milligrams IV over  to  minutes can produce rapid improvement, but only when
,92 given within minutes of exposure. The concept behind this treatment is that low­level methemoglobin formation may enhance conversion of sulfide to the less toxic sulfmethemoglobin. An animal model of lethal hydrogen sulfide toxicity found benefit with both cobinamide and
,94 hydroxocobalamin, but human treatment experience is needed before this agent can be recommended. Hyperbaric oxygen therapy for hydrogen
,95 sulfide toxicity has been described in multiple published case reports, but there is no evidence that it is superior to standard oxygen therapy.
DISPOSITION AND FOLLOW­UP
Patients who receive cyanide antidotal therapy should be admitted for observation. Full recovery is anticipated in many cases of severe poisoning in which treatment is initiated rapidly and cardiac arrest has not yet occurred.
VINYL CHLORIDE AND ADDITIONAL TOXIC CHEMICALS FROM DERAILMENT
On Feb. , 2023 the Norfolk Southern Railway train derailed in East Palestine, Ohio, USA. The US Environmental Protection Agency (EPA) reported that the derailment resulted in the release of multiple toxic chemicals into air, soil, and water, including vinyl chloride, butyl acrylate, ethylene glycol, isobutylene, and ethylhexyl acrylate.
VINYL CHLORIDE is a colorless, flammable gas and known carcinogen. Most studies on vinyl chloride are related to occupational exposure. Longerterm, chronic exposures have been linked to certain liver, brain and lung cancers, lymphomas, and leukemia. Vinyl chloride does not occur naturally and is most used to make polyvinyl chloride (PVC). Vinyl chloride in water or soil evaporates rapidly if it is near the surface. Airborne vinyl chloride spontaneously breaks down in a few days, resulting in the formation of several other chemicals including hydrochloric acid, formaldehyde, and carbon dioxide and phosgene if burned. You can be exposed to vinyl chloride by drinking water from contaminated wells, but it is unlikely to build up in plants or animals used for human consumption.
Acute toxic effects of vinyl chloride include dizziness, headache, drowsiness, and in severe cases, coma. Vinyl chloride can cause irritation of the eyes,
(96) skin, and respiratory system.
Chronic exposure to vinyl chloride has been associated with a variety of health problems, including liver toxicity, nerve damage, Raynaud’s phenomenon and an increased risk of cancer, especially liver cancer, specifically angiosarcoma.
Vinyl chloride exposure may be associated with hepatocellular carcinoma. Vinyl chloride is causally associated with the development of a form of noncirrhotic portal hypertension related to sinusoidal endothelial damage, and to angiosarcoma of the liver. The mean latency between exposure and the
(97) development of angiosarcoma of the liver in one registry was  years.
No diagnostic tests are readily available to the emergency department. Provide supportive care for acute irritant effects and arrange for long­term followup.
BUTYL ACRYLATE is a colorless liquid used to manufacture paints, solvents, and sealants. Exposure can cause irritation to the nose and eyes and
(98) nausea, as well as allergic skin reactions. Chronic respiratory symptoms such as dyspnea and cough have been reported.
ETHYLENE GLYCOL is a solvent used in paints, inks, cleaning products and antifreeze. It is flammable and acutely toxic if ingested. Inhalation or topical exposure would result in irritation of the skin and eyes, causing sore throat, coughing and skin rashes. It is unlikely to cause metabolic derangements and renal failure if exposed to a minimal amount topically or by inhalation. Symptomatic patients should be evaluated, and blood work considered. (see Chapter 185, Alcohols).
ISOBUTYLENE is a gas used as an antioxidant in packaging and plastics. At moderate concentrations it can cause dizziness and drowsiness.
ETHYLHEXYL ACRYLATE is a colorless liquid used to make paints and plastics that acutely can cause skin and respiratory irritation, sore throat, nausea, vomiting and diarrhea.


