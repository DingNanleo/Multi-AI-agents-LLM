## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 208: Cold Injuries
Michael T. Paddock
INTRODUCTION
The occurrence of cold­related injuries depends on the degree of cold exposure, as well as environmental and individual factors. Frostbite is the prototypical freezing injury and is seen when ambient temperatures are well below freezing. Nonfreezing cold injuries occur as a result of exposure to wet conditions when temperatures are above freezing. The most common nonfreezing cold injuries are trench foot and chilblains. Although frostbite is likely to result in permanent tissue damage, nonfreezing cold injuries are characterized by usually mild but uncomfortable inflammatory lesions of the skin. This chapter describes the occurrence, risk factors, and treatment of the nonfreezing cold injuries—trench foot and immersion foot, chilblains or pernio, panniculitis, and cold urticaria—and freezing injury—frostbite.
NONFREEZING COLD INJURIES
TRENCH FOOT
Trench foot, or immersion foot, was first identified during military operations. Homelessness, alcoholism, substance abuse, and psychiatric disorders
,2 are risk factors for trench foot. The pathophysiology of trench foot is multifactorial, but involves direct injury to soft tissue and peripheral nerves
 sustained from prolonged cooling, accelerated by wet conditions.
Early symptoms progress from subjective tingling to numbness of the affected tissues. On initial examination, the foot may appear pale, mottled, anesthetic, pulseless, and immobile, with no immediate change after rewarming. A hyperemic phase begins within hours after rewarming and is associated with severe burning pain and reappearance of proximal sensation. As perfusion returns to the foot over  to  days, edema and bullae may form. Anesthesia frequently persists for weeks and may be permanent. In more severe cases, tissue sloughing and gangrene may develop.
Hyperhidrosis and cold sensitivity are common late features and may persist for months to years. Severe cases may be associated with prolonged
 convalescence and permanent disability. Treatment is supportive, but vasodilator drugs may be tried, such as oral prostaglandin E , limaprost, a
 vasodilator that increases blood flow and inhibits platelet aggregation. Limaprost,  micrograms orally three times daily, has been shown to increase
 skin temperature, which suggests improved circulation. Feet should be kept clean and warm and be dryly bandaged, elevated, and closely monitored for early signs of infection. Prophylaxis for trench foot includes keeping warm, ensuring good boot fit, changing out of wet socks several times a day, never sleeping in wet socks and boots, and, once early symptoms are identified, maximizing efforts to warm, dry, and elevate the feet.
CHILBLAINS OR PERNIO
Chilblains, or pernio, are characterized by mild but uncomfortable inflammatory lesions of the skin caused by long­term intermittent exposure to
 damp, nonfreezing ambient temperatures. Symptoms are precipitated by acute exposure to cold. The most common areas affected are the feet (toes), hands, ears, and lower legs. Chilblains are primarily a disease of women and children, and although rare in the United States, the disease is common in
 the United Kingdom and other countries with a cold or temperate, damp climate. In addition, young females with Raynaud’s phenomenon and other immunologic abnormalities such as lupus erythematosus, as well as those in households with inadequate heating and lack of warm clothing, are at
,7 greatest risk. Some studies suggest that a low body mass index may be associated with increased risk.
Early symptoms progress from tingling to numbness of the affected tissues. The cutaneous manifestations, which appear up to  to  hours after acute exposure, include localized edema, erythema, cyanosis, plaques, nodules, and, in rare cases, ulcerations, vesicles, and bullae. Patients may complain of pruritus and burning paresthesias. Rewarming may result in the formation of tender blue nodules, which may persist for several days.
MDoanwangloeamdeendt i2s0 s2u5p­p7o­1rt i6v:e3.3 T Phe Yafofeucr tIePd issk 1in3 6sh.1o4u2ld.1 b5e9 .r1e2w7armed, gently bandaged, and elevated. Additional recommended therapy includes
Chapter 208: Cold Injuries, Michael T. Paddock nifedipine,  to  milligrams PO three times daily for vasodilatation; pentoxifylline, 400 milligrams PO three times daily to decrease blood viscosity; or
. Terms of Use * Privacy Policy * Notice * Accessibility
,8,9 an oral analog of prostaglandin E , limaprost,  micrograms orally three times daily for vasodilatation. Topical corticosteroids (e.g., .1%

  triamcinolone cream) are beneficial. Smoking cessation should be advised.
PANNICULITIS
Panniculitis is characterized by mild degrees of necrosis of subcutaneous fat tissue that develops during prolonged exposure to temperatures just above freezing. It is observed in children exposed to local or topical cold objects (e.g., “popsicle panniculitis” of the cheeks) and on the thighs and
 buttocks of young women involved in equestrian activities due to tight clothing and cold ambient temperatures. During resolution of the mild inflammation, adipose fibrosis may result in cosmetic defects, such as unevenness of the skin. There is no effective treatment for the injury.
COLD URTICARIA

Cold urticaria is a distinctive example of hypersensitivity to cold air or water, which in rare cases may lead to anaphylaxis. Most cases are idiopathic,
 but they can also be associated with increased affinity of immunoglobulin E to mast cells and viral infections. The diagnosis can be confirmed with the cold water test during outpatient follow­up. Young adults and children and those with atopy or other forms of inducible urticaria are most
,13 commonly affected.
Cold urticaria is treated similarly to urticarial lesions from other causes. Antihistamines (H ) are recommended for acute cases, although up to four
 times the standard dose may be required (avoid elevated doses in patients with chronic kidney disease). Suggested medications include desloratadine

(start at  milligrams daily, up to  milligrams daily for  days) or loratadine (start at  milligrams daily, up to  milligrams PO daily for  days).
,16
Consensus recommends escalating the dose of nonsedating antihistamines before initiating other medications, typically at outpatient follow­up.
,18 
Other potential therapies include leukotriene receptor antagonists (zafirlukast, montelukast), mast cell stabilizers, and immunomodulators.
Epinephrine autoinjectors are available for patients with a history of cold­induced anaphylaxis.
FROSTBITE
EPIDEMIOLOGY
Risk factors for frostbite include activities or occupations with increased cold exposure time such as military personnel, winter sports enthusiasts, outdoor workers, the elderly, the homeless, people who abuse drugs or alcohol, and those with psychiatric disorders. Individual attributes, such as
19­24 physiology, behavior, and general health, affect an individual’s likelihood of developing cold­related injuries (Table 208­1). Wind markedly increases the cooling rate by increasing convective heat loss and reducing the insulation value of clothing, thus increasing the risk of frostbite. Skin temperature is <0°C (<32°F) when frostbite occurs. Frostbite can develop within  to  seconds when metal surfaces that are at or below –15°C (5°F) are
 touched.
TABLE 208­1
Factors Increasing the Likelihood of Frostbite
Environmental
Lower temperatures (especially <20°C, –4°F)
Higher wind speed (>4.5 m/s,  mph)
Increased wetness
Contact with cold objects (metal) or liquids (petroleum, oil)
Duration of cold exposure
Hypoxia
Altitude (>5182 m, ,000 ft)
Physical/anthropometric characteristics
Male gender
Increasing age in men
Activity that increases cold or wind exposure
Prolonged stationary posture
Poor cold acclimatization
Alcohol use
Fatigue
Dehydration
Smoking
Use of moisturizing ointments on exposed skin
Inappropriate or wet clothing
Constrictive clothing (e.g., tight boots)
Health­related/physiologic
Raynaud’s phenomenon
Vibration­induced white finger
Cold­induced vasodilation reactivity
Other peripheral vascular diseases
Diabetes
Peripheral neuropathies
Certain medications (e.g., vasoconstrictive drugs)
Previous cold injury
Psychiatric disorders or altered mental status
,25
The areas most commonly affected by frostbite are the head (31% to .1% of cases), hands (20% to .9%), and feet (15% to .9%). Studies vary regarding which of these sites is most commonly affected, with military personnel reporting higher incidences of foot and hand involvement than
  civilians. Although most cases of frostbite are mild (frostnip), 12% of cases are more severe (Table 208­2).
TABLE 208­2
Body Parts Affected by Frostbite (Lifetime Cumulative Incidence)
Number of Frostbite Episodes
Degree of Frostbite
All Head Hands Feet
All frostbite cases 2555 (44%) 1668 (31%) 1154 (20%) 810 (15%)
First degree 2333 (41%) 1462 (28%) 1064 (19%) 738 (14%)
Higher than first degree, deep 671 (12%) 459 (9%) 213 (4%) 174 (3%)
Notes: Study population, N = 5839. Some persons had multiple locations and degrees of frostbite.
PATHOPHYSIOLOGY
Frostbite is tissue injury secondary to freezing. It is generally agreed that freezing alone is usually not sufficient to cause tissue death, and the
 consequences of thawing contribute markedly to the degree of injury. The depth of tissue freezing depends on the temperature, the duration of exposure, and the velocity of freezing.
Endothelial damage, beginning at the point of thaw, is the likely critical event in frostbite. Immediately after freezing and thawing, an arachidonic acid cascade forms and promotes vasoconstriction, platelet aggregation, leukocyte sludging, and erythrostasis, which results in venule and arterial
 thrombosis and subsequent ischemia, necrosis, and dry gangrene. The necrosis of tissue following frostbite either is due to cellular injury or is
 secondary to a vascular lesion.
Frostbite injury can be divided into three zones. The zone of coagulation is the most severe and is usually distal, and the damage is irreversible. The zone of hyperemia is the most superficial, is typically proximal, has the least cellular damage, and generally recovers without treatment in <10 days.
The zone of stasis is the middle ground and is characterized by severe, but possibly reversible, cell damage. It is this middle zone for which treatment may have benefit if the circulation in the frozen area can be restored.
Tissue susceptibility to frostbite varies. The least to most sensitive tissues are, in order, cartilage, ligament, blood vessel, cutis, epidermis, bone, muscle, nerve, and bone marrow.
CLINICAL FEATURES AND DIAGNOSIS
Frostbite injuries are frequently classified by the depth of injury and amount of tissue damage based on appearance after rewarming (Table 208­3).
Visual determination of tissue viability is difficult during the first few weeks after the injury, and viable tissue can often be identified only after gangrenous tissue has demarcated and sloughed.
TABLE 208­3
Classification of Frostbite Injuries
First degree Numbness, central pallor with surrounding erythema and edema, desquamation, dysesthesia
Second degree Blisters of the skin with surrounding edema and erythema
Third degree Tissue loss involving the entire thickness of the skin; hemorrhagic blisters
Fourth degree Tissue loss involving the entire thickness of the part, including deep structures, resulting in the loss of the part
First­degree injury (frostnip) is characterized by partial skin freezing, erythema, mild edema, lack of blisters, and occasional skin desquamation several days later. The patient may complain of stinging and burning, followed by throbbing. Prognosis is excellent. Second­degree injury is characterized by full­thickness skin freezing, formation of substantial edema over  to  hours, erythema, and formation of clear blisters filled with fluid rich in thromboxane and prostaglandins (Figure 208­1). The blisters form within  to  hours, extend to the end of the digit, and usually desquamate and form hard black eschars over several days. The patient complains of numbness, followed later by aching and throbbing. Prognosis is good. Thirddegree injury is characterized by damage that extends into the subdermal plexus. Hemorrhagic blisters form and are associated with skin necrosis and a blue­gray discoloration of the skin (Figure 208­2). The patient may complain that the involved extremity feels like a “block of wood,” which is followed later by burning, throbbing, and shooting pains. Prognosis is often poor. Fourth­degree injury is characterized by extension into subcutaneous tissues, muscle, bone, and tendon. There is little edema. The skin is mottled, with nonblanching cyanosis, and eventually forms a deep, dry, black, mummified eschar. Vesicles often present late, if at all, and may be small, bloody blebs that do not extend to the digit tips. The patient may complain of a deep, aching joint pain. Prognosis is extremely poor (Figures 208­3 and 208­4).
FIGURE 208­1. Second­degree frostbite in the hand with blisters. [Photo contributed by Scott Sherman, MD.]
FIGURE 208­2. Second­ and third­degree frostbite in the hand with blisters. [Photo contributed by Edward Lew, MD.]
FIGURE 208­3. Third­ and fourth­degree frostbite of bilateral feet. [Photo contributed by Edward Lew, MD.]
FIGURE 208­4. A. Fourth­degree frostbite  month after injury. Note the clear demarcation line in the fingers. B. The same hands  months after surgical treatment.
DIAGNOSIS
The diagnosis of frostbite is clinical. Frostbite may occur anywhere on the skin, but is generally limited to the distal part of the extremities, face, nose, and ears. The injured area looks pale and waxy and feels hard and cold. Patients frequently complain of stinging and numbness.
Because it is initially difficult to estimate the depth of the cold injury, early injuries are best classified simply as either superficial or deep. Prognostic considerations of ultimate tissue loss should take into account duration of exposure, environmental conditions (temperature, wind, and precipitation), type of clothing worn, level of physical activity, possible contact with metal or moisture, and associated use of recreational drugs, alcohol, or tobacco in addition to physical findings. Patients with frostbite may have concomitant cold­related problems such as hypothermia and dehydration, and conversely, patients with hypothermia may also have frostbite.
Although some chemical liquids and burn injuries may cause blister formation, a history of cold exposure differentiates chemically induced blisters from cold­induced injuries.
No specific laboratory tests are indicated when treating patients with frostbite, and specific laboratory evaluation should be guided by the clinical situation including associated trauma or medical illness, as well as guiding the safety of therapeutic agents. Imaging prior to rewarming is not helpful, either for diagnostic or prognostic purposes. The use of technetium­99 scintigraphy (bone scan) has prognostic value and may guide subsequent
,29 therapy. Angiogram of the affected extremity may have prognostic and therapeutic value after initial rewarming has been performed. A retrospective case review of 114 patients in a single burn center undergoing protocolized diagnostic angiogram assessment reported both positive and
 negative predictive value in determining need for amputation of the affected extremities. Patients who demonstrated flow abnormalities within 
 hours of rewarming underwent immediate intra­arterial thrombolysis. Patients should not receive angiograms at institutions unable to provide therapeutic intervention.
TREATMENT
Prehospital Care
Initial field management of frostbite includes prevention of further cold injury, hypothermia, and dehydration. Remove wet and constrictive clothing, cover with dry clothing, and protect against wind. Do not heat the frozen area, because dry heat may cause further injury. Do not attempt rewarming
,32 until the risk of refreezing is eliminated. Refreezing will cause even more severe damage and is an important concern when initiating prehospital care. Provide analgesia, as the rewarming process is very painful. Immobilize and elevate frozen extremities, and handle gently. The patient should not ambulate on edematous or blistered feet. Home remedies such as rubbing the affected area or rubbing snow on frostbitten tissue increase tissue
,32 damage and should not be performed. Topical agents such as creams or lotions should not be applied in the field.
ED Management
,32
Rapid rewarming is the first definitive step of frostbite therapy and should be initiated as soon as the risk of refreezing injury can be avoided. Place the injured extremity in gently circulating water heated to a temperature of 37°C to 39°C (98.6°F to 102.2°F), for approximately  to  minutes, until the
,32 distal extremity is pliable and erythematous. Frostbitten faces can be thawed using moistened compresses soaked in warm water. Some patients may tolerate immersion of the ears in a bowl or pool of warmed water. Anticipate severe pain during rewarming and treat with parenteral opiates prior to initiating rewarming therapy.
Local care is directed toward tissue preservation and infection prevention. Management of clear blisters and the use of prophylactic antibiotics are somewhat controversial. The blister fluid is rich in destructive thromboxane and prostaglandins. Although removal theoretically limits damage from these chemicals and enables access to the underlying tissue for topical therapy, not all experts agree that removal is indicated. Hemorrhagic blisters should not be debrided, because this often results in tissue desiccation and worse outcome. However, there is some controversy as to whether aspiration is helpful. Both blister types should be treated with topical aloe vera cream every  hours, which helps to combat the arachidonic acid
,32 cascade and may provide some symptom relief. Affected digits should be separated with soft padding and wrapped with sterile, dry gauze. Other affected areas should be dressed in bulky, loose­fitting dry gauze dressings to allow room for the expected subsequent edema. Elevation of the involved extremities may help decrease edema and pain. Ibuprofen, 600 milligrams orally every  hours as needed, is recommended due to its
 prostaglandin effects.
Tetanus immunization status should be assessed and appropriate vaccination administered if needed, as frostbite is a tetanus­prone wound (see
Chapter 157, “Tetanus”).
Management of Pulse Deficits After Rewarming
Management of pulse deficits after rewarming requires coordination of multiple specialists and is best facilitated by institutional protocols to guide
 and expedite management, as therapy is time sensitive. Pulse deficits should be confirmed by Doppler. If the institution of patient presentation is unable to provide advanced therapies or imaging to direct management, consider transfer to a center with expertise managing severe frostbite, if advanced treatment options can be implemented within  hours of rewarming. If contemplating intervention, the vasculature of the involved extremity should be imaged, most commonly with technetium­99 scintigraphy or angiography, depending on institutional protocol and anticipated intervention.
Because microvascular thrombosis plays a role in tissue injury, systemic thrombolytic therapy has been advocated for use in cases at risk for proximal
,36 ,37­39 or multiple­digit amputations and, when given within  hours after rapid rewarming, appears to reduce digit amputations. The evidence in support of IV or intra­arterial tissue plasminogen activator is limited to retrospective studies, and bleeding risks must be weighed against potential
 ,31,40­44 benefit. However, thrombolytic therapy is recommended by multiple experts from several specialties. Both IV administration (most commonly tissue plasminogen activator, .15 milligram/kg bolus, followed by .15 milligram/kg over  hours up to a total dose of 100 mg) and intraarterial administration (with papaverine to reduce vasospasm), using an agent and dose determined by institutional protocol, have been used with success; neither route has been shown to be superior. Heparin should be continued for  to  hours after thrombolysis is complete. Alternatively, in
 countries where available (not available in the United States), the prostacyclin iloprost has been shown to be as effective as thrombolytic therapy.
Start iloprost at .5 nanogram/kg/min IV to a maximum dose of  nanograms/kg/min for  days, and titrate the dose down if the patient experiences facial flushing with intolerable headache. Table 208­4 presents the core treatment of frostbite.
TABLE 208­4
Treatment of Frostbite
Core Treatment
Immersion in or application of water at 37°C to 39°C (98.6°F to 102.2°F) until affected area is pliable and erythematous; do not begin rewarming until risk of refreezing is eliminated
Parenteral narcotics for pain management
Topical aloe vera cream every  h
No blister or soft tissue debridement acutely
Meticulous local care
Tetanus immunization
Ibuprofen, 600 milligrams, or  milligrams/kg/dose every  hours as needed
Managing Post­rewarming Pulse Deficits
Prevent refreezing
Assess local frostbite management expertise; consider transfer to facility with frostbite expertise if advanced treatment can be implemented within  hours or rewarming
Image affected extremity vasculature using institutional protocol
Consider IV or intra­arterial thrombolytic therapy by institutional protocol
Consider IV iloprost infusion where available
Therapies of Uncertain Benefit
The role of prophylactic antibiotics is unclear. The edema that is present on the first several days after injury appears to predispose to infection.

However, the historical recommendation for penicillin G, 500,000 units IV every  hours for  to  hours, is not evidenced based. Topical antibiotics
,33 such as bacitracin or silversulfadiazine cream are not currently recommended and may complicate the concurrent use of aloe vera cream, which may be therapeutic. In contrast to prophylactic antibiotics, suspected infections should be investigated with wound culture and treated empirically.
Heparin has not been shown to have benefits outside of being an adjunct to thrombolytic therapy. Hyperbaric oxygen therapy appears to be of limited
,47 value, although it can be added after thrombolytic or prostacyclin therapy has been initiated.
Early surgical intervention is not indicated in the management of frostbite. Premature surgery has been an important contributor to unnecessary tissue loss and poor results in the past. This is due primarily to the inability to assess the depth of frostbite at early stages and the fact that the blackened, mummified carapace protects the underlying regenerating tissue. Limited early escharotomy may be indicated if the eschar is preventing adequate range of motion or circulation. Fasciotomy is rarely, if ever, indicated.
Austere Environment Treatment Considerations
Management of patients in austere environments, such as those in expedition base camps, can be particularly difficult based on environmental conditions, limited access to resources, and reduced ability to transfer patients to more definitive levels of care. Consideration should be given for
 providing core treatment measures in a field clinic or base camp including rewarming therapy, wound management, and oral prostaglandins. If treatment is to occur at altitude where expected oxygen saturations are below 90% (>4000 m or ,000 ft), the use of supplemental oxygen or a portable
 hyperbaric device should be considered. Recent case series proposed the use of systemic thrombolytic therapy and/or prostacyclin therapy in these
 environments if transfer is not possible in time to provide potentially definitive management. These cases include severe frostbite of the digits, when amputation risk is high (significant peripheral cyanosis that extends proximally above metacarpophalangeal joints after rewarming), if unable to
 transfer to higher levels of care within  hours. The field use of IV prostacyclin therapy (iloprost) has also been proposed and may be less risky for
 lower grades of frostbite and if the patient cannot be transferred to a higher level of care within  hours.
Sequelae

Up to 65% of persons with frostbite injuries experience sequelae from their injuries. Sequelae may be seen in patients with mild injuries but are generally more intense with more severe frostbite. The most typical sequelae are hypersensitivity to cold, pain, ongoing numbness, and increased risk for developing future frostbite injury. The clinical and functional limitations associated with late sequelae are dependent on the type and severity of the frostbite injury and the related anatomic deformities and amputations.
Disposition and Follow­Up
Because it is difficult to determine the extent of frostbite on initial examination, it is best to be conservative when contemplating admission. Consider age and social and medical issues when planning disposition. Undomiciled patients should not be discharged back into subfreezing temperatures with an active injury, and a special consideration for admission or discharge to a local shelter is warranted. If the frostbite is extensive and the hospital and staff are not equipped to treat injury of that degree of severity, consider transfer to a tertiary hospital after initial rewarming and treatment.
Patients with only superficial local frostbite may be discharged home if social circumstances allow. Patients with deeper frostbite injuries should be hospitalized. At discharge from the ED, patients must be provided with sufficient guidelines for self­care as well as clear instructions for short­term and long­term follow­up, preferably with local burn center or plastic surgery providers. Patients who are discharged from the ED should be treated with topical aloe vera cream and oral ibuprofen and encouraged not to smoke or drink alcohol to maximize healing potential.


