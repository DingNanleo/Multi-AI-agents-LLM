University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 17: Fluids and Electrolytes
Roberta Petrino; Roberta Marino
INTRODUCTION
Content Update: Sodium Zirconium Cyclosilicate for Hyperkalemia February 2021

Sodium Zirconium Cyclosilicate is a potassium binder that appears effective for emergency treatment of hyperkalemia . See discussion under hyperkalemia treatment, and in Table 17­19. FLUIDS AND SODIUM: PATHOPHYSIOLOGY
Total body water (TBW), which accounts for approximately 60% of total body weight, can be divided into intracellular fluid (ICF) and extracellular fluid
(ECF) compartments. The ECF is composed of intravascular fluid and extravascular, or interstitial, fluid. Three fundamental homeostatic equilibriums govern the behavior of fluids: the osmotic equilibrium, the electric equilibrium, and the acid­base equilibrium.
The key point is that sodium is much more concentrated in the ECF (approximately 140 mEq/L) than in the ICF (approximately  mEq/L), but is equal in both compartments of the ECF because the capillary membrane between intravascular fluid and interstitial fluid is permeable to water and electrolytes.
In contrast, the cell membrane is permeable to water but not to electrolytes, which are moved through ionic pumps against gradient to keep the intracellular sodium concentration constant around  mEq/L and potassium at 150 mEq/L. Table 17­1 lists the electrolyte concentration of body fluids and the most commonly used therapeutic solutions. Table 17­2 defines commonly used terms that describe measures or characteristics of
 electrolytes and/or disorders.
TABLE 17­1
Electrolyte Concentrations of Fluids
Solution Plasma Interstitial Intracellular Normal Lactated Ringer’s Multiple Electrolyte
Saline Solution Injection* Cations
Sodium, mEq/L 142 144  154 130 140
Potassium, mEq/L  .5 150 —  
Magnesium, mEq/L†    — — 
‡  .5 — —  —
Calcium, mEq/L
Total cations, 153 152 200 154 137 148 mEq/L
Anions

Chapter 17: Fluids and Electrolytes, Roberta Petrino; Roberta Marino 
©2025C MhlocrGidrea,w m EHqi/llL. All Rig1h0t4s Reserv1e1d3. Terms of— Use * Privacy P1o54licy * Notice * A10c9cessibility 
Lactate, mEq/L# — — — — 
Acetate, mEq/L — — — — — 
Gluconate, mEq/L — — — — — 
Phosphates, mEq/L   120 — — —
Sulfates, mEq/L    — — —
Bicarbonate, mEq/L    — — —
Proteins, mEq/L    — — —
Organic acids,   — — — — mEq/L
Total anions 153 152 200 154 137 148
Osmolality, 285–295 285–295 285–295 286 254 mOsm
*Multiple electrolyte injection, type , is the generic name for Plasma­Lyte 148®, Normosol®, and Isolyte®
†Multiply by .411 to convert to International System of Units (SI) units in mmol/L.
‡
Multiply by .25 to convert to SI units in mmol/L.
#Multiply by .323 to convert to SI units in mmol/L.
TABLE 17­2
Definition of Terms
Term Definition Comments
Mole .02 × 1023 molecules of a substance Unit measure used in International
System of Units format.
Equivalent Mass (in grams) of a mole of a substance divided Unit of measure used in conventional lab values.
by charge of substance
Osmole Amount of a substance (in moles) that dissociates to form  mole of osmotically active particles
Osmolarity Measure of solute concentration per unit Osmolarity varies with changing temperature, because water changes its volume volume of solvent according to temperature.
Osmolality Measure of solute concentration per unit mass Osmolality is the preferred measure because it remains constant with changes in of solvent temperature.
Tonicity or Measure of the osmotic pressure gradient Tonicity is affected only by solutes that cannot cross a semipermeable membrane. For effective between two solutions, across a example, tonicity is not affected by urea or glucose as they cross semipermeable osmolality semipermeable membrane membranes.
When two solutions are separated by a membrane that is permeable only to water, water crosses into the compartment with the more concentrated
 solution to equalize the ion concentration in each. The force driving this movement is “osmotic pressure.” In human fluids, the substances that
+ – – contribute the most to osmotic pressure in ECF are sodium (Na ) and the anions HCO and Cl , plus glucose. In physiology, this force is called effective
 osmolality or tonicity. The formula to calculate effective osmolality or tonicity is
2×[Na+]+glucose/18(normal range, 275 to 290 mOsm/L)
When  L of free water is added to the ECF, it crosses the cell membrane into the ICF to equalize ECF osmolality. The result is TBW expansion and slight reduction in osmolality (Figure 17­1). When  L of isotonic saline solution .9% is added to the ECF, there is no movement of water into the cells, and
 the final result is ECF expansion only.
FIGURE 17­1
Distribution of total body water into the intracellular fluid (ICF) and extracellular fluid (ECF) compartments. Addition of water expands both compartments. Addition of isotonic saline expands only the ECF, whereas addition of salt without water expands the ECF at the expense of the ICF.
[Reproduced with permission from Eaton DC, Poole JP (eds): Vander’s Renal Physiology, 8th ed. New York: McGraw­Hill, Inc.; 2013. Fig 6­1.]
In contrast, when there is a fluid loss and a consequent increase in osmolality, osmoreceptors in the hypothalamus stimulate thirst and the release of antidiuretic hormone (ADH, known also as vasopressin) from the pituitary gland. With a decrease in circulating blood volume, low­pressure baroreceptors in the great veins and the right atrium augment the effect on the osmoreceptors, with a consequent urine water reabsorption and
1–5 vasoconstriction.
The plasma sodium concentration, or tonicity, leads to changes in cell volume. Hypertonic plasma draws water out of the cell into the vasculature,
 causing cell shrinkage. In the setting of hypotonic plasma, cells swell with water.
DEHYDRATION

Dehydration is a loss in TBW caused by either water loss (hyperosmolality) or salt loss (hypo­osmolality). Water loss may be caused by inadequate fluid intake to replace insensible loss or excessive diuresis, due to hyperglycemia for example. Salt loss can be caused by vomiting, diarrhea, sweating,
 bleeding, or chronic kidney failure.
Symptoms of dehydration include thirst, fatigue, dizziness, and ultimately confusion; signs include sunken eyes, dry mouth and tongue, and tenting of the skin. In elderly patients, dehydration is a cause of delirium, cognitive deterioration, agitation, hallucinations, and delusions. In these patients, rapid
 weight loss, dark (concentrated) urine, and behavioral change suggest a diagnosis of dehydration. A combination of factors may precipitate an episode of dehydration, such as chronic antihypertensive medication or diuretic use combined with exposure to high outdoor temperature, an
 episode of fever, or an acute illness when water intake is insufficient.

Table 17­3 lists the screening suggested by the Dehydration Council to evaluate the risk of dehydration.
TABLE 17­3
Checklist for Evaluation of Dehydration Risk
Diuretics
End of life
High fever
Yellow urine turns dark
Dizziness (orthostasis)
Reduced oral intake
Axilla dry
Tachycardia
Incontinence (fear of, reducing oral intake)
Oral problems
Neurologic impairment
Sunken eyes
HYPONATREMIA
Hyponatremia is defined as a serum [Na + ] <138 mEq/L. However, symptomatic hyponatremia rarely occurs until [Na + ] falls to ≤135 mEq/L. In the setting
,10,11 of normal water intake, high circulating levels of ADH with subsequent water retention are a prerequisite for the development of hyponatremia.
Urine osmolality is always >100 mOsm/L H O with the exception of samples from patients with psychogenic polydipsia, which drives down urine
 osmolality below the typical minimum.
Mild hyponatremia is common, with an incidence of 15% to 30% in hospitalized patients; 1% to .5% of patients have sodium levels below 126
,12 mEq/L. Hyponatremia affects approximately 20% of patients with heart failure, whereas at least 50% of nursing home patients have had one or
,11 more episodes of hyponatremia.
+
The concentration of Na does not give information regarding volume status. Therefore, the first step in the evaluation should include a clinical evaluation of ECF volume status plus comparing measured and calculated plasma osmolalities.
HYPEROSMOLAR HYPONATREMIA (PLASMA OSMOLALITY [P ] >295 mOsm/kg H O)
OSM 
Hyperosmolar hyponatremia occurs when large quantities of osmotically active solutes accumulate in the ECF space. In this setting, there is a net
+ movement of water from the ICF to the ECF, thereby effectively diluting the ECF [Na ]. This happens commonly with severe hyperglycemia. Each
+ 
100 milligram/dL increase in plasma glucose above the normal level of 100 milligrams/dL decreases the serum [Na ] by .6 mEq/L. Other causes of hypertonic hyponatremia are administration of osmotic agents such as mannitol, glycerol, and maltose, causing an osmolar gap and hyponatremia.
The osmolar gap is the difference between measured osmolality and calculated osmolality. Normally the difference is around  mOsm/L; if it is >15
+ mOsm/L, it means that a nondetectable agent with osmotic activity is present, causing an osmolar gap. A consequent osmotic diuresis will cause [Na ] deficit with volume depletion that should be treated with saline solution.
ISO­OSMOLAR HYPONATREMIA (P 275 TO 295 mOsm/kg H O)
OSM 
+
Pseudohyponatremia is a factitiously low value of [Na ] that occurs in the setting of severe hyperproteinemia or hyperlipidemia yielding a
+ measurement error. High concentrations of lipids or protein can displace serum water, which causes laboratory misinterpretation of normal [Na ]; some laboratories use instruments that avoid this laboratory error; check with your laboratory administrator. Patients are asymptomatic; treatment is not needed.
HYPO­OSMOLAR HYPONATREMIA (P <275 mOsm/kg H O)
OSM 
,3
The different causes of hypo­osmolar (hypotonic) hyponatremia according to volume status are listed in Table 17­4. Osmol receptors in the hypothalamus react to low osmolality by secreting ADH, which limits water excretion and increases water reabsorption. In situations such as heart
,14  failure, cirrhosis, and nephrotic syndrome, the effective arterial blood volume is decreased because water is mainly distributed to the interstitial
+ space. Thus, Na and water reabsorption are increased, and water excretion is reduced.
TABLE 17­4
Classification, Differential Diagnosis, and Features of Hyponatremia According to Volume Status
Clinical Conditions Orthostatic Edema U , mEq/L U , mOsm/L
[Na+] OSM
Hypotension
Hypovolemic hyponatremia CHF Absent Yes Compensated: >20 Compensated: <100
Cirrhosis Decompensated: Decompensated:
Nephrotic syndrome <10 >100
Acute and chronic kidney disease
Normovolemic hyponatremia Psychogenic polydipsia Absent No >20 >100
Glucocorticoid deficit
Hypokalemia
Drugs
SIADH
Renal hypovolemic hyponatremia Diuretics Normally present No >20 >100
Mineralocorticoid deficit
Salt­losing nephropathy
Extrarenal hypovolemic Vomiting Normally present No <10 >100 hyponatremia Diarrhea
Abbreviations: CHF = congestive heart failure; SIADH = syndrome of inappropriate antidiuretic hormone excretion; U = urine sodium; U = urine osmolality.
[Na+] OSM
Two important hyponatremic disorders are the syndrome of inappropriate ADH secretion and the less common cerebral salt­wasting
,2,11 syndrome. Both conditions are diagnoses of exclusion after dismissing other causes of hyponatremia. The onset of both syndromes is linked to chronic cerebral disease, but syndrome of inappropriate ADH secretion may also be caused by noncerebral diseases and conditions as described in
Table 17­5. In syndrome of inappropriate ADH secretion, volume status is normal, whereas in cerebral salt­wasting syndrome, there is hypovolemia; therefore, these two disorders are treated differently (see treatment section later in this chapter).
TABLE 17­5
Causes of Syndrome of Inappropriate Antidiuretic Hormone Secretion
Neurologic and psychiatric disorders
Infections: meningitis, encephalitis, brain abscess
Vascular: hemorrhagic or ischemic stroke, subdural hemorrhage, temporal arteritis, cavernous sinus thrombosis
Malignancy: primary or metastatic
Traumatic brain injury
Psychosis, delirium tremens
Other: Guillain­Barré syndrome, neurosurgery
Drugs
Cyclophosphamide
Carbamazepine
Vinca alkaloids (chemotherapy agents)
Thioridazine, other phenothiazines, haloperidol
Selective serotonin reuptake inhibitors and serotonin­norepinephrine reuptake inhibitors
Bromocriptine
Narcotics, opiate derivatives
Amiodarone
Desmopressin overtreatment of diabetes insipidus or enuresis
Lung diseases
Tuberculosis
Lung abscess, empyema
Acute respiratory failure
Non­CNS tumors with ectopic production of vasopressin
Carcinoma of lung (small cell, bronchogenic), duodenum, pancreas, thymus, bladder, prostate, uterus; olfactory neuroblastoma
Lymphoma, leukemia
Sarcoma
Methylenedioxymethamphetamine (MDMA or Ecstasy) intoxication is an uncommon but important cause of hyponatremia that may be profound (see also Chapter 188, “Hallucinogens”).
CLINICAL FEATURES
The most important symptoms of hyponatremia are due to its effects on the brain; symptoms can be divided into moderately severe and severe,
,4 + according to a European clinical practice guideline. Moderately severe symptoms often start when a plasma [Na ] is <130 mEq/L and consist of
+ headache, nausea, disorientation, confusion, agitation, ataxia, and areflexia. When [Na ] reaches levels <120 mEq/L, severe symptoms may develop including intractable vomiting, seizures, coma, and ultimately respiratory arrest due to brainstem herniation. Brain injury may become irreversible.
The symptoms of hyponatremia can be due to many other conditions, and clinicians are cautioned to consider other etiologies before making
 treatment decisions. The presence of hyponatremia­related symptoms is directly related to the rapidity of onset. After a certain period, brain cells
,3 begin to adapt to hyponatremia. Initially the hypo­osmolality drives water into the brain cells, yielding swelling. Due to the rigid skull, intracranial
+ + – hypertension occurs and the described symptoms begin. After  hours, the brain cells start to adapt by extruding Na , K , Cl , and organic osmolytes such as glycine and taurine from the cells, reducing cell osmolality and preventing further water uptake. In several clinical or physiologic conditions, this adaptation mechanism is impaired, as in the syndrome of inappropriate ADH secretion, in children, in menstruating women, and in hypoxia. In such cases, symptoms are more severe and persistent.
DIAGNOSIS
The diagnosis of hyponatremia and its subtypes is based on the clinical findings of volume status in association with specific laboratory values
+ including serum [Na ], serum osmolality, volume status, urinary sodium (U ), and urine osmolality (U ). Acute and chronic hyponatremia are
Na+ OSM defined by an onset time of less than (acute) or greater than (chronic)  to  hours. Experts recommend that when duration is unknown, the hyponatremia should be assumed to be chronic and treated as chronic with a longer correction time. If U is not readily available from the
OSM laboratory, it can be estimated using urinary specific gravity (π). Consider the numerals in the hundredths and thousandths decimal places of the π as
 whole numbers and multiply them by  to obtain U . As an example, for a π of .005, U =  ×  = 175 mOsm/L. Table 17­4 lists the values of
OSM OSM
U and U in different classifications of hyponatremia according to volume status and the differential diagnosis for each classification. As a rule,
Na+ OSM
 only in patients with edematous syndromes and in patients with vomiting and diarrhea will U be found to be <10 mEq/L. The diagnostic criteria for
Na+ syndrome of inappropriate ADH secretion are listed in Table 17­6. TABLE 17­6
Syndrome of Inappropriate Secretion of Antidiuretic Hormone Diagnostic Criteria
Diagnostic Criteria
Hypotonic hyponatremia with (P <275 mOsm/kg H O)
OSM 
Inappropriately elevated urinary osmolality (usually >200 mOsm/kg)
Elevated urinary [Na+] (typically >20 mEq/L)
Clinical euvolemia
Normal adrenal, renal, cardiac, hepatic, and thyroid functions
Abbreviation: P = plasma osmolality.
OSM
Use care when assessing patients with potential exercise­associated hyponatremia. Since the worldwide effort to encourage consuming fluids during endurance exercise beginning in the early 1980s, overhydration with hypotonic fluids is now being seen. If a postexercise athlete presents with bloating, nausea, vomiting, and edema (check wrists and fingers), consider hyponatremia. In contrast, dehydration presents with excessive thirst, sunken eyes, poor skin turgor, and postural hypotension.
TREATMENT
+
Treatment of hyponatremia is guided by four variables: severity of symptoms, rate of onset, volume status, and the current serum [Na ]. Nevertheless,
+ the most important guides for therapy are symptoms (defined also as hyponatremic encephalopathy) rather than the serum [Na ]. When the patient presents with severe neurologic symptoms (vomiting, seizures, reduced consciousness, cardiorespiratory arrest), the initial
,17 ,18 treatment includes infusion of 3% hypertonic saline as recommended by European guidelines and U.S. experts (Table 17­7).
TABLE 17­7
Treatment of Hyponatremia Symptomatic With Seizures or Coma
Step  Assess for indication for 3% hypertonic saline: severe symptoms of hyponatremia such as seizures or coma with suspected impending brainstem herniation in setting of acute* or chronic† hyponatremia.
Step  ‡
Infuse 100–150 mL of 3% hypertonic saline IV over 15–20 min.
Step  Measure serum sodium level after each 3% hypertonic saline infusion.
Step  Stop infusion when symptoms improve or a target of a  mEq/L (range, 4–6 mEq/L) increase in serum sodium concentration is achieved.
Step  May repeat 150 mL of 3% hypertonic saline up to  total doses, or a total of 450 mL IV of 3% hypertonic saline.
Step  Keep the IV line open with minimal volume of .9% normal saline until cause­specific treatment is started. Limit increase in sodium level to no more than 8–12 mEq/L during the first  h or  mEq/L over  h.
*Both European guidelines and U.S. expert panel recommend 3% hypertonic saline infusion for acute life­threatening hyponatremia, which is most commonly due to self­induced water intoxication during endurance exercise, psychiatric illness, in association with methylenedioxymethamphetamine intoxication, or intracranial pathology or increased intracranial pressure.
†European guidelines state that regardless of onset of acute or chronic hyponatremia, presence of seizures or coma is an indication for brief infusion of hypertonic saline to improve symptoms.
‡
European guidelines recommend a prompt 150­mL 3% hypertonic saline infusion over  minutes, then checking the serum sodium concentration after  minutes while repeating an infusion of 150 mL 3% hypertonic saline for the next  minutes, repeating this sequence up to twice more, and stopping with clinical improvement or when target sodium level is reached.
,17,19
Raising serum sodium by  mEq/L is typically all that is required to see an improvement in severe neurologic symptoms. When symptoms are
+ mild or moderate (nausea, confusion, headache) or in chronic hyponatremia, the [Na ] correction should be slower than for acute hyponatremia. Rapid correction increases risk for the most dangerous complication of treatment, the osmotic demyelination syndrome. For chronic
+ hyponatremia [Na ], the correction rate should not exceed  mEq/24 h in high­risk patients and  mEq/24 h in low­risk patients (see

“Osmotic Demyelination Syndrome” section later in this chapter for risks). Hypertonic (3%) saline can be given at a low infusion rate, .5 to 
+ + mL/kg/h, with frequent [Na ] checks. Isotonic (0.9%) saline is frequently used (sometimes before the [Na ] is known), especially for the treatment of mild hyponatremia; however, the additional fluid load must be accounted for in treatment calculations. Loop diuretics (primarily furosemide, starting
+ with a small dose of  milligrams IV) may be used in addition to treatment with saline infusions. Urine volume and [Na ] should be strictly measured.
,7
Specific recommendations for hyponatremia treatment are summarized in Table 17­8. There is no definitive consensus regarding the role of vaptans for patients with hyponatremia, their safety, or their tolerability. The major concerns remain the risk of overcorrection, the risk of precipitating
 osmotic demyelination syndrome, and the high cost.
TABLE 17­8
Cause­Specific Treatment for Hyponatremia
Clinical Therapy Cautions/Comments
Condition
Chronic heart Loop diuretics, water restriction. Consider vasopressin When vasopressin antagonists* are used, serum [Na+] should be failure and antagonists* if the above therapies fail for patients with frequently measured to avoid hypernatremia. FDA recommends against cirrhosis chronic heart failure. vasopressin antagonists in patients with liver disease.
Nephrotic Water restriction.
syndrome
Acute or chronic Water restriction. Frequent assessment of creatinine.
kidney disease
Psychogenic Water restriction. Treat the underlying psychiatric disease.
polydipsia
Hypothyroidism Levothyroxine. Several days of therapy are typically required to correct hyponatremia.
Glucocorticoid Hydrocortisone. If neurologic symptoms, consider When vasopressin antagonists* are used, [Na+] should be frequently deficiency vasopressin antagonists* if resistant to hydrocortisone. measured.
SIADH Water restriction. Enhanced Na+ and protein intake + Isotonic (0.9%) NaCl may worsen hyponatremia; when vasopressin furosemide. Vasopressin antagonists* can be used for antagonists* are used, [Na+] should be frequently measured.
[Na+] <125 mEq/L. Demeclocycline. Lithium.
Diarrhea and Isotonic (0.9%) NaCl. Add KCl if hypokalemia is present. Treat the cause, monitor hemodynamic status.
vomiting
Diuretics (most Stop diuretic. KCl may be sufficient in patients with Slow correction is recommended. Do not overcorrect K+ deficit.
commonly coexistent potassium depletion and normal dietary thiazides) sodium intake. NaCl can be given orally.
Mineralocorticoid Replace volume deficit. Fludrocortisone therapy is Mechanism: volume depletion →↑ ADH → decreases water excretion, ↑ deficiency indicated once diagnosis is confirmed. Na loss.
Salt­losing Isotonic (0.9%) NaCl.
nephropathies
Cerebral salt Isotonic (0.9%) NaCl. Fludrocortisone may be considered NaCl orally at home.
wasting after the diagnosis is confirmed.
Abbreviations: ADH = antidiuretic hormone; FDA = Food and Drug Administration; KCl = potassium chloride; NaCl = sodium chloride; SIADH = syndrome of inappropriate antidiuretic hormone secretion.
*Vasopressin antagonists or vaptans are rarely started in the ED; they are not indicated unless [Na+] <125 mEq/L; starting doses are tolvaptan,  milligrams PO daily; and conivaptan,  milligrams loading dose IV over  minutes, then continuous infusion of  milligrams over  hours for  to  days.
COMPLICATIONS OF TREATMENT
Osmotic Demyelination Syndrome
Osmotic demyelination syndrome is caused by rapid correction of hyponatremia (>12 mEq/L/24 h) as water moves from cells to ECF yielding
+ intracellular dehydration (Figure 17­2). Risk factors for osmotic demyelination syndrome include [Na ] <120 mEq/L, chronic heart failure, alcoholism, cirrhosis, hypokalemia, malnutrition, and treatment with vasopressin antagonists such as tolvaptan. Main symptoms are dysarthria, dysphagia,
+ lethargy, paraparesis or quadriparesis, seizures, and coma. The treatment of [Na ] overcorrection is rarely done in the ED, but consists of giving 5%
,10 dextrose in water at  mL/kg/h, loop diuretics, and desmopressin.
FIGURE 17­2
Adaptation of brain volume to hyponatremia and effect of correction.
HYPERNATREMIA
+
Hypernatremia is defined as serum or plasma [Na ] >145 mEq/L and hyperosmolality (serum osmolality >295 mOsm/L).
+ +
Hypernatremia results from a deficit in TBW and/or a net gain of Na (less common). When [Na ] and osmolality increase, normal subjects become
+ thirsty and drink free water, and the Na level returns toward normal. Any clinical situation that impairs the patient’s sense of thirst, limits the availability of water, limits the kidney’s ability to concentrate urine, or results in increased salt intake predisposes the patient to hypernatremia. Elderly patients, decompensated diabetics, infants, and hospitalized patients are at particular risk of developing hypernatremia. In addition, hypernatremia
,22 may be the result of loss of free water in diarrheal stools or in the urine.
As in hyponatremia, symptoms will be more severe and evident when the onset is rapid; after the first  hours, there is an adaptation of brain cells with an increase in electrolytes and organic osmolytes and thus increased intracellular water partly correcting the initial cell shrinking (Figure 17­3).
FIGURE 17­3
Adaptation of brain volume to hypernatremia and effect of correction.
If severe hypernatremia develops in the course of minutes to hours, such as from a massive salt overdose in a suicide attempt, a suddenly shrinking brain may prompt intracranial hemorrhage.
+
Based on volume status, hypernatremia may be classified as hypovolemic hypernatremia (decreased TBW and total body Na with a relatively greater
+ decrease in TBW), hypervolemic hypernatremia (increased total body Na with normal or increased TBW), or normovolemic hypernatremia (near
,2 normal total body sodium and decreased TBW) (Table 17­9).
TABLE 17­9
Hypernatremia Classification and Features According to Volume Status
Volume Status Clinical Conditions Diagnosis U , mOsm/kg U ,
OSM [Na+]
H O mEq/L

Hypervolemic hypernatremia Cushing’s syndrome Cortisol test >100 >20
Primary History of hypertension and hypokalemia hyperaldosteronism Psychiatric disorder
Salt water intake Hypertonic saline, enteral feeding, bicarbonate
Iatrogenic infusion
Hemodialysis Clinical history
Normovolemic hypernatremia Central DI History of CNS lesion, urinary concentration after Central DI <300 >20
Partial DI desmopressin Partial DI >300 but
Nephrogenic DI History of nephrotoxic drugs, no response to <800
Hypodipsia desmopressin <200
Medications History of poor oral intake >100
Amphotericin, aminoglycosides, lithium, phenytoin <200
Renal hypovolemic Osmotic diuretics Hyperglycemia. High sodium level after correction >100 >20 hypernatremia Loop diuretics Clinical history
Postobstructive Clinical history diuresis
Extrarenal hypovolemic Vomiting Clinical history >800 <10 hypernatremia Diarrhea
GI fistulas
Sweating
Burns
Abbreviations: DI = diabetes insipidus; U = urine sodium; U = urine osmolality.
[Na+] OSM
CLINICAL FEATURES
History depends on hypernatremia type and may reveal nausea and vomiting, lethargy, weakness, increased thirst, low water intake, salt intake, polyuria (>3000 mL of urine/24 h), diabetes, hypercalcemia, hypokalemia, medications such as lactulose, loop diuretics, lithium, demeclocycline (may cause nephrogenic diabetes insipidus), or NSAIDs (may cause interstitial nephritis). Physical exam may reveal hypotension, tachycardia, orthostatic blood pressures, sunken eyes, dry mucous membranes (symptoms of hypovolemia), altered mental status (may be present in any of the hypernatremia classifications), poor skin turgor, or edema in hypervolemic hypernatremia. Without intervention, coma, seizures, and shock may occur. Signs of
Cushing’s syndrome may be present, including moon facies, fatty deposits between the shoulders and upper back, and thinning of the skin. Severe
+  hypernatremia (i.e., a [Na ] >150 to 160 mEq/L) yields a mortality of 75%.
DIAGNOSIS
The diagnosis of hypernatremia and its classification are based on the clinical evaluation including volume status and specific laboratory tests, such as serum electrolytes and osmolality, urine osmolality, urea/creatinine ratio, and free water deficit. A BUN/creatinine ratio >40 is indicative of hyperosmolar dehydration. Urine osmolality can be used to suggest the type of hypernatremia (Table 17­10). A patient’s free water deficit can be calculated with the aid of a phone application or Internet calculator.
TABLE 17­10
Urine Osmolality Findings in Selected Hypernatremic States
Urine Osmolality (U ) Potential Hypernatremic State
OSM
U <300 mOsm/kg H O Central or nephrogenic diabetes insipidus
OSM 
U >300, <800 mOsm/kg H O Partial diabetes insipidus or osmotic diuresis
OSM 
U >800 mOsm/kg H O Hypertonic dehydration
OSM 
TREATMENT
First, shock, hypoperfusion, or volume deficits should be treated with isotonic (0.9%) saline. Second, treat any existing underlying cause, such as diabetes insipidus (see “Diabetes Insipidus” section later in this chapter), vomiting, diarrhea, or fever. Third, correct the patient’s free water deficit at a
,24 rate reflecting the acuity or duration time of the hypernatremia onset (Table 17­11). In cases of a lethal sodium chloride ingestion/load (0.75 to
,25
### .0 grams/kg) less than  hours prior to presentation, the free water deficit may be replaced rapidly with no reported adverse events. When the adaptation of brain cells is incomplete (onset over <48 hours), the correction rate of acute hypernatremia can be performed at a rate of  mEq/L/h. In an alert patient capable of safely drinking water, the route of administration should be two­thirds free water orally and one­third IV. If hypernatremia is chronic (onset over >48 hours), the rate of correction should be slower to avoid the risk of cerebral edema, at no more than .5 mEq/L/h or  to 
 mEq/24 h.
TABLE 17­11
Treatment of Hypernatremia
Treatment Indication and Comments
Isotonic (0.9%) saline Use for correction of volume deficits.
Etiology­specific therapy Treat fever with antipyretics, vomiting with antiemetics, and diabetes insipidus with desmopressin (see
“Diabetes Insipidus” section).
D W or oral free water to replace free In cases of chronic hypernatremia, it is suggested that correcting (lowering) the sodium level should occur at a
 rate of no more than .5 mEq/L/h or 10–12 mEq/24 h.
water deficit over 2–3 d
.45% normal saline at 100 mL/h Correct volume deficits first. A commonly used infusion for mild to moderate hypernatremia, but this therapy adds sodium to total body.
D W to replace free water deficit over 1– Reserved only for those cases where acuity is known to be <6 h and the salt load is known to be lethal (0.75–

### .0 grams/kg of body weight).
 h
Hemodialysis An alternative or as a supplement to D W to replace free water deficit in life­threatening acute cases of salt
 ingestion.
Abbreviation: D W = 5% dextrose in water.

DIABETES INSIPIDUS
,27
Diabetes insipidus is a disease where the ability of the kidney to reabsorb free water is compromised. The disorder is characterized by polyuria, polydipsia, and an increased volume of hypo­osmolar urine. Hypernatremia is present only when the thirst center is impaired or water intake is reduced. Diabetes insipidus can be central (also called neurogenic), due to inadequate ADH secretion, or renal (also called nephrogenic), when ADH secretion is normal or increased but the v2R receptors of the kidney’s collecting duct cells do not respond appropriately to ADH. Diabetes insipidus may be congenital or acquired. In Table 17­12, the main causes of diabetes insipidus are listed. Congenital forms of diabetes insipidus present during infancy. Eventually, recurrent cellular dehydration causes cerebral calcifications that manifest as delayed intellectual advancement.
TABLE 17­12
Classification of Diabetes Insipidus
Class Acquisition Pathophysiology
Central or neurogenic diabetes insipidus Congenital Structural malformations affecting the hypothalamus or pituitary
Autosomal dominant (or rarely recessive) mutations in the gene encoding AVP­NPII precursor protein
Acquired Primary tumors (craniopharyngioma) or metastases
Infection (e.g., meningitis, encephalitis)
Histiocytosis and granulomatous diseases
Trauma
Surgery
Idiopathic
Nephrogenic diabetes insipidus Congenital X­linked: inactivating mutations in AVPR2 gene
Autosomal: recessive or dominant mutations in AQP­2 gene
Acquired Primary renal disease
Obstructive uropathy
Metabolic causes (e.g., hypokalemia, hypercalcemia)
Sickle cell disease
Drugs (e.g., lithium, demeclocycline)
Primary polydipsia or dipsogenic diabetes Acquired Psychogenic illness characterized by excessive fluid intake. Treatment is aimed at the insipidus psychiatric disease.
Central diabetes insipidus is acquired in most cases, associated with various disorders that cause destruction of ADH­secreting neurons. When a diagnosis is not possible, despite imaging and other diagnostic tests, diabetes insipidus will be defined as idiopathic diabetes insipidus.
The most common clinical symptoms and signs are excessive thirst, polydipsia, and polyuria plus several nonspecific symptoms including weakness, lethargy, myalgias, and irritability. In infancy, congenital forms of diabetes insipidus present with fatigue and weakness often manifested by less activity or tiring with feeding, vomiting, polyuria, and sometimes fever. Diagnosis can be suspected in the ED by clinical presentation, but the diagnosis requires a prolonged test, requiring  to  hours. Urine osmolality is assessed after water deprivation; many cases require another assessment after a dose of desmopressin, the “water deprivation test.” A spot check in the ED without water deprivation will typically reveal a U of <300 mOsm/L. In
OSM central diabetes insipidus, a cerebral MRI is indicated (on a nonurgent outpatient basis) to evaluate the hypothalamic–pituitary area.
Central diabetes insipidus is treated with the synthetic hormone desmopressin, as a nasal spray,  micrograms (0.1 mL) every  hours, or PO, .05 milligrams every  hours, as starting doses. Therapy of nephrogenic diabetes insipidus includes a low­salt, low­protein diet, adequate hydration, and the careful use of one to three agents that act together to concentrate urine in these patients: a thiazide diuretic, the potassium­sparing diuretic amiloride, and indomethacin. Exogenous ADH,  to  micrograms SC, two to four times daily, is also used in noncongenital nephrogenic diabetes insipidus, as these patients have a partial response to ADH. Patients with significant electrolyte abnormalities should be admitted to the hospital, whereas stable patients suspected of having diabetes insipidus should be referred for testing.
POTASSIUM: PATHOPHYSIOLOGY
+ + +
Potassium (K ) is the major intracellular cation of the body: 98% of total body K in healthy subjects is intracellular, and 70% to 75% of total K is in
+ muscle tissues. The normal intracellular concentration averages 150 mEq/L, and the normal extracellular concentration is .5 to .0 mEq/L. K is excreted predominantly by the kidneys (80% to 90%) and is filtered freely through the renal glomerulus and then reabsorbed in the proximal and
+ ascending tubules. It is secreted in the distal tubule in exchange for Na . In healthy individuals, the kidneys are able to excrete up to  mEq/kg/d. The
+ several mechanisms of K handling along the nephron are the targets of diuretic therapy.
+ +
Being mostly intracellular, an accurate calculation of total body K is difficult, but an estimation of the K deficit can be determined using the following
+ + + equation: estimated K deficit in mEq/L = (expected serum [K ] in mEq/L – measured serum [K ] in mEq/L) × ICF (calculated as 40% of
 total body weight).
However, this equation is reliable only for healthy subjects, because critical patients sustain significant and rapid intracellular to extracellular shifting in response to severe injury (e.g., surgical stress, trauma, or burns), acid­base imbalance, catabolic states, increased extracellular osmolality, or insulin
+ + deficiency. So it is possible to have hyperkalemia in patients with a total body K deficit (e.g., diabetic ketoacidosis) and hypokalemia with total body K
 + surplus. These shifts are crucial considering the role of K in maintaining the resting membrane potential, as the ratio of intracellular to extracellular
+ ,29
K is the most important determinant of neuromuscular and cardiovascular excitability.
+ +
Acid­base imbalance plays an important role in critically ill patients: there is an inverse proportionality between serum pH and [K ], with [K ] rising
+ +1,30 about .6 mEq/L for every .1 decrease in pH and vice versa, through an exchange between H and K .
In addition, the duration of both hypo­ and hyperkalemia influences the clinical response: chronic potassium depletion or surplus allows adaptation
+ through shifts in intra­/extracellular K concentration to maintain the resting membrane potential, thus mitigating neuromuscular and cardiac electrophysiologic effects.

Potassium derangements are becoming more and more frequent in the ED (up to 11%) and should be promptly and correctly addressed.
HYPOKALEMIA
+
Hypokalemia is defined as a serum [K ] of <3.5 mEq/L. The most frequent causes of hypokalemia are insufficient dietary intake (e.g., fasting, eating disorders, alcoholism), intracellular shifts (e.g., alkalosis, insulin, β ­agonists, hypokalemic periodic paralysis), and increased losses, mainly GI

(vomiting, nasogastric suction, diarrhea) or renal (diuretics, hyperaldosteronism, osmotic diuresis, toxins) (Table 17­13).
TABLE 17­13
Causes of Hypokalemia
Transcellular Alkalosis* shifts
Increased plasma insulin (treatment of diabetic ketoacidosis)
β­Adrenergic agonists
Hypokalemic periodic paralysis (congenital)
Thyrotoxic hypokalemic periodic paralysis
Decreased Fasting intake Alcoholism (worsened by hypomagnesemia)
Eating disorders
GI loss Vomiting*, nasogastric suction
Diarrhea* (including laxative, enema abuse)
Malabsorption
Ureterosigmoidostomy
Enteric fistula
Villous adenoma
Renal loss Diuretics (carbonic anhydrase inhibitors, loop diuretics, and thiazide­like diuretics)* Primary hyperaldosteronism
Secondary hyperaldosteronism
Licorice ingestion
Excessive use of chewing tobacco
Renal tubular acidosis
Postobstructive diuresis
Osmotic diuresis
Bartter’s syndrome (mimics loop diuretic use)
Gitelman’s syndrome (mimics thiazide diuretic use)
Apparent mineralocorticoid excess and related syndromes (Conn’s, Liddle’s)
Drugs and toxins (aminoglycosides, echinocandins, carbenicillin, penicillins, amphotericin B, levodopa, lithium, thallium, cesium, barium, toluene, theophylline, chloroquine, steroids, etc.)
Sweat loss Heavy exercise
Heatstroke
Fever
Other Hypomagnesemia
Acute leukemia and lymphomas
IV hyperalimentation
Recovery from megaloblastic anemia
Hypothermia (accidental or induced)
*Frequently encountered etiologies in the ED.
The clinical manifestations result from abnormalities in membrane polarization and affect almost every body system but are particularly dangerous in
+ the excitable myocardium. Hypokalemia makes the resting potential more electronegative, thus enhancing depolarization; the reduction in [K ] conduction delays repolarization, causing prolonged QT , flattened T waves, and the appearance of U waves in the ECG (Figure 17­4).
c
FIGURE 17­4
ECG of a patient with potassium of .4 mEq/L, with leg paralysis and deep fatigue. The patient had been taking a thiazide­like diuretic for hypertension.
Notice the prolonged QT and a flattened T wave with a U wave visible in V to V .
c  
CLINICAL FEATURES
Symptoms of hypokalemia (Table 17­14) usually start when serum concentrations reach .5 mEq/L, although they may appear sooner with rapid
+ decreases in concentration or appear later (i.e., at even lower [K ]) for chronic depletion.
TABLE 17­14
Symptoms and Signs of Hypokalemia
Cardiovascular Hypertension
Orthostatic hypotension
Potentiation of digitalis toxicity
Dysrhythmias (usually tachyarrhythmias)
T­wave flattening, QT prolongation, U waves, ST depression
Neuromuscular Malaise, weakness, fatigue
Hyporeflexia
Cramps
Paresthesias
Paralysis
Rhabdomyolysis
GI Nausea, vomiting
Abdominal distention
Ileus
Renal Increased ammonia production
Urinary concentrating defects
Metabolic alkalemia, paradoxical aciduria
Nephrogenic diabetes insipidus
Endocrine Glucose intolerance

Particular attention must be paid to cardiac arrhythmias, usually tachyarrhythmias (atrial fibrillation, torsadess de pointes, ventricular tachycardia, and ventricular fibrillation), which can be life threatening.
DIAGNOSIS
Diagnosis of hypokalemia is made with serum chemistry measurement; the etiology is investigated with additional testing. An ECG should be obtained from hypokalemic patients in the ED (Figure 17­4). Obtain blood gas analysis when alkalosis is suspected. If the cause of hypokalemia is not apparent
+ +  from history, spot urinary electrolytes can be obtained before starting K replacement (see Table 17­15 for interpretation of urine K values ); also
+
U , U , and P should be measured, because a U value <30 mEq/L and a U value less than P suggest polyuria. Polyuria can increase K
Na+ OSM OSM Na+ OSM OSM
+ +  excretion even if total body K is depleted; thus urinary K may be misleading for diagnosis in the setting of polyuria.
TABLE 17­15
Interpretation of Urinary Potassium
Spot Urinary Potassium Possible Mechanism
U K+ <10 mEq/L Decreased K+ intake, nonrenal losses
GI losses
Sweat losses
Nasogastric suction (↓U )
Cl–
Transcellular shift
Alkalosis (↓U )
Cl–
Hypomagnesemia (↑U )
Cl–
Hypokalemic periodic paralysis
Thyrotoxic hypokalemic periodic paralysis (calculate TTKG)
U >20 mEq/L Renal losses
K+
If hypernatremia coexists consider: hyperaldosteronism (calculate TTKG)
Massive GI losses (secondary to metabolic alkalosis)
Abbreviations: TTKG = transtubular K+ gradient; U = urinary chloride; U = urinary potassium.
Cl– K+
+ + +
Another useful tool for differential diagnosis is transtubular K gradient = (Urinary K × P )/(U × Plasma K ), with normal values of  to 
OSM OSM mEq/L. Values <5 mEq/L suggest hyperaldosteronism; if paralysis is present, values <3 mEq/L suggest hypokalemic periodic paralysis. A
,37 calcium/phosphate ratio >1.7 on a spot urine is 100% sensitive and 96% specific for thyrotoxic hypokalemic periodic paralysis.
TREATMENT
+
The treatment of hypokalemia is replacement of K . This should be done orally in stable patients with mild hypokalemia (>3.0 mEq/L) who are able to
 + tolerate oral intake. Foods rich in K (fruits, dried fruits, nuts, vegetables, and meat) can be suggested at discharge from ED, as well as salt substitutes
+ or K supplements that should be prescribed with abundant fluids and/or food to prevent gastric irritation. Additional treatment targeted to the underlying cause should be considered. For example, it is possible to treat (and prevent) chronic hypokalemia induced by loop or thiazide diuretics by
 adding an adequate amount of spironolactone to the patient’s chronic therapy ; however, the primary care physician should be aware of or guide such a change in medication. Whenever modifying diuretics or other drugs at ED discharge, recommend follow­up within  week for repeat assessment
+ of renal function and [K ]. In hypokalemia secondary to respiratory alkalosis (as caused by an acute anxiety disorder), the simple correction of the acid­
+ base imbalance (through reassurance or anxiolytics) can correct [K ] without administering exogenous potassium.
IV replacement is indicated in patients with severe (<2.5 mEq/L) hypokalemia and in symptomatic patients with moderate (2.5 to  mEq/L) hypokalemia.
Treat patients with cardiac arrhythmias or prolonged QT or when oral replacement is not tolerated or not feasible (see Table 17­16 for common c
+ medications known to prolong QT ). Monitor the patient’s rhythm when treating with IV K .
c
TABLE 17­16
Common Medications Known to Prolong QT c
Antiarrhythmics Amiodarone, sotalol, flecainide, quinidine, dronedarone, dofetilide
Vasopressors/inotropes Epinephrine, norepinephrine, dopamine, dobutamine
Neuroleptics Haloperidol, droperidol, chlorpromazine, olanzapine, quetiapine, risperidone, paliperidone, clozapine, aripiprazole
Antidepressants Amitriptyline, nortriptyline citalopram, escitalopram, fluoxetine, paroxetine, sertraline, venlafaxine
Antibiotics Macrolides, quinolones, metronidazole, cotrimoxazole
GI prokinetics Domperidone, cisapride, metoclopramide
Antiemetics Ondansetron, granisetron, dolasetron, promethazine
Antifungals Fluconazole, itraconazole, voriconazole, ketoconazole, posaconazole
Antivirals Foscarnet, amantadine, atazanavir, nelfinavir, rilpivirine, ritonavir, saquinavir, telaprevir
Antiparasitics Chloroquine, mefloquine, quinine, hydroxychloroquine, pentamidine
Antihistamines Terfenadine, hydroxyzine, diphenhydramine
Others Cocaine, lithium, methadone, tamoxifen, vardenafil, tacrolimus, pseudoephedrine
+
Monitor closely those patients who sustain rapid [K ] changes due to their illness (e.g., postobstructive polyuria) or IV treatment. An example is diabetic
+ ketoacidosis treatment, where rapid hypokalemia (including life­threatening arrhythmias) should be prevented by adequate IV K administration prior to the detection of a rapid fall in serum potassium.
The following are general principles in hypokalemia correction:
+ +
. Use potassium chloride and avoid administering K in glucose solutions, to reduce insulin­induced K transfer into cells.
+
. Potassium is irritating to the endothelium; adequate dilution is mandatory to prevent pain and phlebitis (maximum recommended [K ] in 500 mL of a saline solution is  mEq, to be infused in  to  hours in a peripheral line). If a more aggressive correction is needed, an identical solution can be administered in a second peripheral line. Higher concentrations can be administered through a central line, but infusion rates should never exceed
 mEq/h.
+
. Reassessing serum [K ] should be adjusted to infusion rate and coexisting factors (e.g., concomitant acid­base imbalance, volume depletion, cardiac arrhythmias).
. ECG monitoring is recommended.
. In most cases, hypokalemic patients are also hypomagnesemic. Thus, magnesium (20 to  mEq/24 h) may be added to the infusion both to
 optimize tubular reuptake of potassium and to contrast proarrhythmic effect of hypokalemia.
HYPERKALEMIA: PATHOPHYSIOLOGY
+
Hyperkalemia is defined as measured serum [K ] of >5.5 mEq/L. The most common cause is factitious hyperkalemia due to release of intracellular potassium caused by hemolysis during phlebotomy. Other causes are listed in Table 17­17. TABLE 17­17
Causes of Hyperkalemia
Pseudohyperkalemia Tourniquet use
Hemolysis (in vitro)* Leukocytosis
Thrombocytosis
Intracellular to Acidosis* extracellular potassium
Heavy exercise shift
β­Blockade
Insulin deficiency
Digitalis intoxication
Hyperkalemic periodic paralysis
Potassium load Potassium supplements
Potassium­rich foods
IV potassium
Potassium­containing drugs
Transfusion of aged blood
Hemolysis (in vivo)
GI bleeding
Cell destruction after chemotherapy
Rhabdomyolysis/crush injury* Extensive tissue necrosis
Decreased potassium Renal failure* excretion
Drugs—potassium­sparing diuretics,*β­blockade, NSAIDs, angiotensin­converting enzyme inhibitors, angiotensin II receptor blockers, cyclosporine, tacrolimus
Aldosterone deficiency* Selective defect in renal potassium excretion (pseudohypoaldosteronism, systemic lupus erythematosus, sickle cell disease, obstructive uropathy, renal transplantation, type IV renal tubular acidosis)
*Frequent or important ED diagnostic considerations.
Clinical manifestations of hyperkalemia result from disordered membrane polarization (Figure 17­5). Cardiac manifestations are the most serious. In hyperkalemia, the resting potential of the excitable myocardium becomes less electronegative, with a consequent partial depolarization that reduces the activation of voltage­dependent sodium channels; this results in a slower and reduced amplitude of action potential. Table 17­18 summarizes the
ECG effects that may lead to arrhythmic complications, such as sinoatrial and atrioventricular blocks and atrial paralysis (Figure 17­5). Calcium administration does not affect potassium levels; rather, calcium antagonizes the effects of hyperkalemia at the level of the cell membrane, raising the threshold potential, thus restoring the membrane potential and myocyte excitability close to normal (Figure 17­6).
FIGURE 17­5
Monitor strip (V V ) of a 35­year­old patient in critical condition, who was hypotensive and fatigued and rapidly deteriorated into cardiac arrest.
1– 
Potassium level was .1 mEq/L. She was on spironolactone and steroid therapy.
TABLE 17­18
ECG Changes Associated with Hyperkalemia
[K+] (mEq/L) ECG Changes* .5–7.5 Prolonged PR interval, tall peaked T waves, short QT interval
.5–8.0 Flattening of the P wave, QRS widening
10–12 QRS complex degradation into a sinusoidal pattern
*In chronic or slowly developing hyperkalemia, ECG changes may not occur until higher [K+] levels are reached.
FIGURE 17­6
The same patient as in Figure 17­5 during calcium chloride infusion. She regained a pulse and became conscious. The QRS and T wave narrowed, as compared with Figure 17­5. CLINICAL FEATURES
Cardiac dysrhythmias, such as ventricular fibrillation, sinoatrial and atrioventricular blocks until complete heart block, and asystole, may occur. Death from hyperkalemia is usually the result of diastolic arrest or ventricular fibrillation. Other common symptoms include neuromuscular dysfunctional
 weakness, paresthesias, areflexia, ascending paralysis, and GI effects (nausea, vomiting, and diarrhea).
DIAGNOSIS
A stat ECG is essential in all hyperkalemic patients (Table 17­18); if ECG changes are present, emergency treatment of hyperkalemia should start immediately. In addition, if ECG changes are detected in a patient whose electrolyte levels are not yet known (e.g., a dialysis patient),
+ hyperkalemia should be suspected and treated. A symptomatic patient with a relatively small elevation of [K ] (5.0 to .0 mEq/L) requires identification
+ + and treatment of the underlying cause. A spot urine K may identify the diagnosis. An elevated spot urine K (>20 mEq/L) suggests an extrarenal cause
+
(and will more likely be responsive to therapy). A low urine K output (<10 mEq/L) suggests oliguric kidney failure or drug effect, such as angiotensinconverting enzyme inhibitors or angiotensin II receptor blockers.
TREATMENT
Emergency treatment includes continuous ECG monitoring and immediate intervention with several therapeutic medications, which based on the action mechanism can be divided into three modalities: membrane stabilization (crucial for cardiac tissue, must be done immediately), intracellular
+ + shift of K , and removal/excretion of K from the body. All three modalities should be administered sequentially in rapid succession. Each mode has a
 different onset time and duration (Table 17­19).
TABLE 17­19
Emergency Therapy of Hyperkalemia
Therapy Dose and Route Onset Duration Mechanism of of Effect
Action
Calcium 5–10 mL IV 1–3 min 30–50 min Membrane stabilization chloride
(10%)* Calcium 10–20 mL IV 1–3 min 30–50 min Membrane stabilization gluconate
(10%)* NaHCO † 50–150 mEq IV if accompanying metabolic acidosis 5–10 1–2 h Shifts [K+] into cell
 min
Albuterol 10–20 milligrams in  mL of normal saline, nebulized over  min 15–30 2–4 h Upregulates cyclic
(nebulized) min adenosine monophosphate, shifts
[K+] into cell
‡ 5–10 units regular insulin IV  min 4–6 h Shifts [K+] into cell
Insulin and
Glucose  grams (50% solution) IV glucose#
Furosemide 40–80 milligrams IV Varies Varies Renal [K+] excretion
Sodium  grams PO; do not give within  hrs of any other oral medications. Can decrease  h  hr Preferentially binds K[+] zirconium levels of clopidogrel and dabigatrain and raise levels of warfarin if not separated by throughout GI tract cyclosilicate at least  hrs (Risk D)
Sodium 25–50 grams PO or PR Hrs Varies Binds [K+] in colon; can polystyrene cause intestinal necrosis sulfonate
Hemodialysis — Minutes Varies Removes [K+]
*Calcium chloride has three times the elemental calcium when compared to calcium gluconate. 10% calcium chloride = .2 milligrams [Ca2+]/mL; 10% calcium gluconate =  milligrams [Ca2+]/mL. Due to its short duration, calcium administration (both chloride and gluconate) can be repeated up to four times per hour.
†May be institutional variations in treatment with sodium bicarbonate; refer to Batterink et al41 and Rossignol et al42 for full discussion.
‡
Reduce dose of insulin in patients with renal failure.
#Glucose infusion should be administered after initial bolus to prevent hypoglycemia. Glucose should not be administered in hyperglycemic patients.
A blood gas is essential to identify metabolic acidosis. A 2015 Cochrane review does not recommend the routine administration of sodium bicarbonate
 for hyperkalemia unless there is concomitant metabolic acidosis. In this Cochrane review, the effectiveness of sodium bicarbonate alone, or in combination with other therapies listed in Table 17­19, could not be clearly demonstrated, even at a variety of time points. Treatment should correct the underlying cause of the acid­base imbalance. If pH is normal or alkaline, the therapeutic measures that act to promote an intracellular to
+ extracellular shift of [K ] will be less effective, and treatment should be aimed at improving renal excretion.
Sodium polystyrene sulfonate is an oral agent in widespread use for the past  years, though there is little data on its effectiveness. It lowers potassium levels by binding potassium primarily in the colon. It can cause intestinal necrosis, especially when used along with sorbitol, and large or
 repeated doses can cause bezoars or fecal impaction. Sodium zirconium cyclosilicate is FDA approved for treatment of hyperkalemia, and has been
 demonstrated to be an effective agent for the emergency treatment of hyperkalemia in a recent Phase II trial . Do not give sodium zirconium cyclosilicate within  h of any oral medication, as it may bind other medications. Notably, it may decrease serum concentrations of clopidogrel and dabigatran when given within  hrs before or after their administration, and may increase the serum concentration of warfarin (risk category D).
Patiromer is a third potassium binder, but with an onset of action of  h, it is not useful for emergency treatment. It also may bind other oral medications, and should not be given within 3h of other medications.
The following are general principles in treatment of hyperkalemia:
+ +
. Immediate cessation of further K administration, reduction of dietary intake, and suspension of drugs impairing K renal excretion directly
+
(angiotensin­converting enzyme inhibitors, angiotensin receptor blockers, K ­sparing diuretics) or indirectly through worsening of renal function
(e.g., NSAIDs, iodine contrast, antibiotics).
+
. Fluid administration enhances K renal excretion through increasing urine output.

. If a patient is on digitalis, hypercalcemia enhances the toxic cardiac effects of digitalis. However, in severe hyperkalemia secondary to digitalis intoxication with advanced intraventricular conduction impairment (wide, low­voltage QRS complexes), calcium administration must be
 considered, in association with antidigoxin antibodies.
+
. ECG continuous monitoring should be used to confirm the effects of therapy, thus reducing the frequency of rechecking [K ].
MAGNESIUM
2+
The total body content of magnesium (Mg ) is  grams, or 2000 mEq, 50% to 70% of which is fixed in bone and only slowly exchangeable. Most of the
2+ 2+ + remaining Mg is found in the ICF space, with a concentration of approximately  mEq/L. The distribution of Mg is similar to that of K , with the
2+ major portion being intracellular. It is the second most abundant intracellular cation. Normal serum [Mg ] ranges between .5 and .5 mEq/L (0.7 to
2+
### .1 mmol/L or .7 to .7 milligrams/dL). Circulating Mg is 25% to 35% bound to proteins (mainly albumin), 10% to 15% complexed, and 50% to 60%
2+ ionized, which is the active portion. The normal dietary intake of Mg is approximately 240 to 336 milligrams/d and is found in vegetables such as dry
2+ beans and leafy greens, meat, and cereals. Sixty percent of excreted Mg is through stool, with the remainder via the urine. Renal reabsorption is carried out with sodium and water and is unidirectional; that means that it is impaired by volume overload, osmotic diuresis, and diuretics. About 300
2+ enzymes have their activities regulated by Mg ; it assists the production of adenosine triphosphate, participates in nucleic acid and protein synthesis,
,2,47 and is involved in coagulation, platelet aggregation, and neuromuscular activity, as well as in cardiac action potential.
2+
Mg homeostasis is very complex and finely regulated by many factors, such as parathyroid hormone, calcitonin, ADH, glucose, insulin, glucagon,
2+  catecholamines, sodium, potassium, calcium, and phosphorus levels. Mg is effective therapy in severe asthma when added to standard therapy
(see Chapter , “Acute Asthma and Status Asthmaticus”).
HYPOMAGNESEMIA
Table 17­20 lists the different causes of hypomagnesemia.
TABLE 17­20
Causes of Hypomagnesemia
Redistribution IV glucose
Correction of diabetic ketoacidosis
IV hyperalimentation
Refeeding after starvation
Acute pancreatitis
Postparathyroidectomy (hungry bone syndrome)
Osteoblastic metastasis (hungry bone syndrome)
Extrarenal loss Nasogastric suction (infrequent)
Lactation
Profuse sweating, burns, sepsis
Intestinal or biliary fistula
Diarrhea
Decreased intake Alcoholism (cirrhosis)
Malnutrition, poor intake
Small bowel resection
Malabsorption (steatorrhea)
Renal loss Ketoacidosis
Saline or osmotic diuresis
Potassium depletion
Phosphorus depletion
Familial hypophosphatemia
Tubulointerstitial renal disease
Drugs Loop diuretics
Aminoglycosides
Amphotericin B
Vitamin D intoxication
Alcohol
Cisplatin
Theophylline
Proton pump inhibitors
Calcineurin inhibitors (cyclosporine, tacrolimus)
Endocrine disorders Syndrome of inappropriate antidiuretic hormone secretion
Hyperthyroidism
Hyperparathyroidism
Hypercalcemic states
Primary or secondary aldosteronism
2+
IV hyperalimentation or treatment of diabetic ketoacidosis without adequate provision of Mg , especially in a previously malnourished patient, can
2+ 2+ cause an abrupt fall in plasma Mg levels. Acid­base imbalance affects the levels of ionized Mg ; a typical example is respiratory alkalosis that
2+ 2+ enhances neuromuscular activity (thus provoking tremors and cramps) by rapidly decreasing ionized [Mg ] and [Ca ] at the same time.

Among the iatrogenic causes, proton pump inhibitors may cause hypomagnesemia, especially in association with diuretic therapy, probably through the inhibition of intestinal absorption. Concomitant hypomagnesemia and hypokalemia may coexist.
CLINICAL FEATURES
2+
Due to the essential role of Mg in enzyme regulation in multiple body systems, hypomagnesemia may result in a wide variety of neuromuscular, GI, and cardiovascular effects (Table 17­21).
TABLE 17­21
Symptoms and Signs of Hypomagnesemia
Neuromuscular Tetany
Muscle weakness
Chvostek and Trousseau signs
Cerebellar (ataxia, nystagmus, vertigo)
Confusion, obtundation, coma
Seizures
Apathy, depression
Irritability
Paresthesias
GI Dysphagia
Anorexia, nausea
Cardiovascular Heart failure
Dysrhythmias
Hypotension
Miscellaneous Hypokalemia
Hypocalcemia
Anemia
DIAGNOSIS

Hypomagnesemia is common in acute illness; it has been found in 12% of hospitalized patients and in up to 65% of medical intensive care patients. It
 is likely underdiagnosed because few hospitalized patients have levels drawn.
The diagnosis of hypomagnesemia in the presence of normal serum calcium levels is suggested by increased neuromuscular irritability, shown by hyperreflexia tremor, tetany, or even convulsions. Chvostek sign and Trousseau sign, findings traditionally associated with hypocalcemia, may be elicited in hypomagnesemic patients. Hypomagnesemia should be suspected in patients with alcoholism or cirrhosis or those requiring IV fluids or
2+ hyperalimentation for prolonged periods. Low total [Mg ] can also be secondary to hypoalbuminemia.
2+
The ECG changes may be similar to those caused by hypokalemia and/or hypocalcemia because they may be due to Mg deficiency altering cardiac
2+ intracellular potassium content. As for hypokalemia, low [Mg ] levels enhance digitalis toxicity, so hypomagnesemia should be searched in ECG
+  disturbances associated with digoxin intake, especially when both digoxin and K levels are normal.
TREATMENT
Hypokalemia, hypocalcemia, and hypophosphatemia are often present with severe hypomagnesemia and must be monitored
2+ carefully. Hypocalcemia does not develop until [Mg ] falls below .2 milligrams/dL.
The following are general principles in treatment of hypomagnesemia:
. Treat or stop the cause of hypomagnesemia.
. For asymptomatic patients (including ECG changes), magnesium supplements should be administered orally, in multiple low doses during the day, to avoid diarrhea. Magnesium lactate, chloride, gluconate, and proteinate are the formulations with minimum effect on intestinal motility.
. For severe and symptomatic hypomagnesemia, urgent IV replacement is mandatory. The formulation most commonly used is magnesium sulfate
(MgSO ). In life­threatening conditions (torsades de pointes, eclampsia),  to  grams or  to  mEq diluted in at least 100 mL of 5% dextrose or
 normal saline (0.9%) solution can be administered in  to  minutes under continuous monitoring: ECG (risk of hypokinetic arrhythmias), noninvasive blood pressure (risk of hypotension), and ventilatory pattern (risk of respiratory depression, usually preceded by areflexia, that can be monitored as an alarm sign). As a minor side effect, flushing due to vasodilatation is common.
2+ 2+
. Patients with chronic Mg deficiency may require >50 mEq of oral Mg (6 grams of MgSO per day). In chronic alcoholics with delirium tremens and
 in patients with severe hypomagnesemia, up to  to  grams of MgSO may be given IM (possible, but very painful) or IV the first day. The first  to

 mEq (1.5 to .0 grams) of IV MgSO can be given over  to  hours. This may be followed by up to  to  grams/d. Approximately half of the

2+ administered Mg will be lost in the urine.
2+
. Spironolactone is effective in maintaining [Mg ] homeostasis as well as in reducing the incidence of arrhythmias in congestive heart failure
 patients.
HYPERMAGNESEMIA
2+
Hypermagnesemia is rarely encountered in emergency medicine practice, because the kidney can increase the fractional excretion of Mg up to nearly
100%. A small elevation in serum concentration has little clinical significance. The most common cause for hypermagnesemia can be found in patients
2+  with renal insufficiency or renal failure who ingest Mg ­containing drugs. Hypermagnesemia is more commonly seen in the perinatal setting
2+ secondary to the treatment of preeclampsia or eclampsia. It has been described as a serious, life­threatening consequence of Mg ­containing laxative
 abuse in patients with normal renal function. Other causes of hypermagnesemia include lithium ingestion, volume depletion, or familial hypocalciuric hypercalcemia (Table 17­22).
TABLE 17­22
Causes of Hypermagnesemia
Renal Failure Acute or Chronic
Increased magnesium load Magnesium­containing laxatives, antacids, or enemas* Treatment of preeclampsia/eclampsia (mothers and neonates)
Diabetic ketoacidosis (untreated)* Tumor lysis
Rhabdomyolysis* Increased renal magnesium absorption Hyperparathyroidism
Familial hypocalciuric hypercalcemia
Hypothyroidism
Mineralocorticoid deficiency, adrenal insufficiency (Addison’s disease)
*Most likely presentations relevant to the ED.
CLINICAL FEATURES
2+
Hypermagnesemia rarely produces symptoms. Mg decreases the transmission of neuromuscular messages and thus acts as a CNS depressant and
2+ decreases neuromuscular activity. Signs and symptoms related to [Mg ] can be found in Table 17­23. TABLE 17­23
Symptoms and Signs of Hypermagnesemia
Magnesium Level (mEq/L) Clinical Manifestations
.0–3.0 Nausea
.0–4.0 Somnolence
.0–8.0 Loss of deep tendon reflexes
.0–12.0 Respiratory depression
.0–15.0 Hypotension, heart block, cardiac arrest
DIAGNOSIS
2+
Serum [Mg ] is usually diagnostic. The possibility of hypermagnesemia should be considered in patients with hyperkalemia or hypercalcemia. Hypermagnesemia also should be suspected in patients with renal failure, particularly in those who are taking magnesiumcontaining antacids or laxatives.
TREATMENT
2+
Immediate cessation of Mg administration is required. If renal failure is not evident, dilution by IV fluids followed by furosemide (40 to  milligrams
IV) may be indicated. Calcium directly antagonizes the cardiac effects of magnesium because it reverts the calcium channel blockade provoked by
2+ elevated [Mg ]. Severe symptomatic hypermagnesemia can be treated with  mL of 10% calcium chloride IV over  to  minutes. Further infusion of 
2+ to  mL during the next  hours can be administered. Patients with renal failure may benefit from dialysis using a decreased [Mg ] bath that lowers
2+ serum [Mg ].
CALCIUM: PATHOPHYSIOLOGY
2+ 2+
Calcium (Ca ) is the most abundant mineral in the body. The total body [Ca ] is  grams/kg of body weight, or about  kg in an average­sized adult.
2+
Ca is 99% bound in bone as phosphate and carbonate (mineral apatite), with the remainder in the teeth, soft tissues, plasma, and cells. The normal
2+ daily intake of Ca is 800 to 3000 milligrams, one third of which is absorbed primarily in the small bowel by active (vitamin D–dependent) and passive
2+
(concentration­dependent) absorption. Excretion of Ca is primarily via the stool.
2+ 2+
The cell content of Ca is ,000 times lower than the plasma content, and this gradient is maintained by Ca­ATPase, Ca ­specific channels, and Na/Ca exchangers.
2+
Plasma [Ca ] is between .5 and .5 milligrams/dL (4.3 to .3 mEq/L or .2 to .7 mmol/L) and is present in three different forms: ionized calcium,
50% of total (4.5 to .6 milligrams/dL; .1 to .4 mmol/L), which is the only active fraction; protein­bound calcium, 40% of total, which is inactive and not filtered by glomerulus; and complexed calcium, 10% of total, which is bound to anions such as phosphate, carbonate, and citrate.
2+
It is necessary to be aware of standard units used by different laboratories to express Ca value:  mEq/L =  milligrams/dL = .5 mmol/L. The
2+ ionized fraction is the only biologically active fraction; a decrease in albumin decreases the total [Ca ] but does not change the ionized fraction. On
2+ 2+ 2+ average, .8 milligram of Ca binds to  gram of protein. Therefore, total serum [Ca ] is equal to ionized [Ca ] plus the product of .8 and total
2+ 2+ protein. Alkalosis produces a decrease in ionized fraction with no change in the total serum [Ca ]. Each .1 rise in pH lowers ionized [Ca ] by about
3% to 8%. The opposite effect is produced by acidosis.
2+
The role of Ca is crucial for muscle and cardiac contraction, nerve conduction, cell growth, enzyme activation, and coagulation, and consequently, any hypo­ or hypercalcemia leads to severe dysfunctions.
HOMEOSTASIS OF CALCIUM
The organs involved in the homeostasis of calcium are bones, kidneys, and the intestines, whereas the major determinants are three hormones and
,2,56,57 one receptor.
 2+
. ,25­Dihydroxycholecalciferol (active vitamin D ) is formed in the distal tubule. It promotes Ca absorption from intestine, but this activity
 is modulated by physiologic conditions that may enhance it (pregnancy and growth) or reduce it (oxalates and phytates in food and aging).
2+ 2+ 2+
. Parathyroid hormone (PTH) is secreted by parathyroid glands when [Ca ] is low and is regulated by Ca ­sensing receptor, vitamin D , and Mg

(hypomagnesemia inhibits PTH secretion). PTH stimulates bone demineralization by activating osteoclasts and by increasing the synthesis of
2+  vitamin D and increasing Ca reabsorption from kidney.

2+
. Calcitonin is a peptide secreted by C­cells of the thyroid gland when [Ca ] is high. It inhibits the activity of osteoclasts and thus bone resorption.

