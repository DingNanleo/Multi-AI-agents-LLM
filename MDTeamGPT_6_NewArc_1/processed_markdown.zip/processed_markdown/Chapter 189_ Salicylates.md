## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 189: Salicylates
Rachel Levitan; Frank LoVecchio
INTRODUCTION
The widespread availability of aspirin or acetylsalicylic acid in prescription and over­the­counter preparations can lead to both accidental and intentional toxicity. Morbidity and mortality increase significantly when the condition is not rapidly identified, if there is a delay to starting treatment, or if poisoned patients are not treated aggressively.
In additional to aspirin oral preparations, numerous forms of salicylate are available as karyolitic agents, liniments, flavoring agents, and combination products. These products may contain salicylate, methyl salicylate, or acetylsalicylic acid, but regardless of the product, all formulations are rapidly
 converted to salicylate once ingested. Five milliliters of oil of wintergreen contain  grams of aspirin and can be deadly to a toddler. Liniments and
 products used in hot vaporizers have high concentrations of methyl salicylate, and an ingestion of  to  mL can be lethal for an infant or a toddler.
Even though salicylate is poorly absorbed after ingestion of bismuth subsalicylate (Pepto­Bismol®), significant exposures can occur from massive ingestions, such as in patients with human immunodeficiency virus/acquired immunodeficiency syndrome taking this medication for chronic
 diarrhea.
PATHOPHYSIOLOGY
After ingestion of therapeutic doses in standard tablet formulation, absorption is variable and dependent on dosage form, presence of food, and gastric pH, with peak salicylate levels usually occurring in  to  hours. In overdose, peak serum salicylate concentrations may not be reached for
 hours. Enteric­coated aspirin exhibits erratic absorption in therapeutic doses, and peak levels may also be delayed for hours after an overdose.

Salicylate itself impairs gastric emptying, which can result in delayed absorption. There is potential for formation of gastric bezoars that can serve as a
 source of ongoing absorption. Ingestion of methyl salicylate or other liquid formulations may have much more rapid absorption and achieve peak levels more rapidly. Limited information on powder forms of salicylates (common in the southeastern United States and the Middle East) suggests
 these forms follow the liquid salicylate pattern of low risk of prolonged absorption.
After absorption, aspirin is hydrolyzed to salicylic acid (salicylate) and is distributed throughout body tissues, with 50% to 80% being bound to serum proteins. As salicylate concentrations increase and saturate protein­binding sites, free (unbound) concentrations of salicylate increase. In solution, salicylate exists in equilibrium between the ionized and nonionized state; only the unbound, nonionized salicylate can readily cross cell membranes. At physiologic pH (7.40), almost all salicylate is ionized, but acidemia will increase the nonionized fraction, enabling more salicylate to cross cell
 membranes and, importantly, substantially increase brain salicylate concentration. Patients with identical total salicylate serum concentrations may vary greatly in their degree of toxicity depending on their tissue burden, plasma protein concentrations, pH, and other factors.
Salicylate undergoes hepatic metabolism in a process that rapidly becomes saturated even within the drug’s therapeutic range. Thus, salicylate
 metabolism in the overdose situation follows zero­order kinetics (i.e., a set amount of salicylate is eliminated per unit of time). Increased fraction of unbound salicylate also enhances renal clearance, making the kidney the major route of elimination during toxicity. Serum alkalinization can be used to keep salicylate in the plasma compartment and out of tissues, and urinary alkalinization can be used to enhance renal elimination. If the urine pH is above .5, more salicylate molecules in the urine will be ionized compared with the renal tubular cell pH of .4, and reabsorption across the urinary tubule will be reduced. This pH difference will also enhance secretion of nonionized salicylate down the concentration gradient.
Salicylate toxicity affects many physiologic systems (Table 189­1).
TABLE 189­1
DoPwanthlooapdheyds i2o0lo2g5y­7 o­f1 S 6a:l2ic8y Pla tYe oTuorx IiPci tisy 136.142.159.127
Chapter 189: Salicylates, Rachel Levitan; Frank LoVecchio 
. Terms of Use * Privacy Policy * Notice * Accessibility
Local gastric irritation
Reversible ototoxicity
Stimulation of the chemoreceptor zone
Stimulation of medullary respiratory center
Stimulation of skeletal muscle metabolism
Uncoupling of oxidative phosphorylation
Enhancement of lipolysis
Inhibition of Krebs cycle
Increased vascular permeability
Mobilization of glycogen stores
Inhibition of gluconeogenesis

Salicylate directly stimulates the medullary respiratory center to produce tachypnea, hyperpnea, and respiratory alkalosis. As toxicity worsens, inhibition of metabolism produces an acidosis that overwhelms the alkalosis. Classically, the acid­base disturbance associated with salicylate poisoning is mixed: early respiratory alkalosis, followed by an elevated anion gap metabolic acidosis, and possibly late respiratory acidosis. This respiratory alkalosis and metabolic acidosis are commonly mistaken for sepsis syndromes. Co­ingestion or administration of CNS depressants may blunt this initial respiratory stimulation. Salicylate stimulates skeletal muscle metabolism, which causes an increase in oxygen consumption and carbon dioxide production. Neurologic toxicity may impair ventilation so that it is unable to keep pace with increased carbon dioxide production, leading to respiratory acidosis—usually a late and ominous finding. Decreased ventilation can also be related to co­ingestions or iatrogenic medication.
Salicylate affects both central and peripheral glucose homeostasis. Although salicylate causes mobilization of glycogen stores, resulting in hyperglycemia, it is also a potent inhibitor of gluconeogenesis. Therefore, normoglycemia is the most common finding in toxicity; hyperglycemia can
,12 be seen occasionally, and hypoglycemia is a rare finding.
Salicylate can cause corrosive injury of the GI tract with abdominal pain, nausea, and vomiting with occasional hematemesis. These GI manifestations
 can lead to volume loss, metabolic alkalosis, and hypokalemia. Gastric perforation has been reported after a significant acute aspirin ingestion.
Salicylate­induced acute lung injury (noncardiogenic pulmonary edema) has been observed in humans. Although antiplatelet activity is a well­known, often desired effect of aspirin (but not other salicylate products), hemorrhage is a rare complication of acute (even massive) overdose. Large doses of
 all salicylates may cause significant hypoprothrombinemia resulting from inhibition of vitamin K–dependent functions.
Salicylate ototoxicity is common, and tinnitus often occurs with levels in the therapeutic range (20 milligrams/dL [1.5 mmol/L]). Although classically described as tinnitus or “ringing in the ears,” in practice, most patients will describe decreased sounds or that their hearing is “muffled.” The exact mechanism causing this is unknown, and hearing effects are not permanent.

Cardiac arrhythmias are a rare complication of salicylate poisoning.
CLINICAL FEATURES
,16
Clinical manifestations of salicylate toxicity depend on the dose ingested, duration of exposure, and age and comorbidities of the patient. In children and the elderly, end­organ toxicity can be seen with smaller doses and lower serum levels following an acute overdose. Chronic toxicity can produce insidious and severe neurologic changes that do not correlate well with dose or serum salicylate level. Patients with even a mild toxicity can become critically and severely ill if acidemia or dehydration develops.
INTOXICATION IN CHILDREN
In general, when the duration of salicylate intoxication is between  and  hours, metabolic acidosis and acidemia (pH <7.35) occur primarily in children <4 years old, and nearly all children <1 year old have acidosis. Young children can have a respiratory alkalosis, but this is often transient and
 missed because of their smaller ventilatory reserves. In older children (>4 years old), the acid­base disturbance is usually a mixed disturbance with respiratory alkalosis, increased anion gap metabolic acidosis, and alkalemia (pH >7.45).
Chronic or “therapeutic” (repeated dose) pediatric salicylate poisonings are more serious and are associated with a higher mortality than acute
,16,18 salicylism. Often, several days may elapse between the initial salicylate administration and the onset of symptoms. There is frequently a concurrent illness that prompted salicylate administration, and children usually appear more ill than those with acute intoxication. The presenting
 features are usually fever, hyperventilation, and altered mental status with volume depletion, acidosis, and severe hypokalemia. Young children are
 prone to hyperpyrexia, which indicates a worse prognosis. Renal failure may be a significant complication, but pulmonary edema is unusual in the
,18 pediatric population. Chronic salicylism is often mistaken for an infectious process, and the resultant delay in diagnosis may account for the more severe clinical picture. The diagnosis can be particularly difficult due to the proscription against aspirin use for fever in children (Reye's syndrome risk). Aspirin may have been given by family members rather than by a physician.
The diagnosis may be delayed if a history of salicylate ingestion is not available. The differential diagnosis includes diabetic ketoacidosis, sepsis, iron intoxication, and toxic alcohol poisoning.
INTOXICATION IN ADULTS
Acute salicylate intoxication in adults is often due to intentional ingestion. The typical clinical presentation includes nausea, vomiting, tinnitus, hearing loss, sweating, and hyperventilation. Patients with tinnitus or hearing loss following an acute ingestion usually have an elevated serum salicylate
 value.
Most adult patients with acute salicylate overdose have a mixed acid­base disturbance of alkalemia with respiratory alkalosis and metabolic acidosis.
As toxicity progresses, acidosis worsens. CNS dysfunction manifests as agitation, lethargy, confusion, seizure, or coma. CNS dysfunction leading to
,20 cerebral edema is an ominous development and a sign of severe toxicity, requiring rapid and aggressive treatment. Despite treatment and decreasing serum salicylate levels, patients may worsen and die from progressive neurologic impairment, possibly because of increasing CNS salicylate levels.
Salicylate­induced vomiting can produce a metabolic alkalosis. Other rare complications of salicylate toxicity include rhabdomyolysis, gastric perforation, and GI hemorrhage. Poor prognostic factors for acute salicylate toxicity include coma, fever, respiratory acidosis, seizure, and cardiac dysrhythmias. In adults with acute salicylate poisoning, independent predictors of severe outcome were older age, tachypnea, and initial lactate concentration. Initial salicylate concentration alone was not predictive.
Chronic salicylate intoxication (from repeated excessive dosing) in adults often presents with neurologic abnormalities such as lethargy, altered
 mental status, irritability, and hallucinations, particularly in the elderly. Toxicity can develop even with small increases in doses due to saturable kinetics. Clinical features of chronic intoxication include hyperventilation, tremor, papilledema, agitation, paranoia, bizarre behavior, memory deficits, confusion, and stupor. Nausea and vomiting are less common than in acute salicylate toxicity, whereas increased liver function tests and increased prothrombin time are more common. Neurologic abnormalities in chronic salicylate poisoning may be nonspecific and may often mislead physicians.
Chronic salicylism should be considered in a patient with unexplained neurologic or behavioral dysfunction, especially in the presence of a mixed acid­
 base disturbance, tachypnea, dyspnea, or unexplained pulmonary edema. Compared with acute toxicity, adults with chronic salicylate toxicity have a higher tissue burden of salicylate, leading to more significant toxicity at a lower serum concentration.
The distinction between acute and chronic salicylate toxicity may not always be clear. A patient may present many hours after an acute severe salicylate overdose, when altered mental status, acidosis, elevated prothrombin time, and a “therapeutic” serum salicylate concentration appear more consistent with a chronically poisoned patient. Significant toxicity may be evident despite declining or “therapeutic” serum salicylate concentrations.
In these situations, the patient’s clinical status is most important when assessing the severity of toxicity (Table 189­2).
TABLE 189­2
Severity Grading of Salicylate Toxicity in Adults
Mild Moderate Severe
Acute ingestion (dose) <150 milligrams/kg 150–300 milligrams/kg >300 milligrams/kg
End­organ toxicity Tinnitus Tachypnea Abnormal mental status
Hearing loss Hyperpyrexia Seizures
Dizziness Diaphoresis Acute lung injury
Nausea/vomiting Ataxia Renal failure
Anxiety Cardiac arrhythmias
Shock
Chronic salicylism may develop in patients taking carbonic anhydrase inhibitors for treatment of glaucoma. The normal anion gap (hyperchloremic) metabolic acidosis produced by carbonic anhydrase inhibitors increases the volume of distribution for salicylate and facilitates its entry into the CNS, causing toxicity at a “therapeutic” serum salicylate concentration.
The differential diagnosis of a triple­mixed acid­base disturbance of increased anion gap acidosis, metabolic alkalosis, and respiratory alkalosis seen in salicylate toxicity is limited. Salicylates uncouple oxidative phosphorylation, which results in abnormal cellular energy production, and patients become dependent on anaerobic metabolism, resulting in accumulation of lactate. Thus, a significant salicylate poisoning will lead to an elevated serum lactate concentration, further broadening the differential diagnosis.
In clinical practice or at early stages of toxicity, this classic three­part acid­base disturbance may be difficult to appreciate. The differential is broad and includes (but is not limited to) sepsis, diabetic ketoacidosis, renal and hepatic failure, alcoholic ketoacidosis, and poisoning by iron, theophylline, caffeine, methanol, or ethylene glycol.
DIAGNOSIS
Diagnosis of salicylate toxicity is made by correlating a careful history, physical examination, and thoughtful ancillary testing. Supportive laboratory findings include an anion gap metabolic acidosis and elevated serum salicylate levels. The Done nomogram is misleading and can grossly underestimate toxicity; itshould not be used.
TOXICOLOGIC TESTING

A pitfall in treating salicylate toxicity is reliance on a single serum level. Significant toxicity has been reported to develop even in cases in which
 salicylates were undetectable on an initial assay approximately  hours after ingestion. Salicylate toxicity can evolve rapidly. In patients with moderate or severe poisoning, it is prudent to obtain serial serum salicylate concentrations approximately every  to  hours, until the concentrations
,26 are declining and the patient’s clinical status stabilizes. Enteric­coated or modified­release preparations are formulated to remain intact in the acidic gastric environment, dissolving in the alkaline intestinal fluids. Drug release is therefore primarily a function of gastric emptying, and peak levels
 may not be reached until up to  hours after ingestion in an overdose.
Commercially available tests for serum salicylate concentration are very accurate; the only reported significant interference has been with diflunisal (a

NSAID), which produces false­positive results for significantly high serum salicylate concentrations. Therapeutic salicylate concentrations are 150 to
300 micrograms/mL (or  to  milligrams/dL [1086 to 2172 micromole/L]). A pitfall is that units for measuring salicylate are not universal; measurement units can vary by institution, with the potential for patients to be mistakenly diagnosed as “salicylate toxic” if the physician mistakenly assumes the unit of measurement used.
ADDITIONAL ANCILLARY TESTING
Essential laboratory tests include electrolytes, glucose, BUN, and creatinine. Blood gases, chest and abdominal radiograph, ECG, CBC, serum calcium level, and urinalysis with urine pH determination should be obtained as clinically indicated. As in any ingestion, consider testing for acetaminophen as well, especially considering the number of combination products available in the market. Some enteric­coated medications are radiopaque and may
 be visible on an abdominal radiograph.
A normal anion gap does not exclude salicylate toxicity in patients with an unknown ingestion. Mixed ingestions that include aspirin and the timing of exposure can alter “classic” metabolic disturbances. A negative anion gap metabolic acidosis may be noted in salicylate toxicity due to aberrant
 reading of salicylate ions as chloride ions by analyzer electrodes.
TREATMENT
GENERAL MEASURES
Treatment priorities are (1) immediate resuscitation with stabilization of airway, breathing, and circulation; (2) correction of volume depletion and
,26 metabolic derangements; (3) GI decontamination; and (4) reduction in body salicylate burden. Salicylate absorption is reduced by the administration of activated charcoal both for regular and modified­release formulations. A single dose of activated charcoal,  to  grams/kg, should
,30,31 be administered to appropriate patients who have ingested potentially toxic amounts of salicylate. There are no convincing data to support the
 use of repeated or multiple doses of activated charcoal in salicylate overdose.
Patients with severe salicylate intoxication are usually significantly volume depleted, have serious acid­base disturbances, and require aggressive IV volume and electrolyte replacement. Careful assessment of a patient’s volume and electrolyte status is important, particularly in the elderly or in patients with a history of cardiac disease. Volume replacement is initially undertaken with normal saline or lactated Ringer’s with administration of an initial bolus of  mL/kg. The average adult who presents several hours after ingestion is dehydrated by at least  to  L.
ALKALINIZATION
,33
Systemic and urinary alkalinization are beneficial for salicylate toxicity, although the precise mechanism is debated. As initial fluid resuscitation is undertaken, patients should undergo treatment with sodium bicarbonate with a goal of a serum pH of approximately .5. Hypokalemia is common, and potassium should be added to the infusion after adequate urine output has been established. Serum potassium should be maintained in the .0 to .5 mEq/L range.

Urinary salicylate clearance is directly proportional to urine flow rate, but, more importantly, it is logarithmically proportional to urine pH. Urine alkalinization is more effective in enhancing salicylate elimination than forced diuresis. Urinary alkalinization also avoids the potential complication of fluid overload that is risked (particularly in those with marginal cardiac output or limited reserve) from the large IV volume given to increase urine flow.
,34
Urinary alkalinization should be considered as first­line treatment for patients with moderately severe salicylate poisoning.
Hydration and alkalinization should be initiated simultaneously in patients with severe salicylate intoxication. A common approach is to volume restore patients with normal saline or lactated Ringer’s to a target urine output of  to  mL/kg per hour. Concurrently, in a second IV line, an IV bolus of sodium bicarbonate (1 to  mEq/kg) is given followed by a continuous infusion (three ampules of either  or  mEq per ampule of sodium bicarbonate added to  L of 5% dextrose in water). Unless there is a contraindication, potassium should be added to the bicarbonate fluid as well. The infusion is run at two to three times maintenance and adjusted to maintain the urine pH >7.5 (Figure 189­1).
FIGURE 189­1. Management of salicylate poisoning. ABG = arterial blood gas; bicarb = bicarbonate; CMP = comprehensive metabolic panel; D W = 5% dextrose in
 water; ICU = intensive care unit; IVF = intravenous fluids; PT = prothrombin time; UOP = urinary output; VBG = venous blood gas.
In moderate and severe overdoses, the patient’s cardiopulmonary and neurologic status should be assessed frequently. Serum salicylate, urine pH,
,26 and electrolyte concentrations should be checked every  to  hours. Once the serum salicylate concentration peaks and begins to decrease on serial measurement, repeat measurement can be obtained every  to  hours.
OTHER MEASURES
Patients with salicylate­induced acute lung injury (noncardiogenic pulmonary edema) should be managed the same as patients with acute lung injury from other causes. Pulmonary edema begins to improve concomitantly with the lowering of serum salicylate concentrations. Aggressive efforts toward rapid elimination by hemodialysis may be beneficial in this subset of patients. Hemodialysis enables removal of salicylate without the volume infusion
 that accompanies sodium bicarbonate administration; hemodialysis thus avoids the risk of volume­mediated aggravation of lung injury.
When a patient with severe salicylate toxicity requires endotracheal intubation, mechanical ventilation, and sedation, it is important to maintain hyperventilation; ventilator settings should not be based on standard age­ and weight­based nomograms. Before intubation and mechanical ventilation, most patients with severe salicylate toxicity have a respiratory alkalosis. Controlling the ventilatory rate and volume to “normal” ranges produces a decrease in serum pH and causes a rapid shift of salicylate into the CNS. It is important to maintain respiratory alkalosis during mechanical ventilation. Use the minimal amount of safe sedation that allows a patient to continue over­breathing the ventilator. Consider one to two ampules (88 to 100 mEq) of bicarbonate bolus immediately prior to intubation as a basic buffer for the transient decrease in ventilation that occurs during rapidsequence induction intubation.
Hemorrhagic complications are rarely seen following single massive salicylate overdoses, but chronic administration of large doses may cause significant hypoprothrombinemia. Even in this circumstance, hemorrhage is rarely seen in clinical practice. When bleeding does occur, it rarely appears to be a contributing factor in mortality from salicylate toxicity. Patients with clinically significant bleeding should be treated with fresh frozen plasma. Observations in animals and humans indicate that administering large doses of vitamin K after the development of hypoprothrombinemia has little or no effect on the prothrombin time when serum salicylate concentration is high.
HEMODIALYSIS
Hemodialysis is considered the extracorporeal technique of choice for the treatment of serious salicylate toxicity because
,37 hemodialysis can correct acid­base and electrolyte abnormalities while rapidly reducing the body salicylate burden. The inherent delays in implementing hemodialysis underline the importance of early consideration of this intervention; thoughtful planning and prompt consultation with the nephrology service are strongly advised. Indications for hemodialysis include clinical deterioration or failure of improvement despite intensive supportive care, lack of success in alkalinizing serum and urine, renal insufficiency or failure, severe acid­base disturbance, altered mental status, and acute lung injury. Consider hemodialysis for salicylism requiring
 respiratory and ventilatory support.
Serum salicylate concentration should not be the sole determinant in the decision to initiate hemodialysis; however, patients with acute toxicity and serum salicylate concentrations >100 milligrams/dL (>7.2 mmol/L), patients with chronic toxicity with concentrations >60 milligrams/dL (>4.3 mmol/L), and symptomatic patients with lower serum salicylate concentrations should be considered candidates for hemodialysis. Consider the early use of hemodialysis in patients who are elderly, have chronically ingested aspirin, have altered mental status, have acidemia, or have comorbidities (e.g.,
 coronary artery disease or chronic obstructive pulmonary disease).
Emergency hemodialysis places a significant demand on the cardiovascular system, and hypotensive patients or those with underlying cardiac disease may not be able to tolerate the hemodynamic intensity of 4­hour hemodialysis treatments. A less demanding but more prolonged therapy, such as hemofiltration, hemodiafiltration, or sustained low­efficiency dialysis, may be used until hemodialysis can be tolerated. Once initiated, extracorporeal elimination techniques should be continued until the serum salicylate level is <20 milligrams/dL (<1.4 mmol/L).
DISPOSITION AND FOLLOW­UP
A patient may be discharged from the ED once it can be determined that the patient had an inconsequential salicylate overdose; this requires demonstration of serial declining salicylate levels. Patients who have overdosed on enteric­coated or modified­release preparations of aspirin should be treated regardless of initial serum salicylate concentrations and be observed for approximately  hours with serial serum salicylate measurements
 until a declining level is confirmed. Salsalate overdoses may warrant an even longer period of observation. Although the determination of serial salicylate concentrations offers valuable information regarding the effectiveness of the treatment implemented, it is not a substitute for clinical evaluation of a patient, and management decisions should not be solely based on a particular serum salicylate concentration. Early consultation with a clinical toxicologist or the regional poison control center is recommended.


