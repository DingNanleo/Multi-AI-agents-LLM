## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 132: Fluid and Electrolyte Therapy in Infants and Children
Melissa Chan; Paul Enarson
INTRODUCTION
This chapter provides a basic guide to parenteral rehydration, maintenance fluids, and management of common electrolyte abnormalities in children.
The most common cause of fluid and electrolyte abnormalities in children is dehydration. Dehydration results from a negative fluid balance due to decreased intake, increased output (renal, GI, or insensible losses from the skin or respiratory tract), or disease states such as burns, sepsis, or diabetes. Negative fluid balance can occur in the intracellular fluid or extracellular fluid compartments and may be accompanied by derangements in electrolytes. Table 132­1 lists some of the common causes of dehydration. Common signs of dehydration are listed in Table 132­2, and a validated clinical scoring system predicting the need for parenteral rehydration is provided in Table 131­6. TABLE 132­1
Causes of Dehydration in Children
Decreased Intake:
Voluntary or involuntary
Anatomic or pathologic diseases (pharyngitis, stomatitis, cleft lip/palate, facial dysmorphism, airway obstruction)
Neurologic diseases (meningitis, encephalitis, brain tumor, seizures)
Febrile illnesses
Increased Output:
Insensible losses (fever, heat, respiratory diseases, diaphoresis, thyroid disease, cystic fibrosis)
GI losses (vomiting, diarrhea)
Renal losses:
Osmotic (DKA, acute tubular necrosis)
Nonosmotic (renal diseases, electrolyte disturbance, diabetes insipidus)
Sodium losing (adrenal disease, diuretics, kidney disease, pseudohypoaldosteronism)
Systemic Diseases:
Moderate to severe burns
Ascites
Respiratory disease
Peritonitis: medical or surgical with third spacing
Anaphylaxis
Abbreviation: DKA = diabetic ketoacidosis.
TABLE 132­2
Clinical Guidelines for Assessing Dehydration in Children

Chapter 132: Fluid aNndo nEele tcot rMoliyntiem Tahl eDreahpyyd irna Itniofann (t<s 3a%nd ChSildormene, (Mmeilldis stoa mChoadne;r aPtaeu) lD Eenhayrdsroantion (3% to Severe Dehydration (>9%P alogses  / 
. Terms of Use * Privacy Policy * Notice * Accessibility loss of body weight) 9% loss of body weight) of body weight)
Mental Well, alert Fatigued, restless, irritable Apathetic, lethargic, unconscious status
Thirst Normal, slight increase, or refusing fluids Increased, eager to drink Very thirsty or too lethargic to indicate
Heart rate Normal Normal to increased Tachycardic with bradycardia in severe cases
Blood Normal Normal Normal to reduced pressure
Pulse Normal Normal to reduced Weak, thready quality
Breathing Normal Normal to tachypneic Deep
Eyes Normal Slightly sunken orbits Deeply sunken orbits
Tears Present Decreased Absent
Mucous Moist Dry Parched membranes
Anterior Normal Sunken Sunken fontanelle
Skin turgor Instant recoil Recoil in <2 s Recoil in >2 s
Capillary Normal Prolonged 1–2 s Prolonged >2 s refill
Extremities Warm Cool Cold, mottled, cyanotic
Urine Normal to decreased Decreased (<1 mL/kg/h) Minimal (<0.5 mL/kg/h) output
Courtesy of Stephen Freedman, MD, and Jennifer Thull­Freedman, MD.
PATHOPHYSIOLOGY
Infants and children are particularly susceptible to dehydration for a number of developmental and physiologic reasons. They are dependent on caretakers to provide oral fluids and therefore cannot regulate their intake. In addition, young children and infants have increased fluid requirements and are at risk of increased fluid losses compared to adults and older children. Basal metabolic rates are highest in young children, peaking at  months of age and gradually decreasing starting at  years of age. Infants also have a higher turnover rate for water. Total body water as a percentage of body weight decreases from 70% in a term infant (75% to 80% in premature infants) to 60% at  year of age, remaining at this percentage until
 puberty. The high percentage of total body water, coupled with a decreased ability to control water loss (e.g., insensible losses from larger surface area–to–body ratio and faster respiratory rate) and a decreased ability to concentrate the urine, predispose infants to dehydration. Furthermore, young children are more prone to hypermetabolic states, such as high fever, which also increases the need for free water. Fever increases the basal
 metabolic rate by 13% for each degree above .8°C.
Because sodium and water are tightly regulated together, dehydration is often described in relation to serum sodium concentrations. Children can develop isonatremic (isotonic) dehydration (sodium level of 135 to 145 mEq/L), hyponatremic (hypotonic) dehydration (sodium level of <135 mEq/L), or hypernatremic (hypertonic) dehydration (sodium level of >145 mEq/L). Isonatremic dehydration is the most common form of dehydration.
Isonatremic (isotonic) dehydration occurs when the fluid sodium losses are proportionate in the intracellular fluid and extracellular fluid compartments. Hyponatremic (hypotonic) dehydration occurs when fluid that is lost contains proportionately more sodium than blood, which leads to osmotic shifts of free water from the intracellular fluid to the extracellular fluid compartments. Hypernatremic (hypertonic) dehydration occurs when the fluid lost contains less sodium than the blood, which causes extracellular free water to move into the intracellular fluid space.
CLINICAL FEATURES
HISTORY
Suspicion of fluid or electrolyte disorders can often be raised through a properly taken history. Ask about symptoms (what they are, when they started, where they started; e.g., was the child in a hot environment), whether fever is present, whether the child is tachypneic, and prior treatment. For breastfeeding infants, inquire about frequency of feeds, whether the mother feels she has good milk production, and whether the infant is feeding or engaged in nonnutrient sucking for comfort. If not breastfeeding, ask what type of fluid has been given, because hypotonic fluids (e.g., water) are often used during illnesses and increase the risk of hyponatremia. If the infant is bottle­fed, ask whether the formula is premixed or made from powder; hypernatremia or hyponatremia can result from inappropriately prepared formula. Questions surrounding output aid in assessing whether replacement of losses has been adequate; excess output results from vomiting or diarrhea (quantify the frequency and volume if possible). Assess urine output by asking how often the child is urinating or the number of wet diapers if the child is not yet toilet trained. Inquire about volume status by asking about tear production, the presence or absence of sweat, and the child’s general appearance and mental status: is the child increasingly irritable or lethargic? Has the parent noticed a change in the skin (cyanotic, pale, mottled)? Most important, if known, is a change in weight,
 because weight loss is the gold standard for assessment of volume status. In addition to the specific questions, ask about signs or symptoms of infection, recent travel, sick contacts, and underlying chronic disease, which may point to a specific cause of dehydration. Children are at risk for accidental ingestion of toxins or plants, many of which can cause vomiting and lead to electrolyte disturbances.
PHYSICAL EXAMINATION
Physical findings related to individual electrolyte disorders are discussed in relation to specific electrolyte disorders below. In general, children with dehydration demonstrate a spectrum of physical findings ranging from a normal exam if dehydration is mild, to hypovolemic shock if dehydration is severe. Table 131­6 presents a simplified and validated clinical scoring system for dehydration. Tachycardia is an early sign of dehydration as the body compensates for a decreased circulatory volume. Tachycardia can present with normal blood pressure with or without signs of shock (compensated shock) but may be accompanied by hypotension (uncompensated shock) in severe dehydration. Tachypnea may also be noted as metabolic acidosis develops in moderate to severe dehydration. Note the mental status and the presence of lethargy or hypotonia, because these suggest severe dehydration or electrolyte abnormalities. In infants, the quality of the fontanelle (flat or sunken) may aid in assessment of hydration status, along with the presence or absence of tears when crying; assess the mucous membranes for cracked, dry lips or decreased saliva in mouth, and the temperature, color, and turgor of the skin (cool, mottled, cyanotic, decreased elasticity), as well as capillary refill time, which should be less then  seconds when normal. Finally, note the character of the pulses because diminished pulses may also reflect significant dehydration.
LABORATORY EVALUATION
Laboratory testing for individual electrolyte disorders is discussed individually below. Routine laboratory testing for assessing dehydration alone is generally not required, and several studies have found a lack of correlation between laboratory values and degree of dehydration based
,5 on percent weight lost. Measure serum electrolytes if IV insertion is required for rehydration and signs of electrolyte disturbance are present, or if electrolyte abnormalities are expected due to certain underlying medical conditions (e.g., diabetic ketoacidosis or congenital adrenal hyperplasia).
Perform a bedside glucose test in any child presenting with altered level of consciousness, and rapidly correct hypoglycemia (see
Chapter 146, “Metabolic Emergencies in Infants and Children”).
INITIAL TREATMENT OF DEHYDRATION
Three main modalities exist for rehydration in children: oral, nasogastric, and parenteral. Treatment at each level of dehydration is discussed below and summarized in Table 132­3, and a detailed discussion of the treatment of mild to moderate dehydration is presented in Chapter 131, “Vomiting,
Diarrhea, and Dehydration in Infants and Children.”
TABLE 132­3
Treatment for Mild, Moderate, and Severe Dehydration
Mild Moderate Severe
Primary phase PO* PO* IV†, IO, NG
Secondary phase (if primary phase fails) NG/IV ‡
NG/IV IO
Central line
Tertiary phase (after rehydration to ensure ability to maintain oral intake PO* PO* ± PO* after initial IV/IO rehydration
—optional)
Laboratory studies None Optional# Electrolytes, BUN, creatinine, calcium, glucose levels; urinalysis
Discharge criteria Appears clinically well, alert, and orientated
Vital signs within normal limits for age
Urine output during hydrating period
Intake is equal or greater to ongoing losses
Treatment failure Admit or place in observation unit
*PO: Use dilute apple juice or patient­preferred fluid or a commercial rehydration solution such as Pedialyte® or Enfalyte® or WHO reduced­osmolality ORS.
Rehydrate with  mL (1 tsp) every 2–3 min. Increase based on patient tolerance; aim for 50–100 mL/kg replacement plus  mL/kg per stool and  mL/kg per emesis episode.
†IV (severe dehydration):  mL/kg over 5–30 min (NS or lactated Ringer’s solution). Aim for 60–100 mL/kg in the first hour. Contraindications include some forms of cardiac disease (e.g., cardiomyopathy).
‡
IV NS  mL/kg over 20–30 min, repeat as needed; NG oral rehydration solution at a rate of 10–20 mL/kg/h.
#Perform laboratory testing based on dietary history or disease state.
Abbreviations: NG = nasogastric; NS = normal saline; ORS = oral rehydration salts; WHO = World Health Organization.
,6
For children unable to tolerate oral rehydration, nasogastric hydration is effective, even in vomiting patients. In a large study comparing nasogastric hydration versus IV hydration over  hours, subjects in the nasogastric­treated group had fewer complications, achieved resolution of ketonuria more
 often, and had greater reduction in specific gravity than IV­treated subjects. Nasogastric treatment is more cost effective than IV treatment.
MODERATE AND SEVERE DEHYDRATION
The child unable to tolerate oral/nasogastric rehydration therapy or with severe dehydration requires prompt fluid resuscitation with large volumes of
 fluid over a short period of time (Table 132­4). Give  mL/kg boluses over  to  minutes repetitively until hemodynamics stabilize. Up to  mL/kg
 or more may be required in the first hour, unless contraindicated based on underlying disease. Use an isotonic solution such as .9% saline or a
 lactated Ringer’s solution during this resuscitation phase.
TABLE 132­4
IV Rehydration for Moderate to Severe Dehydration
Degree of Replacement of Ongoing Losses After Initial
IV Rehydration
Dehydration Rehydration
Severe with  mL/kg .9% saline bolus over  min, repeated until 5–10 mL/kg .9% saline or 5% dextrose in .9% saline uncompensated shock hemodynamically stable for each watery diarrheal stool and
Moderate to severe  mL/kg .9% saline bolus over  h followed by 5% dextrose in  mL/kg .9% saline or 5% dextrose in .9% saline for without signs of shock .9% saline at 1–2× maintenance rate for  h each emesis
For patients with moderate dehydration requiring parenteral fluids, there is no advantage of rapid or ultrarapid (50 to  mL/kg in  hour) hydration over standard hydration with  mL/kg over  hour, and a blinded randomized trial found increased hospitalization rates among those receiving
 ultrarapid hydration. Furthermore, a study of fluid resuscitation among dehydrated children in Africa found that aggressive bolus fluid resuscitation
 was associated with increased mortality.
After initial volume expansion, continue replacement with either normal saline or 5% dextrose in .9% normal saline. Use clinical judgment, because there is no strong evidence to recommend one fluid over the other, although dextrose­containing fluids help clear ketones in the patient who has not
,13 been eating or drinking.
MAINTENANCE TREATMENT
Caloric expenditure and therefore fluid requirements can be estimated from body surface area, which is relatively large in infants in comparison with older children and adults. However, in the ED, weight is a sufficiently accurate value for calculating fluid requirements. The primary formula for daily fluid requirements is calculated as follows:
For the first  kg: 100 mL/kg/d (4 mL/kg/h)
For the second  kg:  mL/kg/d (2 mL/kg/h)
For each kg >20 kg:  mL/kg/d (1 mL/kg/h)
For example:
A 10­kg baby requires: 100 mL ×  kg, or a total of 1000 mL/d.
A 20­kg child requires: (100 mL ×  kg) + (50 mL ×  kg) = 1500 mL/d.
A 40­kg child requires: (100 mL ×  kg) + (50 mL ×  kg) + (20 mL ×  kg) = 1900 mL/d.
Electrolyte requirements remain constant throughout childhood and can be estimated by body weight. All infant formulas contain sufficient electrolytes to satisfy these requirements, as do the commercially available oral rehydration solutions such as Pedialyte® (see Table 131­9). The requirement is  to  mEq/kg/d for sodium and  mEq/kg/d for potassium.
Because hyponatremia is the most common intragenic complication of IV fluid therapy, it is important that isotonic solutions be
,15 used as maintenance fluid, such as normal saline with 5% dextrose. An exception is during the neonatal period. Although there is little evidence as to which maintenance fluids should be used early in life, neonates have immature kidneys and higher glucose requirements compared to older infants and children. Controversy exists on the best maintenance fluids in the first few days of life. The National Institute for Health and Care
Excellence guidelines recommend using 5% or 10% dextrose in normal saline for all neonates from birth onward unless respiratory distress syndrome, meconium aspiration, or hypoxic ischemic encephalopathy is present. If any of these are present, give no sodium (e.g., 10% dextrose in water), until the
 postnatal diuresis with weight loss occurs, typically before day  of life. Others recommend using salt­free fluids in all neonates until after the
 postnatal diuresis occurs.
DISORDERS OF SODIUM
Table 132­5 outlines disease states associated with disruption in serum sodium levels and total body water (volume).
TABLE 132­5
Conditions Altering Serum Sodium and Total Body Water Balance
Total Body Water (volume) Hypernatremia Hyponatremia
Increased Excessive saline infusion Congestive heart failure
Cirrhosis
Nephrotic syndrome
Advanced renal failure
Normal Hypertonic saline infusion SIADH
Bicarbonate intoxication Primary polydipsia
Salt poisoning Exercise­induced
Hyperaldosteronism Low solute intake
Renal osmostat
Hypothyroidism
Glucocorticoid deficiency
Nephrogenic SIADH
Decreased Cutaneous losses Diuretics
Sweating Renal losses
Radiant warmers Interstitial nephritis
Phototherapy Mineralocorticoid deficiency
Burns Burns, heat illnesses (exhaustion/stroke)
Inadequate intake Ascites
Improperly prepared formula Cystic fibrosis
GI losses
Vomiting
Nasogastric suctioning
Diarrhea
Osmotic stool softeners
Renal free water losses
Diabetes insipidus
Increased osmoles (diabetes mellitus, mannitol)
Chronic kidney disease
ATN (if polyuric)
Postobstructive diuresis
Abbreviations: ATN = acute tubular necrosis; SIADH = syndrome of inappropriate secretion of antidiuretic hormone.
HYPONATREMIA
Hyponatremia is a serum sodium level <135 mEq/L. First determine if a low sodium value is a true value by relating the sodium value to the osmolarity.
If hyponatremia occurs in a hyperosmolar state (i.e., >290 mOsm/kg), this suggests an osmotically active solute in the plasma such as excess glucose or
 alcohol. If hyponatremia occurs in the presence of normal osmolarity (275 to 290 mOsm/kg), this is likely due to hyperlipidemia or hyperproteinemia.
In such cases, correct the underlying disorder rather than the serum sodium level. When hyponatremia occurs in a hypo­osmolar state (<275 mOsm/kg), this is likely due to an excess of free water or loss of sodium. The most common causes of hyponatremia seen in the ED are GI losses and water intoxication caused by ingestion of hypotonic replacement fluids, especially during infancy.
Signs and symptoms of hyponatremia depend on the serum sodium level and the speed at which the sodium level falls. Symptoms primarily involve the CNS, as free water moves from the extracellular to intracellular space, and the musculoskeletal system. Neurologic symptoms include nausea, vomiting, headache, mental status changes, altered consciousness, diminished reflexes, hypothermia, pseudobulbar palsy, and seizures.
Musculoskeletal symptoms include weakness, muscle cramps, and lethargy.
Although patients may be only mildly symptomatic with sodium levels as low as 120 mEq/L if the low level is chronic (>48 hours), symptoms usually occur with an acute drop in serum sodium level below 120 mEq/L. Without appropriate treatment, complications include respiratory failure, seizures, and death.
Treatment depends on the stability of the patient and associated symptoms. General guidelines are presented in Table 132­6. Take special care to avoid rapid shifts in sodium levels. Although hyponatremia itself can have dire consequences, rapid correction can cause severe demyelination of
 brainstem neurons. Therefore, correct hyponatremia slowly and in a controlled manner (Table 132­6). The exception to this is in the setting of severe neurologic symptoms, such as confusion, altered level of consciousness, or seizures, typically with sodium level <120 mmol/L. When this occurs, a
 rapid, controlled increase in sodium level is required until neurologic symptoms resolve or a sodium level of 120 mmol/L is achieved.
TABLE 132­6
Treatment of Hyponatremia
Symptoms Treatment* If hypovolemic and Correct instability with NS boluses (20 mL/kg over  min followed by reassessment after each bolus) hemodynamically unstable
Asymptomatic Correct deficit to normal over  h mEq Na required = [(Na+ desired) – (measured Na+)] × (0.6 × weight in kg)
Neurologic symptoms (altered 1–2 mL/kg/h of 3% sodium chloride until asymptomatic or Na level >120 mEq/mL, then increase Na level .5 mEq/mL/h mental status, seizures) (not to exceed increase of  mEq/mL in first  h or  mEq/mL in first  h)
*Does not include maintenance requirements and ongoing losses.
.9% NS = .15 mEq Na/L; 3% saline = .5 mEq Na/L
Abbreviation: NS = normal saline.
For euvolemic hyponatremia, after correction of serum sodium level, begin water restriction and treat the underlying disorder. For hypervolemic hyponatremia (edema), start sodium and water restriction and administer diuretics if needed to treat the clinical condition (e.g., congestive heart failure).
HYPERNATREMIA
Hypernatremia is a serum sodium level >145 mEq/L. Hypernatremia generally indicates a lack of total body water in relation to total body solute and often occurs as a result of dehydration (loss of water through the GI tract, kidney, or insensible losses), but may also occur secondary to excessive sodium intake (e.g., inadequate water intake or hypertonic solution intake) (Table 132­7). Diarrhea is the most common cause in children. Other diseases to consider include renal disease and diabetes insipidus. Children are at risk for hypernatremia if free water is limited or if formula is mixed improperly. Mild hypernatremia is commonly found in ill children, particularly infants with gastroenteritis. If mild, it is usually asymptomatic and corrects with treatment of the underlying cause. Serum sodium levels of >160 mEq/L require immediate attention due to the potential for serious complications and permanent neurologic sequelae, including intellectual deficits, seizure disorder, or other neurologic impairments. Conversely, patients who have a sodium level of <160 mEq/L and receive treatment typically have symptoms that are relatively mild and self­limited.
TABLE 132­7
Treatment of Hypovolemic or Euvolemic Hypernatremia
Condition Treatment* If hypovolemic and hemodynamically unstable Correct instability with NS boluses (20 mL/kg boluses followed by reassessment after each bolus)
Once hemodynamically stable and Correct deficit to normal over  h hypovolemic or euvolemic hypernatremia Free water deficit (mL) =  mL × body weight (kg) × [desired change in serum sodium mEq/L (mmol/L)]
Subtract bolus fluids given from deficit; correct remaining deficit giving half of deficit over first  h and remainder over the next  h (see text for monitoring criteria)†
*Does not include maintenance requirements and ongoing losses.
†Tonicity of fluid used for correction will depend on initial severity of hypernatremia.
Abbreviation: NS = normal saline.
Signs and symptoms of hypernatremia result from cellular dehydration as free water moves from the intracellular to extracellular space and include mental status changes, muscular weakness, ataxia, tremors, hyperreflexia, seizures, unresponsiveness, intracerebral hemorrhage, permanent neurologic dysfunction, and death. In addition, when extracellular fluid hypertonicity develops, brain intracellular osmolar contents increase to prevent or minimize cell shrinkage. In severe hypernatremic dehydration, neurologic findings may include any of the following: increased peripheral tone with brisk reflexes, muscle weakness, high­pitched cry, nuchal rigidity, myoclonus, asterixis, chorea, altered level of consciousness, or
,21 seizures.
Treatment consists of restoration of intravascular volume while decreasing the serum sodium level. Correct serum sodium gradually to avoid cerebral edema and associated central pontine myelinolysis (Table 132­7). Closely monitor serum sodium levels every hour initially to ensure that the level is reduced no faster than  mEq/L/h and no more than  mEq/L in the first  hours. This may require more than

 hours for complete correction. Monitor urine output given the risk of acute tubular necrosis. Correct underlying causes. Hypervolemic hypernatremia may require dialysis if sodium levels cannot be decreased without volume overload. Dialysis may also be required for hypernatremia of any type if the initial serum sodium is >180 mmol/L.
DISORDERS OF POTASSIUM
HYPOKALEMIA
Hypokalemia occurs when the serum potassium level falls to <3.4 mEq/L and most commonly occurs secondary to profuse vomiting and/or diarrhea.
Other common causes include therapy with loop or thiazide diuretics, mineralocorticoids, or laxatives and diabetic ketoacidosis. In diabetic ketoacidosis, profound hypokalemia can result from osmotic diuresis, although in the face of the hydrogen–potassium shift that accompanies acidemia, serum levels may be normal or falsely elevated. Uncommon causes of hypokalemia include renal tubular acidosis, Bartter’s or Gitelman’s syndrome, Cushing’s syndrome, and familial hypokalemia­induced paralysis.
In most cases, hypokalemia occurs slowly, and thus patients are asymptomatic. Clinical signs tend to reflect the rate of fall of serum potassium rather than the absolute level. However, severe potassium depletion can result in skeletal muscle weakness, ileus, and cardiac conduction disturbances. A prominent ECG manifestation is the U wave.
Treatment is generally with oral replacement with potassium,  to  mEq/kg/d in two or three divided doses (maximum  mEq/dose). However, dehydration and magnesium abnormalities must also be corrected to maintain normal potassium levels. If IV therapy is necessary, potassium .2 to .3 mEq/kg/h is generally adequate. In extremely urgent situations, such as hypokalemia­induced respiratory insufficiency or cardiac manifestations,
 potassium .5 mEq/kg/h can be administered (maximum  mEq/dose), with continuous ECG monitoring. If potassium chloride infusion concentration exceeds  mEq/L, the infusion will need to run through a central line, because potassium is a vein irritant. In diabetic ketoacidosis, potassium repletion should begin early in the course of therapy, because diuresis­induced depletion can result in profound hypokalemia as acidosis is corrected and serum potassium shifts into cells (see Chapter 147, “Diabetes in Children”).
HYPERKALEMIA
Hyperkalemia is a serum potassium level of >5.5 mEq/L. In infants and children, a laboratory finding of hyperkalemia is most commonly due to hemolysis from phlebotomy and does not reflect serum levels. However, do not assume hyperkalemia is false; repeat the potassium level, reexamine the patient, obtain an ECG, and place the child on a cardiac monitor. Some common causes of true hyperkalemia include renal failure, rhabdomyolysis, burns, heatstroke, trauma, tumor lysis syndrome, hemolytic anemia, use of potassium­sparing diuretics, and adrenal corticoid insufficiency (e.g.,
Addison’s disease, salt­wasting congenital adrenal hyperplasia). Metabolic acidosis can result in hyperkalemia due to hydrogen–potassium shifts.
Cardiac conduction delay is the most common manifestation of hyperkalemia and is potentially life threatening. Peaked T waves are the first manifestation, followed by prolonged PR interval and then widening of the QRS complex, an ominous finding that can precede the characteristic “sine wave” pattern, leading to ventricular dysrhythmias and asystole. Any patient with ECG changes requires emergent therapy to reverse cardiac conduction toxicity.
Treatment is detailed in Table 132­8. Asymptomatic patients with normal ECG findings usually do well with therapy to enhance potassium excretion.
In patients with renal failure with a gradual rise in serum potassium levels, sodium polystyrene sulfonate can be given. It is a resin that exchanges sodium for potassium at a 1:1 ratio and therefore enhances potassium excretion and can be administered orally or by enema. A dose of  gram/kg lowers the serum potassium level by up to .2 mEq/L. When administered orally, it is usually given with a cathartic to speed transit time through the GI tract. Hypernatremia and volume overload are potential complications. In patients with severe hyperkalemia from renal failure, dialysis is usually necessary, but emergency correction of potassium must be done first (Table 132­8). In patients with hyperkalemia secondary to metabolic acidosis,
 normalization of serum pH usually restores serum potassium to normal levels.
TABLE 132­8
Treatment of Hyperkalemia
Purpose Agent Dose
Increase Calcium gluconate 10% (10% calcium 100 milligrams/kg (1 mL/kg/dose) IV at rate not to exceed 100 milligrams/min; maximum  cardiac gluconate contains 100 milligrams/mL) grams/dose. Can be administered peripherally or centrally. May be repeated in  min if necessary.
stability
Calcium chloride 10% (10% calcium  milligrams/kg (0.2 mL/kg/dose) IV at rate not to exceed 100 milligrams/min; maximum  chloride contains 100 milligrams/mL) gram/dose.
Calcium chloride must be given via central line or IO due to vein sclerosis. May be repeated in  min if necessary.
Decrease Albuterol (Ventolin) .5% solution .5–5 milligrams via nebulization; every  min as needed.
potassium
Sodium bicarbonate If acidotic (pH <7.3), 1–2 mEq/kg IV/IO; typical adult dose 50–100 mEq. Onset of action is in minutes. May be repeated every 5–10 min as needed.
Regular insulin .1 unit/kg IV in  mL/kg 10% dextrose in water, .5 gram/kg IV over  min; check glucose level every  min; onset of action,  min. May be repeated every 30–60 min.
Furosemide If renal function normal and patient is not hypovolemic, .5–1 milligram/kg/dose IV to a maximum of  milligrams/dose. Peak effect seen at  min.
Sodium polystyrene sulfonate  gram/kg to a maximum of  grams orally, via nasogastric tube, or rectally. Onset of action, 1–2 h orally, <30 min rectally.
DISORDERS OF CALCIUM
HYPOCALCEMIA
Hypocalcemia is a serum calcium level <8 milligrams/dL (2 mmol/L) or ionized calcium level <4.4 milligrams/dL (1.1 mmol/L); however, levels must be adjusted for albumin levels and pH of the blood. Low calcium levels tend to result from hypoparathyroidism or end­organ resistance to parathyroid hormone. True hypoparathyroidism can be idiopathic, be associated with DiGeorge’s syndrome, occur after thyroid surgery, and/or be associated with magnesium deficiency. End­organ resistance to parathyroid hormone is most commonly associated with vitamin D deficiency. The most common causes are dietary deficiency and chronic renal failure. Young infants fed cow’s milk, which is high in phosphate, can develop severe hypocalcemia.
Another common cause of hypocalcemia is hyperventilation: the decreased partial pressure of carbon dioxide results in an acute respiratory alkalosis that rapidly decreases levels of ionized calcium.
Clinical manifestations of hypocalcemia include muscle weakness, vomiting, and irritability. Infants may simply appear “jittery.” In severe cases, tetany, laryngospasm, carpopedal spasm, and seizures can occur. Carpopedal spasm is especially common in children with hyperventilation syndrome. The most characteristic ECG abnormality is a prolonged QT interval. Investigation of hypocalcemia includes laboratory measurement of total serum and ionized calcium, phosphate, total protein and albumin, parathyroid hormone, BUN, and creatinine levels. Urine calcium level should also be collected.
If a neonate is seen with hypocalcemia, a chest radiograph should be done to look for a thymic shadow in infants and young children. If the thymus is not present, consider DiGeorge’s syndrome.
Treatment is the administration of IV calcium (Table 132­9). Give calcium gluconate 10% in a dose of 100 milligrams/kg at a rate not to exceed 100 milligrams/min, with continuous ECG monitoring. Following initial correction, a calcium infusion may be required to maintain calcium levels. Further
 management depends on the cause.
TABLE 132­9
Treatment of Disorders of Calcium and Magnesium
Treatment Comments
Calcium
Hypocalcemia 10% calcium gluconate IV, 100 milligrams/kg, at a rate <100 milligrams/min Continuous ECG monitoring
Hypercalcemia Hydrate with twice maintenance fluids, furosemide 1–2 milligrams/kg IV to a maximum of  milligrams Treat underlying cause
Magnesium
Hypomagnesemia 10% magnesium sulfate, 25–50 milligrams/kg over  min
Hypermagnesemia Hydration, diuresis 1–2 milligrams/kg IV furosemide to a maximum of  milligrams; or 10% calcium gluconate IV, .5 mL/kg
HYPERCALCEMIA
Hypercalcemia is a serum calcium level of >11 milligrams/dL and most often results from increased bone resorption. Probably the most common cause in children is malignancy involving the lymphoreticular system. Less common causes include vitamin A or D intoxication, hyperparathyroid syndromes, hyperthyroidism, adrenal insufficiency, and pheochromocytoma.
Clinical manifestations include hypotonia, fatigue, irritability, anorexia, vomiting, and constipation. Affected children may be clinically dehydrated and complain of polyuria and/or polydipsia. An ECG may reveal bradycardia and a shortened QT interval.
The laboratory evaluation of hypercalcemia includes measurement of total serum and ionized calcium levels, a CBC, and evaluation of total protein and albumin and alkaline phosphatase levels. An evaluation of the vitamin D level may also be indicated, depending on the patient’s medical history.
Treatment (Table 132­9) depends on the cause. Acutely, patients with functioning kidneys can be treated with aggressive IV hydration (e.g., twice
 maintenance), with or without furosemide,  to  milligrams/kg IV, to a maximum of  milligrams. Then, treat the underlying cause.
DISORDERS OF MAGNESIUM
HYPOMAGNESEMIA
Serum magnesium levels are age independent and range from .5 to .2 mEq/L. Dietary magnesium is absorbed in the intestine and reabsorbed in the urine, particularly in states of decreased intake. Serum levels of <1.5 mEq/L are considered low and usually result from GI or renal losses as well as some endocrine disturbances. Diarrhea, malabsorption, short gut, and fistulas are potential mechanisms of GI magnesium loss, but iatrogenic causes of renal loss (osmotic diuretics, parenteral fluids, antibiotics, and chemotherapeutics) predominate. Hypercalcemia may cause magnesium loss as well as hypophosphatemia. Hypomagnesemia may also occur in diabetes, disorders of the parathyroid glands, and primary hyperaldosteronism.
Clinical manifestations are similar to those seen with hypocalcemia: muscle spasms, weakness, or even atrophy may occur; CNS symptoms include ataxia, abnormal movements, nystagmus, and seizures and occur with very low magnesium levels. Cardiac changes include prolonged PR and QT intervals and may predispose to arrhythmias such as torsades de pointes.
Treatment (Table 132­9) depends on the underlying cause. Include magnesium in parenteral or enteral nutritional liquids in chronically ill children. In symptomatic patients (e.g., those with seizures, arrhythmias), give IV magnesium sulfate,  to  milligrams/kg administered as a 10% solution over  minutes, and repeat every  to  hours as needed.
HYPERMAGNESEMIA
Hypermagnesemia is rare. Serum levels of >2.2 mEq/L are considered elevated. The most common cause is ingestion of exogenous magnesium, typically found in antacids and laxatives. Patients with renal dysfunction are at increased risk. Clinical manifestations include hypotension, loss of deep tendon reflexes, and respiratory failure. Cardiac manifestations include widening of the QRS, PR, and QT intervals.
Treatment (Table 132­9) is removal of exogenous sources and hydration accompanied by diuresis. Severe symptoms may be mitigated with IV calcium,
### .5 mL/kg delivered as calcium gluconate. Dialysis is effective in patients with renal failure.


