## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 52: Syncope
Venkatesh Thiruganasambandamoorthy; James Quinn
Content and Chapter Update: The Canadian Syncope Risk Score (CSRS) June 2021
The CSRS, and its supporting data, are presented in "Decision­Making and Risk Assessment." The CSRS is a tool to aid ED disposition decisions in patients with unexplained syncope, and in patients without clear evidence of a serious cause of syncope.
The chapter has also been updated to reflect additional information throughout.
INTRODUCTION AND EPIDEMIOLOGY
Syncope or fainting is a symptom complex consisting of a brief loss of consciousness associated with an inability to maintain postural tone that spontaneously resolves without medical intervention with the person returning to their baseline neurologic condition. Syncope accounts for approximately 1% to 2% of ED visits each year and 1% to 6% of hospital admissions.1–4 Over a lifetime, the prevalence of syncope ranges from .5% to 19%.1,5 Syncope in the preceding year is the best predictor of recurrence.6 It can affect the young and the old, with the elderly having the greatest morbidity.7Near syncope, a premonition of fainting without loss of consciousness, shares the same basic pathophysiologic process as syncope and carries the same risks.8–11
PATHOPHYSIOLOGY
The final common pathway of syncope is the same regardless of the underlying cause: about  seconds of complete disruption of blood flow or nutrient delivery to both cerebral cortices or to the brainstem reticular activating system, or reduction of cerebral perfusion by 35% to 50%. Most commonly, an inciting event causes a drop in cardiac output, which decreases oxygen and substrate delivery to the brain. Cerebral perfusion and consciousness are restored by the supine position, the response of autonomic autoregulatory centers, or restoration of a perfusing cardiac rhythm.
The causes of syncope are numerous (Table 52­1). The most common causes of syncope identified in the Framingham Heart Study were vasovagal (reflex mediated, 21%), cardiac (10%), orthostatic (9%), medication related (7%), neurologic (4%), and unknown (37%).5 Even with exhaustive patient evaluation, the cause remains unknown in about 18% to 40% of individuals.12,13 After ED investigation, the unknown proportion may be 50% to 60%. Diagnosis is important, because each diagnostic classification carries with it prognostic risk.14 Cardiac syncope doubles the risk of death, neurologic syncope increases the risk of death by 50%, and syncope of unknown cause increases the risk of death by 30%.5 Individuals with neurally mediated, reflex­mediated or vasovagal syncope have no increased risk of death,5 but patients with recurrent syncope have an increased risk of injury.15
TABLE 52­1
Causes of Syncope
Cardiac* Neural/Reflex Mediated
Structural cardiopulmonary disease Vasovagal
Valvular heart disease Situational
Aortic stenosis Cough
Tricuspid stenosis Micturition
Mitral stenosis Defecation
Cardiomyopathy Swallow
Pulmonary hypertension Neuralgia
Congenital heart disease Carotid sinus syndrome
Myxoma POTS

Pericardial disease Orthostatic hypotension (see text)
Chapter 52: Syncope, Venkatesh Thiruganasambandamoorthy; James Quinn 
. Terms of Use * Privacy Policy * NotPicseyc * h iAactrcicessibility
Pulmonary embolism Neurologic
Myocardial ischemia Transient ischemic attacks
Myocardial infarction Subclavian steal
Dysrhythmias Migraine16
Bradydysrhythmias
Medications (Table 52­2)
Short or long QT syndromes
Breath holding (children)*†
Stokes­Adams attack
Sinus node disease
Second­ or third­degree heart block
Pacemaker malfunction
Tachydysrhythmias
Ventricular tachycardia
Torsades de pointes
Supraventricular tachycardia
Atrial fibrillation or flutter
*See Chapter 130, “Syncope, Dysrhythmias, and ECG Interpretation in Children.”
†See Chapter 117, “Brief Resolved Unexplained Events.”
Abbreviation: POTS = postural orthostatic tachycardia syndrome.
CLINICAL FEATURES
CARDIAC­RELATED SYNCOPE
Patients with documented cardiac syncope have a 6­month mortality rate that exceeds 10%. Thus, a timely and thorough evaluation is warranted.5,13 The causes of cardiac syncope are divided into two categories: structural disease and dysrhythmias (Table 52­1). In both settings, the heart is unable to provide adequate cardiac output to maintain cerebral perfusion.
Syncope can occur if structural disease limits the heart’s ability to increase cardiac output to meet demand. Examples of structural cardiac disease associated with syncope include aortic stenosis, hypertrophic cardiomyopathy, pulmonary embolism, and myocardial infarction. Consider aortic stenosis as a structural cardiac cause of syncope in the elderly. The classic symptom constellation of aortic stenosis is chest pain, dyspnea on exertion, and syncope. Hypertrophic cardiomyopathy is characterized by a stiff noncompliant left ventricle, diastolic dysfunction, and outflow tract obstruction. Although it is the most common cause of sudden cardiac death in young adults, it may be first recognized in those >60 years old.17 Massive acute pulmonary embolism may cause syncope due to obstruction of the pulmonary vascular bed and reduction in cardiac output.18Acute myocardial infarction may cause syncope if myocardial dyskinesia reduces cardiac output. Individual chapters in the “Cardiovascular Disease” section of this text provide more discussion on structural cardiopulmonary disorders that may cause syncope.
Although both brady­ and tachydysrhythmias may lead to transient cerebral hypoperfusion (Table 52­1), there is no absolute high or low heart rate that will predictably produce syncope. Symptoms depend on the autonomic nervous system’s ability to compensate for a decrease in cardiac output, the heart’s structural ability to compensate, and the degree of underlying cerebrovascular disease. Dysrhythmias usually occur in patients with congenital or acquired structural conditions
(e.g., myocardial infarction, cardiomyopathy especially resulting in congestive heart failure) in which the conduction system is damaged or compromised. Such individuals are at high risk for arrhythmias and sudden death. Dysrhythmias may also occur in structurally normal hearts in patients with a primary electrolyte imbalance, as in hypomagnesemia (e.g., torsades de pointes) and in the familial disorders of Brugada syndrome, long or short QT syndromes, and catecholamine­associated polymorphic ventricular tachycardia. Syncope from dysrhythmias is typically sudden without prodromal symptoms.
VASOVAGAL AND NEURALLY OR REFLEX­MEDIATED SYNCOPE
Vasovagal syncope is the result of autonomic dysfunction that is reflex mediated or neurally mediated. It is associated with inappropriate vasodilatation, bradycardia, or both, as a result of inappropriate vagal tone that may follow sympathetic stimulation.19–21 A prodrome of lightheadedness, with or without nausea, pallor, and/or sweating, and an associated feeling of warmth may accompany vasovagal syncope. A slow, progressive onset with associated prodrome suggests vasovagal syncope. Vasovagal syncope may occur after exposure to an unexpected or unpleasant sight, sound, or smell; fear; severe pain; emotional distress; or instrumentation. It may also occur in association with prolonged standing or kneeling in a crowded or warm place. Situational syncope occurs during or immediately after coughing, micturition, defecation, or swallowing. Postural orthostatic tachycardia syndrome (POTS) is a poorly defined type of autonomic dysfunction characterized by orthostatic intolerance, with a number of different causes or associations. Most cases are diagnosed in women 13–50 years old.
Diagnosis is by tilt­table testing.
Carotid sinus syndrome is a type of reflex­mediated syncope associated with carotid sinus hypersensitivity, and it is characterized by bradycardia or hypotension.22,23 The carotid sinus is a baroreceptor located within the adventitia at the beginning of the internal carotid artery, at the carotid bifurcation. The carotid sinus responds to an increase or decrease in arterial stretching from changes in cardiac output or blood pressure.23A The term carotid body is often confused with the term carotid sinus. The carotid body is a 3­ to 5­mm chemoreceptor located in the adventitia of the bifurcation of the common carotid artery. The carotid body responds to pH, pO , and pCO by regulating physiologic responses to hypoxia, hypercapnia, and acidosis.24 sensitive receptors. The stimulation of an
  abnormally sensitive carotid sinus inadvertently or by external pressure may lead to two autonomic responses. Most commonly, there is bradycardia and a pause
(asystole) of >3 seconds. Less commonly, there is a vasodepressor response, leading to a marked decrease in systolic blood pressure of >50 mm Hg without a significant change in heart rate. Carotid sinus hypersensitivity is more common in men, the elderly, and those with ischemic heart disease, hypertension, or head and neck malignancies. Although some patients may demonstrate a hypersensitive carotid sinus response on provocative testing, unless this response culminates in syncope or recurrence of prodromal symptoms and unless it is associated with an inciting event, such as shaving or turning of the head, it cannot be definitely diagnosed as the cause of syncope. About 25% of patients with carotid sinus hypersensitivity have true carotid sinus syndrome with spontaneous symptoms.25
Consider carotid sinus hypersensitivity in older patients with recurrent syncope and negative cardiac evaluations.
ORTHOSTATIC SYNCOPE
Orthostatic syncope is suggested when postural hypotension (drop in systolic blood pressure of ≥20 mm Hg or diastolic blood pressure of ≥10 mm Hg) is associated with syncope or presyncope.23,26 When a person assumes an upright posture, gravity shifts blood to the lower part of the body, and cardiac output drops. This change triggers the healthy autonomic nervous system to increase sympathetic output and decrease parasympathetic output, increasing heart rate and peripheral vascular resistance, and thus increasing cardiac output and blood pressure.27,28 If the autonomic response is insufficient to counter the drop in cardiac output upon standing, decreased cerebral perfusion and syncope may follow. Syncope with postural hypotension due to dysfunction of the autonomic nervous system is termed neurogenic orthostatic hypotension.21 Symptom onset is usually within the first  minutes after assuming the upright posture, but may be more delayed in some patients.23 However, positive orthostatic changes have been documented in up to 40% of asymptomatic patients >70 years old and in about a quarter of those <60 years old, so orthostasis does not always result in syncope.20,29Many serious causes of syncope such as internal or external hemorrhage, sepsis, or intravascular volume loss from poor intake, vomiting, diarrhea, or diuretics may be associated with orthostatic changes, so consider potentially other life­threatening causes before attributing syncope to orthostasis and autonomic dysfunction, especially in the elderly.
PSYCHIATRIC DISORDERS
Psychiatric disorders are associated with up to 40% of those with vasovagal syncope and 37% to 62% of those with unexplained syncope.30–32 The most frequent psychiatric diagnoses associated with syncope are generalized anxiety disorder and major depressive disorder.33,34 A psychiatric cause for syncope should be one of exclusion, assigned only after organic causes have been excluded. Psychogenic pseudosyncope is a term reserved for patients with apparent loss of conscious without impaired cerebral perfusion. Eye closure during the event, long periods of apparent transient loss of consciousness, and increased heart rate and blood pressure are commonly seen in psychogenic pseudosyncope.23,35 Hyperventilation may be associated with panic disorder or generalized anxiety disorders and can lead to hypocarbia, cerebral vasoconstriction, and syncope.36
MEDICATION­INDUCED SYNCOPE
Medications may contribute to syncope by a variety of means, and a careful history and consideration are required (Table 52­2). The most common effect is worsening orthostasis.37
β­Blockers or calcium channel blockers may lead to a blunted heart rate response after orthostatic stress, and nitrates can cause venous pooling and vascular dilation. Diuretics may produce volume depletion. Some medications have proarrhythmic properties, especially as combination agents, increasing the concern for dysrhythmia as the cause of syncope.
TABLE 52­2
Drugs Commonly Implicated in Syncope
Erectile dysfunction drugs
Antihypertensives
β­Blockers
Cardiac glycosides
Diuretics
Antidysrhythmics
Antipsychotics
Antiparkinsonism drugs
Antidepressants
Phenothiazines
Nitrates
Alcohol
Cocaine
NEUROLOGIC DISORDERS ASSOCIATED WITH LOSS OF CONSCIOUSNESS
Neurologic causes of syncope are rare. To meet the definition of syncope, symptoms must be transient and with no persistent neurologic deficits. Patients with loss of consciousness with persistent neurologic deficits or altered mental status do not have true syncope. Such patients have alternate medical disorders, many of them life threatening (e.g., stroke, sepsis, overdose). Transient brainstem ischemia, vertebrobasilar atherosclerotic disease, or basilar artery migraine may result in a decrease in blood flow to the reticular activating system, leading to sudden, brief episodes of loss of consciousness. Loss of consciousness due to this mechanism is not only rare but also typically preceded by other signs or symptoms, such as diplopia, vertigo, focal neurologic deficits, or nausea.
Subclavian steal syndrome is a rare cause of brainstem ischemia. It is characterized by an abnormal narrowing of the subclavian artery proximal to the origin of the vertebral artery, so that with exercise of the ipsilateral arm, blood is shunted, or “stolen,” from the vertebrobasilar system to the subclavian artery supplying the arm muscles. Anatomically, narrowing is more common on the left. Physical examination may identify decreased pulse volume and diminished blood pressure in the affected arm.
Spontaneous subarachnoid hemorrhage may present as a cause of syncope, but is usually accompanied by other symptoms such as focal neurologic deficits, headache, or persistent altered mental status, removing it from the true definition of syncope. In this case, the mechanism for syncope is thought to be an increase in intracranial pressure with a decrease in cerebral perfusion pressure. That being said, syncope from any cause can result in head injury causing traumatic subarachnoid hemorrhage. See Chapter 166, “Spontaneous Subarachnoid and Intracerebral Hemorrhage,” for further discussion.
Seizure may be confused with syncope, because brief tonic­clonic movements are often associated with syncope. Distinguishing features of seizure over syncope include a previous history of seizure, confusion (postictal state) lasting more than several minutes, tongue biting, incontinence, or an epileptic aura.
PRINCIPLES OF EVALUATION
The diagnosis of syncope is clinical, with careful evaluation of the presentation and selected use of diagnostic tests. History is most important, and most diagnostic tests have low diagnostic yield and should be guided by the history and physical examination.41 The differential diagnosis is presented in Tables 52­1 and 52­2. The goal of ED evaluation is to identify any serious underlying conditions that caused the episode of syncope, and to identify patients at risk for immediate and future morbidity or sudden death. Patients presenting after near­syncope should be managed the same as patients with syncope.8–11 For patients with a specific diagnosis, the diagnosis directs the disposition plan. For patients without a specific diagnosis including those with a presumptive ED diagnosis of vasovagal or cardiac syncope, risk stratification can guide disposition and care. Risk stratification is based on a careful history, thorough physical examination, ECG interpretation, and additional testing as needed.
HISTORY
Obtain clinical history from the patient and any witnesses of the event. Begin with a detailed description of the events preceding the loss of consciousness, including patient position, environmental stimuli, strenuous activity, or arm exercise. Inquire about premonitory symptoms such as auras, headache, diplopia, vertigo, or focal weakness. Ask about chest pain and palpitations. Clarify the duration of loss of consciousness and symptoms occurring after regaining consciousness. Symptoms associated with syncope that should raise concern of an immediately life­threatening diagnosis include chest pain (acute myocardial infarction, aortic dissection, pulmonary embolism, aortic stenosis), palpitations (dysrhythmia), shortness of breath (pulmonary embolism, congestive heart failure), headache (subarachnoid hemorrhage), and abdominal or back pain (leaking abdominal aortic aneurysm, ruptured ectopic pregnancy). A sudden event without warning and events associated with exertion raise suspicion for a cardiac dysrhythmia or structural cardiopulmonary lesion.38 Ask about antecedent illness and alcohol ingestion or substance abuse. The past medical history should include questions regarding underlying structural heart disease, including congenital heart disease, valvular heart disease, coronary artery disease, congestive heart failure, pulmonary embolism and venous thromboembolism risk, and ventricular dysrhythmias. Document any prior history of syncope because patients with more than five syncopal episodes in  year could be more likely to have vasovagal syncope (autonomic dysfunction) or a psychiatric diagnosis than dysrhythmia as the cause.6,32,34 Record all medications, including over­the­counter medications such as laxatives. Patients aggressively dieting to lose weight may have electrolyte disturbances or may be taking amphetamine­like medications. The family history is important in regard to history of prolonged QT syndrome, dysrhythmias, sudden cardiac death, or other cardiac risks.
Pay special attention to patients presenting after falls or single­car motor vehicle crashes without apparent cause (frequently with a history of driving off the road), particularly if the patient is ≥65 years old, has a history of coronary artery disease, or has an abnormal ECG.39 Clinicians may become preoccupied by the trauma evaluation and miss the possibility of a syncopal event.
Many patients with syncope are mistaken as having suffered a seizure. Mild, brief, tonic­clonic activity (“convulsive syncope”) may accompany syncope of any etiology.
The two conditions do not share the same pathophysiologic mechanisms. A previous seizure disorder or premonitory and post event symptoms may assist in differentiation.40 A classic aura or postictal confusion and muscle pain indicate seizure, whereas characteristic prodromal symptoms of nausea and diaphoresis suggest reflex­mediated (vasovagal) syncope. Witness information of the event may also be useful. Witnessed head turning or unusual posture during the event is consistent with seizure. A prolonged postictal phase is more common with seizure.
PHYSICAL EXAMINATION
Signs of trauma without defensive injuries to the hands or knees may be due to a sudden event without warning, such as a dysrhythmia. Focus the physical examination on the cardiovascular and neurologic systems. Obtain blood pressure measurements in both arms. Consider aortic dissection or subclavian steal if blood pressures are unequal. Take orthostatic blood pressures after  minutes in the supine position. Repeat measurements after  and  minutes of standing. A symptomatic decrease of >20 mm Hg in the systolic pressure is considered abnormal, as is a decrease in pressure <90 mm Hg independent of the development of symptoms. Cardiac examination may reveal the murmur of hypertrophic cardiomyopathy or aortic stenosis. The neurologic examination may uncover findings of focal neurologic disease or evidence of autonomic instability such as peripheral neuropathy. Perform rectal examination to check stool guaiac to evaluate for GI bleeding.
Carotid massage is not part of the ED evaluation. Carotid massage can be combined with tilt ­table testing only in specialized syncope units, with continuous cardiac monitoring and resuscitation equipment immediately available. Neurologic deficits resulting from carotid massage are rare, but can be devastating.41,53
ECG AND ED MONITORING
Obtain a 12­lead ECG and place the patient on a cardiac monitor. Even though the ECG leads to a diagnosis in only a few patients, it is a simple, noninvasive test and is important for risk stratification.23,43,44 Assess the ECG for evidence of prior cardiopulmonary disease, acute ischemia or new ECG changes, dysrhythmia, heart block, and prolonged or short QT interval. A prolonged QT interval has a variable definition, but the literature suggests it is defined as >470 milliseconds, with >500 c c milliseconds associated with significant outcomes,45–47 whereas a short QT interval <350 milliseconds is concerning as well.48 New or old left bundle conduction c abnormalities (e.g., left bundle branch block, posterior or anterior fascicular block, QRS widening) are .5 times more likely to be associated with morbidity than ECGs lacking these findings. Nonsinus rhythms are .5 times more likely to be associated with morbidity than sinus rhythms.49 Numerous studies have pointed out that the value of ED monitoring is additive to a single ECG done in the ED.50–52 For further discussion, see below and Chapter , “Cardiac Rhythm Disturbances.”
LABORATORY TESTING
Laboratory testing is directed by results of the history and physical examination, and no test other than an ECG should be considered “routine.” For example, a patient with orthostatic symptoms and a heme­positive stool test warrants at least a CBC. A reproductive­age female should have a urine pregnancy test. A transitory, wide anion gap acidosis follows a generalized seizure but is not present in simple syncope. Serum electrolytes rarely determine the cause of syncope; however, an elevated blood urea nitrogen is a predictor of serious adverse outcome within  days after syncope.53 Troponin and natriuretic peptides, as well as B­type natriuretic peptide or pro–B­type natriuretic peptide levels appear to be predictive of overall for morbidity.53A,66 While one study reported that troponin was an independent prognostic indicator for short­term outcomes, it found no added value for the pro­B­type natriuretic peptide above that of clinical evaluation, ECG, and troponin.54
See Chapter , "Acute Heart Failure," for a discussion of the diagnostic use of B­type natriuretic peptide.
ANCILLARY TESTING
Hyperventilation Maneuver
A hyperventilation maneuver (open­mouthed, slow, deep breaths at a rate of  to  breaths per minute for  to  minutes) can be very useful in the young patient with undiagnosed syncope and suspected psychiatric illness. A recurrence of prodromal symptoms or syncope significantly correlates with psychiatric (anxietyprovoking) causes of syncope.33
Neurologic Testing
When the history or physical examination does not reveal head trauma or neurologic findings, the clinical yield of CT scanning,59 electroencephalogram, or lumbar puncture is very low. Consequently, in asymptomatic patients who have returned to baseline with an isolated syncopal event, CT or MRI is not warranted unless there is concern for a neurologic cause.
Pulmonary Embolism
Pulmonary embolism assessment should be reserved for those with venous thromboembolism risk factors or history or examination findings suggestive of pulmonary embolism. A large multicenter study found the pulmonary embolism prevalence in ED patients with syncope to be .15% to 2%.61 For all ED patients presenting with syncope, the prevalence of pulmonary embolism ranges from .06% to .4%.61,62 Methodology accounts for different reporting from The Pulmonary
Embolism in Syncope Italian Trial (PESIT). PESIT reported a 17% prevalence of pulmonary embolism in selected hospitalized, non­ED patients.60
DECISION MAKING AND RISK ASSESSMENT
If a serious cause of syncope is identified by the initial history, physical examination, and ECG, the disposition is based on treatment needed. Patients with cardiac or neurologic syncope should have appropriate specialty consultation and be admitted as necessary. Patients with clear vasovagal, orthostatic, and medication­related syncope have no increased risk of cardiovascular morbidity or mortality7 and do not need admission as long as deficits or medication misadventures are corrected.
UNEXPLAINED SYNCOPE AND THE CANADIAN SYNCOPE RISK SCORE (CSRS)
Despite best efforts in the ED, a clear diagnosis will not be established in many patients presenting with syncope. The dilemma of “unexplained syncope” is therefore the inability to identify those patients with serious short­term outcomes. The Canadian Syncope Risk Score (CSRS) was derived and validated through multicenter studies for prediction of 30­day serious outcomes not evident during the index ED evaluation among adult patients with syncope.63,64
The CSRS tool (Table 52­3) is applicable to those≥  years old and includes the following predictors: predisposition to vasovagal syncope, heart disease, any systolic blood pressure (SBP) in the ED <90 or >180 mmHg, troponin level >99th percentile for the normal population, abnormal QRS axis (< –
30° or > 100°), prolonged corrected QT interval >480 milliseconds, and ED diagnosis of cardiac or vasovagal syncope. Each predictor is assigned a score as indicated in Table 52­3. If the examiner feels the presumptive cause of syncope cannot be attributed to either a vasovagal or cardiac cause based on clinical evaluation, the examiner assigns a  (zero) score to the variable “neither cardiac nor vasovagal.” If the score based upon clinical evaluation is felt to be vasovagal, a score of –2 is assigned; if it is felt to be cardiac, a score of +2 is assigned. The total score is then calculated. Based on the total score (–3 to +11) the patient can be risk stratified. The 30­day risk of syncope­related serious outcomes associated with each risk stratum is detailed in Table 52­4. At a threshold score of –1, the CSRS sensitivity and specificity were .8% and .3%, respectively. Patients with serious conditions either identified or strongly suspected based on history or physical examination during the index ED evaluation (see above) will need hospitalization for further management. For most patients with diagnostic uncertainty, however, the CSRS tool can be applied at the end of ED evaluation to decide disposition: very­low­risk and low­risk patients can generally be discharged, hospitalization can be considered for high­risk and very­high­risk patients, and a shared decision approach can be taken for medium­risk patients. The CSRS has been externally validated in multicenter studies in Canada64 and Australia65 and indirectly supported by a multicenter European Study66. ECG MONITORING IN THE ED
The optimal duration of ED cardiac monitoring for patients with syncope is not well defined. One study reported that  hours of observation for CSRS low­risk patients and  hours for non­low­risk patients in the ED will detect half of all underlying arrhythmias.67,68
TABLE 52­3
Canadian Syncope Risk Score (CSRS)* PREDICTOR POINTS
Clinical Evaluation
Predisposition to vasovagal symptoms† –1
History of heart disease 
Any systolic blood pressure reading 
<90 or> 180 mm Hg
Investigations
Elevated troponin level (>99%ile normal) 
Abnormal QRS axis (< –30o or > 1000) 
QRS duration >130 ms 
QT >480 ms  c
ED Diagnosis based on evaluation
Vasovagal syncope –2
Cardiac syncope 
Neither cardiac nor vasovagal 
* DO NOT APPLY CSRS for >5 minutes loss of consciousness, change in mental status from baseline, witnessed seizure, major trauma or head trauma with loss of consciousness, intoxication, or language barrier.
†Vasovagal symptoms triggered by being in a warm crowded place, prolonged standing, fear, emotion, or pain.
TABLE 52­4
The Canadian Syncope Risk Score Memory Aid
Memory aid created by Dr. Rajiv Thavanathan, Emergency Medicine Resident at the University of Ottawa. Infographic created by Dr. Shahbaz Syed, Emergency Physician at the
University of Ottawa. Thiruganasambandamoorthy V, Kwong K, Wells GA, et al: Development of the Canadian Syncope Risk Score to predict serious adverse events after emergency department assessment of syncope. CMAJ 188:E289, 2016. TABLE 52­5
30­Day Serious Outcomes for Each Canadian Syncope Risk Score Category* Arrhythmic Outcomes
All Non­Arrhythmic Any Serious
Risk†
Deaths ‡ Death from unknown Ventricular Non­ventricular Outcomes Outcome cause arrhythmia arrhythmia
Very 0% 0% 0% .1% .1% .2%
Low
Low 0% 0% 0% .5% .2% .7%
Medium .1% 0% .9% .9% .2% .0%
High .0% .4% .2% .0% .6% .2%
Very .0% .4% .4% .5% .0% .3%
High
Total .3% .2% .3% .2% .8% .6%
*Based on multicenter validation study data.
†Proportion of patients in each risk category: Very low .7%, low .9%, medium 18%, high .4% and very high 2%.
‡
Deaths due to another serious arrhythmic or non­arrhythmic condition, or due to unknown cause; not counted toward the total in the last column.
Data from Thiruganasambandamoorthy V, Sivilotti MLA, LeSage N et al: Multicenter emergency department validation of the Canadian Syncope Risk Score. JAMA Intern Med
180(5):737, 2020. Table 52­6
Sensitivity/Specificity Based on the Canadian Syncope Risk Score (CSRS)
CSRS Score Estimated Average Risk of Serious Adverse Event in  days* (sensitivity) [specificity]
–3, –2 (very low risk) .2% (99.3–100%) [28.5%]
–1,  (Low risk) .7% (95.7–97.8%) [44.3–58.2%]
,2,3 (Medium risk) .0% (66.2–91.4%) [78.1–91.6%]
,5 (High risk) .2% (38.9–51.8%) [95.3–97.3%]
≥6–11 (Very high risk) .3% (28.8%) [99%]
*Death, dysrhythmia, myocardial infarction, serious structural heart disease, aortic dissection, pulmonary embolism, severe pulmonary hypertension, severe hemorrhage, subarachnoid hemorrhage, or any other serious condition causing syncope and procedural interventions for the treatment of syncope.
Data from Thiruganasambandamoorthy V, Sivilotti MLA, Le Sage N, et al. Multicenter emergency department validation of the Canadian Syncope Risk Score. JAMA Intern Med
180(5):737, 2020. OTHER RISK TOOLS FOR SYNCOPE RISK STRATIFICATION
There has been a general theme regarding risk factors for adverse outcomes among ED patients with syncope based on previous studies or guidelines44,69,73­79,82: older age (>60–65 years); history of heart disease; abnormal ECG, higher troponin levels; abnormal ED SBP readings (too low or too high), and features suggestive of cardiac syncope (no prodrome, syncope during exercise or when supine, palpitations preceding syncope). While the above risk factors can aid in clinical management, CSRS offers a standardized approach for short­term risk assessment and ED disposition decisions.
Table 52­7 summarizes a selection of previously published risk tools for both short­term and 1­year morbidity and mortality.2,58­65L Some lack external validation or can be applied only to a select subgroup of patients, such as older adults.69,83,84
Table 52­7
Selected Syncope Scores Identifying Risks for Adverse Outcomes After Syncope
San Francisco OESIL
Risk Rule Martin et al70 Syncope Score for EGSYS Score94 STePS75 ROSE85
Rule2,71 Syncope73
Publication Year 1997 2004 2003 2008 2008 2010
Adverse outcomes Arrhythmia or Adverse events at Death at  y Death or Death or need 1­month serious outcome and all­cause death assessed death at  y  and  d diagnosis of for major cardiac syncope procedure at  at 21–24 months d and  y
ECG Abnormal ECG* Abnormal ECG Abnormal Abnormal ECG* Abnormal ECG* Q wave on presenting ECG (except in lead III)
(non­sinus ECG* rhythm or any new changes)
Cardiac disease History of History of CHF History of History of cardiac History of †
CHF/ventricular cardiac disease cardiac disease arrhythmia disease
Age criteria Age >45 y † Age >65 y † † †
Prodrome/vasovagal † † No No prodrome No prodrome † prodrome
Additional factors † Dyspnea † Palpitations Concomitant BNP ≥300 pg/mL, Bradycardia ≤50 bpm in
SBP <90 mm Hg before syncope trauma ED/prehospital, O sat <94%, Hgb <9g/dL [≤90

Hematocrit <30% Syncope during g/L], + fecal occult blood, chest pain with
(<0.30) effort or supine syncope.
Absence of predisposing
‡ factors
Abbreviations: CHF = congestive heart failure; EGSYS = Evaluation of Guidelines in Syncope Study; OESIL = Osservatorio Epidemiologico sulla Sincope nel Lazio; SBP = systolic blood pressure; STePS = Short­Term Prognosis of Syncope.
*The definition of an abnormal ECG varies between studies, from any ECG findings other than completely normal, to more specific rhythm abnormalities, conduction disorders, ventricular hypertrophy, axis deviation, or ST­segment or T­wave abnormalities/changes.
†Variable not included in risk score.
‡
Warm crowded place/prolonged orthostasis/fear, pain or emotion.
TREATMENT
Treatment should be guided by the diagnosis. Patients with or at risk for life­threatening dysrhythmias can be treated with pacemakers or automatic implantable defibrillators as indicated. For patients with suspected medication causes, remove the offending agent. Rehydrate those with orthostasis and dehydration. Educate patients with vasovagal syncope; episodes are likely to recur, and patients should lie or sit down when they sense a prodrome. β­Blockers do not decrease episodes of vasovagal syncope.80
DISPOSITION AND FOLLOW­UP
Guidelines recommend using known risk factors, such as those outlined in the text and Table 52­3, to separate patients into risk groups for disposition and management.23,44,81 European Society of Cardiology guidelines identify high­ and low­risk patients,44 and the American Heart Association guidelines also identify intermediate­risk patients.23,81 There is agreement that low­risk patients (those with clear reflex­mediated syncope, without a history of heart disease, who are currently asymptomatic and with a normal physical exam and ECG) can be discharged with nonurgent primary care follow­up.23,44 There is less agreement as to which patients are at high or intermediate risk of adverse outcome, reflected by guideline discrepancies and regional variation.82 However patients thought to be high risk per the CSRS or by the examining physician and those with active chest pain or dyspnea, exertional syncope, sudden­onset palpitations prior to syncope, ECG evidence of conduction abnormalities or ongoing arrhythmia, history of CHF or structural heart disease, or family history of sudden cardiac death are recommended for admission to the hospital or to a syncope observation unit (if now asymptomatic).23,81 Decisions on testing should be determined by the patient’s presentation and comorbidities. Early evidence suggests that non­low­risk patients identified by the CSRS might benefit from prolonged (15­day) outpatient cardiac rhythm monitoring.67
POST­ED EVALUATION
The indications and utility of post syncope testing are listed in Table 52­8. Table 52­8
Post­ED Testing for Syncope/Syncope Mimics
Test Indication Utility
Cardiac syncope
ECG monitoring Admission Cardiac syncope confirmed if recurrent symptoms occur during monitored dysrhythmia; excluded if recurrent symptoms reported during sinus rhythm.
Outpatient ambulatory monitoring if One recent study suggested CSRS non­low­risk patients who are discharged could benefit from 15­ no significant cardiac disease suspected day cardiac rhythm monitoring (K); others recommend prolonged monitoring.42,86,87,88
Implantable loop recorder Recurrent syncope after admission Long­term use with variable diagnostic yield evaluation
Echocardiography History, examination, or ECG suggestive Confirms and quantifies suspected structural heart disease of structural heart disease
Electrophysiology testing Documented dysrhythmia, Identifies inducible tachydysrhythmias and some bradydysrhythmias23,88­91 preexcitation, or serious underlying heart disease
Stress testing Exercise­related syncope Identifies exercise­induced dysrhythmias and postexercise syncope
Neurologic syncope
CT/magnetic resonance Neurologic signs or symptoms Identifies cerebrovascular abnormality or subclavian stenosis angiography/carotid
Doppler
Electroencephalography Suspected seizure Documents underlying seizure disorder
Reflex­mediated syncope
Tilt­table testing Recurrent syncope, cardiac etiology Positive test establishes diagnosis of neurocardiogenic syncope excluded
Psychogenic
Psychiatric testing Young patient, no underlying heart Identifies underlying psychiatric disorder predisposing to syncope disease
SPECIAL POPULATIONS
THE ELDERLY
Because of both normal physiologic changes with aging and age­related disease processes, the elderly are at increased risk for adverse outcomes after syncope or near­syncope.9,11 Syncope in the elderly is often multifactorial and difficult to establish in the ED. Twelve percent of patients over  years of age who sustain cardiac arrhythmia within  days after syncope have a completely normal ECG at the index ED visit.93
Various specified ages have been studied as risk factors for fatal or serious outcomes after syncope; however, there is a gradual continuum of increasing risk with increasing age. Cardiovascular risk factors appear to be better predictors than age itself. Decreased adrenergic responsiveness contributes to the diminished chronotropic response seen after orthostatic stresses in the elderly. The incidence of vasovagal syncope actually decreases with age, in part as a consequence of the decreased responsiveness of the autonomic nervous systems. The elderly also have a less sensitive thirst mechanism and a decreased endocrine response to volume depletion, exacerbating orthostatic hypotension. Postprandial hypotension is more common in the elderly, especially in nursing home patients, and is thought to be due to a rapid rate of nutrient delivery from the stomach into the small intestine. Aortic stenosis is the most common obstructive cardiac lesion in the elderly, producing a fixed cardiac output. Diabetes may lead to autonomic dysfunction and peripheral neuropathy. Finally, medication usage is much more common in the elderly population, increasing the risk of orthostasis and decreasing autonomic responsiveness to orthostatic stress.29


