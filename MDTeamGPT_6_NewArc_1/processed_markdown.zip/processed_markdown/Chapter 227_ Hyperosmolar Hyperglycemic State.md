## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 227: Hyperosmolar Hyperglycemic State
Charles S. Graffeo
Content Update January 2023
Figure 227­2 on treatment of HHS has been updated.
INTRODUCTION AND EPIDEMIOLOGY
The hyperosmolar hyperglycemic state(HHS) is characterized by progressive hyperglycemia and hyperosmolarity typically found in a debilitated patient with poorly controlled or undiagnosed type  diabetes mellitus, limited access to water, and commonly, a precipitating illness. Although most cases of HHS occur in the elderly, the incidence of HHS in children is increasing, with the common risk factors being obesity and African American
 race.
PATHOPHYSIOLOGY
The basic pathophysiology of diabetes is discussed in Chapter 223, “Type  Diabetes Mellitus,” and Chapter 224, “Type  Diabetes Mellitus,” and is also outlined in Figure 227­1. The development of HHS is attributed to three main factors: (1) insulin resistance and/or deficiency; (2) an inflammatory state with marked elevation in proinflammatory cytokines (C­reactive protein, interleukins, tumor necrosis factors) and counterregulatory stress hormones (catecholamines, growth hormone, glucagon, cortisol) that cause increased hepatic gluconeogenesis and glycogenolysis; and (3) osmotic
,3 diuresis followed by impaired renal excretion of glucose.
FIGURE 227­1. Pathophysiology of hyperglycemic emergencies. HHS = hyperosmolar hyperglycemic state. [Reproduced with permission from Cardoso L et al:
Controversies in the management of hyperglycaemic emergencies in adults with diabetes. Metabolism 68: , 2017 [PMID: 28183452]. Fig. . Copyright
Elsevier.]

Chapter 227: Hyperosmolar Hyperglycemic State, Charles S. Graffeo 
. Terms of Use * Privacy Policy * Notice * Accessibility
In patients with type  diabetes, physiologic stresses combined with inadequate water intake in an environment of insulin resistance or deficiency lead to HHS. As serum glucose concentration increases, an osmotic gradient develops, shifting water from the intracellular space into the intravascular compartment, causing cellular dehydration.
The initial increase in intravascular volume is accompanied by a temporary increase in the glomerular filtration rate. As serum glucose increases, the capacity of the kidneys to reabsorb glucose is exceeded, and an osmotic diuresis occurs with total body water losses that can exceed 20% to 25% of total body weight, or approximately  to  L in a 70­kg patient. During osmotic diuresis, significant urinary loss of sodium and potassium and more modest losses of calcium, phosphate, and magnesium occur. With ongoing volume losses, renal perfusion and glomerular filtration are reduced, and
 renal tubular excretion of glucose is further impaired.
The relative lack of severe ketoacidosis in HHS is poorly understood and has been attributed to three possible mechanisms: (1) higher levels of endogenous insulin than are seen in DKA; (2) lower levels of counterregulatory “stress” hormones; and (3) inhibition of lipolysis by the hyperosmolar state itself. Evidence of significant ketoacidosis in a patient thought to have type  diabetes should bring into question the possibility of variants of type

 diabetes, such as latent autoimmune diabetes in adults. Additionally, a greater proportion of ketosis­prone type  diabetes has been described in

African American, Hispanic, and Asian populations.
CLINICAL FEATURES
HISTORY AND COMORBIDITIES
The typical patient with HHS is elderly and often institutionalized, with baseline cognitive impairment and comorbid medical illnesses, who is referred for abnormalities in vital signs, lab results, and/or mental status changes that have evolved over days to weeks. Patient complaints are often nonspecific and may include malaise, weakness, anorexia, fatigue, vomiting, and cognitive impairment. Up to 15% of patients may present with seizures, which are typically focal, although generalized seizures may occur. In other cases, HHS is noted in patients with no prior history of diabetes mellitus who present with acute illnesses such as stroke, myocardial infarction, pneumonia, abdominal emergencies, and sepsis. Patients taking antipsychotics or antidepressants may present a particular risk, and HHS should be considered as part of the medical screening process for psychiatric patients.

HHS is associated with a host of conditions (Table 227­1) and drugs (Table 227­2) that may predispose to hyperglycemia and volume depletion.
TABLE 227­1
Conditions That May Precipitate Hyperosmolar Hyperglycemic State
Diabetes
Infection, especially pneumonia or urinary tract infection
Myocardial infarction
Renal insufficiency
Cerebrovascular events
Mesenteric ischemia
GI hemorrhage
Pulmonary embolism
Pancreatitis
Severe burns
Parenteral or enteral alimentation
Peritoneal or hemodialysis
Heat­related illness
Rhabdomyolysis
Pregnancy
Trauma
TABLE 227­2
Some Drugs That May Predispose Individuals to the Development of HHS
Diuretics
Statins
β­Blockers
Chlorpromazine
Cimetidine
Glucocorticoids
β­Agonists
Antipsychotics
Antidepressants
Phenytoin
Calcium channel blockers
Pentamidine
Immunosuppressive drugs (tacrolimus, cyclosporine)
Diazoxide
L­asparaginase
Protease inhibitors
Nicotinic acid
Nucleoside reverse transcriptase inhibitors
Interferons
PHYSICAL EXAMINATION
The physical findings in HHS generally include signs of severe volume depletion such as poor skin turgor, dry mucous membranes, sunken eyes, tachycardia, and hypotension. The degree of lethargy and coma has a linear relationship to serum osmolality. Patients with coma tend to be older and
 have higher osmolality, more severe hyperglycemia, acidosis, and greater volume contraction.
DIAGNOSIS AND DIFFERENTIAL DIAGNOSIS
HHS is “defined” by severe hyperglycemia with serum glucose usually >600 milligrams/dL (>33.3 mmol/L), an elevated calculated plasma osmolality of >315 mOsm/kg (>315 mmol/kg), serum bicarbonate >15 mEq/L (>15 mmol/L), an arterial pH >7.3, and serum ketones that are negative to mildly positive. Metabolic acidosis or ketonemia associated with HHS is likely to be due to tissue hypoperfusion,
 starvation ketosis, and azotemia in various combinations, although there is growing evidence for ketosis­prone type  diabetic subgroups. It is important to recognize the potential for a variety of mixed acid­base patterns in patients with HHS.
A comparison of the laboratory features of DKA and HHS is shown in Table 227­3. TABLE 227­3
Diagnostic Criteria for DKA and Hyperosmolar Hyperglycemic State (HHS)
DKA HHS
Plasma glucose >250 milligrams/dL (>13.8 mmol/L) >600 milligrams/dL (>33.3 mmol/L)
Serum bicarbonate ≤18 mEq/L (<18 mmol/L) >15 mEq/L (>15 mmol/L)
Urine acetoacetate* + – or small
Serum beta hydroxybutyrate + – or small
Serum ketones† + – or small
Serum osmolality‡ Variable >320 mOsm/kg (>320 mmol/kg)
Anion gap# >12 mEq/L (>12 mmol/L) <12 mEq/L (<12 mmol/L)
Arterial/venous pH <7.30 >7.30
*Nitroprusside method.
†Gas chromatography method or nitroprusside method.
‡ Osmolality calculation: 2(measured [Na+] + glucose (milligrams/dL or mmol/L)/18. #Anion gap calculation: [Na+] – [Cl–] + [HCO –].

LABORATORY TESTING AND IMAGING
Laboratory tests and diagnostic imaging should be tailored to the individual patient. Laboratory workup commonly includes a CBC with differential, comprehensive metabolic profile, magnesium and phosphate, urinalysis, serum and urine osmolality, lactate, β­hydroxybutyrate, and blood and urine cultures. In addition, cardiac markers, creatine phosphokinase, arterial or venous blood gas, thyroid function studies, procalcitonin, and coagulation profiles should be considered. Chest radiographs and ECGs are generally recommended. Diagnostic studies, such as CT, lumbar puncture, toxicologic studies, and echocardiography, should be patient specific.
In general, electrolyte abnormalities vary. Initially, contraction alkalosis due to a profound water deficit may occur. An anion gap metabolic acidosis is often attributable to sepsis, poor tissue perfusion, starvation ketosis, or renal impairment.
Sodium
Serum sodium level varies and is not a reliable indicator of the degree of volume contraction. Hyperglycemia has a dilutional effect on measured serum
+ sodium: Standard teaching is that serum Na decreases by approximately .6 mEq/L (1.6 mmol/L) for every 100 milligrams/dL(5.6 mmol/L) increase in serum glucose >100 milligrams/dL (5.6 mmol/L). For glucose > 400 milligrams/dL (22.2 mmol/L), a correction factor of .4 is more accurate.
Osmolality
Serum osmolality correlates positively with severity of disease as well as mental status changes and coma. In the United States, many authors suggest using calculated effective serum osmolality, which excludes osmotically inactive urea. Although osmotically inactive, urea is known to be elevated in
 dehydration, shock, renal impairment, and catabolic states. Recent guidelines from the United Kingdom suggest that including urea when calculating serum osmolality may more accurately reflect severity of dehydration and help protect against overzealous correction of osmolality, which can
,10 predispose patients to cerebral edema and osmotic demyelination syndrome.
The normal serum osmolality range is approximately 275 to 295 mOsm/kg. Values >300 mOsm/kg are usually indicative of significant hyperosmolality, and those >320 mOsm/kg are commonly associated with alterations in cognitive function. In general, serum osmolality correction should not exceed
### .0 Osm/kg/h.
Potassium
On average, potassium losses range from  to  mEq/kg. Despite these total­body deficits, initial serum laboratory measurements may be normal or
+ + even high in the presence of acidosis when intravascular [H ] ions are exchanged for intracellular [K ] ions. As intravascular volume is replaced and
+ acidosis is reversed, [K ] deficiency becomes more apparent.
Other Laboratory Testing
Hypomagnesemia is common, and serum magnesium levels should be monitored and replaced. Consequences of hypophosphatemia, such as CNS abnormalities, cardiac dysfunction, and rhabdomyolysis, are uncommon and usually associated with serum phosphate levels below .0 milligram/dL.
Routine replacement of phosphate, unless severe, is usually unnecessary. Prerenal azotemia is common, with plasma BUN­to­creatinine ratios often
 exceeding 30:1, indicating severity of dehydration and the catabolic state.
TREATMENT
Improvement of tissue perfusion is the key to effective recovery in HHS. Treatment includes correction of hypovolemia, identifying and treating precipitating causes, correcting electrolyte abnormalities, gradual correction of hyperglycemia and hyperosmolarity, and frequent monitoring. The therapeutic plan must be carefully considered and adjusted for concurrent medical illnesses such as cardiac, renal, and pulmonary disease.
Overzealous resuscitation can result in significant harms and should be avoided. A protocol for treating severely ill patients likely requiring intensive care unit–level care is shown in Figure 227­2. FIGURE 227­2. Protocol for the management of severely ill adult patients with hyperosmolar hyperglycemic state (HHS). *Concentrations of K
+≥20 mEq/L should be administered via central line. NS = normal saline. (Illustration used with permission of Skyler Lentz, MD)
FLUID RESUSCITATION
Fluid resuscitation alone replenishes intravascular volume, improves tissue perfusion, and decreases serum glucose about  to  milligrams/dL/h.
Begin normal saline infusion before insulin therapy is started.
The average fluid deficit in HHS is in the range of 20% to 25% of total body water, or  to  L. By using the patient’s usual weight in kilograms, normal total body water and water deficit can be calculated. One half of the fluid deficits should be replaced over the initial  hours and the balance over the next  hours when possible. The actual rate of fluid administration should be individualized for each patient, based on the level of renal and cardiac impairment. Begin fluid resuscitation with .9% normal saline at a rate of  to  mL/kg/h during the first hour, followed by rates from  to  mL/kg/h. Limit the rate of volume repletion during the first  hours to <50 mL/kg of normal saline. Once hypotension, tachycardia, serum hyponatremia, and urinary output improve, .45% NaCl can be used to replace the remaining free water deficit.
Hourly glucose, electrolyte, and osmolality measurements should be taken to monitor progress in the critically ill.
ELECTROLYTES
Hypokalemia is a risk for dysrhythmia and should be replaced during volume repletion and insulin administration. If the initial serum potassium measurement is <3.3 mEq/L, begin potassium supplementation and withhold insulin therapy until potassium is replenished.
In general, replace potassium at a rate of  to  mEq/h. For life­threatening hypokalemia, infusion rates of up to  mEq/h may be needed, and under these circumstances, central venous access is warranted. Monitor serum potassium levels every hour until a steady state has been achieved.
Sodium deficits are replenished fairly rapidly, considering the amount of normal saline given during IV fluid replacement. Replace magnesium deficits with  to  grams of magnesium given over  hour. Phosphate should only be replaced if the phosphate level is <1.0 milligram/dL (<1.0 mmol/L). Sodium bicarbonate has been included in American Diabetes Association guidelines if serum pH is <7.0; however, more recent data
,11 suggest no benefit and potential harms in the pediatric population.
INSULIN
Begin insulin after initial fluid resuscitation has been completed. If insulin is started too early, intravascular volume may be further depleted by shifting osmotically active glucose and fluids out of the intravascular space.
The absorption of insulin by the IM or SC route is unreliable in patients with HHS, and a continuous infusion of insulin is recommended. Initiation of
 insulin therapy should begin at .1 unit/kg/h. With adequate hydration and insulin therapy, the goal of therapy is to maintain a steady rate of decline in the glucose concentration of  to  milligrams/dL/h (2.8–4.1 mmol/L/h). With adequate hydration, the insulin infusion may be adjusted every hour until a steady glucose decline is achieved. If glucose falls too rapidly, decrease the infusion rate by half, to .05 or .07 unit/kg/h. Once serum glucose decreases to <300 milligrams/dL (<16.6 mmol/L), change the IV solution to 5% dextrose in half­normal saline, and reduce the insulin infusion to .02 to
### .05 unit/kg/h until serum osmolality is <315 mOsm/kg and glucose is maintained between 200 and 300 milligrams/dL (11.1–16.6 mmol/L). Once the patient is mentally alert and able to eat and prior to discontinuing parenteral insulin, administration of long­acting SC insulin has demonstrated
 efficacy in preventing rebound hyperglycemia.
DISEASE COMPLICATIONS
Despite cerebral edema representing >50% of fatalities in children with hyperglycemic emergencies, cerebral edema is an uncommon complication in adults with HHS. There are few data on the incidence of or clinical indicators that may predispose to cerebral edema in adults. A
 small case series suggests that rapid changes in osmolality in HHS can predispose to osmotic demyelination syndrome. The current recommendation is to limit the rate of volume repletion during the first  hours to <50 mL/kg of normal saline, measure serum osmolality frequently, and monitor the patient’s mental status during treatment. Stat head CT or MRI is indicated, as is early neurosurgical consultation, if cognitive deterioration develops.
Although there are no evidence­based treatments for cerebral edema, osmotic agents remain the most practical option. Venous and arterial thromboses are a common complication in HHS, and unless contraindicated, all patients should receive prophylactic anticoagulation as part of the
 management plan.
DISPOSITION AND FOLLOW­UP
When considering the patient population predisposed to developing HHS (debilitated patients with multiple comorbidities), intensive care unit monitoring for the initial  hours of care is usually the most appropriate course of action. Patients without significant comorbid conditions who demonstrate a good response to initial therapy may be considered for monitored step­down or non–intensive care unit admission. Patients with HHS are often chronically debilitated and may present in a premorbid state often late in the natural history of their disease processes. In this context, the patient’s goals of care should be identified early and remain at the forefront of the ED management plan. In a retrospective study that looked at predictors of recurrent hospitalization for patients with DKA and HHS, age <35 years, history of depression or substance abuse, self­pay or publicly
 funded insurance, and HbA level >10.6% were associated with higher odds of readmission.
1c


