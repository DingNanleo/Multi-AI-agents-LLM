## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 65: PNEUMONIA: Community­Acquired Pneumonia, Aspiration Pneumonia, and Noninfectious Pulmonary Infiltrates
Jessica Pelletier; Alex Koyfman; Brit Long; Eric Anderson; Simone French; Gerald E. Maloney
Content Update: Pneumonia and Community­Acquired Pneumonia December 2024
Updated material is provided in the Community­Acquired Pneumonia section. CAP treatment regimens are stratified by risk factors into outpatient and inpatient management.
PNEUMONIA
INTRODUCTION AND EPIDEMIOLOGY
Pneumonia is an infection of the lung parenchyma caused by a variety of organisms with a variety of symptoms and sequelae. Pneumonia is caused by bacteria, viruses, and fungi, but the specific cause is identified in fewer than half of patients. Of those with pathogens identified, up to 40% with community­acquired pneumonia (CAP) have viruses identified as a cause.1
Streptococcus pneumoniae is the most common bacterium causing pneumonia. CAP, pneumonia contracted in a community setting, is a leading cause of illness and hospitalization around the world. Typical symptoms of pneumonia include fever, cough, purulent sputum, and rigors. Atypical infections, infections in compromised hosts, and infections in patients at the extremes of age may produce atypical findings, such as a change in mental status or a decline in function.
PATHOPHYSIOLOGY
Pathogenic organisms are inhaled or aspirated directly into the lungs. Some bacteria, such as Staphylococcus aureus or the pneumococcus, may also produce pneumonia by pharyngeal spread or hematogenous seeding. Viruses produce disease primarily by inhalation. Bacterial pneumonia results in an intense inflammatory response and tends to cause a productive cough.
Viruses and atypical organisms may not cause an intense inflammatory response and may trigger a mild, nonproductive cough.
Patients most at risk for pneumonia are suggested in Table 65­1. The elderly, children <2 years old, minorities, children who attend group daycare centers, and persons with underlying medical conditions (including HIV infection and sickle cell disease) are at risk for pneumonia. Bacterial pneumonia may appear on chest x­ray as lobar pneumonia (Figure 65­1) with parapneumonic pleural effusions. Patients with functional or anatomic asplenia or those being treated with immunosuppressive drugs may have a rapid progression of disease, with acute prostration and septic shock progressing to multisystem organ failure. Patients with chronic lung disease, nursing home patients, or otherwise healthy elderly patients tend to have a slower progression of pneumonia, with symptoms of malaise with minimal cough or sputum production.
TABLE 65­1
Risk Factors for Pneumonia
Aspiration risk
Swallowing and esophageal motility disorders
Stroke
Nasogastric tube
Intubation
Seizure and syncope
Bacteremia risk
Indwelling vascular devices
Intrathoracic devices (e.g., chest tube)
Debilitation
Alcohol use disorder
Extremes of age
Neoplasia
Immunosuppression
Chronic diseases
Diabetes
Renal failure
Liver failure
Valvular heart disease
Heart failure
Disorders altering the lung

Chronic obstructive pulmonary disease
Chapter 65: PNEUMONIA: Community­Acquired Pneumonia, Aspiration Pneumonia, and Noninfectious Pulmonary Infiltrates, Jessica PPealgleet ie1 r/; 
Chest wall disorders
Alex Koyfman; Brit Long; Eric Anderson; Simone French; Gerald E. Maloney
Skeletal muscle disorders
. Terms of Use * Privacy Policy * Notice * Accessibility
Bronchial obstruction
Bronchoscopy
Viral lung infections
FIGURE 65­1. Lobar pneumonia suggestive of Streptococcus pneumoniae.
When a pathogen causing pneumonia is identified, the pneumococcus is still the most common, followed by viruses and the atypical agents Mycoplasma, Chlamydia, and Legionella. Two bacteria that account for the most severe pneumonia in otherwise healthy adults are S. pneumoniae and Legionella. The treatment of CAP targets covering at least these two organisms. When
COVID­19, respiratory syncytial virus (RSV), and influenza are prevalent in the community, they should be considered as potential causes of CAP.1
CLINICAL FEATURES
Symptoms of pneumonia include cough, fatigue, fever, dyspnea, sputum production, and pleuritic chest pain.2 However, the individual symptoms and physical findings vary, making clinical diagnosis of specific cases of pneumonia, and differentiation from upper respiratory tract disease, difficult.3,4 Symptoms of a viral upper respiratory infection, such as coryza, low­grade fever, rhinorrhea, or nonproductive cough, can precede clinical pneumonia. Weight loss, malaise, dizziness, and weakness also may be associated with pneumonia. Atypical agents may cause headache or GI illness. Occasionally, pneumonia is associated with extrapulmonary symptoms including joint pain, hematuria, or skin rashes. Elderly patients commonly present with atypical signs and symptoms including altered mental status and fatigue.
The physical examination may show evidence of alveolar fluid (inspiratory rales), consolidation (bronchial breath sounds), pleural effusion (dullness and decreased breath sounds), or bronchial congestion (rhonchi and wheezing).3,4 Adventitious lung sounds may not be identified in all patients with CAP.5 Respiratory rate ≥20 (positive likelihood ratio [LR+], .47), fever
(3.21), heart rate >100 (2.79), and crackles (2.42) are the most reliable findings suggestive of pneumonia, while normal vital signs and normal pulmonary examination demonstrate a negative likelihood ratio (LR–) of .10.5–7
Radiologic findings in pneumonia are nonspecific and may not provide a specific radiologic diagnosis. Typical radiologic features are listed in Table 65­2. Immunocompromised hosts, such as those with acquired immunodeficiency syndrome (AIDS) or neutropenia, may not manifest radiographic evidence of pneumonia despite clinical findings suggestive of pneumonia. Clinical and radiographic findings do not necessarily correspond; the patient may be improving clinically despite having a worsening appearance on their chest radiograph. Bacterial pneumonia will frequently demonstrate lobar pneumonia (Figure 65­1), with parapneumonic pleural effusions.
TABLE 65­2
Clinical Characteristics of Common Bacterial Pneumonias
Organism Symptoms Sputum Chest Radiograph
Streptococcus Sudden onset, fever, rigors, pleuritic chest pain, productive Rust­colored; gram­positive encapsulated Lobar infiltrate, occasionally patchy, occasional pleural pneumoniae cough, dyspnea diplococci effusion
Staphylococcus Gradual onset of productive cough, fever, dyspnea, especially Purulent; gram­positive cocci in clusters Patchy, multilobar infiltrate; empyema, lung abscess aureus just after viral illness
Klebsiella Sudden onset, rigors, dyspnea, chest pain, bloody sputum; Brown “currant jelly”; thick, short, plump, gram­ Upper lobe infiltrate, bulging fissure sign, abscess formation pneumoniae especially in alcoholics or nursing home patients negative, encapsulated, paired coccobacilli
Pseudomonas Recently hospitalized, debilitated, or immunocompromised Gram­negative coccobacilli Patchy infiltrate with frequent abscess formation aeruginosa patient with fever, dyspnea, cough
Haemophilus Gradual onset, fever, dyspnea, pleuritic chest pain; especially Short, tiny, gram­negative encapsulated Patchy, frequently basilar infiltrate, occasional pleural influenzae in older adults and COPD coccobacilli effusion
Legionella Fever, chills, headache, malaise, dry cough, dyspnea, Few neutrophils and no predominant bacterial Multiple patchy nonsegmented infiltrates, progresses to pneumophila anorexia, diarrhea, nausea, vomiting species consolidation, occasional cavitation and pleural effusion
Moraxella Indolent course of cough, fever, sputum, and chest pain; Gram­negative diplococci found in sputum Diffuse infiltrates catarrhalis more common in COPD patients
Chlamydophila Gradual onset, fever, dry cough, wheezing, occasionally sinus Few neutrophils, organisms not visible Patchy subsegmental infiltrates pneumoniae symptoms
Mycoplasma Upper and lower respiratory tract symptoms, nonproductive Few neutrophils, organisms not visible Interstitial infiltrates (reticulonodular pattern), patchy pneumoniae cough, bullous myringitis, headache, malaise, fever densities, occasional consolidation
Anaerobic Gradual onset, putrid sputum, especially in alcoholics Purulent; multiple neutrophils and mixed Consolidation of dependent portion of lung; abscess organisms organisms formation
Abbreviation: COPD = chronic obstructive pulmonary disease.
The differential diagnosis of patients with cough and radiographic abnormality includes lung cancer, tuberculosis, pulmonary embolism, chemical or hypersensitivity pneumonitis, connective tissue disorders, granulomatous disease, and fungal infections. In general, patients with bacterial pneumonia are more likely to have unilobar or focal infiltrates. Infiltrates in viral or atypical pneumonia are often interstitial and bilateral. Hilar adenopathy is more common in patients with atypical pneumonia.8 Pleural effusions can accompany bacterial, viral, or atypical pneumonia.8 Cavitary lesions occur in patients with bacterial pneumonia or tuberculosis. Lung abscesses are rare complications of pneumonia in the antibiotic era, but they sometimes occur due to S. aureus or Klebsiella.8
BACTERIAL PNEUMONIAS
S. pneumoniae causes a wide variety of clinical symptoms. Initial infection can extend from the nasopharynx to the ears, sinuses, and upper and lower respiratory tract. Hematogenous spread can spread infection throughout the body. The classic presentation of pneumococcal pneumonia is a sudden onset of illness with fever, severe rigor, dyspnea, sputum production, chest pain, tachycardia, tachypnea, and abnormal findings on lung examination. This presentation is not evident in all cases. Older adults, children <2 years old, minorities, children who attend group daycare centers, and persons with underlying medical conditions (including HIV infection and sickle cell disease) are at risk for pneumococcal pneumonia. Patients will frequently have lobar pneumonia (Figure 65­1) with parapneumonic pleural effusions. Patients with functional or anatomic asplenia, or those being treated with immunosuppressive drugs, may have a very rapid progression of disease with acute prostration and septic shock progressing to multisystem organ failure. Antibiotic resistance to S. pneumoniae is growing, and resistance varies with geographic location, patient factors, and inappropriate antibiotic use.
Staphylococcus aureus is a bacteriologic consideration in patients with chronic lung disease, patients with laryngeal cancer, immunosuppressed patients, and nursing home patients. S.
aureus pneumonia may occur in otherwise healthy patients after viral illness, such as during an influenza epidemic, although pneumococcal pneumonia is still more common. Patients with staphylococcal pneumonia typically have an insidious onset of disease with low­grade fever, sputum production, and dyspnea. The chest radiograph usually demonstrates extensive disease with empyema, pleural effusions, and multiple areas of infiltrate (Figure 65­2).
FIGURE 65­2. Staphylococcal pneumonia with extensive infiltration and effusion or empyema.
Klebsiella pneumoniae pneumonia often occurs in compromised patients: patients at risk of aspiration, alcoholics, the elderly, and other patients with chronic lung disease. In contrast to
S. aureus, patients with Klebsiella have acute onset of severe disease with fever, rigors, and chest pain. Herpes labialis is occasionally associated with Klebsiella pneumonia. Patients with
Klebsiella may develop pulmonary abscesses, although more commonly patients have a lobar infiltrate.
Pseudomonas aeruginosa may cause severe pneumonia with cyanosis, confusion, and other signs of systemic illness. The chest radiograph may show bilateral lower lobe infiltrates, occasionally associated with empyema. Pseudomonas is not a typical cause of CAP but may develop in patients who have received broad­spectrum antibiotics or high­dose steroid therapy or immunosuppressants, who have structural lung disease, or who are nursing home residents.
Haemophilus influenzae pneumonia occurs in the elderly and should be considered in patients with chronic lung disease, sickle cell disease, or immunocompromised disorders and in alcoholics and diabetics; its frequency in the young (and even adults) is markedly diminished now with vaccination. Patients may either have a gradual progression of disease with low­grade fever and sputum production or occasionally have the sudden onset of chest pain, dyspnea, and sputum production. Bacteremia may be seen in older adults. Pleural effusions and multilobar infiltrates are common findings in H. influenzae pneumonia.
Moraxella catarrhalis pneumonia has clinical features similar in spectrum to those of H. influenzae. Typically, patients with M. catarrhalis have an indolent course of cough and sputum production. Fever and pleuritic chest pain are common clinical symptoms. The chest radiograph typically demonstrates diffuse infiltrates.
PNEUMONIA FROM ATYPICAL AGENTS
The term atypical is used to describe organisms that are difficult to detect on Gram stain or culture. Atypical agents are a cause of pneumonia predominantly in older children, in young adults, and in the elderly. The atypical agents are Legionella, Chlamydia, Mycoplasma, and viruses. Mycoplasma is responsible for most. Because these agents lack a cell wall, they do not typically respond to β­lactam antibiotics.
Legionella species can cause a range of illnesses from benign self­limited disease to multisystem organ failure with acute respiratory distress syndrome (ARDS). Most cases are due to inhalation from water sources such as hot tubs or air conditioners. Legionella pneumonia is commonly complicated by GI symptoms, including abdominal pain, vomiting, and diarrhea. In addition, Legionella can affect other organ systems, causing sinusitis, pancreatitis, myocarditis, and pyelonephritis. The chest radiograph frequently shows patchy infiltrates, with the occasional appearance of hilar adenopathy and pleural effusions (Figure 65­3). Use of urinary Legionella antigen testing in patients is no longer recommended except in cases of exposure to a known outbreak or in adults with severe CAP. Treatment for Legionella pneumonia should be based on clinical suspicion.9
FIGURE 65­3. Pneumonia suggesting Legionella.
Chlamydia pneumonia usually causes a mild subacute illness with sore throat, mild fever, and nonproductive cough, although occasionally patients have a more severe course. Rales or rhonchi may be present on exam. The chest radiograph usually shows a patchy subsegmental infiltrate.
Mycoplasma pneumonia is due to person­to­person transmission. Symptoms are dry cough, sore throat, and headache. Mycoplasma is not associated with GI symptoms. The chest radiograph shows patchy infiltrates, with the common occurrence of hilar adenopathy and pleural effusions. Mycoplasma can cause extrapulmonary symptoms, including bullous myringitis, rash, neurologic symptoms, erythema nodosum, erythema multiforme, arthritis and arthralgia, or aseptic meningitis.
Viruses can cause severe pneumonia and result in secondary bacterial infection. While many viruses can cause pneumonia, the most frequent causes are adenovirus, human metapneumovirus, parainfluenza viruses, rhinovirus, RSV (common in infants and older adults), and influenza.10–14 SARS­CoV­1, SARS­CoV­2 (COVID­19), H1N1, and H5N1 influenza outbreaks resulted in rapid worldwide involvement.15 Pregnant women are particularly susceptible to developing severe influenza­associated pneumonia, and use of antivirals is recommended for pregnant women with an influenza­like illness. Varicella, typically benign in most childhood infections, can likewise lead to severe pneumonia. Clinical findings include gradual symptom onset, dry cough, and patchy interstitial infiltrates. Rales or rhonchi are present on chest auscultation.
DIAGNOSIS
Pneumonia is a clinical diagnosis based on a constellation of symptoms and signs; any individual symptom and clinical finding may lack accuracy for precise diagnosis. Diagnosis is based on the combination of two or more symptoms (new or increased cough) or signs (fever >38°C or body temperature <36°C, leukocyte count <4000/mcL or >10,000/mcL) in combination with imaging findings suggestive of pulmonary infiltrate.6,7,16 Physician judgment is more sensitive than scoring systems alone to predict the need for chest imaging for diagnosis of pneumonia.
However, indications for chest x­ray include the presence of respiratory symptoms in a patient with of at least one abnormal vital sign, age ≥65 years, or the presence of crackles or decreased breath sounds in patients who do not have a diagnosis of asthma.17 Unfortunately, the sensitivity of chest x­ray for the diagnosis of pneumonia is <80%.18–21 Approximately 10% to 30% of patients treated for CAP do not meet diagnostic criteria (i.e., signs, symptoms, and radiographic findings) for CAP.22–25 Patients without symptoms who have infiltrates on radiographs should not be treated for CAP. Patients with CAP symptoms in combination with radiographic results without physical examination evidence of CAP should undergo chest CT to determine the presence of alternative causes of the pulmonary symptoms, such as pulmonary malignancy.5 Computed tomography (CT) can also be considered in critically ill patients if CT results would change management.26 Point­of­care ultrasound has a sensitivity of up to 94% for identifying pneumonia.27 Proper technique incorporates the use of a phased array or curvilinear probe evaluating the anterior, lateral, and posterior lung sections for the presence of air bronchograms, B lines, fluid bronchograms, pleural effusion, or subpleural consolidation (Figure 65­4)
(Video 65­1).27
FIGURE 65­4. A. Left lower lobe pneumonia at the lateral costophrenic recess. Fluid bronchograms (FBs) can be seen. They have much more echogenic walls than vessels (V) and do not present flow with
Doppler examination. A tiny pleural effusion (E) is seen above the diaphragm (D) overlying the spleen (S). B. Dynamic air bronchograms. In another image of the same consolidation, movement of secretions could be seen within the air bronchograms (arrows) in real time. [Reproduced with permission from Ma OJ, Mateer JR, Reardon RF, et al (eds): Ma and Mateer's
Emergency Ultrasound, 4th ed. McGraw Hill; 2021.]
Video 65­1. Hepatization pneumonia.
[Reproduced with permission from Ma OJ, Mateer JR, Reardon RF, et al (eds): Ma and Mateer's Emergency Ultrasound, 4th ed. McGraw Hill; 2021.]
Play Video
Obtain ancillary studies based on clinical severity and clinical judgment. In otherwise healthy but mildly ill, ambulatory patients, no further ancillary testing may be necessary. If community outbreaks are present, obtain polymerase chain reaction (PCR) testing for influenza, RSV, and COVID. If a patient requires admission, additional tests are needed including complete blood count (CBC), serum electrolytes, blood urea nitrogen (BUN), creatinine, and glucose levels. Patients may have elevated white blood cell count, procalcitonin, and C­reactive protein.28–30
However, these inflammatory markers do not distinguish bacterial from viral pneumonia. Obtain pH, lactate, and arterial blood gas (ABG) for patients with acute respiratory failure. Venous blood gas (VBG) is not a suitable alternative to assess oxygenation.31–36
The usefulness of blood or sputum cultures varies based on many factors. Most patients do not require identification of a specific organism through blood or sputum analysis to direct antibiotic treatment. The incidence of positive blood cultures in nonhospitalized patients with CAP is low. Pathogen identification usually does not alter treatment, and most patients respond to empiric antibiotic treatment. Exceptions include patients with severe CAP, patients receiving empiric treatment for methicillin­resistant Staphylococcus aureus (MRSA) or Pseudomonas pneumonia, those who have had prior infections with these organisms, and patients who have received IV antibiotics or who have been hospitalized in the last  days. Sputum cultures have little yield and should be obtained only in patients with severe CAP or MRSA/Pseudomonas risk factors.9 Obtain a nasal swab for MRSA in patients who receive antibiotic coverage for MRSA, those hospitalized or who received IV antibiotics in the previous  days, and those with a history of MRSA colonization or infection in the past year.9
Urine antigen testing for Legionella can be obtained in patients with risk factors for outbreak exposure or in those with severe CAP.9
COMMUNITY­ACQUIRED PNEUMONIA (CAP)
INTRODUCTION
CAP is pneumonia acquired in a community setting. The definition of CAP excludes patients in whom pneumonia after hospitalization or pneumonia associated with mechanical ventilation develops.1
Patients with CAP are usually treated as outpatients unless pneumonia is moderate or severe or there are severe comorbidities.
Healthy patients with mild illness may not require extensive ancillary testing, but patients with CAP should be tested for COVID­19, RSV, and influenza when outbreaks are evident in the community.
Risk factors for CAP include age ≥65, pulmonary disease, asthma, poor oral health, malnutrition, immunosuppression, or toxic environmental pulmonary exposures. Patients who are younger or have mild disease are likely to have viral or atypical CAP. Those with severe illness are more likely to have a bacterial cause of CAP.
DIAGNOSTIC TESTING FOR CAP
Diagnostic testing, treatment, and disposition for CAP are based upon risk stratification tools that classify disease into low­risk and higher­risk severity. There are several clinical decision tools available. The Pneumonia Severity Index (PSI) is based on  variables and associated comorbidities (Tables 65­3, 65­4, and 65­5).37,38 The PSI ranks CAP severity based on the 30­ day risk of death and is a good tool for identifying low­risk patients. Class I (0.1% to .4% death) and class II (0.6% to .7% death) scores are typically considered low risk and eligible for outpatient treatment. Class III scores (0.9% to 28% death) are intermediate. Admit patients with class IV and V scores to the floor or ICU. The CURB­65 score (Table 65­6) is based on  variables (confusion, BUN, respiratory rate, BP, and age ≥65) and performs well in intermediate­ or high­risk patients admitted to the hospital.9,39
TABLE 65­3
Pneumonia Severity Index (PSI)
Step 1: If all criteria are zero, assign to risk class . Age >50 years old
Comorbid conditions
Neoplastic disease
Cerebrovascular disease
Heart failure
Renal disease
Liver disease
Physical examination abnormalities
Altered mental status
Pulse >125 beats/min
Respiratory rate >30 breaths/min
Systolic blood pressure <90 mm Hg
Temperature <35°C (95°F) or >40°C (104°F)
If any criteria are positive, go to Step , which advises collecting laboratory and other data and assigning points to determine risk class (Tables 65­4 and 65­5).
TABLE 65­4
Pneumonia Severity Index (PSI) Risk Classes II to V
Criteria Points
Demographics
Male sex Age in years
Female sex Age in years, minus 
Nursing home resident 
Coexistent illness
Neoplastic disease 
Heart failure 
Cerebrovascular accident 
Renal disease 
Liver disease 
Physical examination
Abnormal mental status 
Pulse ≥125 beats/min 
Respiratory rate >30 breaths/min 
Blood pressure (<90 mm Hg) 
Temperature <35°C (95°F) or >40°C (104°F) 
Ancillary studies
Arterial pH <7.35 
BUN ≥30 mg/dL (10.71 mmol/L) 
Sodium >130 mEq/L (130 mmol/L) 
Glucose >250 mg/dL (13.88 mmol/L) 
Hematocrit <30% 
PaO2 <60 mm Hg 
Pleural effusion 
Class assignment
Sum of points <70 = risk class II
Sum of points 71–90 = risk class III
Sum of points 91–130 = risk class IV
Sum of points >130 = risk class V
TABLE 65­5
Pneumonia Severity Index (PSI) Prediction of 30­day Mortality from Pneumonia
PSI Class Points Mortality (%) Treatment Recommendation
I No predictors .1 Outpatient
II <70 .6 Outpatient
III 71–90 .8 Individualized
IV 91–130 .2 Inpatient
V >130 .2 Inpatient
TABLE 65­6
CURB­65
Symptom Score
Confusion 
BUN >  mg/dL (>7 mmol/L) 
Respiratory rate ≥30 
BP <90 mm Hg, <60 mm Hg 
Age ≥65 
Decision Score Mortality
0–1 Outpatient treatment <5%
 Close outpatient follow­up or hospital observation <10%
 Hospitalize, possibly ICU <10%
4–5 Hospitalize, probably ICU 15% to 30%
DIAGNOSTIC TESTING
Although the first­line diagnostic imaging modality to evaluate for the presence of an infiltrate consistent with CAP is a chest x­ray, it has inherent limitations. Older patients, immunocompromised patients, those who are imaged earlier in the course of disease, and patients with left­sided infiltrates are more likely to have false­negative chest x­rays.40,41 Other risk factors for failure of infiltrate identification on chest x­ray include febrile neutropenia, emphysema, and volume depletion.40,42 Subtle chest x­ray findings that may be seen in patients with
CAP include small pleural effusions or a silhouette sign, which refers to obscuration of the right cardiac border caused by a right middle lobe infiltrate.43,44 One­view films are at risk for missing infiltrates in the retrocardiac and diaphragmatic regions, and thus two­view imaging is recommended if possible.45 Infiltrates on chest x­ray may take weeks to months to resolve after clinical resolution of CAP symptoms, so ongoing antibiotic therapy should not be guided by chest radiography findings alone.46
For patients with suspected severe disease, diagnostic testing with CBC, basic metabolic panel, and ABG is necessary to identify criteria for severe CAP (Table 65­4) and to determine the PSI score and need for hospital or ICU admission (Table 65­5). An albumin level is needed to calculate the SMART­COP score to determine need for ICU admission (Table 65­7).
TABLE 65­7
SMART­COP Score for Cap Severity47
Pneumonic Clinical Feature Points
S Systolic BP <  mm Hg 
M Multilobar infiltrates on CXR 
A Albumin < .5 g/Dl (<  g/L) 
R RR ≥  breaths/minute for patients ≤  years 
RR ≥  breaths/minute for patients >  years
T Tachycardia ≥ 125 bpm 
C Confusion ­ new 
O For patients ≤  years 
PaO2 <  mm Hg or
O2 saturation ≤ 93% or
PaO2/FiO2 ratio < 333 if on supplemental O2
For patients >  years
PaO2 <  mm Hg or
O2 saturation ≤ 90% or
PaO2/FiO2 ratio < 250 if on supplemental O2
P Arterial pH < .35 
Abbreviations: bpm = beats/minute; BP = blood pressure; CXR = chest x­ray; FiO2 = fraction of inspired oxygen; O2 = oxygen; PaO2 = partial pressure of oxygen; RR = respiratory rate.
For CAP patients being admitted to the hospital, obtain a MRSA nasal PCR swab as results may alter antibiotic therapy selection. Patients with severe CAP or those being empirically treated for
MRSA/Pseudomonas should undergo blood and sputum culture testing. Urinary antigen testing for Legionella and Streptococcus should be obtained in these patients as well.9 Tracheal suctioning is the gold­standard method for obtaining sputum cultures since it is at lower risk for contamination with GI or upper airway flora. For intubated patients, send endotracheal aspirates for gram stain and culture. Tracheal suctioning is uncomfortable and can induce hypoxia or mucosal bleeding. If tracheal suctioning is not technically feasible or available for awake patients, induced sputum is an alternative, albeit less effective, method.48
TREATMENT
The bioavailability of many antibiotics is similar in oral and IV formulations.49,50 In some patients with CAP, selected oral antibiotics offer several advantages, including easier administration, decreased cost, and lower risk of side effects such as superficial venous thrombosis that accompany IV administration of medications.51
For severe CAP, empiric anti­pseudomonal therapy should be administered and can be de­escalated if cultures are negative (Table 65­8). Those with suspected or proven MRSA CAP should receive anti­MRSA therapy with vancomycin or linezolid (Table 65­8). For patients with CAP secondary to suspected or proven P. aeruginosa or MRSA, the duration of antibiotic therapy should be a minimum of  days as opposed to  days.9
TABLE 65­8
CAP Treatment Based on Clinical Severity and Need for Hospitalization9
Outpatient treatment in those without major comorbidities
Azithromycin 500 mg PO on Do not use a macrolide if S. Treatment duration of at least  days day  and 250 mg on days pneumoniae resistance
2–5 >25%; use doxycycline or or amoxicillin
Clarithromycin 500 mg PO twice daily or clarithromycin XL, 1000 mg daily for  days or
Doxycycline 100 mg twice a day or
Amoxicillin  g three times Does not cover atypical daily bacteria
Outpatient treatment in those with comorbidities
Cefpodoxime 200 mg PO Treatment duration of at least  days
BID or
Cefuroxime 500 mg PO BID or
Amoxicillin­clavulanate 500 mg/125 mg TID or 875 mg/125 mg PO BID and
Azithromycin 500 mg PO once on day  and 250 mg once on days 2–5 or
Doxycycline 100 mg BID or monotherapy: For severe Only use if other antibiotics are inappropriate: resistance to other antibiotics; other antibiotics caused side effects requiring stopping
Levofloxacin 750 mg oral cephalosporin/PCN allergy treatment; treatment with other first­line antibiotics has failed
QD Do not use in myasthenia or gravis
Moxifloxacin 400 mg oral QD
Inpatient treatment
Ceftriaxone 1–2 g IV QD Clarithromycin is an Add vancomycin (15–20 mg/kg Q8–12h) or linezolid (600 mg IV or PO Q12h) if MRSA risk factors (prior positive respiratory culture within or alternative macrolide past  months)
Ampicillin­sulbactam  g IV
Q6h Respiratory and fluoroquinolone
Azithromycin 500 mg IV or monotherapy is an
PO QD alternative or
Doxycycline 100 mg IV or PO
BID or monotherapy:
Levofloxacin 750 mg PO/IV For severe
QD cephalosporin/PCN allergy or Do not use in myasthenia
Moxifloxacin 400 mg PO/IV gravis
QD
Inpatient treatment with P. aeruginosa risk factors (prior respiratory isolation) or severe CAP
Piperacillin­tazobactam .5 Add vancomycin (15–20 mg/kg Q8–12h) or linezolid (600 mg IV or PO Q12h) if MRSA risk factors (prior positive respiratory culture in past g IV Q6h  months) or
Cefepime  g IV Q8h or
Ceftazidime  g IV Q8h or
Imipenem 500 mg IV Q6h or
Meropenem  g IV Q8h or
Aztreonam  g Q8h
Hydrocortisone 200 mg QD Corticosteroids should be considered in severe CAP.53 The 2024 Society of Critical Care Medicine guidelines strongly recommend
IV as continuous infusion or administering corticosteroids for hospitalized adult patients with severe CAP (moderate certainty of evidence).54 However, 2019 IDSA divided doses (e.g.,  mg IV guidelines do not recommend the use of corticosteroids for severe CAP; this is a conditional recommendation based on moderate quality
Q6h IV) of evidence.54,55 or
Dexamethasone  mg IV QD
Abbreviations: BID = twice daily; IDSA = Infectious Diseases Society of America; IV = intravenous; PCN = penicillin; PO = oral; Q = every; QD = once daily; TID = three times daily.
For patients with HIV, if CD4 count is normal or >200 cells/mcL, treat according to CAP based upon risk stratification. If CD4 count is <200 cells/mcL or in cases of clinical AIDS, discuss with
Infectious Disease.
Antivirals should be considered in patients with influenza requiring admission or at risk of complication.9Dexamethasone should be administered in patients with COVID who are hypoxic.52
Treatment options depend upon stratification into acuity levels. Antibiotic choices are based upon initial ED diagnosis and empiric treatment (Table 65­8).
DISPOSITION
The PSI or CURB  may be used to determine the appropriate disposition for patients with CAP. Patients who are PSI class I or II are at low risk for mortality and are safe to be discharged.56
Additional considerations include the ability to obtain antibiotics, inability to follow up or return to the ED, inability to swallow, or malabsorptive syndromes. Those with PSI scores III or greater typically need hospital admission to the general floor or ICU. Those with CURB­65 scores of  can be followed closely as an outpatient or placed in brief hospital observation. Scores 3–
 require hospitalization.
An additional tool to assist with inpatient location decision­making is the SMART­COP score (Tables 65­7, 65­9).47 Scores ≥5 predict the need for intensive respiratory or vasopressor support
(IRVS) and need for ICU admission.47
TABLE 65­9
SMART­COP Score for CAP Disposition Decision for CAP47
Points Interpretation
0–2 Low risk
3–4 Moderate risk
5–6 High risk
≥  Very high risk
Patients with severe CAP need ICU admission. The American Thoracic Society (ATS) and Infectious Diseases Society of America (IDSA) classify severe CAP as meeting one major criterion or ≥3 minor criteria. Major criteria are the need for either mechanical ventilation or vasopressors for shock. Minor criteria include confusion/disorientation; hypothermia (<96.8° F/36°C); respiratory rate ≥30/min; hypotension needing aggressive IV fluids; multilobar infiltrates on chest x­ray; white blood cell count <4000/mcL from infection; PaO2 /FIO2 ratio ≤250; thrombocytopenia with platelets <100,000; BUN ≥20 mg/dL(7.14 mmol/L).9
PNEUMONIA IN SPECIAL POPULATIONS
PNEUMONIA IN PERSONS WITH ALCOHOL USE DISORDER
Patients with alcohol use disorder have a higher risk than many others for many lung diseases, including pneumonia, tuberculosis, pleurisy, bronchitis, empyema, and chronic obstructive pulmonary disease. Patients with alcohol use disorder often are undernourished, aspirate, have poor dentition, are smokers, and have concomitant liver disease. Patients with alcohol use disorder are more likely than persons without alcohol use disorder to have greater oropharyngeal colonization with gram­negative bacteria and are more likely to have pulmonary function abnormalities, including reduced lung volumes, increased airway resistance, and decreased diffusion capacity. In addition, alcohol depresses granulocyte and lymphocyte counts and impairs delivery of neutrophils to sites of infection.
S. pneumoniae is still the most common pathogen causing pneumonia in patients with alcohol use disorder, but Klebsiella species and Haemophilus species also are important agents of infection. In general, rates of pneumonia and death from pneumonia are higher in patients with alcohol use disorder than in those without it.
PNEUMONIA IN PERSONS WITH DIABETES
Diabetes mellitus is an independent risk factor for pneumonia. Patients with diabetes between the ages of  and  years are four times more likely to have pneumonia and influenza and two to three times more likely than patients without diabetes to die with pneumonia and influenza as an underlying cause of death. Pathogens that occur with increased frequency in patients with diabetes include S. aureus, gram­negative bacteria, mucormycosis, and Mycobacterium tuberculosis. Infections due to S. pneumoniae and influenza are associated with increased morbidity and mortality in patients with diabetes.
PNEUMONIA IN PREGNANT WOMEN
CAP in pregnancy is one of the most serious nonobstetric infections complicating pregnancy. Maternal mortality from antepartum pneumonia is approximately 3%. Pregnancy does not seem to alter the course of bacterial pneumonia, but the prognosis of viral pneumonia during pregnancy is more serious than in the nonpregnant patient.
Pregnant women in whom varicella pneumonia develops are five times more likely to be smokers and approximately  times more likely to have skin lesions suggestive of the disease. Order chest radiography in pregnant patients with symptoms of respiratory tract infection and varicella exposure. Pulse oximetry or arterial blood gas analysis helps identify patients with early respiratory compromise. IV acyclovir is often started in the ED, although there is little evidence that the timing of administration affects outcome.
Influenza, particularly the H1N1 influenza strain, triggers severe viral pneumonia in pregnant women. Death from H1N1­associated pneumonia in pregnant women was higher among women who have underlying medical conditions (asthma; diabetes; hypertension; malignancy; and rheumatologic, renal, and cardiovascular disease). The death rate did not stratify out by age, trimester, or ethnicity. Of note, the death rate was lower in women treated with a neuraminidase inhibitor and directly correlated to time from onset of symptoms to initiation of treatment with a neuraminidase inhibitor. Therefore, initiate treatment as soon as possible when a pregnant or postpartum patient presents with an influenza­like illness.
PNEUMONIA IN OLDER ADULTS
Pneumonia is the most common infection in older adults and represents the fifth leading cause of death in this population.57 The incidence of lower respiratory tract infection in older adults ranges from  to  cases per 1000 in the general population, with a mortality rate approaching 40%. Chronic obstructive pulmonary disease, heart failure, cardiovascular and cerebrovascular disease, lung cancer, dementia, diminished gag reflex, and other disorders that predispose older adults to aspiration make them more susceptible to infection.
Older adults are three times more likely to have pneumococcal bacteremia than younger patients. The mortality from pneumococcal pneumonia is three to five times greater in older adults
(up to 40%) than in those younger than  years. Atypical pathogens, such as Mycoplasma, are still more common in younger populations, but they do occur in older adults. Influenza is the most common serious viral infection in older adults.
Postinfluenza bacterial pneumonia is most commonly caused by S. pneumoniae, S. aureus, or H. influenzae. This usually presents as a worsening of respiratory symptoms after several days of improvement.
Older adults with pneumonia may present with falls, weakness, tremulousness, functional decline, GI symptoms, and delirium or confusion. They are more likely to be afebrile on presentation but are more likely than younger adults to have a serious bacterial infection when the temperature is higher than .3°C (100.9°F).
Up to one­third of older adults with CAP will not manifest leukocytosis. Poor prognostic indicators for pneumonia in older adults include hypothermia or a temperature >38.3°C (100.9°F), leukopenia, immunosuppression, gram­negative or staphylococcal infection, cardiac disease, bilateral infiltrates, and extrapulmonary disease. Older adults with pneumonia frequently require hospitalization, and about 10% may require intensive care.
PNEUMONIA IN NURSING HOME PATIENTS
Pneumonia is a major cause of morbidity, mortality, and hospitalization among nursing home residents, something made clearer during the SARS­CoV­2 pandemic, when viral pneumonia from this pathogen triggered high mortality.57,58 Nursing home–acquired pneumonia affects the oldest patients and those who have cerebrovascular disease, and it is associated with high mortality risk scores at ED presentation.
Nursing home patients are less likely than those living independently to have a productive cough or pleuritic chest pain, but more likely to be confused and have poorer functional status and more severe disease.58 Eight variables are significant independent predictors of pneumonia in nursing home patients: increased pulse rate, respiratory rate ≥30 breaths/min, temperature
≥38°C (100.4°F), somnolence or decreased alertness, presence of acute confusion, lung crackles on auscultation, the absence of wheezes, and an increased leukocyte count.22 A patient with one of these variables has a 33% chance of having pneumonia, whereas three or more variables suggest a 50% likelihood of pneumonia.22 Less than 10% of nursing home patients with pneumonia will have no respiratory symptoms. Fever, although nonspecific, is present in approximately 40% of cases of nursing home–acquired pneumonia.
In any pandemic, one pathogen may create a preponderance of pneumonia, as seen with the SARS­CoV­2 pandemic. Otherwise, the most frequently reported pathogens among patients with nursing home–acquired pneumonia are S. pneumoniae, gram­negative bacilli, and H. influenzae. Because nursing home patients live in close proximity to each other, residents are subject to outbreaks of influenza. Unfortunately, vaccination against influenza is only approximately 33% to 55% effective in preventing postinfluenza pneumonia in nursing home patients. M.
pneumoniae and Legionella are uncommon causes of pneumonia in nursing home patients.
Those with nursing home–acquired pneumonia are often admitted to the hospital for care, but many patients can be treated in nursing homes with either IM or PO antibiotics.59 Nursing home patients are at risk for the organisms linked to healthcare­associated pneumonia, and treatment for MRSA is recommended.60
PNEUMONIA IN PATIENTS WITH HIV
Among HIV­seropositive individuals, the incidence of bacterial pneumonia is .5 per 100 person­years, an incidence higher than Pneumocystis pneumonia in this population.23 Among hospitalized patients with HIV, the incidence of bacterial pneumonia is as high as .5 per 100 person­years. CAP accounts for three­fourths of bacterial pneumonia diagnosed in patients hospitalized with HIV infection. Compared with HIV­seropositive patients hospitalized without pneumonia, those admitted with pneumonia generally have a lower CD4+ T­cell count, a higher
Acute Physiology and Chronic Health Evaluation II score, a longer length of hospital stay, a greater chance of ICU admission, and a higher case­fatality rate.
S. pneumoniae is the most common cause of bacterial pneumonia in patients with HIV, recovered on blood culture in 60% of patients with HIV compared with 15% to 30% of patients without
HIV infection who have pneumococcal pneumonia. P. aeruginosa is a common cause of bacterial pneumonia in HIV­positive patients. HIV­positive patients with P. aeruginosa pneumonia are more likely to have a lower leukocyte and CD4+ T­cell count and a longer hospital stay but similar case fatality rate.
Opportunistic infections are more likely to occur with a lower CD4+ count. Bacterial infections are more likely to cause pneumonia when the CD4+ count is >800 cells/mcL.60 Between 250 and
500 cells/mcL,60 infection from M. tuberculosis, Cryptococcus neoformans, or Histoplasma capsulatum poses a greater risk. The risk of Pneumocystis pneumonia is more likely when the
CD4+ count is <200 cells/mcL.60
Bacterial pneumonia produces a pleural effusion in up to about 60% of patients with AIDS, most commonly due to S. pneumoniae and S. aureus. Non­Hodgkin lymphoma, Kaposi sarcoma, and adenocarcinoma of the lung are the three leading noninfectious causes of pleural effusion in patients with HIV. Patients with Kaposi sarcoma, cytomegalovirus pneumonia, and hydrostatic pulmonary edema may present with alveolar hemorrhage as seen by bloody fluid on bronchoalveolar lavage or frank hemoptysis. Pulmonary nodules in patients with HIV are often caused by opportunistic infection, bacterial pneumonia, and tuberculosis. Fever, cough, and a nodule size of <1 cm are independent predictors of an opportunistic infection. Miliary pneumonia on CT scan or chest radiograph may represent varicella pneumonia.
PNEUMONIA IN PATIENTS POST TRANSPLANT
Bacterial pneumonia is less common after renal transplantation but more common in patients receiving liver, heart, or lung transplants during the first  months after surgery, compared with other surgical patients. Gram­negative bacilli (especially P. aeruginosa associated with mechanical ventilation), S. aureus, and Legionella predominate in the first  months after transplantation. K. pneumoniae, Escherichia coli, and fungi also may cause pneumonia in this time period. These early­onset nosocomial bacterial pneumonias have a high mortality rate, approximately 33%.
Cytomegalovirus, Pneumocystis jirovecii, and fungal infections, especially Aspergillus species, are opportunistic infections and may be seen in the first  months after surgery. After  months posttransplant, bacteria more typical of CAP (S. pneumoniae, H. influenzae) are the most likely pathogens and portend less mortality (see Chapter 297, “The Transplant Patient”). Notably, many with organ transplantation have robust responses to protective vaccination, including that for SARS­CoV­2; this means a higher risk of infection and poor outcome is retained for many even with vaccination.
ASPIRATION PNEUMONIA
INTRODUCTION AND EPIDEMIOLOGY
Aspiration is the inhalation of oropharyngeal contents into the respiratory tract.61–64 Aspiration pneumonia is the inhalation of infectious material from the oropharynx into the lower respiratory tract that causes infection of the lung parenchyma.64 Aspiration alone does not cause pneumonia. However, aspiration is a common trigger—note that hospitalized or care facility patients are often much more recumbent than those at home and also have acquired and severe forms of pneumonia, suggesting a link with aspiration facilitated by positioning (especially during meals).
Approximately half of healthy adults aspirate when sleeping. Aspiration pneumonitis is an irritation and inflammatory response to aspirated material. Pneumonitis can develop when the aspirated material has a low pH (<2.5) or when other components of the aspirate cause an inflammatory response.
PATHOPHYSIOLOGY
Aspiration pneumonia is a result of a complex interplay of the aspirated material, aspirated volume, pH, patient physiology, and pulmonary defense mechanisms. There is a large overlap in the etiology, symptoms, and bacterial flora of aspiration pneumonia and CAP, which often makes clinical differentiation difficult. In addition, over the years, microbiology patterns of aspiration pneumonia have changed.65
Risk factors for aspiration pneumonia include prior history of aspiration, altered level of consciousness, anatomic abnormality of the airway, neuromuscular disease, GI disease, retained gastric contents, percutaneous gastric or jejunal tube, nasogastric tube, prolonged supine position, poor oral hygiene, and advanced age66 (Table 65­10).
TABLE 65­10
Risk Factors for Aspiration64,66
Advanced age
Altered level of consciousness
Anatomic abnormality of upper airway
Dementia
Esophageal disorders
Gastroesophageal reflux
Neuromuscular/neurologic disease
Poor oral hygiene
Prior history of aspiration
Prolonged supine position
Retained gastric material
Tube feedings
Oral hygiene risk factors for development of aspiration pneumonia include multiple decayed teeth, gingivitis, periodontitis, periodontal disease–causing organisms in saliva, and dental plaque.67 Medications that decrease saliva production also predispose to higher oral bacterial counts. Medications (diuretics, anticholinergics, anxiolytics, antipsychotics, levodopa) can reduce salivary flow and lead to increased oral bacterial counts.68
Aspiration in younger patients tends to result from obtundation secondary to intoxication, seizures, or medication overdose. If a large volume of fluid is aspirated, it may lead to asphyxia.
Younger patients with aspiration pneumonia may remember the aspiration incident several days earlier or have a history of substance abuse with frequent periods of amnesia or loss of consciousness.
Aspiration in older patients results from preexisting risk factors such as enteral feeding, anatomic abnormalities (head, neck, and esophagus), physiologic abnormalities of the mechanisms of deglutition and decreased immune response (cellular and humoral), decreased mucosal ciliary function, decreased mucus production, and decreased cough reflex. An increased stimulus is needed to provoke a cough reflex in older patients.69
Aspiration pneumonia is the second leading cause of infection in nursing homes, behind urinary tract infections.69 It is the leading cause for transfer from nursing home to the hospital and the leading cause of death in nursing home patients.69 In nursing home patients, the aspiration incident may not be witnessed, and time of aspiration will be unknown.
CLINICAL FEATURES AND TREATMENT
Symptoms of aspiration pneumonitis tend to develop rapidly, with onset of shortness of breath, bronchospasm, hypoxia, and low­grade fever within a few hours of the aspiration. Symptoms typically resolve within  hours.70
Recent research by Driver et al25 demonstrated that aspiration pneumonia developed in 8% of patients after emergency endotracheal intubation. There were no intubation factors that were different in those patients in whom aspiration pneumonia developed and those it did not.71 The National Emergency Airway Registry III investigators demonstrated witnessed aspiration in 5% of emergency endotracheal intubations,72 and occult aspiration occurs in 22% to 50% of prehospital emergency intubations.73
Aspiration syndromes include aspiration pneumonia, aspiration pneumonitis (Mendelson syndrome), acute airway obstruction, exogenous lipoid pneumonia, chronic interstitial fibrosis,
Mycobacterium fortuitum pneumonia, and diffuse aspiration bronchiolitis76 (Table 65­11).
TABLE 65­11
Aspiration Syndromes64,74
Acute airway obstruction
Aspiration pneumonias
Aspiration pneumonitis
Chronic interstitial fibrosis
Diffuse aspiration bronchiolitis
Exogenous lipoid pneumonia
Mycobacterium fortuitum pneumonia
There is a broad spectrum of physical presentations for patients with aspiration pneumonia. The nursing home patient may appear in no distress and present with decreased appetite, weakness, altered sensorium, or fever; vital signs may be normal or show fever, tachycardia, tachypnea, and hypotension. Younger patients with acute aspiration of solid or liquid material may present in a more dramatic fashion with cough, shortness of breath, and possible hypoxia. Rales, rhonchi, and wheezes may exist. Unilateral (total occlusion) or sonorous (partial occlusion) breath sounds may be present in the case of occlusion of a mainstem bronchus. Aspiration of irritative substances such as oils, sterile gastric contents with pH of ≤2.5, activated charcoal, diatrizoic acid, or alendronate sodium all can cause an intense inflammatory reaction. Aspiration of pills such as potassium, iron, or metformin can cause local inflammation and may lead to bronchial stenosis. Sucralfate and pomegranate supplements can expand when in contact with the bronchial mucosa and cause bronchial obstruction.75
A few patients may require chest CT to evaluate for lung abscess or foreign body, as aspiration is a risk factor for pulmonary abscess formation.
After obtaining blood (and possibly adequate sputum) cultures, initiate antibiotic treatment but do not delay antibiotics to obtain cultures. Clindamycin, a carbapenem, ampicillinsulbactam, and moxifloxacin are all reasonable treatments for suspected community­acquired aspiration pneumonia.65 Bronchodilators aid aspiration­induced bronchospasm.
DISPOSITION
Healthy persons who aspirate small volumes of nontoxic material may be observed for a short time, up to  hours, and if without signs of distress and reliable, discharged to return for worsening symptoms. Antibiotic treatment is not needed for witnessed aspiration of a small amount of nontoxic liquid provided the patient's symptoms (cough, low­grade fever) resolve within  to  hours.74
Most patients with community­acquired aspiration pneumonia require admission. It is difficult to clinically distinguish aspiration pneumonia from non–aspiration­related pneumonia.65 The history and clinical environment (older patient, nursing home, sedation, dysphagia, poor dentition, substance use) will lead to an impression of aspiration pneumonia. The admission guidelines for other pneumonias also apply to aspiration pneumonia.
NONINFECTIOUS PULMONARY INFILTRATES
INTRODUCTION AND EPIDEMIOLOGY
A noninfectious pulmonary infiltrate is a radiologic abnormality, often with symptoms, that is not due to an infection. Suspect it when no other infectious findings exist or after antibiotics fail to improve symptoms. Noninfectious infiltrates occur in response to a wide variety of pathophysiologic processes involving the respiratory, cardiovascular, and immune systems or may be due to the infiltration of malignant cells. Some common noninfectious causes of pulmonary infiltrates are heart failure, aspiration pneumonitis, and pulmonary embolism.
CLINICAL FEATURES
The main symptom of noninfectious pulmonary infiltrates is dyspnea. Some disorders present with hemoptysis, cough, chest pain, or fatigue. Fever can also be a symptom of autoimmune disease exacerbation. It may be impossible to clinically differentiate a noninfectious source from an infectious source of fever in the ED. Table 65­12 lists the most common causes of acute noninfectious pulmonary infiltrates and their key clinical features, pathophysiology, and chest radiology findings.75–82 Diffuse alveolar hemorrhage is the most common manifestation of pulmonary vasculitis from asymptomatic chest radiograph abnormalities to severe respiratory failure.79,83
TABLE 65­12
Noninfectious Causes of Pulmonary Infiltrates
Disease Pathophysiology Chest Radiography Findings Symptoms
Allergic bronchopulmonary Aspergillosis Hypersensitivity reaction to Aspergillus fumigatus. Most common in patients Branching tubular opacities may Dyspnea, wheezing, productive with asthma or cystic fibrosis. be seen, usually predominantly cough; may have hemoptysis and
Eosinophils fill small airways and alveolar spaces due to inflammation. or exclusively involving upper occasionally fever.
Bronchiectasis. lobes.
Acute eosinophilic lung disease Cause unknown. Association with new or binge smoking. Eosinophils Nonspecific bilateral Dyspnea, fever, nonproductive accumulate in distal airways and alveolar and interstitial spaces. consolidations and reticular cough, and wheezing. In acute opacities. forms, hypoxia and potential for rapid progression to respiratory failure. Steroid responsive.
Hypersensitivity pneumonitis (extrinsic Inflammation of the alveoli secondary to hypersensitivity in response to Diffuse micronodular interstitial Fever, chills, malaise, cough, allergic alveolitis) inhaled organic dust. infiltrates. May see ground­glass chest tightness, dyspnea, and densities in the lower or mid­lung headache.
fields. Bases spared.
Organizing pneumonia (bronchiolitis Inflammation of the bronchioles and surrounding tissues, leading to loss of Patchy multifocal alveolar Cough, dyspnea, fever.
obliterans organizing pneumonia [BOOP]) the integrity of the bronchioles and organizing pneumonia without infection. infiltrates without effusion.
Cryptogenic organizing pneumonia if immunocompromised or connective tissue diseases (e.g., SLE, rheumatoid arthritis, dermatomyositis).
Antinuclear cytoplasmic antibody (ANCA)– Both systemic vasculitides of small­ and medium­sized vessels of unknown Bilateral peripheral, patchy, Cough, dyspnea, allergic associated vasculitides: granulomatosis origin. Granulomatosis with polyangiitis is characterized by necrotizing alveolar infiltrates and nodules. rhinitis/sinusitis. May have skin, with polyangiitis (Wegener granulomatosis, granulomatous vasculitis with involvement of upper respiratory tract, lung coronary, or intestinal eosinophilic granulomatosis with parenchyma, and kidneys. Churg­Strauss syndrome is an allergic eosinophilic involvement.
polyangiitis (Churg­Strauss syndrome) condition. Most patients are asthmatic.
Acute interstitial pneumonia Idiopathic or secondary (chemical agents). Three stages: interstitial edema Normal for first 12–24 h. Bilateral Rapid progression to respiratory spreads to alveoli with hemorrhage and hyaline membrane formation opacities with sparing of failure. Mortality rate higher in
(exudative), organization of fibrinous exudate (proliferative), scarring and costophrenic angles. Minimal or those with comorbidities.
cyst formation and honeycomb fibrosis (fibrotic). no pleural effusion. “White lung” due to extensive consolidation.
Sarcoidosis Systemic granulomatous disease of unknown etiology. Noncaseating Four stages: bilateral hilar Dyspnea, cough, weight loss; skin pulmonary granulomas. adenopathy; bilateral hilar lesions may also be found. May adenopathy with reticulonodular be asymptomatic.
pulmonary opacities; pulmonary opacities only; pulmonary fibrosis.
Anti–glomerular basement membrane Autoimmune disease affecting the lungs and kidney due to autoantibodies Diffuse, bilateral, predominantly Fatigue, dyspnea, cough with antibody disease (Goodpasture syndrome) to type IV collagen. Causes hemorrhagic interstitial pneumonitis. alveolar densities with sparing of hemoptysis; may have the apices and costophrenic simultaneous hematuria.
angles.
Drug­induced pneumonitis Causes include chemotherapeutic, immunosuppressive, antimicrobial, and Typically, bilateral interstitial Cough, mild fever, dyspnea.
herbal agents. infiltrates. Potentially hypoxia.
Chemical pneumonitis Inflammatory reaction to the presence of foreign substance, such as barium, Diffuse alveolar and interstitial History of exposure or aspiration petroleum distillates, pesticide, or irritating gases. infiltrates. of substance; acute dyspnea, cough, and possibly wheezing.
Radiation pneumonitis Interstitial pulmonary inflammation seen in 5%–15% of patients with Subtle hazy ground­glass Symptoms occur 1–6 months thoracic radiation treatment. densities to marked patchy after treatment: low­grade fever, infiltrates or homogenous cough, fullness in the chest.
consolidation. Air bronchograms are commonly present.
Alveolar cell carcinoma, often called Adenocarcinoma originating in a terminal bronchiole and spreading across Peripheral alveolar infiltrates. Often severe coughing dyspnea bronchiolar or bronchioloalveolar the alveolar walls. May see peripheral nodule or and copious sputum production.
carcinoma mass. May mimic pneumonia, but no fever, leukocytosis, or response to antibiotics.
Leukemic infiltrates Most common in myeloid leukemia when peripheral blast cell counts exceed Interstitial or alveolar infiltrates. Respiratory distress, hypoxemia,
100,000/mcL. Primitive myeloid leukemic cells invade through the Diffuse infiltrates associated with and may progress to respiratory endothelium of the lung capillary beds, yielding hemorrhage. hypoxia and need for intubation; failure.
focal infiltrates associated with coexistent pneumonia.
Fat emboli ED presentations are typically after trauma, associated with long bone Interstitial prominence, Dyspnea, cough, hemoptysis, and fracture. suggesting interstitial edema. pleural pain. May be associated
Radiographic findings may be with confusion, stupor, delirium, delayed by hours after trauma. and a petechial skin rash, most commonly on the chest.
Alveolar hemorrhage In the setting of chemotherapy induction for leukemia and Focal or diffuse alveolar Dyspnea, hemoptysis; symptoms thrombocytopenia (<20,000/mcL), hemorrhage filling alveoli is common infiltrates. are frequently less severe than from endobronchial and interstitial sources. Also seen with SLE. radiographic appearance would predict.
Acute respiratory distress syndrome Reaction of the lung to a number of precipitating causes, including sepsis, Classically, patchy peripheral Hypoxia, tachypnea, rales.
trauma, surgeries, transfusions, and therapeutically induced infiltrates that extend to the immunosuppression. lateral lung margins suggest the diagnosis.
Abbreviation: SLE = systemic lupus erythematosus.
TREATMENT
Treatment is guided by the main differential diagnosis. Assess gas exchange with pulse oximetry in all patients and use selective arterial blood gas analysis in patients who are ill, hypoxemic, or with underlying chronic lung disease; use noninvasive or mechanical ventilation as needed. Definitive treatment for noninfectious pulmonary disease depends on the underlying cause and will occur after ED stabilization. Many of the disorders listed in Table 65­12 are treated acutely with corticosteroids such as methylprednisolone (0.5–1 g IV). Additional immunosuppressive drugs may be initiated by the admitting physician.
DISPOSITION AND FOLLOW­UP
Patients in whom a noninfectious cause of pulmonary infiltrates is suspected require testing beyond the capabilities of the ED. A decision to admit comes from the severity of the medical illness, with attention to hypoxemia, hypercapnia, and work of breathing. Stable patients with mild symptoms may be referred to a pulmonologist, rheumatologist, or another specialist for further outpatient evaluation and treatment.


## Page 25

University of Pittsburgh
Access Provided by:

Chapter 65: PNEUMONIA: Community­Acquired Pneumonia, Aspiration Pneumonia, and Noninfectious Pulmonary Infiltrates, Jessica PPaegllee t2ie5 r/; 
Alex Koyfman; Brit Long; Eric Anderson; Simone French; Gerald E. Maloney
. Terms of Use * Privacy Policy * Notice * Accessibility

