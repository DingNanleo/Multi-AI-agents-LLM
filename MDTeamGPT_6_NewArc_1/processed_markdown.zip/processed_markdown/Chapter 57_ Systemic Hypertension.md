## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 57: Systemic Hypertension
Brigitte M. Baumann
INTRODUCTION AND EPIDEMIOLOGY
1­5
Hypertension affects approximately 40% of the U.S. population, and 1% to 6% of all ED patients present with severe hypertension. Of the latter,
2­5 between one quarter and one half will have end­organ damage. Risk factors for the development of acute hypertensive events include obesity,
 cigarette smoking, older age, lack of access to health care, and noncompliance with antihypertensive medications.

Chronic hypertension is categorized into three classifications: prehypertension, stage  hypertension, and stage  hypertension (Table 57­1).
TABLE 57­1
Categories of Blood Pressure in Adults* BP Category Systolic BP (mm Hg) Diastolic BP (mm Hg)
Normal <120 and <80
Elevated 120–129 and <80
Hypertension
Stage  130–139 or 80–89
Stage  ≥140 or ≥90
Abbreviation: BP = blood pressure.
*Data adapted from: 2017 High Blood Pressure Clinical Practice Guideline: Executive Summary, where BP is based on an average of ≥2 careful readings obtained on
≥2 occasions.7
Hypertensive crisis is an acute elevation of blood pressure, where the systolic blood pressure is >180 mm Hg and/or the diastolic blood pressure is
>120 mm Hg. There are two forms of hypertensive crisis.
Hypertensive emergency is a hypertensive crisis (systolic blood pressure >180 mm Hg and/or diastolic blood pressure >120 mm Hg) with
 concomitant end­organ damage; the targeted end organs include the brain, heart, aorta, kidneys, or eyes (Table 57­2).
TABLE 57­2
Hypertensive Emergencies
Diagnostic
Signs and Symptoms Evidence of Acute End­Organ Damage
Category
Acute aortic Chest pain, back pain Abnormal CT angiogram of chest and abdomen/pelvis or transesophageal
 dissection Unequal blood pressures (>20 mm Hg echocardiogram of the aorta
Chapter 57: Systemic Hypertension, Brigitte M. Baumann 
©2025 McGraw Hill. All dRififgehretsn cRe)e isne urpvpeedr .e x tTreemrmitsie sof Use * Privacy Policy * Notice * Accessibility
Acute Shortness of breath Interstitial edema on chest radiograph pulmonary edema
Acute Chest pain, nausea, vomiting, diaphoresis Changes on ECG or elevated levels of cardiac biomarkers myocardial infarction
Acute coronary Chest pain, nausea, vomiting, diaphoresis Clinical diagnosis, changes on ECG, or elevated levels of cardiac biomarkers syndrome
Acute renal May have systolic or diastolic abdominal Elevated serum creatinine level, proteinuria failure bruit
Severe Seizures, shortness of breath, headache, or Proteinuria (no longer required for the diagnosis of preeclampsia), low platelet count, preeclampsia, vision abnormalities (blurred vision, renal insufficiency, elevated liver enzyme levels, pulmonary edema eclampsia flashing lights, scotomata)
Hypertensive Blurred vision Retinal hemorrhages and cotton­wool spots (Figure 57­1), hard exudates, and sausageretinopathy shaped veins
Hypertensive Altered mental status, nausea, vomiting, May see papilledema or arteriolar hemorrhage or exudates on funduscopic examination, encephalopathy headache may note cerebral edema with a predilection for the posterior white matter of the brain on MRI
Subarachnoid Headache, focal neurologic deficits Abnormal CT of the brain; red blood cells on lumbar puncture hemorrhage
Intracranial Headache, new neurologic deficits Abnormal CT of the brain hemorrhage
Acute ischemic New neurologic deficits Abnormal MRI or CT of the brain stroke
Acute Bleeding unresponsive to direct pressure Clinical diagnosis; manifestations of other hypertensive emergencies perioperative hypertension
Sympathetic Anxiety, palpitations, tachycardia, Clinical diagnosis in the setting of sympathomimetic drug use (i.e., cocaine or crisis* diaphoresis amphetamines) or pheochromocytoma (24­h urine assay for catecholamines and metanephrine or plasma fractionated metanephrines)
*In this syndrome, acute end­organ dysfunction may not be measurable, but complications affecting the brain, heart, or kidneys may occur in the absence of acute treatment.
FIGURE 57­1. Hypertensive retinopathy. Scattered flame (splinter) hemorrhages and cotton­wool spots (nerve fiber layer infarcts) in a patient with headache and a blood pressure of 234/120 mm Hg.
Hypertensive urgency is a controversial term—some believe it does not exist distinctly apart from severe hypertension—denoting a marked and
 acutely elevated blood pressure without acute or worsening target organ dysfunction. Often, an arbitrary blood pressure of >180/120 mm Hg is cited as an indication for rapid pharmacologic intervention (typically parenteral) to reduce blood pressure within hours. There is no clinical benefit of such
7­9 treatment (hence the concern about the term urgency), and precipitous drops in blood pressure can be harmful. Current recommendations for
 patients with hypertensive urgency are reinstitution or intensification of oral antihypertensive therapy and prompt outpatient follow­up. Gradual blood pressure reduction should occur over days to weeks.
PATHOPHYSIOLOGY
At baseline, chronic hypertensive patients have biochemical and structural changes in the arterial walls that shift the vascular autoregulatory curve,
10­12 requiring higher arterial pressures to maintain end­organ blood flow, notably in the brain. Eventually, the ability to adapt is passed. The resultant mechanical wall stress and endothelial injury lead to increased permeability and hyperperfusion of the cerebral, cardiac, and renal vascular beds. This may be followed by activation of the coagulation cascade and platelets, and deposition of fibrin results in fibrinoid necrosis of the arterioles. Clinically,
 this produces hematuria (involvement of the renal vasculature), arterial hemorrhages, or exudates on funduscopic examination. Further contributing to the damage are prostaglandins, free radicals, cytokines, and mitogenic, chemoattractant, and proliferation factors, causing endothelial
,12 damage, smooth muscle proliferation, and thrombosis. The renin­angiotensin system may also be activated, which leads to vasoconstriction.
Pressure natriuresis occurs, leading to volume depletion, prompting additional release of vasoconstrictors from the kidney. These combined effects produce hypoperfusion, ischemia, and dysfunction of end organs. Endothelial dysfunction from such crises can persist for years after the acute
 event.
CLINICAL FEATURES
Measure blood pressure in both arms in a narrow time interval while the patient is quietly resting. Check blood pressure several times before starting antihypertensive therapy. Blood pressure differences between extremities can result from aortic dissection, coarctation, peripheral vascular disease, and some unilateral neurologic and musculoskeletal abnormalities. Interarm blood pressure differences exist in some normal individuals, particularly the elderly, due to the loss of vascular elasticity or asymmetrical atheromatous narrowing of subclavian or brachial arteries. Although no guidelines regarding blood pressure disparities exist, an interarm difference >10 to  mm Hg is meaningful and increases long­
,15 term risks of cardiovascular events and mortality. When an interarm blood pressure difference is detected, treat the higher blood
 pressure and ensure that subsequent measurements are made on the same arm. Avoid wrist oscillometric devices as these give lower
 readings than upper arm measurements.
A modest drop (up to  mm Hg) in systolic and diastolic blood pressures can occur absent therapy in patients presenting with elevated blood
,18 pressures. Conversely, do not discount a diagnosis of hypertensive emergency in patients with no prior history of elevated blood pressure because
 up to 16% have no history of hypertension.
Table 57­3 lists the proportion of patients who present with elevated blood pressure by stroke subtypes, aortic dissection subtypes, heart failure, and acute coronary syndrome. Although elevations in blood pressure accompany most of these presentations, note that severe elevations of blood pressure are far less common in presentations typically labeled as hypertensive emergencies.
TABLE 57­3
Specific Diseases Associated With Elevated Blood Pressures
Disease Threshold Value Raising Risk % of Patients With Elevated Pressures
Subarachnoid hemorrhage19 ≥140 mm Hg SBP 100%
Ischemic stroke19,20 ≥140 mm Hg SBP 77%–82%
≥160 mm Hg SBP 47%–54%
Intracerebral hemorrhage19 ≥140 mm Hg SBP 75%
≥160 mm Hg SBP 27%
Type B aortic dissection21,22 ≥140 mm Hg SBP or ≥90 mm Hg DBP 67%–77%
Type A aortic dissection23 >150 mm Hg SBP 36%–74%
Acute heart failure24,25 >140 mm Hg SBP 52%–54%
NSTEMI­ACS24,26 ≥140 mm Hg SBP 57%–59%
≥160 mm Hg SBP 31%
Abbreviations: DBP = diastolic blood pressure; NSTEMI­ACS = non–ST­segment elevation myocardial infarction acute coronary syndrome; SBP = systolic blood pressure.
CHEST PAIN AND SEVERE HYPERTENSION
Rapid identification of acute aortic dissection is critical because delays in management increase mortality. Differentiating aortic dissection from the more common acute coronary syndromes is imperative given that blood pressure control differs in these two disorders and anticoagulation can prove
 catastrophic in acute aortic dissection.
Acute aortic dissection presents with abrupt, sudden onset of pain, usually in the chest, often described as tearing or ripping, and radiating to the
,23,28­30 interscapular region (see Chapter , “Aortic Dissection and Related Aortic Syndromes,” for more discussion).
ACUTE NEUROLOGIC SYMPTOMS AND SEVERE HYPERTENSION
Elevated blood pressure, headache, and focal neurologic deficits are associated with either ischemic or hemorrhagic strokes (see Chapter 167, “Stroke
Syndromes”) (Figure 57­2).
FIGURE 57­2. Intracerebral hypertensive hemorrhage. Noncontrast head CT scan with acute intraparenchymal hemorrhage, mass effect, midline shift, and intraventricular extension. [Image used with permission of Todd Siegal, MD.]
Hypertensive encephalopathy is a clinical diagnosis made after excluding focal ischemia or bleeding. Patients with this condition have altered mental status, headache, vomiting, seizures, or visual disturbances, and most patients will have papilledema. When MRI findings demonstrate reversible edema that is predominantly posterior (occipital), the posterior reversible encephalopathy syndrome (Figure 57­3) exists, which carries a poor prognosis.
FIGURE 57­3. Axial fluid­attenuated inversion recovery MRI showing white matter hyperintensity in the occipital lobes bilaterally consistent with posterior reversible encephalopathy syndrome. The patient’s confusion improved with blood pressure control. Repeat MRI after several days of therapy demonstrated remarkable improvement. [Image used with permission of Michael Farner, MD.]
ACUTE RENAL FAILURE, PERIPHERAL EDEMA, AND SEVERE HYPERTENSION
Patients with new­onset renal failure may have peripheral edema, oliguria, loss of appetite, nausea and vomiting, orthostatic changes, or confusion.
However, some patients have few or no specific symptoms (see Chapter , “Acute Kidney Injury”). Elevated serum creatinine confirms the diagnosis, and urinary sediment is also abnormal.
PREECLAMPSIA AND ECLAMPSIA
Preeclampsia presents with elevated blood pressure (systolic blood pressure ≥140 mm Hg or diastolic blood pressure ≥90 mm Hg) on two occasions at least  hours apart in pregnant patients beyond the 20th week of gestation. Eclampsia is the progression of preeclampsia to new­onset grand mal
 seizures in the absence of other neurologic conditions that could account for the seizure (see Chapter 100, “Maternal Emergencies After  Weeks of
Pregnancy and in the Peripartum Period”).
SYMPATHETIC CRISIS AND SEVERE HYPERTENSION
There are four settings in which an excess of catecholamines can result in a hypertensive emergency. An acute catecholaminergic syndrome may occur with abrupt discontinuation of oral or transdermal clonidine. This withdrawal syndrome is potentiated by concomitant β­blocker therapy due to unopposed α­mediated vasoconstriction.

Pheochromocytoma is rare, and between 5% and 20% of tumors are malignant. Patients may experience life­threatening hypertension. Signs and symptoms of pheochromocytoma include asymptomatic periods punctuated by episodic headache, elevated blood pressure, tachycardia, and diaphoresis.
Sympathomimetic drugs such as cocaine, amphetamines, phencyclidine hydrochloride, and lysergic acid diethylamide can precipitate a
 hypertensive emergency, with tachycardia, diaphoresis, chest pain, and mental status changes. Patients receiving monoamine oxidase inhibitors
 who consume tyramine­containing foods may develop a hyperadrenergic state.
Autonomic dysfunction due to spinal cord or severe head injury or abnormalities such as spina bifida may also present as a hypertensive emergency, with the diagnosis made clinically. Often, the associated blood pressure measurements are marginally elevated in this condition; do not let
“near normal” values falsely exclude this diagnosis.
ASYMPTOMATIC PATIENTS WITH SEVERE HYPERTENSION

Formal recommendations for the evaluation of an ED patient presenting with asymptomatic but severe hypertension do not exist. Commonly ordered tests include basic metabolic panel, ECG, chest radiograph, and urinalysis, but in the asymptomatic population, abnormal results attributable to acute
,35 hypertensive target organ injury are found in <6% of patients. Until more data are available, base ED evaluation on the patient complaint, history, and review of systems, and perform selected testing.
TREATMENT
Patients presenting with a hypertensive emergency should be admitted to a critical care setting for continuous monitoring of blood pressure and target organ function. Use parenteral antihypertensive agents to reduce systolic blood pressure no more than 25% in the first hour; if stable, then reduce to 160/100 mm Hg over the next  to  hours and then to normal over the following  to  hours. Balance the reduction of blood pressure with avoidance of hypoperfusion of cerebral, coronary, and renovascular beds, which can exacerbate end­organ damage. More aggressive blood pressure control is needed for acute aortic dissection, pheochromocytoma crisis, severe preeclampsia or eclampsia, and acute intracerebral
 hemorrhage. Table 57­4 lists agents used in the management of hypertensive emergencies categorized by diagnosis. In selecting therapy, be familiar with the administration of the selected agent and establish a target range for blood pressure reduction.
TABLE 57­4
Treatment of Hypertensive Emergencies by Diagnosis
Diagnosis Therapy Goals Agents Risks Comments
Aortic dissection Reduce shear forces by ↓ BP and PR Esmolol* IV bolus, then β­blockers: Respiratory Measure BP in both arms and treat
Lower SBP to 100–120 mm Hg continuous distress in asthma, COPD higher BP
↓ PR ≤60 beats/min7,36 infusion7,36,37 OR patients; test dose of Always use β­blocker prior to esmolol recommended, vasodilators; nitroprusside alone
Labetalol* IV bolus or switch to diltiazem if increases wall stress from reflex continuous esmolol intolerant tachycardia; cyanide and infusion7,36,37 thiocyanate toxicity in patients with
Nicardipine IV reduced renal function or therapy continuous infusion
>24–48 h
(after β­blocker)7,38
Nitroprusside continuous infusion
(after β­blocker)7
Acute Reduce BP by 20%–30%; diuresis Nitroglycerin* SL, ACE inhibitors, can IV nitrates dilate capacitance hypertensive through vasodilation; symptomatic topical, or IV continuous worsen renal function vessels at low doses; higher doses pulmonary relief39 infusion7,39,40 ACE inhibitors: Avoid dilate arterioles and lower BP edema hypotension and use Mixed outcomes (favorable and
Clevidipine IV with caution; some unfavorable) with nesiritide, with continuous infusion7 patients experience a most recent ASCEND­HF trial
Nitroprusside IV negative inotropic effect showing no difference in dyspnea continuous
Nitroprusside: Cyanide and mortality when compared to infusion7,39,40 and thiocyanate toxicity placebo4
Enalaprilat IV40 in patients with reduced
Nicardipine IV renal function or therapy continuous infusion7
>24–48 h
Nesiritide IV41
Acute Reduce ischemia; avoid ≤25% Nitroglycerin* SL, Do not give nitrates in β­blockers: Monitor for myocardial reduction of MAP7 aerosol, or IV continuous patients who have taken hypotension; consider RV infarct and infarction infusion7,42,43 phosphodiesterase volume depletion if this occurs inhibitors for erectile SBP >185 mm Hg or DBP > 110 mm
Esmolol* IV continuous dysfunction ≤24 h for Hg is a relative contraindication for infusion7 sildenafil and  h for thrombolytics43
Labetalol or tadalafil42 metoprolol IV
Do not give β­blockers bolus7,42,43 in CHF, low­output states, or other contraindications to β­ blockers
Acute Reduce excessive sympathetic drive Benzodiazepine* IV Benzodiazepines may Benzodiazepines are first­line sympathetic and symptomatic relief bolus33,44 induce respiratory agents for cocaine­induced crisis (cocaine, Aim for SBP <140 mm Hg in the first depression; monitor hypertension
Nitroglycerin SL, amphetamines, hour7 topical, or IV continuous patients closely Phentolamine is first­line therapy
MAOI toxicity) Labetalol remains for pheochromocytoma infusion42,44 controversial, especially Calcium channel blockers in
Phentolamine* IV or for cocaine­induced cocaine­induced hypertension are
IM32 hypertension; if given, considered third­line agents, after
Nicardipine or administer along with a benzodiazepines and nitroglycerin44 clevidipine IV nitrate44 continuous infusion7
Acute renal Reduce BP by no more than 20% Fenoldopam IV Avoid nitroprusside, as it results failure acutely continuous infusion7,45 in cyanide and thiocyanate toxicity
Avoid ACE inhibitors acutely
Nicardipine IV continuous infusion7,45
Clevidipine IV continuous infusion7
Eclampsia, Aim for SBP <140 mm Hg in the first Hydralazine* IV Hydralazine can lead to Hydralazine, labetalol, and preeclampsia hour7 bolus31 reflex tachycardia and nifedipine are all considered firsthypotension line agents.
Labetalol* IV bolus31
Labetalol may cause Nifedipine is ideal if IV access
Nifedipine* oral31 fetal bradycardia, and cannot be established there is risk in patients Contraindicated: ACE inhibitors, with asthma, COPD, and ARBs, renin inhibitors, and heart failure nitroprusside
Nifedipine may cause maternal tachycardia and overshoot hypotension
Hypertensive Decrease MAP 20%–25% in the first Labetalol IV bolus or Avoid β­blockers in Autoregulation of cerebral perfusion encephalopathy hour of presentation46; more continuous infusion7 sympathetic crisis from may be significantly impaired, so drugs avoid rapid BP lowering to prevent aggressive lowering may lead to Nicardipine IV cerebral hypoperfusion ischemic infarction continuous infusion47
Do not give nitroglycerin48 as it
Clevidipine IV may worsen cerebral autoregulation continuous infusion47
Subarachnoid SBP <160 mm Hg to prevent Nicardipine IV Avoid hypotension to Nimodipine is used to decrease hemorrhage rebleeding continuous infusion49,51 preserve cerebral mortality. BP control is not its
BP parameters have not yet been perfusion primary goal, but some decrease in
Labetalol IV bolus, 10– defined49,50  milligrams IV, or BP may be seen49 continuous infusion49,52 Clazosentan is used with success in lieu of nimodipine and has similar
Esmolol IV bolus, then continuous infusion hypotensive effects53
Clevidipine IV continuous infusion49
Intracerebral If SBP >220 mm Hg, consider Labetalol IV bolus or Drops in SBP <150 mm Hg are not hemorrhage aggressive management with IV continuous infusion52,55 associated with increased infusion54 Nicardipine IV morbidity56
If SBP 150–220 mm Hg, IV boluses of continuous infusion52,55 Early hemorrhage growth often antihypertensive medications occurs in first  h. Recent data
Esmolol IV bolus, then should be used to acutely lower SBP suggest that at this time, aggressive continuous infusion to 140 mm Hg54 BP control (SBP 130–139 mm Hg) diminishes hematoma growth, morbidity, and mortality56­58
Acute ischemic If fibrinolytic therapy planned, treat Labetalol* 10–20 Excess BP lowering may Management of BP during and stroke, rtPA if BP remains >185/110 mm Hg after  milligrams IV over 1–2 worsen ischemia after reperfusion therapy candidate (BP measurements59 min; may repeat once55 If SBP >180–230 mm Hg or DBP
≤185/110 mm >105–120 mm Hg, then consider:
The following antihypertensive Nicardipine* 
Hg) Labetalol  milligrams IV bolus recommendations (agents section) milligrams/h IV infusion, followed by continuous IV infusion are for immediate BP control prior to titrate up by .5
2–8 milligrams/min reperfusion; BP management during milligrams/h every 5–15
Nicardipine  milligrams/h IV and after reperfusion therapy is min until desired BP is infusion, titrate up by .5 outlined in comments section reached; maximum  milligrams/h every 5–15 min to milligrams/h59 desired effect; maximum 
Clevidipine* 1–2 milligrams/h milligrams/h IV infusion,
Clevidipine 1–2 milligrams/h IV double the dose every infusion; titrate up by doubling the
2–5 min until desired BP dose every 2–5 min to desired effect; is reached; maximum  maximum  milligrams/h milligrams/h
Nitroprusside may be used if BP is not controlled with above agents or DBP >140 mm
Hg59
Acute ischemic Treat if ≥220/120 mm Hg on third of Same agents and doses Be careful with BP Do not lower SBP by >15% in first  stroke,  measurements, spaced  min as above acute ischemic control efforts in patients h59 hypertension apart; BP should be reduced by stroke rtPA candidate taking oral β­blockers or
BP that is lower during the acute excludes ~15% in the first  h59 clonidine; ischemic stroke than the premorbid reperfusion antihypertensive
Early treatment of hypertension is pressure could be considered therapy withdrawal syndrome indicated if required by other hypotension may occur.
comorbid conditions (i.e., acute coronary syndrome, aortic dissection, preeclampsia/eclampsia).
Lowering by 15% acutely is probably safe59
Abbreviations: ACE = angiotensin­converting enzyme; ARB = angiotensin receptor blocker; BP = blood pressure; CHF = congestive heart failure; COPD = chronic obstructive pulmonary disease; DBP = diastolic blood pressure; MAP = mean arterial pressure; MAOI = monoamine oxidase inhibitor; PR = pulse rate; rtPA= recombinant tissue­type plasminogen activator; RV = right ventricular; SBP = systolic blood pressure; SL = sublingual.
*Preferred agents.
AORTIC DISSECTION
The therapeutic goal in acute aortic dissection is a systolic blood pressure between 100 and 120 mm Hg and a heart rate ≤60
,22,36 beats/min, ideally within the first hour of presentation. The resultant reduction in tachycardia decreases the shearing forces and aortic
 wall stress, limiting the progression of the dissection. Pain control with opioids helps decrease sympathetic tone.
ACUTE HYPERTENSIVE PULMONARY EDEMA
Tailor the treatment of hypertensive pulmonary edema to the underlying pathophysiology. Most patients have existing poorly controlled hypertension with cardiac remodeling and left ventricular hypertrophy, stiffness, and diastolic dysfunction. With an acute rise in blood pressure, there is an increase in afterload and a decrease in venous capacitance. This leads to fluid shifts from the splanchnic and peripheral vascular beds into the pulmonary circulation. Interventions that improve forward flow, via afterload reduction, tend to work better than diuresis. Other causes of acute hypertensive
 pulmonary edema include transient left ventricular systolic or diastolic dysfunction, acute dyssynchrony, or ischemic mitral regurgitation. For these reasons, one must provide individualized management.

The mainstay of therapy is vasodilators, predominantly nitrates. IV, sublingual, and topical nitrates reduce blood pressure, decrease myocardial
,40 oxygen consumption, and improve coronary blood flow. If adding diuretics, be careful using loop diuretics in combination with nesiritide
,41,60 because together these might worsen renal function. In patients with systolic dysfunction, IV nicardipine or clevidipine may help by increasing
,61,62 both stroke volume and coronary blood flow.
ACUTE MYOCARDIAL INFARCTION
,42,43
Patients presenting with severely elevated blood pressure and ischemic changes on ECG should be treated with sublingual or IV nitrates.
Currently, IV β­blockade is only recommended for patients presenting with severe hypertension. Oral β­blockade in patients presenting with ST­ segment elevation myocardial infarctions and non–ST­segment elevation myocardial infarctions remains part of early care, but this route may not
,43 provide sufficient or rapid enough blood pressure control in a hypertensive emergency.
ACUTE SYMPATHETIC CRISIS
Manage patients in acute sympathetic crisis due to either cocaine or amphetamines with an IV benzodiazepine, such as lorazepam or diazepam, to
,44 decrease adrenergic stimulation. Monitor patients for respiratory depression and sedation. If benzodiazepines are not effective, add
,44 nitroglycerin or phentolamine. A calcium channel blocker can serve as a third­line agent. β­blockers can result in unopposed α­blockade,
 which then can worsen coronary vasoconstriction and increase blood pressure. If a β­blocker is selected, labetalol, due to its α­adrenergic blocking
 effects, should be used in conjunction with a vasodilator.
IV phentolamine is the first­line agent for patients with pheochromocytoma and a hypertensive emergency. Intramuscular administration is an option
  if venous access is absent. Second­line agents include clevidipine and nicardipine. Phenoxybenzamine, a long­acting oral adrenergic α­receptor blocker, is used only in the preoperative setting in patients who are hypertensive but not in crisis.
Patients with monoamine oxidase inhibitor toxicity often respond to an IV benzodiazepine; if more therapy is needed, use phentolamine, nitroglycerin, or nitroprusside. Nitroglycerin is the preferred agent for these hypertension events associated with chest pain or cardiac ischemia. Monitor patients closely after reaching a targeted blood pressure because the hypertensive phase is often followed by a hypotensive one.
ACUTE RENAL FAILURE
Fenoldopam, nicardipine, and clevidipine are all suitable for acute hypertension­induced isolated renal failure, because they reduce systemic
 vascular resistance while preserving renal blood flow. Fenoldopam improves natriuresis and creatinine clearance in patients with elevated blood
 pressure and impaired renal function.
ECLAMPSIA AND PREECLAMPSIA
Obstetrical hypertensive emergencies can occur well below the blood pressure threshold for other hypertensive emergencies. Hydralazine and
 labetalol have good safety profiles in pregnancy. Another option is oral nifedipine. (See Chapter 100, “Maternal Emergencies After  Weeks of
Pregnancy and in the Peripartum Period,” for further details.)
NEUROLOGIC EMERGENCIES
Hypertensive encephalopathy (defined as a change in sensorium or seizure from the blood pressure elevation) warrants rapid and uniform blood
,63 pressure reduction once other neurologic emergencies, notably ischemic or hemorrhagic stroke, are excluded.
Management includes cessation of inciting agents, such as chemotherapy and immunosuppressants, and blood pressure control in hypertensive
,47,64 patients with IV nicardipine, clevidipine, labetalol, or fenoldopam. Avoid nitroglycerin because it dilates cerebral arteries and alters both global
 and regional blood flow, which may worsen the autoregulation failure.
The ideal targets for blood pressure control in subarachnoid hemorrhage and ischemic stroke are not clear and should be balanced to avoid worsening ischemia or rebleeding. For subarachnoid hemorrhage, recommended agents include IV labetalol,
 nicardipine, nitroprusside, and clevidipine, with no superior agent identified to date. Oral nimodipine is a good choice for those with modest blood pressure elevations because it lowers blood pressure and reduces vasospasm and subsequent cerebral infarction rates, improving neurologic
,50,65 outcomes. High­dose clazosentan can also decrease the incidence of vasospasm­related delayed ischemic neurologic deficits and has similar
 blood pressure–lowering effects as nimodipine. If an anticonvulsant that can also reduce blood pressure is used, such as IV phenytoin or a benzodiazepine, be cautious with additional blood pressure reduction attempts.
,55,66
The treatment of hypertension in patients with intracerebral hemorrhage includes labetalol, nicardipine, and esmolol. Enalaprilat may also
 be used, but due to concerns of precipitous blood pressure drop, start with a smaller test dose (0.625 mg). Lowering systolic blood pressures from
54­58
>180 mm Hg to 130 to 160 mm Hg may improve clinical outcomes.
In ischemic stroke, moderately elevated blood pressure may be beneficial in preserving cerebral perfusion of ischemic areas. Conversely, it may also worsen edema and contribute to hemorrhagic transformation. Ideal blood pressure ranges for ischemic stroke subtypes have not yet been determined. For the treatment of ischemic stroke, labetalol, nicardipine, and clevidipine are the recommended agents; however, the route and degree
 of blood pressure reduction depend on whether the patient is a candidate for reperfusion therapy (Table 57­4). Fibrinolytic therapy is contraindicated in patients with ongoing blood pressure >185/110 mm Hg after antihypertensive therapy. In patients who maintain blood pressures ≤185/110 mm Hg (with or without antihypertensive therapy) and undergo fibrinolytic therapy, blood pressure goal is ≤180/105 mm Hg for the first  hours. Monitor blood pressure closely from the start of recombinant tissue plasminogen activator therapy for  hours.
PHARMACOLOGIC AGENTS
Parenteral agents used for hypertensive emergencies, including dosage, mechanisms, and warnings, are listed in Table 57­4 and Table 57­5. See
Chapter , “Pharmacology of Antiarrhythmics and Antihypertensives,” for detailed discussion of individual agents.
TABLE 57­5
IV Agents Used for Hypertensive Emergencies
Drug Dosage Mechanism/Comments Warnings
β­Blockers
Labetalol Bolus: 10–20 milligrams (0.25 milligram/kg Combined selective α ­adrenergic and nonselective Avoid use in patients with
 for an 80­kg patient) IV over  min; may bradycardia, greater than first­
β­adrenergic receptor blocker with an α­ to β­ administer 40–80 milligrams at 10­min degree heart block, blocking ratio of 1:7.67 Effect in 2–5 min, peaking by intervals, up to 300 milligrams total dose. uncompensated cardiac failure,
 min, duration 2–4 h. Renal, cerebral, and coronary
Continuous infusion: initially,  or active bronchospasm, and in blood flow maintained; minimal placental transfer.
milligrams/min; titrate to response up to patients receiving IV verapamil or
Safe in pregnancy.
300 milligrams total dose, if needed. diltiazem.
Caution in patients with liver impairment (effects may be prolonged); the elderly have a less predictable response and more toxicity.
Esmolol Loading dose: 250–500 micrograms/kg Ultra­short­acting, cardioselective, β­adrenergic Avoid use in patients with infused over 1–3 min IV, follow with: receptor blocker. Onset within  s, duration 10–20 bradycardia, heart block,
Maintenance infusion:  min. Ideal for use in patients at risk for complications cardiogenic shock, micrograms/kg/min IV over  min; if from β­blockers, especially patients with mild to decompensated cardiac failure, or adequate effect not observed, repeat moderately severe left ventricular dysfunction or active bronchospasm, and in loading dose and increase infusion rate peripheral vascular disease. Duration 10–20 min; patients receiving IV verapamil or using increments of  micrograms/kg/min easily stopped. diltiazem.
IV (for  min). This regimen can be repeated Caution in patients with asthma, for  bolus doses and to an infusion rate of COPD, uncompensated cardiac
300 micrograms/kg/min. failure; extravasation can lead to skin necrosis and sloughing; anemic patients will have a prolonged half­life, because drug is metabolized by red blood cell esterases.
Calcium Channel Blockers
Nicardipine Continuous infusion: start at rate of  Second­generation dihydropyridine calcium channel Avoid in patients with advanced milligrams/h. If target BP not achieved in blocker with vascular selectivity for the cerebral and aortic stenosis. Caution in
5–15 min, increase dose by .5 coronary arteries. Onset of action is 5–15 min; decompensated heart failure.
milligrams/h every 5–15 min until target duration is 1–4 h. Avoid in patients receiving IV β­ pressure or the maximum dose of  blockers.
milligrams/h is reached. Common side effects are headache, hypotension, vomiting, and tachycardia.
Clevidipine Continuous infusion: initiate infusion at 1– Very rapid onset and offset of effect due to its ultra­ Cautions: Clevidipine contains
 milligrams/h. short half­life, approximately 2–4 min. Clevidipine is approximately .2 gram of lipid
Dose titration: double dose at short (90­s) rapidly hydrolyzed to its inactive metabolite in per mL (2.0 kcal). Lipid restrictions intervals initially. As BP approaches goal, blood and extravascular tissues. It exerts a selective may be necessary for patients increase dose by less than doubling and vasodilating action on arteriolar resistance vessels with significant disorders of lipid lengthen time between dose adjustments but has no effect on venous capacitance vessels. Its metabolism. Clevidipine may to every 5–10 min. metabolism is independent of the kidney or liver. produce hypotension and reflex
Maximum dose  micrograms/h; tachycardia.
maximum duration is  h. Contraindicated in patients with severe aortic stenosis and egg or soy hypersensitivity.
Use caution and lower doses in elderly.
Vasodilators
Hydralazine  milligrams slow IV infusion (maximum Potent direct arteriolar vasodilator with minimal Avoid in patients with myocardial initial dose is  milligrams). effect on venous circulation. Onset begins at 10–30 ischemia, pulmonary edema, and
Repeat every 4–6 h as needed. min (can be sooner and precipitous); duration is 2–4 aortic dissection. Reflex h. tachycardia increases myocardial
Safe in pregnancy. demand.
Nitroglycerin Sublingual: .4 milligram. Potent venodilator and only affects arterial tone at Avoid in cases of compromised
Paste: 1–2 in. high doses. Onset begins at  min; duration is 10–20 cerebral and renal perfusion;
Continuous infusion: start  min (paste duration 3–4 h, unless removed). Reduces avoid concurrent use (within past micrograms/min, increase by  BP by reducing preload and cardiac output. 24–48 h) with phosphodiesterasemicrograms/min every 3–5 min to  Decreases coronary vasospasm and cardiac  inhibitors (sildenafil, tadalafil, or micrograms/min; if no response at  workload. vardenafil).
micrograms/min, increase by  Caution: may cause hypotension micrograms/min every 3–5 min, up to 200 with reflex tachycardia, which is micrograms/min (note: many clinicians exacerbated by volume initiate with a higher infusion rate). depletion.
Nitroprusside Continuous infusion: .3–0.5 Arterial and venous vasodilator due to its interaction Avoid in patients with kidney or microgram/kg/min IV initial infusion, with oxyhemoglobin to produce nitric oxide. It hepatic failure, arteriovenous increase in increments of .5 decreases preload and afterload. Onset of action is in shunts, hereditary optic nerve microgram/kg/min; titrate to desired effect. seconds; duration is 1–2 min. Cerebral blood flow is atrophy (increases nerve
Rates >2 micrograms/kg/min may lead to decreased, whereas ICP is increased. ischemia), or elevated ICP.
cyanide toxicity. Use lowest possible dose. Caution: intra­arterial monitoring
For infusions ≥4–10 micrograms/kg/min, is recommended; must be institute a thiosulfate infusion. protected from light.
Nitroprusside is recommended only when other agents fail.
Coronary steal syndrome may occur.
Other Agents
Phentolamine Bolus load: 1–5 milligrams IV; may repeat α ­ and α ­adrenergic blocking agent; effective for Myocardial infarction,
  every  min. cerebrovascular spasm, and pheochromocytoma and hypercatecholaminergic­
Continuous infusion: .2–0.5 cerebrovascular occlusion have induced hypertension.
milligram/min. occurred after administration.
Fenoldopam Continuous infusion: start .1–0.3 Dopamine  receptor agonist. Onset of action in  Caution: causes reflex tachycardia microgram/kg/min, titrate by .05–0.1 min; peak effect at  min; duration 30–60 min. at higher dosages. Concurrent microgram/kg/min every  min to desired Metabolized by liver, without P450 system. Improves use of acetaminophen may
BP. creatinine clearance, urine flow, and sodium increase fenoldopam levels. May
Maximum infusion rate: .6 excretion. cause flushing, dizziness, microgram/kg/min. vomiting.
Caution in patients with increased ocular pressures and ICP; caution in patients who have sulfite sensitivity (it is contained in a solution of sodium metabisulfite).
Enalaprilat Bolus: .25 milligrams IV over  min every Angiotensin­converting enzyme inhibitor. Test dose Avoid in pregnancy and those
4–6 h; titrate at increments of .25 of .625 milligram recommended when concern for with myocardial ischemia or milligrams every 12–24 h, with a maximum first­dose hypotension exists.66 bilateral renal artery stenosis.
of  milligrams every  h. Caution: first­dose hypotension is
AVOID in pregnancy.
common, especially in high­renin states; may cause dizziness and headache.
Abbreviations: BP = blood pressure; COPD = chronic obstructive pulmonary disease; ICP = intracranial pressure.
β­BLOCKERS
Labetalol is unique among commonly used β­blockers because it also has modest selective α ­inhibitory effects, with an α­ to β­blocking ratio of

,68
1:7. It is recommended for nearly all hypertensive emergencies with the exception of cocaine intoxication and systolic dysfunction in association with decompensated heart failure. In the latter, nicardipine and clevidipine are preferred when nitroglycerin fails. Oral metoprolol use is common in
,43 patients presenting with acute coronary syndromes. Oral β­blockers improve survival, whereas mortality data are conflicting with IV formulations.
However, if blood pressure control is needed in a patient with acute coronary syndrome, use the IV formulation first, then change later. Esmolol has a short duration of action and is titratable, an advantage in patients at risk for the adverse effects of β­blockers, such as those with severe asthma and chronic obstructive pulmonary disease.
CALCIUM CHANNEL BLOCKERS
68­70
Clevidipine is a third­generation dihydropyridine calcium channel blocker with ultra­short­acting selective arteriolar vasodilator properties. Its advantage is its ability to be titrated with a half­life less than a minute. Nicardipine has a rapid onset of action and can be titrated at 5­ to 15­minute intervals. It is safe and effective in neurologic hypertensive emergencies and has a favorable effect on myocardial oxygen balance, increasing both stroke index and coronary blood flow. Compared to labetalol, nicardipine achieves physician­specified targeted blood pressure goals more often
  within  minutes of therapy. Use oral nifedipine (10 milligrams) only in peripartum patients.
VASODILATORS
Hydralazine is a potent vasodilator with a rapid onset of action that can have an unpredictable effect on blood pressure, which may not always be dose dependent. A potentially adverse effect is reflex tachycardia, which can worsen myocardial ischemia. Given the availability of other, more easily titratable agents, it is limited to pregnancy­related care. Nitroglycerin is a potent venodilator, showing arterial dilatation only at very high doses. Use may cause hypotension and reflex tachycardia, both worsened by the volume depletion characteristic of hypertensive emergencies. Nitroglycerin is a first­line agent only in the treatment of heart failure and acute coronary syndromes due to its favorable effects on coronary blood flow
 and cardiac workload. Its hypotensive effects are due to its reduction of preload and cardiac output, which makes it a poor choice in other hypertensive emergencies.
Sodium nitroprusside is best used when other agents fail. It requires invasive monitoring to prevent “overshoot” in blood pressure control and has
,71 demonstrated higher mortality rates in cardiac surgery patients when compared to clevidipine. Concerns about cyanide toxicity, heightened in
 patients with renal or hepatic insufficiency, and the potential for tachyphylaxis curtail use. Combination therapy is the most common current use, as in aortic dissection patients who also receive esmolol to achieve blood pressure targets at lower doses.
OTHER AGENTS
Fenoldopam is a unique peripheral dopaminergic­1 receptor agonist, and due to its ability to promote diuresis, natriuresis, and creatinine clearance,
 it is useful in renal hypertensive emergencies. Phentolamine is used successfully in cocaine­, amphetamine­, and pheochromocytoma­related
,68,72 hypertensive emergencies and also to counteract soft tissue catecholamine injection extravasation and ischemia (by injecting in the same area).
Enalaprilat, the only available IV angiotensin­converting enzyme inhibitor, has special application in patients with heart failure or acute coronary
 syndrome, but monitor carefully because of first­dose hypotension.
Clonidine, a central α ­agonist, generally does not have a role in the treatment of patients with hypertensive emergencies except for those who have
 recently stopped taking the drug. The resultant rebound hypertension may be difficult to control with other agents. When used, .2­0.3 mg PO
 clonidine is a common start, with blood pressure reduction starting within  to  minutes and peaking at  to  hours. In patients who are unable to take oral medications, a clonidine patch for dermal delivery is an option, although the onset of action may be delayed by  to  days and titration is
,73 challenging. For maximum absorption, apply the patch to the chest or upper arm. Although abrupt cessation of either clonidine or a β­blocker may result in rebound hypertension, clonidine withdrawal tends to be more severe and often will not respond to therapy without reinstitution.
TREATMENT OF ASYMPTOMATIC SEVERE HYPERTENSION

Acute treatment of asymptomatic severe hypertension does not prevent or reduce short­term patient morbidity or mortality.

However, uncorrected hypertension is associated with an eventual increased risk of cardiovascular events and renal dysfunction. In addition, if severe hypertension is not addressed in the ED setting, patients may not seek further outpatient blood pressure management. These considerations support initiating outpatient blood pressure reduction regimens prior to ED discharge. Table 57­6 lists oral agents commonly used for hypertension.
The drugs listed are chosen for their relatively rapid onset of action and their potential use for ongoing control of chronic hypertension. Choosing an agent that can be used once daily and is inexpensive is often an ideal plan (e.g., generic hydrochlorothiazide, started at  milligrams daily). If choosing an angiotensin­converting enzyme inhibitor or angiotensin II receptor antagonist, check the patient’s creatinine and potassium first.
TABLE 57­6
Oral Agents for Hypertensive Urgencies
Onset
Mechanism
Agent Dosage of Duration Contraindications Adverse Effects of Action
Action
Carvedilol α ­, β­ .25 milligrams 30–60 7–10 h Asthma, chronic obstructive Hypotension,

PO min pulmonary disease, bradycardia, syncope,
Adrenergic bradycardia, heart block, heart dizziness blocker failure, hepatic impairment
Labetalol α ­, β­ 200–400 30–120 6–12 h Asthma, chronic obstructive Bronchoconstriction,
 milligrams PO, min pulmonary disease, bradycardia,
Adrenergic repeat every bradycardia, heart block, heart hyperkalemia blocker
2–3 h failure
Metoprolol β­Adrenergic  milligrams Oral 3–4 h Asthma, chronic obstructive Bronchoconstriction, blocker PO (IR): ≤1 pulmonary disease, bradycardia, heart h bradycardia, heart block, heart block, weight gain, failure hyperglycemia
Captopril Angiotensin­ .5–25 15–30 4–6 h Renal artery stenosis, Acute renal failure, converting milligrams PO min pregnancy angioedema, side effect enzyme of chronic cough inhibitor
Losartan Angiotensin  milligrams  min 12–24 h Second and third trimesters of Allergic reaction (rare)
II antagonist PO pregnancy
Hydrochlorothiazide Thiazide  milligrams  h;  h Renal insufficiency, pregnancy Hypokalemia,
Ideal first choice diuretic PO peak Caution in diabetics; may raise dehydration, increased medication in most effect glucose levels uric acid levels (may patients, but onset of at  h precipitate gout attacks) action is delayed
Nifedipine (extended release) Calcium  milligrams 5–15 3–6 h Angina, acute hypertension Myocardial infarction,
Indicated for preeclampsia channel PO, may min cerebrovascular only blocker repeat every accident, syncope, heart
30–60 min block, CHF
Clonidine Central α ­ .1–0.2 30–60 6–8 h CHF, second­ or third­degree Drowsiness, sedation,

Primary indication for milligram PO min heart block tachycardia, dry mouth agonist rebound hypertension Would not recommend as a new or singular antihypertensive agent
Abbreviation: CHF = congestive heart failure; IR = immediate release.
DISPOSITION AND FOLLOW­UP OF ASYMPTOMATIC HYPERTENSION

Table 57­7 provides a summary of the 2017 blood pressure management recommendations from the American Heart Association. Although the
American Heart Association recommendations are comprehensive, they fall short of providing common ED guidance and management of patients who present with severe hypertension with no prior history of hypertension. In all cases, reinforce the need for outpatient follow­up, with or without ED­
,75 initiated oral therapy, even if elevated blood pressure was not part of the chief complaint.
TABLE 57­7
Recommended Treatment Protocol for ED Patients With Increased Blood Pressure (BP)* SBP
(mm DBP (mm Hg) Follow­Up/Treatment
Hg)
130–139 or 80–89 AND ASCVD† Lifestyle modification and outpatient follow­up risk <10%
130–139 or 80–89 AND ASCVD† Lifestyle modification; initiate antihypertensive; follow­up in <1 month risk ≥10%
140–179 or >90–109 Lifestyle modification; initiate antihypertensive therapy (ideally  agents); follow­up in <1 month
≥180 or ≥110 Evaluation for target organ damage; initiate lifestyle modification and antihypertensive therapy (ideally  agents); prompt outpatient follow­up (within a week)
Abbreviations: ASCVD = atherosclerotic cardiovascular disease; DBP = diastolic blood pressure; SBP = systolic blood pressure.
*To assess 10­year risk, please refer to http://tools.acc.org/ASCVD­risk­estimator/.
†Use the lowest values for cholesterol, if unknown, to obtain a conservative risk value.
Data adapted from: Guideline for the Prevention, Detection, Evaluation, and Management of High Blood Pressure in Adults: A Report of the American College of
Cardiology/American Heart Association Task Force on Clinical Practice Guidelines.7
,75
Table 57­8 lists indications for recommended oral antihypertensive classes based on trial data and consensus guidelines.
TABLE 57­8
Indications for Specific Antihypertensive Therapy
Post–
Heart High Coronary Artery Recurrent Stroke Chronic Kidney
Myocardial Diabetes
Failure Disease Risk Prevention Disease
Infarction
Blood <130/80 <130/80 mm <130/80 mm Hg <140/90 mm Hg <130/80 mm Hg <130/80 mm Hg pressure mm Hg Hg goal
First­line Diuretic β­Blocker, ACE β­Blocker, calcium Thiazide diuretic Nonblack: Thiazide ACE inhibitor or ARB therapy with ACE inhibitor or channel blocker (if angina with ACE inhibitor diuretic, ACE inhibitor, inhibitor ARB pectoris) or ARB ARB, or CCB
Black: Thiazide diuretic or
CCB
Second­ β­Blocker Aldosterone ACE inhibitor, calcium — Above alone or in Above alone or in line antagonist channel blocker, or combination combination with other therapy diuretic drug class
Abbreviations: ACE = angiotensin­converting enzyme; ARB = angiotensin receptor blocker; CCB = calcium channel blocker.
Data adapted from: Guideline for the Prevention, Detection, Evaluation, and Management of High Blood Pressure in Adults: A Report of the American College of
Cardiology/American Heart Association Task Force on Clinical Practice Guidelines.7
Be sure to inform patients about potential adverse effects when prescribing an antihypertensive medication. The most common side effects stratified by drug class are provided in Table 57­9. Pediatric regimens are in Table 57­10; start these in close consultation with a pediatrician.
TABLE 57­9
Common Adverse Effects of Antihypertensive Drugs
Recommended Ancillary Testing
Antihypertensive Class Most Common Adverse Effects
Before Therapy
Diuretic Chemistry panel: renal function and Hypokalemia, hypomagnesemia, hyperglycemia, hypercalcemia, electrolytes hyperuremia, hyponatremia
Angiotensin­converting Chemistry panel: renal function and Cough, hyperkalemia, acute renal failure, angioedema, myopathy, fetal enzyme inhibitor electrolytes abnormalities
Pregnancy test
Angiotensin receptor blocker Chemistry panel: renal function and Hyperkalemia, acute renal failure, angioedema, myopathy, fetal electrolytes abnormalities
Pregnancy test
β­Blocker ECG Bronchospasm, bradycardia, depression, erectile dysfunction
Calcium channel blocker ECG Bradycardia, constipation, lower extremity edema
Aldosterone antagonist Chemistry panel: renal function and Hyperkalemia, gynecomastia, feminization of male fetuses electrolytes
Pregnancy test
TABLE 57­10
Agents for Severely Hypertensive Pediatric Patients With Life­Threatening Symptoms
Agent Dosage Indications/Comments/Cautions
Esmolol 100–500 micrograms/kg/min IV infusion Typically used in perioperative cardiac patients
Risk of bradycardia
Hydralazine .1–0.2 milligram/kg per dose IV or IM; up to .4 milligram/kg Likely the most commonly used agent; caution with inadvertent per dose overshooting of BP reduction
Risk of tachycardia
Give every  h if given as bolus
Labetalol IV bolus: .2–1.0 milligrams/kg per dose; up to  milligrams Rapid onset if given IV (2–5 min) per dose Avoid in asthma and heart failure
Infusion: .25–3.0 milligrams/kg/h Risk of hypotension in children <24 months and concomitant ischemic or traumatic brain injury
Nicardipine IV bolus:  micrograms/kg up to  milligrams per dose May need central access to avoid thrombophlebitis
Infusion: .5–4 micrograms/kg/min Risk of tachycardia; increases cyclosporine and tacrolimus levels
Nitroprusside Starting: 0–3 micrograms/kg/min Significant experience in pediatric population
Maximum:  micrograms/kg per min Risk of cyanide poisoning after >48 h or earlier in renal/liver dysfunction patients
Oral Agents for Severely Hypertensive Pediatric Patients With Less Significant Symptoms and No Target Organ Damage
Clonidine 2–5 milligrams/kg per dose up to  milligrams/kg per dose Often used in patients with chronic hypertension and those refractory given every 6–8 h (PO) to other agents
Risk of dry mouth, drowsiness
Fenoldopam .2–0.5 milligram/kg/min up to .8 milligram/kg/min IV Higher doses may lead to tachycardia without much more BP reduction infusion
Hydralazine .25 milligram/kg per dose up to  milligrams per dose given Half­life varies with genetically determined acetylation rates every 6–8 h (PO)
Isradipine .05–0.1 milligram/kg per dose up to  milligrams per dose Exaggerated BP decrease in patients receiving azole antifungal agents given every 6–8 h (PO)
Minoxidil .1–0.2 milligram/kg per dose up to  milligrams per dose Most potent oral vasodilator; long acting given every 8–12 h (PO)
Abbreviation: BP = blood pressure.
Data adapted from: Clinical Practice Guideline for Screening and Management of High Blood Pressure in Children and Adolescents.76­79


