## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 148: The Child With Special Healthcare Needs
Thomas Abramo; Nicholas W. Porter; Samuel T. Selby
INTRODUCTION AND EPIDEMIOLOGY
Children with special healthcare needs (CSHCN) have or are at increased risk for chronic physical, developmental, behavioral, or emotional conditions
,2 and require health and related services of a type or amount beyond those required by children generally. This group of children encompasses a wide
,4 spectrum of medical complexity, functional limitations, and resource utilization. A subset of the CSHCN population, children with medical complexity
,5 have substantial healthcare service and resource needs for their chronic conditions. Their response to illness and trauma may be unpredictable compared with the normal pediatric patient, sometimes leading to a rapid and unexpected deterioration. This requires a personalized approach that addresses their special needs and chronic medical problems in addition to the emergency medical condition at hand. This unique response to illness
,6 and injury accounts for the majority of pediatric hospital days and deaths in this group. CSHCN is a growing population, accounting for 15% to 18%
,8 ,9,10,11
(11.2 million) of children in the United States and for 40% to 80% of all pediatric healthcare utilization and costs. These trends are largely due
,6 to increased survival of premature infants and improved medical or surgical treatment of conditions that were once terminal. Compared to typical
,10­13 children, children with chronic conditions tend to be older, male, and from white racial or ethnic groups. The clinical spectrum of CSHCN
10­12,14­17 conditions is diverse, and complex medical devices are often required for care (Tables 148­1 and 148­2). Because of the increasing prevalence of this patient population and their high rate of healthcare utilization, emergency medical practices must adapt to meet the needs of this
 complex group.
TABLE 148­1
Congenital or Developmental Disorders and Associated Medical Conditions19,20
Chromosomal disorders10,21 Hamartoses
Down syndrome (trisomy  syndrome)
Sturge­Weber sequence
Seizure disorder (12%–15%); atlantoaxial instability (14%–22%); cataracts (15%);
Flat facial hemangiomata and meningeal hemangiomata with seizures serous otitis media (50%–70%); deafness (75%); congenital heart disease (50%): ASD, VSD,
Tuberous sclerosis syndrome
AV canal, PDA, tetralogy of Fallot, pulmonary hypertension; GI atresias (12%);
Hamartomatous skin nodules (thumb print macules),
Hirschsprung’s disease (1%); constipation, fecal impaction from medications or seizures, angiomyolipomata (45%–81%), phakomata, and hypothyroidism; thyroid disease (15%); diabetes mellitus; leukemia (1%); acquired hip bone lesions dislocation (6%); and psychiatric disorders (22%)
Fragile X syndrome
Neurofibromatosis syndrome
Recurrent serous otitis media (60% in males), strabismus (30%–56% in males), seizures
Multiple neurofibromata, café­au­lait spots, presence or absence of bone lesions, seizures and/or EEG changes in
(14%–50% in males), autism (16% in males), self­abusive, and mitral valve prolapse (22%–
20%, cerebrovascular compromise, and headaches
77% in males)
Trisomy 
Environmental agents (toxins)
Congenital heart disease (99%): VSD, ASD, and PDA
Fetal alcohol syndrome
Turner’s syndrome (XO syndrome)
Vision problems (94%), recurrent serous otitis (93%),
Short stature in females, horseshoe kidney, heart disease (bicuspid aortic valve in 30%, hearing loss (66%), heart defects (29%–41%), renal hypoplasia, duplication of the kidney and collecting coarctation of the aorta in 10%, valvular aortic stenosis, mitral valve prolapse, aortic system, and bladder diverticula (10%) dissection later in life, and hypertension)
Noonan’s syndrome
Other environmental exposures include fetal
Webbing of the neck, pectus excavatum, cryptorchidism, and pulmonic stenosis hydantoin syndrome, fetal trimethadione syndrome, fetal
 valproate syndrome, fetal warfarin syndrome, and retinoic
Disorders with facial defects as major feature
Chapter 148: The Child With Special Healthcare Needs, Thomas Abramo; Nicholas W. Porter; Samuel T. Selby 
©2025 MPcieGrrrea Rwo bHinill .s yAnldl rRoimghets Reserved. Terms of Use * Privacy Policy * Notice * Acces a s c i i b d i e li m ty bryopathy
Micrognathia, glossoptosis, and cleft soft palate; primary defect: early mandibular
Trauma
Traumatic brain injury hypoplasia
Waardenburg’s syndrome
Visual and hearing disturbances; cranial nerve damage;
Lateral displacement of medial canthi, partial albinism, and deafness spasticity, incoordination, ataxia, and feeding disorders;
Occasional associations: VSD, Hirschsprung’s disease, esophageal atresia, and anal
GERD; neuropsychiatric disturbances
Cerebral palsy atresia
Treacher Collins syndrome
Seizures (33%), strabismus (50%), hearing loss (10%),
Malar hypoplasia with downward­slanting palpebral fissures, defect of lower lid, and hip dislocation, scoliosis, contractures, gait disorder, GERD
(8%–10%), chronic aspiration and recurrent RAD, malformation of the external ear pulmonary fibrosis, and bronchiectasis
Disorders with limb defects as major feature
Holt­Oram syndrome
Miscellaneous
Upper limb defect, cardiac anomaly (ASD, VSD, arrhythmia), and narrow shoulders
Angelman’s syndrome (happy puppet syndrome)
Fanconi’s pancytopenia syndrome
Puppet­like gait, paroxysms of laughter, and
Radial hypoplasia, hyperpigmentation, pancytopenia, and renal anomaly characteristic features; seizures vary from major motor to
Radial aplasia thrombocytopenia (TAR syndrome) akinetic, beginning usually at age 18–24 mo
Beckwith­Wiedemann syndrome
Inherited metabolic disorders
Phenylketonuria (autosomal recessive)
Macroglossia, omphalocele, macrosomia, and ear
Light pigmentation, eczema (33%), poor coordination, seizures (25%), and autistic creases; neonatal polycythemia and hypoglycemia in early infancy; associated with Wilms’ tumor behavior
Hunter’s syndrome (X­linked recessive)
CHARGE syndrome
Developmental lag after age 6–12 mo, coarse facies, growth deficiency, stiff joints by
Coloboma, heart disease (tetralogy of Fallot, PDA, double­outlet right ventricle with an atrioventricular canal, age 2–4 y, clear corneas, and hepatosplenomegaly
Hurler’s syndrome (autosomal recessive)
VSD, ASD, and right­sided aortic arch), atresia choanae,
Developmental lag after age 6–10 mo, coarse facies, stiff joints, mental deficiency, retarded growth and development and/or CNS anomalies, genital anomalies and/or hypogonadism, and ear cloudy corneas by age 1–2 y, hepatosplenomegaly, and rhinitis anomalies and/or deafness
Connective tissue disorders
Marfan’s syndrome
Prader­Willi syndrome
Arachnodactyly with hyperextensibility, lens subluxation, and aortic dilatation
Mental retardation, hypotonia, hypogonadism,
Ehlers­Danlos syndrome obesity, hyperphagia, gastric perforation, hypoventilation,
Hyperextensibility of joints, hyperextensibility of skin, and poor wound healing with obstructive sleep apnea, cor pulmonale, NIDDM, scoliosis, strabismus, inability to vomit, decreased sensitivity to pain, thin scar
Osteogenesis imperfecta congenital seizure disorder, hypoxia, right­sided heart failure, and
Short, broad, long bones; multiple fractures; and blue sclera pulmonary hypertension
Rett’s syndrome
Hyperventilation, breath holding, air swallowing, bruxism, ataxia, muscle wasting, poor circulation, scoliosis, seizures, and intermittent flushing
VATER syndrome
Vertebral defects and VSD, imperforate anus, tracheoesophageal fistula, renal anomalies, and single umbilical artery
Williams’ syndrome
Elfin­like syndrome, cardiovascular disease, supravalvular aortic stenosis, pulmonic stenosis, coarctation of the aorta, strabismus, joint contractures, hypertension, urethral stenosis, vesicoureteral reflux, constipation, ulcers, and hypercalcemia
Abbreviations: ASD = atrial septal defect; AV = atrioventricular; EEG = electroencephalogram; GERD = gastroesophageal reflux disease; NIDDM = non–insulindependent diabetes mellitus; PDA = patent ductus arteriosus; RAD = reactive airway disease; TAR = thrombocytopenia­absent radius; VSD = ventricular septal defect.
TABLE 148­2
Common Home Medical Devices and Equipment
Apnea monitors
Central venous lines or percutaneous IV catheters and pumps
Colostomies
Feeding tubes and pumps
Internal pacemakers or defibrillators
Nebulizers
Oxygen/suction
Tracheostomies
Vagus nerve stimulators
Ventilators
Ventricular peritoneal shunts
EMERGENCY INFORMATION FORM
,22
An emergency information form provides information and instructions to optimize emergency care for complex medical conditions. Components of a comprehensive medical plan include information about the patient’s chronic conditions, special instructions for devices or in case of emergencies, and supplies that might be required for routine or emergency medical care.
The individualized information form can be provided at the ED visit by the patient’s caregiver. Informational elements of the form include demographic and emergency contact information; names and contact information for the primary and specialty care physicians; diagnoses, past procedures, and baseline examination findings; vitals; allergies; immunizations; procedures to avoid; common acute problems and suggested management; and comments on other specific medical issues or special instructions for device malfunction. Information should be regularly updated. Copies and access to the form should be available at the home, physician’s office, and care facilities.
The care plan should include special instructions for EMS personnel, first responders, or family members who may need to provide emergency care for
,16 the child. A “go­bag” or kit with specialized equipment should accompany the child. These kits can contain needed supplies such as extra tracheostomy tubes and equipment for replacement, appropriate size suction catheters, syringes and adapters to decompress feeding tubes, a bag­
 valve mask resuscitator, and needles to access central lines. It is important for medical providers to ask for this special equipment in emergency situations.
GENERAL CLINICAL APPROACH
As in typical pediatric emergencies, a standardized approach is needed. Attention to airway, breathing, and circulation is paramount to caring for any child; however, special consideration for known chronic conditions will drive the practitioner’s workup and resuscitation. For example, a child with
 history of comorbidities and resulting temperature instability may present to the ED with hypothermia (<36.5°C) in the setting of infection. Active rewarming and consideration of sepsis even in absence of more classical indicators such as fever and tachycardia are important for approaching the child’s treatment. Ancillary clinical data such as cardiac monitoring, pulse oximetry, capnography, continuous temperature monitoring, and nearinfrared spectrometry may provide important information to the practitioner. Access to multiple informational resources including family, primary
,16,23 care physicians, specialists, and home health nurses is helpful in tailoring the approach to the individual child (Table 148­3). Long­term caregivers often know the child’s baseline status and are familiar with medications and supportive equipment.
TABLE 148­3
Checklist for Emergency Care of Children With Special Healthcare Needs
Fully involve the family and caregivers and use the care plan.
Inquire about advance directives and family goals of emergency care.
Use family information when assessing child’s pain, mental status, and symptoms.
Anticipate latex allergy.
Identify proper equipment sizes (e.g., tracheostomies, gastrostomy tubes, colostomies).
Anticipate difficult intubation in the child with craniofacial or cervical vertebrae anomalies or contractures.
Recognize and treat comorbid states.
Consider physical or sexual abuse in the child with special needs.
HISTORY AND PHYSICAL EXAMINATION
The child may not be able to communicate directly. Elicit essential elements of the history and subtle symptoms of illness from family or care providers; occasionally, a call to a chronic care facility or review of past medical records is necessary to obtain important details. Inquire about advance directives, limitations of care, and family goals as well as treatments prior to ED arrival. Carefully review medications including recent changes or missed doses, allergies (e.g., latex), and comorbidities. The physical examination often relies on accompanying family or care providers, particularly with regard to mental status, assessment of pain, and changes from baseline. Obtain vital signs. Baseline vital signs for children with medical complexity may be out of the range of normal. Core temperature may be low at baseline, and a “normal” temperature may represent fever; baseline values for heart rate, respiratory rate, and oxygen saturation may be abnormal; vital signs may be controlled by a pacemaker or ventilator. Baseline pulse oximetry may be lower in children with congenital heart disease. Obtain an accurate weight to calculate weight­based medication dosing. To obtain a current weight, if a conventional floor scale is not appropriate, ask caregivers for the most recent weight, use a bed scale, or consider a lengthbased tape to estimate weight. When performing a head­to­toe evaluation, pay special attention to medical devices and equipment: palpate the scalp for ventricular shunts for swelling or tenderness; check patency of tracheostomy tubes; assess central or peripherally inserted vascular catheters for patency and signs of infection; and examine gastrostomy sites and feeding tubes. The physical exam should include evaluating the back of nonmobile patients for signs of infection or breakdown.
LABORATORY TESTING AND IMAGING
The specific evaluation depends on the presenting problem and underlying special healthcare needs. Perform bedside glucose testing in all complex patients with altered mental status. Check serum drug levels (e.g., anticonvulsants) as appropriate. Children with complex needs are more likely to have electrolyte disturbances than typical children. Compare plain radiographs and CT scans with prior imaging results to distinguish acute from chronic changes.
TREATMENT
Although treatment is tailored to the presenting condition, the universal approach of prioritizing airway, breathing, circulation, and disability remains the same. A general overview of common respiratory, metabolic, neurologic, GI, and musculoskeletal problems and suspected abuse follows. A review of the complications common to children dependent on medical technology is discussed separately later, under “Technology­Dependent Children.”
CONGENITAL HEART DISEASE
Many children presenting to the ED will have one of a broad range of congenital heart diseases. The practitioner may notice cyanosis, fingernail clubbing, or a loud murmur on physical exam. It is important to understand each patient’s special cardiac needs. They may have been completely surgically repaired with no residual functional limitations due to their heart condition. Alternatively, they may be awaiting surgical correction or be somewhere in a series of staged surgical corrections.
Depending on the patient’s current cardiac physiology, the patient with cyanotic congenital heart disease may have some degree of venous mixing or shunting causing relatively low oxygen saturations. In some cases, a pulse oximetry reading of 70% may be normal, such as in a child with partially repaired hypoplastic left heart syndrome. The same child will have saturations above 90% after completion of their Fontan surgical correction at  years of age. At the other end of the spectrum, the child with pulmonary hypertension depends on a normal oxygen saturation (97% to 100%) to ensure adequate pulmonary blood flow. These children will often be on supplemental oxygen at baseline, and it is essential to correct hypoxemia immediately. Ask the patient’s caregiver or consult with a cardiologist to determine an acceptable oxygen saturation for each patient and the patient’s specific heart defect.
A thorough evaluation of a patient with congenital heart disease may include careful physical examination, vital signs, pulse oximetry, chest radiography, electrocardiography, and consultation with the patient’s cardiologist (see Chapter 129, “Congenital and Acquired Pediatric Heart
Disease”). Admission to the hospital or transfer to a pediatric center may be warranted for conditions that might otherwise be treated on an outpatient basis in typical children.
RESPIRATORY DISORDERS
Children with complex medical histories frequently present with respiratory problems. Chronic lung disease due to prematurity, reactive airway disease, restrictive lung disease due to scoliosis, dysphagia, and tracheostomies are common in this population. It is important to ask about special respiratory needs, such as bronchodilator use, home oxygen supplementation, thickened diets, airway clearance, and infection history.
To evaluate acute respiratory complaints, obtain a thorough history of past respiratory function, especially in patients with a history of prematurity: escalating home therapy including supplemental oxygen use; increased, colored, or thickened secretions from a tracheostomy tube; bronchodilator and inhaled steroid use in reactive airway disease; or baseline stridor in patients with tracheomalacia. Compare the radiology and laboratory results obtained to previous studies. Capillary blood gases may be an important indicator of current and chronic respiratory status. Airway instability can develop in the child with poor head control, and simple head repositioning or jaw thrust may improve airway mechanics and decrease pooling of saliva in the oropharynx. A nasal trumpet or cervical collar may help maintain airway position, alleviating obstruction. Suction and change tracheostomies as needed. Consider foreign body aspiration in appropriate clinical circumstances. Treatment of respiratory distress in this population may include deep suctioning, replacement of malfunctioning equipment (tracheostomy tubes, ventilators), β­agonists for bronchospasm, antibiotics for pneumonia, and subspecialty consultation for airway foreign bodies. Admission is generally warranted for worsening respiratory status, pneumonia, increased home oxygen requirement, persistent respiratory distress, or removal of a foreign body.
METABOLIC DISORDERS
This diverse category of disorders is due to genetic defects that lead to abnormalities in the metabolic pathways of proteins, carbohydrates, and lipids
(see Chapter 146, “Metabolic Emergencies in Infants and Children”). Although a detailed understanding of individual biochemical pathways is not necessary for emergency management and evaluation, general familiarity with presenting signs and symptoms is necessary, because recognition in the
ED could be lifesaving. A bedside glucose at presentation is essential because many of these disorders lead to hypoglycemia. Initial laboratory studies should include a CBC, serum glucose, electrolytes with anion gap, blood gas, ammonia, liver function tests, urine ketones, and lactate dehydrogenase, aldolase, and creatine kinase if there are muscular symptoms. After verifying adequate airway, breathing, and circulation,
 direct care to correct acute metabolic abnormalities such as hypoglycemia (see Chapter 146, “Metabolic Emergencies in Infants and Children).
Consult a biochemical geneticist for further diagnostic evaluation and management guidance.
SEIZURES
,25­29
The prevalence of epilepsy is estimated at .3 cases per 1000 children and seizures are a frequent cause for admission. In general, the nature and complexity of the seizure syndromes differ considerably between patients, but seizure syndromes are often consistent in the individual. The initial evaluation and management follow the standard approach to seizures (see Chapter 138, “Seizures in Infants and Children”), with a few caveats in children with medical complexity. Note anomalies or comorbid conditions that might lead to airway or respiratory compromise with the use of respiratory depressant anticonvulsants. Obtain a careful history including the baseline frequency and type of seizures and efficacy of past medications
(ask about medication or dose changes and what has and has not worked previously). Confirm allergies and potential drug interactions and consult with the primary neurologist if multiple medications are needed for seizure control and to determine if therapeutic adjustments are required. Keep in
 mind a broad differential including shunt malfunction, infection, electrolyte abnormality, and subtherapeutic medication doses. Obtain serum anticonvulsant medication levels as indicated.
Adequate seizure control may require multiple medications. Intractable seizures, those that do not respond to at least two anticonvulsants, may be associated with underlying disorders or syndromes. Patients with refractory seizures, including those with epileptic encephalopathies (e.g., Lennox­
Gastaut or Dravet’s syndrome), may be placed on a ketogenic diet or have an implanted vagus nerve stimulator. For children on a ketogenic diet, it is critical to avoid sugars to maintain ketosis. Therefore, ask caregivers about baseline serum glucose levels before administering dextrose because dextrose may increase seizures previously controlled by therapeutic ketosis. In addition, consider working with a pharmacist to ensure that the vehicle in which a medication is provided is not contraindicated for a ketogenic diet. For example, most chewable and suspension medications and common medications such as acetaminophen and ibuprofen contain sugar.
GI DISORDERS
GI complaints may include dehydration, feeding tube complications, and constipation. Dehydration may result from poor oral intake, oral motor dysfunction, or increased fluid losses from infection or gastric tube output. Children with growth retardation (in particular below the fifth percentile) or marginal reserves may dehydrate even from minimal vomiting and diarrhea. In addition to the clinical signs of dry mucous membranes, tachycardia, and oliguria, ask the family about weight loss, changes in baseline function, and ability to orally or enterally hydrate. IV access may be difficult, and the child may require central or intraosseous access (see Chapter 114, “Vascular Access in Infants and Children”).
Constipation may be associated with nonspecific symptoms such as abdominal pain, change in bowel habits, anorexia, or overflow diarrhea. Treat acute constipation with enemas, suppositories, polyethylene glycol, and dietary adjustments. Avoid mineral oil in children with aspiration potential to avoid pulmonary complications and impaired fat­soluble vitamin absorption. Do not recommend chronic use of Fleet® enemas because electrolyte abnormalities may result.
MUSCULOSKELETAL/DERMATOLOGIC DISORDERS
Children with disorders that require orthopedic braces, have prolonged periods of immobility, or result in wheelchair dependence may develop painful skeletal or cutaneous complications. The risk of pathologic fractures increases from disuse and nutritionally induced osteopenia. Although
 fractures may occur from normal handling, therapy, falls, or accidents, practitioners must also consider abuse. Assess for orthopedic injuries in the irritable, severely impaired, or nonverbal child by palpating all extremities and checking range of motion. Inspect the skin, especially in dependent areas, for pressure ulcers or skin breakdown. Evaluate wheelchair­dependent children on stretchers and out of their chairs to check the entire body.
NEGLECT AND ABUSE
Children with disabilities are greater than three times more likely to be abused (sexually, physically, and/or via neglect) and endure multiple abuse
,32 events when compared with children without disabilities (Sullivan 2000). They often place higher emotional, physical, economic, and social
,35 demands on their families. The added attention required, coupled with limited caregiver resources, can result in failure of the child to receive needed medications, medical care, and appropriate educational placement (see Chapter 150, “Child Abuse and Neglect”).
TECHNOLOGY­DEPENDENT CHILDREN
A technology­dependent child is one who needs a medical device to compensate for the loss of a vital body function and substantial nursing care to
 avert death or further disability. Such patients account for 70% to 90% of technology use, and malfunction accounts for nearly 10% of this
 population’s admissions. Devices include ventilators, pacemakers, tracheostomies, gastrostomy tubes, central venous catheters, ventriculoperitoneal
,37 shunts, and vagus nerve stimulators. Contact the child’s primary physician and home health nurse early in the evaluation process to avoid unnecessary tests, to determine need for inpatient admission, and to simplify care.
TRACHEOSTOMY CARE
There are many types and sizes of tracheostomy tubes, so clarify the exact tube type, size, and most recent change. Common complications related to tracheostomy tubes include decannulation, bleeding at the cannulation site, obstruction, and tube reinsertion into a false passage resulting in subcutaneous emphysema, pneumomediastinum, or pneumothorax. Granuloma or stricture formation at the stoma or tracheal wall can cause bleeding with cannula manipulation or suctioning. Erosion into the innominate artery is rare and is usually related to an inferiorly placed tracheostomy stoma. Consider otolaryngology consultation and urgent bronchoscopy for bleeding.
Infections associated with tracheostomies include tracheitis, bronchitis, and pneumonia. Normal secretions are generally clear to white and thin in consistency. Abnormal secretions are thick and yellow to green in color. Obtain a tracheal aspirate and culture in children with fever, respiratory distress, a new or increasing oxygen requirement, or a change in secretions.
MECHANICAL VENTILATION
Chronic respiratory support is necessary for a variety of conditions: neurologic and neuromuscular disease accounts for about half, and chronic lung
 disease accounts for only 7%. Ventilator­related complications, such as pneumothorax or machine failure, are managed according to standard principles. Provide bag ventilation for total ventilator failure. Table 148­4 provides a checklist for ventilator troubleshooting.
TABLE 148­4
Ventilator Troubleshooting
Alarm Possible Causes Interventions
High pressure Plugged or obstructed airway Clear obstruction
Coughing/bronchospasm Suction tracheostomy
Administer bronchodilator
Low pressure/apnea Loose or disconnected circuit Ensure all circuits are connected
Leak in circuit Check tracheostomy balloon
Leak around tracheostomy site Ensure tracheostomy is well seated
Low power Internal battery depleted Plug the ventilator into a power outlet
Setting error Settings incorrectly adjusted Manually ventilate patient
Transport ventilator and patient
Power switchover Unit switched from AC to internal battery Press “alarm silent” button after ensuring battery is powering ventilator
FEEDING TUBES

Feeding tubes are commonly present. Complications of a nasogastric tube include sinusitis, nasal and esophageal irritation, tube dislodgement or clogging, and pulmonary aspiration. Gastrostomy tubes can be associated with gastroesophageal reflux, tube dislodgement or clogging, peristomal wound infection, abdominal wall abscess, peritonitis, gastric perforation or hemorrhage, gastrocolic fistula, gastric ulceration, and gastric outlet obstruction.
Feeding tubes may become dislodged, break, or otherwise malfunction. It is important to know what size and type of tube to replace. Also knowing the position of feeding tube present (gastric tube, gastrojejunal tube) will help to ensure proper placement. Gastrojejunal tubes will often require a consult to interventional radiology for replacement. Gastrostomy tubes that become displaced require prompt replacement, because a stoma without a tube will close in a matter of hours. A Foley catheter can be placed in a stoma while awaiting appropriate gastrostomy tube replacement. Narrowed stomas may require dilation in order to pass a tube. Confirm proper placement with aspiration of gastric contents. For difficult replacements, stomas that have been present for less than  weeks, or uncertainty about position, it is best to confirm placement with a radiographic dye study (see Chapter
, “Gastrointestinal Procedures and Devices”). Additional complications of gastrojejunostomy tubes include diarrhea, tube migration, small bowel perforation, and intussusception (see Chapter , “Complications of General Surgical Procedures”).
Stomal complications include dermatitis, allergic hypersensitivity, granulation, cellulitis, and fungal infections. Superficial bleeding due to granulation tissue can be cauterized using silver nitrate sticks.
INDWELLING VENOUS CATHETERS
Indwelling catheters, often tunneled central venous catheters, can be of multiple types but will be accessible through either externalized catheter
 tubing, such as a Hickman® device, or a subcutaneous reservoir, such as a Port­a­Cath® device. Complications include occlusion, breakage, dislodgement, air embolism, phlebitis, and infection. Parenteral feeding complications include cholestasis that may lead to irreversible liver disease or metabolic bone disease. Various agents can be used to relieve catheter obstruction in the ED, such as tissue plasminogen activator in the instance of intraluminal coagulated blood, but protocols are typically institution dependent. Surgical or interventional radiology consultation may be necessary if initial attempts at removing the obstruction are unsuccessful. For breakage or dislodgement, clamp externalized catheters proximal to the affected segment and repair with a special kit if available. For nonexternalized catheters, especially when there is concern for dislodgment, seek surgical consultation promptly. Air embolism may be associated with symptoms of respiratory distress and hemodynamic instability. If air embolism is
 suspected, clamp the catheter and place the child in left­sided Trendelenburg position with supplemental oxygen. For suspected infection, obtain
 blood cultures and administer antibiotics to cover gram­positive and gram­negative organisms (Gominet 2017).
Fever in patients with externalized catheters represents a medical emergency due to risk for line infection. These patients should have central and peripheral blood cultures and be started on broad­spectrum IV antibiotics to cover both gram­positive and gram­negative organisms. Admission to the hospital is warranted in even well­appearing patients with central line and fever.
CEREBROSPINAL FLUID SHUNTS

Cerebrospinal shunt placement is the most common neurosurgical procedure performed in children. Most commonly, cerebrospinal fluid is diverted
 from the ventricles to the peritoneal cavity, but occasionally the atria and pleural spaces may be used. Complications include separation or disruption
,42  of the tubing or device, infection, and overdrainage (Table 148­5). Shunt malfunction occurs most often in the year following placement, with
  approximately 40% of standard shunts malfunctioning during this time. After the first year, the annual rate of shunt malfunction is about 5%.
TABLE 148­5
Symptoms and Signs of Ventriculoperitoneal Shunt Obstruction or Malfunction
Symptom Signs
Headache Shunt site swelling or normal exam
Visual disturbances Papilledema
Nausea or vomiting Bulging fontanelle, enlarged head, or normal exam
Lethargy and/or irritability Engorged head veins
Lack of developmental progress and/or poor school performance McEwen sign (cracked­pot sound during skull percussion)
Note: Neurologic findings include increased deep tendon reflexes or lower extremity tone, positive Babinski sign, lateral (sixth) or upward (fourth) gaze palsy (sunsetting), and respiratory compromise.
Seizures are generally accompanied by other signs and symptoms and are seldom, if ever, the only sign of shunt malfunction.
Patients with impending herniation may develop Cushing’s triad: hypertension, bradycardia, and irregular respirations. This is a late sign of impending herniation and a true neurosurgical emergency. When neurosurgical consultation is not immediately available and the patient is experiencing symptoms of herniation, removing cerebrospinal fluid by tapping the shunt reservoir may be lifesaving.
Shunt infections occur most commonly within a few months of shunt placement, many within the first few weeks, and they generally decrease in frequency with time. After  months of shunt placement, infection rates fall to a very low occurrence. Infection rates vary from 1% to 40%, with most in
 the range of 5% to 15%. Signs and symptoms of shunt infection may be nonspecific, such as fever, behavior change (irritability or lethargy), vomiting, and/or abdominal pain. Infected shunts may be accompanied by mechanical shunt failure. Antibiotics should be selected to treat gram­positive (most commonly, coagulase­negative Staphylococcus, Staphylococcus aureus, and Streptococcus) and gram­negative (Escherichia coli, Enterococcus species, and Haemophilus influenzae) species. Intra­abdominal cerebrospinal fluid loculations or peritoneal pseudocysts can occur at the distal tip of the catheter with or without peritonitis. Less common intra­abdominal complications are bowel obstruction due to adhesions, subphrenic abscess,
 and cerebrospinal­enteric fistula.
The evaluation for mechanical shunt malfunction includes plain radiographs of the skull, neck, chest, and abdomen to evaluate continuity of shunt hardware and head CT or MRI to assess ventricular size and shunt positioning. Increased cerebral ventricle size, particularly when compared with previous studies, indicates shunt malfunction. However, malfunction may be present with unchanged ventricular size due to a loss of surrounding tissue compliance. A “negative” neuroimaging study does not rule out shunt malfunction or obstruction. Approximately 11% of shunt failures present with small ventricles, and neuroimaging should not be used as the sole or definitive diagnostic modality when evaluating shunt function. If shunt malfunction or infection is suspected, consult neurosurgery for further evaluation, including shunt aspiration, nuclear medicine flow studies, admission, and monitoring. Programmable shunts will need to be reprogrammed after MRI because the magnet alters the set pressure level.
Programming requires an on­site, trained provider.
URINARY DIVERSIONS
Urinary diversions include vesicostomies, ureterostomies, ileal loop conduits, and bladder augmentations. Complications include prolapse and stomal stenosis in vesicostomies, stenosis of ureterostomies, pyelonephritis, stricture of the ureteroileal anastomosis, peristomal hernia, or stenosis in ileal loop conduits. Small bowel obstruction can be a complication of constriction of the ileal conduit. Most complications are managed in consultation with the child’s urologist.
SPECIAL POPULATIONS
DEVELOPMENTAL DISABILITY/DELAY
Developmental disability is a broad term encompassing conditions such as attention­deficit/hyperactivity disorder, cerebral palsy, seizures, stammering, and other developmental delays in children. Developmental disability is occurring with increased frequency and affects approximately
 one in six children. Children with intellectual disability can be difficult to approach, may have impaired social and communication skills, and may become aggressive or combative when confronted by new or painful stimuli. The parent or primary caregiver is the best source of information for effective interaction strategies. The various medical problems found in these patients can be specific to the underlying syndrome, but treatment is generally the same as with developmentally normal children. Review medication profiles to prevent drug interactions and to identify potential drug
 side effects.
AUTISM SPECTRUM DISORDER
Autism spectrum disorder is a category of disorders characterized by restrictive, repetitive, and stereotyped patterns of behaviors with impaired social
 interaction and communication. The disorder has a wide range of clinical expressions, severity, and levels of function. The increase in prevalence
 ,52 over the past few decades may be due to improved and earlier detection. The current prevalence is approximately  in  children. The cause is unknown, but there is no relationship with childhood immunizations. In general, most children with autism spectrum disorder do not have associated medical disorders and have medical needs similar to those of age­matched, normally developing children. Sensory defensiveness, unusual social behaviors, and aggressive self­protective responses to medical procedures and examinations can complicate medical interactions. Always ask the parents or primary caregivers about the most effective means of communication for each child, as well as specific “do’s and don’ts.” Consider reducing auditory, visual, and tactile stimulation, and allow a period of adjustment to the ED environment. If possible, limit the number of medical providers who are unfamiliar to the child. Sedation may be needed for examination and procedures.
DOWN SYNDROME
Down syndrome is a relatively common genetic disorder, most often resulting from a trisomy of chromosome , that occurs in just over  in 1000 live births. The syndrome (Table 148­1) is characterized by developmental delay, intellectual disability, congenital heart defects, GI abnormalities, thyroid dysfunction, insulin­dependent diabetes mellitus, increased risk of upper respiratory and ear infections, atlantoaxial instability, and leukemia.
Congenital heart defects affect approximately half of children and include atrioventricular canal defects, ventricular and atrial septal defects, tetralogy of Fallot, and patent ductus arteriosus. These defects generally are detected in early infancy, but pulmonary hypertension and congestive heart failure
 can develop over time if treatment is not successful. GI abnormalities occur in approximately 5% of cases and include esophageal atresia, tracheoesophageal fistula, pyloric stenosis, duodenal atresia, Meckel’s diverticulum, Hirschsprung’s disease, and imperforate anus. Therefore, feeding difficulties or vomiting in the infant with Down syndrome requires thorough investigation. Gastroesophageal reflux responds to standard therapy. Midface malformations affect the normal functioning of eustachian tubes, leading to recurrent and chronic infections of the ear, sinuses, and upper respiratory tract. Asymptomatic atlantoaxial instability is present in approximately 13% of children with Down syndrome.
Consider cervical spine injury after trauma, specificallywith deceleration injuries,which can causeatlantoaxial subluxationor
 dislocation. Children with Down syndrome, compared to those without, have a 10­ to 20­fold increased risk of developing leukemia, most commonly acute lymphoblastic leukemia.
CEREBRAL PALSY
The term cerebral palsy describes a collection of nonprogressive disorders of movement and posture originating from injury sustained by the
 developing brain within the first  to  years of life. The prevalence is  to  cases per 1000 individuals. Although motor deficits are the primary feature, cerebral palsy can also be associated with seizures, cognitive impairments, and sensory, communication, and behavioral abnormalities. There is a wide spectrum of intellectual and physical function, ranging from normal intelligence and mild motor deficits to severe disability. Cerebral palsy is often classified by the type of motor abnormality, its distribution, and the degree of involvement (Table 148­6).
TABLE 148­6
Cerebral Palsy
Motor abnormality Spastic Increased tone; muscle stiffness
Dyskinetic Involuntary, nonpurposeful, uncoordinated movements
Ataxic Wide­spaced, unsteady gait; movement uncoordinated and clumsy
Hypotonic Floppy; generalized muscle weakness and flaccidity
Distribution Diplegia Paralysis affecting symmetrical parts of the body
Paraplegia Paralysis of both legs
Hemiplegia Involvement of one half of the body
Quadriplegia Four­limb paralysis
Prenatal injury may occur from teratogen exposure, genetic syndromes, intrauterine infections, brain malformations, intrauterine cerebrovascular accidents, or fetal­placental malfunctions. The perinatal period may be affected by preeclampsia, complications of labor and delivery, sepsis or CNS infection, asphyxia, or prematurity. Older infants and children can develop cerebral palsy as a result of meningitis, traumatic brain injury, or toxic
,57 exposures. Approximately 25% of cases have no obvious cause. Children with severe spasticity may have an intrathecal baclofen pump. Baclofen pump complications include malfunction, dislodgement, infection, or acute medication withdrawal. Life­threatening baclofen withdrawal can occur and may present with malignant hyperthermia, hypotension, myoclonus, seizures, rhabdomyolysis, disseminated intravascular coagulation, multisystem organ failure, cardiac arrest, coma, and death. In addition to lifesaving supportive measures, oral baclofen and benzodiazepines are used to treat symptoms.
NEURAL TUBE DEFECTS AND SPINAL CORD INJURY
Neural tube defects result from the failure of the neural tube to close during the early embryonic stage of development and account for most congenital abnormalities of the CNS. The cause is multifactorial, but folic acid deficiency is associated with an increased risk, and maternal
 supplementation is currently recommended as early as possible in pregnancy. The most common and most severe form of neural tube defect is meningomyelocele, which involves the spinal cord, meninges, and vertebral column. Spina bifida and spina bifida occulta are other examples of neural tube defects. Patients with neural tube defects are often allergic to latex. Complex medical problems result from the impairment of sensory and motor control of voluntary and autonomic activities at or below the site of the lesion (Table 148­7). Spinal cord injury results in a similar loss of motor and sensory control below the level of the lesion. In these patients, significant osteopenia in their nonfunctioning limbs can lead to underlying fractures presenting as extremity swelling. This can occur with their routine physical therapy and care.
TABLE 148­7
Complications of Neural Tube Defects
Autonomic dysreflexia
Chiari II malformation
Cognitive impairment
Constipation
Contractures
Gastroesophageal reflux
Growth failure
Hydrocephalus
Latex allergy
Neurogenic bowel and bladder dysfunction
Osteoporosis
Recurrent urinary tract infections
Respiratory compromise
Scoliosis
Seizures
Spinal cord syrinx
Tethering of the spinal cord
Vesicoureteral reflux
Vision impairment
Autonomic dysreflexia is a serious, potentially life­threatening complication of neural tube defects and spinal cord injuries.
Autonomic dysreflexia consists of paroxysmal sympathetic and parasympathetic hyperactivity initiated by stimuli below the level of the lesion, such as bladder overdistention, fecal impaction, or fracture. The symptoms of autonomic dysreflexia are sweating, flushing, pounding headache, hypertension, bradycardia, and piloerection. The primary intervention is to determine and eliminate the offending stimulus through bladder emptying, disimpaction, discontinuation of painful procedures, or repositioning. If elevated blood pressure does not respond to repositioning or stimulus reduction, institute standard treatment for hypertensive emergencies.
Chiari Malformation
Chiari malformation consists of a downward displacement of the cerebellar tonsils through the foramen magnum, frequently causing obstructive hydrocephalus. Although mild tonsillar herniation seen in type I Chiari malformation can be asymptomatic, the more severe Chiari II is common in children with meningomyelocele and consists of malformation of the cerebellum, hindbrain, and brainstem (Table 148­8), requiring early ventricular shunt placement. Even minor cervical hyperflexion and extension injuries can cause symptoms in children with Chiari malformation; any deceleration injury, even mild, requires cervical spine stabilization and assessment for spinal cord injury due to instability of the craniocervical junction. Consider Chiari II malformation as a possible cause of new­onset stridor in the child with meningomyelocele. Monitor closely for progression to complete airway obstruction. Diagnosis requires emergent MRI of the craniocervical junction. If respiratory function is not severely compromised and the airway remains stable, outpatient disposition may be considered in consultation with subspecialists caring for the child.
TABLE 148­8
Symptoms of Chiari II Malformation
Infant Older Child
Apnea Vision dysfunction
Vocal cord paralysis Motor incoordination
Stridor Headache
Oral motor dysfunction Hand weakness
Vision disturbances
Upper extremity weakness
Incoordination
URINARY TRACT
Complications of a neurogenic bladder include recurrent urinary tract infection, urinary retention or incontinence, and complications of selfcatheterization. Medications or prophylactic antibiotics may be prescribed to enhance continence and minimize damage to the upper urinary tract.
Because bacterial colonization of the urine is common, only treat symptomatic infection with antibiotics. Suspect formation of a false passage during self­catheterization with difficult catheter passage, pain, or urethral bleeding. Do not attempt recatheterization in the ED for these symptoms, for fear of compounding the underlying injury, but obtain urologic consultation. Long­term indwelling catheterization predisposes the patient to the development of latex allergy.


