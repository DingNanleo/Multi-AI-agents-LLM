## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 35: Acute Pain Management
James Ducharme
INTRODUCTION
,2
Pain is the most common presenting symptom for patients coming to the ED, with 70% to 80% of all patients having pain as their primary complaint.

Despite increasing research and information about pain management, oligoanalgesia, or the undertreatment of pain, persists. While all patients are susceptible to oligoanalgesia, certain subgroups, such as ethnic minorities, the aged, the very young, and those with diminished cognitive function, are
4­7 more at risk (Table 35­1). Pain management can also be negatively influenced by concerns of prescription opioid misuse, a situation declared to be
 a public health epidemic in North America. An initial prescription of opioids, such as upon ED discharge, has been associated with persistence of
 opioid use months after the original visit. Nevertheless, appropriate treatment of acute severe pain should not be withheld for fear of facilitating drug
 misuse; rather, opioid use should be but one of many options considered in pain management. Pain and addiction are not mutually exclusive.
TABLE 35­1
Barriers to Adequate ED Pain Control
Patient Related Provider Related System Related
Ethnicity, gender, age (very young, very old) Inadequate education Lack of clearly articulated standards
Diminished cognitive function No objective measuring tool for pain Paucity of treatment guidelines
Fear of medications: addiction, side effects Accepting only pain reports that conform to expectations Fear of regulatory sanctions
Acceptance of pain as being inevitable Concerns of opioid addiction and drug­seeking behavior Lack of healthcare provider accountability
Unwillingness to bother healthcare providers
Specific measures to treat pain should occur in addition to, and at the same time as, treatment of the underlying illness or injury. It is not possible to generalize the extent and quality of pain control needed for a specific patient. For example, pain is an indicator of ongoing cardiac ischemia, and the goal should be to eliminate all pain. On the other hand, a patient with a traumatic injury may choose to endure more pain out of personal or cultural beliefs. Whenever possible, medications that act on specific sites that initiate the pain signal—a mechanistic approach—are preferred to agents such as opioids that mask pain, which is more a symptomatic approach. Current migraine treatment is an excellent example of the mechanistic approach; preferred treatment includes a serotonin agonist (triptan) or a dopamine antagonist (phenothiazine or metoclopramide),
 rather than opiates.
PATHOPHYSIOLOGY
Pain is the physiologic response to a noxious stimulus, whereas suffering—the expression of pain—is modified by the complex interaction of cognitive, behavioral, and sociocultural dimensions. Individual pain experience is therefore not static, but varies depending on current and past medical history, physical and emotional maturity, cognitive state, meaning of pain, family attitudes, culture, and environment. Emotions can modify pain either negatively or positively: fear and anxiety may accentuate pain, or pain can be suppressed completely if an essential task must be performed or if there is acute concern about a loved one. It is difficult for another to assess the severity of pain a patient is feeling as they cannot understand the impact of these modifying variables on any given patient. It is why self­reporting is considered the gold standard for quantifying the severity of a patient’s pain. Since pain and suffering are so intertwined, it must be recognized that a pain score using a standardized rating scale does not have more than a moderate relationship to the amount or type of analgesia required.

Chapter 35: Acute Pain Management, James Ducharme 
The peripheral nervous system (e.g., nociceptors, C fibers, A­δ fibers, and free nerve endings) initiates the sensation of somatic pain by responding to a
. Terms of Use * Privacy Policy * Notice * Accessibility noxious stimulus and sending a neuronal discharge to the dorsal horn of the spinal cord. Neurons in the dorsal horn of the spinal cord integrate and modulate input from multiple peripheral nerves and other sensory stimuli. Transmission then proceeds up the spinal cord to the CNS (e.g., hypothalamus, thalamic nuclei, limbic system, and reticular activating system) where further integration and processing generate the perception of pain. Identification and localization of pain, cognitive interpretation, and triggering of emotional and physiologic reactions also occur at these central sites. Unlike somatic pain, which is easily localized, visceral pain pathways are more complex and differ in structure from somatic pain pathways, which may explain the poor localization of visceral pain.
Opioid analgesics work by binding to receptors in the spinal cord and brain. There are four types of opioid receptors: three classic ones (delta, kappa, and mu, each with identified subtypes) and nociceptin, a receptor with significant structural homology. These receptors are found in the brain, spinal cord, and GI tract where their physiologic function is to interact with endogenous dynorphins, enkephalins, endomorphins, endorphins, and nociceptin. Opioid analgesics interact with these receptors in varying degrees, accounting for the difference in desired and adverse effects among the drugs in this class. Stimulation of the mu­1 (µ ) receptor produces supraspinal analgesia. Stimulation of the mu­2 (µ ) receptor results in euphoria,
  miosis, respiratory depression, and depressed GI motility. Stimulation of the delta (δ) receptor produces analgesia, but less than the µ receptor, and
 also exerts an antidepressant effect. Stimulation of the kappa (κ) receptor produces dysphoria, along with dissociation, delirium, and diuresis by inhibiting antidiuretic hormone release. Opioid receptors, surprisingly, are not linked to addiction, which is much more closely linked to the cannabinoid­1 receptor.
EVALUATION
Document the degree of pain on initial assessment. This process serves to identify patients with severe pain and facilitate pain treatment. ED pain assessment should determine duration, location, quality, severity, and exacerbating and relieving factors. The patient’s subjective reporting of pain, not the healthcare provider’s impression, is the basis for pain assessment and treatment. There is a weak correlation between nonverbal signs, such as tachycardia, tachypnea, and changes in patient expression and movements, and the patient’s report of pain, so do not rely on
,13  these to determine the severity of a patient’s pain or their response to treatment. Because pain is dynamic and changes with time, periodic pain reassessment is needed.
PAIN SCALES
,16
Although standardized scales for measuring reported pain are commonly used, their impact on effective pain control is uncertain. The primary purpose of pain scales is to quantitate pain severity, guide the selection and administration of an analgesic agent, and reassess the pain response to determine the need for repeated doses or alternative analgesics. Pain scales are also essential in pain management research, enabling reproducible comparisons of interventions. Some studies have suggested that the use of pain scales may actually decrease the provision of analgesics. Given the subjectivity both of pain reporting and the provider’s interpretation of such reporting, the use of simple descriptors such as “a little” or “an awful lot” is equally valid in the clinical setting. What is important is that the patient’s subjective reporting should be the basis for assessment and management. For most, but not all, painful conditions, the goal is to control pain to the level the patient desires. Once it is determined a patient requires pain management, asking if the patient requires more analgesic may even be simpler and accomplish more
,18 than using any standardized pain evaluation tool.
Several self­report instruments are valid in patients with acute pain, with some requiring only a verbal response (Table 35­2). Each tool has advantages and specific limitations. ED personnel in any one location should use the same tool so information collected is standardized. A value
 assigned by a patient is not an absolute value but rather a reference point based on past personal experience.
TABLE 35­2
Pain Scales20
Scale Method Comments
Adjective Patient rates pain by choosing from an ordered list of pain Easy to administer.
rating scale descriptors, ranging from no pain to worst possible pain, with
(Figure 35­ allowance for marks between discrete labels.
1)
Visual Patient places a mark that best describes pain intensity along a Pain intensity measured in millimeters from the no­pain end.
analog scale 10­cm linear scale marked at one end with a term such as no A difference of  mm is the minimum clinically significant change
(VAS) pain and at the other end with worst imaginable pain. noticeable by patients, whereas an average decrease of  mm
(Figure 35­ appears to be the minimum acceptable change for pain control.
2)
Numeric The patient is asked to self­report pain on a scale of  to  with Can be used in patients with visual, speech, or manual dexterity rating scale descriptors for , , and . difficulties by using upheld fingers.
(Figure 35­ Not as discriminating as the VAS.
3)
5­Point Patient rates pain as: A decrease of  point is a large change; scales with more choices allow global scale  = none monitoring of small changes in pain and may be more sensitive to
 = a little changes.
 = some
 = a lot
 = worst possible
Verbal The patient is asked to self­report pain on a scale of  to  Most commonly used scale; easy to administer.
quantitative without descriptors.
scale
FIGURE 35­1. Pain scale: Adjective rating scale.
FIGURE 35­2. Pain scale: Visual analog scale (VAS).
FIGURE 35­3. Pain scale: Numeric rating scale.
PAIN SCALE PERFORMANCE IN SPECIAL PATIENT POPULATIONS
The elderly often report pain differently from younger patients because of physiologic, psychological, and cultural changes associated with aging.
Visual, hearing, motor, and cognitive impairments can be barriers to effective pain assessment. Using a numerical pain scale, the elderly may also experience a decrease in the minimum clinically significant noticeable difference in acute pain over time, making it difficult to assess response to
,22 successive doses of analgesics. Family members and caregivers are often able to judge nonverbal actions of the patient as representing pain or
 distress, so they should be used if available to help with pain assessment in the noncommunicating elderly patient.

Trauma patients and those with acute intoxication do not perform as well on pain scales. Women are more likely to express pain and to actively seek
,26 treatment for pain, yet there is a tendency to underestimate and undertreat pain in women. Ethnicity of both the patient and the physician has a
 bearing on different cultural concepts of pain and on the characteristics of culturally appropriate pain­related behaviors. Translators and family
 members should be asked to provide assistance. There is also interplay between the ethnicity of the patient and that of the physician. When there are language difficulties or cross­cultural differences, the visual analog scale is the preferred pain assessment tool because it is the least affected by these factors.
PHARMACOLOGIC ACUTE PAIN TREATMENT
The administration of pharmacologic agents is the mainstay of acute pain management. The key to effective pharmacologic pain management in the ED is selection of an agent appropriate for the intensity of pain, time to onset of analgesic activity, ease of administration,
 safety, and efficacy. Acute pain is usually accompanied by anxiety and feelings of loss of control. Management of the suffering component of acute pain may be best managed by restoring emotional control and providing information about the situation. If verbal reassurance combined with an analgesic does not suffice, an anxiolytic may be useful.
The “tiered approach” to pain management starts with an agent of low potency regardless of pain intensity, assesses the response after a clinically relevant period, and sequentially changes to agents of higher potency if pain persists. The tiered approach to acute pain management unnecessarily subjects the patient to more prolonged suffering. It is preferable to select initial analgesics that are appropriate to treat the intensity (mild, moderate, or severe) of the patient’s pain. Agents such as NSAIDs should be considered for mild to moderate pain or when targeting severe pain originating from smooth muscle spasm such as renal or biliary colic. Systemic opioids should be reserved for severe nociceptive pain (Table 35­3); opioids have little if any role in managing acute neuropathic pain or acute pain flares linked to chronic pain states. In specific instances such as renal and biliary colic, although parenteral NSAIDs may control severe pain, combination therapy with an opioid is usually superior.
TABLE 35­3
Pain Severity With VAS or NRS
Pain Severity VAS (0 to 100 mm) or NRS (0 to 10)
Mild VAS:  to 30–40 mm or NRS:  to 3–4
Moderate VAS:  to 60–70 mm or NRS:  to 6–7
Severe VAS: >60–70 mm or NRS: >6–7
Abbreviations: NRS = numeric rating scale; VAS = visual analog scale.
When possible, local or regional anesthesia can be a useful adjunct. Peripheral nerve blockade for pain control and for procedures is an excellent
,29 option, especially if guided by US (see Chapter , “Local and Regional Anesthesia”).
OPIOID ANALGESICS
Opioid analgesics are the cornerstone of pharmacologic management for severe acute pain (Table 35­4). The term opiate refers to agents that are structurally related to natural alkaloids found in opium, the dried resin of the opium poppy. The term opioid describes any compound with pharmacologic activity similar to an opiate, regardless of chemical structure. Opioid use in the ED is often affected by concern for the precipitation of adverse events, such as respiratory depression or hypotension, or for facilitating drug­seeking behavior. Based on World Health Organization recommendations, amounts of opioids prescribed per capita are excessive in North America, but this should not preclude the use of opioids for ED patients in severe pain; when opioids are felt to be indicated, they should be titrated to effect based on patient feedback or with patientcontrolled analgesia systems. Considerations for use of different opioids include (1) desired onset of action; (2) available routes of administration; (3) duration of action, which will determine achievable frequency of administration; (4) concurrent use of nonopioid analgesics and adjunctive agents; (5) possible incidence and severity of side effects; and (6) continuation of the agent in an inpatient or ambulatory setting.
TABLE 35­4
Pain Treatment: Initial Opioid Dosing
Typical
Drug [Origin, Class] Initial Adult Pharmacokinetics Comments
Dose
Morphine [natural alkaloid 2–6 milligrams Onset: 1–2 min IV, 10–15 Histamine release may produce transient hypotension or nausea and phenanthrene] IV min IM/SC, and  min emesis; neither requires routine adjunctive treatment.
 milligrams PO IR tablet
IM/SC Peak effect: 3–5 min IV,
10–30 15–30 min IM/SC, and  milligrams PO h PO IR tablet
IR tablet Duration: 1–2 h IV, 3–4 h
IM/SC, and 3–5 h PO IR tablet
Hydromorphone .5–2 Onset: 5–15 min IV More euphoria inducing than morphine.
[semisynthetic phenanthrene] milligrams IV Peak effect: 10–20 min
1–2 milligrams IV
IM Duration: 2–4 h IV
Fentanyl [synthetic 50–100 Onset: <1 min IV Less cardiovascular depression than morphine.
phenylpiperidine] micrograms IV Peak effect: 2–5 min IV High doses (>5 micrograms/kg IV) can cause chest wall rigidity.
Duration: 30–60 min IV
100­microgram Used for breakthrough pain in opioid­tolerant cancer patients.
nasal spray in Wait >2 h before treating another episode.
 nostril30 May increase dose by 100 micrograms per episode.
100­microgram Used for breakthrough pain in opioid­tolerant cancer patients.
buccal mucosa May repeat after  min.
tablet31 Wait >4 h before treating another episode.
May increase dose by 100 micrograms per episode.
Available transmucosal forms not bioequivalent.
Meperidine (pethidine) 25–50 Onset:  min IV Contraindicated when patient has taken a monoamine oxidase inhibitor
[synthetic phenylpiperidine] milligrams IV Peak effect: 5–10 min IV within the past  d to avoid precipitating serotonin syndrome.
50–150 Duration: 2–3 h IV Neurotoxicity may occur when multiple doses are given for >48 h or with a milligrams total daily dose >600 milligrams, especially in the presence of renal failure.
IM/SC
Oxycodone [semisynthetic 5–10 Onset: 10–15 min PO Lower incidence of nausea than other opioids.
phenanthrene] milligrams PO Duration: 3–6 h PO Possible inadvertent acetaminophen overdose with combination agents.
Hydrocodone/acetaminophen 5/325–10/325 Onset: 30–60 min PO Lower incidence of nausea than other opioids.
[semisynthetic phenanthrene] milligrams PO Duration: 4–6 h PO IR tablets only available as hydrocodone­acetaminophen combination; possible inadvertent acetaminophen overdose with concomitant use of nonprescription acetaminophen.
Codeine [natural alkaloid 30–60 Onset: 30–60 min PO High incidence of GI side effects.
phenanthrene] milligrams PO and 10–30 min IM Some patients cannot convert to codeine­6­glucuronide and morphine.
30–100 Duration: 4–6 h PO and Possible inadvertent acetaminophen overdose with combination agents milligrams IM IM or with concomitant use of nonprescription acetaminophen.
Tramadol [other] 50–100 Onset:  h PO CNS side effects common.
milligrams PO Duration: 4–6 h PO
Abbreviation: IR = immediate release.
32­34
Opioids should be titrated to effect after the initial dose as patients differ greatly in their response to opioid analgesics. Variation in pain
,36  reduction is related to age, initial pain severity, and previous or chronic exposure to opioids, but not body mass or gender. Relative potency
,39 estimates provide a rational basis for selecting the appropriate starting dose to initiate analgesic therapy, changing the route of administration
(e.g., from parenteral to PO), or switching to another opioid (Table 35­5), but undue reliance on these ratios is an oversimplification with potential for
 over­ or underdosing.
TABLE 35­5
Equipotent Opioid Doses
Equipotent Parenteral Dose Equipotent PO Dose Morphine Milligram Equivalents (MME)* for PO
Drug
(milligrams) (milligrams) Dosing
Morphine   (acute) and  (chronic) 
Hydromorphone .5 .5 
Fentanyl .1 .2 (transmucosal) .4 (transdermal in micrograms/h)
Meperidine  300 .1
(pethidine)
Oxycodone —  .5
Hydrocodone —  
Codeine 120 200 .15
Tramadol — 300 .1
*Multiply the dose for each opioid by the conversion factor to determine the dose in MMEs.
Oral opioids are often manufactured in combination with acetaminophen (paracetamol), ibuprofen, or aspirin. There is evidence that such combinations possess a synergistic effect in treating chronic pain. It is possible for the patient to consume a toxic amount of the nonopioid component with frequent dosing. Patients may also consume a toxic amount by continuing to take their nonopioid analgesic in addition to the prescribed opioid combination. Avoid prescribing combinations upon patient discharge.
Opioid hypersensitivity is uncommon, and true allergic reactions are extremely rare. There is minimal evidence of clinical cross­sensitivity within opioid classes, with the possible exception that cross­sensitivity has been suggested among the phenylpiperidines (fentanyl, alfentanil, and sufentanil). Until more is known, it would be prudent to switch to a drug from a different opioid class if a patient develops a hypersensitivity reaction. When used in equianalgesic doses, there is no compelling evidence to recommend one opioid over another. As much as possible, avoid using multiple agents, and titrate a single drug to the desired effect.
Codeine is not a reliable analgesic, and it produces more nausea, vomiting, and dysphoria than other opioids. The analgesic effect of codeine is highly dependent on the metabolic conversion to the active metabolites codeine­6­glucuronide and morphine. Up to 10% of the U.S. population, and 30% of
Asians are deficient in the relevant enzymes for this conversion and cannot obtain any analgesic response. Conversely, there are case reports of neonatal deaths as a result of breastfeeding from mothers who were hypermetabolizers of codeine. In addition, the standard PO dose of  to 
,42 milligrams produces little analgesic effect above that of acetaminophen or NSAIDs alone.

Tramadol binds to mu receptors and weakly inhibits the reuptake of norepinephrine and serotonin, producing a central opioid analgesic effect.
Tramadol is extensively metabolized by cytochrome P450 enzymes into more potent opioid metabolites, with desmetramadol binding to the mu receptor at 700­fold higher affinity than the parent compound. Thus, the analgesic potency of tramadol varies according to the patient’s cytochrome
P450 activity. Common side effects include dizziness, nausea, constipation, and headache. Tramadol can induce serotonin syndrome. Severe toxicity can include agitation and seizures. Tramadol is one of the many substances that can produce a false­positive result on the urine phencyclidine
 screen.
Meperidine (pethidine) was removed from the World Health Organization list of essential medications in 2003, and its use in North America has
 decreased because of its potential for addiction and adverse side effects. Meperidine is considered to produce more elation than other opioids, prompting concern the euphoria induced will more likely lead to continued use, misuse, and addiction. Meperidine can interact with many drugs to
,47 precipitate serotonin syndrome, although this interaction is also seen with other opioids. Compared to other opioids, meperidine is associated
 with an increased risk of delirium in the elderly. Meperidine is metabolized to normeperidine, which has neuroexcitatory properties and a long
 elimination half­life (24 to  hours). With continued use, such as duration greater than  hours or total daily dose greater than 600 milligrams,
 normeperidine can accumulate and produce toxicity, typically seizures, in the elderly and those with renal failure, although this is a rare event.
Adverse effects of opioids include nausea, vomiting, constipation, pruritus, urinary retention, confusion, and respiratory depression. Pruritus, urinary retention, confusion, and respiratory depression are more common with IV, transmucosal, and epidural administrations as opposed to PO administration.
Adjuncts are sometimes used to enhance the analgesic effect, reduce the amount of opioid required, and prevent side effects (Table 35­6).
Depending on the agent, amount, route, and setting, a beneficial effect can be seen. However, appropriate titration with opioids in the ED is highly
 effective, and there are few data to support the routine use of adjuncts with opioids in the ED. Pretreatment with antiemetics is not necessary given
 the low risk of emesis, but symptom­targeted therapy is sometimes necessary.
TABLE 35­6
Opioid Pain Management: Adjunctive Medications
Drug Initial Dosing Elimination Half­Life Comments
Ondansetron 4–8 milligrams IV/PO 3–6 h Can prolong QT interval
Prochlorperazine 5–10 milligrams IV/IM/PO  h Can cause extrapyramidal reactions
Promethazine 25–50 milligrams IV/IM 7–14 h Can cause extrapyramidal reactions
Metoclopramide 5–10 milligrams IV/IM/PO 5–6 h Can cause extrapyramidal reactions
Transdermal formulations are not useful for acute pain treatment because of delayed onset and prolonged duration of action. Transdermal fentanyl and transdermal buprenorphine preparations are used for chronic pain, particularly in cancer patients. When such patients are treated for acute pain in the ED, it is best to remove the delayed­release transdermal opioid patches to better titrate the acute opioid dose and to minimize adverse reactions from the combination of agents.
OPIOID AGONISTS­ANTAGONISTS
Opioid agonists­antagonists are used to minimize some of the adverse effects of pure opioid agonists (Table 35­7). The major benefit claimed is a ceiling on respiratory depression, with no further reduction in respiration with increasing doses past a set amount. It is not clear if there is a ceiling effect for analgesia. The variability in efficacy relates to each particular agent’s affinity for the various central opioid receptors. These agents may precipitate withdrawal symptoms in opioid­addicted patients due to the antagonistic effect.
TABLE 35­7
Pain Management: Initial Opioid Agonist­Antagonist Dosing
Morphine Milligram
Drug [Class] Initial Dosing Pharmacokinetics Comments
Equivalents (MME)
Buprenorphine [synthetic .3 milligram IV/IM every  h Onset: rapid  (approximate, no reliable Sedation, dizziness, phenanthrene] 75­microgram buccal film every Elimination half­life: 20– conversion) nausea
 h  h
Butorphanol [synthetic  milligram IV or  milligrams Onset: <1 min  Sedation, dizziness, morphinan] IM every 3–4 h Elimination half­life: 5–6 nausea
 milligram nasal spray every h
3­4 h
Dezocine* [synthetic .1 milligram/kg IV every  h Onset:  min IV and  4–6 Dizziness, respiratory benzomorphan] min IM depression
Elimination half­life:  h
Nalbuphine [synthetic  milligrams IV/IM/SC every 3– Onset: 2–3 min IV and  Sedation, headache, phenanthrene]  h <15 min IM dizziness
Elimination half­life:  h
Pentazocine [synthetic  milligrams IV/IM/SC every 3– Onset: 2–3 min IV and .37 CNS side effects benzomorphan]  h 15–20 min IM
Elimination half­life: 2–3 h
*No longer clinically used in Western countries.
NONOPIOID AGENTS

Acetaminophen (paracetamol) is an effective analgesic for acute mild to moderate pain, but is not effective for persistent or chronic pain (Table

35­8). Acetaminophen does not affect platelet aggregation and does not have anti­inflammatory properties. No dosage change is required for renal or mild hepatic impairment. An important precaution is to carefully monitor nonprescription acetaminophen use when concomitantly using combination opioid­acetaminophen products.
TABLE 35­8
Pain Management: Nonopioid Analgesics
Drug Adult Dosage Comments
Acetaminophen 325–1000 milligrams PO every 4–6 h Liver dysfunction and necrosis.
(paracetamol) 325–650 milligrams PR every 4–6 h Maximum oral dose is  grams/d under direction of physician but no more
If >50 kg:  gram IV every  h than  grams/d when using nonprescription product.
If <50 kg:  milligrams/kg IV every  h Maximum IV dose is  grams/d if >50 kg body weight and .75 grams/d if <50 kg body weight.
Not effective for chronic pain.
Aspirin 325–650 milligrams PO every  h GI irritation and mucosal bleeding.
(acetylsalicylic 300–600 milligrams PR every 4–6 h Platelet dysfunction.
acid) Tinnitus, CNS toxicity, metabolic acidosis.
Maximum dose is  grams/d.
Ibuprofen 400–800 milligrams PO every 4–6 h GI upset, platelet dysfunction, renal dysfunction, bronchospasm.
(NSAID) 400–800 milligrams IV every  h Maximum dose is 3200 milligrams/d.
Naproxen 250–500 milligrams PO every 8–12 h GI upset, platelet dysfunction, renal dysfunction, bronchospasm.
(NSAID) Maximum dose is 1250 milligrams on initial day and 1000 milligrams on subsequent days.
Indomethacin 25–50 milligrams PO every  h GI upset, platelet dysfunction, renal dysfunction, bronchospasm.
(NSAID) 25–75 milligrams PR every 6–8 h Maximum dose is 200 milligrams/d.
Ketorolac  milligrams IV/IM every  h GI upset, platelet dysfunction, renal dysfunction, bronchospasm.
(NSAID)  milligrams PO every 4–6 h Greater risk of GI bleeding than ibuprofen.
Use limited to  d IV and  d PO.
Maximum IV/IM dose is 120 milligrams/d, but if age >65 y or weight <50 kg, then maximum dose is  milligrams/d.
Maximum PO dose is  milligrams/d.
Ketamine .1–0.3 milligram/kg (maximum  milligrams) IV over No renal or hepatic adjustment; administer slowly to reduce dystonic
10–15 min; can repeat in 1–15 min up to .5 reactions, laryngospasm, or mental status changes; adverse effects milligram/kg; can follow by IV infusion of .1–0.2 uncommon with single doses; dizziness, agitation, and hallucinations possible milligram/kg per h with higher doses.
Lidocaine Fixed dose: 50–150 milligrams IV No consistent benefit in migraine, renal colic, or radicular low back pain.
Weight­based dose: 1–2 milligrams/kg IV Adverse effects noted in 9% of patients.
Not U.S. Food and Drug Administration approved for acute pain management.
Aspirin and the NSAIDs are both anti­inflammatory agents and analgesics. As anti­inflammatory agents, aspirin and NSAIDs decrease the production of prostanoids and arachidonic acid–mediated inflammatory peptides generated at the site of tissue injury, diminishing the inflammatory response seen with some noxious stimuli. As analgesics, inhibition of the cyclooxygenase­2 enzyme in the spinal cord decreases the excitability of dorsal horn neurons that produce hyperalgesia and allodynia. These agents do not cause sedation or respiratory depression or interfere with bowel or bladder
 function. NSAIDs have significant opioid dose­sparing effects and are more effective than acetaminophen for acute musculoskeletal pain. There is no consistent evidence that the combination of acetaminophen and ibuprofen is more effective than either agent singly for acute pain in the ED.
Adverse effects of NSAIDs include platelet dysfunction, GI irritation and mucosal bleeding, nephropathy, headaches, and dizziness. All NSAIDs increase
,56 the risk of cardiac death in patients with ischemic heart disease. NSAID­induced acute renal failure is more common in elderly patients and in those who are volume depleted, have preexisting renal or cardiac disease, or are taking loop diuretics. Alternating acetaminophen and an NSAID using standard doses every  to  hours is one approach to reducing toxic side effects when treating acute pain for several days.
OTHER PHARMACOLOGIC AGENTS
Ketamine
A phencyclidine derivative, ketamine produces analgesia and/or dissociative anesthesia with the advantage of causing minimal respiratory depression at usual doses (see Chapter , “Procedural Sedation and Analgesia in Adults”). Low­dose (subdissociative or analgesic dose) infusions of ketamine
,58 are effective in combination with opioids for patients in severe pain. Ketamine dosing for analgesia is typically an IV loading dose, followed by
 repeat doses or a continuous infusion (Table 35­8). IV ketamine works best as an adjunct to opioids for patients in severe pain, reducing the amount
,60 ,62 of opioids required, as with pain associated with sickle cell vaso­occlusive crisis. Occasionally, ketamine can be effective on its own for acute
 severe pain. Adverse effects such as dysphoria, hallucinations (at times frightening), and dissociative symptoms have been reported with even these
57­59 low doses of ketamine.
Lidocaine
Lidocaine, a local anesthetic, has been studied as an IV systemic analgesic for perioperative and neuropathic pain. A small number of studies have been done using fixed (50 to 150 milligrams) or weight­based dose (1 to  milligrams/kg) IV lidocaine for ED pain management in patients with
64­66 migraine, renal colic, radicular low back pain, and critical limb ischemia. There is no consistent benefit with IV lidocaine when compared with standard therapy (morphine, fentanyl, ketorolac, dihydroergotamine, or chlorpromazine) for the appropriate condition.
Nitrous Oxide
Nitrous oxide is a fast­onset, short­acting analgesic and sedative inhalational agent useful for brief, minor procedures (see Chapter 37) and for
,68 prehospital analgesia. The primary adverse effects are nausea and vomiting. Nitrous oxide as a preblended 50% mixture with oxygen and administered to the patient by facemask provides variable results in terms of pain relief and sedation. If available, the 70/30 nitrous oxide/oxygen mixture is consistently effective. While minimally available in the United States, the latter mixture is used routinely in pediatric departments in Canada, the United Kingdom, and Australasia. Barriers to ED use of nitrous oxide seem to be related to misunderstanding of risk as well as concern of misuse by staff. An effective scavenging system is mandatory and is now standard in all available systems. Nitrous oxide is contraindicated in patients with altered mental status, head injury, suspected pneumothorax, or perforated abdominal viscus. Severe pulmonary disease also may alter the respiratory elimination of nitrous oxide.
Antidepressants and Anticonvulsants
Patients with acute­onset neuropathic pain, such as postherpetic or trigeminal neuralgia, are difficult to treat with short­acting opioid analgesics. It may be difficult to identify neuropathic causes of pain in ED patients, but if suspected, cyclic antidepressants, serotonin­norepinephrine
,70 reuptake inhibitors, or anticonvulsants can be initiated (Table 35­9). When initiating an agent for patients with new­onset neuropathic pain, close follow­up with the primary care physician is important so that titration to effect may continue. Patients already taking one of these agents for chronic neuropathic pain may require either titration upward of their medication or addition of a second agent; this should be discussed with the patient’s regular physician.
TABLE 35­9
Pain Management: Neuropathic Pain Syndromes
Typical Effective Dosage
Drug Use Initial Dosage Titrate
(Maximum Daily Dose)
Amitriptyline Chronic pain 25–50 milligrams PO once in the evening Increase over 2–3 wk 10–50 milligrams/d PO (maximum or nortriptyline 150 milligrams/d)
Carbamazepine Trigeminal 100 milligrams PO twice per day Increase 100–200 200–400 milligrams PO twice per neuralgia milligrams/d day (maximum 1200 milligrams/d)
Oxcarbazepine Trigeminal 300 milligrams PO daily Increase to 300 450–1200 milligrams PO twice per neuralgia milligrams PO twice a day day after  d
Duloxetine Diabetic  milligrams PO once per day Increase after  wk on  milligrams PO once per day neuropathic initial dose (maximum  milligrams/d) pain
Gabapentin Neuropathic For neuropathic pain: 300 milligrams PO  times a day Titrate by increasing Neuropathic pain: 300–1200 pain, For postherpetic neuralgia: 300 milligrams PO on day by 300 milligrams per milligrams PO  times per day postherpetic , followed by 300 milligrams PO twice a day on day , day up to effective Postherpetic neuralgia: 1800–3600 neuralgia and 300 milligrams PO  times a day on day  dose milligrams/d (maximum 3600 milligrams/d)
Pregabalin Neuropathic  milligrams PO  times per day or  milligrams PO Increase over  wk 150 milligrams PO twice per day to pain, twice per day 100 milligrams PO  times per day postherpetic (maximum 600 milligrams/d) neuralgia
Topical Medications
Topical administration of medications at the site of injury or inflammation can provide pain relief with reduced systemic drug absorption and a lower
,72 risk of adverse drug reactions (Table 35­10). This approach differs from transdermal drug administration to achieve systemic effects, typically with opioids. Topical NSAIDs are effective for treating acute soft tissue injuries such as sprains and strains and also for treating chronic joint pain from osteoarthritis. Topical lidocaine therapy is effective for patients with postherpetic neuralgia and diabetic neuropathy. Topical capsaicin has produced variable results depending on the treatment population and dose applied; regular use appears necessary for prolonged pain relief. A single 60­minute application of a high­dose preparation (8% capsaicin topical patch) is effective for postherpetic neuralgia, but requires professional application and removal to minimize side effects.
TABLE 35­10
Pain Management: Topical Analgesic Agents
Agent Preparation Comments
Diclofenac 1% gel Gel: apply using dosing card—4 grams for knees, ankles, and feet, and  grams for elbows, wrists, and hands. Lightly rub
.3% topical until absorbed. Use up to  times a day. Maximum total daily dose is  grams.
patch Patch: apply to intact skin at most painful site twice a day.
Ibuprofen 5% gel Squeeze 50–125 milligrams (4–10 cm) of the gel from the tube and lightly rub into the affected area until absorbed. Apply up to  times per day.
Ketoprofen .5% gel Squeeze 2–4 grams (5–10 cm) of the gel from the tube and lightly rub into the affected area until absorbed. Apply 2–4 times per day.
Lidocaine 5% gel Gel: apply a moderately thick layer to the affected area (approximately 1/8 inch thick). Allow time for numbness to
5% topical develop. Best results obtained  min to  h after application.
patch Patch: apply to intact skin to cover the most painful area. Up to  patches can be applied in a single application. Patch may be cut to size to fit. Use only once for up to  h within a 24­h period.
Capsaicin .025% Cream and gel: apply to affected area not more than 3–4 times daily. Massage into area until thoroughly absorbed.
cream Patch: only for postherpetic neuralgia.
.075% Requires physician or healthcare professional application. Applied for  min. Treatment may be repeated every  mo.
cream
.1% gel
8% patch
Methyl 10% patch Use only one patch at a time. Apply patch to the affected area and leave on for 8–12 h.
salicylate Do not use more than  patches per day and do not use for more than  d in a row.
The primary adverse reaction of topical medications is local burning, particularly seen with capsaicin, which is derived from chili peppers. Rare cases of
 localized burns have been reported with topical muscle and joint pain relievers. Most of the serious burns were associated with agents containing menthol (>3% concentration) and/or methyl salicylate (>10% concentration).
PRECAUTIONS
Safe and effective use of opioids is facilitated by choosing an appropriate initial dose and subsequently titrating additional doses toward the desired effect, thus avoiding overmedication and minimizing unwanted effects. Excessive doses of opioids given without titration and patient feedback can result in respiratory depression and decreased levels of consciousness. Hypotension is infrequent, is almost always due to histamine release with the first dose of medication, and is usually of short duration. With comorbidities, such as altered mental status, hemodynamic instability, respiratory dysfunction, or multisystem trauma, initial dosing should be decreased.
The Elderly
Acute pain management for the elderly can be a challenge; these patients may have more than one source of pain and/or multiple comorbidities and
 are at increased risk for drug–drug and drug–disease interactions. Opioid­naive elderly patients are more sensitive to the analgesic effects of opioid drugs because they experience a higher peak and longer duration of pain relief. Moreover, they are more sensitive to sedation, respiratory depression, and cognitive and neuropsychiatric dysfunction. Initial IV opioid doses in the elderly are typically half those used in younger adults, although single
 doses may not achieve adequate pain control for elderly patients with acute severe pain.
Addiction and Dependence
Addiction is the misuse of a medication or drug to the detriment of the patient’s well­being. Dependence infers that abrupt cessation of a medication will result in acute withdrawal symptoms. Dependence on opioids requires regular daily usage for  to  weeks in most patients, whereas addiction may occur after one use of heroin or even a few pills of a prescribed opioid. Consider carefully risk factors for misuse, such as concomitant mental health illness or previous drug or alcohol abuse, when prescribing opioids (see Chapter 292, “Substance Use Disorders”). There is no validated assessment tool to classify ED patients for abuse risk. When uncertain, the general approach is to err on the side of acute pain control, using nonopioid
 options whenever possible. Management in opioid­tolerant patients can be a challenge. Although EDs are not where most cases of opioid addiction
  originate, they are perceived as a potential perpetuator of misuse. Distinguishing patient requests for medications because of oligoanalgesia from addiction often requires multiple patient assessments over time; subjective assessment in the ED during a single visit is usually inaccurate for identifying addiction versus aberrant behavior due to oligoanalgesia.
Renal and Hepatic Dysfunction
Because most analgesics are metabolized by the liver or kidney, care must be taken when giving opioids to patients with impaired hepatic or renal function. Renal excretion is a major route of elimination for such pharmacologically active opioid metabolites such as morphine­6­glucuronide and dihydrocodeine. Mild renal failure can impede excretion of the metabolites of many opioids, resulting in clinically significant narcosis and respiratory depression. In patients with renal failure, hydromorphone and fentanyl are the preferred opioids. Mild hepatic dysfunction has little effect on opioid metabolism. In patients with severe hepatic dysfunction, titration with low doses of analgesics will minimize the risk of overdose.
Respiratory Insufficiency
Patients with respiratory insufficiency and those with chronic obstructive pulmonary disease, cystic fibrosis, and neuromuscular disorders affecting respiratory effort (e.g., muscular dystrophy and myasthenia gravis) are particularly vulnerable to the respiratory depressant effects of opioids and nitrous oxide. Careful dose titration and monitoring of oxygenation and ventilation are necessary. Ketamine may be a useful alternative agent in such cases.
Drug Interactions
Opioids may have adverse synergistic sedative effects in patients with psychiatric illnesses taking anxiolytics or other psychoactive drugs. The cyclic antidepressants clomipramine and amitriptyline may increase morphine levels and potentiate the opioid effects. The combination of opioids with benzodiazepines carries a high risk of central sleep apnea and should be used with caution.
NONPHARMACOLOGIC MODALITIES
Traditionally, nonpharmacologic techniques of pain management in the ED have been limited to application of heat or cold and immobilization and
 elevation of injured extremities. Other techniques may be useful in the ED and after discharge. Cognitive­behavioral techniques can be effective in reducing pain and anxiety, may control mild pain when used alone, and can enhance patient satisfaction. Such techniques include reassurance, explanation, reframing, relaxation, breathing exercises, music, psychoprophylaxis, biofeedback, guided imagery, hypnosis, and distraction. They are a useful adjunct to pharmacologic management of moderate to severe pain. Successful application of these therapies requires a cognitively intact patient and skilled personnel, but many of the techniques require only a few minutes to teach the patient.
Physical nonpharmacologic agents are becoming increasingly relevant to acute pain management. In addition to the traditional techniques noted above, less commonly used physical modalities, such as transcutaneous electrical nerve stimulation and acupuncture, may have some potential role in the ED. Although specific technical skills and equipment are required, there is no need for IV access, and there is no systemic effect such as respiratory depression or altered mental status.
SPECIFIC SITUATIONS
ABDOMINAL PAIN
Early administration of IV opioids is safe for the treatment of acute abdominal pain in the ED and does not affect the accuracy of the evaluation,
 diagnosis, or management. The one valid concern regarding analgesia and abdominal pain is that reduction in pain does not indicate improvement
 in pathophysiology. Analgesia without proper evaluation is as inappropriate as proper evaluation without analgesia.
TRAUMA
,82
Patients in shock and those with trauma, burns, and hemodynamic or respiratory instability need judicious use of opioids. Fentanyl, first as a bolus and then as an infusion, may be the opioid of choice due to its lesser impact on hemodynamic function and shorter duration of action. Use of regional
 analgesia is encouraged. NSAIDs should not be given to patients with major trauma due to the risks of excessive bleeding from platelet dysfunction and gastric stress ulcers and the potential for acute renal failure in a volume­depleted patient.
DISPOSITION
Although rare, intractable acute pain can be a primary reason for hospital admission. Otherwise, most patients may be safely discharged with a plan for pain management that includes instructions for use of immediate­release analgesics (i.e., those with a duration of action of up to  hours).
,84
Persistent pain after ED discharge is common. Prescriptions for long­acting agents (e.g., methadone, controlled­release preparations of morphine or oxycodone) are generally avoided upon ED discharge but are sometimes used for those with cancer in whom short­acting agents are no longer effective (see Chapter , “Chronic Pain”).
Patients should be counseled to take subsequent doses on a regular basis or when their pain begins to return, rather than when it approaches its peak. Patients with recurrence of severe pain, changes in the quality of pain, or persistence of pain longer than  hours should be told to return to the ED for reassessment. If opioids are prescribed to the elderly or those naive to narcotics, home observation by a responsible adult is recommended so that adverse effects can be quickly recognized. Discharge instructions for those given opioids should include instructions to avoid making important decisions while medicated and to avoid driving, operating machinery, climbing or working from heights, and so on, and should also include instructions for treatment of constipation. The patient should be instructed to not take acetaminophen or ibuprofen within  hours of an opioid combined with the same agent. Education about securing opioid prescriptions is also required because up to 85% of prescription opioids misused by adolescents come from their parents’ medication cabinet.


