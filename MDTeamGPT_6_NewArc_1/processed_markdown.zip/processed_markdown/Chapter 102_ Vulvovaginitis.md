## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 102: Vulvovaginitis
Ciara J. Barclay­Buchanan; Melissa A. Barton
INTRODUCTION
Content Update October 2021
CDC recommendations for Bacterial Vaginosis, Trichomonas, and Genital HSV are updated accorded to the CDC 2021 guidelines, in Tables 102­4,
102­6, and 102­7 and related text.
Vulvovaginitis, or vulvovaginal inflammation, results from infectious and noninfectious processes that cause symptoms that include burning, irritation, itching, odor, and abnormal vaginal discharge. The factors associated with acute vaginitis are listed in Table 102­1. TABLE 102­1
Factors Associated With Acute Vulvovaginitis
Infections
Irritant or allergic contact
Local response to a vaginal foreign body
Lack of estrogen in perimenopausal and postmenopausal women (atrophic vaginitis)
Postradiation changes
The clinical diagnosis may be challenging because more than one disease can be present, signs and symptoms are nonspecific to a single cause, and polymicrobial infection is common. In approximately 30% of women with vaginal complaints, no etiology is determined even after comprehensive
1­3 testing.
Although infectious vaginitis rarely requires hospitalization, it can lead to serious sequelae. Both bacterial vaginosis (BV) and trichomoniasis are
,5 associated with premature rupture of membranes, preterm labor, and low infant birth weight. Trichomonas vaginitis increases the risk of human immunodeficiency virus (HIV) acquisition and transmission due to the loss of the protective effect found with normal vaginal lactobacilli and is also
,7 associated with pelvic inflammatory disease in patients who are known to be HIV positive.
PATHOPHYSIOLOGY
In females of childbearing age, estrogen helps develop a thick vaginal epithelium with a large number of superficial glycogen­containing cells that serves a protective function. Normal flora, such as lactobacilli and acidogenic corynebacteria, use glycogen to form lactic and acetic acids. The resulting acidic environment favors the normal flora, discouraging growth of pathogenic bacteria. Low estrogen levels in postmenopausal women result in atrophy due to loss of the protective glycogen­containing superficial cells and the altered pH environment.
Normal vaginal secretions vary in consistency from thin and watery to thick, white, and opaque. The volume may also vary from a scant to a copious amount. Secretions are odorless and produce no symptoms. Normal vaginal pH varies between .8 and .5. Alkaline secretions from the cervix before and during menstruation, as well as alkaline semen, reduce acidity and predispose to infection. Before menarche and after menopause, the vaginal pH vDaorwiens lboeatdweede 2n0  a5n­7d­ . 6:3 P Your IP is 136.142.159.127
Chapter 102: Vulvovaginitis, Ciara J. Barclay­Buchanan; Melissa A. Barton 
V©u2l0vo2v5a MgicnGalr ainwfl aHmillm. Aaltli oRnig ihs ttsh Re mesoesrtv ceodm. m Toenrm gsy noef cUosloeg * i cP driivsaocrdye Pr oinli cpyr e * p Nuobteicrtea l * gAirclsc easnsdi binilcitlyudes both infectious causes (e.g., bacterial, fungal, pinworm) and noninfectious causes (e.g., contact/irritant, lichen sclerosis, foreign body). Factors thought to contribute to vaginitis in prepubertal females include less protective covering of the vestibule by the labia minora, low estrogen concentration resulting in a thinner epithelium, exposure to chemical irritants (e.g., bubble bath), poor hygiene, front­to­back wiping, short distance between the vagina and anus, foreign bodies, chronic medical conditions (e.g., eczema, seborrhea), and sexual abuse. Infectious causes include respiratory and enteric bacterial organisms such as Haemophilus influenzae, Staphylococcus aureus, group A Streptococcus, S. pneumoniae, Escherichia coli, Shigella flexneri, Neisseria gonorrhoeae, and Chlamydia,
 as well as Candida and pinworms. Infectious causes may be more common in adolescents, especially those who are sexually active.
CLINICAL FEATURES AND DIAGNOSIS
The most common infectious causes of vaginitis in symptomatic premenopausal women are BV, vulvovaginal candidiasis, and
Trichomonas vaginitis. Candidiasis, contact vaginitis, and atrophic vaginitis may occur in virgins and postmenopausal women.
Obtain a detailed gynecologic history. History should include details of vaginal discharge, odor, irritation, itching, burning, bleeding, dysuria, and dyspareunia. Inquire about associated abdominal pain, new sexual partners, use of barrier protection during intercourse, relationship of symptoms to menses, recent use of antibiotics, hygiene practices, and use of over­the­counter and homeopathic treatments (e.g., douching, boric acid, intravaginal yogurt and probiotics, apple cider vinegar).
Perform a pelvic examination. Note the presence of vulvar edema or erythema, vaginal discharge, cervical inflammation, abdominal tenderness, and cervical motion tenderness. External vulvar inflammation and minimal discharge suggest the possibility of mechanical, chemical, allergic, or other noninfectious causes of vulvovaginitis. During speculum examination, obtain a swab of the discharge. All sexually active women should be tested for gonorrhea and chlamydial infection. If a patient refuses pelvic examination or it is not feasible, the patient may submit a self­swab of vaginal
8­11 secretions and in some cases a urine sample, as self­administered vaginal swabs are accurate screening tests for sexually transmitted infections.
The Centers for Disease Control and Prevention also recommends HIV and syphilis testing for women engaged in high­risk sexual behavior (i.e., new or multiple sexual partners, unprotected intercourse). Finally, women of childbearing age should have a pregnancy test because pregnancy impacts treatment.
Microscopic evaluation of fresh vaginal secretions using both normal saline solution and 10% potassium hydroxide (KOH) slide preparations, the KOH
 whiff test, and pH testing may help establish a specific diagnosis (Tables 102­2and 102­3).
TABLE 102­2
Diagnosis of Vaginitis Based on Vaginal Secretions
Test Finding Diagnosis pH .0–4.5 Normal
.0–4.5 Candidiasis
>4.5 Bacterial vaginosis
>4.5 Trichomoniasis
Microscopy of specimen prepared with normal saline solution Clue cells Bacterial vaginosis
Motile trichomonads Trichomoniasis
Pseudohyphae and/or buds Candidiasis
Whiff test of swab specimen prepared with potassium hydroxide Fishy odor Bacterial vaginosis
Microscopy of specimen prepared with potassium hydroxide Pseudohyphae and/or buds Candidiasis
TABLE 102­3
Vaginitis Signs and Symptoms
Causative Organism Sign or Symptom
Candida Thick, curdy discharge
Itching
Gardnerella or other bacteria Fishy odor
Whitish­gray, thin discharge
Trichomonas Frothy, odorous discharge
Vaginal erythema or edema
Microscopic examination is time consuming and tedious. Results depend on operator skill, and although hospitals have laboratories, not all EDs have microscopes and appropriate reagents. Secretions from the mid­sidewall of the vagina are mixed with one to two drops of .9% normal saline in a test tube. A slide with a coverslip is prepared for microscopic evaluation. Microscopy should be performed immediately following sample collection as trichomonads lose motility quickly. Additionally, a drop of 10% KOH is added to the test tube and assessed for a fishy (amine) smell. KOH can also aid in the visualization of yeast.
To test the pH, obtain a sample from the mid­portion of the vaginal sidewall to avoid false elevations in pH caused by mucus. Sampling from the posterior fornix may yield inaccurate results because cervical mucus, blood, semen, douche products, and vaginal medications can elevate the pH. Apply a small amount of the secretions directly onto pH paper to determine the pH.
BACTERIAL VAGINOSIS
BV is the most common cause of vaginitis in acutely symptomatic women. However, up to 50% of women who meet criteria for this diagnosis are asymptomatic.
BV is usually a polymicrobial infection that occurs when the normal hydrogen peroxide–producing lactobacilli are replaced by other species, including
Gardnerella vaginalis, Ureaplasma, Mycoplasma, Mobiluncus, Prevotella, and various other anaerobes. However, research exists suggesting that BV is
 not a true infection, but rather a bacterial imbalance. Risk factors include multiple sexual partners (female or male), intercourse with an uncircumcised male partner, vaginal intercourse immediately after receptive anal intercourse, lack of condom use, douching, and absence of
,15 peroxide­producing lactobacilli in the vaginal flora. Women who have never been sexually active are less commonly affected. BV is not caused by the transmission of a single sexually transmitted pathogen; however, it is generally agreed that sexual activity plays a role in transmission and may
 promote infection.
BV has been associated with several adverse health outcomes, including increased risk of coinfection with sexually transmitted infections such as HIV,
 herpes simplex virus (HSV) type , Chlamydia trachomatis, and N. gonorrhoeae by decreasing local secretory leukocyte protease inhibitor levels. BV is also linked to complications related to pregnancy and gynecologic surgical procedures, such as spontaneous abortion, premature rupture of membranes, amniotic fluid infection, chorioamnionitis, preterm delivery, postpartum endometritis, pelvic inflammatory disease, postoperative wound
 infection, and infection after vaginal and abdominal hysterectomy.
DIAGNOSIS
The most common clinical presentation is malodorous, vaginal discharge. Classically, it is described as a thin, whitish­gray discharge associated with increased volume and a fishy smell. The absence of discharge or the presence of only a mild discharge makes the diagnosis less likely. Introital and vaginal irritation are uncommon.
The diagnosis is based on history, pelvic examination, microscopic evaluation of vaginal secretions, and point­of­care testing.
The presence of three of the following four criteria supports the diagnosis and correlates with a positive Gram stain (the gold standard for diagnosing

BV) :
. A thin, homogeneous vaginal discharge
. More than 20% clue cells on a wet mount (Figure 102­1)
. Positive results on test for amine release or whiff test
. A vaginal pH level >4.5
FIGURE 102­1. Bacterial vaginosis. Saline wet mount with clue cells (arrow). [Reproduced with permission from DeCherney AH, Nathan L, Laufer N, Roman AS (eds):
Current Diagnosis & Treatment: Obstetrics & Gynecology, 11th ed. New York, NY: McGraw­Hill, Inc.; 2013. Fig. 39­9.]
The diagnostic criterion with the highest sensitivity is vaginal pH, whereas that with the highest specificity is a positive amine odor. If vaginal pH is >4.5
 and there is an amine odor, then the diagnosis of BV can be made with confidence. Commercially available DNA probe–based and vaginal fluid
 sialidase activity–based tests perform similar to Gram stain. Diagnostic cards that detect an elevated pH and trimethylamine are available, but have a low sensitivity and specificity and thus are not recommended. Cultures are not beneficial because Gardnerella is part of the normal vaginal flora.
TREATMENT
Treatment is recommended for all symptomatic women and can be considered in asymptomatic women. Beyond symptom control, the benefit of treatment includes reducing the risk of acquiring C. trachomatis, N. gonorrhoeae, T. vaginalis, HIV, and HSV­2. Recommended treatment regimens are listed in Table 102­4. Counsel patients receiving nitroimidazoles against consuming alcoholic beverages during the treatment period and for  hours (for metronidazole) and  hours (for tinidazole) after the last dose to avoid a disulfiram­like reaction.
Advise all patients to refrain from intercourse or to use condoms during treatment. Clindamycin cream and ovules may weaken diaphragms and condoms. Advise patients to use alternative contraceptives or abstain during and for  days after treatment.
TABLE 102­4
Treatment Regimens for Bacterial Vaginosis
Agent Dosage
Recommended Regimens
Metronidazole 500 milligrams PO BID for  d
Clindamycin cream 2% One full applicator intravaginally (5 g) QHS for  d (do not use <  h after condom or diaphragm application; weakens latex or rubber)
Metronidazole gel One full applicator intravaginally (5 g) QHS for  d
.75%
Alternative Regimens
Clindamycin 300 milligrams PO BID for  d
Clindamycin ovules 100 milligrams intravaginally QHS for  d
Tinidazole  grams PO daily for  d OR  gram PO daily for  d
Secnidazole  gm PO x  (expensive)
Abbreviations: BID = twice a day; QHS = every night at bedtime.
Symptomatic pregnant women should be treated with the same medications as nonpregnant women (Table 102­4). Asymptomatic lowrisk pregnant women should not be screened for BV. Although BV is correlated with poor pregnancy outcomes, studies have not demonstrated that
,21­23 treatment prevents adverse outcomes.
Overall cure rates  weeks after treatment do not differ significantly between a 7­day regimen of oral metronidazole, metronidazole vaginal gel, or clindamycin vaginal cream. Metronidazole vaginal gel has fewer side effects (e.g., GI disturbance and unpleasant taste), but should not be used in women who are allergic to the oral preparation.
Recurrence is common, and some pathogens are developing resistance to standard therapies. Consider suppressive therapy in women with multiple recurrences. The use of Lactobacillus intravaginal suppositories and probiotics to restore the normal vaginal flora is an alternative, especially for recurrent BV. Treatment of male sexual partners has not been shown to prevent recurrence.
CANDIDA VAGINITIS

Candida species are the second most common cause of infectious vaginitis. Candida is isolated in up to 20% of asymptomatic, healthy women of childbearing age, some of whom are celibate. Incidence decreases after menopause unless using estrogen replacement, which further emphasizes the hormonal dependence of the infection. Women can remain entirely asymptomatic despite being heavily colonized with Candida species. C. albicans strains account for 85% to 92% of Candida organisms isolated from the vagina. Candida glabrata and Candida tropicalis are the most common non­albicans strains and are often more resistant to conventional therapy.
Candidal vaginitis can be classified as an uncomplicated or complicated infection. Uncomplicated infections are sporadic with mild to moderate symptoms, are due to C. albicans, and occur in the nonpregnant, immunocompetent host. Complicated infections are recurrent (four or more infections per year), produce severe symptoms or findings, result from suspected or proven non­albicans Candida species, or occur in an abnormal
,25 host (e.g., women who have uncontrolled diabetes, debilitation, or immunosuppression, or are pregnant).
Candidal organisms gain access to the vaginal lumen predominantly from the adjacent perianal area. The growth of Candida is limited by the normal vaginal flora, and symptoms of vaginitis usually occur only when the normal balance is upset. Increased Candida colonization resulting in subsequent symptomatic infection may be caused by conditions that (1) inhibit the growth of normal vaginal flora, particularly Lactobacillus species (e.g., systemic antibiotics); (2) diminish the glycogen stores in vaginal epithelial cells (e.g., diabetes mellitus, pregnancy, oral contraceptive use, hormonal replacement therapy); or (3) increase the pH of vaginal secretions (e.g., menstrual blood or semen).
Vaginal candidiasis is not considered a sexually transmitted infection, although it may be transmitted by sexual intercourse. The wearing of tightfitting, synthetic undergarments may also contribute because of increased temperature. Although all of these factors are thought to be associated with
 symptomatic disease, no causation has been proven.
DIAGNOSIS
Clinical symptoms include discharge, vaginal pruritus, external dysuria, and dyspareunia. Vaginal pruritus is the most common and specific symptom. The discharge varies from none to watery to homogeneously thick and “cottage cheese–like.”
Symptoms vary in severity. An exacerbation frequently presents in the week prior to menses or following coitus, perhaps because each causes the pH to become more alkaline. Odor is unusual and, if present, favors a diagnosis of BV rather than vulvovaginal candidiasis.
Pelvic examination often reveals vulvar erythema and edema, vaginal erythema, and a whitish discharge that adheres to the vaginal walls.
The diagnosis is confirmed with a normal vaginal pH (4.0 to .5) and visualization of budding yeast and pseudohyphae on slide preparation of vaginal secretions (Figure 102­2). The sensitivity of microscopic examination using a sample prepared with normal saline is only 40% to 60%. Adding two drops of 10% KOH to the vaginal secretions dissolves the epithelial cells while leaving yeast buds and pseudohyphae intact and increases the sensitivity to 80% and specificity to nearly 100%.
FIGURE 102­2. Hyphae of Candida albicans, potassium hydroxide wet mount. [Reproduced with permission from Knoop et al: The Atlas of Emergency Medicine, 3rd ed. © 2010 McGraw­Hill, Inc. Fig. 25–16. Photo contributor: H. Hunter Handsfield: Atlas of Sexually Transmitted Diseases. New York, NY: McGraw­Hill,
Inc., 1992.]
TREATMENT
Recommended treatment regimens are listed in Table 102­5. Topically applied azole drugs are more effective than nystatin, with relief of symptoms in 80% to 90% of patients who complete treatment. Consider patient preference because creams, lotions, sprays, vaginal tablets, suppositories, and
 coated tampons are all equally efficacious.
TABLE 102­5
Treatment Regimens for Uncomplicated Vulvovaginal Candidiasis* Agent Formulation Dosage
Butoconazole† 2% cream  applicator intravaginally QHS ×  d
Clotrimazole 1% cream  applicator intravaginally QHS ×  d
2% cream  applicator intravaginally QHS ×  d
Miconazole 2% cream  applicator intravaginally QHS ×  d
4% cream  applicator intravaginally QHS ×  d
Nystatin 100,000­unit vaginal tablet  vaginal tablet QHS ×  d
Terconazole .4% cream  applicator intravaginally QHS ×  d
.8% cream  applicator intravaginally QHS ×  d
80­milligram suppository  suppository intravaginally QHS ×  d
Tioconazole .5% ointment  applicator intravaginally QHS ×  dose
Fluconazole† 150­milligram oral tablet  tablet PO ×  dose
Abbreviation: QHS = every night at bedtime.
*Not all possible regimens listed.
†Not recommended in pregnancy.
Pregnant women should be treated with topical azoles for  days. Oral fluconazole is a category C medication and thus should be avoided in pregnancy.
The azole drugs are all available over the counter in treatment regimens of , , or  days. Uncomplicated disease responds to all azoles, including
 single­dose therapy. Other than initial burning and irritation, side effects of topical agents are unusual. Single­dose treatment with oral fluconazole is as effective as topical therapy in the treatment of uncomplicated disease. Patient preference should be considered,
 because oral therapy is often more convenient. Oral treatment occasionally causes GI symptoms, headache, and rash. Oral azoles interact with a variety of other medications. Sexual partners should not be treated unless they are also symptomatic.
,29
Self­medication is occasionally advised in women with recurrence of previously diagnosed disease, although accuracy of self­diagnosis is poor.
Women who fail to respond to over­the­counter therapy or have recurrence within  months should be evaluated by a physician.
Complicated Vulvovaginal Candidiasis
Vaginal and microscopic examinations should be performed if symptoms persist or recur within  months, and precipitating factors, such as high blood glucose levels, should be controlled. However, most women with recurrences do not have obvious precipitating causes. Vaginal cultures should be obtained to confirm a clinical diagnosis and identify any unusual species, such as C. glabrata, as azoles are ineffective in treating vaginitis caused by
C. glabrata.
The treatment of severe or recurrent vulvovaginal candidiasis requires a longer duration of therapy. Consider treating with a topical azole for 
,28,29 to  days. More resistant cases may require fluconazole, 150 milligrams orally on days , , and  for a total of three doses. Very severe cases
 may require long­term suppression and gynecologic referral.
TRICHOMONAS VAGINITIS
Trichomoniasis, a parasitic infection with the single­celled protozoan T. vaginalis, a flagellated organism, is a sexually transmitted infection.
Both men and women can be infected.
Infection can produce local inflammation when the organism attaches to the vaginal mucosa. Clinically symptomatic women present with vaginal discharge, pruritus, and irritation. Classically, the discharge is frothy, greenish in color, and malodorous. On speculum examination, the cervix may be inflamed and small punctate hemorrhages may be seen (“strawberry cervix”). Symptoms generally develop within  to  days of exposure; however,
 untreated infections can last for months to years and produce symptoms at any time. Many infections are asymptomatic.
DIAGNOSIS
Clinical diagnosis of Trichomonas vaginitis traditionally relies on microscopic examination of the vaginal secretions and visualization of motile trichomonads (Figure 102­3). Culture of vaginal secretions is 95% sensitive and has long been considered the gold standard in diagnosis. However, results may not be available for  to  days. Several newer testing options, such as nucleic acid amplification tests, have been approved by the Food and Drug Administration for the detection of T. vaginalis in endocervical, vaginal, and urine specimens. These newer tests provide rapid results and are
,31,32 highly sensitive and specific.
FIGURE 102­3. Trichomonad. [Reprinted with permission of Piotr Rotkiewicz.]
TREATMENT
Treatment regimens for acute Trichomonas vaginitis are listed in Table 102­6. The nitroimidazoles, metronidazole, and tinidazole are the only medications effective in treating trichomoniasis. Metronidazole gel is not recommended. Single­dose treatment is preferable because of lower cost, fewer side effects, and greater patient adherence to the regimen. Sexual partners should be treated simultaneously. Counsel patients to abstain from sexual intercourse until (1) therapy has been completed; (2) both the patient and partner(s) have been treated; and (3) all are asymptomatic. Patients receiving nitroimidazoles should be advised to avoid consuming alcoholic beverages during the treatment period and for  hours (metronidazole) and  hours (tinidazole) after the last dose to avoid a disulfiram­like reaction.
TABLE 102­6
Treatment Regimens for Trichomoniasis for Women
Agent Dosage
Recommended regimens
Metronidazole 500 milligrams PO bid x  days
Tinidazole  grams PO in a single dose
TRICHOMONIASIS COMPLICATIONS
The spread of T. vaginalis infection is common because many of those infected are asymptomatic. Reinfection is common and can be difficult to differentiate from treatment failure. If treatment failure is suspected, consider treatment with tinidazole.
T. vaginalis infection is associated with several adverse health outcomes, including preterm birth, delivery of low­birth­weight infants, pelvic inflammatory disease, and increased transmission of several other infections, including HIV, HSV­2, and human papillomavirus infection. Not only does
,34
Trichomonas infection increase the likelihood of HIV acquisition, but it also promotes transmission and viral shedding.
SPECIAL POPULATIONS
HIV­positive individuals are more likely to become infected with T. vaginalis and have higher complication rates. HIV­positive patients should be
 treated with the 7­day metronidazole regimen.
Due to the potential adverse pregnancy outcomes, pregnant women should receive treatment with oral metronidazole. Women can be safely treated with single­dose metronidazole therapy at any stage of pregnancy. Breastfeeding mothers should consider withholding nursing during treatment with metronidazole and for  to  hours after the last dose. Tinidazole safety in pregnancy is not well studied and should be avoided. If treated with tinidazole, patients should withhold breastfeeding for  days after the last dose.
HERPES SIMPLEX VIRUS INFECTION
Genital herpes is a lifelong viral infection caused by HSV­1 or HSV­2. HSV­2 more commonly causes genital lesions and is associated with higher recurrence rates. The majority of infected individuals are asymptomatic and unknowingly expose their sexual partners. Prevalence increases with age,
 and women are more commonly infected. Genital herpes may present as either a primary or recurrent infection. Classically, the lesions are found on the perineum, labia, urethral meatus, and introitus and are characterized by groups of painful, erythematous vesicles that quickly ulcerate (Figure
102­4). Primary infections are more severe and often associated with systemic symptoms (e.g., headache, fever, malaise, reginal lymphadenopathy, myalgias). Dysuria is common, and HSV can mimic symptoms of a urinary tract infection. Recurrent HSV infections result from reactivation of the dormant virus from the dorsal root ganglion following a stressor (e.g., acute illness, immunosuppression, psychological stress). Recurrent infections tend to be less severe but are often preceded by a prodromal period of itching, burning, or tingling before the lesions appear. Over time, recurrences tend to become less frequent.
FIGURE 102­4. Herpes lesions. [Used with permission from Dr. William Griffith.]
HSV­2–seropositive individuals are at increased risk of acquiring HIV infection. Extragenital complications include meningoencephalitis, pneumonitis, hepatitis, and disseminated disease. Neonatal HSV infection can result from spread of the infection from an HSV­positive pregnant mother to her child during delivery and is associated with significant morbidity and mortality.
DIAGNOSIS AND TREATMENT
When active lesions are present, polymerase chain reaction swabs are both sensitive and specific; viral culture is less sensitive. Type­specific serologic testing is available as both laboratory and point­of­care tests. A positive HSV­2 test implies an anogenital infection, whereas a positive HSV­1 test is difficult to interpret. Routine screening in the general population is not recommended.
Although oral antiviral therapy does not eradicate the virus, it can help provide symptom relief and shorten the outbreak. Topical antivirals are not effective. Patients should be counseled regarding the possibility of future outbreaks, safe sex practices to reduce the risk of sexual transmission, and consequences of perinatal transmission. Treatment regimens for primary HSV infections, recurrent HSV infections, and daily suppressive therapy are shown in Table 102­7. If the patient remains symptomatic after  days of therapy, then treatment should be extended. Daily suppressive therapy may reduce viral shedding and decrease, but not eliminate, the likelihood of transmission to sexual partners. Patients with severe disease or complications may require admission and treatment with intravenous acyclovir.
TABLE 102­7
Treatment Regimens for Genital HSV Infections
Antiviral Agent Choices Dose
Primary Outbreak (treat even mild 1st case, otherwise recurrences can be more severe; for episodes during pregnancy consult specialists)
Acyclovir 400 milligrams PO three times a day × 7–10 d or
200 milligrams PO five times daily × 7–10 d (not recommended due to 5x/day dosing)
Valacyclovir  gram PO two times daily × 7–10 d
Famciclovir 250 milligrams PO three times daily × 7–10 d
Episodic Therapy for Recurrent Outbreaks
Antiviral Agent Choices Dose
Acyclovir 400 milligrams PO three times a day ×  d or
800 milligrams PO three times a day ×  d
Valacyclovir  gram PO once a day for  days
Famciclovir  gram PO two times a day ×  d
Suppressive Therapy for Recurrent Outbreaks
Antiviral Agent Choices Dose
Acyclovir 400 milligrams PO twice a day
Valacyclovir 500­1000 milligrams PO once a day (500 may not be as effective as 1000)
Famciclovir 250 milligrams PO twice a day
Abbreviations: BID = twice a day; QD = once a day; TID = three times a day.
Sexual partners should be advised to seek evaluation, and if asymptomatic, they may benefit from type­specific testing. If a sexual partner’s HSV status is unknown or discordant, sexual contact should be avoided during outbreaks with strict condom use between outbreaks.
Immunocompromised patients, such as those with HIV infection, may have more severe symptoms or prolonged outbreaks. Additionally, HSV shedding is increased in HIV­positive patients. Patients with HIV often require higher doses and longer durations of therapy in order to achieve symptomatic relief.
CONTACT VULVOVAGINITIS
Contact dermatitis results from the exposure of the vulvar epithelium and vaginal mucosa to a primary chemical irritant or allergen. Irritant dermatitis
 is more common than allergic dermatitis. Common irritants or allergens include chemically scented douches, soaps, bubble baths, and deodorants; perfumes, dyes, and scents in toilet paper, tampons, pads, and feminine hygiene products; topical vaginal antibiotics; laundry detergents, dryer sheets, and fabric softeners; and tight slacks, pantyhose, and synthetic underwear. Benzocaine, used by women to control vulvar discomfort, can also cause a particularly severe contact dermatitis.
Diagnosis may be difficult due to variation in symptom severity and preexisting conditions. Clinically, patients report localized swelling, itching, or a burning sensation. Physical findings range from local erythema and edema to excoriation, ulceration, and secondary infection. Local vesiculation and ulceration are more common with primary irritants used in strong concentrations, but herpes infection must also be considered. Vaginal pH changes may promote colonization and infection with C. albicans that can obscure the primary cause.
Diagnosis of contact vulvovaginitis is made by ruling out an infectious cause and identifying the offending agent. Most cases of mild vulvovaginal contact dermatitis resolve spontaneously when the causative agent is withdrawn. Cool sitz baths and application of wet compresses of dilute boric acid or Burow’s solution may afford relief for patients with severe painful reactions. A few days of therapy with topical corticosteroids, such as hydrocortisone acetate (0.5% to .5%), fluocinolone acetonide (0.01% to .2%), or triamcinolone acetonide (0.025%), applied two or three times daily, provide symptomatic relief and promote healing. If a true allergic reaction is present, then oral antihistamines may be helpful. Superinfection with C.
albicans should be treated as previously described in the section on Candida vaginitis.
ATROPHIC VAGINITIS

Vaginal atrophy, present in 60% of women  years after menopause, can result in atrophic vaginitis. Decreased ovarian steroid production in menopausal women leads to profound changes in the vulva, vagina, cervix, urethra, and bladder. The vagina loses its normal rugae with the mucosa becoming attenuated, pale, and almost transparent as a result of decreased vascularity. The cellular glycogen content decreases, resulting in atrophy of the epithelium and loss of elasticity. The vaginal pH ranges from .5 to .0. The upper one third of the vagina constricts, shortening the length of the vagina. The mucosa is only three or four cells thick and is less resistant to minor trauma and infection. The cervix atrophies and retracts and may become flush with the apex of the vault.
Symptoms include vaginal dryness, soreness, itching, dyspareunia, and occasional spotting or discharge. Discharge is thin, scant, and yellowish or pink. The vaginal epithelium appears thin, inflamed, and even ulcerated.
A clinical vaginal infection with copious purulent discharge may develop due to increased vaginal pH, which permits growth of nonacidophilic coliform organisms and the disappearance of Lactobacillus species. Candida and Trichomonas infections are rare in the postmenopausal woman unless estrogenic replacement therapy is used.
Wet preparations demonstrate erythrocytes, increased polymorphonuclear neutrophils, and small, round epithelial cells, which are immature squamous cells that have not been exposed to sufficient estrogen.
Treatment of atrophic vaginitis consists primarily of topical vaginal estrogen. Creams, pessaries, tablets, and the estradiol vaginal ring are all effective
 in treating the symptoms. Side effects of treatment may include uterine bleeding, breast pain, perineal pain, and endometrial hyperstimulation.
Estrogen should not be prescribed to patients with a history of cancer of any of the reproductive organs. Atrophic vaginitis is uncommon in patients taking systemic estrogen replacement therapy.
Women should be referred to their primary care provider for treatment and follow­up to monitor therapy, because all formulations of estrogen, even
 at low dosages, show systemic absorption and have potentially harmful side effects. In addition, any patient with postmenopausal bleeding, either by history or physical examination, should be referred to a gynecologist to rule out carcinoma.
BARTHOLIN GLAND CYST AND ABSCESS
Bartholin glands are located in the labia minora. The ducts of the glands drain into the posterior vestibule at the  o’clock and  o’clock positions.
Normally the glands are pea sized. The glands begin to function at puberty to provide moisture to the vestibule and involute as women age.
Obstruction of the duct may result in a cyst or abscess. A cyst does not need to be present before an abscess can develop. Abscesses may become quite
 large and cause extreme pain. E. coli is the most common bacterial isolate, but many abscesses are polymicrobial. Less common organisms include
N. gonorrhoeae and C. trachomatis.
DIAGNOSIS AND TREATMENT
Bartholin gland abscess is characterized as a mass in the posterior introitus near the  o’clock or  o’clock positions that has developed over several days. If preceded by a cyst, the abscess may develop over a longer period of time. Pain, induration, and fluctuance are usually present. Systemic symptoms (e.g., fever and chills) are rarely present.
Incision and drainage is usually necessary but should not be performed until the abscess is a well­defined, walled­off structure. An ultrasound of the area can confirm the presence of a discrete fluid collection. If the abscess is not clearly defined, prescribe broad­spectrum antibiotics and analgesics and advise warm sitz baths and short­term follow­up. Most patients present with an exquisitely tender, hyperemic, fluctuant mass that needs drainage by the emergency physician. Care should be taken to distinguish a Bartholin’s abscess from an abscess of the labia majora, which requires gynecologic consultation.
Consider providing parenteral analgesia and even conscious sedation or low­dose ketamine in order to facilitate incision and drainage. To drain the abscess, first provide analgesia with a local injection of  to  mL of 1% lidocaine. Make a stab incision with a #11 scalpel on the mucosal surface of the vestibule, just lateral to the hymenal ring in the region of the Bartholin gland, where the abscess cavity is closest to the mucosal surface and has the greatest fluctuance. Extend the stab incision only for a few millimeters; an incision that is too large will result in displacement of the Word catheter. A
Word catheter (Figure 102­5) is the size of a #10 Foley catheter with a 1­in. (2.5­cm) stem and an inflatable balloon. Once fully drained, insert a Word catheter into the incision site and inflate the balloon with  to  mL of water. Tuck the end of the catheter into the vagina. The catheter should remain in
  place for  to  weeks to avoid recurrence. Case reports describe using plastic tubing (Figure 102­6) when a Word catheter is not available. There
 are many different treatment techniques, none of which have been found to be superior. Prescribe analgesics and broad­spectrum antibiotics and give instructions for follow­up care. If N. gonorrhoeae and C. trachomatis infection are possible, direct antibiotic coverage accordingly (Table 102­2).
Patients with recurrent abscess may require definitive surgical care and should be provided with specialty referral.
FIGURE 102­5. Word catheter. [Reproduced with permission from Reichman EF: Emergency Medicine Procedures, 2nd ed. New York, NY: McGraw­Hill, Inc., 2013. Figure 138­2, p. 932.]
FIGURE 102­6. A. Obtain  cm of narrow tubing, and insert silk suture through tubing. B. After drainage, make a second stab incision into the abscess cavity and insert the threaded tubing. C. Use a hemostat to grasp the threaded tubing through both stab sites. D. Suture the threads so they are secure. [Reproduced with permission from Reichman EF: Emergency Medicine Procedures, 2nd ed. New York, NY: McGraw­Hill, Inc., 2013. Figure 138–5, Parts A, E, F, G, p.
934.]
VAGINAL FOREIGN BODIES
Consider a vaginal foreign body in patients with chronic vaginal discharge. Potential objects include tampons and toilet tissue, devices used for sexual stimulation, packets of illegal drugs, and various other objects.
Premenarchal children presenting with vaginal discharge, especially if bloody or brown, should be evaluated for a vaginal foreign body. The discharge
 associated with a foreign body occurs daily and is often malodorous. Potential foreign bodies include small pieces of toilet paper or cloth and small toys or objects.
Vaginal irrigation with .9% normal saline can be attempted to visualize and remove a foreign body in cooperative children >7 years of age.
Vaginoscopy under anesthesia in the operating room may be necessary for younger children. The use of imaging modalities is limited by the composition of the foreign body. Radiolucent foreign bodies are not seen on plain radiographs and may not be detected by pelvic ultrasound. MRI may aid in the localization of nonmetallic objects but is not always available and is not necessarily conclusive. Treatment is removal.
PINWORMS
Patients with pinworms (Enterobius vermicularis) complain of anal or vaginal pruritus, which is more intense at night (when the gravid female pinworms pass out from the intestinal tract to lay eggs on the perineal skin). The worms may migrate from the anus to the vagina in children.
The diagnosis is made by visualization of 1­cm­long, thin, white worms exiting the anus. Alternately, a sample can be obtained on cellophane tape and used for identification of ova, which are large and double­walled in appearance, on microscopy.
Treat the child and all family members and household contacts with an antiparasitic agent (Table 102­8). Treatments are repeated because
 mature worms are more vulnerable to treatment than young worms.
TABLE 102­8
Treatment Regimens for Pinworms
Agent and Dosage Comments
Mebendazole 100 milligrams PO ×  Teratogenic potential, only if benefits outweigh risk in pregnancy
Repeated in  wk
Albendazole 400 milligrams PO ×  Contraindicated in pregnancy and  month prior to conception
Repeated in  wk
Pyrantel pamoate  milligrams/kg PO ×  (maximum single dose =  gram) Available without prescription, no human data on safety
Repeat dose every  wk ×  (total  doses)


