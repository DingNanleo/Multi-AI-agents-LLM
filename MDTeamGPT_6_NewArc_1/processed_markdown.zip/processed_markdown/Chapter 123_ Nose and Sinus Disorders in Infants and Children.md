## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 123: Nose and Sinus Disorders in Infants and Children
Joanna S. Cohen; Dewesh Agrawal
ACUTE BACTERIAL SINUSITIS

Acute bacterial sinusitis is a bacterial infection of one or more of the paranasal sinuses lasting <30 days. The most common predisposing factor is a viral upper respiratory infection (URI). The incidence of viral URIs in children age  to  months is approximately six episodes per patient­year, with approximately 8% of those becoming complicated by acute bacterial sinusitis. Bacterial sinusitis in children is most common in the  to  months age
,3 group, probably because these children are most likely to be in day care, predisposing them to URIs. The cost of acute pediatric bacterial sinusitis in
 the United States is approximately $20,000 per hospitalized patient, and a large geographic variation in healthcare utilization exists. Total healthcare
 costs in the United States incurred from treating sinusitis in children <12 years of age had been estimated at close to $2 billion a year.
PATHOPHYSIOLOGY
The sinuses are air cavities lined with ciliated columnar epithelium that helps mucus clearance by pushing mucus and debris out of the sinus ostia into the nasal cavity. Blockage of the ostia by mucus and inflammation predisposes to bacterial sinusitis. The ethmoid and maxillary sinuses are present at birth and are most commonly involved in sinusitis in children. The sphenoid sinuses form at  to  years of age. The frontal sinuses do not appear until
 to  years of age and remain incompletely pneumatized until late adolescence. The most common predisposing factors for acute bacterial sinusitis
 are diffuse mucositis secondary to viral rhinosinusitis in about 80% and allergic inflammation in about 20%. Less common predisposing factors
 include nonallergic rhinitis, cystic fibrosis, dysfunctional or insufficient immunoglobulins, ciliary dyskinesia, and anatomic abnormalities.
The most common pathogen of acute bacterial sinusitis is Streptococcus pneumoniae, recovered in 30% of children with acute sinusitis. Nontypeable
,8
Haemophilus influenzae and Moraxella catarrhalis are each recovered in 20%.
CLINICAL FEATURES
Children with acute bacterial sinusitis typically present with high fever and purulent nasal discharge. Headache, particularly behind the eye, is variable.

Complaints of facial pain in children are rare. Parents may report halitosis. The physical examination findings of acute bacterial sinusitis are often similar to those of uncomplicated viral sinusitis, with swollen and erythematous turbinates and mucopurulent discharge. However, reproducible unilateral tenderness to percussion or direct pressure of the frontal or maxillary sinus may indicate acute bacterial infection, and periorbital edema
  might indicate ethmoid sinusitis. Transillumination of the maxillary sinuses is unreliable in children <10 years of age.
DIAGNOSIS
Although the gold standard for diagnosis of acute bacterial sinusitis is the recovery of ≥10  colony­forming units/mL of bacteria from the paranasal
 sinuses, sinus aspiration is painful and impractical in the ED. Therefore, diagnosis is often based on clinical criteria that help to distinguish acute
,10 bacterial sinusitis from an uncomplicated viral URI in an ill­appearing child (Table 123­1).
TABLE 123­1
Clinical Features of Acute Bacterial Sinusitis10
Persistent symptoms lasting >10 d without improvement Nasal or postnasal discharge and/or
 Daytime cough
Chapter 123: Nose and Sinus Disorders in Infants and Children, Joanna S. Cohen; Dewesh Agrawal 
. Terms of Use * Privacy Policy * Notice * Accessibility
Worsening course Worse or new onset of nasal discharge, daytime cough, or fever after initial improvement
Severe onset Fever ≥39°C (102.2°F)
Purulent nasal discharge for ≥3 d
Imaging studies should not be obtained to differentiate acute bacterial sinusitis from viral URI because of the high incidence of sinus
 mucosal abnormalities in patients with simple upper respiratory symptoms or no clinical symptoms at all. In one study, mucosal sinus changes were
 evident in 97% of infants who had a URI in the  weeks preceding a cranial CT done for unrelated reasons. Plain films have limited utility because they require correct positioning that is technically difficult in young children, and there is only a 70% to 75% correlation of culture confirmation with
 abnormal­appearing sinus radiographs. A paranasal sinus CT with contrast or an MRI with contrast is, however, recommended for suspected orbital or CNS complications of bacterial sinusitis, including preseptal or postseptal cellulitis, subperiosteal abscess, cavernous sinus thrombosis,
,12 osteomyelitis of the frontal bone (Pott’s puffy tumor), subdural empyema, epidural or brain abscess, and meningitis.
TREATMENT
Patients with mild symptoms suggestive of a viral infection can be observed for  to  days, with no antibiotics prescribed. However, if symptoms persist or are severe (see Table 123­1), suspect acute bacterial sinusitis and prescribe antibiotics to speed recovery, prevent suppurative
 complications, and minimize asthma exacerbations in susceptible children.
Antibiotic treatment for acute sinusitis is outlined in Table 123­2 and Figure 123­1. TABLE 123­2
Antibiotic Treatment for Bacterial Sinusitis
Duration
Clinical Scenario Additional Factors Treatment of
Treatment
Mild symptoms or age >2 y Not in day care, no antibiotics in Amoxicillin 20–25 milligrams/kg PO twice daily 10–28 d past  weeks or
 d beyond
>10% resistant Streptococcus Amoxicillin  milligrams/kg PO twice daily resolution pneumoniae prevalence of symptoms
Moderate­severe symptoms or age Amoxicillin  milligrams/kg with clavulanate .2 milligrams/kg
<2 years or attending day care or PO twice daily (use Augmentin® ES formulation with 600 recent amoxicillin administration milligrams amoxicillin and .9 milligrams clavulanate per  mL)
Vomiting or unable to tolerate Ceftriaxone  milligrams/kg IV/IM once a day Substitute oral antibiotics PO agent when tolerable
Penicillin allergic Only consider cephalosporins Cefdinir  milligrams/kg PO twice daily 10–28 d with nonsevere or non–type I or or hypersensitivity penicillin Cefuroxime  milligrams/kg PO twice daily  d beyond allergy or resolution
Cefpodoxime  milligrams/kg PO twice daily of symptoms
FIGURE 123­1. Management of uncomplicated acute bacterial sinusitis in children. amox = amoxicillin; clav = clavulanate; ENT = ear, nose, and throat; PCN = penicillin;
PCP = primary care provider; tx = treat.

Decongestants, antihistamines, and nasal irrigation are not effective for children with acute bacterial sinusitis. Adjunctive therapy with intranasal steroids (e.g., fluticasone propionate, one to two sprays per nostril daily, or beclomethasone, one to two sprays per nostril twice a day) has modest
,14,15 benefits and may be considered.
Complications of acute bacterial sinusitis are rare but usually involve the orbit or CNS. If suspected, obtain a contrast­enhanced CT scan or an MRI if
 possible. Proptosis or impairment of extraocular muscle movement suggests orbital inflammation, usually from extension of an ethmoidal infection
(Figure 123­2). Frontal and sphenoidal inflammation can lead to intracranial extension, causing frontal lobe and subdural abscesses as well as meningitis and empyema. IV antibiotics are needed, and surgical management may be necessary. Consult an ophthalmologist and/or neurosurgeon
 promptly for complications. For further discussion of the management of periorbital and orbital sinusitis, see Chapter 122, “Eye Emergencies in
Infants and Children.”
FIGURE 123­2. Sinusitis. Adolescent with pansinusitis complicated by periorbital cellulitis. The patient was also found to have osteomyelitis of the frontal bone (Pott’s puffy tumor). [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, Inc., New
York.]
CHRONIC BACTERIAL SINUSITIS

Chronic rhinosinusitis is an inflammatory process involving the mucosa of the nose and sinuses that lasts >3 months. Factors associated with chronic sinusitis include older age, allergic rhinitis, recurrent viral URIs, immunodeficiency, ciliary dyskinesia, anatomic abnormalities, and fungal colonization
  of the sinuses. The most common organisms identified are α­hemolytic Streptococcus, H. influenzae, and S. pneumoniae. Chronic sinusitis has
 been linked to asthma, and treatment of chronic sinusitis reduces asthma symptoms.
In addition to the more common pathogens seen in acute bacterial sinusitis, chronic sinusitis may also be caused by Staphylococcus aureus,
 anaerobes, and, rarely in children, fungi, including Aspergillus, Fusarium, Bipolaris, Curvularia lunata, and Pseudallescheria boydii. Antibiotics for chronic sinusitis should cover the usual pathogens of acute sinusitis as well as aerobic and anaerobic β­lactamase–producing bacteria. Commonly used oral antimicrobial agents include amoxicillin­clavulanate (20 to  milligrams/kg PO twice daily), clindamycin (8 milligrams/kg PO three times
 daily), and the quinolones (moxifloxacin, 400 milligrams PO daily) for adolescents. Chronic bacterial sinusitis is treated with prolonged antibiotics,
 typically for at least  weeks.
For patients with chronic sinusitis who have failed antibiotic trials and nasal saline irrigation, otolaryngology referral is recommended for complete
 evaluation with nasal endoscopy and consideration of surgical options. Definitive therapies commonly involve adenoidectomy and rarely balloon catheter sinus dilation or endoscopic sinus surgery, in which the ostiomeatal area is opened, antrostomies are created, and ethmoid partitions are
,24  removed. Endoscopic sinus surgery has an estimated success rate of 83% in a combined pediatric and adult study. In the pediatric population, however, a less invasive approach known as a functional endoscopic sinus surgery, which is essentially a drainage procedure, has good efficacy,
 with 90% of patients showing marked reduction in symptoms.
SPECIAL POPULATIONS
Patients with recurrent acute rhinosinusitis, characterized by multiple episodes of sinusitis between which signs and symptoms resolve completely,
 may benefit from prolonged antibiotic prophylaxis with azithromycin. Children with recurrent or refractory sinusitis should be evaluated for immune deficiencies with quantitative immunoglobulin levels, immunoglobulin G subclasses, immunoglobulin A, and T­ and B­cell counts. The most commonly diagnosed immune deficiencies in patients presenting with recurrent or refractory sinusitis are selective immunoglobulin A deficiency, common
 variable immunodeficiency, and immunoglobulin G subclass deficiency. Children with cystic fibrosis have thick mucus that predisposes them to sinusitis. Cystic fibrosis is primarily diagnosed through sweat chloride testing. Suspect cystic fibrosis in a child who presents with nasal polyps or
 chronic sinusitis, particularly in conjunction with failure to thrive and chronic cough.
ALLERGIC RHINITIS
Allergic rhinitis is an immunoglobulin E–mediated chronic or recurrent inflammatory response of the nasal mucosa that is induced by an allergen and typically affects children >2 years old. The worldwide prevalence of symptoms of allergic rhinoconjunctivitis is .2% to .6% in children age  to 
 years old and .5% to .5% in adolescents age  to  years old. Approximately 80% of children with asthma have allergic rhinitis, and allergic
 rhinitis makes it more difficult to control asthma, making it an important topic for the emergency medicine physician caring for children.
PATHOPHYSIOLOGY
Seasonal allergic rhinitis (commonly known as hay fever) is usually caused by airborne allergens such as pollen, whereas perennial allergic rhinitis is usually caused by dust mites, animal dander, and mold. Allergic rhinitis is an immunoglobulin E–mediated inflammatory response in the nasal mucosa that occurs after sensitization with a specific allergen. Immunoglobulin E binding triggers mast cell degranulation and subsequent histamine release.
The binding of histamine to the histamine­1 receptor on nasal neurons and nasal vasculature is the ultimate mechanism responsible for the nasal itch, sneeze, rhinorrhea, and nasal obstruction of allergic rhinitis.
CLINICAL FEATURES
Allergic rhinitis presents with clear rhinorrhea, nasal pruritus, and sneezing. Ocular symptoms, such as conjunctival hyperemia and pruritus, may
 coexist. Symptoms can lead to sleep disturbance, limitations in activity, and poor school performance.
DIAGNOSIS
Patients with allergic rhinitis report symptoms of paroxysmal sneezing, nasal pruritus, rhinorrhea, oropharyngeal pruritus, hyperemia, and ocular pruritus. On physical examination, there may be hypertrophy and edema of the nasal turbinates with associated pale, bluish hue or pallor along with clear secretion from the nares. While it can be difficult to differentiate allergic rhinitis from nonallergic rhinitis, certain physical features may be helpful. For instance, the presence of a horizontal nasal crease (“allergic salute”) is more likely to be associated with allergic rhinitis, while Dennie­
Morgan folds (a fold or line in the skin below the lower eyelid caused by edema in atopic dermatitis) are more likely to be associated with nonallergic
 rhinitis. Concomitant wheezing suggests an association with asthma. A patient with severe symptoms who does not respond to treatment may warrant a referral to an allergist for skin testing to detect immediate hypersensitivity reactions to allergens. Total immunoglobulin E levels are neither
 sensitive nor specific for atopic disease.
TREATMENT
Treatment involves recommending environmental controls such as avoidance of allergens and irritants, including pollutants and cigarette smoke.

Nasal saline irrigation with a syringe or spray reduces the use of antibiotics and other medications.

Intranasal steroids, such as fluticasone furoate nasal spray, are effective for treatment of allergic rhinitis. Intranasal corticosteroids reduce inflammation of the nasal mucosa. Daily morning dosing minimizes the impact on the hypothalamic­pituitary­adrenal axis. Oral antihistamines are also commonly used to treat allergic rhinitis, but there is a lack of evidence for the benefit of oral antihistamine therapy in addition to topical nasal steroids
 for children with allergic rhinitis. Second­generation antihistamines, such as loratadine (5 milligrams daily for age  to  years;  milligrams daily for
>6 years of age) and cetirizine (2.5 to .0 milligrams daily for age  to  years;  to  milligrams daily for >6 years of age), are preferable because they are less likely to cross the blood–brain barrier and therefore cause less sedation than first­generation antihistamines such as diphenhydramine and hydroxyzine. Other therapies target the immune system directly. Montelukast, a leukotriene receptor antagonist, and disodium cromoglycate, a mast
,37 cell stabilizer, have been used with success for symptom reduction. Sublingual and subcutaneous immunotherapy has also been shown to be
38­40 effective in improving symptoms of allergic rhinitis in children.
NASAL FOREIGN BODIES
Foreign body insertion is a common pediatric complaint in the ED. Foreign bodies in the external ear canal predominate, followed by nasal foreign
 bodies. Children who insert objects into their nose are, in general, younger than patients with auditory foreign body insertion. Although pharyngeal foreign bodies can present in adults, nasal foreign bodies are almost exclusively a pediatric problem. Common objects include beads, paper, rocks, toy parts, and organic material such as peas, corn, seeds, nuts, and legumes.
CLINICAL FEATURES
The child with a nasal foreign body may present with local pain (23% to 55%), nasal discharge (7% to 36%), epistaxis, or admission by the child.
Alternatively, the parent may witness the child placing something in the nose, or the object may be found during routine child care. Most children with
 nasal foreign bodies are asymptomatic.
DIAGNOSIS
Most nasal foreign bodies can be directly visualized. Have a high index of suspicion for a nasal foreign body in an appropriately aged child who presents with persistent, unilateral, purulent, foul­smelling nasal discharge (Figure 123­3).
FIGURE 123­3. A 6­year­old child was brought to the ED with a complaint of a foul­smelling serosanguineous discharge from the right nostril. He confessed to putting a button in his nostril about  week before this visit. [Reproduced with permission from Shah BR, Lucchesi M: Atlas of Pediatric Emergency Medicine. ©
2006, McGraw­Hill, Inc., New York, Figure 9­9.]
TREATMENT
Before attempting instrumentation, try less invasive removal using positive­pressure techniques. These include nose blowing in older children while occluding the opposite nostril or applying oral positive pressure by having the parent occlude the unaffected nostril, cover the child’s mouth with their own, and blowing (“parent kiss”); finally, a bag­valve mask can be used in a manner similar to the parent kiss. These techniques are successful in more
 than one half of cases. For more invasive methods, the key to successful removal is immobilization. Approximately 20% of patients undergoing nasal
 foreign body removal in the ED are given procedural sedation, most commonly with ketamine. Place the child in a supine position, and pretreat the
 nasal mucosa with topical 1% lidocaine and .5% phenylephrine. Phenylephrine shrinks inflamed nasal mucosa, allowing for easier removal of entrapped foreign bodies, and also reduces the likelihood of procedural epistaxis. The most common methods for removal include forceps, the Foley catheter technique (advance a lubricated 5­ or 6­French Foley balloon catheter past the object, inflating the balloon with air and withdrawing the catheter to gently remove the foreign body), and the use of a suction catheter. All have varying degrees of success and failure. Alligator forceps work best if the object is close to the anterior nares and can be easily grasped. If the object is friable, there is a risk of pulling it apart and leaving pieces in the nose. A particularly deep nasal foreign body may need to be removed by an otolaryngologist. Although it is possible to aspirate a nasal foreign body,
 this is rare, and most complications of nasal foreign bodies occur during attempted removal. Complications of nasal foreign body removal include failure to remove the object, epistaxis, laceration, and, rarely, septal perforation. If irrigation is attempted and the object is expandable, such as rice, vegetable matter, or sponge, the foreign body can swell, impeding its extraction.
SPECIAL CONSIDERATIONS

Button batteries pose an important risk to children, particularly those less than  years old. A button battery in the nasal cavity can cause liquefactive
 necrosis and septal perforation in as little as  hours. For this reason, remove button batteries as quickly as possible. Do not instill any type of nasal drops before removal because the electrical charge of the battery will produce electrolysis with any electrolyte­rich fluid. This results in a severe alkaline burn. Button batteries are often not directly visualized in the ED because of extensive mucopurulent discharge and mucosal edema. For this
 reason, consider a plain radiograph to characterize a nonvisible foreign body or unilateral foul­smelling nasal discharge.
Although more common in the external ear, live foreign bodies in the nose also require special mention. Cockroaches, mosquitoes, and beetles are all uncommon foreign bodies. They are often related to sleeping on the floor or poor hygiene. The recommended approach is to first kill the insect with
2% lidocaine or mineral oil and then attempt removal.
EPISTAXIS

Epistaxis usually occurs in children age  to  years old. It is rare in infants and older children. Nosebleeds in children are most often secondary to digital trauma (nose picking) or rhinitis sicca. Rhinitis sicca is more common in northern latitudes during the winter when the humidity is low and dry air heating systems can cause nasal mucosa desiccation and frequent bleeding.
Other causes of epistaxis include facial trauma, foreign bodies, sinusitis, or increased vascular pressure secondary to excessive coughing. Less commonly, epistaxis can be the presenting complaint of a coagulopathy, leukemia, or nasal tumor. Rarely, epistaxis may be the presenting sign of a juvenile nasopharyngeal angiofibroma, a tumor seen exclusively in adolescent males. Most pediatric epistaxis originates from Kiesselbach plexus, a venous vascular plexus on the anterior nasal septum. Although anterior bleeds usually ooze, posterior bleeds tend to be more profuse because they originate from the sphenopalatine artery. This type of bleeding, while rare, carries a higher risk of airway compromise, aspiration of blood, and lifethreatening hemorrhage.
TREATMENT
Most epistaxis can be controlled with conservative methods, such as pinching the nostrils together for  to  minutes with the patient slightly bent forward at the waist so as to avoid aspirating or swallowing blood. Ice or topical vasoconstrictors such as oxymetazoline hydrochloride or phenylephrine can also be applied to the nose to promote vasoconstriction. Cautery with silver nitrate can be used if the bleeding site can be identified. If all else fails, the nares can be packed with absorbable gelatin foam, oxidized cellulose, or preformed devices (Rhino Rocket Child®,
Shippert Medical Technologies Corporation, Centennial, CO). See Chapter 244, “Nose and Sinuses,” for the procedure and related information.
DISPOSITION AND FOLLOW­UP
Most children with simple epistaxis can be sent home with instructions to avoid digital trauma and apply topical antibiotic ointment to the nares at night to help lubricate the mucosa. Children with recurrent or severe epistaxis and a family history of a bleeding disorder or abnormal screening prothrombin time or activated partial thromboplastin time should be referred to a hematologist for a complete coagulopathy evaluation.
Approximately one third will have a diagnosable coagulopathy, most often von Willebrand’s disease type  (see Chapter 144, “Hematologic

Emergencies in Infants and Children”). If bleeding is recurrent, unilateral, and associated with nasal obstruction, a neoplasm may be suspected, and an otolaryngology consult is warranted. In an adolescent male with profuse unilateral epistaxis requiring packing, juvenile nasal angiofibroma should be suspected, and the patient should be evaluated with a CT scan.
Acknowledgments
We gratefully acknowledge the contributions of Kimberly S. Quayle, Susan Fuchs, and David M. Jaffe, the authors of this chapter in a previous edition.


