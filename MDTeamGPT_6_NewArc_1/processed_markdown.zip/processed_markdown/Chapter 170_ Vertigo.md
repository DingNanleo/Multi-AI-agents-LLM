## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 170: Vertigo
Brian Goldman; Peter Johns
Content Update: Hints, Vertigo, and Nystagmus April 2020
Text change under BEDSIDE TESTING FOR BPPV: Note that although it is appropriate to perform the Dix­Hallpike test on patients with short episodes of dizziness brought on by head movement, and without spontaneous or gaze evoked nystagmus, such patients should not have the HINTS­Plus exam performed on them. The latter would produce erroneous results. The
HINTS­Plus exam should be reserved for patients with ongoing constant vertigo and spontaneous or gaze evoked nystagmus. See Figure 170­2. INTRODUCTION AND EPIDEMIOLOGY
Vertigo is defined as the sensation of self­motion when no motion is occurring. Vestibular disorders are conditions that affect the vestibular sensory organs in the inner ear or the cerebellum and brainstem and the connections between them.
Some patients have difficulty describing the sensation of vertigo.1Dizziness is a nonspecific word patients use to describe vertigo, but is also used by some patients to describe the symptoms of presyncope, imbalance, lightheadedness, and other sensations. Assess patients for nonvestibular causes of dizziness such as orthostatic hypotension, presyncope, and new medications such as antihypertensives.
Vertigo is a diagnostic challenge because it has many potential causes (Table 170­1).
TABLE 170­1
Peripheral and Central Causes of Vertigo
Relative Frequency of
Peripheral Causes Key Points Clinical Course
Presentation to the ED
Benign paroxysmal The most common cause of Less than 2­minute episodes of vertigo, initiated by head movement. Dix­Hallpike Benign, particle repositioning maneuvers is firstpositional vertigo vertigo test shows vertical upward and rotatory nystagmus. line treatment. Medications rarely indicated.
Vestibular neuritis Common Hours/days of continuous, constant vertigo. Use HINTS plus exam if nystagmus Spontaneous improvement over days/weeks.
present.
Labyrinthitis Less common Ear pain, tinnitus, and hearing loss onset  or more days before vertigo; otherwise A complication of otitis media. Serious if bacterial similar to vestibular neuritis. (rare).
Ménière’s disease Less common Recurrent episodes of vertigo, hearing loss, tinnitus, and ear fullness. Slowly progressive; can lead to profound hearing loss.
Perilymph fistula Rare Vertigo and hearing loss after head trauma or pressure changes to middle ear Can benefit from surgical correction.
(flying/diving/nose blowing).
Superior canal Rare Vertigo brought on by loud sounds, coughing, and straining. Surgery for severe cases.
dehiscence
Vestibular Rare Slow onset of hearing loss, tinnitus, and less commonly, vertigo. Slowly growing; amenable to surgery if growing schwannoma and symptomatic.
Central Causes
Vestibular migraine Most common central cause of Recurrent attacks in patients with migraine, including episodes of isolated vertigo. Most experts recommend treatment as per vertigo, but much About half the episodes have migrainous features. migraine headache.
underdiagnosed.
Cerebellar/brainstem Less common Often presents with other neurologic signs or symptoms, but can present with Admit to hospital, as patients can develop stroke symptoms similar to vestibular neuritis; use HINTS plus exam if nystagmus is edema and/or hydrocephalus, leading to present. coma/death.
Downloaded 2025­7­1 6:22 P Your IP is 136.14H2e.a1ri5ng9 l.o1ss2 c7an occur at onset of stroke.
Chapter 170: Vertigo, Brian Goldman; Peter Johns 
©202P5os tMericoGr cirracuwla tHionill. AlLl eRssi gcohmtsm oRneserved. TermUss uoafl lUy psrees e * n tPs rwiivtha octyhe Pr noeulircoylo g * i cN siogntisc oer s * ym Apctocmes.ssibility Can present shortly before stroke.
transient ischemic stroke.
Cerebellar Less common Significant ongoing headache; possibly decreased level of consciousness. Neurosurgical consult; tonsillar herniation or hemorrhage hydrocephalus can occur.
Abbreviation: HINTS = head impulse test, nystagmus, test of skew.
Three of the most common vestibular disorders are featured prominently in this chapter. These are benign paroxysmal positional vertigo(BPPV), vestibular neuritis, and cerebellar/brainstem stroke. The term Acute Vestibular Syndrome (AVS) is sometimes used to describe the entities of vestibular neuritis and cerebellar/brainstem stroke.
BPPV is the most common cause of vertigo in all clinical settings including the ED. The condition occurs when otoconia (which normally reside in the utricle) are displaced spontaneously or by trauma or infection into the semicircular canals. As a result, when patients move their head in certain positions, they experience vertigo and nystagmus, sometimes very intense, for less than
 minutes, often around  seconds. BPPV can be diagnosed easily with a bedside test and is highly responsive to treatment with the Epley or other particle repositioning maneuvers.
Vestibular neuritis is the second most common peripheral cause of vertigo. Sometimes erroneously mislabeled as labyrinthitis by some clinicians, the condition is believed to be caused by a deficit in one of the vestibular nerves. The likely cause is a virus. The patient develops a prolonged, continuous bout of vertigo that is intense for several days and then resolves over days, weeks, or months. There is no associated ear pain, hearing loss, or tinnitus in vestibular neuritis.
Labyrinthitis, a complication of acute otitis media, is less common than vestibular neuritis but can present in a similar manner, with days of ongoing, continuous vertigo and nystagmus.
Unlike vestibular neuritis, patients with labyrinthitis complain of ear pain, hearing loss, or tinnitus as well as vertigo.
Cerebellar/brainstem stroke (hereafter referred to as cerebellar stroke) is the most feared cause of vertigo. Patients with cerebellar stroke may develop edema causing acute hydrocephalus or brainstem compression that leads to increased disability or death. Many patients present with neurologic symptoms such as limb weakness or paresthesia, diplopia, or dysarthria, but some present without these features; as such, the condition may resemble vestibular neuritis.
When patients are discharged from the ED with a diagnosis of peripheral vestibular disorder, the frequency of missed strokes is very low, about .41%(2).
The fear of missing a stroke can lead the clinician to pursue advanced diagnostic imaging in patients with benign peripheral conditions. Fortunately, the most common peripheral causes of vertigo presenting to the ED, BPPV and vestibular neuritis, can often be differentiated from cerebellar stroke by history, physical examination, and focused bedside testing.3
PATHOPHYSIOLOGY
The CNS coordinates and integrates sensory input from the visual, vestibular, and proprioceptive systems. Vertigo arises from a mismatch of information from two or more of the involved senses, caused by dysfunction in the sensory organ or its corresponding pathway.
Visual inputs provide spatial orientation. Proprioceptors help relate body movements and indicate the position of the head relative to that of the body. The vestibular system (via the otoliths) establishes the body’s orientation with respect to gravity. The cupula’s sensors track rotary motion. The three semicircular canals sense orientation to movement and head tilts and are filled with a fluid called endolymph. The movement of fluid in the semicircular canals causes specialized hair cells inside the canals to move, causing afferent vestibular impulses to fire. Sensory input from the vestibular apparatus travels to the nucleus of the eighth cranial nerve (Figure 170­1).
FIGURE 170­1. Vestibular innervation.
An illustration shows the upper medulla oblongata connected to vestibular apparatus. The spinal nucleus of accessory nerve passes through the upper medulla oblongata. It gives rise to the superior vestibular nucleus, medial vestibular nucleus, and lateral vestibular nucleus, which together form the vestibular ganglion. The vestibular nerve arises from the ganglion and connects to the following: saccule, superior semicircular canal, lateral semicircular canal, and posterior semicircular canal.
The medial longitudinal fasciculus, the red nuclei, the cerebellum, the parietal lobes, and the superior temporal gyrus of the cerebral cortex integrate the various sensory inputs. Connections between these structures and the oculomotor nuclei that drive the vestibulo­ocular reflex complete the system. The vestibulo­ocular reflex prevents visual blurring from head movements and body sway.
Balanced input from the vestibular apparatus on both sides is the norm. Unilateral lesions of the vestibular apparatus as well as excessive unilateral firing due to abnormal motion of the endolymph produce imbalanced activity and vertigo. Rapid head movements accentuate the imbalance. Symmetric bilateral damage does not usually produce vertigo but may lead to truncal or gait instability.
The prevalence of dizziness increases with age and is due to decreases in visual acuity, proprioception, and vestibular input, plus an increase in free­floating otoconia within the semicircular canals that cause BPPV. Older patients are also more likely to take medications that cause dizziness.
CLINICAL FEATURES
OVERVIEW
If the presenting complaint points to true vertigo, the history and physical should then focus on a central cause of vertigo. Such neurologic signs and symptoms include focal weakness of the face or limbs, sensory changes, dysmetria (limb or truncal), diplopia, dysarthria, and dysphagia and dysphonia. Spontaneous vertical nystagmus (seen in primary gaze, with the patient looking straight ahead) is also indicative of central vertigo but is seen less commonly than other types of nystagmus, even in cerebellar and brainstem lesions. Short episodes of vertical upward nystagmus with a rotatory component during the Dix­Hallpike test are diagnostic of the most common form of BPPV.
Patients who are unable to stand unaided should have a central cause of vertigo ruled out. This is in contrast to the patient with peripheral vertigo; they may be very reluctant to stand or walk but are able in general to do so.
A significant and persistent headache that accompanies vertigo suggests the possibility of a cerebellar hemorrhage, and neck pain suggests vertebral artery dissection.
Patients with current or recent transient vertigo who screen positive for the neurologic symptoms mentioned previously should have diagnostic imaging as well as referral to a specialist. This method of screening will identify the majority of ischemic or hemorrhagic cerebellar and brainstem strokes causing vertigo, as well as posterior circulation transient ischemic attacks and vertebral artery dissections. Many of the vestibular disorders that cause peripheral and central vertigo are found in Table 170­1. HISTORY AND PHYSICAL
An initial approach to diagnosing acute vertigo, focusing on BPPV, vestibular neuritis, and cerebellar stroke, is shown in the flow chart in Figure 170­2. FIGURE 170­2. Flow chart of the initial approach to the diagnosis of acute vertigo. BPPV = benign paroxysmal positional vertigo; HINTS = head impulse test, nystagmus, test of skew; HIT = head impulse test.
First, determine neurologic symptoms and or if deficits are or were present. The neurologic symptoms or deficits indicative of a central vertigo are as follows: Focal weakness or paresthesia of face or limbs. Dysarthria, diplopia, dysphagia, dysmetria, dysphonia. Also look for spontaneous vertical nystagmus not during a Dix Hallpike test, significant headache or neck pain and of the patient is unable to stand unaided.If there are positive neurological symptoms, imaging is indicated and determine if there should be a referral to specialist care. If there are no symptoms, two courses can be followed depending on the length of the episode. In the case of a short episode, which lasted less than  minutes, were initiated by head movement, did not result in ongoing, continuous vertigo, and spontaneous or gaze evoked nystagmus is absent, conduct Dix Hallpike testing, where H I N T S plus is not indicated.
Vertical upward and rotatory nystagmus indicates a positive Dix Hallpike. Proceed with B P P V and then with an Epley maneuver.In the case of a negative Dix Hallpike or atypical response, consider other diagnoses. Perform supine roll test to assess for Horizontal Canal B P V V. In the case of many hours or days of ongoing, continuous vertigo, which is worsened by head movement and spontaneous or gaze evoked nystagmus is present, conduct H I N T S plus testing. Dix Hallpike is not indicated. If there are any of the following symptoms, stoke is diagnosed: bidirectional nystagmus, vertical skew deviation, normal HIT, or new hearing loss. Imaging is indicated as is possible referral to specialist care. If all four of following symptoms are present, H I N T S plus equals peripheral and vestibular neuritis is the diagnosis: unidirectional nystagmus, no vertical skew deviation, abnormal HIT, and no new hearing loss.
BPPV comes on abruptly with quick head movements, getting in or out of bed, or rolling over in bed. Patients with orthostatic hypotension complain of dizziness when they stand up but not when they resume the supine position or roll over in bed. If the patient with BPPV remains still, the vertigo usually goes away in less than  or  minutes. However, the associated nausea and vomiting may persist, prompting the patient to state that the dizziness lasts longer than  minutes. In addition, between bouts of vertigo, the patient with BPPV may feel slightly “off” but without ongoing vertigo or spontaneous nystagmus. This is contrasted with the presentations of vestibular neuritis and cerebellar stroke in which the patient has persistent and continuous vertigo lasting many hours or days and whose vertigo is made worse by position change. Note that head movements can worsen both central and peripheral vertigo.
Assess the patient carefully for nystagmus. The direction of the nystagmus is defined as the direction of the fast component of the nystagmus. Nystagmus can be horizontal, vertical, rotatory, or a combination. Since nystagmus may be suppressed by visual fixation, avoid having the patient stare at your finger or light source when observing for nystagmus. Observe for spontaneous nystagmus, which can be seen when the patient is looking straight ahead (primary gaze). Also observe for gaze­evoked nystagmus by having the patient look approximately  degrees from primary gaze to the left and right. To avoid fixation, place a blank piece of paper close to the side of the patient’s head and ask the patient to look through the paper as if it is not there.
BEDSIDE TESTING FOR BPPV
PATIENTS WITH EPISODES OF VERTIGO LASTING LESS THAN  MINUTES AND INITIATED BY HEAD POSITION CHANGE BUT NO SPONTANEOUS OR
GAZE­EVOKED NYSTAGMUS
Dix­Hallpike Test
The Dix­Hallpike test (DHT) (See Video: Dix Hallpike Maneuver) is used to confirm the diagnosis of posterior canal BPPV, which is the most common form of BPPV. It is appropriate to perform a
DHT if a patient has dizziness brought on by head movements only (such as rolling over in bed, lying down, or getting out of bed) that lasts  to  seconds and has no spontaneous or gazeevoked nystagmus.
Video 170­1: Performing the Dix Hallpike Test
Used with permission from Peter Johns, MD.
Play Video
Consider pretreatment with an antiemetic only if the patient is having trouble tolerating positional testing or therapeutic maneuvers; it should not be given routinely.4
Have the patient seated on a stretcher or bed and positioned so that when supine, the patient’s neck can be extended  degrees. To observe for nystagmus, instruct the patient to keep the eyes open throughout the test, even if vertigo occurs. To test the left ear, have the patient turn the head  degrees to the left. The examiner then quickly brings the patient from a sitting position to a supine position, with the neck extended  degrees and head turned  degrees to the left. Wait  seconds, and if no vertigo or nystagmus occurs, sit the patient up. Test the right side in the same manner, with the head turned  degrees to the right (See Video: Performing the Dix­Hallpike Test).
A positive DHT consists of a few seconds (up to 15) of latency, in which the patient is asymptomatic, followed by the onset of vertigo with a crescendo­decrescendo pattern of nystagmus that typical lasts roughly  to  seconds.
The nystagmus is a combination of vertical upward and rotatory, with the upper poles of the eyes beating toward the downward ear. When the patient looks more toward the upward ear, the nystagmus becomes more vertical and more rotatory when looking toward the downward ear.5,6The downward ear is the affected ear. Otoconia that originate in the utricle have been displaced and are now in the posterior semicircular canal (See Video: Positive Dix­Hallpike Test).
Video 170­2: Positive Dix Hallpike Test
Used with permission from Peter Johns, MD.
Play Video
Note that although it is appropriate to perform the Dix­Hallpike test on patients with short episodes of dizziness brought on by head movement, and without spontaneous or gaze evoked nystagmus, such patients should not have the HINTS­Plus exam performed on them. This would produce erroneous results. The HINTS­
Plus exam should be reserved for patients with ongoing constant vertigo and spontaneous or gaze voked nystagmus. See Figure 170­2. TREATMENT OF POSTERIOR CANAL BPPV
Patients who are diagnosed with BPPV can be treated with the Epley maneuver during their ED visit.8The Epley maneuver should be considered first­line treatment for posterior canal BPPV.
The affected ear is the downward ear when the patient has a positive DHT. Since BPPV can occur in either ear, there is a left and right Epley maneuver (Figure 170­3and See Video: The Epley
Maneuver).
FIGURE 170­3. Left­sided Epley maneuver.
Illustration A shows a person in an upright position. The affected spot is in a semicircular canal.Illustration B shows a person lying on his back with head suspended freely downward along his left side. The affected spot moves downward into the canal.Illustration C shows a person lying on his back with head suspended freely downward along his right side. The affected spot moves further downward to almost the end of canal.Illustration D shows a person lying sideway with tilted shoulder and head facing the floor. The affected spot exits the semicircular canal and enter the saccule. Finally, Illustration D shows the person again in upright position. The affected spot has moved to the center of the saccule and remains free.
Video 170­3: The Epley Maneuver
Used with permission from Peter Johns, MD.
Play Video
In Figure 170­3, the left ear Epley maneuver is shown. Hold each position for the length of time the patient is having vertigo, plus another  seconds. The first position is the same as the positive DHT position. Then, without sitting the patient up, the head is rotated  degrees to the negative DHT side, the second position. For the third position, the patient is asked to roll on his or her side and the head is rotated another  or more degrees in the same direction as the previous step, so that the patient is now looking toward the stretcher or straight down at the floor. In the final step, the patient is asked to move the legs forward off the bed, and the patient is brought to the sitting position, while keeping the head turned in the same direction as in the third position. In the final position, the patient should sit with head upright and looking forward.
After  minutes, repeat the DHT. If the post­Epley DHT produces no vertigo or nystagmus, the patient can be discharged without any restrictions on activity. It is not unusual for patients whose vertigo and nystagmus have resolved to feel slightly “off” for a day or two after being treated successfully. However, there should be no further episodes of positional nystagmus. If the post­Epley DHT is still positive, the Epley maneuver can be repeated. If the second Epley maneuver is unsuccessful, instruct the patient to perform subsequent trials of the maneuver at home twice a day until symptoms resolve. Such patients should have follow­up to ensure clinical improvement.
Since the episodes of BPPV typically last  to  seconds, do not prescribe vestibular suppressants.
If the DHT is negative on both sides or purely horizontal nystagmus is seen, then perform the supine roll test to determine whether the patient is suffering from a less common variant of BPPV
—horizontal canal BPPV.
TREATMENT OF HORIZONTAL CANAL BPPV
If the patient has pure horizontal nystagmus when testing both left and right sides with the supine roll test, then the patient has horizontal canal BPPV and will not benefit from the Epley maneuver. Such patients can be treated with another particle repositioning maneuver called the Gufoni maneuver (See Video: Horizontal Canal BPPV).
Video 170­4: Horizontal Canal BPPV
Used with permission from Peter Johns, MD.
Play Video
Horizontal canal BPPV is rarer, resolves spontaneously more quickly, and is more difficult to assess and treat than posterior canal BPPV. Thus, it is reasonable to refer the patient with suspected horizontal canal BPPV to a clinician familiar with the diagnosis for further management.
ANTERIOR CANAL BPPV
Should the patient experience downward vertical nystagmus during the DHT, the patient may be suffering from the least common form of BPPV, anterior canal BPPV. It can be treated using the deep head hanging maneuver (See Video: Anterior Canal BPPV).
Video 170­5: Anterior Canal BPPV
Used with permission from Peter Johns, MD.
Play Video
Patients with a positive DHT are invariably suffering from posterior canal BPPV and do not need imaging. Rarely, patients with purely horizontal or down­beating nystagmus on positional testing may have a central cause of vertigo such as cerebellar degeneration, strokes, or tumors.
If the appropriately selected maneuver fails to resolve the episode of BPPV, the patient should have follow­up for further assessment and treatment.
BEDSIDE HINT + TESTING TO DISTINGUISH VESTIBULAR NEURITIS FROM CEREBELLAR/BRAINSTEM STROKE
PERSISTENT CONTINUOUS ONGOING VERTIGO FOR HOURS OR DAYS WITH SPONTANEOUS NYSTAGMUS AND/OR GAZE­EVOKED NYSTAGMUS
These patients are suffering from acute vestibular syndrome with vertigo, nausea, and vomiting. Symptoms of acute vestibular syndrome worsen with head movement. Patients may also present with difficulty with gait. The majority of patients seen with acute vestibular syndrome are suffering from vestibular neuritis, but some will have a cerebellar stroke. Many, but not all, patients with stroke will have features suggestive of central vertigo (Figure 170­2). If these features are present, the patient should have neurodiagnostic imaging. Less commonly, multiple sclerosis can also present with acute vestibular syndrome.
HINTS Exam and HINTS Plus Exam
The HINTS plus exam is a series of four bedside tests: head impulse test, nystagmus, and test of skew, plus a bedside test for new hearing loss. This battery of tests is used to distinguish patients with continuous vertigo (lasting hours to days) and nystagmus who have a peripheral disorder (most likely vestibular neuritis) from those who have a central disorder (most likely cerebellar stroke). The original HINTS study selected patients with at least two risk factors for stroke, and the majority had strokes. The HINTS exam was performed by a single neuroophthalmologist. The HINTS exam was more sensitive and specific than early MRI.9
A study of acute vestibular syndrome patients (two thirds of whom had vestibular neuritis) who had HINTS performed in the ED by neurology residents showed almost identical results, with
100% sensitivity and 94% specificity for the HINTS exam in identifying stroke from vestibular neuritis.10(See Video: The HINTS Plus Exam in Vertigo.)
Video 170­6: The HINTS "Plus" Exam in Vertigo
Used with permission from Peter Johns, MD.
Play Video
Nystagmus
Examine the patient first for spontaneous or gaze­evoked nystagmus and note the direction and type. Only patients with persistent ongoing vertigo and spontaneous or gazeevoked nystagmus should undergo HINTS testing.7 In vestibular neuritis, the nystagmus (typically horizontal with a rotatory component) becomes more intense when the patient gazes in the direction of the nystagmus and lessens when looking away from the direction of the nystagmus. The affected ear in vestibular neuritis is the ear opposite to the direction of the nystagmus. Note that in vestibular neuritis, the fast component of the nystagmus does not change direction when gazing left and right. In central causes of nystagmus, the direction of the nystagmus may change direction depending on the direction of gaze (bidirectional nystagmus). When the patient looks to the left, the fast component of the nystagmus is to the left, and when looking to the right, the fast component is to the right. Although this is not always seen in central causes of vertigo, it is a highly specific sign for central vertigo.
Test of Skew
Test of skew is accomplished by the cover­uncover test. While the patient looks at the examiner’s nose, the examiner covers one eye and then covers the other eye. Any vertical or diagonally upward or downward movement of the eyes as they are uncovered indicates a central cause of vertigo.
Head Impulse Test
Next, the head impulse test is used to demonstrate an abnormal vestibulo­ocular reflex on the side of the affected ear, a finding in patients with vestibular neuritis. To perform a head impulse test, hold the patient’s head gently but firmly. Ask the patient to look at the examiner’s nose, and gently move the head left and right around  degrees from the midline. The patient should be sufficiently relaxed so that the examiner can then move the patient’s head from  degrees left or right of the midline quickly back to the midline. This should be done in a random fashion so that the patient does not anticipate in which direction the quick movement will occur.
In normal subjects, the eyes remain fixated on the examiner’s nose, indicating an intact vestibulo­ocular reflex. In patients with vestibular neuritis, when the head is moved quickly toward the affected ear (spontaneous nystagmus is in the direction of the unaffected ear), the eyes will move with the head and thus overshoot the target (the examiner’s nose). The examiner sees a
“catch up saccade” in the same direction as the spontaneous nystagmus that is noticeably larger in amplitude.
Since most patients with stroke do not have a nerve deficit, a normal head impulse test is concerning for a central cause of vertigo in patients with persistent vertigo and spontaneous nystagmus. This counterintuitive finding bears emphasis, as it is open to misinterpretation.
Hints Plus
Finally, the “plus” component of the HINTS plus exam has the examiner check for acute hearing loss by rubbing thumb and fingers together just lateral to the patient’s left and right ear and asking whether the patient can hear it. New hearing loss is suggestive of a central cause. In particular, patients with an anterior inferior cerebellar artery stroke may have an abnormal head impulse test due to infarction of the labyrinth, as well as part of the cerebellum. The labyrinth contains the sensory end organs of balance and hearing. Thus, these patients will have both an abnormal head impulse test and new hearing loss.
Table 170­2outlines the clinical characteristics of BPPV, vestibular neuritis, and cerebellar stroke and details the indications for and interpretation of DHT and HINTS plus testing.
TABLE 170­2
Clinical Presentation and Guide to Bedside Testing for BPPV, Vestibular Neuritis, and Cerebellar Stroke
BPPV Vestibular Neuritis Cerebellar Stroke
Vertigo when still No Yes Yes
Able to stand unaided Yes Yes May not be able to
Spontaneous and/or gaze­evoked nystagmus No Yes Yes
Typical spontaneous or gaze­evoked nystagmus Not present Unidirectional Various, including bidirectional horizontal/rotatory, sometimes seen horizontal/rotatory vertical
Not purely vertical
Worse when moves head Yes Yes Yes
Other neurologic symptoms or findings No No Often but not always present
New hearing loss No No Can occur
Appropriate to perform Dix­Hallpike test Yes No No
Nystagmus produced during Dix­Hallpike test Vertical upward and rotatory Do not perform Dix­Hallpike test Do not perform Dix­Hallpike test
Appropriate to perform HINTS plus exam No Yes Yes
Results from HINTS plus exam Do not perform HINTS plus All four findings: ANY of: testing Unidirectional nystagmus Bidirectional nystagmus
No vertical skew Vertical skew present
Abnormal HIT Normal HIT
No hearing loss New hearing loss
HINTS plus = peripheral HINTS plus = central
Imaging indicated No No Yes
Primary treatment Epley maneuver Supportive treatment Treatment for stroke
Abbreviations: BPPV = benign paroxysmal positional vertigo; HINTS = head impulse test, nystagmus, test of skew; HIT = head impulse test.
TREATMENT OF VESTIBULAR NEURITIS
The majority of patients with constant vertigo lasting hours to days who undergo HINTS plus testing in the ED will be diagnosed with vestibular neuritis. The treatment is largely symptomatic, with short courses of antiemetic medications to ease vomiting.11
TREATMENT OF CEREBELLAR/BRAINSTEM STROKE
Admission is indicated to allow monitoring for complications such as cerebral edema and hydrocephalus. Secondary stroke prevention and rehabilitation should also be instituted during hospitalization.
It should be emphasized that the DHT should be performed only on patients with brief episodes of vertigo who have no spontaneous or gaze­evoked nystagmus. HINTS plus testing should be performed only on patients with hours or days of continuous constant vertigo and who have nystagmus. Since the two clinical presentations are easy to distinguish, there is no rationale for performing both the DHT and the HINTS plus exam in the same patient.
Patients who have vertigo that lasts between  minutes and many hours could have other diagnoses, most commonly vestibular migraine, Ménière’s syndrome, or transient ischemic attack.
POSTERIOR CIRCULATION TRANSIENT ISCHEMIC ATTACK
Posterior circulation transient ischemic attack may present with transient vertigo and focal neurologic symptoms typical of cerebellar or brainstem stroke, such as weakness of the face or limbs, sensory changes, dysmetria (limb or truncal), diplopia, dysarthria, dysphagia, or dysphonia. Such patients should be triaged, investigated, and treated similar to patients with anterior circulation transient ischemic attacks. Since HINTS plus testing should be performed only on patients with ongoing vertigo and nystagmus, HINTS plus testing is not appropriate for transient ischemic attack patients whose vertigo and/or other posterior circulation symptoms have resolved.
Patients with posterior circulation stroke often experience transient neurologic attacks prior to the stroke. However, only 4% of patients with posterior circulation stroke seek medical attention for what seems to them to be nonspecific symptoms.12In one study of 169 patients with isolated vertigo, just one patient had a transient ischemic attack.13A study of 3900 patients with transient ischemic attack found that isolated vertigo was negatively associated with having an impending stroke.14The optimal diagnostic approach for patients who present with spontaneous transient isolated vertigo remains uncertain.
DIAGNOSTIC IMAGING
See Table 170­3 for a condition­specific approach to diagnostic imaging.
TABLE 170­3
Approach to Diagnostic Imaging in Vertigo
BPPV and vestibular neuritis: none required if findings are typical and bedside testing is confirmatory
Cerebellar/brainstem stroke:
CT angiography if in rare case the stroke score deficit indicates potential benefit for thrombolysis or endovascular clot retrieval
Emergent MRI if acute intervention not indicated or HINTS plus indicates central cause and more than  hours of vertigo
Admit to hospital and perform delayed MRI in 2–3 days if acute intervention not indicated; HINTS plus indicates central cause and symptoms less than  hours
Vestibular migraine: none required if clinical history and presentation are diagnostic for vestibular migraine
Suspected vertebral artery dissection (significant ongoing neck pain): CT angiography or MRI/MRA of head and neck
TIA with neurologic symptoms or signs beyond vertigo and nystagmus: CT angiography or MRI/MRA
Suspected TIA without neurologic symptoms (isolated vertigo): consider CT angiography or MRA if patient has significant risk factors for stroke/TIA; a optimal diagnostic strategy has yet to be defined
Ménière’s disease: none for typical presentation
Suspected cerebellar hemorrhage (significant ongoing headache or decreased level of consciousness): CT of the head
Multiple sclerosis: MRI
Postconcussive vertigo: CT of the head if intracranial hemorrhage suspected
Labyrinthitis:
Viral: none
Bacterial: MRI
Superior canal dehiscence syndrome: CT of temporal bone
Vestibular schwannomas: MRI
Abbreviations: BPPV = benign paroxysmal positional vertigo; HINTS = head impulse test, nystagmus, test of skew; MRA = magnetic resonance angiography; TIA = transient ischemic attack.
TREATMENT
SYMPTOMATIC TREATMENT FOR PERIPHERAL VERTIGO
Short­term treatment with antiemetic and vestibular suppressant pharmacotherapy is a mainstay for patients with peripheral vertigo other than BPPV15(Table 170­4). Withdraw symptomatic treatments as soon as possible to facilitate central vestibular compensation.16
TABLE 170­4
Pharmacotherapy of Vertigo and Dizziness
Category Drug Dosage Indications Advantages Disadvantages
Anticholinergics Scopolamine .5 milligram transdermal patch Vertigo, nausea Useful if patient is vomiting Sometimes difficult to obtain
(behind ear) three to four times a day
Antihistamines Dimenhydrinate 50–100 milligrams IM, IV, or PO every  Vertigo, nausea Inexpensive Drowsiness/anticholinergic effect h
Diphenhydramine 25–50 milligrams IM, IV, or PO every  h Vertigo, nausea Inexpensive Drowsiness/anticholinergic effect
Meclizine  milligrams PO two to four times a Vertigo, nausea Drowsiness/anticholinergic effect day
Antiemetics Hydroxyzine 25–50 milligrams PO four times a day Vertigo, nausea Inexpensive Drowsiness/anticholinergic effect
Metoclopramide 10–20 milligrams IV, PO three times a Vertigo, nausea Effective, versatile Occasional extrapyramidal effect day
Ondansetron  milligrams IV two to three times a day;  milligrams PO twice a day
Promethazine  milligrams IM, PO, or PR three to four Vertigo, nausea Useful if vomiting Occasional extrapyramidal effect times a day
Benzodiazepines Diazepam 2–5 milligrams PO two to four times a Central vertigo, anxiety Inexpensive Dependency, may impair vestibular day related to peripheral vertigo compensation
Clonazepam .5 milligram PO two times a day Central vertigo, anxiety Inexpensive Dependency, may impair vestibular related to peripheral vertigo compensation
Calcium Cinnarizine  milligrams PO two to three times a Peripheral vertigo, vestibular Nonsedating Lesser clinical experience antagonists day migraine
Nimodipine  milligrams PO two times a day Peripheral vertigo, vestibular Nonsedating Lesser clinical experience migraine
Flunarizine  milligrams PO two times a day Ménière’s syndrome Well tolerated Not available in the United States
Vasodilators Betahistine  milligrams PO three times a day for Ménière’s syndrome Well tolerated Little evidence of efficacy for other causes up to 6–12 mo of peripheral vertigo
Corticosteroids Methylprednisolone 100 milligrams/d tapered by  Vestibular neuronitis Well tolerated Efficacy largely unproven; adverse effects milligrams/d every fourth day associated with corticosteroids
Antivirals Valacyclovir 1000 milligrams three times a day for  Vestibular neuronitis Well tolerated Efficacy largely unproven d
Anticonvulsants Carbamazepine 200–600 milligrams/d Vestibular paroxysmia Inexpensive Monitor CBC and liver function tests
Topiramate 50–100 milligrams/d Vestibular migraine Well tolerated Not well evaluated; does not abort acute prophylaxis vertigo
Valproic acid 300–900 milligrams/d Vestibular migraine Well tolerated Not well evaluated; does not abort acute prophylaxis vertigo
Gabapentin 300 milligrams four times per day Multiple sclerosis–associated Reduces acquired pendular Known adverse effect profile dizziness nystagmus of multiple sclerosis
β­Blockers Metoprolol 100 milligrams/d Vestibular migraine Long experience Known adverse effect profile prophylaxis
DRUG THERAPY
Pharmacotherapy is used to treat specific conditions, reduce symptoms, or enhance vestibular compensation. Drugs with anticholinergic effects can be quite effective for vertigo.
Transdermal scopolamine is a time­honored remedy. H antihistamines are commonly prescribed drugs for their anticholinergic effects. H antihistamines are not effective. Calcium channel
  blockers (Table 170­4) are indicated for the symptomatic relief of vertigo in patients not responding to scopolamine or antihistamines. Neuroleptics such as promethazine and metoclopramide reduce nausea and vomiting by blocking brainstem dopaminergic receptors. They too are indicated as second­line treatment. Do not use prochlorperazine and chlorpromazine in dizziness caused by orthostatic hypotension. Ondansetron, a serotonin 5­HT receptor antagonist, is an antinauseant that has been used to treat intractable vertigo in
 brainstem disorders as well as vertigo due to multiple sclerosis.
Small doses of benzodiazepines may be used sparingly to relieve symptoms of acute vestibular neuritis. However, these agents may impair vestibular compensation and thus should not be used for more than  days.
Betahistine is a strong H antagonist and a weak H agonist that increases cochlear blood flow and decreases peripheral vestibular inputs. A dosage of  milligrams/d is effective in treating
  vertigo, and may facilitate vestibular compensation.17
Gabapentin is indicated for dizziness associated with multiple sclerosis.
Antihistamines can cause sedation and anticholinergic adverse effects. Antidopaminergic neuroleptic agents can induce or exacerbate orthostatic hypotension. These drugs also cause somnolence and acute dystonia and can exacerbate anticholinergic adverse effects. Avoid using medications with overlapping anticholinergic and antidopaminergic effects in combination.
Do not treat patients with nonvertiginous dizziness and disequilibrium of aging with antivertigo medications.
OTHER SPECIFIC CONDITIONS
VESTIBULAR MIGRAINE
Vestibular migraine is the most common central cause of vertigo. After BPPV, it is the second most frequent cause of vertigo in the ED. It has a 1­year prevalence of .89%.18In patients who are referred to a tertiary vertigo clinic, 25% of the patients have vestibular migraine, but the diagnosis was suspected by the referring physician in less than 10% of cases.19
Vestibular migraine is a common cause of vertigo in children. For some postmenopausal women with a long­standing history of migraine, episodic vertigo may replace the typical headache.
Thirty percent of patients have no headache before, during, or after the episode of vertigo. The diagnosis of vestibular migraine is made clinically (Table 170­5). Currently, there is no proven specific therapy for prophylaxis of vestibular migraine.20Expert opinion suggests the use of the medications that are commonly used for migraine headache.
TABLE 170­5
Diagnostic Criteria for Vestibular Migraine
Moderate or severe episodes of vertigo lasting  minutes to  hours
Past or current history of migraine
 or more episodes of vertigo, at least 50% of which have one of following three migrainous features: visual aura, photophobia or phonophobia, or typical migraine headaches
Typical migraine headaches should have at least two of the following four qualities: unilateral, pulsating, moderate or severe intensity, or aggravated by routine activity
In addition, the patient’s clinical presentation should not better accounted for by another headache or vestibular problem
MÉNIÈRE’S SYNDROME
Ménière’s syndrome is a disorder associated with an increased endolymph within the cochlea and labyrinth. It tends to occur in older men and women with equal prevalence. The disease is usually unilateral but may become bilateral over time. The precise pathogenesis is unknown, but evidence suggests that patients have difficulty regulating the volume, flow, and composition of endolymph. The onset is usually sudden, with associated nausea, vomiting, and diaphoresis, with attacks lasting from  minutes to  hours. The frequency of attacks varies from several times per week to several times per month. Other associated symptoms include tinnitus, diminished hearing, and fullness in one ear. Between attacks, the patient is usually well, although decreased hearing may persist.
Ménière’s syndrome is managed symptomatically with antihistamines and betahistine; combination therapy with triamterene and hydrochlorothiazide is also recommended in confirmed cases. Calcium channel blockers may also be used (Table 170­4). None of these drug treatments improves hearing.
Refer patients for treatment to an otolaryngologist, because intratympanic injections of corticosteroids or gentamicin are increasingly used to control the frequency of attacks in patients not responding to standard therapy.21
PERILYMPH FISTULA
A perilymph fistula is an opening in the round or oval window that permits pneumatic changes in the middle ear to be transmitted to the vestibular apparatus. Trauma, infection, or a sudden change in the pressure inside the ventricular system may cause the tear. The diagnosis is suggested by the sudden onset of vertigo and hearing loss associated with head trauma, flying, scuba diving, severe straining, heavy lifting, coughing, or sneezing. Associated symptoms may include hearing loss.
Perilymph fistula is managed with symptomatic treatment and bed rest and referral to an ear, nose, and throat specialist for surgical repair (emergent referral for patients with acute associated hearing loss).
VESTIBULAR GANGLIONITIS
Vestibular ganglionitis is believed to be caused by a neurotrophic virus such as varicella­zoster reactivated years following initial infection. Herpes zoster oticus, also known as the Ramsay
Hunt syndrome, is a neuropathic disorder thought to be associated with vestibular ganglionitis. It is characterized by deafness, vertigo, and facial nerve palsy. The diagnosis is confirmed by the presence of grouped vesicles on an erythematous base inside the external auditory canal. Treat this disorder with antiviral therapy started within  hours of the appearance of vesicles along with symptomatic treatments.
OTOTOXICITY
Various drugs have been found to be ototoxic (Table 170­6). Aminoglycoside antibiotics produce hearing loss and peripheral vestibular dysfunction by accumulating inside the endolymph, causing the death of cochlear and vestibular hair cells. However, because both inner ears are affected, vertigo is uncommon. Clinical manifestations include ataxia and oscillopsia (defined as the inability to maintain visual fixation while moving). The damage is usually irreversible but is dose and duration dependent. Loop diuretics (furosemide and ethacrynic acid) also cause irreversible vestibular toxicity and ototoxicity. Cytotoxic agents such as vinblastine and cisplatin cause vestibular damage; however, newer platinums, such as carboplatin, are less likely to do so. The antiarrhythmic drug quinidine and antimalarial drugs derived from quinine, such as chloroquine and mefloquine, also can cause vestibular symptoms that may be irreversible.
TABLE 170­6
Ototoxic and Vestibulotoxic Agents
Agent Dose Dependent Reversible
Aminoglycosides Yes Usually not; possible improvement with N­acetylcysteine
Erythromycin No Yes
Minocycline No Yes
Fluoroquinolones No Yes
NSAIDs; salicylates Yes Yes
Loop diuretics No Can be irreversible
Cytostatic drugs Yes No
Antimalarials No Yes
Anticonvulsants Yes Yes
Reversible causes of vestibular damage and ototoxicity include NSAIDs, salicylates, minocycline, erythromycin, and some fluoroquinolones. Isolated cases of unsteady gait have been observed with antiviral drugs such as abacavir as well as antiparasitic agents. Solvents and other chemicals such as propylene glycol, toluene, mercury, and hydrocarbons can cause both peripheral and central vestibular symptoms.
Drugs that sometimes induce a central vestibular syndrome include tricyclic antidepressants, neuroleptics, opiates, and alcohol. Anticonvulsants cause dizziness and ataxia, especially in older patients. Phenytoin, toluene, and cancer chemotherapy agents can cause irreversible cerebellar toxicity. Phencyclidine is a recreational drug that causes central vestibular symptoms, including nystagmus and ataxia.
In general, most patients adapt to chronic vertigo by relying on intact proprioception and vision. However, benzodiazepines and neuroleptics that are often used as antivertigo therapy may exacerbate symptoms by delaying or inhibiting such compensation. Thus, avoid using this therapy on a long­term basis. Refer patients with suspected ototoxicity to an otolaryngologist.
POSTTRAUMATIC VERTIGO
Acute posttraumatic vertigo and unsteady gait are caused by a direct injury to the labyrinthine membranes. The onset of vertigo is immediate and is accompanied by nausea and vomiting.
There may be a concomitant fracture of the temporal bone. Vertigo associated with a closed head injury warrants CT or MRI to exclude an intracranial hemorrhage. Vertigo due to direct labyrinthine trauma tends to resolve within several weeks. Closed head trauma also can displace otoconia from the utricular maculae, precipitating an attack of BPPV. Postconcussive syndrome can be associated with unsteadiness of gait and a vague sense of dizziness. These patients may be treated symptomatically, with referral to an appropriate clinic if symptoms fail to resolve.
WALLENBERG’S SYNDROME
A lateral medullary infarction (Wallenberg’s syndrome) of the brainstem can cause vertigo as part of its clinical presentation. Classic ipsilateral findings include facial numbness, loss of corneal reflex, Horner’s syndrome, and paralysis or paresis of the soft palate, pharynx, and larynx (causing dysphagia and dysphonia). Contralateral findings include loss of pain and temperature sensation in the trunk and limbs. Occasionally, lesions of the sixth, seventh, and eighth cranial nerves can occur, causing vertigo, nausea, vomiting, and nystagmus. These patients require emergent MRI and neurologic consultation.
MULTIPLE SCLEROSIS
Demyelinating disease can present with vertigo that lasts several hours to several weeks and is usually not recurrent. The vertigo is mild, with nystagmus the most prominent finding on physical examination. Such patients require confirmatory testing with MRI as well as vestibular evoked myogenic potentials and referral to a neurologist.


