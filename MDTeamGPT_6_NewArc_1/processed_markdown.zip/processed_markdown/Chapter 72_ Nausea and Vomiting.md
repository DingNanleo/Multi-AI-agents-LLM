## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 72: Nausea and Vomiting
Bophal Sarha Hang; Jeffrey S. Ditkoff; Alex Koyfman; Brit Long
INTRODUCTION AND EPIDEMIOLOGY
Nausea and vomiting accompany a variety of illnesses. Symptoms may be due to primary GI disorders such as bowel obstruction or gastroenteritis.
However, symptoms may also represent pathology of the CNS (increased intracranial pressure, tumor), psychiatric conditions (bulimia nervosa, anxiety), endocrine or metabolic abnormalities (DKA, hyponatremia), or iatrogenic causes (medications, toxins). Also, nausea and vomiting may be the result of severe pain, myocardial infarction, sepsis, or other systemic illnesses. A comprehensive history and physical examination, as well as the use of various diagnostic modalities, are needed to determine the cause and its complications.
In the United States, the most common cause of acute nausea and vomiting is viral gastroenteritis. Other important considerations are side effects
 from medication and, in young women, pregnancy.
PATHOPHYSIOLOGY
Multiple neurons in the medulla oblongata are activated in a sequential fashion to induce vomiting. The vomiting center is the chemoreceptor trigger zone, located in the area postrema of the fourth ventricle. Chemoreceptors in this area are outside the blood–brain barrier and are stimulated by circulating medications and toxins, including dopaminergic antagonists (levodopa, bromocriptine), nicotine, digoxin, and opiate analgesics. Another important peripheral pathway for emesis is mediated through vagal afferents. Vagal activation is triggered by direct gastric mucosal irritants (such as
NSAIDs) or increased luminal distention (gastric outlet obstruction, gastroparesis). Vagus activation stimulates neurons in the area postrema and nucleus tractus solitarius. These areas are rich in serotonin receptors and are a major site of action of antiemetic drugs, such as granisetron and
 odansetron. Similar receptors are found throughout the GI tract, as well as the cortex and limbic system, vestibular system, heart, and genitalia.
CLINICAL FEATURES
The differential diagnosis of nausea and vomiting is exhaustive, as pathology of almost every organ system may lead to nausea and vomiting (Table
72­1). A thorough history and physical examination will help guide the diagnostic approach to the patient presenting with nausea and vomiting.
TABLE 72­1
Differential Diagnosis of Nausea and Vomiting
GI Neurologic Infectious Drugs/Toxins Endocrine Miscellaneous
Functional disorders Head injury Bacterial toxins Digoxin Pregnancy Myocardial infarction
Psychogenic Stroke Pneumonia Aspirin Adrenal insufficiency Acute glaucoma
Irritable bowel Pseudotumor Spontaneous bacterial NSAIDs DKA Nephrolithiasis syndrome peritonitis
Obstruction Hydrocephalus Urinary tract infection Acetaminophen Parathyroid disorders Pain
DownlAodahdeesdio n2s025­7­1 5:50 MPa sYs oleusiro InP is 136Vi.r1u4se2s.159.127 Opiates Thyroid disorders Psychiatric
Chapter 72: Nausea and Vomiting, Bophal Sarha Hang; Jeffrey S. Ditkoff; Alex Koyfman; Brit Long disorders 
. Terms of Use * Privacy Policy * Notice * Accessibility
Esophageal Meningitis Adenovirus Alcohol Uremia Anorexia disorders nervosa
Achalasia Migraines Norwalk virus Theophylline Electrolyte disorders, especially Bulimia hyponatremia
Intussusception Labyrinthitis Rotavirus Chemotherapeutics Conversion disorder
Tumor Ménière’s Anticonvulsants Depression disease
Pyloric stenosis Motion Antibiotics sickness
Strangulated hernia Antiarrhythmics
Volvulus Hormones
Organic disorders Illicit drugs
Appendicitis Radiation therapy
Cholecystitis Toxins
Cholangitis Arsenic
Hepatitis Organophosphates
Irritable bowel Carbon monoxide disease
Mesenteric ischemia Ricin
Pancreatitis
Peptic ulcer disease
Peritonitis
HISTORY
Identify the onset and duration of the symptoms. The evaluation of acute conditions differs from a more chronic condition. For chronic conditions, understanding the scope of prior testing and treatment may help narrow the diagnostic possibilities. Chronic symptoms are defined as those symptoms present for >1 month.
Frequency of the episodes and interval between episodes are helpful to gauge the severity of illness. Timing, such as increased number of episodes in the morning, may suggest pregnancy or a CNS cause, whereas postprandial vomiting suggests a GI cause such as gastroparesis or gastric outlet obstruction.
The content of the vomitus may be helpful to determine whether an obstruction is present and its location. Esophageal disorders produce vomitus with undigested food particles. Bile is often associated with a small bowel obstruction, whereas vomitus composed of food particles and devoid of bile often represents a gastric outlet obstruction. Large bowel obstruction often is composed of feculent material and has a foul odor.
Because of the number of organ systems that are the potential cause of pathology, it is important to ask the patient about associated symptoms. The presence or absence of abdominal pain is a focal starting point. If pain is present, elicit its location and quality. Pain preceding the nausea and vomiting
 is most particularly associated with an obstructive process. Fever or, possibly, diarrhea suggests gastroenteritis. Ask about sick contacts or ingestion of food suspicious for a foodborne illness. A history of recent weight loss is associated with a malignancy or psychiatric component. Any CNS sign, such as headache, visual changes, vertigo, or neurologic deficits, may suggest a central cause for the nausea and vomiting. Obtain a thorough past medical and travel history. Prior abdominal surgery is a major risk factor for bowel obstruction from adhesions. Review the patient’s medication list to identify a medication with a common side effect of nausea and vomiting, such as NSAIDs, chemotherapeutic agents, antibiotics, various antihypertensives and antiarrhythmics, and oral contraceptives. Other medications at toxic levels are known to cause nausea and vomiting. Examples include acetaminophen, salicylates, and digoxin.
PHYSICAL EXAMINATION
Assess vital signs for hypotension and tachycardia. Observe skin turgor, mucous membrane hydration, and capillary refill to assess for dehydration. In children, the most useful predictors of significant dehydration (>5% loss of body weight) are abnormal capillary refill, abnormal skin turgor, absent
 tears, and abnormal respiratory pattern. The abdominal examination is particularly important to assess for an emergent problem, as well as to help
 narrow the differential diagnosis to a possible GI cause. Inspect, auscultate, and palpate the abdomen. (For further discussion of abdominal evaluation, see Chapter , “Acute Abdominal Pain.”)
Investigate any other important examination findings particular to various organ systems, as findings may provide valuable information regarding the cause of the nausea and vomiting (Table 72­2).
TABLE 72­2
Differential Diagnosis Based on Physical Examination Findings
Physical Examination Abnormal Signs or Symptoms Some Diagnostic Considerations
General Toxic appearing Dehydration
Generalized weakness Chronic malnutrition
Weight loss Malignancy
Vital signs Fever Infection (gastroenteritis, appendicitis, cholecystitis)
Tachycardia Bowel perforation secondary to peritonitis
Hypotension Severe volume depletion
Hypertension Intracranial hemorrhage or stroke
Head, eyes, ears, nose, Nystagmus Peripheral vs. central causes (benign positional vertigo, cerebellar infarct) throat
Exophthalmos Graves’ disease
Pinpoint pupils Opiate abuse
Acute glaucoma
Fixed­dilated pupil, eye pain
Dry mucous membranes Dehydration
Bulimia
Poor dental enamel, parotid gland Bulimia enlargement
Abdomen Distention, decreased bowel sounds, Small bowel obstruction, gastroparesis, gastric outlet obstruction, ileus surgical scars
Hernias or palpable masses Incarcerated hernia, tumors
Abdominal rigidity Peritonitis
Neurologic Mental status Dehydration, intracranial lesion or pathology, brainstem tumor, elevated
Cranial nerve findings or neurologic intracranial pressure deficits
Papilledema
Extremities Scarring on dorsal surface of the hands Bulimia
Skin Jaundice Hepatobiliary disease (hepatitis, choledocholithiasis)
Poor skin turgor Dehydration
Hyperpigmentation Addison’s disease
Decreased elasticity Scleroderma
Skin track marks Drug abuse/withdrawal
IMAGING AND ANCILLARY TESTING
Diagnostic testing in the ED depends on differential diagnosis raised by a detailed history and physical exam. Often, CBC and basic metabolic panel are part of the initial evaluation. However, liver function tests and lipase may be considered if the patient is presenting with signs of biliary obstruction or upper abdominal pain. A pregnancy test should be considered for all women of childbearing age. Further imaging with abdominal radiographs, CT scan, or US depends on the presentation and concern for acute intra­abdominal pathology. Head CT or brain MRI is ordered to evaluate for an intracranial mass or lesion.
TREATMENT
After initial evaluation of airway, breathing and circulation, focus on providing symptomatic relief (Table 72­3). Definitive management will often require disease­specific treatment. First­line supportive treatment should include fluid hydration with normal saline or lactated Ringer’s and may be sufficient for most patients. H histaminergic agents such as promethazine or a serotonin receptor antagonist such as ondansetron may also be

 helpful for initial treatment. However, promethazine is more sedating, with the potential side effect of vascular damage during IV administration.
Metoclopramide and prochlorperazine are also commonly used drugs in the ED. Patients given these drugs may develop akathisia up to  hours after
 administration. Studies comparing the efficacy of different drugs for treatment of nausea and vomiting in the ED report no definitive evidence to
,8 support the superiority of one drug over another or over placebo.
TABLE 72­3
Antiemetic Agents for the Treatment of Nausea and Vomiting
Medication Class Route Common Side Effects Comments
Antihistamines Drowsiness Also show efficacy in prevention of motion sickness. Useful for migraines and vertigo.
Dimenhydrinate PO Used in migraines and vertigo, which are vestibular in origin.
(Dramamine®) IV, IM,
Diphenhydramine PO
(Benadryl®)* PO
Meclizine
(Antivert®)
Benzodiazepines Sedation Adjunct for chemotherapy­induced nausea and vomiting.
Alprazolam PO
(Xanax®) PO, IV,
Diazepam PR
(Valium®) PO, IV,
IM
Lorazepam
(Ativan®)
Butyrophenones Agitation, restlessness, Treatment of acute chemotherapy­induced symptoms; can prolong QT .
c
Haloperidol PO, IM sedation
(Haldol®)* Corticosteroids Insomnia Used as an adjunct in severe cases of chemotherapy­induced nausea and vomiting;
Dexamethasone PO, IV, reduces prostaglandin formation.
IM
Serotonin Constipation, dizziness Well tolerated; all serotonin antagonists can prolong QT in electrolyte­ or drug­induced c antagonists PO, IV, or congenital long QT syndrome; uncommon side effects include headache; rare case c
Ondansetron SL reports of anaphylaxis.
(Zofran®)* PO, IV
Granisetron PO, IV
(Kytril®)* Dolasetron
(Anzemet®)* Phenothiazines Extrapyramidal Treatment in migraines, vertigo, and motion sickness; rare side effects include neuroleptic
Prochlorperazine PO, IV, symptoms,‡ sedation, malignant syndrome, blood dyscrasias, and cholestatic jaundice.
(Compazine®)† IM, PR orthostatic hypotension
Promethazine
PO, IV,
IM, PR
(Phenergan®)†
Benzamides Extrapyramidal Used in treatment of gastroparesis and children with reflux.
Metoclopramide PO, IV, symptoms,‡
(Reglan®) IM hyperprolactinemia
PO, IM
Trimethobenzamide
(Tigan®)
*QT interval prolongation reported.
†Nonspecific Q or T distortions reported.
‡
Extrapyramidal symptoms: dystonia, tardive dyskinesia, oculogyric crisis, parkinsonism.
ONDANSETRON
In the ED, serotonin receptor antagonists such as ondansetron have been first­line therapy for undifferentiated nausea and vomiting for all age
 groups. In 2011, the U.S. Food and Drug Administration issued a safety advisory for ondansetron due to concern for QT prolongation. Despite this
 warning, the clinical impact of QT prolongation associated with ondansetron use in the ED is unclear. There are a few pediatric case reports of
 cardiac death possibly associated with ondansetron use. In a recent pediatric study, the risk of ventricular arrhythmia was three in 100,000 patients
 and increased with underlying cardiac conditions. Thus, patients with congenital long QT syndrome, congestive heart failure, or bradyarrhythmias or taking concomitant medications that prolong QT interval are at risk, and cardiac monitoring should be instituted for this population. In addition, electrolyte abnormalities (e.g., hypokalemia or hypomagnesemia) should be corrected prior to administration of ondansetron. Consider ordering an
ECG prior to ondansetron administration for a patient with a history of cardiac disease.
GASTROPARESIS
PATHOPHYSIOLOGY
Gastroparesis is delayed gastric emptying in the absence of an obstructing lesion. This condition, which is typically chronic, is associated with
13­15 decreased quality of life and increased healthcare utilization, although it is not typically associated with significant mortality. The most common cause is idiopathic, but other causes include diabetes, bariatric and gastric surgery, viral illness, gastroesophageal reflux disease, and nonulcer
13­16 dyspepsia. Connective tissue or neurologic disease, and even pregnancy, can also be associated with gastroparesis. The incidence appears to be
16­18 increasing, especially in diabetics.
DIAGNOSIS
13­15
Symptoms of gastroparesis typically include early satiety, bloating, postprandial nausea, gastroesophageal reflux, vomiting, and abdominal pain.
If severe and chronic, patients may develop weight loss, electrolyte abnormalities, and nutritional or vitamin deficiencies. Physical examination may
13­15,19 reveal a succussion splash, which indicates excessive gastric fluid from delayed emptying or mechanical outlet obstruction. Significant
13­15,19 abdominal tenderness and peritoneal findings should be absent.
Initial investigations include serum electrolytes, liver function studies, serum lipase, and pregnancy test. If concern for mechanical obstruction is
 present, image with abdominal/pelvic CT. US has been used to diagnose gastroparesis and determine effectiveness of treatment. Outpatient
13­15 diagnostics include endoscopy, scintigraphy, electrogastrography, and assessment with the wireless motility capsule.
TREATMENT
Management includes volume resuscitation with electrolyte repletion. Several medications may be used for symptomatic treatment. Prokinetic agents include metoclopramide (dopamine antagonist,  to  milligrams) and erythromycin (motilin receptor agonist,  to 250 milligrams). Both agents may decrease symptoms and increase gastric emptying. Metoclopramide can decrease nausea, provide analgesia, and act as a prokinetic and is a first­line agent. Erythromycin may demonstrate tachyphylaxis and should be a second­line medication. Other medications include domperidone (a peripherally selective dopamine D receptor antagonist that is approved in Canada but, as of January 2018, not in the United States), diphenhydramine,
 prochlorperazine, and ondansetron. Opioids can treat pain; however, they may result in delayed gastric emptying and are not recommended for first­
13­15 line therapy.
Haloperidol can treat symptoms of nausea, vomiting, and pain. Haloperidol may be administered IV or IM. One study demonstrated a significant
 decrease in ED and hospital length of stay, hospital admission, and opioid administration, with no adverse events. A randomized controlled trial
 reported that haloperidol  milligrams IV significantly reduces pain and nausea. Patients whose symptoms improve are appropriate for discharge and follow­up with a primary care provider or gastroenterologist for further management.
CYCLIC VOMITING SYNDROME
PATHOPHYSIOLOGY
Cyclic vomiting syndrome usually presents in childhood, with more than half of cases resolving by the teenage years. The condition is rare in adults.
Predisposing mitochondrial DNA mutations (15519T and 3010A) have been found in many patients with cyclic vomiting syndrome. It is more common in females than males. In adults, there is a higher incidence of opiate and tobacco use.
The cause is unknown, but it is thought to be related to dysregulation of the neuroendocrine system. Accompanying symptoms of lethargy, anorexia, pallor, abdominal pain, or autonomic symptoms such as sweating and salivation implicate abnormal vagal tone. It has also been suggested that cyclic vomiting syndrome is a functional disorder associated with migraines. Patients commonly have a history of migraines and report a prodrome with
 nausea and photophobia prior to attacks.
DIAGNOSIS
Cyclic vomiting syndrome is characterized by recurrent nausea and vomiting separated by symptom­free periods. Since there is no specific confirmatory test for cyclic vomiting syndrome, diagnosis is clinical and involves excluding other common causes of symptoms. The diagnosis is often delayed for years after multiple ED visits and hospitalizations. Patients may be given the label of “drug­seeking.” Comorbid conditions may include anxiety, depression, and irritable bowel.
Cyclic vomiting syndrome has been well described with four phases: (1) asymptomatic periods of several or many months; (2) prodrome phase lasting minutes to hours, with lethargy, photophobia, anorexia, sweating, or salivation; (3) hyperemesis phase, which usually starts in the morning with severe nausea and vomiting, lasting for days to a week, with the mean duration being .4 days; and (4) finally, recovery phase with improvement in symptoms and energy levels.
The Rome III diagnosis criteria include recurrent episodes of intractable vomiting that are self­limiting, last less than  days, and do not have an organic cause. Typically, patients have more than two episodes of vomiting in the past year with symptom­free intervals in between.
TREATMENT
Management in the ED is symptomatic, with antiemetics (ondansetron), sedatives (lorazepam), analgesics, and IV fluids. For prophylaxis, patients can try to avoid triggers such as sleep deprivation, diet, and physical or emotional stress. Amitriptyline is the standard for medical prophylaxis and has shown response rates as high as 86%. Other therapies include migraine prophylaxis drugs such as sumatriptan, propranolol, and topiramate.
Mitochondrial­targeted therapies such as L­carnitine, coenzyme Q10, and riboflavin have shown excellent efficacy in combination with amitriptyline
 and alone.


