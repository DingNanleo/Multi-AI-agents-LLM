## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 93: Male Genital Problems
Jonathan E. Davis
INTRODUCTION
This chapter reviews the common acute infectious and structural or anatomic GU disorders. There are five GU emergencies: testicular torsion,
Fournier’s gangrene, paraphimosis, priapism, and significant GU trauma (see Chapter 265, “Genitourinary Trauma”). Related emergencies include strangulated inguinal hernia (see Chapter , “Hernias”) and ruptured abdominal aortic aneurysm (see Chapter , “Aneurysmal Disease”), both of which may present with scrotal pain. Chapter 136, “Pediatric Urologic and Gynecologic Disorders,” discusses urologic emergencies in children and adolescents.
ANATOMY
PENIS
Three cylindrical bodies—the corpus spongiosum, which surrounds the urethra, and the paired corpora cavernosa—form the shaft of the penis
(Figure 93­1). The corpora cavernosa are the major erectile bodies, extending distally from the pubic rami and capped by the glans penis. These cylindrical structures are encased in a thick tunic of dense connective tissue, the tunica albuginea. External to the tunica albuginea is Buck’s fascia, which fuses with Colles’ fascia at the level of the urogenital diaphragm. The internal pudendal artery provides the blood supply, which branches to form the deep and superficial penile arteries. Lymphatics drain from the penis into the deep and superficial inguinal nodes.
FIGURE 93­1. Cross­section of the penis.
SCROTUM
The prepubertal scrotal skin is thin and thickens with subsequent hormonal stimulation during puberty. Immediately beneath the skin are the smooth muscle and elastic tissue layers of Dartos’ fascia, similar to the superficial fatty layer (Camper’s fascia) of the abdominal wall. The deep membranous
 lCahyearp (tSecr a9r3p:a M’s afales cGiae)n oitfa tlh Pe raobbdleommsin, aJol wnaatlhl eaxnt eEn. dDsa invtiso the perineum, where it is referred to as Colles’ fascia, and forms part of the scrotaPl wagaell  / 
. Terms of Use * Privacy Policy * Notice * Accessibility
(Figure 93­2). The blood supply is derived primarily from branches of the femoral and internal pudendal arteries. Lymphatics from the scrotum drain into the inguinal and femoral nodes.
FIGURE 93­2. Anatomy of the scrotum and the testis. a. = artery; v. = vein.
TESTES
The testes average in size between  and  cm in length and  cm in width and depth and usually lie in an upright position, with the superior portion tipped slightly forward and outward. Each testis is encased in a thick fibrous tunica albuginea except posterolaterally, where it is in tight apposition with the epididymis. The enveloping tunica vaginalis covers the anterior and lateral aspects of the testes and attaches to the posterior scrotal wall.
Superiorly, the testes are suspended from the spermatic cord; inferiorly, the testis is anchored to the scrotum by the scrotal ligament (gubernaculum).
Maldevelopment with lack of firm posterior fixation of the tunica vaginalis leaves the testes and epididymis at risk for torsion about the spermatic cord.
The posterior (visceral) leaf of the tunica vaginalis is adherent with the tunica albuginea of the anterior testicular surface. A potential space exists between this visceral leaf and the anterior (parietal) tunica vaginalis. Any traumatic or inflammatory event can impede the normal parietal tunica vaginalis from absorbing viscerally secreted fluid, resulting in hydrocele formation anterior to the testes (Figure 93­3). Hematocele results from accumulation of blood in the potential space.
FIGURE 93­3. Embryonic retroperitoneal testis descends into the scrotum and invaginates into the tunica vaginalis, which anchors it to the posterior scrotal wall.
Note the potential space in the tunica vaginalis for development of a hydrocele.
The internal spermatic and external spermatic arteries provide the blood supply, traveling together in the spermatic cord. Venous return is primarily by the internal spermatic, epigastric, internal circumflex, and scrotal veins. The lymphatics drain toward the external, common iliac, and periaortic nodes.
EPIDIDYMIS AND VAS DEFERENS
The epididymis is a single, fine, tubular structure approximately  to  m long compressed into an area of about  cm. It serves to promote sperm maturation and motility. Vestigial embryonic structures, the appendix epididymis and the appendix testis, which have no known physiologic function, are often associated with the testes and epididymis. The appendix epididymis is found attached to the head of the epididymis, or globus major. The appendix testis, a pear­shaped structure, is usually situated on the uppermost portion of the testis at the junction of the testis and the globus major of the epididymis, although anatomic variation exists.
The vas deferens is a distinct muscular tube that is easily palpable within the scrotal sac. It extends cephalad in the spermatic cord from the tail of the epididymis (globus minor), traverses the inguinal canal, and crosses medially behind the bladder over the ureters to form the ampullae of the vas, where it joins with the seminal vesicles to form the paired ejaculatory ducts in the prostatic urethra.
PROSTATE
The prostate originates from the urogenital sinus at approximately the third month of embryonic life. It is continually enlarging and, in the young male, is often not definable on rectal examination. As a man matures, the prostate may enlarge dramatically, resulting in significant bladder outlet obstruction. The anterior, median, posterior, and lateral lobes define the divisions of the prostate.
PHYSICAL EXAMINATION
The GU examination should be performed with the male patient in both the supine and upright positions in a well­illuminated, warm room if feasible.
In uncircumcised males, fully retract the foreskin to inspect the glans, coronal sulcus, and preputial (foreskin) areas for ulceration or lesions. Note the location of the urethral meatus and presence of discharge. Replace the foreskin to its native position following examination to prevent iatrogenic paraphimosis. Carefully palpate the penile shaft for skin or subcutaneous lesions.
Testicular nodularity or firmness should be considered carcinoma until proven otherwise. The epididymis usually lies on the posterolateral aspect of the testis and has a soft, fleshy feel similar to that of the earlobe. Many males experience pain and tenderness with palpation of a normal globus major
(head), body, and globus minor (tail) of the epididymis. Males experience some discomfort during palpation of a normal prostate, and a lateral supine position helps prevent an infrequent vasovagal response. The prostate has a heart­shaped contour, with its apex located more distally, abutting the urogenital diaphragm. The consistency of the normal prostate has the same resiliency as the cartilaginous tip of the nose, whereas suspicious carcinogenic areas feel more like the bony prominence of the chin. The posterior lobe is small and thin, allowing palpation of the median raphe that distinguishes the two lateral lobes. A rectal prostate examination cannot assess the anterior or median lobes. The seminal vesicles, lying just superior to the prostate, cannot normally be distinguished unless there is inflammation, induration, or enlargement.
Examination of the inguinal canals for hernias and the scrotal spermatic cords for varicoceles is best done in the upright position, with the patient straining at the designated time. When the patient is upright, it should be determined whether the testes are aligned along a vertical or horizontal axis.
Horizontally aligned testes are at greater risk for torsion. Likewise, an elevated, horizontally aligned testis may be the result of torsion.
DISORDERS OF THE SCROTUM
An acute scrotum is defined as acute pain or painful swelling of the scrotum or its contents, accompanied by local signs or general symptoms.
Testicular torsion and Fournier’s gangrene are the most time­sensitive diagnoses of the acute scrotum; the first priority in the evaluation of patients with scrotal pain is differentiation of these life­ or testicular­threatening disorders from other entities.
SCROTAL EDEMA

Insect bites and contact dermatitis may cause scrotal edema, or it may be idiopathic. In the setting of hypoalbuminemia, or anasarca from any cause, contiguous scrotal and penile edema may occur. Idiopathic scrotal edema presents as unilateral or bilateral mild pain with scrotal, perineal, and
 inguinal swelling and erythema, most commonly in boys between  and  years of age. US findings include an easily compressible thickened scrotal
,3 wall (mean .2 mm), increased peritesticular blood flow, and in some cases, a reactive hydrocele. Episodes resolve in  to  days with scrotal
 elevation, rest, and NSAIDs, although recurrences occur. Fever, increased warmth, or purulence suggests cellulitis; see Chapter 152, “Soft Tissue
Infections.”
SCROTAL ABSCESS

Management of a scrotal abscess depends on its depth. In the case of a simple hair follicle abscess, the phlegmon is localized to the scrotal wall. A superficial abscess should be differentiated from a deeper abscess involving or originating from infection in one of the primary intrascrotal organs
(i.e., testis, epididymis, or bulbous urethra). This distinction is difficult late in the course of the infection when a general scrotal mass may be the only physical finding. US can determine contiguous involvement of an inflammatory mass in the testis or epididymis with the scrotal skin. A retrograde urethrogram will delineate the integrity of the urethra. Early Fournier’s gangrene should also be considered in patients with systemic symptoms or gas in the tissues (see section below).

A simple hair follicle scrotal wall abscess is managed by incision and drainage. If abscess of deeper structures cannot be ruled out clinically or with US, consult urology for definitive management. Antibiotics are rarely needed in an immunocompetent male unless there are signs of cellulitis or systemic involvement.
FOURNIER’S GANGRENE
Fournier’s gangrene is a polymicrobial, synergistic, infective necrotizing fasciitis of the perineal, genital, or perianal anatomy. While classically
6­8 occurring in men  and older, women account for 10% to 25% of cases. This process typically begins as a benign infection or simple abscess that quickly becomes virulent, especially in an immunocompromised host, and results in microthrombosis of the small subcutaneous vessels, leading to
 the development of gangrene of the overlying skin (Figure 93­4).
FIGURE 93­4. A patient with Fournier’s gangrene of the scrotum. Note the sharp demarcation of gangrenous changes (black portion) and the marked edema of the scrotum and the penis.

Patients with diabetes (32% to 66%) and alcohol abuse (25% to 50%) are disproportionately affected with Fournier’s gangrene. Mortality rates
,13 ,7,8,14­16 have historically varied from 3% to 67%, but contemporary estimates range from 12% to 30%. Age over  and complications during
,16 treatment are the most important predictors of death.
CLINICAL FEATURES AND DIAGNOSIS
,10
Early symptoms include genital or peritoneal pain (65%), often with pruritus and a prodrome of lethargy and fever (but may be afebrile on arrival).
,10
This is followed by swelling (65%) and erythema (35%). As many as 40% of patients will initially have no clear localized symptoms but experience
 pain. In advanced Fournier’s gangrene, the local signs and symptoms are usually dramatic, with crepitus and ecchymosis of the inflamed tissues.
Prompt recognition of Fournier’s gangrene in its early stages may prevent extensive tissue loss that accompanies delayed diagnosis or treatment.
Imaging should not delay urologic consultation or treatment. Bedside US may show scrotal wall thickening, and “dirty shadowing,” suggesting air in
,18  the tissues. CT reveals extent of the disease.
TREATMENT
Treat with aggressive fluid resuscitation and gram­positive, gram­negative, and anaerobic antibiotic coverage (see also Chapter 151, “Sepsis”).
Recommended agents include piperacillin­tazobactam, .375 to .5 grams IV every  hours, or imipenem,  gram IV every  hours, or meropenem, 500
,20,21 ,13 milligrams to  gram IV every  hours, plus vancomycin. Urgent urologic consultation is required for wide surgical debridement. The addition of clindamycin, 600 to 900 milligrams IV every  hours, or metronidazole,  gram IV, then 500 milligrams IV every  hours, to the antimicrobial regimen
,13  may be of benefit. Hyperbaric oxygen therapy in the pre­ and postoperative setting is a treatment option but does not improve mortality.

Admission to the intensive care unit postoperatively is typically required.
DISORDERS OF THE PENIS
Ischemic priapism, paraphimosis, and entrapment injuries are priority diagnoses that, if left untreated, can result in necrosis of the penis.
BALANOPOSTHITIS
Balanitis (inflammation of the glans penis), posthitis (inflammation of the foreskin), and balanoposthitis (inflammation of the glans and the foreskin) are primarily caused by inadequate hygiene or external irritation with subsequent colonization with Candida species, Staphylococcus species,

Streptococcus species, and less commonly, Mycoplasma genialium. Infections frequently show mixed flora. On examination, when foreskin retraction is attempted, the glans and apposing prepuce appear purulent, excoriated, malodorous, and tender. Balanoposthitis can be the sole
  presenting sign of diabetes. Consider Candida, Gardnerella, and anaerobes as potential causes. Treatment consists of cleansing the area with saline, ensuring adequate dryness after cleaning, application of antifungal creams (nystatin or clotrimazole), treatment with an oral azole in severe
 cases (fluconazole, 150 milligrams orally), and circumcision for recurrent cases. Soap may increase inflammation during the acute phase, but routine hygiene is essential to prevent recurrence. Bacterial infection is suggested by warmth, erythema, and edema of the glans, foreskin, and penile shaft;
 anaerobic organism is suggested by foul smell. If these signs are present, oral clindamycin, 300 milligrams three times per day for  days, or
,26 metronidazole, 500 milligrams two times per day for  days, is recommended. Cases that persist warrant culture for potential infective causes or biopsy and follow­up with urology.
PHIMOSIS
Phimosis is the inability to retract the foreskin proximally and posterior to the glans penis (Figure 93­5). Physiologic phimosis occurs naturally in uncircumcised newborns. By  years of age, fewer than 10% of foreskins remain nonretractile, with nearly all becoming retractile by late adolescence.
Infection, poor hygiene, and previous preputial injuries with scarring are common causes of pathologic phimosis. Scarring at the tip of the foreskin can occlude the preputial meatus, infrequently causing urinary retention. Hemostatic dilation of the preputial ostium will temporarily relieve the urinary retention. Circumcision is curative. Alternatively, topical steroid treatment (such as betamethasone, .05% to .10% twice daily) applied from the tip of the foreskin to the glandis corona for  to  months, along with daily manual preputial retraction, has been shown to be an effective nonsurgical
 management option for phimosis.
FIGURE 93­5. Phimosis and paraphimosis.
PARAPHIMOSIS
Paraphimosis, a true urologic emergency, is the inability to reduce the proximal edematous foreskin distally over the glans penis into its natural position (Figure 93­5). The resulting glans edema and venous engorgement can progress to arterial compromise and gangrene.
Paraphimosis can often be reduced by compression of the glans for several minutes to reduce edema and allow for successful reduction of the now smaller glans through the foreskin. Tightly wrapping the glans with a 2­inch elastic bandage for  minutes will reduce edema. Topical

EMLA® cream (2.5% lidocaine and .5% prilocaine) reduces the pain of the wrapping and reduction. The patient may also benefit from an anxiolytic.
The thumbs of the operator should be placed on the glans pushing proximally while the fingers distributed circumferentially on the foreskin pull
 distally over the glans. If these methods are unsuccessful, local infiltration of the constricting band with 1% lidocaine without epinephrine followed
 by superficial dorsal incision of the band will allow foreskin reduction. US can be used to perform a dorsal penile nerve block. Use of an iris scissor may help prevent damage to underlying tissue. The examining provider should perform this procedure in cases of impaired perfusion to the glans, unless a urologist is immediately available.
ENTRAPMENT INJURIES
Circumferential objects surrounding the penis can occlude the veins and, subsequently, the arterial blood supply. Hair, string, metal rings, and wire
 have been wrapped around the penis for accidental, experimental, or sexual reasons. Removing the offending object requires care and ingenuity.

Removal techniques include compression and cooling the penis, cutting the object, and urologic surgical removal. Lubrication with petroleum jelly may assist. Ice packs can help decrease inflammation and edema, but take care to avoid cooling injury. The compression technique uses the same modified string method recommended for removing finger rings, with the addition of inserting an 18­gauge needle into the end of one of the two corpora cavernosa through the glans to allow edema and blood to be pushed out by the proximal to distal compression of the penis. Start by inserting the short end of the tape under the constriction device to be left proximally, while the long end is used to compress the penis winding in a proximal to
,32 distal direction. Cutting devices can remove penile rings. Protect underlying skin with a hard object, preferably metal. Also avoid overheating the
 surrounding tissues. Urologic consultation may be required depending on the entrapment complexity and physiologic concerns.
The penile hair­tourniquet syndrome (Figure 93­6) seen in young males presents with swelling of the glans. The offending hair may be invisible within the edematous coronal sulcus. Several common techniques for removal consist of unwinding the hair, lancing the hair when easily accessible,
 or surgical removal when circumferential edema prevents access to the constricting source.
FIGURE 93­6. Hair is entrapped behind the coronal sulcus (arrow), constricting and progressively amputating the glans.
Another common entrapment injury is penile or scrotal entrapment in a zipper. The reported interventions include dismantling the zipper with wire cutters or trauma shears and surgical interventions such as circumcision. First, cleanse the affected area with povidone­iodine and provide local anesthesia with 1% to 2% lidocaine. Next, try coating the zipper and affected area with mineral oil or other nontoxic lubricant. If this does not free the
 zipper, cut the zipper away from clothing to make the zipper easier to handle. Next, try cutting the sliding bar of the zipper and the zipper teeth. The bottom bar of the zipper apparatus can also be cut and then unzipped from below.
FRACTURE OF THE PENIS

A penile fracture occurs when the tunica albuginea of one or both corpus cavernosa ruptures due to direct trauma to the erect penis. It can be
,36 associated with partial or complete urethral rupture (9% to 18%) or deep dorsal vein injury. The most common cause is sexual intercourse, but
,37 other causes include animal bites, stabbing, bullet wounds, and self­mutilation. On examination, the penis is acutely swollen but flaccid, discolored, and tender. A retrograde urethrogram may be necessary to ensure urethral integrity, but radiologic evaluation rarely influences surgical
  managment. If the clinical diagnosis is in doubt, US is recommended to assess for rupture of the tunica albuginea. Surgical treatment consists of
,39 hematoma evacuation and suture apposition of the disrupted tunica albuginea. Surgery within  hours is recommended to minimize dysfunction.
PEYRONIE’S DISEASE
Peyronie’s disease is a fibrotic disorder of the tunica albuginea. The fibrosis produces progressive penile curvature and painful erections, yielding
 erectile dysfunction or unsuccessful vaginal penetration during intercourse. Examination of the penile shaft will disclose a thickened plaque,
 typically on the dorsum, involving the tunica albuginea of the corpora bodies. Outpatient urologic referral is warranted.
PRIAPISM
Priapism is a urologic emergency that is characterized by persistent, usually painful, pathologic erection in which both corpora cavernosa are
 engorged with stagnant blood. Even though the glans penis and the corpus spongiosum are characteristically soft and uninvolved, urinary retention may develop. Impotence follows in 35% of cases with sustained erections for prolonged periods, so emergency urologic consultation is needed.
Many cases of priapism in adults are pharmacologically related to intracavernosal injection of vasoactive substances for impotence (papaverine, prostaglandin E ), use of oral agents for hypertension (hydralazine, prazosin, calcium channel blockers), neuroleptic medications (chlorpromazine,

 trazodone, thioridazine), or oral agents related to erectile dysfunction. Most cases of priapism in children are due to hematologic disorders, usually sickle cell disease.
Priapism is classified into ischemic priapism (veno­occlusive, low­flow) and nonischemic priapism (arterial, high­flow). Stuttering priapism is a recurrent subset of ischemic priapism. Nonischemic priapism is uncommon, most often painless, and usually results from traumatic fistulae between the cavernosal artery and the corpus cavernosum. Blood gas analysis of the first corporal aspirate is recommended to differentiate nonischemic from
 ischemic priapism. Nonischemic priapism may be further delineated by color Doppler US (increased flow) and is treated by nonurgent
 embolization. Ischemic (low­flow) priapism is more common, is usually quite painful, and is characterized by the aspiration of dark acidic intracavernosal blood from the corpus cavernosum. Color Doppler US shows absence of the normal arterial waveform in the corporal arteries, but
 imaging should not replace blood gas analysis for the diagnosis of ischemic priapism. Provide adequate narcotic analgesia early on in the evaluation process.
ASPIRATION AND IRRIGATION OF CORPORA CAVERNOSA
Corporal aspiration, irrigation, and α­adrenergic agonist (i.e., phenylephrine) injection are the primary treatment methods for persistent priapism.
Ketamine, .5 milligram/kg per dose for up to four doses, may yield detumescence when narcotic medication fails to resolve priapism and provides
 procedural sedation for aspiration and irrigation. A ring block, using lidocaine 1% without epinephrine, injected around the base of the penis can be delayed until procedural sedation has been established. Because of the sinusoidal network in the corporal cavernosa, blood can be aspirated and the space irrigated once the needle fully enters the cavernous body. The introduction of vasoactive or other agents into the corpora may precipitate systemic effects, particularly as partial detumescence is achieved.
The urologic consultant usually performs the aspiration, but the examining provider may need to intervene. On each lateral side of the proximal penis, raise a wheal with 1% lidocaine using a 27­gauge needle. After local anesthesia, insert a 19­gauge (or 18­gauge) butterfly needle into the corpora cavernosa on each side, approximately .5 cm deep. The needle must penetrate the skin, subcutaneous tissue, and the tunica albuginea in order to enter the corpus cavernosum. The needles can be supported in place by using a combination of small gauze pads on either side of the “butterfly
 wings” and roller gauze around the penis to secure its position. Blood is typically aspirated from each side. Send first aspiration for blood gas analysis. In 15­ to 25­mL aliquots, aspirate until bright red blood returns. Instill up to  mL of cold sterile saline into each side, pause  to  minutes, then aspirate, and repeat. If priapism persists, dilute phenylephrine to 100 micrograms/mL and inject 100 micrograms every  minutes as needed, up
 to a maximum dose of  milligram. If this fails to produce detumescence, surgery may be required. If priapism due to sickle cell crisis fails to respond to adequate analgesia and hydration, consult both urology and hematology. Penile aspiration and irrigation, with or without instillation of adrenergic
 agonists, is recommended for acute ischemic priapism in sickle cell patients.
PENILE CARCINOMA
Carcinoma of the penis is rare, usually appearing in the fifth or sixth decade in an uncircumcised male. Carcinoma may appear as a nontender ulcer or warty growth beneath the foreskin in the area of the coronal sulcus or glans penis and is often hidden by an inflamed phimotic foreskin.
DISORDERS OF THE TESTES AND EPIDIDYMIS
TESTICULAR TORSION
The differential diagnosis of acute scrotal pain includes testicular torsion, torsion of the testicular appendages, epididymitis, incarcerated hernia, and trauma, among others. Frequent causes of acute scrotal pain include testicular torsion or epididymitis in adults, with the added possibility of appendage torsion in children (Table 93­1). Because of the potential for infarction and infertility, testicular torsion must be the primary consideration in acute scrotal pain. Testicular torsion presents in a bimodal age distribution, with extravaginal torsion occurring in the perinatal period and
,47 intravaginal torsion peaking during puberty.
TABLE 93­1
Differential Diagnosis of Acute Scrotal Pain
Testicular Torsion Epididymitis Appendage Torsion
Historical Features
Peak incidence Neonates, adolescents Adolescents, young adults Prepubertal
Risk factors Undescended testicle (neonate), rapid increase in Sexual activity/promiscuity, GU Presence of appendages testicular size (adolescent), failure of prior orchiopexy anomalies, GU instrumentation
Pain onset Sudden Gradual, progressive Variable
Nausea/vomiting More likely Less likely Less likely
Dysuria Less likely More likely Less likely
Physical Findings
Fever Less likely More likely, particularly in Less likely advanced disease (epididymoorchitis)
Location of Testicle, progressing to diffuse hemiscrotal involvement Epididymis, progressing to diffuse Localized to head of swelling/tenderness hemiscrotal involvement affected testicle or
(early) epididymis
Cremasteric reflex Testicular torsion less likely if present May be present or absent May be present or absent
Testicle position High riding, transverse alignment Normal position, vertical alignment Normal position, vertical alignment
Torsion of the testis or spermatic cord results from abnormal fixation of the testis within the tunica vaginalis. This allows the testis to twist, especially after episodes of minor trauma and during periods of testicular growth such as puberty. Torsion usually occurs in the absence of a preceding event; only a small percentage occurs due to associated trauma. Torsion may occur during sleep, when unilateral cremasteric muscle contraction results in twisting of the testis. Inadequate fixation of the tunica vaginalis to the posterior scrotal wall (bell­clapper deformity) places the testis at risk for torsion.
A testis aligned along a horizontal rather than a vertical axis is at particular risk.
CLINICAL FEATURES
Patients usually complain of acute severe pain, usually felt in the lower abdominal quadrant, the inguinal canal, or the testis. Although the pain may be constant or intermittent, it is not positional in nature, because testicular torsion is primarily an ischemic event that becomes inflammatory only after
 the testis has infarcted. The presence of vomiting makes the diagnosis of testicular torsion more likely.
When examined early, the involved testis is firm, tender, and often higher than the contralateral testis and frequently with a
 transverse lie. The epididymis may be displaced and not found in its normal posterolateral position. The most sensitive finding in excluding
 testicular torsion is the unilateral presence of the cremasteric reflex, but the sensitivity ranges from 73% to 96%. The absence of an ipsilateral cremasteric reflex is a nonspecific finding and may be associated with scrotal inflammation from any cause. Relief of pain with elevation of the affected testicle (Prehn’s sign–positive for epididymitis) does not reliably distinguish torsion from epididymitis.
DIAGNOSIS
In obvious cases of testicular torsion, the diagnosis is made clinically to facilitate emergent urologic consultation and surgical exploration. Excellent salvage rates are expected with <6 hours of symptoms, but salvage declines rapidly thereafter. There are no readily available clinical or laboratory parameters to judge the degree or duration of testicular ischemia. Therefore, no matter how long the patient has been symptomatic, a rapid evaluation, including emergency scrotal exploration if necessary, should be performed. Doppler US is the diagnostic imaging modality of choice to evaluate patients with equivocal clinical presentations. US is considered “positive” for testicular torsion when ipsilateral intratesticular blood flow is absent or clearly reduced, and “negative” when flow is normal or increased. Older duplex US studies report sensitivities ranging from 69% to 90% and
  specificities ranging from 98% to 99% for testicular torsion ; however, a 2013 prospective study found a sensitivity of only 83%. Importantly, partial torsion may reveal falsely reassuring blood flow in an ischemic testicle. Likewise, normal or increased flow may be seen in a high­risk testicle following spontaneous detorsion. Grayscale US imaging of the spermatic cord itself assessing for coils or kinks may aid in diagnosis. US has the advantage of
 demonstrating scrotal anatomy, which may indicate an alternative diagnosis. Even after negative imaging, consultation with a urologist should be considered when an alternative diagnosis cannot be found because physical examination and Doppler US are not 100% sensitive or specific.
TREATMENT
For emergency or preoperative treatment, consider manual detorsion of the affected testis, which has been shown to be successful in as many as 76%
 of cases. Explain to the patient that detorsion is a painful procedure, but that successful detorsion will help to relieve the presenting pain. Most testes
 twist in a lateral to medial fashion (two thirds of cases); therefore, detorsion initially should be done in a medial to lateral motion. Detorsion is typically done in a manner similar to opening a book (Figure 93­7A). If one were to stand at the patient’s feet, the patient’s right testis would be rotated in a counterclockwise fashion and the patient’s left testis in a clockwise fashion (Figure 93­7B). The initial attempt should include one and one­half rotations (540 degrees). Any relief of pain is a positive end point, and the success of the maneuver can be assessed with Doppler US, demonstrating restoration of blood flow. An occasional patient will require manipulation beyond the initial one and one­half rotations. A worsening of the patient’s pain suggests that detorsion should then be done in the opposite direction (one third of cases). Successful detorsion converts an emergent procedure to an elective one; however, the decision for timing of surgery is the decision of the surgeon. Final management of testicular torsion is surgical fixation by the urologist.
FIGURE 93­7. Testicular detorsion. This procedure is best done standing at the foot of or on the right side of the patient’s bed. A. The torsed testis is detorsed in a fashion similar to opening a book. B. The patient’s right testis is rotated counterclockwise, and the left testis is rotated clockwise. [Reproduced with permission from Strange GR, Ahrens WR, Schafermeyer RW, et al: Pediatric Emergency Medicine, 3rd ed. © 2009, McGraw­Hill, Inc., New York, NY, p.
679.]
APPENDAGEAL TORSION
The four testicular appendages—appendix testis, appendix epididymis, paradidymis (organ of Giraldes), and vas aberrans—have no known physiologic function. These pedunculated structures are capable of torsion and, in prepubertal boys (median age,  to  years), probably twist more
 often than the testes in children. Presenting symptoms, although similar to testicular torsion, classically lack the systemic symptoms of nausea and
  vomiting. Leukocytosis is usually absent. If the patient is seen early, with the pain localized to the upper pole of the testis or epididymis, a blue spot may be observed through the scrotal skin—the “blue dot sign.” This “sign” is considered pathognomonic for torsion of the appendix testis but is infrequently seen. If the diagnosis can be ensured and normal intratesticular blood flow to the involved testis is confirmed by color Doppler US, surgical exploration is not necessary. Torsion of an appendage is usually self­limiting and best managed with analgesics, bed rest, supportive underwear, and reassurance, with the expected symptom resolution within  to  days. If late in the process and testicular swelling is present, or if the color Doppler US is equivocal, then urologic consultation and surgical exploration are needed to exclude testicular torsion.
EPIDIDYMITIS
The onset of pain in epididymitis or epididymo­orchitis is usually gradual. Bacterial infection is the most common cause. Unless high­risk sexual
 behavior can be ruled out, sexually active men should be treated with regimens that cover Gonorrhea and Chlamydia. Consider coliform infection of the lower urinary tract in addition to the more common sexually transmitted infection organisms in the setting of anal insertive intercourse. In older men, epididymitis is commonly caused by urinary pathogens, such as Escherichia coli and Klebsiella, or sexually transmitted infections depending on risk factors. In elderly men with epididymitis and urinary tract infection, consider associated benign prostatic hypertrophy or urethral stricture. Large residual urine volume (>50 to 100 mL urine) suggests outlet obstruction as the cause of the patient’s infection (see Chapter , “Acute Urinary
Retention”).
CLINICAL FEATURES AND DIAGNOSIS
Epididymitis may cause lower abdominal, inguinal canal, scrotal, or testicular pain alone or in combination. The retrograde progression of infection from the prostatic urethra to the epididymis explains the location and progression of pain. Epididymitis represents a more advanced GU tract infection when compared with urethritis. Patients with epididymitis are more prone to lower urinary tract voiding discomfort and may note transient pain relief in the recumbent position with scrotal elevation. Initially, isolated firmness and nodularity of the affected globus minor are noted on examination. As the disease progresses, the sulcus between the epididymis and testis becomes obliterated, and the inflammatory epididymal mass may become contiguous with the testis, producing a large, tender scrotal mass (epididymo­orchitis) that may be difficult to differentiate from testicular torsion or abscess.
Urinalysis may show pyuria in about half of patients. Consider referral for testing for other sexually transmitted infections in the setting of risk features. Obtain urine culture in children and elderly men. Adjunctive diagnostic modalities, such as color flow duplex Doppler sonography or radionuclide scintigraphy, will demonstrate increased or preserved blood flow to the testes. A reactive hydrocele may be seen on US.
TREATMENT
56­59
Most cases of epididymitis can be managed with oral antibiotics (Table 93­2). Although the 2015 Centers for Disease Control and Prevention recommendations direct the coverage of sexually transmitted infections based on an age cut­point of  years, recent studies suggest sexually
,59 transmitted infections associated with epididymitis occur in all sexually active age groups. Therefore, antibiotic treatment should cover sexually transmitted infections unless the care provider can reliably exclude these infections. Admission criteria for epididymitis include fever and clinical toxicity, which can be indicative of epididymal or testicular abscess formation. The ambulatory patient should wear a scrotal supporter, being careful not to lift heavy objects or strain when having a bowel movement, both of which will increase intra­abdominal pressure and exacerbate the
 inflammatory cycle. The need and urgency for follow­up care depend on illness severity and comorbidities. A patient with severe epididymitis not requiring admission should be seen by a urologist in  to  days; patients with milder cases can be reevaluated at  to  days with primary care for clinical improvement and decisions regarding work limitations (i.e., a sedentary worker would be able to return to work sooner than a physical
 laborer).
TABLE 93­2
Empiric Outpatient Treatment of Epididymitis and Epididymo­Orchitis
For acute epididymitis most likely caused by sexually transmitted chlamydia or gonorrhea
Ceftriaxone,* 250 milligrams IM single dose, plus doxycycline,* 100 milligrams PO twice a day for  d
For acute epididymitis most likely caused by sexually transmitted chlamydia, gonorrhea, or enteric organisms (men who practice insertive anal sex)
Ceftriaxone,* 250 milligrams IM single dose, plus doxycycline,* 100 milligrams PO twice a day for  d
Also treat for gram­negative bacilli with:
Levofloxacin, 500 milligrams PO every day for  d or
Ofloxacin,† 300 milligrams PO twice a day for  d
For acute epididymitis most likely caused by enteric organisms
Levofloxacin, 500 milligrams PO every day for  d or
Ofloxacin,† 300 milligrams PO twice a day for  d
*European Association of Urology Guidelines recommend 500 milligrams of ceftriaxone IM and 200 milligrams of doxycycline as first dose.
†Ofloxacin is not currently available in the United States or Canada.
ORCHITIS
Isolated orchitis, or inflammation of the testicle, is quite rare and usually occurs in conjunction with other systemic infections, such as mumps or other viral illnesses (coxsackie virus, Epstein­Barr virus, varicella, or echovirus). Mumps orchitis presents with unilateral involvement in 70% of cases, followed by contralateral involvement in  to  days. Bacterial orchitis is almost always associated with epididymitis. Orchitis in immunocompromised patients can be due to mycobacteriosis, cryptococcosis, toxoplasmosis, or candidiasis. Patients with orchitis usually present with testicular tenderness and swelling of a few days in duration. The diagnosis is primarily clinical using history and physical examination, but US can assist in excluding testicular torsion or abscess. Treatment for acute episodes starts with antibiotic coverage as listed earlier for epididymitis; IV antibiotics should be
,57 considered for patients with systemic features. Immunocompromised patients or patients with risks for tuberculosis (exposure, uncontrolled human immunodeficiency virus, or diabetes) require further evaluation and, in some cases, admission if they have abnormal vital signs. Some patients can alternatively be referred to urology and/or infectious disease for further management.
TESTICULAR MALIGNANCY
The hallmark of testicular carcinoma is an asymptomatic testicular mass with firmness or induration. Ten percent of tumors will present with pain secondary to acute hemorrhage within the tumor, which may be mistaken for orchitis. Metastatic testicular tumors can be insidious and must be suspected in any male with unexplained supraclavicular lymphadenopathy, abdominal mass, or chronic nonproductive cough from a lung metastasis.
Testicular examination may disclose a primary tumor. Any unexplained testicular mass must be approached as a possible tumor with urgent urologic referral.
ACUTE PROSTATITIS
CLINICAL FEATURES AND DIAGNOSIS
Acute prostatitis is bacterial inflammation of the prostate gland. Patient complaints can include irritative or obstructive symptoms such as low back pain; perineal, suprapubic, or genital discomfort; lower urinary tract voiding symptoms; frequency or dysuria; perineal pain with ejaculation; and fever or chills. Risk factors include anatomic or neurophysiologic lower urinary tract obstruction, acute epididymitis or urethritis, anal receptive intercourse, phimosis, intraprostatic ductal reflux, and indwelling urethral catheter or condom drainage. The causative organism is E. coli in most cases, with other uropathogens such as Pseudomonas, Klebsiella, Enterobacter, Serratia, Enterococcus, or Proteus causing the remainder. In contrast to acute prostatitis, chronic bacterial prostatitis is characterized by prolonged or recurrent symptoms and relapsing bacteriuria.
Physical exam findings include perineal tenderness, rectal sphincter spasm, and prostatic tenderness or bogginess. The diagnosis is clinical, because urinalysis and urine culture may both be negative. Prostatic massage is not necessary to make the diagnosis and, in acute prostatitis, may precipitate
60­62 bacteremia or sepsis. Obtain urethral cultures or first­void urine for gonorrhea and chlamydia testing in men younger than  years who are sexually active and in men older than  years who engage in high­risk sexual behavior. While imaging is not routinely needed, patients with signs of
 toxicity or those with voiding difficulty and symptom duration longer than  days are at greater risk for an associated abscess of the prostate.
TREATMENT

Initial treatment is fluoroquinolone antimicrobial therapy for  weeks, such as ciprofloxacin, 500 milligrams orally twice daily for  days, with plan for primary care reevaluation at  weeks for possible continued therapy as needed. Double­strength trimethoprim­sulfamethoxazole, one tablet PO twice a day, is an alternative, although cure rates may be lower than for the fluoroquinolones. Fosfomycin,  grams daily for  days followed by  grams
 every  hours for  weeks, has been successful in treating patients with prostatitis caused by multidrug­resistant E. coli. Consider treating for sexually transmitted infection organisms in younger patients or older patients with sexually transmitted infection risk factors; give ceftriaxone, 250 milligrams IM as a single dose, plus doxycycline, 100 milligrams PO twice a day for  days. Patients frequently require pain medication.
Most patients can be treated as outpatients. Patients with abnormal vital signs or other systemic symptoms should be admitted and given a broad­
,61 spectrum antibiotic such as piperacillin­tazobactam, .375 to .5 grams IV, combined with an aminoglycoside. If associated with urinary retention, urology consultation is needed. Urologic follow­up should be provided for discharged patients to ensure eradication of infection and to provide continuity of care in case of relapse. Chronic prostatitis is managed with urine cultures, long­term antibiotics targeted to culture results, antiinflammatory medications plus α­blockers for nonbacterial chronic prostatitis, and urology follow­up.
DISORDERS OF THE URETHRA
For discussion of urethritis, see Chapter 153, “Sexually Transmitted Infections.” For options regarding the management of obstructed urinary flow, possibly caused by urethral strictures, see Chapter , “Acute Urinary Retention.”
URETHRAL FOREIGN BODIES
Patients of all ages, but especially young children, may be victims of innocent urethral exploration or attempts to heighten sexual experiences by using
 a variety of foreign bodies such as bobby pins; long, thin paintbrushes; or ballpoint pens. Bloody urine combined with infection and slow, painful urination should suggest a possible foreign body in the lower urinary tract. A radiograph of the bladder and urethral areas may disclose the presence of a radiopaque foreign body.
Foreign bodies often require cystoscopic removal or even open cystotomy. Occasionally a gentle milking action of the proximal end of the urethral foreign body by an experienced examiner will allow its retrieval from the distal urethral meatus. Even then, retrograde urethrography or endoscopic confirmation of an intact urethra is indicated.
HEMATOSPERMIA

Hemospermia, or hematospermia, is a disturbing symptom that produces extreme anxiety in sexually active males. The incidence and prevalence of this condition are not known. Most symptomatic men seek medical attention after one or two occurrences. Any process that results in trauma or other
 injury (e.g., tumor with erosion), inflammation, or infection of the male ejaculatory system may result in bloody semen. It is not uncommon after vigorous sexual activity. Unless the cause can be determined on physical exam, the diagnosis cannot be completed in the ED. Spontaneous resolution
 occurs in 89% of patients; however, median symptom duration is  weeks. Hematospermia should be differentiated from hematuria based on a clean­catch urinalysis (see Chapter , “Urinary Tract Infections and Hematuria”). Infection, including sexually transmitted infections, should be considered, and if suspected based on history and physical, the patient should be cultured and treated appropriately. Although all patients with hematospermia should be referred to a urologist, those >40 years old are at higher risk for cancer and should be strongly advised to seek further
 evaluation by a urologist even when there is spontaneous resolution of hematospermia.


