## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 124: Mouth and Throat Disorders in Infants and Children
Derya Caglar; Richard Kwun
INTRODUCTION
Lesions of the mouth and throat are common in children and can range from benign conditions that require no intervention to significant systemic illness requiring extensive treatment and support (Table 124­1). Making the distinction between these conditions can be difficult. Mouth pain secondary to viral infections of the oropharynx is one of the most common presenting complaints of pediatric patients; however, most patients require no treatment beyond supportive care and pain control. Bacterial infections of the mouth and throat, such as pharyngitis and uvulitis, cause local and systemic illness and rarely can lead to life­threatening complications. The management of dental injuries, whether from neglect or trauma, differs for primary and permanent teeth.
TABLE 124­1
Common Causes of Oral Lesions in Children
Anterior Posterior Diffuse
Aphthous ulcers Adenovirus pharyngitis Autoimmune disease
Contact stomatitis Coxsackievirus Candidiasis (thrush)
Herpes simplex gingivostomatitis Cytomegalovirus Chemotherapy­related mucositis
Epstein­Barr virus
Trauma Streptococcal pharyngitis Medication­related (phenytoin [Dilantin®])
Vincent’s angina
Stevens­Johnson syndrome
Varicella­zoster
NORMAL VARIANTS
Epstein pearls are remnants of embryonic development that present as white, slightly raised nodules seen most commonly midline at the junction of the soft and hard palates of neonates. They are often seen incidentally during feeding and do not cause the child any pain or discomfort. Most resolve spontaneously.
Geographic tongue or migratory glossitis (Figure 124­1) can be a source of great parental concern. It is a benign, asymptomatic condition and is often incidentally noticed by parents during another illness. Findings include an area of erythema and atrophy of the papillae of the tongue surrounded by a serpiginous, elevated white or yellow border usually located in the anterior two thirds. The lesions will improve and disappear gradually over time but tend to recur in other areas of the tongue. There is no known cause, although it has been associated with childhood allergies and atopy. No treatment other than reassurance is necessary.

FIGURE 124­1. Chapter 124: Mouth and Throat Disorders in Infants and Children, Derya Caglar; Richard Kwun 
. Terms of Use * Privacy Policy * Notice * Accessibility
Geographic tongue. [Reproduced with permission from Wolff K, Johnson RA, Saavedra AO: Fitzpatrick’s Color Atlas and Synopsis of Clinical
Dermatology, 7th ed. © 2013 by McGraw­Hill, Inc., New York, Figure 33­4.]
Mucoceles (Figure 124­2) and ranulas are lesions of the oral mucosa that present as small, bluish, discrete, mucosal swellings on the lower lip or sublingual areas. These are most often caused by minor trauma such as biting the lip. Referral to otolaryngology for intervention is needed only with disruption of feeding or development of speech. Adjacent salivary glands are usually removed in addition to the lesion to prevent recurrence.
FIGURE 124­2. Mucocele. [Reproduced with permission from Wolff KL, Johnson R, Suurmond R: Fitzpatrick’s Color Atlas & Synopsis of Clinical Dermatology, 6th ed. ©
2009, McGraw­Hill, Inc., New York, Figure 34­14.]
Eruption cysts are smooth, painless bluish­black areas of swelling found over an emerging tooth that usually resolve with the eruption of the underlying tooth. Although these findings are frightening to the parent, they are benign in nature, often asymptomatic, and require no intervention.
APHTHOUS ULCERS
Aphthous ulcers, also known as canker sores, are the most common form of recurrent oral ulcers, occurring in 5% to 25% of the general
 population. They present in children and adolescents as painful, shallow ulcers on the oral mucosa (Figures 124­3). The etiology of canker sores is
 unknown, but genetic factors, food allergies, local trauma, endocrine changes, stress, and anxiety are all thought to contribute to recurrence. They are found most frequently on the buccal and lingual mucosa. Spontaneous resolution after  to  days is the norm. Topical medications, such as antimicrobial mouthwashes and topical analgesics, can achieve the primary goal of reducing pain but do not hasten healing or improve recurrence or
 remission rates. Some adult trials suggest that oral vitamin B may reduce recurrence rates for those with frequent outbreaks regardless of initial
 serum B levels.

FIGURE 124­3. Aphthous ulcers: Note the multiple ulcers of various sizes located on the lip and gingival mucosa. These lesions rarely occur on the immobile oral mucosa of the gingiva or hard palate. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002,
McGraw­Hill, Inc., New York, Figure 6­33.]
Less commonly, periodic fever, aphthous stomatitis, pharyngitis, and cervical adenitis syndrome (PFAPA) can cause aphthous ulcers in children  to  years of age. Patients present with fever, malaise, exudative pharyngitis, cervical lymphadenopathy, and multiple oral ulcers lasting  to  days, often recurring multiple times a year. Recurrence is the key to diagnosis, as this constellation of symptoms is difficult to distinguish from viral infection, particularly in the ED where patient care is cross­sectional rather than longitudinal. The cause of PFAPA remains unknown, but most patients respond
 well to oral steroids, with resolution of symptoms within  hours and typically remission after  to  years. Some studies have also shown that tonsillectomy leads to complete resolution of symptoms and that vitamin D supplementation reduces number and duration of PFAPA episodes;
4­6 colchicine may also be effective for some patients in limiting recurrences.
STOMATITIS
The majority of infectious mouth and throat lesions are viral. Enteroviral infections commonly cause oral lesions with or without other physical findings such as fever, rash, abdominal pain, or diarrhea. Herpes viruses can cause oropharyngeal lesions that are extremely painful, may be recurrent, and are usually associated with high fever during primary infection. Adenovirus can cause acute pharyngitis in association with fever and tonsillar erythema. Exudative pharyngitis in association with fevers, fatigue, and malaise is frequent in infections with Epstein­Barr virus and cytomegalovirus.
HERPANGINA
Herpangina is an enteroviral infection that causes a vesicular enanthem (Figure 124­4) of the tonsils and soft palate, affecting children  months to  years of age during late summer and early fall. It is primarily caused by coxsackievirus A16 and human enterovirus , although other coxsackie A and B genotypes are also common etiologic agents. These vesicles are often very painful and are accompanied by fever, difficulty swallowing, and dysphagia.
Patients may complain of headache, vomiting, and abdominal pain. Diagnosis is primarily clinical. Viral culture is the gold standard for confirmation of infection; however, enteroviral polymerase chain reaction can detect enteroviral RNA from nasopharyngeal secretions, blood, urine, or feces much
 sooner and with higher sensitivity (87% to 100%; 95% from throat culture).
FIGURE 124­4. Herpangina: Typical elliptical or oval­shaped papulovesicular lesions with erythematous rims are seen on the posterior soft palate. [Reproduced with permission from Shah BR, Lucchesi M: Atlas of Pediatric Emergency Medicine. © 2006, McGraw­Hill, Inc., New York, Figure 3­67.]
Treatment is palliative because the symptoms are usually mild and lesions heal spontaneously after  to  days. Antipyretics and systemic analgesics aid with supportive care. Viscous lidocaine is generally not recommended for pain relief because it has no benefit over placebo in improving
,9 oral intake in affected children and also carries a risk of toxicity from lidocaine ingestion, with associated seizures. A mixture of diphenhydramine and Maalox applied orally in a swish­and­swallow fashion can provide local pain relief. When topical treatment does not suffice, systemic analgesics, including narcotics, may be necessary. Pay close attention to hydration status because children can quickly become dehydrated, requiring admission for IV fluid replacement.
HAND­FOOT­AND­MOUTH DISEASE
Hand­foot­and­mouth disease is also seen with enteroviral infections. Coxsackievirus A16 is the most common cause, but A5, A6, A9, A10, B2, B5, and
,11 enterovirus  subtypes have also been implicated. The disease is typically seen in children <5 years old and is most common in infants and toddlers. The infection has a seasonal distribution and primarily occurs in the spring and summer months.
The illness generally follows a mild course, starting with a low­grade temperature lasting  to  days, and is associated with decreased appetite, malaise, vague abdominal pain, and mild upper respiratory symptoms. Children will then develop an enanthem of vesicles, followed by the exanthema, although both can occur simultaneously.
Oral lesions usually begin as erythematous macules and evolve into vesicles and ulcers over the course of  to  days, with new lesions appearing throughout the duration of illness. Lesions typically involve the palate, buccal mucosa, gingiva, and tongue. Pain from these ulcerations often leads to decreased oral intake and mild dehydration.
The associated rash appears on the palms of the hands, soles of the feet, and buttocks (Figure 124­5). Lesions begin as erythematous macules that later may develop into small nontender vesicles. The oral and skin lesions tend to resolve over  to  days.
FIGURE 124­5. Hand, foot, and mouth disease: Typical erythematous macules on the palms (A) and soles (B) and oral lesions (C). [Reproduced with permission from
Shah BR, Lucchesi M: Atlas of Pediatric Emergency Medicine. © 2006, McGraw­Hill, Inc., New York, Figure 3­65.]
Diagnosis is primarily clinical, although the virus can be isolated by viral culture or polymerase chain reaction from swabs of the vesicles and from stool specimens. Treatment involves supportive and symptomatic care with antipyretics, topical and oral analgesics, and oral rehydration. In rare cases, pain may lead to inadequate oral intake. Analgesics and IV fluids may be needed to treat dehydration. Rare complications of these infections include viral
,13  meningitis, meningoencephalitis, myocarditis, and sepsis. Diligent hand washing among children and caregivers is key to preventing spread.
HERPES SIMPLEX GINGIVOSTOMATITIS
Herpes simplex virus can cause a variety of symptoms in the pediatric population. Infants and toddlers will often present with high fever, pharyngitis, and gingivostomatitis during their primary infection. Initial infection is often very difficult to distinguish from other viral etiologies. Most children go undiagnosed with herpes simplex virus until they later present with a more classic painful labial reactivation lesion.
Acute herpetic gingivostomatitis is the most common presentation of primary herpes infection in children (Figure 124­6). It usually presents at  months to  years of age, although primary herpes simplex virus infection may occur in older children and adults. Ninety percent of cases are due to
,16 herpes simplex virus type ; however, herpes simplex virus type  has also been found to cause disease. Herpes transmission occurs via contact with infectious saliva, typically from caregivers who may be unaware of their infectious risk. The incubation period is  to  days, with a mean of  days.
FIGURE 124­6. Herpes simplex virus: Primary herpes gingivostomatitis in a 6­year­old girl. Note multiple erosions on gingiva and labial mucosa. [Reproduced with permission from K Wolff, RA Johnson, AP Saavedra, EK Roh: Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 8th ed.
www.accessmedicine.com. © 2017, McGraw­Hill Education, New York, Figure 27­34.]
Clinically, the disease presents with abrupt onset of high fever, irritability, decreased oral intake and drooling, and swollen, erythematous, friable gingiva. Physical findings include vesicular lesions in the oral cavity, ulcerations, and tender cervical lymphadenopathy. Symptoms may persist for up to  weeks, but more commonly last <1 week.
Diagnosis is primarily clinical. Viral culture has been the gold standard of laboratory testing for years. However, the recovery of virus from lesions is low
(7% to 25%). Herpes simplex virus polymerase chain reaction is a newer, more accurate assay with improved sensitivity in detecting infection from any lesions that are present. Tzanck smear of fluid from unroofed lesions  to  hours old showing multinucleated cells can also confirm the diagnosis but cannot differentiate infection between viruses within the herpesvirus family.
Treatment consists of supportive care with oral analgesics/antipyretics, topical analgesics, and systemic antiviral therapy for substantial pain,
,18 dehydration, or severe disease (acyclovir,  milligrams/kg PO divided five times a day for  days). Antiviral treatment is most effective within  hours of symptom onset. Immunocompromised patients are at significantly higher risk for systemic dissemination, and hospitalization and treatment
,20 with IV acyclovir are recommended.
Prognosis of a primary herpes simplex virus infection beyond the fetal/neonatal period is very good. As the primary infection resolves, a lifelong latent residency of the virus within the trigeminal ganglion occurs, which may lead to less severe recurrences at the same site in the future.
PHARYNGITIS
It is important to distinguish between superficial and deep space infections of the mouth and throat. Deep space infections are discussed in Chapter
126, “Stridor and Drooling in Infants and Children,” and are typically associated with toxic appearance, high fever, drooling, stridor, or changes in phonation, trismus, or torticollis. Sore throat is responsible for 6% of pediatric office visits, resulting in more than  million primary care visits annually
,22 in the United States. In children with acute pharyngitis, 50% to 80% of cases are viral in etiology (Table 124­2).
TABLE 124­2
Causes of Viral Pharyngitis in Children
Adenovirus
Coronavirus
Enterovirus (coxsackievirus)
Respiratory syncytial virus
Rhinovirus
Measles
Herpes simplex virus types  and 
Parainfluenza virus
Epstein­Barr virus
Cytomegalovirus virus
Human immunodeficiency virus
Influenza virus A and B
Symptoms associated with acute pharyngitis include sore throat, odynophagia, fever, headache, abdominal pain, nausea and vomiting, cough, hoarseness, coryza, diarrhea, arthralgias, myalgias, and lethargy. Physical examination may reveal tonsillopharyngeal erythema and/or exudates, soft palate petechiae, uvulitis, anterior cervical lymphadenitis, rash, conjunctivitis, anterior stomatitis, and discrete ulcerative lesions. It is often difficult to
 distinguish between viral and bacterial causes of pharyngitis based on physical examination alone, and tonsillar exudate does not imply bacterial etiology. Most viral infections are self­limited and require only symptomatic treatment; 85% of patients experience spontaneous resolution within  week. Interestingly, patient satisfaction appears to be greatest when a physician shows concern and provides reassurance and is not related to
 whether or not antibiotics are prescribed.
VIRAL PHARYNGITIS
Pharyngitis is the best known acute clinical manifestation of Epstein­Barr virus infection (Figure 124­7). It often begins with malaise, headache, and fevers before development of the more specific signs of exudative pharyngitis and posterior cervical lymph node enlargement. Splenomegaly and hepatomegaly can also occur. Patients mistakenly treated for a bacterial pharyngitis with amoxicillin or ampicillin often develop a characteristic pruritic maculopapular rash that aids in diagnosis.
FIGURE 124­7. Marked white exudates on the tonsils of a child with Epstein­Barr virus infection. [Reproduced with permission from Kane KSM, Lio P, Stratigos A,
Johnson R: Color Atlas & Synopsis of Pediatric Dermatology, 2nd ed. New York, McGraw­Hill, Inc., 2010.]
Diagnosis is often clinical, although a heterophile test (monospot) can aid in diagnosis. It is important to remember that this test relies on crossreactivity of patient antibodies and is relatively insensitive in pediatric patients (25% positive in  to  months vs. 75% in  to  months).
Furthermore, the monospot test typically does not turn positive in cases of Epstein­Barr virus until symptoms have been present for  week or more. A negative test, therefore, does not exclude the diagnosis of Epstein­Barr virus; when necessary, testing for Epstein­Barr virus immunoglobulin M and immunoglobulin G is both sensitive and specific, although results are not immediately available. Atypical lymphocytes may be present on the CBC, if obtained. Epstein­Barr virus infection may be associated with other organ involvement, including hepatitis. Patients with right upper quadrant tenderness should have liver enzymes evaluated.

Treatment is largely supportive; however, some patients may require IV fluids and pain medication. Although there is no evidence of efficacy, a dose of oral or parenteral steroid can be considered to reduce tonsillar enlargement when swallowing or respiratory symptoms are attributed to enlarged tonsils. When splenomegaly is noted, proper counseling regarding risk factors and symptoms of splenic rupture should be given (avoid contact sports until splenomegaly has resolved as determined by the primary care physician).
Cytomegalovirus infection can very closely mimic Epstein­Barr virus mononucleosis. Patients presenting with classic infectious mononucleosis who are heterophile negative are often infected with cytomegalovirus. Fever, malaise, and systemic complaints predominate in the clinical picture of cytomegalovirus, with less prominent cervical lymphadenopathy or splenic enlargement than Epstein­Barr virus. Distinguishing between the two etiologies is difficult, and often, the diagnosis is confirmed with laboratory testing for cytomegalovirus immunoglobulins M and G. Treatment is again supportive.
Acute retroviral syndrome or acute infection with human immunodeficiency virus (HIV) may present similarly to Epstein­Barr virus pharyngitis in
50% to 70% of patients. Differences implicating human immunodeficiency virus from other viral illnesses may include presence of high­risk behaviors in the social history, the acuity of onset, the absence of exudate and prominent tonsillar hypertrophy, presence of a rash, and mucocutaneous ulceration.
Acute human immunodeficiency virus is uncommon in the pediatric patient, although it must be considered in adolescents in whom high­risk behaviors are identified. In addition to the usual causes of pharyngitis, opportunistic infections, such as Candida albicans and Mycobacterium avium,
 should be considered in the immunocompromised patient.
BACTERIAL INFECTIONS
Group A β­hemolytic Streptococcus (GABHS) Pharyngitis
GABHS pharyngitis is the most commonly occurring form of acute bacterial pharyngitis for which antibiotic therapy is indicated. It typically occurs in the winter and early spring and primarily affects children age  to  years old. Although GABHS accounts for up to 37% of pharyngitis in children,
27­29
.2% of children with pharyngitis receive antibiotics. In addition, a substantial proportion of patients treated for GABHS pharyngitis receive an inappropriate antibiotic.
Several clinical prediction rules have been created to identify cases of GABHS pharyngitis, and most are modifications of the original Centor criteria
(Table 124­3). Generally, with zero or one criterion, GABHS is unlikely, and testing and treatment for GABHS are not indicated. With two or more
 criteria, testing should be performed using a rapid antigen detection test and/or culture. To date, no clinical prediction rule for selective testing has demonstrated sufficient diagnostic accuracy for GABHS pharyngitis. It is also recommended to forgo laboratory testing in patients with overt viral features (e.g., cough, rhinorrhea, oral ulcers/vesicles, and/or conjunctival injection) because a positive test suggests GABHS carriage rather than acute
 infection.
TABLE 124­3
Centor Criteria for Likelihood of Group A β­Hemolytic Streptococcus Pharyngitis
Tonsillar exudates
Tender anterior cervical lymphadenopathy
Absence of cough
History of fever
Although bacterial culture remains the gold standard, with a sensitivity of 90% to 95%, the 18­ to 48­hour wait time for definitive diagnosis is often impractical, and the use of a rapid antigen detection test has become popular. The sensitivity of rapid antigen detection tests varies from 80% to 90%.

Current guidelines recommend confirmatory throat culture for all patients with a negative antigen test, although backup cultures may not be
 required in areas with a low incidence of rheumatic fever when antibiotic treatment is not generally recommended. Back­up cultures are not necessary for patients with a positive rapid antigen detection test because the test is highly specific.
The antibiotic treatment of GABHS pharyngitis is effective to (1) shorten the duration of illness, (2) prevent transmission, (3) prevent suppurative complications (acute otitis media, acute sinusitis, and peritonsillar abscess), and (4) prevent systemic illness such as rheumatic fever, rheumatic heart disease, and poststreptococcal glomerulonephritis. Antibiotics for the treatment of GABHS pharyngitis should be reserved, however, for patients with a positive antigen test or culture or those meeting clinical criteria for diagnosis. GABHS pharyngitis is typically a self­limited disease, with fever and constitutional symptoms diminishing markedly at days  and  after symptom onset, and antibiotics only decrease the duration of symptoms by
 approximately  hours.
Treatment
Treatment can be delayed safely for up to  days after symptom onset and still prevent major nonsuppurative sequelae; thus, waiting for confirmatory cultures and providing a wait­and­see prescription for antibiotics are safe. There is no definitive evidence that antibiotic use can prevent acute glomerulonephritis.
No clinical isolate of GABHS has been documented to be penicillin resistant; thus, it remains the treatment of choice based on its efficacy, safety,
 narrow spectrum, ease of dosing (twice­daily dosing), compliance, and cost (Table 124­4). Treatment failures may be attributable to viral pharyngitis with GABHS carriage, medication noncompliance, or reinfection of patients successfully treated for GABHS. A course of  days of oral therapy with twice­a­day dosing is recommended for complete pharyngeal eradication; similar efficacy is achieved with once­daily dosing of amoxicillin for  days or with a single IM dose of benzathine penicillin.
TABLE 124­4
Antibiotics for the Treatment of Streptococcal Pharyngitis
Medication Dosage Route Duration
Penicillin V (first line) Child: 250 milligrams two times daily PO  d
Adolescent/adult: 500 milligrams twice a day
Amoxicillin (first line)  milligrams/kg once daily; maximum dose, 1000 milligrams or  PO  d milligrams/kg/dose twice daily; maximum dose, 500 milligrams
Benzathine penicillin G <27 kg: 600,000 units IM One dose
≥27 kg: ,200,000 units
Cephalexin (alternative for penicillin­allergic  milligrams/kg/dose twice daily; maximum dose, 500 milligrams PO  d patients without anaphylaxis)
Clindamycin (alternative for penicillin­allergic  milligrams/kg three times daily; maximum dose, 300 milligrams PO  d patients)
Azithromycin (alternative for penicillin­allergic Child:  milligrams/kg once daily PO  d patients) Adolescent/adult: 500 milligrams on day , then 250 milligrams on days 2–5
Clarithromycin (alternative for penicillin­ .5 milligrams/kg/dose twice daily; maximum dose, 250 milligrams PO  d allergic patients)
Several alternative therapy options exist for those unable to take penicillin. The efficacy of amoxicillin appears to be comparable to that of penicillin and is acceptable in children who more easily tolerate the taste of the suspension. Clarithromycin and first­generation cephalosporins are suitable alternatives in penicillin­allergic patients. Clindamycin may be required for macrolide­resistant GABHS in the penicillin­allergic patient. Macrolide resistance is increasing worldwide. Currently, 6% to 7% of GABHS isolates in the United States appear to be macrolide resistant, but this is expected to increase given higher resistance patterns in other parts of the world and the widespread use of macrolides for the treatment of upper and lower
 respiratory tract infections.
Routine antibiotic prophylaxis is not recommended for household members exposed to GABHS, because the risk of developing subsequent
 pharyngitis is approximately 10%. Although tonsillectomy is clearly indicated for recurrent tonsillitis in children, there is only modest evidence to support tonsillectomy for recurrent pharyngitis. Patients undergoing tonsillectomy have been shown to have a modest reduction in frequency of

GABHS infections for up to  years after surgery.
Benefits of antibiotic treatment for other bacterial pharyngitides are unclear at this time. There have been no cases of acute rheumatic fever due to non­GABHS, such as groups C and G Streptococcus. If treated, antibiotics used in the treatment of GABHS are appropriate for pharyngitis due to groups C and G Streptococcus.
Several other bacterial etiologies must be considered in patients with pharyngitis. These include Neisseria gonorrhoeae, Corynebacterium diphtheriae, Arcanobacterium haemolyticum, Yersinia enterocolitica, Yersinia pestis, Francisella tularensis, Mycoplasma pneumoniae, Chlamydia species, and Fusobacterium necrophorum.
Neisseria gonorrhoeae
Gonococcal pharyngitis is difficult to distinguish from other bacterial causes of pharyngitis. A careful sexual history, including exposure to partners with known sexually transmitted diseases and oral sex practices, should be elicited in all adolescent patients presenting with pharyngitis. Gonococcal infection of the throat may be associated with infection elsewhere, including proctitis, vaginitis, and/or urethritis. The diagnosis requires special culture on Thayer­Martin medium, although nucleic acid amplification testing is also available. A positive culture in a prepubertal child is highly suspicious for sexual abuse, and further investigation is warranted with involvement of the appropriate child protection agencies. IM ceftriaxone (250 milligrams) is the only therapy recommended by the Centers for Disease Control and Prevention for the treatment of uncomplicated pharyngeal gonorrhea. Empiric treatment for concomitant chlamydia with the addition of  gram of azithromycin should be given unless it has specifically been ruled out.
Corynebacterium diphtheriae
Although occurrence is rare in developed countries due to vaccination, C. diphtheriae should be considered in patients who are under­ or unimmunized. Toxigenic strains of this bacterium produce an exotoxin that causes localized necrosis of the respiratory mucosa and can lead to both cardiac and neurologic complications. Pseudomembrane formation in the respiratory tract can result in airway obstruction. Identification of the causative organism is made using Loeffler or tellurite selective medium. Treatment of pharyngeal diphtheria is aimed at bacterial eradication and exotoxin neutralization. Penicillin and erythromycin are the antibiotics of choice, along with equine diphtheria antitoxin. Serious sequelae can be prevented with prompt antibiotic administration, and treatment should be started when diphtheria is clinically suspected.
Arcanobacterium haemolyticum
A. haemolyticum closely mimics GABHS pharyngitis and may also produce a scarlatiniform rash in teenagers; rarely, it produces a membranous pharyngitis similar to that of diphtheria. It may be missed on routine cultures and may be more readily detected on human­blood agar plates. Both macrolide and β­lactam antimicrobial agents are effective treatments.
Fusobacterium necrophorum
In patients of age  to  years with an acute sore throat, F. necrophorum may be causative in 10% to .5% of cases. However, carriage rates of .4%
 have been reported. It is associated with retropharyngeal abscesses and Lemierre syndrome. F. necrophorum is usually susceptible to penicillin and first­generation cephalosporins.
UVULITIS
Isolated inflammation of the uvula is unusual and has infectious and noninfectious causes. When associated with pharyngitis, the most common bacterial etiology is GABHS. In the unimmunized patient, Haemophilus influenzae type b is the next most common cause and may occur with epiglottitis. Other bacterial causes are Fusobacterium nucleatum, Prevotella intermedia, Streptococcus pneumoniae, and C. albicans. Noninfectious
 causes include trauma from instrumentation, irritant inhalation, vasculitis, allergic reaction, and angioedema.
The inflamed uvula appears erythematous, enlarged, and edematous (Figure 124­8). Patients may present with fever, sore throat, difficulty swallowing, odynophagia, drooling, and/or respiratory distress.
FIGURE 124­8. Uvulitis: Edematous, erythematous uvula. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. ©
2002, McGraw­Hill, Inc., New York, Figure 5­28.]
Uvulitis is a clinical diagnosis. When there is associated pharyngitis, test for GABHS. H. influenzae diagnosis requires culture on Loeffler or tellurite selective medium.
Antibiotics to cover GABHS should be based on antigen testing or throat culture results. Acute airway obstruction is unusual with isolated uvulitis; however, when epiglottitis is also present, intubation may be required. When allergic reaction or angioedema is suspected, treatment may include epinephrine, antihistamines, and steroids. Precipitants, such as inhaled irritants and allergens, and responsible medications, such as an angiotensinconverting enzyme inhibitor, should be discontinued.
ORAL PROBLEMS
DENTAL TRAUMA
The evaluation and management of pediatric dental trauma, including subluxation, luxation, intrusion, extrusion, avulsion, and fracture, differ between primary and secondary (permanent) teeth (see Chapter 245, “Oral and Dental Emergencies,” Figure 245­2).
Most traumatic dental injuries occur in the toddler years, when children are learning to walk. Nonaccidental trauma (e.g., physical abuse, sexual abuse,
,40 bullying, and injuries from human trafficking) must also be considered. More than half of child abuse cases involve craniofacial, head, face, and neck injuries, and a high index of suspicion must be maintained. Two other significant periods of trauma include school­aged children, from play
 injuries, and adolescents, mainly due to sports. Traumatic dental injury prevalence varies between 6% and 58%. The most commonly injured teeth are the maxillary central incisors.
Primary tooth eruption begins at approximately  months of age and is usually complete by  years of age. Secondary teeth may begin to erupt at  years of age and can continue past adolescence if the wisdom teeth are not extracted.
Subluxation refers to loosening of the tooth without displacement and is due to periodontal ligament damage (see Chapter 245, “Oral and Dental
Emergencies,” Figure 245­3). On examination, the tooth is mobile, and sulcal bleeding may be present. When subluxation is noted in a primary tooth, no intervention is required; however, permanent teeth may require splinting. Dental follow­up is recommended in either case, as pulpal necrosis may
 occur.
Luxation is a loosening and displacement of a tooth from its normal anatomic position and occurs when the periodontal ligament is torn. The tooth is often nontender and immobile and may be fixed in its new position. Primary teeth may be allowed to passively reposition, although dental consultation is recommended. Permanent teeth require active repositioning and splinting as soon as possible.
Intrusion occurs when a tooth is driven apically into the socket, displacing into the alveolar bone. The tooth appears shortened, or even absent, and, when visible, is not mobile or tender. Ninety percent of intruded teeth will reerupt spontaneously in  to  months. Extraction of primary teeth is indicated when the apex is displaced toward the permanent tooth germ, as determined by radiography. Permanent teeth with immature root formation may be allowed to reerupt; mature teeth require orthodontic or surgical extrusion.
Extrusion occurs when a tooth is displaced from its socket. The tooth appears elongated and is mobile, due to tearing of the periodontal ligament.
Both primary and permanent teeth should be repositioned and splinted as soon as possible. If the injury is severe enough, primary teeth may require extraction in the ED.
Avulsed primary teeth should not be replanted, because this may damage the permanent tooth germ. Permanent teeth, by contrast, require urgent reimplantation, because success is time dependent. There is 85% to 97% survival of permanent teeth when replaced within  minutes, and near­zero survival at  hour. Avulsed teeth should be handled by the crown to avoid damaging the periodontal ligament. Debris should be removed with gentle rinsing in saline or water; scrubbing should be avoided because it may cause further damage. If the tooth cannot be replanted within  minutes, it should be stored, in order of preference, in ViaSpan, Hanks’ Balanced Salt Solution, cold milk, saliva, physiologic saline, or water.

Of media available at the scene of an accident, regular pasteurized whole milk is the most recommended storage solution.
Fracture of the tooth enamel alone (a type  fracture using the Ellis classification system) or of the enamel and dentin (Ellis type  fracture) may be managed conservatively (Figures 124­9 and 124­10). Treatment of an Ellis type  fracture, involving the pulp (Figure 124­11), includes pulp capping and partial and complete pulpectomy. A root fracture, or Ellis type  fracture, involves the dentin, pulp, and cementum. In both primary and permanent teeth, the coronal fragment should be repositioned and stabilized in its anatomically correct position. In primary teeth, alternatively, the coronal fragment may be extracted, allowing the periodontal ligament and neurovascular supply to heal.
FIGURE 124­9. Ellis type  fracture: Note the fracture of the left upper central incisor. The sole involvement of the enamel is consistent with an Ellis type  injury.
[Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, Inc., New York, Figure 6­5.]
FIGURE 124­10. Ellis type  fracture: Bilateral maxillary central incisor injuries with exposed enamel and dentin consistent with an Ellis class  fracture. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, Inc., New York, Figure 6­6.]
FIGURE 124­11. Ellis type  fracture: A fracture demonstrating blood at the exposed dental pulp. This sign is pathognomonic for an Ellis class  fracture. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, Inc., New York, Figure 6­7.]
Radiographs may be obtained to confirm any of the diagnoses above or to confirm a tooth avulsion when there is question of an intrusion into the alveolar bone.
SOFT TISSUE INJURIES OF THE MOUTH
Repair large lacerations of the gingiva with absorbable sutures. Wounds can allow entry of foreign bodies, such as food particles, dental fillings, and tooth fragments, leading to infection. Frenulum lacerations of the maxilla usually heal well without intervention. By contrast, the vascularity around the mandibular frenulum often requires primary closure. Tongue lacerations can usually be treated conservatively, especially if the wound is <1 cm in length, is in the central portion of the tongue, and does not gape, and bleeding is controlled. Tongue lacerations greater than one third of the total diameter and those at the tip causing forking that may affect speech require suturing.
In general, lacerations limited to the inner mucosal surface heal well on their own and do not require primary repair. By contrast, full­thickness lacerations and those that disrupt the vermillion border require suturing.
CARIES
Children are particularly susceptible to developing caries soon after the initial eruption of teeth if care is not taken to properly examine and clean the
 new teeth. “Baby bottle” caries occur in 24% to 28% of all children age  to  years old. Risk factors include prolonged breast or bottle feeding
(beyond  months), prolonged pacifier use, frequent consumption of beverages high in sugar, and use of a bottle at bedtime.
Encourage parents to minimize beverage choices high in sugar content. Teeth should be cleaned daily from time of eruption to  months of age with a soft toothbrush and increased to twice a day thereafter. Transition to a training cup by  year of age and removal of the bottle can also significantly reduce the occurrence of caries. In addition, an initial screening dental examination between  and  months of age is recommended to look for signs of decay or a need for fluoride supplementation. In communities without fluoridated water, supplemental fluoride should be prescribed by the primary care provider.
Dental neglect is a form of child abuse probably underreported or unrecognized by medical providers. It is defined as the “willful failure of parent or guardian to seek and follow through with treatment necessary to ensure a level of oral health essential for adequate function and freedom from pain and infection.” Poor oral hygiene may be secondary to family isolation, lack of finances, parental ignorance, unfluoridated water, bottle­propping, or
 lack of perceived value of oral health, and clinicians should determine whether one or more of these situations are contributing factors.
GINGIVITIS
Gingivitis is inflammation of the gums that presents as tender, erythematous, often ulcerated or vesiculated areas of tissue. It is seen mainly in the setting of poor dental hygiene but can occur with viral and bacterial infections, certain medications (e.g., phenytoin [Dilantin®]), or even as a presentation of leukemia. Although there are many causes of gingivostomatitis, viral infections are particularly common in children.
Acute necrotizing ulcerative gingivitis is a progressive infection of the gingiva, leading to pain, significant edema, and ulceration. The incidence typically peaks in the teens to early 20s, but may be seen in younger children in developing countries due to poor access to adequate dental care or malnutrition. Other factors that may predispose patients to acute necrotizing ulcerative gingivitis include smoking, immunosuppression, viral infections, stress, and sleep deprivation. Patients present with fever, halitosis, decreased appetite, and generalized malaise. Acute necrotizing ulcerative gingivitis is a mixed infection that includes spirochetes, specifically, Prevotella intermedia. Untreated, acute necrotizing ulcerative gingivitis can spread beyond the gingiva to involve deeper tissues or the tissues of the mouth floor (Ludwig’s angina) or face. Treatment consists of analgesia to facilitate better oral hygiene and antimicrobial oral rinses. Patients with more extensive disease or systemic symptoms may require admission for local debridement and parenteral antibiotic therapy with penicillin or metronidazole. The patient should be referred to a dentist for close follow­up care.


