## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 295: Abuse of the Elderly and Impaired
Jonathan Glauser; Frederic M. Hustey
INTRODUCTION
Elder abuse is an act or omission resulting in harm to the health or welfare of an elderly person. Three key groups have published definitions of elder
1­3 abuse. Although the incidence of elder neglect and abuse is unknown and widely felt to be underreported, the rate of different types of abuse
 among the elderly has been estimated to be in the mid­single digits up to 10% of persons age >65 years, or between 500,000 and  million U.S.
,6  adults. One meta­analysis identified the pooled prevalence of elder abuse overall in geographically diverse countries to be .7%. Alternatively, a
 clinician seeing between  and  adults over age  per day could encounter more than one victim of elder mistreatment on a daily basis. Table
295­1 summarizes the categories of elder abuse.
TABLE 295­1
Categories of Elder Abuse
Categories of
Example
Abuse
Physical abuse Pushing, slapping, burning, striking with objects, improper use of restraint (physical or chemical)
Caregiver neglect Deprivation of food, clothing, hygiene, medical care, shelter, or supervision
Sexual abuse Unwanted touching, indecent exposure, unwanted innuendo, rape
Financial or material Forcible transfer of property or other assets, including changing elderly person’s will exploitation
Emotional or Verbal threats (such as threats of violence, institutionalization, or deprivation), humiliation, intimidation, harassment, social psychological abuse neglect, and isolation
Abandonment Desertion of an elder in the home or a hospital, nursing facility, shopping mall, or other public location by a caregiver or caretaker
Self­neglect Failure or unwillingness to provide adequate food, clothing, shelter, medical care, hygiene, or social stimulation to self in individuals with diminished capacity to perform essential self­care tasks
Source: Reproduced from U.S. Department of Health and Human Services, Administration on Aging and Administration for Children and Families: The National Elder
Abuse Incidence Study. Washington, DC: National Center on Elder Abuse, 1998. CLINICAL FEATURES
PHYSICAL ABUSE
Physical abuse is the most easily recognized form of elder abuse. It is defined as the use of physical force that might result in bodily injury, physical
 pain, or impairment. Pushing, slapping, burning, striking with objects, and improper use of restraint are all examples of physical abuse. Chemical
Chapter 295: Abuse of the Elderly and Impaired, Jonathan Glauser; Frederic M. Hustey r©e2s0tr2a5in Mt (csGucrahw a sH inillt.e Anltl ioRnigahl tosv Reremseedrviceadt.i o nT eorrm asd mofi nUissetr a * tPiorniv aocf ytr aPnoqliucyil i * z eNrso)t iicse a * m Aocrcee ssusbibtlieli tfyorm. Regardless of mechanism, physical abuse is carried out with the intention of causing suffering, pain, or other physical impairment to the abused person.
CAREGIVER NEGLECT
Elder neglect is the most common form of elder maltreatment, accounting for more than half of all elder maltreatment cases reported to adult
 protective services agencies annually. Elder neglect is defined as the failure of a caregiver to meet basic needs for a person or to provide goods and
,11 services necessary to prevent physical harm or emotional discomfort. Examples of neglect include deprivation of food, clothing, hygiene, medical
,11 care, shelter, or supervision that a prudent person would consider essential for the well­being of another.

Elder neglect is both underrecognized and potentially lethal. It likely accounts for the majority of cases of unreported abuse. It is also an independent
 risk factor for mortality, even taking into account that the deaths themselves may not be immediately ascribed to injury. Elder neglect may be difficult to diagnose. Although some cases may be obvious (such as in a patient with multiple deep pressure ulcers), neglect is often more subtle and difficult to detect.
SEXUAL ABUSE
Sexual abuse is broadly defined as nonconsensual sexual contact of any kind with an elderly person. The spectrum of sexual abuse ranges from unwanted touching, indecent exposure, or unwanted innuendo, to rape itself. Although sexual abuse is underreported across all age groups, in the elderly, sexual abuse is even less likely to be reported. Fear of retaliation and shame on the part of patients, as well as stereotyping of older patients as
 asexual or not sexually desirable by clinicians, police, and others, may be factors in underrecognition and underreporting of sexual abuse.
FINANCIAL OR MATERIAL EXPLOITATION

Financial abuse is estimated to be the second most common form of elder abuse, accounting for approximately 20% to 30% of abuse cases. Financial
 or material exploitation is the illegal or improper use of an elder’s funds, property, or assets. It occurs when family members, caregivers, or friends take control of the elder person’s resources. Coercion or outright theft may occur, with or without the awareness of the elder person experiencing abuse. An elderly person may unwittingly sign over access to savings accounts and other assets when he or she is in an incapacitated state. Social
Security checks or pensions may be used by caregivers for personal gain. Theft may be blatant or coerced, with forcible transfer of property, including changing of the elder’s will. Anticonstitutional abuse is a term coined to describe violation of constitutionally guaranteed human rights, such as theft of
 identity papers, coercion, or false pretense resulting in the surrender of rights. Abuse may result in a decrease in the standard of living and an inability to pay bills, purchase food, or obtain medications.
EMOTIONAL OR PSYCHOLOGICAL ABUSE
Emotional or psychological abuse is defined as the infliction of anguish, emotional pain, or distress. Examples of psychological and emotional abuse include verbal threats (such as threats of violence, institutionalization, or deprivation), humiliation, intimidation, and harassment. Social neglect and isolation are also forms of abuse. Psychological and emotional abuse can contribute to the development and worsening of mental health problems
 such as depression, which is common in many older victims.
ABANDONMENT
Abandonment constitutes the desertion of an elderly person by an individual who is that person’s custodian or who has assumed responsibility for providing care to the elder. Desertion of an elder in the home, hospital, nursing facility, shopping mall, or other public location may occur.
SELF­NEGLECT
Self­neglect includes those behaviors of an elderly person that threaten his or her own safety. Such behaviors include failure or unwillingness to provide adequate food, clothing, shelter, medical care, hygiene, or social stimulation for oneself. It is the result of an adult’s inability, due to diminished capacity, to perform essential self­care tasks. By definition, this applies to one who understands the consequences of his or her choices
 and makes a conscious decision to engage in acts that threaten his or her own health or safety. Patients who have cognitive impairment or who are
 living in poverty are at greater risk of self­neglect and may have increased mortality.
DIAGNOSIS
RISK FACTORS
An awareness of risk factors is important for the recognition of potential victims of elder abuse or neglect. Risk factors can be divided into two
,17­21 categories: factors associated with the elders and factors associated with the perpetrators (Table 295­2).
TABLE 295­2
Risk Factors for the Occurrence of Elder Abuse
Risk Factors for Elders Risk Factors for Perpetrators
Cognitive impairment History of mental illness
Physical dependency History of substance abuse
Lack of social support Excessive dependence on elder for financial support
Alcohol abuse History of violence within or outside the family
History of domestic violence Unemployed
Female gender History of financial difficulties
Developmental disability
Difficult behavior (such as aggression or verbal outbursts)
Special medical or psychiatric needs
Limited experience managing finances
Institutionalization
Patient characteristics associated with a higher risk for elder mistreatment are cognitive impairment, physical dependency, lack of social support,
 alcohol abuse, female sex, and a history of domestic violence. In addition, developmental disabilities, special medical or psychiatric needs, and difficult behavior (such as aggression or verbal outbursts) also increase the risk for abuse. Individuals with limited experience in managing finances are at increased risk for financial or material exploitation. Although elder abuse is more common in residential than institutional settings,
,20 institutionalization is also recognized as a risk factor for neglect and abuse.
Three characteristics of perpetrators have been identified as risk factors: a history of mental illness and/or substance abuse, excessive dependence on
 the elder for financial support, and a history of violence within or outside of the family. Abusers are most often the primary caregiver. Adult children
 tend to be more inclined to abuse than are spouses, and males engage in abuse more often than females. Caregivers may be well intentioned but simply overwhelmed by the amount of care required. They may themselves be impaired by mental or physical problems that serve as barriers to the provision of adequate care.
HISTORY
The approach to the patient interview is important. Potential sufferers of abuse should be interviewed in private. The presence of caregivers, family, or friends may cause the patient to feel intimidated or embarrassed, which limits the amount and accuracy of information obtained. Try to put the patient
 at ease by making the assessment seem like a routine part of the evaluation. Separately interview individuals accompanying the patient. Screening
22­24 tools are available to aid in the detection of elder abuse. The use of lengthier tools is not feasible in a busy ED, but the American Medical
Association has proposed a list of nine screening questions that may be more practical to implement (Table 295­3). An affirmative answer to any of the questions in this screening tool raises concern and mandates further exploration.
TABLE 295­3
Screening Questions for Elder Abuse
Has anyone ever touched you without your consent?
Has anyone ever made you do things you didn’t want to do?
Has anyone taken anything that was yours without asking?
Has anyone ever hurt you?
Has anyone ever scolded or threatened you?
Have you ever signed any documents you didn’t understand?
Are you afraid of anyone at home?
Are you alone a lot?
Has anyone ever failed to help you take care of yourself when you needed help?
During the interview, be prepared to recognize behavioral signs and symptoms that suggest elder abuse. These include depression, fear, withdrawal, confusion, anxiety, low self­esteem, and helplessness. Other history­related indicators that suggest abuse or neglect include a pattern of “physician shopping,” unexplained injuries inconsistent with medical findings, and recurrent visits for similar injuries. Additional history taking should explore risk factors for abuse as outlined earlier in “Risk Factors.”
Information can be obtained by the physician prior to conducting the private interview or by other members of the healthcare team, such as nurses, who are likely to have more frequent interaction with the patient and caregivers. Observing the interaction between the accompanying individuals can yield valuable clues (Table 295­4).
TABLE 295­4
Clues During the Medical Interview That May Suggest Elder Abuse
The patient appears fearful of his or her companion.
There are conflicting accounts of an injury or illness from the patient and caregiver.
The caregiver displays an attitude of indifference or anger toward the patient.
The caregiver is overly concerned with the costs of treatment needed by the patient.
The caregiver denies the patient the chance to interact privately with the physician.
The caregiver appears overly concerned and attentive.
PHYSICAL EXAMINATION
Physical examination findings range from subtle and nondiagnostic to highly suspicious. Abuse is often detected when examination findings prompt further history taking with results suggesting elder mistreatment. Psychological abuse and financial abuse are especially hard to diagnose in the ED setting because physical examination findings are uncommon. Nonetheless, it is important to perform a detailed evaluation, including obtaining adequate exposure of the body to evaluate for trauma and pressure ulcers. Common physical findings in sufferers of elder abuse are bruising or
 trauma, poor general appearance and hygiene, malnutrition, and dehydration.
Although not the most common form of elder abuse, physical abuse is the most easily recognized. Evidence of injury to normally protected areas of the
 body is highly suspicious for physical abuse. Examples include contusions or lacerations on the inner arms or inner thighs and injury to the mastoid area. It is important to expose these areas when examining the patient to avoid missing significant findings. Contusions on the palms, soles of the feet,
 and buttocks also raise concern for elder abuse. Multiple injuries in various stages of healing can suggest abuse but may also be seen in patients with recurrent falls. Taking a thorough history is especially important in differentiating these two causes. Although older patients may sustain burns through accidental injury (such as coming too close to an open flame while cooking), unusual burns or multiple burns in various stages of healing should also raise concern. Traumatic alopecia is highly suspicious, although not necessarily diagnostic (because it may be seen in patients with some
 psychiatric conditions). Rope or restraint marks on wrists or ankles occur when elders are inappropriately restrained. Midshaft ulnar fractures
(nightstick fractures) can occur from attempts to shield blows by raising the forearm. Fractures of the head, spine, and trunk may be more indicative of abuse, although these can occur by other mechanisms. More recently, the radiologic literature has investigated specific findings that may be suggestive of elder abuse, although so far these are not considered pathognomonic; examples include upper, posterior, or multiple rib fractures; multiple subdural hematomas; small bowel hematomas; and injuries inconsistent with reported mechanism. Spiral fractures of long bones and fractures with
,26 rotational components also raise suspicion of abuse.
Findings resulting from caregiver neglect or self­neglect are less specific. Perhaps the most identifiable finding is that of multiple or deep pressure ulcers. Ulcers that are uncared for (such as open ulcers lacking appropriate dressings or packing) or those not in lumbar or sacral areas raise suspicion even further. Incapacitated patients should be turned as part of the examination to evaluate for skin breakdown. Poor personal hygiene, inappropriate
 or soiled clothing, dehydration, malnutrition, contractures, fecal impaction, and excoriations suggest neglect.
Sexually transmitted diseases or findings of genital trauma, especially in an incapacitated patient, raise concern for sexual abuse. Patients may complain of genital or anal pain, itching, bruising, or bleeding. Torn or stained underwear, with unexplained difficulty walking or sitting, may be present. Oral trauma can also be a manifestation of sexual abuse.
Depression, anxiety, and fear can be manifestations of psychological abuse, although they are nondiagnostic. Observation of interactions with caregivers and companions can provide further important clues to this type of abuse.
Although elder abuse is widely underrecognized and underreported, remember that underlying medical disorders are often associated with findings that could otherwise be identified with abuse. Advanced neurologic disorders such as multiple sclerosis, amyotrophic lateral sclerosis, and
Parkinson’s disease may lead to immobilization and severe disability. Individuals with such conditions are at risk for pressure ulcers, pneumonia, or
 venous thromboembolism, even with adequate care.
TREATMENT, DISPOSITION, AND FOLLOW­UP
Treatment of elder abuse in the ED involves three key components:
Addressing associated medical and psychological needs
Ensuring patient safety
Complying with local reporting requirements (https://ncea.acl.gov/)
Medical problems, including injuries, should be stabilized and treated and may be best managed through hospital admission. In addition to physical injury, metabolic derangements may be present. Patients with dehydration or malnutrition can have a variety of electrolyte abnormalities and may also have coexisting renal failure. Elders left in the same position for an extended period of time may be at risk for rhabdomyolysis. Additional problems may exist due to failure to administer usual medications at home. These issues should all be addressed during the ED visit, including the ability to conduct activities of daily living, such as meal preparation, housework, bathing, dressing oneself, toileting, and managing finances.
Psychological problems brought on by abuse, as well as preexisting psychiatric conditions and substance abuse, should also be addressed. The severity of the problem and planned disposition can affect the extent to which treatment is completed in the ED. For patients requiring hospitalization, concerns and findings should be communicated to the admitting service and documented in the medical record. For patients who are discharged to home, arrangements should be made for appropriate follow­up. Follow­up must be arranged for the patient’s medical and psychiatric needs, and arrangements must also be made for monitoring and assessment of home safety and assessment of caregiver stress or substance abuse. A variety of resources are available to assist with these issues (Table 295­5). Social work consultation can be helpful in finding local resources.
TABLE 295­5
Resources for Elder Abuse
Who to Contact Services Provided
Clinical Justice Services Provides self­instruction training program, pamphlets, and brochures on elder abuse prevention.
Public Policy Institute
American Association of Retired Persons
601 E St., NW
Washington, DC 20049
202­434­2222
National Adult Protective Services Provides a variety of resources for elder abuse, both nationally and by state and county.
Association (NAPSA)
PO Box 96503 PMB 74669
Washington, DC 20090
202­370­6292 http://www.napsa­now.org/
National Center on Elder Abuse One of the main information sites for elder abuse; provides a variety of resources, both nationally and by c/o University of Southern California Keck state.
School of Medicine
Department of Family Medicine and
Geriatrics
1000 South Fremont Avenue, Unit ,
Building A­6
Alhambra, CA 91803855­500­3537 http://ncea.acl.gov/
National Organization for Victim Assistance Provides referrals, resources in every state.
510 King St., Suite 424
Alexandria, VA 22314
800­TRY­NOVA or 703­535­6682 http://www.trynova.org
National Coalition Against Domestic Provides training and education on domestic violence, publications, and programs.
Violence
One Broadway, Suite B210
Denver, CO 80203 303­839­1852 http://www.ncadv.org
National Domestic Violence Hotline Provides intervention; cannot take reports; ; available  h via phone. Live chat service available
Toll free: 800­799­SAFE via website  h/day.
TTY: 800­787­3224 (for hearing impaired) http://www.thehotline.org/
National Long­Term Care Ombudsman Provides information on support, technical assistance as well as information on local long­term care
Resource Center ombudsman resources by state.
http://www.ltcombudsman.org
National Council on Aging Addresses many aging issues through various programs.
251 18th Street South, Suite 500
Arlington, VA 22202 571­527­3900 http://www.ncoa.org
Commission on Law and Aging Provides information on laws pertinent to elders; has contact information by state and other law­related
American Bar Association services for legal assistance providers; provides mandatory reporting requirements for each state. Makes
321 North Clark Street available Domestic Violence and Sexual Assault in Later Life, a resource packet of information and materials
Chicago, IL 60654 312­988­5000 accessible online.
http://www.abanet.org/aging
National Center on Elder Abuse One of the main information sites for elder abuse; provides a variety of resources, both nationally and by
1201 15th Street, NW, Suite 350 state. Also provides link to Training Library for Adult Protective Services and Elder Abuse.
Washington, DC 20005
202­898­2586
Email: ncea@nasua.org https://www.elderabusecenter.org/
Family Caregiver Alliance Lead agency in CareJourney, a program designed to provide Internet services to caregivers of adults with
235 Montgomery Street, Suite 950 cognitive impairments.
San Francisco, CA 94104 415­434­3388 or
800­445­8106 http://www.caregiver.org
AARP Leading organization representing people over age . Provides publications on caregiving issues, financial
601 E St., NW planning, durable power of attorney, trusts, and insurance.
Washington, DC 20049
888­OUR­AARP http://www.aarp.org
Other resources:
Administration on Aging
330 Independence Ave., SW
Washington, DC 29201
202­245­0641 https://www.acl.gov/aboutacl/administration­aging
National Committee for the Prevention of
Elder Abuse
1730 Rhode Island Ave., NW, Suite 1200
Washington, DC 20036
202­464­9481 http://www.preventelderabuse.org
National Committee for the Prevention of
Elder Abuse c/o Institute on Aging
119 Belmont St.
Worcester, MA 01605
508­793­6166
Elder Care Locator Nationwide service connecting older Americans and caregivers with local support resources.
U.S. Administration on Aging
800­677­1116 https://eldercare.acl.gov/Public/Index.aspx
Patients in immediate danger should be hospitalized, transferred to the care of a friend or reliable family member, or placed in an emergency shelter.
Suspected abuse should be reported to the appropriate state agency (https://ncea.acl.gov/) or local adult protective services agency in order to ensure a follow­up investigation and a thorough long­term assessment. Adult protective services is the federal program that receives mandatory reports of suspected abuse, typically leading to a home visit and further investigation. Although all  states have adult protective services and long­term care ombudsman programs, reporting is not mandated by law in every state. Elderly who live in the community are protected in all states by adult protective services agencies. Elders in institutional settings are protected in all states by long­term care ombudsman programs. Violations specific to nursing home residents might include the following: failure to respond to calls for help, unattended symptoms, injury of unknown origin or falls, physical abuse, poor staff attitudes related to respect or dignity, inappropriate medications or dosages, stolen or lost property, or abuse by other residents.
Much long­term facility abuse occurs between residents; many facilities have younger psychiatric patients who are more mobile and aggressive than
 the older debilitated residents. Become familiar with requirements pertaining to your own practice area (https://ncea.acl.gov/).
In cases of unintentional neglect, education of the caregiver may be the only intervention necessary. Other support options include home health aide
,28 visits, respite services, day programs, accessible transportation, support groups, adult day care, and church activities or pastoral visitations. When mistreatment results because the caregiver is overburdened, interventions to decrease stress and anxiety may be welcomed by all parties. Spouses are most likely to be primary caregivers; most of these are women. Lack of sleep and inadequate exercise and nutrition are commonly expressed by caregivers, perhaps leading to anger and risk of abuse. Services for caregivers may be publicly funded or community based with support groups. Some
 programs provide home­delivered meals, respite care, counseling, and assistance with advance directives and estate planning.
If available, medical case management teams can provide consultation and support by assisting in the multidisciplinary evaluation of suspected abuse
 cases and developing treatment plans. Team members generally are composed of a physician, nurses, and social workers. Teams may make house calls, arrange physical and occupational therapy, and provide for nutritional improvement and management of disease states. Legal intervention teams can also be used to address financial management, probate and guardianships, and other legal and housing issues. Civil courts can issue protective orders, create guardianships, and issue emergency removal orders. Recommendations for ED management of cases of elder abuse and
 neglect are provided in Table 295­6. TABLE 295­6
American College of Emergency Physicians Policy on Domestic Family Violence31
Emergency personnel assess patients for intimate partner violence, child and elder maltreatment, and neglect.
Emergency physicians are familiar with signs and symptoms of intimate partner violence, child and elder maltreatment, and neglect.
Emergency medical services, medical schools, and emergency medicine residency curricula should include education and training in recognition, assessment, and interventions in intimate partner violence, child and elder maltreatment, and neglect.
Hospitals and EDs encourage clinical and epidemiologic research regarding the incidence and prevalence of family violence as well as best practice approaches to detection, assessment, and intervention for victims of family violence.
Hospitals and EDs are encouraged to participate in collaborative interdisciplinary approaches for the recognition, assessment, and intervention of victims of family violence. These approaches include the development of policies, protocols, and relationships with outside agencies that oversee the management and investigation of family violence.
Hospitals and EDs should maintain appropriate education regarding state legal requirements for reporting intimate partner violence and child and elder maltreatment.
SPECIAL CONSIDERATIONS
BARRIERS TO THE DETECTION OF ELDER ABUSE
Sufferers of elder abuse often have low self­esteem and may blame themselves for the abuse. They may not want to admit vulnerabilities and feel
,32 disgraced for having raised a child who would betray them.
Elder abuse victims may also be unwilling to press charges against a family member. Abused older adults are frequently unaware of available
 resources. In addition, they may harbor a fear of being removed from the home or placed in a long­term care facility, of implicating family members, or of experiencing further abuse in retaliation for having divulged information. They may worry about not being believed. Victims may be unable to articulate their circumstances due to cognitive impairment. Abusers may control access to others and prevent encounters with outsiders to ensure that
 secrecy is maintained. There may also be differing perceptions as to what constitutes abuse based on cultural background.
Physicians may fail to report abuse for a variety of reasons. They may not be familiar with reporting laws or adequately understand reporting
 mechanisms. They may fear offending patients or their family members. Time constraints in the ED can also be a barrier to recognition and reporting.
There are no published studies of physical markers of mistreatment to distinguish preventable injury from intentional, inflicted, or avoidable
 trauma. In addition, some physicians may have the misperception that the law requires them to obtain the patient’s permission before reporting
 suspected abuse. Hospitals may also lack protocols for identifying or addressing elder abuse. It has been noted that screening for elder abuse and
 neglect has not been recommended by the U.S. Preventive Services Task Force for some of the aforementioned reasons.
ABUSE IN LONG­TERM CARE FACILITIES

Approximately .4 million Americans lived in nursing homes on any given day in 2012. Elder abuse in nursing homes is well documented. In one
 study, 36% of nurses and nursing aides working in long­term care facilities reported witnessing at least one act of physical abuse in the previous year.
A study of 2400 deaths in Arkansas nursing homes found  cases of suspected abuse or neglect, which indicates that forensic studies need to play a
 larger role in the investigation of unexplained deaths of older adults in long­term care facilities. Abuse in institutional settings manifests in similar ways to abuse in residential settings: theft of money or personal property, unsanitary conditions, poor personal hygiene, sexual assault, physical abuse or unexplained injury, bed sores, physical or chemical restraint, and malnutrition and dehydration. Perpetrators appear to be evenly divided
 between residents of the facility and staff members involved in the direct care of the victim. Nursing homes participating in Medicare and Medicaid
 programs must comply with certain quality­of­care requirements. Suspicion of abuse or neglect among patients in nursing homes should be reported to the state nursing home ombudsman program (http://www.ltcombudsman.org) or to an adult protective services agency.
LEGAL CONSIDERATIONS
Circumstances may occur in which hospital admission is advised, but the patient refuses. If the patient is competent, his or her wishes must be honored, even if those wishes do not appear to be in the patient’s best self­interest. Decisional capacity by the patient depends on his or her ability to understand all of the relevant information in order to make a choice, to communicate that choice, and to appreciate the current situation and treatment options. Therefore, it is especially important to interview the patient alone and to explain in detail the concerns of the healthcare provider.
The physician should also attempt to explore reasons for the patient’s reluctance to stay.
Patients who refuse admission but who lack decision­making capacity should not be discharged back to an unsafe environment. Contact with an adult protective services agency should be initiated. ED social workers can help locate contact information for the local adult protective services agency. If the agency determines that the victim of abuse lacks decision­making capacity, an emergency court order for protective services may be necessary.


