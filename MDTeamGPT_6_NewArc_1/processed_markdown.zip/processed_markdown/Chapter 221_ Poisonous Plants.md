## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 221: Poisonous Plants
Betty Chen; Lewis S. Nelson
INTRODUCTION
Common poisonous and injurious plants number in the hundreds and have a wide variety of toxicities. This chapter focuses on the most important
,2 plant­related exposures clinically relevant to emergency medicine (Tables 221­1 and 221­2). Individual plants are discussed in terms of their
 pathophysiology, clinical features (toxidromes), and treatment. Highly poisonous plants (Table 221­1) are highlighted in depth below, and brief reviews are provided for other common poisonous plants. Table 221­2 organizes common poisonous plants according to toxin structure.
TABLE 221­1
Examples of Severely Poisonous Plants
Poison hemlock (Conium maculatum)
Yew (Taxus spp.)
Foxglove (Digitalis purpurea)
Oleander (Nerium oleander)
Castor bean (Ricinus communis)
Rosary pea (Abrus precatorius)
Water hemlock (Cicuta maculata)
Buckthorn (Karwinskia humboldtiana)
TABLE 221­2
Classification of Poisonous Plants
Toxin Structure Examples
Alkaloids
Solanine and chaconine Green potato leaves, American nightshade, black nightshade (Solanaceae)
Anticholinergics Deadly nightshade (Atropa belladonna)
Angel’s trumpet or jimson weed (Datura spp. and Solandra spp.)
Henbane (Hycoscyamus niger)
Mandrake (Mandragora officinarum)
Cholinergics Calabar bean (Physostigma venenosum)
Pilocarpus (Pilocarpus spp., often grouped and called jaborandi)
Nicotinic and nicotine­like Tobacco (Nicotiana spp.)
Poison hemlock (Conium maculatum)
Golden chain (Laburnum anagyroides)

Blue cohosh (Caulophyllum thalictroides)
Chapter 221: Poisonous Plants, Betty Chen; Lewis S. Nelson 
Lupin (Lupinus spp.)
. Terms of Use * Privacy Policy * Notice * Accessibility
Psychotropics Peyote (Lophophora williamsii)
Nutmeg and mace (Myristica fragrans)
Morning glory (Argyreia spp. and Ipomoea spp.)
Hawaiian baby woodrose seeds (Argyreia nervosa)
Ayahuasca (Banisteriopsis caapi)
Hepatotoxic pyrrolizidines Comfrey (Symphytum officinale)
Sassafras (Sassafras albidum)
Ragwort (Heliotropium spp.)
Sodium channel modulators Monkshood (Aconitum spp.)
Larkspur (Delphinium spp.)
False or green hellebore (Veratrum spp.)
Yew (Taxus spp.)
Antimitotic alkaloids and resins Autumn crocus (Colchicum autumnale)
Mayapple (Podophyllum peltatum)
Wild mandrake (Podophyllum emodi)
Glory lily (Gloriosa superba)
Madagascar periwinkle (Catharanthus roseus)
Glycosides
Cardioactive steroids or cardiac glycosides Foxglove (Digitalis purpurea)
Lily of the valley (Convallaria majalis)
Oleander (Nerium oleander)
Christmas rose (Helleborus niger)
Milkweed (Asclepias spp.)
Squill (Urginea maritime and Urginea indica)
Yellow oleander (Thevetia peruviana)
Cyanogenic glycosides Almond, apricot, and cherry pits (Prunus spp.)
Tapioca plant, cassava (Manihot esculenta)
Elderberry (Sambucus canadensis)
Hydrangea (Hydrangea macrophylla)
Salicylates Poplar species (Populus spp.)
Willow species (Salix spp.)
Proteins, peptides, and lectins
Toxalbumins Castor bean (Ricinus communis)
Rosary pea (Abrus precatorius)
Pokeweed (Phytolacca americana)
Black locust (Robinia pseudoacacia)
American mistletoe (Phoradendron flavescens)
European mistletoe (Viscum album)
Black vomit nut (Jatropha curcas)
Hypoglycin Ackee fruit (Blighia sapida)
Litchi (or lychee) fruit (Sapindaceae spp.)
Carboxylic acids
Calcium oxalate crystals Dumbcane (Dieffenbachia spp.)
Philodendron (Philodendron spp.)
Caladium (Caladium spp.)
Jack in the pulpit (Arisaema triphyllum)
Elephant’s ear (Colocasia spp.)
Rhubarb (Rheum raponticum)
Alcohols
Convulsants Water hemlock (Cicuta maculata)
Phenols and phenylpropanoids
Coumarins and derivatives Sweet clover (Melilotus spp.)
Tonka beans (Dipteryx spp.)
Sweet­scented bedstraw (Galium triflorum)
Red clover (Trifolium pretense)
Capsaicin Cayenne pepper (Capsicum spp.)
Demyelination Buckthorn or coyotillo (Karwinskia humboldtiana)
Terpenoids and resins
Grayanotoxin (sodium channel blockers) Azalea and rhododendron (Rhododoendron spp.), mountain laurel (Kalmia latifolia)
Kava lactones Kava kava (Piper methysticum)
Thujone Grand wormwood (Artemisia absinthium)
Anisatin Star anise (Illicum spp.)
Tetrahydrocannabinol Marijuana (Cannabis sativa)
EPIDEMIOLOGY
In 2016, the American Association of Poison Control Centers received ,793 reports of plant exposures. Of these cases, ,636 involved children <5
 years of age. There were an additional 1644 nonexposure calls that provided information about plants to callers. The vast majority of exposures (96%) are unintentional ingestions. Cutaneous and ophthalmic exposures are common but generally go unreported. Although inhalational exposures are possible, they are rarely reported.
Unfortunately, obtaining an accurate plant exposure history can be difficult. Most exposures occur in children and are usually unwitnessed.
Uncertainty typically surrounds these cases, particularly whether ingestion truly occurred. The timing and amount of exposure are also difficult to quantify in many of these situations. Furthermore, even when a plant is available, identification errors are common and a botanist’s expertise may be required. In fact, data from the National Poison Data System demonstrate that medical providers and poison centers are unable to identify the plant
   approximately 15% of the time. For photos of select toxic plants, the reader is referred to Lim et al and Nelson and Balcik.
GENERAL EVALUATION AND MANAGEMENT
CLINICAL FEATURES
Classification of plants and their toxicities is complex. The most straightforward approach for emergency physicians is to classify toxic plants by the mechanism of action of the toxin and then to further subclassify based on the specific toxin. This will help predict the toxicologic effects. The reverse process can be used if the patient presents with clinical findings (Table 221­2). Unfortunately, attributing one toxicologic syndrome per plant oversimplifies the complexity of plant chemistry. Plants often contain multiple toxic compounds, each of which produces its own toxicologic effects.
Moderate systemic effects as a consequence of plant­related exposures occur in about 1% of exposed patients. Severe life­threatening effects or disabling injuries are extremely uncommon and occur in only about .04% of exposed patients. Death occurs in <0.001% of exposed patients.
Dermatitis and GI irritation are the most commonly reported effects of plant toxicity. GI complaints occur commonly following ingestion, and additional toxic symptoms may accompany or follow. Although dermatitis is another commonly reported finding of plant toxicity, systemic toxicity rarely follows
(see Table 221­3).
TREATMENT
Most plant­related exposures can be managed with supportive care. In patients able to tolerate oral administration and believed to have potentially concerning exposures, administer activated charcoal to prevent absorption of toxin from the GI tract. Because of the uncertainty surrounding plant exposures, observe asymptomatic or minimally symptomatic patients for  to  hours in the ED if the presumed toxin is believed to have a rapid onset of effect. Discharge asymptomatic patients and those with resolved minor toxicity after observation, with strict return precautions if symptoms develop. Admit those with more than minimal findings because toxicity may continue to evolve in those patients exposed to toxins with delayed onset (e.g., cyanogenic glycosides, mitotic inhibitors, or toxalbumins). This approach is generally applied to all patients with plant exposure because the scientific literature lacks adequate data to provide less conservative recommendations. There are few antidotes available to treat poisonings by plant toxins; none are unique to plant exposures but rather are generalized from use in other poisonings.
Report all exposures to the regional poison control center to obtain assistance with plant and toxin identification, to obtain assistance with patient management, and to enable collection of accurate data on toxic plant exposures. Unfortunately, data reported by the National Poison Data System do not require confirmation of exposure, and the incidence of consequential adverse effects is obscured by inconsequential or unconfirmed ingestions.
HIGHLY POISONOUS PLANTS AND COMMON TOXIC PLANTS
NICOTINIC AND NICOTINE­LIKE TOXINS (POISON HEMLOCK)
In Phaedo, Plato details the death of Socrates: After drinking a potion consisting of the extracts of poison hemlock (Conium maculatum), he slowly develops paralysis and dies. All parts of poison hemlock contain coniine and similar alkaloids that are structurally and functionally analogous to nicotine. Typically, ingestion of poison hemlock is due to misidentification because of its similarity in appearance to wild carrot or Queen Anne’s lace
(Daucus carota), parsley (Petroselinum crispum), parsnip (Pastinaca sativa) roots, or anise (Pimpinella anisum). Although most ingestions are
6­8 unintentional, there are case reports of toxicity from intentional use by patients for a presumed opioid­like effect or for intentional self­harm.
Clinical Features
Overstimulation of nicotinic cholinergic receptors can rapidly progress from seemingly mild symptoms to death from respiratory failure. Clinical findings may appear within minutes. Mild effects include nervousness and tremor due to sympathomimetic stimulation. As toxicity progresses, patients exhibit more pronounced sympathomimetic features, parasympathetic findings, and paralysis from nicotinic receptor stimulation at the neuromuscular junction.
Treatment
Management consists of GI decontamination with activated charcoal and supportive care, which may include respiratory support and administration of
IV fluids, antidysrhythmics, and anticonvulsants.
SODIUM CHANNEL TOXINS (YEW, RHODODENDRON, LAUREL, MONKSHOOD, LARKSPUR)
A number of plants across different classifications cause sodium channel effects that result in cardiac, respiratory, GI, and CNS effects. Yew (Taxus spp.) contains taxine alkaloids in all parts of the shrub except the aril, which is the berry’s red fleshy portion. The hard seed inside of the berry also
,10 contains taxine alkaloids that block sodium and calcium channels. Few effects are to be expected if ingestions are small or if berries are consumed without crushing the central seed. However, large ingestions can lead to more serious adverse effects or death.

Grayanotoxins are a class of  terpenoids that either inhibit or open sodium channels depending on the specific toxin. They are found in the leaves, flowers, and nectar of several plants such as azaleas and rhododendron (Rhododendron spp.). They are also found in the mountain laurel

(Kalmia latifolia). Ingestion of the leaves, flower, or honey from the nectar of the flower can result in toxicity.
Aconitine and other aconite alkaloids, found in monkshood (Aconitum spp.) and larkspur (Delphinium spp.), activate cardiac, and less so neuronal,
 sodium channels. Higher aconite alkaloid concentrations correlate with the development of ventricular dysrhythmias. Monkshood is sometimes used in traditional Chinese medicine as an inotrope. False or green hellebore (Veratrum spp.) is often confused for leeks by foragers, and these plants contain veratridine and other assorted veratrum alkaloids, which function similarly to aconitine.
Clinical Features
Regardless of the particular alkaloid or terpenoid and its specific mechanism of cardiac toxicity, findings after ingestion may variably include salivation, lacrimation, bradycardia or tachycardia, cardiac dysrhythmias, hypotension, hyperkalemia, paresthesias, muscle weakness, respiratory failure,
,9,13 seizures, and potentially death.
Treatment
Early after ingestion, activated charcoal may decrease absorption from the GI tract. No antidote is available, and symptomatic patients should receive supportive care such as IV fluids or vasopressors if hypotensive. Atropine is typically effective for bradycardia, although pacing has been used in
 ,12 refractory cases. Antidysrhythmics, such as amiodarone, procainamide, or flecainide, may be needed for malignant dysrhythmias. Cardioversion for wide­complex dysrhythmias can be attempted in unstable patients with the understanding that instability may persist and dysrhythmias may recur given the underlying channelopathy. Case reports describe successful use of cardiopulmonary bypass or extracorporeal membrane oxygenation in
,9,12,14,15 treating critically ill patients with refractory cardiac toxicity from yew poisoning and aconite poisoning.
CARDIOACTIVE STEROIDS (FOXGLOVE, OLEANDER)
Cardioactive steroids are found in many plants, including foxglove (Digitalis spp.), oleander (Nerium spp.), dogbane (Apocynum cannabinum), lily of the valley (Convallaria majalis), and milkweed (Asclepias spp.). Cardioactive steroids, sometimes called cardiac glycosides, inhibit the sodium/potassium–adenosine triphosphatase pump.
Clinical Features
Acute toxicity closely resembles that from digoxin and includes early GI effects followed by cardiac dysrhythmias. Serum digoxin concentrations may be used to qualitatively confirm cardioactive steroid exposure due to cross­reaction with the laboratory assay, but the absolute value holds little clinical quantitative value.
Treatment

Early after ingestion, oral activated charcoal may decrease systemic exposure by preventing absorption. Assess serum potassium concentration and obtain an ECG to aid in prognosis and therapy. Administer digoxin immune Fab fragments to patients with a serum potassium >5 mEq/L after an acute
 overdose or any cardiac dysrhythmia. Unlike with digoxin, antidote dosing should be empiric (10 vials as an initial dose), and the digoxin concentration should not be used to calculate dosing, because the assay is not an accurate reflection of toxin burden. Avoid transvenous pacing and calcium administration for the increased theoretical risks of inducing a dysrhythmia. Traditional treatments for hyperkalemia such as insulin, calcium, sodium bicarbonate, or hemodialysis are usually unnecessary if digoxin immune Fab is administered.
TOXALBUMINS (CASTOR BEAN, RICIN)
Ricin and abrin are examples of toxalbumins that can be extracted from the castor bean (Ricinus communis) and rosary pea (Abrus precatorius), respectively. Ricin, in particular, is a potential biologic weapon and has been implicated in a number of attempted assassinations.
These toxalbumins are proteins, peptides, or lectins, which exert their toxicity by entering cells and inhibiting protein synthesis.
Clinical Features
The clinical syndrome associated with the toxalbumins depends on quantity as well as route of exposure. Although one castor bean contains enough ricin to kill, its toxicity is typically limited following ingestion. Even if the castor bean is chewed to break the protective hard shell that sequesters the
 toxin, the enteral absorption of ricin is poor, which tends to limit toxicity to diarrhea and abdominal pain. Most unintentional toxalbumin ingestions reported to poison centers did not result in severe toxicity, but the small sample size and reporting bias associated with poison center data should not
 discourage providers from treating and observing potential ingestions for signs of toxicity. Although delayed systemic toxicity is possible following large ingestions, this is more concerning following parenteral exposures. Systemic organ dysfunction includes cardiac, neurologic, hepatic, and renal sequelae. Inhalational exposures are rapidly progressive and can result in life­threatening respiratory failure, circulatory collapse, and death within 
 hours.
Treatment
Treat toxalbumin ingestion by administration of activated charcoal followed by a lengthy observation period. All routes of exposure can be fatal, but hydration and aggressive supportive care significantly reduce mortality. More information about ricin can be found at the Centers for Disease Control and Prevention website (http://www.emergency.cdc.gov/agent/ricin).
Toxalbumins are found in a number of other plants such as American mistletoe (Phoradendron flavescens) and European mistletoe (Viscum album). The leaves and stems contain phoratoxin and viscumin, both of which are less potent than ricin. The berries also contain low levels of toxins that may result in gastroenteritis following large doses. These berries are abundant in homes during the holiday season and are attractive to children.
Fortunately, significant morbidity after berry ingestion is rare, although single incidents of seizure, gait instability, hepatotoxicity, and death have been
 reported. Patients who remain asymptomatic for  hours after ingestion can be discharged with return precautions, while patients who develop GI
 symptoms typically do well with fluids and electrolyte monitoring.
CONVULSANTS (WATER HEMLOCK)
Cicutoxin is a diol found in the water hemlock (Cicuta maculata), western water hemlock (Cicuta douglasii), and hemlock water dropwort
(Oenanthe crocata). These plants are often mistaken for wild parsnip, turnip, or parsley, causing toxicity through dermal or enteric absorption. All parts of the plant are poisonous, with the highest concentration of cicutoxin in the tuber. Cicutoxin’s mechanism of action is not fully understood.
However, it may impair γ­aminobutyric acid receptor or potassium channel function.
Clinical Features
Toxicity can manifest as early as  minutes following exposure. Mild effects include GI discomfort, followed by bradycardia, hypotension, respiratory distress, seizures, and death. Seizures may be severe and refractory to conventional anticonvulsant therapy. The mortality rate may be as high as

30%.
Treatment
Treatment consists of GI decontamination with activated charcoal and supportive care. Treat seizures with γ­aminobutyric acid agonists such as benzodiazepines or barbiturates.
DEMYELINATING ANTHRACENONES (BUCKTHORN)
Buckthorn or coyotillo (Karwinskia humboldtiana), which is found in the southwestern United States, Mexico, Central America, and the Caribbean, contains demyelinating anthracenones that lead to progressive muscle weakness that resembles Guillain­Barré syndrome. Weakness occurs weeks after ingestion, rendering GI decontamination futile in symptomatic patients. In severe cases, respiratory paralysis can lead to death without
 respiratory support. There is no antidote, and treatment is largely supportive until recovery.
BELLADONNA ALKALOIDS (NIGHTSHADE, JIMSONWEED, HENBANE)
Deadly nightshade (Atropa belladonna), jimsonweed (Datura spp.), and henbane (Hyoscyamus niger) all contain atropine or atropine­like alkaloids such as hyoscyamine and scopolamine.
Clinical Features
Ingestion or smoking results in antimuscarinic effects such as tachycardia, hyperthermia, mydriasis, decreased bowel sounds, urinary retention,
 altered mental status, and dry, flushed skin, although only some features of the toxidrome may be present. Severe poisoning can include seizures, coma, and death. Onset of effects depends on route of exposure, but findings should be evident within  hours. Exposures most commonly are
 intentional, such as through experimentation with the plant’s psychoactive properties.
Treatment
Treatment is largely supportive. Benzodiazepines are useful in calming patients, but avoid antipsychotics such as haloperidol to prevent further antimuscarinic activity. Physostigmine inhibits cholinesterase, resulting in increased synaptic concentrations of acetylcholine that can overcome the muscarinic antagonism. Physostigmine is generally indicated only for patients with moderate to severe clinical toxicity. Improvement in effect may be transient, and patients can require repeat dosing if toxicity recrudesces. Patients who receive physostigmine may improve faster and require shorter hospitalizations than patients receiving sedative­hypnotics.
ANTIMITOTIC ALKALOIDS (AUTUMN CROCUS, GLORY LILY, MAYAPPLE)
Colchicine is contained in all parts of the autumn crocus (Colchicum autumnale) and glory lily (Gloriosa superba). Colchicine halts cellular mitosis by inhibiting microtubule formation. Gastroenteritis, which may be delayed (2 to  hours), is followed by multisystem organ failure. Common effects include coagulopathy, bone marrow suppression with granulocytopenia and thrombocytopenia, cardiac dysrhythmias, cardiogenic shock, acute respiratory distress syndrome, hepatic failure, delirium, seizures, coma, and death. If patients survive, alopecia and neuropathy may develop. Mild
,26 toxicity is expected if GI symptoms begin >9 hours after ingestion.
Podophyllin is an extract of the roots of the mayapple plant (Podophyllum peltatum). This extract contains a mixture of toxins including podophyllotoxin, which inhibits topoisomerase II and microtubule formation. Toxicity is characterized by obtundation, coagulopathy, hematologic
 suppression, renal failure, GI irritation, hepatotoxicity, and death.
Early after ingestion, pursue aggressive GI decontamination because there is no antidote and toxicity can be fatal due to multisystem organ involvement. Due to colchicine’s potential for delayed onset of toxicity, observe exposed patients for a prolonged period. In addition to GI decontamination with activated charcoal, treatment usually requires aggressive fluid resuscitation and aggressive supportive care. Colchicine­specific
Fab fragments have been used in colchicine­poisoned patients with some success experimentally but are not commercially available.
CALCIUM OXALATE (ELEPHANT’S EAR)
Many common household ornamental plants contain crystalline calcium oxalate. Examples include dumbcane (Dieffenbachia spp.), elephant’s ear
(Colocasia spp.), and philodendron (Philodendron spp.). The calcium oxalate crystals are needle shaped and are bundled in raphides that also contain proteolytic enzymes and other chemicals. The contents are extruded when the plant is injured, causing both direct trauma from the crystals and inflammation due to the chemicals’ effects.
Clinical Features
Ingestion of calcium oxalate–containing plants results in immediate oropharyngeal pain and swelling. This pain usually limits the amount of plant
,28 ingested. In serious cases, the swelling can involve upper airway structures and cause respiratory compromise due to obstruction. Ocular exposures to the calcium oxalate–containing plants result in ocular pain, corneal injury, and conjunctivitis. Pain and swelling can last up to  days.
Treatment
Patients with oropharyngeal swelling and pain following ingestion tend to improve with supportive care. Anti­inflammatories may decrease swelling and provide analgesia. Topical treatments such as ice, ice water, and ice cream are soothing and can be given in patients with stable, patent airways.
Patients at risk of airway obstruction must be closely monitored and should be quickly intubated if progressing. Consider steroid administration; however, there are no trials demonstrating outcome improvement with steroid use.
CYANOGENIC PLANTS (PRUNUS SPECIES)
Several thousand plants, including many common vegetables and fruits, contain cyanogenic compounds such as amygdalin. Fortunately, the toxins are either sequestered in nonconsumed portions of the foods (e.g., seeds) or exist in quantities that are not clinically significant. Amygdalin is found in the leaves, bark, and seeds of those fruits of the Prunus species, including pears, apples, plums, peaches, and apricots. Although the aril (fruit portion) of these plants is nontoxic, ingestion of the other portions of the plants and their seeds can result in the liberation of hydrogen cyanide from amygdalin in the GI tract. Linamarin and lotaustralin are present in cassava (Manihot esculenta) and are similarly hydrolyzed to liberate hydrogen
,29 ,31 cyanide. If prepared correctly, the cyanogenic glycosides are detoxified prior to consumption. Initial GI irritation effects may be delayed; tissue hypoxia can follow. Rapid progression of toxicity can occur, and treatment for cyanide poisoning should be initiated immediately.
CAPSAICIN (PEPPERS)
Capsicum peppers contain capsaicin, a phenylpropanoid toxin that causes irritation, burning, and pain upon contact with skin and mucous membranes. This toxin enhances the release of substance P from small unmyelinated nerve fibers, which stimulate nociceptors that cause the sensation of burning or heat. Contact typically occurs as a result of self­inoculation while preparing peppers or exposure to spraying of pepper extracts in self­defense. Decontaminate affected areas by irrigation with copious amounts of water and gentle hand soap. Ocular exposures may require aggressive decontamination and ophthalmologic evaluation. Analgesics may be necessary.
MISCELLANEOUS GI TOXINS
Solanine and chaconine are glycoalkaloids that are present in many common plants and vegetables of the Solanum species. Unripe eggplant, green potatoes, and their sprouts contain a small amount of these heat­labile glycoalkaloids. Ingestion may cause GI effects such as vomiting, diarrhea,
,32 and abdominal pain, which can be delayed as long as  hours. CNS symptoms such as hallucinations, delirium, and obtundation are reported.
There is no specific antidote for solanine or chaconine poisoning, and supportive care is usually sufficient.
Pokeweed (Phytolacca americana) contains phytolaccatoxin and similar phytotoxins in the leaves and roots. The mature berries are less toxic.
Exposures can occur when foragers mistake the roots for other nontoxics such as parsnips or horseradish. Pokeweed is often prepared in poke salad or pokeroot tea. Toxicity is avoided if prepared by parboiling young greens. Incorrect preparation results in GI upset from direct mucosal irritation.

Nausea, vomiting, hemorrhagic gastritis, abdominal pain, and profuse diarrhea may last for  hours. Severe intoxications may rarely result in coma and death. Treatment is supportive. A nonconsequential lymphocytosis develops approximately  days after ingestion and typically resolves within  weeks.
Ackee fruit grows on the Blighia sapida tree, and it is a common ingredient in West African and Jamaican cuisine. Unripe ackee fruit contains the heatstable toxins hypoglycin A and B. Hypoglycin A inhibits free fatty acids from entering the mitochondria, impairs substrate formation for gluconeogenesis, and prevents conversion of glutamate to γ­aminobutyric acid. The resulting clinical syndrome, which is characterized by severe
,34 vomiting and hypoglycemia, is Jamaican vomiting sickness. Severe cases develop acidemia, seizures, and encephalopathy. Administer IV dextrose or a carbohydrate­heavy meal to hypoglycemic patients. Treat seizures liberally with benzodiazepines. However, seizures may be refractory to benzodiazepines if γ­aminobutyric acid concentrations are critically low. Rarely, chronic toxicity from hypoglycin A can lead to cholestatic hepatitis or
,35 fulminant liver failure. Admit symptomatic patients for close monitoring and treatment.
Hypoglycin A is also found in litchi or lychee fruit (Sapindaceae species). Since 1995, outbreaks of life­threatening hypoglycemic encephalopathy in
India have been associated with litchi harvesting season. Recently, researchers and epidemiologists linked the presence of hypoglycin A and a structurally similar toxin, methylenecyclopropylglycine (MCPG), to these outbreaks. The ingestion of these toxin­containing litchi in malnourished children has led to fatal hypoglycemia. Since this discovery, incidence of this illness has fallen following recommendations to limit litchi consumption,
,37 provide consistent nightly meals, and ensure timely correction of hypoglycemia.

Holly (Ilex spp.) exposures are among the top  plant exposures reported to poison control centers. Although the leaves are nontoxic, the attractive berries contain a mixture of toxins. The most consequential of this mixture are saponins, glycosides that cause abdominal pain, vomiting, and
 diarrhea. If fewer than six berries are ingested, minimal toxicity should follow. Large ingestions with severe GI upset may result in electrolyte abnormalities. For symptomatic patients, treatment is supportive.
PLANT­INDUCED DERMATITIS
Dermal exposure to a number of plants can result in dermatitis. These exposures are some of the most commonly reported plant­related concerns
 reported to poison control centers in the United States. Classification by mechanism of action can guide therapy (Table 221­3), but often, exposure to a single plant can result in injury due to multiple mechanisms.
TABLE 221­3
Plant­Induced Dermatitis
Dermatitis Classification Mechanism of Injury Specific Plants
Mechanical injury
Calcium oxalate Dumbcane (Diffenbachia maculate)
Philodendron (Philodendron spp.)
Raphides and trichomes Stinging nettles (Urtica dioica)
Velvet bean or cowhage (Mucuna pruriens)
Pineapple (Bromeliaceae spp.)
Irritant dermatitis
Phorbol esters Cow’s horn (Euphorbia grandicornis)
Poinsettia (Euphorbia pulcherrima)
Manchineel tree (Hippomane mancinella)
Other chemical irritants Stinging nettles (Urtica dioica)
Velvet bean or cowhage (M. pruriens)
Pineapple (Bromeliaceae spp.)
Contact dermatitis
Urushiol oleoresins Gingko (Ginkgoaceae)
Poison ivy, oak, and sumac (Toxicodendron spp.)
Mango (Mangifera indica)
Pistachio (Pistacia vera)
Cashew (Anacardium occidentale)
Miscellaneous antigens Peruvian lily (Alstroemeria spp.)
Narcissus and daffodils (Narcissus spp.)
Tulips (Tulipa spp.)
Primroses (Primula spp.)
Phytophotodermatitis
Furocoumarins Cow parsnip (Heracleum lanatum)
Wild parsnip (Pastinaca sativa)
Lime (Citrus aurantiifolia)
MECHANICAL INJURY
Specialized plant structures can injure the dermis and serve as a nidus for entry of toxins. Needle­shaped crystals, such as calcium oxalate crystal bundles, are found in a number of common plants, including dumbcane (Dieffenbachia spp.) and philodendron (Philodendron spp.). Needles of pineapples (Bromeliaceae spp.) and the hairs of stinging nettles (Urtica dioica) directly pierce the dermis, and chemical irritants in these structures cause further dermal injury (see next section).
IRRITANT DERMATITIS
Phorbol esters found in the sap of plants of the Euphorbiaceae (spurge) can cause dermal irritation following contact. The phorbol esters can penetrate the dermis upon contact. Symptoms such as erythema and bullae may develop shortly after direct contact. Ocular injuries and GI injury can also occur upon exposure or ingestion. Occasionally, aerosolized irritants can cause dermatitis or respiratory distress. Exposures to poinsettia
(Euphorbia pulcherrima) are typically well tolerated despite the widespread belief that poinsettia ingestion is potentially life threatening. Occasionally, these plants cause hypersensitivity reactions because several members of the Euphorbia family carry common allergens, including trees that produce
 natural latex. Pineapples (Bromeliaceae spp.), stinging nettles (U. dioica), and dumbcane (Dieffenbachia spp.) all introduce irritants such as
 proteolytic enzymes and other proinflammatory chemicals such as histamine, acetylcholine, and 5­hydroxytryptamine.
ALLERGIC CONTACT DERMATITIS
Many plants can cause allergic contact dermatitis after repeat exposure. Sensitization occurs after a resin binds to skin proteins and forms an antigen.
Reexposure then stimulates a T­cell–mediated immune response.
Poison ivy, poison oak, and poison sumac (Toxicodendron spp.) are ubiquitous sources of the antigenic resin urushiol. Ginkgo (Ginkgoaceae), mango (Mangifera indica), pistachio (Pistacia vera), and cashew (Anacardium occidentale) are common foods with urushiol­like compounds. In sensitized individuals, reexposure can result in urticaria and pruritus. Over  to  hours, symptoms may progress to varying degrees of vesiculobullous formation. Treatment usually consists of drying agents and local topical steroids, but systemic steroids may be necessary in severe cases. Some exposures can result in type I hypersensitivity or anaphylaxis. See Chapter 253, “Skin Disorders: Extremities.”
Tulips (Tulipa spp.) and daffodils (Narcissus spp.) contain the glycoside tuliposide A. After hydrolysis, an allergen causes tulip fingers or daffodil itch with chronic reexposure, a painful and pruritic condition.
PHYTOPHOTODERMATITIS
Phytophotodermatitis occurs when furocoumarins are activated by sunlight and produce symptoms that resemble sunburn in the acute phase; erythema and bullae are common. When these symptoms heal, hyperpigmentation persists for months. The mechanism is unknown. Exposure can be directly through the dermis, or furocoumarins can be deposited in the skin following ingestion and subsequent systemic circulation. Many plants,
 including common foods, can cause phytophotodermatitis, including numerous citrus fruits, celery, carrots, and herbs.


