## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 51: Low­Probability Acute Coronary Syndrome
Kathleen Hosmer; Chadwick D. Miller
INTRODUCTION AND EPIDEMIOLOGY
Of ED patients with undifferentiated chest pain, 7% will have ECG findings consistent with acute ischemia or infarction, and 6% to 10% of those in
 whom cardiac markers are ordered will have initially positive results. The remaining patients who do not have diagnostic ECG changes or initially positive cardiac marker results have low­probability or possible acute coronary syndrome (ACS; either infarction or ischemia including unstable
 angina pectoris). The evaluation of those with possible ACS costs approximately $10 billion to $12 billion each year in the United States.

Of all patients with possible ACS, 5% to 15% ultimately prove to have ACS. The rate of discharge from the ED for patients with ACS remains approximately 4%. Patients with ACS discharged home from the ED have worse outcomes and higher mortality compared with patients who are initially hospitalized. The clinical data readily available to the emergency physician, such as historical features, examination findings, and ECG results, cannot exclude ACS among most patients, because 3% to 6% of patients thought to have noncardiac chest pain or a clear­cut alternative diagnosis will have a
,5 short­term adverse cardiac event. Therefore, most patients with possible ACS are observed or admitted for further testing.
PATHOPHYSIOLOGY
ACS is a constellation of signs and symptoms resulting from an imbalance of myocardial oxygen supply and demand. There are three general ACS classifications: unstable angina, non–ST­segment elevation myocardial infarction, and ST­segment elevation myocardial infarction. A detailed discussion regarding these diagnoses is provided in Chapter , “Acute Coronary Syndromes.”
Patients presenting soon after infarction may have normal biomarker results and initially be categorized as having possible ACS. However, patients with evolving myocardial infarction generally have other high­risk features of ACS such as ST­segment depression, and they develop positive injury
,7 biomarker patterns over time.
CLINICAL FEATURES
HISTORY AND COMORBIDITIES
The history is the base tool to assess patients with possible ACS, but it alone cannot exclude the condition. Key data are symptom quality, location, duration, severity, associated symptoms, precipitating and relieving factors, and similarity to prior episodes known to be from ACS. Consider other noncardiac but life­threatening causes of chest pain (see Chapter , “Chest Pain”).
Among patients with possible ACS, historical data allow patients to be placed into categories of low risk, probable low risk, probable high risk, and high
 risk. However, even patients with low­risk features or in a low­risk category have a residual risk of ACS. Lowest­risk features include pleuritic, positional, reproducible, or sharp/stabbing pain. Another low­risk feature is pain that is not exertional or located in a small inframammary area. Higher­risk features include chest pressure (positive likelihood ratio [LR+] .3), pain similar to or worse than prior cardiac pain (LR+ .8), and associated nausea/vomiting or diaphoresis (LR+ .9 and .0, respectively). The highest­risk features include radiation to the right arm or shoulder (LR+
.7), left arm (LR+ .3), or both arms or shoulders (LR+ .1), and exertional chest pain (LR+ .4).
Traditional cardiac risk factors, such as hypertension, diabetes mellitus, tobacco use, family history of coronary artery disease (CAD) at an early age, and hypercholesterolemia, are modestly predictive of the presence of CAD in asymptomatic patients; additionally, in decision making during acute
 episodes, cardiac risk factors are poor predictors of cardiac risk for myocardial infarction or other ACS. CAD is rare in patients <30 years oDlodw, annloda wdheedn  p0r2e5s­e7n­t1, i4t :i5s 5u sPu a Ylloy uarc IcPo misp 1a3n6ie.1d4 b2y.1 o5th9e.1r2 r7isk factors.
Chapter 51: Low­Probability Acute Coronary Syndrome, Kathleen Hosmer; Chadwick D. Miller 
A©l2th0o2u5g Mh caG trruaew a Hltiellr.n Aaltl iRveig dhitasg Rnoessies rdveecdr.e a Tseesr mthse o lifk Uelsieh o * o Pdr iovfa AcCyS P, omliacnyy * pNaotiteicnets * w Aicthc eAsCsSi bairliety mistakenly diagnosed with gastric reflux or
 musculoskeletal pain. Clinical response to treatment with antacids (18% to 45% of ACS patients have relief of pain with antacids), viscous lidocaine, or
NSAIDs cannot exclude ACS. Lack of pain relief with nitroglycerin is similarly unreliable because 65% of patients with an ACS do not fully respond.
Prior cardiac testing (previous ECG tracings, echocardiograms, cardiac catheterization reports, and stress testing reports) aids the ED evaluation. ECG changes offer strong bedside evidence of new disease. Recent cardiac catheterization reports are especially useful, because a truly negative (defined as no luminal irregularities) result is associated with a very low incidence of subsequent infarction or ACS in the next  years. Although a prior positive
 stress test increases the likelihood of a subsequent acute cardiac ischemic event, a prior negative stress test provides little reassurance that a current chest pain event is from a benign cause. Patients with a recent negative evaluation for ACS that included objective cardiac testing (mostly stress testing) have a 6­month incidence of ACS as high as 14%. Furthermore, patients with a prior negative stress test have a similar incidence of ACS compared with
 those with no prior stress testing when presenting with chest pain to the ED. Overall, previous stress test results add evidence but cannot confirm disease presence or absence.
PHYSICAL EXAMINATION
Usually, the exam in the low­risk or possible ACS patient seeks to find complications or alternative causes of the symptoms. When an alternate diagnosis is not clear, the physical examination cannot distinguish between those with and without ACS. High­risk ACS features on physical examination are uncommon but include signs of cardiac failure such as hypotension, diaphoresis, pulmonary rales, jugular venous distention, new
 mitral regurgitation, bradycardia, tachycardia, and an S gallop. Rhythm abnormalities, including either bradycardia (seen with ischemia, especially
 in the inferior myocardium) or infarction that has led to disturbance of the conduction system, or tachycardia (from pump failure, pain, or stress, or from an alternative diagnosis such as pulmonary embolism), can aid on occasion. Positional changes in the pain severity suggest pericarditis or another pleural­based syndrome as a cause of pain.
DIAGNOSIS
The diagnostic process is conceptually split into a primary and secondary evaluation (Figure 51­1).
FIGURE 51­1. Evaluation process for patients with possible acute coronary syndrome (ACS). AMI = acute myocardial infarction.
PRIMARY EVALUATION
The goal during the primary evaluation is to distinguish patients with definite ACS from those with either possible ACS or those with symptoms that are definitely not from ACS. This involves gathering information from the history, physical examination, ECG, chest radiography, and medical record.
ECG
,13
For adult patients with chest pain in whom cardiac causes are possible, obtain a 12­lead ECG rapidly and compare it to any previous tracings.
Patients with ST­segment elevation, a new left bundle branch block, or ST­segment depression have an ACS and are treated as outlined in Chapter . Between 1% and 6% of ED chest pain patients with a normal ECG have non–ST­segment elevation myocardial infarction, and at least another 4% have
 unstable angina. Obtaining follow­up ECG(s) in patients with ongoing or worsening symptoms helps detect changes diagnostic of ACS, or it can show reversal of previous ST­segment or T­wave changes thought to be old—both define dynamic changes and the high likelihood of ACS. In the setting of dynamic ECG changes, incidence of CAD is 84% with classic anginal symptoms and 8% with nonclassic anginal symptoms as assessed by coronary
 angiography.
CHEST RADIOGRAPH
Chest radiography provides modest additional cardiovascular information, including cardiac silhouette size, pulmonary edema, and aortic contour.
Additional causes of chest pain, such as pneumothorax, bony metastasis, rib fracture, and pneumonia, may be detected on chest radiography. Patients presenting with anterior chest pain have findings on chest radiography that influence management 14% of the time.
CARDIAC MARKERS
Laboratory testing during the primary evaluation focuses on two goals: detecting myocardial necrosis and excluding alternative causes of chest pain.
Usual testing includes a CBC, serum electrolytes with renal function, and serum troponin. Other testing is guided by the history and physical examination.
RISK ASSESSMENT
The goal of early decision making is to determine if the patient actually belongs in the possible ACS cohort and is at high enough risk to warrant cardiac testing. All available data are used to create a composite picture for decision making. Some posit that when the pretest probability of ACS is
≤2%, further testing is not indicated  ; others have suggested a threshold of <1% to stop testing.  Detecting patients with a zero chance of any ACS in the presence of ACS­like symptoms is virtually impossible.
Two clinical decision aids help in identifying a very­low­risk (<1%) cohort that does not require further cardiac testing and that is eligible for discharge: the HEAR Score (part of the HEART Pathway) and Emergency Department Assessment of Chest Pain Score (Tables 51­1 and 51­2). Current evidence suggests that patients at low risk by the HEART Pathway or with an Emergency Department Assessment of Chest Pain Score of <16 have a <1%
17­19 risk for major adverse cardiac events within  to  days of presentation.
TABLE 51­1
The HEAR Score
Points
History
Highly suspicious 
Moderately suspicious 
Slightly suspicious 
ECG
Significant ST­segment depression 
Nonspecific repolarization abnormality 
Normal 
Age
≥65 
45–65 
≤45 
Risk factors*  or more risk factors 
1–2 risk factors 
No risk factors 
Total
Low risk = 0–3, high risk ≥4. *Risk factors include currently treated diabetes mellitus, current or recent (<90 days) smoker, diagnosed and/or treated hypertension, diagnosed hypercholesterolemia, family history of CAD, obesity (body mass index >30 kg/m2), or a history of significant atherosclerosis (coronary revascularization, myocardial infarction, stroke, or peripheral arterial disease).
TABLE 51­2
Original Emergency Department Assessment of Chest Pain Score
Factor Points
Age (years)
18–45 
46–50 
51–55 
55–60 
61–65 
66–70 
71–75 
76–80 
81–85 
86+ 
Known coronary artery disease (CAD) 
Male sex 
Typical symptoms
Diaphoresis 
Pain radiating to arm, shoulder, neck, or jaw 
Atypical symptoms
Pain with inspiration Subtract  points
Pain reproduced by palpation Subtract  points
Low risk, 0–15 points; non–low risk, ≥16 points. Known CAD includes previous myocardial infarction, coronary bypass surgery, or percutaneous coronary intervention or≥3 cardiac risk factors in patients age ≤50 years. Risk factors include family history of CAD in first­degree relative age <55 years, hyperlipidemia, diabetes, smoking within past  days, and hypertension.
The HEAR Score is used in conjunction with the HEART Pathway to appropriately categorize patients into low or high risk. Before calculating a HEAR
Score, obtain an ECG and review the past medical history for known CAD. If there are any ischemic changes or the patient has known CAD, the patient is in a high­risk category and does not need a more formal score (Figure 51­2). If the ECG is nonischemic and there is no known CAD, calculate a HEAR
Score to risk­stratify the patient. Patients in the low­risk category and no elevation of troponin(s) can be safely discharged home to follow up with their primary care physician within  days. Those categorized as high risk are bedded for testing to evaluate for ACS (Figure 51­2).
FIGURE 51­2. The HEART Pathway. CAD = coronary artery disease; STEMI = ST­segment elevation myocardial infarction.
Both the HEART Pathway and Emergency Department Assessment of Chest Pain Score involve use a score and an initial and a 3­hour repeat troponin to increase the sensitivity for major adverse cardiac events. This raises sensitivity for major cardiac event detection to 100% while allowing for less index visit cardiac testing (CT or stress imaging). Low­risk patients with two negative biomarkers are able to be safely discharged; others get more testing.
Newer high­sensitivity troponin assays may make this high­sensitivity approach achievable with one test or within a shorter sequential two­test interval.
DISPOSITION AFTER THE PRIMARY EVALUATION
After the primary evaluation, if the treating physician estimates that the probability of ACS is <1% to 2%, further testing for ACS is not warranted. After exclusion of other life­threatening causes of chest pain, these patients may be discharged home. These patients may benefit from primary care followup or care from another specialty physician depending on the suspected cause (e.g., GI, pulmonary).
Be wary of overconfidence in an alternative diagnosis; the rate of ACS is as high as 4% among patients with chest pain and a “clear­cut” noncardiac
 alternative diagnosis. Reserve determinations of noncardiac chest pain to patients with a very low likelihood of coronary disease (<1%) and clear evidence of an alternative diagnosis or with atypical historical features. The rest of patients with ACS­consistent symptoms should have further testing.
SECONDARY EVALUATION
Base the diagnostic plan for patients with possible ACS after the primary evaluation on the clinical data and the available resources at each facility. This may include inpatient secondary testing, hospital­based observation testing, or ED­based observation testing. Once ACS is determined to be present or likely, admission and care by an internist or cardiologist are started.
SERIAL MARKER APPROACH
Patients with possible ACS require serial serum markers to detect necrosis. The purpose of serial markers is twofold. First, evidence of myocardial necrosis confirms the diagnosis of ACS and should change treatment. Second, the presence of necrosis places the patient at higher risk for an adverse event during provocative cardiac testing. Many facilities have moved to an accelerated diagnostic protocol for serial marker timing, due to similar efficacy when compared to conventional longer protocols. Traditional testing protocols for patients with possible ACS involve obtaining serial troponins at presentation and after  hours of observation, whereas accelerated protocols repeat troponins at  or  hours. However, given the imperfect sensitivity and inability to exclude unstable angina, accelerated cardiac marker protocols are not the sole determination to exclude ACS but are used in combination with clinical decision aids and/or cardiac imaging. Again, the impact of higher­sensitivity troponin test is evolving and may alter the need for sequential tests to identify injury, even if subtle.
ADVANCED CARDIAC TESTING
Normal serial ECGs and myocardial marker measurements reduce the likelihood of acute myocardial infarction, but do not exclude unstable angina, which still puts the patient at high risk for a subsequent adverse cardiac event. Therefore, patients with possible ACS who are not identified as low risk using a validated decision aid should undergo cardiac testing to evaluate coronary anatomy, cardiac function, or both. Common modalities used include stress electrocardiography, stress echocardiography, resting and/or stress nuclear medicine testing, stress cardiac MRI, and CT coronary angiography (CTCA).
Advanced cardiac testing occurs after normal biomarkers are present and no clear ischemic ECG changes exist; this happens either as an inpatient or during an observation unit stay, with the latter being less expensive. Another option proffered by the American
College of Cardiology/American Heart Association guidelines is to do the advanced testing as an outpatient and within  hours of
ED discharge if patients are at low risk for ACS, are pain free without recurrent symptoms, have no evidence of ischemia on their

ECG, and have normal serial cardiac markers over  to  hours.
Low­risk patients may safely undergo immediate stress testing. One center performed over 3000 immediate exercise stress tests in low­risk patients
 who had at least one negative serum cardiac marker, noting no adverse events.
ECG­BASED EXERCISE TREADMILL TESTING
The accuracy of ED stress testing is particularly difficult to quantify, because test sensitivity and specificity are influenced by characteristics of the population being tested. As the pretest probability of CAD increases, the likelihood of a false­negative test also increases. Conversely, when a population with a very low pretest probability of disease is tested, the likelihood of a false­positive result increases. Based on current data, use diagnostic stress testing in patients with a low to moderate pretest probability of CAD; it is unlikely to be helpful in those at very
 low risk or at high risk (Figure 51­3).
FIGURE 51­3. Stress testing decision making for patients with possible acute coronary syndrome (ACS). CAD = coronary artery disease; sig = significant.
ECG­based exercise treadmill testing is commonly used for patients without known coronary disease. Subjects exert on a treadmill until a predetermined percentage of predicted maximum heart rate or other end points are reached. A positive exercise test shows ≥1 mm of horizontal or downsloping ST­segment depression or elevation for at least  to  milliseconds after the end of the QRS complex; ST­segment elevation is not sought because it signals acute injury (not a desired outcome), although it is diagnostic.
Sensitivity of exercise treadmill testing depends on the risk and severity of disease of the patient population to which it is applied. A meta­analysis of

,000 patient encounters identified the sensitivity and specificity for significant coronary disease as 68% and 77%, respectively. Advantages of exercise treadmill testing are low cost, wide availability, and short test performance time. Exercise stress testing is contraindicated for various reasons

(Table 51­3). Exercise testing may not be safe for patients at high risk for acute ischemia or those with other uncontrolled cardiovascular or pulmonary pathologies. Furthermore, patients with an abnormal baseline ECG, such as those with left ventricular hypertrophy, bundle branch block, or digoxin effect, are less likely to benefit from standard exercise testing due to difficulties in interpretation of exercise­induced ECG changes.
TABLE 51­3
Contraindications to Exercise Testing
Absolute
Acute myocardial infarction (within  d)
High­risk unstable angina
Uncontrolled cardiac dysrhythmias causing symptoms or hemodynamic compromise
Symptomatic severe aortic stenosis
Uncontrolled symptomatic heart failure
Acute pulmonary embolus or pulmonary infarction
Acute myocarditis or pericarditis
Acute aortic dissection
Relative* Left main coronary stenosis
Moderate stenotic valvular heart disease
Electrolyte abnormalities
Severe arterial hypertension (>200 mm Hg systolic, >110 mm Hg diastolic)
Tachydysrhythmias or bradydysrhythmias
Hypertrophic cardiomyopathy and other forms of outflow tract obstruction
Mental or physical impairment leading to inability to exercise adequately
High­degree atrioventricular block
*Relative contraindications can be superseded if the benefits of exercise outweigh the risks.
ECHOCARDIOGRAPHY
Echocardiography assesses wall motion at rest and while under stress (either exercise or pharmacologically induced); advantages over exercise treadmill testing are improved accuracy for coronary disease and nondependence on the ECG. Compared with other cardiac imaging techniques, echocardiography is noninvasive, delivers no ionizing radiation, and provides information on myocardial function.
The echocardiogram cannot distinguish between myocardial ischemia and acute infarction, cannot reliably detect subendocardial ischemia, and may be falsely interpreted as positive in the presence of several conditions (notably conduction disturbances, volume overload, heart surgery, or trauma).
Timing of the test relative to the onset of symptoms is critical, because transient wall motion abnormalities may resolve within minutes of an ischemic episode. Resting echocardiography within  hours of ED arrival does not provide additional predictive value for myocardial infarction over myocardial markers alone. A normal resting echocardiogram does not exclude ACS, although it lowers the likelihood.
Stress echocardiography combines a standard ECG stress test with cardiac imaging at rest and after exercise­induced or pharmacologically induced tachycardia. Overall, stress echocardiography is 80% sensitive and 84% specific for significant coronary disease, and superior to ECG­based stress testing. In low­risk ED patients, three studies have reported negative predictive values for subsequent cardiac events to be 97% to 100%, comparable to that of stress testing using nuclear imaging techniques.
NUCLEAR MEDICINE
Nuclear medicine techniques use an IV­injected radioactive tracer. Local myocardial uptake and images depend on regional coronary flow and myocardial cell integrity. Tracer uptake occurs in direct proportion to regional myocardial blood flow.
Thallium­201 has been in use longest and is rapidly redistributed after initial uptake. The image generated after thallium injection represents blood flow at the moment of imaging. Areas of positive uptake reflect adequate coronary flow and viable myocardium, whereas areas without uptake represent infarcted or ischemic myocardium. On repeat imaging several hours later, continued lack of perfusion (“irreversible defect”) indicates an area of infarction, and tracer uptake only on delayed images (“reversible defect”) represents ischemic but not infarcted myocardium. Combined with conventional ECG­based stress testing, thallium imaging offers improved sensitivity and specificity for detection of significant CAD over ECG­based testing alone, and it is not hampered by baseline ECG abnormalities. Thallium­based imaging must be performed soon after injection, making it impractical for use in patients with ongoing chest pain. In addition, the long half­life requires a lower injected dose to avoid excessive radiation exposure. This may impair imaging and create false­negative and false­positive results, especially in women and obese patients. Due to these limitations and the lack of ED­based outcome studies, thallium­201 imaging alone is not an ideal agent for use in the ED.
99m
Myocardial perfusion imaging using technetium­99m ( Tc)­labeled agents such as sestamibi offers advantages over thallium for ED use. Because
99m the half­life of Tc is much shorter than that of thallium (6 vs.  hours), a larger dose is possible without harm to the patient. This produces superior
99m image quality, decreased tissue attenuation–related artifacts, and higher ACS detection specificity for sestamibi imaging. In contrast to thallium, Tc is stable for several hours, allowing accurate imaging up to  hours after injection; the image represents the blood flow at the moment of injection. By using gated image acquisition technology, sestamibi scanning also estimates ejection fraction. As with thallium, resting and stress (exercise or pharmacologic) images can be compared to yield additional data.
Perfusion sestamibi imaging of patients with current or recent (within  minutes of injection) pain and no cardiac ischemia on ECG and biomarker analysis is very sensitive in detecting physiologic ischemia; a negative test allows discharge to home. This latter approach requires broader study but is promising in select patients.
Dual­isotope stress testing using thallium and sestamibi is an increasingly common component of ED ACS evaluation protocols. In this technique, a resting thallium scan is first performed. Patients without resting defects can then immediately undergo stress testing with sestamibi imaging, thereby avoiding the delay usually required for isotope “washout” in single­isotope techniques. Dual­isotope stress testing in one trial reliably identified or excluded ACS.
CARDIAC MRI
Cardiac MRI assesses wall motion, perfusion, and coronary anatomy, either at rest or after pharmacologic stress. It is noninvasive and does not expose the patients to radiation. However, cardiac MRI cannot be performed on approximately 11% of ED patients with chest pain due to contraindications such as claustrophobia and implanted metallic objects. Another limit is the longer test performance time, although this is improving with newer scanners and software. Cardiac magnetic resonance stress imaging has excellent test performance but currently is not a common tool for early ACS evaluation.
CT CORONARY ANGIOGRAPHY
CTCA allows gated images of the coronary arteries after rapid, peripheral (not central) IV contrast. Images are improved when the heart rate is <65 beats/min in 16­slice CT scanners, sometimes necessitating β­blocking medications; dual­source scanners (128­slice) can image adequately at higher heart rates but are less available. The advantages of CTCA are ready access to necessary equipment, rapid image acquisition, and the ability to image coronary structure. Notable disadvantages include ionizing radiation exposure, IV contrast exposure (and risk of allergy or kidney injury), need for specially trained technicians, and nondiagnostic scans due to nonvisualization of coronary segments. In addition, CTCA provides a limited assessment of cardiac function. CTCA­detected lesions of >50% stenosis correlate with lesions on standard left­heart angiography; this means the test offers limited information in those with known coronary disease. Patients with positive scans require confirmation either with a cardiac catheterization or a functional advanced cardiac test.
Two recent clinical trials evaluated the usefulness of CTCA in decreasing ED length of stay and assessing for serious cardiac events within  days of
,23 discharge. Both studies included patients with low to intermediate risk for ACS and considered CTCA results of <50% stenosis as negative. These trials found that patients randomized to CTCA versus traditional care had a higher rate of discharge from the ED and a decreased overall length of stay.
No significant coronary disease was missed on CTCA evaluation versus traditional stress testing, although one study found that patients with positive
CTCA findings had more overall testing and increased radiation exposure. The cost of care was similar for both groups of patients. Overall, these
,23 studies provide evidence that CTCA allows for faster and safe discharge of patients from the ED. While ED CTCA helps deliver a prompt, safe
 disposition of patients in the ED, up to 24% of patients will have nondiagnostic CTCA imaging. The ideal approach to these patients is undefined and usually reverts to the previous strategies for evaluating low­risk ACS patients.
DISPOSITION AFTER THE SECONDARY EVALUATION
Use of modern validated risk stratification tools incorporating a second troponin measurement can safely identify patients for discharge without objective testing. Those not classified as low risk should undergo further evaluation to diagnose or exclude ACS. Upon completion of these protocols, those with negative cardiac markers, no dynamic ECG changes, and negative objective cardiac testing can be safely discharged home. Patients with positive cardiac markers, diagnostic ECG changes, or diagnostic testing supporting ACS are admitted to the hospital for cardiac care. Those with nondiagnostic cardiac testing are handled on a case­by­case basis, often in conjunction with a cardiologist.
SUGGESTED FOLLOW­UP INTERVAL
Despite advanced testing, a negative evaluation does not entirely exclude ACS. Patients discharged after exclusion of ACS should be given precautions describing reasons to return to the ED. Ideally, patients should follow up with their primary care physician within the next  to  days.
DIAGNOSTIC PATHWAYS FOR PATIENTS WITH POSSIBLE ACUTE CORONARY SYNDROME
INPATIENT ADMISSION
If observation beds are unavailable, patients with possible ACS needing additional testing beyond one or two troponin measurements are admitted to an inpatient bed. Specific destinations and care level are driven by stratification; those with a prior history of CAD, evidence of congestive heart failure on physical examination, recurrent chest pain, or new or presumed new ischemic ECG changes are at higher short­term risk and may be more appropriately managed in an intermediate­care (step­down) unit.
ED OBSERVATION AND TESTING
ED observation unit management decreases hospital admissions, length of stay, and hospital cost while providing a high level of care. The traditional
 observation unit chest pain protocol was refined by Lateef and colleagues, with patients observed for  hours with continuous 12­lead ST­segment
ECG monitoring and serial creatine kinase­MB testing at , , , and  hours after presentation. Those who completed a negative 9­hour evaluation subsequently underwent echocardiography followed by graded exercise stress testing in the ED before discharge. With this approach, .1% of patients were released home from the cardiac evaluation unit. The approach of serial cardiac markers followed by objective cardiac testing remains the foundation of ED and other observation unit protocols. Although early observation unit protocols focused on low­risk patients, more recent investigations successfully studied patients with intermediate­risk chest pain.
Some observation units adequately manage patients at intermediate risk for ACS, whereas some facilities manage these patients in the hospital. Any protocol that treats all patients with possible ACS equally should incorporate serial cardiac markers and stress testing. In addition, early stress testing after a negative ultra­short cardiac marker testing strategy, or exercise stress testing after one negative cardiac marker in patients with possible ACS, appears safe in low­ and intermediate­risk patients. Finally, outpatient stress testing is an option for reliable low­risk patients in whom acute myocardial infarction has been excluded presenting to a facility where a mechanism exists to arrange this testing. Compliance with follow­up testing is
 better when scheduled before discharge.
TREATMENT
Clinical trials often do not include patients with possible ACS and instead focus on the higher­risk patients with positive cardiac markers or ST­ segment changes on their ECG. Therefore, treatment recommendations for patients with possible ACS are derived from reviewing the risk­to­benefit profile suggested from clinical trial results in the higher­risk patient populations. Additional information on the mechanisms of action and data from clinical trials are discussed in Chapter , “Acute Coronary Syndromes.”
Therapy for patients with possible ACS is linked to the patient’s stratification level. In general, patients at low risk of adverse events receive aspirin and anti­ischemic therapy with nitroglycerin while their evaluation is being completed.
SPECIAL POPULATIONS
Age, ethnic, racial, and gender differences are well described in patients presenting with ACSs. Most current knowledge of ACS­related symptoms and risk factors comes from population­based studies. Studies have suggested that women are more likely to present without chest pain and often have a prodrome of fatigue. Similarly, the elderly less often present with a chief complaint of chest pain and, less frequently, have typical chest pain. Other
  studies have noted delayed presentation for ACS in black women and less frequent chest pain with ACS in those of Asian descent. The Framingham
 criteria overestimate the risk of coronary disease when applied to Chinese patients, and these patients are less likely to experience classic symptoms of ACS. Be aware of all these confounders as you assess the clinical likelihood of ACS.


