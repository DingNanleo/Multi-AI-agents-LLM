## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 270: Elbow and Forearm Injuries
Yvonne C. Chow; Stewart W. Lee
ANATOMY
Articulations of the distal humerus and proximal ulna and radius form the elbow joint (Figure 270­1).
FIGURE 270­1. Elbow anatomy. A. Anterior view. B. Lateral view. C. Medial view.

The distal humerus is comprised of the medial and lateral condyles. The articulating surfaces of the medial and lateral condyles are the trochlea and
Chapter 270: Elbow and Forearm Injuries, Yvonne C. Chow; Stewart W. Lee t©h2e0 c2a5p iMtecllGurma,w r eHspille. cAtlilv Reliyg.h Mtse dRieaslley,r vtheed .t r o Tcehrlmeas aorft iUcuslea t * e Ps rwiviathc yth Peo olilceyc r * a Nnoonti coef t * h Ae cuclneas stoib fiolitrym a uniaxial hinge joint. Laterally, the capitellum abuts the radial head to form a pivot joint. The medial and lateral epicondyles are nonarticulating surfaces where the forearm, wrist, and digit flexors and pronators (medial), and extensor and supinator (lateral) muscles originate.
The radius and ulna articulate at their ends to form the proximal and distal radioulnar joints and are joined along their entire length by a fibrous interosseous membrane. The ulna is a fairly straight bone, whereas the radius has an important outward bowing. During supination and pronation, the radius rotates around the relatively fixed ulna. Because these bones have such a close relationship, injury to one will frequently impact the other.
Several neurovascular structures lie in proximity to the distal humerus, and evaluation of their function is essential. These include the brachial artery and the radial, median, and ulnar nerves (Table 270­1).
TABLE 270­1
Sensory and Motor Function Testing of the Radial, Median, and Ulnar Nerves
Radial Median Ulnar
Sensory function (test with 2­ Dorsum of the thumb and index Tip of the index finger Tip of the little finger point discrimination) web space
Motor function (test against Extend wrist and fingers (“Rock” “OK” sign with thumb and index finger; abduct Abduct index finger resistance) and “Paper” motions) thumb (“thumbs up” motion) (“Scissors” motion)
The neuroanatomy is best understood by appreciating the neural control of wrist and finger movements (Figure 270­2). The radial nerve travels over the lateral epicondyle into the forearm before splitting into a deep branch that pierces through the supinator muscle and a superficial branch that lies adjacent to the radial artery. The proximal portion of the radial nerve controls the more proximal function of wrist extension, the deep branch
(posterior interosseous nerve) controls the more distal function of finger and thumb extension, and the superficial branch is purely sensory, providing sensation over the dorsal aspect of the hand from the thumb to the radial half of the ring finger. Thus, an isolated injury to the posterior interosseous branch affects finger extension but spares wrist extension and sensation to the dorsum of the hand. This can be seen in a compression neuropathy to the posterior interosseous nerve at the level of the supinator muscle.
FIGURE 270­2. Neural innervation of the forearm, wrist, hand, and digits. A. Radial nerve innervation. B. Median nerve innervation. C. Ulnar nerve innervation.
The proximal portion of the median nerve controls the muscles of wrist flexion and the superficial finger flexors before it gives off the anterior interosseous nerve, which controls the radial half of the deep finger flexors and thumb flexion at the interphalangeal joint. The remaining portion of the median nerve provides sensation to the volar surface of the hand from the thumb to the radial half of the ring finger, including the dorsal tips of the thumb, index, and middle fingers. A separate motor branch (recurrent branch of the median nerve) controls the thenar muscles for thumb opposition and abduction.
The ulnar nerve innervates the forearm muscles and the intrinsic muscles of the hand while providing sensation to the little finger and the ulnar half of the ring finger. Proximal to the elbow, the ulnar nerve courses under a ligamentous band called the arcade of Struthers before entering the cubital tunnel posterior to the medial epicondyle. These are two sites where the nerve can become entrapped, leading to ulnar neuropathy syndromes. The ulnar nerve is palpable as a cord in the cubital tunnel and is vulnerable to injury with trauma over this area.
The biceps brachii muscle has two proximal heads and two distal attachments (Figure 270­3). The proximal long head originates proximal to the shoulder capsule, and the proximal short head originates at the coracoid process. The distal attachments are to the radial tuberosity by the distal biceps tendon and the forearm by the bicipital aponeurosis. The biceps muscle is innervated by the musculocutaneous nerve (C5 and C6) and functions primarily to supinate and assist in flexion of the forearm.
FIGURE 270­3. Biceps muscle anatomy.
The brachialis muscle lies deep to the biceps muscle. It is innervated by both the musculocutaneous and radial nerves (C5, C6, C7, and C8) and is the primary flexor of the forearm.
The triceps muscle has three proximal heads (Figure 270­4): a long head originating from the scapula, a lateral head, and a medial head. The triceps inserts at the olecranon via the triceps tendon. The triceps muscle is innervated by the radial nerve (C6, C7, and C8) and is the sole extensor of the forearm.
FIGURE 270­4. Triceps muscle anatomy.
The intrinsic forearm muscles include the brachioradialis, pronator teres, pronator quadratus, anconeus, and supinator (Figure 270­5). The motor functions of these muscles are summarized in Table 270­2. TABLE 270­2
Motor Functions of the Intrinsic Forearm Muscles
Muscle Function
Brachioradialis Assists with forearm flexion
Pronator teres Assists with forearm pronation and flexion
Pronator quadratus Primary forearm pronation
Anconeus Trivial forearm extension
Supinator Primary forearm supination
FIGURE 270­5. Intrinsic forearm muscles. A. Anterior forearm. B. Posterior forearm.
CLINICAL FEATURES
HISTORY
A thorough history is essential for determining the correct diagnosis in a patient with elbow or forearm pain. Onset of symptoms, mechanism of injury, exact location of pain, and associated symptoms such as numbness, weakness, or distal wrist and hand complaints are important elements to obtain.
Most acute traumatic injuries to the elbow and forearm occur due to either a fall onto an outstretched hand or a direct blow. Chronic overuse injuries should correlate with preceding activity involving a repetitive motion. A history of arthritides may point to a systemic disorder such as lupus, rheumatoid arthritis, or gout.
PHYSICAL EXAMINATION
Inspect the elbow and forearm for gross deformity, soft tissue swelling such as bursitis, or open wounds. Assess range of motion of the elbow in
 flexion, extension, pronation, and supination. Inability to fully extend the elbow is correlated with the presence of a fracture. Conversely, full range of
 motion in all four planes has high negative predictive value for fracture.
Radial, median, and ulnar nerve function can be conducted by isolated nerve testing. Test motor function against resistance. Assess sensory function using two­point discrimination. Test radial nerve motor function by having the patient extend both the wrist and fingers against resistance (Table 270­1). Assess sensation over the dorsum of the thumb index web space. Evaluate the median nerve through its distal branches— the anterior interosseous nerve and the recurrent branch of the median nerve. Assess anterior interosseous nerve function by having the patient make a circle, or “OK” sign, with the thumb and index finger. Abduction of the thumb through a “thumbs up” sign against resistance
(recurrent branch of the median nerve) and sensory testing over the tip of the index finger complete the evaluation of the median nerve. Test ulnar nerve function by having the patient spread the fingers apart against resistance; sensation is tested over the tip of the fifth digit. A simple and thorough way to assess radial, median, and ulnar nerve motor function, particularly in children, is to have the patient perform the motions of the
 game Rock, Paper, Scissors, followed by the OK sign. This routine includes the movements of wrist extension (proximal radial nerve), finger extension
(posterior interosseous nerve branch of radial nerve), finger abduction (ulnar nerve), and thumb and finger flexion (anterior interosseous nerve branch of the median nerve) described above.
DIAGNOSIS
IMAGING
Initial imaging studies should include anteroposterior and lateral views of the elbow, and anteroposterior, lateral, and oblique views of the humerus and forearm. If a distal forearm injury is present, obtain anteroposterior, lateral, and oblique views of the wrist instead of the humerus. Clinical decision rules to guide imaging decisions for the elbow, similar to published ankle and knee imaging rules, have to date produced conflicting data and
,4,5 are not helpful.
On lateral films of the elbow, a line drawn straight through the center of the radial shaft (radiocapitellar line) should bisect the radial head and capitellum (Figure 270­6A). Loss of this relationship should raise suspicion for an occult radius fracture or dislocation. A line drawn straight along the anterior border of the humerus (anterior humeral line) should transect the posterior two thirds of the capitellum (Figure 270­6B). Abnormal extension of the line through the anterior one third of the capitellum suggests a distal humerus (in adults) or supracondylar fracture (in children). A small anterior fat pad may be a normal finding. Large anterior and any posterior fat pads are always abnormal and indicate the presence of a joint effusion (Figure 270­7).
FIGURE 270­6. A. Radiocapitellar line. B. Anterior humeral line.
FIGURE 270­7. Anterior and posterior fat pad signs.

Obtain CT imaging to evaluate for fracture when plain radiographs are normal in the setting of concerning physical exam findings. CT also assists in characterizing certain elbow fractures, particularly coronoid and comminuted intra­articular fractures. MRI is useful in the evaluation of soft tissue
7­10 injuries but has a limited role in the acute setting. US can demonstrate effusions, fractures, postreduction fracture alignment, and tendon injury.
Several studies have demonstrated sensitivities and specificities of over 90% for the diagnosis of forearm and elbow fractures using point­of­care
,12
US. While it cannot completely replace plain radiography due to variations in operator skill, point­of­care US can be a powerful diagnostic adjunct in the evaluation of elbow and forearm injuries.
TREATMENT
Consult an orthopedic surgeon immediately for open fractures, irreducible dislocations, injuries resulting in a grossly unstable elbow joint, nerve injury, or vascular injury with signs of ischemia or uncontrolled hemorrhage. All other injuries may be referred for follow­up within  to  days for operative planning or up to a week for nonoperative treatment. Table 270­3 outlines guidelines for ED immobilization and appropriate orthopedic consult time frames for the conditions discussed in this chapter.
TABLE 270­3
Immobilization and Follow­Up Guidelines
Injury Splint Referral
Soft tissue injuries
Biceps tendon rupture Sling immobilization  wk
Triceps tendon rupture Sling immobilization  wk
Lateral/medial epicondylitis Rigid wrist brace, forearm counterforce brace 2–4 wk PRN
Elbow dislocation
Stable/postreduction Long arm posterior splint, elbow slightly less than  degrees, forearm neutral 1–2 d
Unstable/postreduction Long arm posterior splint (presurgical stabilization) Immediate
Irreducible Long arm posterior splint (presurgical stabilization) Immediate
Elbow fractures
Distal humerus nondisplaced Long arm posterior splint, forearm neutral  wk
Supracondylar Long arm posterior splint (presurgical stabilization) <24 h
Intercondylar Long arm posterior splint, forearm neutral 1–2 d
Lateral condyle/epicondyle
Nondisplaced Long arm posterior splint, forearm in supination 1–2 d
Displaced Long arm posterior splint (presurgical stabilization) Immediate
Medial condyle/epicondyle
Nondisplaced Long arm posterior splint, forearm in pronation 1–2 d
Displaced Long arm posterior splint (presurgical stabilization) Immediate
Articular surface Long arm posterior splint, forearm neutral 1–2 d
Coronoid
Nondisplaced or minimally displaced Long arm posterior splint, elbow past  degrees, forearm in supination 1–2 d
Markedly displaced or unstable Long arm posterior splint (presurgical stabilization) Immediate
Olecranon Long arm posterior splint, forearm neutral <24 h
Radial head
Nondisplaced Sling immobilization with early range of motion  wk
Displaced or range of motion block Long arm posterior splint, forearm neutral <24 h
Forearm fractures
Both bones
Pediatric
Greenstick Long arm posterior splint  wk
Displaced Long arm posterior splint Immediate
Adult
Nondisplaced Sugar­tong splint  wk
Displaced Long arm posterior splint (presurgical stabilization) <24 h
Isolated ulna shaft Long arm posterior splint, forearm neutral or Sugar­tong splint if stable and nondisplaced  wk
Proximal two thirds of radius
Nondisplaced Long arm posterior splint, forearm neutral  wk
Displaced Long arm posterior splint, forearm neutral 1–2 d
Monteggia’s Long arm posterior splint (presurgical stabilization) Immediate
Galeazzi’s Long arm posterior splint (presurgical stabilization) Immediate
SOFT TISSUE INJURIES
BICEPS TENDON RUPTURE
Most biceps injuries are proximal, and nearly all of these involve the proximal long head. Injuries usually manifest as tendinopathies from repetitive microtrauma and overuse. The classic mechanism leading to tendon rupture is a sudden or prolonged contraction against resistance in middle­aged and older individuals with a history of chronic biceps tendinopathy. A snap or pop is usually described, and pain is present in the anterior shoulder.
Examination of the anterior shoulder will reveal swelling, tenderness, and often crepitus over the bicipital groove. Ecchymosis may extend the entire length of the biceps. Flexion of the elbow will elicit pain and may produce a midarm “ball,” which represents the distally retracted biceps muscle. Comparing arms for symmetry helps. Loss of flexion strength is minimal, due to the preserved functions of the brachialis and supinator. Avulsion fractures occasionally occur, so radiographs of the shoulder should be obtained.
ED treatment includes sling, ice, analgesics, and referral to an orthopedic surgeon for definitive care.

Distal biceps injuries are less common than proximal injuries. Complete distal tendon ruptures are most common in middle­aged men and usually involve the dominant extremity. Partial tears are seen in men and women. Mechanism of injury is typically a sudden eccentric (extension) load applied to a flexed elbow. Pain is felt in the antecubital fossa, with swelling, ecchymosis, and tenderness to palpation noted on examination. A palpable defect in the antecubital fossa and a midarm “ball” may be present. Strength loss, especially supination, is more notable than with proximal ruptures. The
 biceps squeeze test, similar to the Thompson test for assessing Achilles tendon rupture, can detect biceps rupture. With the patient seated and the forearm at  to  degrees of flexion, place one hand on the muscle belly of the biceps and the other hand on the myotendinous junction, and squeeze with both hands. The squeeze should result in forearm supination. Lack of supination is considered a positive test, indicating rupture of the
 distal biceps tendon. To perform the hook test, flex the patient’s elbow to  degrees. During active supination, if the biceps tendon is intact, the examiner can “hook” the index finger under a cord­like structure in the antecubital fossa. Obtain elbow radiographs to search for an associated
,17 avulsion fracture. Although most complete distal ruptures are diagnosed clinically, US can aid in confirming the diagnosis of partial tears.
ED treatment includes sling, ice, analgesics, and referral to an orthopedic surgeon for definitive care. Although distal biceps ruptures were historically
 treated with surgery, management can be either surgical or conservative, depending on the patient.
TRICEPS TENDON RUPTURE

Injury to the triceps is rare and almost always occurs distally. Ruptures result from either a fall on an outstretched hand causing a forceful flexion of an extended elbow or a direct blow to the olecranon. Pain is felt in the posterior elbow. Examination of the elbow reveals posterior swelling and tenderness, just proximal to the olecranon. A sulcus with a more proximal mass, representing the retracted triceps muscle, may be palpable. With partial tears, some degree of function remains; however, with complete ruptures, the ability to extend the elbow is lost. A modified
Thompson test can be used to evaluate triceps function. The upper extremity is positioned such that the arm is supported and the forearm is hanging in a relaxed position with  degrees of flexion. Squeezing the triceps muscle should produce extension of the forearm, unless a complete rupture is present. Radiographs of the elbow are needed because avulsion fractures of the olecranon are common. Point­of­care US can aid in diagnosis,
,21 especially of partial tears.
ED treatment includes sling, ice, analgesics, and referral to an orthopedic surgeon for definitive care. Complete ruptures require surgical repair, whereas most partial tears can be treated conservatively with immobilization.
LATERAL EPICONDYLITIS
Lateral epicondylitis, or “tennis elbow,” is an overuse syndrome affecting the wrist and digit extensors and the forearm supinators. The diagnosis is made clinically by tenderness over the lateral epicondyle and pain with resisted wrist extension, digit extension, and forearm supination. Treatment is usually conservative, with rest, friction massage, anti­inflammatory medications, immobilization with a rigid wrist brace to limit wrist extension or a
22­24 counterforce forearm brace, and physical therapy. Refer to an orthopedic surgeon or sports medicine specialist for follow­up care.
MEDIAL EPICONDYLITIS
The less common counterpart to lateral epicondylitis is medial epicondylitis (“golfer’s elbow”). As with lateral epicondylitis, the diagnosis is made clinically. Tenderness over the medial epicondyle and pain with resisted wrist flexion and forearm pronation are expected, as these are the muscle groups affected. In addition, patients may develop an ulnar neuropathy, given the proximity of the ulnar nerve to the medial epicondyle. Ulnar neuropathy requires orthopedic follow­up. Treatment is similar to that of lateral epicondylitis, with rest, anti­inflammatory medications, bracing, and physical therapy.
ELBOW DISLOCATION
The elbow is one of the more stable joints. The muscular attachments, lateral collateral ligament, and medial ulnar collateral ligament augment its inherent stability in the flexion­extension plane. Dislocations of the elbow rank third in large­joint dislocations, after glenohumeral and patellofemoral dislocations. The mechanism of injury is usually a fall on an outstretched hand. Approximately 90% of all elbow dislocations are
 posterolateral. Fractures of the coronoid process, radial head, medial epicondyle, and olecranon can complicate the treatment of elbow dislocations. The “terrible triad” injury consists of an elbow dislocation coupled with fractures of the radial head and coronoid. This injury creates an unstable joint and requires emergent orthopedic consultation.
Clinically, the patient presents with the elbow in  degrees of flexion. The olecranon is prominent posteriorly, and the deformity resembles a displaced supracondylar fracture. If the patient is seen immediately after the injury, the bony landmarks can be identified. Later, however, the swelling may be quite severe, with no possibility of evaluating the injury topographically. The priority is to assess the neurovascular status of the brachial artery, ulnar nerve, and median nerve, as these structures may become entrapped. Perform neurovascular examination before and after manipulation. Neurologic complications most frequently involve the ulnar nerve and occur in up to 20% of elbow dislocations. Brachial artery
 injuries are estimated to occur in 5% to 13% of elbow dislocations. Absence of a radial pulse before reduction, an open dislocation, and systemic
,28 injuries (such as those of the head, chest, and abdomen) are findings associated with arterial injury. If vascular injury is suspected, then angiography may be required to assess the extent of injury and need for repair.
On the lateral radiograph, both the ulna and radius are displaced posteriorly (Figure 270­8). In the anteroposterior view, there may be lateral or medial displacement, with the ulna and radius in their normal relationship to each other. Assess for associated fractures, particularly of the coronoid process and radial head.
FIGURE 270­8. Posterior elbow dislocation.
Due to the amount of force that is necessary to reduce a dislocated elbow, success often depends on IV analgesia or procedural sedation. Intraarticular lidocaine is also helpful for closed reduction of dislocated elbows. Regardless of the type of analgesia used, ensure appropriate patient comfort prior to attempting closed reduction.
Closed reduction can be accomplished by several methods. In the first two­person reduction technique, position the forearm supine. While an assistant applies a stabilizing countertraction force on the upper arm, use one hand to apply a longitudinal traction on the wrist and forearm (Figure
270­9). With the other hand, manipulate the elbow to correct any medial or lateral displacement. Then apply slow and steady downward pressure to the proximal forearm with the other hand to help disengage the coronoid process from the olecranon fossa. Continue distal traction and flex the elbow. In the second two­person technique, the patient is prone with the arm abducted and the elbow slightly flexed. The patient may also be supine with the arm adducted across the torso and the elbow slightly flexed (Figure 270­10). Have an assistant apply longitudinal traction on the wrist and forearm. Then, grasp the elbow, positioning both thumbs on the olecranon, and apply firm pressure against the olecranon to push it up and over the trochlea and back into anatomic position. Apply countertraction with the fingers against the distal humerus. A preliminary report described a singleperson reduction technique with the patient in a seated position (Figure 270­11). Place an elbow in the patient’s antecubital fossa, then grasp the patient’s hand or wrist. Flex the patient’s forearm while leveraging a force into the antecubital fossa to bring the olecranon back into anatomic position. As this is a preliminary report of the technique, success and complication rates are not known with certainty. The last technique is a modification of the Stimson hanging technique used in shoulder reductions (Figure 270­12). Place the patient prone with the elbow flexed over the edge of the stretcher. Support the humerus proximal to the elbow with a folded blanket or pillow. Suspend 5­lb weights from the wrist. The patient’s elbow should reduce over a period of several minutes. Gentle manipulation may be applied to the olecranon to aid reduction.
FIGURE 270­9. Traction and flexion reduction method. A. Side­to­side manipulation is used to correct medial or lateral displacement. B. The elbow is then flexed while maintaining longitudinal traction.
FIGURE 270­10. Olecranon manipulation reduction method with the patient positioned (A) prone or (B) supine.
FIGURE 270­11. Single­person reduction method.
FIGURE 270­12. A. Hanging arm reduction method. B. Gentle manipulation can be applied to the olecranon if necessary.
With reduction, a palpable “clunk” is felt as the olecranon is seated back in the trochlea. Move the elbow through its full range of motion to assess stability. Obtain postreduction films to determine reduction and identify fractures not previously identified. Inability to maintain reduction necessitates emergency orthopedic consultation. If the joint is stable and good neurovascular status has been confirmed, splint with a long arm posterior splint with the forearm and wrist both in neutral position and the elbow at slightly less than  degrees of flexion. Arrange orthopedic follow­
,30 up in  to  days.
Obtain emergency orthopedic consultation for irreducible dislocations, neurovascular compromise, postreduction instability, associated fractures, and open dislocations.
FRACTURES ABOUT THE ELBOW
Elbow fractures can be divided into those of the distal humerus, proximal ulna, and proximal radius. The distal humerus includes the condylar structures and the articular surface (trochlea and capitellum). The proximal ulna includes the coronoid process and olecranon, and the proximal radius is essentially the radial head.
Radiographs of fractures about the elbow may reveal abnormal fat pads (Figure 270­7). A traumatic hemarthrosis displaces fat from the olecranon fossa posteriorly (posterior fat pad), and the anterior fat pad may become prominent (“sail sign”). However, abnormal fat pads may also be seen with nontraumatic joint effusions. Furthermore, they may be absent in severe trauma that disrupts the joint capsule and allows intra­articular fluid extravasation. In some nondisplaced fractures, the fracture line may not be seen, with the fat pad sign being the only evidence of injury. Treatment is initiated as though a fracture were identified, with splint immobilization and orthopedic consultation.
DISTAL HUMERUS FRACTURES
Routine ED care of nondisplaced distal humerus fractures with normal neurovascular function includes immobilization, ice, elevation, analgesics, and orthopedic referral. Displaced fractures or those with neurovascular compromise require immediate orthopedic consultation. See Chapter 271,
“Shoulder and Humerus Injuries,” for a detailed discussion of shoulder and humerus injuries.
SUPRACONDYLAR FRACTURES
Supracondylar fractures are the most common fracture about the elbow in children between  and  years of age, but can occur in adults, especially from high­velocity injuries. Fractures can be either extension type (>95%), which are displaced posteriorly, or flexion type (<5%), which are displaced anteriorly. Treatment varies widely between nonoperative management to emergent surgical management. In 2014, the American Academy of
Orthopedic Surgeons developed recommendations on the management of supracondylar fractures based on various clinical scenarios called the

Appropriate Use Criteria for the Management of Pediatric Supracondylar Humerus Fractures. Due to the complexity of these guidelines, the authors recommend emergency orthopedics consultation. However, a more conservative approach with urgent, rather than emergent, fixation has become more common. Treatment largely depends on the degree of displacement of the distal fragment and any concurrent neurovascular or soft tissue injury.
EXTENSION­TYPE SUPRACONDYLAR FRACTURES
Injuries most often occur with a fall on an outstretched hand with the elbow in full extension. Examination reveals significant edema and tenderness at the elbow, a prominent olecranon, and a depression proximal to the elbow. The appearance may be easily mistaken for a posterior elbow dislocation.
Nondisplaced fractures may be subtle and diagnosed only by the presence of a posterior fat pad, anterior “sail sign,” or disruption to the normal path of the anterior humeral line. Initially treat with immobilization using a long arm posterior splint, keeping the elbow at  degrees of flexion and the forearm in neutral rotation, followed by outpatient referral for casting. The presence of >20 degrees of angulation necessitates orthopedic
 consultation for reduction under anesthesia and possible pin fixation. In displaced fractures, the distal fragment will be displaced proximally and posteriorly. More severely displaced fractures may show medial or lateral displacement or rotation along the axis of the humerus (Figure 270­13).
Displaced fractures must be reduced and require orthopedic consultation. Historically, these fractures were treated with immediate reduction and pinning. However, there is now a trend toward delayed reduction and fixation up to  hours after injury without evidence of
,33­36 complication, thus lessening the need for emergent orthopedic intervention. Indications for emergent consultation are vascular insufficiency or decreased perfusion, nerve injury, open fracture, or an irreducible fracture. Admit patients with displaced fractures or significant soft tissue swelling for observation of neurovascular function.
FIGURE 270­13. Extension­type, displaced supracondylar fracture.
FLEXION­TYPE SUPRACONDYLAR FRACTURES
Flexion­type fractures are rare. The mechanism of injury is a direct anterior force against a flexed elbow, resulting in anterior displacement of the distal fragment. Because the mechanism is direct force, these fractures are often open. Management of flexion­type fractures is identical to that for extension­type fractures, with the same criteria for determining emergent versus urgent orthopedic consult. Flexion­type injuries are more likely to
 require open reduction and pinning, particularly if an associated ulnar nerve injury is present.
COMPLICATIONS OF SUPRACONDYLAR FRACTURES
There are numerous potential complications of supracondylar fractures (Table 270­4). Neurologic complications—resulting from traction, direct
 trauma, or nerve ischemia—have an incidence of 10% to 20%. Ulnar nerve injuries are uncommon, with the highest incidence reported iatrogenically from pin placement. Posteromedial displacement may involve the radial nerve, and posterolateral displacement can affect the median nerve. There is a high incidence of anterior interosseous nerve injuries with supracondylar fractures. The mechanism of injury is usually traction or contusion. Complete transection is rare, and entrapment within the fracture occurs only occasionally. Because there is no sensory component to
 the anterior interosseous nerve, the injury can only be identified through motor testing by making the “OK” sign.
TABLE 270­4
Complications of Supracondylar Fractures
Early complications Neurologic
Radial nerve injury
Median nerve injury (anterior interosseous branch)
Ulnar nerve injury (iatrogenic)
Vascular
Brachial artery injury
Volkmann’s ischemic contracture (compartment syndrome of the forearm)
Late complications Nonunion
Malunion
Myositis ossificans
Loss of motion
Always suspect acute neurovascular injuries in patients with supracondylar fractures. Absence of a radial pulse is an indicator of brachial artery injury,
 even if the hand appears warm, pink, and well perfused. Injury can be due to a partial or complete transection, an intimal tear and thrombosis, or entrapment within the fracture fragment of the brachial artery. Suspected or actual neurovascular injury requires emergency orthopedic
,42 consultation.
The most serious complication is a compartment syndrome of the forearm, also known as Volkmann’s ischemic contracture. This classically occurs following a displaced supracondylar fracture. Postischemic swelling increases pressure within the enclosed osteofascial forearm compartment and reduces capillary blood perfusion below the level necessary for tissue viability. If unrelieved, the result is muscle and nerve necrosis and eventual replacement by fibrotic tissue, producing a contracture. Refusal to open the hand, pain with passive extension of the fingers, and forearm pain out of proportion to exam findings are signs of impending Volkmann’s ischemia. Extremities with signs of ischemia require emergency orthopedic consultation.
INTERCONDYLAR FRACTURES
Intercondylar fractures, in which the condylar fragments are separated, are much more common in adults than in children. Assume any distal humerus fracture in an adult to be intercondylar rather than supracondylar. The mechanism of injury is a force directed against the posterior elbow. This drives the olecranon against the humeral articular surface, separating the condyles and producing the fracture. Carefully search for a fracture line separating the condyles from each other and from the humerus. All intercondylar fractures involve the articular surface. CT imaging is useful for identifying comminuted fractures and for planning operative therapy for displaced fractures. Treatment is dependent on the amount of displacement of the fracture fragments.
Nondisplaced intercondylar fractures are stable and can be treated initially with immobilization in a long arm posterior splint with the elbow flexed at
 degrees and the forearm in neutral position. Obtain orthopedic consultation for treatment of displaced, rotated, or comminuted fractures or severe
 edema.
EPICONDYLE FRACTURES
Lateral epicondyle fractures are uncommon, because the anatomic position of the condyle reduces its exposure to direct blows. When they do occur, lateral epicondyle fractures are usually avulsion fractures. These can be treated with immobilization in a long arm posterior splint, with the elbow flexed to  degrees and the forearm in supination, and orthopedic referral.
Isolated medial epicondyle fractures are considered extra­articular injuries and usually occur in children and adolescents. Mechanisms include a posterior elbow dislocation, repeated valgus stress such as throwing a baseball (Little League elbow), or a direct blow. If there is an associated tear of the medial (ulnar) collateral ligament, the epicondyle itself may become entrapped in the joint space. Patients present with pain over the medial elbow that is exacerbated by supination of the forearm and flexion of the forearm, wrist, and digits. Edema and tenderness are noted in the same area.
Carefully test neurovascular function. Obtain standard radiographs with special attention to any intra­articular fragment. Comparison views of the unaffected contralateral elbow may be helpful for diagnosis.
Treat stable, nondisplaced or minimally displaced fractures from a low­energy mechanism nonoperatively, with early range of motion. ED treatment consists of long arm posterior splint immobilization, with the forearm in flexion and pronation, and orthopedic referral. High­energy injuries, open fractures, unstable joints, significant fragment displacement, an intra­articular fragment, and ulnar neuropathy are indications for emergency
44­46 orthopedic consultation. Because surgical treatment should be determined on an individual basis, orthopedic consultation is recommended for all epicondyle fractures.
CONDYLE FRACTURES

Lateral condyle fractures occur in children and are more common than their medial counterpart. They result from either a direct blow to the lateral elbow or from a fall on an outstretched hand. Patients complain of pain in the lateral elbow, and swelling is noted in the same area.
Medial condyle fractures are uncommon and are mostly limited to children. Mechanism of injury is from either a fall on an outstretched hand or excessive valgus stress. Medial pain and swelling are the prominent findings. The injury is often confused with the more common medial epicondyle fracture for two reasons. First, the mechanism and examination findings are similar. Second, because the trochlea ossification center does not appear until age  to  years old, it is often missed on radiographs.
ED care of nondisplaced condyle fractures with normal neurovascular function includes long arm posterior splint immobilization, ice, elevation, analgesics, and orthopedic referral. Follow­up imaging every  weeks is recommended due to the risk of late displacement, which is treated with surgical fixation. Displaced fractures or those with neurovascular compromise require immediate orthopedic consultation.
ARTICULAR SURFACE FRACTURES
TROCHLEA AND CAPITELLUM FRACTURES
Isolated trochlea fractures are rare and are often associated with other elbow injuries, such as posterior elbow dislocations. Physical findings usually include swelling, tenderness, and limited movement of the elbow joint. Radiographic findings can be subtle, and CT or MRI may be required for diagnosis.
Isolated capitellum fractures are also rare. They are usually associated with radial head fractures. Pain is present over the lateral elbow, and examination reveals lateral swelling, tenderness, and limitation of flexion and extension. If pain and tenderness are present medially, then suspect injury to the medial (ulnar) collateral ligament. Radiographic findings may be subtle and are best seen on a lateral view. The capitellum has no tendinous or ligamentous attachments, so many fractures are nondisplaced. A radial head–capitellum view can be helpful in addition to standard anteroposterior and lateral views. CT imaging is useful for diagnosis.
ED treatment of articular surface fractures includes long arm posterior splint immobilization and orthopedic consultation. Complications are common and include limited flexion and extension, elbow joint instability, avascular necrosis, nonunion, and arthritis.
PROXIMAL ULNA FRACTURES
Nearly all proximal ulna fractures are considered intra­articular, except for proximal olecranon chip fractures.
CORONOID FRACTURES
Coronoid fractures are usually associated with posterior elbow dislocations as the trochlea impacts the coronoid. Rarely, a coronoid fracture can occur
 as an isolated injury secondary to elbow hyperextension. There is pain, swelling, and tenderness over the antecubital fossa. Radiographic visualization is best with lateral and oblique films. CT is often needed to make the diagnosis.
ED treatment should include long arm posterior splint immobilization with the elbow in flexion and the forearm in supination, ice, elevation, analgesics, and referral to an orthopedic surgeon within  hours. Due to the critical role the coronoid plays in elbow stability, early orthopedic referral
 is indicated even for isolated, nondisplaced fractures. Displaced fractures or those with joint instability require open reduction and internal fixation and frequently have poor outcomes.
OLECRANON FRACTURES

Olecranon fractures represent up to 10% of upper extremity fractures. The mechanism is usually direct trauma or by a fall with forced hyperextension of the elbow. Associated injuries are common, including open fractures, dislocations, other fractures (especially of the radial head), and ulnar nerve injury. Pain is present over the posterior elbow, and examination reveals swelling, tenderness, and occasionally crepitus. Because the triceps muscle inserts at the olecranon, elbow extension can be compromised. It is important to test extension against resistance, as the patient may falsely appear to have intact extension function by using gravity to draw the forearm down. Ulnar nerve injury is common; therefore, a careful neurologic examination is required. Lateral radiographs offer the best view of the olecranon. In adolescents, the epiphysis ossifies by  years of age and fuses by  years of age, so comparison films and the appearance of an abnormal fat pad can aid in the diagnosis. ED treatment includes long arm posterior splint immobilization with the elbow in flexion and forearm neutral, ice, elevation, analgesics, and referral to an orthopedist within  hours.
Stable, nondisplaced fractures with intact extensor function can be treated conservatively with immobilization. Nonoperative treatment may also be
 considered for elderly patients who are poor candidates for surgery. All other olecranon fractures require surgical repair.
RADIAL HEAD FRACTURES
Radial head fractures are the most common fractures of the elbow. They result from a fall on an outstretched hand, causing the radial head to drive into the capitellum. Associated injuries are common and may include capitellum, olecranon, and coronoid fractures, medial collateral ligament injury, medial epicondyle avulsion fracture, and elbow dislocation. A specific associated injury, the Essex­Lopresti lesion, occurs when there is disruption of the triangular fibrocartilage complex of the wrist and the interosseous membrane between the radius and ulna, causing dissociation of the distal radioulnar joint. This is analogous to a Maisonneuve injury in the lower extremity. Do not miss this injury. Failure to recognize this injury can result in proximal migration of the radius, so obtain emergency orthopedic consultation.
Radial head fractures cause pain in the lateral elbow, especially with pronation and supination of the forearm. On examination, there may be swelling laterally and tenderness with palpation of the radial head. Pronating and supinating the forearm with the elbow flexed allows the examiner to palpate the radial head. On standard elbow radiographs, radial head fractures may be subtle (Figure 270­14). Radiographic clues include the presence of an abnormal fat pad or abnormal displacement of the radiocapitellar line away from the center of the capitellum (Figure 270­7). This is especially helpful in children whose epiphysis has not fused. Additional images, including obliques and a radial head–capitellum view, may be helpful.
FIGURE 270­14. Subtle radial head fracture and anterior fat pad sign (arrow).
Nondisplaced fractures can be treated conservatively with immobilization and early range of motion exercises to avoid the development of a stiff joint.
ED treatment consists of sling immobilization, ice, elevation, analgesics, and referral to an orthopedic surgeon or sports medicine specialist within 
 week. Consider aspiration of the joint hematoma in the ED to improve pain and facilitate early mobilization. For displaced fractures or those with restricted range of motion, surgical repair is generally indicated, and orthopedic referral should be made within  hours. Complications of radial head fracture include chronic pain and restricted range of motion at the elbow.
FOREARM FRACTURES
In adults, solitary fractures of the forearm are uncommon due to the close relationship of the radius and ulna. The fibrous interconnection between the radius and ulna transmits force above and below the injury. As a result, fractures usually occur at two or more sites or involve ligamentous injury or joint dislocation. Because distant structures are commonly injured, examine joints above and below the involved bones both clinically and radiologically. Be suspicious for associated injuries if there is significant angulation of the fracture.
FRACTURES OF BOTH RADIUS AND ULNA
A large amount of force is necessary to fracture both the radius and the ulna. This occurs most often from vehicular trauma, falls from a height, or a direct blow. Force magnitude determines the injury type. Moderate forces produce transverse or mildly oblique fractures. High­impact forces produce comminuted and segmental fractures (often displaced).
Nondisplaced fractures of both bones are exceedingly rare, because the force necessary to produce the injury is also sufficient to displace the bones.
Examination of the forearm reveals swelling, deformity, and tenderness. Carefully assess the neurovascular status. Nerve injuries can occur with severe open fractures, but are uncommon with closed injuries. Because of the excellent collateral circulation of the forearm, vascular compromise is generally not a major concern if either the radial or ulnar circulation is intact.
The fractures are clearly visible on radiographs. Note the degree of angulation, displacement, and shortening. Changes in rotational alignment may be subtle. Assessing the orientation of bony prominences on the radius and ulna can help determine rotational alignment. On the anteroposterior view, the radial styloid and radial (bicipital) tuberosity normally point in opposite directions, whereas the ulnar styloid and coronoid process do so on the lateral view. A change in this arrangement suggests rotation malalignment. Because these bones are oblong rather than circular in their cross­sectional appearance, a sudden change in the bone’s width at the fracture site is another clue to a rotational deformity. Obtain radiographs of the wrist and elbow because of the likelihood of an associated dislocation or articular fracture.
Treatment depends on the type of fracture. Torus or greenstick fractures with minimal angulation in children can be treated with immobilization in a long arm splint. Angulation >15 degrees warrants referral for closed reduction. In younger children, treat displaced fractures with closed reduction and cast immobilization due to the continued remodeling that occurs after fracture healing. Perform closed reduction urgently in the ED to ensure appropriate alignment. Traditionally, closed reduction is performed by an orthopedic consultant, but reductions performed by emergency physicians
 for nonoverlapping fractures have also been show shown to have good outcomes. Surgical intervention is indicated if acceptable reduction cannot
 be achieved through closed reduction and casting. Nondisplaced fractures in adults can be immobilized with a long arm splint and referred for urgent follow­up. All other fractures in adults require orthopedic consultation, ideally within  to  hours.
Complications include reduced ability to supinate and pronate, osteomyelitis, nonunion, malunion, neurovascular injury, and compartment syndrome. Recognizing the development of a compartment syndrome is particularly important to prevent Volkmann’s ischemic contractures of the forearm. Direct measurements of elevated compartment pressures confirm the diagnosis. Emergent orthopedic consultation for fasciotomy is required.
ULNA FRACTURES
ISOLATED ULNA FRACTURE (NIGHTSTICK FRACTURE)
Isolated fractures of the ulna most often result from a direct blow to the forearm. A fracture resulting from the natural response to raise the forearm in defense of a strike is referred to as a nightstick fracture. Nondisplaced fractures are immobilized in a sugar­tong splint and closely followed for subsequent displacement.

Fractures with >50% displacement, with >10% angulation, or that involve the proximal third of the ulna are considered unstable.
Obtain orthopedic consultation for unstable fractures. Assess for any concomitant radius fracture or dislocation.
MONTEGGIA’S FRACTURE­DISLOCATION
Fracture of the proximal third of the ulna with a radial head dislocation is referred to as Monteggia’s fracture­dislocation (Figure 270­15). The
 associated radial head dislocation may be easily missed. Missing the radial head dislocation can lead to chronic pain, limited range of motion, and, possibly, radial head excision as treatment. Monteggia’s fracture­dislocations occur following a fall onto an outstretched hand or a direct blow. Clinically, there is considerable pain and swelling at the elbow. The radial head may be palpable in an anterolateral or posterolateral location. The forearm may appear shortened and angulated. The ulnar fracture is clearly visible on radiographs and may overshadow the less obvious radial head dislocation. An abnormal radiocapitellar line may aid in the diagnosis. Additionally, the apex of the ulna fracture points in the direction of the radial head dislocation to provide another radiographic clue.
FIGURE 270­15. Monteggia’s fracture­dislocation. The angulation of the comminuted fracture of the proximal ulna points in the direction of the radial head dislocation.
Obtain consultation with an orthopedic surgeon. Monteggia’s fracture­dislocations are generally treated with open reduction and internal fixation of the ulna fracture and closed reduction of the radial head dislocation. Complications include nonunion, recurrent dislocation, chronic pain, infection, and paralysis of the posterior interosseous nerve, the deep branch of the radial nerve that controls finger extension.
RADIUS FRACTURES
FRACTURES OF THE PROXIMAL TWO THIRDS OF THE RADIUS
Radius fractures can be divided into those in the proximal two thirds and those in the distal one third of the bone. Excluding radial head fractures, isolated fractures of the proximal two thirds of the radius are uncommon because the radius is relatively well protected from direct blows by the ulna and surrounding forearm musculature. Fractures of the proximal two thirds of the radius are often displaced by both the force of the injury and the action of the forearm supinators and pronators on the radius. Typically, supination of the proximal segment and pronation of the distal segment are seen, although a fracture located beyond these muscle groups may have minimal deformity. Displaced fractures require emergent orthopedic consultation. Nondisplaced fractures are treated with cast immobilization. Compartment syndrome is rare with these fractures. Most complications involve malunion or nonunion because of inadequate or lost reduction.
GALEAZZI’S FRACTURE­DISLOCATION
Fracture of the distal third of the radial shaft accompanied by a dislocation of the distal radioulnar joint is known as Galeazzi’s fracture­dislocation
(Figure 270­16). This injury results from falls on the outstretched hand in forced pronation or from a direct blow. Galeazzi’s fracture­dislocation is
 also referred to as Piedmont fracture,reverse Monteggia’s fracture, or fracture of necessity, reflecting the need for surgical intervention. There is localized tenderness and swelling over the distal radius and wrist. The radius fracture usually results in dorsal lateral angulation. The distal radioulnar joint injury can be subtle. Radiographs may show only a slightly increased distal radioulnar joint space on the anteroposterior view. On the lateral view, the ulna is displaced dorsally. Obtain immediate orthopedic consultation in the ED. Complications include infection, nonunion, and malunion. If the radius heals with a rotational deformity, there may be pain at the distal radioulnar joint with extreme pronation and supination.
FIGURE 270­16. Galeazzi’s fracture­dislocation.
Acknowledgments
The authors wish to recognize the contributions of Harold Chin, MD; Arthur F. Proust, MD; Jason H. Bredenkamp, MD; Brian P. Jokhy, MD; and Dennis
T. Uehara, MD, MS, in previous editions of this chapter, and of Sue Lahey, MLS, for her research assistance.


## Page 2

Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 270: Elbow and Forearm Injuries
Yvonne C. Chow; Stewart W. Lee
ANATOMY
Articulations of the distal humerus and proximal ulna and radius form the elbow joint (Figure 270­1).
FIGURE 270­1. Elbow anatomy. A. Anterior view. B. Lateral view. C. Medial view.
University of Pittsburgh
Access Provided by:
The distal humerus is comprised of the medial and lateral condyles. The articulating surfaces of the medial and lateral condyles are the trochlea and the capitellum, respectively. Medially, the trochlea articulates with the olecranon of the ulna to form a uniaxial hinge joint. Laterally, the capitellum abuts the radial head to form a pivot joint. The medial and lateral epicondyles are nonarticulating surfaces where the forearm, wrist, and digit flexors and pronators (medial), and extensor and supinator (lateral) muscles originate.
The radius and ulna articulate at their ends to form the proximal and distal radioulnar joints and are joined along their entire length by a fibrous interosseous membrane. The ulna is a fairly straight bone, whereas the radius has an important outward bowing. During supination and pronation, the radius rotates around the relatively fixed ulna. Because these bones have such a close relationship, injury to one will frequently impact the other.
Several neurovascular structures lie in proximity to the distal humerus, and evaluation of their function is essential. These include the brachial artery and the radial, median, and ulnar nerves (Table 270­1).
TABLE 270­1
Sensory and Motor Function Testing of the Radial, Median, and Ulnar Nerves
Radial Median Ulnar
Sensory function (test with 2­ Dorsum of the thumb and index Tip of the index finger Tip of the little finger point discrimination) web space
Motor function (test against Extend wrist and fingers (“Rock” “OK” sign with thumb and index finger; abduct Abduct index finger resistance) and “Paper” motions) thumb (“thumbs up” motion) (“Scissors” motion)
The neuroanatomy is best understood by appreciating the neural control of wrist and finger movements (Figure 270­2). The radial nerve travels over the lateral epicondyle into the forearm before splitting into a deep branch that pierces through the supinator muscle and a superficial branch that lies adjacent to the radial artery. The proximal portion of the radial nerve controls the more proximal function of wrist extension, the deep branch
(posterior interosseous nerve) controls the more distal function of finger and thumb extension, and the superficial branch is purely sensory, providing sensation over the dorsal aspect of the hand from the thumb to the radial half of the ring finger. Thus, an isolated injury to the posterior interosseous branch affects finger extension but spares wrist extension and sensation to the dorsum of the hand. This can be seen in a compression neuropathy to the posterior interosseous nerve at the level of the supinator muscle.
FIGURE 270­2. Neural innervation of the forearm, wrist, hand, and digits. A. Radial nerve innervation. B. Median nerve innervation. C. Ulnar nerve innervation.

Chapter 270: Elbow and Forearm Injuries, Yvonne C. Chow; Stewart W. Lee 
. Terms of Use * Privacy Policy * Notice * Accessibility
The proximal portion of the median nerve controls the muscles of wrist flexion and the superficial finger flexors before it gives off the anterior interosseous nerve, which controls the radial half of the deep finger flexors and thumb flexion at the interphalangeal joint. The remaining portion of the median nerve provides sensation to the volar surface of the hand from the thumb to the radial half of the ring finger, including the dorsal tips of the thumb, index, and middle fingers. A separate motor branch (recurrent branch of the median nerve) controls the thenar muscles for thumb opposition and abduction.
The ulnar nerve innervates the forearm muscles and the intrinsic muscles of the hand while providing sensation to the little finger and the ulnar half of the ring finger. Proximal to the elbow, the ulnar nerve courses under a ligamentous band called the arcade of Struthers before entering the cubital tunnel posterior to the medial epicondyle. These are two sites where the nerve can become entrapped, leading to ulnar neuropathy syndromes. The ulnar nerve is palpable as a cord in the cubital tunnel and is vulnerable to injury with trauma over this area.
The biceps brachii muscle has two proximal heads and two distal attachments (Figure 270­3). The proximal long head originates proximal to the shoulder capsule, and the proximal short head originates at the coracoid process. The distal attachments are to the radial tuberosity by the distal biceps tendon and the forearm by the bicipital aponeurosis. The biceps muscle is innervated by the musculocutaneous nerve (C5 and C6) and functions primarily to supinate and assist in flexion of the forearm.
FIGURE 270­3. Biceps muscle anatomy.
The brachialis muscle lies deep to the biceps muscle. It is innervated by both the musculocutaneous and radial nerves (C5, C6, C7, and C8) and is the primary flexor of the forearm.
The triceps muscle has three proximal heads (Figure 270­4): a long head originating from the scapula, a lateral head, and a medial head. The triceps inserts at the olecranon via the triceps tendon. The triceps muscle is innervated by the radial nerve (C6, C7, and C8) and is the sole extensor of the forearm.
FIGURE 270­4. Triceps muscle anatomy.
The intrinsic forearm muscles include the brachioradialis, pronator teres, pronator quadratus, anconeus, and supinator (Figure 270­5). The motor functions of these muscles are summarized in Table 270­2. TABLE 270­2
Motor Functions of the Intrinsic Forearm Muscles
Muscle Function
Brachioradialis Assists with forearm flexion
Pronator teres Assists with forearm pronation and flexion
Pronator quadratus Primary forearm pronation
Anconeus Trivial forearm extension
Supinator Primary forearm supination
FIGURE 270­5. Intrinsic forearm muscles. A. Anterior forearm. B. Posterior forearm.
CLINICAL FEATURES
HISTORY
A thorough history is essential for determining the correct diagnosis in a patient with elbow or forearm pain. Onset of symptoms, mechanism of injury, exact location of pain, and associated symptoms such as numbness, weakness, or distal wrist and hand complaints are important elements to obtain.
Most acute traumatic injuries to the elbow and forearm occur due to either a fall onto an outstretched hand or a direct blow. Chronic overuse injuries should correlate with preceding activity involving a repetitive motion. A history of arthritides may point to a systemic disorder such as lupus, rheumatoid arthritis, or gout.
PHYSICAL EXAMINATION
Inspect the elbow and forearm for gross deformity, soft tissue swelling such as bursitis, or open wounds. Assess range of motion of the elbow in
 flexion, extension, pronation, and supination. Inability to fully extend the elbow is correlated with the presence of a fracture. Conversely, full range of
 motion in all four planes has high negative predictive value for fracture.
Radial, median, and ulnar nerve function can be conducted by isolated nerve testing. Test motor function against resistance. Assess sensory function using two­point discrimination. Test radial nerve motor function by having the patient extend both the wrist and fingers against resistance (Table 270­1). Assess sensation over the dorsum of the thumb index web space. Evaluate the median nerve through its distal branches— the anterior interosseous nerve and the recurrent branch of the median nerve. Assess anterior interosseous nerve function by having the patient make a circle, or “OK” sign, with the thumb and index finger. Abduction of the thumb through a “thumbs up” sign against resistance
(recurrent branch of the median nerve) and sensory testing over the tip of the index finger complete the evaluation of the median nerve. Test ulnar nerve function by having the patient spread the fingers apart against resistance; sensation is tested over the tip of the fifth digit. A simple and thorough way to assess radial, median, and ulnar nerve motor function, particularly in children, is to have the patient perform the motions of the
 game Rock, Paper, Scissors, followed by the OK sign. This routine includes the movements of wrist extension (proximal radial nerve), finger extension
(posterior interosseous nerve branch of radial nerve), finger abduction (ulnar nerve), and thumb and finger flexion (anterior interosseous nerve branch of the median nerve) described above.
DIAGNOSIS
IMAGING
Initial imaging studies should include anteroposterior and lateral views of the elbow, and anteroposterior, lateral, and oblique views of the humerus and forearm. If a distal forearm injury is present, obtain anteroposterior, lateral, and oblique views of the wrist instead of the humerus. Clinical decision rules to guide imaging decisions for the elbow, similar to published ankle and knee imaging rules, have to date produced conflicting data and
,4,5 are not helpful.
On lateral films of the elbow, a line drawn straight through the center of the radial shaft (radiocapitellar line) should bisect the radial head and capitellum (Figure 270­6A). Loss of this relationship should raise suspicion for an occult radius fracture or dislocation. A line drawn straight along the anterior border of the humerus (anterior humeral line) should transect the posterior two thirds of the capitellum (Figure 270­6B). Abnormal extension of the line through the anterior one third of the capitellum suggests a distal humerus (in adults) or supracondylar fracture (in children). A small anterior fat pad may be a normal finding. Large anterior and any posterior fat pads are always abnormal and indicate the presence of a joint effusion (Figure 270­7).
FIGURE 270­6. A. Radiocapitellar line. B. Anterior humeral line.
FIGURE 270­7. Anterior and posterior fat pad signs.

Obtain CT imaging to evaluate for fracture when plain radiographs are normal in the setting of concerning physical exam findings. CT also assists in characterizing certain elbow fractures, particularly coronoid and comminuted intra­articular fractures. MRI is useful in the evaluation of soft tissue
7­10 injuries but has a limited role in the acute setting. US can demonstrate effusions, fractures, postreduction fracture alignment, and tendon injury.
Several studies have demonstrated sensitivities and specificities of over 90% for the diagnosis of forearm and elbow fractures using point­of­care
,12
US. While it cannot completely replace plain radiography due to variations in operator skill, point­of­care US can be a powerful diagnostic adjunct in the evaluation of elbow and forearm injuries.
TREATMENT
Consult an orthopedic surgeon immediately for open fractures, irreducible dislocations, injuries resulting in a grossly unstable elbow joint, nerve injury, or vascular injury with signs of ischemia or uncontrolled hemorrhage. All other injuries may be referred for follow­up within  to  days for operative planning or up to a week for nonoperative treatment. Table 270­3 outlines guidelines for ED immobilization and appropriate orthopedic consult time frames for the conditions discussed in this chapter.
TABLE 270­3
Immobilization and Follow­Up Guidelines
Injury Splint Referral
Soft tissue injuries
Biceps tendon rupture Sling immobilization  wk
Triceps tendon rupture Sling immobilization  wk
Lateral/medial epicondylitis Rigid wrist brace, forearm counterforce brace 2–4 wk PRN
Elbow dislocation
Stable/postreduction Long arm posterior splint, elbow slightly less than  degrees, forearm neutral 1–2 d
Unstable/postreduction Long arm posterior splint (presurgical stabilization) Immediate
Irreducible Long arm posterior splint (presurgical stabilization) Immediate
Elbow fractures
Distal humerus nondisplaced Long arm posterior splint, forearm neutral  wk
Supracondylar Long arm posterior splint (presurgical stabilization) <24 h
Intercondylar Long arm posterior splint, forearm neutral 1–2 d
Lateral condyle/epicondyle
Nondisplaced Long arm posterior splint, forearm in supination 1–2 d
Displaced Long arm posterior splint (presurgical stabilization) Immediate
Medial condyle/epicondyle
Nondisplaced Long arm posterior splint, forearm in pronation 1–2 d
Displaced Long arm posterior splint (presurgical stabilization) Immediate
Articular surface Long arm posterior splint, forearm neutral 1–2 d
Coronoid
Nondisplaced or minimally displaced Long arm posterior splint, elbow past  degrees, forearm in supination 1–2 d
Markedly displaced or unstable Long arm posterior splint (presurgical stabilization) Immediate
Olecranon Long arm posterior splint, forearm neutral <24 h
Radial head
Nondisplaced Sling immobilization with early range of motion  wk
Displaced or range of motion block Long arm posterior splint, forearm neutral <24 h
Forearm fractures
Both bones
Pediatric
Greenstick Long arm posterior splint  wk
Displaced Long arm posterior splint Immediate
Adult
Nondisplaced Sugar­tong splint  wk
Displaced Long arm posterior splint (presurgical stabilization) <24 h
Isolated ulna shaft Long arm posterior splint, forearm neutral or Sugar­tong splint if stable and nondisplaced  wk
Proximal two thirds of radius
Nondisplaced Long arm posterior splint, forearm neutral  wk
Displaced Long arm posterior splint, forearm neutral 1–2 d
Monteggia’s Long arm posterior splint (presurgical stabilization) Immediate
Galeazzi’s Long arm posterior splint (presurgical stabilization) Immediate
SOFT TISSUE INJURIES
BICEPS TENDON RUPTURE
Most biceps injuries are proximal, and nearly all of these involve the proximal long head. Injuries usually manifest as tendinopathies from repetitive microtrauma and overuse. The classic mechanism leading to tendon rupture is a sudden or prolonged contraction against resistance in middle­aged and older individuals with a history of chronic biceps tendinopathy. A snap or pop is usually described, and pain is present in the anterior shoulder.
Examination of the anterior shoulder will reveal swelling, tenderness, and often crepitus over the bicipital groove. Ecchymosis may extend the entire length of the biceps. Flexion of the elbow will elicit pain and may produce a midarm “ball,” which represents the distally retracted biceps muscle. Comparing arms for symmetry helps. Loss of flexion strength is minimal, due to the preserved functions of the brachialis and supinator. Avulsion fractures occasionally occur, so radiographs of the shoulder should be obtained.
ED treatment includes sling, ice, analgesics, and referral to an orthopedic surgeon for definitive care.

Distal biceps injuries are less common than proximal injuries. Complete distal tendon ruptures are most common in middle­aged men and usually involve the dominant extremity. Partial tears are seen in men and women. Mechanism of injury is typically a sudden eccentric (extension) load applied to a flexed elbow. Pain is felt in the antecubital fossa, with swelling, ecchymosis, and tenderness to palpation noted on examination. A palpable defect in the antecubital fossa and a midarm “ball” may be present. Strength loss, especially supination, is more notable than with proximal ruptures. The
 biceps squeeze test, similar to the Thompson test for assessing Achilles tendon rupture, can detect biceps rupture. With the patient seated and the forearm at  to  degrees of flexion, place one hand on the muscle belly of the biceps and the other hand on the myotendinous junction, and squeeze with both hands. The squeeze should result in forearm supination. Lack of supination is considered a positive test, indicating rupture of the
 distal biceps tendon. To perform the hook test, flex the patient’s elbow to  degrees. During active supination, if the biceps tendon is intact, the examiner can “hook” the index finger under a cord­like structure in the antecubital fossa. Obtain elbow radiographs to search for an associated
,17 avulsion fracture. Although most complete distal ruptures are diagnosed clinically, US can aid in confirming the diagnosis of partial tears.
ED treatment includes sling, ice, analgesics, and referral to an orthopedic surgeon for definitive care. Although distal biceps ruptures were historically
 treated with surgery, management can be either surgical or conservative, depending on the patient.
TRICEPS TENDON RUPTURE

Injury to the triceps is rare and almost always occurs distally. Ruptures result from either a fall on an outstretched hand causing a forceful flexion of an extended elbow or a direct blow to the olecranon. Pain is felt in the posterior elbow. Examination of the elbow reveals posterior swelling and tenderness, just proximal to the olecranon. A sulcus with a more proximal mass, representing the retracted triceps muscle, may be palpable. With partial tears, some degree of function remains; however, with complete ruptures, the ability to extend the elbow is lost. A modified
Thompson test can be used to evaluate triceps function. The upper extremity is positioned such that the arm is supported and the forearm is hanging in a relaxed position with  degrees of flexion. Squeezing the triceps muscle should produce extension of the forearm, unless a complete rupture is present. Radiographs of the elbow are needed because avulsion fractures of the olecranon are common. Point­of­care US can aid in diagnosis,
,21 especially of partial tears.
ED treatment includes sling, ice, analgesics, and referral to an orthopedic surgeon for definitive care. Complete ruptures require surgical repair, whereas most partial tears can be treated conservatively with immobilization.
LATERAL EPICONDYLITIS
Lateral epicondylitis, or “tennis elbow,” is an overuse syndrome affecting the wrist and digit extensors and the forearm supinators. The diagnosis is made clinically by tenderness over the lateral epicondyle and pain with resisted wrist extension, digit extension, and forearm supination. Treatment is usually conservative, with rest, friction massage, anti­inflammatory medications, immobilization with a rigid wrist brace to limit wrist extension or a
22­24 counterforce forearm brace, and physical therapy. Refer to an orthopedic surgeon or sports medicine specialist for follow­up care.
MEDIAL EPICONDYLITIS
The less common counterpart to lateral epicondylitis is medial epicondylitis (“golfer’s elbow”). As with lateral epicondylitis, the diagnosis is made clinically. Tenderness over the medial epicondyle and pain with resisted wrist flexion and forearm pronation are expected, as these are the muscle groups affected. In addition, patients may develop an ulnar neuropathy, given the proximity of the ulnar nerve to the medial epicondyle. Ulnar neuropathy requires orthopedic follow­up. Treatment is similar to that of lateral epicondylitis, with rest, anti­inflammatory medications, bracing, and physical therapy.
ELBOW DISLOCATION
The elbow is one of the more stable joints. The muscular attachments, lateral collateral ligament, and medial ulnar collateral ligament augment its inherent stability in the flexion­extension plane. Dislocations of the elbow rank third in large­joint dislocations, after glenohumeral and patellofemoral dislocations. The mechanism of injury is usually a fall on an outstretched hand. Approximately 90% of all elbow dislocations are
 posterolateral. Fractures of the coronoid process, radial head, medial epicondyle, and olecranon can complicate the treatment of elbow dislocations. The “terrible triad” injury consists of an elbow dislocation coupled with fractures of the radial head and coronoid. This injury creates an unstable joint and requires emergent orthopedic consultation.
Clinically, the patient presents with the elbow in  degrees of flexion. The olecranon is prominent posteriorly, and the deformity resembles a displaced supracondylar fracture. If the patient is seen immediately after the injury, the bony landmarks can be identified. Later, however, the swelling may be quite severe, with no possibility of evaluating the injury topographically. The priority is to assess the neurovascular status of the brachial artery, ulnar nerve, and median nerve, as these structures may become entrapped. Perform neurovascular examination before and after manipulation. Neurologic complications most frequently involve the ulnar nerve and occur in up to 20% of elbow dislocations. Brachial artery
 injuries are estimated to occur in 5% to 13% of elbow dislocations. Absence of a radial pulse before reduction, an open dislocation, and systemic
,28 injuries (such as those of the head, chest, and abdomen) are findings associated with arterial injury. If vascular injury is suspected, then angiography may be required to assess the extent of injury and need for repair.
On the lateral radiograph, both the ulna and radius are displaced posteriorly (Figure 270­8). In the anteroposterior view, there may be lateral or medial displacement, with the ulna and radius in their normal relationship to each other. Assess for associated fractures, particularly of the coronoid process and radial head.
FIGURE 270­8. Posterior elbow dislocation.
Due to the amount of force that is necessary to reduce a dislocated elbow, success often depends on IV analgesia or procedural sedation. Intraarticular lidocaine is also helpful for closed reduction of dislocated elbows. Regardless of the type of analgesia used, ensure appropriate patient comfort prior to attempting closed reduction.
Closed reduction can be accomplished by several methods. In the first two­person reduction technique, position the forearm supine. While an assistant applies a stabilizing countertraction force on the upper arm, use one hand to apply a longitudinal traction on the wrist and forearm (Figure
270­9). With the other hand, manipulate the elbow to correct any medial or lateral displacement. Then apply slow and steady downward pressure to the proximal forearm with the other hand to help disengage the coronoid process from the olecranon fossa. Continue distal traction and flex the elbow. In the second two­person technique, the patient is prone with the arm abducted and the elbow slightly flexed. The patient may also be supine with the arm adducted across the torso and the elbow slightly flexed (Figure 270­10). Have an assistant apply longitudinal traction on the wrist and forearm. Then, grasp the elbow, positioning both thumbs on the olecranon, and apply firm pressure against the olecranon to push it up and over the trochlea and back into anatomic position. Apply countertraction with the fingers against the distal humerus. A preliminary report described a singleperson reduction technique with the patient in a seated position (Figure 270­11). Place an elbow in the patient’s antecubital fossa, then grasp the patient’s hand or wrist. Flex the patient’s forearm while leveraging a force into the antecubital fossa to bring the olecranon back into anatomic position. As this is a preliminary report of the technique, success and complication rates are not known with certainty. The last technique is a modification of the Stimson hanging technique used in shoulder reductions (Figure 270­12). Place the patient prone with the elbow flexed over the edge of the stretcher. Support the humerus proximal to the elbow with a folded blanket or pillow. Suspend 5­lb weights from the wrist. The patient’s elbow should reduce over a period of several minutes. Gentle manipulation may be applied to the olecranon to aid reduction.
FIGURE 270­9. Traction and flexion reduction method. A. Side­to­side manipulation is used to correct medial or lateral displacement. B. The elbow is then flexed while maintaining longitudinal traction.
FIGURE 270­10. Olecranon manipulation reduction method with the patient positioned (A) prone or (B) supine.
FIGURE 270­11. Single­person reduction method.
FIGURE 270­12. A. Hanging arm reduction method. B. Gentle manipulation can be applied to the olecranon if necessary.
With reduction, a palpable “clunk” is felt as the olecranon is seated back in the trochlea. Move the elbow through its full range of motion to assess stability. Obtain postreduction films to determine reduction and identify fractures not previously identified. Inability to maintain reduction necessitates emergency orthopedic consultation. If the joint is stable and good neurovascular status has been confirmed, splint with a long arm posterior splint with the forearm and wrist both in neutral position and the elbow at slightly less than  degrees of flexion. Arrange orthopedic follow­
,30 up in  to  days.
Obtain emergency orthopedic consultation for irreducible dislocations, neurovascular compromise, postreduction instability, associated fractures, and open dislocations.
FRACTURES ABOUT THE ELBOW
Elbow fractures can be divided into those of the distal humerus, proximal ulna, and proximal radius. The distal humerus includes the condylar structures and the articular surface (trochlea and capitellum). The proximal ulna includes the coronoid process and olecranon, and the proximal radius is essentially the radial head.
Radiographs of fractures about the elbow may reveal abnormal fat pads (Figure 270­7). A traumatic hemarthrosis displaces fat from the olecranon fossa posteriorly (posterior fat pad), and the anterior fat pad may become prominent (“sail sign”). However, abnormal fat pads may also be seen with nontraumatic joint effusions. Furthermore, they may be absent in severe trauma that disrupts the joint capsule and allows intra­articular fluid extravasation. In some nondisplaced fractures, the fracture line may not be seen, with the fat pad sign being the only evidence of injury. Treatment is initiated as though a fracture were identified, with splint immobilization and orthopedic consultation.
DISTAL HUMERUS FRACTURES
Routine ED care of nondisplaced distal humerus fractures with normal neurovascular function includes immobilization, ice, elevation, analgesics, and orthopedic referral. Displaced fractures or those with neurovascular compromise require immediate orthopedic consultation. See Chapter 271,
“Shoulder and Humerus Injuries,” for a detailed discussion of shoulder and humerus injuries.
SUPRACONDYLAR FRACTURES
Supracondylar fractures are the most common fracture about the elbow in children between  and  years of age, but can occur in adults, especially from high­velocity injuries. Fractures can be either extension type (>95%), which are displaced posteriorly, or flexion type (<5%), which are displaced anteriorly. Treatment varies widely between nonoperative management to emergent surgical management. In 2014, the American Academy of
Orthopedic Surgeons developed recommendations on the management of supracondylar fractures based on various clinical scenarios called the

Appropriate Use Criteria for the Management of Pediatric Supracondylar Humerus Fractures. Due to the complexity of these guidelines, the authors recommend emergency orthopedics consultation. However, a more conservative approach with urgent, rather than emergent, fixation has become more common. Treatment largely depends on the degree of displacement of the distal fragment and any concurrent neurovascular or soft tissue injury.
EXTENSION­TYPE SUPRACONDYLAR FRACTURES
Injuries most often occur with a fall on an outstretched hand with the elbow in full extension. Examination reveals significant edema and tenderness at the elbow, a prominent olecranon, and a depression proximal to the elbow. The appearance may be easily mistaken for a posterior elbow dislocation.
Nondisplaced fractures may be subtle and diagnosed only by the presence of a posterior fat pad, anterior “sail sign,” or disruption to the normal path of the anterior humeral line. Initially treat with immobilization using a long arm posterior splint, keeping the elbow at  degrees of flexion and the forearm in neutral rotation, followed by outpatient referral for casting. The presence of >20 degrees of angulation necessitates orthopedic
 consultation for reduction under anesthesia and possible pin fixation. In displaced fractures, the distal fragment will be displaced proximally and posteriorly. More severely displaced fractures may show medial or lateral displacement or rotation along the axis of the humerus (Figure 270­13).
Displaced fractures must be reduced and require orthopedic consultation. Historically, these fractures were treated with immediate reduction and pinning. However, there is now a trend toward delayed reduction and fixation up to  hours after injury without evidence of
,33­36 complication, thus lessening the need for emergent orthopedic intervention. Indications for emergent consultation are vascular insufficiency or decreased perfusion, nerve injury, open fracture, or an irreducible fracture. Admit patients with displaced fractures or significant soft tissue swelling for observation of neurovascular function.
FIGURE 270­13. Extension­type, displaced supracondylar fracture.
FLEXION­TYPE SUPRACONDYLAR FRACTURES
Flexion­type fractures are rare. The mechanism of injury is a direct anterior force against a flexed elbow, resulting in anterior displacement of the distal fragment. Because the mechanism is direct force, these fractures are often open. Management of flexion­type fractures is identical to that for extension­type fractures, with the same criteria for determining emergent versus urgent orthopedic consult. Flexion­type injuries are more likely to
 require open reduction and pinning, particularly if an associated ulnar nerve injury is present.
COMPLICATIONS OF SUPRACONDYLAR FRACTURES
There are numerous potential complications of supracondylar fractures (Table 270­4). Neurologic complications—resulting from traction, direct
 trauma, or nerve ischemia—have an incidence of 10% to 20%. Ulnar nerve injuries are uncommon, with the highest incidence reported iatrogenically from pin placement. Posteromedial displacement may involve the radial nerve, and posterolateral displacement can affect the median nerve. There is a high incidence of anterior interosseous nerve injuries with supracondylar fractures. The mechanism of injury is usually traction or contusion. Complete transection is rare, and entrapment within the fracture occurs only occasionally. Because there is no sensory component to
 the anterior interosseous nerve, the injury can only be identified through motor testing by making the “OK” sign.
TABLE 270­4
Complications of Supracondylar Fractures
Early complications Neurologic
Radial nerve injury
Median nerve injury (anterior interosseous branch)
Ulnar nerve injury (iatrogenic)
Vascular
Brachial artery injury
Volkmann’s ischemic contracture (compartment syndrome of the forearm)
Late complications Nonunion
Malunion
Myositis ossificans
Loss of motion
Always suspect acute neurovascular injuries in patients with supracondylar fractures. Absence of a radial pulse is an indicator of brachial artery injury,
 even if the hand appears warm, pink, and well perfused. Injury can be due to a partial or complete transection, an intimal tear and thrombosis, or entrapment within the fracture fragment of the brachial artery. Suspected or actual neurovascular injury requires emergency orthopedic
,42 consultation.
The most serious complication is a compartment syndrome of the forearm, also known as Volkmann’s ischemic contracture. This classically occurs following a displaced supracondylar fracture. Postischemic swelling increases pressure within the enclosed osteofascial forearm compartment and reduces capillary blood perfusion below the level necessary for tissue viability. If unrelieved, the result is muscle and nerve necrosis and eventual replacement by fibrotic tissue, producing a contracture. Refusal to open the hand, pain with passive extension of the fingers, and forearm pain out of proportion to exam findings are signs of impending Volkmann’s ischemia. Extremities with signs of ischemia require emergency orthopedic consultation.
INTERCONDYLAR FRACTURES
Intercondylar fractures, in which the condylar fragments are separated, are much more common in adults than in children. Assume any distal humerus fracture in an adult to be intercondylar rather than supracondylar. The mechanism of injury is a force directed against the posterior elbow. This drives the olecranon against the humeral articular surface, separating the condyles and producing the fracture. Carefully search for a fracture line separating the condyles from each other and from the humerus. All intercondylar fractures involve the articular surface. CT imaging is useful for identifying comminuted fractures and for planning operative therapy for displaced fractures. Treatment is dependent on the amount of displacement of the fracture fragments.
Nondisplaced intercondylar fractures are stable and can be treated initially with immobilization in a long arm posterior splint with the elbow flexed at
 degrees and the forearm in neutral position. Obtain orthopedic consultation for treatment of displaced, rotated, or comminuted fractures or severe
 edema.
EPICONDYLE FRACTURES
Lateral epicondyle fractures are uncommon, because the anatomic position of the condyle reduces its exposure to direct blows. When they do occur, lateral epicondyle fractures are usually avulsion fractures. These can be treated with immobilization in a long arm posterior splint, with the elbow flexed to  degrees and the forearm in supination, and orthopedic referral.
Isolated medial epicondyle fractures are considered extra­articular injuries and usually occur in children and adolescents. Mechanisms include a posterior elbow dislocation, repeated valgus stress such as throwing a baseball (Little League elbow), or a direct blow. If there is an associated tear of the medial (ulnar) collateral ligament, the epicondyle itself may become entrapped in the joint space. Patients present with pain over the medial elbow that is exacerbated by supination of the forearm and flexion of the forearm, wrist, and digits. Edema and tenderness are noted in the same area.
Carefully test neurovascular function. Obtain standard radiographs with special attention to any intra­articular fragment. Comparison views of the unaffected contralateral elbow may be helpful for diagnosis.
Treat stable, nondisplaced or minimally displaced fractures from a low­energy mechanism nonoperatively, with early range of motion. ED treatment consists of long arm posterior splint immobilization, with the forearm in flexion and pronation, and orthopedic referral. High­energy injuries, open fractures, unstable joints, significant fragment displacement, an intra­articular fragment, and ulnar neuropathy are indications for emergency
44­46 orthopedic consultation. Because surgical treatment should be determined on an individual basis, orthopedic consultation is recommended for all epicondyle fractures.
CONDYLE FRACTURES

Lateral condyle fractures occur in children and are more common than their medial counterpart. They result from either a direct blow to the lateral elbow or from a fall on an outstretched hand. Patients complain of pain in the lateral elbow, and swelling is noted in the same area.
Medial condyle fractures are uncommon and are mostly limited to children. Mechanism of injury is from either a fall on an outstretched hand or excessive valgus stress. Medial pain and swelling are the prominent findings. The injury is often confused with the more common medial epicondyle fracture for two reasons. First, the mechanism and examination findings are similar. Second, because the trochlea ossification center does not appear until age  to  years old, it is often missed on radiographs.
ED care of nondisplaced condyle fractures with normal neurovascular function includes long arm posterior splint immobilization, ice, elevation, analgesics, and orthopedic referral. Follow­up imaging every  weeks is recommended due to the risk of late displacement, which is treated with surgical fixation. Displaced fractures or those with neurovascular compromise require immediate orthopedic consultation.
ARTICULAR SURFACE FRACTURES
TROCHLEA AND CAPITELLUM FRACTURES
Isolated trochlea fractures are rare and are often associated with other elbow injuries, such as posterior elbow dislocations. Physical findings usually include swelling, tenderness, and limited movement of the elbow joint. Radiographic findings can be subtle, and CT or MRI may be required for diagnosis.
Isolated capitellum fractures are also rare. They are usually associated with radial head fractures. Pain is present over the lateral elbow, and examination reveals lateral swelling, tenderness, and limitation of flexion and extension. If pain and tenderness are present medially, then suspect injury to the medial (ulnar) collateral ligament. Radiographic findings may be subtle and are best seen on a lateral view. The capitellum has no tendinous or ligamentous attachments, so many fractures are nondisplaced. A radial head–capitellum view can be helpful in addition to standard anteroposterior and lateral views. CT imaging is useful for diagnosis.
ED treatment of articular surface fractures includes long arm posterior splint immobilization and orthopedic consultation. Complications are common and include limited flexion and extension, elbow joint instability, avascular necrosis, nonunion, and arthritis.
PROXIMAL ULNA FRACTURES
Nearly all proximal ulna fractures are considered intra­articular, except for proximal olecranon chip fractures.
CORONOID FRACTURES
Coronoid fractures are usually associated with posterior elbow dislocations as the trochlea impacts the coronoid. Rarely, a coronoid fracture can occur
 as an isolated injury secondary to elbow hyperextension. There is pain, swelling, and tenderness over the antecubital fossa. Radiographic visualization is best with lateral and oblique films. CT is often needed to make the diagnosis.
ED treatment should include long arm posterior splint immobilization with the elbow in flexion and the forearm in supination, ice, elevation, analgesics, and referral to an orthopedic surgeon within  hours. Due to the critical role the coronoid plays in elbow stability, early orthopedic referral
 is indicated even for isolated, nondisplaced fractures. Displaced fractures or those with joint instability require open reduction and internal fixation and frequently have poor outcomes.
OLECRANON FRACTURES

Olecranon fractures represent up to 10% of upper extremity fractures. The mechanism is usually direct trauma or by a fall with forced hyperextension of the elbow. Associated injuries are common, including open fractures, dislocations, other fractures (especially of the radial head), and ulnar nerve injury. Pain is present over the posterior elbow, and examination reveals swelling, tenderness, and occasionally crepitus. Because the triceps muscle inserts at the olecranon, elbow extension can be compromised. It is important to test extension against resistance, as the patient may falsely appear to have intact extension function by using gravity to draw the forearm down. Ulnar nerve injury is common; therefore, a careful neurologic examination is required. Lateral radiographs offer the best view of the olecranon. In adolescents, the epiphysis ossifies by  years of age and fuses by  years of age, so comparison films and the appearance of an abnormal fat pad can aid in the diagnosis. ED treatment includes long arm posterior splint immobilization with the elbow in flexion and forearm neutral, ice, elevation, analgesics, and referral to an orthopedist within  hours.
Stable, nondisplaced fractures with intact extensor function can be treated conservatively with immobilization. Nonoperative treatment may also be
 considered for elderly patients who are poor candidates for surgery. All other olecranon fractures require surgical repair.
RADIAL HEAD FRACTURES
Radial head fractures are the most common fractures of the elbow. They result from a fall on an outstretched hand, causing the radial head to drive into the capitellum. Associated injuries are common and may include capitellum, olecranon, and coronoid fractures, medial collateral ligament injury, medial epicondyle avulsion fracture, and elbow dislocation. A specific associated injury, the Essex­Lopresti lesion, occurs when there is disruption of the triangular fibrocartilage complex of the wrist and the interosseous membrane between the radius and ulna, causing dissociation of the distal radioulnar joint. This is analogous to a Maisonneuve injury in the lower extremity. Do not miss this injury. Failure to recognize this injury can result in proximal migration of the radius, so obtain emergency orthopedic consultation.
Radial head fractures cause pain in the lateral elbow, especially with pronation and supination of the forearm. On examination, there may be swelling laterally and tenderness with palpation of the radial head. Pronating and supinating the forearm with the elbow flexed allows the examiner to palpate the radial head. On standard elbow radiographs, radial head fractures may be subtle (Figure 270­14). Radiographic clues include the presence of an abnormal fat pad or abnormal displacement of the radiocapitellar line away from the center of the capitellum (Figure 270­7). This is especially helpful in children whose epiphysis has not fused. Additional images, including obliques and a radial head–capitellum view, may be helpful.
FIGURE 270­14. Subtle radial head fracture and anterior fat pad sign (arrow).
Nondisplaced fractures can be treated conservatively with immobilization and early range of motion exercises to avoid the development of a stiff joint.
ED treatment consists of sling immobilization, ice, elevation, analgesics, and referral to an orthopedic surgeon or sports medicine specialist within 
 week. Consider aspiration of the joint hematoma in the ED to improve pain and facilitate early mobilization. For displaced fractures or those with restricted range of motion, surgical repair is generally indicated, and orthopedic referral should be made within  hours. Complications of radial head fracture include chronic pain and restricted range of motion at the elbow.
FOREARM FRACTURES
In adults, solitary fractures of the forearm are uncommon due to the close relationship of the radius and ulna. The fibrous interconnection between the radius and ulna transmits force above and below the injury. As a result, fractures usually occur at two or more sites or involve ligamentous injury or joint dislocation. Because distant structures are commonly injured, examine joints above and below the involved bones both clinically and radiologically. Be suspicious for associated injuries if there is significant angulation of the fracture.
FRACTURES OF BOTH RADIUS AND ULNA
A large amount of force is necessary to fracture both the radius and the ulna. This occurs most often from vehicular trauma, falls from a height, or a direct blow. Force magnitude determines the injury type. Moderate forces produce transverse or mildly oblique fractures. High­impact forces produce comminuted and segmental fractures (often displaced).
Nondisplaced fractures of both bones are exceedingly rare, because the force necessary to produce the injury is also sufficient to displace the bones.
Examination of the forearm reveals swelling, deformity, and tenderness. Carefully assess the neurovascular status. Nerve injuries can occur with severe open fractures, but are uncommon with closed injuries. Because of the excellent collateral circulation of the forearm, vascular compromise is generally not a major concern if either the radial or ulnar circulation is intact.
The fractures are clearly visible on radiographs. Note the degree of angulation, displacement, and shortening. Changes in rotational alignment may be subtle. Assessing the orientation of bony prominences on the radius and ulna can help determine rotational alignment. On the anteroposterior view, the radial styloid and radial (bicipital) tuberosity normally point in opposite directions, whereas the ulnar styloid and coronoid process do so on the lateral view. A change in this arrangement suggests rotation malalignment. Because these bones are oblong rather than circular in their cross­sectional appearance, a sudden change in the bone’s width at the fracture site is another clue to a rotational deformity. Obtain radiographs of the wrist and elbow because of the likelihood of an associated dislocation or articular fracture.
Treatment depends on the type of fracture. Torus or greenstick fractures with minimal angulation in children can be treated with immobilization in a long arm splint. Angulation >15 degrees warrants referral for closed reduction. In younger children, treat displaced fractures with closed reduction and cast immobilization due to the continued remodeling that occurs after fracture healing. Perform closed reduction urgently in the ED to ensure appropriate alignment. Traditionally, closed reduction is performed by an orthopedic consultant, but reductions performed by emergency physicians
 for nonoverlapping fractures have also been show shown to have good outcomes. Surgical intervention is indicated if acceptable reduction cannot
 be achieved through closed reduction and casting. Nondisplaced fractures in adults can be immobilized with a long arm splint and referred for urgent follow­up. All other fractures in adults require orthopedic consultation, ideally within  to  hours.
Complications include reduced ability to supinate and pronate, osteomyelitis, nonunion, malunion, neurovascular injury, and compartment syndrome. Recognizing the development of a compartment syndrome is particularly important to prevent Volkmann’s ischemic contractures of the forearm. Direct measurements of elevated compartment pressures confirm the diagnosis. Emergent orthopedic consultation for fasciotomy is required.
ULNA FRACTURES
ISOLATED ULNA FRACTURE (NIGHTSTICK FRACTURE)
Isolated fractures of the ulna most often result from a direct blow to the forearm. A fracture resulting from the natural response to raise the forearm in defense of a strike is referred to as a nightstick fracture. Nondisplaced fractures are immobilized in a sugar­tong splint and closely followed for subsequent displacement.

Fractures with >50% displacement, with >10% angulation, or that involve the proximal third of the ulna are considered unstable.
Obtain orthopedic consultation for unstable fractures. Assess for any concomitant radius fracture or dislocation.
MONTEGGIA’S FRACTURE­DISLOCATION
Fracture of the proximal third of the ulna with a radial head dislocation is referred to as Monteggia’s fracture­dislocation (Figure 270­15). The
 associated radial head dislocation may be easily missed. Missing the radial head dislocation can lead to chronic pain, limited range of motion, and, possibly, radial head excision as treatment. Monteggia’s fracture­dislocations occur following a fall onto an outstretched hand or a direct blow. Clinically, there is considerable pain and swelling at the elbow. The radial head may be palpable in an anterolateral or posterolateral location. The forearm may appear shortened and angulated. The ulnar fracture is clearly visible on radiographs and may overshadow the less obvious radial head dislocation. An abnormal radiocapitellar line may aid in the diagnosis. Additionally, the apex of the ulna fracture points in the direction of the radial head dislocation to provide another radiographic clue.
FIGURE 270­15. Monteggia’s fracture­dislocation. The angulation of the comminuted fracture of the proximal ulna points in the direction of the radial head dislocation.
Obtain consultation with an orthopedic surgeon. Monteggia’s fracture­dislocations are generally treated with open reduction and internal fixation of the ulna fracture and closed reduction of the radial head dislocation. Complications include nonunion, recurrent dislocation, chronic pain, infection, and paralysis of the posterior interosseous nerve, the deep branch of the radial nerve that controls finger extension.
RADIUS FRACTURES
FRACTURES OF THE PROXIMAL TWO THIRDS OF THE RADIUS
Radius fractures can be divided into those in the proximal two thirds and those in the distal one third of the bone. Excluding radial head fractures, isolated fractures of the proximal two thirds of the radius are uncommon because the radius is relatively well protected from direct blows by the ulna and surrounding forearm musculature. Fractures of the proximal two thirds of the radius are often displaced by both the force of the injury and the action of the forearm supinators and pronators on the radius. Typically, supination of the proximal segment and pronation of the distal segment are seen, although a fracture located beyond these muscle groups may have minimal deformity. Displaced fractures require emergent orthopedic consultation. Nondisplaced fractures are treated with cast immobilization. Compartment syndrome is rare with these fractures. Most complications involve malunion or nonunion because of inadequate or lost reduction.
GALEAZZI’S FRACTURE­DISLOCATION
Fracture of the distal third of the radial shaft accompanied by a dislocation of the distal radioulnar joint is known as Galeazzi’s fracture­dislocation
(Figure 270­16). This injury results from falls on the outstretched hand in forced pronation or from a direct blow. Galeazzi’s fracture­dislocation is
 also referred to as Piedmont fracture,reverse Monteggia’s fracture, or fracture of necessity, reflecting the need for surgical intervention. There is localized tenderness and swelling over the distal radius and wrist. The radius fracture usually results in dorsal lateral angulation. The distal radioulnar joint injury can be subtle. Radiographs may show only a slightly increased distal radioulnar joint space on the anteroposterior view. On the lateral view, the ulna is displaced dorsally. Obtain immediate orthopedic consultation in the ED. Complications include infection, nonunion, and malunion. If the radius heals with a rotational deformity, there may be pain at the distal radioulnar joint with extreme pronation and supination.
FIGURE 270­16. Galeazzi’s fracture­dislocation.
Acknowledgments
The authors wish to recognize the contributions of Harold Chin, MD; Arthur F. Proust, MD; Jason H. Bredenkamp, MD; Brian P. Jokhy, MD; and Dennis
T. Uehara, MD, MS, in previous editions of this chapter, and of Sue Lahey, MLS, for her research assistance.


