## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 292: Substance Use Disorders
Kathryn Hawk; Elizabeth A. Samuels; Scott G. Weiner; Edward Bernstein; Gail D’Onofrio
Content Update: Substance Use Disorders June 2022
Most current information is provided in the sections Buprenorphine, Treating Opioid Withdrawal, Opioid Use Disorder, and Precipitated
Withdrawal.
Additional important comments are provided in Referral to Treatment
INTRODUCTION AND EPIDEMIOLOGY
In EDs around the world, on every shift, patients present for medical conditions related to the consequences of unhealthy drinking or drug use. The

World Health Organization reported in 2012 that .9% of all global deaths (3.3 million people) were attributed to the consumption of alcohol. From
,3
2006 to 2014, ED alcohol­related visits increased in the United States from 827,100 to .46 million. In 2015, an estimated .5 million people, or .6% of the global adult population, qualified for a drug use disorder, yet fewer than 16% were afforded treatment. The majority of worldwide illicit drug–
 related deaths (190,000) were attributed to opioids. In 2016, the United States accounted for more than 25% of these deaths. U.S. ED drug­related
 visits doubled from 2005 to 2014, fueled by increased supply and misuse of prescription opioids; social and economic determinants; and the low cost
 and easy availability of heroin, synthetic fentanyl, and analogs. Between July 2016 and September 2017, U.S. opioid overdose ED visits among those
 aged  years old and older increased .7% overall, with significant increases across all demographics examined. It is noteworthy that “available data suggest that nonmedical prescription­opioid use is neither necessary nor sufficient for the initiation of heroin use and that other factors are
 contributing to the increase in the rate of heroin use and related mortality.”
The scope of substance use disorders (SUDs) includes unhealthy use of alcohol, use of illicit drugs, and nonmedical use of prescription drugs. Severe
SUDs resemble asthma, diabetes, hypertension, and other chronic diseases in that they have genetic components and patients have problems with
 adherence to medication, loss to follow­up, exacerbations, repeat visits to the ED, and hospital admissions. Nevertheless, only a small fraction of those needing alcohol or drug treatment actually receive indicated therapy, compared with a much higher fraction of patients with chronic medical
 conditions. This understanding of addiction as a chronic, relapsing medical condition requires us to shift our focus toward providing linkage to
 ongoing integrated treatment and community support services as an addition to acute care. The gap in SUD treatment also reflects the impact of social stigma on disparities in availability, accessibility, and affordability of services. Language is powerful, especially when talking about substance use because stigma perpetuates negative perceptions, discourages use of treatment services, and contributes to further substance use. Words do
12­14 matter and the language used to discuss addiction is important to decrease stigma (Table 292­1).
TABLE 292­1
Nonstigmatizing Substance Use Disorder Language
Avoid These Terms Use These Instead
Addict, user, drug abuser, junkie Person with opioid use disorder or person with opioid addiction, patient
Addicted baby Baby born with neonatal abstinence syndrome

Chapter 292: Substance Use Disorders, Kathryn Hawk; Elizabeth A. Samuels; Scott G. Weiner; Edward Bernstein; Gail D’Onofrio 
©2025O MpicoGid raabwu sHe iollr. oAplilo Ridig dhetpse nRdeesnecreved. Terms of Use * POrpivioaicdy u Pseo dliicsoyr * d eNrotice * Accessibility
Problem Disease
Habit Drug addiction
Clean or dirty urine test Negative or positive urine drug test
Opioid substitution or replacement therapy Opioid agonist treatment
Relapse Return to use
Treatment failure Treatment attempt
Being clean Being in remission or recovery
Source: Data adapted from www.thenationalcouncil.org/consulting­best­practices/national­council­shareables. Accessed June , 2018. UNHEALTHY ALCOHOL USE
The term unhealthy alcohol use describes a spectrum of alcohol consumption ranging from “risky” or hazardous use (no consequences experienced), to harmful use (experience of consequences), to what was previously called alcohol dependence but is now termed mild, moderate, or severe alcohol
 use disorders in the Diagnostic and Statistical Manual of Mental Disorders, fifth edition classification. The National Institute on Alcohol Abuse and
Alcoholism defines low­risk drinking as follows: for men, no more than  drinks per week and no more than four drinks over a 2­hour occasion.
Women of all ages and men >65 years old are advised to drink no more than seven drinks per week and no more than three drinks over a 2­hour occasion, because of gender and age differences in volume distribution and concentrations of alcohol dehydrogenase in the liver. Binge drinking
(drinking too much too fast) is alcohol consumption that results in a blood alcohol level over the U.S. legal limit of .08 gram/dL, which for the average male is the result of more than four drinks in  hours and for the average female is more than three drinks in  hours. Nearly  million adults engage in
 extreme binge drinking, described as consuming two or more times these thresholds. Abstinence is advised for pregnant women and underage drinkers, and a lower limit or abstinence is advised for patients with chronic conditions exacerbated by alcohol or who are taking medications with an
 alcohol interaction.

Those who begin drinking before age  have a fourfold increased risk of developing dependence than those who begin drinking later. Early onset
 also predicts adverse health status. Underage drinking and drug use have a profound impact on the developing nervous system, so early intervention
 is needed to mitigate life­altering consequences. Gaps between women and men are narrowing for prevalence, frequency, and intensity of drinking;
,20 early­onset drinking; and driving under the influence. Women who drink are more likely to experience medical complications of alcohol use including liver injury and cirrhosis, some cancers, cognitive dysfunction, and cardiovascular complications such as stroke, hypertension, and
21­24 cardiomyopathy. National survey data demonstrate an upward trend in drinking among U.S. adults aged  and older, particularly among women
 who were found to have increased rates of binge drinking. The ED is an important site for alcohol screening (Figure 292­1).
FIGURE 292­1. American College of Emergency Physicians policy on alcohol screening in the ED.
SUBSTANCE USE DISORDERS
The Diagnostic and Statistical Manual of Mental Disorders, fifth edition, groups substance abuse and dependence into categories from mild to severe

SUD. The diagnosis of SUD requires two or more of the following  criteria: (1) tolerance; (2) withdrawal; (3) recurrent use in greater quantities or for a greater duration than intended; (4) failed attempts to cut back or quit substance use; (5) spending a great deal of time obtaining, using, or recovering from the substance; (6) persistent or recurrent use despite physical and or psychological consequences; (7) giving up important activities in order to use; (8) failure to fulfill responsibilities in work, school, and/or home because of recurrent use; (9) recurrent use resulting in physically hazardous behavior, such as driving under the influence; (10) persistent use despite social or interpersonal problems; and (11) craving alcohol or other drugs.
Severity is based on the number of criteria met: two or three of the criteria constitute mild SUD, four to five constitute moderate SUD, and six or more
   constitute severe SUD. More than  million Americans aged  and older and 110 million people worldwide meet criteria for an SUD.
SCREENING, BRIEF INTERVENTION, AND REFERRAL TO TREATMENT
Screening, brief intervention, and referral to treatment techniques were established in 2003 by the U.S. Substance Abuse and Mental Health Services
Administration to address the gap in preventive services for unhealthy alcohol and drug use, to stem the progression to addiction by early intervention, and to address the treatment gap by promoting help seeking and facilitating access to addiction treatment and recovery support services.
29­43
Screening, brief intervention, and referral to treatment have been associated with short­term benefits and reduction in cost and ED utilization.
SCREENING FOR UNHEALTHY DRINKING AND DRUG USE
Brief standardized screening questions have a higher sensitivity for identifying heavy and dependent drinkers and illicit drug–using patients than noting the smell of alcohol on breath, patient self­report, or profiling based on demographics or presenting complaint. Brief screening instruments are easy to administer and may help match an individual to the most appropriate treatment resource. Validated brief screening questions useful for ED
 providers include the National Institute on Alcohol Abuse and Alcoholism Quantity/Frequency Questions and the Single Screening Questions for

Alcohol and Drug Use (Table 292­2). Questions can be integrated into the triage electronic medical record. Screening for heavy smoking is also
 important since there is an association between heavy smoking and multiple drug use. An alternative approach is to implement the National Institute on Drug Abuse–Modified Alcohol, Smoking and Substance Involvement Screening Test instrument into ED practice if additional ED support personnel are available (e.g., health promotion advocate, alcohol and drug counselors, recovery coaches, trained medical workers, behavioral health or social
,47­49 workers). The National Institute on Drug Abuse–Modified Alcohol, Smoking and Substance Involvement Screening Test instrument was developed to guide clinicians through a series of questions to identify risky substance use in their adult patients. Final scores of  to  on the instrument stratify risk and encourage clinicians to advise, assess, and assist patients with follow­up to primary care; a score of greater than  indicates the need for referrals to SUD specialty treatment.
TABLE 292­2
Single Screening Questions
“Would it be okay with you if I ask you some very personal questions that I ask all my patients to improve the care I give? You do not have to answer them if you are uncomfortable.”
Single Screening Question for Alcohol: “Do you drink beer, wine, liquor, or distilled spirits? How many times in the past year have you had  or more
(for men)/4 or more (for women) drinks in a day?”6,44 Clarify that a standard drink is .5 oz of spirits,  oz of wine, and  oz of beer.6
Single Screening Question for Drug Use: “How many times in the past year have you used an illegal drug or used a prescription medication for nonmedical reasons?” You can add something like “. . for instance, for the experience or feeling it gives you?”45
As part of the social history, emergency care providers can integrate questions that reflect their concern for the patient’s overall health and safety. SUD screening questions could be embedded among other preventive health issues to reduce stigma and patient resistance and encourage veracity and
 trust. Questions asked in a nonjudgmental, matter­of­fact fashion are well accepted by patients.
Patients who are above the “low­risk” drinking guidelines could benefit from a brief intervention and primary care referral to motivate reducing consumption. For moderate to severe alcohol use, provide referral to a specialized treatment center.
THE BRIEF NEGOTIATED INTERVIEW FOR SUBSTANCE USE INTERVENTION
,30,36,37,51,52
The brief negotiated interview has four key elements: establish rapport, provide feedback, enhance motivation, and negotiate a plan of action. The first principle of promoting health behavior change is that the argument for change needs to come from the patient, not the healthcare provider. Begin a respectful, nonjudgmental conversation by recognizing the patient as the decision maker and asking the patient’s permission to talk about alcohol or drug use and health concerns. An important opportunity for early intervention may occur during an ED visit for acute medical care or
  a social or criminal justice crisis. The entire interaction often can be accomplished in  to  minutes, and the conversation can take place at any point in care, such as at discharge or while suturing or casting or performing an incision and drainage of an abscess.
The brief negotiated interview algorithm incorporates key elements of motivational interviewing: open­ended questions, affirmations, reflective listening, and summaries (Figure 292­2). (See Video: Brief Negotiated Interview and Active Referral to Treatment.)
Video 292­1: Brief Negotiated Interview for Substance Use Disorder: College Student
Used with permission from Clara Safi, BNI ART Institute, Boston University School of Public Health.
Play Video
FIGURE 292­2. Screening, brief intervention, and referral to treatment algorithm as taught in the standardized ED curriculum. BNI = brief negotiated interview; f/u = follow­up; NIAAA = National Institute on Alcohol Abuse and Alcoholism; PC = primary care; pt = patient. [Reproduced with permission from D’Onofrio
G, Pantalon MV, Degutis LC, Fiellin DA, O’connor PG: Development and implementation of an emergency practitioner­performed brief intervention for hazardous and harmful drinkers in the emergency department. Acad Emerg Med 12: 249, 2005. Copyright John Wiley & Sons.]
Establish Rapport
Establish rapport and ask the patient’s permission to discuss his or her use of alcohol and drugs. Establish an atmosphere of trust through respect.
The patient is not the problem (a stigmatizing approach) but is a person who has a problem. Instead of “What’s wrong with our patient?”, an alternative approach based on compassionate curiosity would lead the clinician to inquire, “What’s happening with our patient?”
Provide Feedback
Elicit the patient’s thoughts on low­risk or safe alcohol and drug use. Provide information by reviewing current drinking and drug use and guidelines.
Express concern that by drinking in excess of safe limits, the patient is at risk for injury or illness. Elicit/solicit the reaction to the guidelines. Ask patients to make a connection between alcohol and/or drug use and quality of life; possible negative consequences related to health, family, legal system, and employment; and, if applicable, the current ED visit or injury. If appropriate, discuss physical dependence, withdrawal, and the cycle of behaviors to obtain more alcohol and/or drugs.
Enhance Motivation
Assess readiness to change on a readiness ruler. Ask patients to mark on a drawing of a ruler, with a scale of  to , how ready they are to change, cut back, or quit their alcohol and/or drug use. If they say , give affirmation and say that “You are 50% on the way,” and ask, “Tell me why you didn’t mark a  or  or a lesser number?” Here is when we try to elicit change talk or reasons and motivation for change. Repeat what the patient has shared with you and follow up with, “It sounds like you have some important reasons to change, so what small steps can you take to stay healthy and safe?” If the patient shows resistance to the readiness ruler or the score is <2, then explore the pros and cons of current use. A discussion of the pros and cons promotes self­questioning and draws attention to the patient’s own reasons for tipping the scale toward change. Use open­ended questions such as,
“Help me to understand (or see it through your eyes) what you like and dislike about your use of alcohol?” Explore the importance to the patient of the issues that emerge. Use reflective listening to summarize what you think the patient said to verify your interpretation, for example: “On the one hand, you like the taste and how it helps you to loosen up and forget your problems, and it is something to do when you’re bored. On the other hand, you said you don’t like how you feel the next day and that wrecking your car in a crash and ending up in the ED is no fun. You also told me you are spending a lot of money on drinking and are concerned about not meeting some responsibilities. So then, in the balance, where does that leave you?”
Negotiate and Advise
Negotiate an action plan. Explore with patients what life might be like if they made these changes. What would be the benefits of change, and what would be the challenges? Add the steps they would need to take to address challenges and explore and support confidence in ability to make a change.
Offer a menu of options and resources to assist with the change plan, including, if appropriate, referrals to primary care providers and SUD treatment.
Document the plan. Ask the patient to state in her or his own words the agreed­on steps and document them on a piece of paper or discharge instructions as a reminder of goals (a prescription for change). Reflect back to the patient and reinforce reasons for, and steps toward, change. End the conversation by thanking the patient for being honest and spending time talking with you.
Afterward, take a minute for self­assessment using the FLOAT mnemonic: To what degree did you provide feedback? Did you listen carefully? Did you ask open­ended questions? Did you offer affirmations and alternatives? Did the patient have enough time to talk, or did you do the majority of talking?
Did you negotiate a concrete action plan?
REFERRAL TO TREATMENT
Factors that often accompany unhealthy alcohol and drug use, such as psychiatric illness, trauma, homelessness, low level of health literacy, lack of insurance coverage or ability to pay for medications, criminal justice involvement, absence of family support, and limited availability of treatment and recovery support services, make patient management and disposition challenging.
Effective linkage to SUD treatment can be facilitated by training ED staff in screening, brief intervention, and referral to treatment. Develop an ED collaborative team with staff such as behavioral health and social workers, care managers, psychologists, nurse specialists, peer alcohol and drug counselors, volunteers from Alcoholics Anonymous or Narcotics Anonymous, health promotion advocates, or recovery coaches to enhance the efforts
,47­49,52 of existing staff and motivate and assist patients with identifying and accessing treatment options.
,47,52
Build and maintain a referral and resource service network. Current practice in most EDs is to provide patients and family members with a list of treatment resources in the community. The Center for Substance Abuse Treatment at the U.S. Department of Health and Human Services has an online resource locator (http://dasis3.samhsa.gov). The resource list and referral networks ideally would include a continuum of specialized treatment facilities for patients with co­occurring medical, traumatic, and psychiatric illnesses; inpatient and outpatient medical management for withdrawal, acupuncture, and medication for addiction treatment such as methadone maintenance programs, buprenorphine, and oral and IM naltrexone for opioid and alcohol use disorder; outpatient individual and group counseling; intensive outpatient or partial hospitalization; sober housing and residential treatment communities; Alcoholics Anonymous and Narcotics Anonymous meetings; and programs focused on the needs of women, culture­specific programs, and programs designed for gay, lesbian, and transgender clients.
If patients are not ready to enter specialized treatment, provide harm reduction education and strategies such as negotiating a safety plan for not driving, not using alone, testing drug supply for fentanyl, offering naloxone and education to reduce risk of overdose for individuals with opioid use disorders, and community resources such as needle exchange programs, and condom access. Individuals should also be cautioned regarding use of combination of substances and increase risk for overdose and adverse reactions. Patients with substance use disorders, particularly those that injected drugs, should be offered access to testing for human immunodeficiency virus or hepatitis C virus, regardless of if they decline medication treatment referral. Unfortunately, medications for AUD and OUD are underutilized and under prescribed. The use of opioid agonists such as
 methadone and buprenorphine have been demonstrated to save lives and reduce future overdose. Patients should also be referred to low barrier access touchpoints.
THE MEDICAL EVALUATION
EDs often function as sources for the medical evaluation before patient transfer to a substance or psychiatric treatment facility. There is considerable variability in the levels of medical care provided in such facilities, ranging from facilities that manage an array of chronic health problems to those with minimal nursing support only for very stable patients. Medical evaluation means that the patient does not have a medical emergency or acute medical condition requiring hospitalization or preventing addiction treatment. Patients with mild or moderate uncomplicated alcohol withdrawal that responds well to initial ED treatment (i.e., those with no trauma or major medical comorbidities, with no suicidal or homicidal ideation or a seizure disorder) can be managed successfully in a detoxification unit.
The criteria for placement in medically supervised withdrawal are very similar to those for safe discharge and include the following: patients are stable
(in the short term rather than long term) and ambulatory, can take oral medications, and are not suicidal or likely to seize. Patients on medications
(including buprenorphine) should bring them to the treatment facility or be given prescriptions or provided with several doses. Stable patients with dual diagnoses who are not suicidal or acutely psychotic can be medically cleared for transfer, as long as they have a supply of current psychiatric and nonpsychiatric medications and can be expected to take their medications correctly and reliably. Detoxification for opioids is not advised as loss of tolerance places these individuals at very high risk for opioid overdose once discharged. Provision of naloxone is critically important.
PHARMACOLOGIC MANAGEMENT FOR ALCOHOL, OPIOID, AND SEDATIVE USE DISORDERS
A large body of evidence supports the efficacy of pharmacologic interventions for the treatment of alcohol, opioid, and sedative use disorders.
Management of alcohol, opioid, and sedative intoxication; overdose; and withdrawal syndromes is covered in chapters dedicated to each substance.
Pharmacologic management of individuals with moderate to severe alcohol, opioid, and sedative use disorders is discussed here. Many of these treatments will not be typically initiated in the ED, but knowledge of their existence and effectiveness is important for the ED provider to understand both when caring for patients who are prescribed these medications and in providing referrals for medical management to patients with SUDs.
ALCOHOL USE DISORDER MANAGEMENT
Medications for the treatment of alcohol use disorder include alcohol antagonist agents, such as disulfiram (Antabuse®), and medications that directly reduce alcohol consumption, including acamprosate (Campral®), oral naltrexone, and long­acting injectable naltrexone (Vivitrol®). Disulfiram is an oral medication that irreversibly binds to and inhibits alcohol dehydrogenase, causing the unpleasant disulfiram­ethanol reaction, which can include
,55 nausea, vomiting, diaphoresis, flushing, and tachycardia, the avoidance of which serves as a deterrent for the consumption of alcohol.
Acamprosate, an amino acid derivative that increases γ­aminobutyric acid transmission, was previously found to be effective in reducing return to
 alcohol use in a number of U.S. and European studies, but did not show efficacy in a large multicenter trial. In the Combined Pharmacotherapies and
Behavioral Interventions study, a large prospective multisite study investigating the effect of combinations of medications and behavioral therapies on alcohol use disorder, acamprosate showed no significant effect on drinking versus placebo, either by itself or with any combination of naltrexone,
 cognitive behavior therapy, or both.
Naltrexone, an opioid receptor antagonist with no intrinsic agonist activity, is hypothesized to lead to reduce alcohol consumption by indirectly
 affecting the dopaminergic reward pathway through effects on the µ opioid receptor. Early studies reported that oral naltrexone, in conjunction with behavioral intervention, led to lower reports of craving, fewer drinks and drinking days, and fewer relapses; more recent systematic reviews report that
,58 naltrexone is effective at reducing return to heavy drinking and the amount of alcohol consumed. A long­acting IM naltrexone injection was approved by the U.S. Food and Drug Administration in 2006 and can decrease heavy drinking days while avoiding the challenges of taking a daily
 medication. Importantly, these medications are not mutually exclusive to each other, as multiple studies have shown improved outcomes in patients
,57 taking a combination of medications for alcohol use disorder, as well as medications augmented with behavioral or psychosocial interventions.
OPIOID USE DISORDER MANAGEMENT
A substantial body of literature supports medications for opioid use disorder treatment for moderate or severe opioid use disorders, and such
60­63 treatment is recognized by the Centers for Disease Control and Prevention, National Institute of Drug Abuse, and World Health Organization.
Collectively, methadone and buprenorphine are referred to as opioid agonist treatments and have been associated with a variety of improved outcomes including reduced craving, decreased opioid use, decreased crime, decreased nonfatal overdose, decreased mortality, cost­effectiveness,
,62,64­66 and improved social functioning.
Methadone
Methadone is a long­acting oral medication with full opioid agonist properties at the µ receptor. Methadone can be prescribed by physicians for the treatment of pain, but the prescription of methadone for treatment of addiction is limited by the Federal Narcotics Act to inpatient units or outpatient facilities licensed by the U.S. Drug Enforcement Administration. Several large­scale studies have shown a relationship between outcomes and
,67 methadone dose, with improved outcomes including less opioid and cocaine use at doses above  milligrams. Methadone has been associated
 with QT prolongation on the ECG.
Buprenorphine
Buprenorphine is a partial opioid agonist and a weak antagonist. It has a high affinity for µ receptors, displacing other opioids from the receptor and thus potentially can precipitate withdrawal in patients who have recently used opioids. The antagonist effects of buprenorphine block respiratory depression and provide a good margin of safety to treat withdrawal and reduce craving for opioids. The U.S. Food and Drug Administration approved two sublingual formulations of buprenorphine in 2002 for the treatment of moderate/severe opioid use disorder. The preferred preparation is a combination of buprenorphine combined with naloxone in a ratio of 4:1, as a sublingual tablet or film (brand name Suboxone® or Zubsolv®) to prevent
,69 diversion or tampering. The naloxone component is rapidly bioavailable if the medication is tampered with and will precipitate withdrawal symptoms in individuals with severe opioid use disorder. Non–naloxone­containing films are traditionally reserved for pregnant patients or settings with directly observed medication ingestion, such as a healthcare setting or for patients who are intolerant of the naloxone containing formulation.
Overdoses, though rare in adults, can be managed with naloxone. Advise patients about the risks of concurrent benzodiazepine use, including respiratory depression and overdose of prescribed and illicit sedatives with all opioids, including methadone and buprenorphine.
The Drug Addiction Treatment Act of 2000 established office­based opioid treatment in an effort to integrate treatment options into comprehensive clinical care practice and reduce stigmatization of medication treatment for opioid use disorder. The prescription of methadone for opioid use disorder treatment is limited by the Federal Narcotics Act to inpatient units or outpatient facilities licensed by the U.S. Drug Enforcement
Administration, and buprenorphine is limited to certified clinicians in office­ or clinic­based practices that have a Drug Addiction Treatment Act of 2000 waiver, also known as an X­waiver. The Drug Addiction Treatment Act of 2000 allowed clinicians completing approved training to apply for a waiver, although the U.S. Department of Health and Human Services released new practice guidelines in April 2021 that eliminated the training requirement to apply for a waiver for those prescribing for  or fewer patients at one time. For clinicians without a waiver, there is a “3­day rule” (Title , Code of
Federal Regulations, Part 1306.07b) that allows a practitioner who is not separately registered as an opioid treatment program or certified as a
“waivered Drug Addiction Treatment Act of 2000” physician to administer (but not prescribe) narcotic drugs to a patient to relieve acute withdrawal
112,113 symptoms while arranging for referral to treatment. Only  day’s supply may be administered or given to a patient, and this may be done for  hours only, which cannot be extended. The intent of Title , Code of Federal Regulations, Part 1306.07b is to provide flexibility in emergency situations and is especially relevant to emergency physicians. This offers patients options for relief of withdrawal symptoms to bridge the patient for follow­up to either a specialized treatment program or an office­based physician program in the community.
A study of 329 ED patients found that patients with moderate or severe opioid use disorder randomized to receive a brief intervention with initiation of buprenorphine in the ED with primary care follow­up were significantly more likely to be engaged in formal treatment for opioid use disorder at  days (78%; 95% confidence interval [CI], 70% to 85%), compared with referral alone (37%; 95% CI, 28% to 47%) and brief intervention with a facilitated,
 direct referral (45%; 95% CI, 36% to 54%; P < .001). The buprenorphine group reduced the number of days of illicit opioid use per week from .4 days
(95% CI, .1 to .7) to .9 days (95% CI, .5 to .3) versus a reduction from .4 days (95% CI, .1 to .7) to .3 days (95% CI, .7 to .0) in the referral group and from .6 days (95% CI, .3 to .9) to .4 days (95% CI, .8 to .0) in the brief intervention group (P < .001 for both time and intervention effects; P =

.02 for the interaction effect).
This important study from 2015, combined with the rapid increase in opioid­associated fatalities, laid the foundation for EDs to help bridge the treatment gap for patients with opioid use disorder by collaborating with local treatment providers to develop pathways for rapid linkage to care.
Treating Opioid Withdrawal and Opioid Use Disorder
The starting dose for treatment of opioid withdrawal is sublingual buprenorphine/naloxone, usually 4­8 milligrams of buprenorphine/naloxone, with a total of 8­12 mg on the first day, given to patients who meet criteria for moderate or severe opioid use disorder and show signs of moderate or
,71 greater opioid withdrawal according to the Clinical Opiate Withdrawal Scale (Figure 292­3). A recent retrospective study of high­dose buprenorphine initiation (>  to  mg) demonstrated that this option is safe and feasible depending on clinician experience and patient factors. If the patient has minimal withdrawal symptoms (<  on the Clinical Opiate Withdrawal Scale) a physician with a Drug Addiction Treatment Act of 2000 waiver can prescribe buprenorphine to be initiated on their own with clear instructions and referral for follow­up. (Figure 292­4).
FIGURE 292­3. Clinical Opiate Withdrawal Scale. [Reproduced with permission from Wesson DR, Ling W: The Clinical Opiate Withdrawal Scale (COWS). J Psychoactive
Drugs 35: 253, 2003. Copyright Taylor & Francis Ltd.]
FIGURE 292­4. ED­initiated buprenorphine. SL = sublingual. [Adapted from study protocol D’Onofrio G, O’Connor PG, Pantalon MV, et al: Emergency departmentinitiated buprenorphine/naloxone treatment for opioid dependence. JAMA 313: 1636, 2015. The study was supported by grant 5RO1DA025991 from
National Institute on Drug Abuse. https/www.drugabuse.gov/ed­buprenorphine]
Precipitated Withdrawal
Opioid withdrawal can be precipitated through exposure to the partial agonist buprenorphine if opioid agonist, such as heroin or fentanyl, are still bound to the mu­receptors. A detailed review of the patients’ signs and symptoms of withdrawal, as well as a detailed drug use history (including methadone) is critical to preventing buprenorphine precipitated withdrawal. The incidence of precipitated withdrawal is quite low. A recently reported analysis of 800 ED patients receiving sublingual or extended­release buprenorphine throughout the U.S. as part of a clinical trial reported a 1% incidence of precipitated withdrawal, all effectively managed in the ED, with no patients requiring inpatient admission. Patients should be advised that there is a chance that they may feel worse after receiving buprenorphine, but that the emergency care team can treat this with more buprenorphine and a variety of other medications. Although there are no prospective trials on the management of buprenorphine precipitated withdrawal, consensus recommendations include treatment with additional buprenorphine, often high dose, ancillary medications such as antiemetics and small doses of lorazepam. The administration of a sub­dissociative dose ketamine as also been effective in certain circumstances. Buprenorphine precipitated withdrawal is a rare event, and patients’ symptoms can almost always be safely and effectively managed in the emergency department.
Patients can also present in precipitated withdrawal after naloxone administration. These patients may or may not exhibit signs and symptoms of opioid withdrawal to the degree that treatment with buprenorphine may be considered. Although little prospective data is available, consensus recommendations suggest that naloxone precipitated opioid withdrawal may be treated with buprenorphine if the patient is willing and a complicated, polysubstance overdose is not suspected. Otherwise, the patient may be treated symptomatically with non­opioid medications and if they wish to start buprenorphine, they should be discharged with a prescription for buprenorphine for unobserved treatment initiation with close follow­up.
Naltrexone
Naltrexone is a long­acting µ receptor antagonist that reduces relapse or return to opioid use in patients by blockading any positive reinforcement
 from taking opioids. Naltrexone is best suited to patients with opioid use disorder who are highly motivated to avoid opioids, as it provides modest relief from craving, or who were recently released from a controlled environment such as incarceration or an abstinence program. Naltrexone requires at least a 7­day period without opioid exposure to avoid the complication of precipitated withdrawal. Recent studies comparing it with opioid agonist treatment such as buprenorphine highlight the fact that patients may refuse treatment, and evaluation of
,56 effectiveness has been complicated by poor study and treatment retention.
Benzodiazepines
The chronic use of sedatives, particularly benzodiazepines, is a common comorbidity with other substance use disorders. The emergency provider often encounters patients with signs and symptoms of withdrawal, when prescriptions are not filled after hospitalizations or surgeries. Symptoms of withdrawal may develop up to  to  days after stopping chronic benzodiazepine use, and patients may develop withdrawal seizures. The clinical picture resembles alcohol withdrawal with symptoms of hypertension, tachycardia and tachypnea, tremulousness, anxiety, agoraphobia, insomnia, altered mental status, delirium, and hallucinations. Medical management for the treatment of benzodiazepine withdrawal is complicated by risk of
 withdrawal seizures. Most evidence supports a prolonged benzodiazepine taper over  to  weeks. A 2006 Cochrane review found support for a gradual benzodiazepines taper, although it did not find significant differences between patients being tapered on long­ versus short­acting
 benzodiazepines, and no additional benefit was found to support the adjunct use of additional medications such as propranolol or hydroxyzine. A meta­analysis of  studies evaluating strategies for the discontinuation of benzodiazepines found that both minimal interventions and systematic discontinuation of benzodiazepines were more effective than treatment as usual and concluded that there is adequate support of the stepped care
 model, in which minimal intervention is followed by systematic discontinuation. Preliminary evidence for the use of carbamazepine exists, but large,
 controlled trials have not been reported. Benzodiazepines should be continued in collaboration with the primary care provider or mental health provider, and the patient should be referred to an addiction medicine specialist as needed. If benzodiazepines are necessary for continued treatment of debilitating psychiatric illness, patients should have a psychiatry consult or evaluation as these medications are frequently inappropriately prescribed or overprescribed.
REDUCTION OF HARM FROM OPIOID USE DISORDER
Many ED patients with opioid use disorder will not be ready to enter treatment at the time of the ED visit, but we still have an opportunity to help them progress in their readiness to seek treatment, prevent individual and societal harms associated with drug use, and prevent future overdose deaths.
,73
Syringe access and supervised consumption facilities have demonstrated lower human immunodeficiency virus and hepatitis C virus transmission
74­76 rates, fewer injection drug risk behaviors, decreased overdose incidents, and more rapid entry into detox programs. Naloxone, a competitive
 opioid receptor antagonist, has been distributed for bystander opioid overdose reversal since 1996 at community naloxone distribution programs.
78­82
Community naloxone distribution programs have demonstrated that lay people and injection drug users can reliably administer naloxone.

Population studies have noted that naloxone distribution is associated with decreased community overdose deaths and decreased deaths among
  people released from prison, is cost­effective when provided to heroin users, and reduces opioid­related ED visits when co­prescribed with opioids
 for chronic pain by a primary care provider. Given the increasing incidence of opioid overdose, some cities and states have started storing publicly
 accessible naloxone with automated external defibrillator devices, in designated NaloxBoxes, and at public schools.
In addition to referring patients to addiction treatment, community syringe access, and naloxone distribution programs, in 2009 EDs started providing
88­91 take­home naloxone to patients at high risk of opioid overdose to prevent opioid overdose death. Naloxone can be either prescribed for pickup at a pharmacy or given to patients in a preassembled “kit” that includes administration instructions, a mouth barrier for CPR, and two doses of naloxone.
Provision of naloxone at the time of the ED visit decreases access barriers and ensures that the patient and/or their family member has received the medication. In 2018, the U.S. Surgeon General released an advisory encouraging widespread access to naloxone for individuals who take opioids and
114,115 encouraged healthcare practitioners to prescribe naloxone to individuals at increased risk for opioid overdose.
Naloxone can be given IM or intranasally. IM naloxone can be prescribed as two single­dose vials, .4 milligram/mL with a 3­mL syringe and 1­inch 23­ guage needle (Table 292­3). This is the cheapest formulation, but it requires drawing up the medication into a syringe prior to administration.
Another IM formulation, Evzio®, is a U.S. Food and Drug Administration–approved prefilled autoinjector. It has a single dose of naloxone  milligrams/0.4 mL (prior formulation had .4­milligram dose) and comes in packs of two. It is easy to use but more expensive and requires prior insurance authorization, limiting its utility in the ED setting.
TABLE 292­3
Naloxone Formulations Characteristics and Prescriptions
Narcan® Nasal
Generic Intramuscular Evzio® Auto­Injector Generic Intranasal
Spray
Dose .4 milligram/mL  milligrams/0.4 mL  milligram/mL  milligrams/0.1 mL
Titratable X X dose
Assembly X X required
Cost $ $$$ $$ $$
Prescription Two single­use 1­mL vials PLUS two 3­ One two­pack of two  Two 2­mL Luer­Jet® Luer­Lock One two­pack of two and mL syringes with 23­ to 25­gauge 1­ to milligram/0.4 mL prefilled needleless syringes plus two mucosal  mg/0.1 mL quantity .5­inch IM needles; two refills auto­injector devices; two atomizer devices (MAD­300); two refills intranasal devices; refills two refills
Narcan® is a U.S. Food and Drug Administration–approved intranasal form of naloxone that contains  milligrams of naloxone and requires no assembly. It is very easy to use but more expensive than generic formulations. Generic intranasal naloxone is prescribed as two prefilled Luer­Lock needless syringes containing  milligrams/2 mL to be dispensed with a mucosal atomizing device. This formulation requires assembly before use.
Primary considerations when considering distributing naloxone include state regulatory barriers, which can limit direct to patient naloxone distribution and third­party prescribing; cost; and patient education. Naloxone is covered by most insurance plans. Any trained staff member can provide overdose prevention, response, and naloxone administration education. Patient education is best done in person in combination with
 facilitation of treatment referral; however, it can also be done with video.
SAFE PRESCRIBING OF OPIOID PAIN RELIEVERS

Emergency providers commonly treat painful conditions. Opioids are frequently prescribed for patients with pain, with a multicenter study showing
 that 17% of discharged patients received an opioid prescription. With heightened awareness of the risks associated with opioids, that percentage is decreasing, but it is likely that opioids will always continue to have a role for certain ED patients with pain. ED prescribing is not a significant contributor to the overall number of opioid prescriptions written annually in the United States, providing only about 4% to 5% of the total number of
,95 opioid prescriptions and about 2% when converted to morphine equivalents. However, providers must be aware that short­term ED prescriptions
 can have long­term consequences: One study showed that 12% of opioid­naive patients given an ED opioid prescription had recurrent use, and another concluded that about one third of patients with opioid use disorder who were first exposed to opioids by a legitimate prescription obtained
 that prescription from the ED. Standardization of treatment is key: There is currently wide variation in rates of opioid prescribing among physicians practicing within the same ED, and higher­intensity opioid prescribers within an individual department are more likely to have patients who are on
  opioids long term. Furthermore, the longer the duration of an initial opioid prescription, the more likely it is the patient will develop long­term use, leading to the following recommendation by the Centers for Disease Control and Prevention: “When opioids are used for acute pain, clinicians should prescribe the lowest effective dose of immediate­release opioids and should prescribe no greater quantity than needed for the expected duration of pain severe enough to require opioids. Three days or less will often be sufficient; more than seven days
100 will rarely be needed.” Therefore, a framework for safe prescribing of opioids from the ED is essential to incorporate into practice and consists of the following four pillars.
. Determine if an opioid is indicated. There is mounting evidence that outcomes for acutely painful conditions are the same whether or not an opioid is used. For example, for patients with acute arm or leg sprain pain, the combination of ibuprofen and acetaminophen results in the same level of
101 pain reduction at  hours as do combinations of acetaminophen with oxycodone, hydrocodone, or codeine. Likewise, patients with nonradicular back pain who were given naproxen had similar functional outcomes at  week whether or not they also took oxycodone/acetaminophen or
102 cyclobenzaprine. Given these similar outcomes, it would be prudent to use nonopioid pain relievers (e.g., acetaminophen, ibuprofen, topical lidocaine) and avoid the exposure altogether. A formal “alternatives to opioids” program can be created, which encourages use of nonopioid pain medications, triggerpoint injections, nitrous oxide, and ultrasound­guided nerve blocks to avoid opioids when possible.
. Screen patients for opioid misuse risk factors. If the decision is made to prescribe an opioid, determine whether the patient is at higher risk for future opioid misuse. Several screening tools have been produced for this purpose, including the Screener and Opioid Assessment for Patients
103,104 with Pain–Revised and the Opioid Risk Tool. It is important to note that these tools were derived and validated in non­ED settings, and recently, the Centers for Disease Control and Prevention declared that the tools have insufficient accuracy for classification of patients as at low or
105 high risk for abuse or misuse. It is therefore prudent to use caution for all patients when prescribing opioids, although be particularly careful when patients have high­risk features that are detected by these tools, such as concomitant psychiatric illness and/or previous personal or family history of drug or alcohol abuse.
. Utilize a prescription drug monitoring program. Nearly all states have implemented prescription drug monitoring programs that track the
106 prescribing and dispensing of controlled substances at the pharmacy level. When first implemented, states with prescription drug monitoring programs appeared to have lower rates of substance abuse treatment admission and lower rates of increase in abuse/misuse compared to states
107 that did not have them. Prescription drug monitoring program data can change prescribing behavior because providers do not have adequate
108 sensitivity or positive predictive value in detecting certain aberrant drug­related behaviors (e.g., “doctor shopping”) without the aid of this tool.
Although they should be used prior to every opioid prescription, there are limitations to these databases, particularly that they do not detect
109,110 medications that are diverted or purchased illegally, which are the main sources of non–medically used opioid pain relievers. Use prescription drug monitoring program data along with history, physical examination, and clinical impression. Do not use prescription drug monitoring program data as a reason to withhold adequate and necessary analgesia. Several factors from prescription drug monitoring program data may suggest concerning substance abuse risk (Table 292­4).
. Educate about safe opioid use. Every patient who receives an opioid prescription should be provided with specific education about safe use and the risks of the medication. This education should include the following: (1) use recommended nonopioid pain relievers (e.g., acetaminophen and ibuprofen, if not contraindicated) first and understand that the opioid is an adjunct that should be used only to make the pain tolerable but not remove the pain entirely; (2) immediately stop use of the opioid medication once the pain is tolerable with nonopioid medications; (3) safely store the medication away from others in the household who may be at increased risk of nonmedical use, such as adolescents; and (4) dispose of any
111 unused medication promptly and properly, which can now be done at most pharmacies and police stations.
TABLE 292­4
Identifying Substance Abuse Risk
When assessing a prescription drug monitoring program (PDMP) profile, it is important to look at the following factors:
From how many providers did the patient receive prescriptions?
— Patients who used  or more prescribers or  or more pharmacies in  months may have risk of death from overdose.59,60
Is the patient taking both opioids and benzodiazepines?
— Patients who use combinations of medications may be at increased risk for overdose.61
How many morphine milligram equivalents of opioids is the patient taking per day?
— Patients who take  to 100 morphine milligram equivalents per day are at greater risk of overdose death.62­64
Is the patient taking long­acting/extended­release (LA/ER) opioids?
— Patients taking LA/ER may be at increased risk for overdose.65
How often did the patient fill another prescription before the previous one was scheduled to finish?
— Early refills indicate nonmedical use or noncompliance with treatment plan.65
Is the patient taking buprenorphine?
— Patients taking buprenorphine are likely under the care of a pain specialist who should be contacted prior to prescribing a scheduled medication.
Is the patient taking psychiatric medications, such as methylphenidate?
— Psychiatric comorbidities are associated with increased risk of overdose.
If reported by the PDMP, how often did the patient self­pay?
— Patients may pay out of pocket for a prescription without involving an insurer to avoid detection of nonmedical use.


