## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 231: Anemia and Polycythemia
Michael Billet; Robin R. Hemphill
ANEMIA
Anemia is a common medical problem, affecting approximately one quarter of the world’s population, especially children, pregnant and
1­4 premenopausal women, the elderly, and the chronically ill. Anemia is not so much a disease as a sign or symptom. There are three broad causes of anemia: (1) blood loss, (2) decreased red blood cell production, and (3) increased red blood cell (RBC) destruction.
PATHOPHYSIOLOGY
Anemia is a reduced concentration of RBCs. In healthy persons, normal erythropoiesis ensures that the concentration of RBCs present is adequate to meet the body’s demand for oxygen and that the destruction of RBCs balances the production. The average life of the circulating erythrocyte is approximately 110 to 120 days. Any process or condition that results in the loss of RBCs, that impairs RBC production, or that increases RBC destruction will result in anemia if the bone marrow cannot produce new cells to replace those lost (Table 231­1).
TABLE 231­1
Classification of Anemia
Mechanism Example
Loss of red blood cells by hemorrhage Acute GI bleeding
Increased destruction Sickle cell disease
Drug­induced autoimmune hemolytic anemia
Impaired production Nutritional deficiency anemia (iron, folate)
Aplastic or myelodysplastic anemia
Dilutional Rapid IV crystalloid infusion
Quantification of the erythrocyte concentration is reflected in (1) RBC count per microliter, (2) hemoglobin concentration, and (3) hematocrit
(percentage of RBC mass to blood volume). Reference RBC values for adults vary between genders, with smaller variations for ethnicity and age (Table
231­2).
TABLE 231­2
Reference Range Red Blood Cell Values for Adults
Male Female
Red blood cell count (million/mm3) .5–6.0 .0–5.5

Hemoglobin (grams/dL) 14–17 12–15
Chapter 231: Anemia and Polycythemia, Michael Billet; Robin R. Hemphill 
. Terms of Use * Privacy Policy * Notice * Acce(s1s4i0b–i1li7ty0 grams/L) (120–150 grams/L)
Hematocrit or packed cell volume (%) 42–52 36–48
Mean corpuscular volume: MCV (fL) 78–100 78–102
Mean corpuscular hemoglobin: MCH (picograms/cell) 25–35 25–35
Mean corpuscular hemoglobin concentration: MCHC (grams/dL) 32–36 (320­360 g/L) 32–36 (320­360 g/L)
Red cell distribution width: RDW (%) .5–14.5 .5–14.5
Reticulocytes (%) .5–2.5 .5–2.5
Note: Normal values may vary depending upon the equipment used, patient’s age, and the altitude of patient residence.
Anemia reduces the oxygen­carrying capacity of a given volume of blood. The body responds to anemia in ways to minimize the effect of this reduction in oxygen­carrying capacity. Mechanisms vary depending on the rapidity of onset, the degree of anemia, and the underlying condition of the patient.
The cardiovascular response typically manifests with vasoconstriction in the peripheral vasculature and vasodilation in the central vasculature to help preserve blood flow to vital organs. As anemia worsens, systemic small­vessel vasodilation will occur, increasing blood flow to tissues. These processes result in decreased systemic vascular resistance, increased cardiac output, and often tachycardia. In addition, RBCs enhance their ability to release oxygen to the tissues by a shift of the oxyhemoglobin dissociation curve. Finally, anemia will result in the stimulation of erythropoietin as a result of tissue hypoxia and breakdown products from RBC destruction. New, immature erythrocytes, known as reticulocytes, will appear in the blood within  to  days.
CLINICAL FEATURES
The severity of signs and symptoms depends on the rate of development of anemia; the degree of anemia; and the age, comorbidities, and general condition of the patient. Otherwise healthy patients may tolerate significant anemia with minimally altered vital signs until they become profoundly fatigued, whereas physiologic compensation will be more challenging in those with medical comorbidities. Most adults will be symptomatic when hemoglobin levels decrease below  grams/dL; however, some patients with chronic anemia may have no complaints even with hemoglobin levels as low as  grams/dL.
Patients with chronic anemia may note weakness, fatigue, dizziness, dyspnea with exertion, palpitations, and orthostatic symptoms. Additional manifestations may depend on comorbid illnesses, such as worsened chest pain in a patient with preexisting angina. Specific historical features can be helpful in the identification and diagnosis of anemia, such as recent trauma, hematochezia, melena, hemoptysis, hematemesis, hematuria, or menorrhagia. More subtle historical features include relevant comorbidities such as peptic ulcer disease, chronic liver disease, and chronic kidney disease. Query regarding the use of antiplatelet agents, anticoagulants, and NSAIDs.
Physical exam findings include tachycardia; skin, nail bed, and mucosal pallor; systolic ejection murmur; bounding pulse; and widened pulse pressure.
Signs of easy bleeding or bruising suggest a coagulation disorder. Evidence of jaundice and hepatosplenomegaly suggests hemolysis. Unusual skin ulcerations, peripheral neuropathy, or neurologic signs such as ataxia or altered mental status may be evidence of nutritional deficiencies.
Patients who develop acute, severe anemia may have any of the signs and symptoms noted above. In addition, they may have resting dyspnea, diaphoresis, anxiety, or severe weakness that may progress to lethargy and altered mental status. Loss of >40% of blood volume from traumatic or
 spontaneous hemorrhage can lead to severe symptoms that are due more to intravascular volume depletion than to anemia.
DIAGNOSIS
The diagnosis is established by a finding of decreased RBC count, hemoglobin, and hematocrit on the CBC. Further workup initiated in the ED can help expedite a diagnosis and should be started before the transfusion of packed RBCs whenever possible.
The initial evaluation of newly diagnosed anemia includes consideration for a source of bleeding, including the most common internal sites—GI or uterine bleeding. If there is no physical or historical evidence of bleeding, RBC indices, reticulocyte count, and peripheral blood smear should be reviewed (Table 231­3). The mean corpuscular volume is the most useful guide to the possible etiology of an anemia and classifies the anemia as
 microcytic, normocytic, or macrocytic. Other useful diagnostic tests include the red cell distribution width and reticulocyte count. Serum ferritin is the
 most useful test for the diagnosis of iron deficiency anemia. Following this initial classification, additional tests can lead to a specific diagnosis
2­4,7­10
(Figures 231­1, 231­2, and 231­3).
TABLE 231­3
Laboratory Tests in the Evaluation of Anemia
Test Interpretation Clinical Correlation
Mean corpuscular Measure of the average red blood cell (RBC) size. Decreased MCV (microcytosis) is seen in chronic iron deficiency, volume (MVC) thalassemia, anemia of chronic disease, and lead poisoning.
Increased MCV (macrocytosis) can be due to vitamin B or folate
 deficiency, alcohol abuse, liver disease, reticulocytosis, and some medications (see “Diagnosis” section).
Mean corpuscular Measure of the amount of hemoglobin in average red — hemoglobin (MCH) blood cell.
Red cell distribution Measures the size variability of the RBC population. In early deficiency anemia (iron, vitamin B , or folate), may be increased
 width (RDW) before the mean corpuscular volume becomes abnormal.
Mean corpuscular Measure of hemoglobin concentration in average Low MCHC can be seen in iron deficiency anemia, defects in porphyrin hemoglobin RBC. synthesis, and hemolytic anemia.
concentration
(MCHC)
Ferritin Ferritin is a protein in the body that binds to iron. Low serum ferritin is associated with iron deficiency anemia and helps
Serum levels serve as an indication of the amount of differentiate this anemia from other causes.
iron stored in the body.
Reticulocyte count These RBCs of intermediate maturity are a marker of Decreased reticulocyte count reflects impaired RBC production.
production by the bone marrow.
Increased counts are a marker of accelerated RBC production.
Peripheral blood Allows visualization of the RBC morphology. May guide to new diagnosis of diseases such as sickle cell disease.
smear
Allows evaluation for abnormal cell shapes. Aids in the diagnosis of entities such as hemolytic anemia.
Allows examination of the white blood cells and May guide the diagnosis of other diseases that cause anemia.
platelets.
Coombs test Direct Coombs test is used to detect antibodies on Direct Coombs test is positive in autoimmune hemolytic anemia,
RBCs. transfusion reactions, and some drug­induced hemolytic anemia.
Indirect Coombs test is used to detect antibodies in Indirect Coombs test is routinely used in compatibility testing before the sera. transfusion.
Abbreviations: MCHC = mean corpuscular hemoglobin concentration; MCV = mean corpuscular volume; RBC = red blood cell; RDW = red cell distribution width.
FIGURE 231­1. Evaluation of macrocytic anemia. MCV = mean corpuscular volume; RDW = red cell distribution width.
FIGURE 231­2. Evaluation of normocytic anemia. MCV = mean corpuscular volume; RDW = red cell distribution width.
FIGURE 231­3. Evaluation of microcytic anemia. MCV = mean corpuscular volume; RBC = red blood cell; RDW = red cell distribution width.

The most common causes of macrocytosis are alcohol abuse, liver disease, vitamin B and/or folate deficiency, and hypothyroidism. Medications that
 affect folate absorption or metabolism and produce macrocytosis include phenytoin, valproate, trimethoprim, sulfamethoxazole, and metformin. The reverse transcriptase inhibitors used to treat human immunodeficiency virus infection can also produce macrocytosis, but they do so without causing anemia. Reticulocytes are larger than mature RBCs, so automated blood cell counters can report a mean corpuscular volume value above the normal range when an increased reticulocyte count is present.
Sideroblastic anemia can be due to a congenital mutation (X­linked or autosomal recessive), a somatic mutation (as seen in myelodysplastic
 syndromes) or from an acquired condition. The most common cause of acquired sideroblastic anemia is alcohol abuse. Pyridoxine deficiency, lead poisoning, copper deficiency, or zinc toxicity can cause sideroblastic anemias. Antimicrobials associated with sideroblastic anemia include linezolid, chloramphenicol, isoniazid, and cycloserine.
TREATMENT
The treatment of anemia depends on the cause and clinical status of the patient. In the ED, anemia that requires the most urgent attention results from
 acute blood loss. All patients with ongoing blood loss should have their blood typed and cross­matched for possible transfusion (see Chapter 238,
“Transfusion Therapy”). The decision to transfuse the anemic patient is individualized, taking into account clinical symptoms, the patient’s age and
,12 health, and the likelihood of further blood loss. In general, patients who are symptomatic at rest or are hemodynamically unstable and show evidence of tissue hypoxia and/or limited cardiopulmonary reserve should have RBCs transfused. In most settings, patients with anemia benefit when transfused at hemoglobin levels of ≤7 grams/dL (60 to  grams/L). Liberal transfusion strategy (defined as a hemoglobin threshold of .5 to 
 grams/dL or  to 100 grams/L) is not generally associated with clinical benefit.
ED patients with lesser degrees of anemia who are hemodynamically stable and have no evidence of tissue hypoxia, typically with hemoglobin levels of
≥8 grams/dL (80 grams/L), do not require immediate transfusion, and outpatient follow­up is recommended for further hematologic evaluation.
Treatment for nutritional deficiency anemias usually produces a reticulocyte response in  to  days (Table 231­4). Standard therapy for iron or folate deficiency uses oral replacement. Vitamin B replacement has traditionally been IM because of concern that malabsorption of the vitamin would limit

 ,15 the effectiveness of oral replacement. However, oral doses of 1000 micrograms of vitamin B per day are as effective as the IM route.

TABLE 231­4
Treatment for Specific Anemias
Anemia Type Treatment (Adult Doses)
Iron deficiency Elemental iron, 200 to 300 milligrams/d (e.g., ferrous sulfate, 325 milligrams, three to four tablets taken on an empty stomach over the anemia course of day); reticulocyte count should increase within 4–7 d and peak at  d; sustained treatment after correction of anemia is usually necessary to replenish iron stores.
Cyanocobalamin Cyanocobalamin, 1000 micrograms IM per week for  wk and every month thereafter; reticulocyte count should increase within  d
(vitamin B ) and peak at  d. Oral replacement with 1000 micrograms/d is as effective (see “Treatment” section).
 deficiency anemia
Folate deficiency Folate,  milligram PO per day (doses up to  milligrams may be needed for patients with malabsorption); reticulocyte count should anemia increase within  d with normalization of hemoglobin level in 1–2 mo.
Sideroblastic Evaluate for reversible causes. Discontinue any offending agents. Treatment is mainly supportive, consisting primarily of blood anemia transfusions to maintain the hemoglobin level. A trial of pyridoxine at pharmacologic doses (500 milligrams PO daily) may be helpful, with response most commonly seen in cases resulting from ethanol abuse or isoniazid. Some patients with hereditary X­linked sideroblastic anemia also respond to pyridoxine. Improvement with pyridoxine is rare for sideroblastic anemia of other causes.
Aplastic anemia Supportive care, including transfusion if appropriate.
Anemia of Supportive care, including transfusion if appropriate. Erythropoietic agents (patients with cancer, chronic kidney disease, human chronic disease immunodeficiency virus). Omega­3 polyunsaturated fatty acids (patients with rheumatoid arthritis and diabetes mellitus).
DISPOSITION AND FOLLOW­UP
Patients with anemia from ongoing blood loss should be admitted to the hospital for further evaluation and treatment. Patients with isolated anemia not related to blood loss do not necessarily require hospital admission if they are asymptomatic and hemodynamically stable, they have minimal comorbid disease, and follow­up can be arranged. Patients newly diagnosed with anemia who also have abnormalities in the WBC or platelet count should have hematologic consultation and may require admission.
POLYCYTHEMIA

Polycythemia is suggested when an elevated hemoglobin or hematocrit (packed cell volume) is found on CBC testing (Table 231­5). Since hemoglobin and hematocrit values on the CBC are ratios, an elevation can be due to either a decrease in plasma volume or an increase in RBC mass.
The former is termed relative polycythemia and is most commonly caused by dehydration from excessive fluid loss, decreased oral intake, and/or excessive diuresis.
TABLE 231­5
Polycythemia (Erythrocytosis)
Relative Normal RBC numbers and mass, decreased plasma Dehydration, diuretics volume
Absolute Primary Polycythemia vera (JAK2 gene mutation)
Congenital mutations in erythropoietin receptor
Secondary–acquired Central hypoxia: lung disease, high­altitude habitat, chronic carbon monoxide exposure
Renal hypoxia: renal artery stenosis, polycystic kidney disease, post renal transplant
Excess erythropoietin production: testosterone and anabolic steroids, paraneoplastic syndromes
Secondary–congenital Altered oxyhemoglobin affinity
Disordered oxygen sensing
Idiopathic No identifiable cause
Absolute polycythemia is an increase in the RBC mass. Primary polycythemia is due to an acquired or inherited mutation in erythroid cell lines and, less
 commonly, erythropoietin receptor mutations. This category includes polycythemia vera. Secondary polycythemia usually results from increased circulating levels of erythropoietin, directly stimulating RBC production (Table 231­5).
CLINICAL FEATURES
Symptoms of polycythemia are often vague and may include chest, abdominal, or muscle pain and generalized weakness. CNS manifestations may be present, from mild fatigue and headache, to focal neurologic signs and coma. Patients with polycythemia vera will classically present with pruritus when exposed to hot water and early satiety from splenomegaly. Physical exam may reveal splenomegaly in these patients. Additional findings may
 include plethoric facies and ruddy skin, as well as distal cyanosis and clubbing from microemboli. Hyperviscosity syndrome is a life­threatening complication of polycythemia that presents with the triad of bleeding, visual disturbances, and focal neurologic deficits caused by thrombosis and
16­18 microhemorrhage. Patients with polycythemia vera are prothrombotic and at increased risk for venous thromboembolism.
DIAGNOSIS
The diagnosis of polycythemia is suggested by a higher than expected hemoglobin or hematocrit for the patient’s demographics on CBC (a hemoglobin
>18.5 grams/dL [>185 grams/L] or hematocrit >52% in a male and a hemoglobin >16.5 grams /dL [>165 grams/L] or a hematocrit >48% in a female). If relative polycythemia is not suspected, workup of absolute polycythemia should include urinalysis, renal and hepatic function tests, and pulse oximetry. Consider co­oximetry to assess for chronic carbon monoxide poisoning. Erythropoietin level, while not helpful in the acute setting, may guide further assessment. Chest radiograph or cardiopulmonary function testing may be indicated if secondary polycythemia is suspected.
Polycythemia vera may be suggested by history, but formal diagnosis requires bone marrow biopsy or genetic testing in addition to an elevated
 hemoglobin level.
TREATMENT AND DISPOSITION
The treatment of relative polycythemia is with correction of decreased plasma volume. The mainstay of treatment for patients with polycythemia vera
,17 is low­dose aspirin and phlebotomy to a hematocrit of 45%. Pharmacotherapy, including hydroxyurea, interferon­α, systemic anticoagulation, and
15­17,19,20 the JAK1/JAK2 inhibitor ruxolitinib may be initiated after risk stratification and hematology consultation. Polycythemia with hyperviscosity
 syndrome should be managed aggressively, with IV hydration and early hematology consultation.
The patient can usually be discharged when polycythemia is discovered as an incidental finding. Patients with clinical manifestations due to hyperviscosity syndrome require admission.


