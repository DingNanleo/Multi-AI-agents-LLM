## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 302: Military Medicine
D. Aaron Baker; Alex P. Keller, IV; Ryan M. Knight; Sarah Goss; Jared A. Sutton; Nicholas D. Drakos; Michael A. Bellamy
INTRODUCTION
The principles of military medical care are applicable to care in civilian mass casualties, in remote settings, for tactical medicine, and in bioterrorism incidents.
Advanced trauma life support approaches are well applied in a hospital setting, but in combat, how do you function without ancillary staff? What do you do without ready access to a surgical team? How will you manage in the dirt, at night, while engaged with enemy forces? Chapter , “Bomb, Blast, and Crush Injuries,” Chapter , “Chemical Disasters,” and Chapter ,
“Bioterrorism,” discuss many conditions relevant to the combat situation. Table 302­1 lists the roles of medical care for combat casualties.
TABLE 302­1
Military Roles of Medical Care
Role 1: self/buddy aid, nonmedical unit–level combat lifesaver, medic or corpsman aid up to battalion aid station; special operations forces medical elements (SOFME)
Role 2: brigade or division level, medical companies/battalions, support battalions, forward surgical teams, PRBCs, limited x­ray and lab capability, damage control care for evacuation to next role
Role 3: corps level, combat support hospitals, in­theater military treatment facility (MTF), comprehensive stabilizing care for evacuation out of theater
Role 4: definitive care, ultimate treatment capability, full rehabilitative care, tertiary care MTF, typically located in continental United States or comparable out­of­theater safe havens
Abbreviation: PRBCs = packed red blood cells.
EQUIPMENT
Combat casualty treatment requires a properly supplied aid bag. Mission analysis, phases of care, and potential worst­case scenarios guide needed equipment. Pack the aid bag with attention to weight and volume; overpacking creates challenges locating supplies. Supplies with multiple purposes reduce weight and volume. Bundling simplifies tasks (i.e., bundle hemostatic dressings with other wound packing material and compression bandages).
Tables 302­2 and 302­3 provide example packing lists. Building multiple, mission­specific bags or packaging extra bundled items assists with modification of bags and resupply. Every soldier is outfitted with an individual first aid kit (Table 302­4). Train on your personal equipment, maintain it, and pack smartly to ensure easy access to critical items.
TABLE 302­2
Trauma Aid Bag Suggested Packing List
Tourniquets Optional Advanced Airway List
Hemostatic gauze Oropharyngeal airway
Gauze or packed gauze Laryngoscope with blade
Trauma dressing(s)  or  inch Endotracheal tube
Cricothyroidotomy kit* Stylet and/or gum elastic bougie
Nasopharyngeal airway(s) with lubricant Syringe  mL or 10­mL saline flush
Supraglottic airway Endotracheal tube–securing device or tape
Suction device Colorimetric carbon dioxide detection device or esophageal detection device
14­ or 10­gauge, .5­inch decompression needle(s) Digital capnography monitor
Chest seal(s) Optional Items – Mission Dependent†
Bag­valve mask Minor wound kit (suture, needle driver, etc.)
Finger pulse oximetry Chest tube kit
IV starter kit(s) with saline lock Thermometer
Intraosseous device (peripheral and/or sternal) Traction splint
Sodium chloride flush(es) (10 or  mL) Cervical collar, adjustable
IV administration tubing (10 gtt) Otoscope/ophthalmoscope
IV fluid for blood administration priming and carrier fluid IV fluids (i.e., volume replacement for burns, dehydration)
Pressure infuser device Red/green/blue/yellow glow sticks for marking and mass casualty events
Sharps container Litter
Abdominal dressing Blood pressure cuff with stethoscope (may not be useful in noisy environments)
Junctional hemorrhage device (consider one that also works as pelvic splint) Electronic monitors (minimum with noninvasive blood pressure and pulse oximetry)

Cravat or elastic bandage(s) Ventilator
Chapter 302: Military Medicine, D. Aaron Baker; Alex P. Keller, IV; Ryan M. Knight; Sarah Goss; Jared A. Sutton; Nicholas D. Drakos; MPicahgaee 1l A/ .8
Splint(s), malleable Basic Medication List
Bellamy
Tape, silk  inches Hard plastic case
. Terms of Use * Privacy Policy * Notice * Accessibility
Exam gloves Combat wound medication pack (acetaminophen, meloxicam, moxifloxacin)
Trauma shears Syringes (1, , and  mL)
Casualty cards 18­gauge filter and 21­gauge needles
Permanent marker Alcohol pads
Hypothermia management Tranexamic acid
Scalpel #10 blade Ketamine
Large skin stapler Fentanyl oral transmucosal lozenge
Chlorhexidine and/or betadine swab(s) Narcotic analgesia (hydromorphone, morphine, or fentanyl)
Eye shield(s) Midazolam
Headlamp with colored filter Naloxone
Sick call items Ondansetron orally disintegrating tablet/IV
Blood Transfusion Lidocaine 1%
Blood cooler/transport container Ertapenem
Blood tubing with filter Epinephrine (vial or autoinjector)
Blood product(s) Benadryl
Normal saline Tetracaine, ophthalmic
*”Kits” are packaged together as a functional unit in a resealable plastic bag or vacuum sealed with quick­open tabs.
†Optional items may need to be in additional bags and located on evacuation platforms or secured locations.
TABLE 302­3
Items to Be Carried on Medical Provider
Light­emitting diode headlamp with colored filter
Tourniquet(s) (immediately available and reachable by both hands)
Trauma dressings (4 inch) or elastic bandages
Hemostatic gauze
Gauze
Cricothyroidotomy kit
Nasopharyngeal airway(s) with lubricant
14­ or 10­gauage, .5­inch decompression needle(s)
Chest seal(s)
Finger pulse oximeter
Combat pill pack(s)
Analgesic medication (fentanyl oral transmucosal lozenge preferred)
Trauma shears or rescue knife
Examination gloves heavy duty
Casualty cards
Permanent marker
Nine­line medical evacuation card
TABLE 302­4
Individual First Aid Kit Packing List
Tourniquet (reachable by both hands)
Trauma dressing
Hemostatic gauze
Gauze
Nasopharyngeal airway with lubricant
14­ or 10­gauge, .5­inch decompression needle
Chest seal
Trauma shears or rescue knife
Examination gloves, heavy duty
Combat wound medication pack
Casualty card
Permanent marker
TACTICAL COMBAT CASUALTY CARE
Tactical combat casualty care (TCCC) is a standardized, prehospital combat trauma guideline designed to address preventable causes of death. TCCC has three phases of care: care under fire, tactical field care, and tactical casualty evacuation.
PHASE 1: CARE UNDER FIRE
The medical actions taken under enemy fire are extremely limited: apply tourniquet for massive exsanguination, protect the casualty, and move him or her to safety. The urge to tend to a casualty must be tempered by situational awareness: return fire, and secure the site before tending to casualties.
TOURNIQUET APPLICATION
A tourniquet is the first­line intervention for massive hemorrhage in a combat setting. If applied before the onset of shock, survival is improved from 17% to 94%.1,2 A wide tourniquet (at least
### .5 inches wide) causes less soft tissue damage and is more comfortable for the patient. To control hemorrhage from a large vessel, a tourniquet must have a windlass to gain a mechanical advantage when tightening. Tourniquets without a windlass cannot attain sufficient force to stop arterial bleeding. In combat, we use a tourniquet that can be applied with one hand for selftreatment.3
Place the tourniquet about  inches proximal to the wound.4 Tighten to greater than arterial pressure, because tightening that exceeds venous but not arterial pressure may increase bleeding. Apply the tourniquet until the distal pulse disappears. If no distal pulse is present on initial evaluation, apply the tourniquet with a force estimated to be greater than the systemic blood pressure. If placement of a single tourniquet does not control bleeding, place a second tourniquet immediately adjacent and proximal to the first. See “Tourniquets,” in Chapter 254,
“Trauma in Adults.” See Figures 254­1, 254­2, and 254­3 for images and detailed application instructions of TCCC­recommended tourniquets.
POSTTOURNIQUET CARE
The safe time limit for tourniquet application has not been determined. Tourniquets are routinely left in place for up to  hours in the operating room, and this is the basis for the recommendation to remove a tourniquet within  hours, situation permitting.5 At  hours with a tourniquet in place, it is probably best not to remove it; at this point, the release of potassium, lactate, myoglobin, and other toxins from a severely acidotic limb into the circulation would likely cause more systemic harm than benefit. There are, however, several cases of limb salvage with tourniquet times greater than  hours.6
A tourniquet is a temporizing measure. The next step is to convert the tourniquet to an effective pressure dressing, using direct pressure and a basic gauze roll and elastic wraps and/or hemostatic agents, if required. A knee or hand can apply additional pressure to the bleeding site or proximal pressure point. Once an effective pressure dressing is applied, release but DO
NOT REMOVE the tourniquet. If bleeding recurs, retighten the tourniquet to control bleeding.
PHASE 2: TACTICAL FIELD CARE—THE PRIMARY SURVEY
This phase begins once the patient and provider are no longer under effective enemy fire. Tactical security, similar to “scene safe” in civilian EMS training, must be maintained at all times.7
Conduct a complete primary survey and perform lifesaving interventions.
Combat medicine deviates from the universally accepted airway, breathing, and circulation algorithm. Massive hemorrhage is the most common correctable cause of death on the battlefield and is the top clinical priority in battlefield trauma care.7 Airway compromise accounts for relatively few combat deaths, and respiratory difficulties typically progress over time. This is the reason that TCCC recommends the modified primary survey algorithm of MARCH:
Massive hemorrhage
Airway
Respiratory
Circulation
Hypothermia prevention/head injury
After hemorrhage control, the algorithm mirrors the airway, breathing, and circulation algorithm, with the additional consideration of a closed head injury and hypothermia prevention as primary survey responsibilities. Level of consciousness and pulse strength are used as indicators of peripheral perfusion in injured soldiers. If the soldier’s peripheral pulse is weak or absent, if the level of consciousness is altered, or if the solder is not verbally responsive, then immediate intervention is needed before moving down the algorithm.
MASSIVE HEMORRHAGE
Topical Hemostatic Agents
If the wound is not amenable to tourniquet use and a pressure dressing is inadequate, use a hemostatic agent. The TCCC Committee recommends the following agents: Combat Gauze®
(zeolite impregnated gauze), Celox Gauze® and ChitoGauze® (both chitosan­impregnated gauze), and XSTAT® (chitosan­impregnated sponge).8
To apply any of these gauze­like hemostatic agents, prepare the wound by evacuating excess blood, taking care to preserve any clot that may have formed around the damaged vasculature; pack the hemostatic gauze/sponge directly over the site of the most active bleeding; repack or adjust the gauze for optimum placement; and use additional hemostatic agent as required. With the exception of XSTAT®, hold direct pressure for a minimum of  minutes, then reassess for bleeding and repack as needed. Secure the hemostatic agent in place with a pressure dressing.
Do not remove XSTAT® in the field. If bleeding continues, pack directly over it.
Junctional Hemorrhage
Junctional hemorrhage (from the “junctional” anatomic area between the limbs and intracavitary areas of the abdomen or thorax) is difficult to control. Hemorrhage in the axilla and groin is not amenable to tourniquet application and hemostatic agents.9 Specialized junctional tourniquets may be beneficial in certain cases. Presently, these include the Abdominal Aortic
Tourniquet,10 the Combat Ready Clamp®,11 the Junctional Emergency Tourniquet Tool,12 and the SAM Junctional Tourniquet®.13 Each product has specific directions for application.
A potential tool in the management of abdominal and junctional hemorrhage that fails to respond to other measures is resuscitative endovascular balloon occlusion of the aorta (REBOA — see Video 302­1). See Chapter 254 for a discussion of REBOA. REBOA has been performed successfully in combat >20 times by U.S. Air Force surgical teams,14 but is currently not considered a first­line treatment for out­of­hospital junctional hemorrhage.15 The use of prehospital REBOA is still largely unexplored and thus requires extensively careful selection before implementation.16
Video 302­1: REBOA
Video Credit: The Tarpan Group
Play Video
Systemic Hemorrhage Control: Tranexamic Acid
Tranexamic acid decreases mortality in trauma.17 It is recommended for use in all casualties that require significant fluid or blood products, both children and adults. Tranexamic acid is most effective when given within  hour of injury and must be given within the first  hours. The dose is  gram of tranexamic acid in 100 mL of normal saline, infused over  min.18
AIRWAY
Airway intervention during the primary survey is similar for both combat and civilian casualties. Less than 1% of combat trauma requires lifesaving airway intervention in the prehospital setting.19,20
If there are no spontaneous respirations after opening the airway, the casualty is triaged to the expectant category (expected to die) in a mass casualty (MASCAL) situation (defined as more casualties than resources available); if the situation and resources allow, perform advanced airway techniques including cricothyrotomy,21 supraglottic airway intubation,22 and mechanical ventilation. If space is limited, cricothyrotomy equipment is the most important. In austere conditions with minimal sedatives and analgesics, prolonged evacuation times spanning hours to days, and delayed medical logistical resupply, the threshold for performing a cricothyrotomy should be low. It is critical to confirm placement and firmly secure the airway.
RESPIRATORY/BREATHING
Tension Pneumothorax
The nearly universal use of body armor in present combat operations provides critical protection to the chest and upper abdomen, as evident in the 5% to 7% thoracic wound rate, the lowest in U.S. military conflicts.23
In a tactical setting, the threshold to perform a needle decompression is very low, as most casualties with penetrating chest trauma in respiratory distress will have some degree of hemo­ or pneumothorax and possible tension pneumothorax. Use the largest and longest catheters available. The TCCC minimum standard is the 14­gauge, 3­inch­long needle.24 However, there are
10­ and 12­gauge catheters available in 3­inch lengths that are highly recommended over the standard because they are less likely to kink when penetrating a muscular chest or occlude with patient movement. Two locations are recommended: (1) the second intercostal space, midclavicular line; or (2) the anterior axillary line at the fourth to fifth intercostal space (see Chapter ,
“Pneumothorax,” for further discussion).25
Penetrating Chest Trauma
Penetrating chest trauma with open pneumothorax or sucking chest wounds is common with large injuries to the chest wall. The updated TCCC standard is to use a valved/vented chest seal as the first choice. Unvented chest seals require continuous reassessment for possible accumulating tension pneumothorax and need for needle decrompression.26 Most casualties encountered in a combat setting are bloody and sweaty; applying a chest dressing that actually adheres to the chest requires skill and proper preparation of the skin. Wipe the skin as dry as possible. Consider using tincture of benzoin or Mastisol® to facilitate dressing adherence if it is available and you have the luxury of time.
Chest Tubes
The lifesaving intervention for a chest injury in the setting of tactical field care is needle decompression; a chest tube is not immediately required. Needle decompression can be as effective as a chest tube in a patient for up to  hours if the patient is not subjected to much movement.27 Needle decompression can be repeated as needed.
CIRCULATION
The TCCC mainstays of circulation management are the appropriate use of low­volume resuscitation (also known as permissive hypotension or hypotensive resuscitation) and the preferred resuscitation fluids. The first step is vascular access.
IV Access
Vascular access is the lifeline for severe combat casualties. Smaller­bore IVs (primarily 18­gauge catheters) are preferred in a tactical environment to provide fluid resuscitation. If blood products are available, which is atypical at this phase of field care, then a larger­gauge catheter is indicated.
It is critical to firmly secure the catheter in the combat setting. Use a clear adhesive bandage first; then wrap enough tape to ensure that the catheter will hold in place if you were to throw the
IV bag. There are also commercially available IV catheters with Velcro® wraps that work very well.
IO Access
An IO line is the alternative to IV access. Nearly universal use of body armor in the modern tactical environment protects the sternum, so this site is ideal for IO access. Provide secure fixation to prevent dislodgement during patient movement. Some devices may require a removal instrument, which you should secure to the patient; without this removal instrument, the IO must be surgically removed at the next level of care.
Permissive Hypotension/Low­Volume Resuscitation
Following the landmark 1994 Ben Taub study documenting increased survival,28 permissive hypotension is the TCCC standard for managing penetrating wounds of the abdomen, thorax, junctional areas where specific tourniquets have failed, or any noncompressible hemorrhage. The goal is to preserve survival of casualties by maintaining a delicate balance between a blood pressure high enough to provide adequate tissue perfusion but low enough to avoid clot “blow­out” and clotting factor dilution. Current recommendations are to maintain a mean arterial pressure of  mm Hg or a systolic blood pressure of approximately  to  mm Hg.29,30 A blood pressure of  to  mm Hg is clinically noted by a normal level of consciousness and a weakly palpable radial pulse.31 The exception is the multiple trauma casualty with head injury; maintain a systolic blood pressure between  and  mm Hg to preserve cerebral blood flow.32,33
Resuscitation Fluid
The prehospital resuscitation fluid of choice for combat trauma has changed over the past  years of U.S. military conflict. The goals of the TCCC Committee in recommending the appropriate resuscitation fluid are the following:
. Enhance the body’s ability to form clots with platelets, plasma, and red blood cells at sites of active bleeding.
. Minimize adverse effects (edema and dilution of clotting factors) resulting from iatrogenic resuscitation injury.
. Restore adequate intravascular volume and organ perfusion prior to definitive surgical hemorrhage control.
. Optimize oxygen­carrying capacity as much as possible.
The current resuscitation fluid recommendations for severe hypovolemic shock are as follows, in order of preference: (1) fresh whole blood; (2) blood components in a 1:1:1 ratio of packed red blood cells (PRBCs):plasma:platelets; (3) blood components in a 1:1 ratio of PRBCs:plasma; (4) plasma (freeze­dried plasma or fresh frozen plasma appropriately reconstituted); (5) PRBCs;
(6) Hextend®; and (7) lactated Ringer’s or multiple electrolyte injection, type . Whole­Blood and Blood Component Infusions
In the combat setting, prehospital blood transfusion is carried out under specifically approved theater protocols by specially trained and certified providers and medics. For example, several special operations units can give European­produced freeze­dried plasma under an approved protocol.
Fresh whole blood is the TCCC primary resuscitation fluid of choice because it has all the required blood components in their natural state and provides a survival advantage to casualties with severe trauma and shock.34,35 In a battlefield environment, whole blood is often obtained from fellow soldiers known as “walking blood banks” or special operations forces tactical universal donors. During Operation Iraqi Freedom, 13% of blood transfusions used fresh whole blood.33
All potential donors should be screened for pathogen risk, although perceived risk is often outweighed by potential benefit; additionally, all recipients and donors have blood samples sent to the Armed Forces Blood Program for retrospective analysis. The collection kits for fresh whole­blood transfusions are readily available through military medical supply channels. Over the past several years of combat, special operations medical teams have employed cold­stored low­titer type O whole blood. This product is collected and produced at military blood­banking facilities and shipped to locations in Iraq and Afghanistan. Cold­stored low­titer type O whole blood typically has a shelf­life of only  days, limiting its utility on a large scale compared with standard PRBCs, which typically have a 42­day shelf­life.
In response to blood supplies that may not meet the wartime requirements due to collection, transport, storage, and distribution issues, some entire theaters have embraced “walking blood bank” or “tactical donor” programs. In 2018, United States Forces Korea instituted a tactical donor program that prescreens both low­titer type O universal whole blood donor personnel and type­specific donors (Figures 302­1 and 302­2). Using operationally secure identification cards, each prescreened individual can act as a blood donor once every  days for a full year from the date of testing, dramatically reducing time from injury to resuscitation with fresh warm whole blood, as well as reducing the cost for one unit of reconstituted 1:1:1 therapy from approximately $650 to $150 for the prescreened donor testing and special operations forces blood collection kit combined. Providers can use these individuals within a fixed treatment facility or at the point of injury during combat conditions without specialized blood storage or testing equipment.36
FIGURE 302­1. Universal donor card example, with low­titer O­positive blood.
FIGURE 302­2. Type­specific donor card example.
If fresh whole blood is not available, the next preferred choice is plasma, PRBCs, and platelets in a 1:1:1 ratio.37,38 A unit of plasma is given first, followed by the PRBCs, and then platelets. In addition to PRBCs, the military fields frozen red blood cells to augment current supplies of liquid­packed red blood cells, although the thawing process (deglycerization) creates a rate­limiting step during active hostilities.
The next preferred choice is PRBCs and plasma in a 1:1 ratio if platelets are not available.39,40 Plasma is again given first, followed by PRBCs. Advances in warm platelet storage will hopefully increase the availability of platelets in the near future.
If availability of blood products is limited, you may have to choose between PRBCs and plasma alone. Debate exists as to whether PRBCs or plasma alone is best, so product availability is more likely to drive this decision. Although availability of plasma is somewhat limited, some special operations combat medics can now carry freeze­dried plasma, as well as PRBCs. The freeze­dried plasma concentrate currently carried by U.S. medics is produced in France and available for use by the North Atlantic Treaty Organization.41 All patients who receive blood or blood products in the field or who the provider expects may require blood products should receive  gram of IV tranexamic acid if it can be administered within  hours of wounding.17
Colloids and Crystalloids
If no blood products are available, Hextend® (hetastarch, synthetic colloid, in lactated Ringer’s solution) is recommended.42 It is compatible with tranexamic acid.43 Colloid has a clear advantage from a weight/volume perspective in the prehospital environment, where the medic must carry the fluid on his back. Hetastarch 500 mL provides intravascular volume expansion of
600 to 800 mL. Hextend® is potentially protective against multisystem trauma–induced acute respiratory distress syndrome, induces a favorable acid­base balance, and results in less severe coagulopathy.44 Indiscriminate colloid use can have coagulopathic and immunologic effects, but these adverse effects typically do not occur with colloid administrations of <1500 mL.45,46
If fluid resuscitation requires >1500 mL of colloid, lactated Ringer’s solution is given next. Initial use of colloids to replenish intravascular volume during resuscitation must be balanced at some point with an appropriate volume of crystalloid to avoid extensive intracellular dehydration. Start with a 500­mL bolus, and repeat the bolus in  minutes if there is no clinical response, using pulse strength and level of consciousness to guide the volume infused. Maintain a systolic blood pressure of  to  mm Hg, but in head injury, a systolic blood pressure between  and 100 mm Hg may be required to ensure sufficient cerebral perfusion pressure.
One liter of infused lactated Ringer’s results in only 200 to 250 mL of intravascular volume expansion; normal saline is not recommended for resuscitation due to the hyperchloremic acidosis it produces.47 Additionally, aggressive resuscitation with saline­based resuscitation strategies is associated with a number of adverse effects, including increased bleeding, acute respiratory distress syndrome, multiorgan failure, acute coronary syndrome, and increased mortality.48­50
Other Resuscitation Solutions
Hypertonic saline has some benefits in the intensive care setting.51­53 Hypertonic saline 3% is the first­line adjunct therapy in the Joint Trauma System Neurosurgery and Severe Head Injury
Clinical Practice Guildline.54 Additional options include mannitol or .4% saline.55 When commercial hypertonic saline is not available, providers can add  mL of .4% saline to 500 mL of
.9% saline to achieve a .98% saline solution to simplify dosing options. Hypertonic saline may be administered through both IV and IO access.
Hemoglobin­based oxygen­carrying solutions are promising, but none are presently approved by the U.S. Food and Drug Administration or available on the commercial market.56,57
Oral Hydration
In the combat setting, there are often limited IV fluids available and long waiting times for evacuation or surgical intervention. In the patient with a normal level of consciousness, the risk of aspiration is very low and outweighed by the benefit of maintaining adequate hydration and patient comfort if evacuation is delayed. As such, oral fluid hydration is acceptable for combat casualties in many situations, even if surgery is anticipated at the next level of care. The only contraindication is active vomiting or an altered level of consciousness that increases risk of aspiration. Time to surgery is not an issue in oral provision of clear liquids to combat casualties.58
HYPOTHERMIA AND HEAD INJURY
Under TCCC, we prevent hypothermia by wrapping the patient in a multilayer insulating wrap with a vapor barrier liner. Closed head injury is one of the final considerations in this modified algorithm. If a casualty has an altered level of consciousness, it is either because of inadequate cerebral perfusion or cerebral injury. If hypovolemic shock has been ruled out or treated and the mechanism is consistent with closed head injury, we treat for head injury. Have the patient recline with the head elevated at  degrees. Give oxygen to maintain an oxygen saturation of at least 90%. Maintain a systolic blood pressure of at least  mm Hg.31 Consider adjunct therapy such as hypertonic saline or mannitol and minimize interventions that may cause constriction of venous return in the neck such as cervical collars and endotracheal tube tie systems.
SECONDARY SURVEY
Expose the casualty as much as the tactical situation will allow. Be prepared to preserve body heat to avoid hypothermia. Stabilize fractures and treat less severe wounds. Continually reassess the casualty. Attend to the casualties who require intervention, but remember to reassess everyone. This can be as quick as asking a quick question to assess airway, hemodynamic status, and level of consciousness, or quickly palpating a radial pulse to determine rate and strength; obtain blood pressure if possible. The character of the peripheral pulse and the Glasgow Coma Scale are reliable severity indicators.59 Recheck dressings or bandages for continued bleeding.
PAIN CONTROL
Pain control is crucial for facilitating transport and patient comfort. Under TCCC, there are three primary pharmacologic modes of pain control. For lesser injuries with normal mental status, use a combat wound medication pack.7 This contains two 500­milligram acetaminophen tablets and a meloxicam tablet. This combination is effective for moderate pain control, does not affect mental status, and is administered orally. Because meloxicam has a favorable side effect profile and no effect on platelet function, it is the TCCC NSAID of choice.7
FENTANYL AND KETAMINE
For more severe pain, we recommended either oral transmucosal fentanyl citrate lozenge, informally known as the fentanyl “lollipop,” or ketamine. Oral transmucosal fentanyl citrate provides rapid­onset, long­lasting pain relief for severe pain without the need for an IV. When placed into the buccal fold and slowly sucked on, 25% of the fentanyl is absorbed sublingually, with onset in  minutes. The remainder that is swallowed enters the GI tract and loses about 50% of its bioavailability through first­pass effect, but the remaining 50% is slowly absorbed, providing more extended pain relief for the next  to  hours.60 An 800­microgram fentanyl lozenge is the recommended starting dose. Rapidly chewing and swallowing the lozenge will decrease the total amount of fentanyl received, because less is absorbed sublingually and more is subject to first­pass effect. To avoid swallowing, the recommended technique is to tape the lozenge to the patient’s finger, which will deter swallowing and prevent overdosing should the patient become somnolent (as the lozenge attached to the hand will fall from the mouth). If pain control is not achieved in  minutes, a second 800­microgram lozenge can be placed in the other cheek. Fentanyl can also be given intranasally with the use of a nasal atomizer.61 If an IV is available, then IV fentanyl or IV ketamine can be used and titrated to effect.
Ketamine at subdissociative doses is an effective pain control agent. It can be given IM, IV, IO, or intranasally via nasal atomizer or syringe with rapid onset and good efficacy. The initial dose is  milligrams IM or intranasally repeated every  minutes and titrated to effect, or  milligrams IV/IO by slow push repeated every  minutes and titrated to effect. For treatment of associated nausea, the TCCC Committee now recommends ondansetron oral dissolving tablets every  hours as needed.
ANTIBIOTICS
All war wounds are dirty and contaminated. Early antibiotic use with such wounds may decrease subsequent infection.62 For those able to tolerate PO administration, a single 400­milligram dose of oral moxifloxacin, found in the combat wound medication pack,7 is recommended. For casualties with hypotension or an altered level of consciousness, administer ertapenem,  gram IV.
SPECIFIC INJURIES
BURN CARE: UNDERSTANDING THE ENVIRONMENT
Resuscitation decisions for burns in an austere environment are influenced by the availability of medical supplies and the time from definitive care. Underresuscitation may result in shock and progression into the lethal triad (hypothermia, acidosis, and coagulopathy). Overresuscitation may result in fluid overload and respiratory collapse with little to no equipment available to handle an airway emergency.
When optimal resources are available, the Joint Trauma System Clinical Practice Guidelines recommend using fluid resuscitation software (Burn Navigator) to determine fluid resuscitation rates.63 The device makes isotonic fluid rate of administration recommendations based on the patient’s urine output to keep the patient’s resuscitation in the ideal range. This device is not recommended for electrical burn injuries that have caused rhabdomyolysis.63
If fluid resuscitation devices are not available, a simplified rule of 10s is used for burn management, which is clinically effective and easy to implement in a prehospital environment.64 For burns >20% total body surface area, first estimate the total body surface area burned to the nearest 10%. Then, for adults weighing  to  kg, give IV fluid as follows:  mL × % total body surface area burn per hour. For every  kg of patient weight above  kg, add another 100 mL of fluid per hour (resuscitation for hemorrhagic shock takes precedence over resuscitation for burn shock).
For example, for a 90­kg patient with 40% total body surface area burns, the following would be given: 40% ×  mL = 400 mL, plus 100 mL for  kg above the  to  kg range, giving a total of
500 mL of IV fluid per hour. Once the patient is at a higher level of care, the fluid rate can be adjusted based on clinical status and urinary output.
BLAST INJURIES
Injuries from explosions are exceedingly common in combat and frequently cause overpressurization injuries. Tympanic membrane perforations and hypopharyngeal petechiae are common findings in blast casualties and are easily missed without a thorough exam. After the 2013 Boston Marathon bombings, only  of 127 patients evaluated on the day of the bombing
(11.8%) were diagnosed with tympanic membrane injuries.65 More than 100 patients who were hospitalized after the event were prospectively followed, and 90% were found to have sustained tympanic membrane injuries.66 There are many factors that contribute to a pattern of injury, such as body orientation relative to the blast and confined versus open space, so be wary of relying on a particular clinical finding to triage casualties.67 If anything, the most reliable sign may be respiratory distress immediately after the blast. Casualties with clinically significant lung injury typically manifest as respiratory failure within minutes of the blast.67,68 See Chapter , “Bomb, Blast, and Crush Injuries,” for detailed discussion. All casualties should be screened for traumatic brain injury.
CERVICAL SPINE INJURY
The vast majority of penetrating injuries in the combat setting do not require cervical spine immobilization, unless there is direct injury to the neck with associated neurologic deficit.69
Cervical spine immobilization for penetrating injury in a combat casualty is not recommended because it will impede the ability to manage the more immediate concerns of a penetrating neck injury. Blunt head trauma should be treated with cervical spine immobilization, situation permitting, as practiced in the civilian sector.70
ABDOMINAL TRAUMA
Although body armor does provide some protection to the upper abdomen, the lower abdomen is still relatively vulnerable. There is a groin attachment for the issued body armor that provides some protection to the lower abdomen and groin, but it is composed of flexible Kevlar® to allow freedom of movement, rather than the more durable rigid Kevlar® plate that is used to protect the chest and back. Use of this additional piece of equipment has become more prevalent among combat troops.
With a significant large­vessel (aorta, inferior vena cava, iliac vessels), liver, or splenic injury, there is not much a combat physician can do to save a casualty. In this situation, stabilize the casualty as best as possible, start an IV, administer antibiotics, and transport to a higher level of care with surgical capability immediately. For management of difficult­to­control, noncompressible massive hemorrhage, see the section on massive hemorrhage control and REBOA.
If there is a bowel evisceration, replacing the contents will minimize insensible fluid and heat loss and allow for easier casualty movement. First remove any significant particulate matter or dirt; then attempt to replace the bowel contents intra­abdominally (this might not be possible if there is significant bowel edema and/or a small abdominal defect); cover exposed bowel and the abdominal defect with a moist dressing; cover with plastic wrap or other fluid­impervious dressing to minimize insensible fluid loss; start an IV and administer IV fluids as needed; and administer IV antibiotics in preparation for evacuation.
PELVIC TRAUMA
The standard torso body armor does not provide any protection to the pelvis. The groin attachment protects the genital region and some of the perineum, but the inguinal regions are left largely unprotected. The femoral vessels are vulnerable to penetrating injury, often resulting in life­threatening hemorrhage.
A tourniquet or pressure dressing to a proximal femoral artery or vein injury may be ineffective. For this type of injury, use of a hemostatic agent is imperative. Direct pressure should be applied to gain immediate control of the bleeding. Vessel clamping should only be attempted if an effective tourniquet or pressure dressing cannot be applied, a hemostatic dressing is not available, there is no device to control junctional hemorrhage, and there is no ability for immediate evacuation.
Pelvic fractures can result in significant hemorrhage that is difficult to control. Determination of a pelvic fracture, if not obvious, should be done from symptoms of pain and a clinical suspicion. The practice of “springing” or doing a “pelvic rock” is no longer recommended because this technique is likely more harmful than beneficial.71 Past recommendations of improvised pelvic splinting with a sheet to produce needed compression for hemorrhage control can be used (if no other more effective options are available), but such splinting is inferior to more recent commercially manufactured pelvic splints and binders.71
EXTREMITY AMPUTATION
About 7% of wounded soldiers in Operation Iraqi Freedom and Operation Enduring Freedom had a major extremity amputation, and 50% of soldiers killed in action or who died of wounds had major amputations.72 Field treatment of an amputation is focused primarily on hemorrhage control and preserving as much tissue as possible. Often the vessels of the limb have retracted proximally from the initial force of the amputation, making it particularly difficult to identify and control hemorrhage. It may appear that hemostasis has been achieved with little effort; however, effective hemorrhage control may be necessary in the form of a hemostatic agent, pressure dressing, or tourniquet because delayed bleeding often occurs as the damaged vessels relax and dilate shortly after the patient appears stable. Constant reevaluation of the patient is essential. A partial amputation where the limb is still attached by substantial tissue or bone should be treated the same as an open fracture with hemorrhage control, wound debridement and irrigation, antibiotic administration, and splinting in an attempt to salvage the limb.
MASS CASUALTY TRIAGE
Mass casualty, or MASCAL, events are generally defined as medical contingencies in which the number and needs of the casualties exceed available resources (personnel and supplies).
MASCAL events are time­constrained, complex operational problems that require the understanding and calculation of multiple risk variables to accomplish the goal of doing the most good for the greatest number of people.73 In addition to medical considerations, risk variables may include mission objectives, ongoing kinetic activity and threats, availability of casualty evacuation platforms, time and distance to other treatment facilities, environmental conditions, nonmedical manpower, and communications.74 It is critical to have a rehearsed and validated
PACE (Primary, Alternate, Contingency, Emergency) MASCAL response plan.74 After security considerations, the first step in any MASCAL response will involve the consolidation and triage of casualties.
The triage process is ongoing and dynamic and should occur at and through each level of care. Optimal triage is a key component of managing a MASCAL (Table 302­5 provides one example of a simple triage algorithm) that requires a system of command and control, the funneling of casualties through a single designated triage point, a triage algorithm, and a designated triage officer. Medical providers familiar with triage algorithms, triage­specific training, and more relevant clinical experience achieve better accuracy in the triage process.75,76 Multiple triage algorithms exist. Validation of algorithms is difficult, and no standardized criteria exist to assess algorithm efficacy.76,77 However, evidence suggests that the SALT algorithm (Figure 302­3) best balances sensitivity and specificity.76
TABLE 302­5
Mass Casualty Triage Algorithm
AIRWAY: Is the casualty moving air?
Yes—assess breathing
No—open airway, moving air now?
Yes—assess breathing
No—EXPECTANT
BREATHING: Respiratory rate >30 breaths/min?
Yes—IMMEDIATE, address cause
No—assess circulation
CIRCULATION: Radial pulse weak/absent or heart rate >140 beats/min?
Yes—IMMEDIATE, address cause
No—assess mental status
MENTAL STATUS: Responds to simple commands?
Yes—NOT an IMMEDIATE
No—IMMEDIATE, address cause
FIGURE 302­3. SALT (sort, assess, lifesaving interventions, treatment/transport) triage algorithm.
THREE­TIER PRIORITIZATION
SALT stands for sort, assess, lifesaving interventions, and treatment/transport, which are the key activities that must be accomplished during the triage process. SALT begins with a global sorting of casualties, prioritizing them into three tiers for individual assessment. The triage physician directs casualties to walk to a designated area “if they need help.” Those who follow the command to walk are the last priority for individual assessment, because they demonstrate an intact airway, breathing, circulation, and mental status and are therefore the least likely to have a life­threatening condition. The remaining casualties should then be asked to wave or be observed for purposeful movement. Those who remain still and do not move, as well as those with obvious life­threatening injuries, such as massive external hemorrhage, are assessed first. Those who wave are individually assessed next, followed by the ones who previously walked to a designated area. Although this initial sorting is not perfect, it is an attempt to organize numerous casualties.
INDIVIDUAL CASUALTY ASSESSMENT
The second step of SALT is to perform individual assessments and apply lifesaving interventions, such as controlling massive external hemorrhage or opening an airway. Lifesaving interventions must meet all of the following criteria: can be provided quickly; can greatly improve a casualty’s likelihood of survival; does not require the physician to stay with the casualty; are within the physician’s scope of practice; and require only immediately available equipment. After appropriate interventions are performed, casualties are prioritized for treatment and assigned to one of the following triage categories: immediate, delayed, minimal, and expectant (includes the dead for the purpose of military triage), known in the military by the acronym DIME.
Colored triage tags or chemical light markers can mark casualties based on triage category. Colored triage tags typically are red for immediate, yellow for delayed, green for minimal, and black for expectant or deceased. If chemical light sticks are employed, red is typically used for immediate, green/yellow for delayed, and blue for expectant. Avoid using green and yellow chemical lights for different triage categories to mirror the markings on the triage tags, because it may be difficult to distinguish the two colors during night operations.
The field triage score is another easy, rapidly applicable method to identify casualties who are more seriously injured and expected to have a higher mortality. The field triage score is based on two variables: character of the radial pulse and the motor component of the Glasgow Coma Scale (GCS­M), namely the ability to follow commands. A weak or absent radial pulse, which correlates with a systolic blood pressure of ≤90 to 100 mm Hg, is assigned a score of , whereas normal pulse character (systolic blood pressure >90 to 100 mm Hg) is assigned a score of . Similarly, an abnormal GCS­M (<6) is assigned a score of , whereas the ability to follow simple commands (GCS­M of 6) receives a score of . A casualty can therefore receive an aggregate field triage score of , , or . A retrospective review of 4988 casualties in Iraq and Afghanistan from 2002 to 2008 demonstrated that those with a field triage score of  had a mortality of only .1%
(5 of 4366), whereas those with a field triage score of  and  had a mortality of .8% (33 of 540) and .4% (34 of 82), respectively.78
Triage categories are not the same as evacuation categories. Triage identifies the severity of a casualty’s injuries and determines a treatment priority based on the likelihood of survival, whereas evacuation is based on the urgency of transport to definitive care and the likelihood of deterioration over time. Triage is an ongoing, dynamic process, and triage categories may change if an intervention stabilizes a casualty or if a casualty deteriorates clinically. For example, a delayed casualty with second­degree burns over 30% of his body may change to the immediate triage level if unrecognized inhalational injury leads to airway swelling and compromise.
CPR
Battlefield resuscitation of victims of blast or penetrating trauma who have no pulse, respiratory effort, or other signs of life will not be successful and should not be attempted because CPR on combat casualties has failed to show any benefit.79,80 Therefore, CPR on the battlefield is not currently recommended. Even in the civilian setting, very few trauma arrest patients survive when prehospital CPR is performed.81,82 In a tactical situation, CPR should be considered only as a last effort if the situation permits and appropriate resources are available and in the case of nontraumatic disorders such as hypothermia, near­drowning, and electrocution. Casualties with torso trauma or polytrauma, who are pulseless and apneic, should receive bilateral needle decompression of the chest to ensure they do not have a tension pneumothorax prior to discontinuation of care.


