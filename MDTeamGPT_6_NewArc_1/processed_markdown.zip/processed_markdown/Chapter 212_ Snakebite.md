## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 212: Snakebite
Richard C. Dart; Julian White
INTRODUCTION AND EPIDEMIOLOGY

Venomous snakes account for an annual estimated .5 million to  million bites and possibly greater than 100,000 deaths worldwide. The American
Association of Poison Control Centers reports an annual average of 6000 bites, approximately 2000 of them by venomous snakes. Because of
 underreporting, the true number of snakebites in the United States is possibly as high as ,000 per year, with 7000 to 8000 by venomous snakes. The major venomous snakes of the world can be divided into three groups: Viperidae (vipers and pit vipers), Elapidae (includes Hydrophiinae, or sea snakes; see Chapter 213, “Marine Trauma and Envenomation”), and the diverse group of non–front­fanged colubrid snakes (former family Colubridae, now split into several families).
In the United States, most snakebites occur in the warm summer months, when snakes and victims are most active. In the past, it was estimated that mortality from venomous snakebite approached 25%. Because of the availability of antivenom and advances in emergency and critical care, mortality
 rates today are <0.5%; approximately five deaths occur per year.
Except for bites by imported species, North American venomous snakebites involve the pit vipers (Crotalinae subfamily of Viperidae) or coral snakes
(Elapidae family). The crotaline snakes are represented by the rattlesnakes (Crotalus species), pygmy rattlesnakes, and massasauga (Sistrurus species), as well as the copperheads and water moccasins (Agkistrodon species). Venomous snakebites from imported exotic species are infrequent, but may occur in zoo personnel as well as in amateur herpetologists. A regional poison control center can provide information on snake identification, expected toxicity, and location of antivenom.
CROTALINAE (PIT VIPER) BITES
The crotaline snakes are called pit vipers because of bilateral depressions or pits located midway between and below the level of the eye and the nostril (Figure 212­1). The pit is a heat receptor that guides strikes at warm­blooded prey or predators. Crotaline snakes are also distinguished by the presence of two fangs that fold against the roof of the mouth, in contrast to the coral snakes, which have shorter, fixed, erect fangs. Within the pit viper group, the rattle distinguishes the rattlesnake from other crotaline snakes. The mistaken belief that rattlesnakes always rattle before striking has persisted for centuries. In truth, many strikes occur without a warning rattle.
FIGURE 212­1. Pit viper.

Chapter 212: Snakebite, Richard C. Dart; Julian White 
. Terms of Use * Privacy Policy * Notice * Accessibility
PATHOPHYSIOLOGY
Crotaline venom is a complex enzyme mixture that causes local tissue injury, systemic vascular damage, hemolysis, fibrinolysis, and neuromuscular dysfunction, resulting in a mixture of local and systemic effects. Crotaline venom quickly alters blood vessel permeability; this leads to loss of plasma and blood into the surrounding tissue, which causes hypovolemia. Crotaline venom activates and consumes fibrinogen and platelets, causing a coagulopathy. In some species, specific venom fractions block neuromuscular transmission, which leads to cranial nerve weakness (e.g., ptosis), respiratory failure, and altered sensorium.
CLINICAL FEATURES
Up to 25% of crotaline snakebites are dry bites: venom effects do not develop. The manifestations of crotaline envenomation involve a complex interaction of the venom and the victim. The species and size of the snake, the age and size of the victim, the time elapsed since the bite, and characteristics of the bite or bites (location, depth, and number; the amount of venom injected) all affect the clinical evolution. The severity of envenomation following a crotaline bite is therefore variable. An initially minimal bite may evolve into a more serious bite and require large amounts of antivenom.
The cardinal manifestations of crotaline envenomation are the presence of one or more fang marks, localized pain, and progressive edema extending from the bite site. Other early symptoms and signs are nausea and vomiting, weakness, oral numbness or tingling of the tongue and mouth, dizziness, and muscle fasciculation. Systemic effects include tachypnea, tachycardia, hypotension, and altered level of consciousness. In general, local swelling at the bite site becomes apparent within  to  minutes, but in some cases, swelling may not start for several hours. In severe cases, edema can involve an entire limb within an hour. In less severe cases, edema may progress over  to  days. Edema near an airway or in a muscle compartment may threaten life or limb without causing systemic effects. Rapid onset of angioedema may occur.
Progressive ecchymosis may also develop because of leakage of blood into subcutaneous tissue. Ecchymoses may appear within minutes or hours, and hemorrhagic blebs may be seen within several hours. Hemoconcentration often develops as a result of fluid extravasation into subcutaneous tissue; it can be followed by a decrease in hemoglobin level over several days as intravascular volume is restored.
DIAGNOSIS
The diagnosis of snakebite is based on the presence of fang marks and a history consistent with exposure to a snake (e.g., walking through a field).
Snake envenomation involves the presence of a snakebite plus evidence of tissue injury. Clinically, the injury may be manifest in three ways: local injury (swelling, pain, ecchymosis), hematologic abnormality (thrombocytopenia, elevated prothrombin time, hypofibrinogenemia), or systemic effects (e.g., oral swelling or paresthesias, metallic or rubbery taste in the mouth, hypotension, tachycardia). Abnormalities in any one of these areas indicate that venom effect is developing. The absence of any of these manifestations for a period of  to  hours following the bite indicates a dry bite.
TREATMENT
FIRST AID
First aid measures should never substitute for definitive medical care or delay the administration of antivenom (Table 212­1). Take all patients bitten by a pit viper to a healthcare facility. Avoid dangerous first aid treatments such as suction and incision. Do not use kits that contain suction cups; the cups produce little suction and seal poorly on digits. The blade in the kit, or any method of incision, can injure digital nerves, arteries, and tendons. The Sawyer Extractor® (Sawyer Products, Inc., Safety Harbor, FL) suction pump is said to remove venom without incision, but safety and
 efficacy of the product are questioned. Electric shock treatment of the bite site is dangerous and ineffective and can cause electrical injuries. Ice water immersion worsens the venom injury.
TABLE 212­1
Recommended First Aid Measures for Snakebite
Retreat well beyond striking range. Many victims are bitten again while trying to capture the snake.
Remain calm. Movement will increase venom absorption.
Immobilize the extremity in a neutral position below the level of the heart.
Ensure prompt transport to a medical facility whether or not there are signs of envenomation.
Constriction bands (see text) can be applied if there is no nearby medical facility.
Do not use tourniquets because they obstruct arterial flow and cause ischemia. Constriction bands may be useful, especially when immediate medical care is not available. A constriction band is an elastic bandage or Penrose drain, thick rope, or piece of clothing wrapped circumferentially above the bite and applied with enough tension to restrict superficial venous and lymphatic flow while maintaining distal pulses and capillary filling. Apply the band snugly but loose enough to avoid arterial compromise. It should be easy to insert one or two fingers under
 the band. A constriction band can delay venom absorption without causing increased swelling. In distinction to a constriction band, a pressure immobilization bandage is a compression pad placed over the bite site combined with a snug elastic bandage wrap and extremity immobilization. This technique is recommended for coral snake and other elapid snake bites but is generally discouraged for crotaline bites because it may increase pain at the site.
PREHOSPITAL MANAGEMENT
In the prehospital phase, immobilize the limb, establish IV access in another limb, administer oxygen, and transport the victim to a medical facility. Do not remove tourniquets or constricting bands until antivenom is available, except where there is clear arterial vascular compromise threatening limb viability; in this latter situation, anticipate possible rapid development of systemic envenomation upon removal of first aid.
Institute advanced life support measures as indicated. If the patient is hypotensive, rapidly administer IV isotonic fluids. Immobilize the limb in a neutral position during transport to reduce further venom absorption. Consult with a physician or poison control center familiar with the management of snake envenomation.
ED MANAGEMENT
,5
Antivenom is the mainstay of therapy for venomous snakebites (Table 212­2). Antivenom is composed of heterologous antibodies derived from the serum of animals immunized with the appropriate snake venoms. The antibodies bind and neutralize the venom molecules.
TABLE 212­2
Clinical Features and Treatment of Reptile Envenomation
Reptile Clinical Findings Antivenom
Crotaline snake (pit viper) Fang marks Crotalidae Polyvalent Immune Fab
Local tissue injury Crotalidae Immune F(ab’)2 (Equine)
Fibrinolysis
Thrombocytopenia
Systemic effects
Coral snake Neurologic dysfunction Antivenom (Micrurus fulvius)
Elapid snake Coagulopathy for some species Each species has monovalent or polyvalent antivenoms
Systemic effects, primarily neurologic dysfunction
Cardiac arrhythmias and dysfunction
Local injury for some species
Crotalidae Polyvalent Immune Fab (Ovine) (FabAV) is used in the United States. Crotalidae Immune F(ab’)2 (Equine) (Fab AV) is now commercially
 available. The serum half­life of Fab AV is longer, and a prospective trial reported that the incidence of recurrent coagulopathy was reduced. The
 relative effectiveness and safety of each product are unknown. Each antivenom is produced by immunizing sheep or horses with crotaline snake venoms, which vary by the product. The immune serum is harvested from the host animals and then digested with papain (FabAV) or pepsin (Fab AV)
 to produce antibody fragments. In both cases, the more immunogenic Fc portion of the antibody is eliminated during purification.
All snakebite patients who develop progressive signs and symptoms should be treated promptly with antivenom. Progression is defined as worsening of local injury (e.g., pain, ecchymosis, swelling), abnormal laboratory results (e.g., worsening platelet count, prolonged coagulation times, decreased fibrinogen level), or systemic manifestations (e.g., unstable vital signs, abnormal mental status)
(Table 212­3).
TABLE 212­3
Laboratory Evaluation in Crotaline or Elapid Snakebite
CBC* INR or prothrombin time* PTT* Fibrinogen level* Fibrin degradation product levels
Serum electrolyte levels
Glucose level
BUN level
Platelet count
Creatine kinase level
ECG†
‡
Arterial blood gas analysis
*Should be performed as soon as possible and repeated within  h.
†Suggested for patients >50 y of age and patients with a history of heart disease.
‡
Should be performed if any signs or symptoms of respiratory compromise are evident.
Administer antivenom IV to establish “initial control” (Figure 212­2). Initial control is cessation of progression of three clinical evaluation parameters: local effects, systemic effects, and hematologic abnormalities. It is crucial to document initial control because the most common error in management is insufficient dosing early in treatment.
FIGURE 212­2. General strategy for administration of pit viper antivenoms in the United States. Both antivenoms use the same strategy of establishing initial control followed by additional antivenom as needed. However, the dosage varies; the package insert should be consulted for dosing recommendations. *Initial control is cessation of progression of all components of envenomation: local effects, systemic effects, and coagulopathy. FabAV = Crotalidae Polyvalent
Immune Fab (Ovine).
After reconstitution, dilute each dose of antivenom in crystalloid and infuse over  hour. After initial control has been established, two­vial
 maintenance doses are recommended (Figure 212­2) for FabAV. Fab AV will be introduced in 2019 ; dosing schedules are different, and the healthcare
 provider should be careful to use antivenom according to the product label and in consultation with a poison center. In children, the total volume,
 but not the number of vials, may be reduced. If IV access is unavailable, the IO route may be used.
Do not inject antivenom IM or directly into a digit, because venom­induced hypovolemia may retard absorption of antivenom. Hospital pharmacies in regions where venomous snakes are prevalent should maintain adequate stocks of antivenom. Unfortunately, many hospitals stock
 insufficient amounts of antivenom, even in endemic areas.
The package insert is useful as a guide for antivenom preparation. Give antivenom in a critical care facility such as an ED or intensive care unit, under direct physician supervision, and with resuscitative drugs (including epinephrine) and equipment immediately available. The incidence of acute
 reactions to modern antivenoms is low. If an acute allergic reaction occurs, stop the infusion immediately and administer antihistamines (both histamine­1 and histamine­2 receptor blockers). Epinephrine should be readily available and administered for anaphylaxis.
Continue to observe for progression of edema and systemic signs of envenomation during and after antivenom infusion. Measure limb circumference at several sites above and below the bite, and outline the advancing border of edema with a pen every  minutes. These measures serve as an index of the progression as well as a guide for antivenom administration. Repeat laboratory determinations every  hours or after each course of antivenom therapy, whichever is more frequent. Additional doses of antivenom may be warranted if the patient’s condition worsens. The use
 of crotaline antivenom for copperhead envenomation is controversial, but recent studies indicate effectiveness of FabAV. It should be administered in copperhead bites where progression occurs over time. The value of aggressive supportive care cannot be overemphasized. Administer isotonic fluid resuscitation followed by vasopressor agents for hypotension. Antivenom is the best treatment for hematologic abnormalities, but if active bleeding occurs, blood component replacement may be necessary after antivenom has been given.
Compartment syndrome is another complication of snakebite. Increased compartment pressure may occur when venom is injected or spreads into a compartment; this is often manifested by severe pain that is localized to a compartment and usually resistant to opiate analgesia. Table 212­4
 presents the suggested treatment of compartment syndrome. The use of fasciotomy is controversial, and there is no firm evidence supporting its use.
TABLE 212­4
Management of Compartment Syndrome Caused by Crotalinae Snake Envenomation*†
Determine intracompartmental pressure.
If pressure is not elevated, continue standard management.
If signs of compartment syndrome are present and compartment pressure is >30 mm Hg:
Elevate limb.
Administer mannitol, 1–2 grams/kg IV over  min.
Simultaneously administer additional antivenom over  min.
If elevated compartment pressure persists another  min, consider fasciotomy.
*Elevated compartment pressure is caused by the action of the venom on the tissues, and thus management of compartment syndrome due to snakebite is unique; therefore, the most effective treatment is to neutralize the venom, which may reduce the compartment pressure.
†The mannitol and antivenom deliver a high osmotic load, and fluids and electrolyte levels need careful monitoring. The administration of mannitol and antivenom must be completed promptly so that, if ever needed, fasciotomy may be performed as early as possible.
Clean the bite wound and determine the need for tetanus immunization. Obtain wound specimens for culture and administer antibiotics if signs of
 infection are present. Although antibiotic prophylaxis is recommended by some authors, the data available do not support its use. Steroids are not effective and could be harmful. Steroids should be reserved for the treatment of allergic reactions or serum sickness.
Serum sickness is uncommon after antivenom treatment. The symptoms are fever, rash, and arthralgias. Start prednisone,  milligram/kg PO once daily, and taper over  to  weeks.
DISPOSITION AND FOLLOW­UP
It cannot be overemphasized that one can easily be deceived by a bite that initially appears innocuous. Unremarkable physical examination and laboratory test results at presentation do not reliably exclude significant envenomation. Observe patients for at least  to  hours in the ED before determining disposition.
Discharge patients with dry bites who have been observed for  to  hours with instructions to return if pain, swelling, or bleeding develops. Admit patients with severe or life­threatening bites and patients receiving antivenom to an intensive care unit; the general ward is appropriate for patients with mild or moderate envenomations who have completed or do not require further antivenom therapy.
Patients are ready for discharge from the hospital when swelling begins to resolve, coagulopathy has been reversed, and the patient is ambulatory.
Physical therapy for the bitten part (particularly the hand) is recommended after swelling has lessened and coagulopathy has resolved. Patients should return if symptoms recur or if they develop bruising or other signs of recurrent coagulopathy. Outpatient follow­up is necessary to monitor for infection and serum sickness. The patient should be instructed about serum sickness symptoms and advised to report if such symptoms develop.
ELAPID SNAKEBITE
U.S. CORAL SNAKEBITES
U.S. coral snakes include the eastern coral snake (Micrurus fulvius), the Texas coral snake (Micrurus tener), and the Arizona (Sonoran) coral snake
(Micruroides euryxanthus). The eastern coral snake is found primarily in the southeastern United States. The Texas and Arizona coral snakes are found primarily in their eponymous states. Coral snakes account for  to  bites a year.
All coral snakes are brightly colored with black, red, and yellow rings. The red and yellow rings touch in coral snakes, but they are separated by black rings in nonvenomous snakes, which led to the well­known rhyme, “Red on yellow, kill a fellow; red on black, venom lack.” This rule is not always true outside of the United States.
Coral snake venom is primarily composed of neurotoxic components that do not cause marked local injury (Table 212­2). Admit potential victims of coral snakebite to the hospital for observation, because venom effects may develop hours after a bite and are not easily reversed. Administer three to five vials of antivenom, Antivenin® (M. fulvius), IV to patients who have definitely been bitten, because it may not be possible to prevent further effects
 or reverse effects once they develop. Additional doses of coral snake antivenom are reserved for cases in which symptoms or signs of coral snake envenomation appear. Because respiratory failure may result from clinical effects of the neurotoxin, baseline and serial measurement of pulmonary function parameters (e.g., inspiratory pressure and vital capacity), in addition to intensive care observation, may be useful. Prolonged ventilatory support may be required in severe cases. Observe the patient closely for signs of respiratory muscle weakness and hypoventilation. Bites by the
Sonoran coral snake are mild, and antivenom is not usually needed.
ELAPID BITES WORLDWIDE
Elapids are found throughout the world in warm climates. Elapids occur in Australia, New Guinea, Asia, Africa, and the Americas. All sea snakes are elapids (subfamily Hydrophiinae). Medically significant groups include some venomous snakes of Australia (tiger snakes [Notechis], brown snakes
[Pseudonaja], taipans [Oxyuranus], death adders [Acanthophis], “black” snakes [Pseudechis], pygmy copperheads [Austrelaps], rough­scaled snake
[Tropidechis carinatus], broad­headed snakes [Hoplocephalus]) and, in other areas, cobras (Naja; Asia and Africa), mambas (Dendroaspis; Africa),
 kraits (Bungarus; Asia), coral snakes (Micrurus; Americas), and a variety of less common genera and species.
Elapid bites produce systemic effects, particularly neurologic effects: tremor, salivation, dysarthria, diplopia, bulbar paralysis with ptosis, fixed and
 constricted pupils, dysphagia, dyspnea, and seizure. Some groups (e.g., cobras) also produce pain, local injury, and necrosis, which may be more
 clinically prominent than systemic effects. The immediate cause of death is usually paralysis of respiratory muscles. Australian elapids produce coagulopathy; some cause rhabdomyolysis, as do some kraits. Signs and symptoms may be delayed  or more hours. Some cobras in Africa and Asia
(“spitting cobras”) can spit venom several feet. If spit into the eye, this venom can cause venom spit ophthalmia, a very painful acute corneal injury rendering the victim temporarily blind, but systemic envenomation does not occur. In general, a spitting cobra bite causes moderate to severe local effects, including necrosis, with paralytic effects uncommon in most species.
PATHOPHYSIOLOGY
The Elapidae possess nonretractile small­ to medium­sized paired fangs that have grooved, often enclosed venom channels rather than hollow venom
 ducts. It is thought that the Elapidae exert voluntary control over the injection of venom, hence the frequent occurrence of a dry bite.
,15
The venom of the Australian elapids contains several important components. Neurotoxins (tiger snake, taipan, death adder, and others) act at the neuromuscular junction and cause descending symmetric flaccid paralysis. Signs usually develop within  to  hours after the bite and may include ptosis, partial ophthalmoplegia (diplopia), dysarthria, loss of facial expression, loss of airway control, and respiratory paralysis. The procoagulant toxins (seen in brown snake, tiger snake, taipan, and others) act as prothrombin converters, leading to a venom­induced consumptive coagulopathy with fibrinogen depletion and variable thrombocytopenia. Intracranial hemorrhage is a recognized complication.
,16
Brown snake envenomation can cause rapid collapse and death. Renal impairment or failure may also result from snakebite. The mechanisms are
,15 poorly understood and may include hypotension, myoglobinuria, coagulopathy, and direct renal toxicity. Myolysins (tiger snake, taipan, and mulga snake) are structurally related to the neurotoxins but instead produce rhabdomyolysis, which may result in muscle pain, weakness, myoglobinuria,
,15 secondary renal failure, and hyperkalemia. Rarely, a venom­induced thrombotic microangiopathy may complicate brown and tiger snake
16­18 envenomation. Local tissue destruction is uncommon with the bite of any Australian species, although mild to moderate ecchymosis and swelling
 may occur. This likely accounts for the popularity of pressure bandages and immobilization in Australia.
CLINICAL FEATURES
14­17
The severity of elapid envenomation cannot be estimated by the clinical appearance of the bite site or by initial symptoms. Even with severe envenomation, patients may initially feel well and manifest few clinical features. Early symptoms include nausea, vomiting, headache, abdominal pain,
 diplopia, dysphonia, progressive muscle weakness, discolored urine, and seizures. Young children may not provide a history of snakebite; if a child
 develops toxicity in a region populated with elapids, envenomation should be suspected. In Australia, the most common cause of snakebite fatality is a prehospital cardiac arrest, inadequately resuscitated, as a result of a brown snake (Pseudonaja spp.) bite.
DIAGNOSIS
The diagnosis requires correlation of history, clinical features, and laboratory investigations. Laboratory tests often determine if the patient requires
14­17 antivenom treatment. Key tests include prothrombin time (PT), INR, activated PTT, D­dimer, fibrinogen, fibrin degradation products, hemoglobin, platelet count, electrolytes, renal function test, and creatine kinase. These tests should be performed prior to removal of first aid,  hour after removal
,19 of first aid, and at  and  hours after bite (earlier if clinical abnormalities develop). Look for evidence of procoagulant coagulopathy (prolonged
PT and activated PTT, high INR, raised D­dimer/fibrin degradation products, low fibrinogen), anticoagulant coagulopathy (abnormal PT and activated
PTT with high INR, but normal fibrinogen and D­dimer/fibrin degradation products), platelet effects, rhabdomyolysis (grossly elevated creatine kinase, myoglobinuria), renal damage (abnormal renal function tests, reduced urine output), hyponatremia, and a syndrome similar to hemolytic­uremic
 syndrome (thrombocytopenia, anemia, intravascular hemolysis). A Snake Venom Detection Kit® (SVDK; bioCSL, Parkville, Victoria, Australia) is available to identify snake venom at the bite site or in the urine, correlated to venom immunotype (which corresponds to “monovalent” antivenom
 type), for use exclusively with Australian and New Guinea snakes. Positive SVDK identification of venom at the bite site or in the urine assists in selecting a “monovalent” antivenom, but does not represent an indication for antivenom therapy, because of the significant rate of “dry bites” by some

Australian elapids. World Health Organization guidelines on treating snakebite in Asia and Africa are a useful online resource on diagnosis and
,21 treatment for these regions.
TREATMENT
FIRST AID
In Australia and New Guinea, pressure bandaging and immobilization of the involved limb are used. The principle is to contain the venom locally and prevent venom transport by lymphatic vessels. Wrap an elastic bandage firmly over the bite site and then extend it to cover the entire limb (bandage
 pressure similar to that used for sprains: firm, but not tourniquet tight). Limb splinting to prevent movement is an essential part of the method.
Examination of lymphatic flow rates with simulated venom has demonstrated that, even if the upper or lower limb is appropriately bandaged and
 immobilized, walking will hasten systemic envenoming. Use of tourniquets is contraindicated. In the rare circumstance that a bite is inflicted on the trunk, apply firm pressure to the affected area without restricting breathing.
Outside of Australia and New Guinea, the choice of first aid is more nuanced. If the bite is from an elapid that causes predominantly local tissue
 damage (e.g., a spitting cobra) or an unidentified snake, then pressure bandaging and immobilization may potentially increase local tissue injury.
The risk from potentially increased local tissue damage caused by pressure bandaging and immobilization must be balanced against the risk of progressive neurotoxicity, if neurotoxic snakes are present locally. Consider omitting pressure bandaging and immobilization but splinting the bitten part if likely snake species do not include neurotoxic snakes.
ED MANAGEMENT
Any history suggestive of snakebite should prompt appropriate first aid and transport to a medical facility with appropriate medical expertise, laboratory facilities, and antivenom supplies. Maintain pressure bandaging and immobilization (or immobilization only) until envenomation is
 excluded or until the patient can receive antivenom. If the patient deteriorates immediately after removal of first aid measures, reapply and give antivenom. Once antivenom is infusing, remove the pressure bandage so that antivenom can reach the envenomed area. There is no evidence that
 venom is inactivated by being trapped at the bite site.
Antivenom should be given only in cases in which there is clear clinical or laboratory evidence of systemic envenomation. Clinical indications for immediate antivenom therapy include evidence of neurotoxic effects (ptosis, cranial nerve involvement, progressive muscle weakness, or diaphragmatic involvement), coagulopathy, rhabdomyolysis, renal failure, cardiac collapse, significant local tissue injury, or vomiting unresponsive
,15 to antiemetics. If evidence of systemic envenomation is not present, remove the first aid measures and observe the patient for at least  hours, or
,19 longer for some species. Repeat laboratory tests  hour after removing the first aid measures and at intervals thereafter dictated by the patient’s condition.
For Australian elapid snakebites, there is only one manufacturer (Seqirus/CSL Ltd, Melbourne, Australia) that produces five “monovalent” antivenoms corresponding to the five venom immunotypes, a polyvalent antivenom that covers all of the five venom immunotypes, plus a sea snake antivenom that
,15 is effective for all sea snake species globally. The initial dose of antivenom is controversial, but simply following the product instructions is prudent. Similarly, the initial dose of antivenom for non­Australian snakes should be based on manufacturer recommendations. For patients presenting with severe envenomation, higher initial doses may be warranted. Always administer antivenom IV. If IV access is unavailable, consider
IO administration. IM administration is strongly discouraged due to slow absorption and potential complications of anticoagulation. Dilute antivenom about 1:10 in normal saline (lower dilution in small children or cardiac­compromised adults), then commence the infusion slowly, looking for evidence of adverse reaction (rash, wheeze, hypotension, angioedema); gradually increase the rate to give the entire dose over  to  minutes
,15
(longer if high­volume antivenom). Give the same dose to children as adults. Skin testing before antivenom administration is not
,15 recommended, and equipment for treatment of anaphylaxis should be at the bedside. Hypersensitivity is an uncommon complication of
23­25 antivenom therapy in Australia. Elsewhere, antivenoms may have high rates of adverse reactions. A 5­day course of steroids (e.g., prednisone, 
 milligram/kg PO once daily) may be prescribed to reduce the incidence of serum sickness, but clear evidence of efficacy is lacking.
Antivenom cannot reverse some venom effects, such as established presynaptic neurotoxic paralysis, renal failure, and rhabdomyolysis. It is therefore important to give antivenom as soon as indicated. If this is not possible, support respiration and renal function as clinically required. Advanced flaccid paralysis usually requires protection of airway and respiratory support for periods of days to months.
When indicated, give monovalent or polyvalent antivenom immediately in sufficient doses to improve coagulation values. Pregnancy is not a contraindication to antivenom therapy.


