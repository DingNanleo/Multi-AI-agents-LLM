## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 233: Acquired Bleeding Disorders
Robert W. Shaffer; Sally Santen
INTRODUCTION
Bleeding is regulated by a complex process involving platelets and the coagulation system (see Chapter 232, “Hemostasis”). Platelet defects typically manifest with petechiae and mucosal bleeding, whereas coagulation defects usually present as spontaneous or excessive hemorrhage. Management of significant acquired bleeding disorders should be discussed with a hematologist because there are often subtleties in diagnosis and treatment.
ACQUIRED PLATELET DEFECTS
Circulating platelets provide the initial defense against bleeding. Acquired platelet disorders may be quantitative (decreased number of circulating platelets) or qualitative (poorly functioning platelets). Both significant thrombocytopenia and qualitative platelet dysfunction are commonly manifested by the presence of nonpalpable petechiae, often most pronounced in the lower extremities and in areas where blood flow is restricted.
Other typical findings may include purpura, mucosal bleeding (gingival, epistaxis), menorrhagia, hemoptysis, hematuria, and hematochezia, whereas deep tissue bleeding and hemarthrosis are less common.
Securing circulatory stability is the primary treatment priority in the bleeding patient. Once done, perform the history, physical examination, and directed laboratory testing to define the clinical syndrome. Recent illness, symptoms, and medications are potentially relevant in the patient who appears to have a platelet disorder. Physical examination should assess for additional bleeding sites and the type of bleeding. Assess for lymphadenopathy, splenomegaly, rash, pallor, or jaundice that suggests diagnoses such as leukemia, lymphoma, systemic lupus erythematosus, infectious mononucleosis, or hemolytic anemia.
THROMBOCYTOPENIA
Quantitative defects that result in thrombocytopenia are caused by decreased production, increased destruction, splenic sequestration, platelet loss,
 or a combination (Table 233­1). The etiologies of thrombocytopenia are diverse, and the pathologic mechanism is not always initially clear. Viral infections may impair thrombopoiesis due to direct infection of the megakaryocyte, toxic effects of viral proteins or cytokines, hemophagocytosis, or
 production of antibodies that bind to platelets and enhance immune destruction. A drug history is important, because many medications have been
3­5 implicated in causing thrombocytopenia or impairing platelet function (Table 233­2).
TABLE 233­1
Pathophysiology of Acquired Thrombocytopenia
Mechanism Associated Clinical Conditions
Decreased platelet production Marrow infiltration (tumor or infection)
Viral infections (rubella, HIV, hepatitis C, others)
Drugs (Table 233­2)
Radiation
Vitamin B and/or folate deficiency

Increased platelet destruction Immune thrombocytopenia
Thrombotic thrombocytopenic purpura

Hemolytic­uremic syndrome
Chapter 233: Acquired Bleeding Disorders, Robert W. Shaffer; Sally Santen 
Disseminated intravascular coagulation
. Terms of Use * Privacy Policy * Notice * Accessibility
Viral infections (HIV, mumps, varicella, Epstein­Barr virus)
Drugs (Table 233­2)
Platelet loss Excessive hemorrhage
Hemodialysis, extracorporeal circulation
Splenic sequestration Sickle cell disease, cirrhosis
Abbreviation: HIV = human immunodeficiency virus.
TABLE 233­2
Drugs That Produce Thrombocytopenia or Impair Platelet Function
Produce Thrombocytopenia* Impair Function
Heparin Aspirin
Gold salts NSAIDs
Sulfa­containing antibiotics Clopidogrel, prasugrel, and ticagrelor
Quinine and quinidine Penicillins and cephalosporins
Ethanol (chronic use) Calcium channel blockers
Vancomycin β­Adrenergic blockers: propranolol
Ibuprofen Nitroglycerin
Rifampin Antihistamines
Abciximab and eptifibatide Phenothiazines
Thiazides and furosemide Cyclic antidepressants
Penicillins/cephalosporins
Procainamide
Cimetidine and ranitidine
Valproate and carbamazepine
*Many other drugs may also cause thrombocytopenia. The above list shows drugs with the most evidence.
A CBC will establish the presence and degree of thrombocytopenia and also indicate whether other hematologic cell lines are affected. A peripheral smear can assess platelet morphology and evaluate other cell lines. Rarely, in vitro platelet agglutination occurs, which leads to spuriously low platelet counts reported by automated cell counters (pseudothrombocytopenia) when collected in ethylenediaminetetraacetic acid–coated blood tubes; this can be detected by the presence of platelet clumping on a peripheral smear. In this case, a correct platelet count may be obtained by using citrated or heparin­anticoagulated blood tubes.
Testing for human immunodeficiency virus, hepatitis C virus, and Helicobacter pylori is recommended in cases of isolated thrombocytopenia, as low
 platelets may be the only readily apparent manifestation in early infections. If the etiology of low platelets remains unclear, further laboratory testing to evaluate for disorders such as hemolysis and disseminated intravascular coagulation (DIC) may be needed. Although usually not necessary in instances of isolated thrombocytopenia, bone marrow biopsy may be obtained when malignancy or other bone marrow pathologies are of concern.

When circulating platelet levels decrease to below ,000 to ,000/mm (10 to  ×  /L), the risk of spontaneous bleeding becomes concerning, particularly for intracranial hemorrhage. Additional risk factors for bleeding include age, comorbid illness (e.g., renal disease, liver disease, connective tissue disease, peptic ulcer disease, hypertension), fall risk, and lifestyle activity. Platelet transfusion in the nonbleeding patient is usually considered
   when counts fall below ,000/mm (10 ×  /L). The cause of the platelet deficiency may also influence the risk of bleeding. At a given platelet level, patients with immune thrombocytopenia (ITP) typically bleed less than patients with aplastic anemia, as the younger platelets present in ITP are more
 effective in hemostasis.
Immune Causes of Thrombocytopenia
,8
ITP is an acquired immune­mediated disorder in which circulating platelets typically fall to very low levels. ITP results from antiplatelet antibodies that attack platelet surface glycoproteins such as glycoprotein IIb/IIIa, leading to peripheral platelet destruction. There is evidence that the same
 antibodies lead to impaired platelet production by megakaryocytes. Despite very low platelet counts, the circulating platelets are not functionally impaired.
ITP may be classified as primary (formerly known as idiopathic thrombocytopenic purpura) or secondary when associated with other medical
 conditions (autoimmune disorders, infections) or drug exposures. This distinction is of clinical importance, as management of the underlying disorder or discontinuation of the drug in cases of secondary ITP may lead to normalization of the platelet count.
Primary ITP may occur at any age, with equal prevalence between genders, with the exception of those age  to  years, in which women predominate. Primary ITP is classified by duration of illness: newly diagnosed (diagnosis to  months), persistent (3 months to  months), and chronic

(>12 months). The majority of adults with primary ITP progress to chronic illness.
The most common presenting sign of ITP is a petechial rash (Figure 233­1A). Mild epistaxis, gingival bleeding (Figure 233­1B), and menorrhagia in women of childbearing age may also be seen. Except for petechiae and bruising, the patient should have a normal physical examination.
FIGURE 233­1.  
Two patients with primary immune thrombocytopenic purpura. A. Petechiae with platelet count of 3000/mm (3 ×  /L). B. Gingival bleeding with
  platelet count of 5000/mm (5 ×  /L). [Image used with permission of J. Stephan Stapczynski, MD.]
The CBC should demonstrate normal cell lines except for the platelets. A mild anemia may be seen if bleeding has been persistent. The peripheral smear should show large, well­granulated platelets, although they will be few in number. Bone marrow biopsy is not indicated unless clinical features are atypical. If the evaluation supports the diagnosis of primary ITP, then additional testing in the ED is not required.

Treatment for ITP is initiated based on the risk of bleeding (Table 233­3). Major bleeding is uncommon when platelets are >50,000/mm (>50 ×  /L).

As most fatal bleeding complications occur when platelet counts fall below ,000/mm (30 ×  /L), experts and guidelines recommend this level as
,7,9­11 the threshold for initiating treatment of ITP in adults. Bleeding risk correlates with lower platelet counts and patient age greater than , a prior history of bleeding, chronic renal or liver illnesses, and use of medications that alter hemostasis. For all patients with primary ITP, minimize bleeding risk by avoiding use of antiplatelet medications when possible, maintaining good blood pressure control, optimizing control of comorbid conditions
(e.g., liver disease, renal disease), and addressing fall risks.
TABLE 233­3
Treatment of Immune Thrombocytopenia
Platelet transfusion <10,000–20,000/mm3 (<10–20 × 109/L) prophylactically to prevent bleeding
<50,000/mm3 (<50 × 109/L) if actively bleeding
<20,000–50,000/mm3 (<20–50 × 109/L) if patient requires diagnostic puncture
<50,000–100,000/mm3 (<50–100 × 109/L) if patient requires invasive procedure
Corticosteroids Prednisone,  milligram/kg PO per day for  days then tapered or
Dexamethasone,  milligrams/m2 IV per day for  d
IV immunoglobulin  gram/kg IV per day for  d
Splenectomy Considered for refractory cases

About two thirds of children with primary ITP will have spontaneous resolution within  months of diagnosis. An antecedent viral infection is commonly reported. Additionally, the measles­mumps­rubella vaccination has been associated with the development of acute ITP, although this is
 rare, occurring in less than  per ,000 doses given. The risk of severe bleeding complications appears to be rare in children, regardless of their
,8,13 absolute platelet count. Children without signs of active bleeding and good psychosocial support typically do not require hospitalization or medical treatment. Good anticipatory guidance should be provided to the family, and the child should abstain from contact sports or activities that might place them at risk for head injury.
First­line treatment for primary ITP generally includes corticosteroids, typically prednisone for  weeks (shorter courses may be considered for
,9­11,13  children), or alternatively high­dose dexamethasone IV pulse therapy. Initial response may not be seen for  to  days, and peak effect can be expected between  and  days. IV immunoglobulin may also be considered, either alone or in combination with corticosteroids. Initial response to IV immunoglobulin is more rapid than corticosteroids, occurring between  and  days, with peak effect seen between  and  days. Side effects of IV immunoglobulin include aseptic meningitis, transient neutropenia, acute kidney injury, and transfusion reactions/hypotension.
Second­line treatment modalities include splenectomy and use of newer agents, such as the monoclonal antibody rituximab, which blunts the autoimmune destruction of platelets, and thrombopoietin receptor agonists, which stimulate platelet production (i.e., romiplostim, eltrombopag).
In the event of life­threatening hemorrhage where hemostasis must be achieved rapidly, IV corticosteroids (such as dexamethasone) and IV
 immunoglobulin should be administered concomitantly. Platelet transfusions should be initiated, and doses two to three times the typical dose
 might be required due to persistent autoimmune destruction. Platelet transfusions may need to be repeated frequently until bleeding subsides or targeted treatment modalities take effect. Emergent splenectomy may be considered if all other treatment options are exhausted.
Drug­Induced Immune Thrombocytopenia
Over 200 drugs have been implicated in causing immune­mediated suppression of platelet production, increased platelet destruction, or platelet
3­5 aggregation (Table 233­2). The clinical presentation is similar to ITP, and the thrombocytopenia may be severe. Drug­induced thrombocytopenia typically occurs  to  days following initiation of a drug but may occur sooner if there has been recent prior exposure. A careful history should include not only prescribed medications but also herbal remedies, foods, and beverages (e.g., quinine in tonic water, alcohol). Chronic alcohol use is a common cause of thrombocytopenia. Platelet counts typically normalize with cessation of the causative agent. Heparin­induced thrombocytopenia causes a significant drop in platelets, but patients are paradoxically hypercoagulable due to platelet activation (see Chapter 239, “Thrombotics and
Antithrombotics”).
Nonimmune Causes of Thrombocytopenia
Thrombocytopenia may occur from non–immune­mediated causes (Table 233­1). Drugs may cause platelet aggregation as well as decreased
 production. In thrombotic thrombocytopenic purpura and hemolytic­uremic syndrome, thrombotic microangiopathy occurs when vessel injury results in deposition of platelet­fibrin thrombi (see Chapter 144, “Hematologic Emergencies in Infants and Children,” and Chapter 237, “Acquired
Hemolytic Anemia”). DIC is also a well­described cause of platelet destruction. In patients with marked hemorrhage, large­volume fluid resuscitation may lead to a dilutional thrombocytopenia. Additionally, bacterial, rickettsial, and viral infections can cause direct toxic destruction of platelets.
Thrombocytopenia specific to pregnancy may be a result of the hemolysis–elevated liver enzymes–low platelets (HELLP) syndrome, preeclampsia, gestational thrombocytopenia (see Chapter 100, “Maternal Emergencies After  Weeks of Pregnancy and in the Peripartum Period”), or ITP. Finally, an enlarged spleen can sequester a significant portion of the platelet pool.

Thrombocytopenia is present in up to 70% of patients with chronic liver disease. The etiology appears multifactorial. Patients often have underlying medical conditions related to their liver disease such as alcohol use, viral hepatitis, or nutritional deficiencies that impair platelet production.
Thrombopoietin, which is produced by hepatocytes, may be decreased. Portal hypertension may lead to splenic sequestration. Endotoxemia from infection may promote platelet aggregation. Some patients also demonstrate platelet autoantibodies. The degree of quantitative thrombocytopenia may be mitigated by an increased level of circulating von Willebrand factor that is common in patients with chronic liver disease, which promotes platelet adhesion. For this reason, routine platelet transfusion is not recommended in the absence of clinically significant bleeding. However, a platelet
   count of >50,000/mm (>50 ×  /L) should be achieved prior to invasive procedures (e.g., lumbar puncture, surgery, liver biopsy).
FUNCTIONAL PLATELET DISORDERS

Several disease processes can cause acquired qualitative or functional abnormalities of platelets (Table 233­4). In the myeloproliferative diseases, platelets are often dysfunctional, even if the platelet count is normal or elevated. Patients can have prolonged bleeding times and clinically significant
  bleeding. To control acute bleeding, transfusion should be considered to raise the level of normal platelets to ,000/mm (50 ×  /L). In macroglobulinemia and related disorders, the elevated level of viscous proteins interferes with platelet function. Patients with clinically significant bleeding may require plasmapheresis to reduce the protein level and correct hemostatic function.
TABLE 233­4
Clinical Conditions Associated With Qualitative Platelet Abnormalities
Uremia
Liver disease
Disseminated intravascular coagulation
Antiplatelet antibodies (immune thrombocytopenia, systemic lupus erythematosus)
Cardiopulmonary bypass
Myeloproliferative disorders (thrombocytosis, polycythemia vera, chronic myeloid leukemia, acute lymphocytic or myelogenous leukemia)
Dysproteinemias (multiple myeloma, Waldenström’s macroglobulinemia) von Willebrand’s disease (congenital or acquired)
Many drugs can influence platelet function (Table 233­2 and Table 233­5). Of these, the most commonly used are aspirin, which produces an irreversible impairment in platelet aggregation, and the NSAIDs, clopidogrel and prasugrel, which produce impairment in platelet adhesion and aggregation (see Chapter 239, “Thrombotics and Antithrombotics”). Desmopressin can be used to reduce perioperative bleeding if urgent surgery is
 necessary in patients on antiplatelet drugs.
TABLE 233­5
Duration of Antiplatelet Drug Activity
Time to Full Time to Full Recovery of Platelet Drug Elimination
Drug
Effect Function Half­Life
Aspirin 325 milligrams PO single dose or 100 milligrams PO daily  h  d  h
Ibuprofen 400 milligrams PO single dose  h  h  h
Naproxen 220 milligrams PO single dose  h  d 12–17 h
Clopidogrel 600 milligrams PO loading dose and  milligrams PO 2–4 h  d  h daily maintenance

Thrombocytosis, a platelet count exceeding 500,000/mm (500 ×  /L), can be seen in inflammatory reactions, malignancy, polycythemia, and postsplenectomy. Platelet function can be normal or abnormal depending on the underlying condition. Therefore, thrombocytosis can be associated with bleeding (mucosal) or thromboembolic (deep venous thrombosis, portal or mesenteric thrombosis, splenic vein thrombosis) manifestations.

However, these events are unusual, even with platelet counts in excess of ,000,000/mm (1000 ×  /L).
ACQUIRED COAGULATION DISORDERS
Acquired coagulation disorders can result from underlying medical disease and autoimmune factor inhibitors.
LIVER DISEASE
Acute and chronic liver disease is commonly associated with laboratory tests demonstrating impaired coagulation. Hepatocytes synthesize all of the coagulation factors and related regulatory proteins, with the exception of factor VIII and von Willebrand factor. Diseases affecting the hepatic parenchyma may result in a decreased synthesis of these factors, including the vitamin K–dependent carboxylation of factors II (prothrombin), VII, IX, and X. Because vitamin K is a fat­soluble vitamin, malabsorption can occur with processes that interfere with the absorption of fat­soluble vitamins, including impaired bile acid metabolism (i.e., primary biliary cirrhosis), intrahepatic or extrahepatic cholestasis, and treatment with bile acid binders.
Thus, prolonged prothrombin time (PT) is common in patients with decompensated hepatic function.
Despite marked prolongations of PT and activated partial thromboplastin time (aPTT) seen in advanced liver disease and cirrhosis, these tests poorly
,18­20 predict onset and severity of bleeding, including bleeding from esophageal varices or invasive procedures or surgery. Although there may be marked reduction in procoagulant proteins in liver disease, there is typically a parallel decrease in the endogenous anticoagulant proteins such as protein C and antithrombin. Therefore, primary hemostasis may be relatively maintained. In fact, patients with liver disease may be susceptible to thrombosis; patients with liver disease and cirrhosis are twice as likely to develop unprovoked deep venous thrombosis and have a relatively high
 incidence of portal venous thrombosis.
In the actively bleeding patient with liver disease, attention to volume and circulatory status is paramount. Transfusion of packed red blood cells should be used to maintain an adequate hemoglobin and hemodynamic stability. Fresh frozen plasma transfusions or platelets should be transfused if
 significant hemorrhage (e.g., from esophageal varices) is associated with a coagulopathy or thrombocytopenia with a platelet count below ,000/mm

(60 ×  /L). Plasma transfusions should be used cautiously because they may incite thrombosis and expand intravascular volume, exacerbating portal hypertension and increasing the severity of variceal bleeding. There is no evidence that coagulation factor VIIa (recombinant) or prothrombin
 complex concentrate (human) provides benefit. The benefit of vitamin K in these patients has also been called into question, and its routine use is
,23 not substantiated. Treatment may be guided by whole­blood viscoelastic hemostasis assays.
Primary prevention of bleeding in patients with liver disease should focus on medical optimization of their risk factors, rather than treatment of
,18 abnormal tests of coagulation or thrombocytopenia. These include management and prevention of portal hypertension, treatment of esophageal varices, management of primary causes for liver disease (i.e., alcohol use, hepatitis C), optimization of renal function, and management and prevention of sepsis or infection.
RENAL DISEASE
Patients with renal disease frequently manifest disorders of hemostasis. Early renal impairment has been associated with a tendency for thrombosis
 relating to increased production of procoagulant factors as well as decreased formation of tissue plasminogen activator. In advanced renal disease, bleeding complications are of particular concern due to qualitative platelet dysfunction from decreased ability to adhere to damaged endothelium and aggregate. Patients with chronic kidney disease are at increased risk for minor bleeding (mucosal and cutaneous) and major bleeding (intracerebral and GI hemorrhage). Routine tests of hemostasis—PT, aPTT, and platelet counts—are often normal, although bleeding time will usually be prolonged.
Abnormalities in platelet function can be due to direct effects of uremic toxins and impaired drug elimination. Anemia itself has been associated with platelet dysfunction. Thrombocytopenia can occur from dialysis, and the heparin used may also potentiate bleeding.
Desmopressin is the most common agent used to correct bleeding in patients with uremic platelet dysfunction, producing an increase in serum von

Willebrand factor and enhancing the platelet’s ability to aggregate. The dose is .3 milligram/kg SC or IV, with a rapid onset and duration of action lasting at least  hours. Side effects are generally mild and include headache, flushing, minor hypotension, tachycardia, nausea, abdominal cramps, and local site reaction. Other strategies that improve platelet function include the use of cryoprecipitate, conjugated estrogens (0.6 milligram/kg IV
 daily), erythropoietin to improve anemia, and hemodialysis to remove toxins. Platelet transfusions alone are generally ineffective because the infused platelets quickly acquire the platelet defect. Life­threatening bleeding in renal failure patients is treated using the combination of cryoprecipitate, platelet transfusions, packed red blood cell transfusions, desmopressin, and conjugated estrogens.
DISSEMINATED INTRAVASCULAR COAGULATION
DIC is an acquired syndrome characterized by inappropriate and widespread activation of the coagulation system resulting in intravascular thrombin
 generation, small vessel thrombosis, and consumption of clotting factors and platelets. Concomitant activation of the fibrinolytic system also occurs, resulting in the breakdown of fibrin clots and subsequent bleeding. DIC is associated with a variety of precipitating disorders (Table 233­6).
TABLE 233­6
Common Conditions Associated With Disseminated Intravascular Coagulation (DIC)
Clinical Setting Comments
Infection Probably the most common cause of DIC; 10%–20% of patients with gram­negative sepsis have DIC; endotoxins stimulate
Bacterial monocytes and endothelial cells to express tissue factor; Rocky Mountain spotted fever causes direct endothelial damage; DIC more
Viral likely to develop in asplenic patients or patients with cirrhosis; septic patients are more likely to have thrombosis than bleeding.
Fungal
Carcinoma Malignant cells may cause endothelial damage and allow the expression of tissue factor as well as other procoagulant materials;
Adenocarcinoma most adenocarcinomas tend to have thrombosis (Trousseau’s syndrome), whereas prostate cancer tends to have more bleeding;
Lymphoma DIC is often chronic and compensated.
Acute leukemia DIC most common with promyelocytic leukemia; blast cells release procoagulant enzymes; there is excessive release at time of cell lysis (chemotherapy); more likely to have bleeding than thrombosis.
Trauma DIC especially with brain injury, crush injury, burns, hypothermia, hyperthermia, rhabdomyolysis, fat embolism, hypoxia. Massive bleeding can occur.
Organ injury May have chronic compensated DIC; acute DIC may occur in the setting of acute hepatic failure; tissue factor is released from the
Liver disease injured hepatocytes. Pancreatitis can activate the coagulation cascade.
Pancreatitis
Pregnancy Placental abruption, amniotic fluid embolus, septic abortion, intrauterine fetal death (can be chronic DIC); can have DIC in hemolysis–elevated liver enzymes–low platelets (HELLP) syndrome.
Vascular disease Large aortic aneurysms (chronic DIC can become acute at time of surgery), giant hemangiomas, vasculitis, multiple telangiectasias.
Envenomation DIC can develop with bites of rattlesnakes and other vipers; the venom damages the endothelial cells; bleeding is not as serious as expected from laboratory values.
Acute lung injury Microthrombi are deposited in the small pulmonary vessels; the pulmonary capillary endothelium is damaged; 20% of patients with
(ALI) or adult ALI develop DIC, and 20% of patients with DIC develop ALI.
respiratory distress syndrome
Transfusion DIC with severe bleeding, shock, and acute renal failure.
reactions, such as acute hemolytic reaction
Pathogenesis
The common pathway of illnesses that precipitate DIC is an inappropriate loss of localization or compensated control with the intravascular activation of coagulation (Figure 233­2). Immune, inflammatory, and coagulant pathways are involved. Damaged endothelial cell walls trigger activation of the intrinsic clotting cascade, leading to thrombin generation and subsequent intravascular fibrin clot deposition. Increased thrombin generation leads to consumption of anticoagulant regulatory proteins (i.e., protein C, protein S, and antithrombin), further potentiating thrombosis and ischemic tissue damage. Production of thrombin and fibrin indirectly activates tissue plasminogen activator and the counterregulatory fibrinolytic system. When hyperfibrinolysis occurs, the hemostatic clots dissolve and bleeding ensues.
FIGURE 233­2. Pathophysiology of disseminated intravascular coagulation. Refer to “Pathogenesis” section under “Disseminated Intravascular Coagulation” for details. FDPs = fibrin/fibrinogen degradation products.
Clinical Features

Clinical features of DIC vary with the underlying precipitating illness. Hypercoagulation may predominate in certain conditions such as sepsis, where signs of ischemic end­organ failure are common, and physical findings in these patients may include cutaneous gangrene or thrombotic purpura. In other instances, such as DIC associated with leukemia, hyperfibrinolysis may predominate and clinical features may include petechiae, ecchymoses, oozing from catheter or venipuncture sites, or hematuria. Certain DIC­related disorders such as trauma and obstetric complications tend to have both strong hypercoagulation and hyperfibrinolysis elements and lead to major bleeding complications (e.g., wounds, intracranial, GI). Yet other conditions may be associated with mild and compensated DIC in which signs of thrombosis and bleeding are subclinical.
Laboratory Findings
The typical laboratory results in acute DIC (Table 233­7) include thrombocytopenia, prolonged PT, low fibrinogen level, and elevation of fibrin­related markers (i.e., D­dimer, fibrin degradation products, soluble fibrin). The most commonly observed abnormality is thrombocytopenia; a progressive drop in the platelet count is sensitive, although not specific, for DIC. Depletion of coagulation factors is reflected by a prolonged PT. Fibrinogen is an acute­phase reactant and may be normal or elevated in early DIC. Scoring systems have been developed and validated to aid in the diagnosis (Table
,28
233­8).
TABLE 233­7
Laboratory Abnormalities Characteristic of Disseminated Intravascular Coagulation (DIC)28
Studies Result
Most Useful
Platelet count Usually low, or dropping
Prothrombin time (PT) Prolonged
Fibrinogen level Usually low (fibrinogen is an acute­phase reactant, so may actually start out elevated), fibrinogen level <100 milligrams/dL (<1 gram/L) correlates with severe DIC
Fibrin degradation products and Elevated
D­dimer* Helpful
Activated partial Usually prolonged thromboplastin time (aPTT)
Thrombin clotting time (TCT) Prolonged (not sensitive)
Fragmented red blood cells Should be present (not specific)
Specific factor assays Extrinsic pathway factors are most affected (VII, X, V, and II)
Factor II, V, VII,† X Low
Factor VIII (acute­phase Low, normal, high reactant)
Factor IX Low (decreases later than other factors)
*Levels may be chronically elevated in patients with liver or renal disease.
† Factor VII is usually low early because it has the shortest half­life.
TABLE 233­8
International Society on Thrombosis and Haemostasis Scoring System for Disseminated Intravascular Coagulation (DIC) When Associated
Condition Known to Cause DIC Is Present27
Test Points
Platelet count
>100,000/mm3 (>100 × 109/L) 
,000–100,000/mm3 (50–100 × 109/L) 
<50,000/mm3 (<50 × 109/L) 
Fibrin­related marker (D­dimer, fibrin degradation products)
Normal 
Mildly elevated (<5 times upper limit of normal) 
Markedly elevated (>5 times upper limit of normal) 
Prothrombin time prolongation
<3 s 
3–6 s 
>6 s 
Fibrinogen level
>100 milligrams/dL (>1 gram/L) 
<100 milligrams/dL (<1 gram/L) 
Note. A score of ≥5 is compatible with overt DIC. A score <5 is suggestive (not affirmative) for nonovert DIC.
Differential Diagnosis
Primary fibrinolysis is a rare syndrome where plasmin is generated and fibrinolysis occurs without the production of thrombin. Severe liver disease will also manifest with coagulation abnormalities and low platelets. These two entities can be differentiated from DIC based on clinical history and laboratory tests. The hematologic abnormalities in liver disease should be relatively stable in contrast to the worsening abnormalities associated with acute DIC. Additionally, the D­dimer assay will usually be normal or minimally elevated in both primary fibrinolysis and liver disease but is often significantly elevated in DIC.
Treatment
Paramount to the management of DIC is the control of the underlying disorder whenever possible. Treatment strategies in DIC include blood product
,27,29 support and strategies to modulate thrombin formation (Table 233­9). Generally speaking, blood products should only be administered when there is evidence of bleeding.
TABLE 233­9
Treatment of Disseminated Intravascular Coagulation (DIC)
Treat underlying precipitating disorder: volume resuscitation, antibiotics, external cooling
Platelet transfusions for thrombocytopenia <50,000/mm3 (<50 × 109/L) and active bleeding
Fresh frozen plasma for prolonged PT or aPTT (>2 times normal) or low fibrinogen (<100 milligrams/dL [1 gram/L]) and active bleeding
Fibrinogen concentrate for persistent low fibrinogen <100 milligrams/dL (<1 gram/L)
Vitamin K for prolonged PT
Consider venous thromboembolism prophylaxis with LMWH
Consider tranexamic acid for trauma­related DIC
Abbreviations: aPTT = activated partial thromboplastin time; LMWH = low­molecular­weight heparin; PT = prothrombin time.

Platelet transfusions are recommended in actively bleeding patients who have platelet counts below ,000/mm (50 ×  /L) and may be considered in
  those considered to be at high risk for bleeding (such as DIC resulting from chemotherapy) when platelet counts fall below ,000/mm to ,000/mm

(20 to  ×  /L). Fresh frozen plasma should be administered in bleeding patients when PT/aPTT exceeds .5 times normal or when fibrinogen levels fall below 100 milligrams/dL (1 gram/L). The initial recommended dose is  mL/kg, although there is some evidence that  mL/kg may be superior when volume overload is not of concern. Fibrinogen concentrate should be considered when hypofibrinogenemia persists despite use of plasma. Patients with a prolonged PT should receive parenteral vitamin K.
There is no proven benefit in DIC with other coagulation factor products, such as prothrombin complex concentrate (human) or coagulation factor VIIa
(recombinant). Due to high risk of thrombosis in DIC, low­molecular­weight heparin is recommended in patients with DIC when bleeding is absent and
   platelet counts exceed ,000/mm (30 ×  /L). Antifibrinolytic medications (e.g., tranexamic acid) should generally be avoided in patients with DIC.

One notable exception is in trauma­related DIC, where their use reduces mortality.
CIRCULATING INHIBITORS OF COAGULATION
Acquired inhibitors of blood coagulation, also known as circulating anticoagulants, are antibodies directed against one or more of the coagulation factors. Although inhibitors may develop spontaneously in previously healthy patients with normal hemostasis, most inhibitors develop in patients with hereditary bleeding disorders who receive transfusion of plasma products. Inhibitors have been described for most of the coagulation factors; the two most common inhibitors are factor VIII inhibitors and antiphospholipid antibodies. Factor VIII inhibitors are “specific” inhibitors, directed only against factor VIII, as opposed to antiphospholipid antibodies, including lupus anticoagulant and anticardiolipin antibodies, which are “nonspecific” inhibitors directed against several of the coagulation factors. Lupus anticoagulant and anticardiolipin antibodies often result in thrombosis (see
Chapter 234, “Clotting Disorders”).
Factor VIII Inhibitors
Factor VIII inhibitors most commonly develop in patients with hemophilia A (see Chapter 235, “Hemophilias and von Willebrand’s Disease”) but can
 also develop spontaneously in patients with previously normal hemostasis, a condition termed acquired hemophilia A. Although rare, it is important to recognize this clinical entity because the mortality rate is over 20%. Approximately 85% of acquired hemophilia A cases occur in the elderly. In about half of cases, inhibitors develop in association with malignancy, autoimmune disorders, pregnancy, drugs (interferon, clopidogrel), blood transfusions, or infections.
Patients who develop factor VIII inhibitors can present with massive spontaneous ecchymoses, hematomas, and hematuria. Laboratory studies classically show a normal PT, normal thrombin clotting time, and a greatly prolonged aPTT that does not correct with mixing. A factor VIII–specific assay will show very low or absent factor VIII activity.
A hematologist should direct the management of an acute, clinically significant bleeding episode. Treatment options include administration of factor
VIII, prothrombin complex concentrate (human), FEIBA (anti­inhibitor coagulant complex), coagulation factor VIIa (recombinant), desmopressin
31­33 acetate, and tranexamic acid. Additionally, the use of aspirin, NSAIDs, and intramuscular injections should be avoided and conservative therapies should be considered, including compression and immobilization of the bleeding site.


