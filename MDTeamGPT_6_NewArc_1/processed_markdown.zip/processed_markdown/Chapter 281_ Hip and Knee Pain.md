## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 281: Hip and Knee Pain
Kelly P. O’Keefe
INTRODUCTION AND EPIDEMIOLOGY
Every practicing emergency physician over their career will see hundreds of patients with complaints of hip or knee pain that are unrelated to major trauma or an acute fracture. Discomfort and limitations to normal use in these areas are typically related to the minor trauma that occurs on a repetitive basis from performing routine daily functions or exercising. Athletes of all varieties are especially prone to these maladies, where strenuous activity transmits forces that are equivalent to three to five times the body weight directly to these joints. Conversely, the problem of obesity similarly contributes to joint and supporting structural stress and pain.
However, be alert to the various catastrophic processes that can mimic more mundane etiologies, including ruptured abdominal aortic aneurysm, epidural abscess, and septic joint (among others). Pay close attention to historical points, specific risk factors, abnormal vital signs, and physical findings to avoid making a life­ or limb­threatening misdiagnosis.
PATHOPHYSIOLOGY AND ANATOMY
The hip is a ball­and­socket joint (enarthrosis), allowing motion in all directions. The hip is similar to the shoulder in this capacity but is much more stable and relatively resistant to dislocation. The bones of the joint (femoral head, pelvic acetabulum) are strongly reinforced with a fibrocartilaginous labrum, a joint capsule, overlying ligaments, and numerous muscles.
The knee is the largest synovial joint in the body and is relatively complicated in structure, comprising two distinct articulating groups: the tibiofemoral and patellofemoral joints. The patella floats above the main joint, attaching to the femur superiorly by the quadriceps tendon and inserting into the tibia inferiorly by the patellar ligament. The knee is stabilized internally by the anterior and posterior cruciate ligaments, and externally by the medial and lateral collateral ligaments. In addition, distal to the main joint, the fibular head attaches by ligaments to the proximal lateral tibia. The medial and lateral menisci are interposed between, and protect, the femoral and tibial condyles. Numerous muscles, tendons, bursa, and additional ligaments add to the complexity of the joint and serve as potential sources for pain and dysfunction (Figures 281­1 and 281­2).
FIGURE 281­1. Anterior view of the knee. [Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ: Emergency Orthopedics: The Extremities, 5th ed. © 2007, McGraw­Hill, Inc., New York.]

Chapter 281: Hip and Knee Pain, Kelly P. O’Keefe 
. Terms of Use * Privacy Policy * Notice * Accessibility
FIGURE 281­2. Medial view of the knee. [Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ: Emergency Orthopedics: The Extremities, 5th ed. © 2007, McGraw­Hill, Inc., New York.]
NERVES OF THE UPPER LEG AND REFERRED PAIN
The femoral and sciatic nerves are the major nerves within the thigh (Figure 281­3). The femoral nerve is the largest branch of the lumbar plexus, and the sciatic is the longest nerve in the body, traveling posteriorly and supplying sensation to the hip joint through its articular branches. The femoral and obturator nerves also innervate the hip. The femoral nerve divides into anterior and posterior branches, with the posterior becoming the saphenous nerve and providing sensation to the lower leg. The anterior nerve supplies sensation to the anterior medial thigh by the medial and intermediate cutaneous nerves. The two major branches of the sciatic, the peroneal and tibial nerves, course through the posterior fossa of the knee, along with the popliteal artery and vein.
FIGURE 281­3. Nerves that innervate the thigh.
Pain in the area of the knee is not commonly referred to other sites and is usually due to local pathology. However, referred pain from hip pathology is commonly felt in the buttocks, thigh, or groin; may extend to the knee; and may even travel to the foot. Pain felt in the hip and surrounding locations may be referred from pressure on the proximal nerve roots as they exit the lumbar and sacral spine. In the patient with appropriate risk factors, consider expansion or rupture of an abdominal aortic aneurysm as the cause of hip pain that is not otherwise explained by the history or physical examination, especially when there are no preexisting joint issues. Bedside US may exclude this life­threatening diagnosis. Other extra­articular sources of hip pain include intra­abdominal or pelvic tumors; diverticular, epidural, or psoas abscess; and the generally less worrisome diagnoses of herpes zoster or herniated lumbar disc.
DIAGNOSIS OF KNEE AND HIP DISEASES AND SYNDROMES
The majority of knee and hip problems can be diagnosed or excluded with a focused history and physical examination (Table 281­1).
TABLE 281­1
Suggested Clues for the Differential Diagnosis of Hip and Knee Pain
Determine the location of the pain to narrow down the potential diagnosis.
Determine the activities that bring on the pain.
Complaints that the joint “gives out” or “buckles” generally are due to pain and reflex muscle inhibition rather than an acute neurologic emergency.
This complaint may also represent patellar subluxation or ligamentous injury and joint instability.
Poor conditioning or quadriceps weakness generally causes anterior knee pain of the patellofemoral syndrome; therapy should address this weakness.
Locking of the knee suggests a meniscal injury, which may be chronic.
A popping sensation or sound at the onset of pain suggests a ligamentous injury.
A recurrent knee effusion after activity suggests a meniscal injury.
Pain at the joint line of the knee (palpable indentation between distal femur and proximal tibia) suggests a meniscal injury.
IMAGING
A suspected diagnosis obtained via history and physical examination is confirmed or ruled out by imaging. For most soft tissue injuries or overuse syndromes, radiographs are not particularly useful unless a history of significant trauma or cancer exists. More sophisticated imaging is typically not needed for evaluation in the ED, but may be indicated at follow­up or for selected ED patients on an individual basis. US can identify intra­articular or
1­5 bursal effusions and soft tissue swelling and can localize muscle or tendon injuries. Normal comparison US views from the unaffected leg can be helpful. US is very useful for the evaluation of popliteal cysts and arterial structures and will exclude deep venous thrombosis as a cause of pain and swelling.
Plain films are used in the evaluation of bony abnormalities such as severe arthritic changes and spurring, calcification derangements, and other inflammatory processes late in their courses. CT scan provides superior detail of osseous structures, will identify intra­articular loose bodies, and visualizes the early changes of osteonecrosis. Abnormalities of the labrum and joint capsule may also be seen. MRI precisely defines the anatomy of both the hip and knee and provides great detail for soft tissue and bony abnormalities. Although infrequently ordered from the ED, bone scans may be useful for the assessment of a variety of infectious and inflammatory processes, including avascular necrosis. Ultimately, arthroscopy of the knee and hip allows direct visualization of intra­articular lesions and simultaneous treatment.
SPECIFIC SYNDROMES AND DISEASES BY LOCATION
See Table 281­2 for a summary of the most important conditions.
TABLE 281­2
Selected Syndromes by Location
Diagnosis
Diagnosis Pain Location
Category
Nerve entrapment Meralgia paresthetica Anterolateral thigh pain or paresthesias
Obturator nerve entrapment Groin and inner thigh pain
Ilioinguinal nerve entrapment Groin pain
Piriformis syndrome (sciatic nerve compression by Buttocks and hamstrings pain piriformis muscle)
Hip bursitis Trochanteric bursitis Hip pain when lying on side or with hip abduction and adduction
Ischiogluteal bursitis Ischial pain
Iliopectineal and iliopsoas bursitis Anterior pelvis and groin, hip extension
Knee bursitis Pes anserine bursitis Anterior medial knee pain
Prepatellar bursitis Pain anterior to patella
Hip overuse External snapping hip syndrome (coxa saltans) Posterior lateral hip pain syndromes Fascia lata syndrome Lateral thigh pain
Knee overuse Patellofemoral syndrome (runner’s knee) Anterior knee pain, worse with prolonged knee flexion syndromes Medial plica syndrome Anterior medial knee pain, knee snapping during repeated
Iliotibial band syndrome or snapping knee syndrome flexion/extension
Popliteus tendinitis Pain over lateral epicondyles, or snapping when iliotibial band passes
Patellar tendinitis (jumper’s knee) over femoral condyle
Quadriceps tendinitis Posterior lateral knee pain, worse on downhill exercise
Popliteal (Baker) cyst Inferior patellar or proximal patellar tendon pain
Proximal patellar pain
Posterior knee pain
PSOAS ABSCESS
The psoas muscle is susceptible to the hematogenous spread of infection from distant sites because of its rich blood supply and proximity to overlying
 retroperitoneal lymphatic channels. Staphylococcus aureus is the most common pathogen (80%); other less frequent pathogens include Escherichia
 coli, Serratia marcescens, Pseudomonas aeruginosa, Haemophilus aphrophilus, Proteus mirabilis, and enteric pathogens. Mycobacterium
 tuberculosis is a common pathogen in immune­compromised hosts and in non­Western countries.

Symptoms include hip or flank pain (43%), abdominal pain (14%), fever (41%), and limp (22%). Presentation may be insidious. Other symptoms include nausea, weight loss, and malaise. To provoke pain, instruct the patient to perform forceful contraction of the psoas. Place your hand just proximal to the patient’s ipsilateral knee, and have the patient raise his or her thigh against your hand. The overall sensitivity of contrasted CT imaging
 for the diagnosis is over 90%, but is reduced to only 33% if symptoms have been present for less than  days. Treatment includes antibiotics to cover
,7
S. aureus and enteric pathogens and drainage. Consult surgery for percutaneous (most commonly) or open drainage.
REGIONAL NERVE ENTRAPMENT SYNDROMES
Lateral Femoral Cutaneous Nerve Entrapment/Meralgia Paresthesia (Anterolateral Thigh Pain)
Meralgia paresthetica, or compressive inflammation of the lateral femoral cutaneous nerve, is the best known of the lower extremity nerve entrapment syndromes. The nerve enters the thigh under the inguinal ligament near the anterior superior iliac spine and is subject to a variety of minor, recurring traumatic events. Nerve irritation can be triggered by tight clothing belts, heavy tool belts, car seat belts, or corsets; pregnancy; certain sitting positions
(i.e., riding a lawnmower); focal trauma, including surgical interventions such as appendectomy or hysterectomy; and obesity. It has been reported in women with muscular thighs performing activities that require repetitive flexion/extension of the leg, such as cheerleading, and in runners. Symptoms include pain to the hip area, thigh, or groin along the distribution of the nerve (proximal anterior lateral aspect of the leg; Figure 281­4), burning or tingling paresthesias, and hypersensitivity to light touch. Pain may be worsened or reproduced during physical examination by tapping over the area of the anterior superior iliac spine. Those affected should limit the exacerbating activity and eliminate the source of the irritation. NSAIDs, local injections,
,9 weight loss, and (rarely) surgical excision of the nerve are other treatment options.
FIGURE 281­4. Local innervation and locations of pain for specific thigh and groin nerves.
Obturator Nerve Entrapment (Medial Thigh/Groin Pain)
Obturator nerve entrapment is typically a sequela of pelvic fractures or abdominal/pelvic surgery. Obturator nerve inflammation is generally sensed in the groin and down the inner thigh (Figure 281­4) and aggravated by movement of the hip. Exercise­induced medial thigh pain may be the predominant symptom. The nerve is entrapped in athletes due to the presence of a fascial band at the distal obturator canal or may be compressed due to pelvic hematomas or other masses. Surgery may be required for pain relief. Imaging studies are of limited value, but needle electromyography reveals the characteristic findings of chronic denervation. Local injection of lidocaine into the area of the nerve relieves the pain and associated reactive weakness
 and may make the diagnosis; however, the nerve block is both difficult to perform and rarely done in the ED.
Ilioinguinal Nerve Entrapment (Groin Pain)
The ilioinguinal nerve arises from the lumbar plexus and passes through the psoas muscle, the transversus abdominis muscle adjacent to the anterior superior iliac spine, and the abdominal oblique muscles into the inguinal canal to innervate the groin and scrotum or labrum. Entrapment occurs due to hypertrophy of the abdominal wall musculature or pregnancy. Hyperextension of the hip produces pain and hypoesthesia in the distribution of the
 nerve, yielding groin pain.
Piriformis Syndrome (Buttock/Posterior Thigh Pain)
Compression of the sciatic nerve generally produces pain in the distal extremity, but irritation of the sciatic nerve from the piriformis muscle, referred to as the piriformis syndrome, causes pain in the area of the buttocks and hamstring muscles that is worsened by sitting, climbing stairs, or squatting
(Figure 281­5). The clinician may palpate a tender mass over the piriformis muscle and elicit pain in the region of the sacroiliac joint or gluteal musculature. Hip flexion and passive internal rotation will exacerbate the symptoms. Imaging is useful only to rule out other conditions. Treatment is conservative.
FIGURE 281­5. Proximity of the piriformis muscle and the sciatic nerve. [Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ: Emergency
Orthopedics: The Extremities, 5th ed. © 2007, McGraw­Hill, Inc., New York.]
BURSAL SYNDROMES OF THE HIP AREA
Bursae are self­contained flat sacs, lined with synovium, that reduce friction between tissues moving over each other in a repetitive fashion, such as ligaments, tendons, and bone. New bursae may form at any area that is subject to repeat irritation. Causes of bursal pain include inflammation (with repetitive minor trauma; rheumatologic disorders, such as psoriatic arthritis, rheumatoid arthritis, or ankylosing spondylitis; and crystalline disease, such as gout or pseudogout) and infection. Certain bursae are more prone than others to these insults, and these produce symptoms in specific locations that the practitioner should recognize.
Inflammation may be difficult to distinguish from infection, because both share common symptoms and signs, with a significant overlap in diagnostic cell counts when bursal fluid is aspirated. A positive Gram stain or bacterial culture is definitive for septic bursitis, but infection may be present in the absence of these findings. Occasionally, with trauma or prolonged inflammation, a bursa may develop direct communication with a joint.
Arthrocentesis is required when a septic joint is suspected. The development of a draining sinus tract favors septic bursitis (see Chapter 284, “Joints and Bursae”).
Trochanteric Bursitis (Posterolateral Hip Pain)
The trochanteric bursae lie between the gluteus maximus and the posterolateral greater trochanter, with deep and superficial components (Figure
281­6). Female runners with a broad pelvis are prone to inflammation in this location. Pain in this location is also commonly seen in older patients and can be a complication of rheumatoid arthritis. Pain is elicited when lying on the affected side, with direct pressure, or with motion such as walking or stair climbing. Activities where the hip is abducted aggravate the deep bursa, while the superficial component is irritated with adduction. Pain is
,13 revealed by palpation over the greater trochanter and resisted abduction or adduction of the hip.
FIGURE 281­6. Selected bursae of the hip and pelvis. Proximity of the piriformis muscle and the sciatic nerve. [Reproduced with permission from Simon RR, Sherman
SC, Koenigsknecht SJ: Emergency Orthopedics: The Extremities, 5th ed. © 2007, McGraw­Hill, Inc., New York.]
Bursitis from abnormal calcification is uncommon but may affect the trochanteric bursa. Calcific bursitis is identified on plain radiographs or CT as a poorly marginated line that is clearly separated from the femoral cortex. Calcification may also form around tendons. Trochanteric bursitis is
 overdiagnosed. Alternative causes of the “greater trochanteric pain syndrome” include external coxa saltans (snapping hip syndrome), abductor
 tendinopathy (involving one or more of the three gluteal muscles or the tensor fascia lata), and tendon tears. Patients who do not respond to typical
,15 measures should be referred for further evaluation, as treatment may include surgical options. Sonography may assist in making a more precise
16­19 diagnosis.
Gluteus medius tears are often misdiagnosed as trochanteric bursitis and are sometimes called the rotator cuff injury of the hip. The gluteus medius inserts onto the greater trochanter, and is important for leg abduction and stabilization of the hip during the stance phase of gait. Acute tears may cause a “pop” in the hip. Symptoms include pain on weight bearing, difficulty climbing stairs, and limping. Back, buttock, and leg pain develop with chronicity, and common misdiagnoses for chronic pain include spinal stenosis, lumbar radiculopathy, or osteoarthritis. On exam, there is tenderness over the trochanter. Hip rotation movements are normal but may cause buttock pain. Pain is reproduced with the patient lying on the side
,21 with hip extended and leg abducted. US or MRI can identify a gluteus medius tear. Treatment is physical therapy or endoscopic surgical repair.
Ischial or Ischiogluteal Bursitis (Posterior/Gluteal Pain)
More common in sedentary individuals, ischiogluteal bursitis presents with pain over the ischial prominence (Figure 281­5). “Weaver’s bottom” is a nickname for the inflammatory version of this bursitis, which is particularly exacerbated by sitting on a hard surface for long periods. The bursa lies in close proximity to the sciatic nerve and the posterior femoral cutaneous nerve, predisposing to concomitant inflammation of these nerves and subsequent characteristic radicular pain.
Iliopectineal Bursitis (Anterior Hip, Pelvis/Groin Pain)
The iliopectineal bursa is interposed between the hip joint and the iliopsoas muscle (Figure 281­6). Pain is located over the anterior pelvis and the groin on the affected side. The patient may reflexively assume a position of hip flexion and external rotation to aid in relief. On examination, extend the
 hip and palpate the area overlying the joint capsule to reproduce pain.
Iliopsoas Bursitis (Groin Pain)
The iliopsoas bursa lubricates movement of the iliopsoas tendon over the lesser trochanter and is the largest bursa in the hip region. The patient complains of pain on extension of the hip, which is reduced by hip flexion. There may be tenderness over the middle third of the inguinal ligament in the area of the femoral pulse (Figure 281­7). This process may be confused with iliopsoas tendinitis, hernias, femoral aneurysms, adenopathy, or
 psoas abscess.
FIGURE 281­7. Iliopsoas bursitis. Area for palpating the iliopsoas muscle and bursa. [Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ:
Emergency Orthopedics: The Extremities, 7th ed. © 2014, McGraw­Hill, Inc., New York. Figure 18­21.]
BURSAL SYNDROMES OF THE KNEE
Pes Anserine Bursitis (Anterior Medial Knee Pain)
The pes anserine (from the Latin for three­toed foot of the goose) bursa lies deep to the three tendons that insert on the medial aspect of the tibia below the knee joint—the gracilis, sartorius, and semitendinosus—and above the medial collateral ligament and medial femoral condyle (Figure 281­
8). Pes anserine bursitis is common in obese women with osteoarthritis of the knee, in runners, and with other various overuse syndromes. The patient complains of anterior medial pain below the joint line, and focal swelling may be noted over the bursa, with increased tenderness to palpation.

The symptoms are sometimes confused with the pain from a medial meniscal tear or a medial collateral ligament injury.
FIGURE 281­8. Medial view of the right knee, showing local bursa. [Reproduced with permission from Reichman EF, Simon RR: Emergency Medicine Procedures. ©
2004, McGraw­Hill, Inc., New York.]
Prepatellar Bursitis (Pain Anterior to the Patella)
Also known as housemaid’s knee, nun’s knee, or carpet­layer’s knee, this bursa is commonly inflamed through repetitive kneeling on hard surfaces.
Pain is frequently mild, with a restricted range of motion from the swelling, presenting as an effusion over the lower pole of the patella. This swelling may be so significant that one must differentiate it from a joint effusion (Figure 281­9). The area is tender to palpation, and bursal margins are often palpable. The prepatellar bursa is also one of the more common sites for septic bursitis, especially in children (see Chapter 284, “Joints and
,26
Bursae”).
FIGURE 281­9. Prepatellar bursitis. Photograph reveals local bursal swelling of the left knee. [Reproduced with permission from Knoop K, Stack L, Storrow A,
Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, Inc., New York.]
Other Knee Bursae
The superficial infrapatellar bursa lies between the tibial tubercle and the overlying skin (Figure 281­8). The deep infrapatellar bursa is situated between the patellar tendon and the tibia. Neither bursa is commonly inflamed or infected. Consider infection when symptoms resemble septic
 arthritis or osteomyelitis of the proximal tibia, with swelling and loss of full extension of the knee.
The tibial collateral ligament bursa lies between the ligament and the knee capsule. Calcification may occur here, and point tenderness accompanies fibrositis of the ligament. Consider this diagnosis in the patient with medial joint line pain, especially when there is no history of knee instability.
Pellegrini­Stieda disease refers to the ossification of the proximal portion of the medial collateral ligament. This results from injury and presents as a palpable, tender mass. The fibular collateral ligament has a surrounding bursa; when inflamed, it produces lateral knee pain that is increased with varus strain.
TREATMENT OF BURSITIS
Treatment is aimed at the suspected cause. For inflammatory conditions, NSAIDs, rest, heat, and time are the basis of conservative treatment. Steroids may occasionally be required, but steroid injections into the more readily accessible bursa are indicated only when it is clear that no infection exists.
Do not inject steroids into tendons, because this may weaken the tendon and lead to rupture.
For bursal pain with an unclear cause, concomitant treatment for inflammation (rest, NSAIDs) and infection (antibiotics, most commonly for S. aureus and Streptococcus species) may be reasonable while awaiting culture results. See Chapter 284, “Joints and Bursae,” for recommendations concerning bursal aspiration and diagnosis. Serial aspiration and surgical drainage or removal of the afflicted bursa are indicated for refractory, chronic conditions. If infection is suspected in an immunosuppressed patient (consider atypical organisms such as mycobacterial or fungal species) or if any patient presents with toxicity, admit for IV antibiotics and consultation with orthopedic surgery.
When fibrosis or synovial thickening leads to the development of painful nodules, surgical excision of the bursa is indicated. Inflammation of the bursa and the surrounding ligaments and tendons frequently coexists and is difficult to separate clinically.
HIP MYOFASCIAL SYNDROMES/OVERUSE SYNDROMES
The diagnosis of these syndromes is clinical. Overuse syndromes are simply the result of repetitive stresses and microtrauma outpacing the body’s ability to heal.
External Snapping Hip Syndrome (Posterior Lateral Hip Pain)
Also known as coxa saltans, a snapping sound is heard and popping sensation felt as the iliotibial band (an extension of the fascia lata) slips over the greater trochanter (Figure 281­10). In athletes, the syndrome is usually associated with painful inflammation of the band and the involved bursa. The iliotibial band courses from the iliac crest, sacrum, and ischium to the lateral condyles and fibular head, separating the vastus lateralis from the posterior thigh muscles (the hamstrings, consisting of the semitendinosus, semimembranosus, and biceps femoris). The patient will be able to voluntarily cause the snap with hip flexion and extension. Young women are predisposed to this syndrome, which occurs with activities such as dancing or stair climbing. Occasionally, the snap may be due to an intra­articular loose body. MRI may identify intra­articular causes or demonstrate inflammation of the local bursa, the iliotibial band, or the gluteal musculature. Dynamic sonography is also an aid for the diagnosis of extra­articular
,29 causes.
FIGURE 281­10. External snapping hip syndrome. In the snapping hip syndrome, the iliotibial band courses over the greater trochanter. [Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ: Emergency Orthopedics: The Extremities, 5th ed. © 2007, McGraw­Hill, Inc., New York.]
Fascia Lata Syndrome (Lateral Thigh Pain)
The fascia lata syndrome is a potential cause of pain in the lateral thigh region and is associated with pain to palpation and trigger points. Unilateral enlargement of the tensor fascia lata may occur with overuse or as a protective mechanism in injury. Athletes develop pain in the anterior groin and point tenderness over the anterior iliac crest. US is a useful aid to confirm the diagnosis.
KNEE MYOFASCIAL SYNDROMES/OVERUSE SYNDROMES
The diagnosis of these syndromes is clinical.
Patellofemoral Syndrome/Runner’s Knee (Anterior Knee Pain)
This syndrome is a major cause of anterior knee pain, with three typical causes: focal trauma (least common), overuse, and abnormal patellar tracking as it glides and rotates in the patellar groove. A major contributor to abnormal patellar tracking is weakness of the quadriceps muscle. The syndrome is more common in females due to the presence of an abnormal Q angle (>20 degrees), resulting from a broader pelvis. The Q angle is measured at the junction of a line drawn from the anterior superior iliac spine to the central patella and a second line drawn from the central patella to the tibial tubercle (Figure 281­11). A normal angle is approximately  degrees. An increased Q angle increases the risk for patellar subluxation. Because of this
 relationship, females have a 50% to 100% greater incidence of knee injuries compared with males in both athletes and nonathletes.
FIGURE 281­11. Measuring the Q angle. A. The normal Q angle is approximately  degrees. B. A Q angle of >20 degrees is considered to be abnormal. Patellar malalignment is determined clinically by measuring the Q angle. The Q angle is formed by a line drawn from the midpoint of the patella through the midpoint of the femoral shaft and a second line drawn from the midpoint of the patella through the tibial tuberosity. [Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ: Emergency Orthopedics: The Extremities, 5th ed. © 2007, McGraw­Hill, Inc., New York.]
The symptoms of anterior knee pain are gradual in onset, nonradiating, and typically unilateral. Pain is exacerbated by prolonged flexion of the knee, such as sitting in on­air flights or at the movie theater. Pain frequently occurs with activities of daily living, such as walking, and especially with stair climbing.
The presence of crepitus to palpation at the patellofemoral joint suggests degenerative changes but may be normal. The patellar grind test is accomplished by direct anterior to posterior pressure on the patella or the quadriceps tendon while asking the patient to contract the quadriceps muscles. A positive test evokes sudden patellar pain and relaxation of the muscle. The opposite test involves lifting the patella away from the knee joint while passively bending and straightening the knee. If this relieves pain, the patellofemoral joint is likely the source. Radiographic studies are of limited value but may detect arthritis.
Treatment involves the usual conservative measures, with an emphasis on physical therapy and strengthening. Brace support of the knee will also help
 correct the patellofemoral mechanism.
Inflammatory pain to the knee may last for months to a few years following surgery or trauma and is based on a genetic predisposition to arthrofibrosis from these insults. Arthroscopy may cause the release of calcium pyrophosphate from tissue, resulting in a severe synovitis.
Chondromalacia Patellae (Anterior Knee Pain)
Chondromalacia patellae refers to a softening of the cartilage on the posterior surface of the patella, most commonly occurring with the patellofemoral syndrome (Figure 281­12). This diagnosis is made by direct arthroscopic visualization of a ragged appearance of the affected
 cartilage.
FIGURE 281­12. Patellar tenderness in chondromalacia. Palpation of the undersurface of the patella will elicit tenderness in chondromalacia of the patella.
[Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ: Emergency Orthopedics: The Extremities, 5th ed. © 2007, McGraw­Hill,
Inc., New York.]
Medial Plica Syndrome (Anterior Medial Knee Pain)
The plica syndrome is uncommon and is difficult to distinguish from other causes of patellofemoral pain. Plicae are abnormal, redundant folds in the connective tissue of the knee, persisting from embryologic septa that initially divide the knee into compartments, normally disappearing as the fetus matures. Plicae become symptomatic for unclear reasons. Recurring synovitis may result in a palpable, inelastic band that interferes with normal knee movement and pain. This band­like structure is best palpated parallel to the medial border of the patella and produces pain in the area of the medial femoral condyle that radiates anteriorly. Pain may be brought on with activity or may occur at rest. Patients may also report a snapping sensation as the plica moves over the femoral condyle with repeated flexion and extension. Arthroscopy or MRI findings confirm the diagnosis. Treatment is
 conservative, with strengthening and stretching exercises; some patients require arthroscopic resection of the band.
Iliotibial Band Syndrome (Lateral Knee Pain)
Iliotibial band syndrome is most common in distance runners or cyclists. The iliotibial band inserts onto the lateral femoral and tibial condyles (Figure
281­13). The thickened fascia serves as a ligament and stabilizes the joint in extension. With overuse, the bursa underlying the band becomes irritated.
Pain is reproduced consistently after reaching a certain mileage during running or other physical exertion, and examination reveals localized tenderness to palpation over the lateral epicondyles. Treatment involves rest, decreasing the training distance, changing shoes to reduce stress on the structures, stretching exercises, and steroid injections locally.
FIGURE 281­13. Iliotibial band site. A. The iliotibial band lies anterior to the lateral femoral epicondyle when the knee is in extension and passes posterior to it with flexion. B. The coursing back and forth over this bony prominence is the cause of a symptom complex referred to as the iliotibial band syndrome.
[Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ: Emergency Orthopedics: The Extremities, 5th ed. © 2007, McGraw­Hill,
Inc., New York.]
Popliteus Tendinitis (Posterior Lateral Knee Pain)
The small popliteus muscle passes under the lateral head of the gastrocnemius and inserts into the posterior tibia. It assists with internal rotation of the tibia, withdraws the meniscus during flexion to prevent impingement, and stabilizes the knee, preventing forward displacement. A bursa separates the tendon from the underlying structures in the area of the lateral femoral condyle. Overuse syndromes of the popliteus tendon and irritation of the bursa are associated with excessive use of the quadriceps muscle. Pain is localized over the posterior lateral aspect of the knee and is worsened by running downhill. Point tenderness may be appreciated over the insertion on the proximal posterior tibia or along the lateral joint line (palpable “soft” area between the lateral proportions of the “hard” femur and tibia). The Webb test assists in making the diagnosis: internally rotate the leg in the supine patient, flex the knee at  degrees, and ask the patient to force external rotation while the examiner provides resistance. A positive test
 produces pain with the maneuver. Treatment is rest and eventual quadriceps rehabilitation, aided by ice and NSAIDs.
Patellar Tendinitis/Jumper’s Knee (Anterior Inferior Knee Pain)
The patella tendon is subject to significant wear, with microtears and complete ruptures occurring in athletes and nonathletes alike (Figure 281­14).
Any activity that involves jumping can result in focal pain, typically at the inferior pole of the patella or proximal portion of the tendon. Other activities that may exacerbate pain include running (especially uphill), squatting, cutting maneuvers, standing from a sitting position, or even simple walking.
Symptoms may improve with activity early in the course or may progress to the point of significant discomfort at rest. Treatment involves rest, NSAIDs, and cryotherapy. Steroid injections are contraindicated. Complete immobilization is not recommended, because this will reduce collagen production and stimulation of healing by load bearing. Most recently, US­guided intratendinous injection of platelet­rich plasma has been suggested to allow
,35 rapid healing in the patellar tendon and other major tendons. However, insufficient evidence exists to support this modality definitively. Further diagnosis and management of complete patellar tendon rupture are discussed in Chapter 274, “Knee Injuries.”
FIGURE 281­14. Patellar tendon defect. A. Long­axis sonogram of the proximal patellar ligament showing a hypoechoic tendon defect near the origin of the patellar tendon (arrow). The remainder of the tendon appears fibrillar and echogenic. A heel–toe insonating technique confirmed that a hypoechoic defect was present and that a tendinopathy (“jumper’s knee”) was present. B. Short­axis sonogram of the same patellar ligament. The ligament is seen as a somewhat echogenic horizontal structure approximately  mm beneath the skin surface and approximately  mm in width. In the central portion of the tendon, there is a focal area of hypoechogenicity that persists with careful imaging (arrow). This is the classic location and appearance of a “jumper’s knee” or tendinopathy of the proximal patellar tendon. [Reproduced with permission from Ma OJ, Mateer JR, Blaivas M: Emergency Ultrasound, 2nd ed. © 2008, McGraw­Hill, Inc., New York.]
Infrapatellar Fat Pad Syndrome (Anterior Inferior Knee Pain)
The infrapatellar fat pad location is suggested by its name: it fills the anterior part of the knee joint and is held in place by the patellar tendon, the retinaculum on both sides, and the infrapatellar synovial plica inferiorly. Due to its close anatomic relationship, the fat pad commonly becomes inflamed with patellar tendinitis.
Quadriceps Tendinitis (Anterior Superior Knee Pain)
The quadriceps muscles and tendon are subject to significant forces in athletes, resulting in microtears and inflammatory changes, localized predominantly at the insertion of the tendon into the proximal pole of the patella. Chronic recurrent injury or acute explosive trauma can result in complete tear of the tendon. Tendinitis is more likely to occur on a rigid playing surface and with increased frequency of training. Diagnosis and management of complete quadriceps tendon rupture are discussed in Chapter 274. Semimembranosus Tendinitis (Posteromedial Knee Pain)
Pain is elicited just distal to the joint line, where the tendon is easily palpated in most patients. In younger patients, the pain is associated with athletics and overuse. In older patients, it is seen secondary to degenerative changes of the knee joint, especially within the medial compartment. MRI will confirm the diagnosis if conservative therapy fails.
Snapping Knee Syndrome (Knee Pain)
Snapping syndrome of the knee, similar to the same process in the hip, is a result of the iliotibial band passing over the lateral femoral condyle. The same effect may also result from the semitendinosus muscle passing over the medial condyle with the initiation of flexion and termination of extension of the knee. The snapping sensation and sound may be accompanied by pain in the location of the involved tendon. A third cause is the popliteal tendon snapping over the incisura poplitea extensoria on the lateral femoral condyle. Other causes of a snapping knee include intra­articular ganglion
,37 cysts, intra­articular loose bodies, and degenerative joint disease.
POPLITEAL (BAKER) CYST (POSTEROINFERIOR KNEE PAIN)
A popliteal (Baker) cyst develops posteriorly and inferiorly to the knee as a distention of a local bursa, with several potential contributors existing in the areas of the hamstring tendons, the collateral ligaments of the knee, the condyles, and the heads of the gastrocnemius (Figure 281­15). The cyst frequently communicates with the knee (especially in adults), and associated intra­articular pathology is common. The cyst may develop as a herniation of the synovial membrane through the posterior joint capsule. Giant synovial cysts of the calf may develop in patients with rheumatoid arthritis and will also communicate with the knee. Popliteal venous thrombosis can be confused with the pain and swelling produced by these
 posterior cysts or may exist concomitantly. Other potential diagnoses include aneurysms, vascular tumors, fibrosarcoma, lipoma, and other tumors.
FIGURE 281­15. A Baker cyst (an extension of the semimembranosus bursa). [Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ: Emergency
Orthopedics: The Extremities, 5th ed. © 2007, McGraw­Hill, Inc., New York.]
US is useful and readily available for cyst evaluation and for the identification of other conditions (Figure 281­16). Arthrography or MRI is suggested
 for complete evaluation. Excision may eventually be required for symptom relief.
FIGURE 281­16. US of a Baker cyst. Transverse US view of Baker cyst, measuring approximately  cm by  cm.
PIGMENTED VILLONODULAR SYNOVITIS
Pigmented villonodular synovitis is a proliferative disorder, also referred to as giant cell tumor of the tendon sheath. The articular form can be present in many joints, including the hip and knee. The synovium and synovial fluid may appear red or brown, hence the name. Radiographs show specific findings, with erosions and cysts on both sides of the articular surface, usually with normal joint space and bone density. Typically, only one joint is
 involved. Chronic discomfort may be present, or the radiographic findings may be incidental for the asymptomatic joint.
MRI and arthroscopy are required for definitive diagnosis.
GENERALIZED ARTHROPATHY OR TENDINOPATHY RELATED TO MEDICATIONS
An important source of generalized joint pain and swelling, as well as debilitating tendinopathy/tendinitis, including frank tendon rupture, is the use of
 specific medications and drugs. In particular, the fluoroquinolone antibiotics are well described as causing these problems. In 2008, the U.S. Food and Drug Administration issued a black box warning to this effect for the quinolones. This issue occurs with enough frequency that providers should
 consider alternatives to the use of these antibiotics when possible. Other agents that are associated with tendinopathy include corticosteroids, oral contraceptives, and the recreational drugs marijuana and cocaine.
BONE/ARTICULAR DERANGEMENTS (DIFFUSE/VARIED JOINT PAIN)
Septic arthritis, viral arthritis, the arthritis of Lyme disease, osteoarthritis, and the other arthritides such as rheumatoid arthritis, crystalline arthritis, and seronegative spondyloarthropathy are covered in Chapter 282, “Systemic Rheumatic Diseases.”
Osteonecrosis
Other terms used to describe osteonecrosis include avascular necrosis, aseptic necrosis, and ischemic necrosis. Osteonecrosis is the result of bone infarction caused by a lack of blood supply. Osteonecrosis may occur as an idiopathic or primary disorder, secondary to a variety of systemic conditions, or following trauma (Table 281­3). The trauma may be major and obvious or occult and due to repetitive injury. Major trauma leads to sudden disruption of the blood supply, as commonly occurs following dislocation or fracture in the area of the joint. When the hip is involved, pain may be present anywhere in the region of the joint, the buttocks, thigh, or even the knee. Plain radiographs are helpful in establishing the diagnosis, with findings ranging from mottled densities and lucencies to severe collapse of the femoral head (Figure 281­17). With the knee, the weight­bearing medial femoral condyle is more commonly affected. Early in the disease process, CT or MRI will be more helpful in establishing the diagnosis (Figure
281­18). Joint replacement may be required.
TABLE 281­3
Conditions Associated With Avascular Necrosis (Osteonecrosis) of the Femoral Head
Traumatic
Femoral neck fracture
Hip dislocation
Occult or minor trauma
Nontraumatic
Sickle cell disease
Collagen vascular diseases
Alcohol abuse
Renal transplant
Systemic lupus erythematosus
Dysbarism
Chronic pancreatitis
Exogenous steroid administration
Cushing’s disease
Caisson disease
Gaucher’s disease
Renal osteodystrophy
Idiopathic
FIGURE 281­17. Avascular necrosis, bilateral hips (stage IV). [Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ: Emergency Orthopedics:
The Extremities, 5th ed. © 2007, McGraw­Hill, Inc., New York.]
FIGURE 281­18. Osteonecrosis of femoral head: MRI versus plain films. A 45­year­old woman receiving high­dose glucocorticoids developed right hip pain. A.
Conventional radiographs demonstrated only mild sclerosis of the right femoral head. B. T1­weighted MRI demonstrated low­density signal in the right femoral head, diagnostic of osteonecrosis. [Reproduced with permission from Fauci AS, Kasper DL, Braunwald E, et al: Harrison’s Principles of Internal
Medicine, 17th ed. © 2008, McGraw­Hill, Inc., New York.]
Osteomyelitis
Osteomyelitis is an infection of the bone by bacteria or fungus, resulting in bony changes and destruction (Figure 281­19). It develops by spread of infection from contiguous structures (∼80%) or by hematogenous spread (∼20%). Hematogenous spread is more common to the long bones in children and to the spine in adults. Spinal epidural abscess is an important differential diagnosis to consider (see Chapter 279, “Neck and Back Pain”).
Risk factors for osteomyelitis are listed in Table 281­4. Pain at the site is a universal complaint and may be accompanied by warmth, swelling, and erythema. Radiographs are normal early in the course, but later will show bone demineralization, periosteal elevation, and lytic lesions. MRI is the preferred imaging modality, with approximately 95% sensitivity, but bone biopsy confirms the diagnosis with certainty. The urgency to make the diagnosis depends on the clinical situation. Osteomyelitis in diabetics is more common with skin ulcerations >2 cm, a positive probe­to­bone test
(sterile instrument reaches periosteum when probed into wound), an erythrocyte sedimentation rate >70 mm/h, or an abnormal radiograph. S. aureus
 is the most common causative agent overall. Other infectious agents and recommended therapies are listed in Table 281­4. TABLE 281­4
Risk Factors, Likely Infecting Organism, and Recommended Initial Empiric Antibiotic Therapy for Osteomyelitis
Recommended Initial Empiric
Risk Factor Likely Infecting Organism
Antibiotic Therapy* Elderly, hematogenous spread Staphylococcus aureus, including MRSA, gram­negative bacteria Vancomycin plus piperacillin­tazobactam, or imipenem
Sickle cell disease Salmonella, gram­negative bacteria (S. aureus becoming more Ciprofloxacin; add vancomycin if S. aureus common) suspected
Diabetes mellitus, or vascular Polymicrobial: S. aureus, Streptococcus agalactiae, and Vancomycin plus piperacillin­tazobactam, insufficiency Streptococcus pyogenes plus coliforms and anaerobes or imipenem
Injection drug user S. aureus, including MRSA, and Pseudomonas Vancomycin plus piperacillin­tazobactam, or ceftazidime
Developing nations Mycobacterium tuberculosis See Chapter , “Tuberculosis”
Newborn S. aureus including MRSA, gram­negative bacteria, group B Vancomycin plus ceftazidime
Streptococcus
Children S. aureus including MRSA Vancomycin plus ceftazidime
Postoperative with or without S. aureus and coagulase­negative staphylococci Vancomycin retained orthopedic hardware
Human bite Streptococci or anaerobic bacteria Piperacillin­tazobactam or imipenem
Animal bite Pasteurella multocida, Eikenella corrodens Cefuroxime if known P. multocida, piperacillin­tazobactam or imipenem
Abbreviation: MRSA = methicillin­resistant Staphylococcus aureus.
*All patients require bone biopsy and debridement of infected/dead bone.
FIGURE 281­19. CT scan of the posterior ankle. Calcaneal osteomyelitis is seen after percutaneous fixation of a closed fracture with a large pin. Thermal necrosis of bone from drilling resulted in a ring sequestrum around the path of the pin, best shown on this CT scan. This sequestrum needed to be removed in order to control the infection. [Reproduced with permission from Slaven EM, Stone SC, Lopez FA: Infectious Diseases: Emergency Department
Diagnosis & Management. © 2007, McGraw­Hill, Inc., New York.]
Blood cultures may identify the causative agent. When a blood culture is negative, bone biopsy is necessary to guide long­term antibiotic therapy. In acutely ill patients, begin presumptive treatment based on the clinical findings, with high­dose, broad­spectrum, parenteral antibiotics ensuring coverage for S. aureus. The most recent Cochrane systematic review (2013) could not identify the optimal empiric antibiotic agent from randomized
 controlled trials in the literature. Therefore, empiric therapy is based on the suspected organism(s) from risk factors, as listed in Table 281­4. Osteochondritis Dissecans (Knee Pain)
In osteochondritis dissecans, a portion of the joint surface cartilage separates from the underlying bone. It is rare, but seen most often in adolescents, and is of unclear origin. Occult trauma likely plays a role. The lateral portion of the medial femoral condyle is predominantly involved, with unilateral occurrence. The patient experiences pain and swelling. Plain radiographs may reveal a thin rim of calcium separated from the underlying bone (Figure

281­20), with MRI showing much greater detail. Arthroscopic repair of the lesion or removal of associated loose bodies is required if conservative
 therapy fails.
FIGURE 281­20. Osteochondritis dissecans (arrow) is shown at the lateral portion of the medial femoral condyle. [Reproduced with permission from Simon RR,
Sherman SC, Koenigsknecht SJ: Emergency Orthopedics: The Extremities, 5th ed. © 2007, McGraw­Hill, Inc., New York.]
Synovial Osteochondromatosis (Hip or Knee Pain)
Synovial osteochondromatosis is characterized by idiopathic, nodular synovial membrane proliferation and subsequent calcification of the affected tissue. Eventually, multiple fragments of this growth (as large as  cm) break off and occupy the joint space or the area of the bursa and tendon sheaths. With time, degenerative changes and joint deterioration with secondary osteoarthritis occur. The disease is more common in males between the ages of  and  years old. Patients complain of chronic symptoms, with pain and joint swelling. There is a limitation in range of motion, and the joint may lock. The large joints are commonly involved. Radiographs will show the calcification and the intra­articular bodies and later the changes of
 osteoarthritis. Surgical excision of the proliferating synovium and removal of the ossified bodies from the joint space are required.
Transient Osteoporosis of the Hip (Hip Pain)
Transient osteoporosis of the hip occurs in middle­aged men and in pregnant women in the third trimester. The disease is uncommon, idiopathic, and characterized by sudden onset of hip pain, with the findings of osteoporosis on plain films. The disease spontaneously resolves within  to  months.
Symptoms may abate before the associated radiographic findings have resolved. Take precautions against hip fracture while the disease remains
,48 active.
Paget’s Disease
Osteitis deformans, or Paget’s disease, is a chronic disorder resulting in enlarged, deformed bones from overactive breakdown and reformation.
Paget’s disease affects the hip joint in 50% of patients. The disease is familial and is suggested by an elevated serum alkaline phosphate level. Patients complain of pain, and radiographs reveal joint space narrowing with minimal hypertrophic changes (Figure 281­21). Treatment is symptomatic, and medications that slow the rate of bone turnover (calcitonin, alendronate, others) may be helpful to control the disease systemically. Surgery is
,50 required for complications of the disease, such as fracture and severe arthritis.
FIGURE 281­21. Radiograph of a 73­year­old man with Paget’s disease of the right proximal femur. Note the coarsening of the trabecular pattern with marked cortical thickening and narrowing of the joint space consistent with osteoarthritis secondary to pagetic deformity of the right femur. [Reproduced with permission from Fauci AS, Kasper DL, Braunwald E, et al: Harrison’s Principles of Internal Medicine, 17th ed. © 2008, McGraw­Hill, Inc., New York.]
Osteitis Pubis (Midline Pelvis and Groin Pain With Radiation to Hips)
Osteitis pubis should be considered as a possible diagnosis in athletes with pain in the region of the pubis. It also occurs following pregnancy and after bladder and prostate surgery. In athletes, it is an inflammatory process related to overuse of the adductors and gracilis muscles. Bony changes with periostitis occur at the sites of the origins of the involved muscles. The disease is seen in runners, soccer players, weightlifters, fencers, and football players. Symptoms start off gradually and progress to severe pain with any movement of the legs. Rolling over in bed may be next to impossible due to excruciating pain, and there is a characteristic “duck waddling gait.” The symptoms may resolve completely over a period of months with rest and
NSAID use. Rarely, arthrodesis of the pubic symphysis and local debridement are required.
Radiographs show symmetric bone reabsorption medially, widening of the pubic symphysis, and sclerosis along the pubic rami. These changes may
51­53 take several weeks to develop. MRI more clearly details the changes, and bone scans show evidence of the inflammatory process.
Diseases of Abnormal Calcification
Myositis ossificans, or heterotrophic calcification, is the deposition of bone at a site where bone does not normally occur. The process is related to direct trauma, with the thigh and hip muscles frequently involved. Bleeding follows direct trauma to the muscle, and calcium deposits form inside the hematoma. A firm, palpable, painful mass will develop within  weeks and may persist for up to  year. Plain radiographs reveal an irregularly shaped mass around the joint or in the fascial planes (Figure 281­22). The appearance may be confused with a primary neoplasm, such as osteosarcoma or periosteal osteogenic sarcoma. Range of motion in the muscle or joint is limited due to pain or physical presence of the mass. Radicular pain from nerve irritation may also be present. Operative removal of the deposition may be required.
FIGURE 281­22. Myositis ossificans. This radiograph shows extraskeletal ossification of the medial proximal right thigh (immediately inferior to the head of the femur), approximately  weeks after a severe contusion to that area. [Reproduced with permission from Simon RR, Sherman SC, Koenigsknecht SJ: Emergency
Orthopedics: The Extremities, 5th ed. © 2007, McGraw­Hill, Inc., New York.]
Calcifying peritendinitis and bursitis are also traumatic in origin but are relatively uncommon. The trochanteric bursa of the hip is frequently affected.

Radiographs reveal a thin, poorly marginated white line that is separated from the cortex of the hip.
CORE TREATMENT
Treatment for the majority of inflammatory and overuse syndromes consists of NSAIDs, rest, heat, and time as the basis of conservative treatment
(Table 281­5). “Rest” does not require full immobilization, which can lead to muscle atrophy and delayed return to normal function. Full knee immobilization, which is commonly prescribed from the ED, should therefore be used sparingly in most of these conditions. Appropriate rest is followed by gradual resumption of activities, physical therapy, and strengthening activities where appropriate. Steroids may occasionally be required, and steroid injections into the more readily accessible bursa are useful when it is clear that no infection exists but can be detrimental when infection is present. It is critical to avoid steroid injections into tendons, because steroids may weaken the tendon and lead to rupture. Athletes are best served by referral to a sports medicine specialist or an orthopedist. Advanced therapies such as stem cell or platelet­rich plasma injections continue to develop
55­60 for a variety of conditions.
TABLE 281­5
Treatment Caveats
Do not inject steroids in areas where infection is a concern, or where they may accidentally be injected into tendon sheaths and contribute to tendon rupture.
Use caution in the examination of the immunocompromised patient, because signs of infection may be subtle or altered.
Injuries in athletes should be referred to a sports medicine specialist to optimize therapy and decrease time to return to maximum activity levels.


## Page 32

55. Akgun I, Unlu MC, Erdal OA, et al: Matrix­induced autologous mesenchymal stem cell implantation versus matrix­induced autologous implantation in the treatment of chondral defects of the knee: a two­year randomized study. Arch Orthop Trauma Surg 135: 251, 2015. [PubMed: 25548122]
. Rowicki K, Plominski J, Bachta A: Evaluation of the effectiveness of platelet rich plasma in treatment of chronic pes anserinus pain. Orthoped
Traumatol Rehabil 16: 307, 2014. [PubMed: 25058106]
. Vangsness CT Jr, Farr J 2nd, Boyd J, Dellaero DT, Mills CR, LeRoux W: Adult human mesenchymal stem cells delivered via intra­articular injection to the knee following meniscectomy: a randomized, double­blind, controlled study. J Bone Joint Surg 96: , 2014. University of Pittsburgh
[PubMed: 24430407]
Access Provided by:
. Vega A, Martin­Ferrero MA, Del Canto F, et al: Treatment of knee osteoarthritis with allogenic bone marrow mesenchymal stem cells: a randomized controlled trial. Transplantation 99: 1681, 2015. [PubMed: 25822648]
. Koh YG, Jo SB, Kwon OR, et al: Mesenchymal stem cell injections improve symptoms of knee osteoarthritis. Arthroscopy 29: 748, 2013. [PubMed: 23375182]
. Lamo­Espinosa JM, Mora G, Blanco JF, et al: Intra­articular injection of two different doses of autologous bone marrow mesenchymal stem cells vs hyaluronic acid in the treatment of knee osteoarthritis: a multicenter randomized controlled clinical trial. J Transl Med 14: 246, 2016. [PubMed: 27565858]

Chapter 281: Hip and Knee Pain, Kelly P. O’Keefe 
. Terms of Use * Privacy Policy * Notice * Accessibility

