## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 129: Congenital and Acquired Pediatric Heart Disease
Esther L. Yue; Garth D. Meckler
INTRODUCTION
Cardiac Complications of COVID­19: Multisystem Inflammatory Syndrome in Children (MIS­C) February 2021
Although COVID­10 infection is generally less severe in children than adults, the newly emerging clinical syndrome, MIS­C (also termed PIMS, PIMS­
TS, or MISC), may present with early and severe cardiac dysfunction in children. See detailed discussion, ‘MIS­C’, following ‘Kawasaki Disease’ below.
This chapter reviews congenital and acquired heart disease in children. The section on congenital heart defects begins with a review of fetal and neonatal cardiac physiology, followed by a discussion of specific lesions and their diagnosis and management organized by clinical presentation. A brief discussion of pediatric murmurs follows, and the section concludes with a discussion of common surgical procedures for repairing congenital heart defects and associated complications.
The section on acquired heart disease in children reviews inflammatory and infectious disorders and cardiomyopathies, of which the most important is hypertrophic cardiomyopathy.
PEDIATRIC CARDIAC PHYSIOLOGY
FETAL CIRCULATION
Fetal circulation involves a number of shunts to bypass the liquid­filled lungs, which are incapable of providing oxygen to circulating blood. Blood oxygenated by the maternal lungs passes through the placenta via the umbilical vein to the fetus. Roughly half of the blood flow passes through the liver and half through the ductus venosus to the inferior vena cava, where it mixes with deoxygenated fetal blood returning from the lower body. The inferior vena cava enters the right atrium, where deoxygenated blood returning from the upper body and head via the superior vena cava mixes with that from the inferior vena cava. Blood from the right atrium travels in one of three routes: a portion passes through the foramen ovale into the left atrium, where it subsequently travels to the left ventricle, through the aorta, and into the vessels supplying the fetal head and upper extremities; most of the remainder enters the right ventricle and passes into the pulmonary artery, where the majority is shunted away from the lungs through the ductus arteriosus connecting the pulmonary artery with the aorta; and a small amount of blood travels to the lungs to provide oxygen and nutrients to
 support fetal lung growth.
TRANSITIONAL CIRCULATION
The newborn’s lungs expand and become air filled with gradual reabsorption of fetal lung fluid. This increases the partial pressure of arterial oxygen
(Pao ) of blood flowing through the newborn lung, which in turn mediates a cascade of events that completes the transition to adult circulatory
 patterns. Flow through the umbilical arteries ceases, and the venous flow through the cord slows and then stops. Pulmonary vascular resistance falls, and pulmonary blood flow increases (pulmonary vascular resistance continues to fall with increases in blood flow over the first  to  days of extrauterine life). The ductus venosus and ductus arteriosus close, and decreased pulmonary arterial resistance coupled with increased systemic resistance creates increased blood flow through the atria. Left atrial pressure exceeds right atrial pressure, which leads to closure of the foramen
 ovale.
NEONATAL CARDIAC PHYSIOLOGY

Chapter 129: Congenital and Acquired Pediatric Heart Disease, Esther L. Yue; Garth D. Meckler 
B©e2c0a2u5 sMe cnGeroanwa Hteilsl. aAnll dR sigmhtasl lR cehsielrdvreedn. h Taevrem rse olaf tUivsee l * y Pnroivnaccoym Ppolliicayn * t Nvoetnicteri c * uAlcacre wssailblisli,t ythey cannot increase stroke volume but rely on changes in heart rate to adjust cardiac output. Thus, sinus tachycardia is usually the first response to stress in infants and young children.
The neonatal myocardium requires more oxygen than the infant’s or child’s heart and has a lower systolic reserve, which predisposes to congestive heart failure. Although the ductus arteriosus and foramen ovale are usually functionally closed by  hours of life and  months of age, respectively, shunting may still occur through these pathways during times of stress. Finally, the neonatal right ventricle is still predominant, whereas the left ventricle is predominant in older infants and children, and pulmonary vascular resistance is relatively high and oxygen responsive.
Preload is the amount of blood that the heart receives to distribute to the body. Decreasing the amount of blood flowing into the heart lowers cardiac output. Similarly, increasing the amount of blood into the heart increases cardiac output in accordance with Starling forces, to the point of maximum compliance of the ventricular wall. When the ventricular wall compliance is exceeded, cardiac output decreases dramatically, and congestive heart failure occurs.
Afterload is the resistance to blood flow out of the heart and is determined in neonates by the size and compliance of the ventricles, peripheral vascular resistance (which is largely mediated by catecholamines), and, when present, anatomic obstructions such as aortic stenosis or critical coarctation of the aorta.
Contractility or inotropy, which is the ability of the cardiac muscle to pump blood out of the heart, refers to the force or power of cardiac contraction and determines the amount of work that the heart can perform. Increasing the cardiac contractility increases the stroke volume and hence the cardiac output. Cardiac contractility is normally regulated by neural or humoral mechanisms. The ability of the neonatal heart to increase contractility is limited, as previously mentioned, and stroke volume is primarily increased through increases in rate.
Cardiac rate or chronotropy is the ability of the heart muscle to pump blood out of the heart per fixed unit of contraction. In the typical circumstance, chronotropy and inotropy cannot be differentiated with regard to therapeutic maneuvers. Typically, both the cardiac rate and the relatively fixed contractility of the neonatal heart contribute to the overall cardiac output, with the former contributing more of the output. In the hearts of children older than  or  years, there is a more balanced contribution to cardiac output, with the contractility playing a much more prominent role.
PEDIATRIC HEART MURMURS
Common benign pediatric murmurs need to be distinguished from murmurs that represent congenital heart defects. The characteristic murmurs of specific cyanotic and acyanotic congenital heart defects are described in the subsequent brief overviews of each lesion in this chapter. Usually,
,4 innocent flow murmurs are of low intensity and do not radiate, are brief murmurs, and are most often systolic. Table 129­1 lists the most common benign pediatric murmurs and their characteristics.
Table 129­1
Benign Cardiac Murmurs
Murmur Age Character Positioning Cause Differential Diagnosis
Still’s vibratory Most common Grade 1/6–3/6 early Louder when patient is Postulated to be Ventricular septal defect murmur benign murmur systolic ejection murmur, supine from flow across murmur is harsher.
in children 2–6 y; left lower sternal border to valvular cordi can occur in apex, vibratory musical infancy to quality adolescence
Pulmonary Childhood to Grade 2/6–3/6 crescendo­ Louder when patient is Turbulent flow Atrial septal defect has fixed flow murmur young decrescendo, early to supine, increased on full in the split S ; pulmonic stenosis has
 adulthood midsystolic, left upper expiration pulmonary higher pitched, longer murmur, sternal border, second outflow tract ejection click.
intercostal space
Peripheral Birth to  y Grade 1/6–2/6, low­pitched, Increased with viral Turbulence at Significant branch pulmonary pulmonic early to midsystolic respiratory infections, peripheral artery stenosis in Williams’ stenosis ejection murmur in lower heart rate; decreased pulmonary syndrome; congenital rubella murmur pulmonic area and with tachycardia artery branches has higher­pitched murmur, radiating to axillae and due to acute extends beyond S , older child.
 back angles in infants
Supraclavicular Childhood to Crescendo­decrescendo, Decreases with Turbulent flow Idiopathic hypertrophic or young systolic, low pitched, above hyperextension of through major subaortic stenosis: louder with brachiocephalic adulthood the clavicles, radiating to shoulders and reclining brachiocephalic Valsalva maneuver and softer murmur neck, abrupt onset and position vessels arising with rapid squatting.
brief from aorta Aortic stenosis: higher pitched, ejection click.
Venous hum Childhood Faint to grade , Louder when sitting, Turbulence Patent ductus arteriosus has continuous, humming, low looking away from from internal machinery murmur, not anterior neck to lateral murmur; softer when lying, jugular and compressible, bounding pulses.
sternocleidomastoid with compressed jugular subclavian veins muscle to anterior chest vein or head turned toward entering below clavicle murmur superior vena cava
Mammary Pregnancy or High pitched, systole into — Plethora of Patent ductus arteriosus has soufflé lactation, rarely diastole, anterior chest vessels over machinery murmur, does not adolescence over breast, varies day to chest wall vary day to day.
day
Reproduced with permission from Strange GR, Ahrens WF, Schafermeyer RW, et al (eds): Pediatric Emergency Medicine, 3rd ed. New York: McGraw­Hill Professional;
2009, Table 47­2. CONGENITAL HEART DISEASE
INTRODUCTION AND EPIDEMIOLOGY
Congenital heart defects can present at different ages with clinical signs and symptoms ranging from cyanosis to cardiovascular collapse or congestive heart failure depending on the anatomy and physiology of the lesion. Long­term survivors are at risk for a number of postoperative complications.
Congenital heart defects occur in approximately  in 1000 births and range from benign to life threatening. About 10% of congenital heart defects are associated with genetic syndromes such as trisomy , Turner’s syndrome, and Noonan’s syndrome, and heart defects may accompany other organ malformations in conditions such as VACTERL association (vertebral anomalies, anal atresia, cardiac anomalies, tracheoesophageal fistulas, esophageal atresia, renal and limb anomalies, and single umbilical artery). The remaining 90% of congenital heart defects result from isolated embryologic malformation or as yet undefined genetic lesions.
Congenital heart disease is usually classified based on physiology (presence or absence of cyanosis, with or without persistent fetal circulation) or on the nature of the anatomic defect (shunt, obstruction, transposition, or complex defect). Most textbooks separate cyanotic from acyanotic lesions.
Cyanotic lesions result in mixing of deoxygenated and oxygenated blood or right­to­left shunting; cyanotic lesions include the “five Ts”: tetralogy of Fallot, tricuspid anomalies including tricuspid atresia and Ebstein’s anomaly, truncus arteriosus, total anomalous pulmonary venous return, and transposition of the great arteries. Acyanotic lesions include those that result in pulmonary overcirculation such as ventricular septal defect, atrial septal defect, patent ductus arteriosus, and atrioventricular canal as well as those with restricted pulmonary or systemic blood flow such as pulmonary stenosis, aortic stenosis, and aortic coarctation.
It is often more useful to organize congenital heart disease by clinical presentation (Table 129­2). Distinct clinical presentations are discussed further in later sections, including the pathophysiology, clinical features and treatment, and individual defects within each group. Discussion of murmurs and arrhythmias included in this chapter is limited to those related to congenital heart disease. Rhythm disturbances are discussed in greater detail in the later section, “Acquired Heart Disease,” and syncope and sudden death are discussed in Chapter 130, “Syncope, Dysrhythmias, and ECG Interpretation in Children.”
Table 129­2
Clinical Presentations of Congenital Heart Disease
Clinical Symptoms Signs Potential Initial ED Management
Presentation Congenital
Cardiac Lesion
Shock Poor Extreme tachycardia Critical aortic Apply monitors feeding Pallor (often “ashen gray”) or stenosis Apply oxygen if hypoxic
Fussiness acral cŚśyanosis Coarctation of Obtain IV or IO
Progression Weak peripheral pulses the aorta Blood work (glucose, CBC, blood gas, lactate, to lethargy Delayed capillary refill HLHS BUN, creatinine, and blood culture)
Mottled skin ALCAPA with Obtain chest radiograph
Altered mental status myocardial Consider broad­spectrum antibiotics
Hypotension with decreased infarction
If abnormal cardiac exam (murmur, gallop, blood pressure in lower hepatomegaly, no palpable femoral pulses, extremities versus right arm discrepant limb blood pressures):
(in some lesions)
If patient <1 mo old, start prostaglandin E
 infusion .05–0.1 microgram/kg/min
(CAUTION: Contraindicated in TAPVR with obstruction and PPHN)
If patient >1 mo old, administer IV fluid bolus of  mL/kg normal saline
Obtain ECG
Consult cardiology for echocardiogram
Cyanosis Fussiness Central cyanosis (mucous Truncus Calm the patient membranes and trunk) arteriosus Apply monitors
Hypoxia not improved with Transposition Apply oxygen oxygen administration of the great Establish IV or IO
(oxygen saturation typically arteries
If known or suspected tetralogy of Fallot:
<80%–85%) Tricuspid
Place patient in knee­to­chest position atresia
Administer opioid: morphine .1 milligram/kg
Tetralogy of
SC/IM/IVorfentanyl  micrograms/kg
Fallot intranasal
TAPVR with obstructed
Consult cardiology and intensive care unit veins
Administer IV fluid bolus of 5–10 mL/kg normal saline
Consider the following:
Ketamine .5–3 milligrams/kg IV/IO/IM
Propranolol .2 milligram/kg IV over 3–5 min or esmolol 500 micrograms/kg followed by infusion
Phenylephrine  micrograms/kg IV followed by infusion of 2–3 micrograms/kg/min
Sodium bicarbonate  mEq/kg IV
Transfer to cardiology or intensive care unit
Congestive Feeding Tachypnea with labored Ventricular Apply monitors heart failure difficulty breathing septal defect Apply oxygen with caution
Sweating Rales Patent ductus Establish IV or IO with feeds Gallop arteriosus Blood work (glucose, CBC, blood gas, lactate,
Fussiness Hepatomegaly Atrioventricular B­type natriuretic peptide, BUN, and
Failure to Jugular venous distention canal creatinine) thrive (difficult to see in infants) PAPVR If patient not protecting airway, intubate and
Difficulty Cyanosis if severe ALCAPA with notify intensive care unit and cardiology for breathing recurrent extracorporeal life support backup ischemia and If patient has stable airway, obtain chest cardiac failure radiograph
If patient has cardiomegaly/pulmonary edema, consider IV furosemide  milligram/kg
Consult cardiology for echocardiogram and consider additional medications such as digoxin, β­blockers, or inotropes based on patient need
Abbreviations: ALCAPA = anomalous left coronary artery from the pulmonary artery; HLHS = hypoplastic left heart syndrome; PAPVR = partial anomalous pulmonary venous return; PPHN = persistent pulmonary hypertension of the newborn; TAPVR = total anomalous pulmonary venous return.
CYANOSIS IN CONGENITAL HEART DISEASE
Cyanosis is the bluish discoloration of the skin that occurs from the presence of deoxygenated hemoglobin (which is blue) in capillary beds. For cyanosis to be clinically apparent,  to  milligrams/dL of deoxyhemoglobin must be present, corresponding to an oxygen saturation of 70% to 80% on room air. Compression of the placenta during birth typically leads to polycythemia in term newborns, and as a result, clinical cyanosis develops more readily in newborns because a smaller percentage of circulating hemoglobin must be desaturated to manifest this sign. Pulse oximetry is helpful in evaluation of cyanosis; however, its limitations should be recognized. Readings may become inaccurate when oxygen is <80% saturation. Additional factors such as cool extremities, poor peripheral perfusion, skin pigmentation, and probe position may reduce the precision of pulse oximeter
5–7 readings.
Congenital heart defects that present with cyanosis include transposition of the great arteries, tetralogy of Fallot, tricuspid atresia, truncus arteriosus, and total anomalous pulmonary venous return. These lesions have in common the mixing of oxygenated and deoxygenated blood, circulation of desaturated hemoglobin, and a cardinal manifestation as cyanotic heart disease. Another condition resulting in cyanosis is persistent fetal circulation, which can be caused by structural heart disease or noncardiac disease, including meconium aspiration, pneumonia, sepsis, and pulmonary hypertension. Lesions that restrict pulmonary blood flow, such as critical pulmonary stenosis, do not typically cause cyanosis without the presence of associated defects (atrial septal defect, ventricular septal defect) that allow for right­to­left shunting.
Congenital heart defects can lead to cyanosis in the first weeks of life or, for some lesions, episodically throughout childhood if uncorrected. Lesions such as transposition of the great arteries are associated with mixing of oxygenated and deoxygenated blood, usually through an associated ventricular septal defect or atrial septal defect and produce cyanosis in the period immediately after birth. Conditions associated with persistent pulmonary hypertension allow blood to shunt right to left through a patent foramen ovale or through a septal defect. Tetralogy of Fallot (see the next section, “Tetralogy of Fallot”) can produce cyanosis at birth through mixing, but is also associated with episodic cyanosis (“tet spells”; see the later section, “Treatment of Tet Spells”) throughout infancy and childhood if uncorrected. Large uncorrected septal defects (e.g., ventricular septal defect) can cause cyanosis in adolescents and young adults in a condition termed Eisenmenger’s complex. Chronic left­to­right shunting across a nonrestrictive defect leads to hypertrophy of pulmonary arteriolar musculature that causes a gradual and irreversible rise in pulmonary vascular resistance and right­sided heart pressures until supersystemic pressures develop and shunting switches to right to left, which produces cyanosis.
Noncardiac causes of cyanosis range from benign peripheral vasoconstriction in response to cold or crying, causing peripheral cyanosis, to sepsis with
 poor perfusion or even effects of toxins such as methemoglobin. The most common congenital heart defects that must be considered in the cyanotic neonate are briefly reviewed in the sections below before returning to a general approach to the evaluation and management of cyanotic congenital heart disease.
TETRALOGY OF FALLOT
Tetralogy of Fallot is the most common cyanotic congenital heart disease manifesting in the postinfancy period and composes as much as 10% of all
,10 congenital heart disease. There are four primary components of tetralogy of Fallot: a large ventricular septal defect, right ventricular outflow obstruction (created by valvular or supravalvular pulmonic stenosis), an overriding aorta, and right ventricular hypertrophy.
The intensity of cyanosis depends on the amount of obstruction of the right ventricular outflow tract. A nonrestrictive ventricular septal defect balances the systolic pressures in the right and left ventricles. The amount of right ventricular outflow obstruction determines whether shunting is left to right, bidirectional, or right to left. Severe pulmonic stenosis creates a right­to­left shunt, resulting in cyanosis and decreased pulmonary blood flow.
The acyanotic form of tetralogy of Fallot is characterized by mild pulmonic stenosis with a left­to­right shunt. In addition to cyanosis, examination findings can include a systolic thrill at the lower and middle left sternal border. A loud single S , an aortic ejection click, a loud systolic ejection murmur

(heard best at the middle to lower left sternal border), and a continuous patent ductus arteriosus murmur may also be apparent on examination.
TRANSPOSITION OF THE GREAT ARTERIES
Composing about 5% to 8% of all congenital heart disease, transposition of the great arteries is the most common cyanotic heart lesion manifesting in the newborn period. Compared to other congenital heart defects, extracardiac anomalies occur less often in babies with transposition of the great
,12 arteries (<10%). There are many variations in transposition of the great arteries, but the underlying elements are that the aorta arises from the right ventricle and the main pulmonary artery originates from the left ventricle. This arrangement gives rise to two distinct circulatory systems. Because the main pulmonary artery has higher oxygen saturation than the aorta, hyperoxic blood goes through the pulmonary system and hypoxic blood flows through the systemic system. Mixing of the two circulatory systems is the only manner in which oxygenated blood enters the systemic blood flow. A ventricular septal defect, atrial septal defect, or patent ductus arteriosus must exist in order for the infant to survive. In 20% to 40% of patients, a ventricular septal defect is present. The physical examination is notable for a loud and single S , and if a ventricular septal defect exists, a systolic
 murmur may be heard.
TOTAL ANOMALOUS PULMONARY VENOUS RETURN
,14
Total anomalous pulmonary venous return represents 1% of congenital heart disease. The pulmonary veins empty into the right atrium instead of returning blood from the lungs into the left atrium. Total anomalous pulmonary venous return is usually separated into four groups depending on where the pulmonary veins empty. In the supracardiac type (50% of all total anomalous pulmonary venous return cases), the common pulmonary vein is attached to the superior vena cava. In the cardiac type (20%), the common pulmonary vein drains into the coronary sinus. In the infracardiac/subdiaphragmatic type (20%), the common pulmonary vein empties into the portal vein, ductus venosus, hepatic vein, or inferior vena cava. Mixed lesions compose the remaining 10%. Survival depends on the mixing of blood, so an atrial septal defect or a patent foramen ovale must be present.
When pulmonary venous return arrives in the right atrium, there is mixing of the pulmonary and systemic circulations. In the right atrium, blood crosses the atrial septal defect to the left atrium or crosses the tricuspid valve to the right ventricle. Systemic arterial blood becomes desaturated because of the mixing of pulmonary and systemic arterial flow. Pulmonary blood flow determines the degree of desaturation of systemic arterial blood. If there is no obstruction to pulmonary venous return, systemic blood is minimally desaturated. Obstruction to pulmonary venous return results in severe cyanosis. Because of the extra volume returning to the right side of the heart, right ventricular and atrial enlargement can develop.
Although total anomalous pulmonary venous return more commonly presents with signs and symptoms of congestive heart failure (see later section,
“Congestive Heart Failure in Congenital Heart Disease”), tachypnea, tachycardia, hepatomegaly, and cyanosis are commonly seen. Children with pulmonary venous obstruction often have a history of frequent pneumonias and growth retardation. The physical examination reveals a right ventricular heave and fixed split S . A grade 2/6 to 3/6 systolic ejection murmur heard at the left upper sternal border and a mid­diastolic rumble at the
 left lower sternal border are also heard. Total anomalous pulmonary venous return with pulmonary venous obstruction leads to respiratory distress and cyanosis with a loud and single S and a gallop but, on most occasions, no murmur.

TRICUSPID ATRESIA
,16
Tricuspid atresia represents 1% to 2% of congenital heart disease. There is no tricuspid valve, and the development of the right ventricle and pulmonary artery is interrupted. Pulmonary blood flow is decreased. With no flow existing between the right atrium and right ventricle, an atrial septal defect, ventricular septal defect, or patent ductus arteriosus is necessary for survival because the right atrium requires a right­to­left shunt in order to empty. The great arteries are transposed, with a ventricular septal defect and pulmonic stenosis in 30% of cases. Artery anatomy is normal, with a small ventricular septal defect and pulmonic stenosis in half of cases.
With all of the systemic venous return shunted from the right atrium to the left atrium, right atrial dilatation and hypertrophy occur. Increased volume from the systemic and pulmonary circulations causes enlargement of the left atrium and left ventricle. The extent of cyanosis and the amount of pulmonary blood flow are inversely related.
Usually patients have marked cyanosis, tachypnea, and poor feeding. A single S is evident, as well as a grade 2/6 or 3/6 regurgitant systolic murmur
 heard best at the left lower sternal border. The continuous murmur of a patent ductus arteriosus may also exist. Hepatomegaly is present if there is congestive heart failure.
TRUNCUS ARTERIOSUS (COMMON ARTERIAL TRUNK)
In truncus arteriosus, all of the pulmonary, systemic, and coronary circulations originate from a single arterial trunk. The defect comprises <1% of all
,18 congenital heart disease. Associated with truncus arteriosus are a large ventricular septal defect, coronary artery irregularities, and DiGeorge’s syndrome (hypocalcemia, hypoparathyroidism, absent or hypoplastic thymus, and chromosomal abnormalities). Pulmonary blood flow is determined by the type of truncus, and flow can be normal, increased, or decreased. There is a direct relationship between the amount of pulmonary blood flow and systemic arterial oxygen saturation. Decreased pulmonary blood flow creates marked cyanosis, whereas increased pulmonary blood flow produces minimal cyanosis but is associated with congestive heart failure from left ventricular volume overload.
Congestive heart failure and cyanosis typically develop within the first few weeks of life. A loud regurgitant 2/6 to 4/6 systolic murmur at the left sternal border may be accompanied by a high­pitched diastolic decrescendo murmur or diastolic rumble. A single S is prominent.

CLINICAL FEATURES OF CYANOTIC CONGENITAL HEART DISEASE
HISTORY
The cardinal clinical presentation of cyanotic congenital heart defects is cyanosis. The history taking should elicit details of the pregnancy, gestational age, fetal US results if applicable, and complications of labor and delivery, including cyanosis in the period immediately after birth. For older infants and children with known congenital heart defects, details of the anatomy and surgical procedures and current medications should be obtained.
Baseline oxygen saturations may be known by caretakers and are helpful when intercurrent illness leads to an ED visit. Take a careful feeding history, focusing on changes in oral intake, slow or difficult feeding, sweating with feeds, and growth, and a complete review of systems should be performed.
PHYSICAL EXAMINATION
Measure all vital signs, including blood pressure in the upper and lower extremities. A difference in upper and lower extremity blood pressures may signal an obstructive lesion such as coarctation of the aorta (see later section, “Coarctation of the Aorta”). Document weight and growth parameters.
Note if cyanosis is central (mucosal) or peripheral (acral, involving digits). Listen for cardiac murmurs, noting location, timing, and loudness (see later section, “Pediatric Heart Murmurs”), and a gallop or fixed splitting of S (characteristic of atrial septal defect). Palpate the chest for heaves, lifts,
 and thrills, and note surgical scars. Observations of the strength, quality, and symmetry of pulses help in the assessment of cardiac output.
Hepatomegaly and splenomegaly suggest right­sided heart failure. Observe for signs of increased work of breathing, and auscultate for rales, which suggest congestive heart failure. Neonates with cyanosis secondary to congenital heart disease rarely have respiratory symptoms other than tachypnea. Neonates with lung disease producing cyanosis show respiratory distress, grunting, tachypnea, and retractions. Cyanotic infants with CNS disturbances or sepsis have apnea, bradycardia, lethargy, and seizures. Neonates with methemoglobinemia show minimal distress despite their cyanotic appearance. Perform a complete head­to­toe examination in the cyanotic patient without a known history of congenital heart defects to exclude noncardiac causes.
DIAGNOSIS IN CYANOTIC HEART DISEASE
Laboratory tests are not typically helpful in the evaluation of cyanotic congenital heart defects, although they help exclude other causes of cyanosis.
Results of the “hyperoxia test” (Pao in response to breathing 100% oxygen) may help distinguish heart disease from other causes of
 cyanosis. Neonates with cyanotic heart disease do not demonstrate an increase in Pao >20 mm Hg, because of the right­to­left
 shunting of the circulation. Most neonates with lung disease or sepsis, however, demonstrate an increase in Pao after breathing 100% oxygen for

 minutes. Infants with persistent pulmonary hypertension may or may not demonstrate a significant rise in Pao . There is no response to oxygen in
 the neonate with methemoglobinemia. When a blood specimen is exposed to air, it turns pink in all the conditions described earlier except in methemoglobinemia, in which the blood remains chocolate colored. In an infant without known congenital heart defects, results of arterial blood gas analysis with the infant breathing room air and 100% oxygen can be compared: failure of the Pao to rise significantly with 100%
 oxygen suggests cardiac mixing or right­to­left shunting, whereas improvement in the Pao in response to oxygen suggests a pulmonary cause.

The primary diagnostic tests for the patient with suspected cyanotic congenital heart defects are chest radiography and ECG (Table 129­3). Chest radiographic studies are essential in assessing the size and shape of the heart and in evaluating pulmonary blood flow. The chest radiograph also provides some information about the position of the aortic arch, which should be normally left sided. In the normal left­sided aortic arch, there is rightward displacement of the esophagus and trachea. An abnormal position of the aortic arch may be a clue to the diagnosis of the congenital cardiac lesion. Right­sided aortic arches are seen in truncus arteriosus, transposition of the great arteries, tetralogy of Fallot, tricuspid atresia, and total anomalous pulmonary venous return. The chest radiograph is critical to the assessment of pulmonary vascularity. With small left­toright shunts, the pulmonary vascularity is normal. Pulmonary vascularity can also be normal in conditions that cause pulmonary stenosis, such as valvular pulmonic stenosis or functional pulmonic stenosis associated with tetralogy of Fallot. Increased pulmonary vascularity may be seen with any cause of left­to­right shunting or in any cause of left­sided failure, such as outflow obstruction.
Table 129­3
Cyanotic Congenital Cardiac Lesions: Typical Chest Radiograph and ECG Findings
Cardiac Lesion Chest Radiograph ECG
Tetralogy of Fallot Boot­shaped heart, normal­sized heart, decreased Right axis deviation, right ventricular hypertrophy pulmonary vascular markings
Transposition of the great Egg­shaped heart, narrow mediastinum, increased Right axis deviation, right ventricular hypertrophy arteries pulmonary vascular marking
Total anomalous Snowman sign, significant cardiomegaly, increased Right axis deviation, right ventricular hypertrophy, right atrial pulmonary venous return pulmonary vascular markings enlargement
Tricuspid atresia Heart of normal to slightly increased size, decreased Superior QRS axis with right atrial hypertrophy, left atrial pulmonary vascular markings hypertrophy, left ventricular hypertrophy
Truncus arteriosus Cardiomegaly, increased pulmonary vascular Biventricular hypertrophy markings
The ECG is useful to evaluate chamber size, electrical axis, and cardiac conduction. Age­related normal values should be used as a reference to
 determine axis deviation, atrial enlargement, or ventricular hypertrophy. The electrical axis most often defines abnormal chamber diameters and usually does not suggest cardiac ischemia as in the adult population. Table 129­3 lists characteristic chest radiograph and ECG findings of cyanotic congenital heart defects. Figure 129­1 depicts the typical “boot­shaped heart” of tetralogy of Fallot.
FIGURE 129­1
Chest radiograph revealing the classic “boot­shaped heart” of tetralogy of Fallot. [Reproduced with permission from Shah BR, Lucchesi M (eds): Atlas of Pediatric Emergency Medicine. New York, NY: McGraw­Hill, Inc., 2006.]
When available, bedside echocardiography may delineate structural heart disease, although adequate imaging depends on the availability of an ultrasonographer with pediatric cardiac experience.
TREATMENT IN CYANOTIC HEART DISEASE
The management of cyanotic congenital heart defects depends on the age of the patient, hemodynamic stability, and prior diagnosis and medical management (Table 129­3). Most cyanotic congenital heart defects are hemodynamically stable. With obstructive lesions, in contrast, adequate circulation often depends on systemic or pulmonary blood flow through a patent ductus arteriosus, and such lesions can be fatal if patency is not maintained with prostaglandins (see later section, “Shock in Congenital Heart Disease”). Although central cyanosis and low oxygen saturation are alarming and may tempt one to administer oxygen immediately, neonates have significant amounts of oxygen­avid fetal hemoglobin and tolerate oxygen saturation percentages in the 70s (characteristically seen in most mixing lesions) without tissue or brain hypoxemia. Moreover, oxygen is a potent pulmonary vasodilator. Oxygen administration and pulmonary vasodilation are helpful in treating cyanotic congenital heart defects associated with pulmonary hypertension or vasoconstriction, but may actually lead to pulmonary vascular overcirculation or even “steal” of systemic blood flow in patients with a patent ductus arteriosus and ductaldependent systemic blood flow. Oxygen administration should be reserved for patients with signs and symptoms of inadequate tissue perfusion, those without known heart disease in whom it may be diagnostic as well as therapeutic, and patients with known congenital heart defects with oxygen saturation significantly below known baseline values.
The primary management objective in the cyanotic neonate or infant is the treatment of intercurrent illness, exclusion of noncardiac causes of cyanosis, and diagnosis of cyanotic congenital heart defects in those who do not have a previous diagnosis. Treatment thereafter involves consultation with a pediatric cardiologist and transfer to a tertiary pediatric hospital or clinic.
TREATMENT OF TET SPELLS
A tet spell is caused by right­sided outflow tract obstruction leading to right­to­left shunting through a ventricular septal defect.
Hypoxia and acidosis cause pulmonary arterial vasoconstriction, thus increasing pulmonary resistance and exacerbating shunting.
The management goals for tet spells are to increase pulmonary blood flow by increasing preload, provide pulmonary vasodilation, and increase afterload in order to reverse right­to­left shunting and promote pulmonary blood flow. This is often achieved through simple maneuvers such as administering 100% oxygen via a non­rebreathing facemask, calming the child by minimizing stimulation and placing the child in a parent’s arms, and flexing the child’s knees to the chest in order to increase venous return to the heart and increase systemic vascular resistance to mitigate right­to­left shunting. Second­line intervention includes administration of morphine, .1 to .2 milligram/kg IM,
SC, or IV, and isotonic fluid (normal saline  to  mL/kg bolus) to increase preload. Case reports have demonstrated efficacy of intranasal fentanyl or
,21 intranasal midazolam as alternatives to morphine. If these measures are unsuccessful, next options include administration of sodium bicarbonate
 mEq/kg as an IV bolus to treat acidosis and promote pulmonary vasodilation; propranolol .2 milligram/kg IV to relieve infundibular spasm; or phenylephrine  to  micrograms/kg/min to increase systemic vascular resistance. Ketamine may be helpful with its sedative effects and its increase in
 systemic vascular resistance. Refractory spells may require neuromuscular blockade and rapid­sequence intubation.
SHOCK IN CONGENITAL HEART DISEASE
The presentation of congenital heart defects as shock or cardiovascular collapse is dramatic. Cardiogenic shock can be the final common pathway for a wide variety of disease processes, both noncardiac and cardiac. Sepsis, hypovolemic shock, metabolic disease, adrenal insufficiency, respiratory failure, trauma, and poisonings can all lead to cardiogenic shock and are discussed in other chapters. Consider noncardiac causes of shock and low cardiac output states and treat the patient accordingly while contemplating the possibility of congenital heart disease.
Congenital heart defects that present as shock or cardiovascular collapse include lesions that depend on flow through the ductus arteriosus to provide systemic or pulmonary perfusion (Table 129­4). The classic examples are severe coarctation of the aorta and hypoplastic left heart syndrome. In both of these conditions, systemic blood flow is restricted by the underlying defect but maintained by flow through a patent ductus arteriosus that bypasses the coarctation in the former and allows blood pumped by the functional right ventricle to perfuse the aorta in the latter. The ductus typically closes and becomes the ligamentum arteriosum by the second or third week of life, and as it constricts, patients with duct­dependent flow manifest poor peripheral perfusion with increasing acidosis and eventual cardiovascular collapse.
Table 129­4
Duct­Dependent Acyanotic Congenital Cardiac Lesions: Typical Chest Radiograph and ECG Findings
Cardiac Lesion Chest Radiograph ECG
Coarctation of the aorta Cardiomegaly with pulmonary edema (neonate) RVH, right bundle branch block (neonate)
Rib notching and collateral vascularity (child) LVH (child)
Hypoplastic left heart syndrome Cardiomegaly Right atrial enlargement, RVH, peaked P waves
Aortic stenosis Cardiomegaly LVH in severe cases
Abbreviations: LVH = left ventricular hypertrophy; RVH = right ventricular hypertrophy.
Once the ductus arteriosus begins to close, some cardiac lesions become incompatible with life, because blood can no longer reach the lungs or systemic circulation. Both cyanotic and acyanotic lesions may present in this fashion.
Acyanotic lesions include severe coarctation of the aorta, critical aortic stenosis, and a hypoplastic left ventricle. Transposition of the great arteries, pulmonary atresia, and hypoplastic right heart syndrome are examples of the cyanotic lesions that may present with shock.
Nonstructural cardiac causes of shock include dysfunctional myocardium, which may mimic the signs and symptoms seen with shunt­dependent anatomic lesions. Such cardiomyopathies are uncommon in pediatric patients but can easily be confused with anatomic lesions. Cardiomyopathies in children are discussed later in “Acquired Heart Disease.”
Duct­dependent acyanotic congenital lesions are briefly reviewed in the following sections.
COARCTATION OF THE AORTA
Coarctation of the aorta represents 8% to 10% of congenital heart disease and has a 2:1 male predominance. Congenital narrowing of the aorta takes place around the ductus arteriosus in the upper thoracic aorta. Factors determining the severity and clinical manifestations of disease include the degree of narrowing, the length of narrowing, and the presence of associated defects. Infants who present early have a right ventricle that supplies the descending aorta through a patent ductus arteriosus in fetal life. A ventricular septal defect, patent ductus arteriosus, aortic hypoplasia, and underdeveloped collateral circulation can also be seen.
PATENT DUCTUS ARTERIOSUS
A patent ductus arteriosus delays the obstructive effects of coarctation by allowing blood to flow distal to the obstruction. With closure of the patent ductus arteriosus, pulmonary hypertension occurs, leading to pulmonary venous congestion and congestive heart failure. Blood flow distal to the aortic obstruction is compromised. Shock, metabolic acidosis, tachypnea, and feeding difficulty are common; when congestive heart failure occurs, a
 loud gallop and weak pulses with or without a murmur can usually be appreciated.
Finding decreased pulses in the lower extremities is essential to diagnosing a coarctation. Comparing right upper extremity blood pressures and pulse oximeter readings with those of the lower extremities aids in diagnosis unless the patient is in shock, in which case pulses may be decreased all over.
HYPOPLASTIC LEFT HEART SYNDROME
Hypoplastic left heart syndrome consists of hypoplasia of the left ventricle and ascending aorta and aortic arch. Atresia or marked stenosis of the mitral and aortic valves and regressed development of the left atrium are also common. These combined lesions lead to minimal left ventricular outflow. In utero pulmonary vascular resistance remains higher than systemic vascular resistance. The right ventricle is able to maintain normal perfusion of the body through right­to­left shunting through the patent ductus arteriosus as a result of elevated pulmonary resistance. Systemic blood flow is based entirely on the ductus arteriosus. After birth, major problems occur as reversal of the fetal pulmonary­systemic pressure gradient takes place and the ductus arteriosus closes. Cardiac output collapses and aortic pressure falls, which results in circulatory shock and metabolic acidosis.
Pulmonary edema also develops because of increased pulmonary blood flow and increased left atrial pressure. Signs at presentation include an ashen
,24 gray color, tachypnea, and listlessness, and a single heart sound, systolic ejection murmur, and decreased pulses are noted.
AORTIC STENOSIS
Aortic stenosis composes 6% of congenital heart disease and has a 4:1 male predominance. Stenosis can occur at the valvular, supravalvular, or subvalvular levels. Infants with severe obstruction (10% to 15%) present with congestive heart failure and poor distal perfusion or shock. Left ventricular hypertrophy typically develops in severe stenosis. Patients with aortic stenosis who are asymptomatic in infancy can present in childhood with syncope and hypertension.
A bicuspid aortic valve is the most common form of aortic stenosis. Supravalvular aortic stenosis, elfin facies, mental retardation, and pulmonary artery stenosis compose Williams’ syndrome. A systolic thrill may be noticed at the right upper sternal border, suprasternal notch, or carotid arteries along with an ejection click. There can also be a rough or harsh grade 2/6 to 4/6 systolic murmur at the right or left sternal border with transmission to the neck.
CLINICAL FEATURES OF SHOCK IN CONGENITAL HEART DISEASE
HISTORY
The typical history of the neonate with duct­dependent congenital heart defects is one of a day or two of poor feeding, irritability, or lethargy followed by decreasing responsiveness, often in the second or third week of life. By the time the neonate arrives in the ED, he or she is often in severe shock.
Obtain a complete history of the pregnancy, labor and delivery, and immediate perinatal period and carefully review symptoms (e.g., vomiting, diarrhea, fever, respiratory distress) to rule out noncardiac causes of shock such as dehydration or infection.
PHYSICAL EXAMINATION
Measure four­extremity blood pressure to identify a gradient between upper and lower extremities characteristic of coarctation of the aorta. Pulse oximetry measurements in the right (preductal) and left (postductal) upper extremities may also reveal a difference, suggesting duct­dependent flow. Tachycardia is usually severe, and tachypnea may reflect profound metabolic acidosis or may be a manifestation of heart failure. Hypoxemia and cyanosis may accompany cyanotic lesions with duct­dependent flow. An ashen or gray color is characteristic of the infant with left­sided outflow obstruction in systemic shock, and extremities may be cold and mottled with severely delayed capillary refill. A single heart sound is characteristic of hypoplastic left heart syndrome, and a harsh systolic murmur transmitted to the neck may be heard in patients with aortic stenosis. A gallop rhythm may be appreciated when congestive heart failure accompanies shock. Pulses are typically thready and may be absent in the lower extremities with significant delay between right brachial and femoral pulses. The lung examination may reveal rales, tachypnea, and retractions or grunting in neonates with both shock and congestive heart failure. The infant may be limp and lethargic.
DIAGNOSIS IN CONGENITAL HEART DISEASE WITH SHOCK
Laboratory studies that may aid in the diagnosis and management of duct­dependent congenital heart defects include arterial blood gas analysis, which often demonstrates profound metabolic acidosis. Other electrolyte abnormalities are rare, although renal insufficiency from hypoperfusion may accompany severe shock. A CBC is not routinely helpful but may be obtained to rule out noncardiac causes of shock, such as sepsis.
ECG and chest radiography are typically performed and may be useful in narrowing the differential diagnosis of suspected congenital heart defects.
Table 129­4 lists the characteristic findings in duct­dependent acyanotic lesions.
Radiographs are less helpful in duct­dependent acyanotic congenital heart defects than in cyanotic heart disease, but may be useful when clinical symptoms and signs of congestive heart failure exist. Signs of aortic stenosis outside of infancy are cardiomegaly and posterior rib notching of the third to eighth ribs from collateral vessels. Bedside echocardiography requires an ultrasonographer experienced in examining for pediatric heart disease.
TREATMENT OF SHOCK IN CONGENITAL HEART DISEASE
Although oxygen is typically administered to patients in shock in order to increase the dissolved oxygen content of blood and enhance tissue oxygenation, oxygen is a potent pulmonary vasodilator and decreases right­to­left flow through the ductus arteriosus, potentially worsening systemic perfusion. Oxygen is also a vasoconstrictor of the ductus arteriosus, which further worsens perfusion (Table 129­
2). Infants requiring rapid­sequence intubation are at high risk for complications, and pretreatment with atropine is recommended (0.02 milligram/kg

IV  minutes prior to sedation and paralysis).
The single most important therapeutic intervention for duct­dependent lesions is the infusion of IV prostaglandin E to restore ductal patency and
 improve left­to­right shunting and systemic blood flow. The initial dose of prostaglandin E is .1 microgram/kg/min, and improvement in
 peripheral perfusion typically occurs in minutes. Subsequent titration to the lowest effective dosage is recommended, typically .05 microgram/kg/min. Prostaglandin E can be administered through an umbilical venous catheter, central line, IO line, or peripheral IV
 line with equal efficacy. Side effects include vasodilation and flushing, hyperthermia, hypotension (although blood pressure typically improves), and apnea. Continuous monitoring of infants receiving prostaglandin E is therefore advised. In certain obstructive variants of
 total anomalous pulmonary venous return, administration of prostaglandin E can exacerbate the patient’s condition because it increases pulmonary
 flow and decreases pulmonary resistance, thereby increasing pulmonary venous congestion.
Give a bolus of  mL/kg of normal saline with careful reassessment after each bolus to increase preload and improve cardiac output. Infants with severe congestive heart failure may not tolerate much volume. Sodium bicarbonate,  to  mEq/kg, can be considered for severe metabolic acidosis (pH <7.0), but may cause paradoxical intracellular worsening of acidosis and myocardial dysfunction, and adequate ventilation must be ensured. Occasionally, pressors such as dopamine or dobutamine may be helpful after prostaglandin E infusion has been initiated.

Sepsis cannot be excluded on clinical grounds, so also give ampicillin, 100 milligrams/kg, and gentamicin,  milligrams/kg; or cefotaxime,  to 100 milligrams/kg.
Consultation with a pediatric cardiologist and pediatric critical care specialist is of great importance. Although many practitioners routinely intubate
 infants receiving prostaglandin E prior to transport to tertiary hospitals, infants in stable condition may safely be transported unintubated.

CONGESTIVE HEART FAILURE IN CONGENITAL HEART DISEASE
Congenital heart defects can lead to congestive heart failure because of left­sided outflow obstruction resulting in elevated left atrial pressure (e.g., aortic stenosis) or pulmonary overcirculation through a patent ductus arteriosus or septal defect (Table 129­2). Such lesions typically present later in infancy, often in the second through fourth months of life, with failure to thrive, feeding difficulties, sweating with feeds, and gradually increasing respiratory distress that may worsen with respiratory infection. A number of acquired heart conditions, including myocarditis, cardiomyopathy, and arrhythmias, as well as noncardiac conditions, such as sepsis, metabolic disease, or severe anemia, can also cause congestive heart failure in infants and children (see later section, “Acquired Heart Disease”).
Important factors in the development of congestive heart failure include increased afterload from left­sided obstructive lesions (e.g., coarctation or stenosis of the aorta), increased preload or pulmonary circulation from left­to­right shunts (e.g., large ventricular septal defect, atrial septal defect, patent ductus arteriosus), decreased inotropic function (e.g., cardiomyopathy), and rhythm abnormalities (e.g., sustained tachyarrhythmias).
In addition to congenital structural heart disease, noncardiac disorders and acquired heart disease should be considered as causes of congestive heart failure. Congenital structural causes of congestive heart failure not already discussed are described further in the following sections.
ATRIAL SEPTAL DEFECTS
,28
Atrial septal defects compose 10% of congenital heart disease. Only 10% of infants with an atrial septal defect develop clinical symptoms. Large or multiple defects can cause significant left­to­right shunting with overloading of the pulmonary circulation. Surgical intervention is needed for larger atrial septal defects, whereas smaller ones may close spontaneously. Difficulty feeding and trouble gaining weight are common with larger lesions.
Ostium secundum defects represent the majority of atrial septal defects and result from the incomplete adhesion of the foramen ovale and septum secundum. Ostium primum atrial septal defects result from the insufficient merging of the septum primum and endocardial cushion with associated abnormalities of the mitral and tricuspid valves. Sinus venosus atrial septal defects occur when the atrium does not merge with the sinus venosus. In these lesions, a widely and fixed split S with a grade 2/6 to 3/6 systolic ejection murmur at the left sternal border can often be appreciated, along with
 a mid­diastolic rumble.
VENTRICULAR SEPTAL DEFECTS
,29
Ventricular septal defects are the most common congenital heart defect, composing >30% of all such defects. Ventricular septal defects allow blood to mix in the ventricles. The size of the ventricular septal defect determines the clinical extent of disease, with small defects having little or no effect and large defects contributing to pulmonary hypertension and congestive heart failure. Large ventricular septal defects create volume and pressure overload in the right ventricle and volume overload in the left atrium and left ventricle. This results in congestive heart failure and poor weight gain and may lead to developmental delay. A grade 2/6 to 5/6 holosystolic, harsh murmur can often best be heard at the left lower sternal border and may have an associated systolic thrill or diastolic rumble with a narrowly split S .

PATENT DUCTUS ARTERIOSUS

A patent ductus arteriosus is present in 10% of cases of congenital heart disease and occurs when the ductus arteriosus fails to close spontaneously.
The degree of shunting through the ductus arteriosus depends on the length and diameter of the lesion and the pulmonary vascular resistance.
Symptomatic patients have large left­to­right shunts. Normally, the ductus arteriosus closes within  hours of birth and seals completely at  weeks of age, becoming the ligamentum arteriosum. Prematurity and hypoxia can delay closure of the ductus arteriosus. As with all left­to­right shunts, a large patent ductus arteriosus presents as congestive heart failure. A grade 1/6 to 4/6 continuous “machinery” or “to­and­fro” murmur may be appreciated and is loudest at the left upper sternal border. A diastolic rumble and bounding pulses can also be present.
ENDOCARDIAL CUSHION DEFECT (COMMON ATRIOVENTRICULAR CANAL)
Abnormal development of the endocardial cushion causes defects in the atrial septum, ventricular septum, and atrioventricular valves. Complete defects involve the entire endocardial cushion and involve the atrial and ventricular septum as well as the common atrioventricular valve. Incomplete or partial defects have atrial involvement with an intact ventricular septum. Endocardial cushion defects represent 3% of congenital heart disease
,31 cases, with two thirds manifesting as complete defects. Down syndrome and endocardial cushion defects are strongly associated.
Typical presentations include failure to thrive and frequent respiratory infections. There is a direct relationship between left­to­right shunting and the magnitude of the defects, and complete lesions often lead to congestive heart failure from volume overload of both ventricles early in life.
Usually there is a hyperactive precordium, a systolic thrill, a loud holosystolic regurgitant murmur, and a loud and widely split S . The ECG is important
 and demonstrates a pathognomonic superior QRS axis with right ventricular hypertrophy, right bundle branch block, left ventricular hypertrophy, and a prolonged PR interval.
ANOMALOUS LEFT CORONARY ARTERY ARISING FROM PULMONARY ARTERY
Anomalous left coronary artery arising from pulmonary artery is very rare and occurs when the left coronary artery branches from the pulmonary artery instead of the aorta. The decreased pressure in the pulmonary artery causes significantly lower flow in the anomalous left coronary artery and actually reverses blood flow (“coronary steal”), resulting in left ventricular insufficiency. This is one of the most common causes of myocardial
 ischemia and infarction in infants, mostly anterolateral infarct; unfortunately, 90% of untreated children die within  year of life.
Presenting symptoms in infancy include irritability (angina) and diaphoresis with feeds. There may be a murmur present consistent with mitral regurgitation. Mitral regurgitation results from infarction of the papillary muscle or from annular dilation.
CLINICAL FEATURES OF HEART FAILURE IN CONGENITAL HEART DISEASE
HISTORY
The typical history of congenital heart defects presenting with congestive heart failure depends on the pathophysiology of the underlying lesion.
Cyanotic lesions often present early in the neonatal period, whereas obstructive duct­dependent lesions typically present in the second week of life with feeding difficulties and shock, as previously discussed. Patients with pulmonary overcirculation from truncus arteriosus, patent ductus arteriosus, and large ventricular septal defect or atrial septal defect lesions usually present after the neonatal period with poor or prolonged feeding, diaphoresis, and respiratory distress associated with feeds, and poor weight gain, sometimes associated with developmental delay. Parents may notice increased work of breathing, cyanosis, or frequent respiratory infections or wheezing. Tachyarrhythmias and anemia can also lead to congestive heart failure.
PHYSICAL EXAMINATION
Assessment of vital signs may reveal tachycardia and tachypnea with or without associated hypoxemia, depending on the underlying defect. Upper and lower extremity blood pressure differences may signal left outflow tract obstruction. Wide pulse pressure suggests a shunting lesion such as patent ductus arteriosus, whereas a narrow pulse pressure may indicate cardiomyopathy or myocarditis. Record weight and compare with birth and previous weights as an indicator of overall growth. Careful palpation of the chest wall may reveal a hyperdynamic precordium or thrill; palpation of the pulses may uncover a delay between upper and lower extremities or weak distal pulses or may reveal bounding pulses characteristic of patent ductus arteriosus. Murmurs may be noted with nearly all congenital heart defects resulting in congestive heart failure and may be characteristic (e.g., continuous murmur of patent ductus arteriosus); the presence of a diastolic rumble suggests significant pulmonary overcirculation, as seen with a large unrestrictive ventricular septal defect. A fixed split S is suggestive of an atrial septal defect. Gallops may be present, especially with
 cardiomyopathy, and occasionally a friction rub can be appreciated in pericarditis.
The hallmarks of congestive heart failure with elevated left­sided pressure are pulmonary rales and increased work of breathing, although rales are less often detected in infants and young children as compared to older children. Hepatomegaly, with or without splenomegaly, and peripheral or generalized edema suggest right­sided heart failure. Jugular venous distention is often difficult to appreciate in neonates and infants and may be absent.
DIAGNOSIS OF HEART FAILURE IN CONGENITAL HEART DISEASE
The laboratory evaluation of congestive heart failure includes measurement of electrolytes and renal function tests, which may be helpful in determining volume status. A CBC may reveal anemia, and determination of red cell indices may point to a cause.
Chest radiograph may reveal a cardiac silhouette suggestive of a particular congenital defect, cardiomegaly, and pulmonary edema or pleural effusion.
Table 129­5 outlines characteristic chest radiograph and ECG findings in congenital heart defects presenting as congestive heart failure.
Echocardiography provides a definitive diagnosis.
Table 129­5
Acyanotic Congenital Cardiac Lesions Resulting in Congestive Heart Failure: Typical Chest Radiograph and ECG Findings
Cardiac Lesion Chest Radiograph ECG
Atrial septal defect Cardiomegaly with increased vascular Right axis deviation, RVH, RBBB markings
VSD Cardiomegaly with increased vascular LAH, LVH (RVH with larger VSDs) markings
PDA Cardiomegaly with increased vascular LVH, RVH with larger PDAs markings
Endocardial cushion defect Cardiomegaly with increased vascular Superior QRS axis with RVH, RBBB, LVH, prolonged PR interval markings
Anomalous origin of the left coronary Cardiomegaly Abnormally deep and wide Q waves with precordial ST­segment artery changes
Abbreviations: LAH = left atrial hypertrophy; LVH = left ventricular hypertrophy; PDA = patent ductus arteriosus; RBBB = right bundle branch block; RVH = right ventricular hypertrophy; VSD = ventricular septal defect.
TREATMENT OF CONGESTIVE HEART FAILURE IN CONGENITAL HEART DISEASE
Administer oxygen cautiously (Table 129­2). Oxygen saturation of >95% may cause pulmonary vasodilation and worsen congestive heart failure in overcirculating lesions such as ventricular septal defect and patent ductus arteriosus. Elevate the head of the infant’s bed. Provide volume expansion cautiously if at all. A bolus of  to  mL/kg of normal saline may improve cardiac output in some circumstances but may worsen failure in others.
The mainstays of congestive heart failure treatment are furosemide (1 to  milligrams/kg IV) for diuresis and inotropic support. Adjustments to preload
(end­diastolic volume is roughly equivalent to intravascular volume), afterload, contractility, and heart rate can be attempted.
Dopamine and/or dobutamine should be considered in the acutely ill patient with congestive heart failure. Dopamine increases heart rate, blood pressure, and urine output. Give dopamine as a continuous infusion at  to  micrograms/kg/min. Dobutamine reduces afterload through peripheral vasodilation and improves cardiac output without increasing blood pressure. Give dobutamine as a continuous infusion at .5 to  micrograms/kg/min, but in infants <1 year of age, tachycardia can result, and the dose may need to be lowered. Congestive heart failure associated
 with hypotension may require treatment with dopamine and dobutamine.
Milrinone has inotropic effects, improves diastolic relaxation, and causes vasodilation, but does not augment heart rate and does not increase myocardial oxygen demand. Milrinone is given as a loading dose of  micrograms/kg IV administered over  to  minutes followed by a continuous infusion of .25 to .75 microgram/kg/min. While the adjuvant agent synthetic brain natriuretic peptide has been investigated for its vasodilatory and
 natriuretic effects, there is little evidence to support its use in the pediatric population.
Afterload reduction may be useful for conditions unresponsive to standard measures and in consultation with a cardiologist. Nitroprusside is a mixed vasodilator and can be administered as an infusion of  to  micrograms/kg/min. Calcium channel blockers may be more effective in cases of diastolic dysfunction and include diltiazem (0.2 to .5 milligram/kg/dose PO or sublingual) and nifedipine (0.25 to .0 milligram/kg PO) but are contraindicated in infants <1 year of age. Consult a pediatric cardiologist to help guide diagnosis and management and potential transfer to a tertiary care pediatric facility.
For patients in stable condition, digoxin is the inotrope of choice and improves cardiac contractility and output. The total digitalizing dose is  to  micrograms/kg for term neonates weighing >2 kg and  to  micrograms/kg for infants and children between  month and  years of age. The total digitalizing dose is administered over  to  hours as follows: half the total dose is given as an initial IV bolus; one fourth of the total dose is given  to  hours after the initial dose; and the remaining one fourth is given  to  hours later. Digoxin is less helpful in the acute setting as it takes time to reach therapeutic levels. If digoxin is given, check and recheck doses before administration to avoid dosing errors.
INTERVENTIONAL AND SURGICAL REPAIR OF CONGENITAL HEART DEFECTS
In many infants, heart defects can be definitively corrected through surgical repair or the use of devices delivered through catheterization. This section provides a brief review of commonly used techniques for the correction of congenital heart defects. Table 129­6 lists some of the congenital heart
 defects, their respective surgical procedures used in treatment or palliation, as well as potential postsurgical complications.
Table 129­6
Common Surgical Procedures and Their Complications in Complex Congenital Heart Disease
Type of Surgical Repair Postsurgical Complications Comments
CHD Procedure
(Timing)
TGA Arterial switch Switch of the aortic and Myocardial ischemia N/A
(at birth) pulmonary trunks, leaving original valve; coronary arteries reimplanted
Rastelli (at birth) RV to PA conduit and Supravalvular stenosis, atrial dysrhythmias Typically performed in patients
VSD closed with slight with LVOT obstruction
LV protrusion into RV
Mustard/Senning Atrial switch with Atrial dysrhythmias, ventricular failure Rarely used; RV becomes systemic
(at birth) prosthetic (Mustard) or ventricle, LV becomes pulmonary native (Senning) intra­ ventricle atrial baffle
HLHS or Staged repair: Norwood: Neo­aorta Atrial arrhythmias, sudden death, thromboembolism Single­ventricle physiology with tricuspid . Norwood created from aorta and (pulmonary > arterial), thrombosis of shunt, elevated mixing of blood through ASD and atresia (HLHS only) part of PA with ligation CVP (SVC syndrome, ascites, hepatomegaly), POX 75%–85% expected
+ of main PA pericardial or pleural effusion, protein­losing
BTS BTS: right subclavian enteropathy
Or artery to right PA
Sano conduit modification (at Sano: RV to PA conduit birth)
. Glenn (age  BTS or Sano taken POX 75%–85% expected mo) down, SVC anastomosed to right
PA or main PA
(bidirectional Glenn)
. Fontan (age IVC connected to PA At this stage, passive blood flow
### .5 y) to lungs, single ventricle pumps to body, mixing no longer, POX normal
CoA, AS Balloon dilation Can include end­to­end Restenosis at original site or surgical anastomosis N/A or surgical repair anastomosis, patch
(timing variable) repair, balloon dilation, or aortoplasty
Truncus Primary repair Pulmonary arteries Valvular insufficiency, dysrhythmias (RBBB and heart Pulmonary edema and arteriosus (around age  removed from common block), outgrown conduit hypertension from valvular wk) trunk and attached via insufficiency, hypoxia if conduit is conduit to RV and outgrown due to decreased closure of VSD pulmonary blood flow
TOF Complete repair Augmentation of PA and Residual VSD, RV failure, conduction defects, valvular N/A
+/– BTS (around valve, closure of VSD insufficiency age  mo) +/–
Right subclavian to right
PA conduit (BTS)
Abbreviations: AS = aortic stenosis; ASD = atrial septal defect; BTS = Blalock­Taussig shunt; CHD = congenital heart disease; CoA = coarctation of the aorta; CVP = central venous pressure; HLHS = hypoplastic left heart syndrome; IVC = inferior vena cava; LV = left ventricle; LVOT = left ventricular outflow tract; N/A = not applicable; PA = pulmonary artery; POX = pulse oximetry; RBBB = right bundle branch block; RV = right ventricle; SVC = superior vena cava; TGA = transposition of the great arteries; TOF = tetralogy of Fallot; VSD = ventricular septal defect.
Used with permission of EB Medicine, from: Pavan Judge, Garth Meckler. Congenital heart disease in pediatric patients: recognizing the undiagnosed and managing complications in the emergency department. Pediatric Emergency Medicine Practice. 2016;13(5):1­28. © 2016 EB Medicine. www.ebmedicine.net.
COMPLICATIONS OF CONGENITAL HEART DEFECTS
This section discusses complications of medical management, common complications related to surgery for repair of congenital heart defects, and infectious complications in children with congenital heart defects. Diagnosis and management typically require pediatric cardiology consultation and transfer to a tertiary care center.
DYSRHYTHMIAS
Dysrhythmias may be caused by the underlying lesion, the surgical repair, or digitalis toxicity. Supraventricular tachycardia is common with procedures that employ atriotomy (Senning operation, Mustard operation, Fontan procedure, atrial septal defect repair, total anomalous pulmonary venous return repair). In a stable patient without evidence of end­organ dysfunction, manage supraventricular tachycardia initially with vagal maneuvers or with a rapid push of IV adenosine (0.1 milligram/kg/dose, maximum  milligrams). If the patient is unstable and is showing signs of end­organ dysfunction (altered mental status, hypoxia, poor perfusion, or respiratory distress), treat promptly with synchronized cardioversion (0.5 to  J/kg; can increase to  J/kg). Bradycardia may occur in patients who have undergone the Fontan procedure, and atrioventricular block is not uncommon after atrioventricular canal repair.
Some lesions recur after surgery. This is most commonly seen with coarctation of the aorta, which recurs in 10% of cases. Pulmonary stenosis and aortic stenosis balloon dilation may also be complicated by restenosis or valvular incompetence.
SURGICAL SHUNT DYSFUNCTION
When palliative shunt procedures are performed in the neonatal period prior to definitive operative repair of complex congenital heart disease, shunts can malfunction. Typically, infants with surgical shunt failure develop acute distress with increasing cyanosis when the shunt flow narrows to <50% of usual. Ordinarily, a continuous murmur should be heard over the shunt. Diminution or disappearance of the murmur suggests occlusion of the shunt.
Typically, emergency physicians can do nothing for these infants. Palliative therapy with 100% oxygen is used, and transfer to a tertiary center is expedited. The use of thrombolytic therapy has been attempted, but thrombolytic agents should be administered by a pediatric cardiologist either directly into the shunt or systemically. In all cases, definitive treatment consists of surgical repair.
PULMONARY HYPERTENSIVE CRISIS
Many children with congenital heart disease have increased pulmonary artery pressure, particularly those with large ventricular septal defects.
Pulmonary vasospasm can develop in response to painful procedures. In such conditions, cyanosis and lethargy can develop and can mimic the hypercyanotic episodes of tetralogy of Fallot. The goal is to reduce right ventricular afterload by providing adequate ventilation, administering supplemental oxygen to facilitate pulmonary vasodilation, correcting acidosis with IV sodium bicarbonate,  mEq/kg, and keeping patients calm with anxiolytics and analgesics. Temporizing measures such as nitrous oxide, calcium channel blockers, prostacyclin infusions, and oral pulmonary vasodilators such as bosentan and sildenafil may also be considered in consultation with a pediatric cardiologist.
DIURETIC COMPLICATIONS
Because dosing of diuretic medications is weight based, normal infant growth may lead to inadequate diuretic therapy that presents as congestive heart failure. Conversely, during times of excess fluid losses, such as from diarrhea or vomiting, dehydration can occur with hemoconcentration that can compromise cardiac function or shunt integrity. Electrolyte imbalances are a common side effect of many diuretics and can be exacerbated during intercurrent illness, so potassium levels should always be checked.
DIGOXIN TOXICITY
Because of digoxin’s narrow therapeutic window, digoxin toxicity can easily develop. In infants, toxicity often presents with bradycardia or other dysrhythmias. The usual adult patterns of atrial and ventricular tachycardia are not seen in younger children, although they may occur in adolescents.
It is always good practice to monitor digoxin concentrations expectantly during any visit at which blood is drawn. Usually, increased serum concentrations can be managed by withholding dosages of digoxin. Rarely, pharmacologic intervention is required for bradycardia. Ventricular dysrhythmias are managed medically with lidocaine or phenytoin. For severely intoxicated children, the use of digoxin immune globulin (Digibind®) is indicated and reverses toxicity rapidly. Usually, the dosage can be calculated readily based on the amount of digoxin elevation in nanograms above the normal level (see Chapter 193, “Digitalis Glycosides”).
ANTICOAGULATION PROBLEMS
Some children with congenital heart disease require lifelong anticoagulant therapy to prevent shunt occlusion or thrombosis of surgically implanted valves or grafts. The risk of serious bleeding is small but must be considered in any elective repair of fractures or lacerations. Prothrombin time and the INR should be monitored. Reversal of anticoagulation with vitamin K or fresh frozen plasma should be undertaken only after consultation with a pediatric cardiologist.
ANEMIA AND POLYCYTHEMIA
Children with cyanotic congenital heart defects develop an increase in hemoglobin concentration to compensate for hypoxemia. When hemoglobin concentrations fall to normal, these infants can become symptomatic, with tachycardia, feeding difficulty, or congestive heart failure. Conversely, polycythemia causes increased blood viscosity and the potential for stroke. Iron supplementation is important to prevent anemia. When polycythemia occurs, therapeutic phlebotomy may be warranted.
VIRAL INFECTIONS IN CONGENITAL HEART DISEASE
Children with congenital heart disease are at high risk for serious complications from infection with viruses such as influenza virus, parainfluenza virus, or respiratory syncytial virus, and mortality and morbidity are dramatically higher than in normal infants. Children with lesions that increase pulmonary blood flow are at greater risk because of pooling of alveolar secretions. Pooled secretions allow for stasis and secondary bacterial overgrowth. Treat acute influenza according to standard current guidelines. Prophylactic treatment after exposure to influenza virus is recommended only if the patient is not vaccinated against the influenza virus strains circulating at the time of exposure. Annual influenza immunization is recommended for all infants with congenital heart defects. Antiviral therapy for respiratory syncytial virus infection is controversial, but prevention with virus­specific immune globulin is recommended for most infants with congenital heart defects. No effective therapy is available for parainfluenza virus infection.
SERIOUS BACTERIAL ILLNESS AND SUBACUTE BACTERIAL ENDOCARDITIS
Although occult bacteremia has the same probability of occurrence in a child with congenital heart disease as in a child without congenital heart defects (see Chapter 119, “Fever and Serious Bacterial Illness in Infants and Children”), bacterial endocarditis is always a concern in a child with congenital heart defects and fever. Uncorrected congenital heart defects carry a .1% to .2% annual risk of endocarditis, which falls to .02% after correction of most lesions. The highest risk is seen for uncorrected complex lesions and may be as high as .5% per year in these cases, whereas atrial septal defect, ventricular septal defect, patent ductus arteriosus, coarctation, and pulmonary stenosis carry low risk. Transient iatrogenic bacteremia produced by procedures such as dental work or respiratory manipulation can lead to localized colonization and infection. Although the focus of most primary care providers is toward prevention of this disease, cases still occur. The usual presentation is unexplained fever in children with known congenital heart disease. Appropriate evaluation includes multiple blood cultures, urine culture and analysis, and CBC. Parenteral or oral antibiotics should be administered in consultation with a pediatric cardiologist familiar with the child’s history. Prophylactic antibiotics prior to invasive procedures or dental work and the management of bacterial endocarditis are further discussed in the later section, “Endocarditis,” under “Acquired
Heart Disease.”
ACQUIRED HEART DISEASE
MYOCARDITIS
Myocarditis is an inflammatory disorder of the myocardium, affecting children of all ages, and is the leading cause of dilated cardiomyopathy requiring transplantation. This inflammatory disease of the heart frequently results from common viral infections as well as postviral immune­mediated responses. Viral causes include parvovirus B19, human herpesvirus , and adenovirus and enteroviruses (e.g., coxsackie viruses). Additional causes
 are influenza (subtypes A and H1N1), human immunodeficiency virus–associated myocarditis, and chronic Epstein­Barr myocarditis. Many bacterial species have been associated with myopericarditis but rarely myocarditis alone. In some regions of the world rickettsial (e.g., typhus), mycotic (e.g., histoplasmosis), protozoal (e.g., amebiasis, trypanosomiasis), and helminthic (e.g., schistosomiasis) infections have been associated with myocarditis.
Noninfectious causes include conditions such as Kawasaki’s disease (see later section, “Kawasaki’s Disease”), juvenile idiopathic arthritis, and lupus erythematosus.
Clinical Features
Myocarditis is often preceded by a viral respiratory illness. Presenting signs and symptoms include tachypnea, respiratory distress, fever, tachycardia, generalized malaise, and myalgias. Isolated or concurrent GI symptoms such as vomiting, anorexia, and abdominal pain may be present. Arrhythmias may complicate myocarditis and give rise to symptoms of palpitation or syncope in older children. Chest pain may be a symptom of concurrent
 pericarditis.
The physical examination reveals signs of decreased cardiac output and compensatory response: tachycardia, weak pulses, cool extremities with delayed capillary refill, skin mottling, or cyanotic skin. Auscultation of the heart may reveal distant heart sounds, an S or S gallop, and a regurgitant
  murmur. There may be signs of congestive heart failure or fulminant shock.
Diagnosis
No single diagnostic test is sensitive or specific for myocarditis. Diagnostic evaluation may include CBC, serum chemistries, liver function tests, and blood cultures to identify bacterial infection. Inflammatory markers, such as erythrocyte sedimentation rate and C­reactive protein, are nonspecific but may be elevated. Respiratory viral cultures or viral titers may help to identify a specific infectious cause. Natriuretic peptide elevation may help distinguish respiratory symptoms caused by heart failure rather than pulmonary etiologies, and elevated levels may be associated with more fulminant
,36 cases. Troponin T or I may be elevated.
ECG changes are nonspecific, with sinus tachycardia, low QRS voltages (<5 mm in limb leads), flattened or inverted T waves with ST­ and T­wave changes, and prolongation of the QT interval. A prolonged QRS duration of >120 milliseconds is associated with poor clinical outcome. Left ventricular hypertrophy or strain can be seen. Arrhythmias include premature ventricular contractions, atrial tachycardias, junctional tachycardia, or, occasionally, heart block or ventricular tachycardia.
Chest radiograph may reveal cardiomegaly and pulmonary edema. Echocardiography is useful to define cardiac function as well as to rule out other causes of heart failure such as valvular disease, hypertrophic cardiomyopathy, or restrictive cardiomyopathy. Emerging modalities such as
 cardiovascular magnetic resonance are being studied. Endomyocardial biopsy is the diagnostic gold standard.
Treatment
The treatment of myocarditis depends on the cause, with the initial goal of managing heart failure and arrhythmias. Therapeutic agents consist of afterload reduction, preload reduction in the case of true volume overload, or inotropic support. Diuretics will worsen the condition if cardiac output is dependent on preload. Children with heart failure should be admitted to a pediatric tertiary care facility where care can be guided by a pediatric cardiologist. Since much of the myocyte damage in myocarditis is caused by the host’s immune response, treatments targeting the host’s immune system have been studied, namely IV immunoglobulin. However, a systematic review of pediatric and adult literature determined that there is insufficient evidence to support the use of IV immunoglobulin in the treatment of acute myocarditis except in children with concurrent viral
 encephalitis. Fulminant myocarditis may require extracorporeal life support.
PERICARDITIS
Pericarditis is inflammation of the pericardium and has many causes. Infectious causes are common and can be bacterial, viral, fungal, parasitic, or tubercular. Viral etiologies predominate in the infant. Pericarditis is often associated with myocarditis, with myocarditis being the predominant entity.
Staphylococcus aureus, Streptococcus pneumoniae, Haemophilus influenzae, Neisseria meningitidis, and streptococci species are causes of bacterial pericarditis. Noninfectious inflammatory causes include rheumatologic disease, metabolic or endocrine disease (e.g., uremia, thyroid disorders), and

Kawasaki’s disease. Rarely, pericarditis may be caused by malignant disease, including leukemia, lymphoma, and cardiac rhabdosarcoma.
Clinical Features
Pericarditis often follows or accompanies upper respiratory infection. Chest pain may be a symptom of pericardial inflammation and is classically positional, with worsening in the supine position and improvement leaning forward. Pain can worsen with respirations and may be referred to the upper abdomen.
Vital signs may reflect tachycardia, tachypnea, and hypotension with a narrow pulse pressure. Pulsus paradoxus is the sine qua non of pericardial effusion with cardiac tamponade and is defined by a > 10­mm Hg fall in systolic blood pressure with inspiration. Auscultation of the heart may reveal a friction rub (best heard at the left lower sternal border with the patient sitting forward) and muffled or distant heart sounds (when associated with a large effusion). Peripheral pulses may be decreased, with cool extremities, mottled skin, and sluggish capillary refill.
Diagnosis
Routine blood tests are not typically helpful for diagnosis, but specific testing may identify the cause: a positive purified protein derivative or Mantoux screening test suggests tuberculosis, circulating blasts indicate hematologic malignancy, and positive blood cultures may occasionally be seen in
 bacterial pericarditis. Troponin elevations may be seen in both pericarditis and myocarditis.
ECG abnormalities are almost universal and have been described as progressing through stages (although multiple stages may be present simultaneously): concave ST­segment elevation in leads I, II, III, aVL, aVF, and V to V with ST depression in aVR; ST­segment normalization with T­wave
  flattening; diffuse T­wave inversion; and normalization. Other ECG findings in pericarditis include PR depression, decreased precordial voltage, and
 electrical alternans.
The chest radiograph may demonstrate cardiomegaly with a water bottle–shaped heart or a pleural effusion. Echocardiography is best to detect pericardial effusion or tamponade associated with pericarditis but may be normal if there is minimal fluid accumulation or the fluid is loculated. If a tamponade is present, there will be collapse of the right atrial wall or right ventricular wall during diastole.
Treatment
Treatment depends on the underlying cause. Tamponade requires emergency pericardiocentesis (see Chapter , “Cardiomyopathies and Pericardial
Disease,” and Chapter , “Pericardiocentesis”). Empiric antibiotic therapy for bacterial pericarditis includes oxacillin,  milligrams/kg, or vancomycin,  milligrams/kg, for methicillin­sensitive S. aureus and methicillin­resistant S. aureus, with the addition of gentamicin in immunocompromised patients. The treatment of pericarditis without effusion or tamponade includes outpatient treatment with NSAIDs such as naproxen,  to  milligrams/kg/dose every  hours, or ibuprofen,  milligrams/kg/dose every  hours. The addition of colchicine to prevent recurrent disease is recommended for adults, but evidence in children is limited. Patients should be followed for complications such as myocarditis, pericardial effusion, or cardiac tamponade.
KAWASAKI’S DISEASE
Kawasaki’s disease (mucocutaneous lymph node syndrome) is a generalized systemic vasculitis of unknown cause. Along with Henoch­Schönlein purpura (see also Chapters 133, “Acute Abdominal Pain in Infants and Children”; Chapter 137, “Renal Emergencies in Children”; and Chapter 142,
“Rashes in Infants and Children”), Kawasaki’s disease is one of the principal pediatric systemic vascular diseases and is the leading cause of acquired heart disease in North American and Japanese children. It affects infants and children <5 years old most commonly and can occur in endemic and community­wide epidemic forms. There is seasonal variation, with more cases in the late fall through early spring, both in
North America and in northeast Asia. Male­to­female ratio is about .5:1. There is a risk of recurrence (about 3%) and a 10­fold increased risk in siblings
 of those with Kawasaki’s disease in Japan.
CLINICAL FEATURES
The diagnosis is clinical. Criteria for the diagnosis are outlined in Table 129­7, and these criteria can be applied after excluding diseases of similar findings such as viral illnesses (measles, adenovirus, enterovirus), bacterial illnesses (cervical adenitis, scarlet fever, staphylococcal scalded skin syndrome), or immune­mediated syndromes (serum sickness, Stevens­Johnson syndrome, toxic shock syndrome).
Table 129­7
Diagnostic Criteria for Kawasaki’s Disease
Classic or Complete Kawasaki’s Disease Incomplete Kawasaki’s Atypical Kawasaki’s Disease
Disease
Fever for ≥5 d and  of the following clinical criteria: Fever for  d and 2–3 clinical Meets all clinical criteria for complete Kawasaki’s disease criteria of classic Kawasaki’s disease
Bilateral bulbar conjunctival injection without PLUS PLUS exudate CRP ≥3.0 milligrams/L, and/or Additional clinical features not typical of Kawasaki’s disease
Erythema and cracking of lips, strawberry tongue, ESR ≥40 mm/h (e.g., child with Kawasaki’s disease and nephrotic syndrome) and/or erythema of the oral and pharyngeal mucosa
Rash: maculopapular, diffuse erythroderma, or erythema multiforme–like
Erythema and edema of the hands and feet (acute phase) or periungual desquamation (subacute phase)
Cervical lymphadenopathy (>1.5 cm in size, usually unilateral, anterior cervical, nonfluctuant)
PLUS
A positive echocardiogram, or
≥3 supplemental labs:
Albumin ≤3 grams/dL
Anemia for age
Elevated alanine aminotransferase
Platelet count
≥450,000/mm3 after  d of fever onset
WBC count ≥15,000/mm3
Presence of pyuria (>10
WBC cells per high­power field)
Note: Infants <6 months of age with  days of fever without source, even if no clinical criteria met, should undergo laboratory testing and, if indicated, echocardiogram.
Abbreviations: CRP = C­reactive protein; ESR = erythrocyte sedimentation rate.
Cardiac complications are the most severe manifestations of Kawasaki’s disease and include coronary artery aneurysms, myocarditis, pericarditis, pericardial effusion, valvular dysfunction, left ventricular dysfunction, and arrhythmias. Coronary artery
 aneurysms or ectasia occurs in 15% to 25% of untreated children and can lead to myocardial infarction, sudden death, or ischemic heart disease. Left ventricular dysfunction is seen in almost half of patients.
Noncardiac findings of Kawasaki’s disease include arthritis or arthralgia, vomiting and abdominal pain, hydrops of gallbladder, extreme irritability due to systemic inflammation, aseptic meningitis, urethritis, and desquamating rash in the groin (as compared to desquamation of fingers and toes in weeks  and  of illness).
Kawasaki’s disease is divided into three phases: the acute febrile phase typically lasts for the first  weeks of illness; the subacute phase lasts from  to
 weeks; and the convalescent phase lasts from  to  weeks. Laboratory results are nonspecific in the acute phase, but for those children who do not fulfill diagnostic clinical criteria, the supplemental lab abnormalities (Table 129­7) lend support to the diagnosis. Additionally, there may be elevated plasma lipid and elevated serum γ­glutamyl transpeptidase. Thrombocytosis is not usually noted until the second week of illness.
Cardiac complications vary depending on the stage of disease and are presented in Table 129­8. Patients <1 year old and those >9 years old tend to
,40 present with incomplete Kawasaki’s disease, leading to delayed diagnosis and higher risk of coronary artery abnormalities. Other risk factors for
 cardiac complication include higher platelet count, higher C­reactive protein, and lower albumen. Due to the importance of identifying patients at risk of developing coronary artery abnormalities, cardiovascular biomarkers will become important for diagnosis in the future. One biomarker, N­ terminal pro­B­type natriuretic peptide, is increased in patients with Kawasaki’s disease and incomplete Kawasaki’s disease compared with febrile
,43 controls.
Table 129­8
Cardiac Complications of Kawasaki’s Disease
Phase of Illness Cardiac Complications
Acute (0–2 wk) Myocarditis, pericarditis, coronary arteritis, arrhythmias
Subacute (2–4 wk) Coronary artery abnormalities
Convalescent (4–6 wk) Coronary artery abnormalities
The acute phase of disease results in myocarditis and pericarditis, which typically resolve without treatment. The most common cardiac findings include tachycardia out of proportion to fever and a gallop rhythm. Inflammation of aortic and mitral valves can lead to murmurs of valvular incompetence, usually during the acute phase of disease. Pericardial effusions are rarely large or life threatening. Reduced left ventricular function and arrhythmias are more common in the acute phase of illness than in later phases.
Although coronary arteritis begins during the acute phase and aneurysms can be seen as early as  days after the fever starts, most coronary artery aneurysms develop during the third and fourth weeks of illness. Aneurysms of arteries other than the coronaries (subclavian, brachial, iliac, femoral) can also develop but are rare. Myocardial infarction is a complication of coronary artery aneurysm and is the leading cause of death in
Kawasaki’s disease. The majority of infarcts occurs in the first  months of the disease but may present later.
Echocardiography should be performed during the acute stage of disease and repeated in the subacute and convalescent stages and beyond. Findings include pericardial effusion, poor left ventricular function, aortic or mitral valve regurgitation, perivascular brightness of the coronary arteries (acute phase), and coronary artery aneurysms.
TREATMENT
Treatment is directed at reducing inflammation and preventing cardiac complications. Administration of IV immunoglobulin (2 grams/kg over
 hours) results in rapid and dramatic symptomatic improvement in 90% of patients and prevents aneurysm formation in 95%. In addition to IV immunoglobulin, treat with aspirin (30 to  milligrams/kg/d). Although previous guidelines suggested high­dose aspirin therapy during
 the acute phase, meta­analyses suggest high­dose therapy (80 to 120 milligrams/kg/d) confers no additional benefit over anti­inflammatory doses.
Following the acute phase, the aspirin dose is reduced to  to  milligrams/kg once daily for  to  weeks. A second dose of IV immunoglobulin may be given (same dosage) if the patient remains febrile  hours after the initial dose, because refractory fever may be a risk factor for coronary artery abnormalities. As many as 12% to 38% of patients require a second dose of IV immunoglobulin, and despite retreatment with IV immunoglobulin, 3% to 4% of patients may still not respond. A single dose of corticosteroids administered before IV immunoglobulin does not improve coronary outcome.
However, for patients with persistent treatment resistance, rescue dosing of corticosteroids is being studied. The use of infliximab, cyclosporine A, methotrexate, and cyclophosphamide remains to be elucidated in future prospective trials.
MULTISYSTEM INFLAMMATORY SYNDROME IN CHILDREN (MIS­C; ALSO CALLED PIMS, PIMS­
TS, OR MISC)
On April , 2020, the National Health Service (NHS) in the UK reported a newly recognized multisystem inflammatory syndrome affecting children, and
 published the first case definition for “Pediatric Multisystem Inflammatory Syndrome temporally associated with COVID­19” (PIMS­TS). Since that
45–51 time, case series have been published from a number of countries including Italy, France, the UK, and the US. The World Health Organization
(WHO) and US Centers for Disease Control (CDC) have published their own definitions and renamed the condition Multisystem Inflammatory
Syndrome in Children (MIS­C). Many of the clinical features of MIS­C overlap with other inflammatory syndromes in children, including Kawasaki
Disease (KD), Macrophage Activation Syndrome (MAS), and Toxic Shock Syndrome (TSS). Table 129­9 below compares the diagnostic criteria for KD with the WHO and CDC definitions of MIS­C.
Table 129­9
Diagnostic Criteria for Kawasaki Disease vs Multisystem Inflammatory Syndrome in Children
Kawasaki Disease (KD) MIS­C (WHO) MIS­C (CDC)
Clinical Fever ≥5 days AND  or more All  Criteria: All  Criteria:
Features features: . Age 0­19 . Age <21 years
. Bilateral bulbar conjunctival . Fever ≥3 days . All of the following features: injection . At least two inflammatory symptoms: Fever ≥24 hours (documented >38.0
. Oral mucus membrane changes Rash, conjunctivitis, mucocutaneous C or subjective)
. Peripheral extremity changes inflammation Laboratory evidence of
. Polymorphous rash Hypotension or shock inflammation (see below)
. Cervical lymphadenopathy Cardiac dysfunction, pericarditis, Severe illness requiring valvulitis, coronary abnormalities hospitalization
Coagulopathy Multisystem involvement (at least
Acute GI symptoms (abdominal pain, 2): vomiting, diarrhea) Cardiovascular
. Elevated inflammatory markers (see below) Respiratory
. No other microbial causes including sepsis Renal or toxic shock syndrome Neurologic
. Evidence of SARS­CoV­2 infection (any): Hematologic
Positive RT­PCR Gastrointestinal
Positive serology Dermatologic
Positive antigen test . No alternative plausible diagnosis
Contact with an individual with COVID­ . Recent or current SARS­CoV­2 Infection or
 exposure
Positive RT­PCR
Positive serology
Positive antigen test
COVID­19 exposure within  weeks prior to onset of symptoms
Laboratory 2­3 Criteria above PLUS  or Laboratory Evidence Supportive of Clinical Laboratory Evidence Supportive of Clinical
Features more lab abnormalities: Criteria Above: Criteria Above:
Albumin ≤  gram/dL Inflammation (any): Inflammation (any):
Anemia for age Elevated CRP Elevated CRP
Elevated ALT Elevated ESR Elevated ESR
Platelet count ≥450,000 Elevated procalcitonin Elevated Fibrinogen after  days fever onset Organ dysfunction: Elevated procalcitonin
WBC count ≥ ,000/mm3 Elevated troponin or BNP Elevated D­dimer
Pyuria (>10 WBC per high Prolonged PT or PTT or elevated D­ Elevated ferritin power field) dimer Elevated LDH
Elevated IL­6
Neutrophilia
Lymphocytopenia
Hypoalbuminemia
Organ dysfunction: elevated troponin or BNP coagulopathy
Abbreviations: RT­PCR = reverse transcription­polymerase chain reaction; ALT = alanine aminotransferase; CRP = C­reactive protein; ESR = erythrocyte sedimentation rate; BNP = brain natriuretic peptide; PT = prothrombin time; PTT = partial thromboplastin time; LDH = lactic acid dehydrogenase; IL­6 = interleukin­6
The clinical features of KD and MIS­C overlap as noted in Table 129­9 above, and some children may meet criteria for both conditions (e.g., complete
KD + evidence of COVID infection). However, there appear to be some differences in the early epidemiology of the cases of reported MIS­C. MIS­C has primarily been described among older children and adolescents (mean age 9­11 years), and black and Hispanic children have been over­
,48,49,51 represented; by contrast KD usually affects infants and younger children with higher incidence among Asian populations.
While the WHO and CDC case definitions require confirmation of current or past COVID infection or exposure to COVID­19, the relationship between viral infection and MIS­C is not yet clear. Data from the UK, Italy, and US suggest a gap of several weeks between peak COVID infections in the community and peak MIS­C cases. Moreover, only about 1/3 of described cases had evidence of acute infection (positive PCR), while 2/3 had positive
,45,48,49 serology and almost 10% had negative testing but known exposure to COVID.
Clinically, the presenting symptoms of MIS­C include, in decreasing order: fever, GI symptoms (pain that may mimic acute appendicitis, vomiting, diarrhea), rash, conjunctivitis, mucous membrane involvement, neurologic symptoms (lethargy, confusion, headache), and respiratory symptoms.
Respiratory symptoms, though reported, were rare, and typically related to signs of shock and poor perfusion rather than primary pulmonary disease.
Cardiovascular dysfunction is among the most serious of the clinical manifestations of MIS­C. Shock was present in 50­80% of the first reported cases, and evidence of myocardial dysfunction on echocardiogram or laboratory investigation (elevated troponin or BNP) was noted in 50­100% of those cases. The echocardiographic abnormalities described range from poor LV function (50­60%), to abnormalities of the coronary arteries (20­50% with dilation or aneurysm) and mitral valve regurgitation. When present, shock may be fluid­refractory and require inotropic support with epinephrine or norepinephrine. As the total described cases increase and milder disease is captured, the proportion of children with MIS­C experiencing significant
 cardiac abnormalities has decreased to 10­20%.
The treatment of MIS­C has yet to be clearly defined, however, cases with features that fulfill the definition for complete or incomplete KD should be treated for KD with IVIG and aspirin. Because the symptoms of MIS­C presenting with shock overlap with those of sepsis and toxic shock syndrome, broad spectrum parenteral antibiotics should be considered until bacterial infection has been ruled out.
ENDOCARDITIS
Historically, infective endocarditis was most commonly seen in children affected with rheumatic heart disease; however, more recently, it has been more closely associated with congenital heart disease, both corrected and unrepaired: only 10% of pediatric patients with endocarditis have normal
 cardiac anatomy. Table 129­10 lists risk factors for pediatric endocarditis. The annual incidence of infective endocarditis is low, ranging from .05
 to .12 cases per 1000 pediatric admissions. Although mortality has declined, it remains high at 10% to 15%. Significant complications, such as septic emboli, valvular dysfunction, and congestive heart failure, can occur.
Table 129­10
Risk Factors for Infective Endocarditis
Clinical Conditions Comments
Congenital heart disease Unrepaired cyanotic congenital heart disease (including palliative shunts and conduits)
Completely repaired defects with prosthetic material or devices within  months of procedure* Repaired with residual defects at the site or adjacent to a prosthetic patch or device
Prosthetic cardiac valve or material used for valve repair
Cardiac transplantation Especially with subsequent valvulopathy
Previous infective endocarditis
Central venous catheters Higher risk for Staphylococcus aureus
Rheumatic heart disease Uncommon in developed countries
*Applies to devices placed surgically or by catheter intervention.
Infectious endocarditis occurs when damaged endocardium is exposed to circulating bacteria, and both conditions are necessary for vegetations to develop. Congenital heart defects predispose to infection through turbulent blood flow that creates endothelial damage and promotes thrombus formation. The risk for endocarditis is enhanced by the presence of prosthetic heart valves or graft material within the repaired or palliated heart.
Although a number of bacteria can cause endocarditis, staphylococcal, streptococcal, and enterococcal species predominate. S. aureus is seen more commonly in children without heart disease and viridans streptococci are more common in those with underlying heart disease. Gram­negative organisms (e.g., Klebsiella pneumoniae and Enterobacter species), although rare, can cause endocarditis in neonates. HACEK organisms are slowgrowing gram­negative bacteria that are part of normal human flora. The term HACEK is derived from the first letter of the bacteria in the group (Haemophilus, Actinobacillus, Cardiobacterium, Eikenella, and Kingella). Fungal infections, particularly Candida species, are rare causes of endocarditis more often seen in neonates and children with indwelling catheters.
CLINICAL FEATURES
Infective endocarditis can present as an acute or subacute process. Acute endocarditis can be a fulminant disease with high spiking fevers, clinical sepsis, and rapid hemodynamic deterioration. The symptoms of subacute endocarditis are often vague and difficult to distinguish from common childhood illness. Unexplained or persistent fever is the most common complaint; other symptoms include fatigue, weakness, arthralgias, myalgias, weight loss, rigors, and diaphoresis in older children, and symptoms may be subtler in infants. In the patient with cyanotic heart disease, pneumonia, new neurologic deficits, hematuria, or skin rashes prompt consideration of infective endocarditis.
Fever, tachycardia, and a new murmur may be noted on clinical exam. CNS embolization can cause focal neurologic deficits. Rales or decreased breath sounds accompany septic pulmonary emboli. Examine the skin for evidence of cutaneous emboli that appear as splinter hemorrhages of the nail beds, painless erythematous macules on the palms or soles (Janeway lesions), and tender subcutaneous nodules on the fingers (Osler nodes). Although these skin findings are typical for infectious endocarditis, they can be seen in other conditions such as lupus or typhoid fever. Retinal emboli are difficult to visualize in young children. Splenomegaly may be appreciated.
DIAGNOSIS
The diagnosis is made through a combination of clinical features, laboratory investigations, and echocardiography. Obtain multiple (three separate samples in the first  hours, repeated  hours later if initial cultures are negative), large­volume (1 to  mL in infants,  to  mL for toddlers and
 preschool­aged children, and  mL for school­aged children and adolescents) blood cultures if endocarditis is suspected. The CBC may reveal anemia of chronic disease, but leukocytosis may be absent. Nonspecific inflammatory markers, such as erythrocyte sedimentation rate and C­reactive protein, are usually elevated. The mean erythrocyte sedimentation rate in endocarditis is  mm/h. Subacute or chronic endocarditis may produce a positive rheumatoid factor. Urinalysis demonstrates proteinuria and microscopic hematuria in roughly half of patients.
An echocardiogram is not 100% sensitive or specific, and a negative echocardiogram does not rule out endocarditis. Transthoracic echocardiography is more sensitive in infants and children than adults and may reveal vegetations, abscess, or valvular regurgitation. Transesophageal echocardiography is recommended for infants and children with previous chest wall surgery or trauma, those with congenital anomalies of the
 thoracic cage, and those at high risk for aortic root abscess. Histologic confirmation of disease from a vegetation or abscess is sometimes required for definitive diagnosis.
The modified Duke criteria for endocarditis use a combination of diagnostic and echocardiographic findings (Table 129­11). Definite endocarditis is diagnosed by pathologic criteria (microorganisms on culture or histologic examination of a vegetation or cardiac abscess or histologic exam showing active endocarditis) or clinical criteria, which require two major criteria, or one major and three minor criteria, or five minor criteria. The diagnosis of
 possible endocarditis is made by the presence of one major and one minor criterion or three minor criteria.
Table 129­11
Modified Duke Criteria for Infective Endocarditis
Major Criteria Minor Criteria
. Positive blood cultures:2 positive blood cultures for a typical microorganism for endocarditisorPersistently . Fever ≥38°C (100.4°F) positive blood culture—2 or more positive blood cultures for the same organism over  h or  or more . Predisposing heart condition or positive blood cultures for the same organism with  h between first and last cultureorSingle culture for injection drug use
Coxiella burnetii . Vascular emboli
. Endocardial involvement demonstrated by echocardiography . Immunologic phenomena such as elevated rheumatoid factor, immune complex glomerulonephritis, Osler nodes
. Positive blood culture but not meeting major criterion or serologic evidence of endocarditis
TREATMENT
The ultimate goal of treatment is complete eradication of the infecting organisms, which often requires a prolonged course of parenteral antibiotics.
The clinical condition at the time of presentation determines the initial ED management. After proper blood and urine cultures are obtained, if the child is septic or toxic, administer vancomycin (15 milligrams/kg IV every  hours up to  grams) plusgentamicin (5 to .5 milligrams/kg IV every  hours) for synergistic bactericidal effect; add rifampin (10 milligrams/kg IV every  hours to a maximum of 600 milligrams) for children with prosthetic valves. Penicillin G (50,000 to 100,000 units/kg IV every  hours) or ceftriaxone (100 milligrams/kg IV daily) can be used for susceptible streptococcal
 infections.
Hospitalization and consultation with a pediatric cardiologist are indicated. Patients with hemodynamic instability may require assessment by a pediatric cardiac surgeon for emergent intervention.
ENDOCARDITIS PROPHYLAXIS

The 2015 American Heart Association guidelines, as well as those from the American Academy of Pediatrics and the Canadian Pediatric Society, recognize that bacteremia from daily activities is a much more common event than bacteremia from specific medical procedures and that only a small number of cases of bacterial endocarditis can be prevented with antibiotic prophylaxis. Indications and recommended antibiotics for prophylaxis are listed in Table 129­12; administer prophylactic antibiotics  to  minutes before the procedure:
Oral: amoxicillin (50 milligrams/kg)
Parenteral: ampicillin (50 milligrams/kg IM or IV)
Penicillin allergic: cephalexin (50 milligrams/kg PO) orclindamycin (20 milligrams/kg PO/IV) orazithromycin (15 milligrams/kg PO) or cefazolin (50 milligrams/kg IM/IV) or ceftriaxone (50 milligrams/kg IM/IV)
Table 129­12
Antibiotic Prophylaxis for Endocarditis52–54
Risk Group Patient Factors Procedures
High risk: Prosthetic cardiac valves Dental: manipulation of gingival tissue, periapical teeth, or perforation of oral mucosa prophylaxis Previous endocarditis Respiratory tract: invasive procedures involving incision or biopsy including indicated Unrepaired cyanotic CHD tonsillectomy/adenoidectomy including shunts/conduits GI/GU: cystoscopy or surgical manipulation plus established infection or colonization with
Repaired CHD with prosthetic enterococcus material or device within  Skin/musculoskeletal: procedures through infected skin months of repair
Cardiac transplant with valvulopathy
Rheumatic heart disease with prosthetic valve or material
Low risk: Atrial septal defects Dental: routine anesthetic injections; radiographs; placement or manipulation of removable prophylaxis Ventricular septal defects prosthodontic or orthodontic appliances; bleeding from trauma to lips or oral mucosa; loss of

## Page 31

prophylaxis Ventricular septal defects prosthodontic or orthodontic appliances; bleeding from trauma to lips or oral mucosa; loss of not indicated Patent ductus arteriosus deciduous teeth
Mitral valve prolapse Respiratory tract: bronchoscopy without incision
Previous Kawasaki’s disease GI/GU: procedures in the absence of infection or colonization
Hypertrophic cardiomyopathy Skin/musculoskeletal: procedures through normal skin
Pacemakers/defibrillators
Bicuspid aortic valves
Coarctation of the aorta
Calcified aortic stenosis
Pulmonary stenosis
Abbreviations: CHD = congenital heart disease.
CARDIOMYOPATHIES
University of Pittsburgh
Cardiomyopathies are uncommon but significant because of the high mortality and severe disability that they produce. They are the most common cause of heart transplantation in children older than  year of age. Cardiomyopathy refers to a heterogeneous group of disorderAsc cienssv oPrlovviidnegd by: abnormalities of the myocardial muscle fibers. They may be inherited or acquired and are usually classified into distinct groups: dilated, hypertrophic, restrictive, and noncompaction. Clinical and therapeutic features differ according to subtypes, the two most common of which are discussed below.

The overall annual incidence of pediatric cardiomyopathy in the United States is .1 to .5 per 100,000. The incidence is highest among infants in the
 first year of life, with a second peak in children  to  years of age, and is higher among boys than girls. Ethnic and regional variation also exists.

Dilated cardiomyopathies comprise 51% of cases, followed by hypertrophic (42%) and restrictive (3%).
DILATED CARDIOMYOPATHY
Dilated cardiomyopathy is characterized by dilation of all four cardiac chambers and may be accompanied by some degree of hypertrophy. Typically, the left side is more involved than the right, and systolic dysfunction predominates. The cause is unknown in most cases, and thus the term idiopathic dilated cardiomyopathy is applied. Known causes include myocarditis from infections (coxsackieviruses, echovirus, Epstein­Barr virus, cytomegalovirus, rickettsia, parasites, and fungus), neuromuscular disease (muscular dystrophies, Friedreich’s ataxia), collagen vascular disease, anemias, nutritional deficiencies, medications (anthracyclines, cyclophosphamide), metabolic disorders (mitochondrial disorders, glycogen storage
 disease, fatty acid oxidation defects, mucopolysaccharidoses), and genetic abnormalities (35% to 50%).
Dilated cardiomyopathy is the most common form of cardiomyopathy in children, with an annual incidence of .57 per 100,000 in children in the United

States, and the average age at diagnosis is  months old. Boys are more often affected than girls. There is a genetic component in roughly 20% to
30% of patients who have affected relatives. Patterns of inheritance are varied, with autosomal dominant being the most common.
The majority of children with dilated cardiomyopathy present with signs and symptoms of congestive heart failure, although some may be asymptomatic or present with insidious and vague complaints. Poor feeding, irritability, sweating, failure to thrive, and malaise are typical nonspecific symptoms, particularly in infants. Cough, wheezing, and orthopnea are easily confused with upper respiratory infection or reactive airway disease.
Older children may complain of chest pain, palpitations, decreased exercise tolerance, or syncope. For asymptomatic children, cardiomegaly or ECG changes may be incidental findings. A careful family history should be obtained given the frequency of inherited disease.
The physical examination may reveal signs of congestive heart failure: tachycardia, tachypnea, rales, or decreased breath sounds. Peripheral pulses may be weak and the skin pale, cool, or mottled with poor capillary refill. Dependent edema and hepatomegaly may be present. The heart examination may reveal a gallop rhythm (S /S ), regurgitant murmurs, and an accentuated P .

The diagnosis is often suggested by cardiomegaly noted on chest radiograph, which may also demonstrate a prominent left ventricular apex and elevation of the left mainstem bronchus by left atrial enlargement. Pulmonary congestion or effusions may be present. Echocardiography is the diagnostic study of choice and can evaluate the degree of chamber dilation and cardiac dysfunction. ECG changes are typically nonspecific. The diagnosis is further refined by cardiac MRI, catheterization, angiography, and biopsy.
The treatment in the ED is supportive. Administer oxygen and generally avoid IV fluids; diuretics, inotropes, and mechanical ventilation may be necessary in advanced cases of congestive heart failure (see discussion of congestive heart failure in earlier section, “Congenital Heart Disease”).
Admission and pediatric cardiology consultation are required.
HYPERTROPHIC CARDIOMYOPATHY
Hypertrophic cardiomyopathy is a term used for a diverse group of myocardial disorders characterized by intrinsic hypertrophy of one or more of the
 cardiac chambers. The incidence is .47 cases per 100,000 children, and it represents just over 40% of pediatric cardiomyopathy. Males are more commonly affected than females, and the median age of diagnosis is  years of age, with peaks in both infancy and adolescence. Hypertrophic cardiomyopathy is more common in adults, and children under the age of  years old account for <10% of cases. First­degree relatives of affected children can be shown to have echocardiographic evidence of disease in 25% of cases.
The left ventricle is most commonly involved, although all chambers can be affected. Systolic function is often preserved, and diastolic dysfunction predominates. Hypertrophic cardiomyopathy is usually genetic in origin, specifically in sarcomere and other cardiac genetic abnormalities, and is inherited as an autosomal dominant trait in many cases. The disorder may also result from inborn errors of metabolism, neuromuscular disorders, malformation syndromes (e.g., Noonan’s syndrome), and glycogen storage disease.
The pathophysiology depends on the underlying genetic defect. Most familial cases result from defects in genes encoding myosin and actin, which result in disorganized myofibrils, fibrosis, and, ultimately, hypertrophy. Coronary artery abnormalities may be associated with thickened intima predisposing to ischemia. Contractile function of the ventricles is normal, but relaxation (diastolic function) is impaired, leading to increased end­
 diastolic pressures. Some forms involve asymmetric hypertrophy of the ventricular septum, which may lead to left ventricular outflow tract
Chapter 129: Congenital and Acquired Pediatric Heart Disease, Esther L. Yue; Garth D. Meckler obstruction. Typically, this obstruction is dynamic and worsened by increased left­sided volume.
. Terms of Use * Privacy Policy * Notice * Accessibility
The symptoms are variable. Infants typically present with vague symptoms associated with heart failure: poor feeding, irritability or lethargy, sweating with feeds, and increased work of breathing. Older children may complain of chest pain, exercise intolerance, dizziness, syncope or near­syncope
(particularly with exercise), or palpitations. Sudden cardiac death may be the first indication of disease, is most common in adolescents, and is often associated with exercise.
The physical examination can be normal or with signs of heart failure. The precordial impulse may be laterally displaced and forceful, and the second heart sound may be paradoxically split. Left ventricular outflow obstruction results in a systolic ejection murmur, which is loudest between the apex and left sternal border and radiates to the suprasternal notch. Maneuvers that increase preload (e.g., Valsalva, squatting) or increase afterload (e.g., hand grip) will decrease the murmur, whereas standing (which decreases preload) will increase the murmur. In advanced disease associated with mitral regurgitation, a holosystolic murmur is heard radiating to the axilla.
Chest radiograph is nonspecific but may demonstrate cardiac hypertrophy with left atrial enlargement. Echocardiography is the study of choice and will reveal a thickened septal wall and ventricular hypertrophy. Systolic anterior motion of the mitral valve is commonly seen with obstructive disease.
Systolic function is typically normal. ECG findings are nonspecific but may include left ventricular hypertrophy, ST­T wave abnormalities, axis deviation, conduction abnormalities, and atrial arrhythmias. Cardiac catheterization and myocardial biopsy are needed for definitive diagnosis.
Treatment is typically directed by a pediatric cardiologist. The primary role of the emergency physician is to make the diagnosis, exclude secondary causes (e.g., metabolic disease), and reduce the risk of sudden cardiac death, which includes exclusion of vigorous exercise until cleared by a cardiologist. Hospitalization is recommended for patients with heart failure, arrhythmias, syncope or near­syncope, or other significant symptoms.
Outpatient management with exercise restriction may be appropriate for asymptomatic patients.
Pharmacologic therapy includes β­blockers and calcium channel blockers, which may decrease outflow obstruction and improve diastolic relaxation.
Propranolol can be initiated at .01 to .1 milligram/kg IV over  minutes or prescribed at .5 milligram/kg PO every  to  hours. Verapamil should be used in children >1 year of age (increased mortality in infants) and can be administered at .1 milligram/kg IV over  minutes and repeated every  to
 minutes as needed. Maintenance dosing is  to  milligrams/kg four times a day.


