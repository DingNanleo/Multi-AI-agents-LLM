## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 249: Generalized Skin Disorders
William J. Brady; Amit Anil Kumar Pandit; Mark R. Sochor
INTRODUCTION
This chapter describes selected serious generalized skin disorders in adults and discusses their dermatologic diagnosis and treatment. Covered are erythema multiforme, toxic epidermal necrolysis, exfoliative erythroderma, the toxic infectious erythemas, disseminated viral infections, Rocky
Mountain spotted fever, disseminated gonococcal infection, purpura fulminans, and pemphigus vulgaris. Staphylococcal scalded skin syndrome and meningococcemia are discussed in the pediatric section, in Chapter 142, “Rashes in Infants and Children.” Disseminated viral infections are discussed in Chapter 154, “Serious Viral Infections” and in Chapter 142. The disorders erythema multiforme, toxic epidermal necrolysis, exfoliative erythroderma, staphylococcal and streptococcal toxic shock syndrome, and staphylococcal scalded skin syndrome share some features in common. Table 249­1 can help to differentiate these disorders. Management is summarized in Table 249­2. TABLE 249­1
Comparison of Inflammatory and Infectious Generalized Skin Disorders
Disorder Appearance Special Features
Erythema Erythematous macules, papules Cutaneous reaction to drugs or infectious agents.
multiforme Target lesions Stevens­Johnson syndrome is the most severe form.
Urticaria or vesiculobullous lesions
Toxic epidermal Painful, tender erythroderma Nikolsky sign present.
necrosis Vesicles and bullae Stevens­Johnson syndrome is most severe form.
Exfoliation Drugs most common cause.
Exfoliative Nontender erythema Often preexisting eczema or psoriasis; can be drug induced.
erythroderma Skin flaking and scaling
Thickening of skin
Staphylococcal or Staphylococcal: fine punctate erythematous lesions that Colonization or infection with Staphylococcus aureus; streptococcal toxic become confluent; blanching erythroderma; desquamation menstruation associated with tampon use; nonmenstrual shock syndrome first of trunk and face, then extremities associated with burns, cellulites, sinusitis, wounds, etc.
Streptococcal: can be indistinguishable from staphylococcal Group A streptococcal cellulitis, puerperal sepsis, any group A β­ toxic shock; scarlatiniform erythroderma with sheet­like hemolytic Streptococcus infection source.
desquamation of skin
Staphylococcal Scarlatiniform rash or erythema Usually seen in neonates or children <5 y of age.
scalded skin Bullae or bullous impetigo Nikolsky sign present.
syndrome Sloughing of skin
TABLE 249­2

Management of Serious Generalized Skin Disorders
Chapter 249: Generalized Skin Disorders, William J. Brady; Amit Anil Kumar Pandit; Mark R. Sochor 
. Terms of Use * Privacy Policy * Notice * Accessibility
Disorder Treatment Disposition/Comments
Erythema multiforme minor Steroid (prednisone 60–80 milligrams PO daily for 3–5 d or Outpatient management equivalent) Primary care physician or
Oral antihistamine (diphenhydramine 25–50 milligrams dermatology follow­up every 4–6 h or equivalent)
Acyclovir for herpes simplex virus–related event (recurrence suppression only)
Remove trigger if identified
Erythema multiforme major (Stevens­ Resuscitate as needed (respiratory +/– circulatory) Inpatient management; acute,
Johnson syndrome) Fluid and electrolyte management as needed critical care, or burn unit
Steroid (as above or methylprednisolone 125 milligrams IV Intensivist† and dermatologist every  h or equivalent)* consultations
Pain management as appropriate
Diphenhydramine and viscous lidocaine rinses for oral lesions
Burow’s solution (5% aluminum acetate) with cool compresses for blisters
Ophthalmologist for ocular lesions
Antibiotic only for suspected or established infection (i.e., not prophylactic)
Remove trigger if identified
Toxic epidermal necrosis Resuscitate as needed (respiratory +/– circulatory) Inpatient management, critical care
Fluid and electrolyte management as needed or burn unit
Antibiotic only for suspected or established infection (i.e., Intensivist† and dermatologist not prophylactic) consultations
Remove trigger if identified
Pemphigus vulgaris Resuscitate as needed (respiratory +/– circulatory) Inpatient management; acute,
Fluid and electrolyte management as needed critical care, or burn unit
Antibiotic only for suspected or established infection (i.e., Intensivist† and dermatologist not prophylactic) consultations
Immunosuppressive therapy* Plasmapheresis* Immunoglobulin therapy* Exfoliative dermatitis minor Remove trigger if identified Outpatient management
Symptomatic care (oral pain and antihistamine agents as Primary care physician or needed [PRN]) dermatology follow­up
Exfoliative dermatitis major Resuscitate as needed (circulatory) Inpatient management; acute,
Correct hypothermia critical care, or burn unit
Remove trigger if identified Intensivist† and dermatologist
Symptomatic care (oral pain and antihistamine agents PRN) consultations
Steroid after dermatologist consultation
(methylprednisolone 125 milligrams IV every  h or equivalent)* DRESS (drug rash with eosinophilia and Resuscitate as needed (respiratory +/– circulatory) Inpatient management, acute or systemic symptoms) syndrome Remove trigger if identified critical care unit
Symptomatic care (oral pain and antihistamine agents PRN) Intensivist† and dermatologist
Antipyretic therapy consultations
Steroid (as above or methylprednisolone 125 milligrams IV every  h or equivalent)* Staphylococcal toxic shock syndrome Resuscitate as needed (respiratory +/– circulatory) Inpatient management, acute or
Removal of foreign body source (usually colonization only, critical care unit not active infection) Intensivist,† infectious disease, and
Antistaphylococcal antibiotics (only reduces recurrence) dermatologist PRN
Streptococcal toxic shock syndrome Resuscitate as needed (respiratory +/– circulatory) Inpatient management, acute or
Broad­spectrum antibiotics with antistreptococcal coverage critical care unit
Attention to soft tissue infection with incision/drainage, Intensivist,† infectious disease, debridement, amputation, etc.
surgeon, and dermatologist PRN
Staphylococcal scalded skin syndrome Resuscitate as needed (respiratory +/– circulatory) Inpatient management, acute or
Fluid and electrolyte management as needed critical care unit
Identification of source (colonization or active infection) Intensivist,† infectious disease, and
Antistaphylococcal antibiotics dermatologist PRN
Topical dressings PRN* Meningococcemia Resuscitate as needed (respiratory +/– circulatory) Critical care unit
Parenteral antibiotics Intensivist
Purpura fulminans Resuscitate as needed (respiratory +/– circulatory) Critical care unit
Intensivist
*Therapy guided by dermatologist.
†Intensivist involvement if patient admitted to critical care unit.
ERYTHEMA MULTIFORME
Erythema multiforme is an acute inflammatory skin disease (Figure 249­1) that ranges from a minimal, nuisance­level event to a severe multisystem illness. It is divided into two distinct subtypes, considering the extent of involvement, presence of epidermal detachment, and the development of mucous membrane lesions. Erythema multiforme minor is a localized papular eruption of the skin, with an acral distribution and involving target lesions and/or raised, edematous papules. Erythema multiforme major is the severe form with multisystem involvement and widespread vesiculobullous lesions and erosions of the mucous membranes; specifically, erythema multiforme major includes involvement of one or more mucous membrane areas and epidermal detachment less than 10% of total body surface area. Some authorities include Stevens­Johnson syndrome as a severe form of erythema multiforme major, whereas others consider it a less severe form of toxic epidermal necrolysis. Perhaps the most appropriate classification approach for the emergency provider is as follows: Stevens­Johnson syndrome presents with less than 10% of the body surface area with epidermal detachment; the “overlap” presentation of Stevens­Johnson syndrome and toxic epidermal necrolysis presents with

10% to 30% epidermal detachment; and toxic epidermal necrolysis presents with greater than 30% epidermal detachment. In either consideration,
Stevens­Johnson syndrome is a serious dermatologic illness with significant, widespread skin involvement, more extensive epidermal detachment, and mucous membrane lesions. This taxonomic controversy has no meaning for the emergency clinician; what is important is the recognition of a significant, potentially life­threatening, multisystem dermatologic condition.
FIGURE 249­1. Erythema multiforme.

Morbidity and mortality rise with the amount of epidermal detachment. The highest incidence is in young adults (age range,  to  years), and erythema multiforme occurs commonly in the spring and fall. Common precipitating factors are infection, especially with Mycoplasma and herpes
 simplex virus; drugs, especially antibiotics and anticonvulsants; and malignancies. However, the cause is often unknown. Most likely, erythema multiforme is the result of a hypersensitivity reaction, with immunoglobulin and complement components demonstrated in the cutaneous microvasculature on immunofluorescent studies of skin biopsy specimens, circulating immune complexes found in the serum, and mononuclear cell
,4 infiltrate noted on histologic examination.
Symptoms include malaise, fever, myalgias, and arthralgias. Diffuse pruritus or a generalized burning sensation can occur before the skin lesions develop. The morphologic configuration of the lesions is variable, hence the descriptor multiforme. Maculopapular (Figure 249­2) and target, or iris
(Figure 249­3), lesions are the most characteristic. Erythematous papules appear symmetrically on the dorsum of the hands and feet and on the extensor surfaces of the extremities. The maculopapule evolves into the classic target lesion during the next  to  hours. As the maculopapule enlarges, the central area becomes cyanotic, occasionally accompanied by central purpura or a vesicle. Urticarial plaques also may occur with or without the iris lesion in a similar distribution. Vesiculobullous lesions, which may be pruritic and painful, develop within preexisting maculopapules or plaques, usually on the extensor surface of the arms and legs and less frequently on the trunk. Vesiculobullous lesions are found most often on mucosal surfaces, including the mouth, eyes, vagina, urethra, and anus; they may also be seen on the trunk. Ocular involvement rarely occurs in
 erythema multiforme minor, whereas ophthalmologic lesions are seen in almost 70% of patients with Stevens­Johnson syndrome. The various lesions (Table 249­3) develop in successive crops during a 2­ to 4­week period and heal over  to  days. The differential diagnosis of erythema multiforme includes herpetic (herpes simplex virus and varicella­zoster virus) infection, vasculitis, toxic epidermal necrolysis, various primary blistering disorders (pemphigus and pemphigoid), urticaria, Kawasaki’s disease, and the toxic and infectious erythemas.
FIGURE 249­2. Maculopapular erythema multiforme.
FIGURE 249­3. Target, or iris, lesions of erythema multiforme. [Photograph used with permission of Kenneth Greer, MD, University of Virginia Dermatology.]
TABLE 249­3
Erythema Multiforme and Toxic Epidermal Necrolysis
Lesions of Erythema Multiforme Lesions of Toxic Epidermal Necrolysis
Erythematous maculopapules Warm, tender erythroderma
Iris or target lesions Vesicles and bullae
Urticaria Exfoliation
Mucous membranes involved Mucous membranes involved
Recurrence may be noted on repeat exposure to the etiologic agent, a special concern in cases associated with herpes simplex virus infection or
 medication use. The rate of erythema multiforme recurrence is very high in children with herpes simplex virus infection. For example,
75% of children with a history of herpes simplex virus–related erythema multiforme developed erythema multiforme recurrence after herpes simplex
 virus reactivation. Fluid and electrolyte disorders and secondary infection from cutaneous sites are the most frequent complications.
Treatment is provided in Table 249­2. Systemic steroids are commonly used for localized disease and provide symptomatic relief, but are of unproven
 benefit in influencing the duration and outcome of erythema multiforme. Many authorities recommend a short, intensive steroid course of prednisone,  to  milligrams PO once a day, particularly in drug­related cases, with abrupt cessation in  to  days if no favorable response is noted.
Unfortunately, burst steroid therapy does not reduce the chance of development or significance of existing ocular lesions. Provide symptomatic relief of stomatitis and blisters. Do not swallow oral viscous lidocaine because it causes neurotoxicity. Consult ophthalmology for ocular involvement.
Acyclovir may reduce recurrence of herpes simplex virus infection and therefore lessen the potential for another bout of erythema multiforme;
 prolonged prophylactic acyclovir therapy may reduce the chance of recurrent erythema multiforme related to herpes simplex virus.
TOXIC EPIDERMAL NECROLYSIS
Toxic epidermal necrolysis (Figure 249­4) is an explosive dermatosis characterized by tender erythema, bullae formation, mucous membrane lesions, and subsequent exfoliation. Patients are systemically ill. Many authorities consider Stevens­Johnson syndrome to be a less severe form of toxic epidermal necrolysis, whereas others consider Stevens­Johnson syndrome to be a more severe form of erythema multiforme major; in either case,
Stevens­Johnson syndrome and toxic epidermal necrolysis are severe dermatologic illnesses, whether they are distinct entities or two forms of the
 same syndrome.
FIGURE 249­4. Toxic epidermal necrolysis.
Toxic epidermal necrolysis is found in all age groups without predilection for either sex. The syndrome has multiple causes, with medications being the
,4,8 most common cause. Sulfa and penicillin antibiotics, anticonvulsants, and oxicam NSAIDs are the most frequent drug triggers for toxic epidermal
,10 ,11,12 necrolysis. Other causes include malignancy and human immunodeficiency virus infection. In many cases, a cause is not found. The
 pathogenesis is poorly understood and may be partly immunologic and partly genetic.
Symptoms include a 1­ to 2­week prodrome of malaise, anorexia, arthralgias, fever, or symptoms of upper respiratory tract infection. Skin tenderness, pruritus, tingling, or burning may be found at this time. Skin signs (Table 249­3) begin with a warm erythema, initially involving only the eyes, nose, mouth, and genitalia, but later becoming generalized. The erythematous areas become tender and confluent within hours. Flaccid, ill­defined bullae then appear within the areas of erythema. Lateral pressure with a finger on normal skin adjacent to a bullous lesion dislodges the epidermis, producing denuded dermis and demonstrating Nikolsky sign. Nikolsky sign is slippage of the epidermis from the dermis when slight rubbing pressure is applied to the skin. The bullae form along the cleavage plane between the epidermis and the dermis. The epidermis is then shed in large sheets, which leaves raw, denuded areas of exposed dermis. The average time until onset after exposure to the inciting agent is  weeks. Cutaneous extension follows an unpredictable time course, ranging from  hours to  days, with some severe cases demonstrating rapid, extensive involvement within  hours.
Perilabial blistering and erosive lesions are disfiguring and often impair adequate oral intake, contributing to hypovolemia. Ocular complications include purulent conjunctivitis, painful erosions, and potential blindness. Anogenital lesions are common. Additional mucous membrane involvement includes the GI, urinary, and respiratory tracts. The two major complications and leading causes of death in toxic epidermal necrolysis are infection and hypovolemia with electrolyte disorders. A broad range of pathogens is usually found, with staphylococcal and pseudomonal species
 predominating. The mortality rate is as high as 30%. The clinical characteristics associated with poor prognosis include advanced age, extensive
 disease, idiopathic nature, use of multiple medications, steroid therapy, azotemia, hyperglycemia, leukopenia, and thrombocytopenia. The differential diagnosis of toxic epidermal necrolysis is presented in Table 249­1 and also includes primary blistering disorders (pemphigus and pemphigoid) and Kawasaki’s disease in children.

Treatment is presented in Table 249­2. Toxic epidermal necrolysis requires hospitalization in an intensive care or burn unit. Immediate concerns center on the airway, because sloughing of airway and respiratory epithelium can occur. Hypovolemia and electrolyte abnormalities should be corrected. Prompt, aggressive antibiotic administration is necessary in suspected or documented infection; initial prophylactic antibiotics are not recommended by most. Solicit the advice of the burn center regarding any topical dressings that are applied before transfer.
PEMPHIGUS VULGARIS
Pemphigus vulgaris is a generalized, mucocutaneous, autoimmune, blistering eruption with a grave prognosis characterized by intraepidermal acantholytic blistering (Table 249­4). The primary lesions of pemphigus vulgaris are vesicles or bullae (Figure 249­5) that vary in diameter from <1 cm to several centimeters. They commonly first affect the head, trunk, and mucous membranes. The blisters are usually clear and tense, originating from normal skin or atop an erythematous or urticarial plaque. Within  to  days, the bullae become turbid and flaccid. Rupture soon follows, producing painful, denuded areas. These erosions are slow to heal and prone to secondary infection. The Nikolsky sign is present in pemphigus vulgaris. Mucous membranes are affected in most patients, and in some, the mucous membranes are the primary sites of involvement. Blisters on mucous membranes are more transitory than blisters on the skin in that they are more vulnerable to rupture; this is particularly true in the mouth, where ragged ulcerative lesions readily develop after inadvertent biting of the tissues.
TABLE 249­4
Characteristics of Pemphigus Vulgaris Lesions
Large, flaccid bullae
Nikolsky sign present
Skin ulcerations
Exfoliation
Mucous membrane involvement
FIGURE 249­5. Scattered bullous lesions intermixed with erosions and painful inflammatory plaques in a patient with pemphigus vulgaris.
Bullous pemphigoid, another mucocutaneous blistering disorder, can present in similar fashion to pemphigus vulgaris with the following significant differences found in the bullous pemphigoid: older average age at onset, larger blister size, lower rate of mucous membrane involvement, and overall
“less toxicity” with better outcome.
Limited oral intake and accelerated protein, fluid, and electrolyte losses through the involved skin can rapidly lead to hypovolemia and electrolyte disturbances. Treatment is provided in Table 249­2. EXFOLIATIVE DERMATITIS
Exfoliative dermatitis is a condition in which most or all of the skin surface is involved with a scaly erythematous dermatitis. It is a cutaneous reaction in response to a drug or a chemical agent or to an underlying systemic or cutaneous disease. Most patients are over  years of age. The cause is unknown.
,14
Exfoliative dermatitis can have an abrupt onset, particularly when related to a drug, contact allergen, or malignancy; exacerbations related to an underlying cutaneous disorder usually evolve more slowly. Exfoliative dermatitis tends to be a chronic condition, with a mean duration of  years, when related to a chronic illness; the course is often shorter after suppression of the underlying dermatosis, discontinuation of causative drugs, or avoidance of allergen. Idiopathic and chronic disease–related exfoliative dermatitis can continue for ≥20 years; death is rare.
Generalized erythema and warmth are noted, but skin tenderness is usually lacking. Erythema is accompanied by scaling or flaking, and the patient often complains of pruritus and skin tightness (Figure 249­6). The process generally begins on the face and upper trunk with progression to other skin surfaces. The patient usually has a low­grade fever. Excessive heat loss and hypothermia can complicate exfoliative dermatitis. Widespread cutaneous vasodilation may result in high­output congestive heart failure. The disruption of the epidermis results in increased transepidermal water loss, and continued exfoliation can result in significant protein loss and negative nitrogen balance. Chronic inflammatory exfoliation produces many changes, such as dystrophic nails, thinning scalp and body hair, and patchy or diffuse pigmentation changes.
FIGURE 249­6. Exfoliative dermatitis demonstrated by generalized, warm erythema accompanied by scaling or flaking.
The differential diagnosis is found in Table 249­1, and treatment is provided in Table 249­2. Patients generally require admission. Correct hypothermia and hypovolemia. Obtain dermatology consultation before giving systemic corticosteroids.
DRESS (DRUG RASH WITH EOSINOPHILIA AND SYSTEMIC SYMPTOMS) SYNDROME
Drug rash with eosinophilia and systemic symptoms (DRESS) syndrome is a severe adverse drug reaction that usually develops within  weeks of initiation of drug therapy. Aromatic anticonvulsants (such as phenytoin and phenobarbital), allopurinol, and sulfa medications are the most common culprits; however, other causes include NSAIDs, antiretroviral medications, angiotensin­converting enzyme inhibitors, calcium channel blockers, and
13­16 other antibiotics.

It is believed that there is a genetic predisposition if exposed to the appropriate medication. Because of the potential genetic risk, DRESS syndrome risks and implications should be discussed with the family members of any patient in whom it is diagnosed.
DRESS syndrome is defined by fever, rash, and internal organ involvement, with the liver, kidneys, and hematologic system being most commonly
 affected. Rash and fever are typically the first signs of the syndrome, and they may have associated lymphadenopathy (Figure 249­7). The rash itself can take multiple forms, ranging from an erythematous scaly rash similar to that of exfoliative dermatitis, to a blistering/bullous rash similar to that of
Stevens­Johnson syndrome, with varying degrees of severity. Abnormal laboratory findings include eosinophilia, which occurs in about 30% of DRESS
 syndrome patients, and hepatic and renal dysfunction. Because of the variety of clinical presentations, early diagnosis of DRESS syndrome is difficult and requires a high level of clinical suspicion. The current treatment (Table 249­2) involves immediate stoppage of the suspected culprit medication, administration of systemic steroids in severe cases (those with evidence of hepatitis, pneumonitis, or extensive exfoliative dermatitis), supportive care
,18 including antipyretic and antipruritic medications, and hospital admission.
FIGURE 249­7. Drug rash with eosinophilia and systemic symptoms (DRESS) syndrome caused by phenytoin.
PURPURIC DISORDERS
MENINGOCOCCEMIA
Meningococcemia is a potentially fatal infectious illness caused by the gram­negative diplococcus Neisseria meningitidis. Meningococcal disease presents across a wide clinical spectrum in the acute and chronic forms. The acute entities include pharyngitis, meningitis, and bacteremia.
,20
Meningococci are present in mucosal samples from approximately 5% to 10% of the general population (the carrier state). In high­risk
 populations, such as military recruits, the organism may be found in almost half of people without evidence of active disease.
The illness usually strikes patients <20 years of age, with the vast majority of cases occurring in children and infants <5 years old. A rash is frequently noted on presentation and is an invaluable clue to the correct diagnosis early in the disease course. The dermatologic manifestations include petechiae, urticaria, hemorrhagic vesicles, macules, and/or maculopapules (Figure 249­8). The classic petechial lesions are found on the extremities and trunk but also are noted on the palms, soles, head, and mucous membranes. The petechiae evolve into palpable purpura with gray necrotic centers, a pathognomic finding for meningococcal infection. The skin findings result from the organism’s invasion and destruction of the endothelium. Histopathologic analysis shows an infectious vasculitis. For further discussion, see Chapters 142, “Rashes in Infants and Children,” and
120, “Meningitis in Infants and Children.”
FIGURE 249­8. Early findings of meningococcemia with petechiae evolving into pruritic lesions. [Photograph used with permission of Kenneth Greer, MD, University of
Virginia Dermatology.]
PURPURA FULMINANS
Purpura fulminans is a rare vascular disorder characterized by fever, shock, multiorgan failure, and the rapid development of hemorrhagic skin necrosis. It is associated with dermal vascular thrombosis, vascular collapse, and disseminated intravascular coagulation. Purpura fulminans can result from hereditary or acquired protein C deficiency, activated protein C resistance, or protein S deficiency. It may also result from any condition that causes disseminated intravascular coagulation.
Purpura fulminans presents with the dermatologic triad of widespread ecchymoses, hemorrhagic bullae (Figure 249­9), and epidermal necrosis.
Cyanosis with initial ecchymoses and ultimate necrosis of the tip of the nose, ears, and genitalia frequently occur; in general, distal tissue areas with end circulation are affected. Large confluent ecchymoses can develop, often on the extremities, from distal to proximal, and on the perineum, buttocks, and abdomen. The extremities are often involved symmetrically. Treatment is directed at the underlying cause.
FIGURE 249­9. Purpura fulminans (A) with early skin necrosis and (B) later with hemorrhagic bullae. [Photographs used with permission of Kenneth Greer, MD,
University of Virginia Dermatology.]


