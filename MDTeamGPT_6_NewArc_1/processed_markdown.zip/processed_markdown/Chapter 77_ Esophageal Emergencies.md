## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 77: Esophageal Emergencies
Michael J. Bono
INTRODUCTION
The complaints of dysphagia, odynophagia, and foreign body sensation immediately implicate the esophagus. The esophagus also is often the site of pathology in patients who present with chest pain, upper GI bleeding (see Chapter , “Upper Gastrointestinal Bleeding”), malignancy, and mediastinitis. Esophageal foreign body and esophageal perforation demand the attention of the emergency physician, but many diseases of the esophagus can be evaluated over time in an outpatient setting.
ANATOMY AND PATHOPHYSIOLOGY
The esophagus is a muscular tube approximately  to  cm long, primarily located in the mediastinum, posterior and slightly lateral to the trachea, with smaller cervical and abdominal components, as shown in Figure 77­1. There is an outer longitudinal muscle layer and an inner circular muscle layer. The upper third of the esophagus is striated muscle, while the lower two­thirds is all smooth muscle, including the lower esophageal sphincter.
The esophagus is lined with stratified squamous epithelial cells that have no secretory function.
FIGURE 77­1. Anatomic relations of the esophagus (seen from the left side). The distance from the upper incisor teeth to the beginning of the esophagus (cricoid cartilage) is about  cm (6 in.); from the upper incisors to the level of the bronchi,  to  cm (9 in.); and to the cardia,  cm (16 in.). Structures contiguous to the esophagus that affect esophageal function are shown.

Chapter 77: Esophageal Emergencies, Michael J. Bono 
. Terms of Use * Privacy Policy * Notice * Accessibility
Two sphincters regulate the passage of material into and out of the esophagus. The upper esophageal sphincter prevents air from entering the esophagus and food from refluxing into the pharynx. The lower esophageal sphincter regulates the passage of food into the stomach and prevents stomach contents from refluxing into the esophagus. The upper sphincter is composed primarily of the cricopharyngeus muscle, with a resting pressure of around 100 mm Hg. The lower sphincter is not anatomically discrete. The smooth muscle of the lower  to  cm of the esophagus, in combination with the skeletal muscle of the diaphragmatic hiatus, functions as the sphincter, with a lower resting pressure around  mm Hg. An empty esophagus collapses, but three anatomic constrictions affect the adult esophagus:
. At the cricopharyngeus muscle (C6)
. At the level of the aortic arch (T4)
. At the gastroesophageal junction (T10 to T11)
The pediatric esophagus gets two additional areas of constriction:
. At the thoracic inlet (T1)
. At the tracheal bifurcation (T6)
The innervation of the esophagus mirrors that of the heart, with visceral and somatic stimuli converging within the sympathetic system. This anatomy makes pain of esophageal and cardiac origin similar. The esophageal venous circulation includes a submucosal plexus of veins that drains into a separate plexus of veins surrounding the esophagus. Blood flows from this outer plexus in part to the gastric venous system, an important link between portal and systemic circulation. Variceal dilatation of the submucosal system can lead to massive upper GI bleeding.
DYSPHAGIA
Dysphagia is difficulty with swallowing. Oropharyngeal dysphagia occurs as the food bolus moves from the oropharynx through the upper sphincter.
Symptoms include drooling, inability to begin swallowing, or a feeling of food catching in the neck. Common causes are listed in Table 77­1. Esophageal dysphagia is impaired movement of the bolus down the esophagus and through the lower sphincter. A feeling of “food getting stuck” occurs after swallowing is initiated. Esophageal dysphagia can be caused by mechanical obstruction in the esophagus or motility disorders (Table 77­
1). Functional or motility disorders usually cause dysphagia that is intermittent and variable. Mechanical or obstructive disease is usually progressive,
 first with difficulty swallowing solids, then liquids. Odynophagia is throat and chest pain with swallowing and usually signifies esophageal inflammation, infection, or erosion. Common causes include Candida, herpesvirus, or cytomegalovirus.
TABLE 77­1
Causes of Dysphagia
Oropharyngeal Dysphagia Esophageal Dysphagia
Discoordination in transferring bolus from pharynx to esophagus Improper transfer of the bolus from the upper esophagus into the stomach: solids worse than liquids = mechanical obstruction; solids and liquids = motility disorder
Swallowing symptoms—gagging, coughing, nasal regurgitation, inability to Swallowing symptoms—food “sticking,” retrosternal fullness with solids initiate swallow, need for repeated swallows (and eventually liquids), possibly odynophagia
Risk of aspiration present Risk of aspiration present, generally less pronounced than in transfer dysphagia
Long term—weight loss, malnutrition, chronic bronchitis, asthma, multiple Long term—malnutrition, dehydration, weight loss, systemic effects of episodes of pneumonia cancer
Neuromuscular disease—cerebrovascular accident, cerebral palsy, Obstructive disease—foreign body, carcinoma, esophageal webs, peptic polymyositis and dermatomyositis, scleroderma, myasthenia gravis, tetanus, esophageal strictures, Schatzki ring, thyroid enlargement, esophageal
Parkinson’s disease, botulism, lead poisoning, thyroid disease diverticulae, congenital or acquired large­vessel abnormalities
Localized disease—pharyngitis; aphthous ulcers; candidal infection; Motor disorder—achalasia, peristaltic dysfunction (nutcracker peritonsillar and retropharyngeal abscesses; carcinoma of tongue, pharynx, or esophagus), diffuse esophageal spasm, scleroderma larynx; Zenker’s diverticulum; cricopharyngeal bar; cervical osteophytes
Inadequate lubrication—scleroderma Inflammatory disease
The diagnosis of the underlying pathology is most often made outside of the ED, with upper endoscopy, videoesophagography, barium swallow, or
2­6 esophageal manometry. If neoplasm is suspected by history and physical examination, CT imaging of neck and chest may be indicated in the ED.
GASTROESOPHAGEAL REFLUX DISEASE
Reflux of gastric contents into the esophagus causes a wide array of symptoms and long­term effects. Classically, a weak lower esophageal sphincter has been the mechanism held responsible for reflux, and this is seen in some patients. However, transient relaxation of the lower esophageal sphincter complex (with normal tone in between periods of relaxation) is the primary mechanism causing reflux. Hiatal hernia, prolonged gastric emptying,
 agents that decrease lower sphincter pressure, and impaired esophageal motility predispose to reflux. Table 77­2 lists some common contributors.
TABLE 77­2
Causes of Gastroesophageal Reflux Disease
Decreased Esophageal Prolonged Gastric
Decreased Pressure of Lower Esophageal Sphincter
Motility Emptying
High­fat food Achalasia Medicines (anticholinergics)
Nicotine Scleroderma Outlet obstruction
Ethanol Presbyesophagus Diabetic gastroparesis
Caffeine Diabetes mellitus High­fat food
Medicines (nitrates, calcium channel blockers, anti​cholinergics, progesterone, estrogen)
Pregnancy
Heartburn is the classic symptom of gastroesophageal reflux disease (GERD). The burning nature of the discomfort is probably due to localized lower esophageal mucosal inflammation. Many GERD patients report other associated GI symptoms, such as odynophagia, dysphagia, acid regurgitation, discomfort with meals, and hypersalivation. Reflux symptoms can sometimes be dramatically exacerbated with a head­down position or an increase in intra­abdominal pressure. Symptoms are often relieved by antacids, but pain can return after the transient antacid effect wears off. Some patients with symptoms caused by cardiac ischemic disease also report improvement with antacids. Symptoms of cardiac and GERD pain are very similar. Both may be squeezing and pressure­like, and the history may include pain onset with exertion and offset with rest. Both types of pain may be accompanied by diaphoresis, pallor, and nausea and vomiting. Radiation of esophageal pain can occur to one or both arms, the neck, the shoulders, or the back. Given the serious outcome of unrecognized ischemic disease, distinguishing GERD from cardiac disease is often best accomplished in a protocol­driven observation unit.
Over time, GERD can cause complications including strictures, dysphagia, and inflammatory esophagitis. Barrett’s esophagus, a complication of GERD,
8­10 is the extension of gastric epithelium from the stomach to the distal esophagus, with a risk of dysplasia and metaplasia. Less obvious presentations of GERD include asthma exacerbations, sore throat, and other ear, nose, and throat symptoms. GERD has also been implicated in dental erosion, vocal cord ulcers and granulomas, laryngitis with hoarseness, chronic sinusitis, and chronic cough.
Treatment of reflux disease involves decreasing acid production in the stomach, enhancing upper tract motility, and eliminating risk factors. Mild disease is often treated empirically, and the optimal approach to choice of treatment is unclear. A reasonable approach is to start treatment with histamine­2 receptor antagonists, and if there is no improvement in  weeks, stop the current treatment and start a proton pump inhibitor. At ED discharge, remind patients to avoid agents that exacerbate GERD (ethanol, caffeine, nicotine, chocolate, fatty foods), sleep with the head of the bed elevated (30 degrees), and avoid eating within  hours of going to bed at night. The need for additional testing can be determined at outpatient followup care.
ESOPHAGITIS
Esophagitis can cause prolonged periods of chest pain and almost always causes odynophagia as well. Diagnosis of more established esophagitis is by endoscopy. Low­grade disease can be seen by histopathologic examination.
GERD may induce inflammatory esophagitis in the lower esophageal mucosa. Over time, ulcerations, scarring, and stricture formation can develop.

Treatment is pharmacologic therapy with acid­suppressive medications. Ingested medications can also be a source of inflammatory esophagitis and ulcerations. Common offenders include NSAIDs and other anti­inflammatory drugs, potassium chloride, and some antibiotics (e.g., doxycycline, tetracycline, and clindamycin). Risk factors for pill­induced esophageal injury include swallowing position, fluid intake, capsule size, and patient age.
Withdrawal of the offending agent is generally curative. Eosinophilic esophagitis is a chronic allergic­inflammatory condition in which eosinophils
 and other immune system cells infiltrate the esophagus and induce an inflammatory response, in response to foods, allergens, or acid reflux.
Diagnosis is by endoscopy. Treatment is avoidance of allergens and oral liquid corticosteroids or inhaled corticosteroids. Dilatation is necessary if strictures form.
Patients with immunosuppression can develop infectious esophagitis. The diagnosis of infectious esophagitis in an otherwise seemingly healthy host should prompt an evaluation of immune status. Candidal species are the most common pathogens, often associated with dysphagia as a primary symptom. However, oral candidiasis is not always present. Empiric treatment is often begun with oral fluconazole, 400 milligrams per day for  weeks.
Herpes simplex or cytomegalovirus infection and aphthous ulceration are also seen and may be more frequently associated with odynophagia. Other causative agents are rare and include fungi, mycobacteria, and other viral pathogens such as varicella­zoster virus and Epstein­Barr virus. Endoscopy
 with biopsy and specimen culture establishes the specific diagnosis.
ESOPHAGEAL PERFORATION

Iatrogenic perforation is the most frequent cause of esophageal perforation, with a large number of other responsible processes listed in Table 77­
. TABLE 77­3
Causes of Esophageal Perforation
Cause of Perforation Description
Iatrogenic Intraluminal procedures
Endoscopy
Dilatation
Variceal therapy
Gastric intubation
Intraoperative injury
Boerhaave’s syndrome “Spontaneous,” usually associated with transient increase in intraesophageal pressure
Trauma Penetrating
Blunt (rare)
Caustic ingestion
Foreign body Includes pill­related injury
Infection Rare
Tumor May be intrinsic or extrinsic cancer
Aortic pathology Aneurysm
Aberrant right subclavian artery
Miscellaneous Barrett’s esophagus
Zollinger­Ellison syndrome
Boerhaave’s syndrome is full­thickness perforation of the esophagus after a sudden rise in intraesophageal pressure. The mechanism is sudden, forceful emesis in most cases; coughing, straining, seizures, and childbirth have been reported as causing perforations as well. The perforation is usually in the distal esophagus on the left side.
PATHOPHYSIOLOGY
Perforation causes a dramatic presentation when esophageal contents leak into the mediastinal, pleural, or peritoneal spaces. Fulminant, necrotizing mediastinitis, pneumonitis, or peritonitis can rapidly lead to shock. If the perforation is small and leakage is contained by contiguous structures, the
 course may be indolent. Most spontaneous perforations occur through the left posterolateral wall of the distal esophagus. Proximal perforation, seen mostly with instrumentation, tends to be less severe than distal perforation and can form a periesophageal abscess with minimal systemic toxicity.
CLINICAL FEATURES
The pain of rupture is classically described as acute, severe, unrelenting, and diffuse, and is reported in the chest, neck, and abdomen. Pain can radiate to the back and shoulders. Back pain may be a very predominant symptom. The pain is often exacerbated by swallowing. Dysphagia, dyspnea, hematemesis, and cyanosis can be present as well.
Physical examination varies with the severity of the rupture and the elapsed time to presentation. Abdominal rigidity with hypotension and fever often occur early. Tachycardia and tachypnea are common. Cervical subcutaneous emphysema is common in cervical esophageal perforations. Hamman’s crunch, caused by air in the mediastinum that is being moved by the beating heart, can sometimes be auscultated. Pleural effusion can result from intrathoracic perforation but is uncommon in cervical perforation. Pleural fluid can be caused by either direct contamination of the pleural space or a sympathetic serous effusion from mediastinitis.
DIAGNOSIS
Obtain surgical consultation as soon as the diagnosis is seriously entertained. Resuscitate the patient from shock, and administer broad­spectrum parenteral antibiotics. Obtain IV contrast CT of the neck or chest. Obvious perforation requires emergency surgery. If CT is negative but clinical
12­14 suspicion is still high, flexible video esophagoscopy or esophagography, or both, are next steps depending upon resources and local preferences.
Esophagoscopy is extremely accurate for finding esophageal injuries, with a sensitivity of 95% to 100%, and specificity of 90% to 100% if performed by an experienced endoscopist. If an experienced endoscopist is not available, esophagography should be performed with water­soluble contrast material initially (i.e., Gastrografin).
SWALLOWED FOREIGN BODIES AND FOOD IMPACTION
PATHOPHYSIOLOGY
Children  to  months of age and those with mental illness account for most cases of ingested foreign bodies. Small objects, such as coins, toys, and crayons, typically lodge in the anatomically narrow proximal esophagus. In adults, dentures are sometimes swallowed, because diminished palatal sensitivity leads to unintentional ingestion. Adult candidates for swallowed foreign bodies are those with esophageal disease, dementia, prisoners, and psychiatric patients. In adults, most impactions are distal. In children and adults, once an object has traversed the pylorus, it usually continues through the GI tract and is passed without issue. If, however, the object has irregular or sharp edges or is particularly wide (>2.5 cm) or long (>6 cm), it
 may become lodged distal to the pylorus. Esophageal impaction can result in airway obstruction, stricture, or perforation, the latter being the result of direct mechanical erosion (e.g., ingested bones) or chemical corrosion (e.g., ingested button batteries). Esophageal mucosal irritation (often mechanical from a swallowed bone, for example) can be perceived as a foreign body by the patient as well.
CLINICAL FEATURES
Adults with an esophageal foreign body generally provide unequivocal history. Patients often complain of retrosternal pain and may localize the object
(often accurately in the upper third of the esophagus). Patients may have dysphagia, vomiting, and choking. If the patient attempts to wash down the object with liquid or if swallowed secretions pool proximal to the obstruction, coughing or aspiration can occur. In children, the history can be unclear. Signs and symptoms can include refusal or inability to eat, vomiting, gagging and choking, stridor, neck or throat pain, and drooling. A high degree of suspicion is necessary for unwitnessed ingestions in children, especially in those <2 years of age.
Physical examination starts with an assessment of the airway. The nasopharynx, oropharynx, neck, and chest should also be examined but are often unremarkable. Occasionally, a foreign body can be directly visualized in the oropharynx.
DIAGNOSIS
,17
Plain films are used to screen for radiopaque objects. Coins in the esophagus generally present their circular face on anteroposterior films
(coronal alignment), as opposed to coins in the trachea, which show that face on lateral films (Figure 77­2). Obtaining plain films in patients with food impaction is rarely helpful and can generally be omitted. CT scanning is a very high­yield test for esophageal foreign body and has generally replaced the barium swallow test to evaluate ingestion of nonradiopaque objects. CT also delivers excellent information regarding perforation and subsequent infection.
FIGURE 77­2. A coin lodged in a child’s esophagus is visible on an anteroposterior radiograph. [Reproduced with permission from Effron D (ed): Pediatric Photo and
X­Ray Stimuli for Emergency Medicine, vol II. Columbus, OH, Ohio Chapter of the American College of Emergency Physicians, 1997, case .]
TREATMENT
Endoscopy
Patients in extremis or with pending airway compromise are resuscitated and often require active airway management. Complete obstruction of the esophagus (often distal esophageal food impactions) can lead to proximal pooling of secretions and aspiration. Emergent endoscopy is needed.
Table 77­4 lists other situations that require urgent endoscopy, even if patients are clinically stable. Some of these ingestions are discussed in more detail in the sections “Food Impaction,” “Coin Ingestion,” “Button Battery Ingestion,” “Ingestion of Sharp Objects,” and “Narcotics Ingestion” later in the chapter. In general, if endoscopy is clearly indicated, performing advanced imaging studies delays definitive intervention while adding little value to the care of the patient. In the vast majority of cases, the foreign body can be removed relatively easily with endoscopy without complication. Hospital admission is generally not needed.
TABLE 77­4
Circumstances Warranting Urgent Endoscopy for Esophageal Foreign Bodies
Ingestion of sharp or elongated objects (including toothpicks, aluminum soda can tabs)
Ingestion of multiple foreign bodies
Ingestion of button batteries
Evidence of perforation
Coin at the level of the cricopharyngeus muscle in a child
Airway compromise
Presence of a foreign body for >24 h
Laryngoscopy
In stable patients, indirect laryngoscopy or visualization of the oropharynx using a fiberoptic scope may allow removal of very proximal objects. For more distal objects, imaging studies are used to define the location and nature of the ingestion. Objects that persist over time or are in the upper half of the esophagus are less likely to pass, and consultation for endoscopy is prudent.
Expectant Treatment
If the object is distal to the pylorus, has a benign shape and nature, and the patient is comfortable and tolerating intake by mouth, treatment is expectant. For worrisome foreign bodies that are in the more distal GI tract, surgery consultation may be necessary.
Foley Catheter Removal
Alternatives to endoscopy have been advocated by some authors. These include use of a Foley catheter to remove coins (see section “Coin Ingestion” later in the chapter) and bougienage (a procedure involving the use of a bougie) to advance the object from the esophagus into the stomach. Generally, the Foley catheter technique and bougienage should only be attempted in patients with blunt foreign bodies present for <24 hours and in patients without underlying esophageal disease. Provider comfort with the procedure likely influences the generally low complication rates in published
 series.
Glucagon
For distal esophageal objects, glucagon,  to  milligrams IV in adults, has been reported to relax the lower sphincter and allow passage of the object.
Success rates of glucagon therapy are generally reported as poor, however, and it may be no better than watchful waiting without
 other intervention.
FOOD IMPACTION
Meat is the food most commonly identified in food impaction. Food impaction with complete esophageal obstruction or impaction of food containing bony fragments requires emergency endoscopy. Uncomplicated food impaction may be treated expectantly. Time and sedation often allow the bolus to pass into the stomach, but the bolus should not be allowed to remain impacted for >12 to  hours. The use of proteolytic enzymes (e.g.,
Adolph’s Meat Tenderizer®, which contains papain) to dissolve a meat bolus is contraindicated, because of the potential for severe mucosal damage and esophageal perforation, and the availability of superior alternatives. If glucagon therapy is attempted, an initial
 dose of  to  milligrams IV is given (for adults). If the food bolus is not passed in  minutes, an additional dose can be given.
COIN INGESTION
Many centers use endoscopy to remove esophageal coins in children. Removal with a Foley catheter is done under fluoroscopy, and advanced airway management should be immediately available. The patient is placed in the Trendelenburg position to prevent aspiration of the object. The catheter is passed down the esophagus beyond the object, the balloon inflated, and the catheter slowly withdrawn, bringing the object with it. Complications can
 include airway compromise and mucosal injury, although in experienced hands, the rate of these events is low.
BUTTON BATTERY INGESTION
A button battery lodged in the esophagus is a true emergency requiring prompt removal, because the battery may quickly induce mucosal injury and necrosis. Perforation can occur within  hours of ingestion. Morbidity caused by the battery is likely related to the flow of electricity through a locally
 formed external circuit. Lithium cells are associated disproportionately with adverse outcome, probably due to higher voltage.
Figure 77­3 outlines a management algorithm for button battery ingestion. Button batteries that have passed the esophagus can be managed expectantly, as long as follow­up in  hours can be ensured. Repeat films should be obtained at  hours to ensure that the cell has passed through the pylorus, which may not occur if the battery is of large diameter and/or the patient is <6 years old. Most batteries pass completely through the body within  to  hours, although passage can take longer. Any patient with symptoms or signs of GI tract injury requires immediate surgical consultation. The National Button Battery Ingestion Hotline (National Capital Poison Center, Washington, DC) at 202­625­3333 is a 24­hour/7­day­aweek resource for help in management decisions.
FIGURE 77­3. Algorithm for management of button battery ingestion. *Button batteries in the esophagus must be removed. Endoscopy should be used, if available.
The balloon catheter technique can be used if the ingestion occurred ≤2 hours previously, but it should not be used after this period, because it may increase the amount of damage to the weakened esophagus. †When the Foley technique fails or is contraindicated because >2 hours have elapsed, the button battery should be removed endoscopically. This may require transfer of the patient. ‡Acute abdomen, tarry or bloody stools, fever.
INGESTION OF SHARP OBJECTS
Sharp objects in the esophagus need immediate removal. Sharp objects may pass into the stomach spontaneously. Because intestinal perforation from ingested sharp objects that pass distal to the stomach is common, the American Society for Gastrointestinal Endoscopy guidelines recommend removal of sharp objects by endoscopy while they are in the stomach or duodenum. If intestinal perforation occurs, it is usually at the ileocecal valve.
If the object is distal to the duodenum at presentation and the patient is asymptomatic, the object’s passage should be documented with daily plain films. Surgical removal should be considered if  days elapse without passage. The development of symptoms or signs of intestinal injury (e.g., pain,
 emesis, fever, GI bleeding) requires immediate surgical consultation.
NARCOTICS INGESTION
Narcotic couriers (body packers) ingest multiple small packets of a drug in order to conceal transport. A favored packet is the condom, which may hold up to  grams of narcotic. These packets are often visible on plain films. Rupture of even one such packet may be fatal, and endoscopy is contraindicated because of the risk of iatrogenic packet rupture. If the packet(s) appears to be passing intact through the intestinal tract, observation until the packet reaches the rectum is the favored treatment. Some authors advocate the use of whole­bowel irrigation to aid the process.
Acknowledgment
We wish to acknowledge the work of Moss Mendelson, MD, for his authorship of this chapter in the previous edition.


