## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 46: Puncture Wounds and Bites
James Quinn
PUNCTURE WOUNDS
A puncture wound is defined as a wound whose depth is greater than its width. Injuries occur when great focal pressure is applied to a sharp object that can then penetrate the skin and deep tissues. Given the force and depth of penetration, puncture wounds are problematic regardless of location
,2 and are independently associated with higher incidence of infections and complications compared to other wounds. Despite a relatively innocuous appearance, puncture wounds carry a significant risk of infection and injury to underlying structures. Puncture wounds caused by high­pressure injection equipment and animal bites and those involving exposure to body fluids have the potential for unique complications.
PATHOPHYSIOLOGY
With puncture wounds, shear forces between the penetrating object and tissue result in tissue disruption, producing hemorrhage and devitalization of skin and underlying tissues. Inoculation of infectious organisms into the deeper tissues can occur from the penetrating object (with or without leaving
 behind a foreign body from the object or material that has been pierced) or from the skin surface. When the penetrating object is removed, a small skin wound often closes spontaneously, creating a favorable environment for the development of infection. The reported infection rate from plantar
,5 puncture wounds is approximately 6% to 11%. Furthermore, exploration of infected plantar puncture wounds results in foreign material being
  found in about 25% of patients. The rate of infection from puncture wounds associated with dog bites is about 10% to 11%.
Most soft tissue infections from puncture wounds are caused by gram­positive organisms. Staphylococcus aureus predominates, followed by other
,8­11 staphylococcal and streptococcal species. Puncture wounds over joints can penetrate the joint capsule and produce septic arthritis. Those that penetrate cartilage, periosteum, and bone can lead to osteomyelitis. Pseudomonas aeruginosa is the most frequent pathogen isolated from plantar
,10­12 puncture wound–related osteomyelitis, particularly when the injury occurs through the rubber sole of an athletic shoe. The source appears to be
Pseudomonas that colonizes the foam lining of athletic shoes. Infections from punctures caused by bites have unique pathogens discussed in more detail later in this chapter.
Difficulty in visualizing and cleaning to the full depth of the injury contributes to the higher risk for infection for puncture wounds compared with other
,14 traumatic lacerations. Other host and wound factors are associated with delayed healing and/or infection (Table 46­1).
TABLE 46­1
Risk Factors for Puncture Wound Complications
Patient characteristics
Elderly
Diabetes with or without microvascular complications
Immunocompromised (acquired immunodeficiency syndrome, steroids, chemotherapy)
Peripheral vascular disease
Wound characteristics
Contaminated with soil or debris
Bite wounds
Containing foreign body
Occurring outdoors

Occurring through a shoe and/or sock
Chapter 46: Puncture Wounds and Bites, James Quinn 
Deeper penetration (jumping, falling, running)
. Terms of Use * Privacy Policy * Notice * Accessibility
ASSESSMENT

Ask the patient about the time of injury and circumstances involved. Wounds >6 hours old with increasing pain and redness are likely infected. Falling or jumping onto an object or bites from powerful clenched jaws suggest deeper penetration with potential for greater injury. Footwear (for plantar injuries) or clothing through which the object passed increases the potential for foreign body retention and infection. Ask the patient to estimate the depth of penetration and about a foreign body sensation in the wound. Ask about postinjury care rendered before presentation and about host factors predisposing to infection.
Ask about the penetrating object. Materials such as wood, glass, teeth, or plastic are prone to break or splinter, leaving retained fragments in the wound and increasing the risk for infection. Thin objects, such as teeth, needles, or pins, can break off cleanly beneath the skin surface, leaving a fragment behind.
Examine the puncture wound site and the function of underlying structures. Note the size and location of the wound, condition of surrounding skin, and presence of foreign matter or devitalized tissue. Assess for proximity to underlying structures. Assess distal function of adjacent tendons and nerves and the integrity of distal perfusion. Ask about amount of bleeding or any pulsatile bleeding or numbness, as arteries and nerves tend to travel and get injured together. These symptoms can also give an idea of the depth of a puncture wound. This is especially important with puncture wounds
 of the hand and wrist.
Because the entire depth of a puncture wound cannot be reliably explored, assessment for a possible foreign body is complicated. Patient perception
,18 of a foreign body is modestly useful in predicting the presence of one. The practice of probing the wound with a blunt instrument to assess depth and the presence of a foreign body is of unproven utility, but may improve the ability to cleanse wounds.
DIAGNOSIS
Plain film radiographs using soft tissue visualization techniques are indicated in most puncture wounds, especially when the base cannot be visualized and there is any risk of a retained penetrating object. Unless there is concern for fracture, puncture wounds from knives can forgo imaging. Otherwise imaging is necessary in wounds with a concern for fracture, in wounds caused by materials prone to fragment, and whenever the patient reports a
 foreign body sensation (Table 46­2) (see Chapter , “Soft Tissue Foreign Bodies”). Plain radiographs will detect >90% of radiopaque foreign bodies >1 mm in diameter (Figure 46­1). Most organic substances, such as wood, thorns, and other plant matter, have radiodensities close to that of soft tissue and cannot reliably be detected in puncture wounds with plain radiographs.
TABLE 46­2
Indications for Imaging in Puncture Wounds
Plain radiographs
Suspicion of fracture
Infected wound
Wound caused by materials prone to fragment (wood, glass, etc.)
Foreign body sensation reported by patient
US
Organic, nonradiopaque material
Suspected abscess
CT or MRI
Suspected deep­space infection
Persistent pain after injury
Failure to respond to treatment
FIGURE 46­1. Puncture wound to heel. A. Physician enlarged the wound in an unsuccessful attempt to locate and remove foreign body. B. Radiograph showing retained foreign body.
US can identify some soft tissue foreign bodies, but the ability to detect small objects that might have been introduced through a puncture wound is
20­22 limited. US can be helpful with identifying an abscess and facilitating foreign body extraction.
CT can accurately detect most radiolucent foreign bodies and is the imaging modality to use when a retained foreign body is suspected but the plain radiograph does not show one. MRI provides excellent visualization of foreign bodies, but cannot be used to image metallic objects or objects containing certain minerals due to the production of ferromagnetic artifacts. CT or MRI is indicated in patients with deep­space infection, persistent pain after a puncture wound, or when superficial infections fail to respond to therapy (Table 46­2). Rubber from athletic shoes is difficult to visualize
 with any imaging modality.
TREATMENT
,8­13
Treatment recommendations for puncture wounds are largely based on anecdotal evidence and reviews of uncontrolled case series. Traditional wound­cleaning techniques are largely ineffective as a result of the small entrance wound that has often spontaneously sealed by the time of presentation. The occurrence of serious infections after puncture wounds leads some clinicians to recommend more aggressive wound debridement and irrigation, although there is no evidence that this treatment reduces the rate or severity of post–puncture wound infections. In general, the
,4,5 majority of puncture wounds have a benign course, and potentially catastrophic complications are uncommon. It is thus sensible to limit the most aggressive treatment to those wounds and patients at greatest risk of complications. Remember to update tetanus immunization if needed.
WOUND CLEANSING, IRRIGATION, AND DEBRIDEMENT

Uncomplicated clean punctures presenting <6 hours after injury require superficial wound cleansing and tetanus prophylaxis as indicated. Soaking of the wound in an antiseptic solution has no proven benefit other than perhaps keeping a tract open so any retained foreign material can migrate
 out. Low­pressure (e.g., approximately .5 psi) irrigation of wounds will assist in surface cleansing and allow visualization of the entrance site, but will not penetrate the puncture tract. High­pressure (e.g., approximately  psi) injection of irrigation fluid into the wound might penetrate the tract but
 has no proven benefit and theoretically could force foreign matter and bacteria deeper into the surrounding tissue.
Debridement or coring of the wound tract in clean wounds does not reduce infection or facilitate accurate diagnosis of deeper structural injury.
Adverse effects from debridement or coring include increased pain and a wound that is larger than the initial injury.
ANTIBIOTICS
The role for prophylactic antibiotics in the management of all wounds is controversial. Most studies lack power to determine significance or are so poorly done that using them in a meta­analysis is problematic. For punctures, the same problem exists. Despite the lack of adequately sized
 randomized controlled trials on the subject, there is general consensus that prophylactic antibiotics have benefit in some circumstances. Thus, antibiotic prophylaxis is recommended for use in high­risk patients with puncture wounds or in high­risk punctures such as plantar
26­29 punctures, punctures due to bites, or punctures with heavy contamination. High­risk patients includes those with diabetes or any
 immunosuppression.
If prophylactic antibiotics are used, agents typically used for established wound infection are recommended, such as a first­
 generation oral cephalosporin, amoxicillin–clavulanic acid, or a fluoroquinolone. Although methicillin­resistant S. aureus has become a
 common cause of skin and soft tissue infections, postinjury antibiotic prophylaxis to cover this pathogen is not necessary. For plantar puncture
 wounds through athletic shoes, an oral fluoroquinolone with antipseudomonal activity (e.g., ciprofloxacin) is recommended.
Agents such as trimethoprim­sulfamethoxazole and tetracycline can provide antistaphylococcal coverage but lack antipseudomonal activity. If antipseudomonal coverage is desired and oral fluoroquinolones are contraindicated, a combination of oral antistaphylococcal and parenteral antipseudomonal antibiotics (e.g., ticarcillin, ceftazidime, or cefepime) would be an acceptable albeit inconvenient choice.
COMPLICATIONS
Infectious complications of puncture wounds include cellulitis, localized abscess, deep soft tissue infection, and osteomyelitis. The hallmark of all complications is persistent pain. Patients with continued or increasing pain >48 hours after injury should undergo an evaluation for retained foreign body or abscess.
CELLULITIS
Cellulitis usually presents within  days after injury. The patient typically notes pain with or without swelling and redness. Physical examination may demonstrate tenderness, erythema at the site of injury, warmth, and swelling. Postinjury cellulitis is an indication for imaging to evaluate for a retained foreign body. Cellulitis is generally caused by streptococcal and staphylococcal skin flora and usually responds to a 7­ to 10­day course of a firstgeneration cephalosporin, antistaphylococcal penicillin, or clindamycin.
ABSCESS
Localized abscess is usually associated with a retained foreign body. Patients may note swelling and possibly drainage. A tender, warm, fluctuant mass can be palpated and further defined with US. Standard incision and drainage is generally curative. Where possible, the incision should be longitudinal or parallel to underlying tendons, vessels, or nerves. A short course of antibiotics is indicated if surrounding cellulitis, high­risk patient factors, or signs of systemic illness are present.
DEEP SOFT TISSUE INFECTION
Deep soft tissue infection is generally more painful than cellulitis or localized abscess. The key physical examination finding is tenderness, redness, or swelling remote from the puncture site. With plantar or palmar injuries, redness on the dorsum of the foot or hand, respectively, suggests a deepspace infection. CT or MRI is indicated. Treatment requires parenteral antibiotics and surgical exploration with drainage, excision of necrotic tissue, and irrigation of infected areas.
OSTEOMYELITIS
Osteomyelitis is the most disastrous consequence of puncture wounds, occurring in .1% to .0% of all plantar puncture wounds and perhaps with a
8­12 greater prevalence in forefoot punctures occurring through athletic shoes. Patients with osteomyelitis present later than patients with other
 infections, often >7 days after injury and sometimes after a period of symptomatic improvement. Pain is present in nearly every case, but the examination may be deceptively normal. Radiographs are normal in the early stages of osteomyelitis. Elevated erythrocyte sedimentation rate or C­
,31,32 reactive protein supports the diagnosis, but a normal value does not exclude osteomyelitis. The imaging modality most helpful in the diagnosis
 of osteomyelitis is MRI. Once the diagnosis is made, immediate surgical referral should be made. Antibiotic administration should be withheld pending discussion with the consultant, as pathogen identification is best done from cultures obtained during operative debridement. If antibiotics are necessary before surgery, staphylococcal and pseudomonal coverage is recommended.
DISPOSITION AND FOLLOW­UP
Cellulitis and localized abscesses are almost always treated on an outpatient basis with oral antibiotics or incision and drainage, respectively. Follow­
 up is recommended in  hours to assess response. Inpatient therapy is indicated when the patient has a significant systemic response to this localized infection, the infection is extensive, comorbidities or drug allergies preclude safe oral therapy, patients cannot tolerate oral medications, or patients cannot reliably care for the infection outside of the hospital setting. Deep soft tissue infection and osteomyelitis require admission, surgical intervention, and IV antibiotics.
SPECIAL CONSIDERATIONS
NEEDLESTICK INJURIES
34­36
Needlestick injuries are common among healthcare professionals, especially in nurses and physicians who perform invasive procedures.
Mechanical damage from needlestick injuries is essentially negligible. The major concerns are the risk of infection with hepatitis viruses and human immunodeficiency virus (HIV). The risk of infection in a nonimmune recipient after an inadvertent needlestick contaminated from an infectious source has been estimated to be negligible for hepatitis A, up to 37% to 62% for hepatitis B if the source was hepatitis B e
 antigen positive, about 2% for hepatitis C, and .3% for HIV.

Postexposure prophylaxis is available for hepatitis B and HIV, but not for hepatitis C. Recommendations for the assessment and management of occupational exposures to blood and body fluids (such as needlesticks) are complex and change frequently. Hospitals should have predetermined protocols endorsed by local infectious disease specialists that are readily available and periodically reviewed. Consensus recommendations for
 postexposure prophylaxis of HIV are updated regularly by the Centers for Disease Control and Prevention and are available from the Clinicians
Consultation Center, accessible via the Internet at http://nccc.ucsf.edu/clinician­consultation/pep­post­exposure­prophylaxis/ or by phone at the
PEPline at 1­888­448­4911. When available, the use of rapid HIV testing on the source (patient, blood, or fluid) can reduce the need for unnecessary prophylaxis in the exposed individual.
HIGH­PRESSURE INJECTION INJURIES
High­pressure injection injuries are caused by industrial equipment designed to force grease, paint, or other liquids through a small­diameter
38­43 nozzle at high pressures. When the nozzle is applied close to or directly on the skin surface, the high­pressure results in penetration of intact skin, forcing the material deep into the underlying structures and along fascial planes. The nozzle pressures for these devices are typically 5000 to ,000 psi for grease guns, 2000 to 6000 psi for diesel fuel injectors, and up to 5000 psi for paint and water sprayers. Such extreme pressure can lacerate skin and fracture bones (Figure 46­2). The type, amount, and viscosity of material injected will determine the degree of tissue inflammatory response, and in
,42 less distensible tissue compartments, sudden pressure elevations can produce vascular injuries, ischemic necrosis, and gangrene.
FIGURE 46­2. A. Skin and soft tissue injury of left index finger due to high­pressure water device. B. Radiograph showing fractures of metacarpal and proximal phalanx as well as subcutaneous air. [Photo contributed by J. S. Stapczynski, MD.]
Most high­pressure injection injuries occur in the nondominant hand of an operator using a trigger­activated gun. The initial injury may cause little pain and appear relatively innocuous, leading to delays in presentation and underappreciation of the extent of injury. Within hours, pain typically
39­42 becomes severe, with evidence of ischemia or spreading inflammation. Delays in initial management increase the risk of amputation or disability.
Despite an initial appearance that suggests only a minor injury (Figure 46­3), the history of high­pressure injection device use alone should prompt
39­42 immediate consultation with a hand surgeon.
FIGURE 46­3. A. High­pressure injection paint injury to index finger. B. Radiograph showing radiopaque material. [Photo contributed by J. S. Stapczynski, MD.]
ED evaluation includes assessment of neurovascular integrity and tendon function, pain management using IV opioids, prophylactic antibiotic coverage against skin flora, and tetanus prophylaxis as indicated. Radiographs will often demonstrate wide dissemination of radiopaque material as well as injected air along fascial planes (Figures 46­2 and 46­3). Digital nerve blocks should be avoided, as they may further increase pressure in finger compartments. The risk of subsequent amputation is reduced if surgical debridement is performed within 
,40,42 hours of the injury, especially in cases of organic solvents. For patients with high­pressure injection of water only into the hand, it may be possible to forgo exploration and manage with antibiotics, analgesics, and elevation, but that decision should be made in consultation with a hand
,44 specialist.
EPINEPHRINE AUTOINJECTOR INJURIES

Epinephrine autoinjector injuries occur most often to the finger. The typical scenario involves a patient who is unfamiliar with the proper use of
,47 the autoinjector or who errs as a result of the stress of the situation. Patients present with pain due to the needlestick, paresthesias, and
,49 epinephrine­induced vasospasm to the injected area. In the extreme, the entire digit can be blanched and cold. The intensity of digital ischemia and response to treatment can be assessed with digital pulse oximetry of the involved finger. The natural history of this injury is spontaneous
46­50 resolution over several hours, with a reported range of resolution from  to  hours. The published case reports sometimes express concern that
,52 the intense vasospasm can lead to tissue loss or gangrene, although the chance of this occurring appears rare. Additionally, patients sustaining
,52 accidental injection without acute symptoms or signs of ischemia do well. There is no clear evidence that active treatment is better than
 observation alone, although patients and physicians may be uncomfortable with a prolonged ischemic and painful finger.
Attempts to increase blood flow to the ischemic digit with massage, warm water immersion, amyl nitrite inhalations, metacarpal nerve block, or topical
,51 nitroglycerin paste application have no proven value. Subcutaneous phentolamine injection into the affected area is the one treatment
,48­51 consistently described that rapidly reverses digital ischemia from accidental epinephrine injection but is rarely indicated. Phentolamine doses described range from .5 to .0 milligrams, and response is usually seen within minutes. A mixture of .5 mL of standard phentolamine solution (5 milligrams/mL concentration) and .5 mL of 1% lidocaine solution will produce a 1­mL total volume containing .5 milligrams of phentolamine that can be subcutaneously injected directly through the site of autoinjector puncture. Once the ischemia is resolved, the patient can be discharged, as relapse appears very unlikely.
MAMMALIAN BITES
Most patients presenting for ED care of bite injuries have been bitten by domestic dogs or cats. In the United States, an estimated nearly  million
 people are bitten each year, approximately 800,000 seek medical attention, and  to  will die of their injuries. Children have greater potential for
54­57 ,56 serious injuries. Dogs that are specifically bred or trained for guard duty cause a disproportionate number of serious injuries and deaths.
GENERAL PRINCIPLES OF BITE WOUND MANAGEMENT

Complications from bite wounds include the mechanical injury inflicted by the bite itself, local bacterial infection, and systemic infection or illness. A large animal or multiple animals attacking a child or small adult can inflict severe injuries, including vascular damage and blunt or penetrating trauma.
Standard assessment and resuscitation protocols for trauma victims should be employed if the patient is seriously injured. Take particular care when assessing children with facial and scalp bites from large dogs, as there are numerous case reports of innocuous­looking wounds associated with skull
,60 penetration resulting in brain abscess and intracranial injuries. In most animal bite wounds, there is an isolated soft tissue injury, and wound
 management and prevention of infection are the key issues. A recent large observational study reported that the infection rate after a dog bite was about 5%, but if the wound was a puncture wound, it was four times more likely to become infected, and wounds that were sutured were three times
 more likely to become infected.

Meticulous examination and cleansing measures, including aggressive irrigation and debridement of devitalized tissue, are important. Determine the extent of underlying tissue damage, with special attention to the potential for penetration into joint spaces and tendon sheaths. Management of wounds involving the face, hands, or perineum can be challenging due to the close proximity of delicate structures. If there is suspicion of retained
 foreign material in the wound, such as animal teeth, imaging is needed.
63­65
Some bite lacerations can safely undergo primary repair (Table 46­3). If desired for cosmetic or functional reasons, a skilled practitioner can primarily close the wound with percutaneous sutures with a risk of postrepair wound infection of 5% to 15%, and we recommend antibiotic prophylaxis with amoxicillin–clavulanic acid if wound closure is desired. Otherwise nonclosure or delayed primary closure is applicable for the
,15 management of contaminated bite injuries, especially in areas other than the face (see Chapter , “Wound Closure”).
TABLE 46­3
Indications for Primary Closure of Mammalian Bite Wounds
Animal: dog
Location: face or scalp
Wound characteristics: simple and appropriate for single­layer closure, no devitalized tissue
Lack of underlying injury: no underlying fracture
Host: no systemic immunocompromising conditions
Case reports have described the occurrence of bacteremia, sepsis, and death after dog bites in immunocompromised individuals, most often due to
,67
Capnocytophaga canimorsus. Wound closure is associated with a small increased risk of local wound infection, but is unlikely to enhance the risk of serious systemic infection from Capnocytophaga (Table 46­4), unless the patient is immunodeficient or the wound is at high risk of infection. The current practice is to avoid primary wound closure in patients with systemic
 immunodeficiencies and higher­risk wounds (Table 46­5). High­risk wounds should be cleaned and debrided of devitalized tissue, with closure avoided, and dressed with a nonadherent wound dressing to maintain a moist environment for epithelial regeneration, with reevaluation in 
 to  hours. Prophylactic antibiotics are recommended for higher­risk patients and wounds at higher risk of infection (Tables 46­4 and 46­5).
TABLE 46­4
Common Bites and First­Line Treatment
Animal Organism First­Line Antibiotic
Cat Pasteurella multocida Amoxicillin­clavulanate
Bartonella henselae (cat­scratch fever) Azithromycin
Dog Pasteurella, streptococci, staphylococci, Amoxicillin­clavulanate
Capnocytophaga canimorsus
Human Eikenella, staphylococci, streptococci Amoxicillin­clavulanate, cephalexin
Herpes simplex (herpetic whitlow) Acyclovir or valacyclovir
Rats, mice, squirrels, gerbils Streptobacillus moniliformis (North America) or Amoxicillin­clavulanate
Spirillum minus/minor (Asia)
Livestock, large game animals Multiple organisms Amoxicillin­clavulanate or specific agent for disease
Brucella, Leptospira, Francisella tularensis
Bats, monkeys, dogs, skunks, raccoons, foxes (all Rabies Rabies immune globulin, rabies carnivores and omnivores) vaccine
Monkeys Herpes B virus (Cercopithecine herpesvirus) Acyclovir or valacyclovir
Freshwater Aeromonas spp., staphylococci, streptococci Fluoroquinolone or trimethoprimsulfamethoxazole
Saltwater Vibrio, staphylococci, streptococci Fluoroquinolone, doxycycline
TABLE 46­5
Wounds at Higher Risk of Infection
Cat or human bites
Livestock bites
Monkey bites
Puncture wounds
Hand or foot wounds
Bites in immunosuppressed patients
Wounds sustained in fresh or salt water
Signs of local infection when first evaluated
Heavily contaminated wounds that are older with devitalized tissue
Diabetes mellitus
CAT AND DOG BITES
LOCAL INFECTIONS
Mammalian saliva contains large concentrations of microorganisms, and bite wounds should be considered to be contaminated with pathogenic
 bacteria. The force of a bite, especially a clenching bite, can inoculate bacteria deep into the underlying tissue, leading to cellulitis, tenosynovitis, and septic arthritis. Most dog bite wounds are relatively superficial, and despite the inoculation of bacteria, only approximately 5% of dog
 bites will become infected.
,71
Cats have narrower, sharper teeth than dogs, giving them the ability to deliver infectious agents deeper into a small­bore puncture wound. Thus, up to 50% of cat bites that present for care will become infected if untreated, although the true rate of infection is unknown since most
,72 patients with cat bites do not present for care unless the bite appears infected (Figure 46­4). Infection after a cat bite is often due to Pasteurella
73­75 multocida (Table 46­4), particularly if the infection develops within  hours. Infected dog bites are just as likely to contain Pasteurella, as well as
,75 anaerobes, streptococcal, and staphylococcal species. Postexposure antibiotic prophylaxis of most bite wounds to prevent infection is
,76 controversial. The only evidence­based benefit for prophylactic antibiotics is with dog or cat bites of the hands, bites that involve punctures, or bite
,77 wounds that are closed.
FIGURE 46­4. Hand infection after a cat bite. Wound fluid culture grew Pasteurella multocida. [Photo contributed by J. S. Stapczynski, MD.]
A prudent approach is to use prophylactic antibiotics for higher­risk uninfected wounds. These include all cat bites, all bites in
 immunocompromised hosts, dog bite puncture wounds, hand wounds, and any injury undergoing surgical repair. A 3­ to 5­day course of an appropriate antimicrobial (Table 46­4) should be sufficient. Routine follow­up wound check is recommended in all but the most trivial cases. In lower­risk situations, counseling and advice regarding the lack of benefit from prophylactic antibiotics in addition to wound care precautions are warranted.
Amoxicillin­clavulanate is the antibiotic most commonly recommended for prophylaxis of uninfected wounds and for treatment of local infections
,58,72,76­78 following dog, cat, or human bites. However, penicillin V or ampicillin should be adequate for P. multocida infections and represent logical
 lower­cost alternatives for prophylaxis of cat bites. Penicillin­allergic patients should receive doxycycline or cefuroxime for cat bites and clindamycin plus a fluoroquinolone for dog bites. Cephalexin, dicloxacillin, erythromycin, or clindamycin should not be used alone for dog or cat bites, as they do not reliably cover Pasteurella species.
SYSTEMIC INFECTIONS
Capnocytophaga
Serious systemic infection after dog or cat bites is rare, but can develop days after the bite and is not necessarily accompanied by local bite wound
,79,80 infection. Capnocytophaga canimorsus produces a rare but fulminant bacteremic illness after a dog bite, with fatal multiorgan failure,
 particularly in splenectomized patients and those with alcoholism or other immunosuppressive disorders. Broad­spectrum antibiotics are indicated
 in concert with aggressive resuscitation. The virulence of this rare infection provides some justification for the prophylactic use of a penicillin­class agent in all immunocompromised patients bitten by dogs.
Cat­Scratch Disease
81­83
Cat­scratch disease is a clinical syndrome of regional lymphadenopathy developing  to  days after a cat bite or scratch. This chronic indolent
 infection caused by Bartonella henselae can result in painful, matted masses of lymph nodes. Mild constitutional symptoms are common, and nonlymphoid organs may be affected in approximately 10% of cases (Table 46­6). The causative bacteria cannot be easily cultured from human lymph
81­83 node tissue, so the diagnosis is usually made using a combination of epidemiologic, clinical, histologic, and/or serologic criteria.
TABLE 46­6
Organ Involvement in Cat Scratch Disease
Constitutional symptoms
Low­grade fever
Malaise and fatigue
Headache
Nausea and anorexia
Nonlymphoid organ involvement—often with prolonged fever
CNS: encephalopathy with headache, seizures, confusion, or altered mental status
Musculoskeletal: synovitis with joint pain and swelling
Lungs: pneumonitis with dyspnea and cough
Abdomen: granulomatous hepatitis or splenitis producing abdominal pain
Eyes: retinitis with vision loss
Most cases with only lymph node involvement resolve in  to  months, and therapy consists primarily of pain relief and reassurance. Large, painful, fluctuant nodes can be aspirated for symptomatic relief. Incision and drainage is to be avoided, as persistent fistula and scarring have been reported.
Antibiotics are not indicated in most cases, but in patients with severe painful lymphadenopathy, a 5­day course of azithromycin may speed resolution
 of adenopathy. Patients with systemic immunodeficiencies are susceptible to severe infection and bacteremia from B. henselae, so it is reasonable to treat immunodeficient patients with a 7­ to 10­day course of trimethoprim­sulfamethoxazole, ciprofloxacin, or rifampin. Patients with nonlymphoid organ involvement usually require admission for definitive evaluation and parenteral antibiotic treatment. The vast majority of patients, even those with multiorgan involvement, recover without sequelae.
HUMAN BITES
85­87
Human bites tend to be more serious than bites from domestic animals. The reasons are likely due to the nature of the event, location of the bite, and potential bacteria inoculated into the wound. Treatment recommendations are based on experience. All human bites should be treated as
 contaminated wounds. Patients with human bites often present for care late after injury. The closed­fist injury, incurred when a flexed knuckle strikes a human tooth in the course of an altercation, is a common human bite injury (see Chapter , “Arm, Forearm, and Hand Lacerations”). Most human bite wounds should not undergo primary closure, with the possible exception of wounds to the face, where primary closure is associated with a
,88 postrepair wound infection rate of approximately 10%.
Human bite wound infections are usually polymicrobial, and the most common organisms isolated are staphylococcal and streptococcal species.
Other pathogens include the species­specific gram­negative rod Eikenella corrodens. Cephalexin is cost effective and adequate as an initial agent;
,72 amoxicillin­clavulanate is an alternative, with prophylaxis recommended after all but the most trivial human bites. For established infections, parenteral agents of choice include ampicillin­sulbactam, cefoxitin, or piperacillin­tazobactam.
,90
Herpes simplex virus can cause local infection, termed herpetic whitlow, after a human bite or contact with infected saliva. The appearance is usually a painful coalescence of vesicles, typically on the distal phalanx (Figure 46­5). Vesicles usually resolve in  to  weeks. Treatment with oral acyclovir for  to  days or topical acyclovir ointment for  to  days may shorten the duration of the symptoms.
FIGURE 46­5. Herpes simplex virus infection: herpetic whitlow. Painful, grouped, confluent vesicles on an erythematous edematous base on the distal finger were the first (and presumed primary) symptomatic infection. [Reproduced with permission from Wolff K, Johnson RA, Saavedra AP, Roh EK (eds):
Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 8th ed. New York, NY: McGraw­Hill Education; 2017, Figure 27­35.]
RODENTS, LIVESTOCK, AND EXOTIC AND WILD ANIMALS
RODENTS
Patients often seek care or consultation after being bitten by a rodent. The injury is usually trivial, the risk of local wound infection is low, and rodents are not known to carry or transmit rabies, so standard wound care and reassurance should suffice. Of more concern is the potential zoonotic systemic
 infections carried by mice and rats. Rat­bite fever consists of two similar febrile illnesses occurring after a small percentage of bites from rats, mice, squirrels, or gerbils due to either Streptobacillus moniliformis (more common in North America) or Spirillum minus/minor (more common in
,93
Asia). Infection can also result from exposure to rat feces or urine. The incubation period for the streptobacillary form is typically  to  days, whereas it is usually longer than  days for the spirillary variety. Onset is typically with rigors and fevers and progresses to migratory polyarthralgia and a maculopapular petechial or purpuric rash. Infection can spread to the heart, brain, arteries, liver, kidneys, and lungs. The mortality rate for untreated infection is 10% to 15%. Treatment is with IV penicillin for  to  days followed by oral penicillin for an additional  days. Doxycycline or tetracycline is used for penicillin­allergic patients.
LIVESTOCK AND LARGE GAME ANIMALS

Livestock and large game animals can inflict serious tissue injury with their powerful jaws and grinding teeth. The risk of wound infection is significant, and systemic illnesses, such as brucellosis, leptospirosis, or tularemia, can follow the injury. Aggressive wound care, imaging to detect fractures, and prophylactic broad­spectrum antibiotics are recommended. A febrile illness after such a bite usually requires inpatient antibiotic
 therapy guided by blood culture results.
FRESHWATER AND SALTWATER WOUNDS
Freshwater fish bite infections can be due to Aeromonas, streptococci, and staphylococci, and treatment is with a fluoroquinolone or trimethoprimsulfamethoxazole. Saltwater fish bites or lacerations require coverage for Vibrio, usually with a fluoroquinolone or doxycycline.
SYSTEMIC VIRAL INFECTIONS
Disseminated viral illnesses resulting from mammalian bites include rabies, hepatitis, herpes B virus, and HIV. The risk of infection is variable depending on the number of infectious organisms in the saliva of the biting animal.
Most human rabies cases identified in the United States were acquired from contact with bats while in the United States or from dog bites sustained while traveling abroad (see Chapter 158, “Rabies,” for detailed discussion). Local public health agencies and the state veterinarian are good sources of information regarding the rabies risk from contact with specific indigenous animals and recommended postexposure prophylaxis with immunoglobulin and vaccine.
B virus, also called herpes B, is caused by Macacine herpesvirus  and can be transmitted by bites from monkeys and other nonhuman primates,
94­97 although only monkeys of the macaque family serve as the natural reservoir for B virus infection. Human infection with B virus causes myelitis and hemorrhagic encephalitis, with a case fatality rate of 70%. Those at greatest risk for B virus infection are veterinarians, laboratory workers, and others who have close contact with macaques or monkey cell cultures. After a bite or wound from a macaque, immediately and thoroughly wash and gently scrub the area or wound with soap, concentrated solution of detergent, povidone­iodine, or chlorhexidine and water for  minutes, and then irrigate the washed area with running water for  to  minutes to reduce the chance of infection. Consultation with an infectious disease expert is strongly advised before beginning antiviral therapy. The Centers for Disease Control and Prevention maintains a website with current B virus information at

(http://www.cdc.gov/herpesbvirus/index.html). Acyclovir or valacyclovir started immediately after injury can prevent or ameliorate this illness.
Viral hepatitis and HIV can both be transmitted by a human bite, although HIV viral concentration in nonbloody saliva is thought to be relatively low. A protocol similar to that for an occupational needlestick injury should be used when a patient sustains a bite from a high­risk source (see Chapter 155, “Human Immunodeficiency Virus Infections”).


