## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 171: Seizures and Status Epilepticus in Adults
Josh Kornegay
INTRODUCTION AND PATHOPHYSIOLOGY
Content Update October 2023
Updates are provided in Tables 171­2 and 171­3 to provide additional information on seizure risk factors and treatment of Status Epilepticus. Figure
171­1 has been replaced by Table 171­3. Also see Differential Diagnosis: Cardiac electrical instability or chanellopathies.
A seizure is an episode of abnormal neurologic function caused by inappropriate electrical discharge of brain neurons. Neuronal electrical discharge, in its most simple form, can be thought of as the homeostasis of glutaminergic (excitatory) and γ­aminobutyric acid (inhibitory) activity. The seizure is the clinical attack in the setting of inappropriate excitatory activity. Some patients with “epileptic” electroencephalographic (EEG) discharges may not experience any overt clinical symptoms. Some seizure­like episodes may be due to causes other than abnormal brain electrical activity, but such attacks are not true seizures.
Epilepsy is a clinical condition in which an individual is subject to recurrent seizures. It implies a fixed, excitatory condition of the brain with a lower seizure threshold. The term epileptic does not refer to an individual with recurrent seizures caused by reversible conditions such as alcohol withdrawal or metabolic derangements.
Primary or idiopathic seizures are those in which no evident cause can be identified. Secondary seizures are a consequence of an identifiable neurologic condition, such as a mass lesion, previous head injury, or stroke. Electrical stimulation of the brain, convulsant potentiating drugs, profound metabolic disturbances, or significant head trauma all may cause reactive seizures in otherwise normal individuals. Reactive seizures are generally self­limited and not considered to be a seizure disorder or epilepsy.
Additional definitions of seizures are based on clinical factors or duration: status epilepticus is seizure activity ≥5 minutes, or two or more seizures
 without regaining consciousness or returning to one's neurologic baseline between seizures ; refractory status epilepticus is persistent seizure activity despite the IV administration of adequate amounts of two antiepileptic agents.
SEIZURE CLASSIFICATION
The International League Against Epilepsy recommends dividing seizures into two major groups: generalized seizures and partial seizures (Table
171­1). When there are inadequate data to categorize the seizure, the seizure is considered unclassified.
TABLE 171­1
Classification of Seizures
Generalized seizures (consciousness always lost)
Tonic­clonic seizures (grand mal)
Absence seizures (petit mal)
Others (myoclonic, tonic, clonic, or atonic seizures)
Partial (focal) seizures
Simple partial (no alteration of consciousness)
Downloaded 20C2o5m­7p­l1ex  p:a2r3ti aPl ( cYonosucri oIuPs nise s1s3 im6.p1a4ir2e.d1)59.127
Chapter 171: Seizures and Status Epilepticus in Adults, Josh Kornegay 
Partial seizures with secondary generalization (Jacksonian march)
. Terms of Use * Privacy Policy * Notice * Accessibility
Unclassified (inadequate information)
GENERALIZED SEIZURES
Generalized seizures are thought to be caused by near simultaneous activation of the entire cerebral cortex, perhaps caused by an electrical discharge originating deep in the brain and spreading outward. The attacks begin with abrupt loss of consciousness, and this may be the only clinical manifestation of the seizure (as in absence attacks), or there may be a variety of motor manifestations (tonic posturing, clonic jerking of the body and extremities).
Generalized tonic­clonic seizures are the most familiar and dramatic of the generalized seizures. In a typical attack, the patient suddenly becomes rigid (tonic phase), trunk and extremities are extended, and the patient falls to the ground. As the tonic phase subsides, there are increasing coarse movements that evolve into a symmetric, rhythmic (clonic) jerking of the trunk and extremities. Patients are often apneic during this period and may be cyanotic. They often urinate and may vomit. As the attack ends, the patient is left flaccid and unconscious, often with deep, rapid breathing. Typical attacks last from  to  seconds; bystanders generally overestimate the duration of the seizure. Consciousness returns gradually, and postictal confusion, myalgias, and fatigue may persist for several hours.
Absence seizures are very brief, generally lasting only a few seconds. Patients suddenly develop altered consciousness but no change in postural tone. They appear confused or detached, and current activity ceases. They may stare or have twitching of the eyelids. They may not respond to voice or to other stimulation, exhibit voluntary movements, or lose continence. Attacks cease abruptly, and the patients typically resume previous activity without postictal symptoms. Patients and witnesses may be unaware that anything has happened. Classic absence seizures occur in school­aged children and are often attributed by parents or teachers to daydreaming or inattention. The attacks can occur as frequently as 100 or more times daily and may result in poor school performance. They usually resolve as the child matures. Similar attacks in adults are more likely to be minor complex partial seizures and should not be termed absence. The distinction is important because the causes and treatment of the two seizures are different.
PARTIAL (FOCAL) SEIZURES
Partial seizures are due to electrical discharges beginning in a localized region of the cerebral cortex. The discharge may remain localized or may spread, involving nearby cortical regions or the entire cortex. Focal seizures are more likely to be secondary to a localized structural lesion of the brain.
In simple partial focal seizures, the seizure remains localized, and consciousness is not affected. It is possible to deduce the likely location of the initial cortical discharge from the clinical features at the onset of the attack. For example, unilateral tonic movements limited to one extremity suggest a focus in the contralateral motor cortex, whereas visual symptoms suggest an occipital focus. Olfactory or gustatory hallucinations suggest a focus in the medial temporal lobe. Such sensory phenomena, known as auras, are often the initial symptoms of attacks that then become more widespread, termed secondary generalization.
Complex partial seizures are focal seizures in which consciousness or mentation is affected. They are often caused by a focal discharge originating in the temporal lobe and are sometimes referred to as temporal lobe seizures. Complex partial seizures are commonly misdiagnosed as psychiatric problems because symptoms can be so bizarre. Symptoms may include automatisms, visceral symptoms, hallucinations, memory disturbances, distorted perception, and affective disorders. Common automatisms include lip smacking, fiddling with clothing or buttons, or repeating short phrases. Visceral symptoms often consist of a sensation of “butterflies” rising up from the epigastrium. Hallucinations may be olfactory, gustatory, visual, or auditory. There may be complex distortions of visual perception, time, and memory. Affective symptoms may include intense sensations of fear, paranoia, depression, elation, or ecstasy. Because such seizures result in alterations of thinking and behavior, they were previously referred to as psychomotor seizures, but to avoid confusion with psychiatric illness, the term complex partial seizure is preferred.
Focal seizures may spread to involve both hemispheres, mimicking a typical generalized seizure. For the purpose of classification, diagnosis, and treatment, such attacks are still regarded as focal seizures. In some patients, the discharge may spread so rapidly that no focal symptoms are evident, and the correct diagnosis may depend entirely on demonstration of the focal discharge on an EEG recording.
CLINICAL FEATURES
HISTORY
When a patient presents after the event, the first step is to determine whether the episode was truly a seizure. Obtain a careful history of the details of the attack from the patient and any bystanders who witnessed the attack. Inquire about the physical description of the attack, as witnesses may mislabel the activity and mistake nonseizure activity as a seizure.
Important avenues of inquiry include the presence of a preceding aura, abrupt or gradual onset, progression of motor activity, loss of bowel or bladder control, presence of oral injury, and whether the activity was localized, generalized, symmetric, or asymmetric.
Ask about the duration of the episode, and determine the presence of postictal confusion or lethargy.
Next, determine the clinical context of the episode. If the patient is a known epileptic, clarify the baseline seizure pattern. If the attack is consistent with the previous seizure pattern, identify precipitating factors of the current seizure. Common precipitating factors include missed doses of antiepileptic medications; recent alterations in medication, including dosage change or conversion from brand name; weight changes; sleep deprivation; increased strenuous activity; infection; electrolyte disturbances; and alcohol or substance use or withdrawal.
If there is no previous history of seizures, a more detailed inquiry is needed. Symptoms such as unexplained injuries, nocturnal tongue biting, or enuresis suggest previous unrecognized seizures. Ask about a history of recent or remote head injury. Persistent, severe, or sudden headache suggests intracranial pathology. Pregnancy or recent delivery raises the possibility of eclampsia. A history of metabolic or electrolyte abnormalities, hypoxia, systemic illness (especially cancer), coagulopathy or anticoagulation, exposure to industrial or environmental toxins, drug ingestion or withdrawal, and alcohol use may point to predisposing factors (Table 171­2).
TABLE 171­2
Common Causes of Provoked (Secondary) Seizures
Trauma (recent or remote)
Intracranial hemorrhage (subdural, epidural, subarachnoid, intraparenchymal)
Vascular lesion (aneurysm, arteriovenous malformation)
Mass lesions (primary or metastatic neoplasms)
Degenerative neurologic diseases
Congenital brain abnormalities
Infection (meningitis, encephalitis, abscess)
Hypo­ or hyperglycemia
Hypo­ or hypernatremia
Hyperosmolar states
Uremia
Hepatic failure
Hypocalcemia, hypomagnesemia (rare)
Cocaine, lidocaine, antidepressants, theophylline, isoniazid
Mushroom toxicity (Gyromitra spp.)
Hydrazine (rocket fuels)
Alcohol or drug withdrawal
Eclampsia of pregnancy (may occur up to  weeks postpartum)
Hypertensive encephalopathy
Anoxic­ischemic injury (cardiac arrest, severe hypoxemia)
Chanellopathies
PHYSICAL EXAMINATION
Immediately obtain a complete set of vital signs and a point­of­care glucose. In the post­seizure setting, focus the initial exam on checking for injuries, especially head or spine trauma, as a result of the seizure. A posterior shoulder dislocation is an injury that is easy to overlook. Lacerations of the tongue and mouth, dental fracture, and pulmonary aspiration are also frequent sequelae.
Perform a directed, complete neurologic examination and subsequent serial examinations. Follow the patient’s level of consciousness and mentation closely to avoid missing nonconvulsant status epilepticus (see below). A transient focal deficit (usually unilateral) following a simple or complex focal seizure is referred to as Todd’s paralysis and should resolve within  hours.
DIAGNOSIS
Clinical features that help to distinguish seizures from other nonseizure attacks include the following:
Abrupt onset and termination. Some focal seizures are preceded by auras that can last  to  seconds, but most attacks begin abruptly.
Episodes reported to develop over several minutes or longer should be regarded with suspicion. Most seizures last only  or  minutes, unless the patient is in status epilepticus.
Lack of recall. Except for simple partial seizures, patients usually cannot recall the details of an attack.
Purposeless movements or behavior during the attack.
Most seizures are followed by a period of postictal confusion and lethargy.
DIFFERENTIAL DIAGNOSIS
Many episodic disturbances of neurologic function may be mistaken for seizures (seizure mimics). A complete review of these conditions is too lengthy for inclusion here, but several important entities are mentioned.
Syncope usually presents with prodromal symptoms, such as lightheadedness, diaphoresis, nausea, and “tunnel vision.” However, cardiac syncope may occur suddenly without any prodromal warning. Syncope may be associated with injury, incontinence, or even brief tonic­clonic activity. Recovery is usually rapid, with no postictal­like symptoms. For further discussion, see Chapter , “Syncope.”
Pseudoseizures can be difficult to distinguish from true seizures and may occur in a patient who also has a documented seizure disorder.
Pseudoseizures are psychogenic in origin and are often associated with a conversion disorder, panic disorder, psychosis, Munchausen syndrome, or malingering. Suspect this diagnosis when seizures occur in response to emotional upset or occur only with witnesses present. Pseudoseizures are often bizarre and highly variable. Patients often are able to protect themselves from noxious stimuli during the attack. Characteristic movements include side­to­side head thrashing, pelvic thrusting, and clonic alternating extremity motions rather than symmetric. Incontinence and injury are uncommon, and there is usually no postictal confusion. Patients will often stop the seizure­like activity on command. Accurate diagnosis of pseudoseizures may require prolonged EEG or video monitoring to demonstrate normal EEG activity during an attack. The lack of a lactic acidosis or
,3 elevated prolactin level within  to  minutes of the cessation of seizure­like activity makes true seizures much less likely.
Hyperventilation syndrome can be misdiagnosed as a seizure disorder. A careful history will reveal the gradual onset of the attacks with shortness of breath, anxiety, and perioral numbness. Such attacks may progress to involuntary spasm (especially carpopedal) of the extremities and even loss of consciousness, although postictal symptoms are rare. Asking the patient to hyperventilate often reproduces the episodes.
Movement disorders, such as dystonia, chorea, myoclonic jerks, tremors, or tics, may occur in a variety of neurologic conditions. Consciousness is always preserved during these movements, and the patient can often temporarily suppress the movements.
Migraine headaches may be preceded by an aura similar to that seen in some partial seizures. The most common migraine aura is the scintillating scotoma. Migraine headaches may also be accompanied by focal neurologic symptoms, such as homonymous hemianopsia or hemiparesis. However, active movement disorders are inconsistent with migraine.
Cardiac electrical instability or chanellopathies can result in a seizure. Risk factors include severe hypoglycemia, electrolyte derangements,
49­52 bradycardias, Brugada syndrome, and long/short QT syndrome. Diagnosis is difficult and may only be identified by careful assessment and prolonged cardiac monitoring.
LABORATORY TESTING
Individualize the use of laboratory studies. In a patient with a well­documented seizure disorder who has had a single unprovoked seizure, the only tests that may be needed are a glucose level and pertinent anticonvulsant medication levels.
In the case of an adult with a first seizure or unclear seizure history, more extensive studies are usually needed and depend on the clinical context.
Obtain serum glucose, basic metabolic panel, lactate, calcium, magnesium, a pregnancy test, and toxicology studies. Consider assays for
 anticonvulsant drug levels. A seizure may result in a lactate­driven, wide anion gap metabolic acidosis. Most lactate abnormalities will clear within  minutes, and serial lactate levels can be helpful if other lactate­producing pathology, such as sepsis, is suspected. The prolactin level may also be
 elevated for a brief period (15 to  minutes) immediately after a seizure. These tests can prove helpful in distinguishing true seizures from a pseudoseizure.
Interpret the results of anticonvulsant levels with caution. If patient history is limited, a positive serum assay for anticonvulsant drugs suggests (but does not prove) the presence of a chronic seizure disorder. The usual therapeutic and toxic levels indicated in laboratory reports are helpful only as rough guides. The therapeutic level of a drug is the level that provides adequate seizure control without unacceptable side effects. A marked change in previously stable drug levels may indicate noncompliance, a change in medication, malabsorption of a drug, or ingestion of a potentiating or competing drug. A very low serum anticonvulsant drug level suggests medication noncompliance and is the most common cause of a breakthrough seizure.
IMAGING
Obtain a CT scan of the head in the ED for patients with a first­ever seizure or a change in established seizure patterns to evaluate for a structural
,5 lesion. A noncontrast CT is an appropriate screening tool. Obtain a CT scan if there is any concern for an acute intracranial process based on history, comorbidities, or findings on physical examination. Concern for an acute intracranial process is an important indication for obtaining CT imaging, even if there is a coexistent metabolic process.
Because many important processes, such as tumors or vascular anomalies, may not be evident on noncontrast studies, a follow­up contrast­enhanced
CT or MRI is often needed. Almost one quarter of adults with new­onset seizure will have visualized pathology on follow­up MRI, with rates increasing
 to as high as 53% in those with onset of a focal seizure. The timing of further imaging studies can be discussed with the consulting neurologist.
Obtain other radiographic studies as indicated by the clinical presentation to avoid missing other sequela as a result of the seizure. These may include chest radiographs, cervical spine radiographs, or musculoskeletal imaging if aspiration or injuries are suspected. Special examinations, such as cerebral angiography, are rarely part of the ED evaluation.
LUMBAR PUNCTURE
Lumbar puncture in the setting of an acute seizure is indicated if the patient is febrile or immunocompromised or if subarachnoid hemorrhage is suspected and the noncontrast head CT is normal. For further discussion, see Chapter 166, “Spontaneous Subarachnoid and Intracerebral
Hemorrhage,” and Chapter 174, “Central Nervous System and Spinal Infections.”
ELECTROENCEPHALOGRAPHY
Although EEG is helpful, it is often not readily available in most EDs. Emergent EEG can be considered in the evaluation of a patient with persistent, unexplained altered mental status to evaluate for nonconvulsive status epilepticus, subtle status epilepticus, paroxysmal attack when a seizure is suspected, or ongoing status epilepticus after chemical paralysis for intubation. Emergent EEG is normally performed in consultation with a neurologist.
TREATMENT OF UNCOMPLICATED SEIZURES
PATIENTS WITH ACTIVE SEIZURES
Typically, little is required during the course of an active seizure other than supportive and patient protective measures. If possible, turn the patient to the side to reduce the risk of aspiration. It is usually not necessary or even possible to ventilate a patient effectively during a seizure, but once the attack subsides, clear the airway. Suction and airway adjuncts should be readily available. It is not necessary or recommended to give IV anticonvulsant medications during the course of an uncomplicated seizure, although the practitioner should be ready to administer these medications if seizures do not terminate. Most seizures will self­resolve within  minutes. Any unnecessary sedation at this
 point will complicate the evaluation and result in a prolonged decrease in level of consciousness. Seizures that fail to abate after  minutes are considered status epilepticus and require more aggressive medical interventions (see “Status Epilepticus,” below).
PATIENTS WITH A HISTORY OF SEIZURES
Proper management of a patient with a well­documented seizure disorder who presents after one or more seizures depends on the particular circumstances of the case. Identify and correct potential precipitants that may lower the seizure threshold. Many seizures occur due to medication nonadherence. Some anticonvulsants have very short serum half­lives, and missing a single dose may result in a sharp drop in serum levels. If anticonvulsant levels are very low, supplemental doses are appropriate, and the regular regimen can be restarted or adjusted. A loading dose is frequently provided. Without a loading dose, the patient may not achieve anticonvulsant effects for days to weeks and is at risk for subsequent
 seizures. Because there are no data comparing parenteral versus oral replacement, route is left to the discretion of the medical provider and should be based on knowledge of pharmacology. For example, the oral loading dose of phenytoin is  milligrams/kg given in three divided doses every  to  hours—a time frame not acceptable for a typical ED stay—so the IV route is needed to achieve the proper loading dose.
In the noncompliant patient, obtain a serum anticonvulsant level before administering a supplemental or loading dose to avoid drug toxicity. If anticonvulsant levels are adequate and the patient has had a single seizure, specific treatment may not be needed if the seizure pattern and frequency fall within the expected range for the patient. If anticonvulsant levels are not available (i.e., levetiracetam or lacosamide) and there is a missed dose or noncompliance, give the usual dose in the ED before discharge.
Even well­controlled patients may have occasional breakthrough seizures. Attempt to identify any precipitants that have lowered the seizure threshold.
If none is found, a change or adjustment of medication may be needed and should be made in consultation with the patient’s primary care physician or neurologist along with follow­up in  to  days. There are no specific guidelines for the duration of ED observation in the situation of an individual with a prior history of seizures. Some clinicians discharge patients with seizures resulting from nontherapeutic anticonvulsant levels after administration of a loading dose of an anticonvulsant, if vital signs are normal and the mental status has returned to baseline. Ideally, discharge patients with a reliable family member or friend and with medical follow­up arranged.
PATIENTS WITH A FIRST UNPROVOKED SEIZURE
Guidelines do not recommend hospital admission or initiation of anticonvulsant therapy in the patient with a first unprovoked seizure, as long as the
,8 patient has returned to neurologic baseline. The most important predictors of seizure recurrence are the underlying cause of the seizure and the results of the EEG. The decision to begin outpatient treatment with antiepileptics depends on the risk of recurrent seizures weighed against the riskbenefit ratio of anticonvulsant therapy. In general, patients with a first unprovoked seizure who have a normal neurologic examination, no acute or chronic medical comorbidities, normal diagnostic testing including noncontrast head CT, and normal mental status can safely be discharged from the
ED. Initiation of antiepileptic medication may be deferred to the outpatient setting where further studies, including an EEG and MRI, can be
,4,8 performed. Consider consultation and/or admission for patients who do not meet the above criteria.
Patients with secondary seizures due to an identifiable underlying condition (Table 171­2) often require admission and should generally be treated to minimize seizure recurrence.
The ideal initial antiepileptic regimen is a single­drug therapy that controls seizures with minimum toxicity. If treatment is initiated, drug selection is based on the type of seizure and should be done in consultation with a neurologist. Antiepileptic agents, such as valproate, lamotrigine, topiramate,
,9 levetiracetam, and oxcarbazepine, are options for adults with new­onset seizures. Consider developing common protocols between emergency medicine and neurology when treatment of new­onset seizures is initiated from the ED.
Instruct discharged patients to take precautions to minimize the risks of injury from further seizures. Swimming, working with hazardous tools or machines, and working at heights should be avoided. Driving is prohibited until cleared by the neurologist or primary care physician. Driving privileges should conform to state law, and it may be up to the emergency physician to document seizure activity with the Department of Motor Vehicles.
SPECIAL POPULATIONS
HUMAN IMMUNODEFICIENCY VIRUS
Mass lesions, encephalopathy, herpes zoster, toxoplasmosis, Cryptococcus, neurosyphilis, and meningitis are all seen more frequently in this
,11 population and can all provoke seizure activity.
Perform an extensive investigation for the cause of the seizure. If no space­occupying lesion is identified on noncontrast head CT scan and there is no evidence of increased intracranial pressure, perform a lumbar puncture to exclude CNS infection. If no explanation for seizures is found, then obtain a contrast­enhanced head CT or MRI.
NEUROCYSTICERCOSIS
Neurocysticercosis is caused by a CNS infection with the larval stage of the tapeworm Taenia solium and is the most common cause of provoked

(secondary) seizures in the developing world. The most common form of disease is parasitic invasion of brain parenchyma and cyst formation. Over
 to  years, the cyst degenerates and becomes fibrotic, leaving a focal area of scar and calcification. Seizures are the most common clinical manifestation of neurocysticercosis and most frequently occur as the parasite is degenerating. In 80% to 90% of cases, the lesions resolve within  to  months, leaving the patient free of seizures. Up to 20% of patients will continue to have seizures and require ongoing therapy with antiepileptic
 medications.
In most cases, neuroimaging in neurocysticercosis is nondiagnostic. CT or MRI may demonstrate a 1­ to 2­cm cystic lesion with thin walls and a 1­ to 3­ mm mural nodule (the parasite), a localized area of ring­like enhancement with surrounding edema, a calcified lesion, or hydrocephalus. Definitive diagnosis relies on a combination of the patient’s clinical picture, exposure history, serologic testing, and neuroimaging.
Seizures in neurocysticercosis are typically controlled by antiepileptic monotherapy. Definitive treatment of neurocysticercosis is
,14 controversial and highly variable, depending on the number, location, and viability of the parasites within the CNS. Antiparasitics (praziquantel and albendazole) and steroids are best initiated in consultation with an infectious disease specialist or neurologist.
PREGNANCY
The management of seizures (or control of epilepsy) during pregnancy requires a multidisciplinary approach. Most seizures in pregnancy are not firsttime seizures, and initial evaluation is generally as discussed above, with the addition of an obstetric evaluation to determine gestational age and fetal well­being.
When a woman beyond  weeks of gestation develops seizures in the setting of hypertension, edema, and proteinuria, the diagnosis is eclampsia. Magnesium sulfate is the treatment. In eclampsia, magnesium sulfate infusion compared to diazepam and phenytoin
15­ resulted in a >50% reduction in recurrence of seizures and a lower incidence of pneumonia, intensive care unit admission, and assisted ventilation.

Detailed discussion of seizures in pregnancy is provided in Chapter 100, “Maternal Emergencies After  Weeks of Pregnancy and in the Peripartum
Period.”
ALCOHOL ABUSE
Seizures and alcohol use are associated through missed doses of medication, sleep deprivation as an epileptogenic trigger, increased propensity for head injury, toxic coingestions, electrolyte abnormalities, and withdrawal seizures. Benzodiazepines in doses sufficient to manage withdrawal symptoms will usually afford adequate protection from acute seizures. These doses are often very large and need to be given in an escalating
 fashion. Phenobarbital is also a reasonable choice and may have a more predictable pharmacologic profile with less adverse effects when compared
,55 to benzodiazepines. Evaluate and treat the alcohol­abusing patient with a first seizure as any other patient with a first­time seizure. Detailed discussion of alcohol withdrawal seizures is provided in Chapter 292, “Substance Use Disorders.”
STATUS EPILEPTICUS
Status epilepticus can occur in patients with a history of seizures or can be a first epileptic event. The most common causes of status epilepticus include subtherapeutic antiepileptic levels; preexisting neurologic conditions, such as prior CNS infection, trauma, or stroke; acute stroke; anoxia or
 hypoxia; metabolic abnormalities; and alcohol or drug intoxication or withdrawal.
Status epilepticus is a single seizure ≥5 minutes in length or two or more seizures without recovery of consciousness between
,20,21 seizures. After  minutes, seizures are less likely to spontaneously terminate, less likely to be controlled with antiepileptic drugs, and more likely to cause neuronal damage. Status epilepticus is a neurologic emergency, and treatment should be initiated in all patients with continuous seizure activity lasting more than  minutes.
As seizures surpass the 5­minute mark, dramatic changes occur at the cellular level. Decreased expression and internalization of γ­aminobutyric acid receptors, coupled with increased expression of both glutamine and N­methyl­D­aspartate receptors, lead to a greatly diminished seizure
,23 threshold. The blood–brain barrier is also compromised, leading to CNS penetration of potassium and albumin, both of which are hyperexcitatory

CNS chemicals. After  minutes, hypotension, hypoxia, metabolic acidosis, hyperthermia, hypoglycemia, cardiac dysrhythmias, and pulmonary
 edema frequently develop. This hyperexcitatory milieu makes standard antiseizure therapies much less effective in seizure termination.
In nonconvulsive status epilepticus, the patient is comatose or has fluctuating abnormal mental status or confusion, but no overt seizure activity is present. The diagnosis is challenging and is typically made by EEG. Findings suggestive of nonconvulsive status epilepticus include a prolonged postictal period after a generalized seizure; subtle motor signs such as twitching, blinking, and eye deviation; fluctuating alterations in mental status;
 or unexplained stupor and confusion.
TREATMENT OF STATUS EPILEPTICUS
Early recognition and treatment of status epilepticus are critically important. Mortality dramatically increases with delayed diagnosis or initiation of
 treatment, particularly with nonconvulsive status epilepticus, age greater than  years, and in patients with no documented seizure disorder. The goal of treatment is seizure control as soon as possible and within  minutes of presentation (Table 171­3). Examination, identification of potential causes, application of the ABCs (airway, breathing, and circulation), and treatment all begin simultaneously. Direct a focused history and physical examination toward possible causes and subsequent injuries. Protocols may exist in a variety of institutions that vary slightly. For treatment of Status
Epilepticus in Children, see Chapter 138, Fig 138­3. TABLE 171­3
Treatment of Status Epilepticus in Adults53
Time Goals Actions Medication Dosage
0–5 minutes ABCs, continuous cardiac Obtain stat POC  milliliters D50W
Stabilization phase monitoring, establish IV or IO glucose Hypoglycemic patients without IV access can be given  milligram access Assess for glucagon IM; may repeat until desired effect
Laboratory studies underlying Maintain oxygenation > 90%
ECG hypoxic/ischemic event
5–10 minutes Give first dose of benzodiazepine Lorazepam .1 milligrams/kg IV or IO (max.  milligrams)
Initial therapy
Midazolam .2 milligrams/kg or  milligrams IM;  milligrams IN (5 milligrams per nostril)
Diazepam .15 milligrams/kg IV/IO, max.  milligrams; .2 milligrams/kg PR
(max.  milligrams)
If no response to Give first dose of antiseizure Levetiracetam  milligrams/kg IV or IO (max. 4500 milligrams) initial medication benzodiazepine dose
Valproate  milligrams/kg IV or IO (max. 3000 milligrams)
Fosphenytoin  milligrams/kg IV PE (phenytoin equivalent) over  min
If phenytoin is the only agent available, give  milligrams/kg IV, at ≤
 milligrams/min, with BP monitoring q 5­15 min. Takes up to  h to administer
10–20 minutes Give second dose of a benzodiazepine
Consider giving a second antiseizure medication
≤30 minutes If not intubated, plan to perform Midazolam infusion .3 milligrams/kg IV bolus loading dose; start infusion at .1
(Refractory status rapid sequence intubation and milligrams/kg/h and titrate to seizure cessation (max.  epilepticus) start infusions milligrams/kg/h)
May need vasopressor support
Continuous EEG
Transfer to ICU/neuro ICU
Propofol 1–2 milligrams/kg IV loading dose; infusion at  micrograms/kg/min, titrate to seizure cessation (max. variable but generally < 100 micrograms/kg/min)
Pentobarbital  milligrams/kg IV bolus,  milligrams/kg boluses for ongoing seizures; infusion at  milligrams/kg/h, titrate to seizure cessation
≤60 minutes Consider additional antiseizure Ketamine  milligrams/kg IV loading dose, infusion at .5–10 milligrams/kg/h,
Refractory status medications titrate to seizure cessation epilepticus Try alternate anesthetic infusion
(as above, or can add ketamine)
Establish large­bore IV access and determine a bedside POC glucose. Administer crystalloids as needed to maintain perfusion. Place the patient on oxygen, a cardiac monitor, pulse oximeter, and end­tidal capnography.
In established status epilepticus, consider endotracheal intubation for airway protection, oxygenation, and ventilation. Use a short­acting paralytic agent in order not to mask ongoing seizure activity. Arrange for continuous EEG monitoring as soon as possible after paralytic agents have been used.
Initial laboratory evaluation includes blood glucose, a metabolic panel including calcium and magnesium, lactate, and if appropriate, a pregnancy test, a toxicology screen, and anticonvulsant levels.
Administer glucose IV if hypoglycemia is suspected or confirmed. Monitor temperature continuously, and treat hyperthermia with passive cooling.
Place a urinary catheter to monitor urine output and insert a nasogastric tube to help prevent aspiration.
If toxic ingestion is suspected as the cause of seizures, proceed with GI decontamination (as appropriate). Do not attempt lumbar puncture during status epilepticus. If bacterial meningitis or encephalitis is suspected clinically, then immediately start empiric antibiotic or antiviral therapy. Radiographic studies, such as a CT scan, will usually need to be delayed until seizures are controlled.
ANTICONVULSANT DRUGS IN STATUS EPILEPTICUS
The drugs most often used in the therapy of status epilepticus are the benzodiazepines (lorazepam, midazolam, or if not available, diazepam) and fosphenytoin (Table 171­3). Benzodiazepines are used in patients with continuous or very frequent seizures to temporarily control the seizures until more specific agents can be given. IV lorazepam (2 to  milligrams) and IV diazepam (5 to  milligrams) have equal efficacy in controlling status
 epilepticus. Compared to diazepam, lorazepam has a slightly slower onset (3 vs.  minutes) but a significantly longer duration of action (12 to  hours vs.  to  minutes) and is associated with fewer seizure recurrences. In one prehospital study, IM midazolam demonstrated decreased seizure time
 and fewer intensive care unit admissions when compared to lorazepam if no IV access was available, and in an additional noninferiority prehospital
 trial, IM midazolam was determined to be as safe and effective as IV lorazepam. However, IVlorazepam is still considered the initial agent of
 choice if IV access is available. Lorazepam is also more effective than phenytoin or phenobarbital as a first­line agent. Respiratory depression and hypotension may occur, especially in young children and in patients taking alcohol, barbiturates, narcotics, or other sedatives. In patients with difficult IV access and emergent need for seizure control, there may be a role for rectal diazepam gel or buccal midazolam. Although there have been no trials in adults, rectal diazepam has been used by EMS providers in children with good success for years, and recent trials of buccal midazolam (0.5
,31 milligram/kg, up to  milligrams) show more efficacy than rectal diazepam in the pediatric population.
In established status epilepticus, follow benzodiazepines with longer­acting antiepileptic agents: fosphenytoin, levetiracetam, or valproate. One of
 these antiepileptic agents should be started within  minutes of diagnosis. The most updated consensus guidelines do not currently recommend
 one second­line agent over another. Multicenter trials are currently under way to help determine which of these antiepileptic agents are the most
 effective in helping terminate status epilepticus.
Fosphenytoin is a water­soluble prodrug of phenytoin that is converted to phenytoin in the plasma. Fosphenytoin has similar time of onset, effectiveness, and cardiac effects as phenytoin. It has much fewer infusion­site reactions due to the lack of propylene glycol and ethanol as the diluents. Fosphenytoin may be infused quickly, and for that reason, it is preferred over phenytoin. Fosphenytoin dosing is expressed as phenytoin equivalents to prevent confusion. The loading dose is  phenytoin equivalents/kg, which can be infused at 150 phenytoin equivalents/min over  to

 minutes. Fosphenytoin can also be given IM, which may be useful if the patient does not have IV access.
The loading dose for phenytoin is  milligrams/kg IV. Doses in excess of the usual 1000 milligrams are often required. Due to myocardial depression from its propylene glycol diluent, phenytoin is typically infused no faster than a rate of  milligrams/min (taking about  hour to administer). The rate may be increased to  milligrams per minute during status epilepticus as long as hypotension does not develop. Place patients on a cardiac monitor,
 with blood pressure assessments every  to  minutes during the infusion and every  minutes for  hour after infusion. Phenytoin should not be mixed with any glucose­containing IV fluid and should not be given IM due to erratic absorption. Adverse effects include infusion­site reactions, hypotension, and cardiac dysrhythmias, and it is contraindicated in patients with second­ or third­degree atrioventricular blocks. If side effects develop, stop the infusion and restart at a lower rate after side effect resolution.
Valproic acid is effective but has serious side effects compared to the agents listed above; the Food and Drug Administration has issued a blackboxed warning for hepatic failure and pancreatitis, and valproic acid should not be administered along with phenytoin. The dose is  to 
,9,22,35,36 milligrams/kg IV.
Levetiracetam is very effective, is quick to administer, and has few interactions and side effects. The precise mechanism of action is unknown, but it may inhibit voltage­dependent calcium channels and facilitate γ­aminobutyric acid inhibitory transmission. The dose is  to  milligrams/kg IV. While it is not yet approved by the Food and Drug Administration for status epilepticus, it is rapidly gaining favor as a first­line drug for established status
,9,37­39 epilepticus.
Lacosamide is a potential alternative for status epilepticus with limited availability and limited data on its use. The dose is 200 milligrams IV given over
,40
 minutes.
REFRACTORY STATUS EPILEPTICUS
Refractory status epilepticus is defined as persistent seizure activity despite the IV administration of adequate amounts of two antiepileptic agents and
  usually exceeds  minutes. One study found up to 31% of patients with status epilepticus developed refractory status epilepticus.
,7,9,22,36­47
Various approaches to refractory status epilepticus have been advocated (Table 171­3). Overall, there are few controlled trials that strongly support a single agent or combination of agents. Recommendations include propofol, midazolam, and barbiturates such as phenobarbital or
 pentobarbital given as infusions. All of these agents can lead to hypotension, sometimes requiring concomitant vasopressor use, and frequently require intubation. Ideally, treatment is in consultation with a neurologist and in an intensive care setting, as advanced respiratory support, cardiovascular support, and EEG monitoring are all needed.
Propofol is a widely used, lipophilic, general anesthetic that has come into favor for refractory status epilepticus. It can be started as an infusion at typical rates of  to  milligrams/kg/h and titrated up to effect of seizure cessation. Propofol has the added benefit of a short half­life allowing for quicker neurologic recovery after seizure control is achieved. At higher doses (>40 milligrams/kg/h), patients are at increased risk for hemodynamic
,7,9,22,43 instability including hypotension as well as propofol infusion syndrome.
Midazolam is an easily titrated, infusible benzodiazepine that can also be used in the ongoing treatment of refractory status epilepticus. Midazolam
,9,44 can be started at .05 to .4 milligram/kg/h and is titrated up to seizure cessation. Midazolam can accumulate in peripheral soft tissues, particularly with renal insufficiency, leading to a much prolonged recovery period.
Barbiturates, such as phenobarbital (up to  milligrams/kg IV) or pentobarbital, may be considered as third­line drugs in patients whose seizures are not controlled despite full loading doses of benzodiazepines and other agents. However, patients in refractory status epilepticus may not
 respond to barbiturates. One study found no added seizure control with phenobarbital. A subsequent meta­analysis showed improved seizure
 control with pentobarbital compared to propofol or midazolam, but no differences in mortality. Respiratory depression and hypotension are more
,9,22 common when using barbiturates, especially at higher doses or when diazepam or lorazepam is also given. Additionally, midazolam and propofol
 have the advantage over barbiturates of having a shorter half­life and rapid clearance, allowing for earlier extubation and clinical assessment. For these reasons, current recommendations are to use propofol and midazolam infusions as first­ and second­line agents, respectively, in refractory
,9,22,43,44 status epilepticus with barbiturates as a third­line agent.
Finally, ketamine may also be considered as a third­line agent in refractory status epilepticus. Ketamine is an N­methyl­D­aspartate receptor antagonist and helps block the hyperexcitatory pathway, which is thought to be a greater culprit in refractory status epilepticus. Ketamine can be administered as a bolus dose of .5 to .5 milligrams/kg or as an infusion up to  milligrams/kg/h. Multiple case reports and one retrospective study
,44­48 have demonstrated its increased utilization, safety, and likely benefit in terminating refractory status epilepticus.


