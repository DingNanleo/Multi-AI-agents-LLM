## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 100: Maternal Emergencies After  Weeks of Pregnancy and in the
Peripartum Period
Janet S. Young
Content Update: PROM antibiotics April 2020
The 2020 ACOG recommendations regarding acute antibiotic therapy for PROM < 34/07 weeks gestation are listed in text and reference . Erythromycin and amoxicillin are still recommended, and reduce maternal and neonatal morbidity (36).
INTRODUCTION
This chapter examines the diagnosis and treatment of the most important maternal emergencies occurring after  weeks of pregnancy and during the postpartum period. The second half of pregnancy is often characterized as ≥20 weeks of gestation for simplicity, but until  weeks, the chances of fetal survival are less than 50%. The postpartum period is generally accepted as the  weeks after delivery. Vast physiologic shifts in maternal cardiovascular tone occur as pregnancy progresses, highlighting the need for maternal blood pressure recordings and fetal heart tones during any ED visit. Conditions discussed are disorders associated with elevated blood pressure (hypertension, preeclampsia and HELLP syndrome [hemolysis, elevated liver enzymes, and low platelet count], and eclampsia); vaginal bleeding in the second half of pregnancy; premature rupture of membranes; peripartum cardiomyopathy; postpartum endometritis; and the emergency transfer of the pregnant patient.
DISORDERS ASSOCIATED WITH ELEVATED BLOOD PRESSURE: HYPERTENSION,
PREECLAMPSIA AND HELLP SYNDROME, AND ECLAMPSIA
CHRONIC AND GESTATIONAL HYPERTENSION
The decrease in systemic vascular resistance results in a decrease in maternal blood pressure, and blood pressure reaches its nadir at  to  weeks of pregnancy. Blood pressure returns to prepregnancy values near the end of the second trimester. Almost 10% of pregnant women have hypertension; hypertension is preexisting in 1%, gestational hypertension without proteinuria develops in 5% to 6%, and preeclampsia develops in

2%.
Chronic hypertension in pregnancy is defined as a systolic blood pressure of ≥140 mm Hg or a diastolic blood pressure of ≥90 mm Hg that existed prior to pregnancy, is diagnosed before the 20th week of gestation, or persists longer than  weeks after delivery. Severe chronic hypertension is systolic blood pressure >160 mm Hg or diastolic pressure >110 mm Hg. Women with chronic hypertension are at increased risk for placental abruption,
,3 preeclampsia, low birth weight, cesarean delivery, premature birth, and fetal demise.
Gestational hypertension is hypertension present only after the 20th week of pregnancy or in the immediate postpartum period but without proteinuria.

Safe treatment options for hypertensive women who are pregnant are labetalol, methyldopa, nifedipine, and hydralazine. All antihypertensive
,5 drugs cross the placenta. Labetalol is the first­line agent for chronic hypertension in pregnancy. The starting dose is 100 milligrams PO twice a day, and the usual maintenance dose is 200 to 400 milligrams PO twice a day. Methyldopa, used safely in pregnancy for decades, is started at 250 milligrams every  hours PO and titrated to achieve the desired blood pressure. The usual daily dose is 500 milligrams to  grams divided in two to four
 doses per day, with a maximum of  grams per day. The goal is not to normalize blood pressure in the acute setting, but to reach a recommended

 target blood pressure of 140 to 150/90 to 100 mm Hg.
Chapter 100: Maternal Emergencies After  Weeks of Pregnancy and in the Peripartum Period, Janet S. Young 
. Terms of Use * Privacy Policy * Notice * Accessibility
Long­acting nifedipine may be added if blood pressure is not controlled with methyldopa or labetalol. Nifedipine is started at  milligrams PO once daily and can be increased up to 120 milligrams per day slowly if needed. For acute management of hypertensive emergencies, hydralazine  milligrams IV or IM, labetalol  milligrams IV, or nifedipine  to  milligrams PO (not a U.S. Food and Drug Administration–approved indication) may
,6–10 be used during pregnancy. Angiotensin­converting enzyme inhibitors and angiotensin receptor blockers are contraindicated
,6,11 because of their teratogenic effects on fetal scalp, lungs, and kidneys.
PREECLAMPSIA
Preeclampsia has been redefined as the presence of de novo hypertension (>140 mm Hg systolic or >90 mm Hg diastolic) after 
,13 weeks of gestation combined with proteinuria or other maternal organ dysfunction (renal, liver, neurologic). In the absence of proteinuria, thrombocytopenia, liver dysfunction, renal insufficiency, pulmonary edema, and cerebral dysfunction are criteria for preeclampsia. Table
100­1 summarizes the currently recognized definitions of preeclampsia.
TABLE 100­1
Definitions of preeclampsia
Hypertension Proteinuria Multisystem Involvement
≥140 mm Hg systolic or ≥300 mg in  h Thrombocytopenia
≥90 mm Hg diastolic
Previously normotensive patient Protein/creatinine ratio Renal insufficiency
>20 wk gestation ≥0.3 mg/dl
BP measured two times at least  hours aparta Dipstick ≥1+ (only if other methods not available) Liver dysfunction
Pulmonary edema
Cerebral or visual disturbances
Severe features of preeclampsia
Systolic blood pressure ≥160 mm Hg or diastolic blood pressure ≥110 mm Hg on  occasions at least  hours apart while the patient is on bed rest
Thrombocytopenia (<100,000 platelets/mL)
Impaired liver function (liver enzymes levels increased to twice normal) or persistent right upper quadrant/epigastric pain unresponsive to medication and not accounted for by a different diagnosis)
Progressive renal insufficiency (serum creatinine >1.1 mg/dL or doubling of creatinine level without other renal disease)
Pulmonary edema
Cerebral or visual disturbances
Abbreviation: BP = blood pressure.
aGreater than or equal to 160 mm Hg or greater than or equal to 110 mm Hg diastolic may be confirmed within minutes to facilitate treatment.
Source: Adapted with permission from American College of Obstetricians and Gynecologists; Task Force on Hypertension in Pregnancy: Hypertension in pregnancy.
Report of the American College of Obstetricians and Gynecologists’ Task Force on Hypertension in Pregnancy. Obstet Gynecol 122(5): 1122­1131, 2013. The cause of preeclampsia is unknown. The histologic hallmark lesion of preeclampsia is acute atherosis of decidual arteries. Atherosis and thrombosis are thought to lead to placental ischemia and infarctions. Poor placental perfusion is presumed to lead to the formation of free radicals, to
,14 oxidative stress, and to inflammatory responses that may influence the mechanistic development of preeclampsia.
Preeclampsia is associated with intrauterine growth retardation, premature labor, low birth weight, abruptio placentae, and future risk of maternal
,9,12,15,16 cardiovascular disease.
Preeclampsia during an initial pregnancy increases the chances of recurrence in future pregnancies. Other important risk factors for preeclampsia include maternal age >40 years old, hypertension, diabetes, renal disease, collagen vascular disease, and multiple gestation. Low­dose aspirin therapy
,17,18 can prevent preeclampsia and its complications.
DIAGNOSIS OF PREECLAMPSIA

Diagnostic criteria for preeclampsia and severe eclampsia are listed in Table 100­1, and laboratory evaluation is outlined in Table 100­2. TABLE 100­2
Laboratory Evaluation for Preeclampsia
Test Comments
CBC with differential May see hemoconcentration or decreasing hematocrit.
Thrombocytopenia suggests severe disease.
Creatinine Elevation suggests severe disease.
Alanine and aspartate aminotransferase Elevation suggests severe disease.
concentrations
Lactate dehydrogenase level Elevation suggests microangiopathic hemolysis.
Protein in urine ≥1+ proteinuria; 24­h collection may be done by obstetric service. >5 grams/24 h suggests severe disease.
Protein/creatinine ratio .1–0.3 indicates need for 24­h collection.3
Uric acid level Level ≥5.5 milligrams/dL may suggest superimposed preeclampsia on chronic hypertension.3
HELLP SYNDROME
The HELLP syndrome (Table 100­3) is an important clinical variant of preeclampsia. HELLP is more common in the multigravid patient than in the primigravida. Hypertension may not be present initially or at all. This fact, combined with the usual complaint of epigastric or right upper quadrant pain, makes it easy to misdiagnose HELLP syndrome for other causes of abdominal pain, such as gastroenteritis, cholecystitis, hepatitis, pancreatitis, or pyelonephritis. A pregnant woman at >20 weeks of gestation or up to  days postpartum with abdominal pain should be evaluated for HELLP syndrome.
TABLE 100­3
Laboratory Abnormalities in HELLP Syndrome
Test Findings
CBC and test of peripheral smear Schistocytes
Platelet count <100,000/µL
<150,000/µL suspicious for syndrome
Liver function tests (alanine aminotransferase, aspartate aminotransferase levels) Elevated but below levels usually seen in viral hepatitis (<500 U/L)
Renal function tests Normal or elevated BUN and creatinine levels
Coagulation profile Abnormal
Lactate dehydrogenase >600 U/L suspicious for hemolytic anemia
Total bilirubin >1.2 milligrams/dL
Complications of severe preeclampsia, HELLP syndrome, and eclampsia include disseminated intravascular coagulopathy, spontaneous hepatic and
,13,19 splenic hemorrhage, end­organ failure, abruptio placentae, intracranial bleeding, maternal death, and fetal death.
TREATMENT OF PREECLAMPSIA
For mild preeclampsia, outpatient management is an option after consultation with the obstetrician, as long as arrangements are made for frequent
,19 clinical and laboratory evaluation and close fetal surveillance. Headache, scintillating scotomata or other visual changes, abdominal pain, vaginal bleeding, and decreased fetal movement require immediate reevaluation. Treat severe preeclampsia (blood pressure >160 mm Hg) with
,12,13,19–23 antihypertensive agents (Table 100­4) and IV magnesium sulfate. Consult with the obstetrician for admission or transfer to a center that manages high­risk pregnancy especially in the presence of HELLP syndrome. The only definitive resolution for preeclampsia is delivery.
TABLE 100­4
Antihypertensive Drugs for Treatment of Acute, Severe Hypertension in Preeclampsia and Eclampsia6,12,13,22,23
Onset
Generic Mechanism of Dosage Comment
Name of Action
Action
Labetalol Selective α  min  milligrams IV, then 40–80 milligrams IV every  Less hypotension and reflex tachycardia than and min as needed (maximum, 300 milligrams); IV hydralazine. Higher doses cause neonatal nonselective infusion 1–2 milligrams/min titrated hypoglycemia. Longer use associated with fetal growth
β antagonist restriction.
Hydralazine Arterial  min  milligrams IV or  milligrams IM, repeat at 20­min Maternal hypotension, fetal distress; must wait  min vasodilator intervals; consider other drug if no response at for response between IV doses.
maximum of  milligrams IV or  milligrams IM
Nifedipine Calcium 10–20  milligrams PO, repeat in  min if necessary Food and Drug Administration does not approve shortchannel min acting nifedipine for treatment of hypertension.
antagonist
The initial management of HELLP syndrome is similar to that of severe preeclampsia or eclampsia: IV magnesium, blood pressure control, and
 hospital admission for stabilization. Correct coagulopathy if clinically indicated. If HELLP syndrome is suspected and obstetric care is not available locally, stabilize the patient as best as possible and transfer to a tertiary care center with high­risk obstetrics facilities. The definitive treatment is delivery, especially if the patient is ≥34 weeks of gestation. Corticosteroid administration can help delay delivery and improve fetal outcome in
 pregnancies <34 weeks of gestation.
ECLAMPSIA
Eclampsia is the development of new­onset seizures, superimposed upon preeclampsia, in a woman between  weeks of gestation and  weeks postpartum.
Eclampsia should be suspected and treated in any pregnant woman who is at >20 weeks of gestation or <4 weeks postpartum who develops seizures, coma, or encephalopathy. Occasionally, eclampsia can present with seizure in the absence of blood pressure elevation and proteinuria.7,16 Management of eclampsia includes treatment of seizures, treatment of hypertension, and emergent obstetric consultation to facilitate urgent delivery of the fetus. Treat seizures with magnesium sulfate,  to  grams IV in 100­mL aliquot given over 
19–21,25,26 to  minutes followed by an infusion of  grams per hour for at least  hours. Magnesium is renally excreted, and in women with renal insufficiency, reduce the dose to  grams IV bolus and obtain a serum magnesium level before increasing the dose. The main side effects of high levels of magnesium are flushing, diaphoresis, hypothermia, hypotension, flaccid paralysis, and respiratory depression. When levels approach toxicity, patellar reflexes diminish and respiratory rate slows. Administer antihypertensive agents as suggested in Table 100­4. Replace coagulation factors and platelets as indicated, if there is coagulopathy. Obtain emergency obstetric consultation for prompt delivery. If obstetric services are not available, stabilize the patient as best as possible and transfer to a center with facilities for advanced obstetric care.
VAGINAL BLEEDING IN THE SECOND HALF OF PREGNANCY
The causes of serious vaginal bleeding in the second half of pregnancy include abruptio placentae, placenta previa, and vasa previa. All can cause severe hemorrhage. Do not perform a digital or speculum pelvic examination to assess vaginal bleeding until a transvaginal US is performed to determine the location of the placenta. Mechanical disruption of the placenta by speculum or digital examination may precipitate catastrophic hemorrhage. When transvaginal US is properly and carefully performed by those experienced in transvaginal US (vaginal probe is angled against the anterior lip of the cervix, probe is not advanced to contact the placenta, probe is not inserted into the cervix), the technique
,28 is generally considered safe. If there is no evidence of placenta previa or vasa previa, then a sterile speculum examination may be performed to determine if premature rupture of membranes or abruption is present.
ABRUPTIO PLACENTAE
Abruptio placentae is the premature separation of a normally implanted placenta from the uterine lining (Figure 100­1). The incidence of
,30 spontaneous abruption is highest between  and  weeks of gestation. Abruption can cause uteroplacental insufficiency and fetal distress or
 demise. Maternal complications include coagulopathy, hemorrhagic shock, uterine rupture, and multiple organ failure. Abruption usually occurs spontaneously, but is also associated with trauma, even minor trauma. See Chapter 256, “Trauma in Pregnancy.” Risk factors for abruption include abdominal trauma, cocaine use, oligohydramnios, chorioamnionitis, advanced maternal age or parity, eclampsia, and chronic or acute hypertension.
FIGURE 100­1. Abruptio placentae. The placenta has separated from the superior pole of the uterus.
In the diagram, the fetus is positioned with its head down, at the entrance to the birth canal. The placenta is at the top of the uterus, above the fetus' feet.
Clinical features depend on the degree of placental abruption. Mild abruption is characterized by mild uterine tenderness, no or mild vaginal bleeding, normal maternal vital signs, no coagulopathy, and fetal distress. Signs and symptoms of severe abruption are no or heavy vaginal bleeding, fetal distress, coagulopathy, severe uterine pain or tenderness, continuous or repetitive uterine contractions, and maternal hypotension or shock. Nausea, vomiting, and back pain may also be present. Consider placental abruption in pregnant women with acute, painful vaginal bleeding or with acute abdominal/uterine pain.
Diagnosis is made by the clinical features. Electronic fetal monitoring (cardiotocodynamometry) is very sensitive for identifying fetal distress as a sign
 of placental abruption and has a 100% negative predictive value for adverse outcomes when monitoring is reassuring. Transvaginal US is fairly specific for the diagnosis but is not sensitive for the detection of retroplacental clot because the appearance of clotted blood evolves in echotexture
  over time. MRI is diagnostic but requires the transport of a potentially unstable patient out of the ED or intensive care unit for imaging.
Treatment consists of maternal stabilization, cardiotocographic monitoring to detect fetal distress, and emergency obstetric consultation. Place two large­bore IVs; obtain a CBC, metabolic panel, coagulation panel, fibrin degradation product, and fibrinogen levels; and type and cross­match maternal blood. Administer RhoGAM® if the mother is Rh negative. For disseminated intravascular coagulation, replace coagulation factors. Immediate delivery is indicated for severe abruption.
PLACENTA PREVIA
Placenta previa is a placenta that extends near, partially over, or beyond the internal cervical os. Normal placental implantation is in the corpus or fundal region, whereas in placenta previa, implantation is lower in the uterus. The cause is unknown, although the incidence is increasing due to
 increasing rates of cesarean delivery, maternal age, and assisted reproductive technology. Although low­lying or partial placenta previa is not uncommon early in pregnancy, the placenta usually migrates to a normal position as the pregnancy nears term.
Risk factors for placenta previa include cesarean delivery, multiple uterine surgeries, advanced maternal age, minority group status, cigarette smoking, and cocaine use. Patients with symptomatic placenta previa present with painless bright­red vaginal bleeding, which should be differentiated from the normal passage of blood­stained mucus that occurs near the onset of labor. There are three subclasses of placenta previa: marginal placenta previa, which reaches the internal os but does not cover it; partial placenta previa, where the placenta partially covers the internal os; and complete placenta previa, which completely covers the internal os (Figure 100­2).
FIGURE 100­2. Complete placenta previa. Placenta overlies the internal os.
In the diagram, the fetus is positioned with its head down, toward the entrance to the birth canal. The placenta is at the bottom of the uterus, below the fetus' head blocking the entrance to the birth canal.
While proceeding with further patient assessment, place two large­bore IVs for fluid resuscitation; obtain CBC and coagulation parameters; and type and cross­match blood. Do not perform a digital or speculum vaginal examination until normal placental position is confirmed by US, as disruption of the cervical–placental junction could precipitate catastrophic hemorrhage. Carefully perform transvaginal US (see earlier). Once a placenta previa is identified, consult obstetrics for management options. A double setup, in which two teams of staff are available in the operating room during a vaginal examination, may be indicated in cases where the placenta lies within  to  cm of the cervical os and labor is imminent. Otherwise, women in the second half of pregnancy with placenta previa are usually admitted to the hospital for observation and fetal monitoring.
VASA PREVIA
Vasa previa is a rare cause of late­pregnancy bleeding. In vasa previa, umbilical vessels course in the amniotic membrane at the level of the cervical os, so that when the cervix begins to dilate in labor with membrane rupture, the blood vessels tear. Fetal distress or fetal demise may result from fetal exsanguination or vessel compression. Risk factors associated with vasa previa are placenta previa, in vitro fertilization, velamentous insertion of the
 umbilical cord, and bilobed placenta. Vasa previa can sometimes be diagnosed by Doppler color US performed early in pregnancy. Otherwise, it is seldom recognized prior to catastrophic vessel disruption during labor. Treatment is rapid operative delivery.
PREMATURE RUPTURE OF MEMBRANES, PRETERM LABOR, AND PRETERM BIRTH
Premature rupture of membranes is rupture of membranes prior to onset of contractions. Premature rupture of membranes complicates about

8% of all pregnancies. Membrane rupture before  weeks of gestation is known as preterm premature rupture of membranes. The time from membrane rupture to fetal delivery, known as the latent period, may allow for pharmacologic intervention to improve fetal lung maturity and increase fetal survival. Worldwide, an estimated .1% of all live births in 2010 were born preterm (14.9 million babies born before  weeks of
 gestation). Survival of preterm infants generally increases with increasing gestational age, with a generally expected >50% in­hospital survival when
38–40 born at  weeks of gestation.
Preterm (premature) labor is labor prior to  weeks of gestation and is often preceded by premature rupture of membranes. Preterm labor is thought to be a syndrome initiated by multiple mechanisms, including infection, inflammation, uteroplacental ischemia or hemorrhage, uterine
,42 overdistention secondary to multiple gestation, stress, and other immunologically mediated processes. Chlamydia, gonorrhea, Trichomonas vaginalis, and bacterial vaginosis infections increase the risk of preterm premature rupture of membranes and preterm labor. Several non–genital tract infections, including pyelonephritis, asymptomatic bacteriuria, pneumonia, appendicitis, and periodontal disease, are also implicated in preterm labor. Preterm birth is birth before  weeks of gestation and may occur spontaneously or as a result of premature rupture of membranes or placental abruption or may be induced for medical reasons. Surviving preterm neonates are at risk for sepsis, neurologic defects, feeding problems, blindness, deafness, and respiratory distress. Infants weighing <1500 grams or born at <32 weeks of gestation are at greatest risk for these problems, but even infants born at between  0/6 and  6/7 weeks of gestation (late preterm infants) may require intensive care admission for IV fluids, sepsis,
 hyperbilirubinemia, and mechanical ventilation.
DIAGNOSIS AND TREATMENT OF PREMATURE RUPTURE OF MEMBRANES
Details of the history taking and physical examination that aid in the diagnosis of premature rupture of membranes are listed in Table 100­5. Avoid digital cervical examination because it decreases the latent period and may increase the likelihood of infection. Perform speculum examination and visually examine the cervix to identify dilation and test vaginal fluid (Table 100­5). The combination of history, nitrazine
 paper, and fern testing (Figure 100­3) is reported to diagnose 90% of cases of premature rupture of membranes. US assessment of amniotic fluid
 volume may give additional information but is not diagnostic of premature rupture. Additionally, a low amniotic fluid volume (<5 cm) may be
 predictive of impending delivery.
TABLE 100­5
Keys to Diagnosis of Premature Rupture of Membranes
Information Obtained Comments
History
Gush of fluid and continued leakage of fluid Ask patient to perform a Valsalva maneuver while speculum is in place to look for gush of fluid, or apply fundal pressure.
Details of contractions Determine if active labor is in process.
Date of last menstrual period Use to calculate estimated date of delivery and gestational age.
Gestational age is number of weeks from first day of last menstrual period.
Vaginal bleeding Raises concern for placenta previa.
Recent intercourse
Fever Infection raises fetal and maternal risk.
Physical Examination
Measurement of fundal height
Auscultation of fetal heart tones
Sterile speculum examination Check for:
Cervical dilatation and effacement.
Pooling in vagina of fluid leaking from cervix.
If no fluid is noted, apply fundal pressure or ask patient to perform a
Valsalva maneuver or cough.
Laboratory Evaluation
Vaginal fluid Test with nitrazine paper.
Blue color indicates pH >6.5, signaling presence of amniotic fluid.
Note: Blood, semen, bacterial vaginosis, trichomoniasis, soap, and antiseptics may cause false­positive results; false­negative rate, about
7%.44
Swab of vaginal walls or posterior fornix; do not swab cervical mucus; cervical Examine glass slide preparation for ferning.
mucus produces thick, dark, wide arborization pattern, not delicate ferning Ferning indicates presence of amniotic fluid.
Blood may obscure ferning.
Mucus results in a false­positive fern test finding.
Test for Chlamydia, Neisseria gonorrhoeae, group B streptococci, and bacterial vaginosis.
FIGURE 100­3. Ferning of amniotic fluid. [Photo contributed by Robert Buckley, MD.]
Null
Premature labor or premature rupture of membranes requires obstetric consultation. If obstetric services are unavailable, transfer the patient to a center where such services are available. Obstetric treatment includes corticosteroids and antibiotics to treat group B Streptococcus.

A single course of corticosteroids is recommended for pregnant women between  0/7 weeks and  0/7 weeks of gestation. Corticosteroids given at <34 weeks of gestation speed fetal lung maturity, decrease the incidence of intraventricular hemorrhage, reduce the duration of mechanical ventilation, and reduce the incidence of necrotizing enterocolitis without increasing maternal or fetal infection. Betamethasone (12 milligrams IM every
 hours for  days) or dexamethasone (6 milligrams IM every  hours for  days) can be used for gestations between  and  weeks, and may be
 considered for pregnant women as early as  0/7 weeks of gestation.
Antibiotics can decrease neonatal infection, prolong latency, and reduce the incidence of postpartum endometritis, chorioamnionitis, neonatal infections, and intraventricular hemorrhage. Antibiotic administration is recommended to all women less than  0/7 weeks of gestation with preterm premature rupture of membranes. American College of Obstetricians and Gynecologists guidelines recommend ampicillin  grams
IV every  hours and erythromycin 250 milligrams IV every  hours for  hours followed by oral amoxicillin 250 milligrams every  hours and
 erythromycin base 333 milligrams every  hours. Do not give amoxicillin­clavulanate because it is associated with necrotizing enterocolitis. There is
,43 no need for prophylactic antibiotics if membranes are intact, unless the patient is a group B streptococci carrier.
Tocolytic therapy using magnesium sulfate, β­mimetics, indomethacin, or calcium channel blockers is controversial and is relatively contraindicated in
 the patient with preterm premature rupture of membranes. Tocolysis may allow time for administration of antenatal corticosteroids and antibiotics and transfer of the patient to an appropriate receiving facility. Magnesium sulfate may provide neonatal neuroprotective effects against cerebral palsy,
 and indomethacin has been used effectively for short­term tocolysis. Because there are no widely accepted protocols for tocolytic management, consult the obstetrician, who can explain the pharmacologic risks, benefits, and alternatives to the patient.
Management guidelines for expedited delivery in the near­term gestation vary. Expedited delivery was historically recommended in patients with preterm premature rupture of membranes at >34 weeks of gestation to avoid the complications of chorioamnionitis and neonatal sepsis, but recent
 clinical guidelines suggest that induction of labor does not reduce the risk of neonatal sepsis.
A cervical cerclage is a retention suture placed in a “purse­string” fashion around the cervix in order to support the internal cervical os and prevent the cervix from dilating prematurely. In patients with premature rupture of membranes or preterm labor, no specific practice guidelines are recommended. Cerclage retention for preterm premature rupture of membranes has been associated with increased neonatal mortality and sepsis.
Consult with the receiving obstetrician for case­specific recommendations. Tocolysis may be appropriate. Removal of cerclage sutures with preterm
 labor is associated with cervical lacerations, but rapidly progressive labor may necessitate emergency removal.
POSTPARTUM ENDOMETRITIS
Most postpartum infections are identified after hospital discharge. In a postpartum woman with fever, assume pelvic infection until proven
 otherwise. Also consider respiratory tract infection, pyelonephritis, mastitis, thrombophlebitis, and appendicitis. Risk factors for postpartum endometritis are listed in Table 100­6. TABLE 100­6
Risk Factors for Postpartum Endometritis
Cesarean section* Multiple gestation
Younger maternal age
Long duration of labor and membrane rupture
Internal fetal monitoring
Low socioeconomic level
Digital examination after  wk of gestation
Maternal human immunodeficiency virus infection
*Most significant risk factor.
The most common pathogens are gram­positive (streptococci, enterococci) and gram­negative aerobes (Escherichia coli), anaerobes
(peptostreptococci), Mycoplasma hominis, Chlamydia trachomatis (>7 days postpartum), and Neisseria gonorrhoeae. Gardnerella vaginalis is isolated more often in younger women. Many infections are polymicrobial. Group A streptococcal infections are less common, but are increasing causes of
,48 postpartum endometritis.
Symptoms of postpartum endometritis are fever, foul­smelling lochia, leukocytosis, tachycardia, pelvic pain, and uterine tenderness. Only scant vaginal discharge may be present, especially in patients infected with group B streptococci. In patients who are status post cesarean section, there may be surgical wound tenderness and purulent exudate.
Vaginal samples are of little value because of contamination with local flora. Blood cultures are rarely positive. Culture any purulent material from surgical incisions. Creatine phosphokinase levels may be elevated in group B streptococcal endometritis. Consult the obstetrician for disposition decisions. Admission is needed for patients who appear ill, have had cesarean section, or have underlying comorbidities. Treatment consists of antibiotics (Table 100­7), abscess drainage, and debridement of necrotic tissue. Empiric combination of clindamycin (900 milligrams every  hours IV or 600 milligrams every  hours IV) and an aminoglycoside (most commonly gentamicin  milligrams/kg every  hours or .5 milligrams/kg every 
 hours) remains the most effective regimen to treat postpartum endometritis.
TABLE 100­7
Inpatient Treatment of Postpartum Endometritis* Clindamycin 900 milligrams every  h plus gentamicin  milligrams/kg every  h (and add either ampicillin  grams then  gram every  h OR vancomycin  gram every  h)
Ampicillin  grams then  gram every  h plus gentamicin  milligrams/kg every  h plus metronidazole 500 milligrams every  h
*Consult the hospital pharmacist to determine if the antibiotic regimen selected is appropriate for breastfeeding.
After consultation with and recommendation by the obstetrician, patients with mild illness and those for whom follow­up in  hours is ensured can be treated as outpatients with oral antibiotics. Antimicrobial trials of postpartum endometritis treatment and intrauterine microbiology studies suggest five antimicrobial regimens may be effective: oral clindamycin plus intramuscular gentamicin, oral amoxicillin­clavulanate, intramuscular cefotetan,
 intramuscular meropenem or imipenem­cilastatin, and oral amoxicillin in combination with oral metronidazole. Doxycycline 100 milligrams twice a day plus metronidazole 500 milligrams twice a day; levofloxacin 500 milligrams daily plus metronidazole 500 grams three times a day; and amoxicillin­
 clavulanate 850 milligrams PO twice a day are all acceptable oral regimen. Doxycycline is contraindicated in women who are breastfeeding.
Complications of endometritis include parametrial phlegmons; surgical, incisional, and pelvic abscesses; infected hematomas; septic pelvic thrombophlebitis; necrotizing fasciitis; and peritonitis.
PERIPARTUM CARDIOMYOPATHY
Peripartum cardiomyopathy is a dilated cardiomyopathy that can occur at any stage of gestation, but is classically defined as occurring in the last month of gestation or within the first  months after delivery, without an apparent cause or preexisting history of cardiac disease. The cause is unknown. Risk factors include cardiomyopathy during prior pregnancies, multiparity, maternal age >40 years old, black race, chronic hypertension before pregnancy, gestational hypertension, preeclampsia, and HELLP syndrome. Symptoms and signs of peripartum cardiomyopathy are dyspnea, orthopnea, cough, palpitations, chest pain, edema, rales, and jugular venous distention. Diagnose and treat congestive heart failure and pulmonary edema with standard modalities (see Chapter , “Acute Heart Failure”) except that nitroprusside is relatively contraindicated in pregnancy because it can cause thiocyanate and cyanide accumulation in the fetus. In the postpartum patient, angiotensin­converting enzyme inhibitors may be given, but because there is no information available on breastfeeding, an alternative agent is recommended during lactation.
Anticoagulate with heparins because of increased risk of thromboembolism. Do not use warfarin during pregnancy. Warfarin can be given in the postpartum period and poses little risk to the breastfed infant. Recovery to maximal ejection fraction (>50% left ventricular
 ejection fraction) usually occurs in the first  months postpartum and occurred in a majority of women in one study (>70%).
Ventricular dysrhythmias are common and may require a permanent implantable cardioverter­defibrillator with persistent dilated cardiomyopathy.
TRANSFER OF THE PREGNANT PATIENT AND THE EMERGENCY MEDICAL TREATMENT IN
ACTIVE LABOR ACT
There are times when a pregnant woman must be transferred to another hospital. Emergency physicians who work in a hospital that does not provide obstetric services should be familiar with the protocols in place for transfer and inpatient care of such patients. The Emergency Medical Treatment and Active Labor Act specifically addresses the care of pregnant women before and during transfer (see Chapter 303, “Legal Issues in Emergency
Medicine”).
A woman having contractions is considered to have an emergency medical condition if there is insufficient time for transfer before delivery or if the transfer may pose a threat to the health or safety of the child. In such a situation, the patient should not be transferred prior to delivery unless the patient requests transfer. If contractions are not present, an emergency medical condition is not automatically present, and the regular rules of providing medical care and determining the need for transfer of patients apply.
ACKNOWLEDGEMENTS
Acknowledgment
The authors gratefully acknowledge the previous authors, Michelle A. Echvarria and Gloria J. Kuhn, and the contributions of Antonio F. Didonato, who provided the illustrations for this chapter.


