## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 285: Soft Tissue Problems of the Foot
Mitchell C. Sokolosky
INTRODUCTION
This chapter discusses the common foot disorders that are likely to present to the ED. Patients with chronic or complicated foot problems generally should be referred to a dermatologist, orthopedist, general surgeon, or podiatrist, depending on the disease and local resources. Melanoma, tinea pedis, diabetic foot ulcers, onychomycosis, corns, and warts are discussed in Chapter 253, “Skin Disorders: Extremities.” Diabetic ulcers are discussed in Chapter 224, “Type  Diabetes Mellitus.” Puncture wounds of the foot are discussed in Chapter , “Puncture Wounds and Bites.” Lower extremity osteomyelitis is discussed in Chapter 281, “Hip and Knee Pain.”
INGROWN TOENAIL
Normal nail function requires maintenance of a small space between the nail and the lateral nail folds. Ingrown toenails occur when irritation of the
1­3 tissue surrounding the nail causes overgrowth, obliterating the space. Causes include improper nail trimming, using sharp tools to clean the nail
,3  gutters, tight footwear, rotated digits, and bony deformities. Curvature of the nail plate is another predisposing factor. Symptoms are characterized by inflammation, swelling, or infection of the medial or lateral aspect of the toenail. The great toe is the most commonly affected. In patients with underlying diabetes or arterial insufficiency, cellulitis, ulceration, and necrosis may lead to gangrene if treatment is delayed.
TREATMENT OF INGROWN TOENAILS
If infection or significant granulation is absent at the time of presentation, acceptable treatment is daily elevation of the nail with placement of a wisp of
  cotton or dental floss between the nail plate and the skin. Daily foot soaks and avoidance of pressure on the nail help. Another option, if no infection
 is present, is to remove a small spicule of the nail (Figure 285­1). (See Video: Ingrown Toenail Removal.)
Video 285­1: Ingrown Toenail Removal
Used with permission from Alan P. Bocko, Chapel Hill Foot and Ankle Associates; Judith E. Tintinalli, Medical Editor.
Play Video
FIGURE 285­1. Chapter 285: Soft Tissue Problems of the Foot, Mitchell C. Sokolosky 
Partial toenail removal. This method is used for small nail fold swellings without infection. After antiseptic skin preparation and digital nerve block, an
. Terms of Use * Privacy Policy * Notice * Accessibility oblique portion of the affected nail is trimmed about one to two thirds of the way back to the posterior nail fold. Use scissors to cut the nail; use forceps to grasp and remove the nail fragment.
A digital nerve block is placed (see Chapter , “Local and Regional Anesthesia”). Cleanse the area and prepare the skin for an antiseptic procedure.
Trim an oblique portion of the affected nail about one to two thirds of the way back to the posterior nail fold. The nail groove should then be debrided
,2 and a nonadherent dressing placed.
If granulation or infection is present, a larger partial removal of the nail plate is indicated (Figure 285­2). Preprocedure antibiotics are not needed
 unless the patient is systemically ill. First, perform a digital nerve block and prepare the area for antiseptic technique. Longitudinally, cut the entire affected area base to tip, cutting about one fourth of the nail plate, including the portion of the nail beneath the cuticle. Cutting the nail is made easier by first sliding mosquito forceps or small scissors between the nail and nail bed on the affected side, freeing the nail from the bed below. Rotate the forceps, turning up the portion of the nail on the affected side. A nail splitter is the optimal instrument for cutting the nail; however, sturdy scissors are a reasonable alternative. Then grasp the affected cut portion of the nail with a hemostat and, using a rocking motion, remove it from the nail groove.

Then debride the nail groove. Once the procedure is completed, place a nonadherent gauze or antibiotic ointment on the wound and a bulky dressing
,3 over that, covering the toe. Check the toe in  to  hours. Although not mandatory, phenol is often used for chemical matricectomy to reduce growth of granulation tissue. If used, massage the involved nail matrix vigorously with a cotton­tipped swab dipped in an aqueous solution of phenol
88%, with a rotation directed toward the lateral nail fold, for  minute. Irrigate the nail matrix using isopropyl alcohol to neutralize completely the
 phenol solution. Do not expose normal skin or tissues to the phenol solution. Postprocedure antibiotics are not needed unless cellulitis is proximal to
 the toe.
FIGURE 285­2. Partial toenail removal (infection present). This method is used for onychocryptosis in the setting of significant granulation tissue or infection. See
“Treatment of Ingrown Toenails” for a description of the procedure.
For recurrent ingrown toenails, refer to a podiatrist for permanent nail ablation, which may require a combination of surgical excision plus chemical
 matricectomy (phenol ablation).
OTHER NAIL LESIONS
Other common toenail afflictions include paronychia (see Chapter 283, “Nontraumatic Disorders of the Hand”) and subungual hematoma (see Chapter
, “Arm, Forearm, and Hand Lacerations”), which are treated similarly to when they occur in the fingers. Hyperkeratotic toenails can be a problem in the elderly. These may become so severe as to affect gait and cause ulcerations and infections. Refer such patients to podiatry for repeated trimming or nail plate removal.
BURSITIS INVOLVING FEET
Calcaneal bursitis causes posterior heel pain that is similar to Achilles tendinopathy; however, the pain and local tenderness are located at the
6­8 posterior heel at the Achilles tendon insertion point. In contrast, Achilles tendinopathy causes symptoms  to  cm superior to the posterior calcaneus. Pathologic bursae can be divided into noninflammatory, inflammatory, suppurative, and calcified. Noninflammatory bursae are usually pressure induced and are found over bony prominences. Inflammatory bursitis is commonly due to gout or rheumatoid arthritis. Suppurative bursitis is due to bacterial invasion of the bursae (primarily staphylococcal species), usually from adjacent wounds. Acute bursitis can lead to the formation of
,8 a hygroma or calcified bursae. Diagnosis can be aided by the use of US and MRI but is not indicated for evaluation in the ED. Treatment of the bursitis depends on its cause. For nonseptic bursitis, symptoms usually resolve with simple measures including heel lifts, comfortable footwear, rest, ice, and

NSAIDs. Management of septic bursitis is discussed in Chapter 284, “Joints and Bursae.” Diagnosis of these lesions is dependent on analysis of bursal
 fluid, which can be obtained by large­bore needle aspiration.
PLANTAR FASCIITIS
10­12
Plantar fasciitis, inflammation of the plantar aponeurosis, is the most common cause of heel pain. Peak age incidence is usually between  and 
,14 years old, but it has a younger peak in runners. Plantar fasciitis is common among ballet dancers and those performing aerobics. The plantar fascia anchors the plantar skin to the bone and provides support to the foot during gait. The cause is usually overuse. Other causes of heel pain
,10 include abnormal joint mechanics, tightness of the Achilles tendon, shoes with poor cushioning, abnormal foot position and anatomy, and obesity.
In the younger patient, autoimmune and rheumatic diseases can be considered.
The symptom of plantar fasciitis is pain on the plantar surface of the foot that is worse when initiating walking. Examination usually reveals a point of deep tenderness at the anterior medial aspect of the calcaneus, the point of attachment of the plantar fascia. Pain and tenderness tend to be increased upon dorsiflexion of the toes. Diagnosis is clinical. Radiographic studies are not indicated unless other causes are being considered. The presence of heel spurs is of no diagnostic value because many patients without plantar fasciitis have this finding on imaging. For resistant cases, US and MRI may
 aid in diagnosis but are not indicated for evaluation in the ED.
Plantar fasciitis is generally a self­limited disease. Eighty percent of cases resolve spontaneously within  months. Initial treatment consists of rest, ice, NSAIDs, heel and arch support shoe inserts, taping or strapping of the foot, and dorsiflexion night splints (molded ankle­foot orthotics that hold
 the plantar fascia and Achilles tendon stretched). Plantar­specific stretch exercises are the most beneficial treatment in the acute phase: with the ankle dorsiflexed, the patient uses one hand to dorsiflex the toes and, with the other hand, palpates the plantar surface of the foot, confirming
  tension. Patients should be taught Achilles tendon stretching exercises and be told to avoid the use of flat shoes and barefoot walking. In severe cases, a short­leg walking boot may be useful to unload and rest the plantar fascia. Corticosteroid injections provide short­term benefit, up to 
  ,11 month, but are associated with plantar fascia rupture and are best left to the orthopedist. Refer patients to a podiatrist, orthopedist, or primary
,11 care physician for follow­up care.
NERVE ENTRAPMENT SYNDROMES
TARSAL TUNNEL SYNDROME
Tarsal tunnel syndrome is an uncommon source of foot pain and numbness in runners due to compression of the posterior tibial nerve as it
,17 courses behind the medial malleolus. The cause is usually from prior injury (scar tissue, bone or cartilage fragments, or bony spurs) and
,17 overpronation during running. Overpronation (inward rotation) makes the nerve more vulnerable both to direct trauma from stretch and to
,17 indirect trauma from inflammation of the surrounding structures, resulting in compression. Other causes include activities requiring restrictive
 footwear (ski boots, skates), edema from pregnancy, ganglion cysts, and tumors, but frequently, no inciting event is known.
Symptoms include numbness or burning pain of the sole and may be limited to the heel, mimicking plantar fasciitis. Distal calf pain may be due to retrograde radiation (Valleix phenomenon). Weakness is uncommon. Pain is often worse with running, at night, and after standing, and often leads to the desire to remove the shoes. Tinel sign is positive with percussion inferior to the medial malleolus yielding pain radiating to the medial or lateral
 plantar surface of the foot. Simultaneous dorsiflexion and eversion of the ankle exacerbates symptoms. Diagnosis is aided by nerve conduction
,17 studies or MRI, but these are not routinely ordered from the ED.
The differential diagnosis includes plantar fasciitis and, if limited to the heel, Achilles tendinitis. Plantar fasciitis will cause point tenderness over the plantar heel, and pain is worse upon morning standing. Tarsal tunnel syndrome causes greater medial heel and arch pain due to involvement of the abductor hallucis muscle. Tarsal tunnel pain worsens with ambulation throughout the day. In addition, tarsal tunnel syndrome may produce distal calf pain, whereas plantar fasciitis does not. Initial treatment includes avoidance of the exacerbating activities, NSAIDs, shoe modification, anti– neuropathic pain medications if NSAIDs are not helpful, and occasionally orthotics. If there is no improvement or symptoms recur after a few weeks,
,17 then orthopedic evaluation is recommended.
DEEP PERONEAL NERVE ENTRAPMENT

Deep peroneal nerve entrapment occurs most commonly at the location where the nerve courses under the inferior extensor retinaculum (Figure

285­3). Recurrent ankle sprains, soft tissue masses, trauma (both acute and repetitive), chronic biomechanical misalignment, edema, and tightfitting footwear (ski boots) are the most common causes. Symptoms are dorsal and medial foot pain and sensory hypoesthesia at the first toe web space. There may be loss of the ability to hyperextend the toes due to wasting of the extensor hallucis brevis and extensor digitorum brevis muscles.
Pain and tenderness can be elicited on palpation of the peroneal nerve at the site of entrapment and by plantar flexion with inversion of the foot. Pain
 is exacerbated by activity and relieved by rest. Nighttime pain is common. Treatment is the same as for tarsal tunnel syndrome.
FIGURE 285­3. Tendons of the foot, anterior view, including deep peroneal nerve.
GANGLIONS OF THE FOOT
A ganglion is a common benign synovial cyst. Ganglions are .5 to .5 cm in diameter and are often attached to a joint capsule or tendon sheath.
Although ganglions typically occur in the wrist or hand, they may also occur in the foot. Ganglions typically arise in the anterolateral aspect of the ankle but can occur in many areas of the foot. The cause is unknown. Ganglions may appear suddenly or gradually, may enlarge and diminish in size, and may be painful or asymptomatic. On examination, a ganglion is a firm, cystic lesion. Diagnosis is usually made clinically, although outpatient US or MRI may exclude other causes when serious pathology is suspected. Phenol cauterization by an orthopedist may lead to the complete resolution of
 ,24 ganglions in some cases, with surgical excision required for persistence.
TENDON LESIONS OF THE FOOT
TENOSYNOVITIS AND TENDINITIS
Tenosynovitis and tendinitis may occur in the foot, usually due to overuse. Patients present with pain over the involved tendon (Figure 285­3). The
 flexor hallucis longus, posterior tibialis, and Achilles tendon are most commonly involved. Once infection has been clinically ruled out, treatment
 consists of rest, ice, and oral NSAIDs.
Flexor hallucis longus tenosynovitis classically affects ballet dancers but can also be seen in runners and nonathletes. Presentation is similar to plantar fasciitis and tarsal tunnel syndrome. Posteromedial ankle pain, medial arch pain, and a positive Tinel sign (see earlier description in “Tarsal
Tunnel Syndrome”) are seen. Conservative management (rest, mobilization, orthotic shoe implant, NSAIDs) is usually successful. Surgery is reserved for refractory cases.
TENDON LACERATIONS
Tendon lacerations can result from penetrating injuries to the dorsal or plantar aspect of the foot. Tendon repairs in the foot are complex, and
 orthopedic consultation is needed for repair.
The foot should be casted in dorsiflexion after the repair of extensor tendons and in equinus after repair of flexor tendons.
TENDON RUPTURES

Spontaneous rupture of the Achilles tendon is common. Rupture of the anterior tibialis and posterior tibialis tendons may also occur. Age and chronic corticosteroid and fluoroquinolone use are risk factors for spontaneous rupture. Diagnosis is usually clinical but is aided by US or MRI studies in difficult cases.
Achilles tendon rupture occurs when a sudden shear stress, such as sudden pivoting on a foot or rapid acceleration, is applied to an already weakened or degenerative tendon. Many patients report immediate sharp pain, and some hear an audible “pop.” The peak age for rupture is  to 
 years, and rupture is four to five times more common in men than women. Over 80% of ruptures occur during recreational sports (“weekend warrior”). Patients often present with pain, a palpable defect in the area of the tendon, and inability to stand on tiptoes. A minority of patients with complete tendon ruptures are able to ambulate and may be misdiagnosed as having an ankle sprain. Squeezing the calf of the prone patient whose knee is flexed at  degrees will normally cause the foot to plantar flex (calf squeeze or Thompson test). The absence of plantar flexion indicates a positive test indicative of rupture. Initial ED treatment consists of ice, analgesics, immobilization of the ankle or foot in plantar flexion, crutches, and referral to an orthopedic surgeon for management and physical rehabilitation. Definitive treatment is generally surgical in younger patients and
,27 conservative (casting in equinus or plantar flexion) in older patients ; however, rehabilitation may be the most important determinant of
 outcome. For further discussion, see Chapter 276, “Ankle Injuries,” and Figure 276­8 (Thompson test) in Chapter 276. Ruptures of the anterior tibialis tendon are rare. Ruptures usually occur after the fourth decade and are not excessively painful. Patients present with varying degrees of foot drop and a palpable defect distal to the ankle joint in the area of the tendon. In most cases, disability is minimal, and
 surgery is not necessary.
Spontaneous ruptures of the posterior tibialis tendon also occur after the fourth decade. Two thirds of these cases occur in women. The presentation is usually chronic and insidious. Patients notice a gradual flattening of their arch, with modest discomfort and swelling over the medial ankle. Examination reveals absence of the tendon’s normal prominence and weakness on inversion of the foot. Patients find it impossible to stand on
 tiptoes. Treatment may be conservative or surgical, depending on the duration of the tear and activity of the patient.
Flexor hallucis longus rupture presents as a loss of plantar flexion of the great toe. The need for surgery will depend on the patient’s occupation
 and lifestyle.
Disruption of the peroneal retinaculum can occur as a result of direct trauma during dorsiflexion of the foot. Besides pain localized to the peroneal tendon behind the lateral malleolus, the patient complains of a clicking when walking as the tendon subluxes. Peroneal tendon injuries may lead to
 lateral ankle instability. Treatment is generally surgical repair.
PLANTAR INTERDIGITAL NEUROMA (MORTON’S NEUROMA)
Neuromas may form in a plantar digital nerve, usually proximal to its bifurcation. Neuromas may occur in any of the digital nerves but are most common in the third interspace. The cause is thought to be local irritation of the nerve due to entrapment, usually from tight­fitting shoes. Women between the ages of  and  years old are the most commonly affected group. Patients present with pain located in the area of the metatarsal head.
The pain is described as burning, cramping, or aching. Pain is worsened by ambulation and resolved by rest and removal of shoes. The pain may radiate to the affected toes, and patients may note numbness in the toes. Pain is usually easily reproduced upon palpation of the area, and at times, a mass is felt. Diagnosis is usually made clinically, but nerve conduction studies, electromyograms, US, and MRI may be helpful at times. Conservative
 treatment consists of wearing wide shoes with good metatarsal head supports and metatarsal head off­loading inserts. Local glucocorticoid
 injections can sometimes be curative. Surgical removal may be necessary for refractory symptoms.
COMPARTMENT SYNDROMES OF THE FOOT
The foot has up to nine compartments. Compartment syndrome occurs when an elevation of tissue pressure within one of these nonyielding fascial
 compartments impedes vascular flow. The cause of compartment syndrome is a high­energy injury (crush injury) associated with multiple fractures.
Compartment syndromes have been reported in association with foot and ankle fractures (especially calcaneal and Lisfranc’s fracture/dislocation), burns, contusions, bleeding disorders, postischemic swelling after arterial injury or thrombosis, venous obstruction, snakebites, exercise, and
 prolonged pressure to the affected area (e.g., cast immobilization, prolonged abnormal positioning). Pain out of proportion to injury is one of the early findings. Additional symptoms include pain that is worsened on active or passive movement, paresthesias, and neurovascular deficits. An absent pulse and complete anesthesia are late findings and may be difficult to assess due to underlying swelling. The only reliable objective method to diagnose compartment syndrome is by obtaining compartment pressures using an intra​compartmental pressure monitoring system (Stryker STIC
Device [Stryker, Kalamazoo, MI] or similar equipment). A difference between diastolic blood pressure and intracompartmental pressure of <30 mm Hg
 is an indication for fasciotomy. Once the diagnosis is made, fasciotomy should be performed emergently. In the ED, elevate the extremity to the level of the heart pending fasciotomy. The sequelae of compartment syndrome range from transient neurologic compromise to complete myoneural necrosis, fibrosis, and ischemic contractures. The prognosis of compartment syndrome is directly related to the time delay in diagnosis and treatment

(see Chapter 278, “Compartment Syndromes”).

Chronic exertional compartment syndrome is due to overuse. Symptoms occur with exertion and are relieved by rest. Patients should be instructed to avoid overexertion and be referred for further investigation and treatment.


