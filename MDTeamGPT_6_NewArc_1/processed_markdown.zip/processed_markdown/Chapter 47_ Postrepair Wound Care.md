## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 47: Postrepair Wound Care
Adam J. Singer; Judd E. Hollander; Joseph Stephan Stapczynski
INTRODUCTION
Postoperative care begins immediately after laceration repair in the ED with gentle cleansing using normal saline or clean (tap) water to remove any residual blood products or contamination. Additional considerations include dressings, topical antibiotics, edema reduction techniques, prophylactic antibiotics, tetanus prophylaxis, and wound drains. Before ED release, give the patient instructions regarding wound care and cleansing, pain control, signs of infection, follow­up dates, and short­term and long­term cosmetic expectations.
WOUND DRESSINGS
Postoperative wound dressing should be tailored to both the type of wound and method of wound closure. Most sutured or stapled lacerations should be covered with a protective, nonadherent dressing for  to  hours. Maintaining a moist environment increases the rate of re­epithelialization, and
1­3 occluded wounds heal faster than those exposed to air. Conversely, leaving lacerations exposed to air may result in a slightly lower healing rate but
 does not result in an increased rate of infection.
Useful dressings are semipermeable films manufactured from transparent polyurethane or similar synthetic films coated on one surface with a waterresistant hypoallergenic adhesive. They are highly elastic, conform easily to body parts, and are generally resistant to shear and tear. They are permeable to moisture vapor and oxygen but impermeable to water and bacteria. Common brands of semipermeable wound dressings are OpSite
Post­Op® (Smith & Nephew PLC, London, UK), Bioclusive® (Johnson & Johnson, New Brunswick, NJ), and Tegaderm® (3M, St. Paul, MN). The disadvantages of these products are that they cannot absorb large amounts of fluid and exudate and they do not adhere well to very moist wounds.
Topical antibiotic creams and ointments are an alternative to the use of commercial dressings to maintain a moist environment. As an added benefit,
5­7 topical antibiotics may help reduce infection rates and may also prevent scab formation. However, patients whose lacerations are closed with tissue adhesives should not use topical ointments or creams because they will loosen the adhesive and may result in dehiscence. Tissue adhesives serve as their own antimicrobial barrier and occlusive dressing; wounds closed with tissue adhesives do not require supplementary dressings.
EDEMA REDUCTION
Instruct patients to elevate the injury site for  to  hours when soft tissue contusion is present to limit accumulation of fluid in the wound area.
Wounds with little edema heal more rapidly than those with marked edema. Pressure dressings can be used to minimize the accumulation of intercellular fluid in the subcutaneous space. Pressure dressings are useful for ear and scalp lacerations (see Chapter , “Face and Scalp
Lacerations”). For large scalp lacerations that have a tendency to bleed, short­term use of a pressure dressing will limit subcutaneous hematoma formation. Avoid excessive pressure in all pressure dressings, especially in the extremities where they may compromise circulation. Tube gauze
,9 dressing applied to fingers or toes should not be twisted at the base of the digit; such twisting may create a tourniquet and lead to distal ischemia.
Consider a short period of splinting with large lacerations over joints to reduce pain, limit tension on the wound, minimize swelling, and promote healing.
PROPHYLACTIC ANTIBIOTICS
10­13
Prophylactic oral antibiotics are not recommended except for select circumstances based on guiding principles: the degree of bacterial contamination, the presence of infection­potentiating factors (e.g., soil), the mechanism of injury, and the presence or absence of host predisposition

14­17 ,17 to infection. Compulsive wound cleansing is far more important than antibiotics to reduce postrepair wound infection.
Chapter 47: Postrepair Wound Care, Adam J. Singer; Judd E. Hollander; Joseph Stephan Stapczynski 
. Terms of Use * Privacy Policy * Notice * Accessibility
Prophylactic antibiotics are recommended for human bites, cat bites, deep dog bite puncture wounds, bite wounds to the hand, open fractures, and wounds with exposed joints or tendon (see Chapter , “Puncture Wounds and Bites,” and Chapter 267, “Initial Evaluation and Management of
14­16,18­20 ,22
Orthopedic Injuries”). Also, consider prophylactic antibiotics after wound closure in a lymphedematous area.

The risk of bacteremia during care of grossly contaminated lacerations in the ED is unknown but is likely to be small. However, some patients who have structural heart disease, arteriovenous hemodialysis fistulas, prosthetic joints, cerebrospinal fluid shunts, vascular grafts, or other permanent indwelling “hardware” may trap bacteria from the bloodstream and develop infections in the previously mentioned organs or devices. There is no evidence for preprocedure antibiotic prophylaxis to prevent bacteremic spread of infection from manipulation of a contaminated site. Administer a single dose of an IV antibiotic before the wound is manipulated when antibiotic prophylaxis is desired during the management of a heavily contaminated wound in patients with these conditions or devices.

Antibiotics used for postrepair prophylaxis are similar to those used for treatment of established infections (Table 47­1). Oral administration is adequate for the initial dose, and there is no evidence that the parenteral route is better. Antibiotic prophylaxis continues for  to  days for nonbite injuries and  to  days for bite wounds.
TABLE 47­1
Postrepair Oral Antibiotic Prophylaxis
Situation Primary Recommendation Alternative Recommendation
Uncomplicated patient First­generation cephalosporin Macrolide or antistaphylococcal penicillin Clindamycin
Grossly contaminated wounds and/or retained foreign body Amoxicillin­clavulanate or Clindamycin plus a fluoroquinolone second­generation cephalosporin
Bite wounds Amoxicillin­clavulanate Clindamycin plus either a fluoroquinolone or trimethoprimsulfamethoxazole
Plantar puncture wounds Ciprofloxacin First­generation cephalosporin or antistaphylococcal penicillin
Underlying systemic immunodeficiency (acquired immunodeficiency Amoxicillin­clavulanate or Clindamycin plus a fluoroquinolone syndrome, chronic steroid use, poorly controlled diabetes mellitus) second­generation cephalosporin
Impaired local defenses (peripheral arterial disease, lymphedema) Amoxicillin­clavulanate Clindamycin or erythromycin
Although methicillin­resistant Staphylococcus aureus has become a common cause of skin and soft tissue infections, postinjury antibiotic prophylaxis
 ,15 to cover this pathogen does not appear necessary. Amoxicillin­clavulanate is the preferred prophylactic treatment for mammalian bite wounds.
For open fractures or joints, a parenteral first­generation cephalosporin should be used with an aminoglycoside added if extensive soft tissue injury is
 present.
TETANUS PROPHYLAXIS
Tetanus can occur when lacerations, puncture wounds, and crush injuries are contaminated with Clostridium tetani spores (see Chapter 157,

“Tetanus”). Most cases of tetanus in the United States occur in patients who are inadequately vaccinated. As part of wound care, ask the patient about previous tetanus immunizations. Recommendations for postinjury tetanus prophylaxis are based on the condition of the wound and the
 patient’s immunization history (Table 47­2). Because of the emergence of pertussis infections, Tdap (tetanus, diphtheria, and pertussis; containing the acellular pertussis vaccine) should be used in adults who have not previously received a dose of Tdap (either in the primary series, as a booster, or
 for wound management) or are >65 years old.
TABLE 47­2
Recommendations for Tetanus Prophylaxis
Clean Minor Wounds All Other Wounds* History of Tetanus Immunization
Administer Tetanus Toxoid† Administer TIG ‡ Administer Tetanus Toxoid Administer TIG
<3 or uncertain doses Yes No Yes Yes
≥3 doses
Last dose within  y No No No No
Last dose between 5–10 y No No Yes No
Last dose >10 y Yes No Yes No
Abbreviation: TIG = tetanus immune globulin.
*Especially if wound care delayed (>6 h), deep (>1 cm), grossly contaminated, exposed to saliva or feces, stellate, ischemic or infected, avulsions, punctures, or crush injuries.
†Tetanus toxoid: Tdap (tetanus, diphtheria, and pertussis) if adult and no prior record of administration or age >65 y; otherwise, tetanus­diphtheria toxoid if >7 y and diphtheria­tetanus toxoid if <7 y, preferably administered into the deltoid.
‡
Tetanus immune globulin: adult dose, 250–500 IU administered into deltoid opposite the tetanus­diphtheria toxoid immunization site.
The only contraindication to tetanus toxoid is a history of neurologic or severe systemic reaction after a previous dose. Local selflimited reactions, such as erythema, induration, and pain at the injection site, are common after tetanus vaccination. These local side effects do not preclude future tetanus immunization. Exaggerated local reactions occur occasionally after tetanus toxoid and involve extensive pain and swelling of the entire extremity. Exaggerated local reactions occur most often in adults with high serum tetanus antitoxin levels who have received frequent doses of tetanus toxoid. Such patients should not receive tetanus toxoid more frequently than every  years. Severe systemic reactions to tetanus immunization include generalized urticaria, anaphylaxis, or neurologic complications, including peripheral neuropathy and Guillain­Barré syndrome.
A severe allergic reaction, including acute respiratory distress or cardiovascular collapse after a dose of tetanus toxoid, is a contraindication to further immunization. If the use of a tetanus toxoid is contraindicated, consider passive immunization with tetanus immune globulin in a tetanus­prone wound.
WATER CONTACT AND CLEANING
Sutured or stapled wounds can be gently washed and cleansed with tap water as early as  hours after closure without an increase
26­28  in infection rate. Using soap and tap water to cleanse lacerations will not increase the infection rate. Use gentle blotting to dry the area; aggressive wiping could cause wound dehiscence. For routine wounds, tell patients to remove dressings after  hours, cleanse the wound, and examine it for signs of infection. When delayed primary closure is anticipated, the dressing should remain undisturbed for  to  days until the patient is reevaluated by the physician.
Daily cleansing ensures that the patient examines the laceration for early signs of infection. Patients should observe the wound for redness, warmth, swelling, and drainage, and contact a physician if such signs develop. Standardized wound­care instructions improve patient compliance and
 understanding. Reapplication of topical antibiotics for  to  days will decrease scab formation, thereby preventing wound edge separation.
Patients with wounds closed with tissue adhesives may occasionally and briefly get the area wet, but should avoid bathing and swimming because
 prolonged moisture will loosen the adhesive bond and result in earlier sloughing of the adhesive.
PAIN CONTROL
Abrasions and some lacerations can be quite painful. Patients should be educated regarding the expected degree of pain and measures that may help reduce pain. Splints can be used to reduce swelling and pain for extremity lacerations. Appropriate analgesic medications and anti­inflammatory agents will help control pain. The pain from lacerations generally decreases after the initial  hours, and opioid analgesics are rarely necessary after that time. Patients with concurrent contusions (such as victims of motor vehicle crashes) will often report worsening pain  to  hours after the initial injury.
FOLLOW­UP

Tell patients when and with whom to follow up for suture removal or wound examination. Appropriate time to remove nonabsorbable sutures or
 staples varies by location (Table 47­3). Facial sutures are removed in  to  days to avoid formation of unsightly sinus tracts and hatch marks.
Sutures over the joints or on the hands should be left in place for  to  days, as they may be subject to increased tension during movement.
TABLE 47­3
Suture and Staple Removal Recommendations
Location Days
Back 10–14
Buttocks 10–14
Chest 7–10
Delayed closure 8–12
Foot 10–14
Face 3–4 (child), 3–5 (adult)
Hand 10–14
Legs 8–10
Neck 2–3 (child), 3–4 (adult)
Overlying joints 10–14
Retention sutures 14–30
Scalp 10–14
Upper extremity 7–10
Source: Reproduced with permission from Reichman EF (ed): Reichman’s Emergency Medicine Procedures, 3rd ed. New York, NY: McGraw­Hill, Inc.; 2019, Table 114­5. Debride any scab or crusting engulfing the sutures before suture removal, such as by gently applying gauze soaked with hydrogen peroxide. When removing sutures, grasp the suture at the knot with the forceps for removal (Figure 47­1). Avoid applying tension in a direction that would tend to cause dehiscence. Use scissors or a #12 blade to cut the sutures. Skin staples are removed with a device that deforms the center and extracts the legs from the skin (Figure 47­2).
FIGURE 47­1. Suture removal. A. For simple interrupted percutaneous sutures, grasp the suture with the forceps at the knot, cut the suture with scissors on the side of the wound opposite the knot, and pull the knot across the wound. B. Alternatively, cut the suture with a curved #12 blade on the side of the wound opposite the knot (left) and pull the knot across the wound (right). C. For vertical mattress sutures, cut the suture on the side opposite the knot and pull the knot with forceps. D. For horizontal mattress sutures, cut the suture on the side opposite the knot and pull the knot with forceps. [A, C, and D reproduced with permission from Reichman EF (ed): Reichman’s Emergency Medical Procedures, 3rd ed. New York, NY: McGraw­Hill, Inc.; 2019, Figure
.]
FIGURE 47­2. Skin staple removal. A. Place the lower jaw of the staple remover under the horizontal portion of the staple. B. The upper jaw deforms the center of the staple and extracts the vertical legs from the skin. [Reproduced with permission from Reichman EF (ed): Reichman’s Emergency Medical Procedures,
3rd ed. New York, NY: McGraw­Hill, Inc.; 2019, Figure 116­28A&B.]
Tissue adhesives will slough off, typically within  to  days of application, and do not usually require removal. Tell the patient to avoid picking at the tissue adhesive, scrubbing the area, or exposing it to water for more than brief periods. If tissue adhesives remain on the skin for prolonged periods, antibiotic ointment, petroleum jelly, or bathing can accelerate removal. When adhesive tapes are used, they can be removed by gentle peeling away from the skin, starting at one end of the laceration and proceeding along and parallel to the wound, avoiding pulling across or perpendicular to the wound.
Scheduled “wound checks” might be useful in high­risk patients, high­risk wounds, or patients unable to identify signs of infection. Because many healing wounds may develop erythema and patients are not able to correctly identify wound infections, do not prescribe antibiotics without a
 reevaluation. Patients who require further tetanus immunization to complete their primary series should have the second dose  to  months after the first dose, and the third dose  to  months after the second dose.
LONG­TERM COSMETIC OUTCOME
Educate patients about the expected outcome before wound closure. Reinforce the message at the time of suture or staple removal or wound followup. Tell patients that all traumatic lacerations result in some scarring and that short­term cosmetic appearance is not highly predictive of the ultimate
 cosmetic outcome. For patients concerned about scar formation, scar­prevention therapies can be used after the initial phase of wound healing,
 typically after  weeks. Healing lacerations and abrasions should not be exposed to direct sunlight, because sun exposure can result in permanent
 hyperpigmentation. Protect injured skin with a sun­blocking agent for  to  months after injury.


