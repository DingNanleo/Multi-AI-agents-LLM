## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 131: Vomiting, Diarrhea, and Dehydration in Infants and Children
Stephen B. Freedman; Jennifer Thull­Freedman
INTRODUCTION
Acute viral gastroenteritis is the most common cause of vomiting and diarrhea in children and continues to account for over 500,000 deaths globally
 each year in children <5 years old. Transmission of GI infections can be reduced by attention to good hand washing, which can reduce the incidence of
 diarrheal disease by approximately 30% in both high­ and low­income countries. The provision of alcohol­based hand sanitizer and educational
 materials can reduce GI illnesses in child care centers, and a multifactorial intervention including hand sanitizer and surface disinfection similarly
 reduces illness due to enteric pathogens in elementary school students.
Rotavirus previously accounted for the majority of severe cases and contributed significantly to hospitalizations in developed countries. However, the introduction of two live oral rotavirus vaccines, marketed as RotaTeq® and Rotarix®, for use in the United States and numerous other countries has
,6 resulted in an approximately 80% reduction in rotavirus­related hospitalizations and ED visits for rotavirus among immunized children. Although a prospective postlicensure study of more than 200,000 doses identified an increase in the rate of intussusception after vaccination (attributable risk

~5.3 per 100,000 infants vaccinated), the increased risk must be weighed against the benefits of preventing rotavirus­associated illness. The reduction in rotavirus’s burden of disease along with the improved ability to identify norovirus has led to a realization that norovirus is now the pathogen
 responsible for the greatest burden of medically attended cases of gastroenteritis.
Although the clinical diagnosis of gastroenteritis requires the presence of diarrhea, many infants present with isolated vomiting. This chapter focuses on one of the most frequent and important causes of vomiting and diarrhea in children, gastroenteritis, and will also review other important causes of these symptoms.
VOMITING
Vomiting is the forceful act of expelling gastric contents through the mouth. It is controlled by the vomiting center in the reticular formation of the medulla and the chemoreceptor trigger zone underlying the floor of the fourth ventricle. Trigger areas that excite the CNS vomiting centers are found in the pharynx, cardiac vessels, peritoneum, bile ducts, and stomach. Vomiting results when the stomach relaxes, the gastric pylorus constricts, and the contractions of surrounding muscles cause expulsion of the gastric contents. Acute vomiting is usually caused by a self­limited viral illness.
Nonetheless, serious diagnoses that need to be considered include infections, metabolic abnormalities, neurologic processes, acute surgical/GI diseases, or other major organ system dysfunction. The differential diagnosis of vomiting is age specific (Table 131­1). Bilious or bloody vomitus, hematochezia, or significant abdominal pain should trigger concerns of a disease process other than simple viral gastroenteritis or a potential complication of viral gastroenteritis (Tables 131­2 and 131­3).
TABLE 131­1
Causes of Vomiting, by Age
Newborn
Obstructive Esophageal stenosis/atresia, pyloric stenosis, intestinal stenosis/atresia, malrotation ± volvulus, incarcerated hernia, meconium intestinal anomalies ileus/plug, Hirschsprung’s disease, imperforate anus, enteric duplications
Neurologic Intracranial bleed/mass, hydrocephalus, cerebral edema, kernicterus

ChapteRre n1a3l1: Vomiting, DiarUrhrienaar,y a tnradc tD inefhecytdiorna,t ioobns tirnu cIntifvaen utrso apantdh yC, rheinldarle inns,u Sfftiecipehnceyn B. Freedman; Jennifer Thull­Freedman 
. Terms of Use * Privacy Policy * Notice * Accessibility
Infectious Viral illness, gastroenteritis, meningitis, sepsis
Metabolic/endocrine Inborn errors of metabolism (urea cycle, amino/organic acid, carbohydrate), congenital adrenal hyperplasia
Miscellaneous Ileus, gastroesophageal reflux, necrotizing enterocolitis, GI perforation
Infant (<12 mo)
Obstructive Pyloric stenosis, malrotation ± volvulus, incarcerated hernia, Hirschsprung’s disease, enteric duplications, intussusception, foreign intestinal anomalies body, bezoars, Meckel’s diverticulum
Neurologic Intracranial bleed/mass, hydrocephalus, cerebral edema
Renal Urinary tract infection, obstructive uropathy, renal insufficiency
Infectious Viral illness, gastroenteritis, meningitis, sepsis, otitis media, pneumonia, pertussis, hepatitis
Metabolic/endocrine Inborn errors of metabolism, adrenal insufficiency, renal tubular acidosis
Miscellaneous Ileus, gastroesophageal reflux, posttussive, peritonitis, drug overdose, food allergy
Child (>12 mo)
Obstructive Malrotation ± volvulus, incarcerated hernia, Hirschsprung’s disease, intussusception, foreign body, bezoars, Meckel’s diverticulum, intestinal anomalies acquired esophageal stricture, peptic ulcer disease, adhesions, superior mesenteric artery syndrome
Neurologic Intracranial bleed/mass, cerebral edema, postconcussive, migraine
Renal Urinary tract infection, obstructive uropathy, renal insufficiency
Infectious Viral illness, gastroenteritis, meningitis, sepsis, otitis media, pneumonia, hepatitis, streptococcal pharyngitis
Metabolic/endocrine Inborn errors of metabolism, adrenal insufficiency, renal tubular acidosis, diabetes mellitus, Reye’s syndrome, porphyria
Miscellaneous Ileus, gastroesophageal reflux, posttussive, peritonitis, drug overdose, food allergy, appendicitis, pancreatitis, gastritis, Crohn’s disease, pregnancy, psychogenic, cyclic vomiting syndrome
TABLE 131­2
Causes of Vomiting With Significant Morbidity, by Age
Newborn Period (birth–2 wk)
Obstructive Esophageal or intestinal stenosis/atresia, bowel malrotation ± midgut volvulus, meconium ileus/plug, Hirschsprung’s disease, intestinal anomaly imperforate anus, enteric duplications
Other GI disease Necrotizing enterocolitis, perforation with secondary peritonitis processes
Neurologic Mass lesion, hydrocephalus, cerebral edema, kernicterus
Renal Obstructive anomaly, uremia
Infectious Sepsis, meningitis
Metabolic Inborn errors of metabolism, congenital adrenal hyperplasia
Infant (2 wk–12 mo)
Acquired esophageal Foreign body, retropharyngeal abscess disorders
GI obstruction Bezoar, foreign body, pyloric stenosis, malrotation ± volvulus, enteric duplications, complications of Meckel’s diverticulum, intussusception, incarcerated hernia, Hirschsprung’s disease
Other GI disease Gastroenteritis with dehydration, peritonitis processes
Neurologic Mass lesion, hydrocephalus
Renal Obstruction, uremia
Infectious Sepsis, meningitis, pertussis
Metabolic Inborn errors of metabolism
Toxic ingestions —
Child (>12 mo)
GI obstruction Bezoar, foreign body, posttraumatic intramural hematoma, malrotation ± volvulus, complications of Meckel’s diverticulum, intussusception, incarcerated hernia, Hirschsprung’s disease
Other GI disease Appendicitis, peptic ulcer disease, pancreatitis, peritonitis processes
Neurologic Mass lesions
Renal Uremia
Infectious Sepsis, meningitis
Metabolic Diabetic ketoacidosis, adrenal insufficiency, inborn errors of metabolism
Toxic ingestion —
TABLE 131­3
Causes of Diarrhea With Significant Morbidity
Infection: Salmonella gastroenteritis with bacteremia, Shigella, Clostridium difficile (pseudomembranous colitis)
Anatomic abnormalities
Intussusception
Hirschsprung’s disease with toxic megacolon
Partial obstruction
Appendicitis
Inflammatory bowel disease with toxic megacolon
Verotoxigenic Escherichia coli infection with the secondary development of hemolytic­uremic syndrome
Bilious vomiting suggests an obstructive lesion distal to the ampulla of Vater and portends a surgical emergency. From one third to half of newborns
,10 with bilious vomiting have a surgical lesion, often malrotation with volvulus or Hirschsprung’s disease. For further discussion, see Chapter 133,
“Acute Abdominal Pain in Infants and Children.” For discussion of hematemesis, see Chapter 134, “Gastrointestinal Bleeding in Infants and Children.”
Diagnostically, it is important to consider children with isolated vomiting separately from those who present with vomiting and diarrhea. The differential diagnosis of vomiting is vast and age specific (Table 131­1). Gastroesophageal reflux, intussusception, pyloric stenosis, and malrotation are discussed briefly below and more fully in Chapter 133, “Acute Abdominal Pain in Infants and Children.”
GASTROESOPHAGEAL REFLUX (GERD)
Gastroesophageal reflux is the spontaneous regurgitation of gastric contents into the esophagus. Reflux is physiologic in young infants and usually resolves by the end of the first year of life. It is considered pathologic only in the small subset that experiences complications. The typical infant with uncomplicated gastroesophageal reflux effortlessly brings up small amounts of milk after feeding but continues to grow well. Symptoms may begin as early as the first week of life and often resolve around the time of solid food introduction and the assumption of the sitting position. In infants with significant vomiting, pathologic conditions should be considered. Complications that can occur include esophagitis, failure to thrive/weight loss, respiratory disease, refractory asthma, recurrent pneumonia, apnea, and acute life­threatening events. In most infants, the diagnosis can be made based on clinical findings. The gold standard diagnostic test is continuous esophageal pH monitoring to detect the presence of gastric acid in the distal esophagus. Semi­supine positioning (e.g., infant carrier or car seat) may exacerbate gastroesophageal reflux and should be avoided, especially after
 feeding. Although severe cases may require a histamine­2 receptor antagonist or a proton pump inhibitor, the overuse of medications in the “happy
 spitter” should be avoided.
INTUSSUSCEPTION
Intussusception occurs when one segment of bowel invaginates into a more distal segment. It is the leading cause of acute intestinal obstruction in infants and occurs most commonly between  and  months of age. The most common location is ileocolic, and the lead point usually is a hypertrophied Peyer patch. However, in children >2 years of age, a specific pathologic lead point should be considered. The primary manifestation is colicky abdominal pain followed by the onset of vomiting. The “classic” triad of colicky abdominal pain, vomiting, and bloody stools is present in only
20% of cases. For further discussion of intussusception, see Chapter 133, “Acute Abdomnal Pain in Infants and Children.”
PYLORIC STENOSIS
Pyloric stenosis results from pyloric muscle hypertrophy that obstructs gastric outflow. The incidence is  in 250 live births, and >80% of cases occur in
 males ; other risk factors include white race, first born birth order, and a positive family history. Over 90% of cases are diagnosed by  weeks of life,
 with a sharp increase in the incidence after the second week of life, peaking at the fifth week and then steadily declining until the 10th week. Children typically present with nonbilious projectile vomiting associated with weight loss and dehydration. Initially, the vomiting is mild and often mistaken for regurgitation. However, vomiting progresses and becomes more severe over several days. ED treatment includes the correction of fluid and electrolyte abnormalities. The pathognomonic electrolyte abnormalities are a hyponatremic, hypokalemic, and hypochloremic metabolic alkalosis. At present, the diagnosis is usually confirmed by US.
MALROTATION
Malrotation occurs when incomplete rotation of the gut in utero places the cecum in the right upper quadrant and fixes the dorsal mesentery on a narrow base instead of the broad fixation that usually extends from the ligament of Treitz to the ileocecal junction. These anomalies place the small bowel at risk for twisting on the narrow pedicle of mesentery, resulting in a volvulus that subsequently impairs blood flow to the bowel. Although
 malrotation can present at any age, roughly one third of patients present in the first month of life. Symptoms may include bilious vomiting, pain, abdominal distention, and, ultimately, shock due to intestinal ischemia. Bilious emesis, particularly in a young infant, should immediately raise a concern for possible malrotation and volvulus. In some children, the volvulus can be intermittent, resulting in episodic vomiting and pain. Prompt diagnosis and surgical repair are needed to minimize the risk of bowel necrosis and death.
DIARRHEA
Diarrhea is loose or liquid stools and/or an increase in the frequency of evacuations with at least three stools in  hours. The child’s age and diet affect stool consistency and frequency. For example, in the first month of life, a change in stool consistency is more specific for diarrhea than absolute stool number. Breastfed infants typically have several poorly formed, yellow­green stools per day. Recognition of diarrhea in infants is important, because given their small size, they have limited fluid reserves and are at high risk for developing dehydration.
Most children with diarrhea have an acute viral infection, but diarrhea may be a presenting symptom of many conditions (Tables 131­4 and 131­5).
Preexisting conditions may contribute to the clinical presentation or predispose the patient to an unusual cause of diarrhea, so it is important to inquire about previous GI surgery or chronic illnesses such as inflammatory bowel disease and immunodeficiency states. Bacterial and parasitic infections are more likely in institutionalized children and those returning from travel in low­ and middle­income countries. Other causes of diarrhea include food allergies, antibiotic­associated diarrhea, and secondary lactase deficiency.
TABLE 131­4
Causes of Diarrhea
Infection
Viral: rotavirus, norovirus, enteric adenoviruses, sapoviruses, astroviruses
Bacterial: Salmonella, Shigella, Yersinia, Campylobacter, Escherichia coli, Aeromonas hydrophila, Vibrio species, Clostridium difficile
Parasitic: Giardia lamblia, Entamoeba histolytica, Cryptosporidium
Dietary disturbances
Overfeeding, food allergy, starvation stools
Anatomic abnormalities
Intussusception, Hirschsprung’s disease, partial obstruction, appendicitis, blind loop syndrome, intestinal lymphangiectasia, short bowel syndrome
Inflammatory bowel disease
Malabsorption or secretory diseases
Cystic fibrosis, celiac disease, disaccharidase deficiency, acrodermatitis enteropathica, secretory neoplasms
Systemic diseases
Immunodeficiency, endocrinopathy (hyperthyroidism, hypoparathyroidism, congenital adrenal hyperplasia)
Miscellaneous
Antibiotic­associated diarrhea, secondary lactase deficiency, irritable colon syndrome, neonatal drug withdrawal, toxins, hemolytic­uremic syndrome
TABLE 131­5
Mechanisms of Infectious Diarrheal Disease
Characteristic
Pathogen Type Mechanism Pathologic Impact Clinical Impact
Examples
Viral Rotaviruses Invade small intestinal Loss of mature absorptive cells, producing a Salt and water enteropathogens Adenoviruses mucosa villous epithelium proliferative response, resulting in repopulation of absorption is intestinal epithelial lining with poorly differentiated decreased cells. Carbohydrate malabsorption and osmotic diarrhea
Bacterial Invasive Adhere to mucosal cells Intramucosal multiplication elicits an acute mucosal Salt and water enteropathogens Shigella followed by invasion and inflammatory reaction, resulting in ulceration and absorption is
Salmonella multiplication, primarily in synthesis of a variety of secretagogues. decreased (secretory
Yersinia large intestine diarrhea) enterocolitica
Campylobacter jejuni
Vibrio parahaemolyticus
Cytotoxic Elaboration of cytotoxins Cause cell damage and death by inhibiting protein Decreased intestinal
Shigella synthesis or by inducing the secretion of one or more absorptive surface
Enteropathogenic inflammatory mediator substances.
Escherichia coli
Enterohemorrhagic
E. coli
Clostridium difficile
Toxigenic Colonize small intestine Enterotoxin binds to specific mucosal receptors, Alter intestinal salt
Shigella and secrete enterotoxins increasing the concentration of an intracellular and water transport
Enterotoxigenic E. mediator (adenosine 3′:5′­cyclic phosphate or cyclic without affecting coli guanosine monophosphate). mucosal morphology
Y. enterocolitica
Aeromonas
Vibrio cholerae
Adherent Colonization and Binding to epithelial cells indents the surface and Decreased intestinal
Enteropathogenic adherence to intestinal causes glycocalyx dissolution and microvilli absorptive surface
E. coli surface of small and large flattening.
Enterohemorrhagic intestine
E. coli
Acute onset of bloody diarrhea suggests a bacterial cause and a need to perform stool cultures. If there is a known outbreak of Escherichia coli O157:H7 (STEC, or Shiga toxin­producing E. coli), or clinical features of hemolytic­uremic syndrome (HUS), obtain further
 testing to exclude renal failure, thrombocytopenia, and hemolytic anemia and provide early volume expansion. An infant with intermittent, crampy abdominal pain, vomiting, and bloody stools raises concern for intussusception, pseudomembranous colitis, parasitic infection, or inflammatory bowel disease.
DEHYDRATION
Regardless of the cause of vomiting and diarrhea, the end result is fluid loss. Parental reports of dehydration, although highly sensitive, have a high
 false­positive rate. However, a history of normal fluid intake and normal urine output drastically reduces the likelihood of significant dehydration.
Thus, for the majority of children, the physical examination remains crucial and should begin by assessing the child’s overall appearance, level of activity, responsiveness, respiratory pattern, and vital signs. Although the American Academy of Pediatrics, Centers for Disease Control and
Prevention, World Health Organization, and European Society for Paediatric Gastroenterology, Hepatology, and Nutrition have developed treatment
 guidelines based on the degree of dehydration, no single variable in isolation is sufficiently accurate to determine the severity of dehydration. The percentage of body weight lost remains the gold standard measurement of dehydration, but it is infrequently available in the ED. Thus, while we recommend that physicians continue to rely on the presence of a combination of clinical findings as well as historical features to determine the degree
 of dehydration (see Table 132­2), their ability to identify children both with and without dehydration is suboptimal. Moreover, current evidence does not support the routine use of US or urinalysis to determine dehydration severity. A validated dehydration score derived from several clinical
17–19  studies, which correlates with length of stay and need for IV rehydration, is described in Table 131­6. TABLE 131­6
Clinical Dehydration Score
Score General Appearance Eyes Oral Mucosa (Tongue) Tears
 Normal Normal Moist Normal
 Thirsty, restless, lethargic but irritable Mildly sunken Sticky Decreased
 Drowsy/nonresponsive, limp, cold, diaphoretic Very sunken Dry None
Score >0 = some dehydration; score >5 = moderate­severe dehydration.
GASTROENTERITIS
EPIDEMIOLOGY
Diarrheal diseases are the second leading cause of death worldwide in children outside of the neonatal period. Rotavirus is the most common pathogen in areas without a vaccination program, and in areas with widespread rotavirus vaccination, norovirus is the most common pathogen.
PATHOPHYSIOLOGY
To cause diarrhea, an infectious agent must overcome numerous host defense factors, including gastric acidity, intestinal immunity, motility, mucus, and the resident microflora. The interaction between these factors and the infecting agent’s virulence mechanisms determines the subsequent clinical course (Table 131­5). No matter what the mechanism is, acute gastroenteritis is associated with fluid shifts and has the potential to cause dehydration, shock, and even death. The common final pathway results in fluid output exceeding the absorptive capacity of the GI tract. Fasting, which sometimes occurs with gastroenteritis, actually worsens the capacity of the bowel to absorb fluids. Continued feeding not only slows the progression of dehydration by increasing the volume of fluid available to the intravascular space, but the presence of nutrients in the bowel lumen also promotes
 mucosal recovery and improves fluid absorption.
CLINICAL FEATURES
Diarrhea associated with acute viral gastroenteritis typically lasts <7 days and not longer than  days, and it may be accompanied by vomiting or fever. Clinical features associated with the most important causes of bacterial gastroenteritis are listed in Table 131­7. Isolated vomiting should not be diagnosed as acute gastroenteritis. The differential diagnosis for isolated vomiting in the absence of diarrhea is broad.
TABLE 131­7
Clinical Features and Treatment of Bacterial Gastroenteritis24
Antimicrobial
Organism Typical Clinical Features Risk Factors Complications
Therapy* Shigella Ranges from watery stools Contact with infected Pseudomembranous colitis, toxic Typically self­limited without constitutional host or fomite, poor megacolon, intestinal perforation, Treat if: symptoms to fever, abdominal sanitation, crowded bacteremia, Reiter’s syndrome, immunocompromised, pain, tenesmus, mucoid stools, living conditions, day hemolytic­uremic syndrome, severe disease, hematochezia; Shigella care encephalopathy, seizures, dysentery or systemic dysenteriae serotype  causes hemolysis symptoms more severe symptoms If susceptibility unknown: azithromycin, ceftriaxone, ciprofloxacin; if susceptible, ampicillin or trimethoprimsulfamethoxazole
Salmonella Nontyphoidal: may be Direct contact with Meningitis, brain abscess, Typically self­limited asymptomatic or cause watery animals: poultry, osteomyelitis, bacteremia, Treat if: <3 mo of age, diarrhea, mild fever, abdominal livestock, reptiles, pets; dehydration, endocarditis, enteric hemoglobinopathy, cramps consuming food (typhoid or paratyphoid) fever immunodeficiency,
Enterica serotypes: “enteric contaminated by human chronic GI tract disease, fever” may include high fever, carrier: beef, poultry, malignancy, severe constitutional symptoms, eggs, dairy, water colitis, bacteremia, headache, abdominal pain, sepsis dactylitis, Options: ampicillin, hepatosplenomegaly, rose amoxicillin, spots, altered mental status trimethoprimsulfamethoxazole; if resistant, azithromycin, fluoroquinolone
Invasive disease: cefotaxime, ceftriaxone
Campylobacter Diarrhea, hematochezia, Contamination from Acute: dehydration, bacteremia, Often self­limited; 20% abdominal pain, fever, malaise poultry feces or focal infections, febrile seizures have relapse or undercooked poultry, Convalescence: reactive arthritis, prolonged symptoms untreated water, Reiter’s syndrome, erythema Treat if: moderateunpasteurized milk, pets nodosum, acute idiopathic severe symptoms,
(dogs, cats, hamsters, polyneuritis, Miller Fisher relapse, birds); person­to­person syndrome, myocarditis, pericarditis immunocompromised, transmission possible day care and institutions
Options: erythromycin, azithromycin, ciprofloxacin
Escherichia coli–Shiga Initially nonbloody diarrhea, Food or water Hemorrhagic colitis, hemolytic­ None indicated; toxin producing often becoming bloody; severe contaminated with uremic syndrome increased incidence of abdominal pain human or cattle feces, hemolytic­uremic undercooked beef, syndrome with unpasteurized milk treatment
E. Severe watery diarrhea, usually Food or water Dehydration Treat if severe coli–enteropathogenic children <2 years in resource­ contaminated with feces Options: trimethoprimlimited countries sulfamethoxazole, azithromycin, ciprofloxacin
E. coli–enterotoxigenic Moderate watery diarrhea, Food or water Dehydration Treat if severe abdominal cramps; traveler’s contaminated with feces Options: trimethoprimdiarrhea sulfamethoxazole, azithromycin, ciprofloxacin
E. coli–enteroinvasive Fever, bloody or nonbloody Food or water Dehydration Treat if severe diarrhea, dysentery contaminated with feces Options: trimethoprimsulfamethoxazole, azithromycin, ciprofloxacin
E. Watery diarrhea, may be Food or water Dehydration Treat if severe coli–enteroaggregative prolonged contaminated with feces Options: trimethoprimsulfamethoxazole, azithromycin, ciprofloxacin
Yersinia Bloody diarrhea with mucus, Contaminated food: Acute: bacteremia, pharyngitis, Typically self­limited; if fever, abdominal pain; improperly cooked pork, meningitis, osteomyelitis, severe, treat with pseudoappendicitis syndrome: unpasteurized milk, pyomyositis, conjunctivitis, trimethoprimfever, right lower quadrant untreated water; contact pneumonia, empyema, sulfamethoxazole, pain, leukocytosis; Yersinia with animals (ungulates, endocarditis, acute peritonitis, aminoglycosides, pseudotuberculosis causes rodents, rabbits, birds) liver/spleen abscess; cefotaxime, fever, scarlatiniform rash, convalescence: erythema fluoroquinolones, abdominal pain nodosum, glomerulonephritis, tetracycline, reactive arthritis doxycycline, chloramphenicol
Vibrio cholerae Voluminous watery diarrhea, Travel to affected areas, May rapidly lead to hypovolemic Treat if moderate or usually without cramps or consumption of shock, hypoglycemia, hypokalemia, severe: azithromycin, fever, classically described as contaminated water or metabolic acidosis, seizures doxycycline;
“rice water” stools food (particularly ciprofloxacin or undercooked seafood) trimethoprimsulfamethoxazole if resistant
*Most experts continue to limit fluoroquinolone use in children to those selected clinical situations where the benefits clearly outweigh the risks of therapy and there are few other antibiotic choices.
Abdominal pain is often associated with gastroenteritis, but pain is typically poorly localized and crampy with no peritoneal signs on examination. If peritoneal signs are present, consider an alternative diagnosis, such as acute appendicitis. Although appendicitis typically manifests with abdominal pain followed by vomiting associated with constipation, it may also cause diarrhea, particularly once the appendix has perforated. This is presumed to occur because the inflammation irritates the colon, resulting in diarrhea. Stools tend to be frequent, mucus­containing, and small in volume. For further discussion, see Chapter 133, “Acute Abdominal Pain in Infants and Children.”
LABORATORY TESTING
Obtain a CBC only if the child is ill appearing or has bloody diarrhea (mainly to identify bacterial enterocolitis or hemolytic­uremic syndrome). The WBC
21–23 count and C­reactive protein are not reliable for distinguishing viral from bacterial gastroenteritis. The C­reactive protein is only helpful for following activity of inflammatory bowel disease. Given that the reported prevalence of hypoglycemia may be as high as 9% in pediatric
 gastroenteritis, measuring serum glucose in infants and young children is essential.
,26
Obtain serum electrolytes only in specific circumstances. Table 131­8 lists the European Society for Paediatric Gastroenterology,
Hepatology, and Nutrition recommendations for measuring electrolytes in children with gastroenteritis.
TABLE 131­8
Recommendations for Measuring Glucose and Serum Electrolytes
Moderately dehydrated children whose history and physical examination findings are inconsistent with acute gastroenteritis
All severely dehydrated children
All children requiring IV rehydration31
Source: Reproduced with permission from Guarino A, Albano F, Ashkenazi S, et al: European Society for Paediatric Gastroenterology, Hepatology, and
Nutrition/European Society for Paediatric Infectious Diseases evidence based guidelines for the management of acute gastroenteritis in children in Europe. J
Paediatr Gastroenterol Nutr 46: S81, 2008. Copyright Lippincott Williams & Wilkins.

In a study assessing the utility of routinely obtaining electrolytes in 182 children receiving IV rehydration, an electrolyte abnormality was present in nearly half, and management changed in 10% of children. All interventions were related to the administration of fluids and glucose or potassium.
Although BUN is elevated in severe dehydration, it does not identify lesser degrees of dehydration very well. Serum bicarbonate>15 mEq/L makes
  dehydration unlikely. Last, urinary indices have been demonstrated to correlate poorly with severity of dehydration.
RAPID STOOL TESTS
Classic gastroenteritis of bacterial origin arises in the distal small bowel or colon to cause dysentery, with fecal blood, pus, and mucus. Most viral, parasitic, and toxin­mediated etiologies do not cause significant inflammation. Thus, tests for inflammatory markers might help differentiate between viral and bacterial gastroenteritis. Identifying fecal leukocytes has technical limitations, including the need for an experienced technician and a fresh stool sample to provide an accurate identification. More than five WBCs per high­power field has a sensitivity of 73% (95% confidence interval, .33% to

.94%) and specificity of 84% (95% confidence interval, .50% to .96%) and is moderately useful for identifying bacterial gastroenteritis. A marker for fecal leukocytes, fecal lactoferrin, is increased during bacterial infection and in children with clinically more severe disease, and thus it may be a
 good marker for predicting and monitoring intestinal inflammation in children with infectious diarrhea.
STOOL CULTURES
With a diagnostic yield as low as 2% and a high cost per positive result, routine stool cultures are not necessary in acute gastroenteritis. In
,33 select instances, however, stool culture is warranted. Several high­risk factors have been identified: >10 stools in the previous  hours, travel to
   ,34  high­risk country, fever, older age child, blood or mucus in stool, and abdominal pain/tenderness. Obtain stool cultures in cases of persistent diarrhea, when a specific antimicrobial treatment is being considered, or when infection must be excluded to support another diagnosis, such as inflammatory bowel disease. Rectal swabs are an excellent alternative to stool when enteropathogen identification and rapid detection are needed, appropriate molecular diagnostic technology is available, and a stool specimen is not immediately
 available.
Five bacterial pathogens commonly produce gastroenteritis in North America (Table 131­7): Salmonella, Shigella, Yersinia, Campylobacter, and pathogenic E. coli. All but E. coli do not normally inhabit the alimentary tract, so their identification in stool specimens diagnoses bacterial gastroenteritis. E. coli, however, is part of the usual gut flora and is rarely pathogenic; therefore, serotyping is useful for detecting E. coli O157, which causes hemolytic­uremic syndrome. In some parts of the world, Vibrio cholerae is a common bacterial cause of gastroenteritis.
IMAGING
In general, radiologic investigations play a very limited role in assessment of pediatric acute gastroenteritis. Imaging is valuable when the diagnosis is uncertain, such as may occur in children with isolated vomiting. Although plain films of the abdomen are usually nonspecific and have low sensitivity, they may be a useful starting point when looking for bowel obstructions, foreign bodies, and bowel perforation. On the other hand, in a group of neonates with bilious vomiting in the first  hours of life, 56% of lesions requiring surgical repair were not detected with the use of plain
 abdominal radiographs, reinforcing the need for further imaging when clinically indicated. A history of abdominal surgery or foreign body ingestion, or evidence on exam of abnormal bowel sounds, abdominal distention, or peritonitis has 93% sensitivity and 40% specificity in detecting diagnostic or
 suggestive radiographs in patients with major diseases potentially requiring procedural intervention. Abdominal ultrasonography has an important diagnostic role in pediatric centers, but usefulness depends upon technical expertise.
TREATMENT
Oral Rehydration Therapy
Treatment is directed at (1) preventing or treating dehydration, (2) replacing ongoing fluid losses, and (3) meeting nutritional needs. The worldwide adoption of oral rehydration therapy has revolutionized the treatment of dehydration. Oral rehydration therapy has reduced mortality in developing nations and is a safe and effective treatment for dehydrated children in developed nations.
The physiologic effectiveness of oral rehydration therapy is based on the coupled transport of sodium and glucose molecules at the brush border of intestinal epithelial cells, which provides a gradient for the passive absorption of water. This mechanism remains relatively intact, even in severe
 diarrheal disease, and functions optimally when the sodium­to­glucose ratio is 1:1. The World Health Organization recommends an oral rehydration solution with a sodium concentration of  mmol/L, and it is effective for children with noncholera diarrhea as measured by reduced stool output,
 reduced vomiting, and a reduced need for supplemental IV therapy. Most commercially available oral rehydration solution formulations in North
America and Europe contain  to  mmol/L of sodium (Table 131­9). Many other beverages traditionally suggested for children with vomiting and diarrhea, such as tea, juice, or sports drinks, are deficient in sodium and may provide excessive sugar, amplifying fluid losses. These beverages are not suitable for use as rehydration solutions but, in children with mild gastroenteritis and minimal dehydration, initiating oral hydration with dilute apple juice followed by a child’s preferred fluids, results in fewer treatment failures as compared with the use of
 electrolyte maintenance solutions. Thus, in high­income countries, the use of dilute apple juice and preferred fluids may be an appropriate alternative to electrolyte maintenance fluids in children with mild gastroenteritis and minimal dehydration.
TABLE 131­9
Composition of Standard ORS, Reduced­Osmolarity WHO ORS, and Other Commonly Consumed Beverages
Carbohydrate Sodium Potassium Chloride Base Osmolarity
(mmol/L) (mmol/L) (mmol/L) (mmol/L) (mmol/L) (mOsm/L)
WHO reduced osmolarity      245
(2002)
Pedialyte® 139     250
Enfalyte® (formerly 167     200
Ricelyte)
Apple juice 666 .4   N/A 730
Coca­Cola Classic® 622 .6 N/A N/A .4 650
Ginger ale 500 .5 .1 N/A .6 565
Gatorade® 322   N/A  350
Chicken broth  260 .5 260 N/A 450
Abbreviations: N/A = not available; ORS = oral rehydration solution; WHO = World Health Organization.
Although oral rehydration therapy should be the first­line treatment for most children with acute gastroenteritis, it is often underused by healthcare providers in industrialized countries, who too often elect to administer IV rehydration. This may be due to misperceptions about the effectiveness of IV
,26 rehydration or unfamiliarity with published guidelines. IV rehydration is appropriate and necessary in children with severe
 dehydration, hemodynamic compromise, or when altered mental status precludes safe oral administration of fluid. Children with mild to moderate dehydration are candidates for oral rehydration therapy and do not need IV rehydration as first­line therapy.
When comparing oral rehydration therapy with IV therapy, a Cochrane review concluded that there is no difference in failure to rehydrate, weight gain, or total fluid intake; oral rehydration therapy is associated with a shorter hospital stay. For every  children treated with oral rehydration therapy, one
 child would fail and require IV rehydration. A sample ED algorithm incorporating oral rehydration therapy is provided in Figure 131­1. FIGURE 131­1
Algorithm for evaluation and management of acute gastroenteritis in children >2 months of age based on clinical assessment of dehydration status. * ORT = Oral rehydration therapy. If IV access is difficult, consider nasogastric (NG) oral rehydration solution (50 mL/kg) over  hours instead. Continue oral rehydration therapy (ORT) during IV therapy. ICU = intensive care unit; ORS = oral rehydration solution; RN = registered nurse.
In children with moderate dehydration undergoing oral rehydration therapy, the fluid deficit should be corrected rapidly (over  hours). Give  to
100 mL of oral rehydration solution per kilogram of body weight, plus additional oral rehydration solution to compensate for ongoing losses (approximately  mL/kg per stool and  mL/kg per emesis). Offer small volumes initially, such as  mL every  to  minutes, and increase as tolerated. A general rule is to aim for about  ounce (30 mL) of oral rehydration solution per kilogram of body weight per hour. Do not limit breastfeeding during any phase of oral rehydration therapy, both for the nutritional support of the infant and to avoid a decrease in the mother’s milk supply. If necessary, oral rehydration solution may be provided as a supplement. When oral rehydration is not feasible, enteral rehydration by the nasogastric route provides an effective alternative to IV rehydration. This method allows for
 rehydration at a steady rate and is as successful as, and more cost effective than, IV rehydration. Children with severe dehydration requiring IV rehydration can begin oral rehydration therapy when perfusion and mental status return to normal. Caregivers should understand the technique and rationale of oral rehydration therapy and should be provided with helpful equipment such as a clock and a syringe or dropper. Recognizing caregiver expectations and addressing potential obstacles, such as misconceptions about oral rehydration therapy or exhaustion, may also contribute to a successful outcome.
IV Hydration
Parenteral therapy is discussed in Chapter 132, “Fluid and Electrolyte Therapy in Infants and Children.”
Antiemetics
Although vomiting is not a contraindication to oral rehydration therapy and does not usually preclude successful oral rehydration, the presence of ongoing vomiting may be an obstacle to initiating or continuing oral rehydration therapy. Ondansetron, a 5­hydroxytryptamine (serotonin) receptor antagonist, may be used as an adjunct to oral rehydration therapy in children with persistent vomiting at a dose of .15 milligram/kg/dose PO. The use of intravenous ondansetron and multiple dose therapy is not supported by the evidence, which
  associates both such approaches with increased side effects and no additional benefit beyond a single oral dose.
Do not use dopamine receptor antagonists (such as promethazine, prochlorperazine, metoclopramide, and droperidol) to treat
 vomiting in children because of the potential for respiratory depression and extrapyramidal reactions. In addition, they lack evidence of efficacy. The U.S. Food and Drug Administration issued an alert in 2006 indicating that promethazine (marketed as Phenergan®) should not be used in children <2 years of age because of the potential for fatal respiratory depression.
Maintenance Phase and Diet
For children with minimal or no dehydration and those who have been successfully rehydrated, the priority is to prevent dehydration by providing maintenance fluid needs and replacing losses. Fluid needs may be met with oral rehydration solution or regular diet. Children undergoing oral rehydration therapy should resume feedings with an age­appropriate, palatable, and nutritionally complete diet as soon as the initial fluid deficit has been replaced. Do not withhold feedings for >4 hours in a dehydrated child or for any length of time in a child who is not dehydrated.
,26
Early refeeding during oral rehydration therapy has clinical and nutritional benefits and is supported in major guidelines. The introduction of fullstrength formula or regular diet immediately after rehydration is associated with increased weight gain and does not limit the success of oral rehydration therapy. Most young children can continue to receive lactose­containing milk or formula. However, there does appear to be a slight reduction in the duration of diarrhea and the treatment failure rate among inpatients administered lactose­free products, and this approach
 may be considered in this patient population.

The banana, rice, applesauce, and toast diet is unnecessarily restrictive and may not provide enough nutrition, so it is no longer recommended.
Because fats are an important source of calories, low­fat diets are discouraged.
Antidiarrheal Medications
Antidiarrheal medications are not recommended either due to safety concerns or a lack of data to support effectiveness. Potential risks outweigh benefits. Loperamide, a peripheral opiate receptor agonist that can reduce diarrhea, is absolutely contraindicated in children <2 years old and for those with bloody stools or suspected bacterial gastroenteritis from Salmonella, Shigella, or
Campylobacter. The drug can cause lethargy and paralytic ileus. Additionally, loperamide may be associated with a possible increased risk of hemolytic­uremic syndrome when used in the setting of enterohemorrhagic E. coli infection. Although older children with viral gastroenteritis who take an age­appropriate dose are unlikely to experience serious events, potential risks likely outweigh benefits in most children.
Adsorbents and Antisecretory Agents
Smectite is an aluminomagnesium silicate that binds some toxins, bacteria, and viruses and is used in several European countries as an antidiarrheal agent. Although some trials and a recent meta­analysis have reported effectiveness in reducing diarrhea, the limitations of the studies prevent any firm conclusions from being drawn. Bismuth subsalicylate is an antisecretory agent that is commonly found in over­the­counter diarrhea medications.

Although bismuth has a modest effect on reducing severity of diarrhea, it can cause elevated salicylate levels in children.
Consequently, products containing bismuth subsalicylate (e.g., Pepto­bismolØ, KaopectateØ) should not exceed dosing recommendations in children less than  years of age. Racecadotril is a prodrug that must be hydrolyzed to its active metabolite (thiorphan), which then acts as an enkephalinase inhibitor that decreases intestinal secretion by preventing the breakdown of endogenous GI opioids. It is available in Europe and Southeast Asia, but not in the United States. In a systematic review including nine trials and 1384 children, twice as many patients had
 diarrhea resolution at any time point when administered racecadotril relative to placebo. Although racecadotril reduces stool frequency (stool ratio
 of racecadotril to placebo = .63), it does not decrease major clinical outcomes such as hospitalization.
Probiotics
Probiotics are living organisms that, when ingested, can modulate mucosal and systemic immunity by altering microbial balance in the intestinal tract.
Yogurt is a dietary source of probiotics, though the quantity of bacteria in yogurt is variable. Data from several meta­analyses show a moderate clinical benefit of certain probiotic strains in reducing the duration and/or volume of diarrhea in hospitalized children. While a sizable and growing number of
,49  patients are prescribed probiotics to treat intestinal infections, only five of  AGE management guidelines summarized in a recent review endorse probiotic use. Most published studies suffer from methodologic limitations, including small sample sizes, use of restricted populations,
 limited knowledge of causative pathogens, and an absence of adverse event reporting. The first pediatric ED study to date that evaluated

Lactobacillus rhamnosus GG reported no reduction in the time to normal stool or the number of diarrheal stools. Two recently completed multicenter prospective randomized trials of probiotics for acute pediatric gastroenteritis presenting to the emergency department both failed to
,54 demonstrate any benefit among more than 1500 combined study participants, suggesting no role for probiotics in this population. Lastly, there is some evidence that many probiotic product labels do not adequately identify or quantify microbes and that when tested some products do not match
 their labeled microbiologic specification.
Prebiotics, which are nondigestible food components believed to improve microbial balance in the intestinal tract, have not been extensively studied and are not recommended. There is no high­quality published evidence regarding the use of homeopathic or herbal medications for the management of gastroenteritis.
Zinc
Zinc is necessary for intestinal mucosal healing, and its deficiency has been associated with increased diarrhea severity. Malnourished children >6 months old benefit the most from zinc therapy (27­hour reduction in diarrhea duration), and its use should likely be limited to such groups of
  children. Because zinc is an effective therapy for diarrhea and reduces morbidity and mortality in the setting of low­income countries, the United
Nations Children’s Fund and the World Health Organization recommend zinc supplementation as a universal treatment for children with diarrhea in low­income countries at a dose of  milligrams/d of any zinc salt orally for  to  days (10 milligrams/d for infants <6 months old).
Antibiotics for Acute Gastroenteritis
Because the cause of gastroenteritis is rarely known upon presentation, treatment decisions must be made before the identification of a pathogen is possible. Because the vast majority of episodes of pediatric gastroenteritis are of viral origin, do not routinely give antibiotics. In select clinical circumstances, antibiotics may be indicated; see recommendations for specific pathogens and clinical settings in Table 131­7. In most instances, however, antibiotics should only be provided to extremely unwell (e.g., septic or bacteremic), extremely young, or immunocompromised children.
When required, the choice of antimicrobial agent depends on local prevalence and resistance patterns. Parenteral rather than oral antibiotic therapy is appropriate for patients unable to take oral medications, patients with toxic appearance or underlying immunodeficiency, and febrile infants <3 months of age. Children with watery diarrhea generally should not receive empiric antibiotics unless they have been exposed to cholera.
Antibiotics are effective in reducing the symptoms and infectivity of Shigella gastroenteritis. Because of increasing resistance, use ampicillin or trimethoprim­sulfamethoxazole only if the strain is susceptible. Otherwise, azithromycin is an appropriate first­line agent. Ceftriaxone is the treatment of choice for parenteral therapy.
Do not use antibiotics to treat Salmonella gastroenteritis unless specific risk factors are present. A Cochrane review (12 trials, 767 patients)
 demonstrated no evidence of benefit from antibiotic therapy in otherwise healthy individuals with nontyphoidal Salmonella gastroenteritis.
Although the number of young children studied was small, adverse events were more common in participants who received antibiotic treatment. Thus, antibiotics should only be administered to high­risk children to reduce the risk of Salmonella bacteremia and extraintestinal infections. High­risk children include those with underlying immune deficiencies, sickle cell disease, immunosuppressive therapy, or inflammatory bowel disease and infants <3 months old.
Antibiotic therapy for Campylobacter gastroenteritis has a modest effect on symptoms and is most effective if treatment is started within  days of
 disease onset. Antibiotics reduce the duration of fecal excretion of organisms and are recommended to reduce transmission in day care centers and institutions.
Antibiotics for Shiga toxin–producing E. coli do not significantly affect the clinical course. Importantly, in children with Shiga toxin–producing E. coli
 infection, there is a significant association between antibiotic use and the risk of developing the hemolytic­uremic syndrome. Therefore, children with E. coli O157:H7 should not receive antibiotics. Intravenous volume expansion is an underused intervention that may decrease the frequency of oligoanuric renal failure in children with diarrhea­associated hemolytic­uremic syndrome (hematocrit <30% with evidence of
   intravascular erythrocyte destruction), thrombocytopenia (platelet count <150 ×  /mm ), and impaired renal function. Antibiotics may be useful for severe forms of enteroinvasive, enteropathogenic, or enterotoxigenic E. coli infection.Azithromycin and trimethoprimsulfamethoxazole are treatment options.
Antibiotics reduce the severity of V. cholerae diarrhea. Treatment options include doxycycline, azithromycin, or trimethoprim­sulfamethoxazole.
Antimicrobial treatment of Yersinia species is appropriate if severe disease, bacteremia, or extraintestinal infection is suspected. Options include trimethoprim­sulfamethoxazole, aminoglycosides, cefotaxime, fluoroquinolones, tetracycline, doxycycline, and chloramphenicol.
DISPOSITION AND FOLLOW­UP
There are no established evidence­based criteria for admission of patients with gastroenteritis. In general, well­appearing children with minimal or no dehydration who are able to receive oral rehydration therapy at home should be discharged, and caregivers should be taught how to administer oral rehydration therapy and recognize signs of dehydration. Discharge instructions should be verbal and written. Sample discharge instructions are presented in Table 131­10. Ideally, caregivers will have had the opportunity to practice oral rehydration therapy and ask questions while in the ED.
Children with moderate or severe dehydration, intractable or bilious vomiting, a suspected surgical condition, or significant laboratory or neurologic abnormalities, including lethargy or seizures, require further testing and should be observed in the ED or admitted. Patients not likely to succeed with home oral rehydration therapy, such as those with large ongoing losses or inadequate support, should also be observed or admitted. Many patients
 with dehydration who require ongoing treatment can be successfully managed in an observation unit. Young infants are at risk for more rapid and severe dehydration, so the threshold for admission should be low, and follow­up in  hours should be ensured if discharge is considered. Families who are discharged should be instructed to return to seek further care if their child becomes unable to receive oral rehydration therapy, has persistent or bilious emesis, or shows increasing evidence of dehydration, or if symptoms are worsening.
TABLE 131­10
Sample Gastroenteritis Discharge Instructions
Your child has been diagnosed with gastroenteritis. Gastroenteritis is an illness that consists of vomiting and diarrhea. It is often caused by viruses and usually can be treated without medications. Preventing dehydration is the most important goal in caring for children with gastroenteritis.
How will I know if my child is becoming dehydrated?
Dry lips and mouth.
Decreased activity level.
Sunken eyes.
Sunken fontanelle (soft spot) in babies <1 y.
Not urinating as often as usual or dark urine.
Reduced tears when crying.
What should I give my child to eat and drink?
Children who do not have signs of dehydration can drink what is usual for them. You do not need to stop giving milk. Drinks with a lot of sugar, such as fruit juices, can make diarrhea worse.
Your child should return to his or her normal diet as soon as possible. A special diet is not necessary. Good nutrition is important, even if there is still vomiting or diarrhea.
If you are breastfeeding, continue breastfeeding. Babies taking formula can continue to receive their usual formula.
Children who are showing some signs of dehydration should receive oral rehydration solutions (see below).
What types of fluids are acceptable for oral rehydration?
Over­the­counter rehydration solutions are ideal for rehydration. Some brands include Pedialyte and Enfalyte. Generic solutions are also available.
Flavored solutions are usually preferred by children.
Sports drinks are not the same as oral rehydration solutions and should not be used in infants or children who are dehydrated. They may be acceptable in older children with minimal dehydration.
Plain water and tea do not have sugar or salt and can cause electrolyte changes, especially if given to small babies.
Soda/pop and juices have too much sugar and not enough salt to be used for oral rehydration.
Children who are not dehydrated do not need a special oral rehydration solution.
How do I give oral rehydration?
If your child is vomiting, start with small amounts of oral rehydration fluid, such as one teaspoon (5 mL) every  min. Increase the amount gradually, as tolerated.
If your child is breastfed, continue breastfeeding. Oral rehydration solutions can supplement breast milk after or between breast feedings, but should never take the place of breast milk.
When should I call my child’s doctor or seek help?
Call your doctor immediately or go to the nearest emergency department if:
Your child seems dehydrated and is not able to drink.
Your child’s vomit is green or bloody.
Your child has severe abdominal pain.
Your child appears to be very sick.
Your child has blood in the diarrhea.
Your child has a fever and is <3 mo of age.
When should I follow up with my child’s doctor?
If your child is <6 mo of age, follow up within 24–48 h.
If your child is >6 mo of age, call your doctor’s office and schedule a follow­up if symptoms continue.
SPECIAL SITUATIONS
DIARRHEA WITH OR WITHOUT VOMITING
Adverse Food Reactions
Adverse food reactions can be due to either an adverse immunologic response, otherwise known as an allergy, or an adverse physiologic response,
 often referred to as food intolerance. The National Institute of Allergy and Infectious Diseases recognizes four categories of immune­mediated
 adverse food reactions: immunoglobin E (IgE)­mediated, non–IgE­mediated, mixed, and cell­mediated. IgE­mediated GI allergic symptoms may consist of nausea, abdominal pain, cramping, vomiting, or diarrhea developing within minutes to  hours of the ingestion of a food allergen. GI symptoms are often accompanied by symptoms involving the mouth or skin and may also include respiratory and systemic manifestations.
Eosinophilic esophagitis and gastroenteritis are examples of a mixed IgE and non­IgE food allergy, with T­cell–mediated responses playing a significant
 role in pathogenesis. Patients may present at any age, and many will have other allergic or atopic conditions. The portion of the GI tract involved determines symptoms. Because symptoms tend to be delayed, identifying the offending food(s) may be challenging. Infants often present with feeding difficulties, gastroesophageal reflux, vomiting, and failure to thrive. Older children may present with vomiting, abdominal pain, or symptoms similar to irritable bowel syndrome. A history of dysphagia or food impactions suggests eosinophilic esophagitis.
Non–IgE­mediated food allergies are primarily T­cell–mediated and tend to result in delayed symptoms. Examples include food protein–induced
 enterocolitis syndrome, food protein–induced allergic proctocolitis, and celiac disease. Food protein–induced enterocolitis syndrome is a potentially severe condition with a peak incidence in infants between  and  months old. Proteins in cow’s milk or soy formulas are the most common triggers in infants, and symptoms consist of profuse vomiting and diarrhea for several hours after exposure, at times resulting in shock. Many other foods have been implicated in food protein–induced enterocolitis syndrome, and children regularly exposed to the allergenic food may develop chronic vomiting, diarrhea, anemia, or failure to thrive. Food protein–induced allergic proctocolitis most often presents in breastfed infants in the first  months of life.
Infants generally appear healthy but have stools characterized by the presence of blood and mucus. Cow’s milk in the maternal diet is the most common trigger, and symptoms begin to improve within a few days of dietary modification. The condition generally resolves between the ages of  months and  years. Diagnostic tests used for IgE allergies such as skin prick testing are not useful in identifying the offending agents in non–IgE­ mediated food allergies; therefore, the diagnosis is based on clinical suspicion. Dietary avoidance is the mainstay of management.
Celiac disease is a T­cell–mediated inflammatory response triggered by the ingestion of gluten in genetically predisposed individuals. GI presentations are common in children and include chronic or intermittent diarrhea, abdominal pain, abdominal distention, and failure to thrive.
Whereas young children most often have a “typical” presentation, extraintestinal symptoms such as fatigue, osteopenia, iron deficiency anemia, and
 short stature become more common as age increases. Treatment consists of lifelong adherence to a gluten­free diet.
Antibiotic­Associated Diarrhea
Antibiotic­associated diarrhea is otherwise unexplained diarrhea that occurs in association with the administration of antibiotics. The frequency of this complication varies, with diarrhea occurring in 5% to 10% of children treated with ampicillin, 10% to 25% treated with amoxicillin­clavulanate, and
15% to 20% treated with cefixime. The spectrum of findings in antibiotic­associated diarrhea ranges from mild diarrhea to severe colitis that may include abdominal cramping, fever, leukocytosis, fecal leukocytes, hypoalbuminemia, and colonic thickening with characteristic changes visible on endoscopy and biopsy. Although infection with Clostridium difficile accounts for only 10% to 20% of the cases of antibiotic­associated diarrhea, it accounts for most cases of colitis associated with antibiotic therapy. Nonclostridial antibiotic­associated diarrhea may be caused by other enteric pathogens, by the direct effects of antimicrobial agents on the intestinal mucosa, or by the metabolic consequences of reduced concentrations of fecal flora. Clindamycin, cephalosporins, and penicillins are the antibiotics most frequently implicated in C. difficile diarrhea.
C. difficile disease can only be firmly diagnosed once its toxin is identified. However, because children can be asymptomatic hosts of toxin­producing strains, testing for C. difficile should only be performed when there is ample clinical suspicion and/or risk factors identified. When identified in the stool of children <2 years of age (even if diarrheal), it most commonly is not the cause of diarrhea and usually does not require treatment. The following two­step testing strategy has been proposed: screening should be performed through the conduct of an enzyme immunoassay for glutamate
,66 dehydrogenase, which is present in almost all strains of C. difficile, including those that do not produce toxin. If positive, this should be followed by a confirmatory enzyme immunoassay test for toxins A and B or, preferably, by a cell cytotoxin assay that demonstrates cytotoxicity of stool for human fibroblast cells. Polymerase chain reaction testing is a rapid, sensitive, and specific test that appears promising. However, significant variations exist in
,68 testing methodologies and kits, and thus further evaluation of its utility is warranted before widespread adoption. Indications for treatment include positive assays for C. difficile toxin, plus one of the following: evidence of colitis, moderate to severe diarrhea, persistent diarrhea despite the discontinuation of the implicated agent, or the need to continue treating the original infection. Oral metronidazole is the treatment of choice in most cases of pediatric C. difficile colitis. In the most severe cases, vancomycin (oral or rectal) may be used in conjunction with IV metronidazole. The anticipated response to treatment is resolution of fever within  day and resolution of diarrhea in  to  days. Treatment does not eradicate C. difficile, and asymptomatic patients should not be retested or treated based on a positive stool test. Metronidazole is preferred because it is less expensive than vancomycin and avoids the potential risk of promoting vancomycin­resistant enterococci.
Secondary Lactase Deficiency
Secondary lactase deficiency implies that a pathophysiologic condition has resulted in an acquired lactase deficiency and lactose malabsorption. The most common etiology is acute GI infection resulting in small intestinal injury with loss of lactase­containing epithelial cells at the tips of the villi. The immature epithelial cells that replace these are often lactase deficient, leading to secondary lactase deficiency and lactose malabsorption. Despite this, children with infectious diarrheal illnesses who have no or only mild dehydration can continue consuming human milk or standard formula without a significant effect on clinical course. Secondary lactase deficiency with clinical signs of lactose intolerance can be seen in celiac disease, Crohn’s disease, and immune­related and other enteropathies, and should be considered as a possible etiology for diarrhea in children with these conditions.
Diagnostic evaluation should be performed when secondary lactase deficiency is suspected and infection is not the cause.
Parasitic Infection
Parasites are uncommon causes of diarrhea but may be the source of waterborne outbreaks and are more severe in immunocompromised children.
Cryptosporidium and Giardia are the parasites most likely to cause diarrhea. Nitazoxanide is the drug of choice for Cryptosporidium infections, and either metronidazole, tinidazole, or nitazoxanide may be used in the treatment of Giardia infections. For further discussion of parasitic diseases, see
Chapter 160, “Food and Waterborne Illnesses,” and Chapter 162, “Global Travelers.”
TRAVELER’S DIARRHEA
Limited data suggest that diarrhea is common in children traveling to high­risk regions. Although many cases of traveler’s diarrhea are self­limited, antibiotic therapy is appropriate for children with a history of travel to a high­risk region who have severe or prolonged symptoms (>5 days).
Macrolides such as azithromycin are the first­line antibiotic therapy, and trimethoprim­sulfamethoxazole may also be considered.


