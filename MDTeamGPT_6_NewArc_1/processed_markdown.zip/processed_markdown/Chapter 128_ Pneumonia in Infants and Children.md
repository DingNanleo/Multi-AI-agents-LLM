## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 128: Pneumonia in Infants and Children
Kevin M. Overmann; Todd A. Florin
Content Update: Duration of Treatment for Outpatient Pneumonia July 2021
As few as 3­5 days of antibiotics appear to be sufficient. See discussion under "Controversies in Treatment," below.
INTRODUCTION AND EPIDEMIOLOGY
Pneumonia is an infection of the lung and lower respiratory tract. Globally, pneumonia is the leading cause of death in children less than  years of age,
 with an estimated 120 million cases annually resulting in nearly .3 million deaths. The greatest burden of disease and mortality occurs in the developing world, and young children under the age of  account for 81% of pediatric deaths from pneumonia. The burden of disease in the developed
,3 world remains high, with an estimated  to .6 million cases annually, resulting in nearly a million hospitalizations and significant economic impact.

In the United States, it is the second costliest and fifth most common reason for hospitalization in children. This chapter addresses the clinical and radiographic diagnosis of pneumonia, common viral and bacterial causes, evidence­based treatments, and appropriate disposition and follow­up for children seen in the ED. Special mention of unusual microbes, changing patterns of immunization and resistance, and special considerations for children with underlying medical conditions will be highlighted. Clinicians with limited pediatric experience may find the section on the use and interpretation of chest radiographs in children helpful.
PATHOPHYSIOLOGY

Pneumonia results from the invasion and overgrowth of pathogens in the lower respiratory tract. Anatomic and mechanical barriers to infection include the nasal hairs and turbinates, cilia, epiglottis, and cough reflex. Humoral immunity is largely mediated by secretory immunoglobulin A.
Cellular immunity and phagocytic cells (e.g., alveolar macrophages) further protect against infection. Infectious agents may be inhaled or aspirated directly into the lungs, invade respiratory epithelium and spread contiguously, or, less commonly, reach the lungs hematogenously. Viral inoculation is typically by droplet or fomite (e.g., influenza, respiratory syncytial virus), whereas bacterial pneumonia often follows colonization of the nasopharynx.
Infection can result in injury or death of the respiratory epithelium, interstitial inflammation, or alveolar injury. The air space fills with exudative debris, causing atelectasis, impaired oxygenation, and ventilation­perfusion mismatch.
In most cases, the causative agent is never identified. Rapid viral detection via nasopharyngeal or oropharyngeal sampling may identify
 pathogens, but identification of true bacterial superinfection remains difficult. Definitive microbiologic diagnosis requires invasive procedures such as bronchoalveolar lavage, lung puncture, or sampling of pleural effusion for culture or polymerase chain reaction, which are typically unavailable or impractical in the ED.

Viruses are the most commonly detected cause of pneumonia in children, accounting for over 70% of hospitalized cases in the United States.
Bacterial, atypical, fungal, parasitic, and opportunistic organisms can also cause disease. Infection with Mycobacterium tuberculosis can occur in areas where it is endemic and among children with immunodeficiency. Local and regional epidemiology, individual immunization status, and underlying health problems may influence which pathogens cause pneumonia. Causes of pneumonia vary with age. Patterns of disease can also help guide
,9 clinical decisions, as described below.
CLINICAL FEATURES AND ETIOLOGY

TChhea pcaterdr i1n2a8l :s Pymneputommosn ioaf ilno wInefar nretss painradt oCrhyi ltdrraecnt ,i nKfeevcitnio Mn .i nOcvluedrme caonung; hT,o fdedve Ar,. tFalcohriynpnea, and respiratory distress. However, signs and syPmapgteo 1m /s 
. Terms of Use * Privacy Policy * Notice * Accessibility vary by age and specific causative agents.
AGE­SPECIFIC CAUSES OF PNEUMONIA
Neonates  to  Days of Age
Neonates require special consideration because they are at risk for acquired perinatal bacterial pathogens. Specific organisms include group B streptococci, gram­negative enteric bacteria such as Klebsiella and Escherichia coli, and Listeria monocytogenes. Late­onset neonatal pneumonia may be caused by Staphylococcus aureus, Streptococcus pneumoniae, or Streptococcus pyogenes. Pneumonia due to maternal genital Chlamydia trachomatis has been largely eliminated in developed countries through the systematic screening and treatment of pregnant women but is still a
 consideration if the mother has had little or no prenatal care. Any neonate with pneumonia is also at risk of sepsis, and between birth and  months, infants with pneumonia should be evaluated for sepsis.
Infants and Children Between  Days and  Years of Age

Pneumonia in older infants and toddlers is usually viral rather than bacterial. Common viruses include respiratory syncytial virus, human rhinovirus,
 influenza, parainfluenza, human metapneumovirus, and adenovirus. In this age group, the most common bacterial cause of community­acquired pneumonia remains S. pneumoniae. Other agents include Haemophilus influenzae type b in nonimmunized children and nontypeable H. influenzae in all children. Less common but important pathogens include S. aureus, group A Streptococcus, and Bordetella pertussis.
Children  to  Years of Age
As children get older and attend day care or school, they come into contact with many pathogens, particularly respiratory viruses. In children between
 and  years of age, most community­acquired pneumonia is caused by respiratory viruses, notably respiratory syncytial virus, human rhinovirus, and human metapneumovirus. Other notable pathogens in this age group include S. pneumoniae, H. influenzae type b, and nontypeable H. influenzae.
,12
Mycoplasma pneumoniae and Chlamydophila pneumoniae are thought to be less common in children <5 years old. Pneumonias due to varicellazoster virus, measles, H. influenzae type b, B. pertussis, and some strains of pneumococcus are increasingly rare in areas of widespread vaccination and herd immunity.
Children  to  Years of Age
While viruses continue to predominate in children older than , M. pneumoniae is a more commonly detected cause of community­acquired
 ,14 pneumonia, accounting for 17% of cases. C. pneumoniae and S. pneumoniae remain important considerations. Less common bacterial causes
 include S. aureus, Streptococcus species (including group A Streptococcus), nontypeable H. influenzae, and Legionella. M. tuberculosis is a rare but important agent to consider. Pertussis immunity from the acellular vaccine wanes over time, so consider Bordetella even in the immunized child if
 clinical symptoms are strongly suggestive. The proportion of pneumonia cases with any detected pathogen increases with age, from less than 10%
 in young children to about 35% in adolescents. Advancements in pathogen detection methods may refine our understanding of patterns of infections across age groups.
Adolescents
By adolescence, most patients are assumed to have the same infectious risks as healthy adults. The prevalence of specific pathogens may vary according to region, season, and cyclical epidemics in the population. In North America, the role of atypical agents, especially M. pneumoniae and C.
pneumoniae, is estimated to be significant, but data and guidelines from other parts of the industrialized world (e.g., Europe) suggest regional
 differences.
UNIQUE AND HIGH­RISK GROUPS
Tuberculosis remains a consideration for children with known exposures and those from endemic areas such as Native reserves, Alaska, northern
Canada, and some inner­city settings. Consider tuberculosis in immigrants from high­prevalence areas of the world, including Africa, Asia, Venezuela, and parts of Eastern Europe.
Children with underlying chronic disease are at risk for specific infections. For example, younger children with cystic fibrosis are often infected with S.
aureus in the first years of life, and later with Pseudomonas. Children with sickle cell disease are particularly susceptible to infection with encapsulated bacteria (e.g., pneumococcus, Salmonella, Klebsiella), which can cause acute chest syndrome and sepsis. Children with congenital or acquired immune deficiencies such as human immunodeficiency virus infection, malignancy, and congenital immunodeficiencies are at risk for opportunistic infections
 with agents such as Pneumocystis jirovecii, cytomegalovirus, and fungi.
Unvaccinated children and those with incomplete immunization are at risk of serious morbidity and mortality from a variety of vaccine­preventable pathogens.
PATHOGEN­SPECIFIC PATTERNS OF DISEASE
In general, it is not possible to pinpoint specific causative organisms by clinical findings alone. “Typical pneumonias” classically present with high fever, chills, pleuritic chest pain, and productive cough. “Atypical pneumonias” are characterized by gradual onset over days to weeks, low­grade fever, nonproductive cough, and malaise, and suggest infection with mycoplasma or C. pneumoniae. Viral pneumonias may present with similar
,14  symptoms. Wheezing in children with an acute respiratory infection may suggest bronchiolitis, viral pneumonia, or Mycoplasma pneumonia.
Despite these limitations, some patterns of disease do suggest certain etiologies (Table 128­1). Staphylococcal pneumonia, which may follow influenza, is notorious for rapidly progressing symptoms, high fever, toxicity, and presence of pulmonary abscesses. C. trachomatis infection in infants (which is rare where there is prenatal screening and treatment) often presents with a staccato cough, diffuse rales, and lack of fever, so­called afebrile pneumonitis. Scattered rales, rare wheezes, and bilateral interstitial infiltrates are all possible findings. Older children may complain of sore
 throat and dysphagia. B. pertussis and respiratory viruses are also implicated as possible causes. Mycoplasma infection typically produces a
 hacking, dry cough and may be associated with extrapulmonary manifestations including arthralgias, rash, and even CNS symptoms. An upper respiratory tract prodrome followed by paroxysmal cough, gasping respirations, and color change is characteristic of B. pertussis infection
(whooping cough); the postinfection cough may persist for months.
TABLE 128­1
Patterns of Disease by Specific Pathogen
Infective
Disease Characteristics Comments
Agent
Staphylococcus Rapid onset, high fever, toxicity, pulmonary Infection with influenza may predispose to secondary Staphylococcus pneumonia aureus abscesses
Chlamydia Staccato cough, diffuse rales, “afebrile Primarily seen in neonates and young infants but rare with prenatal maternal trachomatis pneumonitis,” possible wheeze; bilateral screening and treatment infiltrates
Mycoplasma Hacking dry cough, headache, sore throat; may Extrapulmonary symptoms: arthralgias, rash, CNS involvement pneumoniae cause wheezing in school­age children
Bordetella Upper respiratory prodrome followed by Cough may persist for months pertussis paroxysmal cough, gasping, stridor, color change
Mycobacterium Prolonged cough and/or fever, extrapulmonary Consider in children from endemic areas and those with known exposure; classic tuberculosis spread symptoms seen in adults (e.g., hemoptysis) may be absent in children
Respiratory Upper respiratory symptoms, cough, wheezing, Clinical diagnosis of classic symptoms in child <2 years old; seasonal epidemics syncytial virus rales, rhonchi
Consider tuberculosis with prolonged cough in the setting of identified risk factors and characteristic radiographic findings. Note that classic signs of tuberculosis may be absent in children, especially those with immune deficiencies. Tuberculosis in infants and young children tends to progress more
19­21 rapidly from infection to clinical disease.
SEVERE DISEASE

Criteria for severity of illness in pneumonia are not well defined and severity scoring systems have not been validated in children. Guidelines include high fever, hypoxemia, and signs of respiratory distress as potential markers of severity. Young age, vital sign abnormalities, chest retractions, and
 multilobar radiographic infiltrates have been associated with more severe disease in hospitalized children with pneumonia. Clinicians should
,24 determine severity in the context of physical exam findings and laboratory and imaging studies.
DIFFERENTIAL DIAGNOSIS
The differential diagnosis of pneumonia includes both infectious and noninfectious conditions, as well as extrapulmonary disorders that may mimic or complicate lower respiratory tract infection (Table 128­2). Formulating a differential diagnosis is especially important for infants and very young children, who may have undiagnosed congenital anomalies.
TABLE 128­2
Differential Diagnosis of Pneumonia
Infectious Causes Noninfectious Causes Extrapulmonary Causes
Upper respiratory tract Foreign body aspiration Sepsis infection (“cold”), otitis media
Bronchiolitis Inhalation pneumonitis (e.g., hydrocarbon inhalation, chronic gastroesophageal Cardiac anomalies (cyanotic heart reflux disease) disease, congestive heart failure, myocarditis)
Croup Intoxication (e.g., salicylate poisoning, carbon monoxide exposure) Endocrinopathies (e.g., diabetic ketoacidosis)
Congenital disorders (e.g., cystic fibrosis, sickle cell disease with chest crisis) Neuromuscular disorders
Anatomic abnormalities (e.g., congenital lobar emphysema, pulmonary Inborn errors of metabolism sequestration, tracheoesophageal fistula, congenital cystic adenomatous malformation)
Neoplasm, metastasis GI emergencies (e.g., appendicitis with grunting)
Pulmonary embolism
Congenital heart disease may present with cyanosis, quiet tachypnea, or respiratory distress related to congestive heart failure (see Chapter 129,
“Congenital and Acquired Pediatric Heart Disease”). Kussmaul breathing suggests diabetic ketoacidosis or other metabolic disease. Toddlers are particularly at risk for foreign body aspiration and ingestion of toxins. Adolescents may intentionally or unintentionally take drug overdoses that speed or slow breathing.
DIAGNOSIS
HISTORY
Relevant history depends on the age and underlying health of the child. Many complaints are nonspecific (e.g., cough and fever) and are common to both upper and lower respiratory tract disease. The predictive value of specific signs and symptoms is discussed below (see “Physical Examination” section).
The presence, timing, and duration of cough, fever, rapid breathing, and difficult breathing may provide diagnostic information. Specific toxic exposures, sick contacts, travel, and pets may be relevant to the diagnosis.
Persistent or recurrent lower respiratory tract symptoms or history of choking suggest foreign body aspiration. Recurrent pneumonias may signify underlying disease such as cystic fibrosis, immune disorders, or anatomic abnormalities.
In young children, lower lobe pneumonia or effusion can cause abdominal pain and may mimic appendicitis.
Fever is a common but nonspecific sign of both upper and lower respiratory tract infections.
Birth History
The mother’s perinatal health is of particular importance, as neonates are at risk for perinatally acquired infections. Obtain relevant information on maternal infections (e.g., chlamydia, gonorrhea, group B streptococci, genital herpes, and human immunodeficiency virus status), intrapartum or postpartum fever, and any specific antibiotic or antiviral therapy received during labor and delivery. Other perinatal risk factors include prolonged rupture of membranes, prematurity, and immediate peripartum complications. Meconium aspiration may cause chemical or bacterial pneumonia in the first  to  hours of life. Neonatal stays in hospital suggest an underlying health problem and also increase the risk of nosocomial infection.
Medical History
Chronic respiratory illnesses (e.g., asthma), recurrent pneumonia, prior complicated pneumonia, or a complex medical history (e.g., cerebral palsy, developmental delay) may place the child at risk for severe disease or treatment failure. Children with congenital respiratory problems (e.g., cystic fibrosis, neuromuscular disorders, immune compromise, recurrent aspiration) are at increased risk of infection with common and rare agents, respiratory failure, and treatment failure.
Social History
A brief, focused social history may influence diagnosis, treatment, and disposition. Exposure to tuberculosis, human immunodeficiency virus–related opportunistic infections, and pathogens during travel may alter the likely etiology of disease. Adequate outpatient management of pneumonia requires that caregivers understand instructions, can afford medication, and have access to required follow­up care (see “Disposition and Follow­Up” section below).
Immunization History
Childhood immunizations can provide protection from common pathogens implicated in pneumonia (e.g., S. pneumoniae, B. pertussis, N.
meningitidis, H. influenzae type b, and measles). Table 106­3 (“Emergency Care of Children”) provides a typical childhood immunization schedule. An unvaccinated child is at risk of serious morbidity, and even death, from vaccine­preventable illness.
Annual immunization against influenza is recommended for children ≥6 months of age and for those at high risk due to underlying health conditions.
Influenza vaccine must be given annually to account for seasonal antigenic changes (see “Special Considerations” section below). Priority is given to children with asthma, cystic fibrosis, and other pulmonary diseases; those with significant cardiac, renal, and immune disorders; and those with
 diabetes. Caregivers and healthcare providers should also be immunized to avoid transmission to these at­risk children.
Immunization against varicella (chickenpox) should protect against the secondary pneumonias associated with this virus, although use of the vaccine is not yet universal. Similarly, the administration of the bacillus Calmette­Guérin vaccine to provide partial protection against certain forms of tuberculosis varies by state, province, and country.
The introduction of a seven­strain pneumococcal polysaccharide­protein conjugate vaccine (PCV7) in 2000 to 2001 led to dramatic decreases in invasive disease, but an increase in the severity of pneumococcal pneumonia attributed to nonincluded serotypes. The inclusion of additional serotypes in subsequent vaccines (PCV10 and PCV13) in 2010 to 2011 led to a decline in the incidence and severity of pneumococcal pneumonia
,27 worldwide. Continued surveillance may detect further emerging serotypes beyond those included in PCV13. Children with human
,29 immunodeficiency virus infection have shown a robust serologic response to most pneumococcal subtypes included in PCV13. The Centers for
Disease Control and Prevention recommends PCV13 administration to all children under  years of age and to older children with high­risk
 conditions.
The older 23­valent polysaccharide vaccine (Pneumovax®) is effective in children ≥2 years of age, and it should be confirmed that the vaccine has been given to children with sickle cell disease, those who have undergone splenectomy, and others at high risk for pneumococcal disease. A booster may be required.
PHYSICAL EXAMINATION
In the developing world where imaging equipment and laboratory tests are limited, the World Health Organization’s classification scheme identifies children with cough and difficult breathing but no other signs as having an upper respiratory infection. Children with associated tachypnea or chest indrawing are considered to have pneumonia to be treated at home with oral antibiotics. Children who also display general danger signs such as
 dehydration or lethargy are classified as severe pneumonia and treated with parenteral antibiotics. Although physicians in industrialized nations have many tools at their disposal, the diagnosis of pneumonia can still be made clinically.

Rapid respiratory rate is a simple screening tool for pneumonia and may be considered in conjunction with the clinical context (Table 128­3).

However, pneumonia has been identified in almost 7% of children without tachypnea or auscultatory exam findings.
TABLE 128­3
Tachypnea as an Indicator for Pneumonia* Age Tachypnea Comments
<60 d old >60 breaths/min >70 breaths/min indicates severe disease
2–12 mo old >50 breaths/min
>1–5 y old >40 breaths/min >50 breaths/min indicates severe disease
>5 y old >20 breaths/min22 >50 breaths/min indicates severe disease
*Determine rate before examination and when child is calm or sleeping; count respiratory rate for a full minute; fever may increase the rate by up to  breaths/min for every 1°C (1.8°F) rise in patient temperature.
Children at very high altitudes may have a resting respiratory rate higher than children at sea level do, so oxygen saturation may be a more useful measure. Severely malnourished or dehydrated children, or those with impending respiratory failure, may not be capable of generating rapid respiratory rates.
Markers of respiratory distress include nasal flaring, tracheal tugging, and intercostal indrawing. Lower chest or “abdominal” indrawing or retractions
 and grunting may suggest more severe pneumonia. In infants, intermittent apnea, grunting, and an inability to feed are surrogate markers of dyspnea. Cough is less common in neonates or very young children, and productive cough is rarely seen before late childhood.
Hypoxia in pneumonia typically is defined as oxygen saturation less than 90% to 92% on room air. In developing countries, hypoxia is associated with
,33 risk of oral amoxicillin treatment failure in severe pneumonia and is a strong independent predictor of radiographic pneumonia.
The chest should be auscultated while fully exposed, assessing all lung zones. Localized fine crackles (rales), coarse breath sounds (rhonchi), or
 diminished breath sounds suggest pneumonia, but sound recognition may not be consistent across observers. Among clinical exam findings relating
 to pneumonia, acceptable interrater reliability has been shown only in wheezing, respiratory rate, and retractions. A toxic appearance and overall
 impression of illness as judged by the clinician show better diagnostic sensitivity than focal auscultatory findings.
CLINICAL DIAGNOSIS
No single physical finding in isolation is diagnostic of pneumonia, and constellations of signs are more useful. For example, the combination of fever plus either tachypnea, decreased breath sounds, or fine crackles predicts radiographic pneumonia with a sensitivity of 93% to 96%. Some studies have shown that the presence of fever plus all three of the other variables raises sensitivity to 98%, while others have shown that hypoxia and increased
 work of breathing have been shown to be more important for diagnosis than tachypnea or auscultatory findings.
Presumptive diagnosis of the causative organism and empiric treatment are made by considering historical and social factors (see above), immunization status (see above), and age of the child. See Table 128­4 for the most common causes of pneumonia by age as well as their treatment. Use care when assessing children with incomplete or no immunizations. Such children may be partially or fully susceptible to pneumonia associated with B. pertussis, H. influenzae type b, and all strains of pneumococcus, as well as measles, influenza, and varicella­zoster viruses.
TABLE 128­4
Bacterial Organisms and Empiric Treatment for Pneumonia in Otherwise Healthy Children
Age Bacterial
Outpatient Treatment Inpatient Treatment
Group Pathogens
Neonates Group B Initial outpatient management not recommended Ampicillin + Gentamicin or cefotaxime
Streptococcus
Gram­negative bacilli
Listeria monocytogenes
1–3 mo Streptococcus Strongly consider inpatient management First­line therapy: pneumoniae Ampicillin or penicillin Gƒ
Chlamydia
If not fully immunized or if significant local pneumococcal trachomatis penicillin resistance:
Haemophilus
Ceftriaxone influenzae
Alternative: cefotaxime, levofloxacin
Bordetella pertussis
If suspected methicillin­resistant S. aureusADD:
Staphylococcus vancomycin or clindamycin* aureus
If presumed atypicalADD:
Azithromycin†
 mo–5 S. pneumoniae First­line therapy: 3­5 days of treatment y‡ H. influenzae type b# Amoxicillin (90 milligrams/kg/d divided in  doses) ±
Nontypeable H. clavulanateƒ influenzae If presumed atypical:
S. aureus Azithromycin (10 milligrams/kg on day , then  milligrams/kg/d)
5–18 y Mycoplasma Alternative: clarithromycin, erythromycin, or pneumoniae doxycycline (if patient >7 y)
S. pneumoniae
Chlamydophila pneumoniae
H. influenzae type b#
S. aureus
*For suspected S. aureus: cefazolin if methicillin sensitive; vancomycin or clindamycin when methicillin­resistant S. aureus is suspected.
†Macrolide should be used for suspected atypical infections (e.g., M. pneumoniae, C. trachomatis, C. pneumoniae, B. pertussis), and options include clarithromycin, erythromycin, or azithromycin. Levofloxacin if children have reached growth maturity.
‡
The majority of pneumonias in preschool­age children are viral, not bacterial, and do not require antibiotics in children well enough to be cared for in the outpatient setting.
#Consider if not fully vaccinated.
ƒFor penicillin allergy, consider individualized treatment: trial of amoxicillin under supervision, trial oral cephalosporin with activity against S. pneumoniae
(cefpodoxime, cefprozil, cefuroxime) under supervision, or treatment with linezolid, clindamycin, or macrolide (if susceptible).
LABORATORY EVALUATION
Because the results of most laboratory investigations are not known in the ED, tests are usually initiated to guide future treatment, except for rapid bedside tests for specific respiratory viruses. Nasopharyngeal assays for respiratory syncytial virus, influenza, and human metapneumovirus may be valuable, because they are quick and specific, and results may negate the need for imaging, invasive testing, and antibiotic therapy. Clinicians must remain vigilant and consider this testing within context, as a significant proportion of children with pneumonia demonstrate bacterial coinfection with
 positive viral swabs. Imaging and antibiotic treatment for nontoxic children with clinical bronchiolitis or influenza may be deferred, especially those
,24 with a positive nasopharyngeal swab finding.
Bacterial cultures of nasopharyngeal samples are generally not helpful, because results are delayed, and oral and nasal flora correspond poorly with the organisms causing disease in the lung. Up to 20% of asymptomatic children under  years of age are colonized
 with S. pneumoniae, which makes differentiating infection from colonization with a positive culture challenging. The majority of newer serologic and polymerase chain reaction techniques to detect organisms such as M. pneumoniae, H. influenzae, or C. pneumoniae have not been validated in
,10,24 children and have produced variable results.
The routine collection of blood cultures is not recommended in healthy children with mild community­acquired pneumonia
 because rates of bacteremia are low. For toxic­appearing children, those with severe disease requiring hospitalization, and those with complicated pneumonia, a blood culture is recommended, preferably before antibiotic administration. Blood cultures generally offer low yield, thus
,40 obtaining them only in targeted patients is cost­effective. A CBC may be useful for severe disease to evaluate for complications of pneumonia (e.g., pneumococcal hemolytic­uremic syndrome) but is not useful for differentiating bacterial or viral etiology. Currently, the literature does not support the routine use of inflammatory markers (C­reactive protein or erythrocyte sedimentation rate), acute­phase reactants, or procalcitonin to distinguish
 bacterial from viral pneumonia in children. However, these markers may be useful to trend disease resolution and inform the need for continued
 antibiotics in severe pneumonia. Drainage and culture of parapneumonic effusions is indicated for large effusions or patients with severe respiratory compromise. Novel biomarkers and systems biology tools under investigation (e.g., RNA signatures, ­omics) show promise for discriminating
,43 pathogens and guiding management.
When tuberculosis is suspected, induced sputum samples from older children or gastric aspirates from infants for microscopy and confirmatory
 culture are necessary. These tests require equipment and expertise beyond the scope of the ED.
IMAGING
,24,45
Guidelines on the use of routine chest radiography are inconsistent. Consider chest radiographs only when the results are likely to alter diagnosis, treatment, or outcome.
Benefits of radiography include diagnosis or confirmation of pneumonia and occasionally the discovery of a significant congenital abnormality. Risks
 and disadvantages include cost, delay, repeated exposure to ionizing radiation, and overdiagnosis/misdiagnosis of bacterial pneumonia. Several studies and major guidelines state that imaging should not be performed routinely in children with mild, uncomplicated acute lower respiratory tract
,24,47,48 infections. Most of these studies and guidelines reference outpatient settings, in which children with prolonged cough, severe symptoms, and other “red flag” features were excluded, so these recommendations may not apply to the ED setting.

The chest radiograph is not the gold standard of diagnosis, because it is neither 100% sensitive nor 100% specific and may be falsely negative (e.g., when clinical disease precedes radiographic changes) or falsely positive (e.g., poor inspiration or rotation; Figures 128­1 and 128­2). While the presence of alveolar infiltrates has shown good interrater reliability among radiologists, other findings such as interstitial infiltrates and pleural
 ,51 effusions are less reliable. Chest radiographs do not reliably distinguish between bacterial and viral causes. Young children with straightforward viral bronchiolitis may show radiographic areas of atelectasis or patchy collapse, resulting in initiation of unnecessary antibiotic therapy for viral
 disease.
FIGURE 128­1. Poor inspiration results in the appearance of pulmonary infiltrates and cardiomegaly in this normal 4­month­old infant. [Photo contributed by BC
Children’s Hospital, Vancouver, British Columbia, Canada.]
FIGURE 128­2. The same child as in Figure 128­1, with adequate inspiration. Note that persistent rotation (see clavicles) causes a false difference in left and right lung density. [Photo contributed by BC Children’s Hospital, Vancouver, British Columbia, Canada.]
The use of ultrasound in the diagnosis of pneumonia is promising. Early studies have shown high interobserver agreement and an acceptable sensitivity and specificity when performed by an experienced sonographer, but it is unclear at this time if ultrasonographic findings correlate with
53­55 etiology or clinical outcomes.
,56,57
Although routine radiographs are not usually necessary, potential indications for chest radiography include the following :
. Infants and children with a toxic appearance and respiratory findings
. Age of  to  months with fever and respiratory symptoms, as part of a full sepsis evaluation
. Child <5 years old, with a temperature of >39°C (102.2°F) lasting  days or more, WBC of ≥20,000/mm, and no clear source of infection 
. Suspicion of a complication, such as pleural effusion or pneumothorax
. Pneumonia that is prolonged or unresponsive to treatment
. Children with biphasic illness (typical symptoms of upper respiratory tract infection followed by acute worsening of [respiratory] symptoms and high fever)
. Suspected foreign body aspiration
. Suspected congenital lung malformation (e.g., sequestration or congenital cystic adenomatous malformation) or chest mass
. Follow­up of recurrent pneumonia involving the same lobe or with lobar collapse at presentation
For a brief overview of important normal and abnormal radiographic findings unique to children, see the “The Pediatric Chest Radiograph” section at the end of this chapter.
TREATMENT
Treatment is based on the presumptive pathogen using information from history, immunizations, and age group (Table 128­4).
SUPPORTIVE AND SYMPTOMATIC TREATMENT
General supportive measures include supplemental oxygen to maintain oxygen saturation above 90% to 92%; antipyretics; oral, nasogastric, or IV fluids to offset respiratory losses; and bronchodilators for wheezing in the setting of asthma. Do not routinely offer bronchodilators for infants less than  months of age if bronchiolitis is suspected. Because children depend on cough to clear mucus, cough suppressants are not generally indicated. Over­the­counter cough suppressants are not effective and have been withdrawn from the market in several countries for children <5 years of age. Narcotic­based cough suppressants are occasionally prescribed in older children, but data on their effectiveness and
 proper dosage are lacking. Codeine in particular is discouraged due to the risk of respiratory suppression in some children. Honey has been shown
 to be an effective and safe treatment for cough in young children with upper respiratory tract infections.
Treat noninfectious pneumonitis (e.g., chemical inhalation, aspiration) and likely viral pneumonia (e.g., age  months to  years, audible wheezing, positive bedside test for respiratory syncytial virus, or influenza) with supportive measures as outlined above. Antibiotics are not indicated for viral pneumonia. Well­appearing, previously healthy febrile infants  to  days old with bronchiolitis (clinical and respiratory syncytial virus– positive) are at low risk for concurrent bacterial pneumonia, bacteremia, and meningitis and do not require radiographs, blood or cerebrospinal fluid testing, or empiric antibiotic therapy for their respiratory infection. These young febrile infants have a small increased risk for concurrent urinary tract
 infections, and urine testing should be considered. Febrile infants younger than  days old generally require a full sepsis workup, including blood, urine and cerebrospinal fluid cultures, and empiric antibiotics.
EMPIRIC ANTIBIOTIC TREATMENT
,11,24
Treat all children with suspected bacterial pneumonia with prompt administration of empiric antibiotics.
Neonates
In neonates younger than  month of age who are at risk of sepsis, administer ampicillin to cover Listeria and group B Streptococcus in conjunction with an aminoglycoside (e.g., gentamicin) or a third­generation cephalosporin (e.g., cefotaxime) for expanded coverage of gram­negative organisms, such as E. coli. Ceftriaxone is contraindicated in neonates because it can displace bound bilirubin.
Young Infants  to  Months Old
The syndrome of afebrile pneumonitis described in infants  to  months old (staccato cough, tachypnea, with or without progressive respiratory distress and diffuse pulmonary infiltrates) may be viral in origin but has also been associated with atypical bacteria, so authors have suggested empiric
 treatment with erythromycin or clarithromycin in this group. Azithromycin is not included in the treatment of patients this young, due to an increased reported risk of pyloric stenosis.
Infants and Children  Months to  Years Old
For these children, treatment choice remains largely empiric. There are notable differences between some North American and European
,16 recommendations, but all presume the most frequent cause of bacterial pneumonia to be S. pneumoniae. For this reason, high­dose oral amoxicillin (80 to 100 milligrams/kg/d) or another β­lactam antibiotic remains the initial drug of choice in suspected bacterial pneumonia. A third­generation cephalosporin (e.g., ceftriaxone or cefotaxime) should be used as initial therapy if penicillin resistance is high in the community, in incompletely immunized children, or in cases of life­threatening infections, including
 empyema.
Children  Years to  Years Old
For children  years to  years old, some North American guidelines list macrolide antibiotics as initial empirical therapy, given the increased role of atypical agents, such as M. pneumoniae and C. pneumoniae, in school­age and adolescent children. This recommendation presumes that macrolides will treat both atypical pathogens and pneumococci. In outpatients in whom atypical pneumonia is a strong suspicion, macrolide monotherapy is a reasonable initial choice. However, high rates of pneumococcal resistance to macrolides in vitro are a growing concern, and several major guidelines now recommend amoxicillin with or without clavulanate as initial therapy for all children ≥3 months of age with simple community­acquired
,24 pneumonia. In hospitalized children in whom the etiology of pneumonia is unclear, β­lactams plus macrolides should be used as first­line therapy for children  years and older. In cases where resistant pathogens or multiple pathogens are suspected, all guidelines make provisions for coverage with third­generation cephalosporins plus macrolides in this age group. With these considerations in mind, typical choices for primary or secondary bacterial pneumonia are listed in Table 128­4. For a child with significant underlying illness or fulminant viral pneumonia, special agents and antimicrobials may be indicated, and consultation is strongly advised. These guidelines may need to be adapted according to formulary, familiarity, and local patterns of antibiotic resistance. Antibiotic choices for children with allergies, unusual exposures, or specific risk factors should be tailored in consultation with a specialist.
The choice of oral versus parenteral antibiotics depends on the patient, severity of disease, and predicted response to therapy. Oral antibiotics provide adequate coverage for most mild­to­moderate cases of bacterial pneumonia. Parenteral therapy is usually limited to neonates and those with severe
 pneumonia requiring hospitalization. Even for children who are admitted, oral treatment may be sufficient within the monitored setting of the
 hospital.
The recommended duration of outpatient treatment is typically  to  days (5 days in cases in which azithromycin is used). This is based on historical
62­64 precedent, although some literature suggests equivalent outcomes in mild pneumonia with as few as  to  days of outpatient treatment. There are theoretical concerns, however, that shorter courses of treatment and poor adherence may drive bacterial resistance. In children, antibiotic choice may also be influenced by important nonmicrobial factors, such as taste, cost, frequency of administration, availability of a liquid formulation, and the child’s ability to swallow.
CONTROVERSIES IN TREATMENT
The optimal duration of outpatient treatment for community­acquired non­severe pneumonia of presumed bacterial etiology in infants and children is controversial. Historically, a 7­ to 10­day course of antibiotic has been used based largely on precedent. However, there is growing evidence to suggest
62­65 equivalent outcomes in mild pneumonia with as few as  to  days of outpatient treatment. The WHO recommends  days of treatment in areas of
 low HIV prevalence and  days of treatment where HIV is common. A 2014 systematic review and meta­analysis of antibiotic treatment for pneumonia in children aged 2­59 months included  studies with ,593 children and found that oral amoxicillin was as effective as parenteral therapy for non­
 severe community­acquired pneumonia and that  days of oral treatment was as effective as  days of the same antibiotic. A recent, two­center, randomized clinical trial in Canada compared  versus  days of high­dose amoxicillin treatment for emergency department­diagnosed community­
 acquired pneumonia in healthy children  months to  years of age not requiring hospitalization. Clinical cure at 14­21 days was similar in both groups (85.7% vs .1%, respectively). Growing concern about antibiotic resistance and principles of antimicrobial stewardship along with emerging
 evidence of effectiveness suggest that a 3­ to 5­day treatment may be a reasonable alternative to traditional longer­course therapy.
,70
The use of macrolides (erythromycin, clarithromycin, azithromycin) as first­line agents in young children is an area of controversy. Macrolides are generally effective against atypical and intracellular agents, which are more common in children after the age of  years, but they may be ineffective
 against S. pneumoniae. Pneumococcal resistance to macrolides in Europe and North America ranges from .5% to >50.0%. The indiscriminate use of
 azithromycin in treating upper respiratory tract infections appears to be driving streptococcal resistance in some populations. The liquid suspension of azithromycin is not approved for children <6 months of age due to the risk of pyloric stenosis. Some suggest that children who have fever of <2 days in duration and who are <3 years of age are at very low risk of community­acquired Mycoplasma infection; macrolides can thus be safely avoided as
 first­line antibiotics. If a child fails to improve when taking amoxicillin or an equivalent β­lactam after at least  to  hours of treatment, consider adding a macrolide.
Pneumococcal resistance to penicillin and other β­lactams is another area of concern around the globe. To date, most antibiotic resistance in community­acquired streptococci has been documented in vitro, rather than in vivo, and clinical response is still satisfactory when clinicians use an
 increased dosage. The safety and efficacy of fluoroquinolones for respiratory infections in children are not established, and their use is generally restricted due to theoretical risks of arthropathy. Doxycycline, a much older and less expensive agent, has activity against atypical pathogens as well as streptococci, but is restricted to use in adolescents and adults, because use in young children it may cause permanent staining of the adult teeth. As resistance to amoxicillin, macrolides, and other antibiotics grows, the importance of prevention using pneumococcal conjugate vaccines is critical.
DISEASE COMPLICATIONS
Most viral pneumonias resolve spontaneously without specific therapy. Complications are similar to those for bronchiolitis and include dehydration, bronchiolitis obliterans (rarely), and apnea. Apnea is a potential complication of infection with respiratory syncytial virus, Chlamydia, or
B. pertussis infection in very young infants. Pleural effusions can occur with viral pneumonias but are not common.
Uncomplicated bacterial pneumonia usually responds within  hours to antibiotic therapy. Failure to respond or worsening of disease suggests a viral etiology, a resistant organism, or development of a pneumonia­associated complication. Complications include pleural effusion, empyema, pneumothorax, or pneumatocele. Effusions can occur in pneumococcal and Mycoplasma pneumonias; they are also associated with H. influenzae type b infections. S. aureus is associated with empyema, abscess, and pneumatoceles. Mycoplasma pneumonia may cause extrapulmonary complications such as arthritis and meningitis. Local and hematogenous spread of tuberculosis can result in myriad manifestations inside and outside the lung.
Systemic complications of pneumonia include dehydration, sepsis, and hemolytic­uremic syndrome.
The child with pneumonia who returns to the ED with worsening clinical symptoms should prompt heightened suspicion for severe or complicated disease. If the initial treatment was supportive care for a presumed viral pneumonia, consider secondary bacterial pneumonia or an alternative
 diagnosis (e.g., cardiac disease, congenital anomaly, foreign body). Similarly, a child receiving antibiotics who returns with diminished breath sounds, dullness to percussion, or worsening respiratory distress should prompt evaluation for complications, such as empyema, effusion, or
,76 pneumothorax. If antibiotic­resistant pneumonia is suspected, further investigation with blood or pleural fluid cultures may be warranted.
DISPOSITION AND FOLLOW­UP

Recommendations for outpatient, inpatient, and intensive care treatment of pneumonia are presented in Table 128­5. In addition to these clinicallybased criteria, neonates and infants up to  days old often require hospital admission, as do infants and children with significant comorbid disease
(e.g., cystic fibrosis, sickle cell disease, underlying immunodeficiency or malignancy). Social indications for admission include the inability of
 caregivers to have access to, afford, understand, or ensure outpatient treatment and follow­up.
TABLE 128­5
Disposition of Infants and Children With Pneumonia
Age Outpatient Management Inpatient Management Intensive Care Management
Infants Mild­to­moderate symptoms (no Oxygen saturation <90–92%, RR Inability to maintain oxygen saturation >90–92% with fraction of cyanosis, grunting, significant >70 breaths/min, respiratory inspired oxygen >0.6, severe respiratory distress or recurrent retractions), oxygen saturation >90– distress (retractions, grunting, apnea, respiratory fatigue or respiratory failure, need for
92%, respiratory rate (RR) <70 apnea), poor feeding, dehydration, positive­pressure ventilation (continuous positive airway breaths/min, feeding well and well family unable to provide pressure, bilevel positive airway pressure, intubation with hydrated, reliable caretakers and appropriate home observation or mechanical ventilation), altered mental status, signs of shock or outpatient follow­up ensure follow­up severe sepsis
Children Mild­to­moderate symptoms (no Oxygen saturation <90–92%, cyanosis, grunting, significant tachypnea (see Table 128­3), retractions), oxygen saturation >90– respiratory distress (retractions,
92%, no tachypnea, feeding well grunting, apnea), poor feeding, and well hydrated, reliable dehydration, family unable to caretakers and outpatient follow­up provide appropriate home observation or ensure follow­up
Infants with suspected B. pertussis infection (whooping cough) are at risk for apnea and should be admitted under respiratory isolation. Indications for hospitalizing patients with respiratory syncytial virus pneumonia are the same as those for patients with respiratory syncytial virus bronchiolitis
(see Chapter 127, “Wheezing in Infants and Children”). Patients with suspected active pulmonary tuberculosis should be admitted under respiratory isolation. Patients who fail a trial of oral antibiotics and those with complications of pneumonia require admission for further diagnosis and therapy.
Moderate to large pleural effusions, pneumatoceles, or findings suggestive of a serious bacterial infection in a child <1 year of age may suggest a pathogen other than S. pneumoniae (in particular H. influenzae type b or S. aureus) and require close monitoring.
DISCHARGE INSTRUCTIONS
All families should be provided with specific instructions on the dosage and scheduling of medications and the signs of worsening respiratory distress, including tachypnea and retractions. Encourage return to medical care for children who cannot take prescribed antibiotics or adequate amounts of fluid. Ensure that all children discharged with the diagnosis of pneumonia have follow­up within a day or two with a primary care provider. Younger children require closer follow­up. Modifiable factors should be reviewed with caregivers:
. Hand washing and general hygiene to prevent transmission
. Breastfeeding of infants, which is known to be protective
. Avoidance of smoking and secondhand smoke
. Vaccination, including pneumococcal conjugate vaccine as well as polysaccharide vaccine for at­risk children older than  years
SPECIAL CONSIDERATIONS
For a child with significant underlying illness or fulminant viral pneumonia, special agents and antimicrobials may be indicated, and consultation is strongly advised.
INFLUENZA
Influenza is a common cause of respiratory infections worldwide. Classic symptoms include fever, cough, runny nose, headache, and myalgias, lasting up to  days.

Complications of influenza include secondary bacterial pneumonia and occasionally a pneumonia from the virus itself. Apnea is a rare but serious complication in young infants.
Point­of­care and other rapid testing may be helpful in pinpointing influenza as the source of fever in children and avoiding a search for additional
 causes. Sensitivities are moderate (40% to 70%), but specificities are high (85% to 100%) if performed within the first  days of symptoms. If a falsenegative result is suspected, confirmatory polymerase chain reaction can be obtained if confirmation of result is necessary. Treatment, if indicated, should not be delayed while waiting for test results.
Treatment of influenza is largely supportive, with fluids, rest, and fever control. Note that acetylsalicylic acid should not be used for fever control, due to the risk of Reye’s syndrome.
The role for antivirals is unclear. A 2012 Cochrane meta­analysis of the older medications amantadine and rimantadine showed a limited role in
 prevention and amelioration of influenza A in children. The number needed to treat was high and the quality of evidence was low.
Neuraminidase inhibitors oseltamivir (Tamiflu®) and zanamivir (Relenza®) may help shorten the duration and severity of symptoms and reduce the risk of complications, especially in hospitalized or high­risk patients. The clinical benefit of these medications is greatest when started early in the disease.

The overall utility of these medications remains unclear. Seasonal recommendations from the Centers for Disease Control and Prevention may help guide the clinician in the appropriate use of antiviral medications.
With few treatments available, the best defense against influenza and its associated pneumonias remains annual vaccination, frequent hand washing, and droplet precautions.
The U.S. Centers for Disease Control and Prevention and the American Academy of Pediatrics recommend routine annual influenza vaccination for children  months and older. Special emphasis is placed on children  years and under, because they are most at risk for complications and most likely to transmit disease in the community.
Children generally require a single dose of the vaccine annually, to account for antigenic changes in the virus from year to year. Those being vaccinated for the first time typically require a second dose at least  days later.
A nasal form of the vaccine containing live, attenuated virus is approved for children  years of age and older. However, the intranasal vaccines have been shown to be ineffective during multiple recent influenza seasons and have not been recommended. Annual recommendations from the Centers for Disease Control and Prevention should be consulted with regard to administration of the nasal live virus vaccine, as these change from year to year.
There is an increased risk of wheezing when used in children with a prior history of wheeze. Those with asthma or immune suppression should use the standard, injectable vaccine, which contains no live virus.
TUBERCULOSIS
Children of all ages are susceptible to tuberculosis, and most have primary disease, rather than secondary reactivation. Both upper lobe infiltrates and hilar lymphadenopathy on chest radiograph suggest the diagnosis, but classic findings can be absent in children, especially those with immune
 deficiencies. Infants and young children tend to progress rapidly from infection to clinical disease, and hematogenous spread can lead to the
 radiographic “snowstorm” appearance of miliary tuberculosis. Secondary tuberculosis has a predilection for the upper segments of the lung, as in adults, and may yield a cavitary lesion in some cases. Mycobacterium avium lesions may be indistinguishable from those of secondary tuberculosis.
OPPORTUNISTIC INFECTIONS
Nodular findings in the lungs may alert the astute clinician to the presence of other, rare infectious agents, such as Histoplasma, Aspergillus, and
Pneumocystis. Pediatric patients with human immunodeficiency virus/acquired immunodeficiency syndrome may be susceptible to all of these, as well as cytomegalovirus, lymphomas, and lymphocytic interstitial pneumonia.
CYSTIC FIBROSIS
Children with cystic fibrosis have decreased mucus clearance, which leads to airway obstruction. More advanced disease results in chest radiograph findings such as peribronchial thickening and mucous plugging, with subsequent cystic or bullous lung lesions, segmental atelectasis, hilar adenopathy, and bronchiectasis. Air trapping may be seen on expiratory views. Patients with cystic fibrosis are also at risk for pneumothorax.
ASPIRATION PNEUMONIA
Patchy atelectasis and air space consolidation in the dependent zones of the lung should raise suspicion of aspiration pneumonia or pneumonitis.
Recurrent aspiration pneumonias may occur in children with chronic gastroesophageal reflux disease, tracheoesophageal fistula, developmental delay, immobility, or neuromuscular disorders.
THE PEDIATRIC CHEST RADIOGRAPH
NORMAL NEONATAL ANATOMY
The chest of a neonate (<1 month of age) has a more pyramidal or trapezoidal shape than the long, rectangular form of the adult. The cardiac silhouette may occupy up to 60% or 65% of the chest width on the frontal view and still be considered normal. In infants, bronchial branching may be visible beyond the level of the carina, giving the false impression of pathologic air bronchograms. The thymus appears as a large, dense, anterior mediastinal “sail,” until involution occurs around age . A normal thymus can often be recognized by the sharp inferior edge of its silhouette and occasionally by a “wave” or “sail” sign at the lateral edge, where the adjacent ribs indent this soft, solid organ. Occasionally the thymus may be confused with a lobar pneumonia, mediastinal mass, or hilar lymphadenopathy (Figure 128­3). A lateral view can help to confirm the anterior location of the thymus (Figure 128­4). A silhouette that extends behind the heart shadow or posterior to the vertical lucency of the trachea should be investigated.
FIGURE 128­3. Arrows indicate a normal thymus. Rotation, apparent from the location of the heart, trachea, and clavicles, makes this thymus appear to be far right of midline. [Photo contributed by BC Children’s Hospital, Vancouver, British Columbia, Canada.]
FIGURE 128­4. Lateral view confirms thymic density fully confined to the anterior mediastinum (arrows). [Photo contributed by BC Children’s Hospital, Vancouver,
British Columbia, Canada.]
TRANSIENT TACHYPNEA OF THE NEWBORN AND MECONIUM PNEUMONITIS
Occasionally parents may bring a very young newborn to the ED because of real or perceived breathing difficulties. Noninfectious causes of tachypnea and respiratory distress in the first few days of life include transient tachypnea of the newborn, or “wet lung,” and chemical pneumonitis from meconium aspiration. The former may cause increased vascular markings, linear interstitial opacities, and even pleural effusions on radiographs due to interstitial edema. Meconium aspiration can block small airways, leading to hyperinflation and bilateral air space opacities on plain radiographs.
Signs of interstitial opacities or edema should prompt observation and/or consultation with a specialist.
FOREIGN BODY OR HYDROCARBON ASPIRATION
In addition to pneumonias from the infectious causes, toddlers are susceptible to choking and foreign body aspiration from objects they can reach.
These may include organic materials (e.g., food) or inorganic objects (coins, buttons, batteries), as well as volatile toxins such as cleaning products, gasoline, or other hydrocarbons. Retained foreign bodies can lead to respiratory distress and febrile aspiration pneumonia. Radiopaque foreign bodies will appear on the chest radiograph; signs of radiolucent foreign bodies include asymmetric air trapping or segmental collapse past an obstructed bronchus. By contrast, inhaled hydrocarbons and irritants may yield a pneumonitis with patchy lower air space opacities and even pneumatoceles if the presentation is delayed.
PNEUMONIA IN THE OLDER CHILD
By school age, the radiographic signs of chest infection in children appear similar to typical findings in adults. There may be obvious lobar consolidation or patchy, multifocal findings. Younger children can also present with “round pneumonia” (Figure 128­5), a sharply defined consolidation often found in the posterior lower lobe, classically from pneumococcal infection. Cavitation and pleural effusions should arouse suspicion of infection with S. aureus or S. pneumoniae, particularly penicillin­resistant pneumococcus (Figure 128­6).
FIGURE 128­5. Anterior­posterior (A) and lateral views (B) show lower lobe consolidation (arrows). [Photos contributed by BC Children’s Hospital, Vancouver, British
Columbia, Canada.]
FIGURE 128­6. Complicated left­sided pneumonia. Note the pleural effusion (white arrows) and cavitation (black arrows). [Photo contributed by BC Children’s
Hospital, Vancouver, British Columbia, Canada.]
Acknowledgment
The author would like to thank Joseph E. Copeland for his prior work on this chapter.


