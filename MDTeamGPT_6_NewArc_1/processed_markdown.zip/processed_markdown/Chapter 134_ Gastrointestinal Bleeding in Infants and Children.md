## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 134: Gastrointestinal Bleeding in Infants and Children
Sarah M. Reid
INTRODUCTION AND EPIDEMIOLOGY
GI bleeding varies in its epidemiology and presentation depending on whether it originates from the upper or lower GI tract. Upper GI (UGI) bleeding is bleeding proximal to the ligament of Treitz, whereas lower GI (LGI) bleeding originates distal to this ligament. A recent study demonstrated a 14%
 increase in pediatric GI bleeding associated ED visits between 2006 (82/100,000 children) and 2011 (94/100,000 children). In this sample, 20% of visits were for UGI bleeding, 30% were for LGI bleeding, and the remainder were unspecified. More than three­quarters (81%) of the patients were discharged home from the ED.
The signs and symptoms of GI bleeding in children vary and include the following: bright red blood in small strands or clots in emesis or bowel movements, vomiting of gross blood (hematemesis), black tarry stools (melena), or the passage of bright red or maroon­colored blood from the rectum (hematochezia). Occult bleeding may result in unexplained pallor, fatigue, and anemia. Severity is assessed by vital signs, physical appearance, and the hemodynamic status of the patient, all of which lead to an estimation of the volume of blood loss. Worrisome symptoms and signs include pallor, diaphoresis, lethargy, abdominal pain, tachycardia, hypotension, and altered mental status. GI bleeding can be life threatening. Advances in endoscopy and radiology and newer therapeutic modalities have helped identify the causes of bleeding more accurately and have provided more treatment options.
CLINICAL APPROACH
Assess bleeding and institute resuscitation if the child has signs of hemorrhagic shock. Next, obtain a history and perform a physical examination, and try to establish the level of bleeding as UGI or LGI, because the subsequent diagnostic and treatment steps differ. Then, narrow the differential diagnosis based on history, physical examination, laboratory studies, and the categorization of age­related causes of UGI and LGI bleeding. The presence of any one of melena, hematochezia, unwell appearance, or moderate to large volume of fresh blood in the vomitus was associated with a clinically significant UGI bleed (defined as a hemoglobin drop of >20 g/L, need for blood transfusion, need for emergent endoscopy, or need for
 surgical procedure).
ASSESS BLEEDING AND BEGIN RESUSCITATION
There are several important questions to consider. Is the patient stable or unstable? Is this really blood, and is it coming from the GI tract? Is it a small
 amount of blood or a large volume? Has the child had prior episodes of bleeding, and if so, do the parents know the cause and prior treatment?
IS THE PATIENT STABLE OR UNSTABLE?
The presence of tachycardia, pallor, tachypnea, prolonged capillary refill time, altered mental status, metabolic acidosis, and/or hypotension indicates significant GI bleeding. Tachycardia and tachypnea are the first clinical signs, followed by delayed capillary refill, decreased urine output, altered mental status, metabolic acidosis, and pallor. Orthostatic changes in heart rate and blood pressure indicate that significant bleeding has occurred.
Hypotension is a late sign and indicates uncompensated hemorrhagic shock. Any signs of hemorrhagic shock require simultaneous resuscitation, diagnosis, and treatment. Maintain the airway, monitor oxygen saturation and provide oxygen, place two large­bore IVs (20 gauge or larger), and administer boluses of crystalloid and, if necessary, blood products.
IS THIS REALLY BLOOD?
Determine whether or not the vomit or stool really contains blood. Beets, food coloring, and fruit juices can look like blood. Black and tarry stools can rDeoswulnt lforaodme vdi t2a0m2i5n­s7 w­1it 6h: i1r2o nP, b Yisomuur tIhP (iPse 1p3to6­.1B4is2m.1o5l®9).,1 s2p7inach, cranberries, blueberries, or licorice. Urinary (urate) crystals in the neonatal diaper
Chapter 134: Gastrointestinal Bleeding in Infants and Children, Sarah M. Reid are often orange in color and may be interpreted by a caregiver as blood. The Gastroccult® and Hemoccult® tests (Beckman Coulter, Brea, CA) can be
. Terms of Use * Privacy Policy * Notice * Accessibility used to document the presence of blood in gastric contents or stool, respectively. These guaiac­based tests rely on the peroxidase activity of the heme portion of hemoglobin. False­positive results are associated with foods that have peroxidase activity such as red meat, melons, grapes, radishes, turnips, cauliflower, and broccoli. False­negative results can result from the ingestion of vitamin C due to its antioxidant properties. Newer guaiac kits
 have improved specificity.
IS BLOOD COMING FROM THE GI TRACT?
Evaluate the child for epistaxis, recent dental work, or gingival bleeding, because swallowed blood may lead to hematemesis. The neonate can swallow maternal blood during delivery or from breastfeeding if the mother has fissures on her nipples. In the toddler, blood could come from an injury to the oropharynx or nose. Make sure that blood does not originate from the throat or lungs. Distinguish whether the blood in the diaper is from a GU or GI source. Examine the perineum and urethra. Neonatal girls may develop some vaginal bleeding from maternal hormone withdrawal.
IS IT A SMALL OR LARGE AMOUNT OF BLOOD?
It is difficult to gauge the amount of bleeding from caretaker descriptions, because even small amounts of blood can appear alarmingly large. Assess the clinical status of the patient, vital signs, results of laboratory studies, and results of serial clinical examinations to determine the amount of bleeding. The hemoglobin and hematocrit are unreliable indicators of blood loss in the early stages.
,5
See Tables 134­1, 134­2, and 134­3 for potential recurrent causes of GI bleeding organized by age and symptoms.
HISTORY
Ask whether the child had prior episodes of bleeding. If so, ask whether the caregivers know the cause and prior treatments. There are many causes of
UGI and LGI bleeding in children, and the causes vary significantly by age (Tables 134­1 and 134­2). In addition to the age­based approach to the differential diagnosis of GI bleeding, the clinical presentation and constellation of associated symptoms are often useful in narrowing the differential diagnosis for a particular child. Table 134­3 describes symptom complexes along with the differential diagnosis of GI bleeding.
TABLE 134­1
Age­Based Causes of Upper and Lower GI Bleeding
Upper GI Bleeding
Neonate Infant/Toddler Child/Adolescent
Common Common Common
Swallowed maternal blood Non­GI source (e.g., epistaxis) Mallory­Weiss tear
Milk/soy protein allergy Mallory­Weiss tear Gastritis (especially Helicobacter pylori gastritis)
Trauma (nasogastric tube in NICU) Esophagitis Esophagitis
Uncommon Gastritis Peptic ulcer disease
Stress ulcer/gastritis Uncommon Uncommon
Esophagitis Stress gastritis or ulcer Esophageal varices
Vascular malformation Peptic ulcer disease Toxic/caustic ingestion
Hemorrhagic disease of newborn (vitamin K deficiency) Vascular malformation Foreign body
Coagulopathy/bleeding diathesis GI duplication Vasculitis
Coagulopathy associated with infection Gastric/esophageal varices Vascular malformation
Bowel obstruction Bowel obstruction
Toxic/caustic ingestion Crohn’s disease
Coagulopathy/bleeding diathesis Coagulopathy/bleeding diathesis
Foreign body GI stromal tumors
Dieulafoy’s lesion
Lower GI Bleeding
Neonate Infant/Toddler Child/Adolescent
Common Common Common
Swallowed maternal blood Anal fissure Anal fissure
Anal fissure Milk/soy protein allergy Infectious gastroenteritis
Milk/soy protein allergy Infectious gastroenteritis Polyps; benign, familial
Infectious gastroenteritis Uncommon Uncommon
Uncommon Intussusception Henoch­Schönlein purpura
Meckel’s diverticulum* Meckel’s diverticulum* Hemorrhoids
Necrotizing enterocolitis GI duplication Inflammatory bowel disease
Vascular malformation Hemolytic­uremic syndrome Meckel’s diverticulum* Hemorrhagic disease of newborn (vitamin K deficiency) Henoch­Schönlein purpura Hemolytic­uremic syndrome
Intussusception Malrotation with volvulus Vascular malformation
Malrotation with volvulus Polyps; benign, familial Celiac disease
Hirschsprung’s­associated enterocolitis (toxic megacolon) Coagulopathy/bleeding diathesis
GI duplication Vascular malformation
Abbreviation: NICU = neonatal intensive care unit.
*Most common cause of severe LGI bleeding in all ages.
TABLE 134­2
Causes of GI Bleeding by Type
Hematemesis
Infant Swallowed maternal blood
Vitamin K deficiency
Vascular malformation
Child/adolescent Swallowed blood from epistaxis, dental work, oral trauma
Mallory­Weiss tear
Esophagitis/gastritis
Peptic ulcer disease
Esophageal varices
Vascular malformation
Toxic ingestion
Foreign body
Coagulopathy/bleeding diathesis
Hematochezia and melena
Infant Upper GI sources
Anal fissure
Milk/soy protein allergy
Infectious gastroenteritis
Meckel’s diverticulum
Intussusception
Malrotation with volvulus
Ischemic bowel
Child/adolescent Upper GI sources
Anal fissure
Infectious gastroenteritis
Polyps
Henoch­Schönlein purpura
Hemorrhoids
Inflammatory bowel disease
Intussusception
Meckel’s diverticulum
Malrotation with volvulus
Ischemic bowel
Hemolytic­uremic syndrome
Celiac disease
Vascular malformation
TABLE 134­3
Symptom Complexes and Differential Diagnosis for GI Bleeding
Symptom Complex Differential Diagnosis
Painless hematemesis Swallowed blood (non­GI source)
Coagulopathy/bleeding diathesis
Hematemesis and abdominal, epigastric, or chest pain Peptic ulcer disease
Helicobacter pylori–associated gastritis
Esophagitis/gastritis
Hematemesis, hematochezia, or melena with underlying systemic disease Esophageal varices
Inflammatory bowel disease
Vomiting, hematochezia, or melena with abdominal pain Intussusception
Malrotation with volvulus
Ischemic bowel
Henoch­Schönlein purpura
Necrotizing enterocolitis
Vomiting, hematochezia, or melena with fever Infectious gastroenteritis
Inflammatory bowel disease
Painless rectal bleeding Polyp
Meckel’s diverticulum
GI duplication
Vascular malformation
The type and implications of questioning differ depending on the age of the child (Tables 134­1 and 134­2). If the child is verbal, obtain the history from both the child and the parent or caregiver. Elicit an accurate chronology of events, and ask questions to help frame the differential diagnosis (Table
134­4). Vomiting of bright red blood or coffee­ground emesis is the classic presentation of UGI bleeding. Bloody diarrhea and bright red blood mixed with or coating normal stool are the classic presentations of LGI bleeding. Hematochezia, melena, or occult GI blood loss could represent UGI or LGI
 bleeding.
TABLE 134­4
Focused Historical Questions
Chief Frequency and volume of vomiting complaint Blood­streaked, coffee­ground, or bloody vomitus
Frequency and volume of diarrhea
Bloody diarrhea
Constipation with blood­streaked stool
Blood on toilet paper or blood in toilet bowl
Abdominal pain along with bloody vomitus or stool
Dyspepsia; heartburn; dysphagia
Fever
Review of Rashes; joint pain; oral ulcers; perianal lesions; ocular symptoms; weight loss; fatigue; delayed puberty; failure to thrive; abnormal systems bleeding; dehydration
Medications Iron; aspirin; NSAIDs; steroids; alcohol; recent antibiotics
Environment Foreign body ingestion; foreign travel; sick contacts; raw meat/poultry; unpasteurized milk/cheese; animal contacts; water source
Trauma Injury to abdomen (especially epigastrium or right upper quadrant) or significant body surface area burns
Past medical Term or premature; umbilical artery catheter; postpartum care; abdominal surgery; sepsis; liver disease; GI disease (enterocolitis, history intussusception, congenital anomalies); coagulopathy/bleeding diathesis
Family GI bleeding; polyps; vascular anomalies; coagulopathy/bleeding diathesis; inflammatory bowel disease history
PHYSICAL EXAMINATION
Obtain vital signs and pulse oximetry. Assess the airway, breathing, and circulation of the patient. Perform a complete physical examination. Gain the confidence of the child before any painful examination or procedures are performed. Examine the nose for any signs of epistaxis and the oral pharynx for any signs of injury, infection, bleeding, or ulcers. Examine the skin for bruises or petechiae (a sign of coagulopathy), jaundice and abnormal venous pattern on the abdomen that would point toward liver disease, cutaneous vascular malformations that may signal lesions of the GI tract, or the palpable purpura associated with Henoch­Schönlein purpura. Allow the young child to rest on the caregiver’s lap while examining the abdomen. Start with visual inspection, then auscultate for bowel sounds, and finally, palpate the abdomen for tenderness, guarding, rebound, rigidity, organomegaly, ascites, or masses. External examination of the anus and digital rectal examination are necessary to identify fissures, skin tags, fistulae, hemorrhoids, polyps, and impacted stool and to test for fecal blood.
DIAGNOSIS
Try to determine if the source of bleeding is UGI or LGI. In cases where it is unclear if UGI bleeding is occurring, consider nasogastric lavage. Nasogastric lavage is performed with a 12­French nasogastric tube in small children and a 14­ to 16­French tube in older children. Instill  mL of warmed saline for infants and 100 to 200 mL for older children while keeping the child’s head elevated to  degrees to reduce the risk of aspiration.
After  to  minutes, gently aspirate gastric contents. Blood­flecked or coffee­ground aspirate suggests a slow rate of UGI bleeding, whereas bright red blood suggests serious hemorrhage. The usefulness of nasogastric lavage is limited, because clear aspirate does not exclude major bleeding from the
UGI tract. For example, a duodenal ulcer distal to the pylorus may not reflux blood into the stomach and could yield a negative gastric aspirate.
Laboratory studies are guided by the results obtained from the history and physical examination, the child’s appearance (ill or not), and the differential diagnosis (see Chapter 133, “Acute Abdominal Pain in Infants and Children,” and Chapter 131, “Vomiting, Diarrhea, and Dehydration in Infants and
Children”).
The stable child with minimal or self­limited bleeding may require no further diagnostic evaluation. A CBC, type and screen or cross­match of blood, serum electrolytes, renal function tests, liver function tests, coagulation panel, urinalysis, and stool testing for enteric pathogens or Clostridium difficile toxin should be obtained, as needed.
For minimal or moderate GI bleeding, it may be difficult to determine the exact cause in the ED. Diagnosis may require ultrasonography, radiographic
 imaging, endoscopic evaluation, or a technetium­99m (Meckel) scan.
DIFFERENTIAL DIAGNOSIS FOR UPPER GI BLEEDING BY AGE GROUP
Although the differential diagnosis is guided by the results of history and physical examination and age­related causes, there is considerable overlap among age groups (Table 134­1). Mucosal lesions such as gastritis, esophagitis, ulcer disease, and Mallory­Weiss tears can be seen in children of any age. Massive bleeding can occur from esophageal varices, ulcer disease, vascular malformations, Meckel’s diverticulum, and GI duplication.
Neonates
Hematemesis in the newborn is most likely the result of swallowed maternal blood at delivery or during breastfeeding from cracked nipples. The
Apt test is a qualitative test that distinguishes fetal from maternal hemoglobin. The blood in question is mixed with alkali to detect conversion of oxyhemoglobin to hematin. Fetal hemoglobin is more resistant to denaturation than adult hemoglobin. If the supernatant stays pink after the addition of alkali, the blood is fetal in origin (reported as a positive test). If it turns brown, it is maternal blood. Hemorrhagic disease of the newborn is rare, but if there was failure to administer vitamin K in the immediate postpartum period (e.g., home birth), a prolonged prothrombin time can result in neonatal bleeding.
Infants and Children
Infants and children with severe gastroesophageal reflux may develop esophagitis and hematemesis. Mallory­Weiss tears after acute forceful vomiting or retching can also cause hematemesis. Any child with significant illness or injury (shock, polytrauma, respiratory failure, burns, head injury, renal failure, or vasculitis) can develop stress­related peptic ulcer disease.
Ingestion of a sharp foreign body or button battery can occasionally cause GI bleeding. Removal by endoscopy is indicated. See Chapter ,
“Esophageal Emergencies,” for further discussion of button battery ingestions.
Preschool and older children can develop idiopathic ulcer disease. Peptic ulcer disease in the child is similar to that in adults, and there may be a positive family history. Young children may have poorly localized abdominal pain, bleeding, or even signs of obstruction or perforation. The adolescent will describe epigastric burning pain in a pattern more typical of the adult. If the bleeding is low grade, chronic symptoms of weakness and fatigue may develop. Helicobacter pylori is a leading cause of secondary gastritis and peptic ulcer disease in older children. Diagnosis should be made
 using endoscopy and is based on either positive culture or H. pylori gastritis on histopathology with at least one other positive biopsy­based test. H.
 pylori eradication is confirmed using either the two­step monoclonal stool H. pylori antigen test or the C­Urea Breath Test (Kimberly­Clark Corp.,

Roswell, GA).

Variceal bleeding is the most common cause of severe UGI bleeding in children. Consider esophageal variceal bleeding in older children and those with underlying chronic hepatic or vascular disease resulting in portal hypertension. Primary diseases of the liver that may lead to portal hypertension include biliary atresia, cystic fibrosis, hepatitis, α ­antitrypsin deficiency, or congenital hepatic fibrosis. Portal hypertension may occur following liver
 transplant or operative repair of liver diseases such as biliary atresia. Other predisposing factors to portal hypertension include neonatal omphalitis,
 umbilical venous cannulation, abdominal sepsis, and abdominal/surgical trauma, although many cases remain idiopathic.
Reactive gastritis can occur due to anti­inflammatory drugs, alcohol, cocaine ingestion, iron ingestion, H. pylori, Crohn’s disease, Henoch­Schönlein purpura, or foreign bodies. Rarely, GI stromal tumors can arise from the wall of the GI tract mesentery or omentum. Most of these are found in the stomach and are associated with genetic disorders such as neurofibromatosis.
An unusual cause of UGI bleeding in children is Dieulafoy’s lesion. Symptomatic lesions result when an abnormal submucosal artery erodes through a tiny mucosal defect, typically in the fundus of the stomach, causing massive bleeding. The characteristic history is recurrent massive hematemesis
 without any prodromal symptoms. Definitive diagnosis is usually made during endoscopy.
DIFFERENTIAL DIAGNOSIS FOR LOWER GI BLEEDING BY AGE GROUP
The presence of melena, hematochezia, or bright red blood per rectum can help to differentiate causes of LGI in children (Figure 134­1). The differential diagnosis for LGI bleeding is also age dependent (Table 134­1). The approach to LGI bleeding in the neonate can be organized based on whether the baby appears well or unwell (Figure 134­2).
FIGURE 134­1. Diagnostic algorithm for lower GI (LGI) bleeding in children. UGI = upper GI.
FIGURE 134­2. Approach to lower GI (LGI) bleeding in a neonate.
Neonates and Infants
The neonate with dark, tarry stools likely has swallowed maternal blood from delivery or breastfeeding. Birth history is important because failure to replace vitamin K can lead to coagulopathy and massive bleeding.
As the infant ages, other disorders become important. Anal fissures are a common cause of bright red rectal blood on the surface of well­formed stools or toilet paper in children of all ages and highlight the importance of a careful rectal examination and spreading of anal skin folds. Milk protein
 allergy has a prevalence of 2% to 3% in infants, and cross­reactivity with soy protein exists in at least 10% of cases. Protein­induced allergic enterocolitis, proctitis, or proctocolitis may lead to blood­streaked, mucousy, loose stools. Food protein–induced enterocolitis is a rare, delayed non– immunoglobulin E–mediated reaction typically presenting with profuse vomiting and diarrhea  to  hours after ingestion of the offending allergen,
 most commonly cow’s milk, soy, rice, or oats. The diarrhea may be frankly bloody, and in 15% of reactions, the infant may develop profound dehydration and lethargy. The basis of therapy in milk or soy protein allergy is removal of the offending protein using hydrolyzed or elemental formula. Breastfed infants whose mothers ingest dairy or soy may also suffer from this condition, and the offending protein must be eliminated from
,11 the maternal diet.
Necrotizing enterocolitis is most commonly seen in preterm infants in the neonatal intensive care unit, but may rarely be seen in term infants.
Infants will be systemically unwell and present with abdominal distention and hematochezia. Plain radiographs reveal ileus and the pathognomonic pneumatosis intestinalis diagnostic of this condition. Infants with Hirschsprung’s disease (congenital aganglionic megacolon) may develop
Hirschsprung’s­associated enterocolitis, also characterized by abdominal distention and hematochezia. Hirschsprung’s­associated enterocolitis
 should be considered in any infant who appears toxic and has bloody diarrhea.
In older infants who develop sudden painless hematochezia, congenital malformations such as Meckel’s diverticulum and GI duplication must be considered. Meckel’s diverticula are remnants of the omphalomesenteric duct in the distal ileum and are present in approximately 2% of the
 population. They may be lined with ectopic gastric mucosa and typically present with painless rectal bleeding in the 2­month to 2­year­old age group.
Diagnosis is made using a Meckel scan. Intussusception is another important consideration in infants and young children with a peak incidence
 between  and  months of age. Intussusception is associated with episodes of colicky abdominal pain and vomiting. As the intussusception progresses, painful episodes may alternate with periods of lethargy, and gross blood (“currant jelly”) may be noted in the stool. Diagnosis is made using US or contrast/air enema. Painful LGI bleeding in the infant can also be a symptom of malrotation with volvulus. Volvulus most commonly presents with abdominal pain, distention, and bilious vomiting, but may lead to bowel ischemia and subsequent LGI bleeding as the condition progresses. Both intussusception and volvulus represent true surgical emergencies and are further discussed in Chapters 131 and 133. Children Age  to  Years Old
Children in the 2­ to 5­year­old age range have a different spectrum of disorders causing LGI bleeding: juvenile polyps, infectious gastroenteritis, hemolytic­uremic syndrome, and Henoch­Schönlein purpura. A review of recent literature suggests an estimated detected prevalence of colorectal
 polyps in 12% of all children with LGI bleeding undergoing colonoscopy. Manifestations of polyps range from chronic heme­positive stools to acute hematochezia from autoamputation of the polyp at its stalk. Juvenile polyps are usually benign hamartomas, and most have no malignant potential.
Multiple adenomatous polyps should suggest diagnoses such as familial adenomatous polyposis.

Infectious gastroenteritis should be evident by history and physical examination (Table 134­5). Also see Chapter 131. When bloody diarrhea is
 present, stool cultures should be obtained. Patients with typical diarrhea­associated hemolytic­uremic syndrome caused by Shiga toxin–producing strains of Escherichia coli have an antecedent episode of hemorrhagic enterocolitis within  to  days before the onset of thrombotic
 microangiopathy. Children who have recently been exposed to antibiotics may develop bloody diarrhea from pseudomembranous colitis associated with C. difficile infection. In Henoch­Schönlein purpura, 50% to 75% of patients have episodic abdominal pain and/or blood in their stool from intestinal vasculitis. One­third of Henoch­Schönlein purpura patients develop acute intestinal bleeding manifested as gross or occult blood per
  rectum. Intussusception develops in 1% to 5% of children with Henoch­Schönlein purpura. Henoch­Schönlein purpura is further discussed in
Chapter 133. TABLE 134­5
Infectious Causes of Bloody Diarrhea in Children
Infectious
Historical Facts Symptoms Diagnosis Treatment
Agent
Salmonella <4 y Fever Stool culture Supportive; antibiotics if enteric fever, sepsis, <3
Foodborne Abdominal pain months old, or immunosuppressed
Reptiles/Amphibians
Shigella <5 y Fever Stool WBC count Supportive; antibiotics unless very mild disease
Child care center Abdominal pain (nonspecific)
Travelers Shiga toxin
Stool culture
Yersinia Uncommon Abdominal pain Stool culture Supportive; antibiotics for neonates,
Livestock (pseudoappendicitis) immunosuppressed, sepsis, or extraintestinal transmission Fever manifestations; otherwise, clinical benefit not
Foodborne Scarlatiniform rash established
Contaminated water
Campylobacter Unpasteurized milk, Often self­limited Stool culture Supportive; antibiotics jejuni improperly cooked +/– Fever poultry Abdominal pain
Contaminated 10%–20% have water severe, prolonged, or relapsing illness
Escherichia coli Ground beef Abdominal pain Stool culture for O157:H7 Supportive; antibiotics not proven beneficial and may
(Shiga toxin) Petting zoos Fever Shiga toxin increase risk of hemolytic­uremic syndrome
Contaminated raw Hemolytic­uremic fruits syndrome
E. coli Foodborne Fever Stool cultures not helpful Supportive; antibiotics
(enteroinvasive) Contaminated water Vomiting (normal flora)
Travelers
Entamoeba Resource limited Increasing severity of Stool for ova and parasites Supportive; antibiotics followed by luminal amebicide histolytica countries diarrhea may be negative (serial
Low socioeconomic Lower abdominal testing may be necessary) status pain Stool antigen test kits
Travelers from Tenesmus endemic areas Serology with enzyme immunoassay kit
Aeromonas Warm weather Chronic diarrhea Stool culture (requires Antibiotics only in special populations hydrophila Waterborne special media)
Clostridium Recent antibiotic Pseudomembranous Stool culture not helpful Antibiotics if symptomatic difficile usage or colitis C. difficile toxin studies on Note: C. difficile can be normal flora in infants.
hospitalization Toxic megacolon diarrheal stool
(rare)
Children >5 Years Old
In children >5 years of age, juvenile polyps and infectious gastroenteritis remain common causes of LGI bleeding. Both Crohn’s disease and
 ulcerative colitis also become evident in this age group, and the incidence of these diseases is increasing. Symptoms are varied and involve multiple systems: skin lesions such as erythema nodosum and pyoderma gangrenosum; extraintestinal GI problems such as nonspecific hepatitis, cholelithiasis, sclerosing cholangitis, and pancreatitis; skeletal involvement including aseptic necrosis of bone, arthralgias, and arthritis; ocular problems with uveitis and scleritis; renal disorders such as stones and nephritis; hematologic abnormalities such as anemia, thrombocytopenia, and hypercoagulability; and general failure to thrive. Crohn’s disease is twice as common as ulcerative colitis and is characterized by abdominal pain,
 weight loss, growth failure, and anemia. Ulcerative colitis often presents with rectal bleeding, bloody diarrhea, urgency/tenesmus, and abdominal
 pain. In the acutely ill patient, diagnosis can be made with a combination of laboratory studies (blood count, erythrocyte sedimentation rate, C­
 reactive protein, albumin, liver function tests) and CT or MRI enterography. Imaging can show areas of inflammation and can identify complications
 such as abscess or perforation. Definitive diagnosis requires upper endoscopy, colonoscopy, and biopsy.
TREATMENT
Severe bleeding requires acute resuscitation and teamwork with the pediatric surgeon and/or gastroenterologist, depending on the suspected cause of bleeding. Treatment goals for UGI and LGI bleeding are: (1) resuscitation from hemorrhagic shock and restoring the intravascular volume; (2) restoring normal oxygen­carrying capacity by transfusion with packed red blood cells; (3) identifying the source of bleeding; and (4) stopping ongoing blood loss.
Management begins with an assessment of the airway, breathing, and circulation, followed by the rapid administration of serial  mL/kg crystalloid fluid boluses. If three boluses of crystalloid do not restore volume, administer  mL/kg of packed red blood cells.
Avoid overexpansion of intravascular volume, particularly if the bleeding is from varices. Correct for shock and restore urine flow, but then titrate additional fluid volume or blood administration based on estimated blood loss and response of the vital signs (Figure 134­3).
FIGURE 134­3. Initial management of GI bleeding. ABCs = airway, breathing, and circulation; RBCs = red blood cells.
UPPER GI BLEEDING
Emergency endoscopy is needed for children with moderate to severe, persistent or recurrent bleeding, and may be both diagnostic and therapeutic
(e.g., coagulation, sclerotherapy, banding).
Variceal Bleeding
For unstable patients in whom endoscopy cannot be performed, octreotide is the drug of choice for esophageal variceal bleeding. Octreotide is administered as a bolus followed by a continuous infusion (1 to  micrograms/kg bolus up to  micrograms, followed with a continuous infusion of 
,20 to  micrograms/kg/h, which may be increased hourly by  microgram/kg up to  micrograms/kg/h). The major adverse effect of octreotide is hyperglycemia, which requires monitoring of serum glucose. If octreotide is unavailable, consult with a pediatric gastroenterologist regarding the use of a vasopressin infusion (0.002 to .005 unit/kg/min titrated as needed, maximum .01 unit/kg/min). If bleeding stops for  hours, then vasopressin
 is tapered off over  to  hours. Intensive care unit admission is needed. Vasopressin use is limited by the side effects of peripheral and central
 vasoconstriction. There are limited pediatric data on the use of both octreotide and vasopressin.
Nonvariceal Bleeding
Medical treatment of bleeding from mucosal lesions, such as peptic ulcers, can include proton pump inhibitors, histamine­2 receptor antagonists,
 antacids, and sucralfate. Proton pump inhibitors are more efficacious than histamine­2 receptor antagonists. Intravenous pantoprazole, given as a
 bolus dose followed by an infusion, is used for control of active bleeding (Table 134­6).
TABLE 134­6
Pantoprazole Dosing
Patient Weight Bolus Infusion
5–15 kg  milligrams/kg/dose IV .2 milligram/kg/h IV
>15–40 kg .8 milligrams/kg/dose IV .18 milligram/kg/h IV
>40 kg  milligrams/dose IV  milligrams/h IV
If bleeding is persistent and endoscopy fails to identify a bleeding site, angiography may be indicated, although it is technically difficult in young
 children and a minimum rate of bleeding of  to  mL/min is required for diagnosis using this modality.
LOWER GI BLEEDING
Hemorrhagic shock is not common as a result of LGI bleeding. There are some important exceptions, however. Meckel’s diverticulum may result in significant blood loss in children of any age and requires surgical excision. Painless hematochezia should point to this diagnosis, and a Meckel scan is diagnostic. Definitive treatment is surgical resection. Bleeding associated with Henoch­Schönlein purpura can be severe, but resuscitation and stabilization are the mainstays of treatment. GI duplications and vascular malformations may also cause significant bleeding.
DISPOSITION AND FOLLOW­UP
The management of potential surgical abdominal emergencies such as intussusception and volvulus are discussed in Chapter 133. Children with LGI bleeding associated with abdominal pain should not be discharged from the ED until symptoms have resolved or definitive diagnosis has been made.
Small amounts of bright red blood per rectum in an otherwise healthy child or signs of chronic blood loss in well­compensated patients can be referred to a gastroenterologist for outpatient colonoscopy. Infants with suspected milk or soy protein allergy who appear well and in whom close follow­up can be arranged do not require specific therapy in the ED; dietary changes are best left to the primary care physician who will follow these patients longitudinally.
When follow­up in  to  hours can be ensured, the majority of children with mild GI bleeding can be discharged from the ED without a definitive diagnosis. Hemodynamically stable children without systemic symptoms or significant abdominal pain do not require inpatient treatment or evaluation. Conditions that can generally be diagnosed simply or presumptively in the ED and managed safely in the outpatient setting include swallowed maternal blood in the infant, Mallory­Weiss tears, gastritis, peptic ulcer disease, anal fissures, juvenile polyps, milk or soy protein allergy, and infectious gastroenteritis effectively treated with oral rehydration therapy. Stable patients with suspected inflammatory bowel disease can often have definitive diagnosis made in the outpatient setting as well.
Patients with large­volume blood loss, even with a normal hematocrit on initial evaluation, and those with associated abdominal pain in whom surgical or serious causes cannot be excluded require admission to the hospital for continued evaluation and treatment.


