## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 200: Caustic Ingestions
Nicholas J. Connors; Wallace A. Carter
INTRODUCTION
Caustics are substances that cause both functional and histologic damage on contact with body surfaces. Many household and industrial chemicals have caustic potential. Caustics are broadly classified as alkalis (pH >7) or acids (pH <7). In developed nations, increased education and product regulation (especially of acids) have decreased morbidity and mortality from caustic exposures in both adults and children. However, in
1­3  underdeveloped parts of the world, exposure to caustics remains a significant problem. Alkaline ingestions predominate in the developed world,
 whereas acid ingestions are more common in developing countries.
Caustic exposures tend to fall into three distinct groups: (1) intentional adolescent or adult ingestions with suicidal ideation; (2) unintentional ingestions (the majority of which are by curious children in the toddler age group); and (3) other incidental, often occupational or industrial contact
 exposures. The majority of reported exposures are unintentional or accidental, but intentional ingestions account for the majority of serious injuries.
The geographic variation in caustic ingestion circumstances, such as involved substances, intention, age of the patient, and extent of evaluation, make it important to base treatment decisions on each particular patient’s presentation.
Many chemicals used in industry have caustic potential (Table 200­1). Household caustics are often less concentrated forms of industrial­strength cleansers.
TABLE 200­1
Common Caustic Compounds
Compound Found In
Alkalis
Sodium hydroxide Industrial chemicals, drain openers, oven cleaners
Potassium hydroxide Drain openers, batteries
Calcium hydroxide Cement, hair relaxers, perm products
Ammonium hydroxide Hair relaxers and perm products, dermal peeling/exfoliation, toilet bowl cleaners, glass cleaners, fertilizers
Lithium hydroxide Photographic developer, batteries
Sodium tripolyphosphate Detergents
Sodium hypochlorite Bleach
Acids
Sulfuric acid Automobile batteries, drain openers, explosives, fertilizer
DownlAocaedtiec da c2id025­7­1 6:31 P YourP IrPin tiisn g1 a3n6d.1 p4h2o.t1o5gr9a.p1h2y7, disinfectants, hair perm neutralizer, pickling solution
Chapter 200: Caustic Ingestions, Nicholas J. Connors; Wallace A. Carter 
. Terms of Use * Privacy Policy * Notice * Accessibility
Hydrochloric acid Cleaning agents, metal cleaning, chemical production, swimming pool products
Hydrofluoric acid Rust remover, petroleum industry, glass and microchip etching, jewelry cleaners
Formic acid Model glue, leather and textile manufacturing, tissue preservation
Chromic acid Metal plating, photography
Nitric acid Fertilizer, engraving, electroplating
Phosphoric acid Rust proofing, metal cleaners, disinfectants
PATHOPHYSIOLOGY
The degree to which a caustic substance produces tissue injury is determined by a number of factors: pH, concentration, duration of contact, volume, and titratable acid or alkaline reserve. Acids tend to cause significant injuries at a pH <3 and alkalis at a pH >11. The physical properties of the product formulation (i.e., liquid, gel, granular, or solid) can influence the nature of the contact with tissue. Following ingestion, solid or granular caustics often injure the oropharynx and proximal esophagus, whereas liquid alkali ingestions are characterized by more extensive esophageal and gastric injuries.
Titratable acid or alkaline reserve refers to the amount of acid or base required to neutralize the agent; the greater this value, the greater is the potential for tissue injury.
Esophageal mucosal burns from caustic ingestions are classified by a visual endoscopic grading system, which correlates with risk of future complications: Grade  burns involve tissue edema and hyperemia; grade  burns include ulcerations, blisters, and whitish exudates, which are subdivided into grade 2A (noncircumferential) and 2B (deeper or circumferential) lesions; and grade  burns are defined by deep ulcerations and
 necrotic lesions. Following the initial mucosal injury, tissue remodeling occurs over roughly  months. In mild cases, normal esophageal function is restored, but in severe cases, dense scar tissue forms, resulting in stricture formation. Esophageal strictures are a source of significant morbidity and may require long­term treatments with dilations, stenting, or surgery. Early phases of remodeling, particularly days  to  after exposure, are associated with increased tissue friability and higher risk of perforation, both spontaneous and iatrogenic.
ALKALI INJURIES
Following caustic alkali exposures, the hydroxide ion easily penetrates tissues, causing immediate cellular destruction via protein denaturation and lipid saponification. This is followed by thrombosis of local microvasculature that leads to further tissue necrosis. Alkali injuries induce a deep tissue injury called liquefaction necrosis. Severe intentional alkali ingestion may cause deep penetration into surrounding tissues with resultant multisystem organ injuries, including esophageal injury, gastric perforation, and necrosis of abdominal and mediastinal structures. Severe injuries to the pancreas, gallbladder, small intestine, and mediastinum after intentional ingestion have been reported. Solid alkali ingestions, such as some lye preparations, have a greater potential for oropharyngeal and proximal esophageal tract injury and less for distal injury.
The most common household alkali is bleach, a 3% to 6% sodium hypochlorite solution with a pH of approximately . Household liquid bleach is minimally corrosive to the esophagus and rarely causes significant injury beyond grade  esophageal burns. Esophageal stricture was not observed as
 a complication of household bleach ingestion in a series involving almost 400 patients. However, ingestion of industrial­strength bleach containing much higher concentrations of sodium hypochlorite may result in gastric and esophageal necrosis. Bleach ingestion may cause emesis secondary to gastric irritation and/or pneumonitis after aspiration. Pulmonary irritation related to chlorine gas production in the stomach or when mixed with other
,9 substances may also occur. A common reaction is the production of the highly irritating chloramine gas when bleach and ammonia household
 cleaners are combined.
ACIDS
Injuries by strong acids produce coagulation necrosis. Dissociated hydrogen ions and their associated anions penetrate tissues, leading to cell death and eschar formation. This process is believed to limit continued hydrogen ion penetration and protect against deeper injury. When ingested acids settle in the stomach, gastric necrosis, perforation, and hemorrhage may result. Although it was previously thought that acids were esophagus sparing with most tissue injury concentrated in the stomach, endoscopy following an acid ingestion finds a similar incidence of gastric and esophageal
11­13  injury. Acid ingestion may be complicated by systemic absorption of acid with associated metabolic acidosis, hemolysis, and renal failure.
Hydrofluoric acid is a unique ingestion discussed in Chapter 218, “Chemical Burns” (see “Hydrofluoric Acid”).
CLINICAL FEATURES

The cardinal features of caustic ingestion are a chemical burn to the GI mucosa, sometimes associated with chemical burns to the skin or eyes from splashes or dribbling (see Chapter 217, “Thermal Burns,” and Chapter 241, “Eye Emergencies”). Pharyngeal burns from ingestion produce pain, odynophagia, drooling, and vocal hoarseness. Dyspnea may be caused by edema of the upper airway, aspiration of the caustic substance into the tracheobronchial tree, or inhalation of fumes, particularly acids. Esophageal burns produce dysphagia, odynophagia, and chest pain. Ocular burns are painful, reduce visual acuity, and produce visible damage to the anterior structures of the eye.
HISTORY
The key priority is rapid airway assessment and stabilization. Following that, obtain a directed history to determine the type, amount, and timing of the ingested caustic and the presence of co­ingestants. Determine if the ingestion was intentional or unintentional.
PHYSICAL EXAMINATION
Look for signs of respiratory distress or circulatory shock. With ingestions, look for signs of oropharyngeal injury (mucosal burns, drooling),
,15­20 respiratory injury (dysphonia, coughing, stridor, wheezing), and gastric injury (vomiting, epigastric tenderness) (Figure 200­1). Streaks of caustic burns on the face or chest are called “dribble burns” (Figure 200­2).
FIGURE 200­1. Acid ingestion. A. Moderate intraoral burns on buccal mucosa and tongue. B. Lingual burns.
FIGURE 200­2. Acid ingestion. Dermal dribble burns on upper chest.
DIAGNOSIS
21­25
Conflicting data exist on the reliability of presenting signs and symptoms to predict upper GI injuries. Intentional ingestions are associated
 with higher grades of GI tract injury, with or without clinically obvious signs. The incidence of serious GI injury after pediatric
,21­23,25,27,28 unintentional ingestions has been the focus of many studies. Although serious esophageal injury can occur in the absence of oral burns, essentially all children with serious esophageal injuries (grade  or 3) after accidental caustic ingestion have some initial signs of injury, such as stridor,
,23,25 drooling, or vomiting. Pain alone is an inconsistent predictor of severity of injury.
Assess for hemodynamic instability. Causes of shock include GI bleeding, complications of GI perforation, volume depletion, and toxicity from coingestants. Examine for peritoneal signs due to hollow viscous perforation. Consider mediastinitis in patients complaining of chest discomfort, and palpate the chest wall and neck for signs of subcutaneous emphysema. Inspect the eyes for ocular burns and the skin for splash and dribble burns.
LABORATORY TESTING
For children who unintentionally ingest common household alkalis (e.g., bleach) or acids (e.g., toilet bowl cleaner), the need for ancillary testing is only necessary in those with signs or symptoms of significant injury (e.g., drooling, respiratory distress, or vomiting). For an intentional ingestion or ingestion of a strong acid or alkali, laboratory evaluation should include a venous or arterial blood gas, electrolyte panel, hepatic profile, complete blood count, lactate, and blood type and screen. Caustic ingestions can cause an anion gap acidosis based on lactate production due to direct tissue injury or shock. Strong acid ingestions may be associated with both severe anion gap (e.g., sulfuric acid) and nongap acidoses (e.g., hydrochloric acid).
In suicidal patients, obtain acetaminophen and salicylate levels to screen for potential co­ingestants. An ECG is indicated following a hydrofluoric acid exposure to check for QT interval prolongation from hypocalcemia.
IMAGING
Obtain a chest radiograph in patients with chest pain, dyspnea, or vomiting to check for peritoneal and mediastinal air. In 2015, the World Society of

Emergency Surgery consensus conference recommended the use of IV contrasted thoracoabdominal CT scans in caustic ingestion management.
Although endoscopy has been the traditional gold standard for grading esophageal injury and predicting stricture rates, recent evidence suggests CT scans outperform endoscopy in the prediction of stricture and the need for surgical esophageal reconstruction due to the greater ability to determine
,31  the depth of injury, although conflicting results are noted and some authors see CT as a useful adjunct to endoscopy but not a replacement. US
 can be used to evaluate and follow up corrosive gastric injury if there is perforation or severe edema preventing endoscopy.
ENDOSCOPY
Endoscopy is the traditional gold standard for evaluating the location and severity of injury to the esophagus, stomach, and
,25,28,34,35 duodenum after caustic ingestion. The controversy has been who needs endoscopy and when should it be performed. Regardless of symptoms, patients with intentional caustic ingestions should undergo early endoscopy because ingestions with suicidal intent carry the highest risk of clinically important injury.
,25,28,34,35
In unintentional ingestions, particularly by children, the decision to perform endoscopy is less clear cut. Most children with serious caustic
 esophageal injury will be symptomatic, and although there is a correlation between clinical findings and corrosive severity, lack of symptoms is
,36,37 judged by some authors not to be an adequate predictor of no injury. Early endoscopy is recommended after unintentional caustic ingestions in adults and children with signs or symptoms of serious injury such as stridor or significant oropharyngeal burns
,24,25,28,34,35,37 and/or vomiting, drooling, or food refusal, with or without oropharyngeal burns.
,38­40
The primary purpose of endoscopy is diagnosis, with high accuracy for grade  injuries and less so for grade  damage when compared to
 biopsy. Early endoscopy permits grading of injuries, helps guide treatment, and predicts future morbidity (Table 200­2). Early endoscopy is safe,
 improves clinical course, and reduces costs of admission. An additional benefit of endoscopy is endoscopic guidance of an orogastric or nasogastric
 tube past injured areas of esophagus or stomach to allow enteral feeding while healing occurs. This is particularly important in children with low glycogen stores or with high­grade injuries, in whom caloric requirements will be high.
TABLE 200­2
Correlation of Esophageal Injury Grade With Morbidity and Interventions
Endoscopic Grade 
Injury Esophageal Grade 2A Esophageal Injury Grade 2B or  Esophageal Injury
Grade Injury
Future No risk of Strictures tend not to occur At risk for hemorrhage and perforation (early), strictures morbidity strictures or (delayed), and carcinoma (late) carcinoma
Nutritional Diet as If unable to tolerate PO, provide nutritional support Initiate early percutaneous feeding tube support tolerated via nasogastric, orogastric, or percutaneous feeding or tube Total parenteral nutrition or
Total parenteral nutrition
General Supportive Admission recommended, supportive care Intensive care unit admission recommended; may require interventions care additional imaging or surgical exploration for gastric injuries
Tissue friability after a caustic burn increases significantly at  to  hours after injury and is maximal between days  and , although endoscopy has
 been performed safely  days after exposure. Experts recommend that endoscopy should be performed early after ingestion, within 
,45­47 to  hours from the time of ingestion, to avoid iatrogenic perforation. Traditionally, endoscopists have terminated their examination at the first sign of severe esophageal injury (grade 2B or 3). Experienced operators using modern, smaller, and flexible endoscopes with minimal insufflation of air can usually obtain more distal visualization documenting all injuries to the esophagus, stomach, and duodenum, an
 important point in pediatric acid ingestions where gastric and duodenal burns are common.
TREATMENT
AIRWAY
The first priority is airway protection. Patients with respiratory distress may have significant oral, pharyngeal, and/or laryngotracheal injuries that require emergent airway management. Respiratory injuries from caustic ingestion can cause significant morbidity and mortality, especially in
 elderly patients. Approach caustic ingestions as difficult airways. Ideally, patients with potential airway injuries should have fiberoptic evaluation of the airway before intubation to determine the extent of the damage, but this may not always be possible.
Oral intubation with direct visualization is the first choice for definitive airway management. For potential airway compromise, establish a secure endotracheal airway early rather than risk greater difficulty later when secondary effects of injury, such as edema, complicate the situation.
Cricothyrotomy may be needed if oropharyngeal edema, tissue friability, and bleeding make intubation difficult or impossible. Blind nasotracheal intubation is contraindicated due to the potential for exacerbating airway injuries. If possible, avoid laryngeal mask airways, combination tubes with pharyngeal and tracheal balloons, retrograde intubation, and bougies because these devices and techniques can increase tissue damage or cause perforation.
DECONTAMINATION, NEUTRALIZATION, AND DILUTION
The ED staff should take precautions to prevent ongoing injury to the patient and staff from continued caustic exposure. ED staff involved should wear protective gowns, gloves, and masks with face shields. Standard decontamination, with removal of soiled or soaked clothing and copious irrigation with towels and soap (as needed), is adequate in most cases. Vomiting may reexpose the patient and staff to the caustic agent.
Gastric decontamination with activated charcoal is contraindicated if a caustic is the only ingestion. Charcoal does not adhere well to most caustics and will impede visualization when endoscopy is performed. Ipecac syrup is contraindicated, because vomiting will result in repeat
 exposure of the airway and GI mucosa to the caustic agent and could precipitate perforation.
In general, do not insert nasogastric tubes until after endoscopic evaluation. With high­grade esophageal burns, feeding tubes may be inserted under endoscopic guidance if clinically indicated. Dilution and neutralization therapy are not recommended in the prehospital setting or ED
51­54 because there is no proven human benefit and because of the potential risk of gastric distention, vomiting, and perforation.
FLUID RESUSCITATION
Establish large­bore IV access and resuscitate with crystalloids. Co­ingestants, bleeding, and third spacing, as well as metabolic disarray from acid­base derangements, can lead to shock. Central venous access may be required for monitoring of resuscitation.
SYSTEMIC STEROIDS AND PROPHYLACTIC ANTIBIOTICS
55­63
There is controversy concerning the benefit of systemic steroids in caustic ingestions. The ability of steroids to inhibit the inflammatory response led to the hypothesis that steroids may decrease stricture formation after caustic ingestion, and animal models have suggested benefit. One prospective human trial found statistically significant protection against the development of stricture formation in grade 2B lesions, and
,63 corticosteroids are recommended by some international treatment guidelines. A subsequent pooled meta­analysis has not shown benefit for
 ,57 injury, and steroids may increase the risk of infection, perforation, and hemorrhage. Use has been discouraged by other experts. One criticism of pooled meta­analysis data is that some individual studies did not clearly distinguish between grade  and 2A lesions, which do not typically lead to
 strictures, and grade 2B and  injuries, which might theoretically benefit from steroids.
There is no current evidence to support the ED administration of prophylactic antibiotics after caustic ingestions in humans. However, in protocols in which steroids are used or in grade 2B or  injury, addition of penicillin or another antibiotic that covers oral flora has been part of the treatment
,64 regimen.
SURGERY AND ESOPHAGEAL STENTING AND DILATION
65­70
Major ingestions of caustic agents may result in perforation of the GI tract or extensive tissue necrosis requiring emergency surgery. Laparotomy is generally preferred over laparoscopic evaluation for posterior gastric visualization. The indications for emergency surgery include esophageal perforation, peritoneal signs, or free intraperitoneal air. Large­volume ingestions (>150 mL), signs of shock, respiratory distress, persistent lactic
 acidosis, ascites, and pleural fluid may be other indications for surgical exploration.

For grade 2B and  injuries without obvious perforation, recommendations include a period of esophageal rest, early gastrostomy for enteral
,72 73­76 feeding, and dilation therapy (in the first  weeks) with or without stenting. Once strictures form, they may be difficult to treat and require
 stenting and/or multiple balloon dilatations or bouginage. Controversy exists about the most appropriate treatment for esophageal stricture (i.e.,
75­78 long­term repetitive dilation therapy versus surgery).
TREATMENT OF SYSTEMIC TOXICITY
Morbidity or death from alkali injuries usually results from the complications of direct tissue necrosis, but acid ingestions may result in additional
 systemic toxicity from absorption of the acid. Acid­base disorders (increased anion gap or normal anion gap acidosis depending on acid ingested), hemolysis, coagulopathy, and renal failure may result. Acute lung injury (noncardiogenic pulmonary edema) may follow caustic ingestions as a complication of local or systemic effects.
NUTRITIONAL SUPPORT
Nutritional support is often necessary following a severe caustic injury to the esophagus or stomach. Support can be achieved by percutaneous
,79
(usually jejunostomy) feeding, nasoenteral feeding, or total parenteral nutrition.
EXPERIMENTAL THERAPIES
Animal experiments have found that drugs affecting collagen deposition, including interferon­α­2b, octreotide, β­aminopropionitrile, colchicine, N­
,80,81 acetylcysteine, D­penicillamine, and polaprezinc, can prevent or treat esophageal strictures after caustic ingestion. Pentoxifylline, a local inflammatory and microcirculation mediator, has experimental benefit. Mitomycin C, a fibroblast proliferation inhibitor, has been used topically on
 strictures with some success. Oral agents to coat and protect the GI tract from insult, including sucralfate, bismuth subsalicylate, and sodium polyacrylate, are beneficial in animal experiments. None of these agents have been evaluated in controlled human clinical trials, and no specific
 recommendation can be made regarding their use. H blockers and proton pump inhibitors are often used in the treatment protocols, but no
 evidence supports or refutes their use.
COMPLICATIONS AND PROGNOSIS
,83
Short­term prognosis is worse with grade  GI injury, systemic complications, and age >65 years. Most long­term sequelae from caustic exposure are related to injuries to the GI tract. Acid ingestions may scar the pylorus and result in gastric outlet obstruction. Caustic alkali ingestions may cause esophageal strictures that may result in dysphagia, odynophagia, and malnutrition. Persistent drooling, reluctance to eat, severe oropharyngeal
 burns, and persistent fever correlate with the development of esophageal stricture after unintentional caustic ingestion in children.
Patients with grade  caustic injuries to the esophagus have about a 1000­fold increased risk for squamous cell cancer of the esophagus, which can
 occur decades after the initial ingestion and resulting esophageal injury. Because cancer can develop if a portion of the esophagus remains after
 reconstructive surgery for esophageal stricture, total removal of the esophagus is recommended.
DISPOSITION AND FOLLOW­UP
Asymptomatic patients with low­risk ingestions and no signs of drooling, stridor, or vomiting and who tolerate food or drink may be discharged from the ED after a period of observation. Admit all patients with symptomatic caustic ingestions. Patients with grade  injuries can be discharged from hospital after endoscopy, provided they can tolerate oral fluids and food. Grade 2A injuries warrant hospitalization to ensure that symptoms and injury do not progress. Grade 2B and  injuries are significant, require enteral or parenteral nutrition, and have an early risk for bleeding or perforation;
 admit these patients to an intensive care unit. Contact the regional poison control center for data collection purposes and assistance with management.
SPECIAL CONSIDERATIONS
LAUNDRY DETERGENT POD INGESTIONS
Laundry detergent pods, also known as capsules, liquitabs, or sachets, have long been available in Europe and were introduced to the U.S. market
,88 in 2010. Each pod contains concentrated detergent within a dissolvable plastic membrane. An individual pod may have internal chambers that contain a stain remover and brightener separate from the detergent. Exposure to the concentrated preparation in these pods is more likely to produce
,90 symptoms than exposure to traditional laundry detergent products.
Dermal or ocular exposure to the contents can produce irritation of the skin, conjunctiva, or cornea. Ingestion by young children can produce
,92 serious toxicity with profuse vomiting, respiratory distress, and neurologic depression. The etiology of these systemic symptoms is
 unknown. Caustic injury to the pharynx and esophagus can produce difficulty swallowing with drooling and aspiration during recovery. Treatment is supportive with airway protection and mechanical ventilation. In severe cases, ventilation may be required for days.


