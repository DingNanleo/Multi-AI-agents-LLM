## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 109: Resuscitation of Children
William E. Hauda, II
INTRODUCTION AND EPIDEMIOLOGY
The resuscitation of children differs from that of adults in a number of important ways. Respiratory failure and shock are more common causes of arrest among children and infants than adults; hypoxemia, hypercapnia, and acidosis subsequently lead to bradycardia, hypotension, and secondary
 cardiac arrest in children. Overall survival and neurologically favorable survival rates in children are .3% and .1%, respectively, in the United States.

Survival rates to discharge after resuscitation from cardiac arrest are greatest among perinatal children (25%) and adolescents (17.3%). Infancy, unwitnessed arrest, and initial asystolic rhythm are associated with poor survival rates. The best chance for a good outcome is to recognize impending respiratory failure or shock and intervene to prevent the development of cardiopulmonary arrest.
Age­related differences are important considerations when treating children. An appropriate drug dose for a 6­month­old infant may be excessive for a
1­month­old newborn but inadequate for a 5­year­old child. Because other aspects of resuscitation, such as endotracheal tube size, tidal volumes, cardiac compression rates, and respiratory rates, vary with a child’s age, equipment selection and medication dosing require specific determination for each child. Valuable time cannot be lost in weight estimation, dosage calculations, and equipment selection. Equipment can be stored on shelves or in drawers labeled by age and weight, or a system of color codes can be used in which color­coded shelves, carts, or equipment organizers correspond to specific length categories, as illustrated in Figure 109­1. FIGURE 109­1. The Broselow® resuscitation tape. [Broselow® tape; Armstrong Medical Industries, Inc., Lincolnshire, IL.]
BASIC LIFE SUPPORT
The American Heart Association guidelines use the following age group delineations: newborn,  month or less in age; infant,  month to  year of age;
 and child,  year of age to the onset of puberty. As in adults, the priorities of resuscitation are airway, oxygenation, ventilation, and shock management (Figure 109­2, A and B). Initial basic life support sequence can be initiated with either an airway­breathing­circulation sequence or a circulation­airway­breathing sequence, with circulation­airway­breathing achieving earlier chest compressions but airway­breathing­circulation
,4 achieving earlier ventilation. To simplify the action sequence, the European Resuscitation Council recommends using the airway­breathing­
 circulation sequence for basic life support assessment but recommends starting with chest compressions if no pulse is present. The American Heart
Association Guideline Update in 2015 recommends “initiating CPR with C­A­B [circulation­airway­breathing] over A­B­C [airway­breathing­circulation]
 sequence (Class IIb).” Cardiopulmonary arrest should be prevented whenever possible with prompt recognition of and intervention for compromised
 physiology. International consensus guidelines for basic life support procedures are listed in Table 109­1. FIGURE 109­2. A. Pediatric basic life support (BLS) algorithm for a single rescuer. B. Pediatric BLS algorithm for multiple rescuers. AED = automated external defibrillator; ALS = advanced life support. [Reprinted with permission Web­based Integrated 2010 & 2015 American Heart Association Guidelines for

CCPhRa p&t eErC 1C0 P9a: rRt 1e1s:u Psecditaiattiorinc Bofa Csich iLldifree Snu, pWpiolliratm & CEP. RH Qauudaali,t yII ©2015 American Heart Association, Inc.] 
. Terms of Use * Privacy Policy * Notice * Accessibility
TABLE 109­1
Guidelines for Pediatric Basic Life Support7
Child  Y to Onset of Puberty
Maneuver Newborn Infant <1 Y
Puberty to Adult
Airway Head tilt/chin lift Head tilt/chin lift Head tilt/chin lift Head tilt/chin lift
If trauma Jaw thrust Jaw thrust Jaw thrust Jaw thrust
If foreign body– Suction Back blows and chest thrusts Abdominal thrusts Abdominal thrusts conscious
If foreign body– Suction Chest compressions Abdominal thrusts Abdominal thrusts unconscious
Breathing rate 30–60/min (every 1–2 s) 12–20/min (every  s) 12–20/min (every  s) 10–12/min (every  s)
Circulation
Pulse check Umbilical Brachial Carotid or femoral Carotid or femoral
Compression
Location One finger below One finger below intermammary line or lower Lower half of sternum Lower half of
Method intermammary line half of sternum Heel of one hand or sternum
Depth Two fingers or two Two fingers or two thumbs two hands Two hands
Rate thumbs One third to one half of chest One third to one half One third of chest
One third of chest 100/min of chest 100/min
120/min 100/min
Compression­to­ 3:1 15:2 (single rescuer–30:2) 15:2 (single rescuer– 30:2 ventilation ratio 30:2)
CHOKING AND FOREIGN­BODY MANAGEMENT
The back blow and chest thrust are recommended maneuvers to clear an infant’s airway. The American Heart Association specifically discourages two common maneuvers used with adult patients: (1) do not use the “Heimlich maneuver” for patients <1 year old, because of the potential for injury to abdominal organs; and (2) do not use blind finger sweeps, because of the possibility of pushing the foreign body farther into
,7 the airway.
CONSCIOUS CHILDREN
A child who is choking but can maintain some ventilation or vocalization should be allowed to clear the airway by coughing. Once a child cannot cough, vocalize, or breathe, a sequence of steps must be instituted immediately. Choking infants are treated with an alternating sequence of five
 back blows and five chest thrusts. With the infant’s torso positioned prone and head down along the rescuer’s arm, or the older child draped prone and head down across the rescuer’s knees, deliver five blows to the interscapular area (Figure 109­3). Then reposition the infant supinely along the rescuer’s arm, or place the larger infant on the floor, as for external cardiac compression, and deliver five chest thrusts (cardiac compressions; Figure 109­4). Continue this sequence until the airway obstruction is relieved or the child becomes unconscious. In children beyond infancy, use the obstructed airway (“Heimlich”) maneuver, with the rescuer kneeling or standing behind the child. Place the rescuer’s clenched fist at the level of the umbilicus and deliver firm upward thrusts until the obstruction is cleared or the child becomes unconscious.
FIGURE 109­3. Back blows to clear airway of choking infant. [Image used with permission of Rita K. Cydulka, MD, MS, MetroHealth Medical Center.]
FIGURE 109­4. Chest thrusts to clear airway of choking infant. [Image used with permission of Rita K. Cydulka, MD, MS, MetroHealth Medical Center.]
UNCONSCIOUS CHILDREN

If a child loses consciousness due to a presumed airway obstruction, begin chest compressions immediately. After  compressions, open the airway and look for a foreign body in the mouth. Attempt to deliver two rescue breaths. If successful, then check for a pulse. If the obstruction is still present, then continue with alternating cycles of compressions and attempted rescue breaths until the obstruction is relieved. Chest compressions will circulate blood after a loss of perfusion and may relieve the obstruction. After each cycle and before each attempt at ventilation (lone rescuer:  to ; two rescuers:  to 2), inspect the airway to see if an object is present and remove visible objects. Do not perform blind finger sweeps.
The foregoing recommendations are directed primarily at first responders or healthcare providers who have neither access to nor the skills to use airway management equipment. For unconscious children in EDs, direct laryngoscopy, visualization, and removal of the foreign body with McGill forceps can be attempted. Until this equipment is ready, use basic life support techniques.
AIRWAY
Management of the pediatric airway including anatomic considerations, positioning, and basic and advanced adjuncts is discussed in detail in Chapter
113, “Intubation and Ventilation in Infants and Children.”
BREATHING
MOUTH TO MOUTH
The size of the child dictates whether to use mouth­to­mouth or mouth­to­mouth­and­nose ventilation. The rate of ventilation is shown in Table 109­1. Make sure the breaths are effective by observing chest rise with each breath.
BAG­VALVE MASK
The self­inflating bag­valve mask system is most commonly used for ventilation. Ventilation bags used for infants and children should have a
 minimum volume of 450 mL, and those used for older children and adolescents should have a minimum volume of 1000 mL.
Pediatric lung compliance is very good, and children can tolerate relatively high pressures. Pneumothoraces usually result from the administration of excessive tidal volume rather than from high pressures. Start ventilation with the smallest volume that causes adequate chest rise, and give each breath slowly, over approximately  second. Carefully monitor the rate of ventilation to avoid excessive hyperventilation.
OXYGEN
It is reasonable to provide 100% oxygen during CPR; however, once circulation has been restored, studies suggest improved outcomes when normal
,7­10 arterial oxygen and carbon dioxide levels are maintained. Wean oxygen to maintain saturations of at least 94% and ensure eucapnia.
END­TIDAL CARBON DIOXIDE

End­tidal capnography has been considered a tool for assessing quality of chest compressions and recognizing excessive ventilation. No studies are available to show an improved outcome in children with targeted end­tidal carbon dioxide monitoring or a specific value for end­tidal carbon dioxide
 level to target in children.
CIRCULATION
Begin cardiac compression in the absence of pulse or with poor perfusion (heart rate ≤60 beats/min). Place patients on a hard surface to improve the effectiveness of compressions. Perform compressions over the lower sternum ensuring adequate rate and depth (Table 109­1). Failure to deliver
 compressions with sufficient force to depress the chest is common even among healthcare providers. Palpate pulses during compression to assess the adequacy of the compression depth and rate. Pause chest compressions for bag­valve mask ventilation, but only long enough to deliver effective breaths; once an advanced airway is established, deliver chest compressions continuously without pause for ventilations.
INFANTS
Use the two­thumb technique when two healthcare providers are present. Compress at a rate of at least 100 per minute. The compression­toventilation ratio is 15:2 for two healthcare providers performing CPR on an infant. If the patient is intubated, then compressions and ventilations may be performed without synchronization, but the rate of compressions should be maintained at 100 per minute. The chest should not be squeezed by
 the hands, but the sternum should be depressed by the thumbs.
CHILDREN  YEAR OLD TO THE ONSET OF PUBERTY
Compress the lower half of the sternum with the heel of one hand. If unable to adequately depress the sternum with one hand, then use the two­hand technique. The rate of compression is at least 100 compressions per minute. If there are two healthcare providers, then perform compressions in a series of 15:2 compressions to ventilations. If there is only one healthcare provider, perform  compressions for every  ventilations. If the patient is intubated, then compressions and ventilations may be performed without synchronization, but keep the rate of compressions at 100 per minute.
CHILDREN AFTER PUBERTY (ADOLESCENTS)

Children who are of pubertal age or older are treated as adults with respect to basic life support. Use the two­hand technique of chest compressions.
The compression­to­ventilation ratio and rate of compressions are the same as with children, 15:2 for two­person CPR and 30:2 for one­person CPR with a rate of 100 compressions per minute.
VASCULAR ACCESS
Difficulty in obtaining rapid IV access is certainly one of the major differences between adult and pediatric resuscitation. Keep several important facts in mind. First, a significant portion of children respond to airway management alone because most cardiac arrests in children are secondary to hypoxia from respiratory arrest. Airway management and ventilation have priority over vascular access; time spent on obtaining vascular access should be
 limited. Intraosseous infusion and fluid administration are quick, safe routes for resuscitation drugs (see Chapter 114, “Vascular Access in Infants and
Children”). If vascular access cannot be obtained but the child is intubated, use the tracheal route to administer drugs, such as lidocaine,epinephrine, atropine, and naloxone (mnemonic: LEAN). Although the ideal endotracheal doses for drugs other than epinephrine have never been studied in children, current recommendations support the use of two to three times the respective IV dose (Table 109­2).
TABLE 109­2
Drugs for Pediatric Resuscitation8
Drug Pediatric Dosage Remarks
Adenosine IV/IO: .1 milligram/kg, followed by 2–5 Maximum single dose:  milligrams first dose,  milligrams second dose.
mL NS flush
Double dose and repeat once, if needed
Amiodarone IV/IO:  milligrams/kg over 20–60 min; Maximum bolus repetition to  milligrams/kg/d. Use lowest effective dose.
then 5–15 micrograms/kg/min infusion Bolus may be given more rapidly in shock states.
Atropine IV/IO: .02 milligram/kg, repeat in  min Maximum single dose: .5 milligram (child) and .0 milligram (adolescent).
(minimum single dose is .1 milligram) Maximum cumulative dose: .0 milligram (child) and .0 milligrams (adolescent).
Endotracheal: .04–0.06 milligram/kg Not routinely recommended. Use for bradycardia in the setting of suspected increased diluted with NS to 3–5 mL vagal tone or primary heart block.
Calcium IV/IO:  milligrams/kg (maximum dose Not routinely recommended. Use in documented hypocalcemia, calcium channel–blocker chloride  grams) overdose, hypermagnesemia, or hyperkalemia. Administer slowly.
(10%)
Epinephrine Bradycardia: Maximum dose:  milligram IV/IO; .5 milligrams ETT.
IV/IO: .01 milligram/kg (0.1 mL/kg of Unlike other agents, epinephrine per endotracheal tube is 10× the IV dose.
1:10,000) Follow endotracheal dose with several positive­pressure ventilations.
Endotracheal: .1 milligram/kg (0.1 No evidence for high­dose parenteral epinephrine (may worsen outcomes).
mL/kg of 1:1000)
Pulseless arrest:
IV/IO: .01 milligram/kg (0.1 mL/kg of
1:10,000)
Endotracheal: .1 milligram/kg (0.1 mL/kg of 1:1000)
Glucose IV/IO: D W preferred (5 mL/kg) through small guage IV as higher dextrose concentrations may be

Newborn:  mL/kg D W
 sclerotic to peripheral IVs. Higher dextrose concentrations may be given through IO if needed.
Infants and children:  mL/kg D W

Adolescents:  mL/kg D W

Lidocaine IV/IO: .0 milligram/kg bolus
Endotracheal: double IV dose and dilute with NS to 3–5 mL
Naloxone IV/IO: If <5 y or ≤20 kg: .1 milligram/kg Titrate to desired effect.
If >5 y and >20 kg: .0 milligrams
Sodium IV/IO:  mEq/kg (1 mEq/mL) Not routinely recommended. Infuse slowly and use only if ventilation is adequate for bicarbonate tricyclic antidepressant overdose and hyperkalemia.
Abbreviations: D W = 10% dextrose in water; D W = 25% dextrose in water; D W = 50% dextrose in water; ETT = endotracheal tube; NS = normal saline.

FLUIDS

If hypotension is due to volume depletion, give isotonic fluid boluses of  mL/kg as rapidly as possible and repeat as needed. Use a syringe attached to a three­way stopcock and extension tubing to rapidly deliver aliquots of fluid, until the entire bolus is administered. This method is far superior to the use of gravity or pressure bags.
Deliver the bolus in <20 minutes and more rapidly, if possible. Reassess the child’s condition after each bolus. If blood pressure normalizes, maintain fluid administration at the minimum rate to keep the vein open or at a rate to compensate for ongoing fluid losses. If hypotension persists despite volume repletion, consider a pressor agent.
Always use a pediatric microdrip assembly when resuscitating children to prevent accidental overhydration and for easy monitoring of the total volume given. It is easy to overhydrate infants and children, even when IV lines are set to keep the vein open, if adult equipment is used for children.
WEIGHT ESTIMATION AND MEDICATION CALCULATIONS
Proper dosage of medications in children requires knowledge of the patient’s weight, knowledge of the dose (usually given in milligrams per kilogram), and error­free calculation and delivery. Use of charts with precalculated drug doses or electronic calculators can reduce dosage errors (Tables 109­2
 and 109­3).
TABLE 109­3
Calculation for Dosage of Medications Delivered by Constant Infusion Using the Rule of 
Continuous Conversion
Drug Delivery
Infusion Dose Factor
Epinephrine .1–1.0 .6 milligram  mL/h = .1 microgram/kg/min × wt (kg) microgram/kg/min
Dobutamine 2–20  milligrams  mL/h = .0 micrograms/kg/min × wt (kg) microgram/kg/min
Dopamine 2–20  milligrams  mL/h = .0 micrograms/kg/min × wt (kg) microgram/kg/min
Norepinephrine .1–2.0 .6 milligram  mL/h = .1 micrograms/kg/min × wt (kg) microgram/kg/min
Lidocaine 20–50   mL/h =  micrograms/kg/min milligrams × micrograms/kg/min wt (kg)
Nitroprusside .5–8  milligrams  mL/h = .0 micrograms/kg/min × wt (kg) microgram/kg/min
Isoproterenol .1–1.0 .6 milligram  mL/h = .1 microgram/kg/min × wt (kg) microgram/kg/min
Dosage of medications delivered by constant infusions is calculated in terms of micrograms per kilogram per minute. Actual calculation can be confusing and a source of lethal decimal errors. The rule of  can be used for dopamine and dobutamine to simplify dosage calculation:
The medication is mixed in an IV set with a measured chamber and a microdrip (1 drop/min  milligrams × wt
=  mL/h). Rate of administration is best set by an electric pump. (kg), fill to 100 mL with D W

Example: For a 10­kg infant requiring dopamine  milligrams ×  =
 milligrams dopamine
In a measured chamber, fill to 100 mL with D W. Weight is now factored in so that:  mL/h = 
 microgram/kg/min
 mL/h =  micrograms/kg/min
 mL/h =  micrograms/kg/min
For epinephrine and isoproterenol, the rule of  is: .6 milligram × wt
(kg), fill to 100 mL with D W

 mL/h = .1 microgram/kg/min
 mL/h = .5 microgram/kg/min
Abbreviations: D W = 5% dextrose in water; wt = weight.

Other methods to reduce medication errors during resuscitation include reformulating drug preparations so that all children receive .1 mL/kg
 regardless of the medication, limiting the number of concentrations of medication available, and using standardized medication reference tables.
To calculate the proper drug dosage from the table, accurately determine the child’s weight. Because it is often not possible to weigh a child during resuscitation, several alternative methods are available for estimating a child’s weight, but each of these has inherent challenges and problems

(Tables 109­4 and 109­5) with errors occurring in all techniques.
TABLE 109­4
Estimating Weight in Infants and Children
Formulas by name Argall (Years + 2) × 
Luscombe (Years × 3) + 
Advanced Pediatric Life Support Infants: (age in months × .5) + 
Children 1–5 y: (2 × age in years) + 
Children 6–12 y: (3 × age in years) + 
Nelson <12 mo: (months + 9)/2
1–6 y: (years × 2) + 
7–12 y: (years × 7) − 
Best Guess <12 mo: (months + 9)/2
1–4 y: (years + 5) × 
5–14 y: (years × 4)
Formulas by age Infants (Months + 9)/2
 to  or  y (Years × 2) + (7, , or 10)
Or
(Years × 3) + 
 or  to  or  y (Years × 2) + 
Or
(Years × 3) + 
Or
Years × 
Or
(Years × 5) − 
TABLE 109­5
Body Weight Estimation by Age
Age Weight (kg) Estimation
Term infant .5 Birth weight
 mo   × birth weight
 y   × birth weight
 y  One­fourth adult weight of  kg
 y  One­half adult weight
LENGTH­BASED ESTIMATION
Systems based on a direct measurement of a patient’s length have been developed for estimating weight, determining dosages, and selecting equipment in pediatric emergencies (Table 109­6). The use of a length­based system is currently included in the American Heart Association Pediatric

Advanced Life Support Course. These systems use a tape measuring device (such as the Broselow® tape; Armstrong Medical Industries, Inc.,
Lincolnshire, IL) to assist in making appropriate selections, with some systems incorporating body habitus to improve accuracy (such as the Paediatric
Advanced Weight Prediction in the Emergency Room). Most tapes are two­sided and display emergency resuscitation drug dosage and equipment selection based on length (Figure 109­1).
TABLE 109­6
Length­Based Equipment Chart (Length = Centimeters)* Item 54–70 70–85 85–95 95–107 107–124 124–138 138–155
Endotracheal tube size .5 .0 .5 .0 .5 .0 .5
(mm)
Lip–tip length (mm) .5 .0 .5 .0 .5 .0 .5
Laryngoscope  straight  straight   straight or  straight or 2–3 straight or  straight or straight curved curved curved curved
Suction catheter 8F 8F–10F 10F 10F 10F 10F 12F
Stylet 6F 6F 6F 6F 14F 14F 14F
Oral airway Infant/small Small child Child Child Child/small Child/adult Medium adult child adult
Bag­valve mask Infant Child Child Child Child Child/adult Adult
Oxygen mask Newborn Pediatric Pediatric Pediatric Pediatric Adult Adult
Vascular access (gauge)
Catheter 22–24 20–22 18–22 18–22 18–20 18–20 16–20
Butterfly 23–25 23–25 21–23 21–23 21–23 21–22 18–21
Nasogastric tube 5F–8F 8F–10F 10F 10F–12F 12F–14F 14F–18F 18F
Urinary catheter 5F–8F 8F–10F 10F 10F–12F 10F–12F 12F 12F
Chest tube 10F–12F 16F–20F 20F–24F 20F–24F 24F–32F 28F–32F 32F–40F
Blood pressure cuff Newborn/infant Infant/child Child Child Child Child/adult Adult
*Directions for use: (1) measure patient length with centimeter tape; (2) using measured length in centimeters, access appropriate equipment column.
Source: Reproduced with permission from Luten RC, Wears RL, Broselow J, et al: Length­based endotracheal tube sizing and emergency equipment for pediatric resuscitation. Ann Emerg Med 21: 900, 1992, ©1992, Elsevier, Philadelphia, PA. Copyright Elsevier.
®
The length­based systems may not be accurate in all populations of children. The Broselow tape has been shown to underestimate and overestimate weights and may not be as accurate as newer systems such as the Mercy method and the Paediatric Advanced Weight Prediction in the Emergency

Room tape. Although length­based systems for weight estimation have limitations, their use in EDs provides a very rapid tool during a critical resuscitation.
AGE­BASED ESTIMATION
There are several formulas based on a child’s age that have been developed to assist in estimating a child’s weight (Tables 109­4 and 109­5). Age­based formulas have challenges in application based on requiring calculations and the accuracy of the estimation and whether the estimation is closer to
 actual body weight or ideal body weight. Although many clinicians still recall and use these formulas, some authors consider these formulas
,17 historical curiosities and feel they should no longer be relied upon for estimating a child’s weight during a critical resuscitation.
HEALTHCARE PROVIDER ESTIMATION

Estimations by healthcare providers without using a specific tool are quite variable. Healthcare providers should not rely on a visual estimation of the child’s weight, but must use some tool in estimating a child’s weight for all resuscitation medications.
PARENTAL ESTIMATION

Parental estimations of a child’s weight are often as accurate as length­based devices. A recent study, however, suggests that parental estimates of a
 child’s weight may underestimate weight in over 50% of obese children and nearly 15% of normal body habitus children.
PHARMACOLOGIC AGENTS
The pharmacology of resuscitation drugs has been well described in other chapters (see Chapter , “Pharmacology of Antiarrhythmics and
Antihypertensives,” and Chapter , “Pharmacology of Vasopressors and Inotropes”), but a few peculiarities pertain to pediatric resuscitation drug use.
EPINEPHRINE
20­22
Epinephrine is the one drug universally used in cardiac arrest; however, its beneficial effect on survival remains questionable. It is specifically indicated for hypoxia­ or ischemia­induced slow heart rates that fail to respond to adequate oxygenation and ventilation and for pulseless arrest situations (i.e., asystole, pulseless electrical activity, and ventricular fibrillation). If the initial dose of epinephrine is not effective, give subsequent doses at the same dose. High­dose epinephrine (0.1 milligram/kg of the 1:1000 concentration) for resuscitation in infants and children does not
 increase survival. The American Heart Association currently recommends that subsequent doses of epinephrine be at the standard dose. High­dose epinephrine may be useful in catecholamine­resistant states, such as anaphylaxis, alpha­ or beta­blocker overdose, or severe sepsis. Adverse effects associated with the use of high­dose epinephrine include intracranial hypertension, myocardial hemorrhage, myocardial necrosis, and a
 postresuscitation hyperadrenergic state.
Epinephrine, rather than dopamine, is the vasopressor infusion of choice in children (Table 109­3) because dopamine requires release of endogenous norepinephrine. In children with cardiac arrest, norepinephrine stores may be low. There is no evidence to recommend use of vasopressin over epinephrine in children.
AMIODARONE
Amiodarone can treat atrial and ventricular arrhythmias and is currently included in the algorithm for ventricular fibrillation and pulseless ventricular
 tachycardia, with expert consultation strongly recommended prior to administration. Dosage for pediatric patients is  milligrams/kg over
 to  minutes and may be repeated to a maximum of  milligrams/kg per day. Administer amiodarone rapidly for ventricular tachycardia or ventricular fibrillation resistant to electrical cardioversion. Lidocaine may be used instead of amiodarone in ventricular fibrillation or pulseless
 ventricular tachycardia, although neither medication appears to be significantly associated with survival to hospital discharge after cardiac arrest.
Avoid amiodarone if there is the potential for a long QT syndrome either due to a primary cardiac dysrhythmia or medication administration or overdose, because amiodarone prolongs the QT interval and its administration may cause irreversible dysrhythmias in these circumstances.
ATROPINE
Atropine is used for treatment of symptomatic bradycardias associated with increased vagal tone or first­degree heart block in the absence of reversible causes (Class IIa). Epinephrine remains the first­line treatment for symptomatic bradycardia after adequate oxygenation and ventilation. When used, the recommended dose of atropine is .02 milligram/kg IV. Maximum single doses are .5 milligram for children and .0 milligram for adolescents. A minimum dose of .1 milligram of atropine is no longer recommended for premedication for emergency intubation but
 should still be given when used to treat symptomatic bradycardia. The dose may be repeated once, with maximum total doses of .0 milligram for children and .0 milligrams for adolescents. Additional doses are unlikely to be beneficial as the maximum recommended dose is considered fully vagolytic. If no response to atropine is seen, then dosing beyond the vagolytic amount is unlikely to be effective. If an effect is seen but not maintained, additional doses can be given. Large doses of atropine are needed to treat exposure to organophosphates or nerve agents.
SODIUM BICARBONATE
Bicarbonate therapy has a primary role in treating overdoses of sodium channel–blocking agents, such as procainamide, flecainide, and tricyclic antidepressants (Class IIa). It has an uncertain utility in calcium channel–blocker overdoses (Class Indeterminate). Because other resuscitation drugs are less effective in the face of severe acidosis, sodium bicarbonate may be useful during prolonged resuscitations, although its routine use in cardiac arrest is not recommended (Class III). Adverse effects of bicarbonate include reducing systemic vascular resistance (thereby lowering coronary perfusion pressure), inhibiting oxygen release (by shifting the oxyhemoglobin dissociation curve), inducing hypernatremia and hyperosmolality, inactivating simultaneously administered catecholamines, and paradoxical worsening of intracellular acidosis (by the production of carbon dioxide, which diffuses rapidly through cell walls). An initial dose of  mEq/kg IV is given only after adequate ventilation has been established. Without adequate ventilation, the child cannot compensate for the release of carbon dioxide by buffering the hydrogen ions, and the adverse effects of bicarbonate therapy surpass any beneficial effects. In neonates or premature infants, dilute sodium bicarbonate 1:1 with sterile water, not saline, to reduce the hyperosmolarity of the solution.
CALCIUM
Routine calcium administration is not recommended during resuscitation because of lack of proven efficacy and because of
 possible harmful effects. Calcium should be used for documented and symptomatic hyperkalemia, hypocalcemia, hypermagnesemia, and
 calcium channel–blocker overdose. Ionized calcium levels should be used to direct calcium administration, but outcomes of ICU patients do not
 appear to be affected by ionized calcium level normalization. Calcium may be given as calcium gluconate,  to 100 milligrams/kg (0.6 to .0 mL/kg of a 10% solution) or calcium chloride,  milligrams/kg (0.2 mL/kg of a 10% solution), via the IV or IO route. Calcium gluconate is less tissue toxic than calcium chloride in the case of extravasation.
DYSRHYTHMIAS
Dysrhythmia are discussed in detail in Chapter 130, “Syncope, Dysrhythmias, and ECG Interpretation in Children.” Ventricular fibrillation is
 an unusual presenting rhythm in infants and children. Children presenting with an unshockable rhythm rarely develop a subsequent shockable
 rhythm during the resuscitation. Because rhythm disturbances are usually secondary to hypoxia and not primary cardiac events, first provide ventilation and oxygenation, and correct hypoxia, acidosis, and fluid balance. If medications such as epinephrine are administered, they are probably most effective when given  to  minutes before a defibrillation attempt.
A child with an abnormal cardiac rhythm or rate, coupled with evidence of poor end­organ perfusion (e.g., cyanosis, mottled skin, lethargy) is unstable and requires immediate intervention. Figures 109­5, 109­6, and 109­7 summarize the approach to unstable cardiac rhythms in children, and Table

109­7 lists the weight­based electrical dose when cardioversion or defibrillation is indicated.
FIGURE 109­5. Pediatric pulseless arrest decision tree. ET = endotracheal; PEA = pulseless electrical activity; pVT = pulseless ventricular tachycardia; VF = ventricular fibrillation; VT = ventricular tachycardia. [Reprinted with permission Web­based Integrated 2010 & 2015 American Heart Association Guidelines for CPR
& ECC Part 12: Pediatric Advanced Life Support ©2015 American Heart Association, Inc.]
FIGURE 109­6. Pediatric bradycardia decision tree. ABC = airway, breathing, circulation; AV = atrioventricular; HR = heart rate. [Reprinted with permission Web­based
Integrated 2010 & 2015 American Heart Association Guidelines for CPR & ECC Part 12: Pediatric Advanced Life Support ©2015 American Heart
Association, Inc.]
FIGURE 109­7. Pediatric tachycardia decision tree for infants and children with rapid rhythm and poor perfusion. HR = heart rate. [Reprinted with permission Webbased Integrated 2010 & 2015 American Heart Association Guidelines for CPR & ECC Part 12: Pediatric Advanced Life Support ©2015 American Heart
Association, Inc.]
TABLE 109­7
Energy Requirements for Defibrillation and Cardioversion
Initial
Rhythm Type of Shock Subsequent Doses
Dose
Ventricular fibrillation or pulseless ventricular tachycardia Defibrillation  J/kg  J/kg to maximum of  J/kg or
(unsynchronized) adult dose
Unstable supraventricular tachycardia or ventricular tachycardia with pulse Synchronized .5–1  J/kg but poor perfusion cardioversion J/kg
The most common rhythms seen in pediatric arrest are the bradycardias, which lead to asystole if untreated. Again, treatment consists of maximizing oxygenation and ventilation.Begin chest compression in children with a heart rate <60 beats/min and signs of poor perfusion and administer epinephrine (Figure 109­6).
Differentiating a rapid secondary sinus tachycardia from a rapid primary cardiac tachycardia can be difficult but is critical to patient management.
Although heart rates of 150 to 200 beats/min in adults are usually cardiac in origin, small infants and young children not uncommonly have compensatory sinus tachycardias as fast as 200 to 220 beats/min. A rate of >220 beats/min in an infant or >180 beats/min in a child is likely
 supraventricular tachycardia.
CARDIOVERSION, DEFIBRILLATION, AND PACING
Electric conversion is used on an emergency basis to treat ventricular fibrillation (defibrillation) and symptomatic tachydysrhythmia (cardioversion).
Energy requirements for defibrillation and cardioversion are listed in Table 109­7. See Chapter , “Defibrillation and Electrical Cardioversion,” for further discussion.
USING PADDLES
Paddle size is .5 cm for infants (who weigh <10 kg) and  cm for children. The paddle should be in contact with the chest wall over its entire surface area. The larger, 8­cm paddles can be used for infants in the anteroposterior position. Electrode cream, electrode paste, and saline­soaked gauze pads are acceptable. Alcohol pads should not be used because serious burns may occur. Ensure the interface substance from one paddle does not come in contact with the substance from the other paddle as this contact creates a short circuit and insufficient energy delivery.
USING SELF­ADHESIVE ELECTRODES
Many defibrillation devices use cables with integrated adhesive pads for delivery of energy. Adhesive pads are used with the same general guidelines as metal paddles, including the recommendations on sizing and positioning.
POSITIONING PADDLES OR ELECTRODES
Place one contact to the right of the sternum at the second intercostal space. Place the other contact at the left midclavicular line at the level of the
 xiphoid. The anteroposterior approach also can be used, although improved success with anteroposterior positioning has not been documented.
DEFIBRILLATION
Defibrillate as quickly as possible for pulseless ventricular tachycardia or ventricular fibrillation, but do not withhold chest compressions while
 waiting for the device to charge. Initially, use  J/kg. Immediately after defibrillation provide  minutes of high­quality uninterrupted CPR regardless of the subsequent rhythm. Recheck the cardiac rhythm after  minutes of CPR. If a shockable rhythm is present, double the defibrillation energy to  J/kg, and use this higher energy level for all additional defibrillation attempts; refractory ventricular fibrillation may require higher energy
,20 to a maximum of  J/kg or the maximum adult dose.
CARDIOVERSION
Tachydysrhythmias are generally very sensitive to electric conversion. The initial dose is .5 J/kg, in the synchronized mode (Table 109­7).
Double the energy level if the first attempt is unsuccessful. If the device has only a few energy settings available, choose the one closest to the desired energy setting. If the device does not provide the synchronized mode, then the unsynchronized mode must be used.
TRANSCUTANEOUS PACING
Severe bradycardia due to an intrinsic myocardial block or congenital heart disease may respond to transcutaneous pacing. Pacing is not indicated if the bradycardia is due to hypoxic myocardial injury, ischemic myocardial injury, or respiratory failure. Oxygenation, chest compressions, and medications should precede attempts at pacing in children with severe symptomatic bradycardia due to heart block or sinus node dysfunction.
Positioning of the pacing electrodes is the same as for self­adhesive defibrillation electrodes. Ventricular capture is determined by the palpation of a pulse or the appearance of an arterial waveform, if an arterial pressure catheter is present. Maximal energy output should be used until ventricular capture occurs, then the energy setting can be decreased progressively until the lowest setting is found that allows ventricular capture. Set the pacing rate slightly higher than the normal rate for age.
AUTOMATED EXTERNAL DEFIBRILLATORS
Because children ≥8 years old may have life­threatening arrhythmias similar to those in adults and because their body weights approach those of adults, an automated external defibrillator (AED) can be used. A child ≥8 years and weighing >25 kg with sudden collapse should have an AED applied as soon as possible. An AED with a pediatric dose attenuator is ideal for children under  years of age because this feature allows the delivery of a lower dose of energy in pediatric patients. More AEDs are available that allow changing the cardioversion energy levels. If an AED with a pediatric dose attenuator is not available, then use a standard AED.
For witnessed arrests and arrests in the hospital, the AED should be applied and allowed to analyze as soon as possible. Start chest compressions the instant cardiac arrest is confirmed and continue compressions until the moment the AED is in place and ready to analyze the rhythm. Realistically, with more than one rescuer, a cycle or two of chest compressions can be provided before the AED is able to analyze the rhythm. If the AED does not recommend defibrillation, then continue CPR. Keep the AED applied until other means of cardiac monitoring become available.
SPECIAL SITUATIONS DURING RESUSCITATION
TERMINATION OF EFFORTS

Pediatric cardiopulmonary arrest lasting >20 minutes is associated with a poor outcome. If hypothermia is thought to be responsible for the arrest and cardiac electrical activity is present, resuscitation can be continued while attempting to achieve a core temperature of 30°C (86°F). The likelihood of
 survival and intact neurologic function diminishes as the duration of the resuscitation attempt increases. Unfortunately, no single factor is predictive of outcome, so integrate all the circumstances of the arrest and the patient’s premorbid condition before terminating resuscitative efforts.

Neurologically intact survival can occur after very prolonged ED resuscitations with high­quality CPR, so developing a strict time for termination of resuscitation efforts is not possible.
FAMILY PRESENCE DURING RESUSCITATION
Family presence during resuscitation efforts should be provided whenever possible. ED staff may worry about the family’s critique of the resuscitation or the family’s unwillingness to terminate efforts. Some family members may become distressed or exceedingly emotional while care is being given to a
 loved one. Positive and negative effects from family presence can occur during resuscitation. Most family members wish to be present during
 resuscitation, and being given the choice to be present contributes to the family’s sense of agency. Having family members present during resuscitation is a holistic approach to patient care, with the family’s and the patient’s needs addressed simultaneously. The current 2015 American

Heart Association guidelines consider family presence during the resuscitation to be a Class I recommendation for pediatric patients. A social worker, chaplain, or nurse can assist the family during resuscitative efforts.
COPING WITH THE DEATH OF A CHILD
Both family members and members of the resuscitation team mourn the death of a child. Several tasks of mourning have been described that must
 occur for successful resolution of grieving (Table 109­8).
TABLE 109­8
Tasks of Family Mourning a Lost Child
Accept the reality of the loss.
Work through painful grieving.
Adjust to life without the child.
Emotional resolution and return to normal activities.
Physicians and other healthcare providers can shape the way families remember the death of a child. Guidelines for communicating with parents are
 listed in Table 109­9. Parents remember how compassionately the bad news is given, but most families still want the “bottom line” when they are first told of their child’s death. They are waiting for it. Saying, “I am very sorry, we did everything we could, but Sally died” is compassionate and direct.
Most families do not want all the technical details about the resuscitation efforts. After delivering the bad news, have a chaplain or social worker stay with the family to allow the family time to deal initially with the shocking news. The physician should remain quietly in the room or return after a few minutes (or later, if other duties require) to answer questions. This is also the time to ask whether the family would like to see the child and to prepare
 them for what they will see. Many parents may regret not seeing their child after death.
TABLE 109­9
Giving Bad News Effectively
Use support staff such as chaplains and social workers.
Early in your delivery of the news, let the family know the child has died.
Use simple, direct, understandable language.
Speak with compassion and caring.
Answer questions from any family members honestly.


