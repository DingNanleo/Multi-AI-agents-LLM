## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 254: Trauma in Adults
Peter A. Cameron; Barry J. Knapp; William Teeter
Content Update: Junctional Hemorrhage Devices May 2022
See section “Hemorrhage Control” with review of devices that can be applied to noncompressible groin and axillary injuries, for which direct pressure or a standard tourniquet may not be effective.
INTRODUCTION AND EPIDEMIOLOGY
Traumatic injury accounts for more than  million ED visits in the United States each year,1 and worldwide, about  million people die each year as a result of injuries. By 2030, road traffic crashes are predicted to become the fifth leading cause of death worldwide.2 In the United States, firearm, suffocation, and drowning/submersion have the highest case fatality rates.2
Trauma remains the leading cause of death among children and adults under the age of  years, accounting for nearly half of all deaths in these age groups.3 In all countries, the incidence of death from injury increases more than threefold with increasing poverty. For the 90% of patients who survive the initial trauma, the burden of ongoing morbidity from traumatic brain injury, loss of limb function, and ongoing pain is even more significant.
The major causes of death following trauma are head injury, chest injury, and major vascular injury. Trauma care should be organized according to the concepts of rapid assessment, triage, resuscitation, diagnosis, and therapeutic intervention.4 Worldwide, there are few countries or regions that have comprehensive systems of trauma care, from roadside to rehabilitation, and that incorporate effective injury prevention strategies.
TRAUMA SYSTEMS AND TIMELY TRIAGE
A systematic approach is required to reduce the morbidity and mortality that occur after traumatic injury (Figure 254­1).
FIGURE 254­1. Phases of a preplanned trauma care continuum. ICU = intensive care unit. [Reproduced from U.S. Department of Health and Human Services, Health Resources and Services Administration.
Model Trauma System Planning and Evaluation. Rockville, MD: U.S. Department of Health and Human Services; 2006. Available at: https://www.facs.org/qualityprograms/trauma/vrc/resources. Accessed February , 2018.]
Recognizing the need to establish a system to triage injured patients rapidly to the most appropriate setting and to promote collaboration among emergency medicine, trauma surgery, and trauma care subspecialists, the U.S. Congress passed the Trauma Care Systems Planning and Development Act of 1990.5 This act provided for the development of a model trauma care system plan to serve as a reference document for each state in creating its own system. Each state must determine the appropriate facility for treatment of various types of injuries. Trauma centers are certified based on the institution’s commitment of personnel and resources to maintain a condition of readiness for the treatment of critically injured patients. Some states rely on a verification process offered by the American College of Surgeons for the designation of certain hospitals as trauma centers.4 In a well­run trauma center, the critically injured patient undergoes a multidisciplinary evaluation, and diagnostic and therapeutic interventions are performed with smooth transitions between the ED, diagnostic radiology suite, operating room, and postoperative intensive care setting. Table 254­1 details the requirements for designation as a Level  trauma center.
TABLE 254­1
Essential Characteristics of Level  Trauma Centers

Chapter 254: Trauma in Adults, Peter A. Cameron; Barry J. Knapp; William Teeter 
Meet the admission volume requirements (at least 1200 trauma patients yearly or have 240 admissions with an Injury Severity Score of >15)
. Terms of Use * Privacy Policy * Notice * Accessibility
Maintain a surgically directed critical care service
Participate in the training of residents and be a leader in education and outreach activities
Conduct trauma research
A well­functioning trauma system defines trauma centers with specific triage criteria, so that patients can be initially transported by EMS to these centers or transferred to trauma centers from other hospitals after stabilization (Table 254­2). In accordance with the principles of advanced trauma life support, injured patients are assessed and treated based on three concepts:
. Treat the greatest threat to life first.
. The lack of definitive diagnosis should never impede the application of an indicated treatment.
. A detailed history is not essential to begin the evaluation of a patient with acute injuries.6
TABLE 254­2
Triage and Trauma System Entry Criteria
Physiologic abnormalities
Systolic blood pressure <90 mm Hg
Glasgow Coma Scale score <14
Inadequate airway or need for immediate intubation
Injury pattern
Penetrating wound to head, neck, or torso
Gunshot wound to extremities proximal to elbow or knee
Extremity with neurovascular compromise
Amputation proximal to wrist or ankle
CNS injury or paralysis
Flail chest
Suspected pelvic fracture
Mechanism of injury
MVC with intrusion into passenger compartment >12 in
MVC with major vehicular deformity >20 in
Ejection from vehicle
MVC with entrapment or prolonged extrication of >20 min
Fall of >20 feet
MVC with fatality in same passenger compartment
Auto–pedestrian or auto–bicycle collision at >5 mph
Motorcycle crash >20 mph
Abbreviation: MVC = motor vehicle crash.
PRIMARY SURVEY
Prior to the patient’s arrival at the hospital, EMS providers should inform the receiving ED about the mechanism of trauma, suspected injuries, vital signs, clinical symptoms, examination findings, and treatments provided. In preparation for the patient’s arrival, ED staff should assign tasks to team members, prepare resuscitation and procedural equipment, and ensure the presence of surgical consultants and other care team members. For patients transported to EDs that are not trauma centers, consider immediately whether transfer to a trauma center is appropriate and what resuscitation or stabilization can or should be performed prior to transfer.
A focused history obtained from the patient, family members, witnesses, or prehospital providers may provide important information regarding circumstances of the injury (e.g., singlevehicle crash, fall from height, environmental exposure, smoke inhalation), ingestion of intoxicants, preexisting medical conditions (e.g., diabetes, depression, cardiac disease, pregnancy), and medication use (e.g., steroids, β­blockers, anticoagulants) that may suggest certain patterns of injury or the physiologic response to injury.
ED care of the trauma patient begins with an initial assessment for potentially serious injuries. A primary survey is undertaken quickly to identify and treat immediately lifethreatening conditions, with simultaneous resuscitation and treatment. Specific injuries that should be immediately identified and addressed during the primary survey include airway obstruction, tension pneumothorax, massive internal or external hemorrhage, open pneumothorax, flail chest, and cardiac tamponade. After assessing the patient’s airway, breathing, and circulation, perform a more thorough head­to­toe examination (the secondary survey) (Table 254­3). Follow the secondary survey with appropriate diagnostic testing, further therapeutic interventions, and disposition. When derangements are identified in any of the systems assessed in the primary survey, undertake treatment immediately.
TABLE 254­3
Primary and Secondary Survey in Trauma Resuscitation
PRIMARY SURVEY (RAPID IDENTIFICATION AND MANAGEMENT OF IMMEDIATELY LIFE­THREATENING INJURIES)
A. Airway and cervical spine
Assess, clear, and protect airway: jaw thrust/chin lift, suctioning.
Perform endotracheal intubation with in­line stabilization for patient with depressed level of consciousness or inability to protect airway.
Create surgical airway if there is significant bleeding or obstruction or laryngoscopy cannot be performed.
B. Breathing
Ventilate with 100% oxygen; monitor oxygen saturation.
Auscultate for breath sounds.
Inspect thorax and neck for deviated trachea, open chest wounds, abnormal chest wall motion, and crepitus at neck or chest.
Consider immediate needle thoracostomy for suspected tension pneumothorax.
Consider tube thoracostomy for suspected hemopneumothorax.
C. Circulation
Assess for blood volume status: skin color, capillary refill, radial/femoral/carotid pulse, and blood pressure.
Place two large­bore peripheral IV catheters.
Begin rapid infusion of warm crystalloid solution, if indicated.
Apply direct pressure to sites of brisk external bleeding.
Consider central venous or interosseous access if peripheral sites are unavailable.
Consider pericardiocentesis for suspected pericardial tamponade.
Consider left lateral decubitus position in late­trimester pregnancy.
D. Disability
Perform screening neurologic and mental status examination, assessing:
Pupil size and reactivity
Limb strength and movement, grip strength
Orientation, Glasgow Coma Scale score
Consider measurement of capillary blood glucose level in patients with altered mental status.
E. Exposure
Completely disrobe the patient, and inspect for burns and toxic exposures.
Logroll patient, maintaining neutral position and in­line neck stabilization, to inspect and palpate thoracic spine, flank, back, and buttocks.
SECONDARY SURVEY (HEAD­TO­TOE EXAMINATION FOR RAPID IDENTIFICATION AND CONTROL OF INJURIES OR POTENTIAL INSTABILITY)
Identify and control scalp wound bleeding with direct pressure, sutures, or surgical clips.
Identify facial instability and potential for airway instability.
Identify hemotympanum.
Identify epistaxis or septal hematoma; consider tamponade or airway control if bleeding is profuse.
Identify avulsed teeth or jaw instability.
Evaluate for abdominal distention and tenderness.
Identify penetrating chest, back, flank, or abdominal injuries.
Assess for pelvic stability; consider pelvic wrap or sling.
Inspect perineum for laceration or hematoma.
Inspect urethral meatus for blood.
Consider rectal examination for sphincter tone and gross blood.
Assess peripheral pulses for vascular compromise.
Identify extremity deformities, and immobilize open and closed fractures and dislocations.
AIRWAY MANAGEMENT WITH CERVICAL SPINE CONTROL
Determine airway patency by inspecting for foreign bodies or maxillofacial fractures that may result in airway obstruction. Perform a jaw thrust maneuver (simultaneously with in­line stabilization of the head and neck) and insert an oral or nasal airway as part of the first response to a patient with inadequate respiratory effort. Insertion of an oral airway may be difficult in patients with an active gag reflex. Avoid nasal airway insertion in patients with suspected basilar skull fractures. Whenever possible, use a two­person spinal stabilization technique in which one provider devotes undivided attention to maintaining in­line immobilization and preventing excessive movement of the cervical spine while the other manages the airway. If the patient vomits, logroll the patient and provide pharyngeal suction to prevent aspiration. Perform endotracheal intubation in comatose patients (Glasgow Coma
Scale score between  and 8) to protect the airway and to prevent secondary brain injury from hypoxemia. Agitated trauma patients with head injury, hypoxia, or drug­ or alcohol­induced delirium may be at risk for self­injury. Trauma patients are frequently difficult to intubate due to the need for neck immobilization, the presence of blood or vomitus, or upper airway injury.
Video laryngoscopy devices are beneficial because they aid in vocal cord visualization while minimizing cervical spine manipulation. Use a rapid­sequence intubation technique for intubation (see Chapter 29A, “Tracheal Intubation” and Chapter 29B, “Mechanical Ventilation”). If anatomy or severe maxillofacial injury precludes endotracheal intubation, cricothyroidotomy may be needed.
Clearance of the cervical spine from serious injury involves careful clinical assessment, with or without radiologic imaging. Not all patients require cervical spine radiographs. The National
Emergency X­Radiography Utilization Study (NEXUS) criteria (Table 254­4)7 and the Canadian Cervical Spine Rule (Table 254­5)8 are useful only in awake and alert patients and are not a substitute for good clinical judgment. Patients meeting NEXUS or Canadian criteria for low risk of cervical spine injury should undergo full examination of the cervical spine, including active range­of­motion testing in all directions along with a thorough neurologic examination.
TABLE 254­4
NEXUS (National Emergency X­Radiography Utilization Study) Criteria for Omitting Cervical Spinal Imaging* No posterior midline cervical spine tenderness
No evidence of intoxication
Alert mental status
No focal neurologic deficits
No painful distracting injuries
*Failure to meet any one criterion indicates need for cervical spine imaging.
TABLE 254­5
Canadian Cervical Spine Rule
Any high­risk factor that mandates radiography? If Yes, radiography indicated
(Age >64 y or dangerous mechanism or paresthesias in extremities)
No
Any low­risk factor that allows safe assessment of range of motion? If No, radiography indicated
(Simple rear­end collision or sitting position in the ED or ambulatory at any time or delayed onset of neck pain or absence of midline cervical spine tenderness)
Yes
Able to rotate neck actively? If No, radiography indicated
(45 degrees left and right)
Yes
No radiography indicated if all criteria are met
If the patient is obtunded, assume a cervical spine injury until proven otherwise. Even when plain radiographs or CT images show normal findings, it is possible for a patient to have unstable ligamentous injuries. Therefore, maintain spinal immobilization during the resuscitation. Imaging of the spine should not delay urgent operative procedures because imaging results will not change the immediate management. CT of the cervical spine is the preferred initial imaging modality. For full discussion of cervical spine imaging and management in trauma, see Chapter
258, “Spine Trauma.”
BREATHING
Once the airway is controlled, inspect, auscultate, and palpate the thorax and neck to detect abnormalities such as a deviated trachea (tension pneumothorax); crepitus (pneumothorax); paradoxical movement of a chest wall segment (flail chest); sucking chest wound; fractured sternum; and absence of breath sounds on either side of the chest (simple or tension pneumothorax, massive hemothorax, or right mainstem intubation). Any of these findings warrants immediate intervention, including needle thoracostomy for tension pneumothorax (see the section “Needle Decompression” in Chapter , “Pneumothorax”); insertion of large­bore chest tubes (36 F) to relieve hemopneumothorax (see Chapter 261, “Pulmonary Trauma”); and application of an occlusive dressing to a sucking chest wound. For asymmetric or absent breath sounds in the intubated patient, partially withdraw the endotracheal tube from the right mainstem bronchus or reintubate. If no breath sounds are heard, and if massive hemothorax or vascular injury is suspected (initial chest tube output of >1500 mL, or >200 mL/h), a thoracotomy or video­assisted thoracic surgery is indicated to identify and control the source of bleeding.
CIRCULATION AND HEMORRHAGE CONTROL
HEMORRHAGE CONTROL
As part of the primary survey in the prehospital and hospital settings, identify and control external hemorrhage. Apply direct pressure, a compression bandage, or a hemostatic dressing to control active external bleeding. QuikClot Combat Gauze® is a kaolin­impregnated rayon and polyester hemostatic dressing that is safe and effective for arterial or venous bleeding.4,9 For exsanguinating extremity injury, apply a tourniquet (Fig. 254­2). Prehospital and battlefield use of tourniquets is common. With aggressive tourniquet use, death rates from isolated limb exsanguination in Iraq decreased to 2% compared to 9% in the Vietnam War.10 In civilian trauma, the need for tourniquet application is less common but can be lifesaving.
FIGURE 254­2. C.A.T.® tourniquet. [Source: J.E. Tintinalli, J.S. Stapczynski, O.J. Maa, D.M. Yealy, G.D. Meckler, D.M. Cline: Tintinalli’s Emergency Medicine: A Comprehensive Study Guide, 8th ed.www.accessmedicine.com. (Copyright .)]
Bleeding from groin and axilla injuries can be difficult to control. The most common cause of bleeding in these areas is penetrating injury. Blunt injury may also result in junctional hemorrhage, as in bicycle handlebar injury, where localized pressure can tear the soft tissues. The vessels of both the groin and axilla are large and may retract into the retroperitoneal compartment or thorax. In addition, the vessels are deeper and there is no way to apply packing, compression, or a standard tourniquet above the bleeding point. Patients may quickly exsanguinate in the prehospital setting or the ED.
There are a number of devices commercially available. The iTClamp (Fig. 254­3 A and B) looks like a hairclip and has steel teeth that allow the clamp to compress the bleeding area. It is also reported to be useful for scalp, arm, and leg injuries if direct pressure and tourniquets fail to control bleeding.11 The CRoC® Combat Ready Clamp has an adjustable bar clamp that can be applied to the groin or axilla (Fig. 254­3 C). The JETT® is a belt­like device that can occlude blood flow to both lower limbs if needed (Fig. 254­3 D).
FIGURE 254­3A
Anterior View iTClamp.® Reproduced with permission from Innovative Trauma Care, Atlanta, GA.
FIGURE 254­3B
Lateral View iTClamp® Reproduced with permission from Innovative Trauma Care, Atlanta, GA.
FIGURE 254­3C
CRoC® Combat Ready Clamp. Reproduced with permission from Combat Medical Systems, Fayetteville, NC.
FIGURE 254­3D
JETT® Junctional Emergency Treatment Tool. Reproduced with permission from North American Rescue, LLC. Greer, SC. narescue.com.
Resuscitative Endovascular Balloon Occlusion of the Aorta (REBOA—see Video 254–1 and Figure  in “REBOA: Resuscitative Endovascular Balloon Occlusion of the Aorta,” below.).
REBOA is potentially indicated for traumatic life–threatening hemorrhage below the diaphragm in patients in hemorrhagic shock who are unresponsive to resuscitation. Depending on the location of hemorrhage, an inflatable balloon catheter is inserted in the femoral artery and advanced to the distal thoracic aorta or distal abdominal aorta. REBOA is a bridging therapy to definitive surgery. The technique should not delay definitive surgery and is suitable for only a limited number of patients. It is important to note that no current, high–grade evidence clearly demonstrates REBOA improves outcomes or survival compared to standard treatment of severe hemorrhage.12,13 Complications of REBOA include arterial disruption, hematoma, thromboemboli, dissection, and spinal or extremity ischemia.
Video 254­1: REBOA
Video Credit: The Tarpan Group
Play Video
TRANEXAMIC ACID (TXA)
Tranexamic acid is an antifibrinolytic agent that reduces blood loss after surgery and may reduce blood loss after traumatic injury. It prevents cleavage of plasmin and degradation of fibrin. It is on the World Health Organization list of essential medications affecting coagulation.14 Studies involving >20,000 patients reported a risk reduction of death from bleeding of 10% to 15%.
There was no reported difference in risk of death from myocardial infarction, vascular occlusion, stroke, pulmonary embolism, mutiorgan failure, or head injury.15 Criticism of the Clinical
Randomization of an Antifibrinolytic in Significant Hemorrhage  (CRASH–2) study was that the patient populations studied were heterogeneous in terms of injury and were in low– to middle– income countries with basic and very limited resources for major trauma management.16,17 Nevertheless, the evidence to date indicates that tranexamic acid may reduce mortality without significant adverse side effects when given as early as possible after injury, with administration within  h of injury reported to decrease the relative risk of death from bleeding by 32% and within  to  h by 21%.18 Administration of tranexamic acid more than  h after injury is less effective and potentially harmful.15 Tranexamic acid must be given before transfer/arrival to a trauma center in order to meet the time requirement of early administration.16 The dose is  gram of tranexamic acid IV bolus over  min, followed by  gram IV over  h.
CIRCULATION
Assessment of the patient's overall hemodynamic status is critical. This assessment includes evaluation of level of consciousness, skin color, and presence and magnitude of peripheral pulses. Note the heart rate and pulse pressure (systolic minus diastolic blood pressure), particularly in young, previously healthy trauma patients, as these may be early clues to impending hemodynamic compromise.
Any hypotensive trauma patient is at risk for development of hemorrhagic shock, a common cause of postinjury death. One system is commonly used for classifying the degree of hemorrhage
(Table 254­6), although it has not been validated and there is wide variability in individual patient response to hypovolemia. Hemorrhage and shock are on a continuum, and some patients can compensate for significant blood loss better than others. Hemorrhage of up to 30% of total blood volume may be associated with only mild tachycardia and a decrease in pulse pressure, but may quickly progress to profound hypoperfusion and decompensated shock if not recognized early. Be aware that medications, such as β­blockers, can mask early hemodynamic indicators of shock.
TABLE 254­6
Classification of Hemorrhage Based on Estimated Blood Loss at Initial Presentation
Class I Class II Class III Class IV
Blood loss (mL)* Up to 750 750–1500 1500–2000 >2000
Blood loss (% blood volume) Up to  15–30 30–40 
Pulse rate (beats/min) <100 100–120 120–140 >140
Blood pressure Normal Normal Decreased Decreased
Pulse pressure Normal or increased Decreased Decreased Decreased
*Assumes a 70­kg patient with a preinjury circulating blood volume of  L.
Establish two large­bore IV lines (18 gauge or larger), infuse lactated Ringer’s, and obtain blood samples or specimens for laboratory studies, particularly blood type and screen. In patients who are unstable or in whom upper extremity peripheral veins are not easily cannulated, establish central venous access via the subclavian, internal jugular, or femoral vein. Avoid placement of a central venous line distal to a potential venous injury. Placement of an IO catheter is a second­line option (after peripheral IV attempt) because it is quick and easy and can accommodate infusion of large volumes. Most medications including blood products can be administered IO. Use a pressure bag to maximize flow rates. A balanced crystalloid, such as lactated Ringer’s, is the fluid of choice for initial resuscitation. There is some advantage of lactated Ringer’s over normal saline when large volumes are given in order to avoid hyperchloremic acidosis, although this is unlikely to be significant for most patients during initial resuscitation.
Reassess hypotensive patients without an obvious indication for surgery after rapid infusion of  L of crystalloid solution. If there is no marked improvement, then transfuse type O blood (O­ negative for females of childbearing age). Aggressive volume resuscitation is not a substitute for definitive hemorrhage control.
Patients requiring massive transfusions generally require urgent surgical intervention to control hemorrhage. A well­defined source of bleeding may be evident on external examination, assessment of chest tube output, extended FAST examination (Figure 254­4), or conventional or CT imaging of the chest or abdomen. There may also be considerable blood loss from blunt trauma to the pelvis and limbs without a discrete source. Immobilize open pelvic fractures in a pelvic wrap or sling and reduce and immobilize limb fractures to tamponade bleeding from fractured bone ends.
FIGURE 254­4. Positive extended FAST exam with blood identified in Morison’s pouch. [Photo contributed by Barry Knapp, MD.]
Major trauma patients may develop a bleeding diathesis almost from the time of injury, which results in defective clotting and platelet function. Data from both military and civilian experience reveal that patients receiving >10 units of packed red blood cells showed decreased mortality when they simultaneously receive fresh frozen plasma in a ratio of packed red blood cells to fresh frozen plasma of 1:1 rather than 1:4 (26% vs. .5% mortality, respectively).19 There is general consensus that there should be a higher ratio of fresh frozen plasma and platelets to packed red cells up to 1:1:1 ratio in massive transfusion protocols.20 Both acidosis and hypothermia contribute to the coagulopathy and should be corrected as quickly as possible.
REBOA: Resuscitative Endovascular Balloon Occlusion of the Aorta
BACKGROUND
Exsanguinating hemorrhage is a leading cause of preventable death following trauma. The U.S. military has improved survival from exsanguinating extremity injuries by means of field tourniquet application, but noncompressible torso hemorrhage remains a difficult problem. Historically, definitive control of noncompressible torso hemorrhage has been attempted through the field application of specially designed tourniquets, as well as emergent thoracotomy. Thoracotomy and laparotomy for definitive hemorrhage control require rapid transport to surgical care. One tool for alternative hemorrhage control is resuscitative endovascular balloon occlusion of the aorta (REBOA), which was originally described during the Korean War and has been re­popularized during the recent wars in Iraq and Afghanistan. REBOA involves insertion and inflation of an endovascular balloon into the proximal aorta via the common femoral artery. Balloon inflation is a temporizing maneuver until definitive hemostasis by vascular interventional procedures or open surgical control.
INDICATIONS
REBOA is primarily used in the United States for trauma or intraoperative exsanguination. It has been used internationally for a wider range of indications and for many years. Other indications reported in the literature include massive exsanguination from postpartum hemorrhage, upper GI bleeding, pelvic surgery, and ruptured aortic aneurysm. Although many protocols exist, experts generally agree that exsanguinating hemorrhage originating from a source below the diaphragm, which is unresponsive or transiently responsive to resuscitation, could benefit from REBOA.1 In addition, REBOA can be considered for acute traumatic cardiac arrest due to presumed life­threatening hemorrhage below the diaphragm. The balloon catheter can be inflated into one of two general “zones” of the descending aorta. Inflation of the balloon at zone  is for control of hemorrhage originating from below the diaphragm to above the renal arteries (Figure 1). If the source of hemorrhage is below the level of the renal arteries, including severe pelvic, groin, or proximal lower extremity hemorrhage, the balloon may be inflated within zone . Zone  extends from the diaphragm to the lowest renal artery and is generally avoided due to the presence of the visceral arteries.
PROCEDURE
A general description of the procedure was originally described by Stannard and colleagues2 as a five­step procedure including arterial access, balloon selection and positioning, balloon inflation, balloon deflation, and sheath removal. With the development of purpose­designed REBOA catheters through smaller introducer sheaths, the procedure requires fewer steps with more rapid insertion and inflation compared to previous technology adapted from vascular surgery.
Training typically consists of a course discussing the risks, benefits, and application of the technique, coupled with simulation, animal model, or cadaver model training.3,4
Procedural steps include obtaining vascular access in the common femoral artery  cm below the inguinal ligament by either US­guided percutaneous or open exposure access. Many experts recommend open access in cardiac arrest. Insert the catheter sheath using the Seldinger technique. Measure the balloon for insertion length, which can be obtained by using either external landmarks, using the xiphoid for zone  and umbilicus for zone , or standardized length measurements, which place the balloon correctly for a large portion of the population.
Then insert the balloon to the measured length and inflate with sterile fluid with or without radiopaque contrast. Imaging may be obtained after catheter insertion and balloon inflation to confirm placement within the aorta, but some experts feel this is not necessary. After inflation, assess patient response and send the patient for definitive hemorrhage control as soon as possible.
The prime consideration for the emergency provider is the most rapid disposition of the patient possible from the ED to definitive hemorrhage control in the operating room or by interventional radiology.3 Field application is possible in the military or in systems with robust prehospital resources as long as there is very rapid transport for definitive hemorrhage control. The effects of prolonged aortic occlusion with REBOA, including partial or intermittent REBOA for mitigation of distal ischemia, are poorly studied.
William Teeter, MD, MS


