## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 278: Compartment Syndrome
Maxwell A. Beck; Paul Haller
INTRODUCTION
Compartment syndrome occurs when increased pressure within a limited space compromises the circulation and function of the muscles and nerves within that space. It was first described in 1881 by Richard Van Volkmann, a German physician who noted that paralysis and contractures were the late sequelae of an interruption of the blood supply to the muscles in the forearm.
A high degree of clinical suspicion, coupled with timely surgery, can be used to save function of the muscles and nerves that are at risk of permanent damage from elevated compartment pressures.
ANATOMY
The borders of a confined space are often made up of bone or tissue that offers minimal capacity to stretch. Any increase in volume within that compartment results in an elevated intracompartmental pressure. In the lower extremity, the most common site is at the level of the tibia and fibula, where 40% of compartment syndromes occur. The lower leg has four compartments: anterior, lateral, superficial posterior, and deep posterior
(Figure 278­1). (Also see Figure 275­1 in Chapter 275, “Leg Injuries.”)
FIGURE 278­1. The four compartments of the lower leg.
The upper leg has three compartments: anterior, posterior, and medial. Due to the larger size of these compartments and their interconnectivity, they are less predisposed to elevated tissue pressures. The foot and buttock region of the leg also have a lower incidence of compartment syndrome.

In the upper extremity, the forearm has three compartments: flexor, extensor, and mobile wad (Figure 278­2). These are the high­risk areas in the
Chapter 278: Compartment Syndrome, Maxwell A. Beck; Paul Haller arm. The hand (Figure 278­3) and upper arm (Figure 278­4) are less likely to develop a compartment syndrome.
. Terms of Use * Privacy Policy * Notice * Accessibility
FIGURE 278­2. Forearm compartments.
FIGURE 278­3. Hand compartments: transverse section through the right hand.
FIGURE 278­4. The biceps brachialis (anterior) and triceps (posterior) compartments of the right arm.
The size of the compartment increases through youth into early adulthood. It then remains the same size through the subsequent years. The amount of muscle mass in a compartment also increases in size until the early 20s, but after age  years, it begins to diminish. Thus, after age  years, a
 patient is less likely to develop compartment syndrome.
PATHOPHYSIOLOGY
Tissue perfusion is created by a gradient between the arterial pressure (diastolic in particular) and the venous capillary pressure. Ischemia may occur when the tissue pressure within a compartment exceeds the venous capillary pressure. The normal pressure within a compartment is <10 mm Hg.
Pressures up to  mm Hg can be tolerated without damage. Cell death results from prolonged exposure to elevated pressures. The exact duration and elevation at which a pressure becomes dangerous remain unclear. Some tissues are more resistant to ischemic damage. Bone is relatively immune; muscle tissue is rather sensitive to ischemia, and nerves can also be easily damaged. Muscles can tolerate ischemic events that last longer than  hours.
Greater than  hours of ischemia clearly leads to cell death and long­term contracture of an extremity. Nerve cells can tolerate periods of ischemia less than  hours in duration. With nerves, ischemic insults longer than  hours often result in neuropathy (Table 278­1).
TABLE 278­1
Tissue Survival of Ischemia
Muscle Nerve
3–4 h Reversible change  h Loss of nerve conduction
 h Variable damage  h Neurapraxia
 h Irreversible damage  h Irreversible damage
CLINICAL FEATURES
HISTORY
Compartment syndrome may occur with or without known trauma. For example, patients with hemophilia or rhabdomyolysis can develop compartment syndrome without direct trauma, and crush injury or tibial fracture can result in compartment syndrome to the affected extremity. In the setting of trauma, symptoms usually develop within a few hours of the injury. The awake patient may initially complain of severe pain in the affected compartment, often refractory to opioids. The pain is due to elevated tissue pressures within a compartment. Thus, the pain worsens when the muscle groups within that compartment are passively or actively stretched. Young age has been shown to be the strongest predictor of developing acute
 compartment syndrome.
PHYSICAL EXAMINATION
The aggravation of pain by passive or active stretching of muscles in the compartment in question is the most sensitive (and often the only) clinical finding before the onset of ischemic dysfunction.
When nerve conduction is affected, the patient will note numbness or dysesthesia in the sensory distribution of the nerve traversing that compartment; motor nerve function may also be affected. Because tissue pressures do not become higher than arterial pressures, the distal pulse in the extremity will remain normal, and there will not be a change in the color or warmth of the extremity. Squeezing or palpation of the muscle groups in the compartments will exacerbate pain. Firmness or fullness in the affected compartment is often detected.
DIAGNOSIS
In the appropriate clinical setting, exam findings alone may be sufficient to make the diagnosis and propel the patient in a timely fashion to the operating room for surgical treatment. At times, direct measurement of the tissue pressures in the compartment should be performed to help calculate the delta pressure, confirm the diagnosis, and determine patient disposition.
COMPARTMENT PRESSURE MEASUREMENT
Several commercial devices are available for measuring intracompartmental pressures. A Stryker Kit® is one such system. The kit consists of a salinefilled syringe, a manometer, and a needle with a side port. Connect the manometer between the syringe and the needle. Insert the needle into the compartment. Inject a few drops of saline to ensure that there are no air pockets and that the needle is not inserted into a tendon. The gauge gives the pressure reading in mm Hg. Check pressures twice in each compartment. Also check adjacent compartment pressures. Because pressures are highest near the injured area, obtain the measurements within  cm of a fracture site. Figure 278­1 demonstrates appropriate sites for pressure measurements in the lower leg, whereas Figure 278­5 shows sites for the forearm. The hands and feet have many compartments within them, all too numerous and small to easily measure. If compartment syndrome is suspected in these sites, some specialists opt for surgical intervention without documentation of elevated pressures.
FIGURE 278­5. A. Forearm extensor compartment. B. Forearm flexor compartments. C. Mobile wad compartment.
The precise intracompartment pressure that should mandate surgical decompression remains unclear. Two different pressure measurements are often used. Using only intracompartmental pressures as a guide, it is clear that pressures <30 mm Hg require no intervention, whereas pressure readings >45 mm Hg require decompression. An alternative approach is to measure the difference between the diastolic blood pressure and the intracompartmental pressure. This may be particularly useful in the hypotensive patient. A diastolic pressure that is  to  mm Hg higher than the compartment pressure may be managed conservatively. A difference between the diastolic pressure and intracompartmental pressure <30 mm Hg does not allow adequate perfusion and should be managed with fasciotomy.
In cases where compartment syndrome is less obvious, such as in patients who are obtunded, continuous measurement of compartment pressures can be helpful. One study determined that continuous intracompartmental pressure monitoring had an estimated sensitivity and specificity of 94%
 and 98%, respectively. The anterior compartment is usually chosen for monitoring, as it has the highest pressures at any given time. Continuous measurement of compartment pressures in a clinically obvious compartment syndrome is not necessary.
LABORATORY TESTING
Laboratory testing is of no benefit in the setting of compartment syndrome. At times, the serum creatine phosphokinase may be elevated, as may myoglobin levels. Urinalysis may reveal myoglobinuria. Hemophiliacs or patients with clotting disorders need assay of coagulation parameters and factor levels.
TREATMENT
The initial medical management of these patients includes prioritizing the primary survey. Immediately remove restrictive casts or dressings, which alone can markedly reduce tissue pressures. Place the affected limbs at the level of the heart; elevation higher than the heart increases the arteriovenous pressure gradient.
Hemophiliacs should have replacement of factor levels (see Chapter 235, “Hemophilias and von Willebrand’s Disease”), and patients on anticoagulants should have reversal or factor replacement (see Chapter 239, “Thrombotics and Antithrombotics”).
Surgical fasciotomy reduces intracompartmental pressure. Long incisions are necessary to release pressure in the affected compartment and simultaneously incise adjacent compartments. Tissue edema within the compartment will typically cause the muscle to bulge from the incision sites.
The wounds should be initially left open with a second­look procedure for debridement and possible closure scheduled within  to  hours after the initial intervention. Ideally, definitive wound closure is obtained within  to  days, which may require skin grafting.
A contraindication to fasciotomy is a missed timely diagnosis of compartment syndrome. Tissue pressures that have been elevated for  to  hours may have already caused permanent dysfunction, and opening the compartments at this time may be futile.
DISEASE COMPLICATIONS
When fasciotomy is performed in a timely fashion, it can prevent death of the muscle within that compartment and the nerves that travel through it.
When delayed, permanent neuropathy and muscle death may occur. Functional impairment is unlikely when compartment syndrome is diagnosed and treated within  hours of onset. Delays in diagnosis and treatment carry not only functional implications but also medicolegal ones. In a retrospective review of malpractice claims involving compartment syndrome, increasing time from the first onset of symptoms to fasciotomy was associated with
 increased indemnity payments.
DISPOSITION AND FOLLOW­UP
Admit all patients with compartment syndrome for surgical management or to an appropriate inpatient unit for serial observation and re­examination.
For patients with equivocal findings who are discharged, stress the importance of close outpatient follow­up and immediate return to the ED for worsening pain, paresthesias, or motor dysfunction.


