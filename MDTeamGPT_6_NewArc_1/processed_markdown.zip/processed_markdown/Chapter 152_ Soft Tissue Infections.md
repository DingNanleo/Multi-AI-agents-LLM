## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 152: Soft Tissue Infections
Elizabeth W. Kelly
Content Update Duration of Outpatient Antibiotic Treatment June 2021
Optimal treatment duration is a 5­6 day course for patients able to self­monitor and who have close followup with primary care. Reference 27A provides best practice guidelines from the American College of Physicians.
INTRODUCTION
More than  in 100 people seek treatment for skin and soft tissue infections each year in the United States, and these infections are about  times
 more likely to be ambulatory treated than inpatient treated. Abscess or cellulitis are the most common of these infections, with the majority of
 patients treated in the outpatient setting. This chapter discusses skin and soft tissue infections in adults; impetigo and other soft tissue infections in children are discussed in Chapter 142, “Rashes in Infants and Children.” Perirectal abscess and pilonidal abscess are discussed in Chapter ,
“Anorectal Disorders.” Bartholin gland abscess is discussed in Chapter 102, “Vulvovaginitis.” Hidradenitis suppurativa is discussed in Chapter 252,
“Skin Disorders: Groin and Skinfolds.” Paronychia and felons are discussed in Chapter 283, “Nontraumatic Disorders of the Hand.”
ANATOMY AND DEFINITIONS
The skin consists of the superficial epidermis, dermis, and deeper subcutaneous tissues including fat (Figure 152­1). The lymphatics run parallel with the blood vessels. Cellulitis is an infection of the dermis and subcutaneous tissue and is divided clinically as purulent or nonpurulent. Management of
,3 the two types is different. Purulent cellulitis is a skin or soft tissue infection with purulent drainage or an underlying abscess. Nonpurulent cellulitis
,3 has no purulent drainage or exudate and no associated abscess. Erysipelas traditionally has been defined as a more superficial skin infection involving the upper dermis with clear demarcation between involved and uninvolved skin with prominent lymphatic involvement. Folliculitis is an infection of the hair follicle, often purulent, but is superficial without involvement of the deeper tissues. Skin abscesses are collections of pus within the dermis and deeper skin tissues, potentially involving the subcutaneous tissues. Furuncles (or boils) are single, deep nodules involving the hair
  follicle that are often suppurative. Carbuncles are formed by multiple interconnecting furuncles that drain through several openings in the skin.
Necrotizing soft tissue infections are characterized by microbial triggered necrosis involving any of the soft tissue layers including the dermis,
 subcutaneous tissues, fascia, and muscle.
FIGURE 152­1. Schematic diagram of the architecture of the skin. This diagram shows the anatomy of the skin, including the epidermis, dermis, and deeper subcutaneous tissues. Also shown are the blood vessels and a hair follicle. [Reproduced with permission from Wolff K, et al: Fitzpatrick’s Dermatology in General Medicine, 7th ed. © 2008, McGraw­Hill, Inc., New York.]

Chapter 152: Soft Tissue Infections, Elizabeth W. Kelly 
. Terms of Use * Privacy Policy * Notice * Accessibility
CELLULITIS AND ERYSIPELAS
EPIDEMIOLOGY
,6
Cellulitis accounts for approximately .3% of all ED visits. General risk factors for cellulitis are listed in Table 152­1. Risk factors for specific
,5,7­12 organisms causing cellulitis are listed in Table 152­2. Cellulitis is observed more frequently among middle­aged and elderly patients, whereas
 erysipelas is more common among children and elderly patients. Patient characteristics demonstrate a male predominance (61%) and a mean age of
 years, and the vast majority of infections involve either the lower or upper extremities (48% and 41%, respectively). Approximately 10% of patients diagnosed with cellulitis are hospitalized, and the majority of these patients are over age  years.
TABLE 152­1
General Risk Factors for Cellulitis and Erysipelas
Risk Factors
Lymphedema
Skin breakdown/site of entry
Venous insufficiency
Leg edema
Obesity
Neutropenia
Immunocompromise
Hypogammaglobulinemia
Chronic renal disease
Cirrhosis
TABLE 152­2
Risk Factors for Specific Organisms Causing Cellulitis
Organism(s) Risk Factors
Methicillin­resistant Staphylococcus aureus (MRSA) Purulent soft tissue infections
Antibiotic use in past month
Previous MRSA infection or colonization
Patient report of suspected spider bite
Previous hospitalization or surgery within the past year
Residence in a long­term care facility within the past year
Hemodialysis
Crowded living environments including day care or homeless shelters, soldiers, prisons
Contact sports
Injection drug users
Men who have sex with men
Household contacts with MRSA infection
Children
β­Hemolytic streptococci Nonpurulent cellulitis that is culture negative by needle aspiration
Gram­negative bacteria Elderly patients, cirrhosis, diabetic foot infections, fish bone injury
Aeromonas hydrophila Fresh water lacerations, contact with wet soil
Vibrio vulnificus, Vibrio parahaemolyticus Salt water lacerations, fish fin or bone injuries, cirrhosis
Pseudomonas aeruginosa Neutropenia, injection drug use, hot tub exposure
Anaerobic bacteria including clostridia Bite wounds,* diabetes mellitus, necrotizing infections, gas in tissues
Polymicrobial Diabetic foot injections, bite wounds* Pasteurella species Dog and cat bites* Capnocytophaga canimorsus Dog and cat bites* Mycobacterium marinum Fish tank exposure
Streptococcus pneumoniae and Haemophilus influenzae Nonimmunized children and adults
*See Chapters  and 211, 212, 213, “Puncture Wounds and Bites,” “Bites and Stings,” “Snake Bites,” and “Marine Trauma and Envenomation,” respectively.
MICROBIOLOGY
Approximately 80% of cellulitis cases are caused by gram­positive bacteria. Community­acquired methicillin­resistant Staphylococcus aureus (MRSA) is
,14 now the most common cause of skin and soft tissue infections presenting to the ED, regardless of patient risk factors. The Infectious Diseases

Society of America recommends differentiation of purulent from nonpurulent cellulitis (see detailed definitions earlier) for treatment decisions.
MRSA is likely to be the causative agent in purulent cellulitis. For nonpurulent cellulitis, the role of MRSA is unknown, and empirical therapy for β­
,15­18 hemolytic streptococcal infection with β­lactams is recommended. Gram­negative aerobic bacilli are the third most common etiology. Other less common pathogens causing cellulitis are listed in Table 152­2 with associated risk factors.

Erysipelas is usually caused by β­hemolytic streptococci. Bullous erysipelas is a more severe form and can represent synergy with β­hemolytic
 streptococci and MRSA.
PATHOPHYSIOLOGY
Most symptoms of cellulitis are secondary to a complex set of immune and inflammatory reactions triggered by cells within the skin itself. Although bacterial invasion is what triggers the inflammation, the organisms are largely cleared from the site within the first  hours. The subsequent inflammatory response is caused by the infiltration of cells, such as Langerhans cells and keratinocytes, which release the cytokines interleukin­1 and tumor necrosis factor that enhance skin infiltration by lymphocytes and macrophages.
CLINICAL FEATURES
Cellulitis
In cellulitis, the affected skin is tender, warm, erythematous, and swollen, and typically does not exhibit a sharp demarcation from uninvolved skin.
Edema can occur around hair follicles that leads to dimpling of the skin, creating an orange peel appearance referred to as “peau d’orange” (Figure
152­2). Symptoms develop gradually over a few days. Lymphangitis and lymphadenopathy are seen occasionally in previously healthy patients, but
 purely local inflammation is much more common. In cases of purulent cellulitis, exudate drains from the wound ; an abscess may or may not subsequently form. Systemic signs of fever, leukocytosis, and bacteremia are more typical in the immunosuppressed. Recurrent episodes of cellulitis can lead to impairment of lymphatic drainage, permanent swelling, dermal fibrosis, and epidermal thickening. These chronic changes are known as elephantiasis nostra and predispose patients to further attacks of cellulitis.
FIGURE 152­2. Cellulitis of the right leg characterized by erythema and mild swelling. [Photo contributed by Lawrence B. Stack, MD. Reproduced with permission from
Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 3rd ed. © 2010, McGraw­Hill, Inc., New York.]
Erysipelas
In erysipelas, the onset of symptoms is usually abrupt, with fever, chills, malaise, and nausea representing the prodromal phase. Over the next  to  days, a small area of erythema with a burning sensation develops. As infection progresses, the affected skin becomes indurated with a raised border that is distinctly demarcated from the surrounding normal skin. The “peau d’orange” appearance is also common in erysipelas. A classic description is a “butterfly” pattern over the face (Figure 152­3). Complete involvement of the ear is the “Milian ear sign” and is a distinguishing feature of erysipelas because the ear does not contain deeper dermis tissue typically involved in cellulitis. Lymphatic inflammatory changes, known as toxic striations, and local lymphadenopathy are common. Purpura, bullae, and small areas of necrosis warrant a search for possible necrotizing soft tissue infection. On resolution of the infection, desquamation of the site often occurs.
FIGURE 152­3. Butterfly rash of erysipelas. The sharp demarcation between the salmon­red erythema and the normal surrounding skin is evident. [Reproduced with permission from Shah BR, Lucchesi M: Atlas of Pediatric Emergency Medicine, © 2006, McGraw­Hill, Inc., New York.]
DIAGNOSIS
The diagnosis of cellulitis and erysipelas is clinical. Management should be guided by the clinical differentiation between purulent and nonpurulent
,3 soft tissue infections. Presence of an abscess or purulent drainage from the area of cellulitis defines the soft tissue infection as purulent.
Mild disease, for both purulent and nonpurulent forms of cellulitis, is distinguished by the absence of systemic symptoms. In cases of mild infection,
 blood cultures, needle aspiration, punch biopsy, leukocyte count, or other lab data are of little benefit and are not recommended. Needle aspiration of the leading edge of an area of cellulitis produces organisms in .7% of cultures (range, 0% to 40%), and punch biopsy reveals an organism only 18%
 to 26% of the time. Areas with abscess formation have significantly higher yields; wound culture is recommend when the decision has been made
 to place the patient on antibiotics for purulent cellulitis. Blood cultures are positive in only 5% of cases. For both purulent and nonpurulent cellulitis, in patients with systemic toxicity, extensive skin involvement, underlying comorbidities, immunodeficiency, immersion injuries, failed initial therapy, or
,20,21 recurrent episodes, or in circumstances such as animal bites, cultures of pus, bullae, or blood are recommended. Routine radiographic evaluation is unnecessary, but should be considered if osteomyelitis (see Chapter 281, “Hip and Knee Pain”) or necrotizing soft tissue infections are suspected (see later section). Table 152­3 lists differential diagnoses and characteristics that help distinguish cellulitis from the listed disorder.
TABLE 152­3
Differential Diagnosis of Cellulitis and Erysipelas
Diagnosis Distinguishing Clinical Characteristics
Bursitis Characteristic locations such as suprapatellar or olecranon, may have palpable fluid collection
Contact dermatitis Pruritus instead of pain, absence of fever, may have bulla, but patient is nontoxic in appearance
Stasis dermatitis Bilateral, long­standing, pitting edema, mild tenderness only
Cutaneous abscess Abscess may appear similar to cellulitis initially; eventual fluctuance and purulent drainage
Deep vein Typically, not associated with skin redness or fever thrombosis
Drug reactions Temporal relation to new drug exposure, pruritus instead of pain, absence of fever
Gouty arthritis Pronounced pain with involved joint movement
Herpes zoster Characteristic vesicles, dermatomal pattern
Insect stings Pronounced pain most at onset
Necrotizing soft Rapid progression; triad of severe pain, swelling, and fever; pain out of proportion to exam; severe toxicity; hemorrhagic or bluish tissue infection bullae; gas or crepitus; skin necrosis or extensive ecchymosis
Osteomyelitis Deeper involvement, prolonged course, comorbidities
Superficial Typically, not associated with fever, limited to venous path thrombophlebitis
Toxic shock Hypotension, multiorgan involvement, severe toxicity syndrome

POCUS is useful to exclude occult abscess. Doppler studies may be indicated to distinguish lower extremity deep venous thrombosis from cellulitis.
The most important diagnosis to exclude is necrotizing soft tissue infection (see later section).
TREATMENT
General Treatment
Treatment is elevation of the affected area, incision and drainage of any abscess found (see later section), antibiotics for cellulitis, and treatment of underlying conditions. Elevation helps drainage of edema. Treat skin dryness with topical agents because skin dryness and cracking further exacerbate symptoms. Treat predisposing conditions such as tinea pedis (see Chapter 253, “Skin Disorders: Extremities”) and refer to primary care for treatment of lymphedema and chronic venous insufficiency.
Treatment for Purulent Cellulitis or Suspected MRSA Etiology
,23
See Table 152­4 for empiric antibiotic recommendations for purulent cellulitis or when MRSA is suspected. Identify and thoroughly drain an abscess. POCUS will aid this procedure. Provide empiric therapy for MRSA for patients who have failed initial non­MRSA therapy, those with a previous
 history of or risks for MRSA, or those who live in an area with a high prevalence of community­associated MRSA infections. For patients with severe infection or systemic toxicity, consider necrotizing fasciitis (see later section on necrotizing fasciitis). It may be difficult to clinically distinguish MRSA cellulitis from methicillin­susceptible S. aureus cellulitis. Treatment failure rates are similar for both β­lactam antibiotics and MRSA­specific antibiotics
,26 such as trimethoprim­sulfamethoxazole.
TABLE 152­4
Empiric Antibiotic Treatment of Purulent Cellulitis* and/or Soft Tissue Abscess
Guide by Severity of Illness Antibiotics Comments
No antibiotics for mild disease: None required for healthy . Presence of an abscess should be carefully investigated clinically
Drainable abscess found with no signs immunocompetent patients where and drained; consider use of US.
of systemic infection abscess drainage is complete after procedure
Oral antibiotics for moderate Trimethoprim­sulfamethoxazole . Wound culture is recommended in cases where antibiotics are disease: double­strength 1–2 tablets twice given.
Purulent cellulitis* without signs of per day PO for 7–10 d† . Patients who have failed to improve on outpatient antibiotics or systemic infection are unable to tolerate oral antibiotics should be admitted to the
Or doxycycline 100 milligrams PO
Or drainable abscess in the presence of hospital and receive IV antibiotics; see below.
twice per day for 7–10 d† mild to moderate signs of systemic
Orclindamycin, 300–450 milligrams infection
PO four times daily for 7–10 d†‡
If immunocompromised, see below.
IV antibiotics for severe disease: For MRSA coverage: . Admit to the hospital.
Purulent cellulitis* with signs of Vancomycin  milligrams/kg IV . Additional antibiotic coverage is listed below.
systemic infection every  h . Consider admission to intensive care unit for patients who meet
Or drainable abscess in the presence of Or linezolid 600 milligrams IV every criteria for sepsis (see also Chapter 151, “Sepsis”).
moderate to severe signs of systemic  h† . For all patients with severe disease, see later section on necrotizing infection# or sepsisf Or daptomycin  milligrams/kg IV fasciitis.
Or an immunocompromised patient every  h†
Ortelavancin  milligrams/kg IV every  h†
Orclindamycin 600 milligrams IV every  h†
Additional coverage for patients with For patients with sepsis, or for For fresh water exposure (Aeromonas species) or for salt water sepsis or for patients with selected unclear etiology, add: exposure (Vibrio species) consider adding doxycycline 100 milligrams indications (see last column to the right) Piperacillin­tazobactam .5 grams IV IV every  hours,† plus ceftriaxone  gram IV every  hours.† every  h†
Or meropenem 500–1000 milligrams
IV every  h†
Or imipenem­cilastatin 500 milligrams IV every  h†
Abbreviation: MRSA = methicillin­resistant Staphylococcus aureus.
*Purulent cellulitis is defined as cellulitis with drainage or exudate in the absence of a drainable abscess. In all cases of purulent cellulitis, the presence of an abscess should be carefully investigated clinically and drained. Bedside US can help diagnose occult abscess formation and verify complete drainage after procedure.
†Optimal treatment duration has not been established. For mild to moderate disease, 5­day oral treatment regimens have been successful but are recommended only in settings where follow­up at  days is feasible.
‡
Not recommended if local resistance is >10%.
#Physicians should use their clinical judgment; there are no validated criteria to differentiate moderate from severe signs for systemic infection.
fCriteria for sepsis in the presence of an infection are two or more of the following: temperature >38°C, tachycardia (>90 beats/min), tachypnea (respiratory rate >24 breaths/min), WBC count <400 cells/mm3 or >12,000 cells/mm3, or immunocompromised patients (see Chapter 151, “Sepsis”). Hypotensive patients should be admitted to the intensive care unit.
Treatment of Nonpurulent Cellulitis/Erysipelas
,23
Guidelines no longer differentiate the treatment of nonpurulent cellulitis from erysipelas. Oral antibiotics are sufficient for simple cellulitis or erysipelas in otherwise healthy adult patients. In cases where there is no evidence of drainage or identifiable abscess, empiric MRSA coverage is not
,18,27 necessary. POCUS to confirm lack of an abscess is highly recommended. MRSA coverage should be considered in patients who are diabetic,
,18 immunosuppressed, have peripheral vascular disease, have a history of IV drug abuse, or require hospitalization. Due to the rise of antibiotic resistance as well as the efficacy of shorter durations of therapy, guidelines no longer recommend extended­treatment regimens and instead endorse
27A
5­6 days of therapy, especially for patients who can self­monitor and have close follow up. See Table 152­5 for guideline­recommended antibiotic
,23 options. Consider surgical consultation in patients with bullae, crepitus, pain out of proportion to examination, or rapidly progressive erythema with signs of systemic toxicity, because these signs and symptoms suggest necrotizing infection (see later section on necrotizing fasciitis).
TABLE 152­5
Empiric Treatment of Nonpurulent Cellulitis*/Erysipelas
Guide by Severity of Illness Antibiotics Comments
Oral antibiotics for mild disease: Cephalexin 500 Cultures are not recommended because of poor yields.
Typical cellulitis/erysipelas with no focus of milligrams PO Consider MRSA coverage in patients who are diabetic or immunosuppressed, purulence and no signs of systemic infection every  h† have peripheral vascular disease or history of IV drug abuse, or require hospitalization.
Or dicloxacillin
Patients should receive a 5­6 day course, particularly for patients able to self­
500 milligrams PO every  h† monitor and who have close follow up with primary care27A
Orclindamycin
150–450 milligrams PO every  h†
Monotherapy IV antibiotics for moderate Ceftriaxone  gram Patients who have failed to improve on outpatient antibiotics or are unable disease: IV every  h† to tolerate oral antibiotics should be admitted to the hospital and receive IV
Typical cellulitis/erysipelas with mild to moderate antibiotics, with coverage dependent on severity of illness.
Or cefazolin 
‡ systemic signs of infection gram every  h†
If immunocompromised, see below.
Orclindamycin
600 milligrams IV every  h†
Broad­spectrum antibiotics for severe Vancomycin  . Consider immediate consultation with surgery for possible debridement disease (including necrotizing fasciitis): milligrams/kg IV (see later section on necrotizing fasciitis for further recommendations).
Those with sepsis# or those with clinical signs of every  h† . Blood cultures recommended in this treatment group.
deeper infection such as bullae, skin sloughing, Plus piperacillinhypotension, or evidence of organ dysfunction tazobactam, .5
Or an immunocompromised patient grams IV every  h†
Or meropenem,
500–1000 milligrams IV every  h†
Or imipenemcilastatin, 500 milligrams IV every  h†
Different/additional coverage for patients Fresh water . Consider immediate consultation with surgery for possible debridement with selected indications exposure (see later section on necrotizing fasciitis for further recommendations).
(suspected . Blood cultures recommended in this treatment group.
Aeromonas species):
Doxycycline 100 milligrams IV every  h†
Plusciprofloxacin
500 milligrams IV every  h†
Salt water exposure
(suspected Vibrio species):
Doxycycline 100 milligrams IV every  h†
Plus ceftriaxone  gram every  h†
Suspected
Clostridium species:
Clindamycin 600–
900 milligrams IV every  h†
Plus penicillin 2–4 million units IV every  h†
Abbreviation: MRSA = methicillin­resistant Staphylococcus aureus.
*If exudate or abscess is found on exam, the patient should be treated for purulent cellulitis; see Table 152­4 for treatment recommendations
†Patients should receive a 5­6 day course, particularly for patients able to self­monitor and who have close follow up with primary care.27A
‡
Physicians should use their clinical judgment; there are no validated criteria to differentiate moderate from severe signs of systemic infection.
#Criteria for sepsis in the presence of an infection are two or more of the following: temperature >38°C, tachycardia (>90 beats/min), tachypnea (respiratory rate >24 breaths/min), WBC count <400 or >12,000 cells/mm3, or immunocompromised state (see Chapter 151, “Sepsis”). Hypotensive patients should be admitted to the intensive care unit.
DISPOSITION AND FOLLOW­UP
Admit patients with cellulitis or erysipelas and evidence of systemic toxicity and those with underlying comorbidities such as diabetes mellitus, alcoholism, or immunosuppression (see later section on necrotizing fasciitis). Healthy patients without systemic toxicity can be discharged to home with close follow­up in  to  days. Mark the patient’s skin with an indelible marker along the perimeter of infection so healing can be determined at follow­up; marks also aid the patient in evaluating worsening infection. Reported risk factors for failure of empiric antibiotic therapy include fever,
 lymphedema or chronic edema, chronic leg ulcers, prior cellulitis in the same area, and cellulitis at a wound site.
CUTANEOUS ABSCESSES, FURUNCLES, AND CARBUNCLES

Furuncles and carbuncles involve the epidermis, and abscesses involve the deeper soft tissue. Skin abscesses, furuncles, and carbuncles can develop in otherwise healthy patients with no risk factors other than skin or nasal carriage of S. aureus. Persons in close contact with those who have an active infection with a skin abscess are at increased risk.
PATHOPHYSIOLOGY
Skin abscesses typically begin as a local superficial cellulitis. Many organisms that colonize normal skin can cause necrosis and liquefaction with subsequent accumulation of leukocytes and cellular debris; however, MRSA causes the majority of skin abscesses presenting to the ED in the United
,14
States. Loculation and subsequent walling off of these products of infection lead to abscess formation. As the infection progresses and the area of liquefaction increases, the abscess wall thins and ruptures spontaneously, draining either cutaneously or into an adjoining tissue compartment.
Infection can be caused by one or multiple pathogens that typically include skin flora or organisms from adjacent mucous membranes. Pathogens implicated in folliculitis are those that can cause furuncles and carbuncles, namely Pseudomonas, Candida, and others.
Any process causing a breach in the skin barrier heightens the risk for a skin abscess. Examples include trauma, such as abrasions or shaving; skin foreign bodies; insect bites; and IV drug abuse. Other risk factors include diabetes mellitus and immunologic abnormalities. Patients with oral, rectal, or vulvovaginal abscesses are more likely to be infected with multiple organisms, including gram­negative and anaerobic organisms.
CLINICAL FEATURES
Skin abscesses are fluctuant, tender, erythematous nodules, often with surrounding erythema (Figure 152­4). Spontaneous drainage of purulent material may occur, and local lymphadenopathy may be present. Signs of systemic toxicity, fever, or chills are rare in the case of simple abscesses. In uncommon cases, skin abscesses may be the result or cause of bacteremia.
FIGURE 152­4. Subcutaneous abscess is noted in the axilla. [Reproduced with permission from Slaven EM, Stone SC, Lopez FA: Infectious Diseases: Emergency
Department Diagnosis & Management, © 2006, McGraw­Hill, Inc., New York.]
Furuncles are clinically very similar to abscesses, and systemic toxicity is rare. Carbuncles are larger infections commonly associated with fever and malaise. Carbuncles are most common on the upper back, chest, buttocks, hips, and axilla but can occur in any hair­bearing region of the body.
DIAGNOSIS

The diagnosis of skin abscesses, furuncles, and carbuncles is clinical; however, physical exam is unreliable for nonsuperficial abscesses. POCUS is an invaluable tool for distinguishing deep abscess from cellulitis, identifying a foreign body within an abscess, and determining the adequacy of
,30,31 drainage (Figure 152­5).
FIGURE 152­5. Long­axis sonogram of a deep midline buttock abscess in the region of the gluteal fold. The skin and immediate subcutaneous tissue exhibit relatively normal echogenicity. The deeper tissues surrounding the rounded abscess cavity appear more hyperechoic and edematous. Note that the superior edge of this large abscess cavity is .5 cm from the skin surface (arrow). [Reproduced with permission from Ma OJ, Mateer JR, Reardon RF, Joing SA:
Ma & Mateer’s Emergency Ultrasound, 3rd ed. New York, NY: McGraw­Hill, Inc.; 2014. From Chapter 18: Musculoskeletal, Soft Tissue, and Miscellaneous
Applications, Figure 18­105, p. 561.]
Radiography is not needed routinely, unless a radiopaque foreign body or underlying osteomyelitis is suspected. Disorders that can mimic abscesses include folliculitis, hidradenitis suppurativa, sporotrichosis, leishmaniasis, tularemia, and blastomycosis, as well as conditions in immunocompromised persons such as Nocardia and Cryptococcus. Wound cultures are not recommended for simple abscess drainage; however,
 guidelines recommend cultures when antibiotics are given.
TREATMENT
It is best to drain extremely large abscesses or those in deep areas in the operating room. Abscesses of the palms, soles, or nasolabial folds can be
 associated with complications and usually require a specialist. Input from an appropriate specialist is also recommended in areas of the body with
 cosmetic concerns.
In the case of small furuncles (boils), warm compresses can be used to promote drainage, and no other treatment is needed. Sitz baths are helpful for furuncles in the buttock or perineal regions. Repeat evaluation in  to  days is best to determine whether suppuration has occurred and surgical drainage is required.

Large furuncles, carbuncles, and skin abscesses require incision and drainage. Simple needle aspiration of abscesses is inadequate to treat
 abscesses caused by MRSA. Prior recommendations for endocarditis prophylaxis in patients undergoing incision and drainage have changed (see
Chapter 156, “Endocarditis”). If indicated by the severity of valvular heart disease, the most common regimen is either clindamycin 600 milligrams IV or vancomycin  gram IV,  to  minutes before the procedure.
Incision and Drainage Procedure
Before the incision and drainage procedure, obtain consent and explain complications. Use universal precautions, including a face shield with eye protection, because many abscesses are under pressure. There are few complications with superficial abscesses, but these include residual local numbness, the risk of injury to deeper nerves and blood vessels, and poor or delayed wound healing, especially in those with diabetes or peripheral vascular disease. Plan the incision along tension lines to minimize scarring if possible, especially in areas of cosmetic significance.
Position the patient for good access, prepare the area with povidone­iodine solution, and drape in a sterile fashion. To provide local anesthesia, approach the abscess from the side and slowly infiltrate the skin over the abscess. Then infiltrate deeper until resistance of the wall of the abscess cavity is overcome. Distend the abscess with several milliliters of lidocaine, taking care to shield the patient and operator from any material forced from the wound due to pressure. The inflamed abscess wall absorbs the lidocaine and lessens pain associated with the procedure.
After appropriate anesthesia, using a No.  or  scalpel blade, incise the abscess over the area of greatest fluctuance, using the results of preparatory
US evaluation to guide the length of the incision. Incisions that are too small or superficial are not likely to provide effective drainage. Express as much pus as possible by gentle compression. Insert a hemostat into the abscess cavity, opening and closing the jaws to break up loculations.
,36
Irrigation of the cavity with saline followed by packing with gauze ribbon to promote drainage is commonly done, but the benefit is uncertain. Less
 painful alternatives to packing include placing a catheter, or tying in a rubber drain after placing two small stab incisions, using a small forceps to
 reach into one incision, coming out the other, and pulling the drain back through the track before making a knot. Primary closure after abscess
  drainage shortens healing time for patients treated in the operating room and has been studied in a small randomized controlled trial in the ED ; however, recommendations for its use await larger trials.
If placed, maintain packing, catheter, or drain long enough for the cavity to heal from the inside out and to prevent re­collection of pus. Patients should apply warm compresses or soaks three times a day. Schedule a follow­up visit in  to  days for recheck. Maintain catheter or replace packing if the cavity is still draining at the follow­up visit.
Adjuvant Antibiotics
Recent studies suggest that in patients with a simple abscess, MRSA antibiotic coverage in conjunction with incision and drainage improves short­term
41­43 outcome. However, the benefit of antibiotics as an adjunct to sufficient abscess drainage must be weighed against the known side effect profile,
,45 especially in healthy patients without significant surrounding cellulitis. Guidelines recommend antibiotics for patients with multiple lesions, extensive surrounding cellulitis, immunosuppression, or signs of systemic infection; see Table 152­4 for indications and specific antibiotics
 recommended.
DISPOSITION AND FOLLOW­UP
Most patients with skin abscess, furuncles, and carbuncles are treated as outpatients. Those with systemic toxicity or severe infection typically require
 parenteral treatment and hospital admission. Age, failed oral antibiotics, and injection drug use impact admission decisions. For those discharged to
 home, remind patients to keep the wound covered and practice frequent hand washing to prevent spread of the infection. Patients with open wounds should not participate in activities involving skin­to­skin contacts, such as wrestling or football, until wounds are fully healed. Individuals should not share items such as towels, clothing, soap, razors, or other items that come in contact with a contaminated wound.
NECROTIZING SOFT TISSUE INFECTIONS
Necrotizing soft tissue infections are a spectrum of illnesses characterized by fulminant, extensive soft tissue necrosis, systemic toxicity, and high
,47 mortality. Early in their course, these infections can appear deceptively benign. Terms used to describe necrotizing soft tissue infections are
Fournier’s gangrene (see Chapter , “Male Genital Problems”), necrotizing fasciitis, necrotizing soft tissue infection, or gas gangrene. Risk factors for necrotizing soft tissue infections are advanced age, diabetes mellitus, alcoholism, peripheral vascular disease, heart disease, renal failure, human
,49 immunodeficiency virus, cancer, NSAID use, decubitus ulcers, chronic skin infections, IV drug abuse, and immune system impairment. However, infections also occur in young and healthy individuals. The incidence is increasing, but mortality has decreased in the United States from 25% to 10%
 over the past  years. Bacteremia is reported in 25% to 30% of cases and is a strong predictor of mortality. Other patient factors that increase mortality are age <1 year old or >60 years old; IV drug use; comorbid conditions, especially cancer, chronic renal disease, and congestive heart failure; and certain characteristics of the clinical course such as positive blood cultures, trunk or perineal involvement, infection related to peripheral vascular disease, and delayed time to diagnosis or treatment.
MICROBIOLOGY
Type I (polymicrobial) infections include 55% to 75% of all necrotizing soft tissue infections, and the causative microbes are a combination of gram­
 positive cocci, gram­negative rods, and anaerobes. Clostridial infections are now uncommon causes due to improvements in hygiene and sanitation.
Type II (monomicrobial) infections are most commonly caused by group A Streptococcus. Type II infection is less common (20% to 30%) than type I infection and tends to occur on an extremity in an otherwise healthy host who often has a history of trauma or has had a recent operative procedure at the site of the infection. Community­acquired MRSA is a cause of type II (monomicrobial) infection, particularly in IV drug abusers, athletes, and
,52 institutionalized patients. Necrotizing infection caused by Vibrio vulnificus is classified as a type III infection. This infection is more common in Asia and may occur in patients who have an apparently insignificant break in their skin in a seawater environment. Type IV is associated with fungal
 infections, primarily in immunocompromised patients.
PATHOPHYSIOLOGY
The rapid necrotizing process typically begins with direct invasion of subcutaneous tissue from external trauma (IV injection, surgical incision, abscess, insect bite, or ulcer) or direct spread from a perforated viscus (usually colon, rectum, or anus). Although spontaneous development is rare, it does occur, and risk factors include diabetes and underlying malignancy. Bacteria proliferate, invade subcutaneous tissue and deep fascia, and release
 exotoxins that lead to tissue ischemia, liquefaction necrosis, and systemic toxicity.
Skin involvement is secondary to vasculitis and thrombosis of perforating blood vessels. The ischemic tissue environment promotes bacterial growth, propagating the process and resulting in rapid spread of the infection, which can spread as fast as  inch/h. Because thrombosis of large numbers
 of capillary beds must occur before skin findings develop, early infection has little overlying skin change to indicate the extent of infection. As the
 disease progresses, widespread gangrene of the skin, subcutaneous fat, fascia, and even skeletal muscle occurs.
In polymicrobial infections, a symbiotic relationship between the different kinds of bacteria seems to promote the necrotizing soft tissue infection.
Facultative gram­negative organisms lower the oxygen reduction potential of the tissue and facilitate anaerobic organism growth. Anaerobic organisms impede phagocyte function, favoring aerobic bacterial growth. The alpha­toxin produced by the Clostridium species causes tissue necrosis and cardiovascular collapse. S. aureus and streptococci produce exotoxins and cause the release of tumor necrosis factor and cytokines that can produce the systemic inflammatory response syndrome and lead to septic shock, organ failure, and death.
CLINICAL FEATURES
,48
Classic symptoms of necrotizing soft tissue infections are severe pain, anxiety, and diaphoresis. Pain is often out of proportion to physical examination findings with tenderness beyond the area of erythema and thus is perhaps the single most important feature to make the diagnosis early.
However, some patients may have little pain, and as the condition progresses, the affected areas may become insensate. About 10% to 40% of the time, patients report trauma or a break in the skin roughly  hours before onset of symptoms.

On examination, the painful area may demonstrate a brawny edema, and crepitus caused by bacterial gas production may be present. The lack of crepitus does not rule out the diagnosis. Two different studies reported that the only signs present in >50% of patients were erythema, tenderness, or marked edema beyond the area of redness; crepitus was present in only 13% to 31% of patients. Late in the course of the infection, the skin can develop a bronze or brownish discoloration with a malodorous serosanguineous discharge, and bullae may be present (Figure 152­6).
FIGURE 152­6. Necrotizing soft tissue infection. Large cutaneous bullae are seen on the leg of this patient with necrotizing fasciitis. Note the dark purple fluid in the bullae. [Photo contributed by Lawrence B. Stack, MD. Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ: Atlas of Emergency
Medicine, 3rd ed. © 2010, McGraw­Hill, Inc., New York.]
Systemic manifestations include a low­grade fever with tachycardia out of proportion to the fever. In fulminant necrotizing infections, particularly from
V. vulnificus, patients may have cardiovascular collapse due to release of bacterial toxins and release of cytokines, and they may be confused, irritable, or have a rapid deterioration of mental status.
DIAGNOSIS
The diagnosis is based on clinical assessment in combination with laboratory tests and imaging when the clinical picture is unclear. One or more

“hard” signs of necrotizing fasciitis—crepitus, skin necrosis, bullae, hypotension, or gas on radiograph—are present in less than half of patients.
55­61
Many laboratory abnormalities have been investigated to aid in the diagnosis, including the laboratory risk indicator for necrotizing fasciitis
(LRINEC score). ,56 Since its derivation, the LRINEC score ≥6 has been proven to miss many cases of necrotizing fasciitis,  especially those caused by

Vibrio species, and neck infections. Table 152­6 lists laboratory factors and imaging findings associated with necrotizing fasciitis to help clinicians
55­64 with medical decision making. Emergency surgical consultation is required when entertaining the diagnosis of necrotizing fasciitis, rather than waiting for confirmatory studies that may yield equivocal results. There is no single test or sign that can reliably confirm the early diagnosis of
,49 necrotizing fasciitis. The finger test has been advocated, which involves making a 2­cm incision over involved tissue down to the fascia after local
 anesthesia, observing for normal blood flow, and inserting a gloved finger to test for normal tissue firmness. A positive test is lack of normal bleeding, or friable tissue to minimal finger pressure. However, its use has never been studied formally.
TABLE 152­6
Laboratory and Imaging Results Associated With Necrotizing Fasciitis
Laboratory Factors Associated With Necrotizing Fasciitis
Laboratory
Threshold Comments
Test
C­reactive >150 milligrams/L Positive result adds  in LRINEC score protein
WBC count >15,000 cells/mm3 Positive result adds  in LRINEC score, level >25,000 cells/mm3 adds 
Hemoglobin <13.5 grams/dL Positive result adds  in LRINEC score,* level <11 grams/dL adds  in LRINEC score* Sodium <135 mmol/L Positive result adds  in LRINEC score* Creatinine >1.6 milligrams/dL Positive result adds  in LRINEC score* Glucose >180 milligrams/dL Positive result adds  in LRINEC score* Potassium >5.0 mEq/L Associated with extremity infections
Band count >7% Associated with Vibrio species
Serum albumin ≤2.0 grams/dL Associated with Vibrio species
Platelets ≤80,000 Associated with Vibrio species
Imaging Findings Associated With Necrotizing Fasciitis
Imaging Test Finding Comments
MRI with Extensive thickening of the intermuscular fasciae with . Presence of gas is highly specific for necrotizing infection (but not contrast an appearance suggesting incomplete vascularization common).
. Absence of MRI abnormalities of the intermuscular fasciae virtually rules out necrotizing fasciitis.
CT with contrast . Fascial thickening of deep facial planes . Presence of gas is highly specific, but found in one third of cases or less.
. Nonenhancing deep fascia on contrast imaging . Accurate diagnosis requires contrast; acute kidney injury is common in suggesting necrosis patients with necrotizing fasciitis and may contraindicate IV contrast.
Ultrasonography . Fluid collections along the fascial plane Radiologists warn that abnormal superficial hyperechogenicity absorbs US
. Fascia irregularity and may block diagnostic deeper findings and give false reassurance.
. Subcutaneous air
Plain Gas in soft tissues Poor sensitivity radiographs
Abbreviation: LRINEC = laboratory risk indicator of necrotizing fasciitis.
*LRINEC score of ≥6 is associated with increased risk of necrotizing fasciitis but misses many cases and therefore should not be used in isolation for the diagnosis and management.
Plain radiographs may reveal subcutaneous gas in a minority of patients, but may miss deep fascial gas and are therefore a poor screening tool. CT with contrast is more sensitive (80% to 97%) but has a false­positive rate of 19%. The most reliable sign of necrosis on CT is nonenhancing deep tissues, which requires contrast, or gas, seen in ≤36% of patients.  IV contrast is a significant risk in this group of patients who frequently sustain acute
 renal failure due to sepsis. MRI has better sensitivity (90% to 100%), but false­positive rates are as high as 39%. Finally, MRI imposes significant delays
 to treatment. Bedside US has been advocated, but radiologists caution against excluding necrotizing fasciitis based on its findings.
TREATMENT
The tissue ischemia produced in necrotizing skin infections impedes immune system destruction of bacteria and prevents adequate delivery of
 antibiotics. Thus, antibiotics alone are rarely effective, and immediate surgical consultation and intervention remain the
 cornerstone of successful management. Begin aggressive fluid resuscitation immediately as well as transfusion of packed red blood cells as needed. Avoid vasoconstrictors, if at all possible, because vasoconstrictors will decrease perfusion to already ischemic tissue.
Surgery is the gold standard for diagnosis and treatment; however, treatment standards are primarily expert consensus based, rather than evidenced
  based. Surgical intervention may include fasciotomy, debridement, and/or amputation. Mortality skyrockets if debridement is delayed >24 hours.
See Table 152­5, “Empiric Treatment of Nonpurulent Cellulitis/Erysipelas,” the row titled “Broad­spectrum antibiotics for severe disease,” for patients with selected indications. Provide tetanus prophylaxis as indicated. Controversial therapies that are typically the decision of the surgical consultant include IV immunoglobulin therapy and hyperbaric oxygen therapy.
OTHER SOFT TISSUE INFECTIONS
FOLLICULITIS
Folliculitis is an inflammation of hair follicles related to infection, chemical irritation, or injury. It typically involves a superficial bacterial infection of the hair follicles with purulent material in the epidermis.
Epidemiology/Microbiology
Folliculitis is usually caused by S. aureus, and nasal carriage of this organism is a risk factor for folliculitis. “Hot tub folliculitis” or “whirlpoolassociated folliculitis” is often attributed to Pseudomonas species and occurs in inadequately chlorinated hot tubs, whirlpools, and swimming pools.
Symptoms of uncomplicated folliculitis and whirlpool­associated Pseudomonas folliculitis are often mild and self­limited, and patients do not seek medical attention.
Individuals exposed to whirlpool footbaths at nail salons are at risk for mycobacterial furunculosis. Candida species are implicated in patients
 receiving broad­spectrum antibiotics or glucocorticoids or who are otherwise immunocompromised.
Clinical Features
The most common sites of involvement for folliculitis are the apocrine areas of the upper back, chest, buttocks, hips, and axilla, but folliculitis can develop in any hair­bearing region of the body, especially in areas of repeated shaving. Folliculitis presents with clusters of pruritic, erythematous
 lesions that are usually <5 mm in diameter, with pustules sometimes present at the centers. Pseudomonas folliculitis can develop over areas exposed to contaminated water, and lesions are often larger (up to  cm in diameter).
Pseudofolliculitis is a related noninfectious condition more commonly seen in persons of African descent secondary to shaving. It occurs when the hair follicle becomes trapped and, instead of exiting the follicle, curls and grows into the follicular wall. Such findings in the beard region are called “sycosis barbae” or “folliculitis barbae” and can progress to deep infections that can cause facial scarring (see Chapter 250, “Skin Disorders: Face and Scalp”).
Diagnosis
Folliculitis is diagnosed clinically. It should be differentiated from other disorders, such as acne vulgaris, impetigo, fungal infections, contact dermatitis, scabies, insect bites, and viral disorders such as herpes.
Treatment/Disposition and Follow­Up
For simple cases of uncomplicated folliculitis or hot­tub folliculitis, stopping exposure or removing the offending agent and twice­daily cleansing with mild hand soap often suffice. Lesions usually resolve spontaneously, but if desired, warm compresses may be applied several times daily, and a topical antibiotic such as bacitracin or polymyxin B can also be used. Shaving should be avoided in the involved areas. Pseudofolliculitis is managed by allowing the hairs to grow  to  mm above the surface and afterward using commercially available razors designed for this condition. For painful or more extensive cases, oral antibiotics with activity against Streptococcus and Staphylococcus, such as cephalexin, dicloxacillin, or azithromycin, are recommended.
INFECTED EPIDERMOID AND PILAR CYSTS
Epidermoid cysts originate from the epidermis, and pilar cysts originate from hair follicles; both contain a thick, cheesy collection of keratin, not sebum. True sebaceous cysts, as these cysts have erroneously been called in the past, are rare. Sebaceous glands occur diffusely throughout the body.
Blockage of the duct of a sebaceous gland may lead to development of a glandular cyst that can exist for a long period without becoming infected. Once bacterial invasion occurs, abscess formation is common. An infected epidermoid or pilar cyst is an erythematous, tender, fluctuant cutaneous nodule.
Simple incision and drainage procedure is the appropriate ED treatment. The cyst always contains a capsule that must be removed to prevent further infection. Capsule excision is typically done at follow­up when the initial inflammation has improved or resolved. Occasionally, the wall of the sac can be grasped with forceps and removed at the time of drainage.
SPOROTRICHOSIS
Sporotrichosis is a mycotic infection caused by the fungus Sporothrix schenckii.
Epidemiology

Sporotrichosis occurs worldwide but is most common in tropical and subtropical zones. It is endemic in Central and South America and in Africa. The organism is found most commonly in soil, sphagnum moss, and decaying vegetable matter. It is a common disease among florists, gardeners, and agricultural workers. Inoculation into the host most often occurs when a spine or barb on a plant punctures the skin during handling. Approximately
10% to 62% of patients relate infection to penetrating trauma from plant thorns, wood splinters, or contaminated organic material.
Transmission from infected animals, especially cats, has been documented. Veterinary workers, animal handlers, and cat owners are therefore at increased risk. The typical patient is a healthy young adult, but the infection can also occur in immunocompromised individuals such as those with alcoholism, diabetes mellitus, hematologic malignancy, organ transplantation, or human immunodeficiency virus infection.
Pathophysiology
S. schenckii is a thermally dimorphic fungus that changes from its mycelial form to its yeast form on entering a body­temperature environment.
Disease is usually limited to local cutaneous or lymphocutaneous areas. Osteoarticular involvement, including osteomyelitis, septic arthritis, bursitis, and tenosynovitis, occurs and may extend from a local cutaneous infection or may be secondary to hematogenous spread. Although less common, transmission may occur through inhalation of the fungus through the upper respiratory tract, and subsequent hematogenic dissemination can occur.
When inhaled, granulomatous pneumonitis with cavitation may arise.
Clinical Features
The incubation period averages  weeks following initial inoculation, but varies from a few days to several weeks. After the fungus enters the body through a break in the skin, three types of localized infections may occur. The fixed cutaneous type is characterized by lesions restricted to the site of inoculation and may appear as a crusted ulcer or verrucous plaque (Figure 152­7). Local cutaneous­type infections also remain local but present as a subcutaneous nodule or pustule. The surrounding skin becomes erythematous and may ulcerate, resulting in a chancre. Local lymphadenitis is common. The lymphocutaneous type is the third and most common type. It is characterized by an initial painless nodule or papule at the site of inoculation that later develops subcutaneous nodules with clear skip areas along local lymphatic channels (Figure 152­8). The local reactions in all three types of infections tend to be relatively painless, but show no signs of improvement without treatment.
FIGURE 152­7. Fixed sporotrichosis. The ulcer and surrounding erythema of fixed cutaneous sporotrichosis could be confused with a brown recluse spider bite.
[Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, Inc., New York.]
FIGURE 152­8. Sporotrichosis. Chronic lymphocutaneous type—an erythematous papule at the site of inoculation on the index finger with a linear arrangement of erythematous dermal and subcutaneous nodules extending proximally in lymphatic vessels of the dorsum of the hand and arm. [Reproduced with permission from Wolff K, Johnson RA: Fitzpatrick’s Color Atlas and Synopsis of Clinical Dermatology, 6th ed. © 2009, McGraw­Hill, Inc., New York.]
Patients occasionally develop extracutaneous illness from what is most probably hematogenous spread. Most cases of extracutaneous sporotrichosis involve the skeletal system. An indolent form of monoarticular arthritis is the most common symptom. Osteomyelitis, tenosynovitis, and carpal tunnel syndrome are occasionally seen as well. Multiarticular arthritis is usually only seen in patients with immunocompromise. Pulmonary involvement is rare, typically occurring in elderly alcoholic males and clinically resembling tuberculosis. Chronic lymphocytic meningitis can be a delayed complication of sporotrichosis infection and should be considered in patients with chronic meningeal symptoms.
Diagnosis

History and physical findings are the keys to diagnosis. Fungal cultures are the best way to isolate the fungus, and tissue biopsy cultures often are diagnostic. Pus, synovial fluid, sputum, blood, or tissue fragment is suitable for culture.
Routine laboratory tests are nonspecific, but an increased WBC count, eosinophil count, and erythrocyte sedimentation rate may occur. The differential diagnosis includes tuberculosis, subcutaneous abscesses of tularemia, cat­scratch disease, leishmaniasis, staphylococcal lymphangitis, paracoccidioidomycosis, chromoblastomycosis, blastomycosis, bacterial pyoderma, primary syphilis, and infections caused by atypical mycobacteria such as Mycobacterium marinum.
Treatment
Itraconazole (100 to 200 milligrams daily for  to  weeks after all lesions have resolved) is the treatment of choice for localized and systemic
 infections. Fluconazole is less effective than itraconazole and should be reserved for those few patients not tolerating itraconazole. Ketoconazole has shown even poorer results than fluconazole. IV amphotericin B is effective, but adverse reactions limit its use to disseminated forms of the disease.
In endemic regions or in epidemic outbreaks, a saturated solution of potassium iodide is an effective low­cost alternative.


