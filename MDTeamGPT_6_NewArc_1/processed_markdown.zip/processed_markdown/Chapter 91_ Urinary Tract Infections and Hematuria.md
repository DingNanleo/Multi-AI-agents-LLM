## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 91: Urinary Tract Infections and Hematuria
Kim L. Askew
Content Update CDC Treatment Guidelines 2021 for Gonococcal and Nongonococcal Urethritis (NGU) October 2021
See new Table 91­5, and reference 35C.
Content Update Duration of Outpatient Antibiotic Treatment August 2021
The trend toward shorter duration outpatient treatment, as little as  days for those with uncomplicated cystitis, is reflected in Table 91­5, and references 35A and 35B.
URINARY TRACT INFECTIONS

In 2015, urinary tract infection (UTI) was the seventh most common diagnosis in women older than  years of age presenting to EDs. Between 2006
 and 2009, .8 million patients were evaluated in EDs due to UTIs, with .8 million admissions. Most visits for UTIs occur in younger women, with
 nearly half of all women experiencing a UTI during their lifetime. Starting at age , men experience an increasing frequency of UTIs as they grow older
 due to prostatic hypertrophy, debilitation, and instrumentation for relief of urinary obstruction. All age groups from neonates to the elderly are affected, with greater risks in special populations (see Chapter 135, “Urinary Tract Infection in Infants and Children,” and Chapter , “Comorbid
Disorders in Pregnancy”).
PATHOPHYSIOLOGY AND DEFINITIONS
UTIs can be grouped based on the anatomic site involved as well as patient characteristics. These classifications are important when determining treatment modalities.
ASYMPTOMATIC BACTERIURIA
Asymptomatic bacteriuria is defined by several criteria:

. The presence of >100,000 (>10 ) colony­forming units (CFU)/mL of a single pathogen on two successive clean­catch urine cultures in a woman
 without symptoms.

. The presence of >100,000 (>10 ) CFU/mL on one clean­catch urine culture in asymptomatic men.
. The presence of 100 CFU/mL of a single isolate in a catheterized urine specimen in a patient without symptoms.
Prevalence of asymptomatic bacteriuria is .5% in the general population, but can be up to 10% in pregnant woman, 30% in male and 55% in female
 residents of nursing homes, and up to 100% in patients with indwelling catheters for more than  month. Treatment of asymptomatic bacteriuria is recommended only in pregnant women (see Chapter , “Comorbid Disorders in Pregnancy”) and in patients immediately prior to invasive urinary
 pDroowcendlouardese din  w0h2i5c­h7 m­1u 5c:o5s8a lP b leYeoduirn IgP m isa y1 3o6cc.1u4r.2.159.127
Chapter 91: Urinary Tract Infections and Hematuria, Kim L. Askew 
U©R20E2T5H MRIcTGISra AwN HDil lC. AYSll TRIiTgIhSts Reserved. Terms of Use * Privacy Policy * Notice * Accessibility
Infections of the lower urinary tract include urethritis and cystitis.Acute cystitis is an infection and inflammation isolated to the bladder.
Cystitis from an infection typically starts with colonization of the urethra by a pathogen from the GI system, which migrates into the bladder. Cystitis is typically diagnosed clinically by presence of dysuria, urinary frequency, and hematuria. Urine cultures in as many as 30% to 50% of women with cystitis
 have 100 to ,000 CFU/mL, which may be reported as negative by some laboratories. Urethritis, commonly associated with sexually transmitted diseases, presents with similar symptoms but typically is associated with a discharge, lesions, or irritation. In women who have dysuria and urinary
 frequency without vaginal discharge or irritation, the probability of cystitis increases to greater than 90%.
PYELONEPHRITIS
Pyelonephritis is an infection of the upper urinary tract.Acute pyelonephritis is infection of the renal parenchymal and pelvicalyceal system.
Pyelonephritis is differentiated from cystitis primarily by clinical findings: a syndrome of flank pain or costovertebral angle tenderness, with or without
 8­11 fever, in the setting of a positive urine culture of  CFU/mL, and frequently other systemic symptoms such as nausea or vomiting. Infections of the upper urinary tract can progress into three patterns of renal infection not commonly considered part of the UTI spectrum: acute bacterial nephritis, renal abscess, and emphysematous pyelonephritis. These diagnoses are made based on imaging studies performed in patients who have an inadequate or atypical response to treatment for presumed acute pyelonephritis.
UNCOMPLICATED URINARY TRACT INFECTION
Uncomplicated UTI is a UTI in a patient without structural or functional abnormalities within the urinary tract or kidney parenchyma, without relevant comorbidities that place the patient at risk for more serious adverse outcome, and not associated
,8­11 with GU tract instrumentation. This classification is limited to young, healthy, nonpregnant women with normal anatomic and functioning urinary tracts. Women are more susceptible than men to UTIs due to a shorter urethra for uropathogenic bacteria to ascend. The traditional diagnostic criterion dating from 1960 had been a positive urine culture of   CFU/mL; however, in symptomatic patients, low­colony­count infections with ≥10  to
 ,8,10
 CFU/mL are clinically valid.
COMPLICATED URINARY TRACT INFECTION
Complicated UTI is infection involving a functional or anatomically abnormal urinary tract or infection in the presence of
 comorbidities that place the patient at risk for more serious adverse outcomes. Risk factors for complicated UTI, including UTI in males,
,10  are listed in Table 91­1. The diagnostic criterion is the isolation of  CFU/mL of urine culture. Unfortunately, patients with complicated UTIs are a very heterogeneous group, and few clinical trials have been conducted to guide management. In general, patients in this group are more likely to be
,11 ,11 infected with resistant organisms. Although older literature categorized pyelonephritis as a complicated UTI, current guidelines do not.
Uncomplicated pyelonephritis refers to the clinical syndrome of fever and flank pain or tenderness with or without vomiting in a woman with an anatomically normal urinary tract without comorbidities. However, the recommended treatment of women with uncomplicated pyelonephritis is similar to recommendations for patients with complicated UTI (see “Treatment” later in the chapter).
TABLE 91­1
Risk Factors for Complicated Urinary Tract Infection (UTI)
Risk Factor Comments
Male sex In young males, dysuria is more commonly secondary to sexually transmitted disease; suspect underlying anatomic abnormality in men with culture­proven UTI.
Anatomic abnormality of the urinary tract Indwelling urinary catheter, ureteral stent, nephrolithiasis, neurogenic bladder, polycystic renal disease, or or external drainage system recent urinary tract instrumentation.
Recurrent UTI plus additional risk factor(s) Recurrent UTI is common in patients with anatomic or functional abnormalities of the urinary tract; however, recurrent infection alone is not a criterion for complicated UTI.
Advanced age in men Presence of prostatic hyperplasia, recent instrumentation, or recent prostatic biopsy.
Nursing home residency With or without indwelling bladder catheter.
Neonatal state See Chapter 135, “Urinary Tract Infection in Infants and Children.”
Comorbidities Diabetes mellitus, sickle cell disease, others.
Pregnancy See Chapter , “Comorbid Disorders in Pregnancy.”
Immunosuppression Active chemotherapy, acquired immunodeficiency syndrome, immunosuppressive drugs.
Advanced neurologic disease Spinal cord injuries, stroke with disability, others.
Known or suspected atypical pathogens Non–Escherichia coli infections.
Known or suspected resistance to typical Resistance to ciprofloxacin predicts multidrug resistance.
antimicrobial agents for UTI
Catheter­associated UTI (CAUTI) refers to a UTI occurring in a person whose urinary tract is currently catheterized, or has been within the previous 
,12 hours. CAUTI is one of the most common healthcare­acquired infections due to common use of urethral catheters in both acute care and long­
 term healthcare facilities. The best way to prevent infections after catheterization is to perform catheterization only for strict indications. As the duration of catheterization lengthens, the risk of bacteriuria increases. Identification of bacteriuria is complicated by contaminated biofilm along the catheter. Patients with chronic catheters often have repetitive exposures to antibiotics and thus can develop antimicrobial­resistant organisms.
Although a patient with a urinary catheter may have bacteriuria present, treatment for CAUTI is not indicated without additional symptoms. CAUTI is diagnosed when a patient has signs or symptoms compatible with a UTI with no other source identified and the presence of ≥10  CFU/mL of one or
 more bacterial species from a catheter urine specimen or midstream voided specimen if the catheter has been removed in the prior  hours.
RECURRENT URINARY TRACT INFECTION
,15
Recurrent UTI is defined as two uncomplicated UTIs in  months or three or more uncomplicated UTIs in the preceding  months. Recurrent UTIs can be classified into two different categories that affect treatment decisions: relapse and reinfection. Relapse of UTI is a recurrence of a UTI within  weeks of treatment completion caused by the same organism from a focus within the urinary system. Reinfection is a recurrent
UTI caused by a different bacterial isolate or by previously isolated bacteria after a negative intervening culture or a period of >2 weeks between
 infections. Reinfection is more common than relapse. Genetic, anatomic, and behavioral factors can lead to increased risk for uncomplicated UTIs.
The strongest behavioral risk factors for recurrent UTI (in women) are the frequency of sexual intercourse and the use of a diaphragm and
,16 spermicide.
MICROBIOLOGY
UTIs typically arise from ascending infection from the urethra to the bladder, although hematogenous and lymphatic spread can occur. Uropathogenic
,18 organisms often have adhesions, fibrillae, or pili that allow the bacteria to adhere to and invade the uroepithelium. Escherichia coli remains the
,18 most common pathogen by a large margin (Table 91­2).
TABLE 91­2
Etiologic Agents in Different Types of Urinary Tract Infection (UTI)
Uncomplicated UTI Escherichia coli (75%)
Staphylococcus saprophyticus
Klebsiella pneumoniae
Enterococcus faecalis
Complicated UTI E. coli
Enterococcus spp.
K. pneumoniae
Candida spp.
Staphylococcus aureus
Proteus mirabilis
Pseudomonas aeruginosa
Catheter­associated UTI* E. coli
Enterococcus spp.
Coagulase­negative Staphylococcus
Candida spp.
P. aeruginosa
P. mirabilis
Morganella morganii
Recurrent UTI Same as above depending on patient risk factors
*Long­term catheters (>30 days) will typically have polymicrobial etiologies of catheter­associated UTI.

First reported in 1983, but with an increase since 2000, community­acquired extended­spectrum β­lactamase–producing E. coli has emerged as a
19­21 small but growing source of antibiotic resistance, affecting approximately 4% to 6% of outpatients with UTI. Emergence of this resistant isolate of

E. coli has important implications for treatment (see “Treatment” later in the chapter) and can increase mortality in those affected.
CLINICAL FEATURES
Clinical features of UTI vary by anatomic site involved and the patient’s risks for complicated UTI. Asymptomatic bacteriuria is a laboratory­based diagnosis (see earlier section, “Pathophysiology and Definitions”).
URETHRITIS
In males, dysuria with a urethral discharge indicates urethritis (see Chapter 153, “Sexually Transmitted Infections”). UTI is uncommon in healthy young adult males, but if the clinical diagnosis does not suggest urethritis or prostatitis in a male with dysuria, bacteriuria is likely due to UTI. In women, Chlamydia infection should be suspected in the following settings: a new sexual partner, a partner with urethritis, examination findings of cervicitis, or low­grade pyuria with no bacteria seen on urinalysis. Concurrent gonorrhea is common with Chlamydia infections.
CYSTITIS
Symptoms and signs of cystitis are frequency, urgency, hesitancy, suprapubic pain, visible (gross) hematuria, and/or suprapubic tenderness. The nature and severity of symptoms are determined by the etiologic organism(s), the portions of the urinary tract involved, and the patient’s ability to
 mount an immune and inflammatory response. A history of vaginal discharge or irritation is more often associated with vaginitis, cervicitis, or pelvic inflammatory disease than with UTI. Fever is uncommon with simple cystitis.
PYELONEPHRITIS
Flank pain, costovertebral angle tenderness, or specific renal tenderness to deep palpation may be associated with cystitis because of referred pain. However, when these findings occur, especially in association with fever, chills, nausea, vomiting, or prostration,
,11 the clinical diagnosis is acute pyelonephritis. Patients with pyelonephritis may or may not have coexistent symptoms of cystitis. The presentation of pyelonephritis may be subtle, and it might be difficult to distinguish lower from upper UTI, especially in patients who do not experience pain normally (those with spinal cord injury), immunocompromised patients, and the aged. A missed diagnosis of cystitis is unlikely to lead to patient
 deterioration ; in contrast, missed pyelonephritis could lead to untreated sepsis.
SEPSIS FROM URINARY TRACT INFECTION
Patients with a UTI may develop or present with sepsis. Patients with sepsis may or may not exhibit the symptoms listed earlier for cystitis or pyelonephritis as part of their presentation. Approximately 10% to 19% of patients treated for sepsis have an etiology from the genitourinary
,24 system. Presentation, evaluation, and management of sepsis can be found in Chapter 151, “Sepsis.”
COMPLICATED URINARY TRACT INFECTION
For patients at risk for complicated UTI (Table 91­1), the clinical features and the classic presenting signs and symptoms of UTI may vary widely or be entirely absent. Fever, pain, and an inflammatory response may be absent. Suspect UTI in more complicated cases involving patients with atypical and diverse signs and symptoms, including weakness, malaise, altered mental status, fever, and flank or abdominal pain. Guidelines suggest the following criteria be used to define symptomatic CAUTI: new onset or worsening of fever, rigors, altered mental status, malaise, or lethargy with no other identified cause; flank pain; costovertebral angle tenderness; acute hematuria; and pelvic discomfort; and in those whose catheters have been
 removed, dysuria, urgent or frequent urination, or suprapubic pain or tenderness. In patients with spinal cord injury, increased spasticity, autonomic
 dysreflexia, and sense of unease are also compatible with CAUTI.
DIAGNOSIS
,25
A definitive diagnosis of UTI combines appropriate historical findings with laboratory confirmation. However, a clinical diagnosis of UTI is made in the ED based on history, physical exam, and supportive laboratory findings (rather than confirmatory culture) for the overwhelming majority of
,11 patients. This clinical diagnosis is used to initiate treatment in most patients, many of whom will have cultures pending definitive confirmation.
Regarding uncomplicated cystitis, a clinical diagnosis can be made with a moderate probability based on a history of dysuria, frequency, and urgency,
 in the absence of vaginal discharge or irritation, in women who have no other risk factors for complicated UTIs. However, the false­positive rate for
,27 the diagnosis of UTI based on history alone has been reported to be 33%. Empiric treatment of uncomplicated cystitis based on history alone in
,26,28 select women continues to be advocated in the emergency medicine, family medicine, and general internal medicine literature, while other
29­33 authors advocate laboratory confirmation to reduce the growing problem of antibiotic resistance. Delaying treatment while awaiting cultures is not practical in the ED and jeopardizes a large subset of patients who require treatment but may be lost to follow­up.
URINALYSIS
The clean­catch, midstream voiding specimen is as accurate as urine obtained by catheterization if the patient follows instructions carefully. If the sample is properly collected, it should contain no or few epithelial cells. Bacteria in urine double each hour at room temperature, so urine should be refrigerated if not sent directly to the laboratory. Catheterization is indicated if the patient cannot void spontaneously, is too ill or immobilized, or is extremely obese.
Visual inspection or assessment of the odor of the urine is unreliable in determining infection. Table 91­3 lists normal reference values for urinalysis.
UTI often results in positive dipstick test for protein in the urine, but this finding is not specific enough to be useful in diagnostic decision making to rule in infection.
TABLE 91­3
Normal Urinalysis Results
Value Normal Range Specimen Type
RBCs, female 0–5/HPF Centrifuged specimen
RBCs, male 0–3/HPF Centrifuged specimen
WBCs 0–4/HPF Centrifuged specimen
Bacteria None/HPF Centrifuged specimen
Leukocyte esterase None—dipstick test Fresh urine
Nitrite None—dipstick test Fresh urine
Abbreviations: HPF = high­power field; RBCs = red blood cells.
Values for individual laboratories may differ from the listed norms in Table 91­3. Dipstick testing is performed on a fresh uncentrifuged urine. Urine for microscopic analysis is routinely centrifuged prior to analysis. If examination of uncentrifuged urine is desired, make a specific request to the laboratory to account for different normal values between centrifuged and uncentrifuged specimens.
NITRITE REACTION BY DIPSTICK TEST
The urine nitrite reaction has a very high specificity (>90%), and a positive result is very useful in confirming the diagnosis of a UTI caused by bacteria
 that convert nitrates to nitrite, primarily the coliform bacteria, including E. coli. Enterococcus, Pseudomonas, and Acinetobacter species do not convert nitrates to nitrites in the urine and therefore are not detected by the nitrite test. Unfortunately, the urine nitrite reaction has
 a low sensitivity (~50%), so it is not always useful as a screening examination because a negative result does not exclude the diagnosis of UTI.
LEUKOCYTE ESTERASE REACTION BY DIPSTICK TEST
Using positive culture results as the criterion standard, the leukocyte esterase urine dipstick test has an overall sensitivity of 62% to 98% and a
 specificity of 55% to 96% for identifying infection. Performance varies greatly when different culture criteria for UTI are used. A positive urinary dipstick nitrite or leukocyte esterase test result supports the diagnosis of UTI, but a negative test result does not exclude it in the correct clinical presentation.
URINE WBC COUNT OR PYURIA BY MICROSCOPY
The assessment of pyuria using standard centrifuged urine is imperfect due to variable specimen preparation techniques. A WBC count of >5 cells/high­power field (HPF) in a centrifuged specimen from a symptomatic patient is abnormal. Although the combination of pyuria and bacteriuria is likely to be found with typical coliform infection, lower degrees of pyuria with or without bacteriuria may be clinically significant, especially in the presence of UTI symptoms.
In a symptomatic patient who has <5 WBCs/HPF in a centrifuged specimen, other causes of false­negative pyuria should be considered such as dilute precentrifuged urine, systemic leukopenia, or patient self­treatment with leftover antibiotics. Pyuria may be intermittent or absent if the patient has an obstructed and infected kidney. In men, >1 or  WBCs/HPF in a centrifuged specimen can be significant when bacteria are present.
Urethritis and prostatitis are far more likely causes of pyuria in young males who are sexually active and complain of dysuria, regardless of the presence or absence of urethral discharge.
BACTERIURIA BY MICROSCOPY
Bacteriuria is a sensitive tool for detection of UTI in the symptomatic patient. The presence of any bacteria on a Gram­stained specimen of
 uncentrifuged urine (>1 bacterium/HPF or 1000×) is significant and highly correlates with culture results of >10 CFU/mL. For Gram­
 stained centrifuged specimens, >1 bacterium/HPF (1000×) is 95% sensitive and >60% specific to predict a culture with  CFU/mL. Both of these methods of looking for bacteria under the microscope fail to detect low­colony­count UTI or infection caused by Chlamydia. False­positive results can occur when vaginal or fecal contamination is present. Female patients with symptoms suggestive of UTI and vaginal discharge or dyspareunia should have a pelvic examination to investigate for pelvic inflammatory disease.
COMBINED RESULTS OF DIPSTICK TESTING, URINE CELL COUNTS, AND HISTORICAL INFORMATION
,31
Two meta­analyses found that classic historical findings of cystitis were weak predictors of positive culture or failed to predict cystitis. Vaginal discharge weakly decreased the likelihood of cystitis; however, in both studies, diagnostic accuracy was significantly improved using dipstick testing,
,31 particularly a positive test for nitrites. A 2013 systematic review of four ED­based studies pooled 948 patients using a reference culture threshold of

 to  CFU/mL and found that no single historical variable of cystitis could rule in or rule out infection, but a dipstick test positive for nitrates,
 moderate pyuria, and/or bacteriuria were accurate predictors of a UTI, effectively ruling in the diagnosis of UTI. However, no single test or combination of testing results can effectively rule out UTI in women presenting to the ED with symptoms of cystitis. Therefore, there will be a subset of women for whom test results are equivocal who should either be treated empirically or receive phone­in treatment based on culture, if follow­up cannot be ensured in  to  days.
URINE AND BLOOD CULTURE
For the patient with typical symptoms of cystitis or an uncomplicated UTI and “positive” findings on urinalysis—pyuria on microscopic examination, bacteria in a Gram­stained specimen, positive leukocyte esterase test result, and/or positive urine nitrite test result—urine culture is not required. The vast majority of patients respond to empiric therapy. Urine culture should be performed for the following patients: those with complicated UTI, pyelonephritis, sepsis, and recent antimicrobial therapy. If the patient is symptomatic, a single positive culture result is significant.
Results of blood cultures in patients admitted for clinical pyelonephritis are positive in up to 40% of cases; organisms in blood culture match those in
 urine culture in 97% of cases, and blood culture results usually do not alter management. The primary indication for blood cultures in patients with suspected UTI is clinical sepsis.
IMAGING
Renal imaging studies in adults are not indicated in otherwise healthy patients with uncomplicated UTIs who can be managed as outpatients. Imaging is typically reserved for the investigation of patients suspected of alternative diagnoses that may explain the symptoms (i.e., nephrolithiasis) or after
 failure of conventional treatment in patients with severe symptoms suggesting an undiagnosed complication, such as renal abscess. Other patients who should be considered for imaging include male, elderly, diabetic, severely ill patients, and those with acute worsening renal function (glomerular
 filtration rate <40 mL/min). The kidneys can be imaged with bedside US to evaluate for obstruction and focal parenchymal abnormalities. Plain film radiography and US have poor sensitivity for detection of intrarenal gas formation in emphysematous pyelonephritis. If kidney or ureteral stones or emphysematous pyelonephritis are suspected, CT is the best imaging modality. US assessment of postvoid residual volume can be assessed to
 determine causes for repeat UTIs or risk for UTI. In men, a residual volume >180 mL predisposes to bacteriuria. Data are not clear for women.
Table 91­4 lists the differential diagnosis for dysuria.
TABLE 91­4
Differential Diagnosis for Dysuria
Disorder Comments
Urinary tract infection Cystitis and pyelonephritis
Vaginitis/cervicitis Infections (STD), atrophy, allergy
Urethritis Infections (STD), allergy
Trauma Trauma involving vagina, urethra, or bladder
Allergy Typically a reaction to a hygienic product or spermicide
Bladder/urethral cancer May have prior history of unexplained hematuria
Nephrolithiasis May have prior history of kidney stone
Urethral stricture or obstruction May have prior history of STDs
Uterine/bladder/vaginal prolapse May be suggested by history of swelling or physical exam
Fistulas Ileovesicular, urethral, urethrorectal, bladder
Urethral foreign body Includes urethral stone disease
Urethral diverticulum —
Cystocele —
Chemical irritation Spermicides, cleansing douches, feminine hygiene products
Behavioral symptom without detectable pathology Consider previous rape, sexual abuse
Chronic disorders Chronic cystitis, chronic urethritis
Abbreviation: STD = sexually transmitted disease.
TREATMENT
ACUTE CYSTITIS AND UNCOMPLICATED URINARY TRACT INFECTION
Selection of antibiotics depends on the organism suspected of causing the infection, the patient’s ability to adhere to the treatment regimen, local resistance patterns, potential drug toxicity, and cost. The Infectious Disease Society of America and the European Society for Microbiology and
,11,35A,35B
Infectious Disease published updated recommendations on antibiotics for uncomplicated UTI in 2010 (Table 91­5). Updated European
 guidelines have been incorporated into recommendations.
TABLE 91­5
Guidelines for Outpatient Management of Urinary Tract Infection (UTI) Including Pyelonephritis (see * footnote for pregnancy)
Patient UTI Type Antimicrobial Regimens Culture/Treatment Comments
Adult Lower (cystitis), Nitrofurantoin No initial culture is required.
female uncomplicated monohydrate/macrocrystals, 100 Consider community resistance; if >20%, use another agent. Amoxicillin­clavulanate, milligrams twice a day × 3­5 d† cefpodoxime­proxetil, cefdinir, and cefadroxil in 3­ to  or 7­d regimens are appropriate choices for therapy when other recommended agents cannot be used.
or
The fluoroquinolones should be reserved for important uses other than acute
TMP­SMX DS (160/800 milligrams), uncomplicated cystitis.
 tab twice a day ×  d or
Fosfomycin,  grams in single dose or (where available)
‡
Pivmecillinam , 400 milligrams twice a day × 3­5 d (lower efficacy than some other recommended agents; avoid if early pyelonephritis suspected)
Adult Lower (cystitis), Ciprofloxacin, 500 milligrams Urine culture is advised.
female upper twice a day × 5–7 d§ Consider community resistance; if >20%, use another agent. Coliforms are common.
or male (pyelonephritis), Treat for at least 5­7 d (mild symptoms) or  d (more severe symptoms, clear or complicated pyelonephritis). Admit if patient is significantly ill, unable to retain fluids or
Levofloxacin, 750 milligrams once medications, or pregnant. Consider IV dose of ceftriaxone if sensitivity uncertain.
a day × 5–7 d§ or
Only if susceptibilities are known, consider:
TMP­SMX DS (160/800 milligrams),  tab twice a day,  d minimum or
Amoxicillin­clavulanate,
875/125 milligrams twice a day × 7–14 d or
Cefpodoxime, 400 milligrams twice a day × 7–14 d
Adult Lower – Doxycycline 100 mg po bid ×  Commonest causative organisms: C. Trachomatis and M. genitalium
Female Nongonococcal days For persistent and recurrent NGU test for M. genitalium; arrange followup for test urethritis (NGU) or results*** (35C) Azithromycin  gm po; or 500 mg po then 250 mg po qd ×  days
Adult Gonococcal ceftriaxone 500 mg IM if <150 kg;  If chlamydia not excluded, add doxycycline 100 mg po bid ×  days; if pregnant,
Female infection of gm IM if > 150 kg; instead give azithromycin 1gm po cervix, urethra, If ceftriaxone not available, rectum (35C) cefixime 800 mg po as single dose;
If cephalosporin allergy, gentamicin 240 mg IM AND azithromycin  gm po
Abbreviations: DS = double strength; TMP­SMX = trimethoprim­sulfamethoxazole.
*β­Lactams, vancomycin, nitrofurantoin, metronidazole, clindamycin, and fosfomycin are generally considered safe in pregnancy. Avoid fluoroquinolones and tetracyclines in pregnancy.36
†Nitrofurantoin is not effective against Staphylococcus saprophyticus.
‡
Not currently available in the United States.
§Fluoroquinolones increase risk of rupture or tear of tendons and aortic wall; also increase risk of hypoglycemia and mental health side effects.
*** if M. genitalium is detected by an FDA­cleared NAAT, give doxycycline 100 mg po bid ×  days, then followed bymoxifloxacin 400 mg qd ×  days. For settings without resistance testing and when moxifloxacin cannot be used, give doxycycline 100 mg po bid ×  days; followed byazithromycin  gm po on day , followed byazithromycin 500 mg po qd ×  days, and a test­of­cure  days after completion of therapy.
Table 91­5 contains treatment recommendations for three separate groups of patients with UTI: (1) uncomplicated lower tract disease, (2) complicated
,12
UTI or pyelonephritis, and (3) women with UTI symptoms in whom coexistent urethritis cannot be excluded.
Trimethoprim­sulfamethoxazole continues to be recommended due to its limited adverse effects. Rates of resistance to trimethoprim­
 sulfamethoxazole are reported to be over the 20% threshold for treatment exclusion in the western and southern United States ; however, hospital
 culture data primarily reflect complicated UTI, and trimethoprim­sulfamethoxazole treatment may be successful for uncomplicated UTI. Fosfomycin has less efficacy than short courses of other regimens. Within regions, local resistance patterns vary widely and change rapidly. Three­day regimens of
35B pivmecillinam have similar clinical and microbial responses to 5­day and 7­day regimens. Pivmecillinam is not currently available in the US.

A 5­day course of extended­release nitrofurantoin is as effective as  days of trimethoprim­sulfamethoxazole therapy. A single 3­gram dose of
  fosfomycin is a first­line choice for uncomplicated UTI because the resistance rate is only 2%. Both nitrofurantoin and fosfomycin are recommended oral agents in the event of extended­spectrum β­lactamase–producing E. coli infection, because resistance is reported to be only 6%
 and 3%, respectively.
Because of bacterial resistance to traditional antibiotics used for UTI, use local sensitivities to guide the substitution of alternative agents such as cephalosporins. Third­generation cephalosporins are highly effective against enterobacteria, whereas first­generation cephalosporins are more effective against staphylococci. Amoxicillin­clavulanate is less effective than fluoroquinolones or oral cephalosporins for UTI due to enterobacteria. It also often leads to selection of Klebsiella. Aminopenicillins are therefore not recommended as first­line therapy in uncomplicated UTI.
If the patient has UTI symptoms and there is also suspicion of Chlamydia or Neisseria gonorrhoeae infection (cervicitis and/or salpingitis), antibiotic treatment is more complex. The patient should be tested and empirically treated for Chlamydia and N. gonorrhoeae (see
,43
Table 91­5; also see Chapter 153, “Sexually Transmitted Infections.” Fluoroquinolones were formerly recommended in this setting as a treatment for both cystitis and urethritis, but the Centers for Disease Control and Prevention no longer recommends them due to N. gonorrhoeae resistance. If coexistent cystitis is suspected in a patient with clinical urethritis, add a recommended treatment for cystitis (Table 91­5) to the treatment for urethritis; alternatively, culture the urine and treat for cystitis pending results.
ACUTE PYELONEPHRITIS AND COMPLICATED URINARY TRACT INFECTION
Recommendations for antibiotic therapy and cultures for patients whose condition is stable enough for outpatient treatment are listed in Table 91­5. ,11
Antibiotics for inpatient management are listed in Table 91­6. For patients with concern for sepsis, see Chapter 151, “Sepsis.” After clinical improvement has been achieved with parenteral antibiotics, treatment should be changed to oral agents as listed in Table 91­5 or by culture sensitivities. Patients may require fluid resuscitation with crystalloids to replace fluid losses due to vomiting or sweating. Although treatment courses
 as short as  days have been studied in patients with pyelonephritis and catheter­associated infections, guidelines recommend a total of  to  days
 of therapy for the majority, regardless of whether or not parenteral therapy is used. Men with UTI without immunocompromise may have improved
,45 outcomes with therapy for  days, rather than  days. For patients with sepsis syndrome, a total of  days of treatment may be required to
 eradicate bacteriuria. In patients with a CAUTI, replacement or removal of the catheter should be performed prior to collection of cultures and
 initiation of antibiotics.
TABLE 91­6
Empiric Initial Treatment for Inpatient Management of Pyelonephritis and Complicated Urinary Tract Infection
Ciprofloxacin, 400 milligrams IV every  h
Ceftriaxone, 1–2 grams IV once daily
Cefotaxime, 1–2 grams IV every  h
Gentamicin or tobramycin,  milligrams/kg/d divided every  h, ± ampicillin,  grams every  h
Piperacillin­tazobactam, .375 grams IV every  h
Cefepime, 1–2 grams IV every  h
Ertapenem,  gram IV every day
Imipenem, 500 milligrams IV every  h
Meropenem,  gram IV every  h
Note: Alternatives include ceftazidime, 1–2 grams IV every 8–12 h; amikacin, .5 milligrams/kg IV loading dose, then  milligrams/kg per dose every  h; and others based on local resistance and sensitivity patterns.
RECURRENT INFECTION
Women presenting to the ED with an acute UTI and a history of greater than two UTIs in  months or greater than three UTIs in  months should be
46­49 cultured, treated empirically, and referred to a primary care physician in  to  weeks for repeat culture and possible prophylaxis. The patient can
 be treated with recommended treatments for uncomplicated cystitis from Table 91­5 including 3­day regimens, unless the recurrence is a relapse
(see earlier section, “Pathophysiology and Definitions”). Treat relapse with an alternative agent, such as one of those recommended for complicated
 46­48
UTI (Table 91­5). Prophylaxis may take the form of continuous, postcoital, or intermittent self­treatment during symptomatic episodes. Woman
,48 with recurrent UTI using spermicide with contraception should be encouraged to inquire about an alternative method of contraception.
DISPOSITION AND FOLLOW­UP
The decision to admit a patient with UTI is based on age, host factors, and response to initial ED interventions. Admit patients who are unable to retain fluids and medication or those with systemic signs of UTI and a stone (see Chapter , “Urologic Stone Disease”), and choose antibiotics as listed in

Table 91­6. Eighty­four percent of patients are discharged. Healthy females tolerating fluids and medication with uncomplicated pyelonephritis are
 candidates for outpatient management. Adjunctive therapies at discharge include increased fluids and frequent voiding to diminish tissue contact with bacteria. An oral bladder analgesic, such as phenazopyridine (200 milligrams PO three times daily), reduces dysuria. Cranberry juice appears to be
  mildly effective in reducing the incidence of recurrent infection. There is no conclusive evidence that postcoital voiding prevents cystitis. Ask patients to return to the ED if they experience increasing pain, fever, or vomiting. Consider systemic analgesics and antiemetics for patients with pyelonephritis.
Complications of acute pyelonephritis include acute papillary necrosis with possible ureter obstruction, septic shock, perinephric abscesses, and emphysematous pyelonephritis. See Chapter 151, “Sepsis,” for the care of critically ill patients with UTI.
SPECIAL POPULATIONS
PREGNANCY
First­line treatment for asymptomatic bacteriuria and simple cystitis is either amoxicillin 500 milligrams PO two to three times daily for  to  days or
 cephalexin 500 milligrams two to four times daily for  to  days. Recent studies have raised concerns about possible nitrofurantoin­linked birth defects. Although it is still a pregnancy class B medication, current American College of Obstetricians and Gynecologists guidelines recommend to
 avoid use of nitrofurantoin in the first trimester unless there are no other options available. See Chapter , “Comorbid Disorders in
Pregnancy,” for detailed discussion.
PATIENTS WITH HUMAN IMMUNODEFICIENCY VIRUS INFECTION/ACQUIRED IMMUNODEFICIENCY SYNDROME
In human immunodeficiency virus (HIV) and acquired immunodeficiency syndrome (AIDS) patients, resistance to trimethoprim­sulfamethoxazole is increased due largely to its use in Pneumocystis jiroveci prophylaxis. Fluoroquinolones should be the initial antibiotic used for UTI in these patients unless urine culture and sensitivity test results are available to guide therapy. Most UTIs in HIV/AIDS patients are caused by typical pathogens or common sexually transmitted disease organisms. Mycobacterium tuberculosis is an infrequent cause of UTI in the HIV/AIDS population. Close outpatient follow­up (recheck in  week) and possible infectious disease consultation are warranted when treating UTI in this population (see Chapter
155, “Human Immunodeficiency Virus Infection”).
HEMATURIA
INTRODUCTION AND EPIDEMIOLOGY
Hematuria is encountered in ambulatory and ED settings, either as a primary complaint of visible blood in the urine or an incidental finding on urinalysis. Gross hematuria is visible to the eye, whereas microscopic hematuria is a laboratory diagnosis. Other pigments, particularly myoglobin, may
,30 discolor the urine and simulate gross hematuria. UTI is the most common cause of hematuria associated with urgency, dysuria, and nocturia ;
53­55 however, these symptoms are also common in the much smaller group of patients who ultimately are diagnosed with cancer of the urinary tract.
Painless hematuria is more often due to neoplastic, hyperplastic, and vascular causes.
It takes approximately  mL of whole blood per liter of urine to result in visible hematuria. Gross hematuria may also result in false proteinuria. The incidence of gross hematuria in the general population and in patients presenting to the ED is unknown. However, gross hematuria is more common in
 premenopausal women due to UTIs and contamination with menstrual blood. The incidence of bladder cancer associated with gross hematuria rises with increasing age.
The American Urological Association defines microscopic hematuria as ≥3 red blood cells (RBCs)/HPF (400×) on a properly collected and centrifuged
 urinary specimen in the absence of an obvious benign cause. Normal urine contains a small number of RBCs, usually too few to be detected by routine chemical dipstick testing or microscopic urinalysis. Population­based studies have found at least one episode of transient microscopic hematuria in 4% to 13% of individuals.
PATHOPHYSIOLOGY
Any process that results in infection, inflammation, or injury to the kidneys, ureters, bladder, prostate, male genitalia, or urethra may result in
 hematuria (Tables 91­7 and 91­8).
TABLE 91­7
Most Common Causes of Hematuria
Cause Associated Age
Urinary tract infections Any age
Nephrolithiasis Usually >20 years
Neoplasms Typically >50 years (except Wilms’)
Benign prostatic hypertrophy Males >40 years
Glomerulonephritis* Mostly young patients and children
Schistosomiasis† Any—underdeveloped country inhabitant
*See Chapter 137, “Renal Emergencies in Children.”
†See Chapter 162, “Global Travelers.”
TABLE 91­8
Differential Diagnosis of Hematuria
Urologic (lower tract)
Any location
Iatrogenic/post­procedure
Trauma
Infection
Stones/calculi
Erosion or mechanical obstruction by tumor
Ureter(s)
Dilatation of stricture
Bladder
Transitional cell carcinoma
Vascular lesions or malformations
Chemical or radiation cystitis
Prostate
Benign prostatic hypertrophy
Prostatitis
Urethra
Stricture
Diverticulosis
Foreign body
Endometriosis (cyclic hematuria with menstrual pain)
Renal (upper tract)
Glomerular
Glomerulonephritis
Immunoglobulin A nephropathy (Berger’s disease)
Lupus nephritis
Hereditary nephritis (Alport’s syndrome)
Toxemia of pregnancy
Serum sickness
Erythema multiforme
Non­glomerular
Interstitial nephritis
Pyelonephritis
Papillary necrosis: sickle cell disease, diabetes, NSAID use
Vascular: arteriovenous malformations, emboli, aortocaval fistula
Malignancy
Polycystic kidney disease
Medullary sponge disease
Tuberculosis
Renal trauma
Hematologic
Primary coagulopathy (e.g., hemophilia)
Pharmacologic anticoagulation
Sickle cell disease
Miscellaneous
Eroding abdominal aortic aneurysm
Malignant hypertension
Loin pain–hematuria syndrome
Renal vein thrombosis
Exercise­induced hematuria
Cantharidin (Spanish fly) poisoning
Bites or stings by insects and reptiles having venom with anticoagulant properties
In men >50 years old, tumors of the prostate or elsewhere in the ejaculatory system and benign prostatic hypertrophy are considerations when hematuria is present. In patients <40 years, common causes are infections and inflammatory conditions, including prostatitis, urethritis, sexually transmitted diseases, epididymo­orchitis, calculi with inflammation, and tuberculosis. Testicular tumors may occur in men younger than  years old.
False hematuria occurs when the urine appears bloody but dipstick test results are negative for blood and there are no RBCs on microscopic evaluation, or blood has been added to a previously blood­free specimen by the patient (Table 91­9). Free hemoglobin, myoglobin, or porphyrins in the urine result in a positive urine test strip reaction for blood.
TABLE 91­9
Causes of False Hematuria on Visual Inspection
Munchausen’s syndrome, malingering, drug seeking
Patients may add blood to voided urine for secondary gain
Medications
NSAIDs, phenytoin, phenothiazines, quinine, rifampin, sulfasalazine, others
Foods and dyes
Beets, berries, rhubarb
Serratia marcescens infection
Amorphous urates
Hemoglobinuria, myoglobinuria, porphyrins
CLINICAL FEATURES
A careful history, including information regarding sexual activity, recent urologic procedures, medications used, and HIV and tuberculosis risk factors, should be obtained. The patient’s general health and condition, vital signs, abdomen, external genitalia, and prostate in males should be evaluated.
Initial hematuria is the appearance of blood at the beginning of micturition, with subsequent clearing, and suggests urethral disease including cancer.

Gross hematuria more often indicates a lower tract cause. In younger patients, microscopic hematuria is most often caused by nephrolithiasis or

UTI. In older patients, infections and nephrolithiasis remain common causes of hematuria; however, hematuria in patients >50 years old warrants
,57 follow­up because renal, bladder, and prostate cancer increase in frequency and may coexist with UTI or kidney stones. Risk factors for uroepithelial cancer are age >50 years, male sex, smoking, family history of bladder cancer, occupational exposures in the chemical, rubber, or leather
 industries (e.g., exposure to dyes, benzenes, or aromatic amines), and excessive analgesic use. Hematuria in a patient taking oral anticoagulants should not be attributed to the anticoagulant alone, because the incidence of underlying disease is up to 80% in patients referred to urology for
 evaluation. Expanding abdominal aortic aneurysms may erode into the urogenital tract or cause inflammation or obstruction from direct pressure.
Malignant hypertension, embolic renal infarction, and renal vein thrombosis are other serious diagnoses that can cause hematuria. In pregnancy, hematuria can be associated with UTI, nephrolithiasis, or preeclampsia. Recent instrumentation of the urinary tract may produce hematuria.
The reported incidence of hematuria in HIV­infected patients is 18% to 50%. Causes include UTI, chlamydial and gonococcal urethritis, glomerulonephritis, neurogenic bladder, thrombocytopenia, subclinical uroepithelial Kaposi’s sarcoma, and urethral trauma. However, in up to 80% of patients, no specific cause is found.
The physical examination should note the vital signs and the patient’s appearance. Hypertension and edema imply nephrotic syndrome. A new heart murmur (endocarditis) or atrial fibrillation increases the likelihood of embolic disease and renal infarction. A full genital­urinary examination is essential for both males and females. Systemic signs need to be correlated to potential diseases that cause hematuria (Table 91­8).
DIAGNOSIS
Potential causes of hematuria are often suggested by considering the patient’s age, sex, demographic characteristics, habits, potential risk factors,
 history of recent GU instrumentation, and comorbidities.
LABORATORY TESTING
A clean­catch midstream urine collection is appropriate for most patients. Catheter­collected specimens are recommended for women with a vaginal discharge or menstrual or vaginal bleeding; however, urethral catheterization induces hematuria in 15% of patients. Brown or smoke­colored urine,
 along with dysmorphic RBCs, cellular casts, and proteinuria, suggests a glomerular source. Red, clotted blood in the urine indicates a source below the kidneys.
A urine dipstick test for blood can detect as little as 150 micrograms/L of free hemoglobin, corresponding to  to  intact RBCs/mL on microscopic analysis. False­negative results may be obtained with urine dipstick tests for blood if the urine has a high concentration of ascorbic acid (>5 milligrams/dL) or a high specific gravity. False­positive results occur in the presence of free hemoglobin, myoglobin, or porphyrins.
For patients with a clinical picture that does not provide a clear cause of hematuria on dipstick analysis (or indication for an urgent evaluation),
 urinalysis with microscopy should be performed to confirm hematuria before further workup. Hemorrhagic cystitis with invasive infection of the bladder wall by bacteria resulting in shedding and bleeding is a common cause of hematuria and resolves with appropriate antibiotic treatment.
For patients taking anticoagulants, obtain appropriate coagulation studies in the ED, with imaging at follow­up for older patients to exclude malignancy.
The finding of normal RBCs on microscopic examination of the urine together with bacteriuria and leukocytes in a young healthy patient supports UTI as the probable cause of hematuria. Additional laboratory studies may be needed depending on the results of the history, physical examination, and presumptive differential diagnosis. The presence of normal RBCs without evidence of infection should prompt further urologic evaluation to determine the site of bleeding; however, in stable patients without an urgent cause suggested by history and physical examination, an outpatient evaluation is appropriate.
IMAGING
,58
Initial upper and lower urinary tract imaging for hematuria is now typically done with noncontrast helical CT or renal US. Helical CT clearly
,58 delineates most renal tumors, obstructions, or stones and their precise location. These tests can often be done by a follow­up physician.
Renal US is useful when screening for obstruction, hydronephrosis, or abdominal aortic aneurysm. It is the study of choice in pregnant patients with suspected nephrolithiasis. However, renal US rarely identifies or locates stones in the ureters that are not large enough to give findings of obstruction.
Renal US also does not provide any assessment of renal function—normal enhancement and excretion of contrast by both kidneys. Helical CT with contrast provides this important information.
Gross hematuria in patients with blunt or penetrating trauma to the abdomen, flank, or back warrants an aggressive approach to identify the source of
 bleeding and to guide management (see Chapter 265, “Genitourinary Trauma”).
TREATMENT, DISPOSITION, AND FOLLOW­UP
Treatment of hematuria is directed at the cause (Tables 91­7 and 91­8). Outpatient management and referral for follow­up are appropriate for patients in hemodynamically stable condition without an apparent life­threatening cause of the hematuria. The urgency for follow­up depends on the presence
,59 of gross hematuria or risk factors for significant disease (Table 91­10). Patients with gross hematuria or listed significant risk factors should ideally be reevaluated at follow­up within  weeks.
TABLE 91­10
Risk Factors for Significant Disease in Patients With Microscopic Hematuria
Age >50 y
Male sex
History of gross hematuria
Smoking history
Occupational exposure to chemicals or dyes (benzenes or aromatic amines)
Analgesic abuse
History of pelvic irradiation
Cyclophosphamide use
Pregnancy
Known malignancy
Sickle cell disease
Renal insufficiency
The American Urological Association guideline recommends referral to urology to assess for urinary tract malignancy in all patients >35 years of age
 with microscopic hematuria without an obvious benign cause. Follow­up within  month is acceptable for patients with microscopic hematuria without significant risk factors. The American College of Physicians guidelines for hematuria recommend workup for all adults (18 year or older),
 including repeat assessment of urinalysis and consideration for CT imaging. This workup can be managed by a primary care physician.
Gross hematuria may lead to intravesical clot formation and bladder outlet obstruction. See Chapter , “Acute Urinary Retention,” for management.
Patients with intractable pain, intolerance of oral fluids and medications, significant comorbid illness, bladder outlet obstruction, evidence of hemodynamic instability, or possible life­threatening causes of hematuria should be admitted, and the appropriate specialist should be consulted.


