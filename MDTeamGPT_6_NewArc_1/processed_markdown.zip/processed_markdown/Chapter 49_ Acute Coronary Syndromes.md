## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 49: Acute Coronary Syndromes
Deborah B. Diercks; Judd E. Hollander; Anna Marie Chang
INTRODUCTION
Content Update: High­Sensitivity Cardiac Troponins and Acute Myocardial Ischemia March 2021
Hs­cTns (high­sensitivity cardiac troponins) improve ability to detect acute coronary ischemia.
Type  and type  myocardial ischemia, and the use of Hs­cTns in ED patients with chest pain are discussed in important updates in the section “Serum Markers of Myocardial Injury.”
Cardiac Complications of COVID­19 June 2020
Acute Coronary Syndrome and STEMI management present unique challenges during the COVID­19 pandemic. Treatment options require close collaboration between EMS systems, emergency departments, and cardiology services. See addition ‘Cardiac Complications of COVID­19’ in the section SPECIAL POPULATIONS at the end of this chapter.
EPIDEMIOLOGY
Ischemic heart disease is the leading cause of death among adults in the United States, with more than 400,000 people dying annually. Atherosclerotic disease of the epicardial coronary arteries—termed coronary artery disease—accounts for the vast majority of patients with ischemic heart disease. The predominant symptom of coronary artery disease is chest pain, and patient concern over potential acute heart disease contributes to the >8 million visits each year to U.S. EDs. In a typical adult ED population with acute chest pain, about 15% of patients will have an acute coronary syndrome (ACS). ACS encompasses unstable angina through acute myocardial infarction (AMI). Of patients with an ACS, approximately one third have an AMI, and the remainder have unstable angina.
The three principal presentations of unstable angina are listed in Table 49­1.1 These definitions assume that the anginal chest pain is due to ischemia, and this categorization does not apply to patients presenting to the ED with chest pain from other causes. During the initial ED assessment, it may not be possible to determine whether the patient has or will sustain permanent damage to the myocardium, has reversible ischemia (injury or unstable angina), or has a noncardiac cause of symptoms.
TABLE 49­1
Three Principal Presentations of Unstable Angina
Class Presentation
Rest angina* Angina occurring at rest and that is prolonged, usually >20 min
New­onset New­onset angina that markedly limits ordinary physical activity, such as walking 1–2 blocks or climbing  flight of stairs or performing lighter activity angina
Increasing Previously diagnosed angina that has become distinctly more frequent, has a longer duration, or is lower in threshold, limiting ability to walk 1–2 blocks or climb  flight of stairs or angina perform lighter activity
*Patients with non–ST­segment elevated myocardial infarction usually present with angina at rest.
The American College of Cardiology and American Heart Association have a tool for estimating the short­term risk for death or AMI in patients with unstable angina (Table 49­2).1
TABLE 49­2
Short­Term Risk of Death or Nonfatal Myocardial Infarction by Risk Stratification in Patients With Unstable Angina
High Likelihood (at least  of the Intermediate Likelihood (no high­risk feature, but must have  of the Low Likelihood (no high­ or intermediate­risk
Feature following features must be present) following) feature, but may have any of the following)
History Accelerating tempo of ischemic symptoms Prior myocardial infarction, peripheral or cerebrovascular disease, or coronary in preceding  h artery bypass grafting; prior aspirin use

Character Prolonged, ongoing (>20 min) rest pain Prolonged (>20 min) rest angina, now resolved, with moderate or high likelihood Increased angina frequency, severity, or duration
Chapter 49: Acute Coronary Syndromes, Deborah B. Diercks; Judd E. Hollander; Anna Marie Chang of the of CAD Angina provoked at a lower threshold
. Terms of Use * Privacy Policy * Notice * Accessibility pain Rest angina (>20 min) or relieved with rest or sublingual nitroglycerin New­onset angina with onset  wk to  mo before
Nocturnal angina presentation
New­onset or progressive angina in the past  wk without prolonged (>20 min) rest pain but with intermediate or high likelihood of CAD (Table 49­3)
Clinical Pulmonary edema, most likely due to Age >70 y old Chest discomfort reproduced by palpation findings ischemia
New or worsening mitral regurgitation murmur
S3 or new/worsening rales
Hypotension, bradycardia, tachycardia
Age >75 y old
ECG Angina at rest with transient ST­segment T­wave changes, pathologic Q waves, or resting ST depression <1 mm in multiple Normal or unchanged ECG changes >0.5 mm lead groups (anterior, inferior, lateral)
Bundle branch block, new or presumed new
Sustained ventricular tachycardia
Cardiac Elevated cardiac troponins above Slightly elevated cardiac troponins Normal markers threshold for myocardial infarction
Abbreviation: CAD = coronary artery disease.
ANATOMY
The left coronary artery divides into the left circumflex and the left anterior descending branches (Figure 49­1). The left anterior descending branch courses down the anterior aspect of the heart providing the main blood supply to the anterior and septal regions of the heart. The circumflex branch supplies blood to some of the anterior wall and a large portion of the lateral wall of the heart. The right coronary artery supplies the right ventricle and provides some perfusion to the inferior aspect of the left ventricle through its continuation as the right posterior descending artery.
Figure 49­1
Schematic diagram of the coronary arteries.
The atrioventricular conduction system receives blood supply from the atrioventricular branch of the right coronary artery and the septal perforating branch of the left anterior descending coronary artery. Similarly, the right bundle branch and the posterior division of the left bundle branch each obtain blood flow from both the left anterior descending and right coronary arteries. The posteromedial papillary muscle receives blood supply from one coronary artery, usually the right coronary artery.
PATHOPHYSIOLOGY
Ischemia occurs when there is an imbalance between oxygen (O ) demand and O supply. O supply is influenced by the O ­carrying capacity of the blood and the coronary artery blood flow.

The O ­carrying capacity of the blood is determined by the amount of hemoglobin present and O saturation. Coronary artery blood flow is determined by the duration of diastolic relaxation
  of the heart and peripheral vascular resistance. Humoral, neural, metabolic, and extravascular compressive forces and local autoregulation mechanisms determine the coronary vascular resistance.
Exercise­induced myocardial ischemia and its sequelae usually occur as a result of fixed atherosclerotic lesions. ACS may be caused by secondary reduction in myocardial blood flow due to coronary arterial spasm, microvascular dysfunction, disruption or erosion of atherosclerotic plaques, and platelet aggregation or thrombus formation at the site of an atherosclerotic lesion.
Secondary causes of myocardial ischemia are less common and prompted by factors extrinsic to the coronary arteries such as increased myocardial O demand (i.e., fever, tachycardia,
 thyrotoxicosis), reduced blood flow (i.e., hypotension), or reduced O delivery (i.e., anemia, hypoxemia). In the event of a secondary cause, global ischemia may occur widely or focally.

Atherosclerotic plaque forms through repetitive injury to the vessel wall. Macrophages and smooth muscle cells are the main cellular elements in plaque development, whereas lipids are predominant in the extracellular milieu. Plaque fissuring and rupture are affected by features inherent to the plaque, such as its composition and shape; local factors, such as shear forces, coronary arterial tone, and coronary arterial perfusion pressure; and movements of the artery in response to myocardial contractions. When plaque rupture occurs, potent thrombogenic substances activate circulating platelets.
The platelet response involves adhesion, activation, and aggregation. Platelet adhesion occurs through the weak platelet interactions with subendothelial adhesion molecules, such as collagen, fibronectin, and laminin, and the binding of the glycoprotein IIb receptor to the subendothelial form of von Willebrand factor. Adherent platelets are strongly thrombogenic. Lipidladen macrophages in the plaque core and adventitia of the vessel wall release tissue factor, which stimulates the conversion of prothrombin to thrombin. Thrombin and the local shear forces are also potent platelet activators. Platelet secretion of adenosine diphosphate, thromboxane A , and serotonin trigger platelet activation. Activated platelet glycoprotein IIb/IIIa
 receptors become cross­linked by fibrinogen or von Willebrand factor in the final common pathway of platelet aggregation.
The extent of O deprivation and the clinical presentation of any coronary disease depends on the limitation of O delivery imposed by any thrombus and the plaque. In stable angina,
  ischemia occurs only when activity induces O demands beyond the supply restrictions imposed by a partially occluded coronary vessel. Ischemia occurs at a relatively fixed point and changes
 slowly over time. In this scenario, the atherosclerotic plaque has not ruptured, and there is little or no superimposed thrombus. In ACS, atherosclerotic plaque rupture and platelet­rich thrombus develop. Coronary blood flow is reduced suddenly, and myocardial ischemia occurs. The degree and duration of the O supply–demand mismatch determine whether the patient
 develops reversible myocardial ischemia without necrosis (unstable angina) or acute myocardial ischemia with necrosis. More severe and prolonged obstruction increases the likelihood of infarction.
AMI may inhibit myocardial contractility and impair both central and peripheral perfusion. When an area of the myocardium does not receive adequate O , the functional deterioration
 progresses; as the size of the infarcted myocardium increases, left ventricular pump function decreases. This creates increased left ventricular end­diastolic pressure and end­systolic volume. Cardiac output, stroke volume, and blood pressure may decrease. When left atrial and pulmonary capillary pressures increase, heart failure or pulmonary edema may develop. Poor perfusion to the brain and kidneys can result in altered mental status and impaired renal function, respectively.
CLINICAL FEATURES
History and Associated Symptoms
The main symptom of ischemic heart disease is chest discomfort or pain; the characterization of the severity, location, radiation, duration, and quality might be helpful. In addition, the presence of associated symptoms such as nausea, vomiting, diaphoresis, dyspnea, lightheadedness, syncope, and palpitations may help detect myocardial ischemia (see Tables 48­1 and 48­2 in Chapter , “Chest Pain”). Obtain information regarding the onset and duration of symptoms, activities that precipitate symptoms, and prior evaluations for similar symptoms to assess the possibility of acute myocardial ischemia.
Symptoms of acute myocardial ischemia may use descriptions other than pain, such as discomfort; look for descriptions of chest pressure, heaviness, tightness, fullness, or squeezing. Less commonly, patients describe their symptoms as knife­like, sharp, or stabbing. The classic pain or discomfort location is substernal or in the left chest, with radiation to the arm (either), neck, or jaw. Reproducible chest wall tenderness occurs in some patients.
Exercise, stress, and a cold environment classically precipitate angina. Angina typically has a duration of symptoms of <10 minutes, occasionally lasting up to  to  minutes, and usually improves within  to  minutes after rest or nitroglycerin. In contrast, acute myocardial ischemia is usually accompanied by more prolonged and severe chest discomfort, more prominent associated symptoms (e.g., nausea, diaphoresis, shortness of breath), and little response to initial sublingual nitroglycerin. Easy fatigability may be a prominent symptom of ACS, especially in women.2
Ask about the frequency of anginal episodes and any change in frequency of episodes over the past few months. Determine if there is any increase in severity or duration of symptoms, or whether less effort is required to precipitate symptoms.
Advanced age, female gender, and a history of diabetes mellitus are associated with less typical ACS presentations.Presentations with nonclassic features or silent myocardial ischemia are common; for example, as many as .5% of women and .4% of men present without chest pain.3 Up to 30% of patients with acute myocardial ischemia identified in large longitudinal studies do not seek medical care or recall any symptoms. The prognosis for patients with nonclassic symptoms (e.g., fatigue, weakness, not feeling well, vague discomfort) at the time of infarction is worse than that of patients with more classic symptoms. Women and the elderly are more likely to have presentations that differ from classic ones in the younger, male patients; across all age groups, those with unstable angina have nonclassic features nearly half the time. Even in patients <55 years old, women were more likely than men to present with associated symptoms such as epigastric pain, palpitations, and jaw pain. This is why the term atypical chest pain is misleading, because nonclassic presentations are common despite being often called atypical.4
Cardiac risk factors are poor predictors of risk for AMI or other ACSs.5 Traditional cardiac risk factors for coronary artery disease, such as hypertension, diabetes mellitus, tobacco use, family history at an early age, and hypercholesterolemia, are not helpful to predict ACS in ED patients >40 years old.5 The cardiac risk factors predict risk of coronary artery disease over time, not likelihood of presence at one moment.
Physical Examination
Patients with ACS may appear well or may be uncomfortable, pale, cyanotic, or in respiratory distress. The pulse rate may be normal or fast, slow or irregular. Bradycardic rhythms are more common with inferior wall myocardial ischemia; in the setting of an acute anterior wall infarction, bradycardia or new heart block is a poor prognostic sign. Blood pressure can be normal, elevated (due to baseline hypertension, sympathetic stimulation, and anxiety), or decreased (due to pump failure or inadequate preload), although extremes of blood pressure are associated with a worse prognosis.
An S is present in 15% to 20% of patients with AMI; if detected, an S may indicate a failing myocardium. The presence of a new systolic murmur is an ominous sign because it may
  signify papillary muscle dysfunction, a flail leaflet of the mitral valve with resultant mitral regurgitation, or a ventricular septal defect.
The presence of rales, with or without an S gallop, indicates left ventricular dysfunction and left­sided heart failure. Jugular venous distention, hepatojugular reflex, and peripheral edema
 suggest right­sided heart failure.
DIAGNOSIS
The diagnosis of ST­segment elevation myocardial infarction (STEMI) depends on the ECG in the setting of symptoms suggestive of myocardial infarction. The diagnosis of non–ST­segment elevation myocardial infarction (NSTEMI) depends on abnormal elevation of cardiac biomarkers but may include ECG changes not meeting criteria for STEMI. The diagnosis of unstable angina is based on history (Table 49­1) because the ECG and cardiac injury biomarkers are nondiagnostic. Early risk assessment for the likelihood of myocardial infarction uses all of these data to aid decision making (Table 49­3).
TABLE 49­3
Likelihood That Signs and Symptoms Represent Acute Coronary Syndrome Secondary to Coronary Artery Disease
Intermediate Likelihood (absence of high­
Low Likelihood (absence of high­ or intermediate­
Feature High Likelihood (any of the following) likelihood features and presence of any of the likelihood features but may have the following) following)
History Chest or left arm pain or discomfort as chief symptom Chest or left arm pain or discomfort as chief symptom Probable ischemic symptoms in absence of any of the reproducing prior documented angina Age >70 y old intermediate­likelihood characteristics
Known history of coronary artery disease, including Male sex Recent cocaine use myocardial infarction Diabetes mellitus
Examination Transient mitral regurgitation murmur, hypotension, Extracardiac vascular disease Chest discomfort reproduced by palpation diaphoresis, pulmonary edema, or rales
ECG New, or presumably new, transient ST­segment deviation Fixed Q waves T­wave flattening or inversion <1 mm in leads with
(≥1 mm) or T­wave inversion in multiple precordial leads ST depression .5–1.0 mm or T­wave inversion >1 mm dominant R waves
Normal ECG
Cardiac Elevated cardiac troponin I, troponin T, or MB fraction of Normal Normal markers creatine kinase
Note: Estimation of the likelihood of significant coronary artery disease is a complex, multivariable problem that cannot be fully specified in a table such as this. Therefore, the table is meant to illustrate major relationships rather than offer rigid algorithms.
ELECTROCARDIOGRAPHY
The standard 12­lead ECG is the single best test—although it can be fallible—to identify patients with AMI upon ED presentation.1Obtain the initial 12­lead ECG and interpret the tracing quickly, ideally within  minutes of presentation in those patients with symptoms suggestive of myocardial ischemia. Prehospital ECGs reduce the time from symptom onset to reperfusion therapy in STEMI patients.6,7 (See Videos: ECG: Ischemia, ECF: MI Mimics, ECG: Myocardial Ischemia/Infarction, ECG: Old MI; ECG: Posterior MI; ECG: ST
Depression; ECG: STEMI; Right Ventricular MI.)
Video 49­1: ECG: Ischemia
Used with permission from Moshe Weizberg, MD.
Play Video
Video 49­2: ECG: MI Mimics
Used with permission from Moshe Weizberg, MD.
Play Video
Video 49­3: ECG: Ischemia/Infarction
Used with permission from Moshe Weizberg, MD.
Play Video
Video 49­4: ECG: Old MI
Used with permission from Moshe Weizberg, MD.
Play Video
Video 49­5: ECG: Posterior MI
Used with permission from Moshe Weizberg, MD.
Play Video
Video 49­6: ECG: ST Depressions
Used with permission from Moshe Weizberg, MD.
Play Video
Video 49­7: ECG: STEMI
Used with permission from Moshe Weizberg, MD.
Play Video
Video 49­8: ECG: Right Ventricular MI
Used with permission from Moshe Weizberg, MD.
Play Video
ST­segment–based diagnostic ECG criteria for AMI are shown in Table 49­4. STEMI in the listed distributions suggests acute transmural injury. ST­segment depressions in these distributions suggest ischemia. Inferior wall AMIs should have a right­sided lead V (V R) obtained, because ST­segment elevation in V R is highly suggestive of right ventricular infarction. For
   patients with a nondiagnostic tracing and persistent symptoms who have a high risk of ACS, repeat the ECG to detect developing changes.1,6,8 Early studies of fibrinolytic therapy identified an increased risk of mortality in patients with new bundle branch block; this led to interpreting a new left bundle branch block as being a “STEMI equivalent.” However, <10% of patients with new or possibly new left bundle branch block have AMI.9
TABLE 49­4
ECG ST­Segment–Based Criteria for Acute Myocardial Infarction
Location ECG Findings
Anteroseptal ST­segment elevations in V1, V2, and possibly V3
Anterior ST­segment elevations in V1, V2, V3, and V4
Anterolateral ST­segment elevations in V1–V6, I, and aVL
Lateral ST­segment elevations in I and aVL
Inferior ST­segment elevations in II, III, and aVF
Inferolateral ST­segment elevations in II, III, aVF, and V5 and V6
True posterior* Initial R waves in V1 and V2 >0.04 s and R/S ratio ≥1; Posterior ECG shows ≥ .5­mm ST elevation in V7–V9
Right ventricular (RV) ST­segment elevations in II, III, and aVF and ST­segment depression in lateral leads; ST­segment elevation in RV leads V3R–V6R
*Posterior wall infarction does not produce Q­wave abnormalities in conventional leads but only reflects reciprocal changes in conventional leads V1 and V2. Reciprocal ST­segment changes—those in leads away from or opposite the elevation area—are from subendocardial ischemia and denote a larger area of injury risk, an increased severity of underlying coronary artery disease, more severe pump failure, a higher likelihood of cardiovascular complications, and increased mortality. In general, the more elevated the ST segments and the more ST segments that are elevated, the more extensive is the injury.
The ECG changes correlate often, but not always, with the infarct­related vessel (Table 49­5). A right sided ECG (Figure 49­2A) and Posterior ECG (Figure 49­2B) are sometimes needed to determine extent of infarction. Inferior wall AMIs can result from occlusion of the left circumflex artery or the right coronary artery. In the setting of an inferior wall AMI, ST­segment elevation in at least one lateral lead (V , V , or aV ) with an isoelectric or elevated ST segment in lead I is strongly suggestive of a left circumflex lesion (Figure 49­3). Elevation of avR > V1 suggests left
  L anterior descending artery occlusion (Figure 49­4). The presence of ST­segment elevation in lead III greater than that in lead II predicts a right coronary artery occlusion (Figure 49­5). When accompanied by ST­segment elevation in V or a V R, it predicts a proximal right coronary artery lesion with accompanying right ventricular infarction (Figure 49­6), demonstrated by right­
  sided ECG leads. RV infarction associated with inferior infarction has higher morbidity than isolated inferior infarction. Reciprocal anterior ST­segment depressions in V through V are
  equally prevalent in right coronary and left circumflex inferior wall AMIs. Figure 49­7 shows anterior myocardial infarction from distal left anterior descending artery occlusion, whereas
Figure 49­8 shows anterior myocardial infarction from proximal left anterior descending artery occlusion. Posterior wall MI can be associated with inferior or lateral MI, or can be isolated. As leads V1­V3 indirectly reflect the posterior wall, a posterior wall MI can be identified with posterior lead placement (Figure 49­2b and Figure 49­9). Figure 49­9 shows posterior wall myocardial infarction.
Figure 49­2
A. Right­sided lead placement. B. Posterior lead placement. Leads V to V are removed from the anterior chest wall and replaced as V to V on the back. Lead V9 is placed paraspinal.

Figure 49­3
ECG showing inferior­lateral myocardial infarction from left circumflex coronary artery occlusion. ECG from a 42­year­old man presenting with chest pain. ECG shows ST­segment elevation in limb leads II, III (inferior), and aVF, as well as lead V (lateral). ST­segment depression is evident in leads V , V , and V , reflecting reciprocal changes in the anterior leads. The
    patient was found to have 100% occlusion of the left circumflex coronary artery at cardiac catheterization. [Used with permission of David M. Cline, MD, Wake Forest University.]
Figure 49­4
ST­segment elevation in lead aVR. First ED ECG taken in a patient with acute chest pain. Note elevation in aVR greater than that of V , suggesting left anterior descending artery occlusion. Initial
 troponin was normal; second troponin was abnormal. Emergency cardiac catheterization demonstrated 90% occlusion of left main coronary artery. [ECG used with permission of Department of Emergency Medicine, University of North Carolina Hospitals.]
Figure 49­5
ECG showing inferior myocardial infarction from right coronary artery occlusion. ECG from an 80­year­old man presenting with acute chest pain. The ECG shows ST­segment elevation in lead III greater than in lead II plus ST­segment depression of >1 mm in lead I and lead aVL. The patient was found to have 100% occlusion of the right coronary artery at cardiac catheterization.
[Used with permission of David M. Cline, MD, Wake Forest University.]
Figure 49­6
Right Ventricular Infarction. A. ECG showing inferior ST­segment elevation myocardial infarction and ST­segment elevation in lead V suggestive of right ventricular infarction. B.

Same patient with placement of right ventricular leads, see Figure 49­2A, showing ST­segment elevation in V R, V R, V R, and V R compatible with right ventricular infarction. [Used with
    permission of J. Stephan Stapczynski, Maricopa Medical Center.]
Figure 49­7
ECG showing anterior myocardial infarction from distal left anterior descending coronary artery occlusion. ECG from a 52­year­old man presenting with chest pain. ECG shows ST­ segment elevation in V , V , and V , with the absence of ST­segment depression in leads II, III, and aVF. The patient was found to have 100% occlusion of the distal left anterior descending
   coronary artery at cardiac catheterization. [Used with permission of David M. Cline, MD, Wake Forest University.]
Figure 49­8
ECG showing anterior myocardial infarction from proximal left anterior descending coronary artery occlusion. ECG from a 65­year­old man presenting with chest pain. ECG shows ST­ segment elevation in V , V , and V , and >1 mm of ST­segment depression in leads II, III, and aVF. The patient was found to have 100% occlusion of the proximal left anterior descending
   coronary artery at cardiac catheterization. [Used with permission of David M. Cline, MD, Wake Forest University.]
Figure 49­9
A. ECG with acute inferior wall myocardial infarction (MI) but ST­segment depression in V and V suggesting accompanying posterior wall MI. B. Posterior lead placement with ST­segment
  elevation in V and V confirming posterior wall MI.

TABLE 49­5
ECG Findings and Culprit Coronary Artery10–14
Positive Negative
Sensitivity Specificity
ECG Findings Culprit Artery Predictive Predictive
(%) (%)
Value (%) Value (%)
ECG findings for inferior ST­segment elevation myocardial infarction
ST­segment elevation in lead III greater than in lead II plus ST­segment depression of >1 mV Right coronary artery     in lead I, lead aVL, or both
In addition to the findings immediately above, ST­segment elevation on V1, V4R, or both Proximal right coronary artery  100 100 
Absence of the above findings plus ST­segment elevation in leads I, aVL, V5, and V6 and ST­ Left circumflex coronary     segment depression in leads V1, V2, and V3 artery
ECG findings for anterior ST­segment elevation myocardial infarction
ST­segment elevation in leads V1, V2, and V3 plus any of the features below:
ST­segment elevation of >2.5 mm in lead V1, or right bundle branch block with Q wave, or Proximal left anterior  100 100  both descending coronary artery
ST­segment depression of >1 mm in leads II, III, and aVF Proximal left anterior     descending coronary artery
ST­segment depression of ≤1 mm, or ST­segment elevation in leads II, III, and aVF Distal left anterior descending     coronary artery
ECG findings for left coronary artery lesions* >0.5­mm elevation in aVR; possibly also ≥1­mm ST elevation in lead V1 Left coronary artery or severe multivessel disease
Wellen’s sign: deeply inverted or deep biphasic T waves in V1 and V2; T­wave findings may Left anterior descending persist or be present even when patient is chest pain free artery
Note:  mm =  mV with standard ECG calibration.
*Nabati M, Emadi M, Mollaalipour M, et al: ST segment elevation in lead aVR in the setting of acute coronary syndrome. Acta Cardiol 71: , 2016. [PMID: 26853253]
ECGs are frequently misinterpreted.15 False­positive interpretations of the ECG, indicating STEMI when no injury exists, occur between 11% and 14% of the time.14 Balancing this is the observation that even patients with normal or nonspecific ECGs have a 1% to 5% incidence of AMI and a 4% to 23% incidence of unstable angina. Patients with nondiagnostic ECGs or evidence of ischemia that is age indeterminate have a 4% to 7% incidence of AMI and a 21% to 48% incidence of unstable angina. Demonstration of new ischemia in ECG increases the risk of AMI from 25% to 73% and the unstable angina risk from 14% to 43%. Thus, the standard 12­lead ECG is useful for cardiovascular risk stratification of patients with ACS.
Guideline­recommended additions to the standard 12­lead ECG are the use of right­sided precordial leads such as V R in the setting of acute inferior myocardial infarction to detect right
 ventricular involvement and V to V in patients with suspected posterior myocardial infarction from a circumflex lesion.1,6,16

There are several clinical conditions in which ECG interpretation is difficult (Table 49­6). In the setting of paced rhythms or left bundle branch block, acute myocardial ischemia can be identified (Figure 49­10) with select findings. In those with a preexisting left bundle branch block, the following patterns are indicative of AMI: (1) ST­segment elevation of  mm or greater and concordant (in the same direction as the main deflection) with the QRS complex (odds ratio, .2; 95% confidence interval [CI], .6% to .7%) seen in Figure 49­10C; (2)
ST­segment depression of  mm or more in leads V , V , or V (odds ratio, .0; 95% CI, .9% to .3%) seen in Figure 49­10D; and (3) ST­segment elevation of  mm or greater and discordant (in
   the opposite direction) with the QRS complex (odds ratio, .3; 95% CI, .8% to .6%) seen in Figure 49­10E.15
Figure 49­10
Discordant and concordant ST elevation and depression in the setting of left bundle branch block. ST­segment abnormalities in left bundle branch block. A. Discordant ST­segment depression (“normal”). B. Discordant ST­segment elevation (“normal”). C. Concordant ST­segment elevation (strongly suggestive of acute myocardial infarction [AMI]). D. Concordant ST­ segment depression (suggestive of AMI). E. Excessive (>5 mm) discordant ST­segment elevation (weakly suggestive of AMI). [Used with permission of William Brady, MD, University of Virginia.].
TABLE 49­6
Conditions in Which ECG Interpretation Can Be Difficult
May have ST­segment elevation in the absence of acute myocardial infarction
Early repolarization
Left ventricular hypertrophy
Pericarditis
Myocarditis
Left ventricular aneurysm
Hypertrophic cardiomyopathy
Hypothermia
Ventricular paced rhythms
Left bundle branch block
Takotsubo cardiomyopathy
May have ST­segment depressions in the absence of ischemia
Hypokalemia
Digoxin effect
Cor pulmonale and right heart strain
Early repolarization
May have T­wave inversions in the absence of ischemia
Persistent juvenile pattern
Stokes­Adams syncope or seizures
Posttachycardia T­wave inversion
Postpacemaker T­wave inversion
Intracranial pathology (CNS hemorrhage)
Mitral valve prolapse
Primary or secondary myocardial diseases
Pulmonary embolism or cor pulmonale from other causes
Spontaneous pneumothorax
Myocardial contusion
Right bundle branch block
Right ventricular pacing, the common pacemaker lead location, causes secondary repolarization changes of opposing polarity to that of the predominant QRS complex. Most leads have predominant negative QRS complexes followed by ST­segment elevation and positive T waves. ST­segment elevation of at least  mm is most indicative of AMI in leads with predominantly negative QRS complexes.17 Any ST­segment elevation concordant to the QRS complex in a predominantly positive QRS complex is highly specific for AMI. The QRS complex is predominantly negative in leads V to V with right ventricular pacing. ST­segment depression in these leads has 80% specificity for AMI.17

Wellens’ sign or syndrome describes a pattern of abnormal T waves in the precordial leads V and V associated with critical stenosis of the left anterior descending artery18

(Figure 49­11 and Table 49­7). Approximately 75% of patients with this finding have deeply inverted T waves, and about a quarter of patients will display a variant pattern of biphasic T waves in the same leads.19,20 T­wave abnormalities are often also seen in leads V and V or occasionally in leads V and V . The abnormal T waves of Wellens’ syndrome are usually visible
    when the patient is pain free and may normalize when pain recurs; repeating the ECG when pain resolves or recurs can aid in detection of these dynamic changes.20 Up to 15% of patients presenting with unstable angina will display the Wellens’ sign.18,21 Because of the high incidence of critical coronary stenosis and the potential for acute infarction, patients with Wellens’ syndrome should receive early interventional management. Similarly, those with hyperacute T waves, de Winter ST­T–wave complex (upsloping of ST segment with overall ST depression), and posterior STEMI patterns should receive emergency reperfusion. (See Video: Wellens’ Sign.)
Figure 49­11
A. Wellens’ sign with ECG showing deep symmetric T­wave inversions in leads V to V . [Reproduced with permission from Lefebvre C, O’Neill J, Cline D (eds): Atlas of Cardiovascular

Emergencies. New York, NY: McGraw­Hill Education, Inc. © 2015. Fig .32.].
B. Hyperactive T waves in V2­V4 represent deWinter ST Waves, predictive of acute LAD occlusion. (Image used with permission of Susan P. Torrey, MD, FAAEM, FACEP.)
TABLE 49­7
General Criteria for Wellens’ Syndrome
History of episodic chest pain consistent with unstable angina
During pain, the ECG may not display abnormal T waves
When pain free, abnormal T waves seen, most prominent in leads V2 and V3, often in leads V1 and V4, and occasionally in leads V5 and V6
Deep symmetric T­wave inversion seen in about 75% of Wellens’ syndrome patients
Biphasic T waves seen in about 25% of Wellens’ syndrome patients
No pathologic Q waves or loss of R waves
Normal or minimally elevated ST segments
Normal or minimally elevated cardiac biomarkers
Video 49­9: Wellens’ Sign
Used with permission from Moshe Weizberg, MD.
Play Video
SERUM MARKERS OF MYOCARDIAL INJURY
Patients with diagnostic ST­segment elevation on their initial ECG are treated as STEMI, as discussed below. Patients with chest pain with nondiagnostic ECGs will need further evaluation in the ED. To establish the diagnosis of acute MI, in addition to clinical criteria, abnormal cardiac biomarkers are required.
The current preferred biomarkers of myocardial injury are cardiac troponin I (cTnI) and T (cTnT). Myocardial injury is defined when blood levels of cTn are increased above the 99th percentile of the upper reference limit (URL). This increased level may indicate chronic or acute injury, and thus levels should be interpreted looking for dynamic rising and/or falling patterns. Cardiac troponin is sensitive to myocardial injury, but does not indicate underlying pathophysiological mechanisms (see Table 48­5).
The Fourth Universal Definition of Myocardial Infarction updates the concepts of myocardial infarction and provides more distinction between type  and type  myocardial infarction.22
Type  myocardial infarctions are defined as those caused by atherothrombotic coronary artery disease and plaque disruption. Type  myocardial infarctions are defined as ischemic myocardial injuries caused by a mismatch between oxygen supply and demand. While it is important to distinguish between the types of myocardial infarctions, cTn elevations are independent risk factors for for acute (<30 days) cardiac complications and short­term (<1 year) prognosis in unstable angina.23 Low­level elevations in either troponin correlate with risk for cardiovascular complications in unstable angina, CAD, and renal failure.23 The data strongly support the claim that any measurable elevated troponin is always worse than no elevated troponin and that more troponin elevation is always worse than less troponin elevation with respect to prognosis.24,25,26
New high­sensitivity cardiac troponins (Hs­cTns) have improved ability to detect ischemia. The high­sensitivity troponins identify 90% to 100% of patients with AMI at the time of arrival using the lowest cut point, albeit with limited specificity (between 34% and 80% depending on the cut­off used).27–29 Compared to prior cardiac troponin assays, high­sensitivity cardiac troponins have a higher negative predictive value for acute myocardial infarction. In addition, Hs­cTns also lead to an increase in the detection of AMI and decrease the diagnosis of unstable angina.30,31
While Hs­cTns are now pervasive in practice, there is still no expert opinion or consensus about specific criteria for how the 99th percentile URL should be defined. In addition, age, renal function, and sex all impact URL values.32,33 Clinicians must learn about their local Hs­cTn assay and practices.
Despite the new sensitive assays which can detect ischemia earlier, guidelines1,6,7 and experts34 recommend serial troponin testing to identify acute disease. Delta or changing values over a 1­ to 3­hour period can also help distinguish acute from chronic injury. A serial high­sensitivity troponin interval as short as  hours after presentation coupled with a low risk score (discussed below) excludes AMI.35 The European Society of Cardiology recommends a 2­hour serial interval when high­sensitivity troponins are used or a 0/1­hour interval36 when a rapid algorithm exists that incorporates a delta change.37,38
B­type natriuretic peptide, an established marker for patients with heart failure, is also elevated in patients with ACS and can identify ACS patients who are at higher risk for adverse cardiovascular events, heart failure, or death.6 When used in conjunction with other markers, the addition of B­type natriuretic peptide increases sensitivity at the cost of decreased specificity, with only a slight increase in overall diagnostic accuracy. However, levels can help determine prognosis, and should be considered as an adjunct to AMI diagnosis.38
ACCELERATED DIAGNOSTIC PROTOCOLS
Despite improvements in troponin assays, early troponin testing alone does not identify all patients at short­term risk for major adverse cardiac events or those with unstable angina.
Accelerated diagnostic pathways, which incorporate clinical information with troponin results, can be used to rule out AMI and ACS. A variety of accelerated diagnostic pathways have been developed, including the History, ECG, Age, Risk Factors, and Troponin (HEART) pathway,39 the Emergency Department Assessment of Chest Pain Score (EDACS) pathway, and the No Objective
Testing Rule,40 as a few examples. For clinicians to use these pathways, several factors need to be considered: some pathways were developed to rapidly rule out AMI (such as EDACS), while other pathways were developed to identify a cohort of chest pain patients who can be rapidly discharged (such as the HEART pathway), and require validation when a new troponin assay is used.
One commonly used pathway is the HEART pathway,41 which uses the HEART score with 0­ and 3­hour cTn testing to identify patients who are safe for discharge from the ED with low risk for
30­day major adverse cardiovascular event (MACE). The HEART score assigns points of , , or  in the categories of History, EKG, Age, Risk Factors, and (initial) Troponin. Those with a HEART score of ≤3 and normal troponin had a low risk (0.9–1.7%) of 30­day MACE. Any patients with elevated initial troponin or HEART score ≥4 warranted further investigation. Results were similar with Hs­Tn assay (see Figure 49­12).
Figure 49­12
Heart score risk stratification.
The current European Society of Cardiology38 updated guidelines discuss the use of 0­ and 1­hour algorithms and 0­ and 2­hour algorithms; these use a very low concentration of circulating
Hs­cTn to rule out purposes, and also define what is considered a change or no change (delta) at  or  hours. The Negative Predictive Value (NPV) for myocardial infarction in patients following these criteria exceeded 99% in large cohort studies.42–44 Clinicians should be aware of the assays and algorithms as used by their practice site.
TABLE 49­8
Heart Score (Table 49­8)
 Points  Point  Points
History1 Slightly suspicious Moderately suspicious Highly suspicious
EKG Normal Non­specific repolarization disturbance2 Significant ST depression3
Age (years) <45 45–64 ≥65
Risk factors4 No known risk factors 1–2 risk factors ≥3 risk factors or history of atherosclerotic disease
Initial troponin5 ≤normal limit 1­3x normal limit >3x normal limit
GENERAL TREATMENT
The treatment of ACS is based on duration and persistence of symptoms, cardiac history, and findings on physical examination and the initial ECG (Figure 49­13). Establish IV access, give aspirin if not already given by EMS, and, as long as there are no contraindications, provide ECG monitoring. Many recommend supplemental O ; however, there is little evidence for benefit in
 patients without hypoxemia, and small studies have shown a negative effect with high­flow O .45 The key treatment strategies aim to achieve immediate reperfusion and limit infarct size

(Table 49­9 and Table 49­10).
Figure 49­13
Treatment considerations for acute coronary syndrome (ACS) patients. *Prasugrel should be considered at the time of PCI in patients who have not yet received either clopidogrel or ticagrelor. †Enoxaparin, unfractionated heparin, or fondaparinux. Note: See text for discussion of individual treatment options, indications, and contraindications. ‡Risk factors for cardiogenic shock/adverse effects: (1) signs of heart failure; (2) evidence of a low cardiac output state; (3) increased risk for cardiogenic shock (cumulatively: age >70 years old, systolic blood pressure <120 mm Hg, sinus tachycardia >110 beats/min or bradycardia <60 beats/min, and longer duration of ST­segment elevation myocardial infarction symptoms before diagnosis and treatment); or (4) standard relative contraindications to β­blockade (PR interval >0.24 seconds, second­ or third­degree heart block, active asthma, or reactive airway disease). AMI = acute myocardial infarction; PCI = percutaneous coronary intervention.
TABLE 49­9
Drugs Used in the Emergency Treatment of STEMI
Antiplatelet Agents
Aspirin 162–325 milligrams
Clopidogrel Loading dose of 600 milligrams PO followed by  mg PO daily. No loading dose is administered in patients >75 y old receiving fibrinolytics
Prasugrel Loading dose of  milligrams promptly and no more than  h after PCI once coronary anatomy is defined and a decision is made to proceed with PCI
Ticagrelor Loading dose is 180 milligrams PO followed by  milligrams twice a day
Antithrombins
Unfractionated Bolus of  units/kg (maximum, 4000 units) followed by infusion of  units/kg/h (maximum, 1000 units/h) titrated to a partial thromboplastin time .5–2.5 × control heparin
Enoxaparin  milligrams IV bolus followed by  milligram/kg SC every  h
Fondaparinux .5 milligrams SC* Fibrinolytic Agents
Streptokinase .5 million units over  min
Anistreplase  units IV over 2–5 min
Alteplase Body weight >67 kg:  milligrams initial IV bolus;  milligrams infused over next  min;  milligrams infused over next  min
Body weight <67 kg:  milligrams initial IV bolus; .75 milligram/kg infused over next  min; .5 milligram/kg infused over next  min
Reteplase  units IV over  min followed by  units IV bolus  min later
Tenecteplase Weight Dose (total dose not to exceed  milligrams)
<60 kg  milligrams
≥60 but <70 kg  milligrams
≥70 but <80 kg  milligrams
≥80 but <90 kg  milligrams
≥90 kg  milligrams
Glycoprotein IIb/IIIa Inhibitors†
Abciximab .25 milligram/kg bolus followed by infusion of .125 microgram/kg/min (maximum,  micrograms/min) for 12–24 h
Eptifibatide 180 micrograms/kg bolus followed by infusion of .0 micrograms/kg/min for 72–96 h
Tirofiban .4 microgram/kg/min for  min followed by infusion of .1 microgram/kg/min for 48–96 h
Other Anti­Ischemic Therapies
Nitroglycerin Sublingual: .4 milligram every  min ×  PRN pain
IV: Start at  micrograms/min, titrate to 10% reduction in MAP if normotensive, 30% reduction in MAP if hypertensive
Morphine 2–5 milligrams IV every 5–15 min PRN pain
Metoprolol  milligrams PO every  h on first day, unless significant hypertension, may consider  milligrams IV over  min every  min up to  milligrams; withhold β­blockers initially if the patient is at risk for cardiogenic shock/adverse effects‡
Atenolol 25–50 milligrams PO, unless significant hypertension, may consider  milligrams IV over  min, repeat once  min later; withhold β­blockers initially if the patient is at risk for cardiogenic shock/adverse effects‡
Abbreviations: MAP = mean arterial pressure; PCI = percutaneous coronary intervention; PRN = as needed; STEMI = ST­segment elevation myocardial infarction.
*Fondaparinux should not be used as monotherapy for PCI; if used, addition of unfractionated heparin or bivalirudin is recommended before PCI.
†American College of Cardiology/American Heart Association 2009 focused update for STEMI patients recommended glycoprotein IIB/IIa inhibitors be given at the time of PCI; benefit prior to arrival in the cardiac catheterization laboratory is uncertain.
‡Risk factors for cardiogenic shock/adverse effects: (1) signs of heart failure; (2) evidence of a low cardiac output state; (3) increased risk for cardiogenic shock (cumulatively: age >70 y old, systolic blood pressure <120 mm Hg, sinus tachycardia >110 beats/min or bradycardia <60 beats/min, and longer duration of STEMI symptoms before diagnosis and treatment); or (4) standard relative contraindications to β­ blockade (PR interval >0.24 s, second­ or third­degree heart block, active asthma, or reactive airway disease).
TABLE 49­10
Drugs Used in the Emergency Treatment of Unstable Angina or NSTEMI
Antiplatelet Agents
Aspirin 162–325 milligrams
Clopidogrel Loading dose of 300–600 milligrams PO followed by  milligrams/d
Prasugrel Loading dose of  milligrams promptly and no more than  h after PCI once coronary anatomy is defined and a decision is made to proceed with PCI
Ticagrelor Loading dose of 180 milligrams PO followed by  milligrams twice a day
Antithrombins
Heparin Bolus of  units/kg (maximum, 4000 units) followed by infusion of  units/kg/h (maximum, 1000 units/h) titrated to a partial thromboplastin time .5–2.5 × control
Enoxaparin  milligram/kg SC every  h
Fondaparinux .5 milligrams SC
Direct Thrombin Inhibitor
Bivalirudin .75 milligram/kg IV bolus followed by .75 milligrams/kg/h infusion for duration of procedure
Glycoprotein IIb/IIIa Inhibitors
Eptifibatide 180 micrograms/kg bolus followed by infusion of .0 micrograms/kg/min for 72–96 h
Tirofiban .4 microgram/kg/min for  min followed by infusion of .1 microgram/kg/min for 48–96 h
Other Anti­Ischemic Therapies
Nitroglycerin Sublingual: .4 milligram every  min ×  PRN pain
IV: Start at  micrograms/min, titrate to 10% reduction in MAP if normotensive, 30% reduction in MAP if hypertensive
Metoprolol  milligrams PO every  h first day; unless significant hypertension, may consider  milligrams IV over  min every  min up to  milligrams; withhold β­blockers initially if the patient is at risk for cardiogenic shock/adverse effects* Atenolol 25–50 milligrams PO; unless significant hypertension, may consider  milligrams IV over  min, repeat once  min later; withhold β­blockers initially if the patient is at risk for cardiogenic shock/adverse effects* Abbreviations: MAP = mean arterial pressure; NSTEMI = non–ST­segment elevation myocardial infarction; PRN = as needed.
*Risk factors for cardiogenic shock/adverse effects: (1) signs of heart failure; (2) evidence of a low cardiac output state; (3) increased risk for cardiogenic shock (cumulatively: age >70 y old, systolic blood pressure
<120 mm Hg, sinus tachycardia >110 beats/min or bradycardia <60 beats/min, and longer duration of ST­segment elevation myocardial infarction symptoms before diagnosis and treatment); or (4) standard relative contraindications to β­blockade (PR interval >0.24 s, second­ or third­degree heart block, active asthma, or reactive airway disease).
STEMI TREATMENT
Patients with persistent symptoms and STEMI should receive mechanical or pharmacologic reperfusion attempts. Percutaneous coronary intervention (PCI) with or without stent placement is the dominant current approach to mechanical reperfusion.6 Pharmacologic reperfusion is accomplished with fibrinolytic therapy, which is improved with adjuvant antiplatelet and antithrombin therapy.
American Heart Association/American College of Cardiology guidelines target a treatment goal of ≤90 minutes for a patient who arrives at a hospital with PCI capability or of ≤120 minutes for patients arriving at a hospital without PCI capability to account for transfer time.6,7 Fibrinolysis should be given within  minutes of ED arrival if PCI cannot be accomplished within these time frames.7 The concept of “first medical contact to device/balloon time” replaces the “door to needle” or “door to balloon” time.7 Each health system and institution treating ACS patients should develop protocols to drive optimal methods of reperfusion, determining which strategy it will use depending on its capabilities.
Most STEMI patients receive antiplatelet agents, antithrombins, and nitrates in the ED. Treat patients with unstable angina or NSTEMI with antiplatelet agents, antithrombins, and nitrates.1
Those with unstable angina or NSTEMI refractory to these therapies or those scheduled to undergo PCI also may benefit from the use of glycoprotein IIb/IIIa antagonists (Table 49­9 and Table
49­10).1
NSTEMI TREATMENT
For patients with NSTEMI (which by definition requires the time for biomarkers to become elevated and the clinical laboratory to perform the measurement), an invasive approach within  to
 hours using PCI reduces the composite of death, myocardial infarction, or recurrent ACS by 19% in women and 27% in men.46 Therefore, the early invasive approach deployed in STEMI is recommended in NSTEMI patients only with refractory angina or hemodynamic or electrical instability or in patients at increased risk for clinical events.1
Based on the results of trials and a meta­analysis,47,48 the American Heart Association/American College of Cardiology guidelines for the management of unstable angina/NSTEMI patients recommend early (within  hours) invasive therapy in patients with signs and symptoms such as recurrent angina/ischemia with or without symptoms of congestive heart failure, elevated cardiac troponins, new or presumably new ST­segment depression, high­risk findings on noninvasive stress testing, depressed left ventricular function, hemodynamic instability, sustained ventricular tachycardia, PCIs within the previous  months, or prior coronary artery bypass grafting.1 More aggressive and earlier PCI in these patients has not proven beneficial compared to the within  hours approach.49,50 If patients with unstable angina/NSTEMI are hemodynamically unstable, guidelines recommend invasive strategy within  hours.
PERCUTANEOUS CORONARY INTERVENTION
The American College of Cardiology, the American Heart Association, and the European Society of Cardiology recommend PCI as the preferred method of reperfusion therapy if the first medical contact to first balloon inflation time is <90 to 120 minutes.6,7,51 In the early presenting cohort (within  hours of symptom onset), the decision to use primary PCI rather than fibrinolysis is based on institutional expertise, availability of the cardiac catheterization team, and the individual patient’s risk of complications from fibrinolysis.
Coronary angioplasty with or without stent placement is the most common PCI; alternatives include atherectomy and laser angioplasty. Balloon angioplasty increases the size of the arterial lumen through endothelial denudation; cracking, splitting, and disruption of atherosclerotic plaque; dehiscence of intima and plaque from underlying media; and stretching or tearing of underlying media and adventitia. With successful dilatation, small amounts of arterial wall dissection and aneurysmal expansion may be seen. The greater the increase in luminal size, the lower is the risk of restenosis. However, more aggressive balloon inflation can augment dissection, platelet deposition, thrombus formation, and plaque hemorrhage.
Alternative PCI procedures attempt to limit complications. Directional and rotational coronary atherectomy extracts atherosclerotic tissue from the coronary artery. Excimer laser atherectomy vaporizes atheromatous tissue. It results in larger luminal diameters but has not reduced rates of restenosis or other complications associated with percutaneous angioplasty procedures.
Coronary stents are fenestrated stainless steel tubes that are expanded by a balloon to provide scaffolding within the coronary arteries. Adding antiplatelet therapy (in particular, thienopyridines and glycoprotein IIb/IIIa inhibitors) results in lower adverse events at  months. Drug­eluting stents are associated with decreased early (within months) vessel closure but a higher delayed closure, particularly once antiplatelet agents (clopidogrel) are stopped.
In centers with expertise in direct angioplasty, primary PCI reduces the cardiovascular complication rate in patients with AMI compared to fibrinolysis.6,52,53 The longer the duration of symptoms, the greater is the benefit to primary PCI over fibrinolysis. PCI is more effective in establishing flow and reducing reocclusion in the infarct­related artery than fibrinolytic therapy and is associated with a decreased incidence of short­ and long­term death, nonfatal reinfarction, and intracranial hemorrhage compared with fibrinolytic therapy.7
Registry data show that the targeted reperfusion time goal is met less than half the time.51 Strategies54,55 to optimize door to balloon time include EMS direct or emergency physician activation of the catheterization laboratory without cardiologist consultation by a one­call system (similar to trauma activations); having a trained catheterization team ready in  minutes; a feedback loop providing the EMS provider and emergency physician with data on the individual case; quality assurance processes in place to measure and report back times; and continually enhancing the team­based approach.
FIBRINOLYTICS
Fibrinolytic agents (tissue plasminogen activator, recombinant tissue plasminogen activator, tenecteplase, streptokinase, and anistreplase) act on the acute thrombosis directly or indirectly as plasminogen activators. Plasminogen, an inactive proteolytic enzyme, binds directly to fibrin during thrombus formation to form a plasminogen–fibrin complex. This plasminogen–fibrin complex incorporated into the clot is more susceptible than circulating plasma plasminogen to activation (thus, the concept that fibrinolytic agents are to a varying degree “clot specific,” promoting fibrin proteolysis).
Fibrinolytic therapy improves left ventricular function and short­term and long­term mortality. A meta­analysis found that the net benefit of fibrinolytic treatment in the first  hours was >30 lives saved per 1000 patients.56 The loss of benefit per hour delay in fibrinolytic administration was .6 lives per 1000 patients per hour.
Fibrinolytic therapy is indicated for patients with STEMI (as a reperfusion option) if time to treatment is <6 to  hours from symptom onset and the ECG has at least  mm of ST­segment elevation in two or more contiguous leads.6,7 Therapy is more beneficial if given early and for larger infarctions and anterior infarctions than for smaller or inferior infarctions. In the elderly, the overall risk of mortality from AMI is high. The proportionate reduction in mortality rate appears to be less in patients >75 years old, but the absolute number of patients who may be saved is still considerable.
After failed fibrinolytic administration, rescue PCI is recommended for patients in cardiogenic shock who are <75 years old, patients with severe heart failure or pulmonary edema, patients with hemodynamically compromising ventricular arrhythmias, and patients in whom fibrinolytic therapy has failed and a moderate or large area of myocardium is at risk.6
Because tissue plasminogen activator, recombinant tissue plasminogen activator, and tenecteplase have similar efficacy and safety profiles, the choice of which to use is usually based on ease of administration, cost, and the local preferences.
Contraindications to fibrinolytic therapy are those that increase the risk of hemorrhage (Table 49­11). The most catastrophic complication is intracranial bleeding. Clinical variables that can be assessed in the ED and predict an increased risk of intracranial hemorrhage are age (>65 years old), low body mass (<70 kg), and hypertension on presentation.6 Intracranial hemorrhage is more common with tissue plasminogen activator than with streptokinase (odds ratio of .6). Patients with relative contraindications may still receive fibrinolytic therapy when the benefits of therapy outweigh the risks of the complications.
TABLE 49­11
Contraindications to Fibrinolytic Therapy in ST­Segment Elevation Myocardial Infarction
Absolute contraindications
Any prior intracranial hemorrhage
Known structural cerebral vascular lesion (e.g., arteriovenous malformation)
Known intracranial neoplasm
Ischemic stroke within  mo
Active internal bleeding (excluding menses)
Suspected aortic dissection or pericarditis
Relative contraindications
Severe uncontrolled blood pressure (> 185 mm Hg SBP OR > 110 mm Hg DBP)
History of chronic, severe, poorly controlled hypertension
History of prior ischemic stroke >3 mo or known intracranial pathology not covered in contraindications
Current use of anticoagulants with known INR >2–3; no evidence with direct oral anticoagulants available as of this writing, but safety data can be extracted from stroke studies with recombinant tissue plasminogen activator and direct oral anticoagulants
Known bleeding diathesis
Recent trauma (past  wk)
Prolonged CPR (>10 min)
Major surgery (<3 wk)
Noncompressible vascular punctures (including subclavian and internal jugular central lines)
Recent internal bleeding (within 2–4 wk)
Patients treated previously with streptokinase should not receive streptokinase a second time
Pregnancy
Active peptic ulcer disease
Other medical conditions likely to increase risk of bleeding (e.g., diabetic retinopathy)
Patients treated with fibrinolytics benefit from early follow­up invasive intervention, called pharmacoinvasive therapy.57 In the TRANSFER­AMI study, high­risk patients treated with fibrinolytics for STEMI at non–PCI­capable centers were randomized to standard care or immediate transfer for PCI within  hours after fibrinolysis.58 The patients who underwent the pharmacoinvasive strategy had a .2% absolute reduction in the composite end point of death, reinfarction, recurrent ischemia, new or worsening heart failure, or cardiogenic shock at  days.
Facilitated PCI refers to a planned initial pharmacologic treatment followed by PCI for treatment of STEMI. The ASSENT­4 PCI trial found no benefit and a higher incidence of death, congestive heart failure, or shock at  days in the group receiving fibrinolytics compared with the PCI­only group. Current guidelines state that a facilitated approach might be considered in high­risk patients with low bleeding risk with long duration to PCI.6 However, no clear benefits are apparent for this method.
Fibrinolytic therapy in STEMI is limited in several ways. First, even the most potent fibrinolytic agents do not achieve early and complete restoration of coronary blood flow in 40% to 50% of patients. Fibrinolytics are plasminogen activators. When fibrin is lysed, thrombin is exposed. The exposed thrombin is a potent biologic platelet activator. As a result, the more fibrin that is lysed, the more thrombin is exposed, and the more prothrombotic substrate is engendered. This may be one reason why optimal antithrombin therapy (enoxaparin rather than unfractionated heparin) and dual antiplatelet therapy (both aspirin and clopidogrel) lead to improved outcomes. The second limitation of fibrinolytic therapy is that approximately .5% to
.0% of patients have intracranial hemorrhage, which usually results in death or disabling stroke.
STEMI patients who received fibrinolytics should get full­dose anticoagulants for a minimum of  hours.6 Recommended therapies include unfractionated heparin, enoxaparin, or fondaparinux.6,7
ANTIPLATELET AGENTS
The glycoprotein IIb/IIIa antagonists are stronger antiplatelet agents than aspirin, interrupting platelet activation regardless of the agonist. In contrast, aspirin only inhibits platelet aggregation stimulated through thromboxane A and mediated through the arachidonic acid pathway.

Aspirin
Give aspirin, ≥162 milligrams and preferably 325 milligrams if naive of aspirin, as soon as possible to all patients with STEMI, NSTEMI, and unstable angina. Aspirin prevents formation of thromboxane A , an agonist of platelet aggregation. This inhibition persists for the 8­ to 12­day life of the platelet, because platelets are unable to generate new
 cyclooxygenase. In patients with STEMI, aspirin alone reduces relative mortality rate by 23%.6 The estimated number needed to treat to aid is  patients, with the number needed to harm
(nondangerous bleeding) being 167 patients.59 Aspirin used in conjunction with fibrinolytic therapy further reduces ischemic events and coronary artery reocclusion. Aspirin doses >162 milligrams cause immediate, near­complete inhibition of thromboxane A . Smaller doses may not be effective for acute use. Aspirin reduces vascular events in patients with AMI and patients
 with unstable angina, especially in those with prior myocardial infarction or stroke (decrease by about 4%).
The side effects of aspirin are mainly GI, accumulative, and dose related. Diluted or buffered aspirin solutions, lowest possible doses, or concurrent antacid or H antagonist administration
 reduces aspirin harm. Due to the benefits during ACS, do not withhold early aspirin from patients with minor contraindications (vague allergy, history of remote peptic ulcer, or GI bleeding).6 Other antiplatelet agents such as clopidogrel are alternatives if true aspirin allergy or active peptic ulcer disease exists.
Adenosine Diphosphate Receptor Antagonists
Prasugrel
Prasugrel is an irreversible, potent platelet receptor antagonist in this class. In the TRITON­TIMI  trial, prasugrel compared favorably with clopidogrel,60 reducing the primary composite outcome by an absolute .2%, although with an increased frequency of bleeding. In post hoc analysis, this increased bleeding risk was greatest in patients with a history of stroke and patients age ≥75 years.61 The U.S. Food and Drug Administration issued a warning for prasugrel, indicating use is contraindicated in patients with a prior cerebrovascular accident or transient ischemic attack or with pathologic bleeding. Additional risk factors for bleeding are age ≥75 years, propensity for bleeding, and concomitant use of medications that increase the risk of bleeding. Prasugrel has only been studied in patients with known coronary anatomy, so it has limited generalizability to ED patients.
Ticagrelor
Ticagrelor is a reversible nonthienopyridine P2Y12 receptor antagonist, with the effect gone within  days of stopping the agent. The PLATO study compared ticagrelor to clopidogrel62 in patients with ACS (with or without ST elevation). The composite primary outcome in those treated with ticagrelor was decreased by an absolute frequency of .9% without any difference in major bleeding. In patients with STEMI undergoing PCI, there was an increase in stroke in patients receiving ticagrelor (1.7% vs. .0%, P = .02).
Clopidogrel
The addition of clopidogrel to aspirin and antithrombin therapy improves cardiovascular outcomes in patients receiving fibrinolysis for STEMI. The CLARITY­TIMI  trial63 and the COMMIT trial64 both demonstrated improvements in hospital and 30­day outcomes with the addition of clopidogrel to standard therapy. The American College of Cardiology/American Heart
Association STEMI guidelines consider this dual therapy a Class I, level of evidence A recommendation.6
Clopidogrel reduces a composite outcome of death, AMI, and stroke in patients with unstable angina/NSTEMI. The CURE trial randomized patients with unstable angina/NSTEMI to clopidogrel
(300­milligram loading dose and 75­milligram daily dose) or placebo,65 with all patients receiving aspirin. The clopidogrel group had a 20% reduction in death, AMI, or stroke between  and  months. There was an excess of bleeding in the clopidogrel group compared with controls; however, this was reduced in patients who received lower doses of aspirin.
Give clopidogrel to patients with true aspirin allergy. Use this agent early in patients with ACS regardless of whether noninvasive management or PCI is planned.66 For patients undergoing urgent PCI, 600 milligrams is superior to 300 milligrams in preventing postprocedure myocardial infarction.67,68 However, the results of the CURRENT­OASIS­7 trial reported that although increasing the clopidogrel dose to 600 milligrams caused a decrease in ischemic events, there was also an increased rate of bleeding.69 Therefore, the current guidelines still provide a clopidogrel dose range of 300 to 600 milligrams in patients with unstable angina/NSTEMI.1
The U.S. Food and Drug Administration issued warnings on the efficacy of clopidogrel in two selected patient groups. First, patients taking omeprazole experience an approximately 50% reduction in the antiplatelet aggregation effects of clopidogrel. Second, patients with the variant CYP2C19 gene have impaired metabolism of clopidogrel and hence a reduced ability to convert the drug to its active form, leading to an increase in stent thromboses and recurrent ischemic events. Consider alternative antiplatelet agents in this group of patients.
Because of an increased bleeding risk, withhold clopidogrel for  days before coronary artery bypass grafting when possible. About 5% to 20% of patients with unstable angina/NSTEMI eventually have near­term coronary artery bypass grafting; do not withhold clopidogrel unless coronary artery bypass grafting is imminent.
Cangrelor
Cangrelor is an intravenous adenosine diphosphate receptor inhibitor that has been shown to reduce ischemic events in patients who undergo PCI when compared to clopidogrel. The proportion of STEMI patients in trials evaluating this agent is low; therefore, the level of recommendation for use by the European Society of Cardiology is Class IIb.70
Glycoprotein IIB/IIIA Inhibitors
Abciximab is a chimeric antibody that binds irreversibly to the glycoprotein IIb/IIIa antagonists. The duration of action is longer than that of the smaller peptide molecules. Eptifibatide is a synthetic heptapeptide that binds reversibly to the glycoprotein IIb/IIIa receptor. Tirofiban is a synthetic small molecule with reversible binding to the glycoprotein IIb/IIIa receptor. All require an IV infusion to demonstrate sustained benefits. Reversal of platelet inhibition after cessation of infusion is more rapid with the polypeptide or small­molecule agents eptifibatide or tirofiban, an advantage when bleeding complications occur.
Despite potential benefits, routine initiation of a glycoprotein IIb/IIIa inhibitor in the ED is not recommended due to conflicting information about the timing of PCI after administration and potential for bleeding.71
The glycoprotein IIb/IIIa inhibitor recommendations include patients with high­risk features, such as positive troponins, or patients treated with an early invasive strategy, but initiation prior to catheterization does not have proven benefit over initiation in the catheterization laboratory. Four large trials evaluated glycoprotein IIb/IIIa antagonists for the medical stabilization of patients with unstable angina/NSTEMI. Tirofiban and eptifibatide reduced the rates of the triple composite end point of death, AMI, and recurrent ischemia. However, abciximab did not benefit patients who did not undergo coronary angiography within  hours. Thus, the American Heart Association/American College of Cardiology guidelines for the management of unstable angina/NSTEMI patients make administration of glycoprotein IIb/IIIa inhibitors in patients treated with an early invasive strategy who are intermediate/high risk a Class IIb recommendation with eptifibatide and tirofiban the preferred agents.1
Antithrombins
Unfractionated Heparin
Unfractionated heparin reduces the risk of AMI and death during the acute phase of unstable angina. The combination therapy of aspirin and heparin reduces the short­term risk of death or
AMI by 56% compared with aspirin alone. When unfractionated heparin is used in combination with aspirin, recurrence of ischemia is diminished after cessation of the infusion. Thus, combination therapy with aspirin and heparin is indicated for patients with ACS.
Unfractionated heparin has an unpredictable anticoagulant response because the bioavailability of heparin is variable. Even in clinical trials, less than half of patients are appropriately anticoagulated within  hours. Unfractionated heparin requires careful laboratory monitoring and dose adjustment. The weight­adjusted regimen is recommended, with an initial bolus of
 units/kg (maximum of 4000 units per American Heart Association/American College of Cardiology guidelines1,6) and an infusion of  units/kg/h (maximum, 1000 units/h1,6).
Unfractionated heparin dosing according to the European Society of Cardiology is  to 100 units/kg IV bolus when no glycoprotein IIb/IIIa inhibitor is planned and  to  units/kg IV bolus when given with glycoprotein IIb/IIIa inhibitors.7 Optimally, cease unfractionated heparin after  hours of therapy to reduce the risk of developing heparin­induced thrombocytopenia.6 Use other agents if ongoing anticoagulation is needed.
Low­Molecular­Weight Heparins
The low­molecular­weight heparins have greater bioavailability, lower protein binding, and a longer half­life, and achieve a more reliable anticoagulant effect. As a result, they are given in a fixed dose subcutaneously once or twice a day and achieve a stable therapeutic response without the need for monitoring anticoagulation.
Large clinical trials show that enoxaparin, rather than unfractionated heparin, improved outcome in STEMI patients treated with aspirin and fibrinolysis.72Enoxaparin is not considered a first­line antithrombin for patients receiving primary PCI for treatment of STEMI6; however, in the event that a patient previously started on enoxaparin goes for PCI, enoxaparin should be continued.
A meta­analysis of six trials comparing enoxaparin with unfractionated heparin demonstrates a .9% reduction in death or recurrent AMI in patients receiving enoxaparin rather than unfractionated heparin, in addition to other standard therapies.73 The benefit of enoxaparin is greater in patients with higher risk, with a significant decrease in the composite end point of death, AMI, and recurrent ischemia requiring PCI at  days in patients with a Thrombolysis in Myocardial Infarction risk score of >3. Trials with high rates of PCI have demonstrated the safety and efficacy of low­molecular­weight heparins in patients receiving PCI. The SYNERGY trial demonstrated improved outcomes in patients with consistent therapy (use of a single antithrombin from the ED through the catheterization laboratory) and increased bleeding when the patient was changed from one antithrombin to another. The best approach is for the emergency physician and cardiologist to work in collaboration to choose the antithrombin agent used from ED through PCI and aftercare. If coronary artery bypass grafting is planned, hold lowmolecular­weight heparin for  to  hours, bridging with unfractionated heparin.
Fondaparinux
Fondaparinux is a synthetic pentasaccharide that binds to antithrombin III to form an antithrombic complex, but unlike heparin, this complex is very specific for factor Xa inhibition.
Fondaparinux has been evaluated in two large clinical trials. In STEMI patients, it has similar efficacy to unfractionated heparin in patients receiving fibrinolytics or primary PCI. However, the
European Society of Cardiology does not recommend fondaparinux in patients going for PCI.7 American College of Cardiology/American Heart Association guidelines make the following caution: fondaparinux is not a monotherapy for PCI; if used, add unfractionated heparin or bivalirudin before PCI.6
In unstable angina/NSTEMI patients, bleeding was lower in fondaparinux­treated versus enoxaparin­treated patients. For NSTEMI patients in whom conservative management is to be used, the American College of Chest Physicians Evidence­Based Clinical Practice Guidelines recommended fondaparinux over enoxaparin,74 as did the European Society of Cardiology,29 but it is not yet U.S. Food and Drug Administration approved for this indication.
Direct Thrombin Inhibitor: Bivalirudin
Direct thrombin inhibitors bind to the catalytic site of thrombin, bind to thrombin in clot, and are resistant to agents that degrade heparin. Bivalirudin reduces the short­term risk of postischemic complications relative to high­dose unfractionated heparin in patients undergoing PCI for unstable or postinfarction angina. The ACUITY trial demonstrated that bivalirudin is safe and effective for intermediate­ to high­risk unstable angina/NSTEMI patients receiving PCI.74 The HORIZONS­AMI trial showed that, in patients with STEMI who are undergoing PCI, anticoagulation with bivalirudin alone, as compared with unfractionated heparin plus glycoprotein IIb/IIIa inhibitors, resulted in significantly reduced 30­day rates of major bleeding.75
LIMITING INFARCT SIZE
Nitrates
Nitrates relax vascular smooth muscle in arteries, arterioles, and veins through the metabolic conversion of organic nitrates to nitric oxide. The pulmonary capillary wedge pressure, systemic arterial pressure, and left ventricular end­systolic and end­diastolic volumes decrease. Reductions in right and left ventricular filling pressures that result from peripheral dilatation combined with afterload reduction that results from arterial dilatation decrease cardiac work and myocardial O requirements. Nitroglycerin has direct vasodilator effects on the coronary vascular bed
 and increases global and regional myocardial blood flows. When obstructing atherosclerotic lesions contain intact vascular smooth muscle, nitrates may dilate these vessels, thereby improving blood flow. Platelet aggregation is also inhibited by nitroglycerin.
When nitroglycerin is used in AMI patients not treated with thrombolytics, it reduces infarct size, improves regional function, and decreases the rate of cardiovascular complications. The mortality rate is lowered by 35% with the use of nitrates. It is important to note that in most studies, IV nitroglycerin titration to 10% reduction in mean arterial pressure for normotensive patients and to 30% reduction in mean arterial pressure for hypertensive patients occurred, not for symptom resolution. In AMI, titrate IV nitroglycerin to blood pressure reduction rather than to symptom (chest pain) resolution. Data are confounded regarding a benefit of nitroglycerin in those receiving fibrinolytic therapy.
The American College of Cardiology/American Heart Association recommends the use of IV nitroglycerin for the first  to  hours for patients with STEMI and recurrent ischemia, congestive heart failure, or hypertension.5 Benefits are likely to be greatest in patients not receiving concurrent fibrinolytic therapy. For unstable angina/NSTEMI, IV nitroglycerin is used in patients who are not responsive to sublingual nitroglycerin tablets.1
The most serious side effect of nitroglycerin is hypotension, which may result in reflex tachycardia and worsening ischemia; paradoxical bradycardia can also follow nitrate use. Use nitroglycerin cautiously in patients with inferior wall ischemia, because one third of such patients might have right ventricular involvement; nitrates reduce preload and commonly trigger hypotension in this setting, worsening infarct. If nitroglycerin results in hypotension, stop the drug and administer fluid for blood pressure. Avoid nitrates in patients with ACS who recently received a phosphodiesterase inhibitor for erectile dysfunction (within  hours of sildenafil use or within  hours of tadalafil use).
β­Blockers
β­Adrenergic antagonists have antidysrhythmic, anti­ischemic, and antihypertensive properties. During AMI, they diminish myocardial O demand by decreasing heart rate, systemic arterial
 pressure, and myocardial contractility. Prolongation of diastole may augment perfusion to ischemic myocardium.
Contemporary trials show no benefit from early β­blocker therapy, and data from one large trial have changed the guideline recommendations for β­antagonists.76 The
COMMIT/CCS­2 trial randomized ,852 patients within  hours of myocardial infarction symptom onset to receive either IV metoprolol followed by PO metoprolol or placebo. Metoprolol reduced the absolute risks of reinfarction by  per 1000 and of ventricular fibrillation by  per 1000, but importantly, it increased the risk of cardiogenic shock by  per 1000. Overall, metoprolol did not significantly reduce mortality in the hospital.76,77American College of Cardiology/American Heart Association recommendations are to start PO (not IV) β­antagonists in patients with STEMI or NSTEMI within  hours provided the patient has none of the following: (1) signs of heart failure, (2) evidence of a low cardiac output state, (3) increased risk for cardiogenic shock (cumulatively: age >70 years old, systolic blood pressure <120 mm Hg, sinus tachycardia >110 beats/min or bradycardia <60 beats/min, and longer duration of STEMI symptoms before diagnosis and treatment), or (4) standard relative contraindications to β­blockade (PR interval >0.24 seconds, second­ or thirddegree heart block, active asthma, or reactive airway disease).1,6 IV therapy is reserved for patients with significant hypertension.
Angiotensin­Converting Enzyme Inhibitors
Angiotensin­converting enzyme inhibitors reduce left ventricular dysfunction and left ventricular dilatation and slow the development of congestive heart failure during AMI. Oral angiotensinconverting enzyme therapy lowers mortality after AMI.78
The American College of Cardiology/American Heart Association recommend that patients with STEMI or heart failure receive treatment with oral angiotensin­converting enzyme inhibitors within the first  hours (not necessarily in the ED).6 For unstable angina/NSTEMI, angiotensin­converting enzyme inhibitors should be administered within the first  hours in patients with pulmonary congestion or a left ventricular ejection fraction <40%, in the absence of hypotension or contraindications.1
Contraindications to angiotensin­converting enzyme inhibitors include hypotension, bilateral renal artery stenosis, renal failure, or history of cough or angioedema due to prior angiotensinconverting enzyme inhibitor use. The efficacy of angiotensin­converting enzyme inhibitors in unstable angina has not been well evaluated.
Magnesium
Magnesium produces systemic and coronary vasodilatation, possesses antiplatelet activity, suppresses automaticity, and protects myocytes from calcium influx during reperfusion. However, studies are conflicting: some have found that the mortality rate is reduced, whereas others have shown no benefit at all. In light of these conflicting data, correct documented hypomagnesemia during AMI and give magnesium for torsades de pointes–type ventricular tachycardia or with a prolonged QT interval.6 Magnesium bolus and infusion in high­risk patients, such as the elderly and those in whom reperfusion therapy is not suitable, are considered possibly beneficial.6
Calcium Channel Antagonists
Calcium channel blockers have antianginal, vasodilatory, and antihypertensive properties. Calcium antagonists do not reduce mortality rate after AMI, and they may be harmful to some patients with cardiovascular disease.6
Verapamil and diltiazem are potentially beneficial in patients with ongoing ischemia or atrial fibrillation with rapid ventricular response who do not have congestive heart failure, left ventricular dysfunction, or atrioventricular block, and when β­adrenergic antagonists are contraindicated.
COMPLICATIONS OF ACUTE CORONARY SYNDROME
Myocardial perfusion and cardiac function affect blood flow to the entire body. As a result, any end organ can be damaged when cardiac pump function is decreased. In this section, discussion of the complications of ACS is limited to the direct effects on the heart. The systemic effects of cardiac function are discussed in organ­appropriate chapters of this book.
Dysrhythmias and Conduction Disturbances
The genesis, diagnosis, and treatment of dysrhythmias are presented in Chapter , “Cardiac Rhythm Disturbances.” The effect dysrhythmias have in complicating the course of patients with
ACS is the subject of this section.
Dysrhythmias occur in 72% to 100% of AMI patients treated in the coronary care unit. Table 49­12 shows the approximate frequency of the various dysrhythmias observed in patients with
AMI. Many dysrhythmias occur in the prehospital and ED settings. The main consequences of dysrhythmias are impaired hemodynamic performance, compromised myocardial viability due to increased myocardial O requirements, and predisposition to even more serious rhythm disturbances due to diminished ventricular fibrillation threshold. (See Video: Zoll Live Vest.)

Video 49­10: Zoll LifeVest
Used with permission from Heather Heaton and Daniel Renner, University of North Carolina, Department of Emergency Medicine, Chapel Hill, NC.
Play Video
TABLE 49­12
Early Dysrhythmias After Acute Myocardial Infarction

## Page 26

Dysrhythmia Frequency of Occurrence (%)
Bradydysrhythmias
Sinus bradycardia 35–40
First­degree AV block 4–15
Second­degree AV block, type I 4–10
Second­degree AV block, type II .5–1.0
Third­degree AV block 5–8
Asystole 1–5
Tachydysrhythmias
Sinus tachycardia 30–35
Atrial premature contractions 
Supraventricular tachycardia 2–9
Atrial fibrillation 4–10
Atrial flutter 1–2
Ventricular premature beats 
Accelerated idioventricular rhythm 50–70
Ventricular tachycardia, nonsustained 60–69
Ventricular tachycardia, sustained 2–6
Ventricular fibrillation 4–7
Abbreviation: AV = atrioventricular.
Wearable Cardioverter­Defibrillators
A wearable cardioverter­defibrillator, of which one is the LifeVest®, is a cardiac monitor and a vest­like garment worn under clothing to monitor cardiac rhythm and automatically deliver cardioversion or defibrillation when a lethal dysrhythmia develops. It is often used as a bridge to automatic implantable cardioverter­defibrillator placement or immediately after STEMI. ED patients wearing a LifeVest® or other such garment should keep the garment on in the ED. It can be removed for procedures or radiographs, as long as the patient is placed on a cardiac monitor and can be observed for the development of a life­threatening dysrhythmia. Do not cut the device off as it is usually a rented device and is returned to the company when no longer needed. As of this writing, whether the device can prevent post–myocardial infarction sudden cardiac death is unclear.
The hemodynamic consequences of dysrhythmias are dependent on ventricular function. Patients with left ventricular dysfunction have a relatively fixed stroke volume. They depend on changes in heart rate to alter cardiac output. The range of heart rate that is optimal becomes narrowed with increasing dysfunction. Slower or faster heart rates may further depress cardiac output.
In addition, maintenance of the atrial filling of the ventricle (or “the atrial kick”) is important for patients with AMI. Patients with normal hearts have a loss of 10% to 20% of left ventricular output when the atrial kick is eliminated. Patients with reduced left ventricular compliance, common in AMI, have up to 35% reduction in stroke volume when the atrial systole is eliminated.
“Pump” failure with resultant increased sympathetic stimulation can also result in sinus tachycardia, atrial fibrillation or flutter, and supraventricular tachycardias.
University of Pittsburgh
Sinus tachycardia is quite prominent in patients with anterior wall AMI. Because of increased myocardial O
 use, persistent sinus tachycardia is associateAdcc wesist hP raov pidoedo bry p:rognosis in AMI; seek the cause and resolve it. Causes may include anxiety, pain, left ventricular failure, fever, pericarditis, hypovolemia, atrial infarction, pulmonary emboli, or use of medications that accelerate heart rate. Similarly, paroxysmal supraventricular tachycardia, atrial fibrillation, and atrial flutter are associated with an increased mortality.
Atrial fibrillation associated with AMI most typically occurs in the first  hours and is usually transient. It more often occurs in patients with excess catecholamine release, hypokalemia, hypomagnesemia, hypoxia, chronic lung disease, and sinus node or left circumflex ischemia. Patients with supraventricular tachycardia, atrial fibrillation, or atrial flutter who have hemodynamic compromise are best treated with direct current cardioversion (see Chapter 18). Patients who are partially or fully compensated or who do not respond to cardioversion can receive amiodarone or β­adrenergic antagonists to slow the ventricular rate79 absent any contraindications. Patients with ongoing ischemia but without hemodynamic compromise, clinical left ventricular dysfunction, reactive airway disease, or heart block should have rate control with β­adrenergic antagonists, such as atenolol (2.5 to .0 milligrams over  minutes to a total of  milligrams) or metoprolol (2.5 to .0 milligrams every  to  minutes to a total of  milligrams). Patients with contraindications to β­adrenergic antagonists can be treated with digoxin (0.3­ to
.5­milligram initial bolus with a repeat dose in  hours) or a calcium channel antagonist.6 Anticoagulate patients with atrial fibrillation and AMI to limit systemic embolization.
Sinus bradycardia without hypotension does not appear to increase mortality during AMI. Prognosis is related to the site of infarction, the site of the block (intranodal vs. infranodal), the type of escape rhythm, and the hemodynamic response to the rhythm. Atropine is used for sinus bradycardia when it results in hypotension, ischemia, or ventricular escape rhythms and for treatment of symptomatic atrioventricular block occurring at the atrioventricular nodal level (e.g., second­degree type I). Atropine can improve heart rate, systemic vascular resistance, and blood pressure; use it with caution in the setting of AMI since the parasympathetic tone is protective against infarct extension, ventricular fibrillation, and excessive myocardial O demand.

Complete heart block can occur in patients with anterior and inferior AMI because the atrioventricular conduction system receives blood supply from the atrioventricular branch of the right coronary artery and the septal perforating branch of the left anterior descending coronary artery. In the absence of right ventricular involvement, the mortality is approximately 15%. It rises to >30% when right ventricular involvement is present. Complete heart block in the setting of an anterior myocardial infarction portends a grave prognosis. Junctional rhythms are usually transient and occur within  hours of infarction.
The increased mortality in patients with heart block during AMI is related to more extensive myocardial damage and not to the heart block itself. As a result, pacing does not reduce mortality in patients with atrioventricular block or intraventricular conduction delay. Nonetheless, pacing is recommended to protect against sudden hypotension, acute ischemia, and precipitation of ventricular dysrhythmias in certain patients.
Use temporary transcutaneous pacers in patients at moderate to high risk of progression to atrioventricular block (Table 49­13). Transvenous pacing follows for patients with a high likelihood (>30%) of requiring permanent pacing (Table 49­13). Patients with right ventricular infarction who are very dependent on atrial systole may require atrioventricular sequential pacing to maintain cardiac output.
TABLE 49­13
Indications for Temporary Pacemaker Placement
Temporary transcutaneous pacemaker indications
Unresponsive symptomatic bradycardia
Mobitz II or higher AV blocks
New LBBB and bifascicular blocks
RBBB or LBBB with first­degree block
Some cases with stable bradycardia and new or indeterminate­age RBBB
Temporary transvenous pacemaker indications
Asystole
Unresponsive symptomatic bradycardia
Mobitz II or higher AV blocks
New or indeterminate­age LBBB
Alternating bundle branch block
RBBB or LBBB with first­degree block
Consider in RBBB with left anterior or posterior hemiblocks
Overdrive pacing in unresponsive ventricular tachycardia
Unresponsive recurrent sinus pauses (>3 s)
Abbreviations: AV = atrioventricular; LBBB = left bundle branch block; RBBB = right bundle branch block.
Ventricular premature contractions are common in patients with AMI and are benign. Accelerated idioventricular rhythms in patients with AMI do not affect prognosis or require treatment. Ventricular tachycardia shortly after AMI is often transient and does not confer a poor prognosis. When ventricular tachycardia occurs late in the course of AMI, it is usually associated with transmural infarction and left ventricular dysfunction, induces hemodynamic deterioration, and is associated with a mortality rate approaching 50%. Primary ventricular fibrillation occurring shortly after symptom onset does not appear to have a large effect on mortality and prognosis, as long as it is quickly and effectively treated. Delayed or secondary ventricular fibrillation during hospitalization is associated with severe ventricular dysfunction and 75% in­hospital mortality.
New right bundle branch block occurs in approximately 2% of AMI patients, most commonly with anteroseptal AMI; it is associated with an increased mortality and complete atrioventricular block. New left bundle branch block occurs in <10% of patients with AMI and is also associated with a higher mortality than in patients without left bundle branch block.
Recognizing STEMI in the presence of left bundle branch block is difficult,9 and due to this uncertainty and false catheterization lab activation, new or suspected new left bundle branch block alone has been removed from the most recent recommendations for emergency perfusion.6 The left posterior fascicle is larger than the left anterior fascicle. Thus, left posterior hemiblock is associated with a higher mortality than is isolated left anterior hemiblock, because it represents a larger area of infarction. Bifascicular block (right bundle branch block and a left hemiblock) has an increased likelihood of progression to complete heart block; it represents a large infarction and has more frequent pump failure and greater mortality.28 See Chapter , “Cardiac
Rhythm Disturbances,” for more detail.

Heart Failure
Chapter 49: Acute Coronary Syndromes, Deborah B. Diercks; Judd E. Hollander; Anna Marie Chang 
. Terms of Use * Privacy Policy * Notice * Accessibility
Approximately 15% to 20% of patients with AMI present with some degree of heart failure. One third of these patients have circulatory shock. In AMI, heart failure occurs from diastolic dysfunction alone or a combination of systolic and diastolic dysfunction. Left ventricular diastolic dysfunction leads to pulmonary congestion. Systolic dysfunction is responsible for decreased forward flow, reduced cardiac output, and reduced ejection fraction. In general, the more severe the degree of left ventricular dysfunction, the higher is the mortality. The degree of left ventricular dysfunction in any single patient depends on the net effect of prior myocardial dysfunction (prior myocardial infarction or cardiomyopathy), baseline myocardial hypertrophy, acute myocardial necrosis, and acute reversible myocardial dysfunction (“stunned myocardium”). For further discussion, see Chapter , “Cardiogenic Shock,” and Chapter , “Acute Heart
Failure.”
Mortality for patients with AMI increases as cardiac output decreases or pulmonary congestion increases, with mortality rates as follows: no heart failure, 10%; mild heart failure, 15% to 20%; frank pulmonary edema, 40%; and cardiogenic shock, 50% to 80%. Elevated levels of B­type natriuretic peptide or pro­B­type natriuretic peptide early in the hospital course portend a worse
30­day outcome.
The presence of shock in AMI results in a complex spiral relationship. Coronary obstruction leads to myocardial ischemia, which impairs myocardial contractility and ventricular outflow. The resulting reduction in arterial blood pressure leads to further decreases in coronary arterial perfusion, resulting in worsening myocardial ischemia and more severe myocardial necrosis.
Interruption of this downward spiral requires careful attention to fluid management and the use of inotropic agents. Resolution of ischemia and preventing or minimizing the area of stunned myocardium that progresses to infarction are imperative; guidelines recommend that patients with STEMI and cardiogenic shock who are <75 years of age should be considered for PCI.6 For further discussion, see Chapters  and . Mechanical Complications
Sudden decompensation of previously stable patients should raise concern for the mechanical complications of AMI. These complications usually involve the tearing or rupture of infarcted tissue, not seen in unstable angina. The clinical presentation of these entities depends on the site of rupture (papillary muscles, interventricular septum, or ventricular free wall).
Ventricular free wall rupture occurs in 10% of AMI fatalities, usually  to  days after infarction. Rupture of the left ventricular free wall usually leads to pericardial tamponade and death
(in >90% of cases). Patients may complain of tearing pain or sudden onset of severe pain. They will be hypotensive and tachycardic and may have onset of confusion and agitation. Increased neck veins, decreased heart sounds, and pulsus paradoxus may be present. In the ED, echocardiography is the diagnostic test of choice. Near equalization of right atrial, right ventricular middiastolic, and right ventricular systolic pressures on pulmonary artery catheterization is also useful but seldom available in the ED. Treatment is surgical.
Rupture of the interventricular septum is more often detected clinically than rupture of the ventricular free wall. The size of the defect determines the degree of left­to­right shunt and the ultimate prognosis. Clinically, interventricular septal rupture presents with chest pain, dyspnea, and sudden appearance of a new holosystolic murmur. The murmur is usually accompanied by a palpable thrill and is heard best at the lower left sternal border. Doppler echocardiography is the diagnostic procedure of choice. Demonstration of left­to­right shunt by pulmonary catheter blood sampling may be useful. An O step­up of >10% from right atrial to right ventricular samples is diagnostic. Rupture of the interventricular septum is more common
 in patients with anterior wall myocardial infarction and patients with extensive (three­vessel) coronary artery disease. Treatment is surgical.
Papillary muscle rupture occurs in approximately 1% of patients with AMI, is more common with inferior myocardial infarction, and usually occurs  to  days after AMI. In contrast to rupture of the interventricular septum, papillary muscle rupture often occurs with a small­ to modest­sized AMI. Patients present with acute onset of dyspnea, increasing heart failure and pulmonary edema, and a new holosystolic murmur consistent with mitral regurgitation. The posteromedial papillary muscle is most commonly ruptured, because it receives blood supply from one coronary artery, usually the right coronary artery. Echocardiography often can distinguish rupture of a portion of the papillary muscle from other etiologies of mitral regurgitation.
Treatment is surgical.6,7
Pericarditis
In the current era of early PCI intervention, early post­AMI pericarditis occurs in <5% of patients,79 a drop from 20% since the 1980s. It is more common in patients with transmural AMI and delayed initial presentations. Pericarditis results from inflammation adjacent on the epicardial surface of a transmural infarction, often  to  days after AMI. Pericardial friction rubs are detected more often with inferior wall and right ventricular infarction, because the right ventricle lies immediately beneath the chest wall. The pain of pericarditis can be confused with that of infarct extension or post­AMI angina. Classically, the discomfort of pericarditis becomes worse with a deep inspiration and may be relieved by sitting forward.
Echocardiography may demonstrate a pericardial effusion; pericardial effusions are much more common than pericarditis and often are present in the absence of pericarditis. Similarly, pericarditis can be present in the absence of a pericardial effusion. The resorption rate of post­AMI pericardial effusions is slow, often taking several months. Treatment is symptomatic with aspirin, 650 milligrams PO every  to  hours, or colchicine, .6 mg twice daily. Ibuprofen interferes with the antiplatelet effect of aspirin and can cause myocardial scar thinning and infarct expansion. Dressler’s syndrome (late post­AMI syndrome) occurs  to  weeks after AMI and presents with chest pain, fever, and pleuropericarditis. Dressler’s syndrome is treated with aspirin and colchicine.80–82
Right Ventricular Infarction
Isolated right ventricular infarction is extremely rare and is usually seen as a complication of an inferior infarction (Figure 49­6 and Figure 49­14). The right ventricle most commonly receives its blood supply from the right coronary artery. In patients with left dominant systems, the blood supply may come from the left circumflex. The anterior portion of the right ventricle is supplied by branches of the left anterior diagonal artery. Approximately 30% of inferior wall myocardial infarction involves the right ventricle. The presence of right ventricular infarction is associated with a significant increase in mortality and cardiovascular complications. Right ventricular infarction can be diagnosed by the presence of ST­segment elevation in the precordial
V R lead in the setting of an inferior wall myocardial infarction (Figure 49­6). The presence of elevated neck veins or hypotension in response to nitroglycerin is also suggestive.

Echocardiography or nuclear imaging can be diagnostic, but they are less readily available in the ED.
Figure 49­14
Right­sided leads demonstrating right ventricular infarction associated with inferior wall myocardial infarction. Right­sided leads have replaced the normal left­sided V leads. In this example, the ST­segment elevation is prominent in leads V R to V R.

The most serious complication of right ventricular infarction is shock. The severity of the hemodynamic derangement in the setting of right ventricular infarction is related to the extent of right ventricular dysfunction, the interaction between the ventricles (the right and left ventricles share the interventricular septum), and the interaction between the pericardium and the right ventricle. Right ventricular infarction results in a reduction in right ventricular end­systolic pressure, left ventricular end­diastolic size, cardiac output, and aortic pressure as the right ventricle becomes more of a passive conduit to blood flow. Left ventricular contraction causes bulging of the interventricular septum into the right ventricle, with resultant ejection of blood into the pulmonary circulation. As a result, right ventricular infarction with concurrent left ventricular infarction has a particularly devastating effect on hemodynamic function. Fluid balance and maintenance of adequate preload are critical in the treatment of right ventricular infarction. Factors that reduce preload (volume depletion, diuretics, and nitrates) or decrease right atrial contraction (atrial infarction and loss of atrioventricular synchrony) and factors that increase right ventricular afterload (left ventricular failure) can lead to significant hemodynamic derangements.
Treatment of right ventricular infarction includes maintenance of preload, reduction of right ventricular afterload, and inotropic support of the ischemic right ventricle, in addition to early reperfusion. Patients with right ventricular infarction should not be treated with drugs, such as nitrates, that reduce preload. In the setting of right ventricular infarction, nitrates often will reduce cardiac output and produce hypotension. Instead, patients with marginal preload or hypotension should be treated with volume loading (normal saline). The increased preload will improve right ventricular cardiac output. If cardiac output is not improved after  to  L of normal saline, begin inotropic support.
High­degree heart block is very common in patients with right ventricular infarction. The loss of right atrial contraction can greatly compromise right ventricular cardiac output. Restitution of atrioventricular synchrony is important. Patients who do not attain hemodynamic improvement after placement of a ventricular pacer may still improve with atrioventricular sequential pacing.
When right ventricular infarction is accompanied by left ventricular dysfunction, the use of nitroprusside to reduce afterload or intra­aortic balloon counterpulsation may be of benefit.
Reduction in left ventricular afterload may help passive movement of blood through the right ventricle.
Other Complications
Other complications of AMI that occur but are not usually seen in the ED include left ventricular thrombus formation, arterial embolization, venous thrombosis, pulmonary embolism, postinfarction angina, and infarct extension. With the more rapid discharge of uncomplicated AMI patients, keep these possibilities in mind for patients who return to the ED shortly after hospital discharge.
Recurrent or Refractory Ischemia
Patients unresponsive to medical management with continued ischemia require an individualized approach to treatment. Refractory ischemia is investigated with coronary catheterization.
Treat patients with ACS after stent placement with antithrombin and antiplatelet therapy, and these patients may require urgent coronary catheterization.
In situations where emergent catheterization is not available or the patient is hemodynamically unstable, an intra­aortic balloon pump may be used. Intra­aortic balloon counterpulsation delivers phased pulsations synchronized to the ECG, so that balloon inflation will occur at the time of aortic valve closure and deflation occurs just before onset of systole. The augmented coronary perfusion pressure during diastole enhances coronary blood flow. Balloon deflation during systole allows the left ventricle to eject blood against a lower resistance. The net effect of intra­aortic balloon counterpulsation is an increase in cardiac output, reduction in systolic arterial pressure, increase in diastolic arterial pressure, little change in mean arterial pressure, and reduction in heart rate. The reduction in left ventricular afterload leads to reduced myocardial O consumption, thereby decreasing the amount of myocardial ischemia. Intra­aortic balloon
 counterpulsation is recommended for patients with ACS who are refractory to aggressive medical management or are hemodynamically unstable as a means to bridge a patient’s stability en route to definitive treatment.
SPECIAL POPULATIONS
Postprocedure Chest Pain
Patients who present with symptoms of an ACS shortly after PCIs, such as angioplasty or stent placement, should be assumed to have had abrupt vessel closure, until proven otherwise. Subacute thrombotic occlusion after stent placement occurs in approximately 4% of patients  to  days after procedure. Bare metal stents are more likely to restenose in the short term. Drug­eluting stents are more likely to present with late stent thrombosis after cessation of daily clopidogrel,  to  months later. Treat patients aggressively for an ACS, and obtain emergent cardiology consultation. Patients with chest pain syndromes after coronary artery bypass grafting also may have abrupt vessel closure.
However, symptoms of recurrent ischemia can be confused with post­AMI pericarditis, as discussed earlier.
Cocaine­ and Amphetamine­Induced Acute Coronary Syndrome
AMI occurs in approximately 6% of patients who present to the ED with chest pain after cocaine use. Cocaine­associated myocardial infarction occurs in younger patients, but over the past two decades, the average age has increased from  years83 to  years,84 highlighting the increased use of cocaine in middle­age patients. The sensitivity, specificity, positive predictive value, and negative predictive value of the ECG to identify cocaine­associated MI are 36%, .9%, .9%, and .8%, respectively.85 Cardiac troponin is the most sensitive biomarker for cocaineassociated myocardial infarction. Aspirin, nitrates, and benzodiazepines are the mainstays of therapy for initial stabilization; β­blockers are contraindicated in the first  hours.85 Patients with cocaine­associated STEMI are best managed with PCI.83 Antithrombotic and antiplatelet therapy may be given according to current guidelines for non–cocaine­related ACS.
There are fewer cases of amphetamine­induced myocardial infarction to guide therapy and no care guidelines. The initial ECG may be unreliable in the setting of methamphetamine­related
ACS, with false­positive ST­segment elevation prompting unneeded thrombolytic therapy. In one case series of  patients admitted for chest pain who were methamphetamine positive, nine
(25%) were diagnosed with ACS (positive markers or required revascularization). Three patients (8%; two ACS and one non­ACS) suffered cardiac complications (ventricular fibrillation, ventricular tachycardia, and supraventricular tachycardia, respectively). Only one patient had Q­wave myocardial infarction treated with PCI. Medical management was the mainstay of therapy.
Acute Medical Disorders Associated with Acute Coronary Syndrome
Those with GI bleeding,84 stroke,85,86 and severe infection have a higher frequency of ACS87; even those with disorders considered otherwise benign, such as acute anxiety or emotional upset, have a higher frequency of myocardial infarction.88 In the case of stroke and GI bleeding, the primary disease process (which came first) is sometimes unclear or underdiagnosed until late in the patient’s course. In a group of patients admitted to the intensive care unit for GI bleeding, approximately 13% sustained myocardial infarction; however, this did not affect mortality in this intensive care unit population. A case­control study found increased risk of death in patients with GI bleeding meeting criteria for myocardial infarction when compared with those with negative markers (33% vs. 8%).84 In general, treatment of the GI bleed takes priority, which precludes the major treatments for AMI. For patients with acute ischemic stroke, 17% have positive troponin assessment, which is associated with .2 relative risk of death compared with patients with normal troponin. The risk of stroke complicating the course of
AMI has been formerly reported as .4% to .5%,89 but with improved treatments for AMI, the risk has dropped to .6% to .8%. Hospital mortality in patients with stroke after AMI is high (17% to 27%). ECG abnormalities are common in patients with subarachnoid hemorrhage, and elevated troponin levels occur in 28%, with over half of these demonstrating transient left ventricular dysfunction. However, simultaneous STEMI is not common with a subarachnoid hemorrhage. Approximately 50% of patients with severe sepsis and septic shock have impairment of left ventricular systolic function, frequently with an elevated troponin level.88 AMI occurs in .3% of patients hospitalized with community­acquired pneumonia, with the risk increasing to 15% in those with severe pneumonia.90
For all patients with dual or multiple acute medical issues, individualize management and weigh the risks of AMI guideline therapies. When indicated, use PCI over thrombolysis to identify the lesion and need for additional therapy.
After Hours and Weekend Presentations
The management of patients with ACS is time sensitive and intensive. Patients who present “after hours” and on weekends wait longer for interventions, with an adverse impact on outcome.
Patients who present when the ED is busy with other ill patients (e.g., trauma patients), patients who present in settings with increased health system dysfunction and high levels of ED boarding, and patients who are not expeditiously transferred to an inpatient bed have worse outcomes.91–93 Systems solutions to improve hospital flow for patients with ACS will help optimize the care of patients with ACS.
Cardiac Complications of COVID­19
Coronavirus 2019 (COVID­19), caused by severe acute respiratory syndrome coronavirus  (SARS­CoV­2), appeared in late 2019, and it was declared a worldwide pandemic by the World Health
Organization on March , 2020.94 While respiratory illness symptoms predominate, the virus has been affecting all organ systems. Several cardiovascular sequelae are associated with COVID­
, ​​​including dysrhythmias, myocarditis, acute coronary syndrome, venous thromboembolism, cardiogenic shock, and heart failure.95
Myocardial injury, defined by an increased troponin level, occurs in about 25% of patients with COVID­19 with mortality rates of .2% vs. .5% in those without myocardial injury.96 Patients with underlying cardiovascular disease are at greatest risk.96,97 In an Italian cohort of 388 consecutive COVID­19 patients, the rate of diagnosis of acute coronary syndrome was .1%.98 While
COVID­19 is often characterized by coagulation activation and endothelial dysfunction leading to thromboembolic disease, thus far there have not been significant increases in type  myocardial infarction due to COVID­19, but clinical concerns remain high. In one case series from six New York hospitals,  patients were identified with ST­segment elevation;  underwent coronary angiography, and only  of these patients had obstructive coronary artery disease.99
Treatment of patients with acute coronary syndromes during COVID­19
An unintended consequence of social distancing and containment policies, may be the reluctance of patients to seek medical care for acute cardiovascular conditions. A report from  hospitals in northern Italy compared the mean number of admissions for acute coronary syndromes in the early days of the pandemic (February , 2020 through March , 2020), compared to control periods of the same period a year prior, and an earlier period during 2020. During the pandemic, 248 (45.3%) presented with ST­segment elevation myocardial infarction (STEMI).
The mean admission rate for STEMI during the study period was .1 admissions per day, compared to .0 admissions per day of the same period a year prior. The mean admission rate for acute coronary syndrome (ACS) during the study period was .3 admissions per day. This rate was significantly lower than either the rate during the earlier period in the same year (18.0 admissions per day) or the rate during the previous year (18.9 admissions per day, p<0.001).100
The American College of Cardiology’s (ACC) Interventional Council and the Society for Cardiovascular Angiography and Interventions (SCAI) issued a joint statement to discuss issues facing catheterization laboratory personnel during the pandemic. China outlined a protocol for STEMI which includes rapid SARS­CoV2 testing and followed by fibrinolytic therapy, compared to primary percutaneous coronary intervention (PCI) as the preferred treatment. The protocol from the Sichuan Provincial People’s Hospital recommended that patients with STEMI onset time of <12 h without contraindications are to be thrombolysed, followed by later elective PCI.101 The ACC/SCAI statement recommends a balance of staff exposure and patient benefit, stating that fibrinolysis is an option for a stable patient with STEMI and active COVID­19. Recognizing again that there are a high number of patients with elevated troponin and type  myocardial infarction, the statement suggests that appropriately selected cases of patients with known COVID­19 and NSTEMI (e.g., particularly for those with type  myocardial infarction), conservative therapy may be sufficient on the basis of patient risk.102
As of May , 2020, North American Cardiovascular Societies including the ACC have provided some guidance on the reintroduction of cardiovascular services during COVID­19.103 The societies recommend collaboration with public health officials, and procedure prioritization based on the environment of the region. As an example, in those areas with high prevalence of COVID­19 and limited procedural capability, low­risk NSTEMI and unstable angina are still recommended for medical therapy, and fibrinolysis may be preferred for STEMI. Those regions that are reintroducing most services may consider PCI. Identification of STEMI and selection of treatment options in patients with or without active COVID­19 disease require close collaboration between EMS systems, emergency departments, and cardiologists.


