## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 192: Methylxanthines and Nicotine
Chip Gresham; Daniel E. Brooks
INTRODUCTION
Methylxanthines include caffeine, theophylline, theobromine, and nicotine. These agents are plant­derived alkaloids with ubiquitous use in beverages (caffeine in coffee and soda), foods (theobromine in chocolate), tobacco products (nicotine), and medications (theophylline and caffeine).
,2
Newer methylxanthine derivatives include pentoxifylline (improves peripheral blood flow) and doxofylline (a bronchodilator). All methylxanthines have shared pharmacologic properties and very similar pharmacodynamic effects.
METHYLXANTHINES
EPIDEMIOLOGY
Caffeine (1,3,7­trimethylxanthine), a structural analog of adenosine, is found with varying amounts in beverages and “energy­enhanced” foods, such
 as candy bars, potato chips, and oatmeal (Table 192­1). Many “energy drinks” contain guarana, a plant whose seeds contain high concentrations of
 caffeine and other methylxanthines. Drinks with guarana may not list caffeine as an ingredient. Other uses for caffeine include apnea of prematurity, analgesic adjuncts, postdural puncture headache, appetite suppression for weight loss, sleep prevention, and diuresis.
TABLE 192­1
Caffeine Content of Various Products
Source Caffeine Content (milligrams)
Coffee (8 oz or 240 mL, brewed) 60–120
Tea (8 oz or 240 mL, brewed) 20–90
Colas, caffeinated (8 oz or 240 mL) 20–40
Dark chocolate (1 oz or  mL) 5–35
“Higher caffeine energy drinks” (8–24 oz) 70–505
Acetaminophen­aspirin­caffeine tablet 
Nonprescription antidrowsiness tablet 200
Caffeine powder (via online sources) Varies; up to 1700 per  mL
Theophylline (1,3­dimethylxanthine) and its water­soluble salt, aminophylline, were used extensively in the past for the treatment of asthma and chronic obstructive pulmonary disease. However, theophylline’s use has declined due to its narrow therapeutic window and the development of safer agents. Theophylline is still used in patients with debilitating bronchospastic disease, particularly outside the United States.

Theobromine (3,7­dimethylxanthine) is found in the seeds of Theobroma cacao, from which chocolate and cocoa are derived, and Camellia thea,
Chapter 192: Methylxanthines and Nicotine, Chip Gresham; Daniel E. Brooks from which teas are steeped, and is an ingredient in numerous “energy drinks” in addition to caffeine. There are very few cases of human toxicity, but
. Terms of Use * Privacy Policy * Notice * Accessibility
 theobromine has been associated with atrial fibrillation.
PHARMACOLOGY
Caffeine is most commonly consumed orally; however, it can be administered rectally or parenterally. Theophylline is usually taken orally as an elixir or as an extended­release or controlled­release tablet, although its absorption may be affected by food. Controlled­release tablets can result in erratic or delayed absorption. Theophylline can also be administered IV as aminophylline.
All methylxanthines are rapidly absorbed with early peak levels, cross the blood–brain barrier and placenta, and are excreted in breast milk (Table
192­2). Half­lives are only accurate at therapeutic concentrations and vary according to drug level, age extremes, smoking, organ system dysfunction
(e.g., cirrhosis), infection, and cytochrome P450 inhibition (Table 192­3).
TABLE 192­2
Pharmacokinetics of Methylxanthines
Parameter Caffeine Theophylline
Therapeutic serum concentration 5–20 micrograms/mL 8–20 micrograms/mL
(25–100 micromole/L) (44–110 micromole/L)
Bioavailability (oral) ∼100% ∼100%
Oral peak absorption (h) (delayed in overdose) .5–1.0 1–2
(up to  h with sustained­release preparations)
Volume of distribution (L/kg) ∼0.6 ∼0.5
Protein binding ∼35% ∼60%
Major active metabolites Paraxanthine Caffeine (only if <6 mo old)
Theobromine
Theophylline
Clearance Hepatic <1 y old: 50% hepatic and 50% renal
>1 y old: 90% hepatic and 10% renal
Half­life (accurate only at therapeutic concentrations) Neonates: >50 h Neonates: 20–30 h
<1 y old:  h Children and adults:  h
>1 y old:  h >60 y old:  h
TABLE 192­3
Factors Affecting Theophylline Clearance
Increase Theophylline Clearance Decrease Theophylline Clearance
Medications Barbiturates Cimetidine
Benzodiazepines (suspected) Ethanol (coingested)
Carbamazepine Erythromycin (all macrolides suspected)
Phenytoin Oral contraceptives
St. John’s wort Propranolol (metoprolol suspected)
Fluoroquinolones (most)
Verapamil
Medical conditions Cirrhosis
Heart failure
Pneumonia (other infections suspected)
Other Hyperthyroidism Pregnancy
Tobacco Obesity
Marijuana (cannabis) Fever (suspected)
Methylxanthines exhibit Michaelis­Menten kinetics; that is, metabolism changes from first­order to zero­order kinetics at increased concentrations such that a fixed amount, not percentage, of drug is eliminated per unit of time, making accurate half­life predictions impossible following an overdose. This also explains why patients who chronically use theophylline may develop a large increase in serum theophylline concentration with only a small increase in dose. Methylxanthines are metabolized in the liver by the cytochrome P450 1A2 pathway. Theophylline undergoes significant enterohepatic recirculation, so toxic serum levels can be maintained longer than anticipated.
CLINICAL FEATURES OF TOXICITY
Theophylline has the most potential for significant toxicity, followed by caffeine and then theobromine. The underlying pathophysiology involves adenosine antagonism, increased endogenous adrenergic stimulation, and, at toxic levels, phosphodiesterase inhibition (Table 192­4).
TABLE 192­4
Methylxanthine Mechanisms of Action and Toxicity
Adenosine Antagonism Increased Catecholamines Inhibition of Phosphodiesterase
Mechanism Inhibition of adenosine­1 and Increased circulating catecholamines Phosphodiesterase inhibition (at toxic levels) adenosine­2 > adenosine­3 receptors (epinephrine and norepinephrine)
Effect Decreased adenosine activity Stimulation of β and β receptors Increased concentration of cyclic adenosine

Increased excitatory monophosphate and catecholamine effects neurotransmitters activity
Therapeutic Bronchodilation Bronchodilation No role at therapeutic doses effect
Clinical Vasoconstriction Tachycardia Enhanced β­adrenergic effects toxicity Dysrhythmias Vasodilation
Seizures Hypotension
The main organ systems involved in methylxanthine toxicity are GI, neurologic, cardiovascular, and metabolic (Table 192­5).
TABLE 192­5
Clinical Manifestations of Methylxanthine Toxicity
Organ System Manifestation
GI Nausea
Vomiting
Gastritis
Neurologic Headache
Tremor
Agitation
Seizure
Cardiovascular Tachycardia
Hypotension
Atrial dysrhythmias
Ventricular ectopy
Metabolic Hypokalemia
Hyperglycemia
Metabolic acidosis
Hyperthermia
Rhabdomyolysis
GI Toxic Effects

Nausea and vomiting are reported in >70% of acute overdoses. Theophylline can also induce esophageal reflux by decreasing lower esophageal sphincter pressure.
Neurologic Toxic Effects
Methylxanthine­induced seizures can be severe and refractory to treatment. First­time seizures in the setting of heavy caffeinated “energy drink”
,8 consumption have been reported. In theophylline toxicity, incidence of seizures is approximately 50% when serum levels are >40 micrograms/mL

(>200 micromole/L) during chronic therapy and >120 micrograms/mL (>600 micromole/L) after an acute ingestion. Seizures during chronic therapy are seen with lower serum concentrations due to relatively higher tissue levels. In chronic toxicity, seizures can occur without prior neurologic symptoms of tremor or agitation.
Cardiovascular Toxic Effects
Methylxanthines induce the release of endogenous catecholamines, stimulating β­adrenergic receptors and resulting in increased inotropy and chronotropy, vasodilation, hypotension, and reflex tachycardia. Sinus tachycardia is the most common cardiac manifestation of both caffeine and
,10 theophylline use and toxicity. Both atrial and ventricular tachydysrhythmias are described with excessive caffeine intake. Theophylline toxicity may result in atrial dysrhythmias such as multifocal tachycardia and fibrillation or flutter. Ventricular ectopy is more common with chronic toxicity and in
 patients with advanced age or underlying cardiac dysfunction. Ventricular fibrillation and tachycardia are rare.
Metabolic Toxic Effects
Methylxanthine toxicity is associated with hypokalemia, hyperglycemia, and metabolic acidosis. Hypokalemia is most common in acute overdose, due
 to increased catecholamines. Rhabdomyolysis has been reported in caffeine and theophylline overdoses, presumably due to the hypermetabolic
,14 state, agitation, and seizures.
Tolerance and Withdrawal
Chronic use of methylxanthines, particularly caffeine, can lead to tolerance, dependence, or withdrawal. Caffeine withdrawal syndrome has a varied course depending on use. Withdrawal symptoms typically start at  to  hours after the last dose, peak at about  hours, and can last for several days.
Headache and fatigue are the most common symptoms and are seen after either chronic use or short­term, high­dose exposures. Caffeine withdrawal headaches can be debilitating and should be included in the differential diagnosis of ED patients with headache.
DIAGNOSIS OF TOXICITY
Caffeine Toxicity
There is no clearly defined toxic dose or level of caffeine. Following a single ingestion of 120 milligrams of caffeine, an average peak serum concentration of  micrograms/mL (15 micromole/L) results at  hour. Caffeine doses around 120 milligrams enhance arousal and performance of
 both cognitive and psychomotor skills.
Ingestions of 100 to 150 milligrams/kg or serum levels >100 micrograms/mL (>500 micromole/L) are likely to cause life­threatening toxicity, and an
,16 acute ingestion of >200 milligrams/kg can be lethal. Serum caffeine concentrations are not readily available in most clinical settings and offer little in terms of clinical decision making, so management of caffeine toxicity is guided by clinical findings.
Theophylline Toxicity
Although there is an established therapeutic serum concentration for theophylline, clinical effects are determined by the amount of free drug in tissue, not the serum. The best predictor of major theophylline toxicity after an acute overdose—seizures, hypotension, or cardiac dysrhythmias—is the peak serum concentration. In chronic toxicity, although serum levels are elevated, the level itself does not necessarily predict major toxicity. In an acute ingestion, monitor serial theophylline levels to establish a trend in absorption and document a declining concentration to assist in the medical clearance of patients, because peak levels may be delayed many hours following a massive, acute overdose (Table 192­6). Management decisions should be based on symptoms and the patient’s clinical condition, not on drug levels alone.
TABLE 192­6
Methylxanthine Toxicity Classifications
Acute Toxicity Acute on Chronic Toxicity Chronic Toxicity
Clinical Acute exposure: one­ Acute exposure in a person chronically An ongoing exposure to a stable amount with bioaccumulation; scenario time ingestion of a using that methylxanthine: an acute typically, due to decreased clearance: a newly prescribed bottle of theophylline ingestion of a bottle of theophylline in a medication inhibits theophylline metabolism, leading to slowly or caffeine tablets patient taking theophylline increasing tissue concentrations
Risk of clinical Variable, depends on High, depends on amount ingested and High, depends on tissue level of drug, age, and comorbidities effects amount comorbidities
Timing of peak Often delayed for Usually delayed Often immediately available serum many hours concentration
Correlation of Moderate correlation Moderate correlation Weak correlation peak serum concentration with clinical effects
TREATMENT
The three main components to caring for a patient with methylxanthine toxicity are resuscitation (stabilizing cardiovascular and pulmonary function),
GI decontamination to interrupt continued absorption (when appropriate), and minimizing end­organ effects. Supportive care and an appropriate observation period are required to prevent secondary sequelae. Monitor patients in a high­acuity setting. Treatments specific to methylxanthines, particularly theophylline, include use of activated charcoal, treatment of dysrhythmias and seizures, and enhanced elimination.
Initial ancillary studies should include ECG, serum electrolytes, creatinine, urea, glucose, and total creatine kinase. Other laboratory tests may be required based on patient presentation, available medications, and comorbidities. After an intentional ingestion, consider comorbid poisonings, such as with acetaminophen (paracetamol) or salicylate. Consult with a medical toxicologist or a regional poison control center to discuss case­specific treatment.
GI Decontamination
Consider GI decontamination with a potentially life­threatening theophylline poisoning provided there are no contraindications, such as an
 unprotected airway, intractable nausea or vomiting, ileus, bowel obstruction, or need for emergent endoscopy (Table 192­7). In caffeine ingestion, there is little benefit to GI decontamination because of the rapid absorption and associated nausea.
TABLE 192­7
GI Decontamination for Methylxanthine Toxicity
GI Decontamination Technique Indication* Dosing
Activated charcoal (single dose) Acute ingestion <12 y old: .5–1.0 gram/kg PO
>12 y old: 25–100 grams PO
Multidose activated charcoal (requires close Acute ingestion Normal activated charcoal loading dose, followed by: .25–0.5 gram/kg PO observation) every 2–4 h for  h (frequency and duration may vary)
Whole­bowel irrigation using iso­osmolar Acute ingestion of  mo–6 y:  mL/kg per hour polyethylene glycol electrolyte solution sustained­release 6–12 y old: 1000 mL/h preparations >12 y old: 1500–2000 mL/h
Duration: 4–6 h or until clear rectal effluent
*Consider contraindications; for details see http://www.clintox.org/resources/position­statements.
Ondansetron is the preferred antiemetic to control associated nausea or vomiting. Do not use phenothiazines (i.e., promethazine) because these agents lower the seizure threshold. Ranitidine can be used to decrease gastric acid hypersecretion. Do not give cimetidine as it can prolong methylxanthine half­life.

Multidose activated charcoal can enhance theophylline elimination by interrupting enterohepatic recirculation. Consult with a toxicologist or
 poison center regarding the use of whole­bowel irrigation for the ingestion of sustained­release preparations. Endoscopic removal of a slow­release, theophylline­containing bezoar may be necessary. Ipecac syrup, cathartics, and gastric lavage after theophylline ingestion are without proven benefit,
20­22 have potential adverse effects, and are not recommended.
Seizures
Due to adenosine antagonism, seizures may be difficult to control, particularly with theophylline toxicity. Benzodiazepines, such as lorazepam  to  milligrams IV or diazepam  to  milligrams IV in adults, are first­line agents. Repeated, larger doses may be necessary. Barbiturates, such as phenobarbital  to  milligrams/kg IV in adults, should be used if escalating doses of benzodiazepines are ineffective. At high doses, benzodiazepines and barbiturates can compromise the airway or lead to respiratory depression, so maintain a low threshold for endotracheal
 intubation. Phenytoin is not useful or recommended.
Patients who fail to respond to anticonvulsant therapy should be sedated, intubated, and paralyzed with a neuromuscular blocking agent; general anesthesia may be required. Paralyzed patients should have an electroencephalogram to monitor for continued seizure activity. Due to the severity of theophylline­induced seizures, some toxicologists recommend prophylactic use of a γ­aminobutyric acid agonist (e.g., lorazepam) to raise seizure threshold in patients presenting with markedly elevated theophylline levels, although this approach has not been validated in human studies.
Cardiovascular Support
Manage hypotension initially with IV fluids. The most commonly reported methylxanthine­induced tachydysrhythmias are atrial fibrillation and
 supraventricular tachycardia, managed using cardioselective β­blockers (esmolol or metoprolol). Ventricular dysrhythmias are uncommon.
Enhanced Elimination
Enhanced elimination techniques can prevent or help treat significant toxicity following methylxanthine poisonings. Multidose activated charcoal is
 recommended for toxic or potentially toxic theophylline ingestions.

Hemodialysis is safe and is as efficacious as hemoperfusion for the treatment of theophylline toxicity. Hemodialysis is also effective for massive
,27 caffeine ingestions and pentoxifylline toxicity.
Hemodialysis enhances methylxanthine clearance and provides fluid and electrolyte correction. Most experts suggest that a methylxanthine­induced life­threatening event, such as seizures or intractable dysrhythmias, is an indication for hemodialysis. In addition, we suggest that dialysis should be considered if (1) after an acute ingestion, a symptomatic patient has a serum theophylline level >100 micrograms/mL
(>555 micromole/L) or (2) a chronic toxicity patient has a serum theophylline level >60 micrograms/mL (>333 micromole/L) with
 significant symptoms or comorbidities. Published experience suggests that most patients who receive hemodialysis after a methylxanthineinduced life­threatening event, such as a seizure or dysrhythmia, will continue to have them, whereas as few as 5% of patients who received
 hemodialysis before manifesting severe toxicity will go on to develop a life­threatening event.
Supportive Care
Treat vomiting with antiemetics, and correct volume depletion with isotonic fluids. Hypokalemia may not require treatment unless there are clinical findings such as ECG changes, cardiac ectopy, or muscle weakness because potassium is shifted intracellularly and total­body potassium is only mildly depleted. Provide continuous cardiac monitoring until toxicity has resolved. Assess for hyperthermia, rhabdomyolysis, and compartment syndrome, and provide specific treatment. Patients who are sedated and paralyzed should undergo continuous electroencephalographic monitoring to evaluate for occult sustained or recurrent seizures.
DISPOSITION AND FOLLOW­UP
Following an intentional or accidental methylxanthine ingestion, patients are judged nontoxic when they are asymptomatic, have a normal physical examination and vital signs, and, if available, have normal or decreasing serum concentrations. Patients who remain asymptomatic for at least  hours after an acute ingestion of immediate­release tablets can be considered nontoxic. Patients with an ingestion of sustained­release medication should be monitored for  hours or longer. Patients with intentional ingestions should receive a behavioral health or psychiatric evaluation to assist with appropriate disposition and follow­up.
NICOTINE
EPIDEMIOLOGY
Nicotine is the primary alkaloid in tobacco, a product produced from the dried leaves of plants in the genus Nicotiana. Tobacco is consumed as smoke

(i.e., cigarettes) or smokeless (i.e., chewing tobacco) products. A typical cigarette contains approximately  milligrams of nicotine, but only about  milligram is absorbed during smoking. Nicotine gums usually contain  or  milligrams per piece; formulation and mastication assist in higher absorption compared to smoking a cigarette.
Liquid nicotine used in electronic (E)­cigarettes contains up to  milligrams/mL of nicotine. Calls to poison centers for pediatric ingestion of
,32  liquid nicotine are increasing, with more serious toxicity seen with liquid nicotine exposure compared to cigarettes, and deaths have been
,34 reported.
Other nicotine sources include smoking cessation products (gums, patches, nasal inhalers), pesticides, traditional remedies, and plants, including
 dermal exposures during tobacco harvest causing “green­tobacco sickness.”
PHARMACOLOGY
Nicotine is rapidly absorbed in the lungs, as well as across mucous membranes, the intestinal tract, and intact skin. Smoking tobacco leads to a peak serum nicotine concentration of  nanograms/mL (250 micromole/L), depending on depth of inhalation. Nicotine crosses the blood–brain barrier and affects the CNS within seconds of smoking. Absorption across mucous (oral) membranes is slower than absorption from smoking and is further delayed by gastric acids. Therapeutic use of a 4­milligram piece of nicotine gum leads to a peak nicotine concentration of about  nanograms/mL (60
 micromole/L) at  minutes. The half­life of nicotine is variable, averaging about  hours in adults. Metabolism is by the liver, mainly by cytochrome
P450 2A6, with 85% being converted to cotinine.
Once absorbed, nicotine binds to nicotinic acetylcholine receptors throughout the body, including the central nervous, autonomic, and neuromuscular systems. Early in toxicity, nicotine acts as an agonist, activating these ion channels and leading to increased neuronal firing with release of neurotransmitters, including acetylcholine, dopamine, glutamate, norepinephrine, and serotonin. At higher concentrations and/or as toxicity persists, the acetylcholine receptors are inhibited by persistent membrane depolarization, ultimately leading to receptor inactivation.
CLINICAL FEATURES
In overdose, nicotine mainly affects the GI, cardiovascular, neurologic, and respiratory systems (Table 192­8). Nausea and vomiting are the most common effects and can limit absorbed amounts following ingestion. Early effects are due to acetylcholine receptor activation and include tremor, dizziness, tachycardia, and bronchorrhea. Delayed effects, manifesting after larger exposures, occur due to receptor inactivation and include bradycardia, dysrhythmias, hypoventilation, and coma. Seizures are possible and are due to centrally mediated actions.
TABLE 192­8
Clinical Effects of Nicotine Toxicity
Signs and Symptoms of Nicotine Toxicity* Organ System Immediate (<1 h) Delayed (>1 h)
GI Hypersalivation Diarrhea
Nausea
Vomiting
Cardiovascular Tachycardia Dysrhythmias
Hypertension Bradycardia
Hypotension
Neurologic Tremor Hypotonia
Headache Seizure
Ataxia Coma
Respiratory Bronchorrhea Hypoventilation
Apnea
*Onset of toxicity is varied and can be delayed for hours following dermal exposure.
Nicotine poisoning in children usually results from the ingestion of tobacco or nicotine­containing products, such as E­cigarette liquid. There is no consensus on the estimated lethal dose of nicotine, and accidental ingestion of cigarettes or chewing tobacco in children rarely results in serious
 outcomes.
A child who ingests one or more intact cigarettes, or three or more cigarette butts, has a 90% chance of becoming symptomatic,
 usually within  minutes. More severe poisonings, such as ingestion of nicotine­containing pesticides, self­harm attempts with nicotine­
 containing E­cigarette liquid, or abuse of dermal patches, can result in seizures, respiratory failure, hypotension, dysrhythmias, and death. Because
 nicotine freely crosses the placenta and is found in small concentrations in breast milk, neonatal withdrawal is possible.
Green­tobacco sickness is characterized by nausea, vomiting, weakness, dizziness, and headaches, due to the dermal absorption of nicotine during
 tobacco harvesting. Onset of symptoms may be delayed for several hours. Patients with significant comorbidities, particularly underlying cardiovascular or seizure disorders, are theoretically at higher risk for morbidity.
Chronic nicotine use has been associated with insulin resistance in diabetics, increased cardiovascular risks, dysrhythmias, and the potential for
 withdrawal. Nicotine withdrawal manifests with irritability, depression, drowsiness, trouble sleeping, increased appetite, and headaches, with symptoms peaking at  to  days after last use. Withdrawal can occur in smokers as well as smokeless tobacco and nicotine gum users.
DIAGNOSIS
The diagnosis of acute nicotine toxicity is based on reliable history and physical examination, with laboratory analysis being of little value. Qualitative toxicologic screening assays can detect nicotine and cotinine in the urine but may only reflect exposure.
TREATMENT
The treatment of nicotine toxicity is symptomatic. Fortunately, because nicotine has a short half­life, symptoms typically resolve rapidly.
Cardiovascular and ventilatory support may be required in severe toxicity (Table 192­9). Benzodiazepines may be used for seizures, and endotracheal intubation and mechanical ventilation may be required if significant neuromuscular weakness or respiratory depression develops. Ipecac syrup or activated charcoal is not recommended. Decontamination with soap and water should be done following dermal exposures. There is no role for enhanced elimination or urine acidification.
TABLE 192­9
Treatment of Nicotine Toxicity
Clinical Condition Intervention Considerations
Nausea, vomiting, gastritis Antiemetics Ondansetron,  milligrams IV
Proton pump inhibitors Pantoprazole,  milligrams IV
Tremor, seizures Benzodiazepines Lorazepam, 1–2 milligrams IV
Diazepam, 5–10 milligrams IV
Hypotension Fluid resuscitation Monitor and replace serum electrolytes
Hypoventilation Intubation and mechanical ventilation —
Withdrawal Nicotine replacement therapy Requires outpatient follow­up
Nicotine withdrawal can be distressing but is not life threatening. Treatment options include the use of nicotine replacement therapy and antidepressants.
DISPOSITION AND FOLLOW­UP
Monitor patients with known or suspected nicotine toxicity; the length of observation depends on the type of product ingested. Patients who remain asymptomatic with normal vital signs after  hours from an acute ingestion of nicotine­containing product (except intact transdermal patches) can be discharged from medical care. Those who ingest intact transdermal patches should be observed longer, at least  hours. Patients with intentional ingestions should receive a behavioral health or psychiatric evaluation to assist with appropriate disposition and follow­up.


