## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 217: Thermal Burns
E. Paul DeKoning
EPIDEMIOLOGY
More than 450,000 individuals in the United States receive medical treatment each year for burn injuries, with 486,000 receiving treatment in 2016
  alone. Although ,000 patients require hospitalization and >60% of those are treated at one of 128 specialized burn centers, the vast majority of
,3 burn patients are treated in the acute setting by emergency physicians and discharged with outpatient follow­up.

Nearly 70% of burn victims are male, and risk is highest between the ages of  and  years. Seventy­seven percent of all injuries are accounted for by
 fire or scalding; 43% of scald injuries occur in children <5 years of age. Although overall survival exceeds 96%, fire, burn, and smoke inhalation still
 4­6 account for approximately 3400 deaths each year in the United States. Elderly patients understandably have a disproportionately higher death rate.

The risk of death from a major burn increases with larger burn size, older age, the presence of inhalation injury, and female sex.
The Centers for Disease Control and Prevention lists the following groups as being at increased risk of fire­related injuries and death: children ≤4 years of age, adults ≥65 years of age, African Americans and Native Americans, persons living in rural areas, persons living in manufactured homes or
 substandard housing, and persons living in poverty.
,9
Care of the acute burn–injured patient has improved significantly over the past several decades. The rate of hospital admissions has decreased owing to improvements in both the acute care provided in the ED and outpatient care at specialized burn centers. Indeed, over the past  years,
 dramatic improvements in survival after burn injury have been seen, in large part due to specialized burn care. Only approximately 4% of those
,11 treated in specialized burn treatment centers die from their injuries or associated complications. Additionally, survivors of high total body surface area (>20%) burns tend to have better 5­year survival than those with <20% total body surface area burns, because burn center survivors tend to be
 younger with fewer comorbidities.
PATHOPHYSIOLOGY
Skin consists of two layers: the epidermis and the dermis (Figure 217­1). Skin thickness varies both by age and anatomic location: It is relatively thinner at extremes of age, whereas it is thicker on the palms, soles, and upper back. Thus, the depth and severity of thermal injury vary by both the age of the victim and the anatomic location exposed.
FIGURE 217­1. Layers of the skin.

Chapter 217: Thermal Burns, E. Paul DeKoning 
. Terms of Use * Privacy Policy * Notice * Accessibility
Skin functions as a semipermeable barrier to evaporative water loss, protects against environmental assault, and aids in the control of body temperature, sensation, and excretion. Partial­thickness thermal injury disrupts these barrier functions and contributes to free water deficits. This effect may be significant with moderate to large burns.
Thermal injury results in a spectrum of local and systemic homeostatic disorders that contribute to burn shock (Table 217­1). These include disruption of normal cell membrane function, hormonal alterations, acid­base disturbance, hemodynamic changes, and hematologic derangement.
TABLE 217­1
Physiologic Effects of Thermal Injury
Disruption of sodium pump
Intracellular influx of sodium and water
Extracellular efflux of potassium
Depression of myocardial contractility (>60% of body surface area burned)
Increased systemic vascular resistance
Metabolic acidosis
Increase in hematocrit and increased blood viscosity
Secondary anemia from erythrocyte extravasation and destruction
Local tissue injury
Release of histamines, kinins, serotonins, arachidonic acids, and free oxygen radicals
The fluid and electrolyte abnormalities seen in burn shock are largely the result of alterations of cell membrane potential causing intracellular influx of water and sodium and extracellular migration of potassium, secondary to dysfunction of the sodium pump. In patients with burns >60% of total body surface area, depression of cardiac output results in a lack of response to aggressive volume resuscitation. Although disputed by others, Baxter and

Shires have explained this phenomenon to be due to circulating myocardial depressants. Systemic vascular resistance is increased. A significant metabolic acidosis may be present even in the early stages of a large burn injury. Massive thermal injury results in an increase in hematocrit with increased blood viscosity during the early phase, followed by anemia from erythrocyte extravasation and destruction. Surprisingly, however, transfusion is seldom required for patients with isolated burn injury, and aggressive transfusion has been associated with increased morbidity and
14­16 mortality.
Thermal injury is progressive. Local effects of thermal injury include the liberation of vasoactive substances, disruption of cellular function, and formation of edema. The subsequent systemic response alters the neurohormonal axis and further extends the injury. Implicated in these events are histamine, kinin, serotonin, arachidonic acid metabolites, and free oxygen radicals. These substances exert their primary effects at the local level and cause progression of the burn wound. Although many factors may influence prognosis, the severity of the burn, the presence of
,6 inhalation injury, associated injuries, the patient’s age, comorbid conditions, and acute organ system failure are most important.
Cell damage occurs at temperatures of >45°C (113°F) owing to denaturation of cellular protein. The size and depth of the resulting burn are functions of the burning agent, its temperature, and the duration of exposure. Burn wounds are described as having three zones: the zone of coagulation, in which tissue is irreversibly destroyed with thrombosis of blood vessels; the zone of stasis, in which there is stagnation of the microcirculation; and the zone of hyperemia, in which there is increased blood flow. The zone of stasis can become progressively more hypoxemic and ischemic if resuscitation is not adequate. In the zone of hyperemia, there is minimal damage to the cells and spontaneous recovery is likely.
CLINICAL FEATURES
BURN SIZE
Burn size determines fluid resuscitation needs and the majority of decisions for hospital transfer. Burn injury size is quantified as the percentage of
 body surface area involved. The Rule of Nines is a simple and commonly used method to calculate burn size (Figure 217­2), It divides the body into segments that are approximately 9% or multiples of 9%, with the perineum forming the remaining 1%. Because of the proportionately larger heads and smaller legs of infants and children, this method must be modified in pediatric burn injury.
FIGURE 217­2. Rule of Nines diagram for estimation of adult burn size.
A second method assumes that the area of the back of the patient’s hand is approximately 1% of their total body surface area. The number of “hands” that equal the area of the burn can approximate the percentage of body surface area burned. A third and more precise method uses the Lund­Browder burn diagram (Figure 217­3). This allows an accurate age­adjusted determination of burn size for a given
 depth, allowing for the anatomical differences of children.
FIGURE 217­3. Lund­Browder diagram for estimation of burn size.
BURN DEPTH
The depth of a burn has historically been described in degrees: first, second, third, and fourth (Table 217­2). However, a classification of burn depth according to the need for surgical intervention has become the accepted approach in burn treatment centers: superficial partial­thickness, deep
 partial­thickness, and full­thickness burns (Table 217­3). Determination of burn depth requires clinician judgment using commonly observed wound features. There is no objective method of measuring burn depth, and burn wound biopsy is not routine practice.
TABLE 217­2
Burn Depth Features Classified by Degree of Burn
Burn Depth Histology/Anatomy Example Healing
Superficial (first degree) Epidermis Sunburn  d
No blisters, painful
Superficial partial­thickness (superficial Epidermis and superficial dermis Hot water scald 14–21 d, no scar second degree)
Blisters, very painful
Deep partial­thickness (deep second Epidermis and deep dermis, sweat glands, and Hot liquid, steam, 3–8 wk, permanent scar degree) hair follicles grease, flame
Blisters, very painful
Full­thickness (third degree) Entire epidermis and dermis charred, pale, Flame Months, severe scarring, skin leathery; no pain grafts necessary
Fourth degree Entire epidermis and dermis, as well as bone, Flame Months, multiple surgeries fat, and/or muscle usually required
TABLE 217­3
Burn Depth Features: American Burn Association Burn Classification
Burn Classification Burn Characteristics Disposition
Major burn Partial­thickness >25% BSA, age 10–50 y Burn center treatment
Partial­thickness >20% BSA, age <10 y or >50 y
Full­thickness >10% BSA in anyone
Burns involving hands, face, feet, or perineum
Burns crossing major joints
Circumferential burns of an extremity
Burns complicated by inhalation injury
Electrical burns
Burns complicated by fracture or other trauma
Burns in high­risk patients
Moderate burn Partial­thickness 15%–25% BSA, age 10–50 y Hospitalization
Partial­thickness 10%–20% BSA, age <10 y or >50 y
Full­thickness burns ≤10% BSA in anyone
No major burn characteristics present
Minor burn Partial­thickness <15% BSA, age 10–50 y Outpatient treatment
Partial­thickness <10% BSA, age <10 y or >50 y
Full­thickness <2% in anyone
No major burn characteristics present
Abbreviation: BSA = body surface area.
A superficial burn involves only the epidermal layer of skin. Sunburn is frequently given as an example, even though it is caused by ultraviolet light
 instead of thermal injury. The burned skin is red, painful, and tender without blister formation. Superficial burns usually heal in about  days without scarring and require only symptomatic treatment (Figure 217­4).
FIGURE 217­4. Superficial burn.
Partial­thickness burns extend into the dermis and are subdivided into superficial partial­thickness (Figure 217­5) and deep partial­thickness burns
(Figure 217­6).
FIGURE 217­5. Superficial partial­thickness burn.
FIGURE 217­6. Deep partial­thickness burn.
In superficial partial­thickness burns, the epidermis and the superficial dermis (papillary layer) are injured, while the deeper layers of the dermis, hair follicles, and sweat and sebaceous glands are spared. Superficial partial­thickness burns are often caused by hot water scalding. The skin is blistered, and the exposed dermis is red and moist. These wounds are exceedingly painful to touch. The dermis is well­perfused with intact capillary refill. Healing typically occurs in  to  days, scarring is usually minimal, and there is full return of function.
Deep partial­thickness burns extend into the deep dermis (reticular layer) (Figure 217­6). Hair follicles and sweat and sebaceous glands are damaged, but their deeper portions usually survive. Hot liquids (e.g., oil or grease), steam, or flame usually cause this type of injury. The skin may be blistered, and the exposed dermis is pale white to yellow in color. The burned area does not blanch; it has absent capillary refill and absent pain sensation. Deep partial­thickness burns may be difficult to distinguish from full­thickness burns. Healing takes  weeks to  months; scarring is common and related to the depth of the dermal injury. Surgical debridement and skin grafting may be necessary to obtain maximum function.
Full­thickness burns involve the entire thickness of the skin (Figure 217­7). All epidermal and dermal structures are destroyed. These injuries are typically caused by flame, hot oil, steam, or contact with hot objects. The skin is charred, pale, painless, and leathery. Because all dermal elements are destroyed, these injuries do not heal spontaneously. Surgical repair and skin grafting are necessary; significant scarring is the norm.
FIGURE 217­7. Full­thickness burn.
Fourth­degree burns are those that extend through the skin to the subcutaneous fat, muscle, and even bone. These are devastating, life­threatening injuries. Amputation or extensive reconstruction is sometimes required.
BURN CENTER TRANSFER
,19
The American Burn Association provides guidelines for referral to a burn center, in addition to indications based on burn depth (Table 217­4).
Children <10 years of age and adults >50 years are considered high­risk patients. Patients with significant comorbidities, such as heart disease, diabetes, or chronic pulmonary disease, are also likely to require prolonged care and should be considered for transfer to a burn unit. Burn severity, underlying medical and social conditions, and the capabilities of the institution initially receiving the patient must all be considered in the decision to transfer the patient to a burn unit.
TABLE 217­4
American Burn Association Burn Unit Referral Criteria
Full­thickness/third­degree burns in any age group
Partial thickness burns >10% total body surface area
Burns involving the face, hands, feet, genitalia, perineum, or major joints
Electrical burns, including lightning injury
Chemical burns
Inhalation injury
Burn injury in patients with preexisting medical disorders that could complicate management, prolong recovery, or affect mortality
Burn injury in any patients with concomitant trauma (e.g., fractures) in whom the burn injury poses the greatest risk of morbidity or mortality
Burn injury in children in hospitals without qualified personnel or equipment to care for children
Burn injury in patients who will require special social, emotional, or long­term rehabilitative intervention
Burn injury in children <10 y and adults >50 y of age
INHALATION INJURY
As treatment of burn shock and sepsis has improved, inhalation injury has become the main cause of mortality in burn patients. Most fire­related
,6,11 deaths are due to smoke inhalation. Inhalation injury is associated with closed­space fires and conditions that decrease mentation, such as
 overdose, alcohol intoxication, drug abuse, and head injury. Exposure to smoke includes exposure to heat, particulate matter, and toxic gases. Direct thermal injury is usually limited to the upper airway; thermal injuries below the level of the vocal cords can occur in cases of steam inhalation.
Smoke contains particulate matter, usually <0.5 µm in size, which is formed from incomplete combustion of organic material. Small particles may reach the terminal bronchioles, where they can initiate an inflammatory reaction that leads to bronchospasm and edema. Toxic inhalants are divided
 into three large groups: tissue asphyxiants, pulmonary irritants, and systemic toxins. The two major tissue asphyxiants are carbon monoxide and hydrogen cyanide.
Carbon monoxide poisoning is a well­known consequence of smoke inhalation injury. Severe carbon monoxide poisoning produces brain hypoxia and coma. Comatose patients lose airway protective mechanisms, which may result in aspiration and further pulmonary injury. All patients with suspected carbon monoxide exposure should receive 100% oxygen by non­rebreather mask and should be evaluated for hyperbaric oxygen therapy
(see Chapter 222, “Carbon Monoxide”). Hydrogen cyanide is formed by the combustion of nitrogen­containing polymers such as wool, silk, polyurethane, and vinyl. Cyanide binds to and uncouples mitochondrial oxidative phosphorylation, which leads to profound tissue hypoxia. Specific treatment for cyanide toxicity may be required (see Chapter 204, “Industrial Toxins”).
Inhalation injury damages endothelial cells, produces mucosal edema of the small airways, and decreases alveolar surfactant activity, resulting in bronchospasm, airflow obstruction, and atelectasis. Although lower airway edema may not be clinically evident for up to  hours, upper airway edema can occur rapidly. Over time, tracheal and bronchial epithelial sloughing occurs. Approximately half of intubated burn patients admitted to
 burn centers develop acute respiratory distress syndrome. The most recent international guidelines for the management of burn injuries suggest lung­protective strategies including using low tidal volumes in patients with acute respiratory distress syndrome. Specifically, maintaining plateau pressures below  cm H O and tidal volumes below  mL/kg is indicated. Prophylactic antibiotics and corticosteroids are not recommended in

 inhalation injury. Therefore, when inhalation injury is present, careful fluid resuscitation guided by hemodynamic monitoring can help avoid pulmonary edema and acute respiratory distress syndrome.
The initial diagnosis of smoke inhalation is made from a history of exposure to fire in an enclosed space and physical signs that include facial burns, singed nasal hair, soot in the mouth or nose, hoarseness, carbonaceous sputum, and expiratory wheezing. No single method for diagnosing the extent of inhalation injury exists. Measurement of arterial carboxyhemoglobin is used to document prolonged exposure to products of incomplete combustion. The chest radiograph may be normal initially. Bronchoscopy and radionuclide scanning may also be helpful in evaluating the full extent of injury.
Treat suspected inhalation injury prior to definitive diagnosis. Provide humidified oxygen (100%) by facemask. Obtain arterial blood gas concentrations, including carboxyhemoglobin levels. Control of the upper airway is achieved by prompt endotracheal intubation. Indications for intubation include (1) full­thickness burns of the face or perioral region, (2) circumferential neck burns, (3) acute respiratory distress, (4) progressive hoarseness or air hunger, (5) respiratory depression or altered mental status, and (6) supraglottic edema and inflammation on bronchoscopy.
Additionally, consider the patient’s anticipated clinical course.
BURN TREATMENT
The management of patients with moderate to major burns can be divided into three phases: (1) prehospital care, (2) ED resuscitation and stabilization, and (3) admission or transfer to a specialized burn center.
PREHOSPITAL CARE
The basis of prehospital care of the burn­injured patient consists of the following: (1) stop the burning process; (2) assess and, if necessary, secure the airway; (3) initiate fluid resuscitation; (4) relieve pain; (5) protect the burn wound; and (6) transport the patient to an appropriate facility.
On­site assessment of a burned patient is divided into primary and secondary surveys. In the primary survey, identify and treat immediately lifethreatening conditions. Initial management of the burn­injured patient is similar to that of any other trauma patient: airway, breathing, circulation, and cervical spine immobilization where appropriate. During the secondary survey, perform a thorough head­to­toe evaluation.
The patient must be extricated from the burning environment, and burning clothing must be immediately removed. The remainder of the clothing should be removed after the airway, breathing, and circulation are secured. Remove rings, watches, jewelry, and belts because they retain heat and produce a tourniquet­like effect on the extremity, causing ischemia. Give oxygen by facemask. Pay close attention to the airway: rapid deterioration may occur even when the initial assessment judges the airway to be acceptable. Consider prophylactic intubation in patients with perioral burns sustained in a closed­space fire. Give IV isotonic crystalloid. Cover the patient with clean sheets to protect the wound.
While early cooling can reduce the depth of burn and reduce pain, uncontrolled cooling may result in hypothermia. Provide analgesia according to protocol or with direction of the online medical control physician. Transport the patient to the nearest ED capable of caring for a burn­injured patient or, if none is available, to the nearest ED for stabilization and subsequent transfer.
ED MANAGEMENT
INITIAL ASSESSMENT
Obtain a directed history from the patient and EMS personnel to determine the burning agent(s), involvement of chemicals, the duration of exposure, and if the injury was sustained in an open or enclosed space. Assess for loss of consciousness, risk of blast injury from explosion, contact with electricity, or other trauma. Assess the adequacy of, or need for, cervical immobilization. Obtain the general history, including past medical and surgical illnesses, chronic disease, allergies, medications, and tetanus immunization status.
Quickly assess the patient’s respiration and circulation and initiate stabilization (Table 217­5). Examine the patient for signs of inhalation injury, as evidenced by respiratory distress, facial burns, carbonaceous sputum, singed nasal hair, and soot in the mouth. If there is any evidence of airway compromise with swelling of the neck, burns inside the mouth, or wheezing, perform early endotracheal intubation.
TABLE 217­5
ED Care of Patients With Major Burns
Airway Breathing Circulation Adjuncts
Reevaluation of airway Continuous pulse Establishment of two large­bore Placement of Foley catheter oximetry with peripheral IV lines in unburned skin
Early intubation for any sign of breathing supplemental oxygen Insertion of nasogastric tube difficulty, airway burn, swelling, or suspected inhalation injury Determination of IV administration of lactated Ringer’s Administration of tetanus carboxyhemoglobin solution using Parkland or other burn booster level resuscitation formula
Bronchoscopy if Cardiac monitoring Assessment for other trauma inhalation injury is a using Advanced Trauma Life concern Support guidelines
Mechanical ventilation Pain control as needed
Assess the adequacy of circulation by noting the blood pressure, pulse rate, capillary refill time, mental status, and urinary output, keeping in mind that due to the catecholamine response associated with burn injury, a heart rate of 100 to 120 beats/min is considered within normal limits for
 adults. Insert IV lines in unburned areas, but when this is not possible, a burned area can be used and resuscitation started according to a burn fluid resuscitation formula.
During the secondary examination, perform a head­to­toe assessment, including examination of the eye for corneal burns. Estimate and record the size and depth of the burn injury. In patients with partial­thickness burns of >20% of body surface area, nasogastric tube insertion is routinely required due to frequent development of ileus. Insert a urinary catheter to measure urinary output and to prevent urinary retention in patients with perineal burns.
Routine laboratory tests, including a CBC and measurement of electrolyte, BUN, creatinine, and glucose levels, should be performed. In patients with moderate or severe burns or suspected inhalation injury, obtain an arterial blood gas analysis, carboxyhemoglobin level, serum creatine kinase, urinalysis for myoglobin, chest radiograph, and ECG. Fiberoptic bronchoscopy is indicated in suspected inhalation injury and in intubated patients for both diagnostic and therapeutic purposes. Additional radiographs should be taken as indicated for other suspected trauma.

Treat suspected inhalation injury with humidified 100% oxygen, intubation and ventilation, bronchodilators, lung­protective vent settings, and aggressive pulmonary toilet; hyperbaric oxygen may be necessary for severe carbon monoxide poisoning.
Burn injury in the pregnant woman is associated with significant morbidity to mother and child. The outcome of the pregnancy is determined by the extent of injury to the mother. Spontaneous termination of pregnancy is common in large–body surface area burns. Resuscitation requirements may exceed those estimated using common guidelines. Fetal monitoring and early consultation with the obstetrician and burn specialist are recommended.
FLUID RESUSCITATION
,23
Although the importance of early fluid resuscitation is supported by clinical experience, no consensus exists on the appropriate assessment of
 resuscitation and its effect on outcome. Additionally, overresuscitation is not without consequence. In general, resuscitation should be guided by monitoring cardiorespiratory status and urine output rather than strict adherence to a formula. The following formulas are a guide for fluid resuscitation of the burn­injured patient. Monitor and adjust according to individual patient response.
,9
The Baxter or Parkland formula is likely the most widely used thermal injury resuscitation regimen in North America. This formula calls for  mL of lactated Ringer’s solution multiplied by the percentage of body surface area burned (partial­ and full­thickness burns only) multiplied by patient body weight in kilograms. Half of the total is administered in the first  hours after injury and the remainder during the following  hours (Table 217­6).
Volumes may be large, and hemodynamic monitoring techniques should be used to protect against inadvertent volume overload.
TABLE 217­6
Parkland Formula for Fluid Resuscitation
Adults
LR  mL × weight (kg) × % BSA burned* over initial  h
Half over the first  h from the time of burn
Other half over the subsequent  h
Example: 70­kg adult with 40% second­ and third­degree burns:  mL ×  kg ×  = ,200 mL over  h
Children
LR  mL × weight (kg) × % BSA burned* over initial  h plus maintenance
Half over the first  h from the time of burn
Other half over the subsequent  h
Abbreviations: BSA = body surface area; LR = lactated Ringer’s solution.
*Partial­ and full­thickness burns only.
Patients with thermal injury and concomitant multisystem trauma and those with inhalation injuries generally require fluid resuscitation in excess of calculated needs. Burn patients with preexisting cardiac or pulmonary disease require much greater attention to fluid management. Monitor fluid resuscitation closely by frequent assessment of vital signs, cerebral and skin perfusion, pulmonary status, and urinary output, as well as hemodynamic monitoring. Urine output should be .5 to .0 mL/kg/h.
Because the ED is primarily responsible for initial fluid resuscitation, early discussion with burn specialists may be helpful in avoiding under­ or overresuscitation. Patients with major burns can quickly receive excessive IV fluid during the prehospital and ED phases, particularly if two large­bore peripheral catheters are in place with fluid infusing at a wide­open rate. Document total fluid infused and titrate infusion to the patient’s response.
Clear documentation of fluid resuscitation should accompany all patients transferred to burn centers.
There are several methods of calculating fluid resuscitation for infants and children. The Parkland formula can be modified to maintain a urinary output of  mL/kg/h. Alternatively, a pediatric maintenance rate for  hours can be calculated, and an additional  to  mL/kg multiplied by percentage of body surface area burned is then added to the total. The entire amount is infused over the first  hours. In children weighing <25 kg, a
 goal urine output of .0 mL/kg/h is necessary. Add 5% dextrose to maintenance fluids for children weighing <20 kg due to smaller glycogen stores.
Two additions or modifications to isotonic crystalloid resuscitation have been studied: adjuvant colloid and hypertonic saline. However, neither improves patient outcome. Adjuvant colloid given along with isotonic crystalloid resuscitation is not beneficial and is associated with decreased
  glomerular filtration rate. Discussion of the use of adjuvant colloid continues, but it is used very little in North America and the United Kingdom,
 although Israeli investigators have reported favorable results with the addition of colloid to their burn formulas. Use of hypertonic saline has been
 associated with an increased rate of renal failure and death. In an effort to decrease burn edema, protein loss, and abdominal compartment syndrome, investigators have also studied the efficacy of permissive hypovolemia in reducing burn edema and the multiple organ dysfunction that
 follows. This practice necessitates invasive monitoring and is of interest, but it is not standard of care and should not be used in ED resuscitation at this time.
Electrical injuries, incineration burns, and associated crush injuries may produce rhabdomyolysis and myoglobinuria, leading to renal failure. Acute renal failure occurs in approximately 15% of patients admitted to burn centers and is associated with severe burns (mean body surface area
 involvement of 48%). Therapy to limit renal damage from myoglobinuria should be initiated as outlined in Chapter , “Rhabdomyolysis.”
WOUND CARE

After evaluation and resuscitation of the patient, attend to burn wounds. Initially, wounds are best covered with a clean, dry sheet. Later, small burns can be covered with a moist saline­soaked dressing while the patient is awaiting admission or transfer. The soothing effect of cooling on burns is most likely due to local vasoconstriction. Cooling stabilizes mast cells and reduces histamine release, kinin formation, and thromboxane B production. For
 large burns, sterile drapes are preferred, because application of saline­soaked dressings to a large area can cause hypothermia.
Consult the admitting service or burn center early. Avoid the use of antiseptic dressings in the ED, because the admitting service will need to assess the wound. Wound care for transferred patients should be discussed with the accepting burn center. Do not delay transfer for wound debridement. For transferred patients, the referring facility should follow the accepting regional burn center’s treatment protocol if available.
Escharotomy
Patients with circumferential deep burns of the limbs may develop compromise of the distal circulation, particularly after initiation of resuscitation.
The distal vascular status of such patients must be monitored closely, including pulses, capillary refill, pulse oximetry, and skin temperature. Doppler flow testing may likewise be useful. If vascular compromise is evident, escharotomy is indicated. The eschar is incised with a scalpel to the level of the fat on the mid­lateral portion of the limb, using care to avoid incising the fascia (i.e., fasciotomy). Elevated compartment pressures can be clinically evident. The incision may be extended to the hand and fingers (Figure 217­8). Escharotomy may provoke substantial soft tissue bleeding. Consider consultation by phone with a burn surgeon.
FIGURE 217­8. Escharotomy of the hand.
If there are circumferential burns of the chest and neck, eschar may restrict ventilation. An escharotomy of the chest wall should be performed to allow adequate ventilation. Incisions are made at the anterior axillary line from the level of the second rib to the level of the twelfth rib. These two incisions should be joined transversely so the chest wall can expand (Figure 217­9).
FIGURE 217­9. Escharotomy of the chest wall.
PAIN CONTROL
Burn injuries are exceedingly painful, and superficial partial­thickness burns are the most painful. Burn injury not only makes an otherwise already injured area and surrounding tissue more painful, but also causes hyperalgesia, chiefly mediated by A fibers. Local cooling may be soothing but does
 not provide pain control and can cause hypothermia; additional pain management should be provided.
During the acute phase, the preferred route for most medication is IV. Opioids (e.g., morphine, fentanyl, hydromorphone) are the mainstay of treatment, and relatively large dosages may be required. Anxiolytic agents may also be given. Ensure adequate analgesia for patients being discharged.
Achieving adequate pain control is required for patients being considered for discharge.
CARE OF MINOR BURNS
Minor burns typically qualify for ambulatory care. Minor burns should be isolated, should not cross joints or be circumferential, and should not meet criteria for burn center care. Treatment of minor burns is provided in Table 217­7. Even in patients with burn injury <10% of body surface area, patients at the extremes of age and/or patients with significant comorbidities, challenging social situations, or inadequate pain control may require inpatient care and possibly transfer to a burn center. Care of minor burns in discharged patients requires appropriate wound care instructions,
 adequate pain control, and coordination between the ED and the physician who will see the patient in follow­up.
TABLE 217­7
ED Care of Minor Burns
Provide appropriate analgesics before burn care and for outpatient use
Cleanse burn with mild soap and water or dilute antiseptic solution
Debride wound as needed
*Apply topical antimicrobial agent or dressing:
Bacitracin ointment
Triple­antibiotic ointment (neomycin, polymyxin B, bacitracin zinc)
Consider use of synthetic, solid, or biological dressings
Provide detailed burn care instructions with follow­up in 24–48 h
*Consider contacting the director of the local or regional burn center to identify the center's preferred topical antimicrobial agent and/or synthetic occlusive dressing to integrate local and tertiary burn care.
Because burns are painful, appropriate analgesia is required. After appropriate analgesia, clean the burn wound with mild soap and water or dilute antiseptic solution. Debride ruptured blisters. Also debride large intact blisters or those over very mobile joints. Small blisters on nonmobile areas should be left intact. Tetanus immunization status should be assessed, and tetanus toxoid and/or immunoglobulin should be administered as needed.
Topical antimicrobials (antiseptics or antibiotics) play an important role in reducing bacterial colonization and enhancing the rate of healing in
,9 burns. A wide variety of topical agents and specialized dressings are commonly used for minor burns. A mainstay of treatment has traditionally been
1% silversulfadiazine due to its easy application and minimal toxicity. However, three meta­analyses found delayed healing in burns treated with silver
32­34  sulfadiazine compared to newer dressings. Newer dressings require less frequent dressing changes and are associated with reduced pain. Do not use silversulfadiazine on the face because it can stain the skin gray. Silversulfadiazine should not be used in infants less than  months of age.
For the face or other small minor burns, recommended topical agents include bacitracin and triple­antibiotic (neomycin, polymyxin B, and bacitracin
 zinc) ointments. Although .5% mafenide acetate cream and .2% nitrofurazone ointment are available for topical application, these are not good choices for treatment of large burns in an outpatient setting. Mafenide penetrates the eschar well and is useful in treating patients with invasive infections, but it is a carbonic anhydrase inhibitor and can cause metabolic acidosis. Nitrofurazone is supplied in a polyethylene glycol vehicle that can be toxic if absorbed in patients with compromised renal function. Mafenide and nitrofurazone have little utility in the ED management of the acutely burn­injured patient. Dressings should ideally be changed twice daily, gently removing residual ointment, for as long as the wounds
 continue to weep, then daily until healing is complete.
Synthetic occlusive, solid, or biological dressings are alternative methods of managing partial­thickness burns in outpatients. Wounds are cleansed and debrided prior to application of these dressings. Examples include clear occlusive synthetics, foam or hydro­fiber dressings impregnated with antiseptics, or treated biologic membranes. Consider contacting the director of the local or regional burn center to identify the center's preferred topical antimicrobial agent and/or specific burn dressing to integrate local and tertiary burn care. The goal is for the dressing to act as artificial skin.
Wounds should be reevaluated at  to  hours. Wounds treated with synthetic solid, or biological dressings are well tolerated by patients, require
 few dressing changes, and heal with good appearance.
Reassess burn wounds at  to  hours for depth and extent of burn. Explain the follow­up visit schedule and prescribe analgesics. Discharge instructions should include home burn care, pain control, and the symptoms and signs of infection. Burned extremities should be elevated for  to  hours to prevent edema. Advise patients to return to the ED with signs or symptoms of infection or if pain is inadequately controlled. Patients with deep partial­thickness, full­thickness, and mixed­thickness burns not requiring admission should be referred to a plastic surgeon or burn care specialist in  to  days for reevaluation and consideration for skin grafting. Patients with self­inflicted burns have additional social and psychological needs that must be addressed either during inpatient admission or prior to discharge from the ED. They have been associated with substance abuse
 and decreased likelihood of follow­up. Consider psychiatric evaluation early if self­harm is suspected.


