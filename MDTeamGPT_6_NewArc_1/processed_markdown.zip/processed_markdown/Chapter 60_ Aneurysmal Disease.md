## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 60: Aneurysmal Disease
Louise A. Prince; Gary A. Johnson
Content Update: TVAR and EVAR February 2022
See expanded discussion of TVAR and EVAR technique and complications, in the section Endovascular Aortic Repair.
INTRODUCTION
An aneurysm is dilation of the arterial wall to >1.5 times its normal diameter. Aneurysms have been classically distinguished as true aneurysms, pseudoaneurysms, and mycotic aneurysms. The wall of a true aneurysm involves of all layers of the vessel. Risk factors for these include smoking,
 increasing age, white race, hypertension, hyperlipidemia, connective tissue disorders, and familial history of aneurysm.
PATHOPHYSIOLOGY
A progressive decrease in elastin, collagen, and fibrolamellar units results in thinning of the media of the vascular wall and a decrease in its tensile strength. In aortic true aneurysm, the dilatation and increased wall force are intertwined, creating more dilatation (Laplace law: wall tension = pressure
× radius). The rate of aneurysmal dilatation is variable, with larger aneurysms expanding more quickly and changing a mean .25 to .5 cm per year.
However, abrupt expansion occurs and is not predictable, and larger aneurysms are more likely to rupture. Rupture is catastrophic, occurring once the stress on the vessel wall exceeds its tensile strength. Patients with low socioeconomic position are at greater risk to present with a ruptured aortic
 aneurysm (versus intact aneurysm) and are more likely to have poor outcomes after surgical repair.
The wall of a pseudoaneurysm consists partly of the vessel wall and partly of fibrous or other surrounding tissue. A pseudoaneurysm can develop at
 the site of previous vessel catheterization and at anastomoses from prior vascular reconstruction, trauma, or infection. Small pseudoaneurysms may eventually spontaneously thrombose.
Mycotic aneurysms and infected aneurysms occur due to an infection in the vessel wall, often in an immunocompromised patient. A mycotic aneurysm occurs secondary to a septic embolization from valvular endocarditis, while an infected aneurysm develops in an existing aneurysm after
 bacteremia or direct extension from a neighboring infection. IV drug abuse is a significant risk factor for both types of these aneurysms. The clinician
 should be vigilant for this diagnosis in patients abusing IV drugs because the misdiagnosis of cellulitis or abscess is possible.
Peripheral and visceral aneurysms are less frequent but an important subset of arterial aneurysmal disease. Popliteal artery aneurysms are the
 most common peripheral aneurysm; they often coexist with contralateral popliteal aneurysms or abdominal aortic aneurysms. Aneurysms of the femoral artery are uncommon and often accompany aneurysmal disease at other sites. Visceral artery aneurysms may occur anywhere but are most common in the renal, splenic, and hepatic arteries. Most visceral aneurysms remain silent and undetected until a complication such as rupture occurs.

All but splenic artery aneurysms are more common in elderly men. Complications of aneurysms include rupture, which has an 80% mortality rate, and
,8 thrombosis, creating ischemia in the perfused organ.
GENERAL CLINICAL FEATURES OF ANEURYSMS
Clinical signs and symptoms can be nonspecific; often, the symptoms are driven by location, the pressure exerted upon neighboring structures, or the signs of peripheral embolization from an intramural thrombus. Visceral aneurysms are often detected after an abdominal CT scan for abdominal or
 fClahnakp cteorm 6p0l:a Ainntes;u sriymsmilaarll yD, lisoewaesre e,x Ltroeumisiety A a.n Peruinrycsem; sG aarrey oAft. eJno dhentseocnted during an extremity Doppler US examination in a search for deepP vaegneo 1u s/  t©h2ro0m25b MoscisG. rOanwc eH rilul.p Atull rRe iogchctsu rRs eins earnvye tdr.u n Tcaelr manse oufr yUssme , * h Pemrivoarcrhy aPgoicli csyh o * c Nk odteicvee l * o Apsc,c aensds imbiolirtytality is high without prompt surgical intervention.
ABDOMINAL AORTIC ANEURYSMS
An abdominal aortic aneurysm is defined as an aorta ≥3.0 cm in diameter; repair is considered for an aneurysm ≥5.0 cm in diameter.
Patients with an abdominal aortic aneurysm often have a first­degree relative with an aortic aneurysm (18%). Most patients are >60 years old, and males have increased risk. Patients with aneurysms involving other major arteries and those with peripheral arterial disease are also at increased risk for aortic aneurysmal disease. Smoking is the most important environmental risk factor, with the prevalence of abdominal aortic aneurysm being more
,9 than four times that in lifelong nonsmokers. In addition, smoking is a major risk factor for accelerated aneurysmal growth and rupture.
CLINICAL FEATURES
Back or abdominal pain is the most common presenting symptom with aortic aneurysm or rupture. The pain is classically severe and abrupt in onset, with about half of patients describing a ripping or tearing pain. The classic triad of a ruptured abdominal aortic aneurysm—abdominal pain, pulsatile
 abdominal mass, and hypotension—occurs in only one third of patients. Syncope occurs in about 10%. Many patients present with nonclassic sites of pain, such as the flank, groin, isolated quadrants of the abdomen, and hip. Other common presenting symptoms include nausea, vomiting, bladder
 pain, hip pain, or tenesmus. Eleven percent of patients deny existence of pain.
Symptomatic abdominal aortic aneurysms may present with GI bleeding from an aortoenteric fistula, extremity ischemia from embolization of a thrombus in the aneurysm, shock, or sudden death. Sudden death most commonly occurs from intraperitoneal rupture of the aneurysm, which leads to massive, rapid blood loss. Syncope without warning symptoms followed by severe abdominal or back pain suggests rupture of an abdominal aortic or visceral aneurysm with some temporary containment. Syncope is caused by rapid blood loss and a lack of cerebral perfusion. Patients may regain consciousness, but irreversible hemorrhagic shock follows without prompt diagnosis and intervention.
DIAGNOSIS
Diagnosis is suspected clinically and confirmed by imaging if the urgency for intervention allows. Physical examination has only a moderate ability to detect a large abdominal aortic aneurysm. The sensitivity of abdominal palpation increases with aortic aneurysm diameter, ranging from 29% for a diameter of .0 to .9 cm to 50% for a diameter of .0 to .9 cm and 76% for a diameter of ≥5.0 cm.  Tenderness to palpation of an aneurysm is commonly interpreted as a sign of aneurysmal expansion or rupture. However, a lack of tenderness does not indicate an intact aorta. Examination is difficult in obese patients, and aortic size may be overestimated by palpation in thin patients. Hypotension and tachycardia are found in a minority of
 cases.
The differential diagnoses include the causes of syncope, abdominal pain, chest pain, back pain, and shock. When seeing a patient with abrupt back pain with syncope or shock, consider aortic aneurysm rupture. However, other cardiac, abdominal, and retroperitoneal diseases may be the cause, including renal disorders, hepatobiliary disorders, and pancreatic disease. If symptoms are insidious, it is possible that some patients may appear well enough and receive benign diagnoses, such as musculoskeletal back pain, and are discharged from the ED. Beware of misdiagnosis as renal colic.
Diagnosis is confounded by coexisting pathology. Coronary artery disease and chronic lung disease are often present, and signs and symptoms of these disorders may distract the physician from the diagnosis of aneurysmal disease. This is especially true in patients without severe pain or with findings that seem congruent with another cause (e.g., ECG changes or dyspnea).
External signs of acute rupture are rare and include periumbilical ecchymosis (Cullen sign) or flank ecchymosis (Grey Turner sign). Retroperitoneal blood may dissect into the perineum or groin, causing scrotal or vulvar hematomas or inguinal masses. Retroperitoneal blood may irritate the psoas muscle, triggering an “iliopsoas sign” (pain upon extension of the hip, typically with the patient lying on the opposite side). Blood may compress the femoral nerve and present as a neuropathy. The presence or rupture of an abdominal aortic aneurysm typically does not alter femoral arterial
 pulsations.
Think of aortoenteric fistulas in patients with unexplained or high­volume upper or lower GI bleeding, especially in patients without liver disease. A history of aortic graft placement increases the risk of fistula. Fistulas most frequently involve the duodenum, with hematemesis, melenemesis, melena, or hematochezia. While life­threatening bleeding is common, mild sentinel bleeding may be the first sign. Aortic aneurysms also may erode into the venous vasculature and form aortovenous fistulas, which cause high­output cardiac failure, decreased arterial blood flow distal to the fistula, and increased central venous volume.
Contained chronic abdominal aortic aneurysmal ruptures are not common. A retroperitoneal rupture may cause enough fibrosis to limit blood loss, and the patient may look well. The inflammatory response commonly causes pain, with pain continuing for an extended interval, clouding the diagnosis.
Imaging
Unstable patients should not be sent out of the ED for imaging. Bedside US is the imaging modality of choice for unstable patients. Occasionally, an aneurysm is picked up on plain abdominal radiography (Figure 60­1). For stable patients in whom an aortic aneurysm is suspected, imaging may involve US (Figure 60­2), CT scanning (Figure 60­3), or uncommonly for ED patients, MRI. Plain abdominal films may show a calcified and bulging aortic contour, implying the presence of an aneurysm (Figure 60­1). Approximately 65% of patients with symptomatic aortic aneurysmal disease have a calcified aorta, which may be more obvious on a lateral view. Plain film radiographs do not exclude the presence of abdominal aortic aneurysm or detect rupture and should be omitted for most patients.
FIGURE 60­1. Plain radiographic images of an abdominal aortic aneurysm. A. Lateral view of a calcified infrarenal aortic aneurysm. B. Posteroanterior view of a calcified infrarenal aortic aneurysm.
FIGURE 60­2. Bedside US image of an abdominal aortic aneurysm. This aneurysm measures .5 cm.
FIGURE 60­3. CT scan of a patient with a 12­cm abdominal aortic aneurysm. Calcification of the aortic wall is seen in the anterior aspect of the aneurysm. Evidence of hemorrhage and surrounding inflammation (arrow).

Bedside US (Figure 60­2) is ideal for initial screening. A technically adequate US study has >90% sensitivity for demonstrating the
 presence of an aneurysm and measuring its diameter. Obesity, bowel gas, and abdominal tenderness may make the study difficult to perform. Measure aneurysms from the outside margin of one wall to the outside margin of the opposite wall in both the transverse (Figure 60­4) and longitudinal (Figure 60­5) planes. Identifying the superior mesenteric artery (Figure 60­6) allows distinguishing the aorta from the vena cava. An aortic diameter <3.0 cm excludes acute aneurysmal disease.
FIGURE 60­4. US image of an abdominal aortic aneurysm in the transverse plane.
FIGURE 60­5. US image of an abdominal aortic aneurysm in the longitudinal plane.
FIGURE 60­6. US image of an abdominal aortic aneurysm in the transverse plane showing the superior mesenteric artery (arrow) coursing parallel to the aorta.
CT scanning with IV contrast (Figure 60­3) best detects the anatomic details of the aneurysm and associated hemorrhage. Scan all stable patients with suspected abdominal aneurysmal disease or rupture. For those who cannot have IV contrast, unenhanced CT can reveal aneurysm size and retroperitoneal hemorrhage.
THORACIC AORTIC ANEURYSMS
Thoracic aortic aneurysms may compress or erode into adjacent structures. Presenting symptoms include esophageal, tracheal, bronchial, or even neurologic complaints. A thoracic aneurysm that erodes into an adjacent structure is generally immediately fatal unless in the presence of rapid hemodynamic resuscitation. Refer any asymptomatic thoracic aortic aneurysm patient to a surgeon and primary care provider for management, including blood pressure control. Repair may involve open or endovascular methods, with controversy over which approaches result in the best long­
 term outcomes.
TREATMENT
ED emergency interventions are listed in Table 60­1. TABLE 60­1
ED Emergency Interventions for Symptomatic Abdominal Aortic Aneurysms
Intervention Comments
IV access Place two large­bore IVs in place for rapid administration of crystalloids, blood, or medication.
Consultation As soon as the diagnosis is suspected, consult vascular or general surgery or transfer to an institution capable of emergency repair.
Blood and Targets unclear; restoring normal blood pressure may worsen outcomes; permissive hypotension, a systolic blood pressure of 80–90 fluids mm Hg, is recommended.14 Level of consciousness (responds appropriately) is another target for volume replacement.15
Pain control Avoid severe hypotension and respiratory depression.
In the ED, aortic aneurysm recognition and facilitating rapid surgical intervention for hemorrhage control are key. Consult a surgeon early while evaluating a patient with the triad of abdominal and/or back pain, a pulsatile abdominal mass, and hypotension. Never delay consultation for imaging if hypotension or acute end­organ perfusion deficit is evident; bedside US can provide a measurement of the aortic diameter and a tentative diagnosis
 in most cases. Use advanced imaging only in patients fully compensated or for patients unlikely to have a ruptured abdominal aortic aneurysm.
Standard resuscitative actions include insertion of two large­bore IV catheters, initiation of cardiac monitoring, and supplemental oxygen. Vigorous
 fluid resuscitation may be harmful; there are limited data, but guidelines from the Society of Vascular Surgery support limiting resuscitation to a
,15 systolic blood pressure target of  to  mm Hg with intact mentation until surgical control occurs. In the event of suspected expanding aneurysm and severe hypertension, esmolol (half­life,  minutes) is recommended for its ability to be titrated to a target systolic blood
,15 pressure of 120 mm Hg. Esmolol can be quickly stopped if the patient’s blood pressure drops suddenly.
Resuscitative endovascular balloon occlusion of the aorta has been used in the setting of ruptured abdominal aortic aneurysms to occlude the aorta above the aneurysmal rupture (see discussion in Chapter 254, “Trauma in Adults”). Currently, the studies are small and inconclusive as to mortality
 reduction. Use of resuscitative endovascular balloon occlusion of the aorta requires training as well as a patient management plan after its insertion.
Currently, its use is seen primarily in the setting of trauma, and its availability is limited to larger centers with vascular teams available to manage the patient.
Symptomatic aneurysms of any size are considered emergent. If at a site without appropriate surgical capacity, initiate patient resuscitation and arrange for immediate transfer to a medical center capable of emergency repair. Outcomes are better if prompt transfer occurs rather than using
,18 local diagnostics (aside from bedside US). Immediate transfer with providers able to recognize and treat shock (having fluid, blood, and blood products available) is the best option for unstable patients. In comparison to asymptomatic aneurysmal repair, patients with symptomatic aneurysms
 have a twofold increased risk of perioperative mortality, and those with rupture have a sevenfold increased risk.
All asymptomatic aortic aneurysms should be referred for follow­up. Abdominal aortic aneurysms ≥5 cm in diameter are at an increased risk of rupture (size is measured from outer wall to outer wall) and require prompt (days) follow­up. The patient should be instructed to return immediately for worsening symptoms or syncope. Abdominal aortic aneurysms in women have a greater likelihood of rupture than in men,
,20  often at smaller sizes. The risk of rupture is elevated in pregnancy and the postpartum period. Aneurysms of  to  cm are less likely to rupture, and these patients can be followed by their primary care physicians or surgeons. The management of patients with small, asymptomatic aneurysms
(including the timing of surgery) varies. The patient should follow up with a vascular surgeon and a primary care provider, the latter for blood pressure
  control. Repairing abdominal aortic aneurysms smaller than .5 cm does not improve survival in men, but may be indicated in women.
ENDOVASCULAR AORTIC REPAIR
Endovascular repair of aortic aneurysms (EVAR) has steadily increased, compared with open repair, due to its less invasive technique and decreased
23­27 operative time, blood loss, hospital length of stay, and overall perioperative morbidity and mortality. Initially endovascular repair was primarily used for abdominal aortic aneurysm but is now also used for both Stanford type A and type B thoracic aortic aneurysms (TEVAR). The principle of repair is to place an aortic stent graft within the aneurysmal portion of the aorta, creating a bridge between the proximal and distal non­aneurysmal sections of the aorta to exclude the aneurysm from aortic circulation (Fig 60­7). Access is achieved through the femoral artery either percutaneously or by surgical cutdown. Although the remaining aneurysmal sac typically thromboses or decreases in diameter, persistent blood flow into the sac from proximal or distal inadequate seals can create the potential for aneurysmal expansion or rupture (endoleak). In addition, the branch arteries including
 lumbar and inferior mesenteric arteries are occluded, which can lead to continued blood flow into the aneurysmal sac.
FIGURE 60­7. Illustration of stents in endovascular aortic repair (EVAR) and thoracic endovascular aortic repair (TEVAR). EVAR illustration demonstrates fenestrations for renal arteries and the superior mesenteric artery.
Endovascular stent grafts require lifelong surveillance. Late endograft complications develop and require intervention in up to 30% of cases in
EVAR and 38% in TEVAR. Patients must undergo a triple­phase (noncontrast, contrast, and delayed) spiral CT and abdominal x­rays within the first month after repair. For the first  to  years, patients undergo imaging at 6­month intervals and yearly thereafter. CT is necessary to detect endoleaks,
 graft migration, and changes in aneurysm size. Plain x­ray helps detect subtle positional changes, stent fractures, and suture breaks . The graft can angulate, kink, migrate, or thrombose. Endoleaks (persistent flow of blood into the aneurysm sac) have been described in up to 20% of patients.

Diagnosis of an endoleak requires CT angiography with an arterial phase, then delayed venous timed bolus . In addition, access site complications are common including hematoma, acute thrombosis of the access vessel, distal embolization, dissection, pseudoaneurysm, and arteriovenous fistula.
,27
TEVAR often requires stent coverage of the left subclavian artery, with potential complications of arm ischemia or stroke . In the first  to  postoperative days, patients can experience a post­implantation inflammatory syndrome with fever, leukocytosis, elevated CRP, and perigraft air.
Endograft infection can occur in ≤3 percent with mortality rates of  to  percent. Aorto­enteric fistulas have been documented. Consider complications of endovascular repair in any patient with back, chest, or abdominal pain; fever; stroke; or limb ischemia. Obtain immediate consultation with the vascular surgeon for any suspected complications of EVAR/TEVAR.
EXTREMITY AND VISCERAL ANEURYSMS
Aneurysms of arteries other than the aorta cause symptoms by expansion or rupture. Table 60­2 lists the risk factors, clinical presentation, and management of nonaortic large­artery aneurysms. Aneurysms of peripheral arteries, such as the popliteal, subclavian, or femoral, may present with limb­threatening complications, including rupture, thrombosis, and peripheral embolization. Visceral artery aneurysms typically remain silent until a complication occurs. Complications include renovascular hypertension, renal artery thrombosis, organ infarction from distal embolization,
 arteriovenous fistula formation, and rupture. Consider visceral artery aneurysms in the differential diagnosis of a patient with sudden acute
,8,29,30 abdominal pain and evidence for intraperitoneal hemorrhage.
TABLE 60­2
Nonaortic Large­Artery Aneurysms
Artery Risk Factors Clinical Presentation Management
Popliteal (>2 cm Advanced age, male gender, trauma, Most common peripheral aneurysm; discomfort behind Thrombolysis, or >150% of congenital disorders knee with swelling with or without deep venous ligation, arterial normal caliber) thrombosis bypass, endovascular repair
Subclavian Arteriosclerosis, thoracic outlet obstruction Pulsatile mass above or below clavicle, dysphagia, stridor, Surgical repair chest pain, hoarseness, upper extremity fatigue or numbness and tingling, limb ischemic symptoms
Femoral Advanced age, male gender, trauma, Pulsatile mass with or without pain, limb ischemic Thrombolysis, congenital disorders symptoms, peripheral embolic symptoms ligation, arterial bypass, endovascular repair
Femoral Prior femoral artery catheterization, trauma, Pulsatile mass with or without pain Surgical repair pseudoaneurysm infection
Iliac Arteriosclerosis, male gender Pain in groin, scrotum, or lower abdomen; sciatica; vulvar or Surgical repair groin hematoma with rupture
Renal Age 40–60 y, no gender preference, HTN, Flank pain, hematuria, collecting system obstruction, shock Surgical repair, fibrodysplasia, arteriosclerosis if ruptured nephrectomy
Splenic Advanced age, female gender, HTN, Rapid symptom onset; epigastric or left upper quadrant Surgical repair, congenital, arteriosclerosis, liver disease, pain first, then diffuse abdominal pain with rupture, shock splenectomy, multiparous, rupture increased in pregnancy embolization if unruptured
Hepatic Infection, arteriosclerosis, trauma, vasculitis Obstructive jaundice, hemobilia from rupture into common Surgical ligation, bile duct, right upper quadrant pain, peritonitis, upper GI embolization bleed
Mycotic or Intravenous drug user, patients with known Fever, pain at the site of the infected aneurysm Intravenous infected aneurysms antibiotics, surgical aneurysms repair
Abbreviation: HTN = hypertension.
A popliteal aneurysm is a localized dilation of the popliteal artery of >2 cm or >150% of the normal arterial caliber. Symptoms include discomfort behind the knee, leg swelling with or without deep venous thrombosis, or claudication. Rupture is rare. Sudden acute limb ischemia caused by
 thrombosis or embolization from the aneurysm is the most serious common complication. On physical examination, a firm mass or a palpable pulsatile mass is evident in the popliteal fossa. Confirm the diagnosis with arterial US, and assess both extremities since popliteal aneurysms can be bilateral.
Femoral or iliac artery aneurysms present as a pulsatile mass in the groin or upper thigh, scrotal hematoma, or acute limb ischemia. Iliac artery aneurysms are notoriously difficult to suspect clinically because the iliac artery cannot be examined directly, and symptoms suggest urologic, bowel, or groin disorders.
Hepatic artery aneurysms result from atherosclerosis or trauma and present as acute hemorrhagic shock with intraperitoneal or retroperitoneal rupture. Quincke’s triad (jaundice, biliary colic, and upper GI bleeding) is seen when hemobilia from a leaking hepatic artery aneurysm occurs.
Splenic artery aneurysms present with left upper quadrant pain, undifferentiated shock, or intra­abdominal hemorrhage. A rupture of the splenic artery has a poor prognosis because of its intraperitoneal location and nondescript presentation; be wary of these in the third trimester of
 pregnancy. Portal hypertension is also a risk factor for splenic artery aneurysms.
Symptomatic subclavian and innominate artery aneurysms can lead to limb ischemia. When evaluating a patient with upper extremity pain, weakness, pallor, or nondermatome sensory changes, think of these aneurysms as a possible cause.
Anastomotic aneurysms may occur in the aortic, iliac, or femoral arteries. These aneurysms cause catastrophic bleeding if they rupture; however, they may present with smaller sentinel hemorrhages noted as pain or transient hypotension. Anastomotic aneurysms may erode into the adjacent intestine and form an aortoenteric fistula. Severe lower GI bleeding in a patient with a history of abdominal aortic aneurysm repair is a classic presentation of this event.
Doppler US is the initial noninvasive diagnostic study for peripheral aneurysmal disease of the femoral, popliteal, and subclavian artery. If ischemia and thrombosis exist, emergent CT angiography is usually performed for both diagnosis and potential treatment.
Symptomatic peripheral artery aneurysms require rapid diagnosis and consultation, especially in light of the potential for rupture, thrombosis, and limb ischemia (Table 60­2). For patients with clinical extremity ischemia, consult immediately with a vascular surgeon to expedite repair and limb salvage. Asymptomatic peripheral aneurysms are managed by a vascular consultant as an outpatient.
Mycotic and infected aneurysms require appropriate IV antibiotics, often for prolonged periods, and consultation for surgical repair. Emergent
 consultation should be sought for suspected rupture.


