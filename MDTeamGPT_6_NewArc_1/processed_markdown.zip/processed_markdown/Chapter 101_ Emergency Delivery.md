## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 101: Emergency Delivery
Elisabeth Frasure Sarah; Kerrigan Kathleen
INTRODUCTION AND EPIDEMIOLOGY
The thought of a woman presenting to the ED in active labor is justifiably a cause for anxiety—the emergency physician must contend not only with the often rusty recollection of the stages of normal delivery but also with the knowledge that there are serious and even fatal complications associated with labor. Maternal and fetal survival may depend on the ability to successfully manage preeclampsia, eclampsia, hemorrhage, shoulder dystocia, malpresentation, cord prolapse, breech delivery, or fetal distress. Every ED should be prepared to take care of a woman in active labor. Tools include a basic delivery kit, an infant warmer or isolate, and medical supplies and equipment for neonatal resuscitation (see Chapter 108, “Resuscitation of
Neonates” and Tables 101­1 and 101­2).
TABLE 101­1
Equipment and Supplies for Emergency Delivery
Sterile gloves
Sterile towels and drapes
Povidone­iodine or chlorhexidine to cleanse the perineum neither of these agents require trademark symbol
Sterile lubricant gel
Sterile scissors
Kelly clamps
Cord clamps
Rubber suction bulb
Towel or blanket for the infant
Gauze sponges (4×4)
Syringes (10 mL) and needles (22–24 gauge)
Placenta basin
Suture (3­0 chromic and 2­0 Vicryl) and needle driver
Note: List excludes standard adult and neonatal resuscitation equipment.
TABLE 101­2
Medications for Emergency Delivery and Indications for Use
Classification Medication Dosage Indication/Use Contraindications
Uterotonic Oxytocin  units/1000 mL normal saline or  units IM Stimulation of uterine Hypersensitivity contraction or as uterotonic for PPH
Misoprostol 1000 micrograms PR, SL, or PO once Unlabeled use for PPH Hypersensitivity
Downloaded 2025­7­1 6M:3e tPh y lYeorguorn IoPv iinse 1360..12 4m2il.l1ig5r9am.1 2IM7 or IV or PO; may repeat at 2­ to 4­h PPH Hypersensitivity,
Chapter 101: Emergency Delivery, Elisabetihn tFerrvaaslusre Sarah; Kerrigan Kathleen hypertension,
. Terms of Use * Privacy Policy * Notice * Accessibility eclampsia, preeclampsia
Carboprost 250 micrograms IM every 15–90 min (total dose  PPH Asthma milligrams)
Antihypertensive Hydralazine  milligrams IV, followed by 5­ to 10­milligram boluses Preeclampsia/eclampsia, Hypersensitivity every  min hypertensive emergency
Labetalol  milligrams IV, followed by doubled doses up to  Preeclampsia/eclampsia, Hypersensitivity, milligrams (20–40–80–80) every  min; maximum total hypertensive emergency sinus bradycardia dose, 220 milligrams
Anticonvulsant Magnesium Loading dose of 4–6 grams IV over  min, followed by  Seizure prophylaxis in Myasthenia gravis sulfate grams/h infusion; can also give  grams IM in each buttock; preeclampsia/eclampsia max serum Mg =  mg/dL
Electrolyte Calcium  gram IV over  min Magnesium toxicity Hypersensitivity, supplement gluconate cardiac arrhythmia toxicity
Analgesic Lidocaine 1% 1–10 mL injected locally Local anesthetic Hypersensitivity
Fentanyl,   micrograms/mL Short­acting opiate Hypersensitivity micrograms/mL analgesic
Opiate Naloxone .4–2.0 milligrams IV every 2–3 min as needed up to  Narcotic overdose Hypersensitivity antagonist milligrams cumulative dose
Antiemetic Ondansetron  milligrams IV Nausea, vomiting Hypersensitivity
Abbreviation: PPH = postpartum hemorrhage.

Out­of­hospital births occurred in .36% of births in 2012. Occasionally, planned home deliveries experience medical complications and require rapid transport to the ED to assist with labor and delivery. In a prospective study of home births in the United States and Canada, nearly 12% of 5400 women
 who had planned a home delivery ultimately required urgent transfer to a hospital during the course of labor. The majority of intrapartum transfers were performed for failure to progress, need for pain management, and maternal exhaustion. Postpartum transfers encompassed a variety of complications such as maternal hemorrhage, retained placenta, or newborn respiratory distress.
Out­of­hospital deliveries may also occur due to inadequate or nonexistent prenatal care, transportation difficulties, a remote setting, or the onset of premature labor. Occasionally, a woman may attempt to avoid the hospital/physician fees associated with pregnancy until the delivery of her child, presenting to a hospital for the first time when in active labor.
The development of obstetric centers for high­risk pregnancy has led to a significant decline in neonatal mortality in the United States. The most common reasons for transport to such centers include preterm labor (41%), premature rupture of membranes (21%), hypertensive disease (16%), and
 antepartum hemorrhage (13%). Other indications for transport include eclampsia or preeclampsia, fetal distress, multiple gestation, fetal anomalies, and maternal health problems, including traumatic injuries. EMS units transporting an actively laboring patient should carry sterile delivery packs, relevant medical supplies (Table 101­1), and appropriate medications (Table 101­2). The transport team should be trained to assist in the precipitous delivery of an infant. Prehospital protocols regarding the complications of labor and delivery should be reviewed regularly to ensure that EMS personnel are adequately prepared for both normal delivery and potentially catastrophic pregnancy­related events.
For deliveries in an austere environment or in a disaster zone, the United Nations Population Fund provides a vaginal delivery kit for use during disaster relief, which includes a plastic sheet to lay on the ground, soap for washing hands and the perineum, string and a razor blade to tie and cut the
 umbilical cord, and a blanket to protect the newborn baby.
LABOR
PHYSIOLOGY
RUPTURE OF MEMBRANES
Determining rupture of membranes predicts not only the likelihood of imminent labor but also the potential for complications, such as infection or cord prolapse. Spontaneous rupture of membranes occurs during the course of active labor in the majority of patients, although it also happens prior
 to onset of labor in approximately 8% of third­trimester patients. Fifty percent of women who experience premature rupture of membranes deliver
 within  hours, and 95% give birth within  hours of this event. The history of spontaneous rupture of membranes typically involves report of a gush of clear or blood­tinged fluid. Occasionally, patients recount continued leaking or dampening of their underwear on standing or with a Valsalva maneuver. Greenish brown fluid suggests the presence of meconium in amniotic fluid.
Rupture of membranes may be confirmed by using nitrazine paper to test residual fluid in the fornix or vaginal vault while performing a sterile speculum examination. Amniotic fluid has a pH of .0 to .4 and will turn nitrazine paper a dark blue. Vaginal fluid, on the other hand, typically has a pH of .5 to .5; the nitrazine strip, thus, remains yellow. False­positive results may occur, however, in the presence of blood, lubricant,
Trichomonas vaginalis, semen, or even cervical mucus. Another test that confirms rupture of membranes is ferning, which is the observation of sodium chloride crystals on a microscope slide as amniotic fluid dries.
CERVICAL DILATATION
Cervical dilatation describes the diameter of the internal cervical os and indicates the progression of labor. The index and middle fingers of the examining hand are used to estimate the diameter, which is expressed in centimeters (from closed to  cm). Dilatation of  cm indicates full dilatation. As labor progresses, the cervix also undergoes thinning, known as effacement, which is described in terms of a percentage of normal cervical length. Unfortunately, this estimate is poorly reproducible among examiners. Station indicates the level that the fetus occupies in the pelvis.
The maternal ischial spines serve as the reference point and are palpable on either side of the vaginal canal (located at  and  o’clock). If the presenting fetal part remains above the ischial spines, the station is described as negative. Once the presenting fetal part has reached the level of the ischial spines, the station is , with further descent into the pelvis described as +1 or +2. Therefore, a +3 station corresponds to visible scalp at the introitus, indicating a fetal position consistent with impending delivery.
TRUE VERSUS FALSE LABOR
Distinguishing true from false labor is an important initial step in the management of the pregnant patient (Table 101­3). False labor is defined as uterine contractions that do not produce cervical changes and is characterized by irregular, brief contractions that are usually confined to the lower abdomen. Commonly known as Braxton Hicks contractions, they are irregular in both intensity and duration. False labor may persist for several days and is commonly treated with hydration and rest.
TABLE 101­3
True Versus False Labor
True Labor False Labor
Contractions
Rhythm Regular Irregular
Intervals Gradually shorten Unchanged
Intensity Gradually increases Unchanged
Discomfort
Location Back and abdomen Lower abdomen
Sedation No effect Usually relieved
Cervical dilatation Yes No
Source: Reproduced with permission from Cunningham FG, Leveno KJ, Bloom SL, Hauth JC, Rouse DJ, Spong CY (eds): Williams Obstetrics, 23rd ed. McGraw­Hill, Inc.,
2010. Table 17­4 on AccessMedicine.com.
True labor, on the other hand, is characterized by painful, repetitive uterine contractions that increase steadily in both intensity and duration and result in cervical effacement and dilatation. Specifically, true labor pains typically commence in the fundal region and upper abdomen and radiate into the pelvis and lower back. True labor leads to not only cervical dilatation and effacement but also the progressive descent of the fetus into the pelvis, in preparation for delivery.
STAGES OF LABOR
There are three stages of labor (Table 101­4). The first stage commences with the onset of regular uterine contractions and ends with full cervical dilatation. The first stage can be subdivided into two phases: latent and active. The latent phase is characterized by moderately uncomfortable uterine contractions that are infrequent and irregular, resulting in gradual cervical changes. In this preparatory phase, the uterus orients to contractions and the cervix undergoes both effacement and softening. The active phase is typically noted to arise once the cervix has dilated to  to  cm and results in cervical dilatation at an average rate of .2 cm/h in nulliparous women and .5 cm/h in multiparous women. The second stage of labor commences at
 full dilatation and ends with the delivery of the infant. The mean length of the second stage of labor is  minutes for multiparous women and 
 minutes for nulliparous women. The third stage of labor starts after the delivery of the infant and ends with the delivery of the placenta. The third stage usually lasts less than  minutes, and active intervention is usually not required until after  minutes, unless hemorrhage occurs.
TABLE 101­4
Stages of Labor
Stage Definition Comments
First stage From onset of regular uterine contractions to full cervical dilatation —
Latent phase Irregular, infrequent contractions Preparatory phase, cervix softens and effaces
Active phase Begins once cervix has dilated to 3–4 cm Nulliparas: cervix dilates at .2 cm/h
Multiparas: cervix dilates at .5 cm/h
Second stage From full dilatation to delivery Nulliparas: mean duration  min
Multiparas: mean duration  min
Third stage From delivery of infant to delivery of placenta  min; intervention not needed until >30 min
FETAL DISTRESS
Fetal distress may occur during active labor. Indicators of fetal distress include fetal bradycardia or tachycardia, or late decelerations in fetal heart rate, which are defined as persistent drops in fetal heart rate both during and more than  seconds after a contraction. A physician or nurse trained in fetal monitoring can identify fetal distress (Figure 101­1). Doppler measurement of fetal heart tones is not reliable to detect decelerations. If decelerations are suspected, obtain emergency obstetrics consultation, and try to increase maternal blood flow by positioning the patient in the left lateral position, provide IV hydration, and administer oxygen. Further information is provided in the Advanced Life Support in Obstetrics course.
FIGURE 101­1. Fetal heart rate variability and uterine contraction patterns. A. Good variability. B. Good variability with brief accelerations. Fetal heart rises above baseline and quickly returns to normal. A reassuring pattern. C. Poor variability. May be due to fetal hypoxia. D. Variable decelerations. No relationship to uterine contractions. May represent cord compression. E. Late deceleration. Occurs at onset of contraction and slow return to baseline after contraction ends. Signifies uteroplacental insufficiency and fetal hypoxia. [Reproduced with permission from Pearlman MD, Tintinalli JE, Dyne PL
(eds): Obstetric and Gynecologic Emergencies: Diagnosis and Management. New York: McGraw­Hill, Inc.; 2003. Figs. 10­9 and 10­10, pp. 131 and 132.]
CLINICAL EVALUATION
When a patient >20 weeks’ gestation presents to the ED with signs of labor, immediately obtain both maternal vital signs (blood pressure, heart rate, respiratory rate, oxygen saturation, temperature) and the fetal heart rate. Doppler US can be used to measure fetal heart rate; a normal fetal heart rate is generally 120 to 160 beats/min, bradycardia is defined as less than 110 beats/min, and
 tachycardia is greater than 160 beats/min. A persistently slow fetal heart rate indicates fetal distress and requires emergency obstetric consultation. As part of the initial evaluation, obtain IV access, procure baseline laboratory studies including blood type, and send a urinalysis.
HISTORY
Ask about the onset and frequency of uterine contractions, fetal membrane status, presence or absence of vaginal bleeding, and presence or absence of fetal movement. The obstetric history should include parity, history of complications with prior deliveries, history of precipitous deliveries, prenatal care during this pregnancy, and estimated date of delivery. Obtain a medical and surgical history and a list of current medications and allergies, and ask the patient about substance abuse. Inquire about symptoms of infection, such as fevers, chills, or foul­smelling vaginal discharge.
Gestational Age
If the patient knows the first day of her last menstrual period, the estimated date of delivery can be calculated by adding  months and  days to that date (Nägele’s rule). Fundal height also provides a rapid estimate of gestational age once greater than  weeks and is measured in centimeters (cm) from the pubic symphysis to the top of the fundus (cm = weeks of gestation ±  weeks). Fundal height may be falsely overestimated in the obese patient and underestimated in active labor when the fetal head has descended into the pelvis. Bedside US also provides a useful assessment of gestational age in the third trimester, but estimated age can vary by ±3 weeks.
PHYSICAL EXAMINATION
Monitor vital signs for evidence of maternal fever, tachycardia, or elevated blood pressure. Assess fetal heart tones for bradycardia or tachycardia. Do not keep the pregnant woman flat on her back for a prolonged time period. Compression of venous return by the gravid uterus can lead to hypotension in the mother, which in turn results in decreased blood supply to the fetus. Place the patient in the left lateral position following the physical examination. On abdominal examination, determine fundal height, abdominal or uterine tenderness to palpation, and presence of uterine contractions. Examine the perineum for perineal lesions, such as those caused by herpes simplex virus, which may be a contraindication for a vaginal delivery.
PELVIC EXAMINATION
Vaginal Bleeding Present
Patients with vaginal bleeding should be evaluated with bedside US prior to speculum or bimanual examination in order to rule out placenta previa.
No Vaginal Bleeding
Patients without vaginal bleeding should be evaluated first with a sterile speculum examination to determine if membranes have been ruptured, to note cervical dilatation, and to determine fetal station and presentation. Bedside US is the simplest method to verify presentation. Vertex presentation and lie can also be confirmed through palpation of the cranial sutures on digital examination. Palpation of small parts, such as feet or hands, often indicates malpresentation and will require urgent obstetrics consultation. If meconium is present on the examining finger, be prepared for neonatal resuscitation (see Chapter 108, “Resuscitation of Neonates”).
Rupture of Membranes
If rupture of membranes is suspected, perform a sterile speculum examination (do not use lubricant because lubricant may produce a false­
 positive nitrazine test), but do not perform a digital examination because even one digital examination increases the risk of infection.
Also avoid digital examinations in the preterm patient in whom the prolongation of gestation is desired.
EMERGENCY DELIVERY
If time allows, prepare the perineum by washing it with mild soap and water and swabbing with povidone­iodine. Place drapes over the patient.
Medical personnel attending to the patient should don gowns, masks, and gloves.
The first steps in the management of a woman in active labor are to measure vital signs and initiate supportive therapy. Obtain venous access, provide
IV hydration, and initiate maternal and fetal monitoring (if available). Delivery is imminent if the pelvic examination reveals complete cervical effacement and the fetus is at the introitus. Labor can progress very rapidly, particularly in multiparous patients. Both the stage of labor and the parity of the patient should be taken into account when considering whether to transport a laboring patient to the labor and delivery suite or to another facility. If the cervix is fully effaced and dilated or the fetal head is visible during contractions, the obstetrician (if available) should come to the ED rather than risk a precipitous delivery during transport to the delivery suite.
As the cervix fully dilates, effacement becomes complete, the fetus descends into the pelvis, and the patient will experience the urge to push. The cervix should be fully dilated before the patient begins to push in order to avoid cervical lacerations. If not already done by US, determine fetal presentation by palpating skull sutures and fontanelle or the buttock or extremity.
Six cardinal movements describe the process of fetal descent during labor and delivery: (1) engagement, (2) flexion, (3) descent, (4) internal rotation,
(5) extension, and (6) external rotation (Figure 101­2). The following discussion describes delivery in the cephalic, occiput anterior position. As the fetus descends through the birth canal and reaches the introitus, the perineum bulges in order to accommodate the fetal head. Gentle digital stretching of the inferior portion of the perineum can aid delivery. The perineum undergoes gradual thinning and stretching to enable passage of the newborn. (See Video: Vaginal Delivery With Episiotomy.)
FIGURE 101­2. The movements of normal delivery for a vertex presentation. A. Engagement, flexion, and descent with vertex anterior. B. Internal rotation with occiput becoming anterior. C. Extension and delivery of the head. As the infant’s head emerges from the introitus, support the perineum by placing a sterile towel along the inferior part of the perineum with one hand, and support the fetal head with the other hand. Ask the mother to breathe through contractions (rather than bear down) in order to deter rapid expulsion of the baby. Provide mild counterpressure for controlled extension of the fetal head. As the infant’s head presents, use the inferior hand to control the fetal chin and keep the superior hand on the crown of the head, supporting the delivery. D. External rotation, bringing the thorax into the anteroposterior diameter of the pelvis. As the head delivers, palpate the infant’s neck to
 assess for the presence of a nuchal cord. Nuchal cord is noted in approximately 25% to 35% of all term deliveries. If the cord is loose, move it over the infant’s head, and allow delivery to proceed as usual. If the cord is wound tightly around the neck, however, apply two close clamps in the most accessible area, and then cut the cord. E. Delivery of the anterior shoulder. Once the head is delivered, it will turn to one side or the other. Grasp the sides of the head with both hands and apply gentle downward traction (go with gravity) until the anterior shoulder is delivered. Jerky or aggressive traction may injure the brachial plexus. If you have not checked for a nuchal cord, do so now. As the head rotates, place the hands on either side of the head, providing gentle downward traction. This maneuver allows for the delivery of the anterior shoulder. F. Delivery of the posterior shoulder. Use an upward movement to deliver the upward shoulder. Do not apply traction. If meconium is present or the newborn is limp or poorly responsive, stimulate the baby and be prepared to begin the steps of neonatal resuscitation with ventilation and oxygenation (see Chapter 108, “Resuscitation of
Neonates”).
Video 101­1: Vaginal Delivery with Episiotomy
Used with permission from Melissa Tscheiner, MetroHealth Medical Center, Department of Emergency Medicine, Cleveland, OH.
Play Video
EPISIOTOMY
Routine episiotomy for a normal spontaneous vaginal delivery varies with practitioner, institution, and country. Episiotomy may be necessary to
 expedite a delivery in cases of fetal distress or shoulder dystocia or if forceps or vacuum devices are used (Figure 101­3). The episiotomy can be performed in the midline or mediolaterally (45 degrees from the midline). Median episiotomy is easy to perform and has less maternal discomfort during recovery, but mediolateral episiotomy has a lower risk of extension to the anal sphincter (third­degree extension) or to the rectum (fourthdegree extension) than median episiotomy. If an episiotomy is clinically necessary, first inject  to  mL of 1% lidocaine solution with a small­gauge needle into the posterior fourchette and perineum. While protecting the infant’s head, make a 2­ to 3­cm incision with scissors in order to extend the vaginal opening, either at the midline or  degrees from the midline. A median incision must be supported with manual pressure from below. Take care to prevent extension of the incision into the rectum.
FIGURE 101­3. Methods for episiotomy.
COMPLETION OF DELIVERY
Do not drop the baby. The combination of amniotic fluid, blood, and vernix generates a very slippery infant. Before delivering the rest of the body, place your posterior hand underneath the axilla of the infant. Use the anterior hand to grasp the ankles of the infant with a firm grip. Following delivery, keep the infant warm and provide gentle stimulation. Do not routinely suction the nose and mouth. Suctioning can cause fetal bradycardia and hypoxia. See Chapter 108, “Resuscitation of Neonates,” for further discussion of neonatal respiratory distress. If delivery is uncomplicated, and the infant has responded well to initial stimulation with a clear airway and good respiratory effort, the mother may hold the child immediately while the cord is cut.
Apgar scores are calculated at  and  minutes after delivery. Scoring parameters include general color, tone, heart rate, respiratory effort, and reflexes
(Table 101­5).
TABLE 101­5
Apgar Scoring for Newborns
Sign  Points  Point  Points
A Activity (muscle tone) Absent Arms and legs flexed Active movement
P Pulse Absent Below 100 beats/min Above 100 beats/min
G Grimace (reflex irritability) No response Grimace Sneezing, coughing, pulling away
A Appearance (skin color) Blue­gray, pale Normal, except extremities Normal over entire body
R Respiration Absent Slow, irregular Good, crying
For an APGAR score of <7, refer to Chapter 108, “Resuscitation of Neonates.” Provide positive­pressure ventilation for all newborns with a heart rate <100 beats/min or who are gasping or apneic after  seconds.
CLAMPING THE UMBILICAL CORD
Do not clamp the umbilical cord of term or preterm infants for at least  to  minutes after birth. Delayed cord clamping increases neonatal iron stores. Double­clamp the umbilical cord  cm distal to its insertion at the umbilicus and transect with sterile scissors. In delivery settings where aseptic care is routine, there is no clear benefit to any additional topical care of the umbilicus. When aseptic care is not
 available, however, antiseptic topical care of the umbilicus with chlorhexidine reduces the risk of omphalitis and neonatal mortality. Once the umbilical cord is cut, dry the infant and either give the infant to the mother or place it in a warming unit.
DELIVERY OF THE PLACENTA
The placenta usually delivers  to  minutes after delivery of the infant. Allow the placenta to separate spontaneously and provide only gentle traction. Aggressive traction on the cord can lead to uterine inversion, tearing of the cord, or disruption of the placenta, all of which can result in severe vaginal bleeding. After the placenta has been removed, gently massage the abdomen at the level of the fundus to promote contraction. Give oxytocin
(10 to  units in  L normal saline at 250 mL/h or  units IM) to sustain uterine contraction.
The estimated blood loss during a vaginal delivery is usually less than 500 mL. Uterine atony, however, which occasionally follows a precipitous delivery, can lead to excessive vaginal bleeding. In that case, give additional oxytocin or another uterotonic of choice (Table 101­2). As contractile
 agents are administered, provide vigorous bimanual massage. If concerned about an episiotomy complication, delay episiotomy or laceration repair until an experienced obstetrician is available to close the laceration and inspect for fourth­degree perineal lacerations.
COMPLICATIONS OF LABOR AND DELIVERY
UMBILICAL CORD PROLAPSE
Umbilical cord compression is life threatening to the fetus. Obtain immediate obstetric assistance, as emergent cesarean delivery is indicated. Should the speculum or bimanual examination reveal a palpable, pulsating umbilical cord, elevate the presenting fetal part to reduce compression on the cord. Keep your hand in the vagina while the patient is transported and prepared for surgery to prevent further compression of the cord by the fetal head. Place the mother in the Trendelenburg position. Do not try to reduce the prolapsed
 cord.
SHOULDER DYSTOCIA
Shoulder dystocia is the impaction of fetal shoulders at the pelvic outlet after delivery of the head. Typically, the anterior shoulder is trapped behind
,16 the pubic symphysis and prevents delivery of the rest of the infant. Complications of shoulder dystocia include fetal brachial plexus injury (due to overaggressive traction), clavicle fracture, fetal hypoxia (due to impaired respirations and/or compression of the umbilical cord), postpartum hemorrhage, and fourth­degree perineal lacerations.
Prior to delivery of the head, the head may retract between contractions. Shoulder dystocia then becomes evident when routine downward traction fails to deliver the anterior shoulder once the head has been delivered. After the infant’s head is delivered, the head retracts tightly against the
 perineum (turtle sign; Figure 101­4). Several steps can be used to relieve shoulder dystocia (Table 101­6). Immediately place the mother in the extreme lithotomy position, with her legs sharply flexed up to the abdomen and the knees held as widely apart as possible (McRoberts maneuver;
Figure 101­5). Either the mother or an assistant should keep the legs held widely apart. Simultaneously apply suprapubic pressure. If a second assistant is available, he or she should place their hands in a CPR position and apply downward pressure just above the pubic symphysis for  to  minutes to disimpact the anterior shoulder. Do not apply pressure to the uterine fundus, as this
 maneuver can further impact the shoulder. Suprapubic pressure serves to rotate the shoulder under the pubic symphysis. The combination of the McRoberts position and suprapubic pressure relieves about 50% of shoulder dystocias.
FIGURE 101­4. Clinical appearance of shoulder dystocia. The infant’s head is impacted against the perineum. [Reprinted with permission from Buckley RG, Knoop KJ:
Gynecologic and obstetric conditions, in Knoop KJ, Stack LB, Storrow AB (eds): Atlas of Emergency Medicine, 2nd ed. New York: McGraw­Hill, Inc.; 2002,
Figure .46.]
TABLE 101­6
Steps to Relieve Shoulder Dystocia
Steps Comments
Flex thighs and McRoberts maneuver keep knees apart as much as possible
Apply suprapubic Keep patient in McRoberts position. Place one hand with wrist clenched, immediately above the pubic symphysis, and push the pressure anterior fetal shoulder to dislodge it. If an assistant is available, place two clenched wrists in CPR position just above pubic symphysis, again using pressure to dislodge the anterior shoulder. Compress for  min.
Do not compress uterine fundus. This worsens impaction.
Deliver posterior Insert hand into posterior vagina, identify arm, and sweep across chest.
arm
Rotational Typically require episiotomy. Attempt to place shoulders in a different diameter.
maneuvers See text.
FIGURE 101­5. McRoberts maneuver. Sharply flex the thighs up onto the abdomen, as shown by the horizontal arrow, and keep the knees spread widely.
Simultaneously provide suprapubic pressure (vertical arrow). [Adapted with permission from Cunningham FG, Leveno KL, Bloom SL, et al: Williams
Obstetrics, 22nd ed. New York: McGraw­Hill, Inc.; 2005, Figure 20­14.]
In the event that the above maneuvers are unsuccessful, the delivery of the posterior arm can be considered as the next maneuver to manage shoulder
 dystocia. To perform this maneuver, the provider reaches into the vagina and identifies the posterior arm. The elbow is flexed and the arm is swept across the fetal chest. This will usually allow the arm to deliver and the anterior shoulder will be disimpacted, allowing the rest of the fetus to deliver.
Should this procedure fail, rotational maneuvers should be attempted. The Rubin maneuver is accomplished by placing a hand on the back surface of the posterior shoulder and rotating the fetus toward the fetal face. The Woods’ corkscrew maneuver (Figure 101­6) is accomplished by placing a hand on the anterior surface of the posterior shoulder and rotating toward the fetal back. Sling procedures have also been described where a finger or 12F or 14F suction catheter is placed through the axilla of the posterior arm. Moderate traction is applied to deliver the posterior shoulder. Do
 not rotate the head. All of the above maneuvers require an episiotomy to allow the provider to place a hand in the vagina.
FIGURE 101­6. Woods corkscrew maneuver, rotating the posterior shoulder.
The Gaskin maneuver (Figure 101­7) can also be employed. It is a simple maneuver, but with IVs and monitors in place or with an exhausted mother, it can be difficult to achieve. Place the patient on all fours. Exert gentle downward traction on the infant’s head. To remember the direction of
 traction, remember to “go with gravity.” In 80% of cases, this maneuver allows the posterior shoulder to successfully deliver.
FIGURE 101­7. Gaskin maneuver. Move the mother onto all fours. This maneuver can widen the pelvic outlet.
BREECH PRESENTATION
Breech presentations occur in 3% to 4% of term pregnancies. Risks of breech presentations include umbilical cord prolapse, trauma, hypoxia, and fetal distress. Breech presentations occur most frequently in the delivery of premature infants; approximately 25% to 30% of all preterm infants (<28 weeks’
 gestation) present in breech position. Given the increased perinatal/neonatal morbidity and mortality associated with vaginal breech deliveries, cesarean section is recommended in breech presentations.
Head entrapment is a major concern in a breech delivery. In a normal cephalic delivery, the larger head dilates the cervical canal, which ensures that the rest of the infant’s body can follow. In a breech delivery, however, the head emerges last and may become stuck in an incompletely dilated cervix.
In frank and complete breech deliveries, the buttocks dilate the cervix almost as well as the fetal head; therefore, emergency delivery may be able to proceed in an uncomplicated fashion. First, determine breech position and full cervical dilation. Check for prolapsed cord. Footling and incomplete breech positions are not safe for vaginal delivery due to the risk of cord prolapse or incomplete dilatation of the cervix. Immediately obtain emergency obstetric consultation for any breech presentation.
Allow the delivery to proceed spontaneously to the level of the umbilicus and do not apply traction (Figure 101­8). The legs will typically deliver spontaneously at this time, or one can insert a finger behind the knee to flex and abduct the baby’s thigh to deliver the legs. Once the umbilicus is evident, gently place your thumbs on the sacrum and gently grasp the fetal pelvis with your hands. Keep the trunk at no more than  degrees to the horizontal. You may need to kneel on the floor. Maintain or redirect the baby’s sacrum anterior. Allow each arm to deliver with slight fetal oblique rotation for each arm, and then maintain sacrum anterior position. You can have an assistant place the baby’s torso in a towel fashioned like a sling for better support.
FIGURE 101­8. A. Breech usually presents with the sacrum oblique, but most often spontaneously turns to sacrum anterior. B. Always allow spontaneous delivery to the umbilicus. If the sacrum has not rotated to the anterior position, put your thumbs on the sacrum and hands underneath on the pelvis (not abdomen) and gently rotate the sacrum anterior. C. Freeing the legs. The legs will typically deliver spontaneously. If not, grasp one leg at the popliteal fossa and sweep the leg out. Do the same with the other leg. Inset shows how to sweep the leg out laterally. D. Freeing the shoulders. Once the scapulae are evident, to turn the shoulders, grasp the sacrum and pelvis as described in B, and rotate clockwise and counterclockwise to free both shoulders. Then maintain the sacrum in an anterior position. E. To safely deliver the head, maintain cervical flexion by placing one hand on the fetal occiput and shoulders, apply flexing pressure on the occiput, and place the fingers of the other hand on the infant’s maxillae (inset) to aid in cervical flexion. An assistant can apply suprapubic pressure to the mother to maintain cervical flexion. F. The delivery is completed by sweeping the baby through an arc; the infant’s body flips over and can be placed in the mother’s arms.
To safely deliver the head, maintain cervical flexion by placing one hand on the fetal occiput and shoulders, and apply flexing pressure on the occiput; and place the fingers of the other hand on the infant’s maxillae to aid in cervical flexion. An assistant can apply suprapubic pressure to the mother to maintain cervical flexion. Maintain cervical flexion, and the baby’s body will then deliver in a large arc, with the sling providing support.
POSTPARTUM HEMORRHAGE
Postpartum hemorrhage usually occurs within the first  hours of delivery and is referred to as primary postpartum hemorrhage. The main causes of primary postpartum hemorrhage include uterine atony, retained placental fragments, lower genital tract lacerations, uterine rupture, uterine inversion, and hereditary coagulopathy. Table 101­7 lists the most common risk factors. Secondary postpartum hemorrhage occurs after the first  hours and up to  weeks postpartum. Common causes of secondary postpartum hemorrhage are failure of the
,20 uterine lining to subinvolute at the former placental site, retained placental tissue, genital tract wounds, and uterogenital infection.
TABLE 101­7
Risk Factors for Postpartum Hemorrhage
Primiparity or grand multiparity
Previous postpartum hemorrhage
Preeclampsia
Prior cesarean section
Placenta previa or low­lying placenta
Marginal umbilical cord insertion
Transverse fetal lie
Labor induction or augmentation
Cervical or uterine trauma
Fetal age <32 weeks of gestation
Fetal birth weight >4500 grams
Prolonged third stage of labor
Excessive blood loss in the postpartum period is defined as a 10% drop in the hematocrit, a need for transfusion of packed red blood cells, or volume loss that generates symptoms of hypovolemia. Normally, plasma volume increases by 40% and red blood cell volume by 25% by the end of the third trimester. The hematologic changes of pregnancy can mask the typical symptoms of hemorrhage; the first sign may be only a mild increase in pulse rate. Up to a 30% loss in total blood volume may occur before the blood pressure drops.
Most cases of postpartum hemorrhage are the results of uterine atony. Another 20% result from cervical, vaginal, or perineal lacerations.

Retention of placental tissue may account for 10%, and underlying coagulopathy is an uncommon cause. The initial resuscitative steps include aggressive fluid and blood resuscitation while identifying and treating the underlying cause (Tables 101­2 and 101­8). Nonpneumatic antishock garments can be applied in combination with fluid resuscitation and uterotonics, resulting in reduced blood loss and increased maternal
 survival in remote settings or with delayed transport.
TABLE 101­8
Common Causes and Treatment of Postpartum Hemorrhage
Cause Treatment
Tone Perform bimanual uterine massage.
Give drugs to improve uterine tone as outlined in Table 101­2. Trauma Examine for cervical, vaginal, or perineal lacerations or hematomas. Repair lacerations. Incise, drain, and appropriately ligate bleeding vessels causing a hematoma. Correct uterine inversion with manual replacement. Uterine rupture requires surgery.
Tissue Inspect the placenta for missing fragments; if a portion is absent, manually evacuate the uterine cavity. Invasive placentation may require hysterectomy. Perform transvaginal or transabdominal US to identify abnormal fluid­filled uterus. Consider a balloon tamponade with either uterine­specific balloon device (Bakri or Rüsch) or an adaptation of a Foley catheter or condom as a temporizing measure.
Thrombin Consider DIC in the setting of severe preeclampsia, sepsis, placental abruption, shock, or intrauterine fetal demise, although undiagnosed coagulopathies may rarely present in nulliparas. Replace coagulation factors.
Abbreviation: DIC = disseminated intravascular coagulation.
Uterine atony is the most common cause of postpartum hemorrhage. Risk factors include preeclampsia, protracted use of uterotonics or tocolytics, prolonged labor, multifetal gestation, fetal macrosomia, multiparity, retained placenta, and uterine infection. Initiate bimanual uterine massage; place a fist in the anterior fornix and compress the uterine fundus against the hand in a suprapubic location (Figure 101­9).
FIGURE 101­9. Treatment of uterine atony. Perform bimanual uterine massage, place a fist in the anterior fornix, and compress the uterine fundus against the hand.
[Reproduced with permission from Cunningham G, Leveno KL, Bloom SL, Hauth JC, Rouse DJ, Spong CY (eds): Williams Obstetrics, 23rd ed. © 2010. The McGraw­Hill Companies, Inc. New York, Figure 35­17.]
Retention of placental fragments or abnormal placental implantation (placenta accreta) may cause severe hemorrhage and may require emergency pelvic embolectomy, hemostatic brace sutures (B­Lynch sutures), or peripartum hysterectomy.
UTERINE INVERSION AND RUPTURE
Uterine inversion generally results from excessive force or overzealous attempts to remove the placenta in order to manage the third stage of
 labor. Inversion can also occur in patients with connective tissue disorders and uterine structural anomalies. It can be difficult to detect uterine inversion, particularly if the fundus remains cephalad to the cervix. The diagnosis can be made, however, with transvaginal or transabdominal US.
Uterine inversion requires immediate manual replacement of the uterus. A Rüsch balloon catheter can be applied to correct uterine inversion. As with
 any device, be gentle when inserting anything into an immediate postpartum uterus. The tissue is very soft, and uterine perforation is a very real risk.
Of note, the correction of uterine inversion is a very painful and difficult procedure that may require general anesthesia and tocolytic agents.
Though rare, uterine rupture carries a high risk of maternal and fetal mortality. Previous cesarean section is the primary risk factor for uterine rupture, and single­layer surgical closure of the uterus, fetal size >3500 grams, and labor augmentation increase the rate of rupture during a trial of labor. Anatomic abnormalities such as a bicornuate uterus, grand multiparity, history of connective tissue disorders, and abnormal placentation are also associated with rupture. Clinical signs of uterine rupture are persistent abdominal pain, severe vaginal bleeding, loss of fetal station, and palpable uterine defect. Fetal monitors may show fetal distress and bradycardia. The diagnosis of uterine rupture must be made clinically and rapidly.
Treatment is aggressive fluid and blood resuscitation and surgical delivery of the fetus.
AMNIOTIC FLUID EMBOLUS
Amniotic fluid embolus is a rare and often catastrophic complication of pregnancy that occurs when amniotic fluid and cells of fetal origin enter the maternal circulation during labor or delivery. Most cases occur before delivery. Fetal and maternal mortality rates are high. Amniotic fluid embolism is very difficult to diagnose. The onset of symptoms until cardiovascular collapse can range from seconds to >4 hours. Presenting signs include respiratory distress, hypoxia, pulmonary edema, altered mental status, seizures, sudden maternal cardiovascular collapse, disseminated intravascular
 coagulation, and sudden onset of fetal distress.
Postulated causes are antigenic stimuli or activation of the clotting cascade when amniotic fluid enters the maternal circulation. Physiologically, the hemodynamic changes identified on echocardiogram are the result of acute onset of severe pulmonary hypertension, right ventricular failure with leftward deviation of the septum, and the absence of pulmonary edema. Secondarily, left ventricular filling becomes impaired due to profound right
 heart failure, eventually resulting in myocardial ischemia.
Death can occur rapidly. Treatment is supportive, and there are no specific interventions currently available. The physician should prevent and/or treat hypoxia, hypotension, and hypoperfusion. Place the woman in the left lateral decubitus position to minimize vena cava compression; give oxygen by nonrebreather mask or endotracheal tube, resuscitate with fluid and blood, and administer pressors to support maternofetal circulation until emergency delivery of the fetus is performed. Obtain emergency obstetric consultation. If the gravid patient cannot be resuscitated, perimortem cesarean delivery within  minutes of cardiac arrest increases the chances of neonatal survival.
EMERGENCY CESAREAN SECTION
Perimortem cesarean section or resuscitative hysterotomy is a procedure rarely performed by emergency providers. The decision to deliver a woman while CPR is in progress is daunting. The American Heart Association 2015 guidelines advise that the decision to perform the procedure should be
 made after  minutes of CPR and the delivery should be accomplished by  minutes. These guidelines are commonly known as the 4­Minute Rule and the 5­Minute Rule. This is very difficult to accomplish. Even in the scenario of simulation on an obstetric unit with obstetric providers, timing is problematic.  Any woman receiving CPR who is ≥20 weeks’ pregnant may benefit from delivery, and it is wise to prepare beforehand if possible. To estimate gestational age, keep in mind the uterus will be at the umbilicus at about  weeks. Manually displace the uterus to the left to minimize compression of the inferior vena cava.
Ideally there should be an emergency delivery kit in the department. If not, the procedure can be performed with minimal equipment. Required items include skin antiseptic, a scalpel, scissors, suction, Kelly clamps or umbilical cord clamps, and retractors if available. Time to delivery is critical, so
 do not move the patient to another location. Apply the antiseptic solution to the abdomen. Place a drape if available. Make a vertical incision with the scalpel, starting at the xiphoid process and extending to the pubic symphysis. The lengthy incision will allow adequate exposure. The incision
 should go through the skin, fat, fascia, and peritoneum. Be careful to identify the bladder and retract it. Then carefully incise the uterus with the scalpel, with an incision large enough to accommodate two fingers. In order to protect the fetus from injury, insert two fingers through the initial incision and elevate the uterine wall off the fetus. Use the scissors to divide the uterus between the fingers, and extend the incision in a vertical fashion.
Then deliver the fetus (Figures 101­10, 101­11, 101­12). The mouth and nose should be suctioned if possible. Doubly clamp and cut the cord. If the decision to continue CPR is made, the placenta must be delivered, with gentle traction on the cord. Once the placenta is delivered, the endometrial cavity needs to be swept with a clean, moist lap pad and inspected for any residual membranes. Pitocin should be administered if possible. At this point the provider may decide to pack both the uterus and incision to allow closure by a surgeon in the operating room. However, if there is a need to close the uterus, more equipment is needed. Once the uterine cavity is empty, the uterus can be closed with the  or 1–0 delayed absorbable suture in a running fashion. The second layer of the uterine closure is usually closed in a running fashion. In some cases, a third layer may be required. The rest of
 the incision is closed in mass.
FIGURE 101­10. Midline vertical incision from xiphoid to symphysis pubis. Go through skin, fat, fascia, and peritoneum.
FIGURE 101­11. Uterine midline vertical incision. Make the uterine incision large enough for  fingers and elevate the uterine wall off the fetus with your fingers. Then use scissors to divide the uterus between your  fingers.
FIGURE 101­12. Delivering the fetus.
Acknowledgments
The authors gratefully acknowledge the contributions of Michael J. VanRooyen, Jennifer A. Scott, and Kimberly B. Fortner, coauthors of this chapter in the previous editions, and Janet Young for the chapter “Maternal Emergencies After  Weeks of Pregnancy and in the Peripartum Period” in the previous edition.


