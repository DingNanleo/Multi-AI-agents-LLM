## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 206: Antimicrobials
Nicholas J. Connors; Wallace A. Carter
INTRODUCTION
Adverse effects associated with antimicrobials occur primarily in three circumstances: side effects with therapeutic dosing, subacute to chronic effects from sustained therapeutic use, and acute toxicity resulting from excessive dosing. Side effects can be immunologic (allergic) or nonimmunologic
(pharmacologic or idiosyncratic) in nature. Antibiotics cause more reported allergic reactions than other drugs, possibly due to their high frequency of use often in a repeated and interrupted fashion. Sometimes a diluent or other chemical constituent in the formulation of a drug causes the adverse effect.
Most patients who sustain an acute antimicrobial overdose remain asymptomatic, and observation is generally all that is required. Measurement of drug levels is neither helpful nor readily available to affect management but may be confirmatory. Levels are available for several antibiotics such as chloroquine, isoniazid, and quinine. Ancillary testing should be based on the substance ingested and the clinical condition of the patient, such as
 methemoglobin concentrations for patients with dapsone or chloroquine toxicity. Some antimicrobials are associated with specific, significant toxicities following an acute ingestion and may require directed therapy (Table 206­1).
TABLE 206­1
Select Antimicrobial Toxicities and Their Specific Treatments
Drug Acute Toxicity Special Therapy for Symptomatic Overdose
Antibacterials
Penicillin Seizures (50 million units or more IV) Benzodiazepines
Amoxicillin Crystalluria, hematuria, acute renal failure IV fluid
Cephalosporins Encephalopathy, seizures Benzodiazepines
Chloramphenicol Cardiovascular collapse Hemodialysis
Fluoroquinolones Seizures Benzodiazepines
Macrolides Prolonged QT interval, torsades de pointes arrhythmia Magnesium sulfate
Sulfonamides Methemoglobinemia Methylene blue
Vancomycin “Red man syndrome” (anaphylactoid response) Slow or stop infusion, antihistamines
Antimalarials
Chloroquine Seizures, QRS­complex and QT­interval prolongation, hypotension, Epinephrine, diazepam hypokalemia
DownlQouaidneinde 2025­7­1 6:3So2d Piu m Y­pooutra IsPsi uism  c3h6an.1n4el2 b.1lo5c9k.a1d2e7, α­adrenergic antagonism, hypoglycemia, Multidose activated charcoal, sodium bicarbonate,
Chapter 206: Antimicrobials, Nicholas J. Connors; Wallace A. Carter 
(quinidine) ototoxicity, ophthalmic toxicity dextrose, octreotide
. Terms of Use * Privacy Policy * Notice * Accessibility
Primaquine Methemoglobinemia, hemolysis Methylene blue
Antituberculous medications
Isoniazid Inhibition of γ­aminobutyric acid synthesis and functional deficiency of Benzodiazepines, high­dose pyridoxine pyridoxine, seizures
Consider GI decontamination for patients suspected of ingesting a toxic amount of a potentially dangerous antimicrobial agent. Single­dose activated
,3 charcoal without sorbitol given orally or via nasogastric tube is most beneficial within  hour of the ingestion. Multidose activated charcoal is
 indicated in symptomatic patients who have ingested dapsone or quinine. Hemodialysis or hemoperfusion is effective at reducing concentrations of
,6  ,9  dapsone, chloramphenicol, cefepime, and possibly pentamidine.
Ask women of childbearing age about pregnancy and lactation when prescribing antimicrobials. LactMed is a National Library of Medicine and National
Institutes of Health database of drugs that describes maternal and infant levels of drugs and effects on breastfed infants and on lactation. Effective
June , 2015, the U.S. Food and Drug Administration published the Pregnancy and Lactation Labeling Rule, which removed pregnancy letter categories (A, B, C, D, and X) and allows for considerations of risk and benefit when prescribing medication to pregnant and nursing women. Also, see
Chapter , “Comorbid Disorders in Pregnancy,” for more detailed discussion of drugs in pregnancy.
ANTIBACTERIALS
PENICILLINS, CEPHALOSPORINS, AND OTHER β­LACTAM AGENTS
Acute overdoses of penicillins and cephalosporins mainly produce nausea, vomiting, and diarrhea but are rarely life threatening. Large doses of penicillins or cephalosporins may produce seizures through γ­aminobutyric acid inhibition, and seizures are managed by administration of
 benzodiazepines or barbiturates. Seizures resulting from intrathecal doses of penicillins or cephalosporins may require cerebral spinal fluid
 exchange for treatment. Imipenem may cause seizures in overdose or at therapeutic doses, and these are treated in the same manner. Agitation, encephalopathy, absence seizures, and nonconvulsive status epilepticus have been reported with cefazolin, ceftazidime, cefuroxime, and
,13,14 cefepime. Patients most at risk for adverse neurologic effects from β­lactams are those with renal failure, those with underlying CNS
,15 abnormalities, and those receiving high­dose therapy. Amoxicillin overdose may produce crystal­induced interstitial nephritis, hematuria, and
16–19 renal failure; treatment is supportive with IV fluids.

Amoxicillin­clavulanate can cause rare cases of cholestatic hepatitis (1 to  weeks after initiation) and pancreatitis. Treat with supportive care and
 discontinuation of the drug. Penicillins are associated with bone marrow suppression, hemolysis, interstitial nephritis, and vasculitis.

Cephalosporins are associated with serum sickness and can cause acute hemolytic crisis. Cephalosporins with the N­methylthiotetrazole side chain,
 such as cefazolin and cefotetan, can produce a disulfiram­like reaction as the side chain is released.
Two unique acute adverse reactions to procaine penicillin G are the Jarisch­Herxheimer reaction and Hoigne’s syndrome. The Jarisch­Herxheimer reaction can begin within a few hours following antibiotic treatment of Lyme disease or early syphilis. This reaction is characterized by headache,
 fever, myalgias, and rash; is usually limited to  hours; and results from antigen released from lysed bacteria. Hoigne’s syndrome begins within minutes after an intramuscular or intravascular injection of procaine penicillin G. This syndrome is characterized by extreme apprehension, fear, hallucinations, illusions, hypertension and tachycardia, and seizures. The cause of this reaction is unclear, but the effects occur in the absence of other
  signs of anaphylaxis. Amoxicillin and ceftriaxone have been reported to produce a similar reaction.
CLINDAMYCIN
The lincosamide class includes clindamycin and lincomycin, and its main acute toxicities are nausea, vomiting, and diarrhea. Although all antibiotics have been associated with depletion of normal gut flora that allows for proliferation of Clostridium difficile, clindamycin is among those antibiotics
 that carry a higher risk for this infection and the potential complications of pseudomembranous colitis and toxic megacolon. Clindamycin is also associated with two forms of liver injury: (1) transient elevations of serum aminotransferases and (2) acute idiosyncratic liver injury characterized by jaundice, alanine transaminase levels  to  times over baseline, fever, and rash. This latter form of injury usually shows minimal cell injury on liver
 biopsy and is not associated with liver failure.
FLUOROQUINOLONES
Acute overdose of fluoroquinolones rarely produces life­threatening effects. Seizures are a rare consequence of fluoroquinolone use, possibly due to

γ­aminobutyric acid inhibition or through sequestration of magnesium. There is also an association with prolongation of the QT interval and
 subsequent torsades de pointes. Fluoroquinolones are associated with acute renal failure, possibly through a hypersensitivity reaction where risk
 factors include concomitant use of renin­angiotensin–blocking agents. Crystal­induced nephropathy has been reported with therapeutic doses of
 ciprofloxacin. Caution is advised when these antibiotics are used in children due to potential musculoskeletal abnormalities with developing
 cartilage and bone, although data suggest the risk is very low. In adults, tendon rupture has been attributed to fluoroquinolone use, with levofloxacin
 accounting for more than all others combined. Discontinue the antibiotic in those who complain of painful or swollen tendons. Fluoroquinolones
 are also associated with dysglycemia, rash, serum sickness, and tinnitus.
LINEZOLID
The first member of a new class of antibiotic, synthetic oxazolidinones, linezolid inhibits monoamine oxidase and can lead to serotonin syndrome
 when used concurrently with other serotonergic medications such as selective serotonin reuptake inhibitors.
Chronic therapy longer than  days is associated with peripheral neuropathy and optic neuropathy with loss of central vision and loss of color and visual acuity. Lactic acidosis can occur, especially in patients with numerous comorbidities including sepsis and cirrhosis. Linezolid is also associated
 with anemia, thrombocytopenia and pancytopenia, and cholestatic hepatitis.
MACROLIDES AND KETOLIDES
Although the most common adverse reaction to macrolide use is GI distress, QT­interval prolongation with potential for torsades de pointes is the
,37 most important. The mechanism for this effect is blockade of the delayed rectifier potassium currents and has been noted after use of erythromycin, clarithromycin, telithromycin, and, to a lesser extent, azithromycin. Erythromycin and clarithromycin, but not azithromycin, also inhibit cytochrome P450 3A4, potentially causing drug interactions. Macrolides are also associated with high­frequency sensorineural hearing loss,
 cholestatic hepatitis, and rarely pancreatitis.
TRIMETHOPRIM­SULFAMETHOXAZOLE
These two antimicrobials work together for their antibiotic effect and are associated with many commonly reported adverse effects. Among them are allergic reactions, hematologic disorders, hypoglycemia, methemoglobinemia, rhabdomyolysis, and psychosis. Trimethoprim­sulfamethoxazole is also associated with idiosyncratic acute liver injury with a clinical pattern suggestive of a drug allergy or hypersensitivity mechanism that is particularly
 common among human immunodeficiency virus–infected patients.
VANCOMYCIN
Red man syndrome is an anaphylactoid response related to the rate of IV vancomycin infusion that can include angioedema, chest pain, dyspnea, flushing, pruritus, and urticaria. Rarely, this syndrome can also cause seizures and cardiovascular collapse. Most symptoms resolve within  minutes when the infusion is stopped. Continuing the infusion at a slower rate or with increased dilution can help decrease recurrence. Pretreatment with
 diphenhydramine is also helpful.
ANTIFUNGALS
TRIAZOLES
Antifungal agents such as fluconazole, clotrimazole, and miconazole are not expected to produce severe toxicity in acute overdose settings.
Uncommon adverse reactions such as hepatotoxicity can occur, rarely leading to liver failure and death. Liver injury is hepatocellular and can be accompanied by eosinophilia, fever, and rash. Recovery begins with stopping the drug and may take as long as  to  months. These antifungals are
 also associated with neutropenia and thrombocytopenia, and they inhibit cytochrome P450 3A4, potentiating toxicity from other pharmaceuticals.
AMPHOTERICIN B
Amphotericin B is used for progressive, life­threatening fungal infections and is rarely encountered in the ED. Acute overdoses are associated with fever, headache, nausea, vomiting, rigors, hypotension and tachycardia, anemia, dysrhythmias, electrolyte wasting, nephrotoxicity, neuropathy, and
 cardiac arrest.
ANTIMALARIALS
ATOVAQUONE­PROGUANIL
Atovaquone­proguanil (generic Malarone) is most often associated with GI distress and headache. It is quite well tolerated and is considered safe during pregnancy and breastfeeding.
CHLOROQUINE AND HYDROXYCHLOROQUINE

Chloroquine toxicity usually begins within  hours of ingestion with nausea, vomiting, and diarrhea. Cardiovascular collapse may be precipitous, with
QRS­complex prolongation and atrioventricular nodal blockade. Hypotension may be more severe than that seen with quinine overdose and is
 accompanied by respiratory depression and hypokalemia. Neurologic toxicity may include headache, obtundation, and seizures.
Aggressive supportive care is needed. A decreased mortality rate has been demonstrated in chloroquine overdose treated with early intubation, gastric lavage, deep sedation with benzodiazepines, and vasoactive pressor support with epinephrine to maintain a systolic blood pressure of 100 mm Hg
45–47
(13.3 kPa).
MEFLOQUINE
Mefloquine is used for prophylaxis or treatment of drug­resistant malaria and is associated with a variety of complications. In addition to GI distress, mefloquine is a rare cause of cardiac depression and severe CNS events, including seizures, hallucinations, and psychosis. Milder CNS effects, such as headache, insomnia, and vivid dreams, occur in up to 25% of patients. Mefloquine is not recommended as first­line therapy and is contraindicated in
 patients with seizures or psychiatric disorders.
PRIMAQUINE
Primaquine is associated with GI distress and may cause hemolytic anemia and methemoglobinemia, especially in a glucose­6­phosphate dehydrogenase–deficient population. Granulocytosis, granulocytopenia, hypertension, dysrhythmia, and neurologic depression are rare
,50 complications associated with overdose.
QUININE
The cardiac toxicity of quinine includes both sodium and potassium channel antagonism, which may result in widened QRS­complex intervals, QT
 prolongation and torsades de pointes, hypotension, syncope, and sudden death. Quinine also has significant ocular toxicity in acute overdose, and
,53 blindness may result from serum levels >10 to  micrograms/mL (31 to  micromol/L). Quinine­induced ototoxicity can produce symptoms that
 range from tinnitus to deafness. Hypoglycemia may also result from hyperinsulinemia.
Sodium bicarbonate to maintain a serum pH of .55 is the mainstay of treatment for quinine­induced cardiac toxicity while avoiding class IA, IC, and III
 antidysrhythmic agents. Quinine overdose is one of the few drugs for which multiple­dose activated charcoal is truly indicated.
ANTIPARASITICS
Most antiparasitics, such as albendazole, mebendazole, and thiabendazole, have minimal toxicity following an acute overdose, usually only producing abdominal pain, nausea, and vomiting. Levamisole, an antihelminthic that was discontinued in the United States in 1999 due to agranulocytosis, has been a common adulterant in illicit cocaine. Complications found among cocaine users stemming from the levamisole contaminant include
 leukocytoclastic vasculitis, cutaneous necrotizing vasculitis, and thrombotic vasculopathy without vasculitis.
ANTITUBERCULOUS MEDICATIONS
ISONIAZID
First­line medications used to treat both latent and active tuberculosis include isoniazid, rifampin, ethambutol, and pyrazinamide. Of these, isoniazid
,57 is associated with high morbidity and mortality in overdose. At therapeutic doses, adverse effects from isoniazid include neuropathy and hepatic injury.
The clinical symptoms of acute isoniazid overdose typically begin with nausea, mental status changes, and ataxia, which may be seen as early as  minutes after ingestion. These symptoms may progress to the three classic features of acute isoniazid overdose: seizures, metabolic
,59 acidosis, and protracted coma. Seizures typically follow acute isoniazid ingestions of greater than  to  milligrams/kg. Isoniazid­induced seizures are generalized tonic­clonic in nature and are often refractory to standard anticonvulsive therapy with benzodiazepines and barbiturates. The mechanism for isoniazid­induced seizures is a functional deficiency of pyridoxine (vitamin B ) and inhibition of the synthesis of γ­aminobutyric acid,

 the primary CNS inhibitory neurotransmitter. Seizures with therapeutic doses of isoniazid have been reported, presumably due to very low vitamin

B levels. Although the metabolic acidosis that accompanies isoniazid­induced seizures is likely due to motor activity, the lactic acidemia may not
 resolve as rapidly as with other more typical epileptic seizures.

Consider isoniazid overdose in patients with refractory seizures. Isoniazid­induced seizures are treated with a combination of
 benzodiazepines and pyridoxine. The dose of pyridoxine is a gram­for­gram equivalent to the amount of isoniazid ingested. For patients who ingest an unknown quantity of isoniazid, the recommended dose of pyridoxine is  grams IV in adults and  milligrams/kg (maximum  grams) in pediatric patients. Pyridoxine should be administered at a rate of approximately  gram IV every  to  minutes until the seizures stop or the maximum dose has been given. After the seizures have ceased, the remainder of the pyridoxine dose should be given over the following  to  hours to limit recurrent seizures. If seizures persist after the full dose has been given, it may be repeated.
Adequate single­dose therapy of pyridoxine should be effective to stop most seizures, but patients who do not receive adequate pyridoxine dosing may have repeat seizures. Pyridoxine may also assist in reversing isoniazid­induced coma. Hospitals where tuberculosis is endemic should ensure that
 an adequate supply of IV pyridoxine is maintained to treat overdoses. If only pyridoxine tablets are available, they may be crushed and administered by nasogastric tube.
Phenytoin has no role in treating seizures originating from isoniazid overdose, and there is little role for sodium bicarbonate treatment of the metabolic acidosis resulting from isoniazid toxicity. Because most isoniazid­induced toxicity occurs within  hours of ingestion, patients who remain asymptomatic for  hours after ED presentation are safe for medical clearance.
OTHER ANTITUBERCULOSIS AGENTS
Other antituberculous medications are associated with a variety of adverse reactions of a milder nature. Ethambutol toxicity is also primarily GI in nature but additionally may cause unilateral or bilateral ocular toxicity including blurred vision, disruption of color perception, and loss of peripheral
 vision. Rifampin infrequently causes severe toxicity and is most often associated with GI symptoms. Acute toxicity has been associated with flushing, angioedema, and neurologic effects including numbness, extremity pain, ataxia, and weakness. Rifampin has been presumptively implicated in
 producing acute kidney injury with proteinuria. Pyrazinamide is not associated with any toxic effects following an acute overdose.
ANTIVIRAL/RETROVIRAL MEDICATIONS
Common side effects from oseltamivir, used for the treatment of influenza, are nausea, vomiting, diarrhea, dizziness, and headache. Oseltamivir is
 associated with QT prolongation, but there is no evidence the drug causes torsades de pointes or should be avoided in patients with congenital long

QT syndrome. Oseltamivir can cause acute neuropsychiatric effects including depression, agitation, and hallucinations within  hours of the first
,68 dose.

In the treatment of human immunodeficiency virus, protease inhibitors as a class can cause QT prolongation and nephrolithiasis, whereas reverse
  transcriptase inhibitors can cause lipodystrophy and lactic acidosis. For patients being induced to or taking buprenorphine, the University of
California, San Francisco (http://hivinsite.ucsf.edu/) maintains a list of antiretrovirals that affect buprenorphine levels.
Methadone also has important interactions with antiretrovirals, mostly requiring methadone dose increases. Check available databases or infectious disease specialists for specific information.


