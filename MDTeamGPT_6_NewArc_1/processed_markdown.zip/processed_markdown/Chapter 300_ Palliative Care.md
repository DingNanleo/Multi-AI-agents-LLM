## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 300: Palliative Care
Justin K. Brooten
INTRODUCTION
The goal of palliative care is to relieve the suffering of patients with serious illness. Regardless of the patient’s prognosis, relief of suffering should be a
 primary goal for both emergency medicine and palliative care. Palliative care is defined by specialty advocates as the physical, spiritual, and
 psychosocial care given by multiple disciplines to patients and their families who are living with life­threatening illness. Although these principles are applicable to all stages of a patient’s illness, a palliative care consultation from the ED is generally considered in the context of previously predicted end­of­life care. Hospice care, a branch of palliative care, is a comprehensive program of palliative treatment that is appropriate when patients with chronic, progressive, and eventually fatal illness are determined to have a life expectancy of  months or less. Palliative care is patient centered rather than disease centered. It strives to ensure that the patient or his or her (formal or informal) representatives have chosen realistic goals of care after the patient’s diagnosis, prognosis, and therapeutic options have been considered. This discussion and decision making should take place during a meeting that includes the patient’s healthcare team, surrogate decision maker(s), and those loved ones who are privileged to receive information.
Palliative care is guided by the axiom that distressing symptoms should be treated. It thus provides expert assessment and treatment of symptoms, including pain, dyspnea, and vomiting. Pain is the most common reason for seeking care in the ED, accounting for 58% to 78% of visits in the United
3­5 
States. Unfortunately, only 60% of patients reporting pain receive pain medications. Dyspnea is the seventh most common chief complaint and
 vomiting the ninth most common chief complaint of patients presenting to the ED.
Palliative care also trains healthcare professionals to compassionately communicate diagnosis, prognosis, and treatment alternatives and guide the formulation of a therapeutic plan. Palliative care clinicians work to coordinate caregivers and interventions for the patient and family, to make care more effective, and to lessen the stress and obstacles for achieving satisfactory outcomes. Standards for compassionate care spelled out by the

Institute of Medicine and numerous professional societies require that distressing symptoms be alleviated concurrently with all treatments directed toward the pathology of the medical disorder. The patient or surrogate must play a key role in decisions regarding care.
The first American Board of Medical Specialties board exam, administered in 2008, qualified the first emergency medicine physicians for practice of the
 subspecialty of hospice and palliative medicine.

In 2014, the American College of Emergency Physicians reaffirmed its 2008 policy statement: Ethical Issues and End­of­Life Care (Table 300­1).
In 2011, the Center to Advance Palliative Care (the primary advocate for palliative care in the United States) released its Improving Palliative Care in
Emergency Medicine project. This project informs and enables EDs to develop thoughtful, creative, and streamlined programs to integrate palliative
 care into the day­to­day operation of the ED.
TABLE 300­1
The American College of Emergency Physicians Board of Directors: Ethical Issues at the End of Life
The American College of Emergency Physicians believes that:
Emergency physicians play an important role in providing care at the end of life (EOL).
Helping patients and their families achieve greater control over the dying process will improve EOL care.
Advance care planning can help patients formulate and express individual wishes for EOL care and communicate those wishes to their healthcare providers by means of advance directives (including state­approved advance directives, do not attempt resuscitation orders, living wills, and durable powers of attorney for health care).

Chapter 300: Palliative Care, Justin K. Brooten 
To enhance EOL care in the ED, the American College of Emergency Physicians believes that emergency physicians should:
. Terms of Use * Privacy Policy * Notice * Accessibility
Respect the dying patient’s needs for care, comfort, and compassion.
Communicate promptly and appropriately with patients and their families about EOL care choices, avoiding medical jargon.
Elicit the patient’s goals for care before initiating treatment, recognizing that EOL care includes a broad range of therapeutic and palliative options.
Respect the wishes of dying patients including those expressed in advance directives. Assist surrogates to make EOL care choices for patients who lack decision­making capacity, based on the patient’s own preferences, values, and goals.
Encourage the presence of family and friends at the patient’s bedside near the end of life, if desired by the patient.
Protect the privacy of patients and families near the end of life.
Promote liaisons with individuals and organizations in order to help patients and families honor EOL cultural and religious traditions.
By implementing principles of palliative care (Table 300­2), emergency physicians will become better skilled at assessing patients’ preferences and health status to determine whether initiating aggressive therapy is both concordant with the patients’ or surrogates’ preferences and potentially beneficial. Patients already receiving a palliative care approach will be able to have their existing care plan continued in a coordinated fashion when
 presenting to the ED for worsening symptoms, although they would be more optimally managed as outpatients.
TABLE 300­2
Description of Palliative Care in Emergency Medicine
Who: Patients with serious, potentially life­threatening illness and their families.
What: Relief of symptoms from potentially curable conditions in the presence of chronic devastating disease when standard treatment impedes the patient’s remaining quality of life, to incurable conditions such as stage IV heart failure, metastatic lung cancer, or advanced dementia.
When: After a life span–limiting prognosis has been defined or when requested by patients and their families to enhance the patient’s quality of life.
Late­stage palliative care for incurable illnesses with a prognosis estimated of  mo or less is provided in the United States under the hospice benefit of Medicare.
Where: In the ED and every other setting in which the patient receives care, or wishes to receive care, such as at home.
Why: Because the relief of suffering is the primary goal of medicine, and there are few places with greater patient suffering than in the ED.
How: The patient and/or family decide the goals of care after a realistic discussion based on diagnosis, prognosis, and effectiveness of potential therapies. An interdisciplinary team consisting of at least the doctor and nurse provides care measures, such as symptom relief, and initiates the coordination of care needed to reach the patient’s goals. Most commonly, this occurs in consultation with a palliative care service, unless the emergency physician is trained in palliative care.
Who Decides: The patient, provided he or she retains decision­making capacity, or the surrogate decision maker, the legally appointed Durable
Power of Attorney for Healthcare or closest family relative who speaks for the patient.
EPIDEMIOLOGY
In 2016 in the United States, the proportion of medical decedents who received hospice prior to death ranged from 23% in Puerto Rico to 58% in

Utah. Although hospice was initially designed for cancer patients, .8% of patients enrolled in hospice in 2016 had a noncancer diagnosis.

Eighteen percent of hospice patients’ death diagnosis is dementia.

In 2002, there were .7 million people aged >65 years in the United States. In 2030, there will be >72 million elderly people. The Hospitalized
Elderly Longitudinal Project study found that the very elderly (>80 years) are most likely to want and to consider comfort care as the best option
 when facing serious chronic illness. The surge in growth in the aging population will increase the demand for quality palliative care.
Approximately 30% of healthcare costs occur in the last  months of life. Data from the Health and Retirement Study showed that 51% of patients over
 age  visit the ED during their last month of life, 77% of those are admitted to the hospital, and 68% of those admitted die during their hospital stay.
A meta­analysis found that the use of hospice saved as much as 40% of healthcare costs during the last month of life and 17% over the last  months of
  life. A subsequent study found that hospice care reduced Medicare costs during the last year of life by an average of $2309 per hospice user.

Admitting eligible patients to hospice is one promising route for addressing the quality/cost chasm.
20­22
Currently, only 4% to 7% of hospitalized patients are referred to palliative care or hospice directly from the ED. The average time in the hospital
,22 before transfer to a palliative care bed is  to  days.
IDENTIFYING PATIENTS FOR PALLIATIVE CARE
In 2011, the Center to Advance Palliative Care released its Improving Palliative Care in Emergency Medicine program, a program that provides a thoughtful approach to palliative care practice in the ED, formulated for and by emergency clinicians. The program covers all aspects of palliative care
  in the ED. Emergency physicians have enthusiastically received the Improving Palliative Care in Emergency Medicine program, despite expressing concerns about the challenges facing them when discussing palliative or hospice care with patients such as interruption of workflow, lack of long­term
 relationships with patients, and lack of training to facilitate interactions.
Patients whose long­term care needs are complex and require skilled nursing care for transfusions, tracheostomy care, or infusions of antibiotics or inotropes are likely in need of palliative care, especially if the disease is progressive. In one study, 54% of patients transported to the ED from a long­
 term care facility as a level  triage priority were dead in  days.
FUNCTIONAL DECLINE
Functional decline is the loss of the ability to care for oneself. This ranges from the loss of complex abilities, like driving, shopping, and managing finances, to basic activities like ambulating to the bathroom and getting safely out of bed. The loss of activities of daily living is the cardinal feature of decline, especially if accompanied by unintentional weight loss, and it indicates the need for increased care assistance and suggests a short life expectancy.
PROGNOSIS
Space in this textbook does not allow for a comprehensive discussion of formulating a prognosis and how to share it with patients and families. There are several key diagnoses and prognostic findings that are extraordinarily helpful to understand. Patients with chronic, progressive, life­threatening diagnoses will almost always benefit from palliative care. Those with extensive disease, be it metastatic cancer, organ failure, or neurologic
 deterioration (with anorexia/cachexia and decreased self­care), are frequently on a dying trajectory. Examples of diagnoses of patients who may
 benefit from palliative care are listed in Table 300­3. A predictive instrument known as the Palliative Prognostic Score correlates with prognosis.
Elements of the Palliative Prognostic Score include ability to ambulate, provide self­care, and maintain oral intake and level of consciousness. A bedbound patient completely dependent for all care with reduced oral intake and a diminished level of consciousness has a Palliative Prognostic Score of

10% and a 1­week median expected survival.
TABLE 300­3
Common Diagnoses and Key Findings of Patients Who May Benefit From Palliative Care
Diagnosis Key Findings
Solid organ neoplasm Widespread metastasis unresponsive to treatment
End­stage heart failure Significant symptoms at rest despite therapy
End­stage COPD Significant symptoms at rest despite therapy
Advanced dementia Impaired mobility and inability to communicate health needs
Degenerative neurologic disease Inability to complete ADLs or communicate health needs
End­stage AIDS Multiple opportunistic infections and/or AIDS dementia
End­stage renal disease Patient no longer willing or able to undergo dialysis
End­stage liver disease Repeated episodes of hepatic encephalopathy, bleeding, or symptomatic ascites resistant to medical therapy
End­stage rheumatologic disease Inability to complete ADLs without significant discomfort
Multisystem trauma Nonsurvivable injury
Burn When age plus percent burn exceeds or nears 140
Multiorgan failure When two or more key body systems fail
Any chronic, progressive, debilitating Whenever symptom burden exceeds resources and the ability of the patient and/or family to cope with disease medical condition
Abbreviations: ADLs = activities of daily living; AIDS = acquired immunodeficiency syndrome; COPD = chronic obstructive pulmonary disease.
DISCUSSING PROGNOSIS AND SETTING THE PLAN OF CARE
DETERMINING PATIENT DECISIONAL CAPACITY AND IDENTIFYING SURROGATE DECISION MAKERS
The ED team should immediately identify the decision makers when a debilitated patient arrives in crisis to the ED. A patient with decisional capacity is one who has the mental ability to grasp and retain information about his or her condition, weigh risks and benefits, and
 demonstrate these abilities by verbalizing a medical decision (see Chapter 303, “Legal Issues in Emergency Medicine,” for a more detailed
 discussion of patient capacity). Table 300­4 lists phrases to aid meaningful communication with patients and families. If the patient lacks decisional capacity, then the patient’s advance directive should be accessed and the named surrogate decision maker should be contacted as soon as possible. If none of these resources are available, then the closest family member(s) should be consulted regarding the plan of care. If no one is available to speak for the patient, then the treating physician should act in the patient’s best interest. This may include an order to “do not resuscitate” the patient if it is clear that aggressive therapy would not be beneficial.
TABLE 300­4
Key Communication Phrases28
Determining Patient Decision­Making Capacity
Will you describe your current condition?
Tell me about the treatment options we have just discussed.
Explain to me why you feel that way.
Quality of Life
What symptoms bother you the most? What concerns you the most?
Prognosis
Has anyone talked to you about what to expect?
Do you have any sense of how much time is left? Is this something you would like to talk about?
Talking With Surrogate Decision Makers
These decisions are very hard; if [the patient] was sitting with us today, what do you think [he/she] would say?
Can you tell me why you feel that way?
It is not a question of whether we care for [your loved one], but we will care for them.
Then we will do everything possible to keep [your loved one] comfortable, but we won’t be providing ineffective and burdensome therapies such as
CPR or intubation.
Discussing Palliative Care or Hospice Referral
To meet the goals we’ve discussed, I’ve asked the palliative care team to visit with you; they are experts in treating the symptoms you are experiencing. They can help your family deal with the changes brought on by your illness.
Breaking Bad News—Death Pronouncement
I wish there is more we could have done; I’m very sorry for your loss. This has to be really difficult for you. Is there anyone I can call to be with you now?
FAMILY MEETING
Once the physician has determined the patient’s decision­making capacity, chronic health status, a clinical diagnosis for the current visit, and a general understanding of the patient’s care preference, the doctor and team are prepared to have an abbreviated family meeting with the decision maker(s) to discuss the approach to care. The physician must be clear in his or her own mind whether there is any available therapy that will restore the patient’s health; have access to the advice of consultants, specialists, and the patient’s primary care physician; and be prepared to issue honest, compassionate, and helpful recommendations based on his or her own assessment.
Realistic Prognosis and Values Discussion
A productive approach to start such meetings is to ask the surrogate decision maker what he or she understands about the patient’s past health and current condition (Table 300­4). After patiently listening, the physician should share his or her insight into the patient’s condition and prognosis while monitoring the family’s reaction to determine whether the ED team and the family are in agreement. An example of a physician’s opinion in a particular case follows: “Your mother’s advanced medical condition cannot be cured, and her illness has made her defenseless against the bacteria in her own body. Treating her again and providing another round of intensive care will not bring her health or immune system back to normal, but may only prolong her suffering.”
The next step is to ask the surrogate decision makers whether they know about the patient’s values and preference for care, for example, how their mother would wish to be treated in the current circumstances. If the answer to that is unknown, ask how the surrogate decision makers would wish to be treated if they were in the same condition.
Separate Desired Outcome From Likely Outcome
Carefully explore discrepancies in the perception of what might be gained from aggressive therapy in patients who are less likely to benefit from such care. Delivering realistic information about the likely outcome and the expectation of poor quality of life significantly impacts subsequent decisions for
 code status or scope of treatment in a patient with an underlying progressive terminal condition. Patients or surrogates who are aware of poor
,31 prognosis and low likelihood of survival from CPR often choose against aggressive therapy or resuscitation. Patients and surrogates may decide to forgo aggressive care if a small potential for survival from an acute event would likely result in a loss of significant function or would necessitate
 constant skilled nursing care for the foreseeable future. Painting a clear picture in lay terms of what the future may hold if various avenues of care are
 chosen may be a much more effective means of conveying the gravity of choice between various options.
Cultural Differences
Cultural differences should be taken into account when discussing treatment options with patients and families, including religious preferences.

African Americans are more likely to select aggressive treatment options and less likely to select hospice care than non­Hispanic whites. Reasons cited for end­of­life preferences among African Americans facing these decisions include historical mistrust toward the healthcare system and the
 importance of spirituality.
CODE STATUS
Do not resuscitate is part of advance healthcare directives. Do not resuscitate status or other limitations of resuscitation should evolve directly from harmonious decisions reached at the family meeting. Do not resuscitate orders and advance directives are discussed in Chapter 301, “Death
Notification and Advance Directives.”
CONSULTATION OPPORTUNITIES
Palliative care consultation services are likely available at your hospital and should be used just as you would any specialist consultation. ED consultation can provide assistance when conducting a family meeting or when access to an inpatient hospice or palliative care unit is needed. When symptom relief, medical decision making, or disposition and coordination of care are beyond your expertise or available time, a consult is appropriate.

Notify the patient’s attending physician of the consultation if time allows.
TREATMENT AND SYMPTOM MANAGEMENT
The most common targets of symptom management are pain control, dyspnea, nausea/vomiting, constipation, and agitation.
PAIN CONTROL
Acute and chronic pain are addressed elsewhere in detail (Chapters  and , respectively). The biggest obstacle to aggressive pain management with opiates has been the fear of respiratory depression. Opioid dosing is reviewed in Chapter , “Acute Pain Management,” and is an essential skill in the practice of emergency medicine. It is also important to understand the progression of side effects from opioids, because these will serve as warnings to reduce the dose or delay the next dose of opioids. Respiratory depression is not a sudden occurrence, but instead is part of a progression that starts
 with sedation, somnolence, and then respiratory depression. The safety of patient­controlled analgesic devices is predicated on this concept. A patient can be safely dosed and redosed until the pain is palliated, as long as level of consciousness is monitored. IV opiates reach maximum therapeutic levels and have peak effects or side effects at  to  minutes. Therefore, IV pain medications can be safely redosed every  minutes until relief is reached if potential adverse effects are monitored.
DYSPNEA
While identifying the cause of dyspnea and treating the underlying pathology may bring definitive relief, treatment should also be offered to palliate the symptoms. Although opioids have traditionally been withheld due to concerns about respiratory depression, opioids are beneficial in treating the
 agitation and anxiety provoked by dyspnea. When treating breathlessness/dyspnea in an opioid­naive patient, start with morphine at a dose of .05 milligram/kg IV, and monitor for sedation and hypoventilation. This is half of the starting dose of morphine when it is used to treat pain. Use a goal of maintaining a respiratory rate of at least  to  breaths/min.
NAUSEA AND VOMITING
Understanding the underlying cause of nausea can help identify the class of antiemetic drugs most likely to be therapeutic. Chemotherapy­induced nausea often responds to high doses of serotonin 5­hydroxytryptamine­3 antagonists such as ondansetron. Corticosteroids such as dexamethasone also may improve nausea from chemotherapy. Steroids can also improve symptoms caused by increased intracranial pressure and bowel obstruction from cancer. Dopamine antagonists such as haloperidol or droperidol are used for refractory nausea in the palliative care setting. Metoclopramide is excellent for the symptoms of diabetic gastroparesis or compression of the stomach due to tumor or ascites.
CONSTIPATION
Constipation is a commonly seen side effect in patients on opiates for pain control. Patients prescribed opiates need a concurrent bowel regimen, such as an osmotic agent (i.e., polyethylene glycol) or stimulant laxatives. A digital rectal exam is also important to rule out a suspected fecal impaction.
When evaluating a patient for constipation, an abdominal radiograph can help to evaluate the amount of stool and lower the index of suspicion for bowel obstruction.
AGITATION
Patients with terminal illness may become agitated, with or without delirium. The causes of this agitation are multifactorial, including pain, effects of the terminal illness, anxiety, terminal restlessness, breathlessness, and mental anguish. The indicated class of medications varies depending on the situation but includes antipsychotics such as haloperidol, anxiolytics such as midazolam, and opiates such as morphine. There is no evidence that
 these palliative interventions hasten death.
DISPOSITION AND COORDINATION OF CARE
Although the majority of patients consulted to palliative care services from the ED will be admitted to the hospital, outpatient treatment is always an option, depending on the resources available and the patient’s needs.
HOSPICE REFERRALS
Patients who qualify for the hospice benefit should be aware of these outstanding programs of care for the physically declining patient. Inpatient
 hospice units, where patients can be directly admitted, provide a good option for care and rapid ED disposition if available at your hospital. Not all families are eager to hear the word “hospice,” but such a recommendation should be phrased in a way that sends a message about your concern for the patient and his or her health status. Exploring any prior experience a patient or family may have had with hospice care and determining their primary goals and explaining how those goals might align with hospice can be an effective way to introduce a potential transition in care.
Patients are eligible for hospice care by Medicare regulations if they wish to take a palliative approach to their condition and if they have a prognosis that, in the judgment of two physicians, is likely ≤6 months, given the usual and natural course of the illness. Hospice referrals can be made from the ED for patients with qualifying debilitating illnesses, such as dementia with sepsis or stage IV cancer with poor performance status. Referrals also can be made for patients with clearly expressed prior wishes for comfort care should they sustain a catastrophic acute illness, such as those with an intracerebral bleed, infarcted bowel, devastating neurotrauma, or renal failure in the presence of advanced heart failure, leading to multiorgan failure.
SPECIAL TOPICS
IMMINENT DEATH
It is common in the ED to receive a patient whose death is likely imminent. Such a patient has entered the process of multiorgan failure due to a disease such as sepsis, vascular crisis, uremia, or metastatic cancer. Vital signs indicate a patient in extremis; breathing may be irregular with pauses; a Foley catheter finds an empty bladder or only a small amount of concentrated urine. The assessment that a patient’s death is imminent should be communicated to family members and the primary care physician. Agreement should be sought to offer comfort measures only. Intermittent or infused opiates plus intermittent or infused midazolam should be initiated and titrated to patient comfort. Delirium therapy can be directed to underlying cause (pain, fever) or, if not known or reversible, treated with .5­ to 5­milligram doses of IV haloperidol. A total dose of  milligrams can produce a calming effect on a patient and, by extension, his or her family. Especially in patients who are having respiratory symptoms, opiates should be considered even though they may induce hypoventilation. Explain to a patient’s family that the goal of opiate therapy is not intended to artificially hasten death but to ensure comfort. There is firm ethical support for providing medication expressly with a goal of comfort even if there is potential for
,41 an unintentional double effect.
OPIOID DOSING AND ROTATION
In the opioid­naive (hydrocodone, oxycodone, morphine, hydromorphone, and methadone) patient, a 2­milligram dose of IV morphine or a .5­ to 1­ milligram dose of hydromorphone is a reasonable starting dose. This should be administered every  minutes until the pain is relieved by approximately 50%. Dose stacking will produce additional, cumulative effects when the doses have all been distributed to the µ­receptors. In the opioid­tolerant patient, the average 4­hourly dose of opioids already prescribed should be doubled for severe pain and increased by 50% for
 moderate pain (pain scale score of  to 6). Smaller doses are required in elderly patients, those with a low body mass index, patients with unstable vital signs, or those with baseline severe cardiorespiratory compromise (e.g., chronic obstructive pulmonary disease) because such patients are at risk for hypoventilation.
CARE OF THE PREVIOUSLY DESIGNATED HOSPICE PATIENT IN THE ED
Occasionally, hospice patients may be directed to the ED. The three most common scenarios are (1) a hospice patient with an acute symptom crisis; (2) a hospice patient who has a health concern unrelated to the hospice diagnosis; or (3) a patient who has previously revoked and signed out of hospice and presents to the ED.
A patient enrolled in hospice may be hospitalized under the care of hospice (general inpatient hospice) if there is an acute symptom crisis related to the hospice diagnosis. An inpatient setting can allow for more aggressive treatment of symptoms such as a pain crisis, new­onset dyspnea, or other concerning symptoms. A patient may also be sent to the ED for a new medical issue unrelated to the hospice diagnosis. For example, a patient admitted to hospice for refractory heart failure may fall and fracture a bone. The fracture is unrelated to the hospice issue.
A patient may revoke hospice care at any time for any reason and may present to the ED for aggressive treatment rather than a palliative approach.
Occasionally, a patient or family may panic and call 911 when there is a change in the patient’s health status. The ED physician should care for the patient as appropriate. It can be very helpful to contact the patient’s hospice agency. Someone should be available  hours a day and may be very useful in helping to clarify the patient’s goals and disposition.
Acknowledgments
The author would like to thank Robert Zalenski and Erin Zimny for their contributions to the last edition of this chapter.


