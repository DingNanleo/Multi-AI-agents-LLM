## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 76: Lower Gastrointestinal Bleeding
Bruce Lo
Content Update: Oakland Score as risk tool for LGI Bleeding July 2020
The Oakland Score has been validated in a retrospective study of ,128 patients at 140 US hospitals. A score of ≤  has a sensitivity of .4% and specificity of 16% for safe discharge of patients with LGI bleeding. Although the Oakland score can help risk stratify patients with LGI bleeding for discharge, clinical judgement along with shared decision making should be used for final disposition. See the risk score and discussion under
Disposition and Followup.
INTRODUCTION AND EPIDEMIOLOGY
Historically, lower GI bleeding is the loss of blood from the GI tract distal to the ligament of Treitz. However, management and outcomes differ if the
 bleeding originates from the small intestine compared with the colon. Nevertheless, lower GI bleeding is a common problem in emergency medicine and should be considered potentially life threatening until proven otherwise.

Lower GI bleeding occurs more often than upper GI bleeding, with an annual incidence of approximately 109 per 100,000 and a mortality of <1%.
Because blood must travel through the upper GI tract down to the lower GI system, upper GI bleeds are the most common source for all causes of blood detected in the lower GI system. Among patients with an established lower GI source of bleeding, the most common cause is
 diverticular disease, followed by colitis, hemorrhoids, and adenomatous polyps/malignancies.

About 80% of episodes of lower GI bleeding resolve spontaneously. However, one cannot predict which episodes will spontaneously resolve or which episodes will result in complications. This is partly due to the difficulty in establishing a pathophysiologic diagnosis. In one study, a cause for bleeding
 was found in <50% of the cases.
PATHOPHYSIOLOGY
Hematochezia is either bright red or maroon­colored rectal bleeding. If hematochezia originates from an upper GI source, it indicates brisk upper GI bleeding, which may be accompanied by hematemesis and hemodynamic instability. Approximately 10% of hematochezia episodes may be associated
 with upper GI bleeding. Melena is dark or black­colored stools and usually represents bleeding from an upper GI source (proximal to the ligament of
Treitz) but may also represent slow bleeding from a lower GI source.
DIVERTICULOSIS
Diverticular bleeding is usually painless and results from erosion into the penetrating artery of the diverticulum. Diverticular bleeding may be massive,
,8 but up to 90% of episodes will resolve spontaneously. Bleeding can recur in up to half of patients. Although most diverticula are located on the left
 colon, right­sided diverticula are thought to be more likely to bleed. Elderly patients with underlying medical illnesses, those with increased needs for
 transfusion, and those taking anticoagulants or NSAIDs have increased morbidity and mortality.
VASCULAR ECTASIA
Vascular ectasia, which includes arteriovenous malformations and angiodysplasias of the colon, is a common cause of lower GI bleeding. Vascular
 ectasia can also be present in the small bowel and is difficult to diagnose. The development of vascular ectasia in the large bowel seems to be due to a
Chapter 76: Lower Gastrointestinal Bleeding, Bruce Lo chronic process and increases with aging. Inherited conditions can also give rise to arteriovenous malformations. There is also a suggestion that
. Terms of Use * Privacy Policy * Notice * Accessibility
 valvular heart disease is a risk factor for developing bleeding vascular ectasias, although this is an area of debate.
ISCHEMIC COLITIS AND MESENTERIC ISCHEMIA
Ischemic colitis is the most common cause of intestinal ischemia and is usually transient. The colon is predisposed to ischemia because of its poor vascular circulation and high bacterial content. Aneurysmal rupture, vasculitis, hypercoagulable states, prolonged strenuous exercise, cardiovascular insult, irritable bowel syndrome, and certain medications that cause vasoconstriction or slow bowel motility are known risk factors. Diagnosis is
 usually made by endoscopy. Although most cases will resolve on their own, some patients require surgical intervention.
Mesenteric ischemia can lead to bowel necrosis. Causes include thrombosis or embolism of the superior mesenteric artery, mesenteric venous thrombosis, and nonocclusive mesenteric ischemia associated with low arterial flow with vasoconstriction. Diagnosis is difficult, and the presentation can mimic other intra­abdominal pathologies. Diagnosis requires a high index of suspicion, especially in patients >60 years old and in those with atrial fibrillation, congestive heart failure, recent myocardial infarction, postprandial abdominal pain, or unexplained weight loss. CT has a specificity of 92% but a sensitivity of only 64%. Angiography remains the diagnostic study of choice. Despite aggressive treatment, prognosis is poor, with a survival of

50% if diagnosed within  hours.
MECKEL’S DIVERTICULUM
Meckel’s diverticulum consists of embryonic tissue, most commonly found in the terminal ileum. More than half of lesions contain ectopic gastric tissue, which can secrete gastric enzymes, eroding the mucosal wall and causing bleeding. It is a rare but important condition, especially in the younger population.
HEMORRHOIDS

Although hemorrhoids are the most common source of anorectal bleeding, massive hemorrhage is unusual. Bleeding is usually associated with bowel movements and is usually painless. Diagnosis can sometimes be made at the bedside as a cause for lower GI bleeding. For further discussion of hemorrhoids, see Chapter , “Anorectal Disorders.”
OTHER CAUSES OF LOWER GI BLEEDING
Numerous other lesions may result in lower GI hemorrhage (Table 76­1), including infectious colitis, radiation colitis, rectal ulcers, trauma, and inflammatory bowel disease. Polyps and carcinomas can cause lower GI bleeding and are usually a source of chronic anemia. Delayed hemorrhage can occur up to  weeks after polypectomy. Patients with left ventricular assist devices are prone to GI bleeding especially due to anticoagulation, risk of
 arteriovenous malformations, and acquired von Willebrand’s disease.
TABLE 76­1
Causes of Lower GI Bleeding
Upper GI bleed
Diverticulosis
GI carcinoma
Angiodysplasia
Arteriovenous malformations
Mesenteric ischemia
Ischemic colitis
Meckel’s diverticulum
Hemorrhoids
Infectious colitis
Inflammatory bowel disease
Polyps
Radiation colitis
Rectal ulcers
Trauma
Foreign bodies
Carcinoma
Prostate biopsy sites
Endometriosis
Dieulafoy lesions
Colonic varices
Portal hypertensive enteropathy
DIAGNOSIS
As with any emergency, the medical history, physical examination, and diagnostics often must be accomplished simultaneously with resuscitation and stabilization. Factors associated with a high morbidity rate are hemodynamic instability, repeated hematochezia, gross blood on initial rectal examination, initial hematocrit <35%, syncope, nontender abdomen (predictive of severe bleeding), history of diverticulosis or angioectasia, elevated creatinine, aspirin or NSAID use (predictive of diverticular hemorrhage), and more than two
,3,13 comorbid conditions.
HISTORY
Although most patients will volunteer complaints of hematochezia or melena, signs and symptoms of hypotension, tachycardia, angina, syncope, weakness, or altered mental status can all occur as a result of lower GI bleeding.
Ask about previous GI bleeding as well as a history of pain, trauma, ingestion or insertion of foreign bodies, and recent colonoscopies. Weight loss and changes in bowel habits may suggest malignancy. A history of an aortic graft may suggest the possibility of an aortoenteric fistula. Medications, such as antiplatelets (e.g., salicylates, clopidogrel), NSAIDs, and anticoagulants (e.g., warfarin, rivaroxaban, apixaban), increase the risk of lower GI
,14­16 bleeding. Ingestion of iron or bismuth can simulate melena, and certain foods, such as beets, can simulate hematochezia. However, stool guaiac testing in those cases will be negative.
PHYSICAL EXAMINATION
Hypotension and tachycardia, or decreased pulse pressure or tachypnea, develop with significant bleeding. However, changes in vital signs may be masked by concurrent medications, such as β­blockers, or medical conditions, such as poorly controlled hypertension. Thus, relative tachycardia and hypotension may represent subtle clues to ongoing bleeding. Some patients can tolerate substantial volume losses with minimal or no changes in vital signs.
Cool, pale skin and an increase in capillary refill can be signs of shock. Physical findings of liver disease, as well as petechiae and purpura, suggest an underlying coagulopathy. The abdominal examination may disclose tenderness, masses, ascites, or organomegaly. In patients with lower GI bleeding, a lack of abdominal tenderness suggests bleeding from disorders involving the vasculature, such as diverticulosis or angiodysplasia. Inflammatory bowel disorders with lower GI bleeding are associated with abdominal tenderness on examination.
Thorough examination of the rectal area may reveal an obvious source of bleeding, such as a laceration, masses, trauma, anal fissures, or external hemorrhoids. A vaginal or urinary source of bleeding mistaken for a GI source will be identified by examination and testing. Perform a digital rectal examination to detect gross blood (either bright red or maroon) and for guaiac testing. Rectal examination can also detect the presence of masses.
Anoscopy can also be performed at the bedside. A source of bleeding such as hemorrhoids can sometimes be elucidated by anoscopy. However, blood
 originating beyond the level of visualization should raise the suspicion for other causes.
LABORATORY TESTING
The most important laboratory tests are the CBC, coagulation studies, and typed and cross­matched blood. Coagulation studies, including prothrombin time, partial thromboplastin time, and platelet count, are of obvious benefit in patients taking anticoagulants or those with underlying hepatic disease. In addition, obtain BUN, creatinine, and electrolytes. In acute, brisk bleeding, the initial hematocrit level may not reflect the actual amount of blood loss. Bleeding from a source higher in the GI tract may elevate BUN levels through digestion and absorption of hemoglobin (BUN­to­creatinine ratio of >30:1).
IMAGING
Routine abdominal radiographs are of limited value without specific indications such as perforation, obstruction, or foreign bodies. Similarly, routine admission chest radiographs for patients with acute GI hemorrhage, even those admitted to the intensive care unit, are of limited utility in the absence
 of known pulmonary disease or abnormal findings on lung examination. Barium contrast studies are not helpful and can interfere with subsequent emergent endoscopy or angiography.
18­21
The initial diagnostic procedure of choice—angiography, scintigraphy, or endoscopy—depends on resource ability and consultant preference.
Angiography can sometimes detect the site of bleeding and help guide surgical management. Moreover, angiography permits therapeutic options such as transcatheter arterial embolization or the infusion of vasoconstrictive agents. However, angiographic diagnosis and therapy require a
 relatively brisk bleeding rate (at least .5 mL/min). Serious complications can also occur with angiography in up to 10% of cases.
Technetium­labeled red cell scans can also localize the site of bleeding in obscure hemorrhage. Such localization can be used to help determine if angiography or surgery is the optimal approach. Scintigraphy appears more sensitive than angiography and can localize the site of bleeding at as low a rate as .1 mL/min. It also has potential value over angiography if bleeding occurs intermittently but requires a
 minimum of  mL of blood to pool.
Multidetector CT angiography has a sensitivity and specificity of up to 100% and 99%, respectively, for detecting active or recent GI bleeding and is
,24 about 93% accurate in determining the site of bleeding. It can be a useful tool, especially in unstable lower GI bleeds, prior to treatment with conventional angiography and can detect bleeding at as low a rate of .4 mL/min.
TREATMENT
Resuscitate unstable or actively bleeding patients. Administer oxygen if patient is hypoxic and institute cardiac monitoring. Place two large­bore IV lines and replace volume with crystalloids. Correct coagulopathy including if international normalized ratio is >1.5 or platelets are <50,000/μL. Blood transfusion should be based on the clinical findings of significant blood loss or continued bleeding rather than on initial hematocrit values as it takes several hours for the hematocrit to decrease. General guidelines for initiation of blood transfusion are continued active bleeding and failure to improve perfusion and vital signs after crystalloid infusion or if hemoglobin falls below  g/dL. The threshold for blood transfusion should be lower in the elderly and those with multiple comorbid conditions.
Consider the placement of a nasogastric tube if lower GI bleeding is significant. Hematochezia unexpectedly originates from upper GI sources
,25 approximately 10% to 14% of the time. Factors that suggest an upper GI source for hematochezia include anemia and previous history of
  upper GI bleeding. Nasogastric aspiration has low sensitivity and negative predictive value for upper GI bleeding. In one study, 15% of patients with
 hematochezia had a negative nasogastric aspirate but had an upper GI source of bleeding. A nasogastric tube is likely beneficial only for those with
,26 significant ongoing upper GI bleeding in whom immediate intervention will occur.
Obtain early consultation for severe lower GI bleeding to expedite the next steps of care. Surgical consultation along with consultation from the gastroenterologist is prudent for uncontrollable bleeding.
ENDOSCOPY AND SURGERY
Flexible sigmoidoscopy can evaluate possible distal colonic and rectal sources of bleeding but cannot identify more proximal sources of bleeding.
Colonoscopy can diagnose various sources of lower GI bleeding, such as diverticulosis or angiodysplasia, and may allow ablation of bleeding sites with various endoscopic hemostasis methods (injection sclerotherapy, electrocoagulation, heater probe therapy, banding, and clipping). If colonoscopy fails to determine the source of bleeding, the specialists may consider upper endoscopy to evaluate for an upper GI source of bleeding, although upper
 endoscopy may be indicated first in certain situations. Timing of endoscopy can vary. Some studies suggest that urgent colonoscopy is both safe and
8­10,27 accurate within  to  hours of admission, but others report that delayed colonoscopy is appropriate in stable patients.
Patients with continued bleeding and failure of endoscopic hemostasis may need emergency surgery. The reported proportion of patients requiring
,18 surgery varies from 5% to 25%.
DISPOSITION AND FOLLOW­UP
Patients with lower GI hemorrhage will often require hospital admission and early referral to an endoscopist. Those who are unstable or with active bleeding may require admission to the intensive care unit, while those with an obvious cause of bleeding (e.g., mild bleeding from hemorrhoids or anal fissures), may be candidates for outpatient treatment.
Recently, the Oakland score was developed and validated regarding prognostication for lower GI bleeding. The Oakland score (TABLE 76­2) was developed in the UK and validated in a retrospective study across 140 hospitals in the US. It consists of  variables, although the validation study only utilized  (which omitted the digital rectal examination) but had similar results ,29 A Score of ≤  (only representing 9% of total cohort) had a sensitivity of 98% for a “safe discharge”, although a specificity of only 16%. A “safe discharge” was defined as the absence of blood transfusion, rebleeding, hemostatic intervention, hospital readmission, and death. While this score may be used to risk stratify patients who could be safe to discharge home, clinical judgement (e.g. social situation, lack of follow up, bleeding diathesis, etc) should still be used along with shared decision making regardless of score for final disposition.
TABLE 76­2
Oakland Score
Variable Score value
Age group (years)
≤39 
40­69 
≥70 
Sex
Female 
Male 
Previous hospital admission with Lower GI Bleed
No 
Yes 
Digital Rectal Exam
No blood 
Blood 
Heart rate (beats/min)
≤69 
70­89 
90­109 
≥110 
SBP (mm Hg)
≥160 
130­159 
120­129 
90­119 
50­89 
Hg (g/dL)
≥16.00 
.0­15.9 
.0­12.9 
.0­10.9 
.0­8.9 
.6­6.9 
(Reproduced with permission from Oakland K, Jairath V, Uberoi R, et al: Derivation and Validation of a Novel Risk Score For Safe Discharge after Acute Lower
Gastrointestinal Bleeding: a modelling study’ Lancet Gastroenterol Hepatol 2017 Sep; 2(9) 635­643).


