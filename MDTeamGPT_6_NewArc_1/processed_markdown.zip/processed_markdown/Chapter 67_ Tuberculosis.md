## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 67: Tuberculosis
Brit Long; Alex Koyfman
INTRODUCTION AND EPIDEMIOLOGY
Tuberculosis is an important worldwide infection, with more than one third of the overall population harboring the bacterium. It is the second leading
,2 infectious cause of death, especially among those with human immunodeficiency disease (HIV). Despite therapeutic progress over the past  years,
 drug resistance and HIV coinfection continue to challenge global control of tuberculosis.

Tuberculosis infections declined in the United States from 2000 to 2010. This reduction is primarily due to efforts targeting high­risk individuals.
Improved infection control policies, increased vigilance among physicians, implementation of directly observed therapy, and standardized drug regimens all contributed to the decline of tuberculosis (Table 67­1). Although overall national cases have decreased, the incidence in foreign­born
 patients remains  times that of U.S.­born persons. In those foreign­born patients, clinical tuberculosis is usually from reactivation of latent disease.

Overall, reactivation of latent tuberculosis is responsible for 70% of active tuberculosis cases.

Screening and treatment of latent infection in high­risk individuals are key to reducing tuberculosis in the United States. However, case detection
 rates are approximately 64%, with close to .3 million people with tuberculosis missed in 2013. TABLE 67­1
Patients With a High Prevalence of Tuberculosis (Highest to Lowest Risk)
Immigrants from high­prevalence countries
Patients with the human immunodeficiency virus
Residents and staff of prisons or shelters for the homeless
Alcoholics and illicit drug users
Elderly and nursing home patients
PATHOPHYSIOLOGY
Mycobacterium tuberculosis is a slow­growing aerobic rod that settles in areas of high oxygen content and blood flow. Transmission occurs via aerosolization of bacteria and inhalation of droplet nuclei into the lungs. Persons with active tuberculosis who excrete mycobacteria in saliva or
  sputum are the most infectious. Only 30% of patients become infected after a droplet exposure.
PRIMARY AND LATENT INFECTION
Once the organisms reach the lungs, host defenses activate. Mycobacteria are highly antigenic, resulting in a rapid immune response. Some organisms survive in the regional lymph nodes, where the host cell­mediated immunity contains the infection. Granulomas, known as tubercles, form from this process, which involves activated macrophages, T lymphocytes, and active bacteria. Tubercles are a sign of primary infection and may progress to caseation necrosis and calcification. These tubercles create a protective area for bacterial growth. In the lung, the Ghon complex (Figure 67­1) is a tubercle, appearing as calcified hilar lymph nodes.
FDIGoUwRnE l6o7a­1d.ed 2025­7­1 5:23 P Your IP is 136.142.159.127
Chapter 67: Tuberculosis, Brit Long; Alex Koyfman 
. Terms of Use * Privacy Policy * Notice * Accessibility
Primary Ghon complex (arrow).
If the tubercle fails to contain the infection, the mycobacteria may spread by hematogenous, lymphatic, or direct mechanical routes. The tendency is for survival in areas of high oxygen content or blood flow, such as the apical and posterior segments of the upper lobe and the superior segment of the lower lobe of the lung, the renal cortex, the meninges, the epiphyses of long bones, and the vertebrae. In these areas, the mycobacteria can remain dormant for years. During dormancy (or latent infection), a positive tuberculin skin test detects the disease. The skin test becomes positive  to  months after initial exposure. Only 1% to 13% of otherwise healthy patients develop active postprimary disease. Children and HIV patients have a
,8 higher risk, approaching a 20% frequency of postprimary infection. Latent infection is not transmissible.
REACTIVATION TUBERCULOSIS
,7
Whether latent infection progresses to recurrently active (or “reactivation”) tuberculosis is dependent on the immune status of the host. As the host defense system weakens, it is no longer capable of containing the foci of previous hematogenous spread, and active tuberculosis may develop. The
 risk for reactivation is higher among HIV­infected persons and those over  years old. In 5% of persons, latent infection may progress to active
,8 disease within  years after initial exposure, with another 5% developing disease later in life. In immunocompromised hosts, spread often occurs rapidly, and progression of early active disease is more frequent. HIV­infected patients have higher progression to active disease reported (7% to 10%
 per year). Other groups at risk for developing tuberculosis activation include those immunocompromised from cancer of solid organs, leukemia, transplantation, or medications such as antagonists of tumor necrosis factor­α (etanercept or infliximab) or corticosteroids (≥15 milligrams/d for ≥4
 weeks of prednisone or its equivalent). Those with select chronic diseases such as diabetes, chronic renal failure requiring hemodialysis, psoriasis,
,10 and silicosis are also at increased risk for tuberculosis activation.
CLINICAL FEATURES
PRIMARY TUBERCULOSIS
The initial infection is usually asymptomatic, often detected only by a positive screening tuberculin skin test or by abnormalities on chest radiograph.

When the infection is primary and active, common symptoms include cough, fever, malaise, weight loss, and chest pain. The lungs are the most common site affected, with over 85% of patients presenting with pulmonary symptoms. Infrequently, a pneumonitis similar to a viral or bacterial infection appears. Hilar adenopathy is present but rarely massive. In some cases, especially in immunocompromised patients, the primary infection is rapidly progressive and fatal.
REACTIVATION TUBERCULOSIS
When latent infection progresses to tuberculosis reactivation, symptoms may be systemic or pulmonary. The most common reactivation symptoms are similar to those seen in primary tuberculosis: fever, night sweats, malaise, fatigue, and weight loss. Productive cough, hemoptysis, dyspnea, and pleuritic chest pain develop as the infection spreads within the lungs. Physical examination is unremarkable, although rales may be noted in areas of pulmonary infection.

Although most cases of active tuberculosis involve the lungs, up to 20% of cases will have other manifestations. The most common extrapulmonary site of tuberculosis is the lymphatic system—painless lymphadenopathy (i.e., scrofula, cervical lymphadenitis). Other extrapulmonary manifestations include abdominal pain due to hepatosplenomegaly, peritoneal tubercles, prostatitis, epididymitis, or orchitis; adrenal insufficiency; bone pain with arthritis, osteomyelitis, or Pott’s disease (bony destruction, often in the spine); hematuria and sterile puree; and meningitis. Tuberculosis can also cause pericarditis, which can lead to tamponade and constrictive symptoms. Extrapulmonary tuberculosis can mimic many other common diseases, especially in the elderly and HIV patients.
DIAGNOSIS AND DIFFERENTIAL DIAGNOSIS

In ED patients with undiagnosed tuberculosis, this infection is often not considered ; consider tuberculosis in all patients over  years old with a
,7 pneumonia­like presentation or prominent respiratory complaint, especially if treatment of the condition has failed. Similarly, those with HIV or on immunosuppressive medications (notably after transplantation or with a connective tissue disease) are often infected with minimal symptoms. The variable clinical presentation and the time required to culture the organism make diagnosis in the ED challenging. The goal is to consider the infection, test for it, and start respiratory precautions in at­risk patients while awaiting results. Place patients with possible tuberculosis in separate waiting areas, provide them with surgical masks, and instruct them to cover the mouth and nose when coughing. Evaluate and isolate immunocompromised
 patients with respiratory symptoms promptly and until tuberculosis is excluded based on a chest radiograph. A negative­pressure room is ideal for isolation when available. Clues that suggest tuberculosis include hemoptysis, night sweats, and weight loss. On chest radiograph, look carefully for
 upper lung field involvement, fibrocalcific changes, pleural capping, or a calcified Ghon complex.
Once tuberculosis is suspected, staff should wear high­efficiency disposable masks when caring for the patient.
MANTOUX OR TUBERCULIN SKIN TEST
The most common method for screening for exposure to M. tuberculosis is a skin test. The Mantoux test uses intradermal injection of .1 mL of purified protein derivative into the forearm. The test relies on a delayed­type hypersensitivity reaction triggered in those with past infection or those with a significant recent exposure to tuberculosis, with sensitivity developing  to  weeks after infection. The test interpretation is between  and  hours after administration and assesses the extent of skin induration at the test site; erythema or other skin changes are not useful (Table 67­

2). Results are less reliable after  hours, with repeat testing required. All persons with a new positive skin test or recent conversion require evaluation for current symptoms, physical examination, and chest radiograph. Also, refer newly positive patients for treatment of latent tuberculosis if no evidence of active tuberculosis is present. Finally, test close contacts of known infected patients because 4% will be positive despite having no
 symptoms, half of whom will have detectable disease less than  month after exposure. Sensitivity of the purified protein derivative test depends on
 the size of induration:  mm demonstrates a sensitivity of 98%, whereas  and  mm possess sensitivities of 90% and 50% to 60%, respectively.
TABLE 67­2
Interpretation of a Purified Protein Derivative Skin Test* ≥5­mm induration is positive in:
Patients with the human immunodeficiency virus
Patients with close contact with a tuberculosis­infected individual
Patients with abnormal chest radiograph suggestive of healed tuberculosis
Patients with organ transplants and other immunosuppressed patients receiving the equivalent of prednisone >15 milligrams per day for >1 month
≥10­mm induration is positive in patients not meeting the above criteria but who have other risks:
Injection drug users
High­prevalence groups (immigrants, long­term care facility residents, persons in local high­risk areas)
Patients with conditions that increase the risk of progression to active disease (silicosis; diabetes; carcinoma of the head, neck, or lung)
Children <4 y of age
≥15­mm induration is positive in all others
Detection of newly infected persons in a screening program:
≥10­mm induration increase within any 2­y period is positive if <35 y
≥15­mm induration increase within any 2­y period is positive if >35 y
If the patient is anergic, other epidemiologic factors must be considered
*A positive reaction does not necessarily indicate disease.
In a few situations, a positive skin test is not diagnostic of tuberculosis. Those who received bacillus Calmette­Guérin immunization for tuberculosis prevention will often have a positive skin test response absent infection. Exposure to nontuberculosis mycobacteria also can result in a false­positive test. False­negative skin test results occur with improper administration, with improper test reading, very early in the disease, with recent
,10,15 measles­mumps­rubella vaccination, or with profound underlying immunosuppression (notably in HIV). In immunocompromised patients with a negative test but recent close contact to infectious tuberculosis, retest in  weeks and consider treatment. A negative tuberculin skin test does not rule
16­18  out the disease, because 20% of patients with active tuberculosis have a negative test result. Adverse reaction to tuberculin skin testing is rare.
BLOOD TESTS
Interferon­γ release assays (IGRAs) indirectly assess for tuberculosis. The test seeks the response to peptides present in all M. tuberculosis
 proteins, which trigger the release of interferon­γ by the infected host. These proteins are absent in the bacillus Calmette­Guérin vaccine and in most
,15,20,21 nontuberculous mycobacteria. IGRA has a specificity of >95% and sensitivity approximating 90% for latent tuberculosis. IGRA is used in
,22 conjunction with history, chest radiograph, and culture in those with suspected active tuberculosis. Currently used IGRA tests give results in  to
 hours, and results are reported as positive, negative, or indeterminant. IGRA tests are especially helpful when follow­up care compliance is a concern, notably in the homeless or drug­abusing patient (it does not require two visits), and can aid detection in patients in whom skin testing is not
,15 helpful for the previously mentioned reasons or in patients with known previous exposure (e.g., a healthcare worker). IGRA cannot distinguish between latent and active infection, and it may be falsely negative in immunocompromised patients. In the setting of active tuberculosis, IGRA
,23,24 sensitivity and specificity are poor and the test should not be used for diagnosis or exclusion.
CHEST RADIOGRAPH
The chest radiograph identifies disease in patients with pulmonary symptoms or after a positive skin test. No singular findings are pathognomonic for
  primary tuberculosis, and the most common finding is a normal chest radiograph, especially in immunocompromised patients. In primary infection, parenchymal infiltrates in any area of the lung may be found (Figure 67­2). Isolated ipsilateral hilar or mediastinal adenopathy is sometimes the only finding. Calcified lymph nodes exist in up to 35% of cases. Pleural effusions are usually unilateral and occur alone or in association with parenchymal disease, with 30% to 40% of radiographs having effusion with other findings. During primary infection, younger patients are more likely to have enlarged hilar lymph nodes, whereas adults more frequently have parenchymal abnormalities and effusions. The enlarged lymph nodes encountered in children may cause external compression, leading to bronchial obstruction, atelectasis, and postobstructive hyperinflation. Cavitation exists in 10% to 30% of patients and is uncommon in primary tuberculosis. Comparison with previous films is extremely helpful in determining the significance of an
,25 abnormal or unusual chest radiograph finding.
FIGURE 67­2. Reactivation tuberculosis. A. This elderly patient was treated with antibiotics for community­acquired pneumonia. B. When the patient did not respond, a past history of asymptomatic exposure to tuberculosis was elicited. Infiltrates were noted to be worse on hospital day  when tuberculosis skin test turned positive, diagnosing reactivation pulmonary tuberculosis.
In latent tuberculosis, nonspecific findings include upper lobe or hilar nodules and fibrotic lesions, sometimes calcified. Other findings are bronchiectasis, volume loss, and pleural scarring. Healed primary areas of infection appear as Ghon foci, areas of scarring, and calcification (Figure 67­
1).
Reactivation infections often have the classic findings of tuberculosis: cavitary or noncavitary lesions in the upper lobe or superior segment of the lower lobe of the lungs, either bilateral or unilateral (Figures 67­3 and 67­4).
FIGURE 67­3. Cavitary tuberculosis of the right upper lobe.
FIGURE 67­4. Advanced pulmonary tuberculosis involving apex and upper lobe.
The radiographic appearance of tuberculosis is often dependent on the integrity of the immune system rather than the stage of tuberculous disease,
,26 with classic findings seen in the immunocompetent patient. The frequency of classic findings on chest radiographs is directly related to the degree of immunosuppression; HIV patients with low CD4 counts have more atypical findings on radiographs. Normal radiographs occur in up to 22% of
,27 tuberculosis patients with advanced HIV. CT is more sensitive than plain chest radiography for the identification of early or subtle parenchymal or nodal disease, especially in immunocompromised patients, although CT is typically not required for diagnosis.
MICROSCOPY AND CULTURES
Sputum culture detects the presence of M. tuberculosis. Obtain samples spontaneously (coughing) or with inducement, seeking at least  to  mL per sample to improve yield. In the absence of a satisfactory sputum sample, gastric aspirates, pleural and other body fluids (blood and urine samples in
HIV patients), or tissue samples are options for culture and other diagnostic tests. Samples are stained using either a Ziehl­Neelsen stain or a fluorochrome procedure followed by exposure to an acidic agent. Mycobacteria will not lose the stain despite being rinsed with an acidic chemical
(hence the term acid­fast bacilli) on microscopic smears. Unfortunately, the staining procedure is not sufficiently sensitive or specific to confirm or
 exclude the diagnosis of tuberculosis, and expertise affects sample interpretation. Negative smears are found in approximately 60% of culture­
,27 positive cases of tuberculosis, with higher false­negative smear results in children and HIV patients (approaching 80%).
Sputum or other tissue cultures for M. tuberculosis are the best method of confirming diagnosis and the most specific test for the disease, detecting as few as  bacteria/mL. Culture results confirm infection and drug susceptibility, detecting resistance to treatment regimens. However, culture results are not available for weeks, thus creating the need for newer adjunctive tests to expedite diagnosis and treatment. Newer rapid culture techniques use liquid rather than solid media, with growth typically within  week, although liquid media are costlier and more prone to contamination compared to
 solid media. Blood cultures require specialized systems to detect growth.
Probe­based tests, or the nucleic acid amplification test (NAAT), can yield results within  day and detect as few as  to  organisms/mL
29­33 ,35 sample. The World Health Organization endorses NAAT for diagnosis of pulmonary and extrapulmonary tuberculosis. Sensitivity of NAAT is
 greater than smears, with a detection rate of 50% to 80% in patients who are smear negative. In patients with positive smears, NAAT has a sensitivity
 of greater than 90% to 95%. Patients with positive smears and positive NAAT should receive treatment pending culture results.
False­positive NAAT results may occur with prior treated disease, contamination, or laboratory error. NAAT will remain positive in the setting of adequate therapy, as it detects dead and live organisms, making it best used for diagnosis of tuberculosis. A negative NAAT result cannot exclude
  tuberculosis. Molecular testing detects M. tuberculosis DNA associated with drug resistance. Urine­based antigen detection assays also aid
  detection in patients with concurrent HIV, especially for those with CD4 counts <200 cells/mm and with smear­negative results.
TREATMENT
TREATMENT OF ACTIVE TUBERCULOSIS

Active tuberculosis treatment requires the use of a combination of antituberculous medications to overcome resistance. Treatment consists of two
,40 phases: an intensive phase and a continuation phase. Initial therapy includes four first­line medications (isoniazid [INH], rifampin [RIF], pyrazinamide, and ethambutol) for  weeks, followed by two­drug continuation treatment for  to  weeks based on culture results. This long
 duration of therapy is a challenge to compliance, with 7% to .6% of patients defaulting on therapy after  weeks. Second­line medications,
,42 including fluoroquinolones, are options for drug­resistant cases or when side effects from initial therapy are not tolerable. In most cases, antituberculous medications will not be started in the ED unless done in consultation and for classic cases. The recommended Centers for Disease

Control and Prevention regimens are as follows :
Daily four­drug (INH, RIF, pyrazinamide, and ethambutol) therapy for  weeks, followed by either INH/RIF or INH/rifapentine for  weeks or
Daily four­drug therapy for  weeks, followed by two times per week for  weeks, with subsequent INH/RIF or INH/rifapentine for  weeks or
Three times weekly four­drug therapy for  weeks, followed by INH/RIF three times weekly for  weeks or
Daily three­drug therapy (INH, RIF, and ethambutol) for  weeks followed by INH/RIF for  weeks
Combination therapy taken daily reduces the risk of relapse and the development of secondary resistance to RIF. Administration of fixed drug combination tablets optimizes effectiveness. Use prolonged therapy in immunocompromised patients, patients with cavitary pulmonary tuberculosis and positive sputum culture after  months of therapy, or patients with extrapulmonary disease (disseminated, CNS involvement, skeletal tuberculosis, and drug­resistant tuberculosis).
Once available, modify initial therapy based on drug susceptibilities. Direct observation of therapy is paramount in patients for whom compliance is a concern; the Centers for Disease Control and Prevention recommends that all regimens using twice­ or thrice­weekly approaches be given using direct
,22 observation. Patients usually experience clinical improvement within days to weeks of beginning therapy. A variety of medications under evaluation
(e.g., bedaquiline, delamanid, pretomanid, SQ­109) may allow shorter treatment regimens.
Although the standard medications used to treat tuberculosis are generally effective and safe, side effects or drug interactions may occur (Table 67­

3). Hepatotoxicity is the major adverse effect of INH, with rates ranging from 5% to 33%. An asymptomatic increase in aspartate transaminase levels occurs in many patients, which usually resolves within several weeks. If serum transaminases are greater than five times the upper limit of normal or if
 serum bilirubin is >3 milligrams/dL, stop antituberculous medications. Patients do not require routine monitoring of liver function unless a higher risk for hepatotoxicity exists, such as preexisting liver disease, use of other liver­affecting medicines, pregnancy, ethanol use, HIV, and hepatitis C
,22,27,43 infection.
TABLE 67­3
Treatment of Tuberculosis (Adults)* Three
Daily Times Two Times Weekly
Drug Potential Side Effects and Comments
(maximum) Weekly DOT DOT (maximum)
(maximum)
Isoniazid    milligrams/kg PO (900 Hepatitis, peripheral neuropathy, drug interactions.
milligrams/kg milligrams/kg milligrams)
PO* (300 PO (900 milligrams) milligrams)
Rifampin    milligrams/kg PO (600 Hepatitis, thrombocytopenia, GI disturbances, drug interactions.
(RIF) milligrams/kg milligrams/kg milligrams)
PO* (600 PO (600 milligrams) milligrams)
Rifapentine Not given Not given  600 milligrams PO twice Hepatitis, thrombocytopenia, exacerbation of porphyria. Recommended daily times weekly weekly in adults; not by Centers for Disease Control and Prevention for continuation therapy approved in children <12 only for human immunodeficiency virus–negative patients.
y old
Rifabutin    milligrams/kg PO (300 Similar to RIF; used for patients who cannot tolerate RIF.
milligrams/kg milligrams/kg milligrams)
PO (300 PO (300 milligrams) milligrams)
Ethambutol 15–20 25–30  milligrams/kg PO (2.5 Retrobulbar neuritis, peripheral neuropathy.
milligrams/kg milligrams/kg grams)
PO (1.6 PO (2.5 grams) grams)
Pyrazinamide 15–30   milligrams/kg PO (2 Hepatitis, arthralgia, hyperuricemia.
milligrams/kg milligrams/kg grams)
PO (2 grams) PO (3 grams)
Abbreviation: DOT = directly observed therapy.
∗
See http://www.cdc.gov/tb for more accurate weight­based protocols and dosages for children.
,27,44
A portion of patients treated for tuberculosis worsen after the initiation of antituberculous medications. This effect is called a paradoxical reaction or immune reconstitution syndrome and can be seen in any patient receiving treatment for tuberculosis, although it is more commonly seen in those with HIV infection, specifically with CD4 counts ≤50 cells/mm  . Findings include fever, worsening respiratory status and pulmonary infiltrates, lymphadenopathy, hepatosplenomegaly, ascites, meningitis, and new or worsening CNS lesions. Hypercalcemia is a unique finding in paradoxical reactions. Because treatment of both tuberculosis and HIV improves immune function, the paradoxical reaction emanates from improvement in the ability to mount an inflammatory response as mycobacteria clear. The dilemma is differentiating this from treatment failures, drug resistance, and medication noncompliance. (See the “Special Populations” section.)
TREATMENT OF LATENT TUBERCULOSIS
Treatment of latent infection with INH alone is for those with recent asymptomatic skin test conversion (Table 67­2), any person in close contact with an
,22 actively infected patient, and anergic patients with known tuberculosis contact. Treatment of latent infection is associated with a marked reduction
 in risk of conversion, approximating 70%. Unless contraindicated, therapy is given for a minimum of  months. For those exposed to INH­resistant
 strains or those who are intolerant, use RIF and pyrazinamide for  months with hepatotoxicity monitoring. Rifapentine with INH for latent
46­48 tuberculosis is useful in those unlikely to complete  months of treatment.
DISPOSITION AND FOLLOW­UP
OUTPATIENT CARE
Most patients with tuberculosis start therapy as outpatients. If planning discharge or transfer for other nonmedical care, start or maintain therapy while awaiting smear and culture results on all patients with suspicious findings of active tuberculosis, notably cavitary lesions or known previous infection with new weakness or fevers.
Contact primary care physicians and public health services and arrange for long­term care before patient discharge. In the United States, tuberculosis is a reportable disease in most states, and patients with suspected or confirmed tuberculosis should be reported to a public health authority within 
,50 hours. Discharge instructions include home isolation procedures and follow­up at the appropriate clinic to receive medication and ongoing care.
Antituberculous medications should not be instituted in the ED unless there is joint agreement with the consultant and follow­up providers.
HOSPITAL ADMISSION
Hospital admission is best for ill­appearing, hypoxemic, or dyspneic patients; if the diagnosis is uncertain; if noncompliance is likely or if the social situation makes it difficult to complete evaluation and start care; or for patients with active drug­resistant tuberculosis. Hospitalized patients with suspected tuberculosis require respiratory isolation in a negative­pressure room (Table 67­4). An alternative to admission for therapy compliance alone is a court­ordered drug observation program (if available), where scheduled outpatient contacts to ensure medication use occur for the course
 of therapy.
TABLE 67­4
Engineering Controls to Reduce the Transmission of Tuberculosis
High airflow (at least  room air changes per hour) with external exhaust
High­efficiency particulate filters on ventilation system
Ultraviolet germicidal irradiation
Negative­pressure isolation rooms
Personal respiratory protection: high­efficiency particulate filter masks or respirators
SPECIAL POPULATIONS
PATIENTS WITH TUBERCULOSIS AND HUMAN IMMUNODEFICIENCY VIRUS
HIV infection is the strongest known risk factor for tuberculosis, and the incidence of tuberculosis in HIV­positive patients is much higher than in the general population. Patients with a new diagnosis of tuberculosis are almost  times more likely to have HIV, and HIV patients are  to  times more
 likely to develop tuberculosis, especially within the first year of HIV infection. Tuberculosis (pulmonary and extrapulmonary) often can be the initial clinical manifestation of immunodeficiency and is a defining event in the acquired immunodeficiency syndrome. In 2013, close to .1 million people
 were coinfected with HIV and tuberculosis, with 80% of these cases in Africa. Once active tuberculosis develops, the risk of rapid progression and drug resistance is higher in the HIV patient. Successful treatment with antiretroviral therapy lowers the rate of tuberculosis and reduces the incidence
 of extrapulmonary involvement. For these reasons,physicians considering a diagnosis of tuberculosis should obtain HIV testing to provide early diagnosis and therapy.
Treatment of tuberculosis in HIV­positive patients is effective and not markedly different from others with the infection. However, due to the number of medications taken by patients with HIV, potential drug interactions are common, and compliance may become an issue. Protease inhibitors and several nonnucleoside reverse transcriptase inhibitors have interactions with RIF, and rifabutin can be used in place of RIF in patients with HIV.
,54
The ideal timing of antiretroviral therapy in those with active tuberculosis is uncertain. Beginning antiretroviral therapy early reduces progression to acquired immunodeficiency syndrome in patients with HIV, but in those with higher CD4+ counts, delaying initiation of antiretroviral therapy until
 the continuation phase may be beneficial. (See Chapter 155, “Human Immunodeficiency Virus Infection.”)
MULTIDRUG­RESISTANT TUBERCULOSIS
Multidrug­resistant tuberculosis is tuberculosis with isolates that demonstrate resistance to at least INH and RIF, with approximately 20% of M.
 ,58 tuberculosis isolates meeting this definition. These forms are also highly infectious, with conversion rates approaching 50% in those exposed. M.
tuberculosis becomes resistant by spontaneous genetic mutation, often as a result of inadequate drug therapy or noncompliance with initial treatment. While resistance confirmation requires culture and sensitivity data, certain historical and clinical features raise the level of suspicion for multidrug­resistant tuberculosis. These include a history of tuberculosis treatment in the past, residence in or travel to an area with high prevalence of drug­resistant tuberculosis, exposure to multidrug­resistant tuberculosis, known INH resistance in the community above 4%, progressing
 radiographic findings despite therapy, and persistent symptoms or persistently positive sputum cultures despite  months of standard treatment.
Extensive drug­resistant tuberculosis occurs when resistance to INH, RIF, any fluoroquinolone, and at least one injectable second­line medication
 exists ; this is an intense worldwide threat to public health and tuberculosis control, associated with poorer outcomes and higher mortality. Extensive
,61 drug­resistant tuberculosis exists in New York, California, Italy, Iran, and India.
Treatment of multidrug­resistant tuberculosis is challenging and depends on sensitivity patterns from culture. INH provides the strongest bactericidal action, and RIF has important action against dormant bacilli. Some countries may use standardized regimens based on known local resistance patterns. Usually combination therapy with four to six medications (three to five previously unused medications), including the more toxic and less potent second­line medications, is administered for up to  years. A fluoroquinolone is typically a part of a long­term regimen, and rifabutin is often
,62 used in place of RIF. Success rates rarely exceed 60%. In refractory cases, resectional surgery may be necessary in addition to ongoing medical
 therapy.
The “Global Plan to Stop Tuberculosis” calls for better compliance and new medications to fight against the problem of multidrug­resistant
 63­65 tuberculosis, especially delamanid. Other new options include bedaquiline, approved in 2012. Treatment for this difficult pathogen is administered for  to  months after negative sputum culture samples.
CHILDREN
The clinical course and disease manifestations of tuberculosis in children have several unique aspects. Although children are at greater risk for developing rapidly progressive and disseminated disease, their presenting signs and symptoms can be subtle. When a child develops tuberculosis, test for infection of family members. Primary tuberculosis in children is often asymptomatic and identified only through screening programs or contact
 tracing. Children may be asymptomatic even with abnormal radiographs, but many have fever, cough, wheezing, poor feeding, and fatigue. The classic symptoms of fever, night sweats, and weight loss occur more often in older children; however, in those younger than  years, presentation may be that of miliary tuberculosis (see below), meningitis, or a pneumonia that does not respond to therapy. The most common extrapulmonary presentation is cervical lymphadenitis, but other regions may be involved including the meninges, pericardium, abdomen, bone, joints, kidneys, skin, and eyes. Bony involvement is more common in pediatric patients compared to adults.
The yield of sputum smears and cultures is lower in children because of difficulty in obtaining adequate samples in addition to the lower incidence of
,68 cavitary disease. Traditionally, obtaining three early morning consecutive gastric lavage or gastric aspirate samples occurred. However, this is invasive, unpleasant, and often requires an overnight admission and trained staff. Sputum induction using bronchodilators, followed by nebulized
 saline and expectoration of mucus, can improve sampling.

Tuberculosis confirmation in children using culture happens in only 30% to 40% of cases. IGRA and NAAT are not recommended for children less
 than  years old as the immune response differs in this age group, making the tests less reliable. Often, treatment is initiated based on a skin test or
 on clinical grounds (symptoms, a history of exposure, or abnormal radiographs), and the diagnosis is presumed. Chest radiographs in children typically only demonstrate hilar lymphadenopathy or patchy infiltrate. Multidrug therapy is used for all children with active disease, whereas monotherapy is used for latent infections.
MILIARY TUBERCULOSIS
Miliary tuberculosis is a historic term noting the gross appearance of the lung during disseminated tuberculosis. In such cases, the lung has many small lesions resembling millet seeds. Classic miliary tuberculosis shows diffuse nodules on radiographs (1 to  mm) in a patient with positive laboratory testing or by demonstration of mycobacteria in multiple organs. The classic radiographic findings may not appear on films until the disease has progressed over time. A miliary pattern on radiographs exists in conditions other than tuberculosis including histoplasmosis, malignancy,
 siderosis, and sarcoidosis.
Today, miliary tuberculosis refers to wide hematogenous spread during primary or reactivation disease, and it is associated with higher mortality.
Children, the elderly, and immunocompromised patients are all at increased risk of developing miliary disease.
Miliary disease during primary tuberculosis is generally more rapid and severe, often presenting with multiorgan failure, shock, and acute respiratory distress syndrome. Conversely, miliary reactivation often manifests with a chronic, nonspecific clinical course affecting any number of organ systems.
Fever, anorexia, night sweats, cough, weight loss, splenomegaly, lymphadenopathy, and signs of multisystem illness should cause one to suspect miliary disease. Cutaneous involvement, seen more often in HIV patients, manifests as papules or vesiculopapules (tuberculosis cutis miliaris disseminata or tuberculosis cutis acuta generalisata). Choroidal tubercles found on ocular exam are pathognomonic for miliary tuberculosis.
EXTRAPULMONARY TUBERCULOSIS
Approximately 20% of patients with tuberculosis will have extrapulmonary involvement, and 60% will not have concomitant pulmonary infection. The dermatologic, ophthalmologic, nervous, renal, GI, musculoskeletal, endocrine, and cardiac systems all are targets, with high­oxygen tension areas more commonly infected.
TUBERCULOUS MENINGITIS
Tuberculous meningitis is more common in children, although those with HIV or others who are immunocompromised may also be afflicted. The presentation is subtle and subacute over days to weeks, with gradual fever, headache, and cognition or sensorium changes that often are not accompanied by neck stiffness or irritation; this is in contrast with findings in other forms of bacterial meningitis. Focal neurologic deficits or cranial
 nerve palsies may occur. Suspecting the infection and requesting tuberculosis cultures and smear are key to making a diagnosis. Cerebrospinal fluid findings typically demonstrate lymphocytic pleocytosis, elevated protein, increased opening pressure, and a cerebrospinal fluid–to–protein ratio of
<0.5. CT of the head may be normal in 30% of patients with mild CNS disease. Long­term neurologic dysfunction is common, with ventriculoperitoneal shunting needed in 25% of patients for hydrocephalus. Tuberculous meningitis often seeds after a miliary infection. Treatment parallels other forms of tuberculosis with prolonged therapy, and adjunctive corticosteroids reduce complications.


