## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 126: Stridor and Drooling in Infants and Children
Rushi R. Parikh; Craig J. Huang
INTRODUCTION

Stridor is characterized as a high­pitched, harsh, monophonic sound produced by turbulent airflow through a partially obstructed airway. Both inspiratory and expiratory stridor are associated with airway obstruction. As air is forced through a narrow tube, it undergoes an increase in speed and a decrease in pressure (Bernoulli’s principle). The decrease in lateral pressure causes the walls of the airway to temporarily collapse and vibrate, generating this stridulous sound. Hagen­Poiseuille’s law shows that resistance to laminar airflow increases markedly with small decreases in the
 airway’s radius. A small amount of inflammation can result in significant airway obstruction in children.

R (resistance) =  * η (viscosity) * l (length)/π * r (radius)
Immediately assess a child with stridor, as stridor indicates a difficult airway, and advanced airway management may be necessary (see Chapter 113,
“Intubation and Ventilation in Infants and Children”). A thorough history and examination will often lead to a “working diagnosis.” Inquire about the time and events surrounding the onset of stridor, the presence of fever, known congenital anomalies, cardiac abnormalities, perinatal complications,
 prematurity, neonatal intensive care unit interventions, and previous endotracheal intubation or instrumentation.
The level of obstruction can often be identified on examination. Partial obstruction of the upper airway at the nasopharynx and/or oropharyngeal level produces sonorous sounds, called stertor. Obstruction above the true vocal cords is generally indicative of inspiratory stridor, whereas expiratory
 stridor is characterized by obstruction below the true vocal cords. Biphasic stridor suggests obstruction at the level of the true vocal cords.
Consider airway foreign body until proven otherwise if there is marked variation in the pattern of stridor. The noise made by a child with stridor is often interpreted as wheezing by parents unfamiliar with stridor. Clarify what the parent means when the word “wheezing” is used— whether the sound occurs when the child breathes in or breathes out. The differential diagnosis of stridor depends on the child’s age (Table 126­1).
TABLE 126­1
Causes of Stridor
Children <6 mo of age Children >6 mo of age
Laryngotracheomalacia Croup
Vocal cord paralysis Epiglottitis
Subglottic stenosis Bacterial tracheitis
Airway hemangioma Foreign body aspiration
Vascular ring/sling Retropharyngeal abscess
STRIDOR IN INFANTS <6 MONTHS OLD
An infant <6 months old with a long duration of symptoms often has a congenital cause of stridor. The major causes are laryngomalacia,
 tracheomalacia, vocal cord paralysis, and subglottic stenosis. Less common but important considerations include airway hemangiomas, vascular
Chapter 126: Stridor and Drooling in Infants and Children, Rushi R. Parikh; Craig J. Huang rings, and slings. Stridor presenting in the first  months of life will often require direct airway visualization through endoscopy or advanced imaging.
. Terms of Use * Privacy Policy * Notice * Accessibility
The timing of this evaluation (emergent or outpatient) is dictated by the severity of symptoms and clinical suspicion.
Laryngomalacia accounts for 60% of all neonatal laryngeal problems and results from a developmentally weak larynx. Collapse occurs with each inspiration at the epiglottis, aryepiglottic folds, and arytenoids. Generally, stridor worsens with crying and agitation but often improves with neck extension and when the child is prone. Laryngomalacia usually manifests shortly after birth, which is a key diagnostic feature, and generally resolves by  months of age. In many cases, the tracheal support structures are similarly affected, resulting in laryngotracheomalacia. Symptom exacerbations may occur with upper respiratory infections or increased work of breathing from any cause. Definitive diagnosis can often be made with flexible fiberoptic laryngoscopy. Surgery may be required if a child suffers from failure to thrive, apnea, or pulmonary hypertension.
Vocal cord paralysis can be congenital or acquired. Unilateral vocal cord paralysis is more common than bilateral and can present with feeding problems, stridor, hoarse voice, and changes to a child’s cry. Children with bilateral cord paralysis often have a normal voice associated with stridor
 and dyspnea, and symptoms can include cyanosis and apneic episodes. Diagnosis is by flexible nasolaryngoscopy. Endotracheal intubation can be difficult with bilateral cord paralysis, and a surgical airway may be required to secure the airway.
Subglottic stenosis may be congenital or acquired and is diagnosed when there is a narrowing of the laryngeal lumen. Congenital stenosis is usually diagnosed in the first few months of life when the child is noted to have persistent inspiratory stridor. Mild cases may present later in childhood as
 recurrent or persistent croup. Prolonged endotracheal intubation in premature babies is the most common cause of acquired subglottic stenosis.
Treatment is based on the severity of the stenosis.
Hemangiomas are benign congenital tumors of endothelial cells or vascular malformations that can occur anywhere on the body (80% are located above the clavicles), including the airway, where they can cause obstruction and stridor. Hemangiomas typically enlarge throughout the first year of life, may not be noticed at birth, and tend to spontaneously regress by age  years old. For infants <6 months old, thoroughly examine the skin, because cutaneous hemangiomas, especially in a beard distribution, may be a clue to the presence of an airway hemangioma. Consider airway hemangioma in new­onset stridor beginning after the first month of life without another explanation; definitive diagnosis requires airway visualization through endoscopy. Although most hemangiomas spontaneously regress, large malformations and those causing significant
6­9 respiratory symptoms may require treatment with β­blockers, steroids, laser, or surgery.
Vascular rings and slings are rare congenital anomalies of the aortic arch and pulmonary artery in which anomalous vessels can compress the trachea or esophagus. Examples include a double­ or right­sided aortic arch. Symptoms are often present from birth or early in the first month of life and may be progressive and exaggerated during intercurrent upper respiratory infections; difficulty with feeding may also occur if the esophagus is compressed. Chest radiograph may reveal subtle narrowing or anterior compression of the trachea on the lateral view or an abnormal (e.g., rightsided) aortic arch. Further evaluation includes bronchoscopy, CT angiography, and echocardiography to evaluate for associated congenital heart anomalies. Definitive treatment is surgical.
STRIDOR IN CHILDREN >6 MONTHS OLD
The child >6 months old with a relatively short duration of symptoms (hours to days) characteristically has an acquired cause of stridor. Causes are either inflammatory/infectious, such as croup or epiglottitis, or noninflammatory, such as a foreign body aspiration (Table 126­2).
TABLE 126­2
Common Acquired Causes of Stridor
Bacterial Foreign Body Retropharyngeal Peritonsillar
Viral Croup Epiglottitis
Tracheitis Aspiration Abscess Abscess
Etiology Parainfluenza viruses (occasionally Streptococcus Staphylococcus Variable Polymicrobial Polymicrobial influenza respiratory syncytial virus, pneumoniae aureus (most) rhinovirus, metapneumovirus, enterovirus, and coronavirus) Foods Streptococcus S. pyogenes pyogenes
S. aureus S. pneumoniae Peanuts S. aureus S. aureus
S. pyogenes
Haemophilus H. influenzae Seeds Gram­negative Oral influenzae rods anaerobes
Moraxella Balloons/other Oral anaerobes catarrhalis toys
Age  mo–3 y old All ages  mo–13 y old Any  mo–4 y old 10–18 y old
(most)
Peak 1–2 y old Mean, 6–12 y Mean, 1–6 y old  mo–5 y old Rare >4 y old  mo–5 y old old most common (rare)
80% <3 y old
Onset 1–3 d Rapid, hours 2–7 d viral upper Immediate or Insidious over 2–3 Antecedent respiratory delayed d after an upper pharyngitis infection possible respiratory
(especially infection or local influenza) trauma
Suddenly worse over 8–12 h
Effect of None Worse supine None Usually none Neck stiffness and Worse supine positioning hyperextension on symptoms Prefer erect, Location Trismus chin forward dependent common
Stridor Inspiratory and expiratory Inspiratory Inspiratory and Location Inspiratory when Uncommon expiratory dependent severe
Cough Seal­like bark No Usually present Often transient No No or positional
Possible thick sputum
Voice Hoarse Muffled Usually normal Location Often muffled Muffled dependent
Not muffled “Hot potato” Possibly raspy Primarily if at “Hot potato” “Hot potato” or above glottis
Drooling No Yes Rare Rare—often if Yes Often esophageal
Dysphagia Occasional Yes No Rare—typically Yes Yes if esophageal
Radiologic Subglottic narrowing “steeple sign” (no Enlarged Subglottic Often normal Thickened bulging May see appearance diagnostic value) epiglottis; narrowing retropharyngeal enlarged
“thumbprint soft tissue tonsillar soft sign” tissue
Thickened Irregular tracheal Possible aryepiglottic margins radiopaque folds density
Stranding across Ball­valve trachea effect
Segmented atelectasis
CROUP
Croup (viral laryngotracheobronchitis) is the most common cause of stridor outside the neonatal period, commonly affecting children  months to  years old. The incidence is highest in the fall and the early winter months, but sporadic cases can be seen year­round. The most common viruses are parainfluenza virus and rhinovirus, followed by various other respiratory viral pathogens including influenza, respiratory syncytial virus, metapneumovirus, enterovirus, and coronavirus. In areas where measles remains prevalent, this is an important cause of croup.
,11
Coinfection by more than one virus is not uncommon, and bacterial superinfection, although rare, is also possible.
CLINICAL FEATURES
The clinical course of croup varies, but symptoms typically begin after  to  days of nasal congestion, rhinorrhea, cough, and low­grade fever. Classic symptoms are a harsh barking cough, hoarse voice, and stridor. Symptoms are often worse at night. The severity of symptoms is related to the amount of edema and inflammation of the airway. Assess for tachypnea, stridor at rest, nasal flaring, retractions, lethargy or agitation, and oxygen desaturation. Most croup is self­limited and short in duration, resolving spontaneously within  days, although depending on the etiology, it may last
 longer.
DIAGNOSIS
Diagnosis is clinical. Laboratory studies, viral tests, or radiographs are needed only in children who fail to respond to conventional therapy or if
 considering another diagnosis such as epiglottitis, retropharyngeal abscess, or aspirated foreign body. If radiographs are ordered, provide close
 monitoring during the procedure, as agitation may worsen existing airway obstruction. Radiographs may demonstrate subglottic narrowing
(“steeple sign”) (Figure 126­1); however, the steeple sign may be present in normal children and can be absent in up to 50% of those with croup.
FIGURE 126­1. Anteroposterior neck radiograph in a patient with croup; note presence of “steeple sign” (arrow). [Photo used with permission of W. McAlister, MD,
Washington University School of Medicine, St. Louis, MO.]
Croup is often classified as mild, moderate, or severe, and treatment is directed primarily at decreasing airway obstruction. Croup scoring systems are more useful as research tools than in clinical practice. The score, if calculated, should be used as only one piece of data in the decision­making
 process. One of the commonly used scoring guidelines is the modified Westley Croup Score (Table 126­3).
TABLE 126­3
The modified Westley Croup Score
Inspiratory stridor None =  points With agitation only =  point At rest =  points
Intercostal retractions Mild =  point Moderate =  points Severe =  points
Air entry Normal =  points Slightly decreased =  point Severely decreased =  points
Cyanosis None =  points With agitation only =  points At rest =  points
Level of consciousness Normal =  points Altered =  points
0–17 points total <4 points = mild croup 4–6 points = moderate croup >6 points = severe croup
Place children in a position of comfort, often in the lap of the caretaker, and assess respiratory distress through observation, without disturbing the child. Agitation and crying increase oxygen demand, creating turbulent airflow and resulting in greater airway resistance. Humidified air or cool mist
 does not appear to improve clinical symptoms. However, anecdotally, exposing children with croup to cold air at home reduces the intensity of
 symptoms.
The primary treatments for croup include nebulized epinephrine and corticosteroids (Table 126­4). Give nebulized epinephrine for moderate to severe croup, primarily those with stridor at rest; mild croup generally does not require epinephrine. Epinephrine decreases airway edema through its vasoconstrictive α­receptor effects. Clinical effects of epinephrine are seen in as few as  minutes. Use of epinephrine decreases the number of children with croup requiring hospitalization, intensive care unit stay, or intubation. Studies comparing l­epinephrine with racemic epinephrine show no significant difference in response initially; however, at  hours after administration, patients receiving l­epinephrine displayed
,16  lower croup scores. Administration of nebulized intermittent positive­pressure breathing has no benefit over simple nebulization. ED observation for at least  hours is recommended when epinephrine is required because an increase in croup scores can occur between the second and
 third hours after epinephrine in patients ultimately requiring admission.
TABLE 126­4
Croup Treatment
Medication Dose Notes
Dexamethasone .15–0.6 milligram/kg PO/IM (10 Give for mild, moderate, or severe croup. May crush pills and mix in juice or applesauce or milligrams maximum) administer the IV formulation orally.
Budesonide  milligrams nebulized Consider if PO steroids vomited.
l­Epinephrine .5 mL/kg nebulized (5 mL maximum) Use for moderate or severe croup; may need repeat dose if severe.
(1:1000)
All patients with croup, whether mild, moderate, or severe, benefit from the administration of oral steroids as a one­time dose.
,18
Steroid administration reduces the severity and duration of symptoms and results in a decrease in return visits to the ED or hospital length of stay.
A one­time dose of dexamethasone has become the steroid of choice given ease of administration, cost, and medication half­life. Dexamethasone is equally effective given parenterally or orally. Currently, a single dose of .6 milligram/kg PO of the oral dexamethasone preparation is
  recommended. The onset of action for oral dexamethasone is generally  to  hours after oral administration, but effects can be seen within  hour.
Most clinicians initially prescribe oral corticosteroids because of ease of administration. Using injectable dexamethasone formulation (4 milligrams/mL) for oral administration provides less volume than commercially available oral products (0.1 milligram/mL or  milligram/mL) and can
 improve tolerability and minimize risk of emesis. Nebulized budesonide and IM dexamethasone are alternatives to oral dexamethasone in children who are vomiting.
For severe croup with respiratory failure despite medical therapy, endotracheal intubation may be necessary. When possible, intubation should be performed in a controlled setting such as the operative room or intensive care unit by the most experienced person available. Intubation should be performed using an endotracheal tube .5 to  mm smaller than normally used for the patient’s size given the upper airway edema.
Heliox, in a 70% helium/30% oxygen ratio, has theoretical treatment benefits for severe, refractory croup. Replacing nitrogen with the less dense helium decreases airway resistance and may improve gas flow through a compromised airway. An important limitation is the low fractional concentration of inspired oxygen in the gas mixture. Despite its theoretical benefits, studies show no definitive advantage of heliox over conventional
,21 treatment. In certain clinical scenarios, it may still hold some short­term clinical benefit. Although historically used in children with mild to
 moderate croup, the use of humidified air is also likely ineffective.
,22
There are insufficient data to determine whether nebulized β­agonists are beneficial in children with croup. In addition, there is theoretical risk of worsening upper airway obstruction with β­agonist use in croup, as β­receptors in the vasculature cause vasodilation (as compared to the vasoconstrictive α effects of epinephrine), which may worsen upper airway edema in croup. Therefore, β­agonists are not recommended for treatment of croup.
DISPOSITION AND FOLLOW­UP
Most children with croup can be safely discharged to home (Table 126­5). Children who have received nebulized epinephrine should be observed in the ED for  to  hours after administration. Children with persistent stridor at rest, tachypnea, retractions, and hypoxia or those who
,11,22 require more than two treatments of epinephrine should be admitted to the hospital. Admit children with respiratory failure and those requiring intubation to intensive care.
TABLE 126­5
Criteria for Discharge From ED in Patients With Croup
No stridor at rest and  h since last epinephrine (if given)
Normal color, pulse oximetry, and mental status
Able to tolerate oral fluids
Caretaker can recognize worsening symptoms and return to ED if necessary
EPIGLOTTITIS
Epiglottitis, or supraglottitis, is an acute inflammatory condition of the epiglottis that may progress rapidly to life­threatening airway obstruction.
Widespread administration of Haemophilus influenzae type B vaccine has significantly reduced the number of cases of childhood epiglottitis and shifted the epidemiology toward older children (mean age  to  years). In the postvaccine era, most cases of infectious epiglottitis are caused by streptococcal and staphylococcal species, whereas Candida species can cause epiglottitis in the immunocompromised patient. Noninfectious causes,
 such as thermal injury, caustic burns, and direct trauma, can cause swelling and inflammation of the epiglottis with a similar clinical picture.
CLINICAL FEATURES
Infection typically presents with the abrupt onset of fever, stridor, drooling, and sore throat. Symptoms may progress rapidly, with inability to handle oral secretions followed by stridor and respiratory distress. Cough is often absent, and the voice may be muffled. Most children appear toxic and
 anxious and may assume a tripod or sniffing position with the neck hyperextended and the chin forward to maintain the airway.
DIAGNOSIS
The ideal approach to the diagnosis of epiglottitis varies depending on the practice and the environment. Each institution should have a written protocol for suspected epiglottitis management. Important components of all protocols are listed in Table 126­6. TABLE 126­6
Suspected Epiglottitis Management Protocol
Immediate recognition and triage to a resuscitation area
Continuous monitoring by someone trained in the management of a difficult airway
Rapid consultation with appropriate colleagues from otolaryngology and anesthesiology
Consideration and risk­benefit analysis of patient transfer with appropriate personnel present during the transfer
Bedside radiology without disturbing the patient or, if moved to the x­ray suite, constant monitoring by a physician with appropriate airway equipment and skills
In older children and those with mild respiratory distress, gentle direct visualization of the epiglottis may be attempted. Despite concerns that such maneuvers could trigger worsening distress, no documented reports show this to be unsafe.
Lateral neck radiographs are usually unnecessary in patients with the classic presentation of epiglottitis. When the diagnosis is uncertain, obtain soft tissue neck radiographs with the neck extended during inspiration. Affected children typically hold their heads in a sniffing position and have prolonged inspiration already, making it quite simple to obtain radiographs. Lateral neck radiographs may show an enlarged epiglottis protruding
,24 from the anterior wall of the hypopharynx (often called the “thumb sign”) and thickened aryepiglottic folds (Figure 126­2). If suspicion for the diagnosis still exists despite normal­appearing radiographs, direct visualization of the epiglottis is necessary to exclude the diagnosis (Figure 126­3).
FIGURE 126­2. Lateral neck view of a child with epiglottitis. Note the swollen epiglottis (arrow) resembling a “thumb.”
FIGURE 126­3. Epiglottitis at laryngoscopy. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 3rd ed. McGraw­Hill, Inc.,
New York. Part  Specialty Areas, Chapter , Pediatric Conditions, Figure 14­38.]
TREATMENT
Keep the child seated and upright in a position of comfort. Provide oxygen only if this does not further agitate the child. Administer nebulized lepinephrine to decrease airway edema. Alert the referral center or pediatric otolaryngologist as soon as possible so decisions concerning intubation or tracheotomy can be made in concert with consultants and support personnel can be mobilized. The most skilled individual available should perform intubation as soon as the diagnosis is made. Awake, fiberoptic nasotracheal intubation under conscious sedation should be considered in the spontaneously breathing patient. Use paralytics and vagolytics as needed. For a child who is able to maintain an airway, the decision to administer paralytics must be accompanied by absolute certainty that intubation will be successful. Have multiple endotracheal tube sizes immediately available.
Supraglottic devices are not effective in children with upper airway obstruction; if endotracheal intubation is unsuccessful, an emergent surgical airway is required. Antibiotic coverage should target Streptococcus pneumoniae, Staphylococcus aureus, and H. influenzae, with consideration for methicillin­resistant S. aureus (e.g., ceftriaxone and vancomycin). Antibiotics are typically continued for  to  days. Steroids are often used to decrease mucosal edema of the epiglottis. Admit all children with suspected or confirmed epiglottitis to an intensive care unit setting.
BACTERIAL TRACHEITIS
Bacterial tracheitis, also known as membranous laryngotracheobronchitis or bacterial croup, is an uncommon infection that can cause life­threatening upper airway obstruction. It can be a primary or secondary infection. The mean age of presentation is now  to  years of age compared with the 
,26 years of age that has been classically described. The most commonly isolated pathogen obtained from culture at bronchoscopy is S. aureus. Other organisms implicated in bacterial tracheitis include S. pneumoniae, Streptococcus pyogenes, Moraxella catarrhalis, H. influenzae, and oral
25­29 anaerobes.
CLINICAL FEATURES
Bacterial tracheitis often develops secondarily after a viral upper respiratory tract infection, particularly influenza A. A history of upper respiratory infection symptoms followed by sudden worsening with high fever, stridor (often biphasic), and cough (which may be productive with thick sputum) and a toxic appearance suggest the diagnosis. Thick mucopurulent secretions of the trachea can result in upper airway obstruction. Children with tracheitis often complain of sore throat and will point to their trachea when asked where it hurts. There is often tenderness with palpation of the trachea.
DIAGNOSIS
Laboratory studies other than tracheal cultures (typically obtained during bronchoscopy) are of limited use in the diagnosis. Neck radiographs are not needed to make the diagnosis. When obtained to evaluate for other potential diagnostic entities, neck films may show subglottic narrowing of the trachea and irregular tracheal margins in patients with tracheitis (Figure 126­4). Because no single clinical or radiographic feature can definitively make a diagnosis, bronchoscopy is the diagnostic method of choice in bacterial tracheitis.
FIGURE 126­4. Membranous tracheitis. Lateral soft tissue radiograph of the neck in a 13­year­old girl with the acute onset of stridor after  days of sore throat.
Membranes (arrows) are visible in the subglottic region. [Reproduced with permission from Knoop KJ, Stack LB, Storrow AB, Thurman RJ (eds): The
Atlas of Emergency Medicine, 4th ed. McGraw­Hill Education, Inc. © 2016. Fig .87, page 478. Photo contributor: Matthew R. Mittiga, MD.]
TREATMENT
The management of tracheitis is similar to that of epiglottitis, with patients ideally going to the operating room for sedation, intubation, and bronchoscopy. There is no clear benefit from β­agonists or glucocorticoids in bacterial tracheitis. Administer empiric antibiotics in the ED to cover likely pathogens. In children with tracheostomies, prior lower respiratory cultures may also guide initial antibiotic choices. Appropriate choices include vancomycin or clindamycin plus a third­generation cephalosporin. Definitive antibiotic choices depend on cultures and Gram stain of the mucopurulent secretions obtained at the time of bronchoscopy. Bronchoscopy may be therapeutic because the removal of purulent pseudomembranes improves tracheal toilet and may lessen upper airway obstruction. For continued management, most patients with bacterial tracheitis require a definitive airway and ventilatory support.
AIRWAY FOREIGN BODY
Airway foreign body aspiration occurs most commonly in children between  and  years old as a result of increasing mobility and oral exploration.
Foreign body aspiration in children <6 months old often involves a well­meaning sibling who places an object in the infant’s mouth. The most common objects aspirated fall into two groups: food and toys. Commonly aspirated foods include peanuts, sunflower seeds, carrots, raisins, grapes, and hot dogs.
Suspect foreign body aspiration with a history of sudden coughing and choking in the child; this is the most predictive of all signs and symptoms in
30­32 foreign body aspiration. In many cases, the choking episode is not witnessed by a caregiver. Consider foreign body aspiration in a young child with respiratory symptoms, regardless of the duration of symptoms, because many children may present >24 hours after foreign body aspiration. If the clinical scenario clearly indicates the presence of a foreign body or airway obstruction, immediately implement a protocol for obstructed airway management (see Chapter 109, “Resuscitation of Children”).
CLINICAL FEATURES
A history of witnessed choking (sudden onset of cough, shortness of breath) is highly suggestive of airway foreign body, although not always
 observed. Although the location of the aspirated foreign body plays a role in determining the symptoms and signs on presentation, there is great overlap between groups, and some children may be asymptomatic on presentation. “Classic dogma” is that laryngotracheal foreign bodies cause stridor and hoarseness, whereas bronchial foreign bodies cause unilateral wheezing and decreased breath sounds. A large majority of airway foreign bodies are found in the bronchi. Children can develop severe immediate­onset stridor or even cardiopulmonary arrest, but there are a proportion of patients who will remain minimally symptomatic. The most important factor in reducing mortality from an airway foreign body is recognition of the child in acute airway distress.
DIAGNOSIS
Radiographs are helpful to confirm the diagnosis of airway foreign body but should not be used to exclude the diagnosis. Plain
 chest radiographs are normal in >50% of tracheal foreign bodies and 25% of bronchial foreign bodies. More than 75% of airway
,35 foreign bodies in children <3 years of age are radiolucent. Laryngeal and tracheal foreign bodies often constitute an acute emergency, and radiography is omitted. If performed, posteroanterior and lateral neck radiographs are the radiographic examinations of choice. Foreign bodies lodged in the proximal esophagus may also present with airway compression. Tracheal and esophageal foreign bodies can be differentiated on neck radiographs: foreign bodies typically lodge in the trachea in profile and in the esophagus en face. Suspected bronchial foreign bodies can be evaluated with the use of posteroanterior and lateral chest films (Figure 126­5, A and B). Indirect radiologic signs of a radiolucent airway foreign body include unilateral obstructive emphysema, atelectasis, and consolidation. Unilateral obstructive emphysema is seen when a foreign body obstructs airflow, mainly on expiration. This generates a check­valve obstruction that results in hyperinflation of the affected side and potential mediastinal shift to the opposite side. A foreign body that obstructs a bronchus may produce focal atelectasis and consolidation visible on chest films. Inspiratory and expiratory chest radiographs can aid in the diagnosis by showing hyperinflation (air trapping) on expiratory films in cooperative patients (Figure 126­
, A and B). Bilateral decubitus chest films have been used to demonstrate air trapping; however, they increase false positives without increasing true
,36­38 positives, suggesting a lack of clinical benefit. A clinically suspected foreign body aspiration should ultimately be ruled out by bronchoscopy,
,36,37 regardless of the chest radiograph findings.
FIGURE 126­5. (A) Posteroanterior and (B) lateral chest radiographs showing radiopaque bronchial foreign body. [Photos used with permission of W. McAlister, MD,
Washington University School of Medicine, St. Louis, MO.]
FIGURE 126­6. (A) Inspiratory and (B) expiratory chest radiographs showing air trapping on the left with shift of the mediastinum to the right caused by a peanut in the left mainstem bronchus. [Photos used with permission of W. McAlister, MD, Washington University School of Medicine, St. Louis, MO.]
TREATMENT
Children with complete airway obstruction are typically unable to breathe or speak and require emergency basic life support measures to relieve airway obstruction. For detailed discussion, see Chapter 108, “Resuscitation of Neonates,” and Chapter 109, “Resuscitation of Children.” If basic life support maneuvers fail, perform direct laryngoscopy and foreign body extraction with Magill forceps. When the foreign body is not visible or able to be removed, orotracheal intubation with dislodgment of the foreign body more distally (often into the right mainstem bronchus) may relieve complete obstruction and be lifesaving. If the foreign body cannot be removed and ventilation cannot be provided through an endotracheal tube, attempt a surgical airway (needle cricothyroidotomy or emergency tracheostomy). For children with partial airway obstruction, monitor respiratory status closely and arrange for bronchoscopic removal under general anesthesia.
RETROPHARYNGEAL ABSCESS
The retropharyngeal space occupies the space between the posterior pharyngeal wall and the prevertebral fascia and extends from the base of the skull to approximately the level of the second thoracic vertebrae. This space is fused down the midline and contains two chains of lymph nodes extending down each side. An important potential complication is caudal spread into this potential space leading to mediastinitis. These lymph nodes tend to regress by age  years old, obliterating this potential space, which explains the decreasing frequency of retropharyngeal abscess in older children. The formation of a retropharyngeal abscess is believed to be secondary to suppuration of these lymph nodes that have been seeded from a distant infection. Localized penetrating trauma with subsequent invasion of this space by bacteria is another cause of retropharyngeal infection. This most commonly occurs in children who fall with a stick or other similar object in their mouth. Infection can also occur from traumatic esophageal instrumentation or ventral extension of vertebral osteomyelitis. Retropharyngeal infection typically progresses from an organized phlegmon to a mature abscess.
CLINICAL FEATURES
Most cases of retropharyngeal abscess evolve insidiously over a few days after a relatively minor upper respiratory infection or pharyngitis. Fever is
39­41 typically present but may be absent in >10% of patients. Additional signs and symptoms include neck pain, odynophagia, dysphagia, trismus, excessive drooling, and neck swelling. The child may maintain the neck in an unusual position, with stiffness, torticollis, and hyperextension. The voice may be muffled, and anterior cervical lymphadenopathy is common. A unique finding is bulging of the posterior oropharynx. The diagnosis should be
 considered in any child who will not fully extend his or her neck to look up (Bolte’s sign). Abscess progression can lead to stridor and respiratory distress. Pleuritic chest pain is an ominous sign, indicating extension of the infection into the mediastinum.
DIAGNOSIS
Initial imaging includes a soft tissue lateral neck radiograph. The radiograph should be taken during inspiration with the neck extended to limit falsepositive results. The diagnosis of retropharyngeal abscess/cellulitis is suggested when the retropharyngeal space at C2 is twice the diameter of the vertebral body or greater than one half the width of the C4 vertebral body (Figure 126­7). Rarely, gas may be seen within the collection. Contrast­enhanced CT scan may demonstrate necrotic nodes, inflammatory phlegmon, or fluid collection within a ring­enhancing abscess (Figure 126­8). CT is helpful for diagnosing and defining the extent of the infection and surgical planning. However, CT scans are limited in their ability to differentiate between abscess and cellulitis/phlegmon. Therefore, imaging results should be correlated to clinical findings when guiding
39­47 the decision of conservative versus surgical treatment. Unstable patients should be intubated before going to the radiology suite for CT scan.
Patients requiring sedation to obtain a scan may require presedation intubation if airway obstruction is present. A provider accustomed to managing the difficult pediatric airway should escort patients without airway compromise to radiology, and appropriate equipment should accompany the patient.
FIGURE 126­7. Lateral soft tissue neck radiograph demonstrating retropharyngeal swelling (arrow).
FIGURE 126­8. Contrast­enhanced neck CT showing a retropharyngeal fluid collection (arrow).
TREATMENT
Carefully monitor and stabilize the airway. Obtain IV or IO access to administer fluids, antibiotics, and CT contrast. Most retropharyngeal abscesses are
,40 found to contain mixed flora when cultured. Common organisms include S. aureus, S. pyogenes, Streptococcus viridans, and β­lactamase– producing gram­negative rods. Oral anaerobes are also frequently seen. Retropharyngeal cellulitis and small, localized abscesses may be treated successfully with antibiotic therapy alone. All other cases should undergo operative incision and drainage, usually by an otolaryngologist. Initiate empiric antibiotic therapy in the ED with clindamycin (15 milligrams/kg per dose every  hours IV) or ampicillin­sulbactam (50 milligrams/kg per dose every  hours IV). Unusual complications of retropharyngeal abscess include airway obstruction, spontaneous abscess perforation, mediastinitis, sepsis, aspiration, and jugular venous thrombophlebitis/thrombosis, also known as Lemierre’s syndrome.
PERITONSILLAR ABSCESS
Peritonsillar abscess, also known as a quinsy, is a posterior oropharyngeal infection. It can occur in patients of any age, but most commonly occurs in adolescents and young adults. The disease typically begins as a superficial infection that progresses to an accumulation of pus in a space between the tonsillar capsule and the superior constrictor muscle. Most are unilateral, whereas <10% are bilateral at the time of diagnosis. Most peritonsillar
 abscesses are polymicrobial infections. Predominant organisms include anaerobes, group A β­hemolytic streptococci, S. aureus, and H. influenzae.
CLINICAL FEATURES
Patients with peritonsillar abscess typically present with sore throat (often unilateral), fever, chills, trismus, and voice change (“hot potato voice”).
Patients will often complain of “the worst sore throat” of their life and may drool due to difficulty swallowing their saliva. Ipsilateral ear pain and torticollis may be present. On examination, bulging of the affected tonsil and deviation of the uvula away from the involved tonsil are evident (Figure
126­9). Differentiating peritonsillar cellulitis from peritonsillar abscess can be difficult. If the child is toxic, consider a peritonsillar abscess until proven otherwise.
FIGURE 126­9. Examination of the oropharynx illustrating unilateral bulging palate and erythema of the left peritonsillar fossa with the uvula mildly deviated to the contralateral side. [Reproduced with permission from Goldman L, Ausiello D: Cecil Medicine, 23rd ed. Philadelphia, PA: Saunders Elsevier; 2008.]
DIAGNOSIS
Peritonsillar abscess is typically a clinical diagnosis, and routine laboratory or imaging studies are not needed. If drainage is performed in the ED, send purulent material for Gram stain and culture. Cases without typical exam findings may require imaging to distinguish cellulitis from abscess. US
(intraoral or submandibular) may be helpful in cooperative children. For cases in which deep space neck infection is a consideration, imaging with CT using IV contrast is often helpful. As mentioned earlier, lateral radiographs of the neck may identify retropharyngeal abscess.
TREATMENT
Most cases of peritonsillar abscess are managed as outpatients with prompt aspiration or incision and drainage using local anesthetics in the ED.
Young and uncooperative children may require procedural sedation to facilitate adequate evaluation and drainage. Complications of needle aspiration and incision and drainage include hemorrhage, puncture of the carotid artery, and airway aspiration of purulent material. Younger children
 with few prior episodes of tonsillitis and small abscesses may respond to oral antibiotics without the need for drainage. In non–toxic­appearing adolescents with good follow­up and findings most consistent with peritonsillar cellulitis, a trial of oral antibiotics is also reasonable. Empiric coverage includes amoxicillin­clavulanate (45 milligrams/kg per dose every  hours to a maximum of 875 milligrams per dose) or clindamycin (10 milligrams/kg per dose every  hours). Adjunct therapy with single high­dose steroid administration seems to improve symptoms in patients with peritonsillar
 abscess after drainage.
LUDWIG’S ANGINA
Ludwig’s angina is a potentially life­threatening, rapidly expanding infection of the submandibular space. The submandibular space is composed of two spaces subdivided by the mylohyoid muscle into the sublingual and submylohyoid space (submaxillary space) and extends from the floor of the mouth to muscular attachments at the hyoid bone. Infectious expansion into this space spreads superiorly and posteriorly and often involves the entire submandibular space (Figures 126­10 and 126­11). Most cases arise from an odontogenic source, often from the spread of periapical abscesses of mandibular molars. Infection is typically polymicrobial involving oral flora.
FIGURE 126­10. Spread of infection within the submandibular space of the neck.
FIGURE 126­11. CT showing soft tissue stranding and inflammation representing infection in the submandibular space (arrow) in a patient with Ludwig’s angina.
Ludwig’s angina usually begins with a mild infection that progresses rapidly to include fever, chills, severe mouth pain, drooling, trismus, tongue protrusion, and brawny neck swelling. The child may maximize airway diameter by assuming a “sniffing position.” Stridor may develop with subsequent progressive airway obstruction. Control the airway early, because intubation can be extremely difficult late in the clinical course of the
 disease. Treatment includes empiric antibiotics and oral surgery to remove the dental abscess that is the source of the infection. IV antibiotics should cover β­lactamase–producing aerobic or anaerobic gram­positive cocci and gram­negative bacilli (e.g., ampicillin­sulbactam or clindamycin or
,52 penicillin G). Consider additional coverage for community­acquired methicillin­resistant S. aureus in those at risk for colonization.
DIPHTHERIA
Diphtheria is an acute toxin­mediated disease caused by Corynebacterium diphtheria, a gram­positive non–spore­forming bacillus, and has largely been eradicated in developed nations through widespread vaccination. It is transmitted from person to person through respiratory secretions or skin lesions. In cases of pharyngeal diphtheria, symptoms include sore throat, malaise, dysphagia, and low­grade fever. Characteristic thick gray membranes (pseudomembranes) can develop over the tonsils and soft palate and potentially cause respiratory obstruction and death. Laryngeal diphtheria is characterized by a classic “barking” cough, stridor, hoarseness, and difficulty breathing, accompanied by marked edema of the neck referred to as “bull neck.”
Complications include myocarditis and neuritis potentially leading to diaphragmatic paralysis and death from respiratory failure. Diagnosis is confirmed by isolation of bacteria by culture of a nasopharyngeal swab. Treatment includes antitoxin, antibiotics, and respiratory support as needed.
OROPHARYNGEAL TRAUMA
Traumatic oropharyngeal injuries in children typically occur during a fall with an object within the mouth. Such injuries are often referred to as “pencil injuries” and most commonly occur in patients between  and  years of age. When evaluating these injuries, ask if the entire foreign body was removed intact or if part of the object may have broken off into the soft tissue. Pencils, straws, toothbrushes, and toothpicks are the most common
53­55 culprits.
There are rare, but well­known complications of penetrating pharyngeal injury. Entrance of free air into the neck or chest can result in stridor and acute airway obstruction. Subsequent retropharyngeal infection from introduction of oral flora/bacteria into the penetrating wound can occur. A more severe complication of oropharyngeal trauma is carotid artery injury, as the carotid artery courses along the lateral aspect of the oropharynx and is therefore at risk of injury from both blunt and penetrating impact forces. Penetrating injury can result in anything from hematoma formation to massive hemorrhage. Blunt injuries can cause compression of the carotid artery between the object and upper cervical vertebrae. The resultant shearing effect can cause an intimal tear in the vessel with subsequent thrombosis formation. Problems such as neck/mediastinal emphysema, retained foreign bodies, abscess formation, thrombosis, and arterial dissection should be considered, as these findings may be delayed after time of presentation. Symptoms may evolve over hours to days and can result in significant neurologic sequelae (stroke in the distribution of the common carotid territory).
CLINICAL FEATURES
Children with acute oropharyngeal trauma may present with bleeding, drooling, or dysphagia. Children may also present in a delayed fashion with complications of oropharyngeal trauma such as retropharyngeal abscess (discussed separately earlier), or even neurologic symptoms of stroke in cases of carotid artery injury or thrombosis from prior trauma.
DIAGNOSIS
Neither mechanism nor degree of injury is helpful in determining the possibility of neurovascular compromise. Soft tissue lateral neck films can assist in the evaluation of air in soft tissues, radiopaque foreign bodies, and evaluating for abscess. CT is superior to plain radiographs for the detection of free air, inflammation, or abscess. No consensus or specific clinical criteria exist with regard to advanced imaging for vascular injury. CT angiography is necessary if carotid injury is suspected and should be considered for patients who are unstable or have neurologic sequelae, who cannot be
,56 adequately assessed, and for whom lateral pharyngeal trauma raises concern for vascular injury. The risks of radiation from CT may outweigh the
 potential benefits in well­appearing children, however.
TREATMENT
Most wounds do not require surgical intervention and closure, but large gaping wounds and those with persistent bleeding may require closure under sedation or anesthesia. Lateral wounds adjacent to the path of the carotid artery have a greater risk of arterial injury than more midline injuries, and those involving the soft palate have higher infectious complication rates than those limited to the hard palate. Oral wounds are tetanus prone, and prophylaxis should be given to unimmunized children. The incidence of infectious complications following penetrating palate trauma is approximately

1%, and thus the role of prophylactic antibiotics is unclear.


