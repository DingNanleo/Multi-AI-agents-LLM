## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 228: Hypothyroidism and Myxedema Crisis
Alzamani Mohammad Idrose
INTRODUCTION AND EPIDEMIOLOGY
Hypothyroidism is a clinical syndrome caused by insufficient thyroid hormone production, which slows cell metabolism. The prevalence of overt
1­4 hypothyroidism in the general population varies between .3% and .7% in the United States, and between .2% and .3% in Europe. The prevalence
 of hypothyroidism increases with age (>65 years) and is higher among white individuals and women. The disorder is nearly  times more common in females than in males. On the other hand, subclinical hypothyroidism is more prevalent than overt hypothyroidism in all age groups and can be seen in

4% to 15% of women, especially the elderly. Myxedema coma mortality rates with current treatments are between 30% and 60%.
PATHOPHYSIOLOGY
Thyroxine (T ) and triiodothyronine (T ) are the thyroid hormones. The ratio of thyroxine T to triiodothyronine T released in the blood is about 10:1.    
Peripherally, thyroxine T is converted to the active triiodothyronine T , which is three to four times more potent than thyroxine T . The half­life of
   thyroxine T is  days, and the half­life of triiodothyronine T is about  day.

Primary hypothyroidism is caused by the intrinsic dysfunction of the thyroid gland. The most common cause is Hashimoto’s thyroiditis. Primary
 hypothyroidism is also caused by surgical removal or radioactive ablation and can be a result of some drug effects. Drugs such as lithium, α­ interferon, interleukin, and tyrosine kinase inhibitors (e.g., sunitinib) can cause hypothyroidism. Amiodarone can cause hypothyroidism in up to 14%
8­10 of patients.
Secondary hypothyroidism is caused by a deficiency of thyroid­stimulating hormone (TSH) from the pituitary gland or deficiency of thyrotropin­
,12 releasing hormone from the hypothalamus. Some literature specifically refers to hypothalamic causes as tertiary hypothyroidism. Nevertheless, both are central causes of hypothyroidism involving the hypothalamic­pituitary axis and shall be referred to as secondary hypothyroidism in this chapter.
Euthyroid sick syndrome is associated with low triiodothyronine T or thyroxine T levels and a normal or low TSH level in a patient who is clinically
  euthyroid. This condition is found in critically ill patients or those with severe systemic illness.
Table 228­1 lists common causes of hypothyroidism.
TABLE 228­1
Common Causes Primary and Secondary of Hypothyroidism
Secondary Hypothyroidism (disorders of hypothalamic­pituitary
Primary Hypothyroidism (disorders of thyroid gland) axis)
Autoimmune disease (e.g., Hashimoto’s thyroiditis) Panhypopituitarism
Thyroiditis Pituitary adenoma, hypothalamic tumor
Iodine deficiency Infiltrative disorders (hemochromatosis, sarcoidosis)
After ablation (surgery, radioiodine) Brain irradiation
Infiltrative thyroid disease (lymphoma, sarcoid, tuberculosis) CNS infection

Drugs directly affecting thyroid function
Chapter 228: Hypothyroidism and Myxedema Crisis, Alzamani Mohammad Idrose 
Valproate
. Terms of Use * Privacy Policy * Notice * Accessibility
Potassium perchlorate
Iodine
α­Interferon
Interleukin­2
Amiodarone
Lithium
Sunitinib
Antituberculosis drugs (ethionamide and para­aminosalicylic acid
[PAS])
Retroviral agents
CLINICAL FEATURES OF HYPOTHYROIDISM
The common clinical features of hypothyroidism are listed in Figure 228­1. Additional cardiopulmonary findings include angina, bradycardia, distant
 heart sounds from pericardial effusion, low voltage on the ECG, pleural effusions, cardiomyopathy, or hypoventilation. Figure 228­2 shows an example of severe pretibial myxedema. Table 228­2 describes the clinical differences between primary and secondary hypothyroidism.
FIGURE 228­1. Signs and symptoms of hypothyroidism.
FIGURE 228­2. Mysedema (non­pitting edema) in a patient with hypothyroidism. (Image courtesy of Dr. Zanariah Hussein.)
TABLE 228­2
Clinical Differentiation of Primary and Secondary Hypothyroidism
Features Primary Hypothyroidism Secondary Hypothyroidism
Previous thyroid operation Yes None
Obese More obese Less obese
Hypothermia More common Less common
Voice Coarse Less coarse
Pubic hair Present Absent
Skin Dry and coarse Fine and soft
Heart size Increased Normal
Menses and lactation Normal No lactation, amenorrhea
Sella turcica size Normal May be increased
Serum TSH Increased Decreased
Plasma cortisol Normal Decreased
Response to TSH None Good
Response to levothyroxine without steroids Good Poor response
Abbreviation: TSH = thyroid­stimulating hormone.
CLINICAL FEATURES OF MYXEDEMA CRISIS
Myxedema crisis is a state of metabolic and multiorgan decompensation characterized by uncorrected hypothyroidism, mental status changes or coma, and hypothermia (usually <35.5°C [95.9°F]). In hypothyroid patients, myxedema crisis can be precipitated by a number of conditions, including infection, anesthetic agents, cold exposure, trauma, myocardial infarction or congestive heart failure, stroke, GI hemorrhage, surgery, burns, medications (e.g., β­blockers, sedatives, narcotics, phenothiazine, amiodarone), or thyroid medication noncompliance.
The characteristic hypothyroid habitus is evident (Figure 228­1), as well as bradycardia, hypotension, hypothermia, hypoventilation, and altered mental status or coma. Blood pressure is quite variable, but of patients in full myxedema crisis, half initially exhibit clinical shock with systolic blood pressure <100 mm Hg. The capillaries are “leaky,” and this may contribute to hypotension. Infection may be present even though fever, tachycardia and sweating may not be evident, because bradycardia and hypothermia mask these signs. Altered mental status can result from CO narcosis or
 hypoglycemia. Pleural effusions are frequently demonstrable. Other potential respiratory problems include upper airway obstruction from glottic edema, vocal cord edema, and macroglossia. Metabolism of tranquilizers, sedatives, and anesthetics is reduced in hypothyroidism, and the exaggerated effects of such medications can also contribute to altered mental status. Hypothermia is so common in myxedema crisis that a normal temperature should suggest an underlying infection. Hypothyroid habitus, absence of shivering, and pseudomyotonic reflexes
(prolonged relaxation phase of deep tendon reflexes—at least twice as long as the contraction phase) may help distinguish myxedema crisis from accidental hypothermia.
DIAGNOSIS
The diagnosis of hypothyroidism is based on laboratory testing. The diagnosis of myxedema crisis is clinical. The differential diagnoses include sepsis, depression, adrenal crisis, congestive heart failure, hypoglycemia, stroke, hypothermia, drug overdose, and meningitis.
LABORATORY EVALUATION AND IMAGING
Obtain baseline levels of TSH, thyroxine T , triiodothyronine T , and cortisol before initiating treatment. This facilitates eventual diagnosis as well as
  response to treatment.
High TSH, with low total or free thyroxine T and triiodothyronine T , confirm primary hypothyroidism. Low TSH with low total or free thyroxine T and
   triiodothyronine T points toward secondary hypothyroidism (hypothalamic–pituitary etiology). The assays of free thyroxine T and triiodothyronine

T are preferable to total thyroxine T and triiodothyronine T , as results are more accurate and not affected by protein binding.

Thyroid hormone levels may also be altered as a result of drug interactions (Table 228­1), but thyroid function usually normalizes after discontinuation of these drugs. Ideally, thyroid function tests should be obtained before initiating therapy with these agents and periodically thereafter.
Menorrhagia can be a sign of hypothyroidism, and if menorrhagia is severe, microcytic anemia due to iron loss can develop. Hyponatremia due to increased antidiuretic hormone and impaired free water clearance is common. Hypoglycemia may be present due to decreased gluconeogenesis, decreased insulin clearance, and concomitant adrenal insufficiency or growth hormone deficiency. Arterial blood gases typically show hypoxemia, hypercapnia, metabolic acidosis from tissue hypoxia, and respiratory acidosis from hypoventilation due to muscle weakness.
Further laboratory assessment depends on the differential diagnosis, comorbidities, and search for precipitating factors. Obtain an ECG to identify myocardial infarction or heart block. Chest radiograph is needed to identify pneumonia, pleural effusion, or cardiomegaly. Bedside ultrasound can detect pericardial and pleural effusions.
TREATMENT OF SYMPTOMATIC HYPOTHYROIDISM
If a hypothyroid patient has symptoms of hypothyroidism and has been noncompliant with thyroid medication, or a newly diagnosed hypothyroid patient is confirmed by thyroid function tests done in the ED, oral levothyroxine may be started. The average starting dose for healthy adults younger
 than age  is  micrograms of oral levothyroxine once a day. For those older than  years or with cardiac disease, the initial dose is lower, .5 to
 micrograms once a day. For all adults, the dose is adjusted by .5­ to 25­microgram increments at 4­ to 6­week intervals. Instruct the patient to follow up with the primary care physician or endocrinologist for monitoring and further dose adjustments in a month.
TREATMENT OF MYXEDEMA CRISIS
Myxedema crisis treatment consists of supportive care, thyroid hormone replacement (supplementing with thyroxine T , triiodothyronine T , or a
  combination of both), and identification and treatment of precipitating factors (Table 228­3).
TABLE 228­3
ED Treatment for Myxedema Crisis
Supportive care
Airway, breathing, and circulation: airway control, oxygen, IV access, and cardiac monitoring
IV therapy: dextrose for hypoglycemia; water restriction for hyponatremia
Vasopressors: if indicated (ineffective without thyroid hormone replacement)
Hypothermia: treated with passive rewarming
Steroids: hydrocortisone (due to increased metabolic stress; start with 100–200 milligrams IV)
Thyroid replacement therapy (see discussion of thyroid hormone replacement in text)
IV thyroxine (levothyroxine) at  micrograms/kg (typically between 200 and 400 micrograms as initial dose), followed in  h by 100 micrograms IV, then  micrograms IV until oral medication is tolerated. Starting dose of thyroxine in the elderly is 100 micrograms IV.
OR
IV triiodothyronine (liothyronine) at a dose of  micrograms IV followed by  micrograms IV every  h until the patient is conscious.
Start with no more than  micrograms IV for the elderly or those with coronary artery disease. (Triiodothyronine is less preferred in patients with cardiac disease, as its potency could precipitate cardiac arrhythmias or infarction.)
Note: Start with IV levothyroxine first. IV liothyronine can be added if treatment with IV levothyroxine alone is not effective or in patients with persistent hemodynamic instability or poor respiratory effort.
Identify and treat precipitating and comorbid factors
Infections
Sedatives
Cold exposure
Trauma
Myocardial infarction or congestive heart failure
Cerebrovascular accident
GI hemorrhage
Hypoxia
Hypercapnia
Hyponatremia
Hypoglycemia
THYROID HORMONE REPLACEMENT FOR MYXEDEMA CRISIS
Administer thyroid hormone upon clinical suspicion of myxedema crisis, as confirmatory laboratory thyroid hormone levels will not be available initially. IV thyroxine (T ) in the form of levothyroxine should be started as replacement. Alternatively, IV triiodothyronine (T ) in the form of
  liothyronine (synthetic triiodothyronine T ) can be given if it is available, but should be cautiously used in the elderly or those with cardiac disease as it
 is more potent. IV thyroxine T and IV triiodothyronine T can be given together if the patient has persistent hemodynamic instability or poor
  respiratory effort.
Thyroid hormone replacement should initially be given IV because severe or even mild hypothyroidism results in decreased intestinal motility and GI absorption. Once intestinal motility recovers, oral medication can be given.
Replacement with Intravenous Thyroxine (Levothyroxine)
Levothyroxine is the synthetic form of thyroxine. The initial dose for myxedema crisis is  micrograms/kg IV, with the usual starting dose from 200 to

400 micrograms IV. This is followed in  hours by 100 micrograms IV, then  micrograms IV until oral medication is tolerated. Starting dose in the elderly is lower at 100 micrograms IV. The advantages of levothyroxine are smooth, slow, and steady onset of action and its widespread availability. Disadvantages include the fact that extrathyroidal conversion of thyroxine T to triiodothyronine T may be reduced in myxedema crisis.

The onset of action of thyroxine T is longer than that of triiodothyronine T .

Replacement with Intravenous Triiodothyronine (Liothyronine)
Liothyronine is the synthetic form of triiodothyronine T . In myxedema crisis, the loading dose of  micrograms can be given, followed by a

 maintenance dose of  micrograms every  hours until oral medication can be given. The advantage of triiodothyronine T over thyroxine T is that
  the deiodinase conversion of thyroxine T to the active hormone triiodothyronine T is reduced in myxedema crisis. IV triiodothyronine T also has a
   rapid onset of action, between  and  hours. triiodothyronine T crosses the blood–brain barrier more readily than thyroxine T . However, the
  disadvantages of IV triiodothyronine T are its more potent effect and fluctuating serum levels and its potency, which can cause cardiac arrhythmias or
 myocardial ischemia, especially in the elderly or those with cardiac disease. If IV triiodothyronine T is given, provide continuous cardiac monitoring
 and obtain interval ECGs to identify myocardial ischemia.
Supportive Management
Supportive measures should be directed at treating hypothermia, hypoventilation, and hyponatremia, volume depletion, and hypoglycemia. For myxedema crisis, give a stress dose of hydrocortisone (100 to 200 milligrams IV) at the start of therapy. Obtain serum cortisol levels prior to initiation of
,16 therapy, but it is not necessary to wait for results. If sepsis is possible or likely, give empiric broad­spectrum antibiotics.
DISPOSITION AND FOLLOW­UP

Myxedema crisis carries a high mortality rate, ranging from 30% to 60% depending on comorbid diseases. Factors such as advanced age, bradycardia, and persistent hypotension suggest a poor prognosis. All patients with myxedema crisis require intensive care unit admission. Milder hypothyroidism patients may only be discharged with a clear plan of management with follow­up by either an endocrinologist or primary care physician.
SPECIAL SITUATIONS
PREGNANT WOMEN

Overt hypothyroidism is seen in about 1% to 2% of pregnant women. Subclinical hypothyroidism is seen in another .5%.
Pregnancy increases the requirement of thyroid hormone because of the increased rate of metabolism in the mother and the transplacental transport of thyroid hormone, which is essential for the development and maturation of the different organs of the fetus. For women who are being treated for
 hypothyroidism, the dose of thyroxine T should be increased by approximately 30% as soon as the pregnancy is confirmed. The thyroid function
 should be checked every  weeks. Thyroid function test results during pregnancy may be difficult to interpret. This is because pregnant women may have a higher production of thyroid hormone from stimulation of the thyroid gland by human chorionic gonadotropin, which has a similar structure to that of TSH. In addition, increased estrogen during pregnancy results in higher levels of thyroid­binding globulin, which transports thyroid hormone in the blood. Therefore, a normal thyroid hormone level in a pregnant woman may not mean the patient is euthyroid, especially if the patient has symptoms of hypothyroidism. Thyroid hormone replacement may still be required in such a case.
Hypothyroidism is diagnosed in pregnancy if patients have symptoms and, in general, have high levels of TSH and low free thyroxine T . Subclinical
 hypothyroidism in pregnancy can be identified if the test results show high levels of TSH and normal free thyroxine T . Subclinical hypothyroidism
 should be treated to ensure a healthy pregnancy.
In myxedema crisis, IV levothyroxine is used for pregnant women. It is safe for the fetus.
ELDERLY/CARDIAC PATIENTS
Age and the presence of cardiac comorbidities are associated with a poor outcome in myxedema crisis. Standard doses of thyroxine T , and especially
 of triiodothyronine T , can precipitate cardiac arrhythmias. When required, start with no more than half the recommended dose of thyroxine T or
  triiodothyronine T for elderly patients.

THE ASYMPTOMATIC PATIENT WITH A PALPABLE NODULE IDENTIFIED IN THE ED
Solitary thyroid nodules are a common physical finding in the general population. Although most are benign colloid nodules that will disappear over time, a small percentage of solitary nodules are thyroid carcinomas. Refer for fine­needle aspiration biopsy.
THYROXINE HORMONE OVERDOSE
Levothyroxine is the most widely used agent for thyroid replacement. When taken in overdose, symptoms do not occur until  hours later as a result of metabolic conversion of thyroxine T to triiodothyronine T . The symptoms may present earlier if triiodothyronine T is ingested. Treatment is not
   standardized. For acute ingestion, activated charcoal can be given. Cholestyramine can increase fecal elimination, and propranolol can control tachycardia and anxiety.


