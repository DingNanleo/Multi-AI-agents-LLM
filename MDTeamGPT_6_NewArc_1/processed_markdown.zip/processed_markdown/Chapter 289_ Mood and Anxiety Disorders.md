## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 289: Mood and Anxiety Disorders
Tracy M. DeSelm
INTRODUCTION
Mood disorders, which include depressive disorders and bipolar disorders, are the most common mental health complaints presenting to the ED,
 accounting for about half of mental health–related visits, behind anxiety and substance use disorders (about 25% each). Trends for ED visits for
2­5 depressive disorders, bipolar disorders, and suicide ideation are sharply increasing. The prevalence of depression and bipolar disorders in the ED
 patient population is twice that of the general population. This chapter discusses the depressive disorders, bipolar disorders, and anxiety disorders.
Substance use disorders are discussed in detail in Chapter 292. DEPRESSIVE DISORDERS

Depressive disorders appear to affect women twice as often as men. Adolescents, the elderly (especially nursing home patients), and people living
 below the poverty level appear to be particularly vulnerable populations for depression. Increased rates of depressive disorders are seen with chronic
,11    illnesses, including CNS diseases, cardiovascular disorders, cancer, and chronic obstructive pulmonary disease.
PATHOPHYSIOLOGY
The pathophysiology of depressive disorders includes genetic, biological, and psychosocial factors. A genetic predisposition heightens
,16 17­19 susceptibility. Malfunctioning monoamine neurotransmitters (especially serotonin, norepinephrine, and dopamine) are implicated and may explain the effectiveness of some current medical therapies. Abnormal γ­aminobutyric acid and glutamate levels in various areas of the brain have
 been noted. Abnormal neurocircuitry that links the prefrontal cortex to the amygdala, ventral striatum and pallidum, medial thalamus,
 hypothalamus, and the periaqueductal gray areas has been shown in mood disorders. Early childhood stress may alter corticotropin­releasing
,23 hormone cells in the hypothalamus to heighten future stress responses.
A large number of medical disorders, medications, and substances of abuse may cause depressive symptoms (Table 289­1). A thorough history, examination, and appropriate laboratory studies will help differentiate the disorders. Strongly consider medical causes of the depressive symptoms in patients with new­onset symptoms of depression, in the elderly, and in those with complex medical problems.
TABLE 289­1
Differential Diagnosis of Depression
Neurologic: CNS infection, CNS tumor, cerebrovascular accident, Alzheimer’s disease, traumatic brain injury, multiple sclerosis, Parkinson’s disease,
Huntington’s disease, normal pressure hydrocephalus
Endocrine/metabolic: hypothyroidism, hyperthyroidism, Addison’s disease, Cushing’s disease, hyperparathyroidism, hypoglycemia, porphyria, severe anemia
Infectious: meningitis, encephalitis, Lyme disease, human immunodeficiency virus, encephalopathy, Epstein­Barr virus, tertiary syphilis
Inflammatory: systemic lupus erythematosus
Medication side effects: steroids, neurologic or psychiatric medications (especially withdrawal from), β­blockers, calcium channel blockers, hormone therapies, chemotherapy drugs
Substances of abuse: withdrawal from cocaine and amphetamines, alcohol, opiates
Other psychiatric disorders: bipolar, posttraumatic stress disorder, substance abuse, anxiety disorder

Chapter 289: Mood and Anxiety Disorders, Tracy M. DeSelm 
. Terms of Use * Privacy Policy * Notice * Accessibility
CLINICAL FEATURES OF DEPRESSION
The most common type of depressive disorder is major depressive disorder. Clinical features are listed in Table 289­2. Depressive disorders are often
,25 unrecognized in the ED, as the investigation of somatic complaints usually takes priority during patient evaluation. Vague complaints and repeat

ED visits, especially in patients with nonspecific abdominal pain, suggest the need for additional questioning regarding symptoms of depression.
The two simple questions in the Patient Health Questionnaire­2 have been validated as a screening tool for depressive disorders in the primary care
 setting but may also be useful in the ED:
. During the past month, have you been bothered by feeling down, depressed, or hopeless?
. During the past month, have you been bothered by little interest or pleasure in doing things?
TABLE 289­2
Diagnostic Criteria for Major Depressive Disorder* Depressed mood
Anhedonia (decreased interest or pleasure)
Significant weight loss or gain
Insomnia or hypersomnia
Psychomotor retardation or agitation
Fatigue or loss of energy
Feelings of worthlessness or excessive guilt
Difficulty with concentration or indecisiveness
Suicidal ideation, with or without a plan
*The patient needs to have five or more of the symptoms for  weeks; one symptom has to be depressed mood or anhedonia. Symptoms cannot be due to substance abuse or a medical condition. Symptoms must be significant enough to impair normal functioning.
Source: Data from Diagnostic and Statistical Manual of Mental Disorders, 5th ed. Arlington, VA: American Psychiatric Association; 2013. 29­31 
Other screening tools used in the primary care setting include the SAD PERSONS scale, Patient Health Questionnaire­9 Self­Assessment Tool, the

Geriatric Depression Scale, and the Beck Depression Inventory for Primary Care.
DETERMINATION OF SUICIDE RISK
The most important part of the evaluation of depression is the assessment of suicide risk. Use straightforward, nonjudgmental questions regarding the patient’s suicide or homicidal thoughts or intent, and seek corroborative information from family members, friends, law enforcement,
EMS, and outside providers. If the patient is at potential risk for harm to self or others, perform a thorough search for weapons, medicines, and potentially harmful items; place the patient in a safe environment with monitoring; and consider initiating a precautionary, safety, or involuntary hold.
Complete the appropriate history taking (including potential access to guns) with outside source verification, physical examination to include a mental status evaluation, and laboratory studies. Detailed evaluation of patients with mental health disorders is provided in Chapter 286, “Mental Health

Disorders: ED Evaluation and Disposition.” Alcohol and drug abuse are important suicide risk comorbidities. Patients cannot be adequately evaluated for depression or suicidal intent until they are no longer intoxicated. This does not necessarily mean an alcohol level of , but rather a return to normal or baseline cognition.

A guide for the evaluation of suicide risk and disposition determination in ED patients is provided by the Suicide Prevention Resource Center and begins with the Decision Support Tool (Table 289­3).
TABLE 289­3
Suicide Prevention Resource Center Decision Support Tool36* Transition question: Confirm suicidal ideation. Have you had recent thoughts of killing yourself? Is there other evidence of suicidal thought, such as reports from family or friends? This confirms that suicide risk exists and one should move forward to questions  to . A “yes” response to any question below indicates the need for emergency psychiatric consultation.
. Thoughts of carrying out a plan. Have you been thinking about how you might kill yourself?
. Suicide intent. Do you have intention of killing yourself?
. Past suicide attempt. Have you ever tried in the past?
. Significant mental health conditions. Have you had treatment for mental health problems?
. Substance use disorder. Do you have a history of alcohol or substance abuse? Have you used drugs or medication for nonmedical reasons in the past month?
. Irritability/agitation/aggression. Have you been feeling anxious or agitated? Having conflicts or getting into fights? Is there direct evidence of irritability, agitation, or aggression?
Source: Suicide Prevention Resource Center. (2015). Caring for adult patients with suicide risk: A consensus guide for emergency departments. Waltham, MA:
Education Development Center, Inc. www.sprc.org/ed­guide.
If the patient answers yes to any of the questions in Table 289­3, then an emergency psychiatric consultation is warranted. If all answers are “no,” then a brief intervention is suggested to include follow­up resources. The Emergency Department Safety Assessment and Follow­Up Evaluation study demonstrated that a brief intervention in the ED, including resources and a follow­up phone call for at­risk patients who are being discharged, showed
 an absolute reduction in suicide attempt risk by 5%.
TREATMENT OF DEPRESSIVE DISORDERS
Antidepressants are usually prescribed by primary care physicians or psychiatrists for depression, neurogenic pain, or smoking cessation. The side effect profiles, potential serious adverse effects, and toxicities of common antidepressants are reviewed in Table 289­4 and in the Toxicology section of this text. Antidepressant therapy is typically not initiated in the ED, although resumption of a well­tolerated, recently stopped medication may be considered. Antidepressants take about  to  weeks to have clinical effects and may initially place a patient at increased risk of suicide. Ideally, ED antidepressant prescriptions should be discussed with the follow­up practitioner and should include an arranged visit within a week. Antidepressants may pose fetal risk, so the risks and benefits during pregnancy and lactation must be weighed carefully under the guidance of a psychiatrist and obstetrician. The major categories of antidepressants in use today are the selective serotonin reuptake inhibitors (SSRIs), serotoninnorepinephrine reuptake inhibitors (SNRIs), and atypical antidepressants (Table 289­4). Heterocyclic antidepressants and monoamine oxidase inhibitors are used infrequently due to adverse effects and drug–drug interactions.
TABLE 289­4
Commonly Used Antidepressants in the United States
Agent
Mechanism of Common Adverse Starting
(Generic/Brand Comments
Action Effects of Class Dose
Names)
Selective serotonin Block presynaptic N/V, drowsiness, HA, Insufficient clinical studies to determine safety in pregnancy reuptake inhibitors serotonin uptake dizziness, insomnia,
(SSRIs) agitation, mania, paresthesias, sexual/cognitive dysfunction, weight gain
Citalopram/Celexa® 10–20 Lower doses if anxiety prominent milligrams once a day
Fluoxetine/Prozac® 10–20 First line for children/adolescents milligrams once a day
Fluvoxamine/Luvox®  More sedating, shorter half­life milligrams at night
Paroxetine/Paxil® 10–20 More anticholinergic, more sedating, more withdrawal milligrams symptoms once a day
Sertraline/Zoloft® 25–50 Okay in breastfeeding patients milligrams once a day
Escitalopram/Lexapro® 5–10 Okay in breastfeeding patients milligrams once a day
Serotonin Blocks presynaptic Same as for SSRIs, Insufficient clinical studies to determine safety in pregnancy norepinephrine serotonin and except less sexual reuptake inhibitors norepinephrine dysfunction, elevated
(SNRIs) uptake BP, urinary hesitancy/retention
Duloxetine/Cymbalta®  More withdrawal symptoms; may increase anxiety milligrams once a day
Venlafaxine/Effexor® .5–50 More withdrawal symptoms milligrams once a day
Desvenlafaxine/Pristiq®  Synthetic active metabolite of venlafaxine milligrams once a day
Atypicals
Bupropion/Wellbutrin®, Dopamine and Seizures, dry mouth, 50–75 When used with linezolid can precipitate serotonin syndrome
Zyban norepinephrine nausea, agitation and milligrams Seizures associated with doses >450 milligrams; contraindicated
Bupropion/Wellbutrin® reuptake inhibitor irritability, aggressive  times a if underlying seizure disorders or risk factors for seizure; history sustained release behavior, insomnia, HA day of anorexia or bulimia; abrupt discontinuation of alcohol,
Bupropion/Wellbutrin® 150 benzodiazepines, or antiepileptic drugs; less sexual extended release milligrams dysfunction, less weight gain, used for smoking cessation once a day, increase to twice a day after  days
Mirtazapine/Remeron® DA and NE Dry mouth, nausea,  More weight gain, more sedation, good choice for oncology reuptake inhibitor restlessness, insomnia, milligrams patients with failure to thrive
Increases release HA, pharyngitis, once a day of NE, serotonin constipation, dizziness, by antagonizing somnolence, weight inhibitor receptors gain, malaise
Trazodone/Desyrel® Serotonin Marked sedation,  Also used in insomnia, prominent sedation antagonist and priapism, orthostatic milligrams reuptake inhibitor; hypotension, once a day antagonist at ventricular histamine and α­ dysrhythmias in adrenergic patients with known receptors cardiac disease
Heterocyclics Blockage of Cardiotoxic: prolonged presynaptic QTc/AV block reuptake of NE, Anticholinergic: serotonin sedation, dry mouth, tachycardia, constipation
Amitriptyline/Elavil®  Also used for chronic/neurogenic pain control, low therapeutic milligrams index once a day
Nortriptyline/Pamelor®  Metabolite of amitriptyline, although less sedating milligrams at night
Abbreviations: AV = atrioventricular; BP = blood pressure; DA = dopamine; HA = headache; NE = norepinephrine; N/V = nausea and vomiting.
SELECTIVE SEROTONIN REUPTAKE INHIBITORS AND SEROTONIN­NOREPINEPHRINE REUPTAKE INHIBITORS
The mainstays of current antidepressant therapy are the SSRIs and SNRIs, which increase the amount of intrasynaptic serotonin or serotonin and norepinephrine, respectively. A significant advantage of SSRIs and SNRIs over other classes of antidepressants is their high therapeutic index and favorable side effect profile. Common side effects for the SSRIs include nausea and vomiting, drowsiness, headache, changes in sleep patterns, sexual dysfunction, cognitive dysfunction, and precipitation of mania in bipolar patients. SSRIs may initially increase suicidal ideation, and the U.S. Food and
Drug Administration currently requires that all antidepressants carry a black box warning that antidepressants may increase suicide risk in patients <25 years old. When SSRIs are abruptly stopped or rapidly decreased in dosage, a withdrawal syndrome may occur, characterized by flulike symptoms, including nausea, vomiting, fatigue, myalgias, vertigo, headache, insomnia, and paresthesias. Although these symptoms are not life threatening, they may be very uncomfortable for the patient.
SNRIs are very similar to SSRIs in side effect profile, although they may cause elevated blood pressure and result in less sexual dysfunction.
Withdrawal may also occur several days after discontinuation or rapid decrease in dosage of an SNRI.
Serotonin Syndrome
Serotonin syndrome, a potentially life­threatening adverse drug reaction, may occur in patients taking SSRIs (or any other antidepressant) when used in combination with another agent that has serotonergic activity such as monoamine oxidase inhibitors, opiates (including tramadol), CNS stimulants (including cocaine, ecstasy), serotonin agonists, St. John’s wort, lithium, dextromethorphan, risperidone, olanzapine, ondansetron, and metoclopramide. The syndrome is manifested by neuromuscular hyperactivity (tremor, myoclonus, hyperreflexia/clonus, seizures), altered mental status (restlessness, agitation, excitement, confusion), autonomic hyperactivity (tachycardia, tachypnea, fever, diaphoresis), and GI irritability (nausea, vomiting, diarrhea). Treatment consists of discontinuing the affecting agents, administering benzodiazepines, and supportive care.
ATYPICAL ANTIDEPRESSANTS
Atypical antidepressants include bupropion, mirtazapine, and trazodone. Bupropion, a dopamine reuptake inhibitor, is also used for smoking cessation. It typically causes less weight gain and less sexual dysfunction than other antidepressants. Trazodone is a serotonin antagonist and reuptake inhibitor that is more sedating than other antidepressants with less anticholinergic effects and is commonly used as a sleep aid. Mirtazapine is related to the heterocyclic antidepressants, tends to cause weight gain, and has a more rapid onset of action of about  week. As with the other antidepressants, these medications may cause withdrawal when abruptly stopped.
Although not approved by the U.S. Food and Drug Administration, ketamine is being studied for treatment­refractory depression, as its onset of action
  is much faster than current therapies. Ketamine’s long­term efficacy and side effect profile need further investigation.
HETEROCYCLIC ANTIDEPRESSANTS
Heterocyclic antidepressants, once commonly used for depression, are prescribed less often now due to low therapeutic index, many possible side effects at prescribed doses, and dangerous overdose potential. The side effects are mainly anticholinergic related and cardiotoxic, including prolonged QT interval and atrioventricular block. One agent in this category, amitriptyline, is commonly prescribed for chronic or neurogenic pain.
c
MONOAMINE OXIDASE INHIBITORS
Monoamine oxidase inhibitors are rarely used first line in treating depression because of potentially lethal drug–drug and dietary interactions.
Monoamine oxidase inhibitors block oxidative deamination of tyramine and may precipitate a sometimes fatal hypertensive crisis when certain drugs
(sympathomimetic amines, levodopa, narcotics, and heterocyclic antidepressants) or tyramine­containing foods or beverages (aged cheese, beer, and wine) are co­ingested.
DISPOSITION
The disposition of the depressed patient is based on the assessment of harm to self or others, the ability to care for one’s self, level of supportive environment at home, and complicating medical or substance abuse problems. Any combination of the above may require psychiatric consultation for admission evaluation. Patients who may safely go home need specific, timely follow­up plans with a primary care provider, psychiatrist, or other appropriate counselor. “No­harm” contracts between ED providers and patients are not recommended. Two helpful websites for both practitioners and patients are www.samhsa.gov (Substance Abuse and Mental Health Services Administration) and www.sprc.org (Suicide Prevention Resource
Center). An ED­specific guide regarding safe patient disposition is found at www.sprc.org/edguide.
SPECIAL CONSIDERATIONS
Mood disorders in the elderly are discussed in Chapter 288, “Mental Health Disorders of the Elderly,” and mood disorders in children are discussed in
Chapter 149, “Behavioral Disorders in Children.”
POSTPARTUM DEPRESSION

Postpartum depression affects 10% to 15% of women within  year of delivery, but typically occurs within the first month. In one urban pediatric ED,
 one third of postpartum patients screened positive for depression. Symptoms are extreme fatigue, ambivalent feelings about caring for the newborn, guilt about those feelings, and the other classic major depressive disorder symptoms. Low energy is in excess of the normal fatigue felt by
 most postpartum women. Risk factors for postpartum depression are prior depression, young age, low socioeconomic status, and partner abuse.
Recognition in the ED is important to identify and mitigate infant vulnerability.
CROSS­CULTURAL ISSUES
Surveys of depressive disorders show a wide range of prevalence across diverse cultures, although it is unclear how much of this difference is due to each culture’s definition and expressions of depressive disorders. Non­Western cultures may emphasize somatic symptoms of depression, whereas in
Western cultures, it may be more acceptable to express psychological complaints. Avoid stereotyping, but acknowledge the possibility of cultural influence in symptom description.
BIPOLAR DISORDERS
Bipolar disorders, previously called manic­depressive disorder, are the other major type of mood disorder and are characterized by mania, typically cycling with periods of depression. The depressive periods tend to last longer than the manic periods. Mania can be diagnosed if there is a distinct
 period of elevated, expansive, or irritable mood for at least  week. This behavior must be associated with three of the following symptoms: inflated self­esteem or grandiosity, decreased need for sleep, pressured speech, flight of ideas or racing thoughts, distractibility, increase in goal­directed activity or psychomotor agitation, or involvement in high­risk activities (often sexual or financial in nature). These symptoms must cause marked
 impairment in usual functioning and must not be attributable to medical disease or substance abuse. Mania may exist with or without psychotic features. Bipolar disorder is divided into several subtypes including bipolar I (mania, with or without major depressive episodes), bipolar II
(intermittent hypomania with depressive episodes), and cyclothymic (recurrent dysthymic and hypomania episodes). A “mixed” state is one in which the patient meets the criteria for a manic episode plus depressive disorder symptoms for at least  week. Bipolar disorders affect men and women equally and have no race/ethnicity predilection.
PATHOPHYSIOLOGY
The pathogenesis of bipolar disorder is likely multifactorial. There is a strong genetic component, with about 50% of all bipolar patients having a
  parent with a mood disorder. The concordance rate is 40% in monozygotic twins compared with 6% in dizygotic twins. Areas of the brain involved in normal emotional responses, ventral prefrontal networks and limbic regions, demonstrate decreased connectivity on functional MRIs in bipolar
  patients. Environmental factors, such as negative life events, increase the likelihood of developing bipolar disorder in predisposed persons.
CLINICAL FEATURES
The manic patient may seem “fun,” energetic, and expansive, but beware; the patient may quickly become irritable or even hostile if plans are antagonized by providers or family members. Manic patients may experience grandiose or delusional ideas and loss of cognitive abilities, with little insight. The initial evaluation of the manic patient is similar to that of patients with other psychiatric disorders and is discussed in Chapter 286. Consider nonpsychiatric causes of agitation, such as thyroid disease, acute toxic ingestions (cocaine, stimulants), and drug withdrawal
(antidepressants, alcohol, benzodiazepines). Consider other psychiatric diseases, such as schizophrenia and attention deficit disorder, as features may mimic the manic phase of bipolar disorder. Patients exhibiting mania should be questioned about a previous history of depressive disorder, because most bipolar disorder patients are initially diagnosed with depressive disorder.
TREATMENT OF BIPOLAR DISORDER
Treatment for bipolar disorder is complex, often requires more than one medication, and thus should not be initiated by the emergency physician, except for treatment of acute agitation (see Chapter 287, “Acute Agitation”) or to restart lithium or an anticonvulsant medication that has been recently stopped. Medications to treat the acutely manic patient include “mood stabilizers,” such as lithium, valproic acid, or carbamazepine, with or without the addition of an antipsychotic (such as haloperidol) or a benzodiazepine (Table 289­5). The same mood stabilizers may also be used for maintenance therapy. Lithium and valproic acid may be combined with an atypical antipsychotic medication for bipolar maintenance therapy.
Lithium has a narrow therapeutic index and requires frequent monitoring. Patients taking lithium must avoid dehydration to prevent toxic levels from
 accumulating. The efficacy of antidepressant use in bipolar disorder is unclear because of the possible risk of precipitating mania.
TABLE 289­5
Medications Used for Bipolar Disorder
Usual
Generic Brand Mechanism of Side Effects (BLACK BOX WARNING IN
Starting Comments
Name Name Action CAPS)
Dose
Lithium Eskalith®, ? increase NE TOXICITY closely related to serum lithium levels: 300 Effective for both acute carbonate Lithonate®, function diarrhea, vomiting, tremor, mild ataxia, milligrams  and maintenance
Lithotabs® ? increase serotonin drowsiness or muscular weakness. or  times a therapy function Initially: nausea, dry mouth, excessive thirst, day Narrow therapeutic tremors, polyuria, peripheral edema, cognitive window; toxicity impairment common; symptoms
Long­term: polyuria, diabetes insipidus, goiter, may be delayed up to  hypothyroidism, rashes, leukocytosis h in acute overdose
Avoid giving with NSAIDs,
ACE inhibitors, or diuretics to avoid toxicity.
Dose is lower in elderly and patients with renal dysfunction
Valproic acid Depakene®, Antiepileptic; HEPATOTOXICITY, FETAL RISK, PANCREATITIS, 250 Effective for both acute
Depakote® enhances weight gain, nausea, vomiting, hair loss, bruising, milligrams  and maintenance
(12 h), transmission of GABA tremor, thrombocytopenia or  times a therapy
Depakote day Can monitor drug levels
Sprinkles® Monitor liver and platelet
(12 h), function
Depacon® May be used alone to
(IV) treat BD, or in combination with antipsychotic or lithium
Carbamazepine Tegretol® Antiepileptic; AGRANULOCYTOSIS, STEVENS­JOHNSON 100–200 Effective for acute or stabilizes sodium SYNDROME/TOXIC EPIDERMAL NECROLYSIS, milligrams  maintenance therapy channels, potentiates nausea, vomiting, hyponatremia, rash, or  times a Can monitor drug levels
GABA receptors leukopenia day Monitor LFTs
May be better in rapid cycling disorder
Do not use with antipsychotics
Many drug interactions with similarly livermetabolized medications
OCP failure
Lamotrigine Lamictal® Antiepileptic; sodium STEVENS­JOHNSON SYNDROME/TOXIC  Used with more severe channel blockade EPIDERMAL NECROLYSIS—rare complications but milligrams depressive symptoms potentially fatal; nausea, vomiting, fatigue, once a day Dose adjustment dizziness (unless on required with other other antiepileptic antiepileptic Progestin­only OCP medication) failure
Requires slower dose titration when used with valproic acid
Olanzapine Zyprexa® Antipsychotic; INCREASED MORTALITY IN ELDERLY PATIENTS .5–5.0 May be used in muscarinic; WITH DEMENTIA­RELATED PSYCHOSIS, sedation, milligrams  combination with lithium dopamine and constipation, dry mouth, glucose intolerance, or  times a or valproic acid serotonin antagonist orthostatic hypotension, hyperlipidemia day Injection cannot be given within  h of injectable benzodiazepine
Quetiapine Seroquel® Antipsychotic; INCREASED MORTALITY IN ELDERLY PATIENTS 25–50 May be used in dopamine, serotonin, WITH DEMENTIA­RELATED PSYCHOSIS, SUICIDAL milligrams  combination with lithium and adrenergic THOUGHTS AND BEHAVIORS WITH or  times a or valproic acid antagonist ANTIDEPRESSANT DRUGS, headache, dry mouth, day weight gain, sedation, dizziness, orthostatic hypotension
Risperidone Risperdal® Antipsychotic; INCREASED MORTALITY IN ELDERLY PATIENTS .25–1 May be used with lithium serotonin and WITH DEMENTIA­RELATED PSYCHOSIS, milligram  or valproic acid dopamine antagonist extrapyramidal side effects, prolactin elevation, or  times a Use lower doses in sedation, dyspepsia, nausea, weight gain day elderly due to orthostasis risk
Aripiprazole Abilify® Antipsychotic; partial INCREASED MORTALITY IN ELDERLY PATIENTS 2–10 May be used with lithium agonist of WITH DEMENTIA­RELATED PSYCHOSIS, SUICIDAL milligrams or valproic acid dopamine/serotonin THOUGHTS AND BEHAVIORS WITH once a day receptors; antagonist ANTIDEPRESSANT DRUGS, headache, nausea, of other serotonin vomiting, extrapyramidal symptoms, especially receptors akathisia
Ziprasidone Geodon® Antipsychotic; INCREASED RISK OF DEATH IN DEMENTIA­  May be used with lithium serotonin and RELATED PSYCHOSIS; rash, weight gain, milligrams or valproic acid dopamine constipation, nausea, tremor, extrapyramidal twice a day antagonist; side effects, sedation, vision changes adrenergic antagonist; agonist at other serotonin receptors
Lurasidone Latuda® Antipsychotic; INCREASED RISK OF DEATH IN DEMENTIA­  serotonin and RELATED PSYCHOSIS, nausea, vomiting, milligrams dopamine extrapyramidal side effects, sedation, anxiety once a day antagonist; adrenergic antagonist; agonist at other serotonin receptors
Abbreviations: ACE = angiotensin­converting enzyme; BD = bipolar disorder; GABA = γ­aminobutyric acid; LFTs = liver function tests; NE = norepinephrine; OCP = oral contraceptive pill.
DISPOSITION
Disposition of the bipolar disorder patient is similar to that of the depressive disorder patient, including careful assessment of suicide risk. Lack of insight to the loss of cognitive abilities and delusional ideas may put the patient at significant risk for self­harm, though not explicitly expressed.
Bipolar disorder patients who are exhibiting psychotic features or are at risk for harm to self or others need psychiatrist evaluation for admission.
ANXIETY DISORDERS

Anxiety is the most common mental health disorder overall, although second behind mood disorder in ED presentation, accounting for approximately

1% of all ED visits. ED patients with anxiety are more likely to be women, nonelderly, and non­Hispanic whites. Patients with anxiety disorders seek
,50 medical care about twice as often as non­anxiety patients and are high users of the ED. This is partly due to the fact that anxiety disorders, especially panic disorder, may mimic life­threatening conditions, such as acute coronary syndrome. Anxiety disorders are often associated with mood
    disorders, alcohol abuse, personality disorders, and other anxiety disorders. Anxiety disorders are characterized by excessive fear or worry about real or imagined events. Fears often adversely impact both physical and psychological health.
PATHOPHYSIOLOGY
The pathophysiology of anxiety disorder is multifactorial. Dysregulation of γ­aminobutyric acid inhibitory neurotransmission and increased excitatory neurotransmitters, specifically serotonin, have been implicated and may explain the utility of SSRIs and benzodiazepines to treat anxiety disorder.
Hyperactivity in the limbic regions, especially the amygdala, and the inability of executive cortex areas to modulate the limbic response to stimuli may
  contribute. There appears to be a genetic role, especially in panic disorder, although it does not seem to be as strong a predictor as in other
 psychological illnesses. Exposure to stressful events, especially in childhood, is a risk factor for development of anxiety disorder. A specific stressful event precedes the development of posttraumatic stress disorder.
CLINICAL FEATURES
Anxiety disorders are a heterogeneous group, although they share many common somatic and cognitive symptoms (Table 289­6), with timing, severity, and associated beliefs separating the different types. Generalized anxiety disorder, panic disorder, and posttraumatic stress disorder are discussed here.
TABLE 289­6
Symptoms of Anxiety Disorders
Physical Symptoms Cognitive Symptoms
Palpitations, pounding heart, tachycardia Fear of losing control or “going crazy”
Sweating Derealization (feeling of unreality) or depersonalization (feeling detached from oneself)
Trembling or shaking Inability to concentrate
Feeling of choking Obsessions and compulsions
Chest pain or discomfort Feeling generally ill at ease
Nausea or abdominal distress Fear of dying
Feeling dizzy, unsteady, lightheaded, or faint
Paresthesias
Chills or hot flashes
Difficulty sleeping
Increased muscle aches or soreness
GENERALIZED ANXIETY DISORDER
The Diagnostic and Statistical Manual of Mental Disorders, 5th edition, defines patients with generalized anxiety disorder as having chronic excessive
 anxiety and worry about real or imagined events, occurring more days than not, for at least  months. The symptoms cause significant impairment in daily functioning and are generally recognized by the patient as excessive and inappropriate. The anxiety and worry are associated with three or more of the following symptoms: restlessness or being keyed up or on edge, irritability, muscle tension, being easily fatigued, difficulty concentrating or

“mind going blank,” and sleep disturbance. Patients with generalized anxiety disorder may have interspersed, more intense panic attacks.
PANIC DISORDER
Panic disorder (“panic attack”) is a common, often chronic illness characterized by recurrent, spontaneous panic attacks. Panic attacks are shortlived episodes of anxiety or intense fear accompanied by a range of somatic symptoms (commonly cardiac, GI, or neurologic), usually peaking within  minutes and but that may last up to an hour. The Diagnostic and Statistical Manual of Mental Disorders, 5th edition, criteria for panic disorder also stipulate that the panic attack must be followed by  month of persistent concern about having additional attacks, worry about the implications of the attack or its consequences, or a significant change in behavior related to the attacks. It cannot be better accounted for by another
 psychiatric or medical disorder. Panic disorder may occur with or without agoraphobia (irrational fear of crowded spaces); panic disorder with agoraphobia may be severely disabling both socially and occupationally. Because of the often debilitating symptoms, panic disorder patients are high
 users of the ED. In one Canadian study, 25% of patients presenting to the ED with chest pain were ultimately diagnosed with panic disorder.
Underrecognition of anxiety disorders, which are treatable, continues the cycle of overutilization of medical resources. Panic disorder may have an
    association with several medical disorders, including asthma, hypertension, interstitial cystitis, migraine headaches, and cardiovascular
  disease. The long­held association between mitral valve prolapse is less clear.
POSTTRAUMATIC STRESS DISORDER/ACUTE STRESS DISORDER
Posttraumatic stress disorder (PTSD) patients have all experienced or witnessed an intense traumatic event, such as rape, combat, natural disaster, child abuse, chronic exposure to an extreme stressor, or motor vehicle crash. The prevalence of PTSD within the first several months after a motor
 vehicle crash is 25% to 40%, and in 15% of patients, PTSD will persist. Elderly patients are at higher risk, with 21% having significant PTSD at 
 months.

Diagnostic criteria state that the patient has to be exposed to the stressor and that the response involved intense fear, hopelessness, or horror. This is followed by “intrusive recollection,” which would include one or more of the following: recurrent distressing dreams of the event, acting or feeling as if the event were recurring (“flashbacks”), and intense psychological distress with or without physiologic reactivity upon exposure to internal or external cues that symbolize the traumatic event. There may also be avoidance of stimuli associated with the trauma and a numbing of general responsiveness. Hyperarousal demonstrated by hypervigilance or exaggerated startle may occur. The symptoms have to be present for at least a
 month and cause significant impairment in functioning and cannot be better explained by another psychiatric or medical cause. Acute stress disorder is diagnosed when the same symptoms of PTSD last between  days and  month. Feinberg and colleagues found a direct correlation
 between development of PTSD after a motor vehicle crash and persistent moderate to severe axial pain. At discharge of initial visit for a motor vehicle crash, or during return visits to the ED after serious trauma, patients should be questioned about persistent pain, coping strategies, general wellbeing, and follow­up plan to possibly avert development of acute stress disorder, PTSD, or chronic pain.
DIAGNOSIS
Initially, assess patients who present with anxiety for life­threatening medical conditions, such as myocardial infarction, pulmonary embolus, hypoglycemia, hypoxia, tachyarrhythmias, thyroid storm, and cerebrovascular accident. Also ask about suicidal and homicidal ideation, as there is a

10­fold greater suicide risk among patients with anxiety disorders compared with the general population, and even greater risk when the patient also
 has both an anxiety disorder and a mood disorder. Try to identify current stressful situations that may have precipitated symptoms. Anxiety symptoms may also be caused by certain medications or substances of abuse, including corticosteroids, neuroleptics, bronchodilators, decongestants, caffeine, nicotine, cocaine, and amphetamines. Withdrawal from benzodiazepines, opiates, SSRIs/SNRIs, and alcohol may cause agitation and anxiety. One useful screening question for panic attacks is: “Have you experienced brief periods for seconds or minutes of an
 overwhelming panic or terror that was accompanied by racing heart, shortness of breath, or dizziness?” Take care to identify victims of domestic violence, sexual abuse, or assault, because such past or present experiences can provoke panic attacks.
TREATMENT OF ANXIETY DISORDERS
Psychological treatment with cognitive­behavioral therapy and pharmacologic therapy with antidepressants for long­term treatment have both been
,71 shown to be effective for anxiety disorders and may be more effective when used in combination. Benzodiazepines for short­term use and lowdose β­blockers to mitigate physical symptoms may also be helpful.
Benzodiazepine pharmacotherapy in the ED may be considered (Table 289­7) for acute panic attack, especially for patients who need rapid control of debilitating symptoms. The limitation of benzodiazepines for anything but very short­term use is their potential for abuse and dependence. Use with caution in patients with a respiratory disorder or history of substance abuse or dependence. The use of benzodiazepines is discouraged in the elderly because of concerns for falling, cognitive slowing, paradoxical agitation, and drug interactions due to polypharmacy.
TABLE 289­7
Pharmacotherapy for Anxiety Disorder
FDA Approved for Which
Class of Drug Drug and Dosage
Anxiety Disorder
Acute medication Benzodiazepines Lorazepam (Ativan®), .5–1.0 milligram  times a day All treatment Clonazepam (Klonopin®), .5–1.0 milligram twice a day All
Alprazolam (Xanax®), .25–1.0 milligram 3–4 times a day All
Diazepam (Valium®) 2–10 milligrams 2–4 times a day All
Ongoing Selective serotonin Sertraline (Zoloft®), 50–200 milligrams daily (initial dose,  PD, PTSD, SAD, OCD medication reuptake inhibitor milligrams) GAD, PD, PTSD, SAD, OCD treatment Paroxetine (Paxil®), 40–70 milligrams daily (initial dose, 10–20 GAD milligrams) PD, OCD
Escitalopram (Lexapro®), 10–20 milligrams daily (initial dose 5–10 milligrams)
Fluoxetine (Prozac®) 20–60 milligrams daily (initial dose  milligrams)
Serotonin­norepinephrine Venlafaxine (Effexor®), 75–300 milligrams daily (initial dose, .5 GAD, PD, SAD reuptake inhibitor milligrams) (Venlafaxine XR preferred in anxiety) GAD
Duloxetine (Cymbalta®) 20–120 milligrams daily (initial dose,  milligrams)
Abbreviations: FDA = U.S. Food and Drug Administration; GAD = generalized anxiety disorder; OCD = obsessive­compulsive disorder; PD = panic disorder; PTSD = posttraumatic stress disorder; SAD = social anxiety disorder.
SSRIs and SNRIs are effective treatments for anxiety disorders and ideally administered in conjunction with a primary care or psychiatric practitioner with a follow­up plan in place. Starting doses may be lower than used when treating depression and may take longer to be effective.
Cognitive­behavioral therapy is not usually arranged in the ED, although one study in patients who presented to the ED with noncardiac chest pain
(thought to be panic disorder) demonstrated a decrease in panic disorder symptoms with a single session of cognitive­behavioral therapy within 
 weeks of discharge. This may have return ED visit implications.
DISPOSITION
Once a diagnosis of anxiety disorder is considered, the next step is to educate patients and provide reassurance that they are not dying or “going crazy.” Emphasize that this is an illness that can be treated effectively with cognitive­behavioral therapy and antidepressants. Choice of treatment is based on an individual assessment of risks, benefits, efficacy, availability, acuity, and patient preference. Although cognitive­behavioral therapy is not practiced in the ED, education regarding it is worthwhile. Therapy consists of patient education about the disorder, symptom and thought records, and learning anxiety management skills (e.g., breathing retraining) with the guidance of a trained therapist.
After exclusion of a life­threatening medical condition, the need for admission or emergent psychiatric consultation is rare, except in patients expressing suicidal or homicidal ideation, or other psychiatric or medical comorbidities that prohibit the patient from self­care. Medication changes or initiation of antidepressants should be done in conjunction with the primary care provider or psychiatrist.
Acknowledgment
Special thanks to Dr. Shauna Garris, PharmD, BCPP, BCPS, for her assistance in preparing this chapter.


