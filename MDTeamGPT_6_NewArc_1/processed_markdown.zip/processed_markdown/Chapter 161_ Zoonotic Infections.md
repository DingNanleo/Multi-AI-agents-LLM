## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 161: Zoonotic Infections
Bryan B. Kitch; John T. Meredith
INTRODUCTION
Zoonoses are diseases caused by bacteria, viruses, parasites, or fungi transmitted from vertebrate animals or insects to or from humans. Ticks are one of the most important vectors of human infectious diseases in the world. Exposures or occupations that involve animal contact are risk factors for disease (Table 161­1). Recent travel, particularly in spring, summer, and early fall, or history of habitation in an underdeveloped country are additional risk factors. Zoonoses can occur at any time of the year, but in temperate climates, most zoonoses happen in the spring and summer. A patient with a zoonotic infection has signs and symptoms similar to many acute infections: fever, headache, myalgias, malaise, and weakness (Table
161­2).
TABLE 161­1
Risk Factors for Zoonotic Infection
Risk Category Examples
Agricultural workers Farmers, cattle ranchers, sheep ranchers, and migrant workers
Animal processing Slaughterhouse workers, animal hide processors, and workers in manufacturing who deal with animal products workers
Outdoor enthusiasts Forestry workers, lumbermen, surveyors, park rangers, hunters, spelunkers, and fishermen
Pet owners Those living alongside a dog, cat, bird, rodent, rabbit, reptile, or fish
Professionals Veterinarians, animal researchers, and animal handlers
Immunocompromised Those with congenital immunodeficiencies, diabetes mellitus, alcoholism, renal failure, liver failure, cancer, splenectomy, or patients human immunodeficiency virus
TABLE 161­2
Common Systemic Zoonotic Infections
Animal
Agent Physical Findings Diagnostic Tests Treatment
Reservoir
Aeromonas Fish, reptiles Nonspecific fever, severe — See Chapter 160, “Food and Waterborne species crepitant cellulitis with Illnesses” systemic toxicity, gastroenteritis
Brucella canis Dogs Nonspecific fever Serologic testing, blood culture Doxycycline plus gentamicin or rifampin.
 TMP­SMX plus gentamicin in children
Chapter 161: Zoonotic Infections, Bryan B. Kitch; John T. Meredith 
. Terms of Use * Privacy Policy * Notice * Accessibility
Capnocytophaga Dogs and cats Fever, septic shock, and Culture of bite wound Amoxicillin­clavulanate or clindamycin.
meningitis from infected bite Pip­Tazo or a carbapenem plus clindamycin/vancomycin for shock
Chlamydophila Birds Fever, flulike illness, Serologic testing and sputum Doxycycline. Azithromycin and psittaci pneumonia, endocarditis, culture levofloxacin are alternatives sepsis
Coxiella burnetii Cattle, sheep, Fever, pneumonia, hepatitis, Serologic testing, PCR Doxycycline, with the possible alternative goats, and meningitis, endocarditis of a fluoroquinolone or macrolide occasionally cats
Ehrlichia species Ticks Nonspecific fever, sepsis, Clinical diagnosis, serologic testing, Doxycycline recommended for all meningitis, hepatitis peripheral blood smear, patients (even children and pregnancy).
immunocytologic testing, PCR Rifampin is alternative
Leptospira Birds, dogs, Fever, pneumonia, Darkfield microscopic examination Penicillin G IV. Ceftriaxone IV alternative.
species rodents conjunctivitis, of body fluids, serologic testing Mild disease: oral doxycycline or lymphadenopathy amoxicillin or azithromycin
Francisella Rabbits, cats, Fever, sepsis, meningitis, Serologic testing (poses hazards to IV aminoglycosides. Alternative: tularensis wild animals, pneumonia, hepatitis, rash laboratory staff) Doxycycline or ciprofloxacin biting insects
Rickettsia Ticks Fever, diarrhea, or typical Clinical diagnosis, rise in antibody Doxycycline or chloramphenicol rickettsii presentation of Rocky titer between acute and
Mountain spotted fever convalescent serum, skin biopsy
Salmonella Dogs, cats Fever, abdominal pain, sepsis, Blood or stool culture Fluoroquinolones or third­generation enterica (rarely), cellulitis, meningitis, cephalosporins reptiles endocarditis, septic arthritis
(turtles)
Streptococcus Fish, seafood Fever, cellulitis Wound culture, blood culture β­Lactams except aztreonam.
iniae cellulitis Alternatives: azithromycin, clindamycin, fluoroquinolones
Yersinia pestis Dogs, cats, Bubonic: fever, headache, Blood culture, culture of suspected Doxycycline, fluoroquinolone, rodents buboes; or pneumonic: cough, sites gentamicin, streptomycin, or chills, dyspnea, shock chloramphenicol
Abbreviations: PCR = polymerase chain reaction; Pip­Tazo = piperacillin­tazobactam; TMP­SMX = trimethoprim­sulfamethoxazole.
This chapter focuses on the most important tick­borne diseases, upper and lower respiratory zoonoses, and parasitic zoonoses. Many of the parasitic, bacterial, and viral organisms responsible for gastroenteritis share a zoonotic source in addition to a human source. These are discussed in Chapter
, “Disorders Presenting Primarily with Diarrhea.” Life­threatening zoonoses such as rabies, malaria, and serious viral infections are discussed in separate chapters.
TICK­BORNE INFECTIONS
Ticks parasitize vertebrates in virtually every part of the world. Saliva of some tick species contains anesthetic and inflammatory factors, and some species contain a toxin that paralyzes the host. Ticks feed for several days on the host, and their presence often goes unnoticed for a time; many
 affected patients do not recall a history of a tick bite. Tick­borne diseases are often accompanied by a rash. Tick­borne zoonoses have a geographic distribution (Table 161­3) and seasonal variation.
TABLE 161­3
Tick­borne Infections
Primary Animal
Disease Clinical Features Geographic Distribution
Vector Reservoir
Babesiosis Ixodes Cattle, Fatigue, malaise, anorexia, nausea, headache, sweats, rigors, Northeast and north­central dammini, I. horses, abdominal pain, emotional lability, depression, dark urine, United States scapularis, dogs, cats, hepatomegaly, fever, petechiae, ecchymosis, occasional rash, and and I. rodents, occasionally, pulmonary edema pacificus deer
Colorado tick Dermacentor Deer, Fever, chills, headache, myalgias, nausea, vomiting, photophobia, Western and northwestern fever andersoni marmots, abdominal pain, and occasional sore throat; also may have United States and southwestern
(wood tick) porcupines conjunctivitis, lymphadenopathy, hepatosplenomegaly, stiff neck, Canada retro­orbital pain, weakness, and lethargy
Anaplasmosis I. scapularis, Dogs, deer, Fevers, chills, malaise, headache, nausea, muscle aches, cough, sore Japan, Malaysia, and the
I. pacificus other throat, and pulmonary infiltrates (especially in children) eastern, northeastern, and mammals north­central United States
Ehrlichiosis Amblyomma Dogs, deer, Fevers, chills, malaise, headache, nausea, muscle aches, cough, sore Japan, Malaysia, Europe, and americanum other throat, and pulmonary infiltrates (especially in children) southeastern and south­central
(lone star mammals United States tick)
Lyme disease I. dammini Deer, Erythema migrans, meningitis, encephalitis, neuropathy, and joint Atlantic central and north­
(Borrelia sheep, and heart symptoms central United States, Europe burgdorferi) deer mice
Rocky D. andersoni North Petechiae, purpura, pulmonary infiltrates, jaundice, myocarditis, Most of the continental United
Mountain and American hepatosplenomegaly, meningitis, encephalitis, and States, although more spotted fever Dermacentor mammals lymphadenopathy prevalent in the southeast and
(Rickettsia variabilis south­central United States rickettsii) (dog tick)
Relapsing Ornithodoros Human Fever, chills, headache, myalgias, and arthralgias; pain, nausea, Worldwide fever species body lice, vomiting, and hypotension
(Borrelia wild species) rodents, humans
Southern A. Ticks; Erythema migrans, fever, headache, myalgias Eastern, southeastern, and tick­ americanum unclear if south­central United States associated other rash illness reservoir exists
Tularemia Dermacentor Rabbits, Pneumonia, regional lymphadenopathy and headache, cough, Northern hemisphere, North
(Francisella spp. and deer, dogs myalgias, arthralgias, nausea, vomiting, ulceration at inoculation site, America, northern Asia, Europe tularensis) Amblyomma and ocular findings spp.
TICK REMOVAL, PROPHYLACTIC TREATMENT, AND PREVENTION OF TICK BITES
The most effective way to remove an embedded tick is manual extraction with tweezers or blunt angled forceps to grasp the tick as close to the skin surface as possible. Avoid puncturing or grasping the body of the tick because this can lead to rupture of the tick and release of an infectious pathogen. Pull perpendicular to the skin with gentle traction, avoiding twisting or breaking the tick. Remove all residual body parts to limit any granulomatous reaction and infection. After complete removal of the tick, cleanse and disinfect the skin surface. Do not use topical or injected lidocaine or pass sutures through the tick, and avoid the use of gasoline, kerosene, petroleum jelly, or fingernail polish, which all can increase
 infection or impair complete tick removal. Commercially available tick removal devices exist, although tweezers are effective. Save the removed tick in alcohol to aid in identification, which is helpful if later illness occurs.

Use prophylactic treatment of a tick bite in select circumstances. Prophylactic indications include the ability to easily identify the tick as Ixodes scapularis, tick attachment for >36 hours or with obvious tick engorgement, and a local tick bite in an area with Borrelia burgdorferi carrier rate of

>20%. In such cases, use a one­time dose of doxycycline 200 milligrams for adults or  milligrams/kg in children for Lyme disease prophylaxis.
The best method to avoid tick bites is the application of topical DEET (N,N­diethyl­m­toluamide) to exposed skin and treatment of clothing with permethrin. Optimal DEET concentration is 15% to 33%, with less effectiveness if the DEET concentration is >35%. Apply to skin according to label directions.
ROCKY MOUNTAIN SPOTTED FEVER
The human disease­causing rickettsioses—the spotted fevers—include a number of different species identified in the Americas, Europe, Southwest
Asia, Africa, Siberia, western Russia, and Australia. Disease names are based on species and geography: Mediterranean spotted fever, Israel spotted fever, Astrakhan fever, Siberian tick typhus, Queensland tick typhus, African tick bite fever, and so on.
Rocky Mountain spotted fever is one of the most severe of the tick­borne illnesses in the United States, with peak occurrence occurring in June and
July. The fatality rate for Rocky Mountain spotted fever is <0.5%. More than 60% of reported U.S. cases originate from five states: North Carolina,

Tennessee, Oklahoma, Missouri, and Arkansas. The causative organism is Rickettsia rickettsii, a pleomorphic, obligate intracellular organism, and the vectors are the very small Dermacentor (D. variabilis and D. andersoni, the American dog tick) and Rhipicephalus sanguineus ticks (the brown dog tick, found in the American Southwest). Deer, rodents, horses, cattle, cats, and dogs are zoonotic hosts, with higher incidence in communities with free­
 roaming dog presence. Rickettsia parkeri and other members of the family can possibly cause Rocky Mountain spotted fever and may be responsible for an increase in incidence.
CLINICAL FEATURES
The diagnosis relies on epidemiologic features and the clinical exclusion of other diseases. Early signs and symptoms of Rocky Mountain spotted fever are fever, headache, myalgia, and malaise. Additionally, other nonspecific findings include lymphadenopathy, abdominal pain, nausea, vomiting, diarrhea, and headache. Late in the disease course, confusion, meningismus, renal failure, respiratory failure, and myocarditis may occur. The classic clinical picture is the triad of fever, rash, and tick bite, but only about half of patients can recall a tick bite.
The rash occurs on days  to  after the onset of fever but is absent in approximately 20% of patients. Most patients do not have a petechial rash when
 they seek initial medical care. The rash occurs earlier in children than in adults and begins as small blanching erythematous to pink macules and becomes petechial later. This characteristic maculopapular rash begins on the hands, feet, wrists, and ankles, and then spreads centripetally up the trunk. The rash is not pathognomonic and may occur in other illnesses. Additionally, the rash is easily overlooked early in infection and in those with dark skin. Another feature to recognize is the possibility of a nonexudative conjunctival injection with bilateral periorbital edema, resembling that
 found in toxic shock syndrome or Kawasaki’s disease. Abdominal distention and organomegaly may exist on physical exam.
DIAGNOSIS AND TREATMENT
Immunoglobulin G– or immunoglobulin M–specific antibodies are not detectable in acute­phase serum. Laboratory abnormalities are usually nonspecific, but the combination of normal white and red cell counts, thrombocytopenia, mild elevation of liver enzymes (aspartate aminotransferase and alanine aminotransferase), and hyponatremia suggests Rocky Mountain spotted fever, especially if the disease is
 advanced. Hypoalbuminemia may be present and is the cause of edema. In addition to clinical patterns, diagnosis confirmation with a rise in antibody titer between acute and convalescent serum, skin biopsy with immunofluorescent testing, or culture is possible, although none of these are useful for
ED diagnosis.
Preferred treatment is doxycycline (Table 161­4). Given the long half­life of doxycycline (18 to  hours), several days of a higher dose regimen may be required to achieve rapid therapeutic response in the critically ill patient. The risk of cosmetically perceptible tooth staining is small for a single course of treatment. Use doxycycline therapy as the treatment of choice for all rickettsial diseases, including Rocky Mountain spotted fever,
 in children of all ages.
TABLE 161­4
Tick­borne Zoonotic Infections and Specific Treatment
Tick­borne
Zoonotic Specific Treatment
Infection
Rocky Doxycycline 100 milligrams PO or IV twice a day for  d, or for  d after temperature normalizes. Some recommendations exist for an initial
Mountain loading dose of 200 milligrams. For children weighing <45 kg, the dose is .2 milligrams/kg twice daily. Although doxycycline is spotted fever contraindicated for use in pregnancy, it may be warranted in life­threatening situations. Chloramphenicol is an alternative; however, it has multiple toxic effects and contraindications and may be difficult to obtain. Dosing is  milligrams/kg/d divided into  doses for  d.
Lyme disease Primary stage or mild secondary: 14–21 d of doxycycline (100 milligrams PO twice a day), amoxicillin (500 milligrams PO  times a day in adults,  milligrams/kg/d divided  times a day in children), or cefuroxime (500 milligrams PO twice a day in adults,  milligrams/kg/d divided  times a day in children). Macrolides possible but less effective.
Severe illness, CNS positive, or high­degree heart block: ceftriaxone  grams IV for 14–30 d.
A single 200­milligram oral dose of doxycycline given within  h of a high­risk deer tick bite is effective in preventing Lyme disease.
Tick­borne Doxycycline (100 milligrams PO/IV twice a day for 7–10 d). Alternative: erythromycin (500 milligrams PO/IV  times a day for 7–10 d).
relapsing Chloramphenicol is an alternative.
fever
Colorado tick Treatment is supportive.
fever
Southern Treatment is supportive, often treated cautiously as Lyme with doxycycline as above.
tickassociated rash illness
Tularemia Adults: streptomycin,  gram IM/IV twice a day, or gentamicin/tobramycin,  milligrams/kg IV divided every  h. Treat for  d.
Children: streptomycin,  milligrams/kg IM twice daily (should not exceed  grams/d).
Mild disease: ciprofloxacin, 750 milligrams PO twice a day, or doxycycline, 100 milligrams PO twice a day. Treat for  d.
Prophylaxis for lab exposures: doxycycline, 100 milligrams PO twice a day, or ciprofloxacin, 500 milligrams PO twice a day. Treat for  d.
Babesiosis Atovaquone (750 milligrams PO every  h) plus azithromycin (500 milligrams PO on day , then 250 milligrams daily). Treat for  d. If relapse occurs, treat for the longer duration:  weeks or  weeks after negative blood smear.
Severe disease in adults: clindamycin (1200 milligrams IV twice a day or 600 milligrams PO  times a day) + quinine (650 milligrams PO  times a day). Treat for 7–10 d.
Ehrlichiosis Doxycycline, 100 milligrams PO twice a day for 7–14 d. For children weighing <45 kg, the dose is .2 milligrams/kg twice a day.
and anaplasmosis
TICK PARALYSIS
Many tick species secrete neurotoxic substances from salivary glands of attached ticks. Tick paralysis occurs worldwide, in Australia, Africa, Europe, and North America, and is more common in children than adults. Prolonged tick attachment (5 to  days) can result in host paralysis. Symptoms are ascending weakness, beginning in the lower extremities, and moving upward to the trunk, upper extremities, and head over hours to days.
Cerebrospinal fluid analysis is normal. Diagnosis is made upon finding a tick on the body. Tick removal leads to recovery in  hours.
LYME DISEASE
The first reports of Lyme disease were in Europe about 100 years ago based on descriptions of the rash, erythema chronicum migrans. Lyme disease is the most common vector­borne zoonotic infection in the United States, with approximately ,000 annual cases reported. Based on public health data
 and insurance information, the actual number of patients diagnosed with Lyme disease may be closer to 300,000 per year. Lyme disease is reported in
Europe, China, Japan, Australia, parts of Russia, and in all U.S. continental states, with 96% of the reported cases originating from  states clustered in the northeast and upper midwest. Peak transmission occurs in May through August. The responsible organism is B. burgdorferi, a spirochete, and the vector is the Ixodes deer tick, also known as the black­legged tick. The overall risk of Lyme disease after a deer tick bite is low, about 3% in endemic areas. However, the risk of infection is proportional to the length of time the tick feeds on the host, with minimal to no risk associated with tick
,8 attachment duration of <36 hours.
CLINICAL FEATURES
Lyme disease has three stages. The first stage is local and often with erythema migrans: an erythematous plaque with central clearing, seen in
 approximately 60% to 80% of cases. It develops within  to  days at the site of the tick bite and is a result of a vasculitis. There may be accompanying fever, chills, fatigue, myalgias, arthralgias, and lymphadenopathy. The rash may persist for up to  month and recur in the secondary stage of Lyme disease. Untreated erythema migrans resolves spontaneously in  to  weeks. This rash causes few symptoms and may go unnoticed by the patient.
The second stage, early disseminated disease, develops with the reproduction and spread of the Borrelia spirochete, occurring within a few days to months of the initial infection. This stage has fever, adenopathy, neuropathies, cardiac abnormalities, arthritic complaints, and skin lesions. Multiple annular/target­shaped skin findings occur in up to 50% of the patients infected and are the most characteristic component of the secondary stage of illness.
The most common neurologic symptom in the secondary stage of illness is the development of cranial neuritis, most often unilateral or bilateral facial nerve palsy. Facial palsy can also occur along with the initial rash of erythema migrans. Neuroborreliosis occurs in 15% of the untreated cases and can consist of periodic headache, neck stiffness, difficulty in mentation, cerebellar ataxia, myelitis, encephalitis, motor or sensory radiculoneuritis,
 mononeuritis multiplex, and facial palsy. Asymmetric oligoarticular arthritis of the large joints, with a particular predilection for the knees, is another complication. Brief attacks of asymmetric oligoarticular arthritis are common in the untreated patient in the secondary stage of illness. Attacks are characteristically separated by months of remission. Cardiac abnormalities occur in up to 8% of patients and present as varying degrees of atrioventricular block, sometimes requiring the insertion of a temporary pacemaker for stabilization. Additionally, myopericarditis may also be a manifestation on initial presentation.
The late disseminated stage of illness occurs months to years after the initial infection and is characterized by chronic arthritis, myocarditis,
 subacute encephalopathy, axonal polyneuropathy, and leukoencephalopathy. The advanced, chronic neurologic forms of Lyme disease can persist for over  years. Additionally, between 10% and 20% of patients treated with antibiotics have persistent symptoms, usually muscle and joint aches with fatigue and perhaps an autoimmune response persistent after the initial infection.
DIAGNOSIS AND TREATMENT

Diagnosis is clinical early in disease when erythema migrans is present; testing diagnoses later stages of Lyme disease. For the latter, use polymerase
 chain reaction testing, polyvalent fluorescence immunoassay, or Western immunoblot testing, because B. burgdorferi is difficult to culture.
Treatment of Lyme disease is with doxycycline (preferred agent) or amoxicillin. Neurologic symptoms or other persistent manifestations require ceftriaxone therapy (Table 161­4). A previously marketed vaccine no longer exists, because it conferred no ongoing immunity.
EHRLICHIOSIS AND ANAPLASMOSIS
Ehrlichiosis is a group of zoonotic diseases caused by the Ehrlichia genus, gram­negative pleomorphic coccobacilli that will infect circulating
 leukocytes. Infection due to Ehrlichia chaffeensis is also called human monocytic ehrlichiosis. The disease vector is the lone star tick, Amblyomma americanum. The major animal reservoir in North America is the white­tailed deer in the southeastern United States, with dogs and mice carrying
 several less common species of the pathogen. Disease incidence rose from .8 to  cases per million in the United States in 2000 to 2007, partly attributed to increased recognition. It also exists in Europe. The mortality rate in confirmed cases varies between 1% and 3% depending on causative
 agent.

Symptoms usually develop within  to  weeks of a tick bite. Clinical signs and symptoms are fever, headache, malaise, nausea, vomiting, diarrhea, abdominal pain, and arthralgias. Fever is present in the vast majority of cases (97%). Rash is present in 30% of adults and has no pathognomonic
 features. With disease progression, a minority of patients develop renal failure, respiratory failure, and encephalitis. The acute phase of illness lasts
<4 weeks, with the majority of patients recovering and proceeding on to a convalescent phase. Laboratory studies can demonstrate leukocytopenia, thrombocytopenia, and elevation of hepatic enzymes.
DIAGNOSIS AND TREATMENT
Diagnosis is made clinically but can be confirmed by laboratory testing once treatment has begun. Peripheral blood smear may show colonies of ehrlichiae in the WBCs in 20% of infected patients. Polymerase chain reaction is specific but not sensitive and is best done in the first week of illness.

Antibody tests are negative in 85% of patients during initial infection. The reference criterion test is immunofluorescence assay.
Treatment is with doxycycline until  to  days after fever resolution or  to  days after resolution of CNS symptoms in severe disease. Rifampin is an
 alternative in those with contraindications to doxycycline.

Anaplasmosis is a tick­borne disease caused by the bacteria Anaplasma phagocytophilum. Older terms for the disease are human granulocytic ehrlichiosis and human granulocytic anaplasmosis. The vector is the black­legged tick, I. scapularis, as well as the western black­legged tick, Ixodes pacificus. The clinical presentation of this disease is similar to ehrlichiosis, with geography of tick prevalence as the key difference between the two.
Testing is similar, and treatment is also with doxycycline.
TICK­BORNE RELAPSING FEVER
Relapsing fever is caused by several varieties of gram­negative Borrelia spirochetes. It was first described in West Africa and is now worldwide. Within
 the United States, it is rarely found east of Texas. Ornithodoros ticks (soft ticks that can survive for years between meals) are the vectors, and the
 principal zoonotic reservoirs are wild rodents, specifically tree squirrels and chipmunks. The classic risk factor is sleeping in rustic mice­infested structures in the wilderness of the western United States. The initial presentation may be that of a rash or a 2­ to 3­mm pruritic eschar at the site of a tick bite. An average incubation period of  days precedes the onset of fever, chills, cephalgia, myalgia, arthralgia, abdominal pain, and general
 malaise. Headache and myalgia occur in >90% of cases. Characteristically, the 3­day­long febrile episodes are interspersed with 7­day­long afebrile
 periods, which may cycle one to four times before resolution. Untreated, the disease is usually self­limited, with deaths occurring mostly at the extremes of age. Leukocytosis and thrombocytopenia are the typical laboratory findings.
DIAGNOSIS AND TREATMENT
Diagnosis confirmation is with the appearance of spirochetes on darkfield microscopy or Wright­Giemsa–stained peripheral blood smears, with a 70% sensitivity if obtained during a febrile period. Patients with relapsing fever may test false positive on Lyme disease assays due to protein cross­
  reactivity. Treatment is with tetracycline or erythromycin. Use IV ceftriaxone for  to  days if any CNS involvement exists. Patients in an endemic
 area with a confirmed tick bite can receive postexposure doxycycline for prophylaxis.
COLORADO TICK FEVER

Colorado tick fever is caused by an RNA virus of the genus Coltivirus in the family Reoviridae. The principal vector is the wood tick, D. andersoni, and the zoonotic reservoirs are deer, marmots, and porcupines. The disease is endemic to the western mountainous regions of the United States with elevations between 4000 and ,000 ft. Transmission to humans can occur with short periods of tick attachment. The incubation period is  to  days, and the onset of illness has fever, chills, headache, myalgias, and photophobia. There may be a macular or petechial rash in a minority of patients. The disease is self­limited, and complications are rare, although some patients may experience recurrent fever after  to  days of improvement.
DIAGNOSIS AND TREATMENT

Diagnosis is most often based on history, clinical findings, and geography. Treatment is supportive.
SOUTHERN TICK­ASSOCIATED RASH ILLNESS (STAR)

Southern tick­associated rash illness (STAR) is an illness that clinically presents in a manner nearly identical to Lyme disease. This disease has the typical target­shaped rash of primary Lyme and may be accompanied by nonspecific symptoms such as fever, myalgias, headache, and fatigue. This
 illness is transmitted by the lone star tick, A. americanum, which is endemic to the eastern, southeastern, and south­central United States. Unlike
Lyme disease, southern tick­associated rash illness is not known to cause delayed presentations of illness, nor does it cause cardiac or CNS involvement. The disease is thought to be transmitted directly by the tick, but no animal reservoirs or causative bacteria have been discovered.
Although it is thought to be a benign and self­limited disease requiring only supportive care, southern tick­associated rash illness’s clinical mimicry of
Lyme disease leads many providers to empirically treat for the latter.
TULAREMIA
Tularemia is caused by a small, gram­negative, nonmotile intracellular coccobacillus, Francisella tularensis. The disease is found in North America, northern Asia, and Europe. The zoonotic vectors are ticks of the Dermacentor species (wood tick, dog tick) and the Amblyomma species (lone star tick),
 as well as various flies. The principal zoonotic reservoirs are rabbits, hares, and deer. Tularemia is contracted through tick/fly bites, by inhalation, or through open wounds while in contact with an infected zoonotic host. Incubation is often between  and  days but may range from  hours to  weeks.
The clinical presentation depends on the method of inoculation, and the clinical forms are called ulceroglandular, glandular, typhoidal, pneumonic,
 oculoglandular, and oropharyngeal. The ulceroglandular form is the most common, occurring in 80% of cases, with a maculopapular skin lesion that ulcerates, followed by painful regional adenopathy and systemic symptoms. The glandular form consists of painful adenopathy without ulcerations. The typhoidal form, occurring in 20% to 30% of cases, consists of high fever, chills, cephalgia, and abdominal pain with an absence of skin and lymph involvement. Typhoidal tularemia has a slower tachycardia than would be expected given the fever magnitude. It is the form of the disease with highest morbidity, complications, and organ failure. The oculoglandular form and pneumonic form are the result of deposition into the eyes or inhalation of the F. tularensis bacterium. Pneumonic tularemia has up to a 50% mortality rate and is the most lethal form of the disease.
Laboratory findings are nonspecific.
DIAGNOSIS AND TREATMENT
Confirmatory testing is difficult and poses health risks to laboratory staff. First­line treatment is with streptomycin; gentamicin, ciprofloxacin, imipenem, doxycycline, and chloramphenicol are alternative therapies. Prevention of exposure and early treatment are key measures to prevent adverse outcomes. Think of this infection in endemic areas. Due to the ease of transmission and lethality, F. tularensis is a possible agent of biologic warfare/terrorism (Table 9­1).
BABESIOSIS
Babesiosis is a malaria­like disease transmitted by ticks, with the etiologic agents being protozoan parasites. Babesia microti is the most common
 causative organism in the United States, with sporadic cases caused by Babesia duncani on the Pacific coast. The major zoonotic reservoirs are domesticated mammals, rodents, and deer. Ixodes ticks function as the principal vector globally. Babesiosis is also transmitted through blood
 transfusions, with about 160 cases reported since 1979. Clinically, the presentation occurs  to  weeks after exposure with generalized malaise, anorexia, fever, and chills that can progress to intermittent sweats, myalgia, headache, and hemolytic anemia. Splenectomy and immunosuppression are risk factors. Laboratory tests demonstrate hemolysis, liver dysfunction, anemia, thrombocytopenia, and renal failure. Coinfection with Lyme disease or anaplasmosis/ehrlichiosis is common; patients with severe disease or disease refractory to treatment should be considered for alternative etiologies of illness.
DIAGNOSIS AND TREATMENT
Diagnose this infection by finding intraerythrocytic ring forms resembling malaria on a Giemsa­ or Wright­stained peripheral blood smear, although false­negative results can occur when the level of parasitism is low. Treatment duration is typically for  to  days with atovaquone plus azithromycin or clindamycin, with quinine added for severely ill patients (Table 161­4).
ZOONOTIC ENCEPHALITIS AND MENINGITIS

Zoonotic encephalitis is most often an arboviral infection transmitted hematologically by an arthropod or insect vector from an animal host.
There are multiple distinct arboviruses that cause zoonotic encephalitis in the United States and Canada. Furthermore, encephalitis may be seen in the nonviral zoonotic infections of Bartonella henselae, Brucella canis, borreliosis, Coxiella burnetii, Ehrlichia species, listeriosis, leptospirosis, Lyme
 disease, Rocky Mountain spotted fever, psittacosis, and toxoplasmosis. See Chapter 174, “Central Nervous System and Spinal Infections,” for additional discussion.
The first clinical signs and symptoms are nonspecific: malaise, myalgia, and fever. Next often comes headache and a sudden decline in mental status.
Head CT scan is usually normal. The cerebrospinal fluid is often abnormal, showing a slightly elevated opening pressure, normal to slightly elevated protein concentration, normal glucose levels, and predominance of lymphocytes. The infectious agent is rarely isolated from the cerebrospinal fluid.
Enzyme­linked immunosorbent assay of serum can detect most arboviral infections causing encephalitis.
Treatment is supportive. Consider treatable causes of encephalitis, such as herpes simplex or varicella, in the differential diagnosis.
The West Nile virus is an arbovirus that can cause a flulike illness, West Nile fever or West Nile virus encephalitis. Infected mosquitoes transmit the virus to humans and other animals through bites. Approximately 20% of patients infected develop symptomatic illness, with <1% having severe or
 potentially fatal infection. Although antibody responses can confirm disease, lab testing is usually not specific. Treatment for West Nile virus encephalitis is supportive (Table 161­5).
TABLE 161­5
Selected Zoonotic Infections and Specific Treatment
Selective Zoonotic
Specific Treatment
Infections
West Nile/Powassan Supportive care.
encephalitis
Brucellosis (Brucella Mild disease: doxycycline, 100 milligrams PO twice a day for  weeks, + gentamicin,  milligrams/kg IV daily for  d.
species) Alternative: doxycycline, 100 milligrams PO twice a day, + rifampin, 600–900 milligrams PO daily for  weeks.
Joint involvement: doxycycline, 100 milligrams PO twice a day, + rifampin, 600–900 milligrams PO daily for  months, + gentamicin,  milligrams/kg IV once daily for first  d.
Neurologic involvement: doxycycline, 100 milligrams IV/PO twice a day, + rifampin, 600–900 milligrams PO daily, + ceftriaxone,  grams IV twice a day. Treat until cerebrospinal fluid normalizes.
Psittacosis Doxycycline, 100 milligrams PO for 5–7 d.
(Chlamydophila psittaci) Alternative: azithromycin dose pack or levofloxacin, 750 milligrams PO for 5–7 d.
Q fever (Coxiella Doxycycline, 100 milligrams PO twice a day for 2–3 weeks.
burnetii) Alternative: consider 2–3 weeks of a fluoroquinolone or a macrolide.
Pasteurellosis Amoxicillin­clavulanate, 875/125 milligrams PO twice a day for 7–10 d.
(Pasteurella multocida) Alternative therapies based on culture data and presence of Staphylococcus coinfection. Often resistant to cephalexin, clindamycin, and macrolides.
Plague (Yersinia pestis) Gentamicin,  milligrams/kg IV daily for  d.
Alternative: streptomycin,  milligrams/kg IV/IM twice a day for  d.
Postexposure prophylaxis: doxycycline, 100 milligrams PO twice a day, or ciprofloxacin, 500 milligrams PO twice a day. Treat for
 d.
Hantavirus Treatment consists of supportive care with attention to adequate oxygenation.
Toxocariasis (Toxocara Moderate to severe disease: albendazole, 400 milligrams PO twice a day, with/without prednisone,  milligrams/d for allergic canis) response. Treat for  d.
Alternative: mebendazole, 100–200 milligrams PO twice a day for  d.
Dipylidiasis (dog Praziquantel, 5–10 milligrams/kg PO, one­time dose.
tapeworm) Alternative: niclosamide,  grams PO, one­time dose
Leptospirosis Mild disease: doxycycline, 100 milligrams PO twice a day for 5–7 d.
Alternative: azithromycin, 500 milligrams PO daily for  d.
Severe disease: penicillin G, .5 million units IV every  h for  d, or ceftriaxone,  grams IV daily for  d.
Alternative: doxycycline, 100 milligrams IV for  d.
Powassan disease is an arbovirus similar to West Nile but is transmitted by the deer tick rather than mosquitos. The infection begins with a
 nonspecific prodrome of fever and chills, but often progresses to a viral encephalitis. Diagnosis is by specialty tests at national laboratories, but the disease should be suspected in areas prone to Lyme disease.
Zoonotic meningitis can be caused by brucellosis, listeriosis, plague, salmonellosis, tularemia, leptospirosis, Lyme disease, ehrlichiosis, Q fever,
Rocky Mountain spotted fever, or psittacosis. Cerebrospinal fluid is almost always abnormal, showing a slightly elevated opening pressure, normal to slightly elevated protein concentration, normal glucose levels, and predominance of lymphocytes. Treatment is directed toward the specific organism cultured from the cerebrospinal fluid. However, empiric antibiotic coverage should be administered immediately in any presumptive case of meningitis in an effort to reduce mortality and morbidity (see Chapter 174, “Central Nervous System and Spinal Infections”).
UPPER RESPIRATORY ZOONOTIC INFECTIONS
Recurrent pharyngitis in a household member can have a zoonotic source, sometimes the household pet. Case reports exist where domestic animals in cohabitation with humans were associated with group A streptococcal pharyngitis recurrence; however, current practice guidelines on infection can
 find no causal link. Prolonged exudative pharyngitis raises the suspicion of a zoonotic origin or atypical pharyngitis, particularly if the exudative pharyngitis includes systemic symptoms and leukocytosis, and is refractory to standard antistreptococcal therapy.
Dogs and domesticated farm animals can be the source of Streptococcus species, Corynebacterium ulcerans, Yersinia species, and viral vesicular stomatitis. All of these zoonoses can present as an exudative pharyngitis. Nondomesticated animals can be a source of exudative pharyngitis as a result of Bordetella species, F. tularensis, Streptobacillus moniliformis, and Yersinia pestis. Birds carry Chlamydophila psittaci, which can cause an atypical exudative pharyngitis in humans.
LOWER RESPIRATORY ZOONOTIC INFECTIONS
Zoonotic pneumonia presents as an atypical, community­acquired pneumonia with systemic symptoms. Most often, the presentation is productive or nonproductive cough, fever, chills, headache, myalgias, and a nonspecific rash. Symptoms can progress very rapidly. Ask about animal exposure, occupation, and recent travel. Consider zoonotic pneumonia as a source of gram­negative community­acquired pneumonia and in any case of atypical pneumonia with systemic symptoms (Table 161­6).
TABLE 161­6
Zoonotic Pneumonias
Disease Organism Reservoirs Treatment
Inhalation Bacillus Imported animal Adult initial treatment: ciprofloxacin, 400 milligrams IV every  h (alternative: doxycycline, anthrax anthracis hides, raw wool, sick 100 milligrams IV every  h or levofloxacin, 500 milligrams every  h), + clindamycin, 900 domestic animals milligrams IV every  h, + rifampin, 300 milligrams IV every  h.
Plus one­time infusion raxibacumab,  milligrams/kg diluted over .25 h.
When clinically stable: ciprofloxacin, 500 milligrams PO twice a day, + clindamycin, 450 milligrams PO every  h, + rifampin, 300 milligrams PO twice a day.
Treat for  d.
Brucellosis Brucella Food animals and Mild disease: doxycycline, 100 milligrams PO twice a day for  weeks, + gentamicin,  species product handling, milligrams/kg IV daily for  d.
ingestion, inhalation Alternative: doxycycline, 100 milligrams PO twice a day, + rifampin, 600–900 milligrams PO daily for  weeks.
Joint involvement: doxycycline, 100 milligrams PO twice a day, + rifampin, 600–900 milligrams PO daily for  months, + gentamicin,  milligrams/kg IV once daily for first  d.
Neurologic involvement: doxycycline, 100 milligrams IV/PO twice a day, + rifampin, 600–900 milligrams PO daily, + ceftriaxone,  grams IV twice a day. Treat until cerebrospinal fluid normalizes.
Psittacosis, Chlamydophila Bird exposure—pet Doxycycline, 100 milligrams PO for 5–7 d.
ornithosis psittaci and pet shop, Alternative: azithromycin dose pack or levofloxacin, 750 milligrams PO for 5–7 d.
veterinarians, turkey farms
Q fever Coxiella Inhaled endospores Doxycycline, 100 milligrams PO twice a day for 2–3 weeks.
burnetii from animal­ Alternative: consider 2–3 weeks of a fluoroquinolone or a macrolide.
contaminated soil; cat afterbirth, ticks
Tularemia Francisella Aerosol from dead Adults: streptomycin,  gram IM/IV twice a day, or gentamicin/tobramycin,  milligrams/kg tularensis birds, animals; IV divided every  h. Treat for  d.
bacteremic spread Children: streptomycin,  milligrams/kg IM twice daily (should not exceed  grams/d).
from bubo; ticks and Mild disease: ciprofloxacin 750 milligrams PO twice a day or doxycycline 100 milligrams PO biting flies twice a day. Treat for  d.
Prophylaxis for lab exposures: doxycycline 100 milligrams PO twice a day or ciprofloxacin
500 milligrams PO twice a day. Treat for  d.
Leptospirosis Leptospira Domestic and wild Mild disease: doxycycline, 100 milligrams PO twice a day for 5–7 d.
interrogans animals, Alternative: azithromycin, 500 milligrams PO daily for  d.
contaminated water, Severe disease: penicillin G, .5 million units IV every  h for  d, or ceftriaxone,  grams IV veterinarians, farmers daily for  d.
Alternative: doxycycline, 100 milligrams IV for  d.
Pasteurellosis Pasteurella Underlying Amoxicillin­clavulanate, 875/125 milligrams PO twice a day for 7–10 d.
multocida respiratory disease; Alternative therapies based on culture data and presence of Staphylococcus coinfection.
contact with cat, dog Often resistant to cephalexin, clindamycin, and macrolides.
in home
Rocky Rickettsia Tick­associated, Doxycycline 100 milligrams PO or IV twice a day for  d, or for  d after temperature
Mountain rickettsii typical rash normalizes. Some recommendations exist for an initial loading dose of 200 milligrams. For spotted fever children weighing <45 kg, the dose is .2 milligrams/kg twice daily. Although doxycycline is contraindicated for use in pregnancy, it may be warranted in life­threatening situations.
Chloramphenicol is an alternative; however, it has multiple toxic effects and contraindications, and may be difficult to obtain. Dosing is  milligrams/kg/d divided into
 doses for  d.
Toxoplasmosis Toxoplasma Contact with domestic Severe disease: gondii food animals and Pyrimethamine, 200 milligrams PO on d , followed by 50–75 milligrams PO every  h, + pets, ingestion of sulfadiazine, 1–1.5 grams PO every  h, + leucovorin, 5–20 milligrams  times weekly.
cysts, pneumonia in If ocular involvement, treat as above and add prednisone, .5 milligrams/kg PO twice a day.
immunocompromised Treat until 1–2 weeks after symptoms resolve, continue leucovorin for  week past that.
persons
Plague Yersinia pestis Contact with Gentamicin,  milligrams/kg IV daily for  d.
mammals and fleas; Alternative: streptomycin,  milligrams/kg IV/IM twice a day for  d.
veterinarians; outdoor Postexposure prophylaxis: doxycycline, 100 milligrams PO twice a day, or ciprofloxacin, 500 activities in endemic milligrams PO twice a day for  d.
area; cats
Hantavirus Bunyaviridae Rodent feces, urine, Extracorporeal membrane oxygenation or consideration of ribavirin pulmonary and saliva syndrome
ANTHRAX
Inhalation anthrax (Bacillus anthracis) is acquired most often from handling unsterilized, imported animal hides or imported raw wool; anthrax is generally fatal. Inhalation anthrax is a mediastinitis without alveolar involvement rather than pneumonia. Initial symptoms are similar to influenza with a slightly higher propensity for dyspnea. Illness can progress to respiratory failure in  to  days, with marked mediastinal and hilar edema. Anthrax vaccination is available primarily for populations at high risk of exposure to aerosolized B. anthracis spores such as military personnel and
 laboratory workers.
A 60­day antibiotic course combined with a three­dose vaccination course used in postexposure prophylaxis may aid in preventing anthrax
 postexposure, although this regimen is not presently approved by the U.S. Food and Drug Administration. Antibiotics typically used in inhalation anthrax are doxycycline or ciprofloxacin, plus an additional one or two agents for synergy, including penicillin G, vancomycin, rifampin, or other agents
 for which the strain is suspected to be sensitive. Cephalosporins are contraindicated due to resistance.
BRUCELLOSIS
Brucellosis (Brucella species) occurs most often from the consumption of unpasteurized dairy products. Reports of slaughterhouse workers exposed
 to aerosols containing Brucella bacteria becoming ill exist. In the rare inhalation form of Brucellosis, patients have the appearance of an upper respiratory infection with a cough, productive sputum, hoarseness of voice, dyspnea, and wheezing. There are no pathognomonic signs on chest radiograph, and a variety of findings may be present including pneumonia, adenopathy, effusion, granulomas, and effusion. With long­standing
 resolution, calcified granulomas may remain. Doxycycline combined with rifampin is effective therapy; the recommended duration is  weeks to
 prevent recurrence (Table 161­6).
PSITTACOSIS
Psittacosis (parrot fever, parrot disease) is caused by Chlamydophila psittaci, an organism common to most birds and domesticated fowl. Psittacosis is the term for disease contracted from parrots, and ornithosis is the term for disease contracted from pigeons, sparrows, ducks, hens, and many other birds. This disease is rare, with few cases reported annually in the United States, although underreporting is likely due to the often mild unrecognized
 form of disease. Human acquisition is from the inhalation of dust from dried bird feces, feather dust, aerosolized avian respiratory secretions, or
 direct bird contact. Psittacosis is characterized by an incubation period of  to  days followed by abrupt onset of fever, chills, cephalgia, myalgia, and generalized malaise. Pneumonia is atypical, with a nonproductive cough and lobar or interstitial infiltrates on chest radiograph. Extrapulmonary manifestations including endocarditis, hepatitis, cranial nerve palsies, and acute interstitial nephritis are possible. Diagnosis is based on clinical suspicion for the disease and confirmation of isolation of C. psittaci from respiratory secretions or by immunoglobulin M immunoassay. Doxycycline is
 the mainstay of treatment, with most patients responding rapidly to therapy. Tetracycline is also an option along with macrolides (Table 161­6).
Q FEVER

Q fever (Coxiella burnetii) is a rickettsial infection acquired by aerosol inhalation primarily; however, arthropod vector transmission is possible. The primary reservoirs are cattle, sheep, and goats, with bacterial shedding in urine, afterbirth products, and feces. The organism is highly resistant to environmental degradation. The disease is often self­limited, with variable pulmonary manifestations and extrapulmonary findings. In addition to pulmonary infiltrates, severe headache, pericarditis, myocarditis, endocarditis, and a nonjaundiced hepatitis can occur. The majority of patients have
 nonspecific infiltrates on chest radiograph. Doxycycline is the treatment of choice for acute Q fever and is most effective in reducing duration of symptoms and risk of complications when initiated within the first  days of illness. Q fever may rarely progress to a chronic infective state with fatigue
 and extrapulmonary manifestations being predominant findings (Table 161­6).
PASTEURELLOSIS
Pasteurellosis (Pasteurella multocida) is endemic to the normal oral flora of cats and most dogs. Classically, infection is associated with necrotizing cellulitis from bite wounds. Rarely bronchitis, bronchopneumonia, and suppurative pleural effusion occur as a result of pulmonary infection.
Treatment is with amoxicillin­clavulanate, doxycycline, penicillin, or a third­generation cephalosporin (Table 161­6).
PULMONIC PLAGUE
Between 1000 and 2000 cases of plague are reported each year to the World Health Organization, with mortality rates of approximately 10%. Most human cases today are in sub­Saharan Africa. In the United States, pulmonary plague (Yersinia pestis) is most often found in rock squirrels and ground rodents of the Southwest. Cats can be carriers of plague, whereas dogs are resistant to the disease. The principal vector is the rodent flea, with the
 majority of infected fleas globally found on black rats or brown sewer rats. Humans and household pets become infected when bitten by a harboring flea or by consuming other infected animals. Humans may also be infected by inhalation of animal secretions. Incubation period from a flea bite to disease ranges from  to  days. Often an eschar develops at the site of the flea bite, followed by the development of a bubo, an enlarged, suppurative, proximal lymph node. Sepsis and pneumonia from hematologic spread occur following the bubo appearance. The disease is rapidly fatal if not aggressively treated.
Start treatment when plague is suspected, using parenteral streptomycin or gentamicin. Transition to oral therapy with doxycycline, ciprofloxacin, or chloramphenicol occurs after improvement, although these agents can be used as initial therapy in those who cannot tolerate the preferred choice.

Continue any therapy for at least  days or  days after resolution of fever (Table 161­6).
HANTAVIRUS
Hantavirus, identified in 1977, is from the Sin Nombre virus, which belongs to the Bunyaviridae family of viruses. The deer mouse (Peromyscus
 maniculatus) is the primary vector in the southwestern United States. Infected rodents excrete hantavirus in feces, urine, and saliva. Human infection occurs with the inhalation of dried, particulate feces, by contact with urine, or by a rodent bite. In Asia, hantaviruses can cause hemorrhagic fever with renal syndrome—acute renal failure with concurrent thrombocytopenia, ocular abnormalities, and flulike symptoms. In the United States, the
 presentation of this zoonosis is that of a cardiopulmonary syndrome, which consists of an initial flulike prodromal illness of  to  days in duration, rapidly followed by pulmonary edema, hypoxia, hypotension, tachycardia, and metabolic acidosis. Dizziness, nausea, vomiting, absence of cough, and thrombocytopenia are common and may help to differentiate hantavirus pulmonary syndrome from acute respiratory distress syndrome, bacterial pneumonia, and influenza pneumonia. Hantavirus pulmonary syndrome carries a very high mortality rate, initially estimated around 60%, but that has
 now improved to 30% with efforts toward recognition and early aggressive care. Diagnosis is with an immunofluorescent or immunoblot assay.

Treatment is supportive.
SELECTED DERMATOLOGIC ZOONOTIC INFECTIONS
Dermatologic findings are common in zoonotic infections because the skin is often the site of inoculation. Ulcerations at the site of inoculation
(chancres), typically on the hands or forearms, can result from zoonotic infection caused by bacteria, mycobacteria, fungi, or viruses.
BACTERIAL AND VIRAL ZOONOTIC SKIN INFECTIONS
The most well­described bacterial chancriform zoonotic lesions are B. anthracis (anthrax), B. henselae (cat­scratch disease), Erysipelothrix rhusiopathiae (erysipeloid), F. tularensis (tularemia), Listeria monocytogenes (listeriosis), Mycobacterium marinum (aquarium granuloma), and

Burkholderia mallei (glanders). Most chancriform zoonotic infections occur in livestock workers, cattle ranchers, veterinarians, stable workers, horse trainers, slaughterhouse workers, poultry workers, and farmers. Significant zoonotic fungal infection is principally from Blastomyces dermatitidis
(cutaneous blastomycosis) and Sporothrix schenckii (sporotrichosis). Dog and cat owners, along with veterinarians, are most at risk of contracting these two fungal zoonoses.
Viral zoonotic dermatoses include Vaccinia species (cowpox), Paravaccinia species (pseudocowpox), and bovine papular stomatitis. These cutaneous viral zoonoses often occur on the hands and forearms of patients who work closely with cattle, sheep, goats, or horses. Systemic zoonoses can be accompanied by a nonspecific generalized maculopapular rash, which does not facilitate the diagnosis.
CUTANEOUS ANTHRAX

Cutaneous anthrax, also known as woolsorter’s disease, accounts for 95% of all anthrax infections. Cutaneous anthrax is most common in groups
 dependent on and in close contact with livestock and in agriculture­based societies. Recently, localized outbreaks occurred in injection drug users.
The hands and fingers are the most commonly infected areas of the body, but arms, lower legs, and feet can also be involved. After deposit of anthrax spores in a skin wound, a painless or pruritic macule develops  to  days later at the inoculum site. The macule evolves into an ulcerative site with multiple serosanguinous vesicles. Vesicles contain the anthrax bacillus and are infectious. Gram stain or culture of the vesicular fluid is often diagnostic. The ulcer progresses to a painless black eschar and falls off within  weeks. If purulence is present, suspect secondary bacterial superinfection. Untreated, mortality is between 5% and 20% with progression to shock possible. If the disease is acquired naturally (i.e., bioterrorism
 not a concern), penicillin or amoxicillin for  to  days is the primary treatment. Other patients are treated with oral ciprofloxacin for  days, with doxycycline as an alternative option.
ZOONOSES ACQUIRED FROM HOUSEHOLD PETS
Dogs and cats are the two most common household pets in North America and account for the majority of these zoonotic infections. Small rodents, pet
 birds, reptiles, and aquarium fish account for only a fraction of the zoonotic infections in the United States (Table 161­7). A growing trend of
 individuals owning small flocks of chickens and other poultry led to >70 outbreaks of Salmonella since 2000. Although hand washing is often key to prevention, the number of outbreaks has increased as residential livestock have become more common.
TABLE 161­7
Pet­Associated Zoonotic Infections
Dog: anthrax, brucellosis, campylobacteriosis, cryptosporidiosis, dipylidiasis, echinococcosis, histoplasmosis, leptospirosis, pasteurellosis, rabies,
Rocky Mountain spotted fever, salmonellosis, toxocariasis, tularemia, yersiniosis
Cat: anthrax, campylobacteriosis, cryptosporidiosis, histoplasmosis, pasteurellosis, plague, Q fever, rabies, salmonellosis, toxocariasis, tularemia
Bird and fowl: Cryptococcus, erysipeloid, listeriosis, Mycobacterium, psittacosis/ornithosis (Chlamydophila psittaci), salmonellosis, tularemia, viral encephalitis
Rodent: leptospirosis, listeriosis, lymphocytic choriomeningitis, murine typhus, plague, rat­bite fever (Streptobacillus moniliformis), salmonellosis, tularemia, yersiniosis
Fish and reptiles: erysipeloid, Mycobacterium marinum, salmonellosis, Streptococcus iniae, vibriosis
HELMINTHS (WORMS)
Up to 50% of dogs are infected with at least one intestinal parasite, and 15% of adult dogs actively excrete Toxocara canis, the source of toxocariasis
 and visceral larva migrans. Despite its prevalence in dogs, human toxocariasis is infrequently diagnosed, probably because infection is often subclinical. Typically, the only indication of infection is eosinophilia. Children may display fever, cough, nonspecific rash, and failure to thrive. Rarely, pulmonary infiltrates, hepatosplenomegaly, and seizures may occur. Diagnosis is by either biopsy of infected tissue or by enzyme­linked immunosorbent assay. Treatment in the symptomatic patient consists of albendazole or mebendazole (Table 161­5). Corticosteroids can be used to control the allergic component.
Other intestinal parasites transmitted to humans from household pets include Ancylostoma caninum or braziliense (cutaneous larva migrans),

Echinococcus granulosus (echinococcosis), and Dipylidium caninum (dipylidiasis or dog and cat tapeworm).
Cutaneous larva migrans is often a self­limiting, pruritic, erythematous serpiginous rash caused by a migrating hookworm larva in the skin acquired from fecally contaminated soil. Single­dose ivermectin is the preferred treatment in patients over  years of age. Multiple­dose albendazole is another option, as is topical thiabendazole. Although dogs and other carnivores are the definitive hosts for E. granulosus, echinococcosis is most common in areas of cattle and sheep ranching. This zoonosis involves multiple organ systems: liver, lung, muscle, bone, kidney, and brain. Typically, there is a unilocular cyst containing multiple larvae that enlarge over time. Definitive treatment is surgical; however, leakage of the cystic fluid can spread the infection and cause an anaphylactic reaction. Should the lesion not be anatomically favorable for unruptured excision, pharmacotherapy with
 benzimidazoles can be used, but recurrence is high.
PROTOZOA
Cats are the host of the intracellular protozoan Toxoplasma gondii, which causes toxoplasmosis. Human toxoplasmosis can occur in three ways: by ingestion of uncooked or raw meat, especially pork or mutton containing the Toxoplasma cysts; by ingestion of the oocysts from cat and wild­animal
 feces; and transplacentally. Transplacental transmission can result in fetal abnormalities including retinochoroiditis, hydrocephalus, hepatosplenomegaly, and thrombocytopenia. Pregnant women should limit their contact to only indoor cats, avoid changing cat litter, and wear gloves when gardening or in contact with soil or sand that could be contaminated with toxoplasma. The encysted trophozoite can become reactivated in a previously infected host if the host becomes immunocompromised. Treatment of acute chorioretinitis, of severely symptomatic patients, or in certain pregnancy conditions is with pyrimethamine (25 to 100 milligrams/d PO for  to  weeks) plus sulfadiazine (1.0 to .5 grams PO four times a day for  to
,41
 weeks) and folinic acid.
IMMUNOCOMPROMISED PATIENTS
Immunocompromised patients include those with congenital immunodeficiencies, diabetes mellitus, chronic renal failure, or liver failure; splenectomized patients; chronic alcoholics; cancer patients; transplanted patients; and human immunodeficiency virus–positive patients. Of all of these patients, those undergoing chemotherapy and those with acquired immunodeficiency syndrome have the greatest risk of acquiring a zoonotic
 infection. Salmonella and Campylobacter are the two most common infections acquired by immunocompromised patients from their pets, but the overall risk of transmission of Salmonella and Campylobacter from contact with pets is low. Other acquired zoonotic infections in immunocompromised patients are listed in Table 161­8. TABLE 161­8
Zoonotic Infections in Immunocompromised Patients
Infection Source Clinical Findings Antibiotic Treatment
Cat­scratch disease, Cats Pyogenic granulomas, regional lymphadenopathy, Azithromycin
Bartonella and fever Add rifampin for severe disease henselae
Bordetella Dogs Fever, pharyngitis, and cough TMP­SMX, fluoroquinolones, azithromycin if bronchiseptica Bordetella pertussis suspected
Campylobacter Dogs, cats Gastroenteritis and diarrhea See Chapter 160, “Food and Waterborne Illnesses” species
Cryptococcus Bird droppings Flulike symptoms early, photophobia, headache, Mild disease: fluconazole neoformans and cats cranial nerve symptoms, and meningeal irritation Severe: amphotericin B + flucytosine followed by later fluconazole
Cryptosporidium Dogs Diarrhea Immunocompetent host: nitazoxanide
HIV positive: HAART only
Giardia lamblia Dogs, cats Gastroenteritis and diarrhea See Chapter 160. Listeria Livestock and Sepsis and meningitis Severe disease: ampicillin + gentamicin monocytogenes dairy products Gastroenteritis in at­risk population: amoxicillin or
TMP­SMX
Mycobacterium
M. avium Pet birds Pneumonia and gastroenteritis Clarithromycin or azithromycin
+ ethambutol
+ rifampin
M. marinum Fish Cutaneous granulomas, skin ulcerations at distal Clarithromycin, minocycline, doxycycline, TMP­SMX, extremities or rifampin + ethambutol
Rhodococcus equi Farm animals Pneumonia and cavitating lung lesions Two of the following agents: levofloxacin, rifampin, azithromycin, ciprofloxacin, imipenem, vancomycin
Salmonella, Dogs, cats, Gastroenteritis, diarrhea, and sepsis See Chapter 160. Salmonella species reptiles, poultry, livestock
Toxoplasmosis, Cats Pneumonia, brain abscesses, encephalitis, and ocular Pyrimethamine + sulfadiazine + folinic acid
Toxoplasma gondii disease
Abbreviations: HAART = highly active antiretroviral therapy; HIV = human immunodeficiency virus; TMP­SMX = trimethoprim­sulfamethoxazole.


