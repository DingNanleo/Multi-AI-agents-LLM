University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 13: Approach to Traumatic Shock
David M. Somand; Kevin R. Ward
INTRODUCTION
Severe hemorrhage after injury carries a mortality rate of 30% to 40% and is responsible for almost 50% of deaths occurring within  hours of injury. Hemorrhagic shock is an important contributor to postresuscitation organ failure and late mortality. Resuscitation of traumatic shock, starting in the prehospital setting and continuing throughout the victim’s care in the ED and on into the hospital, has the goal of restoring the necessary level of tissue perfusion and oxygenation for survival while simultaneously limiting further volume loss.
This chapter focuses on the issues related to fluid and blood resuscitation in traumatic shock, with an emphasis on hemorrhagic shock. Processes that cause loss of plasma fluid and electrolytes (e.g., burns, sepsis), often requiring aggressive fluid therapy, are discussed in other chapters (see Chapter 151, “Sepsis,” and Chapter 217, “Thermal Burns”).
The principal objectives of fluid and blood resuscitation in traumatic shock are (1) to restore intravascular volume sufficient to maintain oxygencarrying capacity and tissue perfusion for adequate cellular oxygen delivery and (2) to prevent or correct derangements in coagulation.
PATHOPHYSIOLOGY
Hemorrhagic shock creates a state of impaired oxidative metabolism and homeostasis, due to inadequate oxygen delivery to meet metabolic demand, and hypoperfusion leading to inadequate cellular waste removal. Hemorrhagic shock triggers a complex range of physiologic responses that may temporarily compensate for intravascular volume loss and maintain perfusion to the most important vascular beds. Shock also produces a global insult to the vascular endothelium that activates the coagulation and inflammatory systems (Figure 13­1). When uncorrected, coagulopathy, additional inflammation, and organ system damage will result.

FIGURE 13­1
Endothelium­mediated activation of the triad of hypoxia, inflammation, and coagulation. [©Kevin R. Ward, MD.]
While moderate transient hypoperfusion may be well tolerated, prolonged or severe hypoperfusion leads to accumulation of oxygen debt and progressive cellular and organ dysfunction. If rapid and severe, sudden cardiovascular collapse and death may occur.

Coagulopathy observed in trauma victims, termed trauma­induced coagulopathy, is ascribed to a combination of factors beginning with tissue hypoxia, loss of coagulation factors from hemorrhage followed by hemodilution from crystalloid resuscitation, and then exacerbated by acidosis (evidenced by a base deficit) and hypothermia that occur during the course of ongoing hemorrhage and resuscitation. However, acidosis does not, by itself, have a significant effect on coagulation until the pH decreases below 7.0. 

The normal total circulating volume of an adult is approximately 7% of ideal body weight or about  L for an average 70­kg adult patient divided into about  L of plasma and  L of red blood cell volume (Table 13­1). Replacement of lost blood with room temperature isotonic unbuffered crystalloid contributes to hypothermia, hemodilution, and acidosis.

TABLE 13­1
Adult Fluid Spaces
Fluid Compartment % Body Weight* % Body Water* Volume* (70 kg)
Total body water  100  L
Intracellular    L
Extracellular    L
Interstitial    L
Intravascular ~7–8 ~11–13 ~5.0–5.5 L
Plasma ~4.0–4.5 ~7 ~3.0–3.5 L
Red blood cells† ~3.0–3.5 ~5 ~2.0–2.5 L
*Approximate percentage and amount.
†Percentages do not add up to 100% because fluid contained within intravascular red blood cells is included within the intracellular fluid compartment.

Early trauma­induced coagulopathy is characterized by anticoagulation and hyperfibrinolysis modulated through the protein C pathway. Endothelial damage associated with trauma stimulates an increase in thrombomodulin expression on the endothelium that complexes with thrombin and in turn activates protein C (Figure 13­2). Complexed thrombin is now no longer available for its usual hemostatic role of cleaving fibrinogen to form fibrin. Subsequent consumption of plasminogen activator inhibitor­1 by activated protein C contributes to hyperfibrinolysis (Figure 13­2).

FIGURE 13­2
Endothelial damage results in increased thrombomodulin (TM) expression. TM can complex with thrombin (thrombin­TM complex), leading to activation of the protein C (PtnC to aPtnC) pathway. Modulated through a multistep pathway leading to plasminogen activator inhibitor­1 (PAI­1), fibrinolysis is encouraged, resulting in increased fibrin degradation products (FDPs). In addition, the complexed thrombin is no longer able to perform its usual role in cleaving fibrinogen to fibrin to form clots.

Thrombomodulin normally found in the endothelium may be viewed as locally protective because it is able to sequester thrombin and thus allow for generation of adequate levels of protein C to prevent thrombosis caused by local low­flow states. However, on a systemic level, this appropriate local response may become pathologic, resulting in clotting inhibition.

CLINICAL FEATURES
The clinical appearance of acute traumatic shock is variable and depends on the cause, rate, volume, and duration of volume loss or bleeding; the presence of other acute disorders; the effects of current medications; and the patient’s baseline physiologic status.

The hemodynamic response to acute severe hemorrhage­induced hypovolemia traditionally includes tachycardia, hypotension, and signs of poor peripheral perfusion (cool, pale, clammy extremities with weak peripheral pulses and prolonged capillary refill). Arterial and venous vasoconstriction leads to a narrowing of the pulse pressure. Cerebral hypoperfusion causes alterations in mental status. With increasing blood loss, signs and symptoms become more pronounced. Classification of hemorrhage severity as a percentage of blood volume loss estimated based on
 systolic blood pressure, heart rate, and Glasgow Coma Scale is not reliable and should not be used to guide ED resuscitation.
Patients with excellent baseline physiologic status (e.g., young athletes) may have such a robust compensatory response to hemorrhage that they appear stable and do not manifest tachycardia or hypotension, even with large blood volume loss. Signs of peripheral hypoperfusion and subtle mental status alterations may be the only clues that the severity of hemorrhage is greater than predicted based on hemodynamic parameters. Elderly patients may not develop tachycardia due to underlying heart disease or medications such as β­adrenergic blockers. Bradycardia or lack of tachycardia may occur in about 30% of patients with intra­abdominal hemorrhage from increased vagal tone in response to hemoperitoneum. In a pregnant trauma patient, compression of the inferior vena cava by the gravid uterus can decrease central venous return and worsen hypotension and tachycardia in the setting of less severe hemorrhage.

DIAGNOSIS
Vital signs offer little value unless they are in extreme low ranges. Arterial blood pressure does not adequately reflect cardiac output or regional perfusion. Clinical evidence of peripheral hypoperfusion is useful but is not a quantitative measurement. Metabolic information (discussed later), assessment of mechanisms of injury, and appropriate imaging studies offer the best chance for early recognition of severe hemorrhage and for guiding an appropriate response to treatment.
There is a biphasic relationship between oxygen consumption and oxygen delivery (Figure 13­3). This relationship exists for the body as a whole, but also is present in each individual organ system largely mediated by the microcirculation. Oxygen debt develops in tissues or organs when oxygen delivery does not meet the metabolic demands and represents the amount of extra oxygen that is needed to metabolize the accumulated products of anaerobic metabolism once perfusion is restored. Total oxygen debt is the accumulation of multiple oxygen deficits over time and is a measure of whole­body ischemia. Oxygen debt is the only physiologic measure that has clearly been linked to both mortality and morbidity in the form of multiple
 organ failure after shock. The degree of oxygen debt incurred after injury has also been clearly linked to inflammation.
FIGURE 13­3
The biphasic relationship of oxygen delivery (DO ) and oxygen consumption (VO ). As DO decreases, VO may remain constant due to an increase in
    the ratio of extracted oxygen (OER) at the tissue level. This is mirrored by a decrease in venous hemoglobin oxygen saturation (SvO ). However, at some
 point, OER will not meet the VO demands of the tissues, resulting in a state of DO dependent VO whereby aerobic VO transitions to anaerobic VO .

At this point of critical DO , oxygen debt begins to accumulate along with metabolic by­products of anaerobiosis such as lactate. While this relationship
 exists for the body as a whole, it also exists for each individual organ system and is largely mediated by the microcirculation. [© Kevin R. Ward, MD.]
Measurements of lactate and base deficit are commonly used in trauma centers and EDs to detect occult shock. Using lactate and/or base deficit as a resuscitation trigger and its clearance/normalization as an endpoint is associated with improvements in survival. However, elevated lactate and base deficit are late findings. An earlier finding is an increase in oxygen extraction, indicated by a decrease in indicators of oxygen consumption such as mixed or central venous hemoglobin oxygen saturation (Figure 13­2). Furthermore, improvements in oxygen delivery resulting in lactate clearance do not indicate that oxygen extraction is normal. Although lactate is also a measure of oxygen debt, its resolution during resuscitation does not ensure the important repayment and resolution of oxygen debt.
To overcome the limitations with intermittent lactate or base deficit measurement, continuous measures of oxygen consumption surrogates are available in the form of invasive oximetric catheters measuring central venous oxygen saturation (ScvO ) and tissue oxygen saturation (StO ) noninvasively from target tissues such as skeletal muscle using near­infrared spectroscopy. StO measurements with infrared spectroscopy are based on the fact that tissue blood volume is 70% to 80% venous blood with the remaining 10% to 20% a combination of arterial and capillary blood. Thus, aggregate measures of hemoglobin oxygenation in the tissue are heavily dominated by the venous blood and thus the postextraction compartment.
Although not an exact mirror of ScvO , ensuring StO values above 50% appears to be reasonable from both a diagnostic and treatment standpoint to begin and sustain hemostatic resuscitation. A target StO or ScvO between 60% and 70% should be maintained to help ensure resolution of tissue hypoxia.

TREATMENT
Resuscitation begins in the prehospital setting and continues in the ED. The priority for prehospital care is treatment of life­threatening conditions and rapid transport to an appropriate facility. For the hemorrhaging patient, this entails ensuring adequate ventilation and oxygenation (including securing an airway if necessary), controlling external bleeding (if present), and protecting the spinal cord (if potentially vulnerable).
In the ED, priorities are to restore intravascular volume to reverse or limit systemic and regional hypoperfusion, maintain oxygen­carrying capacity so that tissue oxygen delivery meets demand, limit ongoing blood loss, and prevent the development of coagulopathy. From the moment resuscitation begins, prevent the development of hypothermia by keeping the patient warm and administering warmed IV fluids and blood products. Endogenous hypothermia occurs when heat production from cellular respiration is decreased by hypoperfusion and inadequate tissue oxygen delivery. Major causes of exogenous hypothermia are exposure and the use of below­body­temperature fluid and blood resuscitation. Apply external warming devices early to prevent external heat escape. Warming devices that allow for the rapid warming of infused fluid and blood should be used for all patients in whom large­volume resuscitation is undertaken.
AIRWAY CONTROL, VENTILATION, AND OXYGENATION
If spontaneous ventilation is not adequate, intubate and ventilate to achieve an arterial hemoglobin oxygen saturation of ≥94%. Identify and treat potential respiratory conditions such as pneumothorax, tension pneumothorax, hemothorax, or upper airway obstruction.
VASCULAR ACCESS AND MONITORING
Establish adequate IV access concurrent with airway management. Large­bore (14­ to 16­gauge in adults) peripheral lines may be adequate if two or more can be secured. Intraosseous lines are suitable for resuscitation when peripheral IV access is problematic.
Institute continuous ECG heart rate monitoring, continuous pulse oximetry, and, if possible, continuous end­tidal carbon dioxide monitoring. Monitor arterial blood pressure, mental status, and peripheral perfusion frequently. Bedside FAST and POCUS are useful to identify intraperitoneal bleeding, assess cardiac function and volume status, and assist in central venous cannulation.
HEMOSTATIC­HYPOTENSIVE RESUSCITATION
A principle of hemostatic resuscitation is to limit intravascular volume expansion and avoid normalization of blood pressure. Complete normalization of blood pressure will raise hydrostatic pressure and can increase hemorrhage, which is particularly evident in noncompressible hemorrhage where raising blood pressure could potentially “pop the clot” and reestablish active hemorrhage.
Hypotensive resuscitation limits initial fluid resuscitation to an acceptable systolic blood pressure goal until surgical control of the bleeding is
 obtained, usually in the operating room. The acceptable value has sometimes been defined as  mm Hg (12.0 kPa), although there is no supporting data for this value. Alternatively, the specific value for acceptable systolic blood pressure can be pragmatically chosen as the initial value below which
 adverse physiologic outcomes increase. This occurs at about a systolic blood pressure of 110 mm Hg (14.7 kPa) for civilian trauma patients and 100
  mm Hg (13.3 kPa) for combat casualties. The overall benefit of low­volume hypotensive resuscitation is supported by civilian studies.
Hypotensive resuscitation may be harmful to some patients, such as those with head injury, hypertension, coronary artery disease, or cerebral vascular disease where a low systolic pressure exacerbates end­organ hypoperfusion. Hypotensive resuscitation should not be used in patients with
 myocardial disease, cerebral ischemia, or traumatic brain injury. Obviously, there is not an unlimited time span that patients can tolerate hypotensive resuscitation. From a cellular standpoint, patients will at some time incur irreversible damage from prolonged tissue hypoxia if adequate tissue oxygenation is not restored.
ISOTONIC CRYSTALLOID SOLUTIONS
Isotonic crystalloids—normal saline and lactated Ringer’s solution—are the most commonly used resuscitation fluids in the United States. Concerns about each fluid are as follows: (1) infusion of large volumes of either normal saline or lactated Ringer’s solution can cause increased neutrophil activation; (2) lactated Ringer’s solution can increase cytokine release and may increase lactic acidosis when given in large volumes; and (3) normal
 saline can exacerbate intracellular potassium depletion and cause hyperchloremic acidosis.
Crystalloid solutions are isotonic but hypo­oncotic, because they lack the large protein molecules present in the plasma. Low oncotic pressure results in substantial shifts of crystalloid to the extravascular space corresponding to the relative size of the intravascular and interstitial fluid compartments
(Table 13­2). This was the physiologic basis for the 3:1 ratio for crystalloid to blood; for every amount of blood lost, three times that amount of isotonic crystalloid is required to restore intravascular volume because, at best, about 30% of the infused fluid stays intravascular. Based on this rule, a loss of  L of blood (about 15% to 20% of total circulating blood volume) would require about  L of isotonic crystalloid to restore normovolemia, assuming no ongoing blood loss.
TABLE 13­2
Theoretical Volemic Effect of  L of Fluid Administration on Fluid Compartments
Intracellular (mL) Interstitial (mL) Plasma (mL)
5% dextrose in water 660 255 
Normal saline or Ringer’s lactate –100 825 275
.5% saline –2950 2960 990
5% albumin  500 500
Whole blood   1000
Common modifications of isotonic fluids include use of acetate instead of lactate in Ringer’s solution, Hartmann’s solution, and Plasma­Lyte® (Table
13­3). Plasma­Lyte is the shared name for a family of isotonic crystalloid solutions available worldwide, marketed with variation in composition according to regional preferences. Solutions containing lactate or acetate are considered balanced crystalloids because they are buffered and have a lower chloride concentration compared to normal saline. Balanced crystalloids yield better clinical outcomes compared to normal saline in both
,17 critically ill and non–critically ill patients from all causes, although the effect is small (number needed to treat is approximately 90). Ringer’s lactate is compatible with current red blood cell preservatives.
TABLE 13­3
Isotonic Fluid Composition* Fluid Na+ K+ Ca++ Mg++ CL– Buffer Osmolarity
(mmol/L) (mOsm/L)
(mmol/L) (mmol/L) (mmol/L) (mmol/L) (mmol/L)
Normal saline 154    154 None 308
Ringer’s 130  .4  109  lactate 273 lactate
Ringer’s 130    112  acetate 276 acetate
Hartmann’s 131    111  lactate 278
Plasma­Lyte 140   .5   acetate 294
A®  gluconate
*Minor variations may exist between different commercial manufacturers.
COLLOIDS
Despite theoretical and animal model benefits, clinical trials of colloid resuscitation for traumatic shock have not demonstrated a clear survival benefit
 or reduction in morbidity. The one advantage of colloids is that achievement of hemodynamic goals requires less volume to be infused. However, initiating resuscitation with plasma—a colloid solution—instead of crystalloids as part of a hemostatic resuscitation along with red cells as needed
 conferred a survival advantage in hypotensive predominantly blunt trauma patients transported by air medical services , but this effect was not seen
 in an urban ground EMS system with equal number of blunt and penetrating trauma victims. In light of these studies, serious consideration should be given to severely restricting the use of crystalloids and instead beginning the early use of blood products in blunt trauma victims, especially if
 ongoing hemorrhage is expected or operative repair is going to be delayed.
PACKED RED BLOOD CELLS
Packed red blood cells (PRBCs) are the most commonly transfused blood product (see Chapter 238, “Transfusion Therapy”). Using only PRBCs in the patient with traumatic shock and ongoing bleeding (without plasma and platelets) will do little to promote hemostasis and may not fully restore tissue oxygenation. If hemorrhage is definitively controlled, do not transfuse if the hemoglobin concentration is >7 grams/dL (>70 grams/L) for those
,22 without cardiopulmonary, cerebral, or peripheral vascular disease. For those with comorbidities such as coronary artery or cerebrovascular disease, clinical judgment should be used for achieving and maintaining minimum hemoglobin levels, with the general principle that there is no
,22 benefit to transfusion when the hemoglobin concentration is >10 grams/dL (>100 grams/L).
When possible, typed and cross­matched blood is preferable. However, if time and the patient’s clinical status do not permit full cross­matching, typespecific blood is the next option, followed by low­titer O­negative blood. In U.S. blood banks, whole blood is not routinely stocked, and only PRBCs are available. See Chapter 302, “Military Medicine,” for discussion of whole­blood transfusion in trauma combat casualty care.
PRBC transfusion obviously restores lost hemoglobin. Using current preservatives, PRBCs can be stored for up to  days, and the average age of a unit of blood administered in the United States is about  days. Stored red blood cells can lose deformability (storage lesion), limiting their ability to pass normally through capillary beds or even resulting in capillary plugging. The oxygen dissociation curve is altered by loss of ,3­diphosphoglycerate in the erythrocytes of stored PRBCs, impeding the off­loading of oxygen at the tissue level. Despite these changes, no consistent harm has been identified with use of “older” stored blood.
PLASMA
Fresh frozen plasma (FFP) is plasma obtained after the separation of whole blood from red blood cells and platelets and then frozen within  hours. A unit of FFP has a volume of 200 to 250 mL and contains all the coagulation factors present in fresh blood. Kept frozen, FFP can be stored for up to a year after the unit was collected. It takes between  and  minutes to thaw a unit of FFP in a 37°C water bath, which can limit availability in a massive transfusion situation. However, some major trauma centers and their respective blood banks keep thawed FFP (kept at 1°C to 6°C) available for immediate use. When transfusing FFP, ABO compatibility is required, but because there are no red cells in FFP, Rh compatibility is less important; universal donor FFP is typically AB+ (see Chapter 238) and does not require cross­matching for emergency use.

Dried plasma is currently used by combat medical personal in European and Israeli military forces. When reconstituted, this product both restores volume and hemostatic factors. There is no currently available U.S. Food and Drug Administration–approved dried plasma product.
PLATELETS
Platelets are collected from whole­blood donations or from single donors using apheresis techniques and can be stored for up to only  days. Six units of pooled random­donor platelet concentrate or one apheresis­collected single­donor platelet concentrate in an adult will increase platelet count up
  to ,000/mm (50 ×  /L).
MASSIVE TRANSFUSION PROTOCOLS
CONCEPT
Massive transfusion is generally defined as the requirement for >10 units of PRBCs within the first  hours of injury. An estimated 10% of military trauma patients and 3% to 5% of civilian trauma patients receive massive transfusion. Massive transfusion is not a substitute for definitive surgical
 hemostasis but enhances the ability to achieve surgical hemostasis and to limit complications. Several accurate and validated tools exist to predict
 the need for massive transfusion in trauma. The Assessment of Blood Consumption score uses four values available on patient arrival: penetrating mechanism of injury, positive FAST examination, blood pressure <90 mm Hg (<12.0 kPa), and pulse rate >120 beats/min. The presence of two or more
 variables has a sensitivity for massive transfusion of 76% to 90%, with a specificity of 67% to 87%. If hemorrhage is clinically significant and immediate hemostasis is not achievable, transition from crystalloid­based resuscitation to a plasma­based massive transfusion protocol.
Draw sufficient specimens from the patient early in anticipated massive transfusion because once the patient has received close to one blood volume of transfused products, new blood specimens will contain so much donor blood that cross­matching of subsequent units is difficult. Initially use isotonic solutions to begin resuscitation in predetermined aliquots (250 to 500 mL) while assessing the likelihood of ongoing active hemorrhage and
 the need for further resuscitation.
PROTOCOL
Soldiers receiving high ratios of plasma to PRBC (a plasma:PRBC ratio of approximately 1:1.4) have significantly improved survival rates compared with those receiving lower ratios (between 1:1.8 and 1:2.5). Additional evidence supporting this also comes from combat casualty care data suggesting that
 early administration of fresh whole blood (something not currently practical in civilian trauma) offers survival advantages. These survival
,31 observations using high plasma­to­PRBC ratios were confirmed by civilian studies.
High plasma­to­PRBC ratio resuscitation appears to also offer survival benefit independent of coagulopathy, and plasma may enhance cell survival by endothelial repair and reducing vascular permeability. It may also be that plasma is simply a superior fluid for perfusion and tissue oxygenation restoration.
In addition, many trauma centers now include early platelet administration in predetermined ratios to plasma and PRBC in their resuscitation protocols based on findings that platelet function can rapidly decrease soon after trauma. Studies using platelets during massive transfusion have
31–33 shown improved clinical outcomes in mortality and blood loss. Some experts advocate a 1:1:1 ratio of PRBCs to platelets to FFP during massive
 transfusion, but the optimal ratio is unknown. Likewise, the benefits with adjunctive agents such as prothrombin complex concentrates and
,33 fibrinogen concentrate included in some protocols are unknown.
An institution­specific massive transfusion protocol is recommended to guide the clinician when ordering blood components and to facilitate release from the blood bank (Figure 13­4).
FIGURE 13­4
Massive transfusion protocol (MTP) from the University of Michigan’s Level I Trauma Center. ABG = arterial blood gas; D/C = discontinue; DDAVP = desmopressin; FFP = fresh frozen plasma; MD = physician; Plts = platelets; PT = prothrombin time; RBCs = red blood cells; T&S = type and screen; U/O = urine output; VS = vital signs; VW = von Willebrand’s.
ADJUNCTS
Tranexamic Acid
Currently, tranexamic acid (an antifibrinolytic) is advocated early in the resuscitation of major trauma victims based on the early fibrinolytic phase of trauma­induced coagulopathy and on clinical studies suggesting improved survival. Military and civilian studies have shown that the administration of
34–36 tranexamic acid to bleeding trauma patients reduces overall mortality. Ongoing studies are seeking to define which specific patient group most benefits from the administration of tranexamic acid (see Chapter 254, “Trauma in Adults”).
Calcium

PRBCs and FFP contain citrate that can complex calcium, producing life­threatening hypocalcemia. Most massive transfusion protocols include the administration of calcium and/or monitoring of ionized calcium. Calcium chloride is preferred over calcium gluconate because a well­perfused liver is
 required to liberate more free calcium from calcium gluconate. Maintain ionized calcium levels at or above .9 mmol/L.

Viscoelastic Hemostatic Assays
The blood coagulation system consists of nearly  very tightly coupled biochemical reactions. Conventional coagulation testing such as the prothrombin time and activated partial thromboplastin time does not account for the cellular components of the clot such as red cells and platelets.
Because the blood clot itself consists of a complex three­dimensional network of cross­linked fibers made of fibrin, platelets, and red cells entrapped within this mesh, newer viscoelastic hemostatic assays, namely thromboelastography and rotational thromboelastometry, measure the physical and dynamic characteristics of clotting. Thromboelastography and thromboelastometry can detect trauma­induced coagulopathy and can be used to guide massive transfusion protocols better than traditional prothrombin time and activated partial thromboplastin time assays. Recent studies indicate trauma resuscitations guided by such viscoelastic hemostatic assays improve survival and reduce total blood product use.


