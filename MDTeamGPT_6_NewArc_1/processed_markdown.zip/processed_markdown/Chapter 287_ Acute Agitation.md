## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 287: Acute Agitation
Michael Wilson
INTRODUCTION AND EPIDEMIOLOGY
Patient agitation is frequently encountered in the ED. Although exact numbers are difficult to determine, it is likely that as many as .7 million episodes
1–4 of acute agitation are treated annually in U.S. EDs, with countless more in the prehospital setting.
Over the past several years, modern expert consensus both inside and outside the field of emergency medicine has called for improved treatment of
,5–8 agitated patients who need emergent treatment. Broadly, the following best practices have been recommended for optimum care:
Approach the agitated patient with safety in mind. This safety planning should start even before agitated patients arrive.
Attempt verbal de­escalation in all patients.
If agitation persists or worsens, employ a “show of concern.”
Treat underlying medical problems first.
Restraints should be used sparingly and only to protect the staff or patient from harm.
Target medication to the most likely cause of agitation and use oral medicines when possible.
Use second­generation antipsychotics as first­line agents in most situations not involving alcohol intoxication.
The underlying goal of treatment with every acutely agitated patient is to treat agitation in order to allow performance of a thorough medical
9–11 evaluation as soon as it safe to do so.
GENERAL THERAPEUTIC APPROACH
Agitation has been defined by many experts as a “temporary disruption of the typical physician­patient collaboration which has unintended
 consequences for the staff or other patients.” This broad definition encompasses more than the typical aggressive or violent patient, because by the time patients are agitated to the point of violence, treatment options are usually limited to restraints and forced medication.
It is important to treat acute agitation early, because nursing staff caring for the patient may be the most vulnerable to untreated agitation. A survey by the Emergency Nurses Association in 2011 indicated that .5% of emergency medicine nurses had been physically or verbally abused in the past 
 days. The National Emergency Department Safety Study surveyed staff at  U.S. EDs and found that at least 25% of ED staff felt safe at work

“sometimes,” “rarely,” or “never.” In another study conducted at a medium­size university teaching hospital, university police had to respond an
 average of twice daily to violent incidents.

An agitation scale may be helpful, as this provides a uniform way to communicate the level of agitation to other staff. There are currently nearly two dozen potential scales that have been used to rate agitation, but unfortunately, as of yet there has been no head­to­head research that has established
 the superiority of any of these scales. One scale that has been studied in an Australian ED as part of an ongoing sedation protocol is the Sedation

Assessment Tool (Table 287­1).
TABLE 287­1
DoSwendlaotaiodne dA s2s0e2s5s­m7e­1n t9 T:2o oPl SYcoourri nIPg Sisy s1t3e6m.142.159.127
Chapter 287: Acute Agitation, Michael Wilson 
. Terms of Use * Privacy Policy * Notice * Accessibility
Score Responsiveness Speech
+3 Combative, violent, out of control Continual loud outbursts
+2 Very anxious and agitated Loud outbursts
+1 Anxious/restless Normal/talkative
 Awake and calm/cooperative Normal
–1 Asleep but rouses if name called Slurring or prominent slowing
–2 Responds to physical stimulation Few recognizable words
–3 No response to stimulation Nil
In the single study assessing the Sedation Assessment Tool scoring system, patients who could not be calmed by verbal de­escalation or oral
 medication were administered parenteral medication at values of +2 or +3. SAFETY FIRST
There are few reliable predictors of when agitated patients will become aggressive or violent, although community studies and risk stratification tools have indicated that historical factors, such as which patients have been violent in the past, are reasonable predictors of which patients will become
,19 violent again. “Safety first” starts with the planning for, and recognition of, agitation. Although agitated patients may not always become aggressive, patients who are aggressive should only be approached by hospital security or police. If not immediately available, maintaining a safe distance and attempting verbal de­escalation should occur until security resources arrive. Agitated patients should have a prepared place in a separate room away from potential weapons and sharp objects, and there should be an easy way of notifying security if the need arises. Rooms should ideally
 have more than one exit, and external stimuli such as loud noises should be minimized.
SHOW OF CONCERN

Patients who require ongoing verbal de­escalation or who refuse medication may benefit from a show of concern. In this scenario, patients are approached with security agents and staff standing in a visible location outside the patient’s room. Oral medication is typically offered at this point, with the decision to use IM medication only if the patient continues to escalate and/or refuse medication. In the ED, this is typically done while awaiting medication or security at the bedside.
PHARMACOLOGY
FIRST­GENERATION ANTIPSYCHOTICS
The decision to administer IM or IV medication involuntarily requires a determination that the patient is not willing or capable of controlling behavior
 and that the patient is at risk of harm to self or others.
The presumed etiology of agitation will most likely guide the best choice of medication (Figure 287­1). Haloperidol and lorazepam are perhaps the
,23 most common combination used in U.S. EDs. Haloperidol, first approved by the U.S. Food and Drug Administration in 1967, is a butyrophenone
 with primary activity at the dopamine  receptor. Haloperidol, like all antipsychotics, carries a black box warning about the risks of use for dementiarelated psychosis. In addition, this medication lengthens QT intervals, is associated with motor­related side effects, and is likely not appropriate for
 use as a single agent. IV use is off­label.
FIGURE 287­1
A suggested algorithm for the treatment of acute agitation. BZN = benzodiazepine; EPS = extrapyramidal side effects; ETOH = alcohol; FDA = U.S. Food and Drug Administration. Low­dose haloperidol is considered <3.0 milligrams/d. [Reproduced with permission from Wilson MP, Pepper D, Currier GW, et al: The psychopharmacology of agitation: consensus statement of the American Association for Emergency Psychiatry Project Beta
Psychopharmacology Workgroup. West J Emerg Med 13: 26–34, 2012.]
There is no strong evidence that haloperidol alone is more efficacious than lorazepam in terms of number of people asleep or repeat injections and no
,25 strong evidence that the adverse effects of haloperidol are offset by concomitant use of lorazepam. Concomitant use of promethazine is an
 acceptable alternative to lorazepam and is recommended by the United Kingdom National Institute for Health and Care Excellence. Although addition
 of promethazine has better support from randomized trials, a recent Cochrane review found no evidence in one trial that there was any difference in acute dystonias by  hours after injection. Given both this and concerns over excessive sedation with the combination, an American expert consensus
 panel has recommended second­generation antipsychotics instead of this combination (see below).
Another medication in the butyrophenone class, droperidol, has often been used in the ED despite a Food and Drug Administration black box
,27­30 warning. Both haloperidol and droperidol are thought to have minimal interactions with other medications, although droperidol has been
 implicated in respiratory depression in alcohol­intoxicated patients. Droperidol may have a lower risk of movement­related side effects than
 haloperidol. When administering first­generation antipsychotics, identify and treat electrolyte disturbances, especially if using the IV route. Select an alternative agent if possible and provide continuous cardiac monitoring when administering the agent to patients receiving other QTc­prolonging medications.
KETAMINE
Another potential medication for agitation treatment is ketamine, an N­methyl­D­aspartate antagonist that has long been used in the ED for procedural
 sedation. The use of ketamine has been proposed as a treatment both for patients with excited delirium syndrome, a syndrome in which patients are
,35  at high risk of death if not emergently treated, and for patients who have proven refractory to other antipsychotics. However, the routine use of
 ketamine for severely agitated patients is not well studied, and most importantly, dose regimens have not been validated. Some suggest a dose of 
38–41 to  milligrams/kg IM or  to  milligrams IV. In the prehospital setting, use of ketamine for severely agitated patients may result in increased
38–41  adverse airway events requiring intubation upon arrival in the ED. Cole et al reported that 39% of patients who received  milligrams/kg IM required ED intubation. Severe hypersalivation was another reported complication. Although ketamine administered in the ED setting may be generally well tolerated with few vital sign abnormalities, other potential drawbacks include the inability of the patient to participate in their own care
 or provide history, the fact that ketamine is not a specific treatment for agitation, and the need for frequent redosing. In addition, there is some
 evidence from one small trial that the use of ketamine may worsen psychosis. A recent clinical policy from the American College of Emergency
Physicians stated that ketamine may be a “reasonable option” in the treatment of agitated patients, although it noted that there are no
 methodologically rigorous trials that support its use.
SECOND­GENERATION ANTIPSYCHOTICS
Given the side effects of first­generation antipsychotics, second­generation antipsychotics have been recommended by multiple expert panels as
,7 better first­line agents in patients who are not intoxicated with alcohol, although their efficacy may be similar to first­generation antipsychotics in
 reducing agitation. Certain second­generation antipsychotics may also be as effective as benzodiazepines. In a recent prospective nonrandomized
 study, for instance,  milligrams IM olanzapine achieved equally rapid sedation as  milligrams IM midazolam. Current guidelines also recommend that medication be administered at a dose that promotes calming but not sleep, as sleeping patients cannot generally be evaluated by physicians and
,45 nursing staff for disposition.
Second­generation antipsychotics antagonize dopamine  receptors to a lesser degree than first­generation antipsychotics and have a relatively
 higher affinity for other receptor types such as serotonin. Although second­generation antipsychotics such as olanzapine have a risk of side effects
 that is comparable to the use of haloperidol plus promethazine, use of second­generation antipsychotics does not cause as much somnolence. One expert consensus panel on the treatment of agitation recommended that medications be selected to target the presumed etiology of the agitation and that second­generation antipsychotics were almost always first­line treatment for agitation of psychiatric origin (Figure 287­1 and Table 287­2).
TABLE 287­2
Treatment of Agitation: Comparison of Agents
Half­
Drug PO or IM Dose Comments on IV Dosing
Life
Risperidone 1–6 milligrams/d, divided daily or twice a day  h N/A
(Risperdal®)
Olanzapine  milligrams × , may repeat  h after 1st dose, 21–54 Some studies have shown that IV olanzapine is efficacious, although it has a
(Zyprexa®) then  h after 2nd dose to max  milligrams h greater risk of airway adverse effects; it is not FDA approved for this route. IV
Consider lower doses or oral route in elderly or route may not offer additional advantages over PO or IM route.
alcohol­intoxicated patients.
Ziprasidone  milligrams ×  (may repeat every  h to  h Not studied
(Geodon®) maximum dose of  milligrams); alternatively, may administer  milligrams every  h
Haloperidol .5–10 milligrams every 1–4 h (use lowest 21–24 FDA black box warning for IV use
(Haldol®) effective dose; do not exceed 100 milligrams/d) h
Abbreviations: FDA = U.S. Food and Drug Administration; N/A = not applicable.
OTHER TREATMENTS
VERBAL DE­ESCALATION
A variety of other approaches have been recommended for the treatment of agitated patients. Perhaps the most common recommendation is the use
  of verbal de­escalation or “talking down” the patient. Use of verbal de­escalation is standard in many psychiatric settings and may even be useful in
 patients with dementia.
The goal of verbal de­escalation is to help the patient regain control. Clinicians should use the  principles in Table 287­3 to optimize the chances for
,49 successful verbal de­escalation.
TABLE 287­3
Principles of Verbal De­escalation
Respect personal space
Do not be provocative
Establish verbal contact
Be concise
Identify wants and feelings
Listen closely to what the patient is saying
Agree or agree to disagree
Lay down the law and set clear limits
Offer choices and optimism
Debrief the patient and staff
Source: Reproduced with permission from Richmond JS, Berlin JS, Fishkind AB, et al: Verbal De­escalation of the agitated patient: consensus statement of the
American Association for Emergency Psychiatry Project BETA De­escalation Workgroup. West J Emerg Med 13: 17–25, 2012. 
Verbal de­escalation likely does not need to be provided for long periods of time and may allow PO medication over IM injections. In some clinical
 trials of agitation, a high proportion of patients have been ineligible for medication treatment after successful verbal calming.
RESTRAINTS
,52,53
The decision to restrain has philosophical and legal implications. If possible, restraint should be placed by police, security officers, or similarly trained individuals. According to guidelines published by the American College of Emergency Physicians, restraint should be performed in the least
 restrictive manner possible (e.g., never face down) and only after verbal de­escalation is attempted. Although clinicians often assume that a restrained patient is safer for staff than an unrestrained patient, this may not be true, as most of the injuries to both patients and staff occur during
,56 restraint episodes. In addition, there are many disadvantages of restraint; it may consume a disproportionate share of ED resources, result in
57–59  increased lengths of stay in the ED, and be associated with poorer outpatient follow­up. In one study on ED lengths of stay, Weiss and colleagues found that restrained patients remain .2 hours longer on average in the ED than other psychiatric patients.
SPECIAL POPULATIONS
Pregnant women, elderly patients, and children represent specific subgroups in whom nonpharmacologic approaches are generally preferred over
60–63  antipsychotics or benzodiazepines, even though acute short­term use of these agents has occasionally been suggested in the ED literature. Extra
,65 attempts should be made to use nonpharmacologic treatments such as verbal de­escalation, which may work even in patients with dementia. If
66–68 medications must be used as a final resort, second­generation agents are preferred over first­generation agents. In elderly patients with delirium,
,69,70 the safest approach is to treat the underlying cause that is producing both the delirium and agitation. If medications are needed, second­
,71 generation agents and low­dose haloperidol (<3.0 milligrams/day) do not seem to worsen delirium. Avoid benzodiazepines and antihistamines.
For further discussion, see Chapter 149, “Behavioral Disorders in Children,” and Chapter 288, “Mental Health Disorders of the Elderly.”


