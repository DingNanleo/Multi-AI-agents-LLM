## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 182: Barbiturates
Chip Gresham; Frank LoVecchio
INTRODUCTION
Barbiturates are still the most common class of antiepileptic drugs used in developing countries, but their use is declining due to the introduction of
  safer, less toxic sedative­hypnotics (e.g., benzodiazepines) and second­generation anticonvulsants. Status epilepticus, severe ethanol and sedative
3­5  withdrawal syndromes, and toxicologic seizures are typically managed with benzodiazepines, but barbiturates have a useful role as second­line
7­9 agents. They are still used in combination drugs (e.g., butalbital) and alone (e.g., secobarbital) for the treatment of tension and migraine headaches
 and for refractory intracranial hypertension from focal and diffuse brain injury.
PHARMACOLOGY
Barbiturates are generally classified according to their duration of action, which is primarily dependent on lipid solubility and tissue distribution rather than the elimination half­life (Table 182­1).
TABLE 182­1
Selected Properties of Commonly Used Barbiturates in Adults
Long Acting* Intermediate Acting* Short Acting* Ultrashort Acting* Agent
Phenobarbital† Amobarbital Butalbital Pentobarbital Secobarbital Thiopental Methohexital
Duration of action (hours) >6 3–6 3–4 <3 <3 5–10 min 5–7 min
Elimination half­life (hours) 24–96 14–42 35–88 21–42 20–28 6–26 1–2
Hypnotic dose PO 300–500 100–200 50–200 100–200 50–100 100–200 50–100 IV
(milligrams)
Fatal dose, approximate  3–6 2–5 3–6 3–6 ND ND
(grams)‡
Abbreviation: ND = no data.
*This classification scheme is a convention only; it preceded the discovery that the elimination half­lives do not conform to the apparent duration of action.
†Only drug responsive to extracorporeal removal.
‡
In nontolerant individuals.
Barbiturates readily distribute throughout the body to most tissues, crossing the blood–brain barrier and placenta, and are excreted in breast milk.
Fetal blood barbiturate concentrations closely reflect maternal plasma levels, creating the potential for fetal withdrawal syndrome. Most barbiturates are metabolized in the liver to inactive metabolites, primarily through routes involving the cytochrome P450 system. The elimination half­life of
 barbiturates can be greatly shortened in infants and children and very prolonged in the elderly and in patients with liver or renal disease. Chronic
Chapter 182: Barbiturates, Chip Gresham; Frank LoVecchio b©a2r0b2it5u rMatceG ursaew i nHdilul.c Aesll aRcitgivhittsy Rofe tsheer vceydto. c hTreormmes Po4f 5U0s een * z yPmrievsa cayn dP moliacyy a * c Nceolteicraet e * tAhcec mesestiabbiloitlyism of concurrently taken therapeutic drugs such as oral contraceptives, anticoagulants, and corticosteroids.
Barbiturates’ main action is the depression of activity in the CNS and musculoskeletal system. In the CNS, this is accomplished by enhancing the
 action of the primary inhibitory neurotransmitter γ­aminobutyric acid at its receptor. When γ­aminobutyric acid binds to its chloride channel receptor, it causes it to open, resulting in a depolarization; the depolarization temporarily stabilizes the resting membrane potential and inhibits the firing of new action potentials. Barbiturates bind to the α subunit of the γ­aminobutyric acid receptor, causing an increase in the duration of opening of the cell membrane chloride channel; this results in prolonged depolarization and prolonged inactivity.
Benzodiazepines bind to a different site on the α subunit of the γ­aminobutyric acid receptor and increase the frequency with which the chloride channel opens. Increased duration, as opposed to increased frequency, is one of the reasons cited for increased morbidity and mortality with barbiturate overdoses compared to benzodiazepines.
Barbiturates inhibit both the activity of the excitatory neurotransmitter glutamate at the glutamate receptor and calcium­mediated excitatory neurotransmitter release at the presynaptic terminal. Blockade of the calcium channel may contribute to the cardiac contractility impairment seen with barbiturate overdoses. Barbiturates also have effects on voltage­dependent sodium and potassium channels, but in concentrations typically far above
 the therapeutic range. These effects may contribute to the toxicity or paradoxical actions seen with some barbiturate drugs in overdoses.
CLINICAL FEATURES
Mild to moderate barbiturate intoxication closely resembles alcohol intoxication and toxicity of other sedative­hypnotics. Drowsiness, disinhibition, ataxia, slurred speech, and mental confusion are common features that escalate with increasing dose. The progressive neurologic depression seen with severe barbiturate intoxication predictably manifests as a range from stupor to coma to complete neurologic unresponsiveness, including the
 absence of a corneal reflex, deep tendon reflexes, and even brainstem reflexes (in patients who ultimately completely recover).
The most common vital sign abnormalities seen in overdose are respiratory depression, hypothermia, and hypotension, with respiratory depression usually occurring first. Abnormal temperature control and respiratory depression are centrally mediated phenomena, whereas hypotension is primarily a result of decreased vascular tone. Pulse rate, pupil size, light reactivity, and nystagmus are variable. GI tract motility is slowed, resulting in delayed gastric emptying and ileus. Skin bullae, sometimes referred to as “barb blisters” or “coma blisters,” are uncommon and may indicate nothing
 more than the effects of local skin pressure, although hypoxia has been implicated as well. Coma blisters are not specific to sedative­induced coma;
   they have been reported after surgery, from other causes of coma, and even without coma.
Early deaths in barbiturate overdose result from respiratory arrest and cardiovascular collapse. Common complications include hypoglycemia
(perhaps due to starvation), pulmonary edema, aspiration pneumonia, and acute lung injury. Current mortality rates range between 1% and 3%; death usually results from multiple organ system failure. Lethal doses are estimates (Table 182­1), but severe poisoning can be assumed if more than

 times the hypnotic dose has been ingested in a single exposure in a nontolerant patient. As with other sedative­hypnotics, the toxic properties of barbiturates may be enhanced in the presence of benzodiazepines or alcohol. Conversely, the depressive effects may be protective in a
 mixed­stimulant overdose.
DIAGNOSIS
Laboratory evaluation in barbiturate overdose should include determination of glucose levels, blood chemistries, CBC, blood gas (if indicated), toxicology screen for co­ingestants, chest radiograph, and an ECG. Urine drug screens most commonly use the immunoassay methodology, and a
 false­positive result on the barbiturate screen has been reported with ibuprofen and naproxen. If important, confirm a positive urine screen using a more accurate method, such as gas chromatography–mass spectrometry.
Barbiturate serum levels are useful in establishing the diagnosis of a comatose patient; however, acute treatment decisions should be clinically based.
Serum barbiturate levels reported in lethal overdoses vary widely, and measurements are not reliable in predicting clinical course after an overdose because they do not reflect brain barbiturate concentrations and may underestimate the clinical condition of a patient in the setting of polydrug
 exposure. Barbiturate levels are also invalid in chronic barbiturate abusers who have developed physiologic tolerance and in patients with renal or
 hepatic disease who have decreased clearance.
TREATMENT
In a barbiturate overdose, the initial priorities are airway management and supportive care. Once pulmonary and cardiovascular function has been stabilized, options for increasing drug clearance are considered.
AIRWAY ASSESSMENT AND INITIAL STABILIZATION
Assess the patient’s mental status and airway stability. Intubation with mechanical ventilation in severe sedative­hypnotic overdose is often required.
Barbiturate toxicity results in decreased cardiac output and vascular tone, often resulting in profound hypotension. Volume expansion with IV crystalloids is the mainstay for circulatory support in the absence of cardiac failure. If fluid resuscitation fails to correct hypotension, administer vasopressors such as dopamine or norepinephrine. Hypothermia between 30°C (86°F) and 36°C (96.8°F) is common and should be monitored via continuous core temperature and treated with rewarming measures.
ACTIVATED CHARCOAL

A single dose of activated charcoal should be given to cooperative, clinically stable patients who present within  hour of acute oral overdose.

Current consensus guidelines are to consider multidose activated charcoal if a patient has ingested a life­threatening amount of phenobarbital. A typical adult regimen for multidose activated charcoal is an initial dose of  to 100 grams PO followed by .5 to  grams PO every  hours.
Concurrent administration of cathartic agents remains unproven and is discouraged (see Chapter 176, “General Management of Poisoned Patients”).
Careful attention to and monitoring of the patient’s airway is important to decrease the risk of aspiration or bowel obstruction.
FORCED DIURESIS AND URINARY ALKALIZATION
Forced diuresis is not recommended because of the risks of sodium and fluid overload and lack of proven efficacy.
Urinary alkalization (see Chapter 176) does enhance the clearance of phenobarbital and primidone (which is metabolized to phenobarbital). This treatment is less effective than multidose activated charcoal in reducing serum levels, does not improve clinical outcomes, and is not effective for
 ,26 shorter­acting barbiturates. In barbiturate poisoning, urinary alkalization is not a first­line treatment and has only a minor, if any, role.
EXTRACORPOREAL ELIMINATION
Hemodialysis, hemoperfusion, and hemodiafiltration can enhance elimination of phenobarbital, but are reserved for patients who are deteriorating
26­28 despite aggressive supportive care. These modalities are not useful for poisoning from barbiturates other than phenobarbital.

Exchange transfusion has also been reported to be useful in neonatal phenobarbital toxicity.
DISPOSITION AND FOLLOW­UP
Mild to moderate barbiturate intoxication responds well to general supportive care, including a single dose of activated charcoal, as long as potential benefits outweigh aspiration risk. Improvement in neurologic status and vital signs over  to  hours signals eventual patient discharge or transfer.
When indicated, obtain mental health assessment. For a long­acting agent such as phenobarbital, serial serum levels should be obtained during the initial  hours after an overdose before concluding the patient can be safely discharged or transferred. Evidence of toxicity after  hours will require hospital admission, and patients with severe toxicity should go to the intensive care unit. Consult with a medical toxicologist or local poison center to assist in the care of severe barbiturate­poisoned patients.
BARBITURATE WITHDRAWAL SYNDROME
Abrupt discontinuation of barbiturates in a chronically dependent user will produce withdrawal symptoms similar to alcohol or benzodiazepine withdrawal. Clinical manifestations will range from anxiety and restlessness to hallucinations, delirium, and/or generalized seizures. Severe symptoms in the ED can be treated with benzodiazepines or barbiturates, but due to the associated mortality, gradual in­hospital detoxification is needed.


