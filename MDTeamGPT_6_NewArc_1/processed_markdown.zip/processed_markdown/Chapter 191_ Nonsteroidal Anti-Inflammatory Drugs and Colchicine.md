## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 191: Nonsteroidal Anti­Inflammatory Drugs and Colchicine
Jonathan de Olano; Rana Biary; Patrick C. Ng; Alex Koyfman; Brit Long
CONTENT UPDATE: Colchicine Toxicity June 2021
Colchicine is an anti­flammatory agent with several therapeutic applications. It has antimitotic activity, can inhibit mitosis of rapidly dividing cells, and has a narrow therapeutic window. Colchicine overdose is unusual but can result in severe shock and death. See “Colchicine Toxicity” at the end of this chapter.
INTRODUCTION
Nonsteroidal anti­inflammatory drugs (NSAIDs) are among the most widely used therapeutic agents in the United States. All share inhibition of the cyclooxygenase enzyme as a mechanism of action. NSAIDs are effective antipyretics, analgesics, and anti­inflammatory agents. Because of their large
,2 therapeutic window, acute ingestion with overdoses rarely produces serious complications. The morbidity from NSAIDs in acute overdose is far overshadowed by complications of NSAIDs at therapeutic doses, which include GI bleeding, drug­induced renal failure, and atherosclerotic heart
3–6 disease.
PHARMACOLOGY
NSAIDs are structurally varied compounds with common therapeutic effects (Table 191­1). NSAIDs reversibly inhibit COX, which is responsible for the production of prostaglandins from arachidonic acid. The anti­inflammatory effect of NSAIDs is through the inhibition of prostaglandin production and
 neutrophil migration. NSAIDs are antipyretics via inhibition of prostaglandin E in the hypothalamus. Analgesia is mediated by attenuation of
 prostaglandin­mediated hyperalgesia and local pain fiber stimulus.
TABLE 191­1
Nonsteroidal Agents Available in the United States
Class and Half­Life With Therapeutic Doses of Standard Typical Initial Adult Oral Maximum Recommended Adult Daily
Agent Oral Tablets or Capsules* (h) Dose (milligrams) Oral Dose (milligrams)
Nonselective NSAIDs
Acetic acids
Diclofenac   TID 150
.6–11.2  BID or TID 200
Indomethacin
Ketorolac   QID 120
Downl oaded 2025­7­1 16–:22 (81 5P†) Your IP is 136.142.159.127  QID 400
ChapteMre 1cl9o1fe:n Namonasteteroidal Anti­Inflammatory Drugs and Colchicine, Jonathan de Olano; Rana Biary; Patrick C. Ng; Alex Koyfman; Brit LPoangge  / 
. Terms of Use * Privacy Policy * Notice * Accessibility
Mefenamic  250 QID 1000 acid
<1 (22–26†) 1000 daily 2000
Nabumetone
Sulindac  (16†) 150 BID 400
Tolmetin  400 TID 1800
Propionic acids
Fenoprofen  300 TID 3200
Flurbiprofen 5–8  BID 300
Ibuprofen  400 QID 2400 (pain, dysmenorrhea)
3200 (osteoarthritis)
Ketoprofen 2–4  TID 300
Naproxen 12–17 250 BID 1000 (pain)
1500 (osteoarthritis)
Oxaprozin 16–45 (38–57‡) 1200 daily 1800
Oxicams
Piroxicam   daily 
Partially selective COX­2 inhibitors
Etodolac 6–8 200 TID 1000
Meloxicam 20–24  daily 
Selective COX­2 inhibitors
Celecoxib  200 BID 400
Abbreviations: BID = twice per day; COX­2 = cyclooxygenase ; QID = four times per day; TID = three times per day.
*Not sustained­release or enteric­coated preparations.
†Half­life of active metabolite.
‡
Half­life of protein­bound drug.
CYCLOOXYGENASE

Two isoforms of COX (COX­1 and COX­2) vary in presence and distribution. COX­1 is present with a steady level of activity and is found primarily in
 blood vessels, kidneys, and the stomach. In contrast, COX­2 is found in low levels in human tissue unless induced by proinflammatory mediators.
COX inhibitors can be categorized as nonselective, partially selective, or selective regarding their inhibition of COX enzyme isoforms (Table 191­1). Most
NSAIDs nonselectively inhibit both COX­1 and COX­2. COX­1 inhibition is responsible for most of the unwanted GI side effects of NSAIDs. Drugs such as etodolac and meloxicam were created to inhibit COX­2 preferentially, theoretically reducing the unwanted GI effects. Unfortunately, the COX­2–
,10 selective compounds do not appear to be more effective mediators of inflammation or analgesia and are still associated with GI side effects.
PHARMACOKINETICS
All NSAIDs are rapidly absorbed from the GI tract, and most achieve peak serum levels within about  hours. They are highly protein bound, have low volumes of distribution (approximately .2 L/kg), and cross the blood–brain barrier. NSAIDs undergo metabolism mainly in the liver. Plasma half­lives of NSAIDs range from  hours for ibuprofen to greater than  hours for the long­acting agents piroxicam and phenylbutazone (Table 191­1). Creation of active metabolites may prolong the therapeutic effect beyond that of the parent compound.
Ingestion of large amounts of some drugs, such as ibuprofen and naproxen, results in slower absorption, with  to  hours required to achieve peak plasma levels. As greater amounts of NSAIDs are absorbed in large overdoses, greater fractions of free drug become available for toxicity in a nonlinear manner because protein binding is limited.
Topical NSAIDs
Topical NSAIDs are well absorbed through the skin and reach therapeutic levels in synovial fluid. According to the most recent Cochrane review, topical
 diclofenac and ketoprofen provide good relief in acute muscular injuries but have limited efficacy in chronic conditions such as osteoarthritis.
SIGNIFICANT DRUG–DRUG INTERACTIONS
Aspirin
Daily aspirin therapy reduces the incidence of recurrent myocardial infarction and stroke by impairment of platelet aggregation. Ibuprofen administered three times per day competitively inhibits this aspirin effect on platelets by its interaction with the thromboxane pathway, thus
,13 undermining aspirin’s cardioprotective effect. Ketorolac and diclofenac, unlike other NSAIDs, do not alter aspirin’s inhibition of platelet
 aggregation and thromboxane synthesis.
Antihypertensive Agents

NSAIDs decrease the effectiveness of antihypertensive drugs through inhibition of prostaglandin synthesis. NSAIDS can also aggravate preexisting hypertension or raise blood pressure through their renal effects.
Anticoagulants
,17
When combined with warfarin or non–vitamin K oral anticoagulants, NSAIDs increase risk for upper GI bleeding, although the risk may vary with
 specific agents. A recent meta­analysis demonstrated a small increase in risk of bleeding with the use of warfarin and NSAIDs, while other studies
 demonstrate that the risk is NSAID specific, with meloxicam being the only NSAID to increase INR with warfarin therapy. Concomitant therapy with
,21
COX­2 inhibitors and warfarin still incurs some risk of GI bleeding, but the risk is less with nonselective NSAID–warfarin combinations. Due to the
,23 drug–drug interactions and risk of GI bleeding, avoid chronic NSAID use in patients on warfarin or novel oral anticoagulants.
Decreased Renal Clearance of Drugs
NSAIDs may also decrease renal clearance by inhibition of renal synthesis of prostaglandins (which serve as vasodilators) and by decreasing renal blood and glomerular filtration rate. NSAIDs increase concentrations of drugs such as lithium, methotrexate, and metformin. NSAIDs are a potential
 risk factor in the development of metformin­associated lactic acidosis.
TOXICITY AT THERAPEUTIC DOSES
NSAIDs are generally safe drugs but have a number of well­reported side effects at therapeutic doses (Table 191­2). Indomethacin, piroxicam, and diclofenac are responsible for a greater proportion of side effects, whereas the propionic acid agents (e.g., ibuprofen) are associated
,26 with fewer problems.
TABLE 191­2
NSAID Toxicity at Therapeutic Doses
Organ
Clinical Toxicity
System
CNS Behavioral changes, cognitive difficulties, headache, psychosis, aseptic meningitis, seizures
Cardiovascular Increased risk of myocardial infarction and risk of sudden death following myocardial infarction
Pulmonary Bronchospasm, hypersensitivity pneumonitis, pulmonary edema
GI Dyspepsia,* nausea,* heartburn,* gastritis, gastric and duodenal erosions, mucosal bleeding,* gastric and duodenal perforation
Hepatic Spectrum of hepatic injury ranging from asymptomatic elevation of serum transaminases to fulminant hepatic failure
Renal Sodium and water retention,* hyperkalemia, azotemia,* acute tubular necrosis, interstitial nephritis, renal failure
Hematologic Increased risk of bleeding, bone marrow suppression, aplastic anemia, agranulocytosis, red cell aplasia, hemolytic anemia, thrombocytopenia
Dermatologic Maculopapular rashes, photosensitivity reactions, Stevens­Johnson syndrome, toxic epidermal necrolysis
Bone Delayed wound and fracture healing
Reproductive Slowed uterine contractions, premature closure of ductus arteriosus, fetal intracranial hemorrhage, necrotizing enterocolitis, oligohydramnios
*Common side effects.
CNS
,28
CNS adverse effects at therapeutic doses include headache, cognitive difficulties, behavioral change, and aseptic meningitis. Acute psychosis has
 been reported with indomethacin and sulindac—agents with structural similarity to serotonin—and is more commonly in the elderly.
Patients with NSAID­induced aseptic meningitis may experience symptoms of headache, fever, and neck stiffness occurring within hours of a
,30,31 therapeutic dose. Cerebrospinal fluid analysis of these patients finds elevated WBC counts and protein levels with normal or decreased glucose
 levels. Symptoms resolve after NSAID use is stopped and may recur with repeat NSAID challenges. This phenomenon, most often seen in patients who have underlying autoimmune diseases such as systemic lupus erythematosus, is thought to be a hypersensitivity reaction. Exclude infection before assuming NSAID­induced aseptic meningitis. Agents associated with aseptic meningitis include celecoxib, diclofenac, ibuprofen, ketoprofen, naproxen, rofecoxib, sulfasalazine, sulindac, and tolmetin.
Cardiovascular
Increased cardiovascular events, including myocardial infarction, can result from long­term use of both nonselective NSAIDs and selective COX­2
,33 ,34 agents. Risk depends on drug, drug dose, and duration and is also more profound in patients with established coronary artery disease. The
,35 greatest risk for myocardial infarction occurs within the first month of any NSAID use and at higher doses. Begin therapy with medications not associated with increased cardiovascular effects, such as acetaminophen, and progress to nonselective NSAIDs, or for patients over  years of age,
35–39 ,41 use a topical rather than oral NSAID. If NSAIDs are administered in patients with high cardiovascular risk, give short courses of the lowest dose.
Pulmonary
NSAIDs have been associated with adverse pulmonary reactions, including bronchospasm in asthmatics, hypersensitivity pneumonitis, eosinophilic
42–44 pneumonia, and rarely pulmonary edema. Cessation of NSAID use resolves the symptoms.

NSAIDs and aspirin can trigger bronchospasm in patients with reactive airway disease. The spectrum of this reaction ranges from rhinitis to severe
 bronchospasm with laryngeal edema. Patients with underlying reactive airways disease and nasal polyps are at greater risk for these complications.
Hypersensitivity reaction to NSAIDs is due to increased proinflammatory cysteinyl leukotrienes and decreased prostaglandin E from COX­1

 inhibition.
GI

GI effects from NSAIDs include dyspepsia, heartburn, nausea, and GI bleeding. These effects derive from inhibition of cytoprotective gastric
 prostaglandins resulting in injuries ranging from mild ulceration to life­threatening bleeding. NSAIDs’ inhibition of gastric prostaglandins also
 increases permeability of the GI barrier.
Hepatic

Clinically apparent liver injury caused by NSAIDs is idiosyncratic and rare. Diclofenac and sulindac are the two NSAIDs most commonly linked to hepatotoxicity. Drug withdrawal should lead to complete recovery.
Renal
COX inhibition decreases prostaglandin synthesis and causes renal vasoconstriction. Continued NSAID use may lead to acute tubular necrosis.
,6,48
Interstitial nephritis and glomerular injury may result from NSAID­associated activation of inflammatory cells.
Hematologic
Nonselective NSAIDs inhibit platelet formation of thromboxane A , a potent stimulator of platelet aggregation. The new COX­2 inhibitors have far fewer
 antiplatelet effects than traditional NSAIDs. Most NSAIDs decrease platelet aggregation only when significant concentrations of the drug are present, and therefore, increased bleeding tendencies from NSAIDs are not widely reported.
Bone marrow suppression and aplastic anemia are rare hematologic complications of almost all NSAIDs, with indomethacin, diclofenac, and phenylbutazone responsible for most reported cases. NSAID use has also resulted in agranulocytosis, hemolytic anemia, red cell aplasia, and
49–51 thrombotic thrombocytopenic purpura.
Dermatologic

Rash, angioedema, and urticaria are the most common manifestations of hypersensitivity reactions to NSAIDs. The agents most frequently involved in dermatologic complications include benoxaprofen, phenylbutazone, and piroxicam. Drug reactions to NSAIDs range from benign maculopapular rashes to Stevens­Johnson syndrome and toxic epidermal necrolysis. NSAIDs are among the most commonly implicated drugs in cases of toxic epidermal necrolysis, accounting for up to one third of drug­related cases. NSAIDs of all types (oral and topical) can cause photosensitivity reactions including increased sensitivity to sun exposure (phototoxic) and true photoallergic reactions (see Chapter 249, “Generalized Skin Disorders”).
Ketoprofen and piroxicam are the most frequently involved in photoallergic reactions.
Bone
,54
Bone healing is a complex cascade of events that involves prostaglandins’ influence on the balance between bone formation and resorption. The most recent guidelines by the American Pain Society recommend the use of NSAIDs for postoperative pain in fractures because there is not sufficient
 evidence against its use in humans.
Reproductive
Prostaglandins are found in high concentration in the uterus at term and have a stimulatory effect on normal labor. NSAIDs will impair uterine motility
 through inhibition of prostaglandin synthesis. They may be associated with increased risk of miscarriage when used around conception. One of the most significant effects of fetal exposure to NSAIDs is premature constriction of the ductus arteriosus that may result in fetal pulmonary
 hypertension. The many other reported effects of in utero exposure to NSAIDs have resulted in the U.S. Food and Drug Administration
 recommendation against the use of NSAIDs after  weeks of pregnancy.
TOXICITY WITH ACUTE OVERDOSE
Although the vast majority of patients with acute overdoses suffer little morbidity, with massive NSAID ingestions, some fatalities can occur; these
58–61 cases may present with altered mental status, metabolic acidosis, and shock. Historically, phenylbutazone was most commonly associated with severe toxicity following an overdose, and although it was withdrawn from the U.S. market in the 1970s, it is still available from veterinary sources and in other countries. By a wide margin, ibuprofen is the most common agent currently reported in NSAID overdoses. Patients who develop symptoms following an ibuprofen overdose usually ingest more than 100 milligrams/kg. Initial symptoms predominantly include abdominal pain, nausea, and vomiting, all beginning within  hours of ingestion (Table 191­3). Most patients who manifest severe toxicity, including apnea, coma, and metabolic acidosis, ingest more than 400 milligrams/kg. There is limited published experience concerning acute overdose of COX­2 inhibitors, but they are assumed to have similar profiles as the nonselective NSAIDs.
TABLE 191­3
NSAID Toxicity After an Acute Overdose
Initial symptoms within  h after Abdominal pain, nausea, vomiting ingestion
CNS Headache, nystagmus, diplopia, altered mental status, coma, muscle twitching, and seizures (mefenamic acid)
Cardiovascular Hypotension, shock, bradydysrhythmia, ventricular tachycardia or fibrillation and QT prolongation
Metabolic Hyperkalemia, hypocalcemia, hypomagnesemia
GI and hepatic Continued abdominal pain, nausea, vomiting, hepatic injury, pancreatitis (rare)
Renal Acute kidney injury
CNS
CNS manifestations of acute NSAID overdose are usually minimal, although patients with significant overdose may have headache, diplopia,
  nystagmus, and altered mental status including coma. Mefenamic acid has high potential for seizures in overdose. Muscle twitching and seizures
 that are responsive to benzodiazepines have been reported.
Cardiovascular
Acute NSAID overdose can be associated with hypotension and dysrhythmias ranging from bradycardia to ventricular tachycardia and fibrillation.
NSAIDs are not known to be a primary cause of dysrhythmias, but fluid and electrolyte abnormalities provoked by NSAID toxicity may induce cardiac rhythm abnormalities. Cardiovascular dysfunction from acute NSAID overdose is responsive to conventional critical care management.
Metabolic
Electrolyte and acid­base abnormalities may occur in acute NSAID overdoses. Alterations in serum electrolytes may develop secondary to decreased prostaglandin synthesis or from NSAID­induced renal failure. Sodium and water retention may lead to volume overload in patients with preexisting cirrhosis, heart failure, or renal failure. Hyperkalemia, hypocalcemia, and hypomagnesemia have been reported in NSAID overdoses complicated by acute renal failure.
Increased anion gap metabolic acidosis has been observed with large overdoses of ibuprofen and naproxen, which may be due to these NSAIDs and their metabolites being weak acids. Concurrent lactic acid production in the setting of NSAID­induced seizures or shock may exacerbate the acidosis.
GI and Hepatic
Patients presenting after acute NSAID overdose may have abdominal pain, nausea, and vomiting, but life­threatening GI hemorrhage is not a typical finding after acute overdoses. Overdose may also result in hepatic injury, as measured by cholestasis and elevated transaminase levels. Rare cases of
64–66 pancreatitis have been reported after overdoses of ibuprofen, naproxen, and indomethacin.
Renal
NSAID overdose rarely causes acute kidney injury, but may place a stressed renal system at risk for failure. The clinical presentation may include hematuria and oliguria. Most patients with acute renal failure due to an NSAID overdose have eventual recovery of renal function, but some may need long­term dialysis.
TREATMENT
Most patients who present following an NSAID overdose will be asymptomatic. Follow the general principles for managing the poisoned patient (see
Chapter 176, “General Management of Poisoned Patients”). Determine if the amount of drug ingested was less than 100 milligrams/kg (unlikely to result in toxicity) or more than 400 milligrams/kg (significant risk for toxicity).
Asymptomatic NSAID ingestions usually require minimal laboratory evaluation and supportive care (Figure 191­1). Activated charcoal is recommended for the majority of patients with NSAID overdose who have an intact mental status and are protecting their airway. IV fluids and an H
 blocker or proton pump inhibitor can be given empirically. Replace electrolytes. Screen for potentially dangerous co­ingestants by measuring the serum acetaminophen and salicylate levels and obtaining a 12­lead ECG.
FIGURE 191­1
Approach to treatment of acute NSAID overdose.
Patients who are symptomatic with altered mental status, seizures, shock, respiratory distress, or cardiac dysrhythmias require aggressive resuscitation and stabilization (Figure 191­1). Establish an airway as needed, institute mechanical ventilation when necessary, treat hypotension with fluid boluses and/or vasopressors, and manage seizures initially with IV benzodiazepines. Activated charcoal is recommended in all symptomatic patients with a protected airway. Consider gastric lavage for recent ingestions involving mefenamic acid or phenylbutazone. Whole­bowel irrigation
 can be considered for severe overdose with enteric­coated formulations. Hemodialysis, hemofiltration, and charcoal hemoperfusion are not effective in enhancing elimination because NSAIDs are highly protein bound. Likewise, manipulation of serum and urine pH through IV alkalinization is not beneficial in enhancing renal elimination. Hemodialysis may be needed for severe metabolic derangements or renal failure not responsive to conservative therapies.
Patients with symptomatic NSAID overdoses should have a serum chemistry panel, hepatic profile, CBC, and coagulation profile. Serum NSAID levels do not correlate with observed toxicity or outcomes, so serum levels for specific NSAIDs are not indicated.
DISPOSITION AND FOLLOW­UP
Most patients with asymptomatic NSAID ingestions can be safely discharged after a 4­hour period of observation. Admit patients for observation and supportive care for symptoms such as altered mental status, abnormal vital signs after  hours of observation, or with metabolic or electrolyte abnormalities. Consider obtaining psychiatric consultation for suicidal gestures or intent. All overdoses should be reported to the regional poison control center both for management assistance and for statistical tracking. The majority of NSAID overdoses will not cause significant sequelae, and even patients with major symptoms have a good prognosis if they overcome the initial insult.
COLCHICINE TOXICITY
Patrick C. Ng; Alex Koyfman; Brit Long
Introduction
Colchicine is a plant alkaloid derived from Colchicum autumnale and Gloriosa superba (crocus family) and is used in the ED to treat gout/pseudogout
 attacks and pericarditis, as well as several other conditions (Table 191­4).
TABLE 191­4
Colchicine indications
Acute/pseudo gout Various autoimmune diseases
Recurrent pericarditis Pulmonary fibrosis
Familial Mediterranean fever Amyloidosis
Primary biliary or hepatic cirrhosis Paget’s disease
Pharmacokinetics and Mechanism of Action
Colchicine has a narrow therapeutic window. When ingested, the lipophilic medication is rapidly absorbed from the jejunum with 25–50% bioavailability. Colchicine is primarily hepatically metabolized and is a substrate for CYP3A4 and p­glycoprotein. It undergoes phase  biotransformation, biliary secretion, and fecal excretion. Less than 20% is renally eliminated, unchanged. Thus, those with compromised hepatic/renal function and those on medications that inhibit CYP 3A4 (itraconazole, ketoconazole, and clarithromycin) or p­glycoprotein (azithromycin,
 cyclosporine, and certain antifungals) are at higher risk for colchicine toxicity. Dosage adjustments are needed in the presence of hepatic or renal disease, or with competing medications as listed above. While data are limited, colchicine does not appear to significantly increase the incidence of
 fetal malformations or miscarriage.
Colchicine has complex actions. Its anti­inflammatory properties are especially important for treating crystal­induced inflammation. It has antifibrotic activity and appears to downregulate multiple inflammatory pathways. Chronic administration can be associated with myelosuppression, leukopenia, or thrombocytopenia due to the drug’s antimitotic activity. At toxic doses, colchicine primarily inhibits mitosis of rapidly dividing cells such as leukocytes, enterocytes, stem cells, and skin cells.
Toxicity of Overdose
The toxic dose of colchicine is not well established, but >0.5 mg/kg is concerning for overdose, and some reports note that doses above .8mg/kg are
71–73 associated with a high mortality rate. There is no blood test for colchicine levels.
The presenting symptoms are nonspecific. Obtain a thorough medical history. To recognize a potential exposure, determine how patients may have access to colchicine. Depending on the degree of toxicity and the timing of presentation, the clinical picture can range from mild symptoms to multisystem organ dysfunction. Mild toxicity is marked by gastrointestinal effects such as abdominal pain, nausea, vomiting, and diarrhea, which may
 lead to volume loss. With severe toxicity, three phases may occur (Table 191­5).
TABLE 191­5
Phases of toxicity
Time
Stage after Findings
Ingestion
 First  Gastrointestinal symptoms (nausea, vomiting, diarrhea, abdominal pain), dehydration, and leukocytosis (typically >30,000/mm3) hours
  hours Multiorgan dysfunction and failure: leukopenia, alopecia, myopathy and rhabdomyolysis, electrolyte abnormalities, renal and to  days liver failure, hypovolemia, coagulopathy, acute lung injury leading to acute respiratory distress syndrome, dysrhythmias, cardiovascular collapse, seizures, sensory neuropathies, areflexia, encephalopathy, and sepsis
 Weeks Death or recovery
ED Management
The diagnosis is clinical, so focus on evaluation for end­organ injury (Table 191­6). The current management of toxicity is supportive care and decontamination if possible (Table 191­7).
TABLE 191­6
ED testing
Complete blood cell count Fibrinogen Chest x­ray
Renal and liver function Lactate Continuous pulse oximetry
Electrolytes including magnesium/phosphorus Troponin* Electrocardiogram
Creatine kinase Venous blood gas Ultrasound: RUSH exam
Coagulation panel Urinalysis
Abbreviation: RUSH = rapid ultrasound for shock and hypotension.
*Prognostic marker.
TABLE 191­7
Management modalities
Activated charcoal and/or gastric lavage Decontamination if presenting within  hours; may need to intubate prior
Intravenous fluid resuscitation and electrolyte replacement As clinically indicated
Antibiotics For concurrent infection
Vasopressor(s) If refractory to fluid resuscitation
Hemodialysis Dialysis does not remove colchicine
Granulocyte colony­stimulating factor (G­CSF)75 For those who develop bone marrow aplasia
Extracorporeal life support In patients with refractory shock and severe toxicity


