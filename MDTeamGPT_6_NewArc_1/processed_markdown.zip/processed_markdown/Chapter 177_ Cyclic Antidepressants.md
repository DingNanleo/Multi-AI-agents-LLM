## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 177: Cyclic Antidepressants
Frank LoVecchio
INTRODUCTION
Cyclic antidepressants were the first generation of drugs developed to treat depression. Their use for treating depression has declined greatly as safer agents have been developed. Cyclic antidepressants are now occasionally used to treat obsessive­compulsive disorder, attention­deficit/hyperactivity disorder, panic and phobia disorders, and anxiety disorders.

Cyclic antidepressants have the highest ratio of deaths to exposures for antidepressants reported to U.S. Poison Control Centers. Roughly half of all cyclic antidepressant exposures involve other drugs as well, and most co­ingestants increase the incidence and severity of cyclic antidepressant overdose toxicity.
Eight cyclic antidepressants are currently available in the United States (Table 177­1), with more agents available in other countries. Two related antidepressants, amoxapine and maprotiline, have structural differences from traditional cyclic antidepressants but have similar toxicity in overdose.
Cyclobenzaprine is a muscle relaxant that is almost structurally identical to amitriptyline but lacks antidepressant activity, and serious toxicity from
 overdose is rare.
TABLE 177­1
Cyclic Antidepressants and Related Drugs
Typical Adult Outpatient Recommended Maximum Adult Elimination Half­Life
Generic Name Active Metabolites
Daily Dose (milligrams) Outpatient Daily Dose (milligrams) (h)
Amitriptyline 75–150 300 10–26 (amitriptyline) Nortriptyline
18–44 (nortriptyline)
Amoxapine* 50–300 400  (amoxapine) 7­Hydroxyamoxapine
 (8­hydroxyamoxapine) (minor)
8­Hydroxyamoxapine
(major)
Clomipramine 25–50 250  (clomipramine) Desmethylclomipramine

(desmethylclomipramine)
Cyclobenzaprine* 15–30   None
Desipramine 75–200 300 12–27 None
Doxepin 75–300 300  (doxepin) Desmethyldoxepin
 (desmethyldoxepin)
Imipramine 75–200 300 11–25 Desipramine

Maprotiline* 75–150 225  (maprotiline) Desmethylmaprotiline
Chapter 177: Cyclic Antidepressants, Frank LoVecchio 
60–90
. Terms of Use * Privacy Policy * Notice * Accessibility
(desmethylmaprotiline)
Nortriptyline 75–150 150 18–44 None
Protriptyline 15–60  67–89 None
Trimipramine 75–200 300 9–11 Desmethyltrimipramine
*See text for clarification.
Cyclic antidepressants possess a narrow therapeutic index, and toxicity can occur at therapeutic dosages (Table 177­2).
TABLE 177­2
Mechanisms for Cyclic Antidepressant Drug Toxicity at Therapeutic Dosages
Administration of high therapeutic dosages to naive individuals
Drug interactions with medications sharing similar pharmacologic actions
Elevated levels of cyclic antidepressants due to genetically slow hepatic metabolism
Drug interactions with other medications that inhibit hepatic metabolism (cytochrome P450 system)
Additional toxicity from other active ingredients (e.g., antipsychotics) contained in some combination cyclic antidepressant formulations
Preexisting cardiovascular or CNS disease that predisposes patients to toxicity
Development of serotonin syndrome, usually in combination with serotoninergic medications
PHARMACOLOGY
The cyclic antidepressants are named after their chemical structure, which consists of a three­ring central structure plus a side chain—thus the common term tricyclic antidepressants. Maprotiline is a tetracyclic (also termed a heterocyclic), with a four­ring central structure plus a side chain.
Cyclic antidepressants are subdivided into two categories: tertiary and secondary amines. Tertiary amines have two methyl groups at the end of the side chain. The five tertiary amines—amitriptyline, clomipramine, doxepin, imipramine, and trimipramine—are generally more potent in blocking reuptake of serotonin compared to blocking reuptake of norepinephrine. Tertiary tricyclics also cause more anticholinergic side effects (e.g., constipation or blurred vision) and are also highly sedating because of their central effects on histamine receptors.
Secondary amines—desipramine, nortriptyline, and protriptyline—have one methyl group at the end of the side chain and are more potent in blocking reuptake of norepinephrine. The tetracyclic maprotiline has a side chain identical to that of the secondary amines; thus, it is more potent in blocking reuptake of norepinephrine.
Amoxapine has a three­ring central structure and a side chain that differs from the other tricyclics. It is a potent norepinephrine reuptake inhibitor and also blocks postsynaptic dopamine receptors. Thus, it is the only antidepressant that has antipsychotic effects and can produce seizures with minimal warning and normal QRS complex.
Cyclic antidepressants are nonselective agents with multiple pharmacologic effects (Table 177­3) with considerable variation in potency at
3­5 therapeutic dosages. However, these differences become less important at the higher plasma levels typically seen in overdose. Inhibition of amine reuptake (norepinephrine, serotonin) and antagonism of postsynaptic serotonin receptors are believed to produce the therapeutic effects of these agents. The remaining pharmacologic actions are seemingly without therapeutic benefit in treating major depression, but significantly contribute to cyclic antidepressant–related adverse effects and overdose toxicity.
TABLE 177­3
Pharmacologic Profile of Cyclic Antidepressants
Pharmacologic Activity Clinical Presentation
Antagonism of postsynaptic histamine Sedation, depressed consciousness receptors
Antagonism of postsynaptic muscarinic Central antimuscarinic: agitation to delirium, confusion, amnesia, hallucinations, slurred speech, ataxia, receptors (both central and peripheral) sedation, and coma
Peripheral antimuscarinic: dilated pupils, blurred vision, tachycardia, hyperthermia, hypertension, decreased oral and bronchial secretions, dry skin, ileus, urinary retention, increased muscle tone, and tremor
Antagonism of postsynaptic α­adrenergic α ­Adrenergic receptor: sedation, miosis, orthostatic hypotension, reflex tachycardia
 receptors (α ­adrenergic > α ­adrenergic
  α ­Adrenergic receptor: mild hypertension
 receptors)
Inhibition of norepinephrine reuptake Agitation, mydriasis, diaphoresis, tachycardia, early hypertension
Inhibition of serotonin reuptake Sedation, mydriasis, myoclonus, hyperreflexia (see Chapter 178, “Atypical and Serotonergic
Antidepressants”)
Inhibition of voltage­gated sodium channels Impaired conduction, wide QRS complex, other conduction abnormalities; impaired cardiac contractility; wide­complex tachycardia, Brugada pattern, ventricular ectopy
Hypotension
Inhibition of voltage­gated rectifier potassium Prolongation of QT interval, ventricular ectopy, torsades de pointes channels

Cyclic antidepressant–induced cardiotoxicity is the most important factor contributing to patient mortality. Cardiac conduction abnormalities occur during cyclic antidepressant poisoning because inhibition of the fast sodium channels in the His­Purkinje system and myocardium decreases conduction velocity, increases the duration of repolarization, and prolongs absolute refractory periods. Fast sodium channel blockade produces changes in the QRS complex. Severe sodium channel blockade culminates in depressed myocardial contractility, hypotension, various types of heart blocks, cardiac ectopy, bradycardia, widening of the QRS complex, and/or the Brugada pattern. Cyclic antidepressants also block myocardial
 potassium channels and inhibit the efflux of potassium during repolarization. This effect is seen on the ECG as QT interval prolongation, which is
,8 more pronounced at slower heart rates.
PHARMACOKINETICS

All cyclic antidepressants share similar pharmacokinetic properties. They are highly lipophilic, readily cross the blood–brain barrier, and achieve peak plasma levels between  and  hours after ingestion at therapeutic doses. In overdose, GI absorption can be prolonged because of the antimuscarinic effect on gut motility. Bioavailability is only 30% to 70% because of extensive first­pass hepatic metabolism. Cyclic antidepressants are highly protein bound to α ­acid glycoproteins, with a large apparent volume of distribution, ranging from  to  L/kg. Tissue cyclic antidepressant levels are
 commonly  to 100 times greater than plasma levels, and only 1% to 2% of the total body burden of cyclic antidepressants is found in the blood. These pharmacokinetic properties explain why it is unproductive to attempt removal of cyclic antidepressants by hemodialysis, hemoperfusion, peritoneal
 dialysis, or forced diuresis.
Cyclic antidepressants are eliminated almost entirely by hepatic oxidation, which consists of N­demethylation of the amine side­chain groups and hydroxylation of ring structures. The removal of a methyl group from the tertiary amine side chain usually produces an active metabolite designated by the desmethyl prefix (Table 177­1). Clinical toxicity from cyclic antidepressants usually lasts longer than explained by the activity of the parent drug because of the production of active metabolites.
TOXICITY

Ingestions of <1 milligram/kg are generally nontoxic. Life­threatening symptoms usually occur with ingestions of >10 milligrams/kg in adults, and fatalities are commonly associated with ingestions of >1 gram. Children are particularly susceptible to antimuscarinic effects and show clinical toxicity
 at lower dosages. The majority of adult intentional ingestions and pediatric accidental exposures of >2.5 milligrams/kg are expected to result in some
 clinical toxicity based on the low therapeutic index of cyclic antidepressants. In addition, patients at higher risk for cyclic antidepressant toxicity include patients who have co­ingested cardiotoxic or sedative­hypnotic medications, geriatric patients, and patients with underlying heart or neurologic disease.
Desipramine is the most potent sodium channel blocker among the cyclic antidepressants and is able to precipitate severe cardiotoxicity (e.g., wide
QRS complex, hypotension) without producing significant antimuscarinic symptoms. It is associated with a higher case­fatality rate than the other
 cyclic antidepressants. Amoxapine and maprotiline have historically been associated with greater toxicity than other cyclic antidepressants,
 especially in regard to causing seizures.
Quantitative measurement of plasma levels of cyclic antidepressants (parent and metabolite) is helpful in monitoring long­term drug therapy, with therapeutic levels of  to 300 nanograms/mL (300 to 1000 nmol/L) for most agents. Patients with a combined plasma level of parent cyclic antidepressant and metabolite of >1000 nanograms/mL (>3500 nmol/L) are at greater risk for developing seizures and cardiotoxicity, but the severity
 of clinical toxicity does not always correlate with plasma cyclic antidepressant level.
CLINICAL FEATURES
The clinical presentation of cyclic antidepressant toxicity varies from mild antimuscarinic symptoms to severe cardiotoxicity secondary to sodium channel blockade. Antimuscarinic symptoms commonly serve as markers for cyclic antidepressant toxicity (e.g., dry mouth and axillae, sinus tachycardia), but they alone are rarely responsible for fatalities. Moreover, antimuscarinic symptoms are not uniformly present in cyclic antidepressant
,12­14 toxicity. Altered mental status is the most common symptom reported after cyclic antidepressant exposure. A Glasgow Coma Scale score of <8 in
,6 the ED is a strong predictor of serious complications such as seizures and cardiac dysrhythmia. Sinus tachycardia is the most frequent dysrhythmia
,12­14 noted in cyclic antidepressant toxicity, occurring in up to 70% of symptomatic patients.
Mild to moderate cyclic antidepressant toxicity presents as drowsiness, confusion, slurred speech, ataxia, dry mucous membranes and axillae, sinus tachycardia, urinary retention, myoclonus, and hyperreflexia. Antimuscarinic syndrome is classically associated with decreased bowel sounds and ileus, but bowel function is fairly resistant to inhibition, so the presence of active bowel sounds does not exclude antimuscarinic syndrome. Mild hypertension is occasionally present and rarely requires treatment. Overflow urinary incontinence may be mistaken for normal micturition in diaperdependent children or older adults.
Most cyclic antidepressant overdose fatalities occur within the initial hours after ingestion, often before the patient reaches the hospital. If serious toxicity is going to occur, it almost always is seen within  hours of ingestion and consists of the following features: coma, cardiac
 conduction delays, supraventricular tachycardia, hypotension, respiratory depression, ventricular tachycardia, and seizures.
Secondary complications from serious toxicity include aspiration pneumonia, pulmonary edema, anoxic encephalopathy, hyperthermia, and
 rhabdomyolysis. Seizures are more commonly reported in maprotiline and trimipramine overdoses. Seizures are usually generalized, are of brief
 duration, and occur with other signs of serious toxicity. The exception to this rule is amoxapine overdoses; this agent can cause status epilepticus without warning or QRS complex widening. Cyclobenzaprine overdoses are usually characterized by prolonged CNS sedation and
 antimuscarinic toxicity with minimal cardiotoxicity compared to amitriptyline.
DIAGNOSIS
Cyclic antidepressant toxicity is diagnosed using a combination of four criteria: history of exposure, clinical symptomatology, characteristic ECG findings, and positive cyclic antidepressant urine drug screen results. Other toxic exposures may produce similar symptoms, signs, and ECG changes; the essential point is that the initial treatment for toxicity due to any of these medications is identical and should not be delayed until definitive drug test results become available. At least half of all cyclic antidepressant exposures involve co­ingestion of other substances, which can significantly increase or alter toxic manifestations.
False­positive results on qualitative cyclic antidepressant urine drug screens occur with carbamazepine, cetirizine, cyclobenzaprine,
 cyproheptadine, diphenhydramine, hydroxyzine, quetiapine, and phenothiazines (e.g., thioridazine). The false­positive cyclic antidepressant screen result is generally dose dependent and is more common following a supratherapeutic dose of these medications. Most of these medications are structurally similar to cyclic antidepressants, producing the same ECG abnormalities and clinical toxicity in overdose as cyclic antidepressants.
Conversely, false­negative results on cyclic antidepressant drug tests are extremely unusual with clinical toxicity.
ECG abnormalities are common with cyclic antidepressant toxicity and are useful in identifying patients at increased risk for seizures and ventricular
 dysrhythmias. The classic ECG with cyclic antidepressant toxicity shows sinus tachycardia, right axis deviation of the terminal  milliseconds, and prolongation of the PR, QRS, and QT intervals (Figure 177­1). Right axis deviation is demonstrated as a positive terminal R wave in lead aVR and a negative S wave in lead I (Figure 177­1). This classic ECG pattern is seen frequently in moderate to severe cyclic antidepressant toxicity, but its absence does not eliminate the possibility of toxicity, and life­threatening complications can occur in the absence of significant ECG abnormalities, especially following amoxapine ingestion. Less common ECG abnormalities include right bundle branch block and high­degree atrioventricular blocks. The Brugada pattern is seen in roughly 10% to 15% of patients with cyclic antidepressant poisoning who
,19 require intensive care unit admission but is rarely seen in other overdoses. Torsades de pointes is rarely seen in cyclic antidepressant overdoses in the presence of sinus tachycardia, which is partially protective against severe QT interval prolongation and afterpotential generation.
FIGURE 177­1. Twelve­lead ECG showing classic cyclic antidepressant ECG abnormalities: sinus tachycardia; prolonged PR, QRS, and QT intervals; and right axis deviation of the terminal  milliseconds of the QRS complex.
The risk of seizures increases if the QRS complex is >100 milliseconds, and ventricular dysrhythmias are more common if the QRS duration is >160
,17 milliseconds. Widening of the QRS complex from baseline and positive deflection of the terminal QRS complex in lead aVR are usually seen together but can occur independently of each other. The development of right axis deviation of the terminal  milliseconds and/or QRS complex widening appear to be less predictive of cyclic antidepressant–induced cardiotoxicity in young children because pediatric ECGs tend to have a wider range of acceptable variant features, and this complicates the identification of cyclic antidepressant toxicity on the ECG.

ECG abnormalities develop within  hours of ingestion and typically resolve over  to  hours. Although these ECG abnormalities in isolation are not 100% specific for cyclic antidepressant toxicity, they should be assumed to be attributable to cyclic antidepressant exposure and managed accordingly in appropriate clinical circumstances.
TREATMENT
Evaluate patients for alterations of consciousness, hemodynamic instability, and respiratory impairment. Establish an IV line, initiate continuous cardiac rhythm monitoring, and obtain serial ECGs. Suggested laboratory studies include serum electrolytes, creatinine, and glucose. To identify coingestants, obtain serum acetaminophen and salicylate levels. Blood gas measurement is recommended for symptomatic patients. In patients with antimuscarinic symptoms, urinary catheterization may be required to prevent urinary retention, and a nasogastric tube may be needed if ileus is present. Patients who are initially asymptomatic may deteriorate rapidly and therefore should be monitored closely for  hours.
Treatment recommendations (Table 177­4) are based primarily on cohort or case­control studies resulting in only moderate strength of evidence for
 those measures discussed in the following sections.
TABLE 177­4
Treatment of Cyclic Antidepressant Overdose
Treatment Dose Indication Comments
GI Activated charcoal  gram/kg PO Within  h of ingestion as long as Do not give multidose charcoal; do not perform decontamination airway is stable and patient is awake whole­bowel irrigation
Initial treatment Sodium bicarbonate, 1–2 mEq/kg For dysrhythmias, conduction Keep blood pH .50–7.55 of hypotension IV bolus; repeat bolus or add 150 abnormalities (QRS >100 ms), or or dysrhythmias mEq to  L 5% dextrose in water hypotension refractory to IV fluid at 2–3 mL/kg per hour
Hypokalemia Replace potassium as needed Serum potassium <3.5 mEq/L Bicarbonate will decrease potassium level
Seizures or Benzodiazepines for seizures or Phenobarbital 10–15 milligrams/kg Do not give physostigmine, flumazenil, or phenytoin agitation agitation for seizures refractory to benzodiazepines; watch for hypotension; secure airway with intubation
Hypotension Treat hypotension with normal Use norepinephrine or epinephrine if Case reports suggest effectiveness of glucagon,  saline, up to  mL/kg refractory to IV normal saline milligram IV bolus
Torsades de Magnesium sulfate  grams IV; 3% Consider lipid emulsion for refractory Do not give class I antiarrhythmics (i.e., pointes and saline 1–3 mL/kg IV over  min; dysrhythmias, but no convincing procainamide, lidocaine, phenytoin, flecainide), β­ refractory overdrive pacing evidence of effectiveness blockers, calcium channel blockers, or class III dysrhythmias antiarrhythmics (i.e., amiodarone, sotalol, ibutilide)
GI DECONTAMINATION
,21­23
Do not use ipecac syrup or gastric lavage. Give a single  gram/kg dose of activated charcoal PO if patients are awake, have a patent
,24 airway, and arrive within  hour of ingestion. Activated charcoal effectively binds cyclic antidepressants and decreases absorption. Neither
,25 multidose activated charcoal nor whole­bowel irrigation is warranted. Asymptomatic patients with reliable histories of minimal cyclic antidepressant ingestion can be treated with activated charcoal alone and observed for toxicity.
SODIUM BICARBONATE
,26
Sodium bicarbonate is used to treat cardiac conduction abnormalities, ventricular dysrhythmias, or hypotension refractory to IV fluid. Administer sodium bicarbonate as an initial IV bolus of  to  mEq/kg, and repeat until patient improvement is noted or until blood pH is between .50 and .55 (Figure 177­2). Additional alkalization beyond this point can be deleterious to oxygen extraction and serum electrolytes.
FIGURE 177­2. ECG before and after bicarbonate treatment. A. Cardiac rhythm strip of a patient with a wide QRS complex recorded  hours after ingestion of amitriptyline. B. Narrowing of the QRS complex in the same patient after administration of an IV bolus of sodium bicarbonate.
As an alternative of repeat boluses, continuous infusions of sodium bicarbonate can be administered as 150 mEq added to  L of 5% dextrose in water
(or 100 mEq added to 5% dextrose in .45% saline, creating a slightly hypertonic solution with the sodium bicarbonate added) and infused IV at a rate of  to  mL/kg per hour. Adjustments in the IV rate are made based on blood pH measurements and clinical response to therapy. Monitor serum
 electrolytes during the sodium bicarbonate infusion. Hypernatremia is not of particular concern using this dose of sodium bicarbonate. Serum
 potassium will decrease during sodium bicarbonate therapy, and IV potassium supplementation may be required.
ALTERED LEVEL OF CONSCIOUSNESS
Antagonism of postsynaptic muscarinic, histaminic, and α­adrenergic receptors contributes to the development of depressed mentation in cyclic antidepressant overdose. Coma from cyclic antidepressant toxicity typically is rapid in onset and is a predictive factor for cardiotoxicity and/or
 seizures. Pulmonary aspiration is common among comatose cyclic antidepressant overdose patients. Agitation is observed commonly prior to the onset of coma, as well as during awakening. Agitation is best controlled with reassurance, decreased environmental stimulation, and benzodiazepines.
Do not give flumazenil or physostigmine for mixed cyclic antidepressant–benzodiazepine or cyclic antidepressant–anticholinergic overdoses, respectively.
SEIZURES

Most seizures occur within the first  hours following ingestion and are typically generalized and of brief duration. Multiple seizures are reported in approximately 10% to 30% of cases of cyclic antidepressant overdose. Focal seizures and status epilepticus are atypical and should prompt further neurologic evaluation. Seizures are especially common with maprotiline and amoxapine ingestions and require aggressive management, because
 status epilepticus is frequently associated with these two particular antidepressants. Benzodiazepines (e.g., diazepam, lorazepam) are the anticonvulsants of choice to stop seizure activity. Barbiturates (e.g., phenobarbital) are indicated to treat seizures resistant to benzodiazepines. The initial IV dose of phenobarbital is  to  milligrams/kg, but this can be increased in patients with continued seizure activity and adequate blood pressure. Other therapy for refractory seizures includes continuous­infusion midazolam or propofol. Hypotension is a major side effect of IV phenobarbital administration.
Endotracheal intubation and respiratory support may be needed. Phenytoin, sodium bicarbonate, and physostigmine do not stop cyclic antidepressant–induced seizures. Neuromuscular blockers will stop the physical manifestations of seizures and their secondary effects, which include metabolic acidosis, hyperthermia, rhabdomyolysis, and renal failure, but they do not stop brain seizure activity. Therefore, following the induction of muscle paralysis, continue anticonvulsant therapy and consider electroencephalographic monitoring.
HYPOTENSION

Hypotension should be treated initially with isotonic crystalloid fluids in IV boluses in increments of  mL/kg to a maximum of  mL/kg. With impaired cardiac contractility, pulmonary edema can develop if excessive fluids are administered. Hypotension that does not improve with appropriate fluid challenges should be treated with sodium bicarbonate (regardless of QRS complex duration). Vasopressors should be used when hypotension is
 unresponsive to fluids and sodium bicarbonate therapy, although response may be inconsistent. Norepinephrine and epinephrine are expected to be the most effective vasopressors because they directly compete with the cyclic antidepressants at the α­adrenergic receptors. Start the IV infusion at  microgram/min and titrate according to blood pressure. Vasopressin can be tried if there is no response to
 norepinephrine or epinephrine. Dopamine is less effective than norepinephrine in reversing cyclic antidepressant–induced hypotension because it has primarily indirect α­adrenergic agonist activity and, at lower dosages, promotes vasodilation through its β­adrenergic and dopaminergic actions.
Placement of a pulmonary artery catheter for monitoring in patients whose hypotension is refractory to fluid, sodium bicarbonate, and vasopressor therapy may precipitate life­threatening conduction abnormalities and ventricular dysrhythmias as the catheter passes through the right ventricle.
Mechanical support of the circulation with cardiopulmonary bypass, overdrive pacing, or aortic balloon pump assistance may be warranted in patients with refractory hypotension, although no studies document the effectiveness of these measures. There are case reports suggesting that glucagon
 administered as 1­milligram IV boluses might be effective in patients with refractory cyclic antidepressant–induced hypotension.
CARDIAC CONDUCTION ABNORMALITIES AND DYSRHYTHMIAS
Cyclic antidepressants frequently alter cardiac rate, conduction, and contractility. These negative cardiac effects are increased with acidosis, which occurs in patients with respiratory depression or seizures. Asymptomatic patients with sinus tachycardia, isolated PR interval prolongation, or firstdegree atrioventricular block do not require specific pharmacologic therapy. Conduction blocks greater than first­degree atrioventricular block are worrisome because they can progress rapidly to complete heart block secondary to impaired infranodal conduction.
The controversial issue is whether asymptomatic or mildly toxic patients with isolated QRS complex prolongation should be treated with sodium
 bicarbonate therapy. There are no controlled human trials demonstrating benefits in otherwise asymptomatic patients with QRS complex prolongation. Nonetheless, many physicians use sodium bicarbonate therapy in asymptomatic or minimally toxic patients with cyclic antidepressant overdose if the QRS duration is >100 milliseconds. Hyperventilation represents a reasonable alternative to sodium bicarbonate therapy in the setting
 of renal failure, pulmonary edema, or cerebral edema, although hyperventilation is less effective in reversing toxicity.
Ventricular dysrhythmias should be treated with sodium bicarbonate. Consider 3% hypertonic saline,  to  mL/kg IV over  minutes, to decrease
 ventricular ectopy or dysrhythmia in a patient with cardiotoxicity refractory to sodium bicarbonate therapy.
Torsades de pointes should be treated initially with  grams of IV magnesium sulfate. Identify and treat electrolyte disorders that are associated with torsades de pointes. Overdrive pacing may be considered for refractory tachydysrhythmias. Older case reports indicate that IV isoproterenol may be of some benefit when overdrive pacing is not available. The following medications are contraindicated in the treatment of cyclic antidepressant–induced dysrhythmias: all class I antiarrhythmic agents, β­blockers, calcium channel blockers, and all class III antiarrhythmic agents. Lidocaine, a sodium channel blocker, has unclear benefits in cyclic antidepressant–induced dysrhythmias, and there are no convincing data to support its effectiveness.
LIPID EMULSION
Cyclic antidepressants are highly lipid soluble, and it has been postulated that IV lipid emulsion creates a “lipid sink” that sequesters the drug and
 33­39  prevents toxicity. Case descriptions of lipid emulsion therapy for cyclic antidepressant overdoses report benefit, no benefit, and
,41 ,42­44 complications. Currently, there is no consensus or convincing evidence for the use of lipid emulsion in cyclic antidepressant toxicity. In patients with cardiotoxicity refractory to other measures, it seems reasonable to infuse a 20% lipid emulsion in an amount based on that recommended for local anesthetic systemic toxicity: 100 mL IV bolus (1.5 mL/kg) over  to  minutes, followed by an infusion of  mL (0.25 mL/kg) per
 minute to a total dose of  mL/kg.
DISPOSITION AND FOLLOW­UP

Patients who remain asymptomatic after  hours of observation do not require hospital admission for toxicologic reasons. All symptomatic patients require hospital admission to a monitored bed. Patients demonstrating signs of moderate to severe toxicity should be admitted to an intensive care unit. Hospitalized patients can be cleared medically after they are asymptomatic, with a normal or baseline ECG, normal mental status, and resolution of all antimuscarinic symptoms. Patients with an intentional overdose require mental health evaluation.


