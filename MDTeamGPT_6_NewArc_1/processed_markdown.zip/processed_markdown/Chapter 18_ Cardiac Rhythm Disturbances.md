University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 18: Cardiac Rhythm Disturbances
William J. Brady; George F. Glass III
GENERAL CONSIDERATIONS
INITIAL APPROACH TO THE STABLE PATIENT
The focused evaluation of the patient includes determining the presenting complaint(s), obtaining the medical history, identifying medication use, performing a physical examination, initiating continuous cardiac rhythm monitoring, reviewing the 12­lead ECG, and analyzing the cardiac rhythm on the rhythm monitor, a printed strip, or the ECG.
Presenting symptoms may include palpitations, lightheadedness, fatigue, or weakness. Ischemic symptoms, such as chest pain, nausea, dyspnea, or lightheadedness, may be due to dysrhythmia­induced ischemia.
The medication history includes prescribed medications, herbals, recreational drugs, and caffeine­containing beverages. Especially note recently started new medications or increased medication doses. Symptoms of hyperthyroidism should be sought. Patients with a family history of sudden death or syncope and those with organic heart disease have a higher risk of cardiac dysrhythmias and complications. Panic or anxiety is a diagnosis of exclusion in tachycardic ED patients.
INITIAL APPROACH TO THE UNSTABLE PATIENT
An unstable patient requires rapid assessment and treatment to prevent cardiovascular collapse. Instability as related to cardiac rhythm disturbances means that the dysrhythmia is (1) impairing perfusion and threatening vital organ function or (2) has the potential to deteriorate into cardiac arrest

(Table 18­1). Establish an IV line, initiate cardiac rhythm monitoring, obtain an ECG, and be prepared for drug or electrical therapy.
TABLE 18­1
Instability Indicators in the Patient With Cardiac Dysrhythmias
Hypotension: e.g., systolic blood pressure <90 mm Hg (<12 kPa)
Systemic hypoperfusion
Altered mentation
Chest pain (due to coronary ischemia)
Dyspnea (due to pulmonary edema)
Extremely rapid ventricular rate: e.g., rate over 220–240 beats/min in adult
Dysrhythmia­induced chest pain results from coronary hypoperfusion, and dyspnea results from pulmonary edema, usually with objective evidence:
ST­segment abnormalities, rales on examination, or low oxygen saturation. As the ventricular rate exceeds 220 beats/min, severe systemic hypoperfusion often results, increasing the opportunity for malignant ventricular dysrhythmias.
GENERAL APPROACH TO BRADYDYSRHYTHMIAS
Bradydysrhythmia describes rhythms with a ventricular rate slower than  beats/min in the adults and slower than age­appropriate heart rates in children. Bradydysrhythmias can be broadly categorized as bradycardias (atria and ventricles beat at the same slow rate) and atrioventricular (AV)
 blocks (ventricles beat slower than the atria). The bradycardias include sinus bradycardia, junctional rhythm, idioventricular rhythm, atrial
 fibrillation/flutter with a slow ventricular response, and hyperkalemia­related sinoventricular rhythm. Bradydysrhythmias due to AV blocks include
Chapter 18: Cardiac Rhythm Disturbances, William J. Brady; George F. Glass III s©e2c0o2n5d ­MdecgGrreaew (u Hsuilla. lAlyl lt Rypigeh ItIs) aRneds tehrivredd­d. e gTreerem AsV obfl oUcske. * Privacy Policy * Notice * Accessibility
The most common bradycardia is sinus bradycardia, followed by junctional rhythm and, less commonly, idioventricular rhythm. These rhythms are found in both stable and unstable patients. Atrial fibrillation or flutter with slow ventricular response are uncommon; these rhythms are usually seen in patients experiencing significant conduction system disease, such as sick sinus syndrome, or suffering from excessive AV node blocking medications. If the patient is unstable, the vast majority of AV blocks are third­degree heart block followed much less frequently by second­degree AV block. If the patient is stable, second­degree type I AV block is most frequently seen, third­degree AV block is less common, and second­degree type II
2–4
AV block is quite rare.
Bradydysrhythmias result from conditions that affect the automaticity and refractoriness of cardiac cells as well as the conduction of impulses within
,4 the cardiac electrical system. About 80% of bradydysrhythmias are caused by factors external to the cardiac electrical system including acute
,3 coronary syndrome, drug effects or overdose, and hypoxia with cardiac hypoperfusion.
Emergent treatment of bradydysrhythmia is not required unless (1) the heart rate is slower than  to  beats/min accompanied by hypotension or hypoperfusion and/or (2) the bradydysrhythmia is due to structural disease of the infranodal conduction system. This first group requires resuscitative treatment while evaluating the cause. The second group of patients does not require immediate treatment but should be closely monitored, with cardiac pacing readily available while arranging definitive care. Of course, patients with “low normal” heart rates (i.e., pulse of approximately  beats/min in an adult) who are simultaneously in shock are experiencing a relative bradycardia—the relative nature of the bradycardia is noted in that the appropriate or anticipated heart rate in this situation is rapid, with a markedly accelerated sinus rhythm or sinus tachycardia; selected patients in this setting may require rhythm­focused therapy as well.
Medications used to increase heart rate in symptomatic bradycardias include atropine, β­adrenergic agonists, and glucagon (Table 18­2; see Chapter
,4
, “Pharmacology of Antiarrhythmics and Antihypertensives”). Atropine enhances the automaticity of the sinoatrial (SA) node and potentiates conduction through the AV node by direct vagolytic activity. Atropine is usually effective for sinus bradycardia and junctional rhythms but is not useful
,3
(nor particularly harmful) in idioventricular rhythms and second­degree type II and third­degree AV block. β­Adrenergic agents stimulate both chronotropic and inotropic cardiac activity, as well as enhancing electrical conduction within the AV node and infranodal system, thus their potential to produce ischemia and ectopy. Glucagon stimulates inotropic and chronotropic cardiac activity independent of the β­adrenergic receptors. Glucagon is primarily used for bradycardias due to cardiotoxicity from β­blocker or calcium channel–blocker overdose. Effectiveness of drug treatment for bradycardia varies, and in general, these agents are best used as a temporary bridge to cardiac pacing unless a sustained, near­complete to complete response occurs in response to these medications and the cause of the bradycardia is temporary.
TABLE 18­2
Drug Treatment for Cardiac Dysrhythmias in Adults
Drugs for Bradydysrhythmias
Atropine .5­ to .0­milligram IV push; may repeat every 3–5 min until desired heart Most effective for bradydysrhythmias due to sinus and rate is achieved or to total dose of  milligrams higher AV nodal disease
Dopamine IV infusion at rate 2–20 micrograms/kg/min; titrate to desired heart rate May precipitate myocardial ischemia and ectopy
Epinephrine IV infusion at rate 2–10 micrograms/min; titrate to desired heart rate May precipitate myocardial ischemia and ectopy
Glucagon 3–10 milligrams IV infused over 1–2 min, followed by an IV continuous Used for cardiotoxicity associated with β­blocker and infusion of 1–5 milligrams/h calcium channel–blocker overdose
Limited human data are available supporting its use
Nausea and vomiting are often limiting side effects
Tachyphylaxis may develop during infusion
Drugs to Block AV Nodal Conduction
Adenosine 6­milligram rapid IV push; if after 1–2 min the dysrhythmia persists, repeat Effective in terminating narrow QRS complex reentrant rapid IV push with  milligrams; may repeat once more if dysrhythmia tachydysrhythmias involving the AV node persists
Verapamil 5–10 milligrams IV bolus over 2–3 min; if after  min the dysrhythmia Effective in terminating narrow QRS complex reentrant persists, may repeat with dose of  milligrams tachydysrhythmias involving the AV node and reducing ventricular rate in atrial fibrillation or flutter
Diltiazem 15–20 milligrams IV bolus over  min, followed by IV infusion at 5–10 milligrams/h; a repeat bolus of 20–30 milligrams may be given after  min if inadequate response to initial bolus
Esmolol 500 micrograms/kg IV bolus over  min, followed by IV infusion starting at  micrograms/kg/min; titrate infusion to desired heart rate
Metoprolol .5–5 milligrams IV every 2–5 min; maximum total dose  milligrams IV over
10–15 min
Propranolol 1–3 milligrams IV over  min; may repeat every 2–5 min up to a total of  milligrams
Drugs to Terminate Tachydysrhythmias
Procainamide Initial: 20–50 milligrams/min OR 100 milligrams every  min until arrhythmia Used in wide­complex tachydysrhythmias and newis suppressed, hypotension occurs, or the QRS complex is prolonged by 50% onset atrial fibrillation from its original duration (maximum dose:  milligrams/kg) Median time to conversion of new­onset atrial
Maintenance infusion rate: 1–4 milligrams/min fibrillation about  h
Caution in patients with AMI and LV dysfunction
Infuse initial dose at rate of  milligrams/min to reduce adverse effects
Amiodarone Stable patient: 150 milligrams in 100 mL of D5W over  min, followed by Used in wide­complex tachydysrhythmias and newinfusion at  milligram/min for  h onset atrial fibrillation
If breakthrough arrhythmia occurs, may give repeat 150­milligram boluses Preferred in setting of AMI or LV dysfunction over  min Contraindicated in pregnancy
Maximum total daily dose is .2 grams
Ventricular fibrillation or pulseless ventricular tachycardia: 300 milligrams IV bolus; may repeat with additional dose of 150 milligrams IV bolus
Lidocaine Loading dose: 50–100 milligrams over 2–3 min. May repeat in  min (up to 300 Third­line agent for ventricular tachycardia and milligrams in any 1­h period) ventricular fibrillation
Maintenance: 1–4 milligrams/min (start low in patients with liver dysfunction or CHF)
Magnesium  grams IV over  min, followed by infusion of 1–2 grams/h Used in torsades de pointes with long QT interval sulfate
Ibutilide Weight <60 kg:  micrograms/kg IV over  min Used for conversion of new­onset atrial fibrillation or
Weight >60 kg:  milligram IV over  min flutter
Median time to conversion 20–30 min
Flecainide Weight <70 kg: 200 milligrams PO Used for conversion of new­onset atrial fibrillation or
Weight >70 kg: 300 milligrams PO flutter
OR  milligrams/kg IV over  min* Median time to conversion up to  h
Avoid in patients with ACS or cardiomyopathy
Propafenone Weight <70 kg: 450 milligrams PO Used for conversion of new­onset atrial fibrillation or
Weight >70 kg: 600 milligrams PO flutter
OR  milligrams/kg IV over  min* Median time to conversion  h
Avoid in patients with ACS, cardiomyopathy, or severe
COPD
Vernakalant*  milligrams/kg IV infusion over  min; if dysrhythmia persists after  min, a Used for conversion of new­onset atrial fibrillation or second infusion of  milligrams/kg IV over  min can be given flutter
Median time to conversion 8–11 min
Avoid in patients with hypotension, ACS within  days, severe aortic stenosis, and prolonged QT interval
Abbreviations: ACS = acute coronary syndrome; AMI = acute myocardial infarction; AV = atrioventricular; COPD = chronic obstructive pulmonary disease; LV = left ventricle.
*IV preparations of flecainide, propafenone, and vernakalant not available in the United States.
Transcutaneous pacing is the most appropriate pacing method for the acutely symptomatic patient (see Chapter , “Cardiac Pacing and Implanted
Defibrillation”). Transvenous pacing requires physician expertise, time, and specialized equipment for insertion and proper placement. With any form of cardiac pacing, (1) establish electrical capture (pacer spike is associated with appropriate ECG response, such as QRS complex); (2) once electrical capture occurs, determine mechanical capture by demonstrating a palpable pulse occurring in association with the paced beat as well as a sustained improvement in perfusion; (3) adjust the paced rate (the rate at which the pacer spikes are delivered by the machine); and (4) establish the energy required to achieve sustained electrical pacing (capture). Disease­specific therapies can also be effective in reversing a toxin­induced bradycardia (e.g., treatment of hyperkalemia or toxicity from calcium channel blockers, β­blockers, or digitalis).
GENERAL APPROACH TO TACHYDYSRHYTHMIAS
Tachycardia describes rhythms with a ventricular rate greater than 100 beats/min in an adult, with age­appropriate values in children. Tachycardias are categorized as supraventricular or ventricular (Figure 18­1). Supraventricular tachycardias originate from a focus within or above the AV node and most often present with a narrow QRS complex; thus, they are termed narrow­complex tachycardias. Ventricular tachycardias, resulting from a focus below the AV node in the ventricular myocardium, usually demonstrate a widened QRS complex and are referred to as wide­complex tachycardias. This classification scheme does have limitations; a supraventricular rhythm can present with a widened QRS complex due to aberrant ventricular conduction, the widened QRS complex resulting from a fixed (i.e., preexisting) bundle branch block, rate­related conduction block, ventricular
 preexcitation syndrome (i.e., Wolff­Parkinson­White [WPW] syndrome), or toxic­metabolic condition. The normal QRS complex duration is less than
100 milliseconds for older children and adults; therefore, a wide­complex tachycardia possesses a QRS complex width greater than 100 milliseconds.
FIGURE 18­1. Tachycardia classification. AVnRT = atrioventricular nodal reentrant tachycardia; AVRT = atrioventricular reentrant tachycardia; VT = ventricular tachycardia.
Common narrow­complex tachycardias include sinus tachycardia, atrial fibrillation, atrial flutter, and paroxysmal supraventricular tachycardia; less common narrow­complex tachycardias include multifocal atrial tachycardia, atrial tachycardias, and preexcited tachycardias seen in accessory
 pathway syndromes such as the WPW syndrome. Wide­complex tachycardias include ventricular tachycardia and supraventricular tachycardia with
,7 aberrant conduction. Ventricular tachycardia is further subdivided into monomorphic and polymorphic forms; the polymorphic category includes the subtype called torsades de pointes, a form of polymorphic ventricular tachycardia diagnosed when the specific QRS complex pattern (sequential
 and recurring QRS complex amplitude increase and decrease) and QTc interval prolongation (>450 milliseconds) are noted.
Treatment for symptomatic tachycardia is primarily IV medications for the stable patient and electrical therapy for the unstable patient (see Chapter ,
“Defibrillation and Cardioversion”). In certain situations, treatment of the underlying event is the most appropriate, rather than therapy aimed at the dysrhythmia; in other situations, direct attention to both the dysrhythmia and the underlying medical situation is required. The QRS width, often indicating the portion of the heart where the dysrhythmia originates, guides therapeutic choices.
NARROW­COMPLEX TACHYCARDIA
Sinus tachycardia and multifocal atrial tachycardia are best managed by treating the underlying cause rather than the dysrhythmia specifically. Other narrow­complex tachycardias, such as atrial fibrillation/flutter, AV nodal reentrant tachycardia, and AV reentrant tachycardia (narrow complex
[orthodromic] AVRT), require specific antiarrhythmic treatment by a combination of vagal maneuvers (Table 18­3), medications (Table 18­2), and
 electrical cardioversion (Figure 18­2). Basic supportive therapy in most patients involves an IV fluid bolus to expand the circulating intravascular volume and supplemental oxygen as needed. (See Video: Narrow Complex Tachycardia.)
TABLE 18­3
Vagal Maneuvers
Carotid sinus massage Listen for bruit first; do not massage an artery with a bruit
Massage only one side at a time
Massage for  s or less
Valsalva maneuver Patient lying flat or with head and chest elevated to  degrees
Have patient hold breath and strain against closed glottis while tightening abdominal wall muscles
Hold for as long as practical, ideally >10–20 s
Increased vagal tone seen during release phase after breath hold
Modified Valsalva maneuver13 Patient lying on stretcher with head and chest elevated to  degrees
Patient instructed to blow into 10­mL syringe with enough force to move plunger for  s
Patient then laid flat and legs passively elevated to  degrees for  s
Legs then lowered and patient lies flat for an additional  s
Diving reflex More effective in infants than adults
Place bag of ice and water on face for 15–30 s
FIGURE 18­2. Treatment of narrow­complex tachycardia. AV = atrioventricular; AVnRT = atrioventricular nodal reentrant tachycardia; AVRT = atrioventricular reentrant tachycardia; CHF = congestive heart failure; MAT = multifocal atrial tachycardia; VT = ventricular tachycardia.
Video 18­1: Narrow Complex Tachycardia
Used with permission from Sarah Stahmer, MD
Play Video
Vagal maneuvers heighten parasympathetic tone and may slow electrical conduction in the heart to a degree that abolishes sustained reentry (Table
18­3). If applied early, vagal maneuvers can convert many patients presenting with reentrant tachycardias, such as paroxysmal supraventricular tachycardia and narrow­complex tachycardia associated with WPW syndrome (narrow complex [antidromic] AVRT). Effective vagal maneuvers include carotid sinus massage, the release phase of the Valsalva maneuver, and the diving reflex; the response to these vagal maneuvers is enhanced by
10–12 placing the patient supine during the release phase. A recently described modification of the Valsalva maneuver (Table 18­3) is more effective than
,14 the standard technique in terminating reentrant supraventricular tachycardias.
Adenosine is a very­short­acting agent that blocks conduction through the AV node and can interrupt sustained reentry when the AV node is part of the circuit (Table 18­2). The AV nodal blocking effect of adenosine is very transient, although quite profound, so a brief period of AV nodal blockade with near­immediate recurrence of the reentrant supraventricular tachycardia is not a treatment failure but a consequence of the medication’s short
 duration of effect. In such situations, repeat adenosine with a higher dose (12 milligrams).
β­Blockers and calcium channel blockers slow conduction through the AV node and can convert some supraventricular tachycardias, such as reentrant supraventricular tachycardias, and slow the ventricular response in others, such as atrial fibrillation or flutter. Esmolol, an IV β­blocker with a short duration of effect, can be used when temporary AV nodal blockade is desired and a longer period of action is not anticipated (as in conversion of paroxysmal supraventricular tachycardia) or when the patient is unstable and the ability to titrate the degree of drug effect is important. Metoprolol is a longer­acting β­blocker used in more stable patients, typically for ventricular rate control in patients with atrial fibrillation. Verapamil is a calcium channel blocker used for conversion of reentrant supraventricular tachycardias, and although it can be used for ventricular rate control, there is a greater potential for hypotension, so diltiazem, which does not have as much potential to induce hypotension, is the calcium channel blocker recommended for ventricular rate control.
Synchronized electrical cardioversion can be used in narrow­complex tachycardias when patients are unstable or do not respond to pharmacologic measures (see Chapter 23).
WIDE­COMPLEX TACHYCARDIA
Wide­complex tachycardia includes ventricular tachycardia and supraventricular tachycardia with aberrant conduction, manifested by widened QRS complex. The differential diagnosis of the category of supraventricular tachycardia with aberrant conduction includes not only the SVTs noted in
Figure 18­1 but also WPW­related arrhythmias, such as wide­complex (antidromic) AV re­entrant tachycardia, and WPW­related atrial fibrillation.
In the stable patient, pharmacologic agents used to terminate a wide­complex tachycardia include procainamide, amiodarone, lidocaine, and
,17 magnesium (Table 18­2 and Figure 18­3). Procainamide is the antiarrhythmic of choice for the stable patient. Amiodarone and
16–18 lidocaine are less effective. If WPW­related atrial fibrillation or wide­complex (antidromic) AVRT are suspected, use procainamide as the drug of choice and avoid amiodarone. Magnesium is used for tachydysrhythmias associated with QT interval prolongation, such as torsades de pointes.
FIGURE 18­3. Treatment of wide­complex tachycardia. AF = atrial fibrillation; AV = atrioventricular; SVT = supraventricular tachycardia; WPW = Wolff­Parkinson­White syndrome.
Electrical cardioversion is the preferred treatment for wide­complex tachycardia (including ventricular tachycardia and certain types of supraventricular tachycardia with aberrant conduction [atrial fibrillation/flutter, AV nodal reentrant tachycardia, and AV reentrant tachycardia]) with
,8 hemodynamic instability, myocardial ischemia, or failure of pharmacologic treatment (see Chapter 23).
ECTOPIC BEATS
Ectopic beats originate from atrial, AV nodal, and/or ventricular tissues. These beats are frequently benign but can cause symptoms, with patients
 noting palpitations or an irregular heartbeat. Uncommonly, premature ventricular contractions can trigger serious reentrant dysrhythmias and may require therapy.
PREMATURE ATRIAL CONTRACTIONS
DESCRIPTION
Premature atrial contractions originate from ectopic pacemakers anywhere in the atrium other than the SA node (Figure 18­4); they are identified by
 characteristic ECG features (Table 18­4). The ectopic P wave may not be conducted through the AV node if the premature atrial contraction reaches the AV node during the absolute refractory period. When a premature atrial contraction reaches the AV node during the relative refractory period, it may be conducted with a delay, as demonstrated on the ECG by a longer PR interval than seen with a sinus beat. Nonconducted premature atrial contractions are the most common cause of pauses in cardiac rhythm. Premature atrial contractions may occur in a pattern, such as every other beat
(atrial bigeminy), every third beat (atrial trigeminy), and so on.
FIGURE 18­4. Premature atrial contractions in an atrial trigeminal pattern.
TABLE 18­4
ECG Features of Premature Atrial Contractions
P waves that appear sooner (prematurely) than expected sinus beat
Ectopic P waves
With different shape and axis than the SA node–initiated P wave
That may or may not be conducted through the AV node
Interval between normal P waves encompassing the premature atrial contraction is less than twice the existing P to P cycle length (a noncompensatory pause)
Abbreviations: AV = atrioventricular; SA = sinoatrial.
Most premature atrial contractions are conducted with baseline QRS complexes, but some may be conducted aberrantly through the infranodal system, particularly if they reach a bundle branch during the refractory period. The premature atrial contraction will often depolarize the SA node
(“reset”), so the interval between normal P waves encompassing the premature atrial contraction will not be twice the existing P to P interval, creating a shorter pause than the fully compensatory pauses seen after most premature ventricular contractions.
CLINICAL SIGNIFICANCE
Premature atrial contractions are common at all ages and usually do not indicate underlying heart disease. Increased rates of premature atrial contractions are seen in patients with chronic heart or lung disease. Chemical agents that enhance either sympathetic tone (e.g., cocaine, amphetamines, caffeine, nicotine) or parasympathetic tone (e.g., digoxin) may lead to a higher frequency of premature atrial contractions. Premature atrial contractions can precipitate sustained atrial tachycardia, flutter, or fibrillation under certain circumstances. Frequent premature atrial
 contractions are associated with an increased risk for stroke and sudden death, although there is no evidence that attempts to suppress reduce that risk. Symptomatic patients are managed by discontinuing any precipitating toxins and treating any underlying disorder that is contributing to premature atrial contraction generation.
PREMATURE VENTRICULAR CONTRACTIONS
DESCRIPTION
Premature ventricular contractions (PVCs) occur when electrical impulses originate from single or multiple areas in the ventricles (Figure 18­5) and
 are identified by characteristic ECG features (Table 18­5).
FIGURE 18­5. Sinus rhythm with premature ventricular contractions (PVCs). A. Sinus rhythm with a single PVC. B. Sinus rhythm with multiple, unifocal PVCs. C. Sinus rhythm with multifocal PVCs (in this example, three different PVC morphologies in this single lead, indicated by #1, #2, and #3).
TABLE 18­5
ECG Features of Premature Ventricular Contractions
Absence of P wave prior to the QRS complex
Occasional retrograde P wave following QRS complex
Abnormally widened QRS complex with different morphology from SA node–initiated QRS complex
Commonly a compensatory postectopic pause following the PVC to next SA node–initiated beat
ST segments and T waves that are directed opposite the major QRS complex deflection
Abbreviations: PVC = premature ventricular contraction; SA = sinoatrial.
Most PVCs do not affect the spontaneous discharge of the SA node, so the interval between normal sinus P waves encompassing the PVC is twice the previous P to P interval—an interval termed a fully compensatory postectopic pause. This fully compensatory pause occurs because the SA node discharges during the refractory period of either the AV node or His bundles induced by the PVC. Less commonly, a PVC may be interpolated between two sinus beats. Many PVCs occurring in a bigeminal or trigeminal pattern have a fixed coupling interval (within  milliseconds) from the preceding sinus beat (Figure 18­6). Occasionally, a ventricular fusion beat occurs when both supraventricular and ventricular impulses depolarize the ventricular myocardium almost simultaneously. The QRS configuration of a fusion beat has characteristics of both the normally conducted beat and the ectopic one.
FIGURE 18­6. Premature ventricular contractions producing ventricular bigeminy.
The degree (quantity and quality) of the PVCs is categorized as follows: (1) an occasional PVC seen on the rhythm strip is categorized as isolated (Figure
18­5A), (2) multiple PVCs of similar morphology are called unifocal (Figure 18­5B), and (3) multiple PVCs with different morphology are called multifocal
(Figure 18­5C), implying more than one ventricular focus is producing ectopy.
CLINICAL SIGNIFICANCE
PVCs are very common and related to factors that alter the electrophysiology of cardiac tissue or to pathologic conditions of the myocardium itself.
Sometimes, infrequent or rare PVCs may be observed in patients without any evidence of heart disease. PVCs may trigger sustained runs of ventricular
,21 tachycardia (Figure 18­7).
FIGURE 18­7. Sinus rhythm in an ST­segment elevation myocardial infarction patient with a premature ventricular contraction (PVC) initiating ventricular tachycardia. Note the R wave (large arrow) of a PVC falling on the T wave (small arrow) of the last sinus beat. This R­on­T event produces ventricular tachycardia.
There is a correlation between the severity of underlying coronary artery disease and the degree of ventricular ectopy, and in addition, ventricular
,23 ectopy is an independent risk factor for sudden cardiac death. In acute coronary syndrome, PVCs indicate the underlying electrical instability of the heart, but patterns of ventricular ectopy (“warning dysrhythmias”) are not reliable predictors of subsequent ventricular fibrillation.
Frequent PVCs present over a long duration (>30 months) can induce a reversible impairment in ventricular function, termed PVC­induced
 cardiomyopathy. Such patients typically have >15% to 20% of their heartbeats due to PVCs (PVC burden), noting palpitations along with symptoms of heart failure.
TREATMENT
Review the ECG for evidence of ischemia or infarction, chamber enlargement, QT interval prolongation, or Brugada syndrome. Assess for potentially
,25 reversible conditions such as hypoxia, drug effect, or electrolyte abnormalities and treat appropriately. Typical recommendations for stress
 reduction and elimination of stimulants such as caffeine or nicotine are not consistently effective. Patients with greater than three PVCs in a row are considered to have nonsustained ventricular tachycardia, which can be a marker for sustained tachydysrhythmias and sudden cardiac death. If this is a new dysrhythmia, initiate emergency cardiac investigation.
Pharmacologic suppression of isolated PVCs with IV antiarrhythmic medications in the acute setting does not improve survival for the acute condition, and attempts to suppress PVCs with long­term oral antiarrhythmics increase mortality due to the dangerous prodysrhythmic properties of the
,25 medications themselves. Implantable cardioverter­defibrillators are used in patients with PVCs that have potential to trigger malignant ventricular dysrhythmias or cardiac arrest. Patients with PVC­induced cardiomyopathy can be successfully treated with ablation of the ectopic focus, reducing PVC
 burden with recovery of impaired ventricular function over time.
BRADYDYSRHYTHMIAS
Junctional and idioventricular rhythms may present with lightheadedness, syncope, or hypotension requiring therapy.
JUNCTIONAL RHYTHM
DESCRIPTION
Under normal circumstances, the SA node discharges at a faster rate than the AV node, so the pacemaker function of the AV node and all other slower pacemakers are suppressed. If SA node discharges are slow or fail to reach the AV node, junctional escape beats will produce a rhythm (Figure 18­8) usually at a rate between  and  beats/min. If the junctional beats continue in sequence, then a junctional rhythm is present. In most cases, junctional escape beats do not conduct retrograde into the atria, so a QRS complex without a P wave is usually seen (Figure 18­8A); rarely, the junctional escape beat conducts back into the atria, producing the retrograde P wave, which is an inverted P wave found immediately prior to or following the QRS complex (Figure 18­8B).
FIGURE 18­8. Junctional rhythm. A. Junctional rhythm. B. Junctional rhythm with retrograde P waves (arrow).
At times, enhanced AV nodal automaticity overrides the sinus node and produces an accelerated junctional rhythm with a rate of  to 100 beats/min or junctional tachycardia with a rate greater than 100 beats/min (Table 18­6). Usually, the enhanced junctional pacemaker captures both the atria and ventricles.
TABLE 18­6
ECG Features of Junctional Rhythm
Absence of normal (sinus­mediated) P waves with normal PR interval
Rare retrograde P wave (usually an inverted P wave and immediately adjacent to QRS complex, before or after)
Narrow QRS complex
Ventricular rate
Between  and  beats/min for junctional rhythm
Between  and 100 beats/min for accelerated junctional rhythm
>100 beats/min for junctional tachycardia
CLINICAL SIGNIFICANCE
Junctional escape beats may occur whenever there is a long enough pause in the impulses reaching the AV node, as with sinus bradycardia, slow phase
 of sinus dysrhythmia, or during the pause after premature beats. Sustained junctional escape rhythms may be seen with heart failure, myocarditis, hypokalemia, or digitalis toxicity.
Accelerated junctional rhythm, including junctional tachycardia, may occur from medication toxicity, acute rheumatic fever, or inferior myocardial
 ischemia. With medication toxicity (particularly digitalis compounds) in a patient being treated for atrial fibrillation, the rate is usually between  and 130 beats/min, and the ECG is characterized by regular QRS complexes superimposed on atrial fibrillatory waves.
TREATMENT
Isolated, infrequent junctional escape beats usually do not require specific treatment. If sustained junctional escape rhythms are producing symptoms, the underlying cause should be treated. Atropine can be used to accelerate the SA node discharge rate and enhance AV nodal conduction.
Accelerated junctional rhythm and junctional tachycardia are managed by treating the underlying cause.
IDIOVENTRICULAR RHYTHM
DESCRIPTION
Idioventricular rhythms originate from the ventricles (Figure 18­9), manifesting as regular widened QRS complexes without evidence of atrial activity
(Table 18­7). An idioventricular rhythm has a ventricular rate of  to  beats/min, and an accelerated idioventricular rhythm has a ventricular rate of

 to 110 beats/min. Idioventricular rhythm tends to appear in nonsustained fashion with runs of short duration, ranging from  to  consecutive beats, and will typically begin with a fusion beat. Accelerated idioventricular rhythms are more sustained and tend to have a gradual onset and termination.
FIGURE 18­9. Idioventricular rhythm with a ventricular rate of approximately  beats/min.
TABLE 18­7
ECG Features of Idioventricular Rhythm
Widened QRS complex
QRS complexes occurring regularly
No evidence of atrial activity: no P waves
Ventricular rate
30–50 beats/min for idioventricular rhythm
50–110 beats/min for accelerated idioventricular rhythm
Often in nonsustained fashion with runs of short duration: 3–30 consecutive beats
CLINICAL SIGNIFICANCE
Idioventricular rhythm is seen most commonly in the setting of an ST­segment elevation myocardial infarction. Accelerated idioventricular rhythms have been seen in drug toxicity (cocaine and digitalis), electrolyte abnormalities (hyperkalemia), and cardiomyopathies, and during fibrinolysis of an occluded coronary artery, termed a reperfusion dysrhythmia, although the appearance of this dysrhythmia does not distinguish between complete
 and incomplete reperfusion. Although there is some association with ventricular tachycardia, there is no apparent association with ventricular fibrillation. Idioventricular rhythms, particularly the slower versions, can produce dizziness, weakness, syncope, chest pain, and dyspnea; profound hypoperfusion may occur. Accelerated idioventricular rhythm itself usually produces no symptoms, but the loss of atrial contraction and subsequent fall in cardiac output can produce hemodynamic deterioration.
TREATMENT
With idioventricular rhythm producing hypoperfusion, drugs to increase the heart rate are appropriate. Atropine can be tried, although the likelihood of successful treatment is low. Cardiac pacing is often needed, starting via the transcutaneous route. In most cases of accelerated idioventricular rhythm, treatment is not necessary. If accelerated idioventricular rhythm is the only functioning pacemaker, suppression with antiarrhythmic agents may lead to asystole. If sustained accelerated idioventricular rhythm produces symptoms secondary to a decrease in cardiac output, sequential AV pacing is recommended.
SUPRAVENTRICULAR TACHYDYSRHYTHMIAS
ATRIAL FIBRILLATION AND ATRIAL FLUTTER
DESCRIPTION
After sinus tachycardia, atrial fibrillation is the next most frequent narrow­complex tachycardia encountered in the ED; atrial flutter is a less common
 dysrhythmia. Atrial fibrillation occurs when there are multiple, small areas of atrial myocardium continuously discharging and contracting. There is no uniform atrial depolarization and contraction but, rather, only a quivering of the atrial chamber walls, resulting in less than effective ventricular filling and diminished cardiac output.
The ECG hallmarks of atrial fibrillation (Figure 18­10 and Table 18­8) include the absence of discernible P waves and an irregularly irregular ventricular rhythm. With the chaotic atrial activity, distinct P waves are not noted; rather, either a flat or chaotic baseline is seen, most prominent in lead V . The irregularly irregular ventricular rhythm results from the atrial chaos and the variable conduction of impulses through the AV node to the
 ventricle. The atrial rate in atrial fibrillation is often greater than 600 beats/min, whereas the ventricular rate is markedly lower due to the refractory period of the AV node; in atrial fibrillation where the AV node is unaffected by disease or medications, the ventricular rate is typically 120 to 170 beats/min. Illnesses or medications may reduce AV node conduction and markedly slow ventricular response. A very rapid ventricular response (>200 beats/min) may be seen in patients with accessory or bypass tracts (discussed later in this chapter).
FIGURE 18­10. Three examples of atrial fibrillation with irregular ventricular response.
TABLE 18­8
ECG Features of Atrial Fibrillation
Absence of discernible P waves with flat or chaotic isoelectric baseline
QRS complexes narrow unless preexisting bundle branch block or preexcitation syndrome
Irregularly irregular ventricular rhythm
In contrast to atrial fibrillation, atrial flutter most often is a regular rhythm (Figure 18­11 and Table 18­9); in rare cases, it can be irregular due to variable AV nodal block. P waves are present and of a single morphology, typically a downward deflection, called flutter waves resembling a saw blade with a “sawtooth” pattern, best seen in the inferior ECG leads and lead V . Most commonly, the atrial rate is regular, classically around 300 beats/min,
 varying between 250 and 350 beats/min. The ventricular rhythm is frequently regular and is a function of the AV block. AV ratios of 2:1 are common and produce a ventricular rate around 150 beats/min, whereas a 3:1 AV ratio will result in a ventricular rate of 100 beats/min. Although the degree of AV conduction is often fixed, it may also be variable and create an irregular ventricular response. A regular narrow­complex tachycardia at an approximate rate of 150 beats/min (+/–  beats/min) strongly suggests atrial flutter with 2:1 conduction.
FIGURE 18­11. Atrial flutter. A. Regular, narrow­complex tachycardia at a ventricular rate of 155 beats/min. B. Atrial flutter with flutter waves most visible in leads , , and aVF. C. Atrial flutter response to carotid sinus massage inducing transient AV block and unmasking flutter waves.
TABLE 18­9
ECG Features of Atrial Flutter
Identifiable P waves
Single morphology
Negative amplitude (“flutter waves” in “sawtooth pattern”) best seen in inferior ECG leads and V

Atrial rate is regular, usually at 300 beats/min (250–350 beats/min)
QRS complexes narrow unless preexisting bundle branch block
Ventricular rate regular, although occasional irregularity can be seen
Ventricular rate often 150 beats/min due to 2:1 atrioventricular nodal block
CLINICAL SIGNIFICANCE
Atrial fibrillation is usually associated with ischemic or valvular heart disease; less common causes include congestive cardiomyopathy, myocarditis,
,31 alcohol binge (“holiday heart”), thyrotoxicosis, and blunt chest trauma. Left atrial enlargement is a common feature of patients with chronic atrial fibrillation. Atrial fibrillation can be paroxysmal (lasting less than  days, terminating either spontaneously or with treatment), persistent (sustained longer than  days or requiring treatment to terminate), long­standing persistent (lasting continuously longer than  year), or permanent (long­
 standing where a decision has been made not to try to restore normal sinus rhythm). New or recent onset is applied to symptomatic patients presenting to the ED without a prior history of atrial fibrillation.
The clinical consequences of atrial fibrillation include loss of atrial contraction, potential for rapid ventricular rates, and risk of thromboembolism. In patients with compromised cardiac function, left atrial contraction contributes significantly to left ventricular filling, so the loss of effective atrial contraction, as in atrial fibrillation, may produce heart failure in these patients. A rapid ventricular rate can impact ventricular filling as well as coronary and systemic perfusion. Atrial fibrillation increases the risk of venous and atrial thrombosis, with potential for pulmonary and systemic arterial
 embolism.
If an atrial thrombus has formed, conversion from atrial fibrillation to sinus rhythm can propel a portion of the thrombosis out into the systemic circulation, and this risk increases with duration of the dysrhythmia. Observational studies note that conversion from new­onset atrial fibrillation that has been present for  hours or less carries a .3% risk of arterial embolism, whereas that risk is about 1% for durations of  to  hours before
 conversion. For patients with heart failure and diabetes mellitus, conversion from new­onset (duration <48 hours) atrial fibrillation carries a risk of
 thromboembolic events as high as .8%. After a duration of >48 hours, the risk of conversion­induced thromboembolic events is increased across all
,35 patient groups, so a 3­ to 4­week period of anticoagulation is recommended prior to conversion.
TREATMENT
Treatment of atrial fibrillation in the ED involves three issues: ventricular rate control, rhythm conversion, and anticoagulation to prevent arterial
35–40 embolism. Treatment varies according to patient stability, duration of symptoms, and chronicity of atrial fibrillation (paroxysmal, persistent, or permanent). Review prior records to identify past episodes or treatment for atrial fibrillation. For new­onset atrial fibrillation, consider checking
 thyroid function. For patients on warfarin, check the prothrombin time and INR. Calculate either the CHADS or CHA DS ­VASc score to risk­stratify
   the potential for future arterial embolic complications; a CHADS score of  or a CHA DS ­VASc score of  or  identifies low­risk patients (Table 18­

,31
10).
TABLE 18­10
CHAD S and CHA DS ­VASc Scores

Criteria CHADS  CHA  D S  ­VAaSc
Congestive heart failure  
Hypertension  
Age ≥75 y  
Diabetes mellitus  
Stroke, TIA, or thromboembolism  
Vascular disease (CAD, PAD) – 
Age 65–74 y – 
Sex (female) – 
Range 0–6 0–9
Abbreviations: CAD = coronary artery disease; PAD = peripheral artery disease; TIA = transient ischemic attack.
For patients with paroxysmal atrial fibrillation or acute medical conditions producing atrial fibrillation, a period of observation and treatment in the ED
,42 is appropriate as the atrial fibrillation may spontaneously convert. Up to 70% of otherwise healthy ED patients evaluated for acute­onset atrial
 fibrillation will spontaneously convert within  to  hours. Ventricular rate control may help control symptoms until conversion. Also, it is significantly more difficult to achieve rate or rhythm control of atrial fibrillation in patients with acute underlying medical illness, and such attempts are
 associated with an increased incidence of adverse events. In situations involving atrial fibrillation with rapid ventricular response and an active, significant underlying acute medical issue (e.g., sepsis, severe hypovolemia, pulmonary embolus, alcohol withdrawal), the presentation can be
 described as complex atrial fibrillation. In these presentations, management priority is focused on treating the underlying medical issue while not employing standard rate and rhythm control therapies in the early stages of care.
For patients with recent­onset atrial fibrillation and a rapid ventricular response that is producing hypotension, myocardial ischemia, or pulmonary
,35,36,45 edema, treat with urgent electrical cardioversion. For unstable patients with long­standing atrial fibrillation, electrical cardioversion is not likely to succeed, and instead, initiate hemodynamic resuscitation and ventricular rate control treatment. If the unstable patient is at increased risk for embolic complications related to cardioversion, administer an initial dose of a direct­acting oral anticoagulant for nonvalvular atrial fibrillation or lowmolecular­weight heparin for patient with mechanical prosthetic valve, rheumatic mitral stenosis, or serious renal impairment before or immediately
 after electrical cardioversion (Table 18­11). For patients treated with heparin, transition to warfarin is begun on discharge with continued heparin treatment until the INR is in the therapeutic range, typically .5 to .5 for mechanical prosthetic valves or mitral stenosis. Patients are continued on
 anticoagulant therapy until early follow­up to review whether long­term anticoagulation is needed.
TABLE 18­11
Pericardioversion Anticoagulation for Unstable Patients
Nonvalvular atrial fibrillation: Dabigatran etexilate mesylate 150 milligrams PO (75 milligrams if CrCl is 15–30 mL/min)
Onset >48 h or unknown or or Rivaroxaban  milligrams PO (15 milligrams if CrCl is 15–50 mL/min)
Stroke or TIA <6 mo or or Apixaban  milligrams PO (2.5 milligrams PO in patients with at least  of the following characteristics: age
CHA DS ­VASc scores ≥2 ≥80 y, body weight ≤60 kg, or serum creatinine ≥1.5 milligrams/dL)

Mechanical prosthetic valve, rheumatic Enoxaparin  milligram/kg SC mitral stenosis, or CrCl <15 mL/min
Abbreviations: CrCl = creatinine clearance; TIA = transient ischemic attack.
For stable low­risk patients in the ED with new­onset atrial fibrillation, either rate­control or rhythm­conversion strategies are appropriate (Table 18­
,35,36
12). The rate­control approach consists of initiating medications that block the AV node to control the ventricular response, initiating oral anticoagulants to prevent thromboembolism (if appropriate), and reevaluation after  to  weeks for elective cardioversion. The rhythm­conversion approach uses electrical or pharmacologic methods to convert the patient back into sinus rhythm while in the ED.
TABLE 18­12
ED Management of Atrial Fibrillation/Flutter in Stable Patients* Ventricular Rate Control
Diltiazem 15–20 milligrams IV bolus over  min; may repeat bolus if inadequate rate response
Once satisfactory rate response, begin IV infusion 5–10 milligrams/h, titrate to ventricular rate <90–100 beats/min
Begin transition to oral diltiazem,  or  milligrams PO at 5­ or 10­milligram infusion rate, respectively
Stop IV infusion  h after oral dose
Metoprolol  milligrams IV; may repeat every  min to total of  milligrams
Once satisfactory rate response, give metoprolol PO (12.5 milligrams PO for every  milligrams given IV)
Rhythm Conversion: Synchronized Cardioversion
Atrial flutter May require as little as 25–50 J
Atrial 150–200 J fibrillation
Rhythm Conversion: Pharmacologic
Ibutilide Weight <60 kg:  micrograms/kg IV over  min
Weight >60 kg:  milligram IV over  min
Procainamide 15–17 milligrams/kg IV over  min, followed by IV infusion at 1–4 milligrams/min
Flecainide  milligrams/kg IV over  min†
Vernakalant†  milligrams/kg IV infusion over  min; if dysrhythmia persists after  min, a second infusion of  milligrams/kg IV over  min can be given
*See Chapter , Tables 19­6, 19­7, and 19­19, for detailed discussion.
†Not available in the United States
Control of the ventricular response is done using a calcium channel blocker (diltiazem) or β­blockers (metoprolol or esmolol) with evidence of more
 effective acute rate control with diltiazem. If diltiazem or β­blockers are ineffective, IV procainamide or amiodarone is an option to slow the
 ventricular response. The goal for rate control is a ventricular rate of <100 beats/min at rest.
,45
Electrical cardioversion using 150 to 200 J can terminate atrial fibrillation allowing for sinus rhythm to resume. Conversion to and retention of sinus rhythm is more likely when atrial fibrillation is of short duration (<48 hours) and the atria are not greatly dilated. Observational analysis also notes that administration of rate control or rhythm conversion medications prior to electrical cardioversion attempts is associated with a reduced rate
  of successful conversion to sinus rhythm. Although ED electrical cardioversion is effective in many atrial fibrillation patients and observational
 49–51 studies indicate shorter ED length of stay, there has been mixed acceptance of this approach. As noted earlier, a significant portion of patients
,42,43,52,53 with new­onset atrial fibrillation will spontaneously convert to sinus rhythm within  hours of onset and evaluation. This rate of spontaneous conversion coupled with the results of atrial fibrillation trials demonstrating that rate control is similar to rhythm control in terms of
,52–54 several key end points indicates no proven benefit for conversion of all new atrial fibrillation patients to sinus rhythm while in the ED. The patient with new­onset atrial fibrillation who is stable can certainly be managed with rate control alone, either as an inpatient or outpatient depending on overall clinical condition.
,55–58
The antiarrhythmics procainamide, ibutilide, flecainide, propafenone, and vernakalant can chemically convert atrial fibrillation to sinus rhythm.
Of the five, ibutilide has the highest consistent success rate for conversion. Ibutilide should not be given in the presence of hypokalemia, prolonged QT interval, or history of heart failure, as torsades de pointes may be initiated. This risk of torsades de pointes persists for  to  hours after the ibutilide is given. Pharmacologic conversion therapy is best avoided if duration is unknown or greater than  hours, allowing for heart clot detection and anticoagulation prior to any attempt.
Patients with recurrent paroxysmal atrial fibrillation are sometimes given oral medications (usually flecainide or propafenone) to be taken at the onset
 of the dysrhythmia; this “pill in a pocket” approach is successful in selected outpatients. This approach should only be used in patients with paroxysmal episodes after SA or AV node dysfunction, conduction disturbance (bundle branch block, Brugada syndrome), and structural heart disease
 have been excluded.
Atrial flutter is managed in the same fashion as atrial fibrillation: either rhythm conversion or ventricular rate control with β­blockers or calcium
 channel blockers. Atrial flutter is very responsive to electrical cardioversion; as little as  to  J is often effective. In general, patients in atrial flutter tend to better tolerate the dysrhythmia hemodynamically than patients with atrial fibrillation. This “hemodynamic toleration” results from the organized atrial contraction seen with atrial flutter, as opposed to the lack of organized atrial contraction with atrial fibrillation. Despite organized
 atrial activity, there is a risk of arterial embolism with atrial flutter, and corresponding recommendations for anticoagulation are based on the same
 criteria used for atrial fibrillation.
Patients with chronic atrial fibrillation and planned cardioversion should be anticoagulated for  to  weeks, assuming clinical stability allows such an
 approach. Patients with permanent atrial fibrillation are at increased risk for embolic stroke, and oral anticoagulation can reduce that occurrence.
The benefits of oral anticoagulation are counterbalanced by the potential adverse effects, usually hemorrhagic events. Clinical scoring tools, such as the CHA DS ­VASc, are used to estimate risk of stroke and guide the decision to initiate long­term oral anticoagulation therapy in atrial fibrillation

,31 patients.
DISPOSITION
Significant regional variation for hospitalization after an ED visit for atrial fibrillation has been reported, reflecting the interplay between patient
 clinical, socioeconomic, and hospital characteristics. Admission is indicated when the patient’s clinical status identifies distress with the need for
 continued therapy, such as heart failure with pulmonary congestion and continued respiratory distress, or ongoing myocardial ischemia. Admission
 is advised when ventricular rate control cannot be achieved and the patient has persistent symptoms. Patients with longer duration of dysrhythmia onset to presentation, previous stroke or transient ischemic attack, or pulmonary congestion on chest radiography are at higher risk for adverse 30­
 day outcomes ; these issues as well as other clinical factors should be considered when selecting disposition. Nonetheless, many patients can be safely discharged from the ED with short­term cardiology follow­up. Eighty percent or more of patients with atrial fibrillation can be discharged from
 the ED after rate or rhythm control with low risk for stroke or death within  days. For patients with atrial flutter converted to sinus rhythm with
,62 electrical cardioversion, about 90% can be discharged with a very low incidence of stroke within the following year. A site­specific protocol is useful to ensure that the patient with persistent dysrhythmia is discharged with appropriate medications and a plan for follow­up (Tables 18­13 and 18­

14).
TABLE 18­13
Example Protocol for Discharge of Patient With Persistent Atrial Fibrillation or Flutter
Patient is breathing comfortably on room air with oxygen saturation by pulse oximetry >95% and blood pressure is at baseline
Ventricular rate has been controlled to a rate <100 beats/min at rest
For nonvalvular atrial fibrillation patients not converted to sinus rhythm, determine risk for embolic stroke by calculating the CHA DS ­VASc score:

CHA DS ­VASc = 0: oral anticoagulation not recommended

CHA DS ­VASc = 1: either no anticoagulation or antiplatelet or oral anticoagulant is acceptable

CHA DS ­VASc ≥ 2: oral anticoagulation recommended; consult follow­up specialist for specific agent

Consult with internist or cardiologist to arrange early follow­up (within  d) and choose medications for rate and/or rhythm control and oral anticoagulants upon discharge (see Table 18­14)
Arrange outpatient echocardiography for patients with new­onset atrial fibrillation or flutter
Discharge patient with prescriptions for rate and/or rhythm control, and oral anticoagulant if indicated, in quantity only sufficient to last until followup appointment
TABLE 18­14
Rate Control and Oral Anticoagulation Medications Used Upon Discharge of Patients With Persistent Atrial Fibrillation or Flutter
Typical Initial Dose Comments
Rate Control Medications
Diltiazem  to  milligrams PO four times a day (immediate release); adjust dose as More effective than metoprolol in controlling heart needed for ventricular rate control rate and reducing dysrhythmia­related symptoms
Avoid in patients with heart failure with reduced ejection fraction
Transition to extended­release form when rate control dose established
Metoprolol  to  milligrams twice a day (immediate­release form); adjust dose as needed Transition to extended­release form when rate for ventricular rate control control dose established
Anticoagulants
Warfarin  milligrams PO daily Half­life 20–60 h; mean  h
Preferred regimen if CrCl <15 mL/min
Enoxaparin  milligram/kg SC every  h See text comments about bridging parenteral
Reduce dose if CrCl <30 mL/min anticoagulation
Dabigatran 150 milligrams PO twice a day (if CrCl >30 mL/min) Half­life 12–17 h etexilate  milligrams PO twice a day (if CrCl 15–30 mL/min) mesylate
Rivaroxaban  milligrams PO daily with evening meal (if CrCl >50 mL/min) Half­life 5–9 h
 milligrams PO daily with evening meal (if CrCl 15–50 mL/min)
Apixaban  milligrams PO twice a day Half­life during repeat oral dosing  h
### .5 milligrams PO twice a day in patients with at least  of the following characteristics: age ≥80 y, body weight ≤60 kg, or serum creatinine ≥1.5 milligrams/dL
Abbreviation: CrCl = creatinine clearance.

Oral anticoagulation is used to reduce the incidence of embolic stroke in patients with atrial fibrillation or flutter. Practical factors such as comorbidities, convenience, and cost should be considered when selecting the specific oral anticoagulant. It is appropriate to consult with the specialist who will be following the patient after ED discharge to discuss the specific agent to be used.
MULTIFOCAL ATRIAL TACHYCARDIA
DESCRIPTION
Multifocal atrial tachycardia is an irregular rhythm resulting from at least three different atrial foci competing to pace the heart, resulting in distinct P­
 wave morphologies on the ECG (Figure 18­12 and Table 18­15). Due to irregularity and the chaotic appearance of atrial depolarization, multifocal atrial tachycardia is often confused with atrial fibrillation or atrial flutter.
FIGURE 18­12. Multifocal atrial tachycardia. Note multiple P­wave morphologies with irregular tachycardia rhythm.
TABLE 18­15
ECG Features of Multifocal Atrial Tachycardia
At least  distinct P­wave morphologies in a single ECG lead
No consistent P to P, PR, or R to R intervals
Irregularly irregular rhythm with rates usually 100–180 beats/min
Normal QRS complex unless preexisting bundle branch blocks
Frequently confused with atrial fibrillation or flutter
CLINICAL SIGNIFICANCE
Multifocal atrial tachycardia is found most often in elderly patients with decompensated chronic lung disease, but may also complicate heart failure or sepsis. Treatment is directed toward the underlying disorder. With decompensated lung disease, oxygen and bronchodilators improve pulmonary function and arterial oxygenation and decrease atrial ectopy. Antiarrhythmic treatment is not indicated, and cardioversion has no effect.
PAROXYSMAL SUPRAVENTRICULAR TACHYCARDIA (ATRIOVENTRICULAR NODAL REENTRANT TACHYCARDIA)
DESCRIPTION
Eighty percent or more of cases of paroxysmal supraventricular tachycardia are AV nodal reentrant tachycardia, resulting from sustained reentry occurring within the AV node, with an ectopic atrial focus accounting for the remaining 15% to 20%. In paroxysmal supraventricular tachycardia
(Figure 18­13 and Table 18­16), the QRS complex is of normal width, rapid, and regular. P waves are “buried” within the QRS complex in about 70% of cases. In the other 30%, a P wave (so­called “retrograde” P wave) is found immediately adjacent before, during, or after the QRS complex without a measurable PR interval.
FIGURE 18­13. Paroxysmal supraventricular tachycardia.
TABLE 18­16
ECG Features of Paroxysmal Supraventricular Tachycardia
Absence of normal (sinus­mediated) P waves with normal PR interval
Rare retrograde P wave (usually inverted P wave and immediately adjacent to QRS complex, before or after)
Narrow QRS complex, usually <100 ms in duration
Ventricular rate usually 170–180 beats/min; the rate can range from as low as 130 beats/min to as high as 300 beats/min
CLINICAL SIGNIFICANCE
Paroxysmal supraventricular tachycardia is seen more frequently in females, with a peak in the late teenage and young adult years. The majority of
 patients are without active cardiovascular disease. Patients may be able to describe the abrupt onset of this reentrant dysrhythmia and also note when it self­terminates. Palpitations, lightheadedness, and dyspnea are common symptoms.
TREATMENT
,11,13,14
If applied early in the dysrhythmia course, vagal maneuvers are often effective (Table 18­3). Attention to technique is important to maximize
 success rate. If there is no response to vagal maneuvers, IV adenosine is recommended to convert to sinus rhythm. It is the rare patient who requires
β­blocker or calcium channel blocker. In patients with recalcitrant paroxysmal supraventricular tachycardia or who are unstable, use electrical cardioversion to convert the dysrhythmia.
ATRIOVENTRICULAR BLOCKS
First­degree AV block is characterized by a delay in AV conduction manifested by a prolonged PR interval. Second­degree AV block is characterized by intermittent AV conduction: some atrial impulses reach the ventricles, and others are blocked. Third­degree AV block is characterized by the complete blockage of atrial impulses to the ventricles.
First­degree and second­degree Mobitz type I AV blocks are usually not compromising. These two AV blocks can occur in asymptomatic healthy individuals without any implication for subsequent problems, but if newly noted or occurring in the setting of an acute presentation, such as acute coronary syndrome or ingestion, then these two forms of AV block should be considered as potential warning of the development of more serious forms of AV block. Second­degree Mobitz type II and third­degree AV blocks are always abnormal with frequent hemodynamic compromise.

AV blocks are divided into nodal and infranodal blocks because of the clinical significance and prognostic differences. Nodal AV block (block within the AV node) is usually due to reversible depression of conduction, is often self­limited, and generally has a stable infranodal escape pacemaker pacing the ventricles. Infranodal blocks (block below the AV node) usually are due to organic disease of the His bundle or bundle branches; often the damage is irreversible. They generally have a slow and unstable ventricular escape rhythm pacing the ventricles, and they frequently have a bad prognosis.
FIRST­DEGREE ATRIOVENTRICULAR BLOCK
DESCRIPTION
In first­degree AV block, each atrial impulse is conducted to the ventricles but less rapidly than normal, as noted by a prolonged PR interval, greater than 200 milliseconds. There is a P wave for each QRS complex; this association is consistent from one beat to the next (Figure 18­14 and Table 18­
17). The AV node is usually the site of conduction delay, although this block may occur at an infranodal level.
FIGURE 18­14. Sinus rhythm with first­degree atrioventricular block (PR interval, 300 milliseconds).
TABLE 18­17
ECG Features of First­Degree Atrioventricular Block
Consistent P wave to QRS complex relationship
Prolongation of PR interval >200 ms
CLINICAL SIGNIFICANCE
First­degree AV block occasionally is found in normal hearts. Other common causes include increased vagal tone of any cause, medication toxicity, inferior myocardial infarction, and myocarditis. Patients with first­degree AV block without evidence of organic heart disease appear to have no difference in mortality compared with matched controls. In the setting of an acute coronary syndrome event, its appearance can indicate an increased chance of progression to complete heart block.
SECOND­DEGREE MOBITZ TYPE I (WENCKEBACH’S) ATRIOVENTRICULAR BLOCK
DESCRIPTION
In second­degree Mobitz type I (Wenckebach’s) block, there is progressive prolongation of AV conduction (and the PR interval) until an atrial impulse is completely blocked; when an atrial impulse is blocked, no accompanying QRS complex is seen (Figure 18­15 and Table 18­18). Conduction ratios indicate the ratio of atrial to ventricular depolarizations; for instance, a 4:3 ratio indicates that three of four atrial impulses are conducted into the ventricles. Usually, only one atrial impulse is blocked. After the dropped beat, the AV conduction returns to normal, and the cycle usually repeats itself with the same conduction ratio (fixed ratio) or a different conduction ratio (variable ratio). This type of block almost always occurs at the level of the AV node and is often due to reversible depression of AV nodal conduction.
FIGURE 18­15. Second­degree, type I atrioventricular block. Note the nonconducted P waves (arrows).
TABLE 18­18
ECG Features of Second­Degree Mobitz Type I (Wenckebach’s) Atrioventricular Block
Progressive prolongation of PR interval until an atrial impulse is completely blocked: a P wave without accompanying QRS complex
After the nonconducted beat, cycle repeats
Grouped beating
Second­degree type I, or Wenckebach’s, block occurs because each successive depolarization produces prolongation of the refractory period of the AV node. When the next atrial impulse comes upon the node, it is earlier in the relative refractory period, and conduction occurs more slowly relative to the previous stimulus. This process is progressive until an atrial impulse reaches the AV node during the absolute refractory period, and conduction is blocked altogether (Figure 18­16A). The pause allows the AV node to recover, and the cycle repeats. This cyclic occurrence produces a pattern of
“grouped beating” and is apparent over successive cycles (Figure 18­16B).
FIGURE 18­16. A. Second­degree, type I atrioventricular block. B. The cardiac rhythm strip illustrates the concept of grouped beating, or clustering of QRS complexes indicated by the ovals in the rhythm strip.
CLINICAL SIGNIFICANCE
This block is often transient and usually associated with inferior myocardial ischemia, medication toxicity, or myocarditis, or after cardiac surgery. It may occur when a normal AV node is exposed to very rapid atrial rates. This block can also be a normal variant, not indicative of acute or chronic heart disease. Specific treatment is usually not necessary unless very slow ventricular rates produce signs of hypoperfusion, where most patients will respond to atropine.
SECOND­DEGREE MOBITZ TYPE II ATRIOVENTRICULAR BLOCK
DESCRIPTION
In second­degree Mobitz type II block, the PR interval remains constant across the rhythm strip, both before and after the nonconducted atrial beats
(Figure 18­17 and Table 18­19). Each P wave is associated with a QRS complex until a nonconducted atrial depolarization (i.e., P wave) is noted without accompanying QRS complex. Mobitz II blocks usually occur in the infranodal conducting system, often with coexistent fascicular or bundle branch blocks, and the QRS complexes therefore are usually wide. High­grade AV block is noted when more than one consecutive P wave is not conducted (Figure 18­17C).
FIGURE 18­17. Three examples of second­degree, type II atrioventricular (AV) block: (A) with narrow QRS complex rhythm; (B) with wide QRS complex rhythm; and (C) with wide QRS complex rhythm and high­grade AV block indicated by two or more consecutive nonconducted P waves (arrows).
TABLE 18­19
ECG Features of Second­Degree Mobitz Type II Atrioventricular Block (AVB)
PR interval remains constant.
Each P wave is associated with a QRS complex until a nonconducted atrial depolarization (i.e., P wave) is noted without accompanying QRS complex.
QRS complexes are usually widened, although a narrow complex is occasionally seen.
High­grade AVB is noted when more than one consecutive P wave is not conducted.
When second­degree AV block occurs with a fixed conduction ratio of 2:1, it is not possible to differentiate between type I (Wenckebach’s) and type II block. If the QRS complex is wide, the block is more likely to be in the infranodal system. If the QRS complex is narrow, then the block is in the AV node or infranodal system with about equal incidence; it is recommended that the “worst case scenario” be assumed in such presentations and to consider the “untypeable” second­degree AV block a type II blockage.
CLINICAL SIGNIFICANCE
Type II blocks imply structural damage to the infranodal conducting system, are usually permanent, and may progress suddenly to complete heart block, notably with concomitant acute myocardial ischemia. Patients should have transcutaneous cardiac pacing pads applied in the ED in anticipation of possible need. Start emergent pacing when slow ventricular rates produce symptoms of hypoperfusion. Atropine can be tried, but the effect is
,3 inconsistent. Most patients, especially in the setting of acute myocardial ischemia, will require eventual transvenous cardiac pacing.
THIRD­DEGREE ATRIOVENTRICULAR BLOCK (COMPLETE HEART BLOCK)
DESCRIPTION
In third­degree AV block, there is no AV conduction (Figure 18­18 and Table 18­20). An escape pacemaker (manifested by the QRS complex) paces the ventricles at a rate slower than the atrial rate manifested by the P wave. When third­degree AV block occurs in the AV node, a junctional escape pacemaker takes over with a ventricular rate of  to  beats/min. The QRS complexes are narrow because the rhythm originates above the bifurcation of the bundle of His. When third­degree AV block occurs at the infranodal level, the ventricles are driven by a ventricular escape rhythm at a rate slower than  beats/min. Third­degree AV blocks at the His bundle level can have a narrow or wide QRS complex, whereas blocks in the bundle branches or elsewhere in the Purkinje system invariably have escape rhythms with wide QRS complexes.
FIGURE 18­18. Two examples of third­degree atrioventricular block. Both have an atrial rate of  with ventricular escape rate of . Not all P waves are visible; some are hidden by the QRS complex or T wave.
TABLE 18­20
ECG Features of Third­Degree Atrioventricular Block (Complete Heart Block)
No association of P wave with QRS complexes
Atrial rate greater than ventricular rate
QRS complexes are usually widened; occasional narrow QRS complexes are seen
Ventricular rate is regular
CLINICAL SIGNIFICANCE
Nodal third­degree AV block (i.e., with a narrow QRS complex) develops in up to 8% of inferior acute myocardial infarction patients and may last for several days. Infranodal third­degree AV blocks (i.e., with a wide QRS complex) indicate structural damage to the infranodal conducting system, as seen with an extensive anterior acute myocardial infarction. The ventricular escape pacemaker is usually inadequate to maintain cardiac output and the patient is unstable, with periods of ventricular asystole. When third­degree block is seen in acute myocardial infarction, mortality is increased, even with pacing.
Infrequently, patients with complete heart block will present with minimal to no symptomatology; these patients require monitoring and admission.
Manage the symptomatic patient with either medication and/or pacing. Nodal blocks may respond to atropine; infranodal blocks are unlikely to respond to atropine or other medications that can enhance AV nodal conduction. Patients should have transcutaneous cardiac pacer pads applied in the ED. If there is no or incomplete response to atropine, use transcutaneous cardiac pacing, recognizing that transvenous pacing is eventually necessary in most patients.
WIDE­COMPLEX TACHYCARDIAS
Wide­complex tachycardias are defined as a rhythm with a QRS complex duration greater than 100 milliseconds and a rate over 100 beats/min. Both
 ventricular tachycardia and supraventricular tachycardia with aberrant ventricular conduction present with wide QRS complexes (Figure 18­19).
FIGURE 18­19. Wide­complex tachycardias. A. Ventricular tachycardia (monomorphic). B. Ventricular tachycardia (polymorphic). C. Sinus tachycardia with bundle branch block. D. Atrial fibrillation with preexisting bundle branch block. E. Preexcited atrial fibrillation in the Wolff­Parkinson­White syndrome. F.
Atrioventricular reentrant tachycardia in the Wolff­Parkinson­White syndrome. G. Paroxysmal supraventricular tachycardia with rate­related bundle branch block in an infant. H. Paroxysmal supraventricular tachycardia with fixed (preexisting) bundle branch block. I. Sodium channel–blocker toxicity with wide­complex tachycardia. J. Wide­complex tachycardia in patient with severe hyperkalemia.
Traditional teaching, derived largely from coronary care units and electrophysiology laboratories, presents that 80% of wide­complex tachycardias are
 ventricular tachycardia. However, in the ED, there is a range of pathophysiologic conditions that can produce delayed ventricular depolarization that,
 when combined with a sinus tachycardia induced by acute illness, results in a wide­complex tachycardia. The conduction abnormality can be the result of a bundle branch block (new­onset, preexisting, or rate­related), metabolic abnormality (e.g., hyperkalemia), adverse medication effect (e.g., sodium channel blockade), or ventricular preexcitation syndrome. All supraventricular tachycardias can present as a wide­complex rhythms if intraventricular conduction is abnormal. In addition, two tachycardias seen in WPW syndrome will present with a widened QRS complex: the antidromic version of the AV nodal reentrant tachycardia and atrial fibrillation or flutter with ventricular depolarization predominantly or exclusively via the accessory tract.
VENTRICULAR TACHYCARDIA
DESCRIPTION
Ventricular tachycardia is the occurrence of three or more consecutive depolarizations from a ventricular ectopic pacemaker at a rate faster than 100
  beats/min. Ventricular tachycardia can occur in a nonsustained manner, with short episodes, lasting several beats, with spontaneous termination,
 or it can occur in a sustained fashion, with longer episodes that typically require treatment. Ventricular tachycardia can be further characterized according to hemodynamic effect (stable vs. unstable), morphology (monomorphic vs. polymorphic), or clinical presentation (perfusing vs. pulseless as during cardiac arrest).
The ECG features (Figure 18­20 and Table 18­21) vary between the monomorphic and polymorphic varieties. Monomorphic ventricular tachycardia is the most commonly encountered form of ventricular tachycardia, accounting for about 70% of cases, and is usually very regular with rates most often in the 140 to 180 beats/min range. Medications, such as amiodarone, may slow the rate of ventricular tachycardia; such patients may present with ventricular rates of 110 to 130 beats/min. On rare occasions, monomorphic ventricular tachycardia may present with an irregular rhythm, but only minimally irregular as compared to an aberrantly conducted atrial fibrillation, which ordinarily manifests marked irregularity.
FIGURE 18­20. Three examples of monomorphic ventricular tachycardia. A. Ventricular tachycardia with a rate of 270 beats/min. B. Ventricular tachycardia with a rate of 220 beats/min. C. Ventricular tachycardia with a rate of 180 beats/min.
TABLE 18­21
ECG Features of Monomorphic and Polymorphic Ventricular Tachycardia
Monomorphic
No P waves associated with QRS complex, occasional dissociated P wave
Rapid and regular rhythm
Rate usually 140–180 beats/min (range, 120–300 beats/min)
Widened QRS complex >100–120 ms with consistent beat­to­beat morphology
Polymorphic
No P waves associated with QRS complex; may have occasional dissociated P wave
Rapid and irregular rhythm
Rate 140–180 beats/min (range, 120–300 beats/min)
Widened QRS complex >100–120 ms with inconsistent beat­to­beat morphology
Polymorphic ventricular tachycardia has varying QRS morphology in any single ECG lead (Figure 18­21 and Table 18­21). Variations in both the RR interval and electrical axis are also features of this form of ventricular tachycardia. Torsades de pointes, a specific subtype of polymorphic ventricular
 tachycardia, occurs in the setting of delayed myocardial repolarization manifested on the sinus rhythm ECG by a prolongation of the QT interval. The
French term torsades de pointes means “twisting of the points” and describes the appearance of the QRS complex as it varies in appearance (Figure
18­21B).
FIGURE 18­21. Two examples of polymorphic ventricular tachycardia. A. Polymorphic ventricular tachycardia. B. Polymorphic ventricular tachycardia of the torsades de pointes subtype, with the characteristic pattern of progressively changing QRS complex amplitude and direction.

## Page 32

CLINICAL SIGNIFICANCE

Ventricular tachycardia is rare in patients without underlying heart disease. The most common causes of ventricular tachycardia are chronic ischemic heart disease and acute myocardial infarction, composing about 50% of all cases of symptomatic ventricular tachycardia. Less common causes of ventricular tachycardia include dilated or hypertrophic cardiomyopathy, valvular heart disease (including mitral valve prolapse), inherited ion channel abnormalities, and drug toxicity. Hypoxia, alkalosis, and electrolyte abnormalities, especially hyperkalemia, exacerbate the propensity for ventricular ectopy and tachycardia.
Torsades de pointes occurs when repolarization is delayed, and cardiac afterpotentials can initiate this form of polymorphic ventricular tachycardia.

Delayed repolarization is seen in inherited (congenital long QT syndrome) and acquired (primarily drug toxicity) circumstances. Torsades de pointes often occurs in bursts of up to  cycles before spontaneously stopping. Sustained torsades de pointes is uncommon and can potentially degenerate into ventricular fibrillation.
It is a misconception that patients with ventricular tachycardia are clinically unstable. Ventricular tachycardia cannot be reliably differentiated from supraventricular tachycardia with aberrant conduction on the basis of clinical symptoms or vital signs. Differentiation using the 12­ lead ECG can be challenging and, at times, impossible (see discussion in next section).
TREATMENT
The management of ventricular tachycardia is based on the patient’s clinical stability. The most extreme form of instability is cardiac arrest; these patients should receive prompt electrical defibrillation, chest compressions, and other advanced life support measures. Patients with a pulse but compromised by the ventricular tachycardia should undergo electrical cardioversion, coupled with administration of a procedural analgesia and
 sedation if clinical status allows. In the stable patient, pharmacologic agents are first­line therapy.

Hemodynamically stable patients with ventricular tachycardia are treated with procainamide, amiodarone, lidocaine, or magnesium. Procainamide is
,17 superior to amiodarone or lidocaine for converting patients with stable ventricular tachycardia. The primary disadvantage of procainamide is the relatively slow dosing because rapid infusions can cause hypotension. If the patient deteriorates during pharmacologic treatment, proceed to
University of Pittsburgh electrical synchronized cardioversion, airway management, and sedation, if possible. Obtain a cardiology consult in stable patients with ventricular
Access Provided by: tachycardia refractory to standard pharmacologic therapy because unusual forms of this dysrhythmia may require electrophysiologic evaluation and
 treatment.
Magnesium is primarily used as an antiarrhythmic agent in patients with known hypomagnesemia, QT interval prolongation, polymorphic ventricular
 tachycardia, or torsades de pointes. Case reports describe the benefits of isoproterenol or phenytoin in torsades de pointes, but controlled studies
71–73 are lacking. Definitive treatment of torsades de pointes is ventricular pacing at a rate necessary to prevent the bursts of polymorphous ventricular tachycardia. Pacing is continued until the cause of QT prolongation (drug toxicity, electrolyte abnormality) is ameliorated.
UNDIFFERENTIATED WIDE­COMPLEX TACHYCARDIA
DESCRIPTION
A regular, wide­complex tachycardia can be either of ventricular origin (ventricular tachycardia) or due to a supraventricular tachycardia with aberrant
 conduction of the electrical impulse through the ventricles. While the differentiation between ectopic beats of ventricular origin and those of aberrantly conducted supraventricular origin can be difficult, it is more so in sustained tachycardias with wide QRS complexes.
CLINICAL FEATURES
Traditional teaching emphasizes five ECG features as helpful in differentiating ventricular tachycardia from supraventricular tachycardia with aberrant conduction: irregularity, AV dissociation, fusion and capture beats, QRS duration, and QRS complex concordance, both negative and positive (Figure
,7
18­22). Ventricular tachycardia is usually very regular; and if irregular, the degree of irregularity is minimal (see Figures 18­20B and 18­22C). Marked irregularity is strongly suggestive of atrial fibrillation with bundle branch block; of course, torsades de pointes is also irregular, but the changing polarity of the QRS complex is usually quite apparent.
FIGURE 18­22. ECG considerations in the distinction of supraventricular tachycardia with aberrant ventricular conduction from ventricular tachycardia. A. Irregular rhythm in Wolff­Parkinson­White–related atrial fibrillation. B. Regular rhythm in ventricular tachycardia. C. Atrioventricular dissociation in ventricular tachycardia. The arrows indicate P waves, indicative of atrioventricular dissociation, which is strongly suggestive of ventricular tachycardia. D. Capture
(large arrow) and fusion (small arrow) beats that are indicative of ventricular tachycardia.
AV dissociation, where the atria and ventricles have separate independent pacemakers (Figure 18­22C), if noted, is strongly suggestive of ventricular tachycardia. In cases of ventricular tachycardia without retrograde conduction to the atria, the SA node continues to initiate atrial depolarization.
Because atrial depolarization is completely independent of ventricular activity, the resulting P waves will be dissociated from the QRS complexes. AV dissociation is not common; it is noted in only approximately 10% of ventricular tachycardia patients.
Capture and fusion beats (Figure 18­22D) are potentially useful and suggest ventricular tachycardia. In the patient with ventricular tachycardia, an independent atrial impulse may occasionally cause ventricular depolarization via the normal conducting system; such a supraventricular impulse, if
 cCohnadputectr e1d8 a: nCda ardbilaec t oR htryigthgmer Da idsetuproblaanriczeasti,o Wn iwlliiathmin J t. hBer avdeny;t rGiceleo,r wgeil lF r.e Gsulalts isn IaII different QRS complex morphology—different than the oPtahgeer 3w2id / e54
Q©R2S0 2c5o mMpclGexra bwe aHtsil.l .I fA tlhl eR rigehsutslt Rinegs QeRrvSe cdo. m Tpelerxm osc ocfu Urss eea * r lPierri vtahcayn Pexoplieccyt e * dN aontidc eis * n Aarcrcoews,s tihbeil ictyomplex is called a capture beat; the supraventricular impulse electrically captures the ventricle, producing a narrow complex. The presence of capture beats strongly supports a diagnosis of ventricular tachycardia. Fusion beats occur when a sinus beat conducts to the ventricles via the AV node and joins, or fuses, with a ventricular beat originating from the abnormal ectopic focus. These two electrical “beats” combine, resulting in a QRS complex of intermediate width and differing morphology when compared to the other beats of ventricular tachycardia. As with capture beats, the presence of fusion beats is strongly suggestive of ventricular tachycardia. Fusion and capture beats occur infrequently and are seen in fewer than 10% of patients with ventricular tachycardia.
Ventricular tachycardia usually has a wider QRS complex than does supraventricular tachycardia with aberrancy, so extreme QRS durations >160 milliseconds argue in favor of ventricular tachycardia. Concordance describes that the polarity of the QRS complexes is consistent across the precordium, either all negative or positive from leads V to V . Negative concordance, with all the precordial QRS complexes having a negative or
  downward deflection, suggests ventricular tachycardia.
In addition to these traditional characteristics, algorithms using ECG features have been created to assist in the differentiation of ventricular
74–78 tachycardia versus supraventricular tachycardia with aberrancy (Table 18­22). The algorithmic approach varies: the Brugada, Griffith, and Lau approaches use multiple leads and criteria; the Vereckei algorithm uses only lead aVR, although with four criteria; and the Pava algorithm uses only lead II and only one criterion. The Griffith approach is reversed from the other four; it assumes that the wide­complex tachycardia is ventricular in origin and then looks for evidence that favors supraventricular with aberrancy. Published comparisons are mixed regarding the sensitivity and
79–83 specificity of these different algorithms, and neither has proven consistently superior. Simplicity favors the Vereckei or Pava approaches.
TABLE 18­22
Methods for Wide­Complex Tachycardia Differentiation
Author and Favors Ventricular Tachycardia (VT) Favors Supraventricular Tachycardia with Aberrant Conduction (SVTAC)
Year
Brugada, VT diagnosed if, analyzed in sequence, any  of these  SVTAC diagnosed if no to all  criteria for VT
199174 criteria is present:
Absence of RS complexes in all precordial leads
R to S interval >100 ms in one or more precordial leads
AV dissociation
Morphologic criteria for VT in leads V and V (V :
   monophasic R, qR, QS, or RS; and V : rS, QS, qR, or

S > R)
Griffith, VT diagnosed if no to either criteria for SVTAC SVTAC diagnosed if both criteria are present:
199475 QRS morphology classic for bundle branch block: LBBB (rS or QS in leads V
 and V ; time to S wave nadir in lead V or V >70 ms; R wave and no Q wave in

V ) or RBBB (rSR’ in lead V ; RS in lead V ; R wave larger than S wave in V )

No atrioventricular dissociation is seen
Lau, Bayesian analysis starting with pretest odds for VT SVTAC diagnosed if posttest odds <0.33
200076 then multiply by likelihood ratio for VT associated with each of these factors:
QRS duration
QRS frontal plane axis
V morphology with a RBBB pattern

V and V morphology with an LBBB pattern

Interval of initial R­wave deflection in V

V morphology

VT diagnosed if posttest odds >3
Vereckei, VT diagnosed if, analyzed in sequence, any of these  SVTAC diagnosed if none of the  criteria for VT are present
200877 criteria are present in lead aVR:
Initial R wave
Initial r or q wave >40 ms
Notch present on the initial descending limb of a predominantly negative QRS
Slow conduction at beginning of QRS: ratio of vertical distance traveled in voltage during the initial  ms (v) and terminal  ms (v ); ratio of i t v /v <1 i t
Pava, VT diagnosed if time from isoelectric to peak of R wave SVTAC diagnosed if not
201078 in lead II is >50 ms
Abbreviations: LBBB = left bundle branch block; RBBB = right bundle branch block.
TREATMENT
Before treating the patient, consider if the undifferentiated wide­complex tachycardia is due to either hyperkalemia or sodium channel blockade producing the widened QRS complex; both situations require specific therapy.
If the patient is hemodynamically unstable, assume the symptomatic wide­complex tachycardia is ventricular in origin and treat accordingly. In stable patients, response to adenosine has been described as helpful in differentiating ventricular from supraventricular wide­complex tachycardias, but rare
 forms of ventricular tachycardia can be responsive to adenosine, potentially missing the diagnosis because of conversion to sinus rhythm. Not all wide­complex tachycardias require antiarrhythmic agents or urgent electrical therapy; consultation with a cardiologist for stable patients with unclear diagnosis is recommended.
VENTRICULAR FIBRILLATION
DESCRIPTION
Ventricular fibrillation is disorganized depolarization and chaotic contraction of small areas of ventricular myocardium absent any effective mechanical cardiac activity; there is no cardiac output. The ECG of ventricular fibrillation shows a fine, irregular pattern without discernible P waves or organized QRS complexes. The irregular pattern itself can be coarse, intermediate, or fine in amplitude (Figure 18­23).
FIGURE 18­23. Three examples of ventricular fibrillation. A.Fine amplitude. B. Coarse amplitude. C. Coarse amplitude mimicking ventricular tachycardia.
CLINICAL SIGNIFICANCE
Ventricular fibrillation is seen most commonly in patients with severe ischemic heart disease, with or without an acute myocardial infarction. Primary ventricular fibrillation occurs suddenly and without preceding hemodynamic deterioration, whereas secondary ventricular fibrillation occurs after a prolonged period of left ventricular failure and/or circulatory shock. In addition, direct stimulation of the myocardium by catheters or other instruments, electrocution, and direct blunt chest trauma (also known as commotio cordis) can induce ventricular fibrillation.
Treatment of pulseless ventricular tachycardia or fibrillation is with electrical defibrillation along with chest compressions and other advanced life support measures. If resuscitation is successful at restoring spontaneous circulation, address any dysrhythmic triggers including acute ischemia,
 metabolic derangements, or toxicologic insult.
CONDUCTION AND REPOLARIZATION ABNORMALITIES
Inherited or acquired abnormalities in myocardial conduction or repolarization can provide the substrate for cardiac dysrhythmias.
WOLFF­PARKINSON­WHITE SYNDROME
DESCRIPTION
WPW syndrome is a form of ventricular preexcitation involving an accessory conduction pathway that bypasses the AV node and creates a direct
,86 electrical connection between the atria and ventricles. WPW patients are prone to a variety of supraventricular tachydysrhythmias (Table 18­23).
Ventricular fibrillation is rare in the WPW patient and often the result of therapeutic misadventure.
TABLE 18­23
Dysrhythmias Seen in Symptomatic Wolff­Parkinson­White Syndrome
Atrioventricular reciprocating tachycardia (AVRT)
Narrow QRS complex tachycardia (orthodromic AVRT)—65%
No P wave
Narrow QRS complexes
No delta wave
Rapid and regular
Ventricular rates ranging from 160–220 beats/min
Difficult to distinguish from paroxysmal supraventricular tachycardia
Wide QRS complex tachycardia (antidromic AVRT)—5%–10%
No P wave
Widened QRS complexes with consistent QRS complex morphology
Rapid and regular
Ventricular rates ranging from 160–220 beats/min
Difficult to distinguish from ventricular tachycardia
Atrial fibrillation—25%
No P wave
Widened QRS complexes with varying, bizarre QRS complex morphologies
Delta wave
Rapid and irregular
Ventricular rates usually >200 beats/min
CLINICAL FEATURES
The classic triad of ECG findings (Table 18­24 and Figure 18­24) seen in WPW is visible during sinus rhythm and is usually not detectable during tachydysrhythmias. The PR interval is shortened in sinus rhythm because the impulse moving through the accessory pathway is not subject to the physiologic slowing within the AV node. The ventricle is activated by two separate pathways, resulting in a fused, or slightly widened, QRS complex. The initial part of the complex, the delta wave, represents aberrant activation through the accessory pathway, while the terminal portion of the QRS complex represents normal activation through the His­Purkinje system from impulses traveling through the AV node. Due to altered ventricular depolarization, secondary repolarization changes are reflected in altered ST segments and T waves that are generally directed opposite (discordant) to the major delta wave and QRS complex. The delta wave may create Q waves that can mimic ECG changes associated with ischemic heart disease.
TABLE 18­24
The ECG Triad of Wolff­Parkinson­White Syndrome During Sinus Rhythm
PR interval <120 ms
Slurring of the initial QRS complex, known as a delta wave
Slightly widened QRS complex
FIGURE 18­24. A. A 12­lead ECG of a patient with the Wolff­Parkinson­White (WPW) syndrome in sinus rhythm. B and C. Single P­QRS­T complex; note the shortened
PR interval, delta wave, and widened QRS complex. D. The direction of cardiac impulse conduction in the WPW syndrome patient in sinus rhythm. The two arrows indicate the direction of the impulse, moving from atrial (A) tissues to ventricular (V) tissues via the accessory pathway (AP) and atrioventricular node (AVN). The impulse arrives at the ventricular tissues via the AVN and moves through ventricular tissues via the right bundle branch (RBB) and left bundle branch (LBB); the impulse also arrives at ventricular tissues via the AP and moves through ventricular tissues using cellto­cell conduction. SAN = sinoatrial node.
An incidental ECG may identify WPW in an otherwise asymptomatic individual. While such asymptomatic individuals will never develop
 tachydysrhythmias, a portion of patients do, and some rare patients experience ventricular fibrillation and cardiac arrest. Electrophysiologic studies can identify patients with multiple accessory tracts and short refractory periods in those tracts and, thus, who are at increased risk for ventricular
 fibrillation and cardiac arrest.
The most frequent dysrhythmia seen in the WPW patient is a reentrant tachycardia termed AV reciprocating tachycardia. In AV reciprocating tachycardia, the reentry circuit involves the AV node and the accessory pathway. AV reciprocating tachycardia is either orthodromic (anterograde conduction through the AV node with narrow QRS complex) or antidromic (retrograde conduction through the AV node with widened QRS complex).
During orthodromic or anterograde AV reciprocating tachycardia (Table 18­23 and Figure 18­25), the atrial stimulus is conducted to the ventricle through the AV node with a return of the impulse back to the atria through the accessory pathway. Since the ventricles are stimulated solely via the normal His­Purkinje system, the QRS complexes are narrow and there is no delta wave. Orthodromic AV reciprocating tachycardia accounts for approximately 65% of dysrhythmias seen in WPW patients and is difficult to distinguish from AV nodal reentrant tachycardia (i.e., typical paroxysmal supraventricular tachycardia).
FIGURE 18­25. Narrow­complex tachycardia (orthodromic atrioventricular [AV] reciprocating tachycardia [AVRT]), the most common dysrhythmia of the Wolff­
Parkinson­White syndrome. A and B. Rapid, regular, narrow QRS complexes without delta waves. C. The direction of cardiac impulse conduction in orthodromic AVRT; anterograde from atrial (A) tissues to ventricular (V) tissues through the AV node (AVN) and returning to the atrial tissues from ventricular tissues via the accessory pathway (AP). D. A 12­lead ECG demonstrating orthodromic AVRT. AP = accessory pathway; LBB = left bundle branch; RBB = right bundle branch; SAN = sinoatrial node.
In approximately 5% to 10% of symptomatic WPW patients, an antidromic (retrograde) AV reciprocating tachycardia occurs (Table 18­23 and Figure
18­26). In antidromic AV reciprocating tachycardia, the reentrant circuit conducts in the opposite direction, with anterograde conduction down the accessory pathway and return of the impulse retrograde to the atria via the AV node. With this pathway, the QRS complexes are wide; the ECG displays a very rapid, wide­complex tachycardia that looks like ventricular tachycardia.
FIGURE 18­26. Antidromic atrioventricular (AV) reciprocating tachycardia (AVRT; wide­complex tachycardia). A. Wide­complex tachycardia that mimics ventricular tachycardia. B. The direction of cardiac impulse conduction in a Wolff­Parkinson­White syndrome patient during antidromic AVRT. The two arrows indicate the direction of the impulse movement, anterograde from atrial (A) tissues to ventricular (V) tissues through the accessory pathway (AP) and returning to the atrial tissues from ventricular tissues via the AV node (AVN). LBB = left bundle branch; RBB = right bundle branch; SAN = sinoatrial node.
Atrial fibrillation occurs in up to 25% of WPW patients with symptomatic dysrhythmias. The ECG features (Table 18­23 and Figure 18­27) of atrial fibrillation with WPW syndrome are a very fast ventricular rate due to the ability of the accessory pathway to conduct impulses into the ventricle faster than through the AV node and significant beat­to­beat variation in the QRS complex morphology resulting from a combination of the two impulses arriving at the ventricle and fusing to form a composite depolarization. This wide­complex dysrhythmia may appear relatively regular and can be
 misdiagnosed as ventricular tachycardia.
FIGURE 18­27. Atrial fibrillation in Wolff­Parkinson­White (WPW) syndrome. A, B, and D. Rapid, wide, irregular QRS complex tachycardia with varying QRS complex morphologies. C. The direction of cardiac impulse conduction in a WPW syndrome patient during atrial fibrillation. The two arrows indicate the direction of the impulse movement, both anterograde from atrial (A) tissues to ventricular (V) tissues through both the accessory pathway (AP) and the atrioventricular node (AVN). The larger of the two arrows indicates that the majority of impulses travel to the ventricular via the AP. E. A 12­lead ECG demonstrating a rapid, wide, irregular QRS complex tachycardia with varying QRS complex morphologies. LBB = left bundle branch; RBB = right bundle branch; SAN = sinoatrial node.
TREATMENT
Treat all three tachydysrhythmias in the WPW patient according to the patient’s clinical stability and the ECG features of the dysrhythmia. Use electrical cardioversion in patients with hemodynamic instability.
In the stable patient, therapy is guided by the QRS complex width and the regularity of the rhythm. In patients with a regular, narrow QRS complex tachycardia (i.e., orthodromic AV reciprocating tachycardia), the first intervention is vagal maneuver (Table 18­3). If this intervention fails, the next step would be IV adenosine (Table 18­2). If adenosine fails, then longer­acting AV nodal blocking agents, such as β­blockers and calcium channel blockers, are indicated. In refractory cases, procainamide is an effective agent that blocks conduction in the accessory conduction pathway and can terminate this reentrant tachycardia. If all medications are unsuccessful, the patient can be electrically cardioverted with appropriate sedation.
In stable patients with a wide QRS complex tachycardia, either regular (i.e., antidromic AV reciprocating tachycardia) or irregular (atrial fibrillation),
 procainamide should be administered. If unsuccessful, electrical cardioversion with appropriate sedation should be considered. Some antiarrhythmic medications can paradoxically enhance condition via the accessory tract, potentially enabling excessively rapid atrial activity to trigger ventricular fibrillation. Also, by blocking conduction through the AV node in WPW patients with atrial fibrillation, more of the rapid atrial depolarizations are able to initiate ventricular depolarization because competition from the normal conducting pathway is impaired, although
 evidence of adverse clinical outcome by such action is weak. Agents that can enhance conduction in the accessory tract and/or block conduction in the AV node should be avoided in WPW patients with wide­complex, both regular and irregular tachycardias; these
 include adenosine, amiodarone, β­blockers, and calcium channel blockers.
After conversion, observe the patient with continuous cardiac rhythm monitoring and a repeat ECG. In general, patients who have rare episodes of tachydysrhythmias and who are stable after conversion can be discharged home with routine follow­up. Patients with frequent tachydysrhythmia episodes or who have an episode of atrial fibrillation with a very rapid ventricular response should be promptly referred for ablation of the accessory pathway. Patients who experience loss of consciousness during a known or possible tachydysrhythmia should be kept for observation due to the potential for repeat episode or cardiac arrest. Asymptomatic patients in whom WPW appears as an incidental finding should be referred to a
 cardiologist for further evaluation.
BRUGADA SYNDROME
DESCRIPTION
Brugada syndrome is an inherited disorder of myocardial depolarization that predisposes young individuals to malignant ventricular dysrhythmias
93–96 and sudden death. Congenital Brugada syndrome is due to mutations in the genes responsible for transmembrane sodium, calcium, or potassium
  ion channels in the heart. Eight genetic mutations have been identified as producing a channelopathy that results in the Brugada syndrome.
Brugada syndrome occurs predominantly in males, and its prevalence varies dramatically among different ethnic groups; it is highest in East and
Southeast Asian populations, relatively lower in groups originating from Western Europe, and less common in the Americas.
CLINICAL FEATURES
The majority of patients with Brugada syndrome are asymptomatic and are only found via an incidental ECG. Symptomatic patients present with
 palpitations, near to complete syncope, or seizures due to cerebral ischemia resulting from ventricular tachydysrhythmias. Characteristic ECG
 changes are necessary for the diagnosis, but such changes are variable and not always evident (Table 18­25 and Figure 18­28). Fever and provocative testing with a sodium channel blocker (e.g., flecainide) may provoke surface ECG abnormalities associated with Brugada syndrome. The type  pattern is considered diagnostic when combined with appropriate clinical or family history (Table 18­26). Type  is considered suggestive but not diagnostic of Brugada syndrome. Because type  may convert to type , either spontaneously or with provocative testing, further evaluation is recommended if there is an appropriate history.
TABLE 18­25
ECG Patterns Associated With Brugada Syndrome in ECG Leads V to V

Type  Coved­shaped ST­segment elevation >2 mm
Followed by an inverted T wave
Type  ST­segment elevation >2 mm
With a trough in the ST segment at least  mm deep
Followed by a positive or biphasic T wave
Producing a “saddleback” pattern
FIGURE 18­28. Brugada ECG pattern. A. Type . B. Type . TABLE 18­26
Risk Stratification in Brugada Syndrome
Personal history Near or complete syncope
Seizure
Nocturnal agonal respiration
Aborted sudden cardiac death Polymorphous ventricular tachycardia
Ventricular fibrillation
Family history Family history of unexplained sudden cardiac death
Family history of coved­shaped ST segment (type 1) ECG pattern
Electrophysiologic study Inducibility of ventricular tachycardia or fibrillation with programmed stimulation
100,101
Risk stratification is done to identify patients with Brugada syndrome at significant risk for malignant ventricular tachydysrhythmias. In patients with aborted sudden cardiac death, the risk of recurrence of ventricular fibrillation is over 50% within  years.
TREATMENT
An important role for the emergency provider is to recognize this ECG pattern, especially in patients who present with symptoms, and to refer for
102 appropriate follow­up. Avoid exacerbating the underlying pathophysiology; do not use medications that possess sodium channel–blockade effects
(http://www.brugadadrugs.org). Educate the patient on the importance of treating fever, with even minor infections. The only proven therapy to
 terminate malignant ventricular dysrhythmias and prevent sudden death is implantable cardioverter­defibrillator placement. Quinidine, a class Ia antiarrhythmic, is sometimes used as an adjunct with implantable cardioverter­defibrillator placement to reduce the incidence of dysrhythmias. Side effects (hepatitis, thrombocytopenia, and diarrhea) and the potential to induce torsades de pointes are cautions to quinidine’s routine use.
LONG QT SYNDROME
DESCRIPTION
The long QT syndromes are characterized by prolongation of the QT interval (Figure 18­29) and a predisposition to ventricular tachydysrhythmias,
103–106 including torsades de pointes and sudden cardiac death. Congenital long QT syndrome is an inherited disorder due to mutations in cation
 channel genes (channelopathies). Of the  described variants of congenital long QT syndrome, the three most common, accounting for about 90% of all cases, are mutations in a cardiac potassium channel for long QT syndrome types  and  and the sodium ion channel for long QT syndrome type

. With increased awareness and identification, the prevalence of congenital long QT syndrome is estimated to be  in 2000 live births. Acquired long
QT syndrome can occur from electrolyte abnormalities (hypokalemia, hypomagnesemia), medication effects, and other disease states, such as acute
107,108 coronary syndrome and severe left ventricular dysfunction.
FIGURE 18­29. Long QT interval; QTc is 550 milliseconds.
CLINICAL FEATURES
The normal QT interval corrected for heart rate (QTc) is up to 440 milliseconds in adult males and 460 milliseconds in adult females. The risk of dysrhythmias associated with long QT syndrome increases as the QTc prolongs, with moderate risk between 480 and 499 milliseconds and significantly
 higher risk when the QTc is greater than 500 milliseconds. Syncope is the most common clinical feature and torsades de pointes is the most common dysrhythmia in symptomatic patients. A diagnostic scoring system has been created to assist in identifying patients with congenital long QT syndrome

(Table 18­27).
TABLE 18­27
Diagnostic Score for Congenital Long QT Syndrome
Feature Points
ECG* QTc ≥480 ms 
460–479 ms 
450–459 (male) ms 
QTc ≥480 ms at 4th min of recovery from exercise stress test 
T­wave alternans 
Notched T waves in three ECG leads 
Heart rate < second percentile for age (<50 in adults age 20–60) .5
Clinical History
Syncope or episode of torsades de pointes (not both) Torsades de pointes 
Syncope provoked by stress 
Syncope not provoked by stress 
Congenital deafness .5
Family History
Family members with definite long QT syndrome 
Immediate family member <30 y old with unexplained sudden cardiac death .5
Scoring: Range,  to ; .5 to  points = intermediate probability; ≥3.5 points = high probability
*In absence of medications or conditions known to affect QT interval or T wave.
TREATMENT
An important role for the emergency provider is to recognize this ECG pattern, especially in patients who present with syncope, and to refer for
102,110 appropriate follow­up. Avoid exacerbating the underlying pathophysiology; do not use medications that possess channel blockade effects,
111 impair cardiac repolarization, prolong the QT interval, and provoke tachydysrhythmias (https://crediblemeds.org/healthcare­providers/). Correct underlying electrolyte abnormalities, especially those of potassium and magnesium. β­Blockers are the initial treatment for symptomatic patients with
112 congenital long QT syndrome. Propranolol and nadolol are the most effective β­blockers, and patients with congenital long QT syndrome type  are the most responsive.

Lifestyle modifications are beneficial in congenital long QT syndrome. Exercise is a trigger for lethal dysrhythmic events, especially in patients with congenital long QT syndrome type , where swimming is notably dangerous. Patients with congenital long QT syndrome type  are sensitive to decreased serum potassium and are at risk for lethal cardiac events triggered by emotions or being startled, such as being roughly aroused from rest or sleep.
SHORT QT SYNDROME
DESCRIPTION
114,115
Short QT syndrome is a rare but highly lethal entity associated with an increased risk of ventricular tachydysrhythmias. As with long QT syndrome, short QT syndrome is an inheritable illness with demonstrated autosomal dominant pattern. The syndrome is primarily recognized by a shortened QT interval without any need to adjust for heart rate. Afflicted patients have otherwise structurally and functionally normal hearts.
CLINICAL FEATURES
Patients can be asymptomatic or present with palpitations, lightheadedness, syncope, or cardiac arrest due to ventricular dysrhythmias. The primary
114,115
ECG feature is a shortened QT interval (<360 milliseconds), with QT intervals <340 milliseconds associated with increased risk of sudden death.
Other ECG features include tall, peaked T waves and a shortened J­point to T­wave apex less than 120 ms (the time interval from the J point to the top of the T wave).
A risk stratification tool is available using the following features: QT interval, J­point to T­wave peak, patient history of cardiac events (atrial fibrillation, unexplained syncope, known polymorphic ventricular tachycardia or ventricular fibrillation, and/or sudden cardiac death), family history (close relative with sudden cardiac death, diagnosed syndrome, or sudden infant death syndrome), and identified mutations in one of eight known
,114,115 genes.
TREATMENT
Asymptomatic, incidental discovery should result in cardiology referral. Symptomatic presentation with concerning findings should include cardiology evaluation and/or admission. Current recommendations are that an implanted defibrillator be placed in patients who have had episodes of ventricular
115 tachycardia or fibrillation and be considered in those with a strong family history of sudden cardiac death. Pharmacologic therapy with quinidine is
114,115 recommended in symptomatic individuals and in asymptomatic patients with a strong family history of sudden cardiac death.
ARRHYTHMOGENIC RIGHT VENTRICULAR CARDIOMYOPATHY
DESCRIPTION
Arrhythmogenic right ventricular cardiomyopathy, also known as arrhythmogenic right ventricular dysplasia, is an inherited myocardial disease
116–118 associated with sudden cardiac death. The pathogenesis includes a fibrofatty replacement of right ventricular myocardium. The prevalence of arrhythmogenic right ventricular cardiomyopathy is  in 5000 to ,000 persons; it is more common in men (3:1 male:female ratio) and those with a
Mediterranean heritage. As with the other inherited arrhythmogenic disorders, a family history of unexplained (or explained) sudden cardiac death is present. Patients may also develop subacute to acute right ventricular heart failure, eventually progressing to biventricular failure.
CLINICAL FEATURES
Patients typically present with palpitations and syncope due to ventricular tachycardia, which may be transient or sustained. Other manifestations include circulatory shock, cardiac arrest, and right ventricular failure. ECG features suggestive of arrhythmogenic right ventricular cardiomyopathy include the following: epsilon wave (seen in 30% of patients); T­wave inversions in leads V to V (85% of patients); a prolonged S­wave upstroke (55
  milliseconds) in leads V to V (95% of patients); QRS complex widening (110 milliseconds) seen in leads V to V ; and in patients with ventricular

116,117 dysrhythmia, paroxysmal episodes of ventricular tachycardia with left bundle branch block morphology.
The epsilon wave—a terminal irregularity of the QRS complex occurring at the J point—is the most specific finding of arrhythmogenic right ventricular cardiomyopathy yet is seen in only 30% of afflicted patients. A prolonged upstroke of the S wave of  milliseconds in the anterior leads is also suggestive of arrhythmogenic right ventricular cardiomyopathy.
The diagnosis of arrhythmogenic right ventricular cardiomyopathy is complex and based on a combination of clinical, ECG, biopsy, and
116,117 echocardiographic features, with little application in the ED. For the emergency provider, when the ECG demonstrates the combination of an epsilon wave and anterior ECG lead findings (deep S­wave upstroke and T­wave inversion), the diagnosis can be considered, particularly in a patient
116 with palpitations, syncope, family history of sudden death, and/or resuscitation from cardiac arrest.
TREATMENT
Asymptomatic discovery of an epsilon wave should prompt a referral to a cardiologist. Symptomatic patients with suggestive clinical features should be admitted for cardiology evaluation. Active dysrhythmias, most often a malignant ventricular dysrhythmia, are managed in standard manner.
Patients with high­risk features (e.g., prior history of cardiac arrest, ventricular tachydysrhythmias, or strong family history of sudden cardiac death) likely require insertion of an implantable cardiac defibrillator. Patients lacking high­risk features can be managed with β­blockers (e.g., sotalol) or amiodarone, as prescribed by a cardiologist. Persistent malignant dysrhythmias can be managed with ablation. Heart failure, whether right or biventricular, is managed in standard fashion.


