## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 236: Sickle Cell Disease and Hereditary Hemolytic Anemias
Brit Long; Alex Koyfman
INTRODUCTION
Hereditary anemias result from defects in hemoglobin production, abnormalities in red blood cell (RBC) metabolism, or changes within RBC membrane structure. Increased hemolysis occurs because the RBCs produced are either abnormal or sustain damage after release from the bone marrow and are removed from the circulation, primarily by the spleen. Depending on the compensatory rate of production, the concentration of circulating erythrocytes may decrease, resulting in anemia.
Inherited hemoglobin disorders are comprised of two main groups: disorders with abnormal hemoglobin structure (e.g., sickle cell disease) and disorders of abnormal hemoglobin production (e.g., the thalassemias). About 5% of the world’s population are carriers of a clinically significant
 abnormal hemoglobin gene. These genetic abnormalities result in hemoglobin that tends to gel or crystallize, possesses abnormal oxygen­binding properties, or is readily oxidized to methemoglobin, rendering the RBC susceptible to hemolysis.
SICKLE CELL DISEASE
,3
Sickle cell disease (SCD) is a group of genetic RBC disorders that constitute a worldwide public health problem. An estimated 250 million people

(approximately .5% of the world population) are carriers of the sickle cell gene, with an estimated >250,000 new individuals born each year with

SCD. SCD affects predominantly people of African Equatorial descent, although it is also found in persons of Mediterranean, Indian, and Middle

Eastern origin. SCD affects approximately 100,000 people in the United States, and about  million Americans are sickle cell gene carriers. One of
 every  African Americans carries the sickle cell gene, and SCD occurs in  of every 365 African American births.
Antenatal and neonatal screening, parental education about complications, monitoring in clinics and close follow­up, immunizations, prophylactic penicillin to prevent pneumococcal septicemia, and increased use of drugs such as hydroxyurea counteract the high mortality rate seen with untreated
,6
SCD. In the United States, survival to age  years approaches 94%, and the overall life expectancy is >50 years.
PATHOPHYSIOLOGY
SCD is characterized by RBCs that contain at least one abnormal hemoglobin, hemoglobin S. Hemoglobin is made of iron (heme) and protein chains

(globin). There are four types of globin molecule chains (alpha, beta, gamma, and delta), which determine the type of hemoglobin present.
Hemoglobin A, the normal constituent of adult hemoglobin (95% to 98%), consists of a pair of alpha and beta chains. HbSS, the hemoglobin of sickle cell anemia, consists of a pair of alpha chains and a pair of sickle beta chains. The hemoglobin of sickle cell trait, HbS, consists of two alpha chains, one normal beta chain, and one sickle beta chain.
,8
The abnormal hemoglobin S results from an adenine­to­thymine DNA substitution in the beta­globin chain of hemoglobin. RBCs with normal hemoglobin are donut shaped and flexible enough to move through arterioles and capillaries. RBCs containing hemoglobin S are stiff and sickle shaped. Sickling, or distortion of the RBC, results in premature RBC destruction (abnormal life span of about  days) and increases blood viscosity,
8­10 leading to microvascular obstruction (Figure 236­1). Vascular obstruction worsens hypoxia and causes acidosis in the microcirculation that contributes to further sickling. The sickling process is initially reversible when the HbS is reoxygenated, but with repeated episodes of sickling, the red cell membrane is permanently damaged, and the cell remains irreversibly sickled. Anywhere from 5% to 50% of the circulating erythrocytes in a patient with SCD can be irreversibly sickled cells. The overall effect is chronic, ongoing hemolysis and episodic periods of vascular occlusion, resulting in tissue ischemia affecting many organ systems.

FIGURE 236­1. Chapter 236: Sickle Cell Disease and Hereditary Hemolytic Anemias, Brit Long; Alex Koyfman 
. Terms of Use * Privacy Policy * Notice * Accessibility
Intravascular blood flow of normal and sickle red blood cells (RBCs). Abnormal, sickled RBCs clumping and blocking blood flow in a blood vessel.
(Other cells also may play a role in this clumping process.)
SICKLE CELL ANEMIA (HbSS DISEASE)
CLINICAL FEATURES
Because newborn screening occurs in the United States and in most developed countries, patients usually know that they have the disease. HbSS
,8 disease can produce a wide spectrum of manifestations, but vaso­occlusive crises account for the majority of ED presentations. Life­ or organ­
 threatening complications should always be anticipated (Table 236­1).
TABLE 236­1
Complications of Sickle Cell Anemia
Neurologic Ischemic or hemorrhagic stroke
Cerebral aneurysm
Chronic and neuropathic pain syndrome
Eye Retinopathy
Pulmonary Pulmonary hypertension
Pneumonia
Acute chest syndrome
Cardiac Cardiomegaly
Abdominal, GI Cholelithiasis
Mesenteric ischemia
Hepatic infarction
Intrahepatic cholestasis
Splenic sequestration
Renal, GU Hematuria
Urinary tract infection
Renal infarction
Papillary necrosis
Renal failure
Priapism
Musculoskeletal Acute vaso­occlusive pain crisis; bone, joint, and muscle pain
Osteomyelitis
Avascular necrosis of femoral head
Dermatologic Leg ulcers
Hematologic Chronic hemolysis
Acute hemolytic crisis
Aplastic crisis
Hypercoagulability: pulmonary embolism and venous thrombosis
Vaso­Occlusive Pain Crisis
The initiating event of the pain crisis may not be identifiable, but stressors such as infection, cold, dehydration, and altitude have been implicated. As a result of intravascular sickling and small­vessel occlusion, infarction of bone, viscera, and soft tissue occurs. This manifests as diffuse bone, muscle, and joint pain (back or extremity pain are most common) and, in some cases, symptoms related to a specific affected organ. Initial management includes timely and aggressive pain management, appropriate hydration, identification of a treatable cause of the crisis, and a
,12 search for complications (Table 236­2).
TABLE 236­2
Guidelines for the Assessment and Management of Acute Vaso­Occlusive Crisis in Adults
History Duration and location of pain
History of fever
Presence of focal swelling or redness
Precipitation factors for acute episode
Medications taken for pain relief
Prior vaso­occlusive episodes and any differences/similarities to the current episode
Physical Assess degree of pain examination Inspect sites of pain, looking for swelling, warmth, redness
General: respiratory distress, pallor, hydration, jaundice, rash
Vital signs: especially temperature, pulse oximetry
Respiratory: lung sounds
Heart: cardiomegaly and systolic murmur common with chronic anemia
Abdomen: tenderness, organomegaly
Ancillary tests CBC, leukocyte differential, electrolyte and renal function panel, urine dipstick (obtain if moderate to severe pain or focal pathology is present, or pain is atypical for acute episode)
CBC, leukocyte differential, reticulocyte count, liver function, bilirubin, lactate dehydrogenase, electrolyte and renal function panel, urinalysis (if being admitted, concern for another condition or complication, toxic appearing)
Chest radiograph, if signs of lower respiratory tract pathology are present
Blood cultures and additional blood tests: as indicated by clinical condition
General Bed rest; provide warmth and a calm, relaxing atmosphere management Distractions where appropriate: television, music, etc.
Oral fluids: typically about  L/d
IV fluids to correct dehydration or if reluctant to drink or vomiting is present (unnecessary if euvolemic)
Oxygen: not routinely required unless hypoxemia is present (<92%)
Encourage deep breathing, incentive spirometry
Pain Use analgesics appropriate to degree of pain management Acetaminophen for mild pain
NSAIDs for mild to moderate pain (avoid if renal insufficiency is present); conflicting results for opioid sparing, reduction in pain severity and duration
Opioids for moderate to severe pain; typical initial doses include:
Morphine, 20–30 milligrams PO or 6–10 milligrams IV
Hydromorphone, 2–4 milligrams PO or 1–2 milligrams IV
Reassess response in 15–30 min; may repeat with one fourth to one half of the initial dose
Ketamine in subdissociative doses can be used for opioid sparing, reduction in treatment time, and reduced pain scores
Consider Medication to prevent constipation adjuvant Antiemetic therapy Anxiolytic
Disposition Consider admission to the hospital if: and follow­up Acute chest syndrome is suspected
Sepsis, osteomyelitis, or other serious infection is suspected
WBC count is >30,000/mm3 (30 × 109/L)
Hemoglobin level is <5 grams/dL (50 grams/L)
Platelet count is <100,000/mm3 (100 × 109/L)
Pain is not under control after  to  rounds of analgesics in the ED
Consider discharge if:
Pain is under control and patient can take oral fluids and medications
Appropriate oral analgesics are available
Patient is able to comply with home care instructions
Patient has resources for follow­up
The CBC and reticulocyte count assess the degree of anemia and whether the marrow is still producing red cells. If the reticulocyte count is not available, the presence of polychromasia in the peripheral blood smear can be used to provide evidence of continued RBC production. It is common for HbSS patients to have a low­grade temperature as well as a modestly elevated leukocyte count during a painful crisis, potentially confounding
  detection of an infection. A leukocyte count >20,000/mm (>20 ×  /L) with an increased number of bands is not typical for sickle crisis alone; this combination suggests a potential infection. Mild elevations in serum bilirubin and lactate dehydrogenase levels are common due to chronic hemolysis.
,13
Supplemental oxygen is needed only for hypoxia (<92%). During a painful crisis, HbSS patients may be hypovolemic due to their disease (deficient renal concentrating ability) or crisis (anorexia, vomiting, or fever), so PO or IV rehydration followed by maintenance hydration may be necessary. There
 are no published trials that have evaluated the safety and efficacy of different types of IV fluids for vaso­occlusive crises. Euvolemic patients do not
 require IV hydration, and no hydration regimen shortens the duration or severity of a painful sickle cell attack.
No reliable signs or tests can diagnose or exclude a vaso­occlusive pain crisis. Self­reported pain scores do not reliably correlate with vital sign abnormalities, and patient behavior (walking around, talking on phone) or appearance does not exclude significant pain. Laboratory values are not markers for pain.
,11,12
Treatment of acute, severe pain typically requires parenteral opioids, such as morphine or hydromorphone, although oral morphine may be effective. Meperidine is not recommended due to the potential for neurotoxicity (seizures and behavior changes) from accumulation of the metabolite normeperidine. Avoid IM injections because repeated injections can be associated with unpredictable absorption and muscle fibrosis. Some patients may require large opioid doses for adequate analgesia. Regular doses of analgesics for a few hours to several days typically are required. Continuous or demand patient­controlled analgesia, or both, is an effective method for pain control and can reduce opioid need and decrease opioid­related adverse events, and in general, it is well accepted by patients. NSAIDs can be used for their probable additive effect in pain management of sickle cell
,11,12,16 crisis, but use should be individualized based on patient risk factors, such as renal disease. Low­dose ketamine by continuous IV infusion is a
,18 potential adjuvant analgesic in acute pain crisis and may reduce opioid medication requirements, time to analgesic treatment, and total pain.
A recommended practice is to develop an individualized assessment and treatment protocol for specific patients who frequent the
ED with painful crises.
Transfusion Practice
RBC transfusion to reduce the concentration of HbS­containing erythrocytes does not shorten the duration or reduce the risk of complications of routine acute vaso­occlusive painful crisis. Furthermore, transfusion involves significant expense, the risk of bloodborne disease transmission, and the potential for iron overload and exposes the patient to the minor RBC antigens, with the potential to induce antibodies that prevent or complicate future transfusions (see Chapter 238, “Transfusion Therapy”). Transfusion for sickle cell crisis or complications is reserved for specific indications
,11­13 such as aplastic crisis, pregnancy, stroke, respiratory failure, and general surgery. Transfusion protocols are categorized as aggressive
(decreasing HbS to <30%) and conservative (increasing hemoglobin to >10 g/dL or 100 g/L); for most indications, there is no clinical difference between aggressive or conservative protocols.
Bone Pain
Bone pain is common during a sickle cell crisis and is usually located in the back and the extremities. The pain is diffuse, without focal signs of inflammation; therefore, redness, warmth, or swelling suggests infection such as cellulitis or osteomyelitis. The femoral and humeral heads are most commonly affected, primarily due to pressure increases from vascular occlusion and increased RBC marrow. Localized hip pain with difficulty ambulating suggests aseptic necrosis of the femoral head; approximately 30% of HbSS patients develop femoral head damage by age  years old.
Joint effusions are occasionally seen in painful sickle cell crisis, and arthrocentesis is often necessary to differentiate this complication from infection.
Plain radiographs may show evidence of aseptic necrosis or osteomyelitis, whereas bone infarcts usually are not visible on radiographs. A radionuclide bone scan or MRI may be necessary to differentiate infection from infarction.
Acute Chest Syndrome
Acute chest syndrome is defined as a new infiltrate on chest radiograph in association with one other new sign or symptom: fever >38.5°C (101.3°F),
19­21 cough, wheezing, tachypnea, or chest pains. In adults, acute chest syndrome occurs most commonly  to  days after hospitalization for an acute pain crisis. Acute chest syndrome is the leading cause of death in patients with HbSS in the United States, with a mortality up to 9% and 13% of patients
 requiring mechanical ventilation. Although this phenomenon occurs most often as a single episode, some patients may experience multiple attacks,
 resulting in chronic lung disease.
Acute chest syndrome has multiple potential precipitating etiologies, including pulmonary infections, pulmonary infarction, fat emboli, and rib
20­22 infarction. Acute chest syndrome may also result from iatrogenic causes. Opioid analgesics promoting hypoventilation can increase the risk of
 acute chest syndrome. It is not clear if excess hydration producing pulmonary edema increases the risk of acute chest syndrome.

Up to 30% of cases of acute chest syndrome admitted to the hospital will have an infectious pathogen identified. The two most common organisms
 identified are the atypical pneumonia pathogens Chlamydia pneumoniae (in adults) and Mycoplasma pneumoniae (in pediatric patients). Other organisms associated with acute chest syndrome include Staphylococcus aureus, Haemophilus influenzae, Klebsiella pneumoniae, adenoviruses,
 influenza viruses, parainfluenza viruses, respiratory syncytial viruses, cytomegalovirus, and parvovirus B19. Traditionally, Streptococcus pneumoniae was considered the most frequent cause of pulmonary infection, but this pathogen is now rare in cases of acute chest syndrome, presumably due to the use of pneumococcal immunization and prophylactic penicillin therapy.
Abundant evidence for fat embolism as a possible cause for acute chest syndrome includes bony slivers and marrow fat found in the pulmonary vasculature at autopsy, fat droplets within endothelial cells identified in lung biopsy specimens collected via bronchoscopy in living patients, and elevated serum levels of free fatty acids and circulating secretory phospholipase A , a potent inflammatory mediator originating from the bone

  marrow. Pulmonary thrombosis has a high prevalence in sickle cell anemia and is common in acute chest syndrome (17% of cases).
The acute chest syndrome is the final result of several pathogenic processes exerting their effects individually and collectively in a vicious cycle, creating regional hypoxia, acidosis, and lung injury (Figure 236­2).
FIGURE 236­2. Pathogenesis of acute chest syndrome. RBC = red blood cell; VCAM­1 = vascular cell adhesion molecule­1. ,21
Respiratory symptoms are usually present, including cough, shortness of breath, chest pain, and fever, although the clinical presentation may vary.
Fever occurs in 80%, followed by cough in up to 74% and chest pain in 44% to 57% (may be pleuritic due to pulmonary infarction). On physical
 examination, rales are the most common finding (48% to 76%). Chest radiographs are important to identify the presence of a new patchy infiltrate; any lobe can be affected. The radiographic changes often lag behind the clinical features, so the radiograph may be initially normal, and the clinical
 severity of disease and the extent of hypoxia may not correlate with radiographs. Adults typically demonstrate lower lobe disease with effusion.
,13,20­22
Acute chest syndrome is treated with supportive care (oxygen, analgesics, hydration), antibiotics, and exchange transfusion (Table 236­3).
Give oxygen for hypoxemia. Pain control with parenteral opioids requires careful monitoring to prevent both oversedation and hypoventilation.
Patients are often unable to adequate drink fluids to maintain hydration. Administer maintenance IV fluid therapy with 5% dextrose in half normal
 saline until the patient is able to adequately drink. Monitor closely to avoid volume overload.
TABLE 236­3
Assessment and Treatment of Acute Chest Syndrome
History Major presenting symptoms: dyspnea, fever, cough
Accompanying chest, rib, bone, or joint pain
Assess degree or severity of pain
Recent or previous sepsis, infection, pneumonia, or hospitalization
Prior history of acute chest syndrome, especially if required intubation and ventilatory support
Potentially infectious contacts
Current medications, especially daily prophylactic penicillin
Immunization history, especially pneumococcal and Haemophilus influenzae type b
Baseline hemoglobin level and arterial oxygenation saturation
Physical General: respiratory distress, pallor, hydration, jaundice, rash examination Vital signs: especially temperature, pulse oximetry
Respiratory: chest wall, lung sounds
Heart: cardiomegaly and systolic murmur common with chronic anemia
Abdomen: tenderness, organomegaly
Ancillary tests CBC, leukocyte differential, reticulocyte count, serum electrolytes, liver function, renal function, urinalysis
Cross­match sample: if red blood cell transfusion is contemplated
Arterial blood gas: if moderate to severe respiratory distress and/or hypoxemia on pulse oximetry
Chest radiography
Blood cultures
Additional blood tests: as indicated by clinical condition
Treatment Oxygen: adjust according to pulse oximetry
Oral hydration: preferable
IV hydration: use Dextrose 5% in half­normal saline at rate  to .5 times maintenance (aggressive IV fluids can worsen acute chest syndrome)
Analgesics: if needed, generally potent parenteral opioids are used, monitor for signs of respiratory suppression
Incentive spirometry
Antibiotics: empiric antibiotics recommended to cover community­acquired pneumonia pathogens
Transfusion: use if severe acute anemia is present
Exchange Consider when transfusion Severe acute chest syndrome on admission and past history of requiring ventilatory support: useful to prevent intubation
Multiorgan dysfunction/multiorgan failure syndrome
Neurologic abnormalities
Deterioration despite above management: useful to prevent intensive care unit admission
Patient already intubated and on ventilatory support: useful to shorten duration of ventilatory need
Suspected or confirmed fat or bone marrow embolism
Antibiotics are recommended irrespective of cultures, and many experts believe that patients with acute chest syndrome should receive a full course of
,13,20,21 empirical broad­spectrum antibiotics to treat pathogens commonly associated with community­acquired pneumonia. Typically a parenteral
 cephalosporin and macrolide are used to ensure coverage of Mycoplasma and Chlamydia. Bronchospasm may accompany acute chest syndrome and can persist after recovery, indicating that bronchial hyperactivity can be a marker of lung injury in some patients. Inhaled β ­adrenergenic agents can

 be used if wheezing occurs. Incentive spirometry is recommended for prophylaxis and treatment.

Transfusion therapy is believed to be lifesaving in acute chest syndrome, but there are no firm evidence­based recommendations for its use, and
,13,20­22 currently accepted indications for exchange transfusion in acute chest syndrome are based on empirical observations. Significant increases in
 hemoglobin from transfusion may increase viscosity and the risk of complications. Exchange transfusion appears more advantageous, particularly in patients with relatively high hemoglobin (>9.0 g/dL or  g/L). Exchange transfusion decreases the concentration of sickled hemoglobin while maintaining an unchanged whole­blood viscosity and resulting in little iron gain. Exchange transfusion is usually reserved for severe crises signaled by deterioration of the patient’s partial pressure of arterial oxygen to <60 mm Hg (<8 kPa) with the goal to decrease the HbS level to <30%; it is also used in the presence of neurologic abnormalities or multiorgan failure in the setting of acute chest syndrome.
Systemic corticosteroids to treat acute chest syndrome are controversial; they may prevent deterioration and decrease the need for transfusion but
30­32 are associated with higher rates of readmission.
Patient clinical status dictates disposition and level of care required. All patients with acute chest syndrome should be admitted to a monitored setting, although not necessarily an intensive care unit. Increasing age is associated with poor outcome, but the best predictors of poor outcomes include
  platelets <199,000/mm , comorbidity including cardiac disease, and extensive lung involvement. Long­term complications include pulmonary
 hypertension, pulmonary fibrosis, and cor pulmonale.
Abdominal Crisis
Generalized and constant abdominal pain is a common complaint during an acute sickle cell crisis, and it may be difficult to distinguish from a focal abdominal problem, such as cholecystitis or appendicitis. With a vaso­occlusive crisis, there should be accompanying musculoskeletal pain, the patient can frequently identify that the pain is similar to prior episodes, and there should not be physical evidence of peritonitis. Repeated abdominal examinations should be done to assess for progression of tenderness and development of peritoneal signs.
Hepatic infarction may produce jaundice and abdominal pain, which can be difficult to distinguish from hepatitis or cholecystitis. Liver involvement is common in patients with vaso­occlusive pain crisis, with elevation in liver function tests due to sinusoidal vaso­occlusion. Hepatic sequestration is similar to splenic sequestration and results from hepatic congestion from sickle cells. Anemia with a brisk reticulocyte response, hepatomegaly, and right upper quadrant pain typically occur. Severe right upper quadrant pain and marked elevations of bilirubin may be due to intrahepatic cholestasis, which rarely may progress to shock liver and hepatic failure. Hepatic crises including hepatic sequestration and intrahepatic cholestasis require volume resuscitation and likely exchange transfusion. Biliary disease is common because pigment­related cholelithiasis occurs in 30% to 70% of sickle cell anemia patients from chronic hemolysis and increased bilirubin turnover.
GU System

Vaso­occlusive events involving the kidneys are often asymptomatic and likely account for the frequent finding of microscopic hematuria. Infarction
 in the renal medulla may cause flank pain, renal colic–type pain, and costovertebral angle tenderness, mimicking pyelonephritis. Papillary necrosis may result in either gross or microscopic hematuria, but RBC casts are uncommon. Approximately 30% of adults with HbSS develop renal failure, with
 microalbuminuria and proteinuria common findings. Renal imaging studies generally are necessary for correct diagnosis of renal infarction or papillary necrosis. Both are treated with IV fluids to maintain urine flow and close monitoring of hemoglobin levels to ensure that anemia does not worsen. Patients are often prescribed angiotensin­converting enzyme inhibitors prophylactically to reduce renal disease progression. The higher
 incidence of renal injury in this population warrants caution with NSAIDs. Urinary tract infections are common, and routine urine dipstick is recommended with ED assessment.
Priapism occurs in up to 30% of males. Priapism is typically the low­flow variety due to stasis, hypoxia, and ischemia. Patients with stuttering priapism
(recurrent episodes that last <3 hours often with a pattern of increasing frequency and severity) are treated with oral adrenergic agents or hormonal
 analogs. Patients with a major episode (sustained erection lasting >4 hours) are treated with fluid hydration, pain control, corporal aspiration, and intracorporal installation of a dilute α­adrenergic agonist solution (see Chapter , “Male Genital Problems”). Transfusions, either simple or exchange,
 have no proven benefit for sickle cell–associated priapism.
Splenic Infarction and Sequestration
The spleen is particularly susceptible to the vaso­occlusive effects of sickled cells, and over time, microinfarctions result in a spleen that is essentially
 nonfunctional by age . This renders these patients at risk for serious infections and overwhelming sepsis from encapsulated organisms. Therefore, immunizations, prophylactic penicillin therapy, and parental education are critical to minimize the risk of infection and prompt early evaluation of fever in these patients. As HbSS patients grow into teenage years, the risk of overwhelming sepsis decreases, but they remain predisposed to infection.
Splenic sequestration is an important cause of significant morbidity and occasional mortality, with its occurrence being more common in children
 than in adults due to RBCs becoming trapped within the spleen and removed from circulation. After ages  to  years, splenic sequestration is
 uncommon due to splenic autoinfarction. However, it may occur in adults with persistent splenic tissue. This syndrome manifests by the sudden enlargement of the spleen with an acute decrease in the hemoglobin level (>2 g/dL or >20 g/L) due to sequestration of the blood volume within the spleen, along with reticulocytosis and splenomegaly. Left upper quadrant pain may or may not be present. Symptoms include tachycardia, hypotension, pallor, and lethargy, and the spleen is usually enlarged and firm. Platelets also may be sequestered, resulting in moderate thrombocytopenia. The reticulocyte count should remain elevated.
Therapy includes volume resuscitation, which may mobilize some of the RBCs trapped within the spleen. Simple RBC transfusion or exchange transfusion may be necessary. An investigation for a precipitating infection should be done. Rarely, splenectomy is necessary. Unfortunately, recurrence of this syndrome is common at a rate approaching 50%.
Hemolytic Anemia and Aplastic Crisis
Patients with HbSS have a chronic hemolytic state due to the shape of the red cells. The baseline hemoglobin level is often between  and  g/dL (60 to
 g/L), and the reticulocyte count is between 5% and 15%. With infections, the hemolytic process may worsen, and hemoglobin may drop from the previous baseline. Typically, erythrocyte production will increase in response to the increased RBC destruction, but it may not be enough to compensate for the increased hemolysis. Acutely, the patient may notice symptoms of worsening fatigue, shortness of breath, dyspnea on exertion, and scleral icterus. Symptoms may worsen if other comorbid diseases are present. It is uncommon for the hemolysis to be so severe as to require transfusion.
Aplastic crisis results when the production of RBCs declines significantly, producing a rapid decrease in the hemoglobin level with
 reticulocytopenia. The most common cause of aplastic crisis appears to be infection, specifically from human parvovirus B19. Folate deficiency and
 bone marrow necrosis with fat embolism also may play a role. Aplastic crisis is more common in children than in adults. Patients generally will present with increasing fatigue and pallor and no evidence of increased hemolysis. The hemoglobin level will be unusually low, and few or no reticulocytes will be present; reticulocyte count is typically <0.5%. The leukocyte and platelet levels are usually normal. This syndrome is usually selflimiting, lasting  to  days, and the marrow will begin producing RBCs spontaneously within  week. Transfusion may be required in the interim.
Acute Stroke

Ischemic and hemorrhagic stroke, as well as subarachnoid hemorrhage, are common in patients with HbSS disease. The risk of stroke in children
 with sickle cell anemia is >200 times greater than those without the disorder, and approximately 10% of patients experience a stroke before age 
,8 years old. Stroke is more common in pediatric patients compared to adults with HbSS. The cause of stroke in most patients is cerebral infarction due
 to occlusion or narrowing of large cerebral vessels. Increased cerebral blood flow and oxygen extraction at rest accompany these anatomic
,46 changes. Silent cerebral infarcts visible on MRI have been observed in over a third of patients by age  years and are associated with decreased
 intellectual ability, poor academic achievement, and risk of progression to overt stroke. Hemorrhagic strokes and subarachnoid hemorrhage most
,48 commonly occur in the third decade of life and are the most common acute neurologic complication in adults. Cerebral aneurysms are also more common, perhaps due to local vessel occlusion or ischemia.

Acute stroke in an sickle cell anemia patient is treated with emergent simple or partial exchange transfusion to maintain HbS <30%. Unfortunately, children who suffer a stroke are at 70% to 90% risk for recurrence, so chronic transfusion therapy is indicated to prevent recurrent stroke after the
 initial event. The 2018 American Heart Association/American Stroke Association guidelines state that tissue plasminogen activator in sickle cell
 anemia patients with acute ischemic stroke may be beneficial, and discussion with a neurologist and hematologist is recommended.
Infections
Patients with sickle cell anemia are functionally asplenic after early childhood and functionally immunocompromised due to altered complement activity and increased bone marrow turnover, rendering them susceptible to infections from encapsulated organisms, such as H. influenzae and S.
,52 pneumoniae. Other common infections associated with sickle cell anemia include pneumonia caused by these organisms as well as M.
pneumoniae, meningitis, and osteomyelitis due to Salmonella typhimurium, S. aureus, and Escherichia coli. In addition to H. influenzae immunization, patients with sickle cell anemia should be encouraged to receive yearly influenza vaccinations and remain up to date with pneumococcal
 immunization, and children should be maintained on prophylactic daily oral penicillin.
In patients with fever and sickle cell anemia, CBC, chest radiograph, and urinalysis are recommended, with further testing based on the suspected source. If no source is found on history, examination, or basic assessment, obtain blood/urine cultures and consider admission for empiric IV
 antibiotic therapy in those who have a high fever (>39.5°C [103.1°F]) or those who appear ill.
Cardiovascular Complications
Cardiomegaly is common and correlates with the degree of chronic anemia. Additionally, cardiac dysfunction may occur from microinfarcts and
 hemosiderin deposition from hemolysis and blood transfusion. Cardiac contractility is enhanced to maintain adequate systemic oxygen delivery, producing a systolic ejection murmur. Although the literature suggests patients with HbSS have minimal atherosclerosis of the large coronary
55­57 58­60 vessels, acute coronary syndrome may result from vaso­occlusive events. Thus, consider acute coronary syndrome and obtain an ECG and cardiac biomarkers in patients presenting with chest pain or dyspnea. Further testing and treatment are based on these results, with interventional treatment recommended if ST­elevation myocardial infarction is diagnosed.
HbSS patients have laboratory evidence of thrombophilia, and combined with endothelial dysfunction and impaired vascular flow, there appears to be
61­65 a 50­ to 100­fold increased risk for pulmonary embolism and venous thrombosis. Pulmonary embolism may also increase the risk of chronic
  pulmonary hypertension. Because baseline D­dimer levels are increased in the steady state and levels are much higher during pain crisis, clinical decision tools for deep venous thrombosis or pulmonary embolism using published D­dimer thresholds are not reliable in HbSS patients.
Dermatologic

Chronic, poorly healing leg ulcers around the malleoli are common in older sickle cell patients. Minor injury, impaired microcirculation due to repeated sickling episodes and microinfarcts, and infections all contribute to the development and persistence of these ulcers. No systemic or topical
 therapy has proven superior to facilitate healing.
Multiorgan Failure Syndrome
,69
A small proportion of patients with vaso­occlusive crises can progress to multiorgan failure syndrome, a most ominous complication with high mortality. The syndrome most commonly occurs in the setting of brisk hemolysis, with hemodynamic compromise and acute deterioration of at least
 two of three major organs (lungs, liver, or kidneys).
Laboratory findings typically include elevated serum lactate dehydrogenase, acute anemia, thrombocytopenia, and renal injury. Thrombotic
,71 thrombocytopenic purpura can develop. Chest radiograph may reveal multilobar infiltrates, and acute lung injury is a complication in 25% of
 cases. Consultation with hematology and nephrology with admission to the intensive care unit is recommended. Simple or exchange transfusion is
 recommended, although evidence supporting this is lacking. If thrombotic thrombocytopenic purpura occurs, plasma exchange with exchange transfusion can be of benefit, and in the setting of acute lung injury, endotracheal intubation with lung­protective strategies may be needed.
SICKLE CELL TRAIT
People with sickle cell trait (HbAS, heterozygous with one gene for the sickle mutation) have a normal life span and usually are asymptomatic,
 although complications have been attributed to the trait, categorized as definite, probable, or possible. Definite associations include renal medullary carcinoma, hematuria and renal papillary necrosis, hyposthenuria, splenic infarcts, and exercise­related deaths. Probable associations include venous thromboembolic events, pregnancy­related complications, and complicated hyphema. Possible associations include retinopathy, acute chest
 syndrome, and asymptomatic bacteriuria. Many of the associations are seen only under conditions of severe tissue hypoxia, acidosis, dehydration, or
 hypothermia or with coexistent beta­thalassemia.
OTHER VARIANTS OF SICKLE CELL DISEASE
SICKLE CELL–HEMOGLOBIN C DISEASE
HbC results from a single point mutation in the β­globin chain gene; lysine is substituted for glutamic acid at the sixth position. The prevalence of the

HbC gene is approximately  per 5000 in African Americans but is as high as 16% in parts of West Africa. Deoxygenated HbC has the tendency to precipitate inside the RBC, forming crystals that decrease cell deformability and increase blood viscosity. Patients with HbC trait (heterozygous for the
HbC gene, or HbAC) are asymptomatic, and those with HbC disease (homozygous for the HbC gene, or HbCC) typically have a mild hemolytic anemia,
  abundant target cells, and sporadic episodes of musculoskeletal pain, splenomegaly, dental infarctions, and angioid retinopathy.
The heterozygous sickle cell variant, sickle cell–hemoglobin C (HbSC), results when the gene for HbS is inherited from one parent and the gene for HbC is inherited from the other parent. These individuals have almost equal amounts of HbS and HbC but no HbA. Because HbC does not polymerize as
 readily as HbS, HbSC disease generally has less severe clinical consequences than sickle cell anemia (HbSS). HbSC patients have a milder chronic hemolytic anemia and, as a consequence, milder reticulocytosis. The peripheral smear shows abundant target cells and a few sickle cells.
The complications of HbSC disease are similar to HbSS disease, although usually less severe. As opposed to sickle cell anemia, adult patients with
HbSC disease often have splenomegaly. HbSC disease patients are susceptible to a proliferative retinitis that is visible on fundoscopy as angioid
 streaks (jagged, reddish brown, subretinal lines that taper outward from the optic nerve), representing breaks in the brittle Bruch membrane. Cracks in the membrane lead to impairment of the choriocapillaries, which may produce loss of photoreceptor cells and lead to impaired vision.
SICKLE CELL–HEMOGLOBIN O­ARAB DISEASE
Hemoglobin O­Arab is a hemoglobin variant resulting from substitution of lysine for glutamic acid at position 121 of the β­globin chain. Hemoglobin O­

Arab is widespread in the Middle East, is present in the Balkans, and occasionally occurs in African Americans. Patients heterozygous for hemoglobin
O­Arab (HbAO­Arab) have no clinical problems. Patients homozygous for hemoglobin O­Arab (HbOO­Arab) or heterozygous for sickle cell–hemoglobin
O­Arab (HbSO­Arab) are clinically similar to patients with sickle cell anemia, having severe hemolytic anemia and recurrent vaso­occlusive crises, and children have the potential to develop sickle cell dactylitis and splenic sequestration crises.
THALASSEMIA
The thalassemias are a diverse group of hereditary disorders caused by defective synthesis of globin chains, resulting in an inability to produce normal
79­81 adult hemoglobin. The hallmark of these disorders is a microcytic, hypochromic, hemolytic anemia. These disorders are most common in those of

Mediterranean, Middle Eastern, African, and Southeast Asian descent and are thought to be protective against malaria.
The thalassemia syndromes are categorized depending on the globin chain affected or the abnormal hemoglobin produced. Thus, β­globin gene
 mutations give rise to β­thalassemia and α­globin mutations cause α­thalassemia.
Both forms of thalassemia are characterized by varying degrees of anemia depending on the amount of ineffective erythropoiesis and premature destruction of the circulating RBCs. The hypoxia associated with severe anemia triggers compensatory mechanisms in an attempt to increase RBC production. This causes enlargement of the reticuloendothelial organs and expansion of the bone marrow cavity, leading to osteopenia.
α­THALASSEMIA CARRIER AND TRAIT
Patients who are α­thalassemia carriers and with α­thalassemia trait have no clinical symptoms or physical findings, and patients with α­thalassemia
 trait are detected by the finding of microcytic RBCs and a borderline to slightly low hemoglobin level.
α­THALASSEMIA (HEMOGLOBIN H DISEASE)
This disorder is thought to be protective for malaria and consists of both ineffective erythropoiesis and increased hemolysis. The populations with highest incidences are found in Southeast Asia, the Mediterranean, the Middle East, northern Thailand, and southern China. There is marked phenotypic variation in the clinical picture, from intrauterine or fetal death to mild anemia in adulthood. Hemoglobin H can cause chronic hypochromic microcytic anemia and hemolysis, which worsens during oxidant stress. Treatment is supportive and includes avoidance of unnecessary iron therapy. Table 236­4 lists drugs to avoid in patients with α Thalassemia (HbH disease) because the drugs may precipitate hemolysis.
TABLE 236­4
Drugs That Produce Oxidative Stress on Red Blood Cells at Therapeutic Doses
Definite Association Possible Association
Sulfonamides Sulfacetamide Sulfasalazine
Sulfamethoxazole Sulfadimidine
Sulfanilamide Glibenclamide
Antimalarials Primaquine Chloroquine
Pamaquine
Urinary agents Nitrofurantoin
Nalidixic acid
Phenazopyridine
Miscellaneous antibiotics Dapsone Ciprofloxacin
Chloramphenicol
Mothballs Naphthalene
Miscellaneous drugs Methylthionium chloride (methylene blue) Vitamin K analogs
Ascorbic acid
β­THALASSEMIA MINOR (β­THALASSEMIA TRAIT)
,79
Patients with β­thalassemia minor are heterozygous for the β­globin mutation and have only mild microcytic anemia. Splenomegaly may be present. On blood smear, these patients may have microcytosis and hypochromia as well as basophilic stippling. An elevated hemoglobin A level,
 typically 4% to 6%, confirms the diagnosis. These patients generally have no clinical manifestations and may only come to attention during an evaluation for a mild anemia.
β­THALASSEMIA INTERMEDIA
β­Thalassemia intermedia is the result of genetic combination of β­gene mutations producing microcytic moderate anemia (blood hemoglobin usually
,84
>7 g/dL), splenomegaly, and intense bone marrow hyperplasia. HbF levels are elevated. Clinical symptoms tend to be milder and delayed compared to thalassemia major. Transfusion requirements are variable, and complications from iron overload are less extreme.
β­THALASSEMIA MAJOR (COOLEY’S ANEMIA)
In β­thalassemia major, both β­globin genes are defective, and production of β­globin chains is severely impaired. Newborn infants with β­thalassemia major are usually well because HbF is predominant during the first few months of life. Symptoms emerge during the second  months of life when β­ globin production would be expected. The RBCs of these children show a low mean corpuscular volume with microcytic and hypochromic cells.
Variation in size and shape of the RBCs will be notable (increased RBC distribution width), as will be the presence of nucleated cells. HbF levels remain elevated, often >90% in untransfused individuals. This diagnosis should be considered in any child with a severe microcytic anemia and the appropriate ethnic background.
Affected children develop hepatosplenomegaly, jaundice, and expansion of the erythroid marrow, causing bone changes and osteoporosis, and
 possess increased susceptibility to infection. The anemia is severe and requires regular, lifelong blood transfusions, with resultant challenges of
 alloimmunization. Transfusions and enhanced iron absorption eventually cause iron overload, which is the etiology of most of the morbidity and mortality associated with the thalassemia. Untreated iron overload results in hemochromatosis with cardiac, hepatic, and endocrine
,79,85,87  ,90  dysfunction. Treatment is chelation, with parenteral (desferrioxamine) or oral (deferiprone and deferasirox) agents.
For those with a known diagnosis who present to the ED with significant symptoms related to anemia or hemolysis, consider transfusion along with a search for precipitating events.
SICKLE CELL–β­THALASSEMIA DISEASE
Sickle cell–β­thalassemia disease, a heterozygous sickle cell variant, occurs when the gene for sickle hemoglobin is inherited from one parent and a gene for β­thalassemia is inherited from the other parent. The frequency of sickle cell–β­thalassemia disease is about  per 1600 African American births. The severity of the disease depends on the functionality of inherited β­thalassemia gene. Between 80% and 90% of affected individuals have a
β­thalassemia gene that results in the production of some normal β­chains, yielding a modest amount of HbA. Such patients have a mild hemolytic anemia with near­normal hemoglobin levels, few crises, and minimal organ damage. Those 10% to 20% of patients who inherit a β­thalassemia gene that inhibits all β­globin production have severe hemolytic anemia and vaso­occlusive symptoms comparable with patients with sickle cell anemia.
GLUCOSE­6­PHOSPHATE DEHYDROGENASE DEFICIENCY
Glucose­6­phosphate dehydrogenase (G6PD) deficiency is the most common enzymopathy of RBCs in humans, affecting >400 million people
  worldwide, mainly among persons of African, Asian, or Mediterranean ancestry, a distribution suggestive of an ability to protect against malaria.
,93
The disease has >400 variants.

G6PD deficiency is an X­linked inherited disorder that primarily affects males. Females must have two defective genes to be severely affected, but because expression of this gene is variable, women with one abnormal gene may still show some symptoms. Most adults are usually asymptomatic, but some may have intermittent hemolytic anemia, and a few have chronic hemolysis.
G6PD is an enzyme that catalyzes the oxidation of glucose 6­phophogluconate while concomitantly being responsible for the production of nicotinamide adenine dinucleotide phosphate, a required cofactor for maintaining glutathione in its reduced state. Typically, multiple enzymes catalyze dehydrogenase reaction in cells, except in RBCs, where G6PD is the predominant producer of nicotinamide adenine dinucleotide phosphate.
Glutathione in the reduced state acts as a scavenger for harmful oxidative cell metabolites and, with the help of the enzyme glutathione peroxidase, converts harmful peroxide to water. G6PD­deficient RBCs are therefore susceptible to oxidative stress; oxidization of the sulfhydryl groups causes hemoglobin to precipitate within the cell. The precipitated hemoglobin is recognized by the presence of Heinz bodies on the peripheral blood smear
(Figure 236­3). The affected RBCs are removed from the circulation by the spleen. Oxidant damage also occurs at the RBC membrane, producing both extravascular and intravascular hemolysis.
FIGURE 236­3. Heinz bodies. Blood mixed with hypotonic solution of crystal violet. Precipitates of denatured hemoglobin within the cells. [Reproduced with permission from Lichtman M, Beutler E, Kaushansky K, et al: Williams Hematology, 7th ed. Copyright © 2006, McGraw­Hill Inc., New York.]
CLINICAL FEATURES
The clinical expression of G6PD variants encompasses a spectrum of hemolytic syndromes. The likelihood of developing hemolysis and disease severity are determined by the degree of the enzyme deficiency (Table 236­5).
TABLE 236­5
World Health Organization Classification of Glucose­6­Phosphate Dehydrogenase (G6PD) Variants
Class I variants: severe enzyme deficiency (<1% of normal activity) and have chronic hemolytic anemia.
Class II variants, such as G6PD Mediterranean: severe enzyme deficiency (1%–10% normal activity), associated with acute intermittent hemolytic episodes.
Class III variants, such as G6PD A–: moderate enzyme deficiency (10%–60% of normal activity) with intermittent hemolysis usually associated with stressors such as infection or drugs.
Class IV variants: no enzyme deficiency (60%–150% normal activity), no hemolysis or other clinical significance.
Class V variants: increased enzyme activity (>150% normal activity), no clinical significance.
A serious complication of G6PD deficiency is neonatal jaundice occurring during the first week of life. The elevated bilirubin induces neurotoxicity that can result in permanent neurologic sequelae (kernicterus). Phototherapy is used to lower the serum bilirubin concentration.
Class III variants are the most prevalent G6PD mutations, with acute hemolytic events that are usually self­limited and well tolerated, so the variant
 condition may remain undetectable.
Aside from favism and drug­induced hemolytic anemia, infection is the most common cause of hemolysis in G6PD­deficient individuals. There is also an increased incidence of pigmented gallstones and splenomegaly in patients with G6PD deficiency.
DIAGNOSIS
G6PD deficiency is established by the demonstration of decreased enzyme activity through quantitative assay. Evaluation of a blood film can reveal evidence of oxidative hemolysis. In societies with a high prevalence of G6PD deficiency, neonatal screening programs for this disorder are appropriate.
Patients with acute symptoms should be evaluated with a CBC and reticulocyte count (to evaluate level of anemia and bone marrow function), serum bilirubin levels, serum aminotransferases (to exclude other causes of jaundice), urinalysis (hemoglobinuria), and lactate dehydrogenase (elevated in hemolysis and a marker of hemolytic severity).
TREATMENT
Treatment of the patient with G6PD deficiency is determined by the patient’s overall clinical condition and removal of the offending agent, if present. If the illness is severe, then blood transfusion with packed RBCs may be warranted. Fluids are essential to prevent renal injury.
In patients with known G6PD deficiency, infections should be treated aggressively and oxidant drugs avoided. There is solid evidence to implicate eight currently used medications as causing acute hemolysis in patients with G6PD deficiency: dapsone, phenazopyridine, nitrofurantoin, primaquine, rasburicase, pegloticase, methylthioninium chloride (methylene blue), and tolonium chloride
,95 
(toluidine blue). Other oxidant drugs in therapeutic doses are not associated with increased hemolysis in G6PD­deficient patients. Full recovery is typical after an acute hemolytic event.
HEREDITARY SPHEROCYTOSIS
Hereditary spherocytosis is the result of an erythrocyte membrane defect and is the most prevalent hereditary hemolytic anemia among people of
 northern European descent, affecting approximately  in 2000. The disease typically is inherited in an autosomal dominant pattern, although a less common autosomal recessive variant exists, and up to 20% of hereditary spherocytosis patients develop the condition as a result of an apparent spontaneous mutation. The abnormal shape of the RBC results from molecular abnormalities in the cytoskeleton of the cell membrane, most
,98 commonly from mutations in the genes for the proteins spectrin and ankyrin. These abnormalities result in RBCs with a microspherocytic shape that is not pliable enough to pass through the spleen. This results in an increased rate of destruction and a compensatory increase in RBC production.
CLINICAL FEATURES
The clinical spectrum of hereditary spherocytosis is divided into those with (1) mild disease, occurring in about 20% with an autosomal dominant inheritance; (2) moderate disease, occurring in about 75% with primarily autosomal dominant inheritance; and (3) severe disease, occurring in
,100 approximately 5% with an autosomal recessive inheritance. The main complications include aplastic or megaloblastic crises, hemolytic crisis,
,100 cholecystitis or cholelithiasis, and neonatal hemolysis with jaundice. The disease is primarily marked by anemia, jaundice, and splenomegaly.
Neonatal jaundice during the first week of life occurs in 30% to 50% of those with hereditary spherocytosis. After the neonatal period, the symptoms and signs depend on the severity of ongoing hemolysis. Patients with mild disease usually have a normal hemoglobin level and little or no splenomegaly but are susceptible to hemolytic or aplastic episodes triggered by infection. Patients with moderate disease have mild to moderate anemia, modest splenomegaly, periodic episodes of hemolysis with jaundice, and an increased incidence of pigmented gallstones. The rare patient with severe hereditary spherocytosis has significant hemolytic anemia requiring episodic blood transfusions, chronic jaundice, and an enlarged spleen.
DIAGNOSIS
The peripheral blood smear shows spherocytes with a normal to low mean corpuscular volume and increased mean corpuscular hemoglobin concentration (>36%). The diagnosis of hereditary spherocytosis is usually established by a combination of clinical history and examination, family
101 history, and RBC indices and morphology.
TREATMENT
,102
Severe symptomatic anemia is acutely treated with RBC transfusions. In severe cases, splenectomy generally will reverse the anemia, except in the unusual cases of autosomal recessive variants. After splenectomy, spherocytes are still present.


