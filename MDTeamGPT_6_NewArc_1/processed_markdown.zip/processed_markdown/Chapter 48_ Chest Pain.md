## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 48: Chest Pain
Lane M. Smith; Simon A. Mahler
INTRODUCTION AND EPIDEMIOLOGY

About  million patients with chest pain present to a U.S. ED each year. Of these, more than 50% are placed into an observation unit or admitted to the
2­6 hospital, yet only about 10% are eventually diagnosed with an acute coronary syndrome (ACS). Still, approximately 2% of patients with acute
 myocardial infarctions (AMIs) are not diagnosed on initial presentation to the ED. We discuss the features and approach that help differentiate ACS from other causes of chest pain. Chapter , “Acute Coronary Syndromes,” and Chapter , “Low­Probability Acute Coronary Syndromes,” discuss management of these specific syndromes.
Acute chest pain is the recent onset of pain, pressure, or tightness in the anterior thorax between the xiphoid, suprasternal notch, and both midaxillary lines. ACS includes AMI and acute ischemia (unstable angina). AMI is defined by myocardial necrosis, evident from elevation of cardiac biomarkers, and is classified by ECG findings into ST­segment elevation myocardial infarction (STEMI) or non–ST­segment elevation myocardial infarction (NSTEMI). Unstable angina is a clinical diagnosis defined by chest pain or an equivalent (neck, upper extremity pain) from inadequate myocardial perfusion that is new or occurring with greater frequency, less activity, or at rest. Patients with unstable angina do not have pathologic ST­ segment elevation on ECG or cardiac biomarker elevation, but they are at risk of eventual myocardial damage absent recognition and treatment.
PATHOPHYSIOLOGY
The chest wall, from the dermis to the parietal pleura, is innervated by somatic pain fibers. Neurons enter the spinal cord at specific levels corresponding to the skin dermatomes. Visceral pain fibers are found in internal organs, such as the heart, blood vessels, esophagus, and visceral pleura. Visceral pain fibers enter the spinal cord and map to areas on the parietal cortex corresponding to cord levels shared with somatic fibers.
Stimulation of visceral or somatic afferent pain fibers results in two distinct pain syndromes. Pain from somatic fibers is usually easily described, precisely located, and often experienced as a sharp sensation. Pain from visceral fibers is generally more difficult to describe and imprecisely localized.
Patients with visceral pain are more likely to describe it as discomfort, heaviness, pressure, tightness, or aching. Visceral pain is often referred an area of the body corresponding to adjacent somatic nerves, which explains why pain from an ACS may radiate to the neck, jaw, or arms. Factors such as age, sex, comorbid illnesses, medications, drugs, and alcohol may interact with psychological and cultural factors to alter pain perception and communication.
CLINICAL FEATURES
INITIAL ASSESSMENT
Patients with abnormal vital signs, ECG findings of ischemia or injury, a history of prior coronary artery disease, multiple atherosclerotic risk factors, or any abrupt, new, or severe chest pain or dyspnea should be quickly placed into a treatment bed. Initiate cardiac monitoring and IV access, and obtain an ECG, ideally within  minutes of arrival. Identify and treat immediate life needs such as supporting the airway, breathing, and circulation. Measure vital signs promptly and at regular intervals. Administer oxygen if ambient saturation is <94%.
Next, focus on history, physical exam, and laboratory findings associated with cardiac (ACS) versus noncardiac chest pain causes. Obtain a directed history of symptoms, abridged past medical history, and review of systems seeking features of life­threatening causes of chest pain, such as ACS, aortic dissection, pulmonary embolism (PE), severe pneumonia, and esophageal rupture. Ask about the onset, timing, severity, radiation, and character of the chest pain; alleviating and exacerbating factors; and presence of associated symptoms, such as diaphoresis, dyspnea, nausea, vomiting, palpitations, and dizziness.

The physical examination seeks findings to aid in detecting life­threatening or common causes of chest pain. Inspect the thorax for prior surgical
Chapter 48: Chest Pain, Lane M. Smith; Simon A. Mahler i©n2ci0s2io5n Ms, ccGherastw w Haillll .d Aelflo Rrmigihtitess R, aensde rsvyemdm. e Ttreircm riss eo fa Unds efa * l lP wriivtha creys Ppoirlaictyio * n .N Poatlicpea t * e Athcec echsseisbti lwitayll for tenderness, masses, or crepitus. Auscultate to identify chest consolidation or pneumothorax, murmurs, gallops, or friction rubs, and obtain a chest radiograph to identify immediate life­threatening processes.
HISTORY
Patients with serious and life­threatening intrathoracic disorders, including ACS, may report pain outside the chest, such as in the epigastrium, neck, jaw, shoulders, or arms. Some patients never experience chest pain or have migratory pain that is no longer in the chest at the time of medical evaluation. Patients with AMI who present without chest pain have diagnostic and treatment delays and have an in­hospital mortality rate more than
 twice that of AMI patients with chest pain.
Classic Chest Pain
Terms such as typical and atypical symptoms are misleading because symptoms among patients with ACS vary and may not include classic findings.
Classic cardiac chest pain is retrosternal left anterior chest crushing, squeezing, tightness, or pressure. Cardiac chest pain is often brought on by or exacerbated by exertion and relieved by rest. Traditional teaching is that anginal pain lasts  to  minutes, unstable angina pain lasts  to  minutes, and pain from AMI often lasts longer than  minutes, but great overlap exists. Other classic features of ACS presentations include radiation of the pain
 to the arms, neck, or jaw; diaphoresis; dyspnea; and nausea or vomiting.
Nonclassic Chest Pain
The absence of classic symptoms contributes to delays in seeking care and in evaluation.
Nonclassic presentations are common and include chest pain lasting for seconds, constant pains lasting for  to  hours or more without waxing and waning intensity, or pain worsened by specific body movements or positions, such as twisting and turning of the thorax. Reports of stabbing, welllocalized, positional, or pleuritic chest pain are uncommon with ACS but do not exclude it with certainty. The Multicenter Chest Pain Study reported
 that 22% of patients with AMI described their chest pain as sharp or stabbing. Nonclassic presentations of ACS occur more frequently in women, racial minorities, diabetics, the elderly, and patients with psychiatric disease or altered mental status than in other patient
,10,11 groups. Multiple prescription medications, drugs, alcohol, patient or provider sex, and cultural differences can impact the pain perception or
12­14  reporting of symptoms. For example, the term sharp in some cultures is interpreted to mean severe, rather than knife­like.
Pre­ and early menopausal women with ACS are more likely to present with pain unrelated to exercise, pain not relieved by rest or nitroglycerin,
 pain relieved by antacids, palpitations without chest pain, or a chief complaint of fatigue. Associated symptoms of nausea, emesis, jaw pain, neck
 pain, and back pain are more common in women with ACS, whereas diaphoresis is more common among men.
Anginal or Ischemic Symptom Equivalents
One large public hospital reported that 47% of 721 consecutive patients with myocardial infarction presented complaining of symptoms other than
 chest pain. These symptoms include dyspnea at rest or with exertion, nausea, lightheadedness, generalized weakness, acute changes in mental status, diaphoresis, or shoulder, arm, or jaw discomfort. Patients with dyspnea have a fourfold increased risk of sudden death from cardiac causes
 compared with asymptomatic patients and a twofold increased risk compared with patients with classic angina.
Epigastric or upper abdominal discomfort, even when relieved with antacids, raises suspicion for ACS, especially for patients >50 years old or those with known coronary artery disease. In these two high­risk groups, include an ECG in routine evaluation of abdominal pain. Consider ACS in patients presenting with new palpitations, because myocardial ischemia may increase automaticity and irritability, leading to dysrhythmias. Furthermore, tachycardia can cause an increase in myocardial oxygen demand, triggering myocardial ischemia.
Risk Factors
Major risk factors for coronary artery disease include age >40 years old, male or postmenopausal female, hypertension, tobacco use,
,19 hypercholesterolemia, diabetes, truncal obesity, family history, and a sedentary lifestyle. Cocaine use is associated with AMI even in young people
 with minimal or no coronary artery disease, and chronic cocaine use may accelerate atherosclerosis and severe coronary artery disease. Despite this
,22 association, patients with acute chest pain and concomitant cocaine use have low rates of adverse outcomes. Human immunodeficiency virus
 infection and treatment with highly active antiretroviral therapy can accelerate atherosclerosis.
While cardiac risk factors are useful in predicting coronary artery disease risk within a given population, they are less useful for diagnosing the
,24,25 presence or absence of ACS in an individual patient. Patients with known coronary artery disease and prior ACS are at risk for another ACS event; therefore, identify previous episodes of chest pain; prior echocardiography, stress testing, or coronary angiography; or prior revascularization (stent placement or coronary artery bypass graft surgery).
AMI SIGNS AND SYMPTOMS: LIKELIHOOD RATIOS
There are no historical features with sufficient sensitivity and specificity to either diagnose or exclude ACS. Radiation to the arms and shoulders,
,26,27 particularly to the right arm or both arms, and exertional chest pain are the historical features most strongly associated with ACS. Dyspnea,
,27 diaphoresis, and nausea or vomiting are also associated with ACS but are less predictive. Pressure­like chest sensation also has a limited value in
  the prediction of ACS. Sharp, pleuritic, positional chest pain is associated with a decreased likelihood of ACS, but cannot eliminate the diagnosis.
,27
Lack of exertional pain or pain radiation has no diagnostic value for exclusion of ACS. Since classic cardiac ischemic pain is not universal, and men and women both present with nonclassic symptoms, the diagnostic utility of specific chest pain descriptions does not differ significantly between men
 and women. Tables 48­1 and 48­2 summarize the chest pain characteristics associated with increased or decreased likelihood ratios of ACS.
TABLE 48­1
Acute Myocardial Infarction–Associated Symptoms
Pain Descriptor Study Positive Likelihood Ratio or Odds Ratio (95% CI)
Radiation to right arm or shoulder Body et al. .31 (1.52–3.53)
Radiation to both arms or shoulders Body et al. .58 (1.53–4.34)
Associated with exertion Hess et al. .81 (2.23–3.54)
Radiation to left arm Body et al. .36 (0.89–2.09)
Associated with diaphoresis Hess et al. .50 (1.16–1.94)
Associated with nausea or vomiting Hess et al. .89 (0.68–1.18)
Described as pressure/squeezing Hess et al. .52 (1.21–1.91)
Similar to previous ischemia Hess et al. .35 (2.65–4.24)
Source: Data from Body R, Carley S, Wibberley C, et al: The value of symptoms and signs in the emergent diagnosis of acute coronary syndromes. Resuscitation 81:
281­6, 2010; and Hess EP, Brison RJ, Perry JJ, et al: Development of a clinical prediction rule for 30­day cardiac events in emergency department patients with chest pain and possible acute coronary syndrome. Ann Emerg Med 59: 115­25, 2012. TABLE 48­2
Symptoms Not Associated With Acute Myocardial Infarction
Pain Descriptor Study Odds Ratio (95% CI)
Described as pleuritic Goodacre et al. .5 (0.1–2.1)
Described as worse with movement Hess et al. .69 (0.50–0.95)
Described as sharp Hess et al. .42 (0.30–0.59)
Tender chest wall Goodacre et al. .2 (0.1–1.0)
Radiation to abdomen Hess et al. .34 (0.08–1.42)
Not associated with exertion Goodacre et al. .8 (0.6–0.9)
Source: Data from Goodacre S, Locker T, Morris F, Campbell S: How useful are clinical features in the diagnosis of acute, undifferentiated chest pain? Acad Emerg Med
9: 203, 2002; and Hess EP, Brison RJ, Perry JJ, et al: Development of a clinical prediction rule for 30­day cardiac events in emergency department patients with chest pain and possible acute coronary syndrome. Ann Emerg Med 59: 115­25, 2012. PHYSICAL EXAMINATION
The examination of patients with ACS is often normal, and there are no exam findings that diagnose or exclude ACS. Use the exam in conjunction with history to search for other causes and guide therapy.
Vital sign abnormalities from ACS may include hyper­ or hypotension, tachycardia, or bradycardia. Tachycardia may result from increased sympathetic tone and decreased left ventricular stroke volume. Bradycardia may occur due to ischemia or infarction involving the conduction system or alterations in sympathetic and parasympathetic activation of the sinoatrial or atrioventricular nodes. Patients with acute myocardial ischemia or infarction may have abnormal heart sounds due to changes in ventricular function or compliance, such as an S or S gallop, diminished S , or a paradoxically split S .

New murmurs in patients with chest pain may be associated with AMI with chordae tendineae rupture or aortic root dissection. Ischemia­induced congestive heart failure may produce crackles on auscultation of the lungs.
Physical examination findings most strongly associated with AMI in patients presenting with acute chest pain are hypotension, S gallop, and

 diaphoresis; however, the frequency, interrater reliability, and added diagnostic value of these are limited. Reproducible chest wall tenderness
 suggests a musculoskeletal etiology, but is reported in up to 15% of patients with confirmed AMI and cannot exclude the diagnosis of ACS.
RESPONSE TO THERAPY
Response to medications poorly discriminates between cardiac and noncardiac chest pain. Although nitroglycerin reduces anginal pain, it may also
30­32 relieve the pain from noncardiac conditions such as esophageal spasm. Similarly, relief from an antacid agent, alone or in combination with other
 agents, does not eliminate a cardiac cause of pain.
DIAGNOSIS
Life­threatening concerns in acute chest pain are ACS, aortic dissection, PE, pneumonia, tension pneumothorax, and esophageal rupture. Other diagnoses with the potential for morbidity and mortality include simple pneumothorax, myocarditis, pericarditis, aortic stenosis, perforated ulcer, pancreatitis, and cholecystitis. Benign causes of chest pain include anxiety, musculoskeletal pain, esophagitis, and gastritis. Common causes of chest pain are listed in Table 48­3. Table 48­4 summarizes the classic symptoms of the life­threatening causes of acute chest pain.
TABLE 48­3
Common Causes of Acute Chest Pain
Visceral Pain Pleuritic Pain Chest Wall Pain
Typical angina Pulmonary embolism Costosternal syndrome
Unstable angina Pneumonia Costochondritis (Tietze’s syndrome)
Acute myocardial infarction Spontaneous pneumothorax Precordial catch syndrome
Aortic dissection Pericarditis Xiphodynia
Esophageal rupture Pleurisy Radicular syndromes
Esophageal reflux or spasm Intercostal nerve syndromes
Mitral valve prolapse Fibromyalgia
TABLE 48­4
Classic Symptoms of Potentially Life­Threatening Causes of Chest Pain* Disorder Pain Location Pain Character Radiation Associated Signs and Symptoms
Acute coronary Retrosternal, left chest, Crushing, tightness, Right or left shoulder, right or Dyspnea, diaphoresis, nausea syndrome or epigastric squeezing, pressure left arm/hand, jaw
Pulmonary Focal chest Pleuritic None Tachycardia, tachypnea, hypoxia, may embolism have hemoptysis
Aortic dissection Midline, substernal Ripping, tearing Intrascapular area of back Secondary arterial branch occlusion
Pneumonia Focal chest Sharp, pleuritic None Fever, hypoxia, may see signs of sepsis
Esophageal Substernal Sudden, sharp, after Back Dyspnea, diaphoresis, may see signs rupture forceful vomiting of sepsis
Pneumothorax One side of chest Sudden, sharp, lancinating, Shoulder, back Dyspnea pleuritic
Pericarditis Substernal Sharp, constant or pleuritic Back, neck, shoulder Fever, pericardial friction rub
Perforated Epigastric Severe, sharp Back, up into chest Acute distress, diaphoresis peptic ulcer
*Atypical presentations are common.
PULMONARY EMBOLISM
Symptoms of PE include sharp chest pain (may worsen with inspiration, called “pleuritic”), dyspnea, hypoxemia, syncope, or shock. There may be associated cough or hemoptysis. Patients with PE may be febrile (fever often not very high if present) or have leg swelling or pain, and some patients will report chest wall tenderness. Common physical examination findings include tachypnea, tachycardia, and hypoxemia. PE risk factors include recent surgery, trauma, prolonged immobility, active cancer, estrogens from birth control pills or hormone replacement therapy (particularly when
 combined with smoking), procoagulant syndromes, or a history of prior PE or deep venous thrombosis.

Clinical decision aids, such as the Wells and Revised Geneva Scores, can risk­stratify patients with possible PE. The Pulmonary Embolism Rule

Out Criteria exclude PE in patients with a low pretest probability without further diagnostic testing. Normal D­dimer testing, measured by a sensitive enzyme­linked immunosorbent assay, in a hemodynamically stable, low­ to intermediate­risk patient (with a Revised Geneva Criteria Score of
,38
 to 10) effectively excludes PE; in those with higher risk assessment, a negative D­dimer has limited value. In patients with PE, elevated cardiac
 troponin indicates ventricular dysfunction and identifies patients with an elevated risk of death and complications.
In PE, ECG findings are nonspecific, with the most common finding being sinus tachycardia.
Chest radiographs often have nonspecific changes, but in rare cases, they may show signs of pulmonary infarction. CT pulmonary angiography is the test of choice and is highly sensitive for the detection of large to medium­sized PEs. See more details on PE in Chapter , “Venous Thromboembolism
Including Pulmonary Embolism.”
AORTIC DISSECTION
Pain from aortic dissection is classically described as a ripping or tearing sensation radiating to the interscapular area of the back. The pain is often sudden in onset, maximal at the time of symptom onset, and may migrate or be noted above and below the diaphragm. Lack of sudden­onset pain
 decreases the probability of aortic dissection but cannot exclude it. Secondary symptoms of aortic dissection result from arterial branch occlusions and include stroke findings (lateralizing weakness or sensory changes), AMI, or limb ischemia. Risk factors include male sex, age over  years, poorly controlled hypertension, cocaine or amphetamine use, a bicuspid aortic valve or prior aortic valve replacement, certain connective tissue disorders

(Marfan’s syndrome and Ehlers­Danlos syndrome), and pregnancy. Physical exam findings for aortic dissection lack sensitivity and specificity. A unilateral pulse deficit of the carotid, radial, or femoral arteries suggests aortic dissection in the setting of acute chest pain (likelihood ratio, ; 95%
 confidence interval,  to 86). Focal neurologic deficits are rare, occurring in only 16% of patients with aortic dissection, but the combination of chest
 pain and a focal neurologic deficit increases the likelihood of aortic dissection. Although a completely normal chest radiograph lowers the likelihood, it does not exclude dissection (sensitivity, .4%; 95% confidence interval, .5 to .3). A normal D­dimer level also lowers the probability of aortic
 dissection (detecting the clot/declotting expected), but it also cannot exclude the disease. ECG changes are common among patients with aortic
,44 dissection, with up to 40% to 50% presenting with ST­segment or T­wave changes, but there is no diagnostic pattern. Elevated troponin among
 patients with aortic dissection is associated with increased mortality. When aortic dissection is suspected, obtain a CT aortogram or transesophageal echocardiogram. See Chapter , “Aortic Dissection and Related Aortic Syndromes.”
PNEUMONIA
Pneumonia is potentially life threatening in the elderly, immunocompromised, or patients with multiple comorbid conditions. Chest pain from
 pneumonia is usually described as sharp or pleuritic and associated with fever, cough, sputum production, and possibly hypoxemia. Auscultation may reveal decreased breath sounds, rales, or bronchial breath sounds over the affected areas of consolidation. A chest radiograph usually confirms the diagnosis. See Chapter , “Community­Acquired Pneumonia, Aspiration Pneumonia, and Noninfectious Pulmonary Infiltrates.”
ESOPHAGEAL RUPTURE (BOERHAAVE’S SYNDROME)
Patients classically present with a history of sudden­onset sharp substernal chest pain following forceful vomiting. Patients with esophageal rupture are usually ill­appearing and may be tachycardic, febrile, dyspneic, or diaphoretic. Physical examination may reveal crepitus in the neck or chest from subcutaneous emphysema. Hamman’s crunch, audible crepitus that varies with the heartbeat on auscultation of the precordium, is a rare finding associated with pneumomediastinum. Chest radiography could show a pleural effusion (left more common than right), pneumothorax, pneumomediastinum, pneumoperitoneum, or subcutaneous air, although a normal radiograph cannot exclude esophageal rupture. When suspecting esophageal rupture, obtain a CT with oral water­soluble contrast. See Chapter , “Esophageal Emergencies.”
SPONTANEOUS PNEUMOTHORAX
The symptoms of spontaneous pneumothorax are sudden­onset, sharp, pleuritic chest pain with dyspnea. Classically, spontaneous pneumothorax occurs in tall, slender males. Risk factors for spontaneous pneumothorax include smoking and chronic lung diseases such as asthma and chronic
 obstructive pulmonary disease. Approximately 1% to 3% of patients with a spontaneous pneumothorax may develop a tension pneumothorax.
Auscultation may reveal decreased breath sounds and hyperresonance to percussion on the ipsilateral side. However, the physical exam findings of a simple pneumothorax are inconsistent and cannot be used to exclude presence, with the diagnosis made by chest radiography. See Chapter ,
“Pneumothorax.”
ACUTE PERICARDITIS
Pain from acute pericarditis is classically described as a sharp, severe, constant pain with a substernal location. The pain may radiate to the back, neck, or shoulders; is worsened by lying flat and by inspiration; and is relieved by sitting up and leaning forward. A pericardial friction rub is the most specific
 physical exam finding, but is not always evident. The classic ECG findings are diffuse ST­segment elevation with PR depression. See Chapter ,
“Cardiomyopathies and Pericardial Disease.”
MITRAL VALVE PROLAPSE
Symptoms attributed to mitral valve prolapse include sharp chest pain, palpitations, fatigue, anxiety, and dyspnea unrelated to exertion. A midsystolic click may be heard on auscultation. However, most patients are asymptomatic and have no consistent association of chest pain, dyspnea, or anxiety
,50 with the disorder. See Chapter , “Valvular Emergencies.”
CHEST WALL PAIN
Musculoskeletal or chest wall pain is characterized by sharp, highly localized, and positional pain. The pain should be completely reproducible by light to moderate palpation or by specific movements and may be increased by inspiration or coughing. However, chest wall tenderness is also reported by some patients with ACS and PE. Costochondritis (Tietze’s syndrome) is an inflammation of the costal cartilages or their sternal articulations and causes chest pain that is variably sharp, dull, and often increased with respirations. Xiphodynia is inflammation of the xiphoid process that causes sharp, pleuritic chest pain reproduced by light palpation. Texidor twinge or precordial catch syndrome is a short, lancinating chest pain occurring in bunches lasting  to  minutes near the cardiac apex and is associated with inspiration, poor posture, and inactivity. Pleurisy is inflammation of the parietal pleura resulting in sharp pleuritic chest pain.
GI PAIN

GI disorders often cannot be reliably differentiated from ACS by history and physical examination alone. Gastritis and esophageal reflux typically produce burning or gnawing pain in the lower half of the chest, with a brackish or acidic taste in the back of the mouth. The pain may be lessened with antacids and exacerbated by recumbency. Peptic ulcer disease is classically described as a postprandial, dull, boring pain in the epigastric region.
Patients often describe being awakened from sleep by discomfort. Duodenal ulcer pain may be relieved after eating food, whereas gastric ulcer pain is often exacerbated by eating. Antacid medications usually provide symptomatic relief. Acute pancreatitis and biliary disease typically present with right upper quadrant or epigastric pain and tenderness, but can also cause chest pain. Esophageal spasm is often associated with reflux disease and is characterized by a sudden onset of dull or tight substernal chest pain. The pain is frequently precipitated by consumption of hot or cold liquids or a large food bolus and may be relieved by nitroglycerin. See Chapter , “Esophageal Emergencies,” and Chapter , “Peptic Ulcer Disease and Gastritis.”
PANIC DISORDER
Panic disorder is characterized by recurrent, unexpected, and discrete periods of intense fear or discomfort (panic attacks) with at least four of the following symptoms: chest pain, dyspnea, palpitations, diaphoresis, nausea, tremor, choking, dizziness, fear of losing control or dying, paresthesias, chills, or hot flashes. In one study, 25% of ED patients with chest pain met diagnostic criteria for panic disorder. Conversely, 9% of the patients
 identified as having panic disorder were ultimately diagnosed with ACS on hospital discharge. This means panic disorder is best a diagnosis of exclusion or a co­diagnosis with ACS (or another cause). Do not assume panic disorder in a patient with chest pain in the ED until further testing allows better risk stratification. See Chapter 289, “Mood and Anxiety Disorders.”
DIAGNOSTIC TESTING
Focus initial diagnostic testing for patients with chest pain on the exclusion or confirmation of serious pathology based on the differential diagnosis drawn from the history and physical examination. When history and exam make ACS a potential cause, testing commonly includes an ECG, chest radiograph, and cardiac biomarkers. Stress testing, advanced cardiac imaging, serial or continuous ECG monitoring, and serial cardiac biomarker measurements are discussed in Chapter , “Low­Probability Acute Coronary Syndrome.”
IMAGING
Chest radiography is commonly performed in the evaluation of ED patients with chest pain. Most patients with ACS have a normal chest radiograph,
 but the images are useful to diagnose or exclude other conditions such as pneumonia and pneumothorax. Other imaging modalities such as CT help evaluate conditions such as aortic dissection or PE.
ECG

Guidelines recommend a screening ECG within  minutes of ED arrival in patients with chest pain or other symptoms concerning for ACS. Rapid ECG
54­58 screening limits delays in identifying STEMI, allows more rapid time to reperfusion, and improves patient outcomes.
Fewer than 5% of patients presenting to the ED with chest pain have evidence of a STEMI on ECG. ,60 However, new ST­segment elevation of ≥1 mm in
 at least two contiguous leads represents an AMI that will benefit from rapid reperfusion interventions. ST­segment elevation also occurs in patients with pericarditis, myocarditis, early repolarization, left ventricular hypertrophy, and ventricular aneurysms. New ST­segment depression and T­wave
 inversions are also associated with an increase in risk of AMI.
A normal ECG lacks the sensitivity to exclude ACS, notably unstable angina or NSTEMI. In a large, multicenter, observational study of
391,208 patients with an evaluable ECG and diagnosis of AMI, 57% had “diagnostic” ECG changes, 35% had nonspecific changes, and 8% had normal

ECGs. Diagnostic changes were defined as ST­segment elevation, ST­segment depression, or left bundle branch block. Other studies document
62­65 normal or near­normal ECGs in 5% to 10% of patients with AMI. A normal ECG is also an independent risk factor for missed AMI and inappropriate

ED discharge (odds ratio, .7; 95% confidence interval, .9 to .2). However, among young patients (<40 years old) without known coronary artery
 disease, a normal ECG is associated with a cardiovascular event rate of <1% at  days.

Misinterpretation of ECGs or failure to detect ischemic changes that are present occurs in up to 40% of missed AMI cases. Furthermore, the initial ECG represents only a single time point in a dynamic pathophysiologic process. Thus, if there is a high concern for ACS, the ECG should be repeated at 15­
 to 30­minute intervals and compared to prior ECGs.
CARDIAC BIOMARKERS
Cardiac Troponins
Cardiac troponins (cTn) are proteins essential to cardiac muscle contraction that are complexed with actin and myosin filaments within cardiac
 myofibrils and are present within cardiac myocyte cytoplasm. Myocardial injury resulting in the disruption of myocyte cell membrane integrity or myofibril destruction results in extracellular cTn leak, which can be detected in the patient’s peripheral blood and used to identify and quantify
 myocardial damage. Due to its high sensitivity and nearly complete cardiac specificity, cTn is the biomarker of choice for the detection of myocardial
 injury.
Although cTn elevation is specific for myocardial injury, elevation does not indicate the mechanism of injury. There are numerous nonischemic causes of cTn elevations, which are summarized in Table 48­5. AMI can be differentiated from nonischemic cTn elevations based on the pattern of cTn elevation and the clinical context. The diagnostic criteria for AMI includes a gradual rise and fall of cTn with a maximum value above the 99th percentile of a reference population (the upper reference limit), combined with any of the following: symptoms consistent with ischemia, characteristic acute ECG changes (ST­segment and T­wave changes, new left bundle branch block, or new Q waves), or imaging evidence of a new regional wall motion
 abnormality or new loss of viable myocardium. cTn testing has made older cardiac biomarkers, such as myoglobin and creatine kinase­MB, obsolete in ACS care.
TABLE 48­5
Conditions Associated With Elevated Cardiac Troponin Levels in the Absence of Ischemic Heart Disease
Cardiac contusion
Cardiac procedures (surgery, ablation, pacing, stenting)
Acute or chronic congestive heart failure
Aortic dissection
Aortic valve disease
Hypertrophic cardiomyopathy
Arrhythmias (tachy­ or bradyarrhythmia)
Apical ballooning syndrome
Rhabdomyolysis with cardiac injury
Pulmonary hypertension
Pulmonary embolism
Acute neurologic disease (e.g., stroke, subarachnoid hemorrhage)
Myocardial infiltrative diseases (amyloid, sarcoid, hemochromatosis, scleroderma)
Inflammatory cardiac diseases (myocarditis, endocarditis, pericarditis)
Drug toxicity
Respiratory failure
Sepsis
Burns
Extreme exertion (e.g., endurance athletes)
Immunoassays have been developed for the isoforms of cTnI and cTnT. Isoforms I and T provide nearly identical information except in the setting of
,71 renal failure, where elevation in cTnT is more common than cTnI. A single manufacturer produces the cTnT assay; however, multiple manufacturers produce cTnI assays, which differ in their upper reference limits (the cTn value above the 99th percentile of a reference population),
72­74 coefficients of variability, and lower limits of detection.
Recently developed fifth­generation assays, commonly referred to as high­sensitivity troponin assays, have a 10­fold higher analytical sensitivity
 compared to previous assays. The first of these assays, which have upper reference limits ranging from  to  ng/L, were approved by the U.S. Food
,77 and Drug Administration in 2017. In comparison with preceding assays, high­sensitivity cTn assays are more sensitive for the detection of AMI (94%
,79 to 96% vs. 85% to 90%) and increase the early detection of myocardial injury. Among patients presenting within  hours of chest pain onset, high­
 sensitivity cTn assays are 92% to 94% sensitive for AMI compared to 76% for the previous assay. However, the increased sensitivity of high­sensitivity
,77,78 cTn assays for AMI also creates the potential of oversensitivity and unneeded care by detecting more patients with non­AMI cTn elevations.
The prognostic value for populations with elevated cTn levels is clear. A meta­analysis of ,982 patients with ACS found that an elevated cTn was
 associated with an increased risk of cardiac death or AMI at  days (odds ratio, .4; 95% confidence interval, .9 to .0). Even in the absence of chest
 pain, elevations in cTn portend a worse prognosis at  days and  year that is independent of ECG findings. Higher cTn elevations impart a stronger risk for adverse events, and even patients with minimally detectible cTn (below the upper reference limits) are at greater risk for adverse events than
 those with undetectable cTn.
Patients with renal disease often have an elevated cTnT (15% to 50%), whereas cTnI elevations are less common (<10%). After dialysis, serum levels
 of cTnT generally increase, whereas cTnI levels decrease. Despite these features, cTnT and cTnI assays remain highly sensitive for AMI in patients with renal failure, particularly when new measures can be compared to baseline measures. Furthermore, renal failure patients with elevated cTn levels
 are at higher risk for death and adverse events than patients with normal cTn levels.

Obtain cardiac cTn levels in all patients with suspected ACS. A single fourth­generation cTn assay will identify most patients (approximately 80%) with
AMI within  to  hours of ED arrival, and the sensitivity of two high­sensitivity cTn samples drawn within  hours of presentation approaches 100% for
,79,85 
AMI. Thus, serial measurements of cTn are generally needed to safely exclude AMI in most patients presenting with chest pain. AMI may safely be excluded with a single cTn in select, low­risk patients with constant symptoms for >6 to  hours. Rapid diagnostic pathways using short interval
86­89 testing (1 to  hours) or a single high­sensitivity cTn evaluation to exclude AMI are being used in Europe, but U.S. data are limited.
B­Type Natriuretic Peptide
Natriuretic peptide elevations are not specific to myocardial ischemia or infarction, and rise with any ventricular dysfunction. Patients with ACS and an elevated natriuretic peptide level have higher short­term mortality, although the lab test does not aid in specific patient management actions.
Other Biomarkers
Troponin testing has made older cardiac biomarkers, such as myoglobin and creatine kinase­MB, obsolete in ACS care. High­sensitivity C­reactive
 protein aids in long­term cardiac event prediction, but this test is not recommended for ED care (Figure 48­1). A variety of other assays have been studied as cardiac biomarkers, such as ischemia­modified albumin, interleukin­6, vascular cell adhesion molecule, intercellular adhesion molecule, E­ selectin, P­selectin, pregnancy­associated plasma protein A, myeloperoxidase, copeptin, and heart­type fatty acid binding protein. Current evidence does not support the use of these novel biomarkers for ED chest pain evaluations.
FIGURE 48­1. Typical pattern of cardiac troponin elevation after acute myocardial infarction (AMI). URL = upper reference limit.


