## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 187: Cocaine and Amphetamines
Rachel S. Wightman; Jeanmarie Perrone
INTRODUCTION
Historical records of indigenous cultures in South America describe early stimulant use by chewing leaves of the Erythroxylum coca plant, a practice that continues today. Cocaine was first used therapeutically in 1884 for ophthalmologic procedures, accompanied closely by reports of severe toxicity.
Amphetamines were synthesized in 1887, and in 1932, they were marketed medicinally in an inhaler form as a bronchodilator. Use of methamphetamine to enhance physical and intellectual performance began in the 1930s. Amphetamines were widely used as an alertness aid for troops by both Allied and Axis powers during World War II. Today, cocaine and amphetamines have limited therapeutic roles but are widely used as drugs of abuse. Clinical effects and toxicity are due to sympathetic nervous system stimulation.
PHARMACOLOGY
COCAINE
Cocaine is the naturally occurring alkaloid found in E. coca, a plant indigenous to South America. The water­soluble hydrochloride salt is absorbed across all mucosal surfaces, including oral, nasal, GI, and vaginal epithelium; cocaine can thus be topically applied, swallowed, or injected IV. The hydrochloride salt (powder) form is most often insufflated (snorted) or dissolved in water and injected IV; it degrades rapidly when pyrolyzed.
Freebase cocaine can be smoked because it melts at a much lower temperature and can be prepared in many ways. A common method uses an alkali, such as sodium bicarbonate, to produce “crack cocaine,” which, when smoked, produces the popping sound that characterizes its name. The onset and duration of action vary with the route of administration (Table 187­1).
TABLE 187­1
Pharmacokinetics of Cocaine
Route of Exposure Onset of Action Peak Action Duration of Action
IV <1 min 3–5 min 30–60 min
Nasal insufflation (snorting) 1–5 min 20–30 min 60–120 min
Inhalation (smoking) <1 min 3–5 min 30–60 min
GI 30–60 min 60–90 min Unknown
Source: Reproduced with permission from Hoffman RS, Howland MA, Lewin NA, Nelson LS, Goldfrank LR: Goldfrank’s Toxiciologic Emergencies, 10th ed. © 2015 by
McGraw­Hill, Inc., New York.
When cocaine is insufflated nasally, the delayed and prolonged effect is a result of vasoconstrictive properties that limit mucosal absorption followed by swallowing a portion of the insufflated cocaine, which is then absorbed from the stomach. GI absorption is also prolonged by vasoconstriction, producing delayed peak effect.
Cocaine is primarily metabolized to ecgonine methyl ester by plasma cholinesterase. Relative deficiency of this enzyme may predispose affected pDaotwiennltosa tdoe ldif e2­0th2r5e­a7t­e1n i6n:g2 7to Pxi c Yitoy.u1r B IePn izso 1y3le6c.g1o4n2i.n1e5 i9s. 1th2e7 other major metabolite excreted in the urine and is the target compound detected in
Chapter 187: Cocaine and Amphetamines, Rachel S. Wightman; Jeanmarie Perrone routine urine toxicology screens. Cocaethylene is a long­acting metabolite formed when cocaine is used in combination with ethanol. Cocaethylene
. Terms of Use * Privacy Policy * Notice * Accessibility has vasoconstrictive properties similar to those of cocaine.
,3
Cocaine is both a CNS stimulant and a local anesthetic. Central effects are mediated by enhancement of excitatory amino acids and blockade of presynaptic reuptake of norepinephrine, dopamine, and serotonin. The excess of neurotransmitters at postsynaptic receptor sites leads to sympathetic activation, producing the characteristic physical findings of mydriasis, tachycardia, hypertension, and diaphoresis, and predisposing to dysrhythmias, seizures, and hyperthermia. Cocaine use produces a euphoria associated with enhanced alertness and a general sense of well­being. It is thought that the psychological addiction, drug craving, and withdrawal effects are mediated by interference with dopamine and serotonin balance in the CNS. Subsequent dopamine depletion at the nerve terminals may account for the dysphoria and depression associated with long­term abuse.
Like other local anesthetics, cocaine inhibits conduction of nerve impulses by blocking fast sodium channels in the cell membrane. In cardiac myocytes, cocaine inhibits rapid inward sodium channels causing QRS prolongation and can also block potassium channels resulting in QT c prolongation. Thus, in large doses, cocaine may exert a direct toxic effect on the myocardium, resulting in negative inotropy and wide­complex dysrhythmias.
AMPHETAMINES
Amphetamines compose a broad class of structurally similar derivatives of phenylethylamine. The derivative methamphetamine, also known as “ice,” is abused by ingestion, IV injection, inhalation, or nasal insufflation. Absorption and peak effects vary with the route (Table 187­2). Modification of the
,5 basic amphetamine structure produces substances with additional psychoactive properties. More than  such “designer” amphetamines have been created (Table 187­3), primarily for hallucinogenic effects (see Chapter 188, “Hallucinogens”). Methamphetamine and the designer amphetamines may have effects that persist for up to  hours or longer.
TABLE 187­2
Pharmacokinetics of Methamphetamine
Route of Exposure Onset of Action Peak Action Duration of Action
IV 15–30 s  min 10–12 h
Nasal insufflation (snorting) 3–5 min 1–2 h 10–12 h
Inhalation (smoking) 10–30 s 5–10 min 8–12 h
GI 15–20 min 2–3 h 10–12 h
TABLE 187­3
Commonly Abused Designer Amphetamines
Abbreviation Chemical Name
MDMA ,4­Methylenedioxymethamphetamine
MDA ,4­Methylenedioxyamphetamine
MDEA ,4­Methylenedioxyethamphetamine
PMA Paramethoxyamphetamine
DOB 4­Bromo­2,5­dimethoxyamphetamine
2CB 4­Bromo­2,5­dimethoxyphenylethylamine
STP or DOM 4­Methyl­2,5­dimethoxyamphetamine
Fenethylline (Captagon®) Amphetaminoethyltheophylline
Amphetamines enhance the release and block the reuptake of catecholamines at the presynaptic terminal and may also directly stimulate
 catecholamine presynaptic and postsynaptic receptors. Some amphetamine metabolites inhibit monoamine oxidase, increasing cytoplasmic
 concentrations of norepinephrine. Certain amphetamine derivatives can also induce release of serotonin and affect central serotonin receptors.
These serotonergic effects account for the hallucinogenic properties of some amphetamine derivatives such as MDMA (3,4­ methylenedioxymethamphetamine) and mescaline (3,4,5­trimethoxyphenethylamine). Downregulation of dopamine receptor activity with long­term use may contribute to the withdrawal phenomenon. Mortality from amphetamine toxicity is a result of hyperthermia, dysrhythmias, seizures, hypertension (intracranial hemorrhage or infarction), and encephalopathy.
Stimulants such as methylphenidate, ephedrine, pseudoephedrine, and phenylpropanolamine produce toxic syndromes similar to but generally less
8­13 severe than those caused by cocaine and amphetamines. The U.S. Food and Drug Administration–approved prescription stimulant medications for attention­deficit/hyperactivity disorder, such as methylphenidate and dextroamphetamine, are available in both immediate­ and extended­release formulations. Abusers may crush the extended­release tablet to separate the active agent from the extended­release matrix to achieve a rapid onset of
 action after insufflation or injection.
Synthetic (or substituted) cathinones, often termed “bath salts,” are designer drugs derived from naturally occurring amphetamine analogs found in the Catha edulis plant. Cathinones stimulate the release and block the reuptake of norepinephrine, dopamine, and serotonin at synapses in the brain,
15­17 producing stimulant effects similar to cocaine and amphetamines. Commonly abused substituted cathinones include mephedrone, methylenedioxypyrovalerone, and methylone, although the composition in bath salts sold for abuse varies widely.
CLINICAL FEATURES
The clinical features of cocaine and amphetamine toxicity are the result of their sympathomimetic, vasoconstrictive, psychoactive, and local anesthetic
2­4,6 properties affecting a variety of organ systems.
CARDIOVASCULAR

Cocaine induces dysrhythmias, myocarditis, cardiomyopathy (including takotsubo), and acute coronary syndromes. Other vascular complications include aortic rupture and aortic and coronary artery dissection. Even at relatively low doses, cocaine induces vasoconstriction in coronary arteries,
 contributing to cocaine­induced chest pain. Coronary vasoconstriction is exacerbated by β­adrenergic blockade and antagonized by phentolamine,
 which suggests mediation through stimulation of α­adrenergic receptors. This effect is potentiated by cigarette smoking, and risk is heightened in
,22 patients with preexisting coronary artery disease. In addition to promoting vasospasm and causing increased myocardial oxygen demand, cocaine predisposes to acute coronary syndrome by increasing atherogenesis through increased platelet aggregation, thrombogenesis, and accelerated atherosclerosis.
Most patients who suffer cocaine­associated acute coronary syndrome are nonwhite men between the ages of  and  years who smoke cigarettes and regularly use cocaine. These demographic characteristics encompass the majority of patients presenting with cocaine­associated chest pain,
23­25 making it difficult to predict those at greatest risk for myocardial infarction. However, a recent study of a nationwide inpatient sample of 363,143 admissions for cocaine­induced chest pain suggests female sex, age >50 years, history of heart failure, supraventricular tachycardia, endocarditis,
 tobacco use, dyslipidemia, coronary artery disease, or renal failure as predictors of myocardial infarction. All routes of cocaine administration are associated with chest pain, acute coronary syndrome, ST­segment elevation myocardial infarction, and non–ST­segment elevation myocardial infarction. Atypical chest pain is common.

Acute coronary syndromes and aortic dissection are also reported in association with ephedrine, phenylpropanolamine, and amphetamine use.
Mitral and aortic valve abnormalities associated with use of the amphetamine combination phentermine­fenfluramine prompted a voluntary recall of these appetite­suppressant drugs. Cardiopulmonary toxicity from other amphetamine diet aids has also been reported.
Dysrhythmias induced by cocaine can result from sympathomimetic stimulation, blockade of the sodium channel during depolarization, inhibition of
,28 the potassium channel during repolarization, and effects on calcium channel current. Sympathomimetic­induced dysrhythmias are tachycardias, such as sinus tachycardia, reentrant supraventricular tachycardia, and atrial fibrillation and flutter. Sodium channel blockade produces a rightward shift of the terminal portion of the QRS complex as seen on the frontal plane ECG leads (aVr with terminal R wave >3 mm and R/S ratio >0.7), a pattern
 similar to that of cyclic antidepressants. Progressive toxicity may induce a complete right bundle branch block or a prolonged QRS >120 milliseconds that, when combined with sinus tachycardia, produces a wide­complex tachycardia. Cocaine can induce the ECG appearance of the Brugada pattern, although it is not clear whether this is strictly a toxic effect or if the sodium channel–blocking effect of cocaine unmasks an underlying genetic
 predisposition to the Brugada syndrome.

Potassium channel blockade impairs repolarization, prolonging the QT interval on the ECG. The effects of cocaine on calcium channel current are dose dependent and complex, but at concentrations associated with clinical toxicity, prolongation of both depolarization and repolarization is seen, as
 well as enhanced dispersion in repolarization. Delayed repolarization and enhanced dispersion promote early afterpotentials that can trigger reentrant dysrhythmias, such as ventricular tachycardia and a variant, torsades de pointes.
Takotsubo syndrome, transient apical ballooning of the left ventricle, has been associated with cocaine use. The physiology is not clearly
,32 understood, but has been attributed to the effects of a sympathomimetic surge on the myocardium after cocaine use.
CNS
Neurologic syndromes associated with cocaine abuse include seizures, cerebral infarctions, and hemorrhages. Hyperadrenergic tone induces severe transient hypertension, hemorrhage, or focal vasospasm, and, sometimes, exacerbation of underlying abnormalities of cerebral blood vessels.

Cerebral vasoconstriction following cocaine administration has been observed using magnetic resonance angiography.
Other CNS manifestations reported after cocaine use include spinal cord infarctions, cerebral vasculitis, and intracranial abscesses. Choreoathetosis and repetitive movements (termed “crack dancing”) are associated with cocaine and amphetamine intoxication and appear related to dopamine dysregulation. Acute dystonic reactions following cocaine use and withdrawal are also observed. Unilateral blindness has been reported secondary to central retinal artery occlusion, and bilateral blindness can be caused by diffuse vasospasm. A syndrome of corneal abrasions and ulcerations secondary to smoke and irritation is known as “crack eye.” Keratitis caused by methamphetamine use has been described as well.
“Cocaine washout” is a syndrome that may occur in patients after a prolonged crack binge and results from depletion of neurotransmitters. Patients have a depressed level of consciousness but can be aroused to normal with stimulation. Resolution of lethargy can take up to  hours.
,6
Amphetamine, phenylpropanolamine, and ephedrine use are associated with intracranial hemorrhage, infarction, encephalopathy, and seizures.
Amphetamines can also cause a CNS vasculitis, resulting in focal neurologic deficits. A profound paranoid psychosis can be seen with long­term amphetamine abuse and withdrawal.
PULMONARY
Respiratory effects of cocaine use are more common in patients who smoke crack cocaine. Pulmonary hemorrhage, barotrauma, pneumonitis,
 asthma, and pulmonary edema have been observed. Pneumomediastinum, pneumothorax, and pneumopericardium result from barotrauma secondary to performance of the Valsalva maneuver after inhalation or nasal insufflation in an attempt to enhance drug effect. Pneumonitis, asthma, and bronchiolitis may be an immunologic phenomenon or may result from numerous adulterants in illicit preparations.
,36
Inhalation of crack cocaine is associated with new­onset bronchospasm, likely the result of local airway irritation. Acute lung injury associated with cocaine use is multifactorial and may be catecholamine mediated. A similar syndrome has been described in patients with adrenergic excess from pheochromocytoma and intracranial hemorrhage. Upper airway irritation and a “thermal” uvulitis can occur in patients smoking crack cocaine.
GI
Cocaine­induced mesenteric vasospasm may produce intestinal ischemia, bowel necrosis, ischemic colitis, and splenic infarctions. In addition, GI ulceration, bleeding, and perforation occur in association with cocaine use. Advanced tooth decay (termed “meth mouth”) is common in habitual methamphetamine users. The reasons are presumably multifactorial and are related to poor oral hygiene, persistent dry mouth, jaw clenching, and tooth grinding. The belief that contamination with acidic or corrosive substances from the manufacturing process is responsible for this condition is not supported by analysis of illicitly produced methamphetamine.
ENDOCRINE
MDMA users may develop hyponatremia due to drug­induced secretion of vasopressin in the setting of overhydration with water, which has been associated with several deaths. There is limited evidence suggesting that synthetic cathinones may cause similar effects.
RENAL
37­39
Cocaine or amphetamine use may cause traumatic and nontraumatic rhabdomyolysis. In cocaine­induced rhabdomyolysis, up to one third of
 patients develop acute kidney failure. Risk factors for rhabdomyolysis include altered mental status, seizures, dysrhythmias, and hemodynamic instability. Stimulants may further exacerbate renal injury by producing hyperthermia, vasoconstriction, hypotension, and hypovolemia. Renal infarction has been described following IV cocaine use.
PREGNANCY
Cocaine is a potent vasoconstrictor that affects uteroplacental blood flow. Cocaine abuse during pregnancy is associated with an increased incidence
40­43 of spontaneous abortions, abruptio placentae, fetal prematurity, and intrauterine growth retardation. Both spontaneous abortions and abruptio placentae appear to occur from placental vasoconstriction and increased uterine contractility, with concomitant maternal hypertension. A breastfed infant can become intoxicated secondary to maternal cocaine use. Methamphetamine abuse during pregnancy has detrimental effects on fetal growth.
DIAGNOSIS
Cocaine or amphetamine intoxication can usually be suspected based on the symptoms and signs of the sympathomimetic toxidrome: agitation, mydriasis, diaphoresis, tachycardia, tachypnea, hypertension, and possibly hyperthermia. Mental status can range from normal to severely agitated and paranoid. Lethargy or coma suggests a postictal state or intracranial hemorrhage. Symptoms such as chest pain, palpitations, dyspnea, headache, or focal neurologic complaints suggest end­organ toxicity. Without a history of cocaine or other stimulant use, it may be difficult to distinguish this presentation from other conditions with catecholamine excess, such as withdrawal from alcohol or sedative­hypnotic drugs (Table 187­4). Lactic acidosis may be present following seizures or as a result of vasoconstriction and hypoperfusion. As with all intoxicated patients, consider occult trauma and hypoglycemia.
TABLE 187­4
Differential Diagnosis of Cocaine or Amphetamine Toxicity
Toxicologic Phencyclidine toxicity
Hallucinogen toxicity
Anticholinergic toxicity
Sedative­hypnotic withdrawal
Serotonin syndrome
Neuroleptic malignant syndrome
CNS Ischemic stoke
Intracranial hemorrhage
Traumatic brain injury
Encephalitis or meningitis
Cerebral vasculitis
Neoplasm
Endocrine Hypoglycemia
Pheochromocytoma
Hyponatremia
Thyrotoxicosis
Psychiatric Acute psychosis
Other Heatstroke
Hypoxia
Concomitant use of alcohol and other drugs frequently alters the clinical presentation. For example, a patient using both opioids and stimulants may present with a decreased level of consciousness and few, if any, other diagnostic features of catecholamine excess. When the opioid effects are reversed with naloxone, the stimulant effects are unmasked, often with impressive findings.
LABORATORY EVALUATION
Laboratory studies and imaging are directed by clinical findings. Obtain a chemistry panel and creatine kinase level in a patient with agitation or elevated temperature to evaluate for possible metabolic acidosis, renal failure, or rhabdomyolysis. Hyponatremia, often with altered mental status, occasionally occurs after the use of hallucinogenic amphetamines such as MDMA or mescaline. For chest pain, obtain an ECG and serum levels of cardiac biomarkers. If the patient is hyperthermic (>104°F or 40°C), coagulation and liver function studies should be performed. Altered mental status typically requires neuroimaging.
Urine drug screens to confirm cocaine or amphetamine use are readily available, but interpretation requires knowledge of pharmacology and the
 testing method. Most of the rapid urine screening tests for cocaine are highly specific for cocaine metabolites (such as benzoylecgonine) and exhibit little cross­reactivity to the parent compound or other metabolites. Commonly available urine drug screens for the cocaine metabolite benzoylecgonine are sensitive at very low levels, and cocaine use within the past  to  hours is typically detected, depending on dose. Cocaine can be detected in habitual users by more sensitive techniques (radioimmunoassay, gas chromatography) for up to  weeks after last use of the drug.
Most urine amphetamine screens detect amphetamine, dextroamphetamine, methamphetamine, and, with decreasing sensitivity, ,4­ methylenedioxymethamphetamine, MDMA, and ,4­methylenedioxyamphetamine. Synthetic cathinones may be detected, but results are too variable to be clinically useful due to variation in both laboratory analyzers as well as “bath salt” preparations. Commercial urine drug screens for amphetamine are sensitive to 1000 nanograms/mL, and amphetamine use within the past  hours is usually detected. However, interfering substances and other phenylethylamine compounds cross­react with amphetamine immunoassays, which limits their specificity. For example, excessive use of certain nasal inhalers that contain cross­reacting stimulant­class drugs may lead to positive results on immunoassays. Patients who take the nonprescription decongestants pseudoephedrine or phenylephrine or use prescription stimulants for attention­deficit/hyperactivity disorder or narcolepsy can have a positive urine amphetamine result. Many drugs, such as bupropion, chlorpromazine, promethazine, thioridazine, trazodone, desipramine, and doxepin, have metabolites that react with the amphetamine immunoassay. Other drugs, such as labetalol, isometheptene, ranitidine, ritodrine, and trimethobenzamide, possess enough structural similarity to the basic amphetamine form to react with the immunoassay as well.
TREATMENT
Follow the standard protocol for poisoned patients (see Chapter 176, “General Management of Poisoned Patients”). Establish IV access, and provide oxygen administration for hypoxia. The cornerstone of therapy is monitoring of vital signs, treatment of complications, supportive care, and adequate
 sedation to prevent self­harm and allow for testing and imaging (Table 187­5). Treat hyperthermia with an ice bath or cooling blankets (see Chapter

210, “Heat Emergencies”). Aggressive IV hydration is the primary treatment for rhabdomyolysis (see Chapter , “Rhabdomyolysis”). Seizures are initially treated with benzodiazepines, and status epilepticus requires aggressive treatment (see Chapter 171, “Seizures and Status Epilepticus in
Adults”). Obtain a head CT to identify intracranial pathology as the cause of seizures.
TABLE 187­5
Management of Sympathomimetic Toxicity
Vital signs and continuous cardiac monitoring
Supportive care and prevent self­harm
Benzodiazepines for sedation
Aggressive cooling for hyperthermia
IV fluid for rhabdomyolysis
Benzodiazepines for seizures
Evaluate chest pain and treat ACS
Phentolamine for uncontrolled hypertension
Targeted therapy for dysrhythmias
Abbreviation: ACS = acute coronary syndrome.
SEDATION
Benzodiazepines are the cornerstone of therapy for sedation. Lorazepam,  milligrams IV, or diazepam,  milligrams IV, can be administered and titrated with repeated doses to decrease the excess autonomic and neural stimulation. Antipsychotics such as haloperidol, droperidol, and chlorpromazine are not first­line therapy because they may lower the seizure threshold, contribute to hyperthermia, and increase QT prolongation and the risk of ventricular dysrhythmias. However, if benzodiazepines are ineffective, antipsychotics may be necessary to control agitation and dangerous behavior.
CHEST PAIN
Chest pain characteristics in cocaine users are no different than in patients with atherosclerotic heart disease. Question chest pain patients about the
 use of cocaine. Cocaine users with suspected acute coronary syndrome are managed with aspirin and nitroglycerin (see Chapter , “Acute Coronary
,48
Syndromes”). Additional therapy is guided by the ECG.
IV calcium channel blockers (diltiazem,  to  milligrams IV) are recommended as adjunctive therapy for patients with ST­segment
 elevation or depression. Use of β­adrenergic antagonists (“β­blockers”) in the management of cocaine­associated myocardial ischemia or
47­50 infarction is controversial. Case reports suggested that β­blockers may create the potential for unopposed stimulation of α­adrenergic receptors
,48 that worsens coronary and peripheral vasoconstriction, hypertension, and possibly ischemia. Conversely, large observational studies of patients
51­53 with cocaine­related chest pain did not find an increased incidence of adverse effects in patients who received a β­blocker in the ED. Labetalol (a mixed α­adrenergic and β­adrenergic antagonist) has been suggested for use by some in cocaine­associated chest pain because it does not appear to
,54­57 induce coronary artery vasoconstriction, even though β­adrenergic–blocking activity predominates over α­adrenergic–blocking activity. The
2014 American Heart Association/American College of Cardiology guidelines recommend that β­blockers not be administered to
 patients with signs of acute cocaine intoxication. Although there are no definitive data to guide treatment of tachycardia in the setting of cocaine­related chest pain, available evidence from the emergency medicine literature supports use of labetalol when clinical judgment dictates a need for heart rate reduction.

Emergent coronary angiography is recommended if ST segments remain elevated despite nitroglycerin and calcium channel–blocker therapy.
Fibrinolytics may be used for cocaine­induced ST­segment elevation myocardial infarction if no other contraindications exist and coronary
 angiography is not available. Based on limited observational data demonstrating cardiac toxicity and similarities in pathophysiology between cocaine and amphetamines, the current American Heart Association/American College of Cardiology guidelines recommend therapy similar to that of cocaine­
,56 induced chest pain for chest pain in the setting of amphetamine use.
For patients without evidence of acute cocaine intoxication or ST­segment elevation on ECG and a negative initial troponin, risk stratification using the
HEART Pathway (history, ECG, age, risk factors, and troponin) or other risk stratification tools including serial ECGs and a minimum of two troponin
 assessments is reasonable.
DYSRHYTHMIAS
,59,60
Target antidysrhythmic therapy according to the probable pathogenesis of the dysrhythmia. Sinus tachycardia is generally responsive to sedation, cooling, and IV fluid rehydration; β­blocker therapy should be avoided if possible, and labetalol should be used if β­blockade is judged necessary. Use a calcium channel blocker to treat reentrant supraventricular tachycardia as well as to control the ventricular rate in atrial fibrillation or flutter.
A wide­complex tachycardia with clinical evidence of cocaine toxicity can be assumed to be due to sodium channel blockade and treated with sodium
,61 bicarbonate, a  to  mEq/L IV bolus followed by either intermittent boluses or an infusion. The frequency of boluses or the rate of infusion is guided by clinical response and serum pH; do not alkalinize the serum above a pH of .55 with sodium bicarbonate. Lidocaine in standard doses can be used in refractory cases of wide­complex tachycardia; theory and animal models suggest harmful interaction, but clinical experience has documented
 safety.
Magnesium, lidocaine, and overdrive pacing have all been reported to be successful in cocaine­induced torsades de pointes. It seems reasonable, although of unproven benefit, to administer magnesium in an attempt to prevent torsades in patients with a prolonged corrected QT interval >500
 milliseconds or who fall above the QT–heart rate pair nomogram.
HYPERTENSION
Severe hypertension not responding to sedation with benzodiazepines should be treated with phentolamine (initial dose, .5 to .0 milligrams IV), nitroglycerin, nicardipine, or a sodium nitroprusside infusion (initial dose, .3 microgram/kg per minute). Blood pressure may be lowered aggressively if the patient does not have chronic hypertension. Treatment for refractory hypertension is similar to that for hypertensive emergencies except that β­ adrenergic blockers are not used (see Chapter , “Systemic Hypertension”).
BODY STUFFERS AND BODY PACKERS

Cocaine and other drugs can be internally concealed. Patients who swallow cocaine following police pursuit to conceal the evidence are termed

“body stuffers.” The swallowed packets are often poorly wrapped and can leak or perforate. “Body packers” swallow a large number of well­sealed
,64 packets in order to smuggle drugs across international borders. Both methods can result in severe toxicity and death.

Management of an asymptomatic cocaine body packer brought in by police or customs officials is a treatment dilemma. CT is the best imaging
65­67 modality to identify the packets. If the patient shows no signs of toxicity, give single­dose activated charcoal and institute whole­bowel irrigation
,68 with polyethylene glycol electrolyte solution to gently hasten packet elimination. Continue whole­bowel irrigation until passage of the last packet, and then obtain a confirmatory CT to ensure that all containers have passed. For symptomatic patients, provide sedation and symptomatic care, and obtain immediate surgical consultation for operative removal of the packets. Do not consult for endoscopy or colonoscopy because endoscopic
,64 manipulation may rupture the packets.
DRUG INTERACTIONS
Because cocaine is metabolized by plasma cholinesterase, coadministration of drugs such as succinylcholine and mivacurium that are also metabolized by plasma cholinesterase may lead to unpredictable rates of metabolism, leading to foreshortened or prolonged effects.
Both lidocaine and cocaine are local anesthetics and act as sodium channel antagonists. It is thought that the neurotoxic effects of both occur by similar mechanisms. Despite theoretical risk in treating cocaine­induced dysrhythmias with lidocaine, it has been used safely in patients with cocaineassociated myocardial infarction.
Monoamine oxidase inhibitors block the degradation of intracellular catecholamines, increasing adrenergic neurotransmitters in the presynaptic terminals. Amphetamines are indirect­acting sympathomimetic amines that induce the release of stored catecholamines and are also weak inhibitors of monoamine oxidase. Thus, patients taking monoamine oxidase inhibitors who subsequently use amphetamines or phenylpropanolamine (and to a lesser extent cocaine) may precipitate an acute syndrome of excessive catecholamine release that results in severe hypertension, tachycardia, hyperthermia, agitation, tremors, and possible severe neurotoxicity.
DISPOSITION AND FOLLOW­UP
Disposition depends on initial patient presentation, response to therapy, the nature of the stimulant involved, and expected duration of effect.
Patients demonstrating resolution of toxicity and clear sensorium in the absence of focal complaints or end­organ damage should be advised of the medical risks of drug abuse and referred to appropriate detoxification, counseling, and social support services.
Patients who present with adrenergic excess following recent cocaine use and who respond to initial sedation may be expected to improve completely during a period of observation in the ED because of the relatively limited duration of cocaine effects. In contrast, amphetamines have a longer duration of effect and produce prolonged toxicity, which necessitates observation or hospitalization.
WITHDRAWAL

Cocaine withdrawal is characterized by irritability, paranoid ideation, and depression. Although symptoms during cocaine withdrawal are generally milder than those during amphetamine withdrawal, psychological addiction may be particularly strong. Methamphetamine withdrawal is characterized by drowsiness, lethargy, hunger, tremor, and chills. There is considerable potential for long­term depression and suicide. Symptoms of withdrawal are strongest during the first  hours, but milder symptoms can last up to  weeks. Although pharmacologic adjuncts (e.g., antidepressants, adrenergic
69­71 antagonists, dopaminergic agents) are sometimes used during cocaine or amphetamine withdrawal, there are no data confirming efficacy.


