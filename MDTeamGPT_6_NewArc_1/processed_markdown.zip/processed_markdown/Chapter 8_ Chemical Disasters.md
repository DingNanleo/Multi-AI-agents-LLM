University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 8: Chemical Disasters
B. Zane Horowitz; Robert G. Hendrickson
INTRODUCTION AND EPIDEMIOLOGY
Content Update: Riot Control Agents August 2020
Riot Control Agents are highly irritating agents used by law enforcement for crowd control, or by individuals as a method of personal protection.
Chemicals are dispersed as aerosols or liquid sprays, and cause symptoms primarily to the eyes, face, mucous membranes, skin, and respiratory tract. Signs, symptoms, and treatment are discussed in the section ‘Riot Control Agents’ at the end of this chapter.
Although the term “agents of mass destruction” is often used in planning for terrorist events, in reality, few chemicals can be delivered by terrorists in
1 the appropriate fashion to create large numbers of deaths. However, chemical mass casualty events do occur. The setting may involve the release of industrial chemicals, such as the 1984 industrial accident in Bhopal, India, that caused more than 2500 deaths and 200,000 injuries from a methyl
2 isocyanate release, or a natural chemical incident, such as the emission of carbon dioxide in Lake Nyos, Cameroon, that was responsible for 1700 chemical asphyxiant deaths. Chemical terrorism may also occur through acts of willful deployment, as with the sarin release in the Tokyo subway in
1995 in which 12 people died and 5500 sought medical attention.
The emergency physician is most likely to encounter the accidental release of a chemical from a fixed industrial site or transportation accident. In 2005,
2,3 a freight train collision in Graniteville, South Carolina, caused the release of chlorine gas that resulted in nine deaths and 511 ED visits.
Environmental contamination, even without injuries, may affect an entire community, including local EDs. In 2014, a previously little­known chemical named 4­methylcyclohexane methanol that was used in coal washing leaked into the Elk River in West Virginia, in proximity to the intake area for the water supply for nine counties that served 300,000 people. Although there were no injuries, emergency planners needed to supply clean water to the affected population. Providing risk management advice based on limited data on this chemical and the chemical’s strong black licorice odor despite
4 levels below the toxic concentration made it challenging to convince the citizens that the water was safe to use again.
What has been learned from these incidents is that when chemicals are released, the agents create a penumbra effect, in which true chemical emergencies occur in the epicenter and a larger surrounding area of fear and panic arises in individuals with lower, usually nontoxic levels of exposure. Planning for chemical disasters must take into account both the chemical emergency occurring near the center of any
2,3 chemical release and the chaos that can ensue through fear of exposure. What makes these events overwhelming for an individual ED is
5 the larger number of victims who are ambulatory, frightened, and make their own way to the hospital, bypassing any scene triage or decontamination.
Appropriate planning for management of this large, self­extricated population is paramount to the concept of disaster preparedness for chemical emergencies and perhaps even more important than specific antidotes for rare agents that might be encountered.
PRINCIPLES OF PHYSICS: SOLIDS, LIQUIDS, AND GASES

Solids have a fixed volume and shape and can be bulk solids, powders, dusts, or fumes. Dust particles are visible if they are >100 μm in diameter;
7 particles smaller than this size are imperceptible to the naked eye. Most dust particles settle with time as the result of gravity; however, in a windblown environment or an explosion, they can be blown through the air and contaminate mucous membranes or be inhaled. Dust particles between 2.5 and 6.0 μm in diameter deposit in the bronchial mucosa, whereas particles smaller than 2.5 μm can reach the alveoli. Fumes are fine, solid particles created by either combustion or condensation and are smaller than 1 μm in diameter. Chemicals may adhere to fumes or dusts and be deposited in the lungs through inhalation.

LCihqaupidtes rh 8a:v eC ah efimxeicda vl oDluismaes,t ebrust, tBh.e Zira snhea pHeo croownfiotzr;m Rso tboe brot tGh. gHraevnidtaritcioknso annd container shape. They will flow downhill and can accumulateP iang cel o1t h/ i1n6g
. Terms of Use * Privacy Policy * Notice * Accessibility and shoes. A liquid forced through a small orifice under pressure can be aerosolized into fine liquid droplets (i.e., aerosols). Aerosols, like dust, will settle with gravity over time. A vapor may be a dispersion of a liquid or a volatile solid, like mercury. Vapors and aerosols may penetrate clothing, causing contact injury by soaking the underlying skin or reacting with moisture in mucous membranes.
A gas has a variable shape and volume and will diffuse to fill an enclosed space once released. Many compressed gases are stored as liquids in cylinders and are converted to a gas upon their release. Hazardous risk analysis should take into consideration misuse or theft of these compressed gas cylinders. An endothermic reaction may occur during release of a compressed gas, causing hypothermic skin injury. Gases can be inhaled into the lungs and cause local reaction, systemic toxicity, or, in some cases, delayed reactions deep in the pulmonary tree.
How deeply in the lungs a gas or vapor exerts its effects depends on its degree of water solubility. Highly water­soluble compounds react with water in
6 mucous membranes and can irritate the eyes and upper airway. Examples of agents with this property includes ammonia and hydrogen chloride.
These agents have good warning properties, allowing an awake and ambulatory individual to leave the area of exposure. Low water­soluble compounds may be less irritating, allowing greater duration of exposure and, therefore, greater pulmonary penetration. Phosgene is an example of a low­solubility gas; it has a pleasant smell like new­mown hay and penetrates deep into the alveoli where it slowly is converted to hydrochloric acid.
HAZARDOUS MATERIALS EXPOSURE­LIMIT GUIDELINES
Several agencies have created exposure guidelines used for different purposes, of which a few may be useful in assessing health risks during an
8 exposure. The American Conference of Governmental Industrial Hygienists has created threshold limit values for many substances. This value is the maximum allowable airborne concentration of a substance that a worker can be exposed to for an 8­hour workday. Concentrations below this should
6,8 be regarded as acceptable and safe. The American Conference of Governmental Industrial Hygienists has also established a short­term exposure
8 limit for substances to which an individual should not be exposed for >15 minutes. The National Institute for Occupational Safety and Health has established an acute exposure limit called the immediately dangerous to life or health limit. This is the maximum environmental air concentration of a
6 substance from which a person without protective equipment could escape within 30 minutes and not sustain irreversible health effects. This applies only to acute health effects and does not take into account chronic health effects or carcinogenicity. The immediately dangerous to life or health level is meant to apply to the work environment and not a chemical accident, where the level of a substance measured in an environment is usually unavailable during an actual disaster and may change over time.
SCENE HAZARDOUS MATERIALS RESPONSE
Each year, there are 15,000 to 19,000 hazardous materials events in the United States. Planning for chemical exposure events, whether terrorist or accidental, builds on our existing principles of hazardous materials response. Core concepts of planning are listed in Table 8­1. Table 8­1
Scene HAZMAT Planning Guidelines
Community risk assessment
Recognition of an event
Identification of the substances involved
Isolation and scene control
Decontamination
Stabilization and triage
Abbreviation: HAZMAT = hazardous materials.
COMMUNITY RISK ASSESSMENT
The Superfund Amendments and Reauthorization Act, also called the Emergency Planning and Community Right­to­Know Act, requires states to create state­level emergency response commissions and communities to form local emergency planning committees to prepare emergency response plans for chemical accidents. Chemical facilities are required to provide local emergency management agencies and local fire departments with annual inventory reports and information about hazardous chemicals. The Environmental Protection Agency maintains a national database containing a
Toxics Release Inventory that mandates certain facilities to annually report the quantities of their emissions of toxic chemicals
(https://www.epa.gov/toxics­release­inventory­tri­program and http://www.epa.gov/triexplorer/maps.htm). This information includes the chemical name, an estimate of the maximum amount of the hazardous chemical present at the facility at any time during the preceding calendar year, an estimate of the average daily amount of the hazardous chemical present at the facility during the preceding calendar year, a brief description of the manner of storage of the hazardous chemical, and the location within the facility of the hazardous chemical. Table 8­2 lists the most common chemicals stored in the United States. Appropriate emergency planning would require a laborious review of these databases at each local level and is not often done with any assessment of vulnerability to release. Rather than expect an accurate accounting of local risk, each ED must be knowledgeable in the general principles of hazardous materials decontamination. An awareness of the clinical manifestations of the most common
9 stored chemicals and the availability of just­in­time information sheets can supplement risk assessment in the real world.
Table 8­2
Most Common Chemicals Stored in the United States
Anhydrous ammonia
Chlorine
Flammable mixtures
Propane
Sulfur dioxide
RECOGNITION OF AN EVENT
Most chemical releases are recognized early because many chemicals have early warning properties, including a noxious or unusual odor, or cause eye or upper airway irritation. Toxic exposures may produce rapid death at the site of the release. Sometimes, more subtle clues are present, such as large numbers of dead animals in an outdoor environment.
Most hazardous material events occur in fixed industrial facilities, and many industries have monitors for leaks of chemicals at nontoxic threshold levels that have no warning properties. For example, the semiconductor manufacturing industry has monitoring sensors for many toxic semiconductor gases, such as arsine, and these are triggered at very low levels.
IDENTIFICATION OF THE SUBSTANCES INVOLVED
The most common agents released in the United States are the pulmonary irritants ammonia and chlorine. There are numerous resources for the identification of which substances are involved in a spill by a transportation accident or industrial site (Table 8­3).
Table 8­3
Chemical Identification Aids
U.S. Department of Transportation placards with Department of Transportation Emergency Response Guidebook
Container National Fire Protection Association markings (NFPA 704 system)
Chemical Abstracts Service (CAS) number
Material Safety Data Sheets (MSDS)/Safety Data Sheets (SDS)
Bill of lading
Shipping documents
CHEMical TRansportation Emergency Center (CHEMTREC): 1­800­424­9300
Few of these resources will identify the amount, and none will have treatment recommendations. Although it may be intuitive that an exact identification of a substance is critical to the disaster or hazardous material process, in reality, it is more important to recognize the clinical syndromic manifestations of the victims. It is not necessary at the scene to know which organophosphate is involved; it is more important to identify that the symptom complex of a cholinergic crisis is occurring. Similarly, early recognition of the pulmonary irritant effects of a highly water­soluble acid is usually more important than the concentration or the specific chemical identified. Ultimately, identification of the exact agent involved will need to be made. Hazardous materials teams have several techniques to identify substances and usually have a standard procedure to enter and evaluate a building where an odor is detected. The treating physician should evaluate all presumptive initial identifications of substances
3 with some caution. If the symptoms of the patient do not fit the initial chemical identification, then the accuracy of the identification should be called into question. Experience with chemical events has sometimes revealed that the initial determination of the chemical involved in the release is wrong.
ISOLATION AND SCENE CONTROL
Once a suspected chemical release occurs, the EMS response team must establish an incident command system; designation of hot, warm, and cold zones; and an isolation process. The immediate area where the suspected chemicals and victims of exposure are located is designated the hot zone.
Only trained personnel in fully encapsulated protective gear should be allowed to enter. Their primary role is rescue of victims by removing them from further exposure. There is substantial risk of secondary contamination and, therefore, toxic effects for any rescuer or bystander who
10 enters the hot zone without the proper protective gear.
A surrounding corridor through which each victim is washed off and decontaminated is created outside the hot zone and is designated the warm zone
(Figure 8­1). Basic treatment, such as opening obstructed airways, may occur simultaneously with decontamination. Once appropriately decontaminated, the patient can be transferred to the cold zone where a lower level of protective equipment is necessary and a very low risk of secondary contamination exists. With less cumbersome protective gear, reevaluation in the cold zone, triage, and initiation of treatment can occur
(Figure 8­2).
FIGURE 8­1
Control zones of a chemical event. decon = decontamination; pt. = patient; Tx = treatment.
FIGURE 8­2
Personal protective equipment. Level A: Completely encapsulated protection. Requires use of self­contained breathing apparatus (SCBA) inside a chemical­resistant suit sealed at the face. Taped or suit­incorporated gloves and boots make this a completely sealed environment. Level B: Provides either an SCBA or a supplied air respirator and splash protection. The SCBA is worn outside the protective clothing and could expose this equipment to secondary contamination. There may be areas of the skin around the face mask of the SCBA where gas or vapor may penetrate. Level C: Either a gasmask or air­purifying respirator and skin slash protection. This is the highest level of protection most hospital­based personnel should be trained to
11,12 use. (From U.S. Army Center for Health Promotion and Preventive Medicine Fact Sheet for Acute Exposure Guideline Levels. http://chppmwww.apgea.army.mil.)
DECONTAMINATION IN THE WARM ZONE
Primary contamination is caused by direct contact with the released substance. Both people and the environment may suffer primary contamination.
Secondary contamination is the inadvertent contamination of rescue personnel through contact with a contaminated patient or environment.
Secondary contamination can be avoided by proper use of personnel protective equipment and adequate decontamination of adherent solids and liquids. Some rare substances are excreted in sweat and exhaled. Close unprotected contact with wet skin, mouth­to­mouth ventilation, or mouth­to­mask ventilation could be a source of secondary contamination. Equipment can become secondarily contaminated and may be required to be taken out of service until appropriate decontamination is done. This equipment contamination can be something as simple as a stethoscope or as large as a fire truck. Organophosphates can be excreted in sweat and may adhere to leather. Care must be taken with first responders who may not have protective gear; their shoes, belts, and holsters need to be discarded because they cannot be effectively decontaminated and could potentially pose a risk to coworkers or their families at home.
After the victim is removed from the hot zone to the warm zone, the critical management issue is adequate decontamination. The first and most
10–12 effective method of decontamination is removing clothing, brushing off solid particles, and washing and toweling the face. Water is the universal decontamination agent. Some guidelines recommend decontamination for nerve agents and vesicants with dilute household bleach, but there is little evidence of superiority over plain water, and bleach is likely to be unavailable in sufficient quantities at the scene. In general, 5
12 minutes of decontamination with warm water in the warm zone is adequate for most ambulatory patients. Warm water is used to prevent shivering. If the patient has had direct contact with either liquid or vapor, he or she must be hosed off with water, paying critical attention to occult areas where fluids can hide, such as the hair, skin folds, axilla, groin, toes, and eyes. Patients with severe symptoms may require rapid decontamination and simultaneous treatment in the warm zone.
STABILIZATION AND TRIAGE IN THE COLD ZONE
Triage patients in the cold zone. Safety requires the cold zone to be upwind and, if needed, uphill from the hot zone. Once decontaminated, stabilize patients and evaluate for syndromic symptoms and the need for antidotes. Primary stabilization includes the establishment of airway, applying oxygen, and administering bronchodilators for bronchospasm. The establishment of IV lines in a disaster or multiple­casualty incidents requires judgment of the need for fluid resuscitation and critical IV medications. Give priority for IV line placement to patients requiring benzodiazepines for stopping seizure activity, treating cardiac dysrhythmias with usual advanced cardiac life support medications, and volume resuscitation for hypotension. Only a few antidotes may truly be beneficial if given early, such as the cyanide antidote, hydroxocobalamin, or atropine for muscarinic effects of organophosphate exposure. The need for additional antidotes in the prehospital phase is unusual unless prolonged onscene triage is likely to occur.
ED HAZARDOUS MATERIAL RESPONSE
Despite the best planned and drilled chemical emergency response plan, most individuals will self­rescue and make their way in an uncoordinated
3 fashion to a healthcare facility, so potentially contaminated patients will find their way by private transportation to the ED. In the Tokyo subway
13–15 release of sarin, 85% of patients who presented to St. Luke’s Hospital, the facility closest to the scene, arrived under their own accord. Therefore,
EDs cannot rely solely on the prehospital system to completely decontaminate and triage every patient. Each facility must consider their physical space and patient flow, create a hospital­based plan for chemical emergencies, and have a policy and training that allow for the identification of chemically exposed patients. There should be an organized plan to perform decontamination and mobilize a system for decontamination of multiple patients, and the plan with deployment of equipment must be practiced on a regular basis. Regardless of the specific type of equipment, EDs should have the ability to decontaminate large numbers of patients external to the ED with warm water and proper personal protective equipment. ED decontamination is performed far from the release of the chemical, is not in a warm zone, and does not require fully encapsulated supplied air gear. However, ED personnel involved in the decontamination process should wear chemical­resistant covers for all body surfaces (e.g., chemical­resistant gloves,
10,12 coveralls, and boots) and air­purifying respirator masks with filters that are designed for chemical threats.
HIGH­RISK CHEMICALS
High­risk chemicals are detailed in Table 8­4. Table 8­4
High­Risk Chemicals
Simple Irritant Agents That Agents That Nerve Agents Incapacitating Vesicants
Asphyxiants Gases or Interrupt Interfere With Agents
Droplets Delivery of Oxygen
Oxygen to Utilization in
Tissues Mitochondria
Mechanism Displace React with Alter Bind to Organophosphates, which Immobilize Blistering to oxygen from H O in upper hemoglobin so it cytochrome bind to victims in a eyes, skin,
2 air cannot oxidase acetylcholinesterase variety of ways mucous respiratory transport O ; or membranes, tract 2 lungs produce methemoglobin
Agents CO, H, N, Ammonia, CO, methylene Cyanide, HS, GA, GB (sarin), GD, VX, GF Mace, narcotic Sulfur methane, chloramine, chloride, nitrites, phosphine, vapors, LSD, BZ mustard, butane, SO HCl, HFl, benzocaine, sodium azide, CO phosgene
2, propane phenazopyridine oxime, chlorine, lewisite phosgene
Treatment Remove from Remove O , methylene Hydroxocobalamin Identify DUMBELS Individualize for Irrigate with
2 source, give from source, syndrome; atropine for agent water, blue
O give O , muscarinic effects; 2­PAM supportive
2 2 for nicotinic effects; care; monitor benzodiazepines for mustard pulmonary seizures; ipratropium agents can status; for bromide (Atrovent®) for cause
HFl, monitor wheezing; never give marrow serum Ca succinylcholine suppression
Abbreviations: BZ = 3­quinuclidinyl benzilate; DUMBELS = defecation, urination, miosis, bradycardia/bronchospasm/bronchorrhea, emesis, lacrimation, and salivation; LSD = lysergic acid diethylamide; 2­PAM = pralidoxime.
TOXIC INHALANTS
Toxic inhalants tend to interfere with one or more of the four phases of oxygen delivery. Gases that interfere with oxygen uptake by displacement of oxygen from air are simple asphyxiants. Interruption of pulmonary diffusion may occur with some of the less soluble irritant agents such as phosgene. Agents that may interrupt oxygen transport include carbon monoxide and the methemoglobin­forming agents. Agents that interfere with oxygen utilization at the cellular level, such as cyanide, azide, and sulfides, produce severe lactic acidosis.
DISPLACEMENT OF OXYGEN FROM AIR: SIMPLE ASPHYXIANTS
Simple asphyxiants create an oxygen­poor environment by displacing oxygen from air. Many inert gases fall into this category, such as carbon dioxide, hydrogen, nitrogen, the noble gases (helium, neon, argon, krypton, xenon, radon), and simple hydrocarbons such as methane, butane, and propane.
An occupant confined in a closed unventilated space may die as the concentration of an asphyxiant gas builds up silently. For example, deaths have been reported in persons transporting dry ice in the back seat of an automobile with the windows closed. As the solid carbon dioxide sublimes from solid to gas, oxygen concentration drops, and the driver asphyxiates. When the concentration of any of these nonreactive gases increases, the fraction of inspired oxygen (FIO ) decreases. At an FIO of <16%, air hunger, tachypnea, and changes in level of consciousness occur. At FIO <10%, loss of
2 2 2 consciousness, seizures, or vomiting may occur. Treatment is restoration of a higher FIO with supplemental oxygen and correction of the problem that

16 led to the exposure.
IRRITANT AGENTS THAT INTERRUPT PULMONARY DIFFUSION
Irritant agents are classified according to their water solubility as high­, intermediate­, or low­solubility agents. Despite being often referred to as
“irritant gases,” many of these agents are actually liquid droplets suspended in the air. Highly water­soluble agents react with water in the upper respiratory tract and produce immediate irritation and discomfort. The most common agent released in chemical events is the highly soluble pulmonary irritant ammonia. Ammonia, used as an industrial refrigerant, is prototypical of a highly water­soluble vapor. The gas chloramine is created accidentally when bleach and ammonia cleaners are mixed together. Other chemicals with high water solubility include sulfur dioxide and hydrogen chloride. Hydrogen fluoride, in addition to being a highly water­soluble irritant vapor, also reacts with intercellular calcium, causing life­threatening calcium depletion and cardiac dysrhythmias. Because of the immediate discomfort caused by these agents, they have excellent warning properties to those exposed. These agents cause significant eye irritation and edema, burning in the throat, and, at higher
6,16 concentrations, constriction of the upper airway. Treatment is removal from the source, providing supplemental humidified oxygen, and monitoring pulmonary status. Hydrogen fluoride exposure also requires close monitoring of the serum ionized calcium level and administration of supplemental calcium IV.
The only agents classified as intermediate in solubility are chlorine and hydrogen sulfide. Chlorine was the first gas used in chemical warfare in the
16,17 trenches during the First World War. Chlorine is used for chlorinating water in swimming pools and as a disinfectant, making chlorine the second most common hazardous material released. Chlorine reacts with water in the upper airways to produce hydrochloric and hydrochlorous acids. Symptoms include burning of the conjunctiva, throat, and the bronchial tree. Because of its acrid odor, chlorine has good warning properties. Higher concentrations can produce bronchospasm, lower pulmonary injury, and delayed pulmonary edema.

Phosgene, another chemical warfare agent used extensively in World War I, is prototypical of the minimally soluble agents. At concentrations as low as 25 parts per million, it can be fatal after even brief exposures. It produces only minimal irritation to the eyes and upper airways and, in fact, has a pleasant odor of new­mown hay. However, it slowly hydrolyzes to hydrochloric acid and reacts in the alveoli to cause the delayed onset of severe acute lung injury. Treatment is directed at providing pulmonary monitoring, and the need for intubation and ventilator management is guided by clinical symptoms and radiographic findings of acute lung injury. Noncardiogenic pulmonary edema may require ventilation with positive end­expiratory pressure.
AGENTS THAT INTERRUPT OXYGEN TRANSPORT
Chemicals that react in the body to interrupt the delivery of oxygen do so by altering hemoglobin so that it is no longer capable of binding and transporting oxygen. Examples are carbon monoxide and methylene chloride, which is metabolized to carbon monoxide to generate carboxyhemoglobin. Certain other chemicals, including the nitrites, and some pharmaceuticals, such as benzocaine and phenazopyridine (Pyridium®),
2+ 3+ may cause the iron moiety in hemoglobin to convert from divalent Fe to trivalent Fe . Hemoglobin with trivalent iron is called methemoglobin, and it
18 is incapable of binding and transporting oxygen. Symptoms of either exposure include those consistent with declining oxygenation. Headache, nausea, and fatigue occur at low levels; however, in those with critical fixed coronary artery lesions, angina may occur. Both carboxyhemoglobin and methemoglobin can be measured by co­oximetry on an arterial blood gas analyzer. Pulse co­oximeters are also available that detect both carboxyhemoglobin and methemoglobin and may be used by either prehospital agencies or in hospitals. Both toxic hemoglobinopathies may be treated initially with high concentrations of oxygen. Methemoglobinemia may be treated with methylene blue, which acts as an electron donor and
18 converts trivalent iron back to divalent iron.
AGENTS THAT INTERFERE WITH CELLULAR OXYGEN UTILIZATION (CHEMICAL ASPHYXIANTS)
Chemical asphyxiants are agents that interfere with oxygen utilization at the electron transport chain in the mitochondria. These agents include
19,20 cyanide, hydrogen sulfide, phosphine, and sodium azide. Carbon monoxide also interferes with oxygen utilization, in addition to its effect on oxygen delivery. By binding to cytochrome oxidase a , these agents disrupt aerobic metabolism and create intracellular acidosis. Cyanogens have

20,21 been developed for use in chemical warfare, and nitriles used in industry release cyanide. Symptoms include headache, alteration of consciousness, seizures, and severe acidosis. Hydroxocobalamin was approved for use in the United States in 2006 for cyanide toxicity and for smoke
21 inhalation and is administered as a 5­gram infusion.
NERVE AGENTS
During World War II, scientists in Germany discovered and manufactured three nerve agents, classified as GA (tabun), GB (sarin), and GD (soman). In
22,23
1952, chemists in Great Britain and America manufactured the agents VX and GF. Although the preferred terminology for these chemicals is organic phosphorus compounds, they are still referred to as organophosphates in most publications. These agents were chosen as chemical warfare agents over existing insecticides because they had greater CNS activity and higher lethality than many of the organophosphates and carbamates used for
22–26 insect control. With the advent of the Cold War, organophosphate production accelerated, with both the United States and Soviet Union
23 developing large stockpiles of these agents. Occasional accidents occurred, sickening soldiers handling these agents, and one chemical release of VX
27,28 in Skull Valley, Utah, killed 6000 sheep. The Kuala Lumpur airport assassination in 2017 of Kim Jong­nam was carried out using VX.
In the 1980s, Iraq developed an extensive capability to manufacture and weaponize these agents and used both sarin and GF against both its own

Kurdish people and the Iranians with whom it was engaged in a prolonged border war. During the Syrian civil war in 2013, nerve agents were
29,30 confirmed to be used as well, with over 800 civilian casualties. Today, not only do many countries have the capability to manufacture these or similar agents, but terrorist groups have used them also. The Aum Shinrikyo cult used sarin in two separate attacks, one in Matsumoto in 1984, which
13,15 killed seven people, and in a larger release in the Tokyo subway a year later that killed 12 people and sickened 5500 individuals.
The organophosphate compounds inhibit several key enzymes by binding to them. They bind to acetylcholinesterase in a two­stage process. The first
25 stage is reversible if the antidote pralidoxime (Protopam®) is given. The second stage (aging process) makes the enzyme unavailable to be regenerated by pralidoxime. Acetylcholinesterase breaks down the neurotransmitter acetylcholine. With this enzyme inhibited, acetylcholine remains at its postsynaptic receptor sites, causing excessive cholinergic stimulation. Within the parasympathetic nervous system, there are cholinergic receptors at muscarinic sites, such as tear glands, sweat glands, bronchial secretion glands, and the sinoatrial and atrioventricular nodes of the heart.
Overstimulation of these leads to the “DUMBELS” syndrome, a mnemonic for the following symptom complex: defecation,
6 urination, miosis, bradycardia/bronchospasm/bronchorrhea, emesis, lacrimation, and salivation.
The second location within the peripheral nervous system where cholinergic transmission is affected is the neuromuscular junction, or nicotinic receptor. Excess cholinergic stimulation here causes the progression from muscular fasciculation to profound muscular weakness to complete paralysis in a dose­dependent fashion. Early in the course of an exposure, there can also be paradoxical hypertension and tachycardia, but these both subside as the bradycardia from muscarinic receptors predominates in the clinical presentation.
The last location of importance for cholinergic stimulation is the brain, where excessive stimulation produces coma and seizures. Many organophosphates cross the blood–brain barrier freely, and the nerve agents in particular have potent CNS effects.
The treatment strategy for nerve agents must counteract cholinergic excess at all three of these receptor sites. Atropine counteracts only the
23,25 muscarinic effects. Pralidoximecounteracts the nicotinic effects. Benzodiazepines treat seizures. The indication for each of these agents varies with the clinical manifestations. For the patient with exposure in low concentrations, such as with vapor releases, only eye findings may develop. Pinpoint pupils, frequently with local pain, may be treated with any of the anticholinergic eye drops, scopolamine, or homatropine. If pulmonary symptoms are isolated to bronchospasm in the reactive airway disease–prone patient, ipratropium bromide (Atrovent®) may be adequate.
24,25
AdministerIV atropine to anyone experiencing hypersalivation, bronchial secretions, or bradycardia. Large doses of IV atropine,
25 sometimes as much as 20 milligrams, may be needed. This has been reported typically in ingestions but could be needed in liquid exposure to the
13–15 nerve agents. High doses of atropine were not needed in the lower concentration exposures that occurred in the Tokyo subway incident. Titrate atropine administration to clearing of the excess secretions. Pupil size and heart rate response are poor indicators of adequate atropinization in organophosphate exposure.
Pralidoxime reactivates the enzyme acetylcholinesterase at the neuromuscular junction. It can reactivate the enzyme only if the aging process has not occurred. How rapidly an agent ages varies from agent to agent; VX takes 24 hours, whereas soman takes only 5 to 8 minutes to age and
25 23–25 create an irreversible bond. The recommended initial dosage of pralidoxime is 1 to 2 grams IV slowly over 20 to 30 minutes. In a large event with multiple casualties, half this may be given to spread the antidote to the maximal number of patients. Many patients with neuromuscular weakness will eventually require intubation and mechanical ventilation. Succinylcholine should not be used, if at all possible, because the same enzymes inhibited by the organophosphates metabolize it. The onset of action of succinylcholine will be the same (usually <90
31 seconds), but the duration of action of this drug will be prolonged to several hours. Seizures, when they occur, may be refractory and, in combination with diaphragmatic paralysis, will lead to respiratory arrest. Use any of the IV benzodiazepines to treat seizures. Phenytoin and fosphenytoin are not effective for seizure control.

Patients with minor symptoms, such as eye findings only, may be observed for a 6­ to 8­hour period and released if no further symptoms occur.
Admit any patient who received pralidoxime to an intensive care unit and give either a continuous infusion of pralidoxime at 500 milligrams/h or
13,23 intermittent bolus dosages of 1 to 2 grams every 6 hours.
INCAPACITATING AGENTS

The incapacitating agents are a diverse group of chemicals that immobilize victims. Although riot control agents, such as Mace (Mace Security
International, Horsham, PA) and tear gas, are not classically defined in this category, they can be considered incapacitating and are generally nonlethal.
Narcotic vapors have also been used, such as the fentanyl derivatives used by Russia when they stormed the Moscow theater in 2002 where terrorists
32 were holding hostages. The potent fentanyl derivatives, carfentanil and remifentanil, may have been mixed with a halothane­like anesthetic agent.
Despite the intent of this mixture to immobilize those inside the theater, lack of coordinated rescue efforts and late use of the antidote naloxone led to
>100 casualties.
3­Quinuclidinyl benzilate is a long­acting potent anticholinergic agent. The U.S. Army developed it in the 1960s; exact information on how it was used is
23 difficult to substantiate. 3­Quinuclidinyl benzilate causes a severe and prolonged anticholinergic delirium similar to diphenhydramine. Other agents intended to immobilize victims have been experimented with, such as lysergic acid diethylamide, benzodiazepines, α ­agonists, vomiting agents, and
2 other exotic agents.
VESICANTS
Sulfur mustard was first deployed by Germany in 1917 near Ypres, Belgium, the site of their release of chlorine as a chemical weapon 2 years
33,34 earlier. Vesicant agents were used extensively as military weapons by both sides in World War I and in a variety of regional wars leading up to and
23 during World War II (Ethiopia, Manchuria). The largest number of casualties from sulfur mustard came with the explosion of the Liberty ship John
35,36
Harvey, during World War II in Bari, Italy, where 617 sailors sustained burns from sulfur mustard. During the 1980s, sulfur mustard was used in the
Middle East (Iraq against Iran and the Kurds, Egypt against Yemen); 12 of these patients were transported to Germany, and their therapy was described
34 35 in detail. A small number of spills have occurred since in the United States at chemical weapons storage facilities. Vesicants cause damage to eyes, skin, mucous membranes, and potentially the lungs if exposed to high concentrations. Sulfur mustards [bis(2­chloroethyl) sulfide]
33 make up the most common vesicants used, although the nitrogen mustards were also produced, but never used militarily. Other vesicant agents are
23,35 phosgene oxime, a solid that liquefies at 35°C (95°F); this agent does not cause blisters but produces severe skin erythema. Lewisite, an arsenical compound that smells like geraniums and that was developed in 1918, too late for use in World War I and thus never deployed, is also included in this
35 34–36 category. Both lewisite and phosgene oxime produce symptoms on immediate contact. Sulfur mustard skin symptoms are
33 delayed in onset for 4 to 8 hours, leading to blistering similar to second­degree burns within 2 to 18 hours of initial exposure.
Ocular damage from vapor exposure to all these agents is common, leading to incapacitation of the victims exposed. Corneal vesicle formation and sloughing of epithelium occur. The primary goal of therapy is copious irrigation with water to dilute and remove the chemical, and then monitoring the patient with serial eye examinations, pulmonary monitoring, and careful attention to skin care. The mustard agents may produce a systemic toxicity, with marrow suppression as a delayed component presenting with a falling white blood cell count and increased risk of infection 3 to 5 days after
34 exposure.
BIOTOXINS
The biotoxins differ from biologic agents in that the toxins do not replicate in the body and a sufficient dose needed to cause disease must be delivered. These agents produce unusual symptoms, some with delayed onset. Clues to biotoxin exposure are presented in Table 8­5. Table 8­5
Indications of a Possible Biotoxin Exposure
Occurrence of a disease or syndrome that rarely occurs naturally
Multiple victims of a similar disease with no classic risk factors
Epidemiology suggesting a point source or localized exposure
Possible animal and human morbidity in the same area
High mortality in an otherwise healthy population
With many biotoxins, the lethal dose in 50% of exposed subjects is quite low (Table 8­6), allowing small amounts to potentially be made into a high­
23 risk weaponized aerosol and dispersed intentionally.
Table 8­6
Lethality of Biotoxins
Agent LD (micrograms/kg)

Botulinum toxin 0.001
Tetanus toxin 0.002
Staphylococcal enterotoxin B 0.02
Diphtheria toxin 0.10
Ciguatoxin 0.4
Ricin 3.0
Tetrodotoxin 8.0
Saxitoxin 10.0
Trichothecene toxin 1200
Abbreviation: LD = lethal dose in 50% of exposed subjects.

BOTULINUM TOXIN
Inhalational botulism has been described in humans only after an accidental laboratory exposure. It is estimated that the lethal dose in 50% of
23 exposed subjects for inhalation botulism is 1 to 3 nanograms/kg. Three days after performing an autopsy on a lab animal that died of botulism, three technicians developed tightness in the throat, difficulty swallowing, and symptoms characterized as a cold without a fever. They developed ocular
23 paresis, rotatory nystagmus, dilated pupils, dysarthria, ataxia, and generalized weakness. All recovered within 2 weeks with antitoxin treatment.
Diagnosis requires the recognition of the clinical presentation, with early subtle cranial nerve palsies, typically presenting with difficulty swallowing,
37 palsies of extraocular muscles, and trouble speaking. Treatment with antitoxin will prevent progression of the disease but will not reverse paralysis once it occurs. Administer the antitoxin based on clinical suspicion as early as possible; do not wait for the results of laboratory tests. The heptavalent antitoxin against all subtypes of botulism is available by contacting the Centers for Disease Control and

Prevention. Give one vial of antitoxin IV in suspected cases of botulism. Supportive care, including mechanical ventilation, is frequently needed and
37 may be required for 90 days or more in cases presenting with diaphragmatic paralysis before receiving the antitoxin. Antibiotics only have a role in wound botulism and are not indicated in inhalational botulism.
RICIN
Ricin toxin gained notoriety when it was used as the agent to assassinate Bulgarian activist Georgi Markov. At autopsy, a pellet containing ricin was removed from a small wound in the back of his leg. The pellet was fired from a specially designed umbrella into his leg while he waited at a London bus
23 38 stop. Ricin is a toxin derived from the castor bean, Ricinus communis. Ricin is not toxic by ingestion and must either be injected or inhaled as an aerosolized powder to produce disease. Ricin is taken up by cells in many tissues and causes destruction of RNA, leading to cell death. With inhalation exposure, pulmonary symptoms occur after about an 8­hour postexposure delay. Inflammation, exudates, and pulmonary edema occur, producing a necrotizing pneumonitis. After parenteral administration, local pain occurs, followed in a few hours by weakness and flu­like symptoms. Fifteen to 24 hours later, nausea, vomiting, fever, and localized lymphadenopathy proximal to the injection site may occur. After 48 hours, a sepsis­like syndrome occurs with hypotension, leukocytosis, disseminated intravascular coagulation, and multiorgan system failure (involving the liver, kidneys, heart,
23 lungs, and GI hemorrhage). In Georgi Markov’s case, death occurred by deterioration to complete atrioventricular dissociation. The differential diagnosis includes other causes of sepsis, but in the setting of an intentional attack, staphylococcal enterotoxin B must also be considered. Aggressive supportive care in an intensive care unit is warranted for all cases.
RIOT CONTROL AGENTS
Riot control agents are chemicals that are used to temporarily incapacitate exposed individuals by causing intense irritation and pain in the eyes,
39,40 mucous membranes, and skin. Most agents are dispersed in aerosols or sprayed as a liquid.
The most commonly used agents are OC (oleoresin capsaicin or “pepper spray”, trans­8­methyl­N­vanillyl­6­noneamide), CS (“tear gas”, ochlorobenzylidene malononitrile), CR (“tear gas”, DBO, dibenzo­[b, f] [1, 4] oxazepine), and CN (1­chloroacetophenone). MACE® is a brand name for a company that produces several varieties of agents. CS is the most commonly used formulation by law enforcement. None are water soluble. All the C
40 agents stimulate the nocireceptor transient potential channel subtype (TRPA_1). This results in the sensation of burning pain (Table 8­7) .
Table 8­7
Common Riot Control Agents
Common Name Agent Comments
Pepper Spray (OC) Oleoresin capsaicin (trans­8­methyl­N­vanillyl­6­noneamide) Organic compound
‘Tear Gas’ (CS) o­chlorobenzylidene malononitrile Commonest by law enforcement
‘Tear Gas’ (CR) (UK agent) DBO, dibenzoxazapine Most potent lacrimator
Chloroacetophenone (CN) 1­chloroacetophenone This was the original MACE® product.
Signs/symptoms
All agents produce immediate intense pain on exposed areas, particularly the eyes, nose, and mouth. Pain may resolve over 15­60 minutes once removed from the exposure. Patients may have tearing, blepharospasm, conjunctival injection, rhinorrhea, and erythematous irritation over all
39–42 exposed areas. Rarely, these agents can cause skin blistering.

All symptoms usually resolve quickly, however, symptoms such as mucous membrane irritation, cough, and wheezing may last for weeks.
Severe symptoms have occurred particularly when removal from the exposure is not possible and when exposure is prolonged, such as in an enclosed space. These include wheezing, pneumonitis, hypoxemia, and in rare cases, death.
Treatment
All exposed areas should be thoroughly decontaminated with water, although any neutral liquid may work in a field setting. Both milk and antacids such as Maalox have been used by protest organizers as a street treatment, but its effectiveness is not studied. Contaminated clothing should be removed and stored in sealed bags to decrease the risk of secondary contamination of healthcare workers. Decontamination of the eyes may require topical ophthalmic anesthetic and irrigation with 1­2 liters of normal saline or water. Continue irrigation until ocular symptoms resolve. Wheezing or pneumonitis may be treated with inhaled bronchodilators (e.g. albuterol, salmetamol) and corticosteroids. Painful dermal injury of the extremities from OC (capsaicin) or CN, may be immersed in cool water to relieve pain. For painful, persistent dermal injury in a small body surface area, topical lidocaine gel or topical corticosteroids may decrease pain.
