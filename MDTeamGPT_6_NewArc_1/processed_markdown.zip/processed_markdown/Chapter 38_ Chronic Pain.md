## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 38: Chronic Pain
David M. Cline
CHRONIC PAIN
EPIDEMIOLOGY
Chronic pain is defined as a painful condition that lasts greater than  months, pain that persists beyond the reasonable time for an injury to heal, or pain that persists  month beyond the usual course of an acute disease. Whereas acute pain is a vital biologic signal to stop the individual from a potentially injurious activity or to pursue medical care, chronic pain serves no obvious biologic function. Complete pain relief is unrealistic in cases of chronic pain. Rather, the goal of therapy is pain reduction and return to functional status. Chronic pain syndromes discussed in this chapter are divided into neuropathic and nonneuropathic conditions, with a separate discussion of abdominal and pelvic pain syndromes. Aberrant drug­related behavior is also discussed.
1­3
Chronic pain is a common problem, affecting 20% to as much as 50% of the population in developed countries. Women (34%) are affected more
  than men (27%). The back is the most common site for chronic pain, followed by the knee and neck. The prevalence of neuropathic pain is .9% to

10% of the population. The prevalence of chronic abdominal pain in association with irritable bowel syndrome and functional dyspepsia is 23%. Risk
 factors for chronic pain include increasing age, female gender, higher body mass index, and chronic illness. An exacerbation of chronic pain is part of
 the presentation of 11% to 15% of ED visits. Compared to patients with acute pain, chronic pain patients are more likely to report their pain as severe
 and are more likely to be frequent visitors to the ED.
PATHOPHYSIOLOGY
Our understanding of the pathophysiology of chronic pain is incomplete. Many chronic pain syndromes follow nerve or tissue injury, producing nerve dysfunction secondary to the mechanical injury or in response to chemical mediators released from adjacent cell injury. Peripheral sensitization or central sensitization commonly follows, where peripheral nerves or the CNS become abnormally sensitive, exhibiting pathologic spontaneous activity
 through upregulation of sodium channels and receptors. Neuroplastic changes in the central descending pain modulatory systems, inhibitory or facilitatory, may lead to further hyperexcitability. These changes lead to hyperalgesia (exaggerated response to a normally painful stimulus) and allodynia (pain from a normally nonpainful stimulus). In several disorders, a history of injury may be lacking, such as for fibromyalgia, where central
 sensitization plays a key role. Psychological factors frequently precede or follow the onset of chronic pain and often predispose individuals to
 physiologic changes through the fear­avoidance model. The fear of pain may lead to disuse disability, which leads to nerve hyperexcitability and
 dysfunction, which may ultimately result in a chronic pain syndrome.
CLINICAL FEATURES
The nonneuropathic syndromes share certain characteristics, with the most common feature being muscle­related pain (Table 38­1). A feature common to most neuropathic syndromes is allodynia (Table 38­2).
TABLE 38­1
Symptoms and Signs of Nonneuropathic Pain Syndromes
Disorder Pain Symptoms Signs
Myofascial headache Constant dull pain, occasionally shooting pain Trigger points on scalp, muscle tenderness and tension

Chapter 38: Chronic Pain, David M. Cline 
©2025C MhrcoGnicra twen sHioilnl. All RighCtosn Rsteanste drvuelld p.a i nTerms of Use * Privacy Policy * Notice * AccesDsififbuisleit ytenderness of the scalp and associated tension headache
Medication overuse May be migraine like, becomes constant, dull; nausea, vomiting Muscle tenderness and tension, normal neurologic exam headache
Myofascial neck pain Constant dull pain, occasionally shooting pain, pain does not Trigger points in area of pain, usually no muscle atrophy, typically follow nerve distribution poor ROM in involved muscle
Chronic neck pain Constant dull pain, occasionally shooting pain, pain does not No trigger points, poor ROM in involved muscle due to pain follow nerve distribution
Chronic back pain Constant dull pain, occasionally shooting pain, pain does not No trigger points, poor ROM in involved muscle due to pain follow nerve distribution
Myofascial back pain Constant dull pain, occasionally shooting pain, pain does not Trigger points in area of pain, usually no muscle atrophy, syndrome typically follow nerve distribution poor ROM in involved muscle
Abbreviation: ROM = range of motion.
TABLE 38­2
Symptoms and Signs of Neuropathic Pain Syndromes
Disorder Pain Symptoms Signs
Painful Symmetric numbness and burning or stabbing pain in lower extremities; allodynia Sensory loss in lower extremities diabetic may occur neuropathy
Phantom Variable: aching, cramping, burning, squeezing, or tearing sensation May have peri­incisional sensory loss limb pain
Trigeminal Paroxysmal, short bursts of sharp, electric­like pain in nerve distribution Tearing or red eye may be present neuralgia
HIV­related Symmetric pain and paresthesias, most prominent in toes and feet Sensory loss in areas of greatest pain symptoms neuropathy
Postherpetic Allodynia; shooting, lancinating pain Sensory changes in the involved dermatome neuralgia
Fibromyalgia Widespread muscular pain in  of  regions (right upper body, left upper body, Widespread point tenderness common, but not and chronic torso, right leg, or left leg) for >3 mo, with stiffness, fatigue, sleep disturbance, and required for diagnosis, isolated fibromyalgia does widespread cognitive dysfunction (forgetfulness, inability to concentrate or recall simple not produce joint inflammation, muscle atrophy, or pain words or numbers) sensory changes
Poststroke Same side as weakness; throbbing, shooting pain; allodynia Loss of hot and cold differentiation pain
Sciatica Constant or intermittent, burning or aching, shooting or electric shock–like pain; Possible muscle atrophy in area of pain, possible
(neurogenic may follow dermatome; leg pain > back pain diminished tendon reflexes back pain)
Complex Burning persistent pain, allodynia, associated with immobilization or disuse Early: edema, warmth, local sweating regional pain syndrome Late: above alternates with cold, pale, cyanotic skin; type I eventually atrophic changes
Complex Burning persistent pain, allodynia, associated with peripheral nerve injury Early: edema, warmth, local sweating regional pain syndrome Late: above alternates with cold, pale, cyanotic skin; type II eventually atrophic changes
Abbreviation: HIV = human immunodeficiency virus.
Clinical assessment should be appropriate to the circumstances and either be comprehensive for the unidentified patient or focused for the patient presenting with a typical exacerbation of well­established chronic pain. A comprehensive evaluation starts with assessing the quality and character of the patient’s current pain, including initiating, exacerbating, and relieving factors. Compare and quantify prior episodes as they relate to the current episode. Determine sources, modes, and success or failure of prior treatment, including medications and dosages for physician­prescribed, over­thecounter, and alternative medications. Determine the patient’s functionality across the course of the illness and treatment. Treatments that have provided pain relief yet have led to disability cannot be considered a success. Assess any history of alcohol or drug addiction, need for prior detoxification, or psychiatric illness that may impact decisions about choice of medication. A review of systems should assess for potential life­ or limbthreatening conditions.
Look for findings of acute pain, such as tachypnea, tachycardia, hypertension, and less commonly, diaphoresis or muscle spasms on stimulation,
 although, for ED patients, there is no correlation between patient­reported pain severity and vital signs. Evaluate for muscle atrophy in the distribution of pain due to disuse and skin temperature changes due to the effects of the sympathetic nervous system after disuse or secondary to nerve injury. Trigger points, another objective sign, are focal points of muscle tenderness and tension that, when stimulated with pressure, provoke referred pain, typically in the distribution of the involved muscle. Trigger points are differentiated from simple focal tender portions of the muscle, as trigger points provoke referred pain throughout the affected muscle. Trigger points lack a biologic basis and interexaminer
 agreement, yet they remain an essential feature of the diagnosis of myofascial pain syndromes. Lack of objective evidence of pain does not rule out the presence of pain.
CLINICAL FEATURES OF SELECTED CHRONIC PAIN SYNDROMES
Further discussion of chronic pain, including treatment of chronic back pain, neck pain, and sciatica, is found in Chapter 279, “Neck and Back Pain.”
Migraine headaches and tension headaches are discussed in Chapter 165, “Headache.”
Medication Overuse Headache
History of migraine, depression, using combination analgesics, headache disability, and fear of pain are risk factors for medication overuse
 headache. The patient may carry the diagnosis of classic or common migraine headaches that change over time and develop into a chronic pain
  syndrome due to medication overuse. Medications implicated in this transition are barbiturates, opioids, triptans, or less commonly, NSAIDs.
Patients with medication overuse headache may have more symptoms similar to tension headache with tenderness and tension of scalp musculature.
Nausea and vomiting or failure of an oral antimigraine medication often prompts an ED visit. In addition to increased headache frequency, headache duration is longer in patients with medication overuse headaches.
Fibromyalgia
Fibromyalgia is a clinical syndrome of widespread chronic pain associated with fatigue, unrefreshing rest, and/or cognitive symptoms. Prevalence is
  thought to be .4% of the population. Diagnostic criteria for fibromyalgia were initially proposed in 1977 and most recently updated in 2016. Widespread chronic pain is defined as affecting at least four of five body regions (right upper body including jaw, left upper body including jaw, torso including neck, right leg, and left leg) for more than  months. The nonpain component of fibromyalgia for diagnosis requires a symptom severity score ≥5, calculated from the severity of fatigue (0 to  scale), unrefreshed waking (0 to  scale), and cognitive symptoms (0 to  scale), plus presence of
 headache, abdominal pain, and depression (1 point each, if present). Patients without fatigue or cognitive symptoms may carry a diagnosis of chronic widespread pain.
Painful Diabetic Neuropathy
The symptoms of painful diabetic neuropathy are symmetric numbness associated with burning, electrical, or stabbing pain in lower extremities.
Patients may have hyperesthesia, dysesthesias, and/or deep aching pain. Pain may be provoked with a gentle touch to the skin in the areas of abnormal sensation.
Postherpetic Neuralgia
Postherpetic neuralgia may follow the course of an acute episode of herpes zoster in 5% to 30% of cases; pain lasts more than  year for 30% of
 patients. Pain is characterized by allodynia and a shooting, lancinating (tearing or sharply cutting) sensation. Often, patients have hyperesthesia in the involved dermatome. Occasionally there are pigmentation changes in the distribution of the involved dermatome, but this is not unique to postherpetic neuralgia.
Trigeminal Neuralgia
Typical symptoms of trigeminal neuralgia include short, paroxysmal bursts of sharp, electric shock–like pain in the nerve distribution of the trigeminal nerve. Pain is often triggered by chewing, speaking, washing, brushing teeth, or something touching the face. Tearing of the eyes or red eye may be present.
Phantom Limb Pain
Phantom limb pain is quite variable in presentation but occurs more frequently in patients who had pain in the extremity before amputation. Pain may be described as aching, cramping, burning, tearing, or squeezing. Phantom limb pain occurs in 30% to 81% of amputations and changes over years,
 typically becoming less knife­like and more burning in character.
Complex Regional Pain Syndrome
There are two types of complex regional pain syndrome: type I, from prolonged immobilization or disuse, as after stroke; and type II, from a peripheral nerve injury (e.g., due to fracture or gunshot). Symptoms include allodynia and a persistent burning or shooting pain on the affected side or limb.
Associated signs early in the course of the disease include edema, warmth, and localized abnormal sweating. It may be difficult to distinguish this stage from an underlying wound infection or osteomyelitis. Later signs include periods of edema and warmth that alternate with cold, pale, cyanotic skin and, eventually, atrophic changes.
Human Immunodeficiency Virus–Related Pain
Patients with acquired immunodeficiency syndrome can develop distal sensory polyneuropathy characterized by shooting pain, numbness, and burning sensations, primarily on the soles, dorsum of the feet, and toes. This human immunodeficiency virus–related sensory neuropathy is
 associated with antiretroviral therapy but not with low CD4 counts. Sensory loss is common in the areas of greatest pain symptoms. As the neuropathy progresses, walking becomes difficult, and quality of life is diminished.
CHRONIC ABDOMINAL AND PELVIC PAIN SYNDROMES
By definition, these disorders lack features to suggest impending life­threatening complications or a need for surgical intervention. However, these syndromes may present with transient tachycardia or tachypnea in response to the patient’s pain experience. Furthermore, patients experiencing significant vomiting (or less commonly diarrhea) may be dehydrated on initial presentation and therefore may have hypotension due to hypovolemia.
Patients with isolated exacerbations in pain will lack alarm signs, such as unintentional weight loss, palpable abdominal mass, significant fever, or positive fecal blood (see later “Diagnosis” section for discussion of laboratory testing). The patient should be asked about prior episodes, and to describe any unique aspects to the current presentation. An atypical presentation suggests the need to broaden the differential diagnosis to include acute disorders.
Chronic Pain Syndromes of the Esophagus and Stomach
21­23
Esophageal and gastric pain syndromes typically present with epigastric and/or chest pain, with or without vomiting (Table 38­3). Upper endoscopy is necessary to differentiate these disorders from acute disorders, and therefore, a clinical diagnosis is only preliminary. Eliciting a history of cannabis use is essential in identifying cannabinoid hyperemesis syndrome (Table 38­3).
TABLE 38­3
Signs and Symptoms of Chronic Pain Syndromes of the Esophagus and Stomach
Disorder Pain Symptoms Signs
Functional Retrosternal burning discomfort or pain present longer than  months that is refractory to Normal upper endoscopy, no heartburn optimal antisecretory therapy (H blockers and proton pump inhibitors) in patients correlation between symptoms and
 endoscopic evidence of physiologic without endoscopic evidence of GERD, histopathologic mucosal abnormalities, GI motor reflux. Absence of alarm signs.* disorders, or structural explanations.
Reflux Retrosternal heartburn or chest pain present longer than  months in patients who lack Normal upper endoscopy, positive hypersensitivity evidence of reflux on endoscopy or abnormal acid burden on reflux monitoring, but show correlation between symptoms and triggering of symptoms by physiologic reflux (some degree of reflux is considered normal, endoscopic evidence of physiologic such as postprandial reflux). reflux. Absence of alarm signs.* Functional Bothersome epigastric pain or epigastric burning for ≥6 months. Symptoms severe enough No evidence of structural disease on dyspepsia with to significantly limit meals or limit daily activities at least  day per week. Significant endoscopy. Pain may be induced or epigastric pain vomiting suggests another disorder. relieved by a meal. Absence of alarm syndrome signs.* Cyclic vomiting Stereotypical episodes of vomiting with acute onset and duration lasting a week or less; ≥3 Upper endoscopy is normal or does not syndrome (with discrete episodes in the previous year; absence of nausea and vomiting characterize reveal cause of repeated vomiting.
pain) symptom­free periods lasting weeks to months. Personal or family history of migraine Absence of alarm signs.* headache supports the diagnosis.
Gastroparesis Patients with gastroparesis may have frequent visits to the ED with vomiting and Absence of alarm signs.* Distention may with pain abdominal pain and distention. Pain may be a primary complaint, especially for patients occur in the absence of small bowel with recurrent symptoms. obstruction. Assess for dehydration.
Cannabinoid Stereotypical episodic abdominal pain and vomiting after prolonged excessive cannabis Urine drug screen positive for hyperemesis use with  or more episodes in the past year. Relief of vomiting episodes by hot showers, cannabinoids. If performed, upper syndrome often for hours at a time. endoscopy is normal. Absence of alarm signs.* *Alarm signs: unintentional weight loss, abdominal mass, positive fecal blood, anemia, hypoalbuminemia, abnormal liver function tests, elevated erythrocyte sedimentation rate, and elevated C­reactive protein.
Abbreviation: GERD = gastroesophageal reflux disease.
Chronic Pain Syndromes of the Bowel
Centrally mediated abdominal pain syndrome (formerly, functional abdominal pain syndrome) requires repeated episodes to meet criteria for
23­27  diagnosis (Table 38­4). By the time of diagnosis, narcotic bowel syndrome may coexist or dominate the clinical picture. It is important to differentiate these chronic syndromes from acute disorders, but this task may be difficult for both the patient and the physician. Prior records are helpful to identify the patient’s typical presentation. Patient with inflammatory bowel disease my present with exacerbations of the underlying disease,
,27 chronic noninflammatory pain, or coexistent irritable bowel syndrome. Differentiation of these disorders may require more than history and physical examination.
TABLE 38­4
Signs and Symptoms of Chronic Pain Syndromes of the Bowels
Disorder Pain Symptoms Signs
Centrally Near­continuous abdominal pain (6 months or longer); no or only occasional Absence of alarm signs*; may have mediated relationship of pain to physiologic events (e.g., eating, defecation, or menses); pain limits voluntary guarding, frequently has had abdominal pain daily functioning; pain is not explained by another structural or functional disorder. prior surgery, may have had surgery for syndrome Patients may previously have had a disorder causing abdominal pain with a clear lysis of adhesions.
(formerly, anatomic basis or that required prior surgery.
functional abdominal pain syndrome)
Narcotic bowel Must include all  of the following criteria: Absence of alarm signs*; may have syndrome . Chronic or recurrent abdominal pain that is treated with acute high­dose or chronic voluntary guarding. Would be expected to narcotics. test positive for opioids, unless test is not
. The nature and intensity of the pain is not explained by a current or previous GI specific to the opioids taken chronically.
diagnosis.
. Two or more of the following: a. The pain worsens or incompletely resolves with continued or escalating dosages of narcotics.
b. There is marked worsening of pain when the narcotic dose wanes and improvement when narcotics are reinstituted (soar and crash).
c. There is a progression of the frequency, duration, and intensity of pain episodes.
Irritable bowel Recurrent abdominal pain, on average, at least  day per week in the past  months, May have bloating or distention. May have syndrome (IBS) associated with  or more of the following criteria: (1) related to defecation, (2) had multiple imaging studies. Patients with pain (2 associated with a change in frequency of stool (diarrhea or constipation), or (3) with depression and anxiety seek care for types: IBS– associated with a change in form (appearance) of stool. abdominal pain more frequently.
diarrhea predominant and IBS– constipation predominant)
Inflammatory Recurring episodes of crampy abdominal pain, fatigue, and diarrhea, with or without Exacerbations of chronic pain should be bowel disease, fever and blood per rectum, are typical symptoms of Crohn’s disease and ulcerative distinguished from exacerbations in bowel
Crohn’s disease, colitis. Twenty percent of patients with inflammatory bowel disease have chronic wall inflammation using both clinical and and ulcerative abdominal pain despite resolving inflammation and clinical remission; chronic opioid objective factors; smoking, prior colitis use is associated with exacerbations of pain in the absence of active bowel wall outpatient opioid use, and psychiatric inflammation. Coexisting diagnosis of irritable bowel syndrome associated with chronic diagnoses are associated with opioid use. exacerbations of chronic pain.
*Alarm signs: unintentional weight loss, abdominal mass, positive fecal blood, anemia, hypoalbuminemia, abnormal liver function tests, elevated erythrocyte sedimentation rate, and elevated C­reactive protein.
Chronic Pelvic Pain Syndromes
Chronic pelvic pain be due to more than one etiology (Table 38­5), and consideration should be given to coexistent syndromes, such as irritable
28­31 bowel syndrome, or other chronic abdominal pain syndromes (Table 38­3). If the history suggests an atypical presentation of pain or related symptoms, a pelvic exam should be done to rule out new palpable pathology. The most common diagnosis at the time of laparoscopy for the
 evaluation of chronic pelvic pain in woman is endometriosis; however, endometriosis may exist without pain. Post–pelvic inflammatory
,30 disease pain and interstitial cystitis (bladder pain syndrome) are common causes of chronic abdominal pain.
TABLE 38­5
Signs and Symptoms of Chronic Pelvic Pain Disorders
Disorder Pain Symptoms Signs
Endometriosis Defined as the presence of endometrial glands and stroma outside of the normal location, Diagnosis is usually made with typically over pelvic peritoneum or ovaries. Pain is constant (noncyclic) in middle to lower laparoscopy or MRI. Patients with pelvis, but may slowly intensify. Dysmenorrhea or dyspareunia may herald worsening of postcoital bleeding, postmenopausal pain or be the presenting complaint. Uncommonly, there is dysuria (bladder involvement) bleeding, weight loss, pelvic mass, or or pain with defecation (rectosigmoid involvement). hematuria should have further testing or referral.
Post–pelvic 30%–36% of patients treated for PID develop chronic pain. An exacerbation of chronic Patients often have cervical motion inflammatory pelvic pain in a patient with prior PID is unlikely to be associated with fever, mucopurulent tenderness, possibly with uterine and disease (PID) discharge, cervical friability, elevated C­reactive protein, or erythrocyte sedimentation rate. adnexal tenderness. Patients with pelvic chronic pelvic Patients with postcoital bleeding, postmenopausal bleeding, or weight loss should have mass or hematuria should have further pain further testing or referral. testing or referral.
Interstitial Suprapubic pain, occasionally radiating to groin, vagina, rectum, or sacrum, exacerbated by Suprapubic tenderness, negative cystitis/bladder bladder fullness and relieved partially by voiding. Symptoms are worsened by fluid intake. urinalysis; cystoscopy commonly pain syndrome performed but controversial.
DIAGNOSIS
The most important task is to distinguish an exacerbation of chronic pain from a life­ or limb­threatening condition. The history and physical examination should either confirm the chronic condition or point to the need for further evaluation when unexpected signs or symptoms are elicited.
Because patients with chronic pain may be frequent visitors to the ED, the entire staff may prejudge complaints as simply chronic or even factitious.
Follow routine procedures, including a standard triage assessment and a complete set of vital signs.
After eliminating potential conditions that require emergent treatment, clinical judgment determines if focused management of pain is an appropriate course of action in the ED. The principles of focused management are to identify that symptoms are an exacerbation or continuation of a chronic pain pattern, provide appropriate rescue therapy for pain relief, and reinforce the need for a single provider (physician or clinic) for ongoing pain management.
Rarely is a provisional diagnosis of a chronic pain condition made for the first time in the ED. Definitive assessment for chronic pain conditions is difficult and requires expert opinion and often advanced procedures such as MRI, CT, and thermography. Furthermore, abnormal results usually do not confirm with certainty the cause of pain. For example, abnormalities on MRI of the spine and extremities are common in both asymptomatic and symptomatic patients. Therefore, referral back to the primary source of care is warranted to confirm the diagnosis.
The diagnosis of a chronic abdominal or pelvic pain syndrome is clinically based (Tables 38­3, 38­4, 38­5) but frequently requires testing to exclude other disorders. A specialist is best suited to make the diagnosis of these syndromes (specialist type will depend on the syndrome). However, emergency physicians who suspect a diagnosis should refer the patient for confirmation. When laboratory investigation is warranted by an atypical presentation or physician suspicion of an acute disorder, the presence of a new anemia, elevated white blood cell count, elevated creatinine, hypoalbuminemia, abnormal liver function tests, elevated erythrocyte sedimentation rate, or elevated C­reactive protein may warrant imaging or other additional testing. Stable patients can be discharged to follow­up for further testing. When the diagnosis cannot be determined during the ED visit, patient acuity should determine the need for admission.
TREATMENT
OPIOIDS FOR CHRONIC PAIN
Opioids are not recommended for the ED treatment of chronic pain. The use of opioids to treat chronic, noncancer pain in the United States
,33 increased rapidly from 1986 to 2010. A similar increase in opioid prescribing was seen upon ED discharge, from .8% to .0% between 2001 and
,35
2010. With the growth in opioid prescribing, the age­adjusted rate for opioid­analgesic poisoning deaths nearly quadrupled from .4 per 100,000 in

1999 to .4 per 100,000 in 2011. Poisoning is now the most common cause of injury­related death in the United States, surpassing motor vehicle– related death.
In response to the dramatic increase in opioid­analgesic poisoning, state agencies created statewide prescription drug monitoring programs
37­39 accessible by the Internet for registered medical providers to view controlled substance prescriptions that a patient has received. Although helpful,
 drug monitoring programs have not been shown to reduce opioid prescribing. In contrast, individual hospital opioid­prescribing policies reduce
 opioid prescribing. The American College of Emergency Physicians, individual states, and the Centers for Disease Control and Prevention have issued
42­45 guidelines on the prescription of opioids for patients discharged from the ED (Table 38­6).
TABLE 38­6
Summary of Key Guideline Recommendations for Prescribing Opioids to Adult Patients in the ED42­45
*For the treatment of back pain, given a lack of demonstrated evidence of superior efficacy of either opioid or nonopioid analgesics, and the individual and community risks associated with opioid use, misuse, and abuse, opioids should be reserved for more severe pain or pain refractory to other analgesics rather than routinely prescribed.
†If opioids are indicated, the prescription should be for the lowest practical dose for a limited duration (e.g.,  days), and the prescriber should consider the patient’s risk for opioid misuse, abuse, or diversion.
*Emergency providers should avoid the routine prescribing of outpatient opioids for a patient with an acute exacerbation of chronic noncancer pain seen in the ED.
*The clinician should, if practicable, honor existing patient–physician pain contracts/treatment agreements.
*The clinician should, if practicable, consider past prescription patterns from information sources such as prescription drug monitoring programs.
‡The administration of IV and IM opioids in the ED for the relief of acute exacerbations of chronic pain is discouraged.
‡Emergency medical providers should not provide replacement prescriptions for controlled substances that were lost, destroyed, or stolen.
‡Long­acting or controlled­release opioids (such as OxyContin®, fentanyl patches, and methadone) should not be prescribed from the ED.
‡Prescriptions for controlled substances from the ED should state that the patient is required to provide a government­issued picture identification (ID) to the pharmacy filling the prescription.
‡Emergency medical providers should not provide replacement doses of methadone for patients in a methadone treatment program.
‡If the emergency medical provider decides to prescribe opioids to a patient with chronic pain, the provider should only prescribe enough pills to last until the office of the patient’s primary opioid prescriber opens.
*2012 American College of Emergency Physicians policy.
†Centers for Disease Control and Prevention guidelines.
‡
Washington State Opioid Prescribing guidelines.
CANNABIS FOR CHRONIC PAIN

Many patients with chronic pain self­medicate with cannabis. Medical use of cannabis has significant health risks but may offer benefits in some
,48 patients.
TREATMENT OF CHRONIC NONNEUROPATHIC PAIN SYNDROMES
49­55
Evidence­based treatment for chronic nonneuropathic pain syndromes is divided into primary and secondary treatment modalities (Table 38­7).
For management in the ED, an acute exacerbation of a chronic migraine can be treated like an exacerbation of episodic migraine (see Chapter 165,

“Headache”).
TABLE 38­7
Management of Nonneuropathic Chronic Pain Syndromes
Disorder Primary Treatment Secondary Treatment Possible Referral Outcome
Myofascial NSAIDs orally, topical diclofenac Amitriptyline Trigger point injections or dry needling, US treatments, pain patch for single site of pain optimization of medical therapy, recommendations for exercise syndromes
Chronic See Chapter 165, “Headache,” for Prophylaxis with sodium Optimization of medical therapy, evaluation for use of migraine treatment of acute exacerbations valproate or topiramate prophylactic onabotulinumtoxinA headache
Medication Stop prior medications Celecoxib or prednisone Optimization of medical therapy, withdrawal of prior overuse taper during withdrawal medications, evaluation for use of prophylactic headache period onabotulinumtoxinA
Medication dosing for above indications: amitriptyline  milligrams PO at bedtime; celecoxib 400 milligrams PO per day for the first  days, then decreased at a rate of 100 milligrams every  days; diclofenac .3% patch every  hours over single site of focal pain; prednisone  milligrams PO per day for the first  days then tapered down to a dose of  milligrams every  days; sodium valproate 250 milligrams PO two times daily; topiramate  milligrams PO at bedtime during first week, then  milligrams two times daily during second week, with further dose adjustments at follow­up.
Treatment in the ED should never be regarded as definitive, and follow­up care is essential. Many emergency providers will elect to prescribe shortacting nonspecific pain medications (Table 38­7) for patients with chronic pain, deferring initiating of more specific therapy for the primary care physician or pain specialist. Specialty referral may provide optimization of therapy, trigger point injections, and novel treatments, such as onabotulinumtoxinA injections.
TREATMENT OF CHRONIC NEUROPATHIC PAIN SYNDROMES
56­69
Evidence­based treatment for chronic neuropathic pain syndromes is divided into primary and secondary treatment modalities (Table 38­8).
TABLE 38­8
Management of Neuropathic Chronic Pain
Primary
Disorder Secondary Treatment Possible Referral Outcome
Treatment
Fibromyalgia Pregabalin Duloxetine Exercise program; optimization of medical therapy
Trigeminal neuralgia Carbamazepine Oxcarbazepine Optimization of medical therapy; consideration for surgery or radiation
HIV­related neuropathy pain Gabapentin Topical capsaicin Optimization of medical therapy including antiretroviral medications
Spinal cord pain Pregabalin Tramadol Optimization of medical therapy
Painful diabetic neuropathy Duloxetine Gabapentin or pregabalin Optimization of medical therapy
Postherpetic neuralgia Pregabalin or Lidocaine patch Optimization of medical therapy; gabapentin regional nerve blockade
Phantom limb pain Gabapentin Referral for mirror therapy Optimization of medical therapy; ketamine infusion
Poststroke pain Pregabalin Gabapentin Optimization of medical therapy
Complex regional pain syndrome types I and II (reflex Acute phase: Chronic: intermittent ketamine, Physical therapy, individualized therapy sympathetic dystrophy and causalgia) prednisone bisphosphonates, by specialist based on neurologic testing
Dosing for above indications can be started as follows: capsaicin is best started at follow­up as pain increases before it decreases; carbamazepine 100 milligrams PO two times daily; duloxetine  to  milligrams PO daily; gabapentin 300 milligrams PO, once on day , two times day , then three times daily, eventually increasing to 1200 milligrams per day guided by follow­up clinician; lidocaine patch 5%, up to three patches at a time, apply for up to  hours per day; oxcarbazepine 300 milligrams PO two times daily for  days, 300 milligrams at morning and 600 milligrams at evening for  days, then 600 milligrams two times daily; prednisone  milligrams PO daily for  days to be adjusted by follow­up physician; pregabalin  milligrams PO three times per day; tramadol  milligrams PO every  hours as needed.
Abbreviation: HIV = human immunodeficiency virus.
There is no convincing unbiased evidence to support the use of opioids (specifically oxycodone) in the treatment of neuropathic pain, including
  fibromyalgia. Duloxetine is favored over pregabalin and gabapentin in the treatment of painful diabetic neuropathy. Human immunodeficiency
 syndrome–related neuropathy is resistant to many therapies commonly used for neuropathic pain; gabapentin is recommended. Topical capsaicin is
 effective for chronic neuropathic pain, but is best directed by a specialist because pain increases at first application and pretreatment with topical
  lidocaine may be required. Phantom limb pain responds poorly to medication ; mirror therapy provides some benefit. Poststroke pain responds
 poorly to most therapies.
Tramadol reduces pain in most neuropathic pain syndromes, but is considered secondary treatment because it is less effective than the primary
,71  treatments (Table 38­8). Complex regional pain syndrome is resistant to most therapies. An IV infusion of ketamine may reduce pain for up to 
 weeks but does not improve function. Corticosteroids (prednisone,  milligrams PO once a day) have been recommended at the time of first
 diagnosis when signs of inflammation are present, but steroids do not affect the course of illness. Although considered second line, cyclic antidepressants are effective therapy for most patients with neuropathic pain, except spinal cord injury pain, phantom limb pain, human immunodeficiency virus–related neuropathy, and chronic regional pain syndrome. Amitriptyline can be started at  milligrams PO nightly and escalated by the follow­up clinician. Complete relief of pain is an unrealistic goal for patients with chronic pain, both for the ED visit and for follow­up care; patients should be informed of this limitation early in their ED course.
TREATMENT OF CHRONIC ABDOMINAL AND PELVIC PAIN SYNDROMES
,22,28,72­87
Patients with chronic abdominal and pelvic pain syndromes may require acute treatment (Table 38­9). Potent opioid analgesics are
 associated with narcotic bowel syndrome and should be avoided, unless a single dose is required to obtain an abdominal examination to minimize
 voluntary guarding. Antinausea medication and IV fluids may be required. Nonopioid analgesics should be provided as the individual case requires, provided that the known side effect profile of the drug would not worsen the patient’s condition (e.g., NSAIDs exacerbating gastritis).
TABLE 38­9
Treatment of Selected Chronic Abdominal and Pelvic Pain Syndromes
Disorder Primary Management Secondary Management
Functional heartburn* Citalopram, other agents. Behavioral modification.
Reflux hypersensitivity* Standard­dose or double­dose proton pump inhibitor. Citalopram, other agents.
Functional dyspepsia with Amitriptyline; frequent, small, low­fat meals; avoid NSAIDs. Proton pump inhibitors, H blockers, Helicobacter
 epigastric pain syndrome* pylori eradication.
Cyclic vomiting syndrome (with Rehydration with .9% normal saline including dextrose; give Avoidance of triggers (stress, poor sleep, pain) ondansetron, ketorolac but opioids or lorazepam may be infections), management of common coexisting required for acute vomiting. disorders (irritable bowel syndrome, migraine headaches, gastroparesis, and anxiety).
Cannabinoid hyperemesis Stop cannabinoids; treat with antiemetics and hydration as for Substance abuse treatment as necessary, syndrome cyclic vomiting; avoid opioids. amitriptyline for recurrent cases.
Centrally mediated abdominal Specialty care for chronic abdominal pain; avoid opioids; Consider substituting duloxetine, add quetiapine.
pain syndrome (formerly, amitriptyline first line for chronic management.
functional abdominal pain syndrome)
Gastroparesis­related pain and Haloperidol reduces pain and need for hospital admission when Standard antiemetics and IV fluids.
vomiting* compared to other antiemetics.
Narcotic bowel syndrome May require admission with 15%–30% reduction in daily For outpatient management, consider 4­ to 6­week narcotic dose per day; give antiemetics for vomiting and withdrawal duration. Maintenance of benzodiazepines for anxiety as needed. Augment first day with antidepressant therapy and ongoing outpatient amitriptyline and continue at discharge. care for prevention of repeat ED visits.
Irritable bowel syndrome (IBS) For constipation: psyllium, polyethylene glycol. For pain: Change in diet (per specialist, after testing); for with pain (2 types: IBS–diarrhea dicyclomine and/or amitriptyline. resistant symptoms, lubiprostone, linaclotide, and predominant and IBS– other medications.
constipation predominant)
Inflammatory bowel disease, Acute medical management discussed in Chapter , “Disorders Parenteral opioids are given in 70% of
Crohn’s disease, and ulcerative Presenting Primarily With Diarrhea.” hospitalizations; outpatient opioids should be colitis limited and/or replaced with dicyclomine and amitriptyline.
Endometriosis Progesterone orally (or long­acting injection at follow­up). Levonorgestrel­releasing intrauterine system or
NSAIDs. goserelin at follow­up.
Post–pelvic inflammatory NSAIDs are the most common treatment for pain. Empiric Amitriptyline, with or without gabapentin.
disease chronic pelvic pain treatment for possible reinfection of a sexually transmitted disease should be considered.
Interstitial cystitis/bladder pain Amitriptyline. Pentosan polysulfate sodium (coating agent), syndrome hydroxyzine, gabapentin.
*Referral to specialist in chronic abdominal pain or gastroenterologist that performed the original endoscopy.
Note: Dosing for above indications can be started as follows: amitriptyline  to  milligrams daily at bedtime; citalopram  milligrams daily; dicyclomine  to  milligrams up to four times daily; duloxetine  to  milligrams daily; gabapentin, 300 milligrams PO, once on day , two times on day , then three times daily; haloperidol  milligrams IV; ketorolac  to  milligrams IV; linaclotide 290 micrograms daily; lorazepam  to  milligrams; lubiprostone  micrograms twice daily; ondansetron  to  milligrams acutely; polyethylene glycol  to  grams daily; progesterone  to  milligrams daily; psyllium up to  grams per day divided two to three times daily; quetiapine  to 100 milligrams daily; hydroxyzine  milligrams every  to  hours.
TREATMENT OF CHRONIC PAIN IN THE ELDERLY AND MENTALLY IMPAIRED

The prevalence of chronic pain increases with age. Opioid analgesic alternatives, such as NSAIDs, have side effects that may limit their use in the elderly who are prone to GI and renal complications; however, when compared to opioids, NSAIDs have fewer side effects overall and are less likely to
 lead to premature death in the elderly. GI bleeding rates are similar for patients treated with opiates or nonselective NSAIDs and lower for those
 treated with cyclooxygenase­2 inhibitors. NSAIDs should not be given to patients with renal dysfunction. Topical analgesics (lidocaine 5% or
 capsaicin 8%) are effective and can be given alone or as adjuncts. Topical NSAIDs provide excellent joint and tissue levels with low plasma levels and
 are available as diclofenac gel, patch, or topical solution.
Cognitively and mentally impaired adults with chronic pain are at risk for inadequate pain control due to barriers in communicating the nature and intensity of their pain. Be alert to these potential barriers and look for nonverbal signs of pain: agitation, irregular breathing, facial expressions of pain, stiffened body positioning, and reports of irregular sleep patterns. Undesired side effects, such as sedation, may limit the use of certain pain medications in this population.
DISPOSITION AND FOLLOW­UP
Referral to an appropriate specialist is one of the most productive means of aiding in the care of chronic pain patients who present to the ED. Chronic pain clinics have been successful in changing the lives of patients by eliminating opioid use, decreasing medication use, reducing pain levels, and increasing work hours. Patients’ compliance with pain clinics may improve if these benefits are explained. Admission to the hospital is rarely indicated.
However, occasionally patients may be admitted for pain control, possibly using self­controlled analgesic administration.
ABERRANT DRUG­RELATED BEHAVIOR
INTRODUCTION
The term drug­seeking behavior is imperfect, and its definition varies among clinicians. A more accurate term is aberrant drug­related behavior, which raises concern for addiction and opioid misuse (Table 38­10). The spectrum of people seeking controlled drugs includes those who have chronic pain and have been prescribed limited opioids, the drug addict who is trying to supplement a habit, and the “hustler” who is obtaining prescription drugs to sell on the street. However, the ability of the physician to correctly identify individuals in any of these three categories is difficult and imperfect.
TABLE 38­10
Aberrant Drug­Related Behaviors
Forges/alters prescriptions* Sells controlled substances* Uses aliases to receive opioids* Current illicit drug use* Factitious illness, requests opioids
Conceals multiple physicians prescribing opioids
Abusive when refused
Conceals multiple ED visits for opioids
*Unlawful behaviors in many states.
The prevalence of aberrant drug­related behaviors is not known; however, there is considerable indirect evidence of the problem. A systematic review of the literature found that the only consistent predictor of aberrant drug­related behaviors in chronic pain patients is a personal history of illicit drug
 and alcohol abuse. A separate systematic review of chronic nonmalignant pain patients exposed to chronic opioid analgesic therapy found that

.4% of patients had negative urine tests for prescribed opioids despite filling regular prescriptions, and .5% tested positive for illicit drugs. In

2012, 17% of the teens trying illicit drugs for the first time used prescription opioids, second only to marijuana. Individuals attempting to secure
 opioids from emergency providers are often successful through persistence.
CLINICAL FEATURES
The history given may be factual or fraudulent. Patients may be demanding, intimidating, or flattering. The most common complaints of patients who
 attempt to obtain opioids from the ED are (in decreasing order) back pain, headache, extremity pain, and dental pain. Patients may complain of panic disorder or drug withdrawal symptoms and request benzodiazepines. In some cases, observation of vital signs and physical examination findings will help identify factitious illness, but even experienced clinicians are frequently misled.
Patients should be examined for signs of injection drug use, including needle marks, and the heart should be examined for evidence of a regurgitant murmur indicative of valve damage from prior endocarditis. Look for key characteristics of patients attempting to falsify illness (Table 38­11).
Patients most commonly have completely normal physical examination findings. Widespread anecdotal experience of ED personnel has indicated that such patients will relate an allergy to alternative pharmacotherapy and insist that only one or two specific opioids are effective.
TABLE 38­11
Recommendations to Manage Fraudulent Techniques Used by Patients Attempting to Obtain Opioids for Illicit Use
Technique Characteristics Management
Lost prescription Calls or returns stating that opioid prescription was lost before Establish a policy: no lost opioid prescriptions being filled. refilled.
Notify patients of policy at discharge as they receive prescriptions.
“Stolen” prescription or pill Police have not been called. Inform patient this is a police issue and bottle recommend calling police to rectify matter.
Establish a policy: no stolen opioid prescriptions refilled.
Impending surgery Wants temporizing opioids, doctor “unavailable,” previous Use Internet and phone calls to check validity of surgery, patient from out of town. information.
Check medical records.
Offer substitute for opioid.
Carries own records and Suspicious or forged records, doctor’s written permission to Use Internet and phone calls to check validity of radiographs receive opioids, patient from out of town. information.
Check medical records.
Offer substitute for opioid.
Factitious hematuria with Appears comfortable or overacting, pricked finger dipped in urine, Examine fingers and mouth.
complaint of kidney stones lip/cheek bitten and blood spat into urine. Obtain witnessed urinalysis.
Offer nonopioid pain medicine.
Obtain confirmatory test before giving opioid.
Self­mutilation Done with dominant hand, requests opioids for pain. Use bupivacaine for local block.
Do not prescribe opioids without indications.
Offer substitute for opioids.
Dental pain Dental caries only. Perform local nerve block with bupivacaine.
Refer to dentist.
Factitious injury Old injury, old deformity, self­massaged to produce erythema; Radiograph before treatment.
patient from out of town. Check medical records.
Check for erythema that dissipates over time.
DIAGNOSIS
The diagnosis of aberrant drug­related behavior may not be possible in the ED. The medical record can provide a wealth of information about the patient, including documentation proving that the patient is supplying false information. Often the diagnosis is suspected in the ED but cannot be confirmed. In such cases, the clinical impression should be documented in the chart listing the provider’s concerns, but physicians should be careful when using terms such as drug­seeking behavior; instead, document the concerning facts. Electronic medical records can be programmed to flag charts with alerts for patient safety; accidental overdose is always a concern in such patients.
Do not miss a true emergency in patients suspected of aberrant drug­related behaviors because the negotiation over pain medicine can distract the entire team from a subtle yet life­threatening medical or surgical illness.

Prescription drug monitoring programs and other computerized tracking systems help identify patients who are abusing or overusing prescription drugs. Practitioners are encouraged to review the prescription drug monitoring program database before prescribing a discharge medication, because
 that information may change the intended discharge plan.
TREATMENT AND DISPOSITION
The treatment of definite aberrant drug­related behavior is to refuse the controlled substance, consider the need for alternative medication or treatment, and refer for drug counseling. When confronted, patients hoping to acquire opioids may become verbally abusive, and hospital security may be required to control the situation and, if necessary, escort the patient out of the ED. Inform the patient that you are not able to prescribe or administer the medication they seek, and offer a substitute.
When aberrant drug­related behavior is confirmed or suspected in the ED, it should be documented in the chart, stating only the facts. Concerns about opioid overuse can be documented without diagnosing the patient with “drug­seeking behavior,” which may not be appropriate without evidence of illegal behavior. When physicians are notified by a pharmacist of forged or altered prescriptions, law enforcement authorities should be called, and physicians should cooperate with the legal investigation. The prosecution of fraudulent behaviors, such as using aliases to obtain opioids, requires the involvement of the state bureau of investigation or a similar state agency.
SPECIAL CONSIDERATIONS: LEGAL ISSUES
The U.S. Drug Enforcement Agency (in addition to state agencies) licenses physicians to administer or dispense controlled substances. However, state law determines most prescribing regulations. Physicians should be aware of state laws regulating controlled substances prescribed in their practice setting. The prescribing of opioids to a known drug addict could result in restriction of the physician’s medical license in some states, although this is rarely prosecuted for isolated incidents. If a patient refuses to acknowledge an addiction, the physician cannot be held accountable unless medical records at the facility where the patient presents document the addiction. In all states, it is illegal for patients to forge or alter prescriptions. In some states, it is illegal for patients to use aliases or factitious illness to obtain opioids. Furthermore, in some states, concealing previous or recent prescriptions for opioids when requesting opioids from a new practitioner is illegal.


