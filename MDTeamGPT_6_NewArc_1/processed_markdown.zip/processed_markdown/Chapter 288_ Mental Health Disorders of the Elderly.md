## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 288: Mental Health Disorders of the Elderly
Christina L. Shenvi
INTRODUCTION
Delirium Associated with COVID­19 January 2021
Delirium is a common presenting symptom, and sometimes is the main presenting symptom, of COVID­19. Consider COVID­19 screening in the elderly with delirium. See further discussion in the section 'COVID­19 Associated Delirium.'

The proportion of ED visits by older adults is expected to continue its rapid increase over the coming decades. As a result, we can expect to see many patients who present for, or present with, mental health disorders. In 2013, the American Psychiatric Association released the fifth edition of the

Diagnostic and Statistical Manual of Mental Disorders, in which they introduced the terms mild and major neurocognitive disorder, the latter of which was previously called dementia. We will continue to use the term dementia to represent major neurocognitive disorder in this chapter. Delirium, dementia, and depression affect many older adults, and the differentiation of these disorders can be challenging because they are interrelated.
 4–7
Patients with dementia are more likely to develop delirium, and patients who experience delirium are more likely to develop dementia later in life.
It can also be difficult to diagnose depression in patients with dementia, as both disorders can demonstrate similar symptoms such as apathy and
 behavioral changes. Also, depression in late life has been associated with an increased risk of developing dementia, further demonstrating that dementia, delirium, and depression are interconnected, increase the risk of each other, and are all associated with an increased risk of mortality and
9–15 morbidity. Table 288­1 provides distinguishing features of delirium, dementia, and psychiatric disorders. Chapter 168, “Altered Mental Status and
Coma,” and Chapter 286, “Mental Health Disorders: ED Evaluation and Disposition,” also discuss the distinctions between delirium, minor neurocognitive disorder, and psychiatric disorders.
TABLE 288­1
Features of Delirium, Dementia, and Psychiatric Disorder
Characteristic Delirium Dementia Psychiatric Disorder
Onset Over days Insidious Varies
Course over  h Fluctuating Stable Varies
Consciousness Reduced or hyperalert Alert Alert or distracted
Attention Disordered Normal May be disordered
Cognition Disordered Impaired Rarely impaired
Orientation Impaired Often impaired May be impaired
Hallucinations Visual and/or auditory Often absent May be present

Delusions Transient, poorly organized Usually absent Sustained
Chapter 288: Mental Health Disorders of the Elderly, Christina L. Shenvi 
. Terms of Use * Privacy Policy * Notice * Accessibility
Movements Asterixis, tremor may be present Often absent Varies
Finally, the management of acute delirium, psychosis, or behavioral disturbances in older adults in the ED can be difficult. Medications such as benzodiazepines and antipsychotics, which are frequently used in younger agitated patients, may have significant side effects in older patients, such as prolonged sedation, or paradoxical agitation with benzodiazepines. Medications for acute agitation should be selected carefully and typically at lower doses than for younger patients, and should only be used after nonpharmacologic modifications and interventions have been exhausted.
DELIRIUM
Delirium is an acute change in cognition that fluctuates rapidly over time and is often reversible. Delirium is frequently the first sign of an underlying acute medical illness. Patients demonstrate altered levels of consciousness, inattention, disorganized thinking, and altered perception. There are
 three main types of delirium: hypoactive, hyperactive, and mixed. By far, the most common types are hypoactive and mixed delirium, which also have
17–23 the highest potential to be missed. Hypoactive delirium has been called “quiet delirium” because patients have decreased psychomotor activity
24–26 and can appear somnolent. If hypoactive delirium is confused for depression, the underlying medical disorder causing the delirium can be missed.
Hyperactive delirium, in contrast, is characterized by increased psychomotor activity. Patients with hyperactive delirium are often agitated, anxious, and sometimes combative. Mixed type can present with a combination of both hyperactive and hypoactive states that fluctuate over time.
,27,28
Delirium is present in 7% to 10% of older patients presenting to the ED. Environmental risk factors for delirium include functional dependence,
,29 living in a nursing home, and hearing impairment. Delirium in the ED is an independent predictor of 6­month mortality. Delirium is associated with a longer hospital length of stay, more in­hospital complications, higher likelihood of discharge to long­term care facilities, and lasting cognitive
30–37 ,38­41 deficits. Even though delirium is a common disorder in the elderly, the diagnosis may be missed by providers in 57% to 83% of cases. If
 delirium is missed in the ED, it is likely to be missed on the inpatient services as well.
CLINICAL FEATURES
The differential diagnosis of delirium includes minor neurocognitive disorder, depression, or another underlying psychiatric disorder. Such conditions can also be comorbidities of each other. However, it is important to first assess for delirium and then consider the possibility of the other disorders. If delirium is suspected, the history and physical should be thorough to help determine the underlying cause.
History
It is important when taking the history to find out the patient’s baseline mental status and level of functioning, and the time course of changes. This may require calling the patient’s family members or their facility to obtain collateral information. Patients with delirium may not be able to provide a clear history, or may confabulate. Ask a reliable source about past medical history and recent illness. Obtain an accurate medication list, and ask about
 over­the­counter medications, particularly medications with anticholinergic properties, or any new medications. Ask about substance abuse to assess the likelihood of intoxication or withdrawal. Any past psychiatric history requires close investigation of prior diagnoses, hospitalizations, and medications. Determine the patient’s ability to make informed medical decisions, and determine whether another individual has legal power of attorney for medical decision making.
When attempting to differentiate delirium from minor neurocognitive disorder, consider several key factors. An acute change in mental status is more
 consistent with delirium than with minor neurocognitive disorder, and a fluctuating course over time is also more likely due to delirium. Altered level
 of consciousness, inattention, and disorganized thinking are all more common in delirium than in minor neurocognitive disorder. However, delirium is more likely to occur in patients who have underlying minor neurocognitive disorder, so features of both may be present.
Physical Examination
The physical examination should be thorough. Vital signs must be complete, including oxygen saturation and temperature. Baseline blood pressures are usually higher than in younger age groups, with a wider pulse pressure. Older patients may not be able to mount a tachycardic response to physiologic stress either due to effects of medications such as β­blockers, or because of physiologic limitations. Older patients have lower basal
 temperatures, with means of .3 to .8°F depending on the time of the day, so the threshold for a fever is lower. Look for evidence of trauma, as patients may not recall falling or injuring themselves. Examine the entire body, making sure to look at the patient’s back and heels for evidence of decubitus ulcers. Check between the toes for infections such as tinea or cellulitis. Perform a complete neurologic exam, looking for focal findings, abnormal posturing, or difficulty with gait, coordination, or vision. A normal physical examination does not exclude the diagnosis of delirium.
Mental Status Examination
,35,38­41,45,46
Mental status examination is performed to identify delirium and to differentiate it from other conditions. The examination consists of an assessment of six mental­behavioral components (Table 288­2).
TABLE 288­2
Mental Status Examination
Appearance, behavior, and attitude
Is dress appropriate?
Is motor behavior at rest appropriate?
Is the speech pattern normal?
Disorders of thought
Are the thoughts logical and realistic?
Are false beliefs or delusions present?
Are suicidal or homicidal thoughts present?
Disorders of perception
Are hallucinations present?
Mood and affect
What is the prevailing mood?
Is the emotional content appropriate for the setting?
Insight and judgment
Does the patient understand the circumstances surrounding the visit?
Sensorium and intelligence
Is the level of consciousness normal?
Is cognition or intellectual functioning impaired?
Two of the most common screening tests used to detect delirium are the Confusion Assessment Method for general use and the Confusion
,48
Assessment Method–Intensive Care Unit for intubated patients who are not heavily sedated. Figure 288­1 outlines the components of the
Confusion Assessment Method. Inattention is characterized by an easily distracted patient who has difficulty keeping track of the conversation.
Disorganized thought processes are rambling, unclear, or illogical. An altered level of consciousness is lethargy, lack of responsiveness, or coma— essentially anything other than alert. The diagnosis of delirium requires features  and  and either  or . See Table 288­3 for further details about
,48 using the Confusion Assessment Method and the Confusion Assessment Method–Intensive Care Unit.
FIGURE 288­1
Confusion Assessment Method (CAM). To make a diagnosis of delirium, the patient must have features  and  and either  or . Following are the four components of CAM: Feature 1: Acute onset of mental status changes or a fluctuating course.Feature 2: Inattention.Feature
3: Disorganized thinking.Feature 4: Altered level of consciousness.A positive diagnosis involved features  and  along with either feature  or feature . TABLE 288­3
Confusion Assessment Method and Confusion Assessment Method (CAM)–Intensive Care Unit* Confusion Assessment Method Confusion Assessment Method–Intensive Care Unit Version
Feature . Is there evidence of an acute change in mental status Is there evidence of an acute change in mental status from the baseline?
Acute Onset or from the patient’s baseline? Did the (abnormal) behavior fluctuate during the past  h, that is, tend to
Fluctuating Did the (abnormal) behavior fluctuate during the day, come and go or increase and decrease in severity?
Course that is, tend to come and go, or increase or decrease in Sources of information: Serial Glasgow Coma Scale or sedation score ratings severity? over  h, as well as readily available input from the patient’s bedside
Sources: Family or nurse critical care nurse or family
Feature . Did the patient have difficulty focusing attention, for Did the patient have difficulty focusing attention?
Inattention example, being easily distractible or having difficulty Is there a reduced ability to maintain and shift attention?
keeping track of what was being said? Sources of information: Attention screening examinations by using either picture recognition or Vigilance A random letter test. Neither of these tests requires verbal response, and thus they are ideally suited for mechanically ventilated patients.
Feature . Was the patient’s thinking disorganized or incoherent, Was the patient’s thinking disorganized or incoherent, such as rambling or
Disorganized such as rambling or irrelevant conversation, unclear or irrelevant conversation, unclear or illogical flow of ideas, or unpredictable
Thinking illogical flow of ideas, or unpredictable switching from switching from subject to subject?
subject to subject? Was the patient able to follow questions and commands throughout the assessment?
“Are you having any unclear thinking?”
“Hold up this many fingers.” (Examiner holds two fingers in front of the patient)
“Now, do the same thing with the other hand.” (Not repeating the number of fingers)
Feature . Is the patient’s mental status anything other than alert, Any level of consciousness other than “alert.”
Altered Level for example, vigilant, lethargic, stuporous, or comatose? Alert—normal, spontaneously fully aware of environment and interacts of appropriately
Consciousness Vigilant—hyperalert
Lethargic—drowsy but easily aroused, unaware of some elements in the environment, or not spontaneously interacting appropriately with the interviewer; becomes fully aware and appropriately interactive when prodded minimally
Stupor—difficult to arouse, unaware of some or all elements in the environment, or not spontaneously interacting with the interviewer; becomes incompletely aware and inappropriately interactive when prodded strongly
Coma—unarousable, unaware of all elements in the environment, with no spontaneous interaction or awareness of the interviewer, so that the interview is difficult or impossible even with maximal prodding
*To diagnose delirium, the patient must have features  and  and either  or . There are also standardized questions that can be used to formalize the Confusion Assessment Method assessment. One such method is the 3D­
Confusion Assessment Method, which is a 3­minute structured assessment developed and validated for Confusion Assessment Method–defined
,50 delirium, with tasks or questions to test for each of the Confusion Assessment Method criteria.
Laboratory Testing and Imaging

Laboratory testing and imaging are obtained to identify the underlying causes of delirium (Table 288­4) and to direct treatment.
TABLE 288­4
DELIRIUM: Mnemonic for Reversible Causes of Delirium
Drugs Any new additions, increased dosages, or interactions
Consider over­the­counter drugs and alcohol
Consider high­risk drugs* Electrolyte Dehydration, sodium imbalance, thyroid abnormalities disturbances
Lack of drugs Withdrawals from chronically used sedatives, including alcohol and sleeping pills
Poorly controlled pain (lack of analgesia)
Infection Especially urinary and respiratory tract infections
Reduced sensory input Poor vision, poor hearing
Intracranial Infection, hemorrhage, stroke, tumor
Rare; consider only if new focal neurologic findings, suggestive history, or diagnostic evaluation otherwise negative
Urinary, fecal Urinary retention: “cystocerebral syndrome”
Fecal impaction
Myocardial, pulmonary Myocardial infarction, arrhythmia, exacerbation of heart failure, exacerbation of chronic obstructive pulmonary disease, hypoxia
*High­risk drugs: anticholinergics, anticonvulsants, antidepressants, antihistamines, antiparkinsonian agents, antipsychotics, barbiturates, benzodiazepines, H ­
 blocking agents, zolpidem, opioid analgesics.
Reproduced with permission from Marcantonio ER: Delirium. In: Pacala JT, Sullivan GM, eds. Geriatrics Review Syllabus: A Core Curriculum in Geriatric Medicine, 7th ed. New York, NY: American Geriatrics Society; 2010:297. 
In geriatric patients, infections, such as urinary tract infections and pneumonia, are associated with nearly 50% of delirium cases, and medications
52–54 account for another 40%.
Laboratory Testing for Delirium
Check point­of­care glucose as soon as possible after the patient arrives in the ED. Other laboratory testing should be directed by the patient’s symptoms and presentation. However, often a broad range of tests may be needed to determine the underlying cause of the delirium. Obtain a CBC and basic metabolic studies and liver function tests. A urinalysis is necessary because urinary tract infections are a frequent cause of delirium.
However, the results of the urinalysis should be considered within the clinical context of new symptoms such as fever, dysuria, or new incontinence. It is also important to know that asymptomatic bacteriuria is very common in older adults, with rates of 5% for men and 6% to 10% for women who are
 community dwelling, and as high as 15% to 35% for men and 25% to 50% for women who are institutionalized. Incidental pyuria is also common, especially in those with chronic incontinence. Obtain cardiac markers and consider a blood gas analysis, especially in patients with chronic lung
  disease, because hypercarbia can cause delirium. Urine or serum toxicologic studies, a troponin level, and thyroid­stimulating hormone level may be in order. Lumbar puncture may be necessary (after CT scan) if there is suspicion for meningitis or encephalitis or if the patient has had a new­onset
 seizure. Further studies may be needed depending on the results of history, examination, and basic tests.
Imaging/Ancillary Tests

ECG and chest radiograph are essential. Head CT scan is advised for patients with signs of, or a history of, trauma, focal neurologic deficits, impaired
,59 level of consciousness, or an otherwise unrevealing evaluation.
TREATMENT
Prevention
Patients can develop delirium or their delirium can worsen while they are in the ED both because of their underlying disease process and because of the unfamiliarity and chaotic nature of the environment. In high­risk patients, such as the very old or those with a history of minor neurocognitive disorder, avoid medications that could be deliriogenic, such as anticholinergics or antihistamines, unless necessary. Titrate pain medications carefully to treat pain but avoid sedation. In addition, try to ensure the patient has access to fluids, hearing aids, and glasses whenever possible. Allow family or caregivers to stay at the bedside, provide frequent reorientation about surroundings and course of care, and make sure there is access to a
 bathroom. The Multicomponent Intervention to Prevent Delirium in Hospitalized Older Patients study identified six risk factors for the development of delirium and targeted each risk factor with specific interventions carried out by a multidisciplinary team. The risk factors included cognitive
 impairment, sleep deprivation, immobility, visual impairment, hearing impairment, and dehydration. Precipitating factors in the development of delirium in the hospital include the use of physical restraints, malnutrition, use of a bladder catheter, more than three medications added, and any
 iatrogenic event. Preventing and minimizing these factors are especially important when long ED stays are unavoidable.
Medical Treatment
Treatment should be directed toward the underlying cause of delirium. Withhold or remove medications that may be responsible for the delirium.
Treat infection, provide IV fluids for dehydration, correct hypoglycemia and other metabolic derangements, and treat pain.
Agitation
If the patient is agitated, begin with a nonpharmacologic approach by addressing patient needs (such as using the restroom and, if possible, allowing
,62 the patient to eat or drink), providing comfortable surroundings, and having the family close by. Avoid bladder catheters unless unavoidable. If these basic interventions and the preventive measures above are not successful, consider medication (Figure 288­2). We recommend the
 avoidance of benzodiazepines in the elderly if at all possible, unless alcohol withdrawal is the cause of delirium. Benzodiazepines can cause paradoxical disinhibition and increased agitation in the elderly. If a benzodiazepine is used, consider a short­acting agent such as lorazepam to minimize prolonged benzodiazepine effects. Avoid antihistamines, because this drug class has strong anticholinergic effects and can induce or worsen delirium in the elderly. Physical restraints should be an absolute last resort when patient or staff safety is in jeopardy. When it comes to psychiatric medications for acutely agitated older patients, the adage “start low and go slow” is particularly apt.
FIGURE 288­2
Acute agitation in the elderly: dosing considerations. BZDs = benzodiazepines.
Sequential stages are as follows:Treatment Stage 1: Consider nonpharmacologic treatment first. Consider delirium and possible causes. Avoid physical restraints.Medication: Reorientation; Modify environment; Attend to basic needs; Treat pain.Treatment Stage 2: Use oral route if possible.
Use lowest effective dose and repeat if needed,  minutes. Benzodiazepines within  to  hours of IM olanzapine are contraindicated. Cardiac history required with ziprasidone.Medication is of two types: Preferred and alternative pharmacotherapy.Preferred pharmacotherapy: Risperidone, or Risperdal:  milligram P O; or Olanzapine or Zyprexa, .5 to  milligrams P O, I M, NO B Z Ds with I M; or Quetiapine, or Seroquel,  milligrams
P O; or Haloperidol, or Haldol,  to .5 milligrams P O, I M. Alternative pharmacotherapy, Higher risk of Q T c prolongation: Ziprasidone , or
Geodon,  to  milligrams I M; or Haloperidol, Haldol, .25 to  milligram I V.Treatment Stage 3: Benzodiazepines are linked with causing or worsening delirium. Avoid benzodiazepines unless otherwise indicated for seizures, withdrawal, catatonia. Choose agents with lower risk of accumulation.Medication: Follow­up of preferred pharmacotherapy from stage . Lorazepam, Ativan, .5 to  milligram, P O, I M, I V; or Oxazepam,
Serax,  milligrams P O; or Temazepam, Restoril, .5 milligrams P O.
DISPOSITION AND FOLLOW­UP
The vast majority of patients with delirium should be hospitalized. Criteria for possible discharge include the following: the source of delirium has been identified and treated; the patient has returned to baseline function and mentation in the ED; the patient can be cared for after discharge by a capable individual or to a responsible facility; and the patient has access to follow­up in  hours or has the ability to return immediately to the ED if the condition deteriorates. Patients with unrecognized delirium who are discharged home are less able to understand discharge instructions and less
 likely to seek further treatment, underscoring the importance of screening for delirium in geriatric patients.
COVID­19 ASSOCIATED DELIRIUM
In a multi­center cohort study performed in seven emergency departments from March­May 2020, of 817 elderly patients with COVID­19, 28% had
 delirium at ED presentation . Of the 28% with delirium, 16% had delirium as the primary presenting symptom, and 37% had delirium without a fever or shortness of breath. Be aware of the association of delirium as the only presenting symptom of COVID­19 in the elderly, and consider COVID­19 screening in such patients.Delirium in the elderly with COVID­19 is associated with worse outcomes, including a higher rate of hospital admission, ICU stay, discharge to a rehabilitation facility and death. TABLE 288­5 and TABLE 288­6 describe the most common symptoms at presentation in the elderly with COVID­19, and comorbidities with the highest relative risk for development of COVID­19 associated delirium.
TABLE 288­5
The top  most common symptoms at presentation among older patients diagnosed with COVID­19. Symptom at presentation % of patients with symptom
Fever 
Shortness of breath 
Cough 
Hypoxia (O2 sat < 90%) 
Weakness 
Delirium 
Fatigue 
Diarrhea 
TABLE 288­6
Comorbidities with the highest relative risk for development of COVID­19 associated delirium
Factor RR (95% CI)
Vision impairment .98 (1.54­2.54)
Age <75 .51 (1.17­1.95)
Stroke .47 (1.15­1.88)
Prior psychoactive medications .42 (1.11­1.81)
Living in a nursing home or assisted living .23 (0.98­1.55)
Hearing impairment .47 (1.15­1.88)
DEMENTIA (MAJOR NEUROCOGNITIVE DISORDER)
In the fifth edition of the Diagnostic and Statistical Manual of Mental Disorders published in 2013, dementia was retermed major neurocognitive
 disorder, and the criteria for diagnosis were modified. The diagnosis now requires significant decline in cognitive function in one or more of the following cognitive domains: learning and memory, language, executive function, complex attention, perceptual­motor, and social cognition. The diagnosis cannot be made in the setting of delirium, and deficits should be severe enough that they interfere with the ability to live independently and perform all activities of daily living or independent activities of daily living. In addition, the cognitive deficits should not be attributable to other mental disorders such as major depressive disorder or schizophrenia.
The most common type of dementia (major cognitive disorder) is Alzheimer’s disease, which affects approximately  million people in the United
States.  Alzheimer’s disease is reported in 6% to 8% of those over  years old and in ≥30% of those over  years old.  Some other common types are vascular dementia, Lewy body dementia, frontotemporal dementia, dementia associated with Parkinson’s disease, and mixed dementia.
PATHOPHYSIOLOGY
Alzheimer’s disease has a gradual onset and primarily affects memory. The disease can also result in personality changes and visual­spatial
 problems. Vascular dementia characteristically has a sudden or stepwise onset, and symptoms typically correlate with the affected area of brain
 ischemia. Lewy body dementia has a gradual onset of memory deficits, and patients will also frequently have hallucinations and parkinsonian­like
 ,69 features. Patients with Lewy body dementia do very poorly when given typical antipsychotics, so avoid them in these patients.
Patients with Lewy body dementia also frequently resemble patients with delirium. They can have a rapid decline, fluctuating course, and perceptual
 disturbances. Frontotemporal dementia often presents in patients less than  years old and is associated with disinhibition, apathy, language
 difficulties, and atrophy in the frontal and temporal lobes.
CLINICAL FEATURES
The main long­term pharmacologic therapy for patients with dementia is cholinesterase inhibitors such as donepezil. The side effects of these
 medications may prompt an ED visit and include GI upset, anorexia, urinary incontinence, bradycardia, dizziness, and abdominal cramps.
Behavioral disturbances are frequently encountered in patients with dementia and are common reasons for ED presentation, especially when caregivers are feeling overwhelmed. The first steps are to screen for delirium and to identify the presence of a comorbid medical disorder (see earlier discussion and Tables 288­1, 288­3, and 288­4, and Figure 288­1). Subsequent management strategies for agitation are listed in Figure 288­2. Mental Status Examination
Perform a mental status exam on all geriatric patients because patients with dementia can often appear intact if a formal evaluation is not performed.
In the ED, short screening tests such as the Mini­Cog, which takes  minutes to complete, can be used efficiently. The Mini­Cog (Figure 288­3)
 combines a three­word recall with a clock drawing test. Ask patients to remember three words (e.g., apple, table, penny). Then ask them to immediately repeat the words and remember them. Three minutes later, ask for the three words again. If patients can recall all three words, they do not need to complete the clock drawing test and do not have signs of cognitive impairment. If patients are not able to recall any of the words, they may have cognitive impairment, and the clock drawing test is not needed. If patients recall one or two words, they will need to perform the clock drawing test. Ask the patient to draw a specific time, indicating hour and minute. The test is graded as either normal (negative for cognitive impairment) or
 abnormal (positive for cognitive impairment). Alternatively, while waiting the  minutes to test the patient’s recall, ask the patient to draw the clock, as valuable information can be obtained from that exercise alone.
FIGURE 288­3
Mini­Cog Screening Test. Scoring is as follows:  point for each word recalled and clock drawing test is rated as either normal or abnormal. If the patient scores a  in word recall or can recall one or two words but has an abnormal clock drawing test, this is consistent with cognitive impairment.
Sequential steps are as follows:Step 1: Mini­CogStep  Ay: If recall all , person is not demented. Step  B: If recall  to , proceed to step 
B.Step  C: If recall is none, person is demented.Step  B: Check clock. If clock is normal, person is not demented. If clock is abnormal, person is demented.
MENTAL HEALTH DISORDERS
As the population of older adults continues to increase, so will the number of geriatric patients with mental health disorders. One estimate predicts
 that the number of geriatric patients with mental illness will increase by 275% from  million in 1970 to  million in 2030. The most common mental
 health disorders in older adults are major depression and alcohol use disorders. Significant research remains to be done in the field of geriatric psychiatry. The next sections will give a short overview of what is currently known regarding several mental health disorders found in older patients including depression, bipolar disorder, schizophrenia, and eating disorders.
DEPRESSION AND SUICIDE
Although the prevalence of major depressive disorder among community­dwelling older adults is low (1.4% to .4%), the proportion of patients with
,73,74 symptoms of depression below the threshold of major depressive disorder can be quite high, around 8% to 16%. Older patients with overt or
 subclinical depression can both benefit from treatment.
Depression in the geriatric population is associated with chronic medical illness, disability, increased use of health services, and poor health
,75,76 outcomes. Risk factors associated with development of depression in older adults include lack of social support, living alone, being unmarried,
,76 cognitive impairment, bereavement, and lower socioeconomic status.
Depression presents differently in older adults compared to younger age groups. Older adults with depression frequently report loss of appetite and
  sexual interest, rather than crying spells, sadness, or feelings of failure. They are more likely to be irritable and withdrawn than sad. Older patients
 may also present with somatic or cognitive complaints when they are actually suffering from depression, which can make the diagnosis difficult.

Caregivers and patients themselves may attribute depressive symptoms to normal aging, again making the diagnosis difficult. Comorbid anxiety is common with depression, and generalized anxiety disorder is frequently seen in the elderly population, with a reported lifetime prevalence of 15% in
 older adults.
There are several screening tests for depression currently available to practitioners. Many are lengthy and would be difficult to use in the ED setting.
The Patient Health Questionnaire­2 and Patient Health Questionnaire­9 are two­ and nine­item self­administered questionnaires that have been
 developed to screen for depression based on Diagnostic and Statistical Manual of Mental Disorders, fourth edition, criteria. The Patient Health
Questionnaire­9 assesses nine features of depression: anhedonia, depressed mood, trouble sleeping, feeling tired, change in appetite, guilt or worthlessness, trouble concentrating, feeling slowed down or restless, and suicidal thoughts. The Patient Health Questionnaire­2 has two questions
 addressing anhedonia and low mood, and has sensitivity and specificity of 83% and 90%, respectively. See Table 288­7 for the Patient Health

Questionnaire­2. Both questionnaires can easily be located and are comparable to longer scales used to screen for depression with more evidence
 supporting the use of the Patient Health Questionnaire­9. Several sources recommend starting with the Patient Health Questionnaire­2 and, if positive, then administering the Patient Health Questionnaire­9. TABLE 288­7
Patient Health Questionnaire­2
Scores range from  to . A score of  or greater indicates the need for further screening.
Over the past  weeks, how often have you been bothered by any of the following problems?
Feeling down, depressed, or hopeless?0 = Not at all1 = Several days2 = More than half the days3 = Nearly every day
Have you often been bothered by little interest or pleasure in doing things?0 = Not at all1 = Several days2 = More than half the days3 = Nearly every day

Treatment for depression combines both nonpharmacologic and pharmacologic interventions. It is unlikely that new medications will be started in the ED for depression in geriatric patients, but recognizing depressive symptoms and ensuring that the patient has appropriate follow­up are important. Review antidepressant doses, side effects, and drug interactions, as ED visits may be precipitated by symptoms from side effects or interactions. Selective serotonin reuptake inhibitors and selective norepinephrine reuptake inhibitors are some of the most frequently prescribed and
 effective antidepressants, but they can be associated with serotonin syndrome.

Screening for suicide is vital in the assessment of geriatric patients with depression. People over  years old have the highest rates of completed
 suicide of any age group.

Older adults may give fewer warning signs of suicidal intent, and they are more successful in attempting suicide. Depression is the largest risk factor for suicide. Other risk factors include perceived poor health status, poor sleep quality, alcohol abuse, absence of a
 confidant, physical illness, functional decline, and presence of a firearm.
SUBSTANCE ABUSE

Substance abuse is relatively common in the geriatric population and may increase with the aging baby­boomer cohort. The number of older adults
 who will need substance abuse treatment is expected to increase from .7 million in 2000–2001 to .4 million in 2020. Although the vast majority of substance abuse in the elderly is related to alcohol and prescription medications, there are reports of increased illicit drug use as well, highlighting the
 need to ask all patients about drug use.
Alcohol abuse in older adults is the most prevalent substance use problem. In a cross­sectional study of ,000 older adult primary care patients, 15%
 of patients were felt to be at risk for, or were affected by, high­risk drinking. Other community surveys estimate the prevalence of high­risk drinking
88–90  to be between 1% and 15%. Physiologic changes from advancing age decrease alcohol tolerance, increasing the risk of complications. Current
 guidelines consider high­risk drinking in older adults to be either more than one standard drink per day or more than three drinks on an occasion.

Alcohol­related problems, such as falls, confusion, and malnutrition, may be misattributed to normal aging, and thus alcohol misuse may be missed.
If you identify high­risk drinking, refer the patient to an inpatient or outpatient treatment facility. Also, if the plan is to admit a patient with known alcohol or substance abuse, notify the admitting physician so withdrawal symptoms can be monitored.
BIPOLAR DISORDER

Research regarding bipolar disorder in older adults is limited. The prevalence of bipolar disease in older adults is approximately .08% to .5%.
Older adults who present with new­onset mania therefore require a complete medical evaluation before a new diagnosis of bipolar disorder is made.
While the overall prevalence is very low, one study found that 17% of patients over  years old presenting to a psychiatric ED carried a diagnosis of
 bipolar disorder. There are some differences between younger and older patients with bipolar disorder. Older patients are more likely to be female.

Late­onset bipolar disorder (onset between age  and  years) is associated with fewer genetic associations and more neurologic illnesses. The
 frequency of psychotic features is essentially the same in young and old patients with bipolar disorder.
Patients may present to the ED both for symptoms of bipolar disorder and from adverse effects of the treatments. One of the most common
,96 medications used for bipolar disorder is the mood stabilizer lithium. Older patients can benefit from lithium even at lower serum levels than
 younger patients. The renal clearance of lithium decreases with age, increasing the elimination half­life and predisposing to lithium toxicity. Side
 effects of lithium include tremor, muscle twitches, GI symptoms, and CNS effects such as sedation. Many common medications interact with lithium, including thiazide diuretics, NSAIDs, and angiotensin­converting enzyme inhibitors, which can increase serum lithium concentrations and the risk of
  toxicity. Older adults taking lithium can display signs of toxicity even if the level is within the therapeutic window. See Chapter 181,
“Lithium,” for further details of toxicity and treatment. Three anticonvulsants have also been approved to treat bipolar disorder: valproate,
 carbamazepine, and lamotrigine. The literature regarding their use in older adults is sparse.
PSYCHOSIS AND SCHIZOPHRENIA
Several disorders, such as schizophrenia, psychosis associated with dementias, and more acute processes such as delirium, can present with symptoms of psychosis (hallucinations and delusions) in geriatric patients.
98–100
The prevalence of schizophrenia in older adults is around .1% to .5%. The majority of patients with schizophrenia develop the disease in the second or third decade of life (considered early­onset schizophrenia), meaning that most geriatric patients with schizophrenia have had the disorder
101 since they were much younger. There are two other groups of patients with schizophrenia: late­onset schizophrenia (over  years old) and very­
101 late­onset schizophrenia­like psychosis (over  years old). Individuals with late­onset schizophrenia have many of the same symptoms as patients
102 with early­onset schizophrenia, but late­onset patients have fewer problems with learning, abstraction, and flexibility. The diagnosis of very­late­
101 onset schizophrenia and primary psychotic disorders is rare. Very­late­onset patients tend to have fewer negative symptoms, greater risk of tardive
101 dyskinesia, and evidence of a neurodegenerative process rather than a neurodevelopmental process.
Schizophrenia in geriatric patients involves a complex interplay of the psychiatric, medical, and social factors. Nonadherence to medical therapy is
103 common. Mortality secondary to cardiovascular disease is more than twice as common compared with the general population, likely due to high rates of smoking, diabetes mellitus, hypertension, and obesity in schizophrenic patients. Older patients with schizophrenia often have a more
103 sedentary lifestyle and a worse diet. Atypical antipsychotics used for treatment increase the risk of metabolic syndrome and weight gain, which in
104 105 turn increase the risk of cardiovascular diseases. The use of typical antipsychotics is limited because of the higher risk of tardive dyskinesia. The cumulative annual incidence of tardive dyskinesia in patients over  years old treated with low­dose typical antipsychotics is about 26%, which is five
105 to six times greater than in younger patients. Antipsychotic medications should be carefully selected and doses titrated upward slowly with close monitoring for side effects. Older patients with schizophrenia can also benefit from adjunctive psychosocial interventions. For example, Functional
106–
Adaptation Skills Training, a group therapy targeting everyday life skills, improves the functional capabilities of older patients with schizophrenia.

EATING DISORDERS
There is little information regarding eating disorders such as anorexia nervosa and bulimia nervosa in older adults. A study of women over  years old found that about 13% reported some form of current eating disorder symptoms. Binge eating and purging in the absence of binge eating were the
109 109 most common symptoms. Approximately 71% of women in the study were trying to lose weight. Another review identified  cases of eating disorders in adults over  years old. In this article, 88% were female and 60% were over  years old. The most frequent diagnosis was anorexia
110 110 nervosa (81% of cases). Of the  cases, 79% had the onset of eating disorders later in life. Importantly, this study identified a strong connection between eating disorders and other psychiatric conditions (60% of cases), with major depression being the most important. Eating disorders were
110 often preceded by a stressful event such as widowhood, bereavement, or marriage difficulties. Of the  patients reviewed, 21% of the patients died
110 from complications of their eating disorder.
Diagnosis is difficult and is made by excluding any physical or medical cause of unexplained weight loss. Eating disorders in older patients are treated
110 similarly to those in any other age group, with a combination of cognitive­behavioral treatment and pharmacotherapy.
ACKNOWLEDGEMENTS
Special thanks to prior authors of this chapter, Dr. Kristen Barrio and Dr. Kevin Biese.


