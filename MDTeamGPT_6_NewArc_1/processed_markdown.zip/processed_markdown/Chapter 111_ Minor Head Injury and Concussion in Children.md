## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 111: Minor Head Injury and Concussion in Children
Paul M. A. Korn; Franz Babl
INTRODUCTION AND EPIDEMIOLOGY
Head trauma is an important cause of morbidity and mortality in children. Over 750,000 children and adolescents with head injuries present annually
 to EDs in the United States, double that of a decade ago. The highest incidence is in the 0­ to 4­year age group. Annual estimates of pediatric sports­
 related concussion in the United States range from .1 to .9 million. Although the majority of concussions are not seen in healthcare settings, an estimated 378,000 patients were seen as outpatient visits, 150,000 presented to the ED, and 5000 were admitted to hospitals annually in the United

States alone.
Concussion, minor head injury, and mild traumatic brain injury historically have had different definitions in medical literature. Typically, minor head injury is defined by Glasgow Coma Scale (GCS) score of  or  at the time of presentation to the ED. At a major conference of concussion specialists in

Berlin in 2016, a consensus definition of concussion was derived: traumatic brain injury induced by biomechanical forces.
Concussion may be caused by a direct blow to the head, face, neck, or elsewhere on the body, with an impulsive force transmitted to the head. It typically results in the rapid onset of short­lived impairment of neurologic function that resolves spontaneously. However, in some cases, signs and symptoms evolve over a number of minutes to hours.
PATHOPHYSIOLOGY
Concussion may result in neuropathologic changes, but the acute clinical signs and symptoms reflect a functional disturbance rather than gross structural injury, and as such, no abnormality is seen on standard structural neuroimaging studies.
Blunt head trauma in children often causes diffuse rather than focal injuries. A relatively larger calvarium and weaker cervical musculature in children impair protective mechanisms. The brain rotates around its center of gravity, resulting in diffuse axonal injury and possible subdural hemorrhage.

Acceleration and deceleration forces initiate a neurochemical cascade that results in neuronal membrane disruption and axonal stretching.
The acute phase of injury is characterized by an increase in cerebral cellular energy demand coupled with insufficient energy substrate delivery resulting in a metabolic crisis. This metabolic mismatch leads to alterations in neuronal depolarization, ion transport, glycolysis, mitochondrial function, and neurotransmitter release. Global and regional cerebral blood flow is reduced. Stretching of axons due to mechanical forces results in indiscriminate release of neurotransmitters and calcium influx and potassium efflux, resulting in widespread depolarization. Cells respond by activating ion pumps in an attempt to restore the normal membrane potential, which accelerates glycolysis and contributes to a state of hypermetabolism. Intracellular magnesium levels appear to diminish and may remain suppressed for several days. Magnesium is essential for generation of adenosine triphosphate, initiation of protein synthesis, and maintenance of cellular membrane potential. High intracellular calcium levels combined with stretch injury can cause destruction of microtubules within axons. The effect of this disruption leads to axonal swelling and detachment. Most cells, however, appear to recover normal cellular function, so the concussed brain undergoes dynamic restoration and brain function returns to the preconcussed state in the majority of children and youth. In some cases, however, brain structure and physiology may undergo
 reorganization and long­term pathologic changes.
CLINICAL FEATURES
The signs and symptoms of concussion are numerous and highly variable and can develop over seconds to several days following an injury. Children and adolescents may not be fully aware of their symptoms and may not be able to articulate or describe the effects clearly. In infants and very young cDhoilwdnrelona, dsyemd p2t0o2m5­s7 o­f1 n 6e:u5r Pol o Ygoicu irn IjPur yis m 1a3y6 .b1e4 s2u.1b5tl9e..1 L2e7thargy, irritability, poor muscle tone, breathing abnormalities, and poor feeding should raise
Chapter 111: Minor Head Injury and 4Concussion in Children, Paul M. A. Korn; Franz Babl concerns of a significant head injury.
. Terms of Use * Privacy Policy * Notice * Accessibility
The GCS is often used as an initial reliable tool for determining severity of brain injury (Table 111­1). Children presenting with a GCS of ≤14 are at
 increased risk for intracranial injuries.
TABLE 111­1
Modified Glasgow Coma Scale for Infants and Children
Component Infant Child/Adult Score
Eye opening Spontaneous Spontaneous 
To speech To speech 
To pain only To pain only 
No response No response 
Best verbal response Coos and babbles Oriented, appropriate 
Irritable cries Confused 
Cries to pain Inappropriate words 
Moans to pain Incomprehensible sounds 
No response No response 
Best motor response Moves spontaneously/purposefully Obeys commands 
Withdraws to touch Localizes painful stimulus 
Withdraws to pain Withdraws to pain 
Abnormal flexion posture to pain Abnormal flexion posture to pain 
Abnormal extension posture to pain Abnormal extension posture to pain 
No response No response 
Red flags for serious injury include neck pain or tenderness, double vision, weakness or tingling in the arms or legs, severe or increasing headache, seizure, loss of consciousness, deteriorating mental status, persistent vomiting, and increasing restlessness. A history of a coagulopathy, previous
 neurosurgery (e.g., shunt), dangerous mechanism of injury (see Table 111­3), and multiple injuries deserve special consideration.
HISTORY
Obtain a comprehensive history including mechanism and severity of injury and eyewitness accounts. Concussions should be considered in the presence of one or more physical, cognitive, emotional, or sleep changes (Table 111­2).
TABLE 111­2
Symptoms of Concussion
Domain Symptoms
Physical Headache, nausea, vomiting, confusion, dizziness, balance problems, visual changes, fatigue, photophobia, phonophobia
Cognitive Fogginess of thought, difficulty with concentration, difficulty with memory, forgetfulness, repeating questions, answering questions slowly
Emotional Irritability, sadness, anxiety, emotional lability
Sleep Drowsiness, sleeping more than usual, sleeping less than usual, trouble falling asleep, trouble staying asleep
Inquire about loss of consciousness, disorientation, confusion, blank stare, poor balance, gait instability, and posttraumatic seizure. Determine if there has been improvement or deterioration since the time of injury, particularly relating to level of consciousness, headache, and vomiting. Gather information relating to previous concussions, preexisting neurologic disorders including migraine, emotional dysregulation, learning difficulties, attention­deficit/hyperactivity disorder, behavioral disorders, and coagulation disorders. Inquire about antegrade and retrograde amnesia, shortterm memory loss, and ability to concentrate. If patients present to the ED beyond the acute stage, determine when the injury occurred; if there has been repeat head trauma, change in mood, change in sleep pattern, or symptom triggers; and if school or physical activity has worsened symptoms.
Symptoms of concussion are often nonspecific and may mimic other conditions such as anxiety and depression. Moreover, some individuals may overreport symptoms (reporting resolved symptoms as unresolved, exaggerating the extent and severity of symptoms, fabricating symptoms), whereas others may underreport symptoms. Everyday somatic complaints, such as headache, fatigue, and sleep difficulties, may be misattributed to a
 head injury.
PHYSICAL EXAMINATION
Obtain vital signs and perform a general examination to determine extent of all injuries. Look for external signs of trauma including facial and scalp bruising, boggy scalp hematoma, evidence of an open or depressed skull fracture, hemotympanum, “racoon eyes,” “battle sign,” otorrhea, and rhinorrhea of cerebrospinal fluid. Scalp hematomas that are large and nonfrontal in location have a higher association with skull fracture in infants <3 months of age, although they are rarely associated with clinically important intracranial injury in otherwise asymptomatic infants and older
,10 children. Specific bruising and injury patterns in infants and young children raise concern for abusive trauma (see Chapter 150, “Child Abuse and
,12
Neglect”).
Determine the GCS (Table 111­1). Assess orientation and memory for events directly preceding the head injury. Test immediate memory, delayed memory, and concentration. Perform a detailed neck exam, assessing for central spine tenderness, painful or reduced cervical spine range of motion, and focal neurologic deficits. If concerned, the cervical spine should be immobilized until the extent of injury is determined (see Chapter 112, “Cervical
Spine Injury in Infants and Children”).
Perform a focused neurologic exam including cranial nerve, cerebellar, motor, sensory, balance, and gait assessment. Assess vestibular­ocular reflexes for gaze stabilization, gaze shifting, and vergence. Damage to any of these systems can lead to complex symptoms that exacerbate and complicate recovery, including balance disturbance, eye tracking difficulties, nausea, dizziness, headache, difficulty reading, and difficulty walking. Test visual acuity, extraocular motility, pupillary response to light, and fundoscopy.
IMAGING
After initial assessment and stabilization, the most immediate question in children presenting with head injuries to the ED is whether they require neuroimaging. Currently, there are no recommendations for electroencephalogram, advanced neuroimaging, genetic testing, and serum biomarkers in the ED setting.
Noncontrast head CT identifies and excludes critical intracranial injuries that require immediate or urgent intervention, can be conducted within
,14 seconds, and usually does not require sedation. Although the need for sedation is increased in agitated or combative children or those <2 years old, the majority can be imaged without sedation by using parental presence. The primary drawback of CT, however, is radiation exposure, which may
15­17 increase the lifetime risk of brain and other cancers, particularly in young children. Although MRI is a radiation­free alternative, it is impractical at this time in the ED due to the time required for imaging.
It is generally agreed that children with GCS score of <13 should undergo neuroimaging based on the increased risk of significant intracranial injury. For milder head injuries (GCS score of  to 15), multiple clinical decision rules have been developed to assist clinicians in identifying children at increased risk of intracranial injury, help balance the risk of missing a significant injury, and minimize the risk of radiationinduced cancer. Decision rules for head injuries use elements of injury mechanism, patient history, and physical examination to risk­stratify patients.
Although many rules appear superficially similar, they differ in details, inclusion and exclusion criteria (e.g., age limits, injury severity), predictor
18­21 variables, and the outcomes used (Table 111­3). The highest­quality, prospectively derived, and externally validated decision rules are (1) the prediction rule for the identification of children at very low risk of clinically important traumatic brain injury developed by the Pediatric Emergency

Care Applied Research Network (PECARN, United States), (2) the Canadian Assessment of Tomography for Childhood Head Injury (CATCH, Canada)
  rule, (3) the Children’s Head Injury Algorithm for the Prediction of Important Clinical Events (CHALICE, United Kingdom), and (4) the National
,26
Emergency X­Radiography Utilization Study II (NEXUS II, United States). These rules were derived based on large numbers of patients in different countries and were based on different baseline imaging rates, ranging from 3% (CHALICE) to 53% (CATCH) for the population under investigation.
Whereas PECARN, CATCH, and CHALICE were specifically designed for pediatric head injuries, the premise of NEXUS II was to create a risk decision instrument for head­injured patients of all ages, because the majority of children are seen in mixed EDs that care for both adult and pediatric patients.
TABLE 111­3
Predictor Variables and Outcome Measures of PECARN, CATCH, CHALICE, and NEXUS II Clinical Decision Rules22­25
PECARN <2 y PECARN ≥2 y CATCH CHALICE NEXUS II
Primary Clinically important traumatic brain injury; Need for neurologic Clinically significant Clinically important intracranial outcome defined as death from traumatic brain intervention; intracranial injury; defined injuries; defined as substantial injury, neurosurgical intervention for defined as either as death as a result of epidural or subdural hematoma (>1.0 traumatic brain injury (intracranial death within  d head injury, requirement cm in width or causing mass effect); pressure monitoring, elevation of secondary to the for neurosurgical substantial cerebral contusion (>1.0 depressed skull fracture, ventriculostomy, head injury or need intervention, or marked cm in diameter or >1 site); extensive hematoma evacuation, lobectomy, tissue for any of the abnormality on CT subarachnoid hemorrhage; mass effect debridement, dura repair, other), following (defined as any new, or sulcal effacement; signs of intubation of >24 h for traumatic brain procedures within  acute, traumatic herniation; basal cistern compression injury or hospital admission of  nights or days: craniotomy, intracranial pathology as or midline shift; hemorrhage in the more for traumatic brain injury* in elevation of skull reported by consultant posterior fossa; intraventricular association with traumatic brain injury on fracture, monitoring radiologist, including hemorrhage; bilateral hemorrhage of
CT† of intracranial intracranial hematomas any type; depressed or diastatic skull pressure, insertion of any size, cerebral fracture; pneumocephalus; diffuse of endotracheal contusion, diffuse cerebral edema; diffuse axonal injury tube for the cerebral edema, and management of depressed skull fractures) head injury
Predictor variable‡§
Mechanism Severe mechanism Severe mechanism Dangerous High­speed RTA as Persistent vomiting of injury (MVC with of injury (MVC with mechanism of pedestrian, cyclist, Altered level of alertness, abnormal patient ejection, patient ejection, injury (e.g., MVC; fall occupant (defined as behavior death of another death of another from elevation ≥3 ft accident with speed >40 Coagulopathy passenger, or passenger, or (≥91 cm) or  stairs; mph or  km/h) rollover; rollover; fall from bicycle Fall >3 m in height pedestrian/bicyclist pedestrian/bicyclist with no helmet) High­speed injury from without helmet without helmet projectile or object struck by struck by motorized vehicle; motorized vehicle; falls >0.9 m; head falls >1.5 m; head struck by high­ struck by highimpact object) impact object)
History LOC ≥5 s Any or suspected History of Witnessed LOC >5 min
Not acting LOC worsening ≥3 vomits after head normally per History of vomiting headache¶ injury (discrete episodes) parent Severe headache Amnesia
(antegrade/retrograde >5 min)
Suspicion of NAI (NAI defined as any suspicion of NAI by the examining doctor)
Seizure in patient with no history of epilepsy
Examination GCS <15 GCS <15 GCS <15 at  h after GCS <14, or <15 if <1 y old Neurologic deficit
Other signs of Other signs of injury¶ Abnormal drowsiness (in Abnormal behavior altered mental altered mental excess of that expected by Evidence of significant skull fracture
Irritability on status (agitation, status (agitation, examining doctor) Presence of scalp hematoma examination¶ somnolence, somnolence, Focal neurologic deficit
Any sign of basal repetitive repetitive Signs of basal skull skull fracture (e.g., questioning, slow questioning, slow fracture hemotympanum, response to verbal response to verbal (hemotympanum, racoon
“racoon” eyes, communication) communication) eyes, otorrhea or otorrhea or
Palpable or unclear Clinical signs of rhinorrhea of rhinorrhea of the skull fracture basilar skull cerebrospinal fluid, cerebrospinal fluid,
Occipital, parietal, fracture Battle’s sign)
Battle’s sign) or temporal scalp Suspicion of penetrating
Large, boggy scalp hematoma or depressed skull injury, hematoma or tense fontanelle
Note: Although the predictor variables are reproduced verbatim, the order in which the variables from each clinical decision rule are presented has been altered to facilitate comparison.
Abbreviations: CATCH = Canadian Assessment of Tomography for Childhood Head Injury; CHALICE = Children’s Head Injury Algorithm for the Prediction of
Important Clinical Events; GCS = Glasgow Coma Scale; LOC = loss of consciousness; MVC = motor vehicle crash; NAI = nonaccidental injury; NEXUS II = National
Emergency X­Radiography Utilization Study II; PECARN = Pediatric Emergency Care Applied Research Network; RTA = road traffic accident.
*Hospital admission for traumatic brain injury defined by admission for persistent neurologic symptoms or signs such as persistent alteration in mental status, recurrent emesis due to head injury, persistent severe headache, or ongoing seizure management.
†Traumatic brain injury on CT is defined by any of the following descriptions: intracranial hemorrhage or contusion, cerebral edema, traumatic infarction, diffuse axonal injury, shearing injury, sigmoid sinus thrombosis, midline shift of intracranial contents or signs of brain herniation, diastasis of the skull, pneumocephalus, or skull fracture depressed by at least the width of the table of the skull.
‡
In each of the four clinical decision rules, the absence of all of the above predictor variables indicates that cranial CT scan is unnecessary.
§NEXUS II predictor variable includes the criterion age >65 years (which is not relevant in pediatric patients).
¶High­risk predictors for CATCH (need for neurologic intervention).
The main difference between PECARN and the other three rules is that its goal is to identify patients at very low risk of intracranial injury who do not need a CT scan (all predictor variables negative, no CT required), with separate rules for children <2 years and ≥2 years old, whereas the other rules seek to identify the patients who do require a CT scan (any predictor variables positive, CT required). The rules were also designed for patients of different injury severity, with CHALICE designed for all severities (GCS  to 15), PECARN for patients with GCS of  and , and CATCH for patients with GCS of  to  and with symptoms of mild head injury (blunt trauma to the head resulting in witnessed loss of consciousness, definite amnesia, witnessed disorientation, persistent vomiting, and persistent irritability in the ED [in children <2 years old]). NEXUS II
25­27 was designed for patients of all severities who had already been selected for CT scans.
Although all four rules had very high sensitivities when using the rule­specific design and outcomes (PECARN <2 years, .6%; PECARN ≥2 years, .7%;
CHALICE, .6%; CATCH, 100%; NEXUS II in children <18 years old, .6%; with specificities of .7%, .5%, .9%, .2%, and .1%, respectively), the accuracy of the rules is difficult to compare due to the many differences in their design. Recently a large external cohort of ,137 head­injured children was used to compare the pediatric­specific rules using a common outcome (clinically important traumatic brain injuries, which are defined as death from traumatic brain injury, neurosurgical intervention for traumatic brain injury, intubation of >24 hours for traumatic brain injury, or hospital admission of ≥2 nights for traumatic brain injury in association with traumatic brain injury on CT) in patients with GCS of  to .  All three pediatric rules had high sensitivities (PECARN, 100% [<2 years] and .2% [≥2 years]; CHALICE, .5%; CATCH, .9%) and overlapping confidence intervals, with
PECARN <2 years and ≥2 years missing  and  injured patient, respectively; CHALICE missing  patients; and CATCH missing  patients. Sensitivities in detecting traumatic brain injury on CT and identifying patients requiring neurosurgery were similar to the detection of clinically important traumatic brain injuries.
As a widely used and highly accurate decision rule, PECARN is presented in more detail. The PECARN rule provides guidance for children <2 years and
≥2 years of age (Figure 111­1).  The main difference between older and younger rule is the inclusion of vomiting and severe headache as a predictor variable in children ≥2 years and the inclusion of occipital, parietal, or temporal scalp hematomas or palpable skull fractures and the exclusion of vomiting as predictor variables in children <2 years. If all six predictor variables are negative, the risk of a clinically important traumatic brain injury is so low that a CT scan is not necessary. The PECARN group also provides guidance for patients with one or more positive predictor variables (Figure
111­1). Children with higher risk predictor variables—GCS of  or other signs of altered mental status, palpable skull fracture (<2 years), or signs of basilar skull fracture (≥2 years)—are at increased risk of clinically important traumatic brain injury and should undergo a CT scan. Children with any of the other four predictor variables are at intermediate risk of intracranial injury, and other factors should be used, such as multiple findings, worsening symptoms, and clinician and parental preferences.
FIGURE 111­1. Suggested CT algorithm for children <2 years old (A) and ≥2 years old (B) with Glasgow Coma Scale (GCS) scores of  and  after head trauma. ciTBI =
† clinically important traumatic brain injury; LOC = loss of consciousness. Other signs of altered mental status include agitation, somnolence, repetitive
‡ questioning, or slow response to verbal communication. Severe mechanism of injury includes motor vehicle crash with patient ejection, death of another passenger, or rollover; pedestrian or bicyclist without a helmet struck by a motorized vehicle; falls of >0.9 m (3 ft) or >1.5 m (5 ft) for panel B; or
∫ head struck by a high impact object. Patient with certain isolated findings (i.e., with no other findings suggestive of traumatic brain injury) such as isolated LOC, isolated headache, isolated vomiting, and certain types of isolated scalp hematoma in infants >3 months old have a risk of ciTBI
¶ substantially lower than 1%. Risk of ciTBI exceedingly low, generally lower than risk of CT­induced malignancies. Therefore, CT scans are not indicated for most patients in this group. [Reproduced with permission from Kuppermann N, Holmes JF, Dayan PS, et al: Identification of children at very low risk of clinically­important brain injuries after head trauma: a prospective cohort study. Lancet 2009 Oct ;374(9696):1160­1170. Copyright
Elsevier.]
TREATMENT
The ED management of serious brain injuries is covered in Chapters 110, “Pediatric Trauma” and 250, “Skin Disorders: Face and Scalp”, whereas associated cervical spine injury management is discussed in Chapter 112 and abusive head injuries are discussed in Chapter 150. Once these major injuries have been ruled out, the ED management of concussion focuses on relief of acute or persistent symptoms, patient and family education, and appropriate outpatient follow­up. Strategies for the ED management of specific symptoms related to mild traumatic brain injury and education of patients regarding postdischarge care are discussed below.
HEADACHE
Headache is the most common complaint following mild traumatic brain injury, with an onset within  days of the initial injury, and can be acute or persistent in nature. Although classified as a secondary headache (see Chapter 139, “Headache in Children”), posttraumatic headaches often have characteristics of one of the primary headache disorders (Table 111­4), and a history of primary headache disorder may predispose to persistent
 symptoms after injury. Treat posttraumatic headaches based on the primary headache disorder they most resemble.
TABLE 111­4
Posttraumatic Headache Symptoms Resembling Primary Headache Disorders
Corresponding Primary
Symptoms
Headache Disorder
Bilateral, moderate severity, dull pressure/squeezing sensation. Location is variable. Triggers are stress, reading, Tension type sustained poor posture.
Unilateral, severe, pulsating, associated nausea, vomiting, photophobia, sensory and visual changes. Location may Migraine vary. Triggers can be exercise, lights, and sounds.
Unilateral, severe, throbbing, autonomic activation, lacrimation, and rhinorrhea. Pain is often described as retro­ Cluster orbital or periorbital.
Unilateral, mild to severe in quality, often described as aching. Location is focal, involving the neck. Triggers are neck Cervicogenic movement. There is often a history of whiplash.
Determining appropriate pharmacotherapy in the ED is challenging because there is limited evidence for effective treatment strategies.
Acetaminophen and NSAIDs (ibuprofen and naproxen) may provide acute relief. Do not provide NSAIDs until intracranial hemorrhage is excluded.
After the first few days, NSAIDS may lose their effectiveness. The frequent and prolonged use of over­the­counter analgesics may result in worsening
 and rebound headaches.

Although one previous study suggested hypertonic saline for symptomatic treatment of acute concussive symptoms, the 2018 Centers for Disease
Control and Prevention guideline on the diagnosis and management of mild traumatic brain injury among children does not recommend hypertonic
 saline outside of the research setting at this time.
For headaches with a migraine component, the use of IV dopamine antagonists (metoclopramide, prochlorperazine, chlorpromazine) and ketorolac
  may provide temporary relief of symptoms, but does not appear to alter recurrence or persistence. Potential adverse effects of dopamine antagonists include drowsiness, hypotension, and acute dystonic reactions, particularly in adolescents (Chapter 139, “Headache in Children”) . The use of migraine­specific abortive triptan medications may be effective, but should be limited to less than  times per month. Do not provide opioids for persistent headaches.
Identify headache triggers and relievers if possible. Management strategies should focus on education and expected clinical course. Physical and cognitive overexertion are key factors for worsening headache.
Patients with prolonged and debilitating postconcussive headaches should be referred to a neurologist. Preventive medications including gabapentin, valproic acid, topiramate, amitriptyline, carbamazepine, and cyproheptadine may provide symptomatic relief, but require dosage titration and careful monitoring.
NAUSEA
Consider ondansetron for significant nausea or difficulty tolerating liquids. One study suggested that children treated with ondansetron after head
 injury had lower rates of ED return visits, and ondansetron did not mask serious underlying conditions in those who did not have imaging. Physical and cognitive rest often results in resolution of nausea. Keep the child well hydrated, as dehydration can worsen nausea.
DIZZINESS
Concussion­associated dizziness tends to resolve quickly with rest. Dizziness may result from an injury to the vestibular system, the effects of visual disturbances (decreased convergence, accommodation, smooth visual pursuits, eye saccades), decreased exercise tolerance, or cervicogenic injury.
For prolonged symptoms, refer to a physiotherapist or concussion clinic for targeted exercises including vestibular rehabilitation. A concussion vision specialist may assist in neuro­optometric vision rehabilitation with the goal of improving central­peripheral vision, visual­vestibular and accommodation­vergence integration, pursuit and saccadic eye movement, and convergence ability. Therapy involves strengthening binocularity, reducing visual motion hypersensitivity, and reducing disequilibria.
DISPOSITION AND FOLLOW­UP
ED DISPOSITION
At this time, there is clinical variation and no gold standard regarding the need for, and length of, ED observation. However, we do know the following:
. Patients who have been imaged and in whom the CT is negative are at extremely low risk for subsequent deterioration from a bleed.
. Children who meet PECARN low­risk criteria (Table 111­3) are at very low risk for clinically important traumatic brain injury requiring intervention.
. For children who are symptomatic and not low risk, the PECARN rule recommends observation or CT, but does not specify the duration of observation. This author uses around  hours of ED observation, with CT scan if patient is getting worse and discharge if getting better. Provide discharge instructions regarding signs and symptoms for which to seek immediate medical care. This includes lethargy, irritability, focal deficits, seizures, intractable vomiting, slurred speech, paresthesia, and worsening headache.
Caregivers of infants in the first year of life should be warned about the risk of “growing fractures” over the weeks to months following a skull fracture and instructed to see their primary care physician if there is a persistent or worsening palpable defect in the skull >2 weeks after the injury.
Patients with intracranial injury and those thought to be at risk for abusive head trauma should be admitted into hospital with appropriate pediatric subspecialty medical, neurosurgical, and nursing resources.
Children and adolescents with complex, depressed, or basilar skull fractures should be managed in conjunction with neurosurgery and typically require admission. Stable asymptomatic infants and children with linear, nondisplaced skull fractures with no evidence of intracranial injury are safe for discharge with primary care follow­up.
FOLLOW­UP CONSIDERATIONS
The majority of children and adolescents who sustain a concussion will recover within  to  weeks. The strongest and most consistent predictor of slower recovery is the severity of symptoms during the first few days following injury. A low level of symptoms in the first day following an injury is a favorable prognostic indicator. Approximately one third of concussed children and adolescents, however, will go on to experience ongoing somatic, cognitive, psychological, or behavioral symptoms, commonly referred to as persistent postconcussion symptoms. These symptoms do not reflect a single pathophysiologic entity, but describe a constellation of nonspecific posttraumatic symptoms that may be linked to coexisting or confounding factors (e.g., previous concussions, mental health problems, migraine history, previous neurologic disorders, lack of social supports, female gender, higher level of symptoms, presence of life stressors, substance abuse). They do not necessarily reflect ongoing physiologic injury to the brain. Children and youth who have been diagnosed with attention­deficit/hyperactivity disorder or learning disabilities may require more assistance in returning to
,35 school, but are not at increased risk for persistent symptoms.
Risk factors for poor prognosis include previous concussion history, persistent posttraumatic headache, depression, anxiety, persisting vestibularocular abnormalities, ongoing cognitive difficulties, preinjury sleep disturbances, increased symptoms with return to school and exercise, and return
 to high­risk contact sports prior to full recovery.
Those who have persistent symptoms should be referred to a concussion specialty clinic. The team should encompass expertise by a pediatrician, sports medicine specialist neurologists, or neurosurgeon, with allied professional specialties including physiotherapy, clinical psychological, neuropsychology, physiatry, kinesiology, and neuro­ophthalmology. Delay in seeking a multimodal assessment and treatment may lead to prolonged
 functional disabilities.
POSTDISCHARGE COUNSELING
REST AND INITIATING PHYSICAL ACTIVITIES
Following a concussion, there should be a period of physical rest for  to  hours. Returning to physical activity can be guided by the four P’s:
 prioritize activities, plan in advance, pace appropriately, and position in a calm environment. Gradually introduce noncontact and low­risk activities.
Avoid activities that exacerbate symptoms. Early return to graduated physical activities results in lower rates of prolonged concussion symptoms at 
 month compared to children and adolescents who adhere to strict rest guidelines until symptom free. The proposed mechanism by which exercise may improve recovery is through the promotion of neuroplasticity mechanisms. Controlled aerobic exercise may improve recovery by restoring normal cerebral blood flow regulation.
RETURN TO LEARN
Cognitive rest prevents overtaxing of a functionally injured brain and prevents metabolic overload. The degree and duration of cognitive rest vary from person to person. Mental activity should be resumed gradually, even if the person has not returned to baseline. Activities that worsen symptoms should be avoided. Graded return to learn requires accommodation by schools. Providing teachers with specific symptom­based guidelines for successful reintegration is helpful (Figure 111­2). Returning to school, even with restrictions, may have significant psychosocial benefits.
FIGURE 111­2. Return to school staged approach.
RETURN TO SPORTS
A graduated return to sports protocol should be followed. Children and adolescents must be symptom free, off all medications, have a normal neurologic examination, and have successfully returned to learn before returning to competitive sports. The graded return to sport protocol (Figure
111­3) advances through the following rehabilitation stages: light aerobic activity, more intensive training, sports­specific exercises, noncontact participation, full practice, and finally game play. The athlete must be symptom free during and after exertion before advancing to the next stage, and there should be at least  hours between the stages. If symptoms return at any level, the athlete must rest until the symptoms resolve and then begin the protocol level again, at the previous level of symptom­free exertion. The return to play guideline must be individualized and progressive.
FIGURE 111­3. Return to sport staged approach.
GENERAL LIFESTYLE MEASURES
Encouraging healthy lifestyle choices is an important aspect of initial care. Physical and cognitive rest assists recovery from concussion through conservation of limited adenosine triphosphate supply. Discuss nutrition (three meals, including protein, and two snacks per day), optimal hydration, and the importance of restorative sleep. Limit screen and device time, and gradually resume normal social activities.
Preventing further injury during the time of recovery is essential. Patients should avoid higher­risk recreational activities (cycling, skating, skateboarding) that may result in a second head injury. During recovery, the brain is particularly vulnerable to worsening symptoms, additional concussions, and rarely, second impact syndrome, which results from subsequent low­energy collisions. The injured brain may lose its ability to
 autoregulate cerebral perfusion, leading to cerebral edema, herniation, and potential death.
SLEEP
Fatigue and sleep disruption are common following head injury. Daytime drowsiness, difficulty falling asleep, and difficulty staying asleep are often experienced. Normalizing sleep patterns hastens recovery.
The American Academy of Sleep Medicine recommends that children  to  years of age sleep  to  hours per day and adolescents  to  years of
 age sleep  to  hours per day on a regular basis to promote optimal health. This should be appropriately timed and uninterrupted. Sleeping less is associated with attention, behavior, and learning problems and an increased risk for accidents, injuries, hypertension, obesity, diabetes, and
 depression. Excessive sleep is linked to obesity and mental health concerns. Sleep difficulties after head injury may be caused by headache, dizziness, and nausea, but are likely to improve when they are effectively controlled.
Provide sleep hygiene strategies. Discuss healthy sleep habits emphasizing the same bedtime and wake time. In the first few hours and days following concussion, daytime naps do not need to be limited. After the initial stages of recovery, lengthy naps should be avoided so as not to interfere with nighttime sleep. If patients have ongoing fatigue, recommend naps <30 minutes long and before 3:00 p.m. Electronic devices should be turned off during the evening. The sleeping environment should be dark, cool, tidy, and comfortable. The bedroom should be designated exclusively for sleep and should not have any electronic devices. Heavy meals, caffeinated beverages, and excessive sugar should be avoided. A healthy diet with optimal vitamins, minerals, and iron may facilitate endogenous melatonin production. Regular exercise when tolerated should be encouraged earlier in the day, but should be avoided within  hours of bedtime. Patients should be exposed to natural light during the day. If sleep strategies are not effective, a trial of melatonin may be indicated; however, its efficacy for concussion has not been studied. As melatonin is not subject to U.S. Food and Drug
Administration controls, different preparations may produce variable results. Side effects including daytime drowsiness, headache, dizziness, nausea, depression, and anxiety are uncommon. If melatonin is tried, children should be started at  milligrams and adolescents at  milligrams approximately
 minutes before bedtime. Long­acting melatonin should be given if children and adolescents have trouble both falling asleep and staying asleep.
Pharmaceuticals including trazadone, mirtazapine, amitriptyline, and quetiapine might be considered but should be prescribed by a concussion specialist, neurologist, or pediatrician. Benzodiazepines should be avoided as they cause daytime drowsiness and may interfere with cognition and memory.
FATIGUE
Fatigue is often disabling and can be managed by optimizing the home and school environment, including ergonomic furnishings and adjusting lighting. Determine optimal hours for learning and physical activities. Schedule regular periods of rest, break down activities into smaller tasks, and set priorities.
MOOD
Mood changes following concussion are often multifactorial and can be transient, persistent, or relapsing. Variables include medical comorbidities, medications, family history of psychiatric disorders, past history of psychiatric disorders, substance abuse, social relationships with family and friends, and cultural factors.
Management is multipronged and a referral to a rehabilitation team including mental health specialists and occupational and physical therapists is advised. Psychotherapy focuses on supportive care (providing hope, minimizing misattributions) and behavioral therapy (daily structure, sleep hygiene, exercise–relaxation balance, impulse control, anger management). Cognitive therapy and mindfulness are important components of care.
There are no U.S. Food and Drug Administration–approved medications for the treatment of neuropsychiatric symptoms associated with concussion, although psychotropic medications have been used “off label” with some success (antidepressants, mood stabilizers, antipsychotics, dopamine agonists, β­blockers).


