## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 201: Pesticides
Shaun Greene
INTRODUCTION

Pesticides include insecticides, herbicides, and rodenticides. Pesticide toxicity results from intentional, accidental, and occupational exposures. More
 than 150,000 pesticide poisoning deaths occur each year worldwide, with insecticides accounting for the majority of the mortality. Pesticides are marketed as multiple formulations, often under shared brand names. Therefore, complex clinical syndromes can result from exposure to both active and other ingredients. Human toxicity can occur from many ingredients in formulations, including solvents and surfactants. Pesticides have class­specific toxicities, with many having both local and systemic effects. Management often includes consultation with a hazardous materials and toxins database or with a poison control center. Cornerstones of management are meticulous supportive care and early identification of exposures that may benefit from administration of an antidote.
The World Health Organization classifies pesticides according to toxicity based on rodent median lethal oral and dermal exposures. However, human
 case­fatality rates display large variation for compounds within the same chemical and/or World Health Organization toxicity classification. Toxicity classification should not be used to predict severity after human exposure.
INSECTICIDES
Chemical insecticides are toxic to the human nervous system, producing acute and chronic manifestations, as well as delayed sequelae after acute exposure. Six major classes of insecticides are in common use (Table 201­1). Other compounds used to control insects include repellents.
TABLE 201­1
Insecticides and Repellents
Insecticides Repellents
Organophosphates Amitraz
Carbamates N,N­diethyl­3­methylbenzamide (DEET)
Organochlorines
Pyrethrins/pyrethroids
Neonicotinoids
Nereistoxin analogs
ORGANOPHOSPHATES
Commonly used organophosphates include diazinon, acephate, malathion, parathion, and chlorpyrifos. Organophosphate and carbamate
 compounds are the insecticide exposures most commonly resulting in healthcare facility attendance in the United States. Potency among
 organophosphates varies; highly potent compounds, such as parathion, are used primarily in agriculture, whereas those of intermediate potency,
Chapter 201: Pesticides, Shaun Greene i©n2cl0u2d5in Mg ccGouramwa pHhilol. sA alln Rdi gtrhictsh lRorefsoenr,v aerde. u sTeedr mins a onfi mUasle c * a rPer.i vDaiaczyi nPoonli cayn d * Ncholtoicrpe y * r iAfocsc wesesreib pilihtyased out from household use in the United States in

2000 due to neurotoxicity, particularly on the developing brains of children, but they continue to be used in many other parts of the world. The organophosphate structure can be modified into chemical agents of mass destruction (see Chapter , “Chemical Disasters”).
,5
Globally, organophosphate poisoning results most commonly from deliberate self­poisoning. Accidental exposures occur in agricultural and
 industrial settings through use of pesticide spray applicators or spills during transport. Inadvertent exposure can occur from flea­dip products in pet groomers and children and from contaminated food. Systemic absorption of organophosphates occurs by inhalation and after mucous membrane, transdermal, transconjunctival, or GI exposure.
Consultation with a poison control center or medical toxicologist can be useful to assist in patient management and to collect data for surveillance reports. When consulting, precise communication of the specific product name from the container label is essential to identify both active and inert ingredients. As noted, confusion can arise because similar brand names are used for more than one agent.
Pathophysiology

Organophosphate and carbamate compounds inhibit the enzyme cholinesterase. Acetylcholinesterase (true or red blood cell acetylcholinesterase) is found primarily in erythrocyte membranes, nervous tissue, and skeletal muscle. Plasma cholinesterase (pseudocholinesterase or butyrylcholinesterase) is found in the serum, liver, pancreas, heart, and brain. Inhibition of cholinesterase leads to acetylcholine accumulation at nerve synapses and neuromuscular junctions, resulting in overstimulation of acetylcholine receptors. This initial overstimulation is followed by paralysis of cholinergic synaptic transmission in the CNS, in autonomic ganglia, at parasympathetic and some sympathetic nerve endings (e.g., sweat glands), and in somatic nerves. Excess acetylcholine results in a cholinergic crisis that manifests as a central and peripheral clinical toxidrome.
Organophosphate compounds bind irreversibly to acetylcholinesterase, thus inactivating the enzyme through the process of phosphorylation. The term aging describes the permanent, irreversible binding of the organophosphorus compound to the cholinesterase. The time to aging is highly variable among different agents and can range from minutes to a day or more. Once aging occurs, the enzymatic activity of cholinesterase is permanently destroyed, and new enzyme must be resynthesized over a period of weeks before clinical symptoms resolve and normal enzymatic function returns. Antidotes are more effective if given before aging occurs.
Clinical Features
Clinical presentations depend on the specific agent involved, the quantity absorbed, route of exposure, and the amount and character of additives
,8
(including solvents) in any preparation. Organophosphate insecticide poisoning can have substantial variability in clinical course, response to
,9 treatment, and outcome. Four clinical syndromes are described following organophosphate exposure: acute poisoning, intermediate
 syndrome, chronic toxicity, and organophosphate­induced delayed neuropathy.
In acute organophosphate poisoning, most poisoned patients are symptomatic within the first  hours and nearly all within the first  hours.
Organophosphate agents such as malathion are associated with local irritation of the skin (dermatitis) and respiratory tract (wheezing) without evidence of systemic absorption.
Acute organophosphate poisoning results in CNS, muscarinic, ​nicotinic, and somatic motor manifestations (Table 201­2). In mild to moderate poisoning, symptoms occur in various combinations. In severe exposures, nicotinic features may be observed first. Time to symptom onset varies according to exposure route, occurring within minutes of massive ingestion. Symptom onset is most rapid with inhalation and least rapid with transdermal absorption; however, dermatitis or skin excoriation may hasten this.
TABLE 201­2
Clinical Effects of Cholinergic Excess Secondary to Organophosphorus Insecticide Poisoning
Mnemonics for the Muscarinic Effects of Cholinesterase Inhibition
S Salivation
L Lacrimation
U Urinary incontinence
D Defecation
G GI pain
E Emesis
D Defecation
U Urination
M Miosis
B Bradycardia, bronchorrhea, bronchospasm
E Emesis
L Lacrimation
S Salivation
“Killer Bs” Bradycardia, bronchorrhea, bronchospasm
Nicotinic Effects of Cholinesterase Inhibition
 * Muscle fasciculations, cramps, and weakness (including diaphragm)
 * Mydriasis, pallor
 * Tachycardia, hypertension
CNS Effects of Cholinesterase Inhibition
 * Anxiety, restlessness, emotional lability
 * Tremor, headache, dizziness
 * Confusion, delirium, hallucinations
 * Seizures, coma
Acetylcholine is the presynaptic neurotransmitter at nicotinic receptors in the sympathetic ganglia and adrenal medulla. Inhibition of acetylcholinesterase at these locations results in sympathetic stimulation, producing pallor, mydriasis, tachycardia, and hypertension. In most patients, parasympathetic stimulation usually predominates, but mixed autonomic effects are common.
Nicotinic stimulation at neuromuscular junctions results in muscle fasciculations, cramps, and muscle weakness. This syndrome may ​progress to paralysis and areflexia, making it difficult to detect seizure activity. Respiratory muscle paralysis can lead to ventilatory failure. Death is often due to respiratory failure caused by bronchorrhea and respiratory muscle weakness.

Abdominal pain is common, with rare cases of pancreatitis and peritonitis. The clinical course may be complicated by aspiration of gastric contents and hydrocarbon solvents within insecticide preparations; this causes lipoid pneumonia and contributes to respiratory failure. ​Myocardial ischemia
 can occur in the early stages of severe toxicity.
More lipid­soluble organophosphates may not produce immediate symptoms of toxicity, but instead produce delayed sequelae. Low­grade chronic organophosphate exposures occur among farmworkers, ​pesticide manufacturing plant workers, exterminators, and patients ​taking cholinergic
 ophthalmologic preparations. Symptoms and signs are often less dramatic and nonspecific and occur without the ​cholinergic syndrome.

An intermediate syndrome occurring  to  days after an organophosphate exposure is reported in up to 40% of patients following ​ingestion.
Clinical features include paralysis of neck flexor muscles, muscles innervated by the cranial nerves, proximal limb muscles, and respiratory muscles
(respiratory support may be needed). Symptoms or signs of cholinergic excess are absent in this syndrome. Electromyography may assist in making
 the diagnosis. Aggressive, early antidote therapy and supportive measures may prevent or ameliorate the severity of this syndrome. Symptoms usually resolve within  days. Nerve gas poisoning has not been reported to cause the intermediate syndrome.

Chronic toxicity, seen primarily in agricultural workers with daily exposure, manifests as symmetrical sensorimotor axonopathy. This mixed sensorimotor syndrome may begin with leg cramps and progress to weakness and paralysis, mimicking features of the Guillain­Barré syndrome.
Organophosphate­induced delayed neuropathy is characterized by cognitive dysfunction, impaired memory, mood changes, autonomic
 dysfunction, peripheral neuropathy, and extrapyramidal signs. Chronic fatigue syndrome and multiple chemical sensitivity have been reported in
 some (predominantly female) patients after exposure to very low doses of organophosphate insecticides. Children are at greater risk of toxicity when exposed, due to smaller body size and lower baseline levels of cholinesterase activity.
Chemical warfare nerve agents, such as soman, sarin, tabun, and VX, are organophosphate compounds that inactivate acetylcholinesterases. They are
 rapid acting and extremely potent; death can occur within minutes of inhalation or dermal exposure, as was reported during the 2013 Syrian conflict.
Soman ages within minutes; thus, there is little time to administer antidotes.
Diagnosis
Diagnosis and treatment are based on history and the presence of a suggestive toxidrome; laboratory cholinesterase assays and reference laboratory testing for specific compounds take time and have limitations, and waiting for results delays administration of potentially lifesaving therapy. Diagnosis is often difficult due to a constellation of clinical findings that can be variable in both acute and chronic poisonings.
Noting a characteristic hydrocarbon or garlic­like odor may assist in diagnosis. The cholinergic toxidrome may vary depending on the intoxication’s severity and the predominance of muscarinic, nicotinic, and CNS manifestations. The majority of patients severely poisoned with an
 organophosphorus insecticide will have altered mental status, pinpoint pupils, excessive sweating, and difficulty breathing.
Plasma butyrylcholinesterase and red cell acetylcholinesterase enzyme activity are both quantifiable but serve only as markers of cholinesterase activity at the synaptic junction. Red cell acetylcholinesterase is a more accurate indicator of synaptic cholinesterase inhibition, but plasma butyrylcholinesterase is easier to assay and more available. Baseline cholinesterase activity varies among individuals, and the degree of cholinesterase inhibition necessary to produce symptomatic illness is variable. In addition, there is poor standardization of normal ranges between laboratories.
Plasma butyrylcholinesterase activity may be decreased by up to 50% following exposure in asymptomatic patients not requiring treatment. Red cell acetylcholinesterase is typically reduced to 10% to 20% of normal activity in moderate poisoning and to <10% in severe cases. Plasma butyrylcholinesterase activity usually decreases first following a significant exposure and takes  to  days to normalize in cases where an oxime
(e.g., pralidoxime) has not been administered. Red cell acetylcholinesterase requires regeneration of red blood cells to recover, and following a severe exposure, full activity may not be restored for up to 120 days.
Plasma butyrylcholinesterase levels may be depressed in patients with genetic variants, chronic disease states, liver dysfunction, hypersensitivity reactions, infection, pregnancy, and low serum albumin states and by drugs (​succinylcholine, codeine, morphine), neoplasms, and malnutrition. Red blood cell acetylcholinesterase measurements are factitiously lowered by hemoglobinopathies, pernicious anemia, oxalate­containing blood containers, and concurrent antimalarial treatment.
Routine laboratory test abnormalities are nondiagnostic but may include evidence of pancreatitis, hypo­ or hyperglycemia, leukocytosis, and abnormal
 liver function. In severe cases, a chest radiograph may show pulmonary edema. Common abnormalities include torsades de pointes, ventricular tachycardia, and ventricular fibrillation. ECG changes include ST­segment changes, peaked T waves, atrioventricular block, and prolongation of the QT
  interval. Electromyography may identify and quantify acetylcholinesterase inhibition at neuromuscular junctions.
Treatment
Treatment consists of airway control, intensive respiratory support, general supportive measures, decontamination, prevention of absorption, and the
,19 administration of antidotes (Table 201­3). Death occurs in untreated patients through a combination of bronchorrhea, respiratory muscle paralysis, and CNS depression. Therefore, immediate priorities following decontamination are airway protection, provision of ventilation, reduction of bronchorrhea via adequate atropinization, and reversal of respiratory muscle paralysis through administration of an oxime. Therapy should not be withheld pending determination of cholinesterase levels.
TABLE 201­3
Treatment for Organophosphate Poisoning
Decontamination Protective clothing must be worn to prevent secondary poisoning of healthcare workers.
Handle and dispose of all clothes as hazardous waste.
Wash patient with soap and water.
Handle and dispose of water runoff as hazardous waste.
Monitoring Cardiac monitor, pulse oximeter, 100% oxygen
Gastric lavage No proven benefit
Activated No proven benefit charcoal
Atropine Initial bolus of .2–3.0 milligrams IV in an adult depending on severity of symptoms (doses in children should start at .05 milligram/kg IV).
Double the dose of IV atropine every  min to achieve adequate atropinization:
Clear chest on auscultation
Heart rate >80 beats/min
Systolic blood pressure >80 mm Hg
Follow with continuous infusion of 10%–20% per hour of the initial dose of atropine that was required to achieve adequate ​­ atropinization (typical infusion rates vary from .4 to  milligrams/h IV in adults).
Adjust infusion rate to maintain adequate atropinization and avoid atropine toxicity (absent bowel sounds, hyperthermia, delirium).
Pralidoxime Give as soon as possible, may even be given 24–48 h after exposure
 milligrams/kg IV in adults (30 milligrams/kg up to  gram in children), mixed with normal saline and infused over 5–10 min
Followed by continuous infusion:  milligrams/kg per hour for 24–48 h
Seizures Benzodiazepines IV

In cases of acute cutaneous exposure, protective clothing must be worn to prevent secondary poisoning of healthcare workers.
Neoprene or nitrile gloves should be used instead of latex. Patients with suspected exposure must be removed from the contaminated environment and transported to the ED, in a manner that is safe for patients and healthcare workers (e.g., no transport by helicopter). All clothes and accessories
 must be removed completely, placed in plastic bags, and disposed of as hazardous materials. The patient should be immediately decontaminated externally with copious amounts of a mild detergent such as dishwashing liquid and water. Decontamination includes the scalp, hair, fingernails, skin, conjunctivae, and skin folds. Body fluids should be treated as contaminated. Abrasion or irritation of the skin should be avoided. Contaminated runoff water should be contained and disposed of as hazardous material. Instruments used can be decontaminated using chlorine bleach.
Patients with acute exposures should be placed on oxygen, a cardiac monitor, and pulse oximeter. A 100% nonrebreather mask will optimize oxygenation in the patient with excessive airway secretions and bronchospasm; however, atropine administration should not be delayed or withheld if
 oxygen is not immediately available. Gentle suction will assist in clearing airway secretions resulting from hypersalivation, bronchorrhea, or emesis.
Coma, seizures, respiratory failure, excessive respiratory secretions, or severe bronchospasm necessitates endotracheal intubation. Establish an IV line with baseline blood sampling that can include determination of cholinesterase levels. A nondepolarizing agent should be used when neuromuscular blockade is needed. Succinylcholine is metabolized by plasma butyrylcholinesterase; therefore, prolonged paralysis may result. Hypotension is initially treated with fluid boluses of isotonic crystalloid.

There is no published evidence demonstrating that gastric lavage improves outcome following organophosphate ingestion. Gastric lavage undertaken within  hour of a very large ingestion (following airway protection via endotracheal intubation) may be beneficial, but its performance should not delay timely administration of antidotal therapy. Activated charcoal is sometimes recommended because organophosphates do bind in
 vitro, although there is no evidence that single or multiple doses of activated charcoal improve patient outcome. ​Hemodialysis, hemofiltration, and hemoperfusion are of no proven value.
,25­27
Atropine is the antidote for significant organophosphate poisonings (Table 201­3). As a competitive antagonist of acetylcholine at central and peripheral muscarinic receptors, atropine will reverse the effects secondary to excessive cholinergic stimulation. Pinpoint pupils, excessive sweating and secretions, and respiratory distress are triggers for treatment with atropine. In adults, an initial dose of .2 to .0 milligrams is given depending on severity of symptoms. The dose is doubled every  minutes until the following are achieved: chest clear on auscultation, heart rate >80 beats/min, and systolic blood pressure >80 mm Hg. Large amounts of atropine, on the order of hundreds of milligrams, may be necessary in massive ingestions. Proactive contact with the hospital pharmacy (or even other centers) may be necessary to ensure access to adequate amounts of atropine.
Pupillary dilatation is not a therapeutic end point. Tachycardia is not a contraindication to the use of atropine in organophosphorus poisoning because tachycardia can occur secondary to bronchospasm or bronchorrhea with hypoxia, which can be reversed with atropine.
The initial atropine should be IV when possible, but  to  milligrams IM should be considered when IV access is not possible. Normally, this initial dose of atropine should produce clinically obvious antimuscarinic symptoms; absence of anticholinergic symptoms after an initial dose is thus consistent with organophosphate poisoning. Once an effective amount of atropine has been given, an infusion of 10% to 20% per hour of the initial dose of atropine that was required to achieve adequate atropinization should be started in order to maintain an anticholinergic state. Importantly, atropine reduces respiratory tract secretions but does not reverse muscle weakness. Respiratory support through endotracheal intubation and artificial ventilation is required in severe poisoning.
Glycopyrrolate, an alternate anticholinergic agent that does not produce CNS toxicity, may be used. However, its dosing is not well defined, and there is no proven benefit compared to atropine. The need for glycopyrrolate is unclear because adequate atropinization (using atropine) without significant
CNS toxicity can be achieved via monitoring for anticholinergic effects (e.g., absent bowel sounds, hyperthermia, delirium) and adjusting the atropine
 infusion rate as needed.
,25,28
Compounds called oximes are used to displace organophosphates from the active site of acetylcholinesterase, thus reactivating the enzyme.
Pralidoxime is the oxime in common use and ameliorates muscarinic, nicotinic, and CNS symptoms. Importantly, pralidoxime reverses muscle paralysis if given early, before aging occurs. If ​possible, blood samples for acetylcholinesterase levels are obtained before administration of pralidoxime, but it is important that pralidoxime be administered as soon as possible before permanent and irreversible aging occurs.
Although pralidoxime is more effective in acute than in chronic intoxications, it is recommended for use even later than  to  hours after exposure.
The pralidoxime dose recommended by the World Health ​Organization is a 30­milligram/kg IV bolus followed by an IV infusion of  milligrams/kg per hour.
Pralidoxime should be continued for  to  hours while monitoring acetylcholinesterase levels. Despite theoretical and experimental benefit and worldwide clinical use, current evidence is inadequate to show that oximes reduce mortality or the complication rate in acute organophosphate
28­30 poisoning. Pralidoxime is not recommended for asymptomatic patients or for patients with known carbamate ​exposures presenting with minimal symptoms.

Seizures are treated with airway protection, oxygen, atropine, and benzodiazepines. Atropine may prevent or abort seizures (due to cholinergic overstimulation) that occur within the first few minutes of exposure. Pulmonary edema and bronchospasm are treated with oxygen, intubation, positive­pressure ventilation, atropine, and pralidoxime. Succinylcholine, ester anesthetics, and β­adrenergic blockers may potentiate poisoning and should be avoided.
Although there is some evidence for the benefit of magnesium sulfate and calcium channel blockers in the treatment of organophosphate ​poisoning,
 they are not yet recommended for routine clinical use.
Disposition and Follow­Up
Minimal exposures may require only decontamination and  to  hours of observation in the ED to detect delayed effects. Reexposure should be avoided because sequential exposures can result in cumulative toxicity. Patients returning to work should be limited from further exposure.
Admission to the intensive care unit is necessary for significant poisonings. Most patients respond to pralidoxime therapy with an increase in acetylcholinesterase levels within  hours. If there is no post­hypoxic brain damage and if the patient is treated early, symptomatic recovery occurs in
 days. If toxins are fat soluble, the patient may be symptomatic for prolonged periods of time and may be dependent on continuous pralidoxime infusion. During this period, which may last weeks while awaiting resynthesis of new enzyme, supportive care and respiratory support may be needed.
The end point of therapy is determined by the absence of signs and symptoms on withholding of pralidoxime.
CARBAMATES
The carbamate insecticides—aldicarb, carbofuran, carbaryl, ethienocarb, fenobucarb, oxamyl, methomyl, pirimicarb, propoxur, and ​trimethacarb—are
 cholinesterase inhibitors that are structurally related to the organophosphate compounds. These agents are primarily used as insecticides, but
 illegally imported rodenticides may contain aldicarb.
Pathophysiology
Carbamates can be toxic after dermal, inhalation, and GI exposure. Carbamates transiently and reversibly bind to and inhibit the cholinesterase enzyme. Regeneration of enzyme activity by dissociation of the carbamate–cholinesterase bond occurs within minutes to a few hours and involves rapid, spontaneous hydrolysis of the carbamate–cholinesterase bond. Therefore, aging does not occur, and as a major difference from organophosphate poisoning, in carbamate poisoning, restoration of normal function does not require generation of new enzyme.
Clinical Features
In adults, symptoms of acute carbamate poisoning are similar to the cholinergic syndrome observed with organophosphate agents but are of shorter duration. Because carbamates do not effectively penetrate the CNS in adults, less central toxicity is seen, and seizures do not occur. However, in children, presentation of acute carbamate poisoning differs, with a predominance of CNS depression and nicotinic effects.

Carbamates can also produce the intermediate syndrome.
Diagnosis
Diagnosis is based on clinical history and findings. Measurement of acetylcholinesterase activity is generally not helpful because enzymatic activity may spontaneously return to normal  to  hours after a carbamate exposure.
Treatment
Initial treatment of carbamate poisoning is the same as for organophosphorus compounds. Atropine is the antidote of choice and is administered for muscarinic symptoms. Atropine is usually all that is necessary while waiting for the carbamylated acetylcholinesterase complex to dissociate spontaneously and recover function (usually within  hours). Therapy is usually not needed for more than  to  hours.
The use of pralidoxime in carbamate poisoning is controversial. The carbamate­binding half­life to cholinesterase is approximately  minutes, and irreversible binding does not occur; therefore, there is little need for pralidoxime. Human case reports and some (but not all) animal studies suggest
 that pralidoxime may potentiate the toxicity of carbamates such as carbaryl. Pralidoxime should be avoided in known single­agent carbaryl poisonings. However, pralidoxime should be considered in mixed poisonings with an organophosphorus compound and a carbamate or if the type of insecticide is unknown.
Disposition and Follow­Up
Because carbamate poisonings have ​transient cholinesterase inhibition and rapid enzyme reactivation, the clinical course tends to be more benign than seen with organophosphates. Most patients recover completely within  hours. However, patients with depressed levels of consciousness have a
 significant m​ ortality, and methomyl poisoning is associated with a high risk of cardiac arrest at presentation as well as subsequent death after
 resuscitation.
In mild poisonings, observation suffices, and the patient may be discharged with follow­up. Moderate poisonings necessitate  hours of observation that includes evaluation for possible concomitant exposure to (and toxicity from) inactive ingredients or vehicles such as hydrocarbons.
ORGANOCHLORINES
Dichlorodiphenyltrichloroethane (DDT) is the prototype insecticide of these chlorinated hydrocarbons. Chlordane, heptachlor, dieldrin, and aldrin are compounds used for termite and roach control. Most have been restricted or banned in the United States, Europe, and many other countries because of their toxicity as well as their persistence in the environment and long half­life in the human body. Worldwide, these insecticides continue to be used.
Hexachlorocyclohexane (lindane) is a general garden organochlorine insecticide that is also used in some countries to treat scabies and head lice infestations. This compound is well absorbed by ingestion and inhalation. Dermal absorption occurs, particularly if the skin is abraded or repeated
 applications are used. Children and the elderly can develop neurotoxicity and seizures with therapeutic use of lindane.
Pathophysiology
Organochlorines are central neurologic stimulants that can be toxic after dermal, inhalation, and GI exposures. Transdermal absorption is affected by the type of vehicle and the agent’s (liquid or solid) physical state. Organochlorines antagonize γ­aminobutyric acid–mediated inhibition of the central neurons, leading to hyperexcitability with repetitive neuronal discharges following the action potential. Organochlorines are highly lipid soluble and accumulate in human ​tissues. Most are capable of inducing the hepatic microsomal enzyme system. Presence of organochlorines therefore reduces therapeutic e​ fficacy of drugs that are inactivated by this system.
Clinical Features
,38
Neurologic symptoms predominate in acute organochlorine intoxication. Mild poisoning presents with dizziness; ataxia; fatigue; malaise; headache; neurologic stimulation with hyperexcitability, irritability, and delirium; apprehension; tremulousness; myoclonus; and facial
37­39 paresthesias. More severe exposures may result in seizures, hyperthermia, coma, renal injury, and death. Seizures may occur early, without prodromal syndromes, and are usually short lived (although status epilepticus may occur). Organochlorines are marketed dissolved in hydrocarbon solvents that, by themselves, can cause sedation, coma, and aspiration pneumonitis. Either the organochlorines or the solvents can sensitize the myocardium to endogenous catecholamines, posing risk for cardiac dysrhythmia.
Chlorfenapyr is a prodrug insecticide that is converted into the active form after absorption by the insect. Chlorfenapyr manifests biphasic
 neurotoxicity. Initial symptoms are nonspecific and include headaches, body aches, drowsiness, and weakness. A latent period of apparent recovery is followed, on the seventh day after ingestion, by rapidly progressive paralysis leading to coma with a fatal outcome. No treatment is effective once the delayed symptoms start.
Diagnosis
History is important, and valuable information can be obtained from the package label regarding the product and vehicle involved. Laboratory evaluation generally is not helpful, but organochlorines can be detected in the serum and urine by specialty laboratories.
Treatment
Decontamination with removal of clothes and washing of the skin with mild detergent and water should occur following dermal exposure. Treatment includes administration of oxygen, with intubation indicated to treat hypoxia secondary to seizures, aspiration, and ​respiratory failure.
Benzodiazepines are indicated for ​seizure control. Dysrhythmia control may be indicated, but epinephrine should be avoided because both organochlorines and the associated ​co­ingested organic solvents can sensitize the myocardium to endogenous ​catecholamines. Hyperthermia is managed by external cooling. Activated charcoal and possibly gastric lavage (in large, recent ingestions) may be useful. The exchange resin cholestyramine is potentially useful for symptomatic patients exposed to chlordecone.
Disposition and Follow­Up
Exposed patients should be observed for  hours and admitted to the hospital if signs of toxicity develop or if ingestion involved a hydrocarbon.
PYRETHRINS AND PYRETHROIDS
Pyrethroid use and poisonings have increased since the phaseout of organophosphate insecticides for use in human dwellings. Pyrethrins are naturally occurring active extracts derived from the chrysanthemum plant. Pyrethroids are synthetic analogs of the pyrethrins with greater potency and
 environmental persistence, but they are considered safer than organochlorine and organophosphate insecticides. Pyrethroids are used commonly as aerosols in automated insect sprays in public areas; therefore, inhalation is the most common source of exposure. These agents are available as dusts and liquids in a hydrocarbon base. Pyrethrins are common ingredients in over­the­counter household insecticides, pediculicides, and scabicides. They are rapidly hydrolyzed by mammals and therefore pose low risk of human toxicity.
Pathophysiology
Toxicity results from dermal absorption, inhalation, or ingestion. Pyrethroids block the sodium channel at the neuronal cell membrane, causing
 repetitive neuronal discharge. Additional effects include inhibition on γ­aminobutyric acid receptors, increased nicotinic cholinergic transmission, norepinephrine release, and interference with sodium–calcium exchange across cell membranes. Pyrethrin antigens are cross­antigenic with ragweed pollen, so allergic reactions are common after exposure.
Clinical Features
These compounds can cause dermal, pulmonary, GI, and neurologic illness. Allergic hypersensitivity reactions are the most common effects
,43 of pyrethrins and manifest as dermatitis, bronchospasm, rhinitis, hypersensitivity pneumonitis, or anaphylaxis. Skin contact may lead to paresthesias and burning within  minutes of exposure that usually dissipates within  hours.
Systemic toxicity can occur from occupational poisonings and following large intentional ingestions. Features of systemic toxicity include fatigue and
 lethargy, nausea and vomiting, paresthesias, hyperexcitability, tremors, muscle fasciculations, pulmonary edema, respiratory failure, and seizures.
Diagnosis
Diagnosis is dependent on a history of exposure. Differential diagnosis includes allergic reactions and ingestions with neurologic stimulants.
Laboratory tests have no diagnostic value.
Treatment
Treatment includes removal from exposure; dermal, ocular, and GI decontamination; treatment of allergic manifestations; and ​supportive care.
Disposition and Follow­Up
Disposition is usually related to the severity of asthmatic and allergic manifestations. The clinical course is usually benign, and hospitalization is not necessary for most accidental exposures.
NEONICOTINOIDS
Neonicotinoids are structurally similar to nicotine, acting as agonists at the postsynaptic acetylcholine receptor. Neonicotinoids have high affinity for insect CNS nicotinic acetylcholine receptors, producing paralysis and death. Commercially available agents from this family include imidacloprid, thiamethoxam, clothianidin, acetamiprid, thiacloprid, dinotefuran, and nitenpyram.
Data regarding human toxicity are limited to case reports. Toxicity from imidacloprid poisoning is relatively mild to moderate in most cases, with symptoms of nausea, emesis, diarrhea, and headache. However, uncommon cases of respiratory failure, encephalopathy, hypotension,
,46 rhabdomyolysis, and renal failure have occurred. Toxicity from acetamiprid poisoning has been associated with severe nausea and vomiting,
 muscle weakness, hypothermia, convulsions, and ​hypothermia. Treatment is supportive.
NEREISTOXIN ANALOGS
Analogs of nereistoxin are considered low­toxicity insecticides and include bensultap, cartap, thiocyclam, and thiosultap. These insecticides induce neurotoxicity by promoting extracellular calcium influx and stimulating the release of intracellular calcium from the sarcoplasmic reticulum.
Occupational skin exposure can produce nausea, vomiting, muscle tremors, dyspnea, and mydriasis. Intentional ingestions are associated with
48­50 depressed level of consciousness, muscle fasciculations and spasms, seizures, hypotension, hypoxia, and death.
Animal studies suggest that sulfhydryl­containing compounds including L­cysteine, acetylcysteine, D­penicillamine, and dimercaprol, may be effective antidotes, but human data are lacking. Treatment is supportive.
AMITRAZ
Amitraz is an insect repellent, topical insecticide, and acaricide used as a spray on agricultural crops and as a wash solution to treat ectoparasites found on domesticated animals. Amitraz possesses agonist activity at the postsynaptic α ­adrenergic receptor, interacts with the neuromodulator
 octopamine, inhibits monoamine oxidase, and impairs prostaglandin synthesis.
The clinical manifestations following human overdose include mental status depression, bradycardia, respiratory depression, miosis, hypotension,
,52 and hypothermia. Mechanical ventilation may be required, but with supportive therapy, recovery is expected.
N,N­DIETHYL­3­METHYLBENZAMIDE (DEET)
DEET is used extensively as an over­the­counter insect repellent, formulated within products at concentrations from 5% to 100%. When used as directed, these products are generally safe. Toxicity can occur with ingestion or prolonged exposure on covered or damaged skin. DEET is a neurotoxin that causes seizures after large ingestions or extensive dermal exposures of high­concentration products. Small children are most susceptible to systemic toxicity from skin absorption. Dermal absorption occurs within  hours of topical application, but peak concentrations may be delayed several hours.
Systemic toxicity is rare but manifests as restlessness, insomnia, altered behavior, confusion, neurologic depression, slurred speech, ataxia, tremors, muscle cramps, hypertonia, and seizures occurring with or without prodrome. Hypotension and bradycardia have been reported with large dermal or oral exposures. Treatment includes benzodiazepines for seizures, skin decontamination with mild detergent and water, and activated charcoal for recent ingestions. Most patients recover with supportive care.
HERBICIDES
Herbicides are used to kill weeds. Mechanisms of toxicity to plants include inhibition of photosynthesis, respiration, protein synthesis, or growth stimulation (by mimicking plant hormones called auxins). Some classes pose a health hazard to humans (Table 201­4). Herbicidal formulations contain multiple ingredients such as organic solvents, surfactants, and preservatives that may have their own toxic effects; these may not always be disclosed on the product label.
TABLE 201­4
Selected Herbicide Classes That Pose Potential Harm to Humans
Chlorophenoxy compounds
Bipyridyls: paraquat and diquat
Urea substituted herbicides
Organophosphates
Glyphosate
CHLOROPHENOXY HERBICIDES

Chlorophenoxy herbicides are synthetic plant hormones that disrupt transport of nutrients and growth, leading to plant death. The most commonly used compounds are ,4­dichlorophenoxyacetic acid and 4­chloro­2­methylphenoxy­acetic acid. ,4,5­Trichlorophenoxy acetic acid has been banned throughout much of the world because of its contamination with ,3,7,8,­tetrachlorodibenzo­p­dioxin. These compounds are effective against broadleaf plants and are used as weed killers on lawns and grain crops.
Pathophysiology
Mechanisms leading to human toxicity following chlorophenoxy herbicide exposure include cell membrane damage, disruption of neuronal transport mechanisms, formation of false neurotransmitters acting at muscarinic and nicotinic receptors, and uncoupling of mitochondrial oxidative
 phosphorylation. Oral absorption of chlorophenoxy herbicides is rapid. Dermal and inhalational absorption is poor and rarely results in systemic toxicity.
Clinical Features
Local exposure leads to eye and mucous membrane irritation that may last for days. After ingestion, nausea, vomiting, and diarrhea occur. Pulmonary complications may include dyspnea, hemoptysis, and pulmonary edema. Cardiovascular findings include hypotension, tachycardia, and dysrhythmias.
Mental status changes and seizures may occur. Muscle toxicity manifests as muscle tenderness, fasciculations, myotonia, and rhabdomyolysis.
Metabolic acidosis and hyperthermia may occur secondary to uncoupling of oxidative phosphorylation; hypercapnia and ventilatory failure can follow.
Peripheral neuropathy and myopathy have been described in the recovery phase after acute and chronic exposure.
Diagnosis
Diagnosis is based on a history of exposure. Ancillary tests generally are nonspecific but may demonstrate a metabolic acidosis, rhabdomyolysis, or evidence of hepatorenal dysfunction. Toxin levels are not immediately available.
Treatment
Treatment is supportive and includes decontamination measures, respiratory support for myopathic­related respiratory failure, and maintenance of
,54 adequate urine output for rhabdomyolysis. Although urinary alkalinization will increase the elimination of these compounds and is recommended for severely poisoned patients, it should be used with caution in cases of hyperthermia since bicarbonate administration will increase carbon dioxide
,55 production. Hemodialysis can also be used to enhance chlorophenoxy herbicide clearance.
Disposition and Follow­Up
Severe toxicity and serious complications are not common following exposure to chlorophenoxy herbicides. Because toxic effects usually appear within  to  hours, patients with mild symptoms can be observed and discharged after that time.
BIPYRIDYL HERBICIDES
The bipyridyl compounds, paraquat and diquat, are nonselective contact herbicides. Both are used widely and are responsible for significant
 morbidity if ingested. Paraquat is a fast­acting, nonselective herbicide. It is used for killing grass and weeds and is manufactured as a liquid, granules, or as an aerosol. Paraquat is commonly combined with diquat and other herbicides. Most products contain a blue dye, a stenchant, and an emetic.

Ingestion is responsible for the majority of paraquat deaths, although deaths have been reported after transdermal exposure. Inhalation of and exposures to sprays can be very irritating to conjunctivae and the airway but are unlikely to cause systemic toxicity. Diquat poisoning is less commonly reported than paraquat poisoning, but clinical features of toxicity are similar. Management of diquat toxicity is considered the same as for paraquat.
Pathophysiology

Paraquat is a severe local irritant and devastating systemic toxin. There is minimal transdermal absorption of paraquat in the absence of preexisting skin lesions. Ingested paraquat is absorbed rapidly, particularly if the stomach is empty. Plasma concentration peaks within minutes to  hours after ingestion. Paraquat is then distributed to most organs, with the highest concentrations found in the kidneys and lungs. A lethal oral dose of the 20% concentrate solution is about  to  mL in an adult and  to  mL in a child.

Paraquat actively accumulates in the alveolar cells of the lungs, where it is transformed into a reactive oxygen species, the superoxide radical. This anion is responsible for lipid peroxidation that leads to degradation of cell membranes, cell dysfunction, and necrosis. Lung injury has two phases. An initial destructive phase is characterized by loss of type I and type II alveolar cells, infiltration by inflammatory cells, and hemorrhage. These changes may be reversible. The later, proliferative phase is characterized by fibrosis in the interstitium and alveolar spaces. Paraquat and oxygen enhance each other’s toxicity by sustaining the redox cycle. Myocardial injury and necrosis of the adrenal glands may occur.
Diquat’s structure and action mechanism are similar to those of paraquat. Formulations containing diquat do not contain the dye, stenching agent, or emetic usually added to paraquat. The lethal dose for diquat is similar to that of paraquat, but there is less occurrence of pulmonary injury and fibrosis because of diquat’s lower affinity for pulmonary tissue. Diquat is caustic to the skin and GI tract, and exposure can result in renal and liver necrosis.
Clinical Features
Clinical features depend on both the amount and route of exposure. Paraquat’s severe caustic effects produce local skin irritation and ulceration of epithelial surfaces. Severe corrosive corneal injury may result from eye exposure. Upper respiratory tract exposure may result in mucosal injury and epistaxis. Inhalation may lead to cough, dyspnea, chest pain, pulmonary edema, epistaxis, and hemoptysis. Respiratory symptoms may persist for several weeks after inhalation exposure.
Ingestion causes GI irritation and mucosal damage with ulcerations (Table 201­5). A burning sensation of the lips or mouth may occur within a few minutes to hours, followed by ulceration  to  days later. Nausea, vomiting, diarrhea, buccopharyngeal pain, esophageal pain, and abdominal pain may develop. Hypovolemia occurs from GI fluid losses and decreased oral intake.
TABLE 201­5
Paraquat Toxicity From Ingestion
Category Clinical Features Approximate Amount Ingested
Mild Asymptomatic or nausea, vomiting, and diarrhea. <20 milligrams/kg or <7.5 mL of 20% concentrated ​solution
Renal and hepatic injury minimal or absent. in average adult
Decreased pulmonary diffusion capacity may be present.
Complete recovery expected.
Severe Initially nausea, vomiting, diarrhea, abdominal pain, and mouth and throat Between  and  milligrams/kg or between .5 and  mL ulceration. of 20% concentrated solution in average adult
Positive colorimetric test for paraquat in the urine.
1–4 d: renal failure, hepatic ​impairment, hypotension.
1–2 wk: cough, hemoptysis, pleural effusion, pulmonary fibrosis.
Survival possible, but majority of cases die within 2–3 wk from pulmonary failure.
Fulminant Initially nausea, vomiting, diarrhea, and abdominal pain. >40–50 milligrams/kg or >15–20 mL of 20% ​concentrated
Rapid development of renal and hepatic failure, GI ulceration, pancreatitis, solution in ​average adult toxic myocarditis, refractory hypotension, coma, convulsions.
Death from cardiogenic shock and ​multiorgan failure within 1–4 d.
Multisystem effects include GI tract corrosion, acute renal failure, cardiac failure, hepatic failure, and extensive pulmonary injury. The effects can be evident within a few hours following large ingestions, but more typically, manifestations of renal failure and hepatocellular necrosis develop between the second and fifth days; progressive pulmonary fibrosis leading to refractory hypoxemia occurs  days to several weeks after exposure. Metabolic
(lactic) acidosis is common as a result of pulmonary effects (e.g., hypoxemia) combined with multisystem failure.
Diagnosis
Early diagnosis, prognostication, and subsequent therapy are important. Obtain details of the exposure, including its timing, route, accidental or intentional nature, and amount and concentration of the product. The quantity of paraquat ingested is directly related to outcome. Age over  years
,59 and a history of renal disease are associated with worse prognosis. A sensation of generalized skin burning is associated with increased risk of
 death.
Laboratory abnormalities generally reflect the consequences of vomiting, diarrhea, and multiorgan failure. Acute kidney injury is common and is associated with increased mortality. Creatinine increase is driven by paraquat­induced oxidative stress as well as acute kidney injury; thus, it is not an accurate marker of glomerular filtration rate in the setting of paraquat toxicity. An increase in creatinine of <0.034 milligram/dL (3 micromole/L) per hour over  hours is associated with recovery. An increase in creatinine of >0.049 milligram/dL (4.3 micromole/L) per hour over  hours or an increase
 in serum cystatin C concentration of >0.009 milligram/L over  hours is associated with death.

Serum lactate may aid with prognosis. Two retrospective studies assessed lactate levels associated with death. One identified a lactate of >3.35 mmol/L (30 mg/dL) as having 74% sensitivity for mortality, whereas the other found an 82% sensitivity for death associated with a lactate level
,64 exceeding .4 mmol/L (40 mg/dL).
Radiographic abnormalities of diffuse pulmonary infiltrates may indicate aspiration or direct paraquat­induced parenchymal injury. Radiographic extent of pulmonary involvement is related to outcome. Chest radiographs may also show pneumomediastinum or pneumothorax due to corrosive
 rupture of the esophagus; these findings are associated with increased mortality risk.
A urinary dithionite test can be performed to detect paraquat within a few hours after ingestion and has some prognostic value; a clear test color between  and  hours after paraquat exposure favors survival. The test is semiquantitative; patients with a darker blue color change have a worse
,67 prognosis. A commercially available semiqualitative colorimetric test (Paraquat Test Kit®; Syngenta CTL, Surrey, United Kingdom) is available for detecting paraquat in urine or plasma.

Quantitative analyses for paraquat in blood can assist in the diagnosis. Nomograms are used for predicting survival based on plasma paraquat
 concentration and time of ingestion, but require availability of specific analytical methods that may not always be available. A predictive nomogram based on plasma concentration has not been developed for diquat poisoning.
Consult with gastroenterology about the need for endoscopy to identify the extent and severity of mucosal lesions.
Treatment
The goal of early and vigorous decontamination is to prevent absorption and thus reduce pulmonary toxicity. Any exposure to paraquat is a medical emergency, with hospitalization indicated even if the patient is asymptomatic. Commencement of treatment should never be delayed to wait for the results of diagnostic testing. The outcome for patients with evidence of severe poisoning is extremely poor, despite best available treatments instituted in advanced critical care settings. In some cases, the most humane approach will be to provide analgesia and supportive care, rather than invasive interventions. Early treatment is mainly supportive but is an important determinant of survival. Do not administer supplemental oxygen unless the patient is severely hypoxic because added oxygen stimulates superoxide radical formation and promotes oxidative stress.
Remove clothing and decontaminate skin with mild detergent and water. Take care to avoid skin abrasions that may increase absorption. If there is conjunctival irritation, irrigate with copious amounts of water or saline. Replace fluid and electrolytic losses and maintain intravascular volume and urine output. Treat pain with opioids. Gastric lavage is contraindicated due to the high likelihood of paraquat­induced corrosive injury. Consult with GI
 for consideration of potential esophageal ​corrosive injury and need for endoscopy.
In patients presenting within  hours of ingestion, GI decontamination with absorbents that bind paraquat should be undertaken as a matter of urgency, either via oral ingestion or via a nasogastric tube. A single dose of activated charcoal (1 to  grams/kg), diatomaceous fuller’s earth (1 to 
 grams/kg in 15% aqueous suspension), or bentonite (1 to  grams/kg in a 7% aqueous slurry) should be used.
Hemoperfusion can remove paraquat and has been recommended to be started as soon as possible. Limited evidence suggests a
,69 possible survival benefit when hemoperfusion is commenced within  hours of paraquat exposure. If hemoperfusion is not available, then other
70­72 extracorporeal elimination therapies including intermittent hemodialysis may be beneficial. Although continuous venovenous hemodialysis removes paraquat, it is unlikely to provide rapid reductions in paraquat concentrations and therefore should not be used if other therapies are available. Continuous venovenous hemodialysis may be used as a therapy in the event of acute kidney injury.
Small methodologically limited studies suggested a benefit from repeated pulse doses of glucocorticoids and cyclophosphamide, but a large
,74 randomized controlled trial demonstrated no benefit. Dexamethasone may be beneficial and should be administered at a dose of  milligrams IV
 every  hours for the first  hours. Dexamethasone has relatively low toxicity and, in severe poisoning, may provide benefit if continued for weeks following exposure when there is the possibility of progression of pulmonary injury. Acetylcysteine may provide benefit and is of low toxicity. It should
 be administered continuously while there is evidence of acute toxicity in the inpatient setting.
Serial pulmonary function tests, chest radiographs, renal function tests, and blood gas determinations may be used to monitor progression of
 toxicity.
Treatment for diquat poisoning is similar to that for paraquat. Despite the lower toxicity for diquat, mortality approaches 50% after intentional diquat ingestion.
Disposition and Follow­Up
All patients should be observed for at least  hours following exposure. Clinically well patients with a negative urine dithionite test at this time are unlikely to develop toxicity. Patients with evidence of severe toxicity and prognostic markers indicating a fatal outcome should receive appropriate supportive and palliative care. Patients with clinical toxicity and an unclear prognosis are admitted to a critical care environment.
UREA­SUBSTITUTED HERBICIDES
Urea­substituted herbicides such as chlorimuron, diuron, fluometuron, and isoproturon are inhibitors of photosynthesis and have low systemic
 toxicity. In humans, methemoglobinuria may occur with ingestion. Treatment includes decontamination, supportive care, and as­needed treatment for methemoglobinemia (with methylene blue) (see Chapter 207, “Dyshemoglobinemias”).
ORGANOPHOSPHATE HERBICIDES
In addition to their use as insecticides, some organophosphate compounds are effective herbicides. Butiphos is used commonly as a cotton defoliant applied prior to mechanical harvesting. Treatment is identical to that for organophosphate insecticides.
GLYPHOSATE
Glyphosate is the active ingredient in many widely used preparations available for consumer use on lawns and gardens. Some lawn and ​garden products sold using a common or group brand name may contain different active ingredients; a common brand name may contain either glyphosate or the more toxic herbicide diquat.
Glyphosate can produce severe toxicity with massive ingestions of the diluted product or smaller­volume ingestions of solutions that are concentrated

(>10%). Ingestion of >150 mL of a 36% glyphosate solution is associated with severe multiorgan toxicity. Preparations may contain the toxic surfactant polyoxyethyleneamine, which is a corrosive, and the combination is more toxic than glyphosate alone. Inhalational exposures cause respiratory irritation. Dermal absorption is poor, so symptomatic poisonings are generally from ingestion.

Clinical effects include mucous membrane irritation and erosions with nausea, vomiting, abdominal pain, and diarrhea. Severe toxicity is characterized by airway burns, GI corrosive injury, metabolic acidosis, acute kidney injury, hyperkalemia, coma, refractory cardiovascular collapse, and potentially death.
Early airway evaluation is important in order to detect burns and edema. Airway protection may be required via endotracheal intubation. Treatment is primarily supportive. Along with oxygenation and ventilation, priorities include supporting circulation, treating hyperkalemia, and ameliorating
 complications due to corrosive GI effects. Hemodialysis may be supportive when severe acidosis and acute kidney injury are present.
Patients with small, asymptomatic ingestions can be discharged after  hours of observation. Significant GI symptoms, altered level of ​consciousness, hypoxemia, metabolic acidosis, and cardiovascular abnormalities indicate admission to an intensive care unit.
RODENTICIDES
A number of agents with distinct toxicities are used as rodenticides. Rodenticides are commonly classified based on whether they are anticoagulants or nonanticoagulants. Although intentional ingestions are often associated with significant morbidity and mortality, most unintentional exposures occur in young children and result in minimal or no toxicity.
NONANTICOAGULANTS
A number of nonanticoagulant rodenticides have been used throughout history. Many have been discontinued, although poisonings still occur from old products stored in garages, barns, and homes (Table 201­6).
TABLE 201­6
Selected Non­anticoagulant Rodenticides
Rodenticide Toxicity Mechanism Clinical Effects Treatment
Arsenic Severe Binds sulfhydryl groups Dysphagia, muscle cramps, nausea and vomiting, Activated charcoal in conjunction on proteins bloody diarrhea, dysrhythmias (QT prolongation), with airway protection, supportive cardiovascular collapse, altered mental status, care, chelation therapy using seizures, and late peripheral neuropathies. succimer, and dimercaprol.
Barium Severe Inhibits potassium Onset occurs within 1–8 h with nausea, vomiting, Gastric lavage with sodium or carbonate and channels, leading to diarrhea, abdominal pain, ​dysrhythmias, ​respiratory magnesium sulfate added to lavage other soluble hypokalemia. Acts as failure, muscular ​weakness, ​paresthesias, and solution to convert carbonate to forms such as ​­ depolarizing paralysis. less toxic sulfate; potassium barium neuromuscular blocker. replacement.
chlorides, ​­ hydroxides, and sulfides
Elemental or Severe, Caustic. Possible Skin irritation, cutaneous burns, oral burns, Supportive care, cardiac monitoring, yellow early mitochondrial toxin. abdominal pain, hematemesis, possible “​smoking” correction of electrolyte phosphorus cardiac luminescent vomitus and stool, ​garlicky odor, direct abnormalities. Maintenance of and toxic effects on the ​myocardium, kidney, and serum glucose ​concentration may neurologic peripheral ​vessels, ​cardiovascular collapse; late reduce cellular injury.
toxicity is neurologic ​depression with multisystem toxicity and ​­ a poor hepatorenal syndrome.
prognostic sign.
Sodium Severe Blocks Krebs cycle Nausea, vomiting, apprehension, lactic ​acidosis, Activated charcoal, seizure and ​­ fluoroacetate seizures, coma, respiratory depression, cardiac dysrhythmia control, and
(SFA)81 dysrhythmias, and pulmonary edema; ECG supportive care; experimental abnormalities include ST­segment and T­wave regimens include glycerol changes, tachycardia, premature ventricular ​­ monoacetate, calcium ​gluconate, contractions, ventricular tachycardia, and ​ventricular sodium succinate, and ethanol fibrillation; hyperkalemia and ​hypocalcemia are loading; consultation with a common. toxicologist is recommended.
Strychnine Severe Competitive Restlessness, muscle twitching, painful ​extensor Airway control, quiet environment antagonism of the spasms, opisthotonos, trismus, inability to ​swallow, (minimize sensory stimulation), and inhibitory and facial grimacing; medullary ​paralysis and death activated charcoal; avoid lavage neurotransmitter can follow. (may precipitate seizures); glycine at the benzodiazepines, barbiturates, postsynaptic brainstem analgesia; neuromuscular blockage and spinal cord motor if necessary.
neuron
Tetramine82 Severe Blocks γ­aminobutyric Rapidly acting; initial features include headache, The median lethal dose for acid receptors in the nausea, dizziness, fatigue, anorexia, numbness, and tetramine is ∼0.1 milligram/kg; 6–12
CNS listlessness; severe symptoms include loss of milligrams sufficient to kill an adult; consciousness, seizures, and coma; death is ​usually no antidote; supportive care; caused by respiratory failure. benzodiazepines or barbiturates for seizures.
Thallium Severe Combines with Early GI symptoms: nausea, vomiting, and abdominal Supportive care; multiple doses of ​­ sulfate83 mitochondrial pain; after 2–5 d, painful ​paresthesias, myalgias, activated charcoal or Prussian blue sulfhydryl groups, muscle weakness, ​headache, lethargy, tremors, (potassium ferric hexaniacinate) to interfering with ataxia, delirium, seizures, and coma; death from interrupt enterohepatic circulation oxidative respiratory failure and dysrhythmias; alopecia after and increase elimination in stool; phosphorylation approximately  wk; chronic neurologic sequelae. hemodialysis.
Zinc or Severe Combines with water Immediate nausea, vomiting, epigastric pain, Treat acidosis and hypocalcemia; ​­ aluminium and ​stomach acid to phosphorous or fishy breath, black vomitus, and GI consider acetylcysteine86; phosphide84,85 produce ​phosphine gas; irritation or ulceration; myocardial toxicity, shock, supportive care.
cellular toxicity and and acute lung injury; agitation, coma, seizures, necrosis to the GI tract, ​­ hepatorenal injury, metabolic acidosis, hypocalcemia, kidney, and liver if tetany.
ingested and to the lungs if inhaled
Cholecalciferol Moderate Mobilization of calcium Hypercalcemia, osteomalacia, and systemic Treat hypercalcemia with IV normal
(vitamin D ) from bones metastatic calcifications. saline, furosemide, steroids,
 calcitonin, and biphosphates as needed.
Red squill Low Blocks sodium­ Nausea, protracted vomiting, diarrhea, ​abdominal Treat as digoxin toxicity (atropine,
(limited potassium ​adenosine pain; massive ingestion causes hyperkalemia, external pacing, digoxin­specific ­​ toxicity in triphosphatase ​(similar atrioventricular block, ventricular irritability with antibody fragments, activated humans to digoxin poisoning) dysrhythmias, and death. charcoal).
due to early onset of emesis with gastric emptying)
ANTICOAGULANTS
Warfarin­type anticoagulants were the first generation of anticoagulant rodenticides and distributed commonly disguised as yellow corn meal or
 rolled oats. Most one­time warfarin rodenticide ingestions are insignificant accidental poisonings and do not cause any bleeding problems. Significant coagulopathy requires large amounts in a single exposure or a repetitive exposure over several days.
Following a single large ingestion, onset of the anticoagulant effect takes place within  to  hours. Warfarin’s biologic half­life is approximately  hours.
Therapy is not necessary for ingestion of a single mouthful of a warfarin rodenticide. For potentially toxic recent ingestion, consider activated charcoal.
Obtain a baseline prothrombin time and INR determination and repeat it in  to  hours. Vitamin K (phytonadione) administration is indicated if the

INR is >2.0. The suggested total PO daily dose is  to  milligrams in children and  milligrams in adults, administered in two to four divided doses.

Second­generation superwarfarins and the indandione derivatives were introduced when rodent resistance to warfarin began to appear. They are currently responsible for approximately 80% of human ​rodenticide exposures reported in the United States. Their mechanisms are the same as that of warfarin, but they are more potent, have more prolonged anticoagulant activity, and therefore have the potential to be highly toxic. Poisonings involving the indandione derivatives ​pindone, diphacinone, chlorophacinone, and valone have toxic and clinical ​characteristics similar to those of the superwarfarins.
The superwarfarins include the 4­hydroxy­coumarins brodifacoum, difenacoum, coumafuryl, and bromadiolone. These are readily available over the counter as grain­based bait. After intentional ingestions, adults often develop a coagulopathy within  to  hours. Because the biologic halflife of brodifacoum is approximately 120 days, a single ingestion may result in marked anticoagulation effects for weeks to
 months. Intentional repeated ingestions can cause severe bleeding.
The diagnosis may not be readily apparent. Some patients may not report an intentional ingestion. Small children and depressed patients with an unexplained coagulopathy or bleeding should raise suspicion of superwarfarin poisoning. Although the prothrombin time and INR are usually monitored, large doses of warfarin can also cause prolongation of the activated partial thromboplastin time. Superwarfarins are not detected by warfarin assays, but specific serum assays are available in reference laboratories.

Unintentional superwarfarin ingestions in the pediatric patient are unlikely to result in significant toxicity. Obtain a baseline INR and repeat  and  hours after ingestion. For acute intentional ingestions, gastric lavage is indicated for early presentations, and activated charcoal should be administered. Obtain a baseline INR and repeat in  and  hours. If the INR is elevated but there is no active hemorrhage, oral vitamin K is
 recommended. Forms of vitamin K other than vitamin K are ineffective because the conversion of these other forms to the active form is blocked by
 superwarfarins. Because of the extended half­life of the anticoagulant, prolonged therapy with high doses of vitamin K may be required to maintain

,91 hemostasis. Initial daily doses of  to  m​ illigrams in children and  milligrams in adults are recommended with titration to maintain a normal INR.
Doses up to 100 milligrams per day for  months have been reported. Upon discontinuation of vitamin K therapy, serial INR determinations are
 required to ensure that further therapy is not needed.
Patients with acute hemorrhage may require repletion of volume losses with normal saline or blood transfusions. Vitamin K ,  ​milligrams, should be
 administered by slow IV infusion to minimize the risk of a hypotensive reaction. Replacement of coagulation factors should be achieved using fourfactor prothrombin complex concentrate or three­factor prothrombin complex concentrate and fresh frozen plasma.
For asymptomatic patients who have accidentally ingested a superwarfarin, follow­up in  and  hours for coagulation studies should be arranged.
Prevention measures should be emphasized.


