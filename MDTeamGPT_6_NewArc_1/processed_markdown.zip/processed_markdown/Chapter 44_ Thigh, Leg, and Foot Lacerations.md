## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 44: Thigh, Leg, and Foot Lacerations
Moira Davenport
ANATOMY

Lower extremity injuries most frequently involve the lower leg and ankle, followed by the foot and toes, hip, and then knee.
THIGH ANATOMY
The thigh contains two fascial layers; the superficial fascia containing fat, lymphatics, cutaneous nerves, and superficial veins; and the deep fascia, containing muscles, major vessels, and nerves.
Thigh lacerations typically involve skin and superficial fascia, although deep lacerations can penetrate the deep fascia and into the underlying muscle.
Lacerations in the area of the femoral triangle can injure the femoral nerve, artery, or vein (Figure 44­1A). Arterial injury resulting from penetrating and blast wounds most commonly affects the femoral artery or its branches: circumflex, deep femoral, popliteal, and geniculate (Figure 44­1B).

Vascular injury is the most life­ and limb­threatening concern, with arterial injuries at high risk for limb loss. Suprapatellar lacerations may involve the quadriceps tendon, resulting in impaired knee extension. Compartment syndrome is a rare complication of thigh wounds (see Chapter 278,
“Compartment Syndromes”).
FIGURE 44­1. Thigh anatomy. A. Nerves, arteries, and veins in the femoral triangle. B. Femoral artery and its branches. a = artery; m = muscle. [Reproduced with permission from Morton DA, Foreman KB, Albertine KH: The Big Picture: Gross Anatomy, McGraw­Hill Education, Inc. © 2011, Figure 36­4.]

Chapter 44: Thigh, Leg, and Foot Lacerations, Moira Davenport 
. Terms of Use * Privacy Policy * Notice * Accessibility
LOWER LEG ANATOMY
The muscles of the lower leg are organized into four fascial compartments (see Figure 278­1). Muscles in the anterior compartment primarily produce extension (dorsiflexion) and inversion (Figure 44­2A); muscles in the superficial and deep posterior compartments primarily produce flexion
(plantarflexion) and inversion (Figure 44­2B); and muscles in the lateral compartment primarily produce flexion (plantarflexion) and eversion
(Figure 44­2C).
FIGURE 44­2. Muscles of the lower leg. A. Anterior compartment. B. Superficial posterior compartment. C. Lateral compartment. m = muscle; mm = muscles.
[Reproduced with permission from Morton DA, Foreman KB, Albertine KH: The Big Picture: Gross Anatomy, McGraw­Hill Education, Inc. © 2011, Figures
37­1C, 37­3A, and 37­2, respectively.]
Several important tendons in the lower leg are at risk for injury. The fibularis longus and fibularis brevis (also known as the peroneus longus and peroneus brevis) tendons, which contribute to foot plantar flexion and eversion, run behind the lateral malleolus and can be lacerated at this location
(Figure 44­2C). Lacerations of the shin rarely involve vital nerves or tendons, but infrapatellar lacerations can transect the patellar tendon, resulting in inability to extend the leg. The common peroneal nerve can be injured in complex fractures, sharp injuries, or lacerations of the lower extremity,
 resulting in foot drop (Figure 44­3).
FIGURE 44­3. Common peroneal nerve. [Reproduced with permission from: Waxman SG: Appendix C. Spinal nerves and plexuses. In: Waxman SG (ed): Clinical
Neuroanatomy, 27th ed. New York, NY: McGraw­Hill, Inc.; 2013. Figure C­16.]
Arterial supply to the lower leg originates from the popliteal artery (a continuation of the femoral artery) that bifurcates into the anterior and posterior tibial arteries at the inferior border of the popliteus muscle (Figure 44­4).
FIGURE 44­4. Major arteries of the lower leg.
FOOT ANATOMY
With the exception of the arch, the plantar epidermis and dermis of the foot are thick, able to withstand the force produced by a moving body while remaining quite sensitive to two­point discrimination and pressure. The heel has an 18­mm­thick modified pad of fat separated into chambers by fibrous septae. There is an additional broad internal fibrous arch, called the inner cup ligament, which helps maintain the shape of the heel. The skin of the sole readily hypertrophies, becoming quite thickened, especially in people who walk barefoot. The dense fibrous fatty tissue of the ball of the foot and heel makes wound exploration and visualization difficult in the ED.
In contrast to the protective plantar surface, skin on the dorsal aspect of the foot and about the entire ankle provides little protection for underlying tendons, nerves, and blood vessels. The dorsum of the foot, the ankle, and the pretibial surface are particularly vulnerable to blunt­force injuries. Most lacerations on the dorsal foot and in the ankle area are easily explored, except for posterior ankle lacerations, a limitation when partial laceration of the Achilles tendon is considered. The extensor hallucis longus tendon, which extends the first toe, runs along the top of the first metatarsal and may be injured when heavy objects are dropped on the foot (Figure 44­5). The Achilles tendon, the primary contributor to foot plantar flexion, may be severed by penetrating injuries to the posterior ankle.
FIGURE 44­5. Tendons of the foot.
Sensory nerves predominate in the foot, with most motor control of the foot being performed by nerves and muscles in the lower leg (Figures 44­6 and 44­7). The exceptions to this generalization are that the posterior tibial nerve innervates the intrinsic foot musculature, and the deep peroneal nerve innervates the extensor digitorum brevis and extensor hallucis brevis muscles; injuries to these nerves may
 result in toe clawing.
FIGURE 44­6. Nerves of the foot. a. = artery; n. = nerve.
FIGURE 44­7. Sensory innervation of the foot. n. = nerve.
GENERAL MANAGEMENT PRINCIPLES
HISTORY
Obtain a description of the mechanism of injury, assessing the potential for damage to underlying tissue, the risk of a retained foreign body, and degree of potential contamination. Determine the time interval from injury to evaluation, as delayed presentations can increase the incidence of infection. Inquire about foreign body sensation, paresthesias, anesthesia, weakness, or loss of function suggesting a nerve, vascular, or tendon injury.
The patient’s age influences wound healing and functional status following the injury. Ask about tetanus immunization status and conditions that increase the risk for infection or delayed wound healing such as diabetes, immunosuppression, or vascular disease. Patients who smoke, consume alcohol, or use illicit substances may be at additional risk of poor healing secondary to vascular disease. The patient’s employment should also be discussed as injuries may preclude a patient’s ability to return to work during the healing process.
PHYSICAL EXAMINATION
Inspect the wound, noting its location and proximity to underlying nerves or arteries. Document the location, length, estimated depth, and general shape of the wound. General appearance, obvious injuries, or visible foreign bodies should be noted; more detailed wound exploration typically waits until after anesthesia and radiographs, if needed. Provide anesthesia, cleanse the wound, and carefully inspect the full extent of the wound for foreign bodies.
The loose, thin skin over the dorsum of the foot allows for adequate visual, digital, and instrument exploration for tendon lacerations, as well as for foreign body discovery. The dense tissue of the plantar surface of the foot limits wound visualization, and the risk of creating further injury limits exploration. An exception to this general rule of limited exploration on the weight­bearing plantar surface is in an infected wound with suspected foreign body. With significant blunt injury to the leg, like a crush injury, consider compartment syndrome and evaluate accordingly (see Chapter 278,
“Compartment Syndromes”).
If a nerve laceration is suspected, light touch and/or static two­point discrimination should be tested in the foot and toes and compared with the uninjured side. Two­point discrimination varies in the foot, with normal values of .5 cm in the hind, mid, and forefoot, and <1 cm in the big toe, but
 these measures are not reliable in patients with diabetes or peripheral vascular disease. Sensory deficits to the foot can result in significant long­term morbidity. Motor function may be easier to assess after anesthesia or reduction of an associated fracture or dislocation. Obtain prompt surgical
 consultation if motor nerve or major sensory nerve injury is identified as primary repair may be indicated. Nerve injuries caused by open blunt injuries are not typically repaired at the time of injury, partly due to the risk of infection and partly due to the possibility that a contused nerve will regain function without surgical intervention.
Assess motor function, palpate the tendon, and observe the tendon through its entire range of motion to evaluate for tendon injuries. A partially injured tendon may be noted to “catch” on the synovial sheath during range of motion. The superficial location of the Achilles tendon facilitates evaluation of an injury to this structure; US can be used to augment manual palpation. Sometimes an Achilles tendon laceration may not be visible or palpable, and presence of active plantar flexion of the foot cannot be used to exclude the injury as the tibialis posterior muscle also flexes the foot at the ankle. The Thompson test can assist in detecting an Achilles tendon rupture. The patient lies prone on the examination cart with the feet hanging over the edge of the bed, and the examiner places one hand on each mid­calf (Figure 44­8). If the Achilles tendon is intact, the foot plantar flexes when the calf is squeezed. Comparison with the unaffected side is helpful to detect subtle movement. A positive Thompson test is when the affected
 foot does not flex, indicative of an Achilles tendon rupture.
FIGURE 44­8. Thompson test.
If the patient has a laceration about the knee, quadriceps and patellar tendon disruption may be directly visualized. Tendon integrity is also assessed by having the patient lay supine on the stretcher with the hip partially flexed and the heel in contact with the stretcher pad. Ask the patient to lift the foot; inability to raise the foot off the stretcher suggests quadriceps or patellar tendon disruption.
ANCILLARY STUDIES
Obtain radiographs when a fracture, radiopaque foreign body, or joint penetration is suspected. Forgoing radiographs and using wound exploration
7­9 alone to exclude a foreign body is a reasonable approach, but carries a small risk of missing a retained object. CT or MRI can detect retained organic material. Bedside US may identify retained foreign bodies and detect tendon lacerations and fractures (see Chapter , “Soft Tissue Foreign Bodies”).
Fluoroscopy is a useful dynamic imaging modality that may assist in identifying and removing foreign bodies. No single imaging modality or wound exploration will identify every foreign body; emphasize close follow­up if the mechanism of injury suggests a potential for a foreign body but none was identified on imaging or wound exploration.
Lacerations in proximity to a joint may penetrate the articular capsule, but detecting joint penetration by examination alone is often difficult. Intraarticular gas on plain radiograph is a definite sign of joint penetration. If the radiograph does not display intra­articular gas, the saline load
 test can be used to determine joint integrity, especially in the knee and ankle. Inject sufficient amounts of saline to adequately stress the capsule, because false­negative results may be obtained if too little fluid is injected. Volumes of  to 194 mL into the knee and  to  mL into the ankle yield sensitivities of ≥95% in detecting joint penetration by observing fluid leaking from the wound. ,11 The addition of methylene blue to the
 injected saline does not increase diagnostic accuracy. CT detection of intra­articular gas can also be used to identify joint penetration in periarticular
 knee wounds with high sensitivity.
TREATMENT
ANESTHESIA
Anesthesia can be administered by topical, local, or regional routes. The toes can be anesthetized using standard digital blocks. Epinephrinecontaining local anesthetics can be safely used for digital blocks in toes (see Chapter , “Local and Regional Anesthesia”).
Lacerations to the dorsum of the foot can be sufficiently anesthetized by infiltration of local anesthetic. Topical agents may also be used if there is a concern for tissue disruption with infiltration of anesthetic. The plantar surface of the foot is sensitive to the infiltration of a local anesthetic, so regional nerve blocks may be helpful. The sural nerve block and the posterior tibial nerve block (see Chapter 36) are the two most commonly used nerve blocks for the foot. Topical local anesthetic preparations can achieve adequate anesthesia on the dorsum of the thigh, leg, and foot, but may be ineffective on the dense epidermis of the plantar surface of the foot. In children, distraction techniques, use of child­life specialists, anxiolytics, and conscious sedation may help alleviate anxiety and pain response (see Chapter 115, “Pain Management and Procedural Sedation in Infants and
Children”).
WOUND PREPARATION
Wound irrigation with copious amounts of saline is recommended due to the increased risk of infection with lower extremity lacerations (see Chapter
, “Wound Preparation”). Debridement to remove devitalized tissue is an important aspect of wound care to reduce the risk of wound complications, but debridement should be limited on the plantar surface of the foot or on the shin as skin in those areas is not pliable enough to be stretched and cover a defect. Any opening resulting from debridement would then require repair under tension across the laceration.
A lower risk of wound infection if the repair is performed within  hours after the injury is not substantiated by published evidence
(see Chapter , “Wound Preparation”). Repair of clean­appearing wounds without visible contamination presenting after  hours is acceptable if primary closure is felt beneficial. Otherwise, consider delayed primary closure in cases of delayed presentation or heavy contamination (see Chapter

, “Wound Closure”).
WOUND CLOSURE
Wound location, size, and shape guide the decision to close with adhesive strips, sutures, or staples. Staples are acceptable for linear lacerations through the dermis as long as the wound is sharp with straight and accurately aligned wound edges, minimizing the potential for scar formation. Most leg lacerations do not have these characteristics, so using staples will often result in less aesthetic wound healing. Staples should not be used on the foot because they are uncomfortable when attempting to walk during recovery. Lacerations of the lower extremity can be under increased wound tension compared with other anatomic sites, so these lacerations are frequently repaired using tension­reducing techniques such as multiple­layered closure or horizontal mattress closure.
Repair is guided by the type of tissue injured. Subcutaneous fat is not sutured as even absorbable suture material will tear through fat based on the consistency of the tissue. The large muscle groups of the leg, particularly the quadriceps and the gastrocnemius complex, are somewhat superficial and thus are prone to lacerations. Laceration to the fascia overlying muscle should be repaired using absorbable suture. Small lacerations to
15­17 underlying muscle do not require repair, but larger lacerations to a muscle belly or the musculotendinous joint typically require operative repair.
LEG LACERATIONS
THIGH LACERATIONS
Proximal lower extremity lacerations are usually straightforward, and thickness of the soft tissue layers helps to prevent injury to vital structures.
Lacerations to the proximal lower extremity also have less tension on them, allowing for easier exploration, debridement, and repair. Assess lacerations to the proximal femoral area for injuries to the femoral artery, vein, and nerve. Acute traumatic femoral artery injuries are uncommon, but
 are associated with a high incidence of limb loss and morbidity.

Chainsaws can produce serious injury to the leg. Obtain additional historical information relating to this injury, including the size of the blade, the type of material being cut, and whether the patient fell into other debris once the laceration was sustained. Remove obvious foreign bodies or debris, and use copious irrigation during wound cleansing. Radiographs should be obtained to evaluate bony involvement in the injury as blade speed can lead to significant injury. Do not remove the blade if the patient arrives with it embedded in the muscle; removal should be done in the operating room to determine the location of the blade relative to the major arteries.
KNEE LACERATIONS
Close simple lacerations in the knee area with 4­0 nonabsorbable sutures, using interrupted or horizontal mattress sutures because of the marked active skin tension in this area. As already noted, assess for joint capsule penetration and laceration of the patellar and quadriceps tendons. The common peroneal nerve is prone to injury as it runs over the head of the fibula laterally, so distal limb motor function should be assessed (foot eversion and dorsiflexion). Deep popliteal wounds can injure the popliteal artery and tibial nerve. Popliteal artery injuries typically require emergent repair because, in most individuals, there is minimal collateral circulation at the level of the knee (Figure 44­4).
The knee should be splinted or placed in a knee immobilizer to decrease active tension and promote better wound healing. Knee area lacerations in children can be closed with tissue adhesives and splints to restrict movement.
PRETIBIAL LACERATIONS
Managing pretibial skin lacerations, especially in the elderly patient with comorbidities, is challenging. These wounds often occur on the distal third of
,20 the pretibial region, which is poorly vascularized and slow to heal. Pretibial wounds are approached according to the type and severity (Table 44­
,22
1).
TABLE 44­1
Pretibial Lacerations
Classification Description Management
Ia Simple linear laceration not under tension Primary closure with adhesive strips or sutures
Ib Simple linear laceration under tension Primary closure using methods to reduce skin tension
IIa Flap laceration with no skin loss and/or wound hematoma Close with adhesive strips
IIb Flap laceration with some necrosis and/or hematoma Excise small nonviable areas; close with adhesive strips
III Flap laceration with significant skin loss or necrosis Primary excision and skin grafting under local anesthesia
IV Degloving injury Plastic surgery consult
Wounds where the edges can be approximated without tension can be closed with adhesive tapes or simple sutures. Wounds with tension can be closed using horizontal mattress sutures with 4­0 nonabsorbable sutures. Occasionally, the 4­0 suture is too fine and cuts through the skin, so use 3­0 sutures. The natural contraction of the thin skin makes closure more difficult because sutures often cut through the fragile skin when attempting to approximate the wound edges. A technique to overcome this problem is to reinforce the wound edges with adhesive tape applied along the edges
23­25 before closure with placement of percutaneous sutures penetrating through the adhesive tape. Additionally, to minimize tension across the wound, tincture of benzoin can be applied over the sutures, and then broad adhesive tape strips (1/2 in.) can be placed over the sutures to minimize tension across the wound. Alternatively, the wound edges can be held in place by adhesive strips perpendicular to the wound, with sutures placed through the strips, thereby removing the shear force of the strip on the skin.
,22,26
Flap lacerations with significant skin loss are best repaired with primary excision and skin grafting. Apply a foam adhesive dressing (such as 3M
Tegaderm; 3M, St. Paul, MN) to absorb exudate and reduce healing time. Patients should remain ambulatory during the healing of pretibial injuries,
 even after skin grafting. Protecting the repair from the tension created by foot plantarflexion is useful; consider using a lightweight plastic ankle­foot
 orthosis.
FOOT AND ANKLE LACERATIONS
DORSAL FOOT AND ANKLE LACERATIONS
Dorsal surface lacerations are repaired almost exclusively with nonabsorbable, monofilament suture material, most commonly 4­0 or 5­0 for small lacerations. Use careful technique suturing the skin to avoid vessels, nerves, and tendons that lie just under the surface. Deep sutures are not recommended for the same reason. Running sutures are acceptable on the dorsal surface, and smaller lacerations may be closed with adhesive tapes or tissue adhesives. For lacerations under tension, consider applying a splint to restrict movement, allowing for healing during the first  to  days.
The decision to repair tendon lacerations in the foot depends on the functional impairment caused by the injury compared with the benefits of repair.
Many extensor tendon lacerations involving the mid­foot and forefoot can go unrepaired without compromising foot function. The skin is closed and the foot splinted, leaving the injured tendon alone. Lacerations of the extensor hallucis longus or tibialis anterior require consultation with an
 orthopedist or podiatrist because dorsiflexion of the great toe and foot is important in walking and running. Flexor tendon lacerations across the toes (excluding the great toe) can usually be left unrepaired without significant functional sequelae, but occasionally a hammer toe or claw toe
 deformity develops. Lacerations of the flexor hallucis longus are frequently repaired, although long­term benefit is unproven, even in athletes.
PLANTAR FOOT LACERATIONS
Repairing a laceration on the plantar surface is best done with the patient placed in a prone position, with the foot overhanging the cart or elevated by placing a pillow beneath the ankle. A large suture needle with thick thread is required to penetrate the hypertrophied epidermis and dermis of the sole of the foot. If there is tissue loss or the site is under tension, vertical mattress sutures may be required. In the arch area, achieving tissue eversion can be difficult. Do not use adhesive tapes, tissue adhesives, and staples on the plantar surface. Repair small plantar lacerations if the wound gapes open, but small or superficial wounds to the plantar surface where the edges approximate typically heal rapidly without sutures.
DIGITAL LACERATIONS
Digital lacerations may injure the nail bed, often accompanied by digital fractures. Clinical signs such as bleeding from the eponychium and a
 laceration proximal to the nail bed suggest a possible open fracture. Nail bed lacerations place the underlying bone at risk for bacterial contamination because the skin is directly attached to the periosteum with no intervening layer of subcutaneous tissue. Missed open fractures have resulted in osteomyelitis and growth delay of the digit in children. Consider removal of the nail to evaluate for nail bed laceration if a subungual
 hematoma occupies a large portion of the nail plate or if there is disruption of the nail or nail folds. Repair the nail bed with either absorbable
 sutures or tissue adhesives. Conversely, simple nail trephination is adequate for drainage of subungual hematomas without nail or nail fold deformities.
Tendon injuries of the digits may require consultation, especially when the extensor hallucis longus is involved, because injury to this tendon impairs functionality during the swing phase of the gait cycle. Surgery is often recommended for patients with extensor hallucis longus tendon lacerations, and grafting may be needed.
INTERDIGITAL LACERATIONS
Lacerations between the toes are difficult to repair because the confined interdigital space is difficult to access for suturing. An assistant gently separating the toes enhances exploration and repair of interdigital lacerations. Simple interrupted sutures often lead to skin inversion and risk of failure of the initial wound repair with interdigital lacerations. The more effective closure technique, albeit somewhat more difficult to perform, is to place horizontal or vertical mattress sutures. Use 5­0 monofilament nonabsorbable sutures on a small cutting needle. Use monofilament absorbable sutures in young children, thus avoiding suture removal. When a web space laceration involves the neurovascular bundle, the skin is usually closed without attempting to repair the neurovascular injury, followed by subsequent referral to a specialist.
HAIR­THREAD TOURNIQUET SYNDROME
Hair­thread tourniquet syndrome, also referred to as acquired constriction ring syndrome, is an unusual type of toe injury usually seen during infancy
33­35 and rarely seen in older children. A long strand of hair or thread becomes wrapped around a toe, often producing strangulation and digital ischemia. This can be an occult source of irritability for infants. Complete removal is required to restore perfusion and allow skin healing. Approaches to salvage the compromised digit are to either unwind the hair or thread, apply a chemical depilatory agent to dissolve the hair, or cut the hair or
,36 thread with suture removal scissors. If there is soft tissue swelling and the hair or thread is imbedded and not easily accessible, make a midline
 longitudinal incision along the extensor surface of the toe to cut the hair or thread. To cut the encircling material, it will often be necessary to split the fibers of the extensor ligament, but avoid transecting the fibers. The multiple strands of hair or thread are then removed using fine forceps without teeth.
After removal of the hair or thread, the toe often retains the initial appearance, making the physician uncertain whether all of the strands have been
 released. Hair­thread tourniquet syndrome can cause deep cutaneous lacerations that result in tendon lacerations requiring operative repair. Hair­
 thread tourniquet syndrome is not the result of intentional injury and does not warrant reporting as suspected child abuse.
DISPOSITION AND FOLLOW­UP
Most patients with lower extremity lacerations will be able to go home after ED evaluation and treatment. Patients at high risk for compartment syndrome, those with limited mobility and inadequate home assistance, and patients requiring operative repair should be admitted. Patients may require ancillary devices such as crutches, walkers, and wheelchairs. Elevation of the extremity decreases swelling and infection risk. Sutures are typically removed in  to  days.
Significant tendon lacerations of the lower extremity are usually repaired a few days to weeks after the initial injury. Treatment in the
ED consists of skin closure; splinting of the foot, ankle, or leg; initiation of prophylactic antibiotics; instruction for non–weight­bearing crutch use; and arrangement for the patient to follow up with an orthopedist or podiatrist.
SPECIAL CONSIDERATIONS
AGE CONSIDERATIONS
The preverbal child may have particular difficulty limiting movement of the injured extremity and is more likely to contaminate the wound. Generous dressings aid in protecting a lower extremity laceration according to the general rule, “the smaller the child, the larger the dressing.”
Elderly patients tend to have thin skin and decreased subcutaneous fat, especially over the pretibial surface, making wound edges more difficult to appose and resulting in closure under tension. Additionally, fragile skin in elderly patients predisposes sutures to tear through the skin. Adhesive tapes may be needed to reinforce the closure. Elderly patients are more likely to have medical conditions that can delay wound healing and are less likely to be adequately immunized against tetanus. Assess for fall risk and the ability to perform daily tasks after repair and immobilization of the injured leg.
TOE AMPUTATION
Reimplantation of a severed toe is not typically performed. Reattachment of an amputated great toe, forefoot, or entire foot is occasionally done, although it is extremely complex. Immediate consultation with a reimplantation surgeon is essential in such circumstances. Any severed part should be gently washed (not scrubbed) with sterile saline to remove gross debris, wrapped in saline­soaked gauze, and placed in a plastic bag that is then closed and placed in an ice water bath.
RETAINED FOREIGN BODIES
Retained nonreactive foreign bodies, such as glass, can cause chronic pain, especially during walking, if the material is not removed. In the absence of chronic discomfort, inert foreign bodies can remain in the foot, where they typically become encapsulated without causing injury or infection.
Conversely, reactive organic material does not become encapsulated and does promote infection. Therefore, reactive organic material should be aggressively identified and removed. Sonography or fluoroscopy may be useful to guide removal of foreign bodies. Deep foreign bodies in the foot can be extremely difficult to remove in the ED, and such cases are best referred to the surgeon for location and removal in the operating room.
PROPHYLACTIC ANTIBIOTICS
Although infection occurs in 3% to 8% of lower extremity lacerations, there is no evidence to support routine antibiotic prophylaxis in uncomplicated lacerations (see Chapter , “Postrepair Wound Care”). However, use prophylactic antibiotics for complicated lacerations in the setting of bites, open fractures, tendon or joint involvement, presence of foreign debris, and obvious infections. Diabetes and other predisposing medical conditions,
 wound contamination, and laceration length >5 cm are factors that predispose to wound infection.
Most lower extremity wound infections are due to either methicillin­sensitive Staphylococcus and/or Streptococcus species. Animal bites to the leg and foot require additional coverage for Pasteurella. Asplenic or immunocompromised patients who sustain a dog bite should receive coverage against
Capnocytophaga canimorsus. Amoxicillin­clavulanate will cover all four organisms (see Chapter , “Puncture Wounds and Bites”).
Staphylococcus and Streptococcus are the most common cause of soft tissue infections following plantar puncture wounds. Pseudomonas aeruginosa is a frequent cause of osteomyelitis and osteochondritis when the puncture occurs through the sole of a shoe (see Chapter 46).
Open fractures associated with wounds <10 cm in size without extensive soft tissue damage or contamination should receive antibiotic prophylaxis using cefazolin,  grams IV (alternatively clindamycin, 900 milligrams IV, if severe beta­lactam allergy), plus
 vancomycin,  milligrams/kg IV if there is known methicillin­resistant Staphylococcus aureus colonization. For open fractures with extensive soft tissue damage, antibiotic prophylaxis should use ceftriaxone,  grams IV, with metronidazole, 500 milligrams IV, added if soil or fecal contamination is present and vancomycin,  milligrams/kg IV, if there is known methicillin­resistant S. aureus
 colonization.


