## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 234: Clotting Disorders
Jessie G. Nelson
THROMBOPHILIA
COVID­19­Associated Coagulopathy June 2020
Critically ill patients with COVID­19 have significant coagulation abnormalities which can result in venous thromboembolism, ischemic stroke, myocardial infarction, and arterial thrombosis and embolism. Institutional and society guidelines for prophylactic and therapeutic anticoagulation are evolving rapidly and require close attention by emergency physicians.
INTRODUCTION
Most patients develop arterial or venous thromboses because of local factors (e.g., a focal atherosclerotic lesion producing a thrombus in a coronary artery) or major systemic events (e.g., trauma, surgery, or prolonged immobilization). However, several inherited genetic mutations and acquired conditions predispose patients to venous thromboembolism with some studies finding up to 50% of patients with unprovoked venous
 thromboembolism having a hypercoagulable disorder or thrombophilia (Table 234­1). No specific risk factor or condition guarantees abnormal thrombosis. Rather, similar to seizures, patients have a varying threshold for clotting. Risks for clotting from genetic, acquired, and environmental
 factors are additive and, in some cases, multiplicative.
TABLE 234­1
Hypercoagulable States
Inherited Acquired
Activated protein C resistance due to factor V Leiden Pregnancy mutation
Medications: Oral contraceptives/hormone replacement therapy, tamoxifen, lenalidomide
Prothrombin gene mutation 20210A Malignancy
Protein C deficiency Heparin­induced thrombocytopenia
Protein S deficiency Antiphospholipid syndrome
Antithrombin deficiency Warfarin­induced skin necrosis
Hyperhomocysteinemia, severe Hyperviscosity syndromes
ABO blood type (non­O) Human immunodeficiency virus (HIV)

Chapter 234: Clotting Disorders, Jessie G. Nelson 
PATHOPHYSIOLOGY
. Terms of Use * Privacy Policy * Notice * Accessibility
Several physiologic systems ensure that blood clots do not extend beyond the necessary area. The two most clinically important pathways involve antithrombin and protein C (Table 234­2). Antithrombin (also called antithrombin III) is a plasma­based protein that inhibits several activated coagulation factors, primarily thrombin, factor Xa, and factor IXa. Both unfractionated heparin and low­molecular­weight heparin possess anticoagulant activity by increasing the rate by which antithrombin inhibits these factors: approximately 2000­ to 4000­fold for thrombin, about 500­ to
1000­fold for factor Xa, and about a million­fold for factor IXa. Protein C is a vitamin K–dependent plasma protein that binds to the endothelial cell surface and is activated by thrombin. Activated protein C cleaves both factor Va and factor VIIIa, inhibiting both the common pathway and the intrinsic pathway. Protein S, another vitamin K–dependent plasma protein, is a cofactor that increases the inhibitory action of activated protein C by about 20­ fold.
TABLE 234­2
Functions of Coagulation Proteins in Protein C and Antithrombin Systems
Factor Function Pertinent Disorders
Prothrombin Precursor to thrombin, which converts fibrinogen to fibrin. Prothrombin mutations, 20210A and others
(factor II)
Factor V, Complexes with factor Xa, calcium, and phospholipid to convert prothrombin to Activated protein C resistance due to factor V activated thrombin. Leiden mutation
Protein C, Cleaves activated factors Va and VIIIa. Congenital protein C deficiency activated
Activated protein C resistance due to factor V
Leiden mutation
Neonatal purpura fulminans
Warfarin­induced skin necrosis
Protein S Cofactor for activated protein C. Congenital protein S deficiency
Cofactor for tissue factor pathway inhibitor (which inhibits extrinsic pathway of Neonatal purpura fulminans coagulation).
Counteracts factor Xa’s protection of factor Va from degradation. Warfarin­induced skin necrosis
Antithrombin Inhibits thrombin, factor Xa, and factor IXa. Antithrombin deficiency
Binds heparins, leading to increased antithrombin activity.
Phospholipids Present on cell membranes of endothelial cells that line blood vessels. Antiphospholipid syndrome
The activity of several proteins in the coagulation cascade is enhanced when bound to phospholipids.
DIAGNOSIS
Thrombophilic disorders are rarely diagnosed in the ED. Instead, the emergency physician’s primary responsibilities are to suspect the thrombophilia, recognize higher risk of thrombosis in patients with a known thrombophilia, obtain pertinent information to suspect an undiagnosed prothrombotic
 state, refer for evaluation, and appropriately manage acute thrombosis (Table 234­3).
TABLE 234­3
Features Suggestive of Thrombophilia
Early thrombosis (age  y and younger)
Recurrent thrombotic events or fetal loss
Family history of thrombosis or recurrent fetal loss
Thrombosis in unusual location (mesenteric, cerebral, axillary, or portal veins)

Laboratory testing specific for hypercoagulable conditions is not helpful in an ED setting. Some factor levels cannot be reliably measured in the setting of acute thrombosis or while the patient is taking a vitamin K antagonist such as warfarin or direct oral anticoagulants.
The ED diagnostic approach to individual episodes of suspected thrombosis in a thrombophilic patient is site specific (e.g., cerebral arterial or venous
 circulation, coronary circulation, or peripheral venous system). Recorded characteristics in the derivation samples for the Wells Score or Pulmonary

Embolism Rule Out Criteria excluded patients with known genetic causes for thrombophilia. Instead of risk stratification tools, use the patient’s personal history of venous thromboembolism (phenotypic evidence of thrombophilia). Using a normal serum D­dimer level to exclude venous thromboembolism in patients with known hypercoagulable disorders has not been validated.
TREATMENT AND DISPOSITION
Initial management and disposition of individual episodes of confirmed thrombosis in a patient with thrombophilia are similar to those of a patient
 without known thrombophilia, with exceptions discussed in specific conditions. Patients not currently on anticoagulation should consider prophylactic anticoagulants for high­risk situations such as surgery, pregnancy and the postpartum period, and prolonged travel. Estrogen­based oral contraceptive pills and hormone replacement therapy should be avoided in patients with known thrombophilia because of the thrombotic risk.
SPECIFIC CONDITIONS ASSOCIATED WITH THROMBOPHILIA INHERITED CLOTTING
DISORDERS
ACTIVATED PROTEIN C RESISTANCE (FACTOR V LEIDEN)
Activated protein C resistance caused by the factor V Leiden mutation is the most prevalent inherited hypercoagulable disorder; approximately 5% of
 the U.S. population of European descent is heterozygous for this mutation. In this disorder, the gene for factor V has a single point mutation that makes factor Va resistant to inhibition by activated protein C (factor V Leiden). This leads to overabundant conversion of prothrombin to thrombin.
Factor V Leiden is inherited in an autosomal dominant pattern, with most patients being heterozygous for the mutation. Heterozygotes for factor V
Leiden have a sevenfold increased risk of deep venous thrombosis compared with noncarriers, with homozygotes having a 20­fold increase in risk.

Factor V Leiden is more highly associated with deep vein thrombosis than pulmonary embolism and has been observed in up to 21% of patients with
 first­time deep venous thrombosis. Activated protein C resistance also produces pregnancy complications such as severe preeclampsia, placental abruption, fetal growth restriction, and stillbirth.
PROTHROMBIN GENE MUTATION
The most common mutation of the prothrombin gene (20210A) leads to increased prothrombin biosynthesis with about a 30% increase in circulating prothrombin levels, creating a prothrombotic state. Prothrombin mutations are inherited in an autosomal dominant manner, with mutations in the
 prothrombin gene present in about 2% of Caucasians. Heterozygotes account for up to 10% of patients with initial episodes of deep venous
 thrombosis. Patients with prothrombin gene mutation present with increased risk of venous thromboembolism and pregnancy complications, similar to activated protein C resistance from factor V Leiden.
DEFICIENCIES OF CLOTTING INHIBITORS
Antithrombin Deficiency
Several mutations to the antithrombin gene exist, many leading to antithrombin deficiency. Two percent of patients with a history of thrombosis have
 an antithrombin deficiency, and it is more prevalent in Asian populations. Antithrombin deficiency is classified into two main groups. In type , the measured level of antithrombin is diminished, whereas patients with type  have a normal amount of antithrombin, but the function is greatly diminished due to conformational changes in the protein. Antithrombin deficiency is inherited in an autosomal dominant fashion. Heterozygous patients have a fivefold increased risk of thrombotic events, typically pregnancy complications and venous thromboembolism. Homozygous antithrombin deficiency is incompatible with life.
Protein C and Protein S Deficiencies
Protein C and S deficiencies, like antithrombin deficiency, are transmitted in an autosomal dominant fashion, but with more varied clinical presentations. Prevalence can only be estimated, because not all patients with heterozygous defects develop inappropriate thrombosis. Heterozygous protein C deficiency is thought to be present in 1:250 to 1:500 people, and heterozygous protein S deficiency is estimated to occur in about 1:500
 individuals. Homozygous protein C or S deficiency is rare and presents as neonatal purpura fulminans. Patients with heterozygous protein C or S deficiency are at higher risk for venous thromboembolism, and like antithrombin deficiency, these disorders can be associated with either decreased total amount of protein C or S or decreased functional activity. In general, lower function is associated with higher risk and frequency of thrombotic events. Protein C and S deficiency, like antithrombin deficiency, is more prevalent in the Japanese and Chinese populations, with up to 32% percent of

Japanese adults with venous thromboembolism having a deficiency of protein C, protein S, or antithrombin.
Patients with heterozygous protein C or S deficiency are at higher risk for warfarin­induced skin necrosis because warfarin inhibits protein C and S synthesis. Warfarin­induced skin necrosis is rare and is prevented by both avoiding loading doses of warfarin and continuing heparin products until the INR is therapeutic. Therefore, any patient who develops warfarin­induced skin necrosis should be evaluated for protein C or S deficiency. Early
 evidence suggests direct oral anticoagulants are not as efficacious for protein S deficiency compared to other inherited thrombophilias.
OTHER INHERITED CONDITIONS
Hyperhomocysteinemia is associated with increased risk for various vascular diseases as well as venous thromboembolic disease, primarily through
 pathogenic effects of elevated homocysteine levels on vasculature. In recent years, mounting evidence exists showing an association between non­O
 blood groups (i.e., A, B, and AB) and a modest but statistically significant increased risk of both venous and arterial thromboembolic events. The pathogenesis of this interaction is incompletely understood.
ACQUIRED CLOTTING DISORDERS
PREGNANCY AND ESTROGEN USE

The coagulation changes in pregnancy (Table 234­4) represent an adaptive measure to prevent excessive hemorrhage with delivery. Many of these changes are anatomic in nature, whereas some are related to the relatively high estrogen state. These changes promoting thrombosis are similar but less profound in women taking oral contraceptives and hormone replacement therapy.
TABLE 234­4
Factors Contributing to Hypercoagulable State in Pregnancy
Anatomic Hematologic
Venous occlusion from gravid uterus. Increased thrombin generation from placental secretion of tissue factor
Trauma to pelvic veins during delivery.
Tissue injury during surgical delivery. Increased production of procoagulant proteins
Left iliac vein crosses over left iliac artery, leading to relative compression (left leg deep venous Decreased free and total protein C thrombosis is three times more likely than right in pregnant patients).
Increased platelet activation and platelet turnover
The exact mechanism of how exogenous estrogen therapy leads to a hypercoagulable state is complex and not completely understood, but high doses of estrogen clearly confer a higher risk for clotting. The current low doses for estrogens in oral contraceptives are associated with a smaller but still clinically significantly increased risk of thrombosis. Estrogen use has been associated with modest increases in several procoagulant proteins (factors
VII, VIII, and X, prothrombin, and fibrinogen) as well as decreases in anticoagulant proteins (antithrombin, protein S, protein C). Use of oral contraceptives or hormone replacement therapy in a patient with known heterozygosity for factor V Leiden puts the patient at an even higher risk for thrombosis, approximately a 15­fold increase.
MALIGNANCY
,18
Malignancy is associated with increased risk for thrombus formation, but the exact mechanisms are not completely understood. For patients with a new diagnosis of cancer, the risk of venous thromboembolism is highest in the first  months after diagnosis, with an odds ratio of about . Some types of cancers are more likely to promote thrombosis than others, with pancreatic, brain, acute myelogenous leukemia, gastric, esophageal, gynecologic, kidney, and lung cancers having the highest association with thrombosis. Cancer also increases the incidence of arterial thrombotic
 events, such as myocardial infarction and ischemic stroke. Other manifestations of hypercoagulability in cancer patients include chronic disseminated intravascular coagulation, nonbacterial thrombotic endocarditis, migratory superficial thrombophlebitis, and thrombotic microangiopathy. Chemotherapy itself can also affect coagulation in many ways, such as downregulation of proteins C and S, induction of tissue factor production by endothelial cells, and direct cell damage.
,19
Use low­molecular­weight heparin for the initial treatment of venous thromboembolism in patients with active cancer. Long­term anticoagulation
 following the diagnosis of venous thromboembolism in these patients uses low­molecular­weight heparin for  months as opposed to warfarin.
Evolving data indicate the effectiveness of direct oral anticoagulants; however, because of their increased risk of GI bleeding, it is suggested to avoid
,20 these agents in patients with GI malignancies. Prophylactic anticoagulation for primary prevention of venous thromboembolism in ambulatory
 medical oncology patients is not recommended.
HEPARIN­INDUCED THROMBOCYTOPENIA
Heparin­induced thrombocytopenia is a consumptive coagulopathy in which components of the clotting cascade are inappropriately activated,
 forming arterial and venous thrombus. Platelet factor  is a cell­signaling molecule that plays a central role in this syndrome. Platelet factor  neutralizes heparin and heparin­like endogenous compounds, and the heparin–platelet factor  combination inhibits local antithrombin activity, thereby promoting coagulation. Heparin­induced thrombocytopenia develops when patients develop antibodies against the heparin–platelet factor  complex. A complex of heparin, platelet factor , and the antibody binds to platelets, activating them. The platelets then form small microparticles that initiate clot formation. The measured platelet count falls because platelets are bound in both small and large clots. Also, the heparin–platelet factor  antibody complex can stimulate endothelial cells and monocytes to release tissue factor, which further stimulates the coagulation cascade.

The typical presentation of heparin­induced thrombocytopenia has the platelet count falling to ,000 to ,000/mm (50 to  ×  /L) within  to  days after starting heparin treatment. Despite the low platelet counts, the patient is hypercoagulable for days to weeks, even after heparin is stopped.
Rarely, patients can develop a rapid­onset presentation within hours of initiation of heparin. Case reports of heparin­induced thrombocytopenia­like
 illness without prior exposure to heparin products exist.
With more outpatients being treated with heparin products for venous thromboembolism or other thrombophilias, patients with heparin­induced thrombocytopenia may present to the ED with this syndrome. The diagnosis of heparin­induced thrombocytopenia hinges on laboratory findings and
 cannot be definitely diagnosed on clinical grounds alone. Thrombocytopenia is almost universally present (with the exception being patients with preexisting thrombocytosis). Suspect the syndrome when platelets have dropped approximately 50% from a recent value in a patient currently or recently taking a heparin product. All heparin products, both unfractionated and low­molecular­weight, must be stopped. These patients need
 anticoagulation because the risk for thrombosis is highest in the first week after diagnosis. Patients are typically treated with direct thrombin
 inhibitors (argatroban or bivalirudin) or indirect factor Xa inhibitors (danaparoid). Hematology consultation should be sought.
WARFARIN­INDUCED SKIN NECROSIS
Warfarin inhibits the production of vitamin K–dependent coagulation factors, with the serum levels of the individual factors decreasing according to their half­life. Upon initiation of warfarin, protein C is decreased before most of the procoagulant proteins. This decrease in protein C leads to a transient relative protein C deficiency, which can lead to clinically significant hypercoagulability.

Warfarin­induced skin necrosis presents with painful, red lesions usually located over the extremities, breasts, trunk, or penis. Lesions typically start with an initial central erythematous macule, extending over hours to a localized edema, developing central purpuric zones and then necrosis.
Thrombin inhibitors, such as low­molecular­weight heparin, are administered and continued until therapeutic anticoagulation is achieved with
 warfarin to prevent this complication. Rarely, warfarin­induced skin necrosis occurs despite appropriate heparin treatment. When it does, approximately one third of patients will prove to have an inherited protein C deficiency.
ANTIPHOSPHOLIPID SYNDROME
Antiphospholipid syndrome is an autoimmune disorder defined by the development of venous and/or arterial thrombosis and pregnancy morbidity in
 the presence of antiphospholipid antibodies. Many of the specific antibodies discovered have targets that are not phospholipids, but rather proteins that interact with phospholipids, such as prothrombin, protein C, and protein S. The most common specific antibodies associated with antiphospholipid syndrome are lupus anticoagulant, β ­glycoprotein I, and anticardiolipin antibodies. Lupus anticoagulant was initially discovered in
 patients with systemic lupus erythematosus and prolongation of the activated thromboplastin time; hence, the name lupus anticoagulant. However, in
 vivo, the lupus anticoagulant acts as a procoagulant and is associated with thrombosis.
Up to 5% of normal, healthy young people have antiphospholipid antibodies; this number increases with age and comorbid conditions, but only a minority of these patients develop antiphospholipid syndrome (40 to  per 100,000 persons). Antiphospholipid antibodies are positive in
 approximately 13% of patients with stroke, 11% with myocardial infarction, and .5% with deep venous thrombosis. As with most autoimmune disorders, antiphospholipid syndrome is more common in women and is diagnosed from a combination of laboratory findings and clinical findings
(Table 234­5).
TABLE 234­5
Clinical Manifestations of Antiphospholipid Syndrome
System Examples
Venous Deep venous thrombosis: extremities, cerebral, portal, hepatic, renal, retinal
Arterial Premature atherosclerosis
Acute coronary syndrome
Ischemic stroke
Vascular stenosis or occlusion: extremities, aorta, renal, retinal
Obstetric Fetal loss: often after 10­wk gestation
Preterm labor
Low birth weight
Preeclampsia
Neurologic Migraine
Sneddon’s syndrome—clinical triad of stroke, hypertension, and livedo reticularis
Cognitive dysfunction
Subcortical dementia
Chorea
Dysphagia
Guillain­Barré syndrome
Seizures
Optic neuritis
Skin Livedo reticularis
Cardiac Valvular abnormalities (Libman­Sacks endocarditis)
Syndrome X (angina­like chest pain, cardiac stress test positive for ischemia, normal coronary angiography)
Skeletal Osteonecrosis
Renal Thrombotic microangiopathy
Renal artery or vein thrombosis
Renal artery stenosis with hypertension
Pulmonary Pulmonary embolus
Pulmonary hypertension (from recurrent emboli)
GI Budd­Chiari syndrome (hepatic vein thrombosis)
Mesenteric ischemia
Hepatic infarction
Acalculous cholecystitis with gallbladder necrosis
Hematologic (other than thrombosis) Bleeding diathesis (rare)
Acquired hypoprothrombinemia
Thrombocytopenia
Hemolytic anemia
Catastrophic antiphospholipid syndrome Fulminant multisystem organ failure
Most patients with antiphospholipid syndrome have no predisposing conditions (primary antiphospholipid syndrome). A minority have conditions thought to be associated with their antiphospholipid syndrome (secondary antiphospholipid syndrome), such as rheumatologic or autoimmune disorders (systemic lupus), infections, and drug exposures (e.g., phenytoin, hydralazine, cocaine).
Although most patients with antiphospholipid syndrome present with isolated, recurrent thrombotic events, about 1% have a rapidly progressive form known as catastrophic antiphospholipid syndrome, representing acceleration in the pathophysiologic processes of antiphospholipid syndrome with
 widespread small­vessel occlusions in multiple organs. Common triggers for the catastrophic course include infection, surgery, oral anticoagulant withdrawal, oral contraceptive use, obstetric complications, and cancer. However, 40% of the time, no obvious trigger can be found. Mortality of catastrophic antiphospholipid syndrome is approximately 50% despite treatment.
Obviously, antiphospholipid syndrome patients with recurrent thrombotic events need lifelong anticoagulation. Pregnant women with antiphospholipid syndrome need anticoagulation with subcutaneous unfractionated or low­molecular­weight heparin or low­dose aspirin therapy.
Because many normal healthy patients have antiphospholipid antibodies, prophylaxis without a personal history of thrombosis is not recommended.
In the rare event of catastrophic antiphospholipid syndrome, a multipronged approach involving anticoagulation, steroids, immunosuppressive
 therapy, plasmapheresis, and/or IV immunoglobulin is typically used.
HYPERCOAGULABILITY ASSOCIATED WITH OTHER DISORDERS
Many other conditions are associated with increased risk of clotting. Patients with nephrotic syndrome have an increased risk of hypercoagulability for complex reasons. In several cases, this is simply a matter of increased urinary excretion of anticoagulant proteins. The nephrotic syndrome can also lead to increased endothelial injury and platelet aggregation. Patients with several forms of vasculitis, such as Behçet’s syndrome, antineutrophil cytoplasmic antibody–associated vasculitis, and granulomatosis with polyangiitis, have a slightly increased risk of thrombosis. Hyperviscosity syndromes, such as essential thrombocythemia, polycythemia vera, Waldenström’s macroglobulinemia, multiple myeloma, and sickle cell disease, also place patients at increased risk for thrombosis. Most risk factors for cardiovascular disease, such as obesity and diabetes, are also risk factors for
 venous thromboembolism to varying degrees. Diabetes alone slightly increases the risk for thrombosis in younger patients without other obvious
 risks for thrombosis. Patients with human immunodeficiency virus have a 2­ to 10­fold increased risk for venous thromboembolism compared to
 the general population.
COVID­19 ASSOCIATED COAGULOPATHY
Novel coronavirus (SARS­CoV­2) infection leading to COVID­19 was initially recognized in December 2019 and was declared a pandemic just four months later. While the majority of presenting symptoms relate the pulmonary dysfunction, significant coagulation laboratory and clinical
 abnormalities have been described. In a study of 184 ICU patients with COVID­19, 49% were found to have venous thromboembolism, ischemic
 stroke, myocardial infarction, and/or systemic arterial thrombosis and embolism. Critically ill patients with COVID­19 have a much higher incidence of venous thromboembolic disease compared to similar patients without COVID­19 despite prophylactic or therapeutic anticoagulation (11.7% compared
 to .1%). This correlation between COVID­19 and excess coagulation is being called COVID­19­associated coagulopathy or COVID­19­induced coagulopathy.
The COVID­19 pandemic shines a spotlight on the interplay between the immune and coagulation systems, a process termed thromboinflammation.

The ACE2 receptor, a target of the SARS­CoV­2 virus, is found in the endothelium, in addition to the lungs, heart, kidney, brain, and gut. Endothelial
 cells, of which 98% lie in the microvasculature, serve as a critical regulator of thromboinflammation. For example, bacterial endotoxin stimulates tissue factor expression and blocks fibrinolysis, changing the normally anticoagulant endothelial surface to a more procoagulant state. Platelets serve important roles in the immune response to microbes as well, binding to many different microbes directly, and interacting with leukocytes for pathogen
  clearance. Decline in platelet counts often portend a worse outcome in critically ill patients. Elevated D­dimers correlate with increasing severity of

COVID­19 disease, and patients with very elevated D­dimers have improved 28­day mortality when treated with low­molecular­weight heparin.
COVID­19 has potent inflammatory and coagulation effects. Emergency physicians need to strongly consider thrombosis, particularly pulmonary embolism, in seriously ill patients with suspected or confirmed COVID­19. Patients being admitted for COVID­19 should have D­dimer levels checked, as elevations predict more severe disease and may guide hospital
 anticoagulation management. Interim guidelines for anticoagulation for hospitalized patients are developed and are evolving rapidly. All hospitalized patients should receive at least prophylactic anticoagulation. Hospitalized patients with diagnosed thrombosis should be treated with usual therapeutic dosing. However, little guidance currently exists for anticoagulation management of the patient being discharged from the emergency department. Emergency physicians may need to consider prophylactic anticoagulation in carefully selected patients being discharged from the ED, taking into account the patient’s medical history for other procoagulant conditions, ability to be safely monitored in the outpatient setting, and available resources during the COVID­19 pandemic.


