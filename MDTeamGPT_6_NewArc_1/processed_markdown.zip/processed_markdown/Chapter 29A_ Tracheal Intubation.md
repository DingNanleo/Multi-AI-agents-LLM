University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 29A: Tracheal Intubation
Henry E. Wang; Jestin N. Carlson
INTRODUCTION
Content Update: Content Update: Preoxygenation with BiPAP October 2024
In the presence of hypoxemia, preoxygenation with BiPAP before intubation can result in lower rates of hypoxemia during intubation compared to facemask oxygen alone. See discussion in OROTRACHEAL INTUBATION – Preoxygenation.
Content Update: Airway Management in the COVID­19 Patient June 2020
Respiratory distress and hypoxemia can be critical complications of COVID­19. Key issues and recommendations for management are presented at the end of Chapter 19A, in the section entitled Oxygenation, Ventilation and Intubation in the patient with COVID­19. Tracheal intubation is a cornerstone of emergency airway management, creating a direct conduit to the trachea, allowing airway patency, aiding oxygenation and ventilation, and preventing aspiration. Intubation may also be needed to safely allow sedation or paralysis needed in critically ill patients requiring diagnostic or therapeutic interventions. Intubation is one component of the spectrum of emergency airway interventions.
Supraglottic airways and the conversion of a supraglottic airway to an endotracheal tube (ETT) are discussed in Chapter , “Noninvasive Airway
Management and Supraglottic Airways.”
PREPARATION
Proper preparation is key to successful intubation. Table 29A­1 lists emergency airway equipment needed at the bedside before beginning intubation. Have basic airway, intubation, rescue, and surgical airway equipment immediately accessible, ideally in the same cart with other airway management equipment. If treating a child, have enough and appropriately sized pediatric airway devices accessible (see Chapter 113, “Intubation and
Ventilation in Infants and Children”).
TABLE 29A­1
Equipment Needed for Airway Management
Oxygen source and tubing
Ambu bag
Mask with valve, various sizes and shapes
Oropharyngeal airways—small, medium, large
Nasopharyngeal airways—small, medium, large
Suction catheters: Yankauer, tracheal suction catheters, nasogastric suction connection tubing for particulate and large amounts of vomitus
Suction source
Pulse oximetry
Carbon dioxide detector
Endotracheal tubes—various sizes
DownloadeLda r2y0ng2o5s­c7o­p1e  b:l4a1d ePs a Yndo huar nIPdl eiss 136.142.159.127
Chapter 29A: Tracheal Intubation, Henry E. Wang; Jestin N. Carlson 
Syringes
. Terms of Use * Privacy Policy * Notice * Accessibility
Magill forceps
Stylets, assorted
Tongue blade
Intubating stylet (gum elastic bougie)
Water­soluble lubricant or anesthetic jelly
Rescue devices: video laryngoscopes, laryngeal mask airway, intubating laryngeal mask airway, i­Gel (Intersurgical Inc., Liverpool, NY), King LT® (King
Systems, Noblesville, IN)
Surgical cricothyroidotomy kit
Medications for topical airway anesthesia, sedation, and rapid­sequence intubation
Key starting tasks are imperative: Ensure ongoing cardiac rhythm monitoring with continuous displays of the heart rate, blood pressure, SaO , and
 end­tidal capnography. Establish IV access and appropriate fluids.
Raise the patient to the level of the operator’s xiphoid (Figure 29A­1). Although ventilation and intubation are typically performed with the patient fully supine, positioning the patient so that the external ear is aligned with the sternal notch may improve glottis visualization (Figure 29A­2). Refrain from applying padding under the shoulders or neck as this position is suboptimal for facilitating emergency intubation. A more upright position for intubation may be necessary if the patient cannot lay supine—for example, the patient with severe pulmonary edema or morbid obesity (Figure 29A­
3).
FIGURE 29A­1
Correct patient­stretcher height, so that the patient’s head is just below the intubator’s xiphoid. [Reproduced with permission from Knoop K, Stack L,
Storrow A, Thurman RJ: Atlas of Emergency Medicine, 4th ed. © 2016, McGraw­Hill, Inc., New York. Figure .14. Photo contributor: Lawrence B. Stack,
MD.]
FIGURE 29A­2
Patient positioning for optimal laryngoscopy. Align the external auditory canal and the sternal notch. [Reproduced with permission from Knoop K,
Stack L, Storrow A, Thurman RJ: Atlas of Emergency Medicine, 4th ed. © 2016, McGraw­Hill, Inc., New York. Figure .10 Part C. Photo contributor:
Lawrence B. Stack, MD.]
FIGURE 29A­3
An upright position may be necessary for intubation of select patients. [Reproduced with permission from Knoop K, Stack L, Storrow A, Thurman RJ:
Atlas of Emergency Medicine, 4th ed. © 2016, McGraw­Hill, Inc., New York. Figure .6. Photo contributor: Lawrence B. Stack, MD.]
Ensure that the oxygen source and regulator are functional. Have a bag­valve­mask ventilator and oral and nasal airways at the bedside, and make sure that a large­diameter suction catheter and functional suction unit are ready. For potential uncontrolled emesis, use an assistant to place a Yankauer catheter or the suction tubing itself in the side of the mouth, so suctioning can be done throughout the intubation process. Another option for largevolume suction or in instances where suction is required to remove large particles of material (e.g., food debris) is to use another ETT attached to
,2 suction tubing, placing it to the left oropharynx to allow continuous large­volume suction (suction­assisted laryngoscopy airway decontamination)
(Figure 29A­4).
FIGURE 29A­4
Suction­assisted laryngoscopy airway decontamination (SALAD) approach for suctioning. A. SALAD set up. B. View of suction in the esophagus.
Verify the function of primary and backup intubation equipment, including laryngoscope blade, bulbs, and video laryngoscope screens. Test the cuffs of selected ETTs, usually the size you think is best and one smaller. Verify the availability of rescue supraglottic airways and surgical airway kits.
Confirm that a mechanical ventilator is available for application immediately after intubation. Estimate the patient’s body mass and calculate appropriate doses of any adjunctive intubation medications.
Before proceeding with intubation, assess all available clinical information, including the patient’s suspected condition, history, anatomy, physiology, and goals of care. Develop an emergency airway management plan—one that anticipates failure and has alternative options—and review this plan with the entire care team. Discuss the plan for preparation, medications, intubation, postintubation sedation, and rescue airway management. A checklist
 may facilitate decision making and reduce errors.
Try to normalize patient heart rate and blood pressure, and try to optimize SaO prior to drug administration and laryngoscopy; peri­intubation
 cardiac arrest is likely if any of these parameters is abnormal. Anticipate airway difficulty; if anatomic abnormalities will impede basic airway techniques or will not improve with rapid­sequence intubation, consider awake intubation.
AIRWAY ASSESSMENT

Approximately up to 15% of initial emergency airway attempts and 1% to 3% of overall attempts at tracheal intubation fail with standard techniques. It is best to expect difficulty with all emergency airway cases, applying a uniform approach to all patients. While the terms difficult intubation and difficult laryngoscopy are often used interchangeably, there are important distinctions. Difficult intubation refers to a situation where multiple attempts are made at intubation, whereas difficult laryngoscopy refers to challenges with or inability to visualize the glottis. Factors associated with airway management and intubation difficulty are listed in Table 29A­2. TABLE 29A­2
Factors Associated With Airway Management Difficulty
Obesity
Facial hair
Edentulous anatomy
History of snoring/sleep apnea
Short neck
Limited neck mobility
Small or large chin
Prominent incisors
High arched palate
Facial or airway trauma
Head and neck tumors
Angioedema
Ludwig’s angina
Inflammation of the airway (e.g., airway burns)
Obesity or the lack of neck flexibility may make it difficult to align the oral, pharyngeal, and tracheal axes needed for intubation. Physical airway obstruction (foreign body, tumor, angioedema, epiglottitis) may limit the physician to nasal techniques or a surgical airway (see Chapter , “Surgical
Airways”). Some anesthesia scales associate anatomical features with intubation difficulty; for example, Mallampati criteria relate the degree of
 posterior pharyngeal obstruction by the tongue with intubation difficulty (Figure 29A­5). Although potentially applicable to some ED patients, in select situations, formal airway assessment may be impractical or impossible.
FIGURE 29A­5
The Mallampati score. [Reproduced with permission from Samsoon Y: Difficult tracheal intubation: a retrospective study. Anaesthesia 42: 487­490,
1987.]
OROTRACHEAL INTUBATION
PREOXYGENATION

Oxygen desaturation to <70% is associated with increased risk of dysrhythmias, decompensation, and cardiac arrest. Preoxygenation displaces nitrogen from the alveoli, creating a potential oxygen reservoir that may prevent hypoxia and hypoxemia during apnea. In the healthy operating room patient, preoxygenation increases safe apnea time (time to desaturation to <90%) from  to  minutes. However, in critically ill patients such as those with chest injuries or shock states, safe apnea time is shorter.
Begin preoxygenation as soon as possible before intubation, even for patients with no apparent hypoxia or hypoxemia. Administer 100% oxygen for at least  minutes using a non­rebreather mask supplied with at least  L/min of oxygen. Non­rebreather masks typically deliver 60% to 70% oxygen.
Higher oxygen delivery is possible by increasing the oxygen regulator to its maximum “flush” rate, which will provide 90% to 97% oxygen, between 
 and  L/min.
If unable to achieve SaO > 95% with spontaneous breathing, consider the use of bag­valve­mask ventilation, application of a PEEP valve, or the use of

CPAP/BiPAP. Preoxygenation with >3 minutes of BiPAP (expiratory pressure of >5 cm H O and an inspiratory pressure of >10 cm H O, respiratory rate of

>10/minute) results in lower rates of hypoxemia (SaO <85%) during intubation compared to facemask oxygen alone. This strategy should not be
 utilized in patients who are apneic or hypopneic or who require immediate intubation. Preoxygenation must occur with tidal volume breathing and/or a good mask seal. See Chapter  for more details of noninvasive ventilation. Apneic oxygenation (through standard nasal cannula, high­flow nasal
 cannula, or other nasopharyngeal catheters) before and during laryngoscopy may reduce the risk of desaturation. Elevating the head of the patient
20–30 degrees may improve preoxygenation. With agitated patients, some clinicians selectively use sedation with induction agents to facilitate
 preoxygenation.
Nasal cannulas with low flow alone do not provide optimal preoxygenation. However, some clinicians use apneic oxygenation—oxygen at ≥15 L/min
 via nasal cannula—concurrently with bag­valve­mask (or BiPAP) ventilation and subsequent laryngoscopy. During laryngoscopy, the continued high oxygen flow creates a pressure gradient, facilitating airflow from the pharynx to the lungs.
PROCEDURE
Table 29A­3 summarizes the steps of tracheal intubation. The objective of laryngoscopy is to align the oral, pharyngeal, and laryngeal axes to provide an unobstructed direct view of the glottis and allow passage of the ETT between the vocal cords (Figure 29A­6). (See Video: Orotracheal Intubation.)
Video 29­1: Orotracheal Intubation
Used with permission from David Cline and Henderson McGinnis, Department of Emergency Medicine, Wake Forest University School of Medicine, Winston­Salem,
North Carolina.
Play Video
TABLE 29A­3
Steps of Tracheal Intubation
Step Comments
. Clear the oropharynx. Remove dentures and any obscuring blood, secretions, or vomitus. Suction airway clear.
. Hold laryngoscope in left Hold the laryngoscope at the base, where the blade inserts to the handle.
hand.
. Use right hand to: Use a scissor motion to open the mouth and facilitate laryngoscope passage by pressing caudally on the patient’s lower
Open the mouth. incisors with the operator’s thumb and cranially on the patient’s upper incisors with the operator’s index finger.
Operate suction catheter. Use a properly sized stylet to assist with tube placement. The tip of the stylet must not extend beyond the end of the ETT
Manipulate larynx to or exit the Murphy eye.
enhance visualization.
Insert the ETT.
. Insert blade into the right Use the vertical flange of the curved Macintosh blade to push the tongue toward the left side of the oropharynx.
corner of the patient’s mouth.
Carefully advance blade into oropharynx.
Lift and hyperextend the head.
. Visualize and lift the Lift the epiglottis directly with the straight blade (Miller) or indirectly with the curved blade (Macintosh).
epiglottis.
. Visualize vocal cords Look for the arytenoid cartilages to avoid overly deep insertion of the blade, which is a common error. BURP maneuver
(arytenoids). may improve visualization.
. Advance ETT. Visualize tube and cuff passing through vocal cords.
Correct tube placement is a minimum of  cm above the carina (approximately  cm at the incisors in men and  cm in women).
. Inflate balloon. Use 5–7 mL of air. Check cuff pressure to avoid tracheal injury from pressure (target 25–40 cm H O).

. Confirm ETT placement. Listen for bilateral breath sounds and the absence of epigastric sounds.
Confirm placement with capnography or colorimetric carbon dioxide detector.
. Secure ETT. Use commercial tube holder, adhesive tape, or umbilical tape.
Abbreviations: BURP = backward­upward­rightward pressure; ETT = endotracheal tube.
FIGURE 29A­6
Alignment of oral, pharyngeal, and laryngeal axes during intubation.
Select the appropriate­size ETT: .0­ to .5­mm inner diameter for an average adult male and .5­ to .0­mm inner diameter for an adult female. Check the cuffs for air leaks with a 10­mL syringe. Choose an ETT with a high­volume, low­pressure cuff. The second hole at the end of the ETT (Murphy eye) permits some uninterrupted airflow if the tip is occluded. Insert a lightly lubricated stylet to aid ETT direction and placement.
The Macintosh and Miller blades are most commonly used in direct laryngoscopy. The curved Macintosh blade tip is placed in the vallecula to indirectly lift the epiglottis off the larynx. The straight Miller blade physically lifts the epiglottis to visualize the larynx. Blade selection is a matter of personal preference. Be sure to test the light on the laryngoscope after attaching the appropriate­size blade (Figure 29A­7).
FIGURE 29A­7
A. Curved or Macintosh blade. B. Straight or Miller blade.
With the curved Macintosh blade, choose a #3 for most adults or a #4 for larger patients. Holding the laryngoscope with the left hand, insert the curved blade deeply into the far right side of the patient’s mouth. Use the broad vertical flange to sweep the tongue to the left while simultaneously placing the blade tip in the vallecula. Apply pressure upon the vallecula via the hyoepiglottic ligament to facilitate elevation of the epiglottis and exposure of the vocal cords. Lift upward to flex the lower neck and extend at the atlanto­occipital joint. The goal is to align the oral, pharyngeal, and laryngeal axes, facilitating a direct view of the glottis. Laryngoscopy should be performed in a single fluid motion.
With the straight Miller blade, choose a #3 for most adults. Insert the straight blade at the far right side of the mouth at an angle, aiming to expose and lift the glottis in a single motion. Bring the handle to midline, using the broad part of the blade to lift the tongue.
Optimal intubation occurs with a full, unobstructed view of the glottis. Often, no matter what blade chosen, the glottis is not seen; a common error is inserting the tip of a blade too deep. Withdraw the blade slowly and slightly; the glottis often “drops” into view. If the glottis and vocal cords are not seen clearly, esophageal tube placement is more likely. Anesthesiologists characterize glottic exposure using the Cormack­Lehane system; grade 
 reflects a fully exposed glottic view, and grade  reflects the inability to visualize any of the vocal cord (Figure 29A­8). The percentage of glottic
 opening provides an alternate glottic visualization rating from 0% to 100%. Abort the attempt if you cannot visualize the larynx.
FIGURE 29A­8
Cormack­Lehane scale for rating glottic exposure. [Reproduced with permission from Stone CK, Humphries RL, Drigalla D, Stephan M (eds): Current
Diagnosis & Treatment: Pediatric Emergency Medicine. McGraw­Hill Education, Inc. © 2015. Figure 9­6.]

Glottic exposure may be aided by backward­upward­rightward pressure (BURP maneuver) applied to the thyroid cartilage. Another effective technique is bimanual laryngoscopy, where the intubator manipulates the larynx with the right hand until ideal visualization and then an assistant
 maintains this position. The Sellick or cricoid maneuver (application of direct pressure on the cricoid ring) can hamper bag­valve­mask
 ventilation, laryngoscopic view, and ETT insertion.
Where there is concern for cervical spine fracture or injury, use in­line stabilization of the cervical spine without extension of the head or neck during laryngoscopy. This stabilization may make laryngoscopy and glottic exposure more difficult; because of this, some experts question the utility
 of manual inline stabilization and wonder if it really affords adequate spinal cord protection.
Gently insert the ETT through the glottis, inflate the cuff, and remove the stylet. The typical correct tube insertion depth is  cm, measured at the patient’s incisors. Difficulties in passing the ETT may result from the failure to maintain optimal laryngoscopic view, selecting too large a tube, applying cricoid pressure, or suboptimal shaping of the ETT stylet. Switching to a smaller tube, altering the curve of the stylet, and rotating the tube  degrees to align the bevel with the glottic opening are other techniques for facilitating ETT insertion.
,16
Multiple intubation attempts are associated with adverse events including cardiac arrest. To minimize oxygen desaturation, limit each intubation attempt (insertion of blade) to no more than  seconds. Between intubation attempts, use a bag­valve mask to reoxygenate the patient to 100% SaO .

For anyone in extremis or with anticipated difficulty, first­pass success is more vital; have the most experienced person perform intubation in these situations.
The gum elastic bougie (“bougie”) introducer aids orotracheal intubation, especially when the glottis cannot be fully visualized (Figure 29A­9).
After laryngoscopy and best exposure of the vocal cords, insert the angled tip of the bougie through the glottis. When correctly inserted, you may feel the bougie tip moving over the tracheal rings. Thread the ETT over the introducer into the trachea, inflate the ETT cuff, and then remove the
 introducer. First­pass success is higher with bougie­assisted intubation. Never force the tube through the vocal cords, which can avulse the arytenoid cartilages or lacerate the vocal cords.
FIGURE 29A­9
Gum elastic bougie.
CONFIRM ENDOTRACHEAL TUBE LOCATION
Mainstem bronchial or esophageal intubation may cause hypoxia, hypoxemia, hypercarbia, bradycardia, and cardiac arrest. Confirm intratracheal tube positioning with multiple methods; no single technique is infallible. Although directly visualizing the tube between the vocal cords is the best method for confirming successful placement, trauma or a small oropharynx may limit visual assessment. Other clinical assessments include chest and epigastric auscultation and observation for tube condensation or symmetric chest wall expansion.
Capnometers and capnographs measure carbon dioxide in expired air of the ETT (Figure 29A­10). The presence of carbon dioxide suggests intratracheal tube placement. The absence of carbon dioxide suggests ETT misplacement. Colorimetric end­tidal carbon dioxide detectors have a pH­ sensitive filter paper that changes color from yellow to purple with carbon dioxide exposure. Capnography measures expired carbon dioxide in real time, displaying either the peak value with each breath or continuous graphical waveforms. Clear, regular waveforms or carbon dioxide measurements
>30 mm Hg correlating with exhalations suggest proper ETT placement. Rarely, a misplaced hypopharyngeal glottic tube tip may result in normal oximetry and capnography in a spontaneously breathing patient. In cardiac arrest states, expired carbon dioxide will be low due to poor perfusion; continuous capnography waveforms may still be detectable in these cases. Table 29A­4 notes conditions associated with false colorimetric or capnographic carbon dioxide readings.
FIGURE 29A­10
End­tidal carbon dioxide detectors. A. Colorimetric. B. Combined digital and waveform.
TABLE 29A­4
Conditions Associated With False Colorimetric or False Capnographic Carbon Dioxide Readings
False­Negative Reading
Low pulmonary perfusion—cardiac arrest, inadequate chest compressions, massive pulmonary embolism, shock
Massive obesity
Tube obstruction (secretions, blood, foreign body)
False­Positive Reading
Recent ingestion of carbonated beverage (should not persist beyond  breaths)
Heated humidifier, nebulizer, or endotracheal epinephrine (transient false readings)
The esophageal detection device may also indicate ETT placement. When the ETT is in the esophagus, the soft, noncartilaginous walls will collapse, and air cannot be easily aspirated with an esophageal detector. Esophageal detection devices use either syringe aspiration or a compressible bulb technique. If the ETT tube is in the esophagus, the vacuum causes the esophagus to collapse around the tube, creating resistance to aspiration or preventing the bulb from refilling. Conversely, syringe aspiration or bulb refilling is rapid when the ETT is in the trachea.
,19
Recent studies suggest ultrasonography as an alternate technique for confirmation of intratracheal ETT placement. Position the US probe cephalad to the cricoid membrane, just above the sternal notch (Figures 29A­11 and 29A­12). The ETT should be visualized within the lumen of the trachea. The visualization of two separate structures (“double track sign”) likely indicates esophageal intubation. Some operators inflate the ETT cuff with water to improve its visualization on ultrasonography.
FIGURE 29A­11
Use of ultrasonography for confirmation of tracheal tube placement. [Reproduced with permission from Reichman EF (ed): Reichman’s Emergency
Medicine Procedures, 3rd ed. © 2019, McGraw­Hill, Inc., New York. Figure 19­7.]
FIGURE 29A­12
A and B. Ultrasonographic view of intratracheal (left) and esophageal (right) endotracheal tube placement. [Images used with permission of Jordan
Chenkin, MD.]
A chest radiograph is customarily obtained after intubation to verify correct vertical positioning of the ETT. However, a chest radiograph does not reliably distinguish ETT placement in the trachea from the esophagus. Other important postintubation radiograph findings include the presence of a pneumothorax and consolidations suggestive of pneumonitis (due to aspiration or infection).
Never assume correct ETT positioning and patency if the patient is deteriorating after intubation. Suctioning may help to clear secretions from obstructing the tube. If the ETT cuff leaks after the intubation, check the inflation valve. If the tube needs to be replaced, use a tube changer or bougie; insert the changer into the ETT, withdraw the ETT, and then insert a new ETT over the catheter and reconfirm placement. If in doubt about its position, withdraw and replace the ETT or restart bag­valve­mask assistance.
After successful intubation, secure the ETT to prevent device dislodgement during subsequent patient care. Tube displacement can occur during patient movement or any care if not properly secured. During EMS transfer of the patient into the stretcher, have an assistant hold the ETT in place during the transfer. Once the patient is stabilized, the most common approach to securing the ETT is wrapping adhesive tape around the neck
 and the ETT (Lillehei method). Flat umbilical “twill” cloth tape may also be used to tie the tube in place. Commercial tube holders consist of a plastic bite block strapped to the patient’s face using Velcro tape and a plastic strap or screw clamp to hold the ETT in place. One cadaver study found that
 conventional adhesive taping surpassed most commercial ETT holders. Finally, if not already done, place an orogastric tube and connect it to suction.
COMPLICATIONS OF ENDOTRACHEAL INTUBATION
Many complications can be avoided with preparation (Table 29A­5). Although some events are directly associated with the procedure (e.g., ETT misplacement), other indirect events are also important (e.g., hyperventilation and CPR interruption). Be especially vigilant for peri­intubation
21–23 hypotension and cardiac arrest, which occur after 23% and 4% of ED intubations, respectively. Some advocate for bolus­dose or ‘push­dose’ vasopressors to mitigate hypotension. However the ideal pressor and dose is not yet evidence­based. See Chapter , Pharmacology of Vasopressors and Inotropes, ‘Bolus­Dose Administration of Vasopressors’ and Table 20­1 for further discussion.
TABLE 29A­5
Complications of Endotracheal Intubation, Preventive Strategies, and Potential Corrective Actions
Complication Preventive Strategies Corrective Action
ETT misplacement View ETT entry through glottis Quick recognition. Remove and replace ETT.
ETT dislodgement Secure ETT, minimize patient movement, use continuous Quick recognition. Remove and replace ETT.
capnography
Mainstem intubation View ETT entry through glottis, know appropriate ETT depth Quick recognition. Adjust ETT position.
Oxygen desaturation Preoxygenate patient prior to intubation Verify ETT position. Clear ETT. Hyperventilate.
Hypotension Ensure adequate blood pressure before intubation efforts, Place patient in Trendelenburg position. Give IV minimize use of medications known to induce hypotension fluids. Give pressors. Avoid hyperventilation.
Bradycardia Ensure adequate heart rate before intubation efforts Hyperventilate. Give atropine or epinephrine.
Cardiac arrest Ensure adequate heart rate, blood pressure, SaO before Initiate CPR.
 intubation efforts
Aspiration Avoid aggressive BVM ventilation, keep patient upright before Large­bore suction or oropharynx and ETT.
intubation
Injury to oropharynx or Careful laryngoscopy hypopharynx
Pneumothorax Careful laryngoscopy, avoid aggressive BVM ventilation Insert chest tube or pigtail.
Gastric/visceral perforation Careful laryngoscopy, avoid aggressive BVM ventilation
Vocal cord injury Careful laryngoscopy, careful ETT placement
ETT cuff leak Check cuff before intubation, avoid rubbing cuff against teeth Remove and replace ETT.
ETT obstruction (secretions, Suction oropharynx before intubation efforts Suction ETT. Clear obstruction.
vomitus, foreign body)
Hyperventilation Judicious control of manual ventilations
Interruptions in CPR chest Minimize CPR interruptions during intubation, use a supraglottic compressions airway instead of ETT
Failed intubation/Inability Anticipate and plan for intubation difficulty Immediate rescue with supraglottic or other airway.
to intubate
Abbreviations: BVM = bag­valve mask; ETT = endotracheal tube.
RAPID­SEQUENCE INTUBATION
Rapid­sequence intubation (RSI) is the sequential administration of an induction agent and neuromuscular blocking agent to facilitate endotracheal intubation (Table 29A­6). The goal of RSI is to facilitate rapid insertion of the ETT while minimizing physiologic perturbations. RSI is superior to sedation alone, allows the highest intubation success rate in properly selected emergency airway cases, and is the method of choice for emergency airway management.
TABLE 29A­6
Rapid­Sequence Intubation Steps
Discuss airway management strategy with the team.
Set up IV access, cardiac monitor, oximetry, and capnography/capnometry.
Plan procedure. Assess physiologic status and airway difficulty.
Prepare equipment, suction, and potential rescue devices.
Preoxygenate.
Consider pretreatment agents.
Give sedative agent immediately followed by neuromuscular blocking agent.
Intubate trachea.
Confirm tube placement.
Secure tube.
Adjust mechanical ventilation and provide postintubation sedation.
Not all patients are best managed with RSI. Patients who are deeply comatose or in cardiac or respiratory arrest may be intubated without pharmacologic assistance. Relative contraindications to RSI include anticipated airway management difficulty and clinical scenarios where muscle relaxation will not improve laryngeal exposure (e.g., massive edema, immobile jaw from injury or infection, oral tumors or obstruction). Always be prepared for failure and have rescue airway plan and equipment ready.
PRETREATMENT AGENTS
Sympathetic responses to laryngoscopy and intubation include increases in heart rate, blood pressure, and intracranial pressure. These effects may be particularly important in select clinical settings such as traumatic brain injury, hemorrhagic stroke, myocardial ischemia, or aortic dissection.
Laryngeal stimulation may cause laryngospasm, cough, and bronchospasm. Pretreatment medications may help to mitigate these responses prior to
RSI (Table 29A­7). However, since the effectiveness of these measures is unclear, many clinicians omit this step. If used, administer pretreatment agents  to  minutes before initiation of RSI.
TABLE 29A­7
Rapid­Sequence Intubation Pretreatment Agents
Agent Dose Indications Precautions
Lidocaine .5 milligrams/kg IV/topically Elevated ICP Lack of evidence­based studies on effectiveness in ICP
Bronchospasm, asthma No evidence of improved outcome and may not be better than inhaled albuterol
Fentanyl  micrograms/kg IV Elevated ICP Respiratory depression
Cardiac ischemia Hypotension
Aortic dissection Chest wall rigidity
Abbreviations: ICP = intracranial pressure.
INDUCTION AGENTS
The ideal RSI induction agent achieves rapid, deep sedation of limited duration, avoids hypotension, and mitigates the physiologic response to laryngoscopy and intubation. There is no single induction agent of choice. Commonly used agents offer advantages and risks in specific clinical conditions (Table 29A­8).
TABLE 29A­8
Rapid­Sequence Intubation Induction Agents
Agent Dose Onset Duration Benefits Caveats
Etomidate .3–0.5 milligram/kg IV <1 min 10–20 min ↓ ICP Myoclonic jerking or seizures and vomiting in awake patients
↓ Intraocular pressure No analgesia
Neutral BP ↓ Cortisol
Propofol .5–1.5 milligrams/kg IV 20–40 s 8–15 min Antiemetic Apnea
Anticonvulsant ↓ BP
↓ ICP No analgesia
Ketamine 1–2 milligrams/kg IV  min 10–20 min Bronchodilator ↑ Secretions
“Dissociative” amnesia ↑ BP
Analgesia Emergence phenomenon
Abbreviations: BP = blood pressure; ICP = intracranial pressure.
Etomidate, a nonbarbiturate hypnotic, has a short duration of action, protects from myocardial and cerebral ischemia, causes minimal histamine release, and causes little hemodynamic depression in most patients. Myoclonus, nausea, and vomiting can occur in awake patients, but these effects are less important in the setting of RSI. Etomidate is not an analgesic, and it does not blunt the sympathetic response to intubation. Single­dose
 etomidate given for ED RSI can cause cortisol inhibition, but the clinical significance of this association is unclear.
Propofol is a highly lipophilic, rapid­acting sedative. Propofol has a more rapid onset of action and shorter duration of action than etomidate. It has anticonvulsant and antiemetic properties, and it may lower intracranial pressure without triggering histamine release. Important side effects of propofol include hypotension through myocardial depression and vasodilation, making it less appealing for trauma patients or shock states.
Ketamine, a phencyclidine derivative, is a dissociative agent that provides analgesia and amnesia. Ketamine preserves the respiratory drive, an ideal feature for sedation during awake intubation. Ketamine increases blood pressure and heart rate through catecholamine release, which may be useful in hypovolemic or hypotensive states. Ketamine causes direct smooth muscle relaxation and bronchodilation and is often used in those with refractory status asthmaticus. Despite theoretic concerns about γ­aminobutyric acid–altering effects that could worsen CNS function, ketamine is a good option in patients with head injury and hypotension. Ketamine does not cause consistent increased intracranial pressure in sedated and ventilated patients, and some studies suggest that the drug has possible cerebroprotective effects. Avoid ketamine in the elderly or for patients with suspected acute cardiac ischemia because of the potential for associated tachycardia and hypertension.
Other Agents
Barbiturates commonly cause hypotension from myocardial depression and venous dilatation; they have been largely replaced with etomidate or propofol. Benzodiazepines such as midazolam may be used when other agents are contraindicated or unavailable, but their depth and speed of onset are less reliable.
PARALYTIC (NEUROMUSCULAR BLOCKING) AGENTS
Neuromuscular blockade eliminates protective airway reflexes (Table 29A­9). Neuromuscular blockade can facilitate tracheal intubation, improve mechanical ventilation, and help control intracranial hypertension. Neuromuscular blockade limits assessments of neurologic status, and long­term use increases the risks of polyneuropathy and posttraumatic stress disorder. Neuromuscular blockers are neither anxiolytics nor analgesics, so delivering concurrent sedation is mandatory. Neuromuscular blockers include depolarizing and nondepolarizing agents. Depolarizing neuromuscular blocking agents have high affinity for cholinergic receptors of the motor end plate and are resistant to acetylcholinesterase.
Depolarizing blockade is not antagonized and may be enhanced by anticholinesterase agents. Nondepolarizing neuromuscular blocking agents compete with acetylcholine for the cholinergic receptors and usually can be antagonized by anticholinesterase agents.
TABLE 29A­9
Rapid­Sequence Intubation Paralytic (Neuromuscular Blocking) Agents
Adult Intubating IV
Agent Onset Duration Comments
Dose
Rocuronium  milligram/kg 1–3 30–45 min Tachycardia. Longer duration of action and onset compared to
(intermediate/long) min succinylcholine. Most common alternative to succinylcholine.
Vecuronium .08–0.15 milligram/kg 2–4 25–40 min Prolonged recovery time in obese or elderly, or if there is hepatorenal
(intermediate/long) .15–0.28 milligram/kg min 60–120 dysfunction.
(high­dose protocol) min
Succinylcholine .5 milligrams/kg 45–60 5–9 min Provides optimal intubating conditions most rapidly. There are several rare s but important contraindications (see Table 29A­10).
Succinylcholine is the most commonly used agent for neuromuscular blockade in ED RSI. A depolarizing agent, succinylcholine is two joined acetylcholine molecules and is rapidly hydrolyzed by plasma cholinesterase. It has a rapid onset after IV dosing and a shorter duration of action than nondepolarizing agents. After brief fasciculation, complete relaxation occurs at  seconds, with maximal paralysis at  to  minutes. Effective respirations resume in  to  minutes. IM succinylcholine (4 milligrams/kg) acts more slowly and lasts longer; this is best reserved for the rare setting where paralysis is required absent IV access.
If choosing succinylcholine, know its side effects (Table 29A­10). Serum potassium will transiently rise in all patients by an average of .5 mEq/L with succinylcholine, usually without any clinical impact. Due to acetylcholine receptor upregulation at the neuromuscular junction, an exaggerated hyperkalemic response may occur  or more days after a burn, denervation, or crush injury, or in patients with preexisting myopathies. Do not use succinylcholine in patients with suspected preexisting significant hyperkalemia (especially renal failure), myopathies, or myasthenia gravis. Repeated doses can cause cardiac dysrhythmias including bradycardia and asystole.
TABLE 29A­10
Succinylcholine Complications and Contraindications
Complications
Fasciculations
Transient increased intragastric, intraocular, and intracranial pressure
Bradycardia
Masseter spasm
Malignant hyperthermia
Prolonged apnea with pseudocholinesterase deficiency or myasthenia gravis
Contraindications
Preexisting hyperkalemia
Burns >5 d old
Denervation injury >5 d old
Significant crush injuries >5 d old
Severe infection >5 d old
Preexisting myopathies
Genetically susceptible individuals may develop malignant hyperthermia after succinylcholine. Suspect malignant hyperthermia if unexplained rapid fever with muscle rigidity, acidosis, or hyperkalemia occurs after succinylcholine. Treat with IV dantrolene sodium (2.5 milligrams/kg) and temperature control. Patients with acquired or genetic atypical or low plasma cholinesterase may have prolonged paralysis. Cocaine is metabolized by plasma cholinesterase, which reduces the amount of enzyme available for succinylcholine metabolism. If known plasma cholinesterase deficiency is suspected, use a nondepolarizing agent (usually rocuronium) instead of succinylcholine.
Rocuronium is an intermediate­duration nondepolarizing agent that is an excellent alternative to succinylcholine for RSI due to its shorter duration of action. By increasing the dose of rocuronium to .9 to .2 milligrams/kg, the onset of action approximates that of succinylcholine, but the duration of action is prolonged.
Vecuronium bromide is an intermediate­ to long­acting nondepolarizing agent. Vecuronium has no cardiac effects. Hypersensitivity reactions are rare, doses are only minimally cumulative, and excretion is biliary. Despite the lack of histamine release, hypotension may occur through other mechanisms that include sympathetic ganglia block and less venous return from altered or absent muscle tone and positive­pressure ventilation.
Sugammadex is a reversal agent that reverses blockade from rocuronium or vecuronium by encapsulating the molecules of the nondepolarizing
 agents circulating in plasma. The dose is  to  milligrams/kg, depending on the intensity of neuromuscular paralysis, and the drug takes effect within minutes. Neostigmine, a cholinesterase inhibitor, may be used to reverse neuromuscular blockade, but it has undesirable cardiac and cholinergic side effects.
VIDEO LARYNGOSCOPY
Video laryngoscopes (VLs) use an integrated high­resolution camera and video monitor to facilitate indirect glottic visualization and ETT placement. VL creates a magnified view that cannot be obtained through direct laryngoscopy. VL also allows shared visualization and video recording useful for quality review, education, and training. VL may be used as the primary or rescue intubation technique. While first­pass and overall intubation success rates are similar between direct laryngoscopy and VL, VL improves glottic visualization and reduces intubation complications, including rates
26–28 of esophageal intubation. However, compared with conventional direct laryngoscopy, the glottic view with VL may be inferior in a small subset of
 patients. VL may be most useful in patients with difficult airway anatomy, including obese patients and those with limited mouth opening or neck mobility. Avoid VL and use direct laryngoscopy if the camera may be obscured by emesis.
Laryngoscopic technique is slightly different with VL than conventional laryngoscopy. First, the operator performs the intubation watching a video screen rather than looking directly into the oropharynx. Second, VL often uses a hyperangulated blade. The combination of these two features allows visualization of the glottis with only limited extension of the head and neck. A specially designed stylet is required when VL is used in this manner.
In contrast to traditional laryngoscopy, a midline insertion approach is preferred and a tongue sweep is not needed with VL. Once past the teeth, the operator identifies the midline by finding the uvula. The blade is then slowly advanced down the tongue until the epiglottis is seen. The ideal view is usually obtained by insertion into the vallecula, much like a Macintosh blade. The handle is then gently tilted forward until visualization of the glottic opening is obtained.
The two most studied VLs are the GlideScope Video Laryngoscope® (Verathon, Bothell, WA) and the C­MAC Video Laryngoscope® (Karl Storz,
Tuttlingen, Germany) (Figure 29A­13). Both brands also have conventionally curved blades available, allowing the device to function much like a conventional laryngoscope; this feature allows for supervision of novice intubators during the traditional intubation technique. (See Video: Intubation:
C­MAC Video Laryngoscope.)
FIGURE 29A­13
Video laryngoscopes. A. GlideScope®. B. C­MAC®.
Video 29­2: Intubation: C­MAC
Used with permission from C. Scott Forsythe, University of North Carolina, Department of Emergency Medicine, Chapel Hill, NC, from Tintinalli’s Emergency Medicine
(©2014 Product Courtesy of KARL STORZ Endoscopy­America, Inc.)
Play Video
[online only insert MM ID 8300739Intubation: C­MAC Video Laryngoscope]
FLEXIBLE FIBEROPTIC LARYNGOSCOPY
The flexible fiberoptic laryngoscope (FFL) uses fiberoptic technology embedded in a flexible tube to facilitate visualization of and access to the airway
(Figure 29A­14). Newer flexible scopes use video technology, not fiberoptics, and interface directly with VL monitors. FFL aids when anatomic limitations, such as angioedema, epiglottitis, Ludwig’s angina, congenital anatomic abnormalities, and cervical spine immobility, prevent traditional
 laryngoscopy. Growing numbers of ED practitioners are becoming skilled with FFL. FFL requires proper equipment as well as appropriate training. If equipment or expertise is not available in the ED, consult an expert with fiberoptic skills and tools.
FIGURE 29A­14
Flexible fiberoptic intubation (Ambu Airscope; Ambu, Ballerup Denmark). A. Flexible fiberoptic scope B. Flexible fiberoptic scope with screen.
FFL requires setup time as well as a compliant, spontaneously breathing patient. Patients needing an immediate airway, with near­complete obstruction, with large bleeding or vomitus, and who cannot be ventilated to maintain saturation are poor FFL candidates.
Topical anesthesia is essential for FFL intubation success. Use atomized or nebulized topical anesthetics, such as 4% lidocaine. An antisialagogue, such as glycopyrrolate .01 milligram/kg, or homatropine reduces secretions and enhances topical anesthesia, but should be given  minutes prior to intubation for best effect. If sedation is necessary to facilitate FFL, ketamine is a good choice as it will preserve spontaneous breathing. If using the nasal route, instill a topical vasoconstrictor such as phenylephrine or oxymetazoline. Nasal viscous lidocaine followed by a nasal airway allows topical anesthesia and enhanced passage of the scope through the airway; remember to remove the nasal tube prior to the passage of an ETT.
Focus the eyepiece if needed and lubricate the flexible shaft. Immerse the lens at the tip of the laryngoscope in warm water or apply antifogging solution. Intermittent insufflation of oxygen at  to  L/min through the suction port will keep the optic tip clear. If possible, use a #7.5 ETT. Remove the adapter from the ETT and slip the lubricated tube over the FFL up to the handle. If the distal end of the FFL does not extend beyond the end of the
ETT, the scope is too small and should not be used for intubation.
FFL is often easiest through the nasal route, allowing easier midline airway positioning and entry of the glottis at a less acute angle. If using the oral route, tongue extrusion, anterior mandibular displacement, or the use of a specially designed oral airway or bite block may help (Figure 29A­15).
Advance the scope through the hypopharynx. Hold the laryngoscope in the opposite hand to control tip deflection while advancing it through the vocal cords. Spraying 4% lidocaine through the working channel when the scope is over the glottic opening may help to suppress the gag or cough reflex.
Once the scope is through the cords, pass the ETT over the scope in Seldinger fashion and remove the scope. Resistance at the cords is best overcome with tube rotation rather than forceful insertion.
FIGURE 29A­15
Bite block for oral passage of flexible fiberoptic laryngoscope (ConMed, Utica, NY).
A valuable adjunct to FFL is the Aintree catheter (Cook Medical, Bloomington, IN), a hollow stylet that can be inserted over an FFL. After intratracheal placement of the Aintree catheter, the FFL may be removed and a standard ETT inserted over the Aintree much like a bougie. The Aintree may be inserted via FFL through a properly placed supraglottic airway (e.g., laryngeal mask airway), allowing for conversion to an ETT.
BLIND NASOTRACHEAL INTUBATION
Blind nasotracheal intubation may be helpful where laryngoscopy may be difficult, RSI is contraindicated, and FFL is not available. Nasotracheal intubation is less common given other available options. Severe traumatic nasal or pharyngeal hemorrhages are relative contraindications to nasotracheal intubation.
Position the patient upright with the head in a neutral or slightly extended position (“sniffing position”). Stand to the side of the patient with one hand on the tube and with the thumb and index finger of the other hand straddling the larynx. Insert and advance the lubricated tube along the nasal floor; the right naris is often larger. Pass the ETT straight back toward the occiput (not upward), and then advance it while rotating it medially  to  degrees until maximal airflow is heard through the tube. Steady, gentle pressure or slow rotation of the tube usually bypasses small obstructions.
Gently but swiftly advance the tube at the initiation (upswing) of inspiration. The typical optimal depth of nasotracheal tube placement is  cm at the nares in men and  cm at the nares in women. Confirm tracheal placement using multiple methods.
MANAGING INTUBATION DIFFICULTY
ANTICIPATED INTUBATION DIFFICULTY

Several factors can help identify a potentially difficult intubation (Table 29A­2). Assess the patient’s clinical condition and identify factors that will impede successful intubation. Weigh these observations against the urgency of the patient’s condition. If patient consciousness or agitation is the sole anticipated obstruction, proceed with sedation and paralysis. In the presence of major anatomic barriers (tumor, trauma, obesity, difficult anatomy), consider deferring RSI, preserving the patient’s natural respiratory drive and protective airway reflexes. In these situations, strategies of awake intubation using FFL or (for those skilled with the technique) blind nasotracheal intubation are options. In the case of severe facial trauma, immediate or urgent surgical airway placement (cricothyroidotomy or tracheostomy) is always an option. Awake orotracheal intubation with topical anesthetic is theoretically possible but rarely achievable in the emergency setting.
Where immediately available, emergent assistance from anesthesiologists, surgeons, or otolaryngologists may aid. The use of BiPAP, CPAP, or highflow nasal cannula oxygen may mitigate the patient’s deterioration, affording additional time to assemble resources.
UNANTICIPATED INTUBATION DIFFICULTY
The more challenging clinical scenario is the case of unanticipated intubation difficulty occurring after the administration of sedative and paralytic medications. A single failed laryngoscopy attempt should signal potential airway difficulty and prompt corrective action. Although there is no single pathway or approach to unanticipated intubation difficulty, operators should consider several guiding principles.
Stay calm. Think clearly. Communicate directly and clearly. Use available team members (nurses, respiratory therapists, technicians, and other physicians) to assist with care and mobilize needed equipment, medications, and personnel. Use of cognitive aids (e.g., checklists and difficult airway algorithms) can help to minimize the stress while providing cognitive offloading. Call for help. Where readily available, assistance from anesthesiologists, surgeons, otolaryngologists, intensivists, or fellow emergency physicians may be helpful but often requires time to mobilize. If you anticipate the need for assistance, call for help early. Plan and communicate the next two steps. Plan not only the next therapeutic intervention but also the subsequent intervention in the event of failure. For example, “I will switch to a Miller blade with bougie insertion. If unsuccessful, I will insert a laryngeal mask airway.” Engage team members so that they are aware of your planned actions. Alter airway techniques with each attempt. Modify intubation blade type, blade size, approach, or operator with each attempt. Do not repeat the same unsuccessful methods with successive attempts. Let RSI medications wear off. Recovery of even a minimal degree of protective airway reflexes and spontaneous respirations may facilitate critically needed airway patency. Use noninvasive airway measures. Bag­valve mask with an oral or nasal airway or insertion of a supraglottic airway may be helpful, mitigating clinical deterioration. Bag­valve mask or supraglottic airway insertion may allow additional time for surgical airway execution.
HYPOTENSION ASSOCIATED WITH INTUBATION
Physiologic changes triggered by laryngoscopy or the medications used during RSI can induce hypotension. While some advocate for empiric isotonic crystalloid infusion just prior to RSI, others believe dilute low­dose boluses or ‘push­dose’ pressors prior to ETI help mitigate hypotension. The ideal fluid volume and timing, and the optimal vasopressor choice and dose, are unknown. Table 20­1 notes common vasopressor preparations used in this manner, commonly epinephrine or phenylephrine ready ahead of time in syringes (rather than quickly drawn at the time of perceived need). The overall benefit of either practice is unclear.
OXYGENATION, VENTILATION, AND INTUBATION IN THE PATIENT WITH COVID ­19

COVID­19 is primarily a droplet­borne pathogen. Manipulations of the airway can result in aerosolization or spread of the virus. Operators managing the airway are at high risk of exposure because of their proximity to the patient’s oropharynx. Adaptations described below mitigate viral spread and minimize personnel exposure
Provider Protective Equipment (PPE)
During Intubation/Aerosol Generation PPE should include the following:
Bonnet or hair cover
Fitted N95 mask or powered air purifying respirator (PAPR)
Eye protection
Faceshield
Gown

Gloves (ideally double gloved)
Where possible, place the patient in a negative pressure room. Given the risk of aerosolizing the virus during endotracheal intubation, some advocate
 for intubation hoods or intubation boxes. No outcome data exist on the use of such devices, though simulation suggests that they can reduce the amount of viral particles aerosolized into the air. Potential benefits of hoods or boxes must be weighed against the restricted movement of providers
 during the process of intubation.
Other steps can reduce the risk of aerosolization and protect providers. For patients who require inhaled medications traditionally administered via nebulization (i.e. albuterol), metered dose inhalers (MDIs) help minimize aerosolization compared to nebulization; be sure to adjust the dose – often 4­
 “puffs” with a spacer. Viral filters, including high‐efficiency particulate air (HEPA) filters can reduce aerosolization when ventilating. Place viral filters
 between the bag­valve mask and endotracheal tube, or between the endotracheal tube and Y­connector of the ventilator.
High­Flow Nasal Cannula (HFNC)

Many patients with COVID­19 illness have hypoxemia but little overt respiratory distress. In such instances, start with oxygen therapy. Initial pandemic concerns over provider exposure from HFNC in patients with suspected COVID­19 are lessened because data have reported limited aerosolization with
 this approach. HFNC can help oxygenate patients with COVID­19, and patients should wear traditional surgical masks when receiving HFNC to further reduce the risk of aerosolization.
Non­Invasive Positive Pressure Ventilation (NIPPV)
The role of NIPPV including BiPAP and CPAP ventilation in COVID­19 illness care is still evolving. There is concern that these measures can increase the aerosolization of the virus and thereby increase the risk of spread to others nearby. When using NIPPV, attach a viral filter to the exhaust port of the mask to help reduce viral transmission.
Awake Proning
Prone positioning may help to improve oxygenation in patients with COVID­19 by decompressing and recruiting the posterior areas and decreasing
 shunting. This simple intervention can potentially help to avoid intubation and mechanical ventilation.
Considerations During Intubation
Limit who is present (only those needed) and ensure appropriate PPE for providers.
Preoxygenation is important. Many COVID­19 patients have early acute lung injury and may not be able to tolerate prolonged apnea.

Maximize first intubation attempt success. Have the most experienced intubator perform the intubation.
Utilize rapid sequence intubation with paralytics to reduce the risk of coughing or gagging during the procedure. Ablate all muscular activity prior to attempted laryngoscopy.
Utilize video laryngoscopy for intubation to improve first attempt success and reduce the risk of transmission from patient to intubator. The provider is farther away from the patient’s oropharynx using video laryngoscopy than with direct laryngoscopy.
In the event of unsuccessful laryngoscopy, consider use of a supraglottic airway with viral filter instead of bag­valve­mask for re­oxygenation.


