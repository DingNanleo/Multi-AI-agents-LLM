## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 156: Endocarditis
Daniel Saul Brenner; Catherine A. Marco; Richard E. Rothman
INTRODUCTION AND EPIDEMIOLOGY
Endocarditis patients often have nonspecific signs and symptoms, but endocarditis has the potential for multiorgan involvement. The clinical course of endocarditis can be indolent or fulminant. The majority of endocarditis is infective; diagnosis relies on a set of explicit criteria (see later Tables 156­3 and 156­4 in “Diagnosis” section). Unrecognized endocarditis has frequent complications and high mortality.
1­7
In developed countries, the incidence of infective endocarditis ranges from  to .6 cases per 100,000 patient­years and is higher in urban settings
(likely reflecting the impact of injection drug use). Pediatric endocarditis is uncommon and is primarily associated with structural heart disease,
 postoperative congenital heart disease, rheumatic heart disease, or catheter­related bacteremia. Overall, men are more commonly affected than
,2,9 women, and in­hospital mortality rate ranges from 18% to 32%. Short­term mortality in medically managed endocarditis increases with severe
 comorbid illnesses, abnormal mental status, congestive heart failure, or a bacterial etiology other than Streptococcus viridans.
Most cases of endocarditis occur in those with a predisposing structural abnormality (congenital or acquired), prosthetic valve, or a risk factor for disease (e.g., injection drug use, intravascular device, poor dental hygiene, chronic hemodialysis, human immunodeficiency virus infection). Although the mitral valve is the most commonly affected site (followed by the aortic, tricuspid, and pulmonic valves), the incidence of tricuspid valve endocarditis
 has steadily increased, attributed principally to increased rates of injection drug use.
For native valve endocarditis in the developed world, mitral valve prolapse is a common predisposing lesion. Other underlying structural factors include congenital defects (e.g., bicuspid aortic valve), degenerative cardiac lesions (calcific aortic stenosis), and rheumatic heart disease. In developing countries, rheumatic heart disease–related valvulopathy remains the leading risk factor.
The estimated risk in injection drug users is 2% to 5% per year, with a mean age of diagnosis of  years old. Injection drug use–associated endocarditis often involves the tricuspid valve, has an increased susceptibility to recurrence (approximately 40%), and has increased mortality in
 human immunodeficiency virus–positive patients with CD4+ count of <200/mm . Large vegetation size and fungal organism are also associated with
 poor outcome.
Indwelling vascular devices create increased risk that microorganisms will attach to valves during bacteremia. Healthcare­associated endocarditis occurs when diagnosis is made >72 hours after admission without evidence of endocarditis on admission, endocarditis develops within  months after hospital discharge, or endocarditis develops within  months of cardiovascular manipulations including central venous catheter use, arteriovenous
,14 fistula for hemodialysis, invasive intravascular techniques, or intracardiac devices such as pacemakers and left ventricular assist devices.
Prosthetic valve endocarditis occurs in 1% to 4% of recipients during the first year following replacement and in approximately 1% per year thereafter.
There is no difference in infection risk between mechanical or bioprosthetic valves. Cases with onset within  days after surgery are termed early prosthetic valve endocarditis and are usually nosocomial. Cases starting beyond  days after surgery are termed late prosthetic valve endocarditis and are usually community acquired. Hospital mortality rates are highest for those with early (30% to 80%) versus late (20% to 40%) prosthetic valve endocarditis, attributable to the greater virulence of the causative organisms involved.
PATHOPHYSIOLOGY
The normal endothelium is resistant to infection and thrombus formation. Injury from high­pressure gradients and turbulent flow, as occurs with preexisting valvular or congenital cardiac lesions, lessens the natural defense. With injection drug use, endothelial damage occurs from repetitive bombardment with particulate matter (i.e., talc) present in injected material or from ischemia brought on by drug­induced vasospasm (cocaine use is
 pCahratipctuelra 1rl5y6 a:s Esoncdioatceadrd witiitsh, Denadnoiecla Srdaiutils B). rTehnen reers; uCltaatnhte erinndeo Ath. eMliaarlc doa; mRaicghea prdro Em. oRteosth pmlaatenlet/fibrin deposition and the formation of steriPleage  /  v©e2g0e2ta5t iMoncGs (rnaown Hbailcl.t Aerlil aRl itghhrotsm Rbeosteicr veendd.o c Taredrmitiss) o. Nf Uonseb a * c Pterriviaalc tyh rPoomlicbyo t * i cN voetgiceet a * t iAocncse (saslsiob icliatylled marantic endocarditis) can result from hypercoagulable states, malignancy, or systemic lupus erythematosus (Libman­Sacks endocarditis) and in areas surrounding foreign bodies (vascular catheters or prosthetic valves).
Transient bacteremia (as little as  organisms per milliliter of blood for <30 minutes) may colonize and convert to infective endocarditis. Triggers include skin trauma or endogenously colonized surfaces of the oropharynx or GI or GU tract. Endocarditis can occur in the absence of trauma, and in
15­19 normal hosts, it can be related to spontaneous bacteremia arising from brushing teeth, dental procedures, and both minor or systemic infections.
Coexistence of bacteremia and nonbacterial thrombotic endocarditis does not uniformly result in infective endocarditis. The infecting organism must be able to adhere to the nonbacterial thrombus on the endothelium. Adherent organisms stimulate further deposition of platelets and fibrin, leading to generation of a “protected site” that phagocytic cells cannot easily penetrate. Although nonbacterial thrombotic endocarditis often precedes infective endocarditis, it not a prerequisite because highly invasive organisms (Staphylococcus aureus) can directly invade the endocardium. As the disease progresses, fragments from vegetation spread into the circulation and cause sustained bacteremia.
MICROBIOLOGY
A wide range of pathogens cause infective endocarditis. Bacteria are the predominant cause, with a small number of species responsible for most of the cases (Table 156­1). Staphylococcus is the single most common cause, followed by streptococci (including viridans group streptococci) and
,3,20­23 enterococci. Other rarer causes of infectious endocarditis include Rickettsia, Chlamydophila, Bartonella, Coxiella burnetii, Legionella, Candida,
 and Aspergillus.
TABLE 156­1
Microbiology of Infective Endocarditis (IE)
Native Valve IE (% of cases) Intracardiac Device IE (% cases)
Normal Injection Drug Prosthetic Valve Other
Host Use IE Devices* Staphylococcus aureus   S. aureus  
Coagulase­negative   Coagulase­negative  
Staphylococcus Staphylococcus
Viridans group streptococci   Viridans group streptococci  
Other streptococci   Streptococcus bovis  
Enterococcus species   Enterococcus species  
HACEK   HACEK  
Fungus   Fungus  
Polymicrobial   Polymicrobial  
Others   Others  
Culture negative   Culture negative  
Abbreviation: HACEK = Haemophilus, Aggregatibacter, Cardiobacterium, Eikenella, and Kingella group.
*Including pacemakers and implantable cardioverter­defibrillators.
The increase in staphylococcal endocarditis is linked to the increase in healthcare­associated endocarditis and increasing IV drug use. S. aureus is associated with rapid valve destruction, infection of structurally normal heart valves (particularly tricuspid valves in patients who are IV drug abusers),
 and increased risk of in­hospital death. The incidence of staphylococcal endocarditis related to pacemaker lead infection is also increasing and
 associated with severe morbidity and mortality. In contrast, streptococcal endocarditis tends to be indolent. Enterococcal endocarditis is associated with underlying valvular disease and risk factors (diabetes mellitus, manipulation of the GU or lower GI tract). Early prosthetic valve endocarditis is most commonly caused by perioperative colonization from Staphylococcus epidermidis,Aspergillus, or Candida albicans.
Blood cultures are the best method for detection of endocarditis but are negative in about 5% of patients; 33% to 50% of culture­negative endocarditis is attributed to prior antibiotic administration. For culture­negative cases without prior antibiotic administration, infection is most often due to fastidious organisms (usually from the HACEK group—Haemophilus, Aggregatibacter, Cardiobacterium, Eikenella, and Kingella—and also Bartonella
 and Coxiella burnetii).
CLINICAL FEATURES

The clinical manifestations of endocarditis range from acute/fulminant to insidious/indolent. Common presenting symptoms include fever, chills, weakness, and dyspnea. The most common complications are congestive heart failure (44%), CNS findings (30%), and peripheral arterial embolization

(22%).
FEVER
Early bacteremia produces nonspecific signs and symptoms (Table 156­2), usually beginning within  weeks of infection. Symptoms include fever,
 chills, nausea, vomiting, fatigue, and malaise. Fever (>38°C [100.4°F]) is present in almost all patients (>90% overall, >98% with injection drug
,14,20,21 use). Fever may be absent in the elderly, those using antibiotics or antipyretics, and those with congestive heart failure, renal failure, or immunosuppression.
TABLE 156­2
Clinical Features of Infective Endocarditis
Symptoms % Signs %
Fever  Fever 
Chills  Heart murmur 
Weakness  New murmur 3–5
Dyspnea  Changing murmur 5–10
Anorexia  Skin manifestations 18–50
Cough  Osler nodes 10–23
Malaise  Splinter hemorrhages 
Skin lesions  Petechiae 20–40
Nausea/vomiting  Janeway lesions <10
Headache  Splenomegaly 20–57
Stroke  Embolic phenomena >50
Chest pain  Septic complications 
Abdominal pain  Mycotic aneurysm 
Mental status change 10–15 Renal failure 
Back pain  Retinal lesions 2–10
CARDIAC MANIFESTATIONS
Congestive heart failure occurs in up to 70% of patients from distortion or perforation of valvular leaflets, rupture of the chordae tendineae or papillary muscles, or perforation of cardiac chambers. Heart murmurs are common, heard in 50% to 85% of patients, although less so in right­sided endocarditis (<50%). Valvular abscesses and pericarditis can result from local extension. Other cardiac complications include heart blocks and dysrhythmias that result from extension of infection through the interventricular septum to the conduction system.
NEUROLOGIC MANIFESTATIONS
About 20% to 40% of patients develop neurologic symptoms, including embolic cerebral ischemic events (often in multiple areas, a clinical clue), CNS
 abscess, intracranial hemorrhage, mycotic (or infected) aneurysm, meningitis, or seizures. Rupture of a cerebral mycotic aneurysm results in
 subarachnoid hemorrhage. Embolic stroke involving the middle cerebral artery is the most common CNS complication.
ARTERIAL EMBOLIZATION

Embolization of vegetation fragments is common (20% to 50% of patients), resulting in infarction or abscess in remote tissues. Pulmonary complications include pulmonary infarction, pneumonia, empyema, or pleural effusion; multifocal pneumonia, like multifocal cerebral infarction, often is a clue to septic embolization. Coronary artery emboli usually arise from the aortic valve and may cause acute myocardial infarction or myocarditis. Embolic splenic infarction causes left upper quadrant abdominal pain with radiation to the left shoulder. Renal emboli result in flank pain and hematuria. Emboli to the mesenteric arteries cause acute abdominal pain, melena, or bowel ischemia. Emboli to arteries of the extremities may produce acute limb ischemia. Retinal artery embolism may cause acute monocular blindness.
CUTANEOUS FINDINGS
Cutaneous embolic phenomena are less common due to early detection and treatment. Cutaneous findings may occur in 5% to 10% of cases and may include petechiae, splinter or subungual hemorrhages of digits, Osler nodes (small, tender subcutaneous nodules on the pads of the digits), and
,29
Janeway lesions (small hemorrhagic painless plaques on the digits). Digital clubbing is infrequent, and occurs only in those with long­standing disease. Cutaneous signs are not specific and occur in other types of vasculitis or bacteremia.
DIAGNOSIS

Suspicion of endocarditis usually requires hospital admission for culture, echocardiography, and assessment of the clinical course.
Prolonged unexplained fever, malaise, or other constitutional symptoms should prompt evaluation for endocarditis. Thoroughly evaluate and admit febrile injection drug users since the prevalence of endocarditis is high (10% to 15%), follow­up is often challenging, and clinical findings cannot reliably exclude the diagnosis. Admit patients with a cardiac prosthetic valve and fever (or persistent malaise, vasculitis, or new murmur) given the high morbidity and mortality associated with prosthetic valve infections. In stable patients with a low suspicion of endocarditis who were initially discharged, admit immediately once positive blood cultures result.
,31
The Duke criteria aid diagnosis of infective endocarditis (Tables 156­3 and 156­4). A more recent study demonstrated excellent negative predictive value for the Prediction Rule for Endocarditis in Injection Drug Users, which assesses risk based on tachycardia, cardiac murmur, and
 absence of skin infection. This latter tool requires more research before wider use in ED treatment and disposition decisions.
TABLE 156­3
Duke Criteria* for Infective Endocarditis
Major Criteria
Positive blood culture for IE
Typical microorganism consistent with IE from two separate blood cultures* as noted below:
Streptococcus bovis, viridans streptococci, HACEK group or
Community­acquired Staphylococcus aureus or enterococci in the absence of a primary focus or
Microorganisms consistent with IE from persistently positive blood cultures defined as:
At least two positive cultures of blood samples drawn >12 h apart or
All of three or a majority of four or more separate blood cultures (with first and last sample drawn at least  h apart)
Single positive blood culture for Coxiella burnetii or antiphase I immunoglobulin G antibody titer of >1:800
Evidence of echocardiographic involvement
Positive ECG for IE defined as:
Oscillating intracardiac mass on valve or supporting structures, in the path of regurgitant jets, or on implanted material in the absence of an alternative anatomic explanation or
Abscess or
New partial dehiscence of prosthetic valve
New valvular regurgitation (worsening or changing of preexisting murmur not sufficient)
Minor Criteria
Predisposition: predisposing heart condition or injection drug use
Fever: temperature >38°C (100.4°F)
Vascular phenomena: major arterial emboli, septic pulmonary conjunctival hemorrhages, and Janeway lesions
Immunologic phenomena: glomerulonephritis, Osler nodes, Roth spots, and rheumatoid fever
Microbiologic evidence: positive blood culture but does not meet a major criterion as noted in Table 156­4* or serologic evidence of active infection with organism consistent with IE
Echocardiographic minor findings were eliminated in the modified Duke criteria
Abbreviations: HACEK = Haemophilus, Aggregatibacter, Cardiobacterium, Eikenella, and Kingella; IE = infective endocarditis.
*Excludes single positive cultures for coagulase­negative staphylococci and organisms that do not cause IE.
TABLE 156­4
Modified Duke Criteria for Infective Endocarditis
Definite Infective Endocarditis
Pathologic criteria
Microorganisms demonstrated by culture or histologic examination of a vegetation or in a vegetation that has embolized or in an intracardiac abscess or
Pathologic lesions: vegetation or intracardiac abscess present, confirmed by histology showing active endocarditis
Clinical Criteria, Using Specific Definitions Listed in Table 156­3
Two major criteria or
One major and three minor criteria or
Five minor criteria
Possible infective endocarditis
One major criterion and one minor criterion
Three minor criteria
Rejected
Firm alternate diagnosis for manifestations of endocarditis or
Resolution of manifestations of endocarditis with antibiotic therapy for  d or less or
No pathologic evidence of infective endocarditis at surgery or autopsy after antibiotic therapy for  d
Does not meet criteria for possible infective endocarditis
BLOOD CULTURES
Obtain blood cultures (at least  mL per culture bottle) before beginning antibiotics. Draw three sets from separate sites because fewer collections may not detect bacteremia. Those receiving any antibiotic therapy recently often require additional sets of blood cultures. Ideally, wait at least  hour between the first and last blood culture. Although administration of antibiotics prior to culture acquisition reduces recovery rate of bacteria by 35% to

40%, in critically ill patients, do not withhold antibiotics to obtain cultures. In patients with confirmed endocarditis, repeat blood cultures every 
,35 to  hours to assess treatment progress.
For patients at risk for culture­negative infective endocarditis, advise the laboratory of the suspected diagnosis to prompt specialized testing for fastidious organisms. Polymerase chain reaction techniques aid pathogen detection.
OTHER DIAGNOSTIC TESTS
There are no definitive laboratory tests that diagnose endocarditis. Common findings are anemia (70% to 90%), hematuria, and elevation of erythrocyte sedimentation rate (>90%), C­reactive protein, or procalcitonin.
ECG findings are also nonspecific but can identify conduction abnormalities resulting from infection. Prolonged PR interval, new left bundle branch block, or new right bundle branch block with left anterior hemiblock suggests spread of infection into the conduction system. Junctional tachycardia,
Wenckebach block, or complete heart block may indicate extension of infection from the mitral annulus into the atrioventricular node or proximal bundle of His.
Chest radiographs may demonstrate pulmonic emboli (often in multiple areas) in patients with right­sided valvular involvement or may show acute heart failure in those with left­sided valvular involvement.
ECHOCARDIOGRAPHY
Echocardiographic abnormalities represent one of the two major criteria for definitive diagnosis. Two­dimensional transthoracic echocardiography is
,36 the first choice for those with native valves. The specificity of transthoracic echocardiography for vegetations is excellent (98%), although sensitivity varies according to patient population. Sensitivity of transthoracic echocardiography is highest in injection drug users (88% to 94%), who more often have larger vegetations, right­sided lesions, and favorable acoustic windows. For those with chest wall deformities, obesity, or chronic obstructive pulmonary disease, transthoracic echocardiography is less sensitive.
Transesophageal echocardiography is more sensitive and specific in detecting valvular abnormalities than transthoracic echocardiography due to improved image resolution but is less immediately available in the emergency setting. Use transesophageal echocardiography in patients with prosthetic valves or intracardiac devices, patients with inadequate transthoracic echocardiography imagery, and those with intermediate or high
,36 clinical probability of endocarditis. Transesophageal echocardiography is of particular value for assessing suspected complications such as myocardial abscess and perivalvular extension.
TREATMENT
INITIAL STABILIZATION
Patients with endocarditis may present with hemodynamic instability, respiratory compromise, pulmonary edema, diminished pulmonary capacity, altered mental status, and acidosis. Emergency stabilization with airway management and hemodynamic monitoring and support are priority interventions. Intra­aortic balloon counterpulsation aids the emergency management of unstable mitral valve rupture but is contraindicated for aortic valve rupture.
Definitive management requires a team approach, and that often includes experts from cardiology, infectious disease, and cardiac surgery.
Systemic clot lysis or anticoagulation for treatment of endocarditis­associated stroke is controversial (concern of worsening underlying event) and best managed together with a stroke expert. Current guidelines for native valve endocarditis recommend withholding anticoagulation for at least 
,37,38 weeks after a CNS embolic event to reduce the risk of hemorrhagic transformation.
Patients with prosthetic valves being treated with anticoagulants may be maintained on established regimens as long as there is no evidence of bleeding. Patients with prosthetic valve endocarditis and evidence of embolic strokes should have anticoagulation and antiplatelet therapy withheld
,39 for at least  weeks to reduce the risk of hemorrhagic transformation.
EMPIRIC TREATMENT OF SUSPECTED ENDOCARDITIS OF NATIVE VALVES
,39­41
Antibiotic selection is based on patient characteristics and local resistance patterns. Table 156­5 lists sample empiric treatment regimens.
Although some recommend awaiting culture results before antibiotic therapy for patients with subacute bacterial endocarditis, we recommend ED initiation of antibiotic therapy targeting the most common organisms for all patients suspected of endocarditis after obtaining blood cultures. For
 patients with suspected native valve infection, empiric antibiotic therapy includes a penicillinase­resistant penicillin, a cephalosporin, or daptomycin.
Gentamicin is no longer recommended for native valve staphylococcal infective endocarditis due to minimal benefit and significant
,41,43 nephrotoxicity. For patients with complications (injection drug use, congenital heart disease, nosocomial infection, endocarditis developed while taking oral antibiotics, or suspected methicillin­resistant S. aureus), add vancomycin.
TABLE 156­5
Empiric Therapy of Suspected Bacterial Endocarditis* Patient Characteristics Recommended Agents, Initial Dose
Uncomplicated history Ceftriaxone, 1–2 grams IV or
Nafcillin,  grams IV or
Oxacillin,  grams IV or
Cefepime,  gram IV and
Vancomycin,  milligrams/kg (if anaphylactic to penicillins) or
Tobramycin,  milligram/kg IV
Injection drug use, congenital heart disease, hospital­acquired, suspected methicillin­resistant Nafcillin,  grams IV
Staphylococcus aureus, or already on oral antibiotics plus
Vancomycin,  milligrams/kg IV or
Daptomycin 8–10 milligrams/kg IV
Concern for vancomycin­resistant Enterococcus infection Daptomycin 8–10 milligrams/kg or
Linezolid 600 milligrams
Prosthetic heart valve Nafcillin  grams IV (if oxacillin­susceptible) or
Vancomycin,  milligrams/kg IV (if oxacillin resistance is suspected) plus
Gentamicin, 1–2 milligrams/kg IV plus
Rifampin, 300 milligrams PO
*Based on American Heart Association, endorsed by the Infectious Diseases Society of America (http://www.idsociety.org/Organ_System/, accessed April , 2014).
Because of controversy in the literature regarding the optimal regimen for empiric treatment, antibiotic selection should be based on patient characteristics, local resistance patterns, and current authoritative recommendations.
EMPIRIC TREATMENT OF SUSPECTED PROSTHETIC VALVE ENDOCARDITIS
For patients with suspected artificial valve endocarditis, empiric therapy includes an antistaphylococcal β­lactam agent or vancomycin, with
,41 consideration of adding gentamicin and rifampin.
DEFINITIVE TREATMENT OF ENDOCARDITIS
Base definitive antibiotic treatment on culture and sensitivity results. Most patients will require  to  weeks of antibiotic therapy. Surgical management is indicated in patients with severe valvular dysfunction, congestive heart failure, relapsing prosthetic valve endocarditis, major embolic
,39,44 complications, fungal endocarditis, new conduction defects or dysrhythmias, or persistent bacteremia after appropriate therapy. Surgical risk
 increases in those >65 years old, on inotropes, with sepsis, or with cerebral emboli. Patients with concern for pacemaker lead infection may require
 removal of infected hardware in order to achieve source control.
ENDOCARDITIS PROPHYLAXIS
Because every day dental activities (brushing, flossing, chewing) cause bacteremia, dental hygiene is critical. Give antibiotic prophylaxis to those
,39,46 at risk(Table 156­6) prior to manipulation of gingival tissue or the periapical region of teeth or perforation of the oral mucosa. Prophylaxis is not needed in those at risk for nondental procedures, such as local injections, laceration suturing, IV placement, blood drawing, endotracheal intubation, endoscopy, vaginal delivery, oral trauma, urethral catheterization, or uterine dilation and curettage. Some experts
,47 recommend prophylaxis for body art, such as tattooing and piercing, but this is not a standard practice.
TABLE 156­6
Highest­Risk Conditions for Endocarditis31
Prosthetic heart valves
Prosthetic material used for valve repair
History of previous infective endocarditis
Unrepaired cyanotic congenital heart disease
Repaired congenital heart defect with prosthetic material or device
Repaired congenital heart disease with residual defects
Cardiac transplant recipients with valve regurgitation due to a structurally abnormal valve
Prophylaxis is not routinely indicated for patients with mitral valve prolapse, pacemakers, hypertrophic cardiomyopathy, physiologic murmurs,
 coronary artery bypass surgery or angioplasty, or surgical repair of atrial septal defect, ventricular septal defect, or patent ductus arteriosus.
Recommendations for procedures that manipulate infected skin structures or musculoskeletal tissue are Class IIb (consider but usefulness not established); it is reasonable to administer antibiotics before the procedure for the highest­risk groups identified in Table 156­6. Choose an antibiotic active against staphylococci and β­hemolytic streptococci; vancomycin and clindamycin are options for those unable to tolerate a β­lactam or those suspected to have an infection caused by a methicillin­resistant strain of Staphylococcus. The incidence of bacteremia with abscess incision and drainage is very low, which is one reason why many do not prophylaxis in this setting.
A simplified strategy for antibiotic prophylaxis is provided in Table 156­7. With the endorsement of the National Institute for Health and Clinical

Excellence of London, the European College of Cardiology does not recommend prophylaxis before respiratory tract procedures, GI or GU
 procedures, or uncomplicated dermatologic or musculoskeletal procedures.
TABLE 156­7
Prophylaxis Against Endocarditis for Highest­Risk Patients
Antibiotic
Procedure Patient Characteristics Dose
Agent
Dental procedures involving manipulation of either Able to take oral antibiotics Amoxicillin  grams PO, 30– gingival tissue or the periapical region of teeth or  min before perforation of the oral mucosa procedure or
Unable to take oral medication Ampicillin  grams IM or
IV, 30–60 min before procedure or
Cefazolin or  gram IM or IV, ceftriaxone 30–60 min before procedure
Allergic to penicillins or ampicillin Cephalexin  grams PO, 30–
 min before procedure or
Clindamycin 600 milligrams
PO, 30–60 min before procedure or
Azithromycin 500 milligrams or PO, 30–60 min clarithromycin before procedure
Unable to take oral medication and allergic to penicillins or Cefazolin or  gram IM or IV, ampicillin ceftriaxone 30–60 min before procedure or
Clindamycin 600 milligrams
IM or IV, 30–60 min before procedure
Procedures on infected skin, skin structure, or Non–methicillin­resistant strain of Staphylococcus or β­ Dicloxacillin  grams PO, 30– musculoskeletal tissue hemolytic Streptococcus suspected  min before procedure or
Cephalexin  grams PO, 30–
 min before procedure
Patients unable to tolerate a β­lactam or who are known or Vancomycin  gram IV, 30–60 suspected to have an infection caused by a methicillin­ min before resistant strain of Staphylococcus procedure or
Clindamycin 600 milligrams
IM or IV, 30–60 min before procedure
Other procedures (respiratory; GI; GU; noninfected Prophylaxis dermatologic or musculoskeletal procedures) not indicated

With good aseptic technique, prophylactic antibiotics are not recommended prior to invasive procedures such placement of as central lines.
RISK OF ENDOCARDITIS RECURRENCE
Nearly 5% of patients with a single episode of endocarditis have repeat or relapse of endocarditis. Risk factors for repeat endocarditis include IV drug
  use and hemodialysis. Repeated episodes of endocarditis may require valvular repair or replacement.


