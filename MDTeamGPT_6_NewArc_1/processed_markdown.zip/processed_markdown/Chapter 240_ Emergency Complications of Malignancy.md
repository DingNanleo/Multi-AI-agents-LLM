## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 240: Emergency Complications of Malignancy
Patricia Brock; Maria T. Cruz­Carreras
INTRODUCTION
Content Update: Neutropenic Enterocolitis (Typhlitis) February 2021
Neutropenic enterocolitis, also called 'typhlitis' can develop after intensive chemotherapy. See clinical findings and general treatment under 'Febrile
Neutropenia; Evaluation.'
The incidence of cancer is increasing as the general population ages and individual longevity grows. More patients with active malignancy are likely to
 come to the ED for care because of this increase, coupled with more intensive and varied treatments being applied in the outpatient setting. Many
,3 conditions that prompt these patients to come to the ED will not be due to cancer. Conversely, there are disorders often or uniquely related to
4–7 malignancy that collectively are termed oncologic emergencies. These malignancy­related emergencies are broadly categorized as: (1) those due to local tumor effects, (2) those secondary to biochemical derangement, (3) those that are the result of hematologic derangement, and (4) those related to therapy (Table 240­1).
TABLE 240­1
Emergency Complications of Malignancy
Related to local tumor effects Malignant airway obstruction
Bone metastases and pathologic fractures
Malignant spinal cord compression
Malignant pericardial effusion with tamponade
Superior vena cava syndrome
Related to biochemical derangement Hypercalcemia
Hyponatremia due to inappropriate antidiuretic hormone secretion
Adrenal insufficiency
Tumor lysis syndrome
Related to hematologic derangement Febrile neutropenia and infection
Hyperviscosity syndrome
Thromboembolism
Related to therapy Chemotherapy­induced nausea and vomiting
Chemotherapeutic drug extravasation
Complications due to biologic therapy
EMERGENCIES RELATED TO LOCAL TUMOR EFFECTS

MChAaLpIteGrN 2A40N: TE mAeIRrgWenAcYy COoBmSpTlicRaUtioCnTs IoOf NMalignancy, Patricia Brock; Maria T. Cruz­Carreras 
. Terms of Use * Privacy Policy * Notice * Accessibility
Malignancy­related airway compromise is usually an insidious process that results from a mass originating in the oropharynx, neck, or superior
,8 mediastinum progressively obstructing airflow. Acute compromise may occur with supervening infection, hemorrhage, or loss of protective mechanisms, such as muscle tone. Iatrogenic factors, such as radiation therapy, may create additional difficulties by producing local inflammation with tissue breakdown. It is helpful to classify airway impairment due to malignant tumor obstruction in two manners, as to location—from the lips and nares to the vocal cords (upper airway) versus those from the vocal cords to the carina (central airway)—and as to nature of the obstruction
—endoluminal, extraluminal, or mixed. Almost regardless of the cause, airway obstruction usually presents with symptoms of shortness of breath and signs of tachypnea and stridor. The physical examination may show evidence of a mass in the pharynx, neck, or supraclavicular area.
,8
Patients with airway obstruction due to a malignant tumor are evaluated with a combination of plain radiographs, CT, and endoscopic visualization.
Direct laryngoscopy is discouraged because injudicious manipulation of the upper airway may convert a partial obstruction into a complete one by
 provoking bleeding or edema.
Emergency management includes the administration of supplemental humidified oxygen and maintenance of the best airway possible through patient positioning. Heliox—typically a 50:50 mixture of helium and oxygen—may provide symptomatic improvement in upper airway obstruction due to
 cancer when combined with other therapy. High­flow nasal oxygen administration can also bide time to definitive airway management.
Mechanical intervention for critical airway obstruction from a tumor is rarely required in the ED. For patients with critical upper airway obstruction, emergency transtracheal jet ventilation or cricothyroidotomy could be lifesaving if the obstruction is above the vocal cords (see Chapter , “Surgical
Airways”). However, the presence of an overlying tumor or swelling may render such procedures technically difficult. Alternatively, passage of the
,9 endotracheal tube beyond the area of obstruction is a consideration when the patient is progressing to complete airway occlusion. This is best done using awake fiberoptic intubation with a 5­0 or 6­0 endotracheal tube that is wire reinforced, if possible. Placement of such a tube can provide symptomatic relief and time until procedures with more sustained benefit can be performed.
The various procedures to relieve malignancy­related airway obstruction include placement of an expanding stent at the stenotic site, neodymiumyttrium­aluminum­garnet laser photoradiation or argon plasma coagulation for vaporization of obstructing tissue, and mechanical tumor resection;
11–13 these modalities are often combined. Alternatively, variations of radiotherapy, such as endobronchial brachytherapy, photodynamic therapy, and external­beam radiation therapy, can be directed to the obstructing tumor, but the time for symptomatic response is longer than that of the mechanical approaches of laser photoradiation and stenting.
BONE METASTASES AND PATHOLOGIC FRACTURES
Anatomic disruption of bone weakened by preexisting conditions is termed a pathologic fracture. Pathologic fractures due to malignancy most commonly affect the axial skeleton (calvarium included) and the proximal aspect of the limbs. Most pathologic fractures are due to metastases from
 solid tumors (e.g., breast, lung, prostate) that localize in areas of bones with high blood flow, identified as containing red marrow. Most patients with pathologic fractures have a known malignancy. Patients with bone metastases usually present with localized pain and a benign outward appearance of
 the involved area.
Malignancy alters the normal radiographic appearance of bone, including loss of trabeculae with indistinct margins (osteolytic, or “moth eaten”), poorly demarcated areas of increased density (osteoblastic), and/or a periosteal reaction. Plain radiographs may identify only about half of metastatic
 bone lesions, and advanced imaging is often required for accurate detection. CT with IV contrast, particularly when using reconstruction software, can visualize three­dimensional bone integrity and soft tissue extension, whereas MRI best detects small tumors and delineates soft tissue and bone marrow involvement. A total­body radionuclide bone scan can be used as a screening tool to identify areas of increased bone activity that could
 represent additional metastatic spread. However, areas of radionuclide localization on the bone scan are not specific for cancer, and additional imaging studies of these areas are necessary for confirmation.

Treatment priorities are pain relief and restoration or salvage of function. For acute pain or fracture, parenteral analgesics are recommended for rapid treatment. Patients with bone metastases often require long­acting oral opioids and other adjunctive medications for pain relief (see Chapter ,
“Chronic Pain”). Approximately 80% of painful bone metastases can be helped with palliative radiotherapy, although it may take several weeks after
  completion of a typical 5­day course of treatment to experience maximal benefit. The majority of pathologic fractures require open surgical repair.
MALIGNANT SPINAL CORD COMPRESSION
,5,7,19
Up to 20% of cancer patients will develop neoplastic involvement of the vertebral column, and 3% to 6% will develop spinal cord compression.
Most cases of malignant spinal cord compression are due to metastases to vertebral bodies from solid organ tumors, with the thoracic vertebrae being the most common location for such metastases. Spinal cord compression occurs when these metastases enlarge, erode through the vertebral cortex into the spinal canal, and compress on the spinal cord. Less common causes of malignant spinal cord compression include local spread from paraspinal tumors through the intervertebral foramen or tumors (primary or metastatic) directly involving the spinal cord or meninges.

Approximately 90% of patients with malignant spinal cord compression will have back pain (Table 240­2). Such pain is often described as unrelenting, progressive, worse when supine, and located in the thoracic vertebral area. Approximately 80% of patients with malignant spinal cord compression have a prior diagnosis of cancer, so individuals with known cancer and back pain should undergo radiographic imaging. Other symptoms of malignant spinal cord compression may include muscular weakness, radicular pain, and bladder or bowel dysfunction. Weakness is most apparent in the proximal extremity musculature and may progress to complete paralysis. Sensory changes initially may be confined to a band of hyperesthesia around the trunk at the involved spinal level and that eventually becomes anesthetic distal to the level. Urinary retention (with overflow incontinence), fecal incontinence, and impotence are late manifestations.
TABLE 240­2
Malignant Spinal Cord Compression
Suspect Patient with known cancer: especially lung, breast, prostate
Thoracic location: 70%
Progressive pain and worse when supine
Motor weakness: proximal legs
Sensory changes: initially radicular, later distal anesthesia
Bladder or bowel dysfunction: late findings
Imaging Plain radiographs: may detect vertebral body metastases but less sensitive and specific for malignant spinal cord compression
MRI: modality of choice, preferably with contrast; image entire vertebral column
CT myelography: used when MRI not available or accessible
Corticosteroids Dexamethasone,  milligrams IV followed by  milligrams PO or IV every  h
Consider starting in ED if imaging is delayed
Radiotherapy Standard approach, beneficial in approximately 70%
No specific radiotherapy regimen proven superior
Prognosis highly dependent on pretreatment neurologic function
Surgery Consider in highly selected cases, such as the following:
Patient in good general condition and able to undergo extensive surgery
Appropriate prognostic life expectancy
Rapidly progressive symptoms
Clinical worsening during radiotherapy
Unstable vertebral column
MRI preferably with contrast is the imaging modality of choice to localize the site, define the degree of cord compression, and identify additional vertebral lesions. The entire spinal column is imaged due to the potential for multiple level involvement. CT with or without myelography is used when
MRI is contraindicated or inaccessible. Plain radiography may identify an abnormality in approximately 80% of patients with painful vertebral metastases. However, plain radiographs are less useful in patients with suspected malignant spinal cord compression, because radiographic findings do not always correlate with the level of spinal cord compression, and causes of malignant spinal cord compression other than vertebral body metastases will not produce visible changes in vertebral body radiographic appearance.
Use opioid analgesics for initial pain control. Consider administration of corticosteroids in the ED, especially if there will be a delay in MRI or CT
,5,7,19 myelography. Typically dexamethasone,  milligrams IV bolus, followed by  milligrams PO or IV every  hours, is used. Further treatment, with continued corticosteroids, radiation therapy, surgery, or a combination of modalities, will depend on the life expectancy of the patient, extent of
 disease, and degree of motor impairment. Radiation therapy has been the typical treatment for patients with malignant spinal cord compression,
,21 and a beneficial response is seen in approximately 70% of those treated. The overall prognosis for those treated with radiotherapy is highly dependent on pretreatment functional ability; approximately 90% of those who can walk at the time of diagnosis remain ambulatory after radiation treatment, about half of those who have motor function but cannot walk will recover ambulatory ability with radiotherapy, but few patients with
 complete paraplegia at the time of diagnosis will recover lower extremity motor function. Select patients with malignant spinal cord compression
,20 may benefit from surgical tumor resection, including those with neurologic impairment (Table 240­2). Because of the complex decision making from among the therapeutic options, specialists in oncology, radiotherapy, and spinal surgery should be consulted early.
MALIGNANT PERICARDIAL EFFUSION WITH TAMPONADE
Pericardial involvement, often with effusion, occurs in up to 35% of patients with all types of cancer, although the effusions are often small and remain
,5,7,23 undiagnosed. Symptomatic pericardial effusions occur less frequently and usually result from lung or breast cancer. Other etiologies for pericardial effusions in patients with malignant disease include other tumor types (such as melanoma, leukemia, or lymphoma) and a complication of treatment (radiotherapy or chemotherapy).
Symptoms and physical examination findings are a function of pericardial fluid accumulation rate and volume (see Chapter , “Cardiomyopathies and
Pericardial Disease”). Large effusions can develop gradually and are surprisingly well tolerated. Symptoms of a pericardial effusion include dyspnea, orthopnea, chest pain, dysphagia, hoarseness, and hiccups. Physical findings include distant cardiac sounds, jugular venous distention, and a pulsus paradoxus.
A sudden increase in fluid between the nondistensible pericardium and compressible heart creates a cardiac tamponade: the low­pressure right heart is unable to accept vena caval return or pump forward to the pulmonary arteries, and the left ventricle cannot fill or produce a sustainable ejection fraction. Signs and symptoms include accentuation of those noted with pericardial effusion with additional manifestations of circulatory shock. There is usually tachycardia, hypotension, and a narrowed pulse pressure.
The ECG may demonstrate reduced voltage in the QRS complex throughout all leads, a reflection of the insulating characteristics of the effusion.
Electrical alternans is a classic, although infrequent, finding with a large pericardial effusion. The cardiac silhouette on chest radiography may appear large, reflecting the gradually accumulated effusion in the stretched pericardial sac. Echocardiography is the diagnostic tool of choice, being noninvasive, portable, and highly accurate in trained hands. Echocardiography can not only detect the presence of a significant pericardial effusion, but also assess cardiac function and identify physiologic changes associated with cardiac tamponade.
Asymptomatic pericardial effusions do not require specific treatment. Patients with symptomatic effusions should undergo pericardiocentesis, ideally with echocardiographic guidance (see Chapter , “Pericardiocentesis”). Most often, this procedure can await the arrival of the specialist and transport of the patient to the appropriate procedural area. If patients with cardiac tamponade require emergent pericardiocentesis in the ED, use bedside US to guide needle direction during the procedure.

Malignant pericardial effusions are treated depending on the tumor type and overall patient condition. Reduction in fluid production can be done by treating the tumor with appropriate systemic chemotherapy or radiotherapy. Intrapericardial chemotherapy may be useful in tumors sensitive to these agents. A pericardial window or partial pericardial resection can be done to prevent accumulation of fluid within the pericardial space. A percutaneous
 indwelling intrapericardial catheter can also prevent accumulation of fluid, but with the risks associated with percutaneous devices. Malignant pericardial effusion typically indicates the presence of advanced disease, and most patients die within  year after diagnosis.
SUPERIOR VENA CAVA SYNDROME
The term superior vena cava (SVC) syndrome describes the clinical effects of elevated venous pressure in the upper body that result from obstruction
,5,7,25,26 of venous blood flow through the SVC. This syndrome is classically caused by external compression of the SVC by an extrinsic malignant mass.
The most common tumors associated with malignant SVC syndrome are lung cancer in 70% and lymphoma in approximately 20%. Benign conditions and intravascular thrombosis (precipitated by indwelling vascular catheters or pacemaker leads) currently account for about one third of all SVC syndrome cases. SVC syndrome rarely constitutes an emergency; the vast majority of patients do not materially deteriorate during the initial  to  weeks after diagnosis. The exception is when neurologic abnormalities are present due to increased intracranial pressure.
Symptom development correlates roughly with the severity of obstruction and the rate of narrowing. If compression occurs over weeks, collateral vessels dilate to compensate for impaired flow through the SVC. Most patients will describe symptoms developing a few weeks before seeking medical attention. Clinical manifestations correlate with a jugular venous pressure of  to  mm Hg (2.7 to .4 kPa), as compared with a normal range of  to 
,26 mm Hg (0.3 to .0 kPa). The most common symptoms are facial swelling, dyspnea, cough, and arm swelling. Less common symptoms include hoarse voice, syncope, headache, and dizziness. In rare but extreme cases, venous obstruction can lead to increased intracranial pressure that produces visual changes, dizziness, confusion, seizures, and obtundation. Physical examination findings may show swelling of the face and arm, sometimes with a violaceous hue or plethora, and distended neck and chest wall veins.
The plain chest radiograph will usually show a mediastinal mass in cases of malignant SVC syndrome. CT of the chest with intravascular contrast is the
,26 recommended imaging modality to assess the patency of the SVC. MRI is useful for patients who cannot receive IV contrast. Contrast venography is rarely needed, except in uncertain cases or as part of an intravascular interventional procedure. In patients with a known diagnosis of lung cancer, biopsy for pathologic confirmation of a malignancy is usually not required. For patients without a known intrathoracic cancer, tissue confirmation of a
 malignant cause is highly desirable before initiation of radiotherapy and required before initiation of chemotherapy.
Initial management is with head elevation to decrease venous pressure in the upper body and supplemental oxygen to reduce the work of breathing.
Corticosteroids and loop diuretics are commonly used, but there is no evidence that they contribute to clinical improvement, with the exception that corticosteroids would be expected to be helpful when the cause of the obstruction is lymphoma.
Radiation therapy is effective in reducing symptoms in approximately 75% of patients with SVC syndrome, reflecting the approximate incidence of
 radiosensitive tumors producing this disorder. Many patients will experience a reduction in symptoms within  days after the start of radiation treatment.
,27
Intravascular stents, with or without angioplasty, can be used to reduce obstruction to SVC flow. These stents appear to produce a more rapid improvement in symptoms and signs compared with radiotherapy or chemotherapy, suggesting a preferential benefit in patients with severe
,27 manifestations who require urgent treatment. Stent placement should also be considered for malignant causes that do not respond well to radiotherapy or chemotherapy (e.g., mesothelioma), for benign causes (e.g., fibrosing mediastinitis), or for intravascular thrombosis associated with
 an indwelling catheter.
Chemotherapy is effective in producing symptomatic relief from SVC syndrome in approximately 80% of patients with lymphoma, 80% of patients with small­cell lung cancer, and 40% of patients with non–small­cell lung cancer.

Patients with SVC syndrome due to intravascular thrombosis can be treated with catheter­directed fibrinolytics. Removal of an inciting intravascular object, such as a central venous catheter, should be considered. Postfibrinolytic anticoagulation is generally recommended to prevent recurrence,
 although there is no firm supporting evidence. For cancer patients with an indwelling central venous catheter, prophylactic low­molecular­weight heparin decreases the incidence of symptomatic catheter­related venous thromboembolism for up to  months, but its use must be balanced by the
 potential harms of anticoagulation.
Recurrence of SVC syndrome is seen in approximately 20% of lung cancer patients treated with radiotherapy and/or chemotherapy and 10% treated
 with intravascular stents. For patients with malignant SVC syndrome, survival is dependent on the causative cancer; with lung cancer, median survival is approximately  to  months.
EMERGENCIES RELATED TO BIOCHEMICAL DERANGEMENT
HYPERCALCEMIA

Hypercalcemia is seen in 5% to 30% of patients with advanced cancer at some time during their disease course. Breast cancer, lung cancer, and multiple myeloma are the malignancies most commonly associated with hypercalcemia. The three primary mechanisms whereby malignancy produces hypercalcemia are: (1) most commonly by production of a parathyroid hormone–related protein that is structurally similar to parathyroid hormone so that calcium is mobilized from bones and its renal reabsorption is increased; (2) by extensive local bone destruction associated with osteoclastactivating factors seen in lung and breast cancer and multiple myeloma; and (3) by production of vitamin D analogs, usually in lymphomas.
Classic symptoms of hypercalcemia include lethargy, confusion, anorexia, and nausea (see Chapter , “Fluids and Electrolytes”). Because most patients with hypercalcemia due to malignancy have advanced cancer, symptoms of general debility due to tumor may be difficult to distinguish from those caused by hypercalcemia. Hypercalcemia reduces intestinal motility, so constipation is common, although that symptom can be produced by concomitant opioid therapy for pain. Hypercalcemia produces an osmotic diuresis, so some of the nonspecific symptoms can be due to relative hypovolemia. Clinical symptoms of hypercalcemia are most often correlated with the rate of rise in the serum calcium level, as opposed to the actual calcium level. Therefore, slow increases in serum calcium may be relatively asymptomatic until reaching high levels.
Hypercalcemia does not always require treatment, especially if the patient is asymptomatic and well hydrated and the total serum calcium is less than
 milligrams/dL (3.5 mmol/L). The initial treatment of symptomatic hypercalcemia is with IV isotonic saline according to the patient’s initial volume
,7 status followed by a rate adjusted to the ability of the patient’s cardiovascular system to tolerate a volume load (Table 240­3). IV saline will result in clinical improvement and a modest decrease in the plasma calcium over  to  hours, but rarely normalizes the level. Furosemide is useful in patients with heart failure or renal insufficiency to prevent volume overload from normal saline infusion, but has little additive effect to the use of IV saline alone in the treatment of hypercalcemia in patients with normal cardiac and renal function. Therefore, furosemide is not routinely recommended in the treatment of hypercalcemia due to malignancy.
TABLE 240­3
Treatment of Cancer­Associated Hypercalcemia7
Intervention Dosage Comments
Normal saline If hypovolemic: 1­ to 2­L initial bolus over  h Adjust the infusion rate according to the patient’s cardiovascular
If euvolemic: 250–500 mL/h IV for  L, followed by 100–150 mL/h status
IV
Furosemide 20–40 milligrams IV Use only for patients with volume overload after volume expansion
Pamidronate 60–90 milligrams IV over 2–4 h Use with caution in renal insufficiency
Onset of action may take days
Zoledronic acid  milligrams IV over  min Use with caution in renal insufficiency
Onset of action may take days
Short infusion time is an advantage over pamidronate
Calcitonin 4–8 IU/kg SC or IV every  h Rapid onset of action but short lived (about  d)
Use when prompt reduction of calcium level is needed
Glucocorticoids Prednisone  milligrams PO daily Used for hypercalcemia due to lymphomas and multiple or myeloma
Hydrocortisone 100 milligrams IV every  h
Denosumab 120 milligrams (or .3 milligram/kg) SC weekly for  wk, then every Used in hypercalcemia refractory to bisphosphonate therapy
 wk Can cause symptomatic hypocalcemia
Because the initial priority is restoration of intravascular volume with IV saline, pharmacologic treatment of hypercalcemia is usually not initiated in the
,7
ED. Bisphosphonates, such as pamidronate or zoledronic acid, are the recommended agents to treat malignancy­associated
,7,29 hypercalcemia. Bisphosphonates are potent inhibitors of bone resorption and produce a sustained decrease in calcium  to  hours after administration, with the effect lasting for approximately  to  weeks. Bisphosphonates are given by slow IV infusion to prevent precipitation of bisphosphonate–calcium complexes in the kidney and subsequent renal failure.
Other agents have a limited role in the treatment of malignancy­induced hypercalcemia. Calcitonin lowers plasma calcium within  to  hours, but it may cause a hypersensitivity response, and tachyphylaxis develops within  days, so the beneficial effect is short lived. Calcitonin is only used when
 prompt reduction of calcium levels is needed. Glucocorticoids, such as prednisone  milligrams PO daily, may be helpful with steroid­sensitive
,7,29 tumors, such as lymphomas and multiple myeloma. Denosumab, a humanized monoclonal antibody that inhibits osteoclast activity and function, is approved for hypercalcemia refractory to bisphosphonate therapy.
Hemodialysis can be used to treat hypercalcemia and is indicated for those with profound mental status changes or renal failure or those unable to tolerate a saline load.
HYPONATREMIA DUE TO INAPPROPRIATE ANTIDIURETIC HORMONE SECRETION
Inappropriate secretion of antidiuretic hormone is most commonly associated with bronchogenic cancer, but may be seen in other malignancies and
,30,31 can also occur from chemotherapy, opioids, carbamazepine, and selective serotonin reuptake inhibitors. Regardless of the etiology, the syndrome of inappropriate antidiuretic hormone consists of hyponatremia, decreased serum osmolality, and less than maximally dilute urine, all in the presence of euvolemia, absence of diuretic therapy, and normal renal, adrenal, and thyroid function (see Chapter 17). Syndrome of inappropriate antidiuretic hormone secretion should be suspected if a patient with cancer presents with normovolemic hyponatremia.
Signs and symptoms of hyponatremia are primarily neurologic and correlate with severity and with rapidity of development. Anorexia, nausea, and malaise are the earliest findings, followed by headache, confusion, obtundation, seizures, and coma. Seizures are usually generalized tonic­clonic in nature; focal seizures are uncommon from hyponatremia, and their occurrence suggests focal CNS lesions. Life­threatening symptoms are almost invariably associated with sodium concentrations <110 mEq/L (<110 mmol/L).
Water restriction is the mainstay of treatment in euvolemic asymptomatic patients. Patients with sodium levels >125 mEq/L (>125 mmol/L) are generally asymptomatic and can be managed with water restriction of 500 mL/d and close follow­up. More severe hyponatremia—serum sodium between 110 and 125 mEq/L with mild to moderate symptoms—may require furosemide .5 to .0 milligram/kg PO with concomitant IV normal saline to maintain euvolemia and effect a net free water clearance.
For severe hyponatremia—serum sodium <110 mEq/L, usually with coma or repetitive or sustained seizures—infuse 3% hypertonic saline (510 mEq/L) 100 mL over  to  minutes. Then reassess patient and measure serum sodium. If symptoms have not resolved or the serum sodium has not increased by  mEq/L, one or two additional doses of 3% hypertonic saline may be necessary (see Chapter 17).
ADRENAL INSUFFICIENCY
Adrenal insufficiency associated with malignancy may be secondary to adrenal tissue replacement by metastases, but is more commonly due to abrupt physiologic stress in the face of chronic glucocorticoid therapy with pharmacologic adrenal suppression (see Chapter 230, “Adrenal
,33 
Insufficiency”). The subsequent vasomotor collapse may be sudden and severe. Clues for acute adrenal insufficiency include mild hypoglycemia, hyponatremia, and hypotension refractory to volume loading and vasoconstrictor therapy.
Obtain a serum cortisol level, institute IV rehydration with normal saline, and administer stress doses of steroids, such as hydrocortisone 100 milligrams IV or dexamethasone  milligrams IV (see Chapter 230). The steroid­dependent patient will need increased doses of steroids during the
 acute illness, typically three times the daily maintenance dose of glucocorticoid.
TUMOR LYSIS SYNDROME
,7,34
Tumor lysis syndrome is a metabolic crisis resulting from massive cytolysis and release of intracellular contents into the systemic circulation. Of particular concern are the individual ions (potassium, phosphate, calcium), nucleic acids (which metabolize to uric acid), and intracellular proteins.
Tumor lysis syndrome most commonly occurs with treatment of hematologic malignancies because of rapid cell turnover and growth rates, bulky tumor mass, and high sensitivity to antineoplastic agents. Tumor lysis syndrome is uncommon with solid tumors or without prior therapy
(“spontaneous tumor lysis syndrome”).
The manifestations of tumor lysis syndrome can be categorized by clinical effects (acute kidney injury, seizure, cardiac dysrhythmia, or arrest) and laboratory abnormalities (hyperuricemia, hyperkalemia, hyperphosphatemia, or hypocalcemia). Renal failure is the strongest predictor of morbidity in tumor lysis syndrome and usually results from uric acid precipitation within the renal tubules. Phosphorus released from tumor cells may combine with calcium and precipitate in renal tubules and parenchyma as well. Hypovolemia may contribute to the renal impairment seen with tumor lysis syndrome. The release of intracellular potassium can produce acute hyperkalemia and provoke or contribute to cardiac dysrhythmias or cardiac arrest. Because malignant cells can contain fourfold the amount of phosphorus as normal cells, the abrupt release of extensive phosphate into the circulation may produce a decrease in serum calcium. The resultant hypocalcemia may induce tetany and seizures and contribute to dysrhythmias.
Recognize the potential for tumor lysis syndrome with treatment of hematologic malignancies. Prophylactic allopurinol and maintaining good hydration can reduce the risk of tumor lysis syndrome developing. Patients with established tumor lysis syndrome may experience sudden electrolyte changes and life­threatening complications, so admission to an intensive care unit with cardiac rhythm monitoring is indicated. Aggressive IV fluid
,34 administration to increase urinary excretion of the released intracellular solutes is the cornerstone for treatment of tumor lysis syndrome.
Increased urine flow will counteract the precipitation of urate and calcium phosphate crystals in the renal tubules.
Hyperkalemia is the most immediate life­threatening element with tumor lysis syndrome because of induced cardiac dysrhythmias and cardiac
,34 arrest. Treatment is identical to other causes of hyperkalemia: β­adrenergic agonists, sodium bicarbonate, and dextrose­insulin therapy (see
Chapter 17). Avoid calcium administration unless there is cardiovascular instability (ventricular dysrhythmias or wide QRS complexes) or neuromuscular irritability (seizures) because supplemental calcium may cause metastatic precipitation of calcium phosphate. Hyperphosphatemia is managed with phosphate binders (limited effect) or by the administration of dextrose and insulin. Hemodialysis can correct all biochemical abnormalities of tumor lysis syndrome, although a large phosphate burden may require repeat frequent and prolonged dialysis sessions or
,34 continuous renal replacement therapy.
EMERGENCIES RELATED TO HEMATOLOGIC DERANGEMENT
FEBRILE NEUTROPENIA AND INFECTION
,36
Infections are a common source of morbidity and mortality in patients with malignancies. A common feature associated with the increased risk of
,36 infection in these patients is the presence of impaired immunity, especially neutropenia. For clinical decision making, neutropenia is defined as an
    absolute neutrophil count <1000/mm (<1.0 ×  /L), severe neutropenia is defined as an absolute neutrophil count <500/mm (<0.5 ×  /L), and
  profound neutropenia is defined as an absolute neutrophil count <100/mm (<0.1 ×  /L). Fever is defined for the purposes of clinical decision making as a temperature of .3°C (100.9°F) on one occasion or .0°C (100.4°F) persisting >1 hour.
Neutropenia in cancer patients is most commonly caused by chemotherapy, with the lowest neutrophil count typically seen  to  days after the last
36–38 chemotherapeutic dose and recovery usually seen within  days afterward. The risk of developing an infection primarily depends on the severity
,7,36,37 and duration of neutropenia. Comorbid conditions and other circumstances, such as indwelling devices, also contribute to the risk.
Fever is the most common finding seen with bacterial infections in the neutropenic patient. Common symptoms and signs that usually localize the infectious source are often absent or muted in the neutropenic patient because the lack of neutrophils impairs the inflammatory response and
 diminishes the occurrence of expected findings. Thus, a pulmonary infection may have minimal cough, have no productive phlegm, and lack radiographic infiltrates. A kidney infection may not produce pyuria.
Evaluation
Perform a careful physical examination, with attention to three areas typically overlooked in routine examination: the oral cavity, the perianal area, and entry sites of intravascular catheters. Digital rectal examination is relatively contraindicated in neutropenic patients—withhold until after initial antibiotic administration. Evaluate the entry sites of IV and tunneled catheters for evidence of infection. Clotted catheters represent a high risk of infection due to bacterial colonization, and central venous catheters may cause endocarditis.
36–39
Because localizing signs and symptoms of a specific infection are often lacking, an evaluation for an occult infection is indicated. Obtain two blood culture samples, with one from a central catheter, if present. A urinalysis, urine culture, and chest radiograph should be performed. Sputum, stool, and wound drainage Gram stain and culture should be obtained if productive cough, diarrhea, or wound drainage, respectively, are present. Assess serum electrolyte levels, renal function, and hepatic function.
Neutropenic enterocolitis (also called 'typhlitis') is an acute polymicrobial inflammatory disorder of the cecum that can spread to the ascending colon. This condition is seen in patients with mucosal injury and neutropenia, especially hematologic malignancies, and usually resulting from cytotoxic chemotherapy or radiation. The presentation is usually fever, bloody diarrhea, and diffuse or right lower quadrant abdominal pain, with onset typically two weeks after intensive chemotherapy. Oral or anal mucositis may be present. CT criteria for diagnosis include bowel wall thickening
(>4mm and  mm in length), mesenteric stranding, bowel dilatation, and pneumatosis. Differential diagnosis includes C. difficile infection,
Cytomegalovirus colitis, graft vs host disease in transplanted patients, and ischemic colitis. Initial management is by fluid resuscitation, electrolyte correction, bowel decompression, and broad­spectrum antibiotics. Treatment is medical and surgical, so obtain early surgical consultation. Mortality is between 30­50% from perforation, with peritonitis and sepsis; or massive GI bleeding.
Assessment
If an infectious source is found, therapy and disposition are guided by the presumed pathogens and the expected clinical course. If, after assessment, no localized infection can be found, the two major clinical decisions are: (1) Does this patient require hospitalization, and (2) should empiric antibiotics be started? To assist in addressing both these questions, consult with the patient’s oncologist.
Although hospitalization enhances the ability to reassess the patient and intervene early if a severe infection or clinical deterioration develops, hospitalization exposes the immunocompromised patient to hospital flora that is often drug resistant. Patients who appear well, have no abdominal pain, have no physical signs of infection, have a normal chest radiograph, and are expected to resolve their neutropenia within  days have a low risk of
36–38 severe infection and can be considered for outpatient care.
High­risk febrile neutropenic patients for whom hospitalization is recommended are defined by one or more of the following features: profound neutropenia expected to last >7 days, comorbid medical conditions, acute liver or renal injury, or non–low­risk scores by the Multinational Association
,36,40­42 for Supportive Care in Cancer Risk Index or Clinical Index of Stable Febrile Neutropenia tool.
Treatment
Empiric broad­spectrum antibiotics are used in febrile neutropenic patients when the benefits of early treatment are greater than the adverse side
36–39 effects associated with such drugs. Clinical evidence consistently supports the benefits of empiric antibiotics when the absolute neutrophil count is ≤500/mm  (<0.5 ×   /L). There is little convincing evidence for empiric antibiotics when the absolute neutrophil count is

>1000/mm (>1.0 ×  /L). For neutrophil counts between 500 and 1000/mm (0.5 and .0 ×  /L), use other risk factors for bacterial infection to make
36–38 the decision regarding empiric antibiotics.
36–38,43
Administer the initial empiric antimicrobial therapy to cover the range of potential bacterial pathogens (Table 240­4). No specific antibiotic regimen has proven consistently superior in clinical trials, and monotherapy with an appropriate broad­spectrum agent is as effective as dual­agent treatment in most circumstances. If there is no known colonization with multidrug­resistant bacteria or colonization with vancomycin­resistant
 enterococci, initial treatment should be with a Pseudomonas­active β­lactam. Add vancomycin in the following situations: hemodynamic instability, catheter­related infection, skin or soft tissue infection, known colonization with resistant gram­positive organism, or severe mucositis when
 fluoroquinolone prophylaxis was recently used. If there is a history of colonization with extended­spectrum β­lactamase–producing enterobacteria,
 initial treatment should be with imipenem or meropenem.
TABLE 240­4
Empiric Antibiotic Therapy in Febrile Neutropenia
Situation Drug (Adult Dose) Comments
Outpatient Ciprofloxacin 500 milligrams PO every  h For low­risk patients with daily assessments by a medical provider for the initial or  d
Levofloxacin 750 milligrams PO daily plus
Amoxicillin/clavulanate 500/125 milligrams PO every  h or 1000/62.5 milligrams PO twice daily or
Clindamycin 300 milligrams PO every  h
Monotherapy Piperacillin/tazobactam .5 grams IV every  h If no known colonization with multidrug­resistant bacteria or colonization with or VRE, use piperacillin/tazobactam, cefepime, or ceftazidime
Cefepime  g IV every  h If known colonization with ESBL­E, use imipenem/cilastatin or meropenem or
Ceftazidime  g IV every  h or
Imipenem/cilastatin  g IV every  h or
Meropenem  g IV every  h
Dual therapy One of the monotherapy agents Increased risk of adverse effects plus Add if hemodynamic instability, catheter­related infection, cellulitis, or known
Vancomycin  gram IV every  hours colonization with MRSA
Or If abdominal symptoms are present
Metronidazole  gram IV, followed by 500 milligrams
IV every  h
Abbreviations: ESBL­E = expended­spectrum β­lactamase–producing enterobacteria; MRSA = methicillin­resistant Staphylococcus aureus; VRE = vancomycinresistant enterococci.
The median duration of fever after initiation of empiric antibiotics is  days in low­risk patients and  to  days in high­risk patients. Therefore, continue initial empiric antibiotic therapy for  to  days before assessing clinical response and making therapeutic adjustments. Adjustments may be made earlier if clinical deterioration occurs or culture results become available. Continue empiric antibiotics until the documented infection has
  36–38 clinically resolved and/or the patient has been afebrile for  days and the absolute neutrophil count is >500/mm (>0.5 ×  /L).
HYPERVISCOSITY SYNDROME

Hyperviscosity syndrome is a pathologic condition in which blood is “thicker” than normal and its flow is impaired. Blood viscosity depends on its plasma and cellular contents, and dehydration exacerbates hyperviscosity. Abnormal plasma contents that most commonly produce hyperviscosity are

Waldenström’s macroglobulinemia and immunoglobulin A–producing myeloma. Hyperproduction of any cell line can lead to hyperviscosity.

Polycythemia (with a hematocrit >60%) and leukemia (with a WBC count >100,000/mm [>100 ×  /L] or a leukocrit >10%) are often are associated with
 clinically significant hyperviscosity.
,46
Initial symptoms are vague and may include fatigue, abdominal pain, headache, blurry vision, or, most commonly, altered mental status.
Cutaneous or mucosal bleeding is common. Intravascular thrombosis may occur, with the creation of focal or unusual findings. Patients with hyperleukocytosis often report dyspnea and fever. Funduscopic findings include retinal venous engorgement appearing as linked sausages, along with exudates, hemorrhages, and papilledema.
Laboratory findings suggesting hyperviscosity include rouleaux formation (red cells stacked like coins) on a peripheral blood smear and being unable to perform chemical testing due to serum stasis in the laboratory analyzers. Laboratory testing of blood viscosity is usually done on plasma or serum,
 and specific analytic methodology varies. A common approach is to report the viscosity of the sample as a ratio to that of water; normal plasma
 viscosity is .7 to .1 and normal serum viscosity is .4 to .8, compared with water. Symptomatic patients usually have a serum viscosity >4. Laboratory measurement of plasma or serum viscosity will not identify hyperviscosity from polycythemia or leukemia.
44–46
Initial therapy is intravascular volume repletion, early involvement of a hematologist, and emergency plasmapheresis or leukapheresis. If coma is present and the diagnosis established, a temporizing measure can be a 2­unit (1000­mL) phlebotomy with concomitant volume replacement using  to
 L of normal saline. Transfusion of red blood cells should be done with caution because such treatment may increase blood viscosity. Long­term management is appropriate chemotherapy.
VENOUS THROMBOEMBOLISM
47–49
Venous thromboembolism occurs with all tumor types and is the second leading proximate cause of death in cancer patients. Symptomatic deep
,48 venous thrombosis occurs in approximately 15% of all patients with cancer and up to 50% of those with advanced malignancies. Multiple factors
 contribute to an increased risk for venous thromboembolism. The tumor may release procoagulant factors or inflammatory cytokines that directly activate the coagulation system. Large tumors may cause venous obstruction and promote thrombosis. Impaired production of proteins C and S and antithrombin can produce a hypercoagulable state. Surgery with attendant postoperative immobilization or long­term central venous catheterization can incite thrombosis. Chemotherapy or hormonal therapy for breast cancer increases the risk for thromboembolism. The angiogenesis inhibitors
,48 thalidomide, sunitinib, and bevacizumab are associated with significant thrombotic risks.
Low­molecular­weight heparin is recommended as the initial treatment in cancer patients with venous thromboembolism, both
50–53 ,53 deep venous thrombosis and pulmonary embolism. Unfractionated heparin and fondaparinux are acceptable alternatives. Continued treatment with low­molecular­weight heparin for at least  to  months is recommended because of better efficacy in preventing recurrent
51–54 thromboembolic events compared to vitamin K antagonists. Direct­acting oral anticoagulants are not recommended for treatment of venous thromboembolism in patients receiving active treatment for their cancer, but can be considered for use after the initial treatment
,55 with low­molecular­weight heparin of  days to  months in patients with stable cancer not receiving anticancer therapy.
EMERGENCIES RELATED TO THERAPY
CHEMOTHERAPY­INDUCED NAUSEA AND VOMITING
Nausea and vomiting can be debilitating to an already compromised patient. Most IV chemotherapeutic agents are emetogenic, so antiemetics are
,57 commonly administered on the day of therapy and for  to  days afterward based on the emetogenic potential of the agent. Antiemetics used for
56–58 chemotherapy­induced vomiting include neurokinin­1 receptor antagonists, serotonin receptor antagonists, and corticosteroids (Table 240­5).
,58
For refractory nausea and vomiting, benzodiazepines, dopamine receptor antagonists, or antipsychotic agents are added.
TABLE 240­5
Antiemetic Agents for Chemotherapy­Induced Vomiting
Class and Adult Dose Comments
Agent
Neurokinin­1 Receptor Antagonists
Aprepitant 125 milligrams PO, followed by  Half­lives: aprepitant = 9–13 h; fosaprepitant = 9–13 h; netupitant =  h; rolapitant = 169– milligrams PO on days  and  183 h
Common adverse effects: fatigue, neutropenia, abdominal pain, bradycardia, hypotension,
Fosaprepitant 150 milligrams IV headache, cough, decreased appetite, pruritus, and insomnia
Netupitant 300 milligrams plus palonosetron .5 milligram PO
Rolapitant 180 milligrams PO
Serotonin Receptor Antagonists
Granisetron  milligram IV Common reactions: headache, abdominal pain
Serious reactions: serotonin syndrome, QT interval prolongation
Ondansetron  milligrams IV Half­lives vary from  h for ondansetron,  h for granisetron, and  h for palonosetron
Palonosetron .25 milligram IV
Tropisetron*  milligrams IV
Ramosetron* .3 milligram IV
Corticosteroids
Dexamethasone 8–12 milligrams IV Mechanism unknown
Benzodiazepines
Lorazepam 1–2 milligrams IV Sedation, half­life  h
Midazolam  milligram IV or  milligrams IM Sedation, half­life 2–3 h
Dopamine Receptor Antagonists
Metoclopramide  milligrams IV or IM Dose­related extrapyramidal side effects, half­life 5–6 h
Prochlorperazine 5–10 milligrams IV or IM Extrapyramidal side effects, half­life  h
Antipsychotics
Olanzapine  milligrams PO or IM Not FDA approved for this indication, half­life 21–54 h
Abbreviation: FDA = U.S. Food and Drug Administration.
*Not available in the United States.
,59
Chemotherapy­induced vomiting can be anticipatory, acute, or delayed. Anticipatory vomiting is a conditioned reflex where vomiting occurs prior to administration of the chemotherapeutic agent. Acute vomiting occurs during the first  hours with maximal intensity at  to  hours after administration. Delayed vomiting has maximal intensity  to  hours after administration and can last up to  days.
For patients receiving highly emetogenic chemotherapy, the three­drug combination of a neurokinin­1 receptor antagonist (days  through  for aprepitant; day  only for fosaprepitant), a serotonin receptor antagonist (day  only), and dexamethasone (days  through  or 4) is recommended.
For moderately emetogenic chemotherapy, the two­drug combination of palonosetron (day  only) and dexamethasone (days  through 3) is
 recommended. For low emetogenic agents, a single dose of dexamethasone  milligrams IV before chemotherapy is suggested. For delayed
 chemotherapy­induced vomiting, the neurokinin­1 receptor antagonists are recommended.
EXTRAVASATION OF CHEMOTHERAPEUTIC AGENTS
Most chemotherapeutic agents cause local tissue reaction when extravasated, but the agents associated with significant tissue damage are the
60–63 vesicants primarily in the anthracycline, taxane, platin salt, and vinca alkaloid classes. Clinical manifestations of chemotherapeutic drug extravasation include pain, erythema, and swelling, usually within hours of the infusion. Occasionally, clinical signs may be delayed if only a small amount of highly cytotoxic drug is extravasated. Serious injury produces blistering, induration, ulceration, and necrosis over a few days to weeks.
If extravasation happens to occur through an active peripheral line, the infusion is stopped and aspiration through the line is attempted and continued
,63 while the catheter is removed. Aspirate palpable cutaneous blebs containing the extravasated chemotherapeutic agent. Elevate and immobilize the affected limb. Cooling or warming is beneficial for some agents (Table 240­6). Consult with the oncologist for treatment recommendations. Early referral to a plastic surgeon is suggested for anthracyclines and vinca alkaloids.
TABLE 240­6
Antidotes for Selected Extravasated Chemotherapeutic Drugs
Drug Antidotes Comments
Anthracyclines (daunorubicin, doxorubicin, epirubicin, and idarubicin) Dry cooling Initially  h, then  min several times per day
Hold during dexrazoxane infusion
Dexrazoxane IV infusion within  h; repeat doses at  and  h
Dimethyl sulfoxide Apply over involved area; repeat 4–6 times per day for ≥7 d
Vinca alkaloids (vincristine and vinblastine) Dry warming Do not press or rub area
Hyaluronidase Inject in and around extravasated area
Mitomycin, cisplatin, mechlorethamine Dry cooling Initially  h, then  min several times per day
Dimethyl sulfoxide Apply over involved area; repeat 4–6 times per day for ≥7 d
Paclitaxel Hyaluronidase Inject in and around extravasated area
,63
Antidotes are available for some chemotherapy drugs (Table 240­6). Dexrazoxane is used for anthracycline extravasation at a dose of 1000
  milligrams/m IV infused over  to  hours within  hours of the extravasation event, with additional doses of 1000 milligrams/m at  hours and 500
   milligrams/m at  hours. Dimethyl sulfoxide and hyaluronidase are used to enhance absorption of the extravasated agent. Dimethyl sulfoxide is
 applied as a generous trickle of the 99% solution over the involved area without pressing or rubbing and then covered with dry pads. Hyaluronidase
 is reconstituted with normal saline to a concentration of 150 units/mL and then injected in and around the extravasation area via multiple punctures.
Inject about .2 mL per puncture site with a typical total dose of  mL, but up to  mL may be required. There are limited data supporting the use of
 sodium thiosulfate for reversal of alkylating agent toxicity. Intralesional injections of corticosteroids or bicarbonate are not effective.
EMERGENCY COMPLICATIONS DUE TO BIOLOGIC THERAPY
Targeted antineoplastic agents and immunotherapeutic drugs are increasingly used for cancer therapy, and many patients have experienced substantially improved outcomes. However, these biologic cancer agents are associated with toxicities, some of which can be potentially life
 threatening.
MONOCLONAL ANTIBODIES
Monoclonal antibodies are proteins produced by immune cells that specifically recognize a cell target. In targeted cancer therapy, specially engineered humanized or chimeric antitumor monoclonal antibodies are designed to bind to T cells, activating them to target and kill cancer cells (Table 240­

7).
TABLE 240­7
Common Monoclonal Antibodies (MAB) and Their Applications in Cancer Therapy
MAB (origin) Target Indications Serious Toxicities
Rituximab (human/murine) CD20 Non­Hodgkin’s lymphoma CRS
Lymphocytic leukemia
Ofatumumab (human IgG1 MAB) CD20 Chronic lymphocytic leukemia unresponsive to chemotherapy Immunodeficiency
Trastuzumab (humanized MAB) HER2/neu Breast cancer Cardiac disease
Metastatic GI cancers
Cetuximab (human MAB) EGFR Colon cancer Diarrhea
Head and neck cancer Exanthema
Bevacizumab (humanized IgG1 MAB) VEGF Metastatic colon cancer Hypertension
Breast cancer GI bleeding or perforation
Renal cell cancer Thromboembolism
Non–small­cell lung cancer
Glioblastoma
Abbreviations: CD20 = B­leukocyte antigen CD20; CRS = cytokine release syndrome; EGFR = epidermal growth factor receptor; HER2 = human epidermal growth factor receptor ; IgG = immunoglobulin G; VEGR = vascular endothelial growth factor.
Common adverse effects associated with monoclonal antibodies are fevers, chills, pruritus, and muscle pain, which can be managed using antipyretics, antihistamines, adequate IV fluids, along with cardiopulmonary monitoring and oxygen supplementation. A potentially serious adverse reaction with monoclonal antibody therapy is cytokine release syndrome, where activated T cells release cytokines, with Il­6 as a key mediator.
CYTOKINE RELEASE SYNDROME
Cytokine release syndrome is a potentially life­threatening systemic inflammatory reaction observed after infusion of agents targeting different
,67 immune effectors. Most commonly, affected patients develop fever, chills, tachycardia, and hypotension during or within  hours following drug administration. The syndrome may cause a broad spectrum of constitutional symptoms such as headache, myalgia, arthralgia, asthenia, and back or abdominal pain. Organ­related symptoms of cytokine release syndrome include bronchospasm, dyspnea, dysrhythmias, hypotension, confusion, oliguria, erythema, urticarial reaction, and pruritus. Symptoms of cytokine release syndrome that appear during or after first exposure to a “new” drug
 may be difficult to distinguish from anaphylaxis. Treatment of cytokine release syndrome is guided by the severity, and all patients with cytokine
 release syndrome should be admitted to the hospital (Table 240­8).
TABLE 240­8
Recommendations for the Management of Cytokine Release Syndrome (CRS)
Grade Clinical Features Management
Grade Fever or mild organ toxicity Treat fever with acetaminophen (ibuprofen is an alternative if not contraindicated) and
 hypothermia blanket (if needed)
Maintenance IV fluids to prevent dehydration
Assess for infection using blood and urine cultures and chest radiography
If neutropenic, start empiric broad­spectrum antibiotics and filgrastim
Grade Hypotension, responds to IV fluids Initial IV fluid bolus with normal saline 500–1000 mL
 and/or low­dose vasopressors Administer a second IV fluid bolus if systolic blood pressure remains <90 mm Hg
For hypotension refractory to two IV fluid boluses, administer anti–IL­6 therapy using tocilizumab  milligrams/kg IV or siltuximab  milligrams/kg IV
If hypotension persists after two fluid boluses and anti–IL­6 therapy, start vasopressors, transfer to intensive care unit, obtain echocardiogram, and initiate hemodynamic monitoring
Hypoxia, responds to FIO2 <40% Administer supplemental oxygen
Organ toxicity Symptomatic management of organ toxicities
Grade Hypotension, required high­dose or IV normal saline fluid boluses as needed
 multiple vasopressors Tocilizumab and siltuximab as recommended for grade  CRS, if not previously administered
Vasopressors as needed
Transfer to intensive care unit, obtain echocardiogram, initiate hemodynamic monitoring
Dexamethasone  milligrams IV every  h
Hypoxia, requiring FIO2 >40% High–flow oxygen delivery and consider noninvasive positive­pressure ventilation
Organ toxicity Symptomatic management of organ toxicities
Grade Hypotension, life­threatening IV fluids, anti–IL­6 therapy, vasopressors, and hemodynamic monitoringMethylprednisolone  gram
 IV daily
Hypoxia, requiring ventilatory Mechanical ventilation support
Organ toxicity Symptomatic management of organ toxicities
Abbreviations: FIO2 = fraction of inspired oxygen; IL­6=interleukin­6. IMMUNE CHECKPOINT INHIBITOR THERAPY
Some tumor cells elaborate surface proteins that bind to receptors on T lymphocytes, inhibiting the ability of the T lymphocyte to kill the tumor cell.
Immune checkpoint inhibitor therapy uses monoclonal antibodies that bind to either the tumor cell protein or the corresponding T­lymphocyte receptor, breaking the inhibition so that the T lymphocyte can kill the tumor cell. Current immune checkpoint inhibitors target either the cytotoxic T­ lymphocyte–associated protein  (ipilimumab), the programmed cell death protein­1 on the tumor cell (pembrolizumab, nivolumab, or cemiplimab), or the programmed cell death ligand­1 on the T lymphocyte (atezolizumab, avelumab, or durvalumab). Most patients receive single­agent treatment with occasional use of combination therapy. Ipilimumab, nivolumab, and pembrolizumab have been in use for a longer time, so more instances of
 adverse effects arising from these drugs have been reported.
Immune checkpoint inhibitor–induced immune­related adverse effects are defined as any toxicity with a potential immunemediated cause. Although some immune­related adverse effects can present with potentially life­threatening symptoms, several immune­related
 endocrine adverse effects have an insidious onset and present with low­grade, nonspecific symptoms that are difficult to diagnose. Immune checkpoint inhibitors can attenuate tolerance and cause overwhelming inflammation, tissue damage, and autoimmunity. The main target tissues are
 the GI tract, lungs, skin, pancreas, liver, and endocrine system.
The adverse effects of immune checkpoint inhibitors vary with the specific agent and are more common with ipilimumab than nivolumab or
,68  pembrolizumab. The most frequent complications of ipilimumab are diarrhea and enterocolitis. Typically, the onset of GI symptoms is  weeks
,69 after start of treatment. Hypophysitis, inflammation of the pituitary gland, and thyroiditis are common adverse effects. Pancreatitis is associated more with combination therapy and with nivolumab than ipilimumab and pembrolizumab. Other adverse effects of immune checkpoint inhibitors
 include pneumonitis, dermatitis, adrenalitis, nephritis, vasculitis, anemia, and uveitis. Awareness of the distinct adverse effects of immune
 checkpoint inhibitor therapy is important to appropriately diagnose and manage these complications. The American Society of Clinical Oncology has
 published guidelines for the management of immune­related adverse effects of immune checkpoint inhibitor therapy. Mild toxicities can be
 controlled using topical regimens or oral antipruritics without use of systemic glucocorticoids. For serious immune­related adverse effects
(neurologic, pulmonary, and cardiac toxicities), systemic glucocorticoids are used and anti–tumor necrosis factor­α therapy may be needed by patients
 who do not respond adequately to glucocorticoid treatment.


