## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 197: Anticonvulsants
Frank LoVecchio
INTRODUCTION
Anticonvulsants, or antiepileptics, are used to treat acute seizures and prevent convulsions in patients with epilepsy. The first generation of antiepileptics was developed between 1938 and 1978 (Table 197­1). Since 1993, over  additional agents, termed the second and third generations of antiepileptic drugs, have been introduced into clinical use. In general, these new anticonvulsants have fewer serious adverse side effects and fewer drug interactions than the first­generation agents.
TABLE 197­1
First­Generation Anticonvulsant Drugs
Typical Oral Adult Dose Maximum Oral Daily Dose Elimination Half­Life With Therapeutic
Drug
(milligrams) (milligrams) Doses (h)
Carbamazepine 800–1200 per day divided BID to QID 1600 25–65 (initial doses)
12–17 (repeated doses)
Ethosuximide 250–750 BID 1500 56–60
Methsuximide 300–1200 once daily 1200 1–3 (parent drug)
28–34 (active metabolite)
Phenobarbital  BID or TID 200* 
Phenytoin 300–400 per day divided BID or TID 600* 7–42
Primidone 250 TID or QID 2000 10–12 (parent drug)
75–126 (phenobarbital)
Valproic acid 30–60 per kilogram per day divided BID  per kilogram  or TID
Abbreviations: BID = twice a day; QID = four times a day; TID = three times a day.
*Approximation: Individualize dosage based on serum drug concentrations and clinical parameters.
The first­generation drugs have an established therapeutic range for serum levels that can guide therapy during long­term management and that roughly correlate with acute toxicity from an overdose. Consistent therapeutic levels have not been established for the second­ and third­generation anticonvulsants, and serum levels are not a useful guide to therapy.
The toxicity of two benzodiazepines used to treat seizures—clonazepam and clobazam—is discussed elsewhere (see Chapter 183, “Benzodiazepines”)
This chapter reviews the pharmacology, clinical features, and treatment for toxicity of commonly used anticonvulsants. Disposition recommendations dDeopwennldo aodne tdh e2 0re2s5o­l7u­t1io 6n: 3o0f c Pli n Yicoaul tro IxPi ciist y1, 3b6u.t1 p4a2t.i1e5n9ts.1 w2i7th intentional overdose need mental health evaluation in the ED before discharge.
Chapter 197: Anticonvulsants, Frank LoVecchio 
. Terms of Use * Privacy Policy * Notice * Accessibility
PHENYTOIN AND FOSPHENYTOIN
Phenytoin is a primary anticonvulsant for partial and generalized tonic­clonic seizures. In conjunction with rapidly acting anticonvulsants, it is useful in
 the treatment of non–drug­induced status epilepticus. Phenytoin has been used to prevent seizures due to head trauma (in the immediate posttraumatic period) and in the management of some chronic pain syndromes. Serious complications are extremely rare after intentional phenytoin overdose if supportive care is provided. Most phenytoin­related deaths have been associated with rapid IV administration or hypersensitivity reactions.
Phenytoin is available in oral and injectable forms. Phenytoin has poor solubility in water, so the vehicle for the parenteral formulation is 40% propylene glycol and 10% ethanol, adjusted to a pH of  with sodium hydroxide. The acute cardiovascular toxicity seen with IV phenytoin infusion is usually ascribed to the propylene glycol diluent. Other limitations with parenteral phenytoin are the irritating nature of the vehicle and a tendency to precipitate in IV solutions. Fosphenytoin (a disodium phosphate ester of phenytoin) is a prodrug that is converted to phenytoin by phosphatases in the body with a conversion half­life of  to  minutes. The advantage of parenteral fosphenytoin is that it is soluble in aqueous
 solutions, is buffered to a pH of .8, is nonirritating to the tissues, and can be given by IM injection.
PATHOPHYSIOLOGY
Mechanism of Action
Phenytoin exerts its anticonvulsant effects by blocking neuronal voltage­sensitive and frequency­dependent sodium channels, suppressing repetitive
 neuronal activity, and preventing the spread of a seizure focus.
Pharmacokinetics
Phenytoin is a weak acid with a pK of .3. In the acid milieu of the stomach and even at physiologic pH, most of the drug is nonionized and its aqueous a solubility is limited. Absorption after oral ingestion is slow, variable, and often incomplete, especially after an overdose. Different phenytoin preparations can have major differences in bioavailability. Consequently, it may be necessary to obtain serial measurements of serum level in suspected overdose to determine peak levels. Peak levels typically occur between  and  hours after a single therapeutic oral dose.
Protein Binding
Phenytoin is extensively (about 90%) bound to plasma proteins, especially albumin. The free, unbound form is the biologically active moiety responsible for the drug’s clinical effect and toxicity. The unbound fraction of the drug is greater in neonates, the elderly, and pregnant women; unbound fractions are also higher in the settings of renal failure, hypoalbuminemia (cirrhosis, nephrosis, malnutrition, burns, trauma, or cystic fibrosis), or hyperbilirubinemia. Drugs that displace phenytoin from binding sites (salicylate, valproate, phenylbutazone, tolbutamide, and sulfisoxazole) also result in an increased unbound fraction.
Metabolism
Ninety­five percent of phenytoin is metabolized by hepatic microsomal enzymes, and it is primarily hydroxylated through a series of inactive compounds. The metabolism of phenytoin is capacity limited (dose dependent). At plasma concentrations of <10 micrograms/mL, elimination is by first­order kinetics (a fixed percentage of drug is metabolized per unit of time). At higher concentrations, including those in the therapeutic range of
 to  micrograms/mL (40 to  micromole/L), the metabolic pathways may become saturated and the elimination may change to zero­order kinetics (a fixed amount is metabolized per unit of time). With zero­order kinetics, small increases in maintenance doses may saturate the enzyme systems, markedly prolonging phenytoin’s half­life and resulting in a disproportionate increase in the plasma level. Thus, incremental dose increases should be limited to  to  milligrams at a time, and levels should be carefully monitored when it is necessary to raise phenytoin doses above 300 milligrams (or above  milligrams/kg) per day.
Concomitant use of drugs that inhibit or enhance hepatic microsomal activity may result in an increase or decrease of phenytoin level, respectively.
Phenytoin also affects the metabolism of various other agents (Table 197­2).
TABLE 197­2
Phenytoin Drug Interactions (Partial List)
Phenytoin increases serum levels of Phenytoin levels are increased by
Acetaminophen Amiodarone
Acetazolamide Chloramphenicol
Amiodarone Cimetidine
Oral contraceptives Disulfiram
Primidone Fluconazole
Zidovudine Isoniazid
Phenytoin increases toxicity of Oral anticoagulants
Carbamazepine Phenylbutazone* Oral anticoagulants Salicylate (high dose)* Phenytoin decreases serum levels of Trimethoprim
Cyclosporine Phenytoin levels are decreased by
Disopyramide Antineoplastic drugs
Doxycycline Calcium
Ethanol (chronic use) Ethanol
Furosemide Diazepam
Glucocorticoids Diazoxide
Levodopa Folic acid
Methadone Phenobarbital
Mexiletine Rifampin
Quinidine Sucralfate
Theophylline Sulfonamides* Valproate Theophylline
Tolbutamide* Valproate* *These drugs displace phenytoin from its protein­binding sites, thus increasing the free phenytoin fraction, although the total phenytoin level may decrease.
Propylene Glycol and Ethanol Diluents
Propylene glycol is a potent myocardial depressant and vasodilator and also enhances vagal tone. This chemical can cause coma, seizures, circulatory
 collapse, ventricular dysrhythmias, atrioventricular node depression, and hypotension in experimental animals. Other toxic effects from propylene
 glycol include hyperosmolality, hemolysis, and lactic acidosis. The ethanol diluent fraction of parenteral phenytoin may precipitate a reaction in patients taking disulfiram.
CLINICAL FEATURES
CNS Toxicity
As toxic phenytoin levels are reached, inhibitory cortical and excitatory cerebellar and vestibular effects begin to occur. The initial sign of toxicity is
 usually nystagmus, which is seen first on forced lateral gaze and later becomes spontaneous (Table 197­3). Vertical, bidirectional, or alternating nystagmus may occur with severe intoxication. A decreased level of consciousness is common and may be seen with initial sedation, lethargy, ataxic
 gait, and dysarthria. This may progress to confusion, coma, and even apnea in a substantial overdose. Nystagmus may disappear as the level of consciousness decreases, and complete ophthalmoplegia and loss of corneal reflexes may occur. Therefore, absence of nystagmus does not exclude severe phenytoin toxicity. Nystagmus returns as serum drug levels decrease and coma lightens.
TABLE 197­3
Clinical Features of Phenytoin Toxicity
CNS Dizziness, tremor (intention), visual disturbance, horizontal and vertical nystagmus, diplopia, miosis or mydriasis, ophthalmoplegia, abnormal gait (bradykinesia, truncal ataxia), choreoathetoid movements, irritability, agitation, confusion, hallucinations, fatigue, coma, encephalopathy, dysarthria, meningeal irritation with pleocytosis, seizures (rare)
Peripheral nervous Peripheral neuropathy, urinary incontinence system
Hypersensitivity Eosinophilia, rash, pseudolymphoma (diffuse lymphadenopathy), systemic lupus erythematosus, pancytopenia, hepatitis,
(anticonvulsant pneumonitis hypersensitivity syndrome)
GI Nausea, vomiting, hepatotoxicity
Dermatologic Hirsutism, acne, rashes (including Stevens­Johnson syndrome)
Other organs Fetal hydantoin syndrome, gingival hyperplasia, coarsening of facial features, hemorrhagic disease of the newborn, hyperglycemia, hypocalcemia
Parenteral toxicity May cause hypotension, bradycardia, conduction disturbances, myocardial depression, ventricular fibrillation, asystole, and tissue necrosis from infiltration
Paradoxically, very high levels of phenytoin may be associated with seizures, although this is a rare occurrence, and such phenytoin­induced seizures
 are usually brief and generalized; they are almost always preceded by other signs of toxicity, especially in acute overdose.
Cerebellar stimulation and alterations in dopaminergic and serotonergic activity levels may cause acute dystonias and movement disorders such as opisthotonos and choreoathetosis. Hyperactive deep tendon reflexes, clonus, and extensor toe responses also may be elicited. Chronic neurologic toxicity includes peripheral neuropathy and cerebellar degeneration with ataxia.
Cardiovascular Toxicity
Cardiovascular complications have been almost entirely limited to cases of IV administration, in large part due to the constituents
 of the parenteral vehicle or, in rare cases, with chronic oral toxicity. Cardiac toxicity after acute oral phenytoin overdose in an otherwise
 healthy patient has not been reported and, if observed, is due to other causes (e.g., hypoxia, other drugs).
Reported cardiovascular complications include hypotension with decreased peripheral vascular resistance, bradycardia, conduction delays progressing to complete atrioventricular nodal block, ventricular tachycardia, primary ventricular fibrillation, and asystole. ECG changes include increased PR interval, widened QRS interval, and altered ST segments and T waves. Cardiovascular toxicity is more common in the elderly, those with underlying cardiac disease, and the critically ill. Guidelines for parenteral phenytoin administration stress a slow rate of infusion and constant monitoring. Even though fosphenytoin does not contain the propylene glycol diluent, cardiovascular toxicity can occur with IV administration.
,10,11
Hypotension is seen in about 8%, and rare cases of bradycardia, atrioventricular nodal block, and asystole have been observed.
Vascular and Soft Tissue Toxicity
IV extravasation can produce skin and soft tissue necrosis, compartment syndrome, and limb gangrene. There are reports of delayed bluish
 discoloration of the affected extremity (“purple glove syndrome”) followed by erythema, edema, vesicles, bullae, and local tissue ischemia.
Hypersensitivity Reactions
Hypersensitivity reactions usually occur within  to  weeks of beginning phenytoin therapy and can present as a febrile illness with skin changes
(erythema multiforme, Stevens­Johnson syndrome, or toxic epidermal necrolysis) and internal organ involvement (hepatitis, rhabdomyolysis, acute interstitial pneumonitis, renal failure, lymphadenopathy, leukopenia, and/or disseminated intravascular coagulation). Patients with a history of previous hypersensitivity reactions should not receive phenytoin, and because of similar reactions to phenobarbital, lamotrigine, felbamate, and carbamazepine, these anticonvulsants should also be avoided.
DIAGNOSIS
The therapeutic phenytoin serum level is  to  micrograms/mL (40 to  micromole/L), which generally corresponds to a free phenytoin level of  to

 micrograms/mL. Although 50% of patients achieve reduction in seizure frequency below these levels, some patients require levels as high as  micrograms/mL for adequate control. The ratio of toxic dose to therapeutic dose for phenytoin is rather low, and there is wide individual variability in the levels required to cause adverse effects. In general, toxicity is correlated with increasing plasma levels (Table 197­4).
TABLE 197­4
Correlation of Plasma Phenytoin Level and Toxic Effects
Total Plasma Phenytoin Level (micrograms/mL [micromole/L]) Toxic Effects
<10 (<40) Usually none
10–20 (40–80) Occasional mild nystagmus
20–30 (80–120) Nystagmus
30–40 (120–160) Ataxia, slurred speech, nausea and vomiting
40–50 (160–200) Lethargy, confusion
>50 (>200) Coma, seizures
TREATMENT
The initial treatment of severe oral phenytoin overdose is similar to that for ingestion of other drugs. Correct acidosis (respiratory or metabolic) to decrease the active free phenytoin fraction. Multidose activated charcoal may decrease drug half­life, but does not decrease time to recovery and does
 not change outcome in overdose patients. Seizures may be treated with IV benzodiazepines or phenobarbital, with the caution that seizures are uncommon in phenytoin overdose. For patients with severe and persistent toxicity, hemodialysis and hemoperfusion can produce
15­17 substantial improvement in neurologic toxicity.
Cardiac monitoring after isolated oral ingestion is unnecessary.Atropine and temporary cardiac pacing may be used for symptomatic bradyarrhythmias associated with IV phenytoin. Hypotension that occurs during IV administration of phenytoin or fosphenytoin usually responds to discontinuation of the infusion and administration of isotonic crystalloid.
DISPOSITION AND FOLLOW­UP
Phenytoin has a long and erratic absorption phase after oral overdose, so the decision to discharge or medically clear a patient for psychiatric evaluation cannot be based on one serum level. After acute ingestions, serum level should be measured every few hours. Patients with oral ingestion who have serious complications (seizures, coma, altered mental status, or significant ataxia) should be admitted for further evaluation and treatment. Those with mild symptoms should be observed in the ED and discharged once their levels of phenytoin are declining and they are clinically well. Mental health or psychiatric evaluation should be obtained, as indicated, in cases of intentional overdose.
Patients with symptomatic chronic intoxication should be admitted for observation unless signs are minimal, adequate care can be obtained at home, drug levels are decreasing, and  to  hours have elapsed since the patient’s last therapeutic dose. Phenytoin therapy should be stopped in all cases, and if toxicity continues to resolve, serum level may be reassessed in  to  days to guide resumption of therapy.
CARBAMAZEPINE
Carbamazepine is a primary anticonvulsant used in the treatment of partial and tonic­clonic seizures. Other uses include trigeminal neuralgia, chronic pain disorders, manic disorder, and bipolar disorder.
PATHOPHYSIOLOGY
Carbamazepine inhibits sodium channels and interferes with muscarinic acetylcholine receptors, nicotinic acetylcholine receptors, N­methyl­D­
 aspartate receptors, and CNS adenosine receptors. It has central antidiuretic effects, which may lead to the syndrome of inappropriate antidiuretic hormone secretion. Carbamazepine is a potent cytochrome P450 (CYP450) enzyme inducer and enhances its own metabolism over time.
Carbamazepine is an iminostilbene derivative that is chemically and structurally similar to imipramine. GI absorption is slow, and peak serum concentrations usually occur within  hours but may occur as late as  hours after ingestion. A therapeutic carbamazepine concentration is  to 
 micrograms/mL (34 to  micromole/L).
Carbamazepine has a protein binding of about 80% and is metabolized by liver CYP450 isoenzymes to an active metabolite (10,11­epoxide) responsible for much of the neurotoxicity seen in overdose. Autoinduction of the enzymes that metabolize carbamazepine occurs after about  month of
 continuous use, decreasing the elimination half­life (Table 197­1).
CLINICAL FEATURES
After an overdose, the delayed and erratic absorption due to anticholinergic properties (which delay GI motility) and low water solubility can cause
 delayed clinical deterioration or a crescendo­decrescendo clinical course. Manifestations of acute toxicity include mental status depression, ataxia,
19­21 nystagmus, ileus, hypertonicity with increased deep tendon reflexes, dystonic reactions, and an anticholinergic toxidrome. Paradoxical seizures can occur in patients with high carbamazepine concentrations and an underlying seizure disorder. There are sporadic reports of left ventricular dysfunction with heart failure and transient heart block (without hemodynamic compromise). Cardiac arrhythmias are rarely seen, but carbamazepine is one of the few drugs that can potentially cause both a wide QRS interval and seizures. Laboratory abnormalities seen with acute overdose include hyponatremia, hyperglycemia, and transient elevation of serum liver enzyme levels.
DIAGNOSIS
Serum carbamazepine concentrations are not linearly correlated with poisoning severity. However, serum concentrations of >40 micrograms/mL (>170 micromole/L) are associated with an increased risk of serious complications such as seizures, respiratory failure, coma, and cardiac conduction
 defects. Serum concentrations higher than  to  micrograms/mL (250 to 340 micromole/L) may be fatal. The seriousness of toxicity should be
20­22 judged by the clinical status of the patient, not by the serum concentration.
Because the chemical structure of carbamazepine is related to imipramine, carbamazepine can cause a false­positive tricyclic antidepressant
 result on a urine drug screen. Both carbamazepine and epoxide metabolite are measured by the standard enzyme­multiplied immunoassay to determine serum levels.
TREATMENT

Because delayed absorption is possible, activated charcoal may be considered if the patient is not obtunded and presents within  hour of ingestion.

Multidose activated charcoal may decrease drug half­life but does not decrease time to recovery or change outcome in overdose patients. In
25­31 patients with severe toxicity and multiorgan dysfunction, hemodialysis, hemoperfusion, and hemodiafiltration are effective.
Although cardiac conduction delays are rare, if conduction delay is noted on the ECG, sodium bicarbonate treatment is reasonable.
DISPOSITION AND FOLLOW­UP
Patients can be medically cleared from the ED if at least two carbamazepine measurements obtained a few hours apart show decreasing levels
(preferably <15 micrograms/mL or  micromole/L) and the patient is awake, ambulatory, and free of cardiac conduction abnormalities.
VALPROIC ACID
Valproic acid (oral preparation) or valproate sodium (IV form) is used to treat tonic­clonic seizures, absence seizures, partial complex seizures, and posttraumatic epilepsy. Valproic acid is also used in migraine headache prophylaxis, to control manic episodes in bipolar disorder, and in the treatment of neuropathic pain.
PATHOPHYSIOLOGY

Valproic acid affects neurotransmitters and the function of electrically excitable cells. Valproic acid increases γ­aminobutyric acid concentrations,
 reduces release of γ­hydroxybutyrate, and blocks N­methyl­D­aspartate receptors. Valproic acid prolongs recovery of inactivated sodium channels, enhances potassium conductance, and reduces T­type calcium current firing.
With standard preparations at therapeutic doses, peak serum concentrations occur within  hours after ingestion. If the enteric­coated or controlled­
 release formulation has been ingested, peak serum concentration may be delayed for  to  hours.
Valproic acid is metabolized by the liver by glucuronic acid conjugation and mitochondrial beta oxidation. Valproic acid enters mitochondria by using L­ carnitine as a cofactor. Protein binding is extensive and influenced by serum concentration, with 90% of the drug protein bound at concentrations of
33­36
 micrograms/mL (277 micromole/L). The half­life of valproic acid may be two or three times longer after overdose.
CLINICAL FEATURES

After an overdose with acute toxicity, the most frequent sign is CNS depression, ranging from drowsiness to coma. Other findings include respiratory depression, hypotension, hypoglycemia, hypocalcemia, hypernatremia, hypophosphatemia, and anion gap metabolic acidosis that may persist for days. Toxicity to the liver produces elevated serum levels of aminotransferases, ammonia, and lactate. Pancreatitis may occur, and thrombocytopenia
 may be clinically significant and severe.
Valproic acid increases renal ammonia production and blocks hepatic ammonia metabolism, thus producing hyperammonemia following valproate
,38 ,35 overdose and during long­term therapy. Cerebral edema has been seen in acute overdose. Valproic acid–induced hepatotoxicity may be either intrinsic and benign (reversible, reproducible, and dose dependent) or idiosyncratic and fatal (unpredictable, not dose dependent, with a long latent
39­41 period). Children <3 years of age who are receiving multiple antiepileptic agents and have additional medical problems are at highest risk for fatal hepatotoxicity, with an incidence of about  in 500. Serum levels of transaminases and ammonia should be checked in children on valproate therapy who demonstrate somnolence or lethargy.
DIAGNOSIS
Therapeutic valproic acid concentrations are  to 100 micrograms/mL (346 to 693 micromole/L). Although serum concentration does not correlate well with either seizure control or toxicity, adverse side effects increase as concentrations rise above 150 micrograms/mL (1040 micromole/L), and coma may occur with levels above 800 micrograms/mL (5547 micromole/L). Serum ammonia and glucose concentrations should be measured with suspected valproic acid toxicity. Valproic acid is eliminated partly as ketone bodies and may cause a positive test result for ketones in the urine or blood.
TREATMENT
Single­dose activated charcoal alone is sufficient for the vast majority of patients with a valproic acid overdose. Consider multidose activated charcoal and/or whole­bowel irrigation after ingestion of enteric­coated, delayed­release preparations to prevent the
,42 ongoing absorption that may occur from delayed capsule or tablet dissolution. Because of delayed peak serum levels after an overdose, serial concentrations should be measured.
Overdose patients have been given L­carnitine in an attempt to increase valproic acid metabolism by beta oxidation, and this therapy appears to
43­ hasten the resolution of coma, prevent hepatic dysfunction, and reverse mitochondrial metabolic abnormalities in patients with acute intoxication.

Administration of L­carnitine 100 milligrams/kg IV initially followed by infusions of  milligrams/kg every  hours is recommended in cases of
 valproic acid toxicity with lethargy, coma, hyperammonemia, and hepatic dysfunction.
46­50
Hemoperfusion and hemodiafiltration have been used to treat severe valproic acid overdose. Although valproic acid should not be amenable to dialysis due to significant protein binding, unbound (free) drug is markedly increased in overdose, and removal of valproic acid from this pool appears beneficial. During hemoperfusion and hemodiafiltration treatment, elimination half­life is decreased by two­ to seven­fold. Universal use of hemodiafiltration cannot be recommended for all patients. Clinical comparison of extracorporeal detoxification with supportive care reports a benefit
 with extracorporeal removal.
DISPOSITION AND FOLLOW­UP
Patients can be medically cleared from the ED if valproic acid levels measured every few hours demonstrate a decline and the patient is asymptomatic.
OTHER FIRST­GENERATION ANTICONVULSANTS
ETHOSUXIMIDE AND METHSUXIMIDE
Ethosuximide and methsuximide are used to treat absence seizures. Therapeutic serum concentrations for ethosuximide are  to 100 micrograms/mL (280 to 700 micromole/L). Therapy with methsuximide is monitored by measuring the metabolite normethsuximide, with a therapeutic range of  to  micrograms/mL (53 to 212 micromole/L). Acute toxicity from ethosuximide or methsuximide overdose is characterized by CNS depression (ataxia, confusion, slurred speech, decreased level of consciousness), respiratory depression, and nausea and vomiting. Treatment is supportive.
PRIMIDONE AND PHENOBARBITAL
Primidone and phenobarbital are used to treat a variety of seizure types. Primidone is metabolized into phenobarbital; both the parent drug and its active metabolite act on γ­aminobutyric acid receptors, producing synaptic inhibition. Therapeutic serum concentrations for primidone are  to  micrograms/mL (23 to  micromole/L). The therapeutic serum concentrations for phenobarbital are  to  micrograms/mL (65 to 172 micromole/L). Urinary alkalinization somewhat enhances the clearance of phenobarbital and primidone. See Chapter 182, “Barbiturates,” for further discussion.
SECOND­ AND THIRD­GENERATION ANTICONVULSANTS
As a group, the second­ and third­generation anticonvulsants are less toxic in acute overdose than the first­generation agents, and most of the serious
 complications reported have occurred in cases of mixed ingestion. Some specific acute toxic effects are notable (Table 197­5).
TABLE 197­5
Second­ and Third­Generation Anticonvulsants
Usual Oral Maximum Oral Elimination Half­Life in
Drug Adult Dose Adult Daily Dose Adults With Therapeutic Unique Effects Seen With Overdose
(milligrams) (milligrams) Doses (h)
Brivaracetam 25–100 BID 200 
Eslicarbazepine 800–1600 once 1600 13–20 Vertigo, ataxia, hemiparesis acetate daily
Ezogabine or Agitation, irritability, aggressive behavior retigabine* Felbamate 2400–3600 per 3600 20–23 Crystalluria, hematuria, aplastic anemia, liver failure day divided TID or QID
Gabapentin 300–1200 TID 3600 5–7 Drowsiness, ataxia, nausea, vomiting
Lacosamide 150–200 BID 400 7–15 Limited experience; serious toxicity unlikely
Lamotrigine 200 once daily 200  Drowsiness, vomiting, ataxia, and dizziness; serious neurologic and cardiovascular toxicity with co­ingestants;
Stevens­Johnson syndrome
Levetiracetam 500–1500 BID 3000 6–8 Lethargy, coma, respiratory depression
Oxcarbazepine 600 BID 2400  (parent drug) Little toxicity from isolated oxcarbazepine overdose
 (active metabolite)
Perampanel 8–12 every night  105 at bedtime
Pregabalin 160–600 per day 600  Drowsiness and depressed level of consciousness divided BID or
TID
Rufinamide 1600 BID 3200 6–10 Limited experience; serious toxicity unlikely
Stiripentol* No information
Tiagabine 32–56 per day  7–9 Rapid onset of lethargy, coma, seizures, and status divided BID to epilepticus; myoclonus, muscular rigidity, and delirium
QID
Topiramate 200 BID 400  Somnolence, vertigo, agitation, and mydriasis; seizures and status epilepticus; metabolic acidosis
Vigabatrin† 1500 BID 3000 Drowsiness, unconsciousness, coma
Zonisamide 100–600 per day 600  Little toxicity from isolated zonisamide overdose divided once daily or BID
Abbreviations: BID = twice a day; QID = four times a day; TID = three times a day.
*Not available in the United States as of March 2018. †Restricted distribution in the United States.
BRIVARACETAM
Brivaracetam is used as monotherapy or adjunct therapy for partial seizures.
ESLICARBAZEPINE ACETATE
Eslicarbazepine acetate is a prodrug for eslicarbazepine, an anticonvulsant that stabilizes sodium­dependent channels in their inactivated state
,54 and is used to treat partial seizures. Eslicarbazepine possesses modest and possible clinically relevant drug interactions with phenytoin,
53­55 carbamazepine, and oral contraceptives. Symptoms of vertigo, ataxia, and hemiparesis have been observed after accidental overdose.
EZOGABINE
Ezogabine (generic name in the United States), known in Europe as retigabine, activates voltage­gated potassium channels in the brain, a unique
,54,56 53­55 mechanism among the anticonvulsants. Ezogabine has drug interactions with phenytoin, carbamazepine, and lamotrigine. Side effects seen
 with ezogabine therapy include dizziness, fatigue, confusion, tremor, and ataxia. Increased rate of urinary retention and slight increase in QT interval have been reported. There is limited experience with overdose, but agitation, irritability, and aggressive behavior have been noted. This drug is no longer distributed in the United States.
FELBAMATE

Felbamate was the first of the second­generation antiepileptics. However, shortly after its introduction in 1993, it received a “black box warning” because of the association with aplastic anemia (with an incidence 100 times higher than in the general population) and hepatic failure. Hence, it is only recommended when other treatment regimens have failed to control seizures. The proposed mechanism of action of felbamate is inhibition at γ­ aminobutyric acid receptors and excitation at N­methyl­D­aspartic acid receptors. Felbamate has drug interactions with the first­generation anticonvulsants and oral contraceptives. In overdose, the symptoms are usually mild, but in large ingestions, felbamate can crystallize in the kidney,
57­59 producing crystalluria, hematuria, and possibly acute renal failure. Treatment is supportive.
GABAPENTIN
Gabapentin, as its name suggests, increases γ­aminobutyric acid levels in the brain. It also has indirect effects on calcium channels located on the postsynaptic terminal. Gabapentin is used to treat partial seizures. Gabapentin has drug interactions with cimetidine and antacids. With an overdose,
 gabapentin produces little toxicity, usually being associated with drowsiness, ataxia, nausea, and vomiting that resolve in about  hours. Depressed level of consciousness has been described in a patient with end­stage renal disease who ingested multiple doses of gabapentin over  days without
  intervening hemodialysis; hemodialysis was associated with rapid recovery. The only reported suicide from gabapentin overdose is controversial.
LACOSAMIDE

Lacosamide affects voltage­gated sodium channels in the CNS and is used to treat partial seizures. Lacosamide has no significant drug
,55 interactions. During therapeutic use, adverse reactions are usually mild to moderate and typically include dizziness, headache, nausea, and
 diplopia. There is limited clinical experience with lacosamide overdose, but serious toxicity after an isolated overdose would not be expected to occur.
LAMOTRIGINE

Lamotrigine inhibits sodium channels in CNS neurons and likely has the same effect in the heart. Lamotrigine is used to treat partial and
 generalized seizures. Lamotrigine interacts with the first­generation antiepileptics. Autoimmune reactions, such as Stevens­Johnson syndrome, have occurred during therapeutic use. With an overdose, the clinical course is usually benign, and the most common effects are drowsiness, vomiting,
,65 ataxia, and dizziness. Serious neurologic and cardiovascular toxicity is rare, but has been reported after lamotrigine overdose (although
66­70  ,72­75 sometimes with co­ingestants). Neurologic toxicity includes oculogyric crisis, provoking of seizures, status epilepticus, and coma. Cardiac
  ,75 toxicity includes QRS complex widening, atrioventricular nodal block, and cardiovascular collapse. Acute pancreatitis has been reported in
  association with a lamotrigine overdose. Treatments used in lamotrigine overdose include activated charcoal to reduce absorption, sodium bicarbonate for QRS complex widening, magnesium sulfate for QT interval prolongation, and IV lipid emulsion to remove active drug
,81 from binding sites and sequester it in a lipid sink.
LEVETIRACETAM
The mechanism of action of levetiracetam is not known. The drug binds to a synaptic vesicle glycoprotein and inhibits presynaptic calcium channels, reducing neurotransmitter release. This is believed to impede impulse conduction across synapses. Levetiracetam is used to treat partial and generalized seizures. During therapeutic use, the major side effect is somnolence, and mood disorders are usually seen during the initial  weeks of
 therapy. There are few reports of levetiracetam overdose, and the most common symptom is lethargy that can progress to coma and rarely
83­86 respiratory depression. Recovery is usually rapid with supportive care alone.
OXCARBAZEPINE

Oxcarbazepine inhibits voltage­sensitive sodium channels in the nervous system and is used to treat partial seizures. Oxcarbazepine interacts with
,55 phenytoin, lamotrigine, and oral contraceptives. During therapeutic use, hyponatremia and drug rash can be seen. Hyponatremia is a common adverse effect of both oxcarbazepine and carbamazepine, due in part to increased responsiveness of collecting tubules to antidiuretic hormone. There
88­91 appears to be little toxicity from isolated oxcarbazepine overdose; most of the serious neurologic depression has been seen with mixed ingestions.
PERAMPANEL
Perampanel is used to treat partial­onset seizures and generalized seizures in those >12 years old, mostly as an adjunctive agent. The half­life is about 100 hours. It is a possible agent of abuse, because high doses can produce euphoria. It is a U.S. Food and Drug Administration Schedule III drug
,93 because abuse can lead to dependence. Dose­related effects include hostility, aggression, and agitation. There are almost no reports describing overdose. It is best to discuss management with your toxicologist or poison control center.
PREGABALIN
Pregabalin has a mechanism of action similar to that of gabapentin, increasing γ­aminobutyric acid levels in the brain in addition to having indirect effects on calcium channels located on the postsynaptic terminal. Pregabalin is used as adjunct therapy for partial seizures. Pregabalin has drug
,55 interactions with ethanol, lorazepam, and oxycodone. During long­term therapeutic use, the most commonly reported side effects are somnolence and dizziness; serious adverse effects are rare. There is little reported experience with pregabalin overdose. Depressed level of consciousness appears
,95 to be the major symptom. Similar to the experience with gabapentin, toxicity from pregabalin has been reported in patients with end­stage renal
 failure but resolves with dialysis.
RUFINAMIDE

Rufinamide inhibits the activity of sodium channels, prolonging their inactive state and is used as adjunct therapy in Lennox­Gastaut syndrome.
Rufinamide has drug interactions with other anticonvulsants—phenytoin, carbamazepine, valproate, phenobarbital, and lamotrigine—as well as with
,55 oral contraceptives. During long­term therapy, commonly reported adverse reactions include headache, dizziness, fatigue, and somnolence. There is limited clinical experience with rufinamide overdose, but given the lack of symptoms seen with doses of more than six times the recommended amount, toxicity would not be expected after an isolated overdose.
STIRIPENTOL
Stiripentol inhibits the reuptake of γ­aminobutyric acid into the presynaptic neuron, thereby increasing γ­aminobutyric acid concentrations in the
,55 synaptic cleft and promoting γ­aminobutyric acid activity. Stiripentol possesses modest drug interactions with valproate and clobazam. Side effects during therapeutic use include drowsiness, ataxia, tremor, anorexia, nausea, and vomiting. Transient aplastic anemia and leukopenia have occurred. There is no information on clinical overdose with this medication. Stiripentol, first used in Europe and Canada, was approved in 2018 by the
Food and Drug Administration for use in the United States.
TIAGABINE
Tiagabine inhibits the reuptake of γ­aminobutyric acid into the presynaptic neuron, thereby promoting γ­aminobutyric acid activity. Tiagabine is used as adjunct therapy to treat partial seizures. Tiagabine interacts with most of the first­generation antiepileptics, including phenytoin, valproate,
,55 carbamazepine, phenobarbital, and primidone. In overdose, tiagabine can cause the rapid onset of neurologic toxicity, including lethargy, coma,
98­101 102­105 and seizures. Tiagabine overdose can provoke status epilepticus, even in patients without an underlying seizure disorder. Other signs seen
 in tiagabine overdose include myoclonus, muscular rigidity, and delirium. Recovery usually occurs in about  hours.
TOPIRAMATE
Topiramate inhibits γ­aminobutyric acid receptors in addition to affecting sodium channels in the brain and is used to treat partial and generalized seizures. Topiramate possesses drug interactions with other anticonvulsants—phenytoin, valproate, carbamazepine, phenobarbital, and primidone—
,55 as well as with oral contraceptives. Adverse effects observed during therapeutic use include promotion of renal stone formation and glaucoma. In
106­108 109,110 overdose, topiramate can produce somnolence, vertigo, agitation, and mydriasis. Seizures and status epilepticus have been reported. A
111­113 unique aspect of topiramate overdose is the production of a non–anion gap metabolic acidosis. The cause is inhibition of renal carbonic anhydrase, and because of the long half­life of topiramate, metabolic acidosis can last up to  days. However, this effect is completely reversible, and no permanent sequelae have been seen.
VIGABATRIN
Vigabatrin is a structural analog of γ­aminobutyric acid that increases brain concentrations of this neurotransmitter. Vigabatrin has a modest drug
,55,114 interaction with phenytoin. Vigabatrin is used to treat refractory complex partial seizures, and because of the potential to induce permanent vision loss, it is only available in the United States via a restricted distribution program. During chronic therapy, vigabatrin may worsen mood and exacerbate psychosis. Sedation, headache, and weight gain are common side effects. After acute overdose, drowsiness, unconsciousness, and coma
115 are described in the majority of cases.
ZONISAMIDE

Zonisamide inhibits voltage­sensitive sodium channels in CNS neurons and is used to treat partial seizures. Zonisamide has drug interactions with
,55 most of the first­generation antiepileptics, including phenytoin, valproate, carbamazepine, phenobarbital, and primidone. Serious adverse effects during therapeutic use include the promotion of renal stone formation and a drug­induced rash. Isolated zonisamide overdose is associated with
117,118 119 lethargy. A death ascribed to zonisamide overdose was actually a mixed ingestion that included mirtazapine, diphenhydramine, and caffeine.


