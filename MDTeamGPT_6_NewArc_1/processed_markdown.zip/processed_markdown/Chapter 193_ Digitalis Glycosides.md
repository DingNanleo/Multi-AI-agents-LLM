## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 193: Digitalis Glycosides
Michael Levine; Aaron Skolnik
INTRODUCTION
The medicinal benefits of cardiac glycosides have been recognized for centuries. Even with development of alternative medications, digitalis
 preparations such as digoxin are still used for the treatment of atrial fibrillation and symptomatic congestive heart failure. In addition to availability as pharmaceuticals, cardiac glycosides are also found in plants such as foxglove, oleander, red squill, and lily of the valley. Similar cardioactive steroids are also found in the skin of toads in the Bufonidae family and in some herbal medications. Although intentional overdoses of cardiac glycosides are
,3 relatively uncommon, adverse drug reactions and chronic toxicity continue to cause morbidity.
PATHOPHYSIOLOGY
Digoxin is a cardiac glycoside available for PO or IV use. Following oral absorption, digoxin reaches a maximal serum concentration  to  hours after ingestion. It is approximately 25% protein bound and has a large volume of distribution (6 to  L/kg). The drug is primarily eliminated through the kidneys.

Digoxin, like other cardiac glycosides, inhibits sodium­potassium adenosine triphosphatase (ATPase). This inhibition results in increased intracellular sodium and increased extracellular potassium. As a result of the increased intracellular sodium, the sodium­calcium antiporter is not able to effectively remove calcium from the myocyte. Consequently, there is an increase in intracellular calcium, which augments inotropy. The increased intracellular calcium can contribute to delayed afterdepolarizations, which may lead to premature ventricular contractions and dysrhythmias. In addition, there is a decreased refractory period of the myocardium, which increases automaticity and hence is associated with an increased risk of dysrhythmias.
Furthermore, cardiac glycosides shorten atrial and ventricular repolarization, thereby decreasing the refractory period and thus increasing automaticity.
Cardiac glycosides also increase vagal tone via action at the carotid body, thereby reducing conduction through the sinoatrial and atrioventricular
 nodes. In toxic concentrations, cardiac glycosides can increase sympathetic tone. Digoxin can reduce plasma renin concentrations. In healthy people
(or animals), cardiac glycosides increase vascular tone. In patients with moderate to advanced heart failure, digoxin or other cardiac glycosides can
 decrease vascular resistance.
CLINICAL FEATURES
Digoxin has a narrow therapeutic index, and toxicity results from an exaggeration of its pharmacologic activity. The timing and clinical presentation of
 acute versus chronic digoxin toxicity differ significantly (Table 193­1). In addition to cardiac manifestations such as syncope and arrhythmia, digoxin toxicity may present with GI distress, dizziness, headache, weakness, malaise, delirium, or confusion. Thus, an elderly patient taking digoxin who presents with mental status changes should be evaluated for toxicity.
TABLE 193­1
Clinical Presentation of Digitalis Glycoside Toxicity
Acute Toxicity Chronic Toxicity
Clinical history Intentional or accidental ingestion Typically elderly cardiac patients taking diuretics; may have renal insufficiency.

Chapter 193: Digitalis Glycosides, Michael Levine; Aaron Skolnik 
©2025G MI ecffGecrtasw Hill. All RNaiguhsetsa Raneds veormveitdin. g , Tabedrmoms ionaf lU psaein * , aPnroivreaxciay Policy * NotNicaeu s * e aA, cvcoemsitsinibgi,l idtyiarrhea, abdominal pain.
CNS effects Headache, dizziness, confusion, coma Fatigue, weakness, confusion, delirium, and coma are often prominent features.
Cardiac effects Bradyarrhythmias or supraventricular tachyarrhythmias Almost any ventricular or supraventricular arrhythmia can occur; with atrioventricular block ventricular arrhythmias are common.
Electrolyte Hyperkalemia Normal, decreased, or increased serum potassium, hypomagnesemia.
abnormalities
Digoxin level Marked elevation (if obtained within  h) Minimally elevated or within “therapeutic” range.
ACUTE TOXICITY
Patients with acute digoxin toxicity tend to have more abrupt onset of symptoms than those with chronic toxicity. In acute cardiac glycoside poisoning, there may be an asymptomatic period of several hours before the onset of symptoms. Nausea, vomiting, anorexia, and vague abdominal pain are often the earliest manifestations of acute toxicity. Increased central vagal tone typically produces cardiac manifestations such as bradyarrhythmias or atrioventricular block. Neurologic manifestations such as weakness or confusion can occur independently of hypotension. The classic description of digoxin toxicity includes viewing yellow­green halos around objects, termed xanthopsia. However, patients more frequently describe nonspecific
 changes in color vision.
Hyperkalemia is an important finding in acute toxicity and may develop due to inhibition of sodium­potassium ATPase. Digoxin levels obtained within the first  hours following an acute ingestion may be falsely elevated; the level represents a predistribution level rather than reflecting the amount ingested. Overall, the severity of acute toxicity correlates most closely with the degree of hyperkalemia and correlates poorly with
 the early serum digoxin levels.
CHRONIC TOXICITY
Chronic toxicity occurs most typically in the elderly and is often the result of drug–drug interactions or declining renal function. Some of the more common drug interactions that predispose to chronic digoxin toxicity involve calcium channel antagonists, amiodarone, β­receptor antagonists, diuretics, indomethacin, procainamide, or erythromycin. A common scenario involves a patient being prescribed a diuretic, which results in mild dehydration and hypokalemia; dehydration reduces the clearance of digoxin, and hypokalemia increases susceptibility to digoxin, with the combination effect resulting in chronic toxicity.
Decreases in renal function and lean body mass associated with aging may alter the pharmacokinetics of digoxin, leading to toxicity at normally
 ,11 therapeutic doses. Older patients may also be at higher risk due to coexisting diseases and polypharmacy.
As compared to cases with acute digoxin toxicity, patients with chronic toxicity often have vague and nonspecific signs and symptoms. GI symptoms may occur with chronic toxicity, but they may be less pronounced than seen in the acutely toxic patient. Neurologic manifestations, such as
 weakness, fatigue, confusion, or delirium, are more prominent features in chronic toxicity.
DIAGNOSIS
The diagnosis of digoxin toxicity is a composite picture, using history, physical examination, and laboratory studies; no single element excludes or confirms the diagnosis. In patients with heart failure and normal renal function, daily digoxin doses are usually between 125 and 250 micrograms.
Digoxin toxicity can occur with a single ingestion of  to  milligrams in an adult, and fatalities have been reported following an acute ingestion of  milligrams in an adult and  milligrams in a child.
Differential diagnosis includes other bradyarrhythmia­inducing agents such as calcium channel antagonists, β­receptor antagonists, class IA antidysrhythmics (procainamide and quinidine), class IC antidysrhythmics (flecainide and encainide), clonidine and other imidazolines, and organophosphate or carbamate insecticide poisoning. Glycoside­containing and other cardiotoxic plants should also be considered (e.g., foxglove, squill, lily of the valley, oleander, rhododendron, monkshood, tobacco, false hellebore, and yew berry). Sick sinus syndrome, with its combination of supraventricular arrhythmias and cardiac conduction blocks, can also mimic digoxin toxicity. Hyperkalemia from any cause may produce bradycardia and abnormal cardiac conduction and should be considered in the differential diagnosis.
ECG
,13
In digoxin toxicity, almost any cardiac arrhythmia may be observed, with the exception of rapidly conducted atrial arrhythmias. The most
 common arrhythmias in digoxin toxicity are premature ventricular contractions and bradycardic rhythms. Ventricular arrhythmias occur more frequently in chronic than in acute poisonings. Although rare and not pathognomonic for digoxin toxicity, bidirectional ventricular tachycardia should be investigated for possible toxicity because only a few xenobiotics (digoxin included) are known to produce this unique arrhythmia.
Digoxin­toxic patients may have four specific ECG findings that are typically seen with therapeutic drug levels; presence of these findings does not indicate toxicity. The four findings are T­wave changes (such as flattening or inversion), QT­interval shortening, “scooped” depression of the ST
 segment, and increased U­wave amplitude (Figure 193­1).
FIGURE 193­1. ECG demonstrating findings seen with digoxin use. A. ECG shows scooping of ST segments and small U waves with a serum digoxin level of .9 nanogram/mL (1.15 nmol/L). B. ECG shows scooping of ST segments, flattening of T waves, and first­degree atrioventricular block with a serum digoxin level of .2 nanograms/mL (1.54 nmol/L).
LABORATORY

In acute poisonings, the serum potassium and digoxin levels can provide useful diagnostic information. As noted, acute poisoning of the sodiumpotassium ATPase pump may result in markedly elevated serum potassium levels. In this circumstance, the serum potassium level is a better indicator
 of end­organ toxicity (and a better prognostic indicator) than the serum digoxin level.
With chronic toxicity, in contrast to acute poisoning, the serum potassium and digoxin levels are less useful. In these patients, the serum potassium is usually normal or low due to concomitant diuretic therapy, but it may be elevated due to renal insufficiency. Thus, in the setting of chronic toxicity, measured serum potassium is more reflective of underlying comorbidities than the degree of inhibition of sodium­potassium ATPase by digoxin. Also, the serum digoxin level does not correlate with the clinical manifestations and may be within therapeutic ranges despite significant cardiac toxicity.
Serum digoxin level should be interpreted in the overall clinical context and not relied upon as the sole indicator of the presence or absence of toxicity.
Generally accepted therapeutic digoxin levels are .5 to .0 nanograms/mL (1.0 to .6 nmol/L), with corresponding toxic levels above .5 nanograms/mL (above .2 nmol/L). Due to a relatively slow distribution phase, high digoxin levels sampled from the serum following a recent acute ingestion are not always an accurate indicator of concentration at receptor sites. Serum levels are most reliable when obtained  hours after ingestion,
 when distribution is complete. Despite the limitations as just noted, it is generally true that higher serum digoxin levels are associated with greater likelihood of toxicity. Importantly, the serum digoxin level should not be the sole factor in establishing the diagnosis of digoxin toxicity, so do not wait for a digoxin level before implementing therapy in an unstable patient.
Some individuals have digoxin­like immunoreactive substances that cross­react with the digoxin assay, artificially elevating the serum digoxin levels even in the absence of cardiac glycosides. Digoxin­like immunoreactive substances may be found in neonates, third­trimester pregnant women, patients with subarachnoid hemorrhage, and patients with renal or hepatic dysfunction. In addition, naturally occurring cardiac glycosides and cardioactive steroids from plants and animals may cross­react with digoxin assays. The degree of cross­reactivity is variable, and no reproducible
 correlation has been established between these substances’ serum levels and toxicity.
TREATMENT
Management of a digoxin­poisoned patient includes general supportive care, treatment of specific complications of toxicity, prevention of further drug
 absorption, enhancement of drug elimination, antidote administration (when indicated), and safe disposition (Table 193­2). Although patients with intentional or accidental ingestions may present with no symptoms, life­threatening complications of toxicity should be anticipated. Management of the asymptomatic patient should focus on preventing drug absorption and closely monitoring for the development of toxicity. Continuous cardiac monitoring, IV access, and frequent reevaluations should be provided for any patient with a potentially toxic ingestion of digoxin.
TABLE 193­2
Overview: Treatment of Digitalis Glycoside Poisoning
Asymptomatic patients
Obtain accurate history.
Secure IV access.
Initiate continuous cardiac monitoring.
GI decontamination: Activated charcoal,  gram/kg PO, can be considered in an awake, alert, cooperative patient who presents within  h of ingestion.
Frequent reevaluation.
Symptomatic patients
Obtain accurate history.
Secure IV access.
Initiate continuous cardiac monitoring.
GI decontamination: Activated charcoal,  gram/kg PO, in an awake, alert, cooperative patient who presents within  h of ingestion.
Bradyarrhythmias
Atropine: .5–1.0 milligram IV as a temporizing measure for bradyarrhythmias while awaiting digoxin­specific antibody fragments
Transcutaneous pacing while awaiting digoxin­specific antibody fragments for symptomatic bradycardia that does not respond to atropine
Digoxin­specific antibody fragments: IV infusion (see later discussion for dose)
Cardiac arrest
CPR with current advanced cardiac life support protocols (prolonged CPR may be appropriate)17
Digoxin­specific antibody fragments: IV bolus (10 vials if amount ingested is unknown)
For the patient with life­threatening arrhythmias, identify and rapidly correct conditions such as hypoxia, hypoglycemia, hypovolemia, and electrolyte
 abnormalities. IV magnesium may counteract ventricular irritability seen with cardiac­glycoside toxicity. Use atropine and/or transvenous cardiac
 pacing as a temporizing treatment for bradyarrhythmias while preparing or obtaining digoxin­specific antibody fragments.
Digoxin­specific antibody fragments (digoxin­Fab) are the treatment of choice in acute poisoning with hyperkalemia (potassium
,21
>5.0 mEq/L) and in acute or chronic toxicity with any life­threatening arrhythmia. Hyperkalemia is not typically the cause of the death; it is instead a predictor of severe poisoning and increased mortality. Treatment of digoxin­induced hyperkalemia with insulin, dextrose, sodium
 bicarbonate, or exchange resins does not reduce mortality.
Administration of calcium salts in cardiac glycoside–induced hyperkalemia is controversial. Older literature indicated an increased incidence of ventricular arrhythmias and a higher mortality when calcium was administered to digoxin­toxic patients. However, data from an animal model and retrospective review of a limited number of human patients with digoxin toxicity who received IV calcium found no increase in ventricular arrhythmias
22–24 or mortality. Given that hyperkalemia is not typically the cause of death in digoxin toxicity, calcium salts are best avoided in cases of recognized digoxin toxicity. In summary, hyperkalemia in acute digoxin poisoning is an indicator of severe toxicity and digoxin­Fab should be given to reduce mortality.
In chronic toxicity, hypokalemia and hypomagnesemia should be corrected, because both predispose to digoxin toxicity.
GI DECONTAMINATION AND ENHANCED ELIMINATION

Administrating activated charcoal may have utility in early acute ingestion of digoxin. Activated charcoal may be of benefit following the acute
 ingestion of yellow oleander, although results of large, randomized trials have been mixed. Gastric lavage is not recommended; asystole during lavage has been reported in a digoxin­toxic patient, presumably from vagal stimulation during the procedure, and no clinical benefit has been demonstrated. Cathartics, forced diuresis, hemodialysis, and hemoperfusion have no role in enhancing elimination of digitalis glycosides. In patients with chronic renal failure who develop digoxin toxicity, there are limited data supporting use of binding resins such as cholestyramine to help enhance
 elimination.
DIGOXIN­SPECIFIC ANTIBODY FRAGMENTS (DIGOXIN­FAB)
Digoxin­Fabs are derived from ovine antibodies to digoxin. Following IV infusion, the antibody fragments bind digoxin in the plasma and distribute widely throughout the body, removing digoxin from tissues. In severely poisoned patients after digoxin­Fab administration, 90% will show reversal or significant improvement in life­threatening arrhythmia; in most cases, clinical improvement occurs within  hour. Patients in cardiac arrest had a 50% survival when receiving digoxin­Fab during the resuscitation, which is significantly better than historical survival with treatment with conventional
 therapies. Because of cross­reactivity with other cardiac glycosides, digoxin­Fabs are also beneficial in treating digitoxin, foxglove, and oleander
,25 poisonings, although large doses have sometimes been required. Indications for digoxin­Fab are life­threatening arrhythmias (including hemodynamically significant arrhythmias) and hyperkalemia in excess of  mEq/L associated with acute poisoning.
,27
Digoxin­Fab administration is associated with few adverse effects. Cardiogenic shock has been reported in patients dependent on digoxin for inotropic support. In addition, ventricular response to atrial fibrillation may be increased. Hypokalemia may develop rapidly as digoxin toxicity is reversed. There have been reports of mild acute hypersensitivity reactions, manifesting as rash, flushing, or facial swelling.
A full neutralizing dose of digoxin­Fab is based on an estimation of the total­body load of digoxin, which can be calculated from either the dose ingested or a steady­state serum digoxin level (Table 193­3). In an acute poisoning, each vial of digoxin­Fab reverses approximately .5 milligram of ingested digoxin. In hemodynamically stable patients, half the calculated total neutralizing dose is infused initially, and the other half is given if an
 adequate clinical response is not seen in  to  hours. Observational studies report that a total of 200 to 480 milligrams of digoxin­Fab (5 to  vials)
 were required to effectively treat severely digoxin­toxic patients. When the ingested dose is unknown and serum level is unavailable,  vials are recommended as initial treatment in life­threatening situations. Digoxin­Fab is administered IV through a .22­mm filter over  minutes, except in cardiac arrest, when the dose is given as an IV bolus.
TABLE 193­3
Calculation of Digoxin­Specific Antibody Fragment (Fab) Full Neutralizing Dose
Based on suspected amount ingested Digoxin body load (milligrams) = .8 × suspected ingested amount (milligrams)
Digoxin body load (milligrams) = serum digoxin concentration (nanograms/mL) × .6 L/kg × weight (kg)/1000
One vial (about  milligrams) of digoxin­Fab neutralizes .5 milligram of digoxin ingested
Based on total serum digoxin concentration Number of vials = serum concentration (nanograms/mL) × patient weight (kg)/100
Calculations of a full neutralizing dose may overestimate the amount of digoxin­Fab necessary, and smaller doses may adequately eliminate digoxin
 from the central compartment. In chronic toxicity, an acceptable approach in the hemodynamically stable patient without clear life­threatening arrhythmias is to administer half of the dose calculated by level. If instability develops, the remainder of the full calculated dose can be administered.

One to three vials (40 to 120 milligrams) of digoxin­Fab are often adequate in reversing chronic toxicity.
Total serum digoxin levels obtained following digoxin­Fab administration have little correlation with clinical toxicity. Because most laboratory assays do not distinguish between antibody­bound and unbound digoxin, total serum levels obtained following digoxin­Fab administration may increase 10­
 to 20­fold. However, because the Fab­digoxin complex is not pharmacologically active, this increased level does not correlate with clinical toxicity. In
 the presence of renal failure, the Fab­digoxin complex may persist in the circulation for prolonged periods. Recurrent toxicity can occur up to  days after digoxin­Fab administration in patients with renal failure as the complex degrades. Due to the large molecular weight of the Fab­digoxin complex
,32
(45,000 to ,000 Da), hemodialysis does not enhance its elimination, although plasma exchange may be of benefit. New liver support devices incorporating albumin­based dialysis and plasma filtration may be expected to be able to clear the Fab­digoxin complex based on molecular weight
 alone; some devices have been reported to clear substances up to 100 kDa. However, there is no experience using this technique with digoxinpoisoned patients.
DISPOSITION AND FOLLOW­UP
Extended observation with serial digoxin and potassium levels is recommended for anyone with a confirmed acute ingestion. Asymptomatic patients should be observed until the serum digoxin level is decreasing on serial measurements and the potassium level has remained normal. Patients with signs of toxicity should be admitted to a monitored unit. Consultation with a medical toxicologist or the regional poison control center is
 recommended. Patients receiving digoxin­Fab require intensive care unit observation for  to  hours. Patients in renal failure who receive digoxin­
Fab may be at risk of delayed toxicity, as the Fab­digoxin complex can dissociate several days later. Finally, patients with suspected suicidality should undergo behavioral health or psychiatric evaluation before discharge.


