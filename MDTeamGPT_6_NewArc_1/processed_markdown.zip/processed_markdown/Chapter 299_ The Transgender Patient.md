## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 299: The Transgender Patient
Monica L. Gaddis; Frances W. Grimstad
INTRODUCTION
A transgender person is someone whose gender identity differs from their sex assigned at birth. Sex is an assignment of “male” or “female” based on birth assessment of genitalia. An intersex assignment can also be made at birth based on ambiguous genitalia. Unlike sex, gender identity is selfidentified, not assigned, and may or may not be congruent with sex. Thus, transgender persons include those who were assigned as being of male sex at birth but who identify as female and those who were assigned as being of female sex at birth but who identify as male. Further, some individuals identify outside the male–female binary, including those who identify as both, neither, or in between, and may identify with terms such as gender
  nonbinary, gender nonconforming, or gender fluid. Approximately .5% of people in the United States identify as transgender. Not all transgender patients desire physical alignment.

Transgender identity is not classified as a mental disorder. Transgender patients should have access to respectful, nondiscriminatory, and affordable medical care. According to the 2015 National Transgender Discrimination Survey, 28% of the transgender respondents reported postponing necessary
 medical care due to prior negative experiences. In addition, 19% of those surveyed reported being denied care because they were transgender. More
 than 50% of transgender persons reported that they had to teach their healthcare provider about the health care that they needed. Transgender individuals may abstain from seeking medical care in an office­based setting due to fear of mistreatment and only seek episodic care in free clinics and
,6
EDs. Thus, it is of great importance that emergency providers become aware of the special healthcare needs of the transgender patient.
The World Professional Association for Transgender Health is a nonprofit organization that works for high­quality and evidence­based care for transgender and gender nonconforming individuals. The World Professional Association for Transgender Health provides an online resource for
 identifying culturally competent caregivers based on geographic location (state).
Table 299­1 contains a summary of current important terminology and definitions. Terminology is evolving and may change over time.
TABLE 299­1
Terminology and Definitions
Sex An assignment of “male” or “female” based on birth assessment of genitalia. “Sex” is identified as male or female on legal documents such as birth certificates, passports, and driver’s licenses, although some states are beginning to offer additional options (e.g., “other” or “X”) on legal documentation.8
Gender or gender A person’s inner feeling related to being male, female, both, something else, or neither. It is self­identified, and although it is identity initially identified as the same as the birth sex, it can be changed as a person ages. Thus, gender does not always align with sex.
Gender expression The external expression of how one affirms their gender. Gender expression is manifested through a person’s dress, mannerisms, hairstyle, speech pattern, or other behaviors. All of these components of gender result in an external identification of one’s being masculine and/or feminine. Gender expression may not always align with gender identity, as persons can identify as a feminine male or a masculine female.
Transgender An individual who identifies their gender as different from their sex assigned at birth. A transgender male was assigned female sex at birth but identifies as male gender. A transgender female was assigned male sex at birth and identifies as female gender.

Gender An individual whose gender identity falls outside the male–female gender binary (identifying as both male and female, neither,
Chapter 299: The Transgender Patient, Monica L. Gaddis; Frances W. Grimstad nonconforming/gender or something else). In this chapter, the term transgender includes persons identifying along the nonbinary spectrum as well.
. Terms of Use * Privacy Policy * Notice * Accessibility nonbinary/gender fluid
Transmasculine A person with a female sex assigned at birth who identifies as masculine on the gender spectrum.
Transfeminine A person with a male sex assigned at birth who identifies as feminine on the gender spectrum.
Cisgender A person whose gender identity is congruent with their sex assigned at birth. A cisgender person is also referred to as nontransgender.
Sexual orientation This term describes the sexual attraction for others that an individual possesses. It is self­identified and identified by gender, not sex. A transgender male who is attracted to other males may identify as a gay man. A transgender female who is attracted to males may identify as a straight female.
Transition The process of affirming or aligning one’s body with their gender. The process can include medical, legal, or social changes that are made during this process.
Gender dysphoria A state of distress. In the context of transgender care and gender identity, dysphoria describes the anxiety, trauma, or unease felt by a transgender person in situations when there is discordance between their gender and sex assigned at birth.
Gender affirmation A term used to describe actions, medications, surgeries, or feelings that are used by a transgender person to express their gender and/or align their body with their gender.
Chosen name The name a person uses when referring to themselves. May not be the same as their legal name. The name that should always be used when referring to a patient both directly and indirectly and included in handoffs.
Legal name This name is used on legal documentation and often is the name assigned at birth. The legal name is also called the “dead name” when the name is no longer used by the patient.
Pronouns Pronouns have historically been defined based on gender expression. Pronouns are a core part of a person’s identity and should not be presumed. Pronouns include masculine (he/him/his), feminine (she/her/hers), and gender neutral
(they/them/theirs).
CLINICAL ENVIRONMENT
Reducing barriers and creating a positive environment for health care for the transgender patient in the ED begins at triage and continues throughout

ED care. Use respectful and sensitive communication and documentation, including the use of correct terminology and pronouns. Provide privacy. If family or friends accompany the patient to the ED, ask the patient about any limits to conversation when others are present. Transgender­identified
,11 minors are at high risk for being forced to leave the home when family members become knowledgeable about the gender identity.
THE PATIENT GREETING
The first priority is to ensure that the patient is being addressed in the desired manner. Use the patient’s chosen name and be consistent in communication, documentation, and healthcare provider handoffs (including to allied healthcare professionals, trainees, financial counseling,
 volunteer staff, etc.). Ways to ask about names and preferred pronouns include the following:
. “Hello, my name is Dr. Lastname. What name do you go by? It is a pleasure to meet you [insert chosen name]. What pronouns do you use?”
. “Hello, I’m here to see [insert legal name]. What name would you like me to call you? What pronoun do you want me to use?”
. “Hello [insert chosen name], my name is Dr. Lastname. My pronouns are she, her, and hers. What pronouns do you use?”
PATIENT HISTORY AND EXAMINATION: SPECIAL CONSIDERATIONS
Contextualizing why questions are being asked can help the patient understand and help them prepare for difficult questions. Asking if there is a preferred, more gender­neutral terminology for body parts or processes (e.g., saying “monthly bleed” instead of “menses”) can help a patient feel more comfortable (Table 299­2). Next, it is important to ask about gender­affirming hormones and surgeries, not only for a complete history but also so that this information can be considered in the context of a chief complaint. For example, it is important to know if a transfeminine person has a neovagina if they are presenting with pelvic pain. Ask about past surgery, especially gender­affirming surgery, and hormone use and route. Not all transgender persons follow the same path with regard to hormones and surgeries or gender expression. Although a transgender male may experience
 amenorrhea shortly after the initiation of masculinizing hormone therapy, testosterone does not provide a form of birth control. Determine sexual activity and pregnancy risk.
TABLE 299­2
Medical Named Body Part With Possible Alternative Name* Medical Term Alternative Name
Penis External genitalia, phallus
Testes External genitalia
Breasts Chest tissue
Vagina Front hole, internal genitalia
*Defer to patient preference.

It is not necessary to visualize or examine the anatomic changes that accompany gender­affirming therapy and surgery, unless clinically applicable.
Address the chief complaint and describe the body exposure that will be required. Respect the patient’s preferences. If refusal puts the patient at risk, explain the risks in a compassionate manner.
MANIFESTATIONS OF GENDER­AFFIRMING TREATMENTS
This section discusses hormone therapy, medical illnesses that may be affected by hormone therapy, transgender­affirming surgery, and the complications of transgender­affirming surgery.
HORMONES
Because everyone’s transitional journey is unique, not every patient will use hormones, and the utilization of hormones does not make a patient more or less transgender than someone else. Some people will desire to use hormones but will lack access. These individuals may, in turn, use alternative resources for nonprescription hormones. Complications of hormone therapy are listed in Table 299­3. TABLE 299­3
Gender­Affirming Hormone Therapy–Related Complications
Feminizing Hormone Therapy
Hypercoagulability
Venous thromboembolism
Electrolyte imbalances
Hyperkalemia (with spironolactone use)
Prolactinoma
Increased risk of cardiovascular disease15
Masculinizing Hormone Therapy
Erythrocytosis
GONADOTROPIN BLOCKERS
Gonadotropin analogues (also termed gonadotropin­releasing hormone analogues or puberty blockers) are commonly used. Suppression of puberty allows a youth the opportunity to further explore gender identity without acquiring unwanted secondary sex characteristics from natal pubertal hormones. Puberty blockers can be initiated once a child reaches the pubertal stage of Tanner stage II.
Because the puberty blockers work to occupy the receptors in the pituitary, initially there is an increase in gonadotropin production followed by suppression. This increase is termed the flare and happens roughly  days after initiation. Some patients may experience hot flashes or fatigue if
 puberty blockers are initiated further along in puberty due to exposure to natal gonadal steroids followed by suppression.
Youth on puberty blockers alone should be treated like any prepubertal youth. They normally will not have progression of secondary sex
 characteristics, and laboratory values will show gonadotropin and sex hormone levels in the prepubertal range.
MASCULINIZING HORMONES
The goal with masculinizing hormones is to suppress estradiol levels and to achieve male range total testosterone levels (320 to 1000 nanograms/dL).
Testosterone at this level suppresses menses; increases libido; increases clitoral size; deepens the voice; produces male­pattern fat, muscle, and hair distribution; and increases energy. Side effects of testosterone include erythrocytosis (hematocrit >50%), which can increase risk for cerebrovascular disease and thrombosis; vaginal dryness; and changes in lipid profile (via decreasing circulating levels of high­density lipoprotein). Transaminase
,14 elevation can result from testosterone therapy. Cigarette smoking and morbid obesity increase the risk of venous thromboembolism (VTE).
Transmasculine persons who have been prescribed testosterone continue to have risks for estrogen­sensitive pathology. Guidelines recommend including any estrogen­sensitive pathology, such as uterine, ovarian, or breast malignancies, in the diagnosis as appropriate (Table 299­4).
TABLE 299­4
Breast Tissue Cancer Risk
Transfeminine patients: proliferative tissue
Transmasculine patients: residual tissue
Note: Guidelines recommend that transmasculine patients continue breast cancer screening guidelines for cis females and that transfeminine patients begin breast cancer screening guidelines for cis females after  years on estrogen therapy or at age .1
Testosterone does not provide any form of birth control. Screen for pregnancy if the patient has a uterus and ovaries, regardless of testosterone use. If a patient is found to be pregnant, stop testosterone pending pregnancy planning.
Some patients will present with pelvic bleeding while on testosterone. Testosterone causes vaginal atrophy, which can be a source of bleeding.

Evaluate for infection, pregnancy, and uterine pathology. Progestins can stabilize the uterine lining in patients with persistent uterine bleeding while on testosterone.
FEMINIZING HORMONES
Feminizing hormones come in two forms because of the potency of testosterone: estrogens and antiandrogens. 17­β­Estradiol is the form of estrogen used for feminization because it is the most bioidentical and the least thrombogenic of estrogen preparations. It comes in oral, transdermal, and intramuscular injectable forms. The goal of estrogen use is to suppress testosterone (to <55 nanograms/dL) and promote increased estradiol levels. Antiandrogens can be used as adjuvant therapies and include spironolactone (which inhibits testosterone secretion and androgen binding to receptors), finasteride (which inhibits the conversion of testosterone to dihydrotestosterone) and gonadotropin­releasing hormone analogues (which suppress gonadal steroid production). Feminizing hormone regimens cause breast growth, reduce body hair growth, redistribute fat and muscle, and soften skin. They have no effect on vocal cords or bone structure.
Side effects of feminizing hormones in general include decreased libido and reduced testicular volume and sperm production. Less frequent and less firm erections can also occur (mostly in those on spironolactone).
Estradiol side effects include breast tenderness, nausea and vomiting, dry skin, brittle nails, headaches, and increased appetite and weight gain.
Estradiol also increases the risk of thromboembolic disease due to increased production of coagulation factors. Patients with signs or symptoms
,17 concerning for thromboembolism should be considered at risk and should be evaluated for venous thromboembolism. Estradiol can cause prolactinomas in transfeminine persons. If a transfeminine patient taking estradiol presents with concerns for a pituitary space­occupying lesion or new­onset vision changes, especially any compromise of vision in one lateral field or in both lateral fields, or headaches, consider prolactinoma in the
  differential. Estrogen can increase the incidence of hypertension, gallstones, and hypertriglyceridemia.
Spironolactone is a diuretic and is the most commonly used antiandrogen in the adult transfeminine population. Side effects include hyperkalemia, increased urine output, and hypotension. GI upset can also occur.
Transgender patients may restrict fluid intake due to unsafe restroom conditions during the day. For those who are taking spironolactone, this is dangerous and can result in dehydration. Patients on spironolactone should have potassium and renal function checked as clinically indicated. Those
 who present with dehydration are also at increased risk of hyperkalemia.
NON–MEDICALLY PRESCRIBED HORMONES
Testosterone and estradiol can be acquired through nonmedical sources. Shared oral medication and third party–acquired injectable testosterone are common. With injectable testosterone use, there is an increased risk for human immunodeficiency virus and hepatitis due to shared needles. Also
 common is the use of birth control pills in place of prescribed estrogen.
GENDER­AFFIRMING SURGERIES AND THEIR COMPLICATIONS
Gender­affirming surgeries include procedures that are performed for non–gender­affirming reasons as well (e.g., breast implants, mastectomies, and hysterectomies), and the complications do not differ greatly. However, there are surgeries specific to gender affirmation with which many healthcare
,19­27 providers have limited or no experience. Gender­affirming surgeries and their complications are listed in Table 299­5. TABLE 299­5
Complications of Gender­Affirming Surgeries
Facial feminization surgery: Bleeding, wound infection, hematoma, swelling, pain
Facial masculinization surgery: Bleeding, wound infection, hematoma, swelling, pain
Transfeminine breast surgery: Prolonged swelling, surgical site wound infection, wound dehiscence, hematoma, pain, movement or rotation of implants, neuropathy around nipples
Transmasculine chest surgery: Bleeding, surgical site wound infection, wound dehiscence, hematoma, pain, swelling, neuropathy around nipples
Transfeminine genital surgery: After surgery—bleeding, hematoma, surgical wound dehiscence, urinary retention; long term—granulation of the tissue with dilation, stenosis of vagina, webbing of vagina or complete expulsion of graft, vaginal drainage and odor, rectovaginal fistula, urethravaginal fistula, urinary tract infection
Transmasculine genital surgery: After surgery—bleeding, hematoma, catheter infection; long term—urethrocutaneous fistula, urethral stricture, implant erosion, expulsion or rupture
GENITAL FEMINIZING PROCEDURES
Complete expulsion of a vaginal skin graft is a possible occurrence (usually in the first postoperative week). This represents a failure of the procedure
,22 and requires consultation with a surgeon for repair. Depending on the type of neovagina created, masses and precancerous lesions can appear inside the vaginal canal. If used to create the neovagina, colonic tissue poses risk for inflammatory bowel disease, colitis, or adenocarcinoma. Penile
 inverted tissue can develop skin lesions such as melanoma or psoriasis. Frequent discharge can be common after a vaginoplasty as dilation postoperatively will cause repeated trauma to granulation tissue. Discharge will diminish over time. Silver nitrate can be applied to any bleeding
 granulation tissue in the interim.
GENITAL MASCULINIZING PROCEDURES
Early in the postoperative course, patients go home with urinary catheters, which can obstruct or kink. Care should be taken with evaluation because the neourethra is still healing. Should a patient present further along with dysuria, evaluation should include a urine culture because white and red blood cells are present in urine sample after a normal reconstruction and are not necessarily evidence of a pathologic condition. Negative cultures in the setting of dysuria may indicate a stricture. Urethral strictures may happen up to  to  months after surgery. Patients may present with dysuria,
,26 reduced stream, and inability to pass a catheter on exam. Cystourethrography can be useful in identifying postoperative urethral complications. If the patient underwent a vaginectomy as a component of genital surgery, rectal injury is a possible complication. Another complication is the
 development of a fistula, which may communicate with the skin of the neophalus, scrotum, or perineal suture sites. For patients who have erectile
 implants, erosion through the skin of the phallus is a possible complication.
MENTAL HEALTH
Transgender persons disproportionately experience societal discrimination, mistreatment, harassment, and prejudice in everyday life. Table 299­6
,29 provides a list of mental health disorders and social issues.
TABLE 299­6
Mental, Social, and Health Issues in Transgender Persons
Compared to the cis population, transgender persons have increased prevalence of:
Human immunodeficiency virus infection
Substance abuse (drug and alcohol)
Mental health disorders (depression, suicide, anxiety disorder)
Physical assault (domestic violence, sexual assault, physical assault)
Homelessness
Sexually transmitted diseases

Do not assume that mental health issues are always related to the gender experience of the patient. At a minimum, depression, anxiety, and mood disorders occur as frequently in transgender patients as in the general population. Treatment of these mental health disorders follows typical treatment plans. However, be vigilant for mental health complaints that may be a result of the patient’s gender experience. Gender­related depression
 and anxiety with resultant suicidal ideation are prevalent in the transgender community. Also common are mental health issues related to drug and
 alcohol addiction, homelessness, and traumatic experiences such as physical assault, sexual assault, and abuse.
Emergency treatment of mental health issues in the transgender patient should follow the practices outlined in Section , “Psychosocial Disorders.”
30­32
The transgender patient should be referred to a mental healthcare provider who specializes in transgender care. In addition, because of the high rate and impact of societal stressors associated with being transgender, social services should be considered when patients need housing, food, and safety.


