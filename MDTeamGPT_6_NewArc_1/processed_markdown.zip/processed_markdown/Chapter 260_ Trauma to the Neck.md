## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 260: Trauma to the Neck
Ashley S. Bean
INTRODUCTION
The human neck contains numerous vital structures. Both blunt and penetrating injuries can damage structures from many organ systems. The challenge is to treat immediate, life­threatening complications of neck injury, such as airway compromise and hemorrhage, while recognizing subtle signs of serious pathology.
ANATOMY
The neck is anatomically defined by triangles, zones, and fascial planes. Each sternocleidomastoid muscle separates the neck into two descriptive triangles, anterior and posterior (Figure 260­1). The posterior triangle is bordered by the anterior surface of the trapezius, posterior surface of the sternocleidomastoid muscle, and the middle third of the clavicle. The anterior triangle is formed by the borders of the sternocleidomastoid muscle, inferior mandible, and midline of the neck. Most vital structures are contained within the anterior triangle.
FIGURE 260­1. Triangles of the neck.
The anterior triangle is further subdivided into three horizontal zones (Figure 260­2), which have historically determined whether a patient undergoes mandatory surgical exploration or further diagnostic evaluation. Using this classification system, the index of suspicion for injury to a particular structure is dictated by the zone (Table 260­1). Classically, zone II injuries undergo surgical exploration; zone I and III wounds undergo further evaluation. This zone­based approach assumes a direct correlation between the site of the external wound and damage to deep
,21­23 structures; however, the trajectory of the penetrating object can be difficult to determine clinically, and nearly half traverse multiple zones.
FIGURE 260­2. ZCohnaepst eorf 2th6e0 :n Tercaku.ma to the Neck, Ashley S. Bean 
. Terms of Use * Privacy Policy * Notice * Accessibility
TABLE 260­1
Anatomic Zone and Structures of the Anterior Neck
Neck Zone Anatomic Boundaries Structures
Zone  Clavicles to the cricoid cartilage Proximal carotid vertebral arteries
Major thoracic vessels
Superior mediastinum
Lungs
Esophagus
Trachea
Thoracic duct
Spinal cord
Zone  Cricoid cartilage to the angle of the mandible Carotid and vertebral arteries
Jugular veins
Esophagus
Trachea
Larynx
Spinal cord
Zone  Angle of the mandible and the base of the skull Distal carotid and vertebral arteries
Pharynx
Spinal cord
Finally, the neck is divided into fascial planes (Figure 260­3). The platysma is a thin muscle that stretches from the facial muscles to the thorax, demarcating superficial from deep wounds. Wounds that do not penetrate the platysma are not life threatening. The platysma muscle is enclosed within superficial fascia anteriorly and deep fascia posteriorly. The deep fascia is comprised of the investing, pretracheal, and prevertebral
 fascia and the carotid sheath. These fascial layers compartmentalize neck structures and, thus, can prevent exsanguination by confining hematomas.
Conversely, increased pressure from expanding hematoma or edema can compromise the airway. Further, the layers can serve as a conduit for infection tracking from the neck into the mediastinum.
FIGURE 260­3. Fascial layers of the neck. a. = artery; Int. = internal; n. = nerve; v. = vein.
INITIAL MANAGEMENT OF NECK INJURIES
The initial management of neck trauma follows the Advanced Trauma Life Support Guidelines with the systematic Airway, Breathing, Circulation, and
Disability approach. Perform a primary survey to identify and treat immediate life­threatening injuries, followed by a secondary survey to discover further injuries.
AIRWAY

Many patients with neck trauma have signs and symptoms of airway compromise. Patients with shock, airway obstruction, impending airway collapse, or altered mental status require immediate airway control (Table 260­2). Promptly intubate any patient at risk for airway compromise (Table 260­3) as airway anatomic distortion can progress rapidly. Assume a difficult airway in a patient with neck trauma. Keep all your adjuncts to intubation, as well as a secondary means of securing the airway, readily available.
TABLE 260­2
Clinical Factors Indicating Need for Aggressive Airway Management
Stridor
Acute respiratory distress
Airway obstruction from blood or secretions
Expanding neck hematoma
Profound shock
Extensive subcutaneous emphysema
Alteration in mental status
Tracheal shift
TABLE 260­3
Relative Indications for Airway Management
Progressive neck swelling
Voice changes
Progressive symptoms
Massive subcutaneous emphysema of the neck
Tracheal shift
Alteration in mental status
Expanding neck hematoma
Need to transfer symptomatic patient
Symptomatic patient with anticipated prolonged time away from ED
Rapid­sequence orotracheal intubation, the preferred modality for securing the airway in patients with neck trauma, is successful in 98% of patients,
 and may decrease the risk of hematoma expansion due to bucking or coughing. Cricoid pressure and positive­pressure ventilation prior to intubation
 may worsen airway injuries. When bag­mask ventilation is contraindicated or proves difficult due to airway distortion or physical characteristics, perform an awake, orotracheal intubation using a sedative or local anesthetic without a paralytic. Anticipate difficulty with bag­mask ventilation in patients with facial hair precluding a seal; unstable midfacial fractures; airway obstruction from blood, vomitus, or expanding hematoma; subcutaneous emphysema; or an open laryngeal injury that allows external passage of air.

Video laryngoscope–guided intubation and endotracheal intubation over a fiberoptic bronchoscope are useful techniques to secure the airway.
Video laryngoscopes with an endotracheal tube channel cause less manipulation of the pharynx and may be preferred in patients with neck trauma.
Additionally, the video laryngoscope may be used to guide a fiberoptic bronchoscope by allowing visualization of the relation of the larynx to the
 bronchoscope tip.
The laryngeal mask airway is a bridging device but is contraindicated in patients with significant airway distortion. Even if effective, the laryngeal mask airway is only a temporary method for ventilating trauma patients, not a definitive airway.
A surgical cricothyrotomy, or needle cricothyrotomy if the patient is younger than  years of age, is generally the last step in the failed airway management. Patients with neck trauma are at increased risked for requiring a surgical cricothyrotomy due to disruption of the laryngotracheal
  anatomy. In patients with extensive airway injuries, consider a surgical airway as the preferred primary modality. Although there are no absolute contraindications to cricothyrotomy, relative contraindications include suspected or known tracheal transection, fractured larynx, or laryngotracheal disruption with retraction of the distal segment into the mediastinum. Tracheal transection can occur in patients with a “clothesline injury.” In such patients, pharmacologic paralysis may cause loss of muscle tone with disruption of the proximal and distal tracheal segments. However, failure of
 intubation is an absolute indication for cricothyrotomy or surgical tracheostomy. If the patient has an open laryngeal disruption, you can perform direct intubation through the wound into the distal segment.
BREATHING
Pneumothorax and hemothorax are present in up to 20% of patients with penetrating neck trauma. Auscultate for the presence or absence of breath sounds during the primary survey. Suspect tension pneumothorax in patients with unilateral breath sounds, hypotension, and respiratory distress, and treat with needle decompression and/or placement of a thoracostomy tube. Needle decompression at the fourth or fifth
,11 intercostal space in the anterior axillary line is more likely to successfully penetrate the chest wall. Provide continuous pulse oximetry monitoring and supplemental oxygen.
CIRCULATION

Exsanguination is the proximate cause of death in most penetrating neck injury victims. Massive bleeding from trauma kills more rapidly than an unstable airway. Control hemorrhage by applying direct pressure to bleeding wounds. Be careful not to simultaneously occlude both carotid arteries or obstruct the patient’s airway. Do not blindly clamp vessels in the ED because this practice can lead to cerebral ischemia or nerve injury. If lifethreatening hemorrhage is not controlled by simple pressure, you can insert a Foley catheter into the wound tract and inflate the balloon until
 bleeding stops or you encounter resistance. Tactical medicine experience suggests that topical hemostatic static agents may improve the survival of patients with bleeding not controlled by pressure. Hemostatic dressings combined with direct pressure appear to decrease blood loss and increase
 patient survival. Hemostatic dressings applied to bleeding wounds during civilian prehospital transport demonstrated a 95% success rate of
 achieving hemostasis; half of the injuries treated with hemostatic dressing were head and neck wounds. Additionally, hemostatic dressings may benefit patients with uncontrolled bleeding who need transfer to another hospital for definitive care. Patients with uncontrolled hemorrhage despite
 these attempts require immediate surgery. If subclavian vessels are involved, uncontrolled hemorrhage in zone I injuries may require emergent thoracotomy.
DISABILITY

Unstable cervical spine injury is uncommon in awake, neurologically intact patients with an isolated penetrating neck injury. Vertebral fractures
 and spinal cord injury are exceedingly rare in patients with isolated stab wounds to the neck. Therefore, cervical collar placement may be detrimental
 by obscuring the injury and increasing the difficulty of hemorrhage control and intubation. Cervical collars should not be maintained at the expense of monitoring the injury or lifesaving procedures.
Spinal cord damage is more likely from gunshot wounds, and cord damage is sustained at the time of injury. Deficits should be evident at time of presentation unless the patient has an altered sensorium. Place a cervical collar on patients with a neurologic deficit or altered mental status
 precluding exam, after checking the neck to identify any penetrating injuries, vascular thrills or bruits, or bleeding or hematoma.
However, patients with blunt neck trauma frequently have cervical spine fractures, so maintain cervical spine immobilization in
 such injuries.
INITIAL RADIOLOGIC EVALUATION
Although conventional radiographs of the chest and neck may suggest a variety of pathologies in the patient with neck trauma (Table 260­4), most patients with penetrating or blunt neck trauma will require advanced imaging in the form of multidetector CT angiography (MDCTA), MRI, or magnetic resonance angiography. Obtain a chest radiograph to evaluate for pneumothorax and hemothorax in patients with neck trauma because there is a high incidence of these thoracic complications. In addition, pneumothorax and hemothorax can be detected rapidly by bedside ultrasound. Do not delay transfer of patients between hospitals or to the operating room to obtain conventional radiographs of the neck.
TABLE 260­4
Pathologic Findings on Conventional Radiographs
Chest radiograph
Pneumothorax
Hemothorax
Mediastinal air
Widened mediastinum
Subcutaneous emphysema
Foreign body or bullet fragments
Pulmonary edema
Aspiration pneumonia
Soft tissue neck radiograph
Prevertebral air
Foreign body or bullet fragments
Tracheal narrowing or deviation
Subcutaneous or retropharyngeal emphysema
Cervical spine radiograph (anteroposterior, lateral, and odontoid)
Vertebral fracture
Hyoid bone fracture
DIAGNOSIS AND TREATMENT
Any wound deep to the platysma raises concern for damage to the vital structures of the neck. Simple diagnostic maneuvers add valuable information to the physical exam. Instruct awake and cooperative patients to cough (to check for hemoptysis), to swallow saliva (to assess for dysphagia from esophageal injury), and to speak (to evaluate for laryngeal fracture). In patients with penetrating neck trauma, a careful,
 structured physical exam is more than 95% sensitive for detecting clinically significant vascular and aerodigestive injuries. The physical exam is most accurate for identifying arterial injuries; conversely, esophageal and venous injuries may be missed. Assess the patient for

“hard” and “soft” signs of injury (Table 260­5). Nine out of  patients with hard signs will have an injury requiring repair and should be rapidly transferred to the operating room or angiography suite. If your institution does not have the requisite surgical or diagnostic capabilities readily available, transfer to an appropriate hospital. Presence of soft signs increases suspicion of structural damage and indicates the
 need for additional diagnostic evaluation; however, only a minority of patients with soft signs will have a clinically significant injury.
TABLE 260­5
Signs and Symptoms of Neck Injury
Hard Soft
Vascular injury
Shock unresponsive to initial fluid therapy Hypotension in field
Active arterial bleeding History of arterial bleeding
Pulse deficit Nonpulsatile or nonexpanding hematoma
Pulsatile or expanding hematoma Proximity wounds
Thrill or bruit
Laryngotracheal injury
Stridor Hoarseness
Hemoptysis Neck tenderness
Dysphonia Subcutaneous emphysema
Air or bubbling in wound Cervical ecchymosis or hematoma
Airway obstruction Tracheal deviation or cartilaginous step­off
Laryngeal edema or hematoma
Restricted vocal cord mobility
Pharyngoesophageal injury
Odynophagia
Subcutaneous emphysema
Dysphagia
Hematemesis
Blood in the mouth
Saliva draining from wound
Severe neck tenderness
Prevertebral air
Transmidline trajectory
PENETRATING NECK INJURY

Although penetrating neck wounds account for only 1% of traumatic injuries, the mortality rate is as high as 10%. Gunshot wounds and stab wounds
,20 are the predominant mechanisms of injury, whereas flying debris and sharp object impalement are less frequent causes. Patients often have
 significant concurrent wounds to the head, chest, or abdomen.
Gunshot wounds are more likely than stab wounds to cause vascular and aerodigestive system damage. Transcervical gunshot wounds have at least a
70% chance of substantial associated injuries. Vascular injuries are the most common cervical injury and the leading cause of death from
 penetrating neck trauma. The remainder of associated neck injuries are split among spinal cord, aerodigestive tract, and peripheral nerve injuries.
There is no debate regarding the treatment of unstable patients with clear evidence of vascular or aerodigestive injury—this group of patients should
,4 undergo invasive intervention. Controversy arises in two areas concerning the management of stable patients:
. Should all zone II injuries undergo mandatory exploration?
. Should all zone I and III injuries undergo a specific, extensive battery of diagnostic testing?
GENERAL TREATMENT OPTIONS
MANDATORY OPERATIVE EXPLORATION
Historically, all zone II injuries were surgically explored. This aggressive practice began during World War II as a response to a high incidence of missed injuries and mortality, but selective management is generally recommended today to minimize unnecessary surgery. Zone II is the most commonly injured area and is easily accessed surgically. Exposure and vascular control are more difficult for zone I and III injures, so most patients with zone I and
III injuries undergo angiography and endoscopy to determine the need for operative intervention.
SELECTIVE MANAGEMENT
The movement toward selective management rather than mandatory exploration began in response to the high rate of negative neck explorations.
Furthermore, advocates of a more conservative methodology cite the sensitivity of physical exam in detecting clinically significant injuries. Contrarians maintain concerns about missed lethal injuries when relying solely on the clinical exam. Less invasive, selective protocols, which mandate rapidly obtained angiography, esophagography, and panendoscopy, have radically decreased nontherapeutic neck operations without increasing morbidity
,8 and mortality; however, the yield of angiography and endoscopic studies in asymptomatic patients is exceedingly low.
NO­ZONE TARGETED DIAGNOSTIC WORKUP
A new iteration in selective management has evolved with the addition of information gleaned from MDCTA to the diagnostic process. MDCTA now permits fast, reliable information about injuries in all neck zones. Furthermore, physical examination plus MDCTA is up to 100% sensitive and .5% specific for detecting significant vascular or aerodigestive injury. Perhaps more importantly, the negative predictive value for arterial injury is 98% to

100%. Unlike angiography, MDCTA also allows assessment of the aerodigestive tracts and the cervical spine.
In addition to defining specific injuries, MDCTA can determine if the wound track approximates important structures. Wounds with a trajectory not concerning for injury do not need further invasive (angiographic or endoscopic) workup. Conversely, trajectories in close proximity to vital structures should prompt a targeted diagnostic workup. Disadvantages of MDCTA include exposure to ionizing radiation, use of iodinated IV contrast, and image
  artifacts due to motion or metallic foreign bodies. Less than 2% of MDCTAs are nondiagnostic due to artifact.
One concern is that undergoing post­MDCTA angiography poses unnecessary contrast nephropathy risk for patients suffering penetrating neck
23­26 injuries. However, several studies suggest that the incidence of postcontrast nephropathy is much lower than formerly believed.
A penetrating neck trauma protocol (Figure 260­4) that combines a structured physical exam and MDCTA dramatically reduces formal neck
,27 explorations. In this scheme, the zone of injury has little impact on the management of the patient because the neck is considered to be a single unit. Per this protocol (see Figure 260­4), symptomatic patients with hard signs of neck injury undergo emergent operative or angiographic intervention. Symptomatic patients with only soft signs of injury are at intermediate risk and should undergo MDCTA. Further diagnostic testing can be
,28 guided by MDCTA findings. Symptomatic patients with an indeterminate MDCTA artifact should undergo traditional testing.
FIGURE 260­4. Penetrating neck trauma protocol. CTA = CT angiography.
Asymptomatic patients are at low risk for injury. A study of  asymptomatic patients (80% underwent MDCTA) demonstrated no clinically significant
 injuries. No patient is this group underwent further diagnostic testing. Specific concern for digestive tract injuries can be addressed via esophagoscopy or esophagram; potential laryngotracheal injuries can be evaluated with endoscopy. Trauma centers with a high volume of
 penetrating neck injuries may opt to observe patients with serial physical exams in lieu of advanced diagnostic testing.
PENETRATING VASCULAR INJURIES
Vascular injuries are present in up to 40% of patients with penetrating neck trauma and are the most commonly associated cervical injury in this population. Arterial injuries, which predominantly involve the carotid artery, account for 45% of penetrating neck vascular trauma and
,8 are the most frequent cause of death. The morbidity and mortality of vascular injuries are related both to exsanguination and neurologic
 complications. For instance, carotid artery injury leads to stroke in 15% of patients and death in up to 22%. Venous injuries are discovered in up to 20% of patients with penetrating neck wounds. Signs of venous injury are often subtle and difficult to identify by physical exam; however, most asymptomatic venous injuries do not require repair.
The overwhelming majority of patients with hard signs of vascular injury (Table 260­5) will require operative intervention. In contrast, while up to one quarter of patients with soft signs of vascular injury will have a vascular abnormality identified at angiography, only 3% of these patients will require
 vascular repair.
DIAGNOSIS AND TREATMENT
Several imaging modalities are useful during the evaluation of vascular neck trauma (Table 260­6). Although angiography remains the gold standard
 for investigating penetrating neck vascular injuries, MDCTA is now the first­line imaging modality. Angiography continues to be useful, however, in specific circumstances. MDCTA findings that are inconclusive or incongruent with the patient’s clinical exam should be refined by
  angiography. In addition, stable patients with injuries suitable for endovascular repair may undergo definitive angiographic intervention.
TABLE 260­6
Vascular Evaluation of Penetrating Neck Trauma
Imaging
Advantages Disadvantages
Modality
Catheter Gold standard Invasive angiography Both diagnostic and therapeutic Expensive
Access to zone I and III injuries where surgical repair is difficult Labor intensive
Requires skilled operators
Helical CT Readily available Only diagnostic, not therapeutic angiography Fast Requires IV contrast
Minimally invasive Image quality affected by technique of contrast injection
Visualization of missile trajectory Metallic streak artifact may obscure findings
High­resolution images of vascular, aerodigestive, and bone Limited evaluation of low zone I and high zone III injuries structures with single study May miss small intimal flaps, pseudoaneurysms, and arteriovenous fistulas
Duplex Noninvasive Highly operator dependent ultrasonography Inexpensive Limited view of zones I and III
No contrast medium Obscured by subcutaneous emphysema and hematomas
May miss small lesions
Disadvantages of angiography include its inability to provide a comprehensive evaluation of nonvascular neck structures, limited availability, and
 mobilization of additional personnel. Potential complications include contrast­induced nephropathy, puncture site hematoma, thrombosis, embolism, vascular spasm, ischemia, and arterial dissection.
The advent of CT angiography and improvements in multidetector CT technology have revolutionized the diagnosis and treatment of penetrating neck injuries. MDCTA images the vascular, aerodigestive, and osseous structures of the neck. Furthermore, MDCTA is sensitive for the detection of injury,
 can be rapidly performed, and is noninvasive, accurate, and widely available.
Color flow Doppler US is highly sensitive for detecting clinically important vascular injuries. Advantages of US include its portability, noninvasive nature, lack of ionizing radiation, and relatively decreased capital expense. Disadvantages include the inability to scan through subcutaneous emphysema, hematoma, marked operator variability, and limited availability. Additionally, US cannot penetrate bone and is thus unable to image
  intrathoracic or intracranial vessels. Finally, it cannot evaluate the aerodigestive structures of the neck.

MRI or MRI angiography in patients with metallic projectiles is contraindicated due to concern for ferromagnetic material. Furthermore, the role of MRI in the diagnosis of aerodigestive injuries has not been evaluated. Thus, MRI cannot be used to comprehensively evaluate neck
  structures. MRI may play a select role in the evaluation of nonprojectile penetrating trauma that involves the cervical spine.
Treatment of vascular injuries depends on the vessel involved and accessibility of the lesion. Options vary from observation to surgical repair to angiographic embolization or stenting. Patients with carotid artery injuries that are asymptomatic, low­velocity injuries, or small intimal tears or pseudoaneurysms may not need repair if they have intact distal circulation and reliable surgical follow­up.
BLUNT NECK INJURY
Blunt neck trauma composes only 5% of traumatic injuries to the neck. Road traffic accidents are the most common cause of blunt neck trauma. Other
 causes of blunt neck injury include assault, pedestrians struck by vehicles, falls, and hanging. While vascular injury occurs in approximately 1% of patients with blunt neck trauma, cervical aerodigestive injuries are rare. As with penetrating neck trauma, patients with blunt neck injury frequently have significant associated injuries. In contrast, airway occlusion rather than hemorrhage is the most rapidly fatal injury.
BLUNT CAROTID AND VERTEBRAL DISSECTION

The mortality rate of symptomatic blunt cerebral vascular injury approaches 60%. However, most patients with blunt cerebral vascular injury are
 initially asymptomatic and do not develop neurologic symptoms for hours to days. Fortunately, angiographic screening of certain asymptomatic
 patients for blunt cerebral vascular injury can increase the likelihood of diagnosis 10­fold. Moreover, early identification and treatment of blunt
 cerebral vascular injury significantly reduce the rate of stroke and death. Numerous screening criteria can be used to increase blunt cerebral vascular
,33,34 injury detection in asymptomatic patients (Table 260­7). Unfortunately, if using traditional screening criteria, 20% of blunt cerebral vascular injuries occur without any established risk factor. To capture all injuries using injury pattern modeling, an estimated 96% of trauma patients would
 need to be screened ; however, a proposed expanded Denver screening protocol is purported to reduce the number of missed blunt cerebral
 vascular injuries to 5%.
TABLE 260­7
Screening Criteria for Blunt Cerebral Vascular Injury
Signs and symptoms
Arterial hemorrhage from nose, neck, or mouth
Cervical bruit in patients <50 y old
Expanding cervical hematoma
Focal neurologic deficit: transient ischemic attack, hemiparesis, vertebrobasilar symptoms, Horner’s syndrome
Stroke on secondary CT
Neurologic deficit unexplained by head CT
Risk factors for blunt cerebral vascular injury
High­energy transfer mechanism and one of the following:
Facial fractures: Le Fort II or III fracture, mandible fracture, frontal skull fracture, orbital fracture
Cervical spine fracture patterns: subluxation, fractures extending into the transverse foramen, fracture at any level
Any basilar skull fracture or occipital condyle fracture
Petrous bone fracture
Diffuse axonal injury with Glasgow Coma Scale score ≤8
Concurrent traumatic brain and thoracic injuries
Neck hanging with anoxic brain injury
Clothesline type injury or seat belt injury with significant swelling, pain, or altered mental status
Scalp degloving
Thoracic vascular injuries
Blunt cardiac rupture
Upper rib fractures
The mechanism of injury for blunt cerebral vascular injury is cervical hyperextension and rotation or hyperextension during rapid deceleration, which
 can result in intimal dissections, thromboses, pseudoaneurysms, fistulas, and transections. Intimal tears expose subendothelial collagen that acts as a substrate for platelet aggregation. The subsequent thrombus can embolize, cause stenosis, or create critical vessel occlusions. Furthermore, tears can provide a pathway for dissection.
DIAGNOSIS AND TREATMENT
Digital subtraction angiography is the gold standard for the diagnosis of blunt cerebral vascular injury. Rapid diagnosis and treatment are crucial. Due to the lack of digital subtraction angiography availability and potential complications associated with this procedure, many institutions use MDCTA as the initial screening modality. While MDCTA has a negative predictive value approaching 100% for subsequent stroke, it has a false­positive rate of approximately 45%. To avoid unnecessary anticoagulation, a reasonable approach is to use MDCTA as a screening exam followed by digital subtraction
 angiography to confirm true positives. Continue anticoagulation until digital subtraction angiography results confirm the need for further therapy.
US has a low sensitivity for blunt cerebral vascular injury and should not be used as a screening test.
MRI has a variable sensitivity (50% to 100%) and specificity (29% to 100%) as compared to digital subtraction angiography for detection of blunt cerebral vascular injury. Therefore, do not use MRI as the sole screening study for blunt cerebral vascular injury unless the patient has an absolute
 contraindication to iodinated contrast.

Patients with untreated or undiagnosed blunt cerebral vascular injury have up to a 60% risk for stroke with rates increasing with injury grade severity.
Antithrombotic agents (aspirin, clopidogrel, or heparin) and operative or interventional angiographic repair are blunt cerebral vascular injury
 treatment options. Antithrombotic agents dramatically reduce mortality and morbidity after blunt cerebral vascular injury and are safe even if the
,42 patient has a traumatic brain injury, solid organ injury, spinal cord injury, or concomitant neurologic hemorrhage. No differences in outcomes of
,44 blunt cerebral vascular injury patients treated with anticoagulant versus antiplatelet therapy have been demonstrated. Specific therapy is determined by a grading scale (Table 260­8).
TABLE 260­8
Blunt Carotid and Vertebral Artery Injury Grading Scale
Grade Description Treatment
Grade Luminal irregularity or dissection with <25% luminal narrowing Antithrombotic agent
I
Grade Dissection or intramural hematoma with ≥25% luminal narrowing, intraluminal thrombus, or Antithrombotic agent or surgical repair if
II raised intimal flap accessible
Grade Pseudoaneurysm Antithrombotic agent or surgical repair if
III accessible
Grade Occlusion Antithrombotic agent or surgical repair if
IV accessible
Grade Transection with free extravasation Surgical repair if accessible
V Balloon occlusion or embolization
UPPER AIRWAY AND ESOPHAGEAL INJURIES FROM BLUNT AND PENETRATING TRAUMA
LARYNGOTRACHEAL INJURIES
,8
Penetrating neck trauma causes laryngotracheal injury in 2% to 5% of penetrating trauma patients and has a 2% to 15% mortality rate.
Significant laryngotracheal injuries should be detected by physical exam. Patients with hard signs of laryngotracheal injuries (Table 260­5) need urgent airway control and operative intervention. Soft signs of laryngotracheal injury (Table 260­5) are present in approximately 18% of patients
 with penetrating neck injury, but only 15% of these patients will have a laryngotracheal injury diagnosed.
Blunt laryngotracheal injuries occur in less than .5% of blunt trauma patients. The majority of blunt laryngotracheal trauma is caused by car
 collisions. Such injuries are rare because the larynx is protected by the mandible and supported by muscles that deflect most external forces.
Patients with laryngotracheal injuries due to blunt trauma may have a quiescent phase with progressively increasing subclinical airway edema or hematoma that can result in delayed airway obstruction.
DIAGNOSIS AND TREATMENT
,46
Evaluate patients with a history of significant anterior neck trauma or signs and symptoms of a laryngotracheal injury with flexible fiberoptic laryngoscopy to define airway patency and the extent of intraluminal injury. CT imaging is critical in patients with suspected laryngotracheal injury
 without airway compromise and can impart information that influences management. Treatment of laryngotracheal injuries is based on the classification system developed by Schaefer and Brown (Table 260­9). Patients with grade I and II injuries can be managed medically; grade III, IV, and
V injuries typically require operative intervention.
TABLE 260­9
Laryngeal Injury Grading Scale
Grade I Minor endolaryngeal hematoma without detectable fracture
Grade II Edema, hematoma, minor mucosal disruption without exposed cartilage, nondisplaced fractures
Grade III Massive edema, mucosal disruption, exposed cartilage, vocal fold immobility, displaced fracture
Grade IV Grade III with two or more fracture lines or massive trauma to laryngeal mucosa
Grade V Complete laryngotracheal separation
PHARYNGOESOPHAGEAL INJURIES
Up to 9% of patients with penetrating neck trauma have pharyngoesophageal injuries. Whereas laryngotracheal injuries are usually apparent, pharyngoesophageal injuries typically have more subtle signs, resulting in diagnostic delays. In fact, there are no hard signs of pharyngoesophageal injury. Deaths from esophageal injury are usually due to mediastinitis and sepsis. Soft signs and symptoms (Table 260­5) that portend injury may be present and signal the need for further evaluation. Also suspect this injury if the trajectory of the bullet visualized by CT is in
 close proximity to the pharynx or esophagus. Finally, in patients receiving conventional soft tissue neck radiographs, prevertebral air is suggestive of a pharyngoesophageal injury.
Pharyngoesophageal injuries are exceedingly rare in patients with blunt neck trauma. Between 1970 and 2003,  cases of cervical digestive tract injury due to blunt forces were reported. Suspect esophageal injury in patients with a history of a sudden acceleration or deceleration event in which the neck was extended. In this scenario, injuries occur as the esophagus is forced against the spine. However, the low incidence of injuries coupled with their subtle clinical presentation can lead to a delay in diagnosis, leading to morbidity and mortality. In patients with blunt trauma, the signs and symptoms of pharyngoesophageal injury are much more likely to result from laryngotracheal pathology.
DIAGNOSIS AND TREATMENT
Patients with hard signs of vascular or laryngotracheal injuries should undergo intraoperative endoscopy if a pharyngoesophageal injury is identified or suspected during exploration. Symptomatic patients who do not meet criteria for neck exploration can be evaluated by either direct esophagoscopy
 or swallowing studies. Esophagoscopy is more sensitive for detecting esophageal injuries with the added benefit of quantifying the size and extent of the injury. It can be performed intraoperatively and on unstable or intubated patients. The combination of these two studies achieves 100% sensitivity for detecting these injuries.
Patients who are asymptomatic can be evaluated for digestive tract injuries with multidetector CT. Patients without evidence of injury by multidetector
CT should either be observed or, if a high suspicion for injury exists, undergo direct esophagoscopy or swallowing studies using a water­soluble
 agent.
Treat pharyngoesophageal injuries with IV antibiotics. Small pharyngeal perforations may be managed medically, whereas pharyngeal perforations larger than  cm and esophageal perforations require surgical repair.
STRANGULATION
Strangulation is one form of blunt neck trauma. Mechanisms include hanging, postural strangulation, ligature strangulation, and manual
 strangulation. Accidental, homicidal, and suicidal strangulations are frequent causes of death. In fact, 10% of violent deaths in the United States are
  due to strangulation, and hanging is the second most common means of suicide death in the United States. Accidental strangulation is more frequent in children, but also occurs in adults whose clothing or hair becomes entangled in machinery or who participate in the paraphilia of erotic asphyxiation. In all forms of strangulation, death is ultimately due to cerebral anoxia and ischemia; obstruction of cerebral venous return rather than acute airway compromise is postulated to be the most common pathophysiologic mechanism of death.
CLINICAL FEATURES
Although airway compromise is envisioned by most people to be the cause of strangulation deaths, the major pathologic mechanism is neck vessel occlusion rather than airway obstruction. There are numerous case reports of people with functioning tracheostomies committing suicide by hanging or strangulation. Only limited pressure is needed for venous compression. If both external and internal jugular veins are simultaneously occluded, cerebral vascular congestion, edema, and unconsciousness result. Next, loss of muscle tone allows arterial compression with subsequent cerebral anoxia. Airway obstruction and carotid body reflex–mediated cardiac dysrhythmia are minor mechanisms of death in strangled patients.
In addition to cerebral anoxia, strangulation injuries include laryngotracheal fractures, cervical spine fractures, pharyngeal lacerations, and carotid artery injuries. Although hyoid bone fractures are classically associated with strangulation, they are found in a minority of these patients—even those with fatal injuries. Furthermore, except for judicial hangings, cervical spine and cord injuries are not frequently seen in patients who survive strangling. Carotid artery dissection is a rare complication, but should be suspected in a patient with a lateralizing neurologic exam or bruising or tenderness over the carotid artery. Moreover, consider unreported strangulation in young patients with acute neurologic deficits or a spontaneous carotid artery dissection.
Physical signs of strangulation include petechiae and neck contusions; however, half of victims have no visible signs of neck trauma, and two thirds are
 asymptomatic. In fact, patients with extensive laryngeal injury may have few external signs. In those who are symptomatic, the most common complaints are neck pain, voice changes, swallowing difficulty, and breathing problems. Any of these symptoms can signal impending airway compromise and should be investigated.
Patients presenting in cardiac arrest have a dismal prognosis. Conversely, recovery of patients with neurologic symptoms is unpredictable. Patients with severe neurologic symptoms, such as a Glasgow Coma Score of , may recover without sequelae, whereas patients with normal initial exams may
 progressively deteriorate. Most in­hospital, poststrangulation deaths occur due to laryngeal or pulmonary edema or cerebral anoxia.
Perhaps the most difficult task in caring for strangled patients is evaluating the “walking and talking” victim who lacks physical signs of strangulation.
Victims may be under the influence of alcohol or drugs or be hyperventilating. Physicians may be tempted to ascribe symptoms to anxiety and to
 discount the patient’s story. Furthermore, there is a subset of seemingly asymptomatic patients who die after developing delayed cerebral or pulmonary edema.
DIAGNOSIS
The evaluation of patients with suspected strangulation is multifaceted and may involve radiologic imaging or endoscopy. Although pulmonary edema, aspiration pneumonia, larynx or hyoid bone fractures, or tracheal deviation caused by edema or hematoma may be visible on chest radiography, CT and MRI can provide more detailed information of soft tissue neck structures. Radiologically demonstrated intramuscular hemorrhage or edema,
 swelling of the platysma, subcutaneous bleeding, and hemorrhagic lymph nodes are indicative of strangulation injury. To exclude carotid dissection,
 carotid artery imaging should be performed on patients with neurologic deficits discordant with brain CT findings. Finally, patients with symptoms of laryngeal tracheal injury such as dyspnea, dysphonia, aphonia, or odynophagia should undergo laryngobronchoscopy, which may reveal petechiae,
 edema, or vocal cord paralysis.
TREATMENT AND DISPOSITION
Patient with hard signs of strangulation injury (Table 260­10) should undergo further diagnostic testing. Admit patients with abnormal radiologic or endoscopic imaging to the appropriate service and level of care. Observe symptomatic patients with normal imaging. Barring psychosocial issues, asymptomatic patients may not need further evaluation and may be discharged if friends or family are available for patient monitoring. Emphasize
 strict return precautions as well as education about possible delayed respiratory and neurologic dysfunction.
TABLE 260­10
Hard Signs of Strangulation Injury
Head, Eyes, Ears, Nose, and Throat
Visual disturbances
Conjunctival or facial petechial hemorrhages
Swollen tongue or oropharynx
Foreign body (blood, vomit, tissue) in oropharynx
Facial edema, lacerations, abrasions, ecchymosis
Neck abrasions, edema, lacerations, or ligature marks
Tenderness to palpation over larynx
Hoarseness or stridor
Subcutaneous edema or crepitus
Cardiovascular
Cyanosis or hypoxia
Arrhythmias
Respiratory distress
Crackles or wheezes
Cough
Neurologic
Altered mental status
Seizures
Stroke­like symptoms
Incontinence
Source: Data from https://www.ncbi.nlm.nih.gov/books/NBK459192/ (Dunn RJ, Smock W: Strangulation injuries. 2017.) Accessed July , 2018. Unconscious patients and those with progressive symptoms such as odynophagia, hoarseness, neurologic changes, or dyspnea require aggressive airway management. Patients with pulmonary edema may benefit from positive end­expiratory pressure ventilation. Furthermore, patients may
 develop cerebral edema, requiring strategies to reduce intracranial pressure or seizure prophylaxis.
Addressing the numerous psychosocial issues that are typically present in strangled victims is a critical element of their overall coordinated treatment plan. Victims of domestic violence may need social services. Only 5% of strangled domestic violence victims seek medical attention within  days of the
 strangulation. Such patients are at high risk for subsequent harm and death from the same abuser. Survivors are also at risk for posttraumatic stress disorder. Patients who have attempted suicide require psychiatric evaluation. Hangings are often one component of a complex suicide attempt. When
 suicide is suspected, evaluate patients for other methods of self­harm such as wrist lacerations, self­stabbing, gunshot wounds, or ingestions.
SPECIAL CONSIDERATIONS
CHILDREN
Children with blunt or penetrating trauma are susceptible to the same mechanisms and injuries as adults. Additional mechanisms of injury seen in childhood include child abuse, playground trauma, and handlebar injuries during bike falls.
The initial management and indications for emergent intervention for children with penetrating neck trauma mirror those of adults. Children are at higher risk for complications from angiography, endoscopy, and ionizing radiation. Thus, the need for an extensive workup in the asymptomatic child must be critically evaluated.
Children have the same incidence of injury and ischemic sequelae of blunt cerebral vascular injury. The 40% rate of ischemic symptom development in
 untreated children with blunt cerebral vascular injury is reduced to nearly zero when treatment is initiated during the quiescent phase.
Children have certain anatomic characteristics that protect them from laryngeal injury. In addition to being more flexible, the larynx is located in a higher, more protected position. Conversely, there are features that predispose children to developing symptomatic airway edema. During childhood, the diameter of the larynx is smaller and its mucosa is more loosely attached, allowing edema and hematomas to progress. Therefore, children are more likely to present with respiratory distress.
As with adults, pharyngoesophageal injuries are rare and often have a subtle, delayed presentation. Maintain a high index of suspicion for these injuries.
ANTICOAGULATED OR MASSIVELY BLEEDING PATIENTS
Correct coagulopathy in patients with neck trauma who are taking anticoagulants. See Table 166­5 for suggested protocols for anticoagulant reversal.
The exception to this recommendation is for patients with blunt cerebral vascular trauma, because the majority of these injuries are treated with antithrombotic agents.

Finally, resuscitate massively bleeding patients with blood products in ratios as outlined by a massive transfusion protocol. Also, consider administering tranexamic acid to bleeding trauma patients. The CRASH­2 trial demonstrated that this antifibrinolytic significantly reduces deaths
 from traumatic bleeding when given within  hours of the inciting injury.


