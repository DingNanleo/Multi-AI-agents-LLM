## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 162: Global Travelers
Shawn M. D’Andrea; Annelies De Wulf
INTRODUCTION

Of returning travelers who become ill, many have neither serious nor exotic illnesses. In a study evaluating ,825 returning travelers seen in global
 travel clinics between 1996 and 2011, only .4% (3655) of the cases involved acute, tropical, potentially life­threatening causes of illness. The initial task is to separate the more common causes of symptoms, such as upper respiratory infections, diarrheal illnesses, reactions to stress, fatigue, or new medications, from more ominous causes of illness in travelers.
Key points for the initial ED care are as follows:
. Isolate and use personal protective precautions early when evaluating patients with suspected travel­related infections.
. Identify red flag symptoms such as hemorrhage and altered mental status and initiate isolation and treatment prior to diagnostic confirmation.
. Consider malaria in the febrile patient returning from travel, even in the presence of prophylaxis, and initiate treatment promptly.
. Report suspected reportable illnesses.
INITIAL EVALUATION OF THE RETURNING TRAVELER

Illness before and after travel is common (Table 162­1). Start by evaluating the travel destination. Diseases such as malaria are uncommon in the
United States, but are leading causes of mortality overseas. Other parasitic agents, such as helminths and rickettsia, also occur with increased frequency and severity in the tropics (see Chapters 159 and 161, “Malaria” and “Zoonotic Infections”). Although both tuberculosis and human immunodeficiency virus are endemic to the United States, consider these in patients presenting from areas with a higher disease burden.
TABLE 162­1
Risk of Infectious Exposure
High risk (1 in  travelers): diarrhea, upper respiratory illness, and noninfectious illnesses such as injuries and exacerbation of preexisting chronic diseases
Moderate risk (1 in 200 travelers): dengue fever, chikungunya, enteroviral infection, gastroenteritis, giardiasis, hepatitis A, malaria, salmonellosis, sexually transmitted diseases, shigellosis
Low risk (1 in 1000 travelers): amebiasis, ascariasis, measles, mumps, enterobiasis, scabies, tuberculosis, typhoid, hepatitis B
Very low risk (1 in >1000 travelers): human immunodeficiency virus, anthrax, Chagas’ disease, hemorrhagic fevers, pertussis, plague, typhus, hookworm
HISTORY
Once imported disease in recent travelers is suspected, direct the history (Tables 162­2, 162­3 and 162­4). Immunosuppression, age <5 years, advanced age, pregnancy, and diabetes often render the patient less tolerant of tropical infections.
DoTwABnLloEa 1d6e2­d2 2025­7­1 6:20 P Your IP is 136.142.159.127
Chapter 162: Global Travelers, Shawn M. D’Andrea; Annelies De Wulf 
Typical Incubation Periods for Selected Tropical Infections
. Terms of Use * Privacy Policy * Notice * Accessibility
Incubation Period Infections Likely
<10 d (short incubation) Traveler’s diarrhea
Dengue fever and arboviral infections
Chikungunya
Yellow fever
Anthrax
Diphtheria
Malaria
Typhoid fever
Meningococcal infections
Plague
Tularemia
Typhus (louse­ and flea­borne)
<21 d (intermediate incubation) Leptospirosis
Viral hemorrhagic fevers
Malaria
Enteric fevers (typhoid, paratyphoid)
Typhus
African trypanosomiasis
Rabies
Zika
>21 d Viral hepatitis (A, B, C, D, E)
Malaria
Acute HIV infection
Amebic liver abscess
Schistosomiasis (Katayama fever)
Visceral leishmaniasis
Filariasis
>Months Tuberculosis
Malaria
Filariasis
Viral hepatitis B, C
HIV
Visceral leishmaniasis
Rabies
Syphilis
African and American (Chagas’ disease) trypanosomiasis
Abbreviation: HIV = human immunodeficiency virus.
TABLE 162­3
Travel­Specific Aspects of the Medical History
Pretravel information
Previous medical condition
Pediatric patient, diabetes, pregnancy, immunosuppression (especially human immunodeficiency virus [HIV]/acquired immunodeficiency syndrome or steroid use)
Pretravel consultation and preparation (self­treatment medications, vaccination history, prophylaxis, etc.)
Type and compliance with chemoprophylaxis, particularly malaria
History of routine childhood immunization (DPT, polio, MMR, HiB, etc.)
Nation of birth and citizenship
Travel information
Exact itinerary of departure and arrival (within the last 3–5 y may be relevant)
Season of travel (monsoon, dry season)
Destinations visited (including locations of transit or stopovers)
Urban or rural, altitude
Purpose of travel and activities in country
General purpose of visit or travel (e.g., “adventure travel” with high exposure to remote, natural elements)
Contacts and their health
Habitat and location of lodging (bed nets, window screens, thatched roof, mud walls)
Crowded living or sleeping conditions
High­risk activities (e.g., medical care of displaced populations, spelunking in caves)
Opioid use or injection drug use
Sexual intercourse with high­risk sexual contacts (unprotected with anyone; with high­risk populations, e.g., commercial sex workers, in areas with high prevalence of HIV); dates and nature of sexual contact
Exposure to environment (swimming in freshwater or saltwater, hiking, trekking, digging, or soil contact, e.g., open­toed shoes or bare feet)
Consumption of high­risk foods (wild game or bush meat, raw or undercooked meats or fish, unpasteurized milk products, food from street vendors, natural sources of water, salads)
Exposure to dogs, birds, or rodents
Adverse incidents
Insect or animal bites
Saliva from animals to open wounds
Assault or trauma
Status and health of fellow travelers
Possible ill contacts
In­country medical consultations sought, remedies used, and procedures (injections, acupuncture, transfusions, dental procedures, body piercing, or tattooing)
Abbreviations: DPT = diphtheria, pertussis, and tetanus; HiB = Haemophilus influenzae type b; MMR = measles, mumps, and rubella.
TABLE 162­4
Regional Tropical Illnesses
Africa: malaria, human immunodeficiency virus, TB, hookworm, tapeworm, roundworm, brucellosis, yellow fever (and other hemorrhagic fevers such as Lassa fever or Ebola), relapsing fever, schistosomiasis, tick typhus, filariasis, strongyloidiasis, Zika, chikungunya
Central and South America: malaria, relapsing fever, dengue fever, filariasis, TB, schistosomiasis, Chagas’ disease, typhus, Zika, chikungunya
Mexico and the Caribbean: dengue fever, hookworm, malaria, cysticercosis, amebiasis, Zika
Australia, New Zealand: dengue fever, Q fever, Murray Valley encephalitis, Japanese encephalitis
Middle East: hookworm, malaria, anthrax, brucellosis, middle eastern respiratory virus
Europe: giardiasis, Lyme disease, tick­borne encephalitis, babesiosis, chikungunya (southern Europe)
China and East Asia: dengue fever, hookworm, malaria, strongyloidiasis, hemorrhagic fever, Japanese encephalitis, Zika, chikungunya
Abbreviation: TB = tuberculosis.
Ask about the duration of travel and timing of return (Table 162­2). For example, if fever begins >21 days after return from travel, yellow fever, viral hemorrhagic fevers (including Ebola, covered elsewhere), and other arboviruses (e.g., dengue fever) are unlikely, irrespective of the exposure history
(Table 162­2). In comparison, schistosomiasis may cause symptoms  to  weeks after exposure. Incubation periods may vary somewhat depending on host factors such as immune status and the use of chemoprophylaxis.
Other important considerations are the specific locales of the traveler, as rural versus urban areas have different infectious disease risks, types of accommodation (e.g., tents or beds without bed nets), and travel­related activities (e.g., exposure to jungles, farm animals), and high­risk behaviors
(e.g., eating jungle meat, drinking untreated water) (Table 162­5).
TABLE 162­5
Specific Exposures and Associated Tropical Infections
Contact/Exposure Possible Infections
Untreated water, unpasteurized dairy Salmonellosis, shigellosis, hepatitis, amebiasis, brucellosis, listeriosis, TB products
Raw or undercooked shellfish Clonorchiasis, paragonimiasis, Vibrio, hepatitis A
Raw or undercooked animal flesh Trichinosis (e.g., pig, horse, bear), Salmonella, enterohemorrhagic Escherichia coli
Raw vegetables, water plants (e.g., Fascioliasis watercress)
Animal contact (and animal products) Rabies, Q fever, tularemia, brucellosis, echinococcosis, anthrax, plague, Nipah virus, toxoplasmosis, herpes B encephalitis
Rodent contact Hantavirus, viral hemorrhagic fevers, murine (endemic) typhus, Lassa fever, plague, leptospirosis
Arthropod vectors
Mosquitoes Malaria, dengue fever, chikungunya, filariasis, yellow fever, Zika, and other arboviral infections
Ticks or mites Rickettsioses, tularemia, scrub typhus, Crimean­Congo hemorrhagic fever, African tick bite fever
Reduviid (kissing) bugs American trypanosomiasis (Chagas’ disease)
Tsetse flies African trypanosomiasis (African sleeping sickness)
Fleas Typhus, plague
Sandflies Leishmaniasis, sandfly fever
Freshwater exposure Schistosomiasis, leptospirosis
Barefoot exposure Strongyloidiasis, cutaneous larva migrans, hookworm
Sexual contacts Human immunodeficiency virus, hepatitis B, syphilis, gonorrhea, chlamydia, herpes simplex, Zika
Infected persons contact Viral hemorrhagic fever, enteric fever, meningococcal infection, TB
Abbreviation: TB = tuberculosis.
Review any pretravel immunizations and preventive medications. Proper vaccination against hepatitis A, hepatitis B, and yellow fever can effectively rule these out as causes of illness. Although chemoprophylaxis reduces the risk of acquiring malaria, it does not eliminate the possibility. Because of increasing malaria resistance and variable adherence to chemoprophylaxis regimens, consider malaria in the febrile returning traveler even with reported chemoprophylaxis.
A history of medications, herbs, and traditional medicines is also useful. These may contain antipyretics and other components that can alter disease presentation.
If altered mental status and the appropriate travel history exist, suspect cerebral malaria or meningitis and provide prompt empiric treatment. In the context of fever and hemorrhagic symptoms with travel to affected areas, initiate infection control practices until Ebola and other hemorrhagic viruses are excluded. In the case of suspected bioterrorism, initiate infection control and decontamination immediately. It is important to identify diseases that may be rapidly fatal, easily treatable, and/or potentially contagious. Do not await confirmatory testing to initiate decontamination, isolation, and treatment.
PHYSICAL EXAMINATION AND DIAGNOSTIC TESTING
Evaluate the abdomen for hepatosplenomegaly or focal abdominal discomfort. Examine for lymphadenopathy and inspect the skin for rashes, lesions, or pallor. Ophthalmologic examination should look for scleral icterus, conjunctival injection, and petechiae. Remain alert for subtle neurologic signs and altered mental status.
Suspect an imported disease in the presence of high fever, signs of hemorrhage, diarrhea, shortness of breath, skin lesions, and neurologic
 disturbances. Table 162­6 lists other signs of tropical illness.
TABLE 162­6
Physical Findings in Selected Tropical Infections
Physical Finding Likely Infection or Disease
Rash Dengue fever, typhus, syphilis, gonorrhea, Ebola fever, brucellosis, chikungunya, HIV seroconversion
Jaundice Hepatitis, malaria, yellow fever, leptospirosis, relapsing fever
Lymphadenopathy Rickettsial infections, brucellosis, HIV, Lassa fever, leishmaniasis, Epstein­Barr virus, cytomegalovirus, toxoplasmosis, trypanosomiasis
Hepatomegaly Amebiasis, malaria, typhoid, hepatitis, leptospirosis
Splenomegaly Malaria, relapsing fever, trypanosomiasis, typhoid, brucellosis, kala­azar, typhus, dengue fever, schistosomiasis
Eschar Typhus, borreliosis, Crimean­Congo hemorrhagic fever, anthrax
Hemorrhage Lassa, Marburg, or Ebola viruses; Crimean­Congo hemorrhagic fever; meningococcemia, epidemic louse­borne typhus
Abbreviation: HIV = human immunodeficiency virus.
Usually one or more hallmark symptoms or signs are associated with specific infections, guiding diagnostic testing and categorization. These include fever, CNS complaints, abdominal pain, diarrhea, skin and eye complaints, and respiratory symptoms. Initial studies include a CBC with differential, hepatic function tests, and urinalysis; thick and thin blood smears for malaria with rapid antigen detection test if available; blood cultures, urine cultures, stool cultures, and stool analysis for WBCs, ova, and parasites; and chest radiograph.
In a clinically well­appearing patient in whom malaria treatment is suspected, obtain blood for smear every  to  hours. Use other specific serologic tests selectively, such as erythrocyte sedimentation rate, purified protein derivative, syphilis testing, human immunodeficiency virus testing, and serology for arboviruses or rickettsiae.
Infectious disease consultation early in the evaluation can optimize testing and follow­up. Obtain an extra vial of serum in a red­top tube (for serology and immunology) during the initial evaluation for follow­up testing.
DISEASES COMMONLY ASSOCIATED WITH FEVER
Although fever is nonspecific, it raises the suspicion for a serious infection and is present in up to about 90% of serious travel­related illnesses (Table
,5­7
162­7). Treat patients with fever after tropical travel as if they have malaria until proven otherwise. Other common serious infections
,9 are listed in Table 162­8. TABLE 162­7
Tropical Infectious Diseases Causing Fever Among International Travelers
INCUBATION <2 WEEKS
Disease Distribution Mode of Transmission
Undifferentiated fever
Malaria, Zika Most tropical and subtropical areas Infected mosquito bite
Dengue Tropics and subtropics, including urban areas Infected mosquito bite
Chikungunya Africa, Asia, Latin America, US, southern Europe, Infected mosquito bite and Caribbean
Spotted fever Worldwide Infected tick or mite bite
Scrub typhus Asia, Australia Infected mite bite
Leptospirosis Widespread, mostly tropics Percutaneous contact with animal urine or contaminated soil and water; ingestion
Typhoid fever Developing countries, especially Indian Contaminated food/water ingestion subcontinent
Acute HIV infection Worldwide Permucosal or percutaneous exposure to infective blood or fluids
African trypanosomiasis East African form found in East and South Africa. Infective tsetse fly bite
West African form found in central and West Africa
Shigellosis Widespread, most common in developing Contaminated food/water ingestion countries
Salmonellosis Widespread, most common in developing Contaminated food/water ingestion countries
Campylobacteriosis Widespread, most common in developing Contaminated food/water ingestion countries
Fever with hemorrhage
Meningococcemia Widespread, highly prevalent in sub­Saharan Via respiratory and oral secretions meningitis belt in dry season from December to
June
Leptospirosis Widespread, most common in tropical climate Freshwater exposure
Crimean­Congo hemorrhagic fever East and West Africa, Eurasia Infected tick bite
Viral hemorrhagic fever Worldwide Contact with an infected patient, rodent, bat, tick, or mosquito
Other bacterial infection
Fever with CNS involvement
Meningococcemia See listing above See listing above
Rabies Common in Africa, Asia, and Latin America Infected animal saliva exposure
Malaria See listing above See listing above
Many viral and bacterial forms
Arboviral encephalitis (Japanese encephalitis, tick­ Worldwide Infected mosquito or tick bite borne encephalitis, dengue, West Nile, Murray Valley)
Angiostrongyliasis Widely scattered, most common in East Asia and Ingestion of contaminated food/water
Southeast Asia with snail or slug slime
Poliomyelitis Primarily Africa and parts of Asia Ingestion of feces­contaminated food/water
Fever with respiratory findings
Influenza Widespread; outbreaks on cruise ships Direct or airborne droplet transmission
Severe acute respiratory syndrome China, Hong Kong, other regions in East Asia Direct or airborne droplet transmission
Legionellosis (legionnaires’ disease) Widespread; outbreaks in hotels and cruise ships Inhalation or aspiration of infected droplets
Q fever Worldwide Inhalation of infective aerosol from animal source
INCUBATION 2–6 WEEKS
Malaria See listing above See listing above
Typhoid fever See listing above See listing above
Hepatitis A and E Widespread; most common in developing Contaminated food/water ingestion countries
Acute schistosomiasis Africa, Middle East, Southeast Asia, and Brazil Penetration of skin by larval cercaria during freshwater exposure
Amebic liver disease Widespread; developing countries Ingestion of cysts usually in fecescontaminated food/water
Leptospirosis See listing above See listing above
African trypanosomiasis See listing above See listing above
Q fever See listing above See listing above
Acute HIV infection Worldwide, increased risk in developing countries Sexual exposure
INCUBATION >6 WEEKS
Malaria See listing above See listing above
Tuberculosis Worldwide Inhalation
Hepatitis B Widespread Permucosal or percutaneous exposure to infective blood or fluids
Visceral leishmaniasis Many parts of Africa, Asia, South America, and Infective sand fly bite
Mediterranean basin
Lymphatic filariasis Widespread in tropical areas Infected mosquito bite
Schistosomiasis See listing above See listing above
Amebic liver abscess See listing above See listing above
Rabies Worldwide Infected animal saliva exposure
African trypanosomiasis See listing above See listing above
Abbreviation: HIV = human immunodeficiency virus.
TABLE 162­8
Most Common Causes of Fever After Travel to Tropical Regions
Malaria
Respiratory tract infections (upper respiratory tract infections, pneumonia, legionnaires’ disease, and influenza)
Diarrheal disease
Urinary tract infection
Dengue fever
Enteric fever (typhoid, paratyphoid fever)
Rickettsial infection
Infectious mononucleosis
Pharyngitis
MALARIA
,11
The classic clinical triad for all species of malaria is fever, splenomegaly, and thrombocytopenia. Fever is typically irregular for the first week and later may be periodic. Patients usually have continuous symptoms initially followed by episodic pyrexia every  to  days, depending on the infecting species. Periodicity is unusual with falciparum malaria. Serious malaria infections occur primarily in young children, pregnant women, the elderly, individuals who are immunologically naive or who have lost their acquired immunity through prolonged absence from an endemic country, and patients with comorbid medical problems. Because associated symptoms such as headache, cough, and GI problems mimic other conditions, malaria should be a consideration in all febrile travelers. If a patient has the appropriate travel history and altered mental status, suspect cerebral malaria and initiate treatment promptly.
Diagnosis is based on clinical presentation then confirmed with laboratory evidence of bloodborne protozoa. Patients with fever >38.5°C (101.4°F) of unclear origin and recent or past travel to an endemic area should be screened by blood smears and rapid antigen detection tests when available.
Refer to Chapter 159, “Malaria,” for a detailed discussion of malaria diagnosis and treatment.
DENGUE FEVER
The World Health Organization reports a 30­fold increase in incidence of dengue in the past  years, becoming a leading cause of morbidity and
 mortality in the tropics. Suspect dengue fever among travelers with fever developing within  weeks of travel. Dengue may be contracted more than
 once, and subsequent infections may be progressively more severe.
Dengue is transmitted by the day­biting Aedes aegypti mosquito. Dengue fever presents after a typically short incubation period of  to  days with sudden high fever, headache, nausea, vomiting, severe myalgias (hence the term “break bone fever”), and rash usually lasting several days. Facial flushing, conjunctival injection (although uncommon), and retro­orbital pain can occur. After defervescence, a fine, pale, morbilliform rash develops on the trunk and spreads to the extremities and face. Small children may only present with a mild upper respiratory infection. Dengue may be confused with influenza, measles, or rubella. West Nile fever can also present similarly, but also causes lymphadenopathy, which is usually absent in dengue.
Dengue can cause petechial hemorrhages indistinguishable from meningococcemia.
Severe dengue, previously known as dengue hemorrhagic fever, preferentially occurs among infants of immune mothers, children >1 year old, and those with second and subsequent infections. It begins with fever and myalgias. After  to  days, as pyrexia improves, lassitude, fatigue, and shock develop with an ensuing mortality that is >10%. Clinical features include pleural effusions and bleeding diathesis with epistaxis, purpura, petechia, and marked thrombocytopenia with elevated hematocrit because of vascular permeability. Severe dengue may rapidly evolve and is often fatal. Severe dengue exhibits abdominal pain, severe emesis, mental status changes, and alternating severe pyrexia and hypothermia.
Diagnosis of dengue is based on clinical findings. Although serology is confirmatory, cross­reactivity often occurs with other flaviviruses. Enzymelinked immunosorbent assay provides rapid confirmation of infection by day  of the illness. Laboratory abnormalities include leukopenia, thrombocytopenia, and hepatic dysfunction. In uncomplicated dengue fever, treatment is supportive and consists of fluids and analgesics. Only acetaminophen is recommended for managing pain and fever because aspirin and other NSAIDs are contraindicated due to anticoagulant properties.
TYPHOID FEVER
Enteric fever, or typhoid fever, is a serious infection diagnosed in roughly 400 travelers annually returning to the United States, with an additional 100
 cases of paratyphoid. Typhoid and paratyphoid are caused by Salmonella typhi and Salmonella paratyphi, respectively. Once malaria is excluded,
 typhoid fever is commonly the cause of a febrile illness lasting >10 days. Typhoid fever is endemic in countries with poor sanitation and
 unsafe drinking water in Africa, the Americas, Southeast Asia, and the Western Pacific regions. Vaccination before travel helps prevent illness, although protection wanes with time and revaccination is required.
The disease is transmitted in a dose­related fashion after food contamination by feces or urine from actively infected cases or healthy disease carriers.
Incubation times and disease severity vary from  to  weeks. Most pathology occurs in the gut because of inflammation, necrosis, and ulceration.
Typhoid fever classically begins with fever and headache and then progresses to high fever with chills, headache, cough, abdominal distention, myalgias, constipation, and prostration. In epidemics, patients can present with acute diarrhea and vomiting, headache, and meningeal signs.

However, 30% of patients present with constipation rather than diarrhea. Bradycardia relative to fever is classic (but may be absent); after several days of fever, a pale red macular rash may appear on the trunk (rose spots) among fair­skinned individuals. As the disease progresses, splenomegaly develops. Patients may develop leukopenia and elevated liver enzymes, although most cases have nonspecific laboratory values.
Complications include small bowel perforation, anemia, disseminated intravascular coagulopathy, mycotic aneurism, pneumonia, meningitis, septic arthritis, myocarditis, cholecystitis, and renal failure. Sequelae include deafness, and other neurologic involvement including psychosis, ataxia, and
 seizures can occur.
Diagnosis is clinical, confirmed by culturing blood, urine, or stool (during the second week) or by rapid antigen testing. Although most cultures have a moderate yield, bone marrow culture is most sensitive, and organism identification is possible after antibiotic treatment.
Current treatment recommendations for typhoid fever include fluoroquinolones (ciprofloxacin), cephalosporins (cefixime and ceftriaxone), or azithromycin, with duration of treatment dependent on severity of illness. Currently, fluoroquinolone resistance is increasing, especially in travelers
 returning from South and Southeast Asia, associated with nalidixic acid–resistant S. typhi strains. Ampicillin, trimethoprim­sulfamethoxazole, and chloramphenicol are unreliable due to resistance. If the patient is severely ill with suspected typhoid meningitis/encephalitis or shock, administer
 dexamethasone in addition to antibiotics. Supportive treatment includes IV rehydration and blood transfusion (if needed from GI losses). Relapses
 can occur after clinical improvement. Untreated, mortality is 10% to 20%, mostly in young children.
RICKETTSIAL SPOTTED FEVERS
Rickettsial spotted fevers are transmitted by the bite, body fluid, or feces of ixodid arthropod ticks, which are widely distributed globally. Fleas and mites can also transmit rickettsial infections. Among the eight major rickettsial infections, there is variation in severity. Mortality without treatment approaches 25%, which drops to 5% with treatment (see Chapter 161, “Zoonotic Infections”).
Scrub Typhus and African Tick Typhus
Suspect scrub typhus (Rickettsia orientalis) after rural travel in the Asia­Pacific region and maritime Russia and African tick typhus (Rickettsia conorii var. pijperi) after travel to sub­Saharan Africa or the West Indies. The mite bite, in the case of scrub typhus, or tick bite, with African tick typhus, may go unnoticed. After  to  days of incubation, patients develop fever, malaise, myalgias, severe headache, rash, nausea, and vomiting. The rash may be absent. Scrub typhus is characterized by a papule at the bite site. The papule later becomes necrotic and forms a crusted black “tache noire” eschar. As organisms disseminate, patients develop fever, malaise, headache, lymphadenopathy, and splenomegaly. African tick typhus presents like scrub typhus, but with less severe symptoms and localized lymphadenopathy associated with an eschar. Diagnosis is clinical, and serologic tests are
 confirmatory. Doxycycline is the empirical treatment of choice; azithromycin and chloramphenicol are alternatives. African tick typhus requires only  days of therapy and is often self­limited even without treatment. In severe cases of scrub typhus, death occurs from a multiorgan toxemia within  to  weeks of illness onset if untreated. Continue treatment for at least  days and for  hours after defervescence.
Typhus (Epidemic Louse­Borne Typhus)
Typhus is a rickettsial louse­borne disease caused by Rickettsia prowazekii. Typhus is a different disease from typhoid fever, the bacterial disease due to S. typhi (see earlier). Epidemic louse­borne typhus is transmitted by the arthropod body louse. Typhus is widespread and found in Central Africa,
Asia, and Central, North, and South America. It is also common in rainy seasons and in cold regions affected by famine, war, or mass population movement, where clothing and blankets harbor the lice. Louse­borne disease occurs after louse body fluids and feces are rubbed into abrasions or after bites. Infection results in high fevers after an 8­ to 12­day incubation period. Severe headache is common, and a maculopapular rash appears between days  and , generally sparing palms and soles. The rash may be hemorrhagic. Diagnosis starts on clinical grounds and is confirmed with
 serologic testing. Treatment is doxycycline or chloramphenicol until  hours after defervescence. Treatment also includes delousing the patient’s
 clothing. Mortality in severe cases is as high as 24%.
LEPTOSPIROSIS (WEIL’S DISEASE)
Leptospirosis, or Weil’s disease, follows mucous membrane or percutaneous exposure to freshwater contaminated by Leptospira interrogans.
Infected animals include many wild and domesticated animals, especially rodents, which excrete the spirochete in their urine. Infected patients typically have had contact with dogs; swam, rafted, or waded in contaminated surface water; or farmed or gardened in contaminated areas. Outbreaks
 commonly occur after flooding. Although the risk to most routine travelers is low, recent ecotourists and adventure travelers have become infected
 after intense water exposure.
The clinical course can be asymptomatic, but often symptoms illustrate a biphasic pattern. After an incubation of  days to  weeks, symptoms may include high fever, severe headache, chills, myalgias, hepatitis (with or without jaundice), and nonspecific influenza­like complaints. Notable is conjunctival injection without purulent discharge. Symptoms resolve in  to  days, followed several days later by the severe, icteric Weil’s disease caused by circulating antibodies. The second phase lasts for up to  weeks and can include aseptic meningitis, renal failure, uveitis, rash, and, rarely, circulatory collapse. Isolation of leptospires from blood, urine, or cerebrospinal fluid is diagnostic, although sensitivity varies with duration of symptoms. Serology is most often used to confirm the diagnosis. Treatment reduces the severity and duration of symptoms and may prevent the second disease phase. Mild disease can be treated within the first  days of illness with PO amoxicillin or doxycycline, whereas more severe cases require IV penicillin, ceftriaxone, or ampicillin. Treatment duration is  to  days. Consider empiric therapy with PO doxycycline or IV penicillin (or ampicillin) when suspecting leptospirosis.
ZIKA VIRUS
Transmitted by the Aedes mosquito, Zika virus (a member of the Flaviviridae family) is transmitted in a wide range of tropical areas in the world. In addition to mosquitos, Zika may be transmitted through sexual intercourse, from mother to fetus in utero and mother to child through breastfeeding, and through blood transfusion. Symptoms may include conjunctivitis, headache, joint pain, fever, and malaise. Although Zika does not commonly pose a serious threat to those infected, it has been associated with Guillain­Barré syndrome. Zika infection of a pregnant woman can cause multiple serious birth defects including severe microcephaly. Offer testing to any pregnant women traveling from Zika­affected regions exhibiting signs of Zika; counsel men and women with suspected Zika infection or exposure of the risk of sexual transmission. The Centers for Disease Control and Prevention currently recommends that men returning from places at risk of Zika virus wait  months before having unprotected sex and that women wait 
 months, even if they have not been symptomatic. Treatment is supportive.
CHIKUNGUNYA FEVER
A self­limited arboviral infection with epidemic potential also spread through the Aedes mosquito species, chikungunya has become a significant
 cause of illness, especially in the Caribbean and South America. The incubation period is  to  days (usually  to  days), and it presents with fever, severe myalgias, fatigue, headache, morbilliform rash, and occasional thrombocytopenia. Hemorrhagic complications are rare. Diagnosis is through increases of immunoglobulin M antibodies either in serum or the cerebrospinal fluid. Treatment is supportive, and long­term arthralgia sequelae are
 not uncommon.
RELAPSING FEVER
Relapsing fever is a bacterial infection caused by the spiral­shaped Borrelia species (Borrelia species not including Borrelia burgdorferi, the causative organism of Lyme disease) transmitted by lice or tick bites. It is rare among travelers yet should be suspected in those who have contact with refugee and displaced populations. After being introduced by a louse or tick bite, Borrelia reproduces in body fluids and produces endotoxins affecting the liver, spleen, and capillaries. After incubation of  to  days, patients develop fever, chills, headache, and myalgias. In rare severe cases, acute respiratory distress syndrome, CNS involvement, and liver failure occur. After spontaneous abatement, fever may relapse several times. Diagnosis is made by clinical suspicion and confirmed by identifying spirochetes in blood peripheral smear, cerebrospinal fluid, or bone marrow. Spirochetes are best seen when blood is sampled during a febrile period. Louse­borne and tick­borne relapsing fever is treated with tetracycline, doxycycline, or
 erythromycin. Ceftriaxone can also be given with CNS involvement.
DISEASES COMMONLY ASSOCIATED WITH FEVER AND HEMORRHAGE
Among the most feared tropical diseases are viral hemorrhagic fevers. However, viral hemorrhagic fevers are rare when compared with other febrile hemorrhagic infections such as malaria, dengue fever, meningococcemia, leptospirosis, plague, bacterial sepsis, and rickettsial fevers. Neisseria meningitidis is the most common cause of acute hemorrhagic fever in temperate climates. Among travelers, several treatable infections, including Lassa fever, meningococcemia, leptospirosis, and rickettsial infection, can cause fever associated with hemorrhage. Most people with viral hemorrhagic fevers, such as dengue, hantavirus (Chapter 161), Lassa, Ebola, Marburg, and Rift Valley, develop fever within  weeks after exposure. Viral hemorrhagic fever usually follows the bite of infected mosquitoes and ticks, close contact with rodent/bat excreta, or direct contact with infected, symptomatic individuals (the latter notably for Ebola).
In the event of a suspected viral hemorrhagic fever of tropical origin, institute control measures, including isolation in a negativepressure room, the use of high­efficiency particulate­arresting respirators, and the use of gloves and gowns. Immediately notify local public health officials for suspected contagious viral hemorrhagic fevers such as Marburg, Lassa, Ebola, or Crimean­Congo hemorrhagic fever. If intentional bioterrorism is suspected, notify local law enforcement officials, the Federal Bureau of Investigation, and the Centers for Disease
Control and Prevention.
YELLOW FEVER
Yellow fever, an acute zoonotic flavivirus, has a jungle monkey reservoir present in the tropics of South America and Africa, where vaccination is mandatory. Outbreaks are common near tourist areas and may occur among nonimmunized adventure travelers who travel to endemic areas. With the increase in global travel and because the day­biting mosquito vector A. aegypti (which also transmits dengue) is endemic in a wide global distribution, including North and Central America, the Caribbean, as well as parts of Asia, yellow fever outbreaks can appear outside of traditionally endemic areas,
,32 as evidenced by a recent outbreak in Brazil.
Yellow fever ranges in severity from an undifferentiated self­limited flulike illness to a hemorrhagic fever that is fatal in 20% to 50% of patients who
,33 develop severe disease (15% of infected persons). After an incubation of  to  days, patients develop fever, headache, myalgias, conjunctival injection, abdominal pain, prostration, facial flushing, and relative bradycardia. In most cases, patients recover, but in others, fever remission lasts a few hours to several days, followed by renewed high fever, jaundice, vomiting, shock, multiorgan failure, and bleeding diathesis. The classic presentation is a triad of jaundice, black emesis, and albuminuria. Confusion, seizures, and coma are common in the late stages of the illness, and death can occur within  to  days after onset. The diagnosis is primarily clinical, although confirmation is possible through virus identification or rising antibody titers in recovering patients. Leukopenia and albuminuria are typical, direct bilirubin levels rise, and liver enzymes are elevated for several days, during which time azotemia and oliguria ensue. Treatment is supportive, with fluid replacement and management of hematologic complications.
EBOLA AND MARBURG VIRUSES
Periodic outbreaks of Ebola virus disease have existed since 1976. Transmission is thought to occur via human contact with infected animals, either
 ,36 primates or fruit bats. The most recent large outbreak in multiple West African countries had >11,000 associated deaths by 2016. Four Ebola species cause disease in humans. Disease transmission is by direct contact with infected blood or body fluids, contaminated needles or syringes, or infected bats or primates. The virus is stable, with little mutation in current species compared to that in the epidemic of 1976. Symptoms begin  to  days after exposure with fever, myalgia, malaise, diarrhea, abdominal pain, and vomiting, and progress to hemorrhage, shock, and end­organ failure. Mortality is high, but those who recover have an antibody response that lasts about  years. Diagnosis is by enzyme­linked immunosorbent assay serology, polymerase chain reaction, culture, or immunochemistry and, in the United States, is performed at the U.S. Centers for Disease Control and Prevention after consultation and acceptance of specimens (770­488­7100). Treatment is supportive with no proven effective antiviral therapy; however, investigational therapies including convalescent serum and antibody treatments have been used. Vaccines remain under development, although at the time of this writing (November 2018), an investigational vaccine is being deployed in the Democratic Republic of Congo, which is combating an ongoing outbreak. Epidemic containment focuses on avoidance of exposure and, for healthcare workers, the use of personal protective equipment. Hospital preparedness consists of the identification of potential exposed contacts by identifying travel and direct exposure
 history, determining disease signs and symptoms, and then isolating individuals with possible disease.

Similar to Ebola, episodic outbreaks of Marburg virus infection exist in sub­Saharan Africa, and the virus has been found in African fruit bats. Clinical
 presentation is similar to Ebola.
CRIMEAN­CONGO HEMORRHAGIC FEVER

This tick­borne viral disease is common in Africa, Eastern Europe, Asia, and the Middle East, especially in Turkey. Mortality ranges from 3% to 30%.
The prehemorrhagic period is characterized by the sudden onset of fever, headache, myalgia, dizziness, and, possibly, altered mental status. The hemorrhagic period is short (2 to  days), develops rapidly, and usually begins between the third and fifth day of disease. The most common bleeding sites are the nose, GI system (hematemesis, melena, and intra­abdominal), uterus (menometrorrhagia) and urinary tract (hematuria), and the respiratory tract (hemoptysis). Thrombocytopenia is common. Patients may have leukopenia and elevated liver enzymes, lactate dehydrogenase, and creatinine. Prothrombin time and activated PTT can be prolonged.
Diagnosis is clinical and confirmed with serology. Treatment is primarily supportive, including treatment of coagulopathy and respiratory support in
 severe cases. Oral or IV forms of ribavirin are available and used in more severe cases; treat for  days.
LASSA FEVER
Lassa fever is spread by contact with bush rat excreta or body fluid exposure from an infected person. Although found in rural parts of West Africa, it has been exported to Europe and North America by infected patients, and in endemic areas, impact is high, with up to 16% of admitted patients in
 hospitals having Lassa fever.
After an incubation period of  to  days, the disease presents as a viral syndrome with insidious onset of fever, malaise, headache, sore throat, retrosternal chest pain, back pain, abdominal pain, and myalgias. Varied and nonspecific symptoms persist for  to  days, at which time the patient suddenly deteriorates and becomes gravely ill. Among those infected, approximately 80% have mild symptoms and 20% will have severe multiorgan disease. Pregnant women and their fetuses are at elevated risk of severe disease and death. The main features are high fever, prostration, severe sore throat with dysphagia and yellow­white exudates, abdominal pain, diarrhea, and vomiting. Only one third of patients experience bleeding, which may include oozing from the gums, hematemesis, melena, hematochezia, hemoptysis, hematuria, or brain hemorrhage. Diagnosis is made by enzymelinked immunosorbent assay serology, culture, or immunohistochemistry. Strict patient isolation and use of personal protection by healthcare workers are necessary. Treatment is largely supportive, but patients with severe disease may benefit from early treatment with ribavirin IV or PO.

Survivors will defervesce within  days of disease onset and, except for sensorineural deafness, can make a complete recovery.
DISEASES COMMONLY ASSOCIATED WITH FEVER AND CNS INVOLVEMENT
Fever with acute mental status changes, headache (Table 162­9), nuchal rigidity, and focal neurologic signs is associated with a number of serious infections. CNS involvement with fever in travelers returning from malaria­endemic regions requires emergency presumptive treatment for both malaria and bacterial meningitis (see Chapters 159 and 174, “Malaria” and “Central Nervous System and Spinal
Infections,” respectively). The differential diagnosis for fever with CNS involvement includes malaria, meningitis, tuberculosis, typhoid fever, rickettsial infections, and rabies. Other causes are viral encephalitides, including Japanese and West Nile encephalitis, which often present similarly.
TABLE 162­9
Tropical Infectious Diseases Causing Severe Headache and Fever
Malaria
Rickettsial disease
Dengue fever
Typhoid fever
Human African trypanosomiasis
Patients with altered mental status suspected of tropical illness may demonstrate coma, decreased level of consciousness, meningeal signs, or seizures. Although seizures should arouse suspicion of cerebral malaria, suspect cysticercosis in those with long­term residence in Latin America and a first­time seizure. Meningococcal meningitis (caused by Neisseria meningitidis) occurs with regularity in sub­Saharan Africa along the
“meningitis belt” running from Senegal to Ethiopia, and pilgrims attending the Hajj in Saudi Arabia are also at risk of Neisseria meningitis (Chapter
174). Aseptic meningitis may be caused by enteroviruses or, less commonly, typhoid fever, leptospirosis, or rickettsiae. Encephalitis may be caused by an arboviral infection, such as Japanese encephalitis.
JAPANESE ENCEPHALITIS
Japanese encephalitis is a vaccine­preventable flavivirus infection that occurs in an epidemic or sporadic pattern over large areas of Asia and the western Pacific. It is rarely transmitted to U.S.­bound travelers because the Culex mosquito vector breeds primarily in rural rice fields. Approximately
25% of infected patients will have severe symptoms, presenting with a sudden high fever, headache, nuchal rigidity, vomiting, and seizures (especially infants) after the incubation time of  to  days. A variety of pyramidal and extrapyramidal signs may develop soon after fever. If the outcome is fatal, it usually occurs in the first  days. Diagnosis is based on clinical suspicion, although virus can be isolated from cerebrospinal fluid, and antibody titers can rise. Treatment is supportive. Recovery may take months, and varying degrees of residual neurologic damage may persist indefinitely.

Immunization is recommended for travelers to rural, endemic regions in Asia.
CYSTICERCOSIS
Cysticercosis is a systemic illness caused by dissemination of the larval form of the pork tapeworm, Taenia solium. The disease affects an estimated  million people worldwide. Endemic areas include Mexico, Latin America, sub­Saharan Africa, India, and East Asia. The incidence in the United States is increasing due to increased immigration from endemic areas and increased travel to endemic areas. Humans are definitive T. solium hosts and can carry the intestinal adult tapeworm. An intermediate host, usually a pig, ingests fecally shed egg­containing proglottids or T. solium eggs. Humans develop cysticercosis when they inadvertently ingest eggs from contaminated food or soil, not from eating undercooked pork, which can result in
 tapeworm infection only.
Infestation can occur in almost any tissue. Involvement of the CNS, neurocysticercosis, is the most clinically important manifestation of the disease.

Neurocysticercosis is the most common cause of CNS infection globally and the leading cause of adult­onset seizures worldwide. Other symptoms of neurocysticercosis include obstructive hydrocephalus, meningoencephalitis, stroke­like focal deficits, headache, and visual or mental status changes.
Noncontrast CT scan shows calcifications of inactive disease and can reveal mass effect or hydrocephalus. Antihelminthic agents (albendazole or praziquantel) are the mainstay of treatment. Use steroids in those with encephalitis, hydrocephalus, or vasculitis to avoid inflammation as cysts
 involute. In nonendemic areas, check stool studies of household contacts of confirmed cases.
DISEASES COMMONLY ASSOCIATED WITH CHRONIC FEVER
Evaluate patients with chronic or relapsing fever lasting beyond  weeks after travel initially for non–travel­related infections, inflammatory diseases, and noninfectious disorders. Tropical illnesses that cause chronic fever include protozoal infections (e.g., trypanosomiasis, leishmaniasis, amebiasis, and malaria), typhoid or paratyphoid fever, and tuberculosis (Table 162­10).
TABLE 162­10
Selected Causes of Chronic and Relapsing Fevers
Etiologic Organism Organism Species
Bacterial Bartonellosis
Brucellosis
Leptospirosis
Q fever
Relapsing fever
Syphilis
Tuberculosis
Tularemia
Typhoid fever
Fungal Blastomycosis
Coccidioidomycosis
Cryptococcosis
Histoplasmosis
Protozoan Amebic liver disease
Visceral leishmaniasis
Malaria
Human African and human American trypanosomiasis
Viral Human immunodeficiency virus
Helminthic Angiostrongyliasis
Fascioliasis
Schistosomiasis
Toxocariasis
Trichinosis
HUMAN AFRICAN TRYPANOSOMIASIS (AFRICAN SLEEPING SICKNESS)
Sleeping sickness is caused by the two nearly identical endemic protozoan subspecies, Trypanosoma brucei gambiense (responsible for most clinical cases) and Trypanosoma brucei rhodesiense, transmitted by the tsetse fly found in rural East and West Africa. Large animal game is the main reservoir.
After a bite, a localized inflammatory reaction occurs, followed in  to  days by a painless chancre (more common in East African than West African sleeping sickness) that increases in size for  to  weeks and then gradually regresses. Trypomastigotes mature and divide in the blood and lymph and cause intermittent fever unresponsive to antimalarials and occasional rash. In later stages, CNS involvement occurs, causing behavioral and neurologic changes, encephalitis, coma, and death. Disease categorization depends on whether or not the CNS has been invaded. Other complications include
,47 hemolysis, anemia, pancarditis, and meningoencephalitis.
Diagnosis is made by rapid evaluation of blood smears for the mobile parasite. Organisms can also be identified by aspiration of lymph nodes, chancres, or bone marrow or by CSF examination. The treatment of sleeping sickness varies according to the stage of illness. If the disease has not invaded the CNS, treat with pentamidine or suramin. If the CNS is invaded, treatment requires eflornithine, a combination of nifurtimox and
,47 eflornithine, or melarsoprol. A newly approved 10­day regimen of oral fexinidazole (given once daily at a dose of 1800 milligrams on days  to , and then 1200 milligrams on days  to 10) eases the treatment difficulty with similar success to IV regimens that are much more challenging.
AMERICAN TRYPANOSOMIASIS (CHAGAS’ DISEASE)
The protozoan Trypanosoma cruzi is spread by the reduviid “kissing bug” or “assassin” bug. Among travelers, it is rare; it causes an acute illness and, commonly, an asymptomatic infection with complications arising years later in the heart and GI tract. It is transmitted during a blood meal when the bug defecates trypanosome­infected feces around the meal site, causing a local inflammatory reaction and trypanosome inoculation after the host rubs the organism into the bite wound or into adjacent mucous membranes or conjunctiva. Infection can also be acquired by blood transfusion, by
,49 laboratory accidents, congenitally, and by oral transmission.
Unilateral periorbital edema (Romaña sign) or painful cutaneous edema at the site of skin penetration (chagoma) is followed by a toxemic phase with parasitemia causing lymphadenopathy and hepatosplenomegaly. The acute phase generally lasts  to  weeks but may last up to  months. Next is a long, asymptomatic, latent phase when nerve ganglion cells are gradually destroyed, leading to depressed cardiac and GI function. Cardiac complications include myocarditis, dysrhythmias, cardiomyopathy, and sudden death. Chagas­induced heart disease is the leading form of congestive heart failure in much of Latin America. GI complications are also due to the nervous system damage, most commonly in the form of megaesophagus or
 megacolon.
The acute­phase diagnosis occurs by detecting motile parasites on blood smears, by blood culture, or by muscle biopsy. In the chronic phase, serologic tests and tissue biopsy aid. Treatment is available for acute, reactivated, or chronic cases. The two medications used are nifurtimox and
 benznidazole.
LEISHMANIASIS (VISCERAL)
Leishmania is an intracellular protozoan transmitted by sandflies. The disease occurs sporadically in rural Africa, Asia, the Mediterranean basin, and
Central/South America, and additional global outbreaks occasionally occur. Suspect Leishmania in military personnel and their families living
 proximal to jungles, adventure travelers, field biologists, and emigrants from endemic zones.
The infecting species determines the pathology, ranging from a localized self­healing lesion to widespread, persistent, and potentially destructive disease. Four major clinical syndromes exist.
The most important diagnostic information is patient origin and travel itinerary because endemic areas suggest the infection type. Definitive diagnosis requires reference laboratory expertise to isolate motile extracellular parasites aspirated from bone marrow, spleen, or lymph nodes, or on smears or sections taken from the ulcer edge by punch biopsy.

Treatment is with liposomal amphotericin B.
DISEASES COMMONLY ASSOCIATED WITH ABDOMINAL AND URINARY COMPLAINTS
Illnesses causing abdominal pain and diarrhea are common among world travelers because of infecting bacteria, viruses, soil­transmitted helminths, and other parasites. Most infections are caused by the consumption of undercooked or fecal­contaminated foods and are preventable by adequate hygiene, potable water, and careful food preparation.
SCHISTOSOMIASIS (BILHARZIA OR SNAIL FEVER)
Schistosomiasis, infection with a blood fluke found in Africa, the Middle East, South America, and Asia, infects >200 million people worldwide, with  million people suffering severe consequences. For most short­term travelers, the risk is low, although significant outbreaks now occur among adventure tourists, longer­term visitors such as missionaries and volunteers, and those who swim in infested streams and lakes. The larvae are released into freshwater by snails, which are intermediate hosts. Infection occurs by tiny, free­swimming cercariae that penetrate wet, unbroken skin or are ingested from slow­moving freshwater. After inoculation, an immediate cercarial allergic and pruritic dermatitis may occur. When Katayama syndrome occurs, fever is accompanied by headache, cough, urticaria, diarrhea, hepatosplenomegaly, and eosinophilia. Worms mature into adults in the venous blood and, for the next  to  years, deposit eggs into selective body tissues (Schistosoma haematobium in the bladder and Schistosoma mansoni and Schistosoma japonicum in the GI tract). Eggs are deposited throughout the brain, skin, liver, and GI tract. Eggs stimulate a vigorous
 immune response that results in clinical symptoms.
CNS symptoms include seizures, paralysis, and acute transverse myelitis. S. haematobium infection causes dysuria, frequency, and terminal hematuria, and can cause bladder scarring, calcification, and squamous cell carcinoma. S. japonicum and S. mansoni infections can cause diarrhea, abdominal cramps, and acute abdominal pain and, late in the disease course, can lead to hepatosplenomegaly, hepatic granulomas, periportal fibrosis, and portal hypertension.
Diagnosis is suspected by detecting eosinophilia, confirmed by microscopic identification of ova in midday urine or stool samples or in a biopsy specimen. Serologic antibody detection methods are accurate and are usually positive in light infections missed by egg detection. Praziquantel
 treatment is active against adult worms only; thus, it cannot be used for postexposure prophylaxis, and re­treatment may be required.
DISEASES COMMONLY ASSOCIATED WITH ABDOMINAL PAIN AND DIARRHEA
Diarrhea and gastroenteritis are the most common travel ailments, affecting up to one half of travelers (Table 162­11). Traveler’s diarrhea is especially common after travel to Africa, Asia, the Middle East, South and Central America, and Mexico. Diarrhea is typically accompanied by fever, flatulence, nausea, emesis, and abdominal pain, which is usually spasmodic and colicky. Campylobacter jejuni may cause severe and constant pain, and cholera may cause somatic muscle cramps. Nonbloody gastroenteritis and diarrhea are usually caused by bacteria or bacterial toxins, whereas dysentery usually results from toxigenic and invasive bacteria such as Shigella, Salmonella, Campylobacter, Aeromonas, Escherichia coli, or
Entamoeba histolytica (Table 162­12). Traveler’s diarrhea is less commonly due to viruses.
TABLE 162­11
Common Infectious Diseases Causing Diarrhea in Travelers
Cause Organism Comments
Acute (duration <2 wk)
Viral Norwalk­like virus Often not diagnosed; may account for 5%–10% of acute traveler’s diarrhea
Rotaviruses
Enteroviruses
Bacterial Escherichia coli (enterotoxigenic or Most common identified cause of acute traveler’s diarrhea; 50%–70% enteroaggregative)
Campylobacter jejuni
Salmonella
Shigella
Vibrio
Clostridium difficile
Parasitic Giardia lamblia Accounts for <1%–5% of acute traveler’s diarrhea
Cryptosporidium parvum
Entamoeba histolytica
Cyclospora cayetanensis
Isospora belli
Balantidium coli
Trichinella spiralis
Chronic or persistent (duration >2–4 wk)
Bacterial See above Rare cause of chronic diarrhea
Parasitic
Enterocytozoon bieneusi Almost exclusively in immunocompromised
Microsporidial Encephalitozoon intestinalis
Protozoal G. lamblia Most commonly identified cause
E. histolytica Bloody diarrhea with fever; fecal WBCs are rare
Helminthic Trichuris trichiura Rarely associated with chronic diarrhea; usually in persons with heavy parasite
Strongyloides stercoralis burdens
Fasciolopsis buski
Schistosoma
TABLE 162­12
Causes of Diarrhea With and Without Fever or Blood
With Fever Without Fever
With blood Bacillary dysentery Amebiasis
Campylobacter enterocolitis Balantidium coli
Salmonella enterocolitis Schistosoma
Escherichia coli Trichuris
Without blood Salmonella enteritis Staphylococcus aureus
Malaria (especially Plasmodium falciparum) E. coli (enterotoxigenic)
Mild shigellosis Clostridium perfringens
Campylobacter infections Viral infections of the gut
Almost any infections in a child Food toxins
Acute abdominal pain among travelers is usually caused by nontravel causes with an expanded travel­based differential diagnosis. Mild traveler’s diarrhea can be treated with bismuth or loperamide alone. For moderate to severe traveler’s diarrhea (significant pain or blood in stool), treat empirically with azithromycin or fluoroquinolones (ciprofloxacin or levofloxacin), although resistance to fluoroquinolones is rising. Regional
 resistance can occur and should be verified (see Chapter 160, “Food and Waterborne Illnesses”).
AMEBIASIS
Pathogenic species such as E. histolytica are found worldwide and disproportionately infect those living in low­income settings. Amebiasis is typically spread by asymptomatic carriers whose excrement contains the encysted organism and is the leading cause of diarrhea globally. Travelers who are traveling for >6 months are at higher risk. Incubation times are typically  to  weeks for colitis and  weeks to several months for liver abscesses. Once cysts are ingested, amebic trophozoites invade the colon wall, lyse tissues, and cause necrotic abscesses.
Most infected people are asymptomatic. Symptoms range from alternating constipation and diarrhea over  to  weeks, to abdominal pain, bloody diarrhea, fever, dehydration, and weight loss. Extraintestinal metastases can infect the liver and, rarely, pericardium, lung, and brain. Colitis can lead to intestinal perforation and peritonitis. Complications such as liver abscesses may cause fever, right upper quadrant pain, or chronic, vague abdominal
 pain accompanied by weight loss.
It can be difficult to differentiate pathogenic organisms (E. histolytica) from benign organisms (Entamoeba dispar) on stool microscopy without use of stool antigen detection tests or, preferably, stool polymerase chain reaction. Serology for elevated antibody titers helps identify systemic disease.

Ultrasonography or CT scans may be useful to identify hepatic abscesses.
Treatment of asymptomatic cyst passers includes iodoquinol, paromomycin, or diloxanide furoate. For symptomatic disease, choices include metronidazole, or tinidazole followed by either iodoquinol or paromomycin. For liver abscess, severe intestinal disease, or extraintestinal disease,
 treat with metronidazole or tinidazole followed by iodoquinol or paromomycin.
GIARDIASIS
Giardia lamblia is a flagellated protozoan infecting the small intestine and biliary tree. It is globally endemic and is food­ or waterborne by fecal contamination with encysted parasites and can be transmitted through person­to­person contact. It is a common cause of chronic traveler’s diarrhea and can be contracted at camping sites and rural swimming areas. It can be differentiated from other causes of traveler’s diarrhea by the slow onset of
 symptoms and incubation period of typically longer than  week.
Ingested parasites reside in the duodenum and may lead to malabsorption because of duodenal microvilli obstruction. Symptoms include abdominal cramping, flatulence, and foul­smelling, watery diarrhea without blood or mucus. Chronic infections cause weight loss and anemia, and a common complication is lactose intolerance. Diagnosis is by duodenal sampling and stool ova and parasites showing either motile trophozoites or cysts. Giardia antigen detection in stool has good sensitivity and specificity. Treatment is with metronidazole, tinidazole, quinacrine, nitazoxanide, paromomycin, or
,61 furazolidone. Treatment is not always successful regardless of drug used, and combination therapy may be necessary.
CHOLERA
Cholera is an acute diarrheal disease caused by the bacterium Vibrio cholerae. It is endemic and epidemic to many tropical nations. It is reported in
Africa, Asia, Latin America, and more recently, Haiti and Mexico. Epidemics occur after flooding or acute population displacement with disruption of the water­sanitation system. Transmission is by fecal contamination of water or food (including raw or poorly cooked seafood and shellfish).
Significant bacterial ingestion is required to cause symptoms. The incubation time is  to  days, and symptoms result from sodium pump inhibition in the GI tract by the cholera toxin. Infection is usually mild but can be life threatening, particularly among vulnerable populations, such as malnourished children, migrants, and those with chronic illness. Another group at risk are individuals with achlorhydria or those using medications decreasing
 gastric acidity. There is an asymptomatic carrier state.
Severe disease is characterized by profuse, usually painless, watery diarrhea (“rice water stools”), severe dehydration, vomiting, leg cramps, and, occasionally, fever. Rapid fluid loss (up to  L/d) leads to extreme dehydration and shock. Aggressive rehydration can prevent death. Without proper
 fluid resuscitation, death can occur within hours, and mortality rates reach 50% to 75%. Diagnosis is clinical, and when suspected, a rectal swab or stool specimen can be sent to a reference laboratory for culture confirmation. Rapid dipstick testing of stool is possible but should be followed by confirmatory testing.
The cornerstone of treatment is aggressive fluid resuscitation with PO rehydration solution or IV fluids, coupled with correction of metabolic acidosis and hypokalemia. For those with severe illness, antibiotics can shorten the illness course, diminish vomiting, lessen volume resuscitation needs, and ensure that bacteria are eradicated from stool. Doxycycline is the antibiotic of choice, followed by azithromycin, tetracycline, erythromycin, or
 ciprofloxacin. Secondary transmission is rare, and close contacts should not be given antibiotics as prophylaxis.
PARASITIC HELMINTH (WORM) INFECTIONS
Major infestations are discussed here, and diagnosis and treatment are presented in Table 162­13. TABLE 162­13
Common Parasitic Helminth (Worm) Infestations
Source of
Name Human Symptoms Diagnosis Treatment
Contamination
Ascaris lumbricoides Fecal–oral Minimal symptoms; or pneumonia, Stool examination, Albendazole, 400
(roundworm) contamination malnutrition, biliary or bowel serology. milligrams single dose or poorly cooked obstruction, hepatic abscess, or food appendicitis, etc. Mebendazole, 100 milligrams twice a day for  d or 500 milligrams single dose or
Ivermectin, 150–200 micrograms/kg single dose
Enterobiasis (pinworm, Fecal–oral and Intense perianal itching Visual inspection, Albendazole, 400 seatworm) from cellophane tape swab of milligrams single dose contaminated anus upon waking. and repeat in  wk objects or
Mebendazole, 100 milligrams single dose and repeat in  wk or
Pyrantel pamoate,  milligrams/kg (up to  gram) single dose and repeat in  wk
Trichuris trichiura (whipworm) Fecal–oral Asymptomatic; or bloody diarrhea, Stool examination. Albendazole, 400 contamination rectal prolapse milligrams daily for  d or
Mebendazole, 100 milligrams daily for  d or 500 milligrams single dose
Ancylostoma duodenale and Contaminated Severe anemia; cutaneous larva Stool examination, may Albendazole, 400
Necator americanus (hookworm) soil, larvae migrans require serial exams. milligrams single dose penetrate the or skin Albendazole, 400 milligrams twice a day for  d or
Pyrantel pamoate,  milligrams/kg
(maximum,  gram) daily for  d
Taenia solium (pork tapeworm), Raw or Asymptomatic, abdominal pain, bowel Stool examination or Praziquantel, 5–10
T. saginata (beef tapeworm), and undercooked obstruction; Taenia cysts in skin, eye, serology. Serology may milligrams/kg single
Diphyllobothrium latum (fish pork or beef or brain, heart (see “Cysticercosis” be negative if cysts are dose tapeworm) fish section, above) calcified.
Strongyloides stercoralis Contaminated Cough, pneumonia, and wheezing; Stool examination or Ivermectin, 100
(threadworm) soil, larvae abdominal pain, bloody diarrhea stool concentration micrograms/kg/d for  d penetrate skin methods; serology or or sputum examination. Albendazole, 400 milligrams twice a day for  d
In the patient in whom empirical therapy is chosen due to the appearance of a worm in fecal matter, treatment for nematodes can be considered. By treating the adult patient empirically with albendazole for  days with a single repeat dose in  weeks, a number of pathologies can be treated (roundworm, pinworm, whipworm, and hookworm). Send stool samples for laboratory analysis to provide more focused treatment.
Diagnosis and treatment of these worms are provided in Table 162­13. ASCARIASIS (ROUNDWORM)
The risk of infection with Ascaris lumbricoides to short­term travelers is low, and infection is suspected following ingestion of street vendor foods or vegetables fertilized by “night soil” (human feces) or animal feces. Eggs survive for years in moist soil, and transmission is typically fecal–oral or through poorly cooked food. Symptoms are usually minimal; a dry cough or eosinophilic pulmonary infiltrates may occur as young worms are expectorated and migrate from the lungs to the esophagus and gut. A large worm burden can lead to malnutrition and weakness, as well as bowel obstruction. Wandering Ascaris also traverse internal organs, rarely leading to biliary obstruction, hepatic abscess, acute pancreatitis, acute
 appendicitis, or hypersensitivity pneumonitis.
ENTEROBIASIS (PINWORM)
Enterobiasis vermicularis is a common tropical disease caused by a small intestinal parasite transmitted by the fecal–oral route and is often acquired from contaminated objects such as toys, utensils, and bedding. It is a common disease among U.S. children and is more likely to be peridomestic rather than occur after tropical travel; hence, treatment of all housemates is recommended. The disease is characterized by intense perianal itching.
Occasionally, worms may migrate to cause appendicitis, or via perianal migration, they may ultimately migrate to fallopian tubes and endometrium,
 causing inflammation and obstruction.
TRICHURIS (WHIPWORM DISEASE)
Whipworm (Trichuris trichiura) is a nematode parasite of the large intestine distributed globally but most heavily in the tropics. Long­term travelers, former tropical residents, and visitors from the tropics are at high risk. It is obtained by ingesting contaminated soil or vegetables and is not transmissible from person to person. Light infestations are asymptomatic, and heavy infestations cause nonspecific abdominal symptoms, bloody
 diarrhea, and rectal prolapse.
HOOKWORM
Hookworm is a common chronic nematodal infection caused by Ancylostoma duodenale and Necator americanus, which are globally distributed but are most heavily found in the tropics and subtropics. Because symptoms require large worm burdens, it is a low risk among short­term travelers.
Hookworm causes chronic, severe anemia, especially in children. The cutaneous form is called cutaneous larva migrans (see later section, “Diseases
Commonly Associated With Eye or Skin Complaints”). Transmission is by direct skin contact with soil contaminated by human feces, often in children with poor footwear exposed to raw sewage. Filariform larvae penetrate the skin. Microscopic examination of stool for eggs is the usual means of
,67 diagnosis.
CESTODES (TAPEWORMS)
Among the cestodes, taeniasis and cysticercosis are the most pathologic. Infections occur worldwide, but especially in the tropics, and risk is high among children, the mentally disabled, and immigrants or visitors from endemic nations. Risk to travelers is low but is increased with consumption of undercooked pork, fish, or beef.
Taenia solium and Taenia saginata (Pork and Beef Tapeworm)
T. solium (pork tapeworm) is encountered in the United States in immigrants or visitors to or from Central America and the Middle East. T. saginata
(beef tapeworm) is seen more often, especially in those who consume raw beef (e.g., steak tartare), particularly in Latin America, Eastern Europe,
Africa, and Russia. Adult worms live in the small intestine. Infected patients can be asymptomatic or present with nausea and vomiting, headache, abdominal pain, pruritus, constipation, diarrhea, and intestinal obstruction. The larval stage of T. solium can cause clinical disease (cysticercosis), which can sometimes be fatal. Taenia cysts may be found in subcutaneous tissue, the eye, brain, and heart and can cause seizures and hydrocephalus.
Radiographs of the soft tissues may reveal curvilinear calcifications indicative of cysts, and cysts can be seen in the meninges and brain parenchyma on

CT scanning. For discussion of neurocysticercosis see the earlier “Cysticercosis” section. Dipylidium caninum is discussed in Chapter 161. Diphyllobothrium latum (Fish Tapeworm)
Diphyllobothrium latum (fish tapeworm) is encountered in those consuming raw fish (e.g., sushi and sashimi) or gefilte fish. Diphyllobothrium can compete with the host for vitamin B , and patients can develop pernicious anemia. Most patients are asymptomatic, but some develop intestinal or

 biliary obstruction.
STRONGYLOIDES
Strongyloides stercoralis infects the small intestine. Distribution is worldwide, but infection is most common in humid tropics. Infection can develop in overseas military personnel, refugees, or immigrants. The risk is low in short­term travelers. Most infections cause minimal GI symptoms, occasional dyspnea, or hemoptysis with migration, or no symptoms. However, severe disseminated disease may occur in immunocompromised patients and cause hyperinfection with multiorgan symptoms, including meningitis, and septic shock. An upper GI series may reveal a deformed duodenal bulb, and

Strongyloides may be confused with ulcer disease.
DISEASES COMMONLY ASSOCIATED WITH EYE OR SKIN COMPLAINTS
Skin complaints among travelers are common and nonspecific and have many causes. Travel­related skin disease is generally caused by one of the following: (1) exacerbations of previous conditions (e.g., atopic dermatitis, psoriasis); (2) environmental conditions (e.g.,
 photosensitivity, contact allergies); or (3) infective organisms causing infestations or infections. The distribution and timing of the
 dermatosis may aid diagnosis of rashes associated with systemic illness (Table 162­14). Among rashes reported by travelers, most are minor problems, such as sunburn, phototoxic/sensitivity reactions, insect bites, and prickly heat, and are often self­limiting and necessitate symptomatic care. The most common tropical travel dermatoses in ill individuals requiring therapy are cutaneous larva migrans, insect bites
 including bites with bacterial superinfections, abscesses, and allergic reactions. The risk of serious conditions tends to increase with the amount of time spent overseas, and thus short­term travelers rarely contract dermatoses such as filariasis, Buruli ulcer, yaws, and leprosy (Hansen’s disease). To further aid diagnosis, travelers with dermatoses can fit into five syndromic and morphologic categories (Table 162­15).
TABLE 162­14
Cutaneous Manifestations of Selected Infections
Appearance of Lesion Possible Diagnosis
Maculopapular rash Dengue fever
Viral hemorrhagic fevers
Leptospirosis
Acute human immunodeficiency virus infection
Erythema chronicum migrans Lyme disease
Rose spots Typhoid fever
Pustules Disseminated gonococcal infection
Petechiae, ecchymoses, hemorrhage Meningococcemia
Dengue fever
Viral hemorrhagic fevers
Yellow fever
Rocky Mountain spotted fever
Epidemic louse­borne typhus
Leptospirosis
Eschar Tick or scrub typhus
Anthrax
Ulcer Tularemia
Cutaneous diphtheria
Urticaria Helminthic infections
TABLE 162­15
Syndromic Categories of Travel­Related Dermatoses With Select Examples
Fever and rash (petechial or hemorrhagic): dengue fever, arboviruses, rickettsial infections (e.g., scrub typhus), chikungunya, meningococcemia, leptospirosis, malaria, and erythema multiforme caused by drug reaction or common infection
Papular eruptions: insect bites, persistent lesions (chiggers), scabies, allergic drug reactions, cercarial dermatitis (swimmers), Pseudomonas folliculitis
(hot­tubbing), onchocerciasis (long­term travel)
Persistent nodules: furunculosis, myiasis (movement within the lesion), chancroid, syphilis, systemic parasites/fungi
Migratory swellings or skin lesions: cutaneous larva migrans, strongyloidiasis (fast moving and often on the buttocks), urticaria from various causes, and Loa loa (rarely)
Ulcerative lesions: pyodermas, spider bites, chancroid and syphilis, cutaneous leishmaniasis
Management includes arranging biopsy for patients with chronic ulcerative lesions. Beware of the rare patient presenting with anxiety of parasitosis regardless of travel history. The following are select dermatoses associated with tropical exposures.
FILARIASIS: ONCHOCERCIASIS AND LOA LOA
ONCHOCERCIASIS (RIVER BLINDNESS)
River blindness is a chronic, nonfatal filarial disease leading to subcutaneous skin changes and blindness. It is caused by Onchocerca volvulus, a nematode transmitted by the female black fly, Simulium species, found near fast­moving rivers predominantly in sub­Saharan Africa as well as small foci in Yemen, Venezuela, and Brazil. Symptoms may take up to  months to appear and include intractable pruritus, altered skin pigmentation, skin nodules, lymphadenitis, and gradual visual impairment leading to blindness. Adult female worms reside in 2­ to 3­cm painless nodules in skin and bones near joints, and release microfilariae that migrate through the skin, causing intense pruritus when they die, leading to chronic dermatitis, edema, and skin atrophy. Skin pigment changes result in “leopard skin,” whereas loose pelvic skin is called “hanging groin.” Blindness is a result of microfilariae migrating to the eye, invading it, and causing permanent damage when they die. Diagnosis is made by identification of microfilariae from a fresh skin biopsy, from nodule biopsies, or in the urine. Slit­lamp examination may reveal microfilariae in the cornea, anterior chamber, or vitreous.
Treatment of choice is ivermectin, which kills microfilariae but does not kill the adult worm, thus requiring repeated dosing, suppressing microfilariae
 release from adults and preventing spread to eyes and skin.
LOA LOA (EYE WORM)
Loiasis is caused by a filarial nematode confined to the rain forests of western and central Africa in a distribution that overlaps with that of onchocerciasis. It is a low risk to short­term travelers but should be suspected among immigrants, refugees, visiting nationals, and expatriates living several months or more in endemic zones. Among travelers, worm burden is usually low, and symptoms are related to hypersensitivity syndromes and not serious disease. The adult worms inhabit subcutaneous tissues, move about freely, and can live for up to  years after the patient’s last possible exposure. They are spread from the bite of the Chrysops fly. Infections are usually asymptomatic; however, at times, infections cause painful or itchy subcutaneous swellings near the face and extremities known as Calabar swellings. Occasionally a worm passes across the eye under the conjunctiva,
 causing intense irritation, pain, and swelling of the periorbital tissues.
Diagnosis is made by clinical presentation and by evaluating daytime­drawn blood for distinctively sheathed microfilariae and high­grade eosinophilia.
Treatment for microfilariae and adult worms is diethylcarbamazine citrate. Screen for coinfection with onchocerciasis, which requires treatment first, given that diethylcarbamazine citrate is contraindicated in the treatment of onchocerciasis due to an inflammatory response that could induce blindness. In patients with very high microfilariae counts, diethylcarbamazine citrate may induce a sudden severe hypersensitivity and encephalitic
 syndrome, so treatment is begun with a very small dose, or a test­and­not­treat strategy for individuals with high microfilarial loads can be employed.
Albendazole can also be used to treat loiasis. Surgical excision is not recommended because multiple worms may not be visible. Subconjunctival
 worms, however, can be removed from the eye with analgesia and fine tweezers.
CREEPING ERUPTION (CUTANEOUS LARVA MIGRANS)
Erythematous “creeping eruption” commonly occurs among tropical travelers and beach resort vacationers who walk barefoot or sit in beach sand
 contaminated by dog feces harboring the parasite Ancylostoma braziliense. The lesions are typically slow moving, tracking, and serpiginous and are a result of an inflammatory reaction from the worm, which is unable to complete its growth cycle in humans (it is only an effective parasite of dogs or cats). Pruritus causes sleeplessness and restlessness. Bacterial superinfection is not uncommon. Diagnosis is based on clinical presentation, and no
 serology is available. Treatment consists of albendazole or ivermectin.
CUTANEOUS LEISHMANIASIS
Cutaneous leishmaniasis is the most important cause of chronic skin ulceration in the world and is spread by sandflies in tropical and subtropical regions of Latin America, Africa, the Middle East, and Asia. This should be suspected among travelers such as military personnel, biologists, ecotourists, and adventure travelers, and should be part of the differential diagnosis of nonhealing cutaneous ulcers among travelers, foreign visitors, and immigrants from endemic areas. Although there are a variety of subtypes causing varying infections, the common presentation is of a small papule slowly enlarging and forming a painless shallow skin ulcer with a noticeable rolled edge like a volcano, with a raised edge and central crater, often with a scab. Diagnosis is made by tissue biopsy of the indurated ulcer margin or scraping of the base with material placed on a slide followed by Giemsa stain. Many forms are self­limiting; often observation alone is preferred, or lesions can be treated with heat application or paromomycin topical ointment. More serious forms can be treated with liposomal amphotericin B or sodium stibogluconate. Treatment response may vary with involved
 species and geographic distribution.
LYMPHATIC FILARIASIS
Lymphatic filariasis is caused by nematodes (Wuchereria bancrofti, Brugia malayi, and Brugia timori) residing in the subcutaneous tissues and lymphatics. It is common to South America, Africa, and Asia. The risk to short­term travelers is low, although cases have been imported by long­term travelers. It is transmitted by flies or mosquitoes permitting larvae to enter the puncture wound during their blood meal. Adult filariae then reside in lymphatics and produce microfilariae that migrate to the bloodstream at night. First, symptoms develop after  months to  years. The most common symptom is recurrent bouts of “filarial fevers” lasting  to  weeks, associated with warmth and tenderness overlying a lymphatic vessel, followed by retrograde lymphangitis. The most frequently affected sites are extremities, breasts, and spermatic cord. As more attacks occur, lymphatics are chronically damaged, and the consequence is elephantiasis. “Nocturnal asthma” can occur with associated tropical pulmonary eosinophilia. Diagnosis depends on finding the sheathed microfilariae in a nocturnal peripheral blood smear. Serology is often useful in mild infections. Treatment is diethylcarbamazine citrate, which can cause hypersensitivity reactions with antigen liberation. Because of this, testing for coinfection with onchocerciasis and Loa loa is important to prevent adverse effects. Symptoms can be reduced by starting with a small dose. Repeated treatment may
,80 be necessary.
DISEASES COMMONLY ASSOCIATED WITH PULMONARY COMPLAINTS
Returning travelers frequently develop respiratory complaints such as persistent cough, sinus congestion, and fever. Common local respiratory pathogens including viral causes such as influenza and bacterial infections are the most common etiologies. Risk factors for pulmonary disease include prolonged air travel with recirculation of dry cabin air and exposure to fellow travelers with infectious agents. Long­term travelers are at increased risk for tuberculosis that may manifest many years after travel. In the ED, isolate the patient because contagious infections, such as tuberculosis, influenza, or coronaviruses (e.g., severe acute respiratory syndrome or Middle East respiratory syndrome), are possible. Also, have healthcare workers use personal protective devices.
Once public health threats are reasonably excluded, the evaluation is similar as for any nontravel patients. Additionally, ask about travel­related risk factors because a variety of pathogens such as viruses (viral hemorrhagic fevers), helminths (Strongyloides, Schistosoma, Paragonimus, Ascaris), and protozoa (E. histolytica, Trypanosoma, Leishmania) produce pulmonary symptoms or radiographic infiltrates.
CORONAVIRINAE: SEVERE ACUTE RESPIRATORY SYNDROME AND MIDDLE EAST RESPIRATORY SYNDROME
Coronaviruses are the causative agents of a diverse set of respiratory illnesses, ranging from the common cold to severe acute respiratory syndrome.
As such, symptoms range from benign upper respiratory symptoms of cough, sinus congestion, and malaise to severe respiratory distress, pneumonia, multiorgan failure, and death.
Preventive measures target reduced close contact with infected persons and lessening nosocomial transmission. Place patients on airborne
 precautions, and healthcare providers should use gowns, gloves, eye protection, and respiratory protection with a minimum of a N95 mask. Promptly notify local and state health departments of the case. Treatment of a respiratory syndrome caused by a coronavirus is supportive, although other
,83 therapies, including interferon­alfa, ribavirin, and steroid treatments, are often attempted absent strong data.
SEVERE ACUTE RESPIRATORY SYNDROME FROM CORONAVIRUS
First reported in 2002 in China, severe acute respiratory syndrome from coronavirus is a poorly understood coronavirus. The reservoir is not certain, but the transmission cycle is thought to include bats and civet cats. Human­to­human transmission is most common. In 2002 to 2003, an outbreak occurred with the spread of severe acute respiratory syndrome to  countries with >8000 cases. Symptoms start with dry cough and diarrhea and
 progress to fulminant respiratory failure. At present, there are no known epidemics occurring.
MIDDLE EAST RESPIRATORY SYNDROME FROM CORONAVIRUS
Middle East respiratory syndrome from coronavirus is an emerging coronavirus first reported in 2012. Between September 2012 and November 2018,
 the World Health Organization reported a total of 2260 cases of the Middle East respiratory syndrome coronavirus infection with >800 deaths ; approximately 80% of cases have been reported in Saudi Arabia, but cases have been reported in  countries, including the United States.
Although not certain, Middle East respiratory syndrome is likely to be spread by “droplet infection.” Dromedary camels are thought to be a reservoir, but exact transmission mechanisms are not understood. Polymerase chain reaction can be used to detect Middle East respiratory syndrome
 coronavirus.
TUBERCULOSIS

One fourth of the world is infected with tuberculosis, and in 2017, there were .3 million tuberculosis­related deaths worldwide. The risk of tuberculosis in travelers is about 1% per year of stay in most areas of the world; however, individual risk factors and highly endemic settings can result
 in an increased risk. High­risk sites for multidrug­resistant mycobacteria are Russia, Eastern Europe, Southeast Asia, China, southern Africa, and
South America. Refugees and immigrants or expatriate workers (especially healthcare workers) returning from endemic areas are at higher risk of clinical tuberculosis (e.g., Eastern Europe, Africa, Asia). The initial ED management of suspected tuberculosis after respiratory isolation is discussed elsewhere (see Chapter , “Tuberculosis”).
PARAGONIMIASIS (LUNG FLUKE DISEASE)
Paragonimus species cause trematode infections primarily affecting the lungs. It is widely distributed but is mostly found in the Far East and Southeast
Asia (China is the major endemic site). It is uncommon in short­term travelers, but should be considered among immigrants or long­term residents of

Asia who are also at risk for tuberculosis and among travelers indulging in local exotic foods. Cases in the United States have also been reported.
Humans are infected by swallowing larvae contaminating raw or pickled crustaceans. Incubation lasts  to  weeks, as larvae migrate from the duodenum to the lungs, where they cause purulent and bloody effusions, productive cough (eggs are expectorated), pleuritic chest pain, and hemoptysis. Chest pain is often present, and fever with night sweats may occur during early infections, causing tuberculosis to be incorrectly
 diagnosed.
Chest radiographs demonstrate diffuse segmental infiltrates, nodules, ring cysts, or pleural effusions. Suspect paragonimiasis when no sputum smear acid­fast bacilli are found. Less commonly, parasites do not reach the lung, and diverse symptoms develop depending on fluke location. Symptoms include abdominal pain, diarrhea, migrating subcutaneous swelling, blindness, epididymis, testicular inflammation, and a variety of cerebral symptoms. Seizures can occur from intracranial encysted adults. Diagnosis is made by finding the characteristic eggs in sputum, urine, or stool, or by
 serologic tests. The treatment of choice is praziquantel or triclabendazole.


## Page 31

University of Pittsburgh
Access Provided by:
. https://www.cdc.gov/parasites/cysticercosis/index.html. (Centers for Disease Control and Prevention: Parasites: cysticercosis.) Accessed
November , 2018. . Gripper LB, Welburn SC: Neurocysticercosis infection and disease: a review. Acta Trop 166: 218, 2017. [PubMed: 27880878]
. Neurocysticercosis. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . Trypanosomiasis, West African. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . Trypanosomiasis, East African. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . Filigheddu MT, Górgolas M, Ramos JM: Orally­transmitted Chagas disease. Med Clin (Barc) 148: 125, 2017. [PubMed: 27993415]
. Bern C: Chagas’ disease. N Engl J Med 373: 456, 2015. [PubMed: 26222561]
. https://www.cdc.gov/parasites/chagas/disease.html. (Centers for Disease Control and Prevention: Parasites: American trypanosomiasis [also known as Chagas disease].) Accessed November , 2018. . Trypanosomiasis, American, Chagas Disease. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November ,
2018. . https://www.cdc.gov/parasites/leishmaniasis/epi.html. (Centers for Disease Control and Prevention: Parasites: leishmaniasis.) Accessed November
, 2018. . Leishmaniasis. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . https://wwwnc.cdc.gov/travel/yellowbook/2018/infectious­diseases­related­to­travel/schistosomiasis. (Centers for Disease Control and
Prevention: Schistosomiasis.) Accessed November , 2018. . Schistosomiasis. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . Traveler’s Diarrhea. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . https://wwwnc.cdc.gov/travel/yellowbook/2018/infectious­diseases­related­to­travel/amebiasis. (Centers for Disease Control and Prevention:
Amebiasis.) Accessed November , 2018. . Shirley DT, Farr L, Watanabe K, Moonah S: A review of the global burden, new diagnostics, and current therapeutics for amebiasis. Open Forum
Infect Dis 5: ofy161, 2018. [PubMed: 30046644]
. Amebiasis, Entamoeba histolytica. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . https://wwwnc.cdc.gov/travel/yellowbook/2018/infectious­diseases­related­to­travel/giardiasis. (Centers for Disease Control and Prevention:
Giardiasis.) Accessed November , 2018. . Tornieporth NG, Johnson WD: Infectious considerations in the world traveler. Dermatol Clin 15: 285, 1997. [PubMed: 9098637]
. Gastroenteritis, Vibrio cholerae. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. 6D3o. wRnoluonaddwedo r2m0 2N5e­m7­a1t o6d:2e0 A sPc a Yrioausirs I. PS aisn f1o3rd6 .G14u2id.1e 5A9n.t1im27icrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. Chapter 162: Global Travelers, Shawn M. D’Andrea; Annelies De Wulf 
. Terms of Use * Privacy Policy * Notice * Accessibility
. Roundworm Nematode Pinworm. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . Trichuris trichiura, Whilworm. (2018). Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . https://www.cdc.gov/parasites/hookworm/. (Centers for Disease Control and Prevention: Parastites: hookworm.) Accessed November , 2018. . Hookworm, Necator americanus and Ancylostoma duodenale. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software].
Accessed November , 2018. . https://www.cdc.gov/parasites/taeniasis/. (Centers for Disease Control and Prevention: Parasites: taeniasis.) Accessed November , 2018. . https://www.cdc.gov/parasites/diphyllobothrium/ (Centers for Disease Control and Prevention: Parasites: diphyllobothrium infection.) Accessed
November , 2018. . Strongyloides stercoralis, Strongyloidiasis. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November ,
2018. . Suh KN, Kozarsky PE, Keystone JS: Evaluation of fever in the returned traveler. Med Clin North Am 83: 997, 1999. [PubMed: 10453260]
. Lederman ER, Weld LH, Elyazar IR, et al: Dermatologic conditions of the ill returned traveler: an analysis from the GeoSentinelSurveillance
Network. Int J Infect Dis 12: 593, 2008. [PubMed: 18343180]
. https://wwwnc.cdc.gov/travel/yellowbook/2018/infectious­diseases­related­to­travel/onchocerciasis­river­blindness. (Centers for Disease Control and Prevention: Onchocerciasis [river blindness].) Accessed November , 2018. . https://wwwnc.cdc.gov/travel/yellowbook/2018/post­travel­evaluation/skin­soft­tissue­infections­in­returned­travelers (Centers for Disease
Control and Prevention: Skin and soft tissue infections in returned travelers.) Accessed November , 2018. . Kamgno J, Pion SD, Chesnais CB, et al: A test­and­not­treat strategy for onchocerciasis in Loa loa­endemic areas. N Engl J Med 377: 2044, 2017. [PubMed: 29116890]
. Filariasis: Loa loa, Onchocerciasis. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . Jong EC, McMullen R: Travel medicine problems encountered in emergency departments. Emerg Med Clin North Am 15: 261, 1997. [PubMed: 9056580]
. Ancylostoma brazielense, caninum (Cutaneous Larva Migrans). Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software].
Accessed November , 2018. . Lymphatic Filiarisis: Elephantiasis. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . https://wwwnc.cdc.gov/travel/yellowbook/2018/infectious­diseases­related­to­travel/filariasis­lymphatic. (Centers for Disease Control and
Prevention: Filiarisis, lymphatic.) Accessed November , 2018. . http://www.cdc.gov/coronavirus/mers/infection­prevention­control.html. (Centers for Disease Control and Prevention: Middle East respiratory syndrome.) Accessed February , 2015. . Coronavirus, SARS, MERS. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018. . Middle East Respiratory Syndrome, MERS. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November ,
2018. . http://www.who.int/ith/diseases/sars/en/. (World Health Organization: Severe acure respiratory syndrome.) Accessed November , 2018. . http://www.who.int/emergencies/mers­cov/en/. (World Health Organization: Middle East respiratory syndrome coronavirus [MERS­CoV].) Accessed
November , 2018. . http://www.who.int/en/news­room/fact­sheets/detail/middle­east­respiratory­syndrome­coronavirus­(mers­cov). (World Health Organization:
Middle East respiratory syndrome coronavirus [MERS­CoV].) Accessed November , 2018. . https://www.cdc.gov/tb/statistics/default.htm. (Centers for Disease Control and Prevention: Tuberculosis [TB].) Accessed November , 2018. . Denholm JT, Thevarajan I: Tuberculosis and the traveller: evaluating and reducing risk through travel consultation. J Travel Med 23: , 2016. [PubMed: 27358971]
. Lane MA, Marcos LA, Onen NF, et al: Paragonimus kellicotti flukes in Missouri, USA. Emerg Infect Dis 18: 1263, 2012. [PubMed: 22840191]
. https://www.cdc.gov/parasites/paragonimus/health_professionals/index.html (Centers for Disease Control and Prevention: Parasites: resources for helath professionals. Accessed November , 2018.)
. Flukes: Liver, Lung, Intestinal. Sanford Guide Antimicrobial Therapy for iOs [Mobile Application Software]. Accessed November , 2018.

