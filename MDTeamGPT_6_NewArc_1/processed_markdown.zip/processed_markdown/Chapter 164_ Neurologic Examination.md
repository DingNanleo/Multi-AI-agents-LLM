## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 164: Neurologic Examination
J. Stephen Huff; Andrew D. Perron
INTRODUCTION
In most patients, the physical examination confirms thoughts formulated during history taking that are often the key to patient evaluation. Time of onset, symptom progression, associated complaints, and exacerbating factors are important historical points to guide appropriate examination and testing. The neurologic examination does not exist in isolation from the general physical examination or imaging procedures, and it is unusual for the neurologic examination to delineate a problem not already suggested by the patient’s history or general physical examination. Few findings of the neurologic examination are pathognomonic of clinical conditions or are sufficiently specific that examination alone secures the diagnosis. Further complicating the value of the neurologic examination is that the sensitivity and specificity of different examination techniques have not been rigorously investigated, and the degree of interobserver variability is not known. The uncooperative patient or the patient with altered mental status presents additional challenges in performing a detailed examination.
The idea of performing a “complete” examination in the ED is impractical, because a “complete” examination frequently is neither appropriate nor required. An adequate examination is one that is sufficient for the task at hand. Examination of children follows the same framework as that for adults, but even more information is gathered indirectly by observation. For example, interacting with a child while playing with a toy or other object allows
 the examiner to assess vision, extraocular motion, coordination, and strength as the child reaches for and grasps the toy. Traditional neurologic formulation follows a three­tiered approach: (1) Is there a lesion of the nervous system? (2) Where is the lesion? (3) What is the lesion? The examination detailed in this chapter is arbitrarily divided into eight sections with basic and advanced levels described for each section.
ORGANIZATIONAL FRAMEWORK
Organization of the neurologic examination into a framework of subsections is a convenient technique. Some of the tests grouped in a section assess several aspects of nervous system function, and listing of tests in a particular section is for organizational convenience. For example, visual field testing, although technically a test of higher cortical function, is listed with cranial nerve testing because the examining physician may find it easier to evaluate visual fields during that portion of the examination assessing cranial nerve function. One organizational scheme divides the examination into eight elements:
. Mental status testing
. Higher cerebral functions
. Cranial nerves
. Sensory examination
. Motor system
. Reflexes
. Cerebellar testing
. Gait and station
MENTAL STATUS TESTING

A mental status examination is part of every patient encounter. The observation may be brief and descriptive, such as, “The patient is awake, alert, and
Chapter 164: Neurologic Examination, J. Stephen Huff; Andrew D. Perron conversant,” or it may be quite detailed. Mental status assesses the emotional and intellectual functioning of the patient. It is important to make some
. Terms of Use * Privacy Policy * Notice * Accessibility assessment of mental status since the patient with an abnormal mental status cannot be relied on for an accurate medical history.
Major elements of mental status testing are assessment of appearance, mood, and insight; assessment for thought disorders or abnormal thought content such as hallucinations; and testing of the sensorium. Sensorium is a term for the appropriate awareness and perception of consciousness.
Mental status testing is covered more fully in Chapter 168, “Altered Mental Status and Coma.”
One key element in mental status testing is assessment of attention and memory. Attention testing is easily performed with digit repetition. The average adult of normal intelligence should be able to repeat six or seven digits forward and four or five digits backward. Failure to do so may suggest confusion, delirium, or a problem with language perception. Often this represents a problem with attention rather than with memory. Memory is a complex process but is often simply broken into long­term and short­term activities. Long­term memory is recall of events of some months or years ago. Short­term memory is assessed by asking about events of the day or by three­object recall at  minutes. State three items and ask the patient to repeat; reassess at  minutes to obtain a gross assessment of short­term memory function. Failure to repeat the items immediately after presentation is likely an indication of an attention problem rather than of a memory problem.
Evaluation by screening tools is described in Chapter 168. Other screening tests for depression, substance abuse, or other problems are outside the scope of this chapter.
In general, patients with abnormal mental status, especially attention problems or disorientation, are more likely to have medical problems rather than functional or psychiatric causes. If a patient suffers from significant inattention, it is unlikely that the examiner will truly be able to determine whether the primary problem is one of cognition or attention.
HIGHER CEREBRAL FUNCTIONS
Assessment of higher cerebral functions tests neurologic tasks that are thought to be processed in the cerebral cortex. Language function defines the dominant hemisphere. The majority of the population is right­handed; for 90% of these patients, the left hemisphere is where language functions reside; hence, they are referred to as left­hemisphere dominant. Even in left­handed patients, most will be left­hemisphere dominant for language.
Thus, a large cortical stroke affecting the cortex of the dominant hemisphere (the left hemisphere in most patients, whether they are left­ or right­hand dominant) likely will affect language functions.
The nondominant hemisphere is the right hemisphere in most people. The nondominant hemisphere is concerned with spatial relationships. Often a nondominant hemispheric problem is suspected in the ED when the patient has consistent visual inattention to a care provider approaching from one side (usually the patient’s left side).
Higher cerebral function pragmatically involves the assessment of language. For a patient with speech that is difficult to understand, a fundamental distinction must be made between dysarthria and a dysphasia (aphasia and dysphasia are often used interchangeably in clinical practice). Dysarthria is a mechanical disorder of speech resulting from difficulty in the production of sound from weakness or incoordination of facial or oral muscles; this may result from a motor system problem (cortical, subcortical, brainstem, cranial nerve, or cerebellar), but it does not represent a disorder of higher cerebral function. Dysphasia is a problem of language resulting from cortical or subcortical damage; the portion of the brain concerned with comprehension, processing, or producing language is impaired.

There are many different types of aphasias, but a simplified scheme is sufficient for assessment in the ED. A description of aphasia into fluent, nonfluent, or mixed patterns is adequate for initial testing and for communicating with other physicians.
BASIC
Normal conversation monitoring for correct responses is the common screening examination for a language disorder. If suspicion of a language disorder exists, a series of assessments allows categorization of the aphasia.
Test comprehension initially by the ability to follow simple commands. Asking the patient to identify common objects may also be part of the assessment. Use commonly available objects, such as a watch or a pen, as a stimulus. Query the patient regarding the names of different parts of the objects. Ask the patient to demonstrate how an object is used. The inability to show how an object is used, assuming hearing and motor functions are intact, may represent an apraxia, which is defined as the inability to perform a willed act.
In a nonfluent aphasia (a rough synonym is motor or expressive aphasia), the speed of language and the ability to find the correct words may be impaired. A common type of nonfluent motor aphasia is known as Broca’s aphasia. Speech may be halting and slow, with stops between words or word fragments.
In a fluent aphasia (a rough synonym is auditory or receptive aphasia), the quantity of word production is normal or even increased. Sentences may have normal grammatical structure with normal rhythm, and intonation may be clearly articulated. However, language is impaired, and the listener may be struck by peculiarities of conversation that lack appropriate content. Incorrect words may be substituted within sentences that may be soundalike words or words with similar yet incorrect meanings. A global or mixed aphasia involves elements of fluent and nonfluent aphasias and is the most common type encountered in clinical practice.
Nondominant hemisphere problems may show problems of auditory inattention, visual inattention, or sensory inattention.
ADVANCED
Testing of mental status and cognitive function requires an appreciation of cultural context and language barriers. Further assessment of comprehension may involve showing the patient a picture and asking for the patient’s interpretation of the picture while noting if the content is correctly described and if the sentence structure and word selection of the descriptions are correct.
Assessing the ability of the patient to repeat a phrase may be a key point in delineating some types of fluent aphasias. Typically, the ability to repeat short words is more impaired than the ability to repeat longer words. A classic test involves asking the patient to repeat the phrase, “No ifs, ands, or buts.” In one type of fluent aphasia, Wernicke’s aphasia, comprehension is impaired, as is repetition.
Paraphasic errors may be further characterized in patients with fluent aphasia. Literal paraphasic errors are ones in which parts of words are replaced by incorrect sounds. The use of spool when spoon is meant is an example of a literal paraphasic error. At times, the errors may reach the point where the substitutions are not understandable, and neologisms (meaningless collections of syllables that take the place of a words in conversation) are produced. Verbal paraphasic errors involve substitutions of correct words for others; for example, a patient may wish to use spoon in a sentence and substitute fork or even bike; the word is a correct word, but the meaning of the sentence is transformed erroneously. A patient aphasic in speaking will also be aphasic in written communication.
A sequence of simple commands such as requesting the patient to draw a circle and then placing numbers like the numbers on a clock may reveal constructional errors. A response consistent with dysfunction of the nondominant hemisphere might be numbering half the clock face and stopping or placing all the numbers around one half of the circle.
Impairment of sensory perception on the cortical level may involve the inability to distinguish objects by touch alone. Implied in this testing is that the primary sensory modalities (sharp, light touch, etc.) are intact. In cases of nondominant hemisphere lesions, the ability to identify objects placed in a hand, such as coins, may be impaired.
SPECIAL CIRCUMSTANCES
A fluent aphasia may so severely impair communication that the patient is thought to be intoxicated or psychotic. Pay attention to the pattern of speaking—this may give the first indication of a language problem, and further constructional or language testing may demonstrate the presence of an aphasia.
CRANIAL NERVES
BASIC
A survey of the cranial nerves is often an integral part of neurologic assessment. Much information may be gathered informally. Look for facial asymmetry (cranial nerve VII) at rest or with movement. Lingual movement (XII) and other facial movements may be inferred during conversation if articulation is good. However, a more formal approach often is used in examination. Most examiners start with cranial nerve II in testing; cranial nerve I
(olfactory) testing has infrequent application in emergency medicine.
Cranial nerve II is the optic nerve active in the afferent function of light and visual perception. Common tests for optic nerve function include visual acuity and stimulation for pupillary reactivity. The response to bright light stimulation involves direct and indirect (consensual) pupillary responses.
This is a reflex arc, with the afferent limb being cranial nerve II and the efferent limb of the arc being cranial nerve III, which carries the pupilloconstrictors. A bright light directed into one eye should cause a brisk constriction of equal magnitude in both pupils. In the swinging flashlight test, observe the pupils as the light is slowly moved from one pupil to the other. A seemingly paradoxical dilation of one pupil as the light is moved onto that pupil may indicate optic nerve dysfunction of that eye; this is referred to as an afferent pupillary defect (see Chapter 241, “Eye Emergencies”).
Cranial nerves III, IV, and VI are concerned with extraocular eye movements (see Chapter 241). Tracing an object through a full­H pattern allows assessment of the different cranial nerves. Cranial nerve VI innervates the lateral rectus muscle, which abducts the globe, moving it laterally away from the midline; this lateral movement will be impaired or lost in the case of cranial nerve VI palsy. In fact, the unopposed adduction movement of medial rectus muscle innervated by cranial nerve III may result in the globe being medially deviated. Cranial nerve III innervates the extraocular muscles that adduct each eye and those that elevate and depress the globe. Impairment of cranial nerve III will reveal several abnormalities of extraocular movement, reflecting weakness in the innervated muscles. A complete paresis of cranial nerve III will show a dilated pupil in a globe deviated downward and outward. An isolated cranial nerve IV weakness may be hard to detect; cranial nerve IV supplies the superior oblique muscle that elevates and intorts the globe.
Cranial nerve III also carries the parasympathetic pupilloconstrictors to the eye; a lesion of cranial nerve III may impair those fibers, resulting in unopposed dilatation and a pupil larger than in the unaffected eye. Ptosis from levator muscle paralysis may be another finding of cranial nerve III paresis.
Cranial nerve V has motor and sensory functions. It supplies the muscles of mastication and is assessed by appreciating the masseter bulk. The sensory component of cranial nerve V supplies the cornea; the corneal reflex is a reflex arc involving cranial nerves V and VII. Cranial nerve VII supplies the muscles for facial movement as well as facial proprioception.
Cranial nerve VIII has auditory and vestibular afferent components. Cranial nerves IX and X are tested by observing pharyngeal musculature and gag reflexes. Cranial nerve XI is assessed by a shoulder shrug. Cranial nerve XII controls lingual movement and can be assessed by asking the patient to stick out the tongue and observing for any asymmetry of motion.
ADVANCED
In approximately 20% of the population, some degree of physiologic anisocoria on the order of  to  mm may be present. Small differences in pupillary size in otherwise asymptomatic patients likely represent this normal variant. A peripheral lesion of cranial nerve VII will cause complete facial paralysis on the same side as the lesion (“peripheral VIIth pattern”). A cortical lesion (often stroke) results in weakness of the lower and midface on the opposite side of the injury with preservation of motor function in the upper face (“central VIIth pattern”). This is due to the bilateral cortical upper motor neuron innervation of the forehead musculature present in most patients.
SPECIAL CIRCUMSTANCES
In the comatose patient, a unilaterally dilated pupil that is unreactive or reacts sluggishly to light may represent third nerve dysfunction or paresis from impingement of the oculomotor (III) nerve at the tentorium; this finding is consistent with the uncal herniation syndrome.
Vertigo often is a symptom from a vestibular system dysfunction but may result from a CNS disorder such as posterior circulation stroke. Observe the patient for nystagmus while looking ahead; if nystagmus is present while simply looking ahead, especially if vertical or direction­changing, a central cause of vertigo is likely. If vertical skew gaze is present or is provoked by alternately covering each eye with the patient looking directly ahead, a central cause may also be present.

The horizontal head impulse test (HIT) is a bedside maneuver to detect peripheral vestibular disease. Assess the HIT by rapidly rotating the head to one side then the other while asking the patient to continue to look at a target; normally the vestibular­ocular reflex involuntarily moves the eyes while maintaining visual fixation on the target. With peripheral vestibular problems, the inability to maintain visual fixation during head rotation results in a rapid corrective jerking (saccade) back to the target; this is an abnormal HIT. In patients with acute persistent vertigo from stroke (central cause of vertigo), a normal finding with the HIT (visual fixation maintained, no rapid saccadic movement observed) reliably identified patients with a central cause of acute persistent vertigo. However, an abnormal test (positive saccadic movement observed) occurred in patients with both peripheral and
 central causes of vertigo. Two additional maneuvers were advocated to be used in conjunction with the HIT to reliably exclude central causes of vertigo. Examination for nystagmus and assessment for skew gaze were added to HIT; this was termed HINTS testing (head impulse, nystagmus type,
,5 test of skew). Nystagmus that changes direction with gaze to either side is predictive of a central lesion, as is spontaneous vertical or multidirectional
 nystagmus. Skew deviation refers to misalignment of the eyes. Although subtle at times, it may be unmasked by alternately covering each eye while
 the patient fixes gaze on the examiner. The HIT and HINTS exams have not been extensively analyzed in the ED setting.
SENSORY EXAMINATION
BASIC
The sensory evaluation can be key in some patients with sensory complaints. The primary sensory modalities are light touch, pinprick, position, vibration, and temperature sense. Because of variability in neuroanatomy, at times, dissociation of these modalities occurs and allows localization of problems to anatomic areas within the CNS.
Practically establishing that touch or pinprick is perceived in all extremities is often the only sensory assessment needed in a screening examination.
However, if touch or pinprick is not intact or if peripheral nerve or spinal cord injury is suspected, additional detailed examination is usually necessary.
Position testing is best used for the detection of peripheral neuropathy or posterior column spinal cord disease. Position and vibration sensations are conveyed in the posterior columns of the spinal cord, so that there is no need to test both position and vibration—just test one.
ADVANCED
Spinal cord dermatome levels are illustrated in Figure 164­1. If sensory alteration conforms to a level or selectively involves specific dermatomes, further localization to the peripheral nerve or nerve root may be possible.
FIGURE 164­1. Sensory dermatomes.
If primary sensory modalities are intact, then testing of higher sensory functions may be pursued; these are covered in the section on higher cerebral functions.
SPECIAL CIRCUMSTANCES
A few patterns of sensory loss are worthy of special mention. In cervical spinal cord injury or compression, an area of apparent sensory demarcation often appears to be just above the nipples. This transverse sensory level suggests a spinal cord lesion in the low cervical to high thoracic area. Most cervical dermatomes are represented in the upper extremity and not in the trunk (see Figure 164­1), and further testing is necessary to delineate the sensory level.
With suspected spinal cord injury, test the area of the perineum for sensation. The sacral dermatomes are distributed in an onion skin pattern around the perineum and are represented only in that region. The demonstration of a preserved island of sensation around the perineum may be the only sign of an incomplete spinal cord injury, which has a different prognosis than a complete spinal cord injury.
Some general comments may be made about patterns of sensory alterations. In general, a half­body sensory loss or alteration suggests cortical or subcortical lesions. A localized problem in one limb suggests a peripheral nerve or nerve root problem, although there are other possible locations of
 abnormalities in the CNS.
MOTOR SYSTEM
There is more to evaluation of the motor system than simple assessment of strength. Muscle bulk and muscle tone are basic areas of assessment.
BASIC
Muscle tone may be characterized as normal, decreased, or increased. Assess tone by movement of muscle groups and appreciating any resistance to movement. Ask the patient to relax and not resist. Increased tone is greater than normal resistance to passive motion. Cogwheeling is transient increase or catching in resistance followed by release to the movement. Assess axial or truncal tone by standing behind the patient, grasping the shoulders, and gently moving the shoulders back and forth in a gentle rotation. A patient with normal tone will offer little resistance to repeated motions, and some spontaneous swing of the arms will be noted. A patient with increased axial tone (e.g., Parkinson’s disease) may turn without the arm swing.
Simply having the patient hold the arms outstretched with palms upward and observing for any inward rotation or downward drift is a very sensitive sign for upper extremity weakness (pronator drift); this also may be assessed in unresponsive patients (Figure 164­2). If both arms are held outright at the same time, comparison is easy, with observation of the upper extremity of one side as opposed to the other. A similar maneuver may be performed in the lower extremities. Another sensitive test for a subtle hemiparesis is the forearm­rolling technique. With the forearms outstretched, ask the patient to make tight circles with each arm. The movements should be small and rapid. Asymmetry or slowness with one arm suggests a weak
  limb. Decreased speed of foot tapping also may suggest weakness and an upper motor neuron problem.
FIGURE 164­2. Testing for weakness in the comatose patient; diagram illustrates assessment of muscular tone in a patient with a right hemiplegia. A similar maneuver may be used in the conscious patient.
Tremor can be difficult to characterize, and there are many types of tremor. Action tremors, those that are absent at rest but evident with action or sustained limb position, include those from caffeine, hyperthyroidism, and alcohol or sedative withdrawal. Essential familiar tremor is also an action tremor. Rest tremors characterize Parkinson’s disease, with tremor present during rest, diminishing with willed movement, and then resuming with the new position.
Assessment and recording of other motor strength are best done by description of the stimulus and response. For example, the fact that the patient is able to strongly resist elbow extension or elbow flexion against the examiner is an appropriate notation.
ADVANCED
Compare muscle mass or bulk of the affected area with muscle groups of the unaffected areas. If weakness or paralysis has been present for some time, muscle wasting or atrophy may be present. Brief, rapid twitches of small parts of a muscle may represent fasciculations, which may indicate a process involving the lower motor neurons.
A formal rating scale for muscle strength exists but is not straightforward to apply. A rating of  is assigned for normal strength, and a rating of  indicates weakness and the ability to contract the muscle against some resistance. Thus, a tremendous range of strength is covered within the range of the  rating. A rating of  represents complete paresis, and a rating of  indicates a minimal flicker of contraction. A rating of  is assigned for active movement of a muscle with gravity eliminated by limb repositioning (e.g., so that elbow flexion and contraction are demonstrated by a horizontal rather than by a vertical movement). A value of  is assigned to a muscle able to voluntarily demonstrate full motion against gravity only. It is better for the examiner to describe the strength of a muscle by noting the amount of resistance than by invoking what may be a little­used scale and erroneously applying a rating.
Listings of some muscle innervations, actions to test, and dermatomal representations are found in Tables 164­1 and 164­2. TABLE 164­1
Muscle Innervation: Shoulder and Upper Extremity
Nerve Action to Test Muscle* Long thoracic Forward shoulder thrust Serratus anterior
Dorsal scapular Elevate scapula Levator scapulae
Suprascapular Arm external rotation Infraspinatus; C5, C6
Axillary Abduct arm (>90 degrees) Deltoid; C5
Musculocutaneous Flex and supinate arm Biceps brachii
Ulnar Ulnar flexion of hand Flexor carpi ulnaris; C7, C8,† T1
Flex DIP of fingers  and  Flexor digitorum profundus
Thumb adduction Adductor pollicis; C7, C8†
Abduction of finger  Abductor digitorum minimi
Opposition of finger  Opponens digitorum minimi
Flexion of finger  Flexor digitorum minimi brevis
Finger abduction and adduction Interossei; C8, T1†
Flex PIP and extend DIP of fingers  and  Lumbricals  and 
Median Forearm pronation Pronator teres
Radial hand flexion Flexor carpi radialis; C7, C8, T1
Hand flexion Palmaris longus
PIP flexion of fingers 2–5 Flexor digitorum superficialis
Abduct thumb at the metacarpophalangeal Abductor pollicis brevis
Flex proximal phalanx thumb Flexor pollicis brevis; C7, C8†
Anterior interosseous Flex DIP fingers 2–5 Flexor digitorum profundus (radial)
Flex thumb interphalangeal Flexor pollicis longus
Oppose thumb Opponens pollicis; C8, T1†
Flex PIP and extend DIP of fingers  and  Lumbricals  and 
Posterior interosseous Extension of digits 2–5 Extensor digitorum
Ulnar hand extension Extensor carpi ulnaris
Thumb abduction Abductor pollicis longus
Thumb extension Extensor pollicis longus and brevis
Index finger extension Extensor indicis proprius
Radial Forearm extension Triceps brachii; C6, C7,† C8
Forearm flexion Brachioradialis; C5, C6
Radial hand extension Extensor carpi radialis
Forearm supination Supinator
Abbreviations: DIP = distal interphalangeal joint; PIP = proximal interphalangeal joint.
*Dermatomal representations are listed after some muscles.
†Predominant dermatome.
TABLE 164­2
Muscle Innervation: Hip and Lower Extremity
Nerve Action to Test Muscle* Femoral Hip flexion Iliopsoas; T12, L1,† L2, L3
Leg extension Quadriceps femoris; L2, L3,† L4
Obturator Thigh adduction Pectineus
Adductor longus, brevis, magnus; L2, L3, L4
Gracilis
Superior gluteal Thigh abduction Gluteus medius and minimus
Thigh flexion Tensor fascia lata
Lateral thigh rotation Piriformis
Inferior gluteal Thigh abduction Gluteus maximus
Sciatic (trunk) Leg flexion Biceps femoris; L5,† S1, S2
Semitendinosus
Semimembranosus
Deep peroneal Foot dorsiflexion and supination Tibialis anterior; L4, L5
Toes 2–5 and foot extension Extensor digitorum longus/brevis
Great toe and foot dorsiflexion Extensor hallucis longus
Superficial peroneal Plantar flexion foot and eversion Peroneus longus/brevis; L5, S1
Tibial Plantar flexion and inversion Posterior tibialis
Flex distal phalanx toes 2–5 Flexor digitorum longus
Flex distal phalanx great toe Flexor hallucis longus
Flex middle phalanx toes 2–5 Flexor digitorum brevis
Flex proximal phalanx great toe Gastrocnemius; L5, S1,† S2
Knee flexion and ankle plantar flexion Flexor hallucis brevis
Ankle plantar flexion Plantaris, soleus
Pudendal Voluntary pelvic floor contraction Perineal and sphincters; S3, S4
*Dermatomal representations are listed after some muscles.
†Predominant dermatome.
SPECIAL CIRCUMSTANCES
Although not classically described as part of the motor system examination, information regarding bladder tone and function is at times vital to the examiner. In patients with complaints of incontinence and low back pain, for example, discovery of a probable neurogenic bladder by demonstrating large US­assessed or postcatheterization residual urine volume might be a key to diagnosis of spinal cord compression. What is an abnormal postvoid residual bladder volume is difficult to say with certainty, and the literature is not clear on this point, but in general, a volume of >100 mL, or certainly 200 mL, is cause for concern.
REFLEXES
Muscle stretch reflexes are the least important part of the neurologic examination and offer little value when used in isolation. Correctly termed muscle stretch reflexes, the jerk or involuntary motor movement follows the stretching of muscle spindle fibers by the strike of the reflex hammer and the involuntary muscle contraction that follows. Muscle stretch reflexes serve mainly to confirm evidence collected in other parts of the history or physical examination.
Depending on the force of the reflex hammer strike and local impact factors, an elicited reflex may seemingly change from moment to moment. Make sure the patient and the muscle tested are relaxed. Often several reflex strikes are performed. Record the best response.
BASIC
Muscle stretch reflexes are graded on a scale from  to  that is not rigorously defined, with  representing the absence of reflex,  or  being normal, and  representing hyperactive reflexes. Patterns of reflex abnormalities (e.g., upper vs. lower extremity, left vs. right) may suggest a location of a problem within the CNS or peripheral nervous system.
The Babinski response is observation of the great toe moving upward in response to a mildly noxious stimulation applied to the lateral plantar or lateral aspect of the foot. The application of stimuli should not be hard or forceful. In adults, the normal response of the toe is to move downward to plantar stimulation. The presence of a Babinski’s sign—that is, the abnormal reflex with movement of the great toe upward and perhaps fanning of the other toes—is the classic indicator of an upper motor neuron lesion. The reliability and accuracy of a Babinski’s sign have been called into
 question.
ADVANCED
Clonus is the rhythmic oscillation of a body part, typically the ankle, elicited by a brisk stretch (Figure 164­3). It is one sign of spasticity, in addition to a Babinski response (or slowing of foot tapping), increased muscle tone, and hyperactive muscle stretch reflexes. It may be seen in conditions of metabolic disturbance and primary neurologic dysfunction.
FIGURE 164­3. Method for eliciting ankle clonus.
SPECIAL CIRCUMSTANCES
Disease processes involving upper motor neurons or their processes (cortical or spinal cord injuries) result in hyperactive reflexes, a Babinski response, and clonus. Processes injuring lower motor neurons, their axons, peripheral nerve roots, peripheral nerves, or the muscles themselves may result in hypoactive reflexes. However, in spinal cord injury or stroke, reflexes may take several hours or even days to become hyperactive, so the absence of these signs is not valuable in excluding acute spinal cord injury.
Spinal cord emergencies are high­risk clinical scenarios. Although the presence of a Babinski’s sign and hyperreflexia are cardinal signs of upper motor neuron syndrome, the absence of these signs does not reliably exclude a diagnosis of spinal cord compression; pursue the diagnosis if
,12 historical or other physical examination findings suggest the possibility of this critical diagnosis.
CEREBELLAR TESTING
The cerebellum is concerned with involuntary activities of the CNS and is a structure that helps with smoothing muscle movements and aiding with movement coordination. Very simply, the central cerebellar structures may be thought of as controlling coordination of posture and truncal movements (axial coordination). The lateral cerebellar structures are more coordinated with movements of the extremities (appendicular coordination).
BASIC
Rapidly alternating movements may be assessed by a variety of maneuvers. Hand­slapping tests, asking the patient to rapidly pronate and then supinate the forearm, and slapping the thigh with each movement is a commonly used test. The movements are normally small, and the hand slapping should be symmetric. Rapid pronation and supination of the hands is another test for dystaxia and dysmetria; the movements should be equal with both hands (Figure 164­4).
FIGURE 164­4. Pronation and supination test: cerebellar testing.
ADVANCED
Although usually included in cranial nerve testing, eye movements are useful in assessing cerebellar function, and abnormalities in their movements may suggest cerebellar dysfunction. Tracking an object slowly should show smooth, slow eye movements; breakup of the smooth movement may be evident and is analogous to the decompensation of movements that may occur in isolated cerebellar impairment. Similarly, if a patient is asked to look back and forth between two objects (finger­to­nose testing involves the patient looking back and forth quickly between the examiner’s outstretched finger and nose), the eyes should quickly and conjugately look at the target without overshoot. These faster movements are, at least in part, reflective of intact cerebellar function. Nystagmus is rapid involuntary movements of the eyes that may be present with primary (straight­ahead) gaze or provoked by looking at extremes of gaze. Coarse nystagmus or other abnormalities of eye movements are at times present with cerebellar problems
(see discussion above under cranial nerve testing, or see Chapter 170, “Vertigo,” for more discussion of nystagmus).
GAIT AND STATION
It has been said that, if only one neurologic test could be performed, observation of the patient walking would be the most informative. The posture that the patient assumes when stationary defines the station of the patient. A variety of abnormal gaits and postures are discussed further in Chapter
169, “Ataxia and Gait Disturbances,” as are different techniques of physical examination.
One feature common in many patients with cerebellar hemorrhage is the sudden inability to walk. Keep the possibility of cerebellar injury in mind when evaluating a patient with sudden onset of symptoms that include the inability to walk. Patients with cerebellar hemorrhage may also have severe nausea and vomiting. Their clinical condition is such that fine neurologic examination is simply not possible.
Acknowledgments
The authors would like to acknowledge the work of Dr. Greg Henry and Dr. Hugh S. Mickel, authors of chapters on this topic in previous editions of the study guide. Their chapters served as a check for completeness and provided some tabular information. J. Stephen Huff would like to acknowledge the influence of the late Dr. William DeMyer of Indiana University, whose instruction in the neurologic examination years ago stimulated an interest in this area.


