## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 294: Intimate Partner Violence and Abuse
Cameron Crandall; Sylvia Gonzalez Alden
INTRODUCTION AND EPIDEMIOLOGY
Intimate partner violence includes physical violence, sexual violence, threats of physical or sexual violence, stalking, progressive social isolation, and psychological aggression perpetrated by someone who is, was, or wishes to be involved in an intimate or dating relationship with an adult or
1­3 adolescent individual. These actions are aimed at establishing control by one partner over the other.
Intimate partner violence and abuse is the preferred alternative for previously used terms such as spousal abuse, wife battering, and domestic violence. This term more accurately reflects the fact that this type of abuse occurs not only in adult heterosexual married relationships but also in
 relationships between cohabiting, separated, gay and lesbian, bisexual, and transgender individuals as well as in adolescent dating relationships.
Intimate partner violence and abuse occurs in every racial, ethnic, cultural, geographic, and religious group, and it affects individuals of all socioeconomic and educational backgrounds worldwide. Men are affected, but the overwhelming burden of victimization from intimate partner
,4  violence is borne by women. Intimate partner violence occurs in both opposite sex and same sex relationships. Risk factors for intimate partner violence and abuse include female sex, age between  and  years, low income level of the household, black or multiracial race/ethnicity, bisexual
 sexual orientation, and relationship status of separated rather than divorced or married. Presence of weapons in the home and threats of murder are associated with increased risk of homicide.

Effects extend to family members, friends, coworkers, other witnesses, and the community at large. In families in which either child maltreatment or
 spousal abuse is identified, it is likely that both forms of abuse exist. Children exposed to violence in the home have higher rates of behavioral
 difficulties; mental and health problems including depression, anxiety, abusive behaviors, and drug abuse; and eating, sleeping, and pain problems.
Frequent exposure to violence in the home may normalize violence for children, resulting in higher rates of victimization and perpetration later in
,5 life.
Providers should ask about a history of intimate partner violence or abuse during healthcare encounters. Failure to recognize and intervene in situations of intimate partner violence may have serious consequences for the survivor and family. Such consequences may include continued
,6,7 violence, physical and behavioral health problems, and injury or even death.
CLINICAL FEATURES
Intimate partner violence is often cyclical in nature. The cycle begins with a period of tension building, which may include arguing, blaming, or controlling behaviors or jealousy. The next phase is escalation and may include verbal threats, physical and sexual abuse, or assault. Weapons may be used at this point. Sometimes there may be a “honeymoon” phase in which the perpetrator may apologize or make excuses for inappropriate behavior. Over time, the abusive behavior tends to increase in severity, and the intervals between abusive episodes become shorter.
There are no “usual” features to help identify a victim of intimate partner violence. Health­related consequences of violence or abuse often lead to an
,8,9 ,8
ED visit (Table 294­1). Signs suggestive of intimate partner violence and abuse are summarized in Table 294­2. TABLE 294­1
Health Consequences of Intimate Partner Violence
Adults Adolescents Children

Chapter 294: Intimate Partner Violence and Abuse, Cameron Crandall; Sylvia Gonzalez Alden 
©2025I nMjucriGesraw Hill. All Rights ReSsaemrvee ads. f o rT aedrmultss of Use * Privacy Policy * Notice * AccessLoibwil ibtyirth weight
Alcohol and substance plus Prematurity and associated complications abuse Victimization as an adult Failure to thrive
Sexually transmitted Fertility problems Parental neglect syndrome infections Poor school performance and school dropout Speech disorders
Human immunodeficiency Unwanted pregnancy and associated complications of Bedwetting virus infection pregnancy, frequent pregnancies Headaches
Pelvic inflammatory Obesity Cognitive functioning problems—lower verbal and disease Behavioral disorders quantitative skills
Urinary tract infections Involvement with the legal system and courts Psychological and emotional problems—aggression,
Vaginal bleeding Risky sexual behaviors hostility, withdrawal, acting out
Unintended pregnancy Prostitution Child abuse
Headaches Alcohol and drug use
Chronic pelvic pain
Back pain
Eating disorders
GI disorders
Depression
Anxiety disorders
Difficulty sleeping
Posttraumatic stress disorder
Substance abuse
Homelessness
Social isolation
Suicide
Death
TABLE 294­2
Signs Suggestive of Intimate Partner Violence
Findings Comments
Injuries characteristic of violence Fingernail scratches, broken fingernails, bite marks, dental injuries, black eyes, broken bones, cigarette burns, bruises suggesting strangulation or restraint, and rope burns or ligature marks may be seen.
Injuries suggesting a defensive posture Forearm bruises or fractures may be sustained when individuals try to fend off blows to the face or chest.
Injuries during pregnancy Up to 45% of women report abuse or assault during pregnancy.10
Preterm labor, placental abruption, direct fetal injury, and stillbirth can occur.
Central pattern of injury Injuries to the head, neck, face, and thorax, abdominal and genital injuries.
Extent or type of injury inconsistent with Multiple injuries at different anatomic sites inconsistent with the described mechanism of injury.
the patient’s explanation The most common explanation of injury is a “fall.”
Embarrassment, evasiveness, or lack of concern with the injuries may be noted.
Multiple injuries in various stages of These may be reported as “accidents” or “clumsiness.” healing
Delay between the time of injury and the Victims may wait several days before seeking medical care for injuries.
presentation for treatment Victims may seek care for minor or resolving injuries.
Visits for vague or minor complaints Frequent ED visits for a variety of injuries or illnesses, including chronic pelvic pain and other chronic pain without evidence of physiologic syndromes.
abnormality
Suicide attempts Women who attempt or commit suicide often have a history of intimate partner violence.10
Signs of abuse may be suspected by behavior of the partner. The abusive partner may be defensive, hostile, and aggressive, and might demonstrate
 controlling or overly solicitous behavior toward the patient. The patient may appear frightened of the partner or refuse to answer questions and instead defer all responses to the partner. In situations raising concern, and if the patient agrees, hospital security can prevent the alleged perpetrator from visiting the patient in the ED and hospital.
SCREENING AND ASSESSMENT
Many experts, including the U.S. Preventive Services Task Force and the American College of Emergency Physicians, recommend routine screening for intimate partner violence for all adolescent and adult women who present to the ED and for mothers of children brought to the ED. Futures Without

Violence has published national screening consensus guidelines. Because of the known adverse long­term impacts of intimate personal violence on health, when time permits, consider screening for lifetime exposure.
A protocol should be implemented that addresses identification of, and screening for, intimate partner violence; training of ED personnel; 
,9,11 interviewing; and appropriate interventions, including validation and referral.
Multicultural and multilingual information about intimate partner violence and effects on abused individuals and family members should be made available to the public and employees. This may consist of posters and/or brochures in areas of the hospital such as public areas, examination rooms, and restrooms. Community resources that provide services to victims should be a part of the shared information.
Screening should be conducted by providers educated about the dynamics of intimate partner violence. Provide a safe and private environment for the interview. Take into account cultural differences and expectations. If language interpreters are required, use individuals who have no connection to the patient. Document screening results, safety assessment, and any interventions, including referrals and required reporting. Screening guidelines
  for adolescent and adult patients are summarized in Table 294­3. Sample verbal screening questions are listed in Table 294­4. The U.S. Preventive

Services Task Force has published a review of a variety screening tools.
TABLE 294­3
Summary of National Consensus Guidelines for Screening for Intimate Partner Violence and Abuse in the ED9
Screening Assessment Intervention Documentation Referral and Follow­Up
Routinely screen at Assess immediate safety. Listen carefully and Legible, fluent; maintain Refer to primary care physician, every visit. Assess health impact of provide support. ity of records mental health provider, social
Screen for current abuse. “I’m concerned for Abuse history: worker, or intimate partner abuse, and if time Assess pattern of abuse. your health and Subjective information: Patient’s abuse advocate.
allows, screen for Assess for danger and safety.” own words Obtain permission to notify history of abuse. potential lethality. “You are not alone.” Objective information: Detailed provider.
Screen privately (one If the danger assessment “Help is available.” description of patient’s appearance, Know current phone numbers on one) or with findings are positive, “It is not your fault.” behavioral indicators, injuries, and for: nonrelated trained assess potential for “You don’t deserve health complaints Abuse and assault prevention interpreter. suicide and homicide. it.” Use of forensic evidence kits where programs
Ask: What happened? “What happened to appropriate Legal services
When did it happen? you can affect your Results of physical examination Children’s programs
Where did it happen? health.” Use of body maps Mental health services
Who did this? Provide information Photographs (with patient’s consent) Law enforcement
Respect patient and materials. Radiologic, laboratory findings, Substance abuse programs decision to disclose or “What can I do for collection of forensic evidence: Transportation not. you?” clothes, debris, etc. Local clergy or other
Discuss any required Provide a safety Any materials and referrals offered community organizations reporting. plan. Results of health and safety
Include screening Offer services, assessments questions on intake including an forms. advocate, social worker, police, shelter, etc.
TABLE 294­4
Sample of Intimate Partner Violence Screening Questions* The healthcare worker should explain the following in his or her own words:
We are concerned about your health and safety, so we ask all patients the same questions about violence at home and personal life.
Violence is very common, and we want to improve our response to individuals and families experiencing violence.
The healthcare worker may ask the following questions of ALL patients:
Are you ever afraid of your partner?
In the last year, has your partner hit, kicked, punched, or otherwise hurt you?
In the last year, has your partner put you down, humiliated you, or tried to control what you can do?
In the last year, has your partner threatened to hurt you?
If intimate partner violence has been identified in any of the above questions, ask if the individual would like assistance today. Be prepared to offer resources, assess for safety, and discuss a safety plan with the individual.
*Additional screening tools are available.2,9
When conducting screening and assessment, be nonjudgmental, sensitive, and direct. Let the patient know that you take the situation seriously.
Assure victims of ity. Communicate an understanding of the complexity of the situation and the difficulties of achieving a “quick fix.”
Reassure the victim that no one deserves abuse and victims are not at fault. It is the abuser whose behavior is unacceptable. Avoid pressuring, respect
 patient decisions, and work together to determine an appropriate course of action. Ask abused individuals if they have suicidal or homicidal ideation. Such ideation, particularly if accompanied by a concrete plan of action, should trigger immediate consultation with a mental health provider.
RISK ASSESSMENT AND DISPOSITION
Ensuring the safety of the abused individual and children is the foremost goal. The most dangerous periods for abused individuals are during the time of abuse disclosure and during attempts to leave the relationship. Indicators of a high­risk and potentially lethal situation include escalation in the frequency or severity of violence; the threat or actual use of weapons; obsession with the abused individuals; hostage taking; stalking; strangulation; and homicide or suicide threats or attempts and evidence of violent behavior
,8 outside the home. Another risk factor for serious injury or death is substance abuse by the perpetrator, which can increase violent behaviors.

If lethality risk is high, consult with experts before ED discharge. Hospital admission of the abused individual or children is an option in high­risk situations in which there is no other way to ensure safety. Use of a 24­hour safe room, a location established by some hospitals and communities to provide a safe place for the patient to stay while arrangements for safe disposition of the patient and family members are made, is another option. Use of an alias name on admission and screening of incoming phone calls may also be of benefit.

Some individuals feel safer remaining in the violent relationship than leaving without adequate planning for a safe departure. Placing the patient in a shelter or having the attacker arrested may not be congruent with the individual’s goals. Ultimately, the abused individual must decide if it is safe to return home. By providing information about intimate violence, risks, and options, the ED provider can help the patient decide what is best. The patient’s decision making may be very complex, because depression, lack of self­esteem, lack of support, social isolation, financial dependence on the perpetrator, and fear make it difficult to leave the relationship.
Refer individuals to intimate violence experts, such as trained hospital social workers or community­based advocates, who can help the victim assess the situation, understand options, plan for safety, and arrange safe shelter. Community advocates are typically on call or available by telephone. If the patient can be safely discharged from the ED and personal contact with an advocate cannot be made before discharge, give the patient up­to­date information about available services in the community. Intimate personal violence advocates should not be asked to call the patient directly unless the patient agrees, because calls to the home could jeopardize the patient’s safety.
Resources for healthcare providers to assist in preparing their practices for optimal response to victims of intimate personal violence are available from a number of organizations (Table 294­5). Table 294­6 lists hotlines for patients.
TABLE 294­5
Resources for Healthcare Providers
Futures Without Violence (formerly Family Violence Prevention Fund) http://www.futureswithoutviolence.org
National Domestic Violence Hotline http://www.thehotline.org/
800­799­SAFE (7233)
National Coalition Against Domestic Violence http://www.ncadv.org
TABLE 294­6
Hotlines for Patients
National Domestic Violence Hotline:  h; links caller to help in her (or his) area—emergency shelter, domestic violence shelters, 800­799­SAFE (7233) legal advocacy and assistance programs, social services
800­787­3224 (TTY)
Rape, Abuse, and Incest National Network:  h; automatically transfers caller to nearest rape crisis center anywhere in the nation 800­656­HOPE (4673) http://www.rainn.org
ED RECORD DOCUMENTATION
Voluntary descriptions of intimate personal violence should be quoted and described in the patient’s own words. Do not use the word alleged because
 it implies that the person recording the incident does not believe the complaint. A complaint of “sexual assault” is no more alleged than is a complaint of “ear pain” or a “sore throat.”
Record past and current abuse, with details of date, time, location, witnesses, and specific injury. Describe the patient’s health complaints, injuries, appearance, and demeanor. Annotated body maps and photographs can supplement written notes.
Obtain relevant forensic evidence, and follow the appropriate chain of custody of evidence. If sexual assault has occurred, document ED testing and treatment; arrange for a sexual assault nurse examiner exam, if locally available. See Chapter 293, “Female and Male Sexual Assault,” for detailed discussion.
Record safety assessment and planning. A safety assessment form or referral notes from an expert are helpful adjuncts.
LEGAL CONSIDERATIONS
Most states in the United States have laws that require healthcare providers to report specified injuries, wounds, or crimes. Intimate personal violence
 is a crime in all  states. Four states have exceptions to mandatory reporting for injuries related to domestic violence. The specifics of the reporting requirements vary from state to state, and the adequacy of response by the police to reporting varies by jurisdiction. Inadequate or inappropriate response to the reports (e.g., informing the perpetrator of the report without providing for the safety of the abused individual) can increase the risk of harm to the abused. Inform the victim if there is an obligation to make a police report and explain possible ramifications.
SPECIAL POPULATIONS
PREGNANCY
,8
Prevalence of intimate partner violence during pregnancy ranges from 6% to 22%. Women who report intimate partner violence and abuse during pregnancy are at increased risk of postnatal abuse. Women assaulted during pregnancy are three times more likely to be admitted to the hospital than
 nonpregnant women.
IMMIGRANT POPULATIONS
Overall, prevalence of intimate partner violence is lower in people born outside of the United States. However, certain immigrant populations have
,14 rates far higher than U.S. natives. Moreover, the burden of intimate partner violence can be much higher in these populations as victims may be
 socially and linguistically isolated and perpetrators can use threats of deportation to restrain victims from seeking help. The federal Violence Against
Women Act establishes protection that may protect undocumented persons from deportation if they have been a victim of crime, including intimate partner violence.
LGBTQ PERSONS
Intimate partner violence occurs in same sex relationships at rates generally similar to opposite sex relationships. Bisexual women and men, however,
 report substantially higher rates of intimate partner physical violence overall. Transgender women and gender nonconforming persons also experience intimate partner violence at higher rates. Lesbian, gay, bisexual, transgender, and queer persons may not report to police or seek advocacy
 services for fear of discrimination.
Acknowledgment
The authors gratefully acknowledge the contributions of Mary Hancock, the author of this chapter in the previous edition.


