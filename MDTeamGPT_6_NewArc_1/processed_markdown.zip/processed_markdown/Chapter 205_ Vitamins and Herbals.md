## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 205: Vitamins and Herbals
Michael Levine
INTRODUCTION
Vitamins and herbal preparations, particularly those sold in health food stores, are considered by many to be innocuous but may have potential toxicity, especially when taken in excessive amounts over a period of time. Also, herbal preparations may contain toxic contaminants that can cause poisoning.
VITAMINS
Hypervitaminosis from the fat­soluble vitamins A, D, E, and K can produce subacute toxicity (after days to a few weeks) or chronic toxicity (after weeks to months of excessive ingestion). Of the water­soluble vitamins, niacin, pyridoxine, and ascorbate are associated with toxicity (Table 205­1).
TABLE 205­1
Clinical Features of Hypervitaminosis
Vitamin Symptoms
Vitamin A Subacute toxicity: red peeling rash, headache, and vomiting.
Chronic toxicity: blurred vision, appetite loss, abnormal skin pigmentation, hair loss, dry skin, pruritus, long­bone pain, bone fractures, liver failure, pseudotumor cerebri, and hypercalcemia.
Vitamin D Subacute toxicity: hypercalcemia, anorexia, nausea, abdominal pain, lethargy, weight loss, polyuria, constipation, confusion, and coma.
Vitamin E Chronic toxicity: coagulopathy in patients on warfarin, nausea, fatigue, headache, weakness, and blurred vision.
Vitamin K Acute toxicity: anaphylactoid reactions if given rapidly in the parenteral form (rare). Interferes with warfarin, resulting in subtherapeutic coagulation.
Vitamin B No toxicity observed with ingestion of large doses.

(thiamine)
Vitamin B No toxicity observed with ingestion of large doses.

(riboflavin)
Vitamin B Acute toxicity: “niacin flush” (redness, burning, and itching of the face, neck, and chest). Hypotension a rare possibility.

Chronic toxicity: Abnormalities of liver function, impaired glucose tolerance, hyperuricemia, skin dryness, and discoloration.
(niacin)
Vitamin B Subacute and chronic toxicity: peripheral neuropathy with unstable gait, and marked loss of position and vibration senses.

(pyridoxine)
Vitamin B No toxicity observed with ingestion of large doses. With large IV doses: erythema of skin, mucous membranes, serum, and urine. Rare
 anaphylactoid reactions. Possible interference with serum colorimetric lab studies.

Chapter 205: Vitamins and Herbals, Michael Levine 
Folate No toxicity observed with ingestion of large doses. Masking of macrocytic anemia from vitamin B deficiency with large doses of folate.

. Terms of Use * Privacy Policy * Notice * Accessibility
Vitamin C Chronic toxicity: nephrolithiasis (controversial), intrarenal deposition of oxalate crystals with renal failure; large doses can produce
(ascorbate) diarrhea and abdominal cramps.
VITAMIN A
Dietary vitamin A is present in two forms: preformed vitamin A (retinol and retinyl palmitate [an ester] from animal sources) and provitamin A
(carotenoids) found in plants. After ingestion, the ester form is hydrolyzed in the GI tract to retinol. Retinol is then absorbed into intestinal mucosal cells, where it then combines with a fatty acid to again become a retinyl ester. Carotenoids are dark­colored compounds found in plants. β­Carotene is the carotenoid most efficiently converted to retinol by duodenal mucosal cells. The recommended daily allowance (RDA) for preformed vitamin A

(retinol) is 900 micrograms (3000 IU) for adolescents and adult men, and 700 micrograms (2400 IU) in adult women. The liver contains approximately
95% of body vitamin A stores.
Vitamin A forms part of the visual pigments of the retina (rhodopsin and iodopsin), is important for the formation of mucus­secreting cells in the columnar epithelium, maintains bone growth, and maintains cellular membrane stability.

Hypervitaminosis A is usually due to excessive supplement use, although there have been case reports of acute toxicity due to ingestion of mammal
 organs (e.g., fish liver). There is variability among patients in the amounts necessary to develop hypervitaminosis; for example, it is much more
 common in children with chronic kidney disease who take supplements compared to those not on supplements. The minimum dose that may cause toxicity in humans is not established.
Symptoms of hypervitaminosis A include blurred vision, appetite loss, abnormal skin pigmentation, loss of hair, dry skin, pruritus, long­bone pain, and an increased incidence of bone fractures. Rarely, hypervitaminosis A can result in pseudotumor cerebri, hypercalcemia, and hepatic
 failure. The treatment of hypervitaminosis A includes discontinuation of the vitamin and supportive care.
β­Carotene, a provitamin A, does not cause hypervitaminosis. In diabetic patients and patients with hypothyroidism, however, large doses of β­ carotene can cause a yellowish discoloration of the skin, which fades once β­carotene is stopped. This phenomenon is occasionally seen in infants and toddlers who consume large amounts of carrots and other pigmented vegetables.
Vitamin A deficiency can result in anemia, numerous ocular symptoms, and immune suppression with subsequent increased risk of infection. Young
 children and pregnant women are some of the groups at highest risk of developing vitamin A deficiency.
VITAMIN D
Dietary vitamin D is ingested as a provitamin, either ergocalciferol (vitamin D ) or cholecalciferol (vitamin D ); both forms are essentially bioequivalent.

These provitamins are then converted to calcitriol (1,25­dihydroxycholecalciferol), the physiologically active form of vitamin D. The major function of calcitriol is to elevate plasma calcium and phosphorus levels, enabling normal bone mineralization.

The RDA for vitamin D is  micrograms (600 IU) for adults, with therapeutic doses sometimes exceeding 125 micrograms (5000 IU) daily. Patients at
,9 the extremes of age are at higher risk for toxicity, as are those on supplementations. Prolonged exposure to vitamin D may result in hypercalcemia,
 hypercalciuria, and hyperphosphatemia. However, the primary symptoms of hypervitaminosis D relate to hypercalcemia and include anorexia, nausea, abdominal pain, lethargy, weight loss, polyuria, constipation, confusion, and rarely, coma.
Treatment of hypervitaminosis D includes discontinuation of vitamin D, reduction of the calcium intake, and reduction of serum calcium levels. IV hydration, calcitonin, and bisphosphonates can be used in the management of hypercalcemia. Vitamin D deficiency may result in rickets and osteomalacia.
VITAMIN E
There are eight unique, fat­soluble, naturally occurring alcohols (called tocopherols and tocotrienols) that possess vitamin E activity, with d­α­ tocopherol the most active form. Because it is rapidly oxidized, α­tocopherol protects other molecules from being oxidized and thus is termed an
 antioxidant. Foods high in vitamin E include wheat germ, corn, soybean, sunflower seed, almonds, peanuts, spinach, and broccoli.

The RDA for vitamin E is  milligrams (22.4 IU) for adults. Vitamin E is thought to be nontoxic at daily doses of up to 400 milligrams (600 IU). With daily
 doses greater than 670 milligrams (1000 IU) taken for a long time, vitamin E has the ability to antagonize the effects of vitamin K, specifically acting as a competitive inhibitor of vitamin K–dependent γ­carboxylation. In addition, through the production of thromboxane, high levels of vitamin E inhibit platelet aggregation. Thus, patients on warfarin therapy are at risk for bleeding, whereas it is rare for patients not on warfarin to bleed from large
 amounts of vitamin E. Patients on tamoxifen or cyclosporine may also have drug–nutrient interactions at high doses of vitamin E. Other effects in
 adults who take large doses for a long period of time include nausea, fatigue, headache, weakness, and blurred vision. These symptoms resolve weeks after discontinuation of the vitamin.
VITAMIN K
Vitamin K activity is found in several compounds of varied origin: phylloquinone or vitamin K , which is naturally produced by plant sources;
 menaquinone or vitamin K , which is produced by bacterial sources; and menadione or vitamin K , a synthetic chemical that is a vitamin precursor of
  vitamin K . Because large doses of menadione are toxic, the use of menadione supplements is banned in the United States for human use but can still
 be found in animal feed.
The GI absorption of vitamin K requires the presence of bile and pancreatic juice, with between 10% and 80% of ingested vitamin K being absorbed. It is thought that most of the vitamin K used in the body is derived from plant sources (K ). Furthermore, if one has an adequate dietary intake of vitamin K ,

 eradication of the gut bacteria will not lead to a deficiency of vitamin K. In contrast to the other fat­soluble vitamins, vitamin K is not stored in the body to any significant extent. Vitamin K deficiency is uncommon because the normal American diet contains vitamin K substantially in excess of the

RDA, which is 120 micrograms in adult men and  micrograms in adult women.
Vitamin K is required for the production of six factors involved in the coagulation cascade: factors II, VII, IX, and X, along with proteins C and S. Warfarin inhibits vitamin K activity, thereby producing a coagulopathy.
The main concern about vitamin K toxicity is the adverse reactions seen with the IV form. The only recommended form of vitamin K for both oral and parenteral use is K . Because vitamin K is fat soluble, it is given parenterally in a lipid­soluble form. Historically, rates of anaphylactoid

 reactions were more common due to a different colloidal suspension. With current preparations, anaphylactoid reactions to IV vitamin K occur at a
 rate of .03% (3 per ,000). Absorption of IM vitamin K is erratic, and absorption from SC administration is relatively ineffective, whereas PO
 absorption is reliable and effective. Thus, vitamin K should be administered orally when feasible or intravenously for life­threatening hemorrhage or in cases where absorption from the GI tract is questionable.
Toxicity from oral vitamin K is rare, although daily doses exceeding 500 micrograms are associated with skin rashes.
VITAMIN B (THIAMINE)

Vitamin B , or thiamine, is converted by the body to thiamine pyrophosphate, which acts as a cofactor for several metabolic reactions, including
 transketolations. Food sources of thiamine include fruits, grain, meats, fish, and milk, among others.
Intestinal absorption of thiamine is greatest in the jejunum. Thiamine is not stored in the body to any significant extent. Because of renal excretion
(water solubility), there is no toxicity to the ingestion of large doses of thiamine over prolonged periods. The RDA for thiamine is .2 milligrams in adult
 men and .1 milligrams in adult women.
Historically, there was concern about the ability of thiamine to precipitate Wernicke’s encephalopathy if glucose was not administered prior to the
 thiamine. There are no clear data to support that theory, and IV glucose is unlikely to precipitate Wernicke’s encephalopathy in patients with altered mental status. Thiamine supplementation prior to glucose administration is not required.
Rarely, IV thiamine may precipitate anaphylactoid reactions. This event is likely related to the diluent and contaminants, as the current pure aqueous
 forms of thiamine for IV use very rarely result in anaphylactoid adverse reactions. Therefore, IV use of thiamine is both safe and clinically efficacious.
Conversely, PO and IM thiamine is absorbed unpredictably in the emergency setting.
Thiamine deficiency may result in beriberi, which is characterized by anorexia, weight loss, and neuropathy. In addition, thiamine deficiency can result in Wernicke’s syndrome or Korsakoff’s psychosis. Wernicke’s syndrome is characterized by confusion, ataxia, and ophthalmoplegia,
 whereas Korsakoff’s psychosis is characterized by confusion, confabulations, and psychosis.
VITAMIN B (RIBOFLAVIN)

The RDA for riboflavin is .3 milligrams in adult men and .1 milligrams in adult women. Riboflavin is excreted through the urine, and toxicity has not
 been reported regardless of the amount ingested.
VITAMIN B (NIACIN)

There are two active forms of niacin—nicotinic acid and nicotinamide—which, in conjunction with thiamine and riboflavin, function as coenzymes in energy metabolism. Niacin becomes part of the coenzymes nicotinamide­adenine dinucleotide and nicotinamide­adenine dinucleotide phosphate; both are required in all major metabolic pathways where there is oxidative breakdown of amino acids, fatty acids, and other compounds, including the oxidation of ethanol.
Niacin is found primarily in poultry, meat, and fish, with lesser amounts in plants. The RDA for niacin is  milligrams for adult men and  milligrams
 for adult women.
Nicotinic acid in the range of  to  grams per day lowers serum cholesterol and β­lipoprotein, but nicotinamide does not. Large niacin doses can also deplete cardiac muscle glycogen and can cause liver toxicity. Some patients experience a frightening “niacin flush” when taking a dose of >100 milligrams. The niacin flush, caused by prostaglandin D and E release with subsequent vasodilation, is characterized by face, neck,

  and chest burning, itching, and erythema. Rarely, hypotension may occur. The use of aspirin before or at the time niacin is consumed
 may reduce the prevalence of niacin­induced flushing. Higher niacin doses may additionally cause nausea, abdominal cramping, diarrhea, and headache. Extremely high doses of niacin for a prolonged period may produce abnormalities of liver function, impaired glucose tolerance, hyperuricemia, and skin changes such as dryness and discoloration. These subacute and chronic symptoms resolve within days to weeks after stopping treatment.
Niacin deficiency can result in pellagra, which is characterized by dermatitis, diarrhea, and dementia.
VITAMIN B (PYRIDOXINE)

Vitamin B is a necessary cofactor for many enzymatic processes. The active form of pyridoxine is pyridoxal­5­phosphate, which serves as a cofactor for

 the formation of γ­aminobutyric acid. The RDA for vitamin B is .3 milligrams for adults aged  to  years.

Chronic administration of high doses of pyridoxine may result in peripheral sensory neuropathy, and sometimes with autonomic and motor nerve impairment. After withdrawal of the vitamin, recovery occurs within several months, although some patients may have residual neurologic impairment.

There is no evidence that a single 5­gram IV dose of pyridoxine will cause any type of nerve damage.
Vitamin B also can cause intestinal inactivation of levodopa in patients receiving that medication for Parkinson’s disease. Tell
 patients not to take this vitamin at the same time as the medication.
Pyridoxine deficiency primarily manifests as seizures. The deficiency can be congenital or acquired (e.g., decreased γ­aminobutyric acid production as a result of isoniazid or hydrazines). In addition, anemia (caused by impaired synthesis of heme), xanthurenic aciduria (as a result of reduced formation of hydroxyanthranilic acid), cystathioninuria (as a result of decreased cleavage of cystathionine to cysteine and homoserine), and homocystinuria (due to impaired formation of cystathionine) may result.
VITAMIN B (CYANOCOBALAMIN)

Due to the size and complexity of the vitamin B molecules, deficiencies of this water­soluble vitamin result more from absorption problems than from

 dietary insufficiencies. Absorption depends on the production of intrinsic factor by the parietal cells of the stomach. Vitamin B –intrinsic factor
 complexes are initially formed in the stomach. The complexes pass to the ileum, where the intrinsic factor attaches to the intestinal epithelium, facilitating the absorption of the vitamin B . Vitamin B is stored in the liver in such quantities that it takes several years for pernicious anemia to

 develop in an individual who is a strict vegetarian and ingests little B or in someone unable to produce intrinsic factor. Dietary vitamin B12 is

 primarily obtained from animal sources. The RDA for vitamin B is .4 milligrams in adults.

Until recently, it was believed that vitamin B had a wide therapeutic index for harm. With the advent of the use of the vitamin B precursor,
  hydroxocobalamin, as an antidote for cyanide poisoning, there have been a few case reports of direct vitamin B toxicity. These cases are

 characterized by erythema of the skin, mucous membranes, urine, and serum. Rare cases of anaphylactoid reactions have also been reported.

Hydroxocobalamin can also interfere with colorimetric lab tests, including those that test for carbon monoxide.

Vitamin B deficiency can result in hematologic, neurologic, and psychiatric effects. The common hematologic disorders include megaloblastic
 anemia and pancytopenia. The neurologic disorders commonly observed include paresthesias, peripheral neuropathies, and dorsal spinal cord column demyelination. Psychiatric symptoms include depression, dementia, and psychosis.
FOLATE
Folate, or folic acid, is essential for the production of DNA, RNA, and proteins. Folate is found in fresh leafy green vegetables, yeasts, and liver. After
 ingestion, folate is actively absorbed in the small and large intestine. The RDA for folate is 400 micrograms in adults.
Both deficiencies of vitamin B and folate can result in megaloblastic (macrocytic) anemia. Large doses of folic acid given to an individual with an
 undiagnosed vitamin B deficiency could correct megaloblastic anemia, but leave the individual at risk of developing irreversible neurologic damage.

Such cases of neurologic progression in vitamin B deficiency have been mostly seen at folate doses of  milligrams and above.

VITAMIN C (ASCORBATE)
The major form of vitamin C, ascorbate or ascorbic acid, is a strong reducing agent that participates in hydroxylation reactions such as those necessary for the formation of collagen. Vitamin C, which is found primarily in fruits and vegetables, is absorbed through the jejunum and ileum. The RDA for
 vitamin C is  milligrams in adult men and  milligrams in adult women.

Chronic high­dose ascorbate ingestion has been reported to cause renal failure due to intrarenal deposition of oxalate crystals. Large doses of vitamin C may produce diarrhea and abdominal cramps, which subside with discontinuation. Limited data suggest that vitamin C in doses exceeding

1000 milligrams may result in false­negative guaiac testing for fecal occult blood.
Scurvy is due to vitamin C deficiency and results in collagen, protein, and lipid metabolism abnormalities. In addition, the presence of vitamin C in the intestines increases the absorption rate of iron, so those with a vitamin C deficiency will also be iron depleted.
HERBAL OR BOTANICAL DIETARY AGENTS

Herbal preparations have long been used by traditional cultures, and their use appears to be increasing in developed countries. In developed countries, herbal preparations have been looked upon as a natural and inexpensive alternative to common Western pharmaceuticals. However, studies funded by the National Center for Complementary and Alternative Medicine have not supported the use of herbal medications for treatment of
    depression (St. John’s wort), dementia (Ginkgo biloba), prostatic hypertrophy (saw palmetto), osteoarthritis (glucosamine and chondroitin),
 and the common cold (Echinacea). There is also a false belief that because herbal products are “natural” that they must be “safe.”

Because herbal products are classified as dietary supplements by the Dietary Supplemental Health and Education Act of 1994, the U.S. Food and Drug
Administration does not have authority to require testing for safety and effectiveness before marketing. However, since 2007, the Food and Drug

Administration has required that manufacturers guarantee the identity, purity, strength, and composition of their dietary supplements. The Food and Drug Administration can restrict sales or remove a supplement from the market if it is proven to be potentially unsafe or harmful. Herbal agents
49­52 can be classified as generally safe, potentially toxic, or toxic (Table 205­2). Many herbal agents have specific liver, eye, and cardiovascular
53­58 toxicities.
TABLE 205­2
Some Generally Safe Herbal Supplements or Agents
Agent General Use Rare Adverse Effect
Chamomile Antispasmodic Anaphylaxis if patient allergic to ragweed
Chondroitin To treat arthritis May cause GI upset
Echinacea To treat or prevent upper respiratory or urinary Anaphylaxis if patient allergic to daisies tract infections May deplete vitamin stores
Feverfew To prevent migraines Suddenly discontinuing may precipitate migraine
If chewed, may cause mouth sores
If applied to skin, may cause dermatitis
Garlic To treat hypertension, colic, and hyperlipidemia Hypotension, rash, nausea, vomiting, diarrhea; death has been reported in massive doses in children
Ginkgo To treat dementia, vertigo, and Raynaud’s disease May inhibit platelet aggregation and interact with warfarin
May cause GI upset
Ginseng To treat impotence, fatigue, ulcers, and stress May interact with warfarin
Lowers blood glucose
May cause insomnia, nervousness
Glucosamine To treat arthritis Allergic reaction
Kava Used for sedation and to relieve sore throat pain Hepatotoxicity
St. John’s To treat depression Phototoxicity wort May interact with serotonin reuptake inhibitors; avoid tyramine­containing foods
Valerian Used for sleep and sedation Interacts with other sedating drugs
May have paradoxical stimulant effect
Although herbal preparations can cause direct toxicity from the herb itself, it is much more common that the patient becomes ill from the
 contamination, misuse, overuse, or misidentification of the herbal preparation. Herbal preparations can cause either direct toxicity (Table 205­3) or
 60­64 indirect toxicity from herb–drug interactions (Table 205­4). Reported contaminants in herbal preparations include lead, selenium, and cyanide.
TABLE 205­3
Some Potentially Toxic Herbal Supplements or Agents
Agent General Use Adverse Effect
Black cohosh To delay or treat menopause Nausea, vomiting, dizziness, weakness
Chaparral (creosote Antioxidant effects, analgesia Potentially hepatotoxic and nephrotoxic bush)
Comfrey Bone and teeth building, variety of other Potentially hepatotoxic uses
Ephedra Weight loss Hypertension; contraindicated for patients with hypertension, diabetes, or glaucoma
Hawthorn Congestive heart failure Additive toxicity with prescribed cardioactive steroids
Juniper Diuretic Hallucinogenic; may also cause renal toxicity, nausea, and vomiting
Lobelia As an expectorant or for treatment of Anticholinergic syndrome asthma
Nutmeg Dyspepsia, muscle aches, and arthritis Hallucinations, GI upset, agitation, coma, miosis, and hypertension
Pennyroyal Rubefacient, delaying menses, Hepatotoxicity abortifacient
Pyrrolizidine alkaloids Pulmonary ailments Hepatic veno­occlusive disease
Wormwood Dyspepsia Absinthism: restlessness, vertigo, tremor, paresthesias, delirium
Yohimbe Aphrodisiac Hallucinations, weakness, hypertension, and paralysis
TABLE 205­4
Some Likely Herb–Drug Interactions
Herb Herb Used For Drug Effect of Interaction
Cayenne Arthritis, neuralgia, analgesic Angiotensin­converting enzyme Increased cough
(Capsicum) inhibitors Increased absorption
Theophylline sustained­release
Dan shen Reduction of lactation Warfarin Decreased warfarin metabolism
(Salvia)
Ephedra Energizer, weight loss, asthma, Monoamine oxidase inhibitors Increased toxicity sinus congestion Sympathomimetics Additive effect
Ginkgo Dementia, peripheral arterial Aspirin Increased risk of bleeding disease, tinnitus Warfarin
Grapefruit juice For vitamin C activity Amiodarone Increased drug availability of any one of these drugs
Benzodiazepines because of inhibition of intestinal CYP3A4
Calcium channel blockers
Carbamazepine
Clomipramine
Cyclosporine
Dextromethorphan
Ethinyl estradiol
3­Hydroxy­3­methyl­glutaryl­coenzyme
A reductase inhibitors (“statins”)
Phosphodiesterase type  inhibitors
(erectile dysfunction drugs)
Quinidine
Sertraline
Kava Sedative/anxiolytic Caffeine Increased levels from inhibition of CYP1A2
Fluvoxamine
Theophylline
Licorice in Respiratory disorders, hepatitis, Antihypertensives Decreased effect (can cause chronic, high inflammatory diseases, infections Diuretics pseudohyperaldosteronism by inhibiting 11­β­ doses Prednisolone dehydrogenase)
Increased potassium loss, myopathy
Increased drug levels
St. John’s wort Depression Cyclosporine Decreased serum levels; transplant rejection
Digoxin Decreased serum level
Indinavir Decreased serum level
Yohimbine Erectile dysfunction, sexual potency Clonidine Decreased effect
Cyclic antidepressants Enhanced autonomic and central effects of yohimbe
Abbreviation: CYP = cytochrome P450. Much of the available literature on herb–drug interactions is anecdotal and nonreproducible, but there are some herb–drug interactions that, because
 of numerous clinical reports, animal studies, and/or controlled clinical studies, can be deemed to be “likely” (Table 205­4). Although not usually of
66­68 clinical relevance, certain herbals may also interfere with assays for therapeutic drugs.


## Page 2

Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 205: Vitamins and Herbals
Michael Levine
INTRODUCTION
Vitamins and herbal preparations, particularly those sold in health food stores, are considered by many to be innocuous but may have potential toxicity, especially when taken in excessive amounts over a period of time. Also, herbal preparations may contain toxic contaminants that can cause poisoning.
VITAMINS
University of Pittsburgh
Access Provided by:
Hypervitaminosis from the fat­soluble vitamins A, D, E, and K can produce subacute toxicity (after days to a few weeks) or chronic toxicity (after weeks to months of excessive ingestion). Of the water­soluble vitamins, niacin, pyridoxine, and ascorbate are associated with toxicity (Table 205­1).
TABLE 205­1
Clinical Features of Hypervitaminosis
Vitamin Symptoms
Vitamin A Subacute toxicity: red peeling rash, headache, and vomiting.
Chronic toxicity: blurred vision, appetite loss, abnormal skin pigmentation, hair loss, dry skin, pruritus, long­bone pain, bone fractures, liver failure, pseudotumor cerebri, and hypercalcemia.
Vitamin D Subacute toxicity: hypercalcemia, anorexia, nausea, abdominal pain, lethargy, weight loss, polyuria, constipation, confusion, and coma.
Vitamin E Chronic toxicity: coagulopathy in patients on warfarin, nausea, fatigue, headache, weakness, and blurred vision.
Vitamin K Acute toxicity: anaphylactoid reactions if given rapidly in the parenteral form (rare). Interferes with warfarin, resulting in subtherapeutic coagulation.
Vitamin B No toxicity observed with ingestion of large doses.

(thiamine)
Vitamin B No toxicity observed with ingestion of large doses.

(riboflavin)
Vitamin B Acute toxicity: “niacin flush” (redness, burning, and itching of the face, neck, and chest). Hypotension a rare possibility.

Chronic toxicity: Abnormalities of liver function, impaired glucose tolerance, hyperuricemia, skin dryness, and discoloration.
(niacin)
Vitamin B Subacute and chronic toxicity: peripheral neuropathy with unstable gait, and marked loss of position and vibration senses.

(pyridoxine)
Vitamin B No toxicity observed with ingestion of large doses. With large IV doses: erythema of skin, mucous membranes, serum, and urine. Rare
 anaphylactoid reactions. Possible interference with serum colorimetric lab studies.
Folate No toxicity observed with ingestion of large doses. Masking of macrocytic anemia from vitamin B deficiency with large doses of folate.

Vitamin C Chronic toxicity: nephrolithiasis (controversial), intrarenal deposition of oxalate crystals with renal failure; large doses can produce
(ascorbate) diarrhea and abdominal cramps.
VITAMIN A
Dietary vitamin A is present in two forms: preformed vitamin A (retinol and retinyl palmitate [an ester] from animal sources) and provitamin A
(carotenoids) found in plants. After ingestion, the ester form is hydrolyzed in the GI tract to retinol. Retinol is then absorbed into intestinal mucosal cells, where it then combines with a fatty acid to again become a retinyl ester. Carotenoids are dark­colored compounds found in plants. β­Carotene is the carotenoid most efficiently converted to retinol by duodenal mucosal cells. The recommended daily allowance (RDA) for preformed vitamin A

(retinol) is 900 micrograms (3000 IU) for adolescents and adult men, and 700 micrograms (2400 IU) in adult women. The liver contains approximately
95% of body vitamin A stores.
Vitamin A forms part of the visual pigments of the retina (rhodopsin and iodopsin), is important for the formation of mucus­secreting cells in the columnar epithelium, maintains bone growth, and maintains cellular membrane stability.

Hypervitaminosis A is usually due to excessive supplement use, although there have been case reports of acute toxicity due to ingestion of mammal

 oCrhgaapntse (re .g0.5, :f iVshit alimveirn)s. aTnhde rHe eisr bvaalrsia, bMiliicthy aaeml oLnegv ipnaetients in the amounts necessary to develop hypervitaminosis; for example, it is much mPaogree  / 
. Terms of Use * Privacy Policy * Notice * Accessibility  common in children with chronic kidney disease who take supplements compared to those not on supplements. The minimum dose that may cause toxicity in humans is not established.
Symptoms of hypervitaminosis A include blurred vision, appetite loss, abnormal skin pigmentation, loss of hair, dry skin, pruritus, long­bone pain, and an increased incidence of bone fractures. Rarely, hypervitaminosis A can result in pseudotumor cerebri, hypercalcemia, and hepatic
 failure. The treatment of hypervitaminosis A includes discontinuation of the vitamin and supportive care.
β­Carotene, a provitamin A, does not cause hypervitaminosis. In diabetic patients and patients with hypothyroidism, however, large doses of β­ carotene can cause a yellowish discoloration of the skin, which fades once β­carotene is stopped. This phenomenon is occasionally seen in infants and toddlers who consume large amounts of carrots and other pigmented vegetables.
Vitamin A deficiency can result in anemia, numerous ocular symptoms, and immune suppression with subsequent increased risk of infection. Young
 children and pregnant women are some of the groups at highest risk of developing vitamin A deficiency.
VITAMIN D
Dietary vitamin D is ingested as a provitamin, either ergocalciferol (vitamin D ) or cholecalciferol (vitamin D ); both forms are essentially bioequivalent.

These provitamins are then converted to calcitriol (1,25­dihydroxycholecalciferol), the physiologically active form of vitamin D. The major function of calcitriol is to elevate plasma calcium and phosphorus levels, enabling normal bone mineralization.

The RDA for vitamin D is  micrograms (600 IU) for adults, with therapeutic doses sometimes exceeding 125 micrograms (5000 IU) daily. Patients at
,9 the extremes of age are at higher risk for toxicity, as are those on supplementations. Prolonged exposure to vitamin D may result in hypercalcemia,
 hypercalciuria, and hyperphosphatemia. However, the primary symptoms of hypervitaminosis D relate to hypercalcemia and include anorexia, nausea, abdominal pain, lethargy, weight loss, polyuria, constipation, confusion, and rarely, coma.
Treatment of hypervitaminosis D includes discontinuation of vitamin D, reduction of the calcium intake, and reduction of serum calcium levels. IV hydration, calcitonin, and bisphosphonates can be used in the management of hypercalcemia. Vitamin D deficiency may result in rickets and osteomalacia.
VITAMIN E
There are eight unique, fat­soluble, naturally occurring alcohols (called tocopherols and tocotrienols) that possess vitamin E activity, with d­α­ tocopherol the most active form. Because it is rapidly oxidized, α­tocopherol protects other molecules from being oxidized and thus is termed an
 antioxidant. Foods high in vitamin E include wheat germ, corn, soybean, sunflower seed, almonds, peanuts, spinach, and broccoli.

The RDA for vitamin E is  milligrams (22.4 IU) for adults. Vitamin E is thought to be nontoxic at daily doses of up to 400 milligrams (600 IU). With daily
 doses greater than 670 milligrams (1000 IU) taken for a long time, vitamin E has the ability to antagonize the effects of vitamin K, specifically acting as a competitive inhibitor of vitamin K–dependent γ­carboxylation. In addition, through the production of thromboxane, high levels of vitamin E inhibit platelet aggregation. Thus, patients on warfarin therapy are at risk for bleeding, whereas it is rare for patients not on warfarin to bleed from large
 amounts of vitamin E. Patients on tamoxifen or cyclosporine may also have drug–nutrient interactions at high doses of vitamin E. Other effects in
 adults who take large doses for a long period of time include nausea, fatigue, headache, weakness, and blurred vision. These symptoms resolve weeks after discontinuation of the vitamin.
VITAMIN K
Vitamin K activity is found in several compounds of varied origin: phylloquinone or vitamin K , which is naturally produced by plant sources;
 menaquinone or vitamin K , which is produced by bacterial sources; and menadione or vitamin K , a synthetic chemical that is a vitamin precursor of
  vitamin K . Because large doses of menadione are toxic, the use of menadione supplements is banned in the United States for human use but can still
 be found in animal feed.
The GI absorption of vitamin K requires the presence of bile and pancreatic juice, with between 10% and 80% of ingested vitamin K being absorbed. It is thought that most of the vitamin K used in the body is derived from plant sources (K ). Furthermore, if one has an adequate dietary intake of vitamin K ,

 eradication of the gut bacteria will not lead to a deficiency of vitamin K. In contrast to the other fat­soluble vitamins, vitamin K is not stored in the body to any significant extent. Vitamin K deficiency is uncommon because the normal American diet contains vitamin K substantially in excess of the

RDA, which is 120 micrograms in adult men and  micrograms in adult women.
Vitamin K is required for the production of six factors involved in the coagulation cascade: factors II, VII, IX, and X, along with proteins C and S. Warfarin inhibits vitamin K activity, thereby producing a coagulopathy.
The main concern about vitamin K toxicity is the adverse reactions seen with the IV form. The only recommended form of vitamin K for both oral and parenteral use is K . Because vitamin K is fat soluble, it is given parenterally in a lipid­soluble form. Historically, rates of anaphylactoid

 reactions were more common due to a different colloidal suspension. With current preparations, anaphylactoid reactions to IV vitamin K occur at a
 rate of .03% (3 per ,000). Absorption of IM vitamin K is erratic, and absorption from SC administration is relatively ineffective, whereas PO
 absorption is reliable and effective. Thus, vitamin K should be administered orally when feasible or intravenously for life­threatening hemorrhage or in cases where absorption from the GI tract is questionable.
Toxicity from oral vitamin K is rare, although daily doses exceeding 500 micrograms are associated with skin rashes.
VITAMIN B (THIAMINE)

Vitamin B , or thiamine, is converted by the body to thiamine pyrophosphate, which acts as a cofactor for several metabolic reactions, including
 transketolations. Food sources of thiamine include fruits, grain, meats, fish, and milk, among others.
Intestinal absorption of thiamine is greatest in the jejunum. Thiamine is not stored in the body to any significant extent. Because of renal excretion
(water solubility), there is no toxicity to the ingestion of large doses of thiamine over prolonged periods. The RDA for thiamine is .2 milligrams in adult
 men and .1 milligrams in adult women.
Historically, there was concern about the ability of thiamine to precipitate Wernicke’s encephalopathy if glucose was not administered prior to the
 thiamine. There are no clear data to support that theory, and IV glucose is unlikely to precipitate Wernicke’s encephalopathy in patients with altered mental status. Thiamine supplementation prior to glucose administration is not required.
Rarely, IV thiamine may precipitate anaphylactoid reactions. This event is likely related to the diluent and contaminants, as the current pure aqueous
 forms of thiamine for IV use very rarely result in anaphylactoid adverse reactions. Therefore, IV use of thiamine is both safe and clinically efficacious.
Conversely, PO and IM thiamine is absorbed unpredictably in the emergency setting.
Thiamine deficiency may result in beriberi, which is characterized by anorexia, weight loss, and neuropathy. In addition, thiamine deficiency can result in Wernicke’s syndrome or Korsakoff’s psychosis. Wernicke’s syndrome is characterized by confusion, ataxia, and ophthalmoplegia,
 whereas Korsakoff’s psychosis is characterized by confusion, confabulations, and psychosis.
VITAMIN B (RIBOFLAVIN)

The RDA for riboflavin is .3 milligrams in adult men and .1 milligrams in adult women. Riboflavin is excreted through the urine, and toxicity has not
 been reported regardless of the amount ingested.
VITAMIN B (NIACIN)

There are two active forms of niacin—nicotinic acid and nicotinamide—which, in conjunction with thiamine and riboflavin, function as coenzymes in energy metabolism. Niacin becomes part of the coenzymes nicotinamide­adenine dinucleotide and nicotinamide­adenine dinucleotide phosphate; both are required in all major metabolic pathways where there is oxidative breakdown of amino acids, fatty acids, and other compounds, including the oxidation of ethanol.
Niacin is found primarily in poultry, meat, and fish, with lesser amounts in plants. The RDA for niacin is  milligrams for adult men and  milligrams
 for adult women.
Nicotinic acid in the range of  to  grams per day lowers serum cholesterol and β­lipoprotein, but nicotinamide does not. Large niacin doses can also deplete cardiac muscle glycogen and can cause liver toxicity. Some patients experience a frightening “niacin flush” when taking a dose of >100 milligrams. The niacin flush, caused by prostaglandin D and E release with subsequent vasodilation, is characterized by face, neck,

  and chest burning, itching, and erythema. Rarely, hypotension may occur. The use of aspirin before or at the time niacin is consumed
 may reduce the prevalence of niacin­induced flushing. Higher niacin doses may additionally cause nausea, abdominal cramping, diarrhea, and headache. Extremely high doses of niacin for a prolonged period may produce abnormalities of liver function, impaired glucose tolerance, hyperuricemia, and skin changes such as dryness and discoloration. These subacute and chronic symptoms resolve within days to weeks after stopping treatment.
Niacin deficiency can result in pellagra, which is characterized by dermatitis, diarrhea, and dementia.
VITAMIN B (PYRIDOXINE)

Vitamin B is a necessary cofactor for many enzymatic processes. The active form of pyridoxine is pyridoxal­5­phosphate, which serves as a cofactor for

 the formation of γ­aminobutyric acid. The RDA for vitamin B is .3 milligrams for adults aged  to  years.

Chronic administration of high doses of pyridoxine may result in peripheral sensory neuropathy, and sometimes with autonomic and motor nerve impairment. After withdrawal of the vitamin, recovery occurs within several months, although some patients may have residual neurologic impairment.

There is no evidence that a single 5­gram IV dose of pyridoxine will cause any type of nerve damage.
Vitamin B also can cause intestinal inactivation of levodopa in patients receiving that medication for Parkinson’s disease. Tell
 patients not to take this vitamin at the same time as the medication.
Pyridoxine deficiency primarily manifests as seizures. The deficiency can be congenital or acquired (e.g., decreased γ­aminobutyric acid production as a result of isoniazid or hydrazines). In addition, anemia (caused by impaired synthesis of heme), xanthurenic aciduria (as a result of reduced formation of hydroxyanthranilic acid), cystathioninuria (as a result of decreased cleavage of cystathionine to cysteine and homoserine), and homocystinuria (due to impaired formation of cystathionine) may result.
VITAMIN B (CYANOCOBALAMIN)

Due to the size and complexity of the vitamin B molecules, deficiencies of this water­soluble vitamin result more from absorption problems than from

 dietary insufficiencies. Absorption depends on the production of intrinsic factor by the parietal cells of the stomach. Vitamin B –intrinsic factor
 complexes are initially formed in the stomach. The complexes pass to the ileum, where the intrinsic factor attaches to the intestinal epithelium, facilitating the absorption of the vitamin B . Vitamin B is stored in the liver in such quantities that it takes several years for pernicious anemia to

 develop in an individual who is a strict vegetarian and ingests little B or in someone unable to produce intrinsic factor. Dietary vitamin B12 is

 primarily obtained from animal sources. The RDA for vitamin B is .4 milligrams in adults.

Until recently, it was believed that vitamin B had a wide therapeutic index for harm. With the advent of the use of the vitamin B precursor,
  hydroxocobalamin, as an antidote for cyanide poisoning, there have been a few case reports of direct vitamin B toxicity. These cases are

 characterized by erythema of the skin, mucous membranes, urine, and serum. Rare cases of anaphylactoid reactions have also been reported.

Hydroxocobalamin can also interfere with colorimetric lab tests, including those that test for carbon monoxide.

Vitamin B deficiency can result in hematologic, neurologic, and psychiatric effects. The common hematologic disorders include megaloblastic
 anemia and pancytopenia. The neurologic disorders commonly observed include paresthesias, peripheral neuropathies, and dorsal spinal cord column demyelination. Psychiatric symptoms include depression, dementia, and psychosis.
FOLATE
Folate, or folic acid, is essential for the production of DNA, RNA, and proteins. Folate is found in fresh leafy green vegetables, yeasts, and liver. After
 ingestion, folate is actively absorbed in the small and large intestine. The RDA for folate is 400 micrograms in adults.
Both deficiencies of vitamin B and folate can result in megaloblastic (macrocytic) anemia. Large doses of folic acid given to an individual with an
 undiagnosed vitamin B deficiency could correct megaloblastic anemia, but leave the individual at risk of developing irreversible neurologic damage.

Such cases of neurologic progression in vitamin B deficiency have been mostly seen at folate doses of  milligrams and above.

VITAMIN C (ASCORBATE)
The major form of vitamin C, ascorbate or ascorbic acid, is a strong reducing agent that participates in hydroxylation reactions such as those necessary for the formation of collagen. Vitamin C, which is found primarily in fruits and vegetables, is absorbed through the jejunum and ileum. The RDA for
 vitamin C is  milligrams in adult men and  milligrams in adult women.

Chronic high­dose ascorbate ingestion has been reported to cause renal failure due to intrarenal deposition of oxalate crystals. Large doses of vitamin C may produce diarrhea and abdominal cramps, which subside with discontinuation. Limited data suggest that vitamin C in doses exceeding

1000 milligrams may result in false­negative guaiac testing for fecal occult blood.
Scurvy is due to vitamin C deficiency and results in collagen, protein, and lipid metabolism abnormalities. In addition, the presence of vitamin C in the intestines increases the absorption rate of iron, so those with a vitamin C deficiency will also be iron depleted.
HERBAL OR BOTANICAL DIETARY AGENTS

Herbal preparations have long been used by traditional cultures, and their use appears to be increasing in developed countries. In developed countries, herbal preparations have been looked upon as a natural and inexpensive alternative to common Western pharmaceuticals. However, studies funded by the National Center for Complementary and Alternative Medicine have not supported the use of herbal medications for treatment of
    depression (St. John’s wort), dementia (Ginkgo biloba), prostatic hypertrophy (saw palmetto), osteoarthritis (glucosamine and chondroitin),
 and the common cold (Echinacea). There is also a false belief that because herbal products are “natural” that they must be “safe.”

Because herbal products are classified as dietary supplements by the Dietary Supplemental Health and Education Act of 1994, the U.S. Food and Drug
Administration does not have authority to require testing for safety and effectiveness before marketing. However, since 2007, the Food and Drug

Administration has required that manufacturers guarantee the identity, purity, strength, and composition of their dietary supplements. The Food and Drug Administration can restrict sales or remove a supplement from the market if it is proven to be potentially unsafe or harmful. Herbal agents
49­52 can be classified as generally safe, potentially toxic, or toxic (Table 205­2). Many herbal agents have specific liver, eye, and cardiovascular
53­58 toxicities.
TABLE 205­2
Some Generally Safe Herbal Supplements or Agents
Agent General Use Rare Adverse Effect
Chamomile Antispasmodic Anaphylaxis if patient allergic to ragweed
Chondroitin To treat arthritis May cause GI upset
Echinacea To treat or prevent upper respiratory or urinary Anaphylaxis if patient allergic to daisies tract infections May deplete vitamin stores
Feverfew To prevent migraines Suddenly discontinuing may precipitate migraine
If chewed, may cause mouth sores
If applied to skin, may cause dermatitis
Garlic To treat hypertension, colic, and hyperlipidemia Hypotension, rash, nausea, vomiting, diarrhea; death has been reported in massive doses in children
Ginkgo To treat dementia, vertigo, and Raynaud’s disease May inhibit platelet aggregation and interact with warfarin
May cause GI upset
Ginseng To treat impotence, fatigue, ulcers, and stress May interact with warfarin
Lowers blood glucose
May cause insomnia, nervousness
Glucosamine To treat arthritis Allergic reaction
Kava Used for sedation and to relieve sore throat pain Hepatotoxicity
St. John’s To treat depression Phototoxicity wort May interact with serotonin reuptake inhibitors; avoid tyramine­containing foods
Valerian Used for sleep and sedation Interacts with other sedating drugs
May have paradoxical stimulant effect
Although herbal preparations can cause direct toxicity from the herb itself, it is much more common that the patient becomes ill from the
 contamination, misuse, overuse, or misidentification of the herbal preparation. Herbal preparations can cause either direct toxicity (Table 205­3) or
 60­64 indirect toxicity from herb–drug interactions (Table 205­4). Reported contaminants in herbal preparations include lead, selenium, and cyanide.
TABLE 205­3
Some Potentially Toxic Herbal Supplements or Agents
Agent General Use Adverse Effect
Black cohosh To delay or treat menopause Nausea, vomiting, dizziness, weakness
Chaparral (creosote Antioxidant effects, analgesia Potentially hepatotoxic and nephrotoxic bush)
Comfrey Bone and teeth building, variety of other Potentially hepatotoxic uses
Ephedra Weight loss Hypertension; contraindicated for patients with hypertension, diabetes, or glaucoma
Hawthorn Congestive heart failure Additive toxicity with prescribed cardioactive steroids
Juniper Diuretic Hallucinogenic; may also cause renal toxicity, nausea, and vomiting
Lobelia As an expectorant or for treatment of Anticholinergic syndrome asthma
Nutmeg Dyspepsia, muscle aches, and arthritis Hallucinations, GI upset, agitation, coma, miosis, and hypertension
Pennyroyal Rubefacient, delaying menses, Hepatotoxicity abortifacient
Pyrrolizidine alkaloids Pulmonary ailments Hepatic veno­occlusive disease
Wormwood Dyspepsia Absinthism: restlessness, vertigo, tremor, paresthesias, delirium
Yohimbe Aphrodisiac Hallucinations, weakness, hypertension, and paralysis
TABLE 205­4
Some Likely Herb–Drug Interactions
Herb Herb Used For Drug Effect of Interaction
Cayenne Arthritis, neuralgia, analgesic Angiotensin­converting enzyme Increased cough
(Capsicum) inhibitors Increased absorption
Theophylline sustained­release
Dan shen Reduction of lactation Warfarin Decreased warfarin metabolism
(Salvia)
Ephedra Energizer, weight loss, asthma, Monoamine oxidase inhibitors Increased toxicity sinus congestion Sympathomimetics Additive effect
Ginkgo Dementia, peripheral arterial Aspirin Increased risk of bleeding disease, tinnitus Warfarin
Grapefruit juice For vitamin C activity Amiodarone Increased drug availability of any one of these drugs
Benzodiazepines because of inhibition of intestinal CYP3A4
Calcium channel blockers
Carbamazepine
Clomipramine
Cyclosporine
Dextromethorphan
Ethinyl estradiol
3­Hydroxy­3­methyl­glutaryl­coenzyme
A reductase inhibitors (“statins”)
Phosphodiesterase type  inhibitors
(erectile dysfunction drugs)
Quinidine
Sertraline
Kava Sedative/anxiolytic Caffeine Increased levels from inhibition of CYP1A2
Fluvoxamine
Theophylline
Licorice in Respiratory disorders, hepatitis, Antihypertensives Decreased effect (can cause chronic, high inflammatory diseases, infections Diuretics pseudohyperaldosteronism by inhibiting 11­β­ doses Prednisolone dehydrogenase)
Increased potassium loss, myopathy
Increased drug levels
St. John’s wort Depression Cyclosporine Decreased serum levels; transplant rejection
Digoxin Decreased serum level
Indinavir Decreased serum level
Yohimbine Erectile dysfunction, sexual potency Clonidine Decreased effect
Cyclic antidepressants Enhanced autonomic and central effects of yohimbe
Abbreviation: CYP = cytochrome P450. Much of the available literature on herb–drug interactions is anecdotal and nonreproducible, but there are some herb–drug interactions that, because
 of numerous clinical reports, animal studies, and/or controlled clinical studies, can be deemed to be “likely” (Table 205­4). Although not usually of
66­68 clinical relevance, certain herbals may also interfere with assays for therapeutic drugs.


