## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 23: Defibrillation and Electrical Cardioversion
Marcus E.H. Ong; Benjamin S.H. Leong; Yih Yng Ng
PURPOSE OF PROCEDURE
Defibrillation is the therapeutic use of electricity in cardiac arrest to depolarize the entire myocardium to eliminate ventricular fibrillation or nonperfusing ventricular tachycardia so that coordinated contractions can resume. It should be performed in close coordination with CPR of the cardiac arrest patient.
Electrical cardioversion is the application of a synchronized electrical impulse to convert a still­perfusing tachydysrhythmia back to a normal sinus rhythm. Cardioversion may also be performed pharmacologically or nonpharmacologically for the stable patient.
PATIENT SELECTION
The indications for defibrillation include ventricular fibrillation (Figure 23­1) and pulseless ventricular tachycardia (Figure 23­2). Defibrillation is not
“jumpstarting the heart” and is thus not indicated for asystole or pulseless electrical activity. It is contraindicated for sinus rhythm, conscious patients with a pulse, or when there is danger to the operator or others (e.g., from a wet patient or wet surroundings).
FIGURE 23­1. Ventricular fibrillation.
FIGURE 23­2. Ventricular tachycardia.

Chapter 23: Defibrillation and Electrical Cardioversion, Marcus E.H. Ong; Benjamin S.H. Leong; Yih Yng Ng 
. Terms of Use * Privacy Policy * Notice * Accessibility
Electrical cardioversion is indicated for patients with ventricular tachycardia, supraventricular tachycardia, atrial flutter, or atrial fibrillation, who are hemodynamically unstable as a consequence of the rhythm. It may also be considered after unsuccessful pharmacologic therapy for the previously mentioned arrhythmias, even if the patient remains hemodynamically stable. Electrical cardioversion should be synchronized, which means the electric impulse will be timed with the patient’s intrinsic QRS complexes, to minimize the risk of inducing ventricular fibrillation.
EQUIPMENT
The energy used for defibrillation or electrical cardioversion is delivered as a wave and may be monophasic or biphasic. Monophasic waveforms are found in older defibrillators and deliver the energy in a single direction, while biphasic waveforms deliver the energy forward and back in two phases within the same amount of time. The amount of energy required for successful defibrillation is typically lower with biphasic waveforms. Most current defibrillators employ biphasic waveforms, with some manufacturers using their own waveforms.
Manual defibrillators require a manual analysis of the patient’s cardiac rhythm, as well as manual delivery of the shock through paddles or selfadhesive pads (see below) by the operator.
Automated external defibrillators may be fully or semi­automated. Fully automated external defibrillators will analyze the rhythm automatically, and if indicated, charge and deliver the shock, whereas semi­automated external defibrillators will require an operator to manually deliver the shock after analysis and charging.
Manual shocks may be delivered using paddles or self­adhesive defibrillator pads. Manual paddles are docked in cradles on the defibrillator and need to be removed and applied onto the patient’s chest, with minimal time in transit from one position to the other. To prevent inadvertent discharges, always point the paddles downward (Figure 23­3A), and never wave the paddles around, face them toward each other, or hold both paddles in one hand (Figure 23­3B), especially when charged. Safety must be ensured. When using paddles, apply conductive gel or gel pads and firmly press the paddles against the chest wall (25 pounds per square inch of pressure). If conducting gel is used, ensure that the gel does not smear across the chest between the two paddles. Similarly, if gel pads are used, ensure that the two pieces do not overlap (Figure 23­4, A and B). Adhesive pads are single­use and come in disposable packaging. When applying the pads, ensure that they do not overlap and there are no air pockets between the pads and the skin. Good contact ensures maximal shock efficacy. In automated external defibrillators, if contact is insufficient for the defibrillator to operate, a “Check Electrodes” message may also be heard.
FIGURE 23­3. A. Correct paddle handling. B. Improper paddle handling.
FIGURE 23­4. A. Anteroapical positioning of defibrillation paddles in an adult using gel pads. B. Do not overlap gel pads.
Pads are considered advantageous over paddles because of ease of placement, self­retaining nature, improved transmission of current, safety, and hygiene. In addition, they may be used as electrical leads for monitoring of the rhythm or in cardiac pacing. Due to their thinner profile, they can be easily placed in anteroapical, anteroposterior, or anterior­posterior positions (see below) with greater ease. They are preferrred, if available. However, because the pads are only single­use and have expiration dates, paddles may be kept as a backup for situations when pads are unavailable, expired, or malfunction.

Defibrillators and their accessories should be properly maintained and kept in a constant state of readiness. We recommend the use of checklists to identify defibrillator malfunctions and ensure proper maintenance of batteries. Users should be trained in the proper use of checklists and checks should be performed regularly (such as daily or every shift).
PATIENT POSITIONING AND SKIN PREPARATION
Ensure that the scene is safe for performing defibrillation, including water and environmental scene dangers such as traffic. The patient should be in the supine position with ongoing CPR. Expose the chest to apply the pads or paddles. To avoid skin burns, remove all metallic objects, jewelry, or medication patches (wipe off any residue). If there is excessive chest hair over the areas where the pads or paddles are to be placed, quickly shave the hair off to ensure a good contact with the skin. If the patient is on a wet or conducting surface, move the patient to a safe area and dry the body before delivering any shocks. Sweat or moisture on the chest will conduct the current and may reduce the adhesion of pads. Remove all direct
,3 sources of oxygen to avoid fire.
PLACEMENT OF PADS/PADDLES
There are several possible positions for the placement of the pads or paddles:
. Anteroapical position: Place one paddle/pad to the right of the upper half of the sternum, just below the patient’s right clavicle, and place the other pad just below and to the left of the left nipple. With a female patient, place the paddle/pad just below and to the left side of the breast. Do not place it over the breast (Figure 23­5).
This is the preferred position for a supine patient, such as in cardiac arrest, and when using defibrillation paddles. The idea is to maximize current flow across the cardiac chambers rather than along the chest wall.
. Anteroposterior position: Place one pad/paddle at the left lower sternal border and the posterior pad/paddle below the left scapula (Figure
23­6, A and B).
. Pacemakers, automated implantable cardiac defibrillators, and other implants: such devices are implanted under the skin and palpable on examination. Ensure that the placement of the pads is at least four fingerbreadths away from such devices.
FIGURE 23­5. Anteroapical positioning of defibrillation pads. [Image used with permission of Medical Simulation & Education.]
FIGURE 23­6. Anteroposterior positioning of defibrillation pads in an infant. [Reproduced, with permission, from Children’s Emergency, KK Women’s and Children’s
Hospital, Singapore.]
ANESTHESIA AND PROCEDURAL MONITORING
For patients in cardiac arrest, defibrillation is part of the immediate resuscitation process, and anesthesia is unnecessary. However, for emergency or elective electrical cardioversion, good preparation, procedural sedation, and monitoring—before, during, and after the procedure—are essential.
Obtain informed consent whenever possible. Place an IV line and a crystalloid fluid drip to ensure that the vein is open for drug delivery. Ensure airway equipment, suction apparatus, oxygen, and resuscitation drugs are immediately available. Procedural sedation may be provided by using a combination of sedation agents (e.g., etomidate, propofol, midazolam, or ketamine) and analgesic agents (e.g., fentanyl or morphine). Drugs should be selected based on familiarity with the pharmacologic profile as well as the patient comorbidity profile. Ensure cardiac, hemodynamic, and pulse oximetry monitoring before, during, and after the procedure, watching out for adverse effects of the drugs or deterioration of the rhythm.
STEP­BY­STEP TECHNIQUE
MANUAL DEFIBRILLATION
. Prepare the patient and equipment as described earlier. CPR should be ongoing.
. If using paddles, attach the rhythm monitoring electrodes. Alternatively, the paddles may be applied to the chest directly in “quick look” mode to read the rhythm.
. If pads are used, the rhythm will be read by the pads, and additional rhythm electrodes are not necessary.
. Interrupt chest compressions only briefly (<10 seconds) to analyze the rhythm manually.
. Confirm that the rhythm is ventricular fibrillation or pulseless ventricular tachycardia, then resume CPR immediately.
. Select the appropriate energy level. For biphasic defibrillators, select according to the manufacturer’s recommendation (150 to 200 J for biphasic truncated exponential waveforms and 120 to 200 J for rectilinear biphasic waveforms). If the recommendation is unknown, use the maximum energy available. For monophasic defibrillators, begin with an initial 360­J shock. If starting with less than the maximum energy, consider escalation of shock energy for failed shocks or recurrence of fibrillation.
. Ensure that the defibrillator is in unsynchronized mode.
. If using paddles, apply the paddles and charge. CPR should NOT be interrupted during charging. All other personnel may begin to stand clear at this point.
. Call out, “Stand clear,” and ensure that no one is in contact with the patient or trolley. CPR is interrupted only briefly (<10 seconds) at this point.
. With the CPR interrupted, quickly confirm the rhythm remains shockable, then deliver the shock. The operator’s eyes should be back on the patient at the time of shock delivery, to ensure safety.
. Resume CPR immediately once the shock has been delivered. Do NOT pause to check the pulse or reanalyze the rhythm at this time.
. Continue management according to the local resuscitation protocol.
AUTOMATED EXTERNAL DEFIBRILLATION
. Prepare the patient and equipment as described earlier. CPR should be ongoing.
. Turn on the automated external defibrillator (follow the voice prompts according to your device).
. Open the package containing the defibrillation pads with the attached cable and connector. With the chest prepared, carefully pull off the protective backing from the pads and apply the pads to the chest, taking care to avoid air pockets. The pads should be placed at least  inches away from any automated implantable cardiac defibrillators.
. Initiate analysis of the rhythm. This may be automatic or require pressing a button to activate analysis. Ensure that there is no movement of the patient during analysis, including a brief interruption of CPR.
. If a shock is advised, the device will automatically charge to a preset energy level. If a semi­automated external defibrillator is used, CPR should immediately resume while charging. All other personnel may begin to stand clear at this point. Note that fully automated defibrillators do not require the operator’s input to discharge a shock, and all rescuers should stay clear at the time of charging. Follow the voice prompts of the device.
. Call out, “Stand clear,” and ensure that no one is in contact with the patient or trolley. CPR is interrupted only briefly (<10 seconds) at this point.
. Deliver the shock.
. Resume CPR immediately once the shock has been delivered. Do NOT pause to check the pulse or reanalyze the rhythm at this time.
. Continue management according to the local resuscitation protocol.
. There are increasing numbers of automated external defibrillators that provide CPR “guidance” in the form of metronome beats or active feedback on the correct rate and depth of chest compressions in real time. Achieving optimal CPR quality increases the likelihood of successful defibrillation.
ELECTRICAL (SYNCHRONIZED) CARDIOVERSION
. Prepare the patient and equipment as described earlier. Ensure the patient has adequate monitoring and that there is resuscitation equipment on standby.
. Explain the procedure to the patient and provide adequate sedation and analgesia when ready.
. Reassess the patient and the rhythm.
. Ensure that the defibrillator is in synchronized mode.
. Select the appropriate energy level. Narrow regular rhythms should start at  to 100 J (biphasic/monophasic), whereas narrow irregular rhythms should start at 120 to 200 J for biphasic and 200 J for monophasic defibrillators. Wide­complex regular rhythms should start at 100 J
(biphasic/monophasic). Synchronized shocks should not be attempted for wide irregular rhythms; use unsynchronized defibrillation instead.
. Apply the pads or paddles as described above and charge.
. Call out, “Stand clear,” and ensure that no one is in contact with the patient or trolley.
. Visually confirm that the rhythm remains shockable, and then deliver the shock. The operator’s eyes should be back on the patient at the time of shock delivery to ensure safety.
. Reassess the patient and the rhythm.
. If the rhythm has successfully been converted to sinus, continue to monitor and manage according to local protocols.
. If the rhythm remains unconverted, increase the energy level and repeat from step . If maximal energy levels have been reached and the rhythm remains unconverted, consult cardiology for consideration of overdrive pacing.
. If the patient develops cardiac arrest after a cardioversion shock, immediately switch the defibrillator to unsynchronized mode, set the energy level for defibrillation, and charge and deliver shock as described above. If there is any delay during this process, begin CPR immediately while the device is being set and charged. After the defibrillation shock is delivered, resume CPR immediately.
RISKS AND PRECAUTIONS
Electrical energy can terminate an abnormal rhythm, but if inappropriately delivered, it may also induce ventricular fibrillation. This can happen if the
 electric shock is delivered during the relative refractory period of the cardiac electrical cycle. Fine ventricular fibrillation may resemble asystole, and the size of the rhythm waveform should be magnified to reveal this. Movement artifacts or loose leads may resemble ventricular fibrillation and result in an inappropriate shock. New defibrillator technology is available that can filter compression or movement artifacts to “see through” the artifacts to reveal underlying rhythm. However, when using automated external defibrillators, all manufacturers currently still recommend stopping all compressions and patient movement (e.g., during transport) before initiating rhythm analysis.
SPECIAL SITUATIONS
INTERNAL DEFIBRILLATION
Internal defibrillation is indicated in a patient with ventricular fibrillation or pulseless ventricular tachycardia with an open thoracotomy. This could be in a patient with traumatic cardiac arrest, for example, or during open heart surgery. The procedure requires a special set of internal defibrillator paddles (Figure 23­7).
FIGURE 23­7. Internal defibrillation paddles.
Moisten the internal defibrillator paddles with saline, and then place one paddle posteriorly over the left ventricle and the other anteriorly over the right ventricle. Hold the paddles firmly against the myocardium to ensure good contact. Begin with  J for defibrillation and increase as needed.
Open­chest cardiac massage is performed between shocks in this situation.
PEDIATRIC DEFIBRILLATION
Ventricular fibrillation and pulseless ventricular tachycardia in children are relatively uncommon, with the most frequent causes of cardiac arrest being typically respiratory in nature. Thus, treatment should be directed toward preventing cardiac arrest by supporting oxygenation and ventilation. In the event of ventricular fibrillation, use a weight­based energy dose of  to  J/kg body weight for monophasic or biphasic devices. For refractory ventricular fibrillation, consider increasing the dose to  J/kg. For ventricular tachycardia with a pulse, perform electrical cardioversion with  J/kg.
This can be progressively increased up to  J/kg subsequently if needed. Some defibrillator paddles may have integrated child paddles built in, but special pediatric paddles (Figure 23­8, A and B) or pads are also separately available. Adult automated external defibrillators may be used down to  years of age, and some automated external defibrillators also come with pediatric attenuator pads or keys, allowing the device to be used down to  year of age. In an infant, it is possible to defibrillate with the patient propped on the side using the anteroposterior paddle placement. The appropriate compression and ventilation techniques for child or infant CPR will apply accordingly.
FIGURE 23­8. A. Pediatric defibrillation paddles. B. Anteroapical positioning of defibrillation paddles in an infant. [Reproduced, with permission, from Children’s
Emergency, KK Women’s and Children’s Hospital, Singapore.]
DEFIBRILLATION IN HIGH­PERFORMANCE CPR
The concept of high­performance CPR was first promoted by Eisenberg and colleagues and focuses on optimizing the quality of CPR and minimizing
 pauses in compressions associated with defibrillation in team­based resuscitation. It is still important to “stand clear” during defibrillation and to emphasize safety during training. However, it is also important to emphasize attention to high­quality CPR and minimizing rather than eliminating the pause in compressions for defibrillation.

Avoid prolonged pauses beyond  to  seconds, as pauses reduce the chance of defibrillation success. Some strategies adopted by highperformance resuscitation teams include the practice of precharging a defibrillator  seconds before the 2­minute cycle or providing chest compressions while charging and resuming chest compression immediately after a shock. Another strategy is practicing having a second rescuer hovering, ready to commence compressions immediately after defibrillation. In addition, if a mechanical CPR device is being used, defibrillation can be
 safely performed without stopping ongoing mechanical compressions to reduce unnecessary pauses.
HANDS­ON DEFIBRILLATION
This is the practice of defibrillating a patient while providing ongoing manual chest compressions with gloved hands, with the aim of eliminating
 hands­off time. Although inadvertent shocks have been reported in medical literature, inadvertent electrocution during actual resuscitation leading to ventricular fibrillation or death of a rescuer has not been reported. The risk of electrocution is low with proper precautions (e.g., donning of double gloves or electrical safe gloves), but the risk implications must be carefully considered.
DOUBLE SEQUENTIAL DEFIBRILLATION
Double sequential defibrillation (also called dual sequential defibrillation) is a recent practice employing the use of two sets of manual defibrillators simultaneously to attempt to double the defibrillation energy in refractory ventricular fibrillation patients who do not respond to multiple shocks and
 antiarrhythmic drugs. There are anecdotal reports of success with the technique, but lack of evidence from clinical trials. There are manufacturer
 concerns of electrical damage to the defibrillators.
Acknowledgments
We acknowledge Dr. Malcolm Mahadevan, Head and Senior Consultant, Emergency Medicine Department, National University Hospital; Dr. Lynnette
Chung, Resident, Emergency Medicine Department, National University Hospital; Dr. Tham Lai Peng, Senior Consultant, Children’s Emergency, KK
Women’s and Children’s Hospital, Singapore; Madhavi Suppiah, Manager, Life Support Training Center, Singapore General Hospital, Singapore; Susan
Yap, Research Nurse, Department of Emergency Medicine, Singapore General Hospital, Singapore; Garion Koh ZhiXiong, Research Associate,
Department of Emergency Medicine, Singapore General Hospital, Singapore.


