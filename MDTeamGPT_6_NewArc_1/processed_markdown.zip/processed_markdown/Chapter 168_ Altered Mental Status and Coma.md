## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 168: Altered Mental Status and Coma
M. Kathryn Mutter; J. Stephen Huff
INTRODUCTION
Altered mental status and coma are broad clinical categories used to describe disorders of arousal and content of consciousness. Arousal behaviors include wakefulness and basic alerting. Content of consciousness includes awareness, memory, language, reasoning, spatial relationship integration, emotions, complex attention, and the myriad integration processes that make us human. Delirium, dementia, and coma may each affect consciousness, but their clinical presentations are distinct. Prompt and accurate differentiation between the three conditions is essential for appropriate management in the ED setting. Coma is characterized by failure of both arousal and content functions of consciousness. The altered states of delirium and dementia have multiple effects on neuropsychological function to varying degrees. While delirium refers to an acute state of fluctuating attention and change in cognition, dementia is a chronic disorder of deteriorating cognition, with or without behavioral disturbances.
Psychiatric disorders and altered mental states may share features such as hallucinations or delusions. Some distinctions between the different states are summarized in Table 168­1. TABLE 168­1
Features of Delirium, Dementia, and Psychiatric Disorder
Characteristic Delirium Dementia Psychiatric Disorder
Onset Over days Insidious Sudden
Course over  h Fluctuating Stable Stable
Consciousness Reduced or hyperalert Alert Alert
Attention Disordered Normal May be disordered
Cognition Disordered Impaired May be impaired
Orientation Impaired Often impaired May be impaired
Hallucinations Visual and/or auditory Often absent Usually auditory
Delusions Transient, poorly organized Usually absent Sustained
Movements Asterixis, tremor may be present Often absent Absent
DELIRIUM
INTRODUCTION
Delirium, acute encephalopathy, and other synonyms all refer to an abrupt disorder characterized by impairment of attention and cognition. While dDeolwirinulmoa mdeady p2r0e2s5e­n7t­ a1t  a:n2y2 aPg e Y, iot uisr mIPu icsh  m3o6r.1e 4p2r.e1v5a9le.1n2t 7in older adults. The literature suggests that at least  out of  elderly ED patients and at
Chapter 168: Altered Mental Status and Coma, M. Kathryn Mutter; J. Stephen Huff 
1­4 least  out of  elderly hospitalized patients have delirium at the time of admission. Emergency physicians may fail to recognize delirium in three out
. Terms of Use * Privacy Policy * Notice * Accessibility
,4 of four of such cases. Given evidence that delirium in ED patients is associated with an increase in morbidity, mortality, and hospital length of stay, the Society for Academic Emergency Medicine Geriatric Task Force has recommended that formal cognitive assessment should be a quality indicator in
,5­7 emergency care of the elderly.
PATHOPHYSIOLOGY
The pathologic mechanisms leading to delirium are complex and are thought to involve impairments in neuronal connectivity and plasticity, leading to
,8 
“acute brain failure.” There are five general causes :
. Primary intracranial disease
. Systemic diseases secondarily affecting the CNS
. Exogenous toxins (including prescribed pharmacotherapies)
. Drug withdrawal and pain
. Major trauma or surgery
CLINICAL FEATURES
Delirium typically develops over days. Disordered attention and acute fluctuating course are the hallmarks of the condition, which may also affect cognition, level of consciousness, language, and perception. Activity levels may be either increased or decreased. The patient may fluctuate rapidly between hypoactive and hyperactive states. Symptoms may be intermittent, and it is not unusual for different caregivers to witness completely different behaviors within a brief time span. Sleep­wake cycles are often disrupted. Tremor, asterixis, tachycardia, sweating,
,2,10 hypertension, or emotional outbursts may be present. Hallucinations tend to be visual, although auditory hallucinations can also occur.
DIAGNOSIS
Since delirium is a clinical diagnosis, a thorough history and physical examination are key for obtaining findings indicative of possible delirium.
,2,10
Eliciting a history from caregivers, spouse, or other family members is the primary method for diagnosing delirium. Compared to the patient’s baseline, the acute onset of attention deficits and cognitive abnormalities, fluctuating in course, is virtually diagnostic of delirium.
,12
One important tool for detecting delirium is the mental status examination and other cognitive screening instruments. The Mini­Mental State

Examination is historically the standard against which many shorter and less cumbersome tools have been tested. The Geriatric Emergency
Department Guidelines recommend a combination of screening tests: the highly sensitive Delirium Triage Screen (incorporates the Richmond

Agitation­Sedation Scale) and the highly specific Brief Confusion Assessment Method (Figure 168­1).
FIGURE 168­1. Delirium Triage Screen (DTS) and Brief Confusion Assessment Method (bCAM). RASS = Richmond Agitation­Sedation Scale. [Reproduced with permission from XOS Technologies, Inc. dba XOS Digital, Atlanta, GA.]
Evaluate medication history, including both over­the­counter medications and prescribed medications, in detail. Check for drug interactions. Assess for an underlying process, such as infection, metabolic derangement, or trauma. Basic ancillary testing should include serum electrolyte levels, hepatic and renal studies, urinalysis, CBC, and a chest radiograph. Order a head CT if a mass lesion such as subdural hematoma is suspected; follow this by performing a lumbar puncture if meningitis or subarachnoid hemorrhage is considered.
Depression may resemble hypoactive delirium, with withdrawal, slowed speech, and poor results on cognitive testing present in both conditions.
However, rapid fluctuation of symptoms is common in delirium but generally absent in depression. Patients with depression are oriented and able to perform commands.
An unusual cause of an altered mental state, but one suspected to be underrecognized, is nonconvulsive status epilepticus, or complex partial status epilepticus. This twilight state may persist for hours or even months. Suspicion and electroencephalography are required for recognition.
(See Chapter 171, “Seizures and Status Epilepticus in Adults,” for further discussion of nonconvulsive status epilepticus.)
TREATMENT
Direct treatment toward the underlying cause(s). Common medical causes of delirium are listed in Table 168­2. Multiple causes may be present in a given patient.
TABLE 168­2
Important Medical Causes of Delirium
Infectious Pneumonia
Urinary tract infection
Meningitis or encephalitis
Sepsis
Metabolic/toxic Hypoglycemia
Alcohol ingestion
Electrolyte abnormalities
Hepatic encephalopathy
Thyroid disorders
Alcohol or drug withdrawal
Neurologic Stroke or transient ischemic attack
Seizure or postictal state
Subarachnoid hemorrhage
Intracranial hemorrhage
CNS mass lesion
Subdural hematoma
Cardiopulmonary Congestive heart failure
Myocardial infarction
Pulmonary embolism
Hypoxia or carbon dioxide narcosis
Drug related Anticholinergic drugs
Alcohol or drug withdrawal
Sedatives—hypnotics
Narcotic analgesics
Selective serotonin or serotonin­norepinephrine reuptake inhibitors
Polypharmacy
Nonpharmacologic approaches to delirium are the standard of care. Environmental manipulations such as adequate lighting, psychosocial support,
,9,10,13 re­orientation activities, and mobilization may be helpful in enhancing the patient’s ability to interpret the surroundings correctly. In the elderly,
 physical restraints are inadvisable except as a last resort and are associated with worse outcomes. In circumstances of risk of harm to self or others,
 the use of antipsychotics may be indicated. However, the efficacy of antipsychotics in treating delirium in older adults remains controversial.
Haloperidol is a frequent initial choice at a dose of  to  milligrams PO, IM, or IV, with reduced dosing of  to  milligrams in older adults. Repeat at 20­ to 30­minute intervals as needed. In younger patients, benzodiazepines, such as lorazepam, .5 to .0 milligrams PO, IM, or IV, may be used in
,16 combination with haloperidol. Guidelines recommend avoiding benzodiazepines in the elderly. Chapter 287, “Acute Agitation,” provides further discussion on management of agitation.
DISPOSITION AND FOLLOW­UP
Admit the patient with delirium to the hospital for further treatment and additional diagnostic testing, unless a readily reversible cause for the acute mental status change is discovered and treatment initiated. This decision is individualized with consideration of patient characteristics, the resources in the home or healthcare facility, and the patient’s safety.
DEMENTIA
INTRODUCTION
Dementia is a chronic, major neurocognitive disorder entailing a gradual loss of mental capacity. Executive, social, and cognitive abilities deteriorate, and behavioral problems can develop. The most frequent causes of dementia include Alzheimer’s disease and vascular dementia. Dementia with Lewy bodies is the second most common neurodegenerative dementia after Alzheimer’s. However, other, more treatable disorders may cause or simulate dementia.
The typical course of dementia involves insidious symptom onset. The abrupt onset of symptoms or rapidly progressive symptoms should prompt a search for other diagnoses, including delirium. Presentation to the ED is usually precipitated by a sentinel event. Hallucinations, delusions, repetitive behaviors, depression, and anxiety are all common.
PATHOPHYSIOLOGY
Most cases of dementia in the United States are due to Alzheimer’s disease, a neurodegenerative disorder of imprecise etiology. The pathophysiology is complex, with neuritic or amyloid plaques of tau protein and neurofibrillary tangles. However, the relationship between these findings and the
 clinical syndrome of Alzheimer’s disease is incompletely understood. Other neurodegenerative diseases have their own unique pathologies.
Vascular dementia accounts for the next largest number of dementia cases. The pathology is that of cerebrovascular disease with multiple infarctions, not all of which may have been clinically apparent. A listing of different types of dementia is provided in Table 168­3. TABLE 168­3
Classification of Dementia by Cause
Degenerative
Alzheimer’s disease
Dementia with Lewy bodies
Huntington’s disease
Parkinson’s disease
Vascular
Multiple infarcts
Hypoperfusion (cardiac arrest, profound hypotension, others)
Subdural hematoma
Subarachnoid hemorrhage
Infectious
Meningitis (sequelae of bacterial, fungal, or tubercular)
Neurosyphilis
Viral encephalitis (herpes, human immunodeficiency virus), Creutzfeldt­Jakob disease
Inflammatory
Systemic lupus erythematosus
Demyelinating disease, others
Neoplastic
Primary tumors and metastatic disease
Carcinomatous meningitis
Paraneoplastic syndromes
Traumatic
Traumatic brain injury
Subdural hematoma
Toxic
Alcohol
Medications (anticholinergics, polypharmacy)
Metabolic
Vitamin B or folate deficiency

Thyroid disease
Uremia, others
Psychiatric
Depression (pseudodementia)
Hydrocephalic
Normal­pressure hydrocephalus (communicating hydrocephalus)
Noncommunicating hydrocephalus
CLINICAL FEATURES
Clinical features of dementia vary depending on etiology. Whereas visual hallucinations are a cardinal feature of dementia with Lewy bodies, perceptual disturbances may or may not be present in Alzheimer’s or vascular dementia. In many dementias, impairment of short­term memory is gradual and progressive, with relative preservation of remote memories. Language function can be affected in any dementia subtype, but is most common in frontotemporal dementia and later stages of Alzheimer’s disease. Generally, dementia is staged according to degree of decline in global function. Individuals with mild cognitive impairment often have intact activities of daily living and instrumental activities of daily living, whereas those who meet criteria for dementia have some measure of functional deficit.
Patients with vascular dementia often show similar neurocognitive symptoms but may have chronic neurologic physical deficits from prior
 cerebrovascular accidents. Furthermore, vascular dementia often coexists with Alzheimer’s disease.
DIAGNOSIS

General physical examination does not determine the diagnosis of dementia but may be helpful in identifying associated causes. The presence of focal neurologic signs may suggest vascular dementia or a mass lesion. Increased motor tone, rigidity, or a shuffling gait may suggest Parkinsonianrelated dementia. Consider normal­pressure hydrocephalus if urinary incontinence and gait disturbance develop early in the disease process. The recommended screening method by the Geriatric Emergency Department Guidelines is to first screen for delirium with the Delirium Triage Screen and
,20
Brief Confusion Assessment Method combined, and then screen for dementia using the Short Blessed Test.
Laboratory assessment in the ED may include a CBC, comprehensive metabolic profile, urinalysis, and possibly thyroid function tests and chest radiography. Outpatient evaluation may include serum vitamin B level, serologic testing for syphilis (in patients at risk), erythrocyte sedimentation

 rate, serum folate level, and human immunodeficiency virus testing. Consider CT or MRI imaging in the ED when clinically indicated (e.g., if there is concern for normal pressure hydrocephalus or new stroke).
Diagnosis of probable vascular dementia requires signs of cerebrovascular disease. The relationship between stroke and cognitive decline are usually temporally related. A fluctuating, stepped course suggests vascular dementia.
The possibility of a concurrent medical condition suddenly causing cognitive functioning to deteriorate should be strongly considered and often is the thrust of investigation in the ED. Urinary tract infection, congestive heart failure, and hypothyroidism are just a few of the conditions that may cause a patient with mild dementia to show rapid decline. The symptoms overlap with those of delirium, as discussed
,10 earlier in the “Clinical Features” section under “Delirium,” and the two conditions may overlap. In the differential diagnosis, consider the so­called treatable causes of dementia (included in Table 168­3) and impairment in cognitive function caused by depression (pseudodementia). Additionally, behavioral and psychiatric symptoms of dementia (e.g., depression, anxiety, agitation, hallucination) may prompt a visit to the ED.
TREATMENT
The behavioral and psychiatric symptoms of dementia are ideally managed by nonpharmacologic measures. There are three main categories to consider when targeting with interventions: (1) unmet needs, such as unrecognized pain; (2) learned behaviors, such as a behavior that elicits a desired
 response; and (3) environmental vulnerability and stress sensitivity, such as an aggressive behavior due to fear from a new situation.
Atypical and conventional antipsychotic drugs carry a black box warning against use for behavioral and psychiatric symptoms of dementia, due to an increased risk in mortality. Reserve consideration of antipsychotic use for patients with significant risk of harm to self and others. Coordinate treatment with caregivers who are in a position to monitor the patient’s behavior patterns over time.
Treatment of vascular dementia is limited to treatment of risk factors, including hypertension.
Normal pressure hydrocephalus is suggested by the presence of excessively large ventricles on head CT and can prompt consideration of a trial of lumbar puncture with cerebrospinal fluid drainage or ventricular shunting.
DISPOSITION AND FOLLOW­UP
A new diagnosis of dementia may be entertained in the ED, but the depth of the required diagnostic evaluation usually exceeds the time available during the ED visit. A decision to admit or to arrange an outpatient diagnosis should occur after the major and urgent differential diagnostic possibilities have been eliminated. Direct attention toward the presence of delirium or a treatable cause of dementia. Consider hospital admission if comorbid medical problems, a rapidly progressive or atypical clinical course, or an unsafe or uncertain home situation exists.
COMA
INTRODUCTION
,24
Coma is a state of reduced alertness and responsiveness from which the patient cannot be aroused. The Glasgow Coma Scale (Table 168­4; see also Chapter 257, “Head Trauma”) is a widely used clinical scoring system for alterations in consciousness. Advantages are the simplicity of the scoring system and assessment of separate verbal, motor, and eye­opening functions. Disadvantages include lack of acknowledgment of hemiparesis or other focal motor signs and lack of testing of higher cognitive functions. Interrater variability has been noted in assessments using the Glasgow Coma

Scale. Another coma scale, the FOUR (Full Outline of Unresponsiveness) score, has been used in intensive care units and has the advantages of
 assessing simple brainstem functions and respiratory patterns, as well as eye and motor responses. Causes of coma likely to be encountered in the
ED are noted in Table 168­5. TABLE 168­4
Glasgow Coma Scale
Component Score Adult Child <5 y Child >5 y
Motor  Follows commands Normal spontaneous movements Follows commands
 Localizes pain Localizes to supraocular pain (>9 mo)
 Withdraws to pain Withdraws from nail bed pressure
 Flexion Flexion to supraocular pain
 Extension Extension to supraocular pain
 None None
Verbal  Oriented Age­appropriate speech/vocalizations Oriented
 Confused speech Less than usual ability; irritable cry Confused
 Inappropriate words Cries to pain Inappropriate words
 Incomprehensible Moans to pain Incomprehensible
 None No response to pain
Eye opening  Spontaneous Spontaneous
 To command To voice
 To pain To pain
 None None
TABLE 168­5
Differential Diagnosis of Coma
Coma from causes affecting the brain diffusely
Encephalopathies
Hypoxic encephalopathy
Metabolic encephalopathy
Hypertensive encephalopathy
Hypoglycemia
Hyperosmolar state (e.g., hyperglycemia)
Electrolyte abnormalities (e.g., hypernatremia or hyponatremia, hypercalcemia)
Organ system failure
Hepatic encephalopathy
Uremia/renal failure
Endocrine (e.g., Addison’s disease, hypothyroidism, etc.)
Hypoxia
Carbon dioxide narcosis
Toxins
Drug reactions (e.g., neuroleptic malignant syndrome)
Environmental causes—hypothermia, hyperthermia
Deficiency state—Wernicke’s encephalopathy
Sepsis
Coma from primary CNS disease or trauma
Direct CNS trauma
Diffuse axonal injury
Subdural hematoma
Epidural hematoma
Vascular disease
Intraparenchymal hemorrhage (hemispheric, basal ganglia, brainstem, cerebellar)
Subarachnoid hemorrhage
Infarction
Hemispheric, brainstem
CNS infections
Neoplasms
Seizures
Nonconvulsive status epilepticus
Postictal state
PATHOPHYSIOLOGY
The pathophysiology of coma is complex. Coma can result from deficiency of substrates needed for neuronal function (as with hypoglycemia or hypoxia). With systemic causes, the brain is globally affected, and signs that localize dysfunction to a specific area of the brainstem or cortex are usually lacking. With primary CNS causes, coma may result from a brainstem disorder such as hemorrhage or from bilateral cortical dysfunction. Signs localizing to specific areas of CNS dysfunction such as hemiparesis or cranial nerve abnormalities may be present. Unilateral hemispheric disease, such as stroke, should not alone result in coma. The function of the brainstem and/or both hemispheres must be impaired for unresponsiveness to occur.
The herniation syndromes are models for alterations of consciousness, but their mechanisms are unknown. In uncal herniation syndrome, the
,27 medial temporal lobe shifts to compress the upper brainstem, which results in progressive drowsiness followed by unresponsiveness. The ipsilateral pupil is sluggish, eventually becoming dilated and nonreactive as the third cranial nerve is compressed by the medial temporal lobe.
Hemiparesis may develop ipsilateral to the mass from compression of the descending motor tracts in the opposite cerebral peduncle. Central herniation syndrome is characterized by progressive loss of consciousness, loss of brainstem reflexes, decorticate posturing, and irregular
 respiration. Because midline shift without herniation, as demonstrated by neuroimaging, seems to correlate with a decreased level of consciousness, vascular compression due to local cerebral edema or local increased intracranial pressure (ICP) may be an underlying mechanism for these syndromes.
A diffuse increase in ICP can cause diffuse CNS dysfunction. Cerebral blood flow is constant at mean arterial pressures of  to 100 mm Hg due to the process of cerebral autoregulation. At mean arterial pressures outside this range, cerebral blood flow may be reduced, and diffuse ischemia may develop. Cerebral perfusion pressure is equal to the mean arterial pressure minus the ICP (cerebral perfusion pressure = mean arterial pressure – ICP). In extreme uncontrolled elevation of the ICP, cerebral perfusion pressure is diminished as the ICP approaches the mean arterial pressure, which causes brain ischemia.
Particularly in unresponsive patients with a history of seizures, the possibility of ongoing nonconvulsive seizures must be considered. Subtle status epilepticus or ictal coma may represent transformed generalized convulsive status epilepticus. Electrical seizures may continue in the absence of
 clinical seizures.
CLINICAL FEATURES
The clinical features of coma vary with both the depth of coma and the cause. For example, a patient in a coma with a hemispheric hemorrhage and midline shift may have decreased muscle tone on the side of the hemiparesis. The eyes may conjugately deviate toward the side of the hemorrhage.
With expansion of the hemorrhage and surrounding edema, increase in ICP, or brainstem compression, unresponsiveness may progress to a complete loss of motor tone and loss of the ocular findings as well.

A variety of abnormal breathing patterns may be seen in the comatose patient. They offer little information in the acute setting. Pupillary findings, the results of other cranial nerve evaluation, hemiparesis, and response to stimulation are all parts of the clinical picture that need assessment. These findings can assign the cause of the coma into a probable general category—diffuse CNS dysfunction (toxic­metabolic coma) or focal CNS dysfunction
(structural coma). A further division of structural coma into hemispheric (supratentorial) or posterior fossa (infratentorial) coma is often possible at the bedside.
Toxic­Metabolic Coma
Many different toxic and metabolic conditions cause coma. The diffuse CNS dysfunction is reflected by the lack of focal physical examination findings that point to a specific region of brain dysfunction. For example, in toxic­metabolic coma, if the patient demonstrates either spontaneous movements or reflex posturing, the movements are symmetric without evidence of hemiparesis. Muscle stretch reflexes, if present, are symmetric. Pupillary response is generally preserved in toxic­metabolic coma. Typically, the pupils are small but reactive. If extraocular movements are present, they are symmetric. If extraocular movements are absent, however, this sign is of no value in differentiating toxic­metabolic from structural coma. A notable exception is severe sedative poisoning as from barbiturates; the pupils may be large, extraocular movements absent, muscles flaccid, and the patient apneic, which simulates the appearance of brain death.
Coma From Supratentorial Lesions
Coma caused by lesions of the hemispheres, or supratentorial masses, may present with progressive hemiparesis or asymmetric muscle tone and reflexes. The hemiparesis may be suspected with asymmetric responses to stimuli or asymmetric extensor or flexor postures. Uncal herniation syndrome, as described earlier in “Pathophysiology,” is an example of a supratentorial syndrome. Frequently, however, large acute supratentorial lesions are seen without the features consistent with temporal lobe herniation. Coma without lateralizing signs may result from decreased cerebral perfusion secondary to increased ICP. Reflex changes in blood pressure and heart rate may be observed with increased ICP or brainstem compression.
Hypertension and bradycardia in a comatose patient may represent the Cushing reflex from increased ICP.
Coma From Infratentorial Lesions
Posterior fossa or infratentorial lesions compose another structural coma syndrome. An expanding lesion, such as cerebellar hemorrhage or infarction, may cause abrupt coma, abnormal extensor posturing, loss of pupillary reflexes, and loss of extraocular movements. The anatomy of the posterior fossa leaves little room for accommodating an expanding mass. Early brainstem compression with loss of brainstem reflexes may develop rapidly. Another infratentorial cause of coma is pontine hemorrhage, which may present with the unique signs of pinpoint­sized pupils.
Pseudocoma
Pseudocoma or psychogenic coma is occasionally encountered and may present a perplexing clinical problem. Adequate history taking and observation of responses to stimulation reveal findings that differ from those in the syndromes described in the previous sections. Pupillary responses, extraocular movements, muscle tone, and reflexes are shown to be intact on careful examination. Tests of particular value include responses to manual eye opening (there should be little or no resistance in the truly unresponsive patient) and extraocular movements. Specifically, if avoidance of gaze is consistently seen with the patient always looking away from the examiner, or if nystagmus is demonstrated with caloric vestibular testing, this is strong evidence for nonphysiologic or feigned unresponsiveness.
DIAGNOSIS
In the approach to the comatose patient, perform stabilization, diagnosis, and treatment actions simultaneously. Examination, laboratory procedures, and neuroimaging allow differentiation between structural and metabolic causes of coma in almost all patients in the ED. History and physical examination findings allow that initial assignment in many patients, but liberal use of CT scanning is encouraged because exceptions to the tentative
 clinical diagnosis are frequent.
Address airway, breathing, and circulation immediately. Consider reversible causes of coma, such as hypoglycemia or opiate overdose. Access all available historical sources (EMS personnel, caregivers, family, witnesses, medical records, etc.) to aid in diagnosis.
The tempo of onset of the coma is of great diagnostic value. Abrupt coma suggests abrupt CNS failure with possible causes such as catastrophic stroke or seizures. A slowly progressive onset of coma may suggest a progressive CNS lesion such as tumor or subdural hematoma. Metabolic causes, such as hyperglycemia, may also develop over several days.
Address general examination and measurement of vital signs (including oxygen saturation and temperature) following stabilization and resuscitation.
General examination may reveal signs of trauma or suggest other diagnostic possibilities for the unresponsiveness. For example, a toxidrome may be present that suggests diagnosis and treatment, such as the opiate syndrome with hypoventilation and small pupils.
Neurologic testing deviates from the standard examination. Fine tests of weakness, such as testing for pronator drift of the outstretched upper extremities, are not possible in the unresponsive patient. However, asymmetric findings on examination of cranial nerves through pupillary examination, assessment of corneal reflexes, and testing of oculovestibular reflexes may suggest focal CNS lesions. Abnormal extensor or flexor postures are nonspecific for localization or cause of coma but suggest profound CNS dysfunction. Asymmetric muscle tone or reflexes raise the suspicion of a focal lesion. The goal of the physician is to rapidly determine if the CNS dysfunction is from diffuse impairment of the brain or if signs point to a focal (and perhaps surgically treatable) region of CNS dysfunction.
CT is the neuroimaging procedure of choice. Acute hemorrhage is readily identified, as is midline shift and mass lesions. Consider lumbar puncture if
CT scan findings are unremarkable and subarachnoid hemorrhage or CNS infection is suspected. Suspect basilar artery thrombosis in a comatose
 patient with “normal” results on head CT, in which the only finding may be a hyperdense basilar artery. MRI or cerebral angiography is needed to make the diagnosis of basilar artery thrombosis.
SPECIAL CONSIDERATIONS IN COMA
If trauma is suspected, maintain stabilization of the cervical spine during assessment. If protection of the airway is in doubt or the coma state is likely prolonged, then protect the airway by intubating the patient. Rapid­sequence intubation techniques are discussed at length in Chapter 29A, “Tracheal
Intubation” and Chapter 29B, “Mechanical Ventilation.” For children, consider ingestions, infections, and child abuse in the appropriate clinical setting.
Patients who have had generalized seizures and remain unresponsive may be in a continuing state of electrical seizures without corresponding motor movements. This is called nonconvulsive status epilepticus or subtle status epilepticus and can be described as electromechanical dissociation of the brain and body. If the motor activity of the seizure stops and the patient does not awaken within  minutes, then
 consider nonconvulsive status epilepticus. Obtain neurologic consultation and electroencephalography.
TREATMENT
Treatment of coma involves identification of the cause of the brain failure and initiation of specific therapy directed at the underlying cause. Attend to airway, ventilation, and circulation. Evaluate and treat for readily reversible causes of coma, such as hypoglycemia and opioid toxicity.
Antidotes
Rapid point­of­care glucose determination can identify the need for dextrose. Although thiamine should be administered before glucose infusion in patients with a suspected history of alcohol abuse or malnutrition, thiamine is not necessary for all patients. Routine use of flumazenil in coma of
 unknown cause is not recommended. Naloxone, an opiate antagonist, may be useful in diagnosis and treatment of coma of unknown cause, given that the miosis of the opiate toxidrome can be absent with some opioids and mixed ingestions.
Increased Intracranial Pressure
If history, physical examination, or neuroimaging findings suggest increased ICP, specific steps can reduce or ameliorate any further rise in ICP. Any noxious stimulus, including “bucking” the ventilator, can increase ICP, so use paralytic and sedative agents. A general recommendation is to keep the head elevated about  degrees and at midline to aid in venous drainage. Mannitol (0.5 to .0 gram/kg IV) can decrease intravascular volume and brain water and may transiently reduce ICP. Hypertonic saline infusion has also been found to be effective in reducing ICP. In cases of brain edema associated with tumor, dexamethasone,  milligrams IV, reduces edema over several hours. Hyperventilation with reduction of partial pressure of arterial carbon dioxide can reduce cerebral blood volume and transiently lower ICP. Current recommendations are to avoid excessive hyperventilation
(partial pressure of arterial carbon dioxide ≤35 mm Hg) during the first  hours after brain injury. Brief hyperventilation may be necessary for refractory intracranial hypertension. Data to recommend specific therapy are lacking, and preferences among individuals and institutions vary greatly, so communicate early with consultants and admitting physicians.
DISPOSITION AND FOLLOW­UP
Patients with readily reversible causes of coma, such as insulin­induced hypoglycemia, may be discharged if home care and follow­up care are adequate and a clear cause for the episode is suspected. Admit patients with persistent altered consciousness. Most institutions depend on emergency physicians to stabilize the patient’s condition and correctly assign a tentative diagnosis so that the patient may be admitted to the proper specialty service. If the appropriate service is not available, then consider transfer to another hospital after patient stabilization.


