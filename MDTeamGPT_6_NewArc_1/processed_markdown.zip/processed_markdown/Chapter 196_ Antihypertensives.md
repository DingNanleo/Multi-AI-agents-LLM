## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 196: Antihypertensives
Frank LoVecchio; Dan Quan
INTRODUCTION

An estimated 29% of adults in the United States have hypertension; thus, antihypertensives are commonly found in patient homes. Several classes of drugs used to treat hypertension are discussed in this chapter: diuretics, sympatholytic agents, angiotensin­converting enzyme inhibitors (ACEIs), angiotensin II receptor blockers (ARBs), and vasodilators (Table 196­1). Calcium channel blockers and β­blockers, also used in the treatment of hypertension, are discussed elsewhere (see Chapter 195, “Calcium Channel Blockers,” and Chapter 194, “Beta­Blockers”).
TABLE 196­1
Summary of Antihypertensive Drugs
Clinical
Class Drug Mechanism of Action Presentation With Comments
Toxicity
Diuretics Chlorothiazide Inhibition of distal tubule Hypovolemia Metabolic complications, such as hypokalemia,
Chlorthalidone sodium chloride absorption Hypokalemia glucose intolerance, and hyperuricemia seen with
Hydrochlorothiazide Hypercalcemia increased therapeutic thiazide doses.
Indapamide
Metolazone
Bumetanide Inhibition of sodium­potassium­ Hypovolemia
Furosemide chloride symporter in renal Hypocalcemia loop of Henle Hypokalemia
Hypomagnesemia
Amiloride Inhibition of sodium absorption Hypovolemia
Triamterene and potassium elimination in Hyperkalemia renal distal collecting duct
Eplerenone Mineralocorticoid antagonist Hypovolemia
Spironolactone Hyperkalemia
Sympatholytics Doxazosin α ­Adrenergic receptor Hypotension Phenylephrine may be used for refractory

Prazosin hypotension.
antagonist
Tamsulosin
Terazosin
Clonidine α ­Adrenergic receptor agonist Hypotension Dopamine considered agent of choice for

Guanabenz Bradycardia hypotension.
Imidazoline receptor agonist
Guanfacine Neurologic Phenylephrine may be used for refractory
µ­Receptor opioid agonist depression hypotension.

Chapter 196: Antihypertensives, Frank LoVecchio; Dan Quan 
Oxymetazoline Imidazoline receptor agonist Hypotension
. Terms of Use * Privacy Policy * Notice * Accessibility
Tetrahydrozoline Bradycardia
Neurologic depression
Guanadrel Decreased norepinephrine Hypotension
Methyldopa release Bradycardia
Reserpine Hemolytic anemia
(idiosyncratic reaction to methyldopa)
Angiotensin­ Benazepril Inhibition of ACE Hypotension Epinephrine, corticosteroids, and antihistamines converting Captopril Inhibition of bradykininase Hyperkalemia have no proven benefit in ACEI­induced enzyme Enalapril Angioedema angioedema.
inhibitors Fosinopril (idiosyncratic) Icatibant  milligrams SC or C1 esterase inhibitor
Moexipril Cough (idiosyncratic) [human] 1000 U IV appear effective in ACEI­
Perindopril induced angioedema.
Quinapril
Trandolapril
Angiotensin Candesartan Angiotensin II receptor Hypotension Epinephrine, corticosteroids, or antihistamines receptor Eprosartan antagonist Hyperkalemia have no proven benefit in ARB­induced blockers Irbesartan Angioedema (less angioedema.
Losartan common than with
Telmisartan ACE inhibitors)
Valsartan
Vasodilators Hydralazine Arteriolar vasodilation Hypotension
Lupus­like syndrome
(idiosyncratic reaction to hydralazine)
Minoxidil Arteriolar vasodilation Tachycardia
Increased myocardial oxygen demand
Sodium Arteriolar and venous Hypotension Thiosulfate should be administered if cyanide nitroprusside vasodilation (via nitric oxide Tachycardia toxicity is considered.
release) Thiocyanate toxicity
(after prolonged Many pharmacies mix sodium nitroprusside and infusion) thiosulfate to avert cyanide toxicity.
Cyanide toxicity
(very rare)
Abbreviations: ACE = angiotensin­converting enzyme; ARB = angiotensin II receptor blocker; ACEI = angiotensin­converting enzyme inhibitors.

For most of these agents, life­threatening toxicity is not expected in acute overdose. In nearly all cases, good supportive care is adequate. The initial approach to the patient with potential overdose of an antihypertensive drug is fairly uniform. Secure the airway as necessary, establish IV access, provide continuous cardiac monitoring, and obtain an ECG. A bolus of crystalloid solution is first­line treatment for hypotension. If a vasopressor is required, a direct­acting drug such as norepinephrine is preferred. If pulmonary aspiration is not a concern, activated charcoal can be given within the first hour. Although there is usually no specific therapy for initial management of these drugs in overdose, the different classes of antihypertensives are distinct in their potential for causing metabolic derangements and adverse effects.
DIURETICS
Diuretics initially control hypertension by increasing elimination of salts, but their mechanism of action in long­term blood pressure control is not clear. All diuretics cause increased sodium elimination, which results in the potential for hyponatremia, hypokalemia, hyperkalemia, hypomagnesaemia, and hypovolemia.
Thiazides, like hydrochlorothiazide, inhibit sodium chloride reabsorption in the renal distal convoluted tubule. Decreased sodium reabsorption leads to increased excretion of potassium and the possibility of hypokalemia. Calcium regulation is also affected by thiazide diuretics via two separate mechanisms: (1) inhibition of vitamin D synthesis and thus decreased calcium absorption from the GI tract, and (2) increased renal absorption of
 calcium. The net result, however, is calcium retention and potentially hypercalcemia. Glucose intolerance is noted at higher doses.
Loop diuretics, such as furosemide and bumetanide, are used more frequently for control of edema and pulmonary congestion than for hypertension. Loop diuretics inhibit the activity of the sodium­potassium­chloride symporter (a type of cotransporter that facilitates transport across a plasma membrane) in the renal loop of Henle, where 25% of the filtered sodium load is typically reabsorbed. A secondary effect of the inhibition of this symporter is decreased calcium and magnesium reabsorption, which results in hypocalcemia, hypokalemia, and hypomagnesemia.
Triamterene,amiloride, spironolactone, and eplerenone are referred to as potassium­sparing diuretics for their ability to cause a sodium chloride diuresis without increased potassium secretion. Triamterene and amiloride inhibit sodium channels in the distal renal tubule and collecting duct, which play a role in both reabsorbing sodium and secreting potassium. These drugs may be used in conjunction with other stronger diuretics for
 management of hypertension. Triamterene has been associated with rare cases of crystalline nephropathy.
Spironolactone and eplerenone are antagonists of mineralocorticoids such as aldosterone. Mineralocorticoid antagonists increase elimination of sodium and retention of hydrogen and potassium. Spironolactone is typically used to treat heart failure and hepatic cirrhosis. In the acute overdose setting, hyperkalemia and hypotension are the most serious clinical manifestations of these drugs.
Clinical manifestations of excessive diuresis include tachycardia, hypotension (orthostatic or supine), electrolyte abnormalities, and generalized weakness. The ECG may show changes caused by these electrolyte abnormalities (see Chapter , “Fluids and Electrolytes”). A widened QRS interval or peaked T waves may suggest hyperkalemia, such as from a potassium­sparing diuretic. A prolonged QT interval may indicate hypokalemia, hypomagnesemia, or hypocalcemia, which may be caused by a loop diuretic.
The first priority of therapy is restoration of plasma volume. Administer an isotonic crystalloid solution bolus, such as .9% saline. Treat electrolyte abnormalities, such as hyperkalemia, hypokalemia or hypocalcemia, with standard management and fluid resuscitation (see Chapter , “Fluids and
Electrolytes”).
In addition to causing direct toxicity, diuretics may potentiate toxicity from other medications. Mechanisms include decreased renal clearance of drugs or creation of a metabolic state that changes a particular drug’s effect. Diuretics and ACEIs can increase the risk of lithium toxicity by reducing
 lithium elimination (see Chapter 181, “Lithium”). Hypokalemia from diuretics may exacerbate arrhythmias seen in chronic digoxin poisoning or other antiarrhythmics (see Chapter 193, “Digitalis Glycosides”).
SYMPATHOLYTIC AGENTS
Catecholamines produced by the sympathetic nervous system play a key role in maintaining blood pressure. Drugs with action at α­adrenergic receptors are used to diminish peripheral sympathetic tone in order to decrease blood pressure. There are two subtypes of α­adrenergic receptors.
Stimulation of the α ­adrenergic receptors causes vasoconstriction of arterioles and veins, increasing peripheral vascular resistance and elevating
 blood pressure. Stimulation of the α ­adrenergic receptors produces different effects in the peripheral and central nervous systems. In the peripheral
 nervous system, stimulation of the α ­receptors produces vasoconstriction and increases blood pressure. In the CNS, stimulation of the α ­receptors
  at presynaptic sympathetic terminals inhibits the release of catecholamines, thereby decreasing sympathetic tone, promoting peripheral vasodilation, and decreasing blood pressure.
DOXAZOSIN, PRAZOSIN, AND TERAZOSIN
Doxazosin, prazosin, and terazosin antagonize α ­adrenergic receptors, reducing peripheral vascular resistance. Although the aforementioned
 drugs are used for the treatment of hypertension, other members of this class, such as tamsulosin, are used exclusively for management of benign prostatic hyperplasia and as an adjunct in nephrolithiasis management. Because an increase in peripheral vascular resistance is required to maintain blood pressure when changing from a supine to an upright position, it is not surprising that the most typical adverse effect observed with α ­
 adrenergic antagonists is orthostatic hypotension, particularly within  to  minutes after ingestion, and is most prominent after taking the first
 dose.
Although orthostatic hypotensive episodes may be associated with lightheadedness and adverse events such as falls resulting in hip fracture, patients rarely come to the ED with prolonged hemodynamic instability. Patients who do present with hypotension associated with α ­adrenergic antagonist
 use should be placed supine and receive a crystalloid bolus. Based on the mechanism of action of these drugs, α ­adrenergic agonists should be used

 if blood pressure does not improve with IV fluids.
CLONIDINE
Clonidine is the most commonly used α ­adrenergic agonist. Clonidine is available in an oral formulation and as a transdermal patch. This class of
 drugs, which also includes guanabenz and guanfacine, stimulates α ­adrenergic receptors in the CNS, inhibiting release of catecholamines in the
 periphery, which results in decreased heart rate, contractility, and peripheral vascular resistance. Clonidine shares the imidazoline functional group with the nasal spray decongestant oxymetazoline and topical eye vasoconstrictor medication tetrahydrozoline. Inappropriately ingesting
,9 oxymetazoline or tetrahydrozoline can result in toxicity similar to clonidine poisoning. In addition to hemodynamic effects, clonidine
 also possesses opioid agonist properties at the µ receptor. For this reason, clonidine is used in some opioid­dependent patients to ameliorate symptoms of withdrawal.
,12
Clonidine poisoning typically results from either intentional overdose or exploratory pediatric poisoning. Even a single tablet may cause
,14 ,16 significant symptoms in a child. Toxicity can develop from ingesting clonidine patches. Compounded ointments used for chronic pain
17­19 may contain clonidine; application of these patches to small children (or to adults in excessive quantity) may produce toxicity.
,20
Shortly after an ingested overdose of clonidine, the peripheral α ­adrenergic stimulation may cause hypertension. By the time of presentation,
 however, the clinical manifestations of central α ­adrenergic stimulation and imidazoline toxicity are present with bradycardia, CNS depression, and

,21  hypotension. Clonidine may produce miotic pupils in a manner similar to opioids. Hypothermia may occur as a result of opioid or adrenergically
,11,23 mediated pathways. Somnolence is typical and may progress to apnea in severe cases. Although clonidine is intended to be dosed twice daily, symptoms may last days with an overdose.
,24
Focus on ventilatory and hemodynamic support in clonidine toxicity. Clonidine­induced respiratory and neurologic depression has variable
,25­29  response to naloxone, and its use is unlikely to be helpful in adults ; however, it is considered to be more effective in children. Bradycardia may be treated with atropine. When encountered, hypertension should be treated only if it is severe and prolonged, because hypertension may unpredictably give way to hypotension. If it is necessary to treat clonidine­associated hypertension, use a short­acting drug that can be quickly discontinued (e.g., nitroprusside). Hypotension associated with clonidine typically responds well to crystalloid fluid resuscitation.
METHYLDOPA
Methyldopa is also a centrally acting antihypertensive, although it has a unique mechanism. Methyldopa is a dopamine analog that, in the CNS, is converted in two steps to α­methylnorepinephrine, which in turn substitutes for norepinephrine in adrenergic neuron secretory vesicles. In the CNS, α­ methylnorepinephrine stimulates presynaptic α ­adrenergic receptors, reducing peripheral sympathetic tone. In therapeutic dosing, the peak effect of
 methyldopa is delayed for  to  hours, because time is required for methyldopa to pass into the brain and be converted to its active form. Methyldopa
,31 use is also associated with an autoimmune hemolytic anemia, which can occur during long­term therapeutic use. If symptomatic hypotension is encountered in association with methyldopa, IV crystalloid solution should be administered. In cases of refractory, severe hypotension, a direct­acting
 vasopressor such as norepinephrine should be administered.
GUANADREL AND RESERPINE
Guanadrel and reserpine are antihypertensives that interfere with the release of catecholamines from synaptic terminals. Guanadrel, which has no intrinsic sympathetic activity, substitutes for norepinephrine in presynaptic storage vesicles. Reserpine inhibits formation of biogenic amine storage vesicles in central and peripheral neurons. In each case, there is a decreased capacity to release catecholamines in response to a sympathetic stimulus.
Sympathetic tone is diminished, and peripheral vascular resistance decreases. There is little experience with these drugs in overdose. However, because the common mechanism of both drugs is a decrease in circulating catecholamines, it would seem reasonable to administer boluses of crystalloid as first­line therapy and to use a direct­acting vasopressor, such as norepinephrine or phenylephrine, to treat refractory hypotension.
ANGIOTENSIN­CONVERTING ENZYME INHIBITORS AND ANGIOTENSIN RECEPTOR BLOCKERS
Angiotensin II raises blood pressure by several mechanisms, including triggering aldosterone release, increasing response to catecholamines, and acting as a direct vasoconstrictor. Angiotensin II is created in a two­step process. In the first step, renin, released by the kidneys, cleaves angiotensinogen, forming angiotensin I. The second step uses angiotensin­converting enzyme, which separates the carboxy terminus off angiotensin I, forming angiotensin II. Inhibition of this conversion at either step results in decreased blood pressure.
ACEIs are thought to slow the progression of diabetic glomerulopathy and have been shown to improve mortality and left ventricular function when administered after myocardial infarction. Members of this large class of drugs can be identified by their shared “­pril” suffix: benazepril, captopril, enalapril, fosinopril, moexipril, perindopril,quinapril, and trandolapril. Inhibition of angiotensin­converting enzyme results in decreased production of angiotensin II, which causes vasodilation. Despite their widespread use, these medications have not been associated with significant morbidity in overdose. ACEIs can cause hyperkalemia in therapeutic dosing. If hypotension is encountered, initial therapy focuses on basic management, including administration of boluses of crystalloid and vasopressors for refractory cases.
Captopril, and possibly other ACEIs, are thought to inhibit the metabolism of the enkephalins, a group of endogenous opioids. Naloxone, a µ­opioid
  antagonist, may reverse captopril­associated hypotension but is not universally effective.
ARBs produce vasodilatation and increase renal salt elimination. Members of this class end with the suffix “­artan” and include losartan, candesartan, irbesartan, valsartan, telmisartan, and eprosartan. When they are taken therapeutically, the peak antihypotensive effect of agents in this class is not observed for  weeks. Typically, these drugs are not associated with significant morbidity in overdose. There are no reported cases of isolated ARBs overdose causing life­threatening hypotension. Like ACEIs, ARBs can cause hyperkalemia, which results from decreased aldosterone
 production. This effect is typically seen in patients with renal insufficiency.

Persistent dry cough occurs in 5% to 20% of patients treated with ACEIs. Cough typically develops within a few weeks after ACEI therapy is started and is more common in women, and the rate of occurrence or severity does not correlate with dose. Cough will usually resolve in  to  weeks after the drug is stopped, although resolution may take up to  months for some patients. The only effective treatment is discontinuing the ACEI, substituting a different antihypertensive. ARBs are not associated with an increased incidence of chronic cough and may be used in patients with ACEI­induced
 cough.
37­39
Angioedema is the most consequential adverse effect associated with ACEIs and ARBs (see Chapter , “Allergy and Anaphylaxis”).
,40
Angioedema is an idiopathic reaction that occurs in .1% to .7% of patients prescribed these drugs. Because these agents are widely used, this small percentage represents a large number of events. Patients present with swelling of the lips, larynx, pharynx, tongue, or vocal cords, which can
 range in severity from mild to airway compromise. Symptoms develop over several hours and may not resolve for  hours or longer. The absence of urticaria, abdominal swelling, and genitourinary swelling differentiates ACEI­induced angioedema from histamine­mediated
 causes. The mechanism is thought to be related to inhibition of ACE­mediated degradation of bradykinin, a peptide associated with vasodilatation
,41 and tissue edema, and accumulation of substance P and other prostaglandins. ARBs do not inhibit bradykinin, so the exact pathophysiology of angioedema associated with drugs from this class is not clear. The mean time from first use to development of angioedema has been
 reported as about  years, but angioedema can occur at any time during therapy, with 12% of patients developing this reaction in the first week of ACEI use.
Management of ACEI­induced angioedema begins with evaluation of the airway. If the patient has difficulty breathing, stridor, or lingual or
 oropharyngeal edema, secure the airway, usually by intubation. Fiberoptic­guided laryngoscopy is recommended because it requires minimal sedation and provides direct visualization in an edematous airway. Regardless of the method employed, a skilled operator should secure the airway early because angioedema can progress rapidly and anatomic landmarks may become obscured.
Allergic­reaction drugs, such as epinephrine, antihistamines, and corticosteroids, are often given but not likely beneficial because ACEI­induced
 angioedema is not mediated by histamines or immunoglobulins. Agents reported beneficial in ACEI­induced angioedema include icatibant, a
  ,47 bradykinin­2 antagonist, at a dose of  milligrams SC ; C1 esterase inhibitor (human) 1000 units IV ; and fresh frozen plasma  units, but the
,49 overall quality of evidence is mixed.
Patients with milder symptoms should be observed and managed medically. There is no consensus regarding the disposition of patients with ACEI­ associated angioedema who do not require ED airway intervention. Patients with milder swelling only around the lips or face should be observed for 
 to  hours and considered for discharge when swelling begins to regress. Patients should be instructed that angioedema can recur if they continue
,51 to take the same agent or switch to another agent of the same class. After an episode of angioedema, the safest and recommended course of action is to discontinue all ACEIs and ARBs.
VASODILATORS
HYDRALAZINE AND MINOXIDIL
Hydralazine is an antihypertensive agent most commonly used during pregnancy. Hydralazine relaxes arteriolar smooth muscle but does not affect venous smooth muscle or epicardial coronary arteries. Hydralazine is metabolized to an inactive compound by hepatic acetylation. Roughly half of
Americans are fast acetylators and therefore require a higher dose to achieve a given clinical effect. The peak effect of the drug is seen  to 120 minutes after ingestion, although effects may last as long as  hours. The most common adverse effects of hydralazine overdose result from
 vasodilatation, but serious events are rare. Patients with hydralazine overdose with mild hypotension may develop ST­segment depression on ECG.
This myocardial ischemia is thought to result from a steal syndrome in which peripheral vasodilatation is accompanied by reflex tachycardia without an increase in epicardial blood flow, so that myocardial demand increases while coronary perfusion does not. Because of this reflex tachycardia, hydralazine should not be used for treatment of acute coronary syndrome or cocaine­associated chest pain.
Patients on continuous treatment with hydralazine are at risk for development of a lupus­like syndrome. The mechanism is thought to be formation of autoantibodies, but it is not known how hydralazine contributes to this process. Risk factors include high dose, female gender, slow­acetylator phenotype, and white ethnic background. Symptoms of this syndrome include arthralgia, arthritis, fever, and pericardial effusion. Management includes administration of anti­inflammatories and discontinuation of the drug.
Minoxidil is a potent antihypertensive generally used only for resistant cases of hypertension. Minoxidil is better known for its topical formulation as a treatment for male pattern baldness. Minoxidil is metabolized to minoxidil sulfate, which in turn relaxes smooth muscle by opening potassium channels and causing hyperpolarization. Like hydralazine, minoxidil has little effect on venous smooth muscle. Peripheral vasodilatation results in reflex tachycardia and increased cardiac output. Reduced renal perfusion causes fluid retention. For this reason, minoxidil is usually prescribed with a
β­blocker and diuretic. Overdose of minoxidil is associated with hypotension, common reflex tachycardia, and occasional myocardial ischemia in a
53­56 manner similar to hydralazine.
Hypotension from either hydralazine or minoxidil is treated with IV crystalloid fluids. Vasopressors should be avoided if possible, because severely poisoned patients may have coronary ischemia. If blood pressure is refractory to fluid resuscitation, an α ­adrenergic agonist, such as phenylephrine

 or midodrine, is preferable to a β­adrenergic agonist, in order to minimize tachycardia and prevent increased myocardial oxygen demand.
SODIUM NITROPRUSSIDE
,58
Sodium nitroprusside is administered IV for hypertensive emergencies. Nitroprusside derives its activity from the release of nitric oxide, an endogenous mediator of vasodilation, which stimulates smooth muscle guanylyl cyclase to produce cyclic guanosine monophosphate. The onset of action is roughly  seconds, and the offset is  minutes. Nitroprusside dilates both arteriolar and venous smooth muscle. In the ED, hypotension is the adverse effect most likely to be observed. If hypotension occurs, the infusion should be stopped immediately. If signs of cerebral hypoperfusion are present, place the patient supine or possibly in the Trendelenburg position. Because of the very brief duration of action of the drug, little else is generally necessary after discontinuing the drug.
When nitric oxide is released from nitroprusside, cyanide is produced as well. As long as the nitroprusside infusion rate is not above  to  micrograms/kg per minute, the cyanide is usually of little consequence, because it is immediately metabolized by rhodanese to thiocyanate, a much
 less toxic metabolite. At higher infusion rates over several days, the ability of rhodanese to detoxify cyanide may become overwhelmed.
Administration of sodium thiosulfate, which serves as a substrate for rhodanese, can be protective for patients requiring a high rate of nitroprusside administration. Cyanide toxicity may manifest as confusion, lactic acidosis, and progression to cardiovascular collapse. If the clinician is concerned about cyanide toxicity, the infusion should be discontinued, and sodium thiosulfate should be administered.
Over time, the thiocyanate generated by detoxification of cyanide can itself cause toxicity manifesting as nausea, fatigue, and CNS depression.
Thiocyanate toxicity, although much more common than cyanide toxicity during nitroprusside treatment, is unlikely to occur in the ED. Thiocyanate,
 which is eliminated by the kidney with a half­life of  to  days, usually does not accumulate until infusion has continued for several days. The most important predictors of toxicity are rate of production (nitroprusside infusion rate) and rate of elimination (renal function).
FENOLDOPAM
Fenoldopam is a selective dopamine­1 agonist used for hypertensive emergencies, although its clinical utilization in the United States has remained
,62 ,58 low. Fenoldopam is administered parenterally and acts as a vasodilator and diuretic. Fenoldopam has a half­life of approximately  minutes, and after infusion is instituted, steady­state serum levels are reached in about  to  minutes. If hypotension is encountered after fenoldopam administration, the infusion should be stopped immediately and a fluid bolus administered.


