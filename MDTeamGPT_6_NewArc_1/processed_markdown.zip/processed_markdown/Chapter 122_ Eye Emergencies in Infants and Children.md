## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 122: Eye Emergencies in Infants and Children
Janeva Kircher; Andrew Dixon
INTRODUCTION
Pediatric ophthalmologic problems are a common yet challenging issue for all emergency physicians. The history often comes from the parents, particularly in preverbal children, and it may even be difficult for older children to fully articulate their symptoms. The child and the parents need to be calmed and reassured sufficiently to allow for a complete and thorough examination. This chapter includes a review of eye examination techniques and illnesses specific to the care of children. Because the care of pediatric and adult trauma to the eye and its surrounding structures is similar, only those areas of difference are discussed in this chapter. Further discussion of eye emergencies is provided in Chapter 241, “Eye Emergencies.” Eye anatomy is presented in Figures 122­1, 241­2, and 241­6. FIGURE 122­1. Anatomic diagram of the eye and the adnexa.
A visit to the ED is an opportunity to educate the patient and family about prevention of ocular injury and sun exposure. The annual incidence of eye
 trauma is  to .2 per 100,000 children, and most events are thought to be preventable. Protective eyewear and adequate supervision during
 recreational and competitive sports should be available and may prevent injuries.
Discuss the use of sunscreen and sunglasses for children before going outdoors for any sustained period of time. Emphasize the importance of using sunglasses with both ultraviolet A and ultraviolet B protection. Sun exposure is cumulative, and there is some research that it has an effect on
 development of cataracts and macular degeneration. Ultraviolet B rays may also increase the risk of developing pterygia and pinguecula (yellowish­
 wChhaitpet vear s1c2u2la: rE cyoen jEumncetrigvaeln lceiseiso nins )I lnaftaenrt isn a linfed. Children, Janeva Kircher; Andrew Dixon 
. Terms of Use * Privacy Policy * Notice * Accessibility
EYE EXAMINATION IN A CHILD
If a history of chemical exposure is obtained, triage as highest priority, and immediately irrigate the eye with  to  L of saline.
A complete eye exam includes gross examination, assessment of visual acuity, extraocular movements, and ophthalmoscopic exam of the eye. A slit lamp exam of the eye should be performed whenever possible.
Begin by performing a general survey, adopting an outside­in approach, to note any obvious abnormalities such as rash, soft tissue changes, matter on the lashes, ptosis, misalignment of the eyes, injection of the conjunctiva, drainage from the eye, or corneal/lens opacities. Newborns may appear cross­eyed during the first  months of life as ocular fixation develops.
VISUAL ACUITY AND EXTRAOCULAR MOVEMENTS
Visual acuity is the vital sign of the eye, and it should be the first objective measurement obtained after the history. Obtaining visual acuity in a child will depend on the child’s age and level of development. A child  months to  years old should be able to fix and follow a face, toy, or light; a child  to  years old should have a visual acuity of 20/40 or better with one line acuity difference between eyes; and a child >5 years old should
 have a visual acuity of 20/25 or better with no acuity difference between eyes. Several different eye charts can be used to check distance visual acuity in children, including the Snellen, Allen picture, and tumbling E charts. If the child knows letters of the alphabet (typically  to  years of age), use the standard Snellen eye chart. Consider using the tumbling E chart if the child is illiterate or has a cognitive disability. To use the Snellen chart, check acuity at a distance of  ft. When using the Allen picture or tumbling E chart, assess acuity at a distance of  ft.
Check acuity in the nonaffected eye first to establish baseline function. Assess visual acuity with the child’s glasses. If not available, then use a commercial pinhole occluder or a card with five to six holes created with an 18­gauge needle. If the child is unable to read the top line of an eye chart, then ask to count fingers and see motion. If the child is unable to see motion, then shine a bright light into the eye and document the presence or absence of light perception.
For visual acuity in children from approximately  months to  years of age, use a brightly colored object, light source, or moving toy to attract the child’s attention. See if the child is able to follow it with both eyes and then with each eye individually with the opposite eye occluded.
Extraocular movements can be assessed after visual acuity. Relieving pain will make your exam much easier, especially in a child unwilling to open his or her eye. With the patient supine, analgesic drops can be applied to the space between the medial canthus and the nose. The drops will flow into the eye when the child eventually opens his or her eye.
EXAMINATION OF PUPILS AND FUNDUS
Older and more cooperative children can be examined sitting independently or on a parent’s lap. Infants, toddlers, developmentally delayed children, and uncooperative children may need to be swaddled in a sheet. Some patients require an eyelid retractor to examine the eye.
First, document pupil diameter in ambient light. If the difference between pupils is .5 mm or greater, then anisocoria exists. A greater size discrepancy in a dark room when compared with a light room indicates physiologic anisocoria, which is of no clinical significance. It is also important to look for leukocoria (white appearance of pupil), which may be indicative of problems with the cornea, lens, or anterior or posterior chamber. Leukocoria is discussed later in the chapter.
Next, check the direct and consensual light reflexes. Then assess for a relative afferent pupillary defect, a sign of unilateral optic neuropathy. Some children will have a small amount of pupillary movement (dilation and contraction) in the consensual eye when the light is swung from the direct to the consensual eye. This is pupillary escape and can be a normal response.

Continue with examination of the red reflex, which should be performed in children of all ages. In a dimly lit room, look at the pupils through the direct ophthalmoscope or panoptic scope; position yourself at the patient’s eye level about  to  ft. away. Document the presence or absence of the red reflex for each eye (Figure 122­2). With older children, perform the same funduscopic examination that you would in an adult.
FIGURE 122­2. Normal red reflexes. [Reproduced with permission from Shah BR, Lucchesi M: Atlas of Pediatric Emergency Medicine. © 2006, McGraw­Hill, Inc., New
York, Figure 8­18.]
STRABISMUS
Strabismus is ocular misalignment. Knowledge of preexisting strabismus helps differentiate between congenital/childhood strabismus and acquired emergent causes of strabismus. Misalignment can be described as a “tropia,” or constant misalignment, or a “phoria,” or intermittent misalignment, such as when the patient is tired or fusion is broken. With a “phoria,” the eyes will revert to normal (equal) alignment when both eyes are uncovered.
Terminology used to describe strabismus is listed in Table 122­1. Normal newborns may have transient misalignment that usually improves by  to 
 months of age as the strength of extraocular muscles improves. Amblyopia is a loss of visual acuity not correctable by glasses in an otherwise healthy eye. Uncorrected strabismus can cause amblyopia. If children have unilateral visual impairment, their brain will “choose” the image presented by the eye with better vision. If amblyopia is not corrected by about age  years old, the brain eventually suppresses visual information presented by the impaired eye, leading to permanent vision loss.
TABLE 122­1
Strabismus Terminology
Term Description
Esotropia Inward eye deviation
Exotropia Outward eye deviation
Hypertropia Upward eye deviation
Hypotropia Downward eye deviation
Esophoria Inward eye deviation when the other eye is covered
Exophoria Outward eye deviation when the other eye is covered
CAUSES OF STRABISMUS
Emergent causes of strabismus include cranial nerve palsy and muscle restriction or entrapment that may be associated with trauma, stroke, tumor, aneurysm, thyroid­associated orbitopathy or other infiltrative process, increased intracranial pressure, or infection. The innervation of the extraocular muscles defines which cranial nerve is involved. Cranial nerve VI innervates the ipsilateral lateral rectus muscle, and palsy will lead to esotropia. Cranial nerve IV innervates the ipsilateral superior oblique muscle, and palsy will cause hypertropia. Cranial nerve III innervates all other extraocular muscles, and palsy will lead to exotropia, hypertropia or hypotropia (depending on which branch is affected), and ptosis.
DIAGNOSIS AND MANAGEMENT
Strabismus is usually suspected after general inspection. Some children have epicanthal folds that lead to pseudostrabismus, or the appearance of ocular misalignment, when the eyes are in fact in proper alignment (Figure 122­3). Two simple tests can identify true strabismus.
FIGURE 122­3. Pseudostrabismus.
Begin with the Hirschberg test by holding a penlight several feet from the child and observe the reflection of the light on each cornea. In normal ocular alignment (pseudostrabismus), the light reflection will appear on the same position of each eye. In true strabismus, the light reflection will not be on the same position of each eye. Then, perform a cover test. Have the child fixate on a distant object and then cover one of the child’s eyes. If the uncovered eye then moves, it can be assumed that it was not properly fixated on the object and true strabismus is present. When the eyes are uncovered, they will revert to their original misalignment.
Historical clues to an emergent cause of strabismus include trauma, diplopia, report of abnormal extraocular movements, sunsetting of the eyes
(upgaze deficit), nausea, vomiting, and lethargy. If an emergent cause of strabismus is suspected, obtain imaging directed at the suspected condition.
Congenital strabismus caused by extraocular muscle weakness usually self­resolves in infancy. Stable strabismus that persists into childhood should be referred nonemergently to an ophthalmologist. Strabismus caused by amblyopia often resolves with glasses that equalize the vision, although a patch over the “good” eye or surgical correction may be required.
LACRIMAL SYSTEM PROBLEMS
Tears are produced in the lacrimal gland and drain at the medial aspect of the eye through the nasolacrimal duct and lacrimal sac through the canalicular system to the Hasner valve and finally into the nose. Several common problems seen in pediatrics can arise in the gland and canalicular system.
DACRYOSTENOSIS
Dacryostenosis, or nasolacrimal duct obstruction, is a narrowing or obstruction of the nasolacrimal duct. It occurs in 6% of all newborns and usually
 resolves with conservative management. Dacryostenosis is a common condition presenting to the ED, and infants may present with epiphora, eyelash matting, and tears that appear thicker and yellowish in color, which may be mistaken by parents as infection. Fluorescein applied to the eye and left for
 minutes will accumulate, whereas it normally would be cleared by the lacrimal system. An important clinical feature is the lack of accompanying signs or symptoms, such as fever, irritability, or conjunctivitis. If the conjunctiva are not inflamed, the cause is dacryostenosis with evaporation of the aqueous layer of poorly draining tears, which leaves the yellow mucus layer behind and mimics conjunctivitis.
Treatment of dacryostenosis is supportive and does not require antibiotics. Teach parents gentle massage with a downward motion to the nasolacrimal duct three to four times a day. If still present after  months of age, ophthalmology referral is indicated for possible dilation of the duct.
DACRYOCYSTITIS
Inflammation and bacterial superinfection of the lacrimal sac will cause dacryocystitis. Common pathogens are Streptococcus pneumoniae,
,7 staphylococci, and Haemophilus influenzae. Patients develop a chronic mucopurulent discharge followed by erythema and swelling inframedially to the eye (Figure 122­4).
FIGURE 122­4. Dacryocystitis. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, Inc., New
York, Figure 2­10.]
In children of all ages, dacryocystitis is usually a secondary bacterial infection following a viral upper respiratory infection. The diagnosis is made when gentle pressure with a finger or cotton swab applied to the nasolacrimal sac causes a reflux of mucopurulent material. The discharge should be cultured to identify the causative agent.
Improperly treated dacryocystitis may lead to periorbital and orbital cellulitis. Children are often quite ill and require hospital admission
,9 with parenteral antibiotics until the infection begins to improve. A cephalosporin, such as cefuroxime (50 milligrams/kg IV every  hours) or cefazolin
(33 milligrams/kg IV every  hours), may be used, or clindamycin (10 milligrams/kg IV every  hours) may be used for penicillin­allergic patients. If
,10 methicillin­resistant Staphylococcus aureus is suspected, vancomycin (10 to  milligrams/kg IV every  to  hours) is indicated.
DACRYOCELE
A dacryocele is a small, bluish­hued, palpable mass in the location of the nasolacrimal duct (inferior and medial to the eye) without conjunctival
 erythema, discharge, or other pathologic findings. It is caused by an obstruction at the valve of Hasner and the common canaliculus. Due to possible
 need for marsupialization, patients should be urgently referred to a pediatric otolaryngologist or ophthalmologist.
DACRYOADENITIS
Dacryoadenitis is inflammation of the lacrimal gland and can be acute or chronic. Chronic dacryoadenitis is caused by noninfectious inflammatory disorders such as Sjögren’s syndrome, sarcoidosis, or thyroid disease. Acute dacryoadenitis is usually infectious. In both acute and chronic disease, children will have soft tissue swelling, especially in the region of the lateral upper lid. With infectious causes, systemic symptoms such as malaise and fever may also be present.
Viral dacryoadenitis causes less intense discomfort and erythema than bacterial dacryoadenitis. Causative viral pathogens include Epstein­Barr virus, mumps virus, coxsackievirus, cytomegalovirus, and varicella­zoster virus. Bacterial dacryoadenitis is associated with intense eye discomfort, tenderness, and erythema. The most common causative bacterial pathogen causing dacryoadenitis is S. aureus, although streptococci, Neisseria
 gonorrhoeae, Chlamydia trachomatis, and Brucella melitensis have also been implicated.
The first­line treatment of bacterial dacryoadenitis is oral or parenteral antibiotics against S. aureus. For mild infections, an oral first­generation cephalosporin, such as cephalexin (25 milligrams/kg PO every  hours), until the infection has resolved is appropriate. If methicillin­resistant S. aureus is suspected, sulfamethoxazole­trimethoprim (10 mg/killigram PO [or IV] every  hours) or linezolid (10 milligrams/kg PO [or IV] every  hours) may be used. For more severe infections, parenteral antibiotic therapy is indicated. Nafcillin (37.5 milligrams/kg IV every  hours) is appropriate when methicillin­resistant S. aureus is not suspected. Vancomycin (10 to  milligrams/kg IV every  to  hours) is indicated for severe dacryoadenitis caused
 by methicillin­resistant S. aureus.
BLEPHARITIS
Blepharitis is inflammation of the eyelid that may present with eye redness, tearing, photophobia, crusting of the lid margin, swelling, or pruritus.
Anterior blepharitis is usually infectious in nature (staphylococci) and presents with crusting and debris around the base of the eyelashes and red, irritated skin. Posterior blepharitis affects the conjunctival surface of the eyelid, usually due to meibomian gland dysfunction, and presents with
 inflammation of the posterior lid margin and eye irritation. Both types of blepharitis are treated with warm compresses and baby shampoo scrubs once to twice daily. Have caregivers apply shampoo to a washcloth and then gently scrub the eyelids. This should be continued until symptoms have resolved completely, which usually requires prolonged treatment. In addition, staphylococcal blepharitis should be treated with erythromycin or
 bacitracin­polymyxin ointment one to three times a day for  days, with the length of treatment depending on severity.
PERIORBITAL AND ORBITAL CELLULITIS
The orbital septum is a connective tissue extension of the orbital periosteum that extends into the upper and lower eyelids and acts as a barrier to the spread of infection. However, infection can be facilitated by the valveless drainage system of the midface region that permits bacteria to travel
 hematogenously in an anterograde fashion (i.e., away from the heart) despite a retrograde venous system. Periorbital, or preseptal, cellulitis must be distinguished from orbital, or postseptal, cellulitis. The diagnosis may be difficult clinically, and imaging is often required to make the appropriate diagnosis.
PERIORBITAL CELLULITIS
The average age of presentation with periorbital cellulitis is  years old. Periorbital cellulitis can be caused by local infection, hematogenous spread, and extension of sinusitis.
Local infection, such as conjunctivitis, dacryoadenitis, dacryocystitis, hordeolum, or even a minor traumatic cellulitis after an insect bite or small scratch, can spread to the periorbital area (Figure 122­5).
FIGURE 122­5. Preseptal cellulitis. Left periorbital cellulitis with edema and erythema of the eyelids in a nontoxic cooperative toddler with a normal ocular exam.
(Photo contributor: Kevin J. Knoop, MD, MS. Reproduced with permission from Knoop KJ, Stack LB, Storrow AB, Thurman RJ (eds). The Atlas of
Emergency Medicine, 4th ed. © 2016, McGraw Hill Education, Inc., New York, Figure .67, Pg 468.)
Hematogenous spread of nasopharyngeal pathogens can also lead to periorbital cellulitis. Affected children tend to be younger (often <18 months old) and have a history of a viral upper respiratory infection followed by abrupt onset of fever and eyelid swelling. The most common pathogens are S.
 pneumoniae and Streptococcus pyogenes.
Finally, periorbital cellulitis may be the result of acute sinusitis. Sinusitis can be associated with reactive edema and mild inflammation of the eyelids noted upon awakening that regresses during the day as dependent edema resolves. Unilateral periorbital edema that does not regress may indicate cellulitis. Bacteria that cause sinusitis, such as S. pneumoniae, nontypeable H. influenzae, and Moraxella catarrhalis, are the most common pathogens
 for this type of periorbital cellulitis.
CLINICAL FEATURES AND DIAGNOSIS
Periorbital (preseptal) cellulitis is characterized by an erythematous, tender, indurated, swollen, and warm eyelid and periorbital area. There is no associated decrease in visual acuity, conjunctival injection, impairment of extraocular movements, proptosis, pain with eye movement, or other intraorbital pathology. It may not be possible to always differentiate clinically between an insect bite near the eye, a mild allergic reaction, and early periorbital cellulitis. Children with moderate to severe periorbital cellulitis may have difficulty opening their eyelids for the examiner, so eyelid retractors may be required to fully examine the eye and its movements. A CT scan of the orbits can differentiate between periorbital cellulitis and the often more severe but less common orbital cellulitis.
TREATMENT, DISPOSITION, AND FOLLOW­UP
Children with periorbital cellulitis who are well appearing and are afebrile are candidates for outpatient oral antibiotic therapy. Amoxicillin­clavulanate
(20 milligrams/kg PO twice a day) is appropriate oral therapy. Those with more severe periorbital cellulitis or in whom hematogenous spread is suspected require parenteral therapy and hospitalization. Cefuroxime (50 milligrams/kg IV every  hours), ceftriaxone (50 milligrams/kg IV every  hours), or ampicillin­sulbactam (50 milligrams/kg IV every  hours) are appropriate choices. Add vancomycin if methicillin­resistant S. aureus is
,8 suspected.
ORBITAL CELLULITIS
Orbital cellulitis is usually an extension of a sinus infection into the orbit behind the septum but may also be spread hematogenously or from traumatic inoculation (Figures 122­6 and 122­7). The average age of presentation is  years old. Complications include subperiosteal abscess, orbital abscess, cavernous sinus thrombosis, panophthalmitis, or endophthalmitis. The most common bacterial pathogens are S. pneumoniae, M. catarrhalis, S.
 aureus, S. pyogenes, and anaerobic upper respiratory flora such as Bacteroides and Fusobacterium species. Nontypeable H. influenzae remains a
 pathogen in the postvaccine era.
FIGURE 122­6. A. Orbital cellulitis. Left orbital cellulitis with subperiosteal abscess and extensive ethmoid and maxillary sinusitis are seen in this postcontrast CT scan.
B. About 75% to 90% of cases of orbital cellulitis are associated with either preceding or concurrent acute paranasal sinusitis (commonly involved sinuses: ethmoid, maxillary, and frontal). [Reproduced with permission from Shah BR, Lucchesi M, Amodio J (eds): Atlas of Pediatric Emergency
Medicine, 2nd ed. © 2013, McGraw­Hill Education, New York, Figure 8­3A&B, Pg 311. Photo contributor: John Amodio, MD.]
FIGURE 122­7. Orbital cellulitis. Severe proptosis, malalignment of globe with restriction of eye movements, swelling of eyelids, and unilateral eye involvement.
[Photo contributor: Binita R. Shah, MD.]
CLINICAL FEATURES AND DIAGNOSIS
Orbital cellulitis is characterized by erythema and swelling around the eye. Suspect orbital cellulitis if the eyelid or periorbital inflammation is accompanied by any of the following: proptosis, impaired extraocular movements, pain with eye movement, decreased visual
 acuity, chemosis, or an afferent pupillary defect (see Figure 241­8). Fever may or may not be present.
Diagnosis of orbital cellulitis is primarily clinical, but an orbital and sinus CT differentiates between periorbital and orbital cellulitis and can identify a
 concomitant abscess or other pathology. CT findings are also useful to predict the need for surgical intervention. Culture of the blood, nares, and conjunctiva may be obtained to help identify the bacterial source. After neuroimaging, consider lumbar puncture for symptoms such as headache, lethargy, neurologic symptoms, or toxic appearance to exclude associated meningitis.
TREATMENT, DISPOSITION, AND FOLLOW­UP
Orbital cellulitis requires inpatient management. Consult otolaryngology and ophthalmology for evaluation and possible surgical drainage of abscesses. Parenteral therapy is indicated until significant clinical improvement is noted, followed by oral antibiotics to complete a 3­week course.
Cefuroxime (50 milligrams/kg IV every  hours) and ampicillin­sulbactam (50 milligrams/kg IV every  hours) are appropriate first­line antibiotics. If cefuroxime is used or if an anaerobic infection is strongly suspected, add clindamycin (10 milligrams/kg IV every  hours) or metronidazole (15
,8 milligrams/kg IV every  hours). Also add vancomycin for life­threatening infections or suspected methicillin­resistant S. aureus.
THE RED EYE
There are many problems that may produce a red eye in a child. In this section, we focus on the most common pediatric complaints, corneal abrasion and conjunctivitis, and then discuss other pertinent pediatric problems, including Kawasaki’s disease and pediculosis. Inflammatory conditions including scleritis, episcleritis, uveitis, and iritis are covered in Chapter 241. CORNEAL ABRASION
CLINICAL FEATURES
Corneal abrasions in older children are characterized by a foreign body sensation, pain, photophobia, injection, and a history of direct trauma, ultraviolet light exposure, or pain from windblown particulate matter in the eye. Smaller children and infants often lack a history of trauma to the eye and may present with a chief complaint of inconsolable crying and an otherwise normal physical examination. If instillation of an anesthetic drop such as tetracaine .5% onto the surface of the eye calms the child, it strongly suggests that injury to the surface of the eye may be the source of the child’s distress.
DIAGNOSIS AND TREATMENT
A thorough eye examination with instillation of fluorescein confirms the diagnosis of corneal abrasion. An abrasion will fluoresce to a yellow­green color under the cobalt blue filter in the slit lamp or handheld Wood’s lamp. The presence of a vertical linear abrasion suggests the presence of a retained foreign body, so make sure to evert the upper eyelid and examine the superior conjunctiva. If details on the iris are not visible due to corneal
 opacification, this may indicate a corneal ulcer, needing an emergency ophthalmology consult.

Treatment of a corneal abrasion is erythromycin or bacitracin­polymyxin ophthalmic ointment to help avoid superinfection and provide lubrication.

See treatment for abrasions in contact lens wearers below. Avoid ointments containing neomycin due to hypersensitivity reactions. Cyclopentolate
.5% drops may alleviate pain by reducing ciliary spasm. Occasionally nonsteroidal anti­inflammatory drops are also used (such as ketorolac), but the
 evidence is not robust. Eye patching is not routinely recommended but may be useful for any child who frequently attempts to scratch or rub the
 injured eye. Instillation of topical anesthetics at home is currently not recommended. Although the need for tetanus prophylaxis of a corneal abrasion is debatable, the ED visit should be used to remind the caregiver to check the child’s tetanus status with the primary care provider. In a
 tetanus­prone injury, using the same criteria as a standard skin abrasion, updating unknown tetanus status is recommended.
For uncomplicated and simple corneal abrasions, recommend follow­up in  hours with the pediatrician or other primary care provider. Children with involvement of the visual axis should follow up the next day with ophthalmology. Children or adolescents who use contact lenses, have a history of herpes, or may have a retained foreign body should also be evaluated by an ophthalmologist. If the child wears contact lenses, give tobramycin ophthalmic solution to treat Pseudomonas. Ciprofloxacin and ofloxacin ophthalmic are acceptable options for children due to limited absorption.
Discard that set of contact lenses. Do not resume contact lens use until approved by the ophthalmologist. Corneal abrasions heal quickly, and patients who continue to have foreign body sensation  to  days after initial presentation require urgent ophthalmologic reevaluation.
OPHTHALMIA NEONATORUM
Ophthalmia neonatorum is conjunctivitis in neonates up to  days old. The five primary categories of neonatal conjunctivitis are chemical, gonococcal, chlamydial, other bacterial, and viral (Table 122­2). Gonococcal, chlamydial, and viral neonatal conjunctivitis can all lead to severe morbidity. Although specific diagnoses and treatments are discussed in the following sections, in the ED, it may not be possible to determine the specific etiology. A rapid Gram stain of discharge should be obtained in all cases and will aid in management.
TABLE 122­2
Ophthalmia Neonatorum
Age of
Type Cause Key Findings Treatment
Presentation
Chemical Erythromycin ointment prophylaxis  h Bilateral, watery discharge, Watchful negative Gram stain waiting
Gonococcal Neisseria gonorrhoeae 2–7 d Intense chemosis, copious Admission, IV discharge, gram­negative diplococci antibiotics on Gram stain
Chlamydial Chlamydia trachomatis 7–14 d Intense erythema, purulent Admission, PO discharge and topical antibiotics
Other Staphylococcus aureus, nontypeable Haemophilus 7–14 d Identify etiology on Gram stain Topical bacterial influenzae, Staphylococcus epidermidis, Escherichia coli, antibiotics
Pseudomonas
Viral HSV­2, less commonly HSV­1 14–28 d Dendrites on fluorescein exam Admission, IV and topical antivirals
Abbreviation: HSV = herpes simplex virus.
CHEMICAL OPHTHALMIA NEONATORUM

Chemical conjunctivitis occurs in the first  hours of life following erythromycin ointment prophylaxis. Infants present with bilateral conjunctivitis, inflamed eyelids, and watery discharge. Gram stain of the discharge would reveal the absence of pathologic bacteria and only a few WBCs. Treatment of neonatal chemical conjunctivitis is watchful waiting. Symptoms should resolve within  hours. Erythromycin prophylaxis is often used at birth to diminish the risk of conjunctivitis caused by N. gonorrhoeae, although this practice has become controversial. The Canadian Paediatric Society advises
,20 against routine use, while the American Academy of Pediatrics continues to recommend prophylaxis for all newborns.
GONOCOCCAL OPHTHALMIA NEONATORUM
Gonococcal conjunctivitis usually presents at  to  days of life with intense bilateral bulbar conjunctival erythema, chemosis, and a copious purulent discharge (Figure 122­8). The diagnosis is made by Gram stain, revealing gram­negative diplococci, and culture using chocolate
 agar. Admit all infants with gonococcal conjunctivitis, obtain ophthalmology consultation, and evaluate for disseminated disease.
Test blood, urine, cerebrospinal fluid, and any other sites with suspected infection. Therapy for isolated conjunctivitis in a neonate without hyperbilirubinemia is a single dose of parenteral ceftriaxone (50 milligrams/kg IV; maximum, 125 milligrams). To avoid exacerbation of hyperbilirubinemia or if disseminated infection is suspected and longer­term antibiotics are required, use cefotaxime (50 milligrams/kg IV every  hours). Irrigate the infant’s eyes with normal saline frequently to eliminate the purulent discharge. Gonococcal ophthalmia neonatorum may progress to ulceration and perforation of the cornea if improperly treated.
FIGURE 122­8. Gonococcal ophthalmia. Copious purulent drainage in a newborn with neonatal gonococcal conjunctivitis. [Reproduced with permission from Eye
Care Skills: Presentations for Physicians and Other Health Care Professionals, Version .0: Eye Trauma and Emergencies. American Academy of
Ophthalmology, Copyright © 2009.]
CHLAMYDIAL OPHTHALMIA NEONATORUM
Symptoms of chlamydial conjunctivitis present slightly later than those caused by gonorrhea, typically around  to  days of age. Signs are unilateral or bilateral purulent discharge with intense erythema of the palpebral conjunctiva (Figure 122­9). Chlamydial ophthalmia may be associated with chlamydial pneumonia. Diagnosis is confirmed with Giemsa stain, culture, or nucleic acid amplification of conjunctival scrapings. Treat chlamydial conjunctivitis with or without associated pneumonia with a 14­day course of oral erythromycin (12.5 milligrams/kg PO every  hours) and erythromycin
 ophthalmic ointment. Ophthalmology consultation is recommended. Patients with isolated chlamydial ophthalmia who do not have respiratory symptoms or evidence of pneumonia may be safely discharged to home with follow­up in  hours.
FIGURE 122­9. A and B. Conjunctivitis due to Chlamydia trachomatis is the most common infectious cause of ophthalmia neonatorum. This 10­day­old neonate presented with lid swelling with erythema and mild mucopurulent eye discharge. Intense hyperemia of the palpebral conjunctiva is seen (B). Direct fluorescent antibody staining for elementary bodies was positive, and both Gram stain and culture were negative for Neisseria gonorrhoeae. [Photo contributor: Binita R. Shah, MD.]
OTHER BACTERIAL OPHTHALMIA NEONATORUM
Bacterial conjunctivitis due to bacteria other than chlamydia and gonorrhea is also less common when erythromycin topical prophylaxis has been
 given. The most common bacterial pathogens are S. aureus, nontypeable H. influenzae, Staphylococcus epidermidis, Escherichia coli, and

Pseudomonas. Symptoms are variable and usually begin within  weeks of birth with hyperemia, purulent discharge, and edema. Gram stain and culture will identify the cause. Parenteral or oral therapy is not necessary in almost all cases, except nontypeable H. influenzae, and topical therapy
 with bacitracin­polymyxin ointment is sufficient. Nontypeable H. influenzae requires admission to the hospital, a full septic workup, and parenteral antibiotics.
VIRAL OPHTHALMIA NEONATORUM
Viral neonatal ophthalmia, caused by herpes simplex virus types  and , is a rare cause of neonatal conjunctivitis. Because there is a significant risk of keratitis and devastating disseminated infection, early identification and treatment are critical. Symptoms develop at  to  days of life with bilateral lid edema and conjunctival erythema. Suspect herpes infection in a neonate with associated mucocutaneous lesions and a maternal history of herpes; however, a history of maternal infection is not necessary for the diagnosis. Herpes conjunctivitis is confirmed with the presence of keratitis or corneal dendrites on fluorescein examination and viral culture or nucleic amplification tests. Neonates with suspected herpetic ophthalmia require hospital admission, full septic evaluation (including lumbar puncture with herpes polymerase chain reaction testing of cerebrospinal fluid), IV acyclovir (20
 milligrams/kg IV every  hours for  to  days), and topical antivirals (1% trifluridine, .1% iododeoxyuridine, or .15% ganciclovir). Steroid drops should be strictly avoided in herpes conjunctivitis.
CHILDHOOD CONJUNCTIVITIS
Conjunctivitis, or inflammation of the conjunctiva, is very common in children and may be caused by viruses, bacteria, or allergy; less commonly, it may be a symptom of a systemic disease. Each type of conjunctivitis is discussed in the following sections.
VIRAL CONJUNCTIVITIS
Viral conjunctivitis in childhood is most frequently caused by adenovirus. Less frequent pathogens are rhinovirus, enteroviruses, influenza, and

Epstein­Barr virus. Measles virus can also cause conjunctivitis but is an unlikely diagnosis with proper childhood immunization. Measles outbreaks can occur among unimmunized populations. Conjunctivitis caused by the herpes viruses requires immediate therapy to prevent permanent vision loss and is covered separately below.
Viral conjunctivitis has several distinct presentations. Pharyngoconjunctival fever presents with fever, acute onset of conjunctivitis, pharyngitis, and preauricular adenopathy, and may be unilateral or bilateral. Epidemic keratoconjunctivitis can present with pain, photophobia, subepithelial defects, and pseudomembranes over the conjunctiva, and is usually bilateral. Follicular conjunctivitis often presents with a foreign body sensation and erythema of the conjunctiva. On examination, an aggregation of lymphocytes around networks of blood vessels in the conjunctiva will give the appearance of follicles. Finally, acute hemorrhagic conjunctivitis presents with hyperemic conjunctiva, subconjunctival hemorrhages, chemosis, swelling, photophobia, and pain. Figure 122­10 shows a child with adenoviral conjunctivitis.
FIGURE 122­10. Adenoviral conjunctivitis. [Reproduced with permission from Shah BR, Lucchesi M: Atlas of Pediatric Emergency Medicine. © 2006, McGraw­Hill, Inc.,
New York, Figure 8­3.]
The treatment of these categories of viral conjunctivitis is supportive only. Cool compresses may offer patients symptomatic relief. Artificial tears and topical vasoconstrictors may improve redness and the sensation of dryness. Topical antibiotics should not be prescribed because there is no
 evidence of protection against secondary infections and there is suspicion of harm. Symptoms may last  to  weeks, and patients should be referred to ophthalmology if conjunctivitis is persistent or worsening. Viral conjunctivitis is very contagious, and families should not share face cloths, towels, or pillows.
HERPES VIRUS CONJUNCTIVITIS
Conjunctivitis caused by varicella most often occurs during primary infections. However, it can also occur with herpes zoster ophthalmicus, which is when the varicella virus lies dormant in the trigeminal nerve and causes recurrent vesicles in the V distribution. Herpes simplex virus type  may
 also present similarly with unilateral vesicles in the same distribution. A typical dendritic pattern will be seen on the cornea with fluorescein examination.
Treat both primary and secondary varicella conjunctivitis presenting in the first  hours of symptoms with oral acyclovir (for age >2 years old: 
 milligrams/kg PO every  hours for  days; maximum dose, 3200 milligrams/d) and obtain ophthalmology consultation. Similarly, herpes simplex infections of the eye in children also require ophthalmology consultation but may be treated with topical antivirals such as trifluridine,
 iododeoxyuridine, or ganciclovir. Topical steroids may be prescribed by an ophthalmologist for both varicella and herpes simplex infections of the eye but should not be prescribed by the emergency physician.
CHILDHOOD BACTERIAL CONJUNCTIVITIS

Bacterial conjunctivitis in childhood is most frequently caused by Haemophilus species, S. pneumoniae, M. catarrhalis, and S. aureus. Less common pathogens include Pseudomonas aeruginosa, group B Streptococcus, E. coli, and Neisseria meningitidis. Oculoglandular syndrome is a rare infection often caused by Bartonella henselae (cat­scratch disease) or Francisella tularensis (tularemia), which causes ipsilateral conjunctivitis and lymphadenopathy, often axillary. Physical exam findings include normal vision, mucopurulent matting of the lashes (especially after sleep), and eyelid edema. Photophobia and eye pain are not present, although patients will have some discomfort. Consider chlamydial and gonococcal conjunctivitis in the differential diagnosis, especially in sexually active adolescents and neonates.
The diagnosis of bacterial conjunctivitis is primarily clinical. If patients have concomitant otitis media, the diagnosis is most likely conjunctivitis­otitis syndrome caused by nontypeable H. influenzae; prescribe oral antibiotics. Otherwise, treat with a broad­spectrum topical antibiotic such as a fluoroquinolone (ciprofloxacin or ofloxacin ophthalmic, which, due to limited absorption, are acceptable for use in children), bacitracin­polymyxin, or
 trimethoprim­polymyxin. An ointment is preferable to eyedrops. Although erythromycin ointment is inexpensive, it does not provide adequate coverage for H. influenzae or M. catarrhalis. Therefore, if erythromycin ointment has been prescribed and the patient is not clinically improving, change the topical antibiotic ointment.
Patients with isolated bacterial conjunctivitis or conjunctivitis­otitis syndrome may be safely discharged to home. Symptoms that do not improve after
 days of therapy merit ophthalmology referral.
It may be difficult in the ED to differentiate bacterial from viral conjunctivitis. In addition to the earlier noted differences, clues to bacterial etiology include history of discharge causing eyelash matting and mucoid or mucopurulent discharge on exam. Viral conjunctivitis is likely in the presence of
 preauricular lymphadenopathy, recent respiratory illness, and conjunctivitis that spreads among close contacts. Consider a swab of the conjunctiva for severe or recurrent cases.
ALLERGIC CONJUNCTIVITIS
Children with a history of atopy are most likely to suffer allergic conjunctivitis, but almost any child can be affected. Children with allergic conjunctivitis may have bilateral itchy eyes, tearing, thin mucoid discharge, mild redness, and eyelid edema, as well as chemosis. In severe cases, patients may have mild photophobia. Treat allergic conjunctivitis with allergen avoidance, topical antihistamines, and mast cell stabilizers. Ketotifen (one drop to each eye every  to  hours) and olopatadine (one to two drops to each eye daily), which are both antihistamines and mast cell stabilizers, are very
 effective. Topical NSAIDs, vasoconstrictors, and lubricants may provide symptomatic relief. Cool compresses may also be beneficial. Oral antihistamines are discouraged because they can cause eye dryness, exacerbating symptoms.
KAWASAKI’S DISEASE
Kawasaki’s disease, a severe medium­sized vessel vasculitis that can cause coronary artery aneurysms, predominantly presents in children  to  years of age (see Chapter 142, “Rashes in Infants and Children”). Nonpurulent bilateral conjunctivitis is a key diagnostic feature of Kawasaki’s disease. In typical cases, patients have a fever (>5 days), dry and erythematous lips and oropharynx, enlarged cervical lymph node (>1.5 cm), nonvesicular rash, edema, or peeling of the hands and feet. A diagnosis of Kawasaki’s disease requires inpatient admission, IV γ­globulin, aspirin therapy, cardiology consult, and, in most institutions, either infectious disease or rheumatology consultations.
PEDICULOSIS
Lice can infest the eyelashes of a child of any age, leading to itching and scratching, with a mild conjunctivitis caused by the louse’s saliva. Occasionally by scratching, children can cause a secondary bacterial infection or corneal abrasion.
Do not use pediculicide shampoos to treat pediculosis of the eyelashes because the shampoo is toxic to the eyes. Rather, attempt to remove nits (eggs) and then smother the lice with petroleum jelly or other ophthalmic ointment three times a day. Although the head and body louse may frequently involve the eyelashes of children, if Pthirus pubis (pubic louse) is identified, consider sexual abuse.
PEDIATRIC GLAUCOMA
Pediatric glaucoma is an important worldwide cause of visual impairment. Primary pediatric glaucoma is the result of dysgenesis of the chamber angle leading to decreased outflow of aqueous humor and increased intraocular pressure. In secondary glaucoma, aqueous outflow is diminished by systemic disease, scarring, trauma, inflammation, or infection. Primary pediatric glaucoma is more common than secondary glaucoma in children and
 is often familial. Estimates of incidence range from .31 to .41 per 100,000 births. Approximately 75% of cases are bilateral, and 80% of cases will present before  year of age. Pediatric syndromes associated with glaucoma include Sturge­Weber syndrome, Lowe’s syndrome, Down syndrome, neurofibromatosis, and maternal rubella syndrome. It is important to be familiar with the presenting signs of pediatric glaucoma so that proper ophthalmologic consultation and referral may be made.
Children with pediatric glaucoma will have a number of pathologic ocular signs and symptoms. Intraocular pressure will be elevated (≥20 mm Hg), and the cornea will appear enlarged and often cloudy and edematous (Figure 122­11). A full­term newborn cornea is nearly adult sized, with a horizontal
 diameter range of .0 to .5 mm versus .5 to .0 mm in an adult. Children <1 year of age should not have a corneal diameter >12 mm,
 and no child should have a corneal diameter >13 mm. There is associated blepharospasm, conjunctival injection, and myopia. The globe may appear enlarged. If the optic disc can be visualized, abnormal cupping or asymmetry may be found.
FIGURE 122­11. Infantile glaucoma. An enlarged, hazy cornea resulting from congenital glaucoma. [Reproduced with permission from Shah BR, Lucchesi M: Atlas of
Pediatric Emergency Medicine. © 2006, McGraw­Hill, Inc., New York, Figure 8­32.]
Consult ophthalmology, and initiate medical therapy of pediatric glaucoma to temporarily decrease intraocular pressure while awaiting definitive
 surgical repair. Therapies include oral and topical carbonic anhydrase inhibitors and topical β­blockers. Acetazolamide (3 milligrams/kg PO every  hours) can be used for short periods of time, and pediatric doses are prepared by crushing the tablets used for adults. Topical carbonic anhydrase inhibitors such as dorzolamide or brinzolamide may also be used with fewer systemic side effects. Topical β­blockers such as timolol .25% are recommended at a starting dose of one drop daily.
LEUKOCORIA
Leukocoria is a white­appearing pupil (Figure 122­12). Normally when a bright light is directed at the pupil, a red reflex appears as the light is reflected off the retina. With leukocoria, the red reflection is blocked. Despite routine screening during pediatric well­child examinations, leukocoria is frequently discovered by parents after a photograph with flash photography is noticed to have unequal “red eye.”
FIGURE 122­12. Cataract. [Reproduced with permission from Shah BR, Lucchesi M: Atlas of Pediatric Emergency Medicine. © 2006, McGraw­Hill, Inc., New York, Figure 8­
.]
Leukocoria has many causes, as listed in Table 122­3. Of patients age  to  years old presenting with leukocoria, up to 60% will have congenital
 cataracts and 18% will have retinoblastoma. Leukocoria requires prompt emergency evaluation by an ophthalmologist to avoid loss of vision or life.
TABLE 122­3
Causes of Leukocoria in Children
Congenital cataracts
Retinoblastoma
Retinal detachment
Retinoschisis
Retinopathy of prematurity
Falciform retinal fold
Persistent hyperplastic primary vitreous
Coats’ disease
Retinal coloboma
Endophthalmitis or panophthalmitis
Posterior uveitis
Vitreous hemorrhage
High myopia
Sarcoma
Corneal opacity
Phakomatosis
Other tumors
Ocular larva migrans
CATARACTS
Cataracts, in addition to retinopathy of prematurity, glaucoma, and abusive head trauma, are one of the most common avoidable causes of childhood
 visual impairment. Although cataracts are not treated in the ED, it is important for emergency providers to recognize and refer children with cataracts promptly to avoid permanent visual loss.

Pediatric cataracts can be unilateral or bilateral, and can be due to perinatal infection, or can be hereditary, or idiopathic. Hereditary cataracts can be inherited in an autosomal dominant or recessive pattern. Cataracts recognized in the neonatal period are most frequently from the TORCH infections
(toxoplasmosis, syphilis, rubella, cytomegalovirus, and herpes simplex). Cataracts may also be associated with a variety of systemic illnesses and syndromes such as Down syndrome, galactosemia, Lowe’s syndrome, Alport’s syndrome, homocystinuria, Wilson’s disease, and many more.
Children with cataracts present with any one of the following: leukocoria (Figure 122­12), strabismus, and/or nystagmus. On direct or slit lamp examination, lens opacities will be seen that can have partial or complete lens involvement, obscuring the retina.
Cataracts require referral to an ophthalmologist. Although there are a wide variety of surgical techniques used, generally central cataracts that are >3 mm warrant surgical removal. Children older than  years old may benefit from intraocular lens placement. Patients may also require surgery to repair concomitant strabismus.
RETINOBLASTOMA
The most common presenting signs of retinoblastoma are leukocoria and strabismus, and most children are identified by  years of age. Leukocoria in children with retinoblastoma is most often detected by family and friends (80% of cases), and less commonly by ophthalmologists (10%) and
 pediatricians (8%). Children may also present with proptosis, retinal detachment, glaucoma, hyphema, vitreous hemorrhage, and a red, painful eye due to ocular inflammation that may be confused with orbital cellulitis. Retinoblastoma is further discussed in Chapter 145, “Oncologic Emergencies in
Infants and Children.”
RETINAL HEMORRHAGES

The incidence of abusive head trauma is approximately .8 per 100,000 infants. Retinal hemorrhages are seen in approximately 75% to 80% of cases
 and are a sensitive finding for this diagnosis (Figure 122­13). Retinal hemorrhages appear to be caused by shaking of the infant’s head and are not
 sequelae of intracranial injury. Although retinal hemorrhages are pathognomonic of abusive head trauma in most settings, rarely, victims of a severe
 head crush injury have similar findings. Although children may suffer vision loss from ocular pathology, the most common cause of blindness in abusive head trauma is cortical blindness, rather than retinal hemorrhage. Obtain ophthalmologic consultation to detect retinal hemorrhage if child abuse is suspected. Child abuse is discussed in detail in Chapter 150, “Child Abuse and Neglect.”
FIGURE 122­13. Retinal hemorrhage. [Reproduced with permission from Knoop K, Stack L, Storrow A: Atlas of Emergency Medicine, 2nd ed. © 2002, McGraw­Hill, Inc.,
New York, Figure 15­33.]


