University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 29B: Mechanical Ventilation
Skyler Lentz; Patricia Ruth Atchinson; Matthew A. Roginski
INTRODUCTION
Content Update: Target light sedation after intubation December 2020
After successful intubation, target light sedation, not deep sedation. Use analgesia­first pain control followed by sedating agents to achieve light sedation. See detailed discussion in the section ‘Analgesia and Sedation in Mechanically Ventilated Patients’
MANAGING VENTILATOR SETTINGS
The primary function of mechanical ventilation is to provide respiratory support while treating the underlying process that caused respiratory failure.
Safe oxygenation and ventilation can be accomplished in either a volume­ or pressure­targeted mode. The chosen mode is often based on provider
,2 preference and experience. Patient outcomes are unlikely to be changed by the mode of ventilation.
VOLUME TARGETED
In a volume­targeted mode (e.g., volume control; Figure 29B­1), the ventilator provides an inspiratory flow over time to target a set volume. To avoid ventilator­induced injury, multiple trials have shown that limiting the tidal volume improves patient outcomes compared to using the larger volumes more common in the past (often ≥10 mL/kg to start). 3–6 One approach is to start volume­targeted ventilation at  mL/kg ideal body weight for patients with or at risk for acute respiratory distress syndrome and  to  mL/kg ideal body weight for other patients. The definition of acute respiratory distress syndrome is provided in Table 29B­1. Those at risk for acute respiratory distress syndrome have pneumonia, sepsis, trauma, pancreatitis, or any
 shock state. To choose ventilation settings, calculate ideal body weight using the patient’s height, an important caveat in obese patients in whom harm is risked if tidal volumes choice is based on actual body weight.
FIGURE 29B­1
Normal ventilator waveforms for volume control with a square inspiratory waveform flow. Yellow is the pressure waveform, green is the flow waveform, and blue is the volume waveform. This figure is an example of volume control with a square inspiratory waveform where the tidal volume of
600 mL is delivered over  second. PEEP = positive end­expiratory pressure.

Chapter 29B: Mechanical Ventilation, Skyler Lentz; Patricia Ruth Atchinson; Matthew A. Roginski 
. Terms of Use * Privacy Policy * Notice * Accessibility
Table 29B­1
Acute Respiratory Distress Syndrome Definition (Berlin Definition)8
Onset within  week of a known clinical insult or new or worsening respiratory symptoms
Bilateral opacities on chest imaging not fully explained by lobar/lung collapse or nodules
Respiratory failure not fully explained by cardiac failure or volume overload
PaO /FIO ratio ≤300 mm Hg with PEEP ≥5 cm H O

Mild PaO /FIO 200–300 mm Hg

Moderate PaO /FIO 100–200 mm Hg

Severe PaO /FIO ≤100 mm Hg

Abbreviations: FIO = fraction of inspired oxygen; PaO = partial pressure of arterial oxygen; PEEP = positive end­expiratory pressure.

Source: Data from The ARDS Definition Task Force. Acute respiratory distress syndrome: the Berlin definition. JAMA 2012;307(23):2526­2533. In volume control mode, the airway pressures depend on the tidal volume plus the size and compliance of the respiratory system. Peak pressures are the highest pressures seen by the respiratory system and are measured every breath by the ventilator. They are a combination of airway resistance and alveolar and thoracic pressures. Peak pressures often reflect proximal airway resistance either in the endotracheal tube (as with mucous plugging or tube obstruction) or conducting airways (as with bronchospasm), but do not represent the pressure applied to the alveoli (Figure 29B­2). To approximate alveolar pressure, measure a plateau pressure with an end inspiratory pause in a passively breathing or paralyzed patient. The end
 inspiratory pause means flow in the respiratory circuit is zero and the pressure measured at the ventilator is the same at the alveolus (Figure 29B­3).
,4
Target a plateau pressure of <30 cm H O.

FIGURE 29B­2
Pressure waveform of a patient with high airway resistance from obstructed airways (e.g., chronic obstructive pulmonary disease or asthma). The high peak pressure and low plateau pressure indicate the problem is in the proximal airways. It also illustrates that the high peak pressure (69 cm H O) is
 not being transmitted to the alveoli.
FIGURE 29B­3
Pressure waveform of a patient with low lung compliance (i.e., acute respiratory distress syndrome). The plateau is  cm H O in this example. A high
 plateau pressure in relation to the peak pressure indicates that there is reduced pulmonary compliance and not proximal airway resistance.
PRESSURE TARGETED
In a pressure­targeted mode (e.g., pressure control), the ventilator will raise the airway pressures a prescribed amount over the positive end­expiratory pressure (PEEP) for a set amount of time (inspiratory time). The tidal volume depends on the resistance and compliance of the respiratory system. In pressure­control ventilation, follow tidal volumes and minute ventilation to ensure adequate ventilation. Start with a pressure control of  cm H O
 above PEEP and adjust the pressure up or down to target tidal volumes of  to  mL/kg ideal body weight. In a spontaneously breathing patient who is not intubated for severe hypoxemia or obstructive lung disease, consider transitioning to pressure support after a volume­targeted mode because the former may be more comfortable for the patient.
SYNCHRONOUS INTERMITTENT MANDATORY VENTILATION
Synchronous intermittent mandatory ventilation allows the patient to spontaneously breath between mandatory volume or pressure­targeted breaths. In this mode, the provider prescribes the mandatory breath type (volume or pressure targeted) and the amount of pressure support for spontaneous breaths. The set mandatory respiratory rate ensures a minimal minute ventilation. In heavily sedated or paralyzed patients not spontaneously breathing, synchronous intermittent mandatory ventilation is no different than pressure­ or volume­targeted control modes (i.e., volume control–assist control). Similarly, if the mandatory rate is set close to zero, almost all breaths will be spontaneous and appear more similar to pressure support. The type of breath delivered to spontaneously breathing patients depends on the timing of the triggered breath. If the breath is triggered near a mandatory breath time, the patient will receive a controlled breath. If the breath is triggered outside of the set timing of the mandatory
 breath, ventilator support will depend on the set pressure support. When using synchronous intermittent mandatory ventilation in critically ill patients, be sure to guarantee safe tidal volumes during spontaneous breaths.
RESPIRATORY RATE
The ideal respiratory rate depends on many factors. Most adult patients with normal respiratory physiology have adequate ventilation at a respiratory rate of  to  breaths/min. In sedated or paralyzed patients, the prescribed machine rate will be the actual respiratory rate. In patients who are triggering their own breaths, patients may determine their respiratory rate above the set rate. When deciding on a rate, anticipate demands; for example, in severe metabolic acidosis (e.g., diabetic ketoacidosis), set a high respiratory rate to maintain an adequate minute ventilation.
POSITIVE END­EXPIRATORY PRESSURE
Oxygenation can improve with mechanical ventilation by increasing the fraction of inspired oxygen (FIO ) or increasing the mean airway pressure with

PEEP. PEEP improves oxygenation by recruiting additional lung units, increasing the surface area for gas exchange, and redistributing lung water. Set initial PEEP at  cm H O in most patients. Obese patients or those with a tense abdomen require a higher PEEP; for these patients, start PEEP at  to 

 cm H O. When you encounter a patient who is difficult to oxygenate despite using these initial PEEP and FIO settings, titrate using a table (Table 29B­

2) to incrementally increase your PEEP until the desired oxygenation is achieved. Improvements through increased PEEP are not immediate, so use incremental changes in PEEP of  cm H O every  to  minutes rather than rapidly increasing or decreasing because there is potential for
 unanticipated hemodynamic, intrathoracic, or intrapulmonary changes.
Table 29B­2
Positive End­Expiratory Pressure (PEEP) Tables
Lower PEEP/higher FIO

FIO .3 .4 .4 .5 .5 .6 .7 .7

PEEP        
FIO .7 .8 .9 .9 .9 .0

PEEP      18–24
Higher PEEP/lower FIO

FIO .3 .3 .3 .3 .3 .4 .4 .5

PEEP        
FIO .5 .5–0.8 .8 .9 .0 .0

PEEP      
Abbreviation: FIO = fraction of inspired oxygen.

Source: Adapted from http://www.ardsnet.org/files/ventilator_protocol_2008­07.pdf (ARDSNet: NIH NHLBI ARDS Clinical Network Mechanical Ventilation Protocol
Summary). Accessed January , 2019. HYPEROXIA
11–13
Hyperoxia (too much supplemental oxygen) increases patient mortality in a dose­dependent relationship. Many recommend titrating the FIO to
 target an oxygen saturation of no greater than 96% as soon as the patient recovers from the apneic induction period (Table 29B­3).
Table 29B­3
Initial Ventilator Settings
Mode Volume control Pressure control
Control variable Tidal volume 6–8 mL/kg ideal body weight  cm H O

Measure­dependent variable Peak and plateau pressures Tidal volume
Respiratory rate 10–20 breaths/min
PEEP 5–8 cm H O

FIO Titrate to saturation of <96%

Abbreviations: FIO = fraction of inspired oxygen; PEEP = positive end­expiratory pressure.

ANALGESIA AND SEDATION IN MECHANICALLY VENTILATED PATIENTS
Sedation decisions during mechanical ventilation center on two fundamental questions: Does the ventilator need to be adjusted to accommodate the patient, or does the patient need to be sedated to accommodate the ventilator?how much sedation is needed? Not all patients require the same depth.
Patients intubated for severe hypoxic/hypoxemic or hypercapnic respiratory failure often need to be more deeply sedated to accommodate lung protective ventilation. Patients who are intubated for airway protection do not often require the same level of sedation as others being mechanically ventilated for pulmonary dysfunction. Finally, although often not an ED issue, ending sedation or using sedation holidays allows for more prompt return to spontaneous ventilation.
Target adequate analgesia before targeting sedation because pain can be a major source of agitation and discoordinated breathing. Use a standardized scale to assess pain and agitation, such as the Richmond Agitation­Sedation Scale(RASS)Table 29B­4. In the ED, target a RASS score of –2
14–16
(awakens and makes eye contact to voice) to  (awake, alert, and calm).
Table 29B­4
The Richmond Agitation­Sedation Scale(RASS) is an example of a validated scoring system for sedation.17 A lighter sedation target sedation of  to ­2 is recommended using pain control followed by sedative agents.
Score Description
+4 Combative (Combative or violent)
+3 Very agitated (pulls on or removes support devices)
+2 Agitated (Frequent non­purposeful movement or ventilator dyssynchrony)
+1 Restless or anxious
 Alert and calm
­1 Drowsy (awakens to voice for more than  seconds with eye contact to voice)
­2 Light Sedation (awakens for less than  seconds with eye contact to voice)
­3 Moderate Sedation (any movement but no eye contact to voice)
­4 Deep Sedation (no response to voice, but any movement with physical stimulation)
­5 Unarousable (no response to voice or physical stimulation)
After successful intubation, provide adequate analgesia and sedation to tolerate mechanical ventilation (Figure 29B­7) . If a longer acting neuromuscular blocking agent (e.g. rocuronium) is used for rapid sequence intubation, early analgesia and sedation is important to avoid patient awareness. Once the neuromuscular blockade has resolved, the recommended depth of sedation is ‘comfortable but easily awakened’. Target light
17–19 ,21 sedation. Avoid early deep sedation (i.e. ­3 to ­5 on RASS) as it is associated with worsened patient outcomes. Patients with severe hypoxemia or obstructive lung disease are important exceptions to the light sedation target, because such challenging patients may require deep sedation to target ventilator synchrony.
,19
The recommended approach from specialty guidelines is “analgesia­first” pain control followed by sedating agents as needed to achieve light sedation. Intravenous opioids (e.g. fentanyl, hydromorphone, morphine, etc.) delivered either as needed by intermittent dosing or continuous
 infusions are the first line therapy for pain in critically ill patients. Use multimodal pain control, including non­pharmacologic measures, and low­
 dose ketamine or acetaminophen to decrease the opioid requirements. If there is continued agitation or anxiety after adequate pain control,
 recommended sedating agents include propofol or dexmedetomidine. Dexmedetomidine is associated with a higher rate of hypotension,
 bradycardia and need for additional sedatives compared to usual care with propofol or benzodiazepines. Avoid benzodiazepines as they may be
,19 associated with delirium, prolonged sedation and worse outcomes.
OBSTRUCTIVE LUNG DISEASE
Acutely decompensated asthma and chronic obstructive lung disease patients are difficult to manage on the ventilator because the primary pathology is not improved by intubation (Table 29B­5). The problems encountered are increased airway resistance (with resultant high peak pressures; Figure

29B­2), pulmonary hyperinflation, and increased dead space causing hypercapnia. The obstructive nature of these diseases leads to an effort­
,24 independent prolonged exhalation time. Arterial hypercapnia tempts the treating physician to increase the respiratory rate to exhale more carbon dioxide; however, increasing the respiratory rate is counterproductive because it shortens the exhalation time, leading to an additional breath prior to
,25 the lungs completely emptying. This latter event is called dynamic hyperinflation. As dynamic hyperinflation worsens, lung volumes increase, and
 the risk of barotrauma, pneumothorax, and hypotension also increases. Incomplete emptying can be detected by monitoring the expiratory flow limb on the ventilator (Figure 29B­4) in a passively breathing patient. Measure the intrathoracic pressure from dynamic hyperinflation during an endexpiratory hold (Figure 29B­4). The difference between the total PEEP (from end­expiratory hold) and set PEEP is called auto­PEEP or intrinsic PEEP, signifying trapped air.
Table 29B­5
Ventilator Management for Obstructive Lung Disease
Slow Start with a rate of 10–14 breaths/min.
respiratory A slow respiratory rate is the best way to increase emptying time compared with a decrease in inspiratory time.
rate
Tolerate Tolerate a pH of ≥7.20. hypercapnia A respiratory acidosis with a pH >7.20 is safe assuming there is not concomitant pulmonary hypertension.25,27 If a respiratory acidosis is causing systemic effects, increase the tidal volume >8 mL/kg while keeping a low respiratory rate to maximize alveolar ventilation.
Check for Check for auto­PEEP.
gas trapping Ensure the expiratory flow limb of the flow curve reaches zero before the next breath (in a passively breathing patient). Perform an endexpiratory hold to calculate auto­PEEP. If hypotension occurs, disconnect the patient from the ventilator for 15–20 seconds and decrease the respiratory rate after reconnection.
Abbreviation: PEEP = positive end­expiratory pressure.
Source: PEEP Table Adapted from ARDSNet NIH NHLBI ARDS Clinical Network Mechanical Ventilation Protocol Summary.
http://www.ardsnet.org/files/ventilator_protocol_2008­07.pdf
FIGURE 29B­4
Pressure waveform demonstrating auto–positive end­expiratory pressure (PEEP) with an end­expiratory hold. The total PEEP is  cm H O, and the set

PEEP is  cm H O, which means the auto­PEEP is  cm H O. In the green flow waveform, inspiration is positive (above the baseline flow of zero) and
  expiration is negative (below the baseline flow of zero). The expiratory flow limb not returning to zero (baseline) means there is continued expiration when the next breath is delivered. This leads to dynamic hyperinflation and air trapping.
SEVERE HYPOXIA/HYPOXEMIA, ACUTE RESPIRATORY DISTRESS SYNDROME, AND TRAUMA
Determining the etiology of hypoxia (depressed alveolar oxygen) or hypoxemia (depressed arterial oxygen) starts with determining if there is unilateral or bilateral lung disease; this strategy guides potential therapies or interventions. In patients with bilateral lung disease at risk for acute respiratory distress syndrome, use lung­protective ventilator settings discussed earlier. Although it is often difficult to completely exclude a cardiogenic source of bilateral infiltrates and all patients at risk will not develop acute respiratory distress syndrome, this approach of limiting tidal volume can provide
 benefit.
The mainstays of suspected acute respiratory distress syndrome treatment are low tidal volume ventilation, adequate PEEP, and treatment of the underlying condition (Figure 29B­5). If the plateau pressure is above  cm H O, the tidal volume should be incrementally decreased by  mL/kg to as
 low as  mL/kg. These protective lower tidal volumes may lead to hypercapnia and acidemia, although a pH of >7.20 is usually well tolerated. Most
 patients with restrictive lung physiology tolerate a respiratory rate of  to  breaths/min without air trapping. As noted earlier, avoid hyperoxia; do
,12 not routinely seek a saturation of 98% to 100% in most patients. In acute respiratory distress syndrome, many seek an oxygen saturation of 88% to

95% or partial pressure of arterial oxygen of  to  mm Hg.
FIGURE 29B­5
Pressure waveform of a patient with low lung compliance (i.e., acute respiratory distress syndrome). Decreasing the tidal volume is one method to decrease the plateau pressure. In the top waveform, the tidal volume is  mL/kg ideal body weight and the plateau is  cm H O. In the bottom
 waveform, the tidal volume is  mL/kg ideal body weight and the plateau is  cm H O.

Setting appropriate PEEP aids by improving oxygenation through recruiting additional lung, increasing the surface area for gas exchange, and
 preventing atelectrauma. Titrate PEEP based on the PEEP/FIO tables in Table 29B­2. 
In those with refractory hypoxemia and criteria for severe ARDS, other options include neuromuscular blockade, prone positioning, pulmonary
28–31 vasodilators, or transfer to an extracorporeal membrane oxygenation–capable center.
Trauma patients are at risk for either lung injury by direct trauma to the chest or secondary lung injury from systemic inflammation. Use the same
 principles noted earlier, targeting normoxia and maintaining plateau pressure <30 cm H O and adequate PEEP. In traumatic brain injury, the current
 goal is normoxia and normocapnia with a goal partial pressure of carbon dioxide of  to  mm Hg while reserving hyperventilation for a temporizing
 therapy in those with an increased intracranial pressure.
VENTILATOR CARE BUNDLE
Implement a ventilator care bundle in every intubated patient as soon as possible. This includes routine measurement of patient height to determine appropriate tidal volume for ventilation, elevating the head of bed to at least  degrees, decompressing the GI tract, and oral care with a chlorhexidine
,34 solution every  hours (Figure 29B­6). Although many recommend stress ulcer prophylaxis with a proton pump inhibitor or a H blocker, the

 overall effect on mortality and morbidity, including ventilator­associated pneumonia, gut infection, and bleeding, is uncertain.
FIGURE 29B­6
Figure 29B­7
Recommended approach to analgesia and sedation for mechanically ventilated patients.
Reassess intubated patients after initial neuromuscular blockade has worn off to assess adequacy of sedation, decrease the FIO quickly to avoid
 hyperoxia, check an arterial blood gas, and adjust ventilatory strategy to meet the patient’s needs. Start a venous thromboembolism prophylaxis approach, and think early about sedation holidays and spontaneous breathing trials in patients expected to be housed in the ED for ≥24 hours.


