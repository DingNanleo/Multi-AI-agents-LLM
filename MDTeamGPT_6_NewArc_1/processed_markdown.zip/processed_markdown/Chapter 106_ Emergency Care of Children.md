## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 106: Emergency Care of Children
Garth D. Meckler
INTRODUCTION
Children are not just small adults. This standard mantra is heard in EDs around the world. About one third of all ED visits are by children. Anatomic, physiologic, and developmental differences between children and adults give rise to a unique epidemiology, pathophysiology, and differential diagnosis. Key elements of the medical history must often be elicited from caretakers, not from the child, and symptoms are often inferred from observation. It may be difficult to perform a physical examination on a child, and cardinal signs of disease are different in children compared to adults. Diagnostic testing can cause pain or potentially long­term harm. Drugs require weight­based dosing, and equipment selection must be tailored to the child’s size. Disposition may require transfer to a specialized children’s hospital. Finally, even though the child is the primary patient, management must be family centered and often involves addressing the fears and stresses of family members.
ANATOMY AND PATHOPHYSIOLOGY
Pediatric age groups are divided into neonates (birth to  month), infants (1 month to  year), toddlers (1 to  years), school­aged children (3 to  years), and adolescents (12 to  years). Significant developmental and physiologic changes occur across these age groups; Table 106­1 summarizes the developmental milestones as they relate to the ED evaluation and approach, and Table 106­2 lists the age­dependent vital signs.
TABLE 106­1
Pediatric Developmental Stages and ED Assessment
Stage Milestone Strategy
Early infancy (0–6 mo) Motor: lifts head, reaches Observation
Verbal: cooing Examine in parent’s arms
Social: responsive smile Direct approach
Late infancy (6–18 mo) Motor: reaches/obtains, sits, walks Observation
Verbal: jargon, few words Examine in parent’s arms
Social: stranger anxiety/ dependence Indirect approach
Toddler (18–36 mo) Motor: walks well, scribbles Observation
Verbal: speaks in phrases Indirect approach
Social: stranger anxiety/autonomy
Preschool (3–5 y) Motor: runs well, colors Indirect or direct approach
Verbal: speaks in sentences Explain briefly just before procedures
Social: magical thinking

School age (5–12 y) Motor: schoolwork, sports Direct approach
Chapter 106: Emergency Care of Children, Garth D. Meckler 
. Terms of Use * Privacy Policy * Notice * Accessibility
Verbal: concrete reasoning Explain in detail before procedures
Social: task oriented
Adolescence (12–17 y) Motor: adult Direct approach
Verbal: abstract reasoning ity
Social: autonomy, rebellion Treat as adult
TABLE 106­2
Pediatric Vital Signs by Age (Awake and Resting)
Heart Rate, Upper Limit Respiratory Rate, Upper Limit Blood Pressure,* Lower Limit (mm Weight,†
Age
(beats/min) (breaths/min) Hg) (kg)
0–1 mo 180  60/40 3–4
2–12 mo 160  70/45 5–10
12–24 140  75/50 10–12 mo
2–6 y 120  80/55 13–25
6–12 y 110  90/60 25–40
>12 y 100  90/60 40–60
*May be estimated by:
Systolic blood pressure (5th percentile) =  plus twice the age in years from age 1­10 years. Beyond age  use adult cut­off of systolic blood pressure . [70 + twice the age in years]
†May be estimated by:
 mo: weight (kg) =  + (age in months/2)
1–12 y: weight (kg) =  + [2 × (age in years)]
Neonates undergo the most profound changes as they transition from metabolic and respiratory dependence on the placenta to independence as airbreathing beings. The cardiovascular and respiratory systems switch from near complete shunting of blood flow away from the lungs to typical adult circuitry and dependence on the lungs for oxygenation as the ductus arteriosus closes (see Chapter 129, “Congenital and Acquired Pediatric Heart Disease”). Oxygenavid fetal hemoglobin changes to adult hemoglobin with predictable changes in hemoglobin levels throughout the first years of life. The neonatal and infant immune systems depend on passive maternal humoral protection transferred through the placenta and breast milk until cellular and humoral defenses mature. Immunologic immaturity predisposes to bacterial and viral systemic infections early in life (see Chapter 119, “Fever and Serious Bacterial Illness in
Infants and Children”). The neurologic system is characterized by rapid growth, differentiation, and myelination and changes in the balance of excitatory and inhibitory neurotransmitters, which account for susceptibility to seizures.
Anatomically, growth and development of every organ system characterizes infancy and childhood and affects emergency care across the life span. A relatively large occiput, small jaw, high and anterior larynx, narrow cricoid cartilage, and large tongue require unique considerations in airway management (see
Chapter 113, “Intubation and Ventilation in Infants and Children”). A soft, compliant chest wall, obligate nose breathing, and gastric inflation from swallowed air alter the mechanics, symptoms, and signs of respiratory distress in young children. Neonates, infants, and children increase cardiac output through an increase in heart rate rather than stroke volume. Tachypnea, an increased rate of breathing, not hyperpnea, an increased depth of respiration, is the primary respiratory compensatory mechanism. The musculoskeletal system of young children differs from that of older children and adults not only in its proportions (e.g., relatively large head), but also because ligaments are stronger than bones, predisposing to fractures rather than sprains. Linear growth of long bones occurs from specialized cartilaginous end plates (physes), which results in unique fracture patterns (see Chapter 141,
“Pediatric Orthopedic Emergencies”).
EPIDEMIOLOGY
In the United States, consider congenital anomalies, inherited disorders (see Chapter 146, “Metabolic Emergencies in Infants and Children”), complications of prematurity and pregnancy, and accidental and nonaccidental trauma in the first year of life. Injuries, malignancy, and congenital heart disease are the predominant causes of death among children after the first year of life, with injury, suicide, and homicide becoming leading killers in adolescents. Worldwide, infectious diseases, including diarrheal illness, respiratory infections, and preventable or treatable conditions such as measles, malaria, and human immunodeficiency virus infection, predominate.
CLINICAL FEATURES
HISTORY
For preverbal children, obtain the medical history from caregivers. The reliability and quality of historical information are variable. Astute caregivers know their children well and often infer symptoms and complaints from subtle changes in behavior that may not be apparent to the ED physician; this is particularly true for children with special healthcare needs whose medical history and technology may be complex (see Chapter 148, “The Child with Special Healthcare
Needs”). The expression of some cardinal symptoms of disease varies by age group. For example, vomiting and crying are both common and nonspecific in younger children and may signal serious disease including infection, heart disease, metabolic disease, and surgical abdominal disease.
For neonates and infants, carefully review maternal complications during this and previous pregnancies: a history of spontaneous abortions or maternal liver disease, for example, may indicate inherited metabolic disease, and maternal infections may be congenitally acquired by the neonate. The birth history is important, because gestational age, complications of labor and delivery, and immediate perinatal events alter the differential diagnosis.
Review growth and development and childhood immunizations (Table 106­3) to assess overall health. For older children and adolescents, the history should be obtained from both the child and caregiver. Social history becomes important, including questions about risk taking.
TABLE 106­3
Recommended Childhood Immunizations
Vaccine* DTaP
Pneumococcal Meningococcus
Age (Tdap Hib Hep B Polio Rotavirus HPV MMR VZV Hep A Influenza† BCG
(conjugate) (conjugate)
>6 y)
Birth C, U, W W
 mo C, U, W C, U, W C, U, W C, U, W C, U, W C, U, W
 mo C, U, W C, U, W C, W C, U, W C, U, W C, U, W
 mo C, U, W C, U, W C, U, W C, U, W U, W C, U, W C, U, W
12–15 U C, U C, U, W C, U, W U, W C, W mo
15–23 C, U, W C C U mo
2–4 y C C W
4–6 y U C, U U U
10–12 U C, U, W C, U y
13–15 C y
 y U
17–18 y
Abbreviations:BCG = bacillus Calmette­Guérin; C = Canada (Public Health Agency of Canada); DTaP = diphtheria, tetanus, acellular pertussis; Hep A = hepatitis A; Hep B = hepatitis B; Hib = Haemophilus influenzae type b conjugate; HPV = human papilloma virus; MMR = measles, mumps, rubella; U = United States (Centers for Disease Control and Prevention); W = World Health Organization.
*The exact sequence varies according to manufactured brand of vaccine, and many combination vaccines and conjugate vaccines with variable serotypes exist. Schedule is approximate. World Health Organization (W) guidelines recommend additional vaccination of high­risk patients for the following: Japanese encephalitis, yellow fever, tickborne encephalitis, typhoid, cholera, and rabies. See http://www.who.int/immunization/documents/positionpapers for more information.
†Given annually beginning as early as  months of life; requires two­vaccine series for children under  years of age; avoid live vaccine in children <2 years of age and those with asthma or who are immunocompromised.
PHYSICAL EXAMINATION
The examination is different for children in each developmental stage. Infants are easily separated from parents, whereas children  to  years of age have stranger anxiety and must be examined in a parent’s lap. Crying may make evaluation of the heart, lungs, and abdomen difficult. The sequence of examination should progress from the least to most invasive aspects. Adolescents require special considerations for privacy and autonomy.
Vital signs are age dependent (see Table 106­2). For best precision, obtain rectal temperature in infants and young children. Measure blood pressure in all four extremities when considering congenital heart disease. Calculate weight and growth percentiles, including head circumference in infants. Observe skin color, capillary refill, and respiratory effort. For infants and children, note the response to stimulation and check motor tone to identify listlessness or lethargy.
Meningismus is present in <15% of infants with bacterial meningitis. Focal abdominal tenderness is difficult to appreciate in the younger child, which leads to delay in the diagnosis of conditions like appendicitis. Skin temperature, color, and capillary refill are affected by ambient temperature, fear, and pain. The inability of the infant to take a deep breath on command makes chest auscultation less reliable for the diagnosis of pneumonia in young infants compared with older children (see Chapter 128, “Pneumonia in Infants and Children”).
DIAGNOSIS
LABORATORY EVALUATION
The pretest probability of disease varies by the child’s age and the potential differential diagnosis. The sensitivity and specificity of many common laboratory tests may be unique for children compared with adults. Urinalysis, for example, may be less sensitive for detecting infection in young infants who do not store urine long enough to allow accumulation of inflammatory or metabolic markers (e.g., leukocyte esterase and nitrites). Conversely, noninvasive collection of urine by perineal bag or “clean catch” in young infants, although sensitive, lacks specificity in infants due to perineal contamination with bacteria. Other common laboratory screening tests, such as the basic metabolic panel and CBC, have little specificity and predictive power for most childhood conditions (see
Chapter 131, “Vomiting, Diarrhea, and Dehydration in Infants and Children”; Chapter 132, “Fluid and Electrolyte Therapy in Infants and Children”; and Chapter
119, “Fever and Serious Bacterial Illness in Infants and Children”). Unless specifically directed by the history and examination, screening labs that are commonly used in adults add little value to the routine evaluation of common pediatric emergencies such as dehydration, febrile seizures, and chest pain.
Carefully consider the need for blood tests in children, because of the technical difficulties and the anxiety and pain caused by venipuncture.
IMAGING
Weigh the potential risks and benefits of diagnostic imaging in children. The lifetime risk of a fatal malignancy from a single CT scan may be as high as  in 2000 in infants and  in 5000 for older children.1 Ionizing radiation from medical imaging increases the risks of both leukemia and brain cancers.2,3 If infants and young children require sedation for imaging, the risks of sedation are added to the risk of ionizing radiation. Radiographs can be avoided for a number of childhood respiratory conditions (see Chapter 127, “Wheezing in Infants and Children”). Ultrasound is the imaging modality of choice for a number of disease conditions in children, such as pyloric stenosis, appendicitis, and intussusception. Bedside ultrasound (e.g., FAST), although standard in adults, is less reliable in children.
TREATMENT
Many treatment parameters are age specific. Resuscitation principles differ for neonates, children, and adults (see Chapter 108, “Resuscitation of Neonates” and Chapter 109, “Resuscitation of Children”). Neonatal resuscitation focuses primarily on respiratory assistance with effective positive­pressure ventilation.
Children maintain normal blood pressure until very late in critical illness, so compensated shock and respiratory distress require early and aggressive intervention; cardiac arrest is most commonly secondary to respiratory failure in children, rather than primary as in adults. Try to include parents and caretakers in the room during pediatric resuscitation.
Children require special medication dosage calculations based on weight or body surface area due to age­dependent metabolic pathways and differing body composition, volumes of drug distribution, and organ development. Most prescription medications have not been formally tested in children and do not have specific U.S. Food and Drug Administration approval for use in children due to the ethical and practical difficulties of performing drug trials in children.
Common medications can have adverse effects in children, such as dental staining from tetracycline antibiotics and life­threatening complications from antimotility drugs commonly used for adult diarrheal disease.
Children generally do not understand the transient nature of painful procedures or of their relative risks and benefits. Such comprehension allows adults to consent to and cooperate with common emergency procedures. Chapter 115, “Pain Management and Procedural Sedation in Infants and Children,” discusses the pharmacologic and nonpharmacologic approach to this important topic.
Caretakers make legal decisions on behalf of their children. Consent for treatment and procedures must be obtained from legal guardians for all minors except in cases of emergency medical necessity. A variable exception is the provision of care to adolescents with regard to their reproductive and mental health.
DISPOSITION AND FOLLOW­UP
Disposition decisions in children require consideration of caretaker abilities and indications for transfer to another institution. Discharge to reliable caretakers is an important part of practice guidelines for many common pediatric conditions, including minor head injury (see Chapter 138, “Seizures in
Infants and Children”) and fever without source in the infant (see Chapter 119, “Fever and Serious Bacterial Illness in Infants and Children”). Children requiring hospitalization may require transfer to a tertiary­care pediatric hospital. The emergency physician has responsibility for determining the need, risks, and benefits of transfer, and the mode of transporting children to a higher level of care. Ultimately, the disposition requires close communication with receiving facilities and with the child’s family.


