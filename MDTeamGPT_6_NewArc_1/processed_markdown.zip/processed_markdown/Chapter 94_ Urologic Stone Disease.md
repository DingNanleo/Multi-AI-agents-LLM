## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 94: Urologic Stone Disease
David E. Manthey; Bret A. Nicks
INTRODUCTION AND EPIDEMIOLOGY
Emergency medicine management is directed at relieving pain, assessing kidney function, and determining the likelihood of spontaneous stone passage. This chapter discusses renal and ureteral stones. Bladder stones are discussed in Chapter , “Acute Urinary Retention.” Renal stones in children are discussed in Chapter 133, “Acute Abdominal Pain in Infants and Children.”

The prevalence of kidney stones in the United States has risen from .2% in 1994 to .8% in 2010. The prevalence is .6% in men and .1% in
   women. Increasing prevalence is also documented in Europe and Southeast Asia. Obesity and diabetes are strongly associated with kidney stones.

For first­time stone formers, recurrence rates at , , , and  years are 11%, 20%, 31%, and 39%, respectively.
PATHOPHYSIOLOGY
Stone formation requires supersaturation of dissolved salts in the urine, which condense into a solid phase. Increasing the amount of solvent (urine) and decreasing the amount of solute presented to the kidney (i.e., calcium, oxalate, uric acid) can aid in prevention. Inhibitory substances, such as citrate, and magnesium can prevent crystal precipitation and stone formation.
About 80% of calculi are composed of calcium oxalate, calcium phosphate, or a combination of both. Calcium excretion is elevated in conditions that include hyperparathyroidism, absorptive and renal hypercalciuria, and immobilization syndrome. Complex interactions between the gut, kidney, and bones contribute to calcium oxalate stone formation. A diet restricting calcium paradoxically increases calcium stone formation because there is less calcium to bind oxalate in the intestinal lumen, leading to increased absorption of oxalate from the gut, recruitment of calcium from bones, osteoporosis, and symptomatic stone disease in predisposed patients.
About 10% of stones are struvite (magnesium­ammonium­phosphate), which are found most commonly in women with recurrent urinary tract infections. These stones are associated with infection by urea­splitting bacteria (Proteus, Klebsiella, Staphylococcus species, Providencia, and
Corynebacterium) and are the most common cause of staghorn calculi, which are large stones that form a cast of the renal pelvis. Antibiotic penetration into staghorn calculi is poor, and the potential for urosepsis exists as long as the stones remain.
Uric acid causes about 10% of urolithiasis, occurs more commonly in men, and is associated with gout or chemotherapy. Urate stones are radiolucent, and the urine is typically acidic. Cystine stones account for approximately 1% of all stones and occur in patients with cystinuria, an autosomal recessive genetic disorder affecting amino acid transport (COLA: cysteine, ornithine, lysine, arginine).
Some medications predispose to stone disease. The protease inhibitor indinavir sulfate, used to treat the human immunodeficiency virus, is associated with a 4% to 10% incidence of symptomatic urolithiasis. Pure indinavir stones are radiolucent on plain abdominal radiograph and CT scan.

Carbonic anhydrase inhibitors, triamterene, and laxative abuse also increase the prevalence of renal stones. With appropriate evaluation, 90% of
 patients will have a cause identified, and over 50% of calcium oxalate stone recurrences can be prevented. Table 94­1 lists risk factors associated
,3,7 with kidney stones.
TABLE 94­1
Kidney Stone Risk Factors
Risk Factor Mechanisms

ChapteOrb 9es4it:y Urologic Stone Disease, David E. MantMhaeyy ;p rBormeot tAe. h Nypicekrcsalciuria 
. Terms of Use * Privacy Policy * Notice * Accessibility
Low urine volume Allows solute to supersaturate
Excess dietary meat (purine) Creates acidic urinary milieu; depletes available citrate (inhibitor); promotes hyperuricosuria
Excess dietary sodium Promotes hypercalciuria
Insulin resistance, metabolic syndrome Ammonia mishandling; alters pH of urine
Family history Genetic predisposition
Gout Promotes hyperuricosuria
Bowel surgery, inflammatory bowel disease Promotes low urine volume; acidic urine depletes available citrate (inhibitor); hyperoxaluria
Primary hyperparathyroidism Creates persistent hypercalciuria
Prolonged immobilization Bone turnover creates hypercalciuria
Medications Indinavir, ephedrine, loop diuretics, topiramate, acyclovir, triamterene
Pain associated with kidney stones is due to obstruction of a hollow viscus organ (ureter) and subsequent hydronephrosis creating pressure against
Gerota’s fascia, causing flank pain. Isolated small renal pelvis stones (not staghorn) do not cause pain unless they cause intermittent obstruction of the entrance to the ureter. A migrating but nonobstructive stone also causes pain. During acute obstruction, most patients have no rise in serum creatinine because the unobstructed kidney functions at up to 185% of its baseline capacity. A rise in serum creatinine in acute obstruction suggests a solitary kidney or preexisting renal disease such that the unobstructed kidney is unable to compensate completely. Fortunately, most patients have incomplete ureteral obstruction, and many patients can be safely observed over weeks. Irreversible renal damage from an obstructive kidney stone is rare if obstruction has been present for ≤1 month. 
The probability of spontaneous passage of stones is determined by multiple factors, including size, shape, location, and degree of ureteral obstruction. Bizarre or irregularly shaped stones with spicules or sharp edges have a lower spontaneous passage rate. With complete obstruction, there is a lower rate of spontaneous passage than if the blockage is partial. The most common sites of obstruction include the ureteropelvic junction, where the 1­cm pelvis constricts into the 2­ to 3­mm ureter; the pelvic brim, where the ureter courses over both the pelvis and the iliac vessels; and finally, the ureterovesical junction, because this is the most constricted site of the ureter due to the muscular coat of the bladder. Based on stone size alone, 98% of stones <5 mm will pass within  weeks without intervention. Sixty percent of stones  to  mm and 39% of stones >7 mm will pass within  weeks. Stone size on plain radiographs is magnified by up to 20%, and a
 measured stone on CT is 88% of actual stone size.
CLINICAL FEATURES
The classic symptom complex for nephrolithiasis is the acute onset of a crampy intermittent flank pain that radiates toward the groin. As pain originates from a hollow viscus (ureter), the pain is visceral in nature without associated peritoneal irritation. Patients writhe in pain, unable to find a
 position of comfort. However, patients with renal colic may demonstrate rebound abdominal tenderness (29%), guarding (61%), and rigidity (8%).

Pain is commonly accompanied by nausea and vomiting (50%). The adrenergic response to pain can result in tachycardia, hypertension, and
 diaphoresis. Hematuria is present in only 85% of patients with renal colic, and 30% have gross hematuria.
The location of the pain correlates somewhat with the location of the stone. Stones in the upper ureter refer pain to the flank, whereas those in the mid­ureter radiate to the lower anterior quadrant of the abdomen. A distal ureter stone, which is where 75% of stones are diagnosed, refers pain to the groin. Stones positioned at the ureterovesical junction can mimic a urinary tract infection by causing frequency, urgency, and dysuria in 3% to 24% of
 patients. Extracorporeal shock wave lithotripsy fractures stones into small particles with the use of focused sound waves. The resulting “sludge” is passed in the urine. When there are large fragments, an acute episode of renal colic occurs.
During the patient interview, elucidate four important items of history: assess risk factors for stone development (Table 94­1), prior stone­related outcome, history of renal disease, and important mimickers. The risk factors for a poor outcome with stones include three categories: renal function at risk, history of difficulty with stones, and infection (Table 94­2). Two mimickers that are very important to exclude are abdominal aortic aneurysm and renal artery infarction. Nephrolithiasis is the most common misdiagnosis given to patients with a rupturing or expanding abdominal aortic aneurysm. Recall that stones do not usually present in men older than age  without a prior history of nephrolithiasis and do not cause hypotension, even transiently. Renal artery thrombosis can mimic stone symptoms due to swelling of the infarcted kidney and can also be associated with hematuria. If the patient is pregnant, consider ectopic pregnancy in the differential diagnosis.
TABLE 94­2
Risk Factors for Poor Outcome With Stones
Renal function at risk
Diabetes
Hypertension
Renal insufficiency
Single kidney
Horseshoe kidney
Transplanted kidney
History of difficulty with stones
Extractions
Stents
Ureterostomy tubes
Lithotripsy
Symptoms of infection
Fever
Hypotension
Systemic illness
Urinary tract infection
DIAGNOSIS
The diagnosis of urologic stone disease is clinically suspected and supported by the presence of hematuria; imaging confirms the diagnosis with certainty.
Many diagnoses can be confused with renal colic (Table 94­3). History and physical examination can be difficult because the patient’s discomfort may interfere with adequate information collection. The most critical diagnoses to consider are aortic dissection and ruptured abdominal aortic aneurysm.
Renal colic and abdominal aortic aneurysm may have similar presentations.
TABLE 94­3
Differential Diagnoses for Ureterolithiasis
Vascular Aortic dissection
Abdominal aortic aneurysm
Renal artery embolism
Renal vein thrombosis
Mesenteric ischemia
Renal Pyelonephritis
Papillary necrosis
Renal cell carcinoma
Renal infarct
Renal hemorrhage
Ureter Blood clot
Stricture
Tumor (primary or metastatic)
Bladder Tumor
Cystitis
GI Biliary colic
Pancreatitis
Perforated peptic ulcer disease
Appendicitis
Inguinal hernia
Diverticulitis
Cancer
Bowel obstruction
Gynecologic Ectopic pregnancy
Pelvic inflammatory disease/tubo­ovarian abscess
Ovarian cyst
Ovarian torsion
Endometriosis
GU Testicular torsion
Epididymitis
Other Drug­seeking behavior
Shingles
Retroperitoneal hematoma/abscess/tumor
LABORATORY EVALUATION
The laboratory evaluation centers on evaluating for infection, kidney dysfunction, and possibility of pregnancy. Test all females of childbearing potential for pregnancy when considering renal colic, to help direct imaging and to exclude ectopic pregnancy.

Urinalysis is needed to rule out infection. If infection is found, obtain urine culture and sensitivities to guide antibiotic therapy. A urine culture should
 be done on all patients with sterile pyuria as renal colic patients with pyuria have 36% positive cultures as compared to those without pyuria (3.3%).
In suspected pediatric nephrolithiasis, urine culture is routine (see Chapter 135, “Urinary Tract Infection in Infants and Children”).
Hematuria (three or more red blood cells per high­power field), or even its absence, can mislead the physician. Although 10% to 15% of patients with nephrolithiasis will have no hematuria, approximately 24% of patients with flank pain and hematuria have no radiographic
 evidence of ureterolithiasis. Therefore, although hematuria may contribute to diagnostic decision making, it should not be used alone to exclude
 or confirm the diagnosis of ureterolithiasis (see Chapter , “Urinary Tract Infections and Hematuria”).

Check renal function because the overwhelming majority of patients who form stones have reduced creatinine clearance. A WBC count does not aid in the evaluation because many patients will have an elevated WBC count due to stress demargination. Other laboratory studies, such as serum calcium or uric acid, are not useful in the initial evaluation or treatment but help determine stone type and long­term therapy.
IMAGING
Imaging confirms the presence of a ureteral stone, rules out other diagnoses, identifies complications, defines stone location, and assists with
 management if the stone fails to pass spontaneously. Imaging is recommended by the American Urological Association in patients with suspected
 first­time stones. For young, healthy, stable patients with a history of kidney stones in whom the diagnosis is clinically clear, imaging may be deferred
 until the follow­up visit, provided that a reliable follow­up mechanism exists. However, clinicians are frequently incorrect in their clinical impression
  in 20% to 70% of cases. CT scanning reveals an alternative diagnosis in 33% of the patients. Thus, determine the need for confirmation of the diagnosis based on the patient’s past medical history, dangers of accumulated radiation exposure, clarity of the clinical diagnosis, and ease of followup and ability to return for worsening symptoms.
CT
The noncontrast CT scan is sensitive and specific, with “diagnostic” positive and negative likelihood ratios for detection of renal stones (Table 94­

4). Images are obtained from the top of the kidney to the bladder base. Secondary signs of ureteral obstruction, such as ureteral dilatation, stranding of perinephric fat, dilatation of the collecting system, and renal enlargement, can be helpful in making the diagnosis. In combination, unilateral
 ureteral dilatation and perinephric stranding have a positive predictive value of 96% for stone disease. If both are absent, the negative predictive
 value is 93% to 97% (Figures 94­1 and 94­2).
TABLE 94­4
Ancillary Tests in Urologic Stone Disease
Sensitivity Specificity
Test LR+ LR– Comments
(%) (%)
Noncontrast CT 94–97 96–99 24–∞ .02– Advantages: speed, no RCM, detects other diagnoses

Disadvantages: radiation, no evaluation of renal function
US 63–85 79–100 10–∞ .10– Advantages: pregnancy, no RCM, no radiation, no known side effects

Disadvantages: insensitive in middle third of the ureter, may miss smaller stones (<5 mm)
Plain abdominal 29–58 69–74 .9– .58– Advantage: may be used to follow stones radiograph .0 .64
Disadvantage: poor sensitivity and specificity
Abbreviations: LR = likelihood ratio; RCM = radiocontrast media.
FIGURE 94­1. A.Arrow shows 6­mm stone within the proximal third of the left ureter on noncontrast CT reformatted image of upright abdomen. B. From same patient as in A, note 6­mm stone (arrow) within the proximal third of the left ureter on noncontrast CT.
FIGURE 94­2. CT image shows 5­mm stone (arrow) at left ureterovesical junction. Other calcifications are seen in the pelvis, unrelated to the urinary outflow system.
Noncontrast CT has advantages over other imaging modalities, including superior speed, the avoidance of radiocontrast media, and greater ability to identify other pathologies. However, because radiocontrast is not used, the specificity and sensitivity for other diagnoses (e.g., abdominal aortic aneurysm, appendicitis, renal infarct, or perinephric abscess) are not as great as with imaging protocols using contrast, and renal function is not assessed.
Low­dose CT has been studied in small numbers. Low­dose CT is as sensitive as standard CT in detecting stones >3 mm in patients with a body mass
  index <30 kg/m . However, it was not as sensitive for smaller stones or at higher body mass indices.
IV Urography

This imaging modality is not a useful imaging modality except in unusual circumstances. Nearly half of patients who received this test to evaluate
 urologic stones required a second study (usually noncontrast CT) for management.
Plain Abdominal Radiographs
Approximately 90% of urinary calculi are radiopaque because calcium phosphate and calcium oxalate stones have a density similar to that of bone.
Struvite stones are typically mixed with calcium and thus are radiopaque. A plain kidney­ureter­bladder film is neither sensitive nor specific enough to rule in or rule out a stone. However, once the location of a stone is identified on CT scan, the progression of a radiopaque stone can be followed by a plain abdominal film.
US
US should be the first­line imaging modality in pregnant patients. Although useful in the detection of larger stones (Figure 94­3), US may miss smaller

(<5 mm in diameter) ureteral stones. US is helpful in diagnosing stones in the proximal and distal ureters but is insensitive for mid­ureteral stones.
Overall, US has only modest sensitivity and specificity for detecting renal stones (Table 94­4). Reported overall sensitivity of US color Doppler twinkling
 artifact is about 55%, with a false­positive rate of about 50% compared to CT. It is not unreasonable to consider US as a first­choice modality in a
 patient with a strong suspicion of stones, but CT should follow US if US is inconclusive. Rapid bolus infusion of crystalloid can result in a falsepositive finding of hydroureter.
FIGURE 94­3. US of renal pelvis showing stones (marked with 1+ and 2+) with shadowing effects (arrows).
US provides information on hydronephrosis, renal size, and, with Doppler scanning, renal blood and urine flow. Obesity may interfere with obtaining good­quality scans, and diagnostic accuracy depends on the skill and experience of the operator.
One study assessing diagnostic accuracy of bedside US by ED physicians reported overall sensitivity of visualization of hydronephrosis or stones of
.4% (95% confidence interval, .6% to .3%), but with best sensitivity for stones ≥6 mm (sensitivity, 90%; 95% confidence interval, 82% to 98%).  A comparison of ED bedside US versus radiology­performed US and CT scan reported similar diagnostic accuracy among the ED and radiology US, but
 the best diagnostic accuracy was found with CT.
TREATMENT
Treatment for symptomatic nephrolithiasis in the ED includes pain and nausea/vomiting control as needed, antibiotics for those with evidence of infection, and in selected cases, medical expulsion therapy.
PAIN AND NAUSEA

Forced IV hydration results in no difference in pain control or stone passage rates when compared to minimal IV hydration. Fluids should be given to correct any fluid deficit due to vomiting or limited oral intake.

NSAIDs have a direct action on the ureter by inhibiting prostaglandin synthesis. IV administration achieves more rapid relief than IM or PO dosing

(e.g., ketorolac,  to  milligrams IV ). There are several U.S. Food and Drug Administration boxed warnings regarding NSAID use: Do not give
NSAIDS to patients with aspirin or NSAID hypersensitivity; avoid in coagulopathic patients or those at risk for bleeding; and avoid in patients with renal impairment. Inform the urologist if the patient is given antiplatelet drugs (NSAIDS) or if the patient is taking antithrombotics, especially if imminent
 surgical therapy or lithotripsy is anticipated. Opioids (e.g., hydromorphone, .5 to .0 milligrams IV) are also routinely given for pain control.
Because both pain and opioids may cause vomiting, antiemetics are frequently required.
Lidocaine IV can reduce smooth muscle tone and reduce transmission by afferent sensory pathways. The dose is .5 mg/kg IV and should be given slowly to avoid numbness or dizziness. IV lidocaine may provide pain relief sooner than IV morphine. It is useful alone or used along with
,33 morphine.
URINARY TRACT INFECTION
Patients with a ureteral stone and fever, renal insufficiency, and/or systemic signs of infection are treated with IV antibiotics and admitted. Consult
,34 urology to determine if surgical options are indicated. First­dose antibiotic options include piperacillin­tazobactam, .375 grams IV; cefepime,  grams IV; ticarcillin­clavulanic acid, .1 grams IV; or ciprofloxacin, 400 milligrams IV. For patients without renal compromise, consider gentamicin or tobramycin, .0 milligrams/kg/d divided every  hours, plus ampicillin,  to  grams every  hours. Local sensitivities should guide antibiotic choice to prevent treatment failure.
Patients who have a ureteral stone with an associated urinary tract infection but no evidence of significant obstruction, fever, or systemic illness can be treated as outpatients, provided follow­up in  to  hours can be accomplished (see section “Disposition and Follow­Up” later in the chapter). The choice of antibiotic should cover gram­negative rods and be appropriate for antibiotic sensitivity at your institution. Resistance rates of >10% to 20% should preclude use of that antibiotic. Choices include ciprofloxacin, 500 milligrams PO twice a day for  to  days; levofloxacin, 500 milligrams PO once a day for  to  days; cefpodoxime, 200 milligrams PO twice a day for  to  days; or others predicted to be successful based on local sensitivities.
MEDICAL EXPULSION THERAPY
34­41
Studies of medical expulsion therapy have a variety of study designs, and results have sometimes been contradictory. Tamsulosin, an α­blocker, is
,38 the most commonly used drug for medical expulsion therapy. The most recent guidelines indicate that α­blockers may result in shorter stone expulsion times and are more effective for stones >5 mm. Surgical intervention rates appear similar with and without the drug. Inform patients of the
,38 drugs’ limited benefit and important potential side effects, including orthostatic hypotension, lightheadedness and dizziness, and headache. The dose of tamsulosin is .4 milligram PO once daily, but terazosin (5 to  milligrams once daily) and doxazosin (4 milligrams once daily) are also
,37 ,38,39 ,38 used. Calcium channel blockers are not recommended, as effects appear inferior to α­blockers. Steroids are not recommended.
DISPOSITION AND FOLLOW­UP
Most patients with stones are discharged with urologic or primary care follow­up, at which time preventive therapy may be considered based on stone
 type. Because of lower rates of spontaneous passage, discuss disposition of patients with large (>5 mm), irregular, or proximal stones (Table 94­5) with the urology consultant. Also discuss with the urologist the disposition of patients with renal insufficiency, severe underlying comorbidities, complete obstruction, multiple ED visits associated with the stone, renal transplantation, or associated urinary tract infection without sepsis.
TABLE 94­5
Indications for Admission in Patients With Nephrolithiasis
Absolute Indications for Admission Relative Indications for Admission
Intractable pain or vomiting Fever
Urosepsis* Solitary kidney or transplanted kidney without obstruction
Single or transplanted kidney with obstruction* Obstructing stone with signs of urinary infection
Acute kidney injury Urinary extravasation
Hypercalcemic crisis Significant medical comorbidities
Severe medical comorbidities/advanced age Stone unlikely to pass—large stone above the pelvic brim
*Indication for urgent decompression.
Discharge is appropriate in patients with smaller stones, in the absence of infection, and when pain is controlled by oral analgesics. Give patients a urinary strainer with instructions to save any stones they pass for pathologic evaluation. Average time for stone passage varies according to size and location but may range up to  to  days for stones  to  mm in diameter. Patients should be counseled to return promptly for fever, vomiting, or uncontrolled pain. A prescription for an oral opiate and NSAIDs should be provided, as well as for medical expulsive therapy if used.

Inform the urologist if the patient is using anticoagulant or antiplatelet drugs, especially if imminent surgical therapy or lithotripsy is anticipated.
Follow­up with a urologist within  days is recommended.
If the stone passes in the ED, no further acute treatment is required. Elective urologic consultation is recommended so that the composition of the stone is evaluated and a prophylactic strategy can be arranged. Patients with hematuria, negative imaging studies, and no other source require outpatient urologic follow­up to determine the cause of hematuria.
SPECIAL POPULATIONS/CONSIDERATIONS
PREGNANCY
Stones occur in  in 1500 pregnancies, and 80% to 90% present in the second or third trimester. The presentation is the same as in nonpregnant
 patients with flank pain (89%) and hematuria (95%). The study of choice in pregnancy is US to identify hydronephrosis. However, up to 90% of pregnant patients display physiologic hydronephrosis. US techniques recommended to improve sensitivity and diagnostic accuracy include
 endovaginal approach and looking for ureteral jets and calculating resistive indices for the kidneys. If US does not provide the information necessary
,45  for management, low­dose CT or MRI should be considered in consultation with a urologist and obstetrician. The radiation doses for various imaging modalities for stones are as follows: kidney­ureter­bladder, .05 to .15 cGy; three­film IV pyelogram, .15 to .20 cGy; and

CT scan, .2 to .5 cGy. The American College of Obstetricians and Gynecologists recognizes the need to use CT scan in the evaluation of emergent conditions in pregnancy, including nephrolithiasis; however, the imaging “should be used prudently and only when use is expected to answer a
 relevant clinical question or otherwise provide medical benefit to the patient.”

With regard to treatment of pregnant patients, NSAIDS are not recommended, so narcotic pain control is most commonly used. Nifedipine, known to
 be safe in pregnancy, has been recommended for medical expulsive therapy in pregnant patients, but efficacy in the general population has been
 questioned. α­Blockers are pregnancy category C drugs; safety is unknown.


