## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 218: Chemical Burns
Anthony F. Pizon; Michael Lynch
INTRODUCTION AND EPIDEMIOLOGY
More than ,000 products can produce chemical burns. Most exposures occur occupationally, but home exposures are common as well. As few as
10% of all burn center admissions are the result of chemical burns; however, the morbidity and mortality are high and may account for as many as 30%
,2 of all burn deaths. Burn injuries from corrosives, mostly to the face and neck, are unfortunately a common and growing method of assault in low­
 and middle­income countries. Long­term psychological and physical effects are debilitating. Careful individual attention is required for chemical burn treatment due to the nature of concomitant tissue injury as well as chemical exposure.
PATHOPHYSIOLOGY
The skin is a barrier and transition zone between the internal and external environments. Although the outer stratum corneum layer of the skin functions as an excellent barrier against many chemicals, some penetrate it readily. Chemicals can produce burns, dermatitis, allergic reaction, thermal injury, and/or systemic toxicity.
Most chemicals produce tissue damage by their chemical reaction rather than by thermal injury. Certainly, some chemicals produce significant heat by means of an exothermic reaction. However, most skin damage is the result of the chemical’s unique characteristics. Unlike thermal burns, chemical burn injuries require tailored evaluations and treatments based on the specific agent involved. Multiple factors influence tissue damage and percutaneous absorption of chemicals (Tables 218­1 and 218­2).
TABLE 218­1
Factors Influencing Tissue Damage
Duration of contact
Concentration of agent
Quantity of agent
Mechanism of action
Extent of penetration
TABLE 218­2
Factors Influencing Percutaneous Absorption of Chemicals
Body site
Areas of thin skin (i.e., genitalia, face, and skinfolds are particularly vulnerable)
Amount of surface area
Integrity of skin
Increased vulnerability: traumatized skin, elderly skin, dehydration, inflammation
Nature of the chemical
Lipid solubility, pH, concentration

Chapter 218: Chemical Burns, Anthony F. Pizon; Michael Lynch 
Duration of contact
. Terms of Use * Privacy Policy * Notice * Accessibility
Poor irrigation, chemical­soaked garments, occlusive dressings
Most chemical burns are caused by acids or alkalis. At similar volumes and manner of contact, alkalis usually produce far more tissue damage than acids. Acids tend to cause coagulation necrosis with protein precipitation forming a tough leathery eschar. The eschar typically limits deeper penetration of the agent. Alkalis produce liquefaction necrosis and saponification of lipids. The result is a poor barrier to chemical penetration allowing deeper burns and persistent tissue injury. Other chemical injuries occur by various pathophysiologic mechanisms. Some chemical agents cause injury by more than one mechanism (Table 218­3).
TABLE 218­3
Classification of Chemicals
Classification of Chemical Damage Mechanism of Injury
Acids Protein denaturation as proton donors
Alkalis Protein denaturation as proton acceptors
Organic solvents Disruption of cellular membranes
Inorganic solvents Scavenge ions and salt production within tissues
Death early after severe chemical burns is usually related to hypotension, acute renal failure, and hypovolemic shock. However, systemic toxicity and subsequent morbidity and mortality may also occur if chemicals are absorbed. Acidosis, hypotension, hyperkalemia, dysrhythmia, and shock can occur with systemic absorption of certain caustics (Table 218­4).
TABLE 218­4
Systemic Effects Associated With Chemical Burns
Chemical Systemic Toxicity
Hydrofluoric acid Hypocalcemia, hypomagnesemia, hyperkalemia, cardiac arrhythmias, sudden death
Tannic acid, chromic acid, formic acid, picric acid, phosphorus Hepatic necrosis, nephrotoxicity
Cresol Methemoglobinemia, massive hemolysis, multiple organ failure
Gasoline Severe pulmonary, cardiovascular, neurologic, renal, and hepatic complications
Phenol (carbolic acid) Cardiovascular and CNS toxicity
Sodium nitrate, potassium nitrate Severe methemoglobinemia with refractory cyanosis
Dichromate solution Liver failure, acute renal failure, death despite hemodialysis
GENERAL APPROACH TO CHEMICAL BURNS

The initial goal of treatment is to remove the patient from the exposure and prevent any further chemical contact. If not performed prior to arrival,
 remove all exposed clothing immediately. With few exceptions, aggressive large­volume irrigation with water is the cornerstone of initial treatment.
Chemical agents will continue to damage tissue until they are removed or inactivated. Dry chemical particles such as lime should be brushed away
 before irrigation. Sodium metal and related compounds should be initially covered with mineral oil or excised, because water can cause a severe
  exothermic reaction. Dilution of phenol (carbolic acid) with water may enhance penetration. For the most part, however, use of water or saline to irrigate a chemical burn should not be delayed while searching for other treatment agents and should ideally begin
,5 immediately at the scene of the accident. Almost universally, earlier irrigation means a better prognosis. New amphoteric and hypertonic
 chelating agents offer promise as more effective irrigation solutions for chemical burns as more evidence becomes available.
Hospital personnel should maintain universal precautions while decontamination is ongoing. At the very minimum, mask, face shield, chemicalresistant gown, gloves, and water­impervious boots should be worn.

The amount of elapsed time to initiate dilution or removal of chemical agents is directly related to the eventual depth and degree of injury. The time required for irrigation varies. Severe alkali burns may require several hours of irrigation. Use pH indicator paper to determine continued presence of alkali or acid in burn wounds and possible need for further irrigation. Irrigation should continue until pH is neutral or near neutral.
Although thermal energy is produced in an exothermic reaction when using water irrigation, copious amounts of water will decrease the rate and
 intensity of the chemical reaction and dissipate the heat. Continue irrigation at a gentle flow to avoid continued skin contact with chemicals. After irrigation and debridement of remaining particles and devitalized tissue, apply topical antimicrobial agents to affected areas, and provide tetanus
 immunization as needed. Other than measures specific for a particular chemical burn, treatment following initial therapy is similar to that of thermal
 burns (Table 218­5). Aggressive fluid replacement is needed if extensive chemical burns are sustained. Analgesics may be needed, and in the case of allergic responses to chemicals, epinephrine, antihistamines, and steroids may be required.
TABLE 218­5
Treatment of Select Chemical Burns
Chemical Treatment Comments
Acids
All acid burns require prompt decontamination and copious irrigation with water.
Acetic acid Copious irrigation Consider systemic antibiotics for extensive scalp burns.
Phenol (carbolic acid) Copious irrigation Isopropyl alcohol may also be used.
Sponge with undiluted polyethylene glycol of molecular weight 200–400
Chromic acid Copious irrigation Observe for systemic toxicity.
Formic acid Copious irrigation Dialysis may be needed for severe toxicity.
Hydrofluoric acid Copious irrigation Consider intradermal injection of 10% calcium gluconate or
10% calcium gluconate intradermal for severe cases intra­arterial calcium gluconate for severe cases.
Monitor serum calcium and magnesium in severe exposure.
Topical calcium gluconate gel, .5% for mild cases  mL of 10% calcium gluconate in  mL of sterile watersoluble lubricant (K­Y jelly or US jelly)
Nitric acid Copious irrigation Consult with burn specialist.
Oxalic acid Copious irrigation Evaluate serum electrolytes and renal function.
IV calcium may be required Cardiac monitoring for serious dermal exposure
Alkalis
All alkali burns require prompt decontamination and copious, prolonged irrigation with water.
Portland cement Prolonged copious irrigation May need to remove cement particles with a brush, such as a preoperative scrubbing brush
Elemental Metals
Water is generally contraindicated in extinguishing burning metal fragments embedded in the skin.
Elemental metals (sodium, Cover metal fragments with sand, foam from a class D lithium, potassium, magnesium, fire extinguisher, or mineral oil aluminum, and calcium) Excise metal fragments that cannot be wiped away
Hydrocarbons
Gasoline Decontamination
Tar Cool before removal Baby oil can be used.
Remove using antibiotic ointment containing polyoxylene sorbitan (polysorbate)
Vesicants
Mustards Decontaminate If limited water supply, adsorbent powders (flour, talcum
Copious irrigation powder, fuller’s earth) can be applied to the mustard and then wiped away with a moist towel.
Reducing Agents
Alkyl mercury compounds Copious irrigation Blister fluid is high in metallic mercury content.
Debride, drain, and copiously irrigate blisters
Lacrimators
Tear gas Copious irrigation May cause respiratory symptoms if inhaled
Pepper spray Copious irrigation May cause respiratory symptoms if inhaled
Miscellaneous
White phosphorus Remove clothing Systemic toxicity is a significant concern.
Copious irrigation; keep exposed skin areas wet or submerged until all particles have been removed due to risk of ignition when exposed to air
Debride visible particles
Air bag Prolonged copious irrigation
ACID BURNS
Perform a complete examination of a patient with a significant chemical acid burn to the skin because acids may also cause respiratory and mucous membrane irritation. Furthermore, skin absorption of some compounds may occur and result in systemic illness.
Apart from hydrofluoric acid, strong acids produce coagulation necrosis from the denaturation of proteins in the superficial tissue. Injury severity is related to the physical characteristics of the acid. Most substances with a pH <2 are strong corrosives. Other important tissue­damaging properties of acids include concentration, molarity, and complexing affinity for hydroxyl ions. The higher each of these factors is, the greater is the tissue damage.
Contact time with the skin is the most important chemical burn feature that healthcare professionals may alter. For example, instantaneous skin decontamination of 18M sulfuric acid will cause no burn, but a 1­minute exposure can cause full­thickness skin damage.
ACETIC ACID
The dilute (<40%) acetic acid solution found in hair­wave neutralizer solutions is perhaps the most common cause of chemical burns to the scalp in women. Prolonged contact, especially with an already damaged scalp, can cause a partial­thickness burn that heals slowly and is prone to infection.
Initial treatment is copious water irrigation. Oral antibiotics should be prescribed if the scalp burn has created open skin lesions.
CARBOLIC ACID (PHENOL)
Phenol (carbolic acid), a corrosive organic acid used widely in industry and medicine, denatures proteins and causes chemical burns characterized by a relatively painless white or brown coagulum. Paradoxically, dilute phenol penetrates tissue more readily than the concentrated form. Systemic absorption may result in life­threatening cardiac dysrhythmias or seizures. Although commercially available in concentrations up to 90%, even dilute solutions of 1% to 2% phenol may cause a burn if contact is prolonged or extensive. Chemically related phenolic compounds that induce skin damage include cresol, creosote, and cresylic acid.
Coagulation necrosis of the involved area is common. Necrotic tissue may delay absorption temporarily, but phenol may become entrapped under the eschar. Remove contaminated clothing and begin water irrigation immediately. Water lavage alone may not be totally effective, because the necrotic coagulum inhibits water penetration to the deeper layers.
Decontamination is more effective using an undiluted polyethylene glycol solution of molecular weight 200 to 400 or by a gentle wash with isopropyl
,9 alcohol. An isopropyl alcohol rinse is equivalent to polyethylene glycol in removing phenol. Either irrigation solution reduces the extent of cutaneous corrosion and decreases systemic toxicity. If neither polyethylene glycol nor isopropyl alcohol is available in adequate supplies, large volumes of water should be used.
CHROMIC ACID
6+
Chromium hexavalent compounds (Cr ) are powerful oxidizers. The chromate ion in chromic acid produces a chronic penetrating ulcerating lesion of the skin. Generalized exposure to powdered chromic acid can result in conjunctivitis, lacrimation, and ulceration of the nasal septum. Systemic chromium toxicity can cause liver or renal failure, GI bleeding, coagulopathy, and CNS disturbances. Significant symptoms may occur after only 1% to
2% body surface area burns. A 10% body surface area cutaneous burn caused by chromic acid can be fatal due to systemic toxicity. Any acute skin exposure to chromic acid should be treated with copious water irrigation and observation for systemic effects. Aggressive excision is the best method for prevention of systemic effects because depth of the burn is difficult to determine and absorption of chromium may continue after
 irrigation.
FORMIC ACID
Formic acid in 60% solution is used by acrylate glue makers, cellulose formate workers, and tanning workers. Formic acid produces coagulation
 necrosis. Systemic effects, including decreased respiration, anion gap metabolic acidosis, and hemolysis, have been reported. Treatment includes
 immediate decontamination and irrigation with water. Systemic toxicity may require IV sodium bicarbonate for the metabolic acidosis or exchange transfusions for severe hemolysis.
HYDROCHLORIC AND SULFURIC ACIDS
The dermal toxicity of hydrochloric acid and sulfuric acid is so well recognized that early decontamination and water irrigation usually prevent severe burns to the skin. These acids can burn the skin dark brown or black. Toilet bowl cleaners may contain 80% solutions of sulfuric acid, and some drain cleaners may be 95% to 99% sulfuric acid solutions. Munitions, chemical, and fertilizer manufacturers commonly use 95% to 98% sulfuric acid solutions in their industrial processes. Automobile battery fluid is 25% sulfuric acid. Most household bleaches are only 3% to 6% hypochlorite solutions, which, although acidic, cause little damage unless they are in contact with skin for a prolonged time. Treatment is the same as for formic acid burns.
HYDROFLUORIC ACID
Hydrofluoric acid is used in the production of high­octane fuel, glass etching, semiconductors, microelectronics/microinstruments, germicides, dyes, plastics, tanning, and fireproofing material and is used in cleaning stone and brick buildings. It is also a very effective rust remover.
Unlike other acids, hydrofluoric acid penetrates deeply and will cause progressive tissue loss. It produces burns in two ways. First, hydrogen ions cause direct cellular damage as other acids do through protein denaturation. Second, free fluoride ions scavenge intracellular cations, such as calcium and magnesium, disrupt cellular membranes, and inhibit the sodium/potassium/ATPase. This leads to systemic hypocalcemia, hypomagnesemia, and hyperkalemia. Locally, free fluoride ions cause spontaneous depolarization of nerve tissue and severe pain. Pain will persist until all free fluoride ions have been neutralized.
The dermal effects may not be immediately noted and are more related to the concentration of hydrofluoric acid than to the duration of exposure.
Solutions >50% produce immediate pain and tissue destruction. Solutions <20% may not produce signs and symptoms until  to  hours after exposure. The skin often develops a blue­gray appearance with surrounding erythema.
The treatment of hydrofluoric acid burns consists of two phases. The first, immediate phase is copious water irrigation for  to  minutes. This may be the only treatment that is needed if the hydrofluoric acid solution is <20% concentration, the duration of exposure was very brief, and decontamination is begun immediately. Severe, persistent pain denotes a more serious injury requiring the second phase of treatment.
The second phase of treatment is aimed at replacing calcium and magnesium and detoxifying the enzyme­poisoning fluoride ion. Two ions—calcium
2+ 2+ 
(Ca ) and magnesium (Mg ) —bind the fluoride ion and curtail its toxic effects. However, the overwhelming clinical experience to date has been with calcium gluconate, so it is the agent of choice. Calcium gluconate can be administered as a topical preparation, subcutaneous/intradermal injection, or intra­arterial infusion. If commercial .5% gel is not available, a calcium gluconate gel can be made with a water­soluble lubricant and should be generously applied to the affected skin. The topical preparation is made by mixing .5 grams of calcium gluconate powder in  oz of water­soluble lubricant, or  mL of 10% calcium gluconate in  mL of water­soluble lubricant. Calcium chloride or calcium carbonate can be substituted if no calcium gluconate is available. The main limitation of topical therapy is the impermeability of the skin to calcium, and therefore, topical therapy is limited to use in mild, superficial burns. Most importantly, topical therapy should not delay intradermal or intra­arterial injections for severe burns.
Treatment with intradermal injection of a 10% calcium gluconate solution through a 27­gauge needle into the hydrofluoric acid–burned skin can be effective. A typical dose of .5 mL of 10% calcium gluconate per square centimeter of burned skin is recommended. Pain relief is nearly immediate, and, indeed, the elimination of pain may be used as a guide for further therapy. Unfortunately, injection therapy has several disadvantages:
(1) only limited amounts of calcium are delivered to the tissue; (2) hyperosmolarity and inherent toxicity of free calcium ions cause more pain initially, and more tissue damage is possible if calcium is not bound to fluoride; (3) vascular compromise can result if too much fluid is injected, especially into digits; and (4) rapid penetration of hydrofluoric acid beneath the nail requires nail removal to administer the calcium gluconate into the nail bed adequately. Acute hydrofluoric acid contamination of the hands, feet, digits, or nails requires consultation with a medical toxicologist and plastic surgeon.

Intra­arterial infusion of calcium gluconate may be used to prevent tissue necrosis and stop the pain associated with hydrofluoric acid burns. This should be performed as soon as possible after the initial burn, preferably within  hours of insult. Place an intra­arterial catheter in the appropriate vascular supply (the brachial artery if the entire hand is affected) and connect to a three­way stopcock to which is attached an arterial pressuremonitoring device and the infusion syringe of calcium gluconate. A 50­mL syringe may be filled with  mL of a 10% calcium gluconate solution and  mL of 5% dextrose in water and infused over  hours. The arterial pressure­monitoring device ensures that the catheter has not dislodged from the lumen of the cannulated artery. Repeat infusion may be needed if pain recurs within  hours. Intra­arterial infusion avoids the disadvantages of local infiltration therapy, but it has its own disadvantages: it is an invasive vascular procedure that (1) may result in arterial spasm or thrombosis, (2) requires more time and hospital resources, and (3) requires experience in the technique.
Inhalation of hydrofluoric acid can cause immediate or delayed pulmonary injury. All cases of suspected inhalation injury should be admitted for observation even if asymptomatic. Nebulized calcium gluconate may be attempted in these cases, but no controlled studies exist for its use. The solution is made by adding .5 mL of 10% calcium gluconate solution into .5 mL of sterile water or saline and is administered by nebulizer.
Ocular exposure to hydrofluoric acid requires water irrigation for at least  minutes and emergent ophthalmologic consultation.

An animal study suggests that calcium­containing irrigation fluids for eye exposures may be harmful. Therefore, standard eye irrigation practices should be used. The possibility of severe injury and eye necrosis should not be taken lightly. In severe ocular exposures, systemic absorption is possible as well.
Systemic toxicity from dermal and oral hydrofluoric acid exposure can result in ventricular fibrillation because of systemic acidosis, hyperkalemia, hypomagnesemia, and hypocalcemia. In major hydrofluoric acid burns or oral exposures, immediately administer IV calcium and magnesium, using standard slow IV rates, before laboratory results are available. Once patients develop hypocalcemia or hypomagnesemia, it is very difficult to restore these electrolyte deficiencies. Cardiac monitoring, IV access, and electrolyte monitoring should be performed in all cases of significant hydrofluoric acid dermal burns or oral exposures (Table 218­6).
TABLE 218­6
Options for Treatment of Hydrofluoric Acid Skin Burns
Copious irrigation for 15–30 min immediately.
Application of calcium gluconate gel; use commercial .5% gel or mix  mL of 10% calcium gluconate in  mL of water­soluble lubricant.
Further treatment options as dictated by patient response:
Dermal injection of 10% calcium gluconate at the rate of .5 mL/cm2 of skin surface using a small­gauge needle.
Arterial infusion over  h (40 mL of 5% dextrose in water with  mL of 10% calcium gluconate).
Consider supplemental magnesium and calcium IV.
METHACRYLIC ACID
Methacrylic acid, found in many artificial nail cosmetic products, can produce severe dermal burns, usually in preschoolers. Emergency treatment is copious water irrigation.
NITRIC ACID
Nitric acid is used in industry for casting iron and steel, electroplating, engraving, and fertilizer manufacturing. Upon contact with skin, nitric acid can produce tissue damage by oxidation and may turn the skin yellowish as it is burned. Emergency treatment consists of copious water irrigation and standard burn care (see Chapter 217, “Thermal Burns”).
OXALIC ACID
Oxalic acid is used for leather tanning and blueprint paper. Oxalic acid binds calcium and prevents muscle contraction. The wounds should be irrigated with water, and IV calcium may be required. Serum electrolytes and renal function should be evaluated, and cardiac monitoring should be instituted after serious dermal exposure.
ALKALI BURNS
Alkalis penetrate skin deeper and longer than acids and present a greater danger of toxicity from systemic absorption. Wounds may initially look superficial only to become full­thickness burns in  to  days. Alkalis combine with protein and lipids in tissue to form soluble protein complexes and soaps that permit passage of hydroxyl ions deep into tissue. Soft, gelatinous, friable, brownish eschars are often produced (Figure 218­1). Strong alkalis have a pH >12. FIGURE 218­1. Deep alkali burn. [Reproduced with permission from http://www.burnsurgery.org/Modules/initial_mgmt/sec_6.htm.]
LYES
Strong, corrosive alkalis (“lyes”) include ammonium, barium, calcium, lithium, potassium (caustic potash), and sodium (caustic soda) hydroxides. Lyes are widely used in industry and are found in home products such as drain and toilet cleaners, detergents, and paint removers. The urine sugar reagent
 tablet Clinitest® (Bayer) contains anhydrous sodium hydroxide. Ammonium hydroxide is used in the production of synthetic fibers and extensively in agriculture. Exposure to these chemicals can result in severe toxicity including mucous membrane, ocular, dermal, GI, and inhalational/pulmonary injury. Suicidal ingestion of lye may result in rapid death from upper airway occlusion. Late morbidity related to esophageal and gastric necrosis may be minimized by early surgical intervention with esophagogastrectomy. The mainstay of treatment is immediate, voluminous, and persistent
 irrigation. Lyes are extremely corrosive and penetrating. Lye burns require copious irrigation for long periods of time.
LIME
Lime (calcium oxide) is found in agricultural products and cements. There is considerable variability of lime content in different grades of cement, with fine to textured masonry cement having more lime than concrete. Lime is converted by water to the alkali calcium hydroxide. Upon skin contact, lime
 draws water out of the skin. All dry lime particles should be brushed away before irrigation. Even a small amount of water may generate an exothermic reaction resulting in calcium hydroxide formation and tissue injury. Brisk irrigation with a large volume of water
(taking care to avoid splashing in eyes) should be used and will permit dissipation of heat.
PORTLAND CEMENT
Portland cement, which accounts for a major proportion of the cement used in the United States, is a mixture of sand, lime, and other metal oxides. In the presence of water, calcium hydroxide, sodium hydroxide, and potassium hydroxide may all be formed. Workers who kneel in wet cement or get cement in their boots may discover burns hours after initial contact. In addition, skin may become irritated from gritty material, and a contact dermatitis may develop in individuals sensitive to the chromate contained in the material. Treatment of cement burns may require cleaning the wound with a brush, such as a preoperative scrubbing brush, to remove cement particles imbedded in the dermis.
METALS
Foundry workers are sometimes burned by molten metal, which may spill or splash on body parts and run down into the boots. Elemental metals, sodium, lithium, potassium, magnesium, aluminum, phosphorus, and calcium may all cause burns. When exposed to air, some elemental metals spontaneously ignite. Water is generally contraindicated in extinguishing burning metal fragments embedded in the skin because the resultant explosive exothermic reaction can lead to significant tissue injury. Burning metal may be extinguished with a class D fire extinguisher, smothered with sand, or covered with mineral oil. Wound debridement should include excision of metal fragments that cannot
 be wiped away. Metal fragments should be placed in mineral oil to prevent further ignition.
HYDROCARBONS
GASOLINE
Hydrocarbons cause a fat­dissolving corrosive injury to the skin referred to as defatting dermatitis. Gasoline, a complex mixture of alkanes, cycloalkanes, and aromatic hydrocarbons, is the most common hydrocarbon burn treated in the ED.
A hydrocarbon chemical burn typically resembles a thermal scald or a partial­thickness burn, although full­thickness burns rarely result from
 prolonged contact with gasoline. During extremely cold weather, topical gasoline exposure may lead to frostbite when rapid gasoline evaporation causes heat loss from the skin. Systemic effects of hydrocarbon absorption include neurologic, pulmonary, cardiovascular, GI, and hepatic injuries.
For further discussion, see Chapter 199, “Hydrocarbons and Volatile Substances.”
The primary treatment is decontamination by removing saturated clothing and irrigating exposed skin with soap and water. Otherwise, management is as for a thermal burn.
HOT TAR
Hot tar is derived from long­chain petroleum and coal hydrocarbons. Roofing tars and asphalt are heated to temperatures up to 500°F (260°C), and the burns sustained are usually more thermal than chemical. Although the surface area size of the burn is usually small, solidified material stuck to skin and hair is difficult to remove. If hot, the tar should be cooled to prevent continued thermal injury. Manual mechanical debridement can be painful and destructive to skin structures. Polyoxylene sorbitan (polysorbate), contained in many antibiotic ointments, is an emulsifying agent that can be used to remove tar. Industrial removal agents such as De­Solv­It®, a citrus and petroleum distillate, are also effective in tar removal. Baby oil is also effective for tar removal.
VESICANTS (DIMETHYL SULFOXIDE, CANTHARIDES, AND SULFUR MUSTARD)
Dimethyl sulfoxide, cantharides, and mustard gas are vesicant or drying agents. Skin burns present with edema and blister formation due to production of ischemia and anoxic necrosis at the site of contact. Dimethyl sulfoxide is a water­soluble organic solvent used in industry. It is available without prescription and is used topically for sprains, bruises, minor burns, and joint pain. Due to its chemical composition and solubility, dimethyl sulfoxide can penetrate barrier surfaces such as nitrile gloves. Cantharides (“Spanish fly”) is occasionally used for its supposed aphrodisiac effects.
Sulfur mustard is a vesicant historically used in chemical warfare. An alkylating agent, exposure results in inhibition of cellular enzymatic activity, leading to necrosis. For further discussion, see Chapter , “Chemical Disasters.”
Skin damage following vesicant exposure is often severe and can result in deep skin penetration, edema, blisters, ulcers, and serious morbidity.
Immediate, copious irrigation with water or saline may mitigate the extent of tissue injury. Skin can also be decontaminated by using adsorbent powders such as flour, talcum powder, and fuller’s earth if the supply of water is limited. These powders adsorb the mustard from the skin and should be wiped away with a moist towel. Almost any material can be used to brush the vesicant away from skin. The military uses M258A1 kits for skin decontamination. These kits contain three sets of towelettes, one of each containing phenol, sodium hydroxide, and sodium benzene sulphonochloramine (chloramine). Chloramine produces “free” chlorine, which inactivates sulfur mustard. Povidone iodine shows great promise in the prevention and early treatment of skin damage caused by sulfur mustard. Human data are currently lacking, but in animal models, both prevention
 of burns and immediate (<10 minutes) treatment yielded impressive skin protection.
POTASSIUM PERMANGANATE
Potassium permanganate is an oxidizing agent that is mildly irritating in dilute solution, but in concentrated solution, it can produce dermal burns with a thick, brownish purple eschar of coagulated protein. Burns should be copiously irrigated with water.
ALKYL MERCURY COMPOUNDS
Alkyl mercury compounds, which are reducing agents used in disinfectants, fungicides, and wood preservatives, can produce dermatitis or burn lesions. Lesions typically are erythematous with blister formation. The blister fluid is high in metallic mercury content. The burning process continues if the agent remains in contact with skin. Partial­thickness burns deepen if the blister fluid remains, so the blisters should be debrided, drained, and copiously irrigated. Repeated or prolonged exposure to topical mercury compounds may lead to systemic mercury toxicity.
LACRIMATORS OR TEAR GAS
Lacrimators, or tear gas, such as 2­chloroacetophenone, o­chlorobenzylidene malonitrile, and oleoresin capsicum (pepper spray), cause skin and mucosal irritation within  to  seconds of exposure and can lead to development of contact dermatitis. Although the skin injury is usually limited, inhalation and eye injuries may be severe. Treatment of skin exposure is rapid removal from the offending agent followed by irrigation. Ocular irritation is treated with copious water or saline irrigation, followed by slit­lamp examination for corneal damage. Arrange ophthalmology follow­up in

 hours. Inhalation injuries are treated with respiratory support including oxygen and bronchodilators. There is no role for steroid therapy.
WHITE PHOSPHORUS
White phosphorus is used as an incendiary in munitions and fireworks and as a component of insecticides, rodenticides, and fertilizers. It ignites spontaneously when exposed to air and is rapidly oxidized to phosphorus pentoxide. Burns caused by both its solid and liquid forms are seen in both the military and civilian populations. Death has been reported in burns covering <10% body surface area.
Flaming droplets of inorganic phosphorus may embed beneath the skin. The heat of the reaction causes tissue destruction. Particles continue to oxidize slowly until debrided, neutralized, or completely oxidized. If phosphorus is exposed to air, it will continue to burn. Remove contaminated clothing and visible particles, and copiously irrigate burns with normal saline or water. Skin exposed to white phosphorus must remain wet or
 immersed in water until completely debrided to prevent further injury. Wood’s lamp examination aids identification of remaining phosphorus as it fluoresces. Copper sulfate solution should not be used despite its ability to detoxify phosphorus because it causes hemolysis and increases mortality.
White phosphorus burns are characterized by slow healing and ongoing burning, necessitating early and aggressive treatment. Systemically absorbed phosphorus is a serious concern. Hypocalcemia, hyperkalemia, and hepatic and renal injury all have been reported. Even patients with small burns
 should be considered for admission or transfer to a burn center for aggressive hydration, monitoring, and further treatment. Treatment providers should take care to wear protective equipment and avoid direct contact with the patient’s clothing, feces, and emesis.
AIR BAG BURNS
Approximately 8% of individuals suffering injuries related to air bag deployment are burned. Air bags deploy by ignition of solid propellant—sodium azide and cupric oxide—that creates an exothermic reaction leading to rapid inflation of the air bag. Many other gases are created during activation, including corrosives such as sodium hydroxide, nitric oxide, ammonia, and multiple hydrocarbons. Burns associated with air bags include friction,
 thermal, and chemical burns. Most frequently, burns are produced on the face, hands, and eyes. Full­thickness skin burns have been reported.
Perform slit­lamp examination for eye irritation to detect keratitis. Treatment of air bag chemical burns is similar to any alkali burn: immediate and copious water irrigation.
OCULAR BURNS

After the hands, the eyes are the second most common site of chemical burns documented in a national insurance database in Asia. Chemical
 burns to the eyes are ocular emergencies requiring immediate treatment.
If the nature of the chemical is not known, use pH paper to determine the presence of acid or alkali. Acid quickly precipitates the superficial tissue proteins of the eye, producing the typical “ground glass” appearance of the cornea. Damage sustained secondary to acid burns is, in most cases, immediate and limited to the area of contact.
Alkali burns are generally more severe than acid burns, frequently with unsightly and disastrous results. In a short period of time, strong alkalis can penetrate the cornea, anterior chamber, and retina, with destruction of all sensory elements, thus causing complete blindness
(see Figure 241­49 in Chapter 241, “Eye Emergencies”). Begin with  to  L of normal saline for each eye for 30­minute continuous irrigation as the minimum treatment. Do not use neutralizing substances.
Check the pH in the conjunctival sac to see whether it has returned to .0­7.3 to determine the need for further irrigation. Many many liters may be needed for irrigation. However, extended 2­ to 3­hour irrigation, despite apparent conjunctival pH correction, is recommended in the setting of strong alkaline or hydrofluoric acid burns with obvious examination abnormality, to correct anterior chamber pH as well as conjunctival pH. During irrigation, the eyelid may have to be held open manually or with retractors due to severe orbicularis spasm (see Chapter 241). The eyelids should be everted. Sweep the fornices with a wet cotton applicator to remove any particulate matter, especially if the pH is not responding well to irrigation.
Pain control with topical anesthetics during evaluation and treatment is necessary. Systemic opioids may be necessary for severe pain or associated injuries. For additional discussion, see Chapter 241. Obtain emergency ophthalmology consultation for corneal burns.


