## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 257: Head Trauma
David W. Wright; Lisa H. Merck
INTRODUCTION AND EPIDEMIOLOGY

Traumatic brain injury (TBI) is defined as brain function impairment that results from external force. Clinical manifestations represent a broad constellation of symptoms from brief confusion to coma, severe disability, and/or death. The underlying pathology ranges from temporary shifts in cellular ionic concentrations to permanent structural damage.
TBI is classified as mild, moderate, and severe based on the Glasgow Coma Scale (GCS) score. Over 80% of TBI is defined as mild (GCS  to 15) (mTBI)
 and is often called “concussion.” The label of mild, however, is a misnomer. mTBI may lead to significant, debilitating short­ and long­term sequelae.
Moderate TBI (GCS  to 13) accounts for approximately 10% of head injuries. Mortality rates for patients with isolated moderate TBI are <20%, but long­term disability can be higher. Overall, 40% of patients with moderate TBI have an abnormal finding on CT scan, and 8% will require neurosurgical intervention. In severe TBI (GCS  to 8), mortality rate approaches 40%, with most deaths occurring in the first  hours after injury. Fewer than 10% of
,3 patients with severe TBI experience good recovery.
The prevalence of TBI is twice as high in males as in females. Distribution of age at injury is trimodal, with peaks at  to  years,  to  years, and >75
4­6 years of age. Mortality rate increases with age at time of injury. Motor vehicle collisions are the primary cause of blunt head injury in young adults
  and children, and falls are more common in the elderly. TBI has been called a “signature injury” of modern­day warfare.
PATHOPHYSIOLOGY
CEREBRAL BLOOD FLOW
Autoregulation, cerebral perfusion pressure (CPP), mean arterial pressure (MAP), and intracranial pressure (ICP) are interrelated factors that affect cerebral blood flow (Table 257­1). Under normal circumstances, autoregulation regulates local cerebral blood flow to maintain equilibrium
 between oxygen delivery and metabolism. Other systemic factors, such as hypertension, hypocarbia, and alkalosis, can affect cerebral blood flow by causing vasoconstriction.
TABLE 257­1
Factors That Affect Cerebral Blood Flow
MAP = DBP + [(SBP – DBP)/3]
CPP = MAP – ICP
Abbreviations: CPP = cerebral perfusion pressure; DBP = diastolic blood pressure; ICP = intracranial pressure; MAP = mean arterial pressure; SBP = systolic blood pressure.
Under normal situations, autoregulation can adjust to accommodate CPPs from  to 150 mm Hg in order to maintain local cellular oxygen demands and regional cerebral blood flow. In brain injury, autoregulation is often impaired, so even modest drops in blood pressure can decrease brain perfusion and result in cellular hypoxia. A CPP <60 mm Hg is considered the lower limit of autoregulation in humans, below which local control of
 cerebral blood flow cannot be adjusted to maintain flow adequate for function. Traumatic hypotension leads to ischemia within low­flow regions of the injured brain, so aggressive fluid resuscitation may be required to prevent hypotension and secondary brain injury. In the absence of an ICP
 mChoanpittoerr, 2it5 i7s :i mHpeaodrt aTnrat utom ma,a iDnataviind aW M. AWPr oigfh ≥t8; 0Li smam H .H Mg ebrecckause low blood pressure in the setting of elevated ICP will result in a low CPPP aangde b1r /a 3in5
. Terms of Use * Privacy Policy * Notice * Accessibility injury.
The cranium is an enclosed space with a fixed volume. Any changes to the volume of the intracranial contents (e.g., bleeding) affect the ICP, and an increase in ICP can decrease the CPP. ICP is determined by the volume of the three intracranial compartments: the brain parenchyma (<1300 mL in the adult), cerebrospinal fluid (100 to 150 mL), and intravascular blood (100 to 150 mL). When one compartment expands, there is a compensatory reduction in the volume of another, and/or the baseline ICP will increase (Figure 257­1). Elevations in ICP are life threatening and may lead to a
 phenomenon known as the Cushing reflex (hypertension, bradycardia, and respiratory irregularity). Hypertension is an attempt to maintain cerebral perfusion. Normal values for ICP vary with age (Table 257­2).
FIGURE 257­1. Pressure–volume relationship in brain injury. Normal cerebral blood flow (CBF) autoregulation curve and the abnormal curve with traumatic brain
 injury (TBI). Normal autoregulatory control (blue line) maintains a relatively constant CBF over a broad range of mean arterial pressure (MAP). Loss of autoregulation results in a more linear relationship between CBF and MAP. Elevated intracranial pressure (ICP) can dramatically decrease CBF when autoregulation is impaired (inflection point of red line). Increases in ICP may result in a net loss in CBF.
TABLE 257­2
Intracranial Pressure by Age Group
Age Group Intracranial Pressure (mm Hg)
Adults <10–15
Young children 3–7
Infants .5–6.0
PRIMARY BRAIN INJURIES
The initial insult associated with moderate and severe TBI imparts mechanical forces that produce high levels of direct damage and strain to the brain parenchyma. The primary injuries include contusions (bruises to brain parenchyma), hematomas (subdural, epidural, intraparenchymal, intraventricular, and subarachnoid), diffuse axonal injury (stress or damage to axons), direct cellular damage (neurons, axons, and other supportive cells), loss of the blood–brain barrier, disruption of the neurochemical homeostasis, and loss of the electrochemical function.
SECONDARY BRAIN INJURIES
A wave of secondary damage is unleashed by the impact that results in a series of deleterious cellular and subcellular events (also known as the
,12 secondary neurotoxic cascade). The secondary neurotoxic cascade causes ongoing damage to the brain and ultimately results in a poorer neurologic outcome than might have occurred based on the original mechanism.
The secondary neurotoxic cascade should not be confused with the term secondary insults, a term used in the clinical literature to describe
13­24 conditions or circumstances (e.g., hypotension, hypoxemia, hyperglycemia) that accelerate neurotoxic damage and worsen long­term outcome.
Mediation of secondary insults reduces morbidity and mortality and is discussed in the treatment section.
The secondary neurotoxic cascade is a massive release of neurotransmitters, such as glutamate, into the presynaptic space, with activation of N­
 methyl­D­aspartate, α­amino­3­hydroxy­5­methyl­4­isoxazole propionic acid, and other receptors. Ionic shifts activate cytoplasmic and nuclear
,25,26 enzymes, induce mitochondrial damage, and lead to cell death and necrosis. Proinflammatory cytokines and other enzymes are released in an attempt to clean and repair the damage. Secondary injury, however, is indiscriminate and produces extensive neuronal loss. Additionally, many
 survivable cells undergo apoptosis, or programmed cell death, during secondary injury. Apoptosis has been reported to occur longer than a year
,28 after injury.
BRAIN EDEMA

Brain edema results from two distinct processes and can be fatal in TBI. Cellular swelling, or cytotoxic edema, results from large ionic shifts and the loss of cellular membrane integrity from mitochondrial damage (loss of adenosine triphosphate, ion pump productivity, and increased free radical production). Extracellular edema results from direct damage to, or the breakdown of, the blood–brain barrier, ionic shifts, and alteration of water
,31 exchange mechanisms (e.g., aquaporins). As intracellular and extracellular water content rises, the brain swells and the ICP increases, leading to direct compressive tissue damage, vascular compression­induced ischemia, brain parenchyma herniation, and brain death.
BRAIN HERNIATION
There are four major brain herniation syndromes: uncal transtentorial, central transtentorial, cerebellotonsillar, and upward posterior fossa. The most common is uncal herniation, which occurs when the uncus of the temporal lobe is displaced inferiorly through the medial edge of the tentorium.
This is usually caused by an expanding lesion in the temporal lobe or lateral middle fossa. Uncal transtentorial herniation leads to compression of parasympathetic fibers running with the third cranial (oculomotor) nerve, causing an ipsilateral fixed and dilated pupil due to unopposed sympathetic tone. Further herniation compresses the pyramidal tract, which results in contralateral motor paralysis. In some cases, the pupillary changes can be contralateral, whereas the motor changes are ipsilateral.
Central transtentorial herniation is less common and occurs with midline lesions, such as lesions of the frontal or occipital lobes, or vertex. The most prominent symptoms are bilateral pinpoint pupils, bilateral Babinski’s signs, and increased muscle tone. Fixed midpoint pupils follow along with prolonged hyperventilation and decorticate posturing.
Cerebellotonsillar herniation occurs when the cerebellar tonsils herniate through the foramen magnum. This may lead to pinpoint pupils, flaccid paralysis, and sudden death. Upward transtentorial herniation results from a posterior fossa lesion and leads to a conjugate downward gaze with absence of vertical eye movements and pinpoint pupils.
CLINICAL FEATURES
The results of history, examination, and diagnostic imaging will allow the distinction into two categories of injury: moderate­severe brain injury and mild brain injury. Treatment and disposition are quite different in the two categories and are detailed later in this chapter.
HISTORY
Obtain an accurate history from the patient, witnesses, and EMS crew members to gain important insight into the mechanism of injury and overall severity of TBI (e.g., height of fall, impact surface condition, damage sustained to vehicle, air bag deployment, seat belt use, history of ejection from the vehicle, or report of fatalities at the scene). Premorbid medical history, medications (especially anticoagulants), drug use, and/or alcohol intoxication are also important in the assessment and treatment of acute TBI. Initial clinical findings and physical exam as reported by EMS are an essential component of triaging and managing TBI. The presence of a focal neurologic deficit, seizures, emesis, or depressed level of consciousness increases concern for underlying brain injury.
THE GLASGOW COMA SCALE
TBI severity is classified using the GCS (Table 257­3). The scale is composed of three components: eye opening (1 to  points), verbal response
(1 to  points), and motor response (1 to  points) (Table 257­3). The sum of these components defines the TBI severity classification into severe (GCS score of  to 8), moderate (GCS score of  to 13), and mild (GCS score of  or 15). The motor score independently correlates with outcome, almost as
 well as the full score.
TABLE 257­3
Glasgow Coma Scale for All Age Groups
 y to Adult Child <4 y Infant
Eye opening
 Spontaneous Spontaneous Spontaneous
 To speech To speech To speech
 To pain To pain To pain
 No response No response No response
Verbal response
 Alert and oriented Oriented, social, speaks, interacts Coos, babbles
 Disoriented conversation Confused speech, disoriented, consolable, aware Irritable cry
 Speaking but nonsensical Inappropriate words, inconsolable, unaware Cries to pain
 Moans or unintelligible sounds Incomprehensible, agitated, restless, unaware Moans to pain
 No response No response No response
Motor response
 Follows commands Normal, spontaneous movements Normal, spontaneous movements
 Localizes pain Localizes pain Withdraws to touch
 Moves or withdraws to pain Withdraws to pain Withdraws to pain
 Decorticate flexion Decorticate flexion Decorticate flexion
 Decerebrate extension Decerebrate extension Decerebrate extension
 No response No response No response
Total score range: 3–15
Note: In intubated patients, the Glasgow Coma Scale verbal component is scored as a , and the total score is marked with a “T” (or tube) denoting intubation (e.g.,
8T).
The GCS is an objective measurement of clinical status, correlates with outcome, is a reliable tool for interobserver measurements, and is effective for measuring patient recovery or response to treatment over time. However, the scale has several limitations. It measures behavioral responses, not the underlying pathophysiology. Patients with similar GCS scores may have dramatically different underlying structural injuries and require different clinical interventions (Figure 257­2). It is not as useful for defining severity at one point in time; rather, it is intended to gauge disease progression over time. Serial GCS exams provide a broader picture of neurologic recovery and/or worsening. ED documentation and EMS documentation of best
GCS after resuscitation are important for prognostication. The GCS may be confounded by drugs; alcohol; medications; paralytics; or ocular, spinal, or peripheral extremity injuries. The GCS is designed for moderate and severe TBI and lacks the granularity necessary to assess mTBI.
FIGURE 257­2. Each of these CT images shows a distinct trauma­induced pathophysiologic abnormality, yet all patients had a Glasgow Coma Scale score of . TBI = traumatic brain injury. [Image used with permission of Alisa Green, MD, University of California, San Francisco.]
33­35
The motor GCS (simplified GCS) consists of three motor variables (Table 257­4). The motor GCS has been validated in multiple large studies.
Scores <2 predict the need for ED intubation, clinically significant brain injuries, and the need for neurosurgical intervention, with similar accuracy to the full GCS.
TABLE 257­4
Simplified/Motor Glasgow Coma Scale
Criteria Value
Obeys commands +2
Localizes pain +1
Withdraws to pain or worse 
PHYSICAL EXAMINATION
Follow Advanced Trauma Life Support principles to perform the trauma­focused examination, with simultaneous lifesaving procedures as needed.
Protect the cervical spine during evaluation, treatment, and imaging.
Obtain the GCS. Classify the injury as severe (GCS score of  to 8), moderate (GCS score of  to 13), or mild (GCS score of  or 15). If emergency intubation is necessary, obtain a preintubation GCS and record the patient’s best score.
Determine pupillary response. In an unresponsive patient, a single fixed and dilated pupil may indicate an intracranial hematoma with uncal herniation that requires rapid surgical decompression. Bilateral fixed and dilated pupils suggest increased ICP with poor brain perfusion, bilateral uncal herniation, drug effect (e.g., atropine), or severe hypoxia. Bilateral pinpoint pupils suggest either opiate exposure or a central pontine lesion.
Altered motor function can indicate brain, spinal cord, or peripheral nerve injuries. Assess movement in a coma patient by observing the patient’s reaction to noxious stimuli, such as pressure to a nail bed. Assessment of symmetry, as well as gradation of motor strength is important initially and upon serial neurologic exams. Decorticate posturing (upper extremity flexion and lower extremity extension) indicates severe intracranial injury above the level of the midbrain. Decerebrate posturing (arm extension and internal rotation with wrist and finger flexion and internal rotation and extension of the lower extremities) indicates a more caudal injury. For completely unresponsive patients, respiratory pattern and eye movements can provide information regarding brainstem function. Pupillary reflex, corneal reflex, cough, and gag reflexes will offer information on the patient’s brainstem function. Do not assess oculovestibular (cold caloric) and oculocephalic (doll’s eyes) responses in a patient under cervical spine precautions.
IMAGING
Individually assess each patient’s mechanism of injury, history, comorbidities, and signs and symptoms when determining the need for CT imaging of the head and cervical spine.
Head CT is exquisitely sensitive to the presence of blood and guides ED management. Do not delay head CT; expanding hemorrhagic lesions need emergency neurosurgical intervention. Therefore, if the patient is uncooperative or combative, endotracheal intubation and sedation are often the best options to enable rapid CT imaging. Other means to control agitated patients with TBI include midazolam (1 to  milligrams IV) and propofol (20 milligrams every  seconds to desired effect).
36­40
Several decision rules have been developed to minimize unnecessary head CT imaging. The guidelines strive to identify patients with surgical
 emergencies. These studies do not specifically address the relationship between minor CT findings (Figure 257­3) (which may place the patient at risk for the development of seizures), the duration of postconcussive symptoms, and progressive changes on CT during the course of a patient’s evaluation. Adults with mTBI and a GCS score of  or  will have an intracranial lesion on CT up to 15% of the time; <1% will require neurosurgical
 intervention.
FIGURE 257­3. Sample comparison between images used for standard ABC/2 (A) and three­dimensional image analysis (B and C) methods in quantification of
 subdural hematoma. ABC/2 is a method for estimating the volume of intracerebral hemorrhage derived from multiplanar CT measurements. [Images contributed by Derek Merck, PhD, and Scott Collins, RT, (R) (CT), Rhode Island Hospital, Brown University.]
The prevalence of cervical fractures in comatose TBI patients is approximately 8%, and an estimated 4% of injuries are missed on the initial
 assessment of the trauma patient. Cervical imaging is a vital component in the care of the brain­injured patient. Perform CT imaging of the cervical spine in patients with altered mental status and who were injured by a mechanism that increases the risk of cervical spine injury. CT is superior to plain radiography in patients with altered mental status and can be performed at the same time as the head CT.
The NEXUS (National Emergency X­Radiography Utilization Study) and Canadian Cervical Spine Rules are discussed in detail in Chapter
258, “Spine Trauma.”
MRI can detect subtle lesions missed by CT imaging and can better define the extent of contusions. However, MRI cannot be performed if the patient is unstable, and is not always available.
DECISION RULES FOR HEAD CT IMAGING IN ADULTS
Decision rules can guide clinical practice, but each patient must be assessed individually, and none of the rules described here address short­ or longterm nonoperative sequelae of TBI. See Chapter 110, “Pediatric Trauma,” for a discussion of the role of head CT imaging in children with minor head injury.

The two most commonly used evidence­based clinical decision rules for head CT in adults are the New Orleans Criteria and the Canadian CT

Head Rule (Table 257­5). Both rules have been validated and are 100% sensitive in detecting patients who will need neurosurgical intervention, but they have limited specificity (5% vs. 37%, respectively). The Canadian CT Head Rule is less sensitive (83%) if intracranial lesion is the defined end point. The studies used to validate these rules included loss of consciousness and/or amnesia as inclusion criteria and technically are not valid for patients who do not have these features.Most minor brain injury events do not result in loss of consciousness, and loss of consciousness is not the best predictor of intracranial pathology. Do not apply these rules to patients taking anticoagulants or antiplatelet agents or to children, because these variables were not included in the validation studies.
TABLE 257­5
New Orleans Criteria and Canadian CT Head Rule Clinical Decision Rules
New Orleans Criteria—GCS 15* Canadian CT Head Rule—GCS 13–15* Headache GCS <15 at  h
Vomiting Suspected open or depressed skull fracture
Age >60 y Age ≥65 y
Intoxication >1 episode of vomiting
Persistent antegrade amnesia Retrograde amnesia >30 min
Evidence of trauma above the clavicles Dangerous mechanism (fall >3 ft or struck as pedestrian or fall >5 stairs)
Seizure Any sign of basal skull fracture
Identification of patients who have an intracranial lesion on CT
100% sensitive, 5% specific 83% sensitive, 38% specific
Identification of patients who will need neurosurgical intervention
100% sensitive, 5% specific 100% sensitive, 37% specific
Abbreviation: GCS = Glasgow Coma Scale.
*Presence of any one finding indicates need for CT scan.
The National Institute for Clinical Excellence and the Neurotraumatology Committee of the World Federation of Neurosurgical Societies have evaluated
,40 clinical signs and symptoms associated with TBI in adults and adolescents and adults, respectively. The resultant decision rules for head CT have been applied to large data sets and shown to be relatively sensitive (National Institute for Clinical Excellence: 94% for neurosurgical lesions, 82% for intracranial lesions; Neurotraumatology Committee: 100% for neurosurgical lesions and intracranial injuries). One study evaluated 1101 patients with mTBI who had GCS scores of  or ; approximately 2% of these patients without loss of consciousness had intracranial lesions and .6% required surgery (rates similar to patients with loss of consciousness).
One of the most important findings from these studies is the relative significance of certain elements of the history and physical examination. For example, nausea and vomiting after concussion has an odds ratio comparable to that of loss of consciousness for a positive CT finding (Table 257­6).
Importantly, the predictive value of individual clinical signs and symptoms differs between adults and children (see Chapter 111, “Minor Head Injury and Concussion in Children”). A combination of rules helps identify patients at risk and determine the possible need for a head CT (Tables 257­5 and
257­6).
TABLE 257­6
Odds Ratio (OR) for Head CT and Clinical Features
Smits et al38 Ibanez et al39 Fabbri et al40
OR (95% CI) OR (95% CI) OR (95% CI)
Glasgow Coma Scale score of   (1–3)  (4–14)  (14–26)
Neurologic deficits  (1–3)  (2–25)  (13–28)
Signs of basilar skull fracture  (8–22)  (6–23)  (6–16)
Loss of consciousness  (1–3)  (4–11)  (2–3)
Posttraumatic amnesia .7 (1–2)  (2–5)  (6–12)
Headache .4 (1–2)  (2–6)* —
Vomiting  (2–4)  (2–7)  (3–8)
Posttraumatic seizure  (1–10)  (0.25–17)  (2–5)
Intoxication  (0.6–2)  (0.3–3) —
Antithrombotics  (1–4)  (3–7)  (3–9)
Age >65 y —  (1–3)  (1–3)
Dangerous mechanism of injury  (1–4) —  (2–4)
Abbreviation: CI = confidence interval.
*For severe headache.
PREHOSPITAL TREATMENT
Early appropriate management can have a profound impact on the patient’s final outcome. For patients with moderate to severe head injury, provide stabilization and rapid transport to a facility with experience in the management of brain injury. The most important prehospital interventions are
 airway and blood pressure management. If the patient needs prehospital intubation, avoid hyperventilation (which causes cerebral vasoconstriction and can negatively affect outcome), and use capnometry to keep PCO at  to  mm Hg. Treat hypotension aggressively. If transport times are short,
 do not give mannitol or hypertonic saline for presumptive elevated ICP. Guidelines for prehospital care are available at http://www.braintrauma.org.
ED TREATMENT
The primary goals of treatment are to maintain cerebral perfusion and oxygenation by optimizing intravascular volume and ventilation; prevent secondary injury by correcting hypoxia, hypercapnia, hyperglycemia, hyperthermia, anemia, or hypoperfusion; recognize and treat elevated ICP;
,20 arrange for neurosurgical intervention to evacuate intracranial mass lesions; and treat other life­threatening injuries.

Systolic blood pressure of <90 mm Hg and hypoxemia (PaO <60 mm Hg) are associated with a 150% increased risk in mortality.

Observe for the signs/symptoms of elevated ICP: change in mental status, pupillary irregularities, focal neurologic deficits, decerebrate or decorticate posturing, or CT pathology. Some CT signs of intracranial hypertension are loss of symmetry, attenuation of the visibility of sulci and gyri, compressed lateral ventricles, and poor gray/white matter distinction. Papilledema is a sign of increased ICP; however, it may not be evident early in the patient’s course. Sedation and analgesia may decrease baseline ICP and prevent transient rises in ICP attributed to agitation, coughing, or gagging from the endotracheal tube. Control seizure activity, which also is associated with transient increases in ICP.
Treat hypotension, hypoxemia, hypercarbia, and hyperglycemia. A single occurrence of hypotension and hypoxia after brain injury is
 associated with a 150% increase in mortality. TBI is progressive, so appropriate early management will have a greater impact on outcome than treatments initiated after neuronal cell death and the development of secondary injury, such as cerebral edema. Jointly develop and apply goaldirected protocols with emergency medicine, trauma, neurosurgery, and intensive care teams. An example of early goal­directed therapy is provided in
Table 257­7. TABLE 257­7
Checklist for ED Treatment of Brain Injury
Treatment Comments
Cervical spine Spinal precautions
Airway Maintain airway, intubate for GCS <8 or as needed
Oxygenation and Oxygen saturation >90%; PCO2 35–45 mm Hg No prophylactic hyperventilation ventilation
BP Systolic BP >90 mm Hg, MAP  mm Hg; give NS, blood products, or No permissive hypotension; pressors may be required if transfuse as needed fluids not sufficient
Exam and GCS GCS before paralytics if possible; treat life­threatening injuries and Serial GCS is helpful in identifying change; keep goal of active bleeding “brain resuscitation” as top priority
Stat head CT and Identify mass lesions and signs of increased ICP Protect cervical spine until cleared cervical spine CT
Repeat exam Check GCS for changes and for signs of impending Change of >2 points should prompt further workup herniation/deterioration
Check glucose Treat hypoglycemia and hyperglycemia Hyperglycemia is bad for the brain
Control temperature Maintain between 36°C and .3°C Aggressive cooling: Tylenol®, cooling blanket, etc.
Seizure prophylaxis Give antiepileptic drug if GCS ≤10, acute seizure with injury, or Phenytoin (Dilantin®)/fosphenytoin/levetiracetam abnormal head CT scan
Identify and treat Keep head of the bed at  degrees; ensure good BP, ventilation, Consider adding hypertonic saline (3% NaCl 250 mL/30 elevated ICP, and temperature control; give mannitol  gram/kg IV bolus; urgent min) for refractory elevations in ICP; monitor BP and herniation NS consult electrolytes
Neurosurgery ICP monitoring, ventriculostomy for ICP management, aggressive ICP monitoring and CSF diversion in GCS ≤8 referral/transfer for tiered approach to management, emergency surgery advanced care
Abbreviations: BP = blood pressure; CSF = cerebrospinal fluid; GCS = Glasgow Coma Scale; ICP = intracranial pressure; MAP = mean arterial pressure; NS = normal saline.
Airway and Breathing
Treat any condition that compromises ventilation (e.g., altered mental status, facial/neck trauma, pneumothorax). Patients with severe injury
(GCS score of≤8) require intubation. Use short­acting induction agents that have limited effect on blood pressure or ICP (Table 257­8). Avoid nasotracheal intubation if facial trauma or basilar skull fracture is evident or suspected. Monitor blood pressure throughout the procedure.
Preinduction agents such as low­dose succinylcholine, vecuronium, pancuronium, and lidocaine do not improve outcome, but can be used as adjuncts
 if they do not delay airway control. Ketamine is not advocated by the Brain Trauma Foundation or American College of Surgeons and can cause adverse reactions such as agitation in patients after trauma. The authors do not recommend ketamine as a preintubation agent. Maintain inline cervical spine stabilization during intubation.
TABLE 257­8
Intubation Agents in Brain Injury
Agent Comments
Induction agent
Etomidate, .3 milligram/kg IV May be neuroprotective; may lower intracranial pressure; adrenal suppression unlikely with single use
Propofol 1–3 milligrams/kg IV Rapid onset and offset; antiseizure properties; can cause hypotension if inadequate fluid resuscitation
Paralytics
Succinylcholine 1–1.5 milligrams/kg IV Short acting; avoid in burns, extensive muscle injury, etc.
Rocuronium, .6–1.0 milligram/kg IV Short acting, safe in hyperkalemia
Maintain oxygenation and use capnometry to control PCO and avoid hyperventilation. Prolonged (>6 hours) hypocapnia causes cerebral
 vasoconstriction and worsens cerebral ischemia. Keep oxygen saturation >90%, PaO >60 mm Hg, and PCO at  to  mm Hg.

Circulation
Traumatic hypotension leads to ischemia within low­flow regions of the injured brain. Ischemia amplifies the neurotoxic cascade and increases cerebral edema. Provide aggressive fluid resuscitation to prevent hypotension and secondary brain injury. Normal saline is recommended for volume resuscitation. Maintain systolic blood pressure at ≥100 mm Hg for patients  to  years old or at ≥110 mm Hg for patients  to 
,24,47,48 years old or >70 years old. A blood pressure within “normal” range may be inadequate to maintain adequate flow and CPP if ICP is increased. Permissive hypotension worsens outcome in patients with brain injury.
Isolated head injury rarely produces hypotension, except as a preterminal event. Hypovolemic shock may be seen with polytrauma, massive blood loss from scalp lacerations, or in small children from subgaleal hematoma. If fluid and blood resuscitation is not effective, use vasopressors to preserve cerebral perfusion. Transfusion has been associated with improved outcomes in TBI, and studies have associated anemia, defined as a hemoglobin <8
,49,50 grams/dL, with worsening outcome after brain injury.
Pain and increased ICP can cause hypertension. Treat pain, and assess for impending herniation (Cushing reflex). For management, see discussion within this chapter under “Increased Intracranial Pressure Management” section.
Patient Positioning
Raising the head of the bed may improve cerebral blood flow by lowering ICP. However, the interaction between ICP, MAP, and tissue oxygenation is complex and highly variable. Response to position change depends on many factors such as degree of intact autoregulation, brain compliance, and individual patient variability. There is still uncertainty as to whether this procedure is beneficial, but in the setting of suspected elevated ICP, it is currently recommended as a simple maneuver to improve cerebral blood flow. One must ensure that the patient’s blood pressure is maintained above the minimum recommended level (MAP  mm Hg), because elevation of  degrees can drop the mean pressure within the brain by up to  to  mm
Hg and improve CPP. (Remember CPP = MAP ­ ICP, so lowering the ICP improves CPP, but lowering MAP in the setting of hypotension could be counterproductive and lower CPP.) Elevating the head of the bed to  degrees can be safely accomplished even when the spine has not been cleared,
 as long as the cervical spine is stabilized within a collar (reverse Trendelenburg).
Glucose Control
Hyperglycemia in the setting of neurologic injury (both stroke and TBI) is associated with worse outcome. Tight hyperglycemic control is recommended in patients with moderate to severe TBI. Insulin drips may be required to achieve adequate control (glucose 100 to 180 milligrams/dL or .55 to .99
 mmol/L).
Temperature Control
Elevated temperature is associated with an increased metabolic demand and excessive glutamate release. Elevated temperature elevates ICP and worsens outcome in many neurologic critical care conditions including TBI. Treat fever with the goal of normothermia. The evidence for hypothermia
 in TBI is not sufficient to recommend its use.
Seizure Treatment and Prophylaxis
Seizures after head injury can change the neurologic examination, alter oxygen delivery and cerebral blood flow, and increase ICP. Prolonged seizures
 can worsen secondary injury. Treat acute seizures with midazolam or lorazepam, and if seizures continue, treat as for status epilepticus. In consultation with the neurosurgeon, administer prophylactic phenytoin/phosphenytoin if the GCS is ≤10, if the patient has an abnormal head CT scan, or if the patient has had an acute seizure after the injury. The dose is  milligrams/kg IV at  milligrams/min. Prophylactic anticonvulsants reduce the occurrence of posttraumatic seizures within the first week. Phenytoin/phosphenytoin is the agent most studied. Levetiracetam can be used, but there
 are fewer data supporting its use. Steroids have no role in the treatment of TBI.
Cerebral Herniation
Develop a team approach to ICP management between emergency medicine, neurosurgery, intensive care unit, and trauma teams.
Use patient history and physical examination to identify signs and symptoms of impending herniation. Indicators of rising ICP include severe headache, visual changes, numbness, focal weakness, nausea, vomiting, seizure, change in mental status, lethargy, hypertension, coma, bradycardia, and agonal respirations. Signs of impending transtentorial herniation include unilateral or bilateral pupillary dilation, hemiparesis, motor posturing, and/or progressive neurologic deterioration.
Measure neurologic deterioration by comparing sequential GCS scores. In a patient with a rapidly deteriorating GCS, if time permits, obtain a repeat head CT to identify an expanding intracranial hematoma.
Mannitol and/or hypertonic saline can lower ICP. Mannitol is an osmotic agent that can reduce ICP and improve cerebral blood flow, CPP, and brain metabolism. Mannitol is also a free radical scavenger. It generally has an effect within  minutes. Mannitol expands plasma volume and can improve oxygen­carrying capacity. Administer mannitol by repetitive bolus (0.25 to  gram/kg) and not by constant infusion. Because no dosedependent effect is seen with mannitol, some clinicians advocate beginning at the lower range of the suggested dose. Mannitol results in a net intravascular volume loss because of its diuretic effect. Monitor the patient’s input and output. Osmotic diuresis is relatively contraindicated in hemorrhage and hypotension. However, in the setting of acute herniation, mannitol has been demonstrated to effectively reduce life­threatening elevations of ICP.
Hypertonic saline may be used as an alternative to mannitol in the patient who is not adequately fluid resuscitated or hypotensive. The Brain Trauma
Foundation indicates that at this time, data support the primary use of mannitol for the acute treatment of ICP. Most EDs have 3% sodium chloride available; the dose for adults is 250 mL over  minutes. Intensive care units may stock .4% sodium chloride solution; the dose for adults is  mL over  minutes. Monitor serum osmolality and serum sodium.
Mannitol and hypertonic saline may be given serially and in conjunction with one another.
ADVANCED TREATMENT OF BRAIN INJURY
Advanced treatment of brain injury requires invasive and close monitoring (Table 257­9).
TABLE 257­9
Goal­Directed Therapy of Brain Injury
Goal­Directed Therapy—Suggested Targets
Pulse oximetry ≥90% CPP ≥60 mm Hg Physiologic sodium 135–140 mEq/L
SBP ≥90 mm Hg ICP <20 mm Hg INR ≤1.4
MAP ≥80 mm Hg PbtO ≥15 mm Hg Platelets ≥75 × 103/mm3

PaCO2 35–45 mm Hg pH .35–7.45 Hemoglobin ≥8 grams/dL
Temperature .0°C–38.3°C Glucose 80–180 milligrams/dL
Abbreviations: CPP = cerebral perfusion pressure; ICP = intracranial pressure; MAP = mean arterial pressure; PbtO = brain tissue oxygen tension monitoring; SBP =
 systolic blood pressure.
Cerebral Perfusion Pressure Management
If the GCS is≤8, arrange for placement of an intracranial bolt or extraventricular drain with monitoring capabilities as soon as possible to monitor ICP and to direct treatment. The Brain Trauma Foundation recommends a target CPP of between  and  mm Hg in order to improve survival and outcomes. Increasing CPP >70 mm Hg may result in injury to other organs (e.g., acute respiratory distress syndrome from lung tissue trauma), and further research is needed in this area.
Consider ICP monitoring for patients with a normal admission brain CT scan if two or more of the following criteria are met: age over  years, unilateral or bilateral motor posturing, and systolic blood pressure <90 mm Hg. In addition, provide ICP monitoring in patients undergoing emergency surgery (e.g., orthopedic repair). Management of CPP is essential intraoperatively, where the patient with elevated ICP may experience large shifts in central volume status due to surgical blood loss.
Increased Intracranial Pressure Management
An ICP of >20 mm Hg increases morbidity and mortality. Early consultation with neurosurgery for direct ICP monitoring, cerebrospinal fluid diversion, or surgical intervention is highly recommended in moderate and severe TBI. In certain circumstances, an ICP monitor will be placed in the ED by
,18,21,24 neurosurgery to help guide medical management, as well as for direct cerebrospinal fluid diversion to lower ICP.
SPECIFIC HEAD INJURIES
SCALP LACERATIONS
Scalp lacerations can lead to massive blood loss, so control bleeding as rapidly as possible. If direct pressure is not effective, locally infiltrate lidocaine with epinephrine and clamp or ligate bleeding vessels. Before closure, carefully examine wounds to identify foreign bodies, underlying fractures, and galeal lacerations. Large galeal disruptions should be repaired. For discussion of repair of scalp lacerations, see Chapter , “Face and Scalp
Lacerations.”
SKULL FRACTURES
Patients who have or are suspected of having a skull fracture require a head CT scan. Skull fractures are usually categorized by location (basilar vs.
skull convexity), pattern (linear, depressed, or comminuted), and whether they are open or closed (Figures 257­4 and 257­5). A linear skull fracture with an overlying laceration is an open fracture. Explore wounds gently to avoid driving bone fragments into the brain.
FIGURE 257­4. Linear fracture seen on CT. Arrow indicates skull fracture; asterisks indicate normal cranial suture lines. [Image used with permission of Joseph Piatt,
Jr., MD, Division of Neurosurgery, A. I. duPont Hospital for Children, Wilmington, Delaware; Departments of Neurological Surgery and Pediatrics,
Thomas Jefferson University, Philadelphia, Pennsylvania.]
FIGURE 257­5. Open skull fracture with underlying cerebral contusion. This injury was sustained from a fall of two stories. [Image used with permission of Joseph
Piatt, Jr., MD, Division of Neurosurgery, A. I. duPont Hospital for Children, Wilmington, Delaware; Departments of Neurological Surgery and Pediatrics,
Thomas Jefferson University, Philadelphia, Pennsylvania.]
Fractures that cross the middle meningeal artery, a major venous sinus, or linear occipital fractures have high intracerebral complication rates.
Patients with skull fractures that are open or depressed, involve a sinus, or are associated with pneumocephalus should be given antibiotics
(vancomycin,  gram IV, and ceftriaxone,  grams IV). A skull fracture that is depressed by more than the thickness of the skull usually requires operative repair.
BASILAR SKULL FRACTURE AND CEREBROSPINAL FLUID LEAKS
The presence of a basilar skull fracture is a significant risk factor for intracranial injury. The most common basilar skull fracture involves the petrous portion of the temporal bone, the external auditory canal, and the tympanic membrane. It is associated with dural tearing, which often leads to otorrhea or rhinorrhea. Basilar skull fractures may occur anywhere along the skull base, from the cribriform plate through the occipital condyles. Do not place a nasogastric tube through the nares if cribriform plate fracture is suspected; this can lead to direct intracranial injury. Signs and symptoms associated with basilar skull fractures include cerebrospinal fluid leak, mastoid ecchymosis (Battle sign), periorbital ecchymoses (raccoon eyes), hemotympanum, vertigo, decreased hearing or deafness, and seventh nerve palsy. Periorbital and mastoid ecchymoses develop gradually over hours after an injury and are often absent in the ED. Cerebrospinal fluid leaks (otorrhea or rhinorrhea) are difficult to diagnose; however, the patient often complains of discharge of clear fluid from the nose or ears. Fluid may be collected and sent for analysis
(identification of β­transferrin). The β ­transferrin isoform of transferrin is found only in cerebrospinal fluid, and not in blood, mucus, or tears.

Patients with acute cerebrospinal fluid leaks are at risk for meningitis. Antibiotic prophylaxis is often recommended to reduce the incidence of
 infection. Administration of antibiotics should be done in consultation with the neurosurgeon who will be following the patient. If prophylactic antibiotics are instituted, the drugs selected should have broad coverage with good penetration into the meninges, such as ceftriaxone,  grams IV, and vancomycin,  gram IV. Elevate the head of the patient’s bed to  degrees. A lumbar drain is often placed by the neurosurgical team. Cerebrospinal fluid leaks may require repair by a neurosurgeon or otolaryngologist.
CEREBRAL CONTUSION AND INTRACEREBRAL HEMORRHAGE
Contusions most commonly occur in the subfrontal cortex, in the frontal and temporal lobes, and, occasionally, in the occipital lobes (Figure 257­6).
They are often associated with subarachnoid hemorrhage. Contusions may occur at the site of the blunt trauma or on the opposite side of the brain, known as a contrecoup injury.
FIGURE 257­6. CT scan demonstrating delayed intraparenchymal hemorrhages from a traumatic contusion. [Image used with permission of Jack Fountain, Jr., MD,
Emory University and Grady Memorial Hospital.]
Intracerebral hemorrhage can occur days after significant blunt trauma, often at the site of resolving contusions. This complication is more common in patients with coagulopathy. CT scan findings immediately after injury may be normal. Obtain serial CTs if any change in mental status occurs in a patient with coagulopathy until the clot is stable.
SUBARACHNOID HEMORRHAGE
Traumatic subarachnoid hemorrhage results from the disruption of the parenchyma and subarachnoid vessels and presents with blood in the cerebrospinal fluid (Figure 257­7). Patients with isolated traumatic subarachnoid hemorrhage may present with headache, photophobia, and meningeal signs. Traumatic subarachnoid hemorrhage is the most common CT abnormality in patients with moderate to severe TBI.
Patients with early development of traumatic subarachnoid hemorrhage have a threefold higher mortality risk than those without traumatic
 subarachnoid hemorrhage (42% vs. 14%, respectively). Some traumatic subarachnoid hemorrhages can be missed on early CT scans. Generally, CT scans performed  to  hours after injury are sensitive for detecting traumatic subarachnoid hemorrhage.
FIGURE 257­7. CT scan demonstrating subarachnoid hemorrhage. Arrow  indicates prepontine cisternal blood, and arrow  identifies blood in the ambient cistern.
[Image used with permission of Jack Fountain, Jr., MD, Emory University and Grady Memorial Hospital.]
EPIDURAL HEMATOMA
An epidural hematoma results when blood collects in the potential space between the skull and the dura mater (Figure 257­8). The anatomic relationships of the branches of the middle meningeal artery and the sequelae of fracture and laceration of the artery are shown in Figure 257­2. FIGURE 257­8. Epidural hematoma. Note the convex shape and focal location. [Image used with permission of Jack Fountain, Jr., MD, Emory University and Grady
Memorial Hospital.]
Blunt trauma to the temporal or temporoparietal area with an associated skull fracture and middle meningeal arterial disruption is the primary mechanism of injury. Occasionally, trauma to the parieto­occipital region or the posterior fossa causes tears of the venous sinuses with epidural hematomas.
The classic history of an epidural hematoma involves a significant blunt head trauma with loss of consciousness or altered sensorium, followed by a lucid period and subsequent rapid neurologic demise. This clinical presentation occurs in a minority of cases. Traumatic blows to the thin temporal bone over the lateral aspect of the head carry the highest risk (e.g., baseball or pool stick injury). The diagnosis of an epidural hematoma is based on
CT scan and physical examination findings. The CT appearance of an epidural hematoma is a biconvex (football­shaped) mass, typically found in the temporal region.
The high­pressure arterial bleeding of an epidural hematoma can lead to herniation within hours after an injury. Early recognition and evacuation reduce morbidity and mortality. Underlying injury of the brain parenchyma is often absent; full recovery may be expected if the hematoma is evacuated prior to herniation or the development of neurologic deficits.
SUBDURAL HEMATOMA
Subdural hematoma is caused by sudden acceleration­deceleration of brain parenchyma with subsequent tearing of the bridging dural veins. This results in hematoma formation between the dura mater and the arachnoid (Figures 257­9 and 257­10). Subdural hematoma tends to collect more slowly than epidural hematoma because of its venous origin. However, subdural hematoma is often associated with concurrent brain injury and underlying parenchymal damage. Brains with extensive atrophy, such as in the elderly or in chronic alcoholics, are more susceptible to the development of acute subdural hematoma. Even seemingly benign falls from standing position can result in subdural bleeding in the elderly.
Children <2 years old are also at increased risk of subdural hematoma.
FIGURE 257­9. Small subdural hematoma in the right frontotemporal region in an adult. [Image used with permission of Jack Fountain, Jr., MD, Emory University and
Grady Memorial Hospital.]
FIGURE 257­10. A. Bifrontal chronic subdural hematoma extending through the anterior fontanelle in a 1­month­old child. B. Second image in the same child showing bifrontal chronic subdural hematoma, as well as small, acute intraparenchymal hemorrhage in the posterior fossa.
Traditionally, subdural hematomas have been classified as acute, subacute, or chronic depending on the length of time from onset and occurrence of active hemorrhage. Acute symptoms usually develop within  days of the injury. After  weeks, the term chronic subdural hematoma is used. There is no specific clinical syndrome associated with a subdural hematoma. Acute cases usually present immediately after severe trauma, and often the patient is unconscious. In the elderly or in alcoholics, chronic subdural hematomas may result in vague complaints or mental status changes. Often, there is no recall of injury. On CT scan, acute subdural hematomas are hyperdense (white), crescent­shaped lesions that cross suture lines. Subacute subdural hematomas are isodense and are more difficult to identify. CT scanning with IV contrast or MRI can assist in identifying a subacute subdural hematoma. A chronic subdural hematoma appears hypodense (dark) because the iron in the blood has been metabolized.
The definitive treatment depends on the type, size, effect on underlying brain parenchyma, and the associated brain injury. Mortality and the need for surgical repair are greater for acute and subacute subdural hematomas. Chronic subdural hematomas can sometimes be managed without surgery depending on the severity of the symptoms. Table 257­10 compares intracranial injuries.
TABLE 257­10
Comparison of Intracranial Injuries
Type of Anatomic
CT Findings Common Cause Classic Symptoms
Patient Location
Epidural Young, rare in Potential space Biconvex, football­ Skull fracture with tear Immediate LOC with a “lucid” the elderly and between skull shaped hematoma of the middle period prior to deterioration those age <2 y and dura mater meningeal artery (only occurs in about 20%)
Subdural More risk in the Space between Crescent­ or sickle­ Acceleration­ Acute: rapid LOC, lucid period elderly and dura mater and shaped hematoma deceleration with possible alcoholic arachnoid tearing of the bridging Chronic: altered mental state patients veins and behavior with gradual decrease in consciousness
Subarachnoid Any age group Subarachnoid Blood in the basilar Acceleration­ Mild, moderate, or severe after blunt cisterns and deceleration with traumatic brain injury with trauma hemispheric sulci and tearing of the meningeal signs and symptoms fissures subarachnoid vessels
Contusion/intracerebral Any age group Usually anterior May be normal Severe or penetrating Symptoms range from normal hematoma after blunt temporal or initially with delayed trauma; shaken baby to LOC trauma posterior frontal bleed syndrome lobe
Abbreviation: LOC = loss of consciousness.
DIFFUSE AXONAL INJURY
Diffuse axonal injury is the disruption of axonal fibers in the white matter and brainstem. Shearing forces on the neurons generated by sudden deceleration cause diffuse axonal injury. The condition is seen after blunt trauma, such as from a motor vehicle crash. In infants, shaken baby
 syndrome is a well­described cause.
In severe diffuse axonal injury, edema can develop rapidly. The underlying injury can result in devastating and often irreversible neurologic deficits. A
CT scan of a patient with diffuse axonal injury may appear normal, but classic CT findings include punctuate hemorrhagic injury along the gray­white junction of the cerebral cortex and within the deep structures of the brain (Figures 257­11 and 257­12). Treatment options are very limited, but an attempt should be made to prevent secondary damage by reducing cerebral edema and limiting pathologic increases in ICP.
FIGURE 257­11. Diffuse axonal injury with intraventricular blood. [Image used with permission of Jack Fountain, Jr., MD, Emory University and Grady Memorial
Hospital.]
FIGURE 257­12. Diffuse axonal injury with loss of the gray matter–white matter interface. [Image used with permission of Daniel Curry, MD, PhD, Texas Children’s
Hospital and Baylor College of Medicine.]
PENETRATING INJURY
Depending on the velocity, a bullet that passes through the brain can create a cavity three to four times larger than its diameter. Direct penetration of the bullet through the brain substance and the transfer of kinetic energy cause the majority of the destruction (Figure 257­13). The GCS can be used to predict the prognosis for nonintoxicated patients with a gunshot wound to the brain. Patients with a GCS score of >8 and reactive pupils have a 25% mortality risk, whereas mortality approaches 100% in those with a GCS score of <5. Intubate patients with a penetrating gunshot wound to the brain and treat with prophylactic antibiotics, such as vancomycin,  gram IV, and ceftriaxone,  grams IV.
FIGURE 257­13. Gunshot wound traversing through frontal lobes bilaterally; note bone fragments. [Image used with permission of Thomas Egglin, MD, Director of
Emergency Radiology and an Associate Professor of Diagnostic Imaging at the Warren Alpert Medical School of Brown University, Providence, RI.]
Stab wounds have very low energy and impart only direct damage to the area contacted by the penetrating object. Patients with penetrating injury require admission, broad­spectrum antibiotics, and operative intervention. Leave impaled objects in place until controlled surgical removal is facilitated.
MILD TRAUMATIC BRAIN INJURY
Mild traumatic brain injury (mTBI) and concussion are terms used interchangeably in this chapter. While some clinicians believe concussion to be a subset of mTBI, we do not make the distinction here. It is important that patients with an mTBI be identified in the ED, as it may be the patient’s only interaction with a healthcare entity and only chance for appropriate diagnosis and management. mTBI, an impairment in brain function without overt hemorrhage or other gross lesions, is caused by an external force, and results in a GCS score of  or  (see Chapter 110, “Pediatric Trauma,” and

Table 257­3). The diagnosis is made by a history of any alteration in consciousness or disturbance in brain function occurring at the time or shortly after the inciting mechanical force (acceleration­deceleration or blunt force). Alteration in consciousness includes the individual’s account of “getting his/her bell rung,” “seeing stars,” or being dazed or confused as a result of the force. The presence of amnesia further supports the diagnosis and is often associated with more significant injury.
Signs and symptoms such as vomiting, headache, loss of consciousness, focal neurologic deficit, age >65 years, coagulopathy, and/or dangerous
,40,55 mechanism of injury are factors that increase risk of serious injury (see Tables 257­5, 257­6, and 257­7). The presence of alcohol, distracting injuries, and other barriers to obtaining a clear history of the event confound the signs and symptoms of mTBI.
PATHOPHYSIOLOGY mTBI represents a spectrum of pathophysiology. In its mildest form, mTBI causes an ionic shift that leads to a momentary disruption in function.
Symptom recovery is rapid, and the concussive injury results in no obvious structural damage. More “severe” forms of mTBI lead to long­term and/or permanent structural damage. Mild insults may mediate gene regulation that cause fundamental changes to the brain (e.g., the upregulation of ion channels along axons). A single traumatic event has been shown to increase ion channel density. An increase in the density of ion channels leaves the brain vulnerable to overactivation. Repeated exposure to trauma during this vulnerable period greatly increases neuronal toxicity and cell death.
In addition to ion channel upregulation, large shifts in ion concentrations may lead to mitochondrial dysfunction and depletion of intracellular energy
,58­60 stores. The state creates a metabolic “mismatch” during which neuronal dysfunction persists until recovery occurs. This pathway is a recognized pattern of injury in moderate/severe TBI but is thought to also play a role in mTBI.
Metabolic insults, electrochemical imbalances (calcium influx and sodium and potassium shifts), and mitochondrial dysfunction also result in damage to axonal transport systems. Structural abnormalities are not always identified on MRI or CT. However, histopathology shows microscopic injury.
Indeed, evidence of damage on diffusion tensor imaging has been demonstrated in high school athletes after a single football season, even without
,62  clinical signs or symptoms of a concussion. Chronic traumatic encephalopathy is hypothesized to occur as a result of repeated exposure to TBI in
64­66 sports.
67­70
Repetitive concussions can result in long­term cognitive deficits and structural damage to the brain. In extreme cases, when a second concussion occurs prior to recovery from the first, rapid onset of cerebral edema and death can occur, particularly in athletes prematurely returning to play

(second impact syndrome).
DIAGNOSIS
HISTORY
The signs and symptoms of concussion can be subtle and easily overlooked, especially in patients with polytrauma in the setting of a busy ED. A systematic approach is necessary to ensure at­risk patients are identified. The physical examination findings in isolated mTBI are often normal, and by definition, head CT scans are normal. Currently, there are no objective tests that can confirm the diagnosis of concussion. The diagnosis is clinical and based on symptoms and neurologic functional impairments associated with a mechanical force.
A two­question screen can help alert clinicians to the need for further evaluation: (1) Did the patient sustain a blunt force mechanism and/or whiplashtype acceleration­deceleration event? and (2) Did the event cause any neurologic alteration in mental state (e.g., dazed, confused, loss of consciousness)? Some mTBIs may be missed by this screen, such as those with delayed onset, those that occur in the setting of polytrauma, or those that present primarily as isolated symptoms and are not initially associated with trauma. Even if a clinician is confident of an mTBI diagnosis, it is important to complete a thorough history and exam because it informs management and helps predict the patient’s recovery trajectory.
The fundamental mTBI­focused evaluation includes the following five components: (1) event history and immediate postevent symptoms; (2) mechanism; (3) key premorbid cofactors (concussion, migraine/headache, and depression history; bleeding disorders; or anticoagulant medication);
(4) current symptom checklist; and (5) concussion­specific neurologic exam.
Obtain the history of the event from the patient and a witness if possible. Symptoms may have completely resolved by the time the patient presents to the ED, and lack of current symptoms does not preclude the diagnosis. Mechanism of injury informs the level of suspicion and may instruct modifiable risk behaviors or guide management and discharge instructions, such as in the setting of sports­induced injury. When available, the patient’s medical history may provide information that needs further evaluation, such as imaging if the patient is on anticoagulants, or predict poorer recovery (history of depression, headaches, attention­deficit/hyperactivity disorder, or prior mTBI).
Symptoms are best assessed using a symptom checklist (ideally embedded in an electronic medical record). The most commonly used are those listed in the Sport Concussion Assessment Tool  or the Postconcussion Symptom Index (see
 http://bjsm.bmj.com/content/bjsports/early/2017/04/26/bjsports­2017­097506SCAT5.full.pdf). Symptoms are sensitive but nonspecific (Table 257­
11). The greater number of symptoms reported, the longer duration of symptoms, and the greater severity of symptoms all correlate with length of recovery. Treatment of acute symptoms may shorten a patient’s course.
TABLE 257­11
Signs and Symptoms of Mild Traumatic Brain Injury
Physical Signs and
Cognitive Symptoms Behavioral Changes
Symptoms
Attention difficulties Headaches Irritability
Concentration problems Dizziness Depression
Amnesia and perseveration Insomnia Anxiety
Short­term and long­term memory problems Fatigue Sleep disturbances
Uneven gait Emotional lability
Orientation problems Nausea, vomiting Loss of initiative
Altered processing speed Blurred vision Loneliness and helplessness
Altered reaction time Seizures Problems related to job, relationship, home, or school
Calculation difficulties and problems with executive management function
Note: At  months after injury, <30% are symptomatic; at  year, 15% are symptomatic.
PHYSICAL EXAMINATION
Ominous findings include an abnormal GCS, racoon’s eyes, Battle’s sign, hemotympanum, cerebrospinal fluid rhinorrhea, and an abnormal pupil exam.
The focused mTBI exam has the following five elements: (1) awareness and alertness; (2) brief cognitive assessment; (3) cervical spine assessment;
(4) oculomotor exam; and (5) balance exam.
. Alertness is grossly measured by the GCS. A patient with a GCS of <15 may not be able to cooperate with the remainder of the mTBI exam and should raise serious concerns for intracranial pathology.
. A comprehensive cognitive exam is impractical in the ED setting, but a brief exam exploring short­term memory, encoding, or working memory should be performed. In adults, serial 7’s counted backward from 100 (down to 65) is sufficient. Inability to complete or more than four errors is abnormal.
. Evaluate the cervical spine in all trauma patients with suspected head injury and prior to neck movement or ambulation. If injury is clinically suspected, order a noncontrast CT scan.
. The vestibular ocular motor system is highly complex and involves sensory integration among multiple neuronal pathways that are vulnerable to shear forces. The Vestibular Ocular Motor Screening Exam is relatively sensitive and specific for mTBI and can be rapidly performed in the ED.
The Vestibular Ocular Motor Screening Exam includes five components: near­point convergence, near­point accommodation, smooth pursuits,
 saccades, and vestibulo­ocular reflex. Published instructions are available. When scoring the Vestibular Ocular Motor Screening Exam, symptom exacerbation is as important as an abnormal functional finding.
. Balance is an important sensory integration task using visual, vestibular, and proprioception input from cortical networks that is frequently disturbed after an mTBI. Balance is initially tested in the standing position with the examiner nearby for safety. A formal Romberg’s test with feet together and eyes open and then closed (falling to one side >30 degrees, moving feet to adjust balance, or lifting hands off hips is abnormal) may illicit gross balance abnormalities. Gait assessment can also be used to interrogate balance. Normal gait should not result in swaying, wide­based gait, or slow staggered steps. The patient should be able to turn around rapidly without imbalance as well. For more intense testing, such as might be needed in an athlete, tandem gait can be tested.
BIOMARKERS
,75
Serum markers specific to neurologic injury may improve future diagnosis and management. Two protein biomarkers, glial fibrillary acidic protein
(GFAP) and ubiquitin C­terminal hydrolase­L1 (UCH­L1), were recently cleared by the U.S. Food and Drug Administration for risk­stratifying significant intracranial hemorrhage and distinguishing the need for CT in patients with presenting GCS scores of  to . UCH­L1 was found to be most sensitive
(100% sensitive and 39% specific if <40 pg/mL) at  hours after injury. UCH­LI, GFAP, and S100B had similar areas under the curve in the primary study, with GFAP and S100B having lower specificity. Rapid laboratory testing for these proteins is not yet widely available, and how to deploy the tests is still in question (e.g., what time frame after injury is optimal for testing to maintain high sensitivity). S100B is also not currently approved by the U.S. Food and Drug Administration for mTBI. Note that the studies validating these biomarkers (and the U.S. Food and Drug Administration clearance) are
76­79 specific to ruling out significant intracranial hemorrhage on CT and are not diagnostic of mTBI.
NEUROIMAGING AND ELECTROENCEPHALOGRAM
CT remains the imaging tool of choice for TBI because it is sensitive to intracranial blood and provides the clinician with the needed information regarding surgical intervention. In mTBI, CT imaging is normal. MRI is more sensitive for contusion and other subtle findings, but provides no additional actionable data to the ED clinician.
Several studies have shown the utility of using portable electroencephalogram with algorithms to determine the need for CT imaging. The devices provide a risk profile (negative, positive, equivocal) for the possibility of intracranial blood and structural abnormalities that would be visible
 on CT. BrainScope® is one device that is U.S. Food and Drug Administration cleared for such purpose and is being adopted in some EDs.
TREATMENT AND DISPOSITION mTBI is a treatable disease. Not dissimilar to the treatment of a fracture, the primary intervention is rest (“splinting the brain”). Although the duration of rest remains controversial, emerging evidence shows that physical and neurologic rest past the acute 48­hour period shortens the duration of symptoms.
ED treatment objectives are to identify patients who have intracranial lesions requiring neurosurgical intervention; to admit patients whose condition might deteriorate over time; to provide some prognostication based on the evaluation (e.g., patients with history of depression, prior concussions, multiple symptoms, abnormal Vestibular Ocular Motor Screening Exam or balance test, or who are at risk for prolonged course); to treat symptoms; to provide injury prevention messaging (especially for athletes); and for those discharged, to provide instructions for cognitive and physical rest and provide follow­up for reassessment before return to normal activities.
When the patient is safe for discharge, one of the most important “interventions” is to provide thorough concussion discharge instructions. The
Centers for Disease Control and Prevention has developed excellent discharge instructions that include a letter to school/work to help inform stakeholders of the possible need for accommodations. Physical and neurologic rest is needed until symptoms abate. Discharge the patient to the care of a responsible individual and provide instructions to both the patient and that individual. Patients with mTBI may not comprehend or remember detailed discharge instructions. Have the patient return to the ED for worsening symptoms, headaches, altered mental status, nausea, or vomiting.
Refer patients for further evaluation and follow­up care. Patients at an increased risk for reinjury, such as athletes, should undergo a formal graduated return­to­activity program (Table 257­12).
TABLE 257­12
Return­to­Activity Program
Sports Related Non–Sports Related
No activity (rest until symptom free) No activity (rest until symptom free)
Light aerobic exercise Light aerobic exercise
Sport­specific training (noncontact) Moderate aerobic exercise
Noncontact drills Return to normal activities
Full­contact drills
Game play
Note: Patient must remain asymptomatic for  hours between each step. Development of symptoms at any level requires return to the previous symptom­free level.
RETURN TO ACTIVITY
,81
Symptoms reflect underlying metabolic dysfunction and are currently the only reliable guide to brain health. Return to play or work decisions are based on symptoms and a graduated evaluation program.
Assessments incorporate serial symptom checklists, neuropsychological tests (memory and reaction time assessment), and a balance evaluation (see
,82
Table 257­12). Because this type of assessment is not practical in the ED setting, emergency physicians should not provide definitive return­to­activity directions.
SPECIAL CONSIDERATIONS
POSTCONCUSSIVE SYNDROME
Patients often report a series of physical, emotional, and cognitive symptoms in the days and weeks after mTBI. The estimated prevalence of
,84 postconcussive syndrome varies widely, with about 20% to 40% of patients reporting symptoms at  months and about 15% at  year. The most commonly reported postconcussion symptoms are headache, dizziness, decreased concentration, memory problems, sleep disturbances, irritability,
 fatigue, visual disturbances, judgment problems, depression, and anxiety. When a cluster of symptoms becomes chronic after mTBI, they are often called persistent postconcussive symptoms or postconcussion syndrome. Clinical findings at the time of the injury do not reliably predict the development of postconcussive syndrome. Postconcussive syndrome symptoms can overlap those of posttraumatic stress disorder.
Neuropsychological testing and use of a symptom checklist are the cornerstones of diagnosis and management. Treatment is symptomatic. Refer patients to a neuropsychologist or mTBI clinic.
RECURRENT CONCUSSIONS
,68,86
Three or more concussions pose a risk for long­term sequelae, especially in adolescents and young children. Almost all cases of second impact
 syndrome have occurred in young athletes. Chronic traumatic encephalopathy, characterized by early onset of memory loss and depression, is a concern in athletes who compete in collision sports. Pathologically large deposits of tau protein are seen in the brains of deceased chronic traumatic
 encephalopathy patients. Tau protein deposits have been discovered even in youth football players who died from other causes.
SECOND IMPACT SYNDROME

Second impact syndrome is a rare disorder that results in rapid cerebral edema and high mortality (60% to 80%). The pathophysiology and the predictors are not well understood. It is hypothesized that occurrence of a second impact before the brain has reset or recovered from a first mTBI causes a loss of autoregulation and ion imbalance and leads to rapid cerebral edema. This explanation fits well with the concept of enhanced
,88 vulnerability due to metabolic disturbances, energy­demand mismatch, and ion channel upregulation after a concussion.
ANTICOAGULATION

Anticoagulants and antiplatelet agents increase the risk of intracranial hemorrhage after injury, especially in the elderly.

Intracranial hemorrhage in patients taking warfarin and who have an elevated INR is associated with a high mortality rate (89%). In general, patients with head trauma, who are taking anticoagulants or antiplatelet agents, should undergo emergent head CT. The odds ratio for the risk of intracranial
  lesions after mild head injury in patients taking any antiplatelet therapy is .6. Clopidogrel use seems to be a potent risk factor. The effect of lowdose aspirin (162 mg or less taken daily) on post–head injury bleeding has not been determined. Patients with intracranial hemorrhage need immediate anticoagulant reversal. Patients taking warfarin who have an elevated INR are optimally treated with plasma or four­factor concentrate. See
Chapter 239, “Thrombotics and Antithrombotics,” and Chapter 166, “Spontaneous Subarachnoid and Intracerebral Hemorrhage,” for in­depth discussion.
A negative initial CT finding in an asymptomatic TBI patient receiving anticoagulation or antiplatelet therapy is reassuring, but delayed hemorrhage may occur and is not easily predicted.


## Page 32

University of Pittsburgh
. Stiell IG, Wells GA, Vandemheen K, et al: The Canadian CT Head Rule for patients with minor head injury. Lancet 357: 1391, 2001. [PubMed: 11356436] Access Provided by:
. Stein SC, Fabbri A, Servadei F, Glick HA: A critical comparison of clinical decision instruments for computed tomographic scanning in mild closed traumatic brain injury in adolescents and adults. Ann Emerg Med 53: 180, 2009. [PubMed: 18339447]
. Smits M, Dippel DW, Steyerberg EW, et al: Predicting intracranial traumatic findings on computed tomography in patients with minor head injury: the CHIP prediction rule. Ann Intern Med 146: 397, 2007. [PubMed: 17371884]
. Ibanez J, Arikan F, Pedraza S, et al: Reliability of clinical guidelines in the detection of patients at risk following mild head injury: results of a prospective study. J Neurosurg 100: 825, 2004. [PubMed: 15137601]
. Fabbri A, Servadei F, Marchesini G, et al: Clinical performance of NICE recommendations versus NCWFNS proposal in patients with mild head injury. J Neurotrauma 22: 1419, 2005. [PubMed: 16379580]
. Kothari RU, Brott T, Broderick JP, et al: The ABCs of measuring intracerebral hemorrhage volumes. Stroke 27: 1304, 1996. [PubMed: 8711791]
. Haydel MJ, Preston CA, Mills TJ, Luber S, Blaudeau E, DeBlieux PM: Indications for computed tomography in patients with minor head injury. N
Engl J Med 343: 100, 2000. [PubMed: 10891517]
. Nuño T, Denninghoff KR, Pauls Q, et al: Reply to: Prehospital intubation: further confounders in trial results. Prehosp Emerg Care 22: 537, 2018. [PubMed: 29338483]
. Chesnut RM, Marshall SB, Piek J, Blunt BA, Klauber MR, Marshall LF: Early and late systemic hypotension as a frequent and fundamental source of cerebral ischemia following severe brain injury in the Traumatic Coma Data Bank. Acta Neurochir Suppl 59: 121, 1993. [PubMed: 8310858]
. Marmarou A, Lu J, Butcher I, et al: Prognostic value of the Glasgow Coma Scale and pupil reactivity in traumatic brain injury assessed pre­hospital and on enrollment: an IMPACT analysis. J Neurotrauma 24: 270, 2007. [PubMed: 17375991]
. Robinson N, Clancy M: In patients with head injury undergoing rapid sequence intubation, does pretreatment with intravenous lignocaine/lidocaine lead to an improved neurological outcome? A review of the literature. Emerg Med J18: 453, 2001. [PubMed: 11696494]
. Berry C, Ley EJ, Bukur M, et al: Redefining hypotension in traumatic brain injury. Injury 43: 1833, 2012. [PubMed: 21939970]
. Butcher I, Maas AI, Lu J, et al: Prognostic value of admission blood pressure in traumatic brain injury: results from the IMPACT study. J
Neurotrauma 24: 294, 2007. [PubMed: 17375994]
. Sekhon MS, McLean N, Henderson WR, Chittock DR, Griesdale DE: Association of hemoglobin concentration and mortality in critically ill patients with severe traumatic brain injury. Crit Care 16: R128, 2012. [PubMed: 22817913]
. Wright DW, Yeatts SD, Silbergleit R, et al: Very early administration of progesterone for acute traumatic brain injury. N Engl J Med 371: 2457, 2014. [PubMed: 25493974]
. Tasker RC: Intracranial pressure: influence of head­of­bed elevation, and beyond. Pediatr Crit Care Med 13: 116, 2012. [PubMed: 22222657]
Chapter 257: Head Trauma, David W. Wright; Lisa H. Merck 
. Terms of Use * Privacy Policy * Notice * Accessibility
. Coester A, Neumann CR, Schmidt MI: Intensive insulin therapy in severe traumatic brain injury: a randomized trial. J Trauma 68: 904, 2010. [PubMed: 20032790]
. Silbergleit R, Lowenstein D, Durkalski V, Conwit R, Neurological Emergency Treatment Trials (NETT) Investigators: RAMPART (Rapid
Anticonvulsant Medication Prior to Arrival Trial): a double­blind randomized clinical trial of the efficacy of intramuscular midazolam versus intravenous lorazepam in the prehospital treatment of status epilepticus by paramedics. Epilepsia 52(Suppl 8): , 2011. [PubMed: 21967361]
. Edwards P, Arango M, Balica L, et al: Final results of MRC CRASH, a randomised placebo­controlled trial of intravenous corticosteroid in adults with head injury­outcomes at  months. Lancet 365: 1957, 2005. [PubMed: 15936423]
. Smits M, Dippel DW, de Haan GG, et al: Minor head injury: guidelines for the use of CT: a multicenter validation study. Radiology 245: 831, 2007. [PubMed: 17911536]
. Friedman JA, Ebersold MJ, Quast LM: Posttraumatic cerebrospinal fluid leakage. World J Surg 25: 1062, 2001. [PubMed: 11571972]
. King WJ, MacKay M, Sirnick A, Canadian Shaken Baby Study Group: Shaken baby syndrome in Canada: clinical characteristics and outcomes of hospital cases. CMAJ 168: 155, 2003. [PubMed: 12538542]
. Bergsneider M, Hovda DA, Lee SM, et al: Dissociation of cerebral glucose metabolism and level of consciousness during the period of metabolic depression following human traumatic brain injury. J Neurotrauma 17: 389, 2000. [PubMed: 10833058]
. Giza CC, Hovda DA: The neurometabolic cascade of concussion. J Athl Train 36: 228, 2001. [PubMed: 12937489]
. Hovda DA: Oxidative need and oxidative capacity following traumatic brain injury. Crit Care Med 35: 663, 2007. [PubMed: 17251724]
. Bazarian JJ, Zhong J, Blyth B, et al: Diffusion tensor imaging detects clinically important axonal damage after mild traumatic brain injury: a pilot study. J Neurotrauma 24: 1447, 2007. [PubMed: 17892407]
. Bigler ED, Bazarian JJ: Diffusion tensor imaging: a biomarker for mild traumatic brain injury? Neurology 74: 626, 2010. [PubMed: 20107137]
. Rivers E, Nguyen B, Havstad S, et al: Early goal­directed therapy in the treatment of severe sepsis and septic shock. N Engl J Med 345: 1368, 2001. [PubMed: 11794169]
. Sabharwal RK, Sanchetee PC, Sethi PK, Dhamija RM: Chronic traumatic encephalopathy in boxers. J Assoc Physicians India 35: 571, 1987. [PubMed: 3693310]
. Omalu BI, Hamilton RL, Kamboh MI, DeKosky ST, Bailes J: Chronic traumatic encephalopathy (CTE) in a National Football League player: case report and emerging medicolegal practice questions. J Forensic Nurs 6: , 2010. [PubMed: 20201914]
. McKee AC, Stern RA, Nowinski CJ, et al: The spectrum of disease in chronic traumatic encephalopathy. Brain 136: , 2013. [PubMed: 23208308]
. Guskiewicz KM, McCrea M, Marshall SW, et al: Cumulative effects associated with recurrent concussion in collegiate football players: the NCAA
Concussion Study. JAMA 290: 2549, 2003. [PubMed: 14625331]
. Iverson GL, Gaetz M, Lovell MR, Collins MW: Cumulative effects of concussion in amateur athletes. Brain Inj 18: 433, 2004. [PubMed: 15195792]
. Guskiewicz KM, Marshall SW, Bailes J, et al: Association between recurrent concussion and late­life cognitive impairment in retired professional football players. Neurosurgery 57: 719, 2005. [PubMed: 16239884]
. Guskiewicz KM, Marshall SW, Bailes J, et al: Recurrent concussion and risk of depression in retired professional football players. Med Sci Sports
Exerc 39: 903, 2007. [PubMed: 17545878]
. Cantu RC: Second­impact syndrome. Clin Sports Med 17: , 1998. [PubMed: 9475969]
. Echemendia RJ, Meeuwisse W, McCrory P, et al: The Sport Concussion Assessment Tool 5th Edition (SCAT5): background and rationale. Br J
Sports Med 51: 848, 2017. [PubMed: 28446453]
. Mucha A, Collins MW, Elbin RJ, et al: A Brief Vestibular/Ocular Motor Screening (VOMS) assessment to evaluate concussions: preliminary findings.
Am J Sports Med 42: 2479, 2014. [PubMed: 25106780]
. Bazarian JJ, Beck C, Blyth B, von Ahsen N, Hasselblatt M: Impact of creatine kinase correction on the predictive value of S­100B after mild traumatic brain injury. Restor Neurol Neurosci 24: 163, 2006. [PubMed: 16873971]
. Begaz T, Kyriacou, DN, Segal J, Bazarian JJ: Serum biochemical markers for post­concussion syndrome in patients with mild traumatic brain injury. J Neurotrauma 23: 1201, 2006. [PubMed: 16928178]
. Papa L, Silvestri S, Brophy GM, et al: GFAP out­performs S100β in detecting traumatic intracranial lesions on computed tomography in trauma patients with mild traumatic brain injury and those with extracranial lesions. J Neurotrauma 31: 1815, 2014. [PubMed: 24903744]
. Papa L, Brophy GM, Welch RD, et al: Time course and diagnostic accuracy of glial and neuronal blood biomarkers GFAP and UCH­L1 in a large cohort of trauma patients with and without mild traumatic brain injury. JAMA Neurol 73: 551, 2016. [PubMed: 27018834]
. Welch RD, Ayaz SI, Lewis LM, et al: Ability of serum glial fibrillary acidic protein, ubiquitin C­terminal hydrolase­L1, and S100B to differentiate normal and abnormal head computed tomography findings in patients with suspected mild or moderate traumatic brain injury. J Neurotrauma 33:
203, 2016. [PubMed: 26467555]
. Wang KK, Yang Z, Zhu T, et al: An update on diagnostic and prognostic biomarkers for traumatic brain injury. Expert Rev Mol Diagn 18: 165, 2018. [PubMed: 29338452]
. Hanley D, Prichep LS, Bazarian J, et al: Emergency department triage of traumatic head injury using a brain electrical activity biomarker: a multisite prospective observational validation trial. Acad Emerg Med 24: 617, 2017. [PubMed: 28177169]
. Lovell M, Collins M, Bradley J: Return to play following sports­related concussion. Clin Sports Med 23: 421, 2004. [PubMed: 15262380]
. Guskiewicz KM, Bruce SL, Cantu RC, et al: Research based recommendations on management of sport related concussion: summary of the
National Athletic Trainers’ Association position statement. Br J Sports Med 40: , 2006. [PubMed: 16371484]
. Ingersoll CD: Long term effects of closed head injuries in sport. Sports Med 16: 342, 1993. [PubMed: 8272689]
. Mittenberg W, Tremont G, Zielinski RE, Fichera S, Rayls KR: Cognitive­behavioral prevention of postconcussion syndrome. Arch Clin
Neuropsychol 11: 139, 1996. [PubMed: 14588914]
. Butler IJ: Postconcussion syndrome after mild traumatic brain injury in children and adolescents requires further detailed study. JAMA Neurol 70:
636, 2013. [PubMed: 23529540]
. Collins MW, Lovell MR, Iverson GL, et al: Cumulative effects of concussion in high school athletes. Neurosurgery 51: 1175, 2002. [PubMed: 12383362]
. McCrory P, Davis G, Makdissi M: Second impact syndrome or cerebral swelling after sporting head injury. Curr Sports Med Rep 11: , 2012. [PubMed: 22236821]
. Weinstein E, Turner M, Kuzma BB, Feuer H: Second impact syndrome in football: new imaging and insights into a rare and devastating condition. J
Neurosurg Pediatr 11: 331, 2013. [PubMed: 23277914]
. Cohen DB, Rinker C, Wilberger JE: Traumatic brain injury in anticoagulated patients. J Trauma 60: 553, 2006. [PubMed: 16531853]
. Fabbri A, Servadei F, Marchesini G, Stein SC, Vandelli A: Predicting intracranial lesions by antiplatelet agents in subjects with mild head injury. J
Neurol Neurosurg Psychiatry 81: 1275, 2010. [PubMed: 20643657]
. Fabbri A, Servadei F, Marchesini G, et al: Antiplatelet therapy and the outcome of subjects with intracranial injury: the Italian SIMEU study. Crit
Care 17: R53, 2013. [PubMed: 23514619]

