## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 174: Central Nervous System and Spinal Infections
Mary E. Tanski; O. John Ma
CENTRAL NERVOUS SYSTEM INFECTIONS
BACTERIAL MENINGITIS
INTRODUCTION AND EPIDEMIOLOGY

Bacterial meningitis is a life­threatening emergency that affects about .2 millions individuals worldwide each year. The incidence and major
2­4 pathogens vary by region, country, age group, and immunization status. For example, although meningococcal meningitis occurs worldwide in
 epidemic and sporadic form, the highest incidence is in the meningitis belt of sub­Saharan Africa, from Senegal to Ethiopia. In the United States, the most common causes of bacterial meningitis are Streptococcus pneumoniae (58.0%), group B Streptococcus (18.1%), Neisseria meningitidis (13.9%),

Haemophilus influenzae (6.7%), and Listeria monocytogenes (3.4%). Escherichia coli in the neonatal population and Mycobacterium tuberculosis in
 immunocompromised hosts are also important considerations.
PATHOPHYSIOLOGY
Organisms enter the cerebrospinal fluid (CSF) either through hematogenous or direct contiguous spread. In hematogenous spread, bacteria colonize the upper airway and invade the bloodstream, gradually making their way to the subarachnoid space. The subcapsular components of S. pneumoniae,
H. influenzae type b, and N. meningitidis induce an inflammatory cascade, and leukocyte toxins cause cellular swelling and inflammation of the brain
 and meninges. Blood–brain barrier permeability increases, allowing protein and water to enter and leading to vasogenic edema. CSF drainage is inhibited by reduced absorption of the arachnoid granules with resultant obstruction and hydrocephalus, and CSF is forced into the periventricular parenchyma, causing interstitial edema. Disruption of cell membrane homeostasis causes cytotoxic edema. As the brain and meninges rest in a fixedvolume skull, this leads to an elevation in intracranial pressure. Vasculitis decreases cerebral blood flow and can cause ischemia and thrombosis.

Additionally, neurons are directly injured by free radicals from granulocytes and endothelial cells.
In direct contiguous spread, organisms gain entry into the CSF from adjacent infections such as sinusitis, brain abscess, or otitis media. Organisms can also enter directly with penetrating traumatic injury, through congenital defects, or during neurosurgical procedures. In these cases, the organisms and their pathophysiologic effects vary.
Important risk factors for bacterial meningitis are listed in Table 174­1. TABLE 174­1
Important Risk Factors for Bacterial Meningitis
Acute or chronic otitis media
Sinusitis
Immunosuppression/splenectomy
Alcoholism
Pneumonia
Diabetes mellitus
Cerebrospinal fluid leak
Pneumonia

Endocarditis
Chapter 174: Central Nervous System and Spinal Infections, Mary E. Tanski; O. John Ma 
©2025 McGNreauwro sHuirlgl.i cAalll pRroigchetdsu rRee/hseeardv eindju. r y Terms of Use * Privacy Policy * Notice * Accessibility
Indwelling neurosurgical device/cochlear implant
Advanced age
Malignancies
Liver disease
Unvaccinated to Haemophilus influenzae type b, Neisseria meningitidis, or Streptococcus pneumoniae
CLINICAL FEATURES
The presentation of fever, headache, stiff neck, and altered mental status is commonly seen in patients with bacterial meningitis. Most patients have at least two of four of these symptoms, but their absence does not exclude meningitis. Headache is the most common symptom and is seen in more than

85% of patients. Fever is the second most common symptom. Seizures and focal neurologic deficits are seen in 25% to 30% of patients.
HISTORY
Assess historical data in order to elicit risk factors suggestive of certain pathogens. N. meningitidis is associated with close living quarters, such as in military barracks and college dormitories. Unvaccinated patients are at risk for H. influenzae. Consider L. monocytogenes in older adults and
 alcoholics. Penetrating head trauma makes S. pneumoniae more likely. Staphylococcus aureus, coagulase­negative staphylococci, and streptococci are commonly implicated organisms after craniotomy, whereas coagulase­negative staphylococci are commonly seen after ventriculoperitoneal shunt
 and spinal surgery. Immunocompromised patients, such as those with human immunodeficiency virus, on chronic steroids, or with a history of splenectomy, are susceptible to meningitis with encapsulated organisms.
PHYSICAL EXAMINATION
Evaluate for focal neurologic dysfunction such as hemiparesis, visual field deficits, or disordered eye movements. Increased intracranial pressure can cause papilledema or cranial nerve palsy especially involving cranial nerves , , , and . Assess for meningeal irritation with gentle neck flexion and extension, or Brudzinski sign (flexion of hips and knees in response to passive neck flexion) and Kernig sign (contraction of the hamstrings in response
 to knee extension while the hip is flexed). Examine the skin for cutaneous stigmata such as petechiae, splinter hemorrhages, and pustules. Percuss the sinuses and examine the ears for signs of primary infection.
DIAGNOSIS
LUMBAR PUNCTURE
The diagnosis of meningitis is based on CSF results obtained by lumbar puncture (LP). Withhold LP if there is coagulopathy, as evidenced by thrombocytopenia or anticoagulant or antithrombotic use, until coagulopathy is corrected. In general, a platelet count ≤20,000/µL (and some prefer
≤50,000/µL) or INR ≥1.5 is a contraindication to performing an LP on an emergent basis.  The risk of bleeding complications such as epidural hematoma resulting from LP in the presence of anticoagulants, antiplatelet agents, and NSAIDs is not known, and risks and benefits of LP must be
,14  considered in such circumstances. Send CSF for studies including Gram stain and culture, cell count with differential, glucose, and protein.
15­18
Typical CSF findings for bacterial, viral, fungal, and neoplastic meningitides are listed in Table 174­2, but there is considerable overlap.
TABLE 174­2
Cerebrospinal Fluid (CSF) Diagnostic Evaluation of Meningitis and Encephalitis
Opening
Pressure Color Gram Stain Cell Count (<5 WBC, Glucose (>40 Protein (<50 Cytology
(<170 mm (clear) (negative)  PMN) milligrams/dL) milligrams/dL) (negative)
H O)* 
Bacterial Elevated Cloudy, Positive (60%–80% >1000–2000/mm3 WBC, <40 milligrams/dL, >200 Negative turbid before antibiotic, 7%– CSF/blood glucose milligrams/dL neutrophilic
41% after antibiotic) ratio <0.3–0.4 predominance, >80%
PMN
Viral Normal Clear Negative <300/mm3 WBC, Normal <200 Negative or milligrams/dL lymphocytic bloody predominance, <20%
PMN
Fungal Normal to Clear Negative <500/mm3 Normal to slightly >200 Negative elevated or low milligrams/dL cloudy
Neoplastic Normal Clear Negative <300/mm3 Normal to slightly >200 Positive or low milligrams/dL cloudy
*Normal values and findings are in parentheses.
Abbreviation: PMN = polymorphonuclear lymphocyte.
LABORATORY TESTING

Bacterial meningitis is associated with an elevated opening pressure >170 mm H O, and WBCs are elevated greater than 1000/mm with a neutrophilic
 predominance. CSF protein is often elevated above 200 milligrams/dL, and glucose is often decreased below  milligrams/dL or the glucose serum–
15­17 to–CSF ratio is <0.4. Sterilization of the CSF is possible within  hours of initiating parenteral antibiotics in meningococcal and  hours in pneumococcal meningitis,
 highlighting the importance of timely LP. Without antibiotics, Gram stain is positive in 60% to 80% of cases, but in patients treated with antibiotics,
 the Gram stain is positive in 7% to 41%. CSF is positive in 80% to 90% of cases if analysis is performed before antibiotics are initiated, although results are not available during the course of the ED stay. When bacterial meningitis is considered, never withhold empiric antibiotic therapy in
 order to collect the CSF sample.
Rapid latex agglutination tests can be used to detect bacterial antigens and improve bacterial identification. These tests are available for S.
pneumoniae, group B streptococci, H. influenzae, E. coli, and N. meningitidis, but are associated with false­positive and false­negative results and limited sensitivity and specificity. Polymerase chain reaction testing is highly sensitive for organisms such as S. pneumoniae, N. meningitidis,, group B
 streptococci, H. influenzae, L. monocytogenes, and M. tuberculosis but does not provide information on antimicrobial susceptibility. Serum procalcitonin, C­reactive protein, and CSF lactate concentrations have been studied as adjuncts to diagnosis of bacterial meningitis with negative CSF
,21 examinations, but are not a substitute for decision making in the treatment of an individual patient. Recent studies suggest that serum procalcitonin may demonstrate a similar specificity to CSF markers of meningitis while offering a higher sensitivity, making it a useful adjunct for
  diagnosis. If suspicion is great despite negative initial CSF results, admit for empiric antibiotic treatment and consider repeat LP.
CT SCAN BEFORE LUMBAR PUNCTURE
Perform the LP as soon as possible to secure the diagnosis of meningitis. Concern about the complication of cerebral herniation from LP has led to
 controversy in determining which patients require a CT scan of the brain prior to the procedure.
Order a head CT prior to LP in patients with high­risk criteria for herniation (Table 174­3). Although a CT scan can help identify contraindications for an LP, a normal CT scan does not imply that there is no risk of herniation with LP if a patient exhibits clinical predictors of impending herniation such
 as deteriorating mental status, posturing, irregular respirations and pupillary changes, or seizures.
TABLE 174­3
Criteria for Obtaining Head CT Before Lumbar Puncture8,17,23
Altered mental status or deteriorating level of consciousness
Focal neurologic deficit
New­onset seizure
Papilledema
Immunocompromised state
Malignancy
History of focal CNS disease (stroke, focal infection, tumor)
Concern for mass CNS lesion
Age >60 y
TREATMENT
After addressing airway, breathing, and circulation status, immediately initiate empiric antibiotic therapy if bacterial meningitis is clinically suspected.
Never delay administration of empiric antibiotic therapy for neuroimaging or to perform LP, because antibiotic treatment takes
 precedence over definitive diagnosis. Obtain blood cultures to assist in identification of the organism and to help guide inpatient therapy if it will not delay time to antibiotics. Base antibiotic selection on the clinical scenario including age, immunization status, living conditions, and past medical history. See Table 174­4 for general recommendations.
TABLE 174­4
Guidelines for Treatment of Meningitis Based on Patient CharacteristicsB
Patient
Primary Empiric Therapy Presumed Bacteria
Characteristic
Immunocompetent Cefotaxime  grams IV or ceftriaxone  grams IV, plus vancomycin 15–20 milligrams/kg IV S. pneumoniae and N.
If severe penicillin allergy, can replace ceftriaxone with meropenem  grams IV or moxifloxacin 400 meningitidis milligrams IV
Age >50 y Cefotaxime  grams IV or ceftriaxone  grams IV, plus vancomycin 15–20 milligrams/kg IV PLUS L. monocytogenes
Immunocompromised ampicillin  grams IV
If severe penicillin allergy, can replace ampicillin with trimethoprim­sulfamethoxazole 15–20 milligrams/kg/d divided  times daily
EMPIRIC TREATMENT FOR PRESUMPTIVE BACTERIAL MENINGITIS
The empiric antibiotic regimen for adults between  and  years of age is a third­generation cephalosporin, such as cefotaxime  grams IV or ceftriaxone  grams IV, plus vancomycin  to  milligrams/kg IV to achieve serum trough concentrations of  to  micrograms/mL, to cover the common pathogens S. pneumoniae and N. meningitidis.. For adults  years and older or those who may be immunocompromised, add ampicillin 
 grams IV to cover L. monocytogenes. If patients have a severe allergy to penicillin, options include replacing ceftriaxone with meropenem or moxifloxacin and replacing ampicillin with trimethoprim­sulfamethoxazole. Add acyclovir  milligrams/kg IV if herpes simplex virus (HSV) encephalitis
 is suspected. Use a third­ or fourth­generation cephalosporin, such as ceftazidime or cefepime, plus vancomycin for patients who have recently
 ,9 undergone a neurosurgical procedure. Initiate antibiotics as soon as possible in order to increase survival and reduce morbidity.
Administration of dexamethasone to patients with presumptive pneumococcal meningitis before or with the first dose of antibiotics can reduce CSF
,24 inflammation, reduce the risk of morbidity and mortality in adults, and reduce hearing loss and other neurologic sequelae in children. The
 recommended dosage of dexamethasone is  milligrams IV every  hours for  days for adults.
Current guidelines provide no recommendation for the most common ED situation, in which the first dose of empiric antibiotics is given before LP is performed or before results of LP are received. However, delayed initiation of antibiotic treatment in bacterial meningitis patients is associated with
 death or poor clinical outcomes. Common sense suggests that dexamethasone could be administered just before, or concurrently with, empiric antibiotics to patients with strong suspicion for bacterial meningitis or to patients in whom grossly purulent CSF is obtained at the time of LP. One
 expert consensus panel opined that dexamethasone treatment can be administered up to  hours after initiation of antibiotic treatment.
SPECIAL SITUATIONS
BACTERIAL MENINGITIS RESULTING FROM SINUSITIS OR OTITIS
The prevalent use of antibiotics has decreased the frequency of suppurative intracranial complications from sinusitis and otitis, but bacterial meningitis resulting from these diseases still occurs. The virulence of the affecting organism and host factors, such as immunocompromised state, influence spread to the CNS. In the ear, bacteria can spread through endolymphatic channels, bony erosions, or osteothrombophlebitis of small vessels. Thrombophlebitis of veins is a common mechanism by which bacteria disseminate from the sinuses; this may result in cavernous sinus
 thrombosis or empyema. CT imaging is very sensitive for sinusitis and permits earlier diagnosis with demonstration of air­fluid levels in the involved sinuses. CT is nonspecific, however, and should be interpreted with the clinical background in mind (Figure 174­1). Infections are often polymicrobial. Initiate empiric antibiotic therapy with fluoroquinolones, such as levofloxacin or moxifloxacin, or with a third­generation
 cephalosporin, such as ceftriaxone, plus metronidazole.
FIGURE 174­1. Acute sinusitis with opacification of the maxillary sinus. [Reproduced with permission from Brunicardi FC, Andersen D, Billiar T, et al: Schwartz’s
Principles of Surgery, 8th ed. New York, McGraw­Hill, Inc.]
ADDITIONAL ADJUNCTIVE TREATMENT FOR BACTERIAL MENINGITIS
Monitor patients with meningitis closely for complications or signs of clinical deterioration, especially evaluating their respiratory and neurologic
 status. Treat fever, and manage seizures with anticonvulsants. Avoid hypotonic fluids, and monitor serum sodium level serially to detect syndrome of
,24 inappropriate antidiuretic hormone or cerebral salt wasting. Closely evaluate for signs of increased intracranial pressure and vasculopathy that may lead to brain ischemia. If signs of elevated intracranial pressure are detected, elevate the bed to  degrees, use 25% mannitol or hypertonic 3%
 saline for diuresis, and consider a trial of mild hyperventilation. Measurement of intracranial and systemic arterial pressure may be useful in severe
 cases to monitor cerebral perfusion pressure. Consider admission to the intensive care unit to ensure proper level of care.
CHEMOPROPHYLAXIS FOR THOSE EXPOSED TO BACTERIAL MENINGITIS
Bacterial meningitis is spread by droplets, and risk for developing bacterial meningitis after exposure is estimated to be 500 to 800 times higher than
  the general population. Chemoprophylaxis can decrease transmission of N. meningitidis by 89% in close contacts. Chemoprophylaxis is
 recommended for individuals who have been exposed to patients diagnosed with N. meningitidis and H. influenzae. It is not recommended for
 patients diagnosed with pneumococcal meningitis. Close contacts include housemates, individuals exposed to secretions (shared utensils or toothbrushes, kissing, mouth­to­mouth resuscitation), and individuals who intubated the patient without a facemask. To be most effective, initiate chemoprophylaxis within  hours of contact. Risk of infection after a period of  weeks from exposure is considered rare, and prophylaxis is not recommended after this time period. Treatment options for high­risk contacts include rifampin  milligrams/kg to a maximum of 600 milligrams per
 dose every  hours for four doses, ciprofloxacin 500 milligrams orally once, or ceftriaxone 250 milligrams IM once. Instruct all patients who receive chemoprophylaxis to seek medical attention immediately if they develop any symptoms of illness or meningitis.
Admit all patients diagnosed with bacterial meningitis and those highly suspected of having meningitis to the hospital on droplet isolation.
VIRAL MENINGITIS
INTRODUCTION
Viral meningitis typically presents with subacute headache, fever, and findings of meningeal irritation, such as nuchal rigidity. Several viruses can cause viral meningitis, including nonpolio enteroviruses, HSV, varicella­zoster virus, cytomegalovirus, adenovirus, and human immunodeficiency virus. Specific diagnosis depends on isolation of the virus or positive results on immunoassay of the CSF. Nonpolio enteroviruses (echovirus,
 coxsackievirus, and enterovirus) typically are seen in summer through fall and account for more than 90% of all cases of viral meningitis.
LABORATORY TESTING

Viral meningitis is associated with normal opening pressures and a negative Gram stain (Table 174­2). WBCs are <300/mm with a lymphocytic
 predominance, and usually less than 20% polymorphonuclear lymphocytes. Protein is often slightly elevated, but not typically above 200 milligrams/dL, and CSF glucose is normal. The percentage of polymorphonuclear cells may be higher in early viral meningitis, and in some cases,
 glucose levels may be decreased. Consider partially treated bacterial meningitis if a patient with symptoms consistent with meningitis had previously been treated with antibiotics and the LP suggests aseptic meningitis. Viral culture is insensitive, so if a viral etiology is suspected, send for molecular
 testing by polymerase chain reaction from the CSF. Polymerase chain reaction testing is available for HSV, enterovirus, and other viral organisms.
DISPOSITION AND FOLLOW­UP
There can be overlap of CSF findings with early bacterial meningitis and partially treated bacterial meningitis, making the specific diagnosis for some cases of viral meningitis difficult in the ED. Although supportive care is the mainstay of treatment for viral meningitis, it is appropriate to admit the toxic­appearing patient to the hospital for empiric antibiotic therapy until culture results return in situations of diagnostic uncertainty. HSV­2
 meningitis can cause necrotizing encephalitis and neurologic deficits. Admit patients with diagnosed or suspected HSV­2 meningitis after beginning
 treatment with acyclovir  milligrams/kg IV every  hours.
FUNGAL CNS INFECTIONS
Over the past  years, the incidence of fungal CNS infections has been increasing, likely due to acquired immunodeficiency syndrome as well as an
 increase in patients on immunosuppressants due to stem cell and organ transplants. The most common cause of fungal meningitis is Cryptococcus
,28 neoformans, followed by Coccidioides immitis, which can be seen in immunocompetent hosts as well as the immunocompromised. Aspergillus and
Candida are most often discovered in immunocompromised hosts. Mucormycoses can be seen especially in diabetics from direct extension of sinus infection.
LABORATORY TESTING
The CSF analysis of fungal meningitis shows lymphocytic predominance, an elevated opening pressure, low glucose, and slightly increased protein
,29
(Table 174­2). Significant elevations in opening pressure are often seen in cryptococcal meningitis. Gram stain is negative, and WBC is usually

<500/mm . Consider fungal testing especially for immunocompromised patients in whom fungal etiologies are suspected, including India ink staining
 and serum cryptococcal antigen testing, cytology, and histopathology. Send CSF for Borrelia antibodies in patients with suspected Lyme disease and for acid­fast stain and culture for suspected mycobacteria in tuberculous meningitis.
Patients often have a prolonged symptom course. Use fungal stain and culture for diagnosis if a fungal etiology is suspected, and look for elevated opening pressure during LP. Consider CT or MRI to search for intracranial complications such as granulomas or abscesses.
TREATMENT
Treatment for fungal infections is dependent on diagnosis through LP. Liposomal amphotericin B is the agent of choice in cryptococcal meningitis. Use
 fluconazole or itraconazole for C. immitis. Treat Candida meningitis with liposomal amphotericin B often combined with flucytosine.
VIRAL ENCEPHALITIS

Viral CNS infections can also cause viral encephalitis, which is an infection and inflammation of the brain parenchyma. Viral encephalitis is clinically distinguished from viral meningitis with presence of neurologic findings such as altered level of consciousness, focal weakness, or seizures, although the two often coexist.

The causes of viral encephalitis vary year to year and across geographical locations, with an incidence of .5 to .5 per 100,000 people. Immune status, exposure to insects or animals, and travel history play a key role in determining the etiology. An underlying cause, however, is found in only
  about a third of cases. HSV accounts for 40% to 50% of cases where a cause is determined. HSV­1 is responsible for most cases of HSV encephalitis;

HSV­2 frequently causes aseptic meningitis but is not usually associated with development of encephalitis. Other viral pathologic agents in North
America include Epstein­Barr virus, cytomegalovirus, and rabies. Common arboviral encephalitides include La Crosse encephalitis, St. Louis equine encephalitis, Western equine encephalitis, and West Nile virus.
PATHOPHYSIOLOGY
Immunocompromised patients such as those with organ or stem cell transplants are susceptible to new or reactivated infections with HSV and varicella­zoster virus. Impaired immune status also plays a role in cytomegalovirus encephalitis. The arboviruses are transmitted by mosquitoes and
 ticks. Rabies is transferred by the bite of an infected animal and leads to severe encephalitis and a very high mortality rate. Common to all is preliminary viral invasion of the host at a site where replication takes place that is outside the CNS. Most viruses then reach the nervous system hematogenously during viremia. However, at least three important viruses—rabies, HSV, and herpes zoster virus—reach the spinal cord and eventually the brain by traveling backward within axons from a distal site, where they gain access to nerve endings. Once in the brain, disruption of neural cell functions by the virus and by the effects of the host’s inflammatory responses ensues. Gray matter is predominantly affected, resulting in cognitive and psychiatric signs, lethargy, and seizures.
CLINICAL FEATURES

Consider encephalitis in patients exhibiting behavioral changes, new psychiatric symptoms, cognitive deficits, or seizures. The triad of headache, fever, and altered mental status may be seen but is not invariably present. Rash or skin vesicles suggest herpes zoster, and skin vesicle culture may be useful for diagnosis. Lymphadenopathy or splenomegaly points to Epstein­Barr virus, which can be picked up on serologic testing. New onset of psychiatric symptoms and behavioral changes may be attributable to HSV. MRI, electroencephalogram, and polymerase chain reaction of the CSR could assist in making the diagnosis.
PHYSICAL EXAMINATION
Examine for signs of meningeal irritation and increased intracranial pressure and for neurologic findings that reflect the areas of involvement.
Carefully assess mental status and cognition. Encephalitis may show regional tropism. HSV involves limbic structures of the temporal and frontal lobes with prominent psychiatric features, memory disturbance, and aphasia. Some arboviruses predominantly affect the basal ganglia, causing choreoathetosis and parkinsonian movements. Involvement of the brainstem nuclei that control swallowing leads to the hydrophobic choking
 response characteristic of rabies encephalitis.
DIAGNOSIS
Neuroimaging studies such as MRI or CT and electroencephalography are important in ruling out mass occupying lesions and making the diagnosis of encephalitis. MRI is more sensitive than CT. Obtain an MRI to help exclude lesions such as brain abscesses, and examine for findings suggestive of HSV encephalitis, such as involvement of the gray matter in the medial temporal and inferior frontal lobes (Figure 174­2). Electroencephalogram findings are generally nonspecific but can be useful in cases such as HSV encephalitis where an almost pathognomonic picture of periodic, asymmetric sharp
 waves is seen in the setting of acute febrile encephalopathy. LP is the most useful diagnostic procedure in the ED, and CSF should be sent for Gram stain and culture, cell count with differential, glucose, and protein. Viral polymerase chain reaction can be helpful in detecting viral pathogens and has
,32 a 95% sensitivity and specificity for HSV. CSF findings are similar to those in viral meningitis, with a lymphocytic pleocytosis, modestly elevated
 protein, and normal glucose.
FIGURE 174­2. Fluid­attenuated inversion recovery hyperintensity in the left temporal lobe and left insula (arrow) suggests the diagnosis of herpes encephalitis.
[Photo contributed by Elizabeth Yutan, Department of Radiology, Oregon Health & Science University.]
Consider bacterial meningitis in the differential diagnosis when fever and meningeal symptoms predominate. A late­summer encephalopathy suggests the possibility of arbovirus encephalitis, and an animal bite for which no antirabies treatment was administered has relevance for rabies. Suspect subarachnoid hemorrhage with acute onset of severe headache as the presenting sign. Lyme disease, tuberculosis, and fungal and neoplastic meningitis are in the differential diagnosis in less fulminant cases. If focal neurologic signs are present, consider brain abscess, empyema, or cavernous sinus thrombosis as possible causes.
TREATMENT
,30
The antiviral of choice for HSV encephalitis is high­dose acyclovir at  milligrams/kg per dose IV every  hours. Initiate treatment as soon as possible because the prognosis of HSV encephalitis is correlated with neurologic condition at the time antivirals are initiated. Treat varicella­zoster virus with acyclovir,  to  milligrams/kg per dose IV every  hours. Patients with herpes zoster virus encephalitis may also benefit from acyclovir
 therapy. Treat patients with cytomegalovirus encephalitis with ganciclovir,  milligrams/kg per dose IV every  hours. There are no known
 treatments for arbovirus encephalitis; consider initiating treatment with acyclovir empirically until a CSF diagnosis is made. Rabies encephalitis is rare but neurologically devastating, and once symptomatic, it is usually fatal.
DISPOSITION AND FOLLOW­UP
Prognosis of viral encephalitides depends on the causative virus and host factors. Older adults and those who are immunocompromised are more likely to have an adverse outcome. Admit patients with encephalitis to the hospital. Patients may require intensive care unit care if they have signs of altered mental status or coma.
BRAIN ABSCESS
INTRODUCTION
A brain abscess begins as a focal area of cerebritis, which develops into a central pus­filled cavity ringed by a layer of granulation tissue and an outer
 fibrous capsule in a period of about  days. It is surrounded by edematous brain tissue infiltrated with inflammatory cells. A brain abscess is a pathologic response typical of a relatively competent immune system against a bacterial invader. Focal brain infections from other organisms, such as granulomas due to tuberculosis, necrotic lesions of toxoplasmosis in immunocompromised patients, or cystic lesions of cysticercosis, are not abscesses in the pathologic sense.
PATHOPHYSIOLOGY
Organisms reach the brain hematogenously, from direct contiguous infection, or by direct seeding by neurosurgery or penetrating trauma.
Hematogenous spread accounts for 15% to 30% of cases, direct spread from infection accounts for 25% to 50%, and trauma or surgery for 8% to 20%,
,34 while the route is unknown in 15% to 20% of cases. Direct spread usually results in an isolated brain abscess, whereas hematogenous seeding results in multiple abscesses.
Investigate for the source of the brain abscess in order to determine the likely bacterial etiology and to treat the source itself. Otogenic brain abscesses are often caused by gram­negative rods and are located adjacent to the temporal lobe or cerebellum. Sinogenic or odontogenic abscesses are often caused by anaerobic and microaerophilic streptococci and are commonly located in the frontal lobes. Abscesses formed from hematogenous spread are usually polymicrobial, with anaerobic and microaerophilic streptococci commonly represented. Direct implantation or traumatic injuries yield
 staphylococci, with gram­negative rods also seen in cases related to neurologic surgery.
CLINICAL FEATURES
HISTORY
Presenting features of brain abscess are nonspecific, and patients generally appear nontoxic. Headache is the most common feature, with fever as a close second. Although most patients present with one or more findings of headache, fever, altered mental status, focal neurologic symptoms,
,34 seizures, or balance changes, the classic triad of headache, fever, and focal neurologic deficit is present in <25% of all patients. The nonspecific
 presentation contributes to both severity and outcome of brain abscesses because diagnosis and treatment are often delayed. Symptoms reflect the
 infectious and neurologic (focal and mass effect producing) aspects of the disease and are often present for  to  weeks. The presentation may be
 dominated by the origin of the infection (e.g., ear or sinus pain). Seizure occurs in 25% to 34% of patients.
PHYSICAL EXAMINATION
,37
Examine for focal neurologic signs that demonstrate the site of the lesion. Focal signs are present in approximately 60% of patients. Assess for potential sites of origin, which may raise suspicion of brain abscess when the presentation is otherwise nonspecific in a patient with subacute headache and lethargy.
DIAGNOSIS
Neuroimaging is essential to the diagnosis of brain abscess and is one instance where a contrast­enhanced head CT scan is preferred over a noncontrast study in the ED. A noncontrast CT scan may only show a hypodense low­attenuation abnormality with mass effect, but later in the course,
 may show a peripheral ring. A head CT with IV contrast shows one or several thin, smooth rings of enhancement surrounding a low­density central area and surrounded by edema (Figure 174­3). MRI usually demonstrates a ring whether or not gadolinium enhancement is used. Both CT and MRI are highly sensitive; CT is often more readily available in the ED. Avoid LP if clinical suspicion is high or focal neurologic deficits are present to prevent potential herniation in the case of increased intracranial pressure. If possible, obtain cultures of blood and other sites of infection to guide future management.
FIGURE 174­3. Ring­enhancing brain abscess with surrounding edema (arrow). [Photo contributed by David Peterson, Department of Radiology, Oregon Health &
Science University.]
The differential diagnosis is broad because of the nonspecific symptoms of brain abscess. A sudden onset with focal features may suggest cerebrovascular disease. Prominent fever, stiff neck, and altered mental status may suggest meningitis or encephalitis. A protracted course with features of increased intracranial pressure may suggest neoplasm. Brain neoplasm, subacute brain hemorrhage, and other focal brain infections, such as toxoplasmosis, may mimic the imaging findings of brain abscess.
TREATMENT
Early combination empiric antibiotic therapy is important (Table 174­5). A multidisciplinary approach with neurosurgery and infectious disease consultations will help guide treatment selection. Aminoglycosides, macrolides, and first­generation cephalosporins are not effective treatment for brain abscess. Treatment with steroids is controversial.
TABLE 174­5
Guidelines for Empiric Treatment of Brain Abscess Based on Presumed Source
Presumed
Primary Empiric Therapy Alternative Therapy
Source
Otogenic Cefotaxime  grams IV every 4–6 h or ceftriaxone  grams IV Piperacillin/tazobactam .5 grams IV every  h every  h PLUS metronidazole 500 milligrams IV every  h
Odontogenic Penicillin G  million units IV every  h Ceftriaxone  grams IV every  h PLUS metronidazole 500 milligrams IV every  h
Sinogenic Cefotaxime  grams IV every  h or ceftriaxone  grams IV No recommendation every  h PLUS metronidazole 500 milligrams IV every  h
Penetrating Cefotaxime  grams IV every  h or ceftriaxone  grams IV No recommendation trauma every  h PLUS metronidazole 500 milligrams IV every  h
± rifampin  milligrams/kg every  h
After Vancomycin loading dose 25–30 milligrams/kg IV loading Can substitute linezolid 600 milligrams IV every  h instead of neurosurgical dose or linezolid 600 milligrams IV every  h PLUS vancomycin. Can substitute meropenem  grams IV every  h OR procedure ceftazidime  grams IV every  h ± rifampin  piperacillin/tazobactam .5 grams IV every  h OR cefepime  grams IV milligrams/kg every  h every  h for ceftazidime.
Unknown Cefotaxime  grams IV every  h PLUS metronidazole 500 No recommendation source milligrams IV every  h
Note: See also http://www.hopkins­abxguide.org.
DISPOSITION AND FOLLOW­UP
Neurosurgery involvement is paramount in treatment and management decisions. Patients with small abscesses <2.5 cm, with a Glasgow coma score

>12, and who have an etiology that is known may be treated with IV antibiotics alone. Aspiration may be done by the neurosurgical team to elucidate the causative organism. Total excision is less necessary with improved imaging, although it is performed in the setting of increased intracranial
 pressure or after failed medical management or aspiration.
SPINAL INFECTIONS
EPIDURAL ABSCESS
INTRODUCTION AND EPIDEMIOLOGY
Spinal epidural abscess is a collection of pyogenic material that accumulates in the epidural space between the dura and vertebral periosteum and
,40 often leads to devastating neurologic outcomes. The incidence of spinal epidural abscess has doubled in the past two decades, largely attributed to factors such as an increasing proportion of immunocompromised patients, more prevalent IV drug use, an increasing number of spinal procedures,
,42  and improved imaging modalities for detection. Despite improvement in diagnosis and treatment, mortality remains high at 2% to 20%. S. aureus is the most commonly involved bacteria and is responsible for 70% of cases, with a higher proportion of methicillin­resistant S. aureus seen in patients
,42 with implantable devices. Other pathogens include Staphylococcus epidermidis, streptococcal species, and gram­negative bacilli, which is especially prevalent in IV drug users. Mycobacteria and fungi causing spinal epidural abscess are rare. Tuberculosis spinal epidural abscess, also
 known as Pott’s disease, is seen in areas where tuberculosis remains endemic and in the immunocompromised population.
PATHOPHYSIOLOGY
Spinal epidural abscess can arise from hematogenous spread through blood circulation with soft tissue, urine, and respiratory infections contributing
 in the majority of cases. In general, hematogenously spread epidural abscesses are more likely to be found in the posterior epidural space. Less commonly, spinal epidural abscesses are caused by direct extension from infected adjacent tissue, such as vertebral spondylodiscitis or vertebral osteomyelitis, which occurs when areas of slow blood flow in the vertebral body end plates are occluded by venous or arterial septic emboli, causing
 ,45 osteonecrosis. Direct extension typically infects the anterior portion of the spinal column. Fifteen to 22% of spinal epidural abscesses are caused
 iatrogenically from neurosurgical procedures, including percutaneous diagnostic and therapeutic techniques. Trauma contributes to a small
,42 proportion of spinal epidural abscesses, with the remainder of cases without an identifiable source.
Most spinal epidural abscesses affect the thoracic and lumbar spine, where the epidural space is wider with a larger venous plexus. The cervical spine
 is affected only 5% to 20% of the time, although morbidity and neurologic devastation are much greater than in thoracic or lumbar locations.
Mechanisms for spinal cord neurologic sequelae are uncertain and are thought to be from a combination of direct compression from the abscess
 itself, ischemia due to compression of spinal veins and arteries, and septic thrombophlebitis.
CLINICAL FEATURES
Back pain is the most common presenting complaint and is seen in the majority of cases. Fever is another common symptom, followed by the presence
,42 of a neurologic deficit. However, the classic triad of back pain, fever, and neurologic symptoms is seen in a minority of patients (8% to 37%).
Typically, patients with spinal epidural abscess progress through four stages in a period ranging from hours to days. Stage  consists of back pain, fever, and localized spinal tenderness. Stage  is composed of spinal irritation, including radicular pain, hyperreflexia, and nuchal rigidity. Stage  involves the bowel and bladder, with symptoms of fecal or urinary incontinence, as well as focal neurologic deficits such as motor weakness. Finally, in
,42  stage , paralysis ensues. Patients with tuberculosis as an etiology may also endorse night sweats and weight loss.
HISTORY
Screen any patient presenting with back pain, fever, or neurologic complaint for spinal epidural abscess. Patients may have a history of chronic back pain or may offer a mechanism of mild trauma, which can distract from a diagnosis of spinal epidural abscess. Similarly, neck pain or stiffness is often thought to be meningitis or encephalitis, causing cervical spinal epidural abscess to be overlooked.
Carefully search for back pain red flags in the patient’s history, including immunocompromised states and immunosuppressant medications. Elicit a history of recent systemic illness or infection. Inquire about travel and history of tuberculosis. Ask about any current or former IV drug use, which can make patients higher risk for spinal epidural abscess development from Pseudomonas species. Solicit information about prior spinal surgeries or procedures, including LPs, epidurals, spinal injections, or epidural anesthesia. Ask about any changes in bowel or bladder habits, specifically episodes
,48 of bladder fullness or urinary or fecal incontinence.
PHYSICAL EXAMINATION
Perform a thorough physical examination starting with a general assessment of sources of infection. Palpate the spine, searching for tenderness to palpation, especially in the midline, which may suggest spinal epidural abscess. Complete a full neurologic examination, including sensory dermatome testing and motor evaluation including ambulation. Check reflexes for hyper­ or areflexia. Evaluate for symptoms of cauda equina syndrome. Perform a rectal examination looking for decreased rectal tone, which has a sensitivity of 60% to 80%, and an evaluation of perianal sensation for saddle
 anesthesia, which has a sensitivity of 75%.
DIAGNOSIS
Diagnosis is delayed in many patients with spinal epidural abscess due to nonspecific presenting symptoms and the rarity of diagnosis. Send blood for laboratory studies including blood culture, CBC, erythrocyte sedimentation rate, and C­reactive protein. Leukocytosis is seen in only 60% to 78% of
 patients and is not sensitive or specific enough for a diagnosis of spinal epidural abscess. Erythrocyte sedimentation rate is much more sensitive and,
 in one study, was elevated in 110 of 117 patients diagnosed with spinal epidural abscess. C­reactive protein has the advantage of rising faster than erythrocyte sedimentation rate and returns to normal sooner as well, but some labs have a delay in resulting C­reactive protein. Do not withhold
 further diagnostics and treatment pending C­reactive protein. Blood cultures are positive in up to 60% of cases and may be helpful for inpatient
 teams. Do not perform LP if there is suspicion for spinal abscess. CSF culture is positive less than a quarter of the time, and LP poses the risk of
 traversing an abscess and causing meningitis or a subdural infection.
MRI with gadolinium is the gold standard imaging study for the diagnosis of spinal epidural abscess and has a sensitivity and specificity greater than

90%. If MRI is not available, consider emergent transfer to an appropriate referral center. In patients with contraindications to MRI, CT with
 myelography can be useful to localize epidural compression but is limited in its ability to distinguish abscess from other compressive lesions. Plain
 radiographs are not sensitive or specific for diagnosis of spinal epidural abscess.
TREATMENT
Once diagnosis has been established, prompt treatment is essential to reduce morbidity and enhance survival. Immediate consultation with a spine
 surgeon is paramount, and if a spine surgeon is not available, transfer to a referral center. Neurologic outcome is correlated with degree of neurologic deficit prior to treatment.
There are no conclusive data regarding surgery versus conservative antibiotic therapy, and practices vary considerably from immediate operative
 therapy to conservative IV antibiotic therapy. Patients with neurologic deficits usually require evacuation of the abscess with decompressive
 laminectomy, debridement, and long­term IV antibiotics, and some studies have shown improved outcomes with emergent surgery. Patients who are neurologically intact or who have had neurologic deficits for >72 hours may be candidates for conservative treatment or CT­guided aspiration depending on the spinal surgeon’s practice, with the understanding that if they develop neurologic deficits or decompensate, immediate surgical
 therapy is likely required.
Start empiric antibiotic therapy if there will be an unavoidable delay for surgery or if the patient exhibits neurologic dysfunction or signs of sepsis.
Appropriate empiric antibiotics can include a combination of vancomycin,  to  milligrams/kg IV loading dose, to cover methicillin­resistant S.
aureus along with an antipseudomonal β­lactam such as ceftazidime,  grams IV every  hours, cefepime,  grams IV every  hours, or meropenem, 
,50 grams IV every  hours. Once cultures return, an infectious disease consult may be helpful to determine long­term antibiotic choice and duration.
Admit patients diagnosed with spinal epidural abscess for spinal surgery. If the patient will receive conservative therapy, admit to the intensive care unit for close monitoring, neurologic checks, and further management in conjunction with the spinal surgery team.


