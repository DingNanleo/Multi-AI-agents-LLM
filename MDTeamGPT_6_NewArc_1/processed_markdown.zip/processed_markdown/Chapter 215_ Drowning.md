## Page 1

University of Pittsburgh
Access Provided by:
Tintinalli's Emergency Medicine: A Comprehensive Study Guide, 9e
Chapter 215: Drowning
Stephen John Cico; Linda Quan
INTRODUCTION AND EPIDEMIOLOGY

Drowning is submersion in a liquid medium resulting in respiratory difficulty or arrest. As with other causes of accidental death, drowning injury typically involves otherwise healthy, young individuals, but can involve individuals of any age or background.

Worldwide, drowning accounts for >370,000 deaths annually and is the leading cause of injury death among children <15 years of age. In the United
States, there are >500,000 drowning events each year and 1100 deaths, which makes drowning the second leading cause of unintentional death of
,3 individuals from birth to age  years old. Although the rate of drowning deaths has decreased over the past  years, it remains high in low­ and
 middle­income countries, which account for 91% of unintentional drowning deaths worldwide annually. The vast majority of victims survive submersion events, with effects ranging from minimal or transient injury to profound neurologic insult.
,3 ,3
Drowning incidence peaks in three age groups: The highest is in children <5 years old, the second peak is in those aged  to  years, and the
 third peak is in the elderly. Toddlers drown primarily after falling into swimming pools or open water, but they also drown in bathtubs and buckets in the home. Physicians also need to evaluate for intentional drowning (child abuse) or factitious disorder by proxy (formerly Munchausen’s by proxy). In teenagers and adults, suicide, homicide, and domestic violence can be causes of drowning. In this age group, drowning is also more likely if alcohol or
 drugs are involved. The elderly also have an increased risk of bathtub drowning, often related to comorbid medical conditions or medications. Even in coastal areas, most drownings take place in warm, freshwater bodies of water, especially swimming pools.
Additional injuries or disorders that either precipitate or are associated with drowning events are shown in Table 215­1. TABLE 215­1
Disorders and Injuries Associated With Drowning
Disorders Associated With Drowning
Alcohol or other intoxicants
Syncope (e.g., due to hyperventilation prior to underwater diving)
Seizures
Cardiac conditions (e.g., dysrhythmias including prolonged QT syndromes, Brugada’s syndrome, ischemic heart disease)
Dementia
Intentional (suicide, homicide, child abuse or neglect in young children)
Injuries Associated With Drowning
Spinal cord injuries due to diving into shallow water, significant falls from heights, or boating/personal watercraft mishaps
Hypothermia
Aspiration
Respiratory failure, insufficiency, or distress
PATHOPHYSIOLOGY

ACfhtearp steurb m21e5r:s iDorno, wthnein dge,g Sreteep ohfe hny pJooxhinc iCniscuol;t Ltoin tdhae QCNuSa ndetermines the ultimate outcome. It was previously thought that parasympathetic Pacatgivea 1ti o/ 7n o©f2 t0h2e5 d MivcinGgra rwe fHleilxl. (Ai.lel .R, bigrhadtsy Rcaersdeiarv, eapdn. e aT,e prmersip ohfe Urasle v * a sPorcivoancsyt rPicotiliocny, * a nNdo tciceen t * r aAl cscheusnstiinbgili toyf blood flow) provided transient protection during submersion. However, in most cases, the diving reflex is overwhelmed by the stimulation of the sympathetic nervous system, yielding no meaningful
 protection. Cerebral protection in cold water submersions most likely results from rapid CNS cooling before significant hypoxic damage occurs.
,7
Physiologic scoring systems to predict drowning outcome have been devised but are not clinically helpful. The vast majority of patients who arrive at the hospital with stable cardiovascular signs and awake, alert neurologic function survive with minimal disability, whereas those who arrive with unstable cardiovascular function and coma do poorly because of the hypoxic­ischemic insult. Predictors are not accurate for the 15% to 20% of drowning victims whose condition on arrival is between these two extremes. However, patients who had a low Glasgow Coma Scale score upon arrival to the ED (average of .2 for nonsurvivors vs. .6 for survivors), who required CPR, who were intubated, or for whom presser support was initiated all
 had a lower survival than those who did not have or require any of these.
End organs can also be affected by hypoxemia and metabolic acidosis. Aspiration of substances such as contaminated foreign material, particulate matter, bacteria, vomitus, or chemical irritants can affect eventual pulmonary recovery. Electrolyte abnormalities are seldom significant and
,9 are usually transient unless there is significant hypoxia, CNS depression, renal injury from hemoglobinuria, or myoglobinuria.
Hematologic values are usually normal unless there has been massive hemolysis. Disseminated intravascular coagulation can be a complicating factor in drowning outcome but usually occurs following severe hypoxic insult.
TREATMENT
PREHOSPITAL CARE
Rapid resuscitation of a drowning victim (quickly restoring ventilation and oxygenation) optimizes outcome. After safe removal of the victim from the water, CPR should be initiated as quickly as possible. Trauma as a cause of drowning is uncommon, and most injured drowning patients have a history
 of trauma or signs of injury on examination. Cervical spine injury is rare (0.5%) in drowning unless there is a history of diving, falling from a
 significant height, or motorized vehicle crash. Use cervical spine precautions if the history warrants it.
Administer high­flow oxygen by facemask if the patient is breathing or by positive­pressure bag­valve­mask ventilation if the patient is not breathing.
For patients who do not recover spontaneous respiratory effort, endotracheal intubation and positive­pressure ventilation are necessary.
All patients with amnesia for the drowning event, loss of or depressed consciousness, or an observed period of apnea, as well as those who require a period of artificial ventilation, should be transported to an ED for evaluation, even if they are asymptomatic at the scene. The patient should be warmed and monitored, and IV access should be established (Figure 215­1).
FIGURE 215­1. Drowning event algorithm. CBC = complete blood count; CK = creatine kinase; CPAP = continuous positive airway pressure; CVP = central venous pressure; CXR = chest radiograph; GCS = Glasgow Coma Scale score; ICU = intensive care unit; PEEP = positive end­expiratory pressure; PT = prothrombin time; PTT = partial thromboplastin time; SaO = oxygen saturation (via pulse oximetry); U/A = urinalysis.

PRIMARY ED TREATMENT
Upon the patient’s arrival at the ED, assess and secure the airway, provide oxygen, determine core temperature, and assist ventilation as necessary. If the patient is hypothermic, administer warmed isotonic IV fluids and apply warming adjuncts (e.g., blankets, overhead warmers, warming devices). Address any associated injuries. Because cervical injury is rare without a history of diving or associated trauma, routine
 cervical immobilization and CT of the brain are not necessary.
Patients who present to the ED with a Glasgow Coma Scale score of >13 and an oxygen saturation of ≥95% are at low risk for complications (Figure 215­1) and should be observed for  to  hours. If the pulmonary examination does not reveal rales, rhonchi, wheezing, or retractions and arterial oxygen saturation on room air remains ≥95%, the patient can be safely discharged home. Laboratory studies and radiographs
,12 are unnecessary and are not predictive of discharge. The patient should be told to return if fever, mental status changes, or pulmonary symptoms occur. If, after  to  hours, the patient develops an oxygen requirement, the findings on pulmonary examination are abnormal (rales, rhonchi, wheeze,
,12 retractions, etc.), or the patient’s condition deteriorates, reassessment and admission or transfer to a monitored bed are needed.
Patients who present to the ED with a Glasgow Coma Scale score of <13 should be maintained on supplemental oxygen and ventilatory support as needed. If high­flow oxygen (fraction of inspired oxygen of 40% to 60%) cannot maintain an adequate partial pressure of arterial oxygen (>60 mm Hg in adults, >80 mm Hg in children), then intubate the patient and provide positive­pressure ventilation. Chest radiography and laboratory studies should be done to evaluate for pulmonary aspiration and other complications (Figure 215­1). Although aspiration is common,
 prophylactic antibiotics have not been shown to improve outcome and may be associated with resistant infections. Continuous cardiac monitoring, pulse oximetry, temperature monitoring, and frequent reassessments should be performed for all patients. Hypothermia is a concern in patients who have been submerged in cold water (see Chapter 209, “Hypothermia”).
If the patient is normothermic upon arrival in the ED and in cardiopulmonary arrest or asystole, serious thought should be given to
,15 discontinuing resuscitation efforts because recovery without profound neurologic complications is rare.
SECONDARY TREATMENT

Hospital management of drowning victims is largely supportive. All drowning victims who require ED resuscitation should be admitted to an intensive care unit for continuous cardiopulmonary and frequent neurologic monitoring. Most victims of significant submersion injury benefit from mechanical ventilation. Supernormal levels of positive end­expiratory pressure may be used to recruit fluid­filled lung units and aid oxygenation. Most patients demonstrate rapid improvement in oxygenation in the first  hours. Patients presenting with a significant aspiration pattern or cardiovascular collapse are predisposed to develop acute respiratory distress syndrome. Although prophylactic antibiotics lack supporting evidence, delayed pulmonary infection, particularly among patients requiring mechanical ventilation, is a risk, and unusual organisms, including Aeromonas species, should be considered if treatment is initiated. Care should be taken to avoid lung overdistention and ventilator­associated barotrauma.
For patients who have been resuscitated from cardiac arrest, the hemodynamic response to exogenously administered epinephrine is frequently short lived, and most require a continuous infusion of dopamine or epinephrine in the ED or intensive care unit. Invasive (pulmonary artery catheter) or noninvasive (echocardiogram) measurement of ventricular function is often instructive. Hemodynamic recovery, when it occurs, can be expected within  hours. Patients demonstrating no hemodynamic recovery after  hours may slowly improve over the first week but are more likely to have
 long­term neurologic damage.
,16
Results of “brain resuscitation” after significant warm water drowning have been disappointing. The degree of cerebral edema is largely determined by the duration of the anoxic or ischemic insult at the time of submersion. Efforts to control cerebral edema, including the use of mannitol,
 loop diuretics, hypertonic saline, fluid restriction, and mechanical hyperventilation, have not shown benefit. Controlled hypothermia, barbiturate

“coma,” and intracranial pressure monitoring do not improve outcome in pediatric drowning victims. Although rare, complete or near­complete neurologic recovery after asystole has been reported in both children and adults after icy water submersion episodes.
PROGNOSIS, DISPOSITION, AND FOLLOW­UP
Family members should be counseled about likely outcome. Based on initial presentation, resuscitation, laboratory data, and serial examinations,
 experienced practitioners should be able to provide accurate predictions of outcomes in most cases. There are no standardized terms for describing
 drowning incidents. This chapter uses the terms asymptomatic and symptomaticdrowning.
ASYMPTOMATIC DROWNING
Drowning victims who are asymptomatic or mildly symptomatic can be observed for  to  hours. If the findings of pulmonary examination and oxygen saturation on room air remain normal, patients can be discharged home. If deterioration is going to occur, it will do so within the 4­ to 6­hour
,19­21 observation period. No data are available regarding long­term outcomes, but it is unlikely that there are any measurable adverse effects.
Patients and/or parents should be advised to seek medical care for any respiratory complaints or fever.
SYMPTOMATIC DROWNING
Because submersion duration is frequently unknown or only estimated, the extent of required resuscitation is often the most objective measure of the degree of anoxic or ischemic insult (Table 215­2). Details of initial presentation and resuscitation are frequently strong prognostic indicators.
TABLE 215­2
Factors Associated With Poor Resuscitation Prognosis in Near­Drowning
Need for bystander CPR at scene
CPR in the ED
Asystole at scene or in ED after warming
For patients who require hospital admission, if the submersion victim does not require cardiopulmonary resuscitation at the scene or in the ED, complete recovery within  hours is expected. A small fraction of patients with significant aspiration may develop severe, even life­threatening acute respiratory distress syndrome.
Victims requiring bystander CPR at the scene have a guarded prognosis. Of scene­resuscitated pediatric victims, about 20% later die in the
,22 hospital, and about 5% are left with severe hypoxic­ischemic encephalopathy. Those victims who demonstrate continuous neurologic and cardiovascular improvement after hospital admission generally make a good recovery. Frequently, neurologic and cardiovascular examinations are normal within  hours of the drowning event. Victims who later die in the hospital usually demonstrate deteriorating cardiovascular and neurologic status.
Victims undergoing CPR in the ED have a poor prognosis. Prolonged (>30 minutes) CPR in drowning victims indicates significant anoxic or ischemic insult to the heart, brain, and other vital organs. Complete neurologic recovery is rare, with only anecdotal reports of neurologic recovery after ED CPR of pediatric drowning victims. Asystole, whether noted at the scene or in the ED, is a near­universal sign of poor prognosis in both adult
,23 and pediatric drowning injury.
,22
For the emergency physician, the answers to the questions of whom and how vigorously to resuscitate remain challenging. Complete or nearcomplete neurologic recovery after asystole has been reported in both children and adults after drowning in icy water, although such occurrences are rare and documented mostly in case reports or small series (see also Chapter 209, “Hypothermia”). A large series of 1377 open­water drowning victims found no intact survivors among the group submerged for more than  minutes, whether in warm or cold water, and
 there were no survivors of submersion greater than  minutes. There was also no difference in survival for children compared with adults in several
,23 studies, which contradicts the common belief that pediatric patients do better than adults. For asystolic victims of drowning with short submersion
 durations (i.e., a few minutes) and short transport times who receive CPR en route, a vigorous resuscitation attempt is reasonable. CPR should be abandoned if no response is noted. Conversely, because of the poor prognosis for intact neurologic survival, ED resuscitation attempts can reasonably
,22 be withheld from asystolic victims of drowning with longer submersion and transport times.
PREVENTION
The American Academy of Pediatrics’ Committee on Injury, Violence, and Poison Prevention has released a technical report on drowning prevention
,27 detailing information that can instruct local prevention programs. The World Health Organization and the Centers for Disease Control and
,28
Prevention have online information to guide parents and the lay public for drowning prevention.


